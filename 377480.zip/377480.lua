-- Lua provided by RyzenAPI
-- Game: addappid(377480)

-- MAIN APPLICATION
addappid(377480)

-- MAIN APP DEPOTS / PACKAGES
addappid(377481, 1, "f4b562df724284d7d5caa439225d8e6abba73e18c7160abd6590d1c1d57ec656")
