-- Lua provided by RyzenAPI
-- Game: WAIFU IMPACT

-- MAIN APPLICATION
addappid(1549060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549061, 1, "3ae2205af6b40736adfc75b1407ae92373a14d55097e584fa5932b7cc2e27a2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
