-- Lua provided by SkyAPI 
-- Game: AppID 1117090
addappid(1117090)
addappid(1117091, 1, "3190f262974ed84e2a6b9699c7312cc61bd6ed67f3f6b18d650a6a5d3c661932")
addappid(1117092, 1, "506db883c795315b48f3ea36ab5de60ae74ea8baaa3d9d5ab79bcf238ae772e9")
addappid(1117093, 1, "737e0240fa9182cf2e33bd4cafb9f83121d90f2bccdf16b9e4db9b32686b1ca9")
