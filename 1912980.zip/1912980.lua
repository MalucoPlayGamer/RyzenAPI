-- Lua provided by RyzenAPI 
-- Game: Tales of Novariel
addappid(1912980)
addappid(1912981, 1, "7011e67a878686857d5ab943e01ed04f273bc21caff6163eb8b6f30ea1ac0942")
addappid(1912982, 1, "f356c46d09c55f011ab24c9282d43eed5b758554d68d99e78126930492992081")
