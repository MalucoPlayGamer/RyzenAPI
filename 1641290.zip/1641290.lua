-- Lua provided by SkyAPI 
-- Game: AppID 1641290
addappid(1641290)
addappid(1641291, 1, "991a708ae4db5db1e3debab745373598e03592530514fc724ad8177be8a3dfd9")
