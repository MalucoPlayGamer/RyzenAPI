-- Lua provided by RyzenAPI
-- Game: addappid(510390)

-- MAIN APPLICATION
addappid(510390)

-- MAIN APP DEPOTS / PACKAGES
addappid(510391, 1, "d7234532d127c838eae5d39191c9d71b4c90921ebd0d5ca07d95008c9c4bf02d")
