-- Lua provided by RyzenAPI
-- Game: FWsim - Fireworks Display Simulator

-- MAIN APPLICATION
addappid(1494500)
-- Game: addappid(1494500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494501, 1, "3ee8043de76ce556308b524c11a553e65e3568d1539b82e9beead48addd5ca68")
