-- Lua provided by RyzenAPI
-- Game: Enthralled

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2812780)
addappid(2812782)
addappid(2812783)
addappid(3288830)
-- Game: addappid(2812780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812784,0,"1c578b5242f4abf47fa175cb0f89780618f5d6b22568a2e8898beaa117374c02")
