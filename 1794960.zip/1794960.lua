-- Lua provided by RyzenAPI
-- Game: Sonic Origins

-- MAIN APPLICATION
addappid(1794960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794961, 1, "5b6db7100856720d09b091714b4d53a0dabfd3d7cf8264ee8701110604742bb2")
addappid(1816000, 1, "3854adbad2506cf9e095074ff687ea7d71d860dc59a84182ec6bf56f137cf08b")
addappid(1816001, 1, "1c9e390d5c6a2388b5ccd5833fbe0e5639cdd60e5543251daaa48fb899336a11")
addappid(1816002, 1, "3da1170fef0cc209c771234d422cd90bbe215cb6d4201c1408aadb4dc57b78f0")
addappid(2343200, 0, "bde524f650a4ff0b53dd711be091153192798c50b5348f7dad561f16cf63ae31")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
