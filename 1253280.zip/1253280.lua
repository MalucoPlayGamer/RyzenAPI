-- Lua provided by RyzenAPI 
-- Game: AppID 1253280
addappid(1253280)
addappid(1253281, 1, "a700003f2a4eebd877e5e6e1bd42965fa80dc8aaa5a01592eae4f48a6079a9c9")
addappid(1253282, 1, "581354892f9ab90a9587b7eef3acf7764240808f14aca798d09b328a7bc46499")
