-- Lua provided by RyzenAPI
-- Game: Disc Golf Valley

-- MAIN APPLICATION
addappid(1642890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642891, 1, "728d8aa8735cd5a7c93745dc1e978dde685031256c4eb7c5e371d361f2f45709")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
