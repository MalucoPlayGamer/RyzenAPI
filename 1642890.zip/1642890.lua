-- Lua provided by RyzenAPI 
-- Game: Disc Golf Valley
addappid(1642890)
addappid(1642891, 1, "728d8aa8735cd5a7c93745dc1e978dde685031256c4eb7c5e371d361f2f45709")
