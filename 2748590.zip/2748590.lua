-- Lua provided by RyzenAPI
-- Game: Phenom Overdrive

-- MAIN APPLICATION
addappid(2748590)
-- Game: addappid(2748590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2748591, 1, "197dc666998d3b7f6c0de0248c30922b5e90935807bb111beccbb55bbb293fbe")
