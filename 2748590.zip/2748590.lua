-- Lua provided by SkyAPI 
-- Game: Phenom Overdrive
addappid(2748590)
addappid(2748591, 1, "197dc666998d3b7f6c0de0248c30922b5e90935807bb111beccbb55bbb293fbe")
