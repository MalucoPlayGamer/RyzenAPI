-- Lua provided by RyzenAPI
-- Game: DEEEER Simulator: Your Average Everyday Deer Game

-- MAIN APPLICATION
addappid(1018800)
-- Game: addappid(1018800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018801, 1, "bcabe13fbca24e274d6f8500661f2e7dcb0d563d1df259cbedbe791ee05eb11b")
