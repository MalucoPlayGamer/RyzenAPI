-- Lua provided by RyzenAPI
-- Game: DEEEER Simulator: Your Average Everyday Deer Game

-- MAIN APPLICATION
addappid(1018800)
addappid(1801910)
addappid(3360410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018801,0,"bcabe13fbca24e274d6f8500661f2e7dcb0d563d1df259cbedbe791ee05eb11b")

