-- Lua provided by SkyAPI 
-- Game: Delivery INC
addappid(1793260)
addappid(1793261, 1, "b0a5ea220d3ed5f402e74a255ee21ec59d0d293bdf134232a3d5ef49405d7968")
addappid(1793262, 1, "224169073d0d1cad9252c6978f1fe443559e344dae80928155ee1695954592e6")
