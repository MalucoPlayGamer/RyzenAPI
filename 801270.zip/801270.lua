-- Lua provided by RyzenAPI
-- Game: AppID 801270

-- MAIN APPLICATION
addappid(801270)
-- Game: addappid(801270)

-- MAIN APP DEPOTS / PACKAGES
addappid(801271, 1, "6cab35b6dda9ebfec218502b2b482d94ef325b3f2b42fecc8e4b01bcda05057c")
