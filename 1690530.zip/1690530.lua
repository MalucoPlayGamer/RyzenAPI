-- Lua provided by RyzenAPI
-- Game: AppID 1690530

-- MAIN APPLICATION
addappid(1690530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690531, 1, "5098a11eef104ffb84301154e30ea1cfdf4a257f61a6ba0d4b318c0a642cf518")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1702080)
