-- Lua provided by RyzenAPI
-- Game: SORTED! Demo

-- MAIN APPLICATION
addappid(2260300)
-- Game: addappid(2260300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260301, 1, "6dec6f00e2c1bd3a2cd3e0f81ccdd9bc4bff70dde8145e4025ff2a5686f0a45b")
