-- Lua provided by RyzenAPI
-- Game: Game: Cyber Assasin

-- MAIN APPLICATION
addappid(3015120)
-- Game: addappid(3015120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015121, 1, "164bc7359ab55e7e7f2cd596a43610be7d288928966af9f8df8e5399099bba0a")
