-- Lua provided by RyzenAPI
-- Game: Game: Impulse Rogue Demo

-- MAIN APPLICATION
addappid(2777060)
-- Game: addappid(2777060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777061, 1, "bc6bfe59a77a1dbb34f007705a682b80c434900b43507914132c72afa9f8e5c2")
