-- Lua provided by RyzenAPI
-- Game: 1218920

-- MAIN APPLICATION
addappid(1218920)
-- Game: addappid(1218920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218921, 1, "af5d57c94525724879b5bb0a48594146f36eb7827c7b4d84c86e5eac2c6b788c")
