-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: Special Delivery

-- MAIN APPLICATION
addappid(714780)

-- MAIN APP DEPOTS / PACKAGES
addappid(714781, 1, "77fba53b93fd3aad9823d1cedf46cc2520c798107dd5678969703029236e8548")
addappid(714782, 1, "9f14b37d0a095caaaa89c870e378972fecf1fc32c573dfb7d4bee5a116bb0d01")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
