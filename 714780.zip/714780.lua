-- Lua provided by RyzenAPI
-- Game: 714780

-- MAIN APPLICATION
addappid(714780)
-- Game: addappid(714780)

-- MAIN APP DEPOTS / PACKAGES
addappid(714781, 1, "77fba53b93fd3aad9823d1cedf46cc2520c798107dd5678969703029236e8548")
addappid(714782, 1, "9f14b37d0a095caaaa89c870e378972fecf1fc32c573dfb7d4bee5a116bb0d01")
