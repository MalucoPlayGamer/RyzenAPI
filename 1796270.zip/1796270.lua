-- Lua provided by RyzenAPI
-- Game: Circus Pocus

-- MAIN APPLICATION
addappid(1796270)
-- Game: addappid(1796270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796271, 1, "1615266377d557349dba127c4d79c81728860f4b1ae738155f22937d0c572d2c")
