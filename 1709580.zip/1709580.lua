-- Lua provided by RyzenAPI
-- Game: Tiny Robots Recharged

-- MAIN APPLICATION
addappid(1709580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709581, 1, "dc246223559b1139c3b2ec33376c96ee53db610725373215ee9a0906da776fca")
