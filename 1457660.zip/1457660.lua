-- Lua provided by RyzenAPI
-- Game: Game: 幻想三国志4外传

-- MAIN APPLICATION
addappid(1457660)
-- Game: addappid(1457660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457661, 1, "2322aaee0bcf0d6be1008bb24975e2a1cc45c441baa6bf4630193719a44a8afc")
addappid(1457662, 1, "02fc3c96b9bb28c617bd9888f2350b89a7930fe682789d8d54be5859ee320fa5")
