-- Lua provided by RyzenAPI
-- Game: Crazy People

-- MAIN APPLICATION
addappid(2663830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663831, 1, "5b4fb1cc39220122f41bdcc230195d1e1f7aadab9f3bc29561ab7e89302bf224")

