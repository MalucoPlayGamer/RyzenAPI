-- Lua provided by RyzenAPI
-- Game: addappid(1185490)

-- MAIN APPLICATION
addappid(1185490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185491, 1, "6f4aee7553d5809d8f98deb86e28322f21fe02ee60b3b15dc53382bbc906cbf4")
