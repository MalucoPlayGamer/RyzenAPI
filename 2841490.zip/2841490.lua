-- Lua provided by RyzenAPI
-- Game: Backrooms：The Exit

-- MAIN APPLICATION
addappid(2841490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841491, 1, "77fcaf5cae82fb7c2fb2ef3c0e5d34f8a3f4449bb0c9c8bc49fcbe11a1d6374c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
