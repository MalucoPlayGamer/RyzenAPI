-- Lua provided by RyzenAPI
-- Game: Backrooms：The Exit

-- MAIN APPLICATION
addappid(2841490)
-- Game: addappid(2841490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841491, 1, "77fcaf5cae82fb7c2fb2ef3c0e5d34f8a3f4449bb0c9c8bc49fcbe11a1d6374c")
