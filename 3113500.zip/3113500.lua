-- Lua provided by SkyAPI 
-- Game: KILL KILL KILL KILL
addappid(3113500)
addappid(3113501, 1, "a6ebd07e65cc0ca8f54f76db235a3f2084e6eb502b538e05f8d869d77ace032f")
