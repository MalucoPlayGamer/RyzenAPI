-- Lua provided by RyzenAPI
-- Game: 3113500

-- MAIN APPLICATION
addappid(3113500)
-- Game: addappid(3113500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3113501, 1, "a6ebd07e65cc0ca8f54f76db235a3f2084e6eb502b538e05f8d869d77ace032f")
