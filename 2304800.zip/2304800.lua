-- Lua provided by RyzenAPI
-- Game: 2304800

-- MAIN APPLICATION
addappid(2304800)
-- Game: addappid(2304800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304800,0,"65e14018cec79fdb03fe29e260537b66d3f3c9046dcedf722ea6ee7b26f57b61")
