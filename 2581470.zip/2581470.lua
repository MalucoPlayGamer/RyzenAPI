-- Lua provided by RyzenAPI
-- Game: Robocop: Rogue City Demo

-- MAIN APPLICATION
addappid(2581470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581471, 1, "6094091bf711f5624efc3de2fa3e00475b026c7353246ea4c0ae0282f505a113")
