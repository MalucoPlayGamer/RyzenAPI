-- Lua provided by RyzenAPI
-- Game: Anonymous Hacker Simulator

-- MAIN APPLICATION
addappid(2487060)
addappid(4025220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487061, 1, "8ac37795515ca0a4636f53e0c53fdf6ea730d263c91c019ede23a83562b8abae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
