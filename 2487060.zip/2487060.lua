-- Lua provided by RyzenAPI
-- Game: addappid(2487060)

-- MAIN APPLICATION
addappid(2487060)
addappid(4025220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487061, 1, "8ac37795515ca0a4636f53e0c53fdf6ea730d263c91c019ede23a83562b8abae")
