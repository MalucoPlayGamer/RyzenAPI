-- Lua provided by RyzenAPI
-- Game: 3387120

-- MAIN APPLICATION
addappid(3387120)
-- Game: addappid(3387120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3387121, 1, "fbb8e53e574102e5bd2206fea90243c0c7231170a362bb6a0852a8821bd0f17a")
