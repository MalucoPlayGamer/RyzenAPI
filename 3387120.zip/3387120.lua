-- Lua provided by RyzenAPI
-- Game: The Dark Gift

-- MAIN APPLICATION
addappid(3387120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3387121, 1, "fbb8e53e574102e5bd2206fea90243c0c7231170a362bb6a0852a8821bd0f17a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
