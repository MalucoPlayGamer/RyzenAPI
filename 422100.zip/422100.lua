-- Lua provided by RyzenAPI
-- Game: AppID 422100

-- MAIN APPLICATION
addappid(422100)
addappid(573880)

-- MAIN APP DEPOTS / PACKAGES
addappid(422101, 1, "adcb00be885f426857947f82e70416e534dd32efccc7f20752c107ea3947cb53")

