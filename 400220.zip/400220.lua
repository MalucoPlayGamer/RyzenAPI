-- Lua provided by RyzenAPI
-- Game: Bass Blocks

-- MAIN APPLICATION
addappid(400220)

-- MAIN APP DEPOTS / PACKAGES
addappid(400221, 1, "f052c71114b8f5c7db3b656f6aa1e6704edc9d795e4cc09496702590744ee7da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
