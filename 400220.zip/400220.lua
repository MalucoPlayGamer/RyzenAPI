-- Lua provided by RyzenAPI
-- Game: 400220

-- MAIN APPLICATION
addappid(400220)
-- Game: addappid(400220)

-- MAIN APP DEPOTS / PACKAGES
addappid(400221, 1, "f052c71114b8f5c7db3b656f6aa1e6704edc9d795e4cc09496702590744ee7da")
