-- Lua provided by RyzenAPI
-- Game: Two Guys One Cabin

-- MAIN APPLICATION
addappid(1518300)
-- Game: addappid(1518300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518301, 1, "52e8bc504803b5ad60190c03077c3466a0c4a343e97dc49a13656152c198b600")
