-- Lua provided by RyzenAPI
-- Game: addappid(1203790)

-- MAIN APPLICATION
addappid(1203790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203791, 1, "504e2bc39bee928e00bf6603dca3267cf1a24a092beaf17eccc307c31a4c048e")
addappid(1203792, 1, "efd2d2c670f682c6143d6153f8835bc7e63f103d2b73370653b0a13dbbe4e84b")
