-- Lua provided by RyzenAPI
-- Game: Electronic Piano

-- MAIN APPLICATION
addappid(831710)

-- MAIN APP DEPOTS / PACKAGES
addappid(831712,0,"677e4b0543f780a429a0e1648a0d65815d4f2dc25f95abdc8487381d247983f5")

