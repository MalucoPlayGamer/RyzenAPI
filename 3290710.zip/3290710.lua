-- Lua provided by RyzenAPI 
-- Game: RATSHAKER™
addappid(3290710)
addappid(3290711, 1, "37397ac556b50c73f63e87d564ac2d199d4cbfc1bbd0e18c01dc0174009fd33a")
