-- Lua provided by RyzenAPI
-- Game: RATSHAKER™

-- MAIN APPLICATION
addappid(3290710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3290711, 1, "37397ac556b50c73f63e87d564ac2d199d4cbfc1bbd0e18c01dc0174009fd33a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3617860)
addappid(4533540)
addappid(4892280)
addappid(4972410)
