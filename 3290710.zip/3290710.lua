-- Lua provided by RyzenAPI
-- Game: 3290710

-- MAIN APPLICATION
addappid(3290710)
-- Game: addappid(3290710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3290711, 1, "37397ac556b50c73f63e87d564ac2d199d4cbfc1bbd0e18c01dc0174009fd33a")
