-- Lua provided by RyzenAPI
-- Game: 杀青 Demo

-- MAIN APPLICATION
addappid(2884680)
-- Game: addappid(2884680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884681, 1, "87313d9730e192f4ba806bada8856f2d97752703296d003b40138f2f10400271")
