-- Lua provided by SkyAPI 
-- Game: DreamEater 噬梦者
addappid(1015830)
addappid(1015831, 1, "7cb059b1a03d68133c86f81c28d28334b51e519a44995ef1282412166197cfbe")
addappid(1056190, 0, "c7aec0e24cce33f690fff03fa2e5a887684cd6fce774541c4cf722153284f953")
