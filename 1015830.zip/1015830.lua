-- Lua provided by RyzenAPI
-- Game: DreamEater 噬梦者

-- MAIN APPLICATION
addappid(1015830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1015831, 1, "7cb059b1a03d68133c86f81c28d28334b51e519a44995ef1282412166197cfbe")
addappid(1056190, 0, "c7aec0e24cce33f690fff03fa2e5a887684cd6fce774541c4cf722153284f953")

