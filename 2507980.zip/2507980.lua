-- Lua provided by SkyAPI 
-- Game: Meta Ghost: Breaking Show
addappid(2507980)
addappid(2507981, 1, "8520d99b3096cc762d3ad718e0b7a9247890d54f1630eb6f1ea63336e22ca59a")
