-- Lua provided by RyzenAPI
-- Game: Touhou Multi Scroll Shooting

-- MAIN APPLICATION
addappid(1125000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1125001, 1, "1ca748ebf9daa041d0d3066ea5a38648a0674f9dd01bda25c57e73f04413ce14")

