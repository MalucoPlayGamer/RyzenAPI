-- Lua provided by RyzenAPI 
-- Game: Touhou Multi Scroll Shooting
addappid(1125000)
addappid(1125001, 1, "1ca748ebf9daa041d0d3066ea5a38648a0674f9dd01bda25c57e73f04413ce14")
