-- Lua provided by RyzenAPI
-- Game: 1125000

-- MAIN APPLICATION
addappid(1125000)
-- Game: addappid(1125000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125001, 1, "1ca748ebf9daa041d0d3066ea5a38648a0674f9dd01bda25c57e73f04413ce14")
