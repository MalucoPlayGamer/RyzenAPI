-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Seychelles XP

-- MAIN APPLICATION
addappid(1232050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232050,0,"bc63461ae4b2465e6326142bab6316da2cd09e4c5e901b897074e40264a74fe0")

