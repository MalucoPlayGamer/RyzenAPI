-- Lua provided by RyzenAPI
-- Game: Superhero Market

-- MAIN APPLICATION
addappid(3343790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343791, 1, "59c2c08614e675395a3b6a2fd990325fb436fe49461df1b2b227401be95655eb")

