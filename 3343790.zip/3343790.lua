-- Lua provided by RyzenAPI
-- Game: Superhero Market

-- MAIN APPLICATION
addappid(3343790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3343791, 1, "59c2c08614e675395a3b6a2fd990325fb436fe49461df1b2b227401be95655eb")

