-- 4631110's Lua and Manifest Created by Hubcap Manifest
-- Trashy Cashy
-- Created: June 24, 2026 at 13:33:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4631110) -- Trashy Cashy
-- MAIN APP DEPOTS
addappid(4631111, 1, "38172572480c0a2bd94b559ef670c371b0c9140d671e33e96f3cd1b7f272a810") -- Depot 4631111
setManifestid(4631111, "3463819156607450823", 174356192)