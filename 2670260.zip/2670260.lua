-- Lua provided by RyzenAPI
-- Game: addappid(2670260)

-- MAIN APPLICATION
addappid(2670260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670261, 1, "af9c124325c3650a0ffc1a6592ede5d02459919dcf0af521e8384557be3fd78a")
