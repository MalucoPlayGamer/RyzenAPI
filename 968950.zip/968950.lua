-- Lua provided by RyzenAPI
-- Game: Sakura MMO 2

-- MAIN APPLICATION
addappid(968950)

-- MAIN APP DEPOTS / PACKAGES
addappid(968951, 1, "2e2b834a3aaba6e6c0a68ddb9548518abcceeb46441774f969e90d308aba1b11")
