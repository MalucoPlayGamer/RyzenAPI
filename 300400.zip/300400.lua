-- Lua provided by RyzenAPI
-- Game: 300400

-- MAIN APPLICATION
addappid(300400)
-- Game: addappid(300400)

-- MAIN APP DEPOTS / PACKAGES
addappid(300401, 1, "190076465a2ec096ef620c9e945e01ea0d9ad59ac58b5920b20012c770fdce48")
