-- Lua provided by RyzenAPI
-- Game: Game: AppID 1587120

-- MAIN APPLICATION
addappid(1587120)
-- Game: addappid(1587120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587121, 1, "d9691916b9002c2b22ac6727c1a552181549c99e02cee3465929ec107ab0f4a4")
