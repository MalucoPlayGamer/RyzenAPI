-- Lua provided by RyzenAPI
-- Game: Game: AppID 44620

-- MAIN APPLICATION
addappid(44620)
-- Game: addappid(44620)

-- MAIN APP DEPOTS / PACKAGES
addappid(44621, 1, "8212c0f16cd849f0152173eae1832cfa93ceee8135c99ad293a204ba7f9ee034")
