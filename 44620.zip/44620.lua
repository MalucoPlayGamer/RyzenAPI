-- Lua provided by SkyAPI 
-- Game: AppID 44620
addappid(44620)
addappid(44621, 1, "8212c0f16cd849f0152173eae1832cfa93ceee8135c99ad293a204ba7f9ee034")
