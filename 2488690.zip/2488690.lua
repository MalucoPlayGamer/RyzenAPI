-- Lua provided by RyzenAPI
-- Game: Desktop Beach Girls

-- MAIN APPLICATION
addappid(2488690)
addappid(2547130)
-- Game: addappid(2488690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488691, 1, "2837cbd7a0223c4496842d852f6f9792e868c1988eeff6bf4918fa6abe928623")
