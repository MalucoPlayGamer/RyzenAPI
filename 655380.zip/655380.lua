-- Lua provided by SkyAPI 
-- Game: AppID 655380
addappid(655380)
addappid(655381, 1, "4c2a4bb4d15328881db0ed55492393e5b364b965560c6eacf7912bf75e1a53c0")
