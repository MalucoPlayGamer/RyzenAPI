-- Lua provided by RyzenAPI
-- Game: Dig Dog

-- MAIN APPLICATION
addappid(655380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(655381, 1, "4c2a4bb4d15328881db0ed55492393e5b364b965560c6eacf7912bf75e1a53c0")
