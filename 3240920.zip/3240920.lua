-- Lua provided by RyzenAPI 
-- Game: AppID 3240920
addappid(3240920)
addappid(3240921, 1, "64b741910ffa30b9689f89da4f48879cd11e4c7a5c5403ec3703b199dbece8de")
