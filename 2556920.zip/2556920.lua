-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2556920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556920,0,"650909a2f4d56a9edb4abd3ebff2eb50ed79888155049475aea37c2233bf7330")
