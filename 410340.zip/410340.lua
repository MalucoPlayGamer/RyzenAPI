-- 410340's Lua and Manifest Created by Hubcap Manifest
-- Liftoff
-- Created: August 14, 2026 at 00:31:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(410340, 1, "7cbe184b90a8017eb8cda92d33215be543620191be96cd5ea7bd93925365b252") -- Liftoff
-- MAIN APP DEPOTS
addappid(410341, 1, "6607f8580cbb34ef10dd7066d5d69ce9d9c2b77477b408775bdea40885b65318") -- Liftoff Content Windows
setManifestid(410341, "831944730041442230", 22429081308)
addappid(410342, 1, "0a0d311d12a569a44c57dfc44e12441e887eed6667881aeb264f558b260f058e") -- Liftoff Content Mac
setManifestid(410342, "7164984004979013946", 22001789532)
addappid(410343, 1, "33f27f4de551b8801724c8150462a4bf03bfaa284173530354341fda44f66e63") -- Liftoff Content Linux
setManifestid(410343, "2143670296403104777", 22355255656)
addappid(410344, 1, "b073d5a8847539adb3cd915ea1e88d6373dc25cbee902354e69246bb3aacfcca") -- Liftoff Content Windows (32Bit)
setManifestid(410344, "7217323552862899201", 14207276419)
-- DLCS WITH DEDICATED DEPOTS
-- Liftoff - Night Fever (AppID: 1020100)
addappid(1020100)
addappid(1020104, 1, "fe135aa7f9b6b35edb302b754d2cbea0aa317fce4c9a98fc2e82b4ff51f6f45e") -- Liftoff - Night Fever - Liftoff - Night Fever (Windows 32bit)
setManifestid(1020104, "4751368696021242308", 3791463994)
addappid(1020101, 1, "a77a77978cfb70d2d1f78af4a8f4cbcc43fa089e3ebd63bc2b2c97b08897e3fc") -- Liftoff - Night Fever - Liftoff - Night Fever (Windows 64bit)
setManifestid(1020101, "7198052160123485458", 3096499803)
addappid(1020102, 1, "79b53caba7e254d7d730b63697de2d39e4fb9a2f749c45e9ceb9fc9d5f97b466") -- Liftoff - Night Fever - Liftoff - Night Fever (Mac)
setManifestid(1020102, "3323345772559749375", 3071756632)
addappid(1020103, 1, "c2e02b451e8ebd4955a225df3f2796a2b6ea5276083334ac10ee1de5c10d06b9") -- Liftoff - Night Fever - Liftoff - Night Fever (Linux)
setManifestid(1020103, "5936232441744433700", 3090195097)
-- Liftoff - DJI FPV (AppID: 1891780)
addappid(1891780)
addappid(1891781, 1, "5cc09b86101e35be38bf44688d9f8177b46c4e6442cabf108b0d90c8d91af08e") -- Liftoff - DJI FPV - Depot 1891781
setManifestid(1891781, "6439421746963659783", 114467972)
addappid(1891782, 1, "ec0b09e78187c7cf0802713bb287e85ec72ab5ab7b2545aa2744bd0ab42de36d") -- Liftoff - DJI FPV - Depot 1891782
setManifestid(1891782, "6115504840605016488", 114467631)
addappid(1891783, 1, "685e88d21ae3172dd6a671183d0b91840f537670a3735588210eed87ba50e915") -- Liftoff - DJI FPV - Depot 1891783
setManifestid(1891783, "8624376585243696427", 114467807)
-- Liftoff - Slipstream (AppID: 2019790)
addappid(2019790)
addappid(2019791, 1, "1051ab2c812f27beb32e2ce9fd5a4db6422576fcdb6f349dee1e9c0861356af1") -- Liftoff - Slipstream - Depot 2019791
setManifestid(2019791, "2846682758570770351", 449400676)
addappid(2019792, 1, "daa8f7e42649a06883c48ea3d1d15be0638a0bad59eb26fc3defa624219e54ae") -- Liftoff - Slipstream - Depot 2019792
setManifestid(2019792, "774346816007903641", 447769434)
addappid(2019793, 1, "f8f340d15cb05436b21faf323b9d4190eab5673bae1d404decd1c388368f004a") -- Liftoff - Slipstream - Depot 2019793
setManifestid(2019793, "5164331842214565953", 449198417)