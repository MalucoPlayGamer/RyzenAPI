-- Lua provided by RyzenAPI
-- Game: Game: Liftoff®: FPV Drone Racing

-- MAIN APPLICATION
addappid(410340)
-- Game: addappid(410340)

-- MAIN APP DEPOTS / PACKAGES
addappid(410341, 1, "6607f8580cbb34ef10dd7066d5d69ce9d9c2b77477b408775bdea40885b65318")
addappid(410342, 1, "0a0d311d12a569a44c57dfc44e12441e887eed6667881aeb264f558b260f058e")
addappid(410343, 1, "33f27f4de551b8801724c8150462a4bf03bfaa284173530354341fda44f66e63")
addappid(410344, 1, "b073d5a8847539adb3cd915ea1e88d6373dc25cbee902354e69246bb3aacfcca")
