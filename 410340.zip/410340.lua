-- Lua provided by RyzenAPI
-- Game: Liftoff

-- MAIN APPLICATION
addappid(1020100)
addappid(1891780)
addappid(2019790)

-- MAIN APP DEPOTS / PACKAGES
addappid(410340, 1, "7cbe184b90a8017eb8cda92d33215be543620191be96cd5ea7bd93925365b252") -- Liftoff
addappid(410341, 1, "6607f8580cbb34ef10dd7066d5d69ce9d9c2b77477b408775bdea40885b65318") -- Liftoff Content Windows
addappid(410342, 1, "0a0d311d12a569a44c57dfc44e12441e887eed6667881aeb264f558b260f058e") -- Liftoff Content Mac
addappid(410343, 1, "33f27f4de551b8801724c8150462a4bf03bfaa284173530354341fda44f66e63") -- Liftoff Content Linux
addappid(410344, 1, "b073d5a8847539adb3cd915ea1e88d6373dc25cbee902354e69246bb3aacfcca") -- Liftoff Content Windows (32Bit)
addappid(1020101, 1, "a77a77978cfb70d2d1f78af4a8f4cbcc43fa089e3ebd63bc2b2c97b08897e3fc") -- Liftoff - Night Fever - Liftoff - Night Fever (Windows 64bit)
addappid(1020102, 1, "79b53caba7e254d7d730b63697de2d39e4fb9a2f749c45e9ceb9fc9d5f97b466") -- Liftoff - Night Fever - Liftoff - Night Fever (Mac)
addappid(1020103, 1, "c2e02b451e8ebd4955a225df3f2796a2b6ea5276083334ac10ee1de5c10d06b9") -- Liftoff - Night Fever - Liftoff - Night Fever (Linux)
addappid(1020104, 1, "fe135aa7f9b6b35edb302b754d2cbea0aa317fce4c9a98fc2e82b4ff51f6f45e") -- Liftoff - Night Fever - Liftoff - Night Fever (Windows 32bit)
addappid(1891781, 1, "5cc09b86101e35be38bf44688d9f8177b46c4e6442cabf108b0d90c8d91af08e") -- Liftoff - DJI FPV - Depot 1891781
addappid(1891782, 1, "ec0b09e78187c7cf0802713bb287e85ec72ab5ab7b2545aa2744bd0ab42de36d") -- Liftoff - DJI FPV - Depot 1891782
addappid(1891783, 1, "685e88d21ae3172dd6a671183d0b91840f537670a3735588210eed87ba50e915") -- Liftoff - DJI FPV - Depot 1891783
addappid(2019791, 1, "1051ab2c812f27beb32e2ce9fd5a4db6422576fcdb6f349dee1e9c0861356af1") -- Liftoff - Slipstream - Depot 2019791
addappid(2019792, 1, "daa8f7e42649a06883c48ea3d1d15be0638a0bad59eb26fc3defa624219e54ae") -- Liftoff - Slipstream - Depot 2019792
addappid(2019793, 1, "f8f340d15cb05436b21faf323b9d4190eab5673bae1d404decd1c388368f004a") -- Liftoff - Slipstream - Depot 2019793

