-- Lua provided by RyzenAPI
-- Game: Game: Warplane inc.

-- MAIN APPLICATION
addappid(1578250)
-- Game: addappid(1578250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1578251, 1, "121041ba571b82d754ec11584b2f0264f288fb218232020b53827c2e72f2c76e")
