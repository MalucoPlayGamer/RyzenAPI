-- Lua provided by RyzenAPI
-- Game: Warplane inc.

-- MAIN APPLICATION
addappid(1578250)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(1578251, 1, "121041ba571b82d754ec11584b2f0264f288fb218232020b53827c2e72f2c76e")

