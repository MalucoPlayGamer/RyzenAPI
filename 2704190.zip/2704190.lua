-- Lua provided by RyzenAPI
-- Game: addappid(2704190)

-- MAIN APPLICATION
addappid(2704190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704190,0,"586acc45f5598947febb7773ba34427a73508790a856a192a3d123e6faddfded")
