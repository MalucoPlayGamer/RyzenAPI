-- Lua provided by SkyAPI 
-- Game: 晨海星澜 - 追忆篇 Demo
addappid(2138690)
addappid(2138691, 1, "34b0f53b2225a2204eeee97b1f1c05ebd59be7f442f613eb6c72236c3c44acfa")
