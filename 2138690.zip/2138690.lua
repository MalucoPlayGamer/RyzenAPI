-- Lua provided by RyzenAPI
-- Game: Game: 晨海星澜 - 追忆篇 Demo

-- MAIN APPLICATION
addappid(2138690)
-- Game: addappid(2138690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138691, 1, "34b0f53b2225a2204eeee97b1f1c05ebd59be7f442f613eb6c72236c3c44acfa")
