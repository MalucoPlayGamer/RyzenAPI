-- Lua provided by RyzenAPI 
-- Game: DOLL EYE: CHAPTER ONE
addappid(2575360)
addappid(2575361, 1, "3028a039f1c59b642f186ee789619ab0e1031f61ebb20462c1c00d31f0c9d97e")
addappid(2575362, 1, "bda6499eee374cef120c8c155ee892a003fac5bab7be10a50d120933b113b48e")
