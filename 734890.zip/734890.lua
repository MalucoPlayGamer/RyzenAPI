-- Lua provided by RyzenAPI
-- Game: The Francy Droo & Friends Collection

-- MAIN APPLICATION
addappid(734890)
-- Game: addappid(734890)

-- MAIN APP DEPOTS / PACKAGES
addappid(734891, 1, "73dd09e0d5833da0436a71d3fabcbba1637a656d506aff2ccc8f544017429629")
