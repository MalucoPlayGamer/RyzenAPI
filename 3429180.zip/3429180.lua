-- Lua provided by RyzenAPI
-- Game: Game: AppID 3429180

-- MAIN APPLICATION
addappid(3429180)
-- Game: addappid(3429180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3429181, 1, "137f40e7ca63fe1129a2bfc87d2f6a2e2fc2ef81d21c1802bc65490ea541f8dc")
