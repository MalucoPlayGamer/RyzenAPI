-- Lua provided by RyzenAPI 
-- Game: AppID 1084480
addappid(1084480)
addappid(1084481, 1, "0ba09a553ffb63e90825643fc725ee58e0a442120b92070b6cc3814d4a07ef9b")
addappid(1084482, 1, "7d798d029113f1f1d17696a5fb208fa2b52f4aef3422c654c2559da540d8ed68")
