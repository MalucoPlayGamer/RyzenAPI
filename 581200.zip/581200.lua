-- Lua provided by RyzenAPI
-- Game: addappid(581200)

-- MAIN APPLICATION
addappid(581200)

-- MAIN APP DEPOTS / PACKAGES
addappid(581201, 1, "f40a38724ce857f2d0c317675b2b617b6e869a84de927128d9c77ea4a9ddee79")
