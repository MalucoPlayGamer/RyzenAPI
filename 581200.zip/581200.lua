-- Lua provided by RyzenAPI
-- Game: Nash Racing

-- MAIN APPLICATION
addappid(581200)

-- MAIN APP DEPOTS / PACKAGES
addappid(581201, 1, "f40a38724ce857f2d0c317675b2b617b6e869a84de927128d9c77ea4a9ddee79")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
