-- Lua provided by RyzenAPI
-- Game: addappid(1007810)

-- MAIN APPLICATION
addappid(1007810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007811, 1, "455d6d421d216675c42a398f1e08e341a8bff4f09988ee975dbd80fd2bc23a51")
