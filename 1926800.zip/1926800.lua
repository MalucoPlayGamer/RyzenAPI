-- Lua provided by RyzenAPI
-- Game: addappid(1926800)

-- MAIN APPLICATION
addappid(1926800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926801, 1, "b14ec8efc39254b579aee1d7d87d8e3519ef313600cc3c996f13a40f713fcc6b")
