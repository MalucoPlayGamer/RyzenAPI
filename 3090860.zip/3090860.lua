-- Lua provided by RyzenAPI
-- Game: The elevator

-- MAIN APPLICATION
addappid(3090860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3090861, 1, "557b2eb393a527d0cf119c3ce15e1af2939bf779baf99f94d118e8e0a24ccd9f")

