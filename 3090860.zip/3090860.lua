-- Lua provided by RyzenAPI
-- Game: The elevator

-- MAIN APPLICATION
addappid(3090860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3090861, 1, "557b2eb393a527d0cf119c3ce15e1af2939bf779baf99f94d118e8e0a24ccd9f")

