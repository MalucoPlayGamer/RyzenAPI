-- Lua provided by RyzenAPI
-- Game: addappid(973810)

-- MAIN APPLICATION
addappid(973810)

-- MAIN APP DEPOTS / PACKAGES
addappid(973812,0,"0ad0033395422e2622fa4bd3035a017636c7617cb94a84a9ffd50c8f99d43a0b")
