-- Lua provided by RyzenAPI
-- Game: Journey To The Savage Planet

-- MAIN APPLICATION
addappid(973810)
addappid(1503200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(973812,0,"0ad0033395422e2622fa4bd3035a017636c7617cb94a84a9ffd50c8f99d43a0b")

