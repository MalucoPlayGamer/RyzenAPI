-- Lua provided by SkyAPI 
-- Game: Tomb Raider: Underworld
addappid(8140)
addappid(8141, 1, "cea2c65903e50bec294289d441b22b0f9c65f6e6aad83700c30c174b312fe36e")
