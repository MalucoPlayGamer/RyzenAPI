-- Lua provided by RyzenAPI
-- Game: 1162010

-- MAIN APPLICATION
addappid(1162010)
-- Game: addappid(1162010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162011, 1, "cfb7b594b169d0c4ff19008a88363eabd9ccca1f52c0fb875032d27587fb3aa0")
