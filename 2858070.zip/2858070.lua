-- Lua provided by RyzenAPI
-- Game: addappid(2858070)

-- MAIN APPLICATION
addappid(2858070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858070,0,"f03863c771b99b2003bf8ec90d5fcce93b03e25263b5709ef6ff26027ddf92d9")
