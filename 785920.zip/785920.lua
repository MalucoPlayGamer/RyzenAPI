-- Lua provided by RyzenAPI
-- Game: Madness of the Architect

-- MAIN APPLICATION
addappid(785920)

-- MAIN APP DEPOTS / PACKAGES
addappid(785921, 1, "d4db6b11195d31ab347deba0aca6daede7e8d4e86c5e6e59e69a823251a6c085")
