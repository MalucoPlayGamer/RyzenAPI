-- Lua provided by RyzenAPI
-- Game: Storm over the Pacific

-- MAIN APPLICATION
addappid(302320)
-- Game: addappid(302320)

-- MAIN APP DEPOTS / PACKAGES
addappid(302321, 1, "a3b09e77f6c49e65aece9c41ccffc969eb8f7d082d8389c2e03a2d72b7d36e6b")
