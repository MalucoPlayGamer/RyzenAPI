-- Lua provided by RyzenAPI
-- Game: Valiantia

-- MAIN APPLICATION
addappid(1310770)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1310771, 1, "7554dd2ec7719f728456c04e558d95c53d5f15a719f6fd813ecf45f73056e59e")

