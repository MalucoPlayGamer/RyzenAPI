-- Lua provided by SkyAPI 
-- Game: Metrail
addappid(1179750)
addappid(1179751, 1, "3981baedb5eb0602cbbba56bf739c2620eb3181b8bdb8f6dfade7be99176241d")
addappid(1179752, 1, "3abce193dcf46ac9d691f9f0d7c1541a10cc4608311e9453d6fd540661348d76")
