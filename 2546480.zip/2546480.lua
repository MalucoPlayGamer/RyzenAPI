-- Lua provided by RyzenAPI
-- Game: Game: Infinity Islets

-- MAIN APPLICATION
addappid(2546480)
-- Game: addappid(2546480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546481, 1, "c715a9605d1b2f5e8593907746b8a0e81a7001f9c9dea309d2721bd7a5a030ad")
