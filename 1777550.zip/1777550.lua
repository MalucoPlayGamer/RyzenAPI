-- Lua provided by RyzenAPI
-- Game: Fuyu no Tsuma

-- MAIN APPLICATION
addappid(1777550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777551, 1, "adb00b71ca265703464eac806eeb9c7358b99582c84068df4508da3d9bedc20f")

