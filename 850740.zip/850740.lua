-- Lua provided by RyzenAPI
-- Game: The Princess Adventure

-- MAIN APPLICATION
addappid(850740)

-- MAIN APP DEPOTS / PACKAGES
addappid(850741, 1, "3931b61ea6a3bb2cdf44df79a2fd4cc3d1e054ae6533ccb3f48bef07bc559db7")
