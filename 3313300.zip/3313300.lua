-- Lua provided by RyzenAPI
-- Game: Jet Attack Demo

-- MAIN APPLICATION
addappid(3313300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3313301, 1, "4840b9c3b41bfd46a3216692af5790d03ab88806ca4948c584f7f1b46b2f6f61")

