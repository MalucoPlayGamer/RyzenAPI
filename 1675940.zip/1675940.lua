-- Lua provided by RyzenAPI
-- Game: 江湖行

-- MAIN APPLICATION
addappid(1675940)
-- Game: addappid(1675940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675941, 1, "4c24636e2466a9d0cd2dbe69caa7149a56da3f656e7739029f6029b25a733bc7")
