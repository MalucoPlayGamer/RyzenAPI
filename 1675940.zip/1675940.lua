-- Lua provided by SkyAPI 
-- Game: 江湖行
addappid(1675940)
addappid(1675941, 1, "4c24636e2466a9d0cd2dbe69caa7149a56da3f656e7739029f6029b25a733bc7")
