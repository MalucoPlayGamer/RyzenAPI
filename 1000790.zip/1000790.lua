-- Lua provided by RyzenAPI
-- Game: Flex Apocalypse Racing

-- MAIN APPLICATION
addappid(1000790)
addappid(1001580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1000791, 1, "3f6e4df4d3191ad24e8bdce535c9c2695f447caa03e34930bd2332677b7dfe9f")

