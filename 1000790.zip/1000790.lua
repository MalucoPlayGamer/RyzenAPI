-- Lua provided by RyzenAPI
-- Game: addappid(1000790)

-- MAIN APPLICATION
addappid(1000790)
addappid(1001580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000791, 1, "3f6e4df4d3191ad24e8bdce535c9c2695f447caa03e34930bd2332677b7dfe9f")
