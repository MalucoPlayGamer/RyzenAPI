-- Lua provided by RyzenAPI
-- Game: 2633220

-- MAIN APPLICATION
addappid(2633220)
-- Game: addappid(2633220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633220,0,"7ef2cd6e5124bf16d1ba8ad3d313fcdc609ebcadf533d65418d021ee204bcf24")
