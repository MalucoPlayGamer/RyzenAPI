-- Lua provided by RyzenAPI
-- Game: Self Defense Dojo

-- MAIN APPLICATION
addappid(2534120)
-- Game: addappid(2534120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2534121, 1, "d59188b9f24874801e3b610eb5ca4e5485098872f5c980e5fb2906d38ec98c7d")
