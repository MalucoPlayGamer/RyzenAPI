-- Lua provided by RyzenAPI
-- Game: Hades II

-- MAIN APPLICATION
addappid(1145350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145352,0,"ff02298666a5470ddca19f89593983136f6d1727fc82957ca6b847133783b4e7")
addappid(1145354,0,"71f0364cb7bd2b7d7755605c7983bf2b73101a6e2e0ef6b7082d275a4650f7e5")
addappid(1145355,0,"67def0278f458945e71a75914c686e5bf4d3f90c8b4320795c3b78ad999afc56")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
