-- Lua provided by RyzenAPI
-- Game: addappid(2803810)

-- MAIN APPLICATION
addappid(2803810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803811, 1, "73eccebf0686f4b26949e53b277068f6b408e3e52c0eba1d2aa3bc83cd767400")
