-- Lua provided by RyzenAPI
-- Game: 2623040

-- MAIN APPLICATION
addappid(2623040)
-- Game: addappid(2623040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623041, 1, "ffb7b6ea3589f131a8597ef59c7c8c974ca0e3432a2828e4d74fcf11482a7c8a")
