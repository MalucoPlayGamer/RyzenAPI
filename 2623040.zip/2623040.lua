-- Lua provided by RyzenAPI
-- Game: Robots at Midnight

-- MAIN APPLICATION
addappid(2623040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2623041, 1, "ffb7b6ea3589f131a8597ef59c7c8c974ca0e3432a2828e4d74fcf11482a7c8a")

