-- Lua provided by RyzenAPI
-- Game: Snow Plowing Simulator - First Snow

-- MAIN APPLICATION
addappid(2639460)
-- Game: addappid(2639460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639461, 1, "64c2aa1ecf5a79dabe3a749265aa81245bd70fdf5cb9429c1c9ba567ede944ee")
