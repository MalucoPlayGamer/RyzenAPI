-- Lua provided by SkyAPI 
-- Game: Snow Plowing Simulator - First Snow
addappid(2639460)
addappid(2639461, 1, "64c2aa1ecf5a79dabe3a749265aa81245bd70fdf5cb9429c1c9ba567ede944ee")
