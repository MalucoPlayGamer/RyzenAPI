-- Lua provided by RyzenAPI
-- Game: Snow Plowing Simulator - First Snow

-- MAIN APPLICATION
addappid(2639460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639461, 1, "64c2aa1ecf5a79dabe3a749265aa81245bd70fdf5cb9429c1c9ba567ede944ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
