-- Lua provided by RyzenAPI
-- Game: 2674970

-- MAIN APPLICATION
addappid(2674970)
-- Game: addappid(2674970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674971, 1, "606890571c5cafa02a8df6718a9f3af9be56d68c83bfd8005c570e4b5482d4ce")
