-- Lua provided by RyzenAPI
-- Game: 1693500

-- MAIN APPLICATION
addappid(1693500)
-- Game: addappid(1693500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693501, 1, "3d42baa4424cd4b68e38d3c20b73b3d72c5cd264ce4566c7d564714f9845ce5a")
