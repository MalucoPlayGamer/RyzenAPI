-- Lua provided by RyzenAPI
-- Game: FRAMED Collection - The Original Soundtrack

-- MAIN APPLICATION
addappid(856840)

-- MAIN APP DEPOTS / PACKAGES
addappid(856840,0,"dd8477b97b260338c64de543cf3d63ea7645320b4df69836251d5be8da8333a6")

