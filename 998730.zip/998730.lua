-- Lua provided by RyzenAPI
-- Game: Hail To The King

-- MAIN APPLICATION
addappid(998730)

-- MAIN APP DEPOTS / PACKAGES
addappid(998731, 1, "32378f50f6ced87989c5e09515b34803a948f5cd5902e7f03b6ec3db8dd2b693")
