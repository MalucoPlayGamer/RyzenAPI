-- 4731050's Lua and Manifest Created by Hubcap Manifest
-- Who Clicked My Bones
-- Created: July 19, 2026 at 00:22:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4731050) -- Who Clicked My Bones
-- MAIN APP DEPOTS
addappid(4731051, 1, "9f9cf9671368c759f63364ec700f498fd184bf3e4b74f82f8c76b30573b97612") -- Depot 4731051
setManifestid(4731051, "6110059911853477141", 265940238)