-- Lua provided by RyzenAPI
-- Game: OPUS: The Day We Found Earth

-- MAIN APPLICATION
addappid(457680)
-- Game: addappid(457680)

-- MAIN APP DEPOTS / PACKAGES
addappid(457681, 1, "736e11f25bcd1f1338a36d89acfd0276c9b3a1d0993d23175cc471daba9dbbc3")
addappid(457682, 1, "3d6fd0f52cc42aad0bd98f83974b89315ff7532283313d481869274f06ebce8a")
addappid(457683, 1, "606ce2d0f6ca12716b1d7003d761a3147bf46fc0e4aa280a75bfadc8ce38fda4")
addappid(458740, 0, "c863f29f0d2abd96428826b3cdd47e201f07a19d051f3e495f3667e8ae8199e9")
