-- 974480's Lua and Manifest Created by Hubcap Manifest
-- Echoes of Mystralia
-- Created: August 11, 2026 at 21:54:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(974480) -- Echoes of Mystralia
-- MAIN APP DEPOTS
addappid(974482, 1, "9e3ed4c748b7e07b4f1ab0587948c5ef222e9c2ebea8eeb88f274f048d7fc9c7") -- Depot 974482
setManifestid(974482, "7538153243037044677", 6380817089)