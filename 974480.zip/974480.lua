-- Lua provided by RyzenAPI
-- Game: Echoes of Mystralia

-- MAIN APPLICATION
addappid(974480) -- Echoes of Mystralia

-- MAIN APP DEPOTS / PACKAGES
addappid(974482, 1, "9e3ed4c748b7e07b4f1ab0587948c5ef222e9c2ebea8eeb88f274f048d7fc9c7") -- Depot 974482

