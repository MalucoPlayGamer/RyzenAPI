-- Lua provided by RyzenAPI 
-- Game: Unreal Island
addappid(2915080)
addappid(2915081, 1, "ba97f8de3ac88bb025abc05c4046ffbaf6a67829a9740fa4121614a57d39ce11")
