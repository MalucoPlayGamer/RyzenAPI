-- Lua provided by RyzenAPI
-- Game: Game: Hello Neighbor 2 Alpha 1.5

-- MAIN APPLICATION
addappid(1364960)
-- Game: addappid(1364960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364961, 1, "07285105a28500c21344d6488cd02aa8559e117d75a851119b4c22b613802d7b")
