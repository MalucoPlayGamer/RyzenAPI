-- Lua provided by RyzenAPI
-- Game: addappid(1555140)

-- MAIN APPLICATION
addappid(1555140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555141, 1, "9abf22f726e98978021165c2959ac6b843b6662095e2a9bc8ac390d8717dc4de")
