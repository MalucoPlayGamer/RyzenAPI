-- Lua provided by RyzenAPI
-- Game: Born of Bread

-- MAIN APPLICATION
addappid(1555140)
addappid(2585370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1555141, 1, "9abf22f726e98978021165c2959ac6b843b6662095e2a9bc8ac390d8717dc4de")

