-- Lua provided by RyzenAPI
-- Game: 1571070

-- MAIN APPLICATION
addappid(1571070)
-- Game: addappid(1571070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571071, 1, "9d546bb120702acf6a63fad109babe454cad83390f7fde4f6d547f6b567aabae")
