-- Lua provided by SkyAPI 
-- Game: Final Boss
addappid(2178620)
addappid(2178621, 1, "84e74ec3074547d39a845f40084134b9c9c87b07953f19f4182b87d41965cc54")
