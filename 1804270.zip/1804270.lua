-- Lua provided by RyzenAPI
-- Game: addappid(1804270)

-- MAIN APPLICATION
addappid(1804270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804271, 1, "4c6f284a77b97d0f0dedeca23d709fe435215974bb5d28f653869a92fff0a991")
