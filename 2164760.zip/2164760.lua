-- Lua provided by RyzenAPI
-- Game: Game: Touchdown Girls

-- MAIN APPLICATION
addappid(2164760)
-- Game: addappid(2164760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164761, 1, "52acd7b77ef1975c7bebdcb98dee9ad9ef2c107923b1e03ad4b0827c43dcccb4")
