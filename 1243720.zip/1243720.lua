-- Lua provided by RyzenAPI
-- Game: 长安夜明 试玩版

-- MAIN APPLICATION
addappid(1243720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243729,0,"2aa9e5bf30ec276b8636c58876fc23e299049a36e5a265507184cf026c6eb212")
