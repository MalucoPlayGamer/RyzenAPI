-- Lua provided by RyzenAPI
-- Game: VR Dinosaur Gladiators

-- MAIN APPLICATION
addappid(2250830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250831, 1, "8e069ce9349390379001f7532244996c4a30dedb41db234f8da68e667b6e49e1")
