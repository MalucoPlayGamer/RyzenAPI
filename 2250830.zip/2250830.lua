-- Lua provided by RyzenAPI
-- Game: VR Dinosaur Gladiators

-- MAIN APPLICATION
addappid(2250830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2250831, 1, "8e069ce9349390379001f7532244996c4a30dedb41db234f8da68e667b6e49e1")

