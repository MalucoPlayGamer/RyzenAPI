-- Lua provided by RyzenAPI
-- Game: Nazi Furry

-- MAIN APPLICATION
addappid(1985770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985771, 1, "d75efc47cf80299e1e6ac1777324b98b7e18058e6d49e619f3b8e9e2f2294214")
