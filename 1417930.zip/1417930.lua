-- Lua provided by RyzenAPI
-- Game: Lorn's Lure

-- MAIN APPLICATION
addappid(1417930)
addappid(4166680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417931, 1, "5b76612a1259cbc965a2eceef7a1d4d160d6b2e65c2b4fc5681e750fbb003bfe")
