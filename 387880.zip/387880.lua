-- Lua provided by RyzenAPI
-- Game: addappid(387880)

-- MAIN APPLICATION
addappid(387880)

-- MAIN APP DEPOTS / PACKAGES
addappid(387881, 1, "e411da65cb9ce3a750d367bf5030c8a0addad75c0b2341cd838a88f7e1b758b1")
