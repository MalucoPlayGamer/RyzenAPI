-- Lua provided by RyzenAPI 
-- Game: AppID 2990290
addappid(2990290)
addappid(2990291, 1, "6a032eeddf7c3e12c0eb3fa7b329b065645773ca1f6d45c7dc2dab34a762f631")
