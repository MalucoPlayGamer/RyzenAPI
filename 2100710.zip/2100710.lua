-- Lua provided by SkyAPI 
-- Game: Ambulance Chauffeur Simulator
addappid(2100710)
addappid(2100711, 1, "8018ce0f2881fa433112b3f0ec6080cfd0baa8273d04ec50a332690d244d7642")
