-- Lua provided by RyzenAPI
-- Game: addappid(2100710)

-- MAIN APPLICATION
addappid(2100710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100711, 1, "8018ce0f2881fa433112b3f0ec6080cfd0baa8273d04ec50a332690d244d7642")
