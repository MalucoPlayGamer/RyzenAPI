-- Lua provided by RyzenAPI
-- Game: AppID 755500

-- MAIN APPLICATION
addappid(755500)
-- Game: addappid(755500)

-- MAIN APP DEPOTS / PACKAGES
addappid(755501, 1, "4b063e3c50865bfdf39953721eaff46fcd7123ecb3e295d57d306c9b8036a6c0")
