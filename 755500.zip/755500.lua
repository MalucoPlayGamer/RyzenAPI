-- Lua provided by RyzenAPI
-- Game: AppID 755500

-- MAIN APPLICATION
addappid(755500)

-- MAIN APP DEPOTS / PACKAGES
addappid(755501, 1, "4b063e3c50865bfdf39953721eaff46fcd7123ecb3e295d57d306c9b8036a6c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(861090)
addappid(861100)
addappid(861110)
addappid(1024910)
addappid(1024912)
addappid(1024913)
addappid(1024914)
addappid(1024915)
addappid(1024920)
addappid(1028790)
addappid(1028791)
addappid(1028792)
addappid(1028793)
addappid(1028794)
addappid(1028795)
addappid(1071560)
