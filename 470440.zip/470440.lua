-- Lua provided by RyzenAPI
-- Game: addappid(470440)

-- MAIN APPLICATION
addappid(470440)

-- MAIN APP DEPOTS / PACKAGES
addappid(470441, 1, "1bd95eeac1287a7af121597c1257a66eb0b8d7a4d0928fae7fab08a6ceb5eddf")
