-- Lua provided by RyzenAPI
-- Game: Catch it

-- MAIN APPLICATION
addappid(3277250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277251, 1, "f5b06db8d78b96d4356a338fb3237b646a458577d3cd2c9c32afebe8fde402bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
