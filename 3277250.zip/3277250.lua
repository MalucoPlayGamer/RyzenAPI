-- Lua provided by RyzenAPI
-- Game: Catch it

-- MAIN APPLICATION
addappid(3277250)
-- Game: addappid(3277250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277251, 1, "f5b06db8d78b96d4356a338fb3237b646a458577d3cd2c9c32afebe8fde402bf")
