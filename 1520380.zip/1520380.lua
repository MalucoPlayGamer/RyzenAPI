-- Lua provided by RyzenAPI
-- Game: addappid(1520380)

-- MAIN APPLICATION
addappid(1520380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520381, 1, "d9ee02250cf9e8c0beb69d7c8324c0fc8e635a4f318d3e67f340583cdd1b4205")
