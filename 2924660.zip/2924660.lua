-- Lua provided by RyzenAPI
-- Game: 2924660

-- MAIN APPLICATION
addappid(2924660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924663,0,"ecd9ed7243a81ed8173bd37fc849bc60a4f0e831c696a43d50ec7dc43b0cc941")

