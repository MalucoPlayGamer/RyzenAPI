-- Lua provided by RyzenAPI
-- Game: addappid(1725501)

-- MAIN APPLICATION
addappid(1725501)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725501,0,"c85c065b26bcaa31f26ad68f4c4976251b4a17092116434f1b89ffc41ecd87c8")
