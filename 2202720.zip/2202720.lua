-- Lua provided by RyzenAPI 
-- Game: AppID 2202720
addappid(2202720)
addappid(2202721, 1, "539f9f1cc04188c27b8ea9253d0a491b1655d628c88d0aee96576f384ed15380")
