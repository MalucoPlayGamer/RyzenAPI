-- Lua provided by RyzenAPI
-- Game: Enemy at the Gates:The Invincible Sword

-- MAIN APPLICATION
addappid(2202720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2202721, 1, "539f9f1cc04188c27b8ea9253d0a491b1655d628c88d0aee96576f384ed15380")
