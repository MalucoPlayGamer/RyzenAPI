-- Lua provided by RyzenAPI
-- Game: Game: AppID 2202720

-- MAIN APPLICATION
addappid(2202720)
-- Game: addappid(2202720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202721, 1, "539f9f1cc04188c27b8ea9253d0a491b1655d628c88d0aee96576f384ed15380")
