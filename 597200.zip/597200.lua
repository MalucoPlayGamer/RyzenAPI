-- Lua provided by RyzenAPI
-- Game: Epic Little War Game

-- MAIN APPLICATION
addappid(597200)
-- Game: addappid(597200)

-- MAIN APP DEPOTS / PACKAGES
addappid(597201, 1, "6ab250243ceb15719a5b5f1d365decf499615e6e6accfe24f3af061b93d5508d")
