-- Lua provided by RyzenAPI
-- Game: Epic Little War Game

-- MAIN APPLICATION
addappid(597200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(597201, 1, "6ab250243ceb15719a5b5f1d365decf499615e6e6accfe24f3af061b93d5508d")

