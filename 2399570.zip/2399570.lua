-- Lua provided by RyzenAPI
-- Game: Skystead Ranch

-- MAIN APPLICATION
addappid(2399570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399572,0,"2bd06b5169fd8444f2acd8bd01a08fb49a835b96af69125ce66785d9ebb4fcc3")
