-- Lua provided by SkyAPI 
-- Game: Track and Burn
addappid(1668170)
addappid(1668171, 1, "1c07a3223a22079ed9fcab18c1b86477b8eecde86d0f676f5347d6e62429e280")
addappid(1668172, 1, "e8fccd0b6e28ef540ff5134120611db339e8259e259169d01e8c666a023d91e2")
addappid(1668173, 1, "7ddaa55e4dc6c58e2c33ad3ea7f7013582d348dea2efe7a0b0739b4ae0d2a4ea")
