-- Lua provided by SkyAPI 
-- Game: Afternoon empire
addappid(786940)
addappid(786941, 1, "b8254bc810b1ec1020615bd61af8c95d1a3a67f2efa81d0c1936b47be36b1b94")
