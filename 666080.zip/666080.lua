-- Lua provided by RyzenAPI
-- Game: 伝創記IV ~if~

-- MAIN APPLICATION
addappid(666080)

-- MAIN APP DEPOTS / PACKAGES
addappid(666082,0,"3e5475fac826acb2c3971ffe54d995aaf7c6313c34c97bf6d43e5a83e358385a")

