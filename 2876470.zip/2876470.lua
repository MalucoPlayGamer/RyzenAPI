-- Lua provided by RyzenAPI 
-- Game: Teachers Secrets
addappid(2876470)
addappid(2876471, 1, "cee7800540bdb724ec8797194eda7da6678395c3af2767593574b27468b1709f")
