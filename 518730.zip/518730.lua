-- Lua provided by SkyAPI 
-- Game: Zombo Buster Rising
addappid(518730)
addappid(518731, 1, "ff376d0a1e146223fe5ddfccee17468a7e0c155a154147b3f1f2df7963aa8f64")
addappid(518732, 1, "ce487f4f1d1577e94b030001d45003283f561c54ad8f42e59abcba9e92ded400")
addappid(518733, 1, "d73628baec78cef5cb325efccd94ec8eeed6bedbef45348de4f5b34ac479fa4b")
