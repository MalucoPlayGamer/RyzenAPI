-- Lua provided by RyzenAPI
-- Game: 46320

-- MAIN APPLICATION
addappid(46320)
-- Game: addappid(46320)

-- MAIN APP DEPOTS / PACKAGES
addappid(46322,0,"c7d3042e7353b28c0a42c93d63cac92ffb31f6a58014486d212a5d97e6c46914")
addappid(46323,0,"8ee52b7d695ee74ff23dbda1a0a30344143f46893660e4e2c31df6565d92f5aa")
