-- Lua provided by RyzenAPI
-- Game: Stranger Things 3: The Game

-- MAIN APPLICATION
addappid(1097800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1097801, 1, "599b50f95238ed47338149f3959d93a34f909a98266cb42d74c9e79d3eb2168e")

