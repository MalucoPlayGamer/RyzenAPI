-- Lua provided by RyzenAPI
-- Game: Stranger Things 3: The Game

-- MAIN APPLICATION
addappid(1097800)
-- Game: addappid(1097800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097801, 1, "599b50f95238ed47338149f3959d93a34f909a98266cb42d74c9e79d3eb2168e")
