-- Lua provided by RyzenAPI
-- Game: 蔚蓝月下 Sapphire Moon

-- MAIN APPLICATION
addappid(964970)
addappid(991830)
addappid(992570)

-- MAIN APP DEPOTS / PACKAGES
addappid(964971, 1, "ffef11b3cb0c31eda7e38299437131f1ae64916e3e4c68773ebe5cd9b65cd64b")
