-- Lua provided by RyzenAPI 
-- Game: Second Sun Demo
addappid(3260480)
addappid(3260481, 1, "18732924784427151371e1a43839493b751f57603b0c9ac9adf2d1024c51d38b")
