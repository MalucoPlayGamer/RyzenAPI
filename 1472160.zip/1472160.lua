-- Lua provided by RyzenAPI
-- Game: NEKO PAPALA

-- MAIN APPLICATION
addappid(1472160)
-- Game: addappid(1472160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472161, 1, "97a47c991916a8f6f8e2507aa00c8d5e1da1158d434084cc46f80103b40adf42")
addappid(1472162, 1, "37f38ad2cdfe6b0da2468702c8e79bb038e77dde4f17fcd4faaa6c7c03074cb9")
addappid(1472163, 1, "3fe62c0c2e9d943c026cfc128b7ebb3834ca3aa7bb524b9ac49cba9f537b7d51")
addappid(1472164, 1, "5ff5eb913d852e076bc0d27d2c287cbddd65917f0dd6f3d80cbf10b59ec3141e")
