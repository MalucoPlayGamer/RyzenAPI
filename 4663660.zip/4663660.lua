-- Lua provided by RyzenAPI
-- Game: Hidden Objects - Items Find

-- MAIN APPLICATION
addappid(4663660)
