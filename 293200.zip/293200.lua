-- Lua provided by RyzenAPI
-- Game: AppID 293200

-- MAIN APPLICATION
addappid(293200)

-- MAIN APP DEPOTS / PACKAGES
addappid(293201, 1, "4e4c68b5afbf85345f35dd03293a44d90d59dc84d9b3b8b2a846d049e88c4410")
addappid(293202, 1, "535c4064c4230fee53b06e31110b0473625d0f9b2a8afde01c766241b6a54e8f")
addappid(293203, 1, "93523231e742d58779e4aa42fa22c134976a798b6b7c28ca4cfab1e4c9fab19c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
