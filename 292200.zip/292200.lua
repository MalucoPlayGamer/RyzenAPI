-- Lua provided by RyzenAPI 
-- Game: Crazy Plant Shop
addappid(292200)
addappid(292201, 1, "dbd79a1bd43e07e1431b3cf45f4b31c695d08bbbf40818cc6a6ef3fde95d7d35")
