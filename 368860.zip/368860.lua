-- Lua provided by RyzenAPI
-- Game: 368860

-- MAIN APPLICATION
addappid(368860)
-- Game: addappid(368860)

-- MAIN APP DEPOTS / PACKAGES
addappid(368861, 1, "79d20c777ecc3e54a7264445f5b2fb778e56e670790d5e04a27574aefd717c69")
