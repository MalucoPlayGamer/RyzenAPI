-- Lua provided by RyzenAPI
-- Game: PUMP IT UP RISE

-- MAIN APPLICATION
addappid(2756930)
addappid(3932570)
addappid(4445930)
addappid(4446060)
addappid(4528900)
addappid(4744660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756931,0,"654cfb2a808481d61a5d839c4f41eac8c63cb1ecce79750ef671f3f107f4b32b")
addappid(3932571,0,"389018bc4d531a390c6d2ebd9bdba8d84cdf5bb52d5aa6670c43ce6e63d44f0c")

