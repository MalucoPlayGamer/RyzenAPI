-- Lua provided by RyzenAPI
-- Game: 2756930

-- MAIN APPLICATION
addappid(2756930)
-- Game: addappid(2756930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756931, 1, "654cfb2a808481d61a5d839c4f41eac8c63cb1ecce79750ef671f3f107f4b32b")
