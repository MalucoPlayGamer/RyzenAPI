-- Lua provided by RyzenAPI
-- Game: Pathfinder: Wrath of the Righteous - The Lord of Nothing

-- MAIN APPLICATION
addappid(2564570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564571, 1, "febd7c95d401830b10297655b4bdb21aca73020d4608259d893ebdff8bbe05ec")
addappid(2564572, 1, "57bf39c5e5673551129bfddebf1efc8e8369a494b32464fd1417ad3b89d11c26")
