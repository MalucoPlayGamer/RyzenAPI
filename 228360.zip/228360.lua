-- Lua provided by RyzenAPI
-- Game: Full Throttle Remastered

-- MAIN APPLICATION
addappid(228360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228361, 1, "c291c092d3c31ecf5a8a79207b1c287cba54eb31fbab3d29e7d29293d3725e78")
addappid(228362, 1, "ec22c0713321b8a3b14a3f5b5502adb3b42f1825c3d5c3d83ad99c7b77430f69")
addappid(228363, 1, "e8f8d2fbfc136477fcd7d616edd46a4bf90b724275954c3b5b28af3ccb0bb4bc")
addappid(228364, 1, "3c7ed0ff2427df956e044481962391e8738a07e7f6c2e5782dc047b008813003")
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

