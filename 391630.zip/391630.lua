-- Lua provided by RyzenAPI
-- Game: 391630

-- MAIN APPLICATION
addappid(391630)
-- Game: addappid(391630)

-- MAIN APP DEPOTS / PACKAGES
addappid(391631, 1, "c6b28176bea2f417b7cc103dfe02da9b583819e772618f85bbbe650aed0d64c4")
