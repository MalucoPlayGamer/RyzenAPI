-- Lua provided by RyzenAPI
-- Game: Cat Jigsaw Puzzle Games

-- MAIN APPLICATION
addappid(2325190)
addappid(2326900)
addappid(2328050)
addappid(2333690)
addappid(2335660)
addappid(2337980)
addappid(2341120)
addappid(2343020)
addappid(2344220)
addappid(2345310)
addappid(2346050)
addappid(2347330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325191, 1, "38c5ba83a461ceabfa7374ec6929aafe988aea84c6bd0fca89f912f4e70612bf")

