-- Lua provided by RyzenAPI
-- Game: 2325190

-- MAIN APPLICATION
addappid(2325190)
-- Game: addappid(2325190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325191, 1, "38c5ba83a461ceabfa7374ec6929aafe988aea84c6bd0fca89f912f4e70612bf")
