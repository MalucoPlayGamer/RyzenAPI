-- Lua provided by RyzenAPI
-- Game: Checkmate Showdown

-- MAIN APPLICATION
addappid(1803410)
-- Game: addappid(1803410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803411, 1, "6877e49faadc4bd6b1335877667a782cd45a4653f656904f529d723705a7c27c")
