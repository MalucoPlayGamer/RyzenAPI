-- Lua provided by RyzenAPI
-- Game: Checkmate Showdown

-- MAIN APPLICATION
addappid(1803410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803411, 1, "6877e49faadc4bd6b1335877667a782cd45a4653f656904f529d723705a7c27c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
