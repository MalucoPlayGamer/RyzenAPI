-- Lua provided by RyzenAPI
-- Game: addappid(1684161)

-- MAIN APPLICATION
addappid(1684161)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684161,0,"536477a24ea6eddceef359481f1a940d439ad58d3662fff6a0d410d7a592b020")
