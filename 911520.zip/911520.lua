-- Lua provided by RyzenAPI
-- Game: 911520

-- MAIN APPLICATION
addappid(911520)
-- Game: addappid(911520)

-- MAIN APP DEPOTS / PACKAGES
addappid(911521, 1, "00b8798430c740fe5f9056422792dd8a13f32c3c7ecfc7421c19209d9c2a433a")
