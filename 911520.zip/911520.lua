-- Lua provided by RyzenAPI
-- Game: One More Roll

-- MAIN APPLICATION
addappid(911520)

-- MAIN APP DEPOTS / PACKAGES
addappid(911521, 1, "00b8798430c740fe5f9056422792dd8a13f32c3c7ecfc7421c19209d9c2a433a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
