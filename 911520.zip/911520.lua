-- Lua provided by SkyAPI 
-- Game: One More Roll
addappid(911520)
addappid(911521, 1, "00b8798430c740fe5f9056422792dd8a13f32c3c7ecfc7421c19209d9c2a433a")
