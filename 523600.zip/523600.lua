-- Lua provided by RyzenAPI
-- Game: Card Creator

-- MAIN APPLICATION
addappid(523600)

-- MAIN APP DEPOTS / PACKAGES
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(523601, 1, "193d75e273ac8c9685e770804b675392bbf7ff8049489d01ca4b30518e8339d7")
