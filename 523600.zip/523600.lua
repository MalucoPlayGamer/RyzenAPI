-- Lua provided by RyzenAPI
-- Game: Game: AppID 523600

-- MAIN APPLICATION
addappid(523600)
-- Game: addappid(523600)

-- MAIN APP DEPOTS / PACKAGES
addappid(523601, 1, "193d75e273ac8c9685e770804b675392bbf7ff8049489d01ca4b30518e8339d7")
