-- Lua provided by RyzenAPI
-- Game: Game: AppID 1523600

-- MAIN APPLICATION
addappid(1523600)
-- Game: addappid(1523600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523601, 1, "cbda2fc7654b9cf0038d8d437eebdb66856fb93c4f9c7f6716fd20c71c398d76")
