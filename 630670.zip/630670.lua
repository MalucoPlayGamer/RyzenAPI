-- Lua provided by RyzenAPI
-- Game: Call of the Ocean

-- MAIN APPLICATION
addappid(630670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(630671, 1, "359ab742d170abf220ab481b50dceb68def4bffe26dbdc524e04a60490de7149")

