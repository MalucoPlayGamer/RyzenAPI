-- Lua provided by RyzenAPI
-- Game: Call of the Ocean

-- MAIN APPLICATION
addappid(630670)

-- MAIN APP DEPOTS / PACKAGES
addappid(630671, 1, "359ab742d170abf220ab481b50dceb68def4bffe26dbdc524e04a60490de7149")
