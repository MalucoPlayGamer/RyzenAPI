-- Lua provided by RyzenAPI 
-- Game: AppID 1201070
addappid(1201070)
addappid(1201071, 1, "48644d411567c2c4c77e986988d750a640527dc849fada40b1962c91d496cb19")
