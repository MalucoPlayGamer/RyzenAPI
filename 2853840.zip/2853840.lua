-- Lua provided by RyzenAPI
-- Game: Family Breeding

-- MAIN APPLICATION
addappid(2853840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853841, 1, "f690d3dbff4fad9e1a8cd43a7b316abbb670be06a24f218209ca395b034bdc6f")

