-- Lua provided by RyzenAPI
-- Game: 999860

-- MAIN APPLICATION
addappid(999860)
addappid(1287770)
-- Game: addappid(999860)

-- MAIN APP DEPOTS / PACKAGES
addappid(999861, 1, "6ba5307cb5ff2a6617c66d6bfa84295a1a6aa82500b96bf6277bdc5a0613c6eb")
addappid(999862, 1, "90b33ac46bd5f3ba700e61ee1e98a0257066708cf0c3d4ad49d6633d10167391")
