-- Lua provided by RyzenAPI
-- Game: Enemy On Board

-- MAIN APPLICATION
addappid(999860)
addappid(1287770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(999861, 1, "6ba5307cb5ff2a6617c66d6bfa84295a1a6aa82500b96bf6277bdc5a0613c6eb")
addappid(999862, 1, "90b33ac46bd5f3ba700e61ee1e98a0257066708cf0c3d4ad49d6633d10167391")

