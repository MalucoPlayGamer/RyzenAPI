-- Lua provided by RyzenAPI
-- Game: 236470

-- MAIN APPLICATION
addappid(236470)
-- Game: addappid(236470)

-- MAIN APP DEPOTS / PACKAGES
addappid(236471, 1, "c718e845a54d4b808ebf687f05009ffc74970f708bc597a9b5279bafe16115ad")
