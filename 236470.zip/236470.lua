-- Lua provided by RyzenAPI
-- Game: PAC-MAN MUSEUM™

-- MAIN APPLICATION
addappid(236470)

-- MAIN APP DEPOTS / PACKAGES
addappid(236471, 1, "c718e845a54d4b808ebf687f05009ffc74970f708bc597a9b5279bafe16115ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
