-- Lua provided by SkyAPI 
-- Game: Hero's everyday life
addappid(1559460)
addappid(1559461, 1, "0f84cb5ed985e88ad4b4dbed06534ea086bda7c33eb3a628480461244e1d1c51")
