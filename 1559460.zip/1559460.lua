-- Lua provided by RyzenAPI
-- Game: Game: Hero's everyday life

-- MAIN APPLICATION
addappid(1559460)
-- Game: addappid(1559460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559461, 1, "0f84cb5ed985e88ad4b4dbed06534ea086bda7c33eb3a628480461244e1d1c51")
