-- Lua provided by RyzenAPI
-- Game: Hero's everyday life

-- MAIN APPLICATION
addappid(1559460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559461, 1, "0f84cb5ed985e88ad4b4dbed06534ea086bda7c33eb3a628480461244e1d1c51")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1783570)
addappid(1783571)
addappid(1783572)
addappid(1783573)
addappid(1783574)
addappid(1783575)
addappid(1783576)
addappid(1796760)
addappid(1796770)
