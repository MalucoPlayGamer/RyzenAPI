-- Lua provided by RyzenAPI
-- Game: Savara - Webtoon

-- MAIN APPLICATION
addappid(3711830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3711831, 1, "ad709f218d5bc8b43a7c6d563ff2de77ec84efa2f7df61eb25ffdcb6d976a4ba")
