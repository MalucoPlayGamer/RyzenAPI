-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Italy

-- MAIN APPLICATION
addappid(2313240)
addappid(2802100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313241, 1, "53771a49704085d26dab12ef308732dc92a47a2a66c7e4bd4a7a83ab6f641995")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
