-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Italy

-- MAIN APPLICATION
addappid(2313240)
addappid(2802100)
-- Game: addappid(2313240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313241, 1, "53771a49704085d26dab12ef308732dc92a47a2a66c7e4bd4a7a83ab6f641995")
