-- Lua provided by RyzenAPI
-- Game: You, me & Other Animals: The music of Planet Zoo

-- MAIN APPLICATION
addappid(1383610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383611, 1, "7f6c35897448b21336cece1d72e8d98086e52e1f3321e7f21a0fdcf754b205e5")
addappid(1383612, 1, "60e9cb821b764d13f54d002f93c9bac4eda0da0afee5cd41ebe6f4d0304f7e9e")
