-- Lua provided by RyzenAPI
-- Game: addappid(656100)

-- MAIN APPLICATION
addappid(656100)

-- MAIN APP DEPOTS / PACKAGES
addappid(656101, 1, "73fe2cf205a03e3925b25aa5fed92dfae50ca667a3c7afcaa1ee4fe76dcc9c55")
