-- Lua provided by RyzenAPI
-- Game: Mr. Triangle's Maze

-- MAIN APPLICATION
addappid(656100)
-- Game: addappid(656100)

-- MAIN APP DEPOTS / PACKAGES
addappid(656101, 1, "73fe2cf205a03e3925b25aa5fed92dfae50ca667a3c7afcaa1ee4fe76dcc9c55")
