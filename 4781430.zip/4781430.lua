-- Lua provided by RyzenAPI
-- Game: Pocket Squire: Arena

-- MAIN APPLICATION
addappid(4781430) -- Pocket Squire: Arena

-- MAIN APP DEPOTS / PACKAGES
addappid(4781431, 1, "97cd0ee3294462ff07f980e410c71cc186601ea060e344a7395b7c1d395b6841") -- Depot 4781431

