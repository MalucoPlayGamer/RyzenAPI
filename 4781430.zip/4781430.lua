-- 4781430's Lua and Manifest Created by Hubcap Manifest
-- Pocket Squire: Arena
-- Created: August 05, 2026 at 13:24:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4781430) -- Pocket Squire: Arena
-- MAIN APP DEPOTS
addappid(4781431, 1, "97cd0ee3294462ff07f980e410c71cc186601ea060e344a7395b7c1d395b6841") -- Depot 4781431
setManifestid(4781431, "3653685269401536239", 510545921)