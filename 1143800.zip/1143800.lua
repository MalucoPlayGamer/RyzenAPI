-- Lua provided by RyzenAPI
-- Game: AppID 1143800

-- MAIN APPLICATION
addappid(1143800)
addappid(1145170)
addappid(1158930)
addappid(1160170)
addappid(1160960)
addappid(1162260)
addappid(1184920)
addappid(1185210)
addappid(1185650)
addappid(1186420)
addappid(1187160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1143801, 1, "423c1eb897d417cfc2a3db519aa17d4fc0aeacbbaa12dbe79d75f2b4d55f5254")

