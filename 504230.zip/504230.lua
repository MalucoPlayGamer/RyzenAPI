-- Lua provided by RyzenAPI 
-- Game: Celeste
addappid(504230)
addappid(504231, 1, "54f178dcac153879e50ce091af232f1451898adf19d5613d4baa7d67ff7ed15e")
addappid(504232, 1, "6ce8825ef852b78bd99df402294a5fab18cebe0d0e25eff0a1331a5e92ab8f0f")
addappid(504233, 1, "796b0998d2a23eb42b790804bdeaf4be91bcac473dc16634748f1cf88db8fcac")
