-- Lua provided by RyzenAPI
-- Game: Game: Bikini Tits

-- MAIN APPLICATION
addappid(1805250)
-- Game: addappid(1805250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805251, 1, "b7751c50cbc5574f6fd0035754152895356d04723d162db7ac185b6abf80f3d8")
