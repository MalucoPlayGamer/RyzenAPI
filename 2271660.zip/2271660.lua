-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Winlu Fantasy Tileset -  Interior

-- MAIN APPLICATION
addappid(2271660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271660,0,"19ecb3723da78f971f50310760958537c2778edb3b792fbb587c1a412d6359fd")

