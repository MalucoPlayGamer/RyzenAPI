-- Lua provided by RyzenAPI
-- Game: Live2D VR Girls

-- MAIN APPLICATION
addappid(714100)

-- MAIN APP DEPOTS / PACKAGES
addappid(714101, 1, "cf30bf8dd436d29f1d226602a92a6ec85652630c2eb01c642b1e76e33b1b857a")

