-- Lua provided by RyzenAPI
-- Game: Minor Scale

-- MAIN APPLICATION
addappid(2376030)
-- Game: addappid(2376030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376031, 1, "0875b42b58a76bbe08d70d7d21c0dee49240823726ba0607656678530d366c5c")
