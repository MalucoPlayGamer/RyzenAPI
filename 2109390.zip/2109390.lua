-- Lua provided by RyzenAPI
-- Game: Overboss

-- MAIN APPLICATION
addappid(2109390)
addappid(2532960)
-- Game: addappid(2109390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109391, 1, "150e24860309c83b885663f604663fc03b57a3543e4f539892cdefce354f3386")
