-- Lua provided by RyzenAPI
-- Game: LEGO® Batman™: Legacy of the Dark Knight

-- MAIN APPLICATION
addappid(2215200)
addappid(4168610)
addappid(4168620)
addappid(4168630)
addappid(4168640)
addappid(4468750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2215201, 1, "5d2bafc1381c29ebabb37bbab50e496548be24f6bf5d511e8d471b99d60cfbf3") -- LEGO® Batman™: Legacy of the Dark Knight (base)

-- correcao manifest/updates
setManifestid(2215201, "8744395932724193069")

