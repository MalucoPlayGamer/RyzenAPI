-- Lua provided by RyzenAPI
-- Game: LEGO® Batman™: Legacy of the Dark Knight

-- MAIN APPLICATION
addappid(2215200)
addappid(4168610)
addappid(4168620)
addappid(4168630)
addappid(4168640)
addappid(4468750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215201, 1, "5d2bafc1381c29ebabb37bbab50e496548be24f6bf5d511e8d471b99d60cfbf3") -- LEGO® Batman™: Legacy of the Dark Knight (base)

-- correcao manifest/updates
setManifestid(2215201, "8744395932724193069")

