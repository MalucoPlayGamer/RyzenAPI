-- Lua provided by RyzenAPI
-- Game: Batman Beyond Pack

-- MAIN APP DEPOTS / PACKAGES
-- batman lego batman lançamento 2026addappid(2215200)addappid(2215201, 1, "5d2bafc1381c29ebabb37bbab50e496548be24f6bf5d511e8d471b99d60cfbf3")addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")-- DLCSaddappid(4168610) -- Arkham Trilogy Packaddappid(4468750) -- The Dark Knight Returns Suitaddappid(4168640) -- Deluxe Edition Upgradeaddappid(4168630) -- Party Music Packaddappid(4168620) -- Batman Beyond Pack
