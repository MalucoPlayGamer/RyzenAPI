-- Lua provided by RyzenAPI
-- Game: Game: The Tribe Must Survive - Artwork

-- MAIN APPLICATION
addappid(2844790)
-- Game: addappid(2844790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844791, 1, "70012438d483b75f8a15e3a4c940f1f22ec87c06e7d53d2f1f0610cfda5b3608")
