-- Lua provided by RyzenAPI
-- Game: Ground Control II: Operation Exodus

-- MAIN APPLICATION
addappid(254840)

-- MAIN APP DEPOTS / PACKAGES
addappid(254841, 1, "bc0cbf21f07bf6e414e7be5da3ab13c8b60e925a76d290cb7844f18689389c98")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
