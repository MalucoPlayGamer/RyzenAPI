-- Lua provided by RyzenAPI
-- Game: 254840

-- MAIN APPLICATION
addappid(254840)
-- Game: addappid(254840)

-- MAIN APP DEPOTS / PACKAGES
addappid(254841, 1, "bc0cbf21f07bf6e414e7be5da3ab13c8b60e925a76d290cb7844f18689389c98")
