-- Lua provided by RyzenAPI
-- Game: The Coma 2B: Catacomb

-- MAIN APPLICATION
addappid(1781890)
-- Game: addappid(1781890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781891, 1, "7695a89bfd4e0d3f27fb4028c30100e4cfda9fdd21241199a99b368961309df1")
