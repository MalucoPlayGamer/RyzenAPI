-- Lua provided by RyzenAPI
-- Game: The Coma 2B: Catacomb

-- MAIN APPLICATION
addappid(1781890)
addappid(3267780)
addappid(3267790)
addappid(3267800)
addappid(3267810)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1781891, 1, "7695a89bfd4e0d3f27fb4028c30100e4cfda9fdd21241199a99b368961309df1")

