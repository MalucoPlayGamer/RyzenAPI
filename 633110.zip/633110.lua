-- Lua provided by RyzenAPI
-- Game: Game: AppID 633110

-- MAIN APPLICATION
addappid(633110)
-- Game: addappid(633110)

-- MAIN APP DEPOTS / PACKAGES
addappid(633111, 1, "aa8ae31605847cec7e0b74d18723299eea5bf5f90e2222bfe9e74e28457f07ba")
addappid(633112, 1, "b1ce2d7f0dc1a7a7f8c535b828582e38e91008915ed40e9c71a8aeee20e17e4d")
