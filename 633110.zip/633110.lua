-- Lua provided by RyzenAPI
-- Game: Fast Beat Loop Racer GT

-- MAIN APPLICATION
addappid(633110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(633111, 1, "aa8ae31605847cec7e0b74d18723299eea5bf5f90e2222bfe9e74e28457f07ba")
addappid(633112, 1, "b1ce2d7f0dc1a7a7f8c535b828582e38e91008915ed40e9c71a8aeee20e17e4d")
