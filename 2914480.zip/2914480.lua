-- Lua provided by RyzenAPI
-- Game: Game: Welcome to Maison Chichigami

-- MAIN APPLICATION
addappid(2914480)
-- Game: addappid(2914480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914481, 1, "eca0eff88afd8f6e515d9920357fff55523649d76ad1863733cfe67e04cb1f00")
addappid(2914482, 1, "08f99968935826174ca020381073584ca21361918a296388920cfd8cd6f51fb5")
addappid(2914483, 1, "ba286684c739d1139975320aea06d98978c42dfda40f3d31ff8f4fa2c6bc484e")
