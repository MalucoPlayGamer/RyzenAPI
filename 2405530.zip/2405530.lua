-- Lua provided by RyzenAPI
-- Game: 2405530

-- MAIN APPLICATION
addappid(2405530)
-- Game: addappid(2405530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405531, 1, "990833f3fa4b5081928ec82d18cc1ddcb83d313b23872b7d8c07904acdfd1b35")
