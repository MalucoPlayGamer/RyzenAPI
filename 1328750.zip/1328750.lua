-- Lua provided by RyzenAPI
-- Game: BRDG

-- MAIN APPLICATION
addappid(1328750)
-- Game: addappid(1328750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328751, 1, "bc437030f858fa53a80a8d6ba9f3f020e26c5e6e549a05f5337b15240764125b")
