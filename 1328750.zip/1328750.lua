-- Lua provided by RyzenAPI 
-- Game: BRDG
addappid(1328750)
addappid(1328751, 1, "bc437030f858fa53a80a8d6ba9f3f020e26c5e6e549a05f5337b15240764125b")
