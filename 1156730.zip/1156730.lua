-- Lua provided by RyzenAPI
-- Game: 1156730

-- MAIN APPLICATION
addappid(1156730)
-- Game: addappid(1156730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156731, 1, "ffd959c997a072b8a30548cfafca6e64e0b65af794be3560ce9de4a05a0a1cc3")
addappid(1156732, 1, "0a573d599d9ece563bddf9f289679e56fa7aece3d7134be91789d6842b81b70e")
