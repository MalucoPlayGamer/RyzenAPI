-- Lua provided by RyzenAPI 
-- Game: AppID 1272580
addappid(1272580)
addappid(1272581, 1, "5e0d2036f987255f719b63626ab004f7e7084acf91bbc82ab1de754299bf6de3")
