-- Lua provided by RyzenAPI
-- Game: 1272580

-- MAIN APPLICATION
addappid(1272580)
-- Game: addappid(1272580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272581, 1, "5e0d2036f987255f719b63626ab004f7e7084acf91bbc82ab1de754299bf6de3")
