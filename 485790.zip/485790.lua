-- Lua provided by RyzenAPI
-- Game: addappid(485790)

-- MAIN APPLICATION
addappid(485790)

-- MAIN APP DEPOTS / PACKAGES
addappid(485791, 1, "01cfc3591527d7561bd5d4ea25cd1c1ade2c4f3572a8f580020885dfaa7ca58d")
