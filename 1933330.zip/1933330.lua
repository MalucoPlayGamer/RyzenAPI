-- Lua provided by RyzenAPI
-- Game: Tales from the Crossing: The Captain's Chair

-- MAIN APPLICATION
addappid(1933330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933331, 1, "7b0d06b8d336c80e1a2ff1f4eefc46d9197b07d15f666fec8f70dc78a8680740")

