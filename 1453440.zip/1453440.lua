-- Lua provided by RyzenAPI 
-- Game: Hentai VR 18+
addappid(1453440)
addappid(1453441, 1, "75a7d032c1216670fee79f4ebb8e82e612e203d8957d1b841d394d3afcb59087")
addappid(1460180)
