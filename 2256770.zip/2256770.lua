-- Lua provided by RyzenAPI
-- Game: addappid(2256770)

-- MAIN APPLICATION
addappid(2256770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256771, 1, "76b358b4ead12bb7b3ed52a7cdf1613ba4be26131b597edb2332174ce908a58e")
