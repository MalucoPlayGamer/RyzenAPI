-- Lua provided by RyzenAPI
-- Game: Game: Red Recon: 1944 Playtest

-- MAIN APPLICATION
addappid(3723740)
-- Game: addappid(3723740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3723741, 1, "0b41e59136235db495d0cc8cf5221869ddf9cc66d4da9893d802e4cbe71256cd")
