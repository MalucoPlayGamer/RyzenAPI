-- Lua provided by RyzenAPI
-- Game: Gunship Recon

-- MAIN APPLICATION
addappid(1065050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065051,0,"90b912051919d4ea1276a0a7a1c54ad9e711b4e09692eb482e070d316660f2cd")
addappid(1167341,0,"374311cac37bd551c9a69a3522be344fee08f1eeb27789fb213ba44c23da1e7c")
addappid(1217321,0,"f2d20126d014a44e127bd7b10d6c0b6424d5d0a1d6330fec8e270ccf44cc7fd4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1167340)
addappid(1217320)
