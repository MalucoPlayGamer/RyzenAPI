-- Lua provided by RyzenAPI
-- Game: rumii

-- MAIN APPLICATION
addappid(872440)
-- Game: addappid(872440)

-- MAIN APP DEPOTS / PACKAGES
addappid(872441, 1, "8ce11b890441eb60b579348686e6a917be0673bc864f82c01a8de628c9aa5b96")
addappid(872442, 1, "5a5b7fec752526df9e82bcb662e8dab1bbf124089572cbdd3890f1b55a275572")
