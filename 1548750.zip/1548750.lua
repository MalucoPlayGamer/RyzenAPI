-- Lua provided by RyzenAPI
-- Game: AppID 1548750

-- MAIN APPLICATION
addappid(1548750)
-- Game: addappid(1548750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548751, 1, "0dbf6465f16eafdd115570f323fcaf41265b840be2cbe3fb966c6adb21762ff2")
