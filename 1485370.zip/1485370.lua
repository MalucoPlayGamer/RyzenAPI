-- Lua provided by RyzenAPI
-- Game: Futuclass Hub

-- MAIN APPLICATION
addappid(1485370)
addappid(1485400) -- Futuclass - Reaction Balancing I
addappid(1494430) -- Futuclass - Oxygen Escape Room
addappid(1596630) -- Futuclass - Hydrogen & Oxygen
addappid(1596631) -- Futuclass - Salts
addappid(1596632) -- Futuclass - Atom
addappid(3402870) -- Futuclass - Chemical Bonds
addappid(3402890) -- Futuclass - Moles and Molarity 1
addappid(3402900) -- Futuclass - Moles and Molarity 2
addappid(3402910) -- Futuclass - Redox Reactions
addappid(3402920) -- Futuclass - Nuclear Reactions

-- MAIN APP DEPOTS / PACKAGES
addappid(1485371, 1, "6e72ec786d629d413b28996a371ccc2f8f3cc3a6798c689ca2f88744534d811e") -- (64-bit)
addappid(3402880) -- Futuclass - Acids, Bases & Salts

