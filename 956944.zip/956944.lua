-- Lua provided by RyzenAPI
-- Game: Yu Jin - Officer Ticket / 于禁使用券

-- MAIN APPLICATION
addappid(956944)

-- MAIN APP DEPOTS / PACKAGES
addappid(956944,0,"fa46250a270d45108875da2e7ba9fff6a9ae271dd59a4b8e0cd1fccf05c9cd04")

