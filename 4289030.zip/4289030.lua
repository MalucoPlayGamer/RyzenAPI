-- Lua provided by RyzenAPI
-- Game: Edgar Allan Poe's Interactive Horror: 1995 Edition

-- MAIN APPLICATION
addappid(4289030)

-- MAIN APP DEPOTS / PACKAGES
addappid(4289031,0,"31738cf840ad55ab1dd5dda0e398cfa73b5f3b5218886d61137ba14cc95cd61b")
addappid(4289032,0,"0c58f60640b8d25891ef32fc2d7b4b9cd52d0b0bf5e9d1c7b687864e8074808b")

