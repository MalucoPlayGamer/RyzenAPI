-- Lua provided by SkyAPI 
-- Game: AppID 510500
addappid(510500)
addappid(510501, 1, "3aac7a66b99817ad61bcb317cc5e6ff131c0e759194a8c1f9b44e82b303bc0c8")
addappid(510502, 1, "45790c7ee7d0ba8c4e61c2f12144739963b516b7bdb891e3a9927040c8765cfc")
