-- Lua provided by SkyAPI 
-- Game: AppID 459780
addappid(459780)
addappid(459781, 1, "1b4b5930b7b91c187cf8961d001ac7d8c221083b28e7ce4dd94ccfd9b5fb55e2")
