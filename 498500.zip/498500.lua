-- Lua provided by RyzenAPI
-- Game: I Am The Hero

-- MAIN APPLICATION
addappid(498500)
-- Game: addappid(498500)

-- MAIN APP DEPOTS / PACKAGES
addappid(498501, 1, "58c3a75a5f7d6789dfd75cd014a89cceaf022f3d1b79ed5ca6c756a84d6c699b")
