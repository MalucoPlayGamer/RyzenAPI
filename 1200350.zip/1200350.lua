-- Lua provided by RyzenAPI
-- Game: Dead Ground Arcade

-- MAIN APPLICATION
addappid(1200350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200351, 1, "3648cd02f5c9a2d1bced806cf0ef4f8780be52ffeadf1ac6d2d5619498f85d82")
