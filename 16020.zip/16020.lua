-- Lua provided by RyzenAPI 
-- Game: AppID 16020
addappid(16020)
addappid(16021, 1, "fdf7ff9e7af6eeb27af0506360755517a73007a5c558d3bfe6b1311fefe3a7e7")
