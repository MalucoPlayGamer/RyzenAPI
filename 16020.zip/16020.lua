-- Lua provided by RyzenAPI
-- Game: Samantha Swift and the Hidden Roses of Athena

-- MAIN APPLICATION
addappid(16020)
-- Game: addappid(16020)

-- MAIN APP DEPOTS / PACKAGES
addappid(16021, 1, "fdf7ff9e7af6eeb27af0506360755517a73007a5c558d3bfe6b1311fefe3a7e7")
