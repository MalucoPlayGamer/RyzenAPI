-- Lua provided by RyzenAPI
-- Game: Mini Royale

-- MAIN APPLICATION
addappid(1657090)
-- Game: addappid(1657090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657091, 1, "06e981ac0548f6832370e0000e2b143b83bff87533304d75788def7ca640a501")
addappid(1657093, 1, "410be2f9e9eac90f527f26b319eb9da378750e4128143eba950268bc9cb7afc9")
