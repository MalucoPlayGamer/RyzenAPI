-- Lua provided by RyzenAPI
-- Game: Mini Royale

-- MAIN APPLICATION
addappid(1657090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657091, 1, "06e981ac0548f6832370e0000e2b143b83bff87533304d75788def7ca640a501")
addappid(1657093, 1, "410be2f9e9eac90f527f26b319eb9da378750e4128143eba950268bc9cb7afc9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3329230)
addappid(3640690)
