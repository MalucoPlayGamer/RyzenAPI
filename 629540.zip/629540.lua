-- Lua provided by RyzenAPI
-- Game: Game: AppID 629540

-- MAIN APPLICATION
addappid(629540)
-- Game: addappid(629540)

-- MAIN APP DEPOTS / PACKAGES
addappid(629541, 1, "693bde1cd7a520b9c9c88ef0accb965c0d0c9de73624433aeca2d5832a79857e")
