-- Lua provided by RyzenAPI
-- Game: A Butterfly in the District of Dreams

-- MAIN APPLICATION
addappid(617430)

-- MAIN APP DEPOTS / PACKAGES
addappid(617431,0,"8da930c9163ec007b560b6341c447a9d2fcfc63ddb5b984338e915811c2a437d")

