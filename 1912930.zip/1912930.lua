-- Lua provided by RyzenAPI
-- Game: Cursed Blood

-- MAIN APPLICATION
addappid(1912930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912931, 1, "a92608d435e79eae673124134b3ff09096644d6c49779d55507f2d239858ebed")

