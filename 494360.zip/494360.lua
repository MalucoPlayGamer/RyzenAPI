-- Lua provided by RyzenAPI
-- Game: 494360

-- MAIN APPLICATION
addappid(494360)
-- Game: addappid(494360)

-- MAIN APP DEPOTS / PACKAGES
addappid(494361, 1, "bcad0e406e3cbf5a087d90bd192ba2c16cdebac85f91f34661d689814ff6772f")
addappid(494362, 1, "1ac622ff3d6e26cbed7c334327e5ab92488b1c1cee169c37aa9199a6264ba780")
addappid(494363, 1, "4a3f8ca9b21faeb0cd2e6127aeef7c3a074d642230116e9ec2a0ab0505b0ab05")
