-- Lua provided by RyzenAPI
-- Game: Shin Samurai Jazz

-- MAIN APPLICATION
addappid(354970)

-- MAIN APP DEPOTS / PACKAGES
addappid(354971, 1, "789e5abeb70b630537b3ff13fe107500be64b38018f6723673b63bb8ec113483")

