-- Lua provided by RyzenAPI
-- Game: addappid(349760)

-- MAIN APPLICATION
addappid(349760)
addappid(349763)
addappid(349764)

-- MAIN APP DEPOTS / PACKAGES
addappid(349762,0,"5dfa9a889bdb7e65a1a56b1608114d77c2ea08b8b430681f085a3566569e6336")
