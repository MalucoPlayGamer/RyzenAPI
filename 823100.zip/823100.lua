-- Lua provided by RyzenAPI
-- Game: Peace Duke

-- MAIN APPLICATION
addappid(823100)
-- Game: addappid(823100)

-- MAIN APP DEPOTS / PACKAGES
addappid(823101, 1, "73f71c8f69fe1476dad4a36244870cc77c02748daf0167143fc0602bf20bbad2")
