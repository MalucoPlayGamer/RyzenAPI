-- Lua provided by RyzenAPI
-- Game: 3015620

-- MAIN APPLICATION
addappid(3015620)
addappid(4167900)
-- Game: addappid(3015620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015621, 1, "89f663630f68a5c25a643b509807b96e11adbad0ec2ed9bedf02ccb58ebce6aa")
