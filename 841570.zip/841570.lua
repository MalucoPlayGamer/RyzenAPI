-- Lua provided by RyzenAPI
-- Game: BlindMaze

-- MAIN APPLICATION
addappid(841570)
-- Game: addappid(841570)

-- MAIN APP DEPOTS / PACKAGES
addappid(841571, 1, "ff38736d5315a6f2721f90d2f84085184336f55dcd619aac5d8408fddeb729ac")
addappid(841572, 1, "0371f7abcb4dea7e65ad83c6bfacc9362cc87648adfcfbbe95caf50993a7912a")
