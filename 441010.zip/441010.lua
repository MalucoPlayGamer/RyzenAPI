-- Lua provided by RyzenAPI
-- Game: Mount Your Friends 3D: A Hard Man is Good to Climb

-- MAIN APPLICATION
addappid(441010)

-- MAIN APP DEPOTS / PACKAGES
addappid(441011, 1, "6971f7b13080cf903ca6d038aee19b994945f9befed687a1b7c3d0448761fd83")

