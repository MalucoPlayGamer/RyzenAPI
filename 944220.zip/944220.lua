-- Lua provided by RyzenAPI
-- Game: 944220

-- MAIN APPLICATION
addappid(944220)
-- Game: addappid(944220)

-- MAIN APP DEPOTS / PACKAGES
addappid(944221, 1, "071625c457a945e81f12380e050f4847aba7b4b64b30957cbed8afb619918ba1")
