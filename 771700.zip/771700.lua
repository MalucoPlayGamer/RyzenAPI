-- Lua provided by RyzenAPI
-- Game: AppID 771700

-- MAIN APPLICATION
addappid(771700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(771701, 1, "aa71e8bb13c6d0bf005ce3537d5cf45d15645435d492837b2e0b3e2e7c823542")

