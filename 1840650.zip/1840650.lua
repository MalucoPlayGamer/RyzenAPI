-- Lua provided by RyzenAPI 
-- Game: AppID 1840650
addappid(1840650)
addappid(1840651, 1, "5df03d9500373d4270d8843f9afc0ade952c7a5aaa9cbabd9fea12ff94e7bf57")
addappid(1840652, 1, "458c5e1329ce6b9316da4a2571f6314809c7488855a14751e3881ba2307643a9")
