-- Lua provided by RyzenAPI
-- Game: 3720830

-- MAIN APPLICATION
addappid(3720830)
-- Game: addappid(3720830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720831, 1, "942e1801d5524fa6edecb370d2d5e38a4383ba2e598a6ecac51397ceadbb08ef")
