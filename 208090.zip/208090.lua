-- Lua provided by RyzenAPI
-- Game: 208090

-- MAIN APPLICATION
addappid(208090)
addappid(228990)
-- Game: addappid(208090)

-- MAIN APP DEPOTS / PACKAGES
addappid(208091, 1, "545c330a843ba47ab2bc4038b86893a410f3a6ecb3c96d5ef768673c86cf6027")
