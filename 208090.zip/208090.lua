-- Lua provided by RyzenAPI
-- Game: Loadout

-- MAIN APPLICATION
addappid(208090)
addappid(208100)
addappid(208101)
addappid(208102)
addappid(208103)
addappid(228990)
addappid(271520)
addappid(282500)
addappid(304130)
addappid(304131)
addappid(304132)
addappid(304133)
addappid(304134)

-- MAIN APP DEPOTS / PACKAGES
addappid(208091, 1, "545c330a843ba47ab2bc4038b86893a410f3a6ecb3c96d5ef768673c86cf6027")

