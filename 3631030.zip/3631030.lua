-- Lua provided by RyzenAPI
-- Game: StarVaders - Soundtrack

-- MAIN APPLICATION
addappid(3631030)
-- Game: addappid(3631030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3631031, 1, "b636fb3074bbec1c2112f451c361046e191c40c00e12051c5a821493364632b5")
