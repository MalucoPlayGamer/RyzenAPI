-- Lua provided by RyzenAPI 
-- Game: Light Borrower
addappid(829040)
addappid(829041, 1, "8e6667384f2d013d2c94a783eba2e6948ac57b5f3057bef7fc3deaf62899acd8")
