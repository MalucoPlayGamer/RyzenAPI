-- Lua provided by RyzenAPI
-- Game: 2439890

-- MAIN APPLICATION
addappid(2439890)
-- Game: addappid(2439890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439892,0,"db601dceb10f35230c8ce216479d72f9ff4917bc37777b2f8ecdc1d2702671e2")
addappid(2439893,0,"b7fee1ae2a120fbde745216d7251f2acc955f06d4e6bd944bb46752ded3fc0d4")
