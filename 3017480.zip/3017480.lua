-- Lua provided by RyzenAPI 
-- Game: AppID 3017480
addappid(3017480)
addappid(3017481, 1, "cd9058cde5106b5cae6c07e389e8699ecef3a809f0205a5f7e4ed9094a9c628e")
