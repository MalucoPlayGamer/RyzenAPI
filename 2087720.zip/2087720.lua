-- Lua provided by RyzenAPI
-- Game: Capcom Arcade 2nd Stadium: Mini-Album Track 6 - Tiger Road - Gold Dragon Mansion (1st Stage Theme)

-- MAIN APPLICATION
addappid(2087720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087721, 1, "1857e5751209663c85f27e7f81133a6fb2ef948bc9d694b00c51bd4b0852e552")
addappid(2087722, 1, "d353bf92649d0047af3277d26257b732a9c59deea70bcc77e5685c644faea84b")
addappid(2087723, 1, "d3fbd3ac9dcf1c89d392fa2f7fbbd015a7917d3397d22f31bff88345ccbb4b1d")
addappid(2087724, 1, "cb78566a478ca3c166317241661fd4f0208976645b0a1b8a34dbb7fb49111f94")
addappid(2087725, 1, "e30015b910734fd66255251a2e64393014fdbdef4a3da1e8a1cfd5e92b5260ef")
addappid(2087726, 1, "1ccc7411e85e6f3a995b67f39d7b7a1b21223c3aefb97769d7b08c07699736be")

