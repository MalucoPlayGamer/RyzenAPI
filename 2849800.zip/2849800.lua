-- Lua provided by RyzenAPI 
-- Game: AppID 2849800
addappid(2849800)
addappid(2849801, 1, "f28a96bfbea342a37068894325d95fca44f6ccd906aaac0efae35ac9beb29b45")
