-- Lua provided by RyzenAPI
-- Game: Money And Lady

-- MAIN APPLICATION
addappid(3023690) -- Money And Lady
addappid(3168680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023691, 1, "ca75a75d538c49954a3d19aae2f78a7fbc5b509f0688ed966c1ff5166e5f15f0") -- Depot 3023691
addappid(3168680, 1, "67075f673e48fec13e5e73f43010da980f2a99389bb55538734fdee725f257db") -- Money And Lady - HAPPY BOOM PATCH - Depot 3168680

