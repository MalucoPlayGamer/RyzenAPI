-- 3023690's Lua and Manifest Created by Hubcap Manifest
-- Money And Lady
-- Created: September 30, 2025 at 01:26:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3023690) -- Money And Lady
-- MAIN APP DEPOTS
addappid(3023691, 1, "ca75a75d538c49954a3d19aae2f78a7fbc5b509f0688ed966c1ff5166e5f15f0") -- Depot 3023691
setManifestid(3023691, "3675774708206489963", 6845571978)
-- DLCS WITH DEDICATED DEPOTS
-- Money And Lady - HAPPY BOOM PATCH (AppID: 3168680)
addappid(3168680)
addappid(3168680, 1, "67075f673e48fec13e5e73f43010da980f2a99389bb55538734fdee725f257db") -- Money And Lady - HAPPY BOOM PATCH - Depot 3168680
setManifestid(3168680, "1204645125419795634", 6156639225)