-- Lua provided by SkyAPI 
-- Game: Money And Lady | 财貌双全
addappid(3023690)
addappid(3023691, 1, "ca75a75d538c49954a3d19aae2f78a7fbc5b509f0688ed966c1ff5166e5f15f0")
addappid(3168680, 0, "67075f673e48fec13e5e73f43010da980f2a99389bb55538734fdee725f257db")
