-- Lua provided by RyzenAPI
-- Game: addappid(1077530)

-- MAIN APPLICATION
addappid(1077530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077532,0,"73a1afb9ee2377e3cd822156f92537f3bf679c9777cd661ddec366ba3fde030a")
