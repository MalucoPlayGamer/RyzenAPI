-- 4917740's Lua and Manifest Created by Hubcap Manifest
-- Wizard Tournament
-- Created: August 12, 2026 at 01:03:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4917740) -- Wizard Tournament
-- MAIN APP DEPOTS
addappid(4917741, 1, "f9a63e748834ebc9c351030410450f26a6f7aa87f18b7ee320a57a729e94e0ff") -- Depot 4917741
setManifestid(4917741, "5873091917741952562", 1494184852)