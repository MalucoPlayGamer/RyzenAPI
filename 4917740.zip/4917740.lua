-- Lua provided by RyzenAPI
-- Game: Wizard Tournament

-- MAIN APPLICATION
addappid(4917740) -- Wizard Tournament

-- MAIN APP DEPOTS / PACKAGES
addappid(4917741, 1, "f9a63e748834ebc9c351030410450f26a6f7aa87f18b7ee320a57a729e94e0ff") -- Depot 4917741

