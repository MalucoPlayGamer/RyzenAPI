-- Lua provided by RyzenAPI
-- Game: Go Slimey Go!

-- MAIN APPLICATION
addappid(3215230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215231,0,"09f5911cea354942924dcf504934b4f280d81a7065d32d631ea51b81e925edba")

