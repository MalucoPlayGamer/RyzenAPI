-- Lua provided by RyzenAPI
-- Game: Hentai Dream

-- MAIN APPLICATION
addappid(2378540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378541, 1, "a157813363f6713864f6bc850323df1cb0bf36faf17e1d4a14313bf376ed2acb")
