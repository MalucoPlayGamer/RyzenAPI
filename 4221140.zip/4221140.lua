-- Lua provided by RyzenAPI
-- Game: Space Trench

-- MAIN APPLICATION
addappid(4221140)

-- MAIN APP DEPOTS / PACKAGES
addappid(4221141,0,"5a70774f134cd7be0add58cd6aba32284f75e706a6e13c97cde60f7fa979963e")

