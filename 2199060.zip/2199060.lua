-- Lua provided by RyzenAPI
-- Game: Core Devourer

-- MAIN APPLICATION
addappid(2199060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199061, 1, "b2459837790f98bea01c8f2c1cba2965910ac886ca0910330e61e8789f19689f")

