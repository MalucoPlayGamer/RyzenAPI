-- Lua provided by SkyAPI 
-- Game: Core Devourer
addappid(2199060)
addappid(2199061, 1, "b2459837790f98bea01c8f2c1cba2965910ac886ca0910330e61e8789f19689f")
