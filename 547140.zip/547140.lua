-- Lua provided by RyzenAPI
-- Game: Game: AppID 547140

-- MAIN APPLICATION
addappid(547140)
-- Game: addappid(547140)

-- MAIN APP DEPOTS / PACKAGES
addappid(547141, 1, "35ccc6d0a9426be57c2825daaaa46a4fb5df2ed8d96a733256ad4d580702a97e")
