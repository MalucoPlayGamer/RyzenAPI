-- Lua provided by RyzenAPI
-- Game: Lingua Fleur: Lily - Diary1

-- MAIN APPLICATION
addappid(1058960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058960,0,"db05eefadd21a13d91a99d6144cbf37751dc30bed27a948a76e2407b4c5138bd")

