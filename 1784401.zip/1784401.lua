-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - 90s Retro Sounds - Country

-- MAIN APPLICATION
addappid(1784401)
-- Game: addappid(1784401)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784401,0,"d756a125951fd99c82cf3813012994203d6c530835a4a7c2e95efeb1753b7be4")
