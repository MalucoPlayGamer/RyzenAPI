-- Lua provided by SkyAPI 
-- Game: AppID 1914680
addappid(1914680)
addappid(1914681, 1, "00f0446b7663be2b7d7bed8504d15b30e5d2a634456e6da5ddfdaea1868adec6")
