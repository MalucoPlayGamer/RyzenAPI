-- Lua provided by RyzenAPI
-- Game: Game: America's Retribution

-- MAIN APPLICATION
addappid(835110)
-- Game: addappid(835110)

-- MAIN APP DEPOTS / PACKAGES
addappid(835111, 1, "41e6002c70fb5b8b4056239952e960a3b73550eb9ca5e8984f2aaca8785c2d9b")
