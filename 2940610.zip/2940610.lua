-- Lua provided by RyzenAPI 
-- Game: AppID 2940610
addappid(2940610)
addappid(2940611, 1, "19732be9496678e73a08e6fb9a80763274e8c9f434ceac49c0b805668c696fcc")
