-- Lua provided by RyzenAPI
-- Game: addappid(2940610)

-- MAIN APPLICATION
addappid(2940610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940611, 1, "19732be9496678e73a08e6fb9a80763274e8c9f434ceac49c0b805668c696fcc")
