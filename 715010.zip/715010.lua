-- Lua provided by RyzenAPI
-- Game: Diamo XL

-- MAIN APPLICATION
addappid(715010)

-- MAIN APP DEPOTS / PACKAGES
addappid(715011, 1, "881d0e5310e68ad8a8204de7af81bc280e6240aaa290b2ce4b2e99ee394b3afd")
addappid(715012, 1, "db0ddbc833a1ef1cc678120900c51581e2e417bf17bea488a958dffea3a59b57")
addappid(715013, 1, "e5fb3c90575bd24933d34af9da13b6b98c956cfedbcbe0f9df29c6b8636c55a0")

