-- Lua provided by RyzenAPI
-- Game: Game: AppID 394600

-- MAIN APPLICATION
addappid(394600)
-- Game: addappid(394600)

-- MAIN APP DEPOTS / PACKAGES
addappid(394601, 1, "cca3646afb142ba421f85f3db452a2e0bd9fa15a195297b00545f440f5116d89")
