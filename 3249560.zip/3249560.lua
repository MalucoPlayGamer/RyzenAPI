-- Lua provided by RyzenAPI
-- Game: Undercover Fools

-- MAIN APPLICATION
addappid(3249560)
-- Game: addappid(3249560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249561, 1, "ea343cf1ba69fe460155cb56e97c571d6b5a56db520d648d332ff63f6084ce76")
