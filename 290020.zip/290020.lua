-- Lua provided by RyzenAPI
-- Game: LogicBots

-- MAIN APPLICATION
addappid(290020)
-- Game: addappid(290020)

-- MAIN APP DEPOTS / PACKAGES
addappid(290021, 1, "2f0ee90f6347c72cb1bbac9a41bbf2aa55ed5a097247558781b9151f8a0eee12")
