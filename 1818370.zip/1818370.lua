-- Lua provided by RyzenAPI
-- Game: AppID 1818370

-- MAIN APPLICATION
addappid(1818370)
-- Game: addappid(1818370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818371, 1, "c645dc09453d39c14f05f353ead2989e3feef50a672503df97ce23ee3c5cfa5f")
addappid(1818372, 1, "716d9d7a6f427f64701df2004ae1164c201c0fdb34d5bb879770a3885ffb3f99")
