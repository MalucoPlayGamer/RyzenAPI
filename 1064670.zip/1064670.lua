-- Lua provided by RyzenAPI
-- Game: AppID 1064670

-- MAIN APPLICATION
addappid(1064670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064671, 1, "fc0d86b3e6bda7ecc14258f374d2df1daaecd0eaf373d21a9308b8943dd87fac")
