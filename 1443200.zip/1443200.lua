-- Lua provided by RyzenAPI
-- Game: Game: Class of '09

-- MAIN APPLICATION
addappid(1443200)
-- Game: addappid(1443200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443201, 1, "f2b5b84d38ada5c10ba273744eb6bca3639fcaf0aaabd7650015e65c46019029")
