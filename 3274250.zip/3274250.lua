-- Lua provided by RyzenAPI
-- Game: Beat Saber - Monstercat Mixtape 2 - Tokyo Machine - "RAD"

-- MAIN APPLICATION
addappid(3274250)
-- Game: addappid(3274250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274250,0,"0e260a28eb02f50cec5000105a01591d60861f848065d13ded2ddf686252060d")
