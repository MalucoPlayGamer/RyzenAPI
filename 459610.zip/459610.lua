-- Lua provided by RyzenAPI
-- Game: addappid(459610)

-- MAIN APPLICATION
addappid(459610)

-- MAIN APP DEPOTS / PACKAGES
addappid(459611, 1, "5cbc8805170bbb9d7ea12dc07d4345c9f918b65ebd1bea533b05c9b33079d08d")
