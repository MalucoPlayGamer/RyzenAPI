-- Lua provided by RyzenAPI 
-- Game: A Lonely Cabin Trip
addappid(2228890)
addappid(2228891, 1, "270aaf86025da7869dce61aa35c81062c5f41a43a0e68e603ad4e402e6003e40")
