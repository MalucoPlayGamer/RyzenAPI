-- Lua provided by RyzenAPI
-- Game: Forged Battalion

-- MAIN APPLICATION
addappid(686260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(686261, 1, "d079cdd7e7e56fc758c5401a50b4d851c2d774f7b7edb9b5f6df7a5000e92327")

