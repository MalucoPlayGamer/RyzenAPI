-- Lua provided by RyzenAPI 
-- Game: Forged Battalion
addappid(686260)
addappid(686261, 1, "d079cdd7e7e56fc758c5401a50b4d851c2d774f7b7edb9b5f6df7a5000e92327")
