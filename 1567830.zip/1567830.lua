-- Lua provided by RyzenAPI
-- Game: 蛋蛋掌门日志

-- MAIN APPLICATION
addappid(1567830)
-- Game: addappid(1567830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567831, 1, "02436a8e7b760e2b0a094f11d1b48153dbdfb135afa61c220a84be3f243336b0")
