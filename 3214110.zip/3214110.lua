-- Lua provided by RyzenAPI
-- Game: Combat Rover: Operation Storm Demo

-- MAIN APPLICATION
addappid(3214110)
-- Game: addappid(3214110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214111, 1, "dbc24d130abfa3b7bdd2fc3b69487c5596f1b080db9c27f9b649f902d8ef4693")
