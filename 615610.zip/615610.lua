-- Lua provided by RyzenAPI
-- Game: Orbt XL

-- MAIN APPLICATION
addappid(615610)

-- MAIN APP DEPOTS / PACKAGES
addappid(615611, 1, "403895507f5bde603b2e5fcf4d5c93ede719026cad8e5fa4387e719fea261f24")
addappid(615612, 1, "f9cdf7419f706a354c78d403ff3d071613924f875bcb388e0f43befb2c4bd64a")
addappid(615613, 1, "be52910a4bcc01d0ee6825a157a447ebedfc00e7598ed5ee3d816faf923acae5")
