-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] Night Security | 夜間警備

-- MAIN APPLICATION
addappid(2367230)
-- Game: addappid(2367230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367231, 1, "730685812d11dd66d222b93292c251417e6909b3149289208f555169a4557d34")
