-- Lua provided by SkyAPI 
-- Game: [Chilla's Art] Night Security | 夜間警備
addappid(2367230)
addappid(2367231, 1, "730685812d11dd66d222b93292c251417e6909b3149289208f555169a4557d34")
