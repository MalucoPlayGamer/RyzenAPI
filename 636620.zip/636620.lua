-- Lua provided by RyzenAPI
-- Game: AppID 636620

-- MAIN APPLICATION
addappid(636620)
-- Game: addappid(636620)

-- MAIN APP DEPOTS / PACKAGES
addappid(636621, 1, "8ad132095b7dff5b7b2e012a3a05cb85e48a5abd8be64e405175d4da2f74f79f")
