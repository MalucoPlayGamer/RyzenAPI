-- Lua provided by RyzenAPI
-- Game: rote² (roteSquare)

-- MAIN APPLICATION
addappid(1735670)
