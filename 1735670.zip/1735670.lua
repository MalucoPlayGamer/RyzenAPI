-- Lua provided by RyzenAPI
-- Game: rote² (roteSquare)

-- MAIN APPLICATION
addappid(1735670)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2557340)
