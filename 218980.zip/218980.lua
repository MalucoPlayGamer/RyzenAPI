-- Lua provided by RyzenAPI
-- Game: 218980

-- MAIN APPLICATION
addappid(218980)
addappid(218981)
-- Game: addappid(218980)

-- MAIN APP DEPOTS / PACKAGES
addappid(218982,0,"b394977482c7357397550f58313311edfdecdda5966b88fd6f1dacff181662a9")
addappid(218983,0,"0ce75ce8e5884edc9b3c76625d543a923e9b556faae36bc942620f740f3b302a")
