-- Lua provided by RyzenAPI
-- Game: GastroCity: A Restaurant Tycoon Game

-- MAIN APPLICATION
addappid(3690380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3690382,0,"63772fa7c1e6a8538257c1853325ac7c30d913ba5e3d5a3b7c4ed7ee3436d7a3")

