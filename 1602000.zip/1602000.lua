-- Lua provided by RyzenAPI
-- Game: Game: Hotel Architect

-- MAIN APPLICATION
addappid(1602000)
-- Game: addappid(1602000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602001, 1, "0eae087f0db9be78952d7fae0ef01ab55a34cc7d8bae7f18ccc3379d89476fe7")
