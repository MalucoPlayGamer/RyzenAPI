-- Lua provided by RyzenAPI
-- Game: Hotel Architect

-- MAIN APPLICATION
addappid(1602000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1602001, 1, "0eae087f0db9be78952d7fae0ef01ab55a34cc7d8bae7f18ccc3379d89476fe7")

