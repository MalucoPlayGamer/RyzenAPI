-- Lua provided by RyzenAPI
-- Game: 1627570

-- MAIN APPLICATION
addappid(1627570)
-- Game: addappid(1627570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627571, 1, "e661c1eead55950383e838a426867be04461ef2a6dadca9d639d453962de333b")
addappid(3225560, 0, "aea8f638eaba1daafacfefd01049131cd28175920515c6de2acda968040ef673")
