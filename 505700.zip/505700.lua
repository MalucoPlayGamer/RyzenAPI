-- Lua provided by RyzenAPI
-- Game: 505700

-- MAIN APPLICATION
addappid(505700)
-- Game: addappid(505700)

-- MAIN APP DEPOTS / PACKAGES
addappid(505701, 1, "8cb4c334d6c4c718a638446def125fd3901028ad69f97c5df9881f31bad8d397")
