-- Lua provided by RyzenAPI
-- Game: Game: AppID 547010

-- MAIN APPLICATION
addappid(547010)
-- Game: addappid(547010)

-- MAIN APP DEPOTS / PACKAGES
addappid(547011, 1, "171837285e686049f8c127fc9d7c6c067bb551707650e4d2d7e49af9f5e8e55f")
