-- Lua provided by RyzenAPI 
-- Game: AppID 857050
addappid(857050)
addappid(857051, 1, "6858c64c4486de980d795978ea0e0b419e36596b10cb3126dcc978f6afdd7e74")
