-- Lua provided by RyzenAPI
-- Game: Cash Cow DX

-- MAIN APPLICATION
addappid(2225830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225832,0,"b9ed8c7de124388a871e0459d260eb14d9e9f18826fa3ddde54a46536fded68f")

