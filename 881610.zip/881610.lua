-- Lua provided by RyzenAPI
-- Game: Professor Watts Word Search: Space Voyage

-- MAIN APPLICATION
addappid(881610)

-- MAIN APP DEPOTS / PACKAGES
addappid(881611, 1, "22172189d65a52e7f603b1471e2a94a778bf261df5fc3eba3452e58a8a2bd1eb")
