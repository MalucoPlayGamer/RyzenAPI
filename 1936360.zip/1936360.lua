-- Lua provided by RyzenAPI
-- Game: Escape From Mandrillia: Local Asymmetric VR+PC

-- MAIN APPLICATION
addappid(1936360)
addappid(3970680)
-- Game: addappid(1936360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1936361, 1, "f1b2dfcac606c0839d46c944796ba0f9a3503bec8967ff6afc4e070cdf043f4a")
