-- Lua provided by RyzenAPI
-- Game: Pigsaw

-- MAIN APPLICATION
addappid(2519850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519851, 1, "7e64dfb776a6f45f53307b35374961cfa8caeb9dc347e8f91eb55d315481bec9")

