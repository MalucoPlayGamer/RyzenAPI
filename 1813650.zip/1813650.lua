-- Lua provided by RyzenAPI
-- Game: VR Sweet Heart

-- MAIN APPLICATION
addappid(1813650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1813651, 1, "d2c33a5ec3060e3db2a3d66db96574ae147e1173752f5d32efa81d4eadea7e09")

