-- Lua provided by RyzenAPI
-- Game: Leisure Suit Larry 7 - Love for Sail

-- MAIN APPLICATION
addappid(765890)

-- MAIN APP DEPOTS / PACKAGES
addappid(765891, 1, "6978f219eb91690c8660237a74d7251ae7faecf970424a709025ec6550a62768")

