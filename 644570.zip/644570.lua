-- Lua provided by RyzenAPI
-- Game: Game: AppID 644570

-- MAIN APPLICATION
addappid(644570)
-- Game: addappid(644570)

-- MAIN APP DEPOTS / PACKAGES
addappid(644571, 1, "150ae84cd9348f507460f540fa10e755cc9e69b189e10c170186f93812cce935")
