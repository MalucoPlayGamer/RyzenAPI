-- Lua provided by RyzenAPI
-- Game: Tales of Terror: House on the Hill Collector's Edition

-- MAIN APPLICATION
addappid(729930)

-- MAIN APP DEPOTS / PACKAGES
addappid(729931,0,"4ad1bcb2019d3af33d57fc1e63f9e023e3f300653da3b18009da63a07a24d181")

