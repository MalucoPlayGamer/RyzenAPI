-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Bass - Intermediate Linear Playing Exercise 2

-- MAIN APPLICATION
addappid(1122557)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122557,0,"a16119af1147655bb2f39ea4bd92ee7d3d97d5c1521a663eed6bf9273960ec8b")

