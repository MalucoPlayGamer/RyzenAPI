-- Lua provided by RyzenAPI
-- Game: dig

-- MAIN APPLICATION
addappid(1794440)
addappid(1826580)
addappid(1853800)
addappid(1853801)
addappid(1853802)
addappid(2533190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794441, 1, "42f9f2197aedd945b5625f48d743006daf611657c12cb2a914d76957908e2fe1")

