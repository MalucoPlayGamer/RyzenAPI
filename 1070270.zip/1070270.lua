-- Lua provided by RyzenAPI
-- Game: Game: Monster Boy And The Cursed Kingdom Demo

-- MAIN APPLICATION
addappid(1070270)
-- Game: addappid(1070270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070271, 1, "30c163609c9d4f622d20db0f6f13903c51cd89da3d24943bb92e825b0765f296")
