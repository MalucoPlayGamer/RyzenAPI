-- Lua provided by RyzenAPI
-- Game: AppID 1085990

-- MAIN APPLICATION
addappid(1085990)
-- Game: addappid(1085990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085991, 1, "35cf6c2ff0208dfdf359ffc53f6d95a92c0c6428d71a3b203784094598feae49")
