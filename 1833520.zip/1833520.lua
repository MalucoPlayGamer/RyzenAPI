-- Lua provided by RyzenAPI
-- Game: Happy's Humble Burger Farm: Departing Flight (OST)

-- MAIN APPLICATION
addappid(1833520)
-- Game: addappid(1833520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833521, 1, "94f78920d05524eef3a0ceb40a1bd4e106b3135328e46df53848f536c1009370")
