-- Lua provided by RyzenAPI
-- Game: RaidTitans

-- MAIN APPLICATION
addappid(1203140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203141, 1, "37602cdddf57f36b55d551076a364c47518c887fe3a4a817291c7df3acafb8ab")
