-- Lua provided by RyzenAPI 
-- Game: AppID 517320
addappid(517320)
addappid(517321, 1, "d9976495d59e84bbb7008de69f46d9f9a662a0b923068ec5b19a92677e987e90")
