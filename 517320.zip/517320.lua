-- Lua provided by RyzenAPI
-- Game: addappid(517320)

-- MAIN APPLICATION
addappid(517320)

-- MAIN APP DEPOTS / PACKAGES
addappid(517321, 1, "d9976495d59e84bbb7008de69f46d9f9a662a0b923068ec5b19a92677e987e90")
