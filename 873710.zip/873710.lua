-- Lua provided by RyzenAPI
-- Game: Paris: Jigsaw Puzzles

-- MAIN APPLICATION
addappid(873710)

-- MAIN APP DEPOTS / PACKAGES
addappid(873711, 1, "1d91cbac3be7f9ca5c877130c1bdc031518e3ae02451f60cb943af01a5fd6a78")

