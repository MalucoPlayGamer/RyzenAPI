-- Lua provided by RyzenAPI
-- Game: ARMED SEVEN

-- MAIN APPLICATION
addappid(349690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(349691, 1, "0627b63b622e1e9f38ef6e43447f04e10c4fa81a3fdcfea917a2072d8c35a06d")
addappid(349692, 1, "a443bcee01aaab611fa68bfcb6d4ae093bfed4ad24f6f3d25948b36b06d1ad03")
addappid(349693, 1, "fbd65d7fbf3a0e5adfc9abf8b4b211a6acd654885844fd769e0c6fc4baec16d1")

