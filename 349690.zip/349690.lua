-- Lua provided by SkyAPI 
-- Game: AppID 349690
addappid(349690)
addappid(349691, 1, "0627b63b622e1e9f38ef6e43447f04e10c4fa81a3fdcfea917a2072d8c35a06d")
addappid(349692, 1, "a443bcee01aaab611fa68bfcb6d4ae093bfed4ad24f6f3d25948b36b06d1ad03")
addappid(349693, 1, "fbd65d7fbf3a0e5adfc9abf8b4b211a6acd654885844fd769e0c6fc4baec16d1")
