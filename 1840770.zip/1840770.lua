-- Lua provided by RyzenAPI
-- Game: Last Threshold

-- MAIN APPLICATION
addappid(1840770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840771, 1, "c0a5a766236103cabd0d53edb150b337220b65b53aff5bd9ea34cf7582fe32e9")

