-- Lua provided by SkyAPI 
-- Game: Coastal Kitchen Simulator
addappid(3444630)
addappid(3444631, 1, "e1554f73511a4356fbee36d20e50bfd7c12d9791e1e5be7623ea1aa6ebfcd415")
