-- Lua provided by RyzenAPI
-- Game: Coastal Kitchen Simulator

-- MAIN APPLICATION
addappid(3444630)
-- Game: addappid(3444630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3444631, 1, "e1554f73511a4356fbee36d20e50bfd7c12d9791e1e5be7623ea1aa6ebfcd415")
