-- Lua provided by RyzenAPI
-- Game: AppID 4204530

-- MAIN APPLICATION
addappid(4204530)
-- Game: addappid(4204530)

-- MAIN APP DEPOTS / PACKAGES
addappid(4204531, 1, "cf68e3886e076dd14d1781ce17b227087ee52a977e7cef75866f2824ac07e4e6")
