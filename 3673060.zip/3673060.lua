-- Lua provided by RyzenAPI
-- Game: 3673060

-- MAIN APPLICATION
addappid(3673060)
-- Game: addappid(3673060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3673061, 1, "f1e81db7af0e94b79d5c102d03af8bbf130df1ec4da7894aaf4c5b9e9b75b930")
