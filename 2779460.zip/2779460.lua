-- Lua provided by RyzenAPI
-- Game: addappid(2779460)

-- MAIN APPLICATION
addappid(2779460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779461, 1, "93fe2691f9b528e0f250ce4ef5a8e9b14d477fc0be11e84701986e9d55023940")
