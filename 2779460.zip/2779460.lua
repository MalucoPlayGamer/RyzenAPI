-- Lua provided by RyzenAPI
-- Game: Meet My Teacher

-- MAIN APPLICATION
addappid(2779460)
addappid(2818220)
addappid(2818230)
addappid(2818240)
addappid(2818250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779461,0,"93fe2691f9b528e0f250ce4ef5a8e9b14d477fc0be11e84701986e9d55023940")

