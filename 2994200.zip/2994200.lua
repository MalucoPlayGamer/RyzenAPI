-- Lua provided by RyzenAPI
-- Game: Ritter & Rotwein

-- MAIN APPLICATION
addappid(2994200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994201,0,"aed8af5f706d2a26435db418bdb272c5089e9a937eda79b8a55fca40993ecce0")

