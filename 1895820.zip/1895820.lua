-- Lua provided by RyzenAPI
-- Game: Game: Greedventory

-- MAIN APPLICATION
addappid(1895820)
-- Game: addappid(1895820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895821, 1, "f0d9ca60bd56d4a8a4d01d9cc0785234e92f81e0d8ad4bfb7abfc22b6d83c2a3")
