-- Lua provided by RyzenAPI
-- Game: AppID 630640

-- MAIN APPLICATION
addappid(630640)
addappid(1080140)
addappid(1340940)
addappid(1356500)
addappid(1429990)
addappid(1460190)
addappid(1460191)
addappid(1496660)
addappid(1496661)
addappid(1669670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(630641, 1, "d1a365e036daa6c304a7b9ac5382f449fe0f266f81a231134c50d537cfd36b4c")

