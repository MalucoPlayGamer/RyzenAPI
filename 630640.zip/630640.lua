-- Lua provided by RyzenAPI
-- Game: AppID 630640

-- MAIN APPLICATION
addappid(630640)
addappid(1080140)
addappid(1340940)
addappid(1356500)
addappid(1429990)
addappid(1460190)
addappid(1460191)
addappid(1669670)

-- MAIN APP DEPOTS / PACKAGES
addappid(630641, 1, "d1a365e036daa6c304a7b9ac5382f449fe0f266f81a231134c50d537cfd36b4c")
