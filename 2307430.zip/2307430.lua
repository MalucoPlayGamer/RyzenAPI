-- Lua provided by RyzenAPI
-- Game: GHOST: AC-130 Close Air Support

-- MAIN APPLICATION
addappid(2307430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2307431, 1, "8180453fd1ef6ff0bac72ef062d45d755b17833839c56aa475447673e376c7ab")
addappid(2307432, 1, "33412ec38862b266638a7c07b42b5f899322016197f5ed4b5c9afe60c20c7303")

