-- Lua provided by RyzenAPI 
-- Game: Larva Mortus
addappid(11340)
addappid(11341, 1, "11884bce3e35f6328701a3d5f7fd421ab84916f2b1820a31f1c915a8491b1e22")
