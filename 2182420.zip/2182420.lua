-- Lua provided by RyzenAPI
-- Game: Idle Shapes

-- MAIN APPLICATION
addappid(2182420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182421, 1, "94a4cb63fa0e6e63aaac4a4a25ffc1a525d7cdc0349df793f57d8307b67f8908")

