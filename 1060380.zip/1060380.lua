-- Lua provided by RyzenAPI
-- Game: Slime Adventure 2

-- MAIN APPLICATION
addappid(1060380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060381, 1, "094c4ac84c190dd43248b5b38db9dd2b17dc99fa238a4eb35db72001a5f68495")
