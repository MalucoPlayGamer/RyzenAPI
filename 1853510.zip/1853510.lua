-- Lua provided by RyzenAPI
-- Game: addappid(1853510)

-- MAIN APPLICATION
addappid(1853510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853511, 1, "3a42265381c7d8e9bb83a7e5ab49835a43ccc727910faa31a6cb1b9e8fc77421")
