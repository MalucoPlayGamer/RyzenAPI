-- Lua provided by RyzenAPI
-- Game: ROBOCRACY

-- MAIN APPLICATION
addappid(1853510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853511, 1, "3a42265381c7d8e9bb83a7e5ab49835a43ccc727910faa31a6cb1b9e8fc77421")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
