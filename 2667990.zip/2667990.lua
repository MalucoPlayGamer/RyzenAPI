-- Lua provided by RyzenAPI
-- Game: Sapo Xulé and the Unwanted Marriage

-- MAIN APPLICATION
addappid(2667990)
-- Game: addappid(2667990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667994,0,"181dc4b5b5f5f9d291021324fd77d9b8d742a2edb2c3a5d1a204b345f899770a")
