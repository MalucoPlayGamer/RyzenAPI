-- Lua provided by RyzenAPI
-- Game: Contraband Police

-- MAIN APPLICATION
addappid(756800)
addappid(3439880)
-- Game: addappid(756800)

-- MAIN APP DEPOTS / PACKAGES
addappid(756801, 1, "1e813879ae7ee6dc69988e440b40c97412996770a6720c6ffeed76214ac6ce07")
