-- Lua provided by RyzenAPI
-- Game: 2830690

-- MAIN APPLICATION
addappid(2830690)
-- Game: addappid(2830690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830691, 1, "d0363971c0c569c7a2539638b3bb6fbc33c32ccc5f5298a4b60c53f67ea25b6a")
