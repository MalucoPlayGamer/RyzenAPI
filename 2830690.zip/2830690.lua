-- Lua provided by SkyAPI 
-- Game: Save Giant Girl from monsters 4
addappid(2830690)
addappid(2830691, 1, "d0363971c0c569c7a2539638b3bb6fbc33c32ccc5f5298a4b60c53f67ea25b6a")
