-- Lua provided by RyzenAPI
-- Game: The Backwars Demo

-- MAIN APPLICATION
addappid(3451010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3451011, 1, "71f37332a7baf49cd438c86f3b69c03f432cc08f2137edf2c7f77092bdce320b")
