-- Lua provided by RyzenAPI
-- Game: Bot Wars

-- MAIN APPLICATION
addappid(1672140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672141, 1, "c2c2820450e7ceda84fe695f6281f435876cbedd242d973c6fcc4f4ab78d9280")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
