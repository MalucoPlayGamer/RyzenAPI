-- Lua provided by RyzenAPI
-- Game: Bot Wars

-- MAIN APPLICATION
addappid(1672140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672141, 1, "c2c2820450e7ceda84fe695f6281f435876cbedd242d973c6fcc4f4ab78d9280")

