-- Lua provided by RyzenAPI
-- Game: AppID 29160

-- MAIN APPLICATION
addappid(29160)
-- Game: addappid(29160)

-- MAIN APP DEPOTS / PACKAGES
addappid(29161, 1, "b5ced5d29e8ec1d6c45d9a3aac27625dce9f3ef433d10ef7b8539d71272a3a6e")
