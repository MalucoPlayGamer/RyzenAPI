-- Lua provided by RyzenAPI
-- Game: Divine Souls F2P MMO

-- MAIN APPLICATION
addappid(300040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(300041, 1, "e792b149bdfb6349553551857d73ce1066a4696dd0dd6806069fab1fb5688429")

