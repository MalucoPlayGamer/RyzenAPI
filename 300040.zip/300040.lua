-- Lua provided by RyzenAPI
-- Game: Game: Divine Souls F2P MMO

-- MAIN APPLICATION
addappid(300040)
-- Game: addappid(300040)

-- MAIN APP DEPOTS / PACKAGES
addappid(300041, 1, "e792b149bdfb6349553551857d73ce1066a4696dd0dd6806069fab1fb5688429")
