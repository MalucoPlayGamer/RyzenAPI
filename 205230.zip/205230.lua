-- Lua provided by RyzenAPI 
-- Game: Hell Yeah! Wrath of the Dead Rabbit
addappid(205230)
addappid(205231, 1, "07ea6b3b9531e2518094c9345453e15bb045248df1c9a29e9810aa6827b08291")
addappid(213311, 0, "7430545c8a734c8318aa502d4eca350588aea8a1e7edf929b07e7b28789c0945")
addappid(213312, 0, "b7a90073d2d8272e93755097370f772c9c8583c4aed03a302a2a806f71ed43e5")
