-- Lua provided by RyzenAPI
-- Game: October Night Games

-- MAIN APPLICATION
addappid(1334580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1334581, 1, "56f6a2ed9064b85608e9f0917613037647024a945e982fec0d5817be7ff0b629")

