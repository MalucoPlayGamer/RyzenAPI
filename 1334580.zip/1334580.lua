-- Lua provided by RyzenAPI
-- Game: October Night Games

-- MAIN APPLICATION
addappid(1334580)
-- Game: addappid(1334580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334581, 1, "56f6a2ed9064b85608e9f0917613037647024a945e982fec0d5817be7ff0b629")
