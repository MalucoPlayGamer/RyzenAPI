-- Lua provided by RyzenAPI
-- Game: F.E.A.R. 2: Project Origin Demo

-- MAIN APPLICATION
addappid(16470)

-- MAIN APP DEPOTS / PACKAGES
addappid(16421,0,"5d502c01a730f10e231360fb0d3c0c631ffaece0067f787d2fb1b22d7cc84c4f")
addappid(16422,0,"605bb685a77d05d4fdb53ff564fcf8bdad86d0b667b0879fbfda32e98ac39548")
addappid(16424,0,"b80182a6458ebebffd7b9825ca53652ec2eb385b9840b85edae4ac78904eda74")

