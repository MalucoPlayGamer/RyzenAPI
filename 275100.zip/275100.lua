-- Lua provided by RyzenAPI
-- Game: Game: Shelter 2

-- MAIN APPLICATION
addappid(275100)
-- Game: addappid(275100)

-- MAIN APP DEPOTS / PACKAGES
addappid(275101, 1, "2a2f85cf27bd4cef700e89f093def1bdb6824f112432c90c057a371ed9d9cbe9")
addappid(275102, 1, "2c05190081e3970c8f85f6f0580d6ddcf3bf19d07ac6e7e42028196214afcb1e")
addappid(275103, 1, "dcfa9381d58982c1c5d06e73e5c2b9a1054ef4bc8f7210c529fa63a52c859960")
addappid(275104, 1, "cf2b613354e84c0428c5154f070c6f3833f3943e0897446af9e7b4fb9faa3d58")
