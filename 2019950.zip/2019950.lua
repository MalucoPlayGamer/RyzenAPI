-- Lua provided by RyzenAPI
-- Game: Wheels of Duty

-- MAIN APPLICATION
addappid(2019950)
-- Game: addappid(2019950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019951, 1, "780b1d8db23549e4b5cc14d9add5da1ff88cbe5622ddee57c187d45dbed4419c")
