-- Lua provided by RyzenAPI
-- Game: Mush Dash

-- MAIN APPLICATION
addappid(3026250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026252,0,"eec7f6394b2b92a570f8eccc0136880bf10944db5382d66e529c820e25777ac1")

