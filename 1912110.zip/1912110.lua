-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Uchiban Outfit "Yamanbagiri Kunihiro"

-- MAIN APPLICATION
addappid(1912110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912110,0,"af10afd3fa7386bc3e6d97b6aeec25fc83f769ea4d4dbbe67dde9e17587e65ed")
