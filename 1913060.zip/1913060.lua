-- Lua provided by RyzenAPI
-- Game: Long and Hard... Summer! Demo

-- MAIN APPLICATION
addappid(1913060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913061, 1, "223e024c692f229d8d624f6940492ffb2bdf758b955e909fb3ef2a1acf817aa1")
