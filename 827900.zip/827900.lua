-- Lua provided by SkyAPI 
-- Game: Bounty Hunter: Stampede
addappid(827900)
addappid(827901, 1, "34e5ced5a3b22d2b01e80fd06de35fb38b08c6a2ce360cff4c090d3e473f8fa8")
