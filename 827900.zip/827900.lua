-- Lua provided by RyzenAPI
-- Game: Bounty Hunter: Stampede

-- MAIN APPLICATION
addappid(827900)
addappid(1408180)
addappid(1408181)
addappid(1408182)
addappid(1408183)
addappid(1408184)
addappid(1408185)
addappid(1408186)
addappid(1408187)
addappid(1408188)
addappid(1408189)

-- MAIN APP DEPOTS / PACKAGES
addappid(827901,0,"34e5ced5a3b22d2b01e80fd06de35fb38b08c6a2ce360cff4c090d3e473f8fa8")

