-- Lua provided by RyzenAPI 
-- Game: AppID 1631410
addappid(1631410)
addappid(1631411, 1, "f9c2adcd54c13688946fde1f39cdf637d0ec16ec69813f06b474c0b4ded730bb")
