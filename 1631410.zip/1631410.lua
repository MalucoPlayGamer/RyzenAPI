-- Lua provided by RyzenAPI
-- Game: Endless Crawler

-- MAIN APPLICATION
addappid(1631410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631411, 1, "f9c2adcd54c13688946fde1f39cdf637d0ec16ec69813f06b474c0b4ded730bb")

