-- Lua provided by RyzenAPI
-- Game: Game: Reus 2

-- MAIN APPLICATION
addappid(1875060)
-- Game: addappid(1875060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875061, 1, "a33eb91dbaf0ab42248dfe4e4d11a817ad3f8e033b56465281a752da06245e7d")
addappid(1875062, 1, "80791d99567e5d3181ef98a4e8b9138fbf99a33d0d67d1d23d44f46cf315d2b2")
addappid(3010540, 0, "9cf3cbf9469a572366e3c3977b7a7c802708b3fcad132ac73745639df8e05b6f")
