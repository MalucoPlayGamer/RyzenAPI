-- Lua provided by RyzenAPI
-- Game: Dodge It! Online

-- MAIN APPLICATION
addappid(2271320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2271321, 1, "403379f7a1077850c1a967ff421324abadb9e6a72339691c8eb4b96c3413ebd7")

