-- Lua provided by SkyAPI 
-- Game: Dodge It! Online
addappid(2271320)
addappid(2271321, 1, "403379f7a1077850c1a967ff421324abadb9e6a72339691c8eb4b96c3413ebd7")
