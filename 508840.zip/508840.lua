-- Lua provided by RyzenAPI
-- Game: 508840

-- MAIN APPLICATION
addappid(508840)
-- Game: addappid(508840)

-- MAIN APP DEPOTS / PACKAGES
addappid(508841, 1, "e7d682c8c0701dcf21a2242ba10aa8f2e474d00011ccd8f46a1e2a7056ce37e4")
