-- Lua provided by RyzenAPI
-- Game: AppID 508840

-- MAIN APPLICATION
addappid(508840)

-- MAIN APP DEPOTS / PACKAGES
addappid(508841, 1, "e7d682c8c0701dcf21a2242ba10aa8f2e474d00011ccd8f46a1e2a7056ce37e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(530030)
