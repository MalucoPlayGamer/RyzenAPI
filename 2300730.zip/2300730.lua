-- Lua provided by RyzenAPI
-- Game: Superspy Steve

-- MAIN APPLICATION
addappid(2300730)
-- Game: addappid(2300730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300731, 1, "de22af87c55e91c94ad4be69640a02da2b08f7103a9130f8658582631932ba93")
