-- Lua provided by RyzenAPI
-- Game: 878820

-- MAIN APPLICATION
addappid(878820)
-- Game: addappid(878820)

-- MAIN APP DEPOTS / PACKAGES
addappid(878821, 1, "1afe5cac31427d06f1c792ecf3e66b662f524d5c7a1c09ce64e87759c7e66e21")
