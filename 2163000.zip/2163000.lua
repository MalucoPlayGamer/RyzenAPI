-- Lua provided by SkyAPI 
-- Game: 缄默咖啡厅
addappid(2163000)
addappid(2163001, 1, "3df894180938217f21db51afba5c8efdfb33854eec879636dcf95a6691cb1bfe")
addappid(2163003, 1, "b731c237f55ee5dccbe11415983015566f01e8a07eb924c537b0494ccae1c91a")
