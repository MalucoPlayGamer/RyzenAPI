-- Lua provided by RyzenAPI
-- Game: Game: Sins of a Solar Empire: Trinity®

-- MAIN APPLICATION
addappid(201290)
-- Game: addappid(201290)

-- MAIN APP DEPOTS / PACKAGES
addappid(201291, 1, "6bb04d57a33dca6ffff99c7e8fcfdd84bcc741d73f1424ea3a26821554280400")
