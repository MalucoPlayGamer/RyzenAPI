-- Lua provided by RyzenAPI
-- Game: Sins of a Solar Empire: Trinity®

-- MAIN APPLICATION
addappid(201290)

-- MAIN APP DEPOTS / PACKAGES
addappid(201291, 1, "6bb04d57a33dca6ffff99c7e8fcfdd84bcc741d73f1424ea3a26821554280400")
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

