-- Lua provided by RyzenAPI
-- Game: Mannequin

-- MAIN APPLICATION
addappid(2409260)
-- Game: addappid(2409260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409261, 1, "3241b41bcf2432af62bbabedbb209c3b5a1868e596412b4522a51331f851f4e3")
