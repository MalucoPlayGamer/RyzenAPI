-- Lua provided by RyzenAPI
-- Game: Space Beast Terror Fright

-- MAIN APPLICATION
addappid(357330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(357331, 1, "b57bc349d1dc8a12fc7dd6a5120b75cddbc6adeeece780e9a33129e36dcdc697")

