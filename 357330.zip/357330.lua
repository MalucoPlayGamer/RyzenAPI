-- Lua provided by RyzenAPI 
-- Game: Space Beast Terror Fright
addappid(357330)
addappid(357331, 1, "b57bc349d1dc8a12fc7dd6a5120b75cddbc6adeeece780e9a33129e36dcdc697")
