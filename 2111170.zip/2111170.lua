-- Lua provided by RyzenAPI
-- Game: STORY OF SEASONS: A Wonderful Life

-- MAIN APPLICATION
addappid(2111170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111171, 1, "2d9d2b9615e3f11f5256bf67cffb29afba507e75ece6760e7f8e8d8c63f6b8c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2282580)
addappid(2282581)
addappid(2282582)
addappid(2282583)
addappid(2282584)
addappid(2282585)
addappid(2282586)
addappid(2446830)
