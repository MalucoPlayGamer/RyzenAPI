-- Lua provided by RyzenAPI
-- Game: 2889660

-- MAIN APPLICATION
addappid(2889660)
-- Game: addappid(2889660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889661, 1, "8de65c7822383b2d93b5dc0b44e946ab936809a2da93c49d043f289e50f957a7")
