-- Lua provided by RyzenAPI
-- Game: ROBO OH

-- MAIN APPLICATION
addappid(1434880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434881, 1, "baa663fc936818ad2c2e2d94f726e0e1996fbfa047ea62a777b981716d9fd7e6")
