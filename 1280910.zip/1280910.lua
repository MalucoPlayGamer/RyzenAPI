-- Lua provided by RyzenAPI
-- Game: 1280910

-- MAIN APPLICATION
addappid(1280910)
-- Game: addappid(1280910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280911, 1, "556eaf6b3523e989242c9fd2bf97bcac7a5955ea1c5251c19d341bc8d49a677a")
