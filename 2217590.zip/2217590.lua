-- Lua provided by RyzenAPI
-- Game: Àrengard-Invasion

-- MAIN APPLICATION
addappid(2217590)
addappid(2218390)
addappid(2233910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217591, 1, "fe36c3a6c1aaea7073d536732d6253565dd7741f167925033e19479df26c39cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
