-- Lua provided by RyzenAPI
-- Game: 2697060

-- MAIN APPLICATION
addappid(2697060)
-- Game: addappid(2697060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697061, 1, "90eebdd33ee0b6daef15b2e5c67fe87c93717ca8e6e8f9a054e7dcbe1017e9f5")
