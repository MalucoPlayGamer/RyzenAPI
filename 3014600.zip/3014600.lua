-- Lua provided by RyzenAPI
-- Game: SEX Airlines 🔞✈️

-- MAIN APPLICATION
addappid(3014600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014601, 1, "27b0a9e8caa86b0c80e75da3a54d29afba8a84464822bd5ac409cf9f11a25806")
