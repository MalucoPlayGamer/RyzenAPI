-- Lua provided by RyzenAPI
-- Game: Shadow Falls

-- MAIN APPLICATION
addappid(1621480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621481, 1, "7523e7de0ac87c26329fc506de52380acdfa67c337ceb816ee4e5ebb238e3163")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
