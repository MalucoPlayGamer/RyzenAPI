-- Lua provided by SkyAPI 
-- Game: Shadow Falls
addappid(1621480)
addappid(1621481, 1, "7523e7de0ac87c26329fc506de52380acdfa67c337ceb816ee4e5ebb238e3163")
