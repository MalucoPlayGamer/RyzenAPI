-- Lua provided by RyzenAPI
-- Game: Shadow Falls

-- MAIN APPLICATION
addappid(1621480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621481, 1, "7523e7de0ac87c26329fc506de52380acdfa67c337ceb816ee4e5ebb238e3163")
