-- Lua provided by RyzenAPI
-- Game: Town of Zoz

-- MAIN APPLICATION
addappid(1748110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748111,0,"8b37aec374a04cac134ac28a6a99d8b3ffcb618cffd9638a3fbf961f1d305a13")

