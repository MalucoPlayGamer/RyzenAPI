-- Lua provided by RyzenAPI
-- Game: Town of Zoz

-- MAIN APPLICATION
addappid(1748110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748111,0,"8b37aec374a04cac134ac28a6a99d8b3ffcb618cffd9638a3fbf961f1d305a13")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
