-- Lua provided by RyzenAPI
-- Game: 385470

-- MAIN APPLICATION
addappid(385470)
-- Game: addappid(385470)

-- MAIN APP DEPOTS / PACKAGES
addappid(385471, 1, "3a2b20b82c390777ae022e0c32d8eb81d3d5ac59247a967268829b5c592c5a64")
