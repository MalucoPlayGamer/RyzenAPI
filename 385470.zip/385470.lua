-- Lua provided by RyzenAPI 
-- Game: AppID 385470
addappid(385470)
addappid(385471, 1, "3a2b20b82c390777ae022e0c32d8eb81d3d5ac59247a967268829b5c592c5a64")
