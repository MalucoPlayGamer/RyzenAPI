-- Lua provided by RyzenAPI
-- Game: Railroad Lines

-- MAIN APPLICATION
addappid(385470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(385471, 1, "3a2b20b82c390777ae022e0c32d8eb81d3d5ac59247a967268829b5c592c5a64")

