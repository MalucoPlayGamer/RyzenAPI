-- Lua provided by RyzenAPI
-- Game: Game: How a Retired Strategist Saved the Country

-- MAIN APPLICATION
addappid(2169830)
-- Game: addappid(2169830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169831, 1, "50729f57297b7958292cbe0f33ce70aa83e010759ed60e6eb411604df8b407d9")
