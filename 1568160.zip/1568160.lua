-- Lua provided by RyzenAPI
-- Game: Chasing Static Demo

-- MAIN APPLICATION
addappid(1568160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568161, 1, "d86d2d032fde50e2018ba11c2a21646b816176edd4d6ee8dcf2e43a16e636cec")

