-- Lua provided by RyzenAPI
-- Game: setManifestid(525502,"6672497777558769800")

-- MAIN APPLICATION
addappid(525500)

-- MAIN APP DEPOTS / PACKAGES
addappid(525502,0,"fa88b5b541d4de3be2e18faa9f7aa9ed66a0cd1f2e6639fd153a89e1a4601697")

