-- Lua provided by RyzenAPI
-- Game: A Raven Monologue

-- MAIN APPLICATION
addappid(744810)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(763280)
