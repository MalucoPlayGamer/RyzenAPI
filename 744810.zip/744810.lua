-- Lua provided by RyzenAPI
-- Game: A Raven Monologue

-- MAIN APPLICATION
addappid(744810)
addappid(763280)

