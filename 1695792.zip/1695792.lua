-- Lua provided by RyzenAPI
-- Game: addappid(1695792)

-- MAIN APPLICATION
addappid(1695792)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701250,0,"434752fc4cd79a598bbfd1e6f8792d038dead8f79a26abce067d877538997e5d")
