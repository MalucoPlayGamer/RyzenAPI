-- Lua provided by RyzenAPI
-- Game: MewnBase

-- MAIN APPLICATION
addappid(743130)

-- MAIN APP DEPOTS / PACKAGES
addappid(743131, 1, "9de646ec1930d121588be2bc0c8e651f89caab5c681e69af0fb1938d516feb81")
addappid(743132, 1, "827b702d6c4ee34f9e3425a0ad9207d9491348d43a87e082fce008afccb366da")
