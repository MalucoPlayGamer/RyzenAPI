-- Lua provided by RyzenAPI
-- Game: 1036240

-- MAIN APPLICATION
addappid(1036240)
-- Game: addappid(1036240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036241, 1, "a2d7fd11ea51fcae3b1da992e7b95ccc29b8c7582dac6ddab38084e5eee9b0af")
