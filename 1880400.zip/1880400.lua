-- Lua provided by RyzenAPI
-- Game: addappid(1880400)

-- MAIN APPLICATION
addappid(1880400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880401, 1, "d207f21c960257b9f5d5cca6237f57e052768331aff40ee3324bd9238a3ffd4e")
