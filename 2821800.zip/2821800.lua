-- Lua provided by RyzenAPI
-- Game: Drill Core

-- MAIN APPLICATION
addappid(2821800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821801, 1, "2d6f599ca00239c873cb8094d116ff81dc697e1d830ec0e9f62e155f1b5520da")
