-- Lua provided by RyzenAPI
-- Game: Game: Idle Taoist Mage Warrior

-- MAIN APPLICATION
addappid(2427360)
-- Game: addappid(2427360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427361, 1, "56c75726afe937dcd91ec0825ebbd822c6fd0a4117a5b57856d0624fbf1f3d14")
