-- Lua provided by RyzenAPI
-- Game: Tenebris: Terra Incognita

-- MAIN APPLICATION
addappid(2280060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280061, 1, "a8928c3e35f1b486b7e6601779a46aba034470b87b29c84e6035c53ef8da4597")

