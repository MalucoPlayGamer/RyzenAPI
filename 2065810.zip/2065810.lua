-- Lua provided by RyzenAPI
-- Game: Undead Horde 2: Necropolis

-- MAIN APPLICATION
addappid(2065810)
-- Game: addappid(2065810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2065811, 1, "42b390769cfc726615c7a86cbe9a5737ac70af4a22c02623cd1ea63c6eba105b")
