-- Lua provided by RyzenAPI 
-- Game: Undead Horde 2: Necropolis
addappid(2065810)
addappid(2065811, 1, "42b390769cfc726615c7a86cbe9a5737ac70af4a22c02623cd1ea63c6eba105b")
