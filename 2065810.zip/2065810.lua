-- Lua provided by RyzenAPI
-- Game: Undead Horde 2: Necropolis

-- MAIN APPLICATION
addappid(2065810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2065811, 1, "42b390769cfc726615c7a86cbe9a5737ac70af4a22c02623cd1ea63c6eba105b")

