-- Lua provided by RyzenAPI
-- Game: Danger Zone 2

-- MAIN APPLICATION
addappid(513690)

-- MAIN APP DEPOTS / PACKAGES
addappid(513691,0,"f8b8e4d73fdd388c37facf414cc8bcb87f4484d762bec6f59e52e8db854eabda")

