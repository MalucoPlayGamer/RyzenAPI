-- Lua provided by RyzenAPI
-- Game: Hotel Dash™ Suite Success™

-- MAIN APPLICATION
addappid(49000)
-- Game: addappid(49000)

-- MAIN APP DEPOTS / PACKAGES
addappid(49001, 1, "b08e2e37a4f9e9cb8e563de95e10b226d944758cffe703ad15ab2ccd13b9c43b")
