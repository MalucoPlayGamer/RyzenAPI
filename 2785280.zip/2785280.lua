-- Lua provided by RyzenAPI 
-- Game: Ruined Nurse
addappid(2785280)
addappid(2785281, 1, "310cdd51fb23b00e96efb37dc25decdc08cd417a0fced203c292b5d8e1b2a877")
