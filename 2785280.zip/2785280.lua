-- Lua provided by RyzenAPI
-- Game: Ruined Nurse

-- MAIN APPLICATION
addappid(2785280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2785281, 1, "310cdd51fb23b00e96efb37dc25decdc08cd417a0fced203c292b5d8e1b2a877")

