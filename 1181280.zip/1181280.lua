-- Lua provided by SkyAPI 
-- Game: AppID 1181280
addappid(1181280)
addappid(1181281, 1, "fcf252efb80d2f6811e532cec22ef831b50908c60e3664aa53105825328bb954")
