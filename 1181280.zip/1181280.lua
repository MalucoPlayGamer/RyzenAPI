-- Lua provided by RyzenAPI
-- Game: addappid(1181280)

-- MAIN APPLICATION
addappid(1181280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181281, 1, "fcf252efb80d2f6811e532cec22ef831b50908c60e3664aa53105825328bb954")
