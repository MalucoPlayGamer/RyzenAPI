-- Lua provided by RyzenAPI
-- Game: Nightmare

-- MAIN APPLICATION
addappid(1665250)
addappid(2268680)
-- Game: addappid(1665250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665251, 1, "e943f80dc063d129f080752e4199d25636cd56019e5a234b47ade707a9bf5209")
