-- Lua provided by RyzenAPI
-- Game: DuneCrawl Demo

-- MAIN APPLICATION
addappid(3375100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3375101, 1, "0d7a30fda3b53f4e86bd439fbb0fa712b8413ce6e7fc8f7324d6c2c17e389529")

