-- Lua provided by RyzenAPI
-- Game: Game: Chastity Catastrophe

-- MAIN APPLICATION
addappid(1780470)
-- Game: addappid(1780470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780471, 1, "ee5ff53f1e661e5d15c70e57ac19243f1c1a483a532a14275d8101e70d75aaf4")
addappid(1780472, 1, "2e4a4a04aad464032d3f349faf5c0343cd9f6dcb530b0d036cca36ca34bd4f50")
addappid(1780473, 1, "80c87d8e93fd14a34be24f7feeb2a720c155330286355834d316f83913fe16e9")
addappid(1780474, 1, "c34093655b0272422428be3c8fbb23bcb3bc1d9078e5040a15c0973fb4ea5c96")
