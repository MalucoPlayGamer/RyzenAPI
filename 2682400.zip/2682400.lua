-- Lua provided by RyzenAPI
-- Game: addappid(2682400)

-- MAIN APPLICATION
addappid(2682400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682401, 1, "a2a9f25b1a9eac1e09efc30d99f643f0c3d65ddfac102faf9d201ec4a758e2db")
