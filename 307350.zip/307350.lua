-- Lua provided by RyzenAPI
-- Game: 307350

-- MAIN APPLICATION
addappid(307350)
-- Game: addappid(307350)

-- MAIN APP DEPOTS / PACKAGES
addappid(307351, 1, "ff7b9ed6861588e4f45ef03ca024e68c099835155e6768f8a067ec227c6835b5")
