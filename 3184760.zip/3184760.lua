-- Lua provided by RyzenAPI
-- Game: Five Nights at Restroom 2: A Hellish Week

-- MAIN APPLICATION
addappid(3184760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3184760,0,"3242085fa1b7d65f9251040ba1498709e06c7e1dc8c4e7d30f10e49b6f565dd8")
