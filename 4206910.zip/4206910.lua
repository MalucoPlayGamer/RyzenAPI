-- 4206910's Lua and Manifest Created by Hubcap Manifest
-- Kimbap Heaven Simulator
-- Created: July 23, 2026 at 07:44:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4206910) -- Kimbap Heaven Simulator
-- MAIN APP DEPOTS
addappid(4206911, 1, "07dd733182eb88282865eca6d84f0a8dd2c9980359e54045258a1a649d1f31fa") -- Depot 4206911
setManifestid(4206911, "8415085119847926052", 3520631828)