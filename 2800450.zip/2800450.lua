-- Lua provided by RyzenAPI
-- Game: Planetaries

-- MAIN APPLICATION
addappid(2800450)
-- Game: addappid(2800450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800451, 1, "8b515f00500430cd20db00ce76471ac7b69b72f8523c6c7867dccb6cee346fad")
