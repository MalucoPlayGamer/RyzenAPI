-- Lua provided by RyzenAPI
-- Game: Jetpackman

-- MAIN APPLICATION
addappid(1866230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866231, 1, "12059f01ab13010090d0c873413e3bb86d40e88bb2de3d722053340bc0890fa6")
