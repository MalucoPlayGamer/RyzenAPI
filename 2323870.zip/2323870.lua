-- Lua provided by RyzenAPI
-- Game: 乱世无双

-- MAIN APPLICATION
addappid(2323870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323871, 1, "ebb02f8ef5a0c05492a57999bb13b031453e6f357999d1982c9fb746265fe698")

