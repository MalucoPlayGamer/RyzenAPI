-- Lua provided by RyzenAPI
-- Game: 1116870

-- MAIN APPLICATION
addappid(1116870)
addappid(1120180)
-- Game: addappid(1116870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116871, 1, "63aa4ed1f0d367e5574e3489b2cdd0e3a26ef142e11acace5de536f0c63cfffc")
