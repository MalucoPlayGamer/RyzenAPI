-- Lua provided by RyzenAPI
-- Game: Swords of Blood

-- MAIN APPLICATION
addappid(2628100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628101, 1, "07232c3a753d1a51f023c0e580790a6bb9490a2b03076a434eb4490c9a445cc7")

