-- Lua provided by RyzenAPI
-- Game: AppID 1237540

-- MAIN APPLICATION
addappid(1237540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237541, 1, "9037abaea40747709cc5e35d0fcc05f2fba2e2d1b51f6cc785b2af79c61f7e0d")

