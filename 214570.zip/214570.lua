-- Lua provided by RyzenAPI
-- Game: Ether Vapor Remaster

-- MAIN APPLICATION
addappid(214570)
addappid(331250)

-- MAIN APP DEPOTS / PACKAGES
addappid(214571, 1, "4aa9802e2b9fbc6877c3266a47209a243a33a13221983a4c3d5e5bc6d9e6aaad")
