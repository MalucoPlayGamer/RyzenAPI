-- Lua provided by RyzenAPI
-- Game: Arthur's Revenge

-- MAIN APPLICATION
addappid(1467320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467321, 1, "a1278d0a72c504a5995324e3a3616aaa9ef40988240731df236685506ec04160")

