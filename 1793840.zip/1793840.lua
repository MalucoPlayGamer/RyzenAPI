-- Lua provided by RyzenAPI
-- Game: 1793840

-- MAIN APPLICATION
addappid(1793840)
-- Game: addappid(1793840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793841, 1, "88e93f21665c362b6d16aab77ff23f2559ad10e3a1484d818f83815dd999cb1e")
