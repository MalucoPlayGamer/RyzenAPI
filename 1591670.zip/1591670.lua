-- Lua provided by RyzenAPI
-- Game: addappid(1591670)

-- MAIN APPLICATION
addappid(1591670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591671, 1, "2c4c1cd5cd13f741999927bb4dde570f11d8840ae467eb7db0b4f00a3f178e96")
