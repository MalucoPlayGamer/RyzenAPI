-- Lua provided by RyzenAPI
-- Game: Blue Prince Demo

-- MAIN APPLICATION
addappid(2984250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984251, 1, "e6fb12da00c1584d2e4a77db2208d5978144d0d403700e6559ef65585928872f")
