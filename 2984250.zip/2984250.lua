-- Lua provided by SkyAPI 
-- Game: AppID 2984250
addappid(2984250)
addappid(2984251, 1, "e6fb12da00c1584d2e4a77db2208d5978144d0d403700e6559ef65585928872f")
