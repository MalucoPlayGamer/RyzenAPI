-- Lua provided by RyzenAPI 
-- Game: Dungeon Girl
addappid(494090)
addappid(494091, 1, "1d0e66ad4ab61eefe95fe6d8ee0f7cd96816e9af66f166f1339bb6a4aaefb0af")
