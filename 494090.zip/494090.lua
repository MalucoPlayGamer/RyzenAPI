-- Lua provided by RyzenAPI
-- Game: 494090

-- MAIN APPLICATION
addappid(494090)
-- Game: addappid(494090)

-- MAIN APP DEPOTS / PACKAGES
addappid(494091, 1, "1d0e66ad4ab61eefe95fe6d8ee0f7cd96816e9af66f166f1339bb6a4aaefb0af")
