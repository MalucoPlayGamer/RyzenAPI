-- Lua provided by RyzenAPI
-- Game: Dungeon Girl

-- MAIN APPLICATION
addappid(494090)

-- MAIN APP DEPOTS / PACKAGES
addappid(494091, 1, "1d0e66ad4ab61eefe95fe6d8ee0f7cd96816e9af66f166f1339bb6a4aaefb0af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
