-- Lua provided by RyzenAPI
-- Game: 9710

-- MAIN APPLICATION
addappid(9710)
-- Game: addappid(9710)

-- MAIN APP DEPOTS / PACKAGES
addappid(9711, 1, "cf33296d20f606f292ceac718aa7e5a61b9bcc0b3075eae16270339f96c9b6fd")
addappid(9712, 1, "e02870049664114b7fec6ba200d0f3126b34a4d0396be7165cd486992e976844")
addappid(9713, 1, "e03d25ed1e63897160d3079c4abd11a67cacee7453cd3de04d10aa7d02ca68eb")
