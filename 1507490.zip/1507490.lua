-- Lua provided by RyzenAPI
-- Game: Hentai Killer: Girls & Chess

-- MAIN APPLICATION
addappid(1507490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507491, 1, "43ca906e13ff5b54abde68e1e43e215a6d0510a13f46a8c45499b6d4f0069c79")

