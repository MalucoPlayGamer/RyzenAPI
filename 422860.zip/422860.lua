-- Lua provided by RyzenAPI
-- Game: Holodance

-- MAIN APPLICATION
addappid(422860)

-- MAIN APP DEPOTS / PACKAGES
addappid(422861, 1, "14b48ace4adc356204e3847ed692d28ad319af12f31fdecda407a897f2a29f2b")

