-- Lua provided by RyzenAPI
-- Game: Game: AppID 248370

-- MAIN APPLICATION
addappid(248370)
-- Game: addappid(248370)

-- MAIN APP DEPOTS / PACKAGES
addappid(248371, 1, "df5e30d7c04acb563578cc15990ae34437a3a5db38e8d110f4a1f85c3fc263c8")
addappid(248372, 1, "70abd1a41fe4809f01a3f6bb1f235473be03d67de4ca27548c28324b93a182b4")
addappid(248373, 1, "94b9e355b5b5b00d7dfad4c76a94d3920cddf3f41d31327b45da75155f151536")
