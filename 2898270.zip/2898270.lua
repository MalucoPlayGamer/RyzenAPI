-- Lua provided by RyzenAPI
-- Game: Casino Simulator

-- MAIN APPLICATION
addappid(2898270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2898271, 1, "b7b05c08c260c2f0f60c8e3c710557ff2e0c56acaef008ab76d36e12f3bfe83d")
