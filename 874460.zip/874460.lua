-- Lua provided by RyzenAPI
-- Game: AppID 874460

-- MAIN APPLICATION
addappid(874460)

-- MAIN APP DEPOTS / PACKAGES
addappid(874461, 1, "e0d1d093a7293abd79569087ebcdfa17acf1d17a4f6187f88532f618b565e4e7")

