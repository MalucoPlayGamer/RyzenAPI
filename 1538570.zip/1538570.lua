-- Lua provided by RyzenAPI 
-- Game: Patron
addappid(1538570)
addappid(1538571, 1, "0ae219a61f9fab330d2a42b1b7fb8475dca66ce9948d297861b4dd5125c6c6ee")
addappid(1686030, 0, "a114b5572e4e765bb71fe4d78fdaf1533b2077b19daab514de5f01546c6fdcb2")
addappid(1760000, 0, "64aa112ca15617497c271ae0f27d6cd430c566764e0d473335fd8f950885cb78")
