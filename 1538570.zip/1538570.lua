-- Lua provided by RyzenAPI
-- Game: Patron

-- MAIN APPLICATION
addappid(1538570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538571, 1, "0ae219a61f9fab330d2a42b1b7fb8475dca66ce9948d297861b4dd5125c6c6ee")
addappid(1686030, 0, "a114b5572e4e765bb71fe4d78fdaf1533b2077b19daab514de5f01546c6fdcb2")
addappid(1760000, 0, "64aa112ca15617497c271ae0f27d6cd430c566764e0d473335fd8f950885cb78")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
