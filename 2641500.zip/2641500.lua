-- Lua provided by SkyAPI 
-- Game: Li'l Red
addappid(2641500)
addappid(2641501, 1, "3e450a90632b604c86637f7281497fe889b1982d69956a416bb47aa3ea20148e")
