-- Lua provided by RyzenAPI
-- Game: Game: Li'l Red

-- MAIN APPLICATION
addappid(2641500)
-- Game: addappid(2641500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641501, 1, "3e450a90632b604c86637f7281497fe889b1982d69956a416bb47aa3ea20148e")
