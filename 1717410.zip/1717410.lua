-- Lua provided by RyzenAPI
-- Game: addappid(1717410)

-- MAIN APPLICATION
addappid(1717410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717411, 1, "aaac4287a298e9b171dc84ea1b2203859ab6758a6aed84e6dfad2200a39459d2")
addappid(1717412, 1, "0e482c5087bc93b2a7ba85aefccbf5de2747373c4841fd8d067d7f3676fbbd23")
