-- Lua provided by RyzenAPI
-- Game: Game: Helena The 3rd

-- MAIN APPLICATION
addappid(367060)
-- Game: addappid(367060)

-- MAIN APP DEPOTS / PACKAGES
addappid(367061, 1, "b76a0bd4dd17a02e42e55631cb885f4befa2b42c61764c1dcb00278841f9e92a")
