-- Lua provided by RyzenAPI
-- Game: Helena The 3rd

-- MAIN APPLICATION
addappid(367060)

-- MAIN APP DEPOTS / PACKAGES
addappid(367061, 1, "b76a0bd4dd17a02e42e55631cb885f4befa2b42c61764c1dcb00278841f9e92a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
