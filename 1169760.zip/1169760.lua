-- Lua provided by RyzenAPI
-- Game: Game: AppID 1169760

-- MAIN APPLICATION
addappid(1169760)
-- Game: addappid(1169760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169761, 1, "efec2fd2787b3cd2056c7a3ad98013e7217f7a70d1c57294dd950aee860d5d1a")
