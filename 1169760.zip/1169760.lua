-- Lua provided by RyzenAPI
-- Game: AppID 1169760

-- MAIN APPLICATION
addappid(1169760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1169761, 1, "efec2fd2787b3cd2056c7a3ad98013e7217f7a70d1c57294dd950aee860d5d1a")

