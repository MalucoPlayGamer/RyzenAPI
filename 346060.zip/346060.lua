-- Lua provided by RyzenAPI
-- Game: Disney High School Musical 3: Senior Year Dance

-- MAIN APPLICATION
addappid(346060)

-- MAIN APP DEPOTS / PACKAGES
addappid(346061, 1, "9c857ae6f3d89b4c3b9dea95f688c6d554227d62e014193e56cc1a7161d656c8")
addappid(346062, 1, "8a9fa27796ad69e863b274a9268a9532a38f80ebf3121b55bdcb52d280471f1a")
addappid(346063, 1, "f2249db79289248fcfb95d451054fcfb7397e35fd625baa185c327d716b7e2a1")
addappid(346064, 1, "0cfb486da702d24f33da4b1741c9603d5a9b9b522513d9e21b95f1c2c11a483c")
addappid(346065, 1, "0468ac391a2c97426ca755d2bc32b0027a0ec70e945582a2f82ec73d1fc9bf47")
addappid(346066, 1, "e46eb2e4abbe9f17b5a9dbc6c15b3d29f7952f2820ed6ae64f69cdc4bb15ec69")
addappid(346067, 1, "36979e0430910667b8fd073fa66e2cffa45f954744274428e82ec17f3f6c39db")
addappid(346068, 1, "ad85714e2a2d8ca448dad8f86138fca241c3d06caa47e0575c30b9a6e037f734")
addappid(346069, 1, "6b7269f8013fd18ae86a3970a96fc0e3f2a28a43b807d275ec6d86e9ef3161a9")
addappid(349900, 0, "f725981ad38ef783305f225ca9c3c7fc67a57fdabc00b735981f4fa12c6dca82")
addappid(349902, 0, "ff76c2a03a538e812480fece2c1901354cea98ef3f1c2c1e7599657de75ddec6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
