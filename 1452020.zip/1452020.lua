-- Lua provided by RyzenAPI
-- Game: 1452020

-- MAIN APPLICATION
addappid(1452020)
addappid(1452029)
-- Game: addappid(1452020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452028,0,"3ffdc429e989ea1ae55507a2421a890c93b64798d6961ccbe0cddd5475832212")
