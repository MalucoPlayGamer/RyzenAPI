-- Lua provided by RyzenAPI
-- Game: Infinity Strash: DRAGON QUEST The Adventure of Dai

-- MAIN APPLICATION
addappid(1895810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895811, 1, "66e0c0c2fb3bab5aba4e6d81fba4ca733901444874ff9b581eb130c2c57d36cb")
addappid(2118280, 0, "662704661cf18299ce447518dbf4a12a25bc252eab80f62972d7fbdbcb829d83")
addappid(2130430, 0, "6854433404d4b120fd61565a7411b3cb73e601d8888e866e12711a2ad31ba154")
addappid(2130431, 0, "4fa194c9c844706ed8762f3c8c18538764d9e7ac6c64de438e70ca520ab625a1")
addappid(2130432, 0, "a0262602101a882a0ec5c5c13e663d766ad9eb7052dc57070d3f674b8e44bc65")
addappid(2130433, 0, "11ba72743e4354357fc181c0703d278b14c05653c8ae42051a2425bdf398aaae")
addappid(2130434, 0, "05412641b17aeb6a01ddc8e5b8b1c020c77a1ac3d9b2bdf1d8f45f90b0d9fc4a")
addappid(2130435, 0, "35f5b110b37e625d5bc6860bdbb96d7ae1d8289a351aee5aa1a830e4e74528c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2431710)
