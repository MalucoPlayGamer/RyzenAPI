-- Lua provided by RyzenAPI
-- Game: Farming Tractor Simulator: Big Farm

-- MAIN APPLICATION
addappid(2315010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315011, 1, "383f85f799717a2e97601933428795249ccb466e031b910ae82590043d63bba2")
