-- Lua provided by RyzenAPI
-- Game: addappid(284790)

-- MAIN APPLICATION
addappid(284790)

-- MAIN APP DEPOTS / PACKAGES
addappid(284791, 1, "c814574db2a7a411efbf56fc5fe4391eab91c3254dfa5dc53c0305ec303dcb55")
addappid(284792, 1, "1535ffb4c10276f494cabd8a9a9be83d9325346ade91ec14cae8feac6d43ca8f")
addappid(284793, 1, "12a3a0fb47a6abd0cc45b3364f075b5b205aaf43d1d5f709e6b3516e78795668")
