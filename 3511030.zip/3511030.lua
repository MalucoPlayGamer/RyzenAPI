-- Lua provided by RyzenAPI
-- Game: Mini Cozy Room: Lo-Fi

-- MAIN APPLICATION
addappid(3731610)
addappid(3731650)
addappid(3731660)
addappid(3731670)
addappid(3731680)
addappid(4019870)
addappid(4420720) -- Mini Cozy Room  Lo-Fi - Hairstyle Pack
addappid(4430450)
-- addappid(4420720) -- Depot 4420720 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(3511030, 1, "8b9b68601aca430e89969b1968268f79d78cc372b1378a25c1899734f547be5c") -- Mini Cozy Room: Lo-Fi
addappid(3511031, 1, "63addeb1d4c130a0b8466195c15f7c8def157b2fa9b87d815b009f6e1f3b3f54") -- Depot 3511031
addappid(3731610, 1, "e92d909ddd33a1986483a142c83344661bbb26dfc983ce2d1ce634aff91dc7ab") -- Mini Cozy Room  Lo-Fi - Ambient Pack - Depot 3731610
addappid(3731650, 1, "c72b80146f33b31aced0de9f46114c36e9bdf3b2ca6b46eaff2f7de5f2e26ccb") -- Mini Cozy Room  Lo-Fi - Piano Pack - Depot 3731650
addappid(3731660, 1, "b3ab6337d2f385285675c2e4e96b5cf1453b19a35f9c5e9c477e423f919aae78") -- Mini Cozy Room  Lo-Fi - Lo-Fi Hip Hop Pack - Depot 3731660
addappid(3731670, 1, "58940f5bc0297bfd21a692801f9bd2fd5173cbe0c998f54a12e98f269bb11a46") -- Mini Cozy Room  Lo-Fi - Jazz Pack - Depot 3731670
addappid(3731680, 1, "cccd4c372d9573bc3a7795ce20d1f71134070b719014a940d966e1f9f9067588") -- Mini Cozy Room  Lo-Fi - Classic Pack - Depot 3731680
addappid(4019870, 1, "85b36dd2ed580beea310bb3a6502951facebd0f507330397c7003d5f84d62a74") -- Mini Cozy Room  Lo-Fi - nawhij Pack - Depot 4019870
addappid(4430450, 1, "920450e290060dfa376a849cb3125e67ee391e81f385fe01420d3dbdb5ffb808") -- Mini Cozy Room  Lo-Fi - Lo-Five Pack - Depot 4430450

