-- 3511030's Lua and Manifest Created by Hubcap Manifest
-- Mini Cozy Room: Lo-Fi
-- Created: April 14, 2026 at 09:59:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 8

-- MAIN APPLICATION
addappid(3511030, 1, "8b9b68601aca430e89969b1968268f79d78cc372b1378a25c1899734f547be5c") -- Mini Cozy Room: Lo-Fi
-- MAIN APP DEPOTS
addappid(3511031, 1, "63addeb1d4c130a0b8466195c15f7c8def157b2fa9b87d815b009f6e1f3b3f54") -- Depot 3511031
setManifestid(3511031, "3731809747018873933", 2257556714)
-- DLCS WITH DEDICATED DEPOTS
-- Mini Cozy Room  Lo-Fi - Ambient Pack (AppID: 3731610)
addappid(3731610)
addappid(3731610, 1, "e92d909ddd33a1986483a142c83344661bbb26dfc983ce2d1ce634aff91dc7ab") -- Mini Cozy Room  Lo-Fi - Ambient Pack - Depot 3731610
setManifestid(3731610, "5049728378770190684", 178319144)
-- Mini Cozy Room  Lo-Fi - Piano Pack (AppID: 3731650)
addappid(3731650)
addappid(3731650, 1, "c72b80146f33b31aced0de9f46114c36e9bdf3b2ca6b46eaff2f7de5f2e26ccb") -- Mini Cozy Room  Lo-Fi - Piano Pack - Depot 3731650
setManifestid(3731650, "1473955958073598517", 175049123)
-- Mini Cozy Room  Lo-Fi - Lo-Fi Hip Hop Pack (AppID: 3731660)
addappid(3731660)
addappid(3731660, 1, "b3ab6337d2f385285675c2e4e96b5cf1453b19a35f9c5e9c477e423f919aae78") -- Mini Cozy Room  Lo-Fi - Lo-Fi Hip Hop Pack - Depot 3731660
setManifestid(3731660, "6869830191592524255", 233273268)
-- Mini Cozy Room  Lo-Fi - Jazz Pack (AppID: 3731670)
addappid(3731670)
addappid(3731670, 1, "58940f5bc0297bfd21a692801f9bd2fd5173cbe0c998f54a12e98f269bb11a46") -- Mini Cozy Room  Lo-Fi - Jazz Pack - Depot 3731670
setManifestid(3731670, "1590672124428584153", 202761527)
-- Mini Cozy Room  Lo-Fi - Classic Pack (AppID: 3731680)
addappid(3731680)
addappid(3731680, 1, "cccd4c372d9573bc3a7795ce20d1f71134070b719014a940d966e1f9f9067588") -- Mini Cozy Room  Lo-Fi - Classic Pack - Depot 3731680
setManifestid(3731680, "8866004282760907344", 178704048)
-- Mini Cozy Room  Lo-Fi - nawhij Pack (AppID: 4019870)
addappid(4019870)
addappid(4019870, 1, "85b36dd2ed580beea310bb3a6502951facebd0f507330397c7003d5f84d62a74") -- Mini Cozy Room  Lo-Fi - nawhij Pack - Depot 4019870
setManifestid(4019870, "8352239029896544706", 161097903)
-- Mini Cozy Room  Lo-Fi - Lo-Five Pack (AppID: 4430450)
addappid(4430450)
addappid(4430450, 1, "920450e290060dfa376a849cb3125e67ee391e81f385fe01420d3dbdb5ffb808") -- Mini Cozy Room  Lo-Fi - Lo-Five Pack - Depot 4430450
setManifestid(4430450, "6016447553676847037", 88903450)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4420720) -- Mini Cozy Room  Lo-Fi - Hairstyle Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4420720) -- Depot 4420720 (empty depot)