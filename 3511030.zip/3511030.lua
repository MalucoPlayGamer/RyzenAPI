-- Lua provided by RyzenAPI
-- Game: Game: Mini Cozy Room: Lo-Fi

-- MAIN APPLICATION
addappid(3511030)
-- Game: addappid(3511030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3511031, 1, "63addeb1d4c130a0b8466195c15f7c8def157b2fa9b87d815b009f6e1f3b3f54")
addappid(3731610, 0, "e92d909ddd33a1986483a142c83344661bbb26dfc983ce2d1ce634aff91dc7ab")
addappid(3731650, 0, "c72b80146f33b31aced0de9f46114c36e9bdf3b2ca6b46eaff2f7de5f2e26ccb")
addappid(3731660, 0, "b3ab6337d2f385285675c2e4e96b5cf1453b19a35f9c5e9c477e423f919aae78")
addappid(3731670, 0, "58940f5bc0297bfd21a692801f9bd2fd5173cbe0c998f54a12e98f269bb11a46")
addappid(3731680, 0, "cccd4c372d9573bc3a7795ce20d1f71134070b719014a940d966e1f9f9067588")
