-- Lua provided by RyzenAPI
-- Game: Countdown to NTR

-- MAIN APPLICATION
addappid(2919130)
addappid(2919131)
addappid(2919132)
addappid(2919134)
-- Game: addappid(2919130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919133,0,"a916a23830fdfb2a55ee148267cbdd3fee8b59695234e344afff848a8051ff0b")
