-- Lua provided by RyzenAPI
-- Game: Space Engineers

-- MAIN APPLICATION
addappid(573160)
addappid(573900)
addappid(1049790) -- Space Engineers - Decorative Pack
addappid(1084680) -- Space Engineers - Style Pack
addappid(1135960) -- Space Engineers - Economy Deluxe
addappid(1167910) -- Space Engineers - Decorative Pack 2
addappid(1241550)
addappid(1307680) -- Space Engineers - Sparks of the Future
addappid(1374610) -- Space Engineers - Wasteland
addappid(1475830) -- Space Engineers - Warfare 1
addappid(1676100) -- Space Engineers - Heavy Industry
addappid(1783760) -- Space Engineers - Warfare 2
addappid(1958640) -- Space Engineers - Automatons
addappid(2504720) -- Space Engineers - Decorative Pack 3
addappid(2569770) -- Space Engineers - Anniversary Pack
addappid(2914120)
addappid(3066290) -- Space Engineers - Contact Pack
addappid(3601770) -- Space Engineers - Fieldwork Pack
addappid(3858380) -- Space Engineers - Apex Survival Pack
addappid(4116960) -- Space Engineers - Core Systems Pack
addappid(4502100) -- Space Engineers - Economy 2 Pack
addappid(4835530) -- Space Engineers - Prosperity Pack
-- addappid(573161) -- Depot 573161 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
addappid(244850, 1, "88f1361bc409c0dea1f2aada8667ed87d442eed9a908ddc57994d21ff6808a18") -- Space Engineers
addappid(244851, 1, "c2a914f1b4a29930055cf542e9061ead9b68a11f83da2bb811ff0bdd6ccd3fc4") -- Space Engineers Content
addappid(573160, 1, "90b858382780b17809d769a3c519d42315dec52ac14f62cc36a730028c8c2d55") -- Space Engineers Deluxe - Space Engineers Deluxe (573160) Depot
addappid(573900, 1, "4355d154c80000fe9dd53f3d7cee8e668d2f8b838bdaa4fd327f784a740cab10") -- Space Engineers 2013 - Space Engineers First Release (573900) Depot
addappid(1241550, 1, "0f4349457367949e9aca25e33826ae022cd451a67b5ad5761a719d7838caa2f9") -- Space Engineers - Frostbite - Space Engineers - Frostbite (1241550) Depot
addappid(2914120, 1, "06ee550198fe9a4e3e88e9c2ed6213d32339990e903e5513977b540ae06219ed") -- Space Engineers - Signal Pack - Depot 2914120

