-- Lua provided by RyzenAPI
-- Game: addappid(2863090)

-- MAIN APPLICATION
addappid(2863090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863093,0,"5b7bed66f4dbe613b6bff4534d306e22858d07e40c7d4e0727bfb649296afb7f")
