-- Lua provided by RyzenAPI
-- Game: Blue Archive

-- MAIN APPLICATION
addappid(3557620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3557621, 1, "0B4E98809F1C718B10332FE0FE98BF591B2FD8FE88D47E04737CAACDE6C28C65")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
