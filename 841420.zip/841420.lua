-- Lua provided by RyzenAPI
-- Game: Game: AppID 841420

-- MAIN APPLICATION
addappid(841420)
-- Game: addappid(841420)

-- MAIN APP DEPOTS / PACKAGES
addappid(841421, 1, "c2b0f022ff8225c32c0bc352dd498eb85a65d09261d9cdb6769ee4ea9529421a")
