-- Lua provided by RyzenAPI
-- Game: LEMURIA

-- MAIN APPLICATION
addappid(917940)
addappid(2124710)
addappid(2177280)
addappid(2316360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(917941,0,"3f0c72f4664eec3bb6e3e67adde0d6e230cf46c3f56aad4f6f9af1c86ef24ef2")

