-- Lua provided by RyzenAPI
-- Game: AppID 530940

-- MAIN APPLICATION
addappid(530940)
addappid(553980)
addappid(579500)
addappid(579501)
addappid(579502)
addappid(579503)
addappid(580140)

-- MAIN APP DEPOTS / PACKAGES
addappid(530941, 1, "ac4fbff357501dae4a339f425ae926f2c05bee401dd77c86c040954560de5fe0")
addappid(533590, 0, "b97228af4e70631b29b47fec704aec1e7fedd3559f0b8542a4b99c3dd153379e")
addappid(533591, 0, "fbac1dd39cd10be9296b4e9cfdab78dd86c4d8a12d2552f0399b2f9e1f318a14")
addappid(533592, 0, "8f3c2a00ab97a83f5b39ba0f715a54774282873aa88e5ed9c0e0f589bc689178")
addappid(564200, 0, "5f69ffc01a8b323211aeacc84353bfcdfc2b01981e76fd1ad824373a39ef098b")
addappid(579504, 0, "805e5a159de8ecd16afd2a4ef9a03e5f7aed10699d43906cf0d069f27463e55c")
addappid(579505, 0, "59a55387682c646836f8a8aceade8aa22a246024023302b0688ca92b5dc1d0f1")
addappid(579506, 0, "07cc3eb5e4fd2e099c92926e8eaa923fb1db40f7651080337a24159753401fc1")
addappid(579507, 0, "ee17c9035e703f5adf33cff3eac435162c1afba4e649c13abef629752dc5a124")
addappid(579508, 0, "f73ee31d14c81de17e22442b8609bbf30ef5f720e85072003e636a1da353e814")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(543750)
