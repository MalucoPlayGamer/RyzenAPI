-- Lua provided by RyzenAPI
-- Game: Beat Saber - Metallica - "King Nothing"

-- MAIN APPLICATION
addappid(3354540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354540,0,"b3616c6d174fc55806954b440ac06dae9ccd51ea95df214d12959dbc799a2d06")

