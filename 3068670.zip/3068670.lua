-- Lua provided by RyzenAPI
-- Game: Anode Heart: Layer Null

-- MAIN APPLICATION
addappid(3068670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3068671,0,"b74fae8967dbbaf11dc8911db982f81e71bed9d42780b98af6639f7403d67766")
addappid(3068672,0,"0350abc7e5effc3aabd40d077b8043f9bf44abdd0c4b561eee2693247abdd023")

