-- Lua provided by RyzenAPI
-- Game: Tears of Metal

-- MAIN APPLICATION
addappid(1913120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1913121,0,"ef09faa539a0032c86e138039553cfb95ed24ac0a3af18e948854bf7d108cbea")

