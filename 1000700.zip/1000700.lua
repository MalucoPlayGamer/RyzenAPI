-- Lua provided by RyzenAPI
-- Game: Insomnis

-- MAIN APPLICATION
addappid(1000700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000701, 1, "b02cc0c44d32078646664bc2b29adc0a5d3ddf5362ab8f9e806c6de6a1a3c879")

