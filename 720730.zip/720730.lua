-- Lua provided by RyzenAPI
-- Game: Without Escape

-- MAIN APPLICATION
addappid(720730)

-- MAIN APP DEPOTS / PACKAGES
addappid(720731, 1, "19796d0cdd315fd27c1f1f3985a1c344d9c521a832a0e532005c4ed6eae7c5ad")

