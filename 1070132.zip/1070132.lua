-- Lua provided by RyzenAPI
-- Game: 1070132

-- MAIN APPLICATION
addappid(1070132)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070132,0,"8df87d1bd8b33f3a78d9bcd9f42771757c3e9829189ceaa8bd97dbaa3d2551af")

