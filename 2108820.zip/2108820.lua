-- Lua provided by RyzenAPI
-- Game: Pounce Cat

-- MAIN APPLICATION
addappid(2108820)
-- Game: addappid(2108820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108821, 1, "8f672fbaf573a180afdec876798d066255ae6406461867bad8ada1dda16b9cdd")
