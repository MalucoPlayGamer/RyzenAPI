-- Lua provided by RyzenAPI
-- Game: Dragons and Titans

-- MAIN APPLICATION
addappid(263500)
addappid(282130) -- Dragons and Titans - Basic Starter Pack
addappid(282131) -- Dragons and Titans - Premium Starter Pack
addappid(282132) -- Dragons and Titans - Elite Starter Pack
addappid(284500) -- Dragons and Titans - Titan Pass
addappid(284510) -- Dragons and Titans - Act 2
addappid(284511) -- Dragons and Titans - Act 3
addappid(284512) -- Dragons and Titans - Act 4

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(263501, 1, "e4fe4dd9c0d1ab7b50c8e45307ac02e32a149682339ded9a4634edb21132dbe6") -- (windows)
addappid(263502, 1, "ba5c7bf4ecedb26c9b50b78cb969e110b108cf9eed54a3654cb1ad739f9e46f7") -- (macos)
addappid(263503, 1, "e8ca28bb1e7c1b121b49df534d8835c1b09fd9692f734481546e55d6896b3751") -- (linux)

