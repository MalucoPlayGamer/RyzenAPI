-- Lua provided by RyzenAPI
-- Game: Dreamcage Escape

-- MAIN APPLICATION
addappid(556890)

-- MAIN APP DEPOTS / PACKAGES
addappid(556891, 1, "bee044e1e9703e90fb11b568f16b63ec1abc6dd6227acd67f7441edb41b975a9")

