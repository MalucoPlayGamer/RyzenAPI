-- Lua provided by RyzenAPI
-- Game: addappid(325160)

-- MAIN APPLICATION
addappid(325160)

-- MAIN APP DEPOTS / PACKAGES
addappid(325162,0,"7e067bce47000499da091e0c9fad97d127b96bd866c3055a5f1d545c04ca8bfe")
addappid(326290,0,"adce8548eb3321b65a0e235bdfa77e7cbe760c42dbcd5a41d11e12f7f0bb2501")
