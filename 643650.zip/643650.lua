-- Lua provided by RyzenAPI
-- Game: Game: Ken Follett's The Pillars of the Earth - Soundtrack

-- MAIN APPLICATION
addappid(643650)
-- Game: addappid(643650)

-- MAIN APP DEPOTS / PACKAGES
addappid(643651, 1, "e157a70ef9200fb9aaf46217a7f569769b82beb09f848a1d3ae5bbe36d177674")
