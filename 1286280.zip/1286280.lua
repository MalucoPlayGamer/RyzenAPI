-- Lua provided by RyzenAPI
-- Game: Game: Pronty

-- MAIN APPLICATION
addappid(1286280)
-- Game: addappid(1286280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286281, 1, "ebb916a2868eb6ee88612d8d67b81fcc0465b2826adcc9dbbab243f6ece24541")
