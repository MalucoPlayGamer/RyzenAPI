-- Lua provided by SkyAPI 
-- Game: Hell Knight Demo
addappid(2760200)
addappid(2760201, 1, "60561f9d30e377b42236a355fa469abe314beda0d679e39119897097cece9ef3")
