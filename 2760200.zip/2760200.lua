-- Lua provided by RyzenAPI
-- Game: Hell Knight Demo

-- MAIN APPLICATION
addappid(2760200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2760201, 1, "60561f9d30e377b42236a355fa469abe314beda0d679e39119897097cece9ef3")

