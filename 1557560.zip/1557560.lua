-- Lua provided by SkyAPI 
-- Game: Pangman Demo
addappid(1557560)
addappid(1557561, 1, "d81e3d16c3b5900f567f84ca0b3b9ffeb272006f37dec56a5307b8f2a79a849c")
