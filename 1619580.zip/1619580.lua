-- Lua provided by RyzenAPI 
-- Game: Slopecrashers
addappid(1619580)
addappid(1619581, 1, "78268bdf129ff62b394ad6a01bfe74831d564f685507cd84a28c8b407966052a")
