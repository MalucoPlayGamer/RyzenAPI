-- Lua provided by RyzenAPI
-- Game: Game: Slopecrashers

-- MAIN APPLICATION
addappid(1619580)
-- Game: addappid(1619580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619581, 1, "78268bdf129ff62b394ad6a01bfe74831d564f685507cd84a28c8b407966052a")
