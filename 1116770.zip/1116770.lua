-- Lua provided by RyzenAPI
-- Game: Game: AppID 1116770

-- MAIN APPLICATION
addappid(1116770)
-- Game: addappid(1116770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116771, 1, "194b104644a13abdc67425ad88a9ad8835f6824013d2ffa3b94b23dc39542031")
