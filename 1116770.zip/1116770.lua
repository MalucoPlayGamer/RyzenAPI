-- Lua provided by RyzenAPI
-- Game: AppID 1116770

-- MAIN APPLICATION
addappid(1116770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116771, 1, "194b104644a13abdc67425ad88a9ad8835f6824013d2ffa3b94b23dc39542031")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
