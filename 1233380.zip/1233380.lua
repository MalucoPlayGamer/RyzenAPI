-- Lua provided by RyzenAPI
-- Game: Sex Apartments

-- MAIN APPLICATION
addappid(1233380)
-- Game: addappid(1233380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233381, 1, "13d7700e091837834afbf5f00c63910fd6c60a799ce7fef3c71ebe98569c64ed")
