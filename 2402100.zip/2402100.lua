-- Lua provided by RyzenAPI
-- Game: Cube Airport

-- MAIN APPLICATION
addappid(2402100) -- Cube Airport

-- MAIN APP DEPOTS / PACKAGES
addappid(2402101, 1, "9fcabfbb223312d8bc5d1cc8b2266857f0c93c1bcd7ab0c1f19bf0ad6600c35b") -- Depot 2402101
addappid(2402102, 1, "d4aab4147523241666cfab22db8d618fd59377253b636eb4760743032a0c5c08") -- Depot 2402102

