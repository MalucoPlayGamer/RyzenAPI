-- 2402100's Lua and Manifest Created by Hubcap Manifest
-- Cube Airport
-- Created: August 08, 2026 at 22:54:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2402100) -- Cube Airport
-- MAIN APP DEPOTS
addappid(2402101, 1, "9fcabfbb223312d8bc5d1cc8b2266857f0c93c1bcd7ab0c1f19bf0ad6600c35b") -- Depot 2402101
setManifestid(2402101, "3889316480329262279", 410629476)
addappid(2402102, 1, "d4aab4147523241666cfab22db8d618fd59377253b636eb4760743032a0c5c08") -- Depot 2402102
setManifestid(2402102, "7272001036936340030", 402699425)