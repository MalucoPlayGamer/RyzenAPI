-- Lua provided by RyzenAPI 
-- Game: AppID 1312890
addappid(1312890)
addappid(1312891, 1, "292191446dcf173392452984888b104a8333220750629ebad1db0d984d9e4887")
