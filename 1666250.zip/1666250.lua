-- Lua provided by RyzenAPI
-- Game: Circus Electrique

-- MAIN APPLICATION
addappid(1666250)
addappid(2052890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1666251, 1, "7a0f130a1e0bb5a43791d35b4dfc1dbf6b7da0977316e81afa3af0d5d5560764")

