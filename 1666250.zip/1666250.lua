-- Lua provided by RyzenAPI 
-- Game: Circus Electrique
addappid(1666250)
addappid(1666251, 1, "7a0f130a1e0bb5a43791d35b4dfc1dbf6b7da0977316e81afa3af0d5d5560764")
