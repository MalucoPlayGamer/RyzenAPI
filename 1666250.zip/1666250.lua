-- Lua provided by RyzenAPI
-- Game: 1666250

-- MAIN APPLICATION
addappid(1666250)
-- Game: addappid(1666250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666251, 1, "7a0f130a1e0bb5a43791d35b4dfc1dbf6b7da0977316e81afa3af0d5d5560764")
