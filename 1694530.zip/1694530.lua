-- Lua provided by RyzenAPI
-- Game: Game: Wardwell House VR

-- MAIN APPLICATION
addappid(1694530)
-- Game: addappid(1694530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694531, 1, "d7d1b607edb8bf76a12d59f0ba5955981e5b84d8450007e05532c8731451d382")
