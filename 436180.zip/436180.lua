-- Lua provided by RyzenAPI
-- Game: 436180

-- MAIN APPLICATION
addappid(228990)
addappid(436180)
-- Game: addappid(436180)

-- MAIN APP DEPOTS / PACKAGES
addappid(436183,0,"54f7da5da7e07e0cd074e67b2f3b58a8e628cf4596cd31f149b7b6b3c80f9387")
