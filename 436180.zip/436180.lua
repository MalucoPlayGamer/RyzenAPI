-- Lua provided by RyzenAPI
-- Game: Spacelords

-- MAIN APPLICATION
addappid(228990)
addappid(436180)

-- MAIN APP DEPOTS / PACKAGES
addappid(436183,0,"54f7da5da7e07e0cd074e67b2f3b58a8e628cf4596cd31f149b7b6b3c80f9387")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(462600)
addappid(462601)
addappid(462603)
addappid(462604)
addappid(462605)
addappid(580231)
addappid(899410)
addappid(899411)
addappid(984270)
addappid(1030590)
addappid(1100120)
