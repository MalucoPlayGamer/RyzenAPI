-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in Shanghai

-- MAIN APPLICATION
addappid(3118580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118581, 1, "1b26163e51b71904efdc196d3ef27cf32e25e67f8138a748a4524734c1e02a54")
