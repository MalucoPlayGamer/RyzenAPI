-- Lua provided by RyzenAPI
-- Game: Unpacking

-- MAIN APPLICATION
addappid(1135690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135691, 1, "32dcfa1767b00d316eaa45a92c3f4a387f711be0c45ff63508a6b39e233a5f7f")
addappid(1135692, 1, "ee27dc6438ed5a6ef0d323a4ae2863cd1ec157646a31b5287665085f1979b255")
addappid(1135693, 1, "b5fd7ce1c961510f9ffc7db6ec2bd0e67bc2056c9c60ffa506c10c09e801ac97")

