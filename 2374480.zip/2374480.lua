-- Lua provided by RyzenAPI 
-- Game: Naked Hero
addappid(2374480)
addappid(2374481, 1, "1dbf6ce55722b4c77742d6068dfd97ec79d9e0c52dc4ac95da0b1084cbddc47f")
