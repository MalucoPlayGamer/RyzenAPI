-- Lua provided by RyzenAPI
-- Game: Game: Naked Hero

-- MAIN APPLICATION
addappid(2374480)
-- Game: addappid(2374480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374481, 1, "1dbf6ce55722b4c77742d6068dfd97ec79d9e0c52dc4ac95da0b1084cbddc47f")
