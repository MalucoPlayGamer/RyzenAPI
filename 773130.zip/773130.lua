-- Lua provided by RyzenAPI
-- Game: addappid(773130)

-- MAIN APPLICATION
addappid(773130)

-- MAIN APP DEPOTS / PACKAGES
addappid(773131, 1, "b2b8d1777f9f2556f7e584e6984948eed9c270a2210cc06c9a9c824fb821f637")
