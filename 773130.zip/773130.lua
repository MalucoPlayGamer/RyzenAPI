-- Lua provided by RyzenAPI
-- Game: AppID 773130

-- MAIN APPLICATION
addappid(773130)

-- MAIN APP DEPOTS / PACKAGES
addappid(773131, 1, "b2b8d1777f9f2556f7e584e6984948eed9c270a2210cc06c9a9c824fb821f637")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
