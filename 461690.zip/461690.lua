-- Lua provided by SkyAPI 
-- Game: AppID 461690
addappid(461690)
addappid(461691, 1, "af7f9807d9b5ab70d929b2ad4ac79ff0a92c6239fa29f3fe888898b3249183a2")
