-- Lua provided by RyzenAPI
-- Game: AppID 433600

-- MAIN APPLICATION
addappid(433600)

-- MAIN APP DEPOTS / PACKAGES
addappid(433601, 1, "930500de6149307cd295f9ff0ac121df5878d329f996ab27a329ec9e3a699eda")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(457100)
