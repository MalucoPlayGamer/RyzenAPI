-- Lua provided by RyzenAPI
-- Game: 2168870

-- MAIN APPLICATION
addappid(2168870)
-- Game: addappid(2168870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168871, 1, "ba9ebe430f5c37b04e33f6ee1e1fe0fe84156b7313ffeb63d6937f4b3c722dd6")
