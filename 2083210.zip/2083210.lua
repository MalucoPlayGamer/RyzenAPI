-- Lua provided by SkyAPI 
-- Game: Super Woden GP 2
addappid(2083210)
addappid(2083211, 1, "d5a851c0d75567d15c8230415598c577c0d9ffae0f0bb03515db4f2fc4ba8768")
