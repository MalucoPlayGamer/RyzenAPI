-- Lua provided by SkyAPI 
-- Game: AppID 2273580
addappid(2273580)
addappid(2273581, 1, "55ab8244d58bcfbb8309de78d90e9602c51202004fa29789b5665f3f23448bf3")
