-- Lua provided by RyzenAPI
-- Game: Game: Hotshot Racing The Official Soundtrack

-- MAIN APPLICATION
addappid(1400720)
-- Game: addappid(1400720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400721, 1, "a4c125592441e4f31e57a6d97f716379b013b4985c0f79f50157d512351e8c4e")
