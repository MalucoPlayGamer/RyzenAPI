-- Lua provided by RyzenAPI
-- Game: addappid(2855010)

-- MAIN APPLICATION
addappid(2855010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2855011, 1, "82b0340e820d8208574bc01ac8081c4e2f9ae25c7dad1bfb813107068d489c6e")
