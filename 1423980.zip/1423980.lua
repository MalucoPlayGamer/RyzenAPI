-- Lua provided by RyzenAPI
-- Game: 1423980

-- MAIN APPLICATION
addappid(1423980)
-- Game: addappid(1423980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423981, 1, "2d5f52ebf40c5a0d76772252bec833dbe1687710ea3234457c216ce3b69303b3")
