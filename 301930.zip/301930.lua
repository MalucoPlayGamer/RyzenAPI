-- Lua provided by RyzenAPI
-- Game: War of the Human Tanks - Limited Operations

-- MAIN APPLICATION
addappid(301930)

-- MAIN APP DEPOTS / PACKAGES
addappid(301931, 1, "a3b841ea5ac5abe314421836e43bb214a8859e9af4d4a2342813d02fcc348b4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
