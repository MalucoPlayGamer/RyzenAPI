-- Lua provided by RyzenAPI
-- Game: War of the Human Tanks - Limited Operations

-- MAIN APPLICATION
addappid(301930)
-- Game: addappid(301930)

-- MAIN APP DEPOTS / PACKAGES
addappid(301931, 1, "a3b841ea5ac5abe314421836e43bb214a8859e9af4d4a2342813d02fcc348b4c")
