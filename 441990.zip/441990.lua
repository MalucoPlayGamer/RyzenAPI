-- Lua provided by RyzenAPI
-- Game: 441990

-- MAIN APPLICATION
addappid(228990)
addappid(441990)
addappid(441991)

-- MAIN APP DEPOTS / PACKAGES
addappid(357341,0,"ecb34960c8c5998a06d150986dc39d61eef34758ae3886917b7e72e64dc69712")

