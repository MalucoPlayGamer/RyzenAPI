-- Lua provided by RyzenAPI
-- Game: Nayla's Castle

-- MAIN APPLICATION
addappid(2097880) -- Nayla's Castle

-- MAIN APP DEPOTS / PACKAGES
addappid(2097882, 1, "e8a82f4ae601bde673deee16f0e5234454987fa7722ea112f4605db93ebddf68") -- Depot 2097882

