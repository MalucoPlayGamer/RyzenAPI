-- Lua provided by RyzenAPI
-- Game: Soul Eater

-- MAIN APPLICATION
addappid(2836250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2836251, 1, "511bb7c788bc6c535e313a0f33b291408adab46ad544ac86fee8dfa488b42639")
