-- Lua provided by RyzenAPI
-- Game: Arena Champion

-- MAIN APPLICATION
addappid(2194130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194131, 1, "d771f34fcbef691fdc8b5e8580c44835e7a435cf68c8e5b52e7e37b2fd0bcdbd")
