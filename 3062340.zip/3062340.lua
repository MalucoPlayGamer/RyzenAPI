-- Lua provided by RyzenAPI
-- Game: Volleyborne: Unbound Horizons Demo

-- MAIN APPLICATION
addappid(3062340)
-- Game: addappid(3062340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062341, 1, "35be9305866765d549863691cca03930068a5c17420d6a0112f13f52c063b41f")
