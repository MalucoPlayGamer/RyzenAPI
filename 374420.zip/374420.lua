-- Lua provided by RyzenAPI
-- Game: Game: Questria: Rise of the Robot Skullfaces

-- MAIN APPLICATION
addappid(374420)
-- Game: addappid(374420)

-- MAIN APP DEPOTS / PACKAGES
addappid(374421, 1, "223662f5baa1b92f92fafd31d0ebc7fca6c8424395db1dcfc4ca2bd0a3d6af9d")
