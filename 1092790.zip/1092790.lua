-- Lua provided by RyzenAPI
-- Game: Inscryption

-- MAIN APPLICATION
addappid(1092790)
-- Game: addappid(1092790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092791, 1, "524d1fbf5c623583299f19bd4dc4a02744b00056a2b186d832c65fd7158da589")
addappid(1092792, 1, "5924feedab4af060584bed3e37159d187ab7f66c44892fc04470cbbeb40f6da6")
addappid(1092793, 1, "6a24bea06c382f9d2e86202c4b8935ce1c2168c88c89a3be1aa052a9ed41159b")
