-- Lua provided by RyzenAPI 
-- Game: Escape The Museum
addappid(298020)
addappid(298021, 1, "3a9553132494768ecf787ddd1c20dfac259f587783f8a96de44fbe866dcd7d51")
