-- Lua provided by RyzenAPI
-- Game: addappid(298020)

-- MAIN APPLICATION
addappid(298020)

-- MAIN APP DEPOTS / PACKAGES
addappid(298021, 1, "3a9553132494768ecf787ddd1c20dfac259f587783f8a96de44fbe866dcd7d51")
