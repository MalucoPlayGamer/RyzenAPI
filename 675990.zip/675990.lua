-- Lua provided by RyzenAPI
-- Game: Questr

-- MAIN APPLICATION
addappid(675990)

-- MAIN APP DEPOTS / PACKAGES
addappid(675991, 1, "2dc7464cd67d06cb7ae22801926b9634a382e2107c6296fb31ae7ba026eecc74")
