-- Lua provided by RyzenAPI
-- Game: 1647580

-- MAIN APPLICATION
addappid(1647580)
addappid(1647581)
addappid(1647582)
addappid(1647583)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174641,0,"697d5ee432d2e06fb644d3c9536176de82e71ffe4b333f635c904dfa6ed96280")
addappid(1174642,0,"90e9d0a9c55e0aa2363ec6afdbe541ac47297b20c10e90c30dcb48d8b604f46d")
addappid(1174643,0,"0b3b7f9a033dcacd6543281bc3e97fa061f4fe8b13a566dfe654e5b592bbdc38")

