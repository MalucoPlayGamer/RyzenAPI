-- Lua provided by RyzenAPI
-- Game: Game: Mob Rule Classic

-- MAIN APPLICATION
addappid(600420)
-- Game: addappid(600420)

-- MAIN APP DEPOTS / PACKAGES
addappid(600421, 1, "60b49085c2d80a521fb32998a2b9bf3bd5daafcda3f00b0d1a95bb6c7155365a")
