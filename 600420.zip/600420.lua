-- Lua provided by SkyAPI 
-- Game: Mob Rule Classic
addappid(600420)
addappid(600421, 1, "60b49085c2d80a521fb32998a2b9bf3bd5daafcda3f00b0d1a95bb6c7155365a")
