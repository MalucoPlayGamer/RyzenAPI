-- Lua provided by RyzenAPI
-- Game: AppID 3297710

-- MAIN APPLICATION
addappid(3297710)
-- Game: addappid(3297710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3297711, 1, "0ad4409f1cf551dc817b70fc2cae83dba9b2445385268a5991886ddfc90e5e03")
