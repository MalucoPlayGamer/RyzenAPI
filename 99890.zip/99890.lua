-- 99890's Lua and Manifest Created by Hubcap Manifest
-- Darkspore
-- Created: September 29, 2025 at 06:38:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(99890) -- Darkspore
-- MAIN APP DEPOTS
addappid(99891, 1, "8986d4099308fecb3e59b40c7403ee0eb24cb6886a3d55006294d204676df2fa") -- darkspore content
setManifestid(99891, "5463557743298256365", 5908306231)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(99895) -- Darkspore - Game Key
addappid(99896) -- Darkspore - Limited Edition Game Key