-- Lua provided by RyzenAPI
-- Game: addappid(99890)

-- MAIN APPLICATION
addappid(99890)

-- MAIN APP DEPOTS / PACKAGES
addappid(99891, 1, "8986d4099308fecb3e59b40c7403ee0eb24cb6886a3d55006294d204676df2fa")
