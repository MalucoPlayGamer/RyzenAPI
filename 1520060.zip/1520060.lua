-- Lua provided by RyzenAPI
-- Game: Sheep Love

-- MAIN APPLICATION
addappid(1520060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520061, 1, "f22a6d9d77e5447f2d09fbe236b7490d58378a778c4a95effc2f343f6f9b300d")
addappid(1521740, 0, "57222fff5d7923df2cce890eb82590f74a9e5b36cb82fd254caaad2ce25d9017")
