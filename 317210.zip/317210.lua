-- Lua provided by RyzenAPI
-- Game: addappid(317210)

-- MAIN APPLICATION
addappid(317210)

-- MAIN APP DEPOTS / PACKAGES
addappid(317211, 1, "46d1f4d7e5f6e4ca385328e1403330a06e460d7243a12aa7d964c3ca714e0190")
