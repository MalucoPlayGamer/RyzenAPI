-- Lua provided by RyzenAPI
-- Game: Beautiful Japanese Scenery - Animated Jigsaws

-- MAIN APPLICATION
addappid(514090)
-- Game: addappid(514090)

-- MAIN APP DEPOTS / PACKAGES
addappid(514094,0,"557bc46a411431b1c504c48388101a3e8d26ca1240aecba3be26955ed011c773")
addappid(514095,0,"51ae6b2b289c36f90e4348722a8f6ccfc76546bfadaba138e583900e805cfa20")
addappid(514096,0,"ad81df224f2f31338ef2423cbff1113de79d811310bb0e86585a52bf84b37e21")
