-- Lua provided by RyzenAPI
-- Game: 凶鄰

-- MAIN APPLICATION
addappid(3627920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3627921, 1, "dd95031cde6b7b00bb437be56e5cfdb1d21c55af3752bd33ce26c8e23af68ac0")

