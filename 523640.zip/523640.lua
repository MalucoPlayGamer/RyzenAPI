-- Lua provided by RyzenAPI
-- Game: The Works of Mercy

-- MAIN APPLICATION
addappid(523640)

-- MAIN APP DEPOTS / PACKAGES
addappid(523641, 1, "0375389773321860eac430696718d6ee575bd28b6664ef93a9c3ed7c42b9fed0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
