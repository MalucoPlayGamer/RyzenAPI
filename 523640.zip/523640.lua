-- Lua provided by RyzenAPI
-- Game: Game: The Works of Mercy

-- MAIN APPLICATION
addappid(523640)
-- Game: addappid(523640)

-- MAIN APP DEPOTS / PACKAGES
addappid(523641, 1, "0375389773321860eac430696718d6ee575bd28b6664ef93a9c3ed7c42b9fed0")
