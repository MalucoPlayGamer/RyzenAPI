-- Lua provided by RyzenAPI
-- Game: Rock 'N' Roll Defense

-- MAIN APPLICATION
addappid(438480)

-- MAIN APP DEPOTS / PACKAGES
addappid(438481, 1, "e32515484a025addeb2d6d7e4b34b4d73fd2bcff3ee0b5b31d572b54d7d42801")
addappid(438482, 1, "1a88d2ed2ff7071954b379d5bc179f637ac3e36dbf375d7347e22e1bc9a8f680")
addappid(451160, 0, "e77b81bb47900ec58a79152a91193ef3f229a34ed0bb16e56b552584d41b7a31")
