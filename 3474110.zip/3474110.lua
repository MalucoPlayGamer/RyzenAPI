-- Lua provided by SkyAPI 
-- Game: Cubey Quarry
addappid(3474110)
addappid(3474111, 1, "007e4b2e305860139237bee2c530e715fb33bacfaba709cc5f1b1fa91c1438df")
