-- Lua provided by RyzenAPI
-- Game: Cubey Quarry

-- MAIN APPLICATION
addappid(3474110)
-- Game: addappid(3474110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3474111, 1, "007e4b2e305860139237bee2c530e715fb33bacfaba709cc5f1b1fa91c1438df")
