-- Lua provided by RyzenAPI
-- Game: CRYEP

-- MAIN APPLICATION
addappid(798240)

-- MAIN APP DEPOTS / PACKAGES
addappid(798241,0,"4231dac4bb6c5edc754defda4bdae7346d240c2e4a445ca4020e0f6b5fe6e6c8")

