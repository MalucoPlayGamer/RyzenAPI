-- Lua provided by RyzenAPI
-- Game: Game: Hidden World 8 Top-Down 3D

-- MAIN APPLICATION
addappid(2682810)
-- Game: addappid(2682810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682811, 1, "f07e7e3b3d651477cc60c5a82d94d7736a33c2acb2db6f6ee653a3a188e223de")
