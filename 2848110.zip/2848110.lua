-- Lua provided by SkyAPI 
-- Game: Ascent: Rivals Playtest
addappid(2848110)
addappid(2848111, 1, "2cff2c88e1fbee986f0d2da1ae2c447f29d6a52fab4443659d556f92f1e11e45")
