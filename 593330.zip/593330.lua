-- Lua provided by RyzenAPI
-- Game: Algotica Iterations

-- MAIN APPLICATION
addappid(593330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(593331,0,"3135dfea559a49ddb5afbf1baf05e663c4d684a5927d17effa395beed47dcac8")
addappid(593332,0,"29cbac323dcf1e237278cad1f86391d2c8a7f8199be0590c2cda58bf360994e9")
addappid(593334,0,"6f384d03c7e133c21aa5dbccb2619729d2f8a9bf3b80175fcbdd8165048fa422")

