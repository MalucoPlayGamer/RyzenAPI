-- Lua provided by RyzenAPI
-- Game: New Tales from the Borderlands

-- MAIN APPLICATION
addappid(1454970)
addappid(1970470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1454971, 1, "0c09cc3e2bd5caaa5d61569db3274ae251e2f6c3225fed1cb40db1553a66ef35")
addappid(1454972, 1, "ba930a1027c5eb2314b9644d99e87d25131528525c12172fa0328d5a0df9cc36")

