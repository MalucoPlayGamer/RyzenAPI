-- Lua provided by RyzenAPI
-- Game: Logicality

-- MAIN APPLICATION
addappid(2013650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013651, 1, "b85e30259ebe2e4493c67268aebe7f36ce88a510966a5c247fe62fd7ad2930bc")

