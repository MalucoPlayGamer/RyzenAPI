-- Lua provided by SkyAPI 
-- Game: Touhou Juuouen 〜 Unfinished Dream of All Living Ghost.
addappid(2400340)
addappid(2400341, 1, "797d9e2cdc0e52a3cac361b3cc9d4d09bcf023184d25b5267d82a9473c002eb0")
