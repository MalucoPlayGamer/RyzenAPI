-- Lua provided by RyzenAPI
-- Game: Touhou Juuouen 〜 Unfinished Dream of All Living Ghost.

-- MAIN APPLICATION
addappid(2400340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400341, 1, "797d9e2cdc0e52a3cac361b3cc9d4d09bcf023184d25b5267d82a9473c002eb0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
