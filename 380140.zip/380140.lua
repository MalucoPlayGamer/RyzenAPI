-- Lua provided by RyzenAPI
-- Game: The Secret of Tremendous Corporation

-- MAIN APPLICATION
addappid(380140)
addappid(384171)
addappid(500450)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(380141, 1, "0ac855fe4292a5b539086ed26eefa48a8c5ce16fe47b6c74c54f479093969b9d")
addappid(380142, 1, "d6c804903b0e1bfc7d6c200b0097868f1df3a3a3d01aff51df797b470f1843f7")
addappid(380143, 1, "ce9109c1130b10ec5a27b4f83ec1490effa5742a215a83ce7c8d63f03a1e9920")
addappid(380144, 1, "c67592218d463977c4ae866c40c12660633a95933b9137dc1c67f51af772f83f")
addappid(380145, 1, "3ed3832fc944811b15ecb3cb5b1d139afc8b8b92e1055cbe9938fe352fb08bd5")
addappid(380146, 1, "78038ff119a32466cbc03f4883112eb7db649edd01c04668f93a912b4a7c216e")
addappid(408940, 0, "0306b8ca418d70637ede89cc505947a45c83407932fa2172d321564c3a88887f")

