-- Lua provided by RyzenAPI
-- Game: Game: Ikaruga Demo

-- MAIN APPLICATION
addappid(287440)
-- Game: addappid(287440)

-- MAIN APP DEPOTS / PACKAGES
addappid(287441, 1, "ad651fc1699980f55566252d54f5ceb744621c44b666f837851e4cc5ced3236d")
