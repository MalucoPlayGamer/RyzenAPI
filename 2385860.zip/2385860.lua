-- Lua provided by RyzenAPI
-- Game: addappid(2385860)

-- MAIN APPLICATION
addappid(2385860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385861, 1, "bf1702321af0afd9ec1850f374b28b5323ea293c71ca12d60268210b9083a03e")
