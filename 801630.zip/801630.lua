-- Lua provided by RyzenAPI
-- Game: UNDER NIGHT IN-BIRTH Exe:Late[cl-r]

-- MAIN APPLICATION
addappid(801630)
addappid(905680)
addappid(905681)
addappid(905682)
addappid(905683)
addappid(905684)
addappid(905685)
addappid(905686)
addappid(905687)
addappid(905688)
addappid(905689)
addappid(905700)
addappid(905701)
addappid(905702)
addappid(905703)
addappid(905704)
addappid(905705)
addappid(905706)
addappid(905707)
addappid(905708)
addappid(913930)
addappid(1216950)
addappid(1216951)
addappid(1216952)
addappid(1216953)
addappid(1216954)
addappid(1216955)
addappid(1216956)

-- MAIN APP DEPOTS / PACKAGES
addappid(801631,0,"9a118760190ed8f737acd25dfdd8aac5803aac01f6c81d117bb2132d9a90a1aa")
addappid(905680,0,"8e383539adf5b815395c59277568abb524a9d96e8760fc0068bf7948bd81545a")
addappid(1216950,0,"3fd91689671e5e4bb79d727667413253dd9149e60fdb07f0b8e7d589802d7c4b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
