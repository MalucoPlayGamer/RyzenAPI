-- Lua provided by RyzenAPI
-- Game: When the Past Was Around (Original Soundtrack)

-- MAIN APPLICATION
addappid(1413230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413232,0,"e7713874468ed049a19fae35e9cf603c724061e40c0e547bb3fd15d8045aa1fd")
addappid(1413233,0,"7afcd24a6857da0ba10ed1d63730673fdf4132316ea4e8cc07ecee2b0325f638")

