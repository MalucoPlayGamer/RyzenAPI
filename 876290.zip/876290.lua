-- Lua provided by RyzenAPI
-- Game: addappid(876290)

-- MAIN APPLICATION
addappid(876290)

-- MAIN APP DEPOTS / PACKAGES
addappid(876291, 1, "8bffb7323b99cbc2cbe3ef2555825cb2bee65ac896ed68c819a3cbda47c638ca")
