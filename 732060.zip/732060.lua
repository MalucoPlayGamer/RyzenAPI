-- Lua provided by RyzenAPI
-- Game: 732060

-- MAIN APPLICATION
addappid(732060)
-- Game: addappid(732060)

-- MAIN APP DEPOTS / PACKAGES
addappid(732061, 1, "fdc1ff8304d89ada7e41f0ea0129280cabeb1da45d5347edd91478aa53bbfef2")
