-- Lua provided by RyzenAPI
-- Game: 1636300

-- MAIN APPLICATION
addappid(1636300)
-- Game: addappid(1636300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636301, 1, "31bdaf570d9b29616e68f283ad27c0f8db294f7b90666975bdd345ddfc58948c")
