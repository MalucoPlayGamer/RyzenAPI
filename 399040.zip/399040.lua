-- Lua provided by RyzenAPI
-- Game: addappid(399040)

-- MAIN APPLICATION
addappid(399040)

-- MAIN APP DEPOTS / PACKAGES
addappid(399041, 1, "a51f3475aa55563c4d69e7af0bd613a4b4f8812deba229a82e3ad58d341b0fb6")
