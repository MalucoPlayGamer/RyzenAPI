-- Lua provided by RyzenAPI
-- Game: Bouncing Hero

-- MAIN APPLICATION
addappid(999990)

-- MAIN APP DEPOTS / PACKAGES
addappid(999999,0,"34c57169cc9c1a2e19e28e6ad638951bd7dce15f3543539be54e1b12d4be680f")

