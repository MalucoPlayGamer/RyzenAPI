-- Lua provided by RyzenAPI
-- Game: FlyingRock: Arena

-- MAIN APPLICATION
addappid(661950)

-- MAIN APP DEPOTS / PACKAGES
addappid(661951, 1, "71cb17f63e2391972a7a87995aae027bb737288310f1fb4b105b8041106bc0f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1265670)
