-- Lua provided by RyzenAPI
-- Game: Game: FlyingRock: Arena

-- MAIN APPLICATION
addappid(661950)
-- Game: addappid(661950)

-- MAIN APP DEPOTS / PACKAGES
addappid(661951, 1, "71cb17f63e2391972a7a87995aae027bb737288310f1fb4b105b8041106bc0f2")
