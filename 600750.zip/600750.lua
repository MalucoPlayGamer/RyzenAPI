-- Lua provided by RyzenAPI
-- Game: AppID 600750

-- MAIN APPLICATION
addappid(600750)
addappid(668710)
addappid(668714)
-- Game: addappid(600750)

-- MAIN APP DEPOTS / PACKAGES
addappid(600751, 1, "c2d8d67be9a1e0c62c029d4a404b906b205c75b72df43600dc9d5dc5a0137258")
addappid(600752, 1, "6929c441ca0ed99f5f6fe3dca71400b4691685a0ec3c469d23b9c01e5de74365")
