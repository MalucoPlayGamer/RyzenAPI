-- Lua provided by RyzenAPI
-- Game: addappid(1523720)

-- MAIN APPLICATION
addappid(1523720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523721, 1, "ea15734f4ea53d5e88df22b319f8fce3ecb126f4968c54e898d4ee384b1a8ace")
