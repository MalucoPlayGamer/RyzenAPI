-- Lua provided by RyzenAPI
-- Game: addappid(1352930)

-- MAIN APPLICATION
addappid(1352930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352933,0,"635ee2f2bc1fc63e9517e825b75a27071d3d76dc409ced79c1312892abf7fab0")
addappid(1352934,0,"c6f96a0cdb5e91cd0050d0f81ca21843ae0c384991caa4e3c5eaae9da3e28323")
