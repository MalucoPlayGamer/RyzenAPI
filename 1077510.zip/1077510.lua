-- Lua provided by RyzenAPI
-- Game: Breaking Box

-- MAIN APPLICATION
addappid(1077510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077511, 1, "5364d8412f46e4b965cf1d1eae1466693cec55825fba39437ffa9a2d9ad9061a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
