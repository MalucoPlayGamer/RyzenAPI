-- Lua provided by RyzenAPI
-- Game: 1077510

-- MAIN APPLICATION
addappid(1077510)
-- Game: addappid(1077510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077511, 1, "5364d8412f46e4b965cf1d1eae1466693cec55825fba39437ffa9a2d9ad9061a")
