-- Lua provided by RyzenAPI 
-- Game: Pocket Plants
addappid(1467740)
addappid(1467741, 1, "9f874e6bd98d2945c260a453b18522bd7b027edcf5adfe45e38ff8f7cfae5b4f")
