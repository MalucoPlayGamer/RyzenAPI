-- Lua provided by RyzenAPI
-- Game: The Witch's Garden

-- MAIN APPLICATION
addappid(1929670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929671, 1, "76c166da1d3ac7713dea98364360c74ca598ccbee55824b68a52fd2401404ee1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
