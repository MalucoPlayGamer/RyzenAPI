-- Lua provided by RyzenAPI
-- Game: Game: The Witch's Garden

-- MAIN APPLICATION
addappid(1929670)
-- Game: addappid(1929670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929671, 1, "76c166da1d3ac7713dea98364360c74ca598ccbee55824b68a52fd2401404ee1")
