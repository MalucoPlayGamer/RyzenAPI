-- Lua provided by RyzenAPI
-- Game: Heart in the Dark

-- MAIN APPLICATION
addappid(1142890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142891, 1, "c7ad5343c2891db4e6b2ebb87afaca89803054934c22d7834a05fddb29b60574")

