-- Lua provided by RyzenAPI
-- Game: Heart in the Dark

-- MAIN APPLICATION
addappid(1142890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1142891, 1, "c7ad5343c2891db4e6b2ebb87afaca89803054934c22d7834a05fddb29b60574")

