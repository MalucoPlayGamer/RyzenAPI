-- Lua provided by RyzenAPI 
-- Game: Spellcaster University Soundtrack
addappid(1657380)
addappid(1657381, 1, "c86ce560f023825b664463416b88d1267386412c79a91159458804a052292e72")
