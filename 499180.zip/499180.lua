-- Lua provided by RyzenAPI
-- Game: Braid, Anniversary Edition

-- MAIN APPLICATION
addappid(499180)

-- MAIN APP DEPOTS / PACKAGES
addappid(499181, 1, "9c09d267bb11180854133d4cc05cb880cf6688a494be5cea452521225de40556")
addappid(499182, 1, "7052801e7e0590376a4def30e1bef95c91a8e2f7de45bfa619a723b82ad2513c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
