-- Lua provided by RyzenAPI
-- Game: AppID 597120

-- MAIN APPLICATION
addappid(597120)

-- MAIN APP DEPOTS / PACKAGES
addappid(597121, 1, "f1d15e6de475d45120a67a90d70eee8d3f8654cbe07e0538d41df581f08f277a")

