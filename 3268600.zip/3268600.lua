-- Lua provided by RyzenAPI
-- Game: Game: AppID 3268600

-- MAIN APPLICATION
addappid(3268600)
-- Game: addappid(3268600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3268601, 1, "c02a62265079b7984e629157ce299f25dc4fed5d43ab17a4246f3d83157be99d")
