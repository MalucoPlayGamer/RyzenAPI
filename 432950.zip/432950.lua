-- Lua provided by RyzenAPI
-- Game: Orange Moon

-- MAIN APPLICATION
addappid(432950)
addappid(694700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(432951, 1, "f3ee058c1106e1163fac1085656a1dad7e837ae403d027c218011c4fa1f691a6")
