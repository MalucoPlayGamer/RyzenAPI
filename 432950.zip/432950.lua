-- Lua provided by RyzenAPI 
-- Game: AppID 432950
addappid(432950)
addappid(432951, 1, "f3ee058c1106e1163fac1085656a1dad7e837ae403d027c218011c4fa1f691a6")
