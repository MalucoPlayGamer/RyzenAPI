-- Lua provided by RyzenAPI
-- Game: No Time to Build

-- MAIN APPLICATION
addappid(3511660)
addappid(3511661)
addappid(3511663)
addappid(3511664)

-- MAIN APP DEPOTS / PACKAGES
addappid(3511662,0,"afd17ae5075ad9b16ab80aefbadd87b22980318f6fb7c238aed2f75b7aa150a8")
