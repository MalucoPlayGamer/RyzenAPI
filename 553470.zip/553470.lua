-- Lua provided by RyzenAPI
-- Game: Destination Ares

-- MAIN APPLICATION
addappid(553470)

-- MAIN APP DEPOTS / PACKAGES
addappid(553471, 1, "33ad8ea4ec03c35c7acc53740b36f28d3308220a61ccb5ba7b3e1d6bfd6070df")

