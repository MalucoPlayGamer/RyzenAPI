-- Lua provided by RyzenAPI
-- Game: Game: AppID 420100

-- MAIN APPLICATION
addappid(420100)
-- Game: addappid(420100)

-- MAIN APP DEPOTS / PACKAGES
addappid(420101, 1, "cafe5f967c705ab79a941aff9357036b9d8d438a0523605c1e5aaedcf5849881")
