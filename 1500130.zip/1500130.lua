-- Lua provided by RyzenAPI
-- Game: Monitor Girl | 监控姬

-- MAIN APPLICATION
addappid(1500130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500131, 1, "ba10a319b6f55067b19105732fa14ade0f85193669c9466e9f81f874c4cb72d4")

