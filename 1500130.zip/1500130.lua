-- Lua provided by SkyAPI 
-- Game: Monitor Girl | 监控姬
addappid(1500130)
addappid(1500131, 1, "ba10a319b6f55067b19105732fa14ade0f85193669c9466e9f81f874c4cb72d4")
