-- Lua provided by RyzenAPI
-- Game: 3402460

-- MAIN APPLICATION
addappid(3402460)
-- Game: addappid(3402460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402461, 1, "d51c96c0377eab7e6d53cc7336d6dfbd685a16db2b0779cd561d8bdd53e2e8bd")
