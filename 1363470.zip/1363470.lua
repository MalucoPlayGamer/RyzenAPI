-- Lua provided by RyzenAPI
-- Game: ARISEN: Prologue

-- MAIN APPLICATION
addappid(1363470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363471, 1, "116b1955557eb1a75e44d4e903cc7d43ca54bdd2baa0e615511845f566606aae")
