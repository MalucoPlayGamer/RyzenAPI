-- Lua provided by RyzenAPI
-- Game: Mato Anomalies

-- MAIN APPLICATION
addappid(2024390)
addappid(2315370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024391, 1, "0f1bbe77716b58499ff955b92477cea3615d57f4ed09e711424f9d27cf0e8665")
addappid(2315320, 0, "f9e416ba262008f539b325f86de4780bab269880a253d86c98323f586293be30")
addappid(2315350, 0, "9e94d7c6c6c90c847c3c4384bb80fda0339f950c5d5076c980daed6cec585a3b")
addappid(2315351, 0, "d38d6f70a51f3beb4d7d51ce76f341e118e2c8151dee79171ba0bf6637be7882")
addappid(2315352, 0, "4d89dea1d5cd6858eb94a15700e5d12e2ab1d1e74e4eb17ec8c3b3e8703f0738")
addappid(2315353, 0, "66ee3d8eaaddcb1e808d3dcfae7df49e7268e08ba751e0e5445fbfc0a610555e")
addappid(2315354, 0, "74b37d70492c50d98e6a47e892cea108141417b000f8fb4290f9ca8dfa606e18")
addappid(2315371, 0, "40c49bf85a46cf786820a9be88a9d4f366e129c3132e5c9648ab06fbdae22ce2")
addappid(2315380, 0, "cd17f32a7cb5ce8e43ae9e8ce2e800cd56ec10f5ae59f40f75d6984c06f9f05e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
