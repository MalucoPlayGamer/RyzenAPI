-- Lua provided by RyzenAPI
-- Game: Game: AppID 392940

-- MAIN APPLICATION
addappid(392940)
addappid(404930)
addappid(425380)
-- Game: addappid(392940)

-- MAIN APP DEPOTS / PACKAGES
addappid(392941, 1, "88d812976235439ba02ce6a5646bf1e140c237a7d28f7364a0ffea8eb126714b")
