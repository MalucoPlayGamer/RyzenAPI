-- Lua provided by RyzenAPI 
-- Game: AppID 392940
addappid(392940)
addappid(392941, 1, "88d812976235439ba02ce6a5646bf1e140c237a7d28f7364a0ffea8eb126714b")
addappid(404930)
addappid(425380)
