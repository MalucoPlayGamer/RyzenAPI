-- Lua provided by RyzenAPI
-- Game: Shades of Rayna

-- MAIN APPLICATION
addappid(1569820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569821, 1, "44e9977c512cd957fd4451b094c2fc877f56636793140ca9e9003ad35445c129")

