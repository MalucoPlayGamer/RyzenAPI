-- Lua provided by RyzenAPI
-- Game: Shades of Rayna

-- MAIN APPLICATION
addappid(1569820)
addappid(1625560)
addappid(1625590)
addappid(1638900)
addappid(1677760)
addappid(1721040)
addappid(1797620)
addappid(1798370)
addappid(1848760)
addappid(1942220)
addappid(2075520)
addappid(2368290)
addappid(2523680)
addappid(2714570)
addappid(3567500)
addappid(4046290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1569821, 1, "44e9977c512cd957fd4451b094c2fc877f56636793140ca9e9003ad35445c129")

