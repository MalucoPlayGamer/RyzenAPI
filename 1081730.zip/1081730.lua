-- Lua provided by SkyAPI 
-- Game: AppID 1081730
addappid(1081730)
addappid(1081731, 1, "541c493d97512289a4227818f2d875fe5d7636e0f6ed733a31ec4b593799a007")
