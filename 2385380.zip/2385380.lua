-- Lua provided by RyzenAPI
-- Game: 2385380

-- MAIN APPLICATION
addappid(2385380)
-- Game: addappid(2385380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385380,0,"59c32c8e5c3df0ee1c11e05761ede7550c14cb793bc8ab739b181ea99c872237")
