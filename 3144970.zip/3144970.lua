-- Lua provided by RyzenAPI
-- Game: МЕМОЛОГИЯ: ЕГЭ ПО МЕМАМ Demo

-- MAIN APPLICATION
addappid(3144970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144971, 1, "4dbca7eafe87c5621d2c1159dd35ff6c7bad3d69aec23564ed1ddc3c7baa1aab")

