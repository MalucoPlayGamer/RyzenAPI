-- Lua provided by RyzenAPI
-- Game: 1833300

-- MAIN APPLICATION
addappid(1833300)
-- Game: addappid(1833300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833301, 1, "0827f71aa021eec70e29b181bd39b9f1e785aa456f71c2f042f0c8a30edf65ee")
