-- Lua provided by SkyAPI 
-- Game: Epics of Distant Realm: Holy Return
addappid(1833300)
addappid(1833301, 1, "0827f71aa021eec70e29b181bd39b9f1e785aa456f71c2f042f0c8a30edf65ee")
