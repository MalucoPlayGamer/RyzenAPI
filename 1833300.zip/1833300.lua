-- Lua provided by RyzenAPI
-- Game: Epics of Distant Realm: Holy Return

-- MAIN APPLICATION
addappid(1833300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833301, 1, "0827f71aa021eec70e29b181bd39b9f1e785aa456f71c2f042f0c8a30edf65ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
