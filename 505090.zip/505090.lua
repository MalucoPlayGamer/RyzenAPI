-- Lua provided by RyzenAPI
-- Game: Game: The Charming Empire

-- MAIN APPLICATION
addappid(505090)
-- Game: addappid(505090)

-- MAIN APP DEPOTS / PACKAGES
addappid(505091, 1, "37cbaafccdef54a1729513282da207b088770563a69f35ea8d3ee7d45348b64c")
