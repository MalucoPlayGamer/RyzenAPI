-- Lua provided by RyzenAPI
-- Game: 2646350

-- MAIN APPLICATION
addappid(2646350)
-- Game: addappid(2646350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646351, 1, "cc0bbed8727c1426ae75600e655420a5ccb48c85393598d0ffb8df5c8c406dfb")
