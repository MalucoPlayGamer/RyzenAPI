-- Lua provided by RyzenAPI
-- Game: Zafehouse Diaries 2

-- MAIN APPLICATION
addappid(653940)

-- MAIN APP DEPOTS / PACKAGES
addappid(653941, 1, "2deb156a6570fff5044e9bb2f01670f63ff7b4b6c7ca52a86cd171e1538cb7f5")

