-- 4414210's Lua and Manifest Created by Hubcap Manifest
-- Dice Carnival
-- Created: July 18, 2026 at 10:07:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4414210) -- Dice Carnival
-- MAIN APP DEPOTS
addappid(4414211, 1, "c344a68db482ab9d5ef0b2f7a5509a20fd6ffa705bc8327f465bd08c5442a259") -- Depot 4414211
setManifestid(4414211, "2721734333659815608", 1696923411)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4927160) -- Dice Carnival - Supporter Pack