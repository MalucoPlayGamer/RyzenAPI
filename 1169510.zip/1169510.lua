-- Lua provided by RyzenAPI
-- Game: addappid(1169510)

-- MAIN APPLICATION
addappid(1169510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169511, 1, "5cff9944effe964d3580f67a36517b2f2128a231475dbabef5d91a77f7ae3d2b")
