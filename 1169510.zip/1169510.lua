-- Lua provided by RyzenAPI
-- Game: AppID 1169510

-- MAIN APPLICATION
addappid(1169510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169511, 1, "5cff9944effe964d3580f67a36517b2f2128a231475dbabef5d91a77f7ae3d2b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
