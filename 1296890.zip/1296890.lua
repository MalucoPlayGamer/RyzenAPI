-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1296890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296892,0,"3101484424c4a6d5e416d263d9e33bdf6d607d35190c63cd5cadd1f29d5f08c9")
addappid(1296893,0,"ed870f79c7433f6a238a0e8b56262683f9be58a672607832c30c6ebe08975d94")
