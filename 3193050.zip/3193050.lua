-- Lua provided by SkyAPI 
-- Game: Nortopia Demo
addappid(3193050)
addappid(3193051, 1, "45cca0078073f4514981ecbeac3cb35b6a7f5bf1c7d9615995cfc737e0df9265")
