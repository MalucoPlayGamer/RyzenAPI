-- Lua provided by RyzenAPI
-- Game: 717500

-- MAIN APPLICATION
addappid(717500)
-- Game: addappid(717500)

-- MAIN APP DEPOTS / PACKAGES
addappid(717191,0,"4a6c950b7eb46ed9784506aa4ad1171ef5d8a4c5b03926f1ec24a91177653b46")
