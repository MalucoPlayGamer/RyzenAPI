-- Lua provided by RyzenAPI
-- Game: 2208060

-- MAIN APPLICATION
addappid(2208060)
-- Game: addappid(2208060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208061, 1, "1a513b45edac409e60c56f9db1dc1139bcd58beed99f62b7934887e64905002c")
