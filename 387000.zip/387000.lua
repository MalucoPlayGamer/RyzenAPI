-- Lua provided by RyzenAPI
-- Game: Game: Survivor Squad: Gauntlets Demo

-- MAIN APPLICATION
addappid(387000)
-- Game: addappid(387000)

-- MAIN APP DEPOTS / PACKAGES
addappid(387001, 1, "4a5feffeb22bc8e65f70982a12bae8b17528e7210922b87c300078fdcf474647")
