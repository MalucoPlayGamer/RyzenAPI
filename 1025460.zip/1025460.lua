-- Lua provided by RyzenAPI 
-- Game: Rift Racoon
addappid(1025460)
addappid(1025461, 1, "28901a02ae15d35403d547bc80818716b5112d6dc9488faf14bc96d1d988cbc2")
