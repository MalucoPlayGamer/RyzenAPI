-- Lua provided by RyzenAPI
-- Game: Rift Racoon

-- MAIN APPLICATION
addappid(1025460)
-- Game: addappid(1025460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025461, 1, "28901a02ae15d35403d547bc80818716b5112d6dc9488faf14bc96d1d988cbc2")
