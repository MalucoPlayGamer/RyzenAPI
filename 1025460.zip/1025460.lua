-- Lua provided by RyzenAPI
-- Game: Rift Racoon

-- MAIN APPLICATION
addappid(1025460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1025461, 1, "28901a02ae15d35403d547bc80818716b5112d6dc9488faf14bc96d1d988cbc2")

