-- Lua provided by RyzenAPI
-- Game: Escape Floor Zero

-- MAIN APPLICATION
addappid(2760600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2760601, 1, "2b53aba9f4ea2ce6c51e142f0d183ad2cfad67cc22b1db5a4f67b3fa6797d974")

