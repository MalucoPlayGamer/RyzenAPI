-- Lua provided by RyzenAPI
-- Game: Game: Escape Floor Zero

-- MAIN APPLICATION
addappid(2760600)
-- Game: addappid(2760600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2760601, 1, "2b53aba9f4ea2ce6c51e142f0d183ad2cfad67cc22b1db5a4f67b3fa6797d974")
