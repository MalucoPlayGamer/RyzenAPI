-- Lua provided by RyzenAPI
-- Game: Streamer Shall Not Pass!

-- MAIN APPLICATION
addappid(1191540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191541, 1, "6706723ab15d5e045bf6ae25a15651c004399be106f8d5e8990acc479d0c3c3c")
