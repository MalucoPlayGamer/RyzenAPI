-- Lua provided by RyzenAPI
-- Game: Animation Pack - Aquilon's Sex Quest

-- MAIN APPLICATION
addappid(3577740)
-- Game: addappid(3577740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3577740,0,"be966b809a1563c14b2e3d4e4c59e8d00c14a0e1c3a78c17486e910861ab3443")
