-- Lua provided by RyzenAPI
-- Game: Corpse Party (2021)

-- MAIN APPLICATION
addappid(1273260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273261, 1, "b0e8219c58134fbf1bb6f39e24d3971c35993cc0d55fb671e3a0f08342372e4f")
addappid(1273262, 1, "ee12381fca059c1266e0b20e8c633185088a7a5e718d7251cb8353dd04f2f09c")
addappid(1273263, 1, "65fc34f334f7d002c9acdc6df4a016ca985b9ab22f99fe3c87a3900fe6bdafb8")
addappid(1273264, 1, "67494afea8453c9cee0d8be4b64e92885165b97e8a2cbdc9fac3a2feec13d892")
addappid(1273265, 1, "84654cac940709cd111edcc92d7aa3540ba7b1a915661ac0c408456037b6259b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
