-- Lua provided by RyzenAPI
-- Game: AppID 2854180

-- MAIN APPLICATION
addappid(2854180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854181, 1, "281918b7b45f08ccb53636bb7fadffb889dcfad418059c671c08cfa2d086513f")

