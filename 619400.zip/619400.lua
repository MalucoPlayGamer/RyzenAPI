-- Lua provided by RyzenAPI
-- Game: AppID 619400

-- MAIN APPLICATION
addappid(619400)
-- Game: addappid(619400)

-- MAIN APP DEPOTS / PACKAGES
addappid(619401, 1, "39f0b9b25e6da9bdf4265b240264fe156b4785ecbe78b3db90f09369617eb109")
