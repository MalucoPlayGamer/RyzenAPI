-- Lua provided by RyzenAPI
-- Game: Hoversteppers

-- MAIN APPLICATION
addappid(2558930)
-- Game: addappid(2558930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2558931, 1, "2919466c4c9464d6358a4c7f570e934991c94de4aa750b1ba988072224165c34")
