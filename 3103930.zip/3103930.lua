-- Lua provided by RyzenAPI
-- Game: California Escapades

-- MAIN APPLICATION
addappid(3103930)
