-- Lua provided by RyzenAPI
-- Game: Salmon Ninja

-- MAIN APPLICATION
addappid(524050)

-- MAIN APP DEPOTS / PACKAGES
addappid(524051,0,"f195960a67c040b29df3dc50dc459d829712bbe03729dd74b1dab558d1ecf1a3")

