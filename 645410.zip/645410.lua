-- Lua provided by RyzenAPI
-- Game: Ominous Tales: The Forsaken Isle

-- MAIN APPLICATION
addappid(645410)
-- Game: addappid(645410)

-- MAIN APP DEPOTS / PACKAGES
addappid(645411, 1, "8cdb9f5795b3ace367bfdee22b23ca7d6e39b20965af26f3ffeaa0b1b154ab0f")
