-- Lua provided by RyzenAPI
-- Game: 1315070

-- MAIN APPLICATION
addappid(1315070)
-- Game: addappid(1315070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315071, 1, "d77036901e1cafb6bafe981b7ea007bfcd029645f4ed61ff0d062700ac1f6e82")
