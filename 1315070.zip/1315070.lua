-- Lua provided by RyzenAPI
-- Game: Vaccine19

-- MAIN APPLICATION
addappid(1315070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315071, 1, "d77036901e1cafb6bafe981b7ea007bfcd029645f4ed61ff0d062700ac1f6e82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
