-- Lua provided by RyzenAPI
-- Game: AppID 1564120

-- MAIN APPLICATION
addappid(1564120)
-- Game: addappid(1564120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564121, 1, "a3be6a0f70023ec6b2cc6cc5caa9632d566d777e836d2459934adc82b482c8ba")
addappid(1564123, 1, "a89611dd982df3dea13cf4c417e07485b634a48df0f94ef075d1267dc49ebecc")
