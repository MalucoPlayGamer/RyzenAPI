-- Lua provided by RyzenAPI
-- Game: AppID 710520

-- MAIN APPLICATION
addappid(710520)

-- MAIN APP DEPOTS / PACKAGES
addappid(710521, 1, "55530301aa6b365f3bfbaad97545a829f6e39030e4be3df7afc4754ff927cb66")

