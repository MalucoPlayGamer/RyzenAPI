-- Lua provided by RyzenAPI
-- Game: addappid(692690)

-- MAIN APPLICATION
addappid(692690)

-- MAIN APP DEPOTS / PACKAGES
addappid(692691, 1, "2d611db7f46162f7b97cdd5f3326fcaf725e2153fb6feebc4c45e015473885a4")
