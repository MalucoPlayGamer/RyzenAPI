-- Lua provided by RyzenAPI
-- Game: addappid(2237070)

-- MAIN APPLICATION
addappid(2237070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237072,0,"b6be93c13e86e32b2fc613a4dc38bcafa0397293431cca2448b587b4511aa75c")
