-- Lua provided by RyzenAPI
-- Game: The Cerberus Project: Horde Arena FPS

-- MAIN APPLICATION
addappid(662870)

-- MAIN APP DEPOTS / PACKAGES
addappid(662871, 1, "f2b32e9883595b4e8a611515646462233396675e28ffcd7335d295f90e529fa9")
addappid(662872, 1, "349fee11cb0bc8227180e1685bd7ef5396632997ab9bb87ec6720fcb8aa397d7")
addappid(662873, 1, "05addecbfd96bddb31309fda5111fce4bfee82b7760ba7631040f1ca467206ec")
addappid(662874, 1, "8eb5e0b59fb664121f989d58a21ee5762d6e3b7473b897495199f69e5fcd99de")

