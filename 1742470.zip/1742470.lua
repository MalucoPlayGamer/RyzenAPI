-- Lua provided by RyzenAPI
-- Game: My Newborn Life In A Harem

-- MAIN APPLICATION
addappid(1742470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742471, 1, "2143d50b695e0675ace5c8e1c6812f67563c4766ae7fc885aa8ce7fb52f699fc")

