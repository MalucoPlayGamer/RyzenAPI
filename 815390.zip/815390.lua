-- Lua provided by RyzenAPI
-- Game: Psi Cards

-- MAIN APPLICATION
addappid(815390)
addappid(828880)

-- MAIN APP DEPOTS / PACKAGES
addappid(815391, 1, "08f9aa0e125e9e69bf9db696560a29c06cbca870154eabe32a69280d8c663fa3")
