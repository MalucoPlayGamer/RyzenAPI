-- Lua provided by RyzenAPI
-- Game: 3020850

-- MAIN APPLICATION
addappid(3020850)
-- Game: addappid(3020850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020851, 1, "057fdfc3bb79fcb1abd57bd78c40cb0378c77d449264700b23969375e5a4a0b2")
