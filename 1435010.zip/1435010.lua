-- Lua provided by RyzenAPI
-- Game: Game: Succubus★Connect!

-- MAIN APPLICATION
addappid(1435010)
-- Game: addappid(1435010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435011, 1, "72bb0ce2976e4822ef63bd8e32c0d26d78a94dc53048fb1e9741799ac2a40de7")
addappid(2313150, 0, "01588a8f8764c1318f0ed0f01f3569c7614e20db30958f71cef083b7827083b9")
