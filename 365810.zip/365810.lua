-- Lua provided by RyzenAPI
-- Game: Flying Tigers: Shadows Over China

-- MAIN APPLICATION
addappid(365810)
addappid(414360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(365811, 1, "a45c28924f794898ee00335b40ea65bfa7fcc46dc4d445ef392839863d2dcc53")
addappid(366450, 0, "745bde19f7b29096b3781be688f5ee6f6aec449058c63523727803da071561f8")
