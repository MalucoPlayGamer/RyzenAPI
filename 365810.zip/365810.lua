-- Lua provided by RyzenAPI 
-- Game: AppID 365810
addappid(365810)
addappid(365811, 1, "a45c28924f794898ee00335b40ea65bfa7fcc46dc4d445ef392839863d2dcc53")
addappid(366450, 0, "745bde19f7b29096b3781be688f5ee6f6aec449058c63523727803da071561f8")
