-- Lua provided by RyzenAPI
-- Game: addappid(3246190)

-- MAIN APPLICATION
addappid(3246190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3246191, 1, "3e8d3c5368921f884b8efb0d11062e3772f6fe71b3c3e6dccd975db28ccfaa3d")
