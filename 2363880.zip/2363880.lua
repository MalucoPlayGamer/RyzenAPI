-- Lua provided by RyzenAPI
-- Game: 2363880

-- MAIN APPLICATION
addappid(2363880)
-- Game: addappid(2363880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363881, 1, "b79644fca8bc74cd923383158bf3571add465e383faad45980fca34fe45d29eb")
