-- Lua provided by RyzenAPI 
-- Game: Watchers
addappid(1124980)
addappid(1124981, 1, "5ee2572c954e3c33612402bf9c6f256df526f0da38bea57e5dde171a048f5450")
