-- Lua provided by RyzenAPI
-- Game: Watchers

-- MAIN APPLICATION
addappid(1124980)
addappid(1151660)
addappid(1151661)
addappid(1166410)
addappid(1186610)
addappid(1205000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124981,0,"5ee2572c954e3c33612402bf9c6f256df526f0da38bea57e5dde171a048f5450")

