-- Lua provided by RyzenAPI
-- Game: addappid(1124980)

-- MAIN APPLICATION
addappid(1124980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124981, 1, "5ee2572c954e3c33612402bf9c6f256df526f0da38bea57e5dde171a048f5450")
