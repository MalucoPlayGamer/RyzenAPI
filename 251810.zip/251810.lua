-- Lua provided by RyzenAPI
-- Game: Game: AppID 251810

-- MAIN APPLICATION
addappid(251810)
-- Game: addappid(251810)

-- MAIN APP DEPOTS / PACKAGES
addappid(251811, 1, "862a3669096e33870ac99f637a81891567be6f861c86c2bcf75675244a5a7e16")
