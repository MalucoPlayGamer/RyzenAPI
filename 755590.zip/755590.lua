-- Lua provided by RyzenAPI
-- Game: Battle High 2 A+

-- MAIN APPLICATION
addappid(755590)

-- MAIN APP DEPOTS / PACKAGES
addappid(755591, 1, "85a3fca4c6ccae395d70c3e14806e0baaf3194395232040ea53ae260f153c2c9")
