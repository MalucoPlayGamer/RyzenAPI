-- Lua provided by RyzenAPI
-- Game: 1914020

-- MAIN APPLICATION
addappid(1914020)
-- Game: addappid(1914020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914021, 1, "eb019238bc186760bf4ba021b2862ce5446fd948f5c7dd8e1ccd779fe5745eea")
