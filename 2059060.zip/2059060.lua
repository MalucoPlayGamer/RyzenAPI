-- Lua provided by RyzenAPI
-- Game: addappid(2059060)

-- MAIN APPLICATION
addappid(2059060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059061, 1, "8431a7d57a9356af919a686e3aaf6ffb2a3762856efd5907a3d0c810df5482d1")
