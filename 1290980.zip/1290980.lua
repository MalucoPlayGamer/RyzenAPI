-- Lua provided by RyzenAPI
-- Game: Extra Coin

-- MAIN APPLICATION
addappid(1290980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290981, 1, "f9903015cbc6a1a0f42622b510da42741c2a6b8a34fb95cc33838c7107332d51")
