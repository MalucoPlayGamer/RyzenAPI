-- Lua provided by RyzenAPI
-- Game: The Adventures of MICOCO

-- MAIN APPLICATION
addappid(1909270)
-- Game: addappid(1909270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909271, 1, "e44811a30b15095f9690dfd93c62a75f89ed5a00126771c62a35274ff59d3aad")
addappid(1909273, 1, "44df2a194d68bd434120e05460a67ea1accd7f04b6b60b9f6b38bd4a2933a53a")
addappid(1909274, 1, "2a951d30545b6335455e51d6907ae732c8d1d0deedfe4e864121862cad8fc6e7")
