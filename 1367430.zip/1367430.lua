-- Lua provided by RyzenAPI
-- Game: Furry Woof and Nya

-- MAIN APPLICATION
addappid(1367430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367431, 1, "2e062c52c291efe4d10a2d3317f1249355a955cd93ac83aead21254784e2f911")

