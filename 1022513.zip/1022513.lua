-- Lua provided by RyzenAPI
-- Game: DFF NT: Crimson Blitz, Lightning's 4th Weapon

-- MAIN APPLICATION
addappid(1022513)
-- Game: addappid(1022513)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022513,0,"ab7dfc6574da8282d364a0468a71e4860e6376a911f51145ec587abc730011af")
