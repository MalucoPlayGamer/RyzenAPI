-- Lua provided by SkyAPI 
-- Game: Projected Dreams Soundtrack
addappid(3628860)
addappid(3628861, 1, "48dbe51fca9761665aacce08179390c4d630b94e58554b3c7916e623a5885fc8")
addappid(3628862, 1, "766dc3be70233a9dceed45e0843d8945e1f63cd5c3c0d048d1c4fa23a01cddd5")
