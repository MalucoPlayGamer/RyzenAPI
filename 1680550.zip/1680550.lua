-- Lua provided by RyzenAPI
-- Game: Impact Point

-- MAIN APPLICATION
addappid(1680550)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2054720)
