-- Lua provided by RyzenAPI
-- Game: Impact Point

-- MAIN APPLICATION
addappid(1680550)

