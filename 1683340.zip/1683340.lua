-- Lua provided by RyzenAPI
-- Game: Kayak VR: Mirage

-- MAIN APPLICATION
addappid(1683340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683341, 1, "8b6ef18be7308345993f5f17a40a8dcd8c78c73bf42a79a4180abbf3e7a537d6")
addappid(2926750, 0, "1278d96e72cd6ddb2e72c4cd853d93a1166b341a0504b7bba89fbe25132c2e3b")
addappid(3437140, 0, "409befe7c1d9107de4f307e09ee998ecdc3b69f4596f2077d91e63ebfcededfe")

