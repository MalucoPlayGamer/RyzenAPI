-- Lua provided by RyzenAPI
-- Game: Idylls of the Lunar Maria Demo

-- MAIN APPLICATION
addappid(2891440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891441, 1, "fa62dcf0580861637c740639431b4a87199b35623467377e420b079dedd720f3")
