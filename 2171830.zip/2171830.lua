-- Lua provided by RyzenAPI
-- Game: addappid(2171830)

-- MAIN APPLICATION
addappid(2171830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171831, 1, "0ac5a583be4f5f15b84e0008e11d093d9d30e9e0ae4cf3f700dc32e755928880")
