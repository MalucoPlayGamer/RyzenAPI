-- Lua provided by RyzenAPI
-- Game: 8380

-- MAIN APPLICATION
addappid(8380)
-- Game: addappid(8380)

-- MAIN APP DEPOTS / PACKAGES
addappid(8381, 1, "7808b190e01167730fa7589b56143adb62bcf7247cf069f5152b289f4e560756")
addappid(8382, 1, "041c73c5f71e059317ff10f3209c1ac8b2039d8b3fe056cd71ad8b57dfbb88d2")
