-- Lua provided by RyzenAPI
-- Game: Game: PCMark 10 Demo

-- MAIN APPLICATION
addappid(524410)
-- Game: addappid(524410)

-- MAIN APP DEPOTS / PACKAGES
addappid(524411, 1, "d65addd9c7387fd083ac04b9ffa974bdd0f2a4ecd624c6b1708c95091965d865")
