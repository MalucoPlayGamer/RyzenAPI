-- Lua provided by RyzenAPI 
-- Game: PCMark 10 Demo
addappid(524410)
addappid(524411, 1, "d65addd9c7387fd083ac04b9ffa974bdd0f2a4ecd624c6b1708c95091965d865")
