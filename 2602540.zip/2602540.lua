-- Lua provided by RyzenAPI
-- Game: Game: Once Upon a Rogue's Tale

-- MAIN APPLICATION
addappid(2602540)
-- Game: addappid(2602540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602541, 1, "2d16d73285d5ae83fe659ddeae5142dd9eebd0e964de61cc2b5a8d5aabdf25cf")
