-- Lua provided by RyzenAPI
-- Game: 1323410

-- MAIN APPLICATION
addappid(1323410)
-- Game: addappid(1323410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323411, 1, "0f13955a59e7082cae5fb810ca49d65ba242aae14e789a462618b0d8bcb2ec81")
