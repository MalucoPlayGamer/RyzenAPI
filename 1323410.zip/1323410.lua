-- Lua provided by RyzenAPI 
-- Game: AppID 1323410
addappid(1323410)
addappid(1323411, 1, "0f13955a59e7082cae5fb810ca49d65ba242aae14e789a462618b0d8bcb2ec81")
