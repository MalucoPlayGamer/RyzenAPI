-- Lua provided by RyzenAPI
-- Game: 3DMark Demo

-- MAIN APPLICATION
addappid(231350)
-- Game: addappid(231350)

-- MAIN APP DEPOTS / PACKAGES
addappid(231351, 1, "ea967aec25f5d98458c97f13d4eb7a66593415e13426917b37c2c3401ed73d0b")
addappid(496106, 0, "6ea0283e4e59b867500f3a10bffbf76ddc462694f60eec5c36a701679f60afbf")
