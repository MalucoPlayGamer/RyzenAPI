-- Lua provided by SkyAPI 
-- Game: AppID 422020
addappid(422020)
addappid(422021, 1, "4f97e4363cf8160cdd84f04ff7c157728f85a6599986c49f42d87c1136e4fc60")
