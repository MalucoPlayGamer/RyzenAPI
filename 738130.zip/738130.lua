-- Lua provided by RyzenAPI
-- Game: Get Dis Money

-- MAIN APPLICATION
addappid(738130)
addappid(787000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(738132,0,"8d7be5ef4ad590e86bab5161a900a69e5e2d35e3e38ee1a6bcafb4b28933f57b")

