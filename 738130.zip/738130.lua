-- Lua provided by RyzenAPI
-- Game: addappid(738130)

-- MAIN APPLICATION
addappid(738130)

-- MAIN APP DEPOTS / PACKAGES
addappid(738132,0,"8d7be5ef4ad590e86bab5161a900a69e5e2d35e3e38ee1a6bcafb4b28933f57b")
