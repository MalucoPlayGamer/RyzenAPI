-- Lua provided by RyzenAPI
-- Game: Sker Ritual

-- MAIN APPLICATION
addappid(1492070)
-- Game: addappid(1492070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492071, 1, "89d465584a0a654f8213c804ff69c907155ed9ba69bbe5084776845eea29f048")
addappid(1492072, 1, "8c2b060c707e577e5e85f7abc85ee02e0c79c268e7daab9adcb32041b17b5641")
