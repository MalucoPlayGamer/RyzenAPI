-- Lua provided by RyzenAPI
-- Game: Sker Ritual

-- MAIN APPLICATION
addappid(2155330) -- Sker Ritual - Draigs Terror
addappid(2155340) -- Sker Ritual - Friends in the Darkness
addappid(2237020) -- Sker Ritual - Goon Brenn
addappid(2237021) -- Sker Ritual - The Quiet Ones
addappid(2323210) -- Sker Ritual - Stranger Danger
addappid(2323211) -- Sker Ritual - Sirens Song
addappid(2434170) -- Sker Ritual - Smugglers Fortune
addappid(2434171) -- Sker Ritual - Devils Sacrifice
addappid(2695180) -- Sker Ritual - Headless Wanderer
addappid(2702210) -- Sker Ritual - Murder Express
addappid(2715950) -- Sker Ritual - Bloody Night
addappid(3047450) -- Sker Ritual - Skerville Slasher
addappid(3102160) -- Sker Ritual - Dead by Nightfall
addappid(3201960) -- Sker Ritual - Invasion of the Brain Eaters
addappid(4031760) -- Sker Ritual - Hazard Levels
addappid(5038510) -- Sker Ritual - Inferno Upgrade

-- MAIN APP DEPOTS / PACKAGES
addappid(1492070, 1, "9c84b0312d5ce09e10b4b6aa63010c05c47028458a98b1614ce97d7f8ed2f2c1") -- Sker Ritual
addappid(1492071, 1, "89d465584a0a654f8213c804ff69c907155ed9ba69bbe5084776845eea29f048") -- Depot 1492071
addappid(1492072, 1, "8c2b060c707e577e5e85f7abc85ee02e0c79c268e7daab9adcb32041b17b5641") -- Depot 1492072

