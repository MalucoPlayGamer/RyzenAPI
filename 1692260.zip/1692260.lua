-- Lua provided by RyzenAPI
-- Game: Xuan-Yuan Sword: The Scar of Sky OST

-- MAIN APPLICATION
addappid(1692260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692261, 1, "8c97d59b7ea642062572c83d65735f28698ffced4402d2d5d1ce7467ec1b5644")
addappid(1692262, 1, "e9e03d8b8ca899c330aec95915f783dde70dc9080ec7fb0f28648b444fe4be9f")

