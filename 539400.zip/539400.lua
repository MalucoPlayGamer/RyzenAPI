-- Lua provided by RyzenAPI
-- Game: addappid(539400)

-- MAIN APPLICATION
addappid(539400)

-- MAIN APP DEPOTS / PACKAGES
addappid(539401, 1, "962b78e806dd41848bb223ab6bff399d6b82942acbda8aee71c0f1a7f61e0e34")
addappid(539403, 1, "4b0e4079135b2e26e4547619e25c3ab4abe563de9e278cc403e1f6ef1844ea73")
