-- Lua provided by RyzenAPI
-- Game: ENTROPOLY

-- MAIN APPLICATION
addappid(2226160)
-- Game: addappid(2226160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226161, 1, "9ad7cab2ccbcef580cc21ef5923e7790e92d65eb19682e175727f4015cae5280")
