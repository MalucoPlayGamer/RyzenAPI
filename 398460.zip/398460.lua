-- Lua provided by RyzenAPI
-- Game: addappid(398460)

-- MAIN APPLICATION
addappid(398460)

-- MAIN APP DEPOTS / PACKAGES
addappid(398461, 1, "5898a9d7627441d70ecc2c8ef8ec6df3ed99313061e626c879fd4703f5730c9d")
