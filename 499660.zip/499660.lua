-- Lua provided by RyzenAPI
-- Game: Medieval Kingdom Wars

-- MAIN APPLICATION
addappid(499660)
-- Game: addappid(499660)

-- MAIN APP DEPOTS / PACKAGES
addappid(499661, 1, "78ec6286e1984d201c75528375fb7a50cad0659226d399b2d30ccbc776e07853")
addappid(2110750, 0, "675ea1ce1f727a2df9440ab6a602f826726957041be287319481cebca96fe8fa")
addappid(2155290, 0, "cceb71d24e036c2d44e082611f90ae0d7e8e2e151f4a396b9de5886c4e2231d8")
addappid(2431010, 0, "688e0151ec52c82eb6a9dcb9506765c07e3d80e323db7e5ee23d5cfaa7ec55e3")
