-- Lua provided by RyzenAPI
-- Game: addappid(2189860)

-- MAIN APPLICATION
addappid(2189860)
addappid(2189861)
addappid(2189863)

-- MAIN APP DEPOTS / PACKAGES
addappid(2189862,0,"167c5cc69c94faa17d69cfe16e7877426cb935eb4fbf8418149a2465fdae65fa")
