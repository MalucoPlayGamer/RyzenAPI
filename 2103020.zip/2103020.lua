-- Lua provided by RyzenAPI
-- Game: Frightened

-- MAIN APPLICATION
addappid(2103020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103021, 1, "4e4b4f4c64ff9bf1b2106b7f8bdf26d33ae3c34094d8c07a846cea1f4d62fc39")

