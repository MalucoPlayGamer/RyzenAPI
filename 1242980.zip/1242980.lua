-- Lua provided by RyzenAPI
-- Game: KeyWe

-- MAIN APPLICATION
addappid(1242980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242981, 1, "c4ff3a18b74e7013d0def2c2719d68c7705c071c3ddbf860a3631fcfb8d81659")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1728650)
addappid(1873760)
