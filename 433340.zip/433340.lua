-- Lua provided by RyzenAPI
-- Game: AppID 433340

-- MAIN APPLICATION
addappid(433340)

-- MAIN APP DEPOTS / PACKAGES
addappid(433341, 1, "02404d4d6e218a526def6e05f322a0510bcc1199addaa52610cc21258bf0a574")
addappid(433342, 1, "064d5b0bceb825d1a92db63ac6df94ab7765a45943098ea6af90bd09f5305498")
addappid(433343, 1, "5e5f51850ece04988ceff04c7b3bedd6f2e617e1a7e707e9cba06a89f8d3570d")
addappid(433344, 1, "3fb5cef87b8f8a4684a476b8d7429b100117e1bd76a4961e168c98d036422e10")
addappid(939480, 0, "791322ae7ba59474f3e7faea093783d42597e0dc27c5dd3d1c5325f57cccc6b6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(982310)
addappid(1079180)
