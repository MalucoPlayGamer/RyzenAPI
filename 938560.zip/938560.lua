-- Lua provided by RyzenAPI
-- Game: INMOST

-- MAIN APPLICATION
addappid(938560)

-- MAIN APP DEPOTS / PACKAGES
addappid(938561, 1, "8db38f9c3ba3479d346f2aaf73f1862a2b8425fcb4ba76206f0f5a87489a2362")
addappid(938562, 1, "bce617f5fcf1c6dff333c520e5a6c70543239c9e2cad8449fd7923bd7dd2ada9")

