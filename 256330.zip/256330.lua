-- Lua provided by RyzenAPI
-- Game: 256330

-- MAIN APPLICATION
addappid(256330)
-- Game: addappid(256330)

-- MAIN APP DEPOTS / PACKAGES
addappid(256331, 1, "316a6b1f639d6397f5f1a93e287d0a73d360ad1a793ac1dbc7d5135e0f4387c9")
