-- Lua provided by RyzenAPI
-- Game: Flying Flogger

-- MAIN APPLICATION
addappid(1537090)
-- Game: addappid(1537090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537091, 1, "98c369a07e560b8814284f6757f1a27de590f67ca192df9c03b93b606b60809a")
