-- 3592710's Lua and Manifest Created by Hubcap Manifest
-- Neon Striker
-- Created: August 15, 2026 at 03:15:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3592710, 1, "65c8e5f7d7a580ab79a58190cec66dddaf65f752d27f6400b0477e2e0e76bf38") -- Neon Striker
-- MAIN APP DEPOTS
addappid(3592711, 1, "ed265adf651b08008c066172fa1b84ea61b0057b9f6285f687e063845fc52147") -- Depot 3592711
setManifestid(3592711, "9032422219450349079", 553504807)
addappid(3592712, 1, "03493ba3bf20ed73447f20c9c1e55c781a2340b832725435b51a141c59fb3fca") -- Depot 3592712
setManifestid(3592712, "4453834633301047331", 753357368)
addappid(3592713, 1, "d2964950de8f2ae973fa7e0b2a10d9920ce0e54a58031b99e92f32ab9bc98e52") -- Depot 3592713
setManifestid(3592713, "9034428326917826366", 530880155)