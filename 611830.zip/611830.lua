-- Lua provided by RyzenAPI
-- Game: addappid(611830)

-- MAIN APPLICATION
addappid(611830)

-- MAIN APP DEPOTS / PACKAGES
addappid(611831, 1, "d06b45d139c8b69290b1a4bf65ba743ab2aa4e749421f00efa4d5f0ba07c4d79")
addappid(611832, 1, "72a9e19ffbf9ca42f1127902278ed6e9a80076b2ef820d6f24f3192dcd35da06")
addappid(611835, 1, "aa76f5d938a2db30871fa7db2105faaa0d6cba41e6bb2c3282c890b647945e32")
