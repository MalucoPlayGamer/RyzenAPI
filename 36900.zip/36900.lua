-- Lua provided by RyzenAPI
-- Game: addappid(36900)

-- MAIN APPLICATION
addappid(36900)

-- MAIN APP DEPOTS / PACKAGES
addappid(36901, 1, "23ebbe1cb12478ce624544a59e0b3d9365ecbd672366e7deb19a4b084fc9a8ba")
