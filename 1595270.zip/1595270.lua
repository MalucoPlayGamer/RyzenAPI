-- Lua provided by RyzenAPI
-- Game: NOREN

-- MAIN APPLICATION
addappid(1595270)
-- Game: addappid(1595270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595271, 1, "5fb78b31a84150719dba64988aee1805a2c5f8abfefb1792043df661f4ae980b")
