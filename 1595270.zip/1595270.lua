-- Lua provided by RyzenAPI 
-- Game: NOREN
addappid(1595270)
addappid(1595271, 1, "5fb78b31a84150719dba64988aee1805a2c5f8abfefb1792043df661f4ae980b")
