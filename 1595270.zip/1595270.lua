-- Lua provided by RyzenAPI
-- Game: NOREN

-- MAIN APPLICATION
addappid(1595270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595271, 1, "5fb78b31a84150719dba64988aee1805a2c5f8abfefb1792043df661f4ae980b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
