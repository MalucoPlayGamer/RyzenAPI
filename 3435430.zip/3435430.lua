-- Lua provided by RyzenAPI
-- Game: I'm Caught in a Time Loop: I Need to Find a Girl as Soon as Possible

-- MAIN APPLICATION
addappid(3435430)
-- Game: addappid(3435430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3435431, 1, "38df295af0065e033bfc41289f7264b46d29cbccd63f263268e15d98601d284e")
