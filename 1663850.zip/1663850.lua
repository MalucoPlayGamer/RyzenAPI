-- Lua provided by RyzenAPI
-- Game: Game: REPLACED

-- MAIN APPLICATION
addappid(1663850)
-- Game: addappid(1663850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663851, 1, "6c5ad07d24ba971709a2773ed2263ddc46bf21f9a2608989ef9438668db72760")
