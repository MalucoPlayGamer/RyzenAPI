-- Lua provided by RyzenAPI 
-- Game: REPLACED
addappid(1663850)
addappid(1663851, 1, "6c5ad07d24ba971709a2773ed2263ddc46bf21f9a2608989ef9438668db72760")
