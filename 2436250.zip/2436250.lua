-- Lua provided by RyzenAPI
-- Game: Game: Case 03: True Cannibal Boy Demo

-- MAIN APPLICATION
addappid(2436250)
-- Game: addappid(2436250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436251, 1, "562b331296d186f52f4fffab7c75f05856101b3ab5305c9470c9174349020ee2")
