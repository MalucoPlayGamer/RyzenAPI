-- Lua provided by RyzenAPI
-- Game: Gearbits: Test site

-- MAIN APPLICATION
addappid(3174600)
addappid(3174601)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989881,0,"9c51f44bcb1031e78d04a8e4b95f0bf0bb4644df69cfb6150227ea84bd30cba6")
addappid(2989882,0,"ce505763a9f22e8e422c473800ad7b9711661fcd3b3f73704ede3d2d48d7380e")
