-- Lua provided by RyzenAPI
-- Game: Umurangi Generation

-- MAIN APPLICATION
addappid(1223500)
-- Game: addappid(1223500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223501, 1, "91b6d957c063ce0a7d5c48914dbc0a4e20081d5c0ef2a62a56098490889d6bc0")
addappid(1435580, 0, "29a3ac57af3bac830cd863cbb0205d0efe3fe34008310041186a370af31dffb2")
