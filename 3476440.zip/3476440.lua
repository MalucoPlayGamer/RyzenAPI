-- Lua provided by RyzenAPI
-- Game: 3476440

-- MAIN APPLICATION
addappid(3476440)
-- Game: addappid(3476440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3476441, 1, "2e51e5d35a9a7282d2df9008de10de350c88b48e15c3188f7c1cf67b23a0ed9a")
