-- Lua provided by RyzenAPI
-- Game: Game: AppID 228040

-- MAIN APPLICATION
addappid(228040)
-- Game: addappid(228040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228041, 1, "fc997fa3ef98c94dcbe7a83e28dca3d4020c9603f20327127b49448d3b17174d")
