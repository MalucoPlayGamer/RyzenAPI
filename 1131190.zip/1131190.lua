-- Lua provided by RyzenAPI
-- Game: AppID 1131190

-- MAIN APPLICATION
addappid(1131190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131191, 1, "fe3682850fb9a4a52955d15eb8fc1fcebe6cb36272a45923dbd19d2d5d3ca914")
addappid(1131192, 1, "07c52eb247d7100ef9d7083ea3efbe28f55c312bf08a4422be95f13318087344")
addappid(1131193, 1, "bf2556fc78b536fbc5b8f099f5a2497e99c80f4c4aa7d5595d6721a302582783")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1541260)
