-- Lua provided by RyzenAPI
-- Game: Storybook of Tactics

-- MAIN APPLICATION
addappid(2511340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511341, 1, "4f0c6ca64a9b98067a47e22b00e951d8122f2ec9582687caa542cd828dbd3dc5")

