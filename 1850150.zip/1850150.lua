-- Lua provided by RyzenAPI
-- Game: addappid(1850150)

-- MAIN APPLICATION
addappid(1850150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850151, 1, "95a4504dd8a64307bb6b157539d9d72b54b1e5c42c75e2ce2999e8864c4d951b")
