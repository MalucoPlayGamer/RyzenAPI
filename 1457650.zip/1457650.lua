-- Lua provided by RyzenAPI
-- Game: 幻想三国志4

-- MAIN APPLICATION
addappid(1457650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1457651, 1, "13adc3fe4254058689d42a6583cf132cac6b0d123deea09ef4d3aa62364b0c95")
addappid(1457652, 1, "1eb57dc93d7756523820414a941877c1a636a831c3b43f692a1afff5e84bfdc9")

