-- Lua provided by RyzenAPI
-- Game: 1431850

-- MAIN APPLICATION
addappid(1431850)
-- Game: addappid(1431850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431851, 1, "9eb6a7a425663aafdefcf2806e261b9584ac01349ee5e2f245fa41012695cb06")
