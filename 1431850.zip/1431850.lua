-- Lua provided by RyzenAPI 
-- Game: The Tartarus Key
addappid(1431850)
addappid(1431851, 1, "9eb6a7a425663aafdefcf2806e261b9584ac01349ee5e2f245fa41012695cb06")
