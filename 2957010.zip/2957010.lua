-- Lua provided by RyzenAPI
-- Game: addappid(2957010)

-- MAIN APPLICATION
addappid(2957010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957013,0,"fe8cae7ce21176890cfaeaf1b228562b2eac42f72dbf5b2505015b9801cf3586")
