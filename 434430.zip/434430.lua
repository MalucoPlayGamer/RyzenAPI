-- Lua provided by RyzenAPI
-- Game: Abbot's Book Demo

-- MAIN APPLICATION
addappid(434430)

-- MAIN APP DEPOTS / PACKAGES
addappid(434431, 1, "59b677a2108d6a3d913955cc1a8834ded572ff809aef94b35f55c40704503b80")
