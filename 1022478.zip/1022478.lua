-- Lua provided by RyzenAPI
-- Game: DFF NT: Lucent Robe Appearance Set for Cloud of Darkness

-- MAIN APPLICATION
addappid(1022478)
-- Game: addappid(1022478)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022478,0,"ec4bc59b1e7eff44b2c02727b82e154b71c6332724e99203132b76006bbe0e80")
