-- Lua provided by RyzenAPI
-- Game: Partum Artifex

-- MAIN APPLICATION
addappid(2069760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069761, 1, "93f5b0c3183d7a3cfb10d96a1a0d91296c4f9fe296cfee9f0325c724d7c3a6c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
