-- Lua provided by RyzenAPI
-- Game: 2069760

-- MAIN APPLICATION
addappid(2069760)
-- Game: addappid(2069760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069761, 1, "93f5b0c3183d7a3cfb10d96a1a0d91296c4f9fe296cfee9f0325c724d7c3a6c4")
