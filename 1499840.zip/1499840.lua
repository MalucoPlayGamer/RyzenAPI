-- Lua provided by RyzenAPI
-- Game: addappid(1499840)

-- MAIN APPLICATION
addappid(1499840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499841, 1, "7d66701196abe92daffd631261030927e1beee2ab144bed05bcd3033cd9b071e")
