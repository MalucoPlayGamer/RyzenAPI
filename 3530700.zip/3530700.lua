-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in Orlando

-- MAIN APPLICATION
addappid(3530700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3530701, 1, "2fc0dcec15376bf687822acdfba4e9e3d052d99414ad14fbd3d2957ec24539bd")
