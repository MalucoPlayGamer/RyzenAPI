-- Lua provided by RyzenAPI
-- Game: AppID 869060

-- MAIN APPLICATION
addappid(869060)

-- MAIN APP DEPOTS / PACKAGES
addappid(869061, 1, "e49e427c6f3d7cc90d2282dfe3854f1898440a16204cfaf95d128fae0ee6ac39")
