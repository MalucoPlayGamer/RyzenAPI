-- Lua provided by RyzenAPI 
-- Game: AppID 3193000
addappid(3193000)
addappid(3193001, 1, "38202029b3812ef0004e6d13298d6687cd04018ff940614d5e896350338a882e")
