-- Lua provided by RyzenAPI
-- Game: Awaken: Hentai Dice - Wallpaper Pack

-- MAIN APPLICATION
addappid(3296940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296940,0,"bed706587164d7911a7055c5b0b3e1d508d59aedd99b91cd0713014b8cc22074")

