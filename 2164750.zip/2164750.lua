-- Lua provided by SkyAPI 
-- Game: Kai Yuan
addappid(2164750)
addappid(2164751, 1, "82952d21749b90e371582f181f3cedccf11566b5fe7a01714be7f537ca215cfc")
