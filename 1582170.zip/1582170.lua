-- Lua provided by RyzenAPI
-- Game: Knockout City™ Trial

-- MAIN APPLICATION
addappid(1582170)
-- Game: addappid(1582170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582171, 1, "8f68b57c4c9cedd00f917b58d70c7c2a55fa24e09aed2e1666d278ec62ebb4e9")
