-- Lua provided by RyzenAPI
-- Game: Maid Harem With Futa

-- MAIN APPLICATION
addappid(1828970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828971, 1, "fe614635709ca46b4af8fcc18298f22e1642edbec58506a0d6e1ece13ca39f7e")

