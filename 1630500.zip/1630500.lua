-- Lua provided by RyzenAPI
-- Game: 1630500

-- MAIN APPLICATION
addappid(1630500)
-- Game: addappid(1630500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630501, 1, "a3cef1ee775e03cab13711a0a52da242107428668089a3589d53f6c807d4fae2")
