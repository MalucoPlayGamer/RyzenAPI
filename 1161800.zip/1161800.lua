-- Lua provided by RyzenAPI
-- Game: URO2

-- MAIN APPLICATION
addappid(1161800)
addappid(1169680)
-- Game: addappid(1161800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161801, 1, "bcdb907f0e8ac736423894d08c4ef023c23b0861983bd550c79d7264d8223c0c")
