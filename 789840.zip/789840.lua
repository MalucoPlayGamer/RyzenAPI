-- Lua provided by RyzenAPI
-- Game: A Dream of Burning Sand

-- MAIN APPLICATION
addappid(789840)

-- MAIN APP DEPOTS / PACKAGES
addappid(789841,0,"32d8135eeccca7e3d7e093d3b850fb73e7fee1fce55aa93a9ea1f3adbd0a4a5e")
addappid(789842,0,"dcdf5e386e133e150a19bca26fc08ea71145682cfb36d2b3e58f6995ae0a3d60")
addappid(789843,0,"ad833ceb2e0fe9e0a5c82a52b7ed0c93b72d6253760d100077226e76ab53b535")

