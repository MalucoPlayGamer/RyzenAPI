-- Lua provided by RyzenAPI
-- Game: Game: Tall Poppy

-- MAIN APPLICATION
addappid(1814770)
-- Game: addappid(1814770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814771, 1, "0dd42796db8552c965c474f91d532144d04b8c901dff05f787464fcc86104c79")
