-- Lua provided by RyzenAPI
-- Game: Tall Poppy

-- MAIN APPLICATION
addappid(1814770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1814771, 1, "0dd42796db8552c965c474f91d532144d04b8c901dff05f787464fcc86104c79")

