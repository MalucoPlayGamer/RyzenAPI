-- Lua provided by RyzenAPI
-- Game: 失落的猫猫 Lost Cat

-- MAIN APPLICATION
addappid(2679060)
-- Game: addappid(2679060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679061, 1, "ae3ca86bf7aa3cbca5d2f8c57f06030a938ccc437ad01b5950cec8d8bfb5edbc")
