-- Lua provided by RyzenAPI
-- Game: 失落的猫猫 Lost Cat

-- MAIN APPLICATION
addappid(2679060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679061, 1, "ae3ca86bf7aa3cbca5d2f8c57f06030a938ccc437ad01b5950cec8d8bfb5edbc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
