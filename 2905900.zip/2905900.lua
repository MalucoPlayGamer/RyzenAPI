-- Lua provided by RyzenAPI
-- Game: PIRORO

-- MAIN APPLICATION
addappid(2905900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2905901, 1, "00502810bbbe5e981961335042aba95ffd17a8fcbc46c9ebe816b66c9be048da")

