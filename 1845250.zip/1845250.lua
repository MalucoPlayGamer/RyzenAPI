-- 1845250's Lua and Manifest Created by Hubcap Manifest
-- Rubinite
-- Created: July 23, 2026 at 02:19:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1845250) -- Rubinite
-- MAIN APP DEPOTS
addappid(1845251, 1, "25598ffd90253ab700d539a8bff576b1cb82853b6dea1bc4ca8d74e368b07f3c") -- Depot 1845251
setManifestid(1845251, "8839028081984041681", 4333441465)