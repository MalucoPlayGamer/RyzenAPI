-- Lua provided by RyzenAPI
-- Game: Rubinite

-- MAIN APPLICATION
addappid(1845250) -- Rubinite

-- MAIN APP DEPOTS / PACKAGES
addappid(1845251, 1, "25598ffd90253ab700d539a8bff576b1cb82853b6dea1bc4ca8d74e368b07f3c") -- Depot 1845251

