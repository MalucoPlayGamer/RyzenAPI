-- Lua provided by RyzenAPI
-- Game: Ricochet

-- MAIN APPLICATION
addappid(1824450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824451, 1, "83b0265679273634276e6c70320c61dd1dfcd16cb55c381ddd71ea8e761200ab")
addappid(1844970, 0, "4a2e4e114b985a5477e9e6bb951a9973ed8d31f414646e175b823320c72dc7be")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1854550)
