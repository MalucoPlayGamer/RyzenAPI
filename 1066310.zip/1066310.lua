-- Lua provided by RyzenAPI
-- Game: AppID 1066310

-- MAIN APPLICATION
addappid(1066310)
-- Game: addappid(1066310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066311, 1, "8c355e397a7d76c071cd5776e01a3d96298dd5424c0fa42003a0f408a66dedcc")
