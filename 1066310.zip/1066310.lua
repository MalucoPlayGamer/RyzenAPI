-- Lua provided by RyzenAPI
-- Game: OFFSIDE

-- MAIN APPLICATION
addappid(1066310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1066311, 1, "8c355e397a7d76c071cd5776e01a3d96298dd5424c0fa42003a0f408a66dedcc")

