-- Lua provided by SkyAPI 
-- Game: Commander: Modern War
addappid(2214890)
addappid(2214891, 1, "1bc5de05294e9cc82fc2150557a8b4c2e8ec0f16a9ee50db43ed4de27916b37c")
