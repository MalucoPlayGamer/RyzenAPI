-- Lua provided by RyzenAPI
-- Game: Game: Darker : Episode I

-- MAIN APPLICATION
addappid(1543810)
-- Game: addappid(1543810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543811, 1, "eed48d5bafb66d383e63e1c9320952f21e326327977e60f566122c17d3ac4783")
