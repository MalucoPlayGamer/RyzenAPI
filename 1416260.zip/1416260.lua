-- Lua provided by RyzenAPI
-- Game: AppID 1416260

-- MAIN APPLICATION
addappid(1416260)
addappid(1460150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1416261, 1, "3b47506058af9bb7b8a7d8afe36b6dd2dc96eb3cb9f6f2dc1f685c01c5742b31")
addappid(1416262, 1, "b7d347592ba2491886539f1b60ea873031a2718bb59913845176686fbfeffec4")
addappid(1416264, 1, "0cb70b51c7cbf77d58f5859fd3c4bd6f7000231699db6588e2b68ca4b331c228")

