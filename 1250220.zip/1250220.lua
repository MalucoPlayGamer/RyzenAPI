-- Lua provided by RyzenAPI
-- Game: Fallen Region

-- MAIN APPLICATION
addappid(1250220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250221, 1, "1e95b431cf0d8e185f8f3a09259b5e1b3f7d984e280b80b887879b7feef48bb3")

