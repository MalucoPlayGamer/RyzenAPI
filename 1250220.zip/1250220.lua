-- Lua provided by RyzenAPI
-- Game: Fallen Region

-- MAIN APPLICATION
addappid(1250220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1250221, 1, "1e95b431cf0d8e185f8f3a09259b5e1b3f7d984e280b80b887879b7feef48bb3")

