-- Lua provided by RyzenAPI
-- Game: AppID 423740

-- MAIN APPLICATION
addappid(423740)

-- MAIN APP DEPOTS / PACKAGES
addappid(423741, 1, "254c1590f6c348618853d04929171b0a80686055a2d09d291828f1624721f2be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
