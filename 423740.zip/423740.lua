-- Lua provided by SkyAPI 
-- Game: AppID 423740
addappid(423740)
addappid(423741, 1, "254c1590f6c348618853d04929171b0a80686055a2d09d291828f1624721f2be")
