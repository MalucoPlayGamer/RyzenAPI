-- Lua provided by RyzenAPI
-- Game: Besmirch

-- MAIN APPLICATION
addappid(3670630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3670631,0,"9269f1f2b5c6e5660c249589b666e61fb24603e4b0a161fd5024d804a2be2a06")

