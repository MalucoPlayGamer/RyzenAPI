-- Lua provided by RyzenAPI 
-- Game: AppID 1744790
addappid(1744790)
addappid(1744791, 1, "a09468d15c4b2994550018d662ff6fe3e33221b9dec4f4d33f205f9346531563")
