-- Lua provided by RyzenAPI
-- Game: Match Three Pirates II

-- MAIN APPLICATION
addappid(1744790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744791, 1, "a09468d15c4b2994550018d662ff6fe3e33221b9dec4f4d33f205f9346531563")
