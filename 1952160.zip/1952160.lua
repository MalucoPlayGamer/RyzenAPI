-- Lua provided by RyzenAPI
-- Game: Game: March to a Million

-- MAIN APPLICATION
addappid(1952160)
-- Game: addappid(1952160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952161, 1, "00b9c9c69758625f5d83aeafe3ccb40e185529ce0b0c1b42d1b63014041c2be0")
