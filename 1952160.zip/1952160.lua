-- Lua provided by SkyAPI 
-- Game: March to a Million
addappid(1952160)
addappid(1952161, 1, "00b9c9c69758625f5d83aeafe3ccb40e185529ce0b0c1b42d1b63014041c2be0")
