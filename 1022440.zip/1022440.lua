-- Lua provided by RyzenAPI
-- Game: addappid(1022440)

-- MAIN APPLICATION
addappid(1022440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022440,0,"fc8fc2ba7d9fcda184013a334d7706b31cfd5f65f57eac1893a6aa070c27117b")
