-- Lua provided by RyzenAPI
-- Game: Passed Out

-- MAIN APPLICATION
addappid(1986390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986391, 1, "0990576e49878857e8fb99ec40ce58657df180b55a415d69dfaff981a9d7b85b")
