-- Lua provided by RyzenAPI
-- Game: Chimera Island

-- MAIN APPLICATION
addappid(2462970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462971, 1, "8eea7c093fcbb7119e3f63076a8a145724277ecffd708611318b85113acdbc1f")
