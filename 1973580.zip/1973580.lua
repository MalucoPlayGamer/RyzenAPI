-- Lua provided by RyzenAPI
-- Game: Once a Porn a Time

-- MAIN APPLICATION
addappid(1973580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973581, 1, "faf6ab913e2bd0adbb4376a03542bd6b3f35654478d7c92744f04801c4634188")

