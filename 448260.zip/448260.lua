-- Lua provided by RyzenAPI
-- Game: Cubium Dreams

-- MAIN APPLICATION
addappid(448260)

-- MAIN APP DEPOTS / PACKAGES
addappid(448261, 1, "b45b01083c8a04d5a80973f21cb398eec5d52cf7dae179bc42d157e9e1ed4287")

