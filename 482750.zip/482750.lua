-- Lua provided by RyzenAPI
-- Game: Football Manager Touch 2017

-- MAIN APPLICATION
addappid(482750)
addappid(489840)
addappid(489841)
addappid(489842)
addappid(489843)
addappid(489844)
addappid(489845)
addappid(489846)
addappid(489847)
addappid(489848)
addappid(489849)
addappid(489850)
addappid(489851)
addappid(489852)
addappid(514683)
addappid(514684)
addappid(514685)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(482751, 1, "e9a14e42780265e9fed829d74616cc7fba42e81256aefdc901e18853ffa9819c")
addappid(482752, 1, "e46725e6610bf6c5764d6b61d3cb90b3b5276629cb1eb143cd371c4517410fd7")
addappid(482753, 1, "4d324b645bc77e1d59ca096f766449e462cc7013b1dc544cb64f280d5a5796f6")
addappid(482754, 1, "92af2ca9f24d00ef933f99331b0046b6070260bd6428c63a1f3a5fe570a15462")
addappid(482755, 1, "f5035b11512ec75aadf51f5d370f98d3307f538975ff97e0c08fc348fb8c5b12")
addappid(482756, 1, "290cdc7142837306ac806420ec5fca7f716d0d4fa771f2e17e051dcbffb1f17f")
addappid(482757, 1, "70b1aceb3de61801987702f50baabf83d31f88f8e730f1897774982af74b7880")
addappid(482758, 1, "620d82f6f6012ebfd680e0833dcb4ec01e6cfe9d269f1b74f2e0ec645a15ea53")

