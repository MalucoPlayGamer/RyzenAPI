-- Lua provided by RyzenAPI
-- Game: Unturned

-- MAIN APPLICATION
addappid(304930)
addappid(306460)

-- MAIN APP DEPOTS / PACKAGES
addappid(304931, 1, "dd17a6c31d9e3ddcf242dfac38216423a44b761a67b14d09e21982f51dd71f88")
addappid(304932, 1, "08fc4570b3ad5e67e9cdfe25dc1a70b7a464ea61958b06194602552942fd5d20")
addappid(304933, 1, "ea5701216a4bd2c7485492ad9b371aac785e52634dead4cf6989ecc04af600f1")
addappid(304934, 1, "624432d96e490d79ba15e1e120774d56d028c7c1543d3781b5d9a985c4cd9afe")
addappid(304935, 1, "7840dd6b9a055e2c8f8a2ed8b85cc601f0a1f06b039275da696dc443434dc281")
addappid(304938, 1, "dc36bdce4d815f6a3d9427fc2abb7ec2f21199d932c9b546b2fcb8145ae438d3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(392250)
addappid(429880)
addappid(429881)
addappid(1651820)
addappid(2087620)
