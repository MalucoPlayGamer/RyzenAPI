-- Lua provided by RyzenAPI
-- Game: The Divine Speaker - Original Sound Track

-- MAIN APPLICATION
addappid(1953041)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953130,0,"e35132b044481a85f99b4081ee6b1c6bbcf9107bee577e6fdeea2a0977eaac00")

