-- Lua provided by RyzenAPI
-- Game: Kingdom Rush Frontiers

-- MAIN APPLICATION
addappid(458710)

-- MAIN APP DEPOTS / PACKAGES
addappid(458711, 1, "9d1dd1a44f33bf87b6f68344dc1081446e9e3d5e6ee5fb0a47898db00d96f3f8")
addappid(458712, 1, "6fad73399072cb78d6862b7d53a1ad86e4d43ade66bce45feef41e4ee89320a7")
addappid(458713, 1, "27067325606578ca7375447fde6ee006c3f99159176940d56f726cc6509536ed")

