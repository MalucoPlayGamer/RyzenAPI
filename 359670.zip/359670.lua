-- Lua provided by RyzenAPI
-- Game: Vagrant Hearts 2

-- MAIN APPLICATION
addappid(359670)

-- MAIN APP DEPOTS / PACKAGES
addappid(359671, 1, "541413150767f89b081b6fd1faad9a521aaaabfe6b96a4744133b87b9f1a1728")
