-- Lua provided by RyzenAPI
-- Game: Game: AppID 2243120

-- MAIN APPLICATION
addappid(2243120)
-- Game: addappid(2243120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243121, 1, "7eb25af7dc6378c45c07c8ca7daa863cffde1ac65f7f2f00a839377d797b6e86")
