-- Lua provided by RyzenAPI
-- Game: AppID 436070

-- MAIN APPLICATION
addappid(436070)
-- Game: addappid(436070)

-- MAIN APP DEPOTS / PACKAGES
addappid(436071, 1, "04b0737accc39f7605942592d091de0babf81ccd968799e56bb781bb8b3a443b")
addappid(436072, 1, "ce3c618a66066bf139987f9c7c25fedbc827338440b6dc55066e4ccca00eda6d")
addappid(754700, 0, "cd01b7f35478c9d2a871c11acad9fc234093ee1eee5f3b0467ac186ac0c24dc7")
