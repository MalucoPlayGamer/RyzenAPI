-- Lua provided by RyzenAPI
-- Game: Game: Valfaris: Mecha Therion

-- MAIN APPLICATION
addappid(1647920)
-- Game: addappid(1647920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647921, 1, "6fdbed4fbc2e4e9488599c297fc2958d077591fa6a085f403cd5bfa6a0eb95a3")
