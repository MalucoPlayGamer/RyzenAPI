-- Lua provided by RyzenAPI
-- Game: addappid(1012760)

-- MAIN APPLICATION
addappid(1012760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012760,0,"9232b86b359ee5a46c40cbc210cbfad2d075da05db128a89305fe7ddd84c0f39")
