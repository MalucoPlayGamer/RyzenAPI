-- Lua provided by RyzenAPI
-- Game: Blob From Space Demo

-- MAIN APPLICATION
addappid(437150)
-- Game: addappid(437150)

-- MAIN APP DEPOTS / PACKAGES
addappid(437151, 1, "176d5d5c7cc3bc57b91970448ffb38e56e726444009419610b05712d685b52dd")
