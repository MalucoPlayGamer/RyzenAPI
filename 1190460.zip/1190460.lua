-- Lua provided by RyzenAPI
-- Game: AppID 1190460

-- MAIN APPLICATION
addappid(1190460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1190461, 1, "ba4c72812b801fa2b777bbbb0e3bc51cdd4d5a96e9684b8d267d6273eb9d9552")
addappid(1258510, 0, "f584e505fdec0face5332668d8732e56722854f0a1e3d54e7b8c5a6f40dd165a")
addappid(1258610, 0, "800379eb2eac3ae22ec9e8da62e69ee31943887000f2b87b1fea64ba208e6f95")

