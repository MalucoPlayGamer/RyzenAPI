-- Lua provided by RyzenAPI
-- Game: WaveCrash!!

-- MAIN APPLICATION
addappid(751490)

-- MAIN APP DEPOTS / PACKAGES
addappid(751491,0,"80670c2bf2993acaf7934fb8808db1186ab94b77cfc9273e85001ae494c088cc")

