-- Lua provided by RyzenAPI
-- Game: Othello: Battle Royale

-- MAIN APPLICATION
addappid(3682440)
-- Game: addappid(3682440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3682441, 1, "68b6a60d7485a9f74eb749b9a74ba5c572f122b8521c1e59bc199ff8bc14efbf")
