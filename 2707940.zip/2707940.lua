-- Lua provided by RyzenAPI
-- Game: FPV Kamikaze Drone

-- MAIN APPLICATION
addappid(2707940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707941, 1, "6660644ddd76643cb6e2fed1f8da977636b5677060ef6338cf9d2e8d3ecc0c07")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
