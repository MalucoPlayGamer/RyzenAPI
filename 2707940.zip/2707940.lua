-- Lua provided by RyzenAPI
-- Game: 2707940

-- MAIN APPLICATION
addappid(2707940)
-- Game: addappid(2707940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707941, 1, "6660644ddd76643cb6e2fed1f8da977636b5677060ef6338cf9d2e8d3ecc0c07")
