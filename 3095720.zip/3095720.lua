-- Lua provided by RyzenAPI
-- Game: Stick It!

-- MAIN APPLICATION
addappid(3095720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095721, 1, "99d952331be31a9d753ea8199e1248e593ea6d1c734b0e3224df2cfbb72f526c")
