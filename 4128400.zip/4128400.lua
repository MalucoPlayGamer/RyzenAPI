-- Lua provided by RyzenAPI
-- Game: eBaseball™: PRO SPIRIT

-- MAIN APPLICATION
addappid(4128400)

