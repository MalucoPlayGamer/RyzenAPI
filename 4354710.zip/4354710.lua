-- Lua provided by RyzenAPI
-- Game: Ghost Buster:Village

-- MAIN APPLICATION
addappid(4354710) -- Ghost Buster:Village

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4354711, 1, "ec0c1649f6693f2850430aa77d42de084c4f79fbd8624eb2c2f63e4bc7e2f346") -- Depot 4354711

