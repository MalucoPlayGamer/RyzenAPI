-- 4354710's Lua and Manifest Created by Hubcap Manifest
-- Ghost Buster:Village
-- Created: August 21, 2026 at 08:05:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4354710) -- Ghost Buster:Village
-- MAIN APP DEPOTS
addappid(4354711, 1, "ec0c1649f6693f2850430aa77d42de084c4f79fbd8624eb2c2f63e4bc7e2f346") -- Depot 4354711
setManifestid(4354711, "6170652180230689298", 7127887158)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)