-- Lua provided by SkyAPI 
-- Game: ПОСЛЕДНИЙ ДЕНЬ В УРЮПИНСКЕ
addappid(1830870)
addappid(1830871, 1, "b8c0f18a2d283f2945016999b11ac16c800d45931c6b890301d69354db5743d8")
