-- Lua provided by RyzenAPI
-- Game: ПОСЛЕДНИЙ ДЕНЬ В УРЮПИНСКЕ

-- MAIN APPLICATION
addappid(1830870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830871, 1, "b8c0f18a2d283f2945016999b11ac16c800d45931c6b890301d69354db5743d8")

