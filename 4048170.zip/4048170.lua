-- Lua provided by RyzenAPI
-- Game: Marble Mirage

-- MAIN APPLICATION
addappid(4048170)

-- MAIN APP DEPOTS / PACKAGES
addappid(4048171,0,"20792566f648a61820abb7abefad54eab770c5d16df85a46337387194c41de99")

