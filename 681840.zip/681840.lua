-- Lua provided by RyzenAPI
-- Game: AppID 681840

-- MAIN APPLICATION
addappid(681840)

-- MAIN APP DEPOTS / PACKAGES
addappid(681841, 1, "e5269c363e95663043e9527c513c883f00d22dc91ce50db9d81f39d2f0d86275")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
