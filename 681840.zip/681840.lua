-- Lua provided by RyzenAPI
-- Game: Game: AppID 681840

-- MAIN APPLICATION
addappid(681840)
-- Game: addappid(681840)

-- MAIN APP DEPOTS / PACKAGES
addappid(681841, 1, "e5269c363e95663043e9527c513c883f00d22dc91ce50db9d81f39d2f0d86275")
