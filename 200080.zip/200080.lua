-- Lua provided by RyzenAPI
-- Game: AppID 200080

-- MAIN APPLICATION
addappid(200080)

-- MAIN APP DEPOTS / PACKAGES
addappid(200081, 1, "c37d41fbfe6ffe67fe5ed7f0d2942503f337659f125dc3b8c0d5d76baf9a18bc")
