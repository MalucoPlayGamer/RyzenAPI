-- Lua provided by RyzenAPI
-- Game: Oil Wars

-- MAIN APPLICATION
addappid(1208830)
addappid(1238640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1208831, 1, "45c7c2bb5a53cde1e04feed5ed2b3b6be8d9a7884dccde8a7af9cfd1b40f43c3")

