-- Lua provided by SkyAPI 
-- Game: AppID 1668040
addappid(1668040)
addappid(1668041, 1, "de06bce9e8f128f21fbc277d4c4e29b543e51f47c1228363e0e2423e296641dc")
