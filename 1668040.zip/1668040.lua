-- Lua provided by RyzenAPI
-- Game: 1668040

-- MAIN APPLICATION
addappid(1668040)
-- Game: addappid(1668040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668041, 1, "de06bce9e8f128f21fbc277d4c4e29b543e51f47c1228363e0e2423e296641dc")
