-- Lua provided by RyzenAPI
-- Game: AppID 834580

-- MAIN APPLICATION
addappid(834580)

-- MAIN APP DEPOTS / PACKAGES
addappid(834581, 1, "3e780f173d9fe2e7b0266a311912717a4f73f4155338765b58d8f34c40e7b1d8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1165300)
