-- Lua provided by RyzenAPI
-- Game: addappid(1218580)

-- MAIN APPLICATION
addappid(1218580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218581, 1, "6fcafb58728511e0de5e05e3c4a01c049ee3ac894b381a8d4f1cd9833e180165")
