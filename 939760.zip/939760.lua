-- Lua provided by RyzenAPI
-- Game: 939760

-- MAIN APPLICATION
addappid(939760)
-- Game: addappid(939760)

-- MAIN APP DEPOTS / PACKAGES
addappid(939761, 1, "13f03e0d56d307994a4798cd2d10c9e88f902ee0d8cdfc159cf0f985ffc6deb7")
