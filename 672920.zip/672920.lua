-- Lua provided by RyzenAPI
-- Game: The Bounty V2

-- MAIN APPLICATION
addappid(672920)
addappid(2818790)

-- MAIN APP DEPOTS / PACKAGES
addappid(672921, 1, "2ff2203bcf7a6680984bb2c3c7f9355a5bc9c8a7c14971bb09c9a031f1eb20a3")
