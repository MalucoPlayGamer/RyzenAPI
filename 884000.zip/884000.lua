-- Lua provided by SkyAPI 
-- Game: AppID 884000
addappid(884000)
addappid(884001, 1, "e4e5791fead16be113a16f5ee5e99d21d1065ab3f2534952f3e7a9b38894ecf1")
