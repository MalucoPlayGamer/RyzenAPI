-- Lua provided by RyzenAPI
-- Game: AppID 884000

-- MAIN APPLICATION
addappid(884000)
-- Game: addappid(884000)

-- MAIN APP DEPOTS / PACKAGES
addappid(884001, 1, "e4e5791fead16be113a16f5ee5e99d21d1065ab3f2534952f3e7a9b38894ecf1")
