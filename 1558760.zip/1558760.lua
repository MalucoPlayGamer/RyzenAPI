-- Lua provided by RyzenAPI
-- Game: Game: Dread: The Cold Case

-- MAIN APPLICATION
addappid(1558760)
-- Game: addappid(1558760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558761, 1, "702f70211e75de2c2ac276ce27b54c4fcb418b161b466ae51e8515c82c5287a1")
