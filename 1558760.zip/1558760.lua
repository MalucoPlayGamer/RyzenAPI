-- Lua provided by RyzenAPI
-- Game: Dread: The Cold Case

-- MAIN APPLICATION
addappid(1558760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558761, 1, "702f70211e75de2c2ac276ce27b54c4fcb418b161b466ae51e8515c82c5287a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
