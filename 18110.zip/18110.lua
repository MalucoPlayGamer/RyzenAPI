-- Lua provided by RyzenAPI
-- Game: addappid(18110)

-- MAIN APPLICATION
addappid(18110)

-- MAIN APP DEPOTS / PACKAGES
addappid(18111, 1, "b1d2b5d8d704bb948776f43ed29685306dad321952ac9bd75bf3ae26faf42d6a")
