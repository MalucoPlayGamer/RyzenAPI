-- Lua provided by RyzenAPI
-- Game: Timestamps: Unconditional Love

-- MAIN APPLICATION
addappid(1333560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333561, 1, "cd8c599eb8c52e61c9720dfad7ab350980d2f9f50da198d947a17091b408d73c")

