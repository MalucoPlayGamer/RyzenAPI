-- Lua provided by RyzenAPI
-- Game: Timestamps: Unconditional Love

-- MAIN APPLICATION
addappid(1333560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1333561, 1, "cd8c599eb8c52e61c9720dfad7ab350980d2f9f50da198d947a17091b408d73c")

