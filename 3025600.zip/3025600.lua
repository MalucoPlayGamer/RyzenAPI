-- Lua provided by RyzenAPI
-- Game: Bishojo Battlefield

-- MAIN APPLICATION
addappid(3025600)
-- Game: addappid(3025600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025601, 1, "3aefcdb860ab398748f69b37bfc90e44dd088bf59da9722d2818934d149f7806")
