-- Lua provided by RyzenAPI
-- Game: Wrestling Revolution 2D

-- MAIN APPLICATION
addappid(673910)

-- MAIN APP DEPOTS / PACKAGES
addappid(673911, 1, "6c096f24ce655017e7a37dca029101d121f1fbeb6f14aa7e5413304affdaf70e")
