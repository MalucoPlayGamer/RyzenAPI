-- Lua provided by RyzenAPI
-- Game: AppID 2377230

-- MAIN APPLICATION
addappid(2377230)
-- Game: addappid(2377230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377231, 1, "edf035cddbddc9d391b7f1dda148b55c36e4ed8db6cd202a02011830b7ccc4d6")
