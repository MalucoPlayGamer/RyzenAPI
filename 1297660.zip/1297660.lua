-- Lua provided by RyzenAPI
-- Game: Game: Fragment's Moonrise

-- MAIN APPLICATION
addappid(1297660)
-- Game: addappid(1297660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297661, 1, "189bd4f0cd81206ffdfe0f930f6edb2b1c8513ecdbaa0a3f0b05e4836aed03c4")
addappid(1297663, 1, "9d8928007c6028b1a711b71cbe512aa8e704c0ae98eb4d69a43e0f171cc0281d")
addappid(1297664, 1, "7e4ce5bc441729d9cf5d9788f481373855cee0dc6a756f1689e3195a7a8ffd1c")
