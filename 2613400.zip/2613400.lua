-- Lua provided by RyzenAPI
-- Game: Taxi Rush

-- MAIN APPLICATION
addappid(2613400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613403,0,"def735c77210b369e4ec6d1d5433625858e5c79ef0cd43816948bbd2e5a0586b")
