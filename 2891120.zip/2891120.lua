-- Lua provided by SkyAPI 
-- Game: Mad Smartphone Tycoon
addappid(2891120)
addappid(2891121, 1, "0f89934f08c036132da63004a1278e527956820824f956cc538d22113b6dacc0")
