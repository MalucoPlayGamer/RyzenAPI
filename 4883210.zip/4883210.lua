-- Lua provided by RyzenAPI
-- Game: Hidden Memories

-- MAIN APPLICATION
addappid(4883210) -- Hidden Memories

-- MAIN APP DEPOTS / PACKAGES
addappid(4883211, 1, "ba39e84fb3b45f60586b739d71a7800554192b9f4efebde7aa8e00c3934cb8b6") -- Depot 4883211
