-- Lua provided by RyzenAPI
-- Game: Madness on Display

-- MAIN APPLICATION
addappid(3247440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3247441, 1, "7030dc90a540bd67369320f57300cdff551bfae6bde096ae06cb58d67317386f")
