-- Lua provided by RyzenAPI
-- Game: Madness on Display

-- MAIN APPLICATION
addappid(3247440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3247441, 1, "7030dc90a540bd67369320f57300cdff551bfae6bde096ae06cb58d67317386f")

