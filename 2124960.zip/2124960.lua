-- Lua provided by SkyAPI 
-- Game: AppID 2124960
addappid(2124960)
addappid(2124961, 1, "9ed2eccfe7bf9c5d2067858e9f75b507369e8b3e0723e9b27c37d277cb4359ea")
