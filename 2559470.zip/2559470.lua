-- Lua provided by RyzenAPI
-- Game: 2559470

-- MAIN APPLICATION
addappid(2559470)
-- Game: addappid(2559470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2559471, 1, "67e7b7f898977ead00f6210bb5d916bda5fec0bc42814ec13b7543987c806c7e")
