-- Lua provided by RyzenAPI
-- Game: Expedition Agartha

-- MAIN APPLICATION
addappid(1552620)
addappid(2254510)
addappid(2557100)
addappid(2557110)
addappid(2557120)
addappid(2557130)
addappid(2557140)
addappid(2557150)
addappid(2557160)
addappid(2557170)
addappid(2557180)
addappid(2557190)
addappid(2557200)
addappid(2557210)
addappid(2557680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1552621, 1, "84266060056937c37bc1d7f7adca5b009fda8275ab1eacf4dff05ce443839e12")

