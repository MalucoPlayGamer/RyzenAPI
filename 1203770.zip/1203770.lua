-- Lua provided by RyzenAPI
-- Game: A Moustache in the House

-- MAIN APPLICATION
addappid(1203770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203771, 1, "579b7f424dcd108d86be8d1c219ff296a75b2388de177efe8e810266614e34ad")
