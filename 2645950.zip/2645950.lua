-- Lua provided by RyzenAPI
-- Game: Game: Axona

-- MAIN APPLICATION
addappid(2645950)
-- Game: addappid(2645950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645951, 1, "14b150687ba8d0907c12420f2c52ae66c9276b9498779de80d985415dd02e6c8")
