-- Lua provided by SkyAPI 
-- Game: AppID 283580
addappid(283580)
addappid(283581, 1, "19f11ed01cccb41e817b27621d4ef51117e05cda68c274568897f5a52f50699e")
