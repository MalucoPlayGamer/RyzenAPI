-- Lua provided by RyzenAPI
-- Game: Game: Star Fire: Eternal Cycle Demo

-- MAIN APPLICATION
addappid(3233950)
-- Game: addappid(3233950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3233951, 1, "c13d5dcf41efccb5b9d3b98111486875061ebebcf2b12dca5d24369c88efeff0")
