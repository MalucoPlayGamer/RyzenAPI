-- Lua provided by RyzenAPI
-- Game: addappid(736250)

-- MAIN APPLICATION
addappid(736250)

-- MAIN APP DEPOTS / PACKAGES
addappid(736251, 1, "78ab5e6db78ea08e134f92d9755b092f16fefe734dae16d750970d805714661d")
