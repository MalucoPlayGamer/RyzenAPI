-- Lua provided by RyzenAPI
-- Game: AppID 2549740

-- MAIN APPLICATION
addappid(2549740)
-- Game: addappid(2549740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549741, 1, "d4804c31d701987d50ba3f53440fc406838b7b14cdcb0ab64a6f8c7dc678117d")
