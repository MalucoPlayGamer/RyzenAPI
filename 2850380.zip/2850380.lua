-- Lua provided by RyzenAPI
-- Game: Device Doctor Simulator 2024

-- MAIN APPLICATION
addappid(2850380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2850381, 1, "91aae8a0fb823eae6a08f0a579e3e6f3c04bededbf8bcb4a257bf2ca37d146f8")

