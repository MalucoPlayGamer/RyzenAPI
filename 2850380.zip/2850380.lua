-- Lua provided by SkyAPI 
-- Game: Device Doctor Simulator 2024
addappid(2850380)
addappid(2850381, 1, "91aae8a0fb823eae6a08f0a579e3e6f3c04bededbf8bcb4a257bf2ca37d146f8")
