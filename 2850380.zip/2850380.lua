-- Lua provided by RyzenAPI
-- Game: addappid(2850380)

-- MAIN APPLICATION
addappid(2850380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850381, 1, "91aae8a0fb823eae6a08f0a579e3e6f3c04bededbf8bcb4a257bf2ca37d146f8")
