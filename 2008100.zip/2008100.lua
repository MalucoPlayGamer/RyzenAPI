-- Lua provided by RyzenAPI
-- Game: Rule the Waves 3

-- MAIN APPLICATION
addappid(2008100)
addappid(3170370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2008101, 1, "13f30cd722bc69ec14523f5401a4e3ec55681fae33d7178fbe2ab185d6d06690")
addappid(2008102, 1, "66152eff38c7eb7dcee53c21ef361af6cda1c45fc6d4d3670ed3792c07b27ea0")

