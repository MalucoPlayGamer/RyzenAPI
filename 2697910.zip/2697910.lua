-- Lua provided by RyzenAPI 
-- Game: AppID 2697910
addappid(2697910)
addappid(2697911, 1, "305b59829a9f33ab14531677cd221bd5f03998d1ac5c5ada9d5301e8fc1021ec")
