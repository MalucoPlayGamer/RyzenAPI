-- 5035540's Lua and Manifest Created by Hubcap Manifest
-- Rélyora
-- Created: August 20, 2026 at 13:26:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5035540) -- Rélyora
-- MAIN APP DEPOTS
addappid(5035541, 1, "526f3533ac6de1faf88654767ac848c021b18757d00ba9a097864dffbacb131e") -- Depot 5035541
setManifestid(5035541, "5069310898105567239", 630737902)