-- Lua provided by RyzenAPI
-- Game: Rélyora

-- MAIN APPLICATION
addappid(5035540) -- Rélyora

-- MAIN APP DEPOTS / PACKAGES
addappid(5035541, 1, "526f3533ac6de1faf88654767ac848c021b18757d00ba9a097864dffbacb131e") -- Depot 5035541

