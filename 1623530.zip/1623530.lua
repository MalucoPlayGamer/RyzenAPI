-- Lua provided by RyzenAPI
-- Game: 魔物娘捕获大陆

-- MAIN APPLICATION
addappid(1623530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623531, 1, "dddeeca1ea7757a0971f4bbdee16dc1c200339ebf0f88318e490ee180dd63917")
addappid(1799250, 0, "667167655303e8256412f08905b1afb96cfbfe6bf9c63171944a570d5fca8cc5")
addappid(1800150, 0, "5ad0e438283788afc1f0de72307a813a16ad3ed4da54c24ffb094e9da25921b9")
