-- Lua provided by RyzenAPI
-- Game: addappid(498680)

-- MAIN APPLICATION
addappid(498680)

-- MAIN APP DEPOTS / PACKAGES
addappid(498681, 1, "0c0be4153352434e32db8054f08093cc28c6bb3f3ef7f217dce7352bfb49c6f2")
