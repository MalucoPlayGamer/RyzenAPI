-- Lua provided by SkyAPI 
-- Game: Killing Room
addappid(407560)
addappid(407561, 1, "ec58d629de91764f606488acd0e09938b5c3acdad97e8cca295d10f4743ed617")
addappid(407563, 1, "b037ea91feef1dcc85d62ddbf0f1f37280a6e4c2e1288447e3a1a03d0834824b")
