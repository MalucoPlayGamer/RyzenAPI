-- Lua provided by RyzenAPI
-- Game: CROSSBOW: Bloodnight

-- MAIN APPLICATION
addappid(1329540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329541, 1, "8c813becdcb1ce292c28be03ad1bb2ed592032941d4f5fb5652b6e27830cecb8")
