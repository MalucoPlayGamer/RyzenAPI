-- Lua provided by RyzenAPI
-- Game: addappid(2963030)

-- MAIN APPLICATION
addappid(2963030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963030,0,"6c68a92cbc633d34ace95005720cf7b54f8487ee7b4efe2d7c48429b4d442cd4")
