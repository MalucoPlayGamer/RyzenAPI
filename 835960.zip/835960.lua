-- Lua provided by RyzenAPI 
-- Game: The Talos Principle 2
addappid(835960)
addappid(835961, 1, "fb50a63e9de1e5f24f3cfb6de54ba276dff93be8dd3e80dc9f293a0aa862db6d")
addappid(2676320, 0, "a2e9fade3fffaf4f08be587748517b1d81b5cbab0e27814d7f37f557fb9e9188")
addappid(2981410, 0, "e28c73f6c229e2401c0bcea6f209e428b92cb674b2cc662ed5a226ea07b8f3c8")
