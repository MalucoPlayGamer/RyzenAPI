-- Lua provided by RyzenAPI
-- Game: Rojiura Glory Hole

-- MAIN APPLICATION
addappid(1845660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845661, 1, "5c8e6daa7e6754e4bcd90528ba13a2a3bd7df8e972bbf0b7e8d78b7de35b5782")

