-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Character EX Pack Naughty Extreme Masochist

-- MAIN APPLICATION
addappid(2728880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2728881, 1, "026d4f2aab88ea6ab4026818c3a8e3a53f6630b30b9bbe98abfccd1dc72c6468")

