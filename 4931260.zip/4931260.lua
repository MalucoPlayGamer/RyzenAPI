-- 4931260's Lua and Manifest Created by Hubcap Manifest
-- The Ocean Between Us
-- Created: August 12, 2026 at 00:07:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4931260) -- The Ocean Between Us
-- MAIN APP DEPOTS
addappid(4931261, 1, "007333d1d5ea35c9d6f48e7e6da7a3767247c41e9b9e3812e261ace6b9f6f9fb") -- Depot 4931261
setManifestid(4931261, "8481799489555650075", 547779610)