-- Lua provided by RyzenAPI
-- Game: The Ocean Between Us

-- MAIN APPLICATION
addappid(4931260) -- The Ocean Between Us

-- MAIN APP DEPOTS / PACKAGES
addappid(4931261, 1, "007333d1d5ea35c9d6f48e7e6da7a3767247c41e9b9e3812e261ace6b9f6f9fb") -- Depot 4931261

