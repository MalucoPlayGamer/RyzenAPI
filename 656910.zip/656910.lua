-- Lua provided by RyzenAPI
-- Game: 656910

-- MAIN APPLICATION
addappid(656910)
-- Game: addappid(656910)

-- MAIN APP DEPOTS / PACKAGES
addappid(656911, 1, "bb31db3eebea76185d2cffbe579bd670899ea85429b5431ca7f5d27ee44e0812")
addappid(673690, 0, "1f4639ee8d094b8e3b1cdc74fe72392499617c897522141c42c157dbd65c37fe")
addappid(676890, 0, "9e0df262d1c7a88f1aeec71550d67c9f1d174bef166088b19c02e8bd2b278ae9")
