-- Lua provided by RyzenAPI 
-- Game: Forest Horror
addappid(2449830)
addappid(2449831, 1, "3cd966d6b217ee71bca1353bebfb8074e3c87d8baa1d9852e3ef1e6cf0953ffb")
