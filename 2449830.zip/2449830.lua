-- Lua provided by RyzenAPI
-- Game: Forest Horror

-- MAIN APPLICATION
addappid(2449830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449831, 1, "3cd966d6b217ee71bca1353bebfb8074e3c87d8baa1d9852e3ef1e6cf0953ffb")
