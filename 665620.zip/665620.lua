-- Lua provided by RyzenAPI 
-- Game: Zombie Hobby VR
addappid(665620)
addappid(665621, 1, "1706066535d38f5ee59d256691202f053b922113dd84afc04e0dcaf1d1c14361")
