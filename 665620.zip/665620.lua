-- Lua provided by RyzenAPI
-- Game: Zombie Hobby VR

-- MAIN APPLICATION
addappid(665620)

-- MAIN APP DEPOTS / PACKAGES
addappid(665621, 1, "1706066535d38f5ee59d256691202f053b922113dd84afc04e0dcaf1d1c14361")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
