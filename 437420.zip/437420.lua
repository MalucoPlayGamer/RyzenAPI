-- Lua provided by RyzenAPI
-- Game: The Secret Order 3: Ancient Times

-- MAIN APPLICATION
addappid(437420)

-- MAIN APP DEPOTS / PACKAGES
addappid(437421, 1, "b789a6f40f0975da4e2ae7306c878beebe86c224edf40c6f1f85a05aaa9d546e")
addappid(437422, 1, "9bd03bf3aa2532b2459ffc59b787597372af1ac37eca588f3c578e8ea2b85d73")
addappid(437423, 1, "784438cf9df5c2a3cf5513f86df367be3a1537987e27ac350c303c19de06f61e")
