-- Lua provided by RyzenAPI
-- Game: Game: AppID 3279120

-- MAIN APPLICATION
addappid(3279120)
-- Game: addappid(3279120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279121, 1, "67aeced6443b9c43b76211509f663f8a48b16f5bca03977f5dfbab3c8cf7d352")
