-- 3775570's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Emy is streaming
-- Created: December 08, 2025 at 12:33:14 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3775570) -- Hentai Clicker: Emy is streaming
-- MAIN APP DEPOTS
addappid(3775571, 1, "004fb380589efc84a63504a769d6c1a8fafe67ec485227dc343fde01aec1be32") -- Depot 3775571
setManifestid(3775571, "1909705660875413451", 154347033)