-- Lua provided by RyzenAPI
-- Game: addappid(3006980)

-- MAIN APPLICATION
addappid(3006980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3006981, 1, "6b19e407d4fb75a40284960ac2f2a2eb8f0189123eec5b69d5d81bb409d06fd2")
