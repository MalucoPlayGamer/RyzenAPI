-- Lua provided by SkyAPI 
-- Game: SUPER ALICE DOLLS Demo
addappid(3025850)
addappid(3025851, 1, "83393513c064591ae39dc09072d3e29705a55ed76f37e3f5a170110e41127e04")
