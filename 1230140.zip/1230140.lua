-- Lua provided by RyzenAPI
-- Game: ATRI -My Dear Moments-

-- MAIN APPLICATION
addappid(1230140)
-- Game: addappid(1230140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230141, 1, "39502ae3d63e81aa83ffa3684427babdc6369d7d06a742a3d21efbaa0097e917")
