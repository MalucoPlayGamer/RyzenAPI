-- Lua provided by RyzenAPI
-- Game: Game: VR Hentai Simulation

-- MAIN APPLICATION
addappid(2406200)
addappid(2417820)
-- Game: addappid(2406200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406201, 1, "a918acd1a2e2a44c04c5cb1674141ed23da85c203fbf7f3635555841af739935")
