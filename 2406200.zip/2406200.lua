-- Lua provided by SkyAPI 
-- Game: VR Hentai Simulation
addappid(2406200)
addappid(2406201, 1, "a918acd1a2e2a44c04c5cb1674141ed23da85c203fbf7f3635555841af739935")
addappid(2417820)
