-- Lua provided by RyzenAPI 
-- Game: Apocalypse ? No !
addappid(3442760)
addappid(3442761, 1, "2d93f0255c43e74f78c1d1690fc3de3a42e46dd86d4c340088c8d10dbef4f529")
