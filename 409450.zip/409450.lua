-- Lua provided by RyzenAPI
-- Game: The Fall of the Dungeon Guardians - Enhanced Edition

-- MAIN APPLICATION
addappid(409450)

-- MAIN APP DEPOTS / PACKAGES
addappid(409451, 1, "f1e6237fc3bd2fcfe2a05b418602e131a8d156d96d2155c6c93882af3b5072b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
