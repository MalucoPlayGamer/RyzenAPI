-- Lua provided by RyzenAPI
-- Game: Taverna

-- MAIN APPLICATION
addappid(3219160)
-- Game: addappid(3219160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3219161, 1, "47b3fd06848756608051b6ac06518d5632443934f6328ec1b6ddea5105d6b552")
