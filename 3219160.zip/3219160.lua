-- Lua provided by SkyAPI 
-- Game: Taverna
addappid(3219160)
addappid(3219161, 1, "47b3fd06848756608051b6ac06518d5632443934f6328ec1b6ddea5105d6b552")
