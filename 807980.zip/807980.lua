-- Lua provided by RyzenAPI
-- Game: ElvenEscape

-- MAIN APPLICATION
addappid(807980)
addappid(807981)
-- Game: addappid(807980)

-- MAIN APP DEPOTS / PACKAGES
addappid(807982,0,"02deb50b9dddf4ba72bf7db9c9a2a908c16f3193164c9c92ad201d65dcca9582")
