-- Lua provided by RyzenAPI
-- Game: Game: Terranny

-- MAIN APPLICATION
addappid(2131150)
-- Game: addappid(2131150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131151, 1, "d012689d59379055228c03576e5f34d1cb840b75a570c7c14d22eccac72287c3")
