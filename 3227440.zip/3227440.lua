-- Lua provided by RyzenAPI
-- Game: 3227440

-- MAIN APPLICATION
addappid(3227440)
-- Game: addappid(3227440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227440,0,"e1a4b6d5573fb3fd7b897dc24160949ccbb3349d989fb0fbfe84cfc028f85b96")
