-- Lua provided by RyzenAPI 
-- Game: Poker Master - Texas Hold'em, Roulette, Blackjack, Baccarat, Omaha, Slots, Teen Patti
addappid(994910)
addappid(994911, 1, "43bb30c5763b605fc355f359eb84c07d2d112e38fba9ffeedc769c05fcf140f0")
addappid(994912, 1, "0ccde9b536d81b697e963a7f34bfccee497ef3ac21c1bc2888e081df0bada921")
addappid(994913, 1, "5b0381fc72adcfd298e4656f6b92b4cd5ae6fbe2e6b578f70a9227545c2e8064")
