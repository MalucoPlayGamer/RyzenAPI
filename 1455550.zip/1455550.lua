-- Lua provided by RyzenAPI
-- Game: Warhammer: Chaosbane - 4K Textures

-- MAIN APPLICATION
addappid(1455550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455550,0,"361759d8e0d96348724ed7c736924bb97056356a9733fe20d294393233a964b2")

