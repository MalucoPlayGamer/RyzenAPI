-- Lua provided by RyzenAPI
-- Game: Game: Anime Armpits

-- MAIN APPLICATION
addappid(1995600)
addappid(2002800)
-- Game: addappid(1995600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995601, 1, "aef7e2ee88e73e6f1c1b0159563314bd30d5f2859eb2ebb1dcb257c31d36f957")
