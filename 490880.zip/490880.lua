-- Lua provided by RyzenAPI
-- Game: addappid(490880)

-- MAIN APPLICATION
addappid(490880)

-- MAIN APP DEPOTS / PACKAGES
addappid(490881, 1, "6c329e8faac7f97f915db102f6d32432b5306ad8268c3baa31d635794141ab26")
