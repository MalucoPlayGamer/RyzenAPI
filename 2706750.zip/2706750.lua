-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2706750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706752,0,"db122cf4ff4d2168a4d7b561f71c51c03678d6db90c88b5b738f1dfacb67d539")
