-- Lua provided by RyzenAPI
-- Game: 72310

-- MAIN APPLICATION
addappid(72310)
-- Game: addappid(72310)

-- MAIN APP DEPOTS / PACKAGES
addappid(72311, 1, "3905c3bbf58fd5626a652e0bc6c3284b0e38e1e9002dee4e35a4959f87a6a47f")
