-- Lua provided by SkyAPI 
-- Game: AppID 72310
addappid(72310)
addappid(72311, 1, "3905c3bbf58fd5626a652e0bc6c3284b0e38e1e9002dee4e35a4959f87a6a47f")
