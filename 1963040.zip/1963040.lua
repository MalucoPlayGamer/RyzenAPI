-- Lua provided by RyzenAPI 
-- Game: The Lost Village
addappid(1963040)
addappid(1963041, 1, "0960237e0bdfa0375c4556be4c342956e5f6d446657bc4d0a9644f32316b9c76")
