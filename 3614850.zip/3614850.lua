-- Lua provided by RyzenAPI
-- Game: ZDSimulator - ED4m Electric Train

-- MAIN APPLICATION
addappid(3614850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614850,0,"d9960ce7d5bcde64a0a08bbdd9872dffaedd960d72f1457cb024419c1aaf9c03")

