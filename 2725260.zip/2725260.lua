-- Lua provided by RyzenAPI
-- Game: ENDER MAGNOLIA: Bloom in the Mist

-- MAIN APPLICATION
addappid(2725260)
-- Game: addappid(2725260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725261, 1, "935fccb2fcc5c04d8e1f15711fb86eeb0efc2bba42b9b452e559a9c053ab3d82")
