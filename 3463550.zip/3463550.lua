-- Lua provided by RyzenAPI
-- Game: IMMORTAL: Gates of Pyre Demo

-- MAIN APPLICATION
addappid(3463550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3463551, 1, "d30152ce48a8e9e56518c7f67651d6c03da99cee9568b59141b650bed7e7d349")

