-- Lua provided by SkyAPI 
-- Game: The Scrap
addappid(2304650)
addappid(2304651, 1, "0a16cac7276aae5deb9bfad4c43af3ba45dff8b5316a5b08f9ce0aff81ea83ec")
