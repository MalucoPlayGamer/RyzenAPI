-- Lua provided by RyzenAPI
-- Game: The Scrap

-- MAIN APPLICATION
addappid(2304650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304651, 1, "0a16cac7276aae5deb9bfad4c43af3ba45dff8b5316a5b08f9ce0aff81ea83ec")

