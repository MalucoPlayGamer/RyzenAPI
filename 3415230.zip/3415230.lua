-- Lua provided by RyzenAPI
-- Game: Game: Witchy Business

-- MAIN APPLICATION
addappid(3415230)
-- Game: addappid(3415230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3415231, 1, "0974ba2821acf344ea3013f4306ac3763a127d32ec3e08ba0540438127d59f5f")
