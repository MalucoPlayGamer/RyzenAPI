-- Lua provided by RyzenAPI
-- Game: addappid(581430)

-- MAIN APPLICATION
addappid(581430)

-- MAIN APP DEPOTS / PACKAGES
addappid(581431, 1, "65c8191044ced0b3456011ccef2339cd2198b67f1a2eade87389fe1158fd5703")
