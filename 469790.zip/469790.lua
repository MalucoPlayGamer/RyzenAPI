-- Lua provided by RyzenAPI
-- Game: Linelight

-- MAIN APPLICATION
addappid(469790)
-- Game: addappid(469790)

-- MAIN APP DEPOTS / PACKAGES
addappid(469791, 1, "f1082dd64c9af1fc12d2cac7c078ea2803b51351cce9dd7616d1c0102ea37573")
addappid(469792, 1, "40f89fcff851dfc5cb9829d461ca64a104e43b7d4eb3692c6546466607a7333f")
addappid(469793, 1, "a9ae9cd22af2e45be42fa1fddbdb89b8465c6cb8ab7f5389646b4db182398b50")
addappid(587910, 0, "2178fb59468a58893facf89c344bd03e30a9b956c45c1c5bc4cf9cd41459b4d5")
