-- Lua provided by SkyAPI 
-- Game: DianQi 典妻
addappid(2516810)
addappid(2516811, 1, "ca62f38dbd34663f70b6b9a2c8a8411dda9ee56c5c005b0299459f602d8ff41f")
