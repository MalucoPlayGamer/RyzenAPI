-- Lua provided by RyzenAPI
-- Game: Game: AppID 2549560

-- MAIN APPLICATION
addappid(2549560)
-- Game: addappid(2549560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549561, 1, "5bbd46779bf9d1d8966b9fb31251f63974f5be9bf85e199707cc8aff2f7d7cb6")
