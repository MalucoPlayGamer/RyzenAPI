-- Lua provided by RyzenAPI
-- Game: Unrailed! - Soundtrack: Underwater EP

-- MAIN APPLICATION
addappid(2352250)
-- Game: addappid(2352250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352251, 1, "2bae20726d09958edf89ac11d8ad0963c65f0f1970bcd1a740782b0e3363ba35")
addappid(2352252, 1, "80b09078d653f550ccd39b2e0ca0d9713ae284a1738b43dbd184254e5f631ce4")
