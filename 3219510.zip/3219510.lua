-- Lua provided by RyzenAPI
-- Game: AppID 3219510

-- MAIN APPLICATION
addappid(3219510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3219511, 1, "e73edc32cd200bcc5dce0a91ab223c21e89d99992c57a6038bce8e18aa09bc31")

