-- Lua provided by RyzenAPI
-- Game: AppID 994700

-- MAIN APPLICATION
addappid(994700)

-- MAIN APP DEPOTS / PACKAGES
addappid(994701, 1, "0ed341821a32cef64177bef1eac2b0c7820547e0ac0b9889a3b4bba5d1eba6de")
