-- Lua provided by RyzenAPI
-- Game: Loco Launcher

-- MAIN APPLICATION
addappid(994700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(994701, 1, "0ed341821a32cef64177bef1eac2b0c7820547e0ac0b9889a3b4bba5d1eba6de")

