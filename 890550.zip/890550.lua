-- Lua provided by RyzenAPI
-- Game: addappid(890550)

-- MAIN APPLICATION
addappid(890550)

-- MAIN APP DEPOTS / PACKAGES
addappid(890551, 1, "aa5c003ce988893f1b22c53efa4eb7cff9314a6ade916b398f1caf14f1d72146")
