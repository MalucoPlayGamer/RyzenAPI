-- Lua provided by RyzenAPI
-- Game: RUMBLE

-- MAIN APPLICATION
addappid(890550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(890551, 1, "aa5c003ce988893f1b22c53efa4eb7cff9314a6ade916b398f1caf14f1d72146")

