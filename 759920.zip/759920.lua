-- Lua provided by RyzenAPI
-- Game: Souland

-- MAIN APPLICATION
addappid(759920)

-- MAIN APP DEPOTS / PACKAGES
addappid(759921,0,"911d2ce2ecd167ec78279019e376aa67e205f9c512cd84e61e08cfe02b8efd2b")

