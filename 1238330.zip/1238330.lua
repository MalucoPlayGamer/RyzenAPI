-- Lua provided by RyzenAPI
-- Game: Game: Frontline: Panzer Blitzkrieg!

-- MAIN APPLICATION
addappid(1238330)
-- Game: addappid(1238330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238331, 1, "8915c97546419959d5d9b6a524b336e4c3895ff6f9e5254a3a0d04827ce75cde")
