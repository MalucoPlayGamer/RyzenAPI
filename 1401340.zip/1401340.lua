-- Lua provided by RyzenAPI
-- Game: Tea Garden Simulator

-- MAIN APPLICATION
addappid(1401340)
-- Game: addappid(1401340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401341, 1, "f4d28332e199c9cd7e4836a89f5065632083696bcc98e5615c218f6f33097339")
