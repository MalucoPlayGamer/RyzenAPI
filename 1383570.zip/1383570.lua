-- Lua provided by RyzenAPI 
-- Game: Ballex²: The Hanging Gardens
addappid(1383570)
addappid(1383571, 1, "a4233c4ce9ac53eb8564875b3e377326a5433cdf13e17a41b714ef182e3f0037")
addappid(1809190, 0, "3a02d2b2b621b12bbcc4745c3bcd3a5e07a05a978c0d80cab308f32d9b53fab4")
