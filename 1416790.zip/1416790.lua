-- Lua provided by SkyAPI 
-- Game: AppID 1416790
addappid(1416790)
addappid(1416791, 1, "8f197ce49f4b3c5e6ec5fec56704934345b4b79a82be0010e513b45916b8ff5d")
addappid(1416792, 1, "b2c96664435b9440b61cf5618c7235b2da4abb7b9b6457538befb6c2bb21fe7c")
