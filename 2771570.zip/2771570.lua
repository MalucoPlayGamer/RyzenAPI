-- Lua provided by RyzenAPI
-- Game: addappid(2771570)

-- MAIN APPLICATION
addappid(2771570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771571, 1, "7e85813ea0ab11c9793df589a1594ed19aa7753ce87b16a36bc766cb4687618a")
