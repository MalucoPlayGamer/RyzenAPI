-- Lua provided by RyzenAPI
-- Game: 2109010

-- MAIN APPLICATION
addappid(2109010)
-- Game: addappid(2109010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109011, 1, "3102bb8d1f2e6f83cbaa15f5ef0e5e9232dcfa4da0690efff1ea96fc5f71ae5a")
