-- Lua provided by RyzenAPI
-- Game: AppID 501300

-- MAIN APPLICATION
addappid(501300)
-- Game: addappid(501300)

-- MAIN APP DEPOTS / PACKAGES
addappid(501301, 1, "957d96d75b0602ec2946f46e298b1c9179a719d977dd1e80d037e13f9c4a7f7d")
