-- Lua provided by RyzenAPI
-- Game: Shogo: Mobile Armor Division

-- MAIN APPLICATION
addappid(610860)

-- MAIN APP DEPOTS / PACKAGES
addappid(610861, 1, "ce62d5b9fb9a7e08c66c603d05f19b6cf7d71f6581edeac8cb7005ea67b18f2b")

