-- Lua provided by SkyAPI 
-- Game: AppID 610860
addappid(610860)
addappid(610861, 1, "ce62d5b9fb9a7e08c66c603d05f19b6cf7d71f6581edeac8cb7005ea67b18f2b")
