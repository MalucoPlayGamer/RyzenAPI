-- Lua provided by RyzenAPI
-- Game: addappid(1978530)

-- MAIN APPLICATION
addappid(1978530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978531, 1, "445627ea4c48ac94a4345525974572f947de22eebdbeb3fc1f1f1d38f39389e6")
