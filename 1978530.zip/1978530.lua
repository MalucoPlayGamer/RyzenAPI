-- Lua provided by RyzenAPI 
-- Game: AppID 1978530
addappid(1978530)
addappid(1978531, 1, "445627ea4c48ac94a4345525974572f947de22eebdbeb3fc1f1f1d38f39389e6")
