-- Lua provided by RyzenAPI 
-- Game: AppID 2467250
addappid(2467250)
addappid(2467251, 1, "4d60757e542d9916fe1f0d6da4cd36f7cba154c5ef03f563a587efaeb92a941e")
