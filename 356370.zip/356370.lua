-- Lua provided by RyzenAPI
-- Game: 356370

-- MAIN APPLICATION
addappid(356370)
-- Game: addappid(356370)

-- MAIN APP DEPOTS / PACKAGES
addappid(356371, 1, "53125894f33efff80db8a42166a0e74bad9c69fe2f3e49c9d77f7d8af50e1251")
