-- Lua provided by RyzenAPI
-- Game: Whisper of a Rose

-- MAIN APPLICATION
addappid(326730)

-- MAIN APP DEPOTS / PACKAGES
addappid(326731, 1, "5c44383d66770f242763ecd1a1676d5e28a5eee8ddad403b1f0f1e37d2cd074c")
addappid(333410, 0, "050059cf92d834ac97cbcaf9ba0e48b2da03564fbd67152af8dd23b62c202a93")
