-- Lua provided by RyzenAPI
-- Game: BluBoy: The Journey Begins

-- MAIN APPLICATION
addappid(1033250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1033251, 1, "d27060e8b896c44a0a3306ff96202c1ad7560bc03dcbc0eaa304f1a91d465b78")

