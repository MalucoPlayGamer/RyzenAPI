-- Lua provided by RyzenAPI
-- Game: 1033250

-- MAIN APPLICATION
addappid(1033250)
-- Game: addappid(1033250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033251, 1, "d27060e8b896c44a0a3306ff96202c1ad7560bc03dcbc0eaa304f1a91d465b78")
