-- Lua provided by RyzenAPI
-- Game: Star Sonata 2

-- MAIN APPLICATION
addappid(304690)
addappid(356410)

-- MAIN APP DEPOTS / PACKAGES
addappid(304691, 1, "ea68267cca23d0e0b2c47fbdec796dbf86973d91f5fb04681f2705593b6fd584")

