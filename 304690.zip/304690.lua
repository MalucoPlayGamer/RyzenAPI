-- Lua provided by RyzenAPI
-- Game: Star Sonata 2

-- MAIN APPLICATION
addappid(304690)
addappid(356410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(304691, 1, "ea68267cca23d0e0b2c47fbdec796dbf86973d91f5fb04681f2705593b6fd584")

