-- Lua provided by RyzenAPI
-- Game: AppID 621000

-- MAIN APPLICATION
addappid(621000)

-- MAIN APP DEPOTS / PACKAGES
addappid(621001, 1, "aca2e5aecdc146b3d0e5e3020debc32dcd0ea8f51d1f1bec19dd40b7035fd347")
