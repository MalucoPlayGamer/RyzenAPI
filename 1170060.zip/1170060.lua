-- Lua provided by SkyAPI 
-- Game: AppID 1170060
addappid(1170060)
addappid(1170061, 1, "5ced70d72fc2bc820942dc3667d1b99c1035da06c16793c20b9c3eba2306cbf9")
