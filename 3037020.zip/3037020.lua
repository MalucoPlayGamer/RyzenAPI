-- Lua provided by RyzenAPI
-- Game: Project Phoenix

-- MAIN APPLICATION
addappid(3037020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3037021, 1, "a3830d5c285f8c42cf096d1295ce21dd0d664205c6fc94ed46d0d12ec774a2b7")

