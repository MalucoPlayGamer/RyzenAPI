-- Lua provided by RyzenAPI
-- Game: Project Phoenix

-- MAIN APPLICATION
addappid(3037020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037021, 1, "a3830d5c285f8c42cf096d1295ce21dd0d664205c6fc94ed46d0d12ec774a2b7")
