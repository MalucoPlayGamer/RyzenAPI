-- Lua provided by SkyAPI 
-- Game: Project Phoenix
addappid(3037020)
addappid(3037021, 1, "a3830d5c285f8c42cf096d1295ce21dd0d664205c6fc94ed46d0d12ec774a2b7")
