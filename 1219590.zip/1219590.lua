-- Lua provided by RyzenAPI
-- Game: 1219590

-- MAIN APPLICATION
addappid(1219590)
-- Game: addappid(1219590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219591, 1, "e078af408a04b6bdc35b6a7a08a75ea77ad9d573ec345936416e9055d53bca7c")
