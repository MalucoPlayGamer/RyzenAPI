-- Lua provided by RyzenAPI
-- Game: AppID 594160

-- MAIN APPLICATION
addappid(594160)
-- Game: addappid(594160)

-- MAIN APP DEPOTS / PACKAGES
addappid(594161, 1, "c9478ad2fd327d01dd08f8460cc3aaf91eb966afc3d4b6a0e81842a6c356a3e1")
