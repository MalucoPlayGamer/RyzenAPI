-- Lua provided by RyzenAPI
-- Game: The Last Patient

-- MAIN APPLICATION
addappid(594160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(594161, 1, "c9478ad2fd327d01dd08f8460cc3aaf91eb966afc3d4b6a0e81842a6c356a3e1")

