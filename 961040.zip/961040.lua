-- Lua provided by RyzenAPI
-- Game: Down to Hell

-- MAIN APPLICATION
addappid(961040)
-- Game: addappid(961040)

-- MAIN APP DEPOTS / PACKAGES
addappid(961041, 1, "45f32d52cb0296b8554f9af2bc3c69f1020e77fd6c354d34076a6c1ac570140d")
