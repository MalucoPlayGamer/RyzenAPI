-- Lua provided by RyzenAPI
-- Game: 2400590

-- MAIN APPLICATION
addappid(2400590)
-- Game: addappid(2400590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400591, 1, "513d58f3ae64fc29bbb9be9b3f7802cfac9954785d6d4f449f5ad55f104812e4")
addappid(2804640, 0, "decd3dc88e47ffd175d8d379e7bbc689cdec6a85021b4aea9313a8c3830dd643")
