-- Lua provided by RyzenAPI
-- Game: addappid(1912092)

-- MAIN APPLICATION
addappid(1912092)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912092,0,"4f2a67dd4b5fdbb026e6dc246ddea9639499982010fc6959e50c84e6325a1fc4")
