-- Lua provided by RyzenAPI
-- Game: 2535640

-- MAIN APPLICATION
addappid(2535640)
-- Game: addappid(2535640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2535643,0,"04ae0b13f08eb6ca8d8b6eab8529bcd736675d96fa7683e24bb2aab1ebd696ac")
