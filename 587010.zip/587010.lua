-- Lua provided by RyzenAPI
-- Game: EZRA: The Stranger

-- MAIN APPLICATION
addappid(587010)

-- MAIN APP DEPOTS / PACKAGES
addappid(587011,0,"26017948cacc18a3c770347761f4eb4dc4e050b5d7eb9d0ba63aa51cac10e139")

