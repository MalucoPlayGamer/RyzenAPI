-- Lua provided by RyzenAPI
-- Game: Game: Ark of Charon Demo

-- MAIN APPLICATION
addappid(2996270)
-- Game: addappid(2996270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996271, 1, "12815dc074d13ccd472d81e5be4337a923d5c53f99f2e1945f7a51e4f874a87c")
