-- Lua provided by SkyAPI 
-- Game: AppID 2066760
addappid(2066760)
addappid(2066761, 1, "7f19ef3b6edb03837424f71c8b7a4acfc2fe64238c4f0db36dc2dba88217e894")
addappid(2066762, 1, "df7bbed22bc24e3105e1dc71f7a2b041583b4e3c27342c84bd7586b4b4b32712")
