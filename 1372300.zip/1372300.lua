-- Lua provided by RyzenAPI
-- Game: Iwaihime

-- MAIN APPLICATION
addappid(1372300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372301, 1, "d3c5d0e6fd6f57225cf85e5fb1a281b2395ba3af6490f6a5e46e862af016bfca")
addappid(1372400, 0, "e9ddfa1b37782b76f98efd033de04d8065cb6b8def7953b81bbba61325e08cb2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
