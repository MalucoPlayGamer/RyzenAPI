-- Lua provided by RyzenAPI
-- Game: AFL Evolution 2

-- MAIN APPLICATION
addappid(856850)
-- Game: addappid(856850)

-- MAIN APP DEPOTS / PACKAGES
addappid(856851, 1, "d5751e0c91f6105a4f8a3395d510f8aeb9ff1fb33c3197c958bfe6fd24393f94")
