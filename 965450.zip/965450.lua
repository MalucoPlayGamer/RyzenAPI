-- Lua provided by RyzenAPI
-- Game: 965450

-- MAIN APPLICATION
addappid(965450)
-- Game: addappid(965450)

-- MAIN APP DEPOTS / PACKAGES
addappid(965451, 1, "e51e90535a087a2f135eb7c2425b1a7a4328f68ba1b99333f303f86f9bb4a51e")
