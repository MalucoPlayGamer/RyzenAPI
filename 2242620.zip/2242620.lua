-- Lua provided by RyzenAPI
-- Game: 2242620

-- MAIN APPLICATION
addappid(2242620)
-- Game: addappid(2242620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242621, 1, "8a85e278ff486e6f66cd5080db4b6f80f87321a4f3d08aa0ad2f9898ec184ae0")
