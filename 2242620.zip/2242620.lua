-- Lua provided by RyzenAPI
-- Game: Eight Winds

-- MAIN APPLICATION
addappid(2242620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242621, 1, "8a85e278ff486e6f66cd5080db4b6f80f87321a4f3d08aa0ad2f9898ec184ae0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
