-- Lua provided by SkyAPI 
-- Game: Eight Winds
addappid(2242620)
addappid(2242621, 1, "8a85e278ff486e6f66cd5080db4b6f80f87321a4f3d08aa0ad2f9898ec184ae0")
