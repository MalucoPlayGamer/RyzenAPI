-- Lua provided by RyzenAPI
-- Game: Game: AppID 575000

-- MAIN APPLICATION
addappid(575000)
-- Game: addappid(575000)

-- MAIN APP DEPOTS / PACKAGES
addappid(575001, 1, "664f84b66a97092e8c095a61fc5beb52752c3eedcdafed0846de9745dd63ad59")
