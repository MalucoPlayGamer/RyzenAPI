-- Lua provided by RyzenAPI
-- Game: Benefitship Demo

-- MAIN APPLICATION
addappid(2768120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768121, 1, "ed87f6ee352e33b779a3140f12cf9e413dd2aa767637322526985e29b6d9db0a")
