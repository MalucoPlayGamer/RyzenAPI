-- Lua provided by RyzenAPI
-- Game: AppID 602520

-- MAIN APPLICATION
addappid(602520)

-- MAIN APP DEPOTS / PACKAGES
addappid(602521, 1, "26c6ec4aeeb2d7a5242153d94cc47f63b51cd10aee492803f8a8b32098098b05")
addappid(947670, 0, "e6a0c5e1bbd515b8a3daf56b8157789b8489059a094a95a95893870180875e8f")
addappid(1088350, 0, "41c4fbf1d220fbba6483057261581ca8115f00c0b3670b900f0ec819b5f8fa8f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
