-- Lua provided by RyzenAPI
-- Game: Oppai Samurai: Knocked up by a No Name Novice

-- MAIN APPLICATION
addappid(2413090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413091, 1, "106e790fd1ead6e50539700187646a72b9d7cd8a1972af4fb690356485266f8b")

