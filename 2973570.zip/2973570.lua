-- Lua provided by RyzenAPI
-- Game: Hidden Haunted Town Top-Down 3D

-- MAIN APPLICATION
addappid(2973570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973571,0,"7d6de839cb5ea6e5dd59dd55988584a58cdea09c6091a11b5ed7d108f6cd3914")

