-- Lua provided by SkyAPI 
-- Game: Butcherbird
addappid(3287650)
addappid(3287651, 1, "e0d0b9009106a904d266d2c091feef654ed3b9cdd0f3007864880cb45ff914ce")
