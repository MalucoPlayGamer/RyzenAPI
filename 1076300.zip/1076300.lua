-- Lua provided by RyzenAPI
-- Game: The Battles of Spwak

-- MAIN APPLICATION
addappid(1076300)
-- Game: addappid(1076300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076301, 1, "66d574c14de529d021724c5b9d9e966cbf4c3ae398b741b01233e22d8db059f6")
