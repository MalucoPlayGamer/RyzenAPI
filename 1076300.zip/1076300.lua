-- Lua provided by RyzenAPI
-- Game: The Battles of Spwak

-- MAIN APPLICATION
addappid(1076300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1076301, 1, "66d574c14de529d021724c5b9d9e966cbf4c3ae398b741b01233e22d8db059f6")

