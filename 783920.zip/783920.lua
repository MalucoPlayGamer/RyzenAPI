-- Lua provided by RyzenAPI
-- Game: Retro Sphere

-- MAIN APPLICATION
addappid(783920)

-- MAIN APP DEPOTS / PACKAGES
addappid(783921, 1, "7bfed75024577f2df254fe4710edffe482c61586be2123c4a0c7cec69c20cdfe")

