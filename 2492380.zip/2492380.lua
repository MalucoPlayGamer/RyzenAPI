-- Lua provided by RyzenAPI
-- Game: 2492380

-- MAIN APPLICATION
addappid(2492380)
-- Game: addappid(2492380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492381, 1, "332da825e216c9fbdb19cf25246e5b80a32abd4b74459286eb344a6f059e386d")
