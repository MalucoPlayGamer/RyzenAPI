-- Lua provided by RyzenAPI
-- Game: Shooting Game Builder

-- MAIN APPLICATION
addappid(2492380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492381, 1, "332da825e216c9fbdb19cf25246e5b80a32abd4b74459286eb344a6f059e386d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
