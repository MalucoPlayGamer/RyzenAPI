-- Lua provided by RyzenAPI
-- Game: addappid(1620540)

-- MAIN APPLICATION
addappid(1620540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620541, 1, "e06a4e150e3d6c89cb726ac2c86b44e7f39d28f6a8aa85bc3fd1faa7c91987d7")
