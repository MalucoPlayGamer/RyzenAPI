-- Lua provided by RyzenAPI
-- Game: Game: Extremely Powerful Capybaras: Training Grounds

-- MAIN APPLICATION
addappid(2526720)
-- Game: addappid(2526720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526721, 1, "adc3f44c5beefbf36376a5e6bee8a83b28225f7471efcbd619766a57aff351b9")
