-- Lua provided by RyzenAPI
-- Game: Tribe Dash - Stone Age Time Management

-- MAIN APPLICATION
addappid(2254030)
addappid(2516370)

