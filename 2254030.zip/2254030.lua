-- Lua provided by RyzenAPI
-- Game: Tribe Dash - Stone Age Time Management

-- MAIN APPLICATION
addappid(2254030)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2516370)
