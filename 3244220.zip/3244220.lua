-- Lua provided by RyzenAPI
-- Game: 3244220

-- MAIN APPLICATION
addappid(3244220)
addappid(4210530)
-- Game: addappid(3244220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244221, 1, "4f1dcf1c8754ebe535efcdce9a662fc39701588510124052947612f1f24a795c")
