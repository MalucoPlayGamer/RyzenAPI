-- Lua provided by RyzenAPI
-- Game: DanceXR

-- MAIN APPLICATION
addappid(1905510)
addappid(2819100)
addappid(3801770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905511, 1, "079f4d3fd40c87f7df89090998e68b65ec12423b05c6a306bbf87428f4c54463")
addappid(2063770, 0, "bac5c6110f741dc536cc17e52ef0673126c36e52d7efed6b6c464852ef1ffc1f")

