-- Lua provided by RyzenAPI
-- Game: Game: 101 Cats in Thailand

-- MAIN APPLICATION
addappid(3530790)
-- Game: addappid(3530790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3530791, 1, "7186baa2d3685eb82afb8eea3d2a4ef28f3ff46d874025fa39d46dbc2da35b29")
