-- Lua provided by SkyAPI 
-- Game: Grandpa High on Retro
addappid(2967320)
addappid(2967321, 1, "ac63d2f66a8b09b38cd9f20fc73240a077cc73a8b1437ccbb5cb15af25dc7381")
