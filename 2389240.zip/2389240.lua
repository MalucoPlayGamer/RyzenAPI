-- Lua provided by SkyAPI 
-- Game: AppID 2389240
addappid(2389240)
addappid(2389241, 1, "9715448e13f9239fe300750f9469f9813576a81a9336d3f139cd515518e1bc3c")
