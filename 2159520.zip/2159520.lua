-- Lua provided by RyzenAPI 
-- Game: Desktop Farm Remastered
addappid(2159520)
addappid(2159521, 1, "6a845b646dd6ee72603ac40264d5eab5dea4d860ed89a2fe8e2919fe9419f862")
