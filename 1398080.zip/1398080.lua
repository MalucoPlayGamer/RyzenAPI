-- Lua provided by RyzenAPI
-- Game: Seaside Cafe Story

-- MAIN APPLICATION
addappid(1398080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398081, 1, "d4a1654a932dd91dfb9a5c2773cbbfa90e4cc4eb9683ec181948d2d4bf2ed04c")

