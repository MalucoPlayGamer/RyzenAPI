-- Lua provided by RyzenAPI
-- Game: Seaside Cafe Story

-- MAIN APPLICATION
addappid(1398080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1398081, 1, "d4a1654a932dd91dfb9a5c2773cbbfa90e4cc4eb9683ec181948d2d4bf2ed04c")

