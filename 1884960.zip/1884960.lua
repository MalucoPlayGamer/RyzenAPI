-- Lua provided by RyzenAPI
-- Game: addappid(1884960)

-- MAIN APPLICATION
addappid(1884960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884961, 1, "0acbf6cdc75d68d107090c10df5c2619a09d8e468ae73a1b951a653ea0e61e31")
