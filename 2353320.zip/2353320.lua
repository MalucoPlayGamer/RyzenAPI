-- Lua provided by RyzenAPI
-- Game: N+1：New life for unemployed youth！

-- MAIN APPLICATION
addappid(2353320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353321, 1, "bf4cdefb70dcb330ca27430f2bd258e405a981941c5751dd5027ca015b0fa3da")

