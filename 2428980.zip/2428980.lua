-- Lua provided by RyzenAPI
-- Game: Bye Sweet Carole

-- MAIN APPLICATION
addappid(2428980) -- Bye Sweet Carole
-- addappid(3902770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428983, 1, "4459aa4e531d8007450e4a278ffab68b61d229d38bc1801993ed63bd4275d455") -- Depot 2428983
