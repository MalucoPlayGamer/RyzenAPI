-- Lua provided by RyzenAPI
-- Game: Love Wish 2 18+ FREE DLC

-- MAIN APPLICATION
addappid(1274460)
-- Game: addappid(1274460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274460,0,"54f56846f0b171478aaab16e5ea4e7323d6146419f01245d5e324f58d02bbad9")
