-- Lua provided by RyzenAPI
-- Game: Color Splash: Predators

-- MAIN APPLICATION
addappid(2846340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846341, 1, "12a1ad2f2f91791b2f4293942c63f60fff44248a8949034264988568465f49bf")

