-- Lua provided by RyzenAPI
-- Game: addappid(2002220)

-- MAIN APPLICATION
addappid(2002220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002221, 1, "d4d948ea316e69a85da5404e1b7e1f1847c798bfb887b9d5ad83621f2e0f3339")
