-- Lua provided by RyzenAPI
-- Game: Atelier Yumia - "High-Class Dream Style" Costume for Yumia

-- MAIN APPLICATION
addappid(3742540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742540,0,"295336ca4111ed89a772313a004ad5013d180807409660547eda31691e498456")

