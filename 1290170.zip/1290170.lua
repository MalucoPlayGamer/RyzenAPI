-- Lua provided by SkyAPI 
-- Game: AppID 1290170
addappid(1290170)
addappid(1290171, 1, "60c87d45644e23a540a798f8d17f6ab0857750397d173dd5a3e9752650312cd3")
