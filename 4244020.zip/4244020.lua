-- Lua provided by RyzenAPI
-- Game: Mayor Match: City Builder & Match-3

-- MAIN APPLICATION
addappid(4244020)

