-- Lua provided by RyzenAPI
-- Game: AppID 2853810

-- MAIN APPLICATION
addappid(2853810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2853811, 1, "275174fba1621bc5a92121a561858b905bf9ef4e6224bc9abeaaa8636e6b5ad9")

