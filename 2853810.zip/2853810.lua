-- Lua provided by RyzenAPI
-- Game: 2853810

-- MAIN APPLICATION
addappid(2853810)
-- Game: addappid(2853810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853811, 1, "275174fba1621bc5a92121a561858b905bf9ef4e6224bc9abeaaa8636e6b5ad9")
