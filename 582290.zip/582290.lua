-- Lua provided by RyzenAPI
-- Game: Rest House

-- MAIN APPLICATION
addappid(582290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(582291, 1, "aa14b4d68f8e289f780ca758b739c6f83ac0db820ebcbbf72c7b6c67287970b0")
addappid(737790, 0, "fed826cb44a175c388883cc36fda12b446e25276c70faee361d440d687fd0298")

