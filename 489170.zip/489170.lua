-- Lua provided by RyzenAPI
-- Game: Game: Galaxy Reavers

-- MAIN APPLICATION
addappid(489170)
-- Game: addappid(489170)

-- MAIN APP DEPOTS / PACKAGES
addappid(489171, 1, "e67f8da4f6d1d27c62f996dfd844166d7606c93410b3e8dbe417ac7ac2da5f2c")
addappid(505650, 0, "37056c02609b6720c597b1a10dffd3244fdbc015ddfd891e508a09ebe401d3e5")
addappid(511130, 0, "7724596ffc72c249cc9bee8ce41637ea20bcd8a014857a8c4e15bdb2672aa9c8")
addappid(511131, 0, "9f0801186044b107ed8443385354a9220b624e4fa25f374650a4ce7724b644c8")
addappid(554200, 0, "0e141b8d0f5513be896454aea2cfbc3796bb532cee53760c91df8488ef43bca2")
