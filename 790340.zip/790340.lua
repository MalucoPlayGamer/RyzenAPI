-- Lua provided by RyzenAPI
-- Game: Achievement Hunter: Punk

-- MAIN APPLICATION
addappid(790340)

-- MAIN APP DEPOTS / PACKAGES
addappid(790341, 1, "dbc6a2100ec18dd5dc58b756595946202e1c9b7454375fb60ef65ed0cf927732")

