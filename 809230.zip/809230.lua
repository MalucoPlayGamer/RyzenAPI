-- Lua provided by RyzenAPI
-- Game: Unity of Command II

-- MAIN APPLICATION
addappid(809230)

-- MAIN APP DEPOTS / PACKAGES
addappid(809231, 1, "edd49b32d223ee901f9019726cccc21668c065c3197b087d638ba3d0a8356477")
addappid(809232, 1, "2f5a7a28364a93c46bf6d41d72ae8dedfa3310bde9cebac3562f27b64f4fc92a")
addappid(809233, 1, "62e57ddf1c13d1e89ae98eb80d41e71b494af096616c612b9e497fd8d5231f9d")
addappid(1322670, 0, "27b6c4f64f600ade70904654eff79c86bb0558b2cdb6495683ea298bade132c3")
addappid(1493580, 0, "fcb04ed2982b2ab8c04a3be4ee1e117d23e2922ce9eec360e9c4cc44f41c74e8")
addappid(1631480, 0, "df7d1c464eb21c11a3894b5497e05c2b19abfa2783c66bb17084dd3e6dd958de")
addappid(1676010, 0, "f2a23e630e9397d94c2a8e20518029c7aafe4d100ac1c53e3c01825572e91c7d")
addappid(1870350, 0, "2e59b2e2a0e00868e99e747748e28f4a0161889227c1ebc4fc91bbad6cc3770f")
addappid(1884780, 0, "86ef4ca1b421a665e26b562504e78b1e0efc16ec041ca6875c7396a134538fd1")
addappid(1911150, 0, "54465d45e588a28fcf58daa6d843dd1dc7881022db3ba328a82e432ef7080e72")
addappid(2307940, 0, "2184847c0e0f79df48d2748f4761474df7ffe959b1574d8687bc2120cdad6a03")
addappid(2711100, 0, "7f2e941181f7a34adc1e461e6b8e3981e608b31d54ff9a0271399fa53b9d3765")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3456990)
