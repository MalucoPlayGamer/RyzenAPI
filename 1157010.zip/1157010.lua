-- Lua provided by RyzenAPI
-- Game: Him and I

-- MAIN APPLICATION
addappid(1157010)
-- Game: addappid(1157010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157011, 1, "c2ed277cd232fed9e9268753ba445318a35858f35cfb744e096265069211460f")
