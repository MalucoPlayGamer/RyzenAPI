-- 2944340's Lua and Manifest Created by Hubcap Manifest
-- Unless
-- Created: July 30, 2026 at 12:13:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2944340, 1, "dbf452260e09f7fa94f120729af78fa4d614802049360b2ea508db3d42933e71") -- Unless
-- MAIN APP DEPOTS
addappid(2944341, 1, "95517c6cff2f7e8dc552838d3d8c2762c8230dea88a121826ee9025531e6cbe4") -- Depot 2944341
setManifestid(2944341, "578451991147260590", 108210827)
addappid(2944342, 1, "2b00c717882dfdb790b7b8f13235b587611123fee28758372f4c67b82ac6faaf") -- Depot 2944342
setManifestid(2944342, "8772485073899608597", 140915029)
addappid(2944343, 1, "2d85a0f91e765a13c5913582f41cdcf28ca363a1d23f8968fd889639bcfaf722") -- Depot 2944343
setManifestid(2944343, "7240744849269051437", 111560317)