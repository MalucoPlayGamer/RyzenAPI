-- Lua provided by RyzenAPI
-- Game: Unless

-- MAIN APPLICATION
addappid(2944340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2944341, 1, "95517c6cff2f7e8dc552838d3d8c2762c8230dea88a121826ee9025531e6cbe4")
