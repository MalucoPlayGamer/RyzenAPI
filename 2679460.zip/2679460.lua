-- Lua provided by RyzenAPI
-- Game: 2679460

-- MAIN APPLICATION
addappid(2679460)
-- Game: addappid(2679460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679461, 1, "0a945c91ddfaaca28d19da03981f783f8eb23a6dcc1121fb8c0936bb17fe0adb")
