-- Lua provided by RyzenAPI
-- Game: Metaphor: ReFantazio

-- MAIN APPLICATION
addappid(2679460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679461, 1, "0a945c91ddfaaca28d19da03981f783f8eb23a6dcc1121fb8c0936bb17fe0adb")

