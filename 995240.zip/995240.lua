-- Lua provided by RyzenAPI
-- Game: Game: RemiLore: Lost Girl in the Lands of Lore

-- MAIN APPLICATION
addappid(995240)
-- Game: addappid(995240)

-- MAIN APP DEPOTS / PACKAGES
addappid(995241, 1, "1f487c6799e5c7500b0d41f32c717fe457911e453afda77019a3b6d604655ea9")
