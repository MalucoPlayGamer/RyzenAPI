-- Lua provided by RyzenAPI
-- Game: BallBoi

-- MAIN APPLICATION
addappid(1115380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1115381, 1, "3ab370321994eacbc18443d45922e7338a32aa8b99e87591ea5a4df1d285e269")

