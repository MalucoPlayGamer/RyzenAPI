-- Lua provided by RyzenAPI
-- Game: BallBoi

-- MAIN APPLICATION
addappid(1115380)
-- Game: addappid(1115380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115381, 1, "3ab370321994eacbc18443d45922e7338a32aa8b99e87591ea5a4df1d285e269")
