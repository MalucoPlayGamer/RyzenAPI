-- Lua provided by RyzenAPI
-- Game: Tap Cats: Epic Card Battle

-- MAIN APPLICATION
addappid(864920)

-- MAIN APP DEPOTS / PACKAGES
addappid(864921, 1, "0575a85d8911b8294a7f4643f2674eedd802d5393ffc811fed4bf22340a217a3")

