-- Lua provided by RyzenAPI
-- Game: Abalone

-- MAIN APPLICATION
addappid(279480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(279481, 1, "ba695c04e45e99fdac484987e8a16d6ca6f87934a0909f3a29528fb4f9d068b1")

