-- Lua provided by RyzenAPI 
-- Game: Abalone
addappid(279480)
addappid(279481, 1, "ba695c04e45e99fdac484987e8a16d6ca6f87934a0909f3a29528fb4f9d068b1")
