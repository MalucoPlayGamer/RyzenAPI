-- Lua provided by RyzenAPI
-- Game: addappid(3283480)

-- MAIN APPLICATION
addappid(3283480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3283481, 1, "392d1d95dda808a2bb91095f1bf60b11a805cc068e3f8725922e35cc1f0e43d3")
