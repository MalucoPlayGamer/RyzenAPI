-- Lua provided by RyzenAPI
-- Game: The Sekimeiya: Spun Glass - Development Book

-- MAIN APPLICATION
addappid(1567090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567092,0,"075461b5d5496546ae956c3a34bcfeb2b5bc85ce474d21550dae4bd2a5677953")
