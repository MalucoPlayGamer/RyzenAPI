-- Lua provided by RyzenAPI
-- Game: 尼古丁大战芙兰王 Nicotine VS Fulanwang

-- MAIN APPLICATION
addappid(3378000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3378001, 1, "d1a4989f3be7ea3f77d04653ed53e532dd52100294f36278169c37f75ff9e676")

