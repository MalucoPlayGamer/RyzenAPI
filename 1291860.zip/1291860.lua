-- Lua provided by RyzenAPI
-- Game: Rough Justice: '84

-- MAIN APPLICATION
addappid(1291860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291862,0,"b61c572f38b6577c822cbb5cd3515817d3c94829f2d09f19f29a672f18a02a8e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2289840)
