-- Lua provided by RyzenAPI
-- Game: Rough Justice: '84

-- MAIN APPLICATION
addappid(1291860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291862,0,"b61c572f38b6577c822cbb5cd3515817d3c94829f2d09f19f29a672f18a02a8e")

