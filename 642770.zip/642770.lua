-- Lua provided by RyzenAPI 
-- Game: AppID 642770
addappid(642770)
addappid(642771, 1, "4413a75bf1ea3d6e131831e625c3839d3baa27fdcd625dbb4336b248e14eed7c")
