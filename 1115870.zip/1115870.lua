-- Lua provided by RyzenAPI
-- Game: 1115870

-- MAIN APPLICATION
addappid(1115870)
-- Game: addappid(1115870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115871, 1, "faed19be4ceb96f14711d62ee3d1272323eb93db1c721416f1034905d4cedd50")
