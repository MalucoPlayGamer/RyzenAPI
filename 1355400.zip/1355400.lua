-- Lua provided by RyzenAPI
-- Game: The Line

-- MAIN APPLICATION
addappid(1355400)
addappid(1479710)
-- Game: addappid(1355400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355401, 1, "b4c2ff89f3e94aa86282ffc6417bd885982f055d6b96c943d2826dd747ac2002")
