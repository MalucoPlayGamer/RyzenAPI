-- Lua provided by RyzenAPI 
-- Game: CTHULOOT Soundtrack
addappid(3655300)
addappid(3655301, 1, "fb78d4c86406d7ca4f5b1fa37fd4c8629e16dda2562bfe0d113267e867af91be")
addappid(3655302, 1, "f320084de21163f0ac784e58bb653dae3168dd57d0b9e423e36bf8b993cd9f39")
