-- Lua provided by RyzenAPI
-- Game: Fantasy Mosaics 22: Summer Vacation

-- MAIN APPLICATION
addappid(797310)

-- MAIN APP DEPOTS / PACKAGES
addappid(797311,0,"d9b24a7724246bf775789836dee04b090f67c2f4e9b7ad01e38c89c11ba3f2aa")

