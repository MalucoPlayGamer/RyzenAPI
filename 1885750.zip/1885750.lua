-- Lua provided by RyzenAPI
-- Game: Betrayal At Club Low

-- MAIN APPLICATION
addappid(1885750)
-- Game: addappid(1885750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885751, 1, "0ea2e12757f59cf35002fee9b852c95e55bb1bd51993fd1e60aa6d878ffd667b")
addappid(1885752, 1, "6ed52c4a29c1293bc7955d04f8ccf55adebcf7e32caa56650edc6621a9c2222b")
addappid(1885753, 1, "059a0e56bddb0c9362e846e636b2390479686f5c08edc16c6c488a7ad6367289")
