-- Lua provided by RyzenAPI
-- Game: Konrad's Kittens

-- MAIN APPLICATION
addappid(510740)

-- MAIN APP DEPOTS / PACKAGES
addappid(510741, 1, "ad0059c958787244a18e5ff02900c5b278759e9ca4ddadea144f576c27ea70b6")

