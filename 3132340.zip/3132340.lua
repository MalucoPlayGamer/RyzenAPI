-- Lua provided by RyzenAPI
-- Game: They See You

-- MAIN APPLICATION
addappid(3132340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3132341,0,"c3ce4bfdf6e75ffa245269e61a06351d26b88e93abd62fff654b4aeca0df4147")

