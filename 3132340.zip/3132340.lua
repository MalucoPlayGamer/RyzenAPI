-- Lua provided by RyzenAPI
-- Game: They See You

-- MAIN APPLICATION
addappid(3132340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132341,0,"c3ce4bfdf6e75ffa245269e61a06351d26b88e93abd62fff654b4aeca0df4147")

