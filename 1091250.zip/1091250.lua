-- Lua provided by SkyAPI 
-- Game: Total Party Kill
addappid(1091250)
addappid(1091251, 1, "a52f16230ee9bd0f1897992a4582cdf692164fdbd86d1b17b016b6a2b70d750e")
