-- Lua provided by SkyAPI 
-- Game: Idle Banshee Alliance
addappid(2255480)
addappid(2255481, 1, "fb056afd3833c38120e10e986328e0a2d18bbf8cdd54868fff07cef3b101e095")
