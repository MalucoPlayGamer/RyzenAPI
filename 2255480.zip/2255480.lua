-- Lua provided by RyzenAPI
-- Game: Idle Banshee Alliance

-- MAIN APPLICATION
addappid(2255480)
-- Game: addappid(2255480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255481, 1, "fb056afd3833c38120e10e986328e0a2d18bbf8cdd54868fff07cef3b101e095")
