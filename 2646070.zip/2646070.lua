-- Lua provided by SkyAPI 
-- Game: HeadLight
addappid(2646070)
addappid(2646071, 1, "43f5e1d4b2f526f95cdaf83e44857f14b8a855a46a6999b65aea799465b40bf9")
