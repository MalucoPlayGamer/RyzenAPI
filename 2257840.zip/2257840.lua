-- Lua provided by RyzenAPI
-- Game: Game: Arena Story～Rouge And Princess Knight～

-- MAIN APPLICATION
addappid(2257840)
-- Game: addappid(2257840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257841, 1, "5954945f8491022c0b111b4ebdab6a37fa2daec1564c56779703b258da7a2cc3")
addappid(2301720, 0, "64c88f86f3585e25652e487cf442945ee7f1dbe2798554f8af80b23358b8356e")
