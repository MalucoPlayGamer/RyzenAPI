-- Lua provided by RyzenAPI
-- Game: Stygian: Reign of the Old Ones

-- MAIN APPLICATION
addappid(779290)

-- MAIN APP DEPOTS / PACKAGES
addappid(779291, 1, "37f873aaa02255795220c926640e8ceca09ce3fbe9b85686f17f18fe84f7d2e1")
addappid(779292, 1, "e0a846fd36904229fbe83ea10f9b2705ce17374a492bb1729c27d2a2da54fd3d")
addappid(779293, 1, "b98ca338f6096f81ac2f02837bd683abe7d98f906a708ce4839a0a626c7651ef")
addappid(1160140, 0, "5f8df459ccbdf1db750d30565e861ce7e233124786d7c428cb6628919d91b7fb")

