-- Lua provided by RyzenAPI
-- Game: Dead Synchronicity: Tomorrow Comes Today

-- MAIN APPLICATION
addappid(339190)

-- MAIN APP DEPOTS / PACKAGES
addappid(339191, 1, "91724be708ade3b9b09307e91176def58ca294c80ab52a579cc59a2352d2a6a6")
addappid(339192, 1, "c55c9c007e76a5fc8f88ae1775098bcebf7592db7bb8a1ad9e113216b9e105a6")
addappid(339193, 1, "665e1635a789508502acda1d5e188b68783a5246fd3d2b42948176d6013a207f")
addappid(339194, 1, "74197fc8b65d6947949803dbc8d1a5c53a5ede18126aace1a341168f29a4c561")

