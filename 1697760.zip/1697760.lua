-- Lua provided by RyzenAPI
-- Game: 1697760

-- MAIN APPLICATION
addappid(1697760)
-- Game: addappid(1697760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697761, 1, "a87d9af0c1433cdac659ec0eb172d8388bae405f108e75b1806b6afe0e3e6d8a")
