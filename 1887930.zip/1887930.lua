-- Lua provided by RyzenAPI
-- Game: Idle Monster TD: Evolved

-- MAIN APPLICATION
addappid(1887930)

