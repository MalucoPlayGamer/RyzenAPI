-- Lua provided by RyzenAPI
-- Game: All Zombies Must Die!

-- MAIN APPLICATION
addappid(204140)
addappid(209362)

-- MAIN APP DEPOTS / PACKAGES
addappid(204141, 1, "2498ca2135abc310583fb32c74cfc1edff10a890ca4eef6dbac43408ad30e22c")

