-- 4499900's Lua and Manifest Created by Hubcap Manifest
-- Getting Stronger
-- Created: August 05, 2026 at 22:44:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4499900) -- Getting Stronger
-- MAIN APP DEPOTS
addappid(4499901, 1, "4bb184d0fc7b5438cbde85e2fb016fbfbee5e04b1f86bdf4e9c3d3609fce4dc6") -- Depot 4499901
setManifestid(4499901, "8519413251797663814", 52830249)
addappid(4499902, 1, "28bd97b6d750ce49d2aa671ca2e418b46cd548f66e53c4bad4c55f140c11d160") -- Depot 4499902
setManifestid(4499902, "7099735851906995082", 335238742)
addappid(4499903, 1, "0e3d29e213fd77ff5983ea6b6803991da715d53868e6cbecf316a6c6a497b04d") -- Depot 4499903
setManifestid(4499903, "792907108253018685", 52909053)