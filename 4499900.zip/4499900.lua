-- Lua provided by RyzenAPI
-- Game: Getting Stronger

-- MAIN APPLICATION
addappid(4499900) -- Getting Stronger

-- MAIN APP DEPOTS / PACKAGES
addappid(4499901, 1, "4bb184d0fc7b5438cbde85e2fb016fbfbee5e04b1f86bdf4e9c3d3609fce4dc6") -- Depot 4499901
addappid(4499902, 1, "28bd97b6d750ce49d2aa671ca2e418b46cd548f66e53c4bad4c55f140c11d160") -- Depot 4499902
addappid(4499903, 1, "0e3d29e213fd77ff5983ea6b6803991da715d53868e6cbecf316a6c6a497b04d") -- Depot 4499903

