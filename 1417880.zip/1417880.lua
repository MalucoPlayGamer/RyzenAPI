-- Lua provided by RyzenAPI
-- Game: Winter Ember

-- MAIN APPLICATION
addappid(1417880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417881, 1, "d7aeebcc220f2501993e44bf6979fc7038b2a0a5073c6a1414e975217d77db2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1954190)
