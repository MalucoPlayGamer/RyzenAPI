-- Lua provided by RyzenAPI
-- Game: Winter Ember

-- MAIN APPLICATION
addappid(1417880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417881, 1, "d7aeebcc220f2501993e44bf6979fc7038b2a0a5073c6a1414e975217d77db2a")

