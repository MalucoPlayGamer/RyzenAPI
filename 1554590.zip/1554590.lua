-- Lua provided by SkyAPI 
-- Game: ZED Patrol
addappid(1554590)
addappid(1554591, 1, "43dc35a6ff6747f27b9ff76c452f2e4f87aabb72e946bdd4dbffcc61970d9c11")
addappid(1554592, 1, "58569d346b68d989055618207b8b837eac3e403d0cd1fa944423734fde0d149e")
addappid(1554593, 1, "98eba2620a1a2a243ceac03bd8d9d42c49d0faf64849fdefba1744382033768c")
