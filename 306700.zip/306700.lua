-- Lua provided by RyzenAPI
-- Game: Iron Fisticle

-- MAIN APPLICATION
addappid(306700)

-- MAIN APP DEPOTS / PACKAGES
addappid(306701, 1, "45f2a8474d53391ace1b2f1fcec50a590ffa698941442e1b7e67429768673c67")
