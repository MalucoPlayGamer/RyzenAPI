-- Lua provided by RyzenAPI
-- Game: Game: AppID 3182890

-- MAIN APPLICATION
addappid(3182890)
-- Game: addappid(3182890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182891, 1, "fdca7a4115d9664482aa79ef2818077eea42e32a779f4c0e4a32f282a07223e8")
