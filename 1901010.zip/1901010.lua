-- Lua provided by RyzenAPI
-- Game: 1901010

-- MAIN APPLICATION
addappid(1901010)
-- Game: addappid(1901010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901011, 1, "ec2eb2bad57e9a935cf469efea561eda77aa10a3b940a08e274e6db092a0c5f7")
