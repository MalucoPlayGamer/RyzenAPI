-- Lua provided by RyzenAPI
-- Game: AppID 2611890

-- MAIN APPLICATION
addappid(2611890)
-- Game: addappid(2611890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2611891, 1, "81286a1c77b445d0d990218c22ee6c3bb2dd4c7831b379fa39c49b8a190c2122")
