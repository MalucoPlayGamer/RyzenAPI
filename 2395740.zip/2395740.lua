-- Lua provided by RyzenAPI
-- Game: Game: Stranded: Alien Dawn Official Soundtrack

-- MAIN APPLICATION
addappid(2395740)
-- Game: addappid(2395740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395741, 1, "dc1c529de2e123ec71aff98fb0e3d6e963efa928c2e1b80bd01478f2157cd88f")
addappid(2395742, 1, "076a8863135f3d3ac7df4a1c2605013bb24833c14f9ee8a7aae94a1282f6372d")
