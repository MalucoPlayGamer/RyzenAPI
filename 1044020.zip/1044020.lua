-- Lua provided by RyzenAPI
-- Game: 1044020

-- MAIN APPLICATION
addappid(1044020)
-- Game: addappid(1044020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044021, 1, "96a6f61720782c80d4efb4fbac5c0aadc9541fc8bc5f55070e906c654016b1d1")
addappid(1542191, 0, "62a4b4b826aa2758c1661ef8c57a881180acdacb7456347f82cb8e8b6901abdd")
