-- Lua provided by RyzenAPI
-- Game: Anomie

-- MAIN APPLICATION
addappid(625410)
addappid(689490)

-- MAIN APP DEPOTS / PACKAGES
addappid(625411, 1, "7a1d56f7f933bb110f03caf55a2f93c33cc55885aa83e475caa13cecddaf76c9")
