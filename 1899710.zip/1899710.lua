-- Lua provided by RyzenAPI
-- Game: addappid(1899710)

-- MAIN APPLICATION
addappid(1899710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899711, 1, "96dcc4cf68a381ef611e3a077e31c59db660fb5a45dce672c1fdb119b01dd7d7")
