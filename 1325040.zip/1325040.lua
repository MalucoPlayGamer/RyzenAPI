-- Lua provided by RyzenAPI
-- Game: Keylocker | Turn Based Cyberpunk Action

-- MAIN APPLICATION
addappid(1325040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325041, 1, "8a3d01ed8b2245173867d1aee2991451a1b1458f9816f890baa6a2df09aa366e")

