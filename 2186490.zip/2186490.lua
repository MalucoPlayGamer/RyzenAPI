-- Lua provided by RyzenAPI
-- Game: addappid(2186490)

-- MAIN APPLICATION
addappid(2186490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186491, 1, "c627a73e933aef59e30e4fff927da519217bc8cecfa9c85ef08355b107fce582")
