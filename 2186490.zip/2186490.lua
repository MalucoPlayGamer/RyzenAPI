-- Lua provided by SkyAPI 
-- Game: Refuge
addappid(2186490)
addappid(2186491, 1, "c627a73e933aef59e30e4fff927da519217bc8cecfa9c85ef08355b107fce582")
