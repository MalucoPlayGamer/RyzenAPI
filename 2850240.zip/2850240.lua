-- Lua provided by RyzenAPI
-- Game: 2850240

-- MAIN APPLICATION
addappid(2850240)
-- Game: addappid(2850240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850241, 1, "e709d30e3beceef0c4e05f3a204c79bd9fe5dcb46e639ea74e76d7875448a3d1")
