-- Lua provided by RyzenAPI
-- Game: Touhou Fantasia

-- MAIN APPLICATION
addappid(1010890)
addappid(1118431)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1010891, 1, "2e792d6949a5221a2fa1e7e739f63b7a689d746b90b73f2daf51071e127cdbc2")
