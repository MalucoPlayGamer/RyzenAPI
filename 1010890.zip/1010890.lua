-- Lua provided by RyzenAPI
-- Game: addappid(1010890)

-- MAIN APPLICATION
addappid(1010890)
addappid(1118431)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010891, 1, "2e792d6949a5221a2fa1e7e739f63b7a689d746b90b73f2daf51071e127cdbc2")
