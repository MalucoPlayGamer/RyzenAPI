-- Lua provided by RyzenAPI
-- Game: 537740

-- MAIN APPLICATION
addappid(537740)
addappid(751140)
-- Game: addappid(537740)

-- MAIN APP DEPOTS / PACKAGES
addappid(537741, 1, "672f5c0669b24f5065eafdd2d59003376fa7bab905cdaf802189474392da16fe")
