-- Lua provided by RyzenAPI
-- Game: Dino Dini's Kick Off™ Revival - Steam Edition

-- MAIN APPLICATION
addappid(537740)
addappid(751140)

-- MAIN APP DEPOTS / PACKAGES
addappid(537741, 1, "672f5c0669b24f5065eafdd2d59003376fa7bab905cdaf802189474392da16fe")

