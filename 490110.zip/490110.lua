-- Lua provided by RyzenAPI
-- Game: The Precinct

-- MAIN APPLICATION
addappid(490110)

-- MAIN APP DEPOTS / PACKAGES
addappid(490111, 1, "44bcc3870bf156385e37ff47e71ae28824fa905a542cdc8eaf05715799f78fc2")
