-- Lua provided by RyzenAPI
-- Game: Vaultbreakers

-- MAIN APPLICATION
addappid(306910)
-- Game: addappid(306910)

-- MAIN APP DEPOTS / PACKAGES
addappid(306912,0,"ca7591e7b1c28d798d34a416bc65f582509a72a6dc4e186507dbb2a0457077b9")
addtoken(306910,"12656941024338180373")
