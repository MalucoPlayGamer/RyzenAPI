-- Lua provided by RyzenAPI
-- Game: 1619310

-- MAIN APPLICATION
addappid(1619310)
-- Game: addappid(1619310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619311, 1, "746a4bc5852606ac0fe070cc74d3b16dd2556377f868c346992fd88ae1d5eb65")
