-- Lua provided by SkyAPI 
-- Game: SWAT Commander
addappid(1619310)
addappid(1619311, 1, "746a4bc5852606ac0fe070cc74d3b16dd2556377f868c346992fd88ae1d5eb65")
