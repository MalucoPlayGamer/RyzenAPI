-- Lua provided by RyzenAPI
-- Game: The 9th Day - 前传小说《那一日之前的少年少女们》

-- MAIN APPLICATION
addappid(991580)

-- MAIN APP DEPOTS / PACKAGES
addappid(991580,0,"87f78589d27c5166841978f176c00083bd5ee702028572201437e4df5378242a")

