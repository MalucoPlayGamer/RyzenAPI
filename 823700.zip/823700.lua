-- Lua provided by RyzenAPI
-- Game: AUTOCROSS MADNESS

-- MAIN APPLICATION
addappid(823700)

-- MAIN APP DEPOTS / PACKAGES
addappid(823703,0,"50abb00f539d19c5814b2eade52fe5b40ddb8495d06738ee366c095fbfcf1070")
addappid(823704,0,"da252a53ef330f8a1d75d2ea89688a71479659861b8970466bb26f8534a35321")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
