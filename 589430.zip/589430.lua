-- Lua provided by RyzenAPI
-- Game: Killer Elite – Time to Die

-- MAIN APPLICATION
addappid(589430)
-- Game: addappid(589430)

-- MAIN APP DEPOTS / PACKAGES
addappid(589431, 1, "1edd8a194edc66a115fe6b9e4513574074c48461ff9437e6c2923dfc52fa7d89")
