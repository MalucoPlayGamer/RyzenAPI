-- Lua provided by SkyAPI 
-- Game: AppID 947600
addappid(947600)
addappid(947601, 1, "bd2f853418c6ed40e1d94fbdacf58e8e0a09c053156a90b02b0135286b767fcf")
