-- Lua provided by RyzenAPI
-- Game: AppID 947600

-- MAIN APPLICATION
addappid(947600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(947601, 1, "bd2f853418c6ed40e1d94fbdacf58e8e0a09c053156a90b02b0135286b767fcf")

