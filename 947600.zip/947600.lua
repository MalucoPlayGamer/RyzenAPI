-- Lua provided by RyzenAPI
-- Game: AppID 947600

-- MAIN APPLICATION
addappid(947600)

-- MAIN APP DEPOTS / PACKAGES
addappid(947601, 1, "bd2f853418c6ed40e1d94fbdacf58e8e0a09c053156a90b02b0135286b767fcf")
