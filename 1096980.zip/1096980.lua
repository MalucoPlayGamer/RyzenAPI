-- Lua provided by RyzenAPI
-- Game: Game: AppID 1096980

-- MAIN APPLICATION
addappid(1096980)
-- Game: addappid(1096980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096981, 1, "ce9bf9eee2865ea5dd42bc0f0e23c42703fafef4c6dd612ff9f44906bc0c3963")
