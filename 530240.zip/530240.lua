-- Lua provided by RyzenAPI
-- Game: addappid(530240)

-- MAIN APPLICATION
addappid(530240)

-- MAIN APP DEPOTS / PACKAGES
addappid(530241, 1, "a1ca5231a488ddda0edf443fe58d27f2e90c1d4437038994cfc048f41a51a9b5")
