-- Lua provided by RyzenAPI
-- Game: Game: Powerlust

-- MAIN APPLICATION
addappid(1829520)
-- Game: addappid(1829520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829521, 1, "40f477218d983e651682c90551819813bdffca16adfbe2eca08cc99d787e0f0b")
