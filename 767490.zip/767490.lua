-- Lua provided by RyzenAPI
-- Game: Last Wood

-- MAIN APPLICATION
addappid(767490)
-- Game: addappid(767490)

-- MAIN APP DEPOTS / PACKAGES
addappid(767491, 1, "4966ff5edfc6ed6252eb140daa0732f94a2839fc9c0614cb907dd55ddd92dec8")
addappid(767492, 1, "497c83fa449a33d906fe7d9e2bc92e92d81b2c6f2f3b7b4f92857b6f65cb6918")
addappid(767493, 1, "9a20ed524ac9e2ee5993caaa4a709875186b656f0af3e10de336c0a7c32f7568")
addappid(767494, 1, "d2665061484286a9e805fd50626ce6a13d1965361ba3beb4412dbad9286bc5bc")
addappid(767495, 1, "93b2f29d5fa95f56ec386d561d39fcf2f582077fdb281e9196e361b1c54e1b6b")
addappid(767496, 1, "430c35cbfa59fd913ac09d0868d63acfca8bd430ccf1495d5769281bb573af83")
