-- Lua provided by RyzenAPI
-- Game: Shadow Corridor

-- MAIN APPLICATION
addappid(1025250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025251, 1, "dab6700339bc4b40a97556b01afc93b4b021494cddd77234b53f23b543a1ae78")
addappid(1363880, 0, "321a5e727c1e68255d2b601008f27fa224b20300afc2275cb2c0d1c373d2e1c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
