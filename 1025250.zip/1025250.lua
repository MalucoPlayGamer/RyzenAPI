-- Lua provided by RyzenAPI
-- Game: Shadow Corridor

-- MAIN APPLICATION
addappid(1025250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025251, 1, "dab6700339bc4b40a97556b01afc93b4b021494cddd77234b53f23b543a1ae78")
addappid(1363880, 0, "321a5e727c1e68255d2b601008f27fa224b20300afc2275cb2c0d1c373d2e1c8")

