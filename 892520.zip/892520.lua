-- Lua provided by RyzenAPI
-- Game: World War 3 PTE

-- MAIN APPLICATION
addappid(892520)

-- MAIN APP DEPOTS / PACKAGES
addappid(892521, 1, "e3485c0434908cfcb59184cb573ecb96597fdf3a0dbdf8f7b0c456ee9a61e04b")

