-- Lua provided by RyzenAPI
-- Game: AppID 892520

-- MAIN APPLICATION
addappid(892520)
-- Game: addappid(892520)

-- MAIN APP DEPOTS / PACKAGES
addappid(892521, 1, "e3485c0434908cfcb59184cb573ecb96597fdf3a0dbdf8f7b0c456ee9a61e04b")
