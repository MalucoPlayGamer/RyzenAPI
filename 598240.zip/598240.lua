-- Lua provided by RyzenAPI
-- Game: Stupid Raft Battle Simulator

-- MAIN APPLICATION
addappid(598240)

-- MAIN APP DEPOTS / PACKAGES
addappid(598241, 1, "3652cb00a9f87eaeb65bf5b92b5bd8cc50d68eabcdaa49d86e38b97aac1a0cb7")

