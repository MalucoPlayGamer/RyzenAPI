-- Lua provided by RyzenAPI
-- Game: Brothel Tycoon

-- MAIN APPLICATION
addappid(3084180)
addappid(4087470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3084181, 1, "a0cf7b59a7a217e6a8c831cfd4548be477d2f921ea22da2b90c36ba35169fbb8")
