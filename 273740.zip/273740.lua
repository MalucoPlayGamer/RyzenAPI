-- Lua provided by RyzenAPI
-- Game: Extreme Roads USA

-- MAIN APPLICATION
addappid(273740)

-- MAIN APP DEPOTS / PACKAGES
addappid(273741, 1, "2b206a1a29e83bbe5b891e09d8a210dbb1e264669c8e6dcf4ddfa987b5a45bb6")
addappid(273742, 1, "7ae88c80d4a59414e3e9a5854f3c3e537a03050ade83995f5ce9080e573aea43")
