-- Lua provided by SkyAPI 
-- Game: Bug Butcher
addappid(2010390)
addappid(2010391, 1, "df410d7c0e28091597711b5a5e3f462d8b6b7b064dc7e26bcac4d72d9c3fa84f")
