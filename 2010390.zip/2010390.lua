-- Lua provided by RyzenAPI
-- Game: Bug Butcher

-- MAIN APPLICATION
addappid(2010390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010391, 1, "df410d7c0e28091597711b5a5e3f462d8b6b7b064dc7e26bcac4d72d9c3fa84f")
