-- Lua provided by RyzenAPI
-- Game: Game: Munin

-- MAIN APPLICATION
addappid(281750)
-- Game: addappid(281750)

-- MAIN APP DEPOTS / PACKAGES
addappid(281751, 1, "a490a1dc5ee13f6bff0fadb0c0bc1fc42e9dec539f3f14587775658cb42c2b95")
addappid(281752, 1, "bc979151a7101c700ded943706a8402c54d579454bea6dbd69f176d8d0e11997")
addappid(281753, 1, "cb8d9a747fa82d9643b71f54c2d781f5b8de96c57b35ad4462cf079d7e0a575b")
