-- Lua provided by RyzenAPI
-- Game: Game: AppID 2257960

-- MAIN APPLICATION
addappid(2257960)
-- Game: addappid(2257960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257961, 1, "a532d9768607f56ba568a16ad5c11840b70cbac356973cd1c72914a2e5232c2c")
