-- Lua provided by SkyAPI 
-- Game: AppID 228300
addappid(228300)
addappid(228301, 1, "7c4a97797cc41611893bd11617023023d54800e431ba6482ac9386da35ab6602")
addappid(228982)
addappid(228983)
addappid(228990)
addappid(229003)
addappid(229004)
addappid(237800, 0, "ede5043264b54c2cd36d6d1ea2076ad74843779c3c1a4ab4dcf7048595fea44e")
