-- Lua provided by RyzenAPI
-- Game: Destiny Encore

-- MAIN APPLICATION
addappid(3072780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3072781, 1, "272aede05cbd9bd70dadb3b94c0d4a2860b57d040eaba06dcf82b490c44438bf")
