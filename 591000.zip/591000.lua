-- Lua provided by RyzenAPI
-- Game: AppID 591000

-- MAIN APPLICATION
addappid(591000)
-- Game: addappid(591000)

-- MAIN APP DEPOTS / PACKAGES
addappid(591001, 1, "cb0834059ef9df990aa8e377ce608027af2cf7eea3bdab3d46940a676741ce24")
addappid(591002, 1, "cbea0757fc2a6e984654ef77e3ac7f76fc2481f682650277773f5a70205dd071")
