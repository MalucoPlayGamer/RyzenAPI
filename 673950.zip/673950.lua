-- Lua provided by RyzenAPI
-- Game: Game: Farm Together

-- MAIN APPLICATION
addappid(673950)
-- Game: addappid(673950)

-- MAIN APP DEPOTS / PACKAGES
addappid(673951, 1, "f7978b9ae7c7afc0ff181092aa419f38354600be3d68cabb4f29dfcf13c24763")
addappid(673952, 1, "7b41c827c8d02489b9e740eb1e8f4758c02a1c69acc36808b6d2f6f44fa99940")
addappid(673953, 1, "74d9f43b42fef624644f277f9b88cb27ba39220d85c1bea109fc2486fd3608fa")
addappid(673954, 1, "af099d1bfd549173a7a323c759e669ed3f74db41d49f72f84ff423b57589315a")
