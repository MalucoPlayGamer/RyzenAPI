-- Lua provided by RyzenAPI
-- Game: Farm Together

-- MAIN APPLICATION
addappid(673950)
addappid(919770)
addappid(924150)
addappid(924151)
addappid(939060)
addappid(965350)
addappid(995590)
addappid(995640)
addappid(1033790)
addappid(1051380)
addappid(1079990)
addappid(1113700)
addappid(1139990)
addappid(1795210)
addappid(1795250)
addappid(1853450)
addappid(1903470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(673951, 1, "f7978b9ae7c7afc0ff181092aa419f38354600be3d68cabb4f29dfcf13c24763")
addappid(673952, 1, "7b41c827c8d02489b9e740eb1e8f4758c02a1c69acc36808b6d2f6f44fa99940")
addappid(673953, 1, "74d9f43b42fef624644f277f9b88cb27ba39220d85c1bea109fc2486fd3608fa")
addappid(673954, 1, "af099d1bfd549173a7a323c759e669ed3f74db41d49f72f84ff423b57589315a")

