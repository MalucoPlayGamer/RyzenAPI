-- Lua provided by RyzenAPI
-- Game: addappid(2565960)

-- MAIN APPLICATION
addappid(2565960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565961, 1, "90cc65a70ef8f873791de53528202b6a2d669f5b6d4fb38d3bd375f60934dcf3")
