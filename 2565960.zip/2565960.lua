-- Lua provided by RyzenAPI
-- Game: Only Up! 1

-- MAIN APPLICATION
addappid(2565960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565961, 1, "90cc65a70ef8f873791de53528202b6a2d669f5b6d4fb38d3bd375f60934dcf3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
