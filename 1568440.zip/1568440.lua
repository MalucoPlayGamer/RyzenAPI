-- Lua provided by RyzenAPI
-- Game: Sands of Fire

-- MAIN APPLICATION
addappid(1568440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568441, 1, "100f9b78b7a2cd75a9c10638a7ab006c8f845b5ab3655345fe2cb049a6945da6")
