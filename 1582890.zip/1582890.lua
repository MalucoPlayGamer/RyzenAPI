-- Lua provided by RyzenAPI
-- Game: 1582890

-- MAIN APPLICATION
addappid(1582890)
-- Game: addappid(1582890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582891, 1, "dba1ecdb350cd48d06254a4928c7a620023ec9ccb2e89884dee260459b032ff1")
