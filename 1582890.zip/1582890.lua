-- Lua provided by RyzenAPI 
-- Game: AppID 1582890
addappid(1582890)
addappid(1582891, 1, "dba1ecdb350cd48d06254a4928c7a620023ec9ccb2e89884dee260459b032ff1")
