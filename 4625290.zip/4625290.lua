-- Lua provided by RyzenAPI
-- Game: Incident Archives - Flight 882

-- MAIN APPLICATION
addappid(4625290)
