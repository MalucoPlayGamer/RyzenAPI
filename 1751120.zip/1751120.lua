-- Lua provided by RyzenAPI
-- Game: AppID 1751120

-- MAIN APPLICATION
addappid(1751120)
-- Game: addappid(1751120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751121, 1, "52f7aa0b29d0b82aad6d18ed7ff0845e0f9be297f117ddf2f873389c270d6e1e")
