-- 3932890's Lua and Manifest Created by Hubcap Manifest
-- Escape from Tarkov
-- Created: August 03, 2026 at 15:13:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 32
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3932890, 1, "a43bd6d20ab68d15d5edc9aec0debd22d72fdec082c14b60593dc6e16cf79aac") -- Escape from Tarkov
-- MAIN APP DEPOTS
addappid(3932891, 1, "8cf57d9d3c35a5371e82341a2a0aa834b0f4edc929ae700566d6b2ebe66e7210") -- Depot 3932891
setManifestid(3932891, "6241875791120114796", 83410442313)
addappid(3932892, 1, "6a03571f28db62fb25aa43c1c39bf870b8848c97b3624dd0e846023438411904") -- Depot 3932892
setManifestid(3932892, "4240688870308818781", 417366678)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4090950) -- Escape from Tarkov Left Behind - Expansion Pack
addappid(4090970) -- Escape from Tarkov Prepare for Escape - Expansion Pack
addappid(4090980) -- Escape From Tarkov The Unheard - Expansion Pack
addappid(4091290) -- Escape from Tarkov PVE Zone
addappid(4229530) -- Escape from Tarkov USEC - Gold Squadron
addappid(4229540) -- Escape from Tarkov BEAR - Senezh
addappid(4407420) -- Escape from Tarkov BEAR - Arktika
addappid(4407430) -- Escape from Tarkov USEC - Fahrenheit
addappid(4490930) -- Escape from Tarkov TarCoin Ingame Currency
addappid(4531790) -- Escape from Tarkov BEAR - Classic
addappid(4531800) -- Escape from Tarkov BEAR - Cyclone
addappid(4531810) -- Escape from Tarkov BEAR - G99
addappid(4531820) -- Escape from Tarkov BEAR - Instructor
addappid(4531830) -- Escape from Tarkov BEAR - Morozko
addappid(4531840) -- Escape from Tarkov BEAR - Nord
addappid(4531850) -- Escape from Tarkov BEAR - Oldschool
addappid(4531860) -- Escape from Tarkov BEAR - Vacation
addappid(4531870) -- Escape from Tarkov BEAR - Zaslon
addappid(4531890) -- Escape from Tarkov USEC - Day off
addappid(4531900) -- Escape from Tarkov USEC - Deadly Frog
addappid(4531910) -- Escape from Tarkov USEC - Night Patrol
addappid(4531920) -- Escape from Tarkov USEC - Woodland Infiltrator
addappid(4531930) -- Escape from Tarkov USEC - Urban Responder
addappid(4531940) -- Escape from Tarkov USEC - AC Ranger Green
addappid(4531950) -- Escape from Tarkov USEC - Vanguard
addappid(4531960) -- Escape from Tarkov USEC - Special Ops
addappid(4531970) -- Escape from Tarkov USEC - Scadi
addappid(4589090) -- Escape from Tarkov USEC - ScavTac
addappid(4589100) -- Escape from Tarkov BEAR - Three Stripes
addappid(4764340) -- Escape from Tarkov BEAR - Slavianka
addappid(4764350) -- Escape from Tarkov USEC - GEN4
addappid(4898900) -- Escape from Tarkov TarCoin Special Offer