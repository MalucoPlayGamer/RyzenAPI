-- Lua provided by RyzenAPI
-- Game: Game: Burger Joint Simulator

-- MAIN APPLICATION
addappid(3411420)
-- Game: addappid(3411420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3411421, 1, "e9a47d0951ebaef5a6af3cf50dc6ee42f86c625a9c0d82ef98dd9ae907cdf41e")
