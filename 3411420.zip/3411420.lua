-- Lua provided by RyzenAPI
-- Game: Burger Joint Simulator

-- MAIN APPLICATION
addappid(3411420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3411421, 1, "e9a47d0951ebaef5a6af3cf50dc6ee42f86c625a9c0d82ef98dd9ae907cdf41e")

