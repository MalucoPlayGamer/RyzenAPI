-- Lua provided by RyzenAPI
-- Game: Girl Abducted

-- MAIN APPLICATION
addappid(3373050)
-- Game: addappid(3373050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3373051, 1, "585c0c4580115f09051c32079c972dc060710b9451ada386be1f52fcba295014")
