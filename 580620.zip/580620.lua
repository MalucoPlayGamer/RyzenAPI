-- Lua provided by RyzenAPI
-- Game: addappid(580620)

-- MAIN APPLICATION
addappid(580620)

-- MAIN APP DEPOTS / PACKAGES
addappid(580620,0,"612ff17c5ccf72474d746c8b29cb7d98890f8be0521b50ce98c67cc4dc5c7294")
