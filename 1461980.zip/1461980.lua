-- Lua provided by RyzenAPI
-- Game: 九州：立志

-- MAIN APPLICATION
addappid(1461980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461981, 1, "58e0f8f158a90b34033b559e57704bfbf86b3d6e2dbb92206eed33c6f5b673ce")
