-- Lua provided by RyzenAPI 
-- Game: DreadOut: Keepers of The Dark
addappid(418950)
addappid(418951, 1, "7ba9944a344da325a9294a32aa97fed0996026db50673dfb60dfc701cd884cad")
addappid(418952, 1, "8a3e47a53e85e5a60eef9f1db470c0ef0ad1ce7cd9fa01e18c5944901b778704")
addappid(1359580, 0, "a0a49060ccb597d202a5880a79f60c0242985969c7b87e83ac517a080eaefcb3")
