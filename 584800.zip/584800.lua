-- Lua provided by RyzenAPI
-- Game: Game: Civil War: Battle of Petersburg

-- MAIN APPLICATION
addappid(584800)
-- Game: addappid(584800)

-- MAIN APP DEPOTS / PACKAGES
addappid(584801, 1, "122351d74c36837b0a888927b1adda6b01f3163b89a98471f0500b0f9da3a45c")
addappid(584802, 1, "17ea1860b8cde2278d456e1410b2b8216c92d885bb7cf1dc14b0ad05e2522694")
addappid(584803, 1, "af9372cbd511d1e414d21564d41f996f6dcd24e92cfad7ed2e9632c5cffff331")
