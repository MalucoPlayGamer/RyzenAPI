-- Lua provided by RyzenAPI
-- Game: addappid(3198320)

-- MAIN APPLICATION
addappid(3198320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198321, 1, "a68fc92a25b2bf2e6d42ee742bff66d75ec40c1c92792805843b22375ab07851")
