-- Lua provided by RyzenAPI
-- Game: Burden of Command™

-- MAIN APPLICATION
addappid(887490)

-- MAIN APP DEPOTS / PACKAGES
addappid(887492,0,"916ee0bcee2bd55d9845e33454842d93f6c9d2cecf429bdeab6650607e69e98d")
