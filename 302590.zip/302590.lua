-- Lua provided by RyzenAPI
-- Game: Of Guards And Thieves

-- MAIN APPLICATION
addappid(302590)
addappid(500290)
addappid(598390)
addappid(666200)
addappid(701980)
addappid(824890)
addappid(1164380)
addappid(1262980)
addappid(1262981)

