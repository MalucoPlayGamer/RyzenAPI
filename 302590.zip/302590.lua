-- Lua provided by RyzenAPI
-- Game: Of Guards And Thieves

-- MAIN APPLICATION
addappid(302590)

