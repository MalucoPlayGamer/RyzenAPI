-- Lua provided by RyzenAPI
-- Game: AppID 908010

-- MAIN APPLICATION
addappid(908010)

-- MAIN APP DEPOTS / PACKAGES
addappid(908011, 1, "38a2e3cf9316e582a14b2cc835c25e9d16007eff0943bbdcd5a87a70a4096b77")

