-- Lua provided by RyzenAPI
-- Game: No King No Kingdom - Shield of Great Protectors

-- MAIN APPLICATION
addappid(1933250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933250,0,"97aec42c2b6d247f3b21019528050e317fafa7df167465f61171500c95aff857")

