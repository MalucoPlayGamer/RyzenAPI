-- Lua provided by RyzenAPI
-- Game: A Wizard's Lizard

-- MAIN APPLICATION
addappid(280040)
-- Game: addappid(280040)

-- MAIN APP DEPOTS / PACKAGES
addappid(280041, 1, "b23f6c8be9007d1d63f5bc1ca595baf69a497cccc854c94732199bdfe6781f00")
addappid(280042, 1, "f574ce8f8ee562289c22391ec4f5b3cc0c4de8a86d4e6d45f5bf903fa85d5725")
addappid(280043, 1, "90100dc27d478501141caae8e1a0d2193023b556b7f0f62ad0dabeec0d312890")
addappid(280044, 1, "42b162ff280e6f5e7b08bbc3025645e1199a1046964e4901d4ee99af47e258bb")
addappid(280045, 1, "b2498fede2e56c89b13c633c24d1b222217f641f3d15d3c408e3a5c3ad156a1d")
