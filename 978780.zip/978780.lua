-- Lua provided by RyzenAPI
-- Game: AppID 978780

-- MAIN APPLICATION
addappid(978780)

-- MAIN APP DEPOTS / PACKAGES
addappid(978781, 1, "6c1f00459c6e87fccd19c861a3905933c304256f5f3e7ffea2b870ce0c521b0d")

