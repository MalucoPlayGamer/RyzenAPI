-- Lua provided by RyzenAPI
-- Game: AppID 978780

-- MAIN APPLICATION
addappid(978780)
addappid(1292300)
addappid(1292301)
addappid(1292302)
addappid(1292303)
addappid(1292304)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(978781, 1, "6c1f00459c6e87fccd19c861a3905933c304256f5f3e7ffea2b870ce0c521b0d")

