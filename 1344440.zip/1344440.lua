-- Lua provided by RyzenAPI
-- Game: Spaceflux

-- MAIN APPLICATION
addappid(1344440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344441, 1, "2d9926ad019b4892554f6cd9ce55db6ffb03ac0f408ff23a06af70a1a7b49865")

