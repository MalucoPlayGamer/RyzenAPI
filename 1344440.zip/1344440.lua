-- Lua provided by RyzenAPI
-- Game: Spaceflux

-- MAIN APPLICATION
addappid(1344440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344441, 1, "2d9926ad019b4892554f6cd9ce55db6ffb03ac0f408ff23a06af70a1a7b49865")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3381870)
addappid(3385760)
addappid(3385770)
addappid(3385780)
addappid(3385800)
addappid(3385810)
addappid(3385830)
addappid(3385860)
addappid(3388030)
addappid(3388040)
addappid(3388070)
addappid(3388200)
addappid(3544270)
addappid(3544280)
addappid(3544290)
addappid(3544300)
addappid(3544310)
addappid(3544320)
addappid(3544340)
addappid(3563630)
addappid(3563640)
addappid(3563660)
