-- Lua provided by SkyAPI 
-- Game: Artis Demo
addappid(2165320)
addappid(2165321, 1, "6422a7d32393ddc9677a8e5e3c98049d74298831b653725f78190b11c86e0940")
