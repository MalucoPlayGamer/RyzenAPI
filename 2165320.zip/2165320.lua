-- Lua provided by RyzenAPI
-- Game: Game: Artis Demo

-- MAIN APPLICATION
addappid(2165320)
-- Game: addappid(2165320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165321, 1, "6422a7d32393ddc9677a8e5e3c98049d74298831b653725f78190b11c86e0940")
