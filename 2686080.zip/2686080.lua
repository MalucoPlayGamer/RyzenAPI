-- Lua provided by RyzenAPI
-- Game: Sad Satan

-- MAIN APPLICATION
addappid(2686080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686081, 1, "c78c7f2525baf9693b748a25f7ed3a40c5ad626ba64b014d518213b67739cf66")
