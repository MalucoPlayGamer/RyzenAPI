-- Lua provided by RyzenAPI
-- Game: Game: Touhou Artificial Dream in Arcadia

-- MAIN APPLICATION
addappid(2248430)
-- Game: addappid(2248430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248431, 1, "d2896332e1231d545e5fcc8b6301e4f1143a0113bee66061d9acd890d52932e8")
addappid(2248432, 1, "a490ac4ef8a5f449a88df1c4a37bebbd549deb3ecf0fff6dc849da900ab95b72")
