-- Lua provided by RyzenAPI
-- Game: SD Shin Kamen Rider Rumble Shin Godzilla Pack

-- MAIN APPLICATION
addappid(2231715)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231715,0,"20de8e337ff8da34f05ed319e14c1fa5bac3c04a9435c8271eb709b4913159ac")

