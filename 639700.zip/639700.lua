-- Lua provided by RyzenAPI
-- Game: 639700

-- MAIN APPLICATION
addappid(639700)
-- Game: addappid(639700)

-- MAIN APP DEPOTS / PACKAGES
addappid(639700,0,"c1d295fb66d07aa7e86118a3e618c800560a5f44e0995e984e903f407b81cfc4")
