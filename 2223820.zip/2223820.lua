-- Lua provided by RyzenAPI
-- Game: Supermarket Times

-- MAIN APPLICATION
addappid(2223820)
-- Game: addappid(2223820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223821, 1, "d3ca85e3678272707dd4941a5055418e8783cb7129985b366e4bff01c724bd3a")
