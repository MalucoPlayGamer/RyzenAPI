-- Lua provided by SkyAPI 
-- Game: Supermarket Times
addappid(2223820)
addappid(2223821, 1, "d3ca85e3678272707dd4941a5055418e8783cb7129985b366e4bff01c724bd3a")
