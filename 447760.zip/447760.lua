-- Lua provided by RyzenAPI
-- Game: Game: AppID 447760

-- MAIN APPLICATION
addappid(447760)
-- Game: addappid(447760)

-- MAIN APP DEPOTS / PACKAGES
addappid(447761, 1, "1595a4a27377995552b03e26ffcc175823416e264e963226cb71c0a47674fbf1")
