-- Lua provided by RyzenAPI
-- Game: AppID 774201

-- MAIN APPLICATION
addappid(774201)
addappid(1066320)

-- MAIN APP DEPOTS / PACKAGES
addappid(774202, 1, "bf4c8aec9ff3c9bf1f542f5bad624260cb3dd04cffba760393d97f0aacc78dd6")
