-- Lua provided by RyzenAPI
-- Game: Game: Hidden Breaking Bed Top-Down 3D

-- MAIN APPLICATION
addappid(2623560)
-- Game: addappid(2623560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623561, 1, "94a9e5608c441af8000058e5c24aeb54c6fc6b3baa24026adf1dc5e7bbf0b160")
