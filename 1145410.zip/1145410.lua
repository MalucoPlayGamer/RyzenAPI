-- Lua provided by RyzenAPI
-- Game: 1145410

-- MAIN APPLICATION
addappid(1145410)
-- Game: addappid(1145410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145411, 1, "5c5c89f0c67efc16a1dd5b37ed0fec1870770b8b1d26d33f45483827d9f36d66")
