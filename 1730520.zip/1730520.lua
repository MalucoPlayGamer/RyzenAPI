-- Lua provided by RyzenAPI
-- Game: 1000 hidden snails

-- MAIN APPLICATION
addappid(1730520) -- 1000 hidden snails

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1730521, 1, "6b1239c319f1731a5f79e988ce28637c57807e63e8583a282b2e91b954c07a68") -- Depot 1730521

