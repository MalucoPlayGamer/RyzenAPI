-- Lua provided by RyzenAPI
-- Game: ANIME - World War II

-- MAIN APPLICATION
addappid(1159640)
addappid(1169180)
addappid(1169181)
addappid(1169182)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159641,0,"0c8acd4caef2085259eca3dbd37ae3406021cdf050be7320c361430f7e72a3c2")

