-- Lua provided by RyzenAPI
-- Game: 1159640

-- MAIN APPLICATION
addappid(1159640)
-- Game: addappid(1159640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159641, 1, "0c8acd4caef2085259eca3dbd37ae3406021cdf050be7320c361430f7e72a3c2")
