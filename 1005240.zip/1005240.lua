-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles Illustrations & Anime Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1005240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005241, 1, "ca76c73881bb2164be62cd5962f965896b9d6643c56ada9f01a8f8ffc1d6325d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1534110)
addappid(1534112)
addappid(1534113)
addappid(1534114)
addappid(1534115)
addappid(1534117)
addappid(1534118)
addappid(1534119)
addappid(1534120)
addappid(1534121)
addappid(1534122)
addappid(1534123)
addappid(1534124)
addappid(1534125)
addappid(1534126)
addappid(1534127)
addappid(1534129)
addappid(1534130)
addappid(1534131)
addappid(1534132)
addappid(1534133)
addappid(1534135)
addappid(1561410)
addappid(1577781)
addappid(1577782)
addappid(1577783)
addappid(1577784)
addappid(1577785)
addappid(1577786)
addappid(1577789)
addappid(1577790)
addappid(1577791)
addappid(1577792)
addappid(1577793)
addappid(1577796)
addappid(1577799)
addappid(1577800)
addappid(1577801)
addappid(1577802)
addappid(1603120)
addappid(1603121)
addappid(1603162)
