-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles Illustrations & Anime Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1005240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005241, 1, "ca76c73881bb2164be62cd5962f965896b9d6643c56ada9f01a8f8ffc1d6325d")
