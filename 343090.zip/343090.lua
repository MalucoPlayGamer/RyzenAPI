-- Lua provided by RyzenAPI
-- Game: SimpleRockets

-- MAIN APPLICATION
addappid(343090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(343091, 1, "e593b75c3adb8763394ff863aa778ec01f43ef296b8acdecd911ec812fde7698")
addappid(343092, 1, "7b7cff1e765f1e0fe542c1c330d3e887a2265cc051453990528fd95b1cdd84ca")

