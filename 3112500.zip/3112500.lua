-- Lua provided by RyzenAPI
-- Game: Game: Church Simulator

-- MAIN APPLICATION
addappid(3112500)
-- Game: addappid(3112500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3112501, 1, "0ac844d95e35ac0e9158e404c439ad06bedd621872e906dd924bc38067e1187d")
