-- Lua provided by RyzenAPI
-- Game: 2685660

-- MAIN APPLICATION
addappid(2685660)
-- Game: addappid(2685660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685660,0,"cc0b59ac911cd40a3cd44ae65b636028fbd95e1ba6f5d5f28aecbc188aa53197")
