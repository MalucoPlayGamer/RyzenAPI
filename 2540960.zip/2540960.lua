-- Lua provided by SkyAPI 
-- Game: 2099 Gravity Havoc
addappid(2540960)
addappid(2540961, 1, "a2cf1eefa0dd2ca16cd33ed23c0f26ead334e75815741c7918b1db35197c5845")
addappid(2540962, 1, "4560e80b6dfbd6d1f0e7e1e5445b90a9bbbab1cf06f887f5912a1ef2146b0335")
