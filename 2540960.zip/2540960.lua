-- Lua provided by RyzenAPI
-- Game: 2099 Gravity Havoc

-- MAIN APPLICATION
addappid(2540960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540961, 1, "a2cf1eefa0dd2ca16cd33ed23c0f26ead334e75815741c7918b1db35197c5845")
addappid(2540962, 1, "4560e80b6dfbd6d1f0e7e1e5445b90a9bbbab1cf06f887f5912a1ef2146b0335")
