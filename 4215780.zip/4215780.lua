-- Lua provided by RyzenAPI
-- Game: Hidden Things Beach Elves

-- MAIN APPLICATION
addappid(4215780)

