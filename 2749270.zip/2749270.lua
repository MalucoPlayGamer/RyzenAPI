-- Lua provided by SkyAPI 
-- Game: Hunky City
addappid(2749270)
addappid(2749271, 1, "3515fc2a310a5be5ede16f730ccdb02699fe601ed4c321d9fceef772ff52c73f")
