-- Lua provided by RyzenAPI
-- Game: XMusicVisualizer

-- MAIN APPLICATION
addappid(1061820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061821, 1, "a4961b7278ed44408dee9a7702a30ee354b3b6db1ac210211fded551808e0291")

