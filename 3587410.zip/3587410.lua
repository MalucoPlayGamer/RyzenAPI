-- Lua provided by RyzenAPI 
-- Game: ReSetna Official Soundtrack
addappid(3587410)
addappid(3587411, 1, "df54652f583a2bd9c33b7d2a2f08f3d0596f07edc2a7a43ea412f24e8eac6b23")
