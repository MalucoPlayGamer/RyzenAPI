-- Lua provided by RyzenAPI
-- Game: 3587410

-- MAIN APPLICATION
addappid(3587410)
-- Game: addappid(3587410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3587411, 1, "df54652f583a2bd9c33b7d2a2f08f3d0596f07edc2a7a43ea412f24e8eac6b23")
