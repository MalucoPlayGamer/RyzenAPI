-- Lua provided by RyzenAPI 
-- Game: Epic Fantasy Battle Simulator
addappid(1724440)
addappid(1724441, 1, "207e7b731dced4d692e0248fb7a8242e609154bfa2c91060cd2686f88391274a")
