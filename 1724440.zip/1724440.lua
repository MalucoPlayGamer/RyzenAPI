-- Lua provided by RyzenAPI
-- Game: Game: Epic Fantasy Battle Simulator

-- MAIN APPLICATION
addappid(1724440)
-- Game: addappid(1724440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724441, 1, "207e7b731dced4d692e0248fb7a8242e609154bfa2c91060cd2686f88391274a")
