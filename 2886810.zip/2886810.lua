-- Lua provided by RyzenAPI
-- Game: Guidelines for the Book of Changes

-- MAIN APPLICATION
addappid(2886810)
-- Game: addappid(2886810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2886811, 1, "8fb04b0efb232bc2dc1fa631c84c9c84b7030fc56052196f6812583bdf101e32")
