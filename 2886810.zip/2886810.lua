-- Lua provided by RyzenAPI
-- Game: Guidelines for the Book of Changes

-- MAIN APPLICATION
addappid(2886810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2886811, 1, "8fb04b0efb232bc2dc1fa631c84c9c84b7030fc56052196f6812583bdf101e32")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
