-- Lua provided by RyzenAPI
-- Game: CryptoRIG

-- MAIN APPLICATION
addappid(801950)

-- MAIN APP DEPOTS / PACKAGES
addappid(801951,0,"321bd73a5cb03e06e4d3f28b74975a3a56c0af077dccbad3812000de04a9d2de")

