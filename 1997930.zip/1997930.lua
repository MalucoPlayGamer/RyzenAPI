-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1997930)
addappid(1997931)
-- Game: addappid(1997930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997932,0,"98f7dff5b8ab14e6f8e5742eff3086109ba1b51bb18ee006ef8278f272cb3fc2")
