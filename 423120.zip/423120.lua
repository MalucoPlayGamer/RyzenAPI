-- Lua provided by RyzenAPI
-- Game: Community College Hero: Trial by Fire

-- MAIN APPLICATION
addappid(423120)

-- MAIN APP DEPOTS / PACKAGES
addappid(423121, 1, "1c9e51ebf9690c8c1b5a320da178130f856545043e87a946c113778883fabe15")
