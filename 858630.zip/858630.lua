-- Lua provided by RyzenAPI
-- Game: 858630

-- MAIN APPLICATION
addappid(858630)
-- Game: addappid(858630)

-- MAIN APP DEPOTS / PACKAGES
addappid(858631, 1, "d7d38c3412f23632e45d75e6d68e98e931c741c92e9a3e7c8ef4fb90d4277900")
addappid(858632, 1, "afd49ce7c3a14c4e04871e2e2c4d3fa84124cff49c51ddb35cc8d8248e16c308")
