-- Lua provided by RyzenAPI
-- Game: Game: Fury Unleashed Soundtrack

-- MAIN APPLICATION
addappid(1232750)
-- Game: addappid(1232750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232751, 1, "e1dec488a4f313fb54850eafcdf2eb2e04762f86f64058fee5f3364987af7dad")
addappid(1232752, 1, "5597a3f2a935a0cf52a649787eaa8b9e90326ee65ba86aa89de4a4b2627f86ae")
