-- Lua provided by RyzenAPI
-- Game: 1684166

-- MAIN APPLICATION
addappid(1684166)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684166,0,"adea8679f808d42def2075a1cf51944d15f7cb033e8fc2fcad55a74c092bdf1a")
