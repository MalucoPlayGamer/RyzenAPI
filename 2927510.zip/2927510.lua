-- Lua provided by RyzenAPI
-- Game: Game: KilaFlow

-- MAIN APPLICATION
addappid(2927510)
-- Game: addappid(2927510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927511, 1, "ced57c37eb606e43ee29647f613c74e5914903f2fb3180504d55f05c79c90c00")
