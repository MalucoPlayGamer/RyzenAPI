-- Lua provided by RyzenAPI
-- Game: RP7 Soundtrack

-- MAIN APPLICATION
addappid(3179090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179091, 1, "1611e86e7ad96ca8d20f980af4d21829b878174a806665ea8d3807117c7ccb34")

