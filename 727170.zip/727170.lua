-- Lua provided by SkyAPI 
-- Game: Old School FOTD
addappid(727170)
addappid(727171, 1, "c2935eaab365184103358bbae4bbab6c0bb4ab0ad3093b21d314a33aa2393ec0")
addappid(727172, 1, "a804a514078243906a6f1f873894fd6de688bb8c761f804017ba21eb203c277b")
addappid(727173, 1, "76bdc7d494fd8652e6afc36265811ee662152a8121c044d32dd852e79cb94359")
