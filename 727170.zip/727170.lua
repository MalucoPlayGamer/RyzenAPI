-- Lua provided by RyzenAPI
-- Game: Old School FOTD

-- MAIN APPLICATION
addappid(727170)

-- MAIN APP DEPOTS / PACKAGES
addappid(727171, 1, "c2935eaab365184103358bbae4bbab6c0bb4ab0ad3093b21d314a33aa2393ec0")
addappid(727172, 1, "a804a514078243906a6f1f873894fd6de688bb8c761f804017ba21eb203c277b")
addappid(727173, 1, "76bdc7d494fd8652e6afc36265811ee662152a8121c044d32dd852e79cb94359")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
