-- Lua provided by RyzenAPI
-- Game: addappid(2176510)

-- MAIN APPLICATION
addappid(2176510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176512,0,"6377b34f6e9b49b03ec4833c4b5e502706ecba8b686991e5dcb1a75ca789a33b")
