-- Lua provided by RyzenAPI
-- Game: Super Duper Multitasking

-- MAIN APPLICATION
addappid(640290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(640291, 1, "fbf608ec8fdf5bce62dbfd54f304931ce48d644ea62bbb97e2045265a6bff69b")

