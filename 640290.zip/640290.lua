-- Lua provided by RyzenAPI
-- Game: Super Duper Multitasking

-- MAIN APPLICATION
addappid(640290)

-- MAIN APP DEPOTS / PACKAGES
addappid(640291, 1, "fbf608ec8fdf5bce62dbfd54f304931ce48d644ea62bbb97e2045265a6bff69b")

