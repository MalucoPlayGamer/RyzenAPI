-- Lua provided by RyzenAPI 
-- Game: 100 Fantasy Cats
addappid(3141080)
addappid(3141081, 1, "25ef2cb67a2468f3fc9997b12f116ea6df37d90db5ec9a15109b5b70cad04c43")
addappid(3794330, 0, "5ef81219b66d06992bd35996ad72dba4264f901587688f7022b8e0a3dbfbd838")
