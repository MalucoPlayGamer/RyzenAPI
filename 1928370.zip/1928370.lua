-- Lua provided by RyzenAPI
-- Game: Exodemic

-- MAIN APPLICATION
addappid(1928370)
-- Game: addappid(1928370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928371, 1, "87cb8745e1c00899d1c67f1a265b4cea04b76239a23ccb2bc66c568c0e0e0fc1")
