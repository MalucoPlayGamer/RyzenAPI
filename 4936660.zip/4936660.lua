-- 4936660's Lua and Manifest Created by Hubcap Manifest
-- Peg Champ
-- Created: August 24, 2026 at 13:19:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4936660) -- Peg Champ
-- MAIN APP DEPOTS
addappid(4936661, 1, "a8333e8aac498a4d6f63e996be573fade319340499eb543f4216041c8dc76d51") -- Depot 4936661
setManifestid(4936661, "1730516958675573776", 138970072)