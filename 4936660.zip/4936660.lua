-- Lua provided by RyzenAPI
-- Game: Peg Champ

-- MAIN APPLICATION
addappid(4936660) -- Peg Champ

-- MAIN APP DEPOTS / PACKAGES
addappid(4936661, 1, "a8333e8aac498a4d6f63e996be573fade319340499eb543f4216041c8dc76d51") -- Depot 4936661

