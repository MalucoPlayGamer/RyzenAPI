-- Lua provided by RyzenAPI
-- Game: Signal Simulator

-- MAIN APPLICATION
addappid(839310)

-- MAIN APP DEPOTS / PACKAGES
addappid(839311, 1, "ee1b59253f5bd06ddf8f15b2640adc2f9668634cc90fd8ff9d5d4c5a05c23bfe")
addappid(839312, 1, "e91b99116f9d6e407cf254eda2753f44c170927194d5dee3b606326d54bf1c1d")

