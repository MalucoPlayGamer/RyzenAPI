-- Lua provided by RyzenAPI
-- Game: Yaengard

-- MAIN APPLICATION
addappid(1545830)
-- Game: addappid(1545830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545831, 1, "42cad3ebbf0b54dedd7b9e48cca391fec4e221b00c2d58d3527cc609f72a94bc")
