-- Lua provided by RyzenAPI
-- Game: Sophia the Traveler

-- MAIN APPLICATION
addappid(1602540)
addappid(2850160)
-- Game: addappid(1602540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602541, 1, "e6a2337699cbd4fac9c79fa3722df63986a98073162df82b1bb205a12c29e4da")
