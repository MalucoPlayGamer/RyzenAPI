-- Lua provided by RyzenAPI
-- Game: Dawn

-- MAIN APPLICATION
addappid(605610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(605611, 1, "75207bf67d4f2120485d84d012acb03008cd1fa9e2b98f06f4a52d9cf89c1f0f")

