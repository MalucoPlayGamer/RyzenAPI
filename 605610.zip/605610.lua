-- Lua provided by RyzenAPI 
-- Game: Dawn
addappid(605610)
addappid(605611, 1, "75207bf67d4f2120485d84d012acb03008cd1fa9e2b98f06f4a52d9cf89c1f0f")
