-- Lua provided by RyzenAPI
-- Game: 100 Cats New York

-- MAIN APPLICATION
addappid(2782380)

