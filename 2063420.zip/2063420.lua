-- Lua provided by RyzenAPI
-- Game: CozyTyper

-- MAIN APPLICATION
addappid(2063420)
-- Game: addappid(2063420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063421, 1, "7eaf94e13602c9650f460cc51194ea67da8dcfa91d48255d3cfc3ba717df9e76")
addappid(2063422, 1, "a7e29e3a7e2a13a05bc2d425209c8faa4b78bd0468bc2d29450ba43e54f06b89")
addappid(2063423, 1, "52e8399806cd7c35bd15131d4759c941fcfcf215954856af33fc00426140fe07")
