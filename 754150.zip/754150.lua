-- Lua provided by RyzenAPI
-- Game: Rolling Line

-- MAIN APPLICATION
addappid(754150)
addappid(3685460)
-- Game: addappid(754150)

-- MAIN APP DEPOTS / PACKAGES
addappid(754151, 1, "ad04c94991815777be39a3c6261cdd6935c1c1cebb3a87006759ec3dce5edc7e")
