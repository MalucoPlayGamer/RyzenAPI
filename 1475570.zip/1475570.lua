-- Lua provided by RyzenAPI 
-- Game: AppID 1475570
addappid(1475570)
addappid(1475571, 1, "9738f35b19b81b498f684bf86fb2bcac175191aaeb8e7e02929eafbcb302c949")
