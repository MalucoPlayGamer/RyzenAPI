-- Lua provided by RyzenAPI
-- Game: 3553320

-- MAIN APPLICATION
addappid(3553320)
-- Game: addappid(3553320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3553321, 1, "c3fefd52b99d6e00b048d55b607eea014349ea42147fa0aad8c60115bf223134")
