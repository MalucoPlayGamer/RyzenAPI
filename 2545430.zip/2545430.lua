-- Lua provided by RyzenAPI
-- Game: 2545430

-- MAIN APPLICATION
addappid(2545430)
-- Game: addappid(2545430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545430,0,"50ef04fd9aa277d2c1067f9bf0567ad040522c3d54f9ede961a7946f12af7b2a")
