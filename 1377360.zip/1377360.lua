-- Lua provided by RyzenAPI
-- Game: Game: Vampires' Melody

-- MAIN APPLICATION
addappid(1377360)
-- Game: addappid(1377360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377361, 1, "122b2d74b3bc9e514ca9e517200f26335af59d33bc10e8d4414a0df8e7e6c17c")
addappid(1377362, 1, "105d2da6ad91b747bf08b2827c5e0ac01f3c7a26a5cff80f789377fa3fe93209")
addappid(1377363, 1, "246a2e0fd9e0656e6a1b8f68b8bcbe48911e907460abe46aa2b0c0bc395d43c3")
addappid(1437810, 0, "201a81323141888982660d0385473b34b4e39a93e9a98fd5dbf11edba49f4616")
