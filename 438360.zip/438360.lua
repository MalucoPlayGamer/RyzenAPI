-- Lua provided by RyzenAPI
-- Game: Infinitesimal Point

-- MAIN APPLICATION
addappid(438360)

-- MAIN APP DEPOTS / PACKAGES
addappid(438361, 1, "2a356efbf3077ae40b8873d002b9df091da8296318d41e53590a536f314c5ff8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
