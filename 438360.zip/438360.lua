-- Lua provided by RyzenAPI
-- Game: addappid(438360)

-- MAIN APPLICATION
addappid(438360)

-- MAIN APP DEPOTS / PACKAGES
addappid(438361, 1, "2a356efbf3077ae40b8873d002b9df091da8296318d41e53590a536f314c5ff8")
