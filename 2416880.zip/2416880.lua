-- Lua provided by SkyAPI 
-- Game: Duck Life 9: The Flock
addappid(2416880)
addappid(2416881, 1, "7d7831fc7943a6d66fcc0f40764bdefa0c4827c0d80cb8eead0f662b2d375797")
