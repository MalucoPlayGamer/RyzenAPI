-- Lua provided by RyzenAPI
-- Game: Duck Life 9: The Flock

-- MAIN APPLICATION
addappid(2416880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416881, 1, "7d7831fc7943a6d66fcc0f40764bdefa0c4827c0d80cb8eead0f662b2d375797")
