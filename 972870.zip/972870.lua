-- Lua provided by RyzenAPI
-- Game: addappid(972870)

-- MAIN APPLICATION
addappid(972870)

-- MAIN APP DEPOTS / PACKAGES
addappid(972870,0,"a05587d5e3d65a5b3cb8b1d2512487d78056a3ae75574e83c4b27625b41fa3fd")
