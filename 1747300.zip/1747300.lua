-- Lua provided by RyzenAPI
-- Game: Selobus Fantasy

-- MAIN APPLICATION
addappid(1747300)
addappid(2359140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747301, 1, "a1361e46d86ef93cce6a7ce34f216f44c5d9bc54b5459aba144831a1e9765e0c")
