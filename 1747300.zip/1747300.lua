-- Lua provided by SkyAPI 
-- Game: Selobus Fantasy
addappid(1747300)
addappid(1747301, 1, "a1361e46d86ef93cce6a7ce34f216f44c5d9bc54b5459aba144831a1e9765e0c")
addappid(2359140)
