-- Lua provided by RyzenAPI
-- Game: Game: Pleh!

-- MAIN APPLICATION
addappid(2191550)
-- Game: addappid(2191550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191551, 1, "81f5662572f778eca9f41946addf4f1664bc3d96ff179245b1d0fedccf0bb7b2")
