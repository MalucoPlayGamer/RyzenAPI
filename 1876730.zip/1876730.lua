-- Lua provided by RyzenAPI
-- Game: Game: 蔚蓝月下的回忆~SAPPHIRE MOON-FOREVER MEMORIES

-- MAIN APPLICATION
addappid(1876730)
addappid(2167710)
-- Game: addappid(1876730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876731, 1, "3d24abbd9f8e8f951f6928107fcf6cb6903a7218c65c3b6df8106c0869554f25")
