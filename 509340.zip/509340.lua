-- Lua provided by RyzenAPI
-- Game: addappid(509340)

-- MAIN APPLICATION
addappid(509340)

-- MAIN APP DEPOTS / PACKAGES
addappid(509341, 1, "eb6c4ddd60e60f649a51ffdcb90a910f71e9575a6cf0b53f987ad4d2cca1b664")
