-- Lua provided by RyzenAPI 
-- Game: Girls Shop
addappid(1810490)
addappid(1810491, 1, "503428fec91bab21bc063412ce8560827da467c1f82a5e08951d96c3af2c8d13")
