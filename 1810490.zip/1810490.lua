-- Lua provided by RyzenAPI
-- Game: Girls Shop

-- MAIN APPLICATION
addappid(1810490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810491, 1, "503428fec91bab21bc063412ce8560827da467c1f82a5e08951d96c3af2c8d13")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
