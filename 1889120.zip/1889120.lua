-- Lua provided by SkyAPI 
-- Game: The Forked Road
addappid(1889120)
addappid(1889121, 1, "246ee96e527cfb6c8b969d718c78c097f4995ae1b670a8241e80f55aeccf9159")
