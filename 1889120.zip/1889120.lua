-- Lua provided by RyzenAPI
-- Game: The Forked Road

-- MAIN APPLICATION
addappid(1889120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889121, 1, "246ee96e527cfb6c8b969d718c78c097f4995ae1b670a8241e80f55aeccf9159")

