-- Lua provided by RyzenAPI
-- Game: The Forked Road

-- MAIN APPLICATION
addappid(1889120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1889121, 1, "246ee96e527cfb6c8b969d718c78c097f4995ae1b670a8241e80f55aeccf9159")

