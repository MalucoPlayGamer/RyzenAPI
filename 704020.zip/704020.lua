-- Lua provided by RyzenAPI
-- Game: AppID 704020

-- MAIN APPLICATION
addappid(704020)
-- Game: addappid(704020)

-- MAIN APP DEPOTS / PACKAGES
addappid(704021, 1, "3104d0e53956de150339daa35b4e70194dda24a79567f93d413d3fb166bcb7b8")
