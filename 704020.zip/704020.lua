-- Lua provided by RyzenAPI
-- Game: Master Arena

-- MAIN APPLICATION
addappid(704020)
addappid(2016030)
addappid(2857110)
addappid(2857130)
addappid(2857140)
addappid(2857150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(704021, 1, "3104d0e53956de150339daa35b4e70194dda24a79567f93d413d3fb166bcb7b8")

