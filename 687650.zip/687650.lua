-- Lua provided by RyzenAPI
-- Game: addappid(687650)

-- MAIN APPLICATION
addappid(687650)

-- MAIN APP DEPOTS / PACKAGES
addappid(687651, 1, "6476bdb6d1f5282f3fc02f0dabb6259e3c231c2d269ad70b712ed7a21d1a2220")
