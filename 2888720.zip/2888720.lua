-- Lua provided by RyzenAPI
-- Game: Great God Grove Digital Artbook

-- MAIN APPLICATION
addappid(2888720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888720,0,"419f754a1f358c70ebb3c723a4a2b6b933976f4173218cd94d17e39c1ca18055")
