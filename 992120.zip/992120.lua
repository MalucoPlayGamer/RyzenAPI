-- Lua provided by RyzenAPI
-- Game: Inch by Inch

-- MAIN APPLICATION
addappid(992120)

-- MAIN APP DEPOTS / PACKAGES
addappid(992121, 1, "06fa419a348b2c70160710828a8457e0bdd6c25854a8e77c53a386d9bb3dcdbe")

