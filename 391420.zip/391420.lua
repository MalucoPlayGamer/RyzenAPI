-- Lua provided by RyzenAPI
-- Game: Game: Gun Rocket

-- MAIN APPLICATION
addappid(391420)
-- Game: addappid(391420)

-- MAIN APP DEPOTS / PACKAGES
addappid(391421, 1, "9f4c6bc5df7127e31493b8dec33ea1085a104b681558a10610ba8a487010c05f")
addappid(391422, 1, "d420f1ec46fac0c1fa1c6331391a3ef1578fdb1d3502454a6f69e5fd0cfc9290")
addappid(456510, 0, "e849c717d8aa8ea63a822f3b539d8541ec756fb7c2e8db3b23e47c7067147c87")
