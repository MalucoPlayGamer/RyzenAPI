-- Lua provided by RyzenAPI
-- Game: Princess Maker Refine

-- MAIN APPLICATION
addappid(583040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(583041, 1, "6a09ad407046461769b85aca28ac1d6743cae3fcbde899883e4ae6ddeacd711a")
addappid(583042, 1, "06bc284d54f1b972fd5cacc2a9b860ebeed69c1cc296f9c6c4a35aec6ec3d88c")
addappid(583043, 1, "e45c3590dffbe4ddcc8272eb5905b5d80e34edbdc05d4492a689fb31072b27ab")
addappid(583044, 1, "d7d6d53dc852f05623b62f859a7d6a6fa070b7fbbae6bc5d59d18ea29c953cd1")
addappid(583045, 1, "786faeea96d83e4e498916b1ac8484dec955d198761564c103768157985f4bf1")

