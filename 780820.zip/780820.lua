-- Lua provided by RyzenAPI
-- Game: XOXO Blood Droplets

-- MAIN APPLICATION
addappid(780820)
-- Game: addappid(780820)

-- MAIN APP DEPOTS / PACKAGES
addappid(780821, 1, "9b954252e3107c14d4dcabf5558614a14c454bcbad0ae6b40cc18f661cb6fd81")
