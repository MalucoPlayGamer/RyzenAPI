-- Lua provided by RyzenAPI
-- Game: addappid(870690)

-- MAIN APPLICATION
addappid(870690)

-- MAIN APP DEPOTS / PACKAGES
addappid(870691, 1, "caf2eb70248ee1bf52a9d22d4b737f9c8e1790cc2886afa1a5952695580a35ed")
