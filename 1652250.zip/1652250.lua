-- Lua provided by SkyAPI 
-- Game: Tales & Tactics
addappid(1652250)
addappid(1652251, 1, "b33bc6731d4f57b8cbd8877c58b0f35fca6516ce330c14048fb59aadaf364a36")
