-- Lua provided by RyzenAPI
-- Game: Tales & Tactics

-- MAIN APPLICATION
addappid(1652250)
addappid(4802820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1652251, 1, "b33bc6731d4f57b8cbd8877c58b0f35fca6516ce330c14048fb59aadaf364a36")

