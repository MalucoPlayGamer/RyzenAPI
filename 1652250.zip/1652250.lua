-- Lua provided by RyzenAPI
-- Game: Tales & Tactics

-- MAIN APPLICATION
addappid(1652250)
-- Game: addappid(1652250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652251, 1, "b33bc6731d4f57b8cbd8877c58b0f35fca6516ce330c14048fb59aadaf364a36")
