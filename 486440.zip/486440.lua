-- Lua provided by RyzenAPI
-- Game: Mosh Pit Simulator

-- MAIN APPLICATION
addappid(486440)
-- Game: addappid(486440)

-- MAIN APP DEPOTS / PACKAGES
addappid(486441, 1, "c742726ef9efc896035d4ff3075d08b0274ea9cd32810e46226986507e78877d")
