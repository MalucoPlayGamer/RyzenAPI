-- Lua provided by RyzenAPI
-- Game: 386620

-- MAIN APPLICATION
addappid(386620)
-- Game: addappid(386620)

-- MAIN APP DEPOTS / PACKAGES
addappid(386621, 1, "1a90fee2f279e5c1acdcad21efcecdbbd77474616d2a958fa50d7f14462f7fa6")
addappid(386622, 1, "48c67f2ec5227bd6d1a6efc37ceffeb23ee574f37d41d78dac58d67538aea225")
addappid(386623, 1, "ee37aecce3eef1f9eddce48a06d42062780d8955b98366e40a122816e7fc756e")
