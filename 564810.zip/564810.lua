-- Lua provided by RyzenAPI
-- Game: Ticket

-- MAIN APPLICATION
addappid(564810)
-- Game: addappid(564810)

-- MAIN APP DEPOTS / PACKAGES
addappid(564811, 1, "c58b982c8b1d7e141473626f06ad5e04ae384c7a058d5fffbd8c0e5b922f0e6b")
