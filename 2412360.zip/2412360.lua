-- Lua provided by RyzenAPI
-- Game: Phantom Thief Effie Demo

-- MAIN APPLICATION
addappid(2412360)
-- Game: addappid(2412360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412363,0,"69f0af1485526dfe88c27f6e9ad95e85104cba3ec1825330e473bb3a4ee22fff")
