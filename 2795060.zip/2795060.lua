-- Lua provided by RyzenAPI
-- Game: DREAMIO: AI-Powered Adventures

-- MAIN APPLICATION
addappid(2795060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795061, 1, "ef4305110b445059ce0979096ce45df0f73fae89d4fa49738ade891680fc7c9f")
