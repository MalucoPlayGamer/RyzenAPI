-- Lua provided by RyzenAPI
-- Game: The Fielder's Choice

-- MAIN APPLICATION
addappid(805120)

-- MAIN APP DEPOTS / PACKAGES
addappid(805121,0,"b78c3de054d16409edbdae188a87e3f07daa62659c1ef87ff6b6f434f7f796fe")

