-- Lua provided by RyzenAPI
-- Game: 15 Days

-- MAIN APPLICATION
addappid(342990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(342991, 1, "fafd91a13d29a045ce8e8905f79b3ef9b1fb3810352dd41fbdd24f09d1a78f64")
addappid(342992, 1, "33e9585a97203310446bcd03aee8202fd9e06a427957b6390e36cc56f429aafc")
addappid(342993, 1, "eca04586d6f0b88fa5be1cc12c3f5530fddf7b8989f07c27df511e2e8ffb4ee1")
addappid(342994, 1, "254d56eea01ba93c5acf0e3264279be0da563123a20f8a92cd41df33c099994e")
addappid(342995, 1, "5d32603f863ba134931b1dabf07c6903b3a39c6001915ac1a7af8cab0d0e9fb8")
addappid(342996, 1, "c533b126c0ca3e40bdcb5f42d6d32cb2108a1f1c2545384ba4342390d028ff48")
addappid(342997, 1, "ff384afbaec409a25d8b5b73a75de5a505bf5c93ffbd27bc5aecce2879a86c91")

