-- Lua provided by RyzenAPI
-- Game: Ranchbound

-- MAIN APPLICATION
addappid(3962040) -- Ranchbound

-- MAIN APP DEPOTS / PACKAGES
addappid(3962041, 1, "96d7668d922b5278ce8e1c562b98b76e7ddd4214889b79db93b25cd6ab6051a0") -- Depot 3962041

