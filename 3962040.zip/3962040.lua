-- 3962040's Lua and Manifest Created by Hubcap Manifest
-- Ranchbound
-- Created: August 05, 2026 at 22:36:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3962040) -- Ranchbound
-- MAIN APP DEPOTS
addappid(3962041, 1, "96d7668d922b5278ce8e1c562b98b76e7ddd4214889b79db93b25cd6ab6051a0") -- Depot 3962041
setManifestid(3962041, "8310561427511307438", 631909658)