-- Lua provided by RyzenAPI
-- Game: Empyrion - Galactic Survival Dedicated Server

-- MAIN APPLICATION
addappid(530870)

-- MAIN APP DEPOTS / PACKAGES
addappid(530871, 1, "c54d338ba26d66063170bac5269c438ec026d6943bc068c084cc9ac192150170")
