-- Lua provided by RyzenAPI
-- Game: Game: AppID 2940540

-- MAIN APPLICATION
addappid(2940540)
-- Game: addappid(2940540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940541, 1, "471c8bacc434fbeb0d99795f77060010ef28b7290ff026d293f159c934edbc4c")
