-- Lua provided by RyzenAPI
-- Game: addappid(3345970)

-- MAIN APPLICATION
addappid(3345970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345971, 1, "d5ce6a539e7c565344ec2a700cff5ab7ac6f1002ce5566de4077dbf4c9036df3")
