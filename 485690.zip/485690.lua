-- Lua provided by RyzenAPI
-- Game: Hope Lake

-- MAIN APPLICATION
addappid(485690)
-- Game: addappid(485690)

-- MAIN APP DEPOTS / PACKAGES
addappid(485691, 1, "9adf492831d73fc21239b7dc0644a6623f99740c439afc44a99d51c9d9398d1e")
