-- Lua provided by RyzenAPI 
-- Game: One Night With Stalin
addappid(1916290)
addappid(1916291, 1, "9010e2ad4ddc9e917f0b0ce21ca275513593d926de68683c1ac2b24216493d1b")
