-- Lua provided by RyzenAPI
-- Game: Game: One Night With Stalin

-- MAIN APPLICATION
addappid(1916290)
-- Game: addappid(1916290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916291, 1, "9010e2ad4ddc9e917f0b0ce21ca275513593d926de68683c1ac2b24216493d1b")
