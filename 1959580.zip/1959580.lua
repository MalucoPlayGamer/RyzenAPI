-- Lua provided by RyzenAPI
-- Game: Game: Supermoves: World of Parkour

-- MAIN APPLICATION
addappid(1959580)
-- Game: addappid(1959580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959581, 1, "a67bb8576275fc93a82dbaf32462239021ca2f3388a06fb96d65d4b81f4fa75d")
