-- Lua provided by RyzenAPI
-- Game: Game: AppID 3251630

-- MAIN APPLICATION
addappid(3251630)
-- Game: addappid(3251630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251631, 1, "269dce285cb6f2ae0062231d81a30de9d120363c1591ab19ac897cc3f9088cec")
