-- Lua provided by RyzenAPI
-- Game: Drift Survivor

-- MAIN APPLICATION
addappid(2598080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598081, 1, "7118c55aac864db947fdfa359e7c4184ffeffb949076a8b26de0f88d58b99173")
