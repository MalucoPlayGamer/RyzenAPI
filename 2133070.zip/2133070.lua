-- Lua provided by RyzenAPI
-- Game: VR Basketball Sweetie

-- MAIN APPLICATION
addappid(2133070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133071, 1, "c9fb0b9c6674578e695eb225491034913520e2737f3d4fa084bd5b7f0e158fd7")
