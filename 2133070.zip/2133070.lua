-- Lua provided by RyzenAPI
-- Game: VR Basketball Sweetie

-- MAIN APPLICATION
addappid(2133070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133071, 1, "c9fb0b9c6674578e695eb225491034913520e2737f3d4fa084bd5b7f0e158fd7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
