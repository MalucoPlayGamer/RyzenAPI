-- Lua provided by SkyAPI 
-- Game: VR Basketball Sweetie
addappid(2133070)
addappid(2133071, 1, "c9fb0b9c6674578e695eb225491034913520e2737f3d4fa084bd5b7f0e158fd7")
