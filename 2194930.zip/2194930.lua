-- Lua provided by RyzenAPI
-- Game: Evil Awaits

-- MAIN APPLICATION
addappid(2194930)
addappid(3441250)
addappid(3441260)
addappid(4106430)
addappid(4106440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194931,0,"fd289741f27ace947613153f354d22d9617607e09e6cc77562f49b73cadfd1aa")

