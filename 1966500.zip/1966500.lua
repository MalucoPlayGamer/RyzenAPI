-- Lua provided by RyzenAPI
-- Game: Game: Goo Gladiators

-- MAIN APPLICATION
addappid(1966500)
-- Game: addappid(1966500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966501, 1, "4ca951c933c811792ba0d8264ddcf923d20df313875fdd88b222baa5997b6ca2")
