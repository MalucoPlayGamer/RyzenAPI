-- Lua provided by RyzenAPI
-- Game: Goo Gladiators

-- MAIN APPLICATION
addappid(1966500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966501, 1, "4ca951c933c811792ba0d8264ddcf923d20df313875fdd88b222baa5997b6ca2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
