-- Lua provided by RyzenAPI
-- Game: Slime Rancher 2

-- MAIN APPLICATION
addappid(1657630)
-- Game: addappid(1657630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657631, 1, "a37c1409dc2c7880fc988d25d9fa333438bab756f17f7d0fc27015c8ef2faed3")
