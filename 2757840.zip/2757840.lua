-- Lua provided by RyzenAPI
-- Game: PLEASE STOP CRYING

-- MAIN APPLICATION
addappid(2757840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2757841, 1, "972dec86b9e9d07eca0216e224b4002738d07ef4b843a6955f66723552d7e2fa")

