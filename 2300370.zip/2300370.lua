-- Lua provided by RyzenAPI
-- Game: 天羽传奇Online

-- MAIN APPLICATION
addappid(2300370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300371, 1, "9d5350a120dea5ef15d2f291871c10a87a995e8ea0382648410b3093bf567494")

