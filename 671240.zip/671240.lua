-- Lua provided by RyzenAPI
-- Game: Game: AppID 671240

-- MAIN APPLICATION
addappid(671240)
-- Game: addappid(671240)

-- MAIN APP DEPOTS / PACKAGES
addappid(671241, 1, "9148cbb279db9c6cf9ed0a3d0eb205418ee3ee548e6dbfe1767753659102d8e5")
