-- Lua provided by RyzenAPI
-- Game: Cats Organized Neatly

-- MAIN APPLICATION
addappid(1369340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369341, 1, "8ee504b498d114480d5a24d321f31a8bc591eafec62f43de03092c7b78718174")
addappid(1628050, 0, "bb9e9dbf3250e46b4a43e5887aebee43eb61c56ed102cbb9445522482f0e2375")
