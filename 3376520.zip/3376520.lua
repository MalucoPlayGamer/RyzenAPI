-- Lua provided by RyzenAPI
-- Game: Game: 1+1=？

-- MAIN APPLICATION
addappid(3376520)
-- Game: addappid(3376520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376521, 1, "88682e038352e0b0d5c7a10151d682e092ad7388d864ff1acb41fe63e5206736")
