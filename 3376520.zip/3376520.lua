-- Lua provided by RyzenAPI
-- Game: 1+1=？

-- MAIN APPLICATION
addappid(3376520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3376521, 1, "88682e038352e0b0d5c7a10151d682e092ad7388d864ff1acb41fe63e5206736")

