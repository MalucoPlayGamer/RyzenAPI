-- Lua provided by RyzenAPI
-- Game: 373650

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(373650)

-- MAIN APP DEPOTS / PACKAGES
addappid(373659,0,"a5ed5b17b39d6904234a4d2b7e7bef6bdcee3c28a2b776334f9175ff27122713")
addappid(558880,0,"9331d5fada3d612ca84c6a4d6e05ffdfe4c40bafcea9b4a6346463aeb05e3b49")
addappid(560240,0,"32a7dfee1a2858766da301cde5c9b742024366f899c9a1ef3a0fd92017f7c608")

