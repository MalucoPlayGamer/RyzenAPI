-- Lua provided by RyzenAPI
-- Game: 3486770

-- MAIN APPLICATION
addappid(3486770)
-- Game: addappid(3486770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3486771, 1, "003ae6b504108e78dd4d55c04a7f114d7c3f586e97e3bbe4daf7b18929bf179f")
