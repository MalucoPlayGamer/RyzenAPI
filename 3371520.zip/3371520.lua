-- Lua provided by RyzenAPI
-- Game: Game: Tea House Simulator

-- MAIN APPLICATION
addappid(3371520)
-- Game: addappid(3371520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3371521, 1, "00e9df12bbfdb8dc5c6a3426b656f15bf920ea6be40c7d798819e8086aaaaa8f")
