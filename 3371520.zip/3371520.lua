-- Lua provided by RyzenAPI
-- Game: Tea House Simulator

-- MAIN APPLICATION
addappid(3371520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3371521, 1, "00e9df12bbfdb8dc5c6a3426b656f15bf920ea6be40c7d798819e8086aaaaa8f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
