-- Lua provided by RyzenAPI
-- Game: Game: The Horror at Highrook

-- MAIN APPLICATION
addappid(2836860)
-- Game: addappid(2836860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2836861, 1, "1ddcd4129bd990478548f078a611ecbd55e1a03860ed64c86b1be24f1d0313ab")
