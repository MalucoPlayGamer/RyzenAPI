-- Lua provided by RyzenAPI 
-- Game: AppID 329460
addappid(329460)
addappid(329461, 1, "448d1ec79ecbd1c70ae87bf9c4c4056d9f23ea224d029a564ed9196cea96ef23")
addappid(329462, 1, "8563d35e660ab7d76bc9da2f96c7959a3616ba9fd0f6286325aa6c06f5f511b1")
addappid(329463, 1, "5bc320c07f0e02a9ebe1399bf4f4c3d112587f38c8aba23f8ffe5f28c29330d8")
