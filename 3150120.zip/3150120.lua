-- Lua provided by RyzenAPI 
-- Game: StartPlay
addappid(3150120)
addappid(3150121, 1, "36e8d421eeaa870754bfca4dea517d867e06a9f3418359e9a2a4847b584b152d")
