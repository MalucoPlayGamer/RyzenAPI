-- Lua provided by RyzenAPI
-- Game: Game: StartPlay

-- MAIN APPLICATION
addappid(3150120)
-- Game: addappid(3150120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150121, 1, "36e8d421eeaa870754bfca4dea517d867e06a9f3418359e9a2a4847b584b152d")
