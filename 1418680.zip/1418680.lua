-- Lua provided by RyzenAPI
-- Game: Game: Pretty Girls Mahjong Solitaire [BLUE]

-- MAIN APPLICATION
addappid(1418680)
-- Game: addappid(1418680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418681, 1, "7113e18737f49ed8bae044a7f35224043f5ab6234b651e658e0b799435d96eb9")
