-- Lua provided by RyzenAPI
-- Game: 3022940

-- MAIN APPLICATION
addappid(3022940)
-- Game: addappid(3022940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022941, 1, "e183f785e36082aebc05c5118002303053e82cefe1beb72cd46eebfd822027e1")
