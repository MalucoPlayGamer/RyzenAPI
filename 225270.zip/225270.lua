-- Lua provided by RyzenAPI
-- Game: Brutal Legend Soundtrack

-- MAIN APPLICATION
addappid(225270)
-- Game: addappid(225270)

-- MAIN APP DEPOTS / PACKAGES
addappid(225270,0,"194eb748a3fd7b561300842a78e025a27626551927afa05bd1986c895c87e46e")
