-- Lua provided by RyzenAPI
-- Game: WannaMine

-- MAIN APPLICATION
addappid(801500)
addappid(802150)

-- MAIN APP DEPOTS / PACKAGES
addappid(801501, 1, "d0460f1f268d2dac1d9da60d5102afb20739aa947c78d0a6481ce8a333148530")

