-- Lua provided by RyzenAPI
-- Game: AppID 488160

-- MAIN APPLICATION
addappid(488160)
-- Game: addappid(488160)

-- MAIN APP DEPOTS / PACKAGES
addappid(488161, 1, "e05241a9ac08dc7d1a954583e918eac36eb7012878b97b4e6f087dd332c6af88")
