-- Lua provided by RyzenAPI 
-- Game: Rolling Hills: Cozy Sushi Restaurant
addappid(1235100)
addappid(1235101, 1, "f01eed1199f2b7ba7ad6308927281eb2d7541ac201a732eec90497a67bf30224")
