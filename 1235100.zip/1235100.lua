-- Lua provided by RyzenAPI
-- Game: Rolling Hills: Cozy Sushi Restaurant

-- MAIN APPLICATION
addappid(1235100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235101, 1, "f01eed1199f2b7ba7ad6308927281eb2d7541ac201a732eec90497a67bf30224")

