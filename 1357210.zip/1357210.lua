-- Lua provided by RyzenAPI
-- Game: Galactic Civilizations IV

-- MAIN APPLICATION
addappid(1357210)
addappid(2671130)
addappid(2671140)
addappid(2671150)
addappid(2671160)
addappid(2671170)
addappid(2932800)
addappid(4117170)
addappid(4130610)
addappid(4130620)
addappid(4130630)
addappid(4130660)
addappid(4374580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1357211, 1, "e1b28e464e8a1b73bce264c89ada3f3c39d55f32e584807487f8696e927901ff")
addappid(1357212, 1, "c867831f9324890e385929266c8b0ebba69267e6432a5d1ebfb372c32a8ab652")

