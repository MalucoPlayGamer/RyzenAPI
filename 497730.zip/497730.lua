-- Lua provided by RyzenAPI
-- Game: The Wardrobe - Even Better Edition

-- MAIN APPLICATION
addappid(497730)

-- MAIN APP DEPOTS / PACKAGES
addappid(497731, 1, "7d357322083d5b96b01d1f73f4205d6918b49d56046c646434962186ad948760")
addappid(1085200, 0, "ad91e33b69cc4a2a0841ad1623af620c5f14882536c7d8d6abce9f265b8c165a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
