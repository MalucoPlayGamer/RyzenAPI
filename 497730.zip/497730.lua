-- Lua provided by SkyAPI 
-- Game: The Wardrobe - Even Better Edition
addappid(497730)
addappid(497731, 1, "7d357322083d5b96b01d1f73f4205d6918b49d56046c646434962186ad948760")
addappid(1085200, 0, "ad91e33b69cc4a2a0841ad1623af620c5f14882536c7d8d6abce9f265b8c165a")
