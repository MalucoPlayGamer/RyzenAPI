-- Lua provided by RyzenAPI 
-- Game: Geisha World
addappid(1287500)
addappid(1287501, 1, "f1d1830d8cefed8db47166eba445796042a01f61d50494a1327d91f62c19349a")
