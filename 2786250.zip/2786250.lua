-- Lua provided by RyzenAPI
-- Game: Game: IVRI

-- MAIN APPLICATION
addappid(2786250)
-- Game: addappid(2786250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786251, 1, "298357be1bb15e748ed0e462c7b79ec610c8b066d8464498db44ac91d60ed92e")
