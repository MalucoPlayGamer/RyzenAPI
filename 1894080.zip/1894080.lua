-- Lua provided by RyzenAPI
-- Game: I got a millenary cat

-- MAIN APPLICATION
addappid(1894080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894081, 1, "b37e464df0ada9bef2bd148f92db5eec6c1cdabc06c410091ba2b5ebf76f8125")

