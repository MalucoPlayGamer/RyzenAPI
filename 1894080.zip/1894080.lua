-- Lua provided by SkyAPI 
-- Game: AppID 1894080
addappid(1894080)
addappid(1894081, 1, "b37e464df0ada9bef2bd148f92db5eec6c1cdabc06c410091ba2b5ebf76f8125")
