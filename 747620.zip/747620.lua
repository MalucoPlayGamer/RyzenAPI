-- Lua provided by RyzenAPI
-- Game: Joggernauts

-- MAIN APPLICATION
addappid(747620)
addappid(962140)

-- MAIN APP DEPOTS / PACKAGES
addappid(747621, 1, "c164852deff57b8a7271c271579a11b5066635f8e6d83cd4e45b4535d0a73e8c")
addappid(747622, 1, "3b0d3d917ec68f5273b8fef794859d7111c0318141c4240cdcb51d9a320e99bb")

