-- Lua provided by RyzenAPI
-- Game: Game: AppID 815370

-- MAIN APPLICATION
addappid(815370)
-- Game: addappid(815370)

-- MAIN APP DEPOTS / PACKAGES
addappid(815371, 1, "2d729703a7a551530f0fadf02b8c1da3cb944c4a898295bef1c19722f9f9f3cd")
addappid(815372, 1, "03a5e9ecc1760fada61452368cefd3bb2234f78fb25bb7dc481ba9660d781dc7")
addappid(2990430, 0, "cc1e64d590434473930b6edd90d09027aa939a0d8b1fcc7d3ccd30f86ea21e1f")
