-- Lua provided by RyzenAPI
-- Game: UNDER NIGHT IN-BIRTH Exe:Late

-- MAIN APPLICATION
addappid(452510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(452511, 1, "8772de29eb70aa846d77ada2222c221efe3793ebc2198bd11fdac1dec8a030fa")
