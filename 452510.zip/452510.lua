-- Lua provided by RyzenAPI
-- Game: addappid(452510)

-- MAIN APPLICATION
addappid(452510)

-- MAIN APP DEPOTS / PACKAGES
addappid(452511, 1, "8772de29eb70aa846d77ada2222c221efe3793ebc2198bd11fdac1dec8a030fa")
