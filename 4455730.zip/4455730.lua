-- Lua provided by RyzenAPI
-- Game: Love Craft | Deep Sea Groom

-- MAIN APPLICATION
addappid(4455730)

-- MAIN APP DEPOTS / PACKAGES
addappid(4455731,0,"a64756d2824f9532f550f50c9fbd5b7fdd863c2fe1129a0a903ed5a582f567e8")

