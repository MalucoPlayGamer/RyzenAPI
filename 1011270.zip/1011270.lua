-- Lua provided by RyzenAPI
-- Game: Bleeding Hunt VR Chap.1

-- MAIN APPLICATION
addappid(1011270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011271, 1, "f9eab90df8038d65a33f789a91b9557882b3640574fb1d6ea0a3cad938ab12f0")
