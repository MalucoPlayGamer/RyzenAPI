-- 4893010's Lua and Manifest Created by Hubcap Manifest
-- Concord Quarter
-- Created: August 16, 2026 at 07:24:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4893010) -- Concord Quarter
-- MAIN APP DEPOTS
addappid(4893011, 1, "8174edd15efe33b426e7d14574d1d45cc100da1f7521819626ec721fd8f8605f") -- Depot 4893011
setManifestid(4893011, "2347294695864734061", 140616786)
addappid(4893012, 1, "97eb65b9e65045b4bf001788074d66d568879ae6eb79f6e578a1b9574b5a62db") -- Depot 4893012
setManifestid(4893012, "1174296630161525481", 79037512)
addappid(4893013, 1, "243fe217efbecc6c3e386f2ce8b540c983fd6501a01554ba505ab5e28b28bc7e") -- Depot 4893013
setManifestid(4893013, "4874900280149625445", 69836288)