-- Lua provided by RyzenAPI
-- Game: THE MUTE HOUSE

-- MAIN APPLICATION
addappid(2219890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2219891, 1, "80a082b5b38c6fc73e130e75b400a1f1852b8e34799d8d7acc4e1ace808c7d71")

