-- Lua provided by RyzenAPI
-- Game: THE MUTE HOUSE

-- MAIN APPLICATION
addappid(2219890)
-- Game: addappid(2219890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219891, 1, "80a082b5b38c6fc73e130e75b400a1f1852b8e34799d8d7acc4e1ace808c7d71")
