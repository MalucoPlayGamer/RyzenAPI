-- Lua provided by RyzenAPI
-- Game: AppID 379680

-- MAIN APPLICATION
addappid(379680)
-- Game: addappid(379680)

-- MAIN APP DEPOTS / PACKAGES
addappid(379681, 1, "1a9094ef525cab4ddb6b31c3f4675458a1c0e0007658c41f9b36f988da56732b")
