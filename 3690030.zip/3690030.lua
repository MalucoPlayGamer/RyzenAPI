-- Lua provided by RyzenAPI
-- Game: The Last Gas Station

-- MAIN APPLICATION
addappid(3690030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3690031,0,"6e046d7bf13d154a199fdcd2f9a1bedd5de66dc45496e4db97af27a0f31fc5d9")
addappid(3690032,0,"41aaa4bb7e847316b65b3df578c82cae1a6789c35a9c906b776aa156d1802a55")

