-- Lua provided by RyzenAPI
-- Game: 2131960

-- MAIN APPLICATION
addappid(2131960)
-- Game: addappid(2131960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131961, 1, "5b08cc38d33032919c2ad0c6ee6fd3499a02ba8de910050b167f4f56142ae690")
