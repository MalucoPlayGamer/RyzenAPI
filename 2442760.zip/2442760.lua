-- Lua provided by RyzenAPI 
-- Game: Jorōgumo - じょろうぐも
addappid(2442760)
addappid(2442761, 1, "53dc0a94c76ba5aae2bfa3d5de56742dba5dc6715733d51e0817efbfe9681b52")
