-- Lua provided by RyzenAPI
-- Game: Void Destroyer

-- MAIN APPLICATION
addappid(259660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(259661, 1, "8850f661e5f1ea8ff2d519aca1506197c6f449a8be884314ed5eecd2b794b0af")
addappid(344490, 0, "2a234a7c675bdfc0a04970f83bcd9cae2b482e170cae174b3730199bece839e2")
addappid(363320, 0, "8352c8581cd00448e7da18d29ef0a50f52de408a9f565163ca517e636be7c626")

