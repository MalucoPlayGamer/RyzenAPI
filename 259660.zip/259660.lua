-- Lua provided by RyzenAPI
-- Game: 259660

-- MAIN APPLICATION
addappid(259660)
-- Game: addappid(259660)

-- MAIN APP DEPOTS / PACKAGES
addappid(259661, 1, "8850f661e5f1ea8ff2d519aca1506197c6f449a8be884314ed5eecd2b794b0af")
addappid(344490, 0, "2a234a7c675bdfc0a04970f83bcd9cae2b482e170cae174b3730199bece839e2")
addappid(363320, 0, "8352c8581cd00448e7da18d29ef0a50f52de408a9f565163ca517e636be7c626")
