-- Lua provided by RyzenAPI
-- Game: addappid(2858150)

-- MAIN APPLICATION
addappid(2858150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858151, 1, "6098e8439ab4facbc0c97bece65039085d8ba9d4122d5774d2b920e0bf7a619b")
