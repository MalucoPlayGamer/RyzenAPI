-- Lua provided by RyzenAPI
-- Game: Space Pilgrim Academy: Year 3

-- MAIN APPLICATION
addappid(936650)

-- MAIN APP DEPOTS / PACKAGES
addappid(936651, 1, "622ed8f35425ff98d5dd951a5ce02f6ad95b2cad2be950c2773bcc531377ba41")
