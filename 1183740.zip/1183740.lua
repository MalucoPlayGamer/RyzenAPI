-- Lua provided by RyzenAPI
-- Game: addappid(1183740)

-- MAIN APPLICATION
addappid(1183740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183741, 1, "f05211aeabd457946f509810e436a7be2734f9f73566df1ab1fff6cd0aeb8cd2")
