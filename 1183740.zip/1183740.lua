-- Lua provided by SkyAPI 
-- Game: AppID 1183740
addappid(1183740)
addappid(1183741, 1, "f05211aeabd457946f509810e436a7be2734f9f73566df1ab1fff6cd0aeb8cd2")
