-- Lua provided by RyzenAPI
-- Game: Romancing SaGa 2™

-- MAIN APPLICATION
addappid(606370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(606371, 1, "cc70bc7748e76f9c29f7d9adce34a11685c8c4d5dc6b58b0f430f6d93abdc06e")
addappid(606372, 1, "c9a00c463cb39ebd79fd412f3318ec69dd29d848372b2216716225a37e89c082")

