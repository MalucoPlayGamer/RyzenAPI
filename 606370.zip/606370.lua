-- Lua provided by RyzenAPI
-- Game: Romancing SaGa 2™

-- MAIN APPLICATION
addappid(606370)

-- MAIN APP DEPOTS / PACKAGES
addappid(606371, 1, "cc70bc7748e76f9c29f7d9adce34a11685c8c4d5dc6b58b0f430f6d93abdc06e")
addappid(606372, 1, "c9a00c463cb39ebd79fd412f3318ec69dd29d848372b2216716225a37e89c082")

