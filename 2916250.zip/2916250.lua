-- Lua provided by RyzenAPI 
-- Game: My Maid Girls
addappid(2916250)
addappid(2916251, 1, "ca3f0cf2c21100045d4b3a7cba5ce4a3e58a16cfffb405d4da2ba7efac0d9655")
addappid(2948510)
