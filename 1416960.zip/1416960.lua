-- Lua provided by RyzenAPI
-- Game: Everafter Falls

-- MAIN APPLICATION
addappid(1416960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416961, 1, "2257e99decaf0453ec32df3a6762cc771e6ad768998a6dab444a236f02315163")
addappid(1416962, 1, "8054c729d9b4192f95afbfd8926be13d77400cc2444678b85ba5192ff3d34ab6")
addappid(1416963, 1, "c335a4cae8de8708503cee6322771bed0f459928d3a50333a3af3301fe90c76e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3024910)
