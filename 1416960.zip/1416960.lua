-- Lua provided by RyzenAPI
-- Game: Everafter Falls

-- MAIN APPLICATION
addappid(1416960)
-- Game: addappid(1416960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416961, 1, "2257e99decaf0453ec32df3a6762cc771e6ad768998a6dab444a236f02315163")
addappid(1416962, 1, "8054c729d9b4192f95afbfd8926be13d77400cc2444678b85ba5192ff3d34ab6")
addappid(1416963, 1, "c335a4cae8de8708503cee6322771bed0f459928d3a50333a3af3301fe90c76e")
