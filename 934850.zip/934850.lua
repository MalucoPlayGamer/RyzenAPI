-- Lua provided by RyzenAPI
-- Game: Cyberdrome

-- MAIN APPLICATION
addappid(934850)

-- MAIN APP DEPOTS / PACKAGES
addappid(934851, 1, "1347375cbfdd55c5d7a5cb45b679ce0eee94ec9b97dcdda4770a4b6e82f285e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
