-- Lua provided by SkyAPI 
-- Game: Cyberdrome
addappid(934850)
addappid(934851, 1, "1347375cbfdd55c5d7a5cb45b679ce0eee94ec9b97dcdda4770a4b6e82f285e5")
