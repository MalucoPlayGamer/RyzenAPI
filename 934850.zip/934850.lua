-- Lua provided by RyzenAPI
-- Game: addappid(934850)

-- MAIN APPLICATION
addappid(934850)

-- MAIN APP DEPOTS / PACKAGES
addappid(934851, 1, "1347375cbfdd55c5d7a5cb45b679ce0eee94ec9b97dcdda4770a4b6e82f285e5")
