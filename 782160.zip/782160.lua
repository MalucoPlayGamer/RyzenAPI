-- Lua provided by RyzenAPI
-- Game: Raptainment

-- MAIN APPLICATION
addappid(782160)

-- MAIN APP DEPOTS / PACKAGES
addappid(782163,0,"f0be5d2161006f9d4d5d02241b9a7bb80f781ea234310a9338e38ad4dc448b35")

