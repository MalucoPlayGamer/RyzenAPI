-- Lua provided by RyzenAPI
-- Game: Click the Button

-- MAIN APPLICATION
addappid(3946950)
addappid(5110650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3946951,0,"dbc3ed41113fd3842d880a61da7fb1ceb860fbf0d4fa251ff0d05185d1273e46")

