-- Lua provided by RyzenAPI
-- Game: Game: Last Broadcast

-- MAIN APPLICATION
addappid(2508870)
-- Game: addappid(2508870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508871, 1, "3883b07424d1beeda3f25c96ca37da704236ac44f4eb1d221ce39461714f94aa")
