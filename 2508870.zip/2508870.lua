-- Lua provided by SkyAPI 
-- Game: Last Broadcast
addappid(2508870)
addappid(2508871, 1, "3883b07424d1beeda3f25c96ca37da704236ac44f4eb1d221ce39461714f94aa")
