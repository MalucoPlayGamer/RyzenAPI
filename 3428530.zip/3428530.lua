-- Lua provided by RyzenAPI
-- Game: Game: American MILF

-- MAIN APPLICATION
addappid(3428530)
-- Game: addappid(3428530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428531, 1, "d2e0f8ced377f6d01241f8b8b0f1b0553ad3f16390be7c6e0e7f252efbf67804")
