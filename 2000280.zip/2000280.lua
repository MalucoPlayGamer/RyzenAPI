-- Lua provided by RyzenAPI
-- Game: I’m going to die if I don’t eat sushi!

-- MAIN APPLICATION
addappid(2000280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2000281, 1, "d1eca40fc763d2af3153a0aad39df16f5482bae8cd972798a071da86dc3f7a40")

