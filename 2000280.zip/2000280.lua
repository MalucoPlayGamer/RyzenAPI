-- Lua provided by RyzenAPI
-- Game: Game: I’m going to die if I don’t eat sushi!

-- MAIN APPLICATION
addappid(2000280)
-- Game: addappid(2000280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000281, 1, "d1eca40fc763d2af3153a0aad39df16f5482bae8cd972798a071da86dc3f7a40")
