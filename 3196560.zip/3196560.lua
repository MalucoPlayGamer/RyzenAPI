-- Lua provided by RyzenAPI
-- Game: Skateboard Knight Demo

-- MAIN APPLICATION
addappid(3196560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196561, 1, "11922091c8f69b2fefd60ef27f7be4cd774f202d1c1f8ea129365cbbaeaaf75e")

