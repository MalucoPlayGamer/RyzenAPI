-- Lua provided by RyzenAPI
-- Game: Celestial Command

-- MAIN APPLICATION
addappid(330460)

-- MAIN APP DEPOTS / PACKAGES
addappid(330462,0,"2d6236594baf83811091fc1b30a67e993f24c38572f4fbd5ac236fee02cb69d9")
addappid(330464,0,"676e111ebc13d7222dfb3553bda33326dc4ce7934d8ea701fb7986824d9ad959")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
