-- Lua provided by RyzenAPI
-- Game: 都广丹青录 Demo

-- MAIN APPLICATION
addappid(2383290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383291, 1, "d53f1363c96fe4bb0cf243212e0aee0c155aec3b49f0205e447342b846fcc648")

