-- Lua provided by RyzenAPI
-- Game: AppID 2383290

-- MAIN APPLICATION
addappid(2383290)
-- Game: addappid(2383290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383291, 1, "d53f1363c96fe4bb0cf243212e0aee0c155aec3b49f0205e447342b846fcc648")
