-- Lua provided by RyzenAPI
-- Game: addappid(2191870)

-- MAIN APPLICATION
addappid(2191870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191870,0,"8ef7cf4863be316faebb3850cb3104b663dfd85f9509f1ac09f69c04c6579b70")
