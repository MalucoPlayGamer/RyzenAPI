-- Lua provided by RyzenAPI
-- Game: Guild Wars® Reforged

-- MAIN APPLICATION
addappid(29720)

-- MAIN APP DEPOTS / PACKAGES
addappid(29541,0,"7f93d15c7db86244f86cecadc8137f20f72eddd640ea65297e2f067d0471dde6")
addappid(29542,0,"d65c53534c4cf98eefa63b517b1ebd1b983c2c41846e0d55d7837cb1eda51431")
addappid(29543,0,"088886029cf89247fa5fc98ed39121aae6b13e7dd9f61eda89bc44569c469798")
addappid(29544,0,"32d6a8f3f7e420afc49d460ddc5d840f89281780094a55e9b98691aae327df1d")
addappid(29545,0,"294bbd3fe13cf5879b9e8203dd86d2f6e0be165a2c9ccd312f28d4e31ff26ffa")

