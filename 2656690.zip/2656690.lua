-- Lua provided by RyzenAPI
-- Game: Game: Sona-Nyl of the Violet Shadows Refrain

-- MAIN APPLICATION
addappid(2656690)
-- Game: addappid(2656690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656691, 1, "c576fd0968410e2c7ab0d5c1aca685a05f6419430d5701267300852a10556368")
