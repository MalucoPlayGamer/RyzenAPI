-- Lua provided by RyzenAPI
-- Game: AppID 2371630

-- MAIN APPLICATION
addappid(2371630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371631, 1, "16f8094861ddbcb0131503d1f2d5b7ed5a485d6a1f1c1f462e8d98c1ce2116b0")
addappid(2371633, 1, "4c5fd1fb38de1a7b6e1d0ec90950b662674b3d4ce34700e0beea2d05ed1a759f")
addappid(2371634, 1, "afd07ae7c1af8deaae2dd0c42160340d0ab9afd592b8113fc8c4f81c4baaa22e")
