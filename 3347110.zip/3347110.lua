-- Lua provided by RyzenAPI
-- Game: Game: The Wanted 3

-- MAIN APPLICATION
addappid(3347110)
-- Game: addappid(3347110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347111, 1, "c48d075ca239984c3efe4f85ad45d34eeac593da4d52eb8056975bea73412956")
