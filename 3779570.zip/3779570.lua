-- 3779570's Lua and Manifest Created by Hubcap Manifest
-- Heavenly Island
-- Created: August 13, 2026 at 11:14:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3779570, 1, "c53618f767da391e90725b140070e63ad2a611f628f7ff6493ed79569020f090") -- Heavenly Island
addtoken(3779570, "432802252510038431")
-- MAIN APP DEPOTS
addappid(3779571, 1, "f991c4b5abcc61f17bc6e597a3024cffefd6f9a4606f5937d0d859024cd98250") -- Depot 3779571
setManifestid(3779571, "9058738916833924948", 527159739)