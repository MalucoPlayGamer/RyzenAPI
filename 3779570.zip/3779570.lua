-- Lua provided by RyzenAPI
-- Game: Heavenly Island

-- MAIN APP DEPOTS / PACKAGES
addappid(3779570, 1, "c53618f767da391e90725b140070e63ad2a611f628f7ff6493ed79569020f090") -- Heavenly Island
addappid(3779571, 1, "f991c4b5abcc61f17bc6e597a3024cffefd6f9a4606f5937d0d859024cd98250") -- Depot 3779571
addtoken(3779570, "432802252510038431")

