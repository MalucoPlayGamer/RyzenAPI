-- Generated with Luie @ https://lua.tools/
-- 282070 - This War of Mine
-- Generated 2026-08-19 05:36:25 UTC
-- # Depots (Total/DLC/Shared): 15/1/4

-- Main AppID
addappid(282070, 1, "fe6e6a89b726d9c05a497190f0fc3246543f146d4ca7d5e0835461754229642b")

-- Main Depots
addappid(282071, 1, "e0dab4469d4abc2b32a850279e71e6863af67f2cf9284a914523f2e11f0a6417") -- (windows)
setManifestid(282071, "6552058215746440591", 2805049805)
addappid(282075, 1, "0c275e68876ad6ce2edda3ee1beb82edc13332a8a7b514aee527d6676f295258") -- (linux)
setManifestid(282075, "8880811861723404629", 2781440296)
addappid(282076, 1, "d1305ccca6bc352a52f4a8d1a4df9819d5b75ffb9f02f488747903a7a6fd989d") -- (windows)
setManifestid(282076, "4018066801537559079", 2804029001)
addappid(282077, 1, "277d097a46d043c46959fcae68803d7c1bcaa3c21f3a12fe5c822236b5d7cd04") -- (windows)
setManifestid(282077, "452741546977371630", 19936818)
addappid(282078, 1, "7fee77c87195927d57c924b7148fc09b34012e6aad771e88739f425fa8754842") -- (macos)
setManifestid(282078, "4447666893151889109", 21361434)
addappid(282079, 1, "4439900a2a4255f39264f070a6c15c2bb621f4b6f6d630d23b4b333d3dd18862") -- (macos)
setManifestid(282079, "6223985759980493607", 1323259)
addappid(282080, 1, "febf661a527ee326c1ac1405686f841217fa2c6bbf9d9494b5e34d474bbb8ddb") -- (macos)
setManifestid(282080, "8992250823172660735", 101917152)
addappid(282081, 1, "83c07c51b5b1c0c22ebfae13b5d73fae0bd981fa5d2e87df392a3c2c5f0b9bc8") -- (macos)
setManifestid(282081, "3050329373520057479", 173308515)
addappid(282082, 1, "17ca28917674ea02ee60d015d22780a67fba03c320bff92a1ffb11b76bba89a4") -- (macos)
setManifestid(282082, "5097219911030405993", 2028823626)
addappid(282083, 1, "203f1220197ba5c43de5e54a00b19f626db14a29856a49f1aad5b30f122ad3ef") -- (macos)
setManifestid(282083, "8930109651456891263", 479190645)

-- DLC's (no depot keys required)
addappid(348040) -- This War of Mine - War Child Charity DLC
addappid(481090) -- This War of Mine - The Little Ones DLC
addappid(750030) -- This War of Mine: Stories - Father's Promise
addappid(750031) -- This War of Mine: Stories - Season Pass
addappid(974610) -- This War of Mine: Stories - The Last Broadcast
addappid(1125630) -- This War of Mine: Stories - Fading Embers (ep. 3)
addappid(3323700) -- This War of Mine: Forget Celebrations Charity DLC

-- DLC's (with depot keys)
-- This War of Mine Soundtrack (AppID: 354350)
addappid(354350)
addappid(354350, 1, "f9a13515dd2a3f85d0b34e737cf79724289ce9dff89458c7d5456219314bea18")
setManifestid(354350, "8987303691722477873", 787364846)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
