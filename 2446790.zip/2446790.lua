-- Lua provided by RyzenAPI
-- Game: addappid(2446790)

-- MAIN APPLICATION
addappid(2446790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446790,0,"47bd6c5cc1be19a7435d5eb556807f03348a5ba55fbe2f3ef087116338de5280")
