-- Lua provided by SkyAPI 
-- Game: KONKONKON
addappid(3572020)
addappid(3572021, 1, "f714070ee6b9e6c82cd44163c5b5bcb35c4727b57bd09d0d933da893f0caf88c")
addappid(3572022, 1, "47a7bfd97bf64b3fb2d1683d2f41ab78bcd7dbfc091d9d3eebc1102612624fc9")
addappid(3572023, 1, "5733a5a6650008a12035380b9922b65661c62dcd37cdc4a29d7510f6646560b7")
