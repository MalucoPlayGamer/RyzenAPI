-- Lua provided by RyzenAPI
-- Game: Illusion

-- MAIN APPLICATION
addappid(1875610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875611, 1, "d755f55c6e429ad5847060fdeadd0accdbab1d7c4649bc3017b03b7ea05634d2")
addappid(1875612, 1, "b60cd98fad6b95855ae3c8ed070caceee20786a05caa70cdf8ccc8f3eab9e77a")
addappid(1875613, 1, "a960c46f82ccd45c4dcf27831252afd326bddc3453d60a8bf6ef61c64e6642e8")
addappid(1875614, 1, "e757eb965a2bfac254651a74aaecfce1d76644b5ae0ff47ca98902750e77a77f")
addappid(1875619, 1, "89af4d2b268ba094c576a9c0365b5c8156b700e543c2e8ae5c4af68c181a61e4")

