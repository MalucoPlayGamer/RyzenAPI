-- Lua provided by SkyAPI 
-- Game: Automobilista 2
addappid(1066890)
addappid(1066891, 1, "d6f49d09d5511c95e9e8ea45456deb337c87a07d9df1474f781f70dcf3bfae72")
