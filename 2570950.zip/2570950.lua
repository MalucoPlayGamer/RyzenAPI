-- Lua provided by SkyAPI 
-- Game: NURTOPU
addappid(2570950)
addappid(2570951, 1, "356eca3d77726610fd503e216e716db0df5b0eac586809de559e16303280cf6d")
