-- Lua provided by RyzenAPI
-- Game: 970560

-- MAIN APPLICATION
addappid(970560)
-- Game: addappid(970560)

-- MAIN APP DEPOTS / PACKAGES
addappid(970561, 1, "fa58549cb024d567b715406c8fac286395c606bdad9cd30bbb3bad8ffc0d5c04")
addappid(970562, 1, "00a81802ffdaa3ba51840ca9270afe5d5458787f586faf41041b47d3d6fd96a5")
addappid(970563, 1, "c6cf1b844a0c09d6aeb1744265e36cb8844103c28032412e232af0a1cf645ae8")
