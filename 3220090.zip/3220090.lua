-- Lua provided by RyzenAPI
-- Game: 100 Find Kitties: Kitty house

-- MAIN APPLICATION
addappid(3220090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3220091, 1, "e4b161566fca1dd4bf71783775970e5eaac80ae4457d517a4e103cc372a20a3d")

