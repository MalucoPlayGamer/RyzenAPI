-- Lua provided by RyzenAPI
-- Game: AppID 758700

-- MAIN APPLICATION
addappid(758700)
-- Game: addappid(758700)

-- MAIN APP DEPOTS / PACKAGES
addappid(758701, 1, "b11e04dd61259ff856a78b5d06f1fcb0cca027fb994920d9f47dcf483e8d8410")
