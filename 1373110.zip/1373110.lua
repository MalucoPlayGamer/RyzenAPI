-- Lua provided by RyzenAPI
-- Game: Reflect Horizons

-- MAIN APPLICATION
addappid(1373110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1373111, 1, "5c742e1091b4c29d087c11b51f7d4d7c879bbb0bcd217a0dffa995298fd4d127")

