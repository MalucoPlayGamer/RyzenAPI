-- Lua provided by SkyAPI 
-- Game: Reflect Horizons
addappid(1373110)
addappid(1373111, 1, "5c742e1091b4c29d087c11b51f7d4d7c879bbb0bcd217a0dffa995298fd4d127")
