-- Lua provided by RyzenAPI
-- Game: Reflect Horizons

-- MAIN APPLICATION
addappid(1373110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373111, 1, "5c742e1091b4c29d087c11b51f7d4d7c879bbb0bcd217a0dffa995298fd4d127")

