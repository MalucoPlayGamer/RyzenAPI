-- Lua provided by RyzenAPI
-- Game: Cinema Simulator

-- MAIN APPLICATION
addappid(1453250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453251, 1, "a28426cc99557f4e6bbb0a5ebb386ac4feb9236ca9167647558b6a7623dd1110")

