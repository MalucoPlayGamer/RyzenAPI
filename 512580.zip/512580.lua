-- Lua provided by RyzenAPI
-- Game: 512580

-- MAIN APPLICATION
addappid(512580)
-- Game: addappid(512580)

-- MAIN APP DEPOTS / PACKAGES
addappid(512581, 1, "883f615087846f3faa2c52b6ffcab0d6691c2d790625eead14cd4367e70b0ea1")
