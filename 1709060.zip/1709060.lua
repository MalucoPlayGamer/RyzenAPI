-- Lua provided by RyzenAPI
-- Game: 1709060

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1709060)
-- Game: addappid(1709060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709065,0,"9d37a9c86f49a3e217fafda3112c5e2b33c5325807fe9645eeff365cb5b6b623")
addappid(1709066,0,"2eac7790700f2e095c8cc34e5e21b03a53cd798a602436e4462389cc0523eeb3")
