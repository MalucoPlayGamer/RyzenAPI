-- Lua provided by RyzenAPI
-- Game: addappid(1448090)

-- MAIN APPLICATION
addappid(1448090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448091, 1, "04f39e79e6ea064f91af60570eb2cd259f49a1a497fb3d1826a07580ee68b17a")
