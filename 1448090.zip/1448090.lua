-- Lua provided by RyzenAPI
-- Game: Retention: A Love Story

-- MAIN APPLICATION
addappid(1448090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1448091, 1, "04f39e79e6ea064f91af60570eb2cd259f49a1a497fb3d1826a07580ee68b17a")

