-- Lua provided by RyzenAPI
-- Game: 2340600

-- MAIN APPLICATION
addappid(2340600)
-- Game: addappid(2340600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340601, 1, "56c26598bbccf037a41bf07d70db42ac9247f93bd3e15d2326f547c1bbf44bf0")
