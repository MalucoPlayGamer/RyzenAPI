-- Lua provided by SkyAPI 
-- Game: Industrial War
addappid(2340600)
addappid(2340601, 1, "56c26598bbccf037a41bf07d70db42ac9247f93bd3e15d2326f547c1bbf44bf0")
