-- Lua provided by RyzenAPI
-- Game: WhiteLily 1：丽丽公主

-- MAIN APPLICATION
addappid(876850)

-- MAIN APP DEPOTS / PACKAGES
addappid(876851, 1, "f4d1a0ef7609021a8f505788d1f7b7e0817ba961581e8b1a3ad61d435ccd7d14")
addappid(997750, 0, "18421cdfa18cd4d510ea3878cfa55751164b5393ddeba4f31f4132ba5d200f83")

