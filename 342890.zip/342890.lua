-- Lua provided by RyzenAPI
-- Game: 342890

-- MAIN APPLICATION
addappid(342890)

-- MAIN APP DEPOTS / PACKAGES
addappid(342894,0,"e6d0cede1e1aec959f540ba06d7c71acb5497fc6a1b987d2528805db923379f0")
