-- Lua provided by RyzenAPI
-- Game: Hotel Owner Simulator

-- MAIN APPLICATION
addappid(3158480)
-- Game: addappid(3158480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3158481, 1, "1c548a80ffa11012787f71ba74200c0bad4fba33340e1ac0990341a47469cf95")
