-- Lua provided by RyzenAPI
-- Game: Hotel Owner Simulator

-- MAIN APPLICATION
addappid(3158480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3158481, 1, "1c548a80ffa11012787f71ba74200c0bad4fba33340e1ac0990341a47469cf95")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
