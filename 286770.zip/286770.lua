-- Lua provided by RyzenAPI
-- Game: Shadow Ops: Red Mercury

-- MAIN APPLICATION
addappid(286770)

-- MAIN APP DEPOTS / PACKAGES
addappid(286771, 1, "07432f6c8e308901b09769882c1acaf2cd423cd9e329472297143844e28a2899")

