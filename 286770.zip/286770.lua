-- Lua provided by RyzenAPI
-- Game: Shadow Ops: Red Mercury

-- MAIN APPLICATION
addappid(286770)

-- MAIN APP DEPOTS / PACKAGES
addappid(286771, 1, "07432f6c8e308901b09769882c1acaf2cd423cd9e329472297143844e28a2899")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
