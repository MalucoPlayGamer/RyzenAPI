-- Lua provided by RyzenAPI
-- Game: The DeLuca Family - Season 1

-- MAIN APPLICATION
addappid(2814610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814611, 1, "4833fe216b463f6c99c3c0e257b48b3da74f4b27c706366db3bd29f7aa9507bc")
