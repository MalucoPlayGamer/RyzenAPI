-- Lua provided by SkyAPI 
-- Game: AppID 1099830
addappid(1099830)
addappid(1099831, 1, "3faa8bd4533e3e10b10d078d8ff915f4bdbc5f09009ff21c26ab180b066d457f")
