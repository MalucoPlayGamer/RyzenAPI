-- Lua provided by RyzenAPI
-- Game: 2965280

-- MAIN APPLICATION
addappid(2965280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2965282,0,"b18a28a0204a0b1214ebc4fa02b2cb8711fb7dcfd09150cf8a0daa2609257b0d")
