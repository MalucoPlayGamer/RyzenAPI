-- Lua provided by RyzenAPI
-- Game: 1948160

-- MAIN APPLICATION
addappid(1948160)
-- Game: addappid(1948160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948161, 1, "0a1fbb60fad688b3086ac7a323e5eeec89d23665995baaa6948ddf5fa7d403d0")
addappid(1948162, 1, "7bc19ad9a843a98501d5abc39ec6b1be9d0109f1927b1c774e8425d1616c67e4")
