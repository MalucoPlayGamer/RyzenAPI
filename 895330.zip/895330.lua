-- Lua provided by RyzenAPI
-- Game: 895330

-- MAIN APPLICATION
addappid(895330)
-- Game: addappid(895330)

-- MAIN APP DEPOTS / PACKAGES
addappid(895331, 1, "c3474674a7ccfb769156dfb97c76ef055a997b8c55bf55fbd6edb401367b1c24")
addappid(895332, 1, "71479b02bee4fa4affde9a41def956a698afe8c032848a6bda7b9b8aea61ae7d")
addappid(895333, 1, "2e2fdbcff81eb65010dcb862dfbf809eeefd5e6d3b15d91689629c101bbeed0a")
