-- Lua provided by RyzenAPI
-- Game: Tales of the Neon Sea

-- MAIN APPLICATION
addappid(828740)

-- MAIN APP DEPOTS / PACKAGES
addappid(828741, 1, "c065764b26ed23b3f7dec59e133858ad256fb3df8cfc6b89c4fab92e38c0e1eb")
