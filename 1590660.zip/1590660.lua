-- Lua provided by RyzenAPI
-- Game: Game: Mr. Hopp's Playhouse 2

-- MAIN APPLICATION
addappid(1590660)
-- Game: addappid(1590660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590661, 1, "d30f34a19e88398f01766efce4a1ca92e90a23b8ee8fb707360d33053899ca86")
