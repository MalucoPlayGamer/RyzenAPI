-- Lua provided by RyzenAPI
-- Game: Game: Zoo Tycoon: Ultimate Animal Collection

-- MAIN APPLICATION
addappid(613880)
-- Game: addappid(613880)

-- MAIN APP DEPOTS / PACKAGES
addappid(613881, 1, "ed04ae8163a635b93aee92e3325873b8c773c944d50f894444849835644978fd")
