-- Lua provided by RyzenAPI
-- Game: Zoo Tycoon: Ultimate Animal Collection

-- MAIN APPLICATION
addappid(613880)

-- MAIN APP DEPOTS / PACKAGES
addappid(613881, 1, "ed04ae8163a635b93aee92e3325873b8c773c944d50f894444849835644978fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
