-- Lua provided by SkyAPI 
-- Game: Yeah！Fighting Girl
addappid(1926370)
addappid(1926371, 1, "0f3f8bd8710b718b539be84cf2a45760fd964bd83f92c1e519b7f41b21f0d0e1")
