-- Lua provided by RyzenAPI
-- Game: Yeah！Fighting Girl

-- MAIN APPLICATION
addappid(1926370)
-- Game: addappid(1926370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926371, 1, "0f3f8bd8710b718b539be84cf2a45760fd964bd83f92c1e519b7f41b21f0d0e1")
