-- Lua provided by RyzenAPI
-- Game: 1494607

-- MAIN APPLICATION
addappid(1494607)
-- Game: addappid(1494607)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494607,0,"46090ce4feea24dc2e318348eb795fd6da4e93e5b4dfbb19104a006a9a6c79e7")
