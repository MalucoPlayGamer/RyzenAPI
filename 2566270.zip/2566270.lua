-- Lua provided by RyzenAPI
-- Game: addappid(2566270)

-- MAIN APPLICATION
addappid(2566270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566271, 1, "40e2d2d5be53c7fefd3ad35eb4e09a0c5d1e75f1e0ec3236fd369863d2002c45")
