-- Lua provided by RyzenAPI
-- Game: Game: AppID 478980

-- MAIN APPLICATION
addappid(478980)
-- Game: addappid(478980)

-- MAIN APP DEPOTS / PACKAGES
addappid(478981, 1, "7060e58d7ada45015c841809ffabb015a29832246bab51e120edb907d2d39f26")
addappid(478982, 1, "0903f43e351d01854d91bdc3c7639b3a6c03192c81af5d0cc4ca87b056d950c2")
