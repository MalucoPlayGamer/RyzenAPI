-- Lua provided by RyzenAPI
-- Game: 345340

-- MAIN APPLICATION
addappid(345340)
-- Game: addappid(345340)

-- MAIN APP DEPOTS / PACKAGES
addappid(345341, 1, "0704c461467626ee88271a9814395bde84a46fd48115a4a7d7558eacab268a80")
