-- Lua provided by SkyAPI 
-- Game: AppID 1237080
addappid(1237080)
addappid(1237081, 1, "5c3bb4f855eba3d4b49235a44cb64adf8513d2e6f03f0c5c1e6e5bc6cf24b17c")
