-- Lua provided by RyzenAPI
-- Game: 1237080

-- MAIN APPLICATION
addappid(1237080)
-- Game: addappid(1237080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237081, 1, "5c3bb4f855eba3d4b49235a44cb64adf8513d2e6f03f0c5c1e6e5bc6cf24b17c")
