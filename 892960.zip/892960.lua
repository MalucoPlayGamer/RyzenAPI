-- Lua provided by RyzenAPI
-- Game: Dimension Of Gameth

-- MAIN APPLICATION
addappid(892960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(892961, 1, "eac4eb6c13a863b97ccf48fa0aff52a6ebf73a747754ba308bb4c8eaa21f0e5c")
