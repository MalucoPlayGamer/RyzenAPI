-- Lua provided by RyzenAPI
-- Game: AppID 892960

-- MAIN APPLICATION
addappid(892960)

-- MAIN APP DEPOTS / PACKAGES
addappid(892961, 1, "eac4eb6c13a863b97ccf48fa0aff52a6ebf73a747754ba308bb4c8eaa21f0e5c")
