-- Lua provided by RyzenAPI
-- Game: AppID 2140760

-- MAIN APPLICATION
addappid(2140760)
addappid(2140800)
addappid(2140801)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140761, 1, "4c7e558cb41e7490e0290cd1cd2b689bbe82d11f7cb6345a2fec541a88767c8b")

