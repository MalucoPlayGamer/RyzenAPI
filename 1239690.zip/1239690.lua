-- Lua provided by RyzenAPI
-- Game: Retrowave

-- MAIN APPLICATION
addappid(1239690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239691, 1, "b3afc6f0610b768077f53b418f2b79eb1b063644c05ad84b50669eee0b4bae05")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1853060)
addappid(1855260)
addappid(2228880)
