-- Lua provided by SkyAPI 
-- Game: Retrowave
addappid(1239690)
addappid(1239691, 1, "b3afc6f0610b768077f53b418f2b79eb1b063644c05ad84b50669eee0b4bae05")
