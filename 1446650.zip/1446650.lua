-- Lua provided by RyzenAPI 
-- Game: BRAVELY DEFAULT II
addappid(1446650)
addappid(1446651, 1, "3e164871d97ccc847f11b582360cb0a3873d4d335d09f5cd975fcc57f11f2dac")
