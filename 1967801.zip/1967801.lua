-- Lua provided by RyzenAPI
-- Game: addappid(1967801)

-- MAIN APPLICATION
addappid(1967801)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967801,0,"57f6f6b8d0fbd029323b5f0bd08df58b2ad407f38d2c20c5e5c75e4b814f83e4")
