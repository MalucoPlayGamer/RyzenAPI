-- Lua provided by RyzenAPI
-- Game: Game: Survival In Draconia

-- MAIN APPLICATION
addappid(3082820)
-- Game: addappid(3082820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3082821, 1, "0e2cb45ff5a6cc5795b3d8312495621b98a9dee4d11472f95c5c15bc1e94e0e1")
