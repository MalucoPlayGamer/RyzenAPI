-- Lua provided by RyzenAPI 
-- Game: Survival In Draconia
addappid(3082820)
addappid(3082821, 1, "0e2cb45ff5a6cc5795b3d8312495621b98a9dee4d11472f95c5c15bc1e94e0e1")
