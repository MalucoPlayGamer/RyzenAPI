-- Lua provided by RyzenAPI
-- Game: Game: PIP L

-- MAIN APPLICATION
addappid(2209810)
-- Game: addappid(2209810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209811, 1, "174ca7fd358b38677d83bc1e6f473ba90711a6d0bae746a51cd12f8909107e3f")
