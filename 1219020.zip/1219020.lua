-- Lua provided by RyzenAPI
-- Game: Kili's treasure

-- MAIN APPLICATION
addappid(1219020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219021, 1, "a43f1319b8461274e908c6499b46fc6cdd1d30d633874cd504a9821f5103be5c")
addappid(1219022, 1, "b9ed773fdb0e6a3e84562a45c282d379b9b165c09e5184bae1555c59e9acce97")
