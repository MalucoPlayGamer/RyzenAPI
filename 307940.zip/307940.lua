-- Lua provided by SkyAPI 
-- Game: Radiation Island
addappid(307940)
addappid(307941, 1, "89a2b497d6728ca300e9aaa897c672620b346729d7a095b8a5bbd2c004aaefea")
