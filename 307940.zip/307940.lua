-- Lua provided by RyzenAPI
-- Game: 307940

-- MAIN APPLICATION
addappid(307940)
-- Game: addappid(307940)

-- MAIN APP DEPOTS / PACKAGES
addappid(307941, 1, "89a2b497d6728ca300e9aaa897c672620b346729d7a095b8a5bbd2c004aaefea")
