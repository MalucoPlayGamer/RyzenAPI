-- Lua provided by RyzenAPI
-- Game: Radiation Island

-- MAIN APPLICATION
addappid(307940)

-- MAIN APP DEPOTS / PACKAGES
addappid(307941, 1, "89a2b497d6728ca300e9aaa897c672620b346729d7a095b8a5bbd2c004aaefea")

