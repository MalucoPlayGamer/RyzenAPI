-- Lua provided by RyzenAPI
-- Game: 一把菜刀打天下

-- MAIN APPLICATION
addappid(4501680)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4919900)
addappid(4919910)
