-- Lua provided by RyzenAPI
-- Game: 一把菜刀打天下

-- MAIN APPLICATION
addappid(4501680)

