-- Lua provided by RyzenAPI
-- Game: NAVYFIELD : CROSSFIRE

-- MAIN APPLICATION
addappid(3939310)

