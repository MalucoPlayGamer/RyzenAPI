-- Lua provided by RyzenAPI
-- Game: Lust Epidemic

-- MAIN APPLICATION
addappid(1008020)
-- Game: addappid(1008020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008021, 1, "01f4ff1c40221ba5bca1b9a15c1e68474b56fc894d42f9e7531417fa1e109d48")
addappid(1008022, 1, "b1299f314ed5d639a40850f3005dbe538fa59c660b135ddffc4b39f9e83b5c1d")
addappid(1008023, 1, "53f25af4827fdf1d546bed0adc152a54db0dd4706e19657489db5c83fb9e85b7")
addappid(1008024, 1, "16d76215ccd0e61a44700e6b2fe25b85e95c2c2c9f1e799e95a8d8cbb4cbc951")
