-- Lua provided by RyzenAPI
-- Game: Navigation Bar

-- MAIN APPLICATION
addappid(1073720)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1073721, 1, "c36eb668ad96ad5519414d03fa5e4ab4f604fa2be7a6d7ba09faa892f2a854d5")
