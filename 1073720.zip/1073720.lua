-- Lua provided by RyzenAPI
-- Game: 1073720

-- MAIN APPLICATION
addappid(1073720)
-- Game: addappid(1073720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073721, 1, "c36eb668ad96ad5519414d03fa5e4ab4f604fa2be7a6d7ba09faa892f2a854d5")
