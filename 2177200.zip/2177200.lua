-- Lua provided by SkyAPI 
-- Game: Mission In Space
addappid(2177200)
addappid(2177201, 1, "799ee51e8f7dd1ee03e8168120131d5f8b565f5731dbc2d76ecef648c3840743")
