-- Lua provided by RyzenAPI
-- Game: Mission In Space

-- MAIN APPLICATION
addappid(2177200)
-- Game: addappid(2177200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177201, 1, "799ee51e8f7dd1ee03e8168120131d5f8b565f5731dbc2d76ecef648c3840743")
