-- Lua provided by RyzenAPI
-- Game: Tainted Grail: The Fall of Avalon

-- MAIN APPLICATION
addappid(1466060)
addappid(3681950)
addappid(4132150)
addappid(4183140)
addappid(4492250)
addappid(4514980)
addappid(4639800)
addappid(4704460)
addappid(4831420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466062,0,"b164844c9d1dcef4202a397a747eff0fc24b75b5553e21bebbd7e86042d94bca")
addappid(3687050,0,"8a5843ffcee408b2a16680531955ed57dd20d577be56ebb42d7c99dd653a3b2e")

