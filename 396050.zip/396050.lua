-- Lua provided by RyzenAPI
-- Game: Warframe UGC

-- MAIN APPLICATION
addappid(396050)

-- MAIN APP DEPOTS / PACKAGES
addappid(396051, 1, "54bd41aae963a78b1e29bfe02f5b93310639616c62f28973053d51bda0e82763")
addappid(396052, 1, "d42bee53c9bd7ebfea9081218fe7da82667efe6d069b571482c828c5e3d6d425")

