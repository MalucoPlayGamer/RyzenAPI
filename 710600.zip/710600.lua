-- Lua provided by RyzenAPI
-- Game: Red Bow

-- MAIN APPLICATION
addappid(710600)

-- MAIN APP DEPOTS / PACKAGES
addappid(710601, 1, "081517b2c399e08d18ff2cf9392b8b37a45293c94d654872afabeebd7ea44134")
