-- Lua provided by RyzenAPI
-- Game: Red Bow

-- MAIN APPLICATION
addappid(710600)

-- MAIN APP DEPOTS / PACKAGES
addappid(710601, 1, "081517b2c399e08d18ff2cf9392b8b37a45293c94d654872afabeebd7ea44134")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
