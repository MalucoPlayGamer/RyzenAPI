-- Lua provided by RyzenAPI
-- Game: Matchmania Donate

-- MAIN APPLICATION
addappid(3461200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461201, 1, "1cc22e0133299903aca7467bb552a3734031b9c08e33b6481fc22a072e9f676f")
