-- Lua provided by RyzenAPI
-- Game: addappid(1523170)

-- MAIN APPLICATION
addappid(1523170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523171, 1, "e33aa0e1dcc0f2c8de6bcd610237772535401f8826b98e5018a3a4ad95353253")
