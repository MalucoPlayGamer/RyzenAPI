-- Lua provided by RyzenAPI
-- Game: Game: Santa Claws

-- MAIN APPLICATION
addappid(694680)
-- Game: addappid(694680)

-- MAIN APP DEPOTS / PACKAGES
addappid(694681, 1, "db88936fbffa126cabf7b46ad4b41f71317118ffe1bc43f7a38d8ded6ba012e7")
