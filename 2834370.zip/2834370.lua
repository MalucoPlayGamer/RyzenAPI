-- Lua provided by RyzenAPI
-- Game: AppID 2834370

-- MAIN APPLICATION
addappid(2834370)
-- Game: addappid(2834370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834371, 1, "71dca131e83c21709f955a21dc178dabc01d566589e461e0c04c7bdb33c2c312")
