-- Lua provided by RyzenAPI
-- Game: STALZONE

-- MAIN APPLICATION
addappid(1818450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818452,0,"2afb1ec4ab3c9ad17c0742555eaab67f5fc906834613e1680b575302780cb44e")
addappid(1818453,0,"890237dd9eb2a9bb625635f3d7335afe852402662cea92f88ec3bdfb9624d40c")
addappid(1818454,0,"d461a4b4e3bc2cc3fbd4e725738e1f5f63b8af8822ae634ac404acedb49bc02b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2490360)
addappid(2659280)
addappid(2659290)
addappid(2659300)
addappid(2659310)
addappid(2659320)
addappid(2742650)
addappid(2742670)
addappid(2742680)
addappid(2742690)
addappid(2742700)
addappid(2898540)
addappid(2898550)
addappid(2898560)
addappid(3086460)
addappid(3086470)
addappid(3086480)
addappid(3086490)
addappid(3291560)
addappid(3291570)
addappid(4207960)
addappid(4908670)
