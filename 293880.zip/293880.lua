-- Lua provided by RyzenAPI
-- Game: Dark Scavenger

-- MAIN APPLICATION
addappid(293880)

-- MAIN APP DEPOTS / PACKAGES
addappid(293881, 1, "de45a59212afd870ec0c7ea89f169b81e3c4de5570bd556c0ce56c1cca732573")
addappid(293882, 1, "2f98146e9b37f712e26047cdfb35dd2e609369c1eeb2a612dff206e0d594c6ae")
addappid(293883, 1, "e7a56448598bf5951e4839bb858c20696763eb88bed8c8f275fa3259286df018")

