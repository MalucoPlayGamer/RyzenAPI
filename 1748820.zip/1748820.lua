-- Lua provided by RyzenAPI
-- Game: Listen to the Wind - Soundtrack

-- MAIN APPLICATION
addappid(1748820)
-- Game: addappid(1748820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748821, 1, "e4f77ca709b6bae164cf99ffbdcc78d6801f5004ac1d7125c23aa5ec5ddc5a42")
