-- Lua provided by RyzenAPI
-- Game: Memento Mori

-- MAIN APPLICATION
addappid(2974290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2974291, 1, "4a547bbfdee33698a14c535a811daf0f901a1397a8f2ea123c5c98c4033f1663")
