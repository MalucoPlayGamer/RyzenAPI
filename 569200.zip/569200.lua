-- Lua provided by RyzenAPI
-- Game: Space Rogue Classic

-- MAIN APPLICATION
addappid(569200)

-- MAIN APP DEPOTS / PACKAGES
addappid(569201, 1, "1118165917cb7f926a3b6ff9dfa822baf5ff31ef0b0e2e8556c83ea48e3b9541")
addappid(569202, 1, "694ad12de09a447b5c41ccdb5a02cc274314d7eedb634b3c7a3c052455da1ef6")
