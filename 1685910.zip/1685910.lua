-- Lua provided by RyzenAPI
-- Game: 1685910

-- MAIN APPLICATION
addappid(1685910)
-- Game: addappid(1685910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685910,0,"c0d95f71b96a8f4398c7271229f5c2248bed8b24ee5f75fee4453d6da4f7d866")
