-- Lua provided by RyzenAPI
-- Game: Clash of Robots

-- MAIN APPLICATION
addappid(651560)

-- MAIN APP DEPOTS / PACKAGES
addappid(651561,0,"6ad3988116290718d1b2e4c31b6ba141608c81736d00b6ac67ef90dd8672e816")

