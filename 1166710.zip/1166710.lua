-- Lua provided by RyzenAPI
-- Game: Find The Treasure

-- MAIN APPLICATION
addappid(1166710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166714,0,"39ce38f85fef1245356f2f284886a73fe1b623c2a2539780587506dcf0b9bf9b")

