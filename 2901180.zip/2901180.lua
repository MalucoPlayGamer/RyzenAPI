-- Lua provided by RyzenAPI
-- Game: addappid(2901180)

-- MAIN APPLICATION
addappid(2901180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901181, 1, "e0e9cc1a256dcfdf44d06f0f90b65fdcc1822211b4fe7327ccdb7562ca7c6029")
