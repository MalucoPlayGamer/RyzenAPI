-- Lua provided by RyzenAPI
-- Game: Lucky Mayor

-- MAIN APPLICATION
addappid(2659970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659971, 1, "9da05d4ad27637ef6d7da32987557e4251b18dfbfd8610f5c16e7fb25cccd6e4")

