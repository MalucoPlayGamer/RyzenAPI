-- Lua provided by RyzenAPI
-- Game: Brew & Brawl - Gnomes vs. Dwarves

-- MAIN APPLICATION
addappid(1424270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424271, 1, "868d9f23b62d0bfe3e8d29863caf2344905af81631ad7290b07f8ae4bfd3cd25")
addappid(1424273, 1, "15313414ba970693d035d0477cacdd46b282728ca989907e98f8e0663c93bf72")

