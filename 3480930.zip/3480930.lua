-- Lua provided by RyzenAPI
-- Game: Midnight Taco

-- MAIN APPLICATION
addappid(3480930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3480931, 1, "b5ef40b7f5de1c9212c8284509b7cb62bf89be030bb918c4727e63b58ceb3875")

