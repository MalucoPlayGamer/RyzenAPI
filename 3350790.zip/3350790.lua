-- Lua provided by RyzenAPI
-- Game: Game: Banana Ragdoll

-- MAIN APPLICATION
addappid(3350790)
-- Game: addappid(3350790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3350791, 1, "65ab4a5b07e3675097e62f066a0a0edd232f7906c61f0b3b49e7303cef4f1852")
