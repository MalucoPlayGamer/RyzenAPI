-- Lua provided by RyzenAPI 
-- Game: AppID 570500
addappid(570500)
addappid(570501, 1, "4500b88bacb4b8435c1690b8eb1a8af3194db35eff1d82af24f464726e963080")
