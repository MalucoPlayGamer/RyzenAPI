-- Lua provided by RyzenAPI
-- Game: Time Recoil

-- MAIN APPLICATION
addappid(625910)

-- MAIN APP DEPOTS / PACKAGES
addappid(625911, 1, "934756b0f2953b0c11894050d1296d312105f4f453bfb64739c305c4002f7f4c")
addappid(625912, 1, "098975d218591ba8ed2ed04cf7d0522bd5dff69657a809c0b0e53444f618f5fd")
addappid(625913, 1, "5790fc4c95f59ea72d29b630efca884a93ac530dc53c920e6b3015190ff4143d")
addappid(694210, 0, "65d018193e2add6654fadeb10e89c56f5a5268b57ccbe21b776823a40acd9afa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
