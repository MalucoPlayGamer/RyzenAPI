-- Lua provided by RyzenAPI
-- Game: Game: 残秽的我们第二章 Demo

-- MAIN APPLICATION
addappid(2089580)
-- Game: addappid(2089580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089581, 1, "efd3477df380603ee0950dd739a7ac61630fe9edb74bc91ffa168242cdf1709b")
