-- Lua provided by RyzenAPI
-- Game: Strongblade - Puzzle Quest and Match-3 Adventure

-- MAIN APPLICATION
addappid(2430830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430831, 1, "890b599533fc5e0e4b702b182495ecadcd1d34868e9d15eb81ff834ffb27284e")

