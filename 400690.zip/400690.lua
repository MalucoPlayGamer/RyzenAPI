-- Lua provided by RyzenAPI
-- Game: AppID 400690

-- MAIN APPLICATION
addappid(400690)

-- MAIN APP DEPOTS / PACKAGES
addappid(400691, 1, "b0dbfe2a666762f38673708ce02cba4cbd111db98097a0d7f6ae7ccfa932afd9")
