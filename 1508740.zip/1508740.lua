-- Lua provided by RyzenAPI
-- Game: Xuan-Yuan Sword 2

-- MAIN APPLICATION
addappid(1508740)
-- Game: addappid(1508740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508741, 1, "5b56a4411827c0072421584eec11065101858b104ddfbf9aa7d524a7e5e7b367")
