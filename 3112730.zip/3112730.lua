-- Lua provided by RyzenAPI
-- Game: Dog Man: Mission Impawsible

-- MAIN APPLICATION
addappid(3112730)
-- Game: addappid(3112730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3112731, 1, "e2e7af30e6838ec73fec911fb9b23a0ae55393b67bfcaa1318e833a3a6544ba3")
