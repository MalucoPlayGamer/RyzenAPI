-- Lua provided by RyzenAPI
-- Game: Super Kiwi 64

-- MAIN APPLICATION
addappid(1949960)
-- Game: addappid(1949960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949961, 1, "146f9196e4d72c713afe913244385082d624026554d60340aeff4dfb1a55fe71")
