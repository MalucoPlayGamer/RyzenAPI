-- Lua provided by RyzenAPI
-- Game: Suicide Adventures

-- MAIN APPLICATION
addappid(705300)
-- Game: addappid(705300)

-- MAIN APP DEPOTS / PACKAGES
addappid(705301, 1, "736fba89ec11701daefb9ca26de9650cc709b8704a19926dd9712c615f2a0767")
