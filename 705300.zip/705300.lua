-- Lua provided by SkyAPI 
-- Game: Suicide Adventures
addappid(705300)
addappid(705301, 1, "736fba89ec11701daefb9ca26de9650cc709b8704a19926dd9712c615f2a0767")
