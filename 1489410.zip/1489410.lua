-- Lua provided by RyzenAPI
-- Game: Game: Alice Escaped!

-- MAIN APPLICATION
addappid(1489410)
-- Game: addappid(1489410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489411, 1, "5e615adc9a1fa841126c2e56d7302a25fbf834be86a8665a46ec03747663dd0a")
