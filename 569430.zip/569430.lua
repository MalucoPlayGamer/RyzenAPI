-- Lua provided by RyzenAPI
-- Game: A Demon's Game - Episode 1

-- MAIN APPLICATION
addappid(569430)

-- MAIN APP DEPOTS / PACKAGES
addappid(569431, 1, "285033b8c5ebecc1a3850b3119aedc751fac5c7c9d86d3ed35da9c171c5f2b6f")
