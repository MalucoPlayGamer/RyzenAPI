-- Lua provided by RyzenAPI
-- Game: A Demon's Game - Episode 1

-- MAIN APPLICATION
addappid(569430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(569431, 1, "285033b8c5ebecc1a3850b3119aedc751fac5c7c9d86d3ed35da9c171c5f2b6f")

