-- Lua provided by SkyAPI 
-- Game: AppID 1831840
addappid(1831840)
addappid(1831841, 1, "876d59e163f1bd26fc9222d456512d342008374b8484b78c0f0cc999aeea4ce6")
