-- Lua provided by RyzenAPI
-- Game: Game: AppID 1831840

-- MAIN APPLICATION
addappid(1831840)
-- Game: addappid(1831840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831841, 1, "876d59e163f1bd26fc9222d456512d342008374b8484b78c0f0cc999aeea4ce6")
