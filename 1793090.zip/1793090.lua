-- Lua provided by RyzenAPI
-- Game: Game: Blockbuster Inc.

-- MAIN APPLICATION
addappid(1793090)
-- Game: addappid(1793090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793091, 1, "49553c6546a5ec670653a6f705375145360c247e137d8037cb32d36f0f124d63")
