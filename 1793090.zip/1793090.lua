-- Lua provided by RyzenAPI
-- Game: Blockbuster Inc.

-- MAIN APPLICATION
addappid(1793090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793091, 1, "49553c6546a5ec670653a6f705375145360c247e137d8037cb32d36f0f124d63")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
