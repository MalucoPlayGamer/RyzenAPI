-- Lua provided by RyzenAPI
-- Game: Polarities

-- MAIN APPLICATION
addappid(1280980)
-- Game: addappid(1280980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280981, 1, "2762e29f6751e37b7b154035451604f3a4975267df06d1926412e4f4cdab1196")
