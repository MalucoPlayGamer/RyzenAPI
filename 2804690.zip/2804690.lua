-- Lua provided by RyzenAPI
-- Game: Mindcop Demo

-- MAIN APPLICATION
addappid(2804690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804691, 1, "9b2c98f25acee88e6923a2d2b056b51ca2550fd30d1d342c775ed371ff156cc5")

