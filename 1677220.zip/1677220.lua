-- Lua provided by RyzenAPI
-- Game: addappid(1677220)

-- MAIN APPLICATION
addappid(1677220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677221, 1, "667fbd042bff9643be2b7322769bedcbf8303e1a5c4551a14a8d97903f11db0d")
