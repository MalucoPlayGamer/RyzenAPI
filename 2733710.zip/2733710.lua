-- Lua provided by SkyAPI 
-- Game: Tralalero Tralala : Survive the night
addappid(2733710)
addappid(2733711, 1, "26a6c7841a243d9826993fd23c05d7e02c3b5b9b7a9fbdd81957226c3915967b")
