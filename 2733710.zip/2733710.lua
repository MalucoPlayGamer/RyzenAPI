-- Lua provided by RyzenAPI
-- Game: Tralalero Tralala : Survive the night

-- MAIN APPLICATION
addappid(2733710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2733711, 1, "26a6c7841a243d9826993fd23c05d7e02c3b5b9b7a9fbdd81957226c3915967b")

