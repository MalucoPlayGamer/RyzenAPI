-- Lua provided by RyzenAPI
-- Game: Game: Tralalero Tralala : Survive the night

-- MAIN APPLICATION
addappid(2733710)
-- Game: addappid(2733710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733711, 1, "26a6c7841a243d9826993fd23c05d7e02c3b5b9b7a9fbdd81957226c3915967b")
