-- Lua provided by RyzenAPI
-- Game: AppID 925370

-- MAIN APPLICATION
addappid(925370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(925371, 1, "eb2f73bd523673f23e8b3d163c1267cfc77428eb1ff5964ad8d0ea3cb0d06f64")

