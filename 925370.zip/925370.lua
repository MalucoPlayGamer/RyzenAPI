-- Lua provided by RyzenAPI
-- Game: addappid(925370)

-- MAIN APPLICATION
addappid(925370)

-- MAIN APP DEPOTS / PACKAGES
addappid(925371, 1, "eb2f73bd523673f23e8b3d163c1267cfc77428eb1ff5964ad8d0ea3cb0d06f64")
