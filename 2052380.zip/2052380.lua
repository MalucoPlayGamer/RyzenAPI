-- Lua provided by RyzenAPI
-- Game: 3D Massage

-- MAIN APPLICATION
addappid(2052380)
-- Game: addappid(2052380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052381, 1, "c6c72b00eee0ed539db7e817c68c5dba767aa1c5558a6f603d5dd024f883824f")
