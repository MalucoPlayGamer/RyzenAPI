-- Lua provided by SkyAPI 
-- Game: Soul Academy
addappid(2311260)
addappid(2311261, 1, "2d2edc96be3759131e5e09b357a090b74d9416734d5f9d3f326cf6ce5adbc0c0")
