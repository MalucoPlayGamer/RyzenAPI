-- Lua provided by RyzenAPI
-- Game: Soul Academy

-- MAIN APPLICATION
addappid(2311260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311261, 1, "2d2edc96be3759131e5e09b357a090b74d9416734d5f9d3f326cf6ce5adbc0c0")
