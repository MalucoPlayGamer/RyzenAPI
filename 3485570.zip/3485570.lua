-- Lua provided by RyzenAPI
-- Game: ابو فانوس - Abu Fanous

-- MAIN APPLICATION
addappid(3485570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3485571, 1, "53a75ed04b2a0b0dde626906fc7d94a0ce8b7b0110eb6c9cc736c412f773fafc")
