-- Lua provided by RyzenAPI
-- Game: ابو فانوس - Abu Fanous

-- MAIN APPLICATION
addappid(3485570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3485571, 1, "53a75ed04b2a0b0dde626906fc7d94a0ce8b7b0110eb6c9cc736c412f773fafc")

