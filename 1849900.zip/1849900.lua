-- Lua provided by RyzenAPI
-- Game: Among Us 3D: VR

-- MAIN APPLICATION
addappid(1849900)
addappid(2025070)
addappid(2194830)
addappid(2287630)
addappid(2430940)
addappid(2623440)
addappid(2744910)
addappid(2849420)
addappid(2971540)
addappid(2971550)
addappid(3049590)
addappid(3049600)
addappid(3166000)
addappid(3166010)
addappid(3297980)
addappid(3297990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849901, 1, "b7688a6f7b2836e62a8b0562dae9ef1094061ae8f67131c49326cbf1819abdd4")

