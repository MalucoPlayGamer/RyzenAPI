-- Lua provided by RyzenAPI
-- Game: Among Us 3D: VR

-- MAIN APPLICATION
addappid(1849900)
-- Game: addappid(1849900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849901, 1, "b7688a6f7b2836e62a8b0562dae9ef1094061ae8f67131c49326cbf1819abdd4")
