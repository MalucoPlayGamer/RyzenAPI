-- Lua provided by RyzenAPI
-- Game: Game: The Knight Witch

-- MAIN APPLICATION
addappid(1872680)
-- Game: addappid(1872680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872681, 1, "587e81b2b104ef91eafcf919cc42e2e7d4fb6bcd8272bbc066af7b9e61e45d40")
