-- Lua provided by SkyAPI 
-- Game: The Knight Witch
addappid(1872680)
addappid(1872681, 1, "587e81b2b104ef91eafcf919cc42e2e7d4fb6bcd8272bbc066af7b9e61e45d40")
