-- Lua provided by RyzenAPI
-- Game: AppID 396640

-- MAIN APPLICATION
addappid(396640)

-- MAIN APP DEPOTS / PACKAGES
addappid(396641, 1, "135900d4aa35c6ac2ea4a21f4b9359a67a5dc6b5a107742f27678fe010013e7c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(428140)
