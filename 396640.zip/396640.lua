-- Lua provided by RyzenAPI
-- Game: AppID 396640

-- MAIN APPLICATION
addappid(396640)
-- Game: addappid(396640)

-- MAIN APP DEPOTS / PACKAGES
addappid(396641, 1, "135900d4aa35c6ac2ea4a21f4b9359a67a5dc6b5a107742f27678fe010013e7c")
