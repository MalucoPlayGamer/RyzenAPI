-- Lua provided by RyzenAPI
-- Game: 600410

-- MAIN APPLICATION
addappid(600410)
-- Game: addappid(600410)

-- MAIN APP DEPOTS / PACKAGES
addappid(600411, 1, "295b613272f6a32e2539b6e473b42244a884ba2304bd67c44cd0c51424bc602f")
