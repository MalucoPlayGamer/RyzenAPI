-- Lua provided by SkyAPI 
-- Game: Fantasy and Girls
addappid(1782320)
addappid(1782321, 1, "173350fa72a189e246fc3017f1672356391624f067976cf32a91aa527ab61c57")
