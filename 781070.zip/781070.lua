-- Lua provided by RyzenAPI
-- Game: addappid(781070)

-- MAIN APPLICATION
addappid(781070)

-- MAIN APP DEPOTS / PACKAGES
addappid(781071, 1, "a22cc8ef8eb75a412e39313005ffe9966125a61c349bd1394e390f754b57f8b4")
