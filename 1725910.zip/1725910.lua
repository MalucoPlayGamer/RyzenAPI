-- Lua provided by RyzenAPI 
-- Game: Shards of Chaos
addappid(1725910)
addappid(1725911, 1, "bd32014ed313aff65781c4d342f2bd3abce46a4839a7f8fde95fbc1afeddb95c")
