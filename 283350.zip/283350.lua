-- Lua provided by RyzenAPI
-- Game: Eurofighter Typhoon

-- MAIN APPLICATION
addappid(283350)

-- MAIN APP DEPOTS / PACKAGES
addappid(283351, 1, "eaea0ce9ca70343e598033eda05183c4a87be2991f3918377c8a73cdbb4e8829")

