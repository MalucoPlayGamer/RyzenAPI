-- Lua provided by RyzenAPI
-- Game: Game: Coin Pusher Live

-- MAIN APPLICATION
addappid(2731830)
addappid(3933940)
-- Game: addappid(2731830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731831, 1, "a13d992b9871fe201f4a0973f7e6d68f6d290e1d97f59043d3f20cc1257cb8b8")
