-- Lua provided by RyzenAPI
-- Game: Game: Nodebuster

-- MAIN APPLICATION
addappid(3107330)
-- Game: addappid(3107330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107331, 1, "37d4e53fbd3c0b7fa350edff9e11799edbecc6267c54d514128c102d8d390997")
