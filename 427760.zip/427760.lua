-- Lua provided by RyzenAPI
-- Game: 427760

-- MAIN APPLICATION
addappid(427760)
-- Game: addappid(427760)

-- MAIN APP DEPOTS / PACKAGES
addappid(427761, 1, "2cbf2206b75fdd30edfd9f02ca3cfae22a0bc987cb8373b23499bddbca39f042")
addappid(975930, 0, "861cd7811cae3cd82debda49f44c446fb1a27d1185b47acb4f0d26d5ad7fa705")
