-- Lua provided by RyzenAPI
-- Game: Under Pressure

-- MAIN APPLICATION
addappid(2524980)
addappid(2604790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524981, 1, "9cabc3d9b86272a986e368d2a483ea50fd7279ca8d7e853dfd47bf3f8d0567a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
