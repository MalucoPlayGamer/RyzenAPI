-- Lua provided by RyzenAPI
-- Game: Vengeance Demo

-- MAIN APPLICATION
addappid(1217980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217981, 1, "11a6a1b142f46b7bc3f8663b4f3e0d4029abf662d2647e5a653d9e1d59827c79")

