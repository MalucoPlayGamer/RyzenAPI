-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2974340)
-- Game: addappid(2974340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2974340,0,"b54ec4dbd1528067329c6ce102d3dc0501401e41b08a6cabc0c947d0c9541baf")
addtoken(2974340,14621696841799701455)
