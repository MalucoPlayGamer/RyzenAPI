-- Lua provided by RyzenAPI
-- Game: Halo MCC Mod Uploader

-- MAIN APPLICATION
addappid(1695795)
-- Game: addappid(1695795)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701280,0,"040c3961ac4597d1e827004cdff9e754856d787cc64f72b801deb1b3987816d3")
