-- Lua provided by RyzenAPI
-- Game: Frankenstein: Beyond the Time

-- MAIN APPLICATION
addappid(863380)

-- MAIN APP DEPOTS / PACKAGES
addappid(863381,0,"e562057610cde5e2a8a268ea5b2e423cd83a31c361ace804c6c98322a9940f91")

