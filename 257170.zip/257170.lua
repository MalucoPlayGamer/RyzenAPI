-- Lua provided by RyzenAPI
-- Game: Rebuild 3: Gangs of Deadsville

-- MAIN APPLICATION
addappid(257170)
-- Game: addappid(257170)

-- MAIN APP DEPOTS / PACKAGES
addappid(257171, 1, "629fe9b2320891b6b0d095153ef5d1c4802530c445acd092a6a87930e0837a21")
addappid(257172, 1, "9b2b1b3985e1f33d04135c4227c59fd42d193fc8a64e1e41eabedab73c8282fb")
addappid(301140, 0, "f494a14e14821fc2c86eeae2dcb99d76ab46de436bfacd8b6da84243bb9f7636")
