-- Lua provided by RyzenAPI
-- Game: 2796010

-- MAIN APPLICATION
addappid(2796010)
addappid(3913830)
-- Game: addappid(2796010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796011, 1, "5ae77169c533cca90d65bf5be54cc67554c4e7e6b9f2dc23e0bf4c158e0150ee")
