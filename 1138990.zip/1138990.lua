-- Lua provided by RyzenAPI
-- Game: Block in the Lock

-- MAIN APPLICATION
addappid(1138990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138991, 1, "b9bbd443b2b07c567b39a747f7d1cf03c48e5abf04750ad4927a2954a450db1f")
addappid(1138992, 1, "8fbbcc26e71bd8761314beccf7315a6dda3b2abde65342642c15f729f9873a76")
addappid(1138993, 1, "be170d379cbc6391870be37736fca4246fc9280fa8d1c4a5e476c63f229e4319")
addappid(1138994, 1, "8e0a646d6e02daf6b7676b7a244d030dda2d577428c1d33b21e08ff632e0c5a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
