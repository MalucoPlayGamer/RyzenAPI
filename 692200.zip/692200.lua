-- Lua provided by RyzenAPI
-- Game: aMAZE Dark Times

-- MAIN APPLICATION
addappid(692200)

-- MAIN APP DEPOTS / PACKAGES
addappid(692201, 1, "007f57c5e9e4e4deeb4ad5e4312803e5f82d0a5ae66393f971a6bf3a2668f201")

