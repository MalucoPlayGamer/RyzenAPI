-- Lua provided by RyzenAPI
-- Game: Game: AppID 2364050

-- MAIN APPLICATION
addappid(2364050)
-- Game: addappid(2364050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364051, 1, "4eee58d216d04d735d2d33d58421daeb565dd25d38582506ee4f5da8e80cf609")
