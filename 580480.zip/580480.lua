-- Lua provided by RyzenAPI
-- Game: European Mystery: Scent of Desire Collector’s Edition

-- MAIN APPLICATION
addappid(580480)

-- MAIN APP DEPOTS / PACKAGES
addappid(580481,0,"ca5ede7450ef593a8bd0625d8d11fdc82662055ace4c9d0e7ba314f7aaf0e9a9")

