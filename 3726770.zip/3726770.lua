-- Lua provided by SkyAPI 
-- Game: Leaving Home
addappid(3726770)
addappid(3726771, 1, "5b0c0b4f662568f10299ce3e45fe9785f7bfabc3632388f7ff75c759bf35fd46")
