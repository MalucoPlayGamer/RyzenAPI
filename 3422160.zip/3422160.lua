-- Lua provided by RyzenAPI 
-- Game: Frankie's FunClub
addappid(3422160)
addappid(3422161, 1, "6ce08609da82717475de80d8cc827566b5de93a7630b5dd162ffd090ed91b5e7")
