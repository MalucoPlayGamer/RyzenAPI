-- Lua provided by RyzenAPI
-- Game: BAFF 4

-- MAIN APPLICATION
addappid(1158480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158481, 1, "ffdeb40d4b519c7fc634894a38dfcb82e5775827a91be3058aa7a1bdb9e44454")
