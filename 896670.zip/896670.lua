-- Lua provided by RyzenAPI
-- Game: Ritual on the Eve 前夜祭

-- MAIN APPLICATION
addappid(896670)
-- Game: addappid(896670)

-- MAIN APP DEPOTS / PACKAGES
addappid(896671, 1, "1f9fcb34fa4e536d473112d5a3dae1d37842808a3f9417f9533f65ebd10a2350")
