-- Lua provided by RyzenAPI
-- Game: Rogue Heroes: Ruins of Tasos

-- MAIN APPLICATION
addappid(787810)
addappid(1207470)

-- MAIN APP DEPOTS / PACKAGES
addappid(787811, 1, "c89ce5d727e8f959f6a55c01e25c103e6b6e9525cd6c2db48eb5db1be7d94ef1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
