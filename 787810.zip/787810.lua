-- Lua provided by RyzenAPI
-- Game: Game: Rogue Heroes: Ruins of Tasos

-- MAIN APPLICATION
addappid(787810)
addappid(1207470)
-- Game: addappid(787810)

-- MAIN APP DEPOTS / PACKAGES
addappid(787811, 1, "c89ce5d727e8f959f6a55c01e25c103e6b6e9525cd6c2db48eb5db1be7d94ef1")
