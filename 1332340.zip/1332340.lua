-- Lua provided by RyzenAPI
-- Game: DISORDER

-- MAIN APPLICATION
addappid(1332340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332341, 1, "4299a87965c6fa8f20880c1225607076c95cae50666d2ee56b9a19d5cc3e7da2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
