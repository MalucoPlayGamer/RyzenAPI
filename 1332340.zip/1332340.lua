-- Lua provided by RyzenAPI
-- Game: DISORDER

-- MAIN APPLICATION
addappid(1332340)
-- Game: addappid(1332340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332341, 1, "4299a87965c6fa8f20880c1225607076c95cae50666d2ee56b9a19d5cc3e7da2")
