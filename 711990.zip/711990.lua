-- Lua provided by RyzenAPI
-- Game: 711990

-- MAIN APPLICATION
addappid(711990)
-- Game: addappid(711990)

-- MAIN APP DEPOTS / PACKAGES
addappid(711991, 1, "43e23dc10ff4a012a2cf4a0d6c6f05aec79fa655adabf5ce391bb90cafaf1e5a")
