-- Lua provided by RyzenAPI 
-- Game: XENO SIEGE
addappid(3574670)
addappid(3574671, 1, "815a323955abcbc6443431b3a40a978de2a1416ec4cbb169f9d7d0491446d50f")
