-- Lua provided by RyzenAPI
-- Game: 3574670

-- MAIN APPLICATION
addappid(3574670)
-- Game: addappid(3574670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3574671, 1, "815a323955abcbc6443431b3a40a978de2a1416ec4cbb169f9d7d0491446d50f")
