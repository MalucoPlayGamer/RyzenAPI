-- Lua provided by SkyAPI 
-- Game: RESONANCE OF FATE™/END OF ETERNITY™ 4K/HD EDITION
addappid(645730)
addappid(645731, 1, "c18bb034b4c45e196e58a49b94a2ffb3a9254eb60d0c27a6ab61409d94e4c0dc")
addappid(645733, 1, "c928544cea5baa671cab9e8649b90a3ff4cf17ca718f6324066060ef89e39976")
addappid(960720)
