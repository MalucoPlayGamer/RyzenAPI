-- Lua provided by RyzenAPI
-- Game: RESONANCE OF FATE™/END OF ETERNITY™ 4K/HD EDITION

-- MAIN APPLICATION
addappid(645730)
addappid(960720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(645731, 1, "c18bb034b4c45e196e58a49b94a2ffb3a9254eb60d0c27a6ab61409d94e4c0dc")
addappid(645733, 1, "c928544cea5baa671cab9e8649b90a3ff4cf17ca718f6324066060ef89e39976")

