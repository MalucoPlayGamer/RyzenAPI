-- Lua provided by RyzenAPI
-- Game: addappid(2025680)

-- MAIN APPLICATION
addappid(2025680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025681, 1, "ca91e807b626ac15b0fc7f6f1b8d67c2e42d9b55222afc879642006b42ec462f")
