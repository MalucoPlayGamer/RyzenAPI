-- Lua provided by RyzenAPI
-- Game: 34440

-- MAIN APPLICATION
addappid(34440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3902,0,"a0baa209fdc35d4bcaae33cf57dce664b696f1674810eff2184b391521c8843a")

