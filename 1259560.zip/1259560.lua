-- Lua provided by RyzenAPI
-- Game: Britannic: Patroness of the Mediterranean

-- MAIN APPLICATION
addappid(1259560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1259561, 1, "3bca7221b0c8b9be5c7c232296588d513d9d0d3837430c6d1f95b82918597415")
addappid(1259563, 1, "5db6f2ebf8877b1ba28094e2d131e244c09d76d8861afe7d960f7d729de4006c")
