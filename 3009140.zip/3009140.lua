-- Lua provided by RyzenAPI
-- Game: Salt Player for Windows

-- MAIN APPLICATION
addappid(3009140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009141, 1, "f40dfaa93e7ec1dc6f8a420392e886e985846a619e01655eddeaff4fe2216b5a")

