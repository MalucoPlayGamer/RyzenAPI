-- Lua provided by RyzenAPI
-- Game: Westview Academy - Season 1

-- MAIN APPLICATION
addappid(2275560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275561, 1, "61be49995e6b07ee704b915004f9abf3e8a102ec926376dd46f7e50b6e8e0448")
addappid(2571870, 0, "3abaeaf329f704b486cc3dda94831055c94437513af3f4a07c9ba4ce7fbbc28f")

