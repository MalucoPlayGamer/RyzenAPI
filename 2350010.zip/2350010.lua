-- Lua provided by RyzenAPI
-- Game: Game: ZOID ZOID TETSOIDEA

-- MAIN APPLICATION
addappid(2350010)
-- Game: addappid(2350010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350011, 1, "e935e5c7501d398462e59862ad8057e8738b0e95f4bcdd9fbf5981e0f9e367fd")
