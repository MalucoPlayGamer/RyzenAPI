-- Lua provided by RyzenAPI
-- Game: addappid(3078660)

-- MAIN APPLICATION
addappid(3078660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078660,0,"ebfb8ce1be18fd8e3c34a1d472d9c35af2982609a56bf45157ebedd0595189f1")
