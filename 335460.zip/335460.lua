-- Lua provided by RyzenAPI
-- Game: addappid(335460)

-- MAIN APPLICATION
addappid(228985)
addappid(335460)
addappid(335461)
addappid(335462)

-- MAIN APP DEPOTS / PACKAGES
addappid(335463,0,"e887891a5dee1ddfa068f4a63904c0202874a31b66abe4607d2e97bf605b986f")
