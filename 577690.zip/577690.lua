-- Lua provided by RyzenAPI
-- Game: Game: AppID 577690

-- MAIN APPLICATION
addappid(577690)
-- Game: addappid(577690)

-- MAIN APP DEPOTS / PACKAGES
addappid(577691, 1, "220bbcf26e52a2b9fa9afa84937ca4508e39bb78a45077c03b56bce17aad655f")
