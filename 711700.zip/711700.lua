-- Lua provided by RyzenAPI
-- Game: Derpy Fight

-- MAIN APPLICATION
addappid(711700)

-- MAIN APP DEPOTS / PACKAGES
addappid(711701,0,"6f484cbb50a87a7d3774a06efc6a2efd1b2feae183df56edf7a13e6427a62d2f")

