-- Lua provided by RyzenAPI
-- Game: addappid(2408910)

-- MAIN APPLICATION
addappid(2408910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408911, 1, "ac173126e18ed9dc71bc4ff0145536b7a53edec217fcee2b1b15fae3e5cf3c57")
