-- Lua provided by RyzenAPI
-- Game: Her Lie I Tried To Believe

-- MAIN APPLICATION
addappid(806510)
addappid(806630)

-- MAIN APP DEPOTS / PACKAGES
addappid(806511, 1, "69ca087756e8ae63fac0d0b2b5586a244876ab11fcc52061b5b017158bf7ffbc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
