-- Lua provided by RyzenAPI
-- Game: addappid(806510)

-- MAIN APPLICATION
addappid(806510)
addappid(806630)

-- MAIN APP DEPOTS / PACKAGES
addappid(806511, 1, "69ca087756e8ae63fac0d0b2b5586a244876ab11fcc52061b5b017158bf7ffbc")
