-- Lua provided by RyzenAPI 
-- Game: Arc Wizards 3
addappid(1504660)
addappid(1504661, 1, "fbfbd4511c5e0f2f7871320ad6daeb79f1fb3d5c744d98732e0656ce1ca944bb")
