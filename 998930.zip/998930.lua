-- Lua provided by RyzenAPI
-- Game: Game: AppID 998930

-- MAIN APPLICATION
addappid(998930)
-- Game: addappid(998930)

-- MAIN APP DEPOTS / PACKAGES
addappid(998931, 1, "3cb5704dfe5ac8f16f3fa0b881ab6128681bfccbe0e25b46c763b8d567342904")
addappid(1072020, 0, "f0a19c8ada9d72cbf5f91fac0ec3af93b23d73a2fb29f51b39b7e63d42f976a2")
addappid(1110730, 0, "765b97164ac3e12fc227980ea13c048f5484ffb1f3a31e560912088af1a3fc78")
