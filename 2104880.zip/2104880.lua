-- Lua provided by RyzenAPI
-- Game: Undead Inc.

-- MAIN APPLICATION
addappid(2104880)
addappid(2850450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2104881, 1, "5d6187b18a3b7de59ad4b4b5b25d7d537d97d17854fe69dda97edc8d2ec95076")
addappid(2877350, 0, "d2b8616639015cae59fe138b2263cedbbd1d269b91edc6ac9f366f8c9fdfcb9a")

