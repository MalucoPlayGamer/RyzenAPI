-- Lua provided by RyzenAPI
-- Game: Undead Inc.

-- MAIN APPLICATION
addappid(2104880)
-- Game: addappid(2104880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2104881, 1, "5d6187b18a3b7de59ad4b4b5b25d7d537d97d17854fe69dda97edc8d2ec95076")
addappid(2877350, 0, "d2b8616639015cae59fe138b2263cedbbd1d269b91edc6ac9f366f8c9fdfcb9a")
