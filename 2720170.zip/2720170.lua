-- Lua provided by RyzenAPI
-- Game: AppID 2720170

-- MAIN APPLICATION
addappid(2720170)
-- Game: addappid(2720170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720171, 1, "b913ecfd2b8e4da2f0b09d6d7aec4ec3ce4a194d672dd7f15e94274fff620b8b")
