-- Lua provided by RyzenAPI
-- Game: Breeders

-- MAIN APPLICATION
addappid(1391630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391631, 1, "294fe36f4e6a2f48ba9612b0dbc9c4bc16fe2b8fcb8ab7881fe2d071684adf61")
addappid(1391632, 1, "82ecbb0edc14a36dffb7428960d4f6ade4c41483eebd34d590526c2841e40036")
