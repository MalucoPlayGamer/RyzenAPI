-- Lua provided by RyzenAPI
-- Game: 2229290

-- MAIN APPLICATION
addappid(2229290)
-- Game: addappid(2229290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229290,0,"b4ee1b4da08a6d0dadb248a4276492c24171ef4d46af3f24fb6bf067da663ceb")
