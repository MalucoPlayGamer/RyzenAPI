-- Lua provided by RyzenAPI 
-- Game: Project Graviton
addappid(437880)
addappid(437881, 1, "de6eae06fcfd23a9740d5fdb1984e490bdddb1bd2a2a3d57cc2fffa1f5242765")
addappid(437882, 1, "1ffd98489af8f541883aac7e198032fd57650d82eb66f1dc0d82366f9eb3d08b")
addappid(442020, 0, "0b9c0b6a4fc88f1d4ed02794ccd106f2c7048566fefdca2a0d6800577a8cd9f2")
