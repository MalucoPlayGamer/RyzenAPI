-- Lua provided by SkyAPI 
-- Game: Ruff Ghanor
addappid(2087460)
addappid(2087461, 1, "6a814ce2fc2f08acaf6fdaa8f1c10494d75405b06cc47c7bc36b1e419b9a730c")
