-- Lua provided by RyzenAPI
-- Game: Ruff Ghanor

-- MAIN APPLICATION
addappid(2087460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087461, 1, "6a814ce2fc2f08acaf6fdaa8f1c10494d75405b06cc47c7bc36b1e419b9a730c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
