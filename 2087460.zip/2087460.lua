-- Lua provided by RyzenAPI
-- Game: Ruff Ghanor

-- MAIN APPLICATION
addappid(2087460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087461, 1, "6a814ce2fc2f08acaf6fdaa8f1c10494d75405b06cc47c7bc36b1e419b9a730c")
