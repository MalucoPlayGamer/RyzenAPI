-- Lua provided by RyzenAPI
-- Game: Planet

-- MAIN APPLICATION
addappid(1044180)
-- Game: addappid(1044180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044181, 1, "27fe1c9a1fa2639b246318db69abcd8532305e481d38229c067f3525ec622d8c")
