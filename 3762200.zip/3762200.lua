-- Lua provided by RyzenAPI
-- Game: Chinchón

-- MAIN APPLICATION
addappid(3762200) -- Chinchón

-- MAIN APP DEPOTS / PACKAGES
addappid(3762201, 1, "efbe86298ed0e9a068d2ceb162671f2828a7f3743dd2f1875d2ed1a5219d7a81") -- Depot 3762201

