-- 3762200's Lua and Manifest Created by Hubcap Manifest
-- Chinchón
-- Created: August 06, 2026 at 11:24:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3762200) -- Chinchón
-- MAIN APP DEPOTS
addappid(3762201, 1, "efbe86298ed0e9a068d2ceb162671f2828a7f3743dd2f1875d2ed1a5219d7a81") -- Depot 3762201
setManifestid(3762201, "8762424229482960410", 167825537)