-- Lua provided by RyzenAPI
-- Game: 898320

-- MAIN APPLICATION
addappid(898320)
-- Game: addappid(898320)

-- MAIN APP DEPOTS / PACKAGES
addappid(898321, 1, "0069e699658e07df7bf6a8b7fc769d4962aa156ce544c75b72d3369412fa1c9f")
