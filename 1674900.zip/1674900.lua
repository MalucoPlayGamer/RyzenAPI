-- Lua provided by SkyAPI 
-- Game: Train Yard Builder
addappid(1674900)
addappid(1674901, 1, "a5fb13dd90c1ebf2392838ae32e200124d897d2154cf5663f3c062162aab8c32")
addappid(1674902, 1, "b376faa7db07ec236c093a0244a912bd29719ed627b8eb6c44a276e5e3801fb5")
