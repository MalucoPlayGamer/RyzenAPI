-- Lua provided by RyzenAPI
-- Game: Game: WW2 Rebuilder Demo

-- MAIN APPLICATION
addappid(1724250)
-- Game: addappid(1724250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724251, 1, "c1befd12dcd93e2d53945f1731e2ca5fb810ce338d852a8287779dff5635057d")
