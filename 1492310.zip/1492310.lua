-- Lua provided by RyzenAPI 
-- Game: Asterix & Obelix: Slap them All!
addappid(1492310)
addappid(1492311, 1, "3ea03d51b8f021ee1e6d523c490249ea975b2236e7aac5d04f160174e683f979")
