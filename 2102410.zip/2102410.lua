-- Lua provided by RyzenAPI
-- Game: addappid(2102410)

-- MAIN APPLICATION
addappid(2102410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102411, 1, "96a73206020dc545780c1c4e84ce6652d6d855a67efa2689477ab19c4adfe2f7")
