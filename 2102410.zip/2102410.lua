-- Lua provided by RyzenAPI
-- Game: POP SURVIVOR

-- MAIN APPLICATION
addappid(2102410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102411, 1, "96a73206020dc545780c1c4e84ce6652d6d855a67efa2689477ab19c4adfe2f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
