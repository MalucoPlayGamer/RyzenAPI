-- Lua provided by RyzenAPI
-- Game: Zen Chess: Mate in Three

-- MAIN APPLICATION
addappid(1042990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042991, 1, "545afaba5d3ab7ad93a7ae82fc37305a1f8457ad1a5b761b8b642237f0e98366")

