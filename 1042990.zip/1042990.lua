-- Lua provided by SkyAPI 
-- Game: AppID 1042990
addappid(1042990)
addappid(1042991, 1, "545afaba5d3ab7ad93a7ae82fc37305a1f8457ad1a5b761b8b642237f0e98366")
