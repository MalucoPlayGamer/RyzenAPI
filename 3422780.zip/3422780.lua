-- Lua provided by RyzenAPI
-- Game: 悠星大陆 Demo

-- MAIN APPLICATION
addappid(3422780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422781, 1, "a773f1931150302d4a6bb06deb2c016588131a88ecbe683d191b3dee1450c6e5")
