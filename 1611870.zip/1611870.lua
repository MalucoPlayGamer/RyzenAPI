-- Lua provided by RyzenAPI
-- Game: Loot City

-- MAIN APPLICATION
addappid(1611870)
-- Game: addappid(1611870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611871, 1, "c03a5b5c7bded0368e71f49ba1b711fe5fab71a14bc6ccb4e80e60f503cab3ff")
