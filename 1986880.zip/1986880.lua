-- Lua provided by RyzenAPI
-- Game: Growing My Grandpa!

-- MAIN APPLICATION
addappid(1986880)
-- Game: addappid(1986880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986881, 1, "a6c079c86e8c51bc4ab14721777c803c3d3e023e59872cc7e7e8dc75f1b572d2")
