-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1754693)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754693,0,"2f3ddbd2688abc427f48ab3144b6b3492b54fdb0ea5a08b8e89d74509439d0fb")

