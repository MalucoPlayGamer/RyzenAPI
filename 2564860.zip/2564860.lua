-- Lua provided by RyzenAPI
-- Game: Castaway

-- MAIN APPLICATION
addappid(2564860)
-- Game: addappid(2564860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564861, 1, "9c28f3ed3e487430df95cc1e4b40b55ffd3c6383a155e9b9587b728a9504dff1")
