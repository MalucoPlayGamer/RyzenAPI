-- Lua provided by SkyAPI 
-- Game: Castaway
addappid(2564860)
addappid(2564861, 1, "9c28f3ed3e487430df95cc1e4b40b55ffd3c6383a155e9b9587b728a9504dff1")
