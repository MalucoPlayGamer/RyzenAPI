-- Lua provided by RyzenAPI
-- Game: Artificiality-人造物- Demo

-- MAIN APPLICATION
addappid(1095510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095511, 1, "62d44af442d9c071f70dc827bbfb92a8783a717101606147f8d4091f109a48ab")

