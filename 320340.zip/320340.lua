-- Lua provided by RyzenAPI
-- Game: Game: Cosmonautica

-- MAIN APPLICATION
addappid(320340)
addappid(383380)
-- Game: addappid(320340)

-- MAIN APP DEPOTS / PACKAGES
addappid(320341, 1, "a50adb50a24af6a98d749b2e84311f1b91c930941d1f786313a0a369be621408")
