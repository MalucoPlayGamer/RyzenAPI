-- Lua provided by RyzenAPI
-- Game: Cosmonautica

-- MAIN APPLICATION
addappid(320340)
addappid(383380)

-- MAIN APP DEPOTS / PACKAGES
addappid(320341, 1, "a50adb50a24af6a98d749b2e84311f1b91c930941d1f786313a0a369be621408")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
