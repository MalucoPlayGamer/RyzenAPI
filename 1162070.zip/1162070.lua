-- Lua provided by RyzenAPI
-- Game: AppID 1162070

-- MAIN APPLICATION
addappid(1162070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162071, 1, "e7f32bf7cfa527733b7e1f9e704417e0c73c9e87b5944720c77455a35d417727")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1246570)
