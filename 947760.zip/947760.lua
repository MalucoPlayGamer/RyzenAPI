-- Lua provided by SkyAPI 
-- Game: AppID 947760
addappid(947760)
addappid(947761, 1, "f5cd893951ebda90c054b289a17b799ca342dc90ab1b62fecd7c8b11c3d6734d")
addappid(947762, 1, "3bd1a00e4b4f008f51c4d5941edb798e71fbe0037c8e0280652d48930d5f29b6")
