-- Lua provided by SkyAPI 
-- Game: The Chaput's Baby
addappid(2118910)
addappid(2118911, 1, "a3af3ec4a86e5de330d40d430582c0ad2177ee3c3fecf4d19ac5934147028982")
