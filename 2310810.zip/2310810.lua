-- Lua provided by RyzenAPI 
-- Game: AppID 2310810
addappid(2310810)
addappid(2310811, 1, "4e04c687cbe0f78e12353aa4958591194f36961ac2663b4a81da92a861987e02")
