-- Lua provided by RyzenAPI
-- Game: AppID 2310810

-- MAIN APPLICATION
addappid(2310810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310811, 1, "4e04c687cbe0f78e12353aa4958591194f36961ac2663b4a81da92a861987e02")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
