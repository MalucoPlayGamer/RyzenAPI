-- Lua provided by RyzenAPI
-- Game: 441050

-- MAIN APPLICATION
addappid(441050)
-- Game: addappid(441050)

-- MAIN APP DEPOTS / PACKAGES
addappid(441051, 1, "f0778d94be83fca6c6f7291bfbc030335e55cc189aa71d927f2606f8e213d30f")
addappid(506600, 0, "8ac26921d5bd3efd6aa724a718601aae92390b2e15f76a755f2027d1f52af94c")
