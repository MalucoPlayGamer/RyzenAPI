-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack 6

-- MAIN APPLICATION
addappid(1948600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948600,0,"14a3c33c1178894c78b4939e2b7eb58469658650c25be233f5ebeed16843d48d")

