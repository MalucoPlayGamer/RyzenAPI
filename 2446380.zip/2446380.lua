-- Lua provided by RyzenAPI
-- Game: 2446380

-- MAIN APPLICATION
addappid(2446380)
-- Game: addappid(2446380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446380,0,"b2ec39abef34edb0378b8e336fb50e9b942e92070128b508af9b3e0b017f7759")
