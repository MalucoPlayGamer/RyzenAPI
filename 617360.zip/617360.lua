-- Lua provided by RyzenAPI
-- Game: Station Architect

-- MAIN APPLICATION
addappid(617360)
-- Game: addappid(617360)

-- MAIN APP DEPOTS / PACKAGES
addappid(617361, 1, "c23511598c019188a42eabc148d1e2fd247a92b49d0f6534381483af1e61538d")
addappid(617362, 1, "c4779e007f653b95164bd0a67957f292ab9eadde9221469af376173e25085749")
addappid(714660, 0, "f8e294c67bb3ebadee56ccd1ee382049c2f2b0afb48f004b868b05c2b5957e5f")
