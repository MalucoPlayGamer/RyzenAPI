-- Lua provided by RyzenAPI
-- Game: NaziShoot

-- MAIN APPLICATION
addappid(722570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(722571, 1, "01cf3775c15e7c2ef1ed8a34ecbc9d60fb50e872ee8f92202005a02199ea403b")

