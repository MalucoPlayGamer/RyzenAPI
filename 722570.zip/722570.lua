-- Lua provided by SkyAPI 
-- Game: NaziShoot
addappid(722570)
addappid(722571, 1, "01cf3775c15e7c2ef1ed8a34ecbc9d60fb50e872ee8f92202005a02199ea403b")
