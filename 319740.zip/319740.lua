-- Lua provided by RyzenAPI
-- Game: There Came an Echo

-- MAIN APPLICATION
addappid(319740)
addappid(342270)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(319741, 1, "ddb1df2fb8466ba4906abf27ae133b33c046ef1881d9690b139c9a3af7df7ae1")
addappid(327470, 0, "c93d90b55a195b0e3ede2b43156f475a1d316dbd4c8cdf2ffaa6d4511d09b076")

