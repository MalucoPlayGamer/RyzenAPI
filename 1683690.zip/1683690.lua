-- Lua provided by RyzenAPI
-- Game: Skiing VR

-- MAIN APPLICATION
addappid(1683690)
-- Game: addappid(1683690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683691, 1, "5239fe1a3b57d3083e6e25a61f57b4a06ff3e9660bee118b6b0d6f48b7f7f5a4")
