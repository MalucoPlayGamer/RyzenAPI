-- Lua provided by RyzenAPI
-- Game: Levelhead

-- MAIN APPLICATION
addappid(792710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(792711, 1, "b7e78e5bf8315548b49cfb76662927330226c46f2cf89a9099191fa9ff6b7b06")
