-- Lua provided by RyzenAPI
-- Game: addappid(792710)

-- MAIN APPLICATION
addappid(792710)

-- MAIN APP DEPOTS / PACKAGES
addappid(792711, 1, "b7e78e5bf8315548b49cfb76662927330226c46f2cf89a9099191fa9ff6b7b06")
