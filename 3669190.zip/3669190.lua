-- Lua provided by RyzenAPI
-- Game: Outbreak Zero

-- MAIN APPLICATION
addappid(3669190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3669191, 1, "607fe399b55cfc99e5387a402f0a443d2f8acd675147f2e1f6a7f1b9574503e9")
