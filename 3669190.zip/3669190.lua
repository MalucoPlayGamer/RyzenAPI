-- Lua provided by RyzenAPI
-- Game: Outbreak Zero

-- MAIN APPLICATION
addappid(3669190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3669191, 1, "607fe399b55cfc99e5387a402f0a443d2f8acd675147f2e1f6a7f1b9574503e9")

