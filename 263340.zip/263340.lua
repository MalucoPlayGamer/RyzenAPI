-- Lua provided by RyzenAPI
-- Game: Continue?9876543210

-- MAIN APPLICATION
addappid(263340)
-- Game: addappid(263340)

-- MAIN APP DEPOTS / PACKAGES
addappid(263341, 1, "9dd599993b22fdd786cd3658147b22fcc988ca9ba64bd428a843003b5bf83cf0")
addappid(263342, 1, "7940cc6a88c767d362e7cdd828c7e9cdffe5a98eff50140e0386d86a977fc1a3")
addappid(263343, 1, "607cc6d8147494dc7a82816be8dc712e9a829058e361c296e8da136507c9baa0")
