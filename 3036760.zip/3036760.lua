-- Lua provided by RyzenAPI
-- Game: Criminal Archives: Blade of Deceit Collector's Edition

-- MAIN APPLICATION
addappid(3036760)
addappid(3036920)
-- Game: addappid(3036760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036761, 1, "c2cbecf8d578fa4767f77153ecbf5135c77ca90d295d614c3b78cb67f7705db4")
