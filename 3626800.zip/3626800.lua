-- Lua provided by SkyAPI 
-- Game: Barro F25
addappid(3626800)
addappid(3626801, 1, "3f5fd0745401e7654387a8adf69a2f6a5aa023babd7efcc393dd699245a6d94f")
addappid(3626802, 1, "725d9f25216b5e5ccf624da27e4ae6728fdb8c9006fc60c081bd03aff80bdca7")
