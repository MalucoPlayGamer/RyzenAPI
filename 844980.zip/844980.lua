-- Lua provided by RyzenAPI
-- Game: Game: I Am Your President

-- MAIN APPLICATION
addappid(844980)
addappid(2395710)
-- Game: addappid(844980)

-- MAIN APP DEPOTS / PACKAGES
addappid(844981, 1, "102595d8c1a7022f8a67e9009163432ad1b2c970ac09fadbd89643cd571d2928")
