-- Lua provided by SkyAPI 
-- Game: Burntime Remastered
addappid(3269080)
addappid(3269081, 1, "7a86d88322898fd986fd12b72e298e5209697b4bce82e40b7a8f7ee587667c55")
