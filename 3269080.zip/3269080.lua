-- Lua provided by RyzenAPI
-- Game: Game: Burntime Remastered

-- MAIN APPLICATION
addappid(3269080)
-- Game: addappid(3269080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3269081, 1, "7a86d88322898fd986fd12b72e298e5209697b4bce82e40b7a8f7ee587667c55")
