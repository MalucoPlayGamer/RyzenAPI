-- Lua provided by RyzenAPI
-- Game: Game: Oppai Puzzle L

-- MAIN APPLICATION
addappid(2070830)
-- Game: addappid(2070830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070831, 1, "ac04b2541b868f90de36b8fac0d5bd6eae1942b5d07558ba8f6e03122075d2d5")
