-- Lua provided by RyzenAPI 
-- Game: Cat Quest III
addappid(2305840)
addappid(2305841, 1, "7bf9c3f47228c505c20c83dc23a54cbbca66b316a368aab8094deac72c8f4149")
addappid(3126830)
