-- Lua provided by RyzenAPI
-- Game: Cat Quest III

-- MAIN APPLICATION
addappid(2305840)
addappid(3126830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305841, 1, "7bf9c3f47228c505c20c83dc23a54cbbca66b316a368aab8094deac72c8f4149")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
