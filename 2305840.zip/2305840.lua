-- Lua provided by RyzenAPI
-- Game: 2305840

-- MAIN APPLICATION
addappid(2305840)
addappid(3126830)
-- Game: addappid(2305840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305841, 1, "7bf9c3f47228c505c20c83dc23a54cbbca66b316a368aab8094deac72c8f4149")
