-- Lua provided by RyzenAPI
-- Game: Something Took Her

-- MAIN APPLICATION
addappid(3445380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445381, 1, "7e414e8d08bb8aad0cf48efa67825e114e049e21d77b14928fd4a5e91c8f1369")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
