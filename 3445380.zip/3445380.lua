-- Lua provided by RyzenAPI
-- Game: Game: Something Took Her

-- MAIN APPLICATION
addappid(3445380)
-- Game: addappid(3445380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445381, 1, "7e414e8d08bb8aad0cf48efa67825e114e049e21d77b14928fd4a5e91c8f1369")
