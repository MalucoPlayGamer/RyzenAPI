-- Lua provided by RyzenAPI
-- Game: RetroArch - gpSP

-- MAIN APPLICATION
addappid(1227468)
-- Game: addappid(1227468)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227468,0,"fcba132b2d0b6d6939791f20a15580a598a76b3cca773f9925cfa746f39f94e3")
addappid(1789850,0,"c079adee7cd274408e6d90bc2060ef5f5489bdb9ca0582143176a9e186f55df9")
addappid(1789851,0,"54b6f11e8de23d50347a9ef1a29673286ced3423c71cc3e08fae80db2fa880b9")
