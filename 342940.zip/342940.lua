-- Lua provided by RyzenAPI
-- Game: Project: Gorgon

-- MAIN APPLICATION
addappid(342940)
-- Game: addappid(342940)

-- MAIN APP DEPOTS / PACKAGES
addappid(342941, 1, "6158174e24272783bd11d5177270efd4faed48c389e7724832b62ede6a18197a")
addappid(342942, 1, "5748852754412c643fa27563e3f24020c5ca8d1053e2084d0c26c6ce6eead60b")
addappid(342943, 1, "a053b7ca0007cfdbcb8647da11a48c213a2c6ab95066d1cb28974969ce1c180c")
