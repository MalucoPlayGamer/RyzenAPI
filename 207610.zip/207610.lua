-- Lua provided by RyzenAPI
-- Game: The Walking Dead

-- MAIN APPLICATION
addappid(207610)
-- Game: addappid(207610)

-- MAIN APP DEPOTS / PACKAGES
addappid(207611, 1, "2504e31b160035dedf8690255102320b7bc9b2e4ae50fec1ad94f4d77b273e28")
addappid(207612, 1, "18ba8046e6052aab5dee0995041da6f7baf4a2968f335691ee89dcbf4b666fc5")
addappid(207620, 0, "b09a45186c9d017b6b6aa6c5841327bf027bfc952eb31ef3f442c68a8d83e6f0")
