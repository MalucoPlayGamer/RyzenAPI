-- Lua provided by RyzenAPI 
-- Game: Hero Team
addappid(1253410)
addappid(1253411, 1, "21c2698068395c2dc1e445c2286bd843ec63e59e5ff20e89e805ad36e4df4f54")
