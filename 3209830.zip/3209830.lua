-- Lua provided by RyzenAPI
-- Game: Stronghold Crusader: Definitive Edition Demo

-- MAIN APPLICATION
addappid(3209830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209831, 1, "0dc0bdf8a72b010b133df1a86a44d10d89d62bddf3ddd19cdf9a6bfa7d012d5f")
addappid(3209832, 1, "005f303e93436f82846ce26e5e00b5fd22f0417b79fbc89a9e6c9263ae09282e")
addappid(3209834, 1, "f7528ef5bf67827ae6e172b017bd260867aea1dd92e2946ee5529c7d86073273")
addappid(3209835, 1, "27657aaaad987fd933c3f1d98b69af561340e7dbefbc9335a981d7b41ebac4f6")
addappid(3209837, 1, "6d22f0e2c28d7e48d326eb7eadd457feb0f2602d466eb48e5c97e2e5d6a0a04b")
addappid(3209838, 1, "b324975448be17d2944d8ffec3e3665cbb9ca2ec45d857b4b3d1298b9f59d9c7")

