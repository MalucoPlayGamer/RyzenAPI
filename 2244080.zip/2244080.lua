-- Lua provided by RyzenAPI
-- Game: erozld

-- MAIN APPLICATION
addappid(2244080)
-- Game: addappid(2244080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244082,0,"65c2d90187f726fe5ca7a1ab97c7741c20e419aaa01e4d695d6c224adc1a6676")
