-- Lua provided by RyzenAPI
-- Game: addappid(1751690)

-- MAIN APPLICATION
addappid(1751690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751691, 1, "f62ebb0b4ed36290951d19a57a4697c58a414dfc536a63459ad7e0a8ac0600eb")
