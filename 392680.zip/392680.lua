-- Lua provided by RyzenAPI
-- Game: Jeeboman

-- MAIN APPLICATION
addappid(392680)
-- Game: addappid(392680)

-- MAIN APP DEPOTS / PACKAGES
addappid(392681, 1, "0b296abf20627fdd4eb192843ab1697cbf99550493ab63c34b1088c830a1954b")
