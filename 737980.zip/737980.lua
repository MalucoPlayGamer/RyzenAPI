-- Lua provided by RyzenAPI
-- Game: The Grimsworth Reports: Woodfall

-- MAIN APPLICATION
addappid(737980)

-- MAIN APP DEPOTS / PACKAGES
addappid(737982,0,"df000cb8864d80557f625c2dcc3be7c01ae29549c05f07c431aae49d384b1551")
addappid(737983,0,"97fde7b037e0a6a23383e5b49174e6ff025a164ac879c4438d92b559715d59bb")

