-- Lua provided by RyzenAPI
-- Game: addappid(676240)

-- MAIN APPLICATION
addappid(676240)
addappid(676241)

-- MAIN APP DEPOTS / PACKAGES
addappid(676242,0,"2202f4596fdab7e2b83eb0e9b26df11ac5cda0116c27d1c0143c878f76ae6052")
