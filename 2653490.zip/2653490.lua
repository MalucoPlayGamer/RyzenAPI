-- Lua provided by RyzenAPI
-- Game: Game: 非凡：out of the ordinary

-- MAIN APPLICATION
addappid(2653490)
-- Game: addappid(2653490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653491, 1, "6f9dc0ba8b208e1c52e92788932401e5580d16d9ddae322af6a9a029bda5325b")
