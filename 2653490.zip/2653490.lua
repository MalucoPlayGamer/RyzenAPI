-- Lua provided by RyzenAPI
-- Game: 非凡：out of the ordinary

-- MAIN APPLICATION
addappid(2653490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653491, 1, "6f9dc0ba8b208e1c52e92788932401e5580d16d9ddae322af6a9a029bda5325b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
