-- Lua provided by RyzenAPI
-- Game: Little hidden city

-- MAIN APPLICATION
addappid(706490)
addappid(827840)

-- MAIN APP DEPOTS / PACKAGES
addappid(706491, 1, "0a05bb2ee30546ed642d73dc370b1cc37d54530867b5a1cfac3354d50ec83b32")
