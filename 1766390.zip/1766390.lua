-- Lua provided by RyzenAPI 
-- Game: FORWARD: Escape the Fold - Ultimate Edition
addappid(1766390)
addappid(1766391, 1, "09cf6fb155bbaca92b512dd7650c342d8967ae3f9ca2273e891f8fe305e47010")
