-- Lua provided by RyzenAPI
-- Game: Daughter of Shadows: An SCP Breach Event

-- MAIN APPLICATION
addappid(449820)
addappid(495510)
-- Game: addappid(449820)

-- MAIN APP DEPOTS / PACKAGES
addappid(449821, 1, "5355ced930ae4b305a74ed76c6844db05a915cedf9f919c2642ce2bfe24c9f41")
