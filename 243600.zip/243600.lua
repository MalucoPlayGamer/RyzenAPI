-- Lua provided by RyzenAPI 
-- Game: TGDME Demo
addappid(243600)
addappid(243601, 1, "b36a1e07d71d71017a8c6dac8ab2adc67f1e6b70d70c2d87d49c377177bd3266")
addappid(243602, 1, "1a409de8b2406a7b4e8e7023aaca6b127931425b3e43440ba8c1700d45694434")
addappid(243603, 1, "0d8bbc132037067ca1e3657a6ef8cc79c444ebaff4988223acd4a4a5a7dea238")
