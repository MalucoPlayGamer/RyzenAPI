-- Lua provided by RyzenAPI
-- Game: EdgeOfTheAbyssAwaken

-- MAIN APPLICATION
addappid(1641670)
-- Game: addappid(1641670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641671, 1, "7d23d7b7fa7c560cdf18bbfa635fdb400f8fa2456a2c613003c78643fd3514ef")
