-- Lua provided by RyzenAPI
-- Game: Bonus 3 Weapons

-- MAIN APPLICATION
addappid(933503)

-- MAIN APP DEPOTS / PACKAGES
addappid(933503,0,"f59c42a32f57f6362eb9d8c41d19d48b5e46f5057608bf838c8bed0a2df7476e")
addtoken(933503,185799311073323653)
