-- Lua provided by RyzenAPI
-- Game: addappid(343430)

-- MAIN APPLICATION
addappid(343430)

-- MAIN APP DEPOTS / PACKAGES
addappid(343431, 1, "2999782da237069008f3a7c195e4fa061725fcbf9fb8f369cbce9cfec5da2745")
