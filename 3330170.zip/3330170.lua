-- Lua provided by RyzenAPI
-- Game: Sync Sprint

-- MAIN APPLICATION
addappid(3330170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3330171, 1, "6707fb738187bdc3405110e152fae260e67c7049fb1b12e633c2bcbbd0c713b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
