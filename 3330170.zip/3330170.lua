-- Lua provided by RyzenAPI
-- Game: Sync Sprint

-- MAIN APPLICATION
addappid(3330170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3330171, 1, "6707fb738187bdc3405110e152fae260e67c7049fb1b12e633c2bcbbd0c713b5")
