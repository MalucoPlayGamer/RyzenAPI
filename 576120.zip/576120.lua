-- Lua provided by RyzenAPI
-- Game: 576120

-- MAIN APPLICATION
addappid(576120)
-- Game: addappid(576120)

-- MAIN APP DEPOTS / PACKAGES
addappid(576121, 1, "d35a76d41a9abf0b63232b9a726f9288f577bb20d9c912839de729b218053cf3")
