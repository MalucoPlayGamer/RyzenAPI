-- Lua provided by RyzenAPI
-- Game: Hush Hush - Only Your Love Can Save Them Soundtrack

-- MAIN APPLICATION
addappid(2070740)
-- Game: addappid(2070740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070741, 1, "581129adabd1ad59cb35e3204bcdcfc1f774bfa27cac544ff8c628d5e7fc21c3")
