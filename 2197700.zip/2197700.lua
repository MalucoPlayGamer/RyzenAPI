-- Lua provided by RyzenAPI 
-- Game: Gatekeeper: Eclipse
addappid(2197700)
addappid(2197701, 1, "4bdc907cb8fcc7832c35abaa4ad5f3e6d5b94cfcc1863a83bb4eaeffefc71d5a")
