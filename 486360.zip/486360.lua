-- Lua provided by RyzenAPI
-- Game: Timore Inferno

-- MAIN APPLICATION
addappid(486360)

-- MAIN APP DEPOTS / PACKAGES
addappid(486361, 1, "ce34c103967ebc9d9a85af38d6a19de030ffe90976aad253d8c4cede9ec979ca")
