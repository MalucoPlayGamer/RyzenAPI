-- Lua provided by RyzenAPI
-- Game: Game: AppID 1052360

-- MAIN APPLICATION
addappid(1052360)
-- Game: addappid(1052360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052361, 1, "b52fa67eaf5f82f496ef9a44ecb7e4ab46a4d42367e3165112fc61123a614927")
