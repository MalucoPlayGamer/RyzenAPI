-- Lua provided by RyzenAPI
-- Game: I Misteri di Maggia

-- MAIN APPLICATION
addappid(796400)

-- MAIN APP DEPOTS / PACKAGES
addappid(796401, 1, "03593ea0a2f4c9979c3513097507d2f91fbe8d1f0795a23499a689863a7f80bd")

