-- Lua provided by SkyAPI 
-- Game: Cento Demo
addappid(2759090)
addappid(2759091, 1, "d3b639b6b8b088d070ada2b028308bc3dc1991038e05c0d8aee6b2e40aca6d8c")
