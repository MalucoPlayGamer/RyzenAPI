-- Lua provided by RyzenAPI
-- Game: Hunt the Lights

-- MAIN APPLICATION
addappid(1423970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1423971, 1, "2f80b260e45055a8023702513f575665078cce64a9636dc34a1edc0e17b2dd75")

