-- Lua provided by RyzenAPI
-- Game: Hunt the Lights

-- MAIN APPLICATION
addappid(1423970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423971, 1, "2f80b260e45055a8023702513f575665078cce64a9636dc34a1edc0e17b2dd75")
