-- Lua provided by RyzenAPI
-- Game: Nickelodeon All-Star Brawl - Rocko Brawler Pack

-- MAIN APPLICATION
addappid(1967791)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967791,0,"57d2329935af8661ee58824010bbd2321ea463b7ff5a12c88ebcb39ba6570160")
