-- Lua provided by RyzenAPI
-- Game: Trillion: God of Destruction

-- MAIN APPLICATION
addappid(451780)

-- MAIN APP DEPOTS / PACKAGES
addappid(451781, 1, "d9acfd99c1df258f24e1fede2df6c0255ed609d4bf8fac48d9078ff9b73f3b64")
addappid(451782, 1, "ff06caa9ebc8e8cfb754056cd1648f579890130ab0cafcba71d2dd333c772650")
addappid(543470, 0, "dbac803cc85465250d37df4318e93b1b6c7fd83f455b30bfb1e56f362d86a034")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
