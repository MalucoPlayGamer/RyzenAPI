-- Lua provided by RyzenAPI
-- Game: Trillion: God of Destruction

-- MAIN APPLICATION
addappid(451780)
-- Game: addappid(451780)

-- MAIN APP DEPOTS / PACKAGES
addappid(451781, 1, "d9acfd99c1df258f24e1fede2df6c0255ed609d4bf8fac48d9078ff9b73f3b64")
addappid(451782, 1, "ff06caa9ebc8e8cfb754056cd1648f579890130ab0cafcba71d2dd333c772650")
addappid(543470, 0, "dbac803cc85465250d37df4318e93b1b6c7fd83f455b30bfb1e56f362d86a034")
