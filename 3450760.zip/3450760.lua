-- Lua provided by RyzenAPI
-- Game: Game: Cross Court Tennis 3

-- MAIN APPLICATION
addappid(3450760)
-- Game: addappid(3450760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3450761, 1, "b29d4e77a91728775c1414d3caf84a4360e80909b68a0f1377ee672ca2b7265a")
