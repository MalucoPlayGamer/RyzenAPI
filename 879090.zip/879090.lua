-- Lua provided by RyzenAPI
-- Game: Meower's Quest: Jasper's Tale

-- MAIN APPLICATION
addappid(879090)

-- MAIN APP DEPOTS / PACKAGES
addappid(879091, 1, "65a5c131a8a007f438d0f0c6783139fa9f7601cb49c994589e4067b906ce711b")

