-- Lua provided by RyzenAPI
-- Game: 1320830

-- MAIN APPLICATION
addappid(1320830)
-- Game: addappid(1320830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320831, 1, "9d974b96ff5da2681dd8c3118a99fd2f26aa7a15a1f1f7d4cd9932b645fca44a")
