-- Lua provided by RyzenAPI
-- Game: Runes

-- MAIN APPLICATION
addappid(548050)

-- MAIN APP DEPOTS / PACKAGES
addappid(548051,0,"3d5c8e0d169ce926fca74eb914deae0643b39e3dc08108509038199cda5a4da7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
