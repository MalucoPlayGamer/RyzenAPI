-- Lua provided by RyzenAPI
-- Game: Runes

-- MAIN APPLICATION
addappid(548050)

-- MAIN APP DEPOTS / PACKAGES
addappid(548051,0,"3d5c8e0d169ce926fca74eb914deae0643b39e3dc08108509038199cda5a4da7")

