-- Lua provided by RyzenAPI
-- Game: AppID 761190

-- MAIN APPLICATION
addappid(761190)

-- MAIN APP DEPOTS / PACKAGES
addappid(761191, 1, "d34de1d9115f350bd9e74917d3ec88592afaf04cdbb54463021f0ff66d54479c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
