-- Lua provided by RyzenAPI
-- Game: addappid(761190)

-- MAIN APPLICATION
addappid(761190)

-- MAIN APP DEPOTS / PACKAGES
addappid(761191, 1, "d34de1d9115f350bd9e74917d3ec88592afaf04cdbb54463021f0ff66d54479c")
