-- Lua provided by RyzenAPI 
-- Game: AppID 2101110
addappid(2101110)
addappid(2101111, 1, "82b2de4a8fb2daaa0c58eb954a34b48373998cbf7aff943b61f73914b3e2152a")
addappid(2101112, 1, "4db690c80f5305a960f65b79b6816407a19f116bdaa74a8c3e9d44038b749943")
