-- Lua provided by RyzenAPI
-- Game: Haven

-- MAIN APPLICATION
addappid(983970)
addappid(3320740)

-- MAIN APP DEPOTS / PACKAGES
addappid(983971,0,"270bb6d3630d819c2d4e6d0faa2c8a24dfa888eda22a010808caef600c1e6aa2")
addappid(3320740,0,"0905f0e7eb2f64fc3f8af7720b918c3b9064a45aaaeb74dcadf266d3ce48ac59")

