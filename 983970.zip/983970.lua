-- Lua provided by RyzenAPI
-- Game: Game: Haven

-- MAIN APPLICATION
addappid(983970)
-- Game: addappid(983970)

-- MAIN APP DEPOTS / PACKAGES
addappid(983971, 1, "270bb6d3630d819c2d4e6d0faa2c8a24dfa888eda22a010808caef600c1e6aa2")
