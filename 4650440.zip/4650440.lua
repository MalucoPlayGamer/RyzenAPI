-- 4650440's Lua and Manifest Created by Hubcap Manifest
-- Suika Game Planet
-- Created: July 26, 2026 at 13:01:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4650440) -- Suika Game Planet
-- MAIN APP DEPOTS
addappid(4650441, 1, "ad4b903e26d7b063a8630ff80db885f21036ee9d7df6c91628484d7c429c88c3") -- Depot 4650441
setManifestid(4650441, "5909633851236145400", 685505557)