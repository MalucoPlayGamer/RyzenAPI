-- Lua provided by RyzenAPI
-- Game: The 3rd Building 三教

-- MAIN APPLICATION
addappid(942010)

-- MAIN APP DEPOTS / PACKAGES
addappid(942011, 1, "e94a924b6b3d59f93e22f425a02e5914f666993653137a62168d76dfc8e5be9f")
addappid(1072971, 0, "4a2a8523eaec7bd27d097905d37e0c16a75b915956cbcc0f4c0a0331884d2c3b")

