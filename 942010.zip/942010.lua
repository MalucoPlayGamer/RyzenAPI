-- Lua provided by RyzenAPI
-- Game: The 3rd Building 三教

-- MAIN APPLICATION
addappid(942010)

-- MAIN APP DEPOTS / PACKAGES
addappid(942011, 1, "e94a924b6b3d59f93e22f425a02e5914f666993653137a62168d76dfc8e5be9f")
addappid(1072971, 0, "4a2a8523eaec7bd27d097905d37e0c16a75b915956cbcc0f4c0a0331884d2c3b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
