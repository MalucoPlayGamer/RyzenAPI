-- Lua provided by RyzenAPI
-- Game: 1346600

-- MAIN APPLICATION
addappid(1346600)
-- Game: addappid(1346600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346601, 1, "9eab405a9566ee5bceea2997134b8b669dba7cdfa5b08bd03d1dc8214155048e")
