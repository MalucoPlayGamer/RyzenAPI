-- Lua provided by RyzenAPI
-- Game: Game: 秋恋物语 Autumn Romance

-- MAIN APPLICATION
addappid(1874810)
-- Game: addappid(1874810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874811, 1, "dab0f0b8b18035690e31243df03b7772ff38ac52a5c2c3c05b6383a95aad1acb")
