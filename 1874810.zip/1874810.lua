-- Lua provided by SkyAPI 
-- Game: 秋恋物语 Autumn Romance
addappid(1874810)
addappid(1874811, 1, "dab0f0b8b18035690e31243df03b7772ff38ac52a5c2c3c05b6383a95aad1acb")
