-- Lua provided by RyzenAPI
-- Game: Angel's Awakening

-- MAIN APPLICATION
addappid(2086970)
-- Game: addappid(2086970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086971, 1, "632f83c23b73879c61da9dc3b03b8fe5747c9ed29053dceaef78a6e6fe0683b9")
