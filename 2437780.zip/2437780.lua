-- Lua provided by RyzenAPI
-- Game: Shadow Playtest

-- MAIN APPLICATION
addappid(2437780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437781, 1, "b0c6324f1cbf1e86d0193c133570f1e3b4dcd7a0826321ea4e78fb69e2037aec")
