-- Lua provided by RyzenAPI
-- Game: 215470

-- MAIN APPLICATION
addappid(215470)
-- Game: addappid(215470)

-- MAIN APP DEPOTS / PACKAGES
addappid(215471, 1, "f381d4e4dd2565c0e2d2473aed456a5e5d83699dad9ee29779c3f4215bea0d39")
