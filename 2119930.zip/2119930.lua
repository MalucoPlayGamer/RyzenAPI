-- Lua provided by RyzenAPI
-- Game: 2119930

-- MAIN APPLICATION
addappid(2119930)
-- Game: addappid(2119930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119931, 1, "fb211b1c7c9560c918c32cb762f90484b3eb4b5b1756d2382d8a6d976d28a5be")
