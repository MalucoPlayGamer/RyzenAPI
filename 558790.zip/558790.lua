-- Lua provided by RyzenAPI
-- Game: Queen's Quest 2: Stories of Forgotten Past

-- MAIN APPLICATION
addappid(558790)

-- MAIN APP DEPOTS / PACKAGES
addappid(558791, 1, "ea386ba53b6380cb55ac89780dff3236fea1429b6a6b16db1e8207b0810ef8a3")
