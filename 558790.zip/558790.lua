-- Lua provided by SkyAPI 
-- Game: AppID 558790
addappid(558790)
addappid(558791, 1, "ea386ba53b6380cb55ac89780dff3236fea1429b6a6b16db1e8207b0810ef8a3")
