-- Lua provided by RyzenAPI
-- Game: While We Wait Here Demo

-- MAIN APPLICATION
addappid(2493620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493621, 1, "2a92ccf0fd4c81e0594d16faa46392816b0090a5428abb2b1434b9144bf01353")

