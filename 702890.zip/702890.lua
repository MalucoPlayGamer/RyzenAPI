-- Lua provided by RyzenAPI
-- Game: BlazBlue Cross Tag Battle

-- MAIN APPLICATION
addappid(702890)
addappid(804640)
addappid(804641)
addappid(804642)
addappid(804643)
addappid(804644)
addappid(804645)
addappid(804646)
addappid(804647)
addappid(824380)
addappid(824381)
addappid(824382)
addappid(1074980)
addappid(1175090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(702891, 1, "ee68effbac207fcf6b136fa77b7b139ba156c4f9558ad2b4197224d0a7c8406d")
addappid(815770, 0, "04a4d3c47951a2123a2b8549b3d66edb26f5f31f9c9c94045dbfd6ad9004fb40")
