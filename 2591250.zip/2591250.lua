-- Lua provided by RyzenAPI
-- Game: Swords & Crystals Online

-- MAIN APPLICATION
addappid(2591250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591251, 1, "ec23a55bf47f3c53104f2e53833954862f39758bcee908eff8a0ba7620165e3c")

