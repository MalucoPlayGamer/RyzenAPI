-- Lua provided by RyzenAPI
-- Game: Swords & Crystals Online

-- MAIN APPLICATION
addappid(2591250)
addappid(2680910)
addappid(2680920)
addappid(2680930)
addappid(2680940)
addappid(2680950)
addappid(2680960)
addappid(2680970)
addappid(2680980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591251, 1, "ec23a55bf47f3c53104f2e53833954862f39758bcee908eff8a0ba7620165e3c")

