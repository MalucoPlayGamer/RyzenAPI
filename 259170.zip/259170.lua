-- Lua provided by RyzenAPI
-- Game: Alone in the Dark (2008)

-- MAIN APPLICATION
addappid(259170)

-- MAIN APP DEPOTS / PACKAGES
addappid(259171, 1, "36a625c3c671f93e981314833d0250232a6ff453cd9f7f626e94425c2f7f731a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
