-- Lua provided by SkyAPI 
-- Game: Alone in the Dark (2008)
addappid(259170)
addappid(259171, 1, "36a625c3c671f93e981314833d0250232a6ff453cd9f7f626e94425c2f7f731a")
