-- Lua provided by RyzenAPI
-- Game: Portal: Forbidden Testing Tracks

-- MAIN APPLICATION
addappid(1636310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636311, 1, "8aa5f895f6bc900933491cf629eadc3a333fbcf3970b4b42afc283c3907af4e7")

