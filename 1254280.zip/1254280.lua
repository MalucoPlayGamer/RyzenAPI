-- Lua provided by RyzenAPI
-- Game: Game: Locked

-- MAIN APPLICATION
addappid(1254280)
-- Game: addappid(1254280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254281, 1, "ca609446424525ea148854501f921d5f3e55f1fafd080f11d4087a593cbe1ae7")
