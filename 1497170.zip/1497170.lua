-- Lua provided by RyzenAPI
-- Game: ONNANOKO KEEPER 2

-- MAIN APPLICATION
addappid(1497170)
-- Game: addappid(1497170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497171, 1, "99c4daeafbf987bc966d0ee1f38f2bb0dd5c5a497e694948fb9e0f30deb3d3b6")
