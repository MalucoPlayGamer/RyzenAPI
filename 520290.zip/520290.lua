-- Lua provided by SkyAPI 
-- Game: Fright Light
addappid(520290)
addappid(520291, 1, "868801624c3a07e1df9df0b51ff49345e88c5fe16ceceadd412f8b6e200bf098")
