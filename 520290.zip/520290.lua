-- Lua provided by RyzenAPI
-- Game: Game: Fright Light

-- MAIN APPLICATION
addappid(520290)
-- Game: addappid(520290)

-- MAIN APP DEPOTS / PACKAGES
addappid(520291, 1, "868801624c3a07e1df9df0b51ff49345e88c5fe16ceceadd412f8b6e200bf098")
