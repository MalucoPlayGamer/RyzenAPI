-- Lua provided by RyzenAPI
-- Game: Fright Light

-- MAIN APPLICATION
addappid(520290)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(520291, 1, "868801624c3a07e1df9df0b51ff49345e88c5fe16ceceadd412f8b6e200bf098")

