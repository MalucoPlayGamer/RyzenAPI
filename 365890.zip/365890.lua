-- Lua provided by RyzenAPI
-- Game: Heroes of Normandie

-- MAIN APPLICATION
addappid(365890)
addappid(421100)
addappid(502510)

-- MAIN APP DEPOTS / PACKAGES
addappid(365891, 1, "64c92281189e6b99fe82853fcfdcaa8e8c0b272cb63885382083dcd223398360")

