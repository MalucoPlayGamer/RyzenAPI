-- Lua provided by RyzenAPI
-- Game: 365890

-- MAIN APPLICATION
addappid(365890)
-- Game: addappid(365890)

-- MAIN APP DEPOTS / PACKAGES
addappid(365891, 1, "64c92281189e6b99fe82853fcfdcaa8e8c0b272cb63885382083dcd223398360")
