-- Lua provided by RyzenAPI
-- Game: Luvocious

-- MAIN APPLICATION
addappid(714730)
addappid(868990)
addappid(899490)
addappid(986470)

-- MAIN APP DEPOTS / PACKAGES
addappid(714731, 1, "1ec2e16fffd6758d33c90ca81102f286498af1b5dcf276279d809db204f75b49")

