-- Lua provided by RyzenAPI
-- Game: 714730

-- MAIN APPLICATION
addappid(714730)
-- Game: addappid(714730)

-- MAIN APP DEPOTS / PACKAGES
addappid(714731, 1, "1ec2e16fffd6758d33c90ca81102f286498af1b5dcf276279d809db204f75b49")
