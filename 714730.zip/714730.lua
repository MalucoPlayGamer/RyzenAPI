-- Lua provided by SkyAPI 
-- Game: Luvocious
addappid(714730)
addappid(714731, 1, "1ec2e16fffd6758d33c90ca81102f286498af1b5dcf276279d809db204f75b49")
