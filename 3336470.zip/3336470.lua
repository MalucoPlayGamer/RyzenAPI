-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Card Frame Starter Pack

-- MAIN APPLICATION
addappid(3336470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3336470,0,"5c834f8a2a6fb87c42c1918258814e352845dff871e97e4030638ea44e67d5a4")

