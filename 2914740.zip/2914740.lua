-- Lua provided by RyzenAPI
-- Game: Game: Haus Of Irndrous

-- MAIN APPLICATION
addappid(2914740)
-- Game: addappid(2914740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914741, 1, "c2e8fd0068dfe562f6b3da00577f8002a401834fee2ca6166ca8560dd3954187")
