-- Lua provided by RyzenAPI
-- Game: Final Shot

-- MAIN APPLICATION
addappid(2890510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890511, 1, "78b05c509d7deea30422a25974039d5e6c655f4bce93f662b08f30270d6ad48e")

