-- Lua provided by RyzenAPI
-- Game: Ghosts of Tabor

-- MAIN APPLICATION
addappid(1957780)
addappid(2057010)
addappid(2057011)
addappid(2057012)
addappid(2280860)
addappid(2647740)
addappid(2711470)
addappid(2713060)
addappid(3028510)
addappid(3170210)
addappid(3339390)
addappid(3339400)
addappid(3579160)
addappid(3679620)
addappid(3691740)
addappid(3781300)
addappid(3828690)
addappid(3967620)
addappid(4060950)
addappid(4165770)
addappid(4213820)
addappid(4359990)
addappid(4720710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1957781, 1, "80f7fd489853661f0fa88a271db140773c0766a9b9d8cd99f16fea9b00aa8898")

