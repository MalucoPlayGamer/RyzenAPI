-- Lua provided by RyzenAPI
-- Game: addappid(1957780)

-- MAIN APPLICATION
addappid(1957780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957781, 1, "80f7fd489853661f0fa88a271db140773c0766a9b9d8cd99f16fea9b00aa8898")
