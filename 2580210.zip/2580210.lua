-- Lua provided by RyzenAPI
-- Game: SCP: Rulebreaker

-- MAIN APPLICATION
addappid(2580210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2580211, 1, "2678a7bc7d24a9870e98382921d938ed8bea56bc12ab6e8af2634ff79334e238")

