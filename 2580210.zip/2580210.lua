-- Lua provided by RyzenAPI
-- Game: Game: SCP: Rulebreaker

-- MAIN APPLICATION
addappid(2580210)
-- Game: addappid(2580210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2580211, 1, "2678a7bc7d24a9870e98382921d938ed8bea56bc12ab6e8af2634ff79334e238")
