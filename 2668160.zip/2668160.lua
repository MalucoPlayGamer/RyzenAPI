-- Lua provided by RyzenAPI 
-- Game: Escort's Secrets 18+
addappid(2668160)
addappid(2668161, 1, "74693a5d4069437d5cd203a258383afcfa43ca3572d4d72e48632a1b0bbeed1e")
