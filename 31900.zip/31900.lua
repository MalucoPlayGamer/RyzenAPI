-- Lua provided by RyzenAPI
-- Game: 31900

-- MAIN APPLICATION
addappid(31900)
-- Game: addappid(31900)

-- MAIN APP DEPOTS / PACKAGES
addappid(31901, 1, "1e7840dd5eb9e0253e638d70f01fd8b1624a59eb5cfaa7c48bf56b0bdd574faf")
