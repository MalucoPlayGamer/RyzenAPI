-- Lua provided by RyzenAPI
-- Game: Game: Fold

-- MAIN APPLICATION
addappid(1021640)
-- Game: addappid(1021640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021641, 1, "ee958fb2ab7c013fa14cbf1aa92d0c5ac5217364a01fa301b51f8958f620bc47")
