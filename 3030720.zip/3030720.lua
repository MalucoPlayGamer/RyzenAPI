-- Lua provided by RyzenAPI
-- Game: FATE: Reawakened

-- MAIN APPLICATION
addappid(3030720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3030723,0,"d925533af99c1e945956c6294e981eb95863ab700955a2065244b84092708f5b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4362450)
