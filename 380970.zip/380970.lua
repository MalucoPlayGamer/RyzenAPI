-- Lua provided by RyzenAPI
-- Game: addappid(380970)

-- MAIN APPLICATION
addappid(380970)

-- MAIN APP DEPOTS / PACKAGES
addappid(380971, 1, "696d6b8798709b4c0e9bc903d15fe9a38f0af3b01c0b8c674504fc77761e16bd")
