-- Lua provided by RyzenAPI
-- Game: addappid(1174270)

-- MAIN APPLICATION
addappid(1174270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174271, 1, "cc0097f02e8ad3b22334398af25fd156eeb751545a8c23a70dca1f51ebb4ff86")
