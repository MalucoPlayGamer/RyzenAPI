-- Lua provided by RyzenAPI
-- Game: Game: Metania

-- MAIN APPLICATION
addappid(2432190)
-- Game: addappid(2432190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432191, 1, "fa45fa7fae040769e0ba31109a842950258107e5c45f0c18562305976aad3064")
