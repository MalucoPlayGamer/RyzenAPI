-- Lua provided by RyzenAPI
-- Game: Metania

-- MAIN APPLICATION
addappid(2432190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432191, 1, "fa45fa7fae040769e0ba31109a842950258107e5c45f0c18562305976aad3064")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
