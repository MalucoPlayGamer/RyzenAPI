-- Lua provided by RyzenAPI
-- Game: addappid(1536420)

-- MAIN APPLICATION
addappid(1536420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536421, 1, "21de185263a31a43460aa48e475ec28a4b2b5032bef96f0086eab0e3746508d6")
