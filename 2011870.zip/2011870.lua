-- Lua provided by RyzenAPI
-- Game: addappid(2011870)

-- MAIN APPLICATION
addappid(2011870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011871, 1, "3c76d6593eba8e1550a8620c4f239a5418c09eb2bb168d3e4bb4b89f579927cf")
