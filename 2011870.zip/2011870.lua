-- Lua provided by RyzenAPI
-- Game: BRAiN VOMiTS GARDEN

-- MAIN APPLICATION
addappid(2011870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2011871, 1, "3c76d6593eba8e1550a8620c4f239a5418c09eb2bb168d3e4bb4b89f579927cf")

