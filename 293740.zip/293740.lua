-- Lua provided by RyzenAPI
-- Game: Road Not Taken

-- MAIN APPLICATION
addappid(293740)

-- MAIN APP DEPOTS / PACKAGES
addappid(293741, 1, "a7bf824fd11f929a8f12b890c9de4ff72a13f132ab6ab242ee0d2ad893b8a85c")
addappid(293742, 1, "f057e3114e8d2f91b77d6f5bc9b2147d12d842155121ab1808bfc7322a9eaeaa")
