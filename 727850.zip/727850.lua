-- Lua provided by RyzenAPI
-- Game: AppID 727850

-- MAIN APPLICATION
addappid(727850)

-- MAIN APP DEPOTS / PACKAGES
addappid(727851, 1, "70aeeadd2888118c2206b374ff28901e625e757a317c623144afe2a36467a1fb")
addappid(727854, 1, "047d8d44c81794c52712b9a646e76ff63a27992e7987a45c9860dd664b17448b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1176121)
