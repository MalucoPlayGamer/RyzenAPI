-- Lua provided by RyzenAPI
-- Game: 1480600

-- MAIN APPLICATION
addappid(1480600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480602,0,"b52df0e712d6cda2ac8b4dbd30bd5011dc2927a3ac394f2ca19ac96d26c2345f")

