-- Lua provided by RyzenAPI
-- Game: Glassteroids

-- MAIN APPLICATION
addappid(929530)

-- MAIN APP DEPOTS / PACKAGES
addappid(929531, 1, "5596777dbfd26512575fb7a6facc716de133be102dc42a3774236643c0cfdcd3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
