-- Lua provided by RyzenAPI
-- Game: 929530

-- MAIN APPLICATION
addappid(929530)
-- Game: addappid(929530)

-- MAIN APP DEPOTS / PACKAGES
addappid(929531, 1, "5596777dbfd26512575fb7a6facc716de133be102dc42a3774236643c0cfdcd3")
