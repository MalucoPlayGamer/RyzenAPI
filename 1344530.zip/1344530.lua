-- Lua provided by SkyAPI 
-- Game: AppID 1344530
addappid(1344530)
addappid(1344531, 1, "7b2928a85c371f498b84576b21b8d5a8351915677bf27b8474238aa57acc0121")
