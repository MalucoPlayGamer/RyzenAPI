-- Lua provided by RyzenAPI 
-- Game: Mirror Layers Prologue
addappid(1746440)
addappid(1746441, 1, "1126a1828619fab02969946b66b0b15713482b7b6294255c7f8ee9767da880ee")
