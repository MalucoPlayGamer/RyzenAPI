-- Lua provided by RyzenAPI
-- Game: Mirror Layers Prologue

-- MAIN APPLICATION
addappid(1746440)
-- Game: addappid(1746440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746441, 1, "1126a1828619fab02969946b66b0b15713482b7b6294255c7f8ee9767da880ee")
