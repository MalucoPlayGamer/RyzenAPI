-- Lua provided by RyzenAPI
-- Game: 東方鬼形獣 〜 Wily Beast and Weakest Creature.

-- MAIN APPLICATION
addappid(1079160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1079161, 1, "38a7e7a4d7cf6a628645c2c4430acc30e7a168257f6f0c81f209bab6a133d921")
