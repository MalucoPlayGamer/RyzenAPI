-- Lua provided by SkyAPI 
-- Game: AppID 1079160
addappid(1079160)
addappid(1079161, 1, "38a7e7a4d7cf6a628645c2c4430acc30e7a168257f6f0c81f209bab6a133d921")
