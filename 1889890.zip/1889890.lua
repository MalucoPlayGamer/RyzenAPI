-- Lua provided by RyzenAPI
-- Game: Shinehill

-- MAIN APPLICATION
addappid(1889890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889891, 1, "394f614167c2148a460030a32651bb7767018fd312d0faf108ccd8fc3ee988a2")

