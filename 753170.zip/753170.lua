-- Lua provided by RyzenAPI
-- Game: Game: Blood Harvest 2

-- MAIN APPLICATION
addappid(753170)
-- Game: addappid(753170)

-- MAIN APP DEPOTS / PACKAGES
addappid(753171, 1, "a16de667b99cef13a418a595bac584f89f61e8b8311f89dcbb0e35fb08e071ef")
