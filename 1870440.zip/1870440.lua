-- Lua provided by SkyAPI 
-- Game: Funny Panda
addappid(1870440)
addappid(1870441, 1, "f8b84530d6d89432fa5df69bbb66d7f434d93bd35a672a7e8b773db60d5c4101")
