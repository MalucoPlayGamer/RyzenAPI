-- Lua provided by RyzenAPI
-- Game: 大秦帝国

-- MAIN APPLICATION
addappid(1526520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526521, 1, "6f5c6a5a7e9aa164289b7aa26f9450e406391e5b2f96c06c172799239cb2cec4")

