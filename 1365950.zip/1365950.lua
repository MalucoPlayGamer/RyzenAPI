-- Lua provided by RyzenAPI
-- Game: VR Hentai room

-- MAIN APPLICATION
addappid(1365950)
addappid(1374150)
addappid(1387310)
addappid(1392120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365951, 1, "13b00a9f6810286b72fbf28a56307d24cc5b6565239e7e1f571695ff07038dba")
