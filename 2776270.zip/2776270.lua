-- Lua provided by RyzenAPI
-- Game: Beetleball

-- MAIN APPLICATION
addappid(2776270)
addappid(5078680) -- Beetleball - The Beetle Billionaire's Deluxe Golden Scarab Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(2776271, 1, "715a2eb61fe74a8bc428c1f57b1527ae9e0120b0d7f774444110dc9f96969bae")
addappid(2776272, 1, "c2e542cad45ccb5d37718e68c4ed84c1aa75abfb71a48a57f6219f1234fb377a") -- (windows)
