-- Lua provided by RyzenAPI
-- Game: Waltz of the Wizard (Legacy demo)

-- MAIN APPLICATION
addappid(436820)

-- MAIN APP DEPOTS / PACKAGES
addappid(436821, 1, "0d0605d7e07b9d7a30825092b67e7423b8565c1f0015fbbf7d136cf339149889")
