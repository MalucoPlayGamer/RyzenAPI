-- Lua provided by RyzenAPI
-- Game: Game: AppID 600450

-- MAIN APPLICATION
addappid(600450)
-- Game: addappid(600450)

-- MAIN APP DEPOTS / PACKAGES
addappid(600451, 1, "413954757e1df43e4769a4550afe0ebdab79e63cd8c5e97aca5b2137f90d1bc8")
