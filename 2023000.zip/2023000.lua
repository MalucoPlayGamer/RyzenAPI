-- Lua provided by RyzenAPI
-- Game: 2023000

-- MAIN APPLICATION
addappid(2023000)
-- Game: addappid(2023000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023001, 1, "9d6fde66a154326fc97a1d9d950ff733888d0bbac740f7c2c39a0cf593aa293b")
