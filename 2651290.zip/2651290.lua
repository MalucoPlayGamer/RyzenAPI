-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2651290)
addappid(2651291)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651292,0,"695bc3fdfafcddb5bd381f74f0f5df25e7834bf690e4d325face89a635a706d5")
