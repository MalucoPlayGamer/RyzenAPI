-- Lua provided by RyzenAPI
-- Game: addappid(2051000)

-- MAIN APPLICATION
addappid(2051000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051000,0,"fefe74d2b068d6604d6cec3f5de2586f0de14ec511b2933773f718c704d3a4da")
