-- Lua provided by RyzenAPI
-- Game: addappid(336420)

-- MAIN APPLICATION
addappid(336420)

-- MAIN APP DEPOTS / PACKAGES
addappid(336421, 1, "7adbb562503f7136bbe99da70ffe4a6b85d3c32b0f2ae77a0febf7f50740ebf6")
