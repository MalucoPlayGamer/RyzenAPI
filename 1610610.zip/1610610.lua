-- Lua provided by RyzenAPI
-- Game: 1610610

-- MAIN APPLICATION
addappid(1610610)
-- Game: addappid(1610610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610611, 1, "0829a7d9cf7d80ce970d60486b6d50b072c190ffdfc5336e53090407a8a658df")
