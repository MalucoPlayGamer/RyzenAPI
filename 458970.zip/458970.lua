-- Lua provided by RyzenAPI
-- Game: Intruder Alert: Ixian Operations

-- MAIN APPLICATION
addappid(458970)

-- MAIN APP DEPOTS / PACKAGES
addappid(458971, 1, "3c886a7a553bc1b3199881819006c4a2553a14d43b4708d71b6ea8ce0f2e2192")

