-- Lua provided by SkyAPI 
-- Game: AppID 2398770
addappid(2398770)
addappid(2398771, 1, "c5656c25a5c84902dc64795bbc1c4f8c6db643709a0bd59bfdfcf9a3ef147e3f")
