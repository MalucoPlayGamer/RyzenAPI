-- Lua provided by RyzenAPI
-- Game: addappid(427510)

-- MAIN APPLICATION
addappid(427510)

-- MAIN APP DEPOTS / PACKAGES
addappid(427511, 1, "06a40ec453b38b8756a9927dc2ac1ef5a76d779fd9e548649a385029a56a4fab")
