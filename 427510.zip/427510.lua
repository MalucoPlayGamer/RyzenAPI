-- Lua provided by RyzenAPI
-- Game: Way of the Samurai 3

-- MAIN APPLICATION
addappid(427510)

-- MAIN APP DEPOTS / PACKAGES
addappid(427511, 1, "06a40ec453b38b8756a9927dc2ac1ef5a76d779fd9e548649a385029a56a4fab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(428310)
addappid(428311)
addappid(428312)
