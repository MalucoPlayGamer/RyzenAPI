-- Lua provided by RyzenAPI
-- Game: AppID 2368190

-- MAIN APPLICATION
addappid(2368190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2368191, 1, "9c71d08cf4f1ffdc9b64ca164019847993c016e012cb630e08841f80d31db35f")

