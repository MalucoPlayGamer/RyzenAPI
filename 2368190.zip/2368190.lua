-- Lua provided by RyzenAPI
-- Game: 2368190

-- MAIN APPLICATION
addappid(2368190)
-- Game: addappid(2368190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368191, 1, "9c71d08cf4f1ffdc9b64ca164019847993c016e012cb630e08841f80d31db35f")
