-- Lua provided by RyzenAPI
-- Game: Infinity Wars: Animated Trading Card Game

-- MAIN APPLICATION
addappid(257730)
addappid(4695450)

-- MAIN APP DEPOTS / PACKAGES
addappid(257731, 1, "d87fa0b01e7a3904c829208f9e32529a7ddee5948df274680a96cb548edc59c5")
addappid(257732, 1, "afbe015157eb81424585d53a3d4908adcc88df7103a94d682462518af566f63d")

