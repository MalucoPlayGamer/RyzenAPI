-- Lua provided by RyzenAPI
-- Game: Infinity Wars: Animated Trading Card Game

-- MAIN APPLICATION
addappid(257730)
addappid(470610)
addappid(473870)
addappid(473871)
addappid(502310)
addappid(544560)
addappid(544561)
addappid(547240)
addappid(4695450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(257731, 1, "d87fa0b01e7a3904c829208f9e32529a7ddee5948df274680a96cb548edc59c5")
addappid(257732, 1, "afbe015157eb81424585d53a3d4908adcc88df7103a94d682462518af566f63d")

