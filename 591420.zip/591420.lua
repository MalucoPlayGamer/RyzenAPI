-- Lua provided by RyzenAPI
-- Game: Game: Zup! 4

-- MAIN APPLICATION
addappid(591420)
-- Game: addappid(591420)

-- MAIN APP DEPOTS / PACKAGES
addappid(591421, 1, "20aa9bd1a4572eabf41b688b7260d48f564356fc8e7d899cedb0915dbed9c4d6")
addappid(610820, 0, "c49652dd6f38e0261bd6aa9969aa3ceac8fcc37c79bb293cadc8ca8abf2a4afc")
