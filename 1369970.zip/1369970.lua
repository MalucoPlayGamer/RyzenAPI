-- Lua provided by RyzenAPI
-- Game: addappid(1369970)

-- MAIN APPLICATION
addappid(1369970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369971, 1, "6d720b6b8c3313de422469784a69b9f3e35c171c9fd38ed48f481029db65a7ef")
