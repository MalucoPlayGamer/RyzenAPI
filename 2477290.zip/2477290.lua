-- Lua provided by RyzenAPI
-- Game: Half-Life 2 RTX

-- MAIN APPLICATION
addappid(2477290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477291, 1, "c2ed46a3853ae84c30e191f69f3d3b0b0760008364bfdb03b38ed00cbfb0d22a")

