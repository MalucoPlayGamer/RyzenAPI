-- Lua provided by RyzenAPI
-- Game: Wheelborn

-- MAIN APPLICATION
addappid(2704210)
-- Game: addappid(2704210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704211, 1, "be205d15e95247c381eed2e286b2cc92ca09b422c3bd03154dc1bdd06c3bb489")
addappid(2704212, 1, "c2d0f910cb71126976e154189bbb5c8d1b8e2c3dbf5eebb5f77dc7ecc706e0b3")
