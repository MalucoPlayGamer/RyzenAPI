-- Lua provided by RyzenAPI
-- Game: Game: AppID 1108330

-- MAIN APPLICATION
addappid(1108330)
-- Game: addappid(1108330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108331, 1, "e97bf6350fa8713af8e8d091542ded849ddb21752f379d161bebbabe57a3c3b1")
