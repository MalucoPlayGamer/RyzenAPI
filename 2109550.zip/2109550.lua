-- Lua provided by RyzenAPI
-- Game: 2109550

-- MAIN APPLICATION
addappid(2109550)
-- Game: addappid(2109550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109551, 1, "05447179d6f57fc95feae1d7e14d9436e48ac497b601ebe2f5ec5e6009eb89ef")
