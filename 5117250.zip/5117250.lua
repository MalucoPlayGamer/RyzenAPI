-- Lua provided by RyzenAPI
-- Game: Tidying Simulator

-- MAIN APPLICATION
addappid(5117250) -- Tidying Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(5117251, 1, "93d3478ebde948abd0e73e90342aaf18038e90d1634085267862a1c837df41e7") -- Depot 5117251

