-- 3667080's Lua and Manifest Created by Hubcap Manifest
-- Farlands Journey
-- Created: July 08, 2026 at 06:06:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3667080) -- Farlands Journey
-- MAIN APP DEPOTS
addappid(3667081, 1, "06025a2d708931437dcfeb0deb80927192d3dd5606bb227c163c8fb2e0bef7e7") -- Depot 3667081
setManifestid(3667081, "7296703967393941821", 214599435)