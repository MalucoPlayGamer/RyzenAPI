-- Lua provided by RyzenAPI
-- Game: 215815

-- MAIN APPLICATION
addappid(215815)
-- Game: addappid(215815)

-- MAIN APP DEPOTS / PACKAGES
addappid(215815,0,"19e7e83fab2888a49c0e4b76ff01d1c1bff03515ea4e86d5c27e52535055363b")
