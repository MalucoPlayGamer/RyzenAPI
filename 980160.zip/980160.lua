-- Lua provided by RyzenAPI
-- Game: 980160

-- MAIN APPLICATION
addappid(980160)
-- Game: addappid(980160)

-- MAIN APP DEPOTS / PACKAGES
addappid(980161, 1, "8bd3ba0ee71cdfbd191566564d3d240455dfcfd1109cfd434a1ebe7d018fc7e7")
