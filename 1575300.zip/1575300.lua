-- Lua provided by RyzenAPI
-- Game: 1575300

-- MAIN APPLICATION
addappid(1575300)
-- Game: addappid(1575300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575301, 1, "c06c1986cfa306ae74d3c6ecb84169a7dd1d5746c2eea8703f8b619547679efe")
