-- Lua provided by RyzenAPI
-- Game: Taiga

-- MAIN APPLICATION
addappid(1961380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961381, 1, "e8e66d65283d7eef91cd4ea2488557e639b382f96b9b48e331e8d70962649e7f")

