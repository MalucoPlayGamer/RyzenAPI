-- Lua provided by RyzenAPI
-- Game: Garage Flipper: Prologue

-- MAIN APPLICATION
addappid(2414010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2414011, 1, "249ed6113de0d876926c70f953e9eb654dade489cb0875356517e66d9480bc53")
