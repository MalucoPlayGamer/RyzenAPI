-- Lua provided by RyzenAPI
-- Game: MECCHA CHAMELEON

-- MAIN APPLICATION
addappid(4704690)

-- MAIN APP DEPOTS / PACKAGES
addappid(4704690,0,"ddf5e06be47f8470e5735390673244b191e5ab5562310db7bdbcb539a69a4900")
addappid(4704691,0,"04f85383091217f3b9735b5f34a09e0fbcbcb9afe68e33c25244d37bf45933f8")
addappid(4704691, 1, "04f85383091217f3b9735b5f34a09e0fbcbcb9afe68e33c25244d37bf45933f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
