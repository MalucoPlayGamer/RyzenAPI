-- Lua provided by RyzenAPI
-- Game: Game: MECCHA CHAMELEON

-- MAIN APPLICATION
addappid(4704690)
-- Game: addappid(4704690)

-- MAIN APP DEPOTS / PACKAGES
addappid(4704691, 1, "04f85383091217f3b9735b5f34a09e0fbcbcb9afe68e33c25244d37bf45933f8")
