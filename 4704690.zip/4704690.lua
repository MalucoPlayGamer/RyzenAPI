-- 4704690's Lua and Manifest Created by Hubcap Manifest
-- MECCHA CHAMELEON
-- Created: June 24, 2026 at 11:48:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4704690, 1, "ddf5e06be47f8470e5735390673244b191e5ab5562310db7bdbcb539a69a4900") -- MECCHA CHAMELEON
-- MAIN APP DEPOTS
addappid(4704691, 1, "04f85383091217f3b9735b5f34a09e0fbcbcb9afe68e33c25244d37bf45933f8") -- Depot 4704691
setManifestid(4704691, "5119526807930064782", 2574479987)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)