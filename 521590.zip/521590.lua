-- Lua provided by RyzenAPI
-- Game: Subterra

-- MAIN APPLICATION
addappid(521590)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(521591, 1, "6956646dc87427a60856f294dcf3aad7ff6395735c85f02c7288d53dad2182ef")

