-- Lua provided by RyzenAPI
-- Game: Game: Witchfire

-- MAIN APPLICATION
addappid(3156770)
-- Game: addappid(3156770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156771, 1, "e09d98ec7fb6604ed8c2f44292e3f8cb278dd0add46641f0434375eeb9255e87")
