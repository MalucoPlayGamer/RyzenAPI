-- Lua provided by SkyAPI 
-- Game: Witchfire
addappid(3156770)
addappid(3156771, 1, "e09d98ec7fb6604ed8c2f44292e3f8cb278dd0add46641f0434375eeb9255e87")
