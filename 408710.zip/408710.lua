-- Lua provided by RyzenAPI
-- Game: Game: Hacknet Official Soundtrack

-- MAIN APPLICATION
addappid(408710)
-- Game: addappid(408710)

-- MAIN APP DEPOTS / PACKAGES
addappid(408711, 1, "ac86110f9a605651695235db27a8a3554f3484a2de635e606af18125d41cb481")
