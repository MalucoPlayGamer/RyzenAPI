-- Lua provided by RyzenAPI
-- Game: The Lab and Dungeons

-- MAIN APPLICATION
addappid(2658960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658961, 1, "ec84de5202d252dedac61991726c9c01ece919ea615a292378c4e6493fbfb1e7")

