-- Lua provided by RyzenAPI
-- Game: FIND ALL 7: Japan

-- MAIN APPLICATION
addappid(3491570)
