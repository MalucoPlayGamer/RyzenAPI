-- Lua provided by RyzenAPI
-- Game: FIND ALL 7: Japan

-- MAIN APPLICATION
addappid(3491570)
addappid(3680490)
addappid(3722700)

