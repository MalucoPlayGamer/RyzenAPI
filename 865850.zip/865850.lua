-- Lua provided by RyzenAPI
-- Game: addappid(865850)

-- MAIN APPLICATION
addappid(865850)

-- MAIN APP DEPOTS / PACKAGES
addappid(865851, 1, "090106fa5b726a7e922bb97a789f174c4b4e5adbacdca47a443d4e2070097415")
