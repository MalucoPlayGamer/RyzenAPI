-- Lua provided by RyzenAPI
-- Game: Dehumanized

-- MAIN APPLICATION
addappid(865850)

-- MAIN APP DEPOTS / PACKAGES
addappid(865851, 1, "090106fa5b726a7e922bb97a789f174c4b4e5adbacdca47a443d4e2070097415")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
