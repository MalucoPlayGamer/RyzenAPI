-- Lua provided by RyzenAPI
-- Game: addappid(1364100)

-- MAIN APPLICATION
addappid(1364100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364101, 1, "137e823e4c35d9262e8136fffa69341c31eff4ffff14b73781b2d2e6b5060282")
