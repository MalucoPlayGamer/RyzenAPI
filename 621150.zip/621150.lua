-- Lua provided by SkyAPI 
-- Game: False Shelter
addappid(621150)
addappid(621151, 1, "a9959c5d8014778be79a981d0f8ab5ea8fb8f8ac8e86c1f29d1dfd420eb165a0")
