-- Lua provided by RyzenAPI
-- Game: Baldo: The Guardian Owls

-- MAIN APPLICATION
addappid(1614890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614891, 1, "e66b4c8125567f712682f0e053b3320f272c9849a472ddfb9ff8c79e40f3c143")
