-- Lua provided by RyzenAPI
-- Game: 762840

-- MAIN APPLICATION
addappid(762840)
-- Game: addappid(762840)

-- MAIN APP DEPOTS / PACKAGES
addappid(762841, 1, "ebd35af5b2f8549d80d6c2caeb0e747f64e3fe30357b04ad74f8723064b92d4b")
