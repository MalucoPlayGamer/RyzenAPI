-- Lua provided by RyzenAPI
-- Game: AppID 1028350

-- MAIN APPLICATION
addappid(1028350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028351, 1, "65ed4d18f8c7d6dda949a13cd3c69dbc466e2dbeb097493c9989acbb225eccc9")
