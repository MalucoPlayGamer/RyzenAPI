-- Lua provided by RyzenAPI
-- Game: addappid(1234890)

-- MAIN APPLICATION
addappid(1234890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234891, 1, "b41dd3d011b2b7e93a8e0cb7701804caa2b79893c93bf9340df889a8d6ba6d25")
