-- Lua provided by RyzenAPI
-- Game: Sokpop S07: labyrinth

-- MAIN APPLICATION
addappid(1234890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1234891, 1, "b41dd3d011b2b7e93a8e0cb7701804caa2b79893c93bf9340df889a8d6ba6d25")
