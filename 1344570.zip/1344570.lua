-- Lua provided by RyzenAPI
-- Game: 1344570

-- MAIN APPLICATION
addappid(1344570)
-- Game: addappid(1344570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344571, 1, "32ed59fa653a4a6743883cae36907b193017f08fb2bab151277aae376fffcdb3")
