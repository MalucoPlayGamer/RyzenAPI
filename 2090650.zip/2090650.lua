-- Lua provided by RyzenAPI
-- Game: 栖云异梦

-- MAIN APPLICATION
addappid(2090650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090651, 1, "66cb1985e0ef9ff98696691c40551ffabe2dcd79dba488284857204d6320dec8")
