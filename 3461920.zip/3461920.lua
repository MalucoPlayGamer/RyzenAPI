-- Lua provided by RyzenAPI
-- Game: Game: The Boba Teashop

-- MAIN APPLICATION
addappid(3461920)
-- Game: addappid(3461920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461921, 1, "be49622c16cf04591bbdb523169e72248065c5fb1da12c4868c780e4dd8e131b")
