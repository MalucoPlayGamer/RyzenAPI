-- Lua provided by SkyAPI 
-- Game: AppID 3473870
addappid(3473870)
addappid(3473871, 1, "989611e9d5e29fd41c06844a083bc67f8b13beddd5082ba3862fd1343474ea56")
