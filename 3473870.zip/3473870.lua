-- Lua provided by RyzenAPI
-- Game: 3473870

-- MAIN APPLICATION
addappid(3473870)
-- Game: addappid(3473870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473871, 1, "989611e9d5e29fd41c06844a083bc67f8b13beddd5082ba3862fd1343474ea56")
