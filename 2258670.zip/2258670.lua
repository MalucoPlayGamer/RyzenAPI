-- Lua provided by RyzenAPI
-- Game: Crawlspace 2

-- MAIN APPLICATION
addappid(2258670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258671, 1, "a08fbec458ff4492915abc987c978fa8d9e7c5bd4375f25ae49a82962d0b8a99")
