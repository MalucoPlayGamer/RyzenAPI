-- Lua provided by SkyAPI 
-- Game: Pâquerette Down the Bunburrows – Soundtrack
addappid(2373510)
addappid(2373511, 1, "4f6b5c97e0854e334c2417bd9aafbbc34a090a09c423054a243596e37408d610")
addappid(2373512, 1, "8529d4dd03e61061666cea089e1d1540a26da4e25ce7e1a24246dfd65c3fee81")
