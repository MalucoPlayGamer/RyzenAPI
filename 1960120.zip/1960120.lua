-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - ProCam

-- MAIN APPLICATION
addappid(1960120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960120,0,"4264306d8ffc328fe3731c1aa1281dc6a4158a3ff14a6f5879554c8c01a3c495")
