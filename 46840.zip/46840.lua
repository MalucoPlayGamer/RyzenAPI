-- Lua provided by RyzenAPI
-- Game: Ironclads: Chincha Islands War 1866

-- MAIN APPLICATION
addappid(46840)
-- Game: addappid(46840)

-- MAIN APP DEPOTS / PACKAGES
addappid(46841, 1, "60d776a49e04a10d3f33b2db747691ff6eebe993d381acd202efb1ffc47156c3")
