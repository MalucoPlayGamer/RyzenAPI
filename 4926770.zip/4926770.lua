-- Lua provided by RyzenAPI
-- Game: Guardian of soul tower

-- MAIN APPLICATION
addappid(4926770) -- Guardian of soul tower

-- MAIN APP DEPOTS / PACKAGES
addappid(4926771, 1, "fed7a5734e595c63097ebb8ed8e37a7ff69e89ad3c96e9537d58e6ce3e6284d1") -- Depot 4926771

