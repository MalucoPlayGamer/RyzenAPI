-- 4926770's Lua and Manifest Created by Hubcap Manifest
-- Guardian of soul tower
-- Created: August 23, 2026 at 05:45:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4926770) -- Guardian of soul tower
-- MAIN APP DEPOTS
addappid(4926771, 1, "fed7a5734e595c63097ebb8ed8e37a7ff69e89ad3c96e9537d58e6ce3e6284d1") -- Depot 4926771
setManifestid(4926771, "7415059639611455599", 276492016)