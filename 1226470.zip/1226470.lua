-- Lua provided by RyzenAPI
-- Game: 1226470

-- MAIN APPLICATION
addappid(1226470)
-- Game: addappid(1226470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226471, 1, "423d399dc47c7ca3342b69101b10dac6148f46cf3f812d06819e84b2fa0f6920")
