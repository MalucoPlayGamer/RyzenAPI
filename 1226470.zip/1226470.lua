-- Lua provided by RyzenAPI
-- Game: Shadow Arena

-- MAIN APPLICATION
addappid(1226470)
addappid(1312430)
addappid(1320670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226471, 1, "423d399dc47c7ca3342b69101b10dac6148f46cf3f812d06819e84b2fa0f6920")
