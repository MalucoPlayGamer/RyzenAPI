-- Lua provided by RyzenAPI
-- Game: Potato Arena Prologue

-- MAIN APPLICATION
addappid(2391760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391761, 1, "eb806af8650dbb0485e1391e620dbadf84852ad32a21dd092b9cecdc85092757")
