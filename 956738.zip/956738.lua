-- Lua provided by RyzenAPI
-- Game: Sun Ce - Officer Ticket / 孫策使用券

-- MAIN APPLICATION
addappid(956738)

-- MAIN APP DEPOTS / PACKAGES
addappid(956738,0,"ba8aff5f0c3c547f05586ff50f725761c074a0e7eb9ff89c158afb2ad35a9614")

