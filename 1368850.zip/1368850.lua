-- Lua provided by RyzenAPI
-- Game: AppID 1368850

-- MAIN APPLICATION
addappid(1368850)
-- Game: addappid(1368850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368851, 1, "44d8ee0dfe4c9e2b26bc3116d1adb19c5c5cf3ed5bb0963f10d16be179500984")
