-- Lua provided by RyzenAPI
-- Game: AppID 1368850

-- MAIN APPLICATION
addappid(1368850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368851, 1, "44d8ee0dfe4c9e2b26bc3116d1adb19c5c5cf3ed5bb0963f10d16be179500984")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
