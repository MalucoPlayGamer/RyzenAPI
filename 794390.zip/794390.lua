-- Lua provided by RyzenAPI
-- Game: Game: Zed Survival

-- MAIN APPLICATION
addappid(794390)
-- Game: addappid(794390)

-- MAIN APP DEPOTS / PACKAGES
addappid(794391, 1, "19c0016105b29c32fda33851ebbbbf0d2045e5dd6a7146d71d0df3ebe9991399")
