-- Lua provided by RyzenAPI
-- Game: Game: AppID 443050

-- MAIN APPLICATION
addappid(443050)
-- Game: addappid(443050)

-- MAIN APP DEPOTS / PACKAGES
addappid(443051, 1, "a1e846223c025abaa77955ad61c8ea4dae51f842fc05e11dd3f856ae62df6514")
