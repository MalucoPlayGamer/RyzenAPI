-- Lua provided by RyzenAPI
-- Game: 1092700

-- MAIN APPLICATION
addappid(1092700)
-- Game: addappid(1092700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092701, 1, "0e289d2329df3e89a531693565bc7dbc3a1d2a6813610246ad94b9ba1f2c9ac0")
