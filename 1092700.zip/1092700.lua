-- Lua provided by RyzenAPI
-- Game: Hello Neighbor Pre-Alpha

-- MAIN APPLICATION
addappid(1092700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092701, 1, "0e289d2329df3e89a531693565bc7dbc3a1d2a6813610246ad94b9ba1f2c9ac0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
