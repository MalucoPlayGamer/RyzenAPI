-- Lua provided by RyzenAPI
-- Game: addappid(1744260)

-- MAIN APPLICATION
addappid(1744260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744261, 1, "2db5833ca167b4af033247c39c8f10ba67dabe6bf509faeec751220e406c0ef1")
