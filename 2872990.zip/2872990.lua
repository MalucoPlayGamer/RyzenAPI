-- Lua provided by RyzenAPI 
-- Game: School Paranormal Laboratory
addappid(2872990)
addappid(2872991, 1, "d2a26f35b9a9889acc912a87a2c604707ad062bb1318bb565e6f1d29789d5133")
