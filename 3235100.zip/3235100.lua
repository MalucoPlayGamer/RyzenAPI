-- Lua provided by RyzenAPI
-- Game: oath Soundtrack

-- MAIN APPLICATION
addappid(3235100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3235101, 1, "af5b2c28383e071a1c1a4339b00e3c0efc9afc426f4b0a19458a6b84e768fa90")
