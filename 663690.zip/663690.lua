-- Lua provided by RyzenAPI 
-- Game: Rival Rampage
addappid(663690)
addappid(663691, 1, "cf62be1ffa7cba86decd9361b3d8a4aa5aebc261d66309679b6049f31306d076")
addappid(663692, 1, "2344fe4104569e3892f1b95984d58bb6966430b883395b14eb3385c8185ae05e")
