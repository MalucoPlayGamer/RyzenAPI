-- Lua provided by RyzenAPI
-- Game: 1507760

-- MAIN APPLICATION
addappid(1507760)
-- Game: addappid(1507760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507761, 1, "9c700bc65b86f4341a1aacfa337daf26217afd3bc3a8e7b77515c77cc798693f")
