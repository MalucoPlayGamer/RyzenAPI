-- Lua provided by RyzenAPI
-- Game: Gothic Clicker

-- MAIN APPLICATION
addappid(3055250)
addappid(4813280)
addappid(4813290)
addappid(4813300)
addappid(4813310)

