-- Lua provided by RyzenAPI
-- Game: Gothic Clicker

-- MAIN APPLICATION
addappid(3055250)
