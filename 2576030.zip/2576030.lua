-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor 2024

-- MAIN APPLICATION
addappid(2576030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576031, 1, "1a4b5ba505b2ead43295a2f62cbdd05640d6ddeeff354de7dc96573e3d8c443b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2675480)
addappid(2675490)
addappid(2675500)
addappid(2675510)
addappid(2675520)
addappid(2675530)
addappid(2675540)
addappid(2675550)
addappid(2675560)
addappid(2675570)
addappid(2675920)
addappid(2675930)
addappid(2675940)
addappid(2675950)
addappid(2675960)
addappid(2675970)
addappid(2675980)
addappid(2675990)
addappid(2687450)
addappid(2687460)
addappid(2690210)
