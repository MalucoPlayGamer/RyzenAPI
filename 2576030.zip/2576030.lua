-- Lua provided by RyzenAPI
-- Game: addappid(2576030)

-- MAIN APPLICATION
addappid(2576030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576031, 1, "1a4b5ba505b2ead43295a2f62cbdd05640d6ddeeff354de7dc96573e3d8c443b")
