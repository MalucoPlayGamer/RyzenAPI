-- Lua provided by RyzenAPI
-- Game: Stickman Strikes: Conquer Fantasy World

-- MAIN APPLICATION
addappid(2924170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924171, 1, "393522aa3a1d1b12e3f17121b739135ea044d357466490221b2a83030a7d3c08")

