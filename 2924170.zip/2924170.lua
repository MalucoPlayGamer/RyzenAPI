-- Lua provided by RyzenAPI 
-- Game: AppID 2924170
addappid(2924170)
addappid(2924171, 1, "393522aa3a1d1b12e3f17121b739135ea044d357466490221b2a83030a7d3c08")
