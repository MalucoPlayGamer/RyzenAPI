-- Lua provided by RyzenAPI
-- Game: addappid(1796080)

-- MAIN APPLICATION
addappid(1796080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796081, 1, "dadc413771ebfeb2a83703787fff594d2d41346c58bb60872786eb5c56ae5356")
