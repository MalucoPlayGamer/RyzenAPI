-- Lua provided by RyzenAPI
-- Game: 890710

-- MAIN APPLICATION
addappid(890710)
-- Game: addappid(890710)

-- MAIN APP DEPOTS / PACKAGES
addappid(890711, 1, "2e5171c069394ba16a9fa05b0e1c321178c56e48ba9b570fe25f52b0fef6fa46")
addappid(890712, 1, "90c40cd1e4ad237f30637d076a1565f06aa2957701edb4ce53ecaa4b4e3b1000")
