-- Lua provided by RyzenAPI
-- Game: addappid(2120070)

-- MAIN APPLICATION
addappid(2120070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120071, 1, "fd731a7d7b29f84de926aad725a83085c665cc40fb6b52584f71d4ab6b97db0c")
