-- Lua provided by RyzenAPI
-- Game: Project CARS - Dedicated Server

-- MAIN APPLICATION
addappid(332670)

-- MAIN APP DEPOTS / PACKAGES
addappid(332671, 1, "3c09b40b627f67bc52036fc0d8f4e280e2b8259e4cd2a1c311efe7261cd54e6b")
addappid(332672, 1, "9b5081b044912a39d39ba7ae60858ccd6b83a1b15885e9f42a2cf9961efce88c")

