-- Lua provided by RyzenAPI
-- Game: Happy's Humble Burger Farm: Obscura Programming (OST)

-- MAIN APPLICATION
addappid(1832450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832451, 1, "a03d23cda0bcded2e25af85afa6eb1b5cb291203d51184262e6c14b723e312a5")
