-- Lua provided by RyzenAPI
-- Game: 15190

-- MAIN APPLICATION
addappid(15190)
-- Game: addappid(15190)

-- MAIN APP DEPOTS / PACKAGES
addappid(15191, 1, "7031a109c25ebf52f04584a2e67cfa40d2978bda2a6465eee80c1190663b6329")
addappid(15192, 1, "2e067b2b40c3cdf3e2aa3036902a82d8b732982d639ed60c3c4b5016e5d52eb4")
addappid(15193, 1, "c3bc04918e6113269783fbf7bc9cda4e88aafc839d23fbdf4843b66a329a8c1a")
addappid(15194, 1, "b4e3ca5505fd0715522de458c38a667f23c7f0cb1ea48e64cb01dc93bd51bd8f")
addappid(15195, 1, "ce8241bbda6361ea400f6803fe8fbeca9c875aab06bb71c43f6a27e5fe50391e")
addappid(15196, 1, "847d10667477b2059d31650db3bfc3bebbd14cbb9331a58f9cc5dae1b3d81c47")
addappid(15197, 1, "f00bacb236a0fa3931d0717af4ef4e9b1fd937e5103dba0c1ecce8eab9ae302d")
