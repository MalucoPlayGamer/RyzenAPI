-- Lua provided by RyzenAPI
-- Game: CRETE Playtest

-- MAIN APPLICATION
addappid(2173260)
-- Game: addappid(2173260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173261, 1, "bbd69d58d726d73c2e83e15b3c00b6e3e91471458a61e1fc07893c584f1faa46")
