-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228988)
addappid(1753850)
addappid(1753851)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753852,0,"1323001ff8fe328625a3009762331895436cfd9a9799581191632e9fb4ee957d")

