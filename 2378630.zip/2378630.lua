-- Lua provided by RyzenAPI
-- Game: addappid(2378630)

-- MAIN APPLICATION
addappid(2378630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378630,0,"fc227986471c0ba10af08000a62d1676802df92afbfff6411ade394ae8c8dc34")
