-- Lua provided by RyzenAPI
-- Game: The Night is Grey

-- MAIN APPLICATION
addappid(1281490)
addappid(2696810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281491, 1, "365882e880bf72882d38c5cfe7196d4dc23254db55a2d75eff0ed57ad078ecb2")

