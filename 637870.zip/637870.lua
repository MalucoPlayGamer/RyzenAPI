-- Lua provided by RyzenAPI
-- Game: Slice&Dice

-- MAIN APPLICATION
addappid(637870)

-- MAIN APP DEPOTS / PACKAGES
addappid(637871, 1, "94e9e02d2967ddb70b80861b91ebd4cac3a2434f766a00e2469f164c51590e42")

