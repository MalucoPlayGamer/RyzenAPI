-- Lua provided by RyzenAPI 
-- Game: Hypergalactic Psychic Table Tennis 3000
addappid(1233690)
addappid(1233691, 1, "f666af2788507713093076f1541c9ec314b0dc41fd0cef18d54693c6ac9746e3")
addappid(1233692, 1, "6ce437977237053eb046117cd95b985c268cc2e7c0521d7e6b042366c0d9a43b")
