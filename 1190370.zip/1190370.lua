-- Lua provided by RyzenAPI
-- Game: Tank Hurricane

-- MAIN APPLICATION
addappid(1190370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190371, 1, "4b1aff37188ace1d50c5b3b15a48474409602ef5c6b3151c6ac45e5444653856")
