-- Lua provided by RyzenAPI
-- Game: Game: Magna Fortuna

-- MAIN APPLICATION
addappid(1122730)
-- Game: addappid(1122730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122731, 1, "630353e1f7629a49ce6fa6bffa768bf29e1b55773027574f604e6af5d3897763")
addappid(1122732, 1, "f304074352a7ea7c26e636b9c59286fc73308bc684721fb95e618b8f25af9c82")
addappid(1122733, 1, "3194e2fdcf738affe23501716227f51df84d50bd5bfd364c0d90c0a627e7dbef")
