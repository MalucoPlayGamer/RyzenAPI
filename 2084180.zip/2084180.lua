-- Lua provided by RyzenAPI
-- Game: Case 03: True Cannibal Boy

-- MAIN APPLICATION
addappid(2084180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084181, 1, "4c263e97a82241792593c0d920c2102dbfccc71c41b8fe64889e34951ef4e77a")
