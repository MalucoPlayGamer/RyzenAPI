-- Lua provided by RyzenAPI
-- Game: 猫猫旅行社欢迎你！ Momo's Revitalization Project!

-- MAIN APPLICATION
addappid(3586750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586751, 1, "22aaf4a7fb0acabdf3da18c61c8a251bd3d6797323a93bb643c446b2a4c5f612")
