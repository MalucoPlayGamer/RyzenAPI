-- Lua provided by RyzenAPI
-- Game: EDENS ZERO - Lacrima Set

-- MAIN APPLICATION
addappid(3345380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345380,0,"9a9b24b0fcbd745e892372f653dfe0b38e60db478743edb5bc9bf137727da8c2")
