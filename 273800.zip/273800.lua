-- Lua provided by RyzenAPI
-- Game: Forestry 2017 - The Simulation

-- MAIN APPLICATION
addappid(273800)

-- MAIN APP DEPOTS / PACKAGES
addappid(273801, 1, "012717ce2eb5af99dff1abc435f336dc1747f70b10f79b1b767f7a62de2b17c4")
