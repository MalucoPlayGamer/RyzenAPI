-- Lua provided by RyzenAPI
-- Game: 3443670

-- MAIN APPLICATION
addappid(3443670)
-- Game: addappid(3443670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3443671, 1, "d4af0513ebdd72229f2bdaac01a0b615f847229b544ac180ed010e60fa97eb61")
