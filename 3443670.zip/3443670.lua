-- Lua provided by RyzenAPI
-- Game: 赤ずきんちゃんのお見舞い

-- MAIN APPLICATION
addappid(3443670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3443671, 1, "d4af0513ebdd72229f2bdaac01a0b615f847229b544ac180ed010e60fa97eb61")

