-- Lua provided by RyzenAPI
-- Game: addappid(2451730)

-- MAIN APPLICATION
addappid(2451730)
addappid(2697660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451731, 1, "685c21ca8dc701d2588811dd5f6b1b9eaffb9715e2d3f58a68357bbb56f84a45")
