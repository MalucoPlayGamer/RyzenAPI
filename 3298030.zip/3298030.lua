-- Lua provided by RyzenAPI
-- Game: addappid(3298030)

-- MAIN APPLICATION
addappid(3298030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298031, 1, "490dfbb24fad3f19b29a22a85a7b5f6d3bf0d39447cb5b87fa1c0f2763292712")
