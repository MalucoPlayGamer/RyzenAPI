-- Lua provided by RyzenAPI
-- Game: Feigning Innocence

-- MAIN APPLICATION
addappid(3298030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3298031, 1, "490dfbb24fad3f19b29a22a85a7b5f6d3bf0d39447cb5b87fa1c0f2763292712")

