-- Lua provided by RyzenAPI
-- Game: 電卓 - Desktop Mate Widgets

-- MAIN APPLICATION
addappid(4791250)
addappid(4835300)
addappid(4835310)
addappid(4835320)
addappid(4835330)
addappid(4835340)
addappid(4835350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(4791251,0,"0275bcc2155d284cc95f813fd09f82b3f245573718107ed2ad96012a2cd1b96b")

