-- Lua provided by SkyAPI 
-- Game: Atomic Heart Demo
addappid(2407990)
addappid(2407991, 1, "8dd7d33327bc6c1cd6a0d57a2d8a3b4daae24a7da9b8ed05d604812a8e8b847e")
