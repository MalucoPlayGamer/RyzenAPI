-- Lua provided by RyzenAPI
-- Game: Warhammer Underworlds - Shadespire Edition (Classic)

-- MAIN APPLICATION
addappid(1022310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022311, 1, "a86e5fa13916762d1764abd2dd82c7f21b8627efc9cc6973a2f1fde8b7ece843")
