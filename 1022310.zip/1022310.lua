-- Lua provided by RyzenAPI
-- Game: Warhammer Underworlds - Shadespire Edition

-- MAIN APPLICATION
addappid(1022310)
addappid(1320850)
addappid(1320851)
addappid(1375190)
addappid(1421580)
addappid(1471160)
addappid(1471161)
addappid(1489230)
addappid(1489231)
addappid(1489232)
addappid(1489233)
addappid(1489240)
addappid(1574120)
addappid(1626390)
addappid(1639840)
addappid(1639841)
addappid(1824460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022311,0,"a86e5fa13916762d1764abd2dd82c7f21b8627efc9cc6973a2f1fde8b7ece843")

