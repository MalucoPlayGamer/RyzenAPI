-- Lua provided by RyzenAPI
-- Game: AppID 3393460

-- MAIN APPLICATION
addappid(3393460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393461, 1, "fedd38f2c8dc7af9cbe2c5ca991d73b0605a7c50509d851e079b64617b44fb77")

