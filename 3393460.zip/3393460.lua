-- Lua provided by SkyAPI 
-- Game: AppID 3393460
addappid(3393460)
addappid(3393461, 1, "fedd38f2c8dc7af9cbe2c5ca991d73b0605a7c50509d851e079b64617b44fb77")
