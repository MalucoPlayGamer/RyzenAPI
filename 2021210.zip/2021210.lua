-- Lua provided by RyzenAPI
-- Game: addappid(2021210)

-- MAIN APPLICATION
addappid(2021210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021211, 1, "dc08aa0d98571131e51482adeff4dc11faebd3135ea874cd8ce350d0628a0731")
