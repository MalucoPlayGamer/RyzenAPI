-- Lua provided by RyzenAPI
-- Game: Practisim Designer

-- MAIN APPLICATION
addappid(1701370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701371, 1, "c534a1112736677ea840f7a94f59bc00bdba3f9c4690436ddbf0133a59e95ad2")
addappid(1701373, 1, "7beab312a641e3c5a41d01f6c452922f8982f1ea19b0905c13bf25aed7f65ca7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
