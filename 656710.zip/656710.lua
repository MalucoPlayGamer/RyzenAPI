-- Lua provided by RyzenAPI
-- Game: AppID 656710

-- MAIN APPLICATION
addappid(656710)

-- MAIN APP DEPOTS / PACKAGES
addappid(656711, 1, "a2a29a6ddf665fcad3d9947ea6e2694ba7a8e2784f54078e6b29a40b5b61cde6")

