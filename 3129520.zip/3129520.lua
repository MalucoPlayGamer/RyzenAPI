-- Lua provided by RyzenAPI
-- Game: REYNATIS - Art Book

-- MAIN APPLICATION
addappid(3129520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3129520,0,"8d55bf573b4a9d8a7ae7eeac014aa5282fa63edb7663939a2e3947b0a7617547")

