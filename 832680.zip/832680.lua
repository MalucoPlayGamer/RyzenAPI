-- Lua provided by RyzenAPI
-- Game: Darts and Friends

-- MAIN APPLICATION
addappid(832680)

-- MAIN APP DEPOTS / PACKAGES
addappid(832681, 1, "902442b52c6d699df16c1e586885454590ca329a6a025df91738bd7135b7ea90")
addappid(832682, 1, "27b3325066a1c4caa243f6aa4b892d4bac985f141f17908dfa4843958bec04a4")
addappid(832683, 1, "3cc8bea84c48ea50d1dd0f644d138fe58a2f0140d892a242766ab486b51b0f4b")
addappid(832684, 1, "659b52abb1effc0d00feaeddc0751480acd04ce68e5d0bd597b53008c1e19cec")

