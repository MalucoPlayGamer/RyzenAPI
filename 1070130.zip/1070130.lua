-- Lua provided by RyzenAPI
-- Game: Crystar - Sen's Peddler Outfit

-- MAIN APPLICATION
addappid(1070130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070130,0,"4888fb796e879203651f8cdb4b88fffa66400fc92ed2ea299682e7adf31c5403")

