-- Lua provided by RyzenAPI
-- Game: addappid(2322540)

-- MAIN APPLICATION
addappid(2322540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322541, 1, "147cb42dc2c9408cf1e308ab26284943baaa93f92bc561852cdfd2ed91b1066f")
