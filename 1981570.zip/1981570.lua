-- Lua provided by RyzenAPI
-- Game: 1981570

-- MAIN APPLICATION
addappid(1981570)
-- Game: addappid(1981570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981571, 1, "a1b41c1b70dfae9a260b2dd2641088e54a61bce753248a76e247ae96f7537f68")
