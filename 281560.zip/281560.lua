-- Lua provided by RyzenAPI
-- Game: D.W.A.R.F.S.

-- MAIN APPLICATION
addappid(281560)

-- MAIN APP DEPOTS / PACKAGES
addappid(281561, 1, "23e2ddbd104cde268b289458a46793b6fa61ff9738689decb9e8aa1e64c1034b")

