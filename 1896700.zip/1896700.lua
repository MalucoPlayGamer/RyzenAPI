-- Lua provided by RyzenAPI
-- Game: Wylde Flowers

-- MAIN APPLICATION
addappid(1896700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896702,0,"fda9b00e4f7f7da366cc0c9e9714ab914885f162888228352b0bfb9e12e126ca")

