-- Lua provided by RyzenAPI
-- Game: Micron

-- MAIN APPLICATION
addappid(290380)

-- MAIN APP DEPOTS / PACKAGES
addappid(290381, 1, "4c979ffe2d157e8ab4690d3d0bcc0c7cd60f8c8dd5d1cfbf87dd4c656cfad747")
addappid(290382, 1, "a5646a61df11a6d3d4e1e0930d42dc5994e41986a6513829c525cbe162f18d62")
addappid(290383, 1, "e126c43f0832ebd94549bc53fed3ecd430edbcd3a08dbfaf54690718fa005741")
addappid(290384, 1, "013dc5701283faf5b2f627c1c3d65cbe4d77d2346111f5d97b3b125059afe5b7")

