-- Lua provided by RyzenAPI
-- Game: Greed: Abandoned Dogs

-- MAIN APPLICATION
addappid(1239940)
addappid(1278400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239941, 1, "f46f3555134785a1a2dff8dfce8e9985b9c0647424e9be8e01768a7ce3cfbf53")
addappid(1239942, 1, "e0dd8155475d4fdd42acc26ac8ba9b7e6c1719c70cfde16bfa1c1097ada92e4e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
