-- Lua provided by RyzenAPI
-- Game: Gods Will Fall

-- MAIN APPLICATION
addappid(1243690)
addappid(1483510)
addappid(1483511)
addappid(1636180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1243691, 1, "d32aeb7b89cafa56d8c3f9e512dd64eb7026842d81ac6d95e5b6fee18d9da778")

