-- Lua provided by RyzenAPI
-- Game: Game: Gods Will Fall

-- MAIN APPLICATION
addappid(1243690)
addappid(1636180)
-- Game: addappid(1243690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243691, 1, "d32aeb7b89cafa56d8c3f9e512dd64eb7026842d81ac6d95e5b6fee18d9da778")
