-- Lua provided by RyzenAPI
-- Game: AppID 1477490

-- MAIN APPLICATION
addappid(1477490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477491, 1, "2bc5ef3ac9abae757db296b33a6a511e6df9e6934cc5b6504bd9f1260348da37")
