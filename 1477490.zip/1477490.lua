-- Lua provided by RyzenAPI
-- Game: AppID 1477490

-- MAIN APPLICATION
addappid(1477490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1477491, 1, "2bc5ef3ac9abae757db296b33a6a511e6df9e6934cc5b6504bd9f1260348da37")

