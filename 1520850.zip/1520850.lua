-- Lua provided by RyzenAPI
-- Game: Game: Mess Adventures 2

-- MAIN APPLICATION
addappid(1520850)
-- Game: addappid(1520850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520851, 1, "4501310ce82a62d05647e3a8b2fca4a421150739acb91306c44400148c83a08a")
addappid(1520852, 1, "337987504c337a5dae5488446d3db7a2a00fa5c788933d49af4f9345cf1b7731")
