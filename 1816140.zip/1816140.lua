-- Lua provided by RyzenAPI
-- Game: Sinners Landing

-- MAIN APPLICATION
addappid(1816140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816141, 1, "047b5ee922164c61ac956957d3b6362d17be98ae7076ae44fd086b3570f37949")

