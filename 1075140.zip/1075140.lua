-- Lua provided by RyzenAPI
-- Game: addappid(1075140)

-- MAIN APPLICATION
addappid(1075140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075141, 1, "06cd3f3c2af0d33efa1814f01efc31de60d855e83ec305f1a9efedba1de0cc62")
