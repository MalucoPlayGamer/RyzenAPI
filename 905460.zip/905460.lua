-- Lua provided by RyzenAPI
-- Game: Game: AppID 905460

-- MAIN APPLICATION
addappid(905460)
-- Game: addappid(905460)

-- MAIN APP DEPOTS / PACKAGES
addappid(905461, 1, "486be426f276f6111bca58717455c14481a7de9e8cafebf15133806e4d8d3f37")
