-- Lua provided by RyzenAPI
-- Game: AppID 905460

-- MAIN APPLICATION
addappid(905460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(905461, 1, "486be426f276f6111bca58717455c14481a7de9e8cafebf15133806e4d8d3f37")

