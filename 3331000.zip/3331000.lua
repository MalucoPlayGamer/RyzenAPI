-- Lua provided by RyzenAPI
-- Game: addappid(3331000)

-- MAIN APPLICATION
addappid(3331000)
addappid(3350730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331001, 1, "a0428c138c350bf0bc84c8c8156bb309fac77ab030cdbadaf1416825c88b5477")
