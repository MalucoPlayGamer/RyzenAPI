-- Lua provided by RyzenAPI
-- Game: Dragon Traveler

-- MAIN APPLICATION
addappid(4104440)
