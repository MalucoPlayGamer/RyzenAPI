-- Lua provided by SkyAPI 
-- Game: AppID 1612110
addappid(1612110)
addappid(1612111, 1, "fc3d40bec14b4ac28c3ee918f9b39b7ada277031f9a486157d8273150a1fde00")
