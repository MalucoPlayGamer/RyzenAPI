-- Lua provided by RyzenAPI
-- Game: AppID 911540

-- MAIN APPLICATION
addappid(911540)

-- MAIN APP DEPOTS / PACKAGES
addappid(911541, 1, "9d432dd05ee0bc66b4572241e760f140b673f0ae173ed3291bc9c3cf9a6f8eec")

