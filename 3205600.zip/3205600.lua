-- Lua provided by SkyAPI 
-- Game: The Libido Enigma
addappid(3205600)
addappid(3205601, 1, "a5eb7ba85184fc53d9ca979fd6930b2b81ff40de929ad8416032e71be25a9d52")
