-- Lua provided by RyzenAPI
-- Game: The Libido Enigma

-- MAIN APPLICATION
addappid(3205600)
-- Game: addappid(3205600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205601, 1, "a5eb7ba85184fc53d9ca979fd6930b2b81ff40de929ad8416032e71be25a9d52")
