-- Lua provided by RyzenAPI
-- Game: Game: BDSM Sex - Episode 1

-- MAIN APPLICATION
addappid(2805700)
-- Game: addappid(2805700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805701, 1, "ef19ae9535e027762b6f668e5920c28092fc64ab64e1d4a9c96988545664d590")
