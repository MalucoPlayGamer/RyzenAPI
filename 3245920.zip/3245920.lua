-- Lua provided by RyzenAPI
-- Game: Game: Falling for Yaoguais

-- MAIN APPLICATION
addappid(3245920)
-- Game: addappid(3245920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245921, 1, "d46e5fc662a3d875571cbe7449e96b20b0bffe0b40201962dc9c505eda071aef")
