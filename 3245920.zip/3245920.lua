-- Lua provided by RyzenAPI
-- Game: Falling for Yaoguais

-- MAIN APPLICATION
addappid(3245920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3245921, 1, "d46e5fc662a3d875571cbe7449e96b20b0bffe0b40201962dc9c505eda071aef")

