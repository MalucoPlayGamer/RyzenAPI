-- Lua provided by RyzenAPI
-- Game: Escape First

-- MAIN APPLICATION
addappid(850450)

-- MAIN APP DEPOTS / PACKAGES
addappid(850451, 1, "2a5d7fa3cd6d3b35cb0f7d6ee20c04478f1be68f93c6da8b81281d049617af3e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
