-- Lua provided by RyzenAPI
-- Game: Grimind

-- MAIN APPLICATION
addappid(265380)

-- MAIN APP DEPOTS / PACKAGES
addappid(265381, 1, "f73222735647e9cb808ce34839e0cf4d68e1f4a3f0caceac7c8bebe56fe6e3ba")
addappid(265382, 1, "40ffbd7bca8688ccf04a0303855893219a3ca222afd49d278150801616ba18cd")
addappid(265383, 1, "a6754b5b83b05c61ba4a53fcd360d0a24c3185ebb86bfe9a82258a21bc6220db")
addappid(265384, 1, "9d575e4b5a43d1afdd926568e2eeb4440252cf6e5b68418e952e9d123dcd6388")

