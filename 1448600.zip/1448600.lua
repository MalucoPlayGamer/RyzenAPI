-- Lua provided by RyzenAPI 
-- Game: AppID 1448600
addappid(1448600)
addappid(1448601, 1, "758d76083952aab2d7821113905f07437de620ec648854929c71bcd24d360b35")
