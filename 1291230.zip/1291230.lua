-- Lua provided by RyzenAPI
-- Game: Heaven vs Hell

-- MAIN APPLICATION
addappid(1291230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291231, 1, "7997339b6f0c7f41c38bddea374da3ae20296ecdb28ba895e49d9a78754e03af")
