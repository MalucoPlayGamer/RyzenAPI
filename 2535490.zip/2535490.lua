-- Lua provided by RyzenAPI
-- Game: Set Off Fireworks Together

-- MAIN APPLICATION
addappid(2535490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2535491, 1, "62051f6aadcc60b68dbe315d73b804d746e48ae3652f8285227050cf5e9d7cde")
