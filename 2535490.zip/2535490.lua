-- Lua provided by RyzenAPI
-- Game: Set Off Fireworks Together

-- MAIN APPLICATION
addappid(2535490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2535491, 1, "62051f6aadcc60b68dbe315d73b804d746e48ae3652f8285227050cf5e9d7cde")

