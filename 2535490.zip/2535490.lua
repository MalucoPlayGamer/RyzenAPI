-- Lua provided by SkyAPI 
-- Game: Set Off Fireworks Together
addappid(2535490)
addappid(2535491, 1, "62051f6aadcc60b68dbe315d73b804d746e48ae3652f8285227050cf5e9d7cde")
