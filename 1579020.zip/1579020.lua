-- Lua provided by RyzenAPI
-- Game: addappid(1579020)

-- MAIN APPLICATION
addappid(1579020)
addappid(2838700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1579021, 1, "beef181fe7434130a979118595643509163fad6529a8dff59a58df6a17835a20")
