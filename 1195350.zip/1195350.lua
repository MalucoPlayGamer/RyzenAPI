-- Lua provided by RyzenAPI
-- Game: Your little story: Winter

-- MAIN APPLICATION
addappid(1195350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195351, 1, "d3197680028e9155ed9cf104d4fa98abf8faa5b7736f756b34fb018257342c09")
