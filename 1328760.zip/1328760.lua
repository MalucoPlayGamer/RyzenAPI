-- Lua provided by RyzenAPI
-- Game: Game: 妙语连珠

-- MAIN APPLICATION
addappid(1328760)
-- Game: addappid(1328760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328761, 1, "431320adcf6ba7747b438d4d9ca4b5215ab5e7a7a388b97e8a1d86a44a3bd2fa")
