-- Lua provided by RyzenAPI
-- Game: 2238310

-- MAIN APPLICATION
addappid(2238310)
-- Game: addappid(2238310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2238311, 1, "d3761d7e192cd76747b0fcaed434d3415d375f1aeecad27dfa20de1b3f29a528")
