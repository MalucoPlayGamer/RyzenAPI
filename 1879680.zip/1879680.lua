-- Lua provided by RyzenAPI
-- Game: Candle Knight

-- MAIN APPLICATION
addappid(1879680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879681, 1, "9cb6a9082de4bdfdfe9e6872827ef9e5bccf28fee8038a03f841b7bc0f9f5fcd")

