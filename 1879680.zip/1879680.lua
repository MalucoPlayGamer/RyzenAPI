-- Lua provided by RyzenAPI
-- Game: Candle Knight

-- MAIN APPLICATION
addappid(1879680)
addappid(2435580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1879681, 1, "9cb6a9082de4bdfdfe9e6872827ef9e5bccf28fee8038a03f841b7bc0f9f5fcd")

