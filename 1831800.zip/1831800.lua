-- Lua provided by RyzenAPI
-- Game: Game: Grief like a stray dog

-- MAIN APPLICATION
addappid(1831800)
-- Game: addappid(1831800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831801, 1, "f4280390f09cc62158a1a9728f3c2f20992bc80ad2d7ff4043ceb5238bf79eda")
