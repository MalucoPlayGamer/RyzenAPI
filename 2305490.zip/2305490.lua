-- Lua provided by RyzenAPI 
-- Game: THE SEGMENT TWINS
addappid(2305490)
addappid(2305491, 1, "ed6fe7d6a28a2fcada3b248b4d777efc96c45a2a7e93a7100706af7454fe7614")
