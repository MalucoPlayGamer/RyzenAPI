-- Lua provided by RyzenAPI
-- Game: The Fastest Fist

-- MAIN APPLICATION
addappid(544540)
-- Game: addappid(544540)

-- MAIN APP DEPOTS / PACKAGES
addappid(544541, 1, "6d825e1b9418300521e791096b8a7aa5603dbd3b772ed48cf29a7a5dc398d574")
