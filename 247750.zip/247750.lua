-- Lua provided by RyzenAPI
-- Game: The Stanley Parable Demo

-- MAIN APPLICATION
addappid(247750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(247751, 1, "2afe69428f2a76ac3e1d6d4aa75dd330bce73e48971d92669b209ab2416149ae")
addappid(247752, 1, "51d5bd68c06208d0e21767878046c6f65de96aae7ecd156556fb424493620ad7")
addappid(247753, 1, "9052c92c8d77927ee570651f01a08b78ac49064cbf805c6e5d323379f6d92b07")
addappid(247754, 1, "0773e9d24874eb048dc457ec70eeebd3b33a15d872446eecc2f662aaa85f7cfb")

