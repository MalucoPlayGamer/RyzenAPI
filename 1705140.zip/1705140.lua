-- Lua provided by RyzenAPI
-- Game: Final Profit: A Shop RPG

-- MAIN APPLICATION
addappid(1705140)
-- Game: addappid(1705140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705141, 1, "afb305db330270d907c74460a27360f0d865966bf18adfb6223be735106b7832")
