-- Lua provided by RyzenAPI
-- Game: 34640

-- MAIN APPLICATION
addappid(34640)
-- Game: addappid(34640)

-- MAIN APP DEPOTS / PACKAGES
addappid(34641, 1, "0641e757af0e18531685b151f4f63a4520c06f76642ffacaf353def0f4ea86fd")
