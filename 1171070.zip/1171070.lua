-- Lua provided by RyzenAPI
-- Game: Medieval - Embers of War

-- MAIN APPLICATION
addappid(1171070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1171071, 1, "3124b2d3171417e91affc159f7849567fcc97c03adb6fee473b1201e1b9b3822")

