-- Lua provided by RyzenAPI
-- Game: Medieval - Embers of War

-- MAIN APPLICATION
addappid(1171070)
-- Game: addappid(1171070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171071, 1, "3124b2d3171417e91affc159f7849567fcc97c03adb6fee473b1201e1b9b3822")
