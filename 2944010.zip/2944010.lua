-- Lua provided by RyzenAPI
-- Game: Roll 'n' Watch

-- MAIN APPLICATION
addappid(2944010)
-- Game: addappid(2944010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2944011, 1, "bbd82911ade627353581be06becb69a631ef6c0b2eb7b72f96ad391f87ac97f4")
