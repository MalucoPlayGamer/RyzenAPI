-- Lua provided by RyzenAPI
-- Game: Roll 'n' Watch

-- MAIN APPLICATION
addappid(2944010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2944011, 1, "bbd82911ade627353581be06becb69a631ef6c0b2eb7b72f96ad391f87ac97f4")

