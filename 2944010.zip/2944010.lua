-- Lua provided by SkyAPI 
-- Game: Roll 'n' Watch
addappid(2944010)
addappid(2944011, 1, "bbd82911ade627353581be06becb69a631ef6c0b2eb7b72f96ad391f87ac97f4")
