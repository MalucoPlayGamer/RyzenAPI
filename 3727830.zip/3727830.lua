-- Lua provided by RyzenAPI
-- Game: Forest Asylum 2

-- MAIN APPLICATION
addappid(3727830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3727831, 1, "284ba3e50593a66e2141be266bb57ea81cd68e9af328faa5941e722ec411f077")

