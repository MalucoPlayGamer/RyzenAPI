-- Lua provided by RyzenAPI
-- Game: Forest Asylum 2

-- MAIN APPLICATION
addappid(3727830)
-- Game: addappid(3727830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3727831, 1, "284ba3e50593a66e2141be266bb57ea81cd68e9af328faa5941e722ec411f077")
