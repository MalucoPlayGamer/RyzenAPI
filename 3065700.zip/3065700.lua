-- Lua provided by RyzenAPI
-- Game: addappid(3065700)

-- MAIN APPLICATION
addappid(3065700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3065701, 1, "3a9bd20def449107b07c54110c7e319e942a4d841d9aa0e0124c99fb686e41bf")
