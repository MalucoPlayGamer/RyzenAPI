-- Lua provided by RyzenAPI
-- Game: 驱煞

-- MAIN APPLICATION
addappid(2847110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2847111, 1, "f0ccbb576517a41441373a0e36da77e705d187122f140e89214d801b6e148fbc")

