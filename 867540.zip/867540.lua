-- Lua provided by RyzenAPI
-- Game: Honor Cry: Aftermath

-- MAIN APPLICATION
addappid(867540)

-- MAIN APP DEPOTS / PACKAGES
addappid(867541,0,"af2d8b7d64c4fa7248201343113eb7ae2baa52b63ce567eb2fdcda6ab70be4f8")

