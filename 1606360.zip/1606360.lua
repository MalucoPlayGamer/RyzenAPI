-- Lua provided by RyzenAPI
-- Game: Rocket Stop Demo

-- MAIN APPLICATION
addappid(1606360)
-- Game: addappid(1606360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606361, 1, "0e38694a527fe0774f863f4400312d1080fbd57437801ac03661263105016108")
