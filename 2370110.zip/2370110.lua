-- Lua provided by RyzenAPI
-- Game: addappid(2370110)

-- MAIN APPLICATION
addappid(2370110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370111, 1, "c5d0ac6f5070a2bf2a4a030d798a0a9f70b825705a5f77767275ef03cfa39790")
