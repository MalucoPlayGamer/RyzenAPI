-- Lua provided by RyzenAPI
-- Game: Game: 定時制の人妻JK - Married Girls' Night School -

-- MAIN APPLICATION
addappid(2370110)
-- Game: addappid(2370110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2370111, 1, "c5d0ac6f5070a2bf2a4a030d798a0a9f70b825705a5f77767275ef03cfa39790")
