-- Lua provided by RyzenAPI 
-- Game: AppID 1612350
addappid(1612350)
addappid(1612351, 1, "ddddd78202e56b2ae1e201febcffe20c74cf7f2b7cbece377fd94be62e1886ab")
