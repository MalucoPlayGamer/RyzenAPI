-- Lua provided by RyzenAPI
-- Game: AppID 1612350

-- MAIN APPLICATION
addappid(1612350)
-- Game: addappid(1612350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612351, 1, "ddddd78202e56b2ae1e201febcffe20c74cf7f2b7cbece377fd94be62e1886ab")
