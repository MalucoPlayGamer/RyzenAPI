-- Lua provided by RyzenAPI
-- Game: addappid(379320)

-- MAIN APPLICATION
addappid(379320)

-- MAIN APP DEPOTS / PACKAGES
addappid(379321, 1, "869e1ccd6ec3024df1b2bf8215a9905925d8e7a18c60d6c9791a26da6beaab40")
