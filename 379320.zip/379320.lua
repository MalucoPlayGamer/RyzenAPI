-- Lua provided by RyzenAPI
-- Game: Clandestinity of Elsie

-- MAIN APPLICATION
addappid(379320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(379321, 1, "869e1ccd6ec3024df1b2bf8215a9905925d8e7a18c60d6c9791a26da6beaab40")

