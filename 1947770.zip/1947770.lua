-- Lua provided by RyzenAPI
-- Game: 水银疗养院 Demo

-- MAIN APPLICATION
addappid(1947770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947771, 1, "b2572cd5d9e44b0b807ad0be861c72e54920e65d137427d4fd534f1ec08a545e")
