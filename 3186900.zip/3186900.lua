-- Lua provided by RyzenAPI
-- Game: Fantasy Quest Demo

-- MAIN APPLICATION
addappid(3186900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3186901, 1, "47b51547f72de500796bbc9438cf0f6ccec6d53916addb690e71f4a0d7976453")

