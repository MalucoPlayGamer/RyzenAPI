-- Lua provided by RyzenAPI
-- Game: Lords of New York

-- MAIN APPLICATION
addappid(404070)

-- MAIN APP DEPOTS / PACKAGES
addappid(404072,0,"4e4f29adb1f2984d8b18677fb7fc755e5b56dbcc478172aae5f7c5d91a5d4754")
addappid(404073,0,"5d114e9210b903124844eae7daec46737011d8e231de1c3daa96540570dda4b2")

