-- Lua provided by RyzenAPI
-- Game: addappid(943700)

-- MAIN APPLICATION
addappid(943700)

-- MAIN APP DEPOTS / PACKAGES
addappid(943701, 1, "13ebbbc1d2338aad4dcbe60be2c56b0f4ab1c3e8c97fc8172469cd92c092ea08")
