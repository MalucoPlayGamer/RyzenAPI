-- Lua provided by RyzenAPI
-- Game: CSC | Space MMO

-- MAIN APPLICATION
addappid(895040)
addappid(895041)
addappid(895043)
addappid(895044)

-- MAIN APP DEPOTS / PACKAGES
addappid(895042,0,"ee567ab1104229d8ca6bb036c9506711d91f1a689aaa55fe090f9b6dfccbb480")
