-- Lua provided by RyzenAPI
-- Game: Game: The Visitor

-- MAIN APPLICATION
addappid(457580)
-- Game: addappid(457580)

-- MAIN APP DEPOTS / PACKAGES
addappid(457581, 1, "d5069c0ce253d4aa28411421b58b5651500a6cfa339676e810253bd0655520e1")
