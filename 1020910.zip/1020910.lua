-- Lua provided by RyzenAPI
-- Game: 1020910

-- MAIN APPLICATION
addappid(1020910)
-- Game: addappid(1020910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020911, 1, "ce65fb12f7b8496781f1750626b435c4e7fed7043d5b5f953ea2e3dafba67201")
