-- Lua provided by SkyAPI 
-- Game: DarkFighter
addappid(1680050)
addappid(1680051, 1, "14d6dc8c98248eb5896ff1ebc43fbd27c763a09bf6e697cf4111e5c8dbd0fff5")
