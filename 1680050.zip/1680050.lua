-- Lua provided by RyzenAPI
-- Game: 1680050

-- MAIN APPLICATION
addappid(1680050)
-- Game: addappid(1680050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680051, 1, "14d6dc8c98248eb5896ff1ebc43fbd27c763a09bf6e697cf4111e5c8dbd0fff5")
