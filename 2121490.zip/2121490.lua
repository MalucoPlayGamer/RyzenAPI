-- Lua provided by RyzenAPI
-- Game: addappid(2121490)

-- MAIN APPLICATION
addappid(2121490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2121491, 1, "5d68743c4cda7e306a78fa31d5d77b8aac3fd6b85ece67038ca6123bf4a847fc")
