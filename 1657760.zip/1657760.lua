-- Lua provided by SkyAPI 
-- Game: Cactus Cowboy 3 - Fully Loaded
addappid(1657760)
addappid(1657761, 1, "1933f4b3e9f3b4897db5962f2652b9b325ea797dd997497489fa4cba4cfb4824")
