-- Lua provided by RyzenAPI
-- Game: HuniePop Original Soundtrack

-- MAIN APPLICATION
addappid(348560)

-- MAIN APP DEPOTS / PACKAGES
addappid(348563,0,"a697c7c89900efcaa1373cf49e45053adb60439889fb463142042eb369c19e6d")
addappid(348564,0,"cb3db6da0b72ba30606d6341d79639b0db0262a07979c5dc17ccfaeaefa254fa")

