-- Lua provided by RyzenAPI
-- Game: The Stillness of the Wind Original Soundtrack

-- MAIN APPLICATION
addappid(932550)
addappid(932551)

-- MAIN APP DEPOTS / PACKAGES
addappid(828903,0,"4b612c117185fb413386e52b08093de43108a3f6508e0c6500c3517e9e09069f")
