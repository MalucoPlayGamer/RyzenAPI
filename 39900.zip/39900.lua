-- Lua provided by RyzenAPI
-- Game: AppID 39900

-- MAIN APPLICATION
addappid(39900)

-- MAIN APP DEPOTS / PACKAGES
addappid(39901, 1, "47e416445dcbdb45eee7e1d7fcb568407fc44d9eaa826614a9f8495e71532be9")
