-- Lua provided by RyzenAPI
-- Game: Novastella Island

-- MAIN APPLICATION
addappid(2096310)
addappid(2242691)
addappid(2242692)
addappid(2242693)
-- Game: addappid(2096310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096311, 1, "270d0480ee7cd2ce0afd58f591f1ca7fce8412f056717ac4de24e0094f703639")
addappid(2242690, 0, "ddbaf7b846d4a9237bdcc169c1b2169cbc8f3728a715060a6c07295cf3a10f71")
