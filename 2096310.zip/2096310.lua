-- Lua provided by RyzenAPI
-- Game: Novastella Island

-- MAIN APPLICATION
addappid(2096310)
addappid(2242691)
addappid(2242692)
addappid(2242693)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096311, 1, "270d0480ee7cd2ce0afd58f591f1ca7fce8412f056717ac4de24e0094f703639")
addappid(2242690, 0, "ddbaf7b846d4a9237bdcc169c1b2169cbc8f3728a715060a6c07295cf3a10f71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
