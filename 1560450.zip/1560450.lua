-- Lua provided by RyzenAPI
-- Game: the Sequence [2]

-- MAIN APPLICATION
addappid(1560450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560451, 1, "9a10e4877f67e36eef7a6f6305041ea1a96bb23bf38e4dc01485458afba2eab9")
