-- Lua provided by RyzenAPI 
-- Game: AppID 1289340
addappid(1289340)
addappid(1289341, 1, "307125891892321bd7c96c8bb1e5f532c4bdfa4556913af7080d22ddcfd8a1c2")
