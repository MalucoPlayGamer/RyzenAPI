-- Lua provided by RyzenAPI
-- Game: Game: AppID 290990

-- MAIN APPLICATION
addappid(290990)
-- Game: addappid(290990)

-- MAIN APP DEPOTS / PACKAGES
addappid(290991, 1, "c34eacfb7771edb39d15b840366275b3edcea6a04051a64929fc27470d8f3f48")
