-- Lua provided by RyzenAPI
-- Game: Retro Gadgets

-- MAIN APPLICATION
addappid(1730260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730262,0,"ef7a8308e6c5e2c1b2b1a587394e612c6bccccde0f6483f1a169c3e8cdcec62c")

