-- Lua provided by RyzenAPI
-- Game: Game: 皎月坠落之时

-- MAIN APPLICATION
addappid(2786100)
-- Game: addappid(2786100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786101, 1, "284b709886cd4a3f8d8646435be91998f3056fb695c507ca33a9d12d65513469")
