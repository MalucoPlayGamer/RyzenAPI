-- Lua provided by RyzenAPI
-- Game: 324730

-- MAIN APPLICATION
addappid(324730)
-- Game: addappid(324730)

-- MAIN APP DEPOTS / PACKAGES
addappid(324733,0,"f61bb7ba75b366496d72044e7ba7c0e9c107ae214acaa6cd3347261203ea3e61")
