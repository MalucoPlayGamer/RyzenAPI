-- Lua provided by RyzenAPI
-- Game: Caverns of the Snow Witch (Standalone)

-- MAIN APPLICATION
addappid(324730)

-- MAIN APP DEPOTS / PACKAGES
addappid(324733,0,"f61bb7ba75b366496d72044e7ba7c0e9c107ae214acaa6cd3347261203ea3e61")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
