-- Lua provided by SkyAPI 
-- Game: The Dungeon of Lulu Farea
addappid(998220)
addappid(998221, 1, "cfd5337baaa3038e5d141e8007f1e78af30f02fcd39f098894e880e42ffe95df")
addappid(998222, 1, "106b408e0ae2f18d19268216d1bed6b058607588be009a2a5cd572b395476898")
addappid(998223, 1, "d60f448ce5fc7ee74218a924b10e81685d51d16f2862be8eb61d179543121059")
