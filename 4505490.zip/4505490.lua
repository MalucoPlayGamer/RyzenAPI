-- 4505490's Lua and Manifest Created by Hubcap Manifest
-- Mechanical Defense Line
-- Created: June 26, 2026 at 02:10:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4505490) -- Mechanical Defense Line
-- MAIN APP DEPOTS
addappid(4505491, 1, "839992a3890b0eba869ad532edbc9e32d480d434cbced5c9eb5e4d39f6abe8db") -- Depot 4505491
setManifestid(4505491, "427790711111884817", 640783567)