-- Lua provided by SkyAPI 
-- Game: AppID 2070020
addappid(2070020)
addappid(2070021, 1, "249a60112b2cda149027a25ba2753db769ecc5e15e6579057e83e7ca30d7d669")
