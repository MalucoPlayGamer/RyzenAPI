-- Lua provided by RyzenAPI
-- Game: Stars In The Trash Demo

-- MAIN APPLICATION
addappid(2070020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070021, 1, "249a60112b2cda149027a25ba2753db769ecc5e15e6579057e83e7ca30d7d669")

