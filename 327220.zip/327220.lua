-- Lua provided by RyzenAPI
-- Game: Anna's Quest

-- MAIN APPLICATION
addappid(327220)

-- MAIN APP DEPOTS / PACKAGES
addappid(327221, 1, "a88869995a33ad72cbc470187e9e80b0963ad4f21bd73c7b5b717637b8f7e4d9")
addappid(327222, 1, "7d3ab8e3417989e45e17c0dbf8916b8f0f89478dc94e1a6877401b55e824a077")
addappid(327223, 1, "783fe0f16199141257a185d8d796baecdd2fac295cd879a93c7f7191095bfcba")
addappid(327224, 1, "60ab42c440a2a8f6d476b35ee31f8be2cde038fd3e6e1737dc928518560ae371")
addappid(327225, 1, "d662fcadc45f58672aa7e5e5f79f12689bd7e91a3c56c0fa4cfc9179e23eaeb1")
addappid(327226, 1, "94cb5b6e1910a80155d0c9a5a27b1e9745cc588d89cc46a6a7cbe7267ef91143")
addappid(327227, 1, "5abd5b0b0fa58edf029535d72e5f5777c88c22399140b36385e8ed3260eb000d")
addappid(327228, 1, "2d1fe64c04bed87a751630bfdf663cfe80cdafd012844767cb919098ad556a94")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
