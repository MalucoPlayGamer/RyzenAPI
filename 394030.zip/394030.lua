-- Lua provided by RyzenAPI
-- Game: Game: AppID 394030

-- MAIN APPLICATION
addappid(394030)
-- Game: addappid(394030)

-- MAIN APP DEPOTS / PACKAGES
addappid(394031, 1, "b943c0a2d2070db558a76ccb689453fe6f98b8d07c6537473ac8b163c4bc03c2")
