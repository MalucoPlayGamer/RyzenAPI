-- Lua provided by RyzenAPI
-- Game: Trigonarium

-- MAIN APPLICATION
addappid(394030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(394031, 1, "b943c0a2d2070db558a76ccb689453fe6f98b8d07c6537473ac8b163c4bc03c2")

