-- Lua provided by RyzenAPI 
-- Game: Escape The Outbreak
addappid(1731700)
addappid(1731701, 1, "ab88ae7d4a32160ad3bff9c549c587ab2ddb1d652ee996a98e3918f69d8e48aa")
