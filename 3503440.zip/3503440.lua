-- Lua provided by RyzenAPI
-- Game: Astro Prospector

-- MAIN APPLICATION
addappid(3503440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3503441, 1, "3fcd0cd6fb634ba269eb29f2ad970f6753548331145c13247d5626f9a03b4749")

