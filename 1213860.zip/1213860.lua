-- Lua provided by RyzenAPI
-- Game: Cut Smash Wrap

-- MAIN APPLICATION
addappid(1213860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213861, 1, "f94589a6c284aec7eb48c5d1d1072f80b805f4e39a31d41f41cc228b55970871")

