-- Lua provided by RyzenAPI
-- Game: 恋色ぱれっと - Love Palette -

-- MAIN APPLICATION
addappid(2957980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957981, 1, "bd7c39285e0c730ee17eb8135876fd17a8243843e909b3e6f44c38458d9104b5")
