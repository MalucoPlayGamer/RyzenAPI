-- Lua provided by RyzenAPI
-- Game: addappid(1432151)

-- MAIN APPLICATION
addappid(1432151)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432151,0,"feb750d5a0c0afecd071732ee5e148a1cda0dbedb6baddd9b1b92cdb040a3832")
