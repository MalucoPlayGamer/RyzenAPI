-- Lua provided by RyzenAPI
-- Game: Battle Axe

-- MAIN APPLICATION
addappid(1167300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167304,0,"37c89380dd1545a9fc2f141a1223263387b1adf1165daeb30861c63b6278ce98")

