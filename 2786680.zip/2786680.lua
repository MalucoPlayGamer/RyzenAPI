-- Lua provided by RyzenAPI
-- Game: Knowledge, or know Lady

-- MAIN APPLICATION
addappid(2786680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786681, 1, "ba93faedc0bc173e603c50c2a54859361aef98782e177bcbaf501dbfc4671f79")
