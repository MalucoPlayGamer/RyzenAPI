-- Lua provided by RyzenAPI
-- Game: Hentai Rina

-- MAIN APPLICATION
addappid(2640980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2640981, 1, "1496bc5d3da3e2aa61b17a4b4ad10661b350db0252a6b3425d07bee105b5b5dc")

