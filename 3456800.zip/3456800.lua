-- Lua provided by RyzenAPI
-- Game: Rock Crusher

-- MAIN APPLICATION
addappid(3456800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456801,0,"cc9110da216affede1cdc2be9aab3f4f93cf378ff6585fd46dc617b84e1b13ce")

