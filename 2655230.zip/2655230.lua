-- Lua provided by RyzenAPI
-- Game: Shadow Of Sound

-- MAIN APPLICATION
addappid(2655230)
-- Game: addappid(2655230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655231, 1, "6ebe90b50d6e7ddd207c7a2c22ffd7027528b9982fa4e276b0c5d825099815fb")
