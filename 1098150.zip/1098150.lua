-- Lua provided by RyzenAPI
-- Game: Trickster VR: Horde Attack!

-- MAIN APPLICATION
addappid(1098150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098151, 1, "cf68a7565f8cd88328a77394cd23e852afe74b266cc96f0bda929e1a02d2138e")

