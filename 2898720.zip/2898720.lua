-- Lua provided by RyzenAPI
-- Game: Music Man 3: Last Dance

-- MAIN APPLICATION
addappid(2898720)
-- Game: addappid(2898720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2898721, 1, "1dc4a47f46d4b37d8c1e1229fbef468322f4675fd9994ef6a6f98d239d58b6d8")
