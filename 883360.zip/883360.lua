-- Lua provided by RyzenAPI
-- Game: Beyond Blue

-- MAIN APPLICATION
addappid(883360)

-- MAIN APP DEPOTS / PACKAGES
addappid(883361, 1, "69f9d7de4cd6109654715320bfd4acf7a9ced00c23314b8a23d6649430ffc2db")
