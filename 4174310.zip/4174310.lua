-- Lua provided by RyzenAPI
-- Game: Retail Hell

-- MAIN APPLICATION
addappid(4174310)

-- MAIN APP DEPOTS / PACKAGES
addappid(4174312,0,"c5aa51e3ce8c40f87f4f809ba7bde95b71ed545384a55c6072e8bbd5f6619dbe")

