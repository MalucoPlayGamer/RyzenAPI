-- Lua provided by RyzenAPI
-- Game: H Chan: Girl

-- MAIN APPLICATION
addappid(1081090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081091, 1, "dc8f9ca6142dfc56aaadb3ef82c58abf7462d82688dfa852f3995c152ccc7cbd")

