-- Lua provided by RyzenAPI
-- Game: Battle Summoners VR Basic

-- MAIN APPLICATION
addappid(868090)

-- MAIN APP DEPOTS / PACKAGES
addappid(868091, 1, "16dda915a97c2d1a5bddcee08dd5ae8f54e03d82cf7db0730a2a4b50b34892a3")
