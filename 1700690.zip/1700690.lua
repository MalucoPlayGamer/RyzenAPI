-- Lua provided by RyzenAPI
-- Game: Game: Grandma's Footsteps

-- MAIN APPLICATION
addappid(1700690)
-- Game: addappid(1700690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700691, 1, "9484753e50a4b3accde3656b28889d76e1312ccee59a9b1312f01faf7c7aea37")
