-- Lua provided by RyzenAPI 
-- Game: Grandma's Footsteps
addappid(1700690)
addappid(1700691, 1, "9484753e50a4b3accde3656b28889d76e1312ccee59a9b1312f01faf7c7aea37")
