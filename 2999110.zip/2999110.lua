-- Lua provided by RyzenAPI
-- Game: Game: AppID 2999110

-- MAIN APPLICATION
addappid(2999110)
-- Game: addappid(2999110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999111, 1, "c06659298179d462835d41702a57714a76beb599def4efbfdc17a3cc56703164")
