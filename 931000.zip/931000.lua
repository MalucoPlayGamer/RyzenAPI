-- Lua provided by RyzenAPI
-- Game: URUZ "Return of The Er Kishi"

-- MAIN APPLICATION
addappid(931000)

-- MAIN APP DEPOTS / PACKAGES
addappid(931001, 1, "6354c852586a99165b8ca08e2420c5a588486dd4e5335e4d5f749cc790771878")

