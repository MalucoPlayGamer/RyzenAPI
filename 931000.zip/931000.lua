-- Lua provided by RyzenAPI
-- Game: URUZ "Return of The Er Kishi"

-- MAIN APPLICATION
addappid(931000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(931001, 1, "6354c852586a99165b8ca08e2420c5a588486dd4e5335e4d5f749cc790771878")

