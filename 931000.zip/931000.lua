-- Lua provided by SkyAPI 
-- Game: URUZ "Return of The Er Kishi"
addappid(931000)
addappid(931001, 1, "6354c852586a99165b8ca08e2420c5a588486dd4e5335e4d5f749cc790771878")
