-- Lua provided by RyzenAPI
-- Game: Eternal Senia

-- MAIN APPLICATION
addappid(351640)

