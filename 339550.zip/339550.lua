-- Lua provided by RyzenAPI
-- Game: 339550

-- MAIN APPLICATION
addappid(339550)
-- Game: addappid(339550)

-- MAIN APP DEPOTS / PACKAGES
addappid(339550,0,"159a37177dbbf58d285137f21ecb8b0284ea175b82fd25d0d3c3989dfb022135")
