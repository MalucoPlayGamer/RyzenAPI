-- Lua provided by RyzenAPI
-- Game: Sigmund Minisode 2 [Free 2014/15 Holiday Special]

-- MAIN APPLICATION
addappid(339550)

-- MAIN APP DEPOTS / PACKAGES
addappid(339550,0,"159a37177dbbf58d285137f21ecb8b0284ea175b82fd25d0d3c3989dfb022135")
