-- Lua provided by RyzenAPI
-- Game: Game: Space Conquest

-- MAIN APPLICATION
addappid(602550)
-- Game: addappid(602550)

-- MAIN APP DEPOTS / PACKAGES
addappid(602551, 1, "bc25b22af6fa02b0d2c9a6a280dd1968fb8a2b37f48b3fb16fcf3d07e96d0cc1")
