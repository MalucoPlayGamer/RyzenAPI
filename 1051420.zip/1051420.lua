-- Lua provided by SkyAPI 
-- Game: AppID 1051420
addappid(1051420)
addappid(1051421, 1, "08fe3ce0dfe687f52446b249d33c69d71f984d411bac0d798c21185d7b4831f9")
