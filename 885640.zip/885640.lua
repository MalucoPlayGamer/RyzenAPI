-- Lua provided by SkyAPI 
-- Game: AppID 885640
addappid(885640)
addappid(885641, 1, "3ad3c4d8df150b39f2473a957162c0d6e50b99bb50c68ff51ee17475742f3a36")
