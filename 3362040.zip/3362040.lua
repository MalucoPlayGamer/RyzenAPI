-- Lua provided by RyzenAPI
-- Game: Cell Command

-- MAIN APPLICATION
addappid(3362040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362041,0,"e36ce3c1fecf0ff907e0950276d1c044de570ddc4701efeab5499b6590b3ca6e")

