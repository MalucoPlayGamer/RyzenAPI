-- Lua provided by RyzenAPI
-- Game: Game: AppID 46560

-- MAIN APPLICATION
addappid(46560)
-- Game: addappid(46560)

-- MAIN APP DEPOTS / PACKAGES
addappid(46561, 1, "5370659ad59e17f0d699ecb5d59fd12e7b64f66edada336fb759c09c1d215b70")
addappid(46562, 1, "f17c1b12a670bf3a20b15c7630ddbc93ab373a3228d8c828e5e74d164665cabf")
addappid(46563, 1, "b0fdbeb1de091b5e6197ac8b9c9fd85ef6fbfbd1643d66cc5a8370357e9711b6")
addappid(46564, 1, "4290d5ae942207719a8ca0311f118308e7271e2ddb461c2a6a452bf7acf35acf")
addappid(46565, 1, "8eaa5743e4d4604dcd045bc275dbf931b29e03a5f2097e0745a4f6a72b2c3651")
addappid(46566, 1, "0352d330f1e500045f9831793ab8ee3b32370da4fc4278f1da8fd9fea91cf304")
