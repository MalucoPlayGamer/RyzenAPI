-- Lua provided by RyzenAPI
-- Game: Never Alone (Kisima Ingitchuna)

-- MAIN APPLICATION
addappid(295790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(295791, 1, "3716689fac3abf95a3b13b9ca78e16bdb3c2be6d2313e74a11003ce1457b5c07")
addappid(295792, 1, "619eb095077e0e2a126d2aab45991d9326bcf35930d751d50bbdfe2fd7b91cb1")
addappid(295793, 1, "78e832b1bf4bff0c471ed17f737086c961987abd63a0927e406bf635d7842180")
addappid(295794, 1, "b6a283065524bee6e63d4e745f6d6598e324aedc76db8b037a7bad1a944142dd")
addappid(295795, 1, "6b0c3662405cb4ceeccd1fdce5e2b2073ab9935b632e1bb3d113d19c77282237")
addappid(351740, 0, "3144dd495ef0758b0c9f0c33027209bcd3654f3b765c17dc1c486bbe3f158ce3")
addappid(355740, 0, "e42bcc7f20e0f89af4b61a246d0dbfc8eed45f9e7fee92936132dfdb1907cb92")

