-- Lua provided by RyzenAPI
-- Game: Game: Final DOOM

-- MAIN APPLICATION
addappid(2290)
-- Game: addappid(2290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291, 1, "f3de63ac089a3ae253eaf1259df22482ad869fb8a3e88fbb32b782c26de5f4e8")
