-- Lua provided by RyzenAPI
-- Game: AppID 582480

-- MAIN APPLICATION
addappid(582480)
-- Game: addappid(582480)

-- MAIN APP DEPOTS / PACKAGES
addappid(582481, 1, "caf28fefe705c3e2161030efceee7fe592fd8ced56e552328f39995a31349640")
