-- Lua provided by RyzenAPI
-- Game: addappid(1493840)

-- MAIN APPLICATION
addappid(1493840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493841, 1, "d044136d78395d80ef5c981e3dc8a23c4aed9f430bfe73c5d7780bbeda5ef32d")
