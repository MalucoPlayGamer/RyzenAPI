-- Lua provided by RyzenAPI
-- Game: 一代掌门

-- MAIN APPLICATION
addappid(1978000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978001, 1, "d2e4ca079793e3f5f25b60855c48adc277477efa5ee352183a15678f3d2917b4")
