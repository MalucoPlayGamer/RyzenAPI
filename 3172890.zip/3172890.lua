-- Lua provided by RyzenAPI
-- Game: AppID 3172890

-- MAIN APPLICATION
addappid(3172890)
-- Game: addappid(3172890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172891, 1, "cc7fe5ea8be0769812de6398aa3d530f616718b5db4e19d5dd5e2558555e954f")
