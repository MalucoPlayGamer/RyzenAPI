-- Lua provided by RyzenAPI
-- Game: Game: lightblue

-- MAIN APPLICATION
addappid(1547970)
-- Game: addappid(1547970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547971, 1, "da66858677016c4a14584c6a627c28111a1ecc9dc6369803bd4f617844b2d14a")
