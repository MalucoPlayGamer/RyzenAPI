-- Lua provided by RyzenAPI
-- Game: Who's Your Daddy?!

-- MAIN APPLICATION
addappid(427730)

-- MAIN APP DEPOTS / PACKAGES
addappid(427733,0,"ce037d67505cf1b78f6a9749969edf581ed024c2eeccf9fb65605aed36b67521")
addappid(427734,0,"9f32b86318ec5c73a054d96fb153659fccfa6a3a17897259970a5e450fa8226f")
