-- Lua provided by RyzenAPI
-- Game: 2277870

-- MAIN APPLICATION
addappid(2277870)
-- Game: addappid(2277870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277871, 1, "b9e1daa05727f7cd1c2460c666ca5322ed4e4aac1497c53e3d6fd750cb9ab0b5")
