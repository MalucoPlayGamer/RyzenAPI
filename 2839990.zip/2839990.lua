-- Lua provided by RyzenAPI
-- Game: Burger girl clicker

-- MAIN APPLICATION
addappid(2839990)
-- Game: addappid(2839990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839991, 1, "369256bf41cb811d0ce184fd0b35264a9fb62b264b941861bb52f0122eba8b5a")
