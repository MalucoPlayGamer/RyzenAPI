-- Lua provided by RyzenAPI 
-- Game: Burger girl clicker
addappid(2839990)
addappid(2839991, 1, "369256bf41cb811d0ce184fd0b35264a9fb62b264b941861bb52f0122eba8b5a")
