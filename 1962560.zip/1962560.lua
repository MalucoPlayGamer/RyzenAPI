-- Lua provided by SkyAPI 
-- Game: Grim Horde
addappid(1962560)
addappid(1962561, 1, "d5919d51211b74d6c6982e3dc24f8ceda5a43479ba1cebd38a2df38c200c37ea")
