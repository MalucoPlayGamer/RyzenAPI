-- Lua provided by RyzenAPI
-- Game: Gust of Wind

-- MAIN APPLICATION
addappid(1715390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715391, 1, "9847e050f40f0c1f75fe2a706058b018f8afc40780cc0e10299562929f12cc4a")

