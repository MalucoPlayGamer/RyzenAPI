-- Lua provided by RyzenAPI
-- Game: The Undying Plague

-- MAIN APPLICATION
addappid(349440)

-- MAIN APP DEPOTS / PACKAGES
addappid(349441, 1, "8d9463e6eb2148ea7bb1c748da185a8628ac0fd6e1866d50ac1f2e5e2d8d48a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
