-- Lua provided by RyzenAPI
-- Game: addappid(2525230)

-- MAIN APPLICATION
addappid(2525230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525231, 1, "4899aefe8c0b3c65b53bb12bcf5387421c0e6bf741c9a109a925c12800b9c268")
