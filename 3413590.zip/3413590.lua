-- Lua provided by RyzenAPI
-- Game: Raid Auctus

-- MAIN APPLICATION
addappid(3413590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413592,0,"a23e2fa96dd2382708beae33efbbc1196659d2a7e60f54c91792b12e9e95f9d8")

