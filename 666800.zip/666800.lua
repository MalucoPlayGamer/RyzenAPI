-- Lua provided by RyzenAPI
-- Game: Solitaire - Cat Pirate Portrait

-- MAIN APPLICATION
addappid(666800)
-- Game: addappid(666800)

-- MAIN APP DEPOTS / PACKAGES
addappid(666801, 1, "9c51a818f4f8f493f1dd6176d06cf8340cddfaebb6359d4a186cc86d78e45aba")
