-- Lua provided by RyzenAPI
-- Game: Pressure

-- MAIN APPLICATION
addappid(224220)

-- MAIN APP DEPOTS / PACKAGES
addappid(224221, 1, "fa3d4f1df789ee89790d11f5154c1fc0bc45c6e0aa8c760ea222947644ca8af6")
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

