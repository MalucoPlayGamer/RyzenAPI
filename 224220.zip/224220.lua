-- Lua provided by RyzenAPI
-- Game: AppID 224220

-- MAIN APPLICATION
addappid(224220)

-- MAIN APP DEPOTS / PACKAGES
addappid(224221, 1, "fa3d4f1df789ee89790d11f5154c1fc0bc45c6e0aa8c760ea222947644ca8af6")
