-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1180180)
-- Game: addappid(1180180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180180,0,"8a5cc841bae5f44202cbf2d13d4996892d9de58ef45b7594cc5236d2b95290ef")
