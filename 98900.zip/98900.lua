-- Lua provided by RyzenAPI
-- Game: addappid(98900)

-- MAIN APPLICATION
addappid(98900)

-- MAIN APP DEPOTS / PACKAGES
addappid(98902,0,"b8c33c1851f632c133793b6fc93d5912afcc2c3f94eda3550db412fb467414b7")
