-- Lua provided by RyzenAPI
-- Game: Game: Terra Nil

-- MAIN APPLICATION
addappid(1593030)
-- Game: addappid(1593030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593031, 1, "fb819bd41659158d7eaf863588d03381b5065204e716c1f1630ed65a185aa897")
addappid(1593032, 1, "320c010924276129a5ed20b69f92acdd9953c8887fc6af002ead94bbb669f012")
addappid(1593033, 1, "0e7d2a0f9baa8c5a3be1262df6c6a84e70ff44c5f7fcbc04c19c72dbb60f4ccb")
addappid(2321930, 0, "02757f56a474735a503289ae2b52ffb6aeda1c41eb2eec9b5e04bd596eca88d3")
