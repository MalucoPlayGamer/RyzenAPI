-- Lua provided by RyzenAPI 
-- Game: AppID 581100
addappid(581100)
addappid(581101, 1, "fb9160950c0aa08645fec4d09b69d2febf57655a17afc09e6495d79a5166a91b")
addappid(581102, 1, "ebae48ed580582e28d7b2a27a6dc3e41524814f6465f5eeee6902a5e5477a0e5")
addappid(581103, 1, "25ce61fe1d9b671b50763fd05698fa175fbcc6fa4508ae0514c558f89c5f2ae1")
