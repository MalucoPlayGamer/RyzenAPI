-- Lua provided by RyzenAPI
-- Game: Langoth

-- MAIN APPLICATION
addappid(581100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(581101, 1, "fb9160950c0aa08645fec4d09b69d2febf57655a17afc09e6495d79a5166a91b")
addappid(581102, 1, "ebae48ed580582e28d7b2a27a6dc3e41524814f6465f5eeee6902a5e5477a0e5")
addappid(581103, 1, "25ce61fe1d9b671b50763fd05698fa175fbcc6fa4508ae0514c558f89c5f2ae1")
