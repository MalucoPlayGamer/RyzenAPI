-- Lua provided by SkyAPI 
-- Game: SoundPackager 10
addappid(975550)
addappid(975551, 1, "72bb4695e3689fef01d7beca48bfe09f99cd3c6d724931864cb9cb61dbbc1b6e")
addappid(975552, 1, "4ce1c142dcefd891f3676c1a58e48f111fb4721195a0cfe545fcbb6b4268d9d6")
