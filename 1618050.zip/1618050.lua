-- Lua provided by RyzenAPI
-- Game: Game: Synth Retro Vapor Wave

-- MAIN APPLICATION
addappid(1618050)
-- Game: addappid(1618050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618051, 1, "c610c29127b858fd8e4f9e8e787416acbb9c7eecf32baef856615371ef6f9900")
