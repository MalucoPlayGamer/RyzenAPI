-- Lua provided by RyzenAPI
-- Game: Beyond Divinity

-- MAIN APPLICATION
addappid(219760)
-- Game: addappid(219760)

-- MAIN APP DEPOTS / PACKAGES
addappid(219761, 1, "0613adbc9d7d7717badcd74a5c2b8479ec67d4af21e7cbaabce8f3ec98c2287e")
addappid(219762, 1, "6772419782b15c1c4f6d4a27ae1cb742b9b9d00090c7ea83431738e4495340b2")
addappid(219763, 1, "4aaab1d1ed9745ba1f8590022ab0c22c8905e5b6d5b61c50c1f1e89ad3a4673c")
addappid(219764, 1, "89fff6680b30e9a1a97d59610ebee2cc25bf11a74b06214b81b3666d93dea323")
addappid(219765, 1, "6ef1ba197f44343e96fdbd99abfad7c0d66fc2606eea21516e5cd7a696248891")
addappid(219766, 1, "352b7b50c3eb6870ab60c8fb315854a50e3cdae19c2e9750f2863203ea947033")
