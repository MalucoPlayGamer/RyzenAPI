-- Lua provided by RyzenAPI
-- Game: addappid(977510)

-- MAIN APPLICATION
addappid(977510)

-- MAIN APP DEPOTS / PACKAGES
addappid(977511, 1, "04e769b473b2710f0e88414ad7b31f7ad4de3e4e4887a65eca890ae772c5ccdb")
