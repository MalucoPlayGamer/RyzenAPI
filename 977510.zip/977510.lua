-- Lua provided by SkyAPI 
-- Game: Time to Morp
addappid(977510)
addappid(977511, 1, "04e769b473b2710f0e88414ad7b31f7ad4de3e4e4887a65eca890ae772c5ccdb")
