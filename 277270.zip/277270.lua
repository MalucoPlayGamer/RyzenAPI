-- Lua provided by RyzenAPI
-- Game: AppID 277270

-- MAIN APPLICATION
addappid(277270)

-- MAIN APP DEPOTS / PACKAGES
addappid(277271, 1, "308bec331531674d9ef9be285e85ea81ff136f38abdde64637f819a9ad010cfc")
addappid(277273, 1, "ab11ded3bbdeee0d0de6314b02d9aecc46a84659b5b1b8d134fd5662e399d006")
addappid(277274, 1, "8d8a5e31754d0f33396f5ad8dab2d64c8c5ce98f1e91b052d994c2a1cbd2d1da")
addappid(277275, 1, "0b9f9cc848e7d5b09dca4a8ace4cb57ff721c05fdf7c4d3d4871b56b7d120ce0")
addappid(277276, 1, "96845a64afe2562aae677ea5bcc7af8e0968cf8e63164afb7d8f99f11939fa35")
addappid(277277, 1, "1bc0289dbcd7a7d2d473f54b35b92191bf1e9d385353f62fe75f5418e9431612")
addappid(277278, 1, "a3c11962c71b0239d96fb8688d415c43bf81b8731601b9c863f0586a261c178f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
