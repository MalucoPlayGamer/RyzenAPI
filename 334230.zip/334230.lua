-- Lua provided by RyzenAPI
-- Game: 334230

-- MAIN APPLICATION
addappid(334230)
addappid(626470)
-- Game: addappid(334230)

-- MAIN APP DEPOTS / PACKAGES
addappid(334231, 1, "fd70f0b581e55a112ec1bad0c7dd80be2d51d7ef00a9116d2e23008527892d14")
addappid(334232, 1, "1260938e7a4fd7fbd6468c8e19036800e3bef45d2b1581e79e6ef2958fa3d6e2")
addappid(648420, 0, "f14b8455fee151d54b453bf703d357aaf52222c5142a03bdc57ee32ae3c8a12f")
