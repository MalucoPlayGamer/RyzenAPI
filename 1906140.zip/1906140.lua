-- Lua provided by RyzenAPI
-- Game: Game: SEARCH ALL - BERRIES

-- MAIN APPLICATION
addappid(1906140)
-- Game: addappid(1906140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906141, 1, "59be3fcf486b44c072e215b9adee698c2b490555819c8dbe38df6df31501697e")
