-- Lua provided by RyzenAPI
-- Game: Game: OpenVR Benchmark

-- MAIN APPLICATION
addappid(955610)
addappid(1199470)
-- Game: addappid(955610)

-- MAIN APP DEPOTS / PACKAGES
addappid(955611, 1, "55cccea95c81d5a136b6da5cac0d008d23e8cec9cd9ba0af3083cfafd3638ca2")
