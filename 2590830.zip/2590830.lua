-- Lua provided by RyzenAPI
-- Game: 2590830

-- MAIN APPLICATION
addappid(2590830)
-- Game: addappid(2590830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590831, 1, "c044c05f593c20ad25d56d4ca98a2cf0f5789831b91e2a81e3d5fbc690e716cf")
