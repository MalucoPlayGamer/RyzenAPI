-- Lua provided by RyzenAPI
-- Game: Arise: A Simple Story - Artbook

-- MAIN APPLICATION
addappid(2018010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018010,0,"2a1dcbf950c009333b045eb125c4d0263490b4457a1ac37e2c63916117254d97")

