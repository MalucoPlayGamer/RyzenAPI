-- Lua provided by RyzenAPI
-- Game: OPPAI Ero App Academy Bigger, Better, Electric Boobaloo! Special Mosaic Removal DLC

-- MAIN APPLICATION
addappid(2998690)
-- Game: addappid(2998690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998690,0,"ceb593cafb7197c784c7034fb17906781335ecdd45d0f28975ca7a001519ec0e")
