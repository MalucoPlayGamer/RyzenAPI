-- Lua provided by RyzenAPI
-- Game: Sockventure

-- MAIN APPLICATION
addappid(1222340)
-- Game: addappid(1222340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222341, 1, "0beabcea59289b09621d85a115e5915d62524565c5b01156c9de3e876541a799")
