-- Lua provided by RyzenAPI
-- Game: Game: Cepheus Protocol Anthology Season 1

-- MAIN APPLICATION
addappid(1707120)
-- Game: addappid(1707120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707121, 1, "f81836d31c724866de0cb740f978e834ec33ffc4178e428dc5c08b4694095019")
