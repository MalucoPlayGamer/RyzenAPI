-- Lua provided by RyzenAPI
-- Game: Hentai ASMR

-- MAIN APPLICATION
addappid(1465390)
-- Game: addappid(1465390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465391, 1, "c3047dfbf1c28ad980f3e19e567f6286813526a395f17c30224af554e848703d")
