-- Lua provided by RyzenAPI
-- Game: Shoottera

-- MAIN APPLICATION
addappid(804970)
-- Game: addappid(804970)

-- MAIN APP DEPOTS / PACKAGES
addappid(804971, 1, "a987f8467de100ee5d2a9efe69b46a56acd43d7fca4ede61e55980d97e3666cc")
