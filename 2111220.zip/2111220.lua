-- Lua provided by RyzenAPI
-- Game: The Resurrection Of Amelia : Across two worlds

-- MAIN APPLICATION
addappid(2111220)
addappid(2343360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111221, 1, "049ca114e365872f62b27aa232a3c26e7c2e788b25f34c1a32e381d7c6462827")

