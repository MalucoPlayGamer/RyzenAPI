-- Lua provided by RyzenAPI
-- Game: AppID 2093090

-- MAIN APPLICATION
addappid(2093090)
-- Game: addappid(2093090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093091, 1, "684e42de0471a637015342c34323a934cb742bf7bf07ea7f50ebcb2048c7959f")
