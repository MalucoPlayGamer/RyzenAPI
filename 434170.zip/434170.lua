-- Lua provided by RyzenAPI
-- Game: The Jackbox Party Pack 3

-- MAIN APPLICATION
addappid(434170)

-- MAIN APP DEPOTS / PACKAGES
addappid(434171, 1, "1ef088cf38a83d141704681b54e58b887a2725a00f7ac77025c2666189a99ce2")
addappid(434172, 1, "03271cdf2ff0959f932bf06d4f09e4ea35d5b048dae73738ba96c5b4a2426f9b")
addappid(434173, 1, "1ebccc780150add959fa3201f78623e64055db56adf8d914d2034f8913ba990a")
addappid(434174, 1, "132527bd962b8c4f6acd145352cd7ea300cce21bd63cfcc886d27f3377fa6b91")
addappid(434175, 1, "671c941331e7d0399a82ec24a445329d45e41936635502b531ad22be5c9ffd0d")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
