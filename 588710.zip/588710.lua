-- Lua provided by RyzenAPI
-- Game: Neighboring Islands

-- MAIN APPLICATION
addappid(588710)

-- MAIN APP DEPOTS / PACKAGES
addappid(588711, 1, "2415c3d63b1710dc51a223951867734695ea8c2fa0e6ad41cd37c44ffbef53dd")
addappid(588712, 1, "62438d0422b3bd7e1c1d669ff1375a0ad996ff67ca03d0d2bc7e90db9643095d")
