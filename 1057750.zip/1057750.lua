-- Lua provided by RyzenAPI
-- Game: The Suicide of Rachel Foster

-- MAIN APPLICATION
addappid(1057750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057751, 1, "3690ccd9e47ca6bde171f4454e869ef791941117e56ed88eed23e4945b297cfa")
