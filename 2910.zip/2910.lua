-- Lua provided by RyzenAPI
-- Game: Fleet Command

-- MAIN APPLICATION
addappid(2910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911, 1, "e945a298bf614600a3e5f44f038bb0b71b985f5f10e44ecc2c347a68c979c348")
