-- Lua provided by RyzenAPI
-- Game: Game: Koboo: The Tree Spirit

-- MAIN APPLICATION
addappid(718190)
-- Game: addappid(718190)

-- MAIN APP DEPOTS / PACKAGES
addappid(718191, 1, "1a339d436e94b815aef86c90839cb79ee9e2d3db01f6b3472d231a9354507ef0")
