-- Lua provided by RyzenAPI 
-- Game: AppID 716500
addappid(716500)
addappid(716501, 1, "a73cbc7d1a38911d8393f95286c25763663a8fb49e4fa5fea776de4d303782be")
addappid(716502, 1, "7ff6a224d0ec09ba60a7af29dc8fe632fba48b7c5b7c96515ec86d6ffdf5eb1a")
addappid(716503, 1, "b1ae03794a7f5359d9a71ea55165c561f6edc54ae6c452d63709982a11bc7f91")
