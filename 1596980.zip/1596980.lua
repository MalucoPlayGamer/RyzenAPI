-- Lua provided by RyzenAPI
-- Game: Hentai Hack-Her

-- MAIN APPLICATION
addappid(1596980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1596981, 1, "c68401016efad16fc79573e0a80c2fa8fad0f91b41d83199ee5da544a3efdd19")
