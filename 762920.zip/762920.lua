-- Lua provided by RyzenAPI
-- Game: 762920

-- MAIN APPLICATION
addappid(762920)
-- Game: addappid(762920)

-- MAIN APP DEPOTS / PACKAGES
addappid(762921, 1, "757e7884b8da2e208f89cb25a398c16878b62d4bc7e6d73f5a7c367a561f00d6")
