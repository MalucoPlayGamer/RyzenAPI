-- Lua provided by RyzenAPI
-- Game: 1744330

-- MAIN APPLICATION
addappid(1744330)
-- Game: addappid(1744330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744331, 1, "35a5ff9a91ea79ea241820f3d5554be376a9c4b89f22b978a942503b118de9af")
