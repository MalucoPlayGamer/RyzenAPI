-- Lua provided by RyzenAPI
-- Game: No More Heroes 3

-- MAIN APPLICATION
addappid(1744330)
addappid(2122940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1744331, 1, "35a5ff9a91ea79ea241820f3d5554be376a9c4b89f22b978a942503b118de9af")

