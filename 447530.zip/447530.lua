-- Lua provided by RyzenAPI
-- Game: Game: VA-11 Hall-A: Cyberpunk Bartender Action

-- MAIN APPLICATION
addappid(447530)
-- Game: addappid(447530)

-- MAIN APP DEPOTS / PACKAGES
addappid(447531, 1, "47fcb0672e67462091fdc31eae398a3710cdde69f7ead7e9addf905b627df0d7")
addappid(447532, 1, "14a19be13d568a45a54303696f185911c8f92dd7312735eaf06002330e58dd04")
addappid(447533, 1, "efb2ad0bb91cea272ff67141a74130f693893d512b2130d1987b57402a92a03e")
