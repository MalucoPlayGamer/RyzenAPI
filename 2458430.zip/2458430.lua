-- Lua provided by RyzenAPI
-- Game: Leila

-- MAIN APPLICATION
addappid(2458430)
-- Game: addappid(2458430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458431, 1, "d6624f9a9ad8ef374e5e96eed4560fc302f705fc68f88e2fe69369fd4ef9e3fa")
addappid(3640180, 0, "dfc2d151b70a9a2653c9102cf054c689091f90c25bac4c60a1bdc9531c444428")
