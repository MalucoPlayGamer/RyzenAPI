-- Lua provided by RyzenAPI
-- Game: 2435180

-- MAIN APPLICATION
addappid(2435180)
-- Game: addappid(2435180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435181, 1, "bc5ff6bc327ed873aeb49bb25be09ce2d9d7aba4e19f8b467ef2d1e7dc690a71")
