-- Lua provided by RyzenAPI
-- Game: 3667630

-- MAIN APPLICATION
addappid(3667630)
-- Game: addappid(3667630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3667635,0,"fd2057af051fbba3d141e986c99c8c77c63ffe1c34fc549e5f6bd654091eefcf")
