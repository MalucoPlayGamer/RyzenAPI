-- Lua provided by RyzenAPI
-- Game: Tunnel

-- MAIN APPLICATION
addappid(3667630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3667635,0,"fd2057af051fbba3d141e986c99c8c77c63ffe1c34fc549e5f6bd654091eefcf")

