-- Lua provided by RyzenAPI
-- Game: The Drifter Demo

-- MAIN APPLICATION
addappid(1207670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207671, 1, "f0b929fa2106437bc57d18ad1317841591479e2ca2efa55598f32931d1450b4d")
