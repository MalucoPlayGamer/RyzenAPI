-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1798120)
-- Game: addappid(1798120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798120,0,"24e35a121dcda5cec7a6017a1770602c3a03d87c51897b302b38f2153f437aed")
