-- Lua provided by RyzenAPI
-- Game: Neon

-- MAIN APPLICATION
addappid(783090)

-- MAIN APP DEPOTS / PACKAGES
addappid(783091,0,"f8bb17a6395f6a6a45aa8eb6757b7fb315f286eac0112918abf9f28475c1c37f")

