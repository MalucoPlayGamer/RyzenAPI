-- Lua provided by RyzenAPI 
-- Game: Antarctic Adventure
addappid(2053280)
addappid(2053281, 1, "d185a0498e58c2cfaa13782493da82ebd71bfa0d246183eb236608ba03aaef16")
