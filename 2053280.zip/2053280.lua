-- Lua provided by RyzenAPI
-- Game: Antarctic Adventure

-- MAIN APPLICATION
addappid(2053280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053281, 1, "d185a0498e58c2cfaa13782493da82ebd71bfa0d246183eb236608ba03aaef16")

