-- Lua provided by RyzenAPI
-- Game: Looking Up I See Only A Ceiling Demo

-- MAIN APPLICATION
addappid(2205180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205182,0,"50efbed8a0f42d6b51a29f9405996d7fadae685af720f05223d26b0d23d5c528")

