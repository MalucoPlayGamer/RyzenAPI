-- Lua provided by RyzenAPI
-- Game: Taimumari: Definitive Edition

-- MAIN APPLICATION
addappid(375520)
addappid(431340)
addappid(998580)

-- MAIN APP DEPOTS / PACKAGES
addappid(375522,0,"8a26e3f295a44469ac1192cdb26ba89c509cd75d98b6d6649c4d7119b70a9bc8")
addappid(375523,0,"769d83797fff5df6e405260ce5503e09d9e7529c890c5efd6da31852c6c1f93b")
addappid(375524,0,"c929cb1138ff7243e7f2d96df4e34d72f7c6fe3a31355633496923a2f62d2a8d")
addappid(376233,0,"8cc3675d10ca9369cb0afaf08d4aff68b4c14255951b9d25ff3f7f63af2afe27")

