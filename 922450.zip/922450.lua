-- Lua provided by RyzenAPI
-- Game: AppID 922450

-- MAIN APPLICATION
addappid(922450)

-- MAIN APP DEPOTS / PACKAGES
addappid(922451, 1, "a443146c275a32f06a493138eb415706ba75461349e232401e48908e3644c2a9")
addappid(922452, 1, "46d52c7afb65fb380f07005473587a30dff4564da35e4cd2a625ba3cc16a237a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
