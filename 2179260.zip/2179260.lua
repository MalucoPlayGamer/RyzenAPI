-- Lua provided by RyzenAPI
-- Game: Simple Snooker

-- MAIN APPLICATION
addappid(2179260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2179261, 1, "d306a558cc702ee183dbc3b9a09502d9dd01320d9c4a16a3231cecdde0cd8dfd")

