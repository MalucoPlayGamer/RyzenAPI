-- Lua provided by SkyAPI 
-- Game: Simple Snooker
addappid(2179260)
addappid(2179261, 1, "d306a558cc702ee183dbc3b9a09502d9dd01320d9c4a16a3231cecdde0cd8dfd")
