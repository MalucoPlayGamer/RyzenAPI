-- Lua provided by RyzenAPI
-- Game: Simple Snooker

-- MAIN APPLICATION
addappid(2179260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179261, 1, "d306a558cc702ee183dbc3b9a09502d9dd01320d9c4a16a3231cecdde0cd8dfd")

