-- Lua provided by RyzenAPI
-- Game: addappid(1543120)

-- MAIN APPLICATION
addappid(1543120)
addappid(1543160)
addappid(1543161)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543121, 1, "450d1b3630dd6e1a188ca49752fffdee9518a370019a67018a7b8c05aef674d8")
