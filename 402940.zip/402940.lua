-- Lua provided by RyzenAPI
-- Game: Dungeons of Betrayal

-- MAIN APPLICATION
addappid(402940)

-- MAIN APP DEPOTS / PACKAGES
addappid(402941, 1, "e7f908cde78b2f5d7d4461a119deed5323646e2ea470e3a09bffd36c2cbb0207")
addappid(402942, 1, "ef6e7687674aa1e8aed11dfdb54df633659eaa76fd4c11e2ee9f2c197de670b4")
addappid(402943, 1, "21d14686dcad8baf7d72ab5266723bba70cd54003d88f37204295a9a4d82c906")
addappid(402944, 1, "025f4bc8bb2c38f2fc79d40ed80c5e3d3cecffb19899c16a625ac397ed04c3c1")
addappid(402945, 1, "e8b77e909fe4ae2417a26862a43a9be9c710972b0da434fdb8b399781ad186db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
