-- Lua provided by RyzenAPI
-- Game: SenS

-- MAIN APPLICATION
addappid(1966170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1966172,0,"db744f594ab61b8875b922c739d9b17b81f93059b8ad6c82b5e01bb85991faf2")

