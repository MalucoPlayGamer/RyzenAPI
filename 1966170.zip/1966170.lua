-- Lua provided by RyzenAPI
-- Game: 1966170

-- MAIN APPLICATION
addappid(1966170)
-- Game: addappid(1966170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966172,0,"db744f594ab61b8875b922c739d9b17b81f93059b8ad6c82b5e01bb85991faf2")
