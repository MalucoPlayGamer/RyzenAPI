-- Lua provided by RyzenAPI
-- Game: Time For Quest

-- MAIN APPLICATION
addappid(1112050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(1112051, 1, "21384abe55e6d242c7eb2a4e8c1b0d8f29061eb27e8b0260b7ec75a3fc86c57a")

