-- Lua provided by RyzenAPI
-- Game: addappid(1112050)

-- MAIN APPLICATION
addappid(1112050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112051, 1, "21384abe55e6d242c7eb2a4e8c1b0d8f29061eb27e8b0260b7ec75a3fc86c57a")
