-- Lua provided by RyzenAPI
-- Game: Dark Cave

-- MAIN APPLICATION
addappid(1459160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1459161, 1, "ed05af14413abb6f8f28f5e3f2d6688180a0c781d5e82c76925c2791935f2128")

