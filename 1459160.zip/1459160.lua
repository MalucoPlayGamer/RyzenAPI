-- Lua provided by RyzenAPI
-- Game: Dark Cave

-- MAIN APPLICATION
addappid(1459160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459161, 1, "ed05af14413abb6f8f28f5e3f2d6688180a0c781d5e82c76925c2791935f2128")

