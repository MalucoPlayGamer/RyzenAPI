-- Lua provided by SkyAPI 
-- Game: DEEMO -Reborn- Taiko no Tatsujin Collaboration Collection
addappid(1460620)
addappid(1460621, 1, "a1e6639b8d3bc5e0934f952aef5c6674e5aeb6ff9a57ac4b2f6fef4c5fc3d174")
addappid(1460622, 1, "d895162216656daefd5a0a4c04642242b7199b358665f827e2f6d5b76b65ba66")
