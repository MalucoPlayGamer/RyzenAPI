-- Lua provided by RyzenAPI
-- Game: Sleeping Dawn

-- MAIN APPLICATION
addappid(742900)
-- Game: addappid(742900)

-- MAIN APP DEPOTS / PACKAGES
addappid(742901, 1, "a8416db4f43037f4f9b9c95ad60bc1c4903ef1657c29d5b2b57f22d8127a85a9")
