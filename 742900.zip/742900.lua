-- Lua provided by SkyAPI 
-- Game: Sleeping Dawn
addappid(742900)
addappid(742901, 1, "a8416db4f43037f4f9b9c95ad60bc1c4903ef1657c29d5b2b57f22d8127a85a9")
