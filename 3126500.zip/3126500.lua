-- 3126500's Lua and Manifest Created by Hubcap Manifest
-- States of Power
-- Created: August 26, 2026 at 15:44:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3126500) -- States of Power
-- MAIN APP DEPOTS
addappid(3126501, 1, "8a951617e0e845f88da1eae96fa1b83b4c5aa7d543a2f6f98040a14563c59ae0") -- Depot 3126501
setManifestid(3126501, "6622369053885423711", 464623987)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)