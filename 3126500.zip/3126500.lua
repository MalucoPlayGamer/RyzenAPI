-- Lua provided by RyzenAPI
-- Game: States of Power

-- MAIN APPLICATION
addappid(3126500) -- States of Power

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(3126501, 1, "8a951617e0e845f88da1eae96fa1b83b4c5aa7d543a2f6f98040a14563c59ae0") -- Depot 3126501

