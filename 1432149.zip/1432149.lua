-- Lua provided by RyzenAPI
-- Game: FUSER™ - Erasure - "A Little Respect"

-- MAIN APPLICATION
addappid(1432149)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432149,0,"9ffb32780b2b1602e5a35a80c7dcbdaa9028b803b4ae926c625c7afeebee1d3f")
