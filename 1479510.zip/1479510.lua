-- Lua provided by SkyAPI 
-- Game: Per Aspera Original Soundtrack
addappid(1479510)
addappid(1479511, 1, "8806f859514922625ced3b4b01311092c659f49e0a88864e2ca8404610d429df")
