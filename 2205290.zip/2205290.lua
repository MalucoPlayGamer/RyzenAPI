-- Lua provided by RyzenAPI
-- Game: 流光易逝的夏末 - Fleeting Summer's End

-- MAIN APPLICATION
addappid(2205290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205291, 1, "65c6d468e88a8d43369bd7ce3d303dad34c1d73d9514102d3833f9ab1c9d7c33")
addappid(2205293, 1, "1031a182c190d69f85aced82006da8783609931e8c997be6deacbb1751819d85")
addappid(2205294, 1, "58fdaa404a14a076fb4becb7cb8c380811aee804b8090117de6225e1066640bb")
