-- Lua provided by RyzenAPI
-- Game: The Rainman

-- MAIN APPLICATION
addappid(2978710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978711, 1, "e7268b540c3494a64b5f64233b43ee50bc3fd3c1a4a40785b07450c687d14378")

