-- Lua provided by RyzenAPI
-- Game: Psebay

-- MAIN APPLICATION
addappid(608660)
addappid(1218860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(608661, 1, "c36fbd2b410a79ec501b492725bd0a691094b8883be50275915a58b2069635ee")
addappid(608662, 1, "4b2c4c7b6284a70729d69eff5d2ffae40bd166ce2303da8d55e87f852f60d8f8")
addappid(608663, 1, "455ed8423c80df9ea91d6f87b889d1213b1255fce104d8d277ba4774ca2c09b3")

