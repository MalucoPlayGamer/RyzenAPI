-- Lua provided by RyzenAPI
-- Game: Zigfrak

-- MAIN APPLICATION
addappid(259430)
addappid(259431)
addappid(259438)
addappid(259439)
addappid(259440)
-- Game: addappid(259430)

-- MAIN APP DEPOTS / PACKAGES
addappid(259432,0,"d16371876e67beaf7f5494970adce42589ea0a3242bf970e268e7a803c97a4c3")
addappid(259433,0,"b73d318a9943e6d3afde1c11f5def291829e6aadf4e13a716412a59ef5d457d9")
addappid(259434,0,"f0c44aa5ae4219de9b88036749f00e2cc1408c2416385bf4577014e56dafad2a")
addappid(259435,0,"a9dbce35f75cc0934097f4783a4037090b23a413bcca9c576ba65a75d51e216a")
addappid(259436,0,"871212cb287230fca1b0555bd89e1228117b33fd357a2cbdcccbc3075e8cde83")
addappid(259437,0,"e6f6c950ba116ae5c13ffc7a5fee3eeabc111efa745c82117ce7a824004d06f1")
