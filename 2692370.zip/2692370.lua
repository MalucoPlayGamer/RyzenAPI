-- Lua provided by RyzenAPI
-- Game: Game: AppID 2692370

-- MAIN APPLICATION
addappid(2692370)
-- Game: addappid(2692370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692371, 1, "5a089136fe117c514ce06ddc531473082b0b526587e519630c55fc0ef624a70d")
