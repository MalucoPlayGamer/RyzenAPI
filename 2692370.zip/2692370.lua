-- Lua provided by RyzenAPI 
-- Game: AppID 2692370
addappid(2692370)
addappid(2692371, 1, "5a089136fe117c514ce06ddc531473082b0b526587e519630c55fc0ef624a70d")
