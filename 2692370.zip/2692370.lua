-- Lua provided by RyzenAPI
-- Game: 饿殍：明末千里行 Demo

-- MAIN APPLICATION
addappid(2692370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692371, 1, "5a089136fe117c514ce06ddc531473082b0b526587e519630c55fc0ef624a70d")
