-- Lua provided by SkyAPI 
-- Game: Runo
addappid(1642130)
addappid(1642131, 1, "3638454c46c19a2cd60e5fccb519ce3398a8294eddd89408ebb6e202eb2ed278")
