-- Lua provided by RyzenAPI
-- Game: addappid(1642130)

-- MAIN APPLICATION
addappid(1642130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642131, 1, "3638454c46c19a2cd60e5fccb519ce3398a8294eddd89408ebb6e202eb2ed278")
