-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Cai Wenji (Maid Costume) / 蔡文姫 「メイド風コスチューム」

-- MAIN APPLICATION
addappid(978851)

-- MAIN APP DEPOTS / PACKAGES
addappid(978851,0,"5cfaa00da61dc3cfe9c3a83391ed6a45c060e3245ac8cd3dd866f122e38fd0b0")

