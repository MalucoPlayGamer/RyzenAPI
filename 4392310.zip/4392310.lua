-- Lua provided by RyzenAPI
-- Game: Gods of Angling

-- MAIN APPLICATION
addappid(4392310)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4398840)
addappid(4695360)
