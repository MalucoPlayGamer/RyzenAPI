-- Lua provided by RyzenAPI
-- Game: Gods of Angling

-- MAIN APPLICATION
addappid(4392310)
