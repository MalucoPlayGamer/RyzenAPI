-- Lua provided by RyzenAPI
-- Game: Gal*Gun: Double Peace

-- MAIN APPLICATION
addappid(511740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(511741, 1, "47aad8e9732ff6bc8555c630399da0ee0a1694bd45687beea36645e92da7b21f")

