-- Lua provided by RyzenAPI 
-- Game: Gal*Gun: Double Peace
addappid(511740)
addappid(511741, 1, "47aad8e9732ff6bc8555c630399da0ee0a1694bd45687beea36645e92da7b21f")
