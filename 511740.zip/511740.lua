-- Lua provided by RyzenAPI
-- Game: addappid(511740)

-- MAIN APPLICATION
addappid(511740)

-- MAIN APP DEPOTS / PACKAGES
addappid(511741, 1, "47aad8e9732ff6bc8555c630399da0ee0a1694bd45687beea36645e92da7b21f")
