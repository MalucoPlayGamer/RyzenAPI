-- Lua provided by RyzenAPI
-- Game: Game: Ego's Spark

-- MAIN APPLICATION
addappid(2579430)
-- Game: addappid(2579430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579431, 1, "fc02cd196afc6dcab3fa4ba6b1fb019e175bbc1dfc8d4495af9e4c628ce38e62")
