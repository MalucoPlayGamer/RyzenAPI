-- Lua provided by RyzenAPI
-- Game: 帶我去地下城吧！！ - 美術設定集

-- MAIN APPLICATION
addappid(2447350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447350,0,"ca56e3af3369dd95d871d70580bf76197aab0b801e12b483e0d6372bf5b46143")

