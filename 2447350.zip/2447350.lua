-- Lua provided by RyzenAPI
-- Game: 2447350

-- MAIN APPLICATION
addappid(2447350)
-- Game: addappid(2447350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447350,0,"ca56e3af3369dd95d871d70580bf76197aab0b801e12b483e0d6372bf5b46143")
