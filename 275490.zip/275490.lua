-- Lua provided by RyzenAPI
-- Game: addappid(275490)

-- MAIN APPLICATION
addappid(275490)
addappid(307390)

-- MAIN APP DEPOTS / PACKAGES
addappid(275491, 1, "71f91caf9287378e0d4724220823aabf22ca4137b21aa2d76ab68abf31cbe455")
