-- Lua provided by RyzenAPI
-- Game: GOHome_PICO

-- MAIN APPLICATION
addappid(3268450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3268451, 1, "b99428f5fa4dff554ad8e6b0385e049350a5789bb3278b8846386495a64bab3e")

