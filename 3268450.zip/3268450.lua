-- Lua provided by SkyAPI 
-- Game: GOHome_PICO
addappid(3268450)
addappid(3268451, 1, "b99428f5fa4dff554ad8e6b0385e049350a5789bb3278b8846386495a64bab3e")
