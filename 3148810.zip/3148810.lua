-- Lua provided by SkyAPI 
-- Game: DronesKillAnimals
addappid(3148810)
addappid(3148811, 1, "9e54ef982ed510f7a35cfd23d32fe168f58607ab2e350b02657876c99a51e3b6")
