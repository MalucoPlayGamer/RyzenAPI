-- Lua provided by RyzenAPI
-- Game: The Thing: Space X

-- MAIN APPLICATION
addappid(709700)
-- Game: addappid(709700)

-- MAIN APP DEPOTS / PACKAGES
addappid(709701, 1, "45cc92ef6163c4fa93fb576f82fa11a6461688af506e59bab796387fdbef4651")
