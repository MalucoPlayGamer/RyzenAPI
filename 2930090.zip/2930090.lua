-- Lua provided by RyzenAPI 
-- Game: AppID 2930090
addappid(2930090)
addappid(2930091, 1, "0e322ab349c78c29e36b69e269616bbca8d5ee43d3dfd5611693262490b992cb")
