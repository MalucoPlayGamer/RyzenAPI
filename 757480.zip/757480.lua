-- Lua provided by RyzenAPI
-- Game: 757480

-- MAIN APPLICATION
addappid(757480)
addappid(1071810)
-- Game: addappid(757480)

-- MAIN APP DEPOTS / PACKAGES
addappid(757481, 1, "951254e8082301ad84af2d1df49a2579ebfe6893addff9dc574e42deeef7e569")
