-- Lua provided by RyzenAPI
-- Game: addappid(1623720)

-- MAIN APPLICATION
addappid(1623720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623721, 1, "6985404e3763fbcb47ccff196a5294ec52e35cc5f5684fda5d8b4b4835d466f4")
