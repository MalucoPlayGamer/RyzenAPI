-- Lua provided by RyzenAPI
-- Game: addappid(2074000)

-- MAIN APPLICATION
addappid(2074000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074001, 1, "d349eff4d60e0f5c037833f5ba3547fc7ed74f890ddf53ea531d495b2aad7695")
