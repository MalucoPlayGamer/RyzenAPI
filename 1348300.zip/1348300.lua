-- Lua provided by RyzenAPI
-- Game: 1348300

-- MAIN APPLICATION
addappid(1348300)
-- Game: addappid(1348300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348301, 1, "7e31efd0d2195d7eea6d8ccd4445193d5dab192cfefaca1f1d230ad61951e6e6")
