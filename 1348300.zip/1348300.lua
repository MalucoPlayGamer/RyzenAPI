-- Lua provided by RyzenAPI 
-- Game: AppID 1348300
addappid(1348300)
addappid(1348301, 1, "7e31efd0d2195d7eea6d8ccd4445193d5dab192cfefaca1f1d230ad61951e6e6")
