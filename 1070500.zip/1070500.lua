-- Lua provided by RyzenAPI
-- Game: He Who Watches

-- MAIN APP DEPOTS / PACKAGES
addappid(1070500, 1, "009c3ff90465c8995e50ac0e1f5d8fe989895054fe48770b1a315baa617a023d") -- He Who Watches
addappid(1070501, 1, "497918b619080d9af91b43c8588e05bf396bc17b1be53b8cd7636a26c22c1e3c") -- Depot 1070501
addappid(1070502, 1, "5a6ed350c76799a15b67ca656132c5d49db897979da0bded8318b65bb1431e6a") -- Depot 1070502
