-- 4749880's Lua and Manifest Created by Hubcap Manifest
-- Desktop Bouncer
-- Created: August 21, 2026 at 13:42:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(4749880) -- Desktop Bouncer
-- MAIN APP DEPOTS
addappid(4749881, 1, "596d91e6d2f8ad0b4e233b5032731bd7b0f9da077ff313ba27ea40de8526e49a") -- Depot 4749881
setManifestid(4749881, "1602185782160904899", 36933953)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4871310) -- Desktop Bouncer - Supporter Pack (unreleased)