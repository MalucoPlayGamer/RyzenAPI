-- Lua provided by RyzenAPI
-- Game: Desktop Bouncer

-- MAIN APPLICATION
addappid(4749880) -- Desktop Bouncer
-- addappid(4871310) -- Desktop Bouncer - Supporter Pack (unreleased)

-- MAIN APP DEPOTS / PACKAGES
addappid(4749881, 1, "596d91e6d2f8ad0b4e233b5032731bd7b0f9da077ff313ba27ea40de8526e49a") -- Depot 4749881

