-- Lua provided by RyzenAPI
-- Game: Game: AppID 1829060

-- MAIN APPLICATION
addappid(1829060)
-- Game: addappid(1829060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829061, 1, "864d70e9fc9e0272b51a6bda6cb8c6bc8ccef930357f4cc84a9d18dd00548ca1")
