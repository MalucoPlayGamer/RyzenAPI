-- Lua provided by SkyAPI 
-- Game: Europa Universalis IV Demo
addappid(247890)
addappid(247891, 1, "5c6cb98ff8a5dac30b5367eeac64825d35ed10dad0ec9aa6ce03336e372f1439")
