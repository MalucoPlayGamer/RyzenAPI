-- Lua provided by RyzenAPI
-- Game: 247890

-- MAIN APPLICATION
addappid(247890)
-- Game: addappid(247890)

-- MAIN APP DEPOTS / PACKAGES
addappid(247891, 1, "5c6cb98ff8a5dac30b5367eeac64825d35ed10dad0ec9aa6ce03336e372f1439")
