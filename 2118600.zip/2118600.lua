-- Lua provided by RyzenAPI
-- Game: Game: AppID 2118600

-- MAIN APPLICATION
addappid(2118600)
-- Game: addappid(2118600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118601, 1, "d8366fd2ab991e4c22047ca626457f9b06766cdecb58e59b9a4d67afd3053376")
