-- Lua provided by SkyAPI 
-- Game: AppID 2118600
addappid(2118600)
addappid(2118601, 1, "d8366fd2ab991e4c22047ca626457f9b06766cdecb58e59b9a4d67afd3053376")
