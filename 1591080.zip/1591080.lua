-- Lua provided by SkyAPI 
-- Game: BETA: IVRy Monado Tracker for SteamVR
addappid(1591080)
addappid(1591081, 1, "0aca959d4c7877c0993c400d48c585da1017a10db653e7bf4d31525de80e2a51")
