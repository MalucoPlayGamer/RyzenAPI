-- Lua provided by RyzenAPI
-- Game: AppID 806220

-- MAIN APPLICATION
addappid(806220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(806221, 1, "faa50ea834eeda463e352b2284bae41cc72d820d350c2b62eca4a87985dcadd7")
addappid(810280, 0, "e71d5c06d87112ae2c62507513a475aa23e2bb46ed9f0f0d1529d4c9639e5ad8")

