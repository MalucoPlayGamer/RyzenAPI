-- Lua provided by SkyAPI 
-- Game: GARDEN&BIRD Demo
addappid(3426290)
addappid(3426291, 1, "96e6552df337e1a069e8e513b5a31ca77d6f9e7817cdb5d30bed9539ea88e34c")
