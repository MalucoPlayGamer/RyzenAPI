-- Lua provided by RyzenAPI
-- Game: GARDEN&BIRD Demo

-- MAIN APPLICATION
addappid(3426290)
-- Game: addappid(3426290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3426291, 1, "96e6552df337e1a069e8e513b5a31ca77d6f9e7817cdb5d30bed9539ea88e34c")
