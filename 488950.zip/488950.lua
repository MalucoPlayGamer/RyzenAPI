-- Lua provided by RyzenAPI
-- Game: 488950

-- MAIN APPLICATION
addappid(488950)
-- Game: addappid(488950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
