-- Lua provided by RyzenAPI 
-- Game: The Next World
addappid(427860)
addappid(427861, 1, "2279d7c493952f231e0473a8244dee17e8d58ecac0776fbbbbae090bea0e975d")
addappid(461020)
addappid(491740)
addappid(864080)
