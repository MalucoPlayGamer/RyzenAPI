-- Lua provided by RyzenAPI
-- Game: Gold Rush In The Oort Cloud

-- MAIN APPLICATION
addappid(661530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(661531, 1, "4dec0c16c3da4e50db1270a54136e618d25277f93817722e485c8f0ebfd355e2")
addappid(661532, 1, "897fd336a695a47d6bd81942496424a145abdcd82ab06832d1f91464d4a8c606")

