-- Lua provided by RyzenAPI 
-- Game: AppID 661530
addappid(661530)
addappid(661531, 1, "4dec0c16c3da4e50db1270a54136e618d25277f93817722e485c8f0ebfd355e2")
addappid(661532, 1, "897fd336a695a47d6bd81942496424a145abdcd82ab06832d1f91464d4a8c606")
