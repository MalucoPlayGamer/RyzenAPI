-- Lua provided by RyzenAPI
-- Game: AppID 2716210

-- MAIN APPLICATION
addappid(2716210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716211, 1, "afc2af07ad9bdd50d751741a05b9fc748a425c26edd6f2c3eb7f907fe92924d4")
