-- Lua provided by RyzenAPI
-- Game: Fruit Hunter

-- MAIN APPLICATION
addappid(1605580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1605581, 1, "d03d65d6aca95a2e15ea0e41fb6e6e8681303cd630bae47df189fcf8f54be753")

