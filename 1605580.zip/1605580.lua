-- Lua provided by RyzenAPI
-- Game: Fruit Hunter

-- MAIN APPLICATION
addappid(1605580)
-- Game: addappid(1605580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605581, 1, "d03d65d6aca95a2e15ea0e41fb6e6e8681303cd630bae47df189fcf8f54be753")
