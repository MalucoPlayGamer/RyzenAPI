-- Lua provided by RyzenAPI
-- Game: AppID 916060

-- MAIN APPLICATION
addappid(916060)

-- MAIN APP DEPOTS / PACKAGES
addappid(916061, 1, "e7152e4ae799126771115860a29a4d305dc79fcff22b9f583edd4ad5a4ecfd3b")
addappid(916062, 1, "737e20ef971b53e61de00f556f5c5f50955636050c44c3a2687f012751e0a4ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
