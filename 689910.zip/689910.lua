-- Lua provided by RyzenAPI
-- Game: Another Lost Phone: Laura's Story

-- MAIN APPLICATION
addappid(689910)
addappid(717630)

-- MAIN APP DEPOTS / PACKAGES
addappid(689911, 1, "3c455c8a8625f9645f470503cdfb004bd6fb2ef9d84f13d0f2e85354772bee74")

