-- Lua provided by RyzenAPI
-- Game: Small Saga

-- MAIN APPLICATION
addappid(1320140)
addappid(2695760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320141, 1, "aa585e8e53e4ef1a8a67a4dd9ba42fe97d975c57d32c4875da3b0c0f6e6002e8")
