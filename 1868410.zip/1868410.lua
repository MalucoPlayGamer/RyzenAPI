-- Lua provided by RyzenAPI
-- Game: Movie Night

-- MAIN APPLICATION
addappid(1868410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1868411, 1, "33c8b26b2e6e3af1695df93c3289ae8ab2b269dc2474d0d4188a5a6e5a46355f")

