-- Lua provided by RyzenAPI 
-- Game: Movie Night
addappid(1868410)
addappid(1868411, 1, "33c8b26b2e6e3af1695df93c3289ae8ab2b269dc2474d0d4188a5a6e5a46355f")
