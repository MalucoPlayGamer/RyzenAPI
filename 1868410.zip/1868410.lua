-- Lua provided by RyzenAPI
-- Game: 1868410

-- MAIN APPLICATION
addappid(1868410)
-- Game: addappid(1868410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868411, 1, "33c8b26b2e6e3af1695df93c3289ae8ab2b269dc2474d0d4188a5a6e5a46355f")
