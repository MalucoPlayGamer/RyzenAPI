-- Lua provided by RyzenAPI
-- Game: Left 4 Dead Dedicated Server

-- MAIN APPLICATION
addappid(222840)

-- MAIN APP DEPOTS / PACKAGES
addappid(222841, 1, "146d13961dd1054aa77fc06704170a59fbca4842554c5708e2e5d8616d472740")
addappid(222842, 1, "ada5e5b6918480dcfe70712df89a2182e10b3f3e714a59cabe4ec9d49d8daa0e")
addappid(222843, 1, "6c391b000674a94abd055d3c547b705e62a2d2fa5e534bd278be705f444c22c7")
