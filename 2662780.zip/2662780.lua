-- Lua provided by RyzenAPI
-- Game: Heat Death: Survival Train

-- MAIN APPLICATION
addappid(2662780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2662781, 1, "ed24354acad5e4184839fc73f8566220cb531f97a71d4bfae7ba7251b890a8f4")
