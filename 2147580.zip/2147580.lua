-- Lua provided by SkyAPI 
-- Game: 1990
addappid(2147580)
addappid(2147581, 1, "75ea165c9a996573eae54493ffefdec6185fb60e978419542e39a1d4f5bcc05e")
