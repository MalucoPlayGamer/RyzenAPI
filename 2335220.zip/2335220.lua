-- Lua provided by RyzenAPI
-- Game: addappid(2335220)

-- MAIN APPLICATION
addappid(2335220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335221, 1, "27763ab55f1a32e43270bb096bf4e103acef713123efb894cebce26421f66947")
