-- Lua provided by RyzenAPI 
-- Game: Iggy's Egg Adventure
addappid(366040)
addappid(366041, 1, "b90f57549cd8075cd6d08c2062f5e6ea96e68b6340a3d24fcac4dba3677febf2")
addappid(366043, 1, "904fdd0c54f5c58188a6902bbc4ed9771b04367e614b3034c5592f0d2d7e2651")
