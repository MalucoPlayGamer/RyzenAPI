-- Lua provided by RyzenAPI
-- Game: Game: Fisherman's House

-- MAIN APPLICATION
addappid(1745000)
-- Game: addappid(1745000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745001, 1, "61f0235d91eb887a3b20cdbaeb5a2816f985bcc9c4bad8631ce66ffe9f14d3c3")
