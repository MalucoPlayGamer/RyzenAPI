-- Lua provided by RyzenAPI
-- Game: Fisherman's House

-- MAIN APPLICATION
addappid(1745000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745001, 1, "61f0235d91eb887a3b20cdbaeb5a2816f985bcc9c4bad8631ce66ffe9f14d3c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
