-- Lua provided by RyzenAPI
-- Game: Pro Player Life

-- MAIN APPLICATION
addappid(1217610)
-- Game: addappid(1217610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217611, 1, "a2123363b3de236b11a041d50afd519402a7492a79872b3ff70740706df944cd")
