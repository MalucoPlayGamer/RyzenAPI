-- Lua provided by RyzenAPI 
-- Game: Pro Player Life
addappid(1217610)
addappid(1217611, 1, "a2123363b3de236b11a041d50afd519402a7492a79872b3ff70740706df944cd")
