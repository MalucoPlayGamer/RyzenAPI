-- Lua provided by RyzenAPI
-- Game: Stage Cleared

-- MAIN APPLICATION
addappid(3209860)
addappid(3209863)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209862,0,"2664033d3d18bd193a559cf996d0e7f071e5dedf0e5eaa39ef98971e1f4a2b0a")

