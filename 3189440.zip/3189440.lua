-- Lua provided by RyzenAPI
-- Game: Swords & Souls Legacy Collection

-- MAIN APPLICATION
addappid(3189440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3189441, 1, "51ce8d8397b1f2d08fc52011468b28d22dbbe05a96aed8af2343ad479bf9d515")

