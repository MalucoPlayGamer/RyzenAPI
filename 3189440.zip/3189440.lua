-- Lua provided by SkyAPI 
-- Game: Swords & Souls Legacy Collection
addappid(3189440)
addappid(3189441, 1, "51ce8d8397b1f2d08fc52011468b28d22dbbe05a96aed8af2343ad479bf9d515")
