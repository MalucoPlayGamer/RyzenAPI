-- Lua provided by RyzenAPI 
-- Game: Fairground Power Polyp Simulator
addappid(1738670)
addappid(1738671, 1, "5bc8e6cbc9a8213a339a1b19608648833e927b3571f2d2f02228d226d68cd044")
