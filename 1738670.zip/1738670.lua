-- Lua provided by RyzenAPI
-- Game: Fairground Power Polyp Simulator

-- MAIN APPLICATION
addappid(1738670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738671, 1, "5bc8e6cbc9a8213a339a1b19608648833e927b3571f2d2f02228d226d68cd044")

