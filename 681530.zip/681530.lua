-- Lua provided by RyzenAPI
-- Game: 681530

-- MAIN APPLICATION
addappid(681530)
-- Game: addappid(681530)

-- MAIN APP DEPOTS / PACKAGES
addappid(681531, 1, "e9e661f8522aee67c87602296b5c98c94117f84781303679dda0d265f1ded279")
