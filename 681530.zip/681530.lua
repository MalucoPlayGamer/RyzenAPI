-- Lua provided by RyzenAPI
-- Game: NOISZ

-- MAIN APPLICATION
addappid(681530)
addappid(964630)
addappid(964640)
addappid(1046100)
addappid(1789580)
addappid(2842440)

-- MAIN APP DEPOTS / PACKAGES
addappid(681531, 1, "e9e661f8522aee67c87602296b5c98c94117f84781303679dda0d265f1ded279")

