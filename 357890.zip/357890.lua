-- Lua provided by RyzenAPI
-- Game: 357890

-- MAIN APPLICATION
addappid(357890)
-- Game: addappid(357890)

-- MAIN APP DEPOTS / PACKAGES
addappid(357891, 1, "51290b1d023b3979e109c08d7d51c046805c42fbb6739b30f89d2ae0d7ad9344")
