-- Lua provided by RyzenAPI
-- Game: Game: AppID 2725760

-- MAIN APPLICATION
addappid(2725760)
-- Game: addappid(2725760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725761, 1, "fcaaad6451a3d561e72a822afe545699b8bb4b2657719371bd7337bdf605c44e")
