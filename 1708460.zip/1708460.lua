-- Lua provided by RyzenAPI
-- Game: Obsideo

-- MAIN APPLICATION
addappid(1708460)
-- Game: addappid(1708460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708461, 1, "397129534ea4aaa079227a0bea48540daff703198445e3809a71fe139e3a8cbc")
