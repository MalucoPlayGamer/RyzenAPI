-- Lua provided by RyzenAPI
-- Game: Cock Fight Simulator

-- MAIN APPLICATION
addappid(3330460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3330461, 1, "ffd7686475700b955b6eb640d9cff128e0808321dd17c0a7aa21932d056f0929")
addappid(3330462, 1, "30891e9ec47d6c070b61a09b53f7ef84ea460bfc11367abf4543faf1b7c3efa7")

