-- Lua provided by RyzenAPI
-- Game: Game: Unlimited Escape 2

-- MAIN APPLICATION
addappid(318560)
-- Game: addappid(318560)

-- MAIN APP DEPOTS / PACKAGES
addappid(318561, 1, "8d24269bbd4c61ceb38177389d2b78388b6aa129c7dec8644a96851608514961")
