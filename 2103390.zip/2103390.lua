-- Lua provided by RyzenAPI
-- Game: RunOut

-- MAIN APPLICATION
addappid(2103390)
-- Game: addappid(2103390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103391, 1, "825693055f3e41e5af49b1eb656305354d6d7f8870c1aeda8542336d37ff689e")
