-- Lua provided by RyzenAPI
-- Game: 2670760

-- MAIN APPLICATION
addappid(2670760)
-- Game: addappid(2670760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670761, 1, "2bdeb7da78d7b7fbf70c773f3f387d0f60d299b6f21722413e5124e9ab325610")
