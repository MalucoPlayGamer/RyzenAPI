-- Lua provided by RyzenAPI
-- Game: Kreedz Climbing

-- MAIN APPLICATION
addappid(626680)

-- MAIN APP DEPOTS / PACKAGES
addappid(626681, 1, "7ad83015f56e8a686a5da1e2df08fbdce38eee20b5031b66a05096fd04d47771")
addappid(626682, 1, "87f8f52aca026d7ee669d5f59abd9f4b0f8301b6dc63040e49906cee16fffcd0")
addappid(626683, 1, "6534d13b19cab57e0d9cafad8e5c1d1096fa74684d6e45665fb83a9065491c8b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
