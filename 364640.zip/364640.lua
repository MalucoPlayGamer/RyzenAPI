-- Lua provided by RyzenAPI
-- Game: Game: AppID 364640

-- MAIN APPLICATION
addappid(364640)
-- Game: addappid(364640)

-- MAIN APP DEPOTS / PACKAGES
addappid(364641, 1, "cfdf47caa069542ea8fec40f2c619ce1cca6e2a93de800ae26f50ddd57d59d20")
addappid(364642, 1, "095b019be6bc7c3123e6fd0c6671586ef84fed9dfb4c09d638709f7b90416add")
addappid(364643, 1, "d3cc78d393318c1523fdf4d76bdf6a026fd5e37f6d1023eae7c7f3b28a259216")
