-- Lua provided by RyzenAPI
-- Game: addappid(2373960)

-- MAIN APPLICATION
addappid(2373960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2373961, 1, "bbb132b60a253c7e47ef3093c8c8a237c568a5fdb9ad65772a3384384ee6e39f")
