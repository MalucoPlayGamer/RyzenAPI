-- Lua provided by RyzenAPI
-- Game: Game: Lights and Shadow

-- MAIN APPLICATION
addappid(3597690)
-- Game: addappid(3597690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3597691, 1, "e598184cf69273d40dd08e82a1eac4f175a878064492c7964cceba63529d13eb")
