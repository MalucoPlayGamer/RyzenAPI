-- Lua provided by SkyAPI 
-- Game: Lights and Shadow
addappid(3597690)
addappid(3597691, 1, "e598184cf69273d40dd08e82a1eac4f175a878064492c7964cceba63529d13eb")
