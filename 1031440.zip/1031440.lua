-- Lua provided by RyzenAPI 
-- Game: TOKYO CHRONOS
addappid(1031440)
addappid(1031441, 1, "ee43d6c1dca544e30b3836c547351f61238d90440979e3df4cf10d497caa093f")
