-- Lua provided by RyzenAPI
-- Game: 1031440

-- MAIN APPLICATION
addappid(1031440)
-- Game: addappid(1031440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031441, 1, "ee43d6c1dca544e30b3836c547351f61238d90440979e3df4cf10d497caa093f")
