-- Lua provided by RyzenAPI
-- Game: 1334730

-- MAIN APPLICATION
addappid(1334730)
-- Game: addappid(1334730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334731, 1, "80dc804978e2c906abcd41a36b30664dc151a44cc54821218f084c5dec84938a")
