-- Lua provided by RyzenAPI
-- Game: Rabbit Simulator

-- MAIN APPLICATION
addappid(1257210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257211, 1, "b1ab08fd95412a65e8c459036658636933237eb5051c332ddcfbaa9bb8fab459")

