-- Lua provided by RyzenAPI
-- Game: Evil is Back

-- MAIN APPLICATION
addappid(2363930)
-- Game: addappid(2363930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363931, 1, "2c85c727b21623326d1816fd4aa50974ec53cb04a3889e172f0a8e9dfe26e74c")
