-- Lua provided by RyzenAPI
-- Game: Monobeno

-- MAIN APPLICATION
addappid(758090)
addappid(782090)

-- MAIN APP DEPOTS / PACKAGES
addappid(758091, 1, "5f812f0e87d22b6339d47a8fbc98617f2bee84d2599596d2c0b7cbfcb983e5b8")
addappid(758092, 1, "1ed4dd35b3330b6509117d17489ddb2bb18e5e263ee45159da01355fedc685b8")
addappid(758093, 1, "bfbe141313219ac2bce922a2858677a35c0366b46ff23ad84c83d83dee4dbec1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
