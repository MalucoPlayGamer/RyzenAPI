-- Lua provided by RyzenAPI
-- Game: BioGun Demo

-- MAIN APPLICATION
addappid(1861680)
-- Game: addappid(1861680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861682,0,"a189474dd76414cdcd279dedb97be1bcd808e1ae4c29d593be27cf17c037008e")
