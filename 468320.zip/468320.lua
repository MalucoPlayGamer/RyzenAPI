-- Lua provided by RyzenAPI
-- Game: Mini Golf Mundo

-- MAIN APPLICATION
addappid(468320)
-- Game: addappid(468320)

-- MAIN APP DEPOTS / PACKAGES
addappid(468321, 1, "217ec061181c5cf17bdd28967267f6f1959c99659ee4b92218a310a3998e4dd4")
