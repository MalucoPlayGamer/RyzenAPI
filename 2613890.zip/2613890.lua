-- Lua provided by RyzenAPI
-- Game: Game: Icaria

-- MAIN APPLICATION
addappid(2613890)
-- Game: addappid(2613890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613891, 1, "8a57929b81b3083be78a873df5075852d1dc5017c1793a3ef2207212d472cf91")
