-- Lua provided by SkyAPI 
-- Game: Icaria
addappid(2613890)
addappid(2613891, 1, "8a57929b81b3083be78a873df5075852d1dc5017c1793a3ef2207212d472cf91")
