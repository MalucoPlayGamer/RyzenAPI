-- Lua provided by RyzenAPI
-- Game: Game: Holiday in Europe: Czech Adventure Collector's Edition

-- MAIN APPLICATION
addappid(3660100)
-- Game: addappid(3660100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3660101, 1, "8f1e0233787346e42323fbea98659b38eaece3b728579646d3e50e7c9e61aab8")
