-- Lua provided by RyzenAPI 
-- Game: AppID 1258910
addappid(1258910)
addappid(1258911, 1, "3a431e0d78fa0952c9b981a210e2f4ab1feb88d344410e05223b33358a022c67")
