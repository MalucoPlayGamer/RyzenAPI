-- Lua provided by RyzenAPI
-- Game: addappid(678520)

-- MAIN APPLICATION
addappid(678520)

-- MAIN APP DEPOTS / PACKAGES
addappid(678521, 1, "6b76a5a7df2814e535f8897b9408a1aa3ca4f4c27673803c3be2e222737e8b78")
