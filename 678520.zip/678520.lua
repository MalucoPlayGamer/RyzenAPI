-- Lua provided by SkyAPI 
-- Game: Gal*Gun VR
addappid(678520)
addappid(678521, 1, "6b76a5a7df2814e535f8897b9408a1aa3ca4f4c27673803c3be2e222737e8b78")
