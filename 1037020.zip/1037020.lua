-- Lua provided by RyzenAPI
-- Game: ScourgeBringer

-- MAIN APPLICATION
addappid(1037020)
-- Game: addappid(1037020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037021, 1, "4a2d389fbdc5b892beae45c1fa9ec799eac30975f5a0ea8153cd5edd45f60aca")
addappid(1037022, 1, "47cb365689e37b052ebb1c3056732c8280f9b321fea394351f983b049c1638dc")
addappid(1037023, 1, "2960aa663d74f620930aabd416360b185556894cb8d9a14593f59576cd551354")
addappid(1037024, 1, "aee0202ad6ac28ded1edbb1b4f87fbed59f054aa5ab78c50a799ef6c84d68404")
addappid(1408650, 0, "2ab1a48a7d33903d4dd15c49b34d138ae6d4337ee0339b8bfc6f7d6b2a9b8b83")
