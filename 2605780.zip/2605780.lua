-- Lua provided by SkyAPI 
-- Game: Three Kingdoms: Battle of Generals
addappid(2605780)
addappid(2605781, 1, "b69bfcb0d5181e7d2ad487ed49100542400a69a19177b008f7a822f1db692de3")
