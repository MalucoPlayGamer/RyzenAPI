-- Lua provided by RyzenAPI
-- Game: 天月麻雀 Playtest

-- MAIN APPLICATION
addappid(3210340)
-- Game: addappid(3210340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3210341, 1, "44fd30408d37c037dce806ed83a541023c889ac4c643e257c01b94c62ee92101")
