-- Lua provided by RyzenAPI
-- Game: Voidwrought Demo

-- MAIN APPLICATION
addappid(2865740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865741, 1, "ba4260538a2508316e209c20437b28c9fa9fade6b0aa9c6a07744619e3f0f54e")
