-- Lua provided by RyzenAPI
-- Game: G.I. Joe: Wrath of Cobra

-- MAIN APPLICATION
addappid(2516170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516171, 1, "98445802b21b8f4cae4ad9483f0fb3cbd0320519e8cf6dc7bc3d97c9452339c0")
