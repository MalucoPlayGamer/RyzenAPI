-- Lua provided by RyzenAPI
-- Game: Hashi Infinite

-- MAIN APP DEPOTS / PACKAGES
addappid(3280750, 1, "b5bb5b2ab22ee05a046fa48a3c943b434b4ff83c7e19610463eda13ecc891e27") -- Hashi Infinite
addappid(3280751, 1, "dc66c2b551b1bddffcdd7f72b30ec5310c82e3d2edfa74c6589181ac99aa29b8") -- Depot 3280751

