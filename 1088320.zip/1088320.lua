-- Lua provided by RyzenAPI
-- Game: Game: AppID 1088320

-- MAIN APPLICATION
addappid(1088320)
-- Game: addappid(1088320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088321, 1, "edc0a9975a6d473baa7f6c69ba5c9b0a93cba501522f03745d18bd1a50721991")
addappid(1088322, 1, "21701cf1b116cedb6fb775667007019fc5d9b675fde51aab94bb49c84d34c4de")
