-- Lua provided by RyzenAPI
-- Game: Super GTR Racing

-- MAIN APPLICATION
addappid(848260)

-- MAIN APP DEPOTS / PACKAGES
addappid(848261, 1, "7a4ea252887ffc501c11ea9cb9b074ba1b853276cc330e798f256373b71ea72a")
