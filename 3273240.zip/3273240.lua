-- Lua provided by RyzenAPI
-- Game: 3273240

-- MAIN APPLICATION
addappid(3273240)
-- Game: addappid(3273240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3273241, 1, "fe9f86ccf4158ce692f1d0a3e0bc277d689640e5edc7eb3ee53a62541d6ab8c9")
