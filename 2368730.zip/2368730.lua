-- Lua provided by RyzenAPI
-- Game: シロナガス島への帰還ボイスドラマ　少女達のドタバタ騒動

-- MAIN APPLICATION
addappid(2368730)
-- Game: addappid(2368730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368733,0,"137e6fe822c10f94205c57713ef9405d1ebba4543e29bf4636afebd529662695")
addappid(2368734,0,"9784e6ba282a7e49af610a60e04d8a6c792ac310e086d73b47d372915c090c3e")
