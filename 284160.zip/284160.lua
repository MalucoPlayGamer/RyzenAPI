-- Lua provided by RyzenAPI
-- Game: BeamNG.drive

-- MAIN APPLICATION
addappid(284160)

-- MAIN APP DEPOTS / PACKAGES
addappid(284161, 1, "0e77f1cd7bb3169d9885cc26c7d2ef9fffc02c8c49671bec7b7308dd6cf86229")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
