-- Lua provided by RyzenAPI
-- Game: BeamNG.drive

-- MAIN APPLICATION
addappid(284160)
-- Game: addappid(284160)

-- MAIN APP DEPOTS / PACKAGES
addappid(284161, 1, "0e77f1cd7bb3169d9885cc26c7d2ef9fffc02c8c49671bec7b7308dd6cf86229")
