-- Lua provided by RyzenAPI
-- Game: Seducing The Devil

-- MAIN APPLICATION
addappid(2178490)
-- Game: addappid(2178490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178491, 1, "b81dcf590dacac0be52c735e11c065352c41998735721806135d83375d372f75")
