-- Lua provided by RyzenAPI
-- Game: A Hint of Purple

-- MAIN APPLICATION
addappid(2396620)
-- Game: addappid(2396620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396621, 1, "6538ee1dab6b85fd2891d957d49aa49fb58ce90d8b6e6afb61def0646d2e10ab")
