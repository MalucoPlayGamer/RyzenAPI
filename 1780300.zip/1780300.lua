-- Lua provided by SkyAPI 
-- Game: Hello World
addappid(1780300)
addappid(1780301, 1, "418bfac51b36dbff2e0c8580f48b2eb357be21f6f71790bcb5a43e03e7bb6c6a")
