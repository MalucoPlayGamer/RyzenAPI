-- Lua provided by RyzenAPI
-- Game: Game: AppID 891200

-- MAIN APPLICATION
addappid(891200)
-- Game: addappid(891200)

-- MAIN APP DEPOTS / PACKAGES
addappid(891201, 1, "0ce8b85affe566fcbb8b21a5b0c0da9649228fc44353eebae1c250c4c43cdb01")
