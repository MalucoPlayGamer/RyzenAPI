-- Lua provided by RyzenAPI
-- Game: Super Squidlit

-- MAIN APPLICATION
addappid(1813100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813101,0,"9c85813da1eccd7ccca157b595814b8bfe1eb9b9e3f4861201904e7164d5eb84")

