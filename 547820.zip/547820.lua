-- Lua provided by RyzenAPI
-- Game: AppID 547820

-- MAIN APPLICATION
addappid(547820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(547821, 1, "6b3b9bfd7c0b3f83b274d1f25f6e6dea277b7fa099fa2a163bb1bffe2500844f")
addappid(547822, 1, "14ef1808e8148dd97b93c6725120b56250637e18e10a157ca8d9e43305d73482")
addappid(547823, 1, "175299edd2068141256644b3fdcfb90149a359385c1c44987eec49a5f5e8db53")

