-- Lua provided by SkyAPI 
-- Game: AppID 1244210
addappid(1244210)
addappid(1244211, 1, "b4f885f6f0f8e3b7e4d52ff59148f5ac4fa2c59b97c9d25cf4c8e7da42f909a8")
