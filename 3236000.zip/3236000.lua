-- Lua provided by RyzenAPI
-- Game: addappid(3236000)

-- MAIN APPLICATION
addappid(3236000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3236001, 1, "39bfee0a504373c2361d5f13f2ada7107b02278dfc4e5b6cd7acbf3aa6f7a26c")
addappid(3236002, 1, "434eda4915a1d518bb3f02fe1469786b8d9954ba7c80eac9157a289c31d09164")
addappid(3236003, 1, "0fb2b3678af94612dbe61e9264889d6f534c7af412f14505ddd8db28a6dca4ae")
