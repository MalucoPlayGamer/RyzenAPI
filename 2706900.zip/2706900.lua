-- Lua provided by RyzenAPI
-- Game: AppID 2706900

-- MAIN APPLICATION
addappid(2706900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706901, 1, "3879dc49f95bb56ec14849c090fa9c1b8fbdedc696def3f122127fcad061c7a8")

