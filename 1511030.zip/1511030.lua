-- Lua provided by SkyAPI 
-- Game: Pirates Outlaws Soundtrack
addappid(1511030)
addappid(1511031, 1, "37a125b49c6c485221b85649df09c67b120b0dd3c719f4cabcc811114286f88d")
