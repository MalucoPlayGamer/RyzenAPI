-- Lua provided by RyzenAPI
-- Game: Game: Pirates Outlaws Soundtrack

-- MAIN APPLICATION
addappid(1511030)
-- Game: addappid(1511030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511031, 1, "37a125b49c6c485221b85649df09c67b120b0dd3c719f4cabcc811114286f88d")
