-- Lua provided by RyzenAPI
-- Game: Gummy Jump

-- MAIN APPLICATION
addappid(2078820)
-- Game: addappid(2078820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078822,0,"2563cc817cfeb4a70a2bab39be4f7da75d38c855e121b9de2b2e03f9e296ae92")
