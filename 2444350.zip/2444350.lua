-- Lua provided by RyzenAPI
-- Game: Enchanted Portals

-- MAIN APPLICATION
addappid(2444350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444351, 1, "29c6f956c691d22366c4d36368c03246d21d16e683b03444b8f12fc823f6e6b0")

