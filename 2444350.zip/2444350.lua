-- Lua provided by RyzenAPI
-- Game: Enchanted Portals

-- MAIN APPLICATION
addappid(2444350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444351, 1, "29c6f956c691d22366c4d36368c03246d21d16e683b03444b8f12fc823f6e6b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
