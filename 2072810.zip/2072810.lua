-- Lua provided by RyzenAPI
-- Game: Nordic Ashes Demo

-- MAIN APPLICATION
addappid(2072810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072811, 1, "b3ceafec30308c9eaaf544ad1695238cf961050b5b801a6adc3e451ceac4c7f7")

