-- Lua provided by RyzenAPI
-- Game: 925610

-- MAIN APPLICATION
addappid(925610)
-- Game: addappid(925610)

-- MAIN APP DEPOTS / PACKAGES
addappid(925611, 1, "5c34bc5639436de458a5930fd5e693f83c4473ce5cd3792dd96b11549b67eb57")
