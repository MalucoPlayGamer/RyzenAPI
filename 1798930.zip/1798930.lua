-- Lua provided by RyzenAPI 
-- Game: AppID 1798930
addappid(1798930)
addappid(1798931, 1, "752d8f78c72e6af69985e568db0a5e1e46280bf1afb7756507c40a0b55c81883")
