-- Lua provided by SkyAPI 
-- Game: TramSim Vienna - The Tram Simulator
addappid(1314140)
addappid(1314141, 1, "0e49191d71d2e8f8c8e2e4ab2fcc9e1b3ca1cf8d2b6c29a91fd2e73cebbbc6e1")
addappid(1586691, 0, "b1211e7447920d3fc0cc1a6ff7da1f07e5de31232f245e9cf331144f73e1f00c")
