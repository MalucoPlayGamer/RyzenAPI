-- Lua provided by RyzenAPI
-- Game: TramSim Vienna - The Tram Simulator

-- MAIN APPLICATION
addappid(1314140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314141, 1, "0e49191d71d2e8f8c8e2e4ab2fcc9e1b3ca1cf8d2b6c29a91fd2e73cebbbc6e1")
addappid(1586691, 0, "b1211e7447920d3fc0cc1a6ff7da1f07e5de31232f245e9cf331144f73e1f00c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1586690)
addappid(1921280)
