-- Lua provided by RyzenAPI
-- Game: Hood: Outlaws & Legends

-- MAIN APPLICATION
addappid(927350)
addappid(1481490)
addappid(1492020)
addappid(1670390)
addappid(1670391)
addappid(1670392)
addappid(1677070)
addappid(1731600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(927351,0,"71791384496321f5d17e348a819dcae9a8f9137fed669431d7ccaf64df7804ad")

