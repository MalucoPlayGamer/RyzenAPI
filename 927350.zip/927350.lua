-- Lua provided by SkyAPI 
-- Game: Hood: Outlaws & Legends
addappid(927350)
addappid(927351, 1, "71791384496321f5d17e348a819dcae9a8f9137fed669431d7ccaf64df7804ad")
