-- Lua provided by RyzenAPI
-- Game: Hood: Outlaws & Legends

-- MAIN APPLICATION
addappid(927350)
addappid(1481490)
addappid(1492020)
addappid(1670390)
addappid(1670391)
addappid(1670392)
addappid(1677070)
addappid(1731600)

-- MAIN APP DEPOTS / PACKAGES
addappid(927351,0,"71791384496321f5d17e348a819dcae9a8f9137fed669431d7ccaf64df7804ad")

