-- Lua provided by RyzenAPI
-- Game: 927350

-- MAIN APPLICATION
addappid(927350)
-- Game: addappid(927350)

-- MAIN APP DEPOTS / PACKAGES
addappid(927351, 1, "71791384496321f5d17e348a819dcae9a8f9137fed669431d7ccaf64df7804ad")
