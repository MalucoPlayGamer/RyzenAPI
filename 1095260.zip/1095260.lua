-- Lua provided by RyzenAPI
-- Game: Airtight City 1.0

-- MAIN APPLICATION
addappid(1095260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095265,0,"2761a1c3fd5aabc5870e764570680ea0b28282ede455d5a2bec8f86d309c1be8")

