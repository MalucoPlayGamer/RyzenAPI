-- Lua provided by SkyAPI 
-- Game: AppID 1240980
addappid(1240980)
addappid(1240981, 1, "a337d8f4ecca1f0b7c77d281106bdb8d73adf7122b1b65bab6aec9aece53dfd1")
addappid(1240982, 1, "e965d20bf2437a6900431823975de9b2d9fc946b2203ada51a26efe99ffc5c5f")
addappid(1240983, 1, "3e2a14821b74fad334a63d8d31023adf528059115dc688ec550799cdedcfa33c")
