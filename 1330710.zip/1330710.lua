-- Lua provided by RyzenAPI
-- Game: Fraulein Lolita~First Date With You~

-- MAIN APPLICATION
addappid(1330710)
-- Game: addappid(1330710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330711, 1, "b24fdc8ab5c34295a83b8f41aaf0e74024f8c335d251db0ff6d7d1dd00e1d9ae")
