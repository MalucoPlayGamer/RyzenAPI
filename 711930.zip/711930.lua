-- Lua provided by RyzenAPI
-- Game: Square Head Zombies - FPS Game

-- MAIN APPLICATION
addappid(711930)

-- MAIN APP DEPOTS / PACKAGES
addappid(711931, 1, "638c5d719386e6c5606a916b3d45a62872ada70ed86becef56b8c98fca3f9429")

