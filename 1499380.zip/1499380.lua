-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Time Fantasy: Winter Tiles

-- MAIN APPLICATION
addappid(1499380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499380,0,"4fbf924559915ca71261930a5e597d0f7f35a8ab3a545b00831442674134eadf")

