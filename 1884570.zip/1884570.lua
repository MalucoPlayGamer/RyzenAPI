-- Lua provided by SkyAPI 
-- Game: The Gallery
addappid(1884570)
addappid(1884571, 1, "17582b67dcc0262c531bc58fad1ef0b4bd3a39b01a88842bfe40cedbef4b7a6a")
