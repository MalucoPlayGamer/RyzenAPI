-- Lua provided by RyzenAPI
-- Game: addappid(1884570)

-- MAIN APPLICATION
addappid(1884570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884571, 1, "17582b67dcc0262c531bc58fad1ef0b4bd3a39b01a88842bfe40cedbef4b7a6a")
