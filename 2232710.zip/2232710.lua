-- Lua provided by RyzenAPI
-- Game: 2232710

-- MAIN APPLICATION
addappid(2232710)
-- Game: addappid(2232710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232711, 1, "997ea328ee24073665de670535dd2c2c60f71c28639554e7feb75d0bf205c91c")
addappid(2232712, 1, "0ca06a7fffa51be0a04a2ab7f815a00dd5d5ac5b0371f7f424aacf24539d6ca1")
