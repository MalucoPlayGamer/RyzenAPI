-- Lua provided by RyzenAPI
-- Game: 3582020

-- MAIN APPLICATION
addappid(3582020)
-- Game: addappid(3582020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582021, 1, "6187cae89320d1cff23ba2c53318e48926b606c18be20a69436a3359dda5d462")
