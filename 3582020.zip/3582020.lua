-- Lua provided by SkyAPI 
-- Game: EvilSlayer
addappid(3582020)
addappid(3582021, 1, "6187cae89320d1cff23ba2c53318e48926b606c18be20a69436a3359dda5d462")
