-- Lua provided by RyzenAPI
-- Game: addappid(1528080)

-- MAIN APPLICATION
addappid(1528080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528081, 1, "6354be2d808701e66fa44f345d7a1d83ac2755050cff509fac6375a896016ce2")
