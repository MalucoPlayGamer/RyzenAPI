-- Lua provided by RyzenAPI
-- Game: Spider Roulette

-- MAIN APPLICATION
addappid(3900650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3900651,0,"dfcff8d2fc50aff51096d46a49e91eb18f6c22ee84d1e00b93f0c6645f6f88a5")

