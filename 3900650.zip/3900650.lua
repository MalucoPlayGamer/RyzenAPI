-- Lua provided by RyzenAPI
-- Game: Spider Roulette

-- MAIN APPLICATION
addappid(3900650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3900651,0,"dfcff8d2fc50aff51096d46a49e91eb18f6c22ee84d1e00b93f0c6645f6f88a5")
addappid(3900651,0,"dfcff8d2fc50aff51096d46a49e91eb18f6c22ee84d1e00b93f0c6645f6f88a5") -- Main



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
