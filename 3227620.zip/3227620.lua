-- Lua provided by RyzenAPI
-- Game: 诸神竞技场 Playtest

-- MAIN APPLICATION
addappid(3227620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227623,0,"2c86d92e1c13afe69b250dfea1f7a10ed178ca27c231339b679851f5d9c6df84")

