-- Lua provided by RyzenAPI
-- Game: Somewhere inside

-- MAIN APPLICATION
addappid(1178200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178201, 1, "8ebd17c9a917ee4d6fe70f06192618d6451a06d752e09d86ffd4f6b653f1d638")
