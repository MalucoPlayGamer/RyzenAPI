-- Lua provided by RyzenAPI
-- Game: Somewhere inside

-- MAIN APPLICATION
addappid(1178200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178201, 1, "8ebd17c9a917ee4d6fe70f06192618d6451a06d752e09d86ffd4f6b653f1d638")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
