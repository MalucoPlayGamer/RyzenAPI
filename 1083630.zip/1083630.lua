-- Lua provided by RyzenAPI
-- Game: AppID 1083630

-- MAIN APPLICATION
addappid(1083630)
-- Game: addappid(1083630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083631, 1, "8b14218eddc10baea795a124ab603dcbc777b34be1899c698146751ce9253a76")
