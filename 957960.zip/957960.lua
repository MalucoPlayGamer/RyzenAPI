-- Lua provided by RyzenAPI
-- Game: addappid(957960)

-- MAIN APPLICATION
addappid(957960)

-- MAIN APP DEPOTS / PACKAGES
addappid(957961, 1, "0e6ccded358e7330b1e2573ebdd3da24b2ff69380da51090e97faafe1b3684ae")
addappid(957962, 1, "761b2a202e2ce7b6095bbedc33209611ae05da6e6a7cd807a23e19e672b76cab")
addappid(2223510, 0, "325342862eafdb53827450d169a3ecb3c074776ce3e4d09701bcf902176d8a48")
