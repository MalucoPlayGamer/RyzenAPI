-- Lua provided by RyzenAPI
-- Game: Typoman

-- MAIN APPLICATION
addappid(336240)

-- MAIN APP DEPOTS / PACKAGES
addappid(336241, 1, "db7eb78d1bb90b78097dd8edf6f282194f80e1cb0841224749676c15a10fc635")
