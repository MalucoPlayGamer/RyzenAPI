-- Lua provided by RyzenAPI
-- Game: Dicey Tales

-- MAIN APPLICATION
addappid(3279980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279981, 1, "01f3d636d8d7a663adfaaa0298fd74ddb29cf137c7daf4be3f9965ce77707591")

