-- Lua provided by RyzenAPI 
-- Game: AppID 1138910
addappid(1138910)
addappid(1138911, 1, "713b8f5e0f2b981fde8f94d4ab40e76cabd2d8a3ea701e8d993c624224985c26")
