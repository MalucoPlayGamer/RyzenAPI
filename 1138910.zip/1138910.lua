-- Lua provided by RyzenAPI
-- Game: Escape Mind

-- MAIN APPLICATION
addappid(1138910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1138911, 1, "713b8f5e0f2b981fde8f94d4ab40e76cabd2d8a3ea701e8d993c624224985c26")
