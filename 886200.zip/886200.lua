-- Lua provided by RyzenAPI
-- Game: EndCycle VS

-- MAIN APPLICATION
addappid(886200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(886201, 1, "3fd46d4965876589a10131494449f888bf0df286d5f7b137e46f52c45568cb50")

