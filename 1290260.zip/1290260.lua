-- Lua provided by RyzenAPI
-- Game: AppID 1290260

-- MAIN APPLICATION
addappid(1290260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290261, 1, "29a505bf13efb8d0057a2775bbe44884701211624bc85057756b641bd32f4dd3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1329100)
