-- Lua provided by RyzenAPI
-- Game: addappid(2207410)

-- MAIN APPLICATION
addappid(2207410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207411, 1, "b84893f2dc828049207b33aef62d3db55328fd83f83ed1413ab885c457da77e2")
