-- Lua provided by SkyAPI 
-- Game: AppID 2207410
addappid(2207410)
addappid(2207411, 1, "b84893f2dc828049207b33aef62d3db55328fd83f83ed1413ab885c457da77e2")
