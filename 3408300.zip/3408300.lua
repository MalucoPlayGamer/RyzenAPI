-- Lua provided by RyzenAPI
-- Game: Running UP

-- MAIN APPLICATION
addappid(3408300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3408301, 1, "eec647bf724a7ccb02a8f2229aac94a6016772abf71d405b464f490bc8c8b8a2")
