-- Lua provided by RyzenAPI 
-- Game: AppID 3408300
addappid(3408300)
addappid(3408301, 1, "eec647bf724a7ccb02a8f2229aac94a6016772abf71d405b464f490bc8c8b8a2")
