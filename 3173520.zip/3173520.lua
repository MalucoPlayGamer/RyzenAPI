-- Lua provided by RyzenAPI 
-- Game: AppID 3173520
addappid(3173520)
addappid(3173521, 1, "29f3525494df7b15464cc843fc58f017390b35ca6f186f0b225464a19d0dde74")
