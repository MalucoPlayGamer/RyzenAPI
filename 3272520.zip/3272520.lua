-- Lua provided by RyzenAPI
-- Game: BrokenLore: LOW DEMO

-- MAIN APPLICATION
addappid(3272520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272521, 1, "111537a10681861b245a21533c0968f91df9dfff7cf75a6f02fec924ffe3534b")

