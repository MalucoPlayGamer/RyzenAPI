-- Lua provided by SkyAPI 
-- Game: BrokenLore: LOW DEMO
addappid(3272520)
addappid(3272521, 1, "111537a10681861b245a21533c0968f91df9dfff7cf75a6f02fec924ffe3534b")
