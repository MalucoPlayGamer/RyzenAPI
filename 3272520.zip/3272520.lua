-- Lua provided by RyzenAPI
-- Game: 3272520

-- MAIN APPLICATION
addappid(3272520)
-- Game: addappid(3272520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272521, 1, "111537a10681861b245a21533c0968f91df9dfff7cf75a6f02fec924ffe3534b")
