-- Lua provided by RyzenAPI
-- Game: 2826090

-- MAIN APPLICATION
addappid(2826090)
-- Game: addappid(2826090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2826091, 1, "43468abdff7cf5949911e8a739420a44a12bcfbf0f90eccab0f77e3fbb63b066")
