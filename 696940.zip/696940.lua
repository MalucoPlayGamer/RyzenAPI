-- Lua provided by RyzenAPI
-- Game: DreamWorks Voltron VR Chronicles

-- MAIN APPLICATION
addappid(696940)

-- MAIN APP DEPOTS / PACKAGES
addappid(696941,0,"ed224bd454e594c421486a255ab3e03c802cc118c18b4ebe69f3388d8569b1ba")

