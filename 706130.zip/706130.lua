-- Lua provided by RyzenAPI
-- Game: Game: Far from Noise

-- MAIN APPLICATION
addappid(706130)
addappid(757980)
-- Game: addappid(706130)

-- MAIN APP DEPOTS / PACKAGES
addappid(706131, 1, "e191926a897df2db763f0122a495e78e286ccf28c939e5316ad6ea4a00f9c945")
addappid(706132, 1, "f609ef65d41cc6445e51a9e31fc5f1987ed9207d0039266efea9dd8526100ef2")
