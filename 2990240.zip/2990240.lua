-- Lua provided by RyzenAPI
-- Game: E-TECH SIMULATOR

-- MAIN APPLICATION
addappid(2990240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990241, 1, "966a3849e31059e5c59644cc35c4c8aa20cb8b083f77d506981b9d1afb8ad27d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
