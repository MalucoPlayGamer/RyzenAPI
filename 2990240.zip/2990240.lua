-- Lua provided by SkyAPI 
-- Game: E-TECH SIMULATOR
addappid(2990240)
addappid(2990241, 1, "966a3849e31059e5c59644cc35c4c8aa20cb8b083f77d506981b9d1afb8ad27d")
