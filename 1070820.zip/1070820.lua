-- Lua provided by RyzenAPI
-- Game: addappid(1070820)

-- MAIN APPLICATION
addappid(1070820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070821, 1, "0c7454467333a76c1b97fad30e617269a6ff5dcf83ef5d664d9873b5dbf77d14")
