-- Lua provided by RyzenAPI
-- Game: Game: SEX with HITLER 2

-- MAIN APPLICATION
addappid(2194810)
-- Game: addappid(2194810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194811, 1, "b9e4f1facce2925a8594dd2e89bb1619e6db42808a4182f9c1208045f06b840e")
