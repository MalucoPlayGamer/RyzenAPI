-- Lua provided by RyzenAPI
-- Game: Game: AppID 962170

-- MAIN APPLICATION
addappid(962170)
-- Game: addappid(962170)

-- MAIN APP DEPOTS / PACKAGES
addappid(962171, 1, "38a94f12426e70d0c1dfb67a7e2f744864eb6c1ba5eac2510bce265a94c73d39")
