-- Lua provided by RyzenAPI 
-- Game: Bug Battle
addappid(752000)
addappid(752001, 1, "2c899ca6315c8ea52a54be1fe91593a32507790d18a7f2d2bbad462db86389e9")
