-- Lua provided by RyzenAPI
-- Game: Bug Battle

-- MAIN APPLICATION
addappid(752000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(752001, 1, "2c899ca6315c8ea52a54be1fe91593a32507790d18a7f2d2bbad462db86389e9")

