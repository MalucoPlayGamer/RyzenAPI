-- Lua provided by SkyAPI 
-- Game: RPG Alchemy
addappid(2445700)
addappid(2445701, 1, "8352dff71e749418960daad0d30c471832b975d14ed30c0d24480d05c000933e")
addappid(2445702, 1, "aa210fe42184843ab52690196868b9d6b5f86e59bd0df6ae40ceefb3fffb13a3")
addappid(2445703, 1, "f468f56c7fc58c0674e9c6a5fa247d923ee0ffc7bebd99ab7afd5f8479fa4933")
