-- Lua provided by RyzenAPI
-- Game: Game: Trine 3: The Artifacts of Power Soundtrack

-- MAIN APPLICATION
addappid(1227410)
-- Game: addappid(1227410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227411, 1, "41323a06bd457eb47d12169dbadf0b9764195b5eda489d6d29de8af541a7932f")
addappid(1227412, 1, "0d1535dd738a34fdacdc9956c0639b770beeabc2520b8e616c34c12925cbf344")
