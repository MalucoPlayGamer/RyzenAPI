-- Lua provided by RyzenAPI
-- Game: King Arthur: Fallen Champions

-- MAIN APPLICATION
addappid(24460)

-- MAIN APP DEPOTS / PACKAGES
addappid(24461, 1, "ee414393edf8a8e08d925a4fb413682f7908ae2366b79ba2ae73fc58d4eb0b05")
addappid(24462, 1, "5eb4c45d3a666035f3ccc1d9f56ca36432850de818aafb76673543ef015224cb")
addappid(24463, 1, "3a9e1b41e7af1b494bc5dbe174d62442d73264836a6b41848e3f61e3a801bfed")
addappid(24464, 1, "298493cbec87ce17b16c45a4b7ea125b969cdd10fd1585499abd306178135185")
addappid(24465, 1, "4d81b320a13301e69f517d8df9cb860dc7eed569df09efffcda17c9938799328")

