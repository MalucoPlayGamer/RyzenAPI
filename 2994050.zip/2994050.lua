-- Lua provided by RyzenAPI
-- Game: GladMort

-- MAIN APPLICATION
addappid(2994050)
-- Game: addappid(2994050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994051, 1, "71b9458ee70fe4c5eada50a8f2a16bbea9c574cbd423410bb80fc890f086836b")
