-- Lua provided by RyzenAPI
-- Game: addappid(1894680)

-- MAIN APPLICATION
addappid(1894680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894681, 1, "0c04766b10424b9898c2e3384a864ff04f6d821f4014fdce014358b8b5cdcde4")
