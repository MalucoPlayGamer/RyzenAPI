-- Lua provided by RyzenAPI
-- Game: Plague M.D.

-- MAIN APPLICATION
addappid(1423780)
addappid(1423781)
addappid(1423782)
addappid(1423783)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423785,0,"32bd6157a46bdda2da5a21f25ebf8ea315d5d63b5638eff3ad5d4dbd02cc25d0")

