-- Lua provided by RyzenAPI
-- Game: 589370

-- MAIN APPLICATION
addappid(589370)
-- Game: addappid(589370)

-- MAIN APP DEPOTS / PACKAGES
addappid(589371, 1, "b4ec93a4e6a17ec63f4a2813c0646e5a849a9a08e35b24386956d8372bda74b4")
