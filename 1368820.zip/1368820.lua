-- Lua provided by RyzenAPI
-- Game: RollerCoaster Tycoon® 3: Complete Edition

-- MAIN APPLICATION
addappid(1368820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1368821, 1, "f0743d378ea2b0ec9a037ce889330cec3dbfe17982142a7ab26f82427d081faf")
addappid(1368822, 1, "8015b2ef9ac9ed50d5029b603d2d802cf5244ac035c4a109e4f95ca47f7fc604")

