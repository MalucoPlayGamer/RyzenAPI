-- Lua provided by RyzenAPI
-- Game: Nour: Play with Your Food

-- MAIN APPLICATION
addappid(1141050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141052,0,"8cabaee6cec924168eda349fe3c7bdfe15893a49a28f501e1ad9d530157d7fb9")
