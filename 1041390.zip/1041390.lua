-- Lua provided by RyzenAPI
-- Game: Game: AppID 1041390

-- MAIN APPLICATION
addappid(1041390)
-- Game: addappid(1041390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041391, 1, "1d6896e6291aedb716c0d962a3ee3b4f1b66e8d74eb2e9780ae2a0ed2736498e")
