-- Lua provided by RyzenAPI
-- Game: Call of Juarez Gunslinger

-- MAIN APPLICATION
addappid(204450)

-- MAIN APP DEPOTS / PACKAGES
addappid(204451, 1, "3d148329ddf232af3fb18f4858b48bb6996f9ad8e772fd2c704514914bf422d9")
addappid(204452, 1, "8e9a42fdf74eee72bfa07718ed0ae0aef8cb3566eb7493a64f15977ca7683ded")
addappid(204453, 1, "8831bf46c3566b71a12f27a27e95fd784a2485c1d51d3e4ae59c0b0c58c640b2")
addappid(204454, 1, "707c61aedb78b4c745d9030527750bd9ed00d3004bc8344257ccacf41190b701")

