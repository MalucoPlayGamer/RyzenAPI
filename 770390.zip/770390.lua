-- Lua provided by RyzenAPI
-- Game: Game: Draugen

-- MAIN APPLICATION
addappid(770390)
-- Game: addappid(770390)

-- MAIN APP DEPOTS / PACKAGES
addappid(770391, 1, "f757a757608e43c5623283f1fdc1f6950a3f38c8bb607fb8795915cda80c2076")
addappid(1080001, 0, "3dc2a304dc206f97202b481dd6cfbbba88979a4ad58c1659f96cf4c6b991640c")
