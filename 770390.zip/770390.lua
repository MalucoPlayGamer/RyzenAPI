-- Lua provided by RyzenAPI
-- Game: Draugen

-- MAIN APPLICATION
addappid(770390)
addappid(1080002)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(770391, 1, "f757a757608e43c5623283f1fdc1f6950a3f38c8bb607fb8795915cda80c2076")
addappid(1080001, 0, "3dc2a304dc206f97202b481dd6cfbbba88979a4ad58c1659f96cf4c6b991640c")

