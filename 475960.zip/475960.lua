-- Lua provided by SkyAPI 
-- Game: Bombslinger
addappid(475960)
addappid(475961, 1, "82b2003b9edf953d22f241e8d447ff415a6a780f4fb8cb32c970bd5e38109c02")
