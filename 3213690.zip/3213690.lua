-- Lua provided by RyzenAPI
-- Game: addappid(3213690)

-- MAIN APPLICATION
addappid(3213690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213691, 1, "a8fcadf40a9c2180b878045ddb9e35d575ee71c6b49221e980c14cc52f81e02e")
