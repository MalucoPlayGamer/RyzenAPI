-- Lua provided by RyzenAPI
-- Game: 3713820

-- MAIN APPLICATION
addappid(3713820)
-- Game: addappid(3713820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3713821, 1, "40e8ed832df0950eaa6658c8dd5c5f578253ccd01c8ac47e8886da572a1a1d68")
