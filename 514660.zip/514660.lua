-- Lua provided by RyzenAPI
-- Game: BitMaster

-- MAIN APPLICATION
addappid(514660)
-- Game: addappid(514660)

-- MAIN APP DEPOTS / PACKAGES
addappid(514661, 1, "3baa224300fc05338d3024368746fbaefee3d25702c9741629d96d9fb72805b2")
addappid(514662, 1, "97e9fafdcb32d4577ec588584c3dce43af9fa9e2a66c0433c69b6a687561f297")
addappid(514663, 1, "9192aa220f016cafd43d3cd1568f35a6ee369f25f6c0a72d499f3b89caf5b1ad")
addappid(514664, 1, "b75b73d68fab2c0c3d881388765280123aaad5ae6bf0927bc21079ebcb39466e")
