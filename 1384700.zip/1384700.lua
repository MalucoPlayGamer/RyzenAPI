-- Lua provided by RyzenAPI
-- Game: 1384700

-- MAIN APPLICATION
addappid(1384700)
-- Game: addappid(1384700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384701, 1, "e56ce9e9d1f431d099186c05e959e157ea193e161922b181824f842dcc8e4c0e")
