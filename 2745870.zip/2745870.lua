-- Lua provided by RyzenAPI
-- Game: Warfare Legacy Collection

-- MAIN APPLICATION
addappid(2745870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2745872,0,"f5a085e32e34ccaeb23a7ff848257ce0d2056f217fea1111690e021f424ee246")

