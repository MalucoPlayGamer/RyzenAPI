-- Lua provided by RyzenAPI 
-- Game: AppID 530040
addappid(530040)
addappid(530041, 1, "fd957ba6b0886649915ea2fcbd145c782506d2d5940735cfe4125539632025b8")
