-- Lua provided by RyzenAPI
-- Game: 329280

-- MAIN APPLICATION
addappid(228989)
addappid(229004)
addappid(329280)
addappid(329283)
-- Game: addappid(329280)

-- MAIN APP DEPOTS / PACKAGES
addappid(329282,0,"9b6087b25db9f5c357826a9a51c029fe79e19bdff741228886c24123e8a8a404")
