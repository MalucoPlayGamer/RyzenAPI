-- Lua provided by RyzenAPI 
-- Game: TIEBREAK – GRAND SLAM EDITION
addappid(2264340)
addappid(2264341, 1, "4286325b17c5981d0b1dc904cdf038ef362a76ab886955f99b02a088703be8d2")
