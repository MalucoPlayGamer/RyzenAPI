-- Lua provided by RyzenAPI
-- Game: NB Desktop

-- MAIN APPLICATION
addappid(1064820)
addappid(1089582)
-- Game: addappid(1064820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064821, 1, "5f17b9a2945d0bf97d2dbef5454ef82b234cd8bf47bacc58ad86e59f4411fa9f")
addappid(1089580, 0, "d2f7a55e3e3eff44db0ab9620870c9e039c8b550a70a671f38de95253f7de14f")
addappid(1089581, 0, "f7a4dd819b24e4ad78dcbbbf837118d7795e008d537891ab9c7d9c1b4feeec4f")
addappid(1104810, 0, "b3ed5ab4f24cd8662de3596dc6f3323f1ff19a9c325c621113f035993fed8616")
