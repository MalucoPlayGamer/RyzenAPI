-- Lua provided by RyzenAPI 
-- Game: Cardrottini
addappid(3723480)
addappid(3723481, 1, "c0fa9fb9337781565c18e88f767b98d60d8b3c057315fb1291acb0b37ec85538")
