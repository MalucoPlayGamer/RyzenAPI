-- Lua provided by RyzenAPI
-- Game: Cardrottini

-- MAIN APPLICATION
addappid(3723480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3723481, 1, "c0fa9fb9337781565c18e88f767b98d60d8b3c057315fb1291acb0b37ec85538")

