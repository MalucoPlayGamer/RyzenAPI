-- Lua provided by RyzenAPI
-- Game: Fantasy Blacksmith

-- MAIN APPLICATION
addappid(959520)

-- MAIN APP DEPOTS / PACKAGES
addappid(959521, 1, "6e8366cf6575c8b59141d75d329dd23c039877b9da4aea4a7b4aabe311665e82")
addappid(1196730, 0, "0dd43486373ded098e7582e4f61e903a961ff40337e46a068c0110aded758e18")
addappid(1224410, 0, "37810464c5529acc6a93b1a621fcf728b6996bda9db41c23c21a806600f58740")
addappid(1591070, 0, "0958a015b81848ef67bdde31f4cc81f8e1876c3372169b2558ce28f627b1b97e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
