-- Lua provided by RyzenAPI
-- Game: Machinist

-- MAIN APPLICATION
addappid(1265510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265511, 1, "f1470501ed2dff104c3410ba0a3f5758a6e9b4d3a7454ae969b2f76832814894")
