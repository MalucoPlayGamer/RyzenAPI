-- Lua provided by RyzenAPI
-- Game: AppID 1500650

-- MAIN APPLICATION
addappid(1500650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500651, 1, "cba8028e839a09792238faaa905d66166dafa5af67b2596ed1face55c7c9ea21")
