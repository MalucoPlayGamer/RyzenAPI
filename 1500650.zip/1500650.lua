-- Lua provided by RyzenAPI
-- Game: Cyber Waifu

-- MAIN APPLICATION
addappid(1500650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1500651, 1, "cba8028e839a09792238faaa905d66166dafa5af67b2596ed1face55c7c9ea21")
