-- Lua provided by RyzenAPI
-- Game: Voice Love on Air

-- MAIN APPLICATION
addappid(2321120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321121, 1, "1d7072e2c9d2388fa7e05e5bab9ca43ec79cdc2d3270c3de29886d6fff26fc70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2875420)
addappid(3052430)
addappid(3058340)
