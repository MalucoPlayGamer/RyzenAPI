-- Lua provided by RyzenAPI
-- Game: Game: Voice Love on Air

-- MAIN APPLICATION
addappid(2321120)
-- Game: addappid(2321120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321121, 1, "1d7072e2c9d2388fa7e05e5bab9ca43ec79cdc2d3270c3de29886d6fff26fc70")
