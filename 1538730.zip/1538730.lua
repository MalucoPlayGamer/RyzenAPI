-- Lua provided by RyzenAPI
-- Game: Pirates: Golden tits: Chapter 1

-- MAIN APPLICATION
addappid(1538730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538731, 1, "2b21bf87e392641e166ac47f77d50de79b9d25c88bdfd52207193e56d0c1c883")
addappid(1577040, 0, "86cb42bbb3d3d16fb40b77d6372908288f3b5e3c3cfedef5f385d7d28b117210")
