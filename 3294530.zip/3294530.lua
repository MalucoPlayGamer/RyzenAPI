-- Lua provided by RyzenAPI
-- Game: Sea Power Soundtrack

-- MAIN APPLICATION
addappid(3294530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3294531, 1, "ebe54af2a513f15ab91528d1b680a1597d6a8ca7828f5e31b9e44abe04f3c5e0")
