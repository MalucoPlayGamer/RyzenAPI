-- Lua provided by RyzenAPI
-- Game: 2432010

-- MAIN APPLICATION
addappid(2432010)
-- Game: addappid(2432010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432011, 1, "9827b94ced91ee521985a1630d35ea6c42430a05b1a56b4151165d1c1d4ceb18")
