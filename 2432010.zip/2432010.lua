-- Lua provided by SkyAPI 
-- Game: The Stranded Traveler
addappid(2432010)
addappid(2432011, 1, "9827b94ced91ee521985a1630d35ea6c42430a05b1a56b4151165d1c1d4ceb18")
