-- Lua provided by RyzenAPI
-- Game: Game: 太公传承

-- MAIN APPLICATION
addappid(2456340)
-- Game: addappid(2456340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456341, 1, "b1b1f63ba8ce090842fdb20de43815fc64981efc0e9c3dc90e2a50c6c8d529e0")
