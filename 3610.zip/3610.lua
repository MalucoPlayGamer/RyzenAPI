-- Lua provided by RyzenAPI
-- Game: 3610

-- MAIN APPLICATION
addappid(3610)
-- Game: addappid(3610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3611, 1, "cc2647edbd06d8236a11b1056efd2fe1e7b249a1d7ce920f41ac199b80c7b3ef")
