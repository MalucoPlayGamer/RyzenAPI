-- Lua provided by RyzenAPI
-- Game: Desert lost

-- MAIN APPLICATION
addappid(1145810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145811, 1, "33a203131b1462b5bbf0501ff2c9bbf3025f3559b12404a30e8a62a4acd5dffe")

