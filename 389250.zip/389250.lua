-- Lua provided by RyzenAPI
-- Game: Planet Alcatraz 2

-- MAIN APPLICATION
addappid(389250)

-- MAIN APP DEPOTS / PACKAGES
addappid(389251, 1, "10bbf2e9c200259d5a931d3235217063e185258cc2088a907d5c18d36a11ada7")

