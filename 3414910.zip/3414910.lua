-- Lua provided by RyzenAPI
-- Game: Game: Hentai Tales: Saimin Kouhai

-- MAIN APPLICATION
addappid(3414910)
-- Game: addappid(3414910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3414911, 1, "96b6334ff840b45cb6e311e1b7e452a8dfa1574a8cf85b50f204ffd984cae5de")
