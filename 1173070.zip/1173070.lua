-- Lua provided by RyzenAPI 
-- Game: AppID 1173070
addappid(1173070)
addappid(1173071, 1, "1899f6f8720bde4cf05864e4fa05794b974853e21e4e433d11687dd3b97828c8")
