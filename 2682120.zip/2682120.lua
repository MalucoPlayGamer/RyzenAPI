-- Lua provided by RyzenAPI
-- Game: Movie Cinema Simulator

-- MAIN APPLICATION
addappid(2682120)
-- Game: addappid(2682120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682121, 1, "3cc68d260deb9bb026c2c38517e9257980ff4a7975de91222eacd1ca5e40f4d5")
