-- Lua provided by RyzenAPI
-- Game: 23360

-- MAIN APPLICATION
addappid(23360)
-- Game: addappid(23360)

-- MAIN APP DEPOTS / PACKAGES
addappid(23391,0,"69bf246191f67e5c2cf6c0b525f2c537b56dcb6860af118eaf00b2bc12fc6f5d")
addappid(23392,0,"66a5637eafc69ae41f04383b878950cd7828d76223d741fd1f025dc61e542c61")
