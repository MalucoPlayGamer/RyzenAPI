-- Lua provided by RyzenAPI
-- Game: AppID 1751350

-- MAIN APPLICATION
addappid(1751350)
-- Game: addappid(1751350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751351, 1, "08c5703f14d4902ee7635dcebbd61ae48181662b030632e0209284fae026cef3")
