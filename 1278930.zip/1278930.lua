-- Lua provided by RyzenAPI
-- Game: Math Puzzle Alpha Challenge

-- MAIN APPLICATION
addappid(1278930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278931, 1, "b746b43da337c6d592089dae96ba143bade3347ad35fe466a156a702fd05ad32")
addappid(1278932, 1, "9e498320ed2d171a88e807857d03e0841224067d053dc9b49cc0a9f77b1a3977")
