-- Lua provided by RyzenAPI
-- Game: Game: AppID 1067220

-- MAIN APPLICATION
addappid(1067220)
-- Game: addappid(1067220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067221, 1, "1eae7ce4263eaed8a212b98b83371bb26a0a1ec3bd6633173dc0e7399b7abeba")
