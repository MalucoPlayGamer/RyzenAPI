-- Lua provided by SkyAPI 
-- Game: AppID 227380
addappid(227380)
addappid(227381, 1, "c7ce105bc70843db66ce37e9b9f410288ad8cb54e485b37a182854a325b66e77")
