-- Lua provided by RyzenAPI
-- Game: 227380

-- MAIN APPLICATION
addappid(227380)
-- Game: addappid(227380)

-- MAIN APP DEPOTS / PACKAGES
addappid(227381, 1, "c7ce105bc70843db66ce37e9b9f410288ad8cb54e485b37a182854a325b66e77")
