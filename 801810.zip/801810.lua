-- Lua provided by RyzenAPI
-- Game: addappid(801810)

-- MAIN APPLICATION
addappid(801810)

-- MAIN APP DEPOTS / PACKAGES
addappid(801811, 1, "b430280616e51f964823890814bb41d08b70fd76ffbc821b14eb869b254dc5fc")
