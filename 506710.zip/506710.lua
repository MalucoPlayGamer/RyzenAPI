-- Lua provided by RyzenAPI
-- Game: The Colony: New Haven Chronicles

-- MAIN APPLICATION
addappid(506710)

-- MAIN APP DEPOTS / PACKAGES
addappid(506712,0,"627e4b0744d8a0e75fe97927c374b59eaa3f9576c8e7e9e5f63982bea60e238d")

