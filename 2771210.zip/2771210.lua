-- Lua provided by RyzenAPI 
-- Game: AppID 2771210
addappid(2771210)
addappid(2771211, 1, "367613faeb43282c10b340d1779b303f524cd999c6f8f6e55a5abb5db4006b18")
