-- Lua provided by RyzenAPI
-- Game: Xeno Crisis

-- MAIN APPLICATION
addappid(464260)

-- MAIN APP DEPOTS / PACKAGES
addappid(464261, 1, "d801bd0546ccaae97d61bc67a496be02b9e2fd62ed960036da8f56b000387eb5")
addappid(464262, 1, "03ab4b3f7d908a617faca7c758efee2be104de3625ca7c0518adec0414ced598")
addappid(464263, 1, "ff230b8a6f87de7e2909f21073e2c474e3a8b522f40b2f78fcc866855280c93d")
addappid(464264, 1, "311f9da568c9d90bf888e89cdafa2b450552790be62c8e42088f55b0af7900e9")

