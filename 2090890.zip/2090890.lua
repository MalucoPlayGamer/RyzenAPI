-- Lua provided by SkyAPI 
-- Game: Protect Harem City
addappid(2090890)
addappid(2090891, 1, "be66a9cacd044e65dfebe55495b4d7c7d5d15f45907cd0280a7a135ab4b57636")
