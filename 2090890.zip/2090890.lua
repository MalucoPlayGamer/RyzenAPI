-- Lua provided by RyzenAPI
-- Game: Game: Protect Harem City

-- MAIN APPLICATION
addappid(2090890)
-- Game: addappid(2090890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090891, 1, "be66a9cacd044e65dfebe55495b4d7c7d5d15f45907cd0280a7a135ab4b57636")
