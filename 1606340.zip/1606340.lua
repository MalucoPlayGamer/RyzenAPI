-- Lua provided by RyzenAPI 
-- Game: Conquest of Elysium 5
addappid(1606340)
addappid(1606341, 1, "7a22035b823185729e24f6d700fa9d264fba6a5b56e114430c039f334851af85")
