-- Lua provided by RyzenAPI
-- Game: Conquest of Elysium 5

-- MAIN APPLICATION
addappid(1606340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(1606341, 1, "7a22035b823185729e24f6d700fa9d264fba6a5b56e114430c039f334851af85")

