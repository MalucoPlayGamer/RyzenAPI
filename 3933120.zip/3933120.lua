-- Lua provided by RyzenAPI
-- Game: CiniCross

-- MAIN APPLICATION
addappid(3933120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3933121,0,"b04a673aff0ff804c2fb9aed3a304c0082e4f29194016a9a538e726689162bed")

