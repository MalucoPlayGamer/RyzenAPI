-- Lua provided by RyzenAPI
-- Game: Subside

-- MAIN APPLICATION
addappid(2550040)
addappid(4550750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550041, 1, "99dcfc759e2a003f97270e048ead11eee26ec0aabafcf096b3d72676faf8d27e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
