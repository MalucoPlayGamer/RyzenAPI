-- Lua provided by RyzenAPI
-- Game: Subside

-- MAIN APPLICATION
addappid(2550040)
addappid(4550750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550041, 1, "99dcfc759e2a003f97270e048ead11eee26ec0aabafcf096b3d72676faf8d27e")

