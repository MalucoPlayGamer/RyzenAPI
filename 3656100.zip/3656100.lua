-- Lua provided by RyzenAPI
-- Game: ShootX

-- MAIN APPLICATION
addappid(3656100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3656101, 1, "720ba191837514882f2ff11a18a97c71d81e15ad57304c26a2ea5a30ae8a2732")

