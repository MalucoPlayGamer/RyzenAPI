-- Lua provided by RyzenAPI
-- Game: ShootX

-- MAIN APPLICATION
addappid(3656100)
-- Game: addappid(3656100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3656101, 1, "720ba191837514882f2ff11a18a97c71d81e15ad57304c26a2ea5a30ae8a2732")
