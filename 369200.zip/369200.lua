-- Lua provided by RyzenAPI
-- Game: Game: AppID 369200

-- MAIN APPLICATION
addappid(369200)
addappid(412330)
addappid(412331)
addappid(412332)
addappid(412333)
-- Game: addappid(369200)

-- MAIN APP DEPOTS / PACKAGES
addappid(369201, 1, "f9ff39c55500775e3d0cb0240bfe71c82add57bc01eb96b98679ea5cb1fad87d")
