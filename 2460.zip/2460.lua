-- Lua provided by RyzenAPI
-- Game: Bloody Good Time Dedicated Server

-- MAIN APPLICATION
addappid(2460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
addappid(2452,0,"8e17c6b223df2e04eab11586874c1950b3204999174697442ea215c6c58f1966")
addappid(2453,0,"916de5fd91985e2bcff527782be54caa71839708f9b58cefedfe73f7b232e2b2")

