-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1432166)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432166,0,"02baf79221c23f4c1c859ab4b50726af27d4f58ce2b235220f0aa10cb8678194")
