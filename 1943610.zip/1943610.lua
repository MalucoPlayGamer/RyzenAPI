-- Lua provided by RyzenAPI
-- Game: Aero Tales Online: The World - Anime MMORPG

-- MAIN APPLICATION
addappid(1943610)
-- Game: addappid(1943610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943611, 1, "5c8e320787e2c06c5a8b631c4ed4513d80fe27fb3895c99bdb358657948dc14c")
