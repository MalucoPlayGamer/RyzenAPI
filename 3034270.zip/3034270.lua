-- Lua provided by RyzenAPI
-- Game: addappid(3034270)

-- MAIN APPLICATION
addappid(3034270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034271, 1, "8373411373ca417e77fbbd357d3a652b7c0ddca670f7ad86aa886f248b07d537")
