-- Lua provided by RyzenAPI
-- Game: AppID 581970

-- MAIN APPLICATION
addappid(581970)
-- Game: addappid(581970)

-- MAIN APP DEPOTS / PACKAGES
addappid(581971, 1, "f152b9a65ce9400664dd734c04979949c52d0cdd4ac48817b9f04f7ee9bf9ad3")
