-- Lua provided by RyzenAPI
-- Game: An Imp? A Fiend!

-- MAIN APPLICATION
addappid(354960)

-- MAIN APP DEPOTS / PACKAGES
addappid(354961, 1, "2a7b5211da414191d7320efc4149da4c51a04b21821a441e5283bdcd858d3177")
