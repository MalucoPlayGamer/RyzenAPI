-- Lua provided by RyzenAPI
-- Game: 3416980

-- MAIN APPLICATION
addappid(3416980)
-- Game: addappid(3416980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3416981, 1, "45b7266a59f359b83a8b474a4c371ef8855c1cb0432fb4031094fb93bce727f0")
