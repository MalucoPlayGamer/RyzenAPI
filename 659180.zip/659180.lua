-- Lua provided by RyzenAPI
-- Game: Medieval Mystery Match

-- MAIN APPLICATION
addappid(659180)

-- MAIN APP DEPOTS / PACKAGES
addappid(659181,0,"3d86f476364ee93af9a97a88e6b6dd1eede1c9d491d9d5a92b19887a9b0ea7ab")

