-- Lua provided by RyzenAPI 
-- Game: AppID 232090
addappid(232090)
addappid(232091, 1, "f46359be90614cd82464602ee51bc2122dc359d6a493844be3a2edfd2a733be7")
addappid(232092, 1, "4e45d5cae89bca85c7df390c27343ee8c743dd49404f6bb848c900a1a1ef7dcc")
addappid(232093, 1, "15e06cd0dba1b90a3daedffd14e329e4134ec76f3ba808f6f44dc11b32835c0a")
addappid(232094, 1, "ff56a2e376c3a8baddd72e9f22d3c896728aa0846076d76806d96e56e7ff3bec")
