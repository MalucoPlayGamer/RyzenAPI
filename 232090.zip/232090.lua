-- Lua provided by RyzenAPI
-- Game: Killing Floor 2

-- MAIN APPLICATION
addappid(294850) -- KF2 - Mr Foster Dosh Jacket!
addappid(354020) -- KF2 - Digital Deluxe Edition DLC
addappid(360930)
addappid(360931)
addappid(361240) -- KF2 - Full Game
addappid(363760)
addappid(408560) -- KF2 - Alienware DLC
addappid(1368501) -- DLC 1368501
addappid(1368502) -- DLC 1368502
addappid(1368503) -- DLC 1368503
addappid(1524820) -- KF2 - Season Pass 2021
addappid(1914490) -- KF2 - Season Pass 2022
addappid(1914560) -- KF2 - Ultimate Edition Upgrade DLC
addappid(1937240) -- DLC 1937240
addappid(1937241) -- DLC 1937241
addappid(1993760) -- KF2 - Ultimate Edition Upgrade Bundle DLC
addappid(2363410) -- Killing Floor 2 - Cosmetics Season Pass

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(232090, 1, "d50a5c27ad4f493a022571ee34c65609d373b8344825dbe065bff22e893e06e8")
addappid(232091, 1, "f46359be90614cd82464602ee51bc2122dc359d6a493844be3a2edfd2a733be7")
addappid(232092, 1, "4e45d5cae89bca85c7df390c27343ee8c743dd49404f6bb848c900a1a1ef7dcc")
addappid(232093, 1, "15e06cd0dba1b90a3daedffd14e329e4134ec76f3ba808f6f44dc11b32835c0a")
addappid(232094, 1, "ff56a2e376c3a8baddd72e9f22d3c896728aa0846076d76806d96e56e7ff3bec")
addtoken(363760, "10580095351703989210")
addtoken(1368501, "13344653896183276191")
addtoken(1368502, "1461492668364395345")
addtoken(1368503, "7700075408784397171")
addtoken(1937240, "15231710637902033995")

