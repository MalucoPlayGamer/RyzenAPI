-- Lua provided by RyzenAPI
-- Game: Game: NekoMiko

-- MAIN APPLICATION
addappid(969700)
-- Game: addappid(969700)

-- MAIN APP DEPOTS / PACKAGES
addappid(969701, 1, "cce1b0c0934c8c6727d8aee3871b6acd1fed9c098808f7b84173853bd90ad2ed")
