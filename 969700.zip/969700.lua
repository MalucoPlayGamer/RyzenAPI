-- Lua provided by RyzenAPI
-- Game: NekoMiko

-- MAIN APPLICATION
addappid(969700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(969701, 1, "cce1b0c0934c8c6727d8aee3871b6acd1fed9c098808f7b84173853bd90ad2ed")

