-- Lua provided by RyzenAPI
-- Game: addappid(2826440)

-- MAIN APPLICATION
addappid(2826440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2826441, 1, "a087972c772e6c1c4aeebe1fdecedd903184b099e8df1491a15f0d9d077bf753")
