-- 3227240's Lua and Manifest Created by Hubcap Manifest
-- MineGeon: Renegades
-- Created: July 31, 2026 at 00:21:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3227240, 1, "1a63b9269774cd8d8842b035c7fec29367a3f6dfaee29bba4a958daeaea61699") -- MineGeon: Renegades
-- MAIN APP DEPOTS
addappid(3227241, 1, "ff5f7f5718574af232b1d632d3f8aa14c66c0b36add2b5aa44263e2740eb4d73") -- Depot 3227241
setManifestid(3227241, "582137557145835015", 783282652)