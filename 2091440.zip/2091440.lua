-- Lua provided by RyzenAPI
-- Game: Furry Boss - 18+ Adult Only Patch

-- MAIN APPLICATION
addappid(2091440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091440,0,"d067c3bace0acb0ad5b1c0b8df1aed090753177da5d3490a2e14809e92ed495a")

