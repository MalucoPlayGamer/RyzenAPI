-- Lua provided by RyzenAPI
-- Game: 568650

-- MAIN APPLICATION
addappid(568650)
-- Game: addappid(568650)

-- MAIN APP DEPOTS / PACKAGES
addappid(568651, 1, "1fe10ded0844b5e6c1460da5c5cc3909b8929e04d4cc697c1666e9fecf71f1b9")
