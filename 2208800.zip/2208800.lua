-- Lua provided by SkyAPI 
-- Game: AppID 2208800
addappid(2208800)
addappid(2208801, 1, "08735a8a2d7dab298b6670748e9be459e28f870bf359bf326156d16d6f5334f9")
