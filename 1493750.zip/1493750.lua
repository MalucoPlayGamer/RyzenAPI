-- Lua provided by RyzenAPI
-- Game: Evil Dead: The Game

-- MAIN APPLICATION
addappid(1493750) -- Evil Dead: The Game
addappid(1731110) -- Evil Dead The Game - Ash Williams Gallant Knight
addappid(1732950) -- Evil Dead The Game - Ash Williams S-Mart Employee
addappid(2316510) -- Evil Dead The Game - Classics Bundle
addappid(2316520) -- Evil Dead The Game - Army of Darkness Bundle
addappid(2316530) -- Evil Dead The Game - Hail to the King Bundle
addappid(2316540) -- Evil Dead The Game - Immortal Power Bundle
addappid(2316550) -- Evil Dead The Game - 2013 bundle
addappid(2316560) -- Evil Dead The Game - Whos Your Daddy Bundle
addappid(2316570) -- Evil Dead The Game - Savini Variant Skin
addappid(2374110) -- Evil Dead The Game - GOTY Edition Upgrade

-- MAIN APP DEPOTS / PACKAGES
addappid(1493751, 1, "3011c24d44b125bdf6af3f40424f7eb8c58639dca083ec2373e4f6a780f296c7") -- Depot 1493751

