-- Lua provided by RyzenAPI
-- Game: Intravenous

-- MAIN APPLICATION
addappid(1486630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1486631, 1, "b548fd48e03d0ca36cabff4b9b2f94e6633bf7cda791a1055bc6def5c58a776c")

