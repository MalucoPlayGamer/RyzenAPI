-- Lua provided by SkyAPI 
-- Game: Intravenous
addappid(1486630)
addappid(1486631, 1, "b548fd48e03d0ca36cabff4b9b2f94e6633bf7cda791a1055bc6def5c58a776c")
