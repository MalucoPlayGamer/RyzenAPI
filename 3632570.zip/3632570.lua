-- Lua provided by RyzenAPI
-- Game: Gut Eater

-- MAIN APPLICATION
addappid(3632570)
-- Game: addappid(3632570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3632571, 1, "8fd83bbfd6094240062a4c3f5b8855b39266c60e48c3443f5d1c7d4cf6c36bc0")
