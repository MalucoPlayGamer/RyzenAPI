-- Lua provided by RyzenAPI
-- Game: PBA Pro Bowling 2021

-- MAIN APPLICATION
addappid(1415920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415921, 1, "55c1f46d4745d02cdc6466e57157dbbb88f2a266f8f4e58f1e5294d6cffb22cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
