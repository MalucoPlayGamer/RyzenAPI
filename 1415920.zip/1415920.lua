-- Lua provided by RyzenAPI
-- Game: PBA Pro Bowling 2021

-- MAIN APPLICATION
addappid(1415920)
-- Game: addappid(1415920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415921, 1, "55c1f46d4745d02cdc6466e57157dbbb88f2a266f8f4e58f1e5294d6cffb22cf")
