-- Lua provided by RyzenAPI
-- Game: Capcom Fighting Collection

-- MAIN APPLICATION
addappid(1685750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685751, 1, "99b30d263e887d2abba22ead550f7f903db7a4647b9a57b3c5d072e82bb41c55")
addappid(1825790, 0, "6284baf5df92ab607e128879441547d2c27e06d234ed8510106b96098e0d08f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
