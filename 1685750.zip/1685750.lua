-- Lua provided by SkyAPI 
-- Game: Capcom Fighting Collection
addappid(1685750)
addappid(1685751, 1, "99b30d263e887d2abba22ead550f7f903db7a4647b9a57b3c5d072e82bb41c55")
addappid(1825790, 0, "6284baf5df92ab607e128879441547d2c27e06d234ed8510106b96098e0d08f7")
