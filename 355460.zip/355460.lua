-- Lua provided by RyzenAPI 
-- Game: Thunderbird: The Legend Begins
addappid(355460)
addappid(355461, 1, "a719599d9354487cd63a2d0a99763e37ff34746f6a836c6a7c15d162c9e8d8d2")
