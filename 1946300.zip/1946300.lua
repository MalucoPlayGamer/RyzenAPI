-- Lua provided by RyzenAPI
-- Game: Masks Of Deception

-- MAIN APPLICATION
addappid(1946300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946301, 1, "b9b12f9f8073d95822b12d54d24792cee222aba3a8142e70431350dc82dc249a")
