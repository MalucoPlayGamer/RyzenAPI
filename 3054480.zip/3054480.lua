-- Lua provided by RyzenAPI
-- Game: Mech Survivor Elite

-- MAIN APPLICATION
addappid(3054480)
-- Game: addappid(3054480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054481, 1, "fa58c957a516f7a54acf517962ca594226b0c13ab4cb6a830dc19a245486fceb")
