-- Lua provided by RyzenAPI
-- Game: Super Arcade Soccer 2021

-- MAIN APPLICATION
addappid(1256710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1256711, 1, "82ea8aca3ff88922ac0a16ab24a9505092864e1df5263dc9261980208f55750f")

