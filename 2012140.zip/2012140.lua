-- Lua provided by RyzenAPI 
-- Game: AppID 2012140
addappid(2012140)
addappid(2012141, 1, "c1fc8ee0c8ff1653f25c3524caa90af245200058f6f50d468051ece3b832869b")
