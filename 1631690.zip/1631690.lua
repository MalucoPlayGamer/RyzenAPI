-- Lua provided by RyzenAPI
-- Game: addappid(1631690)

-- MAIN APPLICATION
addappid(1631690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631691, 1, "a1f7c23321bd5545cd8eca8b0e44a60b166b6c10621938af3c107ad871240798")
