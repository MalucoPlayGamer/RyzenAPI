-- Lua provided by RyzenAPI
-- Game: Trover Saves the Universe

-- MAIN APPLICATION
addappid(1051200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1051201, 1, "32400332d01c6dc6b17b3ea76db10a769992faecba70c077788ced537c79d231")

