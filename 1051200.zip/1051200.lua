-- Lua provided by RyzenAPI
-- Game: Trover Saves the Universe

-- MAIN APPLICATION
addappid(1051200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051201, 1, "32400332d01c6dc6b17b3ea76db10a769992faecba70c077788ced537c79d231")
