-- Lua provided by RyzenAPI
-- Game: Entropic Decay: Prologue

-- MAIN APPLICATION
addappid(2519880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519881, 1, "d1a95a6f0277a20d8e17c715572847dbe127267c24c4343ae73db34e3655d64a")

