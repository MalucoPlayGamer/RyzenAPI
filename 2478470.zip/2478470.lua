-- Lua provided by RyzenAPI
-- Game: Game: Doomsday

-- MAIN APPLICATION
addappid(2478470)
-- Game: addappid(2478470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478471, 1, "361b5e6eeffa2da595d1c9dfb766a0fcdb4212f7d90b65c7bcd043d4326ffa57")
