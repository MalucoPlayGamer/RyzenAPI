-- Lua provided by RyzenAPI
-- Game: Spaceman Sparkles 2

-- MAIN APPLICATION
addappid(365860)

-- MAIN APP DEPOTS / PACKAGES
addappid(365861, 1, "e0dcb252794b010ed33b92b77655259389d20068623bf71aa41e67e144ab4878")

