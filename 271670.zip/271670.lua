-- Lua provided by RyzenAPI
-- Game: 10 Second Ninja

-- MAIN APPLICATION
addappid(271670)

-- MAIN APP DEPOTS / PACKAGES
addappid(271671, 1, "4a3c90d2130560ccb47d32fa040d676425779577f7b02ac0627a7e3ac8f28133")
