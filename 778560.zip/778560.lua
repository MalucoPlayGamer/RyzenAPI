-- Lua provided by RyzenAPI
-- Game: Game: AppID 778560

-- MAIN APPLICATION
addappid(778560)
-- Game: addappid(778560)

-- MAIN APP DEPOTS / PACKAGES
addappid(778561, 1, "8341b431e89bb649280d62493d7d2c12736b34be8de9d47ae846a14809592048")
