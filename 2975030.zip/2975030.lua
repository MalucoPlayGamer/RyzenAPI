-- Lua provided by RyzenAPI
-- Game: Lust Shot

-- MAIN APPLICATION
addappid(2975030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975031, 1, "b5376faaa3dfbd3d5040efbdc7e544f751d540be86afa609955b5b8e4a254991")

