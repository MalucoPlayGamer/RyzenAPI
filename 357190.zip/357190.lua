-- Lua provided by RyzenAPI
-- Game: addappid(357190)

-- MAIN APPLICATION
addappid(357190)

-- MAIN APP DEPOTS / PACKAGES
addappid(357191, 1, "c855d2a2a022b2f35add948a015356e8fe3c3802195b5507e2bedc3acab1c6bb")
