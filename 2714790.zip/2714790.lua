-- Lua provided by RyzenAPI
-- Game: Peeping Dorm Manager Soundtrack

-- MAIN APPLICATION
addappid(2714790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2714791, 1, "2ab96d79039223c9c1b741a5ce0d39307a486c162f69902ba3a3f8823105e96f")

