-- Lua provided by RyzenAPI
-- Game: Supercar Collection Simulator

-- MAIN APPLICATION
addappid(3453600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453601, 1, "ce8d6b5c4d99db4329aa5baa99ef1de9422793b7c659c2d8474c46aea1e95b8b")

