-- Lua provided by SkyAPI 
-- Game: ButcherBoy
addappid(826160)
addappid(826161, 1, "ffbb8359b7732bb71ae92295626e07f0b16c6998cb33d0db8bf0a4fce5a4faf1")
addappid(826162, 1, "99a9d7a1a8d3fb996f2aaf0445b209af5d746febf4565ca48b86cfd38e27e881")
addappid(826163, 1, "6129a5e0e1b4bce092234c5eece0b022d21832b1b4dd2b2fa8515c57602a73a1")
addappid(826164, 1, "4962cc268cd9a0b9d3a078de8d6685ee10b6b7d6b71a8c74076b142f43934b95")
