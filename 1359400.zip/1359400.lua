-- Lua provided by RyzenAPI
-- Game: 1359400

-- MAIN APPLICATION
addappid(1359400)
-- Game: addappid(1359400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359401, 1, "1b73f4f1df3af50b09edf939689fac26ee67d23e76bc8725278d4391c9aea924")
