-- Lua provided by RyzenAPI
-- Game: Orphans

-- MAIN APPLICATION
addappid(2722400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722401, 1, "9614e79eec1537f48858a0abf22bc642143b423d05c4d9874872cc19eb20507a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
