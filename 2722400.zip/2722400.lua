-- Lua provided by RyzenAPI
-- Game: Game: Orphans

-- MAIN APPLICATION
addappid(2722400)
-- Game: addappid(2722400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722401, 1, "9614e79eec1537f48858a0abf22bc642143b423d05c4d9874872cc19eb20507a")
