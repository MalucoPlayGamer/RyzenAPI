-- Lua provided by RyzenAPI
-- Game: addappid(954530)

-- MAIN APPLICATION
addappid(954530)

-- MAIN APP DEPOTS / PACKAGES
addappid(954531, 1, "cb4159882bb5fed5f16c521a36af58aecd661fd00ad0455dd161f827481adda5")
