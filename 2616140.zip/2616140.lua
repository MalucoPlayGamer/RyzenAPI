-- Lua provided by RyzenAPI
-- Game: addappid(2616140)

-- MAIN APPLICATION
addappid(2616140)
addappid(4437740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616141, 1, "ef52715a1a30dd7b951c862bae4ab7c50394aef7a3635d8ba058e97db3873dbc")
