-- Lua provided by RyzenAPI
-- Game: Sunset Motel

-- MAIN APPLICATION
addappid(2616140)
addappid(4437740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616141, 1, "ef52715a1a30dd7b951c862bae4ab7c50394aef7a3635d8ba058e97db3873dbc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
