-- Lua provided by RyzenAPI
-- Game: addappid(302010)

-- MAIN APPLICATION
addappid(302010)

-- MAIN APP DEPOTS / PACKAGES
addappid(302011, 1, "d9bb6393ada1ae048c575764005d20a1b5c1f204796f522e5184ebd9e15ac20e")
