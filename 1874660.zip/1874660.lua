-- Lua provided by RyzenAPI
-- Game: 浮生箓 Floating Life

-- MAIN APPLICATION
addappid(1874660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874661, 1, "dedb847582fbcca52fd4b1cc71009ab5832338c52ec5efe2a631867a528b5980")
