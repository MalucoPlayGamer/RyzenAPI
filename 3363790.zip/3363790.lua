-- Lua provided by RyzenAPI 
-- Game: Lift/Shift
addappid(3363790)
addappid(3363791, 1, "cd275f0242a5b09f0ecec49f9e5771195c3970f7838beee5a9fb23511199cad1")
