-- Lua provided by RyzenAPI
-- Game: 2181060

-- MAIN APPLICATION
addappid(2181060)
-- Game: addappid(2181060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181061, 1, "117ccf7cda60bc4285464e6d04509e62b8aac3553130368060d8cd67fcb7bba5")
