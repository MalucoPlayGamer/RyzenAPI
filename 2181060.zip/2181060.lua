-- Lua provided by RyzenAPI
-- Game: Obscene Mansion

-- MAIN APPLICATION
addappid(2181060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181061, 1, "117ccf7cda60bc4285464e6d04509e62b8aac3553130368060d8cd67fcb7bba5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
