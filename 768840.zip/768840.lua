-- Lua provided by RyzenAPI
-- Game: FIRST STEAM GAME VHS - COLOR RETRO RACER : MILES CHALLENGE

-- MAIN APPLICATION
addappid(768840)

-- MAIN APP DEPOTS / PACKAGES
addappid(768841, 1, "3116dbcc345854c6687ed594b184971894cc60e8130ec4e13439228379591c12")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(768850)
addappid(768851)
addappid(768852)
addappid(768853)
addappid(768854)
addappid(768855)
addappid(768856)
