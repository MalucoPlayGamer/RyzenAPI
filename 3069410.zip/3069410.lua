-- Lua provided by RyzenAPI
-- Game: addappid(3069410)

-- MAIN APPLICATION
addappid(3069410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3069411, 1, "f0bf423fe38e77b2ff7321a259f5e24d5d6f1b9fb26ea480868bef1bc2207a47")
