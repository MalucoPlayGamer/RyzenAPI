-- Lua provided by SkyAPI 
-- Game: SCHiM Playtest
addappid(1616400)
addappid(1616401, 1, "3653f1a3b0760d8b509da5b0b65b6ef85c34e5e22982d90ae24efae7725a3f28")
