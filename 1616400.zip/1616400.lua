-- Lua provided by RyzenAPI
-- Game: 1616400

-- MAIN APPLICATION
addappid(1616400)
-- Game: addappid(1616400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1616401, 1, "3653f1a3b0760d8b509da5b0b65b6ef85c34e5e22982d90ae24efae7725a3f28")
