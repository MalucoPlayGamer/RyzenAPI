-- Lua provided by RyzenAPI
-- Game: 1811750

-- MAIN APPLICATION
addappid(1811750)
addappid(1963730)
-- Game: addappid(1811750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811751, 1, "fd7aac0ea49b391380b4ef1f0ce8e76b3fbf968cdea13e8325157142b61cda19")
