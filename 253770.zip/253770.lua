-- Lua provided by RyzenAPI
-- Game: Bus-Simulator 2012

-- MAIN APPLICATION
addappid(253770)
-- Game: addappid(253770)

-- MAIN APP DEPOTS / PACKAGES
addappid(253771, 1, "0bb9eaa8c563f8c5845464a12365dc4c2036c618f5b26abb7c4fc2e013a1beed")
addappid(253772, 1, "c5d5fa48171cc22ba84f7bd1b6620e1301b484bf67f8418c0812328407db41c1")
addappid(253773, 1, "cfad9d61deb169c83737eae4507c9c2d42f09736429d4ad521fd2bf8394bd3d8")
