-- Lua provided by RyzenAPI
-- Game: Bus-Simulator 2012

-- MAIN APPLICATION
addappid(253770)

-- MAIN APP DEPOTS / PACKAGES
addappid(253771, 1, "0bb9eaa8c563f8c5845464a12365dc4c2036c618f5b26abb7c4fc2e013a1beed")
addappid(253772, 1, "c5d5fa48171cc22ba84f7bd1b6620e1301b484bf67f8418c0812328407db41c1")
addappid(253773, 1, "cfad9d61deb169c83737eae4507c9c2d42f09736429d4ad521fd2bf8394bd3d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
