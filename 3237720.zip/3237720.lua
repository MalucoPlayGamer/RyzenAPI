-- Lua provided by RyzenAPI
-- Game: Zuido

-- MAIN APPLICATION
addappid(3237720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3237721, 1, "10c679e4f3811545c40ff31e4d1082c7f9379aa2ee602f424e06a532bae6391f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
