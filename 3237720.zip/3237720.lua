-- Lua provided by RyzenAPI
-- Game: Zuido

-- MAIN APPLICATION
addappid(3237720)
-- Game: addappid(3237720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3237721, 1, "10c679e4f3811545c40ff31e4d1082c7f9379aa2ee602f424e06a532bae6391f")
