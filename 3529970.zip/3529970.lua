-- Lua provided by SkyAPI 
-- Game: LiveCap
addappid(3529970)
addappid(3529971, 1, "acdd66722f0db132c6170d1bc3e111848324daab885b7551b7811bf6249745fa")
