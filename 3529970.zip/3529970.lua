-- Lua provided by RyzenAPI
-- Game: LiveCap

-- MAIN APPLICATION
addappid(3529970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3529971, 1, "acdd66722f0db132c6170d1bc3e111848324daab885b7551b7811bf6249745fa")

