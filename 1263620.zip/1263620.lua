-- Lua provided by RyzenAPI
-- Game: Yacht Mechanic Simulator

-- MAIN APPLICATION
addappid(1263620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263621, 1, "c89edf1b152e3259ab7f152c34aff2dfc14a8b4a89620eb835a2faaff703f399")

