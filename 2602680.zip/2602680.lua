-- Lua provided by SkyAPI 
-- Game: AppID 2602680
addappid(2602680)
addappid(2602681, 1, "2b35ab4ec0a8c0b887d371d4c649c4076c1fc881a4f5b012826baf86125138c0")
