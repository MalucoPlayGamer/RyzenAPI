-- Lua provided by RyzenAPI
-- Game: Game: AppID 2602680

-- MAIN APPLICATION
addappid(2602680)
-- Game: addappid(2602680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602681, 1, "2b35ab4ec0a8c0b887d371d4c649c4076c1fc881a4f5b012826baf86125138c0")
