-- Lua provided by RyzenAPI
-- Game: 2199580

-- MAIN APPLICATION
addappid(2199580)
-- Game: addappid(2199580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199581, 1, "20c2c200bc070033e5228cd8b8334d6b9480bd539f393ace259996605debb2a1")
