-- Lua provided by RyzenAPI
-- Game: Telefrag VR

-- MAIN APPLICATION
addappid(916100)
addappid(1122140)
-- Game: addappid(916100)

-- MAIN APP DEPOTS / PACKAGES
addappid(916101, 1, "ece5babfafcfbbb2d002cc20449d9077356ec2e91edec249372cc8bd5cc15fc5")
