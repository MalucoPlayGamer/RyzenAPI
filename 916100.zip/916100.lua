-- Lua provided by RyzenAPI
-- Game: Telefrag VR

-- MAIN APPLICATION
addappid(916100)
addappid(1122140)

-- MAIN APP DEPOTS / PACKAGES
addappid(916101, 1, "ece5babfafcfbbb2d002cc20449d9077356ec2e91edec249372cc8bd5cc15fc5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
