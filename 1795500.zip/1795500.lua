-- Lua provided by RyzenAPI
-- Game: Cooks Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1795500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795500,0,"85d8887aa5ef86a8c481c8c92a9c65d26e27290b764098c5dd1ec2d0587b4d33")

