-- Lua provided by SkyAPI 
-- Game: AppID 223070
addappid(223070)
addappid(223071, 1, "19986e900e311a4ca77e10ca726ad505327a44d92255ea0592af522ce1ca4482")
addappid(228982)
addappid(228983)
addappid(228990)
addappid(229000)
