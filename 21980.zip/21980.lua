-- Lua provided by RyzenAPI 
-- Game: Call of Juarez: Bound in Blood
addappid(21980)
addappid(21981, 1, "ba5d970abe5031344c7056b273d03e5b4bf98f08203c62c785d2c884b3d7f10f")
addappid(21982, 1, "e47b22e089668ec4b13fe661b1c5926811cab149762d79d173e0d9d1c3366de8")
addappid(21983, 1, "55441b5312fe4e2a518d9ff0c87f48e18651bc475df10d391b514359d57a3f0d")
addappid(21984, 1, "54e63e8a628ba3fe15d0e4b699d68bc67ad33501f513edca39cf06ddc143e7fe")
addappid(21985, 1, "89a3bf48bf1760bec15d8b52d49ec57cf5a4e003c65845c3b291a2c80f75ebfa")
addappid(228981)
addappid(228990)
