-- Lua provided by RyzenAPI
-- Game: addappid(1132720)

-- MAIN APPLICATION
addappid(1132720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132721, 1, "62c3fd5cbc41bcf2d1e31dcf61978b15208c666aac620266d176eb7d7cf17518")
addappid(1132722, 1, "e7c4a6d945feb691be0b610d09ffcbc20057dd6423b2996f3769ec69340f4f4d")
