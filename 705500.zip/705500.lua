-- Lua provided by RyzenAPI
-- Game: Tiny Bubbles

-- MAIN APPLICATION
addappid(705500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(705501,0,"af613a98ab1d12b5be4bcd7417414e455ddb606cd2824564722ce00e21c22a38")
addappid(705504,0,"a419f6219d4247670907acc45be25228f7f1b86897567826f184880236d0851f")

