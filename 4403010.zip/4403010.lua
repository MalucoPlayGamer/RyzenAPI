-- Lua provided by RyzenAPI
-- Game: Pegs X Stickers

-- MAIN APPLICATION
addappid(4403010) -- Pegs X Stickers

-- MAIN APP DEPOTS / PACKAGES
addappid(4403011, 1, "91a924366c9d87576691635405f814d6b3184b6e4b0ef43dfff354f5dc672a7a") -- Depot 4403011
addappid(4403012, 1, "b79cd2b905164bb7bd118df46f7dd1142d69346456d96272e8ecbfa0ed0bc03a") -- Depot 4403012

