-- 4403010's Lua and Manifest Created by Hubcap Manifest
-- Pegs X Stickers
-- Created: August 15, 2026 at 00:09:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4403010) -- Pegs X Stickers
-- MAIN APP DEPOTS
addappid(4403011, 1, "91a924366c9d87576691635405f814d6b3184b6e4b0ef43dfff354f5dc672a7a") -- Depot 4403011
setManifestid(4403011, "8286162990109713508", 606219526)
addappid(4403012, 1, "b79cd2b905164bb7bd118df46f7dd1142d69346456d96272e8ecbfa0ed0bc03a") -- Depot 4403012
setManifestid(4403012, "7112127629696367322", 621991412)