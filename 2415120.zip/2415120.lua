-- Lua provided by RyzenAPI
-- Game: Abstract Driver

-- MAIN APPLICATION
addappid(2415120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415121, 1, "73d37e459b60c4d04570975aade52beb685ec1054a5fd267001f217cc093403a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
