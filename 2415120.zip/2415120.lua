-- Lua provided by RyzenAPI
-- Game: 2415120

-- MAIN APPLICATION
addappid(2415120)
-- Game: addappid(2415120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415121, 1, "73d37e459b60c4d04570975aade52beb685ec1054a5fd267001f217cc093403a")
