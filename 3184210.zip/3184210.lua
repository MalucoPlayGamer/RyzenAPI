-- Lua provided by RyzenAPI
-- Game: 3184210

-- MAIN APPLICATION
addappid(3184210)
-- Game: addappid(3184210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3184211, 1, "2e59325f3bace260033aea1f17119e4e522dc67acb27231212f34527b7df4bd9")
