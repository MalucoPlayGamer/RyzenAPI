-- Lua provided by RyzenAPI
-- Game: Adult Puzzles - Hentai Halloween

-- MAIN APPLICATION
addappid(1798220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798221, 1, "f9ab0cfadb2b753000a3d42e65da6435666536e08376e19d5cb9283a6a78e3d7")
addappid(1798800, 0, "695a0ece865def0ee3aaac996e513b02e95374fa3c354fde04725de93b156c64")

