-- Lua provided by RyzenAPI
-- Game: 3146150

-- MAIN APPLICATION
addappid(3146150)
-- Game: addappid(3146150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146151, 1, "f32470ffd239e7d7cdf399921907be74c0ee213021dbc580a83644ca916ad85c")
