-- Lua provided by RyzenAPI
-- Game: Anthro Heat

-- MAIN APPLICATION
addappid(2236060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236061, 1, "0c19793d4fb180ff03bba8db62005d09de0b823a70df4cb8fd393c134817dd61")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
