-- Lua provided by RyzenAPI
-- Game: 2236060

-- MAIN APPLICATION
addappid(2236060)
-- Game: addappid(2236060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236061, 1, "0c19793d4fb180ff03bba8db62005d09de0b823a70df4cb8fd393c134817dd61")
