-- Lua provided by RyzenAPI
-- Game: The Walking Dead: No Man's Land

-- MAIN APPLICATION
addappid(2936310)

