-- Lua provided by SkyAPI 
-- Game: Baldi's Basics Classic Remastered
addappid(1712830)
addappid(1712831, 1, "8cd8a8262724397bb4920562695ccad13355585ccabd879f788c8c4de4909713")
addappid(1712832, 1, "b104d69b61a6551d561cf8b8700fc193af12b792abbf0db5f85582065c62bf5b")
addappid(1712833, 1, "178a80fc3607158abf87c4971467645e6e024d3e9a5c10b2482910a73393fbb0")
