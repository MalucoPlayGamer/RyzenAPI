-- Lua provided by RyzenAPI
-- Game: 1325290

-- MAIN APPLICATION
addappid(1325290)
-- Game: addappid(1325290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325291, 1, "2e160784321e96a504efcf4e359eefe08e2b2b182b4c19344ef8f828b23dc7ba")
