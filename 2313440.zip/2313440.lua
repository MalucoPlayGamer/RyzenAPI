-- Lua provided by RyzenAPI
-- Game: Demonslayer AKA Me

-- MAIN APPLICATION
addappid(2313440)
-- Game: addappid(2313440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313441, 1, "0436067eb75cff1b710d9358a927c5423770b9485c078d2585083e64cc91759e")
