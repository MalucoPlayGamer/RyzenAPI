-- Lua provided by RyzenAPI
-- Game: Game: Rynn's Adventure: Trouble in the Enchanted Forest

-- MAIN APPLICATION
addappid(420500)
-- Game: addappid(420500)

-- MAIN APP DEPOTS / PACKAGES
addappid(420501, 1, "fc5873839069217d5cc5f94d981e657731af85386b4c84fee1bfa0db2b17d4ad")
