-- Lua provided by RyzenAPI
-- Game: Imagine Lifetimes

-- MAIN APPLICATION
addappid(1229570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229571, 1, "31131fcf5172ca971094621369537ad11fb9c5e6ddb97320700ff4d823125cb3")
