-- Lua provided by RyzenAPI
-- Game: addappid(1534850)

-- MAIN APPLICATION
addappid(1534850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534851, 1, "e634e4b60331e2d2a82efa6ea80e884f2e5187cb53f28b8fc469443a20032623")
