-- Lua provided by RyzenAPI
-- Game: MindsEye

-- MAIN APPLICATION
addappid(3265250)
addappid(3511550)
addappid(3511560)
addappid(3511570)
addappid(3511580)
addappid(3511590)
addappid(3511600)
addappid(3511940)
addappid(3519570)
addappid(3711570)
addappid(3804130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3265251, 1, "4314da2fbb6b1038e0f8199b23f2f2c4ab77a7b1fb15289036bdc4fb0178a0a1")

