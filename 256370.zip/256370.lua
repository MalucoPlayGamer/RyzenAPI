-- Lua provided by RyzenAPI
-- Game: MXGP - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(256370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(256371, 1, "ae3d00832cb13bafdaf7e542da36b5eddf02f231d19defe60e604ebad950120f")

