-- Lua provided by RyzenAPI
-- Game: MXGP - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(256370)

-- MAIN APP DEPOTS / PACKAGES
addappid(256371, 1, "ae3d00832cb13bafdaf7e542da36b5eddf02f231d19defe60e604ebad950120f")
