-- Lua provided by SkyAPI 
-- Game: Anime Boys Mirror Quest
addappid(3472190)
addappid(3472191, 1, "18cd20d3745c29a9de2d7b454282564e8e5ad1106d9b5c072a799bf4d8c749eb")
