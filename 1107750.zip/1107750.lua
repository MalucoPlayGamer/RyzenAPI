-- Lua provided by RyzenAPI
-- Game: AppID 1107750

-- MAIN APPLICATION
addappid(1107750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107751, 1, "6405f23c21b53080786a713cc4aa04456e24c07039b0fbb0d9d0e9900329b631")
addappid(1107752, 1, "7828bfa39f0d7633ca5492a9ce527e2b7a4e130f4b2e47f6c3b4d197ef9e3249")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
