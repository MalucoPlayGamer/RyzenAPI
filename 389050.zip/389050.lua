-- Lua provided by RyzenAPI
-- Game: Pocket Rumble

-- MAIN APPLICATION
addappid(389050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(389051, 1, "75cd25866c1aaca771eae2767a4245314ad685a82f8e3f5342067bb00ed42b12")
addappid(389052, 1, "0ca4b5ac17da996bb49039b20633439898f4f9e2aa1c0e204666f1434fc51ba0")

