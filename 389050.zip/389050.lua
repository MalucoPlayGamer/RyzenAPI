-- Lua provided by RyzenAPI
-- Game: Game: AppID 389050

-- MAIN APPLICATION
addappid(389050)
-- Game: addappid(389050)

-- MAIN APP DEPOTS / PACKAGES
addappid(389051, 1, "75cd25866c1aaca771eae2767a4245314ad685a82f8e3f5342067bb00ed42b12")
addappid(389052, 1, "0ca4b5ac17da996bb49039b20633439898f4f9e2aa1c0e204666f1434fc51ba0")
