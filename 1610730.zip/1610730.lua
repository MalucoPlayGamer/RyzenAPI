-- Lua provided by RyzenAPI
-- Game: Fallen from the sky

-- MAIN APPLICATION
addappid(1610730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610731, 1, "b21a70631b77ea52928600b5fa4d1a959e7d88fc33d73785ee8503b33e73917e")
