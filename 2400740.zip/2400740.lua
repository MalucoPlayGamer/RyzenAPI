-- Lua provided by RyzenAPI
-- Game: PIGBLUE

-- MAIN APPLICATION
addappid(2400740)
-- Game: addappid(2400740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400741, 1, "1c61a6754c4df150f55ff00375fded906fddf06738ac5b9a89be8d78b3f98082")
