-- Lua provided by RyzenAPI 
-- Game: PIGBLUE
addappid(2400740)
addappid(2400741, 1, "1c61a6754c4df150f55ff00375fded906fddf06738ac5b9a89be8d78b3f98082")
