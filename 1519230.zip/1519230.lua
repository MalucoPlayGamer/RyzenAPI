-- Lua provided by RyzenAPI
-- Game: Game: AppID 1519230

-- MAIN APPLICATION
addappid(1519230)
-- Game: addappid(1519230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519231, 1, "c7a03b7920033793b399a8feac025cbfea7e4a0da89c2f632db1ba098e58c813")
