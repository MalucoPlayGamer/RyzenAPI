-- Lua provided by RyzenAPI
-- Game: Astatos

-- MAIN APPLICATION
addappid(1430970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430971, 1, "d18950209e9fa12a0be8b1ec2279be601080a944d175e26db9c9a80954434ef0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
