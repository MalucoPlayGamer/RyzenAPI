-- Lua provided by RyzenAPI
-- Game: addappid(1430970)

-- MAIN APPLICATION
addappid(1430970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430971, 1, "d18950209e9fa12a0be8b1ec2279be601080a944d175e26db9c9a80954434ef0")
