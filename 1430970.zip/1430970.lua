-- Lua provided by RyzenAPI 
-- Game: Astatos
addappid(1430970)
addappid(1430971, 1, "d18950209e9fa12a0be8b1ec2279be601080a944d175e26db9c9a80954434ef0")
