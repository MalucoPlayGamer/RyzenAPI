-- Lua provided by RyzenAPI
-- Game: addappid(1701670)

-- MAIN APPLICATION
addappid(1701670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701671, 1, "7f1c8d51470dd4d05e76455711d987ec1f8cbd1ad515bfd8086454c655319c0d")
