-- Lua provided by RyzenAPI
-- Game: BustyBiz

-- MAIN APPLICATION
addappid(1443820)
addappid(2247460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443821, 1, "d458e400ab24176b318ed83700a6f7c6289b2b5470a9d21bd9cdc69481033f9c")

