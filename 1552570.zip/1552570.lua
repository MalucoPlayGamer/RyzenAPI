-- Lua provided by RyzenAPI
-- Game: INFINITE VERSUS: 3D MUGEN - Open Beta

-- MAIN APPLICATION
addappid(1552570)
-- Game: addappid(1552570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552571, 1, "282e6540e045efcb3116f9683d68d044066c0e2e6a3d269bebe12bd50037ce71")
