-- Lua provided by RyzenAPI
-- Game: Mind Over Mushroom

-- MAIN APPLICATION
addappid(791800)

-- MAIN APP DEPOTS / PACKAGES
addappid(791801,0,"60395da7674f89bb34e2836c3e354dee704a1be9ce512ae1fca258315188f6d4")

