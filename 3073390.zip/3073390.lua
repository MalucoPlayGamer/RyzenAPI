-- Lua provided by RyzenAPI
-- Game: AppID 3073390

-- MAIN APPLICATION
addappid(3073390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073391, 1, "9cfaaeaf2efcc1c6c6062fb9aa1ea422654c276dc53b76ae84b42c8ce1fcca2a")
