-- Lua provided by RyzenAPI
-- Game: AppID 1931730

-- MAIN APPLICATION
addappid(1931730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931731, 1, "48ecd148da7853ad66d48b435da51151247b8110a6367e474dee4f8260d7db6e")
addappid(1931732, 1, "54c57b13ed1eaf1a060a4f182efa513a17b3a305a6c3ee1024b03cfb75beac86")
addappid(2545430, 0, "50ef04fd9aa277d2c1067f9bf0567ad040522c3d54f9ede961a7946f12af7b2a")
addappid(3160390, 0, "1085cf46d657900b21a57d1eaed394acf64024a046f970529106d4c98b2da385")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
