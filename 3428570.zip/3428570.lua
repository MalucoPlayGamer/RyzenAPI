-- Lua provided by RyzenAPI
-- Game: Teller's Duty

-- MAIN APPLICATION
addappid(3428570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428571,0,"bb82ff7741f017db02f1aae7dce5f05d252e53801837ff9b604f7175120e379c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5051640)
