-- Lua provided by RyzenAPI
-- Game: addappid(2660830)

-- MAIN APPLICATION
addappid(2660830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660831, 1, "4276625303e7ba906fb1e6cca90d2ab118d6790a6c2168da286baaf59f52a919")
