-- Lua provided by RyzenAPI
-- Game: DEADCAM | ANALOG • SURVIVAL • HORROR

-- MAIN APPLICATION
addappid(2660830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660831, 1, "4276625303e7ba906fb1e6cca90d2ab118d6790a6c2168da286baaf59f52a919")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
