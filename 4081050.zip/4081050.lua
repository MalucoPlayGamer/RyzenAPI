-- Lua provided by RyzenAPI
-- Game: Green Light

-- MAIN APPLICATION
addappid(4081050)

