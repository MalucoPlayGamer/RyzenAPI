-- Lua provided by SkyAPI 
-- Game: Waifu Trainer
addappid(1794170)
addappid(1794171, 1, "6fb3e02bb1e573e45fec218917fc3ba5bc78d09b85c0458f14df9130454b96d1")
