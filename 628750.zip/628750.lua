-- Lua provided by RyzenAPI
-- Game: aMAZE 2

-- MAIN APPLICATION
addappid(628750)

-- MAIN APP DEPOTS / PACKAGES
addappid(628751, 1, "f89507d3759bab72f0c12baa8e61fed98c5c5e83e4cfb0faf6ea229118dd6355")
