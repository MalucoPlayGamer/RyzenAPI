-- Lua provided by RyzenAPI
-- Game: 1588070

-- MAIN APPLICATION
addappid(1588070)
-- Game: addappid(1588070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588071, 1, "41bf0bf62dda6a07c2b05a03f0c28fbfc60abe087927d31e5c6177ed10e226f5")
