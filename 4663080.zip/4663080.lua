-- Lua provided by RyzenAPI
-- Game: Escape the Grind

-- MAIN APPLICATION
addappid(4663080) -- Escape the Grind

-- MAIN APP DEPOTS / PACKAGES
addappid(4663081, 1, "27ad9514d3c304448556e255fe6db10d7908779d441e616613f3dbc91d784833") -- Depot 4663081
