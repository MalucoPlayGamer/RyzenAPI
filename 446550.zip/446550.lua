-- Lua provided by RyzenAPI
-- Game: Infinite Minigolf

-- MAIN APPLICATION
addappid(446550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(446551, 1, "96f8efd9ae839d0b23135c85644d480230adb4f421b5843ed1c7bd0238cd036d")
addappid(580660, 0, "7cfd40f929c17c2326977307ca1b2f4062e831436e332334d623a4792953da85")
addappid(580661, 0, "4a8b682fd97886e311e615fc6338cdb0459c47f8edd2c9f0c75f087ac145221c")

