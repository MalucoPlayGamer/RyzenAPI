-- Lua provided by RyzenAPI
-- Game: I commissioned some bees 13

-- MAIN APPLICATION
addappid(2625170)
-- Game: addappid(2625170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625171, 1, "359f985a8ba96b9d1416514816d98a909971d45b45ad2c2f9c5afcda252a622a")
