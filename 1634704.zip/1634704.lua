-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Weapon set 2

-- MAIN APPLICATION
addappid(1634704)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634704,0,"ffadd27ff7948fb39fd4c26f6d1828d9668d5087b49a05025cf4709078492028")

