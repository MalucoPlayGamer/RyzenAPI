-- Lua provided by RyzenAPI
-- Game: Infinity Runner

-- MAIN APPLICATION
addappid(279920)
addappid(288310)

-- MAIN APP DEPOTS / PACKAGES
addappid(279921, 1, "b8f99a44ef7a2a06c4978b993c31ae083c533448ae2efcc4c3e071342904334e")

