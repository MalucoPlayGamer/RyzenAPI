-- Lua provided by RyzenAPI
-- Game: I Did Not Buy This Ticket Demo

-- MAIN APPLICATION
addappid(2247870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247871, 1, "8aee2b959a4281fff2a3f46c360953db63bcaac56f8d613e3e9d07c29d691b87")
