-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Rolling Stones - "Angry"

-- MAIN APPLICATION
addappid(2650880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650880,0,"08d1f0d701125a6deafb61af226d3adf51821dffd3b40732e1f544249ba24b2d")

