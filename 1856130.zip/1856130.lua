-- Lua provided by RyzenAPI
-- Game: addappid(1856130)

-- MAIN APPLICATION
addappid(1856130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856131, 1, "fa2fdda43a9ef3c2ac357f289e81d5e9cfce0ebd62888655ed5a5f492999ea8a")
