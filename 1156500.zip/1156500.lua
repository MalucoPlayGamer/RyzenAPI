-- Lua provided by RyzenAPI
-- Game: AppID 1156500

-- MAIN APPLICATION
addappid(1156500)
-- Game: addappid(1156500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156501, 1, "f66a429dc5503c466e0d54ffe549204a7fd0209efde434a79df2b5644d213617")
