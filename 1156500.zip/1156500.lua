-- Lua provided by RyzenAPI
-- Game: Project Apocalypse

-- MAIN APPLICATION
addappid(1156500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1156501, 1, "f66a429dc5503c466e0d54ffe549204a7fd0209efde434a79df2b5644d213617")
