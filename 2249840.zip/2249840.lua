-- Lua provided by RyzenAPI
-- Game: AppID 2249840

-- MAIN APPLICATION
addappid(2249840)
-- Game: addappid(2249840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249841, 1, "bba86739a6a59a00baf770e694ab32c12e918b8fe7698fae5d5b9238548d9c8e")
