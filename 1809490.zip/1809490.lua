-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1809490)
addappid(1809491)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809492,0,"7adb7b7a6d19b3e4131901799a93a384bf2bbaf4dff1058d29b86a6e0e5d3451")

