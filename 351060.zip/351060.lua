-- Lua provided by RyzenAPI
-- Game: Game: Outpost 13

-- MAIN APPLICATION
addappid(351060)
-- Game: addappid(351060)

-- MAIN APP DEPOTS / PACKAGES
addappid(351061, 1, "ae7e41c3f2fb3d32d988e9da6ab93c59f6362dc8de3b6b85cf02a37eee27754a")
addappid(351062, 1, "a9d18c2bd248d0328eddbbf0c647894c0e05f799d3d8f6d7327755a29bfd3f91")
