-- Lua provided by RyzenAPI
-- Game: Evacuation Original Soundtrack

-- MAIN APPLICATION
addappid(2236110)
-- Game: addappid(2236110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236111, 1, "50e66a5cd2394159d6b3a6f56acd1423929821ac04571ce24c96163a1284ea2b")
addappid(2236112, 1, "5776c9a07172cdf49c34526b505ff4c793a4dbb4a0546c7d82da2eceff343320")
