-- Lua provided by SkyAPI 
-- Game: AppID 845150
addappid(845150)
addappid(845151, 1, "2eae885abb690d080af8e38ab327bae2ccae59864ac3aaef71479400985d278b")
