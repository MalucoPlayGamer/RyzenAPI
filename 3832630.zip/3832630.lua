-- Lua provided by RyzenAPI
-- Game: Wheelchair Wizards

-- MAIN APPLICATION
addappid(3832630)
addappid(3841630)
addappid(3939380)

