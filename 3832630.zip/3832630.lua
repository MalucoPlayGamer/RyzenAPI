-- Lua provided by RyzenAPI
-- Game: Wheelchair Wizards

-- MAIN APPLICATION
addappid(3832630)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3841630)
addappid(3939380)
