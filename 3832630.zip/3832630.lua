-- Lua provided by RyzenAPI
-- Game: Wheelchair Wizards

-- MAIN APPLICATION
addappid(3832630)
