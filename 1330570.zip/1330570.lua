-- Lua provided by RyzenAPI
-- Game: RUN! GRANDPA! RUN!

-- MAIN APPLICATION
addappid(1330570)
-- Game: addappid(1330570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330571, 1, "9f49ebc922278c0a9fbc2e9d6f85f4aff56d2d9b8cf7e7aa27c22062cfddee05")
