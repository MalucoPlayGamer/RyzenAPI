-- Lua provided by RyzenAPI
-- Game: IS Defense

-- MAIN APPLICATION
addappid(448370)

-- MAIN APP DEPOTS / PACKAGES
addappid(448371, 1, "dd7cf67508f84c78db62e8c44c7fac992f4216a6a52e8b6ef828e986a8cc22b1")
addappid(448372, 1, "dd158d2861b20223ecac0be2cab27907e594017c97d58106a74bbe628c922402")
addappid(448373, 1, "745c939a7f6b89306b43268214558f695f4d4e065def0432fa47a41c2efc55a8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
