-- Lua provided by RyzenAPI
-- Game: Game: IS Defense

-- MAIN APPLICATION
addappid(448370)
-- Game: addappid(448370)

-- MAIN APP DEPOTS / PACKAGES
addappid(448371, 1, "dd7cf67508f84c78db62e8c44c7fac992f4216a6a52e8b6ef828e986a8cc22b1")
addappid(448372, 1, "dd158d2861b20223ecac0be2cab27907e594017c97d58106a74bbe628c922402")
addappid(448373, 1, "745c939a7f6b89306b43268214558f695f4d4e065def0432fa47a41c2efc55a8")
