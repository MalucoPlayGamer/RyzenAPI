-- Lua provided by RyzenAPI
-- Game: Game: AppID 1986900

-- MAIN APPLICATION
addappid(1986900)
-- Game: addappid(1986900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986901, 1, "b61cbf1da96b064c78af8e9ad6cf3511ae29faf31f833b8c63d28984cd43ac56")
