-- Lua provided by RyzenAPI
-- Game: 2204940

-- MAIN APPLICATION
addappid(2204940)
-- Game: addappid(2204940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204941, 1, "bf7e601c03df0e09d44b86ca33cb9748b1e3a5ecc7b4d80d32cee4f5a0d63c71")
