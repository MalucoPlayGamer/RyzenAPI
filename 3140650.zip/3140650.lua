-- Lua provided by RyzenAPI
-- Game: Game: AppID 3140650

-- MAIN APPLICATION
addappid(3140650)
-- Game: addappid(3140650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140651, 1, "ac5977bbcc91382de5bd20b67f2327c101ecbfd23a3986f94354175b90fa7a19")
