-- Lua provided by RyzenAPI
-- Game: Vestaria Saga I Soundtrack PIANO ARRANGEMENT & 8-BIT MUSIC VERSION

-- MAIN APPLICATION
addappid(1216180)
-- Game: addappid(1216180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216180,0,"48bb6a4d32b5bd9eb171cb60626f019e8760c9c88e88ea04101051e88990a40b")
