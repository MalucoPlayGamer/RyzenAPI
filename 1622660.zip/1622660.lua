-- Lua provided by RyzenAPI
-- Game: addappid(1622660)

-- MAIN APPLICATION
addappid(1622660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622661, 1, "830939ea87484c941e8fa780e40b85fbdf94c8d2bb74665203570a3c49af260a")
