-- Lua provided by RyzenAPI
-- Game: Game: Hentai Darts

-- MAIN APPLICATION
addappid(1220190)
-- Game: addappid(1220190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220191, 1, "c950f3717dc878ed6a8504aa5c695b9ce765dfced06eaab62e56c6f0b3bcc11a")
