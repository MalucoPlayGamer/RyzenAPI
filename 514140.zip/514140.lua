-- Lua provided by RyzenAPI
-- Game: Elite Warriors: Vietnam

-- MAIN APPLICATION
addappid(514140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(514141, 1, "ce7c64b88c21c7e8c1813485d3e0a9130a8080e5e3496fb578be2f001c2cc980")

