-- Lua provided by RyzenAPI
-- Game: AppID 514140

-- MAIN APPLICATION
addappid(514140)
-- Game: addappid(514140)

-- MAIN APP DEPOTS / PACKAGES
addappid(514141, 1, "ce7c64b88c21c7e8c1813485d3e0a9130a8080e5e3496fb578be2f001c2cc980")
