-- Lua provided by RyzenAPI
-- Game: Whiplash - Crash Valley

-- MAIN APPLICATION
addappid(552130)

-- MAIN APP DEPOTS / PACKAGES
addappid(552131, 1, "7dd799a24e2006adf84a07a67522e8c6e04e85bcfad00105c759728583d2a144")

