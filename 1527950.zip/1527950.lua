-- Lua provided by RyzenAPI 
-- Game: Wartales
addappid(1527950)
addappid(1527951, 1, "95bd24e7b06dd6b363b41cd5735569fe66f9d030ec1b11d30e46c13171a17852")
