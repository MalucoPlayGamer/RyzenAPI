-- Lua provided by RyzenAPI
-- Game: Wartales

-- MAIN APPLICATION
addappid(1527950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527951, 1, "95bd24e7b06dd6b363b41cd5735569fe66f9d030ec1b11d30e46c13171a17852")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2692400)
addappid(2903960)
addappid(3112270)
addappid(3335020)
addappid(3559560)
addappid(3899740)
addappid(4165520)
addappid(4490120)
