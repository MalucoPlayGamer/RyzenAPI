-- Lua provided by RyzenAPI
-- Game: Solitaire Knights

-- MAIN APPLICATION
addappid(820090)

-- MAIN APP DEPOTS / PACKAGES
addappid(820091, 1, "c2bf5791bc8d2274bad836f7f1b436cc730647bc7d9bcff8469138441b27fcc9")
addappid(820092, 1, "6494e5a4121f1e90bffb94ac365695860ab33e31e8df2bafaf0b221ae1f6fb67")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
