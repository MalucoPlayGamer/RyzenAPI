-- Lua provided by RyzenAPI
-- Game: Game: Solitaire Knights

-- MAIN APPLICATION
addappid(820090)
-- Game: addappid(820090)

-- MAIN APP DEPOTS / PACKAGES
addappid(820091, 1, "c2bf5791bc8d2274bad836f7f1b436cc730647bc7d9bcff8469138441b27fcc9")
addappid(820092, 1, "6494e5a4121f1e90bffb94ac365695860ab33e31e8df2bafaf0b221ae1f6fb67")
