-- Lua provided by SkyAPI 
-- Game: Ekans
addappid(2519010)
addappid(2519011, 1, "1c8eefca8ffaca095dada157633b9d43bb50506be00e3154bbceee1756d47814")
