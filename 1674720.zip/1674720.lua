-- Lua provided by RyzenAPI
-- Game: Rage Quit

-- MAIN APPLICATION
addappid(1674720)
-- Game: addappid(1674720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674721, 1, "368e61d5d2a039783dd2b16b2f08d712166331b73d3ebe07d957b562d707823f")
