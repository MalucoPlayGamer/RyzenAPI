-- Lua provided by RyzenAPI
-- Game: AppID 276730

-- MAIN APPLICATION
addappid(276730)

-- MAIN APP DEPOTS / PACKAGES
addappid(276731, 1, "4266e0e6657156a841544e73b7288afddb5009febb3a15aa06974e9492f98b61")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1347790)
