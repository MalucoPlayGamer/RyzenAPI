-- Lua provided by RyzenAPI
-- Game: Cloudbase Prime

-- MAIN APPLICATION
addappid(511250)

-- MAIN APP DEPOTS / PACKAGES
addappid(511251, 1, "ee5df89b880a367378ee00ec6725a7350c180e12a4fd9d0d55e2a27a0d772ecf")
addappid(511252, 1, "8fc64bf15ea9ed4b4982ea3bef0c52964bbe86faaddebd9e9f66ad536640e453")

