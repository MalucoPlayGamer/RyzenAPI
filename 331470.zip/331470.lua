-- Lua provided by RyzenAPI
-- Game: Everlasting Summer

-- MAIN APPLICATION
addappid(331470)

-- MAIN APP DEPOTS / PACKAGES
addappid(331471, 1, "c1134595d3ccab451501b77b9cb0d5ef533fe01b455653f58f9d4cfc68cd8f93")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(340110)
