-- Lua provided by RyzenAPI
-- Game: 331470

-- MAIN APPLICATION
addappid(331470)
-- Game: addappid(331470)

-- MAIN APP DEPOTS / PACKAGES
addappid(331471, 1, "c1134595d3ccab451501b77b9cb0d5ef533fe01b455653f58f9d4cfc68cd8f93")
