-- Lua provided by RyzenAPI 
-- Game: AppID 2600600
addappid(2600600)
addappid(2600601, 1, "67fd57996b6173fcc34d56f16b0621696df2a8c6fc7a6a76750b70e383189267")
