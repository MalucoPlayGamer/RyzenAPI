-- Lua provided by RyzenAPI
-- Game: 657490

-- MAIN APPLICATION
addappid(657490)
-- Game: addappid(657490)

-- MAIN APP DEPOTS / PACKAGES
addappid(657491, 1, "5cdadd7a72e11fc4032db5b359d0aec53a1bb12cc82bd06adff0af61d1ac3077")
