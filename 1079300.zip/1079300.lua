-- Lua provided by RyzenAPI
-- Game: 1079300

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(1079300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079302,0,"e3d63acadc8c2f1ee417a67b7ad9618257a21e0337365615e4c820fbe7a4f6fc")
