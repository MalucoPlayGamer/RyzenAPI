-- Lua provided by RyzenAPI 
-- Game: Child of Light Demo
addappid(294510)
addappid(294511, 1, "a7a03146991e65f40e8aea2561f1a7ed5585e9000518f9db1838dc60312da14c")
