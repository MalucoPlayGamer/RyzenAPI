-- Lua provided by RyzenAPI
-- Game: addappid(2684960)

-- MAIN APPLICATION
addappid(2684960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684961, 1, "e9cdd1d431304734fd612a0996023e5475b506dd2a35b6e3ae5a95da4abac033")
