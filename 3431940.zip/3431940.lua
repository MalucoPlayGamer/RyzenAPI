-- Lua provided by RyzenAPI
-- Game: addappid(3431940)

-- MAIN APPLICATION
addappid(3431940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3431940,0,"7ecc1784aa8902e88ae28af7a8ac76720550cb34095f684959f1a7f7b522a6a0")
