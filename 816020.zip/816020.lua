-- Lua provided by RyzenAPI
-- Game: addappid(816020)

-- MAIN APPLICATION
addappid(816020)
addappid(974700)
addappid(974701)
addappid(974702)
addappid(974720)
addappid(974721)
addappid(974722)
addappid(974723)
addappid(974724)
addappid(974725)
addappid(974726)
addappid(974727)
addappid(974728)
addappid(974729)
addappid(1248330)
addappid(1248331)
addappid(1248332)
addappid(1248333)
addappid(1248334)
addappid(1248335)

-- MAIN APP DEPOTS / PACKAGES
addappid(816021, 1, "06212bff2603c46ed13947689e04c3513c44d7a2e28898f4b66b848dbbbb3bb1")
