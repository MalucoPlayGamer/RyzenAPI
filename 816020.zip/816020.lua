-- Lua provided by RyzenAPI
-- Game: JUMP FORCE

-- MAIN APPLICATION
addappid(816020)
addappid(974700)
addappid(974701)
addappid(974702)
addappid(974720)
addappid(974721)
addappid(974722)
addappid(974723)
addappid(974724)
addappid(974725)
addappid(974726)
addappid(974727)
addappid(974728)
addappid(974729)
addappid(1248330)
addappid(1248331)
addappid(1248332)
addappid(1248333)
addappid(1248334)
addappid(1248335)

-- MAIN APP DEPOTS / PACKAGES
addappid(816021, 1, "06212bff2603c46ed13947689e04c3513c44d7a2e28898f4b66b848dbbbb3bb1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
