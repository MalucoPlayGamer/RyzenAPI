-- Lua provided by RyzenAPI
-- Game: Anomalies

-- MAIN APPLICATION
addappid(546780)
addappid(696340)

-- MAIN APP DEPOTS / PACKAGES
addappid(546781, 1, "5a2e79dd90e586922407ae74d5cb7e092a5d1290286f6fdeb53a634a8a6b8eb6")
addappid(665990, 0, "7487ea2e11698653f08ff9697e6d6e43049e11ca84bf129eefcc46cc5adafa3d")

