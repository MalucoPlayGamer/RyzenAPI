-- Lua provided by RyzenAPI
-- Game: My Little Riding Champion

-- MAIN APPLICATION
addappid(789900)

-- MAIN APP DEPOTS / PACKAGES
addappid(789901,0,"a95decd00c849f8a67c40bfdeec4df0c6699e235412ab04988b5ed46fb93dc4e")

