-- Lua provided by RyzenAPI
-- Game: My Little Riding Champion

-- MAIN APPLICATION
addappid(789900)

-- MAIN APP DEPOTS / PACKAGES
addappid(789901,0,"a95decd00c849f8a67c40bfdeec4df0c6699e235412ab04988b5ed46fb93dc4e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
