-- Lua provided by RyzenAPI
-- Game: 灵途

-- MAIN APPLICATION
addappid(1841400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841401, 1, "f78f9a5013ab931b51044535432fd3c0266043bdd6538e3fb6d4899c4abeaf47")
