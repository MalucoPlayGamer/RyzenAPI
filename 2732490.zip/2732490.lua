-- Lua provided by RyzenAPI
-- Game: 2732490

-- MAIN APPLICATION
addappid(2732490)
-- Game: addappid(2732490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732491, 1, "de78be8d975469eb162ebf657675a2ed7a9ece5e7dc9157f657808ae5966faa4")
addappid(2819250, 0, "3b13742aeffc30a2eea29c953d542989c575a494d217a4ce3da6ac3f553b85ff")
