-- Lua provided by RyzenAPI
-- Game: Game: Furry Girlfriend Simulator

-- MAIN APPLICATION
addappid(1879790)
-- Game: addappid(1879790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879791, 1, "aaa69e1db89ddef3faec1ac0d87a59ab3b0e1bd50ebcf0654bf42fc0e2c1bc73")
