-- Lua provided by RyzenAPI
-- Game: AppID 3564650

-- MAIN APPLICATION
addappid(3564650)
-- Game: addappid(3564650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564651, 1, "b8608d1dc9520cc2e2feb133bd2eaf2caaf4632cf0505e92f55e00eae46aa0a4")
