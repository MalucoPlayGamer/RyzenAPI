-- Lua provided by RyzenAPI
-- Game: addappid(1049080)

-- MAIN APPLICATION
addappid(1049080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049081, 1, "cc6d62bea2c028a6e8220ea1a5b467717370aee57ee7c064c38245999cda1223")
