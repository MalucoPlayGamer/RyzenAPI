-- Lua provided by RyzenAPI
-- Game: Out of Reach

-- MAIN APPLICATION
addappid(327090)

-- MAIN APP DEPOTS / PACKAGES
addappid(327091, 1, "df079f709359d65236fcd6949c3072bae097b9c61edc72338cf3a5b3e5e2bdeb")
addappid(327092, 1, "6dab6c2d32a95837e6f600f4987a54fa05e689204707a5600efca66eb3356824")
addappid(327093, 1, "653660a571be3b4ccb30c9c77f4379e931e7f9aaad22ef99a6b292af3ac70999")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
