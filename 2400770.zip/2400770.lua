-- Lua provided by RyzenAPI
-- Game: Dungeon Tycoon

-- MAIN APPLICATION
addappid(3233000)
addappid(3908110) -- Dungeon Tycoon - Necropolis Rising

-- MAIN APP DEPOTS / PACKAGES
addappid(2400770, 1, "2991e56d2e58a10b2b952ac037812c49bf9528b688111761364b488a6aca4035") -- Dungeon Tycoon
addappid(2400771, 1, "2702fa62592dc31adb894183b5c31b2408a5c5e3050c2c263441a0319cf00c3c") -- Depot 2400771
addappid(2400772, 1, "aca4df4be197d145c81d925aaff43e8ab99f40932adc112e35f89e6cdb2c6253") -- Depot 2400772
addappid(3233000, 1, "a4944acb674c6afff8251dfb07f4cabfcce477eac25c724619ec3b5e1ce5c0bc") -- Dungeon Tycoon - Supporter Pack - Depot 3233000

