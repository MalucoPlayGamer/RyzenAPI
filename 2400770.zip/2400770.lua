-- Lua provided by RyzenAPI 
-- Game: Dungeon Tycoon
addappid(2400770)
addappid(2400771, 1, "2702fa62592dc31adb894183b5c31b2408a5c5e3050c2c263441a0319cf00c3c")
addappid(3233000, 0, "a4944acb674c6afff8251dfb07f4cabfcce477eac25c724619ec3b5e1ce5c0bc")
