-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2059771)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059771,0,"6e18e1fb5f2f2d81f267207fb4ee9143852bf644c93809b98089a1fdbe923baf")

