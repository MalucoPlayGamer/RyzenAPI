-- Lua provided by RyzenAPI
-- Game: addappid(1927650)

-- MAIN APPLICATION
addappid(1927650)
addappid(1927760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927651, 1, "301e64d07870f582abbe1d5b4d88928e7cd073c4377556f7c94c677e052626cc")
