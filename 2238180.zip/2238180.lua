-- Lua provided by SkyAPI 
-- Game: Idle Dice 2
addappid(2238180)
addappid(2238181, 1, "4f8bbd5251f3ba60a8107d2c75fd672b46dfd83e92c3a42220d9c310b0c6f3d3")
