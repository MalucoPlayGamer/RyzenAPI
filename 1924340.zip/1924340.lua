-- Lua provided by RyzenAPI
-- Game: Game: King of the Savage Realms

-- MAIN APPLICATION
addappid(1924340)
-- Game: addappid(1924340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924341, 1, "188975b8fdc5f94734d552a03f1e1086871f5346c47b8d6a81df3640c8388ea0")
