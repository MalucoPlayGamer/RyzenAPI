-- Lua provided by RyzenAPI
-- Game: addappid(262240)

-- MAIN APPLICATION
addappid(262240)

-- MAIN APP DEPOTS / PACKAGES
addappid(262241, 1, "4fdfc2eae6ee3d986ac56d3fd1d0e1362b559b1b99b08a33cfdb8aaf164de5b1")
