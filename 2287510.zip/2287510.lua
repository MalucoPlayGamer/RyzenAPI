-- Lua provided by RyzenAPI 
-- Game: KOROMU Auto Battler⭐202020 Demo
addappid(2287510)
addappid(2287511, 1, "dd56d104a270ba0b4d694da95166695ab70ca48a94476dd11c0fb673555810fb")
