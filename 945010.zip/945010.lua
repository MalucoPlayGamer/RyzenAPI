-- Lua provided by RyzenAPI
-- Game: 945010

-- MAIN APPLICATION
addappid(945010)
-- Game: addappid(945010)

-- MAIN APP DEPOTS / PACKAGES
addappid(945010,0,"f5a2d224662a2f6696dedb57563b5120b885c615dd3620ba5d89189a3c7b72cc")
addappid(945012,0,"b1acfe5f338ab17e4fa91a1a6912b322d0b53e8ae71f353c84b3cc042e18634c")
