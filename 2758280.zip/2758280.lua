-- Lua provided by RyzenAPI
-- Game: Game: Boldly Forward

-- MAIN APPLICATION
addappid(2758280)
-- Game: addappid(2758280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758281, 1, "2f18f75d72b3483f8d0dbfd78e73a30da564aa75780ad2dc4bfcb46fc7a607ed")
