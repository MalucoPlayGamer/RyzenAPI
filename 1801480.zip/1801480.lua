-- Lua provided by SkyAPI 
-- Game: VTmini
addappid(1801480)
addappid(1801481, 1, "f39f00485172a5beaf2e1acfd330ecacf0767b899fefae8a67e26a2842ae5ced")
