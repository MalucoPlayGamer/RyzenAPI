-- Lua provided by RyzenAPI
-- Game: VTmini

-- MAIN APPLICATION
addappid(1801480)
-- Game: addappid(1801480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801481, 1, "f39f00485172a5beaf2e1acfd330ecacf0767b899fefae8a67e26a2842ae5ced")
