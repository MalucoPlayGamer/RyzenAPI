-- Lua provided by RyzenAPI
-- Game: Minesweeper

-- MAIN APPLICATION
addappid(4335060)

-- MAIN APP DEPOTS / PACKAGES
addappid(4335062,0,"caf3ca4e577f187def490d4a2b9f78500ecd203c955b8dfd3fafff6b408cb6a0")

