-- Lua provided by RyzenAPI
-- Game: AppID 1005930

-- MAIN APPLICATION
addappid(1005930)
addappid(1986181)
addappid(1986182)
addappid(1986183)
addappid(1986184)
addappid(1986190)
addappid(1986191)
addappid(1986192)
addappid(1986193)
addappid(1986194)
addappid(1986195)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005931, 1, "cbe3839f604d84b24f9c489a5600250b68c3963abebb6d799eb8331693732ab4")
addappid(1184200, 0, "dcbc840a1f929656700e2b86fe98432b66465621b27048331d4b5e31cf0adf34")
addappid(1986180, 0, "d2a0deeb24c7195ec515e7f8c885b8ada200d4657b952a7c40a3966170aa07a4")

