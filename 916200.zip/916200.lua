-- Lua provided by RyzenAPI
-- Game: 916200

-- MAIN APPLICATION
addappid(916200)
-- Game: addappid(916200)

-- MAIN APP DEPOTS / PACKAGES
addappid(916201, 1, "a2ccebf9bf757bc6e0bcdc7a0fd4279ac4be1d9ab160b2d68a8d3b6d2152ccf3")
