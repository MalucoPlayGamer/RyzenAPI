-- Lua provided by RyzenAPI 
-- Game: Hell Shooter
addappid(3181290)
addappid(3181291, 1, "e1ecb3678bb20a72e8b8f32e64f1c03f7f7a5243cbee694f01428ba1985142c9")
