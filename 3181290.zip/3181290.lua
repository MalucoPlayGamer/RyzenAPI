-- Lua provided by RyzenAPI
-- Game: Hell Shooter

-- MAIN APPLICATION
addappid(3181290)
-- Game: addappid(3181290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181291, 1, "e1ecb3678bb20a72e8b8f32e64f1c03f7f7a5243cbee694f01428ba1985142c9")
