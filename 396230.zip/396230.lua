-- Lua provided by RyzenAPI
-- Game: VERSUS: The Lost Ones

-- MAIN APPLICATION
addappid(396230)
addappid(396250)

-- MAIN APP DEPOTS / PACKAGES
addappid(396231, 1, "02203753d3c532e1700b466fdac6178cd8e72ee5607ed29322c89d759f9d9638")
