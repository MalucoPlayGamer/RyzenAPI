-- Lua provided by RyzenAPI
-- Game: NeverBound

-- MAIN APPLICATION
addappid(758660)

-- MAIN APP DEPOTS / PACKAGES
addappid(758661,0,"d5b77064bf40ef16d67965f440c1891dad26682b633c6df9b61fbe834d591f22")

