-- Lua provided by RyzenAPI
-- Game: NeverBound

-- MAIN APPLICATION
addappid(758660)

-- MAIN APP DEPOTS / PACKAGES
addappid(758661,0,"d5b77064bf40ef16d67965f440c1891dad26682b633c6df9b61fbe834d591f22")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
