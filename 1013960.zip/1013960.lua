-- Lua provided by RyzenAPI
-- Game: Open Wheel Manager

-- MAIN APPLICATION
addappid(1013960)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1013961, 1, "d32941a7462930729da46e56b27fdf658dfc437b882abf42cd8c55d93bf45371")

