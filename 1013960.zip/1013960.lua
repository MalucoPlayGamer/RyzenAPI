-- Lua provided by RyzenAPI
-- Game: addappid(1013960)

-- MAIN APPLICATION
addappid(1013960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013961, 1, "d32941a7462930729da46e56b27fdf658dfc437b882abf42cd8c55d93bf45371")
