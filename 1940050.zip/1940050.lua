-- Lua provided by RyzenAPI
-- Game: Tin Can Demo

-- MAIN APPLICATION
addappid(1940050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940051, 1, "b42502817f082d2ac2659c74aeb02eb0a4a48cbb814545c1cca1ad975b8956b6")
