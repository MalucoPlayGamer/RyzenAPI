-- Lua provided by RyzenAPI
-- Game: addappid(991710)

-- MAIN APPLICATION
addappid(991710)

-- MAIN APP DEPOTS / PACKAGES
addappid(991711, 1, "7bc407ff2d113ea895ee22301b5848e22b92fe79c27b93733d8bc5fc0a9fee6c")
