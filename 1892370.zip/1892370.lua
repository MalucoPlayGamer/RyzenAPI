-- Lua provided by RyzenAPI
-- Game: Game: Riding to Bounce City

-- MAIN APPLICATION
addappid(1892370)
-- Game: addappid(1892370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892371, 1, "fd530a98821bdfd81e8b9c1e7d7dd88782886a1906d71f4c9fdf0704467142da")
