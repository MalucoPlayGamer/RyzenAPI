-- Lua provided by RyzenAPI
-- Game: Riding to Bounce City

-- MAIN APPLICATION
addappid(1892370)
addappid(2146750)
addappid(2259570)
addappid(2388760)
addappid(2594650)
addappid(2831090)
addappid(3159490)
addappid(3420370)
addappid(3769540)
addappid(4029730)
addappid(4243000)
addappid(4837010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892371, 1, "fd530a98821bdfd81e8b9c1e7d7dd88782886a1906d71f4c9fdf0704467142da")

