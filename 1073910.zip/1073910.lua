-- Lua provided by RyzenAPI
-- Game: Before We Leave

-- MAIN APPLICATION
addappid(1073910)
-- Game: addappid(1073910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073911, 1, "8258e9623adaa9c7ab3490e5f6eb14d3f1ae41c777b869b9b8061d36db8c6566")
addappid(1073912, 1, "e69788e02f4249a9b71ec886356439475340d2b72e378c6ffbc6b83d6bb68afa")
