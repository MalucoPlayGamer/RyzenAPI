-- Lua provided by RyzenAPI
-- Game: 735360

-- MAIN APPLICATION
addappid(735360)
-- Game: addappid(735360)

-- MAIN APP DEPOTS / PACKAGES
addappid(735361, 1, "7262f1992a755c906609056ba15de6f2f1b8d52d0cd660a7fee09c661c21af02")
