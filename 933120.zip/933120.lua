-- Lua provided by SkyAPI 
-- Game: AppID 933120
addappid(933120)
addappid(933121, 1, "d5d4aa545f1d888d928b31c8c149c5f1d2e03e54ad2273ecde319edd6a4d2993")
