-- Lua provided by RyzenAPI
-- Game: 1184790

-- MAIN APPLICATION
addappid(1184790)
-- Game: addappid(1184790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184799,0,"f149c261053b93e773f2f2d51bede7de60af24c3d4307b29e17ebbbd9471168b")
