-- Lua provided by RyzenAPI
-- Game: Visage — Original Digital Soundtrack

-- MAIN APPLICATION
addappid(938721)

-- MAIN APP DEPOTS / PACKAGES
addappid(938721,0,"237b39e0b35e141f64b5354d0ade640791de2d73b268d60eaed3cec81254a6d9")
