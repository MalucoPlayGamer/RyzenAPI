-- Lua provided by RyzenAPI
-- Game: Bathhouse Creatures

-- MAIN APPLICATION
addappid(3209920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209921, 1, "b0592f2a67efceb374d950783e0b7779e192e4f98dd133658567f8c066063c7d")

