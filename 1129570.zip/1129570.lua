-- Lua provided by RyzenAPI
-- Game: Industry Giant 4.0

-- MAIN APPLICATION
addappid(1129570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1129571, 1, "935ab3832e28a8b5f78e186f4fe8c126614978599d03ccc079bfcb638d5c26cf")
addappid(1129572, 1, "0d775dff9ac37058d65a83ffc37683eefeb59f4f75c3532a7521bd0b13d0e6b2")
addappid(3225390, 0, "1b0d7f0259e77baed39b0ea0bdcd7207bc9e70452ff1e34d95858a78c18dffe0")
addappid(3265360, 0, "5e0c11cbb73a2b13463f8371493e7d790c38d40aa5569cb8162e27e2ca6247c4")

