-- Lua provided by RyzenAPI
-- Game: Little Inferno

-- MAIN APPLICATION
addappid(221260)

-- MAIN APP DEPOTS / PACKAGES
addappid(221261, 1, "e68493843bbe2511c4c66b9c5fa415c124ef22654c026e83631600d3157fad99")
addappid(221262, 1, "ccd18724b1b218524310162463a5140456742831d4252a7247bb6cee0babeca3")
addappid(221263, 1, "d3ff456a53378a3b677787b3879ffb5befb57f52c4daebd683f45a77ee13094b")
addappid(221264, 1, "a59b058eaa14da9cc6583d1114f42017eaa0c0277790096563e456a2f0ebffbc")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2108900)
