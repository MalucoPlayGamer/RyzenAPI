-- 3129360's Lua and Manifest Created by Hubcap Manifest
-- Aksun
-- Created: July 22, 2026 at 06:40:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3129360) -- Aksun
-- MAIN APP DEPOTS
addappid(3129361, 1, "579f108fdfcbed372a729c8eedb1aa0ec19aba2f0ee7d4a9abebd615483a35ff") -- Depot 3129361
setManifestid(3129361, "3676447783109625270", 3831762028)