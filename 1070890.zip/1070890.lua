-- Lua provided by RyzenAPI
-- Game: addappid(1070890)

-- MAIN APPLICATION
addappid(1070890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070891, 1, "396fe4315dd4934b4af7adcbefc38b1baf62e29fa02e76b38553ec2e1119f1cc")
