-- Lua provided by SkyAPI 
-- Game: Weird Hat Fight
addappid(1883820)
addappid(1883821, 1, "ed91b1323dbbab9920aae2be74b7e549e7937ea42dc46c0334f1fb963a7d33be")
