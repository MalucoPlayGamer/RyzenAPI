-- Lua provided by RyzenAPI
-- Game: Weird Hat Fight

-- MAIN APPLICATION
addappid(1883820)
-- Game: addappid(1883820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883821, 1, "ed91b1323dbbab9920aae2be74b7e549e7937ea42dc46c0334f1fb963a7d33be")
