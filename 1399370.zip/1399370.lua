-- Lua provided by SkyAPI 
-- Game: AppID 1399370
addappid(1399370)
addappid(1399371, 1, "851e04839434fe73991b18942179d7b7f511bee6715bfdca202c3aa1b00a0bbc")
addappid(1405520, 0, "68f11baad803747df01cf491913118642331d05ceb46395dae8f8ee5d4da408d")
