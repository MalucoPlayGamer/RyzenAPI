-- Lua provided by RyzenAPI
-- Game: Overlord: Fellowship of Evil

-- MAIN APPLICATION
addappid(306670)

-- MAIN APP DEPOTS / PACKAGES
addappid(306671, 1, "8dff6e287a6bd6e11e1dc559c825b7932eadf96a654645cf91bb1aefb3cbf4cf")
addappid(306672, 1, "2ec78d8f92d4d748cbdd3ef0219f89ad108dd0e25de822ec826bdefa7396049d")
addappid(306673, 1, "72fd9acd373c63b6a78f4db32997ff0682c936a4a914177e3bf1c6644d453862")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(408381)
