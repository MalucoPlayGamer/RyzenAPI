-- Lua provided by SkyAPI 
-- Game: Captain Firehawk and the Laser Love Situation
addappid(2054690)
addappid(2054691, 1, "9eae1ff98817892668a0ecd1a577b0e87b68fa93e96d04fc385e48178227d4f0")
addappid(3103880, 0, "1c8d9bb507f945877934bbbc1313c8027cedf7e6f8ca0beecf00c0526aeaa277")
