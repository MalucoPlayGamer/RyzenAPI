-- Lua provided by RyzenAPI
-- Game: AppID 654990

-- MAIN APPLICATION
addappid(654990)
-- Game: addappid(654990)

-- MAIN APP DEPOTS / PACKAGES
addappid(654991, 1, "cf63245cf2ae57354e8586f91e89c2c8f530522b5058961de64f7cc2434ce72d")
