-- Lua provided by RyzenAPI
-- Game: Out of the Park Baseball 18

-- MAIN APPLICATION
addappid(465650)

-- MAIN APP DEPOTS / PACKAGES
addappid(465651, 1, "4e38f6adb22087a23d1a5c6208b85b9e72a485222a877fa3e8940c0d2f007cf2")
addappid(465654, 1, "a9f19f647c897d1304bf8c60abb5dbe39284af39c562f8004bf8c920255bdd7b")
addappid(465655, 1, "f0764cc02284882c1ba03b9d13d5a82287d6b3c016b3758b18d8ec7636173ffa")
addappid(465656, 1, "7d9d25b51ea7ed49cc3813f9a83ad0818a93a4e22ddeb9db2a4d66c7f36405e2")
