-- Lua provided by RyzenAPI
-- Game: Game: Futanari of the Apocalypse

-- MAIN APPLICATION
addappid(2152080)
-- Game: addappid(2152080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152081, 1, "5a43c2affd3d40b67db9568c740bd59cf37b76df415ba0890d60def4f40f75b8")
