-- Lua provided by RyzenAPI
-- Game: 少侠的江湖

-- MAIN APPLICATION
addappid(2610690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610691, 1, "34771e0728e3d88b7ffa0765fbe784beb6b08ec7b717925cc4ba487e848bb719")

