-- Lua provided by RyzenAPI
-- Game: Disaster Report 4: Summer Memories Demo

-- MAIN APPLICATION
addappid(1272310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272311, 1, "1d78407175274275e5775b3e5180139f4f2886f9f22dab127a8e4c16ed4014b9")
