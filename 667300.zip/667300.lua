-- Lua provided by RyzenAPI
-- Game: aMAZE 3D

-- MAIN APPLICATION
addappid(667300)

-- MAIN APP DEPOTS / PACKAGES
addappid(667301, 1, "98d679bfc52aa646f4a97fece7dede666e11c6694fa18489ae88532f03f93e42")
