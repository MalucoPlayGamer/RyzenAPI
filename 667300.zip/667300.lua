-- Lua provided by RyzenAPI
-- Game: 667300

-- MAIN APPLICATION
addappid(667300)
-- Game: addappid(667300)

-- MAIN APP DEPOTS / PACKAGES
addappid(667301, 1, "98d679bfc52aa646f4a97fece7dede666e11c6694fa18489ae88532f03f93e42")
