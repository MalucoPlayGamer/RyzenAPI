-- Lua provided by RyzenAPI
-- Game: VZX Player

-- MAIN APPLICATION
addappid(981590)
addappid(1129040)
addappid(1180950)
addappid(1332400)
addappid(1812940)
addappid(2470570)
addappid(3598230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(981591, 1, "11a43597239b99fd0bd7d3ea8036ead8a90c3462553e4bd0335a9e1fbf21dedd") -- (windows)
addappid(1129040, 1, "047913978990b523a5328e20b63ba99d6a6301de13a9a63cde9bbaabd5123a00") -- (windows)
addappid(2470570, 1, "6882975df394d1b351342225ae309766e4f8de8cd0ff1fd75e0c6ec0ef5e0550") -- (windows)

