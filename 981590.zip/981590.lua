-- Generated with Luie @ https://lua.tools/
-- 981590 - VZX Player
-- Generated 2026-08-20 02:18:27 UTC
-- # Depots (Total/DLC/Shared): 9/6/2

-- Main AppID
addappid(981590)

-- Main Depots
addappid(981591, 1, "11a43597239b99fd0bd7d3ea8036ead8a90c3462553e4bd0335a9e1fbf21dedd") -- (windows)
setManifestid(981591, "5924857962106280102", 60804405)

-- DLC's (with depot keys)
-- VZX Player - Particle Bliss (AppID: 1129040)
addappid(1129040)
addappid(1129040, 1, "047913978990b523a5328e20b63ba99d6a6301de13a9a63cde9bbaabd5123a00") -- (windows)
setManifestid(1129040, "6996605894068898299", 683777)
-- VZX Player - The Next Generation (AppID: 2470570)
addappid(2470570)
addappid(2470570, 1, "6882975df394d1b351342225ae309766e4f8de8cd0ff1fd75e0c6ec0ef5e0550") -- (windows)
setManifestid(2470570, "5496521957922287016", 175404123)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- Missing Depots (We don't have the keys yet lol): 1180950, 1332400, 1812940, 3598230
