-- Lua provided by RyzenAPI
-- Game: addappid(981590)

-- MAIN APPLICATION
addappid(981590)

-- MAIN APP DEPOTS / PACKAGES
addappid(981591, 1, "11a43597239b99fd0bd7d3ea8036ead8a90c3462553e4bd0335a9e1fbf21dedd")
