-- Lua provided by RyzenAPI
-- Game: My Coloring Book: Food and Beverage

-- MAIN APPLICATION
addappid(763760)

-- MAIN APP DEPOTS / PACKAGES
addappid(763761, 1, "0afcb332e2175ed1502d7005d0a949305fac32ac431dcdf5522f27b8211a00b8")
