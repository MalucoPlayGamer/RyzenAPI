-- Lua provided by RyzenAPI
-- Game: OUBEY VR - Samurai

-- MAIN APPLICATION
addappid(1373310)
-- Game: addappid(1373310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373311, 1, "faa9d12e6df9398d9aef9e6c70ea36e60f1d20b9d41f333bc93a87facce169f9")
