-- Lua provided by RyzenAPI
-- Game: Game: King Kaiju

-- MAIN APPLICATION
addappid(556340)
-- Game: addappid(556340)

-- MAIN APP DEPOTS / PACKAGES
addappid(556341, 1, "75a0101496e3bffcb1811979665cb199fb22d794a8617644477089fe91a641f3")
