-- Lua provided by RyzenAPI
-- Game: Soundodger 2 Soundtrack

-- MAIN APPLICATION
addappid(2340480)
-- Game: addappid(2340480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340481, 1, "fac2278e3573ab9ae07c5f21d94ac4a9f9cf14bb6248c57c83bc2793463100a8")
addappid(2340482, 1, "1c2b36b73e88c0d8bde93d5f72d91002f21c8a9205f0eb82e2a3e3a033d55327")
