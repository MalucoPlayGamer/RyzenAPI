-- Lua provided by RyzenAPI
-- Game: Game: Art Metaverse

-- MAIN APPLICATION
addappid(2224020)
-- Game: addappid(2224020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2224021, 1, "8879c33d6d77331e7fac738ccf66cfa403f3ed508245414f5ecfd5c814b76474")
