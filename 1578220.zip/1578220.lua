-- Lua provided by RyzenAPI
-- Game: 1578220

-- MAIN APPLICATION
addappid(1578220)
addappid(2836560)
-- Game: addappid(1578220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1578221, 1, "02abf18c40a810d2ca7c35ff7a19b961ed0218e59b27497ff85ce9fcba4d8820")
addappid(1578222, 1, "94edc13ef668e841ad8434fcc1ecf5b9c5345b13ff0c5e8d082d1000dfc08dd9")
addappid(1578223, 1, "ec2ba4195c61bca3e3a7b952d125dcc8874673985fa821800896298f818c5f7f")
