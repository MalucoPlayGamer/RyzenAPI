-- Lua provided by RyzenAPI
-- Game: Truck Life

-- MAIN APPLICATION
addappid(1066130)
addappid(1130600)
addappid(1287490)
addappid(1385070)
addappid(1468080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066132,0,"90f07c607592aa3b31b2e7bf53daa561245e251e758f5362398dc20e0a422849")
addappid(1130600,0,"697d5528eac57d580c39643293967b35b7b41fcff5e3f6bb9b59167dfd5df5e0")

