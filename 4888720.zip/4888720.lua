-- Lua provided by RyzenAPI
-- Game: Zombie City Together

-- MAIN APPLICATION
addappid(4888720)

-- MAIN APP DEPOTS / PACKAGES
addappid(4888721,0,"6bdba66c0362b64ab34ed53d3643afa598d90d9a82091bae89e4b757218a853c")

