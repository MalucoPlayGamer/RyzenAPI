-- Lua provided by SkyAPI 
-- Game: Muchi Muchi SEX
addappid(2815750)
addappid(2815751, 1, "89b98b465aa236dad42a8038d17c98ff95129a467ca99ed573c8e9330995c417")
