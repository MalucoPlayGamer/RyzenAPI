-- Lua provided by RyzenAPI
-- Game: Game: Muchi Muchi SEX

-- MAIN APPLICATION
addappid(2815750)
-- Game: addappid(2815750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815751, 1, "89b98b465aa236dad42a8038d17c98ff95129a467ca99ed573c8e9330995c417")
