-- Lua provided by SkyAPI 
-- Game: Rocket Shooter
addappid(451210)
addappid(451211, 1, "a9cd210b2a2afad1cad9e77c9d67a11908aa1d7f6c5cd509ede04278c2a1117f")
