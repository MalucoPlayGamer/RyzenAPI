-- Lua provided by RyzenAPI
-- Game: BLOCKADE 3D

-- MAIN APPLICATION
addappid(302830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(302831, 1, "8c2abf746b9779277d6300a735ca30eabbf055b55552642f03ff0179a0616ef5")

