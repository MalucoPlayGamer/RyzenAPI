-- Lua provided by RyzenAPI
-- Game: Game: BLOCKADE 3D

-- MAIN APPLICATION
addappid(302830)
-- Game: addappid(302830)

-- MAIN APP DEPOTS / PACKAGES
addappid(302831, 1, "8c2abf746b9779277d6300a735ca30eabbf055b55552642f03ff0179a0616ef5")
