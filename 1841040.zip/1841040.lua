-- Lua provided by RyzenAPI
-- Game: Department 42: The Mystery of the Nine

-- MAIN APPLICATION
addappid(1841040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1841041, 1, "ddc18a1a3bbf46698c129be2bc0c8718d4f069c4039f275e7c5a637a21c6d9b8")
addappid(1841046, 1, "0e6e7a353f0b08b11514110cb6221c22fc2b9800ebdb646a7d6cdd3e37032437")

