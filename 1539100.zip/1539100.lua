-- Lua provided by RyzenAPI 
-- Game: Noah's Ark
addappid(1539100)
addappid(1539101, 1, "b6eeaa47a4468b0e6aea364ba78a7484817c9b7bffb484ad556d53a6c797f8fd")
