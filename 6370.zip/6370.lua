-- Lua provided by RyzenAPI
-- Game: Bloodline Champions

-- MAIN APPLICATION
addappid(6370)

