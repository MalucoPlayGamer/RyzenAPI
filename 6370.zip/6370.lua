-- Lua provided by RyzenAPI
-- Game: Bloodline Champions

-- MAIN APPLICATION
addappid(6370)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(223031)
addappid(223032)
addappid(338200)
addappid(338201)
addappid(338202)
