-- Lua provided by RyzenAPI
-- Game: addappid(837530)

-- MAIN APPLICATION
addappid(837530)

-- MAIN APP DEPOTS / PACKAGES
addappid(837531, 1, "b0b1c266ed57c6a48d107233f86b0e782bd0ad00b017561d0ee069a40a88ac16")
