-- Lua provided by SkyAPI 
-- Game: Robots with Guns
addappid(3724340)
addappid(3724341, 1, "f8048cc774509a25c7f0343cecf8cb4fe80aa39411dc8131289ee91a66109d2c")
