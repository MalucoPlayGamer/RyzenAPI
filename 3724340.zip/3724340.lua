-- Lua provided by RyzenAPI
-- Game: Robots with Guns

-- MAIN APPLICATION
addappid(3724340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3724341, 1, "f8048cc774509a25c7f0343cecf8cb4fe80aa39411dc8131289ee91a66109d2c")

