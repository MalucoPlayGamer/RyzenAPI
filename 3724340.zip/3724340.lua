-- Lua provided by RyzenAPI
-- Game: 3724340

-- MAIN APPLICATION
addappid(3724340)
-- Game: addappid(3724340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3724341, 1, "f8048cc774509a25c7f0343cecf8cb4fe80aa39411dc8131289ee91a66109d2c")
