-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1762550)
addappid(1762553)
addappid(1762554)
addappid(1762556)
addappid(1762557)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762552,0,"f6f224340f980d87f3e055310adcbbc359e20547df68167480f17acf759cc929")
addappid(1762555,0,"22246694975b6c5cecca7cdb541d6f05e20d15f8e80a7ffb9806acf18f8c1c0b")

