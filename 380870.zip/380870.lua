-- Lua provided by RyzenAPI
-- Game: Project Zomboid Dedicated Server

-- MAIN APPLICATION
addappid(380870)

-- MAIN APP DEPOTS / PACKAGES
addappid(380871, 1, "ef9aa27f31c5b0b31b47f7fe83401e053867e36007b256eba28828f70c0dfa15")
addappid(380872, 1, "251960db779c1ea7d4e0ed023630b0d4ff43d096776c4fa5f8e078c6689928d9")
addappid(380873, 1, "b741106056424134cc608cdf176a023edccde8212b963ad91cab3b002dd4845f")
addappid(380874, 1, "0b0fbb6d705e20749f454834ccbf0d99a450d79ee1965501917ab9abe8f85ed8")

