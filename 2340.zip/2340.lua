-- Lua provided by RyzenAPI
-- Game: Quake II Mission Pack: Ground Zero

-- MAIN APPLICATION
addappid(2340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341, 1, "1aadf64681ddfcfec7a1f212b12ff28bd93cc0eec1c795891e8f9d4a6063c649")
