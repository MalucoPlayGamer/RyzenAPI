-- Lua provided by RyzenAPI
-- Game: Antrabhara Original Soundtrack

-- MAIN APPLICATION
addappid(2403400)
-- Game: addappid(2403400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403401, 1, "e6d41581faac1a0b6e2c6cc423c8375e8203d6dfcd26f2580b5b8f7329005789")
addappid(2403402, 1, "f912482ada5dd38ccd4110da76b3f233ff3035737b09420757397f86c68a967c")
