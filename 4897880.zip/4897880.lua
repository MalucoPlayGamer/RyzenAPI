-- Lua provided by RyzenAPI
-- Game: 三国群英传之英雄传奇

-- MAIN APPLICATION
addappid(4897880)
