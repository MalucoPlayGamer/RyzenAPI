-- Lua provided by SkyAPI 
-- Game: ENSLAVED™: Odyssey to the West™ Premium Edition
addappid(245280)
addappid(245281, 1, "a6cfce21cc7c15d96ab9b03df6ec106aa8de25c858ebcea5c85e82c6c8fbc6f5")
