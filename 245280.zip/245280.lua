-- Lua provided by RyzenAPI
-- Game: ENSLAVED™: Odyssey to the West™ Premium Edition

-- MAIN APPLICATION
addappid(245280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(245281, 1, "a6cfce21cc7c15d96ab9b03df6ec106aa8de25c858ebcea5c85e82c6c8fbc6f5")

