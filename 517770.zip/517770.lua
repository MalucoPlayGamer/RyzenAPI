-- Lua provided by RyzenAPI
-- Game: Caketomino

-- MAIN APPLICATION
addappid(517770)

-- MAIN APP DEPOTS / PACKAGES
addappid(517771,0,"4c6b4b9689cbaec87fced11b29a5d8bf0e1b320cb7f09438175f1cbace2acf55")

