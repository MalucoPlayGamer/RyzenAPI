-- Lua provided by RyzenAPI
-- Game: Game: AppID 3538880

-- MAIN APPLICATION
addappid(3538880)
-- Game: addappid(3538880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3538881, 1, "9a1ce6e81462a304d5ab1a762c286db81e815dda88e3f774520339581845c5b8")
