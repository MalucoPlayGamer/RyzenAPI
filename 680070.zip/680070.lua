-- Lua provided by RyzenAPI
-- Game: 680070

-- MAIN APPLICATION
addappid(680070)
-- Game: addappid(680070)

-- MAIN APP DEPOTS / PACKAGES
addappid(680071, 1, "eea0951efbe85406f97459294fd6ecb94b409cca5563403cd4b871424341ce80")
