-- Lua provided by RyzenAPI
-- Game: I Just Want to be Single!! Demo

-- MAIN APPLICATION
addappid(1871560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871561, 1, "52de812ec2c81da9e9e8dbb546f45f3947308f9f06c016037c334bbea89dd44e")

