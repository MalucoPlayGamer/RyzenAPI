-- Lua provided by RyzenAPI 
-- Game: ChromaGun 2: Dye Hard Playtest
addappid(3385290)
addappid(3385291, 1, "33544add12f25217798f521540d6568e9fec2d40f206679adc86d3b5cc78c528")
