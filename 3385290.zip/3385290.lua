-- Lua provided by RyzenAPI
-- Game: ChromaGun 2: Dye Hard Playtest

-- MAIN APPLICATION
addappid(3385290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3385291, 1, "33544add12f25217798f521540d6568e9fec2d40f206679adc86d3b5cc78c528")

