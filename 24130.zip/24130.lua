-- Lua provided by RyzenAPI
-- Game: EverQuest: Seeds of Destruction

-- MAIN APPLICATION
addappid(24130)
addappid(24135)

-- MAIN APP DEPOTS / PACKAGES
addappid(24121,0,"35fcb8cb4fdec713121264246da4b225ecd790107db697df4ce07a20ac8753a1")

