-- Lua provided by RyzenAPI
-- Game: FriendShip

-- MAIN APPLICATION
addappid(542110)

-- MAIN APP DEPOTS / PACKAGES
addappid(542111,0,"3f424903504934e72eff2e912a4ea1d518f015f378e5b04931e77a3cd9043fbd")

