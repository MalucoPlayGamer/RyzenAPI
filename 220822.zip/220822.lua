-- Lua provided by RyzenAPI
-- Game: addappid(220822)

-- MAIN APPLICATION
addappid(220822)
addappid(1227810)

-- MAIN APP DEPOTS / PACKAGES
addappid(220822,0,"006f52a678e0480a4cdb2d8c44f5e5718ad44b74169b392d57109bbae46fc570")
