-- Lua provided by RyzenAPI
-- Game: addappid(216210)

-- MAIN APPLICATION
addappid(216210)

-- MAIN APP DEPOTS / PACKAGES
addappid(216211, 1, "02f44ddd7b5222b9fcb5c4babdf9e410b0ab88944de267f78430ba9b211be7d8")
addappid(216212, 1, "8cd400765e23e526784c85c817ca1a47a1dde0364b9e44ed51b2aef1720b2fa9")
addappid(216213, 1, "36ef8c2024cb3dbfdebb5e9257b696d664116c135c3635e4386bb6075b71b937")
addappid(216214, 1, "0a7f0563ad08f0b451ac020bc9b582a0795da7aa85e021deebb0bfa54d94ec5d")
