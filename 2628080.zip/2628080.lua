-- Lua provided by RyzenAPI
-- Game: コスプレリラクゼーション - Cosplay Relaxation -

-- MAIN APPLICATION
addappid(2628080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628081, 1, "16782e6e5502287a5cb71df26187f7f6987a37f5253ee6c556d37828bfb09119")
