-- Lua provided by SkyAPI 
-- Game: Nobodies: Silent Blood
addappid(2994680)
addappid(2994681, 1, "b2bdf48f7787ecf60c1f75c1c99068a7c2eae44813bce91b79dbb700ae8963d2")
