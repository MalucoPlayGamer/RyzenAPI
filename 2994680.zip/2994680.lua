-- Lua provided by RyzenAPI
-- Game: Nobodies: Silent Blood

-- MAIN APPLICATION
addappid(2994680)
-- Game: addappid(2994680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994681, 1, "b2bdf48f7787ecf60c1f75c1c99068a7c2eae44813bce91b79dbb700ae8963d2")
