-- Lua provided by RyzenAPI 
-- Game: Mirthwood
addappid(2272900)
addappid(2272901, 1, "58185efce9e4c852272795c4415161a02c53bbd566dd9cb704dbe8c6f0c797ed")
