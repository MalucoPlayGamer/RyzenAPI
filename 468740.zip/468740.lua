-- Lua provided by RyzenAPI 
-- Game: AppID 468740
addappid(468740)
addappid(468741, 1, "787d6052a572be2e57f44dd29fda7ce9d79145569bd87e21992c1bb840bde8e6")
