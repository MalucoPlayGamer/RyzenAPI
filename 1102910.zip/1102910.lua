-- Lua provided by RyzenAPI
-- Game: FOCUS on YOU - 4K Wallpaper

-- MAIN APPLICATION
addappid(1102910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102910,0,"1e9c931df5c1031349520349398e9bc0b2060fdf832286dc675731ebf22c4061")

