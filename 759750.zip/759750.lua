-- Lua provided by RyzenAPI
-- Game: addappid(759750)

-- MAIN APPLICATION
addappid(759750)

-- MAIN APP DEPOTS / PACKAGES
addappid(759751, 1, "68ca9cf8888bfc5a0a038430890711e6179b9a1fa2d747163dce1580a3afe007")
