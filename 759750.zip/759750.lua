-- Lua provided by RyzenAPI
-- Game: Doodle God: Alchemy Jam

-- MAIN APPLICATION
addappid(759750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(759751, 1, "68ca9cf8888bfc5a0a038430890711e6179b9a1fa2d747163dce1580a3afe007")

