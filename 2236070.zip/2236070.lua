-- Lua provided by RyzenAPI 
-- Game: Peaks of Yore
addappid(2236070)
addappid(2236071, 1, "1d7e3a73711932c1784f68220d6f327144897328e4544d877dd2d24bb94a1ab3")
addappid(3246790, 0, "8b8603831abb43f64f73502caff6792bfce2476614890797f1c09eee65408c64")
