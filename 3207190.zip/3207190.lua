-- Lua provided by RyzenAPI
-- Game: 摧毁模拟器 - 街头判官（Smash simulator）

-- MAIN APPLICATION
addappid(3207190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207191, 1, "8b481b3e94017e5133f7c44dbed18e78220203e14954ecc693d326e57d50390f")

