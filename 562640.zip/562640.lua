-- Lua provided by RyzenAPI
-- Game: Introvert Quest

-- MAIN APPLICATION
addappid(562640)

-- MAIN APP DEPOTS / PACKAGES
addappid(562641, 1, "a956309abe3f7efc1ae269e4436a3ee46941730170b876993a785a47d9ccaadb")

