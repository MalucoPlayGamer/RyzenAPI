-- Lua provided by RyzenAPI
-- Game: addappid(1646840)

-- MAIN APPLICATION
addappid(1646840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646841, 1, "42fad83300f8a6d18e9355add668f28deb2324709bda170d30f66ca835d36779")
