-- Lua provided by SkyAPI 
-- Game: AppID 1646840
addappid(1646840)
addappid(1646841, 1, "42fad83300f8a6d18e9355add668f28deb2324709bda170d30f66ca835d36779")
