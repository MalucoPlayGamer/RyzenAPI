-- Lua provided by SkyAPI 
-- Game: Axegend VR
addappid(1153460)
addappid(1153461, 1, "15d60f0a9f2d4d42234ae0d8f00cb5d3c0673e2b8dd9d3d40ccc64d57d77fefa")
