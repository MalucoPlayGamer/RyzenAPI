-- Lua provided by RyzenAPI
-- Game: Vonbit

-- MAIN APPLICATION
addappid(1900480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1900481, 1, "6999fd6960d2bf0f5bf63bec038617dfd04efac91aad0928830cf7cb2c118cfd")

