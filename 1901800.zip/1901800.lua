-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1901800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901800,0,"dc8552da1e835325cd793b990d9299b4e18dfe90a6e496947cdfb8d316410004")
addappid(1901802,0,"2e6541663b436e516ba274ba8fdce7b4376387f7c8b49073f3cd10a1f4f85240")

