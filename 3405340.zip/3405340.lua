-- Lua provided by RyzenAPI
-- Game: addappid(3405340)

-- MAIN APPLICATION
addappid(3405340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3405342,0,"0fbab2971279bba685debbfa503e2da7e014fb5066cec822fcda80f9465e304e")
