-- Lua provided by RyzenAPI
-- Game: Fidel Dungeon Rescue

-- MAIN APPLICATION
addappid(573170)
-- Game: addappid(573170)

-- MAIN APP DEPOTS / PACKAGES
addappid(573171, 1, "08d06f75d17f8622cd2513e9601810da427dee1b5823af36965af10283c862b7")
addappid(573172, 1, "8cd9c54b001d870f9161e321b09f3cdc2f26edc7b2428430e55d7eac6cac4d9b")
