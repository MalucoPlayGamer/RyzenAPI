-- Lua provided by RyzenAPI
-- Game: 807320

-- MAIN APPLICATION
addappid(807320)

-- MAIN APP DEPOTS / PACKAGES
addappid(807320,0,"b092dafddd3c859e811c0c094d82bdbb3b3b04870faecb5749b9aa78c90edcf9")

