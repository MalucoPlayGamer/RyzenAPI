-- Lua provided by RyzenAPI
-- Game: Solasta: Crown of the Magister - Supporter Pack

-- MAIN APPLICATION
addappid(1438980)
-- Game: addappid(1438980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438980,0,"82e68e4ef18583850066c57d580bc90c49e593a751276f5ee53dcc22b6259dcf")
