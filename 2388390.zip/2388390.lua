-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Vintage House

-- MAIN APPLICATION
addappid(2388390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388391, 1, "2fe4f4a749319449d9e744276cab02fc85e1ccfece649c0238a58d1d1a2d8a12")
