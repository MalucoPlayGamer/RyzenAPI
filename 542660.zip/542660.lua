-- Lua provided by RyzenAPI
-- Game: AppID 542660

-- MAIN APPLICATION
addappid(542660)

-- MAIN APP DEPOTS / PACKAGES
addappid(542661, 1, "5e5c5ff8a1438ca5613cf41aca706a964a6b266a261fa597fc748bee7758c7a5")
addappid(542662, 1, "fd324d507cbc6b6073f7e2cde276111358a1d5b467e579a9f2e3e4a793526704")
addappid(542663, 1, "5396b378afaa22c48b78a03986633e78b05838143db81a1c6e2d813af62801f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
