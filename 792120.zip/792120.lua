-- Lua provided by RyzenAPI
-- Game: FIGHT KNIGHT

-- MAIN APPLICATION
addappid(792120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(792121, 1, "cee42f93b5aa25c84b8a6a224335b0dff4efdd5325e0f2a58004c469f34d1ccb")

