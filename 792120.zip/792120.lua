-- Lua provided by RyzenAPI 
-- Game: FIGHT KNIGHT
addappid(792120)
addappid(792121, 1, "cee42f93b5aa25c84b8a6a224335b0dff4efdd5325e0f2a58004c469f34d1ccb")
