-- Lua provided by RyzenAPI 
-- Game: ANCIENT EVIL
addappid(1341620)
addappid(1341621, 1, "41eec3b535822032a546256aa7fb295cec051f768e43ae6fe10a38d58a966f15")
