-- Lua provided by RyzenAPI
-- Game: Game: Sex Adventures - The Naughty Maid

-- MAIN APPLICATION
addappid(2201240)
-- Game: addappid(2201240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201241, 1, "087fee1c7ab35d6a0aa7174bf1adba8a795265b7728c9ccdd8d6daecfcd808b1")
