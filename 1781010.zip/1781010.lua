-- Lua provided by RyzenAPI
-- Game: Pine Hearts

-- MAIN APPLICATION
addappid(1781010)
addappid(2996940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781011, 1, "665b407db8fad40d2933a69dae8c602621afaa6ec4e21d370d78bbb8dcc324f1")

