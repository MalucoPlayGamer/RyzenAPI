-- Lua provided by RyzenAPI 
-- Game: This World Unknown
addappid(521540)
addappid(521541, 1, "f836820cac5b1d45876a785ccf0b75b43d97743e1fb261681f5c6c2e5e2d7bfe")
