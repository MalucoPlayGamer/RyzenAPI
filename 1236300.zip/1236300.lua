-- Lua provided by RyzenAPI
-- Game: Game: AppID 1236300

-- MAIN APPLICATION
addappid(1236300)
-- Game: addappid(1236300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236301, 1, "d871901d18077503a33843f0aed308396db2824654f75fe5217f6ed3c91f1de7")
