-- Lua provided by RyzenAPI
-- Game: AppID 1236300

-- MAIN APPLICATION
addappid(1236300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236301, 1, "d871901d18077503a33843f0aed308396db2824654f75fe5217f6ed3c91f1de7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1607011)
addappid(1607012)
addappid(1607013)
addappid(1607014)
addappid(1607015)
addappid(1607016)
addappid(1607017)
addappid(1607018)
addappid(1607019)
