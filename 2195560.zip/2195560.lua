-- Lua provided by RyzenAPI
-- Game: 2195560

-- MAIN APPLICATION
addappid(2195560)
-- Game: addappid(2195560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195561, 1, "d87d4faa6bccbf220adca8f5c6d4745a16014f13a166e480698d7e63cb9dc009")
