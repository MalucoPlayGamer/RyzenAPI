-- Lua provided by RyzenAPI
-- Game: Hallowed Pumpkins

-- MAIN APPLICATION
addappid(2195560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2195561, 1, "d87d4faa6bccbf220adca8f5c6d4745a16014f13a166e480698d7e63cb9dc009")

