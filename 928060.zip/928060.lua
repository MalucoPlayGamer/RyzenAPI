-- Lua provided by RyzenAPI
-- Game: Hentai Lady

-- MAIN APPLICATION
addappid(928060)

-- MAIN APP DEPOTS / PACKAGES
addappid(928061, 1, "b6563ab8ea0c8c65927bf0211a146d5b22752cfb9c83f5829cd22ed1666f8e73")
