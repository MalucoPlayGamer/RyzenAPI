-- Lua provided by RyzenAPI
-- Game: 2482450

-- MAIN APPLICATION
addappid(2482450)
-- Game: addappid(2482450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482451, 1, "0e2af2864dc7641f3542abaa22a0a2e117604a0c0069ca3cbe57a453310ba2cc")
