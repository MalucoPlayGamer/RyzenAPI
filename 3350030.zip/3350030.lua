-- Lua provided by RyzenAPI
-- Game: The Permanent Residence : Souls Kept

-- MAIN APPLICATION
addappid(3350030)
-- Game: addappid(3350030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3350031, 1, "59c695f77d04989e7e44537c879a020165a99fb228c301bc82f898426824198c")
