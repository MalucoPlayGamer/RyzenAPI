-- Lua provided by RyzenAPI
-- Game: DANMAKAI: Red Forbidden Fruit

-- MAIN APPLICATION
addappid(1388230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388231, 1, "db42f9836d112149612344d88b6630f6cd8acea678766035e1c77717e48dffac")

