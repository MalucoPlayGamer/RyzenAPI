-- Lua provided by RyzenAPI
-- Game: DANMAKAI: Red Forbidden Fruit

-- MAIN APPLICATION
addappid(1388230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388231, 1, "db42f9836d112149612344d88b6630f6cd8acea678766035e1c77717e48dffac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
