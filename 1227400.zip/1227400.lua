-- Lua provided by SkyAPI 
-- Game: Over the Alps
addappid(1227400)
addappid(1227401, 1, "6f9447b3b23e2c92a076e2147a25bc82ac8de1f80e4b57a4fb5ff4bd364f0559")
