-- Lua provided by RyzenAPI
-- Game: Foxy Tales

-- MAIN APPLICATION
addappid(2609490)
addappid(2628630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2609491, 1, "faaeeae7ebc51446d2fa3ecbbd62ddb299e21eef8eed49b6bce5efb19522e1ed")

