-- 4911470's Lua and Manifest Created by Hubcap Manifest
-- FRESHIE SISTERS
-- Created: August 27, 2026 at 13:30:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4911470) -- FRESHIE SISTERS
-- MAIN APP DEPOTS
addappid(4911471, 1, "335043a525447f62f6b85458d00c80d359efb1c8885e6b21b97eee8ec028d9bb") -- Depot 4911471
setManifestid(4911471, "5041628558896065881", 1402246131)
addappid(4911472, 1, "7194d204504f939d30efe4c1d6434251ac92c31db832bb3a8d876990d748be21") -- Depot 4911472
setManifestid(4911472, "1737343145343754789", 1390714789)