-- Lua provided by RyzenAPI
-- Game: MangaKa

-- MAIN APPLICATION
addappid(2234500) -- MangaKa
addappid(2340220) -- MangaKa - Import 3D Pack
addappid(2340240) -- MangaKa - Advance Poser Pack
addappid(2340241) -- MangaKa - 2D Tool Kit
addappid(2340242) -- MangaKa - Rocks  Nature Pack
addappid(2340243) -- MangaKa - Modern World Pack
addappid(2340244) -- MangaKa - Ancient  Fantasy Pack
addappid(2340245) -- MangaKa - Sci-fi  Post Apocalypse Pack
addappid(2668790) -- MangaKa - Pen Tool

-- MAIN APP DEPOTS / PACKAGES
addappid(2234501, 1, "69c78226c8cb2c52f207ef26622a60602000daa7a828cdd4b8e95463c813e79d") -- Depot 2234501
