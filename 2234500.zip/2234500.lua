-- Lua provided by RyzenAPI
-- Game: 2234500

-- MAIN APPLICATION
addappid(2234500)
-- Game: addappid(2234500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234501, 1, "69c78226c8cb2c52f207ef26622a60602000daa7a828cdd4b8e95463c813e79d")
