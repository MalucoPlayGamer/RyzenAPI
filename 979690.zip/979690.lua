-- Lua provided by RyzenAPI
-- Game: The Ascent

-- MAIN APPLICATION
addappid(979690)
addappid(1690300)
addappid(1698300)
addappid(1792190)
addappid(1802450)
addappid(1802451)
addappid(1802452)
addappid(1802470)
addappid(1826620)
addappid(3896950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(979691,0,"8f6782f423cd2844f6369c96e17e6778495eb7c864d0e32f401fae10868fe04b")
addappid(979692,0,"2ba23f9748f7b6c1f04f4fbf6fc25d44d62e8cc4a27232c0bd32045133fc4a8a")

