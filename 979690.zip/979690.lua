-- Lua provided by RyzenAPI
-- Game: The Ascent

-- MAIN APPLICATION
addappid(979690)

-- MAIN APP DEPOTS / PACKAGES
addappid(979691, 1, "8f6782f423cd2844f6369c96e17e6778495eb7c864d0e32f401fae10868fe04b")
addappid(979692, 1, "2ba23f9748f7b6c1f04f4fbf6fc25d44d62e8cc4a27232c0bd32045133fc4a8a")

