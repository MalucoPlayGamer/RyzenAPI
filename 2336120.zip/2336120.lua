-- Lua provided by RyzenAPI
-- Game: addappid(2336120)

-- MAIN APPLICATION
addappid(2336120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336121, 1, "91660eb8c356561b7e73371e27441d9cbab825eb54fbd661315da18ea450126a")
