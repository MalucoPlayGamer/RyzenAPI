-- Lua provided by RyzenAPI
-- Game: Game: Country Park

-- MAIN APPLICATION
addappid(890800)
-- Game: addappid(890800)

-- MAIN APP DEPOTS / PACKAGES
addappid(890801, 1, "08c8fa54f9fc69612714544688b7d80134e11752e4c1135879189f67e22d7bb7")
