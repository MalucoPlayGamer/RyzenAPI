-- Lua provided by RyzenAPI
-- Game: Game: 轮回之理-MOBIUS THEORY

-- MAIN APPLICATION
addappid(1925830)
-- Game: addappid(1925830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925831, 1, "ff6bd360704f94d42bdb086af28405e047b6211d60f52a6a702fe956bd58164b")
