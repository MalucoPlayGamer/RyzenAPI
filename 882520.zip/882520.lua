-- Lua provided by RyzenAPI
-- Game: 882520

-- MAIN APPLICATION
addappid(882520)
-- Game: addappid(882520)

-- MAIN APP DEPOTS / PACKAGES
addappid(882521, 1, "6fcc639a7938709942ba1d84682d84a733820a445504dbdbf403485a67d67f4f")
