-- Lua provided by RyzenAPI
-- Game: Aegis of Earth: Protonovus Assault

-- MAIN APPLICATION
addappid(450250)

-- MAIN APP DEPOTS / PACKAGES
addappid(450251, 1, "3c13e4948caecdd04b24292e97045e81223458be93941390190ec576f3287f9b")

