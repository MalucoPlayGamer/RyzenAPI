-- Lua provided by RyzenAPI
-- Game: Game: Car Physics Simulator

-- MAIN APPLICATION
addappid(1675090)
-- Game: addappid(1675090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675091, 1, "415efa404a1118e75a30f2ecf124a9e20da1c377624002b252186b91065e6064")
