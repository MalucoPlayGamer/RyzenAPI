-- Lua provided by RyzenAPI 
-- Game: Warehouse and Logistics Simulator
addappid(273940)
addappid(273941, 1, "3c1869e3427b534e555bbbe4370ec8a5f327755bd36e00cc2f807806df51d79c")
addappid(282550)
