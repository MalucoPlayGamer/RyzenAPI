-- Lua provided by RyzenAPI
-- Game: Perfect Heist

-- MAIN APPLICATION
addappid(787040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(787041, 1, "8e1b399208f92c18d1de06cfa3f28c3d9a8d311b20c3fc46ff1e71bf58b281e7")

