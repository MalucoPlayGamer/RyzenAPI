-- Lua provided by RyzenAPI
-- Game: Perfect Heist

-- MAIN APPLICATION
addappid(787040)

-- MAIN APP DEPOTS / PACKAGES
addappid(787041, 1, "8e1b399208f92c18d1de06cfa3f28c3d9a8d311b20c3fc46ff1e71bf58b281e7")

