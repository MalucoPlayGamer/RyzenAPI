-- Lua provided by RyzenAPI
-- Game: addappid(1953070)

-- MAIN APPLICATION
addappid(1953070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953071, 1, "bf0861939a6688a9292b5f5d24a75d8dc8fb16c1c76caf5c589c0de99c390546")
