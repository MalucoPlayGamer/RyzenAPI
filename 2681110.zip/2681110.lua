-- Lua provided by RyzenAPI
-- Game: Gunner Girl 女枪手

-- MAIN APPLICATION
addappid(2681110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681111, 1, "c54e0224471f3f3a21588e3c9bc163240eb446dc977e67cf81325f1bcea05612")

