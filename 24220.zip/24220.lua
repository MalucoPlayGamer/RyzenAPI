-- Lua provided by RyzenAPI
-- Game: Everquest: House of Thule

-- MAIN APPLICATION
addappid(24220)

-- MAIN APP DEPOTS / PACKAGES
addappid(24121,0,"35fcb8cb4fdec713121264246da4b225ecd790107db697df4ce07a20ac8753a1")

