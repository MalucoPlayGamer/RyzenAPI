-- Lua provided by RyzenAPI 
-- Game: Touhou: Fearless Frogslayer
addappid(3218680)
addappid(3218681, 1, "3fb13dbb1d6f600b0edf6f6121ce5c5668f42a01d2d0fe11547893f433403ef8")
