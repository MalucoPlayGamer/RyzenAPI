-- Lua provided by RyzenAPI
-- Game: 1506850

-- MAIN APPLICATION
addappid(1506850)
-- Game: addappid(1506850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506851, 1, "93a4dd865b099a328129a06d28448c54fa5fc6cbf63b89e0bb7a1de72aa53166")
