-- Lua provided by SkyAPI 
-- Game: Night Bus
addappid(2820800)
addappid(2820801, 1, "bee2fc5ea1cfbf6c2dce2e4b597c858ea4b39eaccef2337e7ec93a1a40b2f2dd")
