-- Lua provided by RyzenAPI
-- Game: Night Bus

-- MAIN APPLICATION
addappid(2820800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820801, 1, "bee2fc5ea1cfbf6c2dce2e4b597c858ea4b39eaccef2337e7ec93a1a40b2f2dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
