-- Lua provided by RyzenAPI
-- Game: Traversing Traveler

-- MAIN APPLICATION
addappid(1568500)
-- Game: addappid(1568500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568501, 1, "ecec555aaa80f1b78687deb25c69ec09e31d8b629e74dd53b277b2fe51f429ee")
