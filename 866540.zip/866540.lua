-- Lua provided by RyzenAPI
-- Game: VR Flush

-- MAIN APPLICATION
addappid(866540)

-- MAIN APP DEPOTS / PACKAGES
addappid(866544,0,"845f003b1eb454a2542cb404370abcb573aef081bde0bf7605cef4c3439c3470")
addappid(866545,0,"f5d2a9168813fc380c2513eebfabd4ee6c0a245afbaa5956693f3b8ac896a30a")
addappid(866548,0,"2470200a98d4c79a5df8059f938c0c5660a606428c4486f722b25f2da071604a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(946310)
