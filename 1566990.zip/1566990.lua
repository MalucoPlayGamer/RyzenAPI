-- Lua provided by RyzenAPI
-- Game: 1566990

-- MAIN APPLICATION
addappid(1566990)
-- Game: addappid(1566990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566991, 1, "c412f27a4e550d6c46181a0108ddeedaf3597dc3c27e900d8bfea1699af3c75e")
addappid(1566992, 1, "68c87e98e256f61b34cdc87afe6e6faab53058be10f568825ab95a87b834892c")
