-- Lua provided by RyzenAPI
-- Game: I Am Sakuya: Touhou FPS Game

-- MAIN APPLICATION
addappid(1960590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960591, 1, "1b648093a6f1a44d777e559e6ac7f5c6d729067ca35af0fa308c282e7e158baa")
addappid(2239300, 0, "fcb54006dac7daec4175a41789107638d794602372273b31a1b44ba655e9d3a6")

