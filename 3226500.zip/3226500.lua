-- Lua provided by RyzenAPI
-- Game: Game: AppID 3226500

-- MAIN APPLICATION
addappid(3226500)
-- Game: addappid(3226500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226501, 1, "68d2e432ef3d9ad69b19e670b9398d1effed15d09864c7b34e8829401072c8a1")
