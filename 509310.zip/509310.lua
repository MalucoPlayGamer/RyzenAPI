-- Lua provided by RyzenAPI
-- Game: ThrounnelVR

-- MAIN APPLICATION
addappid(509310)

-- MAIN APP DEPOTS / PACKAGES
addappid(509311, 1, "d88dd845412be4f34097347ef7c2fa69fd8c17f046eae238cfa5cfc2a73295f5")
