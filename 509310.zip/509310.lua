-- Lua provided by RyzenAPI
-- Game: ThrounnelVR

-- MAIN APPLICATION
addappid(509310)

-- MAIN APP DEPOTS / PACKAGES
addappid(509311, 1, "d88dd845412be4f34097347ef7c2fa69fd8c17f046eae238cfa5cfc2a73295f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
