-- Lua provided by RyzenAPI
-- Game: Total CATastrophe

-- MAIN APPLICATION
addappid(1877930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877931, 1, "5aca5172d53aca44afca8abe499748edf1cc2814a371ba704ab696b62a114113")
