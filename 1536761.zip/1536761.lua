-- Lua provided by RyzenAPI
-- Game: FUSER™ - Tiësto - "Red Lights"

-- MAIN APPLICATION
addappid(1536761)
-- Game: addappid(1536761)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536761,0,"fee397d2f2624c39db580b4837a028fd1d86b36c1c35bfd94a546aadf5386550")
