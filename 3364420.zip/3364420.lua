-- Lua provided by RyzenAPI
-- Game: 3364420

-- MAIN APPLICATION
addappid(3364420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3364420,0,"f1e157a4d939a27a8bef03217e34a02fb1bacc98f75c95a663c50ae0aa61db7d")
