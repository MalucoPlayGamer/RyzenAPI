-- Lua provided by RyzenAPI
-- Game: AppID 511690

-- MAIN APPLICATION
addappid(511690)
-- Game: addappid(511690)

-- MAIN APP DEPOTS / PACKAGES
addappid(511691, 1, "fbab422334ffffd171e4485558b57b9187df53ea527f3a95b0ad5056c61188c0")
