-- Lua provided by RyzenAPI
-- Game: The Mutational

-- MAIN APPLICATION
addappid(652780)
addappid(1190240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(652781, 1, "d8cb7c0eaa6df1ceea431e85b764467ddba94db717329e4c24f3f42dc08f7611")

