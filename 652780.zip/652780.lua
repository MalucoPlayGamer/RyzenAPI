-- Lua provided by RyzenAPI 
-- Game: The Mutational
addappid(652780)
addappid(652781, 1, "d8cb7c0eaa6df1ceea431e85b764467ddba94db717329e4c24f3f42dc08f7611")
addappid(1190240)
