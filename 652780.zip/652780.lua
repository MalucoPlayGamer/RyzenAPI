-- Lua provided by RyzenAPI
-- Game: The Mutational

-- MAIN APPLICATION
addappid(652780)
addappid(1190240)

-- MAIN APP DEPOTS / PACKAGES
addappid(652781, 1, "d8cb7c0eaa6df1ceea431e85b764467ddba94db717329e4c24f3f42dc08f7611")

