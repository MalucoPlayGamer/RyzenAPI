-- Lua provided by RyzenAPI
-- Game: 2012150

-- MAIN APPLICATION
addappid(2012150)
-- Game: addappid(2012150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012151, 1, "111b814efee8aef5fbef420ceaca9443f8a8fff565aa00d6469bf75ca5d191e2")
