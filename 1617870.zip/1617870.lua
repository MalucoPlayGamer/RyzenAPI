-- Lua provided by RyzenAPI
-- Game: Chef: Eastern Asian Cuisine

-- MAIN APPLICATION
addappid(1617870)
-- Game: addappid(1617870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617871, 1, "68c4afa157147910a41ee8778af66e9f9372848395b0df2035df58f94f03483e")
