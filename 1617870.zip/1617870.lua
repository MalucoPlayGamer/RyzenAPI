-- Lua provided by SkyAPI 
-- Game: Chef: Eastern Asian Cuisine
addappid(1617870)
addappid(1617871, 1, "68c4afa157147910a41ee8778af66e9f9372848395b0df2035df58f94f03483e")
