-- Lua provided by RyzenAPI
-- Game: AppID 1121490

-- MAIN APPLICATION
addappid(1121490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121491, 1, "7cb21e7a003f9fe45427ef3171b4e82d6e9254c3b1f52e1ea1d166f8c1a8ee4d")

