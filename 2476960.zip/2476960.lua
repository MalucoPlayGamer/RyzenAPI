-- Lua provided by RyzenAPI 
-- Game: Death Slayer
addappid(2476960)
addappid(2476961, 1, "83464287c56e0a8de484b57274c571a68b3f330809ec857096fc6c04a7e38133")
addappid(2476962, 1, "3569f802478b76ae74ed1be3fef7a561b081c94e14b095e0597a64194c7b27d7")
