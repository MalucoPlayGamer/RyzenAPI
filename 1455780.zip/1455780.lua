-- Lua provided by RyzenAPI
-- Game: 1455780

-- MAIN APPLICATION
addappid(1455780)
-- Game: addappid(1455780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455782,0,"a04651ce915864e19dca37d592b08fa170d5cd6487dcbd4a28c033aa296f993d")
