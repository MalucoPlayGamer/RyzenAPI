-- Lua provided by RyzenAPI
-- Game: Game: Teenage Mutant Ninja Turtles: Shredder's Revenge

-- MAIN APPLICATION
addappid(1361510)
-- Game: addappid(1361510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361511, 1, "5954562e7f5260400040a818bc29b60b335bb690066ff767e20d145a3b6b4af0")
addappid(1361512, 1, "9018b1f82166ad29381fd77a36a5ffe47a907a20408c0f20f74799537c9a9d11")
addappid(2348930, 0, "cd65db36fbcdc7c86ada27a6e96064807a6576a135f2ac7a4cb204d11173ca26")
