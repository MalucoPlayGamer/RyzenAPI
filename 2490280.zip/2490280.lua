-- Lua provided by RyzenAPI
-- Game: AppID 2490280

-- MAIN APPLICATION
addappid(2490280)
-- Game: addappid(2490280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490281, 1, "27aef986007c1633cc9491eb908bd6143b617e9b015b0e441f1a5087ca8318ec")
