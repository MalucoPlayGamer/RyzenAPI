-- Lua provided by RyzenAPI
-- Game: Zombies Rocket Boom Boom

-- MAIN APPLICATION
addappid(2221070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221071, 1, "17d6680f111a49d1d6f73604c6e3fc86d62c69de03e09d4c2d6a203407b104d1")

