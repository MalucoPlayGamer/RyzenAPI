-- Lua provided by SkyAPI 
-- Game: Fairy Hunter
addappid(2407070)
addappid(2407071, 1, "4bc4a3302ec88c86f2b769a0a620501e89b7f7aef54853f31048e79d35c5d772")
