-- Lua provided by RyzenAPI
-- Game: Game: Fairy Hunter

-- MAIN APPLICATION
addappid(2407070)
-- Game: addappid(2407070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407071, 1, "4bc4a3302ec88c86f2b769a0a620501e89b7f7aef54853f31048e79d35c5d772")
