-- Lua provided by RyzenAPI
-- Game: AppID 1134710

-- MAIN APPLICATION
addappid(1134710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134711, 1, "e4c5307d44d1e6057d21c3828bc766b625266bc61281e682b3ace83b0612f7d0")
addappid(1134712, 1, "6aca6ce3dd1188b29e3251d88aeef183ffd6bfe5f89260be29c375811ba92903")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
