-- Lua provided by RyzenAPI
-- Game: AppID 951820

-- MAIN APPLICATION
addappid(951820)
-- Game: addappid(951820)

-- MAIN APP DEPOTS / PACKAGES
addappid(951821, 1, "ca290c239d24db9ebe3b90e4b1a2b86f32a87801eaf810c67d7a00683c6a55cf")
