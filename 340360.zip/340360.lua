-- Lua provided by RyzenAPI
-- Game: 340360

-- MAIN APPLICATION
addappid(340360)
-- Game: addappid(340360)

-- MAIN APP DEPOTS / PACKAGES
addappid(340361, 1, "f23f8fe306ffe3da92a0a5dceeb23681eac9fb951fca5f57aad4f542f5619df7")
addappid(340362, 1, "accd5c705f72da5c37f4a80dbf948f3db3d8ee582bf43747899d23a2d5253e25")
addappid(340363, 1, "9aea344f9c29a2710e711724ef276946fa3bb4410e7a229d0b9c01609bd17a52")
addappid(340364, 1, "a513ae3a89bfaaf3a9e12de69919b1f2ab2191b35bee84725d453601adf17d1a")
addappid(340365, 1, "3daf2299526f2da9b76f7b0c150a1dc86d56d36edb6d418934a1a414ce7a85d9")
