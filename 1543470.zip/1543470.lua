-- Lua provided by RyzenAPI
-- Game: Game: AppID 1543470

-- MAIN APPLICATION
addappid(1543470)
-- Game: addappid(1543470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543471, 1, "d1c9745dcecc9bbb957ff7a82442c08c56edd0022a57ab555a7b7fbb199e53a2")
