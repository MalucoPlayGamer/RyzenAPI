-- Lua provided by RyzenAPI
-- Game: AppID 1148450

-- MAIN APPLICATION
addappid(1148450)
-- Game: addappid(1148450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148451, 1, "1fa1458e3682a6c5c099f7b89611b1e68a7aae4f2501da16b6f3f1bb82847042")
