-- Lua provided by RyzenAPI
-- Game: The Warlin of Heroes

-- MAIN APPLICATION
addappid(1335300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1335301, 1, "44bb7b3a4b4a67e28a0d2cc9c767faf8422752e823d6adc1c51b0bce7624cfd4")

