-- Lua provided by RyzenAPI
-- Game: The Warlin of Heroes

-- MAIN APPLICATION
addappid(1335300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335301, 1, "44bb7b3a4b4a67e28a0d2cc9c767faf8422752e823d6adc1c51b0bce7624cfd4")
