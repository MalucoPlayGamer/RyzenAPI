-- Lua provided by RyzenAPI
-- Game: Game: AppID 1330100

-- MAIN APPLICATION
addappid(1330100)
-- Game: addappid(1330100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330101, 1, "a31cbd79257353d817d1797ef1e1105e9daf7d9527c320a850888ea7443db5c5")
