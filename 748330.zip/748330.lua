-- Lua provided by RyzenAPI
-- Game: 748330

-- MAIN APPLICATION
addappid(748330)
addappid(748331)
addappid(748333)
addappid(748334)
addappid(748335)
addappid(1190440)

-- MAIN APP DEPOTS / PACKAGES
addappid(748332,0,"182f9a82c81af70af2e83bb0e37ae6fec79f89156663d691bea0aaa092e11a9b")

