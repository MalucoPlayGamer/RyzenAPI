-- Lua provided by SkyAPI 
-- Game: Eternal Tombs Playtest
addappid(2265330)
addappid(2265331, 1, "47dc0cc1d37a51a0b0db6737f091419c4bada5cba0a3a8621abb15eacf7f0727")
