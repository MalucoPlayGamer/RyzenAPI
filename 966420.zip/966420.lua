-- Lua provided by RyzenAPI
-- Game: Hell Breaker

-- MAIN APPLICATION
addappid(966420)

-- MAIN APP DEPOTS / PACKAGES
addappid(966421, 1, "db92f47da2437276e90409eb86e71b8cfd8a7298a3819fca7f081bf4afc72ed9")

