-- Lua provided by RyzenAPI
-- Game: AppID 1096310

-- MAIN APPLICATION
addappid(1096310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096311, 1, "16a1ea4df9a58981b90f729a46a3530568764f876ef097140863e216cb4f3314")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
