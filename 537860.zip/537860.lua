-- Lua provided by RyzenAPI
-- Game: Game: AppID 537860

-- MAIN APPLICATION
addappid(537860)
-- Game: addappid(537860)

-- MAIN APP DEPOTS / PACKAGES
addappid(537861, 1, "fa00261b0c1e82c84a93dac9715b9f0a791ea76b1c6e8a2981fef53dc6f26abe")
