-- Lua provided by RyzenAPI
-- Game: addappid(72780)

-- MAIN APPLICATION
addappid(72780)

-- MAIN APP DEPOTS / PACKAGES
addappid(72782,0,"e85300bc727004bce036f1234decae2593241596f4353e1765f1a6ad8aecf018")
