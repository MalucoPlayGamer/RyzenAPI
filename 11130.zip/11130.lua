-- Lua provided by RyzenAPI
-- Game: Sherlock Holmes: The Mystery of the Mummy

-- MAIN APPLICATION
addappid(11130)
addappid(228990)
-- Game: addappid(11130)

-- MAIN APP DEPOTS / PACKAGES
addappid(11131, 1, "5c4a2f262344af768b14aca0ef999c9b2769b76406bab3e2a544fb0ef3a01532")
addappid(11132, 1, "d82362326832aa5a90c9d12196317c8a4d6c021935ceb406077c1eba3a623668")
addappid(11133, 1, "147c075d9d918cee3d40ad10b2ffe711c0e4e56930b646d1e0128bf8c9b93db9")
addappid(11134, 1, "4f80503d0335e44603c34962fd73c46c93d0ea9c07f6fe6a3db9aeb4744f1b7b")
addappid(11135, 1, "2341cf4fe94ca305514048cc15c395e7bbd05e3118420f61efeda733f7e1aee0")
addappid(11136, 1, "55fdadaff48120177aa8f73d4fbed9860ddb683856b8f55377e7fed5e3d4692e")
addappid(11137, 1, "23d8c95a54f304c617f3d2e472818d9c656fdff5e80272673e7842135972e2c7")
addappid(11138, 1, "7f74ad859964582c323e3a0ca4e65c1bc337bfc121b62b62e9d872eb8d26cd57")
addappid(11139, 1, "1ce81febf5f6dbca41d2277c1eabf5ca25c51660a3f28753b54095b407514503")
