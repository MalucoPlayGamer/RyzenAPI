-- Lua provided by RyzenAPI
-- Game: 1831630

-- MAIN APPLICATION
addappid(1831630)
-- Game: addappid(1831630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831631, 1, "d7e0df3eaa889971f36c22ed8c618e157c82cbcdbfdf519844bbd33013518571")
