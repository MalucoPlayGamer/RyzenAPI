-- Lua provided by RyzenAPI
-- Game: 683940

-- MAIN APPLICATION
addappid(683940)
-- Game: addappid(683940)

-- MAIN APP DEPOTS / PACKAGES
addappid(683941, 1, "a389920cfd3406eac0e91526d347c0bb49582682b3de488af2fac3f444b8516e")
