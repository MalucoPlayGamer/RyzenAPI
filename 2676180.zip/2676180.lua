-- Lua provided by RyzenAPI
-- Game: Game: Fog of War: Book One

-- MAIN APPLICATION
addappid(2676180)
-- Game: addappid(2676180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676181, 1, "fb6093251a4aff67b07eb26ce565a8bf20f3a6adfb55105a0646be9fe2d871fd")
