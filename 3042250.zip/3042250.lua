-- Lua provided by RyzenAPI
-- Game: Her Last Piece

-- MAIN APPLICATION
addappid(3042250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042251, 1, "644b0beed3b491a692a4f916696db56fc45bc2c829e84e4ff6ffe7bba5803906")
