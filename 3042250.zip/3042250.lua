-- Lua provided by SkyAPI 
-- Game: Her Last Piece
addappid(3042250)
addappid(3042251, 1, "644b0beed3b491a692a4f916696db56fc45bc2c829e84e4ff6ffe7bba5803906")
