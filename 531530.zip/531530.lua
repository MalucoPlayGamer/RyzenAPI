-- Lua provided by RyzenAPI
-- Game: Polygod

-- MAIN APPLICATION
addappid(531530)

-- MAIN APP DEPOTS / PACKAGES
addappid(531531, 1, "61d330302929186ed8d1a423abe3df7446638a20a4bb0baa88d6209d3cba6100")
