-- Lua provided by RyzenAPI
-- Game: Gaiadon: Eternal Quest

-- MAIN APPLICATION
addappid(3000030)
addappid(3844680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3000031, 1, "30f52045cbc682c2ab5be9c7801f76bc6cad9bc0ba58b4857fa7329cf4b37d9f")
