-- Lua provided by RyzenAPI
-- Game: 2935280

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2935280)
addappid(2935281)
addappid(2935282)
addappid(2935284)
-- Game: addappid(2935280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2935283,0,"8637fc0ea396c9b71a825e127b31c3eda141ffe786fa536787e1553fbe29640f")
