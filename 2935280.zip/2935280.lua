-- Lua provided by RyzenAPI
-- Game: Zector 7

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2935280)
addappid(2935281)
addappid(2935282)
addappid(2935284)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2935283,0,"8637fc0ea396c9b71a825e127b31c3eda141ffe786fa536787e1553fbe29640f")

