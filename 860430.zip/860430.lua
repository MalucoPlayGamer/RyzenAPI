-- Lua provided by RyzenAPI
-- Game: Burgerwise the Clown

-- MAIN APPLICATION
addappid(860430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(860431, 1, "074fd8aeffce6e4f1cd60ebe36376eb20c773d41d5c62fcc2480aa565351bee1")

