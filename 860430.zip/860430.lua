-- Lua provided by RyzenAPI
-- Game: 860430

-- MAIN APPLICATION
addappid(860430)
-- Game: addappid(860430)

-- MAIN APP DEPOTS / PACKAGES
addappid(860431, 1, "074fd8aeffce6e4f1cd60ebe36376eb20c773d41d5c62fcc2480aa565351bee1")
