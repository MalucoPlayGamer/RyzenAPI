-- Lua provided by RyzenAPI
-- Game: Hereafter

-- MAIN APPLICATION
addappid(652330)

-- MAIN APP DEPOTS / PACKAGES
addappid(652331, 1, "4c7dda8994bc7c0d56c40419fe33a9c08413b1bd9b077cfe3fbc065e547ec726")
