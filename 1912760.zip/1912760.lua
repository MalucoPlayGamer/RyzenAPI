-- Lua provided by RyzenAPI
-- Game: 1912760

-- MAIN APPLICATION
addappid(1912760)
-- Game: addappid(1912760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912761, 1, "ad69ada7aa0e311004e2be1ca5ce72ab52abb78f3e6c0c3e9c3ed3ae0c009a9d")
