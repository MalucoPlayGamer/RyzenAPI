-- 3586450's Lua and Manifest Created by Hubcap Manifest
-- World Tree Ranch: Elven Legacy
-- Created: August 13, 2026 at 11:13:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3586450, 1, "780eaf6dfebaa2fb125744887d379e26e2b8a48b97c7daab6ec5e3813729ee7d") -- World Tree Ranch: Elven Legacy
-- MAIN APP DEPOTS
addappid(3586451, 1, "28a10188bee52e40b97da36060893e1dfe05015c46986c72d4e43a9ae7bb57c7") -- Depot 3586451
setManifestid(3586451, "8418486258313087479", 456366855)
addappid(3586452, 1, "7974b74fcce8b6565aa461a15c40f09477331f629793c884c5d2b416336fdbe7") -- Depot 3586452
setManifestid(3586452, "14360287496100415", 458812977)
addappid(3586453, 1, "1b68e4d43be66f73dab156c01eeca78b3c333145fed15e8b88e6bec5b1320ab8") -- Depot 3586453
setManifestid(3586453, "2665516800118573482", 456362305)