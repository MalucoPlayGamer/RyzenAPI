-- Lua provided by RyzenAPI
-- Game: Deadlock

-- MAIN APPLICATION
addappid(1422450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422451, 1, "5e41412d5525ec19c3b35b0e7394dd394f3afe8a0a40d308fddf6486c5d5f19a")
addappid(1422452, 1, "cec8fb9b3514cdd7394110792bcfdb6b07903f136c0df1f81d7b94b02dc6ca89")
addappid(1422456, 1, "e615f3146e84f310bda59c806c74be74c86d1b81aa2b143e8e00a414ac279868")

