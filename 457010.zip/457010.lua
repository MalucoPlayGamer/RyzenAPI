-- Lua provided by RyzenAPI
-- Game: Game: StarsOne

-- MAIN APPLICATION
addappid(457010)
-- Game: addappid(457010)

-- MAIN APP DEPOTS / PACKAGES
addappid(457011, 1, "a2fbc6ab4249ba13f7fbe8dfb51a32a82b21f06e5157d34d06d55ad4baf53449")
addappid(457012, 1, "f5ca67c896efe388c5b6e15f13a1810d4e7d7ca96ef2a8b0fa03001ccc860afb")
addappid(457013, 1, "c40c36c6eab46cf89f491de2f6e5f5dd26bd996624ea361cad72fdb0f71608b0")
addappid(457014, 1, "4a1575b5c7c5a32ba4a7f13c04946836a1c22a1f1a9f6f1f0dbe991299311139")
