-- Lua provided by RyzenAPI
-- Game: Game: AppID 938820

-- MAIN APPLICATION
addappid(938820)
-- Game: addappid(938820)

-- MAIN APP DEPOTS / PACKAGES
addappid(938821, 1, "1e5af587072d25aad3c9d8a63aedc62e797a7e6020c263292cd3a7f8c5bbd4dc")
