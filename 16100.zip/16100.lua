-- Lua provided by RyzenAPI
-- Game: Virtual Villagers: A New Home

-- MAIN APPLICATION
addappid(16100)

-- MAIN APP DEPOTS / PACKAGES
addappid(16101, 1, "5f95817cc671b3241c97e2a395307781ba2683001e8e336ca4ef14c8387c8ed3")
