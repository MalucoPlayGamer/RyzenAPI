-- Lua provided by RyzenAPI 
-- Game: AppID 16100
addappid(16100)
addappid(16101, 1, "5f95817cc671b3241c97e2a395307781ba2683001e8e336ca4ef14c8387c8ed3")
