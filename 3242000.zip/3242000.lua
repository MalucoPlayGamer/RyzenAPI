-- Lua provided by RyzenAPI
-- Game: AppID 3242000

-- MAIN APPLICATION
addappid(3242000)
-- Game: addappid(3242000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3242001, 1, "7ec50b9354a41f6c8ab9f28b1148a6524909020dff4ff2c894bf9f1a1be296f7")
