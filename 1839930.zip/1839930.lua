-- Lua provided by RyzenAPI
-- Game: Lifecraft

-- MAIN APPLICATION
addappid(1839930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1839931, 1, "90e99f7e92b78e8bf291f6be1a6be1298c3a05504b89436cb4f543120987dd38")

