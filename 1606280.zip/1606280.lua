-- Lua provided by RyzenAPI
-- Game: Hentai Aim Trainer

-- MAIN APPLICATION
addappid(1606280)
addappid(1822400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606281, 1, "0cb26c6de0155975a45e628ad6a57afa0d0b353c03696793c656c0bcb59a534d")

