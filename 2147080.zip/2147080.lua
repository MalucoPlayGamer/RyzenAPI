-- Lua provided by SkyAPI 
-- Game: BomberGuys
addappid(2147080)
addappid(2147081, 1, "1410e6850a206490ef26fac958f672d2f58731134201bbdf64bdb186668cef71")
