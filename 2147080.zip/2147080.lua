-- Lua provided by RyzenAPI
-- Game: BomberGuys

-- MAIN APPLICATION
addappid(2147080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147081, 1, "1410e6850a206490ef26fac958f672d2f58731134201bbdf64bdb186668cef71")

