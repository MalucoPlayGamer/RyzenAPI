-- Lua provided by RyzenAPI 
-- Game: FreakOut: Extreme Freeride
addappid(304540)
addappid(304541, 1, "572bd49c1c634c252d27a5ff17e5ecdd797a5c2284f4881fbb16de354dc742f7")
