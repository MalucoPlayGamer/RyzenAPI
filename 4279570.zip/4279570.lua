-- Lua provided by RyzenAPI
-- Game: Nowhere Road

-- MAIN APPLICATION
addappid(4279570) -- Nowhere Road

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4279571, 1, "9985f013d5d92d799f900051aecc0d8bc8ea393f8697913f0adf8f842d599b71") -- Depot 4279571

