-- Lua provided by RyzenAPI
-- Game: Game: Monster Rampage VR

-- MAIN APPLICATION
addappid(2445540)
-- Game: addappid(2445540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445541, 1, "9fe3da701e6e86f4895ada5a6fa0774a204cc419be3dd280e6a1d6afb935c543")
