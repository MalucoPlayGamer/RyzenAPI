-- Lua provided by RyzenAPI
-- Game: Game: AppID 1235520

-- MAIN APPLICATION
addappid(1235520)
-- Game: addappid(1235520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235521, 1, "ee912403e722de814ebf2606e7d683390d05f2293d0839768a4e61ac3b80924a")
