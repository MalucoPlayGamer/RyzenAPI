-- Lua provided by SkyAPI 
-- Game: Train Traffic Manager
addappid(2543490)
addappid(2543491, 1, "01469bb67414361e1a401de62e2bf58641402f3788c792652e564b8e28c59c78")
