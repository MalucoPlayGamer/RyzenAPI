-- Lua provided by RyzenAPI
-- Game: 魔女的童话 Demo

-- MAIN APPLICATION
addappid(3248770)
-- Game: addappid(3248770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3248771, 1, "427f04b50d26ef7ebc22050c5152cbb82430525a2187736ee2b36d11b6754c7d")
