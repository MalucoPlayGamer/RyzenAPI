-- Lua provided by RyzenAPI
-- Game: Mermaid Land

-- MAIN APPLICATION
addappid(807880)
-- Game: addappid(807880)

-- MAIN APP DEPOTS / PACKAGES
addappid(807881, 1, "61f446874afdba817c3fc54bab94c6ec8ef8e1db56c2f6bf72822da077e01300")
