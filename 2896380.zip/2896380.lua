-- Lua provided by RyzenAPI
-- Game: Beyond the Map

-- MAIN APPLICATION
addappid(2896380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2896382,0,"b1e104f352e8fa4c35a0047bb2297e0e9e667e06b637d97314380809b0df3821")

