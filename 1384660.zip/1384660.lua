-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1384660)
addappid(1384662)
addappid(1384664)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384663,0,"0d23f536ec5e84b3055a0d43d10fda819105675708e407f9480835ee50662e69")
