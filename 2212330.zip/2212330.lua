-- Lua provided by RyzenAPI
-- Game: Your Only Move Is HUSTLE

-- MAIN APPLICATION
addappid(2212330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232859,0,"05957eaa75916b9cbb777a42bcdbe65e7652478e4d8a6fb3549a5716d1ba984a")

