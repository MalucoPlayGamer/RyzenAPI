-- Lua provided by RyzenAPI
-- Game: Your Only Move Is HUSTLE

-- MAIN APPLICATION
addappid(2212330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2232859,0,"05957eaa75916b9cbb777a42bcdbe65e7652478e4d8a6fb3549a5716d1ba984a")

