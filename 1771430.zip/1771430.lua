-- Lua provided by RyzenAPI
-- Game: 1771430

-- MAIN APPLICATION
addappid(1771430)
-- Game: addappid(1771430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771431, 1, "a90182c433cfd8a8fbd7c3070cb1487cfaebe2a02700234787820c8794ab5352")
