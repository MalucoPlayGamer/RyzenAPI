-- Lua provided by RyzenAPI
-- Game: Basketboy's Adventure

-- MAIN APPLICATION
addappid(3478660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478661,0,"0d74ef0fb8b55ca8fe6017048a5cb45fb9f7cac942ec561184f6f3e74b960cf2")

