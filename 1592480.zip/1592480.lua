-- Lua provided by RyzenAPI 
-- Game: Meta Sudoku
addappid(1592480)
addappid(1592481, 1, "3890c199667408802c0da23ffbd16b44845a7683491342fd00f5c2655b992dfa")
