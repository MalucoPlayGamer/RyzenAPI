-- Lua provided by RyzenAPI
-- Game: Game: Meta Sudoku

-- MAIN APPLICATION
addappid(1592480)
-- Game: addappid(1592480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592481, 1, "3890c199667408802c0da23ffbd16b44845a7683491342fd00f5c2655b992dfa")
