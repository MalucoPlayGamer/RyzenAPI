-- Lua provided by RyzenAPI
-- Game: LAN Party Adventures

-- MAIN APPLICATION
addappid(3566720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3566721, 1, "e9d58f55aafa69c611580b54d26740845c79883e64d303801cec79729366532b")

