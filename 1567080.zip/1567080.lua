-- Lua provided by SkyAPI 
-- Game: Furry SexyTails
addappid(1567080)
addappid(1567081, 1, "996764fa3af76ef21a650ffd9de53ee5d4ba7941f78e2a3b14d4def01ad3e076")
addappid(2891480, 0, "32b3ba24ec76cb62f3682b6b2d4ff09fdbff8afc8815c78f9a7f564a735c1906")
addappid(2891490, 0, "bba4d6c4abdce8bb991beac4bb30b37769d636c96fb56d3d1b86d2e99bdd6d40")
