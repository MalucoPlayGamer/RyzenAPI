-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2933520)
-- Game: addappid(2933520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2933520,0,"0ccf2138819057ad30e423f25a9384b0cde1ae02a688f2432b9c697ef276c7ca")
