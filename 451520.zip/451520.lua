-- Lua provided by SkyAPI 
-- Game: theBlu
addappid(451520)
addappid(451521, 1, "9ee13b90e19f8d0a06ffc39f3df7a00b585d13c5998f89e9a9247c8a3513c5a7")
