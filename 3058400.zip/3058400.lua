-- Lua provided by RyzenAPI 
-- Game: Cam Star!
addappid(3058400)
addappid(3058401, 1, "e4f1f6910c7b586bdcab1ec32bab7e04e0c6bd6a3fcf2f5d732e4eb7aa5c7918")
