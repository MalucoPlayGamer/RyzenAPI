-- Lua provided by RyzenAPI
-- Game: Dispersio 2 Demo

-- MAIN APPLICATION
addappid(1639750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489851,0,"3420d0d473506c05667f328d63f6e0a81c55685612a7ccae6af5755c21d4d9ec")

