-- Lua provided by RyzenAPI
-- Game: Spark Rising

-- MAIN APPLICATION
addappid(266550)

-- MAIN APP DEPOTS / PACKAGES
addappid(266551, 1, "f022b96c35e20c6d22e8d3ec31518f7e344fea7f1f0ac8c82529368de4e47cec")
