-- Lua provided by RyzenAPI
-- Game: SeizeControl

-- MAIN APPLICATION
addappid(4496300)

-- MAIN APP DEPOTS / PACKAGES
addappid(4496301,0,"8ddb63f87b0bbb0e7c396f3a82eb6217543c34ecbd7580370ff6c3b9386e452e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4687380)
