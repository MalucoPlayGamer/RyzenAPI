-- Lua provided by RyzenAPI 
-- Game: OUTRIDERS Demo
addappid(1435990)
addappid(1435991, 1, "fb53d34a120f2b38f377b8936be1b92ac8ea2dcbbd4a9c89fe53739793c6c92d")
