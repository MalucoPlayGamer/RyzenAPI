-- Lua provided by RyzenAPI
-- Game: Sex Simulator - Naughty Waitress

-- MAIN APPLICATION
addappid(2671110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2671111, 1, "882804b0f3eeb42d220c1ed21d90dd7bd5dc0e463b022702222b25f42df9120a")

