-- Lua provided by RyzenAPI 
-- Game: AppID 322980
addappid(322980)
addappid(322981, 1, "069aff7af2b033604b02ad6c83a822491b3401777f70d1c211d66e982cda4d7e")
