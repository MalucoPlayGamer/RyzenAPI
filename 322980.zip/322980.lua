-- Lua provided by RyzenAPI
-- Game: 322980

-- MAIN APPLICATION
addappid(322980)
-- Game: addappid(322980)

-- MAIN APP DEPOTS / PACKAGES
addappid(322981, 1, "069aff7af2b033604b02ad6c83a822491b3401777f70d1c211d66e982cda4d7e")
