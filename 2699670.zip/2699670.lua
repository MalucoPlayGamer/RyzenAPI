-- Lua provided by RyzenAPI
-- Game: 大海与你

-- MAIN APPLICATION
addappid(2699670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699671, 1, "a7725e3b6365ab1918f13d5a77c4e37c66f4426ee16ecadfd50b716f898194c9")

