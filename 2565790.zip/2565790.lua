-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2565790)
-- Game: addappid(2565790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565790,0,"3ca6d5b66803096fe10ffac8c4f4018741452c1738533df84600319f6f7a607a")
