-- Lua provided by RyzenAPI
-- Game: Click Space Miner 2

-- MAIN APPLICATION
addappid(1061260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061261, 1, "da8b52838f5e12e820ad596eeaccae182cd98010ea558646442289dd3bf335fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1061440)
addappid(1061441)
addappid(1061442)
addappid(1061443)
addappid(1062030)
