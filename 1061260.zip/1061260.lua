-- Lua provided by RyzenAPI
-- Game: 1061260

-- MAIN APPLICATION
addappid(1061260)
-- Game: addappid(1061260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061261, 1, "da8b52838f5e12e820ad596eeaccae182cd98010ea558646442289dd3bf335fb")
