-- Lua provided by SkyAPI 
-- Game: GAROU: MARK OF THE WOLVES Soundtrack
addappid(1940580)
addappid(1940581, 1, "668942534c2a752bfd4a1efcba03727096961160d1b5056fa86906907b5237fa")
addappid(1940582, 1, "90cd8d035c5ac28c489a5b55bcb67c93009a0a9acbbc3694a162e587b238b333")
