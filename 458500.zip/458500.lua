-- Lua provided by SkyAPI 
-- Game: Babylon 2055 Pinball
addappid(458500)
addappid(458501, 1, "1cca616f7e097d668c37d1e3ca17c65b5f9d9bc7eed50ebaa7a4b4368705d070")
