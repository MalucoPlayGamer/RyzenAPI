-- Lua provided by RyzenAPI
-- Game: 458500

-- MAIN APPLICATION
addappid(458500)
-- Game: addappid(458500)

-- MAIN APP DEPOTS / PACKAGES
addappid(458501, 1, "1cca616f7e097d668c37d1e3ca17c65b5f9d9bc7eed50ebaa7a4b4368705d070")
