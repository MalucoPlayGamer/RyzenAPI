-- Lua provided by RyzenAPI
-- Game: Manga Maker's Mega Milkers

-- MAIN APPLICATION
addappid(2291810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291811, 1, "4f8776a6f8c8016b6f41bc5a98e388753257a1723ed5c3232717e8438547c0f5")
