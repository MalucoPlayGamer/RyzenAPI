-- Lua provided by RyzenAPI
-- Game: The Exit of Nightmare Demo

-- MAIN APPLICATION
addappid(3176690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176691, 1, "d1396e021618c58db4892bc468795133a1de4ec8c17b85d005953069b64763a4")

