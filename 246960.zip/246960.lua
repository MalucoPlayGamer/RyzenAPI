-- Lua provided by RyzenAPI
-- Game: 246960

-- MAIN APPLICATION
addappid(246960)
-- Game: addappid(246960)

-- MAIN APP DEPOTS / PACKAGES
addappid(246961, 1, "0a0491fe5da8d2a7861b858cf9d617ebe0243148f4fd657d3b3054aaa04c7576")
