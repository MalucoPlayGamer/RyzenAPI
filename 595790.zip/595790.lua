-- Lua provided by RyzenAPI
-- Game: Hell is Other Demons

-- MAIN APPLICATION
addappid(595790)
addappid(595791)
addappid(595792)
addappid(595794)

-- MAIN APP DEPOTS / PACKAGES
addappid(595793,0,"631a32323f6be77d97cd419833c0c607394472fc17527e57b68f6e9e4b229573")
addappid(1105400,0,"f1559349c8a3d17261686cacd4831b1f393c92be49a5315aa005a378de102642")

