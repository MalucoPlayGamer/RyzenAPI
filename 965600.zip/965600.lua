-- Lua provided by RyzenAPI
-- Game: Raiders of the North Sea

-- MAIN APPLICATION
addappid(965600)

-- MAIN APP DEPOTS / PACKAGES
addappid(965601, 1, "4448963986a389145fb7a4c836d60130d4694a5c6dac858c692d725e836943e4")
addappid(965602, 1, "662c6de7e3afb347fec81fb8d767d18f3aec269692af85ce829e8469fe548750")

