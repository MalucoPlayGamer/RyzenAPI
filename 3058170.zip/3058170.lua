-- Lua provided by RyzenAPI
-- Game: Kajun-chan's Lucid Room Demo

-- MAIN APPLICATION
addappid(3058170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058171, 1, "0a55c3957094d49a744c77af5f6d205e7291d1658e22205700a136c5f23583f5")

