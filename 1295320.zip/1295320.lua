-- Lua provided by RyzenAPI
-- Game: Can of Wormholes

-- MAIN APPLICATION
addappid(1295320)
-- Game: addappid(1295320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295321, 1, "962ee7f17e604679711cccb70268fab1ec40ec90e4c0cf7d47e4c840fe24635e")
