-- Lua provided by RyzenAPI
-- Game: Field Hospital: Dr. Taylor's Story

-- MAIN APPLICATION
addappid(1315120)
-- Game: addappid(1315120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315121, 1, "bd10efe52717ae7ce7d92881c7c864cda6bdea47dcebbe7c4bcdee2a74d07be8")
