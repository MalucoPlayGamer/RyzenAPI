-- Lua provided by RyzenAPI
-- Game: Smile To Fly

-- MAIN APPLICATION
addappid(1164330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164331, 1, "7bffc04b7476db6a29c4945353c499a5ab73a3d96d752ba7277a2e95882e9132")
