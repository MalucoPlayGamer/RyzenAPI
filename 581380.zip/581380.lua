-- Lua provided by SkyAPI 
-- Game: Clockwise
addappid(581380)
addappid(581381, 1, "4d4666a034f385dcf0c2f31b62346d30a9d03a841b9b0945c99d1888255cc17a")
