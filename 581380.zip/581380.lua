-- Lua provided by RyzenAPI
-- Game: Clockwise

-- MAIN APPLICATION
addappid(581380)

-- MAIN APP DEPOTS / PACKAGES
addappid(581381, 1, "4d4666a034f385dcf0c2f31b62346d30a9d03a841b9b0945c99d1888255cc17a")
