-- Lua provided by RyzenAPI
-- Game: Clockwise

-- MAIN APPLICATION
addappid(581380)

-- MAIN APP DEPOTS / PACKAGES
addappid(581381, 1, "4d4666a034f385dcf0c2f31b62346d30a9d03a841b9b0945c99d1888255cc17a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
