-- Lua provided by RyzenAPI
-- Game: 370670

-- MAIN APPLICATION
addappid(370670)
-- Game: addappid(370670)

-- MAIN APP DEPOTS / PACKAGES
addappid(370671, 1, "7bacde6105a22df8814f5aa3ae4402909a659dbe1bf12dc71cdcc382fc4069b5")
addappid(1087860, 0, "5520d4ec91f8fd91857ba662b38c94ee8462584034ac31f285891a86c38d2ba2")
