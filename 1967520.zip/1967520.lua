-- Lua provided by SkyAPI 
-- Game: Ski3
addappid(1967520)
addappid(1967521, 1, "bb57c8fabbf75e07b06ba159e90b49273cd59427209d035e8a736020a856f909")
