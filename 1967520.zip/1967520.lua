-- Lua provided by RyzenAPI
-- Game: Game: Ski3

-- MAIN APPLICATION
addappid(1967520)
-- Game: addappid(1967520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967521, 1, "bb57c8fabbf75e07b06ba159e90b49273cd59427209d035e8a736020a856f909")
