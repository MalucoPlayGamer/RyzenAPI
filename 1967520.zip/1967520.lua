-- Lua provided by RyzenAPI
-- Game: Ski3

-- MAIN APPLICATION
addappid(1967520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967521, 1, "bb57c8fabbf75e07b06ba159e90b49273cd59427209d035e8a736020a856f909")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
