-- Lua provided by RyzenAPI
-- Game: Game: AppID 35110

-- MAIN APPLICATION
addappid(35110)
-- Game: addappid(35110)

-- MAIN APP DEPOTS / PACKAGES
addappid(35111, 1, "69fed54303c88337de40e9bc5265b57f95bb6ae6529dc6bb5badca2577985fb6")
