-- Lua provided by RyzenAPI
-- Game: Make Good Choices

-- MAIN APPLICATION
addappid(3410310)
-- Game: addappid(3410310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3410311, 1, "9f9fbe1a217b2aa27bb04ddf2d7bd856d6e606ccaf00ac26ce356bf794320a6c")
addappid(3410312, 1, "a60646056cc4bc7da17dd67735e69eb8d9644caa4bcb0f549919cc2f2cfe438a")
