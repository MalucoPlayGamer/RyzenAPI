-- Lua provided by RyzenAPI
-- Game: Star Survivor Demo

-- MAIN APPLICATION
addappid(2106550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106551, 1, "7aa6737a63803ebe0f675bb7844e9e56c0171c3be12b42636f27ad9ee3b6f962")
