-- Lua provided by RyzenAPI
-- Game: STAR WARS™: X-Wing Alliance™

-- MAIN APPLICATION
addappid(361670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(361671, 1, "4c55d4e0ed1c0a9d2e872cd0175cbedef581d3465d65737dd234319fe863790b")
