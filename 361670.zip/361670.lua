-- Lua provided by RyzenAPI
-- Game: addappid(361670)

-- MAIN APPLICATION
addappid(361670)

-- MAIN APP DEPOTS / PACKAGES
addappid(361671, 1, "4c55d4e0ed1c0a9d2e872cd0175cbedef581d3465d65737dd234319fe863790b")
