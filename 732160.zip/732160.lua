-- Lua provided by RyzenAPI
-- Game: The Wild Age

-- MAIN APPLICATION
addappid(732160)

-- MAIN APP DEPOTS / PACKAGES
addappid(732161,0,"df3f4b7e6afa9eb814935ee0f0df494419ed49a65bce45e26c79551d29f3bf0d")

