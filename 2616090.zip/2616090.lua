-- Lua provided by RyzenAPI
-- Game: Whacking Hell!

-- MAIN APPLICATION
addappid(2616090)
-- Game: addappid(2616090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616091, 1, "c6d075c520b892e9ee6c2668626464d0a9df5b1b2e0b2ef29a5e65168b969378")
