-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade - Shadows of New York Artbook

-- MAIN APPLICATION
addappid(1405990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405990,0,"126fbb76bb1ecd80253e7ab18a9af9978595c9bb7dfc1b06b52a63838a82ee86")
