-- Lua provided by RyzenAPI
-- Game: Hentai Girlfriend Simulator

-- MAIN APPLICATION
addappid(1225870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225871, 1, "1b808203d97189a5c3b54682db502584fef90525dafa8e3cdfd92b5fdf3907cd")
