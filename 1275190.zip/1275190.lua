-- Lua provided by RyzenAPI
-- Game: Game: Inside The Mirror

-- MAIN APPLICATION
addappid(1275190)
-- Game: addappid(1275190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275191, 1, "2b168fe29971f9964cde89bc0f7a7bd08029ab7519e3afd9ccfd11a1b65b171c")
