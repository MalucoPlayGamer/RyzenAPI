-- Lua provided by RyzenAPI
-- Game: Game: Gods vs Horrors Demo

-- MAIN APPLICATION
addappid(3079080)
-- Game: addappid(3079080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3079081, 1, "babe159c23c798f77186431a8770934b45ccb366d04c00296a41927fc06dd9a8")
