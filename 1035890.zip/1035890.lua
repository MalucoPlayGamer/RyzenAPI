-- Lua provided by RyzenAPI
-- Game: Game: AppID 1035890

-- MAIN APPLICATION
addappid(1035890)
-- Game: addappid(1035890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035891, 1, "a053f0edbd48380b8c142da92654d1a8fab76e495242b40ae16c4f78c81ff692")
