-- Lua provided by RyzenAPI
-- Game: AppID 2451650

-- MAIN APPLICATION
addappid(2451650)
-- Game: addappid(2451650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451651, 1, "2c6ac2ae4219f56738cb20ad6ae840131f7952e0f42a045f384c3176b0f525da")
