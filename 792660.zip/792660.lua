-- Lua provided by RyzenAPI
-- Game: The Operational Art of War IV

-- MAIN APPLICATION
addappid(792660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(792661, 1, "86d95721e3983f940069ba5b9660899e518ad4669ad28c2356005e244c08728b")
