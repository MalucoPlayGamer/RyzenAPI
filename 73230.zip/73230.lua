-- Lua provided by RyzenAPI
-- Game: Majesty Gold HD

-- MAIN APPLICATION
addappid(73230)
addappid(228982)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(73231, 1, "281093f3893010fef3fab6281684a38ea977052ba843a4e1b01217cbf7921cc9")

