-- Lua provided by RyzenAPI
-- Game: Code Brown: A Game About Pooping

-- MAIN APPLICATION
addappid(930640)
-- Game: addappid(930640)

-- MAIN APP DEPOTS / PACKAGES
addappid(930641, 1, "42147dc7e80270fea1742d9f93c92af098cc9c6ac4bbb6ce41a27b04d202582c")
