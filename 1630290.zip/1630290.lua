-- Lua provided by RyzenAPI
-- Game: 1630290

-- MAIN APPLICATION
addappid(1630290)
-- Game: addappid(1630290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630291, 1, "0735b1889cea37a3fd4a7f372d215593b93c9c0cea5aeca39ef9e9d6af00a85e")
