-- Lua provided by RyzenAPI 
-- Game: AppID 215100
addappid(215100)
addappid(215101, 1, "d150a3a15c26a4d2b5a0477967b79355a7292e40e71269c7eb6bc395ddf2e6e3")
