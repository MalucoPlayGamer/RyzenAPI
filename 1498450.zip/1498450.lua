-- Lua provided by RyzenAPI
-- Game: Happy Funtime Labs

-- MAIN APPLICATION
addappid(1498450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498451, 1, "72bfb2765e511cfd599fda1dcee7f64eec58efa6e0f8502feed92f36a7c5a5d7")
