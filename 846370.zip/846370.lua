-- Lua provided by RyzenAPI
-- Game: 846370

-- MAIN APPLICATION
addappid(846370)
-- Game: addappid(846370)

-- MAIN APP DEPOTS / PACKAGES
addappid(846371, 1, "542d1dbaf147218f037dc4b712c1f22b1609bf1aa8f57c7336edd962e54b3253")
