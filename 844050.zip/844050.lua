-- Lua provided by RyzenAPI
-- Game: Desert Child

-- MAIN APPLICATION
addappid(844050)

-- MAIN APP DEPOTS / PACKAGES
addappid(844051, 1, "108643db4a84313ab9d158733ab4d48a3d153d99ff2a166a7e50163ce2f67311")
addappid(844052, 1, "42d9c333997cba424d603fe04ed18a8d39717820494f0623ddafbad594ec0bdf")
addappid(844053, 1, "7c8af7781edc71e7c0e1b0702c1dc47d9e4008fca06a85d892b4442dce7e844e")

