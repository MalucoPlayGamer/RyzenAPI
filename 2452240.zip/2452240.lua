-- Lua provided by RyzenAPI
-- Game: Desktop Mark

-- MAIN APPLICATION
addappid(2452240)
addappid(2663640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2452241, 1, "e679182e49a3550c71f7ea3d2c94548b98a0192da470f7bb34c5817bc26cbfd5")
addappid(2452242, 1, "c2d6beda2bee02c31043d4f2108b437cff015f85289d5632fbacddf618b24200")

