-- Lua provided by RyzenAPI
-- Game: ATV Drift & Tricks

-- MAIN APPLICATION
addappid(622020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(622021, 1, "1ba2b1d2e297e4b059cb128b04e44f315d41f22165ecfd8714e816acd5aa14c9")

