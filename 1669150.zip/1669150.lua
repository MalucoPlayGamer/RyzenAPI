-- Lua provided by RyzenAPI
-- Game: addappid(1669150)

-- MAIN APPLICATION
addappid(1669150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669151, 1, "3cf4f9d9a6b796dcccd880769faaf2f98f25663bde28b9e718d8f634a42f9a2f")
