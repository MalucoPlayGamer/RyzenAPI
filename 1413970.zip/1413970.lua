-- Lua provided by SkyAPI 
-- Game: Fox Girls Never Play Dirty
addappid(1413970)
addappid(1413971, 1, "c26ddad2f9073684a5b0e7e44a99e49f11dd4562451a98a80df4f756a0359b81")
addappid(1413972, 1, "43c0d633fff76254892032fa3ef630eaf95fba5059fef30c0c1165d686877bde")
addappid(1413973, 1, "7fbff9e053a91028c2ba0f6390071193dbd142cca9d29c8d3eefa7084403c181")
