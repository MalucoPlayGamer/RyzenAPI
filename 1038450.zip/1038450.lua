-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: Midnight in Salem

-- MAIN APPLICATION
addappid(1038450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038451, 1, "731df41d11a8fafa54d4602dd29f80435f1b4db60948d9190e629a12bbe8d27c")
addappid(1038452, 1, "02928fb081f45b7ccc90f0eedd9bc96fd43ca38d8d88f1c0f3f525dd0ede3240")
