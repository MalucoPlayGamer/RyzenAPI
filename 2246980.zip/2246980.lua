-- Lua provided by RyzenAPI
-- Game: Darkest Dungeon® II Demo

-- MAIN APPLICATION
addappid(2246980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246981, 1, "9514410f88a3583101932d7757960dd67942d9b0d0ea603dfa55bfe1f085a341")
