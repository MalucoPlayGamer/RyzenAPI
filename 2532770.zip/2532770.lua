-- Lua provided by RyzenAPI
-- Game: addappid(2532770)

-- MAIN APPLICATION
addappid(2532770)
addappid(3238570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532771, 1, "d706640166d660c5c3a5ca123aa5384aaf1788a0e317130b6b1ce404cedd00eb")
