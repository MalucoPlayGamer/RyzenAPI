-- Lua provided by RyzenAPI
-- Game: Beat Saber - Monstercat Mixtape 2 - Sullivan King - "Thrones of Blood"

-- MAIN APPLICATION
addappid(3274280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274280,0,"fbacda0b5b166c488631490714a4e5b39253547c3c5229856cfb3854011e590d")
