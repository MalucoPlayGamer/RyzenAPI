-- Lua provided by RyzenAPI
-- Game: Mall of Mayhem

-- MAIN APPLICATION
addappid(1558330)
addappid(1988240)
addappid(1988241)
addappid(1988242)
addappid(1988243)
addappid(1988260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1558332,0,"2181f8ff542d63bbcfcf2e1011120dfcef1a9e78010231e6cfaec4023c686913")

