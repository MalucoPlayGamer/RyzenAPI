-- Lua provided by RyzenAPI
-- Game: Mall of Mayhem

-- MAIN APPLICATION
addappid(1558330)
-- Game: addappid(1558330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558332,0,"2181f8ff542d63bbcfcf2e1011120dfcef1a9e78010231e6cfaec4023c686913")
