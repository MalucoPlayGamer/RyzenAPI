-- Lua provided by RyzenAPI
-- Game: Portal Defect

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(229032)
addappid(229033)
addappid(1468800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468806,0,"5038612d1821a01e44a932d2b120cd2efa9b4c68ed09b08c83bfe18399799932")

