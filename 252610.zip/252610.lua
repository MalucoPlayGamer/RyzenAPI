-- Lua provided by RyzenAPI
-- Game: Death Road to Canada

-- MAIN APPLICATION
addappid(252610)

-- MAIN APP DEPOTS / PACKAGES
addappid(252612,0,"76aa4fa712d6147a0abd106932278edbd5c2a1641edb9566f5e3e83b743cfb88")
addappid(252613,0,"9c7fd8af97b96e6d3db7e601fb8c4866736cb0863e36df576ffc6ed36bc09f0b")
addappid(252614,0,"344be414376a525da01ced64978f86b07c948ef6ed5027eac3e23e4e734c4470")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
