-- Lua provided by RyzenAPI
-- Game: Emily: Displaced

-- MAIN APPLICATION
addappid(481950)

-- MAIN APP DEPOTS / PACKAGES
addappid(481951, 1, "f592d1347ad38d5021d41ea2151808eed4cd84e1886c7e49096d255c1c4c571c")
addappid(481952, 1, "d5b180bf8db85b44654d50cd8741aec1d70b42b76d6ae13a2b624f5f4a2e5087")

