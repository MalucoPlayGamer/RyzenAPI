-- Lua provided by RyzenAPI
-- Game: 2968320

-- MAIN APPLICATION
addappid(2968320)
-- Game: addappid(2968320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968321, 1, "2b0dd2e8c0821c9b86cca420ce01a06ae9573f0b2e22f79861ab5471c6a65c48")
