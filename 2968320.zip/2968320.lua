-- Lua provided by RyzenAPI 
-- Game: SLIMECORE Playtest
addappid(2968320)
addappid(2968321, 1, "2b0dd2e8c0821c9b86cca420ce01a06ae9573f0b2e22f79861ab5471c6a65c48")
