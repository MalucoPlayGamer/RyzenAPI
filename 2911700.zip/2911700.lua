-- Lua provided by RyzenAPI
-- Game: Game: AppID 2911700

-- MAIN APPLICATION
addappid(2911700)
-- Game: addappid(2911700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911701, 1, "265d4ce1f8dc47f0630462059bcc8e41a51b350bf801b54379db87a72b048934")
