-- Lua provided by RyzenAPI
-- Game: Winged Sakura: Mindy's Arc

-- MAIN APPLICATION
addappid(331390)

-- MAIN APP DEPOTS / PACKAGES
addappid(331391, 1, "5810cc9aa527e64f78f8a62f47fb6610b38e2dbd0257c7860f1700bdefcea27d")
addappid(331392, 1, "3aeab18412d99b1a3dc7edb1ed49065ea0c5f2640053ec600da8814f611af843")
addappid(331393, 1, "09643ec52efb2963d6fcc2dc7446fd4b8c47a7dcb5239ad725be62da9a2ccda1")
addappid(331394, 1, "70c8fecbf4e8c610ab12d91a2d411693af935ea189a06037043786d93136f70f")
addappid(331550, 0, "9595406bbf1c6b7ace6982def521dbf9af5e2df1df9d141871ab7c5424cc5c0d")
