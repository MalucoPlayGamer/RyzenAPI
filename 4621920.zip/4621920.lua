-- Lua provided by RyzenAPI
-- Game: Adventure Honor

-- MAIN APPLICATION
addappid(4621920) -- Adventure Honor

-- MAIN APP DEPOTS / PACKAGES
addappid(4621921, 1, "756f3f14a5f6772beb2f5473ea3d1524fece62abd48cbf38aaf763d6f93b2231") -- Depot 4621921
