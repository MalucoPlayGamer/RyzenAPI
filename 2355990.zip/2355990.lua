-- Lua provided by RyzenAPI
-- Game: Game: Dippy & Chippy

-- MAIN APPLICATION
addappid(2355990)
-- Game: addappid(2355990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355991, 1, "77894f98a389476c5d7b3673dea3446be533e5ba223a994fbf43e9e2c1520790")
