-- Lua provided by RyzenAPI
-- Game: Dippy & Chippy

-- MAIN APPLICATION
addappid(2355990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2355991, 1, "77894f98a389476c5d7b3673dea3446be533e5ba223a994fbf43e9e2c1520790")

