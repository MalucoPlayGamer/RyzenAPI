-- Lua provided by RyzenAPI
-- Game: addappid(2731990)

-- MAIN APPLICATION
addappid(2731990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731991, 1, "706eb2f0b6ee57461a6a103702a78193223aaff21720d8dd481348fbacdb58c1")
