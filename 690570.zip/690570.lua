-- Lua provided by RyzenAPI
-- Game: Drone Racer: Canyons

-- MAIN APPLICATION
addappid(690570)

-- MAIN APP DEPOTS / PACKAGES
addappid(690572,0,"da7503a170cb4df9ebc903582cc4f4084877b521b16433b0a227e75c19c4d589")
addappid(690573,0,"f3ca1d448b8edd8119b2837e4b2b2213c92051b04f59a871d42ac8c2905bddd4")

