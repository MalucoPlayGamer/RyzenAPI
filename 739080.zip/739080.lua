-- Lua provided by RyzenAPI
-- Game: 9 Monkeys of Shaolin

-- MAIN APPLICATION
addappid(739080)

-- MAIN APP DEPOTS / PACKAGES
addappid(739081, 1, "aa1b588da2ee859a1e530435c7a206d0796edeea69790d1b8fc20f907b51b852")
addappid(739082, 1, "848fdc92e4a4276b9d487573dd6a2dee840f8e79ad8e54917552d7272352d078")
addappid(1426920, 0, "edab9c31af39bd300990e325da324c74004919288d0237d674384a04aa7b3d87")
addappid(1426921, 0, "f39853ffc4f96854986733d5cecb93c67d37c209c9bb818f371d042a2a4b309c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
