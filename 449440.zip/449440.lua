-- Lua provided by RyzenAPI
-- Game: AppID 449440

-- MAIN APPLICATION
addappid(449440)

-- MAIN APP DEPOTS / PACKAGES
addappid(449441, 1, "ab5e26c2ad0fbca195a8502a3013bba5bddd87188478a76d6091f0f9d50b3780")
