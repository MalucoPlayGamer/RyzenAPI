-- Lua provided by SkyAPI 
-- Game: Dyflexion
addappid(1727440)
addappid(1727441, 1, "3b1fdee8e9e3510063442f7df9a8b30a037837af418220f2961fc1af6fb131f0")
addappid(1727442, 1, "6c8b9d48d583a7e15ba1782b627ddc46582d2dd9a89ee99f3362169e650b450d")
