-- Lua provided by RyzenAPI
-- Game: AppID 669380

-- MAIN APPLICATION
addappid(669380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(669381, 1, "cdfa62527bbe202a380026cc153b4e2f952d83b4684a4d0347c252536c8df9dc")

