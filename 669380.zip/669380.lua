-- Lua provided by RyzenAPI
-- Game: 669380

-- MAIN APPLICATION
addappid(669380)
-- Game: addappid(669380)

-- MAIN APP DEPOTS / PACKAGES
addappid(669381, 1, "cdfa62527bbe202a380026cc153b4e2f952d83b4684a4d0347c252536c8df9dc")
