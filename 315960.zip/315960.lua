-- Lua provided by RyzenAPI
-- Game: 315960

-- MAIN APPLICATION
addappid(315960)

-- MAIN APP DEPOTS / PACKAGES
addappid(315960,0,"b33ff1bb7dee008b9d577c0cb20fa81f7df0c3cf54d23032e3b6710f2734d324")
