-- Lua provided by RyzenAPI
-- Game: Ready Player One: OASIS beta

-- MAIN APPLICATION
addappid(779650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(779651, 1, "eb98638e3e44d4ed28ff11188b8ec44f2d81477f137166cbdcce8fd90fd7373c")
addappid(779652, 1, "e5d329d51bf7f98902141ffb034dc2cf6db4e595033954ad84ab072637ad3d57")
addappid(779653, 1, "6f23a1321ef6a5e029bee3af014eeae97b8523c9a84ff7abc9794db7fe29e21e")
addappid(779654, 1, "18e616a2796b6bda5a2b02b8613f150a231f3d5cd1cc800566834e65306bcbb6")
addappid(779655, 1, "14c1afce0d02753b10467d2ffcac514f79d4064986b7bf89e14bab12263b23a0")
addappid(779656, 1, "ac2eb6a1cff5759ea9a6d80efc48bed0b245bdf809db5e3d8d4e83a80802998c")
addappid(779657, 1, "42709e726451cf5c646d8c50c628529a1f81111445566574ed02220784bca746")

