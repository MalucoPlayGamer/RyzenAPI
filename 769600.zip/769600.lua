-- Lua provided by RyzenAPI
-- Game: Rheksetor

-- MAIN APPLICATION
addappid(769600)

-- MAIN APP DEPOTS / PACKAGES
addappid(769601,0,"0e51cda9e3b9cc411d3de469cdb54701e4168f7002c0daa18c0ac808f4ff7f71")

