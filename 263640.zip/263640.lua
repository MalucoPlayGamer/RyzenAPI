-- Lua provided by RyzenAPI
-- Game: CDF Ghostship

-- MAIN APPLICATION
addappid(263640)
-- Game: addappid(263640)

-- MAIN APP DEPOTS / PACKAGES
addappid(263641, 1, "c7eb2c8f02c94457b357043cce816b83a185c9f105058a03ef06099cc9649eb7")
