-- Lua provided by RyzenAPI
-- Game: 3035010

-- MAIN APPLICATION
addappid(3035010)
-- Game: addappid(3035010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035011, 1, "e9618436b7a2e03c36a556f6f857567569e2fc4166f061b9ca3f7ad94dfccc85")
