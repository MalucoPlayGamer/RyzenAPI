-- Lua provided by RyzenAPI
-- Game: Deep Cuts

-- MAIN APPLICATION
addappid(3035010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035011, 1, "e9618436b7a2e03c36a556f6f857567569e2fc4166f061b9ca3f7ad94dfccc85")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
