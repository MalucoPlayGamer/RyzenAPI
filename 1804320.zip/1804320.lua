-- Lua provided by RyzenAPI 
-- Game: Splash Jumper
addappid(1804320)
addappid(1804321, 1, "6cd94de7cf2d0466ed83e640529e41d000d914e900baa9fc354a4067f502eb14")
