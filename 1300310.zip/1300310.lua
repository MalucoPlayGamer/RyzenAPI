-- Lua provided by RyzenAPI
-- Game: Move Code Lines

-- MAIN APPLICATION
addappid(1300310)
addappid(3961680)
-- Game: addappid(1300310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300311, 1, "496f399124b4b339aae3dcfd57a1627e8b8fa3b066a3107a658a7ec1daf9a943")
