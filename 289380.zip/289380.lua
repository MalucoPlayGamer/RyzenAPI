-- Lua provided by RyzenAPI
-- Game: Game: Konung 3: Ties of the Dynasty

-- MAIN APPLICATION
addappid(289380)
-- Game: addappid(289380)

-- MAIN APP DEPOTS / PACKAGES
addappid(289381, 1, "08960fc018f5a65feedd502d513aeab89a577cd768b11d8a7cba8e618aed1b65")
addappid(289382, 1, "45e4fa336b5ad3dea9e67839a2e2a36a56027bf12afcb81aadd5158c1175b07c")
