-- Lua provided by RyzenAPI
-- Game: Idle Colony

-- MAIN APPLICATION
addappid(2843640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843642,0,"36203f6b0b9c46ef8bd3547357cca4c102f1ffc76a43f90217500a567f28cbcc")
