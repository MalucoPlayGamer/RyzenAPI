-- Lua provided by RyzenAPI
-- Game: It's You: A Breakup Story

-- MAIN APPLICATION
addappid(878020)

-- MAIN APP DEPOTS / PACKAGES
addappid(878021,0,"54e12fed6cc6192869010b85390097eef917f68972ca2968be8b34d39b9302e1")

