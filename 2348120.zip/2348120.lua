-- Lua provided by RyzenAPI
-- Game: 2348120

-- MAIN APPLICATION
addappid(2348120)
addappid(3235000)
-- Game: addappid(2348120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348121, 1, "c574248cbc889bce97f47740062ca5178b551ecbbd7c69720d1fc3e2028e2621")
