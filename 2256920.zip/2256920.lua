-- Lua provided by RyzenAPI
-- Game: Friendly Facade

-- MAIN APPLICATION
addappid(2256920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256921, 1, "b4a7818a639b2f7a386e695d714105acbb54616bfc0b7f015316110a1e75cdd3")
