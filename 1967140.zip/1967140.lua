-- Lua provided by RyzenAPI
-- Game: addappid(1967140)

-- MAIN APPLICATION
addappid(1967140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967140,0,"4c7a9e43f4650b66fafe22f237bf57b85365fa9ed144cd17dff72f234c2cf237")
