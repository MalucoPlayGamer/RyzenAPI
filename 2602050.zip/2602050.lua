-- Lua provided by RyzenAPI
-- Game: schoolLife 东洋中学之异闻录

-- MAIN APPLICATION
addappid(2602050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602051, 1, "b0e56f210ff1598bcb70839a4413e333841b88e56c649bf2100102a304b19c6b")
