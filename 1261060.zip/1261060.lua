-- Lua provided by RyzenAPI
-- Game: addappid(1261060)

-- MAIN APPLICATION
addappid(1261060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261061, 1, "ff1fdeda1c6c8aa919ef79d9c30c3c2f7f43ad517a4598c47bac89f5ae136114")
