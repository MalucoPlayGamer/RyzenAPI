-- Lua provided by RyzenAPI
-- Game: Game: 网瘾少年2005 Internet addicted youth 2005

-- MAIN APPLICATION
addappid(2461780)
-- Game: addappid(2461780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461781, 1, "45a160cad384c17d4301716d48288513f87f2b189c63936dcc562451c6c495c1")
