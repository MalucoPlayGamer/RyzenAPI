-- Lua provided by RyzenAPI
-- Game: AppID 399810

-- MAIN APPLICATION
addappid(399810)

-- MAIN APP DEPOTS / PACKAGES
addappid(399811, 1, "112eadae17b6b875e2433fad2131d5835f25344dc07aeee21f9f385ae1cdc72e")
addappid(945322, 0, "90fb822277401bbdff5a6efabb4ade366f566c375cfc884519fae79d116619e8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
