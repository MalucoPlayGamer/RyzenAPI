-- Lua provided by RyzenAPI
-- Game: addappid(1537740)

-- MAIN APPLICATION
addappid(1537740)
addappid(1664970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537741, 1, "2576bff802a49bf64796ed2ccee948f8eb86ec3521de24adb086dcd0c5eb22f9")
