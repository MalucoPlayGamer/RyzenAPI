-- Lua provided by RyzenAPI
-- Game: 1490870

-- MAIN APPLICATION
addappid(1490870)
-- Game: addappid(1490870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490871, 1, "38146c9af34d870042ea71fba30db05cbe86ddbb7bc9339646421328addabf5a")
