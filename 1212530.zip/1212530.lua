-- Lua provided by RyzenAPI
-- Game: addappid(1212530)

-- MAIN APPLICATION
addappid(1212530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212531, 1, "332b0eb17ad9f036a37bdfbb77cf32c2681126e5e9a65240799bdc232c9bbefa")
