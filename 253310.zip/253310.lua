-- Lua provided by RyzenAPI
-- Game: Fester Mudd: Curse of the Gold - Episode 1

-- MAIN APPLICATION
addappid(253310)

-- MAIN APP DEPOTS / PACKAGES
addappid(253311, 1, "fc5247da76dc251031452fe09aab085696270487ae767456c72293e15a7c2be3")
addappid(253312, 1, "29531a1466cc7966adbc5faa0ebb26dafb48020d4b1502ca37c0ce137d727000")
addappid(253313, 1, "e33672d3b6c166947c5d0c89e1aac34cba5338817cb0ab2b3439a4f13c332d3c")

