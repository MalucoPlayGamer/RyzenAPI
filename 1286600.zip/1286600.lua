-- Lua provided by RyzenAPI
-- Game: 1286600

-- MAIN APPLICATION
addappid(1286600)
addappid(1292230)
-- Game: addappid(1286600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286601, 1, "413e96f67c78e5d807f1da2fe02ba504f168e7d2ee6cdfd59d4beb762c64bb4a")
