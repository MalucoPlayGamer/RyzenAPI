-- Lua provided by RyzenAPI
-- Game: Game: Goosebumps: The Game

-- MAIN APPLICATION
addappid(361360)
-- Game: addappid(361360)

-- MAIN APP DEPOTS / PACKAGES
addappid(361361, 1, "5ce9e2fc4304e209789b9a0412b8047149da4f6df48203539a1ca4c424113858")
