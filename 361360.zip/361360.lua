-- Lua provided by RyzenAPI
-- Game: Goosebumps: The Game

-- MAIN APPLICATION
addappid(361360)

-- MAIN APP DEPOTS / PACKAGES
addappid(361361, 1, "5ce9e2fc4304e209789b9a0412b8047149da4f6df48203539a1ca4c424113858")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
