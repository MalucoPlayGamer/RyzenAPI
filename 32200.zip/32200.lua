-- Lua provided by RyzenAPI
-- Game: Game: Metal Drift

-- MAIN APPLICATION
addappid(32200)
-- Game: addappid(32200)

-- MAIN APP DEPOTS / PACKAGES
addappid(32201, 1, "c6fb95d778ba1e2045879541ed204b4e2a163ab02078cb021304e1efa5173a67")
