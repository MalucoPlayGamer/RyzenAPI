-- Lua provided by RyzenAPI
-- Game: The Galactic Harem Handbook: Chapter 2 - NSFW Sci-Fi Porn Demo

-- MAIN APPLICATION
addappid(2864960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864961, 1, "26d31323be4757c77818f7029a4834d3de4b360d02827dfdb7056400f9cd955a")

