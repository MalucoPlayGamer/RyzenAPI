-- Lua provided by RyzenAPI
-- Game: 264320

-- MAIN APPLICATION
addappid(264320)

-- MAIN APP DEPOTS / PACKAGES
addappid(264322,0,"feca330ccfa8f76159af7102843b57b9cf346054df8c0d16fb9902b761aa0b3c")

