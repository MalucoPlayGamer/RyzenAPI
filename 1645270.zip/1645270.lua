-- Lua provided by RyzenAPI
-- Game: AppID 1645270

-- MAIN APPLICATION
addappid(1645270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645271, 1, "578b0ab7e685fd298e70900e7ebabb6c2f6c95653a873177d5d266c113958e27")
addappid(1645272, 1, "9f59acd54c9cdd8a40d1adcfd4484ca8726f6c51b063ccb62c54b6bfdd7a09e9")
addappid(1645273, 1, "482fde6ae4b00ead58bef0d20a0afda7c4d0a2f27083f98fd2fff3b7d5c69da6")

