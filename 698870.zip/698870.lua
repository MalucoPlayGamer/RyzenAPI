-- Lua provided by RyzenAPI
-- Game: Metaverse Keeper

-- MAIN APPLICATION
addappid(698870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(698871, 1, "55180049c19ad19107f35d910516ca0bfc8a9873cacf97e1d95a60de33e09e6b")
addappid(698872, 1, "d3975219821b39d8c061ec4033ef6a4c61738a5652f1400cdfb4e5c41fd7fb7a")

