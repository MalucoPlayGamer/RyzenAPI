-- Lua provided by RyzenAPI
-- Game: Anima : The Reign of Darkness

-- MAIN APPLICATION
addappid(1629200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629201, 1, "c2f4fbe3326edcf44218793b62708275aebd1942f5a1df2f0ef75f3ed6000242")
