-- Lua provided by RyzenAPI
-- Game: Zhao Yun - Officer Ticket / 趙雲使用券

-- MAIN APPLICATION
addappid(956720)
-- Game: addappid(956720)

-- MAIN APP DEPOTS / PACKAGES
addappid(956720,0,"77e6cf963e320439624402033c0e603f200890aa1c620dce6dce70df7b436e3e")
