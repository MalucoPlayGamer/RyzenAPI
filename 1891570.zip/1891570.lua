-- Lua provided by RyzenAPI
-- Game: Sokonashi No Me

-- MAIN APPLICATION
addappid(1891570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891571, 1, "2c1040489b991f2f8ce7a950f891aae246e23b17ffcb6808f214697b99eccd42")

