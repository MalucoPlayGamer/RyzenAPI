-- Lua provided by RyzenAPI
-- Game: 月之镜 Demo

-- MAIN APPLICATION
addappid(2249490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249491, 1, "1aab1de553257e0f3ebea3ee8690b89cc0860bc51ff836422b265629771dddc9")
