-- Lua provided by RyzenAPI
-- Game: Game: Necrosphere

-- MAIN APPLICATION
addappid(607400)
-- Game: addappid(607400)

-- MAIN APP DEPOTS / PACKAGES
addappid(607401, 1, "576eaab50d4fbef7017b807301d78ebef94eb085f33a6d4e845e89ef7ff8ef68")
addappid(607405, 1, "bb506cab2f148d729c9fa8f96f1971b80ee45cb35e06f50cef7aeab8ad8059f2")
addappid(607406, 1, "4a78349a817a99c9fb19707cdc1c260e4351804f8f81da61fd3227f738cc53f7")
addappid(607409, 1, "0341bf7cefe0d2b9e70c8e409bf115a2fc973d87e93a96b90769cec16e1951a2")
addappid(681680, 0, "9663981d36f4e32f6e59677bc642e8578eec06221ae5fbf17096e5606b32a596")
