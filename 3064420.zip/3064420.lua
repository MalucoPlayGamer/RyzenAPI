-- Lua provided by RyzenAPI
-- Game: Innocence Or Money | Season 2 | Episode 1

-- MAIN APPLICATION
addappid(3064420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064421, 1, "61618550785084e1ee20f29109f30b884ccbd8e21c82de83342fe64a11775729")

