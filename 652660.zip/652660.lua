-- Lua provided by RyzenAPI
-- Game: ESport Manager

-- MAIN APPLICATION
addappid(652660)
-- Game: addappid(652660)

-- MAIN APP DEPOTS / PACKAGES
addappid(652661, 1, "f6d912298c0a85c595695d1a640cc44b144ccfef663af9e407bc7f02b82ce356")
