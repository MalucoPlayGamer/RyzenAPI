-- Lua provided by SkyAPI 
-- Game: AppID 589940
addappid(589940)
addappid(589941, 1, "429d871efcbb1b9c0492d7242ee40a51a5b79e2ed042a877d8af1c756fe00332")
