-- Lua provided by RyzenAPI
-- Game: 589940

-- MAIN APPLICATION
addappid(589940)
-- Game: addappid(589940)

-- MAIN APP DEPOTS / PACKAGES
addappid(589941, 1, "429d871efcbb1b9c0492d7242ee40a51a5b79e2ed042a877d8af1c756fe00332")
