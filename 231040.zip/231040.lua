-- Lua provided by RyzenAPI
-- Game: Beatbuddy: Tale of the Guardians

-- MAIN APPLICATION
addappid(231040)
addappid(257310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(231041, 1, "002507fabe6dd491a08e9afe1bd4ab9da5aa60cec42c02ac0f96bc56436680fb")
addappid(231042, 1, "ee556e6c20c8215c50e1ac1f3f6d32af91cf10dcb657fcd84c1cf850fca67264")
addappid(231043, 1, "852faf34f7626358f8f1ca0774a47ab00f338b1110f6c22309b3856cd64e24f1")
addappid(231044, 1, "6822a181d573f220bebe6807d683d0d5b609f70850fa8264f93ba083cae964d1")
addappid(231045, 1, "892ca08369ac5760a8cce0399adaa658af79cb8b88e908e21498ca0f7c519465")
addappid(231046, 1, "353bb38f3ee476e15ab794af73574ccd65e2ac1addb024671c0448dd8c82bf2f")

