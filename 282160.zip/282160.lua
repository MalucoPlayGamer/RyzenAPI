-- Lua provided by RyzenAPI
-- Game: X Tools

-- MAIN APPLICATION
addappid(282160)

-- MAIN APP DEPOTS / PACKAGES
addappid(282161, 1, "a45958f0390a8cc8797334e4cc3b666d692acba3a82b8e89b4d5054822f4c74e")

