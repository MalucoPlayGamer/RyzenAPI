-- Lua provided by RyzenAPI
-- Game: addappid(2056940)

-- MAIN APPLICATION
addappid(2056940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056940,0,"637da22d542fca9edd2fc171d3c2f214648a84399199b4e57555ac170a228c7b")
