-- Lua provided by RyzenAPI 
-- Game: Vampire Survivors: Operation Guns
addappid(2887680)
addappid(2887681, 1, "d3b3c80802a7007f3395fc2878accfc81fed7321a08b7ad295c50bbf10b9751b")
addappid(2887682, 1, "7883e4a2141db966f23677062d3c440c1b5e639a0dc7166104a00a78a4b468db")
addappid(2887683, 1, "8fae317404eb07fb5ef79a30d864888ec98d54c2ba86d3aa73cb68c24833eaca")
