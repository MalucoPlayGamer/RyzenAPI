-- Lua provided by RyzenAPI
-- Game: Jetball

-- MAIN APPLICATION
addappid(666590)

-- MAIN APP DEPOTS / PACKAGES
addappid(666592,0,"fa30fbd94fc99fc99b7a35e794bdf15b1b0737905129a93493e146d7ec067e92")

