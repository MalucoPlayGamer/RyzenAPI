-- Lua provided by RyzenAPI
-- Game: Jetball

-- MAIN APPLICATION
addappid(666590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(666592,0,"fa30fbd94fc99fc99b7a35e794bdf15b1b0737905129a93493e146d7ec067e92")

