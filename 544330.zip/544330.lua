-- Lua provided by RyzenAPI 
-- Game: AppID 544330
addappid(544330)
addappid(544331, 1, "d0197394adf343e4286167f4abea752c2532483c9e998cef798f96b503cfda6e")
