-- Lua provided by RyzenAPI
-- Game: addappid(544330)

-- MAIN APPLICATION
addappid(544330)

-- MAIN APP DEPOTS / PACKAGES
addappid(544331, 1, "d0197394adf343e4286167f4abea752c2532483c9e998cef798f96b503cfda6e")
