-- Lua provided by SkyAPI 
-- Game: Smashing time
addappid(1478670)
addappid(1478671, 1, "163d5f81bc1c62302afb4ec4ad99db48237370e1e89f8f16420a85e06d2d96d7")
