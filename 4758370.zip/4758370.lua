-- Lua provided by RyzenAPI
-- Game: Erotic Fantasy Camp

-- MAIN APPLICATION
addappid(4758370)

-- MAIN APP DEPOTS / PACKAGES
addappid(4758371, 1, "bcde94182618cc554e841da8cecd6b288da3c44d99c8bd8a7efbf9a60759dd9c")

