-- Lua provided by RyzenAPI
-- Game: Memorrha

-- MAIN APPLICATION
addappid(954080)
-- Game: addappid(954080)

-- MAIN APP DEPOTS / PACKAGES
addappid(954081, 1, "bb2da30808161a089a3b962c05ecf102b6d775ff449e910f2f17d77d983c631a")
