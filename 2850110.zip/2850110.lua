-- Lua provided by RyzenAPI
-- Game: Game: The Dream Within

-- MAIN APPLICATION
addappid(2850110)
-- Game: addappid(2850110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850111, 1, "1c062219520d0d92965406225d3c5bbd8802914f1f003da8865e91c098d44a91")
