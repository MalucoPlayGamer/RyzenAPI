-- Lua provided by RyzenAPI
-- Game: Game: AppID 1306860

-- MAIN APPLICATION
addappid(1306860)
-- Game: addappid(1306860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306861, 1, "593ed29fd1b48889b61498e52068fa2ca1fac44d184e4a24cf95295c65867394")
