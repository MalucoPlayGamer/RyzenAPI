-- Lua provided by RyzenAPI
-- Game: addappid(2869000)

-- MAIN APPLICATION
addappid(2869000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869001, 1, "e30af45b49e5463f35b17dd5301a2eb524dd42a389d6a2ff8b46b37d456afa22")
