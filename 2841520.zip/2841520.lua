-- Lua provided by RyzenAPI
-- Game: Game: Hell Survivors: Prologue

-- MAIN APPLICATION
addappid(2841520)
-- Game: addappid(2841520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841521, 1, "2bb076bdf26a6dc447194ea4ef09ff68410f0e21bb4cf58f8fdc62c8000196b8")
