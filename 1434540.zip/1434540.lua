-- Lua provided by RyzenAPI
-- Game: addappid(1434540)

-- MAIN APPLICATION
addappid(1434540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434541, 1, "418e315d0e566827ad0fe6620fb617d6a736c8854f4e9421880c94d8eeeef3ed")
