-- 4620430's Lua and Manifest Created by Hubcap Manifest
-- Meet Me In The Well
-- Created: August 05, 2026 at 13:25:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4620430) -- Meet Me In The Well
-- MAIN APP DEPOTS
addappid(4620431, 1, "4a3ebf1ea7a513af7001ae037c9b923c242c618c30015159f2478878344d37c0") -- Depot 4620431
setManifestid(4620431, "35900901728288437", 354263876)