-- Lua provided by RyzenAPI
-- Game: Meet Me In The Well

-- MAIN APPLICATION
addappid(4620430) -- Meet Me In The Well

-- MAIN APP DEPOTS / PACKAGES
addappid(4620431, 1, "4a3ebf1ea7a513af7001ae037c9b923c242c618c30015159f2478878344d37c0") -- Depot 4620431

