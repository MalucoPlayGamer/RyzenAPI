-- Lua provided by RyzenAPI
-- Game: Marble Parkour

-- MAIN APPLICATION
addappid(1463170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463171, 1, "077586a897419772dde826e78c8abbf8739599c0ed464e58d73c3df9a695684b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
