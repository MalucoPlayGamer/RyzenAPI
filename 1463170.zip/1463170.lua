-- Lua provided by RyzenAPI
-- Game: Marble Parkour

-- MAIN APPLICATION
addappid(1463170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463171, 1, "077586a897419772dde826e78c8abbf8739599c0ed464e58d73c3df9a695684b")
