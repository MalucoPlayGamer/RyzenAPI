-- Lua provided by RyzenAPI
-- Game: Mystical Island

-- MAIN APPLICATION
addappid(2020870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020872,0,"9610c42ce08557195b9929432954afe60cdf8dce1e349e4a285623cb99a95afe")
addtoken(2020870,6764418910810555919)

