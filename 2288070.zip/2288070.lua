-- Lua provided by RyzenAPI
-- Game: The Ninja Saviors: Return of the Warriors

-- MAIN APPLICATION
addappid(2288070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288071, 1, "ded5abd261120d75672804b2645d828f93c7d623ea079ec73f3643709c65a967")
