-- Lua provided by RyzenAPI
-- Game: Sakura Cupid

-- MAIN APPLICATION
addappid(733740)

-- MAIN APP DEPOTS / PACKAGES
addappid(733741, 1, "461b3d26dd1463f5938a6fa7132fe87a8a97b505ab8ee23e46133d4415dd8944")
