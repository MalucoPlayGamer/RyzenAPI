-- Lua provided by RyzenAPI
-- Game: Dragons Reef VR

-- MAIN APPLICATION
addappid(3765460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3765461, 1, "418fd388973a2291238142e8cb5334dd851b6ce80f05b916ae3f27c5bb148025")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
