-- Lua provided by SkyAPI 
-- Game: Dragons Reef VR
addappid(3765460)
addappid(3765461, 1, "418fd388973a2291238142e8cb5334dd851b6ce80f05b916ae3f27c5bb148025")
