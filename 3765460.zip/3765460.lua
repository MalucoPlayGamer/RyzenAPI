-- Lua provided by RyzenAPI
-- Game: Dragons Reef VR

-- MAIN APPLICATION
addappid(3765460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3765461, 1, "418fd388973a2291238142e8cb5334dd851b6ce80f05b916ae3f27c5bb148025")
