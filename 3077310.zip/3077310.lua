-- Lua provided by RyzenAPI
-- Game: addappid(3077310)

-- MAIN APPLICATION
addappid(3077310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077311, 1, "97340f1b114f3fd8e0022597bba3c0e4e2fa2d6527252e4740cc6290a53ee919")
