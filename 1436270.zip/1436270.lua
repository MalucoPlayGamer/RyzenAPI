-- Lua provided by RyzenAPI
-- Game: Skyseeker Demo

-- MAIN APPLICATION
addappid(1436270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436272,0,"e072af5c96d55ee4f655eb49196ada8ab38445ed1a9cd3633f32a1a7e9d6890a")

