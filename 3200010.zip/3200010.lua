-- Lua provided by RyzenAPI
-- Game: Game: The Sims™ 4 Kitchen Clutter Kit

-- MAIN APPLICATION
addappid(3200010)
-- Game: addappid(3200010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3200011, 1, "ab5036a95087c45635b21a0a1b79e5929f157bddbf9b902088a74e94ebcf610e")
addappid(3200013, 1, "434e60df17e225d82abdf1ae1ef63807ba8f784dbde1de8d74b0901e0de641a4")
addappid(3200016, 1, "12f08bbbdf0a3e797cdd5731b673c55687f15e9f759c39ed57e2c19ae6a78f4a")
addappid(3200017, 1, "c4f3b6c89af63f77319fa015803111ec057363be01005c8845afe424944157f5")
addappid(3200018, 1, "23b1043c426fcef8718b718aa217eed83ab71e67ec8cbaa828bc2f278d8edb4e")
addappid(3401291, 0, "f9560d58f763e869570a734795ba184ea5ba77302c2170ec436972fc4c176ac7")
