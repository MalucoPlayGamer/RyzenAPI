-- Lua provided by RyzenAPI 
-- Game: Lady Knight Quest
addappid(3451330)
addappid(3451331, 1, "bcbaa19f1515b2543246d924ec58b070fe5a669b1c93e7b924ba0dfbe7aa0189")
addappid(3451332, 1, "0d10d9f58205cde6a0a593f8abfd5356dbce90b9374bb0c80653a3d93c2e0e90")
