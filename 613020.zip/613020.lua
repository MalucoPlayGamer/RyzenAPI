-- Lua provided by RyzenAPI
-- Game: Gem Hunter

-- MAIN APPLICATION
addappid(613020)

-- MAIN APP DEPOTS / PACKAGES
addappid(613021,0,"0bce9b2de71771f0b020390260e8fbc4fc28a46e5cb3e36c5c43ca555ff14c88")

