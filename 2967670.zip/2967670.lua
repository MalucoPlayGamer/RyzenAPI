-- Lua provided by RyzenAPI
-- Game: Cupiclaw

-- MAIN APPLICATION
addappid(2967670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967671,0,"76d22c931750dd895d121439e09b1282a863c4bac20a29487918fc6d4ab2bf87")

