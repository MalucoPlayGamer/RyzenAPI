-- Lua provided by RyzenAPI
-- Game: 2387510

-- MAIN APPLICATION
addappid(2387510)
-- Game: addappid(2387510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387511, 1, "58cdca72afa74efa3e454faf0110c119ff06bffd2fafb0a12335fe4a9e26b178")
