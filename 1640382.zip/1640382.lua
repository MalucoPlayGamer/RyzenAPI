-- Lua provided by RyzenAPI
-- Game: addappid(1640382)

-- MAIN APPLICATION
addappid(1640382)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712090,0,"7b7e9267b1d355dfb97dd91f33956fa4e2f65b426980ac54d4a9b54bd1140911")
