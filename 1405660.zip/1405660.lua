-- Lua provided by RyzenAPI
-- Game: 1405660

-- MAIN APPLICATION
addappid(1405660)
-- Game: addappid(1405660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405661, 1, "486bbd6889295eabe558d318911b750096fd245ea18e85d68a46d090c2bea36d")
