-- Lua provided by RyzenAPI 
-- Game: AppID 865680
addappid(865680)
addappid(865681, 1, "ad2bfad0e10fcd80b584b45222906cf418640f0ca092dc14d67d2732faebc48e")
