-- Lua provided by RyzenAPI
-- Game: Pocket Penguin DX ( ポケットペンギン): A Retro Style Adventure

-- MAIN APPLICATION
addappid(1456340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456342,0,"81284db3e1337cf4eae666ec46812e5d24132729911bf8243ad785091574b27d")

