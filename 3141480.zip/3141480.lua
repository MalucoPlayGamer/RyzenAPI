-- Lua provided by RyzenAPI
-- Game: Immortals Revenge

-- MAIN APPLICATION
addappid(3141480)

