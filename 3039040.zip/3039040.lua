-- Lua provided by RyzenAPI
-- Game: Arcane Rush

-- MAIN APPLICATION
addappid(3039040)
