-- Lua provided by RyzenAPI
-- Game: PEP

-- MAIN APPLICATION
addappid(2164080)
-- Game: addappid(2164080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164081, 1, "89f87837536a9f48c89fe2cd47b6b6dc83943388c2705f5fa91dee6f97d7345e")
