-- Lua provided by SkyAPI 
-- Game: Furry Love
addappid(1334590)
addappid(1334591, 1, "1e97eafaac6e5c5c87a3b3787b3de63201e9b7be907e705c7ea4669d38d3ac43")
addappid(1334592, 1, "fd80fb532d6e91dfb640c4f299835fd99aeeb2c6b3b0c054b47f010fddf2f885")
addappid(1334593, 1, "453da689e3c233043c51c99230eb7a72dfdb7cb8f77070c65c4b61f37188adc8")
addappid(1334594, 1, "fe81177d3236d35d14d8b64420d105f1483ebfc5aab22bab59f0e5121c69a3d7")
addappid(1356100)
