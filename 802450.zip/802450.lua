-- Lua provided by RyzenAPI
-- Game: NAIRI: Tower of Shirin

-- MAIN APPLICATION
addappid(802450)
addappid(991010)
addappid(991011)

-- MAIN APP DEPOTS / PACKAGES
addappid(802451, 1, "1ba83c1d86522d433c620bd264bfcd228c89ff572bdc8c4f9ebcee7ea3f4a16b")

