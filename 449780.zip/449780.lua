-- Lua provided by RyzenAPI
-- Game: Jacob

-- MAIN APPLICATION
addappid(449780)

-- MAIN APP DEPOTS / PACKAGES
addappid(449781, 1, "38a68407db3b8234edbf7fbd97b633d89da9b3d561f0c1f45242082a254459a2")
