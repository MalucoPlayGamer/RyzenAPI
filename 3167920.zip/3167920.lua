-- 3167920's Lua and Manifest Created by Hubcap Manifest
-- Low-Budget Repairs
-- Created: August 13, 2026 at 11:34:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3167920, 1, "1cc070798c547c218ca5b280a7ec44c479839c6c2bbc7bcdfb1e96b0cf17c99a") -- Low-Budget Repairs
-- MAIN APP DEPOTS
addappid(3167921, 1, "1ed77059aee14eb6bb4872955ca84a0ae7880ce352cbfffefbbd91eca2e98006") -- Depot 3167921
setManifestid(3167921, "6912101174459997301", 25513824745)