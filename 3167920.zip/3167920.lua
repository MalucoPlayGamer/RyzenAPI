-- Lua provided by RyzenAPI
-- Game: Low-Budget Repairs

-- MAIN APPLICATION
addappid(4948230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167920, 1, "1cc070798c547c218ca5b280a7ec44c479839c6c2bbc7bcdfb1e96b0cf17c99a") -- Low-Budget Repairs
addappid(3167921, 1, "1ed77059aee14eb6bb4872955ca84a0ae7880ce352cbfffefbbd91eca2e98006") -- Depot 3167921
addappid(4948230, 1, "8d0687c48e6b694c4e272f79155968c895660a6295ecee04387f52316b384c66") -- Low-Budget Repairs Supporter Pack - Depot 4948230

