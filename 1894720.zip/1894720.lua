-- Lua provided by RyzenAPI 
-- Game: Motordoom
addappid(1894720)
addappid(1894721, 1, "bf1ab5b0c8cf6f29cbe7414c2bb675ff19cbd12f98692ca621b67fcb30acc613")
