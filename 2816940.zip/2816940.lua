-- Lua provided by RyzenAPI
-- Game: Bloody Heaven 2

-- MAIN APPLICATION
addappid(2816940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2816941, 1, "824ab15f03c4e2c2cee5418c086234c683e6a564a6757b98c5fd45418e468aa5")
