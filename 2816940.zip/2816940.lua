-- Lua provided by SkyAPI 
-- Game: Bloody Heaven 2
addappid(2816940)
addappid(2816941, 1, "824ab15f03c4e2c2cee5418c086234c683e6a564a6757b98c5fd45418e468aa5")
