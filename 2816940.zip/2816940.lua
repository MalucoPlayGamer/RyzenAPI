-- Lua provided by RyzenAPI
-- Game: Bloody Heaven 2

-- MAIN APPLICATION
addappid(2816940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2816941, 1, "824ab15f03c4e2c2cee5418c086234c683e6a564a6757b98c5fd45418e468aa5")

