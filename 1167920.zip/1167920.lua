-- Lua provided by RyzenAPI
-- Game: 1167920

-- MAIN APPLICATION
addappid(1167920)
-- Game: addappid(1167920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167921, 1, "84a9248ec9dd2f1761cf810e64cebd2f2f81cedc3ffaed4c07fac96d2cb2a2e1")
