-- Lua provided by SkyAPI 
-- Game: AppID 1167920
addappid(1167920)
addappid(1167921, 1, "84a9248ec9dd2f1761cf810e64cebd2f2f81cedc3ffaed4c07fac96d2cb2a2e1")
