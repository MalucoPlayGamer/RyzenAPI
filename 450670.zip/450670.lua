-- Lua provided by RyzenAPI
-- Game: Table Top Racing: World Tour

-- MAIN APPLICATION
addappid(450670)

-- MAIN APP DEPOTS / PACKAGES
addappid(450671, 1, "e1483cd3544f50fbb18be6f73780c18de949fbe2e13e51ae7edf348144531614")
addappid(450750, 0, "86e0ad6871bb7906925d06761eedb8a1d438917df8f40647e52b5914a94dd480")
addappid(512940, 0, "f3ab3c1e3c67a062dd9d783cad6a3ca1400772a7d9a98f6936edd2cc45562527")
