-- Lua provided by RyzenAPI
-- Game: Game: Grid Ranger

-- MAIN APPLICATION
addappid(2964400)
-- Game: addappid(2964400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964401, 1, "0396a501399ee8cbfd2b19213de4008a1d29a7081d57d83f38e3db679f1f0c85")
