-- Lua provided by RyzenAPI
-- Game: Goat over it

-- MAIN APPLICATION
addappid(1519660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519661, 1, "f6d09a19b153ced4748638a1bc5c4c83dfa0baded3f36d4c13d91d599f98f004")

