-- Lua provided by RyzenAPI
-- Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.7「音成刑事の捜査メモ」

-- MAIN APPLICATION
addappid(2307330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307331, 1, "e6b063a0794cff60df899589e2723376bdd2aa5f800248fceae2a2c3ccc3bd49")
