-- Lua provided by RyzenAPI
-- Game: Ludus Magnatus: Gladiator Manager Simulator

-- MAIN APPLICATION
addappid(4088670)

-- MAIN APP DEPOTS / PACKAGES
addappid(4088671,0,"d36618e6d6424b3742175ed09415c35d06f7efc85b789c64cfacf8248468720b")

