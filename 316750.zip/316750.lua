-- Lua provided by RyzenAPI
-- Game: addappid(316750)

-- MAIN APPLICATION
addappid(316750)

-- MAIN APP DEPOTS / PACKAGES
addappid(316751, 1, "ad78b904ed2774f72d8cdbd6e570f900ab62b4db858ed29db09f90f50c4dfa5b")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
