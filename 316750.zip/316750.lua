-- Lua provided by RyzenAPI
-- Game: Tetris® Ultimate

-- MAIN APPLICATION
addappid(316750)

-- MAIN APP DEPOTS / PACKAGES
addappid(316751, 1, "ad78b904ed2774f72d8cdbd6e570f900ab62b4db858ed29db09f90f50c4dfa5b")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
