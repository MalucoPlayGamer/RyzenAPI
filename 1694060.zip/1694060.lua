-- Lua provided by RyzenAPI
-- Game: The Great Ace Attorney: Adventures Grand Performance Recording

-- MAIN APPLICATION
addappid(1694060)
-- Game: addappid(1694060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694061, 1, "4d33c30230452e71f41ae6ac3590eb572871472308d25cbbd5223574aa83a871")
addappid(1694062, 1, "23ee8fee18999bbdb6ffb37fac82e02b19de551bc79e1b54b690682e6f4b8935")
addappid(1694063, 1, "6f5839b3aabf470056e612e9baf5b050cd3c57c26e7ff9f297a62620c3307390")
