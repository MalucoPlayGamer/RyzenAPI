-- Lua provided by RyzenAPI 
-- Game: Hellwatch: Prelude
addappid(2659030)
addappid(2659031, 1, "da92306db433f83d2d440f5ccb2bc9747b4c1f110422871538819be0fa348d66")
