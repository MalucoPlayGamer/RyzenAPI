-- Lua provided by RyzenAPI
-- Game: Game: VoidExpanse

-- MAIN APPLICATION
addappid(324260)
addappid(499410)
addappid(499411)
addappid(499412)
addappid(602740)
-- Game: addappid(324260)

-- MAIN APP DEPOTS / PACKAGES
addappid(324261, 1, "e146ebc692091c9d8a5db3aafc37001dd134b734fcf20d7a168480dfdaed9d58")
addappid(324262, 1, "8cb285c97a25a4b4f3031d0c22349e0f88f08c69e21e12736abc8955a5696d23")
addappid(324263, 1, "6235169779f0459dc4194873ba3c66b8b7c4eb844ed28c5805759c235717eee2")
