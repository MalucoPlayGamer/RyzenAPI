-- Lua provided by RyzenAPI
-- Game: VoidExpanse

-- MAIN APPLICATION
addappid(324260)
addappid(499410)
addappid(499411)
addappid(499412)
addappid(602740)

-- MAIN APP DEPOTS / PACKAGES
addappid(324261, 1, "e146ebc692091c9d8a5db3aafc37001dd134b734fcf20d7a168480dfdaed9d58")
addappid(324262, 1, "8cb285c97a25a4b4f3031d0c22349e0f88f08c69e21e12736abc8955a5696d23")
addappid(324263, 1, "6235169779f0459dc4194873ba3c66b8b7c4eb844ed28c5805759c235717eee2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
