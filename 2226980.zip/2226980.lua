-- Lua provided by SkyAPI 
-- Game: Iron Diamond
addappid(2226980)
addappid(2226981, 1, "fe10b32e9c4d809146ef8c387f1ad48d9b82ba5ecff430a952736eaed53cbed3")
