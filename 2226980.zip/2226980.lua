-- Lua provided by RyzenAPI
-- Game: Game: Iron Diamond

-- MAIN APPLICATION
addappid(2226980)
-- Game: addappid(2226980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226981, 1, "fe10b32e9c4d809146ef8c387f1ad48d9b82ba5ecff430a952736eaed53cbed3")
