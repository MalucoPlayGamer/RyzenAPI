-- Generated with Luie @ https://lua.tools/
-- 3811040 - Femboy Streamer
-- Generated 2026-08-21 22:47:29 UTC
-- # Depots (Total/DLC/Shared): 3/2/0

-- Main AppID
addappid(3811040)

-- Main Depots
addappid(3811041, 1, "610040c88b549cd7dc2b5fed343e921838945aa78a871d7643fcc404960c289f")
setManifestid(3811041, "2387628412127833310", 532672235)

-- DLC's (with depot keys)
-- Femboy Streamer - CG Gallery (AppID: 4114740)
addappid(4114740)
addappid(4114740, 1, "4dc6a01c0ed02ee888bcd29eb80eba6599be0bfa6546093fdda7fe96608717a0")
setManifestid(4114740, "8533483476828431615", 18217)
-- Femboy Streamer - Wallpaper Pack (AppID: 4114750)
addappid(4114750)
addappid(4114750, 1, "03e3c25a742d55913bbb456db2a880028dbba0538eeb84f3b9d3f2d93081137d")
setManifestid(4114750, "4567197450630666334", 73554376)
