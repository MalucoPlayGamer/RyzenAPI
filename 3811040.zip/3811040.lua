-- Lua provided by RyzenAPI
-- Game: Femboy Streamer

-- MAIN APPLICATION
addappid(3811040)
addappid(4114740)
addappid(4114750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3811041, 1, "610040c88b549cd7dc2b5fed343e921838945aa78a871d7643fcc404960c289f")
addappid(4114740, 1, "4dc6a01c0ed02ee888bcd29eb80eba6599be0bfa6546093fdda7fe96608717a0")
addappid(4114750, 1, "03e3c25a742d55913bbb456db2a880028dbba0538eeb84f3b9d3f2d93081137d")

