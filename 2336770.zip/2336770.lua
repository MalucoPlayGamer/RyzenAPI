-- Lua provided by RyzenAPI
-- Game: Game: AppID 2336770

-- MAIN APPLICATION
addappid(2336770)
-- Game: addappid(2336770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336771, 1, "4d54ed1834fd06c5d7a4a0b11b6824201ac90fa60961a69d8afed62257e91b35")
