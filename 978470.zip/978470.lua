-- Lua provided by SkyAPI 
-- Game: Clicker: Glad Valakas
addappid(978470)
addappid(978471, 1, "8580fee9198442fb264641e5c66a4bf7ffab0f3724710eaf78f6780d8cbc8b2e")
