-- Lua provided by RyzenAPI
-- Game: 978470

-- MAIN APPLICATION
addappid(978470)
-- Game: addappid(978470)

-- MAIN APP DEPOTS / PACKAGES
addappid(978471, 1, "8580fee9198442fb264641e5c66a4bf7ffab0f3724710eaf78f6780d8cbc8b2e")
