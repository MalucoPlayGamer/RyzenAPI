-- Lua provided by RyzenAPI
-- Game: Dad's Monster House

-- MAIN APPLICATION
addappid(1347600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347601, 1, "4f0708670d6b8b5db32a6d5446df73917e63efcb01bcd9576dbb8ba1ffb540a7")

