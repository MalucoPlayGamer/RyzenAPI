-- Lua provided by RyzenAPI
-- Game: Xenoraid

-- MAIN APPLICATION
addappid(460220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(460221, 1, "728a149205810867f1e60a117d8a30387d89831959d2d49582fc33515ce7413b")
