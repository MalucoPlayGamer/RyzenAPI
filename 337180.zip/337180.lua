-- Lua provided by SkyAPI 
-- Game: Velocity 2X
addappid(337180)
addappid(337181, 1, "5d3217cc2ee0573a8c003b6529ad6ccb9ab1bda28292bcb6dfdc91c50a362ba5")
addappid(337182, 1, "fa5bc42490999afc8cf75a0c5e5183a9c0ec2706ada1afa71e342ddabe3235a0")
