-- Lua provided by RyzenAPI
-- Game: Velocity 2X

-- MAIN APPLICATION
addappid(337180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(337181, 1, "5d3217cc2ee0573a8c003b6529ad6ccb9ab1bda28292bcb6dfdc91c50a362ba5")
addappid(337182, 1, "fa5bc42490999afc8cf75a0c5e5183a9c0ec2706ada1afa71e342ddabe3235a0")

