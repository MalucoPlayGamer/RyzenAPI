-- Lua provided by RyzenAPI
-- Game: Skarab

-- MAIN APPLICATION
addappid(3557830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3557831, 1, "032d1f37775427364edd2b2bf75f676b4ccfa3ffc8cd3f19bb554673e95d1e88")

