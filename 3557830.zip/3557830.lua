-- Lua provided by RyzenAPI
-- Game: 3557830

-- MAIN APPLICATION
addappid(3557830)
-- Game: addappid(3557830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3557831, 1, "032d1f37775427364edd2b2bf75f676b4ccfa3ffc8cd3f19bb554673e95d1e88")
