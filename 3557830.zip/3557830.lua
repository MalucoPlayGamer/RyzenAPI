-- Lua provided by RyzenAPI 
-- Game: Skarab
addappid(3557830)
addappid(3557831, 1, "032d1f37775427364edd2b2bf75f676b4ccfa3ffc8cd3f19bb554673e95d1e88")
