-- Lua provided by RyzenAPI
-- Game: AppID 912560

-- MAIN APPLICATION
addappid(912560)

-- MAIN APP DEPOTS / PACKAGES
addappid(912561, 1, "1533d3bdd560769d6ad712bcac06f56d04bad7d96dd21256e5278ce9884d53e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
