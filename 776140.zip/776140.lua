-- Lua provided by RyzenAPI 
-- Game: AppID 776140
addappid(776140)
addappid(776141, 1, "a449a09b8bd4585174607781ca8ddc07f6f5faa9e42eb1e0fd8f3b0460979939")
