-- Lua provided by RyzenAPI
-- Game: Leap Year

-- MAIN APPLICATION
addappid(2951770)
addappid(3458170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951771, 1, "06ab3cc875db4c6cbb8d9a4a1b380cf73d4fd5d869b0ad92e09de4a42759dcd5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
