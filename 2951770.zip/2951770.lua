-- Lua provided by RyzenAPI
-- Game: 2951770

-- MAIN APPLICATION
addappid(2951770)
addappid(3458170)
-- Game: addappid(2951770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951771, 1, "06ab3cc875db4c6cbb8d9a4a1b380cf73d4fd5d869b0ad92e09de4a42759dcd5")
