-- Lua provided by RyzenAPI
-- Game: Dark Elf Historia

-- MAIN APPLICATION
addappid(2492730)
-- Game: addappid(2492730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492731, 1, "1d75534c8f84f7ffc03b72c0233ee5c0e29a09be181953b606942c6604248e7d")
addappid(2492732, 1, "ac039b9ba43cc6f064a54f20b4b7a3f9aa63e692060b80f4fa72482864f8fccc")
addappid(2492733, 1, "64eb171e6e32376655914a80d3b97c5bf9b0a97be811eb947a39a33eea7f0d05")
