-- Lua provided by RyzenAPI
-- Game: Blastforge Breach

-- MAIN APPLICATION
addappid(3706040)
-- Game: addappid(3706040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3706041, 1, "d2d3bc4c3b680944bc42e0a0c1b1846a65bb78fe27110e2347980713ef451710")
