-- Lua provided by RyzenAPI
-- Game: Urban Empire

-- MAIN APPLICATION
addappid(352550)

-- MAIN APP DEPOTS / PACKAGES
addappid(352551, 1, "72323988dbc9a3a2605bffa0dd8cbb81c140e349d46d73f31e97566cce89a943")
addappid(352552, 1, "374576742c1062778ab170d13b66e80e8f947cdd8a02a707af761072811c6796")
addappid(352553, 1, "ab7f4a15e4743dd7221c59c7b43172fd107113f48eacee2f931dd6e46c2a6271")
addappid(352554, 1, "f703f5fc6378905ef996fc65f025134c3dfb6a5ec771fe216d7ffa453a169d9e")
addappid(352555, 1, "99f5817adead26b0c2168950aa341bbec93fcc2ebac9a6e28669caa1abf8d85b")
addappid(352557, 1, "1ce9a539454dae376703b9776581aef9d4b9ccca508163d36e06fcdc97c159d6")
addappid(501540, 0, "fce169f340259c7a09bc5bb26e5412b6339bdd2080a39b3674101874102ff922")
addappid(501541, 0, "56603b7c3bccb0fc46f6d805c7138eb18a4b63240088181d91d8cc432a4647ec")
addappid(557511, 0, "3b5d130be46d04c2e3eaf9ff21e9ecdfad2498c58d4d2aef1be11c958593972d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(557510)
