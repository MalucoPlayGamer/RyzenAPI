-- Lua provided by RyzenAPI
-- Game: Saihate Station

-- MAIN APPLICATION
addappid(3079280)
addappid(3216040)
addappid(3331460)
addappid(4143660)

