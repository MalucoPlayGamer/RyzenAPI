-- Lua provided by RyzenAPI
-- Game: Saihate Station

-- MAIN APPLICATION
addappid(3079280)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3216040)
addappid(3331460)
addappid(4143660)
