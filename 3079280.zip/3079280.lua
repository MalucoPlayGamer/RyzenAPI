-- Lua provided by RyzenAPI
-- Game: Saihate Station

-- MAIN APPLICATION
addappid(3079280)

