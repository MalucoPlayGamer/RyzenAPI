-- Lua provided by RyzenAPI
-- Game: Rumble Fighter: Unleashed

-- MAIN APPLICATION
addappid(357500)

