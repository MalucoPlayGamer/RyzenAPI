-- Lua provided by RyzenAPI
-- Game: Evolings

-- MAIN APPLICATION
addappid(2281820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281821, 1, "d54347e07c562c7ba1b5cef0e354a68dce04e3148630dc64d2a804ab50111450")

