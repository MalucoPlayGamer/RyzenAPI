-- Lua provided by RyzenAPI
-- Game: FUSER™ - The Clash - "Should I Stay or Should I Go"

-- MAIN APPLICATION
addappid(1460363)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460363,0,"6181918a82703e2744bf2ded6719953f88e988a16a97497daa921c65bf493662")
