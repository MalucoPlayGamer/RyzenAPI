-- Lua provided by RyzenAPI
-- Game: Dicey Bugs

-- MAIN APPLICATION
addappid(3438640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3438641,0,"6e0578dc885543a84099cc2a24b8fc32e24e4b62236b7c156a2a6b1bde8cf528")
addappid(3438642,0,"117eb5472e0d4a8a5ae3c75d2640c3ccfbfcb16ac1d00ac0bbc94ebeba8b77d5")

