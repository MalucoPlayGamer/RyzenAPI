-- Lua provided by SkyAPI 
-- Game: AppID 851980
addappid(851980)
addappid(851981, 1, "bfbc3933ab938e8c93fe2470b3bf7f033a452eb8d574a6c5455ccc45302a4223")
