-- Lua provided by RyzenAPI
-- Game: Century: Age of Ashes

-- MAIN APPLICATION
addappid(918570)
addappid(1682640)
addappid(1691470)
addappid(1691471)
addappid(1850770)
addappid(1851500)
addappid(1851510)
addappid(1852460)
addappid(1907460)
addappid(1938960)
addappid(1938961)
addappid(1938962)
addappid(2194650)
addappid(2199670)
addappid(2200870)
addappid(2200880)
addappid(2347230)
addappid(2496230)
addappid(2689430)
addappid(2731380)
addappid(2731390)
addappid(3059020)

-- MAIN APP DEPOTS / PACKAGES
addappid(918571,0,"a93b27550f2a4862a1d66a3dafa345b2bc7a796274a2f732caca7d6aa08e7a66")

