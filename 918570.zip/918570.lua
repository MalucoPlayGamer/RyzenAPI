-- Lua provided by RyzenAPI
-- Game: Century: Age of Ashes

-- MAIN APPLICATION
addappid(918570)
addappid(1682640)
addappid(1691470)
addappid(1691471)
addappid(1850770)
addappid(1851500)
addappid(1851510)
addappid(1852460)
addappid(1907460)
addappid(1938960)
addappid(1938961)
addappid(1938962)
addappid(2194650)
addappid(2199670)
addappid(2200870)
addappid(2200880)
addappid(2347230)
addappid(2496230)
addappid(2689430)
addappid(2731380)
addappid(2731390)
addappid(3059020)

-- MAIN APP DEPOTS / PACKAGES
addappid(918571,0,"a93b27550f2a4862a1d66a3dafa345b2bc7a796274a2f732caca7d6aa08e7a66")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
