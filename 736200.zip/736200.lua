-- Lua provided by RyzenAPI 
-- Game: AppID 736200
addappid(736200)
addappid(736201, 1, "0f9bb10e28eae4e8d1e822adac4494a2e08e552dec9d0f36577edae3dcfdb85a")
