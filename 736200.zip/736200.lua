-- Lua provided by RyzenAPI
-- Game: Game: AppID 736200

-- MAIN APPLICATION
addappid(736200)
-- Game: addappid(736200)

-- MAIN APP DEPOTS / PACKAGES
addappid(736201, 1, "0f9bb10e28eae4e8d1e822adac4494a2e08e552dec9d0f36577edae3dcfdb85a")
