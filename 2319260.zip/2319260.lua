-- Lua provided by RyzenAPI 
-- Game: Toon Toon Racing
addappid(2319260)
addappid(2319261, 1, "5aba84667c113201f91ab3083d751f85142db6c0f1ae83282d70fc017e422d05")
