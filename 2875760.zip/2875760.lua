-- Lua provided by RyzenAPI
-- Game: 幻象游园剧 Demo

-- MAIN APPLICATION
addappid(2875760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875761, 1, "e27d2748abd39c826aaacf4412bfbd63483b0e70d47278fa75192c08ed726987")
