-- Lua provided by RyzenAPI
-- Game: The Hungry Lamb: Digital Artbook

-- MAIN APPLICATION
addappid(3424250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3424251, 1, "ed79b2517c6c65f86ddcb45e48bdf4237c1c2d3a89a483516558840a3b9cbe59")

