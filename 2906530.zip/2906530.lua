-- Lua provided by RyzenAPI
-- Game: Game: Cozy Merge

-- MAIN APPLICATION
addappid(2906530)
-- Game: addappid(2906530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906531, 1, "a64e598419c6950fffaee21f50e45dbb9c72c55d8cb8dbeac01891cf5d51f79c")
