-- Lua provided by RyzenAPI 
-- Game: Cozy Merge
addappid(2906530)
addappid(2906531, 1, "a64e598419c6950fffaee21f50e45dbb9c72c55d8cb8dbeac01891cf5d51f79c")
