-- Lua provided by RyzenAPI
-- Game: Ace Attorney Investigations Collection DEMO

-- MAIN APPLICATION
addappid(2728410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2728411, 1, "22fae1a74501c14bd1e218ae522e31a08906baf70550ef99e87d9a0a522737e2")

