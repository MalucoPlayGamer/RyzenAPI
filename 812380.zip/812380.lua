-- Lua provided by SkyAPI 
-- Game: Flock of Dogs
addappid(812380)
addappid(812381, 1, "e2f1baa7d6adb2a12b28c39353e03da57caa2d947540e4c8e5c7bfe69dcca681")
addappid(812382, 1, "88ed530326471cbd0e240d5ffd334af7284d7fc2d7b45659bbdca8183ea50b1b")
addappid(812383, 1, "1fa7cba95e632dbf1538e0047de46f6d89f29914b673c0d0b23fff7207c5f1d2")
addappid(2236640)
addappid(2306550)
