-- Lua provided by RyzenAPI
-- Game: Incredicer

-- MAIN APPLICATION
addappid(3929760)
addappid(4173070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3929761,0,"ca87053fe81e5ddd672c60a73a803b820277167ed0de1e3313a5f0adfc8c5dfb")
