-- Lua provided by RyzenAPI
-- Game: The Chronicle

-- MAIN APPLICATION
addappid(2004520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004521, 1, "7bf91424a6d46085403cc6e98509ff54017a3dd90647096b149d6ebed1279215")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
