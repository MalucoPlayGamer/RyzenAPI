-- Lua provided by RyzenAPI
-- Game: Game: The Chronicle

-- MAIN APPLICATION
addappid(2004520)
-- Game: addappid(2004520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004521, 1, "7bf91424a6d46085403cc6e98509ff54017a3dd90647096b149d6ebed1279215")
