-- Lua provided by RyzenAPI
-- Game: Definitely Sneaky But Not Sneaky

-- MAIN APPLICATION
addappid(954010)

-- MAIN APP DEPOTS / PACKAGES
addappid(954011, 1, "c58432aec9cfde5dd3442b1f83c1de3181d8c1533b29f1f1d06b3e92cf4c06bf")

