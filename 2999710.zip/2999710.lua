-- Lua provided by RyzenAPI
-- Game: 2999710

-- MAIN APPLICATION
addappid(2999710)
-- Game: addappid(2999710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999711, 1, "63014c166fd2a98a8a8090b8a3a1b033bd6e421e219fa397174fec155d2840ba")
