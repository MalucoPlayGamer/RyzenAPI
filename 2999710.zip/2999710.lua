-- Lua provided by SkyAPI 
-- Game: Unsought
addappid(2999710)
addappid(2999711, 1, "63014c166fd2a98a8a8090b8a3a1b033bd6e421e219fa397174fec155d2840ba")
