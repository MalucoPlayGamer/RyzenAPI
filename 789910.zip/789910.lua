-- Lua provided by RyzenAPI
-- Game: AppID 789910

-- MAIN APPLICATION
addappid(789910)
-- Game: addappid(789910)

-- MAIN APP DEPOTS / PACKAGES
addappid(789911, 1, "0ff37e60674b9d687db1304ed7cf7b9d1be166c03a96f63954aaf54df2cc4e1d")
