-- Lua provided by RyzenAPI
-- Game: Planet of the Apes: Last Frontier

-- MAIN APPLICATION
addappid(789910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(789911, 1, "0ff37e60674b9d687db1304ed7cf7b9d1be166c03a96f63954aaf54df2cc4e1d")

