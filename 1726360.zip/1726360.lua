-- Lua provided by RyzenAPI
-- Game: 1726360

-- MAIN APPLICATION
addappid(1726360)
addappid(1813520)
-- Game: addappid(1726360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726361, 1, "b620d9849edfad3675e21293793272667aa1fef5d21b84c1bcdb81f85dd8319b")
