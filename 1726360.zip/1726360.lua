-- Lua provided by RyzenAPI
-- Game: Peter's Adventures in English [Learn English]

-- MAIN APPLICATION
addappid(1726360)
addappid(1813520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726361, 1, "b620d9849edfad3675e21293793272667aa1fef5d21b84c1bcdb81f85dd8319b")
