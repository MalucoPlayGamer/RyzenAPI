-- Lua provided by RyzenAPI
-- Game: 街机金蟾捕鱼2

-- MAIN APPLICATION
addappid(1403750)
-- Game: addappid(1403750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403751, 1, "5159d0f95646b7e2dc0b51744b05edab7d2d0949b93817247210200fab0398b8")
