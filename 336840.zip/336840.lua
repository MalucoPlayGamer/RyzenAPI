-- Lua provided by RyzenAPI
-- Game: addappid(336840)

-- MAIN APPLICATION
addappid(336840)
addappid(370890)

-- MAIN APP DEPOTS / PACKAGES
addappid(336841, 1, "9a0f2aa9181a237dde53de57a37f2fa504b7762022b7f9ccf71eb10fd32207a8")
