-- Lua provided by RyzenAPI
-- Game: Candy Disaster - Tower Defense

-- MAIN APPLICATION
addappid(1231460)
-- Game: addappid(1231460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231462,0,"0ed52a76045afcb049117291d4a67541f046ee3d7dc31be292d4dfb9b5246a39")
addappid(1231463,0,"5c74aac4edf68da42e89db0cd69f8d7b927e274775407239203b51ba4197b6b0")
addappid(1231464,0,"80ce24d9bf9ba7c13240dbbb076659bff15d128ddf409d5b4257d245c4ecf332")
