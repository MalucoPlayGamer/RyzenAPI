-- Lua provided by RyzenAPI
-- Game: 563830

-- MAIN APPLICATION
addappid(563830)
-- Game: addappid(563830)

-- MAIN APP DEPOTS / PACKAGES
addappid(563831, 1, "f9afafe6b55abd0408f6feb0c3efc5e11a0d352ae40d901e6797302e879069f6")
