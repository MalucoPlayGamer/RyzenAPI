-- Lua provided by RyzenAPI
-- Game: Danganronpa 2: Goodbye Despair

-- MAIN APPLICATION
addappid(413420)

-- MAIN APP DEPOTS / PACKAGES
addappid(413421, 1, "65dd2d598e63ea5ac5c2ccd8a31a71ccb73169f4117c991fa40a8d0fa7f02bdb")
addappid(413422, 1, "a315983577505ccbbff926c252bc06912f1487dd68b7cef7f9eb420c5d199944")
addappid(413423, 1, "eda8cf7512bf7cc489c2bfa82878b18813f77f593e926059b5f709cafa6d8fcf")
addappid(413424, 1, "9477631711d08c528c8b5d021afdac892141f0fdd9228157884aaa2c128862fb")
addappid(413425, 1, "9e198ebff66a43ab19b0ea470fb54f3d13df1c07c50165ade299b54a3848b44d")
addappid(413426, 1, "ac7959cd7d6badec27457439489adf9c8c3803afd22b9ebc331196ded49b3d57")
