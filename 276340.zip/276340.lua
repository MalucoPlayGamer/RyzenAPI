-- Lua provided by RyzenAPI
-- Game: addappid(276340)

-- MAIN APPLICATION
addappid(276340)

-- MAIN APP DEPOTS / PACKAGES
addappid(276341, 1, "2db6cf048085b7a200e5acc4e5aabd5ca37c47ed43e903ab8a647f2086ec32cd")
addappid(276342, 1, "6c5b7c17de7d237dd105a6c23133bfad995e90c260e026fe64cac28ba8374c7a")
