-- Lua provided by RyzenAPI 
-- Game: CrossHud - Crosshair Overlay
addappid(2095190)
addappid(2095191, 1, "0ccd5788960ec0d430bdabec66325c1e1cb0195d5fa1ebd9956f8b9870f52e02")
