-- Lua provided by RyzenAPI
-- Game: 2095190

-- MAIN APPLICATION
addappid(2095190)
-- Game: addappid(2095190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095191, 1, "0ccd5788960ec0d430bdabec66325c1e1cb0195d5fa1ebd9956f8b9870f52e02")
