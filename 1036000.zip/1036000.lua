-- Lua provided by RyzenAPI
-- Game: The Ploshers

-- MAIN APPLICATION
addappid(1036000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036001, 1, "8a75d1b13a926e96f7a01c03b22c09e9193e3b118433b786d9ff69e195904e7e")

