-- Lua provided by RyzenAPI
-- Game: OPUS: Rocket of Whispers Official Artbook + Bonus World Map

-- MAIN APPLICATION
addappid(1792990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792990,0,"220c74733263e4c1bf78a20b81cd40394b5bfcdf7031b450da23cccb03780c3b")

