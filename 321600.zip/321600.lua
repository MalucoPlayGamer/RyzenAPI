-- Lua provided by RyzenAPI
-- Game: AppID 321600

-- MAIN APPLICATION
addappid(321600)
-- Game: addappid(321600)

-- MAIN APP DEPOTS / PACKAGES
addappid(321601, 1, "1207d9f92a79ea268b42b897710e022ae3dc156797a6109deebd91febb80a301")
