-- Lua provided by RyzenAPI
-- Game: Roto Force

-- MAIN APPLICATION
addappid(1181610)
-- Game: addappid(1181610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181612,0,"c1f912991b5ed87c3c66987ba1c1d2bf27982c0351715e3eb608631cea937414")
