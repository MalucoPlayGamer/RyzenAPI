-- Lua provided by RyzenAPI 
-- Game: AppID 2656330
addappid(2656330)
addappid(2656331, 1, "ec511d390865932e341271b83a7289790a47fd3c304124ddf0a3de2586258748")
