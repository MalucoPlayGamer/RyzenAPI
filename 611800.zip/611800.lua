-- Lua provided by RyzenAPI
-- Game: Game: AppID 611800

-- MAIN APPLICATION
addappid(611800)
-- Game: addappid(611800)

-- MAIN APP DEPOTS / PACKAGES
addappid(611801, 1, "c4de051e6e2c6d04c8a4047c12a88604662112e1bb34813a2094ad34e8206223")
