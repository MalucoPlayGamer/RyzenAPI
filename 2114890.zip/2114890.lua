-- Lua provided by RyzenAPI
-- Game: War Obelisks

-- MAIN APPLICATION
addappid(2114890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114891, 1, "adf3118316d03de5c3da2edfc02cd45a241dfd1e1fbc8e8e383587ff2d091aad")

