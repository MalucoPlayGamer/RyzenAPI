-- Lua provided by RyzenAPI 
-- Game: War Obelisks
addappid(2114890)
addappid(2114891, 1, "adf3118316d03de5c3da2edfc02cd45a241dfd1e1fbc8e8e383587ff2d091aad")
