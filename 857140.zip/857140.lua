-- Lua provided by RyzenAPI
-- Game: Snake, snake, snake!

-- MAIN APPLICATION
addappid(857140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(857141, 1, "578cf5ca07e124a346ef16d3731c6d0872ad8a72cbc07e01e8f1a3b4b6e9bd8b")

