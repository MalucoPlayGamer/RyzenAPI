-- Lua provided by RyzenAPI
-- Game: Game: Snake, snake, snake!

-- MAIN APPLICATION
addappid(857140)
-- Game: addappid(857140)

-- MAIN APP DEPOTS / PACKAGES
addappid(857141, 1, "578cf5ca07e124a346ef16d3731c6d0872ad8a72cbc07e01e8f1a3b4b6e9bd8b")
