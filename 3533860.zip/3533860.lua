-- Lua provided by RyzenAPI 
-- Game: AppID 3533860
addappid(3533860)
addappid(3533861, 1, "fa0c30a2bfa648a3f2286438f0e3cf92f01ee83293b28b7def5e3f98f9964f4b")
