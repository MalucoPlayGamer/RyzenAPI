-- Lua provided by RyzenAPI
-- Game: addappid(642610)

-- MAIN APPLICATION
addappid(642610)

-- MAIN APP DEPOTS / PACKAGES
addappid(642611, 1, "9c3a2018fc075d19fbc17daa72bd9cf3073ba0159f73dbfa3620577eef11b21e")
