-- Lua provided by SkyAPI 
-- Game: AppID 642610
addappid(642610)
addappid(642611, 1, "9c3a2018fc075d19fbc17daa72bd9cf3073ba0159f73dbfa3620577eef11b21e")
