-- Lua provided by RyzenAPI
-- Game: AppID 992330

-- MAIN APPLICATION
addappid(992330)

-- MAIN APP DEPOTS / PACKAGES
addappid(992331, 1, "cee7042aa3ac1d7113ab4d4d67b77b3a39e34735ca290a5585a36222fd1465ac")

