-- Lua provided by RyzenAPI
-- Game: 789670

-- MAIN APPLICATION
addappid(789670)
-- Game: addappid(789670)

-- MAIN APP DEPOTS / PACKAGES
addappid(789671, 1, "2d2a0ffdb7fb0b834b93d1dc0e936e0d399fb719166ee866ace911d451f945aa")
