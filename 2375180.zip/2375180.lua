-- Lua provided by SkyAPI 
-- Game: Hypno-Mart
addappid(2375180)
addappid(2375181, 1, "d9b759b2de5a44942daadb87272008f15b098998d517ba741ef8522b8c88d443")
