-- Lua provided by RyzenAPI 
-- Game: MADiSON VR
addappid(2414550)
addappid(2414551, 1, "1e868e36fc545f13dcd46ab60cfd14d400fdf1495423a60a2c3d841d73235fe8")
