-- Lua provided by RyzenAPI
-- Game: ObserVRtarium

-- MAIN APPLICATION
addappid(634060)
-- Game: addappid(634060)

-- MAIN APP DEPOTS / PACKAGES
addappid(634061, 1, "f922a6464c6e2df905964a8107b142019e701699817738f40dc8b3676559d84e")
