-- Lua provided by RyzenAPI
-- Game: 1069730

-- MAIN APPLICATION
addappid(1069730)
-- Game: addappid(1069730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069730,0,"0fd968d9ddd4fe18acad96f063da89cecf95d15e3388a69fee3e69ac50919227")
