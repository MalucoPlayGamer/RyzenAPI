-- Lua provided by RyzenAPI
-- Game: Game: Oh, Dungeon Master

-- MAIN APPLICATION
addappid(1708470)
-- Game: addappid(1708470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708471, 1, "0629fdf712719c13a89f3dc59e94f80c43a74f5078bfbf38830090922f7e9f36")
