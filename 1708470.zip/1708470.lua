-- Lua provided by RyzenAPI 
-- Game: Oh, Dungeon Master
addappid(1708470)
addappid(1708471, 1, "0629fdf712719c13a89f3dc59e94f80c43a74f5078bfbf38830090922f7e9f36")
