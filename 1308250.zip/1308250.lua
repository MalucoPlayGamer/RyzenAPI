-- Lua provided by RyzenAPI
-- Game: addappid(1308250)

-- MAIN APPLICATION
addappid(1308250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308251, 1, "2ee052bf6552d5a65e3e05f57e34b59c90311a341ad837cdc1fdef0c5f739119")
