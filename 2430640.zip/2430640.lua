-- Lua provided by RyzenAPI
-- Game: 2430640

-- MAIN APPLICATION
addappid(2430640)
-- Game: addappid(2430640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430641, 1, "5a46fe640e53dee2cfa9f46c198fe59630c47c2dba1f9b27a9a791a743aeeb6f")
