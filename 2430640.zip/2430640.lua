-- Lua provided by RyzenAPI
-- Game: Sensual Adventures - Episode 9

-- MAIN APPLICATION
addappid(2430640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2430641, 1, "5a46fe640e53dee2cfa9f46c198fe59630c47c2dba1f9b27a9a791a743aeeb6f")

