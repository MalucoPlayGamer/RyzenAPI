-- Lua provided by RyzenAPI
-- Game: Cheat Death

-- MAIN APPLICATION
addappid(3756340)
addappid(4913120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3756341,0,"d7cb2d38efbcb37d75bd97581dabdce696c579a4a463b2066acfd74266fd29d1")

