-- Lua provided by RyzenAPI
-- Game: Anomaly Zone

-- MAIN APPLICATION
addappid(1157250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157251, 1, "6b31cae9fddf57e22945cb5dd9162c7d3535c70f57a916b017e0cb59ac0a2ba2")
