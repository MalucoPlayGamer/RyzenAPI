-- Lua provided by RyzenAPI
-- Game: Anomaly Zone

-- MAIN APPLICATION
addappid(1187760) -- Anomaly Zone - Starter Kit
addappid(1187820) -- Anomaly Zone - Hockey Mask
addappid(1187821) -- Anomaly Zone - Pumpkin Helmet
addappid(1205110) -- Anomaly Zone - Cat Mask
addappid(1205111) -- Anomaly Zone - Bear Mask
addappid(1205112) -- Anomaly Zone - Rabbit Mask
addappid(1205113) -- Anomaly Zone - Evil Rabbit
addappid(1205114) -- Anomaly Zone - Imperial Hat
addappid(1205115) -- Anomaly Zone - Cheburashka Mask

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1157250, 1, "8880d7b4c316da92ca39696d374e9f51d2a58cbe3618aa8c9968fea69f5b2cc1") -- Anomaly Zone
addappid(1157251, 1, "6b31cae9fddf57e22945cb5dd9162c7d3535c70f57a916b017e0cb59ac0a2ba2") -- AnomalyZone Content

