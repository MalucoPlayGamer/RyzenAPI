-- Lua provided by RyzenAPI
-- Game: addappid(857980)

-- MAIN APPLICATION
addappid(857980)

-- MAIN APP DEPOTS / PACKAGES
addappid(857981, 1, "e96a100d13c2991dfae9e5b858877d11d2944ddc1fccb723d5ab116984a3e682")
addappid(857982, 1, "51d92df6a043bf0fa9dc6fd9cee8321161f9e1a1c41c3589a18bf6d67e2e14e1")
