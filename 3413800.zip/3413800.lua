-- Lua provided by RyzenAPI
-- Game: Hotel Tales

-- MAIN APPLICATION
addappid(3413800)
addappid(3669340)
addappid(4082150)
addappid(4082160)
addappid(4082170)
addappid(4082180) -- Hotel Tales - Skins Pack
addappid(4655580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413801, 1, "40b64b20f4fe3a698d29fc24d855b03e15d28f15d7826e77207413b7332af0ad")
addappid(3669341, 1, "c217be7c325787cab056de6ebad207adc6d4e4e1c00abb7b4c7080861d7bb273")
addappid(4082151, 1, "b83b532d76606ad857393cd76851cec8fa1ee26fd8afd1c094a30ac9d490bb78")
addappid(4082161, 1, "835944d43af1ca8b4f968ba8abf6d6ef2c837c4c70d78504ec93bb1476d52378")
addappid(4082171, 1, "227064216432ce8a031b1dd27c25b6289633049b79188524c69199601d10da14")
addappid(4655581, 1, "c47b2adb33fe771946f8a173cfd844b61da19420e147c98ea4d48820cfdf0e02")

