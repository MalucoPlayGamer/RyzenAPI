-- Lua provided by RyzenAPI
-- Game: Hotel Tales

-- MAIN APPLICATION
addappid(3413800) -- Hotel Tales
addappid(4082180) -- Hotel Tales - Skins Pack
-- addappid(3669340)
-- addappid(4082150)
-- addappid(4082160)
-- addappid(4082170)
-- addappid(4655580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413801, 1, "40b64b20f4fe3a698d29fc24d855b03e15d28f15d7826e77207413b7332af0ad") -- Depot 3413801

