-- 3413800's Lua and Manifest Created by Hubcap Manifest
-- Hotel Tales
-- Created: July 31, 2026 at 20:36:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1 (5 excluded)

-- MAIN APPLICATION
addappid(3413800) -- Hotel Tales
-- MAIN APP DEPOTS
addappid(3413801, 1, "40b64b20f4fe3a698d29fc24d855b03e15d28f15d7826e77207413b7332af0ad") -- Depot 3413801
setManifestid(3413801, "3120635834852201330", 7043189757)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4082180) -- Hotel Tales - Skins Pack
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Hotel Tales Comics Vol.1 - The Curse of the Crown (AppID: 3669340) - missing depot keys
-- addappid(3669340)
-- Hotel Tales - Artbook (AppID: 4082150) - missing depot keys
-- addappid(4082150)
-- Hotel Tales - Animations Pack (AppID: 4082160) - missing depot keys
-- addappid(4082160)
-- Hotel Tales - Wallpapers Pack (AppID: 4082170) - missing depot keys
-- addappid(4082170)
-- Hotel Tales Comics Vol.2 - The Bite That Broke Love (AppID: 4655580) - missing depot keys
-- addappid(4655580)