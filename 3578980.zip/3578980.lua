-- Lua provided by RyzenAPI
-- Game: Lovecraft Locker 2: Tentacle Breach

-- MAIN APPLICATION
addappid(3578980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3578981,0,"a4771d25c3b69f05342ae9b301b43c4a137ac1d4cde026a7896b46f40abaf074")

