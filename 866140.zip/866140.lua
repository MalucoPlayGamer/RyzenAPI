-- Lua provided by RyzenAPI
-- Game: 866140

-- MAIN APPLICATION
addappid(866140)
-- Game: addappid(866140)

-- MAIN APP DEPOTS / PACKAGES
addappid(866141, 1, "bc1d9fc90b9f1fe4f26c77680eef7130cb4c7d5a5a8b238d5273e20ba3186ad7")
