-- Lua provided by RyzenAPI
-- Game: Arise: A Simple Story

-- MAIN APPLICATION
addappid(866140)
addappid(1946100)
addappid(1946101)
addappid(2018010)

-- MAIN APP DEPOTS / PACKAGES
addappid(866141,0,"bc1d9fc90b9f1fe4f26c77680eef7130cb4c7d5a5a8b238d5273e20ba3186ad7")
addappid(1946100,0,"fc8b3e21b64bb84db9c48d172939ec2df2cc8b3e91c3a92023ae076273ae72df")
addappid(1946101,0,"930142d1adf8a773b83ea16f5c99f7c92f207503592f395606bc205f55d52794")
addappid(2018010,0,"2a1dcbf950c009333b045eb125c4d0263490b4457a1ac37e2c63916117254d97")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
