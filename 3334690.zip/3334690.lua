-- Lua provided by RyzenAPI
-- Game: OneRoom ―Yui Hanasaka Memorial―

-- MAIN APPLICATION
addappid(3334690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3334691, 1, "b3c648607c7299f5b97d658518ae8627efb5a8ee53ec18509620e8bc8c6b6acc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
