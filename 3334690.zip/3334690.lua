-- Lua provided by RyzenAPI
-- Game: 3334690

-- MAIN APPLICATION
addappid(3334690)
-- Game: addappid(3334690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3334691, 1, "b3c648607c7299f5b97d658518ae8627efb5a8ee53ec18509620e8bc8c6b6acc")
