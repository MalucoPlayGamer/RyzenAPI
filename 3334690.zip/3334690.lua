-- Lua provided by SkyAPI 
-- Game: OneRoom ―Yui Hanasaka Memorial―
addappid(3334690)
addappid(3334691, 1, "b3c648607c7299f5b97d658518ae8627efb5a8ee53ec18509620e8bc8c6b6acc")
