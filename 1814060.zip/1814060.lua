-- Lua provided by RyzenAPI 
-- Game: Virus at Home
addappid(1814060)
addappid(1814061, 1, "3d343f388a18b8b6000bf05cd963301c8a7d6ce229cd0502f7aad4d50108f4c9")
