-- Lua provided by RyzenAPI
-- Game: Hanctt Origins

-- MAIN APPLICATION
addappid(2438290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438291, 1, "dd252931e85dda8b7917e4845c46805e8377f51b48c5f49e4bb51cf5b3132077")
