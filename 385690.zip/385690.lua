-- Lua provided by RyzenAPI
-- Game: Wave Mechanics

-- MAIN APPLICATION
addappid(385690)

-- MAIN APP DEPOTS / PACKAGES
addappid(385691, 1, "d55975c109e868065db54d9c6c474fcd93a61b9b2d9483ab89ee022773f1eb50")
