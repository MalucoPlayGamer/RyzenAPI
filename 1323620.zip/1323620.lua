-- Lua provided by RyzenAPI
-- Game: 1323620

-- MAIN APPLICATION
addappid(1323620)
-- Game: addappid(1323620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323621, 1, "f435ef0213064134bbe91edf66697e93c5f7ee461244282cb0512588ef56cb0d")
