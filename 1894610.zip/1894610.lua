-- Lua provided by RyzenAPI
-- Game: Monster Demo

-- MAIN APPLICATION
addappid(1894610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894611, 1, "ab0af49923e923b4d0825cb915ae21c7510d626bec2035a8c377542acab12243")
