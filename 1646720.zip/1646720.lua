-- Lua provided by RyzenAPI
-- Game: addappid(1646720)

-- MAIN APPLICATION
addappid(1646720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646721, 1, "1bf44613e8c13d5ee0502dc5df83f31953a28cc2a10a835dad9180d1b634c4d8")
