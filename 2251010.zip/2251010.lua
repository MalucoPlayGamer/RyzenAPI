-- Lua provided by RyzenAPI 
-- Game: The Witch's Cauldron
addappid(2251010)
addappid(2251011, 1, "ce1d3af6141c4496a6445719a4772168329fdf44e9aa9e59557b70bd49a79260")
