-- Lua provided by RyzenAPI
-- Game: The Witch's Cauldron

-- MAIN APPLICATION
addappid(2251010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251011, 1, "ce1d3af6141c4496a6445719a4772168329fdf44e9aa9e59557b70bd49a79260")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2955860)
