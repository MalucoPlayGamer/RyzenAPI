-- Lua provided by RyzenAPI
-- Game: AppID 813290

-- MAIN APPLICATION
addappid(813290)

-- MAIN APP DEPOTS / PACKAGES
addappid(813291, 1, "4824eb1ab003afdcbfb37f8224a447c62bad58e3057baa1b7ea2c89e24710a09")

