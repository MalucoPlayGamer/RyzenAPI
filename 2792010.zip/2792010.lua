-- Lua provided by RyzenAPI 
-- Game: Backrooms:Rebirth Demo
addappid(2792010)
addappid(2792011, 1, "a695e5cd310bd560a526868a4516b9df97ca173afa275454eec6c43951577387")
