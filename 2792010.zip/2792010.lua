-- Lua provided by RyzenAPI
-- Game: Backrooms:Rebirth Demo

-- MAIN APPLICATION
addappid(2792010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2792011, 1, "a695e5cd310bd560a526868a4516b9df97ca173afa275454eec6c43951577387")

