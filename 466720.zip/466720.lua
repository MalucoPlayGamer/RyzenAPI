-- Lua provided by RyzenAPI
-- Game: Vintage VR

-- MAIN APPLICATION
addappid(466720)

-- MAIN APP DEPOTS / PACKAGES
addappid(466721, 1, "aead7d82340ccac7d39348b3f203f270ca514acf6b7ea6cae2e6c9eac2bd77f0")

