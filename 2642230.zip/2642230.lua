-- Lua provided by RyzenAPI
-- Game: addappid(2642230)

-- MAIN APPLICATION
addappid(2642230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642231, 1, "5cd36e8fe82776e99deae03297e1deb444eb220bc9ed4f51ba2db1e57c967508")
