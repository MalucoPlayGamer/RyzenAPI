-- Lua provided by SkyAPI 
-- Game: Aim in Space
addappid(2642230)
addappid(2642231, 1, "5cd36e8fe82776e99deae03297e1deb444eb220bc9ed4f51ba2db1e57c967508")
