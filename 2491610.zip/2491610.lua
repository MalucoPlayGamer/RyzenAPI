-- Lua provided by RyzenAPI
-- Game: AppID 2491610

-- MAIN APPLICATION
addappid(2491610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491611, 1, "b9f8751ce03cc40b161abd934dd00bee1253972a9d1cd48ffb61c1ad371e5d9a")

