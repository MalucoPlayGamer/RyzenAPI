-- Lua provided by RyzenAPI
-- Game: 1686520

-- MAIN APPLICATION
addappid(1686520)
-- Game: addappid(1686520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686521, 1, "9ff850f21a18a06ccc9111f4ff7948776d5b2ad2058a700f699d1d9f16d93ed7")
