-- Lua provided by RyzenAPI
-- Game: Ninja Ordinance

-- MAIN APPLICATION
addappid(3070620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070623,0,"bca1f4e668d691881f7f2da78a467f77b6596cb28c5ea3ed28d98a70459464a0")

