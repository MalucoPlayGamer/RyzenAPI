-- Lua provided by RyzenAPI
-- Game: Vroomist

-- MAIN APPLICATION
addappid(464690)

-- MAIN APP DEPOTS / PACKAGES
addappid(464691, 1, "3f128a99576636c8b8fbf743275834a4d8d9acdc9cb3ba3929c918b3ce384071")
