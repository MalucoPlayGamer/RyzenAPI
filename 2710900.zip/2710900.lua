-- Lua provided by RyzenAPI
-- Game: 2710900

-- MAIN APPLICATION
addappid(2710900)
-- Game: addappid(2710900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710901, 1, "4587a829e26604b66b5131bb3b95b94dc6fdc022c11bf45bd030952ad3da83ba")
