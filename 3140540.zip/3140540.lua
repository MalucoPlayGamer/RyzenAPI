-- Lua provided by RyzenAPI
-- Game: addappid(3140540)

-- MAIN APPLICATION
addappid(3140540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140541, 1, "3de2fd17275fc6e06423161d292093d6d0fcbbf18d65a274f176877e965ea0f6")
