-- Lua provided by RyzenAPI
-- Game: Dead by Death

-- MAIN APPLICATION
addappid(663290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(663291, 1, "aa32185e2887238ae9327102fce881fb08039601375eb66acd937c24edf64204")

