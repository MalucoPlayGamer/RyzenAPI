-- Lua provided by RyzenAPI
-- Game: Dead by Death

-- MAIN APPLICATION
addappid(663290)
-- Game: addappid(663290)

-- MAIN APP DEPOTS / PACKAGES
addappid(663291, 1, "aa32185e2887238ae9327102fce881fb08039601375eb66acd937c24edf64204")
