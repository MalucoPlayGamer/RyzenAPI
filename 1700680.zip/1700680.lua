-- Lua provided by RyzenAPI
-- Game: Game: Ki11er Clutter

-- MAIN APPLICATION
addappid(1700680)
-- Game: addappid(1700680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700681, 1, "0f7dc3c8cb2bb5bea55e087b29b48a04c8e1d7f1196cbf6de0b53008a1a2a1c5")
