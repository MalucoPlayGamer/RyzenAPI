-- Lua provided by RyzenAPI
-- Game: Game: Casual Sport Series: Badminton

-- MAIN APPLICATION
addappid(3694260)
-- Game: addappid(3694260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3694261, 1, "af9c21f52d79fa72fa50a47bcde4eff6b34c931582394bc15e2d2f46b4da6e39")
