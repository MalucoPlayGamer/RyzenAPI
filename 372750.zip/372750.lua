-- Lua provided by RyzenAPI
-- Game: Girl Amazon Survival

-- MAIN APPLICATION
addappid(372750)

-- MAIN APP DEPOTS / PACKAGES
addappid(372751, 1, "ff3cd45decca71fa9289898b0b7b26e87f5a0ea94cf96c3a20ad3bc6479ec7b5")
addappid(372752, 1, "d096fe5f0a3c1cb3da9043062393ddf85eabceb987a3c992c70f0bbc73b75947")
addappid(372753, 1, "eec4a29bac38fb245a491bdd43739b597082e25da06206925ac62817773d65fe")
addappid(372754, 1, "7c7196f207db9d653ce6477137d7c215b626aa8da121cfd8023639a5df5894c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
