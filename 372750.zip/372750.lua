-- Lua provided by SkyAPI 
-- Game: Girl Amazon Survival
addappid(372750)
addappid(372751, 1, "ff3cd45decca71fa9289898b0b7b26e87f5a0ea94cf96c3a20ad3bc6479ec7b5")
addappid(372752, 1, "d096fe5f0a3c1cb3da9043062393ddf85eabceb987a3c992c70f0bbc73b75947")
addappid(372753, 1, "eec4a29bac38fb245a491bdd43739b597082e25da06206925ac62817773d65fe")
addappid(372754, 1, "7c7196f207db9d653ce6477137d7c215b626aa8da121cfd8023639a5df5894c1")
