-- Lua provided by RyzenAPI
-- Game: Game: The Companion

-- MAIN APPLICATION
addappid(1392780)
-- Game: addappid(1392780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392781, 1, "3e1accd426b37ac3689ab0bbb1ef1bb18a3cef7c2d0e421a2f91ffaa67431c06")
