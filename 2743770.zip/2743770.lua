-- Lua provided by RyzenAPI
-- Game: AppID 2743770

-- MAIN APPLICATION
addappid(2743770)
-- Game: addappid(2743770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743771, 1, "3e74530f546d7b307ee655e9eed70414bf3b4f3d880aba555e6d12ecd8c14f77")
