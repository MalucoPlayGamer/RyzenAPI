-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1455350)
-- Game: addappid(1455350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455353,0,"7513c8647596f930cecf55887012b722ee8281d2c506a5f43c96c15b37bbabc3")
addappid(1455354,0,"b9b7706378e9e4b6f23f0d583e9cd9a094bc1e15b777d3550dd4b85799731af6")
