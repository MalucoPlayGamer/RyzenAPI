-- Lua provided by RyzenAPI
-- Game: BoneCraft

-- MAIN APPLICATION
addappid(1001220)
-- Game: addappid(1001220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001221, 1, "7f04ce8d716f6219008629333203e7481648c37e2df054e40f4c7decc5a3b05a")
addappid(1105830, 0, "5ac0552f3e7e1eff2fb66f390363cdf1652367f3f090ee834949729c4f36fc33")
