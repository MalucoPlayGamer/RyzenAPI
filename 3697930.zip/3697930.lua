-- Lua provided by RyzenAPI
-- Game: Drop Duchy Soundtrack

-- MAIN APPLICATION
addappid(3697930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3697931, 1, "ef6adc6c15954952f95c82b18e748254851fca78523e8345541f45050442add4")

