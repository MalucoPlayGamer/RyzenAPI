-- Lua provided by RyzenAPI
-- Game: Super Walrus Entertainment System

-- MAIN APPLICATION
addappid(1409190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409191, 1, "d84e55e913d5855e400b8b50cef658ce848e233ac16db16a403cd1927ecc7784")
addappid(1409192, 1, "a8b68673401ecfc174a9e52033518954623a68039de434d5b95cafb5ac9ef77a")

