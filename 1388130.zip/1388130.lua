-- Lua provided by RyzenAPI
-- Game: Religion inc.

-- MAIN APPLICATION
addappid(1388130)
-- Game: addappid(1388130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388131, 1, "d0e7543ab525733d67d6eaf02b2bc4a74186dd8345496ac5fe03ec4f4ef90de1")
addappid(1388132, 1, "c936ece6c08d1f8b09206099f365b9a8b96c52f868dd344e3541d544244fb084")
