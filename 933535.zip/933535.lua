-- Lua provided by RyzenAPI
-- Game: addappid(933535)

-- MAIN APPLICATION
addappid(933535)

-- MAIN APP DEPOTS / PACKAGES
addappid(933535,0,"c0ce527e0ca8ee04a68295bef579e9f02c7af70118399a4f3f4f4a16559a864b")
