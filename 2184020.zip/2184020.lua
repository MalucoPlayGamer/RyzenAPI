-- 2184020's Lua and Manifest Created by Hubcap Manifest
-- LIFTED
-- Created: July 22, 2026 at 14:43:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2184020, 1, "adfb5b42aad29b6c3bce7425fc021d29994106741184b2cb7cfc4257b99d28a2") -- LIFTED
-- MAIN APP DEPOTS
addappid(2184021, 1, "64b092929af7a0d9ea38ae6b78a965b7bd32c16d2d3535943191b1fc6534cd68") -- Depot 2184021
setManifestid(2184021, "8267311636936100226", 7530717451)
addappid(2184022, 1, "ec98496f1096c2828f06c0a1310286864adad00095adb75a38a0acd63c999b19") -- Depot 2184022
setManifestid(2184022, "5051138686440301972", 6634426127)
addappid(2184023, 1, "dba47cf6a8b37c2738d92ede20bc80228ee696d40f058c27f87ccac1057bc39f") -- Depot 2184023
setManifestid(2184023, "9100429008990883520", 6667516270)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)