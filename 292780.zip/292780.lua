-- Lua provided by RyzenAPI 
-- Game: Pajama Sam 2: Thunder And Lightning Aren't So Frightening
addappid(292780)
addappid(292781, 1, "11ce795f353d01258a7a9b193af3a3cd5397c674e95ef54f8a1c9c33fa7ae713")
addappid(292784, 1, "aeb4c242a35033a50bc975ed8c53abd0bf25215829128e45b2eb822423441c42")
addappid(292785, 1, "bc5d36c38591488e625824236177e3622e984f588d483dd2ccb138e559487ad3")
