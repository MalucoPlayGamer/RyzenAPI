-- Lua provided by RyzenAPI
-- Game: New York Mysteries: Secrets of the Mafia Collector's Edition

-- MAIN APPLICATION
addappid(372930)
addappid(389060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(372931, 1, "d2236afae00f55c7dae21adbbaa841a22fd46f86ff6c188ac20954b89096be97")
addappid(372933, 1, "7762e51ff0c6373c44bd6551ac65239c1bfc0083b6a6e13269504e48ef2cfbac")

