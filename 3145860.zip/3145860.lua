-- Lua provided by RyzenAPI
-- Game: Devils Adventure

-- MAIN APPLICATION
addappid(3145860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3145861, 1, "68938e4097613bb411fb4c6f179b7df1421cbea62d7967e0fc3084cdfc3f3fc2")

