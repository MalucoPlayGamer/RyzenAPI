-- Lua provided by RyzenAPI
-- Game: AppID 282590

-- MAIN APPLICATION
addappid(282590)

-- MAIN APP DEPOTS / PACKAGES
addappid(282591, 1, "08ffd3ffd504eef0667cf03f87ce3c0f794f0dbddf60234177b2cfd70e64c3e9")

