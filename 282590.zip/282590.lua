-- Lua provided by RyzenAPI
-- Game: Star Ruler 2

-- MAIN APPLICATION
addappid(282590)
addappid(460420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(282591, 1, "08ffd3ffd504eef0667cf03f87ce3c0f794f0dbddf60234177b2cfd70e64c3e9")
