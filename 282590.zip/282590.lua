-- Lua provided by RyzenAPI
-- Game: AppID 282590

-- MAIN APPLICATION
addappid(282590)

-- MAIN APP DEPOTS / PACKAGES
addappid(282591, 1, "08ffd3ffd504eef0667cf03f87ce3c0f794f0dbddf60234177b2cfd70e64c3e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(460420)
