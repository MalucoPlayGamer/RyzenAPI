-- Lua provided by RyzenAPI
-- Game: 2137650

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2137650)
addappid(2137651)
addappid(2137653)
addappid(2137654)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137652,0,"82441b8f05bb7be981d214d840affb6100ba21680ee7819503584c5d2d9be052")

