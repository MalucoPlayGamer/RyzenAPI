-- Lua provided by RyzenAPI
-- Game: Rubber Bandits: Summer Prologue

-- MAIN APPLICATION
addappid(1620690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620691, 1, "8254f65c7115b61c9d636975065ba01fe029610e78883a1939884f75d116e71c")
