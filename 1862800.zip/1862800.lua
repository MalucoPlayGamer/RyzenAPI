-- Lua provided by RyzenAPI
-- Game: 1862800

-- MAIN APPLICATION
addappid(1862800)
-- Game: addappid(1862800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862800,0,"49470eb076f0a8420fcd2f36a84b58f584e6df356aafb44c28b19187af15a535")
