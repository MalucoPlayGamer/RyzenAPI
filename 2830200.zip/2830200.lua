-- Lua provided by RyzenAPI
-- Game: Game: Bullet: Surge

-- MAIN APPLICATION
addappid(2830200)
addappid(3520700)
-- Game: addappid(2830200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830201, 1, "8c883141b98c779217d3c7627bd646cd215ecb8071656313c48518fbe63d1e7c")
