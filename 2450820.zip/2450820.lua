-- Lua provided by RyzenAPI
-- Game: 2450820

-- MAIN APPLICATION
addappid(228990)
addappid(2450820)
addappid(2450829)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450822,0,"ff990475f9e16f740352cfbab448d5b2aa7ded98c1e060fdd98ce9243b0ea1d2")

