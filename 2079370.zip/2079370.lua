-- Lua provided by RyzenAPI
-- Game: Bicycle Challenge - Wastelands

-- MAIN APPLICATION
addappid(2079370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079371, 1, "fc94b418f3e7e2fedf38170b01c96a9994a92a635b77b9eece038a310f15a3ca")

