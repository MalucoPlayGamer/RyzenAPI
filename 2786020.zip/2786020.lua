-- Lua provided by RyzenAPI
-- Game: Vindefiant

-- MAIN APPLICATION
addappid(2786020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786022,0,"0d64c629a254e361dce59d332cd17febe024ae8c7d61e50244e57174888a0b5f")
