-- Lua provided by SkyAPI 
-- Game: AppID 223000
addappid(223000)
addappid(223001, 1, "77a4abad51cdd2c88d9685aea1d2b739d83f48713d8768400211cec5b821a966")
addappid(223002, 1, "4b2439a42cad95cf95c3fff5feeca2060cff32a323d746fab44e2b3b94fa976c")
