-- Lua provided by RyzenAPI
-- Game: Rescue Rina

-- MAIN APPLICATION
addappid(1400350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400351, 1, "b7c772ac0f1416a1ec6f8c4630e9ebccf39658b8537452cdcb389b573749f6eb")
