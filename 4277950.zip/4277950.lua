-- Lua provided by RyzenAPI
-- Game: Hentai Furry Cat

-- MAIN APPLICATION
addappid(4277950)

-- MAIN APP DEPOTS / PACKAGES
addappid(4277951,0,"2a97a741e9dedf9f0c9e6f29289a937108c08c8e67f4ff144f62f10e6098d4b8")

