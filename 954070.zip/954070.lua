-- Lua provided by RyzenAPI
-- Game: Game: Beat Boxers

-- MAIN APPLICATION
addappid(954070)
-- Game: addappid(954070)

-- MAIN APP DEPOTS / PACKAGES
addappid(954071, 1, "5d95dbef6f2d78dcf684c1452a66bc62f848d96adde80c621f4b029596eedba8")
