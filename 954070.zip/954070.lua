-- Lua provided by RyzenAPI 
-- Game: Beat Boxers
addappid(954070)
addappid(954071, 1, "5d95dbef6f2d78dcf684c1452a66bc62f848d96adde80c621f4b029596eedba8")
