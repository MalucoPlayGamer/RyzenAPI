-- Lua provided by RyzenAPI
-- Game: Splat Arena

-- MAIN APPLICATION
addappid(2684200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684201, 1, "defd8af973fae66e4c6ac2c8c5efca8ac67436eef184a54dfe81a37e2ea78696")

