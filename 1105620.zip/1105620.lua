-- Lua provided by RyzenAPI
-- Game: AppID 1105620

-- MAIN APPLICATION
addappid(1105620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105621, 1, "a34a1b16baf577222400635c84cdc6332c96a1475fbecdaf8c31a5c9efac9fb6")
addappid(1105622, 1, "88990a52f6f8841cdae228e625842537433e5fed6b7d7c5b7dbe9ace6a31d0ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
