-- Lua provided by RyzenAPI 
-- Game: AppID 1105620
addappid(1105620)
addappid(1105621, 1, "a34a1b16baf577222400635c84cdc6332c96a1475fbecdaf8c31a5c9efac9fb6")
addappid(1105622, 1, "88990a52f6f8841cdae228e625842537433e5fed6b7d7c5b7dbe9ace6a31d0ed")
