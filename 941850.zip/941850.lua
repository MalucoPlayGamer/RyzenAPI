-- Lua provided by RyzenAPI
-- Game: addappid(941850)

-- MAIN APPLICATION
addappid(941850)

-- MAIN APP DEPOTS / PACKAGES
addappid(941852,0,"af744a45bf7a5ecdd711bb8598ac0fbbfaf02980b864f21dcb02bce077a5cb9d")
