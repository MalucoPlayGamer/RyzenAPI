-- Lua provided by RyzenAPI
-- Game: Vanguard: Normandy 1944

-- MAIN APPLICATION
addappid(941850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(941852,0,"af744a45bf7a5ecdd711bb8598ac0fbbfaf02980b864f21dcb02bce077a5cb9d")

