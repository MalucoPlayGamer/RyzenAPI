-- Lua provided by RyzenAPI
-- Game: Movavi Video Suite 18

-- MAIN APPLICATION
addappid(973600)

-- MAIN APP DEPOTS / PACKAGES
addappid(973601, 1, "5d8908ddaafda2bd13b89efa3ea35edd9c36050b2579610aac863396c37c273f")

