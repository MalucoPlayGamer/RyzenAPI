-- Lua provided by RyzenAPI
-- Game: Implements of Hell

-- MAIN APPLICATION
addappid(1805040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805041, 1, "7831d65500f0119bb4d6fcab3c2109c5a55acec618584845b3689312539c7437")
