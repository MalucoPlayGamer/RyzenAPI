-- Lua provided by RyzenAPI
-- Game: Implements of Hell

-- MAIN APPLICATION
addappid(1805040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1805041, 1, "7831d65500f0119bb4d6fcab3c2109c5a55acec618584845b3689312539c7437")

