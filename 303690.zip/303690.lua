-- Lua provided by RyzenAPI
-- Game: FATE: The Cursed King

-- MAIN APPLICATION
addappid(303690)
-- Game: addappid(303690)

-- MAIN APP DEPOTS / PACKAGES
addappid(303691, 1, "6bda836a4049a4512f2a905e3adecfd871b2fa4cf8a80686233bc37e6d92f055")
