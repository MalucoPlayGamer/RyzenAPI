-- Lua provided by RyzenAPI
-- Game: DIY MY LADY IN VR WORLD

-- MAIN APPLICATION
addappid(1506450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506451, 1, "f6669858b2a0445c79403b4ea68b99c78b2b03c896cd8a3da38a496a1bb49195")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1696120)
addappid(1719910)
addappid(1820010)
