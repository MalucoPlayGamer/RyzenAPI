-- Lua provided by RyzenAPI
-- Game: addappid(1506450)

-- MAIN APPLICATION
addappid(1506450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506451, 1, "f6669858b2a0445c79403b4ea68b99c78b2b03c896cd8a3da38a496a1bb49195")
