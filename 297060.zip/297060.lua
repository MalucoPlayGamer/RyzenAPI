-- Lua provided by RyzenAPI
-- Game: 297060

-- MAIN APPLICATION
addappid(297060)
-- Game: addappid(297060)

-- MAIN APP DEPOTS / PACKAGES
addappid(297061, 1, "98a1f77fee1d06ac8efa986a52639964b3eaa6789e662918dd0dc2adcb183cb4")
addappid(297062, 1, "45f449ee57853f87a2c576be871df4eef6c6323e49995d8d3f272177e33a405e")
addappid(297063, 1, "bbe133d411c8cd9a662dc01ef8df2afebbe0300e3d0d327b9f531950b935ea2d")
addappid(297064, 1, "4805f6ea41fe02487fdc5d4ad77508ffc1141480191ee8f4b0f774b5ec5bd491")
