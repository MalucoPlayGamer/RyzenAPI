-- Lua provided by RyzenAPI
-- Game: Game: Potion Brew: Co-op

-- MAIN APPLICATION
addappid(2226750)
addappid(2381110)
-- Game: addappid(2226750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226751, 1, "47b43aa23ec2137506fc89da4669620a1c8a438e683d7a80b826a73763a34164")
