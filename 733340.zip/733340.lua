-- Lua provided by RyzenAPI
-- Game: Hakuoki: Edo Blossoms

-- MAIN APPLICATION
addappid(733340)

-- MAIN APP DEPOTS / PACKAGES
addappid(733341, 1, "54f93f73cb39e150cafde44a12d4dcc256312430da3908f815ba01862c108f84")
addappid(733342, 1, "d137ccae29d9538c61282047b57eadd67c928b93758417c7bbf5690ea3bc546e")
addappid(733343, 1, "c1057de47ddf1583a2191cbe1d23632878daedbbd632be2734eb515d3a864412")
addappid(733344, 1, "815b87113b47840d206534722c8695f923cb1e55a84cdd18b94cc6dcadf39228")
addappid(733345, 1, "e87cbb198c1e455b71c099b3920c1533a7225bf207f31eadb56f876f3ca0d2a5")
addappid(733346, 1, "df3d78bd0dacd91a7746502526c0ae47addc1d3431c95dc11a9ff53b4db0a90d")
addappid(774521, 0, "ad7be924e1b8be317fd4eb8cf2fcedb702a274f35cc13f3db8839dc5075091fc")
addappid(785900, 0, "44bb3c2ca7003d73437b1229cd323625cd729f5ba8129f75eff7666643b81dd8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
