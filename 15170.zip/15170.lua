-- Lua provided by RyzenAPI
-- Game: Heroes of Might & Magic V

-- MAIN APPLICATION
addappid(15170)

-- MAIN APP DEPOTS / PACKAGES
addappid(15171, 1, "1a9f1e32152cbd8fe3bba033ea4e23961e5f7ad731190ffcaf82e2668912e33e")
addappid(15172, 1, "135a76c31c623bc24c25760d11804b9522f28958c658386697c9c438451bf8ba")
addappid(15173, 1, "f720d8720508cb14a143ede290a56fae46a3354c4e7effbfa589ad8c395dfa05")
addappid(15174, 1, "e4f33dc01a8f40d48324fe2c99b9eaaf27fc8842dff2c0cf11eb16acf7117f78")
addappid(15175, 1, "c6f52964fcc5edfbe4db4e68097a6877ea345e6411a630215ccdf378244b39b1")
addappid(15176, 1, "b39745c6a8b690a4adb4f003e46812c20a3c0f8784fce49a59e5bf188306719b")
addappid(15177, 1, "98eacaf9b366aa5b41fcdb44e96bba8ea6c1caf208101846e16017c67efba83b")
addappid(15178, 1, "c9d435ea5915c4b208db6caa2ff95011895f89e2d214dd2da0e8e1a942ac56cc")
addappid(15179, 1, "64006af48595f7fb6f56a28d81e4c46dd9893ff3528dc433f996efda1005eb30")
addappid(3833480, 0, "402380215030ff521a52301efbac797c4389ca269ee74873ed1232a118bdf551")
addappid(3833481, 0, "72edcdd8ee3897d3ca7913f85703c0de37baa2a38cf13df8826129f0946aa008")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
