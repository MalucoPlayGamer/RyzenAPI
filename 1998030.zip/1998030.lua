-- Lua provided by RyzenAPI
-- Game: 1998030

-- MAIN APPLICATION
addappid(1998030)
-- Game: addappid(1998030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998031, 1, "3373ae53c5f13f96218215c8bb58bc910de59af24fb23c86746cab14ab145ec8")
