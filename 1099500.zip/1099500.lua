-- Lua provided by RyzenAPI
-- Game: The Curious Tale of the Stolen Pets

-- MAIN APPLICATION
addappid(1099500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099501, 1, "b7d2e3e52d67b9b7197c149bfe997777ce26c068c15264d5f421d9b26c62464d")
