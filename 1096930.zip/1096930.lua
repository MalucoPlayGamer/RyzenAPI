-- Lua provided by RyzenAPI
-- Game: Strategic Command: World War I

-- MAIN APPLICATION
addappid(1096930)
addappid(2526110)
addappid(4543560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096931,0,"0477cd6cd7d8f5d1b2f608ec750ec62b47ba5152080bd9b3e0fc757560b743d9")
addappid(1096932,0,"69b2999b9cbe489fa2b0bfcbf512228a43cf44d0fb38b2435a2abfe69de9cb1d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
