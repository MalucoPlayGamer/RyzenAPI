-- Lua provided by RyzenAPI 
-- Game: Mr.Jezko
addappid(796640)
addappid(796641, 1, "5e55856fac44e5001b0d6c2408a820263ca7a3890ba1ef4e70da3d2fdac106a6")
addappid(796642, 1, "3d470f16be78825ef99da57092d280999e8d6a30002d12c8e0e8598ff45f24c2")
addappid(796643, 1, "c2632f8fee812141f78ecbfd8a18373af156b4d0e5d474105d92c103ce569d9b")
