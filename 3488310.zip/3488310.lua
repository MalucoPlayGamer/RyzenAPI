-- Lua provided by RyzenAPI
-- Game: AppID 3488310

-- MAIN APPLICATION
addappid(3488310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3488311, 1, "d7ed9b8f5a7205da63388f04992ada5a992107bcfbcfe6b3b550fac700c0e130")
