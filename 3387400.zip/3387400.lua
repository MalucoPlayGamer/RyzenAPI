-- Lua provided by RyzenAPI
-- Game: addappid(3387400)

-- MAIN APPLICATION
addappid(3387400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3387401, 1, "4c54e5456ab24b8a6b5a46c118203c2db3310ca72c1419c83ea515f38800d1c8")
