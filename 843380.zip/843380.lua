-- Lua provided by RyzenAPI
-- Game: Super Animal Royale

-- MAIN APPLICATION
addappid(843380)
addappid(997330)
addappid(1475530)
addappid(1475540)
addappid(1695290)
addappid(1784150)
addappid(1899030)
addappid(1984600)
addappid(2095020)
addappid(2173400)
addappid(2255940)
addappid(2374860)
addappid(2524160)
addappid(2640070)
addappid(3095340)
addappid(4115440)
addappid(4439730)
addappid(4610650)
addappid(4786190)
addappid(4938600)

-- MAIN APP DEPOTS / PACKAGES
addappid(843381,0,"a5dc19c640fcea6784742fc659400fef18e32e4e5557e6ff1af4f9a06d4db001")
addappid(843382,0,"249e8ffc343547924f5f047df26c24cb3ab0493370ebb0dc34beb7d92b584d19")

