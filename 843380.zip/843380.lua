-- Lua provided by RyzenAPI
-- Game: 843380

-- MAIN APPLICATION
addappid(843380)
-- Game: addappid(843380)

-- MAIN APP DEPOTS / PACKAGES
addappid(843381, 1, "a5dc19c640fcea6784742fc659400fef18e32e4e5557e6ff1af4f9a06d4db001")
addappid(843382, 1, "249e8ffc343547924f5f047df26c24cb3ab0493370ebb0dc34beb7d92b584d19")
