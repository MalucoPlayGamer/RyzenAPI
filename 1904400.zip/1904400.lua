-- Lua provided by RyzenAPI
-- Game: My Pet Rock

-- MAIN APPLICATION
addappid(1904400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1904401, 1, "111d6d9586d59e342523289c25e3cfd7a3dc3fb09d1ec9ecb75898f55877ff72")

