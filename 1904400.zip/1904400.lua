-- Lua provided by RyzenAPI
-- Game: My Pet Rock

-- MAIN APPLICATION
addappid(1904400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904401, 1, "111d6d9586d59e342523289c25e3cfd7a3dc3fb09d1ec9ecb75898f55877ff72")
