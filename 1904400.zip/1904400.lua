-- Lua provided by SkyAPI 
-- Game: My Pet Rock
addappid(1904400)
addappid(1904401, 1, "111d6d9586d59e342523289c25e3cfd7a3dc3fb09d1ec9ecb75898f55877ff72")
