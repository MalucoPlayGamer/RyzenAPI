-- Lua provided by RyzenAPI
-- Game: Angvik 2

-- MAIN APPLICATION
addappid(2921600)
-- Game: addappid(2921600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921601, 1, "7cab10dc60ea4a056c08439060f93ad9fe3e0221076925cad92ee897c34cb932")
