-- Lua provided by RyzenAPI
-- Game: Doki Doki House

-- MAIN APPLICATION
addappid(1895950)
-- Game: addappid(1895950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895951, 1, "3582f049cd6fff9f612c8a32516c954f2166b0e0ab32c27652212c0e24fe3566")
