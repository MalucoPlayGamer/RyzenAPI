-- Lua provided by RyzenAPI
-- Game: 207750

-- MAIN APPLICATION
addappid(207750)
-- Game: addappid(207750)

-- MAIN APP DEPOTS / PACKAGES
addappid(207751, 1, "002f2eb9a72e805b68f82a48e55e95f306f624f44584456ca08d9463ab924d83")
addappid(207752, 1, "7015f0d830dba53bb5fae8d93b9b3df9bae4abe4d6f350dcfd22d2b54aac0f44")
addappid(207753, 1, "4ff107b89b972d7319de7438bea35b85895bd017350d04f9ec30fc486cdcc72a")
