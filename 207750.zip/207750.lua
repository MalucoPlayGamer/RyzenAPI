-- Lua provided by RyzenAPI
-- Game: Symphony

-- MAIN APPLICATION
addappid(207750)

-- MAIN APP DEPOTS / PACKAGES
addappid(207751, 1, "002f2eb9a72e805b68f82a48e55e95f306f624f44584456ca08d9463ab924d83")
addappid(207752, 1, "7015f0d830dba53bb5fae8d93b9b3df9bae4abe4d6f350dcfd22d2b54aac0f44")
addappid(207753, 1, "4ff107b89b972d7319de7438bea35b85895bd017350d04f9ec30fc486cdcc72a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(207760)
addappid(261060)
