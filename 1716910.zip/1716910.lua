-- Lua provided by RyzenAPI
-- Game: Foot Massage

-- MAIN APPLICATION
addappid(1716910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716911, 1, "135e4425109f3e0fc1be546723a0db65b60e6abc65296fefd3a4925b73930698")

