-- Lua provided by RyzenAPI
-- Game: Taiwan Coolfox

-- MAIN APPLICATION
addappid(3615920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3615921, 1, "a4a2b3fa051cb0f4140a49bbda45fe2bf4f3ccb50c95617486267bd047eecac8")

