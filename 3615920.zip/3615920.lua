-- Lua provided by RyzenAPI
-- Game: Taiwan Coolfox

-- MAIN APPLICATION
addappid(3615920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3615921, 1, "a4a2b3fa051cb0f4140a49bbda45fe2bf4f3ccb50c95617486267bd047eecac8")

