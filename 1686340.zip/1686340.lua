-- Lua provided by SkyAPI 
-- Game: AirFighter
addappid(1686340)
addappid(1686341, 1, "d36154221a99862bb6d88705708fa69b64fa71a6edf08e2cf8aff76011148b07")
