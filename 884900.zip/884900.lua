-- Lua provided by SkyAPI 
-- Game: AppID 884900
addappid(884900)
addappid(884901, 1, "fe13483ece8cf50b623cec6b81595dee0ef6a66f01048397baadc3020ba03e80")
