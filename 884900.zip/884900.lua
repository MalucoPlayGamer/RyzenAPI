-- Lua provided by RyzenAPI
-- Game: Slider

-- MAIN APPLICATION
addappid(884900)

-- MAIN APP DEPOTS / PACKAGES
addappid(884901, 1, "fe13483ece8cf50b623cec6b81595dee0ef6a66f01048397baadc3020ba03e80")

