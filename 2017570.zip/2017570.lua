-- Lua provided by RyzenAPI
-- Game: Dungeon Munchies Original Soundtrack Vol.3

-- MAIN APPLICATION
addappid(2017570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017571, 1, "a9a5f3a606e70a9af611b41c4e8e06ead68946f13cbd9a7f05ac41dddd2c60c1")
