-- Lua provided by RyzenAPI
-- Game: Scarlet Hood and the Wicked Wood - Artbook

-- MAIN APPLICATION
addappid(1566750)
-- Game: addappid(1566750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566750,0,"eeb42a4e56aec709185e31445021c9f9bd523a5bfff5b54357d03016bc3e22c5")
