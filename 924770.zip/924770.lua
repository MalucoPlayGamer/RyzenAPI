-- Lua provided by RyzenAPI
-- Game: Colory Engine

-- MAIN APPLICATION
addappid(924770)
addappid(1452620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(924771, 1, "951c394947df6640389ee6dfc645d3a3861d1f12becb028088bb954f873efe96")

