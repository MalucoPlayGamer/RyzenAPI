-- Lua provided by RyzenAPI
-- Game: Game: Colory Engine

-- MAIN APPLICATION
addappid(924770)
addappid(1452620)
-- Game: addappid(924770)

-- MAIN APP DEPOTS / PACKAGES
addappid(924771, 1, "951c394947df6640389ee6dfc645d3a3861d1f12becb028088bb954f873efe96")
