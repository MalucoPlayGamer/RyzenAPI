-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Warfare

-- MAIN APPLICATION
addappid(355980)
-- Game: addappid(355980)

-- MAIN APP DEPOTS / PACKAGES
addappid(355981, 1, "6b953e5d867a0580dd7b9f3a11887b704cc88f05c778160f7ea146e2e394b3d8")
addappid(355982, 1, "524cb8d53cf996df04c0f87d2c9337110e7c85111cfd2a4d646c237f0cb86b91")
addappid(355983, 1, "3151e8ecd40729bbe2c014424f9ee02ceee0b42245db2f4823f9526c3257c7d5")
