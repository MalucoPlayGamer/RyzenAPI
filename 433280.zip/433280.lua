-- Lua provided by RyzenAPI
-- Game: Warlords Battlecry III

-- MAIN APPLICATION
addappid(433280)

-- MAIN APP DEPOTS / PACKAGES
addappid(433281, 1, "22c5f2039e5d1a0d240d3ac358a8db0357d6d1f984d2430768a0fe232e70e40a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
