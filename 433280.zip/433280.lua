-- Lua provided by RyzenAPI
-- Game: Warlords Battlecry III

-- MAIN APPLICATION
addappid(433280)
-- Game: addappid(433280)

-- MAIN APP DEPOTS / PACKAGES
addappid(433281, 1, "22c5f2039e5d1a0d240d3ac358a8db0357d6d1f984d2430768a0fe232e70e40a")
