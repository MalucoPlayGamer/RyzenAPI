-- Lua provided by RyzenAPI
-- Game: 9960

-- MAIN APPLICATION
addappid(9960)
-- Game: addappid(9960)

-- MAIN APP DEPOTS / PACKAGES
addappid(9961, 1, "dee9a4a4416e8124ec67825070ee48a342e8d261d0ebdcb9b43d87e4ed811ef1")
