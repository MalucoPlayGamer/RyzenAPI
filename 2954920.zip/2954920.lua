-- Lua provided by RyzenAPI
-- Game: Game: Zero-Sum Heart

-- MAIN APPLICATION
addappid(2954920)
-- Game: addappid(2954920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2954921, 1, "f928680559b6e588b7ea01b53108b11dbfc81baa4c1bcf0b4ef83c1ed09a2e2c")
