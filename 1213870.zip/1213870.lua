-- Lua provided by RyzenAPI
-- Game: Kill The Santa

-- MAIN APPLICATION
addappid(1213870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213871, 1, "b98a6aeb99cab4b4501ee3207a38c49310718e38a83476cbe4d2eabb99940a34")

