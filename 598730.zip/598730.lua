-- Lua provided by RyzenAPI
-- Game: Shakedown: Hawaii

-- MAIN APPLICATION
addappid(598730)

-- MAIN APP DEPOTS / PACKAGES
addappid(598731, 1, "59249e242a8015e3a657124c10f647281924270cb5d821f984d42a5aa719e0e6")
addappid(598732, 1, "acbb68570f831295527df34d2d5f77bbeadaf509ba0f9d3dbf90a4f0b4c427d8")
