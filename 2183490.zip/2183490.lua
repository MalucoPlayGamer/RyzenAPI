-- Lua provided by RyzenAPI
-- Game: AppID 2183490

-- MAIN APPLICATION
addappid(2183490)
-- Game: addappid(2183490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183491, 1, "ce33de01b0cb9b72850f8bbb0779609b543e75f9fc98f24e29064e170d649cd0")
