-- Lua provided by RyzenAPI
-- Game: Mech Mechanic Simulator: Prologue

-- MAIN APPLICATION
addappid(1485350)
-- Game: addappid(1485350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485351, 1, "eadc660391f07df0b1ef26383d80cf45079964b9effebcdfbe875199b7e7bf73")
