-- Lua provided by RyzenAPI
-- Game: Putt-Putt®: Pep's Birthday Surprise

-- MAIN APPLICATION
addappid(294700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(294701, 1, "6eed730bc4d6c39b8ccbd504d100a0f8f9bf747e05fc848a4c27f8e85b229557")
addappid(294702, 1, "65617be4fa51c475a12f452ccdd8ac54f53517f3719db2129d24d15298358d79")

