-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2195475)
-- Game: addappid(2195475)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195475,0,"bf0db8d125dbbee7489a66619644da9c780da052249876820280ecef52f99e13")
