-- Lua provided by SkyAPI 
-- Game: Spirit Realm
addappid(2799930)
addappid(2799931, 1, "96045378ae72057e53d00b38e6f124e34b6376bffbdbae9b3ce42ecb17804e30")
