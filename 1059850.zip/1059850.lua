-- Lua provided by SkyAPI 
-- Game: AppID 1059850
addappid(1059850)
addappid(1059851, 1, "6f4de37733f98c169d8fc4d19fe9cf67a50c6c0d25cec23a7e60c80e59b80fa3")
addappid(1059853, 1, "f11f2293931b58ba2d9b700c1c6204bc9b7cdcaa88482bcc5c099290bccde1aa")
