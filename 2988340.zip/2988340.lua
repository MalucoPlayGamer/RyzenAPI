-- Lua provided by RyzenAPI
-- Game: Journey of Harvest

-- MAIN APPLICATION
addappid(2988340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2988341, 1, "fc209a3364614d8e296a555dc2ff8930c51722b0c3e0b42aacbdab179f689fa5")
