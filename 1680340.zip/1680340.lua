-- Lua provided by RyzenAPI
-- Game: 1680340

-- MAIN APPLICATION
addappid(1680340)
-- Game: addappid(1680340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680341, 1, "bdd5460a38de7c27e5936ec97dff6c7f86a7c9d23e468e9579fde951c86914eb")
