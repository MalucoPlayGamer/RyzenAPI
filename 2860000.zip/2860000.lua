-- Lua provided by RyzenAPI
-- Game: Wild Assault PlayTest

-- MAIN APPLICATION
addappid(2860000)
-- Game: addappid(2860000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2860001, 1, "69fbacfd7eaaa47a550607b9ca90e727770b6b585ff18881905199b1bd716fb6")
addappid(2860004, 1, "b521f40783d66cabfe8fefabb3d69524cc5dc9ebf28399cccab69c90210d84a7")
addappid(2860007, 1, "0ea18e50377d9f08ba77597759e17a6c2ff7df8bff0740498f88b04c1b33cef7")
