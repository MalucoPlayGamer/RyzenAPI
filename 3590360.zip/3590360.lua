-- Lua provided by RyzenAPI
-- Game: Goodgame Empire

-- MAIN APPLICATION
addappid(3590360)
