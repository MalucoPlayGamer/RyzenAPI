-- Lua provided by RyzenAPI
-- Game: AppID 1181520

-- MAIN APPLICATION
addappid(1181520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1181521, 1, "4ea1835f607ff8570492ad8a42b9eb0aa339a7a43fc5993d9cf9cad207803927")
addappid(1181522, 1, "8f907e3a86bcfdad2db13b237a303729756331f0bdb6306c91a18deb8719d227")

