-- Lua provided by RyzenAPI
-- Game: Game: AppID 1181520

-- MAIN APPLICATION
addappid(1181520)
-- Game: addappid(1181520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181521, 1, "4ea1835f607ff8570492ad8a42b9eb0aa339a7a43fc5993d9cf9cad207803927")
addappid(1181522, 1, "8f907e3a86bcfdad2db13b237a303729756331f0bdb6306c91a18deb8719d227")
