-- Lua provided by SkyAPI 
-- Game: Obscure
addappid(254460)
addappid(254461, 1, "db88841d00b073d691c95ca056812436d47806878c9352103c037bdc405c1ed8")
addappid(283250, 0, "a6224b1e2b320b54dae7e9abb8708b82119836286ce5bff9dd55866886e633fa")
