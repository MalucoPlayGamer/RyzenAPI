-- Lua provided by RyzenAPI
-- Game: Obscure

-- MAIN APPLICATION
addappid(254460)

-- MAIN APP DEPOTS / PACKAGES
addappid(254461, 1, "db88841d00b073d691c95ca056812436d47806878c9352103c037bdc405c1ed8")
addappid(283250, 0, "a6224b1e2b320b54dae7e9abb8708b82119836286ce5bff9dd55866886e633fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
