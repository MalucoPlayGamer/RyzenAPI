-- Lua provided by RyzenAPI
-- Game: Three Heroes

-- MAIN APPLICATION
addappid(380020)

-- MAIN APP DEPOTS / PACKAGES
addappid(380021, 1, "e6aadaee2ce22bb1215866cea266fb9de657d099834ce818eab86e4155a25ede")
addappid(380022, 1, "a516c772d462709fd6fa8717404bf608e5f3dfbb1de09cf6cdbd1f3218610805")
addappid(380023, 1, "75d0f0f51d5d24c9d6cfabadd3ade2fb1f418448cae20599e6f6b00e652ace8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
