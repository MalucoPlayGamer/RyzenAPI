-- Lua provided by RyzenAPI
-- Game: FMTC

-- MAIN APPLICATION
addappid(2324110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324111, 1, "6d96db93bd5ff4dfded07572295e0588fccf3674e809b8e34d969aff0477ce99")
