-- Lua provided by RyzenAPI
-- Game: 3352300

-- MAIN APPLICATION
addappid(3352300)
-- Game: addappid(3352300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3352301, 1, "5539b807555522ecea112ebe764866422afdc65f76cd9fc71d8d7c6d104f8d47")
