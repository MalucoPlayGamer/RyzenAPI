-- Lua provided by RyzenAPI 
-- Game: After Dark
addappid(2296320)
addappid(2296321, 1, "5ea330815573339d4c5df72913f3c9efed4aa193d96f57b175178787ed7d84ae")
