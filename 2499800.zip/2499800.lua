-- Lua provided by RyzenAPI
-- Game: Garten of Banban 6

-- MAIN APPLICATION
addappid(2499800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499801, 1, "5ec671a05605967a09c2080a51481d78eaa419c60e09ac9c90ca4a98864cd79d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
