-- Lua provided by RyzenAPI
-- Game: Garten of Banban 6

-- MAIN APPLICATION
addappid(2499800)
-- Game: addappid(2499800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499801, 1, "5ec671a05605967a09c2080a51481d78eaa419c60e09ac9c90ca4a98864cd79d")
