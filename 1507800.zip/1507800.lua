-- Lua provided by RyzenAPI
-- Game: Base Defense VR

-- MAIN APPLICATION
addappid(1507800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507801, 1, "265f397e584094992ffd9cadb67d3c5c22159fee12b0b6979ee8650238b1735d")
