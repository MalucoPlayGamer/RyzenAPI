-- Lua provided by RyzenAPI
-- Game: World of Islands

-- MAIN APPLICATION
addappid(810340)

-- MAIN APP DEPOTS / PACKAGES
addappid(810341, 1, "6cf92a7de09adccc44fdf7bda6cfe4edfe4286f4d2d82015cb36242df9e77a8c")
addappid(3539660, 0, "c64f6bece46133b9f8f24e0b12a1821dcbadd0403ab821468c227b9c99d46dee")

