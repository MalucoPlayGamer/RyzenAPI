-- Lua provided by RyzenAPI
-- Game: AB AETERNO Playtest

-- MAIN APPLICATION
addappid(1625640)
-- Game: addappid(1625640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625641, 1, "f44e951e42c708976b6363c651d613946c120ae951aa787230a501cbf8c6328d")
