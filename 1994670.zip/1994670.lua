-- Lua provided by RyzenAPI
-- Game: Neon Nights 2

-- MAIN APPLICATION
addappid(1994670)
-- Game: addappid(1994670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994671, 1, "82551a83a5b32d9ed9d2669fcf1049a1d91be9e4c80617309eaa70aa873dd32c")
addappid(1994674, 1, "9867fd8af310a23e8b90a411bbca67bd5fdf1b72c01ecefafdce9c0a3f3a8e29")
addappid(2276970, 0, "c351f912539aeb2a27edba7bb2357e9623e63d420434e8cd99240718f42886f1")
