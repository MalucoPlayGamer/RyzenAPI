-- Lua provided by RyzenAPI
-- Game: Game: AppID 977210

-- MAIN APPLICATION
addappid(977210)
-- Game: addappid(977210)

-- MAIN APP DEPOTS / PACKAGES
addappid(977211, 1, "c68380842fb2fcbe21b1105f70f76289d014e9c2bac3173909da520bd59ea447")
