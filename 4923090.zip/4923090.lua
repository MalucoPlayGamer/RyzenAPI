-- 4923090's Lua and Manifest Created by Hubcap Manifest
-- Rent Due
-- Created: August 04, 2026 at 18:56:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4923090) -- Rent Due
-- MAIN APP DEPOTS
addappid(4923091, 1, "bc7bac33f95a92d2dc868bf28fc37e3f1331d3b580a5d0ed82a0dfe768103a78") -- Depot 4923091
setManifestid(4923091, "5360085737317411626", 4515818339)