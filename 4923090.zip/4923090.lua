-- Lua provided by RyzenAPI
-- Game: Rent Due

-- MAIN APPLICATION
addappid(4923090) -- Rent Due

-- MAIN APP DEPOTS / PACKAGES
addappid(4923091, 1, "bc7bac33f95a92d2dc868bf28fc37e3f1331d3b580a5d0ed82a0dfe768103a78") -- Depot 4923091

