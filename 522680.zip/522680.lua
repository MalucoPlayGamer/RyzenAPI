-- Lua provided by SkyAPI 
-- Game: STANDBY Demo
addappid(522680)
addappid(522681, 1, "ea5e383e200bb13ebf8fee6a3fb48d43c752bfa7de7bedd644f01b2d7bb0b17a")
