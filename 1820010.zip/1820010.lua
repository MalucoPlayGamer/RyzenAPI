-- Lua provided by RyzenAPI
-- Game: addappid(1820010)

-- MAIN APPLICATION
addappid(1820010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820010,0,"9ab854fa6c5411b955c3b2ce4ad93928af34b7e1ab1923a30e78ca0c9e10ba1e")
