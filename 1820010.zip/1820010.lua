-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1820010)
addappid(1820010,0,"9ab854fa6c5411b955c3b2ce4ad93928af34b7e1ab1923a30e78ca0c9e10ba1e")
-- setManifestid(1820010,"4525063690892793122")