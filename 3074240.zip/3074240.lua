-- Lua provided by RyzenAPI
-- Game: 3074240

-- MAIN APPLICATION
addappid(3074240)
-- Game: addappid(3074240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074241, 1, "b4e752e708fd52450e9bfa6ab37ca83822526e0d9d3d52d4675ccc8de7729165")
