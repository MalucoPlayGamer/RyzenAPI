-- Lua provided by SkyAPI 
-- Game: Void Collector
addappid(3074240)
addappid(3074241, 1, "b4e752e708fd52450e9bfa6ab37ca83822526e0d9d3d52d4675ccc8de7729165")
