-- Lua provided by RyzenAPI
-- Game: AppID 340520

-- MAIN APPLICATION
addappid(340520)

-- MAIN APP DEPOTS / PACKAGES
addappid(340521, 1, "1baf9757f8c83330ea82ad12985c7b8f1be06df87c1159c64c24cfc7e327d610")
addappid(340522, 1, "217b9912b4fb5ab6adff06618c05b262464adc5f534ed792479e82e0ff39cf5b")
addappid(340523, 1, "32b292e750612aea89ddd785c93634e287ca940af346a5da0de05b0eca0ad883")
addappid(340524, 1, "20ef08587303df14553a8c68f6636d6cefaee5ee9e5077d89fbed685a46de5a9")
addappid(340525, 1, "d87cbaae246f15626c31a16b8be58ac02d89d3faca34a7d42d629827a49c4c60")
addappid(340526, 1, "8a8a601760ffa98f1f28277d24208ac8b3165a023d9e63cb43a778581f41f3d3")
addappid(367181, 0, "98b6f222b61e8e8cc2a5ec5e2fc1e568d083a125552dea06eec396133a799262")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(367180)
