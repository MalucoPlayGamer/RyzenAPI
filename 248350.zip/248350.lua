-- Lua provided by RyzenAPI 
-- Game: AppID 248350
addappid(248350)
addappid(248351, 1, "caa3478b3bc897e62aa56c94b94ae6fcf78317ae3b3ff776cc939b21537d7683")
