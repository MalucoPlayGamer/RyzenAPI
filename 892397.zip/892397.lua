-- Lua provided by RyzenAPI
-- Game: Xin Xianying (Special Costume)/辛憲英「特製コスチューム」

-- MAIN APPLICATION
addappid(892397)

-- MAIN APP DEPOTS / PACKAGES
addappid(892397,0,"8320bb19338a719e91c1f744d8351f0ea0fcf4243402edb8546a70f575578543")
