-- Lua provided by RyzenAPI
-- Game: AppID 937980

-- MAIN APPLICATION
addappid(937980)
addappid(938550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(937981, 1, "e26126559d7fe30562a4d47bd93a0f20a76167984c42b62f429ac83b2596ba33")

