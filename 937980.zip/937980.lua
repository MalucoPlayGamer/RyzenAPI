-- Lua provided by RyzenAPI
-- Game: 937980

-- MAIN APPLICATION
addappid(937980)
-- Game: addappid(937980)

-- MAIN APP DEPOTS / PACKAGES
addappid(937981, 1, "e26126559d7fe30562a4d47bd93a0f20a76167984c42b62f429ac83b2596ba33")
