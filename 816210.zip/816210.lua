-- Lua provided by RyzenAPI
-- Game: addappid(816210)

-- MAIN APPLICATION
addappid(816210)

-- MAIN APP DEPOTS / PACKAGES
addappid(816211, 1, "8e08c8ed0ddca90e5c6fbcda7173bda278c62bc347197ae989bbbc23e0c81d67")
