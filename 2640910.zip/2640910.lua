-- Lua provided by RyzenAPI
-- Game: Yeetus

-- MAIN APPLICATION
addappid(2640910)
-- Game: addappid(2640910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2640911, 1, "005b96d65ffdcb0fc49db97f2e06e05e9c8473e0798d65018b20bc5e0564e2d5")
