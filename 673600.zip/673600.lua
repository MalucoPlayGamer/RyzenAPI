-- Lua provided by RyzenAPI
-- Game: Game: Prison Boss VR

-- MAIN APPLICATION
addappid(673600)
-- Game: addappid(673600)

-- MAIN APP DEPOTS / PACKAGES
addappid(673601, 1, "ba5c317d817cb0b27a9f36835adbe76e1a31a7cf8258a0bf9225cf740aba5ccf")
