-- Lua provided by RyzenAPI
-- Game: Nyanco Card

-- MAIN APPLICATION
addappid(1272970)
addappid(1272971)
addappid(1272972)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272973,0,"accf6242a43b3aafc6e1d9a97930d5728c10f005d3c0c1bef2cc59f599648466")
addappid(1285030,0,"45764a704e1cb389f6e64d625cfd7c4b789ba59cc0942e4feb32277ee0668fee")
