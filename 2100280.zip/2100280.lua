-- Lua provided by RyzenAPI
-- Game: World of Tanks: HEAT

-- MAIN APPLICATION
addappid(2100280)

