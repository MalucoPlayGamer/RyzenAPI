-- Lua provided by RyzenAPI
-- Game: addappid(723780)

-- MAIN APPLICATION
addappid(723780)

-- MAIN APP DEPOTS / PACKAGES
addappid(723781, 1, "1a4bde46de86121088346dd599d95244154b45b983ec506fa1fd4a51e54be755")
