-- Lua provided by RyzenAPI
-- Game: 2517830

-- MAIN APPLICATION
addappid(2517830)
-- Game: addappid(2517830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517830,0,"9c5d1ab007adf2d7a35b44be730c4bfc10eddf39ebfc546c1516cd409f50d5b5")
