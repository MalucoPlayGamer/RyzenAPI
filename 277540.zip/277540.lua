-- Lua provided by RyzenAPI
-- Game: Curse of Dragon Mountains: The Strix

-- MAIN APPLICATION
addappid(277540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(277541, 1, "6dd6124c53d1cbd087660d902c3560d0c319e0a282313cf44111bf4d7e8350c2")
addappid(277542, 1, "813454807ef1f8c33a29dc40eb16a976d4cd58289d54dab405b8e00e190b42b4")
addappid(277553, 1, "411a45986ec7417bb8a8fb4e198a7bba96e4011d81ff110c565354f3fc4cb0e9")

