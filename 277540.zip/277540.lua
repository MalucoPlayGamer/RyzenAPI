-- Lua provided by RyzenAPI
-- Game: Curse of Dragon Mountains: The Strix

-- MAIN APPLICATION
addappid(277540)

-- MAIN APP DEPOTS / PACKAGES
addappid(277541, 1, "6dd6124c53d1cbd087660d902c3560d0c319e0a282313cf44111bf4d7e8350c2")
addappid(277542, 1, "813454807ef1f8c33a29dc40eb16a976d4cd58289d54dab405b8e00e190b42b4")
addappid(277553, 1, "411a45986ec7417bb8a8fb4e198a7bba96e4011d81ff110c565354f3fc4cb0e9")

