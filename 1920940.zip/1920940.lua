-- Lua provided by SkyAPI 
-- Game: AppID 1920940
addappid(1920940)
addappid(1920941, 1, "b9a5811c74e582891092cc493632bc8cd6228a36520929bcd188c8abbba938a4")
