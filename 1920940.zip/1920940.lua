-- Lua provided by RyzenAPI
-- Game: Game: AppID 1920940

-- MAIN APPLICATION
addappid(1920940)
-- Game: addappid(1920940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920941, 1, "b9a5811c74e582891092cc493632bc8cd6228a36520929bcd188c8abbba938a4")
