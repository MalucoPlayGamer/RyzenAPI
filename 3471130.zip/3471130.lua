-- Lua provided by RyzenAPI
-- Game: Game: AppID 3471130

-- MAIN APPLICATION
addappid(3471130)
-- Game: addappid(3471130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471131, 1, "d57e69a17d5c9b24ca6dc7312c30988a2dc96186856a05b56d27fd249631d884")
