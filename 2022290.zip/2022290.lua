-- Lua provided by RyzenAPI
-- Game: Amairo Chocolate 2

-- MAIN APPLICATION
addappid(2022290)
-- Game: addappid(2022290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022291, 1, "3c1429ecd48b2e2395eea29bd465a8f5fcb0a0a92dd5b61c864f7b19359791d4")
