-- Lua provided by RyzenAPI
-- Game: 2494960

-- MAIN APPLICATION
addappid(2494960)
-- Game: addappid(2494960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494961, 1, "5d696aac414272e70d9b923d48839bff4f6a23aea82ca674dedf08a61085bf39")
