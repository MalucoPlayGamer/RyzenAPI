-- Lua provided by RyzenAPI
-- Game: AppID 1496850

-- MAIN APPLICATION
addappid(1496850)
-- Game: addappid(1496850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496851, 1, "ce7bfc42dd3a4a5e94121421e6053226b8c5fc9d413dce7a30225b88b2b84625")
