-- Lua provided by RyzenAPI
-- Game: Indigo Prophecy

-- MAIN APPLICATION
addappid(9740)

-- MAIN APP DEPOTS / PACKAGES
addappid(9741, 1, "d70942857036976d5b442a8efa1c7d79e78e29dcecb8172d885790001781cdaa")
addappid(9742, 1, "2c72f4e858bee67a93f2fbc0eb17d9468a48e9dee6adf60abc4a837ab8dea32e")

