-- Lua provided by RyzenAPI
-- Game: 2420440

-- MAIN APPLICATION
addappid(2420440)
-- Game: addappid(2420440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420441, 1, "e8396df7cd83ea34739e07a5d85f34d5050b8bf3ed695dcf7ed6d4c14e754448")
