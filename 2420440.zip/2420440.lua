-- Lua provided by SkyAPI 
-- Game: AppID 2420440
addappid(2420440)
addappid(2420441, 1, "e8396df7cd83ea34739e07a5d85f34d5050b8bf3ed695dcf7ed6d4c14e754448")
