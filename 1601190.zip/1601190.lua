-- Lua provided by RyzenAPI
-- Game: Game: Ultimate Demolition

-- MAIN APPLICATION
addappid(1601190)
-- Game: addappid(1601190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601191, 1, "52914b1b279717447006e52fd2b361d3ae8f2cdee8ece0f2aeb15a206cff67d9")
