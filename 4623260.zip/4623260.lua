-- 4623260's Lua and Manifest Created by Hubcap Manifest
-- slimes!
-- Created: August 02, 2026 at 03:21:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4623260) -- slimes!
-- MAIN APP DEPOTS
addappid(4623261, 1, "005464506b3caf0bd547bbf6e065bef96e897dd0bf170a130d728fcc64d0798a") -- Depot 4623261
setManifestid(4623261, "1567834967100636365", 4231336021)