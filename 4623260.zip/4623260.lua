-- Lua provided by RyzenAPI
-- Game: slimes!

-- MAIN APPLICATION
addappid(4623260) -- slimes!

-- MAIN APP DEPOTS / PACKAGES
addappid(4623261, 1, "005464506b3caf0bd547bbf6e065bef96e897dd0bf170a130d728fcc64d0798a") -- Depot 4623261

