-- Lua provided by RyzenAPI
-- Game: Game: AppID 816740

-- MAIN APPLICATION
addappid(816740)
-- Game: addappid(816740)

-- MAIN APP DEPOTS / PACKAGES
addappid(816741, 1, "48025764b39c1707c67a78d87c831ab2ad5a664d31c818a5e9dcf646599c6914")
