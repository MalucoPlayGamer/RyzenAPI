-- Lua provided by RyzenAPI
-- Game: THE BYTE

-- MAIN APPLICATION
addappid(1498110)
-- Game: addappid(1498110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498111, 1, "5da5e9268b9b760c083a2cba1920d02b26e4af80fb7f8430cd915986b8b42966")
