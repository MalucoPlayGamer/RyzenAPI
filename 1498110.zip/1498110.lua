-- Lua provided by RyzenAPI 
-- Game: THE BYTE
addappid(1498110)
addappid(1498111, 1, "5da5e9268b9b760c083a2cba1920d02b26e4af80fb7f8430cd915986b8b42966")
