-- Lua provided by RyzenAPI
-- Game: AppID 1934780

-- MAIN APPLICATION
addappid(1934780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934781, 1, "6d6f81b7ea8191c8247fbee5965de540e66d5ae8cb433cfdbf0e260b06eed25b")

