-- Lua provided by SkyAPI 
-- Game: AppID 1934780
addappid(1934780)
addappid(1934781, 1, "6d6f81b7ea8191c8247fbee5965de540e66d5ae8cb433cfdbf0e260b06eed25b")
