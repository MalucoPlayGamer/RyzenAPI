-- Lua provided by RyzenAPI
-- Game: VEILED EXPERTS

-- MAIN APPLICATION
addappid(1934780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1934781, 1, "6d6f81b7ea8191c8247fbee5965de540e66d5ae8cb433cfdbf0e260b06eed25b")
