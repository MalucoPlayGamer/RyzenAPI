-- Lua provided by RyzenAPI
-- Game: Kizuna AI - Touch the Beat!

-- MAIN APPLICATION
addappid(2168240)
addappid(2346600)
addappid(2379840)
addappid(2426680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168241, 1, "0b5b008cb201babba949bc2fc102380bf65c566c75f45f787bd79e29ddc71881")

