-- Lua provided by RyzenAPI
-- Game: Xuan-Yuan Sword: Dance of the Maple Leaves

-- MAIN APPLICATION
addappid(1508750)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1508751, 1, "d785cc24156b1789f063b955b588e91dfb33ffb6e6153676066df437159b9f0d")

