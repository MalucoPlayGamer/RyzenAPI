-- Lua provided by RyzenAPI
-- Game: addappid(3176810)

-- MAIN APPLICATION
addappid(3176810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176811, 1, "7b7e5c15868ff79c2364dbb31ba2cc1355c171f0c01aad0e05ad792b5ed2bd34")
