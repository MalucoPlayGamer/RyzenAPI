-- Lua provided by RyzenAPI
-- Game: Esports Godfather Origin

-- MAIN APPLICATION
addappid(2739460)
-- Game: addappid(2739460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739461, 1, "51d2015cfa0a0c5a72ee1e0a09d4e199ec055a1a2151a68a6c155773e0c091a7")
