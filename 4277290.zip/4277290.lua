-- Lua provided by RyzenAPI
-- Game: One More Spin

-- MAIN APPLICATION
addappid(4277290) -- One More Spin

-- MAIN APP DEPOTS / PACKAGES
addappid(4277291, 1, "e816629ad0e607633de4b78b3e984b876fdd473d23eed150e6a833bc285e79a3") -- Depot 4277291
