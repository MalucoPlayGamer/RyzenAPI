-- Lua provided by SkyAPI 
-- Game: Three Kingdoms The Last Warlord-Dawn of Heroes
addappid(3575830)
addappid(3575831, 1, "d670f276b1ae00423bdb91f1d2cde9606690dbd9ad08b172df411476c7458bd8")
