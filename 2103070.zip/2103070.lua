-- Lua provided by RyzenAPI
-- Game: Avani

-- MAIN APPLICATION
addappid(2103070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103071, 1, "5fab7e2b0d8990fef59cf83666b93e9d6ef4ae6486af98ac8cdde383631ed9c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
