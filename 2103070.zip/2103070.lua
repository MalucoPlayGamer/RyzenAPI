-- Lua provided by RyzenAPI 
-- Game: Avani
addappid(2103070)
addappid(2103071, 1, "5fab7e2b0d8990fef59cf83666b93e9d6ef4ae6486af98ac8cdde383631ed9c8")
