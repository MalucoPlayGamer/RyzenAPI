-- Lua provided by RyzenAPI
-- Game: Game: IN THE BUILDING: CATS

-- MAIN APPLICATION
addappid(2203730)
-- Game: addappid(2203730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203731, 1, "34176a6ee7bd2cecd6b146688ff74f00ed32f80395cf3b5efcda9cee2354aaf9")
