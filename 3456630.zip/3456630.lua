-- Lua provided by RyzenAPI
-- Game: Trailmakers: Pioneers Soundtrack

-- MAIN APPLICATION
addappid(3456630)
-- Game: addappid(3456630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456631, 1, "9f9c2f259be9cb593e001d120640262866c3870cf5380455c89fcf30f8995028")
addappid(3456632, 1, "b5eedd68da9030d5ec34420d891dc7430f993ea5598636b794e2ec59927930bb")
