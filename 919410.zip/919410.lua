-- Lua provided by RyzenAPI
-- Game: Felix the Reaper

-- MAIN APPLICATION
addappid(919410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(919411, 1, "9a7f1005cd22b82b955c3c6fe5716a5fa85b531b06cdb4a6ff5180af0cd31287")
addappid(919412, 1, "c3e6124de6dc62845eac8a9e30c7821f877202383d589f2e2592992bc3cacaf5")
addappid(1159930, 0, "e0a4f25bdcf31d6626490476b7fc419185a00b52cf44ef0fe1843832c9d117c7")
