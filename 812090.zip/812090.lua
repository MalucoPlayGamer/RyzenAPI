-- Lua provided by RyzenAPI
-- Game: addappid(812090)

-- MAIN APPLICATION
addappid(812090)

-- MAIN APP DEPOTS / PACKAGES
addappid(812091, 1, "ae088472ebff768d62a704d1fc371b17037a29818a55a635fef567c422ab9750")
