-- Lua provided by RyzenAPI
-- Game: RAW FOOTAGE

-- MAIN APPLICATION
addappid(812090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(812091, 1, "ae088472ebff768d62a704d1fc371b17037a29818a55a635fef567c422ab9750")

