-- Lua provided by RyzenAPI
-- Game: Getaway Island

-- MAIN APPLICATION
addappid(605190)

-- MAIN APP DEPOTS / PACKAGES
addappid(605191, 1, "d12cb7014b50bf747c2dd1a0ae843f3ea6c6d6dce13ce74991d916c0f369d032")

