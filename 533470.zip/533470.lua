-- Lua provided by SkyAPI 
-- Game: AppID 533470
addappid(533470)
addappid(533471, 1, "48984c752a6ad5ac5383e93822386a7cb856b6e3d0c609531138f46c854280fe")
