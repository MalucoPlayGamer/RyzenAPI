-- Lua provided by RyzenAPI
-- Game: Project: Sword Art

-- MAIN APPLICATION
addappid(2304490)
-- Game: addappid(2304490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304491, 1, "c0854b5db167fafc12c98f0ae9353fb7071ee46a984a6c6efe7bdb833e6972b0")
