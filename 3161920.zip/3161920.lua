-- Lua provided by RyzenAPI
-- Game: You Are Grounded

-- MAIN APPLICATION
addappid(3161920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161921, 1, "99983d719172fef83e4c716fdf7eb070ea1cab9a734b68dc1e23e8394ba87417")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
