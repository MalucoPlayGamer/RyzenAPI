-- Lua provided by RyzenAPI
-- Game: You Are Grounded

-- MAIN APPLICATION
addappid(3161920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161921, 1, "99983d719172fef83e4c716fdf7eb070ea1cab9a734b68dc1e23e8394ba87417")
