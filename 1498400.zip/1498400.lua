-- Lua provided by RyzenAPI
-- Game: 1498400

-- MAIN APPLICATION
addappid(1498400)
-- Game: addappid(1498400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498401, 1, "5e56dadd99be15940a99b46b4117b69b43b4a7b05f433a6e12838c3692eb7c7a")
