-- Lua provided by RyzenAPI
-- Game: Legend of Krannia: Cursed Fate

-- MAIN APPLICATION
addappid(1458340)
-- Game: addappid(1458340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458341, 1, "aa3812cc5100589a30f2f3eb03191ca22df76f7cb2a6d53f00b167922e807c7d")
