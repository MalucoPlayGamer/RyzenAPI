-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Easy String Skipping Exercise 2

-- MAIN APPLICATION
addappid(1089227)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089227,0,"cd44389a739ae870d98eb0e23766946fe1ee1fd5d60d810b222af83238bea2fa")

