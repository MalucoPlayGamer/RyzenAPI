-- Lua provided by RyzenAPI
-- Game: AppID 998400

-- MAIN APPLICATION
addappid(998400)

-- MAIN APP DEPOTS / PACKAGES
addappid(998401, 1, "edea4a78e56567e965ed901d64d5b248e8b90195edbb0500ffd8c56a8aa9c95d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
