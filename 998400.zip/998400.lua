-- Lua provided by RyzenAPI
-- Game: AppID 998400

-- MAIN APPLICATION
addappid(998400)

-- MAIN APP DEPOTS / PACKAGES
addappid(998401, 1, "edea4a78e56567e965ed901d64d5b248e8b90195edbb0500ffd8c56a8aa9c95d")
