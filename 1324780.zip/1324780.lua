-- Lua provided by RyzenAPI
-- Game: Easy Red 2

-- MAIN APPLICATION
addappid(1324780)
addappid(1888350)
addappid(2317930)
addappid(2617770)
addappid(3499380)
addappid(4563790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324781, 1, "8a121832d20574941b7d7e7eb4a34323c9ebe72338fc859080aac679b74bd78c")
addappid(1324782, 1, "4540b21d37c237bc72c6a5b2c3c1202a48b56a5e2bd9b7e8aed3e2112f87042c")
addappid(1324783, 1, "3e04baca8a855c9d1936a84667b80691d3a021d9b24927ff2f32a45f46d18b99")

