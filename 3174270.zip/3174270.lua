-- Lua provided by RyzenAPI
-- Game: Dirty League Demo

-- MAIN APPLICATION
addappid(3174270)
-- Game: addappid(3174270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3174271, 1, "8253b83b7c7949a9dc9fb6d46b1560571a6a34e264c100838607cd1e3c5bd697")
