-- Lua provided by RyzenAPI
-- Game: addappid(1937790)

-- MAIN APPLICATION
addappid(1937790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937791, 1, "984a93f7983926f1657e7bdd927e8e735ca9097c59000a921d20df9215bcde3e")
