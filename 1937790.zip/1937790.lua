-- Lua provided by RyzenAPI 
-- Game: AppID 1937790
addappid(1937790)
addappid(1937791, 1, "984a93f7983926f1657e7bdd927e8e735ca9097c59000a921d20df9215bcde3e")
