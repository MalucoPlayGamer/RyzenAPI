-- Lua provided by RyzenAPI
-- Game: Game: AppID 1022000

-- MAIN APPLICATION
addappid(1022000)
-- Game: addappid(1022000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022001, 1, "a37e8632fce7f57e5942dfc41b9ec1e5b8e6ad15f1682dbaad1c3d633139f900")
