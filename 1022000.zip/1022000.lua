-- Lua provided by RyzenAPI
-- Game: Lyantei

-- MAIN APPLICATION
addappid(1022000)
addappid(1027640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1022001, 1, "a37e8632fce7f57e5942dfc41b9ec1e5b8e6ad15f1682dbaad1c3d633139f900")
