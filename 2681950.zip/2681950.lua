-- Lua provided by RyzenAPI
-- Game: Boba Bar: Bubble Tea Tycoon

-- MAIN APPLICATION
addappid(2681950)
-- Game: addappid(2681950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681951, 1, "dee10691e084d77e0c9d64531b300db418dcd1da9e7930fee9238903f5c9f334")
