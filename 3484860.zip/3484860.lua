-- Lua provided by RyzenAPI 
-- Game: 迷雾之村Misty Village
addappid(3484860)
addappid(3484861, 1, "35cb8ac335df6fb8d49bd9b599c4cc9ca4ec82f44162c3bed9c5045229658bf5")
