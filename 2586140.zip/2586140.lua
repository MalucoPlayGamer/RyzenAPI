-- Lua provided by RyzenAPI
-- Game: 2586140

-- MAIN APPLICATION
addappid(2586140)
-- Game: addappid(2586140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586141, 1, "88914d4d43f47fa4cb696436a54bc5faf45c6b534d61c23a2e229c908c260edd")
