-- Lua provided by RyzenAPI
-- Game: Enforcer: Original Soundtrack

-- MAIN APPLICATION
addappid(334580)

-- MAIN APP DEPOTS / PACKAGES
addappid(334580,0,"f4780740da9127e699fea18bcdc69bfbd70dc2feb7584f6ae69467e55a5ab83a")
addtoken(334580,5662659657477429811)
