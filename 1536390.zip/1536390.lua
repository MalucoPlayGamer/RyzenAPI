-- Lua provided by RyzenAPI
-- Game: AppID 1536390

-- MAIN APPLICATION
addappid(1536390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536391, 1, "9f8c1e2ece2edbce0a3b0cb7ac390b5af056f128c2c249908e145f40f121c167")

