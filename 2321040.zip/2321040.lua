-- Lua provided by RyzenAPI
-- Game: 2321040

-- MAIN APPLICATION
addappid(2321040)
-- Game: addappid(2321040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321041, 1, "c5d6ceaa0a1b4c67318ac4bec3cc667777919d374ea1f445bd974d4ada4f68ff")
