-- Lua provided by RyzenAPI
-- Game: Vagrus - The Riven Realms: Demo (Prologue)

-- MAIN APPLICATION
addappid(1304660)
-- Game: addappid(1304660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304661, 1, "e71749d43018b6b0f3bb032158518b73c33e9f9a4d2b1001031464c2e765c02e")
addappid(1304662, 1, "1e04b3fe5cfdcf90d8f2736d97c8ff70f2f2ccceb9ea36b78e00f67958d16dfc")
addappid(1304663, 1, "69333795c81b448b5f55622c5f6a5e64178ce9faeb697b0f1c7b3e7607e88964")
