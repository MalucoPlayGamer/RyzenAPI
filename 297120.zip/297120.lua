-- Lua provided by RyzenAPI
-- Game: Heavy Bullets

-- MAIN APPLICATION
addappid(297120)
-- Game: addappid(297120)

-- MAIN APP DEPOTS / PACKAGES
addappid(297121, 1, "58d969ae18fa82acb659bf17caeed2773222834a0129de7d3f5f5851303d4786")
addappid(297123, 1, "939acaf342aa8e58a4b9b792eb467e5d49b3e57b9778d8030271e7e768a3fb4e")
addappid(297124, 1, "cf665a6bd8ff6114f48e3257397769c07b2f12eaac7801695921731b04b33b69")
