-- Lua provided by RyzenAPI
-- Game: JR EAST Train Simulator: Utsunomiya Line (Kuroiso to Tokyo) E233-3000 series

-- MAIN APPLICATION
addappid(3166710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3166711, 1, "006c080bf4ee4c9d36a33d312ecb3954e751262a906a45a7dc6295d159d16caa")
addappid(3166712, 1, "6633b6719723a476207c87d63d65bb16374b26c41fb3bb8646c172162fd0503b")
