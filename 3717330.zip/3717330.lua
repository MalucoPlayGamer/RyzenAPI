-- Lua provided by RyzenAPI
-- Game: Yakuza Kiwami

-- MAIN APPLICATION
addappid(3717330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3717331, 1, "0ae165b84122aca403f33db5776efe0b7470e19c5dd5f3049ad9b0a149bebc86")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
