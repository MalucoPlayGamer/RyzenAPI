-- Lua provided by SkyAPI 
-- Game: AppID 920820
addappid(920820)
addappid(920821, 1, "7b2e2a6f8d67327e4a994be4bffa37f00e69d2de397e4f0fefa68137c9e2eba2")
addappid(937400, 0, "2b7e2fba3f18afd701bc11e3ac15918401043aa91d08985256a9bc5905947bca")
