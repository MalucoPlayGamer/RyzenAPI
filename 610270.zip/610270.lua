-- Lua provided by RyzenAPI
-- Game: Bloody Trapland 2 : Curiosity - Soundtrack

-- MAIN APPLICATION
addappid(610270)

-- MAIN APP DEPOTS / PACKAGES
addappid(610270,0,"98f5b55d2cc437ddfd4f6deca07681c5e6377a7fde23b89a6c88d8b21dd077d5")

