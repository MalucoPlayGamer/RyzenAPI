-- Lua provided by RyzenAPI
-- Game: Game: Jam Scrapz Collection

-- MAIN APPLICATION
addappid(2097480)
-- Game: addappid(2097480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097481, 1, "20434b1814d5c487fb11291774005a005ebb518a14093fb7fcadaabc98167166")
