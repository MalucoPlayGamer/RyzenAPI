-- Lua provided by RyzenAPI
-- Game: Jam Scrapz Collection

-- MAIN APPLICATION
addappid(2097480)
addappid(2099160)
addappid(2099161)
addappid(2099162)
addappid(2099163)
addappid(2099164)
addappid(2278040)
addappid(2664740)
addappid(2664750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2097481, 1, "20434b1814d5c487fb11291774005a005ebb518a14093fb7fcadaabc98167166")

