-- Lua provided by RyzenAPI 
-- Game: Jam Scrapz Collection
addappid(2097480)
addappid(2097481, 1, "20434b1814d5c487fb11291774005a005ebb518a14093fb7fcadaabc98167166")
