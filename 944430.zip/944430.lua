-- Lua provided by RyzenAPI 
-- Game: AppID 944430
addappid(944430)
addappid(944431, 1, "f9cbe1a06781d0f842b3f0d897b9ff1dc608d43d3dfbd0f0b00b056c805c801f")
