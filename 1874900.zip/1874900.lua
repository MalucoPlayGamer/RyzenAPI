-- Lua provided by SkyAPI 
-- Game: AppID 1874900
addappid(1874900)
addappid(1874901, 1, "6d9697280a4f623736ac39c7c8f97bc85c21c252a0fe2d88c8fc1cd9b2670bef")
addappid(1874902, 1, "eab47d15eff3a057174e71fb28ec7821e1ddf370235bd4ef70fbb7a446d7aa6c")
addappid(1874903, 1, "62840d956f26bc5aab9f01c6a9de7f36e34e9d7fb333341392f53ce9d6aaf81f")
