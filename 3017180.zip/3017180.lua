-- Lua provided by RyzenAPI
-- Game: A cat's way home

-- MAIN APPLICATION
addappid(3017180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017181, 1, "ece4e996b12487f427d07e75f87ae140d94f53272f827a2084baacdc8480939b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
