-- Lua provided by SkyAPI 
-- Game: A cat's way home
addappid(3017180)
addappid(3017181, 1, "ece4e996b12487f427d07e75f87ae140d94f53272f827a2084baacdc8480939b")
