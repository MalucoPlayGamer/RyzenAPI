-- Lua provided by RyzenAPI
-- Game: A cat's way home

-- MAIN APPLICATION
addappid(3017180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017181, 1, "ece4e996b12487f427d07e75f87ae140d94f53272f827a2084baacdc8480939b")

