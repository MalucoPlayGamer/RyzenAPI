-- 4836070's Lua and Manifest Created by Hubcap Manifest
-- Ghosts of Tabor : LEGACY
-- Created: August 01, 2026 at 09:13:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4836070) -- Ghosts of Tabor : LEGACY
-- MAIN APP DEPOTS
addappid(4836071, 1, "5510be0cf6e3d61dedf11fe535673a546745862c409818bd88f0325bab8ac52a") -- Depot 4836071
setManifestid(4836071, "6028414629397910790", 18121147428)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)