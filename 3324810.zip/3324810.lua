-- Lua provided by RyzenAPI
-- Game: Trial of lust

-- MAIN APPLICATION
addappid(3324810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3324811, 1, "233dc888030ec5d02204a357c7ccbe1208e6ea58a814fa636b8bfbbeb1691bbe")
addappid(3324812, 1, "10c563b4d02e066e5b3872051f2f526c6072e12f42baac4e2bbf39d4e65d4a49")
