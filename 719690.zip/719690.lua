-- Lua provided by RyzenAPI
-- Game: Ghost Recon Wildlands Ghost War Open Beta

-- MAIN APPLICATION
addappid(719690)
addappid(719790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(719691, 1, "cc7fd7cb3635f09aa42668228fd136e36754c5c9ac434207430528edcf6365ed")

