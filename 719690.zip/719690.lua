-- Lua provided by RyzenAPI
-- Game: AppID 719690

-- MAIN APPLICATION
addappid(719690)
-- Game: addappid(719690)

-- MAIN APP DEPOTS / PACKAGES
addappid(719691, 1, "cc7fd7cb3635f09aa42668228fd136e36754c5c9ac434207430528edcf6365ed")
