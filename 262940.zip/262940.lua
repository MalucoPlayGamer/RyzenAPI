-- Lua provided by RyzenAPI
-- Game: Broken Sword 5 - the Serpent's Curse

-- MAIN APPLICATION
addappid(262940)

-- MAIN APP DEPOTS / PACKAGES
addappid(262944,0,"9e8318c2a9e687ebbdcfdb3c4840605a4165a4c3988385ec6e1ba8adc8d01862")
addappid(262945,0,"3ebf52226bf2416f83136baf0b8404e284f217b373d73dfb698ac5e531433e85")
addappid(262946,0,"2c1c672d80e672c9926f2e6f312fe4956c9df30ceb76a8533fb66f69e9793a86")
addappid(262947,0,"76371e0d578ddf9281f1975cc9b3710cf12410b4f6e4944b7100f3e81a8b5538")
addappid(262948,0,"eabb5eda708f772c863bc86da2c641e713527703905072e3266e821edeec543a")
addappid(262949,0,"1b7d0412c4dfc0d1aa011d6c48d272313ec89b4002a08dc59682e243588efb92")
addappid(262950,0,"798e42e21c2fda92b6ceee4614e95ae7ad4ddbe6e74378b214ae773b5404d753")
addappid(262951,0,"f058ba5d45a95af6d6e31517b04f09c9dd46a97d6b36f78ba908f12470e802d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(267820)
addappid(565830)
