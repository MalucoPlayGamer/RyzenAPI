-- Lua provided by RyzenAPI
-- Game: 650940

-- MAIN APPLICATION
addappid(650940)
addappid(650941)
addappid(650942)
addappid(650943)
addappid(650944)
addappid(1074360)
addappid(1440601)
addappid(1440602)
addappid(1440603)
-- Game: addappid(650940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440600,0,"e5319bfd2336dbe56e9bd13dcd7905634eeebd0f0eb7599a34d1954ee1d56248")
