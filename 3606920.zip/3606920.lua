-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Academy's Record

-- MAIN APPLICATION
addappid(3606920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3606921, 1, "7882ce82b099fc3a598ec93e2abc7a1a13221f8987ab9e97b34210e763b1a353")
