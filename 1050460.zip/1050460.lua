-- Lua provided by RyzenAPI
-- Game: Devil May Cry 5 Original Soundtrack

-- MAIN APPLICATION
addappid(1050460)
-- Game: addappid(1050460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050461, 1, "6fceef47cd5bd1b29636c65582c0cb8ee3d03717a888e0932455686860aef1da")
addappid(1050462, 1, "12c7ffb76f8329f075547c4ffdfac4d55b2d3f9daac8ee3a960d35da41643378")
addappid(1050463, 1, "34da08cba74dfc017f338c347030b16971cd70e954814555ba2456556b0cf440")
addappid(1050464, 1, "852989f2d761b45f143ff7cec75124bfd00ad5cbbbec30101d20b14fc45178e6")
addappid(1050465, 1, "e23657c8ffa04b0635ef382ac4a04c221ed5bfa2cd3de6c07c2fedf98af6173a")
addappid(1050466, 1, "5716c178a6836c823d18ee2fd44e99e01122a2bd812470f9c607c66b5ad5b5bd")
