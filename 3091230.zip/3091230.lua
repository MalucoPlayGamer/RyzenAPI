-- Lua provided by RyzenAPI
-- Game: 3091230

-- MAIN APPLICATION
addappid(3091230)
-- Game: addappid(3091230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3091231, 1, "1080d8298b33d2c89f2f2eec429e5065d3dc3cc515dd8e259d2f4758b987990e")
