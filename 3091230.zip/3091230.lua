-- Lua provided by RyzenAPI 
-- Game: UFO-Man
addappid(3091230)
addappid(3091231, 1, "1080d8298b33d2c89f2f2eec429e5065d3dc3cc515dd8e259d2f4758b987990e")
