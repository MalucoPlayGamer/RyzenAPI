-- Lua provided by RyzenAPI
-- Game: 528670

-- MAIN APPLICATION
addappid(528670)
-- Game: addappid(528670)

-- MAIN APP DEPOTS / PACKAGES
addappid(528671, 1, "a2d035b5c653b3e18a427a0cc6d25a9ce4bbca32b09643d57356c9788821aa1d")
