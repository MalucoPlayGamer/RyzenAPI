-- Lua provided by RyzenAPI
-- Game: addappid(538810)

-- MAIN APPLICATION
addappid(538810)

-- MAIN APP DEPOTS / PACKAGES
addappid(538811, 1, "cc4a8c16324f69336d2b0b9fd855fb7466d7bcde4942d19cbc53d7ad35750aaa")
