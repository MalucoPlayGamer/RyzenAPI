-- Lua provided by RyzenAPI
-- Game: Dangerous High School Girls in Trouble!™

-- MAIN APPLICATION
addappid(27400)

-- MAIN APP DEPOTS / PACKAGES
addappid(27401, 1, "aefbb85f88caa4730a2e62a99aefe7b88072a86d0d0e06cd599c73ae30ddf7c9")
addappid(27402, 1, "2e7c2b02f7709e1c347bd056f61d6ab26f7cb7ba31700ffee001755860ad1e25")

