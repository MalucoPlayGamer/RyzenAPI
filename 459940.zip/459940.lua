-- Lua provided by RyzenAPI 
-- Game: Deer Man
addappid(459940)
addappid(459941, 1, "f4efd01b09f206cdd5d34666ae75171ceb92bb0350ad51c1cde2c4a1f5da70ab")
addappid(460880, 0, "ebf724a899f940658ce5de03e3bde03185a8df3d20704a8c7f086ce3d773f0af")
