-- Lua provided by RyzenAPI
-- Game: Dark Riddle

-- MAIN APPLICATION
addappid(2486930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486931, 1, "e3552ed46455cedb54a12fe98ff0e1c1db77e36072c518da75daabc789bfdb79")
