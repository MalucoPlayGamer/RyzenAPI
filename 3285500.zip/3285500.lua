-- Lua provided by RyzenAPI 
-- Game: Three Kingdoms Mushouden
addappid(3285500)
addappid(3285501, 1, "d540ff5a3e564eb42dd7bc7fcd2767ba878e869bde88b3b99f21372cf43fe116")
addappid(3786750, 0, "8ea8b93dc597304b744fb21727c260bb3f2940dde0fc68d4cce2c9c1a2cdbecf")
