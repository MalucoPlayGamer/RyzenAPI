-- Lua provided by RyzenAPI
-- Game: Sex with a Vampire 🧛‍♂️❤️ Soundtrack

-- MAIN APPLICATION
addappid(2825170)
-- Game: addappid(2825170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825171, 1, "034c5a9057d1475cd46a605f19816cbc81205749ee22854143edae95316e58ed")
