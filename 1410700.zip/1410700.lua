-- Lua provided by RyzenAPI 
-- Game: AppID 1410700
addappid(1410700)
addappid(1410701, 1, "ca55cc195ebd330c3d50107fcab0e06d6ccdfab9e51a34e51038970a53a01e7a")
