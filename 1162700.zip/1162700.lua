-- Lua provided by RyzenAPI
-- Game: AppID 1162700

-- MAIN APPLICATION
addappid(1162700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162701, 1, "672762756044514f7d5c50eb7d91645058098957016d19d6811ba55a3179b66b")
addappid(1162702, 1, "a51a23ae5acf76cb393c6bcf5f101ec394ba648bffd2766d183e151ff081e7f4")
addappid(1162703, 1, "e36a4aae95f51827def8e1e6429e27251c72f62373b8ba6c4ef1140ec789ffb6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
