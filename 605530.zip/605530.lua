-- Lua provided by RyzenAPI
-- Game: PippiStory

-- MAIN APPLICATION
addappid(605530)

-- MAIN APP DEPOTS / PACKAGES
addappid(605531, 1, "ffc8833fe0eec1ed281065a0d7e89e2a79104344c77fded9597bf144e2e5a768")

