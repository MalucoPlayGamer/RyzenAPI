-- Lua provided by RyzenAPI
-- Game: 613040

-- MAIN APPLICATION
addappid(613040)
-- Game: addappid(613040)

-- MAIN APP DEPOTS / PACKAGES
addappid(613041, 1, "1c8944d289a8269b8f04afa3185c11b9f94743e29ea78bb38b3095dab504eec7")
