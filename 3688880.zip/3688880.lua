-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Hero Character Generator 2 for MZ

-- MAIN APPLICATION
addappid(3688880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3688880,0,"78baf3396a18547ff715b3d4abb9404ccf2031c6f53ec246b7f417ae3e06bf82")

