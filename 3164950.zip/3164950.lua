-- Lua provided by RyzenAPI
-- Game: Hentai Tales: The Secret Of Sato

-- MAIN APPLICATION
addappid(3164950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164951, 1, "af0713d8df65dc89e2e516be52f4b329f0066ad388d89e7e824b38c8496c53a4")
