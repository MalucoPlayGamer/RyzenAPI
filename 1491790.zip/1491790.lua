-- Lua provided by RyzenAPI
-- Game: Atom

-- MAIN APPLICATION
addappid(1491790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1491791, 1, "78d61475478bfa6f24c7b2b515143e9da241e30000da9077f1603eb31a7d76e0")
addappid(1491792, 1, "98fbb9b2b003268155a33c98b8e3435baf28e06f167a50b36c9e8a4d0dbf6c76")

