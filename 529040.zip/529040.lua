-- Lua provided by RyzenAPI
-- Game: Fine China

-- MAIN APPLICATION
addappid(529040)

-- MAIN APP DEPOTS / PACKAGES
addappid(529041,0,"6792a52f587e7616bdf37041369df7fc0747bbd96acce2d718bd6abd47ba954f")

