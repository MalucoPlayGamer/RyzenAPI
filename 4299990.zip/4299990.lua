-- Lua provided by RyzenAPI
-- Game: Unwilling Host

-- MAIN APPLICATION
addappid(4299990)

-- MAIN APP DEPOTS / PACKAGES
addappid(4299991,0,"9ab8b8ef89b8cc4e398fc6a5377afede9433f8179946c0b98a42f3171f09995e")

