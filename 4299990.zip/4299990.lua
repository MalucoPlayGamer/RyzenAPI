-- Lua provided by RyzenAPI
-- Game: Unwilling Host

-- MAIN APPLICATION
addappid(4299990)

-- MAIN APP DEPOTS / PACKAGES
addappid(4299991,0,"9ab8b8ef89b8cc4e398fc6a5377afede9433f8179946c0b98a42f3171f09995e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
