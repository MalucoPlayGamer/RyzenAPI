-- Lua provided by RyzenAPI
-- Game: Flex hooks

-- MAIN APPLICATION
addappid(1613050)
-- Game: addappid(1613050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1613051, 1, "55bc45ecdea710ec6b00edd2f2ce3c1bf24c68eba02515901dc0f7b72d84a3c4")
