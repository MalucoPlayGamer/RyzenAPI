-- Lua provided by SkyAPI 
-- Game: Stickman Escape
addappid(1545260)
addappid(1545261, 1, "92d4e18c8d23dbdcc45e01846aef954b1068806472ff8ce9b5e56d8a64d6bff7")
