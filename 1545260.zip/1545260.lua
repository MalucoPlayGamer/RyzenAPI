-- Lua provided by RyzenAPI
-- Game: Stickman Escape

-- MAIN APPLICATION
addappid(1545260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545261, 1, "92d4e18c8d23dbdcc45e01846aef954b1068806472ff8ce9b5e56d8a64d6bff7")
