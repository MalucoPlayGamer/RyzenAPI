-- Lua provided by RyzenAPI
-- Game: AppID 321350

-- MAIN APPLICATION
addappid(321350)
-- Game: addappid(321350)

-- MAIN APP DEPOTS / PACKAGES
addappid(321351, 1, "cd2023bffb063c89c9efcc62188c34ca00292021f52881c7da8246bc3b1e70db")
