-- Lua provided by RyzenAPI
-- Game: Game: Catherine Ragnor and the Legend of the Flying Dutchman

-- MAIN APPLICATION
addappid(1836360)
-- Game: addappid(1836360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836361, 1, "9fcff6f3ae4f067cac46cdd0917a1b1d08bdf1b2b4c8e046e128bc67492abb6c")
