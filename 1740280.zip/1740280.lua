-- Lua provided by RyzenAPI
-- Game: 1740280

-- MAIN APPLICATION
addappid(1740280)
-- Game: addappid(1740280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740281, 1, "d76325f75b1b662b4819bdbed2c2358fd0ee3311d4882d4bddff1bcbfd2fed43")
