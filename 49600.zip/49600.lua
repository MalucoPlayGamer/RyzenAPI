-- Lua provided by RyzenAPI
-- Game: Game: Beat Hazard

-- MAIN APPLICATION
addappid(49600)
addappid(228990)
-- Game: addappid(49600)

-- MAIN APP DEPOTS / PACKAGES
addappid(49601, 1, "9cdc76c33005e944fe10c08403bd68373e73e2b4f80f47252465208b0a40a9c5")
addappid(49607, 1, "25f62d478e7869ecc8bb22864081aeab4956860d7472b6a8627e4351702256c0")
addappid(49608, 1, "10b60ab82761de0dfcf80f358b1fa002af25bfbcda292b6e1cf32ace9dc94749")
