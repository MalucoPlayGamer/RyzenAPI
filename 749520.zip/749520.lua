-- Lua provided by RyzenAPI
-- Game: Sakura no Mori † Dreamers

-- MAIN APPLICATION
addappid(749520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(749521, 1, "ddc747e6f72b845defd7e93b18af19f763555c7c256ab873f7bc333d9870238b")
addappid(749522, 1, "1d189b497c4c0f56b9ecf8bdc2483b9c68c8d749a9985eb820d4636c8486c21e")

