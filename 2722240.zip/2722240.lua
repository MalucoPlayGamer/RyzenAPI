-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2722240)
-- Game: addappid(2722240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730040,0,"a8e3d1a77ad41396c2c86627773031594decd40d0ace3d502b0d81bc5345e581")
