-- Lua provided by RyzenAPI
-- Game: addappid(2722240)

-- MAIN APPLICATION
addappid(2722240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730040,0,"a8e3d1a77ad41396c2c86627773031594decd40d0ace3d502b0d81bc5345e581")
