-- Lua provided by RyzenAPI
-- Game: Game: The Dragons' Twilight II

-- MAIN APPLICATION
addappid(878090)
-- Game: addappid(878090)

-- MAIN APP DEPOTS / PACKAGES
addappid(878091, 1, "bde2aae3d01338c0d37dbe45fb73b409bd48e35e779b68e12f9abefb569b3bcc")
