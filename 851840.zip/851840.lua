-- Lua provided by RyzenAPI
-- Game: Strangers of the Power 2

-- MAIN APPLICATION
addappid(851840)

-- MAIN APP DEPOTS / PACKAGES
addappid(851841,0,"e06987248429983401fb3c1c7cc19221f4e1b8ecb5b02584009a232b64cb5c12")
addappid(1080840,0,"5c07a5557cdc85701776b0857ca1ce20f2a31b3c263e4be6db5a93a6f61b38e4")
addappid(1182120,0,"59606f074989b6b2eb8fecd3c1929cb383c86e426483b9196c6b0805314de520")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
