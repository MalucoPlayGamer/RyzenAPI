-- Lua provided by RyzenAPI 
-- Game: Spirit Detective
addappid(1872760)
addappid(1872761, 1, "082c3f9230bd45b72c3a781f00120953eb1cabdd469b22dda51ffb0556c7556c")
