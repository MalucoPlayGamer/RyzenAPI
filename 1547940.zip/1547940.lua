-- Lua provided by RyzenAPI
-- Game: GunSoulGirl-DLC_PATCH

-- MAIN APPLICATION
addappid(1547940)
-- Game: addappid(1547940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547940,0,"18737bf9460b33e98a02975b1483d74ab3b00cecf92387512c84c58f174fac46")
