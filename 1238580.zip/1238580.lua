-- Lua provided by RyzenAPI
-- Game: AppID 1238580

-- MAIN APPLICATION
addappid(1238580)
-- Game: addappid(1238580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238581, 1, "552c7945ca0bfb1dffb9bbad103e9d1d66abe9bb03882815940af5fcdb913969")
addappid(1238582, 1, "7f40bb34fad61fd2daddd9d1bef32ee1de0a89e6732140f25ae616fc7e10cb44")
