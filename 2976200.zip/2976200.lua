-- Lua provided by RyzenAPI
-- Game: My Holiness the Gobliness Artbook

-- MAIN APPLICATION
addappid(2976200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976201, 1, "123176ec0c8ba049dc73a7c89dc12a7221025e7ad54e7d288e8486488473ef75")

