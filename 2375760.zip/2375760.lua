-- Lua provided by RyzenAPI
-- Game: addappid(2375760)

-- MAIN APPLICATION
addappid(2375760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375761, 1, "4479492095a638cd435d31ee0569c71d6a201a11408ade892bddef8e4f31f3b9")
