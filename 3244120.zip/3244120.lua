-- Lua provided by RyzenAPI
-- Game: 星彩のメトリア Demo

-- MAIN APPLICATION
addappid(3244120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244121, 1, "6d49317846700c15b48ba91f798b3d6a8e28e539f93f09260e980d347d26cc92")

