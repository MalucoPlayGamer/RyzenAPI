-- Lua provided by SkyAPI 
-- Game: AppID 3244120
addappid(3244120)
addappid(3244121, 1, "6d49317846700c15b48ba91f798b3d6a8e28e539f93f09260e980d347d26cc92")
