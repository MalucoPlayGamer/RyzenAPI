-- Lua provided by RyzenAPI
-- Game: FATAL FRAME / PROJECT ZERO: Mask of the Lunar Eclipse

-- MAIN APPLICATION
addappid(2130460)
addappid(2257210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130461, 1, "ebca96a0f4137d2bb98654148efb453f475b6f091226288bdf31d232a41b7c01")
addappid(2257211, 1, "2b8fa2b81702ac842fbabc262af0a425b1cbd3d4cc2517b33217d654b3a2e19f")
addappid(2257212, 1, "6a3c1c642b13e73002c765f0411d7162b6684697950c82f12b0364706ba6deab")
addappid(2257213, 1, "08baa8a0787b02119e8c8723cb9696d781d91c742f1f0bb8b425a41567aee835")
addappid(2257214, 1, "1cf2f80cdfae6511f1e0b872b9c1b16349c20f4cb9ee6c846a70cefdc520b723")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
