-- Lua provided by RyzenAPI
-- Game: Switch 'N' Shoot

-- MAIN APPLICATION
addappid(498470)

-- MAIN APP DEPOTS / PACKAGES
addappid(498472,0,"6aba31e6e18ce4a0a7af404aa2e2064a4bd20d1c0384707804106b82d48c004c")
