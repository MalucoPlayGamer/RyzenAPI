-- Lua provided by RyzenAPI
-- Game: Game: AppID 716110

-- MAIN APPLICATION
addappid(716110)
-- Game: addappid(716110)

-- MAIN APP DEPOTS / PACKAGES
addappid(716111, 1, "40ef0b2010c59d57801cce83044d6dbf20aa71dd4665d5066b0a344767e48483")
