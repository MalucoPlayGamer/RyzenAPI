-- Lua provided by SkyAPI 
-- Game: AppID 716110
addappid(716110)
addappid(716111, 1, "40ef0b2010c59d57801cce83044d6dbf20aa71dd4665d5066b0a344767e48483")
