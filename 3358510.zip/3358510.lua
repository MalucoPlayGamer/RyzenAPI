-- Lua provided by RyzenAPI
-- Game: 再刷一把2：金色传说

-- MAIN APPLICATION
addappid(3358510)
addappid(3427100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358511, 1, "5fdfeef6973a4e678cbdecbf4e0e1fd9f41e2fc6b37c7926bd7b61b3df165e27")

