-- Lua provided by RyzenAPI
-- Game: YORG.io 3

-- MAIN APPLICATION
addappid(1134480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134482,0,"42923c105c9230137a7b9ba5eff4e01cfa6a4b1f828ef89d9768092b4eeeed9b")

