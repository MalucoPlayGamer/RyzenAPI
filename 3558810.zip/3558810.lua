-- Lua provided by RyzenAPI
-- Game: South of Midnight Original Soundtrack

-- MAIN APPLICATION
addappid(3558810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558811, 1, "678be8b914133c73b665cea06ab2d2e9d208b0eba0f9e2d06312353dc31d1b0b")
addappid(3558812, 1, "f631398c880fb244d758adc51880b4fb9d4f0f86fef45923385963ee0d3c5ca7")
