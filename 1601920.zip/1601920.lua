-- Lua provided by RyzenAPI
-- Game: addappid(1601920)

-- MAIN APPLICATION
addappid(1601920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601921, 1, "1156b5d507e85adacbccca78158e27a3fa32f34ef6a8b11c431dc18b9cf10739")
