-- Lua provided by SkyAPI 
-- Game: ROBOTICS;NOTES ELITE
addappid(1111380)
addappid(1111381, 1, "a4050788ae1a4c19f5985179ff944475aba605ea80634df00a2ffec33d74747c")
addappid(1111382, 1, "e8e53eaf26b2353debd73cdc4de3c9b3c3ba82c0a50445581d6de66955ffbca5")
addappid(1111383, 1, "8d3ca45368170b808ba3a4fd6e9865b9b615ee47e7a6bba3c430cf512b38b1f0")
