-- Lua provided by RyzenAPI
-- Game: 3180510

-- MAIN APPLICATION
addappid(3180510)
-- Game: addappid(3180510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180511, 1, "1c4106a4b588ad71a7af7206ce632621ff9d0234c9b6f0ed19fecd84bdb60285")
