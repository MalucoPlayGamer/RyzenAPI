-- Lua provided by RyzenAPI
-- Game: 936980

-- MAIN APPLICATION
addappid(936980)
-- Game: addappid(936980)

-- MAIN APP DEPOTS / PACKAGES
addappid(936981, 1, "5db4e2a9adadb904f278f4eb511f46c790f126df4b518f46b6b2c576624ba618")
