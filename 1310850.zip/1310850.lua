-- Lua provided by RyzenAPI
-- Game: Game: Gori: Cuddly Carnage Demo

-- MAIN APPLICATION
addappid(1310850)
-- Game: addappid(1310850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310851, 1, "a1b7e93b600dd55d4f140157a28b32100211fc677e043584879faf93e0c90836")
