-- Lua provided by RyzenAPI
-- Game: I Just Want to be Single!! Season One

-- MAIN APPLICATION
addappid(1703610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703611, 1, "bd1ba81f8a697d83bd77e64154e1cd0ba869434ba3e573ec00bf0fddab30779a")

