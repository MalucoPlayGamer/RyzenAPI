-- Lua provided by SkyAPI 
-- Game: Dying Night SEX with ZOMBI
addappid(1879180)
addappid(1879181, 1, "05f8af91783a216f5aac164c4cb249edb48285a9f6e58a4239f2864a64135658")
