-- Lua provided by RyzenAPI
-- Game: Game: Hammerheart

-- MAIN APPLICATION
addappid(1699280)
-- Game: addappid(1699280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699281, 1, "b707430ba06f163114cf1eb0a7b04d35f1dee27f84aa8c05a324c72d23ba7b8e")
