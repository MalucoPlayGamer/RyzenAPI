-- Lua provided by RyzenAPI 
-- Game: BBQ Simulator: The Squad
addappid(1755350)
addappid(1755351, 1, "947aa7f11f43709163732995bfbb21053b73e11053d44662a2b29729189aa446")
addappid(1755352, 1, "9d884f494bee0fd94a7b962046d19e543616cab793d54b140413082d84d008b9")
