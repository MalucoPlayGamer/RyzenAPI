-- Lua provided by RyzenAPI
-- Game: addappid(2851610)

-- MAIN APPLICATION
addappid(2851610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2851611, 1, "fcaf0358ebde409090f7ab373a7e80b626fb879fed9d822dc7d5c00600094ad8")
