-- Lua provided by RyzenAPI
-- Game: 33650

-- MAIN APPLICATION
addappid(33650)
-- Game: addappid(33650)

-- MAIN APP DEPOTS / PACKAGES
addappid(33651, 1, "0907e7c4abae0b8bf9cc1440a2b440642a76699010c2ce7011780a1bf25b4a5b")
