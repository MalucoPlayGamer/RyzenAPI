-- Lua provided by RyzenAPI
-- Game: AppID 2576240

-- MAIN APPLICATION
addappid(2576240)
-- Game: addappid(2576240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576241, 1, "ad955a1e0347e84ba4691a45d642a33adbb1bf77d203dc8de75d494ff1787891")
