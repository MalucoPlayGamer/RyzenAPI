-- Lua provided by RyzenAPI
-- Game: Eraser

-- MAIN APPLICATION
addappid(1819570)
addappid(4682370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819571, 1, "5ae92d94fb4628afd3d300a4e30b0228395d02723eab70c0dca8d14500b58165")
