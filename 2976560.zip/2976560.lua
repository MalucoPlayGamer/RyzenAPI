-- Lua provided by RyzenAPI
-- Game: Game: AppID 2976560

-- MAIN APPLICATION
addappid(2976560)
-- Game: addappid(2976560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976561, 1, "90e2b4eb3c0943a41ec5e5c5e02b4690d1f9fed54cc7bd2b66ff2a528ece3dba")
