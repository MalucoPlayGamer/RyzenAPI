-- Lua provided by RyzenAPI
-- Game: addappid(1028090)

-- MAIN APPLICATION
addappid(1028090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028091, 1, "9afafbd2016331b0630043415031e3921108f59ce8ffb1d71e0b17fd11b005ce")
