-- Lua provided by RyzenAPI
-- Game: Orenji-iro no Kumo

-- MAIN APPLICATION
addappid(1711960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711961, 1, "93c709e283e5156320915276c61b17e2462092f2da1081c68d6aca433ee174f0")
