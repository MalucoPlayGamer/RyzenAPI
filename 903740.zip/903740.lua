-- Lua provided by RyzenAPI
-- Game: Kings

-- MAIN APPLICATION
addappid(903740)

-- MAIN APP DEPOTS / PACKAGES
addappid(903741, 1, "08eb44a1448b38eab606ed112a919a71f22f7f2ddd8c3946a7ec20d15bb941df")

