-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Sex Institute

-- MAIN APPLICATION
addappid(3164970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164971, 1, "9d0b0936f8e8328ed047cc9deac286a854f24a2d5b5c7c74fdaa00eafe00b545")
