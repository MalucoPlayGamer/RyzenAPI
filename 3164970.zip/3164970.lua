-- Lua provided by RyzenAPI 
-- Game: Hentai Tales: Sex Institute
addappid(3164970)
addappid(3164971, 1, "9d0b0936f8e8328ed047cc9deac286a854f24a2d5b5c7c74fdaa00eafe00b545")
