-- Lua provided by RyzenAPI
-- Game: Game: Fair and square Demo

-- MAIN APPLICATION
addappid(2638260)
-- Game: addappid(2638260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638261, 1, "de8c9d369cddc376cd51e58a47e2b9f5c462210f9636f7f4356afee8cd4371be")
