-- Lua provided by RyzenAPI
-- Game: 631920

-- MAIN APPLICATION
addappid(631920)
-- Game: addappid(631920)

-- MAIN APP DEPOTS / PACKAGES
addappid(631921, 1, "5c2e31a0390221e50f1ddf636a762d2c440b77c3368db635a4f88d7997167c23")
