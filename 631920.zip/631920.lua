-- Lua provided by RyzenAPI
-- Game: Somewhere on Zibylon

-- MAIN APPLICATION
addappid(631920)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(631921, 1, "5c2e31a0390221e50f1ddf636a762d2c440b77c3368db635a4f88d7997167c23")

