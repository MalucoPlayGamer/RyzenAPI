-- Lua provided by RyzenAPI
-- Game: Operation Satoshi [Early Version Alpha]

-- MAIN APPLICATION
addappid(2135380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135381, 1, "054d6cd5e0c6f4d2c91b4fcf4e291e37f29c304fa5d051d4dc9ae0512e42a1d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
