-- Lua provided by RyzenAPI
-- Game: Game: Operation Satoshi [Early Version Alpha]

-- MAIN APPLICATION
addappid(2135380)
-- Game: addappid(2135380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135381, 1, "054d6cd5e0c6f4d2c91b4fcf4e291e37f29c304fa5d051d4dc9ae0512e42a1d9")
