-- Lua provided by RyzenAPI
-- Game: Brothel of Darkness

-- MAIN APPLICATION
addappid(2289210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2289211, 1, "739dbf585a5f1503dd2930a89e33d02632be230213bd1455b1885b211f3a1e9b")

