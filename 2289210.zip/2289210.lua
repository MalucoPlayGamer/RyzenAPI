-- Lua provided by RyzenAPI
-- Game: Brothel of Darkness

-- MAIN APPLICATION
addappid(2289210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289211, 1, "739dbf585a5f1503dd2930a89e33d02632be230213bd1455b1885b211f3a1e9b")
