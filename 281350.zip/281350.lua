-- Lua provided by RyzenAPI
-- Game: 281350

-- MAIN APPLICATION
addappid(281350)
-- Game: addappid(281350)

-- MAIN APP DEPOTS / PACKAGES
addappid(281351, 1, "d19fc9f952e3279bf86e4b3132900223bf9077eedb213d13628574fd7283208e")
