-- Lua provided by RyzenAPI
-- Game: addappid(2001460)

-- MAIN APPLICATION
addappid(2001460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001464,0,"c3ada279c8eaff0dee75f05992b15cfea1bf34fbe38a2b230f748a40d6031ea6")
