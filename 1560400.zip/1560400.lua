-- Lua provided by RyzenAPI
-- Game: 1560400

-- MAIN APPLICATION
addappid(1560400)
-- Game: addappid(1560400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560401, 1, "0a38d2b7f9ab1a502e1f87a2137bcd224440d36791c9d5f0e23adb2b9d5fee40")
