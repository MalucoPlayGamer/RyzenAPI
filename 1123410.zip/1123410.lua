-- Lua provided by RyzenAPI
-- Game: Tailypo: The Game

-- MAIN APPLICATION
addappid(1123410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1123411, 1, "805cd25968d5dc2c82accc51d22e24140db6bc9f282cc746cc8c8d679c00c495")

