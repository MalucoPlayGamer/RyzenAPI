-- Lua provided by RyzenAPI
-- Game: 1123410

-- MAIN APPLICATION
addappid(1123410)
-- Game: addappid(1123410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123411, 1, "805cd25968d5dc2c82accc51d22e24140db6bc9f282cc746cc8c8d679c00c495")
