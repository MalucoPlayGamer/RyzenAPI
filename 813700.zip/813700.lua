-- Lua provided by RyzenAPI
-- Game: Sakura Sadist

-- MAIN APPLICATION
addappid(813700)
-- Game: addappid(813700)

-- MAIN APP DEPOTS / PACKAGES
addappid(813701, 1, "a9a1b5944ccd762b97df3e320b4e135ed56762c98f200a04bdac38fe0344b36a")
