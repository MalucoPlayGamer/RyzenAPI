-- Lua provided by SkyAPI 
-- Game: Dragon Fin Soup
addappid(299600)
addappid(299601, 1, "1e82d14eed8bf1ab02cf03b56971f4f06e3f43fb6d6d3ac657124c5931b0c396")
addappid(299602, 1, "5fcd8e8513ab3ce87a66bd2eff8f27f08c7da614bd0d526a77373cd81de9cb3e")
