-- Lua provided by RyzenAPI
-- Game: Dragon Fin Soup

-- MAIN APPLICATION
addappid(299600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(299601, 1, "1e82d14eed8bf1ab02cf03b56971f4f06e3f43fb6d6d3ac657124c5931b0c396")
addappid(299602, 1, "5fcd8e8513ab3ce87a66bd2eff8f27f08c7da614bd0d526a77373cd81de9cb3e")

