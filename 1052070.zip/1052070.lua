-- Lua provided by RyzenAPI
-- Game: Burning Daylight

-- MAIN APPLICATION
addappid(1052070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1052071, 1, "cf30bde96f6c6ab4256abcb5af85b3f6c63ea763344cf1c025fbed73a0067594")

