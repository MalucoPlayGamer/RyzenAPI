-- Lua provided by RyzenAPI 
-- Game: Burning Daylight
addappid(1052070)
addappid(1052071, 1, "cf30bde96f6c6ab4256abcb5af85b3f6c63ea763344cf1c025fbed73a0067594")
