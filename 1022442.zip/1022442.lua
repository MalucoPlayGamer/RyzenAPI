-- Lua provided by RyzenAPI
-- Game: addappid(1022442)

-- MAIN APPLICATION
addappid(1022442)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022442,0,"59929ef44bbceac94db18ba8d1421fe3dde75cc72044003b0991bab257d4c247")
