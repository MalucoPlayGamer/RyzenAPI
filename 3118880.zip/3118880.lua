-- Lua provided by RyzenAPI
-- Game: Strike Mission

-- MAIN APPLICATION
addappid(3118880)
-- Game: addappid(3118880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118881, 1, "e6d07c8c31f3443a89c8ef0de55e7bc4d7953db97ce48abfff82d645dfa54ecd")
