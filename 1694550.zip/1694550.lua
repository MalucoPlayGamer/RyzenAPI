-- Lua provided by RyzenAPI
-- Game: Game: Hype Prototype

-- MAIN APPLICATION
addappid(1694550)
-- Game: addappid(1694550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694551, 1, "ce413365bb22334bf391d218f62862e2dae55b0b00e60da23bbead102929dee6")
