-- Lua provided by RyzenAPI
-- Game: Deadly Escape

-- MAIN APPLICATION
addappid(649450)

-- MAIN APP DEPOTS / PACKAGES
addappid(649451, 1, "ebe1e9152006c868e185a3bbe6bba118f56a266c6798c949d76a1dc59f61a84b")
addappid(649452, 1, "c9fcf3563ed068f0180f906d723f3f9a0b8121c271ff5975a4ab7765fb3f70a2")
addappid(649453, 1, "b656a195099df4d753e49672fc64fc1ac5f38179ebccade58ad9d1b17c0e082e")

