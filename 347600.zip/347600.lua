-- Lua provided by SkyAPI 
-- Game: Total Miner
addappid(347600)
addappid(347601, 1, "94d9be0c54d11c964f9a4587dfea87b667136c56b873e256cb5f45582acedba2")
