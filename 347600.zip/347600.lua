-- Lua provided by RyzenAPI
-- Game: Total Miner

-- MAIN APPLICATION
addappid(347600)
-- Game: addappid(347600)

-- MAIN APP DEPOTS / PACKAGES
addappid(347601, 1, "94d9be0c54d11c964f9a4587dfea87b667136c56b873e256cb5f45582acedba2")
