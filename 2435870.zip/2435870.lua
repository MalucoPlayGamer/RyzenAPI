-- Lua provided by RyzenAPI
-- Game: Blood Rush

-- MAIN APPLICATION
addappid(2435870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435871, 1, "40cacec5f8ff0cf28adc92712f67f941864cd92948f40d46ecb1f6db6d557578")
