-- Lua provided by RyzenAPI
-- Game: Cartel Tycoon Demo

-- MAIN APPLICATION
addappid(1321750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321751, 1, "74e1464d63449163e3d30d77f3a676cba25daf677c99faa97744f1637d4eb0bd")

