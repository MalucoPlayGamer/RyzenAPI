-- Lua provided by RyzenAPI
-- Game: CLANNAD

-- MAIN APPLICATION
addappid(324160)
addappid(509080)
-- Game: addappid(324160)

-- MAIN APP DEPOTS / PACKAGES
addappid(324161, 1, "cceaefea70200c5d9e6200661064d3f4bde2894727f071d4b5fa36f31ddcad2b")
addappid(324163, 1, "283cd6f1bfc6a44cfab2d56951b826b2f89b2c99091dbeb76f50f1ddbddc9c8c")
addappid(509081, 0, "665ab0db87bcf73b830feaa76ca6c8b9acb067ba4ef39dd005d444527125a376")
addappid(519110, 0, "2706a2712987f5edf16fd8293508ab25151efc5f09ca6a0180344280a0342b58")
addappid(615930, 0, "7569614c34e7f7b946e6d61307a64d92167b333e784f4eaf6cc976a6e3ee698d")
