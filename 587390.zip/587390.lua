-- Lua provided by RyzenAPI
-- Game: LOR - League of Runners

-- MAIN APPLICATION
addappid(587390)

-- MAIN APP DEPOTS / PACKAGES
addappid(587391, 1, "d73137f0ddc677b3c879f98e7addb76528859e03402906ec2915803135c5db62")
