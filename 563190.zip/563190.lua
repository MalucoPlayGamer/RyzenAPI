-- Lua provided by RyzenAPI
-- Game: Game: de Blob 2

-- MAIN APPLICATION
addappid(563190)
-- Game: addappid(563190)

-- MAIN APP DEPOTS / PACKAGES
addappid(563191, 1, "a5004b48c0231a7071930672acd5c9bd371dd687a4979c5c592fb799c529ee62")
addappid(563192, 1, "f5b0da76a7bddeb15f3acfd36a8f80140e7ccb5362c69f948c138eea273adec8")
