-- Lua provided by RyzenAPI
-- Game: de Blob 2

-- MAIN APPLICATION
addappid(563190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(563191, 1, "a5004b48c0231a7071930672acd5c9bd371dd687a4979c5c592fb799c529ee62")
addappid(563192, 1, "f5b0da76a7bddeb15f3acfd36a8f80140e7ccb5362c69f948c138eea273adec8")

