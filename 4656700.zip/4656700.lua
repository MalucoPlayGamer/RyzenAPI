-- Lua provided by RyzenAPI 
-- Game: Papa's Mocharia Deluxe
addappid(4656700)
addappid(4656701, 1, "95c3806712adc95912910209aabbded33f41430317c35564a7a787919b856f88")
