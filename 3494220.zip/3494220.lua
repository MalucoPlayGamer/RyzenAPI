-- Lua provided by RyzenAPI
-- Game: addappid(3494220)

-- MAIN APPLICATION
addappid(3494220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3494221, 1, "4d95f11249a26f90688005f4fcd4ee19065e152ba1f732ef2e6325a72ba142f3")
