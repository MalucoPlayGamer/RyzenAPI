-- Lua provided by RyzenAPI
-- Game: setManifestid(1009232,"4963629903546508977")

-- MAIN APPLICATION
addappid(1009230)
-- Game: addappid(1009230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009232,0,"d5b3225094f05a184a2609db0b08b8bb000f864f750e4fe8ef2b9e1f72231f8a")
