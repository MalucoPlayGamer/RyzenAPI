-- Lua provided by RyzenAPI
-- Game: Dracula: Love Kills

-- MAIN APPLICATION
addappid(252890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(252891, 1, "9d9691aa04f9b42d3835207e07f1bd05e41a12d2be1bcd5ccb25d058d6e60797")
addappid(252892, 1, "ce5622a20b02e30a7645078251c971d6bf5f5dfb8db4406248b26c46ef1fd61b")
addappid(252893, 1, "9b9765bce79d99fdf4914ead76244304223e3b1b24c579d4ea5f281d3fbbffec")
addappid(252894, 1, "46f3516bdf4071dcea2fe0aa3df75e6ac33f4d7ba021767881205525d9f91d72")

