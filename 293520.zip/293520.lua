-- Lua provided by RyzenAPI
-- Game: Carnivores: Dinosaur Hunter Reborn

-- MAIN APPLICATION
addappid(293520)

-- MAIN APP DEPOTS / PACKAGES
addappid(293521, 1, "a9c628e41963792f4531685616b694e2298bcbf220ea887acf723a47bd444997")
