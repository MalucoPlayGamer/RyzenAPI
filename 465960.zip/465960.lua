-- Lua provided by RyzenAPI
-- Game: AppID 465960

-- MAIN APPLICATION
addappid(465960)
-- Game: addappid(465960)

-- MAIN APP DEPOTS / PACKAGES
addappid(465961, 1, "727c490e7fea1afc40c156f609a1a3731dda17dcaccfdb8e7a0ae73b6ab6d560")
