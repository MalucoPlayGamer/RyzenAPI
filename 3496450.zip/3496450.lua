-- Lua provided by RyzenAPI
-- Game: addappid(3496450)

-- MAIN APPLICATION
addappid(3496450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3496451, 1, "b1752e3582ba1ee1990094586aebb74fe95b941d99611130cfc9450f7313da4d")
