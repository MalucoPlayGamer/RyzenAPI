-- Lua provided by RyzenAPI
-- Game: Indiana Jones and the Great Circle - Digital Artbook

-- MAIN APPLICATION
addappid(2832900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832901, 1, "71580c3b9c67dd7593e249fb5f670b3481755ab2bbdb5cb0d6656f6f9ed45234")
