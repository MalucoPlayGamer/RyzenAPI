-- Lua provided by RyzenAPI
-- Game: addappid(2832900)

-- MAIN APPLICATION
addappid(2832900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832901, 1, "71580c3b9c67dd7593e249fb5f670b3481755ab2bbdb5cb0d6656f6f9ed45234")
