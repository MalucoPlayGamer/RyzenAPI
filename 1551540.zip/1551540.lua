-- Lua provided by RyzenAPI 
-- Game: Tower of Ardia
addappid(1551540)
addappid(1551541, 1, "a4e0222f7f21f4fc736379c53704caf7a4143c972a79cb269fd24d02e772d724")
addappid(1551542, 1, "4dce358d1391851f340efe80aa660686fbd2f5bbfcf6674b626c2d864287c93c")
addappid(1551543, 1, "63e883ec5dc30abc8f94a78eecafa0d96a9339c982e7147dec2e072c6f63cf7f")
