-- Lua provided by RyzenAPI
-- Game: 2021480

-- MAIN APPLICATION
addappid(2021480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021482,0,"dcea961c38c09e33fe9807f52d6da5b2dfb286c1971e1a2a81c3fdad6ecb050e")

