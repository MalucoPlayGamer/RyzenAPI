-- Lua provided by RyzenAPI
-- Game: Game: AppID 414530

-- MAIN APPLICATION
addappid(414530)
-- Game: addappid(414530)

-- MAIN APP DEPOTS / PACKAGES
addappid(414531, 1, "008780c4aa58b006857573dfded675a6d7d1b692962c51b883444b897b3afecb")
