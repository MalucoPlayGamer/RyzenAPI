-- Lua provided by RyzenAPI
-- Game: AppID 414530

-- MAIN APPLICATION
addappid(414530)

-- MAIN APP DEPOTS / PACKAGES
addappid(414531, 1, "008780c4aa58b006857573dfded675a6d7d1b692962c51b883444b897b3afecb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(546370)
addappid(546371)
addappid(546372)
addappid(546373)
addappid(546374)
addappid(602750)
addappid(695670)
addappid(695671)
addappid(825090)
addappid(995030)
addappid(1050780)
addappid(1150320)
addappid(1651120)
addappid(1780910)
