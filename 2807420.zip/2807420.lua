-- Lua provided by RyzenAPI
-- Game: addappid(2807420)

-- MAIN APPLICATION
addappid(2807420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807421, 1, "bf6c3e6397cdaeac09d2b290125ef8a3f1e7723032662993a1b8a42edc1521fd")
