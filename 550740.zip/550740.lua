-- Lua provided by RyzenAPI
-- Game: Battles of the Valiant Universe CCG

-- MAIN APPLICATION
addappid(550740)

-- MAIN APP DEPOTS / PACKAGES
addappid(550742,0,"32c189924b4b468032025d787bbdf094038a228a643578d80ab95d8cd4cfd295")
addappid(550744,0,"6d43677b52a63f24f56d1fda0fcca90feff58fbbd6960e4335afa855a549efbd")

