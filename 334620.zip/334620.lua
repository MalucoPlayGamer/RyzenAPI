-- Lua provided by RyzenAPI
-- Game: AppID 334620

-- MAIN APPLICATION
addappid(334620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(334621, 1, "2962bfebf46c1b5dd73e476ee141217ed62be95b05ef87f3ab00ba5f338e0245")
addappid(334622, 1, "89fd1db76908dbf4bea3ba3558ff0e3816166e015fec26a4fb4f05fa0b266527")
addappid(334623, 1, "e87ed858459610b41e36d03277fafb71a1a8f460b116ea115a3a16c2187624cd")

