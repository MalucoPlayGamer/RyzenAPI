-- Lua provided by RyzenAPI
-- Game: Fumiko!

-- MAIN APPLICATION
addappid(563810)

-- MAIN APP DEPOTS / PACKAGES
addappid(563811, 1, "bdab1b85b63f539d2e0dd9d685c24d0446e6f483b71936e96063897ecc9f7ba6")
addappid(563812, 1, "2e69e84cc49d65a31b12a69587a8280bebca74e4da75b467aaec6826359be81f")
addappid(563813, 1, "e14e72b5b8cbf9d03d5f02be7a4dfab99d765fe653e3df3242b7bcff34a5d86d")
addappid(563814, 1, "0f27515b1e2aa4cc780965c9f331c2cb9e80f2241608cb1347c5bc55bb19ca38")

