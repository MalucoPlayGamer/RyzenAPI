-- Lua provided by RyzenAPI
-- Game: Game: Hentai Abigail

-- MAIN APPLICATION
addappid(2530730)
-- Game: addappid(2530730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530731, 1, "5e41088bb7e91c5eed8fac1bc78b9107611531217d67c48f7bcd4924f61663a5")
