-- Lua provided by RyzenAPI
-- Game: Ogre Tale

-- MAIN APPLICATION
addappid(1124050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1124051, 1, "1e66df5ba20cd09d78a2926dfb3655605f45a0371aa9e4fa2318ba860b8942b3")

