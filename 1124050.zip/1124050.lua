-- Lua provided by RyzenAPI
-- Game: addappid(1124050)

-- MAIN APPLICATION
addappid(1124050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124051, 1, "1e66df5ba20cd09d78a2926dfb3655605f45a0371aa9e4fa2318ba860b8942b3")
