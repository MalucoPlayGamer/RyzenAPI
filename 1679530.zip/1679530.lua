-- Lua provided by RyzenAPI
-- Game: SYDE Rugby League Simulator

-- MAIN APPLICATION
addappid(1679530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1679531, 1, "cc4b190563907aea6d26d1811b2f56ccfcd6047e0a7e2192dbe9d76afd9fe317")

