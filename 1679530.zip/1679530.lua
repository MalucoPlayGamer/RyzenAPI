-- Lua provided by RyzenAPI
-- Game: 1679530

-- MAIN APPLICATION
addappid(1679530)
-- Game: addappid(1679530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679531, 1, "cc4b190563907aea6d26d1811b2f56ccfcd6047e0a7e2192dbe9d76afd9fe317")
