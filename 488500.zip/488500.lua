-- Lua provided by RyzenAPI
-- Game: The book of commands : Lost Symbol

-- MAIN APPLICATION
addappid(488500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)
addappid(488501, 1, "ef5387490306950f760e17b1fdd04787ce8f6e58033774fefc8bbef02abc2bbc")
addappid(488502, 1, "1aacdbbce8973c03c78066fb9e5ab2f0584f8a17b345fe57e49c048ab19e829c")

