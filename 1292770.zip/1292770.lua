-- Lua provided by RyzenAPI
-- Game: Grisaia Phantom Trigger Vol.7

-- MAIN APPLICATION
addappid(1292770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1292771, 1, "c19627142d4edd8f57c288bd4b4cc7f7ef3a2aa69e1b4ecb2a7b7615a60e5f19")
addappid(1292772, 1, "fffa3ef33792c07beda71dde343c9874e074760bca7f216ffab2f461f442eb50")
