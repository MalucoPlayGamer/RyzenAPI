-- Lua provided by RyzenAPI
-- Game: AppID 1292770

-- MAIN APPLICATION
addappid(1292770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292771, 1, "c19627142d4edd8f57c288bd4b4cc7f7ef3a2aa69e1b4ecb2a7b7615a60e5f19")
addappid(1292772, 1, "fffa3ef33792c07beda71dde343c9874e074760bca7f216ffab2f461f442eb50")

