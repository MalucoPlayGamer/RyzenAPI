-- Lua provided by RyzenAPI
-- Game: Zleepy

-- MAIN APPLICATION
addappid(1701320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1701321, 1, "5035c5739105ae607fdf0524becea1d6967307b979c94a821b13b44933627206")

