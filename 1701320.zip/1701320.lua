-- Lua provided by RyzenAPI
-- Game: Game: Zleepy

-- MAIN APPLICATION
addappid(1701320)
-- Game: addappid(1701320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701321, 1, "5035c5739105ae607fdf0524becea1d6967307b979c94a821b13b44933627206")
