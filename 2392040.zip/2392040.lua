-- Lua provided by RyzenAPI
-- Game: Game: Antbassador

-- MAIN APPLICATION
addappid(2392040)
-- Game: addappid(2392040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392041, 1, "3e0c0e21c60f6e65c6ef28da3af2ce7bfb1f162f316001b2e7df65c8da5ce1f2")
