-- Lua provided by RyzenAPI
-- Game: Antbassador

-- MAIN APPLICATION
addappid(2392040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2392041, 1, "3e0c0e21c60f6e65c6ef28da3af2ce7bfb1f162f316001b2e7df65c8da5ce1f2")

