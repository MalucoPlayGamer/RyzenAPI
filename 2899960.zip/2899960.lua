-- Lua provided by RyzenAPI
-- Game: addappid(2899960)

-- MAIN APPLICATION
addappid(2899960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899961, 1, "8bd3b25ff1026f53aba2b00d750672a928a7e1041e305b8ff2106f5a845fa388")
