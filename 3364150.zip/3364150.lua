-- 3364150's Lua and Manifest Created by Hubcap Manifest
-- Whack A Monster
-- Created: July 28, 2026 at 14:07:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3364150) -- Whack A Monster
-- MAIN APP DEPOTS
addappid(3364151, 1, "1709862a74e84c69535ad09e243431d0690c703942271319bd4aa44eb01ee1bc") -- Depot 3364151
setManifestid(3364151, "3489114944763652395", 327206835)