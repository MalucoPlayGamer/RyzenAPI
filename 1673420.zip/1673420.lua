-- Lua provided by RyzenAPI
-- Game: Game: AppID 1673420

-- MAIN APPLICATION
addappid(1673420)
-- Game: addappid(1673420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673421, 1, "7db19a0ac7392cd948eaaea7cb08593d1d379c1c312670159ac97c0cf919c605")
