-- Lua provided by RyzenAPI
-- Game: Game: Black Jack Story

-- MAIN APPLICATION
addappid(831060)
-- Game: addappid(831060)

-- MAIN APP DEPOTS / PACKAGES
addappid(831061, 1, "d419d402b5168fab8a0b7b263144d3bdcda97896b25e861c5f6ec18fd04379aa")
