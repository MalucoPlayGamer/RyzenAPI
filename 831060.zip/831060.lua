-- Lua provided by RyzenAPI 
-- Game: Black Jack Story
addappid(831060)
addappid(831061, 1, "d419d402b5168fab8a0b7b263144d3bdcda97896b25e861c5f6ec18fd04379aa")
