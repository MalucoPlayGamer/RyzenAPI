-- Lua provided by SkyAPI 
-- Game: Sin-Cay
addappid(1680440)
addappid(1680441, 1, "26292699dfbb140a3b4065a2abf3c4952240558212005a7e3d9bf07565408cee")
