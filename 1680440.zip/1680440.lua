-- Lua provided by RyzenAPI
-- Game: Sin-Cay

-- MAIN APPLICATION
addappid(1680440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680441, 1, "26292699dfbb140a3b4065a2abf3c4952240558212005a7e3d9bf07565408cee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
