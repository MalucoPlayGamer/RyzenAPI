-- Lua provided by RyzenAPI
-- Game: County Hospital Cautery Demo

-- MAIN APPLICATION
addappid(3106920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106921, 1, "dc35ab4923ca5b4e5635eeb48d519b9b56a1a2c82002e62c2e53b0ed4b1f61c8")

