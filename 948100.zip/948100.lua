-- Lua provided by RyzenAPI
-- Game: ニンジャスレイヤー : AREA 4643

-- MAIN APPLICATION
addappid(948100)

-- MAIN APP DEPOTS / PACKAGES
addappid(948101, 1, "a4c12b9381a03b18adcb249fd2a347316c46189a10eca315ec56691e7d6cedd6")

