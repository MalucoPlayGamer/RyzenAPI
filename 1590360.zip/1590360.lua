-- Lua provided by RyzenAPI
-- Game: He Needs His Medicine

-- MAIN APPLICATION
addappid(1590360)
-- Game: addappid(1590360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590361, 1, "340878060c53b8c564216f3f2a0f875ae301fd0d9aaa94119393c9ea98711ac5")
addappid(1590362, 1, "784dbe2823d84d57e5deb1d218b37f4df2483cbd412df99abc6ce997ef4dce7a")
addappid(1590363, 1, "6da2f1899fd6170395fa4f9a7c262c77a4b3ee04ba24565c931ae7f71e254f4c")
