-- Lua provided by RyzenAPI
-- Game: KartKraft

-- MAIN APPLICATION
addappid(406350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(406351, 1, "1bea1168a0a4cf6c8c3079ad6cde520c8802342bd0a0e828a93ddc86eaf4b3a7")

