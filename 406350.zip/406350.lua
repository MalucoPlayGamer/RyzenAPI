-- Lua provided by RyzenAPI
-- Game: AppID 406350

-- MAIN APPLICATION
addappid(406350)
-- Game: addappid(406350)

-- MAIN APP DEPOTS / PACKAGES
addappid(406351, 1, "1bea1168a0a4cf6c8c3079ad6cde520c8802342bd0a0e828a93ddc86eaf4b3a7")
