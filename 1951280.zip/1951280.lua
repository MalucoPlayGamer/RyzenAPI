-- Lua provided by RyzenAPI
-- Game: Jerez's Arena Ⅱ - Digital Artbook

-- MAIN APPLICATION
addappid(1951280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951280,0,"10967ec356455cfc03f27c153f9066c642759c11baf56cc00c8ba13e09919e9f")
