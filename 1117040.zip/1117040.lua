-- Lua provided by RyzenAPI
-- Game: 1117040

-- MAIN APPLICATION
addappid(1117040)
addappid(1138480)
-- Game: addappid(1117040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117041, 1, "b429d6341a3c1a29d8cd2ee60ba94973d582a517ca6ca7e1aa70123fe654e35d")
