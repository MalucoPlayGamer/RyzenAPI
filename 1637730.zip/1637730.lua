-- Lua provided by RyzenAPI
-- Game: addappid(1637730)

-- MAIN APPLICATION
addappid(1637730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637731, 1, "f06b86efa80e91c62751dbacc194e6d32c43928ab5e727d3125b097d38465bcd")
