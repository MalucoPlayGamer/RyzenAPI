-- Lua provided by RyzenAPI
-- Game: Crystal Project

-- MAIN APPLICATION
addappid(1637730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637731, 1, "f06b86efa80e91c62751dbacc194e6d32c43928ab5e727d3125b097d38465bcd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
