-- Lua provided by RyzenAPI
-- Game: Pinchcliffe Grand Prix

-- MAIN APPLICATION
addappid(1668080)
addappid(3607210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1668081, 1, "2a24f7b86849f4c000de5d70068e8cf375e62eb26588b69659c24357ef167911")

