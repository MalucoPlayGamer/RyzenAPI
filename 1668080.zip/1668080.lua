-- Lua provided by SkyAPI 
-- Game: Pinchcliffe Grand Prix
addappid(1668080)
addappid(1668081, 1, "2a24f7b86849f4c000de5d70068e8cf375e62eb26588b69659c24357ef167911")
addappid(3607210)
