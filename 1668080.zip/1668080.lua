-- Lua provided by RyzenAPI
-- Game: Pinchcliffe Grand Prix

-- MAIN APPLICATION
addappid(1668080)
addappid(3607210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668081, 1, "2a24f7b86849f4c000de5d70068e8cf375e62eb26588b69659c24357ef167911")
