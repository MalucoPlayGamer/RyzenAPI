-- Lua provided by RyzenAPI
-- Game: Open The Gates!

-- MAIN APPLICATION
addappid(1332450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332451, 1, "fe8c71932038ad9cfda1326652a7dae837178d200f11bc9047ce96bc579bd9a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
