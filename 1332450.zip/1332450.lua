-- Lua provided by RyzenAPI 
-- Game: Open The Gates!
addappid(1332450)
addappid(1332451, 1, "fe8c71932038ad9cfda1326652a7dae837178d200f11bc9047ce96bc579bd9a5")
