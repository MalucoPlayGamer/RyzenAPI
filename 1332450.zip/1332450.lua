-- Lua provided by RyzenAPI
-- Game: 1332450

-- MAIN APPLICATION
addappid(1332450)
-- Game: addappid(1332450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332451, 1, "fe8c71932038ad9cfda1326652a7dae837178d200f11bc9047ce96bc579bd9a5")
