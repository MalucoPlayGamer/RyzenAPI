-- Lua provided by RyzenAPI
-- Game: addappid(2180340)

-- MAIN APPLICATION
addappid(2180340)
addappid(3222700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180341, 1, "b06b675177eaea9c518bc577e7a3cc94ebc9856603ba5009e0eb3d4589c54e05")
