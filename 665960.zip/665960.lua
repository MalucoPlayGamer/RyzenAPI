-- Lua provided by RyzenAPI
-- Game: Lobster Empire

-- MAIN APPLICATION
addappid(665960)
-- Game: addappid(665960)

-- MAIN APP DEPOTS / PACKAGES
addappid(665961, 1, "d067e010a66ced0131bd25a01fc794148907f27121db0b93ce69a2facc8f4600")
