-- Lua provided by RyzenAPI
-- Game: 1024430

-- MAIN APPLICATION
addappid(1024430)
-- Game: addappid(1024430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024431, 1, "9712ba190e933239db8257082a4dd989b54f879c78ca8272bbbccf0033a5e7ea")
