-- Lua provided by RyzenAPI
-- Game: Super Arcade Soccer

-- MAIN APPLICATION
addappid(1024430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024431, 1, "9712ba190e933239db8257082a4dd989b54f879c78ca8272bbbccf0033a5e7ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
