-- Lua provided by RyzenAPI
-- Game: Hopalong: The Badlands

-- MAIN APPLICATION
addappid(555600)
-- Game: addappid(555600)

-- MAIN APP DEPOTS / PACKAGES
addappid(555601, 1, "8860c2bcfeef08471b9ef33c409dae6770e256d38bbe67d6ced7d8ca5de130bc")
