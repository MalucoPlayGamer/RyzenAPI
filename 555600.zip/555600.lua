-- Lua provided by SkyAPI 
-- Game: Hopalong: The Badlands
addappid(555600)
addappid(555601, 1, "8860c2bcfeef08471b9ef33c409dae6770e256d38bbe67d6ced7d8ca5de130bc")
