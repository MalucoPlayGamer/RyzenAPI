-- Lua provided by RyzenAPI
-- Game: The Complex: Expedition

-- MAIN APPLICATION
addappid(2172260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2172261, 1, "83d83ec58cff9c5a8d4a6c3d49ff5bf3bbd73d72cf9f5fd84508d69d716c5748")

