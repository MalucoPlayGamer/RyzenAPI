-- Lua provided by RyzenAPI
-- Game: Idle Waters

-- MAIN APPLICATION
addappid(2963540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963542,0,"b70785d2f4af67dca603cb2d6679c0c433542623c55fc6f360b8acce351a5a70")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3769100)
