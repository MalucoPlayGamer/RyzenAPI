-- Lua provided by RyzenAPI
-- Game: Touhou: New World

-- MAIN APPLICATION
addappid(2150660)
addappid(2487830)
addappid(3010750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2150661, 1, "1f44dfd64420a36c7fb675c7de8e09684b7d246ce5383e22ab7ecb0c77895cdb")

