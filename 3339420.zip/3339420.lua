-- Lua provided by RyzenAPI
-- Game: addappid(3339420)

-- MAIN APPLICATION
addappid(3339420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339421, 1, "1598c7432d564705f346ee3e22d08d65692a8badf2e71f02e88ad3cd003a42f0")
