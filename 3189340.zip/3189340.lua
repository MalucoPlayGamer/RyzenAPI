-- Lua provided by RyzenAPI
-- Game: addappid(3189340)

-- MAIN APPLICATION
addappid(3189340)
addappid(3903790)
addappid(3903810)
addappid(3903820)
addappid(3903840)
addappid(3903850)
addappid(3934300)
addappid(3934310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3189341, 1, "a66e8b6b64b8fef0f47e81085fd6ec2b5065b00430f881d9cbae78d04338a6f7")
