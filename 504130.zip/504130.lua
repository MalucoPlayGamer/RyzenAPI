-- Lua provided by RyzenAPI
-- Game: Manual Samuel - Last Tuesday Edition

-- MAIN APPLICATION
addappid(504130)

-- MAIN APP DEPOTS / PACKAGES
addappid(504131, 1, "220064b93804e73f1790909d8988c139ed1582f73c04fac674b0a33e29d2e141")
addappid(504132, 1, "fd084af23a8b89b37907b159cd4867c15cd23a2d5fd9d8e03dae9b0a4f6f5331")
addappid(504133, 1, "fc9ef2baafa4a13347d5ebf54b7e68ad4119f6bc4b547a215b840fafe9a4c204")
addappid(504134, 1, "df4ebdaca129cd492e3376950a4a9163cd6792b1538242d0db2cf5515fa5dba6")
addappid(536760, 0, "0944690797f243f9f7c0ceeadc4923a98f81c0af8f193a50a506eb7c9312a2d5")

