-- Lua provided by RyzenAPI
-- Game: 国際指定怪異124号 東京廃村

-- MAIN APPLICATION
addappid(2563160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563161, 1, "0d4da97d3f8fe0b79d9d605aa713d43a1a141da333bec9f0f87cf77e06e15a94")

