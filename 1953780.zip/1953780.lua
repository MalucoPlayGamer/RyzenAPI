-- Lua provided by RyzenAPI
-- Game: Purrrfect Love

-- MAIN APPLICATION
addappid(1953780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953781, 1, "1ae516ef0c808e8570f31c775c6020dd2a1626676c2e4a7508ae83c795262e22")

