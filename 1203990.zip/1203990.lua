-- Lua provided by SkyAPI 
-- Game: AppID 1203990
addappid(1203990)
addappid(1203991, 1, "13e2f5d99913e2eb17ee9b1aa9cf7cbf08d95ea1a8db31eeb042387e88733e7a")
