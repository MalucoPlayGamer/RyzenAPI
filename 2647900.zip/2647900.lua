-- Lua provided by RyzenAPI
-- Game: Seth

-- MAIN APPLICATION
addappid(2647900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2647901,0,"653a6e57a0b7cef4789ab529922f65e4643c6fbda7fbb620306b82a093d321e5")

