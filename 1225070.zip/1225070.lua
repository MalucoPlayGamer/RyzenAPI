-- Lua provided by RyzenAPI
-- Game: Family Mysteries: Poisonous Promises

-- MAIN APPLICATION
addappid(1225070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225071, 1, "286dfad3c13d446144baf36ed18668f1bf2bd72091da0cb909ac6b3b86f2cc4c")
