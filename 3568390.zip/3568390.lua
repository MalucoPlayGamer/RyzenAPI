-- Lua provided by RyzenAPI
-- Game: The Forest Keeper

-- MAIN APPLICATION
addappid(3568390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3568391, 1, "9507290b1805279768eb39905415b2a94d2d32238e76fa2b5dafb57c083844a7")
