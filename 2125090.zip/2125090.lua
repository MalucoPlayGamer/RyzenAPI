-- Lua provided by RyzenAPI
-- Game: addappid(2125090)

-- MAIN APPLICATION
addappid(2125090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125091, 1, "979ee4fcab4ba27bf6ae66d7f30fd6fd4803bad91600833952ce39568bd11e96")
