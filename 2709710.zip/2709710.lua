-- Lua provided by RyzenAPI
-- Game: Succubus 2069

-- MAIN APPLICATION
addappid(2709710) -- Succubus 2069

-- MAIN APP DEPOTS / PACKAGES
addappid(2709711, 1, "6e3902158cc939465100b4b99eca5a63793eab51b01e78ca2743011237fa6af2") -- Depot 2709711

