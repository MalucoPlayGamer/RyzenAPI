-- 2709710's Lua and Manifest Created by Hubcap Manifest
-- Succubus 2069
-- Created: February 16, 2026 at 19:13:54 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2709710) -- Succubus 2069
-- MAIN APP DEPOTS
addappid(2709711, 1, "6e3902158cc939465100b4b99eca5a63793eab51b01e78ca2743011237fa6af2") -- Depot 2709711
setManifestid(2709711, "314950663603642458", 21035022953)