-- 4249850's Lua and Manifest Created by Hubcap Manifest
-- E-Shop Tycoon
-- Created: July 28, 2026 at 11:12:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4249850) -- E-Shop Tycoon
-- MAIN APP DEPOTS
addappid(4249851, 1, "97d1672397100486c472e04fc3a201d94d04224ee65b12a396d63bb7c67547aa") -- Depot 4249851
setManifestid(4249851, "9167159513779867762", 431182962)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)