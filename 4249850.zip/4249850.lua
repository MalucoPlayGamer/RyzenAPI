-- Lua provided by RyzenAPI
-- Game: E-Shop Tycoon

-- MAIN APPLICATION
addappid(4249850)
addappid(5001810)

-- MAIN APP DEPOTS / PACKAGES
addappid(4249851,0,"97d1672397100486c472e04fc3a201d94d04224ee65b12a396d63bb7c67547aa")

