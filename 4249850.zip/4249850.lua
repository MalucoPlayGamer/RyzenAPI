-- Lua provided by RyzenAPI
-- Game: E-Shop Tycoon

-- MAIN APPLICATION
addappid(4249850)
addappid(5001810)

-- MAIN APP DEPOTS / PACKAGES
addappid(4249851,0,"97d1672397100486c472e04fc3a201d94d04224ee65b12a396d63bb7c67547aa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
