-- Lua provided by RyzenAPI
-- Game: AppID 1610900

-- MAIN APPLICATION
addappid(1610900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610901, 1, "f58e7ffdedac09874b34f209c69f445b2646da997167a606b71da79d76578947")
addappid(1610902, 1, "d896443555faa33485f4c26fcecd5a8e490363c593cf13da6dcfba7fde99d0d4")
addappid(1610903, 1, "564eedcd44d83f2c47d6e84bf6b1d2d20e95e26445a8185d6aa3611029d79958")
addappid(1610904, 1, "e73aecb563e1778058bf6da062857948eb9bee84761b0b4f871661fc44ddf176")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
