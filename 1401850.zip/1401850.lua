-- Lua provided by RyzenAPI
-- Game: Until the Last Plane Demo

-- MAIN APPLICATION
addappid(1401850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401851, 1, "0e970b87bb3ed6f014a6662b9afc4397267c2e7d68b0a0d45a7ad260b36d1759")

