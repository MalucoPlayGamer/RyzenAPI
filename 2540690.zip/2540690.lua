-- Lua provided by RyzenAPI
-- Game: UFindO

-- MAIN APPLICATION
addappid(2540690)
-- Game: addappid(2540690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540691, 1, "ae0503d8bd74a0bd46b02d555bb6562d6cbb682e56c6bb454e409a656b609d01")
