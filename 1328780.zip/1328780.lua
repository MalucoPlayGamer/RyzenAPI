-- Lua provided by RyzenAPI
-- Game: Cell Defender

-- MAIN APPLICATION
addappid(1328780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328781, 1, "7a4c18fcbb7382900b6e2e5186e9ff708ecf9379cff2c86d9cb56683fd294967")

