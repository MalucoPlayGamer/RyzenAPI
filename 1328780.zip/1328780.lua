-- Lua provided by RyzenAPI
-- Game: Cell Defender

-- MAIN APPLICATION
addappid(1328780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328781, 1, "7a4c18fcbb7382900b6e2e5186e9ff708ecf9379cff2c86d9cb56683fd294967")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
