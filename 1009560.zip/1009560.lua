-- Lua provided by RyzenAPI 
-- Game: AppID 1009560
addappid(1009560)
addappid(1009561, 1, "5ee108268b12bce8e956a1191d060e9f17e9863b3683606f67c62c27deea00a1")
addappid(2255330, 0, "125a29b999fbc0dbde88100bf2d1df84e3d84197a23d0f36a1831104f11bb596")
