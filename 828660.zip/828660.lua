-- Lua provided by RyzenAPI
-- Game: 828660

-- MAIN APPLICATION
addappid(828660)
-- Game: addappid(828660)

-- MAIN APP DEPOTS / PACKAGES
addappid(828661, 1, "57233f4cba61dca2448944c4d6e86e416fb87080c25d53843f6b9455baafb162")
addappid(828662, 1, "b0916b944764ee2ef1f5cac6dd453b68e9714fc3a00c607a4ecc02e365ad2c8b")
