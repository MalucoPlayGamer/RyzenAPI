-- Lua provided by RyzenAPI
-- Game: Game: AppID 2250100

-- MAIN APPLICATION
addappid(2250100)
-- Game: addappid(2250100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250101, 1, "f5da7ed0484423e00ec0ab4ff6b2e0430c37fe24ae8db29fe7483672606192e5")
