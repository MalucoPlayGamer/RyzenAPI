-- Lua provided by RyzenAPI 
-- Game: AppID 3266000
addappid(3266000)
addappid(3266001, 1, "56800feca8e610e9f7f5f614786c10b477883c107f6b5319e714b71d27614710")
