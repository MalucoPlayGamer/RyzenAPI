-- Lua provided by RyzenAPI 
-- Game: AppID 1141020
addappid(1141020)
addappid(1141021, 1, "53d99c9b4d66f04d57b5bc021b9b9c0565b7d3b583522d9aee90668e1c23c543")
addappid(1141022, 1, "c179bfff6511f2879469ee8eabb512d6a1864025d705d49b6fc1b385d522b260")
