-- Lua provided by RyzenAPI
-- Game: Cicadas - The IQA Edition

-- MAIN APPLICATION
addappid(846660)

-- MAIN APP DEPOTS / PACKAGES
addappid(846662,0,"62f71f9db5b53f0bad986f031d63ae4fae1a7cf077c085b48887602325385c70")

