-- Lua provided by RyzenAPI
-- Game: Idle Fields

-- MAIN APPLICATION
addappid(1807570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807571, 1, "afd9e6d34424744a5db5ee4fc17b49600f801c6879aad630c4b688a47d122afc")

