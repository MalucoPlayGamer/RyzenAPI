-- Lua provided by RyzenAPI
-- Game: AppID 2328540

-- MAIN APPLICATION
addappid(2328540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328541, 1, "216dacebc1a24a9dd381cdaad48fbb703d27dd22bcdebaad9847b3e732884cfd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
