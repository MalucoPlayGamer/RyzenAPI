-- Lua provided by RyzenAPI
-- Game: addappid(2328540)

-- MAIN APPLICATION
addappid(2328540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328541, 1, "216dacebc1a24a9dd381cdaad48fbb703d27dd22bcdebaad9847b3e732884cfd")
