-- Lua provided by RyzenAPI 
-- Game: Jivana
addappid(1815340)
addappid(1815341, 1, "2060511f71f5c7652725175521734075de347b3ae1cb145856bc60dc74aef39a")
