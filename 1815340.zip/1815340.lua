-- Lua provided by RyzenAPI
-- Game: Game: Jivana

-- MAIN APPLICATION
addappid(1815340)
-- Game: addappid(1815340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815341, 1, "2060511f71f5c7652725175521734075de347b3ae1cb145856bc60dc74aef39a")
