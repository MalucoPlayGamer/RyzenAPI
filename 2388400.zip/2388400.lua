-- Lua provided by RyzenAPI
-- Game: Mech Mastery

-- MAIN APPLICATION
addappid(2388400)
-- Game: addappid(2388400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388401, 1, "bbc5827d999c85ef47eb09ca888c37e54a8777eb5c12d5c55d5bbb4c4402eb72")
