-- Lua provided by RyzenAPI
-- Game: Yakuza 0 Director's Cut

-- MAIN APPLICATION
addappid(2988580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2988581, 1, "5dd1da6fa3ee7c2ba5ff647beb5b4fd9899f1ed4c421a6af79eb65b7ce38cb6e")

