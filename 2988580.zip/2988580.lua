-- Lua provided by RyzenAPI
-- Game: Yakuza 0 Director's Cut

-- MAIN APPLICATION
addappid(2988580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2988581, 1, "5dd1da6fa3ee7c2ba5ff647beb5b4fd9899f1ed4c421a6af79eb65b7ce38cb6e")

