-- Lua provided by RyzenAPI
-- Game: Game: Umamusume: Pretty Derby

-- MAIN APPLICATION
addappid(3224770)
-- Game: addappid(3224770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224771, 1, "22b178efa09d88963c4935d572fc8321b864d821a98762c93e791b28a38af501")
