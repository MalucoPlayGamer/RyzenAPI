-- Lua provided by RyzenAPI 
-- Game: Elf Breeding Farm
addappid(1233710)
addappid(1233711, 1, "83ddf1b2d1955d6db3971567a6eec9ec3ca7724c21f5a992a42e6b9c895e75cb")
addappid(1233712, 1, "ea413aacd95d2462027946aaa5b1fdd44116055fa33a6a0b1c210bcce1f0984d")
