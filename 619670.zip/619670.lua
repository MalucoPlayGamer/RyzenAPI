-- Lua provided by RyzenAPI
-- Game: Huge Bang Bang

-- MAIN APPLICATION
addappid(619670)
-- Game: addappid(619670)

-- MAIN APP DEPOTS / PACKAGES
addappid(619671, 1, "1e33285db2bdbd7ba3fafdba9e90fc6cb15c4111fa6783925711bb0baf654524")
