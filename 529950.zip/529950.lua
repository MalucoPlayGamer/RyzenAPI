-- Lua provided by RyzenAPI
-- Game: 12 orbits

-- MAIN APPLICATION
addappid(529950)
-- Game: addappid(529950)

-- MAIN APP DEPOTS / PACKAGES
addappid(529951, 1, "ddb21afe2c3b1ec4827460d628d39b98c95a2f11db58c1189411dbf941b20bb2")
addappid(529952, 1, "17c40085dec2d1bac1da9984ad256303d0184161119a82257763a4fc6407b7f1")
addappid(529953, 1, "65f2b82a30be1ac6120fce94a7d0e651e07230cb4d9c1bbf0a787f0c7ea31b65")
