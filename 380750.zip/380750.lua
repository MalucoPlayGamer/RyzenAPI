-- Lua provided by RyzenAPI
-- Game: Anima: Gate of Memories

-- MAIN APPLICATION
addappid(380750)
-- Game: addappid(380750)

-- MAIN APP DEPOTS / PACKAGES
addappid(380751, 1, "37ee9621d197eeb71e1009946f71fee423b8e11fdefc5eb5846cf97c8a2a0090")
addappid(380756, 1, "2210a4ab19fbb1a5f8d94a700aba22b02ea04c23485330ae0603ebdc2c27a7f7")
addappid(380757, 1, "05047f2a773534f7d803947aae23e278ec460e4c06653a3c381ace0aa125ae48")
addappid(538930, 0, "b78d44ac10c1d08a2740bd6b755b83835aac6aca1d9651b53af1a7d00f8fd10a")
