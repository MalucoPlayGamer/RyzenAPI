-- Lua provided by RyzenAPI
-- Game: Hand2Hand

-- MAIN APPLICATION
addappid(2301060)
-- Game: addappid(2301060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301061, 1, "f829829907baf428ffcb02da3de486ee440053afebb3be4ec7e1181981f56cb7")
