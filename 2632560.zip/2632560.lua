-- Lua provided by RyzenAPI
-- Game: 2632560

-- MAIN APPLICATION
addappid(2632560)
-- Game: addappid(2632560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2632561, 1, "a82067ef2504df8e0c9bc61b9b23ee9f91ddf08ce3286781087837af17ccd609")
