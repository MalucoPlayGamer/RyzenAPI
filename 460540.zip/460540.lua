-- Lua provided by RyzenAPI
-- Game: addappid(460540)

-- MAIN APPLICATION
addappid(460540)

-- MAIN APP DEPOTS / PACKAGES
addappid(460541, 1, "02dc3eead1ff5ac09132f21c83a92632c127997b35f08cb7bc92e6fe6d096206")
