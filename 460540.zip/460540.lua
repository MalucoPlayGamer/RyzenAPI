-- Lua provided by RyzenAPI
-- Game: Temple of Rust

-- MAIN APPLICATION
addappid(460540)
addappid(982470)
addappid(982471)
addappid(982472)
addappid(982473)

-- MAIN APP DEPOTS / PACKAGES
addappid(460541, 1, "02dc3eead1ff5ac09132f21c83a92632c127997b35f08cb7bc92e6fe6d096206")
