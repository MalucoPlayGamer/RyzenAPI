-- Lua provided by RyzenAPI
-- Game: 百詰怪軼與金魚

-- MAIN APPLICATION
addappid(1367960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367961, 1, "b4a10c1f2b0b8662b5546878b7b758668a3a20a88996f87e5bdf1de1fb2d4177")

