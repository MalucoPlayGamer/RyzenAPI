-- Lua provided by RyzenAPI
-- Game: Corsairs Legacy Supporter Pack

-- MAIN APPLICATION
addappid(2461620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461620,0,"469737bbd89d3e796e711d17d630898d706a567335ce76552b97b4d60f130bfe")

