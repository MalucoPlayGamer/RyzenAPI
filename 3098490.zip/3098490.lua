-- Lua provided by RyzenAPI
-- Game: addappid(3098490)

-- MAIN APPLICATION
addappid(3098490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3098491, 1, "119f8de38e4d1029ab396ada6eeebb603b8391df32dfbfb26e3578add4d7f88b")
