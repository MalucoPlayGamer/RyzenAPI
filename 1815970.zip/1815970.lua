-- Lua provided by RyzenAPI
-- Game: A Clockwork Ley-Line: Daybreak of Remnants Shadow

-- MAIN APPLICATION
addappid(1815970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815971, 1, "5684dfa18fe7dd0a921a1099b7e75c667227c1a6f37023de3fd5e77cdec8d0d0")
