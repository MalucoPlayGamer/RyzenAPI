-- Lua provided by RyzenAPI
-- Game: AppID 878670

-- MAIN APPLICATION
addappid(878670)

-- MAIN APP DEPOTS / PACKAGES
addappid(878671, 1, "664c311e20bc756c8f1a41ecdc66eb10e36c82259c9ef242379a7b1c087bb5bb")
