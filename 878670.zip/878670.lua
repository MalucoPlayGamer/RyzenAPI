-- Lua provided by SkyAPI 
-- Game: AppID 878670
addappid(878670)
addappid(878671, 1, "664c311e20bc756c8f1a41ecdc66eb10e36c82259c9ef242379a7b1c087bb5bb")
