-- Lua provided by RyzenAPI
-- Game: Shenmue III

-- MAIN APPLICATION
addappid(878670)
addappid(1047200)
addappid(1047201)
addappid(1047202)
addappid(1166190)
addappid(1166191)
addappid(1166192)
addappid(1166193)
addappid(1166194)
addappid(1166195)
addappid(1166196)
addappid(1166197)
addappid(1166198)
addappid(1166199)
addappid(1166220)
addappid(1166221)
addappid(1166222)
addappid(1166223)
addappid(1166224)
addappid(1166225)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(878671,0,"664c311e20bc756c8f1a41ecdc66eb10e36c82259c9ef242379a7b1c087bb5bb")

