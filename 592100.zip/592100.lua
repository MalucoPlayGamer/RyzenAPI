-- Lua provided by RyzenAPI
-- Game: Flotilla 2

-- MAIN APPLICATION
addappid(592100)

-- MAIN APP DEPOTS / PACKAGES
addappid(592101,0,"ac7dd5694fef943954e6c13b996998252396c0250b6cc34a400c0c56451188ee")

