-- Lua provided by RyzenAPI
-- Game: addappid(1062120)

-- MAIN APPLICATION
addappid(1062120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062121, 1, "00899bc2638eee3ff4d4500b60b565c6901fc431a9e02984efaf291426d810e4")
