-- Lua provided by RyzenAPI
-- Game: Tragedy of Medusa

-- MAIN APPLICATION
addappid(2186300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186301, 1, "75d5d90fee3f02d5e30afe56345d17dcb7eeff37f2d9cc1c08d95cdd923d7d41")

