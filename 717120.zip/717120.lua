-- Lua provided by RyzenAPI
-- Game: AppID 717120

-- MAIN APPLICATION
addappid(717120)

-- MAIN APP DEPOTS / PACKAGES
addappid(717121, 1, "f15e9969ecf8004eb6f42b0b73a0edb581b142fdb25aaebc1230d87542a37e2a")

