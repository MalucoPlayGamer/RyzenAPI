-- Lua provided by RyzenAPI
-- Game: Lucah: Born of a Dream

-- MAIN APPLICATION
addappid(896460)

-- MAIN APP DEPOTS / PACKAGES
addappid(896461, 1, "0960e646599dcf766bd15602c3d042c4cb3635a54df3aa1fcd99c3a58ce09b1f")

