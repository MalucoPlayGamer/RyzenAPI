-- Lua provided by RyzenAPI
-- Game: AppID 3568410

-- MAIN APPLICATION
addappid(3568410)
-- Game: addappid(3568410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3568411, 1, "1f7c30c6bf35edfd128316f88d4e18f498748c10107de22a970ff5252584fe1a")
