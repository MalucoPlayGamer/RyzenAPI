-- Lua provided by RyzenAPI
-- Game: addappid(1828710)

-- MAIN APPLICATION
addappid(1828710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828711, 1, "401e2342809cd38809ec009ab7cd605838ef10a2bde4758bacadca3592cafe92")
