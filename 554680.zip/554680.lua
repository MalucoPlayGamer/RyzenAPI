-- Lua provided by RyzenAPI
-- Game: AppID 554680

-- MAIN APPLICATION
addappid(554680)
-- Game: addappid(554680)

-- MAIN APP DEPOTS / PACKAGES
addappid(554681, 1, "2f25c263bb0e67089ed09bb79f129d98d53ae3e7cbb8b6b816776e2414ba8b8d")
