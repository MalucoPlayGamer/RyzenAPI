-- Lua provided by RyzenAPI
-- Game: VRM Adjuster

-- MAIN APPLICATION
addappid(3130700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130701, 1, "125565e280f88caca7932a1cab5dcb0172974db3df0949c5053974da929793c3")

