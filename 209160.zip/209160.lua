-- Lua provided by RyzenAPI
-- Game: Game: Call of Duty®: Ghosts

-- MAIN APPLICATION
addappid(209160)
addappid(229002)
-- Game: addappid(209160)

-- MAIN APP DEPOTS / PACKAGES
addappid(209161, 1, "6c5f97d6127289ac53c5c62d467652ef5ac48c597a8cdc0eccb13c2e0fc61520")
addappid(209163, 1, "add37e1da3d2ec3cbab0a8976f8bc8bf6ee91f7f3f80e33f2855434803b7dc3d")
