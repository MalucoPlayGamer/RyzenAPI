-- Lua provided by RyzenAPI
-- Game: #DRIVE Rally

-- MAIN APPLICATION
addappid(2494780)
-- Game: addappid(2494780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494781, 1, "e2c270ac8664f72fa91c1b705bd44a7ed986d6ef6230309e000724795e515931")
