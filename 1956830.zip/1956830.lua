-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] The Bathhouse | 地獄銭湯♨️

-- MAIN APPLICATION
addappid(1956830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956831, 1, "94560bd94c52f09005fa75dc4a466541cba019779f6036b93803e693878df07b")

