-- Lua provided by RyzenAPI
-- Game: From Orbit

-- MAIN APPLICATION
addappid(668290)

-- MAIN APP DEPOTS / PACKAGES
addappid(668291, 1, "dd4045face652451fb7aa3220568f7280cf1a59c7cda852286c336466ed61eb3")

