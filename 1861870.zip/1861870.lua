-- Lua provided by RyzenAPI
-- Game: Shadow Fate

-- MAIN APPLICATION
addappid(1861870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(1861871, 1, "877e4f9b32d0dfc9b8729de4b0ed90108c96ead5b7e67b825f2eafce341782b6")

