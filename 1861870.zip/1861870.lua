-- Lua provided by RyzenAPI
-- Game: Shadow Fate

-- MAIN APPLICATION
addappid(1861870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861871, 1, "877e4f9b32d0dfc9b8729de4b0ed90108c96ead5b7e67b825f2eafce341782b6")
