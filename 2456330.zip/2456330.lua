-- Lua provided by RyzenAPI
-- Game: addappid(2456330)

-- MAIN APPLICATION
addappid(2456330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456331, 1, "890888bfdbc1f5be83fd011d6a73c730581d528fb2ac73f6262d5b52d00c377c")
