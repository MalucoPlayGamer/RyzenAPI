-- Lua provided by SkyAPI 
-- Game: Bloompunk
addappid(2456330)
addappid(2456331, 1, "890888bfdbc1f5be83fd011d6a73c730581d528fb2ac73f6262d5b52d00c377c")
