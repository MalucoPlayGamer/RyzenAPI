-- Lua provided by RyzenAPI
-- Game: DFF NT: Organyx, Cloud Strife's 4th Weapon

-- MAIN APPLICATION
addappid(1022420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022420,0,"9df645b7ee299660be82154273c56f5ba656cfc29a4a40680d8a238a26dd10f9")
