-- Lua provided by RyzenAPI
-- Game: The Great Villainess: Strategy of Lily

-- MAIN APPLICATION
addappid(2454960)
addappid(3870100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454961, 1, "f9d837e5f796913d7a8dbdee90b7bd2dd8716a04a89a7975e01c27fd484a674a")

