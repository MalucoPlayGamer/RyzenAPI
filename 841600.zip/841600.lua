-- Lua provided by RyzenAPI
-- Game: Aura of Worlds

-- MAIN APPLICATION
addappid(841600)

-- MAIN APP DEPOTS / PACKAGES
addappid(841601, 1, "b2dbc1073897f493eec0eb069c95c5d5065d3d6297f5057122a2b07cb20e1735")

