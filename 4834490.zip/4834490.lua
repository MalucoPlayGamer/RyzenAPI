-- Lua provided by RyzenAPI
-- Game: Pixel Texas Hold'em

-- MAIN APPLICATION
addappid(4834490)

