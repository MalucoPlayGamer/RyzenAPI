-- Lua provided by RyzenAPI
-- Game: Game: Ukraine Defender

-- MAIN APPLICATION
addappid(1973090)
-- Game: addappid(1973090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973091, 1, "757e15f0d250180bc3fd1262fc978ef4dffc112abd667c1d467c6463378591e3")
