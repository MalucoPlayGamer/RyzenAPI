-- Lua provided by RyzenAPI
-- Game: Bonfire And Tail

-- MAIN APPLICATION
addappid(2249700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249701, 1, "c84414ed983ce9905cfd0855745d318fb20f207be9bd6e0a9f52b54d73eef131")
