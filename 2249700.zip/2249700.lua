-- Lua provided by RyzenAPI
-- Game: Bonfire And Tail

-- MAIN APPLICATION
addappid(2249700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249701, 1, "c84414ed983ce9905cfd0855745d318fb20f207be9bd6e0a9f52b54d73eef131")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
