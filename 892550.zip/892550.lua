-- Lua provided by RyzenAPI
-- Game: Beauty and the Beast: Hidden Objects

-- MAIN APPLICATION
addappid(892550)

-- MAIN APP DEPOTS / PACKAGES
addappid(892551, 1, "9e060933259652dc8e164ee867cdd6bb007b8112021264c3bd6558309617d102")
