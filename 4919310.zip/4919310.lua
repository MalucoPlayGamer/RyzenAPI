-- 4919310's Lua and Manifest Created by Hubcap Manifest
-- MEKAKUSHI-SAN
-- Created: August 06, 2026 at 23:44:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4919310) -- MEKAKUSHI-SAN
-- MAIN APP DEPOTS
addappid(4919311, 1, "6d37569272445dc3d07c127eb366b603b008269f8310139a7ed2794f3984a9c5") -- Depot 4919311
setManifestid(4919311, "1529865571951629610", 587740230)