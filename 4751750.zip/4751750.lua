-- 4751750's Lua and Manifest Created by Hubcap Manifest
-- Froggy Works
-- Created: July 30, 2026 at 00:12:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4751750) -- Froggy Works
-- MAIN APP DEPOTS
addappid(4751751, 1, "e7ca6dae7ad0364382ae51f729d5b8f7a995da3d7fd83b80bd736ef338331eaf") -- Depot 4751751
setManifestid(4751751, "4432563791756382940", 56540681)
addappid(4751752, 1, "f5b15801554d5d78387a8f41253f22d6096f44272296bf52d92eefab46e928c7") -- Depot 4751752
setManifestid(4751752, "747513292677024531", 53104534)