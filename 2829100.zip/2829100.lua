-- Lua provided by RyzenAPI
-- Game: addappid(2829100)

-- MAIN APPLICATION
addappid(2829100)
addappid(2829101)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698941,0,"d883429e0c229f4e0634265ea029ccf4200bf0a6d171047809fab73ae807ba8c")
