-- Lua provided by RyzenAPI
-- Game: Birds Organized Neatly Demo

-- MAIN APPLICATION
addappid(3230110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3230111, 1, "48ed21448d67a6c56657cf964110d62a9df4838d01f481045a34ee01c80f66d4")

