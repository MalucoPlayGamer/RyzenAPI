-- Lua provided by RyzenAPI
-- Game: Game: LUST Company 👾

-- MAIN APPLICATION
addappid(3426450)
-- Game: addappid(3426450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3426451, 1, "0801479ea02220e869cde39868f0c5798d77cfd8557523de93705142e3d1db57")
