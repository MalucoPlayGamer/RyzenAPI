-- Lua provided by RyzenAPI
-- Game: ASTRA

-- MAIN APPLICATION
addappid(1522190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522191, 1, "cdc988ebf43f2fe7862ce17f3429f3a3bb73ababec40cd456d6c500cb5bf629b")

