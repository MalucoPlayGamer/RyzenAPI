-- Lua provided by RyzenAPI
-- Game: 2342780

-- MAIN APPLICATION
addappid(2342780)
-- Game: addappid(2342780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342781, 1, "1827ca8b550c118062c07db0826626bc5c8b6825c6e0ec8dd9e45d3d7e4d5338")
