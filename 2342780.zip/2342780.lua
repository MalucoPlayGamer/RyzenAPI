-- Lua provided by SkyAPI 
-- Game: Neo Harbor Rescue Squad
addappid(2342780)
addappid(2342781, 1, "1827ca8b550c118062c07db0826626bc5c8b6825c6e0ec8dd9e45d3d7e4d5338")
