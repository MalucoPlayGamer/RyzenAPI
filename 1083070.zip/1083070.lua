-- Lua provided by RyzenAPI 
-- Game: Sapper - Defuse The Bomb Simulator
addappid(1083070)
addappid(1083071, 1, "9dee65f5770455ffdc6c532a2220550a7f3b8a011a202374d7fcc4a22b3b3399")
