-- Lua provided by RyzenAPI
-- Game: Sapper - Defuse The Bomb Simulator

-- MAIN APPLICATION
addappid(1083070)
-- Game: addappid(1083070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083071, 1, "9dee65f5770455ffdc6c532a2220550a7f3b8a011a202374d7fcc4a22b3b3399")
