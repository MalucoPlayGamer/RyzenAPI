-- Lua provided by RyzenAPI
-- Game: Game: Snufkin: Melody of Moominvalley

-- MAIN APPLICATION
addappid(1808680)
-- Game: addappid(1808680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808681, 1, "157f66261c91bc328ad7ac3f9551dc063ee56f5f881679928732ec02f0e9e5ba")
addappid(1808682, 1, "bb5c1726c61a08ac86d4ce2ee60ed7b25a714f5e636d280b10f21c4afebf3ead")
addappid(1808683, 1, "957d4d27e12060d0c29f5cfddb63d8d5653ef2180c3711d5ca385eb7c7e8bca0")
