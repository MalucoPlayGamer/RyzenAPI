-- Lua provided by RyzenAPI
-- Game: Undercroft Warriors

-- MAIN APPLICATION
addappid(2547140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2547141,0,"7df45017ae625185991eeeaee5d0ce34cd3601b7a2c1cd28a4b55ced7eb42e70")

