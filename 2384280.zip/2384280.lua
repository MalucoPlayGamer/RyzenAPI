-- Lua provided by RyzenAPI
-- Game: addappid(2384280)

-- MAIN APPLICATION
addappid(2384280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384281, 1, "c149bb69620ac60fe6ca8ef3adbe5f68d8695ba33c8bcef8b202debfc2e65765")
