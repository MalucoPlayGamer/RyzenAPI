-- Lua provided by RyzenAPI
-- Game: addappid(765350)

-- MAIN APPLICATION
addappid(765350)

-- MAIN APP DEPOTS / PACKAGES
addappid(765351, 1, "cb7d20b93ced36c96aef171e0195ba4ee46d05c4cc98c6127e6135277241a512")
