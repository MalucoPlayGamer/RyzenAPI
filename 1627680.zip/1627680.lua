-- Lua provided by RyzenAPI
-- Game: Love n War: Hero by Chance II

-- MAIN APPLICATION
addappid(1627680)
addappid(1809620)
addappid(2311640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627681, 1, "213a60478bd35f3e62f84e79a925d368c4ea4986597d5c4ce33fe9d5ad5c1324")

