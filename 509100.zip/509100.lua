-- Lua provided by RyzenAPI
-- Game: 509100

-- MAIN APPLICATION
addappid(509100)
-- Game: addappid(509100)

-- MAIN APP DEPOTS / PACKAGES
addappid(509100,0,"d9e5ee5b8aaf8c852b83a2b96d13d2bcacf3f42583a37c6586f5936fa327b504")
