-- Lua provided by RyzenAPI
-- Game: Tomb Raider: Legend Demo

-- MAIN APPLICATION
addappid(7030)

-- MAIN APP DEPOTS / PACKAGES
addappid(7031, 1, "b5f7509f888471a7948b8f71c4c027372db6af2dcd454118c6c57e11cde5babc")

