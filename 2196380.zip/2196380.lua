-- Lua provided by RyzenAPI
-- Game: Candy Maid

-- MAIN APPLICATION
addappid(2196380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196381, 1, "c22e9521fd109cb4cee6263726e60a9c34185042772fed323797527f8f7ae5be")

