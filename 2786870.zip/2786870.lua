-- Lua provided by RyzenAPI
-- Game: Ninjurate

-- MAIN APPLICATION
addappid(2786870)
-- Game: addappid(2786870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786871, 1, "5a3c31ae8a1ff49d740b81f3a2de2f5f722e1968aad1be1ba678684514447ce6")
