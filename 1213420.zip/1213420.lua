-- Lua provided by RyzenAPI
-- Game: Texas Holdem Poker: Solo King

-- MAIN APPLICATION
addappid(1213420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213421, 1, "54c73e41cfb03f43d8b3d2caad4b003a3da775516e94d10816f96a4b18559b41")
addappid(1213422, 1, "a8c15a0c3e1a3d73e6b0bf5d4270065b7d106fad68e359aa053a831a21eaea1d")

