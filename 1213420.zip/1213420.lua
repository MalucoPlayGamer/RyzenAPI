-- Lua provided by RyzenAPI
-- Game: Texas Holdem Poker: Solo King

-- MAIN APPLICATION
addappid(1213420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1213421, 1, "54c73e41cfb03f43d8b3d2caad4b003a3da775516e94d10816f96a4b18559b41")
addappid(1213422, 1, "a8c15a0c3e1a3d73e6b0bf5d4270065b7d106fad68e359aa053a831a21eaea1d")

