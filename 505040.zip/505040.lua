-- Lua provided by RyzenAPI
-- Game: Game: AppID 505040

-- MAIN APPLICATION
addappid(505040)
-- Game: addappid(505040)

-- MAIN APP DEPOTS / PACKAGES
addappid(505041, 1, "55427e1043b3f94d81973e9ae9bfa6b47296dad8ffcd2b9f3ea2100b9acb0ddd")
addappid(505042, 1, "3b5db81dac58dcac2771acbb5ad520d8f468f39519830b5b89af1c71b1729535")
addappid(505043, 1, "531a1906c2f0b563c4d875d0379ddb4532b7e7991c7d025dc9e36c8a70745953")
