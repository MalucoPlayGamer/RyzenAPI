-- Lua provided by RyzenAPI
-- Game: Game: Nyasha

-- MAIN APPLICATION
addappid(1035930)
-- Game: addappid(1035930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035931, 1, "af91a1d150c8662d7f914a2197f814c040f7f08af25f50fcba0b9f95c68c6332")
