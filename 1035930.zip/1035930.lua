-- Lua provided by RyzenAPI
-- Game: Nyasha

-- MAIN APPLICATION
addappid(1035930)
addappid(1044260)
addappid(1080420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035931,0,"af91a1d150c8662d7f914a2197f814c040f7f08af25f50fcba0b9f95c68c6332")
addappid(1044260,0,"c85a84e4bab6242e80643ebb3d75a805f7e049fe93fe97505dc1d4df46345d7b")
addappid(1080420,0,"7932deafc36a6fe75ac8a5b498c563ff0ca6929f18cf6eb9a963a0821ef506ca")

