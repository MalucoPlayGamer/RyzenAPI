-- Lua provided by RyzenAPI
-- Game: Game: Aaero2 Demo

-- MAIN APPLICATION
addappid(3261840)
-- Game: addappid(3261840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261841, 1, "e2fa5d860af8cd263ea2f68dd2e1a0842e6062b4327dbc82deda7e184aa37e98")
