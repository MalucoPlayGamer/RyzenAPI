-- Lua provided by RyzenAPI
-- Game: 1338580

-- MAIN APPLICATION
addappid(1338580)
-- Game: addappid(1338580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338581, 1, "2353e713beb2fd2d8e3bb2da9a4a6b2303878d83d2107de54ecd68e249121080")
addappid(1338583, 1, "1ace67d7b020dedb64564005fb1be16fe25142f4e1254b8db1ab3a2b52af9636")
