-- Lua provided by RyzenAPI
-- Game: McPixel 3

-- MAIN APPLICATION
addappid(1338580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1338581, 1, "2353e713beb2fd2d8e3bb2da9a4a6b2303878d83d2107de54ecd68e249121080")
addappid(1338583, 1, "1ace67d7b020dedb64564005fb1be16fe25142f4e1254b8db1ab3a2b52af9636")
