-- Lua provided by RyzenAPI
-- Game: Hazel Sky Soundtrack

-- MAIN APPLICATION
addappid(2024050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024051, 1, "6652cf1698b7753e0fa6b4e9fbfe50cbea1072dc34ff4cba0659b02d049f4f10")
addappid(2024052, 1, "5d61a73e66c8af2b7c0aa1bc33d21bcb3bde9ae93f9fc96f4b7724dc07f15a9a")
