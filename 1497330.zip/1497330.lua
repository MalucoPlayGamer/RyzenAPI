-- Lua provided by RyzenAPI 
-- Game: Bad Way
addappid(1497330)
addappid(1497331, 1, "76eabce095bc0b0b0cdb4c746ce31f3cb799c73a3113c6e697011a9c420535d8")
