-- Lua provided by RyzenAPI
-- Game: Heroes and Test of Succubus

-- MAIN APPLICATION
addappid(2056150)
addappid(2552890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056151, 1, "34943bc374ea9abeaa662cfe171b780782a7cf84b30423792196ce5859f59e5e")
