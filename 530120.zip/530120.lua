-- Lua provided by RyzenAPI
-- Game: 530120

-- MAIN APPLICATION
addappid(530120)
-- Game: addappid(530120)

-- MAIN APP DEPOTS / PACKAGES
addappid(530121, 1, "9b99ac4474bbbe728cdc47b09e249c0e0127d717cefbe55019c6a2727f67fdb5")
