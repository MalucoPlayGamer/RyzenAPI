-- Lua provided by RyzenAPI
-- Game: Night of The Black Goat

-- MAIN APPLICATION
addappid(3141890)
-- Game: addappid(3141890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141892,0,"30956106a730200480d1bdbaccc2ea8717e2dd12b640f292cffdd86c666de83e")
addappid(3141893,0,"85edd720b0c91c2ca0f819fe57d80b19bc370fc2a3eb794d990a2de312ca2a96")
