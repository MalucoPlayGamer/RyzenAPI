-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1089228)
-- Game: addappid(1089228)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089228,0,"6490e990949bf08289370c760ec6fbb9648322c03bf03879e3a4695349b54c5d")
