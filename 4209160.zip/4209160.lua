-- Lua provided by RyzenAPI
-- Game: Idyll Isle

-- MAIN APP DEPOTS / PACKAGES
addappid(4209160, 1, "d32602170bb79f482d976db86c7f6b3b8cc5eacab1b3bddc597bcdea19a87064") -- Idyll Isle
addappid(4209161, 1, "778ec8859a11105b4c2843a87114b339c2f293eff88168988b4089b49ca8593e") -- Depot 4209161

