-- 4209160's Lua and Manifest Created by Hubcap Manifest
-- Idyll Isle
-- Created: August 11, 2026 at 21:00:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4209160, 1, "d32602170bb79f482d976db86c7f6b3b8cc5eacab1b3bddc597bcdea19a87064") -- Idyll Isle
-- MAIN APP DEPOTS
addappid(4209161, 1, "778ec8859a11105b4c2843a87114b339c2f293eff88168988b4089b49ca8593e") -- Depot 4209161
setManifestid(4209161, "2616740435639553746", 127305520)