-- Lua provided by RyzenAPI
-- Game: Bitten! Someone has to be a villain

-- MAIN APPLICATION
addappid(1639530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1639531, 1, "15f2dd9b05d439c31bbbf20328fe039c7eb65d413c1ece73a80979d30f771b5d")

