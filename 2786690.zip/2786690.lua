-- Lua provided by RyzenAPI
-- Game: Game: AppID 2786690

-- MAIN APPLICATION
addappid(2786690)
-- Game: addappid(2786690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786691, 1, "6f8de80f706ca18a05b608de852609b764e8fa77580717415cd2d22179338da5")
