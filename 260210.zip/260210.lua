-- Lua provided by RyzenAPI
-- Game: 260210

-- MAIN APPLICATION
addappid(260210)
addappid(272700)
-- Game: addappid(260210)

-- MAIN APP DEPOTS / PACKAGES
addappid(260211, 1, "6a3490285db760cc79bac0bdecd4f4bb729ee76363f8298ecf13e046213fd845")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
