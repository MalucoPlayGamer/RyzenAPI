-- Lua provided by RyzenAPI
-- Game: Way in the stars

-- MAIN APPLICATION
addappid(1400140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400141, 1, "f8e9cf1e4a9a3ee79f3d8db7c3ad9dcecf6ccf17620263b16f92da5efd5774af")
