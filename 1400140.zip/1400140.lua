-- Lua provided by RyzenAPI
-- Game: Way in the stars

-- MAIN APPLICATION
addappid(1400140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1400141, 1, "f8e9cf1e4a9a3ee79f3d8db7c3ad9dcecf6ccf17620263b16f92da5efd5774af")

