-- Lua provided by RyzenAPI
-- Game: Baisu

-- MAIN APPLICATION
addappid(2821850)
-- Game: addappid(2821850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821851, 1, "34f81784128a1ebbd547d34bf15cf1218649309e468104600e92a3ad09b5463a")
