-- Lua provided by RyzenAPI
-- Game: Baisu

-- MAIN APPLICATION
addappid(2821850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2821851, 1, "34f81784128a1ebbd547d34bf15cf1218649309e468104600e92a3ad09b5463a")

