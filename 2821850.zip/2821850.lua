-- Lua provided by SkyAPI 
-- Game: Baisu
addappid(2821850)
addappid(2821851, 1, "34f81784128a1ebbd547d34bf15cf1218649309e468104600e92a3ad09b5463a")
