-- Lua provided by RyzenAPI
-- Game: Duality

-- MAIN APPLICATION
addappid(959930)

-- MAIN APP DEPOTS / PACKAGES
addappid(959931,0,"72875dc68deb86a6fe795f15286cda4dc58bf3cc2a853bf018ab291bb3ecf84b")

