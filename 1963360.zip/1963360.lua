-- Lua provided by RyzenAPI
-- Game: 1963360

-- MAIN APPLICATION
addappid(1963360)
-- Game: addappid(1963360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963361, 1, "4fe3cd4928f965322e5d0358f901c7ac18b2c9fc8916bfc362ff9628d9395fc9")
