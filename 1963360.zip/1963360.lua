-- Lua provided by RyzenAPI
-- Game: Yerr Out

-- MAIN APPLICATION
addappid(1963360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1963361, 1, "4fe3cd4928f965322e5d0358f901c7ac18b2c9fc8916bfc362ff9628d9395fc9")

