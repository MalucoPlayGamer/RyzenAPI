-- Lua provided by RyzenAPI
-- Game: Secret Paws - Cozy Offices

-- MAIN APPLICATION
addappid(3452270)

