-- Lua provided by RyzenAPI
-- Game: Secret Paws - Cozy Offices

-- MAIN APPLICATION
addappid(3452270)
addappid(3455020)

