-- Lua provided by RyzenAPI
-- Game: Moose Miners Demo

-- MAIN APPLICATION
addappid(2646750)
-- Game: addappid(2646750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646751, 1, "9a0107385ecfa48dd82cea0c6a3ebf46f57813e6cba898b840a2c09408fd597d")
