-- Lua provided by RyzenAPI
-- Game: Game: Mega Mall Story

-- MAIN APPLICATION
addappid(1923680)
-- Game: addappid(1923680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923681, 1, "75778c23874b24a7347903b7e70cf6f1ccf0e94b78c9ff6d8465536180486ec9")
