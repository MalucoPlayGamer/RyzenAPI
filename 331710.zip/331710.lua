-- Lua provided by RyzenAPI
-- Game: 331710

-- MAIN APPLICATION
addappid(331710)
-- Game: addappid(331710)

-- MAIN APP DEPOTS / PACKAGES
addappid(331711, 1, "dc19ceba1f4d1d42a76aa0d1ee74e6ba0310744d5fe2811bcd7fcdbec33c40e9")
