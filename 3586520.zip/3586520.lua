-- Lua provided by RyzenAPI
-- Game: Beek: Familiar Spirit - Remastered

-- MAIN APPLICATION
addappid(3586520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586521, 1, "df59d6a06638307acb5525966a228aab89fafd3da32608600b2998fb255e24bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
