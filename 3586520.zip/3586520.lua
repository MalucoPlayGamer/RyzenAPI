-- Lua provided by RyzenAPI
-- Game: Beek: Familiar Spirit - Remastered

-- MAIN APPLICATION
addappid(3586520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586521, 1, "df59d6a06638307acb5525966a228aab89fafd3da32608600b2998fb255e24bf")

