-- Lua provided by RyzenAPI
-- Game: Commandos: Behind Enemy Lines

-- MAIN APPLICATION
addappid(6800)

-- MAIN APP DEPOTS / PACKAGES
addappid(6801, 1, "8a0187c4c560169f3c1c823961dc790322552b390df0c7e2b7c28daa6f1e8f6a")
addappid(6802, 1, "e3bb91c83193f0f7f0762580d71c338877ab8aacb1824fa62e240813f906bcec")

