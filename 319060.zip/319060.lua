-- Lua provided by RyzenAPI
-- Game: Game: AppID 319060

-- MAIN APPLICATION
addappid(319060)
-- Game: addappid(319060)

-- MAIN APP DEPOTS / PACKAGES
addappid(319061, 1, "d619f2ada3627ef86c5b02d780c771c5cf69c5a6ad63efe76fc8eb5fe2e54c10")
