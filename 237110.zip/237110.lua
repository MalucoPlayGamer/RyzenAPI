-- Lua provided by RyzenAPI
-- Game: AppID 237110

-- MAIN APPLICATION
addappid(237110)

-- MAIN APP DEPOTS / PACKAGES
addappid(237111, 1, "2c086732018a2360a855d4d934af330f401e54794f4f8880fe41f9e0b724a1e3")
addappid(237112, 1, "08ad2e11b65d254326f45d40a792b2687736ba990175d22c1fdaa77b103ae08d")
addappid(237113, 1, "44163a4633f508f0f3fb88f3312505c73b08ef29c787c5743adf862d5f598f3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
