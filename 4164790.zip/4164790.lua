-- Lua provided by RyzenAPI
-- Game: Survival Log

-- MAIN APPLICATION
addappid(4164790) -- Survival Log

-- MAIN APP DEPOTS / PACKAGES
addappid(4164791, 1, "ea042cfee2f842c31ecd3da8061c7dcd086ba70e586991035ef463d0b71ce284") -- Depot 4164791

