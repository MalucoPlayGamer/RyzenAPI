-- 4164790's Lua and Manifest Created by Hubcap Manifest
-- Survival Log
-- Created: August 12, 2026 at 09:14:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4164790) -- Survival Log
-- MAIN APP DEPOTS
addappid(4164791, 1, "ea042cfee2f842c31ecd3da8061c7dcd086ba70e586991035ef463d0b71ce284") -- Depot 4164791
setManifestid(4164791, "4617624453952190310", 4227085325)