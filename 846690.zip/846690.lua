-- Lua provided by RyzenAPI
-- Game: Lost Lands: Ice Spell Collector's Edition

-- MAIN APPLICATION
addappid(846690)
-- Game: addappid(846690)

-- MAIN APP DEPOTS / PACKAGES
addappid(846691, 1, "3aa0234bdf4bb68ad75831055c68765886754c15aad7fe67a26ab93aa5fdcdb7")
addappid(846693, 1, "4e0b4dca77619c806c6bd131afdf61c6aab5481fa327e3f3f7b222189afd3972")
addappid(846694, 1, "4774e0341692ef0d69618132c3a83d0afd46e925a4c9d4ba82725d304e10a05c")
