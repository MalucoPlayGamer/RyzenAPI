-- Lua provided by RyzenAPI
-- Game: 2557870

-- MAIN APPLICATION
addappid(2557870)
-- Game: addappid(2557870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2557871, 1, "3f9d4fad1969550b121ae753b17d325350a51ed20b8f6470947d0d56ffdf3d72")
