-- Lua provided by RyzenAPI
-- Game: Game: Zquirrels Jump

-- MAIN APPLICATION
addappid(966580)
-- Game: addappid(966580)

-- MAIN APP DEPOTS / PACKAGES
addappid(966581, 1, "741f8195a29dd3ccddd299e94bac5a0a0811f08ceb2981be9e497c6a991b57fd")
