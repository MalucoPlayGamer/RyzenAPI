-- Lua provided by RyzenAPI
-- Game: addappid(610110)

-- MAIN APPLICATION
addappid(610110)

-- MAIN APP DEPOTS / PACKAGES
addappid(610111, 1, "5752cb1844869b0512dcee9cea1f31386ded13a39a7516e29ae09017ba18ef71")
