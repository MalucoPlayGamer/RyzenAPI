-- Lua provided by RyzenAPI
-- Game: addappid(771560)

-- MAIN APPLICATION
addappid(771560)

-- MAIN APP DEPOTS / PACKAGES
addappid(771561, 1, "1a825705887e4f8fe89c25a9c508cfcf4b7e8040bf8eae935def11aa8f5cdc7f")
