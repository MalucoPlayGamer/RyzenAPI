-- Lua provided by RyzenAPI
-- Game: 3057940

-- MAIN APPLICATION
addappid(3057940)
-- Game: addappid(3057940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057941, 1, "2fac392046298ee700fbbc8c895bc5736bbbd0cade98c7fe8cf9aabd1ff4a57d")
