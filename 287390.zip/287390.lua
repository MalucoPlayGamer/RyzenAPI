-- Lua provided by RyzenAPI
-- Game: Metro: Last Light Redux

-- MAIN APPLICATION
addappid(287390)

-- MAIN APP DEPOTS / PACKAGES
addappid(287391, 1, "b83248490dbb4df7788d5976584e6829597922e10fb4a9ab537e4da04c52b61b")
addappid(287392, 1, "b31b8b47d359f387ffb0f435de1b127ab2a3dfcfd16304b1d18efff394f3c7f5")
addappid(287393, 1, "fa5c1730f37f191734c73125f261a1f4d6055af0c97b73aad96a19d5f6d33beb")
addappid(287394, 1, "1c30d69b4f3d6c0c219d09fd9c9cdce42c3802d44cd76490d2be50dab0e45c9c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
