-- Lua provided by RyzenAPI
-- Game: addappid(1933780)

-- MAIN APPLICATION
addappid(1933780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933781, 1, "4baead6efae7bd3dc770a1900314d9a11ecf77e98f46a1eecb897ff4ae3991ee")
