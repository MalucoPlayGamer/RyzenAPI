-- Lua provided by RyzenAPI
-- Game: Mystic Destinies: Serendipity of Aeons

-- MAIN APPLICATION
addappid(431510)

-- MAIN APP DEPOTS / PACKAGES
addappid(431511, 1, "866fa17909b023eff78ce378c52695f36d01460fa80fd0f729f6456401bd9e02")

