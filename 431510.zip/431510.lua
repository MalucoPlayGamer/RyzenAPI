-- Lua provided by RyzenAPI
-- Game: Mystic Destinies: Serendipity of Aeons

-- MAIN APPLICATION
addappid(431510)

-- MAIN APP DEPOTS / PACKAGES
addappid(431511, 1, "866fa17909b023eff78ce378c52695f36d01460fa80fd0f729f6456401bd9e02")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(440130)
addappid(455530)
addappid(466710)
addappid(483790)
addappid(484840)
addappid(508160)
addappid(508161)
addappid(508162)
addappid(508163)
addappid(508165)
addappid(649160)
