-- Lua provided by RyzenAPI
-- Game: Bowling Over It

-- MAIN APPLICATION
addappid(1043120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1043121, 1, "bd528dd1ebd5b5fbd96e9626204565587de4f09990e32a50cce8e7693f8175fb")

