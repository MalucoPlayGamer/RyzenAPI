-- Lua provided by RyzenAPI
-- Game: Bowling Over It

-- MAIN APPLICATION
addappid(1043120)
-- Game: addappid(1043120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043121, 1, "bd528dd1ebd5b5fbd96e9626204565587de4f09990e32a50cce8e7693f8175fb")
