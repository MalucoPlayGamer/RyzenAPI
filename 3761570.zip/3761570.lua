-- Lua provided by RyzenAPI
-- Game: addappid(3761570)

-- MAIN APPLICATION
addappid(3761570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3761571, 1, "c61dde95c902ccd55d94011cad885b54cf6bbadb323665ee15fe979a9b3a4650")
