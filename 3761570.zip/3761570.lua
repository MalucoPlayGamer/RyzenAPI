-- Lua provided by RyzenAPI
-- Game: Escape30DayCircle

-- MAIN APPLICATION
addappid(3761570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3761571, 1, "c61dde95c902ccd55d94011cad885b54cf6bbadb323665ee15fe979a9b3a4650")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
