-- Lua provided by RyzenAPI
-- Game: Game: AppID 951640

-- MAIN APPLICATION
addappid(951640)
-- Game: addappid(951640)

-- MAIN APP DEPOTS / PACKAGES
addappid(951641, 1, "5f91eb960b73b4f9c3f43880419b4306921ddeb7e939715197f061818994cdf0")
