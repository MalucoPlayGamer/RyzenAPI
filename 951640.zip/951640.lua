-- Lua provided by RyzenAPI 
-- Game: AppID 951640
addappid(951640)
addappid(951641, 1, "5f91eb960b73b4f9c3f43880419b4306921ddeb7e939715197f061818994cdf0")
