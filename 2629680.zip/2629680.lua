-- Lua provided by RyzenAPI
-- Game: ATV Offroad Simulator 24

-- MAIN APPLICATION
addappid(2629680)
-- Game: addappid(2629680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629688,0,"eca826c00d03567068d7e1c13454784fbe3406ef5ccee919c3ef56ee89e9d7a2")
