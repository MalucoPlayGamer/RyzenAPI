-- Lua provided by RyzenAPI
-- Game: Hostil

-- MAIN APPLICATION
addappid(726200)
-- Game: addappid(726200)

-- MAIN APP DEPOTS / PACKAGES
addappid(726202,0,"4e53942a143c158241d258bde59a667bcbdbc1a2b50def33a9a9c54e4a2ca989")
