-- Lua provided by RyzenAPI
-- Game: 1871310

-- MAIN APPLICATION
addappid(1871310)
-- Game: addappid(1871310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871311, 1, "6a91863287d9e31f492d23ca7ec334a70c4b044017dc2f1ba449aa5b456b8bd9")
