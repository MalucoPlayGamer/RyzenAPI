-- Lua provided by RyzenAPI 
-- Game: Hook 2
addappid(1871310)
addappid(1871311, 1, "6a91863287d9e31f492d23ca7ec334a70c4b044017dc2f1ba449aa5b456b8bd9")
