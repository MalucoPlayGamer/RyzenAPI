-- Lua provided by RyzenAPI
-- Game: Aperture Desk Job

-- MAIN APPLICATION
addappid(1902490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902491, 1, "7b4bca0e4c7ec51479de7910bd8aabeaa3cd0fa7af14dc6520cf7f32579e8ef5")
addappid(1902492, 1, "a1c9040f34b5c6df6d1dbeb93ba178609b71425dfcde1d4e26ff3cb4a5885497")
addappid(1902493, 1, "0a7d2aef906f57aa620e70ca60ecbfa35dd1782932a542bfb51152b290b4334e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
