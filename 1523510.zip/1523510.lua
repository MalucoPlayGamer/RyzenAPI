-- Lua provided by RyzenAPI
-- Game: Cave Digger 2 Dig Harder

-- MAIN APPLICATION
addappid(1523510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523511, 1, "da3742d822328a2a6a6b02dbcd51017fce2c0a67fb2905fda7640a558e5d48d1")

