-- Lua provided by RyzenAPI
-- Game: AppID 269550

-- MAIN APPLICATION
addappid(269550)

-- MAIN APP DEPOTS / PACKAGES
addappid(269551, 1, "4c9f38bda241d658ae0875e53a95399ef1e3dd3713b9d20bbe917cb115db3b47")

