-- Lua provided by RyzenAPI
-- Game: Zoom Player Steam Edition

-- MAIN APPLICATION
addappid(269550)
addappid(404060)
addappid(488640)
addappid(492590)
addappid(746700)
addappid(1635910)
addappid(1637310)
addappid(1860970)
addappid(2603900)

-- MAIN APP DEPOTS / PACKAGES
addappid(269551, 1, "4c9f38bda241d658ae0875e53a95399ef1e3dd3713b9d20bbe917cb115db3b47")
