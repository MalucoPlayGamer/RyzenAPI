-- Lua provided by RyzenAPI
-- Game: Millionaire Loong

-- MAIN APPLICATION
addappid(3410950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3410950,0,"c3df4ff81eedaa744e81ce5dc963c480f6874051e801f17062ff2f54e4a26d6f")

