-- Lua provided by RyzenAPI
-- Game: addappid(2462930)

-- MAIN APPLICATION
addappid(2462930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462931, 1, "a00fd1864b54f5da42d6ad38d3c4989cdaac92a7f6239602ed09fca4a9e68c34")
