-- Lua provided by RyzenAPI
-- Game: AppID 2011520

-- MAIN APPLICATION
addappid(2011520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011521, 1, "b5e1a0c21dbb48cd705c45901f91bb6526dde0d5c0f58198ec1f11ac0b8338ca")
