-- Lua provided by RyzenAPI
-- Game: AppID 605450

-- MAIN APPLICATION
addappid(605450)
-- Game: addappid(605450)

-- MAIN APP DEPOTS / PACKAGES
addappid(605451, 1, "92f77683f8e05e7dc1671ac837b42cd05c7e40d01b159a0e72d52178784273ef")
