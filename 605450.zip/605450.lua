-- Lua provided by RyzenAPI
-- Game: In Death

-- MAIN APPLICATION
addappid(605450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(605451, 1, "92f77683f8e05e7dc1671ac837b42cd05c7e40d01b159a0e72d52178784273ef")

