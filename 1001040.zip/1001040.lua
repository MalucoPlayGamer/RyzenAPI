-- Lua provided by RyzenAPI 
-- Game: AppID 1001040
addappid(1001040)
addappid(1001041, 1, "10af493f6def5cd18f28a4d6d7845beac6aadb0d38ffd282d5295df1e994c753")
