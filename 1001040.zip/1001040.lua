-- Lua provided by RyzenAPI
-- Game: Glorious Companions

-- MAIN APPLICATION
addappid(1001040)
-- Game: addappid(1001040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001041, 1, "10af493f6def5cd18f28a4d6d7845beac6aadb0d38ffd282d5295df1e994c753")
