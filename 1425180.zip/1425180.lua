-- Lua provided by RyzenAPI
-- Game: Vessels of Decay

-- MAIN APPLICATION
addappid(1425180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425181, 1, "4777e9f37c831bd644d2310265434ec3f91e0790244a4273771453e8ff54f7db")

