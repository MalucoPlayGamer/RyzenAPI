-- Lua provided by RyzenAPI
-- Game: Fantasy World Souls

-- MAIN APPLICATION
addappid(2301370)
-- Game: addappid(2301370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301371, 1, "fc1e17ca5e35c0f5d41108266cfda7c3fb7d6cb9a61ae4862b12d80e3e145400")
