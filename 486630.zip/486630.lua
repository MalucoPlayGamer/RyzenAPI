-- Lua provided by SkyAPI 
-- Game: Toxic Terror
addappid(486630)
addappid(486631, 1, "13f60595185532ed0586cdcb8973e732e21fb56674ea802e6888c70a65f0c5d4")
addappid(571820, 0, "04b23680263bdc795da45538908ad094dc09a7534fbe3fa1f5efa6877834571d")
