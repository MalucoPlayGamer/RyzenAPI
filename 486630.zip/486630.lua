-- Lua provided by RyzenAPI
-- Game: Toxic Terror

-- MAIN APPLICATION
addappid(486630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(486631, 1, "13f60595185532ed0586cdcb8973e732e21fb56674ea802e6888c70a65f0c5d4")
addappid(571820, 0, "04b23680263bdc795da45538908ad094dc09a7534fbe3fa1f5efa6877834571d")

