-- Lua provided by SkyAPI 
-- Game: Valfaris
addappid(600130)
addappid(600131, 1, "a3beb0338b2cd8ff8b5ee0c49d788658305ec9faafe052e5e16feb68972e1c58")
addappid(1166721, 0, "9b8cf72535fd33a7d8f42b8781f3e86d8a9a8cce64482fc8bb81d163e62d61ff")
