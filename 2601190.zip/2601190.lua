-- Lua provided by RyzenAPI
-- Game: 2601190

-- MAIN APPLICATION
addappid(2601190)
-- Game: addappid(2601190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601191, 1, "2df0b6f29511ffd0902edc74722aa9b9d0ec019ea58cbf7210381a99749412c5")
