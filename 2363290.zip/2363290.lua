-- Lua provided by RyzenAPI
-- Game: Fireworks Frenzy

-- MAIN APPLICATION
addappid(2363290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363291, 1, "f5c7d0d5b607147877b2b2ee93043dba1d66a6e2cf65dc9373da86a62cd9673f")

