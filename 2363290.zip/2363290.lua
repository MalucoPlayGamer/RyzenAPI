-- Lua provided by RyzenAPI
-- Game: Fireworks Frenzy

-- MAIN APPLICATION
addappid(2363290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363291, 1, "f5c7d0d5b607147877b2b2ee93043dba1d66a6e2cf65dc9373da86a62cd9673f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
