-- Lua provided by RyzenAPI 
-- Game: AppID 780860
addappid(780860)
addappid(780861, 1, "d45f1d2c51144585140eeea11b7d4d65bc960fa5ab15ce2ea9262a50c140b434")
