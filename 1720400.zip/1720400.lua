-- Lua provided by RyzenAPI
-- Game: My Time At Sandrock - Original Soundtrack

-- MAIN APPLICATION
addappid(1720400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720401, 1, "364495165d936ac2da68067973c99e913edf26ee8e8ef51e220ce33e95fab33d")
addappid(1720402, 1, "6af6a4d4adfddd5e7d518de22f243dbd4187f1c6bea5aad0deddde0e8d15b387")

