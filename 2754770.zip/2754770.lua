-- Lua provided by RyzenAPI
-- Game: dont🔥red: SIM💾Trading

-- MAIN APPLICATION
addappid(2754770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754771, 1, "e2ae0f80102baa1bffb6b5f3cc37aefb9d300ef6a2a384ca2efa3bc25395afa7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2765550)
addappid(2765560)
addappid(2765570)
addappid(2771950)
addappid(2774640)
addappid(2793760)
