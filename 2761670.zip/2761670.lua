-- Lua provided by RyzenAPI
-- Game: Sinister Night 2

-- MAIN APPLICATION
addappid(2761670)
addappid(3088630)
addappid(3263800)
addappid(3476450)
addappid(3637500)
addappid(3705960)
addappid(3849210)
addappid(3992480)
addappid(4325620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2761671,0,"dd84f47ac8484212ed8f6d6a1c5372931a0e8b0fac876dcbc5fe2499f90f4282")

