-- Lua provided by RyzenAPI
-- Game: 2761670

-- MAIN APPLICATION
addappid(2761670)
-- Game: addappid(2761670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761671, 1, "dd84f47ac8484212ed8f6d6a1c5372931a0e8b0fac876dcbc5fe2499f90f4282")
