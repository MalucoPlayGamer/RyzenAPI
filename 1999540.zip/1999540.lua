-- Lua provided by RyzenAPI
-- Game: addappid(1999540)

-- MAIN APPLICATION
addappid(1999540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999541, 1, "db8f80e7a1784253dfc3c29109d868c44a971f6708e2ca738d875f26640bc2ac")
