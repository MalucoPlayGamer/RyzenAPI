-- Lua provided by RyzenAPI
-- Game: 1370370

-- MAIN APPLICATION
addappid(1370370)
addappid(2355420)
-- Game: addappid(1370370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370371, 1, "68497e7fa18bce471e738a1298872705e7a05fb6e43fab359f610df6e003d1f2")
