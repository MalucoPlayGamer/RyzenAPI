-- Lua provided by RyzenAPI
-- Game: Touhou Danmaku Kagura Phantasia Lost: Soundtrack

-- MAIN APPLICATION
addappid(2791070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791071, 1, "e09fb85a3e31b719cbf4874fe354e56a53e8bb6843de8a11b8ca56f1263d8212")
