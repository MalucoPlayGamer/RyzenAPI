-- Lua provided by RyzenAPI
-- Game: Lightout 2

-- MAIN APPLICATION
addappid(1988010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988011, 1, "3ad2d2c284b4005e3a38a997558c5828e7ff8e8d9b1c352c9805563c3df1cf30")
