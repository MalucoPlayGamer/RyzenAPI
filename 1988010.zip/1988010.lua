-- Lua provided by RyzenAPI
-- Game: Lightout 2

-- MAIN APPLICATION
addappid(1988010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1988011, 1, "3ad2d2c284b4005e3a38a997558c5828e7ff8e8d9b1c352c9805563c3df1cf30")

