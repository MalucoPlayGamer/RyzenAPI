-- Lua provided by SkyAPI 
-- Game: Lightout 2
addappid(1988010)
addappid(1988011, 1, "3ad2d2c284b4005e3a38a997558c5828e7ff8e8d9b1c352c9805563c3df1cf30")
