-- Lua provided by RyzenAPI
-- Game: Elf World Adventure

-- MAIN APPLICATION
addappid(2415340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415341, 1, "9a28f3b5e87fd1274ec81457962fdf423bdba02066e35a4998a50552ab74e8de")
