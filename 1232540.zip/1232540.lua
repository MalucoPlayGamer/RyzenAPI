-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: JustAsia - CYYT - St. John's International Airport

-- MAIN APPLICATION
addappid(1232540)
-- Game: addappid(1232540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232540,0,"18acd621cfde0b62850aa6cb5fcfbd6b23fd51e593546954178b64119cd825c2")
