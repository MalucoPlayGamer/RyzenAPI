-- Lua provided by RyzenAPI
-- Game: Erocism

-- MAIN APPLICATION
addappid(2961310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2961311, 1, "07121c1590f34dba2119244dd79e17b7fd3fbd902c802f60d7eec832bb731ca2")
