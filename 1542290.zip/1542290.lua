-- Lua provided by RyzenAPI
-- Game: Girls and Dragons

-- MAIN APPLICATION
addappid(1542290)
-- Game: addappid(1542290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542291, 1, "213509c33c0834159c2dd0f4cf7f15d215d3f52d6f5318c38b6569efce034de8")
