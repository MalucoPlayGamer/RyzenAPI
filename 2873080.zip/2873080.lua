-- Lua provided by RyzenAPI
-- Game: addappid(2873080)

-- MAIN APPLICATION
addappid(2873080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873081, 1, "08b343a18857a38239ec80b4280bbd5944eb618feeb2f12e2b3b3314659495df")
addappid(2873082, 1, "aeb4f9a62e8866bd9ceb98b668ebf3daf2c7ece2f0e86b6d1c2963ddccd473fe")
