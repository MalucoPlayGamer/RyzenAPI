-- Lua provided by RyzenAPI
-- Game: 224040

-- MAIN APPLICATION
addappid(224040)
addappid(228983)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(224045,0,"54229c0c4e299deea7560660da92630ba1cd73c662e403283975cec5a420de54")

