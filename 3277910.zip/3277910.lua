-- Lua provided by RyzenAPI
-- Game: The Seven Realms: High Lathión - Bonus Content

-- MAIN APPLICATION
addappid(3277910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277910,0,"69b421f48200c78c1089b0c5d4f5ea1e962a6792755fdf840950fe0380f1c549")

