-- Lua provided by RyzenAPI
-- Game: 7770

-- MAIN APPLICATION
addappid(7770)
-- Game: addappid(7770)

-- MAIN APP DEPOTS / PACKAGES
addappid(7771, 1, "5c7bf4532a5f40a416c3d2f0f2a1b2596f5414ee6dd0bfdc95747ffd989d8fe4")
