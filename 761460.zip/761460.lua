-- Lua provided by RyzenAPI
-- Game: Lamplight City

-- MAIN APPLICATION
addappid(761460)

-- MAIN APP DEPOTS / PACKAGES
addappid(761461, 1, "296fb49fdc982088f71691f386ee8a071d3f26a9abd8065bd5771914582a8a5f")
