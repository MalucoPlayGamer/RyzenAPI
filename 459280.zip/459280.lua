-- Lua provided by RyzenAPI
-- Game: addappid(459280)

-- MAIN APPLICATION
addappid(459280)

-- MAIN APP DEPOTS / PACKAGES
addappid(459281, 1, "b42eaf6ab7559694e198fb9dbbcdfd68a041102f17d3745defc0b58cf804d738")
addappid(459282, 1, "48d4c118628eb6bcc094064dc99ab7dcc9d4e0a6d89f6c46569dc44245d1ec9c")
