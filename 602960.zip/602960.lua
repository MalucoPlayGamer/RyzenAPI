-- Lua provided by RyzenAPI
-- Game: Barotrauma

-- MAIN APPLICATION
addappid(602960)
-- Game: addappid(602960)

-- MAIN APP DEPOTS / PACKAGES
addappid(602961, 1, "9548ba939f90ad1341ef0ea0125642dabf42d425fed0a4a5b2ad3d40a88af1d2")
addappid(602962, 1, "aa05725821345dfdedd93eaef1f0f4fb6e399b95cffc47dbabf9134a7eeca1d9")
addappid(602963, 1, "9420d15bdd3429b9391b475f1d1c59499535e408b59dcc0053cfa369cdbb8609")
addappid(1197650, 0, "179a1e7986e8029892a8442b25794a7e3e6ca59e33a87f8b00233ab4a8fe5ddb")
