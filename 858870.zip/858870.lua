-- Lua provided by RyzenAPI
-- Game: Queen of Seas 2

-- MAIN APPLICATION
addappid(858870)
addappid(876550)
addappid(877130)

-- MAIN APP DEPOTS / PACKAGES
addappid(858871, 1, "0871075dd236fcfd43cdcef15787c5c875ef6ec5cd267a22a64aa08059bf1315")

