-- Lua provided by RyzenAPI
-- Game: The Last Stand

-- MAIN APPLICATION
addappid(1627410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627411, 1, "8f59ff24d7ac05b1fe970cedb9e8f416edf0208466e60a33dcbdd2c1a8f6364a")
