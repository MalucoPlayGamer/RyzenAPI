-- Lua provided by RyzenAPI
-- Game: The Last Stand

-- MAIN APPLICATION
addappid(1627410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1627411, 1, "8f59ff24d7ac05b1fe970cedb9e8f416edf0208466e60a33dcbdd2c1a8f6364a")

