-- Lua provided by RyzenAPI
-- Game: oldbI tyt ?

-- MAIN APPLICATION
addappid(1006270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006271, 1, "3d2927812e2b209d0810f8b6cca4ce5440d2be98f0cd5a6ed15d4123c54757d1")
