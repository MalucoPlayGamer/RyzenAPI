-- Lua provided by RyzenAPI
-- Game: addappid(2545460)

-- MAIN APPLICATION
addappid(2545460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545461, 1, "c28e5e6ef93605a150e20548c93c6df1888decd82093d713f86216f038e4d4dd")
