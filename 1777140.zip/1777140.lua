-- Lua provided by RyzenAPI
-- Game: Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles: Avatar 2 Pack

-- MAIN APPLICATION
addappid(1777140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777140,0,"010c8f072b3fc9a3f7b089be2e56dedc947bc221f9bf5ee6e98bb09bc6d0b032")

