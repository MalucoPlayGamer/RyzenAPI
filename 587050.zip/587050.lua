-- Lua provided by RyzenAPI
-- Game: 587050

-- MAIN APPLICATION
addappid(587050)
-- Game: addappid(587050)

-- MAIN APP DEPOTS / PACKAGES
addappid(587051, 1, "fd55c7b9114c4f48c1ba6d6ab51df590fd38938131e1617aa0ae55ec25aec3b5")
