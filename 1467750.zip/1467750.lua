-- Lua provided by RyzenAPI
-- Game: 1467750

-- MAIN APPLICATION
addappid(1467750)
-- Game: addappid(1467750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467751, 1, "712e7755ca375a8e739d7cc5f8bf3bd2fc0d5e9ebfed6aa91376375c647d761d")
