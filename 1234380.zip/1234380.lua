-- Lua provided by RyzenAPI
-- Game: addappid(1234380)

-- MAIN APPLICATION
addappid(1234380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234381, 1, "cc3ea3e0694bab56d1c410e873779f83bd1ebbf5dd12e58d6ec814cf7dd5c49c")
