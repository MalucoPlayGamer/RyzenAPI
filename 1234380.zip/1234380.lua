-- Lua provided by RyzenAPI
-- Game: Era of Survival

-- MAIN APPLICATION
addappid(1234380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1234381, 1, "cc3ea3e0694bab56d1c410e873779f83bd1ebbf5dd12e58d6ec814cf7dd5c49c")

