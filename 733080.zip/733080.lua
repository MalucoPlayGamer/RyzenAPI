-- Lua provided by RyzenAPI
-- Game: addappid(733080)

-- MAIN APPLICATION
addappid(733080)

-- MAIN APP DEPOTS / PACKAGES
addappid(733081, 1, "0a859327ef065fc95a7fe25ca482f5e09fe7a0803ec0523cdbd1a19156d12563")
