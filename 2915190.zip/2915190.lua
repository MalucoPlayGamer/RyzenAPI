-- Lua provided by RyzenAPI
-- Game: Resonance chain

-- MAIN APPLICATION
addappid(2915190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2915191, 1, "453ea4d7a13cc5bb00319773cb19ede8435eb7e53ff7f1f5eb990f551d318895")

