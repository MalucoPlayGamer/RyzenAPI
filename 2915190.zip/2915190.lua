-- Lua provided by RyzenAPI 
-- Game: Resonance chain
addappid(2915190)
addappid(2915191, 1, "453ea4d7a13cc5bb00319773cb19ede8435eb7e53ff7f1f5eb990f551d318895")
