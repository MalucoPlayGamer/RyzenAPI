-- Lua provided by RyzenAPI
-- Game: addappid(2915190)

-- MAIN APPLICATION
addappid(2915190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2915191, 1, "453ea4d7a13cc5bb00319773cb19ede8435eb7e53ff7f1f5eb990f551d318895")
