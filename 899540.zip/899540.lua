-- Lua provided by RyzenAPI 
-- Game: PROTEST
addappid(899540)
addappid(899541, 1, "3244766ac47c9242a8d20221b838cb0341d989ac3787b24a4d3c5dea239407d1")
