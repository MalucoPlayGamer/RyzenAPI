-- Lua provided by RyzenAPI
-- Game: Game: PROTEST

-- MAIN APPLICATION
addappid(899540)
-- Game: addappid(899540)

-- MAIN APP DEPOTS / PACKAGES
addappid(899541, 1, "3244766ac47c9242a8d20221b838cb0341d989ac3787b24a4d3c5dea239407d1")
