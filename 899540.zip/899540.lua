-- Lua provided by RyzenAPI
-- Game: PROTEST

-- MAIN APPLICATION
addappid(899540)

-- MAIN APP DEPOTS / PACKAGES
addappid(899541, 1, "3244766ac47c9242a8d20221b838cb0341d989ac3787b24a4d3c5dea239407d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
