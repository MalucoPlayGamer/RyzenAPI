-- Lua provided by RyzenAPI
-- Game: Game: Hyper Frenzy

-- MAIN APPLICATION
addappid(1653360)
-- Game: addappid(1653360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653361, 1, "ab38dfc3586cbe367d166d3b6494795cec02154583cb0726898accd3b15d86a6")
