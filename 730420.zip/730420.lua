-- Lua provided by RyzenAPI
-- Game: Combine War Toys

-- MAIN APPLICATION
addappid(730420)

-- MAIN APP DEPOTS / PACKAGES
addappid(730421,0,"e48297de1c027b40fe37f27a5ae384179468d0c39d8941cdab5b5ee5d7d408c4")

