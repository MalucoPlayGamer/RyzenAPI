-- Lua provided by RyzenAPI
-- Game: BLOKI

-- MAIN APPLICATION
addappid(2585380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585381, 1, "65e5b255f859477ec3be9ad8a79db0dcd6252e062a1395cf6fa17c9f2f095e18")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
