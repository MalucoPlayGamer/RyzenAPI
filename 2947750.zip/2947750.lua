-- Lua provided by RyzenAPI
-- Game: Hidden Old House Top-Down 3D

-- MAIN APPLICATION
addappid(2947750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947751, 1, "d144003a7b9ec62f8c0b725e4649b94b84f3aa76e58211a4b46deac772df7176")
