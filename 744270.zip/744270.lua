-- Lua provided by RyzenAPI
-- Game: Rise of Ages

-- MAIN APPLICATION
addappid(744270)

-- MAIN APP DEPOTS / PACKAGES
addappid(744271, 1, "fe3bd95e57e591a1899e4f7e5bee5b48a4a4ddf7266d4c29ab6f9a5620e9fa0c")
