-- Lua provided by RyzenAPI
-- Game: Gravity Force

-- MAIN APPLICATION
addappid(2519290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2519291, 1, "4bbaf23914eb68898c06c277cd0d57a30193a44809634263d825c98b179fa62f")

