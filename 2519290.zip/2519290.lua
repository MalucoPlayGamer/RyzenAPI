-- Lua provided by RyzenAPI
-- Game: Gravity Force

-- MAIN APPLICATION
addappid(2519290)
-- Game: addappid(2519290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519291, 1, "4bbaf23914eb68898c06c277cd0d57a30193a44809634263d825c98b179fa62f")
