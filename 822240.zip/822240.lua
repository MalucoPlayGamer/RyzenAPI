-- Lua provided by RyzenAPI
-- Game: 822240

-- MAIN APPLICATION
addappid(822240)
-- Game: addappid(822240)

-- MAIN APP DEPOTS / PACKAGES
addappid(822241, 1, "8cea4d4a6a5b62151393c35dbfb12ae7d47fb15f124d417867d12028006e3fea")
addappid(822242, 1, "cba73071c79d4464923cc9c9ed50a50beb65bc90de9cf07304b46023635fa619")
