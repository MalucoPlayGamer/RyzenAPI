-- Lua provided by RyzenAPI
-- Game: Animal Jam

-- MAIN APPLICATION
addappid(822240)

-- MAIN APP DEPOTS / PACKAGES
addappid(822241, 1, "8cea4d4a6a5b62151393c35dbfb12ae7d47fb15f124d417867d12028006e3fea")
addappid(822242, 1, "cba73071c79d4464923cc9c9ed50a50beb65bc90de9cf07304b46023635fa619")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
