-- Lua provided by RyzenAPI
-- Game: A Little Time

-- MAIN APPLICATION
addappid(1628650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628651, 1, "42092263675628f40dd2b150c37b69b3d17af0ae5942202f33005bfb41adc839")

