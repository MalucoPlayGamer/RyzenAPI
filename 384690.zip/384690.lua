-- Lua provided by RyzenAPI
-- Game: 384690

-- MAIN APPLICATION
addappid(384690)
-- Game: addappid(384690)

-- MAIN APP DEPOTS / PACKAGES
addappid(384691, 1, "c62885b54a2db573736db3d69438a29ed8a609be388ee3868bc37e222f1919d8")
