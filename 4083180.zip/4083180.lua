-- Lua provided by RyzenAPI
-- Game: My Adorable Ghost Story

-- MAIN APPLICATION
addappid(4083180) -- My Adorable Ghost Story

-- MAIN APP DEPOTS / PACKAGES
addappid(4083181, 1, "961024c2b474634311ba83a8ea7935983881e3cb937c9abff00d93d2d67b1081") -- Depot 4083181
addappid(4083182, 1, "b477e79a612658af5ff7435283cd2011937219e3f97fd9d52c94ad027cc0ff2b") -- Depot 4083182
addappid(4083183, 1, "1df1317c741bea79dfb0dcac6239b0ba8bf09a93469bdabfd5199a0497309151") -- Depot 4083183