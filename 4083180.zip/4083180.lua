-- 4083180's Lua and Manifest Created by Hubcap Manifest
-- My Adorable Ghost Story
-- Created: August 29, 2026 at 01:09:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4083180) -- My Adorable Ghost Story
-- MAIN APP DEPOTS
addappid(4083181, 1, "961024c2b474634311ba83a8ea7935983881e3cb937c9abff00d93d2d67b1081") -- Depot 4083181
setManifestid(4083181, "5376312165629272706", 234598850)
addappid(4083182, 1, "b477e79a612658af5ff7435283cd2011937219e3f97fd9d52c94ad027cc0ff2b") -- Depot 4083182
setManifestid(4083182, "5591165169020770527", 216119046)
addappid(4083183, 1, "1df1317c741bea79dfb0dcac6239b0ba8bf09a93469bdabfd5199a0497309151") -- Depot 4083183
setManifestid(4083183, "8629424411930175444", 215042812)