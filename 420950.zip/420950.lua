-- Lua provided by RyzenAPI
-- Game: Time Tenshi (2015)

-- MAIN APPLICATION
addappid(420950)

-- MAIN APP DEPOTS / PACKAGES
addappid(420951, 1, "2dd48c42458c17ac14aebef420c27aec31334562d6d501b128f6b365e828265c")

