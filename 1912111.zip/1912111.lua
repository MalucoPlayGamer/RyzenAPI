-- Lua provided by RyzenAPI
-- Game: 1912111

-- MAIN APPLICATION
addappid(1912111)
-- Game: addappid(1912111)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912111,0,"3bd1a6d9aefcd4c3a308a425344e31e647c9d2651d4d1904231c7b5fd314a0ef")
