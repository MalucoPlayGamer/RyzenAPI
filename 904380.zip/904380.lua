-- Lua provided by RyzenAPI
-- Game: Game: Vambrace: Cold Soul

-- MAIN APPLICATION
addappid(904380)
-- Game: addappid(904380)

-- MAIN APP DEPOTS / PACKAGES
addappid(904381, 1, "1be4bb145da55d50c0ce81755f61249d708a9f2c57ec912ce8f734bf8e9cf959")
addappid(904382, 1, "67e70294559e020c0e082bb11ccd26a3e77018f3b41a822a24d39292edf12a74")
addappid(904383, 1, "4a4b80913423e62cdbef867c433f6f0d63c1f20291a6a5d30a607835c7674be0")
addappid(904384, 1, "b75e9208eb9174961c7b17de1511e0c98b248e2550ea1977c637d2bef6d0a22e")
