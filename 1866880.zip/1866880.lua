-- Lua provided by RyzenAPI
-- Game: 1866880

-- MAIN APPLICATION
addappid(1866880)
-- Game: addappid(1866880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866881, 1, "030d43aa16163f1360a017db00e68adaf3a1953a22de98b7ba99862192e33e04")
