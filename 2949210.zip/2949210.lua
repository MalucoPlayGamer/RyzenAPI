-- Lua provided by SkyAPI 
-- Game: The Hungry Lamb: Traveling in the Late Ming Dynasty (Original Soundtrack)
addappid(2949210)
addappid(2949211, 1, "2c677de37ebdff5eb3e320373750d234b35c7543d69d71528699e7c796086dfa")
addappid(2949212, 1, "1ac2f95e1efe601967d8a42205d2f73dfad60c5ea2d2bb53e44ff7ebb6efbed0")
