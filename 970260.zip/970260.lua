-- Lua provided by RyzenAPI
-- Game: Game: AppID 970260

-- MAIN APPLICATION
addappid(970260)
-- Game: addappid(970260)

-- MAIN APP DEPOTS / PACKAGES
addappid(970261, 1, "ff8ba3c841598cd8698ebafa8d5e66becb048da6b63d01b7f8cb3c64a99b6429")
