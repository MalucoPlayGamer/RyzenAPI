-- Lua provided by RyzenAPI
-- Game: 2491270

-- MAIN APPLICATION
addappid(2491270)
-- Game: addappid(2491270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491271, 1, "b9b5ef225b731a36656f60f5e20f84ec2fdcd88c7af972b071d2a45580a73037")
