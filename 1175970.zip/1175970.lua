-- Lua provided by RyzenAPI
-- Game: Hibiscus Red

-- MAIN APPLICATION
addappid(1175970)
addappid(1241080)
-- Game: addappid(1175970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175971, 1, "be692f1658ecf88dce09a1fdfc457045d8d47f5489bcafb1cba1ae38c9d0a320")
