-- Lua provided by RyzenAPI
-- Game: 東方苦粗芸物語 Touhou KSG Story

-- MAIN APPLICATION
addappid(992720)

-- MAIN APP DEPOTS / PACKAGES
addappid(992721, 1, "bc893dddd3ed97f76ab6e7e262bb4ce001c33821000159e95084a168159b92f6")
