-- Lua provided by RyzenAPI
-- Game: Created: October 01, 2025 at 11:52:25 EDT

-- MAIN APPLICATION
addappid(992720) -- 東方苦粗芸物語 Touhou KSG Story
addappid(1012760)
-- addappid(994840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
addappid(992721, 1, "bc893dddd3ed97f76ab6e7e262bb4ce001c33821000159e95084a168159b92f6") -- 東方苦粗芸物語 Touhou KSG Story Content
addappid(1012760, 1, "9232b86b359ee5a46c40cbc210cbfad2d075da05db128a89305fe7ddd84c0f39") --  Touhou KSG Story DLC - 東方高枝切鋏 Touhou KSG Story DLC デポ

