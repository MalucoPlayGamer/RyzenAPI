-- Lua provided by SkyAPI 
-- Game: Soulflow
addappid(1822900)
addappid(1822901, 1, "97b4a09a4a942954aa6f0a31e67a3578e536e5c93540c63f9149f977650b4ad7")
