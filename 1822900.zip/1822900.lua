-- Lua provided by RyzenAPI
-- Game: Soulflow

-- MAIN APPLICATION
addappid(1822900)
-- Game: addappid(1822900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822901, 1, "97b4a09a4a942954aa6f0a31e67a3578e536e5c93540c63f9149f977650b4ad7")
