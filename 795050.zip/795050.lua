-- Lua provided by RyzenAPI
-- Game: Techno Boy

-- MAIN APPLICATION
addappid(795050)

-- MAIN APP DEPOTS / PACKAGES
addappid(795051, 1, "cf9145d9211a2c827615bd75f2765301a69bc90d799862db3590b9bfa3d5fc09")
