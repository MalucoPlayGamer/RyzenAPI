-- Lua provided by RyzenAPI
-- Game: Supraland Six Inches Under

-- MAIN APPLICATION
addappid(1522870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522871, 1, "b787c83a3dbe5e5d088f2a22a71a29a9d6e4d51b0faf1d84b5bee06b8f25b5cd")
