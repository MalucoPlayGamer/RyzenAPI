-- Lua provided by RyzenAPI
-- Game: Supraland Six Inches Under

-- MAIN APPLICATION
addappid(1522870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522871, 1, "b787c83a3dbe5e5d088f2a22a71a29a9d6e4d51b0faf1d84b5bee06b8f25b5cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
