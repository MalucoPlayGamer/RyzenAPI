-- Lua provided by RyzenAPI
-- Game: Respark Demo

-- MAIN APPLICATION
addappid(3204890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204891, 1, "6d2f1be4231a360664b8782baf7996433bf22c81cf4a827302776a6c0f76ab39")

