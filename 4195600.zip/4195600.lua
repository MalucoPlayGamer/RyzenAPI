-- Lua provided by RyzenAPI
-- Game: AFK Journey

-- MAIN APPLICATION
addappid(4195600)
