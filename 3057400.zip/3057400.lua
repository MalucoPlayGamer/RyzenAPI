-- Lua provided by RyzenAPI
-- Game: Zombie War:New World

-- MAIN APPLICATION
addappid(3057400)
-- Game: addappid(3057400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057401, 1, "e8a27943cb2acd40759a12aa97189d2f84019dc6b7869cb7442e9d558e336c72")
