-- Lua provided by RyzenAPI
-- Game: Dungeon Slime:  Puzzle's Adventure

-- MAIN APPLICATION
addappid(1455230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1455231, 1, "454214e12ee0fa2a67a51e3266cf6b95131c2bf7c50823c86d5a2f7567862dae")

