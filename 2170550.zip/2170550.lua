-- Lua provided by RyzenAPI
-- Game: Shattered Heaven Demo

-- MAIN APPLICATION
addappid(2170550)
-- Game: addappid(2170550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170551, 1, "651f5dbc9b3fa3e410fe580222d3b24daf4d26dd9d90ce6026073e22d8073d7f")
