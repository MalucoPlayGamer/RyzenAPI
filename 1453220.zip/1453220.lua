-- Lua provided by RyzenAPI
-- Game: addappid(1453220)

-- MAIN APPLICATION
addappid(1453220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453221, 1, "efb470de39ec7eae9069dbcd1f059195d63ee98a46f61ed9f6bd48d632102fa4")
