-- 4228920's Lua and Manifest Created by Hubcap Manifest
-- No More Slimes!!
-- Created: July 23, 2026 at 10:48:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4228920, 1, "afc3c29ccda3b82a28b8900c54a15571d77a16c9e090030ac7e9ac97f1d557b3") -- No More Slimes!!
-- MAIN APP DEPOTS
addappid(4228921, 1, "b595b63408d28778bb8f9aacc77895a7849b7555a7ef1f685227261c2f3466bd") -- Depot 4228921
setManifestid(4228921, "374807772060595454", 155579424)
addappid(4228922, 1, "4e326835413d60a85c7931ba4acf5177f4a25458ff736254a0bcb8428684009b") -- Depot 4228922
setManifestid(4228922, "2005368253551332360", 151931804)
addappid(4228923, 1, "f363a6bc07d37ce0c114fd13fa85e92f0429efc6e3eab6e06c752aaf01b57db7") -- Depot 4228923
setManifestid(4228923, "636279654341159447", 173036904)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4838240) --   -    