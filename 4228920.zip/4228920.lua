-- 4228920's Lua and Manifest Created by Hubcap Manifest
-- Slime Tempest
-- Created: June 16, 2026 at 09:04:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4228920) -- Slime Tempest
-- MAIN APP DEPOTS
addappid(4228921, 1, "b595b63408d28778bb8f9aacc77895a7849b7555a7ef1f685227261c2f3466bd") -- Depot 4228921
-- setManifestid(4228921, "2384307966210410183", 152246036)
addappid(4228922, 1, "4e326835413d60a85c7931ba4acf5177f4a25458ff736254a0bcb8428684009b") -- Depot 4228922
-- setManifestid(4228922, "4647944131112226860", 148618448)
addappid(4228923, 1, "f363a6bc07d37ce0c114fd13fa85e92f0429efc6e3eab6e06c752aaf01b57db7") -- Depot 4228923
-- setManifestid(4228923, "9112740833644880174", 170167197)