-- Lua provided by RyzenAPI
-- Game: Sinderfury

-- MAIN APPLICATION
addappid(1925740)
-- Game: addappid(1925740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925741, 1, "49db88fabca21b41fbda6427c8419f80e79c63d6a92b40b7036439f198f36e46")
