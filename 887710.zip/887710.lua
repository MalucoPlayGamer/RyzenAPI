-- Lua provided by RyzenAPI
-- Game: Ritter

-- MAIN APPLICATION
addappid(887710)
-- Game: addappid(887710)

-- MAIN APP DEPOTS / PACKAGES
addappid(887711, 1, "0990d1f77b0a0de7d6fa710764e086e9544e53d3b26cf99a685050cc5e9137b9")
