-- Lua provided by RyzenAPI
-- Game: Breakout: Recharged

-- MAIN APPLICATION
addappid(1714190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714191, 1, "f6801729df6a7f5fac85862294b7b8bb4e630d6a4647f732aed9963060caa05b")

