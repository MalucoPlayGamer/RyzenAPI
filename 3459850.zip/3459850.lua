-- Lua provided by RyzenAPI
-- Game: Monster Girl Saga: Fallen Heroes

-- MAIN APPLICATION
addappid(3459850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3459851, 1, "b40cca8a471e5fc042be13e34a521d5e89b6c931ae17c412ff564056787bf95e")
