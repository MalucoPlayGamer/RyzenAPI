-- Lua provided by RyzenAPI
-- Game: addappid(1377750)

-- MAIN APPLICATION
addappid(1377750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377750,0,"586ef255dc6f314bab1896f9841fbbfc26c2894468b2a9979d1b322beafe4b8b")
