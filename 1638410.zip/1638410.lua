-- Lua provided by RyzenAPI
-- Game: Game: AppID 1638410

-- MAIN APPLICATION
addappid(1638410)
-- Game: addappid(1638410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638411, 1, "4c50c9fd5278bee6ad607f80ed269f6760fc564446284f824170e64174dcbb4e")
