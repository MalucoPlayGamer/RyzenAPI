-- Lua provided by RyzenAPI
-- Game: 1450080

-- MAIN APPLICATION
addappid(1450080)
-- Game: addappid(1450080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450081, 1, "7057395db03f63afb71bc7b71bfa299dd9e5eef35b5f5e19f6d283470df4cc8e")
