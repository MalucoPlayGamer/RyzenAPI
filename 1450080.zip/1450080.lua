-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Sen no Kiseki III

-- MAIN APPLICATION
addappid(1450080)
addappid(1555250)
addappid(1555251)
addappid(1555260)
addappid(1555261)
addappid(1555263)
addappid(3464310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1450081, 1, "7057395db03f63afb71bc7b71bfa299dd9e5eef35b5f5e19f6d283470df4cc8e")

