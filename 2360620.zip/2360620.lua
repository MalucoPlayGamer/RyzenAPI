-- Lua provided by RyzenAPI 
-- Game: The Queendom of Lithzena
addappid(2360620)
addappid(2360621, 1, "0a864edfa61a27bbd0c7abccc3d6c2e3d6dbbddc9973adcc0f52af78b8e767be")
