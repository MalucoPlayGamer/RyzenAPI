-- Lua provided by RyzenAPI
-- Game: Sentinel 4: Dark Star

-- MAIN APPLICATION
addappid(386840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(386841, 1, "cf09514a2d8aea2493a5fd08da988836175ee68b75b5f50499624a2a372c5aaa")

