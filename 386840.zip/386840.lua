-- Lua provided by RyzenAPI
-- Game: Sentinel 4: Dark Star

-- MAIN APPLICATION
addappid(386840)

-- MAIN APP DEPOTS / PACKAGES
addappid(386841, 1, "cf09514a2d8aea2493a5fd08da988836175ee68b75b5f50499624a2a372c5aaa")

