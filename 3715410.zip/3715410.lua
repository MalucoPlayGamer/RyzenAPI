-- 3715410's Lua and Manifest Created by Hubcap Manifest
-- Cavernreach
-- Created: August 03, 2026 at 22:43:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3715410) -- Cavernreach
-- MAIN APP DEPOTS
addappid(3715411, 1, "d046362605e70a418be93e395c06940bd67715003578d51b86b416ed123a469f") -- Depot 3715411
setManifestid(3715411, "4212821810620051984", 4571171081)