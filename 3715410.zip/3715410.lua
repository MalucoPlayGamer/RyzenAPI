-- Lua provided by RyzenAPI
-- Game: Cavernreach

-- MAIN APPLICATION
addappid(3715410) -- Cavernreach

-- MAIN APP DEPOTS / PACKAGES
addappid(3715411, 1, "d046362605e70a418be93e395c06940bd67715003578d51b86b416ed123a469f") -- Depot 3715411

