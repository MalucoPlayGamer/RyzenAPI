-- Lua provided by RyzenAPI
-- Game: Combat Arms: the Classic

-- MAIN APPLICATION
addappid(1263550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263551, 1, "72eae8c22287d4eff90915a671f7f2c1552096730e83974949117f8d30cdc4fd")
