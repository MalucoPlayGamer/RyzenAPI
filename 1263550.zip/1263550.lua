-- Lua provided by RyzenAPI
-- Game: Combat Arms: the Classic

-- MAIN APPLICATION
addappid(1263550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263551, 1, "72eae8c22287d4eff90915a671f7f2c1552096730e83974949117f8d30cdc4fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
