-- Lua provided by RyzenAPI
-- Game: 2369750

-- MAIN APPLICATION
addappid(2369750)
addappid(2608690)
-- Game: addappid(2369750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369751, 1, "fd8e36e59af082a9e2be28292ad719772c10377e68b64d737898068f6a56c875")
