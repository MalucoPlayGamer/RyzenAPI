-- Lua provided by RyzenAPI
-- Game: The Ship: Remasted

-- MAIN APPLICATION
addappid(383790)

-- MAIN APP DEPOTS / PACKAGES
addappid(383791, 1, "78521ccab8542d74a63c09e0e89b6d0fe8f9ce5709d5dcc65f9b5dc2352a7600")

