-- Lua provided by RyzenAPI
-- Game: addappid(2868820)

-- MAIN APPLICATION
addappid(2868820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868821, 1, "a099d47a3a3a9679806e24d4f4431de82a85e06dfcb6d672e90bade0d12882a3")
