-- Lua provided by RyzenAPI
-- Game: My Darkest Witch

-- MAIN APPLICATION
addappid(2207120)
-- Game: addappid(2207120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207121, 1, "092f9cc9c060c4c9b777678cf52453bb15416fb64bda0a9f3b131ea8ef050f54")
