-- Lua provided by RyzenAPI
-- Game: LUST Eternal 🔞

-- MAIN APPLICATION
addappid(3571560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3571561, 1, "53e1e960171a813b21c2e3fd6af04b59d15deccc6350fcf6e3e1cc96801a4f7e")

