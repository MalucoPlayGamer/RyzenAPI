-- Lua provided by RyzenAPI
-- Game: addappid(3571560)

-- MAIN APPLICATION
addappid(3571560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3571561, 1, "53e1e960171a813b21c2e3fd6af04b59d15deccc6350fcf6e3e1cc96801a4f7e")
