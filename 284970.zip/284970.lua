-- Lua provided by RyzenAPI
-- Game: Project Root

-- MAIN APPLICATION
addappid(284970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(284971, 1, "ec8beae129aafbdc8cad2a1d9aa7c5c28e91444bd3ef17304cc3e5116c7ad947")
