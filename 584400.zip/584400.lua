-- Lua provided by RyzenAPI
-- Game: Sonic Mania

-- MAIN APPLICATION
addappid(584400)
addappid(845640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(584401, 1, "bb1637eb4c893c31ad5b560a6d53f01f665438e9f4deab4db1939b18d631a571")
