-- Lua provided by RyzenAPI
-- Game: AppID 584400

-- MAIN APPLICATION
addappid(584400)
addappid(845640)
-- Game: addappid(584400)

-- MAIN APP DEPOTS / PACKAGES
addappid(584401, 1, "bb1637eb4c893c31ad5b560a6d53f01f665438e9f4deab4db1939b18d631a571")
