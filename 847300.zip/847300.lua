-- Lua provided by RyzenAPI 
-- Game: AppID 847300
addappid(847300)
addappid(847301, 1, "1d53cc950fa6a481e25f76dcb9f188c65db69f63ad52913cd48c9ab84794da60")
