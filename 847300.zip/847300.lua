-- Lua provided by RyzenAPI
-- Game: Game: AppID 847300

-- MAIN APPLICATION
addappid(847300)
-- Game: addappid(847300)

-- MAIN APP DEPOTS / PACKAGES
addappid(847301, 1, "1d53cc950fa6a481e25f76dcb9f188c65db69f63ad52913cd48c9ab84794da60")
