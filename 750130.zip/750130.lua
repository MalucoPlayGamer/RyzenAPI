-- Lua provided by RyzenAPI
-- Game: The Sinking City Remastered

-- MAIN APPLICATION
addappid(750130)
-- Game: addappid(750130)

-- MAIN APP DEPOTS / PACKAGES
addappid(750131, 1, "47a72920d4c72af7e8407a617881be6fa81aaaf4f4334c27bc6ce0844890add5")
addappid(750132, 1, "33dc940870d31a3fff549c22816fa9a2170b5a3c87d60ea2d4d66565fa1520b7")
addappid(750133, 1, "da21083938e32867b6b9190a5f7ae54c1b716b6d74df27516a589f9f0cb9d4f5")
addappid(750134, 1, "b261bbaefbb88b1aa01e939cd69c807fa2d63383f8971c96a563b816db403e92")
