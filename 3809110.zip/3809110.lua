-- Lua provided by RyzenAPI
-- Game: 3809110

-- MAIN APPLICATION
addappid(3809110)
-- Game: addappid(3809110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3809111, 1, "2e17755ea4a2836a0d38a614a7686c6c77f4c392cbd35ae322035ab1bee06d45")
