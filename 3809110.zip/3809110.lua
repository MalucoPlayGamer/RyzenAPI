-- Lua provided by RyzenAPI
-- Game: Japan Stigmatized Property -日本事故物件監視協会-

-- MAIN APPLICATION
addappid(3809110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3809111, 1, "2e17755ea4a2836a0d38a614a7686c6c77f4c392cbd35ae322035ab1bee06d45")

