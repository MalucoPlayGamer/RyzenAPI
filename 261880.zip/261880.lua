-- Lua provided by RyzenAPI
-- Game: Corporate Lifestyle Simulator

-- MAIN APPLICATION
addappid(261880)
addappid(285470)

-- MAIN APP DEPOTS / PACKAGES
addappid(261881, 1, "c1f72a48e791360f5b24267e73d093a7effc315aae15136c03553f9a0281a779")
