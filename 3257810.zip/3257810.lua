-- Lua provided by RyzenAPI
-- Game: Game: AppID 3257810

-- MAIN APPLICATION
addappid(3257810)
-- Game: addappid(3257810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3257811, 1, "251db9b7e9c9e14475ad194260636703e3ab8f0b6e3772708f1cfd61df8a702e")
