-- Lua provided by RyzenAPI
-- Game: 1838190

-- MAIN APPLICATION
addappid(1838190)
-- Game: addappid(1838190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838191, 1, "e9c6abda122b743030aeeb924a19d2ae519a15d3ed7411d8a5297762048837df")
