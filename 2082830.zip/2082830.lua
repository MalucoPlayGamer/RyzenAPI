-- Lua provided by RyzenAPI
-- Game: AppID 2082830

-- MAIN APPLICATION
addappid(2082830)
-- Game: addappid(2082830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082831, 1, "e9ef67b2b284ad7743d3fb7062264edb973191f53ce87b56ef2416bb70652386")
