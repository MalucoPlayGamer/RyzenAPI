-- Lua provided by RyzenAPI 
-- Game: Kronos
addappid(1866640)
addappid(1866641, 1, "23206d2b202bdb9b901c6c496ccd99ee69ff04a19c108987812ac5ee3e0ba4f8")
