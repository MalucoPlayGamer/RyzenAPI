-- Lua provided by RyzenAPI
-- Game: Cosmic collapse

-- MAIN APPLICATION
addappid(860000)
-- Game: addappid(860000)

-- MAIN APP DEPOTS / PACKAGES
addappid(860001, 1, "00c742c677852ead1798f185c7b034de10a99e24d8bb9cab3d5e8ff2aa3b6631")
