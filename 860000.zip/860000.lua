-- Lua provided by SkyAPI 
-- Game: Cosmic collapse
addappid(860000)
addappid(860001, 1, "00c742c677852ead1798f185c7b034de10a99e24d8bb9cab3d5e8ff2aa3b6631")
