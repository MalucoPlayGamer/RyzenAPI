-- Lua provided by RyzenAPI
-- Game: 3274240

-- MAIN APPLICATION
addappid(3274240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274240,0,"adc56c555ff204bf88f0c9a015d39d58f82e8cf71f8bbf6f6d0361c58449e8df")
