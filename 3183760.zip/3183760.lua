-- Lua provided by RyzenAPI
-- Game: SpeedRunners 2: King of Speed

-- MAIN APPLICATION
addappid(3183760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183761, 1, "13869187aea1bbdee5c8171132dcf0121bfaffb4de8081470fbb5164e8a8d21c")
