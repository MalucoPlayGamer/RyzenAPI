-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3061310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3061313,0,"338392f23b23d71d96488bbce2befb882f562a45b44587f0a1365979bf44548b")

