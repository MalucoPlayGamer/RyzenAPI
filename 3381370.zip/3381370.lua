-- 3381370's Lua and Manifest Created by Hubcap Manifest
-- Breachwalk Survivor
-- Created: July 29, 2026 at 05:14:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3381370) -- Breachwalk Survivor
-- MAIN APP DEPOTS
addappid(3381371, 1, "daf63435ef5e368aba47354de7fb5edd6e5ee97f37ad52fad824d73ce4f7dd68") -- Depot 3381371
setManifestid(3381371, "2857945612392304256", 935025717)