-- Lua provided by RyzenAPI
-- Game: Power Chord

-- MAIN APPLICATION
addappid(1724390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724391, 1, "9fbfa3cd2c1b7c17569c2ba67fe3ec930529094ceedb4dd7fcdd7aad7da5f5f6")

