-- Lua provided by RyzenAPI
-- Game: Power Chord

-- MAIN APPLICATION
addappid(1724390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1724391, 1, "9fbfa3cd2c1b7c17569c2ba67fe3ec930529094ceedb4dd7fcdd7aad7da5f5f6")

