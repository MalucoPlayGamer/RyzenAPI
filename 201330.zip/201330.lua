-- Lua provided by RyzenAPI
-- Game: AppID 201330

-- MAIN APPLICATION
addappid(201330)
-- Game: addappid(201330)

-- MAIN APP DEPOTS / PACKAGES
addappid(201331, 1, "b68ccfd39f75859ea9a0752a742654157f2ec83b9349399c1fa210599f46d3d5")
