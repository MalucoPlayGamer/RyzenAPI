-- Lua provided by RyzenAPI
-- Game: addappid(3731240)

-- MAIN APPLICATION
addappid(3731240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3731241, 1, "e90625fc6f1feabcf8d072c72ee8cff50ff96709b08a68f07661c42fb45df8bb")
