-- Lua provided by RyzenAPI
-- Game: Injection No.9 - Chapter 1 (The Prologue)

-- MAIN APPLICATION
addappid(3731240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3731241, 1, "e90625fc6f1feabcf8d072c72ee8cff50ff96709b08a68f07661c42fb45df8bb")
