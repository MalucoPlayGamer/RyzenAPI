-- Lua provided by RyzenAPI
-- Game: Ghosts 'n Goblins Resurrection

-- MAIN APPLICATION
addappid(1375400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375401, 1, "f362b285b7c5d5b8f4c09c292f4bdd7543e2e396452ef0626b4fd077d378ee5e")
addappid(1375403, 1, "b5f3d5fea5b0315e0f65aca470810f05b4ff102127eea9341a84d109a8f8274d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
