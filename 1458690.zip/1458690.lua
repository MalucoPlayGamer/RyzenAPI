-- Lua provided by RyzenAPI
-- Game: Mango

-- MAIN APPLICATION
addappid(1458690)
-- Game: addappid(1458690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458691, 1, "34a1b19377767cea202e32b85131d6c44a875ba871b35ce4778fb3afd2a0e0f9")
addappid(1458692, 1, "221614104462d57e385ccf8d60ef240d00a0eac412dca779ad26dbe67a9a1bc1")
addappid(1458693, 1, "e3340bb5292338b241eaba5be6503efe1fbbbfbb0de8e1b309057865806edceb")
