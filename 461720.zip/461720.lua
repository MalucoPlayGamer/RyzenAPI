-- Lua provided by RyzenAPI
-- Game: addappid(461720)

-- MAIN APPLICATION
addappid(461720)
addappid(627700)

-- MAIN APP DEPOTS / PACKAGES
addappid(461721, 1, "7a31fbb9aa0189e2b9e36300d5f9c2d2821ecfa367920dc8af9f4e6ae213cd85")
addappid(461722, 1, "0508a30911a1ae4d31c835beb5d1bea117b32589f403c808fcd7bbed6a94efe4")
addappid(461723, 1, "842eb21dd8a143aa81ae88deab63b977a8f1821b0ae35458d357371fc6ff7529")
addappid(461724, 1, "fab5f7a0a0e506531757c56515ff061ba6c572831a30f361b3d88cfbed7d971e")
