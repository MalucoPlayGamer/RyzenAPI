-- Lua provided by RyzenAPI 
-- Game: AppID 316720
addappid(316720)
addappid(316721, 1, "9d6574108f8df7fc0847c662ecd66db135fd3260166a3b6d3f84665b6dab11cf")
addappid(316722, 1, "704598d10e827a0817c3b582325901ff8fe021d67650f7c66ffe86231ffd8858")
