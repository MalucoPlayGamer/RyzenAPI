-- Lua provided by RyzenAPI
-- Game: Hentai Girlfriend

-- MAIN APPLICATION
addappid(4310930) -- Hentai Girlfriend

-- MAIN APP DEPOTS / PACKAGES
addappid(4310931, 1, "eeedf5dbcfc9dc1fc4bf052945947c7e5a93f5e99ce9862ddc3597f3c3f92a7b") -- Depot 4310931

