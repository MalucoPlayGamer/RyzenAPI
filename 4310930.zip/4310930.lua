-- 4310930's Lua and Manifest Created by Hubcap Manifest
-- Hentai Girlfriend
-- Created: August 17, 2026 at 14:28:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4310930) -- Hentai Girlfriend
-- MAIN APP DEPOTS
addappid(4310931, 1, "eeedf5dbcfc9dc1fc4bf052945947c7e5a93f5e99ce9862ddc3597f3c3f92a7b") -- Depot 4310931
setManifestid(4310931, "7741615827901416499", 321978279)