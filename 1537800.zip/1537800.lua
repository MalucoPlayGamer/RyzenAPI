-- Lua provided by RyzenAPI
-- Game: Game: AppID 1537800

-- MAIN APPLICATION
addappid(1537800)
-- Game: addappid(1537800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537801, 1, "313eb27ff86886bbfa66615b1bda66c39f4a4c7d91a490e9233cfe4d229eaf32")
