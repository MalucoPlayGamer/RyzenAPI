-- Lua provided by RyzenAPI
-- Game: At Your Feet

-- MAIN APPLICATION
addappid(1537800)
addappid(1630050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537801, 1, "313eb27ff86886bbfa66615b1bda66c39f4a4c7d91a490e9233cfe4d229eaf32")

