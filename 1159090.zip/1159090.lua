-- Lua provided by RyzenAPI
-- Game: addappid(1159090)

-- MAIN APPLICATION
addappid(1159090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159091, 1, "ca1a220351cdfbfc159915fb62baa7c1d066b84049dc8e9e6e91786c8a94a7bf")
addappid(1159092, 1, "9d66efc3bc4d1d3e1238b6257160f0f3b39c3275081551ecce4dd0b5744127b8")
