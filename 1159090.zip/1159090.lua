-- Lua provided by RyzenAPI
-- Game: Zoria: Age of Shattering

-- MAIN APPLICATION
addappid(1159090)
addappid(2726430)
addappid(2769850)
addappid(2769860)
addappid(3217410)
addappid(3240690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159091,0,"ca1a220351cdfbfc159915fb62baa7c1d066b84049dc8e9e6e91786c8a94a7bf")
addappid(1159092,0,"9d66efc3bc4d1d3e1238b6257160f0f3b39c3275081551ecce4dd0b5744127b8")
addappid(2853200,0,"f3efe572a9ca0110c3719018471c306defd99105fc5cfda1995531a9aa81d777")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
