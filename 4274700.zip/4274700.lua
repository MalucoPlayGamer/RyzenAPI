-- Lua provided by RyzenAPI
-- Game: Tonight , resist drinking MiLK!!

-- MAIN APP DEPOTS / PACKAGES
addappid(4274700, 1, "cba2f4b3231a4c596e249b6813e3c995679842342d977e9a4fe5311053a80557") -- Tonight , resist drinking MiLK!!
addappid(4274701, 1, "7c26599f37a8e43ce523e36b3010418e5120b82641bb0398ffa6788fa7d8b16e") -- Depot 4274701

