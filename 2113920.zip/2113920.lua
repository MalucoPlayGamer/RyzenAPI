-- Lua provided by RyzenAPI
-- Game: addappid(2113920)

-- MAIN APPLICATION
addappid(2113920)
addappid(2252254)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113921, 1, "39841636ef36f57154f3bf12675bf0cc3ce7ba928f69190633d2e6fec0c7cd47")
