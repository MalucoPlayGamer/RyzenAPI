-- Lua provided by RyzenAPI 
-- Game: Corsair`s Madness Prologue: Jungle`s Island
addappid(2190570)
addappid(2190571, 1, "8862c98b12d7bde04e2061b73b7f6149377f61f4923fd8100091604772559bc7")
