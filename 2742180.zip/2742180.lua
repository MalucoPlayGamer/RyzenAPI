-- Lua provided by RyzenAPI
-- Game: Game: AppID 2742180

-- MAIN APPLICATION
addappid(2742180)
-- Game: addappid(2742180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742181, 1, "4f9cd56e769ea5583ff931ef27b69d05d9c4e476f6eea2d75fbd274184133c02")
