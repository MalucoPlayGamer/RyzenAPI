-- Lua provided by RyzenAPI
-- Game: TrackDayR

-- MAIN APPLICATION
addappid(1511630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511631, 1, "ee20318f0f85b282e4194e76c77e948511fa4f0bf8f925a03f91096c4db49db0")
