-- Lua provided by RyzenAPI
-- Game: Saihate Station : Twilight Railway

-- MAIN APPLICATION
addappid(3216040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216040,0,"26255c51d6e5628fc23d56de7435d9f494135bc7ac03b5ef821e3fe4d7787626")

