-- Lua provided by RyzenAPI
-- Game: Outlast 2

-- MAIN APPLICATION
addappid(414700)

-- MAIN APP DEPOTS / PACKAGES
addappid(414701, 1, "cacb82c7172211af76cdfefc4cb22d88140cfecd92c21c02bc3692aebf7402a3")

