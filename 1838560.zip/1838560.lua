-- Lua provided by RyzenAPI
-- Game: addappid(1838560)

-- MAIN APPLICATION
addappid(1838560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838561, 1, "3a4330db3fdd7f6f85aac02388f71c9b4c45bfdb21494bea9a614b3ff1c9cd97")
