-- Lua provided by RyzenAPI
-- Game: Game: 我亲爱的妹妹 Happy Sisters Life

-- MAIN APPLICATION
addappid(3492320)
-- Game: addappid(3492320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3492321, 1, "0f5e9a21902c17cc3b073d905021ebad41428fa8e8254fe0383feb545726008e")
