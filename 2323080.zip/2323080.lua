-- Lua provided by RyzenAPI
-- Game: addappid(2323080)

-- MAIN APPLICATION
addappid(2323080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323081, 1, "7c3f7f96f1b148ec508d6eafe91864a8e4d9cd6f66277213b07ce93f23c7124f")
