-- Lua provided by RyzenAPI
-- Game: Riddles of Fate: Wild Hunt Collector's Edition

-- MAIN APPLICATION
addappid(555520)

-- MAIN APP DEPOTS / PACKAGES
addappid(555521, 1, "4726b1e1f3024c6b362b979e4b930e8d661fad406ae2f065c4f00d9f8b2f3bd5")

