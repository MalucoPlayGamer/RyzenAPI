-- Lua provided by RyzenAPI
-- Game: Amber Tail Adventure

-- MAIN APPLICATION
addappid(614460)

-- MAIN APP DEPOTS / PACKAGES
addappid(614461, 1, "164923163d2621ab75300fb3983da172111a45408b03a2fdc6ce19f59e7c7368")

