-- Lua provided by RyzenAPI
-- Game: addappid(3460110)

-- MAIN APPLICATION
addappid(3460110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460111, 1, "d03ec0d3fcbaddda47fe14e2b82f56e030fb49d36adf609f3b33407e95183e75")
