-- Lua provided by RyzenAPI
-- Game: Game: REAVER

-- MAIN APPLICATION
addappid(1890950)
-- Game: addappid(1890950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890951, 1, "9dcaf4562a05d225767c3124f4a94dd23ef5d33b8a1e19383bbe24164342ea99")
