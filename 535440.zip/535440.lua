-- Lua provided by RyzenAPI 
-- Game: WAR7
addappid(535440)
addappid(535441, 1, "b11eabc836f2f75b2bac6954ac5f3c2db6c45713dc4838d90ee57233471e136a")
