-- Lua provided by RyzenAPI
-- Game: AppID 928180

-- MAIN APPLICATION
addappid(928180)
-- Game: addappid(928180)

-- MAIN APP DEPOTS / PACKAGES
addappid(928181, 1, "8ea2cf60cd238e5036ac7f3e1d1d3c427fd140baadf8a5be88eb560283526097")
