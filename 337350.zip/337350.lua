-- Lua provided by RyzenAPI 
-- Game: Flywrench
addappid(337350)
addappid(337351, 1, "ae470c63abd7359546f9634e05f5571b241cc9f63741e778e89f944e84dc9530")
addappid(337352, 1, "db0b2bf4af15e86a8d0f191ca8f283debaccdb18ba49474413b6326ca5687fe0")
addappid(337353, 1, "cd49aee180c18e9f849611a2346a005d1f7181d49d0390e891c7c33808ea313a")
