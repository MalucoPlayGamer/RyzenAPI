-- Lua provided by RyzenAPI
-- Game: Flywrench

-- MAIN APPLICATION
addappid(337350)

-- MAIN APP DEPOTS / PACKAGES
addappid(337351, 1, "ae470c63abd7359546f9634e05f5571b241cc9f63741e778e89f944e84dc9530")
addappid(337352, 1, "db0b2bf4af15e86a8d0f191ca8f283debaccdb18ba49474413b6326ca5687fe0")
addappid(337353, 1, "cd49aee180c18e9f849611a2346a005d1f7181d49d0390e891c7c33808ea313a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
