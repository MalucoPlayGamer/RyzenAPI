-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY® XIII

-- MAIN APPLICATION
addappid(292120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(292121, 1, "80234db32af6ccde408480b0fdce3b9bc0ae476640909a3410943c2ddd62c608")
addappid(292122, 1, "661e081643c994179c8265ea189661608b85cd692da489d01396c7ca303c9033")

