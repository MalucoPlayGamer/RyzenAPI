-- Lua provided by RyzenAPI
-- Game: addappid(627460)

-- MAIN APPLICATION
addappid(627460)

-- MAIN APP DEPOTS / PACKAGES
addappid(627461, 1, "fa96adc749f1224d76ae9be70b98e53cfef27c1da3ffd42dd28c884f6715038f")
