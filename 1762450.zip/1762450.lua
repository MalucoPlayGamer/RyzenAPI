-- Lua provided by RyzenAPI
-- Game: addappid(1762450)

-- MAIN APPLICATION
addappid(1762450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762451, 1, "c00ae681fd14b4b9a7175dfee927dba6de73e3c38fa2ccb4ecd42c384bfb6844")
