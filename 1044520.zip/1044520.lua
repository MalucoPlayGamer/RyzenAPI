-- Lua provided by RyzenAPI
-- Game: Game: AppID 1044520

-- MAIN APPLICATION
addappid(1044520)
-- Game: addappid(1044520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044521, 1, "04d2963229bad51e1f57052816cbebf830af6899f603f483b46956417b49d6a9")
