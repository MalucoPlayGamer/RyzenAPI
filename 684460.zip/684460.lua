-- Lua provided by RyzenAPI
-- Game: Project Lucie

-- MAIN APPLICATION
addappid(684460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(684461, 1, "8f51547478bb06da8eec3e40b02405ed70b48461a91b0c9566969fa47337f4a7")

