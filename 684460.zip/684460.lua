-- Lua provided by RyzenAPI
-- Game: 684460

-- MAIN APPLICATION
addappid(684460)
-- Game: addappid(684460)

-- MAIN APP DEPOTS / PACKAGES
addappid(684461, 1, "8f51547478bb06da8eec3e40b02405ed70b48461a91b0c9566969fa47337f4a7")
