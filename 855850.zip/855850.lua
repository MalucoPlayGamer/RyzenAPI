-- Lua provided by RyzenAPI
-- Game: Space Elite Force

-- MAIN APPLICATION
addappid(855850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(855851, 1, "d26dc235ae9f4eba530b237835063edb9805353feb9ed60718fe3a56c2db583c")
addappid(855852, 1, "b6a5c9e12db54271291a6e6913077b114da61d6287148688992ce2da403f400e")

