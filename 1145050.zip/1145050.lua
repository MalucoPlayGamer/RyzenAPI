-- Lua provided by RyzenAPI
-- Game: Tonetaker VR

-- MAIN APPLICATION
addappid(1145050)
-- Game: addappid(1145050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145051, 1, "2faaab242b3737ac7d0d19bf482dadb98ce1663f9bbb5e5193f822a30290ff16")
