-- Lua provided by RyzenAPI
-- Game: Super Hiking  Simulator 2020

-- MAIN APPLICATION
addappid(1232500)
-- Game: addappid(1232500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232501, 1, "b45d67499c7e0e067b304ea56963939eb079fa459fdd941f8735a5d8ec5c512d")
