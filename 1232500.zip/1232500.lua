-- Lua provided by RyzenAPI
-- Game: Super Hiking  Simulator 2020

-- MAIN APPLICATION
addappid(1232500)
addappid(1240151)
addappid(1290210)
addappid(1706690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1232501, 1, "b45d67499c7e0e067b304ea56963939eb079fa459fdd941f8735a5d8ec5c512d")

