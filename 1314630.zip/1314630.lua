-- Lua provided by RyzenAPI
-- Game: addappid(1314630)

-- MAIN APPLICATION
addappid(1314630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314631, 1, "8c8c2e12120abe19735c96c3b03e5bb8e8a10c8413ecc75317f32011878e698e")
