-- Lua provided by SkyAPI 
-- Game: AppID 568130
addappid(568130)
addappid(568131, 1, "63e7f55ec42b2571083cde337a3e9955f4b9851e4feb27acaf883ba18c3e0e43")
