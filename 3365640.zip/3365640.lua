-- Lua provided by RyzenAPI
-- Game: 3365640

-- MAIN APPLICATION
addappid(3365640)
-- Game: addappid(3365640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365641, 1, "07cd102ce6671f7b13c490a9d05da1b71b6cf3750d0f43ace5998b451105843b")
