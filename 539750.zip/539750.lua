-- Lua provided by RyzenAPI
-- Game: Kombine

-- MAIN APPLICATION
addappid(539750)

-- MAIN APP DEPOTS / PACKAGES
addappid(539751, 1, "c3dec355ebbbd3d74060a0a68e23b460a7118e570d60b848c64d29eee6d6fdc2")
addappid(539752, 1, "7b12e6f221b9f9a999aba163914f1b7dd75b11d2be5aaf775900917689cf1f6a")
