-- Lua provided by RyzenAPI
-- Game: AppID 210390

-- MAIN APPLICATION
addappid(210390)

-- MAIN APP DEPOTS / PACKAGES
addappid(210391, 1, "acc5c06bf6ef7422d634d27b051b18fdc54c7289d1891d8e3be5ff6a502470ee")

