-- Lua provided by RyzenAPI
-- Game: addappid(1717090)

-- MAIN APPLICATION
addappid(1717090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717091, 1, "117f28451d8ab15f4cfdbdd841be0feaa094b6261ecc9d01a3649514ee60f971")
