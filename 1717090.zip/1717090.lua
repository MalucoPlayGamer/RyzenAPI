-- Lua provided by SkyAPI 
-- Game: Into the Necrovale
addappid(1717090)
addappid(1717091, 1, "117f28451d8ab15f4cfdbdd841be0feaa094b6261ecc9d01a3649514ee60f971")
