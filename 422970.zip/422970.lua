-- Lua provided by RyzenAPI
-- Game: AppID 422970

-- MAIN APPLICATION
addappid(422970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(422971, 1, "36083d198678c08bb5b5d1b3070f1513d1a414090ace3af57a73460e98cf6192")
addappid(422972, 1, "9365742411a97ea94ed90d41dbf6aafdad6b973bc6d63a07841e25842648cd61")
addappid(422973, 1, "09ced00464f3ef3326c7323930ec08e0b564dfbf18a1587c252c02132bd1349a")

