-- Lua provided by RyzenAPI
-- Game: 白昼夢の青写真 Soundtrack CASE-0

-- MAIN APPLICATION
addappid(1894050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894051, 1, "66a01e705d2def302f9b503eeffab3bad791870191e64ac25f8445d70d351c66")
addappid(1894052, 1, "4e2fd02a067c4edff664ee88d18277c1cf663f3666e085333bb400a5fa0ad135")

