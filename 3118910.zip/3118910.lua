-- Lua provided by RyzenAPI
-- Game: Reality Breach

-- MAIN APPLICATION
addappid(3118910) -- Reality Breach

-- MAIN APP DEPOTS / PACKAGES
addappid(3118911, 1, "0b9bf074116b386ac3306bf1686625514531997036ea04f3cba51250b8930715") -- Depot 3118911
