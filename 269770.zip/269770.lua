-- Lua provided by RyzenAPI
-- Game: Secrets of Grindea

-- MAIN APPLICATION
addappid(269770)

-- MAIN APP DEPOTS / PACKAGES
addappid(269771, 1, "2c09668a8bd8fdf1e30cb0fb1b6183b05366c8564274d48b00f3b944a0205977")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(292050)
