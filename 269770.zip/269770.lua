-- Lua provided by SkyAPI 
-- Game: Secrets of Grindea
addappid(269770)
addappid(269771, 1, "2c09668a8bd8fdf1e30cb0fb1b6183b05366c8564274d48b00f3b944a0205977")
