-- Lua provided by RyzenAPI
-- Game: AppID 830750

-- MAIN APPLICATION
addappid(830750)
-- Game: addappid(830750)

-- MAIN APP DEPOTS / PACKAGES
addappid(830751, 1, "5e3f8cb230ac4085a7e7e23a9e45428fe9eff5419cb606cea9e6e01ec0d0e8de")
