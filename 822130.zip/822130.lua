-- Lua provided by RyzenAPI
-- Game: Flynn and Freckles

-- MAIN APPLICATION
addappid(822130)

-- MAIN APP DEPOTS / PACKAGES
addappid(822131,0,"258da5a70865fbfc96d02760a74256828d6175fe62987f87c792c0cd75935bf7")

