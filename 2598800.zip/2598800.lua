-- Lua provided by RyzenAPI
-- Game: Psionic Sentry : Infinite

-- MAIN APPLICATION
addappid(2598800)
-- Game: addappid(2598800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598801, 1, "83987eca3d3ed8aa70a8cdbd8e51382cbfbd5784f8f2f2b7e0f48be781fbfefe")
