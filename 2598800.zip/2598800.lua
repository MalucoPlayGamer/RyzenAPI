-- Lua provided by SkyAPI 
-- Game: Psionic Sentry : Infinite
addappid(2598800)
addappid(2598801, 1, "83987eca3d3ed8aa70a8cdbd8e51382cbfbd5784f8f2f2b7e0f48be781fbfefe")
