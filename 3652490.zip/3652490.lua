-- Lua provided by RyzenAPI
-- Game: 3652490

-- MAIN APPLICATION
addappid(3652490)
-- Game: addappid(3652490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652491, 1, "9c3b4273b2f030e508ae6184da68e9147cc596eb612ef768fb95d85ff7d6b6a1")
