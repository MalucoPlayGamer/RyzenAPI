-- Lua provided by RyzenAPI
-- Game: Game: Craft and Dungeon

-- MAIN APPLICATION
addappid(829250)
-- Game: addappid(829250)

-- MAIN APP DEPOTS / PACKAGES
addappid(829251, 1, "a95edfa006b5e8dc1e7e81b15846e3b8953410e7886d5b28325b04b7692370e3")
