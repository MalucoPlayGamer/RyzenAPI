-- Lua provided by RyzenAPI 
-- Game: Underground Keeper
addappid(497040)
addappid(497041, 1, "bbd40db62d9a12e323bb4c175927ea6288da310421c3ba5629e20e8e73e08b1f")
