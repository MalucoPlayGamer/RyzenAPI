-- Lua provided by SkyAPI 
-- Game: AppID 546980
addappid(546980)
addappid(546981, 1, "31da42de6837bdd808b0b9485ea9bba524d6c2c47af12bfcd91fba7f3bc373ad")
