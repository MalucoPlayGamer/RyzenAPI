-- Lua provided by RyzenAPI
-- Game: addappid(546980)

-- MAIN APPLICATION
addappid(546980)

-- MAIN APP DEPOTS / PACKAGES
addappid(546981, 1, "31da42de6837bdd808b0b9485ea9bba524d6c2c47af12bfcd91fba7f3bc373ad")
