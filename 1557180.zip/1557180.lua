-- Lua provided by RyzenAPI
-- Game: Ex Natura: Nature Corrupted

-- MAIN APPLICATION
addappid(1557180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557181, 1, "2a821c7a0b009513ca8ae07dba9adf654ccd2b1d46e18ac3546407b0c1c52073")

