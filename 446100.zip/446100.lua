-- Lua provided by RyzenAPI
-- Game: Mantis Burn Racing®

-- MAIN APPLICATION
addappid(446100)

-- MAIN APP DEPOTS / PACKAGES
addappid(446101, 1, "5321f30b777115618b1c11535df5bfc2e963fcc39992eba601fb0ac23325b21a")
addappid(446102, 1, "6830db879cada08cace6916e8238d3ccaa53d2cfa934ac364a74b184195527c1")
addappid(446103, 1, "2ce3768de7c085793822c346e178e16eaf626030d7dd33022c1c5ac655d2781e")
addappid(584190, 0, "7f71e35f8cf756c0a84c43e1cb14c9f7addf74e304f691a78b57127f405cb837")
addappid(584191, 0, "ad162a1c94f86a0a7b859c2e46da2e7b71d8d0803a04ab013fbbe5d91765087b")
addappid(584192, 0, "62c37e71a8c3d0eb07ae516c46e3d1485b4f544a542d4846f5b1226566103a1a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
