-- Lua provided by RyzenAPI
-- Game: 2470730

-- MAIN APPLICATION
addappid(2470730)
-- Game: addappid(2470730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470731, 1, "a2d05e50e93e4ffe86ef13e5a5d2005c67656a7fd3c37cc40d33e982aceed9e6")
