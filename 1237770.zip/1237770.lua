-- Lua provided by RyzenAPI
-- Game: Game: Age of Empires: Definitive Edition Soundtrack

-- MAIN APPLICATION
addappid(1237770)
-- Game: addappid(1237770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237771, 1, "f62d644ed6d0d8758a8b2e854040f40578c4e5b098ed72c3fd87f8f6ed9b0c97")
