-- Lua provided by RyzenAPI
-- Game: Game: AppID 1475170

-- MAIN APPLICATION
addappid(1475170)
-- Game: addappid(1475170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475171, 1, "0a7051a75939b19d2172627f58880a6ccc8c09b1aaba709f6a981f6d35fcbbc8")
