-- Lua provided by RyzenAPI 
-- Game: Fastest Cars Traffic Racer
addappid(2598970)
addappid(2598971, 1, "403c5b84bb3762dec2f5bb0424e9d5a889d154ba7ead2194a86c92bd39caefdf")
