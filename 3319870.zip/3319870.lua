-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS: ORIGINS - Original Soundtrack (Digital Edition)

-- MAIN APPLICATION
addappid(3319870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319870,0,"69380b72ac8cb5b3f7914bbb0e828d1529ef6b2a20076ceb73945c656515e5c7")
addtoken(3319870,"1595971489372741222")

