-- Lua provided by RyzenAPI
-- Game: A Buttload of Free Games

-- MAIN APPLICATION
addappid(1275070)
-- Game: addappid(1275070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275071, 1, "06125107a0b34f2a15ef40097a6c4af6f07e6b15bf9f31fa9212db169196be0f")
