-- Lua provided by RyzenAPI
-- Game: setManifestid(592754,"5577504952119864546")

-- MAIN APPLICATION
addappid(592750)
-- Game: addappid(592750)

-- MAIN APP DEPOTS / PACKAGES
addappid(592754,0,"b5885e2fea159abb4628848f0d872db929c94a7d64e7aba1b48d94ce6d7bb7d4")
