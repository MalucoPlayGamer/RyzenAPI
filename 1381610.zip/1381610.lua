-- Lua provided by RyzenAPI
-- Game: 1381610

-- MAIN APPLICATION
addappid(1381610)
-- Game: addappid(1381610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381611, 1, "2c4a9d415af1c5af4af80d9aa33dd5c1d9af6f207b2cfe128f5b28edf42e3037")
