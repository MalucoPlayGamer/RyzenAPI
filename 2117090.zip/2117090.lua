-- Lua provided by RyzenAPI
-- Game: Let's Park Backyard Edition

-- MAIN APPLICATION
addappid(2117090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117091, 1, "13b259513dbb3a4bbc8df86b5302fe7229dbe355db9a0e48f34afd0d6e34fc56")

