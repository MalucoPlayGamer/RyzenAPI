-- Lua provided by RyzenAPI
-- Game: Industrial Petting

-- MAIN APPLICATION
addappid(676510)

-- MAIN APP DEPOTS / PACKAGES
addappid(676511, 1, "eed79f2a006d58afbaff31e06fbec12ba52202e02f99fef87658663b4f1e934c")
addappid(676512, 1, "a1ae2fca776e3fdcd04246e5e6909af5d2218e50fee4dba9fff140895cdde638")
