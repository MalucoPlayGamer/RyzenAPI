-- Lua provided by RyzenAPI
-- Game: Carpoon

-- MAIN APP DEPOTS / PACKAGES
addappid(1068840, 1, "81c80c84917dd74e9309759bfa51a9ec8ebb9c58a747743e5d307d182edfdfcc") -- Carpoon
addappid(1068841, 1, "2cd5f2035bafe337861a58dc4927cdca033790dfb0c72049afd337fadd9e41a7") -- Depot 1068841
