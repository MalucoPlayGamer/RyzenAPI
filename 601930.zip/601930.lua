-- Lua provided by SkyAPI 
-- Game: Trianguluv
addappid(601930)
addappid(601931, 1, "9a89899b8499817c39917d6f2adab30459cbbd1044653e6e318ceb14584d2e43")
addappid(601932, 1, "6a07d0075df933db5e8005f773baac96d899ab0572ce2f89424b6f97252b564c")
addappid(601933, 1, "7180bace1993c8e1b571c8f7d3f257f15baf9c25f8ea1335acd3fdd571de5670")
