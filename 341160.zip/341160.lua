-- Lua provided by RyzenAPI
-- Game: Steam Heroes

-- MAIN APPLICATION
addappid(341160)

-- MAIN APP DEPOTS / PACKAGES
addappid(341161, 1, "fff3d8375b1527d2e4f2e76329bb82fd772bf986459600ec98cc1fce0ab9a6db")

