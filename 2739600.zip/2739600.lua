-- Lua provided by RyzenAPI
-- Game: Kalpa of Sword

-- MAIN APPLICATION
addappid(2739600)
-- Game: addappid(2739600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739601, 1, "1ce30ccc349ada57e287bf5000ec6191cf021b37f6363cd9c744683264eea55e")
