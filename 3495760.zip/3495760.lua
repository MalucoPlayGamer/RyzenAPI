-- Lua provided by RyzenAPI
-- Game: Sex Apartment 💫 - Digital Artbook

-- MAIN APPLICATION
addappid(3495760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3495760,0,"69e2392b881b5da5883254c9297349ac89e05b301112be173caafdb90177440e")

