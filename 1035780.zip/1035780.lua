-- Lua provided by RyzenAPI
-- Game: AppID 1035780

-- MAIN APPLICATION
addappid(1035780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035781, 1, "a1e87c69aac4d227f1ac5dc4a92714f5a574b57fbf605987dfea95de221f5cd2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3583350)
addappid(3583360)
