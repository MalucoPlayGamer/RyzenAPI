-- Lua provided by RyzenAPI 
-- Game: AppID 1035780
addappid(1035780)
addappid(1035781, 1, "a1e87c69aac4d227f1ac5dc4a92714f5a574b57fbf605987dfea95de221f5cd2")
