-- Lua provided by RyzenAPI
-- Game: Snik

-- MAIN APPLICATION
addappid(388050)
addappid(399460)

-- MAIN APP DEPOTS / PACKAGES
addappid(388051, 1, "df8c50819b52926b48f12f8da564f592bd4525f98843ffae30a838b6bb7e792a")
addappid(388052, 1, "bffd77dad894cd029ee34e809b397edc71d437e7292f2f66bdf675bb63c0a2dc")
addappid(388053, 1, "108dff6b7c7f2fe75f542dd9d8646c0de43aa9cf84370d1fe8f8fe3a1e601d4e")

