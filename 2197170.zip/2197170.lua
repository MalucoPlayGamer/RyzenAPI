-- Lua provided by RyzenAPI
-- Game: addappid(2197170)

-- MAIN APPLICATION
addappid(2197170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197171, 1, "f5377c75b4e23c7cf5fe26aa203ed2c82e1147cdd8dcbd32d68749c0b226e464")
