-- Lua provided by RyzenAPI
-- Game: Defense Tower Simulator

-- MAIN APPLICATION
addappid(1644650)
-- Game: addappid(1644650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644651, 1, "f169e922a6cd2ae827002245bc6f57865ef6cb3430dccf7457daad2b2f1a7300")
