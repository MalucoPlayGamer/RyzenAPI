-- Lua provided by RyzenAPI 
-- Game: Defense Tower Simulator
addappid(1644650)
addappid(1644651, 1, "f169e922a6cd2ae827002245bc6f57865ef6cb3430dccf7457daad2b2f1a7300")
