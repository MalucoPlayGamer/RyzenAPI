-- Lua provided by RyzenAPI
-- Game: AppID 491530

-- MAIN APPLICATION
addappid(491530)

-- MAIN APP DEPOTS / PACKAGES
addappid(491531, 1, "75706ad45ded4eb130afacc177c675a508d3adac6e944c5cf03260a58db58d94")

