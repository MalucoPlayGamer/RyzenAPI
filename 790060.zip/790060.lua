-- Lua provided by RyzenAPI
-- Game: 790060

-- MAIN APPLICATION
addappid(790060)
-- Game: addappid(790060)

-- MAIN APP DEPOTS / PACKAGES
addappid(790061, 1, "732e35828bde8e203ffa2c4dac9a3328248b14a4b77df5ef70348ef28272124f")
