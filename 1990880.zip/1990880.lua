-- Lua provided by RyzenAPI
-- Game: Leave No One Behind: Ia Drang VR

-- MAIN APPLICATION
addappid(1990880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990881, 1, "7ccd790d675214285def52a7d8db198947dda5960542d35a7960984266f8e332")

