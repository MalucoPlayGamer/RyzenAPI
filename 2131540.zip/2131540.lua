-- Lua provided by RyzenAPI
-- Game: Game: Black Lily's Tale Perfect Sound Track

-- MAIN APPLICATION
addappid(2131540)
-- Game: addappid(2131540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131541, 1, "814128fab503f0e3d1010e0fa043161ca3f2523f592798eebcdab37bf307e882")
addappid(2131542, 1, "76c705f06edacb21f32a159f990a75fa6bf57e4e597f20adbef775a16b0d58ad")
