-- Lua provided by SkyAPI 
-- Game: Furry Cyberfucker
addappid(1943760)
addappid(1943761, 1, "7443efe084c4f947aa1c717e43c67d409f9ff90beaf5987a644b54b5f202ea25")
