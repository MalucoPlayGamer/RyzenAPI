-- Lua provided by RyzenAPI
-- Game: Game: Furry Cyberfucker

-- MAIN APPLICATION
addappid(1943760)
-- Game: addappid(1943760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943761, 1, "7443efe084c4f947aa1c717e43c67d409f9ff90beaf5987a644b54b5f202ea25")
