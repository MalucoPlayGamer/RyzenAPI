-- Lua provided by RyzenAPI
-- Game: The Sandbox of God

-- MAIN APPLICATION
addappid(840730)

-- MAIN APP DEPOTS / PACKAGES
addappid(840731,0,"dbe0952e17df3cc19f7e6be298c6d43887a000f8eaf4f32693f7162d3297a8ee")

