-- Lua provided by RyzenAPI
-- Game: addappid(1970020)

-- MAIN APPLICATION
addappid(1970020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970021, 1, "1e1e255c8b2ba78328590d66f72c3af07bb7c2fc2699357493b16bc2d90597d0")
