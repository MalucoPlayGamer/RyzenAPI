-- Lua provided by RyzenAPI
-- Game: AppID 848280

-- MAIN APPLICATION
addappid(848280)
-- Game: addappid(848280)

-- MAIN APP DEPOTS / PACKAGES
addappid(848281, 1, "a9f986feb4da56b7381ace56fe57e796a07fd797123f70c2a179ddcc11e6f186")
