-- Lua provided by RyzenAPI
-- Game: The Legend of Nayuta: Boundless Trails

-- MAIN APPLICATION
addappid(1668530)
addappid(1823180)
addappid(1825590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1668531, 1, "8ae764bcc3fa1dd73d035cc7a9588dce215e3e2037e3fa8ac62254359ab831e8")

