-- Lua provided by RyzenAPI
-- Game: Game: The Legend of Nayuta: Boundless Trails

-- MAIN APPLICATION
addappid(1668530)
addappid(1823180)
addappid(1825590)
-- Game: addappid(1668530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668531, 1, "8ae764bcc3fa1dd73d035cc7a9588dce215e3e2037e3fa8ac62254359ab831e8")
