-- Lua provided by RyzenAPI
-- Game: AppID 888090

-- MAIN APPLICATION
addappid(888090)

-- MAIN APP DEPOTS / PACKAGES
addappid(888091, 1, "6d9e58818f724b894c15babfbbe890b84a814d06fc412e3f9fc31598a3a5a2dc")
