-- Lua provided by RyzenAPI
-- Game: TREE

-- MAIN APPLICATION
addappid(888090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(888091, 1, "6d9e58818f724b894c15babfbbe890b84a814d06fc412e3f9fc31598a3a5a2dc")
