-- Lua provided by RyzenAPI 
-- Game: Year Walk
addappid(269050)
addappid(269051, 1, "a207b3d36cd28518a74d4e7933a7cb4bfd4b3c3ded2aa41ae8743127588a59ab")
addappid(269052, 1, "5511646a00b7e8ed01af5fd62cfcf9d0055521509030c60af3582d4730e80e47")
addappid(269053, 1, "d1fcde784ba05878f84dfb7fa575a724b981760b1bc94ac88fc51043790c6ead")
