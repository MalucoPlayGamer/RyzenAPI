-- Lua provided by RyzenAPI
-- Game: 222940

-- MAIN APPLICATION
addappid(222940)
addappid(228983)
addappid(228990)
-- Game: addappid(222940)

-- MAIN APP DEPOTS / PACKAGES
addappid(222941, 1, "a5607756385b019287b875f646124e89fe3085da91f38fadd658f58947730be3")
