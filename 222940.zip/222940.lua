-- Lua provided by RyzenAPI 
-- Game: THE KING OF FIGHTERS XIII STEAM EDITION
addappid(222940)
addappid(222941, 1, "a5607756385b019287b875f646124e89fe3085da91f38fadd658f58947730be3")
addappid(228983)
addappid(228990)
