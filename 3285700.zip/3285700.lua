-- Lua provided by RyzenAPI
-- Game: Life is Feudal: Arden

-- MAIN APPLICATION
addappid(3285700)

