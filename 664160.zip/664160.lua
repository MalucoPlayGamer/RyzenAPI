-- Lua provided by RyzenAPI
-- Game: Shn!p

-- MAIN APPLICATION
addappid(664160)

-- MAIN APP DEPOTS / PACKAGES
addappid(664161,0,"80c8893c29b342c7becc34f6f2052f32aa9534bc80b34c8ebe847a5ff602045d")

