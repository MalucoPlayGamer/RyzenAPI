-- Lua provided by RyzenAPI
-- Game: Naturallandscape - GuilinLandscape (自然景观系列-桂林山水)

-- MAIN APPLICATION
addappid(788720)

-- MAIN APP DEPOTS / PACKAGES
addappid(788721, 1, "47edec0e05035df91b0665a2d82f2531c1f4e406833853ddb8d6a1462e67a129")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
