-- Lua provided by RyzenAPI
-- Game: Naturallandscape - GuilinLandscape (自然景观系列-桂林山水)

-- MAIN APPLICATION
addappid(788720)

-- MAIN APP DEPOTS / PACKAGES
addappid(788721, 1, "47edec0e05035df91b0665a2d82f2531c1f4e406833853ddb8d6a1462e67a129")

