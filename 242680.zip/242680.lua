-- Lua provided by RyzenAPI
-- Game: Game: Nuclear Throne

-- MAIN APPLICATION
addappid(242680)
-- Game: addappid(242680)

-- MAIN APP DEPOTS / PACKAGES
addappid(242681, 1, "45ef15e9cac41baef495ec7c6c4d8092b20ef7b914afa66f1b4c3b064088eec6")
