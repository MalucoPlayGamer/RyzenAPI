-- Lua provided by RyzenAPI
-- Game: 蛇香之夜 ～Allure of MUSK～　第二夜　亚洲篇

-- MAIN APPLICATION
addappid(2200350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200351, 1, "f65bc1286a8277a83893d855c70d6a7b5dce764f22c2298d172bcc89010baf5c")
