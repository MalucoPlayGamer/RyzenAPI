-- Lua provided by RyzenAPI
-- Game: addappid(2200350)

-- MAIN APPLICATION
addappid(2200350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200351, 1, "f65bc1286a8277a83893d855c70d6a7b5dce764f22c2298d172bcc89010baf5c")
