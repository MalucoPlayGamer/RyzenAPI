-- Lua provided by RyzenAPI
-- Game: Save the Furries

-- MAIN APPLICATION
addappid(325110)

-- MAIN APP DEPOTS / PACKAGES
addappid(325111, 1, "005443c0e21e79883e6bd16fe6e70109b033c4188e1c4070cc2291e2c290ddcf")
