-- Lua provided by SkyAPI 
-- Game: Oddworld: Abe's Exoddus®
addappid(15710)
addappid(15711, 1, "ae3eb46bc7defb1a242abd9f29df257c09c77698aa0f570d665093b3b0a9bb53")
addappid(15712, 1, "174dfad45e5654f9eaae4cc4051f4711c08e4e742a5d7be6b48e982a74105c17")
addappid(15713, 1, "7798d00518bab8d62308aeecb1e855435043b577ec678f138362ca15b6a27ba4")
addappid(15714, 1, "1501f501a59d3a7b9b1ddbe5c575623b182c45a739532ceb10df6dd759bcac70")
addappid(15715, 1, "38f38764ef30983c0165c36f25a75efaf2feee1b80623fe1504cefc528343d95")
