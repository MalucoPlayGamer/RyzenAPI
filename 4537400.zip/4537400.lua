-- Lua provided by RyzenAPI
-- Game: Paper2Galgame

-- MAIN APPLICATION
addappid(4537400) -- Paper2Galgame

-- MAIN APP DEPOTS / PACKAGES
addappid(4537401, 1, "3c25303df0c713ed43db95c03e903629d4ba8d418aaa0136d43e850578529f35") -- Depot 4537401
addappid(4537402, 1, "ff4df316d1cb6ab5c0bd1321bca52fada9b9dd11fd8743b3a174d57eebaa5be5") -- Depot 4537402
addtoken(4537400, "12371323340878651086")

