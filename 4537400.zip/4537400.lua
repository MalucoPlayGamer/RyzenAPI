-- Lua provided by RyzenAPI
-- Game: Paper2Galgame

-- MAIN APPLICATION
addappid(4537400) -- Paper2Galgame

-- MAIN APP DEPOTS / PACKAGES
addappid(4537401, 1, "3c25303df0c713ed43db95c03e903629d4ba8d418aaa0136d43e850578529f35") -- Depot 4537401
addtoken(4537400, "12371323340878651086")

