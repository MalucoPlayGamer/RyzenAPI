-- 4537400's Lua and Manifest Created by Hubcap Manifest
-- Paper2Galgame
-- Created: August 10, 2026 at 06:43:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4537400) -- Paper2Galgame
addtoken(4537400, "12371323340878651086")
-- MAIN APP DEPOTS
addappid(4537401, 1, "3c25303df0c713ed43db95c03e903629d4ba8d418aaa0136d43e850578529f35") -- Depot 4537401
setManifestid(4537401, "7277524638427869432", 513852962)
addappid(4537402, 1, "ff4df316d1cb6ab5c0bd1321bca52fada9b9dd11fd8743b3a174d57eebaa5be5") -- Depot 4537402
setManifestid(4537402, "5012943807937267427", 443736079)