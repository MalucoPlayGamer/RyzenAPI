-- 4537400's Lua and Manifest Created by Hubcap Manifest
-- Paper2Galgame
-- Created: August 07, 2026 at 07:23:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4537400) -- Paper2Galgame
addtoken(4537400, "12371323340878651086")
-- MAIN APP DEPOTS
addappid(4537401, 1, "3c25303df0c713ed43db95c03e903629d4ba8d418aaa0136d43e850578529f35") -- Depot 4537401
setManifestid(4537401, "697262187188655139", 513877855)