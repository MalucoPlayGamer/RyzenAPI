-- Lua provided by RyzenAPI
-- Game: addappid(386640)

-- MAIN APPLICATION
addappid(386640)

-- MAIN APP DEPOTS / PACKAGES
addappid(386641, 1, "b7e4fa19c556c4e43c30d1dced50cbd1cb8c0ca2359185369190ecf4fbf99032")
