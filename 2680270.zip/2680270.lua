-- Lua provided by SkyAPI 
-- Game: Hero's Adventure:Road to Passion Soundtrack
addappid(2680270)
addappid(2680271, 1, "fbe9342c087a8749040fef7d66fc818dec7c79787b96c98b326d21511605fc51")
