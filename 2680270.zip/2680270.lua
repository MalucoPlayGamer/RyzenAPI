-- Lua provided by RyzenAPI
-- Game: 2680270

-- MAIN APPLICATION
addappid(2680270)
-- Game: addappid(2680270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680271, 1, "fbe9342c087a8749040fef7d66fc818dec7c79787b96c98b326d21511605fc51")
