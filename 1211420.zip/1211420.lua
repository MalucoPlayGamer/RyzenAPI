-- Lua provided by RyzenAPI
-- Game: Find Me: Horror Game

-- MAIN APPLICATION
addappid(1211420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1211422,0,"6599573891c3ef85f21f68c76524c16a4328746ceba210a09d3970320f02d7c8")

