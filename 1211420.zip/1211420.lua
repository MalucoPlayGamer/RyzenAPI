-- Lua provided by RyzenAPI
-- Game: Find Me: Horror Game

-- MAIN APPLICATION
addappid(1211420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211422,0,"6599573891c3ef85f21f68c76524c16a4328746ceba210a09d3970320f02d7c8")

