-- Lua provided by RyzenAPI
-- Game: The Quintessential Quintuplets - Memories of a Quintessential Summer

-- MAIN APPLICATION
addappid(2507610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507611, 1, "b3dba487c72cacb21d129d59ba0a0b3d13ac99c212dca6a0f8766766a7f3e54e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
