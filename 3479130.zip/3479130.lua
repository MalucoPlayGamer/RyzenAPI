-- Lua provided by RyzenAPI
-- Game: Sex & Coffee ☕️🤎 Demo

-- MAIN APPLICATION
addappid(3479130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3479131, 1, "eaac73ffbbdb1bdb21bea193c838b87e7928d7477adf636e0eeac2ab18266a52")
