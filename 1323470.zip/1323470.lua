-- Lua provided by RyzenAPI
-- Game: GetsuFumaDen: Undying Moon

-- MAIN APPLICATION
addappid(1323470)
addappid(1556590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1323471, 1, "b87edd695a17225c0399ce29ead4b4ea56f26342e6078dca0a414ca882547592")

