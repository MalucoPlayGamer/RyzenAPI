-- Lua provided by RyzenAPI
-- Game: addappid(1323470)

-- MAIN APPLICATION
addappid(1323470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323471, 1, "b87edd695a17225c0399ce29ead4b4ea56f26342e6078dca0a414ca882547592")
