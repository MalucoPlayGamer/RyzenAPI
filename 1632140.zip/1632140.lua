-- Lua provided by SkyAPI 
-- Game: Girl Agent
addappid(1632140)
addappid(1632141, 1, "ddc56f0938146777672406b23de2e681f177652dc112f94a9488e505311a0c36")
addappid(1788000, 0, "155b25a16ba1b49eb66790c4c9550a4afda63ca15f56be6fe4ac79a0dfc788db")
