-- Lua provided by RyzenAPI
-- Game: 780990

-- MAIN APPLICATION
addappid(780990)
-- Game: addappid(780990)

-- MAIN APP DEPOTS / PACKAGES
addappid(780990,0,"d1c65ebb7dfd49161c40ad9b9349e2fb2f9925c85f77b0598d2fc591f4040020")
