-- Lua provided by RyzenAPI
-- Game: Chinese Frontiers: Prologue Playtest

-- MAIN APPLICATION
addappid(2326060)
-- Game: addappid(2326060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326061, 1, "486b51bbf3dac72308616b268086f36d38239f8fbe03d740fe1ab62b8f7fd85f")
