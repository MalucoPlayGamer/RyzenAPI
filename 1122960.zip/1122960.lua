-- Lua provided by RyzenAPI
-- Game: Horizon Beyond

-- MAIN APPLICATION
addappid(1122960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1122961, 1, "68b4206cb03af742ffd69ca0bd170703c5d76595152736985c088f9b234b3ea2")

