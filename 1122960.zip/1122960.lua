-- Lua provided by RyzenAPI
-- Game: Game: AppID 1122960

-- MAIN APPLICATION
addappid(1122960)
-- Game: addappid(1122960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122961, 1, "68b4206cb03af742ffd69ca0bd170703c5d76595152736985c088f9b234b3ea2")
