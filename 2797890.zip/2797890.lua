-- Lua provided by RyzenAPI
-- Game: AppID 2797890

-- MAIN APPLICATION
addappid(2797890)
-- Game: addappid(2797890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797891, 1, "5587c862d8831721c383e0d3fbcccca98c6d5c8720fcd20c95412a8b6c75d365")
