-- Lua provided by RyzenAPI
-- Game: AppID 1878970

-- MAIN APPLICATION
addappid(1878970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1878971, 1, "d701293c84eb0a11cb898108b4457ba2ec0c9c90cee5cb2cdcd7f46e958d4078")

