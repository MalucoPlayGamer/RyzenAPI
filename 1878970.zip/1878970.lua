-- Lua provided by RyzenAPI
-- Game: addappid(1878970)

-- MAIN APPLICATION
addappid(1878970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878971, 1, "d701293c84eb0a11cb898108b4457ba2ec0c9c90cee5cb2cdcd7f46e958d4078")
