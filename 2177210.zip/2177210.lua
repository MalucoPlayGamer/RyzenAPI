-- Lua provided by RyzenAPI
-- Game: Mantra

-- MAIN APPLICATION
addappid(2177210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177211, 1, "716e294ca143edb983217851978bba9d25e4845ea5f082ca5c4ca7ae0afe266a")
addappid(2177212, 1, "0d1ccbb38630e6f7f362ca7ca3eee0017ab9e4ce28fc6b826027e8bef38d0f58")

