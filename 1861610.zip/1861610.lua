-- Lua provided by RyzenAPI
-- Game: Endorphin Vice

-- MAIN APPLICATION
addappid(1861610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d")
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12")
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9")
addappid(1861610, 1, "9653b3b514d659609defd2e9ce439285796905666b1736c08e42880e533c0bea")
addappid(1861611, 1, "7489182c47f6a761d23386980f67532ee1b2d6b49a6ed40c3d5de146c142e7a4")

