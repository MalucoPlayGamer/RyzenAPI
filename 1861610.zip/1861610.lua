-- Lua provided by RyzenAPI
-- Game: Endorphin Vice

-- MAIN APPLICATION
addappid(1861610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861611, 1, "7489182c47f6a761d23386980f67532ee1b2d6b49a6ed40c3d5de146c142e7a4")
