-- Lua provided by RyzenAPI
-- Game: Twilight Oracle

-- MAIN APPLICATION
addappid(2338490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338491, 1, "d4a2926c8079263e64c8d1f10812107972a0ceaa7caf07246bca1748f608906f")
addappid(2338492, 1, "7bfd7d330f4f6a17010bb443fb427e397d8f3bc23a7c133d11c60b776087980e")
addappid(2338493, 1, "921ee0226f2f3d672937fca59cecb5deb2c64d6bb8dd909c7bc6bdcc1203b5c7")

