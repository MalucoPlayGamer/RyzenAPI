-- Lua provided by RyzenAPI 
-- Game: Dragon Spirits 2
addappid(1965190)
addappid(1965191, 1, "e9917973ee16bd554326405fe08047b770009ad769ab881c8a458baff91c41a5")
