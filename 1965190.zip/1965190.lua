-- Lua provided by RyzenAPI
-- Game: Dragon Spirits 2

-- MAIN APPLICATION
addappid(1965190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1965191, 1, "e9917973ee16bd554326405fe08047b770009ad769ab881c8a458baff91c41a5")

