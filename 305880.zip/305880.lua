-- Lua provided by RyzenAPI
-- Game: Game: Leona's Tricky Adventures

-- MAIN APPLICATION
addappid(305880)
addappid(333720)
-- Game: addappid(305880)

-- MAIN APP DEPOTS / PACKAGES
addappid(305881, 1, "651a18558bef756428e7fc3d444635e4aae6cc0b5835fda9ba359960a3fd4e3e")
