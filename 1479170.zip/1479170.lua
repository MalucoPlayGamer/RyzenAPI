-- Lua provided by RyzenAPI
-- Game: Meatball

-- MAIN APPLICATION
addappid(1479170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479171, 1, "b14b71e59ea873350d6af1f20ba700ec3ace92a88b768450961e657d3c241a20")

