-- Lua provided by RyzenAPI
-- Game: Labyronia RPG

-- MAIN APPLICATION
addappid(391260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(391261, 1, "44a0a3e6b3e2c0fc08d65a7bfedfd9fdb886915f7e57df64da82a969dcb30e4d")

