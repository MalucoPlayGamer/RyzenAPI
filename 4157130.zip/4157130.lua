-- Lua provided by RyzenAPI
-- Game: Dark Pals: The 1st Floor

-- MAIN APPLICATION
addappid(4157130)

-- MAIN APP DEPOTS / PACKAGES
addappid(4157131, 1, "f0553aec8a8550b7deee04cf5eec6bc0b3fd13a407b189a4201260b5c9198251")
