-- Lua provided by RyzenAPI
-- Game: Dark Pals: The 1st Floor

-- MAIN APPLICATION
addappid(4157130)

-- MAIN APP DEPOTS / PACKAGES
addappid(4157131, 1, "f0553aec8a8550b7deee04cf5eec6bc0b3fd13a407b189a4201260b5c9198251")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4768220)
addappid(4768230)
