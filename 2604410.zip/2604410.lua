-- Lua provided by RyzenAPI
-- Game: Game: Bride into the Cave

-- MAIN APPLICATION
addappid(2604410)
-- Game: addappid(2604410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604411, 1, "f8667252710baef8b48b80e4d2cf7f0bd5a8701e84a6c7ce8889510f49539e70")
