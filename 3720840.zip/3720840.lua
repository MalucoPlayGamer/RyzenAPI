-- Lua provided by SkyAPI 
-- Game: Boxville 2 Soundtrack
addappid(3720840)
addappid(3720841, 1, "772134d58b3dfdeee6b99f94cb3e46ec6f97bf5b794fcd26f37fe2dd70beadb6")
addappid(3720842, 1, "6acd3efb7585e51cb4c7e2fb6b3fb2b27c92bb43c22b37053ac7bfa36bdc394b")
