-- Lua provided by SkyAPI 
-- Game: A YEAR OF SPRINGS
addappid(1688580)
addappid(1688581, 1, "b411798dd4ab83a8e00037c8b57656cb87497bc471180f536546690ef53ee9d5")
