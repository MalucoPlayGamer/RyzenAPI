-- 1688580's Lua and Manifest Created by Hubcap Manifest
-- A YEAR OF SPRINGS
-- Created: August 17, 2026 at 03:57:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1688580, 1, "513a0d3088bb47aa9745f9abdc660a2f2474b005398e58c43e38fec8e61f0e76") -- A YEAR OF SPRINGS
-- MAIN APP DEPOTS
addappid(1688581, 1, "b411798dd4ab83a8e00037c8b57656cb87497bc471180f536546690ef53ee9d5") -- Game
setManifestid(1688581, "207552851141670331", 293990992)
-- DLCS WITH DEDICATED DEPOTS
-- A YEAR OF SPRINGS - Fan Pack (AppID: 4654570)
addappid(4654570)
addappid(4654570, 1, "075083669840daea3ad93ba3ac9e4bd20dc8075d1efe14fa3463f2bebcaaee8b") -- A YEAR OF SPRINGS - Fan Pack - Depot 4654570
setManifestid(4654570, "3912937821594670510", 24005006)