-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Heroine Character Pack 4

-- MAIN APPLICATION
addappid(1378450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378450,0,"27fe2fe45880e663462b7b3a454a29793ca17b1811da2d80b36d473e6c77a6ae")

