-- Lua provided by RyzenAPI
-- Game: addappid(846010)

-- MAIN APPLICATION
addappid(846010)

-- MAIN APP DEPOTS / PACKAGES
addappid(846011, 1, "904daee611173f5f23be645e61533f9a0069dae5b7ec74dc8bf10f139e756f0c")
