-- Lua provided by RyzenAPI
-- Game: Game: AppID 629280

-- MAIN APPLICATION
addappid(629280)
-- Game: addappid(629280)

-- MAIN APP DEPOTS / PACKAGES
addappid(629281, 1, "bc219c8f6988769ade75c7732947e6233c69a38c8a75be993058c7c83f4a4449")
addappid(629282, 1, "9e40db4b25e8ddb2172b8de6c49449be2d02aef79af001451d1c256713d6de3f")
addappid(629283, 1, "bfbfd720c057e22e030fdb51230a948a6efc2f80885c8e3fb551a8e7a67310fd")
