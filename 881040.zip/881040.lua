-- Lua provided by RyzenAPI
-- Game: addappid(881040)

-- MAIN APPLICATION
addappid(881040)
addappid(1223130)

-- MAIN APP DEPOTS / PACKAGES
addappid(881041, 1, "8265ad9d63a8836fc630c8d2daf677e9c7f858e87a46d4e671b79d6c1c4cf5d5")
