-- Lua provided by RyzenAPI
-- Game: addappid(414920)

-- MAIN APPLICATION
addappid(414920)

-- MAIN APP DEPOTS / PACKAGES
addappid(414921, 1, "15caf3eb9ffb6293c334270c862e4923565fe608179167e6e86618c2e7aec230")
