-- Lua provided by RyzenAPI 
-- Game: A Day For A Kitten
addappid(742230)
addappid(742231, 1, "5704d8dc2a629a7d5b4d2bfe72d4a28ce92d054fe6b31b745cf111524eaf5a0d")
