-- Lua provided by RyzenAPI 
-- Game: AppID 3045310
addappid(3045310)
addappid(3045311, 1, "03a16187e588dc14a7364b077640ae2f40a7008edcc2d6a3d38d1e1abb828f9d")
