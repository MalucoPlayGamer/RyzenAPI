-- Lua provided by RyzenAPI
-- Game: DIY Girls in A Ghost House

-- MAIN APPLICATION
addappid(1723640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723640,0,"f3c658f2cd7c28b7a98ac6e860dc7a41ca5feb5ab0a516654e7f0004de389839")

