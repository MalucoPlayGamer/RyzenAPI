-- Lua provided by RyzenAPI
-- Game: Gynocracy Demo

-- MAIN APPLICATION
addappid(2543900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543901, 1, "9cdf0a0e5e13e4417388c281a4a5f72b646a387ca4b590c986be2d3230331869")
