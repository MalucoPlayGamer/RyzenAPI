-- Lua provided by RyzenAPI
-- Game: Airranger Trial Version

-- MAIN APPLICATION
addappid(885980)
-- Game: addappid(885980)

-- MAIN APP DEPOTS / PACKAGES
addappid(885981, 1, "872772002b58678601f19c1cbff5982d112b777f2412a1184e290bd376150dd2")
