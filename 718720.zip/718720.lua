-- Lua provided by RyzenAPI
-- Game: 718720

-- MAIN APPLICATION
addappid(718720)
-- Game: addappid(718720)

-- MAIN APP DEPOTS / PACKAGES
addappid(718721, 1, "8008b8166416b8efc601288f14018a6b6a74951ed5f565cb71a1b4102c67e15b")
