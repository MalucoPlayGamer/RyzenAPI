-- Lua provided by RyzenAPI
-- Game: Demon Hunt Playtest

-- MAIN APPLICATION
addappid(3080100)
-- Game: addappid(3080100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080101, 1, "80e9b370c4ee0373ac624fdf8238607cb0ad12b3e26141130aeb6a4383a8dd55")
