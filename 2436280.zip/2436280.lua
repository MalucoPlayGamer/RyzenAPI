-- Lua provided by RyzenAPI
-- Game: Bung Ball

-- MAIN APPLICATION
addappid(2436280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436282,0,"cc45a7d20ee34fe1c692cadfc17a8d1f7afde26887eca5c8633ec3889d7ef347")
addappid(2436283,0,"e9c70f29606f48d4446b727d0dbcad8b2403fb856fb422369b62d39d77bc27af")

