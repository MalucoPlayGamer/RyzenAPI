-- Lua provided by RyzenAPI
-- Game: AppID 1007940

-- MAIN APPLICATION
addappid(1007940)
addappid(1031620)
addappid(1033760)
addappid(1037510)
addappid(1047400)
addappid(1114450)
addappid(1118710)
addappid(1120250)
addappid(1133960)
addappid(1138340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007941, 1, "33cabfc230e9404fbd77b7d7e194bdb94f72b9e077ecce4b47668a91bdb00b4d")
