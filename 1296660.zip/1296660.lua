-- Lua provided by SkyAPI 
-- Game: AppID 1296660
addappid(1296660)
addappid(1296661, 1, "f226cf79722bb1a23a7669cda4d2e8daf468613f46016c108b74746545ff772e")
addappid(1296662, 1, "ee8a4233e3ba20aaf3907b5ab592c9a6ff2d9844bfffe0ab68f57f7293ab7407")
