-- Lua provided by RyzenAPI
-- Game: Wartorn

-- MAIN APPLICATION
addappid(1296660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1296661, 1, "f226cf79722bb1a23a7669cda4d2e8daf468613f46016c108b74746545ff772e")
addappid(1296662, 1, "ee8a4233e3ba20aaf3907b5ab592c9a6ff2d9844bfffe0ab68f57f7293ab7407")

