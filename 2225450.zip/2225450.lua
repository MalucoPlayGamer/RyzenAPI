-- Lua provided by RyzenAPI
-- Game: Starway: BaRaider VR - Free Trial

-- MAIN APPLICATION
addappid(2225450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225451, 1, "f897b7273b4bacd7f17b7e29ac685968999da82bdc1523ef948b5cdee4dbe76f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
