-- Lua provided by RyzenAPI
-- Game: Duel Timers

-- MAIN APPLICATION
addappid(2380830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2380831, 1, "e6166898dd131c289de89d6d216d42b34b59c3cca79d20eaae9a78cdf2294d8a")
addappid(2380833, 1, "b4e3dc5a49f2aac787c2935fe4490c81d005cc6ab4ce42fe736d2cc1dfdd48a5")

