-- Lua provided by RyzenAPI
-- Game: 2380830

-- MAIN APPLICATION
addappid(2380830)
-- Game: addappid(2380830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380831, 1, "e6166898dd131c289de89d6d216d42b34b59c3cca79d20eaae9a78cdf2294d8a")
addappid(2380833, 1, "b4e3dc5a49f2aac787c2935fe4490c81d005cc6ab4ce42fe736d2cc1dfdd48a5")
