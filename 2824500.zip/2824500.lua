-- Lua provided by RyzenAPI
-- Game: Shockwaves

-- MAIN APPLICATION
addappid(2824500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824501, 1, "07319c1b50c6209eb2f830827df007df88e7605ce22f255d6af6fddce8d4f72e")
