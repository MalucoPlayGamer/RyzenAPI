-- Lua provided by RyzenAPI
-- Game: Critter Crops

-- MAIN APPLICATION
addappid(1641120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641121, 1, "b01345ed7efdd0ed8d1b260f366afbeac5f878e598f28052b538c6c5b8983245")
