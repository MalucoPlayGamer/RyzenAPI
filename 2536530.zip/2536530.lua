-- Lua provided by RyzenAPI
-- Game: Game: The Pony Factory

-- MAIN APPLICATION
addappid(2536530)
-- Game: addappid(2536530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536531, 1, "3976f621748f769cdfef6a1aea9854a9be1ceb632fbd9f9e481a38c6e490dede")
