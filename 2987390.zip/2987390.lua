-- Lua provided by RyzenAPI
-- Game: AppID 2987390

-- MAIN APPLICATION
addappid(2987390)
-- Game: addappid(2987390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987391, 1, "52c297a6a20eaa15ea181e0badd112ef8b4207d8b9888e7a5323e0af4c943cc2")
