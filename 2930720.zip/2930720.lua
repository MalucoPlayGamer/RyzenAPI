-- Lua provided by RyzenAPI
-- Game: Birds Huddled Together

-- MAIN APPLICATION
addappid(2930720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930721, 1, "099d8a0511e800c1cb055016e6e5541edcdcc84c472a293fac937edea722a1a7")
