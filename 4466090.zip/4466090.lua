-- Lua provided by RyzenAPI
-- Game: The Forbidden Tomes of Olipos

-- MAIN APPLICATION
addappid(4466090)

-- MAIN APP DEPOTS / PACKAGES
addappid(4466091,0,"80c48e59238923d983ff1b324511287af7d988f93f12f6506a4bcfa57c5e8711")

