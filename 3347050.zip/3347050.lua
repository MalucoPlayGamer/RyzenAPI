-- Lua provided by SkyAPI 
-- Game: 101 Cats in Singapore
addappid(3347050)
addappid(3347051, 1, "058fed5f5ee87f7d980533b6a63cf70c0f869c26bf6d4084b2389ea5d564eba7")
