-- Lua provided by RyzenAPI
-- Game: addappid(3347050)

-- MAIN APPLICATION
addappid(3347050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347051, 1, "058fed5f5ee87f7d980533b6a63cf70c0f869c26bf6d4084b2389ea5d564eba7")
