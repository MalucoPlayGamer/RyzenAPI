-- Lua provided by RyzenAPI
-- Game: AppID 843660

-- MAIN APPLICATION
addappid(843660)

-- MAIN APP DEPOTS / PACKAGES
addappid(843661, 1, "76ff0cc7a6399f8dcca3facb37e2479ceca806d9dbb3987b5fbf8a316038d08b")

