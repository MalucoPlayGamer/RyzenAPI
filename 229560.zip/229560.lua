-- Lua provided by RyzenAPI
-- Game: Game: AppID 229560

-- MAIN APPLICATION
addappid(229560)
-- Game: addappid(229560)

-- MAIN APP DEPOTS / PACKAGES
addappid(229561, 1, "a9826be003c82a607bbe559609568ad47a3192d1b10849d817c6ea8fa3c0bc7e")
