-- Lua provided by RyzenAPI
-- Game: Game: CRIXUS: Life of free Gladiator

-- MAIN APPLICATION
addappid(1564900)
-- Game: addappid(1564900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564901, 1, "11d3ef7a3ef0433f6a28c5fd5ab523321f3113b2aa05664fcaf4c11a88a35743")
