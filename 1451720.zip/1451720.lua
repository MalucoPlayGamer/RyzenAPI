-- Lua provided by RyzenAPI
-- Game: Minesweeper Classy

-- MAIN APPLICATION
addappid(1451720)
-- Game: addappid(1451720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451721, 1, "0ddf0f1e7857d10b5daba7ab3c4aba9e375682475eb40db37a777d4be438ddde")
