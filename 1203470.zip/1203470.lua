-- Lua provided by RyzenAPI
-- Game: Earth Analog

-- MAIN APPLICATION
addappid(1203470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203471, 1, "3aa882ceb6ee5f339679991b7d66bd452f3813cc81416da147cad75e4fdfdee3")
