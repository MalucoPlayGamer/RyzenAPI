-- Lua provided by RyzenAPI
-- Game: Increment

-- MAIN APPLICATION
addappid(1899820)
addappid(2417460)
addappid(2417461)
addappid(2417462)
-- Game: addappid(1899820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899821, 1, "dcf5e7df172f7b7b7ae87c54635e953abf225bf1f24c658f2ae40516ab48735d")
