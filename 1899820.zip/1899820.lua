-- Lua provided by SkyAPI 
-- Game: Increment
addappid(1899820)
addappid(1899821, 1, "dcf5e7df172f7b7b7ae87c54635e953abf225bf1f24c658f2ae40516ab48735d")
addappid(2417460)
addappid(2417461)
addappid(2417462)
