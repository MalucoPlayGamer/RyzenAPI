-- Lua provided by RyzenAPI
-- Game: Game: World of Fate

-- MAIN APPLICATION
addappid(2241860)
-- Game: addappid(2241860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241861, 1, "2c6ba16f74465c25c6166a6ad3286576b45623a2af1b8b08195b96fe74db81fe")
