-- Lua provided by RyzenAPI
-- Game: Run and Fire

-- MAIN APPLICATION
addappid(360760)
addappid(363730)
addappid(363731)
addappid(363732)

-- MAIN APP DEPOTS / PACKAGES
addappid(360761, 1, "9ff0b3b26f2c894dc839c9179808c7d2e6208d5538c5415e74b4331b1b83cf8d")
