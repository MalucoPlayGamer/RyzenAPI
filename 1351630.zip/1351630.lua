-- Lua provided by RyzenAPI
-- Game: AppID 1351630

-- MAIN APPLICATION
addappid(1351630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351631, 1, "47bcf8eb50f2fa047d3390cf62953b1b927c5035db87ec556305013a086d7b8b")
addappid(1627580, 0, "66b26891e732f5c867c351811a514d6dd3d06f98cd4adc61a34c2b5b1abc15e4")
addappid(1627581, 0, "61a0f890e1bf97d3e6d2b554a429d89f6bb6f2c9e1d571c5da8e36fc7c474589")
addappid(1627582, 0, "48e8f595ec0deb2c92a1bda9bb18a2d7eae245ef22432be0b3cedda30ae7850c")
addappid(1627583, 0, "ec0920ea0c7547bb6cb646a98bb29ecb96e5d65da2ffd91e3074ea63d3c1aa84")
addappid(1627584, 0, "3e3e4861db91a78d845834057c8d5cf9dccce012f6388f2ac76df4d54c0afb3f")
addappid(1627585, 0, "b7a3e62b91e0ea8e9d8c4c19fcd8e36dcf9681ec645df2a65e307b0f3e556fbc")
addappid(1627586, 0, "96d66ccb1b0fe2c7cca271e476a65af4a9706318498d4ce777fdfe54c383a491")
addappid(1636780, 0, "814be4c2816106abe13e15080ff4bdc4e645f040ee0ddbf19121347f11f49a77")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
