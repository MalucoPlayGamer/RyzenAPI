-- Lua provided by RyzenAPI
-- Game: AppID 2016140

-- MAIN APPLICATION
addappid(2016140)
-- Game: addappid(2016140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016141, 1, "e9629bab71945d133d17c3addd581e67968d4156fddbec195b35c76547b08810")
