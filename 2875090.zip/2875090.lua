-- Lua provided by RyzenAPI
-- Game: Idle Fairy Fantasy

-- MAIN APPLICATION
addappid(2875090)
-- Game: addappid(2875090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875091, 1, "c051701a858846806c82952c98a460889646028b8b0bf65abe6354f7b2b9541e")
