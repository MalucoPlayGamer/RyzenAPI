-- Lua provided by RyzenAPI
-- Game: EvilQuest

-- MAIN APPLICATION
addappid(263820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(263821, 1, "9b148cdd4948d1d46c6cd59d87861e4363a8b2ed980f6f896110f993c3a7218f")

