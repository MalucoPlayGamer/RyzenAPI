-- Lua provided by RyzenAPI
-- Game: 263820

-- MAIN APPLICATION
addappid(263820)
-- Game: addappid(263820)

-- MAIN APP DEPOTS / PACKAGES
addappid(263821, 1, "9b148cdd4948d1d46c6cd59d87861e4363a8b2ed980f6f896110f993c3a7218f")
