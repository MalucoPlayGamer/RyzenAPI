-- Lua provided by SkyAPI 
-- Game: AppID 1969740
addappid(1969740)
addappid(1969741, 1, "0709a95f6729e13dac3e396914b0960a631d6e9c756dd9bac79c1fbf937e11ee")
