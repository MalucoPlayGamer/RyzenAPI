-- Lua provided by RyzenAPI
-- Game: Starion Tactics

-- MAIN APPLICATION
addappid(312960)
-- Game: addappid(312960)

-- MAIN APP DEPOTS / PACKAGES
addappid(312961, 1, "1c907d67c4d91835ed22e9b93e66454fe78e6bbc883559cb15548e8e89123c03")
