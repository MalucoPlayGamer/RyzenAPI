-- Lua provided by RyzenAPI
-- Game: Game: AppID 929020

-- MAIN APPLICATION
addappid(929020)
-- Game: addappid(929020)

-- MAIN APP DEPOTS / PACKAGES
addappid(929021, 1, "49f10447c02e0d1d63e532bfa4bc6bf259ad246a719a1ec694cd0acc4b7c48d1")
