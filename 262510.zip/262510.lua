-- Lua provided by RyzenAPI
-- Game: 262510

-- MAIN APPLICATION
addappid(262510)
-- Game: addappid(262510)

-- MAIN APP DEPOTS / PACKAGES
addappid(262511, 1, "6e853dc2d69476bee7d09fee9b947496536603560aef60d7312a3de48a389f19")
