-- Lua provided by RyzenAPI
-- Game: Game: AppID 2393940

-- MAIN APPLICATION
addappid(2393940)
-- Game: addappid(2393940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393941, 1, "13187504473b966745f03750a98e9cbc169016aaa1af771a2ef91e4e05e2c866")
