-- Lua provided by RyzenAPI
-- Game: 无限之书：侠之章 Story Of Infinity: Xia Demo

-- MAIN APPLICATION
addappid(2393940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393941, 1, "13187504473b966745f03750a98e9cbc169016aaa1af771a2ef91e4e05e2c866")

