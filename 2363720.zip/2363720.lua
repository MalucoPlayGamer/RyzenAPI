-- Lua provided by RyzenAPI
-- Game: 2363720

-- MAIN APPLICATION
addappid(2363720)
-- Game: addappid(2363720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363721, 1, "5e41181e839b102127ca9f0cbd53dfc2d0c145919d53342ee611f1ad0e7930a0")
