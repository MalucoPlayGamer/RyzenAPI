-- Lua provided by RyzenAPI 
-- Game: AppID 2363720
addappid(2363720)
addappid(2363721, 1, "5e41181e839b102127ca9f0cbd53dfc2d0c145919d53342ee611f1ad0e7930a0")
