-- Lua provided by RyzenAPI
-- Game: AppID 320430

-- MAIN APPLICATION
addappid(320430)
-- Game: addappid(320430)

-- MAIN APP DEPOTS / PACKAGES
addappid(320431, 1, "43165e65a1d64e976dd456d3c965d9a9a429944bfb95d4d203fa1d86cff53d89")
addappid(320432, 1, "03240daf07cb0cc768ec3edcb7422a58351c257d83826c049269d69af3aeb637")
