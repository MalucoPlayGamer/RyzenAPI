-- Lua provided by RyzenAPI
-- Game: AppID 320430

-- MAIN APPLICATION
addappid(320430)
addappid(858930)
addappid(899140)
addappid(942590)
addappid(987500)
addappid(1644730)
addappid(4103430)
addappid(4634650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(320431, 1, "43165e65a1d64e976dd456d3c965d9a9a429944bfb95d4d203fa1d86cff53d89")
addappid(320432, 1, "03240daf07cb0cc768ec3edcb7422a58351c257d83826c049269d69af3aeb637")

