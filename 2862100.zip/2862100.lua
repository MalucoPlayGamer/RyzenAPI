-- Lua provided by RyzenAPI
-- Game: Game: RetroArch - Vircon32

-- MAIN APPLICATION
addappid(2862100)
-- Game: addappid(2862100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862101, 1, "252ce96fda688158db1a185c88e80320a1b972ca956981356cf6a6342bc767cb")
addappid(2862102, 1, "45503f6f84fdfa86c85f768839e93bd2c8013fd86322cf4b0c8711b06254816d")
