-- Lua provided by RyzenAPI 
-- Game: 日日夜夜 原创音乐集
addappid(1446820)
addappid(1446821, 1, "9bdac3cea6b48ba47f43a29cdab2d359318b43de9fe265733c60f15990d5bc43")
addappid(1446822, 1, "b62744584423d6e4d199349fe1e0abe3a11615ff376d9ebb50785d75a9314f00")
