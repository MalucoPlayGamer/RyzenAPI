-- Lua provided by RyzenAPI
-- Game: Game: Zombie Freaks

-- MAIN APPLICATION
addappid(1610130)
-- Game: addappid(1610130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610131, 1, "601209b36983c4fe7306cbd8707f343856def132973a387212b3bd27e29f4eb0")
