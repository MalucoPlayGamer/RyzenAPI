-- Lua provided by RyzenAPI 
-- Game: Shan Hai Express
addappid(2478160)
addappid(2478161, 1, "c557cb605d8aecc1f098669574ce4341801db7c8f78d64b7fae6f443c44007f4")
