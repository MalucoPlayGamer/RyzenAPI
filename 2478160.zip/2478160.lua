-- Lua provided by RyzenAPI
-- Game: 2478160

-- MAIN APPLICATION
addappid(2478160)
-- Game: addappid(2478160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478161, 1, "c557cb605d8aecc1f098669574ce4341801db7c8f78d64b7fae6f443c44007f4")
