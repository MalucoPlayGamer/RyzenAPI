-- Lua provided by RyzenAPI
-- Game: 3033250

-- MAIN APPLICATION
addappid(3033250)
-- Game: addappid(3033250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3033251, 1, "3c3a5a42cf400e9c55ce64cc990ad26a35f5cd36e7ffba80853001e3fc2ef12c")
addappid(3033252, 1, "1e9dfcfdf5b4240d191352afa3eef13b913f3775ced111a36760ed5ca5dedff2")
