-- Lua provided by RyzenAPI
-- Game: House of Snark 6-in-1 Bundle

-- MAIN APPLICATION
addappid(486810)

-- MAIN APP DEPOTS / PACKAGES
addappid(486811, 1, "ad3e4f1b3d8c37c8599fd8787f04990cbbf71670ddcbd0d8cf69d1ba66a52631")
addappid(486812, 1, "0f2fda4106e227362aabab56ba8af932bd87425140891ec7b263c4e34c5d622e")
addappid(486813, 1, "9ac0325df5b428f8b1e36ecaff88947566962deaf62da6dcfe75776e70a58eea")
addappid(486814, 1, "1fa0a6edc0c84c09eaf25604c74bead448fd6b31d97d73cea25fda125dc1a369")
addappid(486815, 1, "494db2a759c8d31bf73e492e5279e5520be5f46541265f7fa3d3e5bad131e845")
addappid(486816, 1, "4058d2acdc1aecf52e9cf55b04cf72428aceeaf176882e08c0031837a0403f1e")
addappid(486817, 1, "adf2c7baa16377b315df7bc0c4a3010ded4b244e793f48e0c8f6e85a3952ba69")
addappid(486818, 1, "2caf5fcee96284a21bee14cd3eb89315a1f52525487183b4967965f5cb5d4bb7")

