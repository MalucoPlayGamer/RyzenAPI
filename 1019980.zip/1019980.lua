-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Cao Pi Special Scenario / 曹丕「追加ＩＦシナリオセット」

-- MAIN APPLICATION
addappid(1019980)
-- Game: addappid(1019980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019980,0,"7751200422b001850e422155085150b50b6b1eecb217eff50c8ee632b712b9b8")
