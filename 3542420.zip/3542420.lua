-- Lua provided by RyzenAPI
-- Game: Liminal Lane

-- MAIN APPLICATION
addappid(3542420)
-- Game: addappid(3542420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3542421, 1, "f4286fe720343d3768204c02155aa0f1c72c0394e38c6541089ca0032b1f97f3")
