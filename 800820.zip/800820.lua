-- Lua provided by RyzenAPI
-- Game: 800820

-- MAIN APPLICATION
addappid(800820)
-- Game: addappid(800820)

-- MAIN APP DEPOTS / PACKAGES
addappid(800821, 1, "444579d8d253405319bf4f6e1e3b82d750c1108ac04311c455dcc1b5b0bf90ec")
