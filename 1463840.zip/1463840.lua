-- Lua provided by RyzenAPI
-- Game: Warp Out

-- MAIN APPLICATION
addappid(1463840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463841, 1, "8ad8d593e9844e7d6c2e550fbc5cc5ed4764cc00d6a3e9834154b78c7f4b0dae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
