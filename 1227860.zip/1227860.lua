-- Lua provided by RyzenAPI
-- Game: Game: AppID 1227860

-- MAIN APPLICATION
addappid(1227860)
-- Game: addappid(1227860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227861, 1, "dfdd4292bd7c6b2b4943fa23c528c0d7ba393c0d915252481e929db1570a8e6a")
