-- Lua provided by RyzenAPI
-- Game: AppID 461810

-- MAIN APPLICATION
addappid(461810)
-- Game: addappid(461810)

-- MAIN APP DEPOTS / PACKAGES
addappid(461811, 1, "e626ebd59348766b458eaa4eb1fd5e383fabe2b40c8c8e27c8d46fa325d80852")
