-- Lua provided by RyzenAPI
-- Game: Game: AppID 1225110

-- MAIN APPLICATION
addappid(1225110)
-- Game: addappid(1225110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225111, 1, "91229101ba82f3188b86010612b3c7cf8d2466f12d8a4b3a210b1d2ae454b777")
