-- Lua provided by RyzenAPI
-- Game: Game: Project Unknown

-- MAIN APPLICATION
addappid(2115390)
-- Game: addappid(2115390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115391, 1, "a75e682975a3633e354723c49dd911bfd76056391dd5d658c05abc0ecd30056c")
