-- Lua provided by RyzenAPI
-- Game: Project Unknown

-- MAIN APPLICATION
addappid(2115390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115391, 1, "a75e682975a3633e354723c49dd911bfd76056391dd5d658c05abc0ecd30056c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
