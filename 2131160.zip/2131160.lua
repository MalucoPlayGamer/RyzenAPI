-- Lua provided by RyzenAPI
-- Game: Curse of Black Bone Demo

-- MAIN APPLICATION
addappid(2131160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131161, 1, "b00b42d2d5821fe212cb0efe0d60f0d606d6dbcbbaa768244274cf23616b2db8")

