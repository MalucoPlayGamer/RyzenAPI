-- Lua provided by RyzenAPI 
-- Game: AppID 1546110
addappid(1546110)
addappid(1546111, 1, "4427630a7787195f1154c00409ada2271d1719302b0774a9426d4296236ddfe8")
