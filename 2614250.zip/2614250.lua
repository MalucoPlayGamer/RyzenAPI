-- Lua provided by SkyAPI 
-- Game: AppID 2614250
addappid(2614250)
addappid(2614251, 1, "02fceb6e2e6490c268b6503c4ec64c6ed499b717b61d7ca0ac5d5f96f6496c4d")
