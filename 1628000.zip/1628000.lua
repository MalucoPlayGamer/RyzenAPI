-- Lua provided by RyzenAPI
-- Game: Game: Superpantsu Harematchii

-- MAIN APPLICATION
addappid(1628000)
-- Game: addappid(1628000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628001, 1, "69b81b72f2dd7fcb69f990456c21e182e518a6d22aea546d41d10c0a414b71fe")
