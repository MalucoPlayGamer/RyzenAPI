-- Lua provided by SkyAPI 
-- Game: Superpantsu Harematchii
addappid(1628000)
addappid(1628001, 1, "69b81b72f2dd7fcb69f990456c21e182e518a6d22aea546d41d10c0a414b71fe")
