-- Lua provided by SkyAPI 
-- Game: Finger Jets
addappid(830520)
addappid(830521, 1, "47dc6cc8bc2e3b4e45bab46834d736b607715d4960edbe6b87ab71b27b3525f1")
addappid(830522, 1, "d1c389d61b25453c61470285c362fb95f438daf7f1d48986a3a057ee898bda11")
addappid(830523, 1, "9c18975faf28fd7fa16605c2bf4d4d82703abfa41c4689b0e34d8ebbd82404e0")
