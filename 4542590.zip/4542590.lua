-- 4542590's Lua and Manifest Created by Hubcap Manifest
-- Fish Slayer
-- Created: August 21, 2026 at 20:15:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4542590) -- Fish Slayer
-- MAIN APP DEPOTS
addappid(4542591, 1, "91bd0d545b22b0ecf3241dad5e943984467e7c4835644e4d01eb16ba50d2d01b") -- Depot 4542591
setManifestid(4542591, "479782775953260566", 420005308)