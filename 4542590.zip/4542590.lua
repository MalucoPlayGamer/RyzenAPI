-- Lua provided by RyzenAPI
-- Game: Fish Slayer

-- MAIN APPLICATION
addappid(4542590) -- Fish Slayer

-- MAIN APP DEPOTS / PACKAGES
addappid(4542591, 1, "91bd0d545b22b0ecf3241dad5e943984467e7c4835644e4d01eb16ba50d2d01b") -- Depot 4542591

