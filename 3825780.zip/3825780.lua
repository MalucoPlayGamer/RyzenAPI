-- Lua provided by RyzenAPI
-- Game: WonderKing

-- MAIN APPLICATION
addappid(3825780)
