-- Lua provided by RyzenAPI
-- Game: Gunbot Diplomacy

-- MAIN APPLICATION
addappid(2800840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800841, 1, "d905484c40e7ede92522929150334d5730e541dff68df7a2c4c0d2837f0a5d2e")
