-- Lua provided by RyzenAPI
-- Game: addappid(293540)

-- MAIN APPLICATION
addappid(293540)
addappid(316710)
addappid(318670)

-- MAIN APP DEPOTS / PACKAGES
addappid(293541, 1, "761c678252da227e16cea9f127a57edbaf1a678a4ac5d637610b87984f64d4b2")
