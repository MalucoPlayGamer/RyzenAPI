-- Lua provided by RyzenAPI
-- Game: 1212870

-- MAIN APPLICATION
addappid(1212870)
-- Game: addappid(1212870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212871, 1, "1aca8ea09fa87e60d2f2a491b8055493d16fc3a6b055997bd607ddaf46c47609")
