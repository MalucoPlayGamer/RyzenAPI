-- Lua provided by RyzenAPI
-- Game: Game: Lovely Archeologists

-- MAIN APPLICATION
addappid(1782390)
-- Game: addappid(1782390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782391, 1, "49046cd446e7b2772190b40201041bdb65b026e0ca1ff698ea5c6838d026b287")
