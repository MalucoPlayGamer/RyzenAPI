-- Lua provided by RyzenAPI 
-- Game: Lonely Mountains: Downhill - Soundtrack
addappid(1399610)
addappid(1399611, 1, "f3afdc6fa87537e5ea8c0bac2323fb8c2f7c56d8003688e22b0c118c5b0b9fb5")
addappid(1399612, 1, "d4b24779282cf2e40460dd2bd7196b7791b85ef3599c76dd54229ce43f6063fc")
