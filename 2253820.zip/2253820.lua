-- Lua provided by RyzenAPI 
-- Game: AppID 2253820
addappid(2253820)
addappid(2253821, 1, "b4be20c8d2df85f75ecc024ff90f95f4c02cfc558885e392f78151aee1b8457c")
