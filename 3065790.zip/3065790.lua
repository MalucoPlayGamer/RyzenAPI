-- Lua provided by RyzenAPI
-- Game: JustFutanari 2 Demo

-- MAIN APPLICATION
addappid(3065790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3065791, 1, "d2394988a819ec37f57c498a5f0b04c3ffa659f359bdeae45db54b34b0c9c4ac")

