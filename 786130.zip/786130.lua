-- Lua provided by SkyAPI 
-- Game: AppID 786130
addappid(786130)
addappid(786131, 1, "e78f40ef333baabdb5b126a2a9048bd02b807bf3914f34d597dae13b8fb4aa4d")
