-- Lua provided by RyzenAPI
-- Game: Teeny Heist

-- MAIN APPLICATION
addappid(786130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(786131, 1, "e78f40ef333baabdb5b126a2a9048bd02b807bf3914f34d597dae13b8fb4aa4d")

