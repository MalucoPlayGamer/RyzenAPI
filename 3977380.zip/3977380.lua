-- Lua provided by RyzenAPI
-- Game: JAWS: Retro Edition

-- MAIN APPLICATION
addappid(3977380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3977381,0,"006cac7e562cdd91abb9d765648d22700bc9b8c88d980d3b93b35856c49cc24c")

