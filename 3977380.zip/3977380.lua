-- Lua provided by RyzenAPI
-- Game: JAWS: Retro Edition

-- MAIN APPLICATION
addappid(3977380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3977381,0,"006cac7e562cdd91abb9d765648d22700bc9b8c88d980d3b93b35856c49cc24c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
