-- Lua provided by RyzenAPI
-- Game: My Little Blood Cult: Let's Summon Demons

-- MAIN APPLICATION
addappid(2475350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475351, 1, "b06c31c0b15d7d424d36355dda339a456f4b90b6db1aa70367e830870bea05bd")
