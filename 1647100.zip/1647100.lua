-- Lua provided by RyzenAPI
-- Game: addappid(1647100)

-- MAIN APPLICATION
addappid(1647100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647102,0,"b13c7eb6a31d39ae8d88565c745eca3ab334d713fba0f04dc10d72a5ae259fef")
