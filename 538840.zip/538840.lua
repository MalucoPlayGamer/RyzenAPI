-- Lua provided by RyzenAPI 
-- Game: AppID 538840
addappid(538840)
addappid(538841, 1, "4dc5366b5cfdf5faec84953bb1bdea450391e3c27bd3dc628d741e9461e3e08a")
addappid(538842, 1, "7b728ecaa0b44e446685c2a712a1c79be559de37f0e9e5cb9510bcb10bfcddba")
addappid(538843, 1, "d99bd968683ea8fa4da308d34f20e72fdf76cc1b236fabe3669e93476a74037f")
addappid(819290, 0, "75cbff1324bb79777cccfaf30a07c7085894075ae221f914676bbbe52cdc4a35")
