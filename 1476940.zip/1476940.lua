-- Lua provided by RyzenAPI 
-- Game: Skinwalkers
addappid(1476940)
addappid(1476941, 1, "c8154923c2400860639f73d96607e394a312927fde4fb451d6774223d2a9651e")
