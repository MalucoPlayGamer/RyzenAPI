-- Lua provided by RyzenAPI
-- Game: Skinwalkers

-- MAIN APPLICATION
addappid(1476940)
-- Game: addappid(1476940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476941, 1, "c8154923c2400860639f73d96607e394a312927fde4fb451d6774223d2a9651e")
