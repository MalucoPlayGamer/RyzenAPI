-- Lua provided by RyzenAPI
-- Game: Buck Up And Drive!

-- MAIN APPLICATION
addappid(1714590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714591, 1, "3905056b454f38803812955bfd78df1d027fae3640ea4304c3bd52b50593d2b8")
addappid(1714592, 1, "1df2313847f3caab853ffa10bdfe2ce4bb430ccedf7b49637c74205f15ebedc0")
