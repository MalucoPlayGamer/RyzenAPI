-- Lua provided by RyzenAPI
-- Game: 479020

-- MAIN APPLICATION
addappid(479020)
-- Game: addappid(479020)

-- MAIN APP DEPOTS / PACKAGES
addappid(479021, 1, "f5be114a4f4a23365a29418bdafc5bf75c03aed518582badf5302c3722f16811")
