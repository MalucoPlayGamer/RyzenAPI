-- Lua provided by RyzenAPI
-- Game: Zombie World Coronavirus Apocalypse VR

-- MAIN APPLICATION
addappid(1206080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206081, 1, "2fc62d963de84d8783560be03b3ba4ef7dd04cbbc61e752afd1facac8a54314b")
