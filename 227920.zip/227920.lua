-- Lua provided by SkyAPI 
-- Game: Risk
addappid(227920)
addappid(227921, 1, "485d4b8a2158f207d543d0ab6cc99212bb677375c437bee3eaf9a13672c7928f")
