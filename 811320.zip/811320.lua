-- Lua provided by RyzenAPI
-- Game: Jupiter Hell

-- MAIN APPLICATION
addappid(811320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(811321, 1, "f42373cc9a960bc061aee1ebfcae019d25b3c1e20b41c19007de26d57a934f94")
addappid(811322, 1, "e84885778a4603bd4bf573fceb931341e1fb1df79ab2edda9201df56be18effc")
addappid(811323, 1, "09a0ffee12d9cb166e9c435ad4900db8630823dc1949e51719d94fe26af265ba")
addappid(811325, 1, "8681dbf703472baf0d8e2e7e510a13274a49d62f16fcae63f48d2a5987692ea3")

