-- Lua provided by RyzenAPI
-- Game: Kingdom Two Crowns

-- MAIN APPLICATION
addappid(701160)
addappid(980450)
addappid(1299270)
addappid(1708680)

-- MAIN APP DEPOTS / PACKAGES
addappid(701161, 1, "5aae8ca5c454854bdf1b25248fe5f3c01a97c983489767c17930cc8a02156ac3")
addappid(701162, 1, "17174ac183441ce4785eb189f7a80fc0fd9a202494cad02f1ddf4bc3d87aade4")
addappid(701163, 1, "88068941a333be0784b8fd4fe2c414237610909671e189f3068177fc84e0352e")
addappid(988810, 0, "09f7b9d014059b08ea21838c59e9edadb8d14238c0e97a6cbb6d597d98f49174")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2736340)
addappid(3062350)
addappid(3062360)
addappid(3939430)
