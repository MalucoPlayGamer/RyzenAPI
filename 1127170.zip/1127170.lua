-- Lua provided by RyzenAPI
-- Game: addappid(1127170)

-- MAIN APPLICATION
addappid(1127170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127171, 1, "996c85917afa67caaa433caf8dfc82679513c1c3fbec21ad697d83baa0824193")
