-- Lua provided by RyzenAPI
-- Game: DreamFly

-- MAIN APPLICATION
addappid(1127170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1127171, 1, "996c85917afa67caaa433caf8dfc82679513c1c3fbec21ad697d83baa0824193")

