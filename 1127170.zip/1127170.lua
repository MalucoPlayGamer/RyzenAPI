-- Lua provided by SkyAPI 
-- Game: AppID 1127170
addappid(1127170)
addappid(1127171, 1, "996c85917afa67caaa433caf8dfc82679513c1c3fbec21ad697d83baa0824193")
