-- Lua provided by RyzenAPI
-- Game: The Last Summer 那年夏末

-- MAIN APPLICATION
addappid(2583030)
-- Game: addappid(2583030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2583031, 1, "f5d18bed84ac6024613bcbebe320a0688cefffb0797a81492f8e91d266bc7a49")
