-- Lua provided by RyzenAPI
-- Game: Touhou Mystia's Izakaya DLC5 Pack - Makai & Lunar Capital

-- MAIN APPLICATION
addappid(2399331)

-- MAIN APP DEPOTS / PACKAGES
addappid(2831161,0,"852b19716db3348a46ee2e3b930ecc2d86834c533fd0450ed0ad04e59bb6c28f")
addappid(2831162,0,"1650cf4024fd1345a8781f6d1c7a39e8aea788517d4ffc26855978a93dff2776")
