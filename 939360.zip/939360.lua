-- Lua provided by RyzenAPI 
-- Game: Pixel FX Designer
addappid(939360)
addappid(939361, 1, "ac2cf7a60daf935c02b4e0203eb908f2728a32f8f71c54d50035a942ad5f6051")
addappid(939362, 1, "3dabe3827f6ff3328e55e0693cdc2dda17c4ccfb24c792cf09134eaedc0a4de3")
