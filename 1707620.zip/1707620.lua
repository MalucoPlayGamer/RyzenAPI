-- Lua provided by RyzenAPI
-- Game: GAZZLERS

-- MAIN APPLICATION
addappid(1707620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707622,0,"536c99a5c169a2594023cd5ba07858821dc35219767f6ab2e36f6c8a875fe00c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2582120)
