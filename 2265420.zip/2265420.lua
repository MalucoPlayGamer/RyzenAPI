-- Lua provided by RyzenAPI
-- Game: Underquest

-- MAIN APPLICATION
addappid(2265420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265421, 1, "ac632424aa33c97c21c0383f1f3991bf3ce5ee698cf0e8edb5647d06774bee6c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
