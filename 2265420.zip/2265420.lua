-- Lua provided by SkyAPI 
-- Game: Underquest
addappid(2265420)
addappid(2265421, 1, "ac632424aa33c97c21c0383f1f3991bf3ce5ee698cf0e8edb5647d06774bee6c")
