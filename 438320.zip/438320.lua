-- Lua provided by RyzenAPI
-- Game: AppID 438320

-- MAIN APPLICATION
addappid(438320)
addappid(599910)
-- Game: addappid(438320)

-- MAIN APP DEPOTS / PACKAGES
addappid(438321, 1, "ff7cbd6cb10b1c4136e5d44e2881d093e0f34dffed06111db0aa6882495cafdf")
addappid(438322, 1, "88a25457f771ebb28364e0dbd6cd6a13d8a6c7d2ba7f6f64609698ab88d8b99e")
