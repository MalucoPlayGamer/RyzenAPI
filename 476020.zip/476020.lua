-- Lua provided by RyzenAPI
-- Game: Reflection of Mine

-- MAIN APPLICATION
addappid(476020)

-- MAIN APP DEPOTS / PACKAGES
addappid(476021, 1, "366e2dcb145ff194030abb5617c56cac0576d41347d7086a995aa7a1d6076e8f")
addappid(476022, 1, "126cb6d3950b8ff81af606d6568c11dca2bb5bb4fd8ed9a549312d01e7fd11ff")
addappid(476023, 1, "780e5acc2f824864a391b7db52026a7629fbdecdd927eb9d8b48186eed703eeb")
addappid(594060, 0, "acb4231da757a29c33632a8fa390b7e8ea9f5110168e16ed35d8d3cd1782c1d8")
