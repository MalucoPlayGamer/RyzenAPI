-- Lua provided by RyzenAPI
-- Game: 1457490

-- MAIN APPLICATION
addappid(1457490)
-- Game: addappid(1457490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457491, 1, "0e9f86069d28377fe6afa70eb25665cf929b5342f969d8863ed2fbdf84e05aa4")
