-- Lua provided by RyzenAPI
-- Game: addappid(3008850)

-- MAIN APPLICATION
addappid(3008850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3008851, 1, "a703992055deb3ddf8a4ac2e13493d95e9427bcfe9f015a9da5d2219342e0052")
