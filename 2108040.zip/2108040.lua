-- Lua provided by RyzenAPI
-- Game: AppID 2108040

-- MAIN APPLICATION
addappid(2108040)
-- Game: addappid(2108040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108041, 1, "a96b017f2a262a31200474fb06c7d4ad9b935e4b19d8caa0fecb0ccdb431e49c")
