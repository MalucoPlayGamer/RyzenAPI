-- 3981100's Lua and Manifest Created by Hubcap Manifest
-- Leaf it Alone
-- Created: January 17, 2026 at 22:30:10 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3981100) -- Leaf it Alone
-- MAIN APP DEPOTS
addappid(3981101, 1, "56be5b3548cef33e9c53118f311ded8914c2df5ca9430a0264a034dcf185e62e") -- Depot 3981101
setManifestid(3981101, "2188887785008983358", 978841760)