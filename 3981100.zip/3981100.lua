-- Lua provided by RyzenAPI
-- Game: Leaf it Alone

-- MAIN APPLICATION
addappid(3981100) -- Leaf it Alone

-- MAIN APP DEPOTS / PACKAGES
addappid(3981101, 1, "56be5b3548cef33e9c53118f311ded8914c2df5ca9430a0264a034dcf185e62e") -- Depot 3981101

