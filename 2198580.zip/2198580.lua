-- Lua provided by RyzenAPI
-- Game: 2198580

-- MAIN APPLICATION
addappid(2198580)
-- Game: addappid(2198580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198581, 1, "0a1b7caaeb98ff2e307b6a3af97268a244d107dedfebc8b5c87794cf82c8ce12")
addappid(2198582, 1, "1d01ec76a09bf616f90323020f7afa90a1811007e3115fd3bb2ff9a5f3303f37")
addappid(2198583, 1, "01e586f45b78faa863bf6b2a9f60df7dc60b976ef33b2e98e963e50e21ee7b6a")
