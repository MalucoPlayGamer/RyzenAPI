-- Lua provided by RyzenAPI
-- Game: Agatha Christie - Hercule Poirot: The London Case

-- MAIN APPLICATION
addappid(2223740)
addappid(2654920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223741, 1, "9db01eb64f072a7535c6aaa7d57902d1b414a2c4e92ab8e7013e81ce0f6e4f64")

