-- Lua provided by RyzenAPI
-- Game: 1708180

-- MAIN APPLICATION
addappid(1708180)
-- Game: addappid(1708180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708181, 1, "b33103d104689e0b6b477e49e03ff44b5f85ea018eb48c9c891d5afea2c456ec")
