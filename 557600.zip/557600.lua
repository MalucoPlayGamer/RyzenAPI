-- Lua provided by RyzenAPI
-- Game: 557600

-- MAIN APPLICATION
addappid(557600)
-- Game: addappid(557600)

-- MAIN APP DEPOTS / PACKAGES
addappid(557601, 1, "3dbed8d99e716a2c4481b39e1b841b09d8984a126afa6acb9f67ca8471289d62")
addappid(557602, 1, "8da70b135344ce4c582063dd71a2dfb857a4df67d9a086e94f7e09496d9d56b1")
