-- Lua provided by RyzenAPI
-- Game: Star Nomad

-- MAIN APPLICATION
addappid(338830)
-- Game: addappid(338830)

-- MAIN APP DEPOTS / PACKAGES
addappid(338831, 1, "0e58be7ee14504f89e0deeb1e1a0c7f554b663d8058cfb82fa5328e116499028")
addappid(338832, 1, "1b4fce42627b9a40f7252584fb5a1b3056bbf7bc6729b3ba9f9118e9d7d6e93b")
