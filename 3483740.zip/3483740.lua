-- Lua provided by RyzenAPI
-- Game: Cast n Chill

-- MAIN APPLICATION
addappid(3483740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3483741, 1, "0085e2ab6e91d273c72748b41db876429a43a28e359be3bd5519ddfa4d8ac501")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3817870)
addappid(4001650)
