-- Lua provided by RyzenAPI
-- Game: addappid(3626750)

-- MAIN APPLICATION
addappid(3626750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3626751, 1, "3c9577f2e17fb9a2965dd5e00d4b0287854972ae8617059ed0e3f3adc9c677a9")
