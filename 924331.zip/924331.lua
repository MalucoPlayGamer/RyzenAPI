-- Lua provided by RyzenAPI
-- Game: The Messenger Soundtrack - Disc II: The Future [16-Bit]

-- MAIN APPLICATION
addappid(924331)

-- MAIN APP DEPOTS / PACKAGES
addappid(924331,0,"2ba8889ce3173d5a01ca516e45aa76242237cd1e7a14fd734cf3e36162fc9ac3")
addappid(1228770,0,"860d2c11d4583764b95eb1c62121b840b9aa569b20bf83b10577c8e4456b6de3")

