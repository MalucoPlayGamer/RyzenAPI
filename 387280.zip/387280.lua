-- Lua provided by RyzenAPI
-- Game: Inferno 2

-- MAIN APPLICATION
addappid(387280)
-- Game: addappid(387280)

-- MAIN APP DEPOTS / PACKAGES
addappid(387281, 1, "34c3ac185ded565bedc30fdc86866e506c40d39a1b97f636806323388a67c5bc")
