-- Lua provided by RyzenAPI 
-- Game: 100 Forest Cats
addappid(2954560)
addappid(2954561, 1, "6d0c37ba50fdf961cad523bdd08885d331be02f0867240a50583606c5b7ab4ee")
addappid(2954610, 0, "0f3f2747054b37430568e43ee8e1c47b632ed579e0ad70ca6d726d9f08b9c937")
