-- Lua provided by RyzenAPI
-- Game: Dick Wilde

-- MAIN APPLICATION
addappid(585500)

-- MAIN APP DEPOTS / PACKAGES
addappid(585501, 1, "312fa7a6bf708e05a506aff940f3ad71f0a7ed2b1e53d3d9ca0da89215163680")
