-- Lua provided by RyzenAPI
-- Game: 2178410

-- MAIN APPLICATION
addappid(2178410)
-- Game: addappid(2178410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178411, 1, "ead229a9cfe63eeed41c31357082363e88827872c9033ff865eb56d9707215ac")
