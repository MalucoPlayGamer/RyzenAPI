-- Lua provided by RyzenAPI
-- Game: Journey of the Fox

-- MAIN APPLICATION
addappid(849880)

-- MAIN APP DEPOTS / PACKAGES
addappid(849881, 1, "37e327a02a553179aab1c0d8de7935d156d8aa015b279301411146b5e3252ae2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
