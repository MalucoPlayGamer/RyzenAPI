-- Lua provided by RyzenAPI
-- Game: Get Stuffed!

-- MAIN APPLICATION
addappid(1098130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098131, 1, "156afe3d1fa56751b600de2aca07e20b698a6a4ecfb6d377625519bb5b59cf07")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
