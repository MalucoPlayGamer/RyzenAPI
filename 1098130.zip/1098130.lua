-- Lua provided by RyzenAPI
-- Game: Game: Get Stuffed!

-- MAIN APPLICATION
addappid(1098130)
-- Game: addappid(1098130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098131, 1, "156afe3d1fa56751b600de2aca07e20b698a6a4ecfb6d377625519bb5b59cf07")
