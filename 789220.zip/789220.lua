-- Lua provided by RyzenAPI
-- Game: 789220

-- MAIN APPLICATION
addappid(789220)
-- Game: addappid(789220)

-- MAIN APP DEPOTS / PACKAGES
addappid(789221, 1, "1b64e40fa5b2f60be952ae58f32b8380d9a67592d003774766c23739c110dc04")
