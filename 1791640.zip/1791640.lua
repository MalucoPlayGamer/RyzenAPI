-- Lua provided by RyzenAPI
-- Game: Game: AppID 1791640

-- MAIN APPLICATION
addappid(1791640)
-- Game: addappid(1791640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791641, 1, "777aa4b0c0879b805b3210cfebb10836496bb08f7145b68ea81d1cf346277209")
