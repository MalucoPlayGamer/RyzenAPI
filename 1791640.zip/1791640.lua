-- Lua provided by SkyAPI 
-- Game: AppID 1791640
addappid(1791640)
addappid(1791641, 1, "777aa4b0c0879b805b3210cfebb10836496bb08f7145b68ea81d1cf346277209")
