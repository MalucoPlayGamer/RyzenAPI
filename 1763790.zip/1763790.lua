-- Lua provided by RyzenAPI
-- Game: Game: AppID 1763790

-- MAIN APPLICATION
addappid(1763790)
-- Game: addappid(1763790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763791, 1, "239525008aac236b4f683829a2d15d1c85f6fb34cca8f2aaeee8575fc913c9b5")
