-- Lua provided by RyzenAPI
-- Game: Heads Will Roll: Reforged - Artbook

-- MAIN APPLICATION
addappid(2517510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517510,0,"2b2911f11dd4f4323f3a9e0c533cee82088ea26a277f4f9a15baeabb0a9b7af0")
