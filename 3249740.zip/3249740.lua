-- Lua provided by RyzenAPI
-- Game: Game: AppID 3249740

-- MAIN APPLICATION
addappid(3249740)
-- Game: addappid(3249740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249741, 1, "1badfb76ae27dfa93fff15edfe6c2339c61b1ff3925b865219e2ba8950c3a716")
