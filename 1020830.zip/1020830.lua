-- Lua provided by RyzenAPI
-- Game: Game: Something is wrong/有毛病

-- MAIN APPLICATION
addappid(1020830)
-- Game: addappid(1020830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020831, 1, "20700619316e02f295cf693a34873dc696df0a7ca47e2a9a97ff30bab6313e29")
