-- Lua provided by RyzenAPI
-- Game: Game: Radium

-- MAIN APPLICATION
addappid(355410)
-- Game: addappid(355410)

-- MAIN APP DEPOTS / PACKAGES
addappid(355411, 1, "6e0669f21f2a145259c922d0f31d1b1c8022cc6fa13f3f533b8b18e09bf8699a")
addappid(355412, 1, "e65919867946377cbfeaa7fddd9bcc8e3251ff25e33e9c23a6be8b6ba6ed7f28")
addappid(355413, 1, "aace97090b3442f9022058cbf1f948e084217d00ecfcb48bb9f2f3a2cc66e017")
