-- Lua provided by RyzenAPI
-- Game: They Are Here Demo

-- MAIN APPLICATION
addappid(1604670)
-- Game: addappid(1604670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604671, 1, "84b6c7b879d80e9aebafbf5832071cb099db2336de56c6e3540b8c91ff8ca7c2")
