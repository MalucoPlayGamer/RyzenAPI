-- Lua provided by RyzenAPI
-- Game: Game: Interactive Horror Stories

-- MAIN APPLICATION
addappid(1169490)
-- Game: addappid(1169490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169491, 1, "252d1880f1b424876a597c82a94adaa2176b087188c23e71a4d3e1d4f2f0d0c4")
addappid(1169492, 1, "90d3c30cc2c147e2142d716581396a5d371229d27295c8ca5d2e7a8e5706c2d1")
addappid(1169493, 1, "dead8bf594713a90a130298f2d83dbb48039ab8b20eb08c9d02d131ece717429")
