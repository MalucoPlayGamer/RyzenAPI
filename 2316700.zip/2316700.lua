-- Lua provided by RyzenAPI
-- Game: 2316700

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2316700)
-- Game: addappid(2316700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316702,0,"8cf2d3eb20e8a19ff7a2ac7d7e3675972bf6a4e7d7bfb36d62fdee02cef0db30")
