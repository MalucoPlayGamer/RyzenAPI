-- Lua provided by RyzenAPI
-- Game: Paradise Lost

-- MAIN APPLICATION
addappid(982720)

-- MAIN APP DEPOTS / PACKAGES
addappid(982721,0,"57b35468d7e16326837f506f88b942b17a96c076feae650ad83dd2d1558b4e4b")
addappid(1648781,0,"b38b73dd77e3903fafbb8aee8016f243e2820e398c41800cdc66e63e0bdd91df")

