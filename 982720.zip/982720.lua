-- Lua provided by RyzenAPI
-- Game: Paradise Lost

-- MAIN APPLICATION
addappid(982720)
addappid(1648780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(982721,0,"57b35468d7e16326837f506f88b942b17a96c076feae650ad83dd2d1558b4e4b")
addappid(1648781,0,"b38b73dd77e3903fafbb8aee8016f243e2820e398c41800cdc66e63e0bdd91df")

