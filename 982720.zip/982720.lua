-- Lua provided by RyzenAPI
-- Game: 982720

-- MAIN APPLICATION
addappid(982720)
-- Game: addappid(982720)

-- MAIN APP DEPOTS / PACKAGES
addappid(982721, 1, "57b35468d7e16326837f506f88b942b17a96c076feae650ad83dd2d1558b4e4b")
