-- Lua provided by RyzenAPI
-- Game: Game: AppID 1091560

-- MAIN APPLICATION
addappid(1091560)
-- Game: addappid(1091560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091561, 1, "ddfa5054975fd12b016f105e98902521b22a51446563ecca3c54605d091b5a59")
