-- Lua provided by RyzenAPI
-- Game: Johny Explorer

-- MAIN APPLICATION
addappid(2252830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252831, 1, "c512e68207e7db2d335a275bb309ab1ec9dd978da785505cc4a51f6b51c67714")

