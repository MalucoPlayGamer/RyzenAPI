-- Lua provided by RyzenAPI
-- Game: Project Hospital

-- MAIN APPLICATION
addappid(1149760)
addappid(1282550)
addappid(1368210)
addappid(1423900)

-- MAIN APP DEPOTS / PACKAGES
addappid(868360, 1, "ef496df548ac2ac235ec9f63c171bd7fe0c6654780bf83aa26a14d829cefd73e")
addappid(868362, 1, "4f5081e288327046084fa377c67cd5aef2b6307d23a63f139938563ef44e5dab") -- (windows, 64-bit)
addappid(868363, 1, "d373db0fd7c1ee5ebf860648b90f34da40e3c9144b5c83a52abc4dc4cd51bcd5") -- (linux, 64-bit)
addappid(868364, 1, "f31e148df5675a1886aff8250ad2090f7713b0249f9ca221b9a696c3af9714a7") -- (macos, 64-bit)
addappid(1149760, 1, "5fb70dc38e24afb9ba35f48053c7e183732c87980a10715e6fdeba77bc3c7fc5")
addappid(1149761, 1, "c0ca13ce571f95368cfbb70b2f382380b7237eb3be164af332a4610e70d1ae1b") -- (windows)
addappid(1149762, 1, "26D8B148D0F548D8CBD3D95D3191C4CDE217536B306DBDD1C6D2CC70F9CE2957") -- (macos)
addappid(1149763, 1, "AEA81BF29A5F89B6076375E95AF7FE5CE0A4EB08BF110353686EFA34FCA92E09") -- (linux)
addappid(1282551, 1, "1194d8920c53c77a582f8eded1efddd58dff69f1feeef03abc3b70a40cb8f450") -- (windows, 64-bit)
addappid(1282552, 1, "7c8b8f513073691ae4ce239a42e79fc3b923c5f48908d8d31761c1396b51be96") -- (macos, 64-bit)
addappid(1282553, 1, "0e14341c052c873c0b6a29f72f90af6260806d52c3289664f71a25fea30190ba") -- (linux, 64-bit)
addappid(1368211, 1, "e8304490307d54a9c5092ff598919fa9363613103f751e246690ba90c0f2be88") -- (macos, 64-bit)
addappid(1368212, 1, "bbd712271ed4977df01f2509d461b7148f7a0f81da7e00ba3fec257db9b2187d") -- (linux, 64-bit)
addappid(1368213, 1, "f814e39cc322cccf287e3a140d5ca26c8047ac3c37ce5ff0660e9ff08cb22a38") -- (windows, 64-bit)
addappid(1423901, 1, "e769b7cf6049294e299b483c76c9526892d71e9ac191975d7d4abf680aa4bdc1") -- (windows, 64-bit)
addappid(1423902, 1, "8c80b060cfcfd64baa71e2ca772c88730a554cf024959c037176498ca49b7acc") -- (macos, 64-bit)
addappid(1423903, 1, "03273afc355f0e967cd1d9048f2e8a54ebfb8be1a0f1f68da036b575a2100852") -- (linux, 64-bit)

