-- Lua provided by RyzenAPI
-- Game: Project Hospital

-- MAIN APPLICATION
addappid(868360)
-- Game: addappid(868360)

-- MAIN APP DEPOTS / PACKAGES
addappid(868362,0,"4f5081e288327046084fa377c67cd5aef2b6307d23a63f139938563ef44e5dab")
addappid(868363,0,"d373db0fd7c1ee5ebf860648b90f34da40e3c9144b5c83a52abc4dc4cd51bcd5")
addappid(868364,0,"f31e148df5675a1886aff8250ad2090f7713b0249f9ca221b9a696c3af9714a7")
addappid(1149760,0,"5fb70dc38e24afb9ba35f48053c7e183732c87980a10715e6fdeba77bc3c7fc5")
