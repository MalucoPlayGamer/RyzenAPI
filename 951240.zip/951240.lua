-- Lua provided by SkyAPI 
-- Game: AppID 951240
addappid(951240)
addappid(951241, 1, "b0fe62283d60a499922b010c213d2cd3768d69cef6cfa191e837f214ffd9de4f")
