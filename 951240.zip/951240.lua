-- Lua provided by RyzenAPI
-- Game: 951240

-- MAIN APPLICATION
addappid(951240)
-- Game: addappid(951240)

-- MAIN APP DEPOTS / PACKAGES
addappid(951241, 1, "b0fe62283d60a499922b010c213d2cd3768d69cef6cfa191e837f214ffd9de4f")
