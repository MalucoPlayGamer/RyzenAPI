-- Lua provided by RyzenAPI
-- Game: addappid(466630)

-- MAIN APPLICATION
addappid(466630)

-- MAIN APP DEPOTS / PACKAGES
addappid(466632,0,"5c072d50259cf869b10afee552c3c654b1295ec8bca5b2794e08e8b4867e9e93")
