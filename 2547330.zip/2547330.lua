-- Lua provided by RyzenAPI
-- Game: Dr. Lunatic Supreme With Steam

-- MAIN APPLICATION
addappid(2547330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2547331, 1, "8c5936cf4d0b9e4b6b24e794120f507b009b0ad149d287f4fe9f6cbe8230740b")
addappid(2547332, 1, "2af775a6f294ae1ecbdda609678d2d66256708e0f3109ae67569e8b1fa1fb096")
addappid(2547333, 1, "9079d57be4ea5b94a2b138306cc44738e39d0e8322496fb394e0a9a10fd6f780")
