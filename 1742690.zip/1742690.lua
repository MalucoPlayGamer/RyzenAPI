-- Lua provided by RyzenAPI 
-- Game: Requiem
addappid(1742690)
addappid(1742691, 1, "926f44a3789238a1c82ebc519c724f499de2a4459b964137e078f80bbc50b706")
