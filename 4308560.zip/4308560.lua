-- 4308560's Lua and Manifest Created by Hubcap Manifest
-- Heritage
-- Created: August 11, 2026 at 23:24:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4308560) -- Heritage
-- MAIN APP DEPOTS
addappid(4308561, 1, "7dec3132f80b9f9513adc8b92505cc3b08c0cc6b08468f7dc08bf8377b5d9f39") -- Depot 4308561
setManifestid(4308561, "1644556005000269532", 340713179)