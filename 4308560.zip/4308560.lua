-- Lua provided by RyzenAPI
-- Game: Heritage

-- MAIN APPLICATION
addappid(4308560) -- Heritage

-- MAIN APP DEPOTS / PACKAGES
addappid(4308561, 1, "7dec3132f80b9f9513adc8b92505cc3b08c0cc6b08468f7dc08bf8377b5d9f39") -- Depot 4308561

