-- Lua provided by RyzenAPI
-- Game: Rule with an Iron Fish - A Pirate Fishing Adventure

-- MAIN APPLICATION
addappid(645750)
addappid(645751)

-- MAIN APP DEPOTS / PACKAGES
addappid(645752,0,"217b9d51336dc7fcded46ed70d858c98740d2cb71bb8ce5d2c55a66877f18d5c")
