-- Lua provided by RyzenAPI
-- Game: Hidden World 10 Top-Down 3D

-- MAIN APPLICATION
addappid(2703190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703191, 1, "e14334d82a73a180a2df4809696dd196f913f1094d07b536248ac7906bde0b70")
