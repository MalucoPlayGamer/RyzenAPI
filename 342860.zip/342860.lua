-- Lua provided by RyzenAPI
-- Game: Dark Quest

-- MAIN APPLICATION
addappid(342860)

-- MAIN APP DEPOTS / PACKAGES
addappid(342861, 1, "310d075c59b1abedd9f694d6213703b0ac03dfaa98dbf671da8c2f456fcbb871")

