-- Lua provided by RyzenAPI
-- Game: Battlestations Pacific

-- MAIN APPLICATION
addappid(8170)

-- MAIN APP DEPOTS / PACKAGES
addappid(8171, 1, "90faac52f6214e20472b3d850acd2b303662827b0c60c4a7d4ddae82941a9146")
