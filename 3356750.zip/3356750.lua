-- Lua provided by RyzenAPI
-- Game: addappid(3356750)

-- MAIN APPLICATION
addappid(3356750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356751, 1, "e4cc30bbece880e67bc75b171ff52170a72f7a1ec6702901d29f297db39b51c7")
