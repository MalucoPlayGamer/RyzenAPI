-- Lua provided by RyzenAPI
-- Game: Amnesia: The Dark Descent

-- MAIN APPLICATION
addappid(57300)

-- MAIN APP DEPOTS / PACKAGES
addappid(57301, 1, "287ec5e230f11e2f8a67433979f31da236fb1e7b579001e6003c1fb4366ecdc9")
addappid(57302, 1, "9aac14afdc112490cff7559885648ddab96c2ac65eb51b5c0f0858117ff576dd")
addappid(57303, 1, "ce1096b118e5aff8343dd9857272297089fd05e0bd45256fe20a99e23752e575")
addappid(57304, 1, "23b492b4a4acf4b87453c4791ab22324d8bdba0a9a5a21f67dab42d2056639e8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(98002)
