-- Lua provided by RyzenAPI
-- Game: London Ripper

-- MAIN APPLICATION
addappid(1918550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918551, 1, "d5c0919e35afb5351545ec3f4c782cab5eb535968cbaccf5281305c058cd8342")
