-- Lua provided by RyzenAPI
-- Game: Garten of Banban 7

-- MAIN APPLICATION
addappid(2693060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2693061, 1, "da1139079f0e4ea6d14ac29edba3e6860898e0a523c799af51248a060db5bcc8")
