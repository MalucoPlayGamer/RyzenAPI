-- Lua provided by RyzenAPI
-- Game: 2693060

-- MAIN APPLICATION
addappid(2693060)
-- Game: addappid(2693060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693061, 1, "da1139079f0e4ea6d14ac29edba3e6860898e0a523c799af51248a060db5bcc8")
