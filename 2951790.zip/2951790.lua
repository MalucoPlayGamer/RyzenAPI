-- Lua provided by RyzenAPI
-- Game: addappid(2951790)

-- MAIN APPLICATION
addappid(2951790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951791, 1, "946ef2412bb4168e216c39ff8eaa9e84b5e3e2785788d96985e1223f9ac89f03")
