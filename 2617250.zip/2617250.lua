-- Lua provided by RyzenAPI
-- Game: 2617250

-- MAIN APPLICATION
addappid(2617250)
-- Game: addappid(2617250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617251, 1, "5e4aec1bcab514852b53c62029bda397f61a8a5b214cc5237c4ec353d87fcd1b")
