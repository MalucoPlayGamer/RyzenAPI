-- Lua provided by RyzenAPI
-- Game: 1475260

-- MAIN APPLICATION
addappid(1475260)
-- Game: addappid(1475260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475261, 1, "e9422e9f0faaeae3a66c42aa91c8ea515f84141a773e1141f05af16f618dd5e1")
