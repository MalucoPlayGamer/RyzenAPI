-- Lua provided by RyzenAPI
-- Game: Game: AppID 429300

-- MAIN APPLICATION
addappid(429300)
-- Game: addappid(429300)

-- MAIN APP DEPOTS / PACKAGES
addappid(429301, 1, "582a1c071a53430f55ad397789096f93857b0329322e613f025b3f7e49cddeaa")
