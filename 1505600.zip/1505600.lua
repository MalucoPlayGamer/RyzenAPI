-- Lua provided by RyzenAPI
-- Game: 1505600

-- MAIN APPLICATION
addappid(1505600)
-- Game: addappid(1505600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505601, 1, "be8697cc24c7ab120a391e496da77e6f370b433d0a4b6863832938a19bf23dee")
