-- Lua provided by RyzenAPI
-- Game: Unable to Exit 8

-- MAIN APPLICATION
addappid(2878720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878721, 1, "5757a13d5bfbce858447481dc7a46d3e95b3e1c9161eee2b0d01ab34adb52990")

