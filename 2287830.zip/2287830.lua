-- Lua provided by RyzenAPI
-- Game: addappid(2287830)

-- MAIN APPLICATION
addappid(2287830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287831, 1, "a2004391866eb5aa9b3be72c6155450f4df5b865d1f46c3c8acc60bf70b15e1f")
