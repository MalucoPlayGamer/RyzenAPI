-- Lua provided by RyzenAPI
-- Game: Hunter's Trial

-- MAIN APPLICATION
addappid(945850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(945851, 1, "81c5ec18b54b7c42789596ba2bb16788fa4c3b25207016d10a50b429ef432ea5")
