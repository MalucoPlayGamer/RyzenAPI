-- Lua provided by RyzenAPI
-- Game: Game: AppID 945850

-- MAIN APPLICATION
addappid(945850)
-- Game: addappid(945850)

-- MAIN APP DEPOTS / PACKAGES
addappid(945851, 1, "81c5ec18b54b7c42789596ba2bb16788fa4c3b25207016d10a50b429ef432ea5")
