-- Lua provided by RyzenAPI
-- Game: addappid(788210)

-- MAIN APPLICATION
addappid(788210)

-- MAIN APP DEPOTS / PACKAGES
addappid(788211, 1, "b03a752f76ae59d1048beb50a483142cd1e52724f57f7fad1aed9807b07a92a9")
