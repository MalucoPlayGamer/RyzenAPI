-- Lua provided by RyzenAPI
-- Game: addappid(1973100)

-- MAIN APPLICATION
addappid(1973100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973101, 1, "a713b489bab3c8d8a02dc9314482006e09d35702bc86e8f37ba72a580f52b36a")
