-- Lua provided by RyzenAPI
-- Game: Judero Demo

-- MAIN APPLICATION
addappid(2182430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182431, 1, "aa908afa7c005a1926107515452046f77fb3c405a5292b6fef000b0bf457e552")

