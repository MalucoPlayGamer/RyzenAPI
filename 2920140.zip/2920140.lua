-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2920140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920142,0,"99a96d4997575107789dcafd5fc1595ae6afa35cf5bc7bd04b0d903750968abc")
addappid(2920143,0,"431299d544bc7affc29ea2974653ddab35c3510f430884aa9c62ab69b897d60a")
addappid(2920144,0,"2d7a32235bf3007b5f95dd5d3b1743dd428756e959c9b40c0b67a69dfaa97277")

