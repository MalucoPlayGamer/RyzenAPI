-- Lua provided by RyzenAPI
-- Game: The First Thrust of God

-- MAIN APPLICATION
addappid(773650)
addappid(773690)

-- MAIN APP DEPOTS / PACKAGES
addappid(773651, 1, "d8fbff0fea3d968b93191ce241671cb47f406803ec60a1f15195ddd779db01ee")
addappid(773652, 1, "71db341077a84a081793493a283a8f8ecaf01fc7b914503a43423720d9d9924c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4499670)
