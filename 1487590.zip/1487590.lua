-- Lua provided by RyzenAPI
-- Game: addappid(1487590)

-- MAIN APPLICATION
addappid(1487590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487592,0,"2eb03bfd171dfcca2b5f2c184d83f9dd32f579fca79d2d7e082fd0a627daa60b")
