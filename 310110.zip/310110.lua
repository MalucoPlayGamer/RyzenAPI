-- Lua provided by RyzenAPI
-- Game: NS2: Combat

-- MAIN APPLICATION
addappid(310110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(310112,0,"6457e4e79aa1f5cf70a17fa65750bca6278af18dff1343ba9673b036468a3340")
addappid(310113,0,"2dbe578865c1645d15ba2931334ebecb64bb68342d91cbdfba6f56facf0ba6f2")
addappid(313902,0,"e15c527b97933a7c4322af1765e1ab3820d4309fdf942cc57f8b52ce8e64eb20")

