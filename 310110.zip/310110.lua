-- Lua provided by RyzenAPI
-- Game: NS2: Combat

-- MAIN APPLICATION
addappid(310110)
-- Game: addappid(310110)

-- MAIN APP DEPOTS / PACKAGES
addappid(310112,0,"6457e4e79aa1f5cf70a17fa65750bca6278af18dff1343ba9673b036468a3340")
addappid(310113,0,"2dbe578865c1645d15ba2931334ebecb64bb68342d91cbdfba6f56facf0ba6f2")
addappid(313902,0,"e15c527b97933a7c4322af1765e1ab3820d4309fdf942cc57f8b52ce8e64eb20")
