-- Lua provided by SkyAPI 
-- Game: AppID 1346870
addappid(1346870)
addappid(1346871, 1, "a6515f436a6e00a6abe330230164efb9f8071de8b81aec1d510f59f7ada4f89c")
