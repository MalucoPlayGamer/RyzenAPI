-- Lua provided by RyzenAPI
-- Game: Naughty Memories

-- MAIN APPLICATION
addappid(1346870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1346871, 1, "a6515f436a6e00a6abe330230164efb9f8071de8b81aec1d510f59f7ada4f89c")
