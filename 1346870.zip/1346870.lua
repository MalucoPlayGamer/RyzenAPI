-- Lua provided by RyzenAPI
-- Game: Game: AppID 1346870

-- MAIN APPLICATION
addappid(1346870)
-- Game: addappid(1346870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346871, 1, "a6515f436a6e00a6abe330230164efb9f8071de8b81aec1d510f59f7ada4f89c")
