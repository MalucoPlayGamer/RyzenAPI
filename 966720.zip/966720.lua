-- Lua provided by SkyAPI 
-- Game: AppID 966720
addappid(966720)
addappid(966721, 1, "1f2e36cc28e8b92e6d844113b6e727de6bbafe82712e205797322324f2293fb1")
