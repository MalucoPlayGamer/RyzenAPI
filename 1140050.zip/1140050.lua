-- Lua provided by RyzenAPI
-- Game: 三国志·天下归心

-- MAIN APPLICATION
addappid(1140050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140052,0,"ea3b2398e9a9e28f770490ea2f3aaced8a8ad2da262ac79c42fa60b74d2fb658")

