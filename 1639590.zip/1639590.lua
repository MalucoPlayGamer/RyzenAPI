-- Lua provided by RyzenAPI
-- Game: Cold House

-- MAIN APPLICATION
addappid(1639590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639591, 1, "0d776fa79e1f6c06bbe5a7f402fee1dd15a5b6bb21aaa16f7760ee314baddde0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
