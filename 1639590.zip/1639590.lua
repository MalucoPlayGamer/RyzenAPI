-- Lua provided by RyzenAPI 
-- Game: Cold House
addappid(1639590)
addappid(1639591, 1, "0d776fa79e1f6c06bbe5a7f402fee1dd15a5b6bb21aaa16f7760ee314baddde0")
