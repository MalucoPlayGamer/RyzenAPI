-- Lua provided by RyzenAPI
-- Game: Building The Universe

-- MAIN APPLICATION
addappid(1237700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237701, 1, "fdf504da4a7fd951d207afedf58b5a10868c28e03063b841747713c011f4ef3d")

