-- Lua provided by RyzenAPI
-- Game: STAR WARS™ X-Wing vs TIE Fighter - Balance of Power Campaigns™

-- MAIN APPLICATION
addappid(361690)

-- MAIN APP DEPOTS / PACKAGES
addappid(361691, 1, "3b2cf29dcdb3418b85c383877d933c8946d6617a53323725e9bbf5fe16b840e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
