-- Lua provided by RyzenAPI
-- Game: addappid(361690)

-- MAIN APPLICATION
addappid(361690)

-- MAIN APP DEPOTS / PACKAGES
addappid(361691, 1, "3b2cf29dcdb3418b85c383877d933c8946d6617a53323725e9bbf5fe16b840e3")
