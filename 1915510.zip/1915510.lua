-- Lua provided by RyzenAPI
-- Game: Yao-Guai Hunter

-- MAIN APPLICATION
addappid(1915510)
-- Game: addappid(1915510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915511, 1, "1b7531ca6c07167e114602fbe07e1b3ad6ec33c04d54e26567b73bef30fb5376")
