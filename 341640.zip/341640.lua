-- Lua provided by RyzenAPI
-- Game: Relativity Wars - A Science Space RTS

-- MAIN APPLICATION
addappid(341640)

-- MAIN APP DEPOTS / PACKAGES
addappid(341641, 1, "ad84c09541b4c24d387695073fd3639119345b6ec173cc4dca1bd7efb853ee47")
addappid(341642, 1, "5c401d150d45262e3c9489a37a40d03759f9ef83f573c042194d1a2b4acaec91")
addappid(341643, 1, "d06c351d1b810a3fab88c78522b3259bd34f9d00f4c761f12b5100d1586fa805")
