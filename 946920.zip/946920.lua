-- Lua provided by RyzenAPI
-- Game: Paranoid

-- MAIN APPLICATION
addappid(946920)
addappid(2732560)
addappid(2732570)

-- MAIN APP DEPOTS / PACKAGES
addappid(946921,0,"220d4617d4f0ba306a3e11ab0530a73eb40f9c53b1689e9d03cf475f94f318c8")
addappid(2732560,0,"30d024dc31b1f32a4f4710b1bdcce3e78365917a08b3e344490a1d581a23f45a")

