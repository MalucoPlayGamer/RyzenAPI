-- Lua provided by RyzenAPI
-- Game: Paranoid

-- MAIN APPLICATION
addappid(946920)
addappid(2732560)
addappid(2732570)

-- MAIN APP DEPOTS / PACKAGES
addappid(946921,0,"220d4617d4f0ba306a3e11ab0530a73eb40f9c53b1689e9d03cf475f94f318c8")
addappid(2732560,0,"30d024dc31b1f32a4f4710b1bdcce3e78365917a08b3e344490a1d581a23f45a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
