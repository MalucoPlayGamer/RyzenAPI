-- Lua provided by RyzenAPI
-- Game: PARANOID

-- MAIN APPLICATION
addappid(946920)
-- Game: addappid(946920)

-- MAIN APP DEPOTS / PACKAGES
addappid(946921, 1, "220d4617d4f0ba306a3e11ab0530a73eb40f9c53b1689e9d03cf475f94f318c8")
