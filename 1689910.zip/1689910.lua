-- Lua provided by RyzenAPI
-- Game: Dōkyūsei: Bangin' Summer

-- MAIN APPLICATION
addappid(1689910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689911, 1, "7b38eb0c1727643b4c72b7c46708f61b1843815dc793edf7f2f85415706187b1")
addappid(1689912, 1, "9f5c993e99c824323b1ee62b13ba56f6940c1cd4cb9d177bf1c2fb34e5f743a6")
addappid(1689913, 1, "bdfe951e0b74d11725543324176842639a548201d11f72c7a71eebf625c3e308")
addappid(1689914, 1, "7606b6eccc3dbd168bdee6f5912ef5d7bf20bda5309801a07f0df14e890ddcc3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
