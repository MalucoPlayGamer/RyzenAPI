-- Lua provided by RyzenAPI
-- Game: ACE Academy

-- MAIN APPLICATION
addappid(396650)

-- MAIN APP DEPOTS / PACKAGES
addappid(396651, 1, "7b5a91ef0a712108f6a412bede5b65c2b56e3b8eea90809f0be4737ae92c8641")

