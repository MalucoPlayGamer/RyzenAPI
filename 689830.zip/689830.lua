-- Lua provided by RyzenAPI
-- Game: Game: DUELEUM

-- MAIN APPLICATION
addappid(689830)
-- Game: addappid(689830)

-- MAIN APP DEPOTS / PACKAGES
addappid(689831, 1, "b0d7b8fd7924885ec02266da3bd55356d1ec64a3584e945ab4b3684bea7bd8ab")
