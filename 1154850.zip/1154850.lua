-- Lua provided by RyzenAPI
-- Game: AppID 1154850

-- MAIN APPLICATION
addappid(1154850)
-- Game: addappid(1154850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154851, 1, "a72dc653db884ff120cf45b892eeb8c388eb1829f8f1c132f0095860f6e9e8b0")
