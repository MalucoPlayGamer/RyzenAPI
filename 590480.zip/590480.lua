-- Lua provided by RyzenAPI
-- Game: 590480

-- MAIN APPLICATION
addappid(590480)
-- Game: addappid(590480)

-- MAIN APP DEPOTS / PACKAGES
addappid(590481, 1, "f0c52caaf87bea639b07f2eaecca6c189b3c7cfc0a51e976272aeebeed387516")
