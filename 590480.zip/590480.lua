-- Lua provided by RyzenAPI
-- Game: Slash It 2 - Elexive Exclusive Edition

-- MAIN APPLICATION
addappid(590480)

-- MAIN APP DEPOTS / PACKAGES
addappid(590481, 1, "f0c52caaf87bea639b07f2eaecca6c189b3c7cfc0a51e976272aeebeed387516")
