-- Lua provided by RyzenAPI
-- Game: AppID 3130530

-- MAIN APPLICATION
addappid(3130530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130531, 1, "68fb2e4c312f58ebfc681cef51cc4d1f8c48aa8d060f922fba8b71b0ca873739")
