-- Lua provided by RyzenAPI
-- Game: 1810610

-- MAIN APPLICATION
addappid(1810610)
-- Game: addappid(1810610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810611, 1, "75d54914f56bc91463e27b4e28cbd7fd23694dc65b8d69322d7eda16ace0772f")
