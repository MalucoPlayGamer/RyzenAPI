-- Lua provided by RyzenAPI
-- Game: The Hunter's Journals - Pale Harbour

-- MAIN APPLICATION
addappid(1094170)
-- Game: addappid(1094170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094171, 1, "8f5602e3f4715b9459a08d04be5c156914e964f231a97cd33a7094373d14f14f")
