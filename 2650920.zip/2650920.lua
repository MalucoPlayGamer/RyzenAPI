-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Rolling Stones - "Gimme Shelter"

-- MAIN APPLICATION
addappid(2650920)
-- Game: addappid(2650920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650920,0,"c747c61fb2d76fc551dd01a32f286fb7b2b8747946a2b9bf6c9ef5200699ee5b")
