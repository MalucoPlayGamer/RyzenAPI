-- Lua provided by RyzenAPI
-- Game: Game: IRREVERSIBLE

-- MAIN APPLICATION
addappid(2820160)
-- Game: addappid(2820160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820161, 1, "b8336182ffeb1f746bd81cbf2cf85b0331b1c92c91e6d0e0ddea908af4c99008")
