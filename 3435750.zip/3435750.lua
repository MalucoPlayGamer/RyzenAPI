-- Lua provided by RyzenAPI
-- Game: 3435750

-- MAIN APPLICATION
addappid(3435750)
-- Game: addappid(3435750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3435751, 1, "d59dc6f2a1144e5e56f27f1b73cc3bb698340e5f0355b57f68ff2fb164e3bff7")
