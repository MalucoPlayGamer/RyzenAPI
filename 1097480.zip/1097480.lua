-- Lua provided by SkyAPI 
-- Game: AppID 1097480
addappid(1097480)
addappid(1097481, 1, "4798c22d2ea0c2515983d4df59a1f2218590d0ae3c41c413936c1b29627f2708")
