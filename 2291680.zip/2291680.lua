-- Lua provided by RyzenAPI
-- Game: 2291680

-- MAIN APPLICATION
addappid(2291680)
-- Game: addappid(2291680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291681, 1, "d5f249db247fe7b9d64a53304732e9775a8ffc470308d03c4e96fc84f8775f71")
