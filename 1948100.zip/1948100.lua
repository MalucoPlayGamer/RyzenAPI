-- Lua provided by RyzenAPI 
-- Game: Lustful Ponies
addappid(1948100)
addappid(1948101, 1, "1a293d8b3d0a3cef493377174c5fb9e957e208db219ab3c20845cc47e18570e8")
