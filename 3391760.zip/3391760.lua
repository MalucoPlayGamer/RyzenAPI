-- Lua provided by RyzenAPI
-- Game: Kill Ze Bugs Demo

-- MAIN APPLICATION
addappid(3391760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391761, 1, "065d9b0a8b7bce314baa065cd0ec5f8e1c77b48289826870befcc1344cef7483")
