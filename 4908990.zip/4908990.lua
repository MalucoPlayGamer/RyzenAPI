-- Lua provided by RyzenAPI
-- Game: Boring Car Stories - Maghrebine

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4908990, 1, "37e873fbee8c485d94634c96f599c3a69b8f815d621fb544ad01afd486e6cd20") -- Boring Car Stories - Maghrebine
addappid(4908991, 1, "f7b6822f4a26e4214618b30ce437b4c21ff60932d0158bc2adc114dddd321d59") -- Depot 4908991

