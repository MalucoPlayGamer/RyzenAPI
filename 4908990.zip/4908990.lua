-- 4908990's Lua and Manifest Created by Hubcap Manifest
-- Boring Car Stories - Maghrebine
-- Created: August 21, 2026 at 22:34:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4908990, 1, "37e873fbee8c485d94634c96f599c3a69b8f815d621fb544ad01afd486e6cd20") -- Boring Car Stories - Maghrebine
-- MAIN APP DEPOTS
addappid(4908991, 1, "f7b6822f4a26e4214618b30ce437b4c21ff60932d0158bc2adc114dddd321d59") -- Depot 4908991
setManifestid(4908991, "4723991332132730233", 958064611)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)