-- Lua provided by RyzenAPI
-- Game: Super Jet Juck

-- MAIN APPLICATION
addappid(774121)

-- MAIN APP DEPOTS / PACKAGES
addappid(774122,0,"5e61e68ec79c3000ceb6956ab9e96e327c2050aaa8ab934f5fee7a642a503ad3")

