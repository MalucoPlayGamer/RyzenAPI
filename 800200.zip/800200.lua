-- Lua provided by RyzenAPI
-- Game: Game: AppID 800200

-- MAIN APPLICATION
addappid(800200)
-- Game: addappid(800200)

-- MAIN APP DEPOTS / PACKAGES
addappid(800201, 1, "227d629af6da8e1dbd4c8064fc27794603845b89297f77b401e58cdb3767f431")
