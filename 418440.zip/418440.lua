-- Lua provided by RyzenAPI
-- Game: AppID 418440

-- MAIN APPLICATION
addappid(418440)
addappid(427750)

-- MAIN APP DEPOTS / PACKAGES
addappid(418441, 1, "9522ff1731c44ddcc38b8164404faf761953af41be51fafaa076b0824ea1ac0c")
