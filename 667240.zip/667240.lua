-- Lua provided by RyzenAPI
-- Game: addappid(667240)

-- MAIN APPLICATION
addappid(667240)

-- MAIN APP DEPOTS / PACKAGES
addappid(667241, 1, "dbc4da55ed2d55c341c917995a817103d11ac5f2775ce9af380540eaa508d9d5")
