-- Lua provided by RyzenAPI
-- Game: Vintage Hero

-- MAIN APPLICATION
addappid(667240)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(667241, 1, "dbc4da55ed2d55c341c917995a817103d11ac5f2775ce9af380540eaa508d9d5")
