-- Lua provided by RyzenAPI
-- Game: Gears of Dragoon: Fragments of a New Era

-- MAIN APPLICATION
addappid(1999870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999871, 1, "39e0feb9058fee16b2b8029a5ea5285d79f829712d1af0db90d57840a001e05e")
addappid(1999872, 1, "375f23172e8b2a51b8d611d8d6c52ee2a678b6755213159035d9fdec32b697c4")

