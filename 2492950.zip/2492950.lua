-- Lua provided by RyzenAPI
-- Game: To The Sky

-- MAIN APPLICATION
addappid(2492950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2492951, 1, "c9d72d1c4a1bf5a3e1cbbc5c2c84e244da412cb94f3a84b167ed6b292b3169ba")

