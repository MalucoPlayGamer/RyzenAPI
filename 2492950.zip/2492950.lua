-- Lua provided by RyzenAPI
-- Game: 2492950

-- MAIN APPLICATION
addappid(2492950)
-- Game: addappid(2492950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492951, 1, "c9d72d1c4a1bf5a3e1cbbc5c2c84e244da412cb94f3a84b167ed6b292b3169ba")
