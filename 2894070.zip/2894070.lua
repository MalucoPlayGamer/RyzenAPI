-- Lua provided by RyzenAPI
-- Game: Game: Hentai Girls : Mommy Milkers

-- MAIN APPLICATION
addappid(2894070)
-- Game: addappid(2894070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2894071, 1, "9369758c8e2f22753efa205e245a6642aba87ca4cc1b03f81a5ee4b28421e50d")
