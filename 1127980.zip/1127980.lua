-- Lua provided by RyzenAPI 
-- Game: NASCAR Heat 4
addappid(1127980)
addappid(1127981, 1, "cee356efc4df76244c21c59fd56bce02ad7188ad2ecbcc765f7318d0219716ff")
addappid(1154310)
addappid(1154311, 0, "ad163d7b171ea541f1e9a7d5c2b4525ab527102b0c56a85c98f94a051695f0e4")
addappid(1168810)
addappid(1172330)
addappid(1205400)
