-- Lua provided by RyzenAPI
-- Game: Draft Day Sports: Pro Basketball 2022

-- MAIN APPLICATION
addappid(1819870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819871, 1, "f709b45a963adf6fe89df0bf5919852f6c48f67529e1a7e4c0c107a0c6c6f27e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
