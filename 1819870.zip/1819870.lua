-- Lua provided by RyzenAPI
-- Game: Game: Draft Day Sports: Pro Basketball 2022

-- MAIN APPLICATION
addappid(1819870)
-- Game: addappid(1819870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819871, 1, "f709b45a963adf6fe89df0bf5919852f6c48f67529e1a7e4c0c107a0c6c6f27e")
