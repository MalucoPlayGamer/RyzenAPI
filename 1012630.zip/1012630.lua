-- Lua provided by RyzenAPI
-- Game: Epido

-- MAIN APPLICATION
addappid(1012630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012631, 1, "2787f81d1dafc2ce547355d9d53e14a02a7ef4218c5bc45e220d3c25c4849e8c")
addappid(1012632, 1, "2c65dd1b3a46417ca665ce9a059e904b603cdcbee79efeccc8d410575e4d1ede")
addappid(1083670, 0, "c89d60c34ac451e0c7554cd328ea95b58aa72dda3e562cc280694f4e91b95ef0")

