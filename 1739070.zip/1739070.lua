-- Lua provided by RyzenAPI
-- Game: Bone's Cafe

-- MAIN APPLICATION
addappid(1739070)
-- Game: addappid(1739070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739071, 1, "e9bc037e6afef9e30973c77dab241a70af052f9086b012186400b128cacdf7c4")
