-- Lua provided by RyzenAPI
-- Game: Light Maze

-- MAIN APPLICATION
addappid(2023910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023911, 1, "96fa307698b51914c7ce5b0cfa90bc470a956cf34d440f4a8696f2e45e4b8cb2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
