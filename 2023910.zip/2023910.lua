-- Lua provided by RyzenAPI 
-- Game: Light Maze
addappid(2023910)
addappid(2023911, 1, "96fa307698b51914c7ce5b0cfa90bc470a956cf34d440f4a8696f2e45e4b8cb2")
