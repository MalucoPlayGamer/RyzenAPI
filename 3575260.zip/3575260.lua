-- Lua provided by RyzenAPI
-- Game: 3575260

-- MAIN APPLICATION
addappid(3575260)
-- Game: addappid(3575260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575261, 1, "9cece0177fce116e8f0fc93184d035beb0122bf4fa4d9354e3fabc69bcba5b08")
