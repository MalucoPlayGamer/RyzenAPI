-- Lua provided by RyzenAPI
-- Game: 618720

-- MAIN APPLICATION
addappid(618720)
-- Game: addappid(618720)

-- MAIN APP DEPOTS / PACKAGES
addappid(618721, 1, "fe0d237952fa51a3617b676e43b6c3f39c20bab4347d80fbc4e2e619227fdd8a")
addappid(618722, 1, "6ee9caad93c6f5f8f808af30ec6b68decc0b712468472c78f14bb0eb64d749db")
addappid(618723, 1, "75597af786a2d2d6e71afb05fa56e218bc1b3e512af91d94bb8f922b67bceb30")
