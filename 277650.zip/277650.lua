-- Lua provided by RyzenAPI
-- Game: AppID 277650

-- MAIN APPLICATION
addappid(277650)
-- Game: addappid(277650)

-- MAIN APP DEPOTS / PACKAGES
addappid(277651, 1, "033cd8ca24f8d00636d1abd05e52e0f0ab734627b47b2b8902549c6efc4b4d29")
