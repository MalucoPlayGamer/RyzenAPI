-- Lua provided by RyzenAPI
-- Game: Game: Grow a Carrot

-- MAIN APPLICATION
addappid(2794860)
-- Game: addappid(2794860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794861, 1, "91479f0a0bffe6b639ba704c98fcffce35bcea332522d88455e780284342be92")
addappid(3238280, 0, "c2b673759e0469a666ad87949f246c4435f5044ca5aa6461f932d91c25a89b37")
