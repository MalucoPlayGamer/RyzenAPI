-- Lua provided by RyzenAPI
-- Game: Sperm Runner

-- MAIN APPLICATION
addappid(1816560)
-- Game: addappid(1816560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816561, 1, "5ff2e3935421c66223dda62fef13a0b4b0e929afea04c041af9e7e0a02294d2a")
