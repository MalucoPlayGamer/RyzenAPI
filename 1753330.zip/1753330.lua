-- Lua provided by RyzenAPI
-- Game: 战棋三国-英雄(Three Kingdoms : Hero) Playtest

-- MAIN APPLICATION
addappid(1753330)
-- Game: addappid(1753330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753331, 1, "897119b985be1fdbe34616549d98eed505937b73ef5e257eae6884dd9cb72f6b")
