-- Lua provided by RyzenAPI
-- Game: GeckoShop

-- MAIN APPLICATION
addappid(3392420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3392421, 1, "532c60a8d162c91f6d4f8df8fb3332ed631467c57ec5db3bfd3717d804820c1f")

