-- Lua provided by RyzenAPI
-- Game: Dungeon Defenders: Awakened Demo

-- MAIN APPLICATION
addappid(2152920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152921, 1, "46aab4a8f0cc79238c20da978e10a654583c4124150e69385d5239d52268b3cd")

