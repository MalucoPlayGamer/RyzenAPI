-- Lua provided by RyzenAPI
-- Game: addappid(1912050)

-- MAIN APPLICATION
addappid(1912050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912050,0,"e8e6d20878cebb60761e312fbaef57fd4365cae1d4c3fefe00fd7094f2b00aed")
