-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1912050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912050,0,"e8e6d20878cebb60761e312fbaef57fd4365cae1d4c3fefe00fd7094f2b00aed")

