-- Lua provided by RyzenAPI
-- Game: Game: Pixel Golf Club

-- MAIN APPLICATION
addappid(3032590)
-- Game: addappid(3032590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032591, 1, "18afdb50e41cd5ece725d491c7ccb8c8daedda444574120d60a89fa001564871")
