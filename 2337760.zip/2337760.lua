-- Lua provided by RyzenAPI
-- Game: Sky division

-- MAIN APPLICATION
addappid(2337760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337761, 1, "c3dd77b004219616f941df8b982aac09493eb6717cbf6ae28ace563f517ce24d")
