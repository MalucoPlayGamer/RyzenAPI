-- Lua provided by RyzenAPI
-- Game: Panzer Knights Mod Editor

-- MAIN APPLICATION
addappid(1672540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672541, 1, "3d0466455b6e664000337888f24f1a3ce14bb1d9e0349135ec85af591082bcee")
