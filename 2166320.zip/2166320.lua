-- Lua provided by RyzenAPI
-- Game: 2166320

-- MAIN APPLICATION
addappid(2166320)
-- Game: addappid(2166320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166321, 1, "a411dbb7693259256714236ebcdd3e2ee931c492362a83531cbeb4537b00c7a5")
