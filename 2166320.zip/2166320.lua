-- Lua provided by SkyAPI 
-- Game: VRROOM
addappid(2166320)
addappid(2166321, 1, "a411dbb7693259256714236ebcdd3e2ee931c492362a83531cbeb4537b00c7a5")
