-- Lua provided by RyzenAPI
-- Game: GLASS - Art Book

-- MAIN APPLICATION
addappid(1488280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488282,0,"c2d8dd2a05f29074ca8ab39f01c5a8f7e92fe03450989f923510d9803a88f24b")
addappid(1488283,0,"51bafec34266f4ccb83eb91ed08a05bbb93bc921ad423f2ff425290392de65a7")

