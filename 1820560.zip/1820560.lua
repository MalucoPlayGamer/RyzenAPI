-- Lua provided by RyzenAPI
-- Game: 1820560

-- MAIN APPLICATION
addappid(1820560)
-- Game: addappid(1820560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820561, 1, "4542f6cac8da585e061d93a605c57fc1d3707e6fed2632a6b39f83e0690c42df")
