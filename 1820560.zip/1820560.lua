-- Lua provided by RyzenAPI
-- Game: Big Booty Adventures

-- MAIN APPLICATION
addappid(1820560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820561, 1, "4542f6cac8da585e061d93a605c57fc1d3707e6fed2632a6b39f83e0690c42df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
