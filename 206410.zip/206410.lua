-- Lua provided by RyzenAPI
-- Game: Crazy Machines Elements

-- MAIN APPLICATION
addappid(206410)

-- MAIN APP DEPOTS / PACKAGES
addappid(206411, 1, "9879dabf9a6319824b70c3836fd6792b2e11fa7a4789b3b95a6747429ecd6027")
addappid(206415, 1, "e7f5a53c5a551ace6459ac9f6e14ded9833e968b50bc20316104ced3a3887200")
addappid(206416, 1, "2e655c3e9aac1df62c4e208f115cf606a6f9a15cd99063bb23dc8cd990ebd9e3")
