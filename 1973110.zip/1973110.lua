-- Lua provided by RyzenAPI
-- Game: 1973110

-- MAIN APPLICATION
addappid(1973110)
-- Game: addappid(1973110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973111, 1, "a443edb7d8d11ace5363d29faa7958603a3469fde644adf518097f4a8f43b481")
