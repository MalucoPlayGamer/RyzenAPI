-- Lua provided by RyzenAPI
-- Game: 1692240

-- MAIN APPLICATION
addappid(1692240)
-- Game: addappid(1692240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692241, 1, "15cb8dbf675643095e670d155c0d1122ec8def48372a921c33ffb6a0a4ab06b0")
