-- Lua provided by RyzenAPI
-- Game: Rock the Islands

-- MAIN APPLICATION
addappid(2987860)
