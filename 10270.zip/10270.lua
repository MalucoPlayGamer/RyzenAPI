-- Lua provided by RyzenAPI
-- Game: 10270

-- MAIN APPLICATION
addappid(10270)
-- Game: addappid(10270)

-- MAIN APP DEPOTS / PACKAGES
addappid(10271, 1, "b426fb0f8fc745fdb6affdd6efb20709a6cc894a48b133c7f5df3c603497d0de")
addappid(10272, 1, "6b50c0fbf95854b490ac213c94de74f480706b11686d9726aadf8491b246b4cc")
addappid(10273, 1, "9bc472dfc5a842bff0b8c3d05d56c8e7d9bc7acd4949aadd4ff70b9b392548af")
