-- Lua provided by RyzenAPI
-- Game: 1186310

-- MAIN APPLICATION
addappid(1186310)
-- Game: addappid(1186310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186311, 1, "9a2e007df9f2d03bebe5d4afb65d27727a12bf02be81ee80d85c72021fe18d2b")
