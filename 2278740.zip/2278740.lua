-- Lua provided by RyzenAPI
-- Game: addappid(2278740)

-- MAIN APPLICATION
addappid(2278740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278741, 1, "bc9a93417cc7929df7710bd6ec32e7f18e45e77b3f4f1a459eb47a5034144a40")
