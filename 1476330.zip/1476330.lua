-- Lua provided by RyzenAPI
-- Game: 1476330

-- MAIN APPLICATION
addappid(1476330)
-- Game: addappid(1476330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476331, 1, "e9da268e53dff3a6ad40d9e59cc6fc9e8e751fdc5dedc68042fe566d6b54ca9e")
