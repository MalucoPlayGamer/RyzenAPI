-- Lua provided by RyzenAPI
-- Game: Game: Martha's Dolls

-- MAIN APPLICATION
addappid(2614380)
-- Game: addappid(2614380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614381, 1, "0a0affa364cd72bdb4f34f73ae4c24128fdeb17c6580015e50cb75b3eee83cdb")
