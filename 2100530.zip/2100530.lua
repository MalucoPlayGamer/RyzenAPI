-- Lua provided by RyzenAPI
-- Game: Game: AppID 2100530

-- MAIN APPLICATION
addappid(2100530)
-- Game: addappid(2100530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100531, 1, "f292a759636b1434c5aecd9bf6b4fadf90e7a13cf5272c9c00a88cb03b39f9d0")
