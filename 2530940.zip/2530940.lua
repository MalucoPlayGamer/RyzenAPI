-- Lua provided by RyzenAPI
-- Game: 2530940

-- MAIN APPLICATION
addappid(2530940)
-- Game: addappid(2530940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530941, 1, "151d785fd4ce06f521f35c4e709663793cd55a38a8e90ad0b9cdf90872d7296f")
