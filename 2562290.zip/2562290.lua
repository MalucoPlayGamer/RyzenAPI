-- Lua provided by RyzenAPI
-- Game: Penrose

-- MAIN APPLICATION
addappid(2562290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562291, 1, "bbe5dcbca42ff0af3f3d4f13bdd237c26e26327e1d33fad99ee41efd0374c81a")
