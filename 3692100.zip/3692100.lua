-- Lua provided by RyzenAPI
-- Game: 3692100

-- MAIN APPLICATION
addappid(3692100)
-- Game: addappid(3692100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3692101, 1, "5582657c8ed8b433011544859cfd3a3af760c638766ac94f7ad507dbf8262cc8")
