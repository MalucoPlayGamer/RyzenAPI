-- Lua provided by RyzenAPI
-- Game: Haunted Hotel

-- MAIN APPLICATION
addappid(533030)

-- MAIN APP DEPOTS / PACKAGES
addappid(533031,0,"58bed01c61cf0932c08b3721e9111e6185c6fa353e53c61c09ad7b9abdbafe18")

