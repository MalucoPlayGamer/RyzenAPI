-- Lua provided by RyzenAPI
-- Game: Sand in a Box

-- MAIN APPLICATION
addappid(2225680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225681, 1, "547d8df645ce432862ee7d444a68ad1e0bb59e4f47907619259d97ea37415ade")
