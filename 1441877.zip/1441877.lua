-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1441877)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441877,0,"9f2b6eedfb5c53570938c99177e3a28d8bd9c09d26bc01ccc3015ee6abc55ac5")

