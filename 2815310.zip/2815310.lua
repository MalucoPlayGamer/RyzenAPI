-- Lua provided by RyzenAPI
-- Game: The Sims™ 4 Businesses & Hobbies Expansion Pack

-- MAIN APPLICATION
addappid(2815310)
addappid(3171040)
addappid(3171041)
addappid(3171042)
addappid(3171043)
addappid(3171044)
addappid(3171045)
addappid(3171046)
addappid(3171047)
addappid(3171048)
-- Game: addappid(2815310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815311, 1, "2dfb4e345a5cdbe824f6d6ea756437fd3c47353c9e63a165e791815146f25312")
