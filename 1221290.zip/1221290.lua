-- Lua provided by RyzenAPI
-- Game: 1221290

-- MAIN APPLICATION
addappid(1221290)
-- Game: addappid(1221290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221291, 1, "d235f5f0be3c3db0f4165a8febf878ccc63bb401409daade327eda50d8fe8b64")
