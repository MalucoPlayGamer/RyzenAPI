-- Lua provided by RyzenAPI
-- Game: Under the Sky World

-- MAIN APPLICATION
addappid(2185760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185762,0,"21388212517ef0198c0e84d9cefb1429bfa112591a1e5a5dbdc5c6139b259981")
