-- Lua provided by RyzenAPI 
-- Game: AppID 2167050
addappid(2167050)
addappid(2167051, 1, "a0cc373bc2396620bc36ace75dd57ac6432850695af2cd737d38c48f9c40520f")
