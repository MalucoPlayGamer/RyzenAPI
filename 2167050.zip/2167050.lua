-- Lua provided by RyzenAPI
-- Game: addappid(2167050)

-- MAIN APPLICATION
addappid(2167050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167051, 1, "a0cc373bc2396620bc36ace75dd57ac6432850695af2cd737d38c48f9c40520f")
