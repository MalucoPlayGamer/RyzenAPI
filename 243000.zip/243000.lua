-- Lua provided by RyzenAPI
-- Game: Omikron: The Nomad Soul

-- MAIN APPLICATION
addappid(243000)

-- MAIN APP DEPOTS / PACKAGES
addappid(243001, 1, "dd27379942e3d5d04c8c1dd92a5670c463b61c1057dd74a9c741da402e373cb4")

