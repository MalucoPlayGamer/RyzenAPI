-- Lua provided by RyzenAPI
-- Game: Omikron: The Nomad Soul

-- MAIN APPLICATION
addappid(243000)

-- MAIN APP DEPOTS / PACKAGES
addappid(243001, 1, "dd27379942e3d5d04c8c1dd92a5670c463b61c1057dd74a9c741da402e373cb4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
