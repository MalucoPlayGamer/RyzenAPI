-- Lua provided by RyzenAPI
-- Game: addappid(951550)

-- MAIN APPLICATION
addappid(951550)

-- MAIN APP DEPOTS / PACKAGES
addappid(951551, 1, "a1c76332f4d25c5c65f7819c34c82420eedf2e026e7290713fb4acdfbb9d2acf")
