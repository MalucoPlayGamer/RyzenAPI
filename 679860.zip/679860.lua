-- Lua provided by RyzenAPI
-- Game: ZAP Master

-- MAIN APPLICATION
addappid(679860)
-- Game: addappid(679860)

-- MAIN APP DEPOTS / PACKAGES
addappid(679861, 1, "a8f0e60f993406df7673833cc97c6d4102876b1dfd7af46c5c13511c08ea3b8d")
addappid(679862, 1, "b2b72b637b332908b92e3db057a1ba34e5e3882cf3f0ef59026eba4e2aeedfe0")
addappid(679863, 1, "3cf8e5123d212635c5b2010db720ed04f5048b622a17dbea7b72736e0dc1b885")
