-- Lua provided by RyzenAPI 
-- Game: AppID 3331230
addappid(3331230)
addappid(3331231, 1, "6904d81f2f81f8289ff4a558b6ff0c38d4549c58e4cf06e8a73cc1bbeabee647")
