-- Lua provided by RyzenAPI
-- Game: Stackmon

-- MAIN APPLICATION
addappid(3729550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3729551,0,"e5e9399d4f8900ee91c0dc8e562d8be46db19fb6d92153a57e899e7cf9a218fe")

