-- Lua provided by RyzenAPI
-- Game: PC Store Simulator

-- MAIN APPLICATION
addappid(3451560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3451561,0,"8d3bb0f750d70fa49fc72ffbca5841a66eb1452889d431f662c47982223fb1c6")

