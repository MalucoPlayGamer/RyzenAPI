-- Lua provided by RyzenAPI
-- Game: 亚穆蒂斯

-- MAIN APPLICATION
addappid(2814540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814542,0,"b6aa0749338ef92ab96dcdfa77f6600442ab12c55f389eb5f3ab742939516ab0")
