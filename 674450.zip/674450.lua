-- Lua provided by RyzenAPI
-- Game: Game: Blind Witch -Peek Window-

-- MAIN APPLICATION
addappid(674450)
-- Game: addappid(674450)

-- MAIN APP DEPOTS / PACKAGES
addappid(674451, 1, "e298704e1adcc89cdee48424082d1fc079650ad211c09f7e70353816840b6ddc")
