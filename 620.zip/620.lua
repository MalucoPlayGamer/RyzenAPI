-- Lua provided by RyzenAPI
-- Game: Portal 2

-- MAIN APPLICATION
addappid(620)
addappid(650)
addappid(651)
addappid(652)
addappid(653)
addappid(654)
addappid(669)
addappid(323180)
-- Game: addappid(620)

-- MAIN APP DEPOTS / PACKAGES
addappid(621, 1, "d2718f2424c94832a7112661774d98ffb3d52f454312f543a71418d253100d1d")
addappid(622, 1, "0be76bef0b464b2d58b6ced70c86e608708c18c1204836cb1bb5d209776f8a0e")
addappid(623, 1, "6a9fe60f83046355da81ea12f8fe895e3f59f1223d1689cc7e1ba327358e99fb")
addappid(624, 1, "48fcb7e647902c2d9467ef3f4405e1b6308981949705cb2b7489bb3d22aead66")
addappid(625, 1, "d120d4c37faea11be77c787dc48000f297aaf8200a4265969a4f5dbeebc0326c")
addappid(626, 1, "50611154e0550112cb9f9edcc44cf32bb90a7fe8d2f5738f6f24b7ced43cf7c2")
addappid(627, 1, "4ff7fb0bde51bae4f2c7a9bb220fd2da9bd9b3b8210d222c615acf28a8fdd821")
addappid(628, 1, "7f299ff4eec6b9de24869bb482a325b72f792798c87268f03feda25d4f3361c5")
addappid(660, 0, "759d2251fd0bb050f088c166dc269ea869ddafde525032db3095fbf06cc0dfc3")
addappid(661, 0, "5e338dd8d07e4cda5dfbcc7eb03418d9b1d93192bc20d5aac2174b851b11c1a6")
