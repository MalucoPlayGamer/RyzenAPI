-- Lua provided by RyzenAPI
-- Game: AppID 233030

-- MAIN APPLICATION
addappid(233030)

-- MAIN APP DEPOTS / PACKAGES
addappid(233031, 1, "5a510f20f0dcff2a61141bc0022f7957759db7f8b3a1cc956c6b9f5f73adf847")

