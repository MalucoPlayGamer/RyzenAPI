-- Lua provided by RyzenAPI
-- Game: addappid(1121570)

-- MAIN APPLICATION
addappid(1121570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121571, 1, "f373bf75aac7a76ed2ae961d198c30612db6357ef87b0914c93862788d287b0f")
