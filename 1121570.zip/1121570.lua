-- Lua provided by RyzenAPI
-- Game: Avalo Legends

-- MAIN APPLICATION
addappid(1121570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1121571, 1, "f373bf75aac7a76ed2ae961d198c30612db6357ef87b0914c93862788d287b0f")

