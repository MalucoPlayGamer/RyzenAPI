-- Lua provided by RyzenAPI
-- Game: Game: AppID 661570

-- MAIN APPLICATION
addappid(661570)
-- Game: addappid(661570)

-- MAIN APP DEPOTS / PACKAGES
addappid(661571, 1, "94b93e6737d4d0a8aa970dd1582efb256c34ead0a0764c54daf00b553014c651")
