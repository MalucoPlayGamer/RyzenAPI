-- Lua provided by RyzenAPI
-- Game: Outpost Zero

-- MAIN APPLICATION
addappid(677480)

-- MAIN APP DEPOTS / PACKAGES
addappid(677481,0,"d208e95e42226f32745fa111071d97061b2e8a52500d66de15fb6e9d6e52bb65")

