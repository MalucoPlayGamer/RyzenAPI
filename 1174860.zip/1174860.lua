-- Lua provided by RyzenAPI
-- Game: AppID 1174860

-- MAIN APPLICATION
addappid(1174860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174861, 1, "f73a6b735d9818c2eb9fab8a865f1a1f8241e7671a670134764c317bd5aadd07")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1177050)
addappid(1177060)
