-- Lua provided by RyzenAPI 
-- Game: Binarystar Infinity
addappid(1491040)
addappid(1491041, 1, "476ffc56c2ab38a9aadb8f4a257adadc3cf08c2882b82fc2929a8bb7b6765c78")
