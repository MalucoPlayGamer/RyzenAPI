-- Lua provided by RyzenAPI
-- Game: addappid(1491040)

-- MAIN APPLICATION
addappid(1491040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491041, 1, "476ffc56c2ab38a9aadb8f4a257adadc3cf08c2882b82fc2929a8bb7b6765c78")
