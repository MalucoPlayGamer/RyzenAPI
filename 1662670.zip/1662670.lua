-- Lua provided by RyzenAPI
-- Game: 1662670

-- MAIN APPLICATION
addappid(1662670)
-- Game: addappid(1662670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662671, 1, "9ac2d64a665a3b151a03e2e5007396a120829f3b2038331529ec516adaaf4bfe")
