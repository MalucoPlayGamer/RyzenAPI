-- Lua provided by RyzenAPI
-- Game: Everyone Fights

-- MAIN APPLICATION
addappid(3502130)
-- Game: addappid(3502130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3502131, 1, "28f965439fec1350390f1173415032479a50d58c464152a4e3ad2e08ad4eddad")
