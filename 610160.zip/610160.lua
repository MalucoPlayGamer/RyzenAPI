-- Lua provided by RyzenAPI
-- Game: addappid(610160)

-- MAIN APPLICATION
addappid(610160)

-- MAIN APP DEPOTS / PACKAGES
addappid(610161, 1, "0eb97aebb3806e0ee5ec9ebaf5a85d5285621f023a17336d6b38ce0bdbbaaa4e")
