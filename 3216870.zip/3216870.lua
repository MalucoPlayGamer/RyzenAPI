-- Lua provided by RyzenAPI
-- Game: Luma Island Demo

-- MAIN APPLICATION
addappid(3216870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216871, 1, "dcd96faaa736f5586dab96c1d8e73071b333e34981391e78d62d374662989e78")
