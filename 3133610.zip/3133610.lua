-- Lua provided by SkyAPI 
-- Game: Sivi's Factory
addappid(3133610)
addappid(3133611, 1, "3ce0372d68b8c1cd60ee097fedebe8ac6b1d932aeb3c0a65da201ec7ea799af9")
