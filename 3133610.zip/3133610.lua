-- Lua provided by RyzenAPI
-- Game: Sivi's Factory

-- MAIN APPLICATION
addappid(3133610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133611, 1, "3ce0372d68b8c1cd60ee097fedebe8ac6b1d932aeb3c0a65da201ec7ea799af9")
