-- Lua provided by RyzenAPI
-- Game: Sivi's Factory

-- MAIN APPLICATION
addappid(3133610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133611, 1, "3ce0372d68b8c1cd60ee097fedebe8ac6b1d932aeb3c0a65da201ec7ea799af9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
