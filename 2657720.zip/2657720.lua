-- Lua provided by RyzenAPI
-- Game: addappid(2657720)

-- MAIN APPLICATION
addappid(2657720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657721, 1, "acd911734686b55c08dea6cdf20edf59c6d2d424d46fcda8e7e5103b3c71e8b8")
addappid(2657722, 1, "c87e2bb903956bd4d4ef4429661fb63cd4e479c162e11c69af4495d5e828ce64")
addappid(2657723, 1, "fba8717efa22b367e3374d1a2365ead8dff07e195442b69b1b917ea1d1db4887")
