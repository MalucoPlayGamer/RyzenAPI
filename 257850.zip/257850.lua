-- Lua provided by RyzenAPI
-- Game: Hyper Light Drifter

-- MAIN APPLICATION
addappid(257850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(257851, 1, "37a8a32e3f159349f6a5702f391bdd0d4a341ae4c61d63111b9ae41c6b7ee678")
addappid(257852, 1, "e2a9e9b9db696ac8dd6724bfcdf95afbf1429d38a1c21da0f32ffafe69cc6b05")
addappid(257853, 1, "7ce7c20d8ad87abeaf568a6ae959f9a5fc223975000f58e0128ff61f1197d2e0")

