-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(565120)
addappid(782390)
addappid(803430)
addappid(803431)
addappid(803432)
addappid(803433)
addappid(803434)
addappid(803435)
addappid(803436)
-- Game: addappid(565120)

-- MAIN APP DEPOTS / PACKAGES
addappid(565122,0,"7d9474b28e9d4113ee3a19ab33439dc2daef94ead81758eb6d69a281bd04776d")
addappid(565123,0,"31c5a0d37ca76bb1cb1c418cb6e4da938f40da63b98f279f8d7bce61a2601425")
addappid(565124,0,"8b373d9288556f5cbfde59c9f1beb612f60227a3b796095536a09a7813419925")
