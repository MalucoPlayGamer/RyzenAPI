-- Lua provided by RyzenAPI
-- Game: Killing Floor Dedicated Server - Win32

-- MAIN APPLICATION
addappid(215350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251,0,"948100db7737b1e42b84518e4ad90b8957d3cb1c4bde1417ae44ffffdbf30a92")
addappid(1253,0,"1a8942bd259927e86a936945b7450cd828122dbe750c0e8c4f94af15aa849764")

