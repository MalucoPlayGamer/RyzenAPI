-- Lua provided by RyzenAPI
-- Game: Skyscraper Jump

-- MAIN APPLICATION
addappid(1949910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949911, 1, "f0832f6b74ddb13602f986fd60fb9a8d5535d7ad66160ffb32ae83516dd6b382")

