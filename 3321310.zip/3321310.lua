-- Lua provided by RyzenAPI
-- Game: Black Pine: Incident Response Demo

-- MAIN APPLICATION
addappid(3321310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3321311, 1, "1ca72165e97328c4e80e1fc094b819c0f5cc67a3d6ce0c62f43fae462569476b")
