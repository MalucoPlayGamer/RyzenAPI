-- Lua provided by RyzenAPI
-- Game: Sweet Holiday Jigsaws: Halloween Night

-- MAIN APPLICATION
addappid(1216310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216311, 1, "907fc3d6aad7bdeae21407cf169cc3d1c581b369945b2aa381c7385b895dc53a")
