-- Lua provided by RyzenAPI
-- Game: Space Wars: Interstellar Empires

-- MAIN APPLICATION
addappid(574070)

-- MAIN APP DEPOTS / PACKAGES
addappid(574071, 1, "28614b712f6788478cf74a20cf8ce2e6fc9e96f0b0315671458990c78a979e7e")
addappid(574072, 1, "5b76d0594a15909a2a4ebefb58a5b9d62920b0f80aba74e9187b83fee1717e7a")

