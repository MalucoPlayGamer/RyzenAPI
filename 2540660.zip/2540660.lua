-- Lua provided by RyzenAPI
-- Game: AppID 2540660

-- MAIN APPLICATION
addappid(2540660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540661, 1, "acfe3e19d525d320b982172f48ef0c0d4b10cffbe9d1b03b1cd4f59ab24ea6ae")

