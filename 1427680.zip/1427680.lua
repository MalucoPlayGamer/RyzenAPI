-- Lua provided by RyzenAPI
-- Game: Magia X

-- MAIN APPLICATION
addappid(1427680) -- Magia X
addappid(1515940) -- Magia X - Caleera
addappid(1516770) -- Magia X - Morgan
addappid(1516780) -- Magia X - Leta

-- MAIN APP DEPOTS / PACKAGES
addappid(1427681, 1, "f7ff48cd688e26e3b5d76cef08c240cd3bdea39ed62e379606ae3c9318405189") -- Magia X 콘텐츠
