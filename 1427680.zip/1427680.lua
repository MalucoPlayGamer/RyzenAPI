-- Lua provided by RyzenAPI
-- Game: Magia X

-- MAIN APPLICATION
addappid(1427680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427681, 1, "f7ff48cd688e26e3b5d76cef08c240cd3bdea39ed62e379606ae3c9318405189")
