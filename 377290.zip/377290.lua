-- Lua provided by RyzenAPI
-- Game: addappid(377290)

-- MAIN APPLICATION
addappid(377290)
addappid(377291)

-- MAIN APP DEPOTS / PACKAGES
addappid(377292,0,"747fcc34ed91fb7b32e55ec66493d7f5e23cf0fcae4d8bbc44113d103ba90b18")
addappid(377293,0,"862de0bc728d0f69a2eeb513fc696be4eb2078f34602adc4d87bc69f44c3217b")
