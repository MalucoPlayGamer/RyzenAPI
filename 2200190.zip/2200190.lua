-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] The Karaoke | ヒトカラ🎤

-- MAIN APPLICATION
addappid(2200190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200191, 1, "7a0c440b038f5a44bbe42abbfff0fa17ecc272b77115fb9e7b718bdc5f2ad95e")
