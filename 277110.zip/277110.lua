-- Lua provided by RyzenAPI
-- Game: Return to Mysterious Island

-- MAIN APPLICATION
addappid(277110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(277111, 1, "e3d6928289de9aef016a11b9da0903363fdd301a3943760f93ade93cfa3d00e5")
addappid(277113, 1, "e6bab9a3bcd5e5db091949e20e3994541557c55d352d818ae17646340d5dc729")
addappid(277114, 1, "587f0b403c8eff86cbeb8b768942f9afa6d7e0e4d4ca2e3b3b787b0446d00bae")
addappid(277115, 1, "caa330226c7d5a57d269ab07bb5e550d8b895f3e9ebc0a8f7fd654f55590220e")
addappid(277116, 1, "ea6b2b0ead32ca4973a5d6a050e6344728155c4cb92e36adbee96905bf8ae1d3")
addappid(277117, 1, "2defa5d1f1e69d00b766964d21dd668bf20d09bd8218d9d295ddd7871093c2d3")
addappid(277118, 1, "24e50026c8457b1362673c770eae3e29a43716b16d02aa6030cc081780ccb655")

