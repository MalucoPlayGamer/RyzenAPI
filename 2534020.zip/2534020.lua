-- Lua provided by RyzenAPI
-- Game: Dungeon Tale

-- MAIN APPLICATION
addappid(2534020)
-- Game: addappid(2534020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2534021, 1, "7b9b42f051e1554f840e0ef024ee666661e758f98299d68eb272c51844448d61")
