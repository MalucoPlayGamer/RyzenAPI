-- Lua provided by RyzenAPI
-- Game: MergeCrafter

-- MAIN APPLICATION
addappid(1964220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964222,0,"f0ea269760bccbad65c3e1e2f31c00637e9e5faf3d26343c8b18edd57926d669")
addappid(1964223,0,"ec413d0f55864c8eeffb921487f8e81ba77a8547d29ae900227454ce99063291")

