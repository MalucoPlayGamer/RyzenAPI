-- Lua provided by RyzenAPI
-- Game: Hello Puppets! VR

-- MAIN APPLICATION
addappid(1426280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426281, 1, "97fb69ba4342b5cf08dc3873444169b7e3d4c9e3fb68633789cd67261c3269d5")

