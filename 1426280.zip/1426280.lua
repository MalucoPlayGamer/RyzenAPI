-- Lua provided by SkyAPI 
-- Game: Hello Puppets! VR
addappid(1426280)
addappid(1426281, 1, "97fb69ba4342b5cf08dc3873444169b7e3d4c9e3fb68633789cd67261c3269d5")
