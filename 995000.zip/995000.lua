-- Lua provided by RyzenAPI
-- Game: AppID 995000

-- MAIN APPLICATION
addappid(995000)
-- Game: addappid(995000)

-- MAIN APP DEPOTS / PACKAGES
addappid(995001, 1, "91a436a4fdcab4bfced973a2926bcffc97469aa7b94b8155914754b83fdba680")
