-- Lua provided by RyzenAPI
-- Game: Insight

-- MAIN APPLICATION
addappid(2986600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2986601, 1, "cf9ecb67e32ba7075e627d0b059cbf7f9490ecd55971234a82a778e010b5522e")

