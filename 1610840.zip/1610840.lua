-- Lua provided by SkyAPI 
-- Game: Virtuous Western
addappid(1610840)
addappid(1610841, 1, "e6921370b04b7c00188ecfa770af57c10a4681cd922748de5efa74829aa41968")
