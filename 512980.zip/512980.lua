-- Lua provided by RyzenAPI
-- Game: Game: Copy Kitty Demo

-- MAIN APPLICATION
addappid(512980)
-- Game: addappid(512980)

-- MAIN APP DEPOTS / PACKAGES
addappid(512981, 1, "b5e28e6613b927ee7e7e64c29d1b755dd447f30959aba682d84ec2306765856b")
