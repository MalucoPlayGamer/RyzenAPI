-- Lua provided by RyzenAPI 
-- Game: Egypt: Old Kingdom Demo
addappid(863370)
addappid(863371, 1, "783bc0cbc3f32d30fdd101b455c5c4bf2540b86033510e257e164300ec93164e")
