-- Lua provided by RyzenAPI
-- Game: addappid(3672470)

-- MAIN APPLICATION
addappid(3672470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3672471, 1, "e4cb8d2017c1040cc982992b2df32b13094d63cd4e2120ec643abf1e7a0eff74")
