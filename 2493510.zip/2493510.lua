-- Lua provided by RyzenAPI
-- Game: CYBERFIELD

-- MAIN APPLICATION
addappid(2493510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493511, 1, "4b3ca0c1afa6cf22d26eb957fabae1bd26d7e27d41f315f704b911b7edacb5fb")

