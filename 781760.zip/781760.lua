-- Lua provided by RyzenAPI 
-- Game: Trivia Vault: Health Trivia Deluxe
addappid(781760)
addappid(781761, 1, "4895b120849e242d3a0e07a305b0c612be8401a3133263a92c754d48ca0155ca")
