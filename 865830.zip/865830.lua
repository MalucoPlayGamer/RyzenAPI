-- Lua provided by RyzenAPI
-- Game: Game: Psychedelica of the Ashen Hawk

-- MAIN APPLICATION
addappid(865830)
-- Game: addappid(865830)

-- MAIN APP DEPOTS / PACKAGES
addappid(865831, 1, "a095d48a15b2c9b112731592f19b66315678ec5c9739044eab2cb74650a16e5b")
