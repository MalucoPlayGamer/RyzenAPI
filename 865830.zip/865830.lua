-- Lua provided by RyzenAPI
-- Game: Psychedelica of the Ashen Hawk

-- MAIN APPLICATION
addappid(865830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(865831, 1, "a095d48a15b2c9b112731592f19b66315678ec5c9739044eab2cb74650a16e5b")

