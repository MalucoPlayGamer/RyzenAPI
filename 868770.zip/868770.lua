-- Lua provided by RyzenAPI
-- Game: addappid(868770)

-- MAIN APPLICATION
addappid(868770)
addappid(1350040)

-- MAIN APP DEPOTS / PACKAGES
addappid(868771, 1, "95bc4852b1443b0b8228e2b7e60e63553312a8bcdd1a285095b4fe4da8646d52")
