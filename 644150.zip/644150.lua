-- Lua provided by RyzenAPI
-- Game: Smogpunk 湮霾之地

-- MAIN APPLICATION
addappid(644150)
-- Game: addappid(644150)

-- MAIN APP DEPOTS / PACKAGES
addappid(644151, 1, "80a774737f747fe4abbcaeceb78201300236f6af1632ebf40eeb4b82fde7193c")
