-- Lua provided by RyzenAPI 
-- Game: Smogpunk 湮霾之地
addappid(644150)
addappid(644151, 1, "80a774737f747fe4abbcaeceb78201300236f6af1632ebf40eeb4b82fde7193c")
