-- 4005560's Lua and Manifest Created by Hubcap Manifest
-- Maktala
-- Created: June 14, 2026 at 06:05:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4005560) -- Maktala
-- MAIN APP DEPOTS
addappid(4005561, 1, "c1fe299b4117f91e3c8186557ef84bc49f527d6adecba6df625b9093ed971be0") -- Depot 4005561
-- setManifestid(4005561, "3226513760298134616", 439359101)
addappid(4005562, 1, "21107300a6e06f844c1425fa83121300ee3f85d10c60f9daa756602526f9bc33") -- Depot 4005562
-- setManifestid(4005562, "1593600619945550973", 456223678)
addappid(4005563, 1, "2a524bcf4278142e1cf4d42be27de955eeb091f789697085d4936a09913a6ac2") -- Depot 4005563
-- setManifestid(4005563, "739351841911170800", 436814659)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4205280) -- Maktala Slime Lootfest - Supporter Pack