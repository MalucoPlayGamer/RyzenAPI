-- Lua provided by RyzenAPI
-- Game: Wizardry: Labyrinth of Lost Souls

-- MAIN APPLICATION
addappid(948640)
addappid(1022570)

-- MAIN APP DEPOTS / PACKAGES
addappid(948641,0,"26889659d0161f4c07950842c6437d7da11a83cbea608857b11c7c6fb48f84d1")

