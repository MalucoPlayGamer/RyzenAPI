-- Lua provided by RyzenAPI
-- Game: Wizardry: Labyrinth of Lost Souls

-- MAIN APPLICATION
addappid(948640)
addappid(1022570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(948641,0,"26889659d0161f4c07950842c6437d7da11a83cbea608857b11c7c6fb48f84d1")

