-- Lua provided by RyzenAPI
-- Game: Neko-chan's Club

-- MAIN APPLICATION
addappid(2298730)
addappid(2311800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298731, 1, "f542954e54a65d705373a0441596e113a62713761e67492c9386886dc5db5d5c")

