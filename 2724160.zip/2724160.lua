-- Lua provided by RyzenAPI
-- Game: Game: MANA

-- MAIN APPLICATION
addappid(2724160)
-- Game: addappid(2724160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2724161, 1, "e449326e20e0a0b7dd009c515640ae6ea9c8a1bc473b44a0a2ba0e758c29b08d")
