-- Lua provided by RyzenAPI
-- Game: AppID 2160080

-- MAIN APPLICATION
addappid(2160080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2160081, 1, "5f3e3aaeaf228e232f4da3c2aa4f5067d2f7711e2ed256cc011f09b818ec4a76")

