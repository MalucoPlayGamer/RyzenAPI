-- Lua provided by RyzenAPI
-- Game: Cyber Rider

-- MAIN APPLICATION
addappid(1508200)
-- Game: addappid(1508200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508201, 1, "84621d734d765d703b6d169128e73c16b0a74144ef31bd1838e5284593a143b7")
