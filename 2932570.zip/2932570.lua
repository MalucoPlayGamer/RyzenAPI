-- Lua provided by RyzenAPI
-- Game: 2932570

-- MAIN APPLICATION
addappid(2932570)
-- Game: addappid(2932570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932571, 1, "4b04c80f7e3aa1c081827235115d5c55b7573b929ab27a455ad11b4a5e396dd1")
