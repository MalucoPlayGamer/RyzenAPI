-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1235755)
addappid(1242201)
addappid(1242202)
addappid(1242203)
addappid(1242204)
addappid(1242205)
addappid(1242206)
addappid(1242207)
addappid(1242208)
addappid(1242209)
addappid(1242210)
addappid(1242211)
addappid(1242213)
addappid(1242214)
addappid(1242215)
-- Game: addappid(1235755)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235755,0,"f43fa48516505fa06c7ca71371295b051f4522302dd4521c4d10b0be523c7f26")
addappid(1242200,0,"1e4faeba323189cfad294385f9901b815011fa9fa6e9f151a9903aa0cd8015b2")
addappid(1242212,0,"c78fa572c2125d1a1650943c1740ef1c959cdd0e0c78109dc1b2770a422b6562")
addappid(1242216,0,"0a833239f0c08e827bea95762e1d3f6aad58d668326b4ca803dcf6e5d5e095d5")
addappid(1242217,0,"10b94e0f026ef1ee4acfb2b43285064189c75b5efae7586864ea933e4bfc9ad8")
