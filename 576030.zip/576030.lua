-- Lua provided by RyzenAPI
-- Game: Game: AppID 576030

-- MAIN APPLICATION
addappid(576030)
-- Game: addappid(576030)

-- MAIN APP DEPOTS / PACKAGES
addappid(576031, 1, "64198729da54b10481838d098fbe8d3015519a02e47789fd1aa8960276ec49ed")
