-- Lua provided by RyzenAPI
-- Game: addappid(7830)

-- MAIN APPLICATION
addappid(7830)

-- MAIN APP DEPOTS / PACKAGES
addappid(7831, 1, "51d8a5b2ebc2f1cb55723df1287d1d0c2048617b49eb63eff95d73baafe479eb")
addappid(7832, 1, "4ff745af5eec839e17033d3d1e46bb6b8673aa8f1da39d56ac5d49eab14e4899")
addappid(7833, 1, "96d9c3a7d22a835e4896b7bbcff5b38728c0b3efc1fd115956c09a49d7512313")
addappid(7834, 1, "7718aeb2abc060ba4c49e439b5fce0a3d4284e4f585e880e71d9913093b68465")
addappid(7835, 1, "47608591e48d5ae2ffd2d71a07238cc0c56410dadc5994e1a25f53f19beaeee2")
addappid(7836, 1, "df6058ccb9930fc03e868c2746e55db266a464b6b8afb0d00cd33e9fdd2f9762")
