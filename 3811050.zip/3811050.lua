-- Lua provided by RyzenAPI
-- Game: Code L.U.S.T

-- MAIN APP DEPOTS / PACKAGES
addappid(3811050, 1, "e871a028c89ecef282a6e2b9c1c0cf25fbc93f66d1943247656b91ed9c47de8e") -- Code L.U.S.T
addappid(3811051, 1, "ad0da37036b7c1c479686b8ac7b0d025a16b7b401e9b87b0a98f775320b2aeda") -- Depot 3811051
addappid(3811052, 1, "2ec473d5d428abb2d53c19235267d1ccbe14f015cdcd6e3abf809b6fd7cd723c") -- Depot 3811052

