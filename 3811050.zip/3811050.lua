-- 3811050's Lua and Manifest Created by Hubcap Manifest
-- Code L.U.S.T
-- Created: August 11, 2026 at 12:04:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3811050, 1, "e871a028c89ecef282a6e2b9c1c0cf25fbc93f66d1943247656b91ed9c47de8e") -- Code L.U.S.T
-- MAIN APP DEPOTS
addappid(3811051, 1, "ad0da37036b7c1c479686b8ac7b0d025a16b7b401e9b87b0a98f775320b2aeda") -- Depot 3811051
setManifestid(3811051, "2624878993247103556", 1140524381)
addappid(3811052, 1, "2ec473d5d428abb2d53c19235267d1ccbe14f015cdcd6e3abf809b6fd7cd723c") -- Depot 3811052
setManifestid(3811052, "2927025478622696192", 873852419)