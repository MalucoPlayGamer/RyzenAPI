-- Lua provided by SkyAPI 
-- Game: AppID 719430
addappid(719430)
addappid(719431, 1, "cde0a12fb04721436c8470fd87527d9f399fde08c59899413d655ff161acf970")
