-- Lua provided by RyzenAPI
-- Game: Taima Miko Yuugi

-- MAIN APPLICATION
addappid(719430)

-- MAIN APP DEPOTS / PACKAGES
addappid(719431, 1, "cde0a12fb04721436c8470fd87527d9f399fde08c59899413d655ff161acf970")
