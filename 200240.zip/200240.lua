-- Lua provided by RyzenAPI
-- Game: 200240

-- MAIN APPLICATION
addappid(200240)
-- Game: addappid(200240)

-- MAIN APP DEPOTS / PACKAGES
addappid(200241, 1, "cca70f658440e5eef8ae844d6564244b40075a7c9e303e847a80ae67b831135c")
