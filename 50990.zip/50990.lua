-- Lua provided by RyzenAPI
-- Game: AppID 50990

-- MAIN APPLICATION
addappid(50990)
addappid(493640)

-- MAIN APP DEPOTS / PACKAGES
addappid(50991, 1, "6b4c35ab46fa1563f3cef49d2ece9d9fc4b1f448aa11826cbd96ad6583a534c9")
addappid(50992, 1, "95957ada4b6e7346a9116cd5706c4294782fdec987e14362b44dbbe12eb0058a")
addappid(493630, 0, "66fe26dfa6a71bb509da27a40414f7c91add9b9c85ce713fd74395b994d1cb25")

