-- Lua provided by RyzenAPI
-- Game: Cubicity: Slide puzzle

-- MAIN APPLICATION
addappid(970580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(970581, 1, "a8b56ed573b9fd69fe16ac042d34ee39a68ac4527ef4038f5c7507cde17ad80b")
addappid(970582, 1, "d4709d42529661441cf25e5f567418e41dd9c5b706c1ee9368d149f534ef82d4")

