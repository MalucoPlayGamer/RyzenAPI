-- Lua provided by RyzenAPI
-- Game: Return. (Free)

-- MAIN APPLICATION
addappid(1226310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226311, 1, "86221ff965b270eb5bc44becb532fd83be53bfffed020c793776d5c25d39b337")
