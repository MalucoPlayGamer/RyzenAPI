-- Lua provided by RyzenAPI
-- Game: AppID 474040

-- MAIN APPLICATION
addappid(474040)

-- MAIN APP DEPOTS / PACKAGES
addappid(474041, 1, "0219539dfaa434ecd8324cec78ad67e5e5700b8526ead5d1258b0c412d11da8b")
