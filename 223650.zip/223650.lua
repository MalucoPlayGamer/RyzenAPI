-- Lua provided by RyzenAPI
-- Game: AppID 223650

-- MAIN APPLICATION
addappid(223650)
-- Game: addappid(223650)

-- MAIN APP DEPOTS / PACKAGES
addappid(223651, 1, "fd9c3518acec5068111936faceced2aaf62ed8cc3c64815204e233bc9e526e26")
