-- Lua provided by RyzenAPI
-- Game: AppID 223650

-- MAIN APPLICATION
addappid(223650)

-- MAIN APP DEPOTS / PACKAGES
addappid(223651, 1, "fd9c3518acec5068111936faceced2aaf62ed8cc3c64815204e233bc9e526e26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(327230)
addappid(327231)
addappid(327232)
addappid(327850)
addappid(330750)
addappid(331310)
addappid(336050)
