-- Lua provided by RyzenAPI
-- Game: 2524580

-- MAIN APPLICATION
addappid(2524580)
-- Game: addappid(2524580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524581, 1, "bf99a05bfae57586561169330a5238794c25d3da4c9d4ff0fbb0278a1e38d50f")
