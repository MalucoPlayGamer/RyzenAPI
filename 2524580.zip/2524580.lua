-- Lua provided by RyzenAPI 
-- Game: Embers: Return to Dragonland
addappid(2524580)
addappid(2524581, 1, "bf99a05bfae57586561169330a5238794c25d3da4c9d4ff0fbb0278a1e38d50f")
