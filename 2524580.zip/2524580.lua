-- Lua provided by RyzenAPI
-- Game: Embers: Return to Dragonland

-- MAIN APPLICATION
addappid(2524580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2524581, 1, "bf99a05bfae57586561169330a5238794c25d3da4c9d4ff0fbb0278a1e38d50f")

