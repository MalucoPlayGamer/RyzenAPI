-- Lua provided by RyzenAPI
-- Game: Game: AppID 734120

-- MAIN APPLICATION
addappid(734120)
-- Game: addappid(734120)

-- MAIN APP DEPOTS / PACKAGES
addappid(734121, 1, "3ddb7f92c4c15ed72c35efd39cfaebc46f03bca41347b793db72bcc8ac08223a")
