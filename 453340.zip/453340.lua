-- Lua provided by SkyAPI 
-- Game: Hustle Cat
addappid(453340)
addappid(453341, 1, "cdcb198a9c88caa3961b4af571a49dc6b275512914b1f7bf72e5131425e81e0b")
addappid(453342, 1, "e61c72612bd9e374b92b95b2c1b09a0bebeff6d12afa780beef5116730d83110")
addappid(454450)
