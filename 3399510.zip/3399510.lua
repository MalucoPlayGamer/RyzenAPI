-- Lua provided by RyzenAPI
-- Game: Revengeful Ghost

-- MAIN APPLICATION
addappid(3399510)
-- Game: addappid(3399510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3399511, 1, "8475213a04d5d43ca59b69ee261588568190364fb4b873c941ad273796df7979")
