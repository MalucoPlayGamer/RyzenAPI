-- Lua provided by RyzenAPI
-- Game: 2304240

-- MAIN APPLICATION
addappid(2304240)
-- Game: addappid(2304240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304241, 1, "37dd737093c4e1de0e24e542e1a699237ae0cf8bbfedcec74e1d46524cdff146")
