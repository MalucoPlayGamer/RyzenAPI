-- Lua provided by RyzenAPI
-- Game: Golden Axe Idol

-- MAIN APPLICATION
addappid(1827950)
addappid(1827951)
addappid(1827952)
addappid(1827954)
-- Game: addappid(1827950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827953,0,"fd02369feea476506b053d2bec39c02ddf72260914940831f8da225ae341d303")
addappid(1827955,0,"fb8fdece2f77b0d69b7aa7eaaf147c6457ede4308c29f1bf768cb7da9b453e44")
