-- Lua provided by RyzenAPI
-- Game: 445920

-- MAIN APPLICATION
addappid(445920)
-- Game: addappid(445920)

-- MAIN APP DEPOTS / PACKAGES
addappid(445921, 1, "d5bb52d3a40d9401b63013ab46c566d8d90824a6e3b5168d5c6af044ba2ce739")
