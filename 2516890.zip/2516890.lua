-- Lua provided by RyzenAPI
-- Game: Andarin Weppes

-- MAIN APPLICATION
addappid(2516890)
-- Game: addappid(2516890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516891, 1, "8bbf90720a22db7ab819cc4d6299275d8efbee956e54a56974c1c3ea15254e77")
