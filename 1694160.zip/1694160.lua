-- Lua provided by RyzenAPI
-- Game: Singulive

-- MAIN APPLICATION
addappid(1694160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694161, 1, "0c99f4b245eab90736325d8b1b20789a5cfe2ede0df12f9fc0321df42d77747f")

