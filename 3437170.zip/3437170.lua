-- Lua provided by RyzenAPI
-- Game: addappid(3437170)

-- MAIN APPLICATION
addappid(3437170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3437171, 1, "0cec0016673a70d36d7643d8e0f1ddaac468ce5540573d1d6d3a6a01c437c131")
