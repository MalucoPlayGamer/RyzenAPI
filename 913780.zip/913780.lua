-- Lua provided by RyzenAPI
-- Game: NEW LIFE

-- MAIN APPLICATION
addappid(913780)
-- Game: addappid(913780)

-- MAIN APP DEPOTS / PACKAGES
addappid(913782,0,"6d3cfa3629ba48df03f03820cc1565c34dd98090a6d6743515fa59bad52226b0")
