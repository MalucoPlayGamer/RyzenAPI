-- Lua provided by RyzenAPI
-- Game: 3 Minutes to Midnight: Adventurer’s Guide | Hints and Walkthrough

-- MAIN APPLICATION
addappid(3175960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3175960,0,"90cf8eb12d20c6120c8d6f0bc5fec32deeb1dff6b1a43f1c70c97e8a73556400")

