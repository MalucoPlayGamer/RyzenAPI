-- Lua provided by RyzenAPI
-- Game: AppID 240660

-- MAIN APPLICATION
addappid(240660)
-- Game: addappid(240660)

-- MAIN APP DEPOTS / PACKAGES
addappid(240661, 1, "64be1188f26fdae3d7ae14b97826f62c2ee1532a678ed6ba298f982a78aa155a")
