-- Lua provided by RyzenAPI
-- Game: Game: Sky Fleet

-- MAIN APPLICATION
addappid(1347540)
-- Game: addappid(1347540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347541, 1, "2b96d7fe750e5a5019f6a3590129c5e76df8496442e99429536639d8fdda7c17")
