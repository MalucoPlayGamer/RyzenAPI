-- Lua provided by RyzenAPI
-- Game: Four Course Dungeon

-- MAIN APPLICATION
addappid(1962600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1962601, 1, "d5da6f2fbcab61ca872ab083b13a4300f9bc62bebd9b0e3d8d30b8df0a87e0cf")

