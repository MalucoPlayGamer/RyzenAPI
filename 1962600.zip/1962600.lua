-- Lua provided by RyzenAPI
-- Game: Four Course Dungeon

-- MAIN APPLICATION
addappid(1962600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962601, 1, "d5da6f2fbcab61ca872ab083b13a4300f9bc62bebd9b0e3d8d30b8df0a87e0cf")
