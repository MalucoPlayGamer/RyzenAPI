-- Lua provided by RyzenAPI
-- Game: Nigelopia Mini Mix

-- MAIN APPLICATION
addappid(1857570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857571, 1, "6040bb05522610f2f53e8c23acf6cb899eed77eacbb32df559d74c69bfcd1a25")

