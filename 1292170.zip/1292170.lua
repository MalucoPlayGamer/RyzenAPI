-- Lua provided by RyzenAPI
-- Game: Game: Krush Kill 'N Destroy Xtreme

-- MAIN APPLICATION
addappid(1292170)
-- Game: addappid(1292170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292171, 1, "732667744b8b3a92cdac9717e418328369ef7333b3c99d9bdc5ae8ca8d5aeff6")
