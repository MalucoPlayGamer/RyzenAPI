-- Lua provided by RyzenAPI
-- Game: Give Me More Missile!

-- MAIN APPLICATION
addappid(4981080) -- Give Me More Missile!

-- MAIN APP DEPOTS / PACKAGES
addappid(4981081, 1, "2e87cb665dc48baa419b4222b442bfe50bf62a3496dbe6b9d461d4ca91a63545") -- Depot 4981081
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
