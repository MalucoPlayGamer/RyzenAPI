-- Lua provided by RyzenAPI
-- Game: Game: MacGuffin

-- MAIN APPLICATION
addappid(398930)
-- Game: addappid(398930)

-- MAIN APP DEPOTS / PACKAGES
addappid(398931, 1, "a31caf062731ed7c0922c2d963801c3bd806b3691e738c3760f60d894253fb0d")
