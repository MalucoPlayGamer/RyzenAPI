-- Lua provided by RyzenAPI
-- Game: Ultimate Fishing Simulator VR

-- MAIN APPLICATION
addappid(1024010)
addappid(1032180)
addappid(1137530)
addappid(1137531)
addappid(1137532)
addappid(1137533)
addappid(1206640)
addappid(1256790)
addappid(1284890)
addappid(1318300)
addappid(1353990)
addappid(2250880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024011,0,"19e521e163747b91bb782b35a6241bd5d0e102cdeca0eda2dc3b4285bb1f91e4")

