-- Lua provided by RyzenAPI
-- Game: 1024010

-- MAIN APPLICATION
addappid(1024010)
-- Game: addappid(1024010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024011, 1, "19e521e163747b91bb782b35a6241bd5d0e102cdeca0eda2dc3b4285bb1f91e4")
