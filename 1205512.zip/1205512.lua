-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1205512)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205512,0,"5a584ea821de1ec0b842455af205716c8c5f223188547a4827578ba207d64a36")
