-- 5027510's Lua and Manifest Created by Hubcap Manifest
-- Tail Recursion
-- Created: August 21, 2026 at 22:57:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5027510) -- Tail Recursion
-- MAIN APP DEPOTS
addappid(5027511, 1, "efa60f5361914443671713940e12aa8fb8d11a3aeee54cfdd38abe9a0e877a3d") -- Depot 5027511
setManifestid(5027511, "222727459574479104", 65392951)
addappid(5027512, 1, "5d38cc601e66466fcc2b0ce62e9f60e7325fccf372c995eda7d9ef9bc0170dda") -- Depot 5027512
setManifestid(5027512, "6566092919382870100", 65557991)