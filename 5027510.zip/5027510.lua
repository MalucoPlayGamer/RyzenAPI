-- Lua provided by RyzenAPI
-- Game: Tail Recursion

-- MAIN APPLICATION
addappid(5027510) -- Tail Recursion

-- MAIN APP DEPOTS / PACKAGES
addappid(5027511, 1, "efa60f5361914443671713940e12aa8fb8d11a3aeee54cfdd38abe9a0e877a3d") -- Depot 5027511
addappid(5027512, 1, "5d38cc601e66466fcc2b0ce62e9f60e7325fccf372c995eda7d9ef9bc0170dda") -- Depot 5027512

