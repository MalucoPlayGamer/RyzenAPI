-- Lua provided by RyzenAPI
-- Game: ModernArt Virtual Museum

-- MAIN APPLICATION
addappid(2680700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680701, 1, "a915433e84ed3d537123c96311c2a49b55a3f57680b81604dea1282e0a5b9e9a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
