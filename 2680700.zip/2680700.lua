-- Lua provided by RyzenAPI
-- Game: ModernArt Virtual Museum

-- MAIN APPLICATION
addappid(2680700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680701, 1, "a915433e84ed3d537123c96311c2a49b55a3f57680b81604dea1282e0a5b9e9a")
