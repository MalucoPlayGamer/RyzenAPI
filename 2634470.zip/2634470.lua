-- Lua provided by RyzenAPI
-- Game: 2634470

-- MAIN APPLICATION
addappid(2634470)
-- Game: addappid(2634470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2634471, 1, "2e0eda0bbbe7fcf56aa2aa1ef0bb3f28025b90ea2288189d32b004e73a1af287")
