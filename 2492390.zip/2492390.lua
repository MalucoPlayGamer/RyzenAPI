-- Lua provided by RyzenAPI
-- Game: Logiart Grimoire

-- MAIN APPLICATION
addappid(2492390)
-- Game: addappid(2492390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492392,0,"339472ad51cec8d17a8ce990fa1597634a3c33243a6a0ebd323a83f574520cd7")
