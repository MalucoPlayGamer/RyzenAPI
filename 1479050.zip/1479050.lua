-- Lua provided by RyzenAPI
-- Game: AppID 1479050

-- MAIN APPLICATION
addappid(1479050)
-- Game: addappid(1479050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479051, 1, "41698d33e880cc11245b3e76bdb6149eeb85329ac2a98a8d8275aa2207208abe")
