-- Lua provided by RyzenAPI
-- Game: K2: Digital Edition

-- MAIN APPLICATION
addappid(2561310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2561311, 1, "e5c4ab827f4dd550cd0a428f0354bd11d081ec463931445d35bd728fe8d5bba1")

