-- Lua provided by RyzenAPI
-- Game: Game: AppID 794860

-- MAIN APPLICATION
addappid(794860)
-- Game: addappid(794860)

-- MAIN APP DEPOTS / PACKAGES
addappid(794861, 1, "35a0131cbd83b246f13a3abe94f1b3b58934ac648918f770493d7eda3f9c995d")
addappid(794863, 1, "8a9a9941ba0c8bc7af420c385ae2305a89dcc8fd3559a664c2ab082a8cab6001")
