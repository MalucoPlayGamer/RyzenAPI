-- Lua provided by RyzenAPI 
-- Game: Animal Shelter: Prologue
addappid(1661260)
addappid(1661261, 1, "267934754e1099d293186b49fbb4323eaf3feaa20c21422db3c29bc80036b892")
