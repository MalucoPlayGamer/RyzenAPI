-- Lua provided by RyzenAPI
-- Game: Sub Rosa

-- MAIN APPLICATION
addappid(272230)

-- MAIN APP DEPOTS / PACKAGES
addappid(272231, 1, "432150eedff62b50c48602c825e788adb5ef5db96f07d4e2a8fe5699c93b893c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
