-- Lua provided by RyzenAPI
-- Game: AppID 447290

-- MAIN APPLICATION
addappid(447290)

-- MAIN APP DEPOTS / PACKAGES
addappid(447291, 1, "2b16ec9a875fd23b02746ccfcbe6ddd4a54a8ca0cd96b9230fac650d6327ba8f")
addappid(725260, 0, "7d267eb2892c53cb4b9a879799564789e48d9a2e28826b7b8d8d9532a1e53ca3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
