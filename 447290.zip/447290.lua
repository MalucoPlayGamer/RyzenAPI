-- Lua provided by SkyAPI 
-- Game: AppID 447290
addappid(447290)
addappid(447291, 1, "2b16ec9a875fd23b02746ccfcbe6ddd4a54a8ca0cd96b9230fac650d6327ba8f")
addappid(725260, 0, "7d267eb2892c53cb4b9a879799564789e48d9a2e28826b7b8d8d9532a1e53ca3")
