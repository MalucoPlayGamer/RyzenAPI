-- Lua provided by RyzenAPI
-- Game: Sam & Max: Beyond Time and Space

-- MAIN APPLICATION
addappid(1747050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747051, 1, "ec7653752626cdf0a4d712a4d65be08d5cd010987b8494fd36c2e525f1409c59")
addappid(1747052, 1, "b41b094823e049f82937b5c848a837936f9ce3ddde6bfb123b4232c710bd3ab9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1909350)
