-- Lua provided by RyzenAPI
-- Game: 1028630

-- MAIN APPLICATION
addappid(1028630)
-- Game: addappid(1028630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028631, 1, "e9ccb16c87cb95105a5b78d0bbdcbac885cdc99d5b83b4d9d928b13b56ca408a")
addappid(1554620, 0, "2fc404dce88b76903ce2a7d0bbaf98489fae7b3c4f10830d5b5ee8b0278ddd18")
