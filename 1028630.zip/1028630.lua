-- Lua provided by RyzenAPI
-- Game: AppID 1028630

-- MAIN APPLICATION
addappid(1028630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1028631, 1, "e9ccb16c87cb95105a5b78d0bbdcbac885cdc99d5b83b4d9d928b13b56ca408a")
addappid(1554620, 0, "2fc404dce88b76903ce2a7d0bbaf98489fae7b3c4f10830d5b5ee8b0278ddd18")

