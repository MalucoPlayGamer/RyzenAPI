-- Lua provided by RyzenAPI
-- Game: FPV LOGIC

-- MAIN APPLICATION
addappid(2398030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2398031, 1, "b76b683644c7545de3bbdef05520b1a49033e826fb317eb20867f867539c2c6e")
addappid(2398032, 1, "b8c7e49cc33c0c64f1331bb72733f0d0eb430b04a46ce3b467a70ce0828a3dde")
