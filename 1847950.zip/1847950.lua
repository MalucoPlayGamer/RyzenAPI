-- Lua provided by SkyAPI 
-- Game: AppID 1847950
addappid(1847950)
addappid(1847951, 1, "9fe02858ff0f310c6c397f28b32b4d017ba8f8c99a49d1f67d75d97b581ef209")
