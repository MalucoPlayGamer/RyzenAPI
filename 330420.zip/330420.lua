-- Lua provided by RyzenAPI
-- Game: The Interactive Adventures of Dog Mendonça & Pizzaboy®

-- MAIN APPLICATION
addappid(330420)
-- Game: addappid(330420)

-- MAIN APP DEPOTS / PACKAGES
addappid(330422,0,"d3b55963a1db5576c2a67769d5d32f536da88fbf4e2fd13fa17b4df54591c801")
addappid(330423,0,"38e576eff68c2948219c0281ef2866094424cf0897604a4d0ff1b1e920332a16")
addappid(330424,0,"fe504d7c4595fa59d0c26832d3ebf68cb57488a87f27fb588cf32f458306710d")
addappid(330425,0,"a0732198eca8923ece61e93e8b3311e429371f81fdb9108424f2a6a09586dfc5")
