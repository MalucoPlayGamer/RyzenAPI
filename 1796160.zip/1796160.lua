-- Lua provided by RyzenAPI
-- Game: Bunny e-Shop Soundtrack

-- MAIN APPLICATION
addappid(1796160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796161, 1, "c41d30656685935a536deedabc1c34c7ff839cb9047cc97f057d2fb1cc9d33c7")
addappid(1796162, 1, "061fe50297a1f506170773dbbe9d78fc4d1bfb550329916a27b52f6a602578f9")

