-- Lua provided by SkyAPI 
-- Game: AppID 2474720
addappid(2474720)
addappid(2474721, 1, "e4607022a49f9b65d17aae401b9685f56067a06ffbb5559142eda8c878eaccf3")
