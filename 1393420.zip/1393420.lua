-- Lua provided by RyzenAPI
-- Game: 1393420

-- MAIN APPLICATION
addappid(1393420)
-- Game: addappid(1393420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393421, 1, "def86e1b4a91f7b5aaf1e18f202169901416b2544efca6b24538ae620d846289")
