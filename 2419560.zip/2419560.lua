-- Lua provided by RyzenAPI
-- Game: Fujiwara Phoenix Demo

-- MAIN APPLICATION
addappid(2419560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419561, 1, "cae1464e8776c171907e36b481683726a45f73a0fd71fe9b9d5c6528aa1201d9")

