-- Lua provided by RyzenAPI
-- Game: 3025290

-- MAIN APPLICATION
addappid(3025290)
-- Game: addappid(3025290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025291, 1, "8cbe99cf4196809afbd529cb0abf66e2898f3e6c4693ce21949d9fd01c7547e4")
