-- Lua provided by RyzenAPI
-- Game: Into The Dread

-- MAIN APPLICATION
addappid(3054960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3054961, 1, "0e736f722df941c0f48efcf93d12676a5c6bbd9e571875c4b572f82dda690e3b")

