-- Lua provided by RyzenAPI
-- Game: Into The Dread

-- MAIN APPLICATION
addappid(3054960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054961, 1, "0e736f722df941c0f48efcf93d12676a5c6bbd9e571875c4b572f82dda690e3b")
