-- Lua provided by RyzenAPI 
-- Game: Potion Explosion
addappid(788420)
addappid(788421, 1, "61ab64ba3a450d9119c8faa60c50303c42d7a6676a52a000b9f6108d867179af")
addappid(788422, 1, "538331b0c82fbc68cbad730e41449fa23785b178244c9f872689fb0383ab4bc6")
addappid(788423, 1, "48ea9d19dd197b5ebdaf0e96f2eca7bbeeb4c1692e1959ce663ea3fc4106b825")
addappid(789170)
