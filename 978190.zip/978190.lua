-- Lua provided by RyzenAPI
-- Game: Steel Sword Story S

-- MAIN APPLICATION
addappid(978190)

-- MAIN APP DEPOTS / PACKAGES
addappid(978191, 1, "3fbff5c8e310440c9ec430469fc175e9a0b1312ae0fa668210d262bb6081d312")
