-- Lua provided by RyzenAPI
-- Game: Game: Jigsaw 360

-- MAIN APPLICATION
addappid(836610)
-- Game: addappid(836610)

-- MAIN APP DEPOTS / PACKAGES
addappid(836611, 1, "49bb07690c70bea065b51152ab221b7c282453b6c6953d63f9c1add6fbcd5b0c")
