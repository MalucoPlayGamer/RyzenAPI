-- Lua provided by RyzenAPI
-- Game: PHAT STACKS

-- MAIN APPLICATION
addappid(556160)

-- MAIN APP DEPOTS / PACKAGES
addappid(556161, 1, "8329c61fb4db832ac1b6c3d12fffb428db72163e666fa9c0c9dd4649abfc310e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1340461)
addappid(1340462)
addappid(1340463)
addappid(1340464)
addappid(1340590)
