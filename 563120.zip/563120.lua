-- Lua provided by RyzenAPI
-- Game: Game: Desolate Wastes: Vendor Chronicles

-- MAIN APPLICATION
addappid(563120)
-- Game: addappid(563120)

-- MAIN APP DEPOTS / PACKAGES
addappid(563121, 1, "b9e8776f3542b27160745b0b2d662b6114c3b48c8ee949d8179e82d0ee9703f1")
