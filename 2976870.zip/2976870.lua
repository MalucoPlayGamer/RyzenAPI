-- Lua provided by RyzenAPI
-- Game: addappid(2976870)

-- MAIN APPLICATION
addappid(2976870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976871, 1, "dd7f2fcca7b54c05fbefb4870fbc60e3b2534bb47180fb21efb6e0da183b62d4")
