-- Lua provided by RyzenAPI
-- Game: addappid(2715660)

-- MAIN APPLICATION
addappid(2715660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715661, 1, "3a00a9b08397ca3acfcdc79eb55cb035816efb2b173d421483b0dc198f053a83")
