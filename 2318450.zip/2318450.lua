-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails to Azure - Azure Archives Art Book

-- MAIN APPLICATION
addappid(2318450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318450,0,"65baad6b6ab19166844a787c56547647791c3995b429de289bc040011930b501")

