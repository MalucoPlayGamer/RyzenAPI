-- Lua provided by RyzenAPI
-- Game: 416770

-- MAIN APPLICATION
addappid(416770)
-- Game: addappid(416770)

-- MAIN APP DEPOTS / PACKAGES
addappid(416771, 1, "c219d032ce8475630b4f3c47c1153f552bbbd7617686cfd713ec83a22d09cd9b")
addappid(416772, 1, "8d9d6ef147ddefc5a64bd6cc17c03514901aa8c43d1f412d84bdb020222a35ff")
addappid(416773, 1, "9ebe35e32286db82ef71267704edb6b45435896ae3fdb83e6b60021b0e62be42")
