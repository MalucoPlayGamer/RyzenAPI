-- Lua provided by RyzenAPI
-- Game: 322900

-- MAIN APPLICATION
addappid(322900)
-- Game: addappid(322900)

-- MAIN APP DEPOTS / PACKAGES
addappid(322901, 1, "55d7d24475c4a0bc21377345f3d30406160549b3591e359ac886e378fc2cece2")
