-- Lua provided by RyzenAPI
-- Game: 真愿交错

-- MAIN APPLICATION
addappid(3001160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(3001161, 1, "4b60aed1d2b9c99ccbddf335a0296d99eee86147b3e80e85a43e700979f19690")

