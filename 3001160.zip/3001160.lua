-- Lua provided by RyzenAPI
-- Game: Game: 真愿交错

-- MAIN APPLICATION
addappid(3001160)
-- Game: addappid(3001160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001161, 1, "4b60aed1d2b9c99ccbddf335a0296d99eee86147b3e80e85a43e700979f19690")
