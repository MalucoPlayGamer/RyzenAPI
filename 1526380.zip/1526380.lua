-- Lua provided by RyzenAPI 
-- Game: Excavator Simulator VR
addappid(1526380)
addappid(1526381, 1, "20679b00e522f8b9336d342eb0e45f88aeb49e8d890e96f63ff903d88031e4de")
