-- Lua provided by RyzenAPI
-- Game: 506610

-- MAIN APPLICATION
addappid(506610)
-- Game: addappid(506610)

-- MAIN APP DEPOTS / PACKAGES
addappid(506611, 1, "a9afd962f2b3b13615d00940a036fe77bf9bf5c0091de7c9474ac584c51d818f")
