-- Lua provided by RyzenAPI
-- Game: Game: Baldi's Basics Plus

-- MAIN APPLICATION
addappid(1275890)
-- Game: addappid(1275890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275891, 1, "311496f62a59013629f9698b66e74dc8432a2fd9d30b1182891b7a37a9f2113f")
addappid(1275892, 1, "1e23c689edc58019b16cb8dbd4a58a337349ea18d0a52dc77b2882ad0c4dd3e4")
addappid(1275893, 1, "cdd2e002910dcea162209fe5a2b76a05dd46856d6a4b649e09b7b8ccf7ccc1e8")
