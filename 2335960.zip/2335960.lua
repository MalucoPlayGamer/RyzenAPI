-- Lua provided by RyzenAPI
-- Game: Cards We're Dealt

-- MAIN APPLICATION
addappid(2335960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335961, 1, "c537941a3a627761a6fe9a417c329aa7f1cf492c980294de27eaead773d61d56")

