-- Lua provided by RyzenAPI
-- Game: Princess Farmer Demo

-- MAIN APPLICATION
addappid(1473990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473991, 1, "ad67df13d452b8124904173d542b03243aae5a58b0214aa9d2b507357561ac0e")

