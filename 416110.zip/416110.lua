-- Lua provided by RyzenAPI
-- Game: 416110

-- MAIN APPLICATION
addappid(416110)
addappid(428320)
addappid(428321)
-- Game: addappid(416110)

-- MAIN APP DEPOTS / PACKAGES
addappid(416111, 1, "313263d5cf619b3dddf78e1a7e3b78722d67e7e7566be0f40716fd9d0bc40a0a")
