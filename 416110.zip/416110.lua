-- Lua provided by RyzenAPI 
-- Game: Blitz Breaker
addappid(416110)
addappid(416111, 1, "313263d5cf619b3dddf78e1a7e3b78722d67e7e7566be0f40716fd9d0bc40a0a")
addappid(428320)
addappid(428321)
