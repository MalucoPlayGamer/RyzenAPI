-- Lua provided by RyzenAPI
-- Game: 2141820

-- MAIN APPLICATION
addappid(2141820)
-- Game: addappid(2141820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141821, 1, "de9091892532f9cd8ab753dbbf9101c0381dc6196c93a691ce526f38bdde5527")
