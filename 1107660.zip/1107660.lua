-- Lua provided by RyzenAPI
-- Game: Game: Round Rooms

-- MAIN APPLICATION
addappid(1107660)
-- Game: addappid(1107660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107661, 1, "e8d3749f69caf60b002714c305c1d4f3ac2e0b1a905c00febc6bf13db11e8eb5")
