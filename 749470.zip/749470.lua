-- Lua provided by RyzenAPI
-- Game: TAOTH - The Adventures of the Herkulez

-- MAIN APPLICATION
addappid(749470)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(749471, 1, "5b460f4b6c54816f18c37e6519fe2f05ec5e9b0d3bdc568c006031addbf172b7")
addappid(749472, 1, "e08b04c31c545c9d1a1f704d757faf7a4b4e8027de636175eb3fbc8d4021b07a")

