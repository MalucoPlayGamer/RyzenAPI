-- Lua provided by RyzenAPI 
-- Game: Silver Creek Falls - Chapter 3
addappid(441060)
addappid(441061, 1, "903101e7ac199163d17b6f7b77dc14c77c2a9a677ac0c33bb15d23b3687903cf")
