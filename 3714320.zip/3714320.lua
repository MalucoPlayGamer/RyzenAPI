-- Lua provided by RyzenAPI
-- Game: Penguin Panic! Soundtrack

-- MAIN APPLICATION
addappid(3714320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3714321, 1, "0582891e9452b921ea910a5f7d2360f90f964a6915ca8c3f89f6493df29b2669")
