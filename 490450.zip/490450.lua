-- Lua provided by RyzenAPI
-- Game: Game: Tokyo 42

-- MAIN APPLICATION
addappid(490450)
addappid(644720)
addappid(716840)
-- Game: addappid(490450)

-- MAIN APP DEPOTS / PACKAGES
addappid(490451, 1, "55a136b6c47d5201ba1076033fc09181078b209f485b9fc52f613b375886d87a")
addappid(490452, 1, "80c67279102ca47370bee8c7022ddd86d2b111bf5c2a2aa5e737585b09589201")
