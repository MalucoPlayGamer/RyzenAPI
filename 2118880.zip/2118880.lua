-- Lua provided by RyzenAPI
-- Game: 2118880

-- MAIN APPLICATION
addappid(2118880)
-- Game: addappid(2118880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118880,0,"da229b6e7ddd93e39bb45450bf5c87b0d597539a2d8cda6ffde3300e1edd483c")
