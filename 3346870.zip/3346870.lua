-- Lua provided by RyzenAPI
-- Game: Taiwan Love Story⁵ Artbook

-- MAIN APPLICATION
addappid(3346870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3346871, 1, "44c94c69a119fccdf16968acf55d9a009d53fbd0f43ad58d5a7ba5eca1b4c90c")

