-- Lua provided by RyzenAPI
-- Game: addappid(814640)

-- MAIN APPLICATION
addappid(814640)

-- MAIN APP DEPOTS / PACKAGES
addappid(814641, 1, "fc596f287b72922132a772530e098142a212bcf9e574f4ab0e93a7f01476c3ef")
