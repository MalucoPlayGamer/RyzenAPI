-- Lua provided by RyzenAPI 
-- Game: Ground Pounders
addappid(267730)
addappid(267731, 1, "84edafe08f1ad0b7f700ede95443b8f0bc88e3817df294e4d91a95e3f954ab89")
addappid(301060, 0, "0f93e5c43353424dbb4cc2a9b66ef389dcb1ab94d17621bc63c59f57a2b83154")
