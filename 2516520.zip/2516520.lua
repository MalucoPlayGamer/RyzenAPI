-- Lua provided by RyzenAPI
-- Game: 奇怪的RPG 2 Playtest

-- MAIN APPLICATION
addappid(2516520)
-- Game: addappid(2516520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516521, 1, "737212b4589b6321b9ac780124824d239fd71aa8c10c4e45637035bdbd6947b0")
