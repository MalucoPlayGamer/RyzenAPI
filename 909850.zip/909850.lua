-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(909850)

-- MAIN APP DEPOTS / PACKAGES
addappid(909850,0,"144d6b5ea550cd93df107ba4d35fc59dddc78a48ab0d2f8c27a7bbdd10a144c8")

