-- Lua provided by RyzenAPI
-- Game: Resequenced

-- MAIN APPLICATION
addappid(845490)

-- MAIN APP DEPOTS / PACKAGES
addappid(845491,0,"90f9380c83be0f93de5466b86f36af896e9df7cbbac3075bf37fb30f44a72eb8")

