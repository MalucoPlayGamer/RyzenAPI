-- Lua provided by RyzenAPI
-- Game: EarthNight

-- MAIN APPLICATION
addappid(777410)

-- MAIN APP DEPOTS / PACKAGES
addappid(777411, 1, "f31205ab0b0197c1c0f5e28338d320731c3df1b3206798cef9e67eb3e8d76d4f")

