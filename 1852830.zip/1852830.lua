-- Lua provided by SkyAPI 
-- Game: SPACE ACCIDENT
addappid(1852830)
addappid(1852831, 1, "5ffa9f99d536a8a87069f6e60d9c5bad214f5fbc00f16555c80832c0a1286e7b")
