-- Lua provided by RyzenAPI
-- Game: Game: SPACE ACCIDENT

-- MAIN APPLICATION
addappid(1852830)
-- Game: addappid(1852830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852831, 1, "5ffa9f99d536a8a87069f6e60d9c5bad214f5fbc00f16555c80832c0a1286e7b")
