-- Lua provided by RyzenAPI
-- Game: Game: AppID 966870

-- MAIN APPLICATION
addappid(966870)
-- Game: addappid(966870)

-- MAIN APP DEPOTS / PACKAGES
addappid(966871, 1, "b65bc8a4790cb3c1cf26b84313fe10a7a650d801070697a00b151f04ff943d06")
addappid(998601, 0, "b9d122618b7f450ae705b69ad40d630d142b86a5fd18588c95a51a37dbdf1a29")
