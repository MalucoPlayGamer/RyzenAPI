-- Lua provided by RyzenAPI
-- Game: Terminull Brigade™

-- MAIN APPLICATION
addappid(3104410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3104411, 1, "c2e770c44090a689e448c2ab698c82b72545e15b72b003011009958c5d373b6b")
addappid(3104412, 1, "0b53fda1fc27d61b8cfa1c1c8f447837dc58d12ea75541f9ddc20f06d06bb463")
addappid(3104413, 1, "b3f893c0dcb00687862546b4bcd9a50c0ecca2c703b50e97453e27dd1701bf96")

