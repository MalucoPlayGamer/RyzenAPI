-- Lua provided by RyzenAPI
-- Game: Gun Monkeys

-- MAIN APPLICATION
addappid(239450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(239451, 1, "16ab806152d459cacb439cc519ec0ecc42e20d4c6901630456acaeb474756668")
addappid(239452, 1, "a7c06565cdec4db6d82ef1f48b5416b919b30c693df6f333da252b0b2dab8380")

