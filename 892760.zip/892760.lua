-- Lua provided by RyzenAPI
-- Game: Game: Seed of Evil

-- MAIN APPLICATION
addappid(892760)
-- Game: addappid(892760)

-- MAIN APP DEPOTS / PACKAGES
addappid(892761, 1, "11086f74a6eafaa724d7549fcc0eb09ae0976395d36693e72d1c3dfe44696a8f")
addappid(892762, 1, "72a29d0d063f30b800d8d4c09d1f8ea2612de8532bffb5f7f8e2549d2e5e539b")
addappid(892763, 1, "a97b90266c06405df829d30a6d2aa5909bc0d10b8934bcff6adef5a80806ae3a")
