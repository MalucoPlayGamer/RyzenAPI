-- Lua provided by RyzenAPI
-- Game: 2747080

-- MAIN APPLICATION
addappid(2747080)
-- Game: addappid(2747080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747080,0,"1d8d054023fb23a6dffa2c7a99d5000cda65433f87a451509f5476a197baf391")
