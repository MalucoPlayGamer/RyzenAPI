-- Lua provided by RyzenAPI
-- Game: addappid(2998110)

-- MAIN APPLICATION
addappid(2998110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998110,0,"7865ba472bbc2792ab1f46a6a5794b572b11dfdb894ed138cea901276c6138ec")
