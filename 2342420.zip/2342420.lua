-- Lua provided by RyzenAPI
-- Game: Magic Research Demo

-- MAIN APPLICATION
addappid(2342420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342421, 1, "50002b9874528f2dcc695f2d47271ec7cc4b354c61a9a8445265e8f065dcbb22")
