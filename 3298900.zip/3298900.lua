-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3298900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298900,0,"047fe37656b447580e81aee0dddb145f926b096789eda141652c89359908a786")

