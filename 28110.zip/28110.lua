-- Lua provided by RyzenAPI
-- Game: Deus Ex Human Revolution Augmented Edition Bonus Content

-- MAIN APPLICATION
addappid(28110)

-- MAIN APP DEPOTS / PACKAGES
addappid(28111, 1, "d7637a80566708bd1feacbaf54174644ce3d0b2b78677bcbd777f495f68335ba")
addappid(28112, 1, "f68cf2046d0ce1e15455307479c8051d64af6dfbb2e626b64adf29b155b0ea41")
addappid(28113, 1, "51dc649658938e91627b5597983f8e84efb2d6b38228dba3902e968ae4db04d9")
addappid(28114, 1, "a0347eae8b23d793cd8c2cacb0cd356ee4da4859de4af304b0b1bb5c4d53f5b8")
addappid(28115, 1, "ef3dab338be25032df7013937738801418c05e9697e210a5f26c2138c5920713")
addappid(28116, 1, "9f66dc15b8f46124db2fc77d3b62d05306a995daa7b790eb6ce1cb8194c719ef")
addappid(28117, 1, "e459f408b8ca57ae4ac8ae8bda14f25782ffa0acc64e55b7a79cdc3fed7b8323")
