-- Lua provided by RyzenAPI
-- Game: Game: LOOTPLOT

-- MAIN APPLICATION
addappid(3057190)
-- Game: addappid(3057190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057191, 1, "8c0fc9ed0e842f2938f08e3d6e1586f077b553203e9833a3b2d62412b46d3f39")
