-- Lua provided by SkyAPI 
-- Game: LOOTPLOT
addappid(3057190)
addappid(3057191, 1, "8c0fc9ed0e842f2938f08e3d6e1586f077b553203e9833a3b2d62412b46d3f39")
