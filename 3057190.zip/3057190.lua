-- Lua provided by RyzenAPI
-- Game: LOOTPLOT

-- MAIN APPLICATION
addappid(3057190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057191, 1, "8c0fc9ed0e842f2938f08e3d6e1586f077b553203e9833a3b2d62412b46d3f39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
