-- Lua provided by RyzenAPI
-- Game: Game: Football Manager 2019 Touch

-- MAIN APPLICATION
addappid(872820)
-- Game: addappid(872820)

-- MAIN APP DEPOTS / PACKAGES
addappid(872821, 1, "814c4c1ad6807066d96a17fea28dc79240650f814352be006062501d7f449964")
addappid(872822, 1, "8e4bad3a4228681fdf5b2789bc91ef06e0e52212bc33d0e8317c8ac336f0d4c8")
addappid(872823, 1, "3dca93749819b8ea8d454fd4c6eb49ae200e9dd20e58509ea8f23262dd7513e1")
addappid(872824, 1, "3d78ff474586d1e3409c73cf1a13636fd78b25bd31fdb5aebdf893ec58c790be")
