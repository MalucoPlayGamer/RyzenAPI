-- Lua provided by RyzenAPI
-- Game: Football Manager 2019 Touch

-- MAIN APPLICATION
addappid(872820)
addappid(933750)
addappid(933751)
addappid(933752)
addappid(933753)
addappid(933754)
addappid(933755)
addappid(933756)
addappid(933757)
addappid(933758)
addappid(933759)
addappid(933760)
addappid(933761)
addappid(933762)
addappid(933763)
addappid(933764)
addappid(933765)

-- MAIN APP DEPOTS / PACKAGES
addappid(872820,0,"631cd56f1588c21095f2cdcc26f96c503b0dfeedc06258ca522cf70ef7679003")
addappid(872821,0,"814c4c1ad6807066d96a17fea28dc79240650f814352be006062501d7f449964")
addappid(872822,0,"8e4bad3a4228681fdf5b2789bc91ef06e0e52212bc33d0e8317c8ac336f0d4c8")
addappid(872823,0,"3dca93749819b8ea8d454fd4c6eb49ae200e9dd20e58509ea8f23262dd7513e1")
addappid(872824,0,"3d78ff474586d1e3409c73cf1a13636fd78b25bd31fdb5aebdf893ec58c790be")

