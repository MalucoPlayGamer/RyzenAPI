-- Lua provided by RyzenAPI
-- Game: Jungle Rumble

-- MAIN APPLICATION
addappid(1608210)
-- Game: addappid(1608210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608211, 1, "057fc3dfe00b8448cfdfdc0a1203216a83ded1d31c2a6acb02687436ff786797")
