-- Lua provided by RyzenAPI
-- Game: Game: College Bound: Arctic Adventure

-- MAIN APPLICATION
addappid(1895370)
-- Game: addappid(1895370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895371, 1, "4e65201ca8eb20917b3cf365077df3c0704597bcad3872d754cb57a9efeb4fd9")
