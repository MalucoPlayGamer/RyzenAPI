-- Lua provided by RyzenAPI
-- Game: Game: AppID 540510

-- MAIN APPLICATION
addappid(540510)
-- Game: addappid(540510)

-- MAIN APP DEPOTS / PACKAGES
addappid(540511, 1, "2dd34bbb0c1db9001975a754915227519f3bd101270c39137aa8c81a5058bd70")
addappid(540512, 1, "5602bb32fddc9386407845f5d0da0eaa2728c8146ba2338a54ae70203eb721b2")
addappid(540513, 1, "a385c6ce1f6b86eae0f634531f31ee5bc6dbf131c15b0f534be6b72b2cea1d4f")
