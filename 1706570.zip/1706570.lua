-- Lua provided by RyzenAPI
-- Game: Chupacabras: Night Hunt

-- MAIN APPLICATION
addappid(1706570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706571, 1, "b7dcb90f37b98a583bc4ce1b9fe54ffe66e5737632d1f0f644d31d51ebb84c7b")

