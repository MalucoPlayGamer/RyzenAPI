-- Lua provided by RyzenAPI
-- Game: Dual Discovery: Unite Challenge 寻踪觅影：合二为一

-- MAIN APPLICATION
addappid(3251750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251751, 1, "0ae8c86572a67b2671a2fe5d361d2eeeec07d3079de727fb3158a33db460f770")

