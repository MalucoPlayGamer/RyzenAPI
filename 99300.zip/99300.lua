-- Lua provided by RyzenAPI
-- Game: Renegade Ops

-- MAIN APPLICATION
addappid(99300)

-- MAIN APP DEPOTS / PACKAGES
addappid(99301, 1, "1d16c379b67ca3c79d574790d94792d9f62e563d253a34fa5ccc63a8c521b465")
addappid(200610, 0, "561510e21bcae69e7db1ca198b9def77158253f2d6af6d728ecb9f431b5fae50")
addappid(200620, 0, "ecef370371809d072426fb282ba550282dcbc5c9bdac4cad5040552a7b4228f8")

