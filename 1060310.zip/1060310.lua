-- Lua provided by RyzenAPI
-- Game: Great Toilet Simulator

-- MAIN APPLICATION
addappid(1060310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060311, 1, "b36f5266f8d4a1a410cebbe4c4b8d2264bc448bce932dcb2ee0402a836131ca2")
