-- Lua provided by RyzenAPI
-- Game: Happy New Year, Zeliria!

-- MAIN APPLICATION
addappid(1490190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490191, 1, "99b4f0893b06834b6d79b2d23089cfa5730dbd63114797ce5f3789fbe7ae498c")
addappid(1490192, 1, "4b5be2d1bb82eb455aaf9afcf4506c420fe308c39555782e43c1d6a711961611")
addappid(1490193, 1, "22101e36b258d700593e52d304b90fb3fd61f666733a7fa1e9e8add3043b15e0")
addappid(1490194, 1, "2d46fced05bbda54922b7cc85724edd57cfdfc9069abb2461d88c0ede91bb6ed")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1510850)
addappid(1857060)
addappid(2755930)
