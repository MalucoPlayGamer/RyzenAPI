-- Lua provided by RyzenAPI
-- Game: Game: VR Hentai 18+

-- MAIN APPLICATION
addappid(1559160)
addappid(1563810)
-- Game: addappid(1559160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559161, 1, "0e0f3ba374e9b815ad1ebebd214f635d1b992a340a30a8c672e5fc4ef8403202")
