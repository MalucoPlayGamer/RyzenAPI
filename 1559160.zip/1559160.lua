-- Lua provided by RyzenAPI 
-- Game: VR Hentai 18+
addappid(1559160)
addappid(1559161, 1, "0e0f3ba374e9b815ad1ebebd214f635d1b992a340a30a8c672e5fc4ef8403202")
addappid(1563810)
