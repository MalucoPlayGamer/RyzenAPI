-- Lua provided by RyzenAPI 
-- Game: METAL BREAKER
addappid(2658080)
addappid(2658081, 1, "6729782620624c25f247ed08191052bf276f2bd0d9065f8c6ab3ccb8be34d568")
addappid(2658082, 1, "b5180efe7b49d96292273fcf1fbc073e0dddc74f24476aa5287213fe61cb82e9")
addappid(2658083, 1, "0317d8ea93d736cf0f277ee0f226af2a990691460a9634a266bec0f2acfdcaec")
