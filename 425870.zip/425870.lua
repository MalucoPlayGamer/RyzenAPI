-- Lua provided by SkyAPI 
-- Game: Gyrodisc Super League
addappid(425870)
addappid(425871, 1, "86f578b14213f6cfec0df7f7032bf938ddbfe561f7ba7b08fc558e9cced55991")
addappid(425872, 1, "e171596a92d1931632d245b5c2e9afddf93f4a100783762e9f1609dacf3a3998")
addappid(425875, 1, "b20fc3d1e5932be7d8351ede65cf2032f43f0144160556b2e767e5e1492fec51")
