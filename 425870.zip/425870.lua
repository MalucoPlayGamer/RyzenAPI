-- Lua provided by RyzenAPI
-- Game: Gyrodisc Super League

-- MAIN APPLICATION
addappid(425870)

-- MAIN APP DEPOTS / PACKAGES
addappid(425871, 1, "86f578b14213f6cfec0df7f7032bf938ddbfe561f7ba7b08fc558e9cced55991")
addappid(425872, 1, "e171596a92d1931632d245b5c2e9afddf93f4a100783762e9f1609dacf3a3998")
addappid(425875, 1, "b20fc3d1e5932be7d8351ede65cf2032f43f0144160556b2e767e5e1492fec51")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
