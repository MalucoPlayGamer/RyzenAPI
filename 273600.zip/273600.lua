-- Lua provided by RyzenAPI
-- Game: AppID 273600

-- MAIN APPLICATION
addappid(273600)
-- Game: addappid(273600)

-- MAIN APP DEPOTS / PACKAGES
addappid(273601, 1, "532c071817f0fa1114595532fb26f0fd1a1846a8b39c4b57a47fa763178c7bec")
