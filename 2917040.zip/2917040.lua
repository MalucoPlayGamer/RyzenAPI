-- Lua provided by RyzenAPI
-- Game: 2917040

-- MAIN APPLICATION
addappid(2917040)
-- Game: addappid(2917040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917041, 1, "eb73b4d3991f62d144dad56ce9e4d656232da7fdfd146ad693e209fea8738519")
