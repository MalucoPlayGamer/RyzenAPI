-- Lua provided by RyzenAPI
-- Game: Garten of Banban 8: Anti Devil

-- MAIN APPLICATION
addappid(2917040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917041, 1, "eb73b4d3991f62d144dad56ce9e4d656232da7fdfd146ad693e209fea8738519")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
