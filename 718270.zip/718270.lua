-- Lua provided by RyzenAPI
-- Game: Game: ZombieThon

-- MAIN APPLICATION
addappid(718270)
addappid(864820)
-- Game: addappid(718270)

-- MAIN APP DEPOTS / PACKAGES
addappid(718271, 1, "8e2eeb117f93799ea85dabd3512676d348ec63948598ff1afec7e92f8f541543")
