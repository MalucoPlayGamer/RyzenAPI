-- Lua provided by SkyAPI 
-- Game: AppID 1238120
addappid(1238120)
addappid(1238121, 1, "39448b82248648fd23f7267b4c240c29f79fcbc359c790199c961888e50893ce")
