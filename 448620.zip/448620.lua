-- Lua provided by RyzenAPI
-- Game: Rebirth of Island

-- MAIN APPLICATION
addappid(448620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(448621, 1, "4a981b0b8ea3135f3551039d8bfe23b884e8793d13ec1858facc47450b1ff092")

