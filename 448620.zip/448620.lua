-- Lua provided by RyzenAPI
-- Game: Rebirth of Island

-- MAIN APPLICATION
addappid(448620)
-- Game: addappid(448620)

-- MAIN APP DEPOTS / PACKAGES
addappid(448621, 1, "4a981b0b8ea3135f3551039d8bfe23b884e8793d13ec1858facc47450b1ff092")
