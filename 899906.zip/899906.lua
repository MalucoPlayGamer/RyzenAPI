-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Bass - Easy Linear Playing Exercise 1

-- MAIN APPLICATION
addappid(899906)

-- MAIN APP DEPOTS / PACKAGES
addappid(899906,0,"ac1f8e02b09ae43cc154cc18db4930436fc1ca6d29a9ca0f250952da04f6a6f9")

