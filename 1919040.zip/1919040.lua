-- Lua provided by RyzenAPI
-- Game: Winter

-- MAIN APPLICATION
addappid(1919040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919041, 1, "9d4d35dc4a438ad43d2ff01d89972ebc1cd081cae8e5d464a7fc6200a4da2998")

