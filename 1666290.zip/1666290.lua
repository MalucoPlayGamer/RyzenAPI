-- Lua provided by RyzenAPI
-- Game: Audioclash Playtest

-- MAIN APPLICATION
addappid(1666290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666291, 1, "596e6975ff760ac934b10ad981e6df46b508029d9376d43f40f0b41094868cc1")

