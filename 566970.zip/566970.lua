-- Lua provided by RyzenAPI
-- Game: addappid(566970)

-- MAIN APPLICATION
addappid(566970)

-- MAIN APP DEPOTS / PACKAGES
addappid(566971, 1, "0341872f4cbcea97cf65cb716dcd32002ddfc8be893ebd1a461290b49c970e84")
