-- Lua provided by SkyAPI 
-- Game: The Battle of Polytopia
addappid(874390)
addappid(874391, 1, "3e4f836c2b81f6990a3bcc630fbc90bd1897904d6480477a25a4102b7adeb688")
addappid(874392, 1, "468ee2c9635146e7af81725c7cf06cd35fe273a80c3068d630afdb394135bd8b")
addappid(874393, 1, "b0bc887e6a6361cfade1a868bef4b48b9b53b5dd7b6319378b44f3daff4e77ed")
