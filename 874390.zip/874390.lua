-- Lua provided by RyzenAPI
-- Game: The Battle of Polytopia

-- MAIN APPLICATION
addappid(874390)
addappid(982200)
addappid(982201)
addappid(1237430)
addappid(1529660)
addappid(2186650)
addappid(2350830)
addappid(2438450)
addappid(2736400)
addappid(2943450)
addappid(3255910)
addappid(3634640)
addappid(4224710)

-- MAIN APP DEPOTS / PACKAGES
addappid(874391,0,"3e4f836c2b81f6990a3bcc630fbc90bd1897904d6480477a25a4102b7adeb688")
addappid(874392,0,"468ee2c9635146e7af81725c7cf06cd35fe273a80c3068d630afdb394135bd8b")
addappid(874393,0,"b0bc887e6a6361cfade1a868bef4b48b9b53b5dd7b6319378b44f3daff4e77ed")

