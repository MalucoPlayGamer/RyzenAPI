-- Lua provided by RyzenAPI
-- Game: SnowNight

-- MAIN APPLICATION
addappid(965860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(965861, 1, "cf6bf9f9fa8ea54ff8d1bda609d05a84b8993611fab28adaa27eab27040bfee8")
