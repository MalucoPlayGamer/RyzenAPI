-- Lua provided by RyzenAPI
-- Game: AppID 965860

-- MAIN APPLICATION
addappid(965860)

-- MAIN APP DEPOTS / PACKAGES
addappid(965861, 1, "cf6bf9f9fa8ea54ff8d1bda609d05a84b8993611fab28adaa27eab27040bfee8")

