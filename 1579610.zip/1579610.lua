-- Lua provided by RyzenAPI
-- Game: Ragdoll Funhouse

-- MAIN APPLICATION
addappid(1579610)
-- Game: addappid(1579610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1579611, 1, "bcd9dda9e0c0efbd98595d4a347c4d2079f95a9bf7996743ad2f36f53e1c4432")
