-- Lua provided by RyzenAPI
-- Game: Game: AppID 1861790

-- MAIN APPLICATION
addappid(1861790)
-- Game: addappid(1861790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861791, 1, "bdd9d20d8410e7932c78d3309cd9f153c881623b989f746f4758789eb9a0840b")
