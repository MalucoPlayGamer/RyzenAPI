-- Lua provided by SkyAPI 
-- Game: AppID 1861790
addappid(1861790)
addappid(1861791, 1, "bdd9d20d8410e7932c78d3309cd9f153c881623b989f746f4758789eb9a0840b")
