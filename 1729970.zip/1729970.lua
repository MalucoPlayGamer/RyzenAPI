-- Lua provided by RyzenAPI
-- Game: The Art Of Gamedec

-- MAIN APPLICATION
addappid(1729970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729970,0,"511dee1193f29da01192ddf12d11bbb2557c5b52aa6b37e3b7dc6982687f1099")
