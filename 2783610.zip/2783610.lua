-- Lua provided by RyzenAPI
-- Game: Malignant Survivors

-- MAIN APPLICATION
addappid(2783610)
-- Game: addappid(2783610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783611, 1, "03aaf63f91db64d853f421a5ebd04a91a9f5834581ff5853c2aab6c8170e69df")
