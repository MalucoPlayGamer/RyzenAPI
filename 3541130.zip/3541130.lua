-- Lua provided by RyzenAPI
-- Game: Many Nights a Whisper

-- MAIN APPLICATION
addappid(3541130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3541131, 1, "08361b0af3c1eb3a14bcb693a1070ef443aa4566cbc0eb1df8f571b34a2426bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
