-- Lua provided by RyzenAPI
-- Game: Game: Many Nights a Whisper

-- MAIN APPLICATION
addappid(3541130)
-- Game: addappid(3541130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3541131, 1, "08361b0af3c1eb3a14bcb693a1070ef443aa4566cbc0eb1df8f571b34a2426bd")
