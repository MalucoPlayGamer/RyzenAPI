-- Lua provided by RyzenAPI
-- Game: 2685220

-- MAIN APPLICATION
addappid(2685220)
-- Game: addappid(2685220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685221, 1, "c339cf759dee5a2b5ceed763f64cff99430d95521447be3a6b1d33834f4fa581")
