-- Lua provided by SkyAPI 
-- Game: Where Pandas 熊猫在哪里
addappid(2685220)
addappid(2685221, 1, "c339cf759dee5a2b5ceed763f64cff99430d95521447be3a6b1d33834f4fa581")
