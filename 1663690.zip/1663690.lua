-- Lua provided by RyzenAPI
-- Game: Touhou Mystia's Izakaya - Soundtrack 2

-- MAIN APPLICATION
addappid(1663690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663691, 1, "9ed4afa1f6012270b0f598e3a02c0e9b53052c8301b2550a843607ff514302c5")
addappid(1663692, 1, "2c33fd3939a0484d5430f344970a9723fd838dcf6e9d2205eb5c04b3de256c96")

