-- Lua provided by RyzenAPI
-- Game: Game: Tower Wars

-- MAIN APPLICATION
addappid(214360)
-- Game: addappid(214360)

-- MAIN APP DEPOTS / PACKAGES
addappid(214361, 1, "657befbc854c022a389870f495acf1888f876892d2044f6abee341e387514c5f")
addappid(214362, 1, "18eb163ad638904b8f325a13b1e53bb02050dce2f2d9aeb19df2be02c52c2d26")
