-- Lua provided by RyzenAPI
-- Game: Kind Heart Survivors

-- MAIN APP DEPOTS / PACKAGES
addappid(2803170, 1, "26e177115dd627c4862cc0b229cb2d6bc3060164187eebb15cc072d9f108b840") -- Kind Heart Survivors
addappid(2803171, 1, "9da94ef4cf2ea7a7ff1cf2143f50216d1f743451b3ccb47ffeef4231b36b65fd") -- Depot 2803171

