-- 2803170's Lua and Manifest Created by Hubcap Manifest
-- Kind Heart Survivors
-- Created: August 03, 2026 at 02:49:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2803170, 1, "26e177115dd627c4862cc0b229cb2d6bc3060164187eebb15cc072d9f108b840") -- Kind Heart Survivors
-- MAIN APP DEPOTS
addappid(2803171, 1, "9da94ef4cf2ea7a7ff1cf2143f50216d1f743451b3ccb47ffeef4231b36b65fd") -- Depot 2803171
setManifestid(2803171, "4315667335282192976", 305755088)