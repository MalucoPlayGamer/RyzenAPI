-- Lua provided by RyzenAPI 
-- Game: My Furry Teacher 🐾
addappid(1861490)
addappid(1861491, 1, "6e6aa4888ef7f55ae833c2b61039a9220c7767173d87a7c0f607ff8825138040")
addappid(1861492, 1, "201bbb1f2d7ff2f0561c055765265494f7ce08bb7b9092ad9e3c2e097444bf55")
addappid(1862150)
