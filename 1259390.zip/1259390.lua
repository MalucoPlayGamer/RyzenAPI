-- Lua provided by RyzenAPI
-- Game: addappid(1259390)

-- MAIN APPLICATION
addappid(1259390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259391, 1, "43a2da6d6a0de0b1bf6920914f082abe0b0379e690542b5f88698b6a84724a13")
