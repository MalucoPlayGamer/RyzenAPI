-- Lua provided by RyzenAPI
-- Game: AppID 448350

-- MAIN APPLICATION
addappid(448350)
-- Game: addappid(448350)

-- MAIN APP DEPOTS / PACKAGES
addappid(448351, 1, "8dae8a1615dca14b9cb2cf2696bef981f26f70eac6d309d0ea0cd3a79cb59abc")
addappid(448352, 1, "67a5713bba0d672075837ac53024c4fa9ebc71160564d3bd3c4d22ba2f6567d8")
addappid(448353, 1, "ba37aa08bb14c42452d3b01c5f4674c4a84b4f462bc97d604471ae61b4e9404b")
addappid(448354, 1, "a40193e802bcbf13328f18671cf9cedb677617276a9b56672bf0862bfec93fc4")
