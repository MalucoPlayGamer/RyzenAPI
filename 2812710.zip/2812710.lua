-- Lua provided by SkyAPI 
-- Game: Nested Lands Playtest
addappid(2812710)
addappid(2812711, 1, "228746e3c5a3c43a153a96ff1e8aacad92a65ede5f182fe4d38a4e965eb1a80b")
