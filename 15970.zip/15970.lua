-- Lua provided by RyzenAPI
-- Game: 15970

-- MAIN APPLICATION
addappid(15970)
-- Game: addappid(15970)

-- MAIN APP DEPOTS / PACKAGES
addappid(15971, 1, "25be5039f73086d9e940113040b2f794aafc16faf0544e26d40f0d40b7fceb14")
