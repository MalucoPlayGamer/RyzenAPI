-- Lua provided by RyzenAPI
-- Game: Chronos: Before the Ashes

-- MAIN APPLICATION
addappid(967390)

-- MAIN APP DEPOTS / PACKAGES
addappid(967391, 1, "9adf14ca157c505db77002115e9f19fa3193143e1e76c020105aedba43a7cab1")

