-- Lua provided by RyzenAPI
-- Game: Chronos: Before the Ashes

-- MAIN APPLICATION
addappid(967390)

-- MAIN APP DEPOTS / PACKAGES
addappid(967391, 1, "9adf14ca157c505db77002115e9f19fa3193143e1e76c020105aedba43a7cab1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
