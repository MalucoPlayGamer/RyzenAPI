-- Lua provided by RyzenAPI
-- Game: Stay Still

-- MAIN APPLICATION
addappid(2231730)
-- Game: addappid(2231730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231731, 1, "14d45ba3bb177bcdc624cd7371212cacf075d6162afcde8d7a0724674a4a1763")
