-- Lua provided by RyzenAPI
-- Game: Creeper World: Anniversary Edition

-- MAIN APPLICATION
addappid(422910)

-- MAIN APP DEPOTS / PACKAGES
addappid(422911, 1, "cb21af46369daf5e8af1bb4306e5abc3da5651d220de77bd2b26548db0ff6882")
