-- Lua provided by RyzenAPI
-- Game: The Pointless Car Chase: Refueled

-- MAIN APPLICATION
addappid(1839080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839081, 1, "4aa338c127509cbaf3d02c14014a51d9b6278513fddb6d2b3c2628d740b4618b")

