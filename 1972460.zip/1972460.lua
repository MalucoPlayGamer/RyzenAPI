-- Lua provided by RyzenAPI
-- Game: Portobugia

-- MAIN APPLICATION
addappid(1972460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972461, 1, "5b4d70ec841fa778eb51882f8a560b30a8972f4a81162fc3e6a06506556060b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
