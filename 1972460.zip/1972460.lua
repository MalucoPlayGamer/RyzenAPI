-- Lua provided by SkyAPI 
-- Game: Portobugia
addappid(1972460)
addappid(1972461, 1, "5b4d70ec841fa778eb51882f8a560b30a8972f4a81162fc3e6a06506556060b0")
