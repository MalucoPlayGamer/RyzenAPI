-- Lua provided by RyzenAPI
-- Game: Portobugia

-- MAIN APPLICATION
addappid(1972460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972461, 1, "5b4d70ec841fa778eb51882f8a560b30a8972f4a81162fc3e6a06506556060b0")

