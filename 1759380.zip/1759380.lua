-- Lua provided by RyzenAPI
-- Game: 1759380

-- MAIN APPLICATION
addappid(1759380)
addappid(2634450)
-- Game: addappid(1759380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759381, 1, "e8a62c4cf777fa35cdc3e3eb6f874182ba7f7e8f2554658325d7d1642a04360c")
