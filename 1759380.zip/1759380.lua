-- Lua provided by RyzenAPI
-- Game: Bandle Tale: A League of Legends Story

-- MAIN APPLICATION
addappid(1759380)
addappid(2634450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759381, 1, "e8a62c4cf777fa35cdc3e3eb6f874182ba7f7e8f2554658325d7d1642a04360c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2634440)
