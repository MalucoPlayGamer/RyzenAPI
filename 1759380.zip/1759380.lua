-- Lua provided by SkyAPI 
-- Game: Bandle Tale: A League of Legends Story
addappid(1759380)
addappid(1759381, 1, "e8a62c4cf777fa35cdc3e3eb6f874182ba7f7e8f2554658325d7d1642a04360c")
addappid(2634450)
