-- Lua provided by SkyAPI 
-- Game: Spirits
addappid(210170)
addappid(210171, 1, "2b3037f49b88b4d368d0c464b0d19b0928cec8b5e12abbf5e40fd1af684a44c0")
addappid(210172, 1, "c14c80bd0964ef519331ee95029da8e27117d30920745662729c10abae7957a8")
addappid(210173, 1, "b7526d00b5e2b02f7c32b26eaa3a17c659311c71d7702ab6948bfdaee102b2bb")
