-- Lua provided by RyzenAPI
-- Game: Ball laB

-- MAIN APPLICATION
addappid(780800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(780801, 1, "74270bbcf3232c0c915cfc2c76775391eeafc52ff9dc8f79cf5642ac47c6e275")

