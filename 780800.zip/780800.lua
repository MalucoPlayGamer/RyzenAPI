-- Lua provided by RyzenAPI
-- Game: Ball laB

-- MAIN APPLICATION
addappid(780800)

-- MAIN APP DEPOTS / PACKAGES
addappid(780801, 1, "74270bbcf3232c0c915cfc2c76775391eeafc52ff9dc8f79cf5642ac47c6e275")
