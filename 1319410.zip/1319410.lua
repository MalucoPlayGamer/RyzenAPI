-- Lua provided by RyzenAPI
-- Game: The Almost Gone Original Soundtrack

-- MAIN APPLICATION
addappid(1319410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1319411, 1, "d6f8bcae510efc0b9f9f892b8848219fe2650b2283e18ec9a144853d915d6d89")
addappid(1319412, 1, "f31d4bb63ee344a053dbcd55ead691819ecdee67324cda6d818645d0e35ee975")

