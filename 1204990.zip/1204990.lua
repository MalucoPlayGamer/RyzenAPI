-- Lua provided by SkyAPI 
-- Game: Milkcraft
addappid(1204990)
addappid(1204991, 1, "51f94df154b3c9a6d23cf0244be0ff564f197c61a63548097879ec2190f27b85")
