-- Lua provided by RyzenAPI
-- Game: Milkcraft

-- MAIN APPLICATION
addappid(1204990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(1204991, 1, "51f94df154b3c9a6d23cf0244be0ff564f197c61a63548097879ec2190f27b85")

