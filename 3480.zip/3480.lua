-- Lua provided by RyzenAPI
-- Game: Peggle Deluxe

-- MAIN APPLICATION
addappid(3480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3481, 1, "84b8fc8f5aef44c756634061a97dd52f355a38068705741b18ad87c2baf54e40")
addappid(3485, 1, "e48fd850584ba591e32ee481d98d9c19ca173be73fff6c8f49b345ac40208bbc")
addappid(3486, 1, "1bf4d2a04a39089e92982dfef6c353f9d9b1d227e5d07c18b22ea782fdc88dd9")
addappid(3487, 1, "533d6fef2855107b6fafea77130c85db757ad18250ea763ff351547280afa05e")
addappid(3488, 1, "31e5b0deba3c07124c21878f816a9e6815da5ea8a140a85e24ab9de563b5fbbd")
addappid(3489, 1, "5adea0126a71cdc11390b4e1f09a54ffc3a0de686dde2373bcbf1078a7317b4e")

