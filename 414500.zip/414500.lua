-- Lua provided by RyzenAPI
-- Game: 414500

-- MAIN APPLICATION
addappid(414500)
-- Game: addappid(414500)

-- MAIN APP DEPOTS / PACKAGES
addappid(414501, 1, "e2b1a885c2b3a967bbdcab803ecfc03ad8842cc4deff05411959c4e723ef534b")
