-- Lua provided by RyzenAPI
-- Game: 364850

-- MAIN APPLICATION
addappid(364850)
-- Game: addappid(364850)

-- MAIN APP DEPOTS / PACKAGES
addappid(364851, 1, "d2c9dd8c5ae8658aa2700eba9522b9e2fa7225949bd244cb57e07b59320b12f5")
