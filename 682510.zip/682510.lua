-- Lua provided by RyzenAPI
-- Game: Game: 以罪之名 / In the name of sin

-- MAIN APPLICATION
addappid(682510)
-- Game: addappid(682510)

-- MAIN APP DEPOTS / PACKAGES
addappid(682511, 1, "865afeeb9acce371a8869c69c7b638ca53ac6c580ccb82eac1aaad71f101bd7b")
