-- Lua provided by SkyAPI 
-- Game: AppID 612060
addappid(612060)
addappid(612061, 1, "8cc058a41bbe3f22c6d0ce6b7757fe75dc51b155ee71fe9fef7a40a119bebe91")
addappid(612063, 1, "90c875b623a872326a961670b8fa8a15f38a6cf8270eac46b496b89b81aaf915")
