-- Lua provided by RyzenAPI
-- Game: Game: Ark of Charon

-- MAIN APPLICATION
addappid(2827810)
-- Game: addappid(2827810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827811, 1, "dbcdfa84d124266734b40d4cfdc92616e587331d8b072645a9f5f013f96e936d")
addappid(2827812, 1, "6a22d13da4436f00683255b00e77bc4068f050b395eef189c9405f7af4fa5126")
