-- Lua provided by SkyAPI 
-- Game: Eldritch Hunter
addappid(514810)
addappid(514811, 1, "c2ebe581eb6b0d1205f3d5acbd6d5412a6a0bdd0071041104fcb39f3b8fde39e")
