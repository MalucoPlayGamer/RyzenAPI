-- Lua provided by RyzenAPI
-- Game: Eldritch Hunter

-- MAIN APPLICATION
addappid(514810)
-- Game: addappid(514810)

-- MAIN APP DEPOTS / PACKAGES
addappid(514811, 1, "c2ebe581eb6b0d1205f3d5acbd6d5412a6a0bdd0071041104fcb39f3b8fde39e")
