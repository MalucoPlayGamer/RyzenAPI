-- Lua provided by RyzenAPI
-- Game: Critter Crunch

-- MAIN APPLICATION
addappid(61730)

-- MAIN APP DEPOTS / PACKAGES
addappid(61731, 1, "9cb14a45119246bf5f7177fa0772ce2ea078927c80948e51709efb27a9dcac57")

