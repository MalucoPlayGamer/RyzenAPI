-- 4430470's Lua and Manifest Created by Hubcap Manifest
-- 难蚌尖塔
-- Created: July 29, 2026 at 06:10:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4430470, 1, "fa0eabe20c99a1603724debd48743a90930813f973a2545f68f747b9df6ea2c1") -- 难蚌尖塔
-- MAIN APP DEPOTS
addappid(4430471, 1, "3417ad26544f98754707ef1ad54e571579698401f382c0f104fa4ec73de68ff3") -- Depot 4430471
setManifestid(4430471, "842150953738369721", 1326798820)