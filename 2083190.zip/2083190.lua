-- Lua provided by RyzenAPI
-- Game: Game: World Championship Boxing Manager™ 2 Demo

-- MAIN APPLICATION
addappid(2083190)
-- Game: addappid(2083190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083191, 1, "e9acfb603aa662e290a9aa4a90fb2a59feecdd5a3e77825e92b817196d44e190")
