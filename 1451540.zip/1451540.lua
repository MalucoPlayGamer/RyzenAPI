-- Lua provided by RyzenAPI
-- Game: Blade Flash Death

-- MAIN APPLICATION
addappid(1451540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451541, 1, "603a91903cae53743632d64853589f7bf18993ad06d6fac838e101d43e77165c")

