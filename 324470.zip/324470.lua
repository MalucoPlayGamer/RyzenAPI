-- Lua provided by RyzenAPI
-- Game: addappid(324470)

-- MAIN APPLICATION
addappid(324470)

-- MAIN APP DEPOTS / PACKAGES
addappid(324471, 1, "f9ff6da8d56d44bc24eb01da5a6f9eaa19caa0f64fac36e7be08f15d97a9557e")
