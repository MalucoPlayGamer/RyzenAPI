-- Lua provided by RyzenAPI
-- Game: Game: AppID 2989880

-- MAIN APPLICATION
addappid(2989880)
-- Game: addappid(2989880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989881, 1, "9c51f44bcb1031e78d04a8e4b95f0bf0bb4644df69cfb6150227ea84bd30cba6")
addappid(2989882, 1, "ce505763a9f22e8e422c473800ad7b9711661fcd3b3f73704ede3d2d48d7380e")
addappid(2989883, 1, "7d2895eb1feb64c7fd77106911c01459c8ba5adacd44f21cffe38b9fe163c812")
