-- Lua provided by RyzenAPI
-- Game: 2381950

-- MAIN APPLICATION
addappid(2381950)
-- Game: addappid(2381950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381951, 1, "f4d289b87e8e775429fb1febc1042f7666b42d50db09a586771cd0844a9e34a6")
