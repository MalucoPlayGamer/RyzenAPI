-- Lua provided by RyzenAPI 
-- Game: AppID 2381950
addappid(2381950)
addappid(2381951, 1, "f4d289b87e8e775429fb1febc1042f7666b42d50db09a586771cd0844a9e34a6")
