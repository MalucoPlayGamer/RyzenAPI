-- Lua provided by RyzenAPI
-- Game: AppID 1266580

-- MAIN APPLICATION
addappid(1266580)
-- Game: addappid(1266580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266581, 1, "9cfcdb94c29475db9d2b7fb47d07ca3e12cc78146f85e2a03088de018b0c9c3c")
