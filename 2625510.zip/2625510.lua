-- Lua provided by RyzenAPI
-- Game: 2625510

-- MAIN APPLICATION
addappid(2625510)
-- Game: addappid(2625510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625511, 1, "a708aa2063adfad3e6099d80366edf7141f4958e0597bb7dc5f47e05a2684b14")
