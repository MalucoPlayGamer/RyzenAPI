-- Lua provided by RyzenAPI
-- Game: Don't Shout Together

-- MAIN APPLICATION
addappid(2625510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2625511, 1, "a708aa2063adfad3e6099d80366edf7141f4958e0597bb7dc5f47e05a2684b14")

