-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It's a Night Magic Welcome Master Set Vol.05

-- MAIN APPLICATION
addappid(2144620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144621, 1, "25afae4235dc7738113ea977a817ca977bdce649703fbcea3e72414ab3dc5ef7")
addappid(2144622, 1, "2c40530ef51e260e0ea474c1e6a408ca448e447f7c3a7f5f6785bd91e019b949")

