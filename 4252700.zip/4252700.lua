-- 4252700's Lua and Manifest Created by Hubcap Manifest
-- Archon Soul
-- Created: July 30, 2026 at 00:18:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4252700) -- Archon Soul
-- MAIN APP DEPOTS
addappid(4252701, 1, "a367e21b81febcf5051385a63e462c19eda79b9dd10c08ac569794a248ee0b94") -- Depot 4252701
setManifestid(4252701, "7614264220648980494", 2481362079)
addappid(4252702, 1, "2d5a90298f783981557fc97c467e6b208ae8d3dd9135f28ac134fdc554663661") -- Depot 4252702
setManifestid(4252702, "1556264547628004007", 2464712678)
addappid(4252703, 1, "7fe8dac84bda8d7e51943b72a9de8e63a70319b85ed2072c5774878d0841c81a") -- Depot 4252703
setManifestid(4252703, "2515152801313900717", 2479718031)
-- DLCS WITH DEDICATED DEPOTS
-- Archon Soul - Supporter Pack (AppID: 4981820)
addappid(4981820)
addappid(4981820, 1, "f670ea84488391e1e3daece93d62826ba9e8fdcb8c012214f745dcb460de296a") -- Archon Soul - Supporter Pack - Depot 4981820
setManifestid(4981820, "2842220353852282501", 637562666)