-- Lua provided by RyzenAPI
-- Game: addappid(2103180)

-- MAIN APPLICATION
addappid(2103180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103181, 1, "c8e898db8b99e63957faab98316aadecc208d9c9a1c34334d9a25514beae5b0d")
