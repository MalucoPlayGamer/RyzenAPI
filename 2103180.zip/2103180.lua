-- Lua provided by RyzenAPI
-- Game: Ignite

-- MAIN APPLICATION
addappid(2103180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103181, 1, "c8e898db8b99e63957faab98316aadecc208d9c9a1c34334d9a25514beae5b0d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
