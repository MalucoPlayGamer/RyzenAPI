-- Lua provided by RyzenAPI
-- Game: Mira and the Mysteries of Alchemy

-- MAIN APPLICATION
addappid(1328920)
-- Game: addappid(1328920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328921, 1, "cddaeee3f656f2dbc2a0b9ede20216bc17fe2053e2b5644535f551ec2d171f7c")
addappid(1328922, 1, "de898efcd7256e9f6771296b3bb9dae0a6094cf1d7aa9c69e3b62dee01ed769b")
addappid(1328923, 1, "c30c7169795ac8894b765032d753943490039f1b63dfc2caf729dbdab531e4c6")
