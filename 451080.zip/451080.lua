-- Lua provided by RyzenAPI
-- Game: addappid(451080)

-- MAIN APPLICATION
addappid(451080)

-- MAIN APP DEPOTS / PACKAGES
addappid(451081, 1, "c78f6ea7b08cd8aeacc459137765331af3f5bef18103b256ff76581c6af33f1e")
