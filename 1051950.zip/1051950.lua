-- Lua provided by RyzenAPI
-- Game: 1051950

-- MAIN APPLICATION
addappid(1051950)
-- Game: addappid(1051950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051951, 1, "4b5560557352fedef56f33773a4a588edf481b6c25247e608e8fed4696988b5b")
