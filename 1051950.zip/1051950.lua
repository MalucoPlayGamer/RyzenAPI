-- Lua provided by RyzenAPI
-- Game: AppID 1051950

-- MAIN APPLICATION
addappid(1051950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051951, 1, "4b5560557352fedef56f33773a4a588edf481b6c25247e608e8fed4696988b5b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
