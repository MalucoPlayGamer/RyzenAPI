-- Lua provided by RyzenAPI
-- Game: addappid(1746500)

-- MAIN APPLICATION
addappid(1746500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746501, 1, "a362be0db7f78b396567104dd8bceb907302b07b3ae31ad827de79d2df99ded5")
