-- Lua provided by RyzenAPI
-- Game: Guilty Loving Boxing

-- MAIN APPLICATION
addappid(2597300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597301, 1, "5712b9c216c7324d6cd1991074a2f1a53d0ff0634c35c5e7e213e9bce2c3139e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
