-- Lua provided by RyzenAPI
-- Game: Game: Guilty Loving Boxing

-- MAIN APPLICATION
addappid(2597300)
-- Game: addappid(2597300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597301, 1, "5712b9c216c7324d6cd1991074a2f1a53d0ff0634c35c5e7e213e9bce2c3139e")
