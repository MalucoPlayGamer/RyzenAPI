-- Lua provided by RyzenAPI
-- Game: addappid(3389710)

-- MAIN APPLICATION
addappid(3389710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389711, 1, "ca9eff214156c35df0314779a5a150ec7ffe3f559950ac1bf4bd54d9935e9976")
