-- Lua provided by RyzenAPI
-- Game: Game: Hollow Mind: The Lost Puppy

-- MAIN APPLICATION
addappid(1396630)
-- Game: addappid(1396630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396631, 1, "b7f6af10a5753adf6f81e1b7b7e6f41c582c6deb87d5546788941f66c555fbaf")
