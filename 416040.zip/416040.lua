-- Lua provided by RyzenAPI
-- Game: CLASH

-- MAIN APPLICATION
addappid(416040)
addappid(564260)

-- MAIN APP DEPOTS / PACKAGES
addappid(416041, 1, "7ccd81dd8c12d50fec06905f56c5721520495e673bd9bc1546e9ff23b3ec9bab")
