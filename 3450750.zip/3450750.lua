-- Lua provided by RyzenAPI
-- Game: 3450750

-- MAIN APPLICATION
addappid(3450750)
-- Game: addappid(3450750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3450751, 1, "ffbd35d5a62b93eda8a953d23a1e5dbe03ae37033c2462cebf5f8ed6ad46a81e")
