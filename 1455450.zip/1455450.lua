-- Lua provided by RyzenAPI
-- Game: To Hell With The Ugly

-- MAIN APPLICATION
addappid(1455450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455451, 1, "21b814b25aaa0ba55ff178915412d397d17f41de32f59feea38f0a59488f51b3")
addappid(1455452, 1, "9c00b9eac8bb2a273527fd96314f001c2da2d591a7bbce43cdbfb31346073bb1")
addappid(1455453, 1, "7b66841f6696aafd5aa0aa8143bc19aa5d52e6f8a85605229371e65f836a6ad3")
