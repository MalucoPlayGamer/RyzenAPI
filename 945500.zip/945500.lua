-- Lua provided by RyzenAPI
-- Game: AppID 945500

-- MAIN APPLICATION
addappid(945500)

-- MAIN APP DEPOTS / PACKAGES
addappid(945501, 1, "1094a44e9b107f976978720b4227ab68b86b5b736b3bbdeb1508390a744ecebb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
