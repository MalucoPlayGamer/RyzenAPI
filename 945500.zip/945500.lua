-- Lua provided by RyzenAPI
-- Game: Game: AppID 945500

-- MAIN APPLICATION
addappid(945500)
-- Game: addappid(945500)

-- MAIN APP DEPOTS / PACKAGES
addappid(945501, 1, "1094a44e9b107f976978720b4227ab68b86b5b736b3bbdeb1508390a744ecebb")
