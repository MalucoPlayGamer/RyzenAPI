-- Lua provided by RyzenAPI
-- Game: Archers

-- MAIN APPLICATION
addappid(756860)

-- MAIN APP DEPOTS / PACKAGES
addappid(756861,0,"29d926969412457c5a73d1ad065b2c9c71710aa15b9a9700445b7713b1f0decc")

