-- Lua provided by RyzenAPI
-- Game: Beat Saber: Lady Gaga - 'Alejandro'

-- MAIN APPLICATION
addappid(1812880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812880,0,"d680875970c51a97f441f2405483c4f91d4a6aee6f5c93d43f85d5478a47cdca")
