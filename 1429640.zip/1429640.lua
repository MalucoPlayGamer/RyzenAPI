-- Lua provided by RyzenAPI
-- Game: addappid(1429640)

-- MAIN APPLICATION
addappid(1429640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429641, 1, "24940ec7be91b13b2041487fc6228e20ae58ebd20d131501d83c4ed7b39ee576")
