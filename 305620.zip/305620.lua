-- Lua provided by RyzenAPI
-- Game: The Long Dark

-- MAIN APPLICATION
addappid(305620)
addappid(2091330)
addappid(2095000)

-- MAIN APP DEPOTS / PACKAGES
addappid(305621, 1, "2a658a052de2d030f6031e4aa4835b7b12b6646cb7142fde7f0216b06b9b3d85")
addappid(305622, 1, "973dd3d0c6c26bcaaabe742bd507c7d2711d69bbc1f1f5c21650629e93121eca")
addappid(305623, 1, "9960f03341efd0f41aa06b12b9df8c42a592b5d1385f29a87531bec7c84709d0")
addappid(2091331, 0, "ef5d6edc9a2c7de7d0c7e187558780cc5724114441d0e5cfab386460042b0975")
addappid(2091332, 0, "71e3e4cc7b1539fd8cf9f21f16c4c191d9927f04656a51ab06a8e03051a4b612")
addappid(2091333, 0, "9cdb1d532c9c2a2315abf67c51cc52d39725194ee239616f8cb38ad89e8a697a")
addappid(2095001, 0, "c38c5ee851fd90ea714284f31e69e3adde2d17018bef93398aba3cc91cb7548b")
addappid(2095002, 0, "1eddf8e27184634ad945b1491c042d71f3a157e0df86f36dbe724ceb3333f8b6")
addappid(2095003, 0, "a223ad812dca8bccde9bc8fd91c2baa033dc7b67befff5ea497641a6c24b351f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
