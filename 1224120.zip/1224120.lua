-- Lua provided by RyzenAPI
-- Game: Jerking Off In Class Simulator

-- MAIN APPLICATION
addappid(1224120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224121, 1, "44640866ce8772968a1f1e6139a4de483b2176cfda7a7ccae52e5ecb4941ab7b")
