-- Lua provided by RyzenAPI
-- Game: Game: Nanomon Virtual Pet

-- MAIN APPLICATION
addappid(1498060)
-- Game: addappid(1498060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498061, 1, "a2796971f7d00cd69e49721f0a32ce424eaa71901dfe542fc84eac555d942666")
