-- Lua provided by RyzenAPI
-- Game: Game: TouHou Music Recording

-- MAIN APPLICATION
addappid(1744750)
-- Game: addappid(1744750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744751, 1, "cbd32ec185da85b5284c98364e69a6038896d80e6694080d647ff33e49d8eb99")
