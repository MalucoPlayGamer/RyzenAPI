-- Lua provided by RyzenAPI
-- Game: 2012000

-- MAIN APPLICATION
addappid(2012000)
-- Game: addappid(2012000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012001, 1, "a9c6ef965ab6ac8f63f690ea962e26e0d666dcebc0acd7be4fa216724a0817b0")
