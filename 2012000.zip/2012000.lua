-- Lua provided by RyzenAPI
-- Game: MY Neko Waifu!

-- MAIN APPLICATION
addappid(2012000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012001, 1, "a9c6ef965ab6ac8f63f690ea962e26e0d666dcebc0acd7be4fa216724a0817b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
