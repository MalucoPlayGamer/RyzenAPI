-- Lua provided by SkyAPI 
-- Game: SGS Fall Weiss
addappid(1747580)
addappid(1747581, 1, "eb913929c0eb3f2c2c12876ac90a9f889fa50b8c57c50fb4670bf0c1f56a0562")
addappid(1747583, 1, "201f91d0831df46d681afb383b73e18a97b3a3b8ed7ca3f5b0ebd9debd44524e")
