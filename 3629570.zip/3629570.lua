-- Lua provided by RyzenAPI
-- Game: 3629570

-- MAIN APPLICATION
addappid(3629570)
-- Game: addappid(3629570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629571, 1, "9d802faee20203e637595f26c7a5bd7faa1faa21b3844c45e1499e6c824051f2")
