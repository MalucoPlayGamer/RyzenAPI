-- Lua provided by RyzenAPI
-- Game: Red Core Division

-- MAIN APPLICATION
addappid(3629570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629571, 1, "9d802faee20203e637595f26c7a5bd7faa1faa21b3844c45e1499e6c824051f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
