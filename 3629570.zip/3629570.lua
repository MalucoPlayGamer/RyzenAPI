-- Lua provided by SkyAPI 
-- Game: Red Core Division
addappid(3629570)
addappid(3629571, 1, "9d802faee20203e637595f26c7a5bd7faa1faa21b3844c45e1499e6c824051f2")
