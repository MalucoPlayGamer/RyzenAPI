-- Lua provided by SkyAPI 
-- Game: The Fear Island
addappid(1655050)
addappid(1655051, 1, "02c4fe0140d687d678086716cfaf158d95debe7e2d39cb4f37f18c68760feeff")
