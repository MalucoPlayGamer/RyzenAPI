-- Lua provided by RyzenAPI
-- Game: Game: The Fear Island

-- MAIN APPLICATION
addappid(1655050)
-- Game: addappid(1655050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655051, 1, "02c4fe0140d687d678086716cfaf158d95debe7e2d39cb4f37f18c68760feeff")
