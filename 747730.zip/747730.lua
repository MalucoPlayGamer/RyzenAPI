-- Lua provided by RyzenAPI
-- Game: Operation Red Dragon

-- MAIN APPLICATION
addappid(747730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(747731, 1, "f2d55a79dea1010d93fd5a5a20f843b2123cedb2980cfffb5c41c4d03a600791")
addappid(747733, 1, "846cd65db92b99ee57e67144b5106c7649aee1057d32e24fdfe4815b1fdd16d8")

