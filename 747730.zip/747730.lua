-- Lua provided by RyzenAPI
-- Game: addappid(747730)

-- MAIN APPLICATION
addappid(747730)

-- MAIN APP DEPOTS / PACKAGES
addappid(747731, 1, "f2d55a79dea1010d93fd5a5a20f843b2123cedb2980cfffb5c41c4d03a600791")
addappid(747733, 1, "846cd65db92b99ee57e67144b5106c7649aee1057d32e24fdfe4815b1fdd16d8")
