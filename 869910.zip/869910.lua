-- Lua provided by RyzenAPI
-- Game: AmazeBowl

-- MAIN APPLICATION
addappid(869910)

-- MAIN APP DEPOTS / PACKAGES
addappid(869911,0,"9b2c5c2eb0860eb2e5dfac061198f90fef35b2559a91683bf7aee6acbdfde935")

