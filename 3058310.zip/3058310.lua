-- Lua provided by RyzenAPI
-- Game: 3058310

-- MAIN APPLICATION
addappid(3058310)
-- Game: addappid(3058310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058311, 1, "36d8a95dbf3582b061013dde99a98a774dd36e6802fd83cc88441356c0cacc55")
