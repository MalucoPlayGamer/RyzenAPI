-- Lua provided by RyzenAPI
-- Game: 《废土快递》死者国度扩展包

-- MAIN APPLICATION
addappid(2336570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336570,0,"531355f6c470949938aeab2e80e226749a25ed0d7d98d71156b2ebaf4032246a")

