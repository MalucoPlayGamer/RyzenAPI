-- Lua provided by RyzenAPI
-- Game: Nonogram Kingdom

-- MAIN APPLICATION
addappid(1909240)
-- Game: addappid(1909240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909241, 1, "3f6daccdb0ba1e124ddb6b56a866950ad930c2dc3b41ad1f6d4cb0b169890e24")
