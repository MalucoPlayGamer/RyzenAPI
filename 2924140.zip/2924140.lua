-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2924140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924143,0,"7aff9f889d8527a7470b7da00729488a02e22e196ac88cc56f13e9c5f73ff533")
