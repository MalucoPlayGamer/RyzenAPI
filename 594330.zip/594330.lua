-- Lua provided by RyzenAPI
-- Game: Game: AppID 594330

-- MAIN APPLICATION
addappid(594330)
-- Game: addappid(594330)

-- MAIN APP DEPOTS / PACKAGES
addappid(594331, 1, "bd25107db41b4499b57e397d12db225a8488620327bad7ef15021a9e0294cde9")
addappid(594333, 1, "a6a275dec1c322efa0cc50745375764c4f89ccd32a2ed30809681bdadd6a51a6")
addappid(938721, 0, "237b39e0b35e141f64b5354d0ade640791de2d73b268d60eaed3cec81254a6d9")
