-- Lua provided by RyzenAPI
-- Game: 3361280

-- MAIN APPLICATION
addappid(3361280)
-- Game: addappid(3361280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361281, 1, "54681b8a1e0a6d5db1cb8bd224c61f315b937ac18596e8cdda768d2654b23774")
