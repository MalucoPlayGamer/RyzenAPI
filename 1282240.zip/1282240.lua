-- Lua provided by RyzenAPI
-- Game: 泡泡三国

-- MAIN APPLICATION
addappid(1282240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282241, 1, "50324ad09ec13a2997ac42181f2d61ee23ad6302e0f8f04415d559096ead20c8")

