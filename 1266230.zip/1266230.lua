-- Lua provided by RyzenAPI
-- Game: AppID 1266230

-- MAIN APPLICATION
addappid(1266230)
-- Game: addappid(1266230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266231, 1, "c7601c2af958b4a6373a667c50f427dba5c0cff3e65b3bf4d955a094fa2544c3")
addappid(1266232, 1, "63486f5485202dd5e264b689d2c1e2cd2bd29af3721f96bbce9c5c25d77bf474")
