-- Lua provided by RyzenAPI
-- Game: 521350

-- MAIN APPLICATION
addappid(521350)
-- Game: addappid(521350)

-- MAIN APP DEPOTS / PACKAGES
addappid(521351, 1, "709e2cc4806c76e7257f2cc2fbf012f4242b798c35378af6f33c269ce15462f7")
