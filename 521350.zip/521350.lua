-- Lua provided by RyzenAPI
-- Game: Use Your Words

-- MAIN APPLICATION
addappid(521350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(521351, 1, "709e2cc4806c76e7257f2cc2fbf012f4242b798c35378af6f33c269ce15462f7")

