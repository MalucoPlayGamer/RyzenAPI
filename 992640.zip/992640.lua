-- Lua provided by RyzenAPI
-- Game: AppID 992640

-- MAIN APPLICATION
addappid(992640)

-- MAIN APP DEPOTS / PACKAGES
addappid(992641, 1, "13e87245ca9eaa5ab116b44dd47f737332b0ebb1ff643cde9ba02bf79865b25f")

