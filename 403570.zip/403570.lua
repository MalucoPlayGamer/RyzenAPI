-- Lua provided by RyzenAPI
-- Game: AppID 403570

-- MAIN APPLICATION
addappid(403570)
-- Game: addappid(403570)

-- MAIN APP DEPOTS / PACKAGES
addappid(403571, 1, "78ebd994cbafdd1f1c61ab9c4475ec554bea47b3c00b772ff76bc2ba9fc09c58")
