-- Lua provided by RyzenAPI
-- Game: Mandragora: Whispers of the Witch Tree

-- MAIN APPLICATION
addappid(1721060)
addappid(3352590)
addappid(3352600)
addappid(3352610)
addappid(3352620)
addappid(3352630)
addappid(3352640)
addappid(3352650)
addappid(3954740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1721061, 1, "306438da4a61fac40cb7311f983967fcfca6258b8bd766b48605199f1c19c37c")
addappid(3352660, 0, "45bdc1425936ffac9f364dbfe269a725fe18985b08b48927638227e157786a39")

