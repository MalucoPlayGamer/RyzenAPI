-- Lua provided by RyzenAPI
-- Game: Shut Up, Rabbit!

-- MAIN APPLICATION
addappid(2566160)
-- Game: addappid(2566160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566161, 1, "712d0d2bc4dc3161d75d11763f67dba64b135d5adbc66bf519ba85ae37893d88")
