-- Lua provided by RyzenAPI
-- Game: Game: Sorcery! Part 4

-- MAIN APPLICATION
addappid(504800)
-- Game: addappid(504800)

-- MAIN APP DEPOTS / PACKAGES
addappid(504801, 1, "ae996b80020f9204107162531331e433db06ef77ddcf431fb19bafbd4412a340")
