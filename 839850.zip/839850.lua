-- Lua provided by RyzenAPI
-- Game: Lenin - The Lion

-- MAIN APPLICATION
addappid(839850)

-- MAIN APP DEPOTS / PACKAGES
addappid(839851,0,"d30e766bc235b4ca2899257510edec0f805e352fd2fd0aaad946858fdd474789")
addappid(839852,0,"0ca1c05e1b9ffb3645b5069e0ac92676f0d01f31ec95a43a92b615cebb6e1a31")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1157210)
addappid(3416610)
