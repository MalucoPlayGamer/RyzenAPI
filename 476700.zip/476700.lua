-- Lua provided by RyzenAPI
-- Game: Island 359™

-- MAIN APPLICATION
addappid(476700)
-- Game: addappid(476700)

-- MAIN APP DEPOTS / PACKAGES
addappid(476701, 1, "4164c804791fcb733b9e390058a494afd84d574fc0f5f89591529b402d172fb6")
