-- Lua provided by RyzenAPI
-- Game: Throw Bro

-- MAIN APPLICATION
addappid(2994950)
-- Game: addappid(2994950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994951, 1, "6a0e2aadfe4203ce73e0b0a89d5f006648a96f60e566596f742bce9bd0694478")
