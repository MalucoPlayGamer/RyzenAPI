-- Lua provided by RyzenAPI
-- Game: addappid(1487520)

-- MAIN APPLICATION
addappid(1487520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487521, 1, "3485e503737308f7970d469dea253da53d22099a5bb2d2db62daa0341f14be8b")
