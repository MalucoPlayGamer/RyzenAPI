-- Lua provided by RyzenAPI
-- Game: 3018830

-- MAIN APPLICATION
addappid(3018830)
-- Game: addappid(3018830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3018831, 1, "e2b9cdbd1788287ddd7793c4194ba2ceaa42739c327e4c6ae30ec792f9b3491f")
