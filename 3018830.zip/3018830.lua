-- Lua provided by SkyAPI 
-- Game: One Night With Kawaii
addappid(3018830)
addappid(3018831, 1, "e2b9cdbd1788287ddd7793c4194ba2ceaa42739c327e4c6ae30ec792f9b3491f")
