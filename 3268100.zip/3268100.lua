-- Lua provided by RyzenAPI
-- Game: Game: AppID 3268100

-- MAIN APPLICATION
addappid(3268100)
-- Game: addappid(3268100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3268101, 1, "e18fa82c012de75adb0a9a3ee036a0b17f74ef3d3bedb89b5d17783df18fab48")
