-- Lua provided by RyzenAPI 
-- Game: The Shell Part III: Paradiso
addappid(3296790)
addappid(3296791, 1, "0126e59b12d307e4f79210e4b20eec8a4d13dbc80352156b731b6c63131e5a92")
