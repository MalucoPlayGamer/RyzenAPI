-- Lua provided by RyzenAPI
-- Game: The Shell Part III: Paradiso

-- MAIN APPLICATION
addappid(3296790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296791, 1, "0126e59b12d307e4f79210e4b20eec8a4d13dbc80352156b731b6c63131e5a92")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
