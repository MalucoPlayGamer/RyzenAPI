-- Lua provided by RyzenAPI
-- Game: Game: Fantasy Map Simulator

-- MAIN APPLICATION
addappid(3035500)
-- Game: addappid(3035500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035501, 1, "94673b1ae3605b9caf7d167097a8ff459dde31b918ffd8d5c85f2187001485d4")
