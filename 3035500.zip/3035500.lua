-- Lua provided by RyzenAPI
-- Game: Fantasy Map Simulator

-- MAIN APPLICATION
addappid(3035500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3035501, 1, "94673b1ae3605b9caf7d167097a8ff459dde31b918ffd8d5c85f2187001485d4")

