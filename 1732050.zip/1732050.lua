-- Lua provided by RyzenAPI
-- Game: Game: Love Season

-- MAIN APPLICATION
addappid(1732050)
-- Game: addappid(1732050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732051, 1, "d124bc1fd2368dd4caffebc169d05487498694f3f0543fd57119039ab8868f91")
addappid(1910070, 0, "f39e93938fba9c803998eaf664694762434a36d8abf850a2af1c71e32d0825dd")
addappid(2084730, 0, "543a28abadc6efe223b81368d1bdf3d5773f458fd69ae955f9154bfddcb6966c")
