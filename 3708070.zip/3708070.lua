-- Lua provided by RyzenAPI
-- Game: Campsite Hustle! - Management Simulator

-- MAIN APPLICATION
addappid(3708070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3708071,0,"9099b3749b3318ba98a2c79c4a2974b7efa5e3efe8c55c87899841758e01b489")

