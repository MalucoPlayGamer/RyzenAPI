-- Lua provided by RyzenAPI
-- Game: AppID 1886060

-- MAIN APPLICATION
addappid(1886060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1886061, 1, "382acc4f48b3358eb85f2acf2c8f6d20dce6c37dfc6ca474bf66c1e506fe4455")
