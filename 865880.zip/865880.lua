-- Lua provided by RyzenAPI
-- Game: 天岚行 - Through the Mist and Sky

-- MAIN APPLICATION
addappid(865880)
addappid(865890)

