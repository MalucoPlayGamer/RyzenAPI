-- Lua provided by RyzenAPI
-- Game: 天岚行 - Through the Mist and Sky

-- MAIN APPLICATION
addappid(865880)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(865890)
