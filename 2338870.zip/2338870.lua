-- Lua provided by RyzenAPI
-- Game: Game: Detective Demo

-- MAIN APPLICATION
addappid(2338870)
-- Game: addappid(2338870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338871, 1, "b46b1a8360dd244cbc53031ce2c17b0dbcfc9e029152960f8627e5656b2b1688")
