-- Lua provided by RyzenAPI 
-- Game: Detective Demo
addappid(2338870)
addappid(2338871, 1, "b46b1a8360dd244cbc53031ce2c17b0dbcfc9e029152960f8627e5656b2b1688")
