-- Lua provided by RyzenAPI
-- Game: 608110

-- MAIN APPLICATION
addappid(608110)
-- Game: addappid(608110)

-- MAIN APP DEPOTS / PACKAGES
addappid(608111, 1, "4c9bcd9222d04de7cb6dd29e7bca963cddb95b7cb665aac42e9a27dfecdb8854")
