-- Lua provided by RyzenAPI
-- Game: Hot And Lovely XXII

-- MAIN APPLICATION
addappid(3088550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088551, 1, "c298f1a345b5cc53260e60d0b799f48ebb7ef892c43f9ef7cbf2109155cc40f7")

