-- Lua provided by RyzenAPI
-- Game: Game: AppID 370550

-- MAIN APPLICATION
addappid(370550)
-- Game: addappid(370550)

-- MAIN APP DEPOTS / PACKAGES
addappid(370551, 1, "f846f79f7a101def47ad435ee812d0b1cb13b284a187c8172a289a4c8885a6c1")
