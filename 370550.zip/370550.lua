-- Lua provided by RyzenAPI
-- Game: AppID 370550

-- MAIN APPLICATION
addappid(370550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(370551, 1, "f846f79f7a101def47ad435ee812d0b1cb13b284a187c8172a289a4c8885a6c1")

