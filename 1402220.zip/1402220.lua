-- Lua provided by RyzenAPI
-- Game: 1402220

-- MAIN APPLICATION
addappid(1402220)
-- Game: addappid(1402220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402221, 1, "5e65bb7bd10020059951b11a09a6322dec1ba2168ff7842d12d8d36dcb75506d")
