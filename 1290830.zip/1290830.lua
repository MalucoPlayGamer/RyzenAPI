-- Lua provided by RyzenAPI
-- Game: 逃出图书馆(Escape from Library)

-- MAIN APPLICATION
addappid(1290830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290831, 1, "620014855f11377b28d53b8bab8cff02edc9446f55e85d16e57b4095bbfcaa9e")

