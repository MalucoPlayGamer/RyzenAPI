-- Lua provided by RyzenAPI
-- Game: The Maze Survivor: The 9th Entrants

-- MAIN APPLICATION
addappid(2812670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812671, 1, "03b7c3e2e588d243da82bc526fad17c6bc8fc260b92e7723e81ae3e88daa7b3a")

