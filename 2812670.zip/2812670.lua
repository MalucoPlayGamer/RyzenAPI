-- Lua provided by RyzenAPI
-- Game: The Maze Survivor: The 9th Entrants

-- MAIN APPLICATION
addappid(2812670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2812671, 1, "03b7c3e2e588d243da82bc526fad17c6bc8fc260b92e7723e81ae3e88daa7b3a")

