-- Lua provided by RyzenAPI
-- Game: 310

-- MAIN APPLICATION
addappid(310)
-- Game: addappid(310)

-- MAIN APP DEPOTS / PACKAGES
addappid(311, 1, "be683fd87ff0138df1ab70d945653b79c84829d6af4c3b5e43f1a4afe6c1b9e8")
addappid(1004, 0, "f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
