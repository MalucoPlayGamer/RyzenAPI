-- Lua provided by RyzenAPI
-- Game: 暗夜时代  Age of Dark

-- MAIN APPLICATION
addappid(3673550)
-- Game: addappid(3673550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3673551, 1, "97bda03229e3c89c0fc9ecfdd9be89c98c6dda36d7d371e5fae972e33830387b")
