-- Lua provided by RyzenAPI
-- Game: Game: Terra Memoria

-- MAIN APPLICATION
addappid(1912750)
-- Game: addappid(1912750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912751, 1, "244027c934f4d4c69edd854d1bb2be2929f71873ebc6d0e567a3aeb43f8a319d")
addappid(1912752, 1, "dbccbd4eb010d236287b4d0aa7339f1eab1c3f0a6c2b75750f90927f9e7c7122")
addappid(2848870, 0, "3abf934e923319e27f1e07ba89f65129da8a9be7957e6f5a7bc8b6a2b468c743")
