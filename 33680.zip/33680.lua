-- Lua provided by RyzenAPI
-- Game: Eversion

-- MAIN APPLICATION
addappid(33680)

-- MAIN APP DEPOTS / PACKAGES
addappid(33681, 1, "5248db2c07c996bfd0b10d118d4fe57e59ef0692e05b3c679b02eb3489debf39")
addappid(33682, 1, "9a34bdf2cd01afc6add48cca84ed91b73706176a667c9981b87ccce247bdd608")
addappid(33683, 1, "56b09a3d63f2880b03ba29534535aefb579f33fa15ebd896446bc4603646c0c6")
