-- Lua provided by RyzenAPI
-- Game: AppID 717050

-- MAIN APPLICATION
addappid(717050)

-- MAIN APP DEPOTS / PACKAGES
addappid(717051, 1, "a9d3ee645ddf91d84d1f5b39d7229aea224e7cd6e3859ed135a88dcb2e5ae91b")
