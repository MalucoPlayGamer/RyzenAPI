-- Lua provided by RyzenAPI
-- Game: Aliens vs. Predator™

-- MAIN APPLICATION
addappid(10680)

-- MAIN APP DEPOTS / PACKAGES
addappid(10681, 1, "e5f10e7978f6fa4e0a94de2f6bc517a3b83341b9d03be28b9ffcec182065bf86")
addappid(10682, 1, "c535dbdc5d6dce3d9c88fba98ba1402cea72b32c23119ab33901ddf461783160")
addappid(10683, 1, "143eaf0653b5d30796bfc2c9850fa2671172015cac11a363364257d795aa5c09")
addappid(10684, 1, "bb0af99c48e29e60891211ae517d09e1e716013f07060dc9bfc51d22ab4fecbe")
addappid(10685, 1, "c59dab85a643152546281817710447bb7cf04f0fc53ea9852b3aa29693dfe298")
addappid(10686, 1, "2dc7ee5c7256cfaded480710147226a5f0e5b14728b8a185e35dab5c16dc0af3")
addappid(10687, 1, "f1874b33bb84e13a1736df5f9116c87f9a43f9e1d7bf7cf4698a351f3296174f")
addappid(10688, 1, "328f68b56dd43362dc669b187889176fc843a1388d9ec69bb5d9569c3fdefd7e")
addappid(10689, 1, "d31668e2e001984b488dae06ff7dd69f35c28692ca21feb4c7054b8d6edb69d3")
addappid(10695, 1, "1256afb7b46e18e39a1045641f5e1ccd468d5be8d0bc43930ac80e654d3a40d4")
addappid(10697, 1, "a8a65c4cd51acd106bcdb99a1a7209e320c016385bb4afdb442833da1d2395aa")
addappid(34241, 0, "72bfa9f9508343f9810b654d17ccb493fd09011f38dd5ad3be02237c4a024bbb")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(10696)
