-- Lua provided by RyzenAPI
-- Game: AppID 2275640

-- MAIN APPLICATION
addappid(2275640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275641, 1, "a96f3d0d443c1662b38b40915adf2e3ada7cd61d777e0b8d71d62dcc32c3e105")

