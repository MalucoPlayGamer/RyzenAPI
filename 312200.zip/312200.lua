-- Lua provided by RyzenAPI
-- Game: AppID 312200

-- MAIN APPLICATION
addappid(312200)

-- MAIN APP DEPOTS / PACKAGES
addappid(312201, 1, "c140804a963f7b0a7211923ea963c92f2c0ae36957f00588c90c067b58ed146c")
addappid(312202, 1, "86b7d6c78eef2a3622d4a46cf34dcb40140484ad6f81865e33c017ed1edf83c8")
addappid(312203, 1, "4e0908b76debb249c97043810474e0e2145ee9276ce8ff9f0b9bff7bf808f230")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
