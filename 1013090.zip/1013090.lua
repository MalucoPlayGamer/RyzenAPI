-- Lua provided by RyzenAPI
-- Game: ISLAND Soundtrack

-- MAIN APPLICATION
addappid(1013090)
addappid(1013091)
addappid(1013093)
-- Game: addappid(1013090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013090,0,"9d7015042eb52f51b59a0a4da4abaf7520bbd3cca257a1701845c8eea4a18c3b")
addappid(1013092,0,"65d4f0528023666328d4534f6097e0638fcf600a43d32157790f9ca0e985acdd")
