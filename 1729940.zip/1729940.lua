-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1729940)
addappid(1729941)
addappid(1729942)
addappid(1729943)
addappid(1729944)
addappid(1729945)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729946,0,"06fa33562d65c52f1e8fa78f6f3ea9692b09f2fca38368f7c2d660f908bad72b")

