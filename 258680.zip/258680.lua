-- Lua provided by RyzenAPI
-- Game: 258680

-- MAIN APPLICATION
addappid(258680)
-- Game: addappid(258680)

-- MAIN APP DEPOTS / PACKAGES
addappid(258681, 1, "68604f993713e43123555bf8a7fdc3d128a4f5ac90b79bab24c2ac3f67e81810")
