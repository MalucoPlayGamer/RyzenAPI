-- Lua provided by RyzenAPI
-- Game: addappid(1011740)

-- MAIN APPLICATION
addappid(1011740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011742,0,"f4be701f39c754b71f71b38211dcb797d105fa5b1e4dbcb3cd7159cd6bca5e3a")
