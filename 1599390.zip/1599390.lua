-- Lua provided by RyzenAPI
-- Game: Word Hunt Fever

-- MAIN APPLICATION
addappid(1599390)
-- Game: addappid(1599390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599391, 1, "77f15ca5339a710bb75abde2e2adc85b68cc374769f24dae56d796749d9dcb6e")
addappid(1599392, 1, "b8b9ce472389b9d798537780d9530450cba004e51c58385606863ae1b7f7e2cd")
