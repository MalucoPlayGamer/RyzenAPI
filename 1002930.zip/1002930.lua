-- Lua provided by RyzenAPI
-- Game: AppID 1002930

-- MAIN APPLICATION
addappid(1002930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002931, 1, "96bbff3db7a28b9307b3f2e009a5a2851652e7d9cb4e3ccbdf2200f902aa8ab7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
