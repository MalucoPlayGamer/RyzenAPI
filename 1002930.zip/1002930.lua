-- Lua provided by RyzenAPI
-- Game: AppID 1002930

-- MAIN APPLICATION
addappid(1002930)
-- Game: addappid(1002930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002931, 1, "96bbff3db7a28b9307b3f2e009a5a2851652e7d9cb4e3ccbdf2200f902aa8ab7")
