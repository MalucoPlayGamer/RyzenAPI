-- Lua provided by RyzenAPI
-- Game: AppID 1266140

-- MAIN APPLICATION
addappid(1266140)
-- Game: addappid(1266140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266141, 1, "002d5d4596b358236463f6c0a3a6d98f97b2e7ecd72ec28aa9335be6fdb49616")
