-- Lua provided by RyzenAPI
-- Game: Hotel Remorse

-- MAIN APPLICATION
addappid(898160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(898161, 1, "ea5567477789b5e4a4a5437a40cc395bc8fcd19f85e7918ffbf8bfea7d9666f2")

