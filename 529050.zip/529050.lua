-- Lua provided by RyzenAPI
-- Game: 529050

-- MAIN APPLICATION
addappid(529050)
-- Game: addappid(529050)

-- MAIN APP DEPOTS / PACKAGES
addappid(529051, 1, "a29769755a350fd4cfda399c36256912e9572d43f4d35152b662b24bc9f028be")
