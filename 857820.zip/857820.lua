-- Lua provided by RyzenAPI
-- Game: Colorcers

-- MAIN APPLICATION
addappid(857820)

-- MAIN APP DEPOTS / PACKAGES
addappid(857821, 1, "fc121a63ae1d4257243961fee6e15b4b56e58906408feace44813ca920b5f513")

