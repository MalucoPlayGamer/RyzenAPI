-- Lua provided by RyzenAPI
-- Game: 786410

-- MAIN APPLICATION
addappid(786410)
-- Game: addappid(786410)

-- MAIN APP DEPOTS / PACKAGES
addappid(786411, 1, "f79451f69c6fee4fc801f3627bb7b04f221d08b9187fdcd980886b61965163db")
