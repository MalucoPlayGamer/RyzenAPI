-- Lua provided by RyzenAPI
-- Game: 571870

-- MAIN APPLICATION
addappid(571870)

-- MAIN APP DEPOTS / PACKAGES
addappid(571872,0,"2f25b10e87640a1280d38a62d2ef360c3bc3cb911a1fde754dec29c6c95781d7")
addappid(571873,0,"ab1fd59398d1b6bb804bc50c893d84a43cd956a279ae60884b37bb1aeb7abc83")
addappid(571874,0,"dad656782ed12060cc2f2ebeda58cd5f01a92f0f92b9a7cbf4892de963aa3dbd")
