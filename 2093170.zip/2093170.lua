-- Lua provided by RyzenAPI
-- Game: 2093170

-- MAIN APPLICATION
addappid(2093170)
-- Game: addappid(2093170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093171, 1, "32a8219f1b99912f4bdd0425cc1d61ea1e1ed3852fc8a4bbdd3110573a298f87")
