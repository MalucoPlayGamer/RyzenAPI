-- Lua provided by RyzenAPI
-- Game: Game: The Pegasus Expedition

-- MAIN APPLICATION
addappid(1521070)
-- Game: addappid(1521070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521071, 1, "8f76773f0e7e283836a1885f8d45acc7487c1dba017803d7e8e0cc98e4922a1c")
addappid(2467680, 0, "890bde373f160a00253ece51780d4b4729b7e52bfeff35484c32a53387be13e3")
