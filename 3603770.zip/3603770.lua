-- Lua provided by RyzenAPI
-- Game: Through the Wall

-- MAIN APPLICATION
addappid(3603770)
-- Game: addappid(3603770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3603771, 1, "1ae08b3741197ad878828c3336d8743b6f9b10e394a74630bb056edcd9e778dc")
