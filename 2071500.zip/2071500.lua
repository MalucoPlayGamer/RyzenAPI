-- Lua provided by SkyAPI 
-- Game: Islands of Insight
addappid(2071500)
addappid(2071501, 1, "09816c981c46c92d4ed52518b9c9abf09cf588de797d2fbdf5dd7adad94bed69")
addappid(2749900, 0, "135a899bace07a6e0eaa2ed8be6540505c11741d4c828c173ec06eca6385a536")
