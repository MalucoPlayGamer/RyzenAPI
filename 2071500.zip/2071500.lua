-- Lua provided by RyzenAPI
-- Game: Islands of Insight

-- MAIN APPLICATION
addappid(2071500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071501, 1, "09816c981c46c92d4ed52518b9c9abf09cf588de797d2fbdf5dd7adad94bed69")
addappid(2749900, 0, "135a899bace07a6e0eaa2ed8be6540505c11741d4c828c173ec06eca6385a536")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
