-- Lua provided by RyzenAPI
-- Game: Beat Saber - Metallica - "Nothing Else Matters"

-- MAIN APPLICATION
addappid(3354660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354660,0,"8a30d03d4d146489e28e6f392fb7337deaa9281e1801fc7a5394b0140c23f403")

