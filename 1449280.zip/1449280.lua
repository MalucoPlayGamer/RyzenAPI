-- Lua provided by RyzenAPI
-- Game: Ghostbusters: The Video Game Remastered

-- MAIN APPLICATION
addappid(1449280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449281, 1, "1c8f5131185d7127f3f793cca490a02842c142644e7d0ea26149563639bc0f27")
