-- Lua provided by RyzenAPI
-- Game: Winged Sakura: Mindy's Arc - Soundtrack

-- MAIN APPLICATION
addappid(331550)

-- MAIN APP DEPOTS / PACKAGES
addappid(331550,0,"9595406bbf1c6b7ace6982def521dbf9af5e2df1df9d141871ab7c5424cc5c0d")

