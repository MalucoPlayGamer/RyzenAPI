-- 4586040's Lua and Manifest Created by Hubcap Manifest
-- Double Knight
-- Created: July 01, 2026 at 05:57:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4586040) -- Double Knight
-- MAIN APP DEPOTS
addappid(4586042, 1, "963cecd95405b7a05054e515a7a729e08c01a389a30c1cfe3a03be9f6deac9de") -- Depot 4586042
-- setManifestid(4586042, "8908741320462252417", 411692626)
addappid(4586043, 1, "3c72f5e6fcbee3641de65e199cf5bb99d118400df81907c2ef71246138d1dccd") -- Depot 4586043
-- setManifestid(4586043, "8352824750327640152", 434257322)