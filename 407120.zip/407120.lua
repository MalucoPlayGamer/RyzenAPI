-- Lua provided by RyzenAPI
-- Game: AppID 407120

-- MAIN APPLICATION
addappid(407120)
addappid(407140)

-- MAIN APP DEPOTS / PACKAGES
addappid(407121, 1, "479dd9aef66eaabcf25d07a9fc60a362775b732ab8857ae2d20d3e10958573e8")

