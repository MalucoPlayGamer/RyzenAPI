-- Lua provided by RyzenAPI
-- Game: This Way Madness Lies

-- MAIN APPLICATION
addappid(1318970)
-- Game: addappid(1318970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318971, 1, "f175c694fe17db1d44da8fc46ab3b7188d537ef1ab9ea9d529e1c4388ba683bd")
