-- Lua provided by RyzenAPI
-- Game: Just Jump

-- MAIN APPLICATION
addappid(749880)

-- MAIN APP DEPOTS / PACKAGES
addappid(749881, 1, "0877e0f69d7db1f092b51700aedb629a749f2d6308fc8b1decc139fa9c3abeca")
