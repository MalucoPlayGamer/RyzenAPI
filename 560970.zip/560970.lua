-- Lua provided by RyzenAPI
-- Game: 560970

-- MAIN APPLICATION
addappid(560970)
-- Game: addappid(560970)

-- MAIN APP DEPOTS / PACKAGES
addappid(560971, 1, "8d8ef5c8b7594d9524e6cfc0d4f3955526abc131f02df5b860f910adfd5b2f2a")
