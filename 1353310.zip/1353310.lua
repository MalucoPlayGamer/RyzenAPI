-- Lua provided by RyzenAPI
-- Game: addappid(1353310)

-- MAIN APPLICATION
addappid(1353310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353311, 1, "7b33a81fa35df6dc87406a3fedef5ae84307da4db913be63153600de5e343f83")
