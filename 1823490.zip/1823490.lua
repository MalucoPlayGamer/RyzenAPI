-- Lua provided by RyzenAPI
-- Game: Game: Legend of the Phoenix

-- MAIN APPLICATION
addappid(1823490)
-- Game: addappid(1823490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823491, 1, "cd9aed8416f58246adc52d95c217f56ded7fd09a25d76267e2f13c332a3180de")
addappid(1823493, 1, "a0a534e83b625e9c949e32dded8abd87ef8fc265d1b3bc9e08d0636e939f4930")
