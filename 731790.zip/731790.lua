-- Lua provided by RyzenAPI
-- Game: AppID 731790

-- MAIN APPLICATION
addappid(731790)

-- MAIN APP DEPOTS / PACKAGES
addappid(731791, 1, "89987604dd3d8522804f1961162531169be50d54b86a100acd6a5317914dd4a8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
