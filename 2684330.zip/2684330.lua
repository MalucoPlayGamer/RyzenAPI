-- Lua provided by RyzenAPI
-- Game: C.A.R.D.S. RPG: The Misty Battlefield - Original Sound Track

-- MAIN APPLICATION
addappid(2684330)
-- Game: addappid(2684330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684331, 1, "fc2a9d3f50f95b4a42414b3f6a86b4808432e687ec228af6e0351053cf988d47")
