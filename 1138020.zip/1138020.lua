-- Lua provided by RyzenAPI
-- Game: Merge

-- MAIN APPLICATION
addappid(1138020)
-- Game: addappid(1138020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138021, 1, "1744e4b9ca4d671737018eaa58fb1e70b1f1bc11b179560139c988d333c04a8b")
