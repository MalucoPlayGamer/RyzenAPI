-- Lua provided by RyzenAPI
-- Game: Merge

-- MAIN APPLICATION
addappid(1138020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1138021, 1, "1744e4b9ca4d671737018eaa58fb1e70b1f1bc11b179560139c988d333c04a8b")

