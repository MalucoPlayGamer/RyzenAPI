-- 3508910's Lua and Manifest Created by Hubcap Manifest
-- Abyss Kitchen
-- Created: July 24, 2026 at 05:34:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3508910) -- Abyss Kitchen
-- MAIN APP DEPOTS
addappid(3508911, 1, "b8c313d7cd0ac02ed2181cada5eb476a979c2bf29ee968123a2b4ee9a9ff2f50") -- Depot 3508911
setManifestid(3508911, "1579721661311890705", 482443563)