-- Lua provided by RyzenAPI
-- Game: addappid(1607170)

-- MAIN APPLICATION
addappid(1607170)
addappid(2376730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607171, 1, "581614cb0c02ae87521f4ee3ab4ebf9fd8e039445a499559b7528b3124e9a96e")
