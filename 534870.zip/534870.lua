-- Lua provided by RyzenAPI
-- Game: Game: Arcane

-- MAIN APPLICATION
addappid(534870)
-- Game: addappid(534870)

-- MAIN APP DEPOTS / PACKAGES
addappid(534871, 1, "e1af80e14d92aa85cceec610ea15835d42d9a1c9ac004273d6e96e76e8e5547c")
