-- Lua provided by RyzenAPI
-- Game: Wheel World Soundtrack

-- MAIN APPLICATION
addappid(3842600)
-- Game: addappid(3842600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3842601, 1, "aa27f5de5bcc436136a310d116a39e2f01b594cc51fae36007ab487a102b5139")
