-- Lua provided by SkyAPI 
-- Game: Wheel World Soundtrack
addappid(3842600)
addappid(3842601, 1, "aa27f5de5bcc436136a310d116a39e2f01b594cc51fae36007ab487a102b5139")
