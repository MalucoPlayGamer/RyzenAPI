-- Lua provided by RyzenAPI
-- Game: Samurai Bringer

-- MAIN APPLICATION
addappid(1851280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851281, 1, "dfdd2deac37ee7550afe483f6f82d959ef1e1e848742005b550a8255f4c3b510")
