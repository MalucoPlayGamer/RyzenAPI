-- Lua provided by RyzenAPI
-- Game: QbQbQb

-- MAIN APPLICATION
addappid(329320)
-- Game: addappid(329320)

-- MAIN APP DEPOTS / PACKAGES
addappid(329321, 1, "9f528d9657a6d4d9b2ec519924f31b2e956bd1c359369d03ac9ad8873d44b306")
addappid(329322, 1, "daccca4fac430e2b07d46b2beb91c6042de087f92ef3462a370306ea339432dc")
addappid(329323, 1, "890afbc96b4aaeb1a671cd601e2a3609c1865e37a2989bee0a6788a85bc50463")
