-- Lua provided by RyzenAPI
-- Game: Game: Abyss Cave

-- MAIN APPLICATION
addappid(348740)
-- Game: addappid(348740)

-- MAIN APP DEPOTS / PACKAGES
addappid(348741, 1, "35abb4b74a613dde37af5c8dbf796c23a830fdcf908554d3ab1d72fc824183bf")
