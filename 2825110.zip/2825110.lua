-- Lua provided by RyzenAPI
-- Game: Game: Technotopia

-- MAIN APPLICATION
addappid(2825110)
-- Game: addappid(2825110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825111, 1, "ac7599603402d27f51a9a832f2e69b78bd89fe8fb317c7cfd74361fbcdc5b200")
addappid(2825112, 1, "829880f13a645ba004d21884a9b8431f805e2c96c4ee4605c30407c88bfbf041")
