-- Lua provided by RyzenAPI 
-- Game: Tenioha! feat. Mami
addappid(2552420)
addappid(2552421, 1, "52a14f9120f9a4d4e6bcb63df9181596d9ce0168c3e68cd4d598aef3dd1261b7")
