-- Lua provided by RyzenAPI
-- Game: Game: Potato Survival

-- MAIN APPLICATION
addappid(2108600)
-- Game: addappid(2108600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108601, 1, "8eebb6e6f4699dcedf0ea11ce3cb177eaa6bcda73e7147b7d5509182c43ffb8d")
