-- Lua provided by RyzenAPI
-- Game: Game: AppID 2366140

-- MAIN APPLICATION
addappid(2366140)
-- Game: addappid(2366140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366141, 1, "31215ab8ac7753b9218c8f5fbf2a6fd2f14bc580a56d70c8287956db4cb16676")
addappid(2366142, 1, "a320e83debdf0f133df7af597841a30f15e9917bc1bd923ce82cd91b411ca7a1")
