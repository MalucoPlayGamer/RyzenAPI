-- Lua provided by RyzenAPI
-- Game: Game: AppID 871200

-- MAIN APPLICATION
addappid(871200)
-- Game: addappid(871200)

-- MAIN APP DEPOTS / PACKAGES
addappid(871201, 1, "f67cde0b825e9c17d2583644d0ad01a95a73351bb617c90e869e5af266618c53")
