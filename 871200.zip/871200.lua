-- Lua provided by RyzenAPI
-- Game: FIGHTING EX LAYER

-- MAIN APPLICATION
addappid(871200)
addappid(885920)
addappid(892280)
addappid(892281)
addappid(892282)
addappid(892283)
addappid(892284)
addappid(892285)
addappid(892286)
addappid(892287)
addappid(892288)
addappid(892289)
addappid(892290)
addappid(892291)
addappid(892292)
addappid(892293)
addappid(892294)
addappid(892295)
addappid(1023801)
addappid(1023802)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(871200,0,"ff30ea286e81f909a3186975697424da494e844ca874eca915ad74d51dea5448")
addappid(871201,0,"f67cde0b825e9c17d2583644d0ad01a95a73351bb617c90e869e5af266618c53")

