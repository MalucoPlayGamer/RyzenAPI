-- Lua provided by RyzenAPI
-- Game: Despotism 3k - Soundtrack

-- MAIN APPLICATION
addappid(979650)

-- MAIN APP DEPOTS / PACKAGES
addappid(699925,0,"0a4361a0e95f10bb3b29d0c1d79263bf395ca9508c0106ad72253c5bdc058dfe")

