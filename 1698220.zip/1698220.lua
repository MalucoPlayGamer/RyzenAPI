-- Lua provided by RyzenAPI
-- Game: Game: Teslagrad 2

-- MAIN APPLICATION
addappid(1698220)
-- Game: addappid(1698220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698221, 1, "0b06216b980b9c8300ab12b79a070cff7edfe11a16a13c546f7288dfd75c059d")
addappid(1698223, 1, "0dd7c8e0f6947c098c686b26a09db9741571c0ff8642f6d2a40f0544c509f45d")
