-- Lua provided by RyzenAPI
-- Game: Dumb As Wizards

-- MAIN APPLICATION
addappid(828730)

-- MAIN APP DEPOTS / PACKAGES
addappid(828731,0,"29eb66c904baf1c6a9a4f1e35ddd1397381ac6732f23b3ba0abf108abeace31d")

