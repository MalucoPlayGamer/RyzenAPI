-- Lua provided by RyzenAPI
-- Game: 骸心 Mainbody

-- MAIN APPLICATION
addappid(2189420)
-- Game: addappid(2189420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2189421, 1, "8f9828aa261224eeb5675a855202a6aebaa8cab67ef77331772f288601b40563")
