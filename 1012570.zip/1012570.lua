-- Lua provided by RyzenAPI
-- Game: Knuckle Sandwich

-- MAIN APPLICATION
addappid(228990)
addappid(1012570)
addappid(1012571)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012572,0,"a55911949aa2c9382bfeeefb70d922742dc65bc48e68ea83f1d01ad94c7a73b7")
