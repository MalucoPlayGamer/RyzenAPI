-- Lua provided by RyzenAPI
-- Game: 1130700

-- MAIN APPLICATION
addappid(1130700)
-- Game: addappid(1130700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130701, 1, "149bdf7fdc8c0356c593d27b49776a0ef500d453a3466fedbc6a7b21beddaede")
