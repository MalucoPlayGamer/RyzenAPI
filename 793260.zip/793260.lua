-- Lua provided by RyzenAPI 
-- Game: Army of Squirrels
addappid(793260)
addappid(793261, 1, "3161d21cdc3007e8706d682d7c891c6df9b23549e58eb3f385737740c76e2bfd")
