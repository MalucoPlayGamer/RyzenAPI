-- Lua provided by RyzenAPI
-- Game: Game: Army of Squirrels

-- MAIN APPLICATION
addappid(793260)
-- Game: addappid(793260)

-- MAIN APP DEPOTS / PACKAGES
addappid(793261, 1, "3161d21cdc3007e8706d682d7c891c6df9b23549e58eb3f385737740c76e2bfd")
