-- Lua provided by RyzenAPI
-- Game: DSX

-- MAIN APPLICATION
addappid(2345650) -- DSX - Virtual DualSense Emulation DLC

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
addappid(1812620, 1, "05b5ea90c331ed549da81c199d0c68fc1bedebfd05a698d080303ef859e68a80") -- DSX
addappid(1812621, 1, "b16191edf34d9d15597769ae5e091678e720af03f27763b92088c6eace30e1d4") -- Depot 1812621
