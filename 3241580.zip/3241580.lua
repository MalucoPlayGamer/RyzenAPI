-- Lua provided by RyzenAPI
-- Game: 3241580

-- MAIN APPLICATION
addappid(3241580)
-- Game: addappid(3241580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241581, 1, "6686a941a87c575cfd30cbc5fdcd378a5ec3af0269fe481773bd2bb9ea904593")
