-- Lua provided by RyzenAPI
-- Game: 三国：百将牌

-- MAIN APPLICATION
addappid(4071040)
