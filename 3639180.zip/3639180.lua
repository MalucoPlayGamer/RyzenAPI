-- Lua provided by RyzenAPI
-- Game: Telebbit Soundtrack

-- MAIN APPLICATION
addappid(3639180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3639181, 1, "1f09aae93fee5e0ad741360b474c25679f1e4dcd683fd29c3e5ce86c1f03eb63")
addappid(3639182, 1, "02e52a602eb23d45fb63a297afa10c68ea1750fe3d41a7654be766a3f879b309")
