-- Lua provided by RyzenAPI
-- Game: Teatime Samurai

-- MAIN APPLICATION
addappid(2997310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2997311, 1, "a10253402db274a6e272763683c6f15ff56de480ea8f68df607fb59b1213dc65")

