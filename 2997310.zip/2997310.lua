-- Lua provided by SkyAPI 
-- Game: Teatime Samurai
addappid(2997310)
addappid(2997311, 1, "a10253402db274a6e272763683c6f15ff56de480ea8f68df607fb59b1213dc65")
