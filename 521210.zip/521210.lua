-- Lua provided by SkyAPI 
-- Game: Timore 5
addappid(521210)
addappid(521211, 1, "0457bd1cf5fa11e12a85668591c36eb3cb4023a5ac45badf953daf5c16701402")
addappid(639150, 0, "d87bf4b0685a41ec29165be87c91077f1eef30eb1a933d4b8273219719583d23")
