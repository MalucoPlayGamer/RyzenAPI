-- Lua provided by RyzenAPI
-- Game: Game: Aquarelle

-- MAIN APPLICATION
addappid(1495580)
-- Game: addappid(1495580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495581, 1, "d3dc184654d212025f8f7457145e32930676ebb2ad70c8a45df8ee007910df51")
