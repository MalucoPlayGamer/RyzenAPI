-- Lua provided by RyzenAPI 
-- Game: The Beanstalk
addappid(713060)
addappid(713061, 1, "d860a8f17e2babfd137bea6e3b274ca83ac15c56b45c5247eed7bf06c5c34067")
