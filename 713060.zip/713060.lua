-- Lua provided by RyzenAPI
-- Game: The Beanstalk

-- MAIN APPLICATION
addappid(713060)
-- Game: addappid(713060)

-- MAIN APP DEPOTS / PACKAGES
addappid(713061, 1, "d860a8f17e2babfd137bea6e3b274ca83ac15c56b45c5247eed7bf06c5c34067")
