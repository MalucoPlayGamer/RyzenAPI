-- Lua provided by RyzenAPI
-- Game: Tsukumono / つくもの / 付者

-- MAIN APPLICATION
addappid(993850)

-- MAIN APP DEPOTS / PACKAGES
addappid(993851, 1, "b720b5a293a7a8c83fb9d96d7ae96cd6b3c67e99ee98cb3da8dcd648a1785df7")
