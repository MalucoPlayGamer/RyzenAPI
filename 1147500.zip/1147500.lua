-- Lua provided by RyzenAPI
-- Game: A Gay's Life

-- MAIN APPLICATION
addappid(1147500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147501, 1, "8376b2d64cb098a219bc440634b7dd98ed84e0591876a32aef0185f17821ae50")

