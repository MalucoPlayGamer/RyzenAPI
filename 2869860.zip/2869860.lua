-- Lua provided by RyzenAPI
-- Game: Monster Prom 4: Monster Con

-- MAIN APPLICATION
addappid(2869860)
addappid(2869863)
addappid(2869864)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869862,0,"f59cccd69ee74c5c3964979a6840408373293bccab555df8701bf008a0d258b4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3610600)
addappid(3610610)
addappid(3610620)
addappid(3610660)
