-- Lua provided by RyzenAPI
-- Game: addappid(2869860)

-- MAIN APPLICATION
addappid(2869860)
addappid(2869863)
addappid(2869864)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869862,0,"f59cccd69ee74c5c3964979a6840408373293bccab555df8701bf008a0d258b4")
