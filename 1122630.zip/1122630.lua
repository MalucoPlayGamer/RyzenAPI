-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – Stevie Wonder - “Superstition”

-- MAIN APPLICATION
addappid(1122630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122630,0,"2fa21c11b23e163f5029d6625aaa64b91fbf2371c8a559138389a2c3342a152e")
