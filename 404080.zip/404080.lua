-- Lua provided by RyzenAPI
-- Game: AppID 404080

-- MAIN APPLICATION
addappid(404080)

-- MAIN APP DEPOTS / PACKAGES
addappid(404081, 1, "f9ea1d561e7878f3249a0c1dae423e1ab291a91545b3d53432aa671f0792e144")
addappid(404082, 1, "32027f4f414f4e67537850ddc3246df065fdf66b6013f9256fa5649fa83da109")
addappid(404083, 1, "523556f71d0c729694bf720536ef503a0805715535c2210b47b077d4078743ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
