-- Lua provided by RyzenAPI
-- Game: Game: AppID 936810

-- MAIN APPLICATION
addappid(936810)
-- Game: addappid(936810)

-- MAIN APP DEPOTS / PACKAGES
addappid(936811, 1, "abbb056d3ee422b4efb58f1663ad41b34588ced2c8a7de69f6ff9a07599ab587")
