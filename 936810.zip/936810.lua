-- Lua provided by SkyAPI 
-- Game: AppID 936810
addappid(936810)
addappid(936811, 1, "abbb056d3ee422b4efb58f1663ad41b34588ced2c8a7de69f6ff9a07599ab587")
