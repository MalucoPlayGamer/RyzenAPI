-- Lua provided by RyzenAPI
-- Game: The Disappearing of Gensokyo: Byakuren Character Pack

-- MAIN APPLICATION
addappid(781020)

-- MAIN APP DEPOTS / PACKAGES
addappid(781020,0,"d9e164154beb70b194c27378b01f0089c0d00530d82dbfca560df891877afbc9")
addtoken(781020,9089857728787342294)
