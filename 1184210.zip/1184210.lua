-- Lua provided by RyzenAPI
-- Game: Fragile

-- MAIN APPLICATION
addappid(1184210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184211, 1, "1ce426cf9f6beb49d7c30c5434efd05f8903e68c4d6873b9d931075920cdc50c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
