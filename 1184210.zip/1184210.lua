-- Lua provided by RyzenAPI
-- Game: 1184210

-- MAIN APPLICATION
addappid(1184210)
-- Game: addappid(1184210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184211, 1, "1ce426cf9f6beb49d7c30c5434efd05f8903e68c4d6873b9d931075920cdc50c")
