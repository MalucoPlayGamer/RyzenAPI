-- Lua provided by RyzenAPI
-- Game: Sexy Furry - Cat Furry DLC

-- MAIN APPLICATION
addappid(3402000)
-- Game: addappid(3402000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402000,0,"c15fc7ff1b5d03804595e704d76d99b72dc5dfdc39ee947a9c5a3dded7050744")
