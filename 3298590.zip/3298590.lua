-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in Tokyo

-- MAIN APPLICATION
addappid(3298590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298591, 1, "7b3906b8b2a9ed0ff9af376038b4ec0591b92364c93ac32db531a389ac64cd6f")

