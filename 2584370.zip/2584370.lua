-- Lua provided by RyzenAPI
-- Game: 2584370

-- MAIN APPLICATION
addappid(2584370)
-- Game: addappid(2584370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584371, 1, "525c80d808113fa2e8dcd722ba7002bf9f249cc56f5ad5039742133ee140d888")
