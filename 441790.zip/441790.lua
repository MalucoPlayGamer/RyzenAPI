-- Lua provided by RyzenAPI
-- Game: Fragmented

-- MAIN APPLICATION
addappid(441790)

-- MAIN APP DEPOTS / PACKAGES
addappid(441791, 1, "2ae04b7404006664ffe32b9c2cdab5d00a0125780a48d6f9d443f030462658df")
addappid(441792, 1, "d720df6d4ff0092c46a9ffef4f56afc2ce062b65815e5e05719d52293cbaa58b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
