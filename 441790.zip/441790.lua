-- Lua provided by RyzenAPI
-- Game: Fragmented

-- MAIN APPLICATION
addappid(441790)
-- Game: addappid(441790)

-- MAIN APP DEPOTS / PACKAGES
addappid(441791, 1, "2ae04b7404006664ffe32b9c2cdab5d00a0125780a48d6f9d443f030462658df")
addappid(441792, 1, "d720df6d4ff0092c46a9ffef4f56afc2ce062b65815e5e05719d52293cbaa58b")
