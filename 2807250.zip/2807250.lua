-- Lua provided by RyzenAPI
-- Game: addappid(2807250)

-- MAIN APPLICATION
addappid(2807250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807251, 1, "31cb61115b0eaeea97cca7486d70a8e694a7e983e3557a060904f5db959609cd")
