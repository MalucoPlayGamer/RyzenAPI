-- Lua provided by RyzenAPI
-- Game: Game: Midinous Demo

-- MAIN APPLICATION
addappid(1732000)
-- Game: addappid(1732000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732001, 1, "a99a8a25b1a79250d42e8bad5c9733394f3ef3a9872209aa54c37ee8ff57f723")
