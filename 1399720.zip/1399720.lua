-- Lua provided by RyzenAPI
-- Game: Antimatter Dimensions

-- MAIN APPLICATION
addappid(1399720)
