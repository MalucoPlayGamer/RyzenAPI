-- Lua provided by RyzenAPI
-- Game: Serum Playtest

-- MAIN APPLICATION
addappid(1718540)
-- Game: addappid(1718540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718541, 1, "49490336f07f7bb3f9731626366fea0059551096aecdc62117946014db7fc8bf")
