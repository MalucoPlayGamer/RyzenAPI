-- Lua provided by RyzenAPI
-- Game: 3372150

-- MAIN APPLICATION
addappid(3372150)
-- Game: addappid(3372150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372151, 1, "efcfe14fc114dacdcb23698dea26726f7efb2496ff435345d6a8bd0ae5c9ece0")
