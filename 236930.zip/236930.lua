-- Lua provided by RyzenAPI
-- Game: addappid(236930)

-- MAIN APPLICATION
addappid(236930)

-- MAIN APP DEPOTS / PACKAGES
addappid(236931, 1, "fe2ba76b24c99aa1f0cec43c3ac8885e7f5127f4064bfd972bcb2ae1f4d83fc3")
addappid(236932, 1, "8b199351a30fd3af363170a0d359f2ab9d3ddb7ee3a708b333194e696e773335")
addappid(236933, 1, "c8d05e2c1830caf769a35d8ea7dc2782b5318e282eacecac11a8d3ed0b80fa1e")
addappid(236934, 1, "5b9ad032b9d5aaed199d62bbc8f21aa36113512c0cb69862f5141c3ce106b87f")
