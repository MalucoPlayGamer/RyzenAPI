-- Lua provided by RyzenAPI
-- Game: Balance of Soccer

-- MAIN APPLICATION
addappid(863290)

-- MAIN APP DEPOTS / PACKAGES
addappid(863291,0,"a2a53c014dfffe3accee9ecb6a0906c170b92b93e203b585015a3f9de955b22e")

