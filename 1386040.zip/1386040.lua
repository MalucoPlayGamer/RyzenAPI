-- Lua provided by RyzenAPI
-- Game: Jelly Brawl: Classic

-- MAIN APPLICATION
addappid(1386040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386041, 1, "7dc2388049a80dcf425d125b428f7ef56ac54c9dedf5c06bb35ae2691d7697b3")
addappid(1386042, 1, "903d1b741aaaa66b425099f5f7ec11518e189fe0a1940e2ebf262d3d27fe1dac")
addappid(1386043, 1, "c59db93b142d208ab74509968cf5630732028be40cd39c18babfcfd01fde5196")

