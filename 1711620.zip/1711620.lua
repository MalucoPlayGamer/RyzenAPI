-- Lua provided by RyzenAPI
-- Game: Demonheart: The Ice Demon

-- MAIN APPLICATION
addappid(1711620)
addappid(2159490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711621, 1, "07cf4b4db23afb272ad7010fc8bca37e9139176b8c889da6874daaf66b66d7e3")
addappid(1711622, 1, "da1399ad9f874b61b54ff5b80409b3ba42b7554d735b9d225685a78f4703fd8a")
