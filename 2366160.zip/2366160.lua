-- Lua provided by RyzenAPI
-- Game: Landnama Demo

-- MAIN APPLICATION
addappid(2366160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366161, 1, "89579944f4f6cfc578f0af1bde18d845e6d35760846e9e513a4996f5987b6f52")

