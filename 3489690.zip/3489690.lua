-- Lua provided by RyzenAPI
-- Game: addappid(3489690)

-- MAIN APPLICATION
addappid(3489690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3489690,0,"320a1dbbb4df1a88789b0cd16767222f25ee94e1a7580a7101e730d2ea8eae0c")
