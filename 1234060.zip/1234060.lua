-- Lua provided by RyzenAPI
-- Game: 1234060

-- MAIN APPLICATION
addappid(1234060)
-- Game: addappid(1234060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234061, 1, "eca7f7fb85a4bce23a0ff9a048b90fe3462a980b65c19b2ca8dd1ca9475e0e35")
