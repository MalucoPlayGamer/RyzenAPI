-- Lua provided by RyzenAPI
-- Game: HumanBloodSandwich

-- MAIN APPLICATION
addappid(1234060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234061, 1, "eca7f7fb85a4bce23a0ff9a048b90fe3462a980b65c19b2ca8dd1ca9475e0e35")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
