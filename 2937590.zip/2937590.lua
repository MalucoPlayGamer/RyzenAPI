-- Lua provided by RyzenAPI
-- Game: WYRMHALL: Brush and Banter

-- MAIN APPLICATION
addappid(2937590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937591, 1, "368FC50EFFFCA81E3EFB7F7A667B8C3051F1461F62D9859AF20AEA589BC1F6BE")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
