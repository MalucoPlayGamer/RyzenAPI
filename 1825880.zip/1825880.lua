-- Lua provided by RyzenAPI
-- Game: 作死吧！UP主！

-- MAIN APPLICATION
addappid(1825880)
-- Game: addappid(1825880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825881, 1, "e292652d33322c5587f33782133ce7e56d474986c82896266f6d4f1c6c079ff6")
