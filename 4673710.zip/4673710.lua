-- Lua provided by RyzenAPI
-- Game: Infinite Backrooms

-- MAIN APPLICATION
addappid(4673710) -- Infinite Backrooms

-- MAIN APP DEPOTS / PACKAGES
addappid(4673711, 1, "9cac91f6095231e1d5c3f7e8e5b3ff030166fd5ea1e431ab5b73a1ccc7465727") -- Depot 4673711

