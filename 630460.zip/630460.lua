-- Lua provided by RyzenAPI
-- Game: Game: AppID 630460

-- MAIN APPLICATION
addappid(630460)
-- Game: addappid(630460)

-- MAIN APP DEPOTS / PACKAGES
addappid(630461, 1, "1489880b46aeeb0f78d695b984d454a5cad7be3699a1a5ec282e9fca0fc94434")
addappid(630462, 1, "00019f880d1618bfb9b10f6d642d1eecc88991eed90f96ab3015ed31a155d5f1")
