-- Lua provided by RyzenAPI
-- Game: 223280

-- MAIN APPLICATION
addappid(223280)
addappid(229003)
addappid(229012)
-- Game: addappid(223280)

-- MAIN APP DEPOTS / PACKAGES
addappid(223281, 1, "a96efb75bef3aad3fcebabd50f285cbe1fc4e611827ced330c8d776083cbc15f")
