-- Lua provided by RyzenAPI
-- Game: Creepy Shift: House For Sale

-- MAIN APPLICATION
addappid(3400650)
-- Game: addappid(3400650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3400651, 1, "41d5afdb2760edcd2ed7f80f42b61c145fa9ce711b43f9fcd56ff9d63ab5587e")
