-- Lua provided by RyzenAPI
-- Game: Zero G Arena

-- MAIN APPLICATION
addappid(467820)

-- MAIN APP DEPOTS / PACKAGES
addappid(467821, 1, "1142883107da554d95d4f8ee3a5e1705d2126058a57efa1d9dffc15479294a5e")
addappid(467822, 1, "f910f418d8c98548b61efd9b361558098fe08d6d2affecf87dfaa8abf3ac91f8")
addappid(467823, 1, "4909d9c27f4f0cefdc6fec6f0be9628c947ffb0e3d28cdf153964f89e265a7e0")
