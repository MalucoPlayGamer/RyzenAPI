-- Lua provided by RyzenAPI 
-- Game: Marquee Candle Demo
addappid(3262330)
addappid(3262331, 1, "50a7507b963cf55fd50b4c3b096e6177de8586a3e8088b6c1d2a4b763834c82a")
