-- Lua provided by RyzenAPI
-- Game: Tick Tock: A Tale for Two

-- MAIN APPLICATION
addappid(790740)

-- MAIN APP DEPOTS / PACKAGES
addappid(790742,0,"fcb571394fd9d9e7c0dcc9f07c3ac43578b76a16a4e53263d49d495a1d12753f")
addappid(790743,0,"f2b9d4529f72fe9f092c5c43861cd3779c882da62950c577bf01752f48a41e88")
