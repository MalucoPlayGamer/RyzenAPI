-- Lua provided by RyzenAPI 
-- Game: AppID 2304130
addappid(2304130)
addappid(2304131, 1, "e80ed4da136b9c5af03734b0eb4b634f7948f4ccb4a68e63e95378ba3963c0ad")
