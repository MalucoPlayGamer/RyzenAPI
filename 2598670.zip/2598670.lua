-- Lua provided by RyzenAPI
-- Game: AppID 2598670

-- MAIN APPLICATION
addappid(2598670)
-- Game: addappid(2598670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598671, 1, "7d3ef432551671fa95d4cdf36150e9103829ec6d621c7d7b92bc2cec2b368e1b")
