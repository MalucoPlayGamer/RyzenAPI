-- Lua provided by SkyAPI 
-- Game: SUPER ASTEROIDS
addappid(788190)
addappid(788191, 1, "e98db199cb60d2f83840a21133e9baaa4f9b0c1d3d196c4913e7d08ceaf1ade0")
