-- Lua provided by RyzenAPI
-- Game: AppID 370510

-- MAIN APPLICATION
addappid(370510)
-- Game: addappid(370510)

-- MAIN APP DEPOTS / PACKAGES
addappid(370511, 1, "36c1ea7d1320de0b3c3facd1b8246fdb4d6843ac93fea211399e53ab1d6f4a1f")
