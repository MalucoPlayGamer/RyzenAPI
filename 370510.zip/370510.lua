-- Lua provided by RyzenAPI
-- Game: AppID 370510

-- MAIN APPLICATION
addappid(370510)

-- MAIN APP DEPOTS / PACKAGES
addappid(370511, 1, "36c1ea7d1320de0b3c3facd1b8246fdb4d6843ac93fea211399e53ab1d6f4a1f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
