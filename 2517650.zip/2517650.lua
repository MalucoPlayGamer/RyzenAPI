-- Lua provided by RyzenAPI
-- Game: addappid(2517650)

-- MAIN APPLICATION
addappid(2517650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517650,0,"8a4fbeaf721413c1ac8aac37edfef099dc22bd67fbfafbd10fd74f2d45e1d86a")
