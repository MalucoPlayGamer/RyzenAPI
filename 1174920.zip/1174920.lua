-- Lua provided by RyzenAPI
-- Game: addappid(1174920)

-- MAIN APPLICATION
addappid(1174920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174921, 1, "d3bc351060306df7cedc0844d0b43d6c954f8192cdae939fe8115f1632a5b1da")
