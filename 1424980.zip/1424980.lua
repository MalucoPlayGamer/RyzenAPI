-- Lua provided by RyzenAPI 
-- Game: The Solitaire Conspiracy
addappid(1424980)
addappid(1424981, 1, "2fd96b2b3ab9427b80f81eb128370a64ea9821dff0249d25190f7d57426774d8")
addappid(1424982, 1, "f2681bc171c3469e5feae64e0f5deb7d0a5af285277bffd0eb315bf9de6e5def")
