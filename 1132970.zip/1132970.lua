-- Lua provided by RyzenAPI
-- Game: Time To Stop Time

-- MAIN APPLICATION
addappid(1132970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1132971, 1, "955ee1882db11a0b355ed7f82f7a24fcea6ffde1afd24398039058501d6fe154")

