-- Lua provided by RyzenAPI
-- Game: Time To Stop Time

-- MAIN APPLICATION
addappid(1132970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132971, 1, "955ee1882db11a0b355ed7f82f7a24fcea6ffde1afd24398039058501d6fe154")
