-- Lua provided by RyzenAPI
-- Game: Homeworld 3

-- MAIN APPLICATION
addappid(1840080)
addappid(2667180)
addappid(2667190)
addappid(2667200)
addappid(2688040)
addappid(2688050)
addappid(2688060)
addappid(2689700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1840081, 1, "5d53e08892dfc69e5116808861483da9327d3b294b2c9a5e4afd727309439d2c")
addappid(1840082, 1, "ab8b56a6b90d907fe7c1e1def09d1ca6e13772b960b33235c94f5e13f2e16d06")
addappid(2842180, 0, "89ad55c8ea3ea497e1351392578a4b21ea6a03f3199fbc9954849a7c75b035dc")

