-- Lua provided by RyzenAPI
-- Game: Eternal Strands - Prologue Demo

-- MAIN APPLICATION
addappid(3139110)
-- Game: addappid(3139110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3139111, 1, "d7d578cf5930d86cd571bbc252f3bc320e6c5c1e5423bdbf88e97e7419c19f66")
