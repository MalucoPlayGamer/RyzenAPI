-- Lua provided by RyzenAPI
-- Game: AppID 201020

-- MAIN APPLICATION
addappid(201020)

-- MAIN APP DEPOTS / PACKAGES
addappid(201021, 1, "0cdd3b218618e841b664fd043b9d8ddaab8e3ebb76685694aa71328e87afc7d7")

