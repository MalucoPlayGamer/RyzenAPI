-- Lua provided by RyzenAPI
-- Game: Fisticubes - One Button Boxing!

-- MAIN APPLICATION
addappid(1651360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651362,0,"18b842c9a790c493a5617852af681bda8a4ef15a2bc30724782a8fbc7e8298da")

