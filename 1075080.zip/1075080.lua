-- Lua provided by RyzenAPI
-- Game: Falcon Age

-- MAIN APPLICATION
addappid(1075080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075081, 1, "4d34474c7405b56f018c072394a9311146448e8c5b37285dabe051942aaafaac")
