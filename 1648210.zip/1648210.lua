-- Lua provided by RyzenAPI
-- Game: Apopia: Prologue

-- MAIN APPLICATION
addappid(1648210)
-- Game: addappid(1648210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648211, 1, "b6a03da421df1e9f84fa196a63a2a93fbdd9aa6fddd36f53987670d83d057675")
