-- Lua provided by RyzenAPI
-- Game: Weird Cinema

-- MAIN APPLICATION
addappid(1771930)
-- Game: addappid(1771930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771931, 1, "03ad07522b2198dcd5024a9cfd7f923522f2884d3182a2772e9f384842360057")
