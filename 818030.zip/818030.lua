-- Lua provided by RyzenAPI
-- Game: 818030

-- MAIN APPLICATION
addappid(818030)
-- Game: addappid(818030)

-- MAIN APP DEPOTS / PACKAGES
addappid(818031, 1, "b08951f05150b6f6920418bb1f4ecf58876875f3d6db1bd47f88a9a326e94d37")
