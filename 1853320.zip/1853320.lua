-- Lua provided by RyzenAPI
-- Game: The Dawning Clocks of Time Soundtrack

-- MAIN APPLICATION
addappid(1853320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853322,0,"11e671e9ccad4d2c75203fc26fb4f7ccb78518b178bfafef0ddf18afd2d09897")

