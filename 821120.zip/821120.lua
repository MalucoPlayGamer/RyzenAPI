-- Lua provided by RyzenAPI
-- Game: 821120

-- MAIN APPLICATION
addappid(821120)
-- Game: addappid(821120)

-- MAIN APP DEPOTS / PACKAGES
addappid(821121, 1, "1c08817c6a04b05fdced5ac1a5763039dbba7d8cab4679d135b4b0f0d861ffa6")
