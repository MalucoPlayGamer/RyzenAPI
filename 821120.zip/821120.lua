-- Lua provided by RyzenAPI
-- Game: Poopy Philosophy

-- MAIN APPLICATION
addappid(821120)

-- MAIN APP DEPOTS / PACKAGES
addappid(821121, 1, "1c08817c6a04b05fdced5ac1a5763039dbba7d8cab4679d135b4b0f0d861ffa6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
