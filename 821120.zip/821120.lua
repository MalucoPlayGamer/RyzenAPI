-- Lua provided by RyzenAPI 
-- Game: Poopy Philosophy
addappid(821120)
addappid(821121, 1, "1c08817c6a04b05fdced5ac1a5763039dbba7d8cab4679d135b4b0f0d861ffa6")
