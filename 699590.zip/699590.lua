-- Lua provided by RyzenAPI 
-- Game: Trivia Vault: Science & History Trivia 2
addappid(699590)
addappid(699591, 1, "020524b2d5e5cd7727cd586e0b0ec520e318694d34a4130d2e688d6c7996b971")
