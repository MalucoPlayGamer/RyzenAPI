-- Lua provided by RyzenAPI 
-- Game: Gunslingers
addappid(416670)
addappid(416671, 1, "53786a8a0fc765f7b5af88d36ef2b6c0583adb7dd506eb6a7197ce2ea2448f58")
