-- Lua provided by RyzenAPI
-- Game: Mirage

-- MAIN APPLICATION
addappid(1245780)
-- Game: addappid(1245780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245782,0,"0944c15682d5b1001cec428fe718465ff86e6cf35b85c9388e9e756a5be9cca1")
