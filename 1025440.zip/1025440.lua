-- Lua provided by RyzenAPI
-- Game: Fantasy General II

-- MAIN APPLICATION
addappid(1025440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025441, 1, "aa1bfac3f21537ac040aafe3d9e19cdf53b72b31001ee4926b0a1a29af56bf4d")
addappid(1025442, 1, "14aa284d5e4a2f68b2deb8fc3103fa05051b91676448d9a8e2311396026af497")
addappid(1025443, 1, "46188c06027ec9ab604a6eb516992a3a14656a6bf45dda896fb4ae37bdc8367d")
addappid(1025444, 1, "012ae9645bf7c95d8c71082f506a21232168eba951c27eafeed519fe0706aaa2")
addappid(1025445, 1, "267e33531802d2b1f9c2b06c06848fda8386c57d2bfd5ff57697051f09946928")
addappid(1193870, 0, "f20aed2d2c65d6c523cfc00a47bc7842ef8ab553992e412b7eb9a7d8762519f3")
addappid(1193871, 0, "999bebbea9528ed184d4d5fc15cc62d162a64952d8df4438f4f9677815d8b71b")
addappid(1401480, 0, "02206641132248f3c6a6e585251386cd53c0b57c1af708097d56783510bdca91")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1158810)
