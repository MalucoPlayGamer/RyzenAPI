-- Lua provided by RyzenAPI
-- Game: Fantasy Girl

-- MAIN APPLICATION
addappid(1064730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064731, 1, "546af1caef4a99d354d5000b45a8bb66ad9f3136e82ecbd523412f5d51d2a4b9")
addappid(1064740, 0, "29b78418d342bc8b3989f1b44bc686031f6c6831324cac2a55d5df98dc3574e4")

