-- Lua provided by RyzenAPI
-- Game: ❂ Hexaluga ❂ Witch Hunter's Travelling Castle ♉

-- MAIN APPLICATION
addappid(809450)

-- MAIN APP DEPOTS / PACKAGES
addappid(809451, 1, "b11ae6deae37c0964bf8ee5741e651b060655c30a874bf679b056b622d5b8591")

