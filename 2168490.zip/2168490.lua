-- Lua provided by RyzenAPI
-- Game: Masarada Town Story

-- MAIN APPLICATION
addappid(2168490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168491, 1, "41513b03869470179b39937d705aa1e7c4591ecf92dc05f03fc2e3ba79298387")
