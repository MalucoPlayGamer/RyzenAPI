-- Lua provided by RyzenAPI
-- Game: Game: AppID 3484640

-- MAIN APPLICATION
addappid(3484640)
-- Game: addappid(3484640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3484641, 1, "820b251ce6992c510eafb77a443f335402d7168f1859ef8b629082bd0c03560f")
