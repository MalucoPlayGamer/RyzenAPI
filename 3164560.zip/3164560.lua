-- Lua provided by SkyAPI 
-- Game: 100 Wars
addappid(3164560)
addappid(3164561, 1, "7cd2851031311b7c5027e7f65367838547f7341f89d0a0e0924c93a53ba5f0f9")
