-- Lua provided by RyzenAPI
-- Game: 100种战争

-- MAIN APPLICATION
addappid(3164560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3164561, 1, "7cd2851031311b7c5027e7f65367838547f7341f89d0a0e0924c93a53ba5f0f9")

