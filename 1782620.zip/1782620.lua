-- Lua provided by RyzenAPI
-- Game: Gachi Dash

-- MAIN APPLICATION
addappid(1782620)
-- Game: addappid(1782620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782622,0,"ec3baefd6cba5843f5781d9164a0dca525ec05268d3f03606d945aec601cf5ba")
addappid(1782623,0,"cca806589a625154acff9c0e15989afc15b6c0f6f14c0be6920fe1a852125d8b")
