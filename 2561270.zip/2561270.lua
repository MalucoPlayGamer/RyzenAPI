-- Lua provided by RyzenAPI
-- Game: 2561270

-- MAIN APPLICATION
addappid(2561270)
addappid(2889020)
-- Game: addappid(2561270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2561271, 1, "4af81c857b1910c3238be9c71a204fd6c9427e7204978fd9ccf76e7ed53a59d2")
