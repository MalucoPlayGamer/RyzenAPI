-- Lua provided by RyzenAPI
-- Game: Game: Debugging Hero

-- MAIN APPLICATION
addappid(3406850)
-- Game: addappid(3406850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3406851, 1, "d6b82538f2e24ef5312c3082e4f3f12a639a5958ebd657e48ed22f3e0dfe789a")
