-- Lua provided by RyzenAPI
-- Game: Dokapon Kingdom: Connect

-- MAIN APPLICATION
addappid(2338140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2338142,0,"9b76865425ae78ca3892bde91edbce607043c2330fb03c8f4f776551a5ce0f15")
addappid(2338143,0,"ec18f1c99447f2bb03cfbaa7834453a306f43064438151e0ec80952a0903a73f")

