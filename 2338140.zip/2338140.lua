-- Lua provided by RyzenAPI
-- Game: Dokapon Kingdom: Connect

-- MAIN APPLICATION
addappid(2338140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338142,0,"9b76865425ae78ca3892bde91edbce607043c2330fb03c8f4f776551a5ce0f15")
addappid(2338143,0,"ec18f1c99447f2bb03cfbaa7834453a306f43064438151e0ec80952a0903a73f")
