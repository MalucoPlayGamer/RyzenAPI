-- Lua provided by RyzenAPI
-- Game: AppID 645480

-- MAIN APPLICATION
addappid(645480)
-- Game: addappid(645480)

-- MAIN APP DEPOTS / PACKAGES
addappid(645481, 1, "01aa84ae7330d7e983b0e0900d98b729fadee246ad944af94e8c043ebe545f08")
