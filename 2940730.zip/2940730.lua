-- Lua provided by RyzenAPI
-- Game: Lorelei and the Laser Eyes - Original Soundtrack

-- MAIN APPLICATION
addappid(2940730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940731, 1, "015a07883cae5b0c53e152eaa38069be52e052bda8392936f58b4058d1a837eb")

