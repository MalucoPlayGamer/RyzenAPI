-- Lua provided by RyzenAPI
-- Game: MetaDOS

-- MAIN APPLICATION
addappid(2018740)
-- Game: addappid(2018740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018741, 1, "eb4d7defacca456b2a0b06946a8018dd3a670f91259b080d49d51201d65b4e97")
