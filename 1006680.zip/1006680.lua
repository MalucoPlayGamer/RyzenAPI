-- Lua provided by RyzenAPI 
-- Game: AppID 1006680
addappid(1006680)
addappid(1006681, 1, "0c84758608402f438324509c121b3a5ce9b84e9812c901698862aa171644f4d8")
