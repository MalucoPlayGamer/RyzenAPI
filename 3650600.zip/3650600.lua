-- Lua provided by SkyAPI 
-- Game: Final Outpost: Definitive Edition - Art & Wallpapers
addappid(3650600)
addappid(3650601, 1, "1634e3ca73e3bc4bc3ca69c9a97cf952948b835ef194e98db720a3a06adfdcb6")
