-- Lua provided by RyzenAPI
-- Game: Runes of Magic

-- MAIN APPLICATION
addappid(808290)

-- MAIN APP DEPOTS / PACKAGES
addappid(808291, 1, "4abf5ec178f63a2f078f580a1a0f8fdbddc866d4e70e245f98aaff92db8fde62")
addappid(808292, 1, "eeda3f6d5b799974efe11e2e9f192b73769380de7f40c7f074308ae3096837ae")
addappid(808293, 1, "15251c80c473aeb9ff6da997d305673d6eca39444bac4af0b1bbae356c4a8ba1")
addappid(808294, 1, "d6a6626f0882b72787f9f049e52c595578b0fd2deaa7b9a3078c49a46b691976")
addappid(808295, 1, "1c7fc0b33441ae5a55bc49051b70f1afc79df9cd74d3edcd263ccac8a6bc4077")
addappid(808296, 1, "c66bd847b37232346b45cf25e0b0eb5839ce8c0fa9a7a8187b4e134c2dc5aacf")
addappid(808297, 1, "d076fe24547574782af3a711d1e474367c8912d45b3400538b42e8af821297f3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(880540)
addappid(883310)
addappid(883320)
