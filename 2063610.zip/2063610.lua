-- Lua provided by RyzenAPI
-- Game: Pro Cycling Manager 2023

-- MAIN APPLICATION
addappid(2063610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063611, 1, "3738832dad430489a4ee2f2622f24b64374dd72a940b8d9d410460e144628c36")

