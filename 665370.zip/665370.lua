-- Lua provided by RyzenAPI
-- Game: Game: Mutilate-a-Doll 2

-- MAIN APPLICATION
addappid(665370)
-- Game: addappid(665370)

-- MAIN APP DEPOTS / PACKAGES
addappid(665371, 1, "9ae7f44a1e7248cd1d7fd7eab53ea9e26933f7139fba1f5948c45e99f402177f")
