-- Lua provided by RyzenAPI
-- Game: addappid(1420140)

-- MAIN APPLICATION
addappid(1420140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420141, 1, "74e79f2f0b9a1bf2804dd897c0f80a9d23a90ed22df90eb936768d24cfdc5500")
