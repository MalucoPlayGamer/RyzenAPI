-- Lua provided by RyzenAPI 
-- Game: Froggo's Adventure: Verdant Venture
addappid(2854780)
addappid(2854781, 1, "ccff6aca012b2c7ef38531f7f6be57b1ad0aab24bb7fea25ac3e8ed1d627efd5")
