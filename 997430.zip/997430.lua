-- Lua provided by RyzenAPI
-- Game: addappid(997430)

-- MAIN APPLICATION
addappid(997430)

-- MAIN APP DEPOTS / PACKAGES
addappid(997431, 1, "30c3083ed89146efeb3b6b1f13f956a9c9ca32a44644ade3f4e048c956655313")
