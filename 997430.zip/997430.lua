-- Lua provided by RyzenAPI
-- Game: The Mirum

-- MAIN APPLICATION
addappid(997430)

-- MAIN APP DEPOTS / PACKAGES
addappid(997431, 1, "30c3083ed89146efeb3b6b1f13f956a9c9ca32a44644ade3f4e048c956655313")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
