-- Lua provided by RyzenAPI
-- Game: Game: 9 Lives to Defend

-- MAIN APPLICATION
addappid(2389560)
-- Game: addappid(2389560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389561, 1, "d800ec63e385301694045e32bc65f4e13846de13410f464790d90421009e9701")
