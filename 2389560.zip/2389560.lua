-- Lua provided by SkyAPI 
-- Game: 9 Lives to Defend
addappid(2389560)
addappid(2389561, 1, "d800ec63e385301694045e32bc65f4e13846de13410f464790d90421009e9701")
