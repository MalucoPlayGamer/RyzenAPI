-- Lua provided by RyzenAPI
-- Game: Oniwaki Village -Horror game-

-- MAIN APPLICATION
addappid(2085100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085101, 1, "818f5e465cee8d130ed7fd305df8bc6388434ae7d31988daa522102c7f8a12fc")
