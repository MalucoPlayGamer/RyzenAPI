-- Lua provided by RyzenAPI
-- Game: addappid(1218810)

-- MAIN APPLICATION
addappid(1218810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218811, 1, "7e04262fbdf70531d24c40d1ab08d29fcc2ddd640158714dc74f49f5e1ac5d67")
