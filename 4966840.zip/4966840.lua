-- Lua provided by RyzenAPI
-- Game: Purr in Bloom

-- MAIN APPLICATION
addappid(4966840) -- Purr in Bloom

-- MAIN APP DEPOTS / PACKAGES
addappid(4966841, 1, "7abf1ade9887a973a302aee34e8b8e176e5a38d1c2824cc0a43b1133bad9bbf3") -- Depot 4966841

