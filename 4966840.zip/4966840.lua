-- 4966840's Lua and Manifest Created by Hubcap Manifest
-- Purr in Bloom
-- Created: August 13, 2026 at 10:30:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4966840) -- Purr in Bloom
-- MAIN APP DEPOTS
addappid(4966841, 1, "7abf1ade9887a973a302aee34e8b8e176e5a38d1c2824cc0a43b1133bad9bbf3") -- Depot 4966841
setManifestid(4966841, "4589276555450408434", 278264101)