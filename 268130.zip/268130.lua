-- Lua provided by SkyAPI 
-- Game: Heat Signature
addappid(268130)
addappid(268131, 1, "c24a36c5acb159e883e2ffe2892c877f2fec4aed8d6ad69ec16dd706e312d2ba")
addappid(710350, 0, "4143c404ab7b173a30f8f4b6ec80055e1461981b2d83e44b646111706f71bdf8")
