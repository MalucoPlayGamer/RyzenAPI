-- Lua provided by RyzenAPI
-- Game: Heat Signature

-- MAIN APPLICATION
addappid(268130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(268131, 1, "c24a36c5acb159e883e2ffe2892c877f2fec4aed8d6ad69ec16dd706e312d2ba")
addappid(710350, 0, "4143c404ab7b173a30f8f4b6ec80055e1461981b2d83e44b646111706f71bdf8")

