-- Lua provided by RyzenAPI
-- Game: Fog of War

-- MAIN APPLICATION
addappid(574080)
-- Game: addappid(574080)

-- MAIN APP DEPOTS / PACKAGES
addappid(574081, 1, "296d570cbd983d05b0eec5673a457cb2a5cecac935591b0a73e511dc6951e41a")
addappid(628970, 0, "5e1c55e25461ed962eee2d8a4f21b0f31b3ce706c52ad4467bf72edd421ab28d")
