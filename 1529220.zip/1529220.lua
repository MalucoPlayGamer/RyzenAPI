-- Lua provided by RyzenAPI
-- Game: Block'Em!

-- MAIN APPLICATION
addappid(1529220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1529221, 1, "14ae9925564608061bd09ce1d6d7c5c002cc0aba1acaedbf0105bd1874423231")

