-- Lua provided by RyzenAPI
-- Game: addappid(1529220)

-- MAIN APPLICATION
addappid(1529220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529221, 1, "14ae9925564608061bd09ce1d6d7c5c002cc0aba1acaedbf0105bd1874423231")
