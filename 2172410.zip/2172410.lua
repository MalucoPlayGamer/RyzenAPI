-- Lua provided by RyzenAPI
-- Game: 2172410

-- MAIN APPLICATION
addappid(2172410)
-- Game: addappid(2172410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172411, 1, "177588d212c0a5fbcc8a844fdc6a97094d1e1d19a434a289574f602c3afcf8d8")
