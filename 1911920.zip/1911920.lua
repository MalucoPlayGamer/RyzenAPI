-- Lua provided by RyzenAPI
-- Game: 1911920

-- MAIN APPLICATION
addappid(1911920)
-- Game: addappid(1911920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911921, 1, "5260c6631bbce6e31389ffc6a8ddbaef41d02e6a80289436138cde1f06ed5f82")
