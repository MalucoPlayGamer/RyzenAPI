-- Lua provided by RyzenAPI
-- Game: Venture's Gauntlet VR Demo

-- MAIN APPLICATION
addappid(1911920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911921, 1, "5260c6631bbce6e31389ffc6a8ddbaef41d02e6a80289436138cde1f06ed5f82")
