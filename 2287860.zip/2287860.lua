-- Lua provided by RyzenAPI
-- Game: Game: Rusted Moss Artbook

-- MAIN APPLICATION
addappid(2287860)
-- Game: addappid(2287860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287861, 1, "2d921fdc2b25720ee78a5d057f91280d7e8ee9c7301421765de5a22348edef62")
addappid(2287862, 1, "6892dae3181c49256d1ee2ab48d93c12281d1ebaf965b22ae99102d8080df03a")
addappid(2287863, 1, "554ff2f4b5f0b1d99e37832ef906f415d0c43ac494e74e16e777d69aa930f9cf")
addappid(2287864, 1, "e1cdd92959542cca4347bf97a9750d70501f70a0e5aab6d065d6f4e421430752")
addappid(2287865, 1, "7f04b82b9bff9ae2e8d14e87a0e74331006ebdfda27a7d5bf278864dab1ec8c6")
