-- Lua provided by RyzenAPI
-- Game: AppID 876960

-- MAIN APPLICATION
addappid(876960)

-- MAIN APP DEPOTS / PACKAGES
addappid(876961, 1, "5df41c849248e568e37ebe5e8c74b32ebbfda823d0917ccce2eacf01eaf45929")
addappid(876962, 1, "97b7185a6ef1d4becb52b7b490067fae81f2de2bbbbc448989b56c557f755475")
