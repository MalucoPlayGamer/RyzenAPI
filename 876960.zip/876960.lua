-- Lua provided by RyzenAPI
-- Game: AppID 876960

-- MAIN APPLICATION
addappid(876960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(876961, 1, "5df41c849248e568e37ebe5e8c74b32ebbfda823d0917ccce2eacf01eaf45929")
addappid(876962, 1, "97b7185a6ef1d4becb52b7b490067fae81f2de2bbbbc448989b56c557f755475")

