-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1930660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930660,0,"32e8bfe85b82f45dbd5b34ee35c7ee25e92f64f3e6335d7108acd0504807751f")
