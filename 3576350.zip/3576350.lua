-- Lua provided by RyzenAPI 
-- Game: Sex, Secrets & Used Tech
addappid(3576350)
addappid(3576351, 1, "a81a90790f79399b98a8563d1cb099b157662333dd4bac8c1a0060086797e56b")
addappid(4687240, 0, "744448e72018b51db6274ce8a99abdce9989f5d69f64c6da501a77e970363d7f")
