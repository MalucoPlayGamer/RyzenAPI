-- Lua provided by RyzenAPI
-- Game: 1218960

-- MAIN APPLICATION
addappid(1218960)
-- Game: addappid(1218960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218961, 1, "430b1e4a599fb861beaa2aaee8839004a74f29f240239d382f7a4e5f2e58ab2d")
