-- Lua provided by RyzenAPI
-- Game: 2901810

-- MAIN APPLICATION
addappid(2901810)
-- Game: addappid(2901810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901811, 1, "643fa995b4d7c8c5ae45014441b22d8e7d9b294ef57c09cde1c0a88fee8534b9")
