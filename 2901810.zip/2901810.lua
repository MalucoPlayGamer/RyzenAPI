-- Lua provided by RyzenAPI
-- Game: Supermrket: El Videojuego de Gestión de Supermercado

-- MAIN APPLICATION
addappid(2901810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901811, 1, "643fa995b4d7c8c5ae45014441b22d8e7d9b294ef57c09cde1c0a88fee8534b9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2901830)
addappid(2901840)
addappid(2901850)
addappid(3081200)
addappid(3108170)
addappid(3163500)
addappid(3250870)
addappid(3269190)
addappid(3278990)
addappid(3311870)
addappid(3359250)
addappid(3422920)
addappid(3429370)
addappid(3442920)
addappid(3519200)
addappid(3521420)
addappid(3547290)
addappid(3558690)
addappid(3590310)
addappid(3608280)
addappid(3614550)
addappid(3628080)
addappid(3649250)
addappid(3723660)
addappid(3736770)
addappid(3865530)
addappid(3908460)
addappid(3999300)
addappid(4034970)
addappid(4127580)
addappid(4170180)
addappid(4273970)
addappid(4285900)
addappid(4289690)
addappid(4368050)
addappid(4411130)
addappid(4443900)
addappid(4487330)
addappid(4595680)
