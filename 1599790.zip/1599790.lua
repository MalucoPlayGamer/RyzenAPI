-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack

-- MAIN APPLICATION
addappid(1599790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599790,0,"a3bf28e97a63413dc653f3831917127559328979dba2e70dc2bb54486140ee92")
