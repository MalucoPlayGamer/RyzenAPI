-- Lua provided by RyzenAPI
-- Game: 775890

-- MAIN APPLICATION
addappid(775890)
-- Game: addappid(775890)

-- MAIN APP DEPOTS / PACKAGES
addappid(775891, 1, "7b819fbac8a0cca3374862d423fad5292f2f607a84265101e4804151becf7cfc")
