-- Lua provided by RyzenAPI
-- Game: Mirror Forge

-- MAIN APPLICATION
addappid(1807200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807201, 1, "5307695ff33eac0ee958de2b57f897d2257a10f62a788bf00f5fb1a59ed7b400")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
