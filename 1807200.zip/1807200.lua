-- Lua provided by RyzenAPI
-- Game: Mirror Forge

-- MAIN APPLICATION
addappid(1807200)
-- Game: addappid(1807200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807201, 1, "5307695ff33eac0ee958de2b57f897d2257a10f62a788bf00f5fb1a59ed7b400")
