-- Lua provided by RyzenAPI
-- Game: Mushroom Wars 2

-- MAIN APPLICATION
addappid(457730)

-- MAIN APP DEPOTS / PACKAGES
addappid(457731, 1, "9620649449fa6081661a1b17c4051ea5c1d0c21037de9d07a0bf374ae745f732")
addappid(457732, 1, "cac3fb4bffb60322a22295ee5f068b8c5b0074dc54290f693293726715ec2b9e")
addappid(457733, 1, "6469d6c6646a254167a6808a6f3a84e50a2464a1326c31d5ceee2474955973be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1016130)
