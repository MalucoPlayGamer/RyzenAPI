-- Lua provided by RyzenAPI
-- Game: Dragon Age™ II - The Black Emporium

-- MAIN APPLICATION
addappid(1295714)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295714,0,"4a05d3a258fd412997dc8d34addf54d5a0e9fc5ea44404f77cf8d35005e0c713")
addappid(1296040,0,"18a80098680e6c1609323583411d9d73339f0030e8e4fea8ce90977215c9cefc")
addappid(1296041,0,"2afb8ec739f8888be9ef32ff30ca4081bd2a99bb25659f03267d6afe1e0a204d")
addappid(1296042,0,"f285fb6b602b000de4f91bb0071e955fbbebff13bb04a863b80e08e473f05136")
addappid(1296043,0,"cfee28400277440f702c2e3531228baba2991409ed0fffacc7f7b6edfede3fcd")
addappid(1296044,0,"f63e4181c7c1e1cdabab83656c9d041f2db3a343899be90b84e6b6c6ab7abbc0")
addappid(1296045,0,"c6316fa9deeeee62a63877993cb5f9eebbb84b5db958438860be9c71e3c70d89")
addappid(1296046,0,"4b75bd0eac6b7c80ce9e448d99c836c75f78f2cb2c7254871021f0a214d452df")

