-- Lua provided by RyzenAPI
-- Game: addappid(1693680)

-- MAIN APPLICATION
addappid(1693680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693681, 1, "55e1f1cd3eb17a8f50d8a8859647a9e528f3d54af62a67753b26bb3c3c2f871a")
