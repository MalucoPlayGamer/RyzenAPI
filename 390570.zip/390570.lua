-- Lua provided by RyzenAPI
-- Game: addappid(390570)

-- MAIN APPLICATION
addappid(390570)

-- MAIN APP DEPOTS / PACKAGES
addappid(390571, 1, "286d8cb6a5d132ea759f4faa3d50d66ce4d8016b68906bb390730cc444bf4ae4")
addappid(390572, 1, "610364b745878c2af9691637f1b79707420e973918ac72972e321502a20f7129")
addappid(390573, 1, "b002ffa5a11787a6d09d0dcbe9de7f8f6bdd0f814aebceac91f99c93fac66154")
addappid(394400, 0, "dceeba6f7fe4e9cffa7a89b3ed7a0da5cb7ef3855ecd11fe6ca9e4b8ba640ab7")
