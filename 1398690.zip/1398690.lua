-- Lua provided by RyzenAPI
-- Game: Game: Negligee: Opposites Attract

-- MAIN APPLICATION
addappid(1398690)
-- Game: addappid(1398690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398691, 1, "1a90f9da72dc9117ea4fb42355e55a929f7d87df78cabc60d0e1558a6d957b3e")
