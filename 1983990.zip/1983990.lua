-- Lua provided by RyzenAPI
-- Game: Nexus 5X

-- MAIN APPLICATION
addappid(1983990)
-- Game: addappid(1983990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983991, 1, "61ce22191991809930ce4d28b581132ca4a3de2deb870934cbbbedf6f1b4bcd5")
