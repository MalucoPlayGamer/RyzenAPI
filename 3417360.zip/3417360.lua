-- Lua provided by RyzenAPI
-- Game: 3417360

-- MAIN APPLICATION
addappid(3417360)
-- Game: addappid(3417360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3417361, 1, "0f7403813528eca231fa1f7b527aad7c3fa5d35fbee3b4cf30b5bdc7a39fe4bc")
