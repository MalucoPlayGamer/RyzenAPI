-- Lua provided by RyzenAPI
-- Game: Game: AppID 2605840

-- MAIN APPLICATION
addappid(2605840)
-- Game: addappid(2605840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605841, 1, "338e0252b5e03de25a6ce47631e302164a80a4d74e3812bc300d7b5a6a21ae53")
