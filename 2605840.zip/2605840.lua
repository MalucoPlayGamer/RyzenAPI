-- Lua provided by SkyAPI 
-- Game: AppID 2605840
addappid(2605840)
addappid(2605841, 1, "338e0252b5e03de25a6ce47631e302164a80a4d74e3812bc300d7b5a6a21ae53")
