-- Lua provided by RyzenAPI
-- Game: Archons Demo

-- MAIN APPLICATION
addappid(3192850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192851, 1, "fe143596c6aeee432256c5cdcd2c4813e7f632fa6c6a1d8049d0c88cc4d5a85e")

