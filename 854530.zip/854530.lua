-- Lua provided by RyzenAPI
-- Game: Paper Shakespeare: Stick Julius Caesar (with a dagger)

-- MAIN APPLICATION
addappid(854530)
addappid(913610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(854531, 1, "4f8170798080454f0cb84dc35f88f5f30cd2b6b2c32229be18cc6507495b678d")
addappid(854532, 1, "6d592173eaa61079fd9cedc35069d0e8dfca1590ccc09378e7e71bbeec42e6b3")
addappid(854533, 1, "8aa6521b215fc538d9f74dbed66fb15d2c0337de96179b9ebad396f96d7245d4")
addappid(913611, 0, "4354c028e66415f70f1c3520ed9e81fd852847190e538853ad55f61df3dd7481")
addappid(913614, 0, "a4e111bc8c7e0064ab13473ff11ee36905e09807e39a1b68517e30267075e2db")
addappid(913617, 0, "2fb96c23b620d39dd494c6d922aaf22627362643b775820d814fc41a168a474f")

