-- Lua provided by RyzenAPI
-- Game: addappid(955320)

-- MAIN APPLICATION
addappid(955320)
addappid(981610)

-- MAIN APP DEPOTS / PACKAGES
addappid(955321, 1, "2a17707471a2484fae3e8d3ff7a50c0fea555690ea9fa158fe07e895744113b1")
