-- Lua provided by RyzenAPI
-- Game: addappid(1609220)

-- MAIN APPLICATION
addappid(1609220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609221, 1, "295aad64299afe6fff12a7d12c8a0d94ddc6255698747ac1472dda7ddcb9c3d3")
