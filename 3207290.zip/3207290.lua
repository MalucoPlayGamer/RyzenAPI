-- Lua provided by RyzenAPI
-- Game: 3207290

-- MAIN APPLICATION
addappid(3207290)
-- Game: addappid(3207290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207291, 1, "87c1ca8cf33015bcb17e57fc4e5406b39424d93d001ca3007b6f260184c0d25a")
