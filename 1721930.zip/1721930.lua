-- Lua provided by RyzenAPI
-- Game: 1721930

-- MAIN APPLICATION
addappid(1721930)
-- Game: addappid(1721930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721931, 1, "233a7204fda1d4d67f4647602e6aad1d85901f28570fc46704e2a8bf18fb1ec8")
