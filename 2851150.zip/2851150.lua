-- Lua provided by RyzenAPI
-- Game: 2851150

-- MAIN APPLICATION
addappid(2851150)
-- Game: addappid(2851150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2851151, 1, "57976f1df203b53aea3c948a23be724ecd0e0ecc6388d148dbf2f721b0c4daab")
