-- Lua provided by RyzenAPI
-- Game: AppID 2843760

-- MAIN APPLICATION
addappid(2843760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843761, 1, "86e2b51c88c0d94cca6a806d358a3c77cb4aacf879ffc81ca87890eb7bb63ab2")
