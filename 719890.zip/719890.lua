-- Lua provided by RyzenAPI
-- Game: AppID 719890

-- MAIN APPLICATION
addappid(719890)

-- MAIN APP DEPOTS / PACKAGES
addappid(719891, 1, "2da829832bc98bf02ca57d2657259de6374b9c0eb55da360e231471310319cea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2231260)
addappid(2665720)
addappid(2665730)
addappid(2665740)
addappid(2665750)
addappid(2665760)
addappid(2665770)
addappid(2665780)
addappid(2665790)
addappid(2665800)
addappid(2665810)
addappid(2665820)
addappid(2665830)
addappid(2665840)
addappid(2665850)
addappid(2665860)
addappid(2665870)
addappid(2665880)
addappid(2665890)
addappid(2665900)
addappid(2832670)
addappid(3600660)
addappid(3914220)
