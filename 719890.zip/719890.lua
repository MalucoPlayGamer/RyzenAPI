-- Lua provided by RyzenAPI
-- Game: Game: AppID 719890

-- MAIN APPLICATION
addappid(719890)
-- Game: addappid(719890)

-- MAIN APP DEPOTS / PACKAGES
addappid(719891, 1, "2da829832bc98bf02ca57d2657259de6374b9c0eb55da360e231471310319cea")
