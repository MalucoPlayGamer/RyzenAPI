-- Lua provided by RyzenAPI
-- Game: 933531

-- MAIN APPLICATION
addappid(933531)

-- MAIN APP DEPOTS / PACKAGES
addappid(933531,0,"a6d33c84b6a97c821f1c96b78a6e6becef1d002e8cbb4f43e9b04714db2a92c0")

