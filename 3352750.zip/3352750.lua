-- Lua provided by RyzenAPI
-- Game: Kings of Emperor Bonaparte

-- MAIN APPLICATION
addappid(3352750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3352751, 1, "0d0343e377350f89c56a81f692e8eb06a9549cbb47c607660bb2502de8f4dd85")

