-- Lua provided by RyzenAPI
-- Game: addappid(722670)

-- MAIN APPLICATION
addappid(722670)

-- MAIN APP DEPOTS / PACKAGES
addappid(722671, 1, "abe2a90907af2d70d578d4159039c8bfacf35e28ac123dc20b2de4de1f64c425")
