-- Lua provided by RyzenAPI
-- Game: からかい上手の高木さんVR 1学期

-- MAIN APPLICATION
addappid(1264160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264161, 1, "73f7c16f3b54f8f57f8ff434b304c2fbb22817db25aa6fe906400970c874ff60")

