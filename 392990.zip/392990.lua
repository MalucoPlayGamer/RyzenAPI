-- Lua provided by RyzenAPI
-- Game: PCE Open Testing Beta

-- MAIN APPLICATION
addappid(392990)

-- MAIN APP DEPOTS / PACKAGES
addappid(392992,0,"404a53de29bafac3f65e00419715ba7dd611039be66c8092324b9dc6c62ba8ba")
addtoken(392990,"4916025423347788954")

