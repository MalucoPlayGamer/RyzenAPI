-- Lua provided by RyzenAPI
-- Game: AppID 709970

-- MAIN APPLICATION
addappid(709970)
-- Game: addappid(709970)

-- MAIN APP DEPOTS / PACKAGES
addappid(709971, 1, "2d3cf2956886490a84cc87c3f5a6ee819a31a97b2987aef49a4c8e99d969530a")
