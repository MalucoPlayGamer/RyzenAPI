-- Lua provided by RyzenAPI
-- Game: Out Of Hands

-- MAIN APPLICATION
addappid(1839810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839811, 1, "b86d28be2ce99299dbc3db1499c914ce7f15674cf0e72b57198e772c2f1d72d7")
addappid(3627570, 0, "eeae46b3c3a3fe4436f401da403094032b0f05928202f0e430fa6d53e3abd4a8")
