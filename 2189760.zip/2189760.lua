-- Lua provided by RyzenAPI
-- Game: addappid(2189760)

-- MAIN APPLICATION
addappid(2189760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2189761, 1, "034baa4c9608eb18d0f2ec2a566bfb228fcfbcdf733ba42f229b020f3751e81f")
