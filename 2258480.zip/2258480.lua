-- Lua provided by SkyAPI 
-- Game: Gunforged
addappid(2258480)
addappid(2258481, 1, "6df52b2eea89d0847a6698de37970a2a2a79dec36100c519b54ca0c894f02afb")
