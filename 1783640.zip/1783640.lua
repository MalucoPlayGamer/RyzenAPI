-- Lua provided by RyzenAPI
-- Game: Defend the Rook - Supporter Pack

-- MAIN APPLICATION
addappid(1783640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783640,0,"4dabba82710270da92631488d856f3b786e474ab2bb3241063aa10583cdf9709")

