-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1432175)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432175,0,"525148eecf5992d7661b24c0aa815bf694957608a9bea31972fd3b89f372709f")

