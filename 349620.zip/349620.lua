-- Lua provided by RyzenAPI
-- Game: BlastZone 2 Demo

-- MAIN APPLICATION
addappid(349620)

-- MAIN APP DEPOTS / PACKAGES
addappid(349621, 1, "c7bfffa60ee536d1a05be7d7c7236578a0dc93c85ea80cad7e402b945d635e1c")
addappid(349622, 1, "2959a2d46f3d0ad96a969202b867e8a4d09381a9bed990686c49295a90b672e3")
addappid(349623, 1, "96bab2d27dfbb7e6d10d7470565090b7d2d4fe48f84728bc95da49b0ae8cab06")

