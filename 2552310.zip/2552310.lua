-- Lua provided by RyzenAPI
-- Game: Dungeon Inn

-- MAIN APPLICATION
addappid(2552310)
-- Game: addappid(2552310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2552311, 1, "a48d53d95522fbe56c2435f9f17d6b85e7280d997aaeda7da4de01790c56e4ad")
addappid(2552312, 1, "26d5b1f4ba7d0b90411ce8ba61c678e1b6e3b5ca07c7d8175c3ab02a9b4dfa1c")
