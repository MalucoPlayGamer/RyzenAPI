-- Lua provided by RyzenAPI
-- Game: Game: Survival RPG Alisa x Desperate City

-- MAIN APPLICATION
addappid(1565760)
-- Game: addappid(1565760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565761, 1, "0cb5b670d33523c9a4ed02564ddee417a11aa9ca534100f9e8abf2d39bae3104")
addappid(1565762, 1, "2638501a7b4091d56f0697c7debb7aa9cb161ba5c84ac3bcdf2658c0afa5e9cc")
