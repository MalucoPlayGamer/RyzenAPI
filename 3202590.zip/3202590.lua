-- Lua provided by RyzenAPI
-- Game: Game: The Forever Winter Soundtrack

-- MAIN APPLICATION
addappid(3202590)
-- Game: addappid(3202590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202591, 1, "8da4f5d9fd3c7f98a82862356c36d8f81a50569e04685670ba0985cd42d2838a")
addappid(3202592, 1, "b6cc63f60343cbe6299bf0cbf94ccf124cf93641f3806dc46685e77db19b2fee")
