-- Lua provided by RyzenAPI
-- Game: Chromatic

-- MAIN APPLICATION
addappid(660070)

-- MAIN APP DEPOTS / PACKAGES
addappid(660071, 1, "427459e0a21c0c1bf79ea58e9530a9c7d914cc6f44eb8e6fcbd5afc6f73b1d34")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
