-- Lua provided by RyzenAPI
-- Game: addappid(660070)

-- MAIN APPLICATION
addappid(660070)

-- MAIN APP DEPOTS / PACKAGES
addappid(660071, 1, "427459e0a21c0c1bf79ea58e9530a9c7d914cc6f44eb8e6fcbd5afc6f73b1d34")
