-- Lua provided by RyzenAPI
-- Game: Game: Summon: Joint escape

-- MAIN APPLICATION
addappid(2998970)
-- Game: addappid(2998970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998971, 1, "00db5047f3d2a4415beb02b2afc948c0e8309db0d57098abb58d06b52fd36cd0")
