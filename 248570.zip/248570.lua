-- Lua provided by RyzenAPI
-- Game: Toribash

-- MAIN APPLICATION
addappid(248570)

-- MAIN APP DEPOTS / PACKAGES
addappid(248571, 1, "7dce6fc888fda7a03f9a14f734e9728651c38dd2088e55790a963bfb840bd936")
addappid(248572, 1, "e435781d5c303044c9105a63407be1229aeb7bb0f11e19e0f9734b45977ef980")
addappid(248573, 1, "cdfc1f9b68b1b07ec4e1843207da8e5043555b40f6c87c2dec51729f7d19631a")
addappid(248574, 1, "8e2575a4735bcd887694e725aedb33abdf5a68aeed05624c5d787deeda31b541")
addappid(248575, 1, "0d513af3d252e1449351128b23b252ddb05bddee6e063aa14749f179ffbe4bff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
