-- Lua provided by RyzenAPI
-- Game: Game: Toribash

-- MAIN APPLICATION
addappid(248570)
-- Game: addappid(248570)

-- MAIN APP DEPOTS / PACKAGES
addappid(248571, 1, "7dce6fc888fda7a03f9a14f734e9728651c38dd2088e55790a963bfb840bd936")
addappid(248572, 1, "e435781d5c303044c9105a63407be1229aeb7bb0f11e19e0f9734b45977ef980")
addappid(248573, 1, "cdfc1f9b68b1b07ec4e1843207da8e5043555b40f6c87c2dec51729f7d19631a")
addappid(248574, 1, "8e2575a4735bcd887694e725aedb33abdf5a68aeed05624c5d787deeda31b541")
addappid(248575, 1, "0d513af3d252e1449351128b23b252ddb05bddee6e063aa14749f179ffbe4bff")
