-- Lua provided by SkyAPI 
-- Game: Fatekeeper
addappid(2186990)
addappid(2186991, 1, "fb5bfe71c8da540f80d2f72b4ca3cb6a77872984c310ebde5a277944271ac88f")
