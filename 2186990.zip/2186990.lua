-- Lua provided by RyzenAPI
-- Game: Fatekeeper

-- MAIN APPLICATION
addappid(2186990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186991, 1, "fb5bfe71c8da540f80d2f72b4ca3cb6a77872984c310ebde5a277944271ac88f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
