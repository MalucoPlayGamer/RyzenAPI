-- Lua provided by RyzenAPI
-- Game: addappid(748490)

-- MAIN APPLICATION
addappid(748490)

-- MAIN APP DEPOTS / PACKAGES
addappid(748491, 1, "e76ee9043ce59e5c36abd110d68779207bf1d8911020db5c2c0bc47d7640a6d3")
