-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails of Cold Steel II

-- MAIN APPLICATION
addappid(748490)
addappid(773110)
addappid(773760)
addappid(773761)
addappid(773762)
addappid(773763)
addappid(773765)
addappid(773800)
addappid(773801)
addappid(773802)
addappid(773803)
addappid(773804)
addappid(773805)
addappid(773806)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(748491,0,"e76ee9043ce59e5c36abd110d68779207bf1d8911020db5c2c0bc47d7640a6d3")

