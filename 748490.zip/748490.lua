-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails of Cold Steel II

-- MAIN APPLICATION
addappid(748490)
addappid(773110)
addappid(773760)
addappid(773761)
addappid(773762)
addappid(773763)
addappid(773765)
addappid(773800)
addappid(773801)
addappid(773802)
addappid(773803)
addappid(773804)
addappid(773805)
addappid(773806)

-- MAIN APP DEPOTS / PACKAGES
addappid(748491,0,"e76ee9043ce59e5c36abd110d68779207bf1d8911020db5c2c0bc47d7640a6d3")

