-- Lua provided by SkyAPI 
-- Game: Dawn of Discovery™
addappid(33210)
addappid(33211, 1, "2a33fe0af755f45e346dad45e888630dac32e12694da2e9ba5bb2fee0e771c54")
addappid(33215, 1, "094cf0f9e87ba8f9cceddb4c87c4e261e286415fd6f7465b02bba49edbf88248")
