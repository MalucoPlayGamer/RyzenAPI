-- Lua provided by SkyAPI 
-- Game: DaVinCo
addappid(1783500)
addappid(1783501, 1, "3c9544503213796f11a1ff76c4c5cafbd51c7a5f95b2739f29d45532e96a4319")
addappid(1783502, 1, "01e41eb114d004fdaf44f27642f5e0c94d0b630a8de4a906e7fdf3fee661f893")
