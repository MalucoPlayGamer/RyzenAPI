-- Lua provided by RyzenAPI
-- Game: DaVinCo

-- MAIN APPLICATION
addappid(1783500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1783501, 1, "3c9544503213796f11a1ff76c4c5cafbd51c7a5f95b2739f29d45532e96a4319")
addappid(1783502, 1, "01e41eb114d004fdaf44f27642f5e0c94d0b630a8de4a906e7fdf3fee661f893")

