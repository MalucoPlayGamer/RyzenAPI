-- Lua provided by RyzenAPI
-- Game: Desktop Pet Project

-- MAIN APPLICATION
addappid(2618940)
-- Game: addappid(2618940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618941, 1, "44a90b38e315470d7d073ae3f0f39b1c4072c9473c561942978d3e8236d4c763")
