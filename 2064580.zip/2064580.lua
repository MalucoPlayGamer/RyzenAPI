-- Lua provided by RyzenAPI
-- Game: Hausmeister

-- MAIN APPLICATION
addappid(2064580)
-- Game: addappid(2064580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064581, 1, "0f9e0b0441014c5dd03500137d27a4410962764abd80511abc62d5f6ad1741dc")
