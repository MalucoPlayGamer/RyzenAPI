-- Lua provided by RyzenAPI
-- Game: Mireille and Amrita, the Forest of Illusions

-- MAIN APPLICATION
addappid(1743530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743531, 1, "138cab1f61e14709deddae7eec945c1a4d390d7de6b23431ed1e0101e438242d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2260830)
