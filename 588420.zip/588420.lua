-- Lua provided by RyzenAPI
-- Game: Uncompromising Trash

-- MAIN APPLICATION
addappid(588420)

-- MAIN APP DEPOTS / PACKAGES
addappid(588421, 1, "bdeae07bb6bc38379c812e8c00d99bc6da6ecd79b4c8bcaf23d5c0720f04959a")

