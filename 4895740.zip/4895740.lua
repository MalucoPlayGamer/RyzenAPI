-- Lua provided by RyzenAPI
-- Game: Proyecto Huemul

-- MAIN APP DEPOTS / PACKAGES
addappid(4895740, 1, "adfb3ce35b4701bc98a671cb1f5a88209ef9bd89c827b6f4e172a1e85235ecd5") -- Proyecto Huemul
addappid(4895741, 1, "0714adb853f405a91f32e27f56ecd4774a471c1fe38a9e0089d6b0ceac07ba10") -- Depot 4895741
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
