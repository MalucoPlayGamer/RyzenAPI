-- Lua provided by RyzenAPI
-- Game: Across the Obelisk Demo

-- MAIN APPLICATION
addappid(1421400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385381,0,"212b4c54a7dadad3bb6a4a55088868dde54c128e58d7ce4afab3363c77ba1383")

