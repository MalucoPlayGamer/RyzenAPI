-- Lua provided by RyzenAPI
-- Game: Game: Wheelie King 5

-- MAIN APPLICATION
addappid(2304550)
-- Game: addappid(2304550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304551, 1, "5a50657d6eb2498842e1ac0708ae2df26c99fbce886ce65b681b6a56c0a94bd7")
