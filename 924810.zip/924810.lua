-- Lua provided by RyzenAPI
-- Game: AppID 924810

-- MAIN APPLICATION
addappid(924810)

-- MAIN APP DEPOTS / PACKAGES
addappid(924811, 1, "4fde2fc2be9225f8ceef136e6895c28f1a046b07e196471d818bae668bcc58c6")
