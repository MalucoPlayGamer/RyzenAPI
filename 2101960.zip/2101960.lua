-- Lua provided by RyzenAPI
-- Game: Cronos: The New Dawn

-- MAIN APPLICATION
addappid(2101960)
addappid(3748540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101961, 1, "7f2c42a3171b51a0ea7463a8acbf143d1341f27c8e7babad3fa9eeef66f133eb")
addappid(2101962, 1, "d3f3ea72d940025825a5859f4747ec70d37c6b3df38f8ec038c1c70911d4e0ac")
addappid(3748551, 1, "a00d5fc8b73f7250ff62ca6a67441ad191eb2a2415db2d0db193285a7bb92780")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3748530)
addappid(3748550)
addappid(4768180)
