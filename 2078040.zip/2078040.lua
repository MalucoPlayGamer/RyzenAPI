-- Lua provided by RyzenAPI
-- Game: White Day 2: The Flower That Tells Lies - Complete Edition

-- MAIN APPLICATION
addappid(2078040)
addappid(2079900)
addappid(2277190)
addappid(2277191)
addappid(2277480)
addappid(2277481)
addappid(2279900)
addappid(2279901)
addappid(2279902)
addappid(2279903)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078041, 1, "5472ba4226b347600963043344b79eeb090dd333fe9a97cdf09c3f310b4e15af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
