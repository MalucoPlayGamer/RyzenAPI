-- Lua provided by RyzenAPI
-- Game: AppID 1935410

-- MAIN APPLICATION
addappid(1935410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935411, 1, "a160a6d74f9dfc771e2bb790093dd20caf54d6c68dd84dd3bccf1b8e46a33088")
