-- Lua provided by RyzenAPI
-- Game: addappid(1055490)

-- MAIN APPLICATION
addappid(1055490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055491, 1, "18a57e47ef8ea8387e71fbe8344f835d7a5fdd8023d05df58ce1ba3eb1d707d0")
