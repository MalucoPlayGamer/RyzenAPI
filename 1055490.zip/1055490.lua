-- Lua provided by RyzenAPI
-- Game: AppID 1055490

-- MAIN APPLICATION
addappid(1055490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055491, 1, "18a57e47ef8ea8387e71fbe8344f835d7a5fdd8023d05df58ce1ba3eb1d707d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
