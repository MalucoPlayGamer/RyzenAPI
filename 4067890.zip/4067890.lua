-- 4067890's Lua and Manifest Created by Hubcap Manifest
-- Tulip Season
-- Created: July 25, 2026 at 06:07:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4067890) -- Tulip Season
-- MAIN APP DEPOTS
addappid(4067891, 1, "1a7591ddac8c7b56e100d97e75a43c15ee111c8f25ba9f0023e4b3df83c54e46") -- Depot 4067891
setManifestid(4067891, "7655921651204821793", 165133496)