-- Lua provided by RyzenAPI
-- Game: 283330

-- MAIN APPLICATION
addappid(283330)
-- Game: addappid(283330)

-- MAIN APP DEPOTS / PACKAGES
addappid(283331, 1, "28c64897fda8cb0e156f21c683e18777d649a768d78d34fc168663013cc83a09")
