-- Lua provided by RyzenAPI
-- Game: Tongue of Dog

-- MAIN APPLICATION
addappid(1990540)
addappid(3607060)
addappid(3607250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990541, 1, "8c8e8afc160950bf485b41be84ed7c8da843605b139019b5551eef24d5fbf3da")

