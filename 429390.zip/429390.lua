-- Lua provided by RyzenAPI
-- Game: XenoShyft

-- MAIN APPLICATION
addappid(429390)
addappid(429820)
addappid(429870)
addappid(429871)
addappid(429872)
addappid(719260)
addappid(948390)

-- MAIN APP DEPOTS / PACKAGES
addappid(429392,0,"144d6adfb3b8f9177aadff00d0c4569fcb932ef7efada68f3e22d08292ebe4af")

