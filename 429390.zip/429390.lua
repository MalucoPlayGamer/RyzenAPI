-- Lua provided by RyzenAPI
-- Game: 429390

-- MAIN APPLICATION
addappid(429390)

-- MAIN APP DEPOTS / PACKAGES
addappid(429392,0,"144d6adfb3b8f9177aadff00d0c4569fcb932ef7efada68f3e22d08292ebe4af")
