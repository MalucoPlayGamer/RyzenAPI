-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: Labyrinth of Lies

-- MAIN APPLICATION
addappid(572710)

-- MAIN APP DEPOTS / PACKAGES
addappid(572711,0,"48c263978585d11e571c42d6408b1a826ec74a85bfde41773ddb95505e9d108d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(954110)
