-- Lua provided by RyzenAPI
-- Game: 不和我推谈恋爱就会死？！ Demo

-- MAIN APPLICATION
addappid(2413630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413632,0,"be9ef90b47a9c78f6936a6eb3631c6ef837851a140906b28d38e02822483e20a")
