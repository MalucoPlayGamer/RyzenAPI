-- Lua provided by RyzenAPI
-- Game: Joe and the Gun

-- MAIN APPLICATION
addappid(1560130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560131, 1, "6f1d5258de2434b9f296670f59051968639a59c7b55677eefa98c31ee984c682")
