-- Lua provided by RyzenAPI
-- Game: Battleground Shooting Training 吃鸡枪法训练器

-- MAIN APPLICATION
addappid(840090)
-- Game: addappid(840090)

-- MAIN APP DEPOTS / PACKAGES
addappid(840091, 1, "26795bee23f5a60872f9b1f664626e92b3bcdf61f3202d9699881d4da4535be4")
