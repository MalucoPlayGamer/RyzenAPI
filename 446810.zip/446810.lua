-- Lua provided by RyzenAPI
-- Game: Blossom Tales: The Sleeping King

-- MAIN APPLICATION
addappid(446810)

-- MAIN APP DEPOTS / PACKAGES
addappid(446811, 1, "5ac945ee4fe8717b56368fbed5b9a93c45df9438447e908bf5e3eaa579fefe0a")
addappid(601190, 0, "5d77b3862ea33b0a5e9cc39ea36dae7ab49f766a56c533b4c3a3182d8a0b98ca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
