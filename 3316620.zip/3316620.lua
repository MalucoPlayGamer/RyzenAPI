-- Lua provided by RyzenAPI
-- Game: Prove You Can Win

-- MAIN APPLICATION
addappid(3316620)
-- Game: addappid(3316620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3316621, 1, "9e02597fbc3c69cd7081c2e48d929ea92947f81877dccc224141de03fb5738a6")
