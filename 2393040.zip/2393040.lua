-- Lua provided by RyzenAPI
-- Game: 2393040

-- MAIN APPLICATION
addappid(2393040)
-- Game: addappid(2393040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393041, 1, "2cc9745530ec5bd45c1da0fe01a53b28e8fa8f65ad25fe0175945230d9ee4170")
