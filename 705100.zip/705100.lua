-- Lua provided by RyzenAPI
-- Game: Marshmallow Melee

-- MAIN APPLICATION
addappid(705100)

-- MAIN APP DEPOTS / PACKAGES
addappid(705101,0,"fbef20be295dda12de17dd0a74a69e185f72518ab630eb616953579ee1f0a6c7")

