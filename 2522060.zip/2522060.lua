-- Lua provided by RyzenAPI
-- Game: Stacks:Jungle!

-- MAIN APPLICATION
addappid(2522060)
-- Game: addappid(2522060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522061, 1, "899d48878fe96456a6d8bd7e935f911c262415d6f359e6442b254a15958b30e5")
addappid(2522062, 1, "d56f31ed3e6502d15d6ad1c8dfab0249f7fd0260a81c7fa010a1ee00ec5c1543")
