-- Lua provided by RyzenAPI
-- Game: 475430

-- MAIN APPLICATION
addappid(475430)
-- Game: addappid(475430)

-- MAIN APP DEPOTS / PACKAGES
addappid(475431, 1, "db2784afc9cd936dd9d7f165bf6d597ef47fb8e7b62dc139a2fbad074866b868")
