-- Lua provided by RyzenAPI
-- Game: Game: Tomboy: Love in Hot Forge

-- MAIN APPLICATION
addappid(2732730)
-- Game: addappid(2732730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732731, 1, "f44060e8bacdd4cd1fc38616d8692f7b738fdee459520e13d0453c45a1ea6cfd")
