-- Lua provided by RyzenAPI 
-- Game: Tomboy: Love in Hot Forge
addappid(2732730)
addappid(2732731, 1, "f44060e8bacdd4cd1fc38616d8692f7b738fdee459520e13d0453c45a1ea6cfd")
