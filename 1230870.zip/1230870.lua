-- Lua provided by RyzenAPI
-- Game: Game: Parameter

-- MAIN APPLICATION
addappid(1230870)
-- Game: addappid(1230870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230871, 1, "1d489f70c51aa9e62f109d975fcea7c15fddd434241a4fc22b5bb3b31ee2950f")
