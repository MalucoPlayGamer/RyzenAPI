-- Lua provided by SkyAPI 
-- Game: CONERU -DIMENSION GIRL- Demo
addappid(3259960)
addappid(3259961, 1, "656a2fb2bdf4177123979155acecaa730fad099636a5bf598950b99386532c32")
