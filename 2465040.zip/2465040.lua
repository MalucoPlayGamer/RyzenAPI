-- Lua provided by RyzenAPI
-- Game: Bad Boro Demo

-- MAIN APPLICATION
addappid(2465040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465041, 1, "b1735c6349e7ea259f580810f8d7828cbdaa7938a1baf630620fedc696543408")
