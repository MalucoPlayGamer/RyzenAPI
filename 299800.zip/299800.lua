-- Lua provided by RyzenAPI
-- Game: Game: The Land of Eyas

-- MAIN APPLICATION
addappid(299800)
-- Game: addappid(299800)

-- MAIN APP DEPOTS / PACKAGES
addappid(299801, 1, "11431b7b8213c68d5e63c995179cf2aaea61657aa57eb69b40af759b6c8c0130")
