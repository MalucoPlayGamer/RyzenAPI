-- Lua provided by RyzenAPI
-- Game: Game: Victory Road

-- MAIN APPLICATION
addappid(1002430)
-- Game: addappid(1002430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002431, 1, "f3c501ffa3812f25dbe49fae69612e11b06dcf978d094740e5f6452049685327")
