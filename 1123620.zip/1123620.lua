-- Lua provided by RyzenAPI
-- Game: Woman's body 3

-- MAIN APPLICATION
addappid(1123620)
-- Game: addappid(1123620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123621, 1, "56872953b73c1e1857af120e0cd68b9602c81df53e5500a8bb7e9377507dce81")
