-- Lua provided by RyzenAPI
-- Game: Rivalry

-- MAIN APPLICATION
addappid(431770)

-- MAIN APP DEPOTS / PACKAGES
addappid(431771, 1, "e11d39bee2b44026d2e0447d514fcc6551a31405ead87f972ae6dcb9e0c43578")
