-- Lua provided by RyzenAPI
-- Game: Soul Rush

-- MAIN APPLICATION
addappid(3298490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298491, 1, "baacaa3a5cac62cacda5cfb57f41ca23f29de39bda99ab7b179910a3f27b2514")

