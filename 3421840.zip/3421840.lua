-- Lua provided by RyzenAPI
-- Game: 宝贝别怕，有我在

-- MAIN APPLICATION
addappid(3421840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3421843,0,"c50d904d142674b0d76f4e98825c345cfb1e6ba8ef6390faa5ff00b3d08f822d")

