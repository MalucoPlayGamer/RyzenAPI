-- Lua provided by RyzenAPI
-- Game: Buffed

-- MAIN APPLICATION
addappid(2934980)
-- Game: addappid(2934980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934981, 1, "8422aefb5dbd26391c504b2cdaa57e94ee3da08aa5e3d21bc8f7242abe94a1f1")
