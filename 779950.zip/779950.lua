-- Lua provided by RyzenAPI
-- Game: addappid(779950)

-- MAIN APPLICATION
addappid(779950)

-- MAIN APP DEPOTS / PACKAGES
addappid(779951, 1, "9cd48fdc36d6a4d95f523380302e490dc92f492948980ebfd6d217ea0da585ff")
