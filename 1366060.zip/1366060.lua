-- Lua provided by RyzenAPI 
-- Game: Refraction
addappid(1366060)
addappid(1366061, 1, "bf675c7a074c9d7982bc773c20624c227eca1f1939b57b9eebe1629034790520")
