-- Lua provided by RyzenAPI
-- Game: Botworld Odyssey

-- MAIN APPLICATION
addappid(2936030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936031, 1, "2dbe3d5c2eb886bcb49ffd60fc6cb3b304782744ba493bb2e01f0b5d6c2b7acf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
