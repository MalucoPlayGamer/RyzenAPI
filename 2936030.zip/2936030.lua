-- Lua provided by RyzenAPI
-- Game: Botworld Odyssey

-- MAIN APPLICATION
addappid(2936030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936031, 1, "2dbe3d5c2eb886bcb49ffd60fc6cb3b304782744ba493bb2e01f0b5d6c2b7acf")

