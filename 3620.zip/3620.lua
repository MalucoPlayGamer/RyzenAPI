-- Lua provided by RyzenAPI
-- Game: Game: Zuma's Revenge!

-- MAIN APPLICATION
addappid(3620)
-- Game: addappid(3620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3621, 1, "9ee6d5a509a1e506ec9631b44cfc944bf31221765ac1d5f10d4adc93ec61cd94")
