-- Lua provided by RyzenAPI
-- Game: 1464400

-- MAIN APPLICATION
addappid(1464400)
-- Game: addappid(1464400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464402,0,"e252d4c750f74b1865127b20c61651a1cd028cc76a701fefbfee5be5db71e329")
