-- Lua provided by RyzenAPI
-- Game: addappid(1623620)

-- MAIN APPLICATION
addappid(1623620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623621, 1, "5567d18204bd3a210b9bf9ed0d45495f212d5aa5de543adc40a8543e51bccd5d")
