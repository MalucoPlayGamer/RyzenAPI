-- Lua provided by RyzenAPI
-- Game: Magic Heroes: Save Our Park

-- MAIN APPLICATION
addappid(616860)

-- MAIN APP DEPOTS / PACKAGES
addappid(616861,0,"f4892d006c2b30fed6dad0f5fdd0ad75417f3db83ba63731fbb17a21add7dde4")

