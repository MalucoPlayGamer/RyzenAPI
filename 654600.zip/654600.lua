-- Lua provided by SkyAPI 
-- Game: AppID 654600
addappid(654600)
addappid(654601, 1, "cd20afb19026afc4d539c6d952dd111c6efb4aefd983ab9f7d9541c660c74df6")
