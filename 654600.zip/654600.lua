-- Lua provided by RyzenAPI
-- Game: AppID 654600

-- MAIN APPLICATION
addappid(654600)
-- Game: addappid(654600)

-- MAIN APP DEPOTS / PACKAGES
addappid(654601, 1, "cd20afb19026afc4d539c6d952dd111c6efb4aefd983ab9f7d9541c660c74df6")
