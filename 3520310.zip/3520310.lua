-- Lua provided by RyzenAPI
-- Game: Game: Where's My Futa Deck?

-- MAIN APPLICATION
addappid(3520310)
-- Game: addappid(3520310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3520311, 1, "429d602a9a6a94ca8e636a269bd16ffb47521aed056008c6f19c66b17979cad6")
