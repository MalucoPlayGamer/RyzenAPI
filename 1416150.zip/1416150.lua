-- Lua provided by RyzenAPI
-- Game: Drilly Willis

-- MAIN APPLICATION
addappid(1416150)
-- Game: addappid(1416150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416151, 1, "80e80cbd5c69f08ba259982924e6224faa14b548507e0284b85ae3fa48ba93cb")
