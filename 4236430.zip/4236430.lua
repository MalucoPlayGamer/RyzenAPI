-- 4236430's Lua and Manifest Created by Hubcap Manifest
-- RentPoly
-- Created: July 23, 2026 at 02:19:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4236430) -- RentPoly
-- MAIN APP DEPOTS
addappid(4236431, 1, "f97116ded567c3cc275be618566359666c2e3b79522518dfba6b82933da69560") -- Depot 4236431
setManifestid(4236431, "8400519588030159510", 1605165695)