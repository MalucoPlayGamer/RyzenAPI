-- Lua provided by RyzenAPI
-- Game: Selene ~Apoptosis~ Demo

-- MAIN APPLICATION
addappid(1398240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398241, 1, "ea55b544b10880bd9b94b840705d32cf1fa3c6167cf3f1a20e9d58c167bcabe5")

