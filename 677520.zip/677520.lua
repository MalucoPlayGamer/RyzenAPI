-- Lua provided by RyzenAPI
-- Game: setManifestid(677522,"5440237665846520453")

-- MAIN APPLICATION
addappid(677520)

-- MAIN APP DEPOTS / PACKAGES
addappid(677522,0,"1e9e5f435538bd33ddcff6e8ab30058a4f95fee9b9c7b824f258fe0b64e6af9d")

