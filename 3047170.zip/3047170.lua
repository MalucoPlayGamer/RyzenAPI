-- Lua provided by RyzenAPI
-- Game: 3047170

-- MAIN APPLICATION
addappid(3047170)
-- Game: addappid(3047170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3047171, 1, "eaf453936e1aadae8eee5046d0e1931a3a9ea0cbc834713269cc87492d85a4ae")
