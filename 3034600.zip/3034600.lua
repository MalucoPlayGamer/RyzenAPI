-- Lua provided by RyzenAPI
-- Game: 3034600

-- MAIN APPLICATION
addappid(3034600)
-- Game: addappid(3034600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034601, 1, "a0993fe8b6b12e8fd361c3e39f411e537dac659d182f134672fc152ea8963b8a")
