-- Lua provided by SkyAPI 
-- Game: Broken Hearts Island
addappid(2499420)
addappid(2499421, 1, "d4b043b1b804c4e8e1c9d759c4dbab0b8f5621cac2f74ad6d42145cc391a8b32")
