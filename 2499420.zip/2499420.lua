-- Lua provided by RyzenAPI
-- Game: 2499420

-- MAIN APPLICATION
addappid(2499420)
-- Game: addappid(2499420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499421, 1, "d4b043b1b804c4e8e1c9d759c4dbab0b8f5621cac2f74ad6d42145cc391a8b32")
