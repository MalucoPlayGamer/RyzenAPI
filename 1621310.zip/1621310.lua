-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2: The Alchemist of the Mysterious Dream

-- MAIN APPLICATION
addappid(1621310) -- Atelier Sophie 2: The Alchemist of the Mysterious Dream
addappid(1754680)
addappid(1754681) -- Atelier Sophie 2 - Useful Weapons Set
addappid(1754682) -- Atelier Sophie 2 - Useful Items Set
addappid(1754683)
addappid(1754684)
addappid(1754685) -- Atelier Sophie 2 - Season Pass
addappid(1754686)
addappid(1754687)
addappid(1754688)
addappid(1754689)
addappid(1754690)
addappid(1754691)
addappid(1754692)
addappid(1754693)
addappid(1754694)
addappid(1754695)
addappid(1754696)
addappid(1754697)
addappid(1754698)
addappid(1754699)
addappid(1754700)
addappid(1754701)
addappid(1754702)
addappid(1754703)
addappid(1754704)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1621311, 1, "7efa5dc2c1f058948f98a3e2b75be10a0cf423134af8a02f79e9f78dc4602157") -- Depot 1621311
addappid(1754680, 1, "19f21896c7cbe76801f0112566e96cb32d1c6c5efba7b056d7f24985f29ddf69") -- Atelier Sophie 2 - Atelier Series Legacy Swimsuit Set - Depot 1754680
addappid(1754683, 1, "84ea7914b3a4be9ab29aaaa095d4ecabb421ede988931c9df531e7eb39702655") -- Atelier Sophie 2 - Sophies Costume Easy Breezy - Depot 1754683
addappid(1754684, 1, "4c4249b7ae1cbad87da903e7b1094b9807fa78daec77ddbdf33e630c4d119478") -- Atelier Sophie 2 - Sophies Costume Comfy and Casual - Depot 1754684
addappid(1754686, 1, "c7c617a143b13671c071b9c68613aee3a3b732e915b9ffa29e226ada8a5a3898") -- Atelier Sophie 2 - SophieRamizels Costumes Grandmas Outfit (Matching Set) - Depot 1754686
addappid(1754687, 1, "d2234ecbeb4b503ae106df5680d0c6c613b421027bade9352299d6dc6fe432ca") -- Atelier Sophie 2 - Sophies Costume Alchemist of the Mysterious Journey - Depot 1754687
addappid(1754688, 1, "3e88a9d47ab78f7bcdbeccd14956e5d593fa48195b16cfeff5ab3dbfe31531a0") -- Atelier Sophie 2 - Plachtas Costume Haute Couture - Depot 1754688
addappid(1754689, 1, "8e2305c7b006bfa0897d3829a86905e4b2b5c16d0ecdff30ef23ff218b70759e") -- Atelier Sophie 2 - Ramizels Costume Ertona Hunter - Depot 1754689
addappid(1754690, 1, "2234668fadcf8604d2a6d54d11cb91bc1ac801765a437a97e9d6cbcbe4c4ecde") -- Atelier Sophie 2 - Accessory 25 Glasses - Depot 1754690
addappid(1754691, 1, "bd5a71f908e3be7dac852e56dc93a2ea6a08fe5c9b28ffdaa6b587563cbb12fd") -- Atelier Sophie 2 - Accessory Animal Headband - Depot 1754691
addappid(1754692, 1, "fa1773985960e293ff442f39e4769bae393091b693960bc712350bdefbcdbac9") -- Atelier Sophie 2 - SophiePlachtaRamizelAlettes Costume Bunny-Eared Salesgirl - Depot 1754692
addappid(1754693, 1, "2f3ddbd2688abc427f48ab3144b6b3492b54fdb0ea5a08b8e89d74509439d0fb") -- Atelier Sophie 2 - Recipe Expansion Pack The Art of Synthesis - Depot 1754693
addappid(1754694, 1, "7ff85e8497b2526a676d9b7653ba1461045be0785ad93b5a5d310a97b90895cb") -- Atelier Sophie 2 - Recipe Expansion Pack The Art of Battle - Depot 1754694
addappid(1754695, 1, "1b285977b0be3b48b8cf640aa63c0d8b85e853d670aa2acd5d7ccb1a05440fad") -- Atelier Sophie 2 - Gust Extra BGM Pack - Depot 1754695
addappid(1754696, 1, "5358e8fac5274f01364d3bc414c5953d3fe293f777ce09aeb074d0ad271a1d67") -- Atelier Sophie 2 - Extra Area Heartscape - Depot 1754696
addappid(1754697, 1, "9bd5f83ecc0f987dbc59790df0e37fb82c110f683e53dcc58806ee08e43c4dde") -- Atelier Sophie 2 - Sophies Swimsuit White Canvas - Depot 1754697
addappid(1754698, 1, "0f1689965003e30d98b944f77870832ebfa9208f7b1f7bb2563f74aa66cce8f4") -- Atelier Sophie 2 - Plachtas Swimsuit Clivia Nobilis - Depot 1754698
addappid(1754699, 1, "1f367420406fb8d4c7e30ecc28f2c72283bcef5df00e584e54645a2828932852") -- Atelier Sophie 2 - Ramizels Swimsuit Agapanthus Romance - Depot 1754699
addappid(1754700, 1, "5850698dcb737db293d85d928794dceb3455934ba9b1b19e0069d95d37675a28") -- Atelier Sophie 2 - Alettes Swimsuit Rainmaker - Depot 1754700
addappid(1754701, 1, "9e0bc7fa0aa1c6657e3cbf6f6aff4d065ceaab93b8c57d5165988610255d9046") -- Atelier Sophie 2 - Oliass Swimsuit Vegetable Garden - Depot 1754701
addappid(1754702, 1, "ba9d4356ba2c21c741558b8a9686a6a919a0933d888aa8b28f0bbd91aa783dd1") -- Atelier Sophie 2 - Diebolds Swimsuit Knight Commander - Depot 1754702
addappid(1754703, 1, "d3e7799d9a68e156608d74aa0ef6049e36dd0df1308c016b0dc15f90f59298e7") -- Atelier Sophie 2 - Atelier Series Legacy BGM Pack - Depot 1754703
addappid(1754704, 1, "669094ba47d811aeb2e10100040bbdb32afa56f42f401920d9b989b5f55bf9ad") -- Atelier Sophie 2 - Extra ScenarioArea Atelier Plachta - Depot 1754704
addtoken(1754680, "2438579537275917386")
addtoken(1754683, "5776473274934807548")
addtoken(1754684, "12796335806120162501")
addtoken(1754686, "11177714381433317960")

