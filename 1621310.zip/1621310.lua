-- Lua provided by RyzenAPI
-- Game: 1621310

-- MAIN APPLICATION
addappid(1621310)
-- Game: addappid(1621310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621311, 1, "7efa5dc2c1f058948f98a3e2b75be10a0cf423134af8a02f79e9f78dc4602157")
