-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2: The Alchemist of the Mysterious Dream

-- MAIN APPLICATION
addappid(1621310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621311, 1, "7efa5dc2c1f058948f98a3e2b75be10a0cf423134af8a02f79e9f78dc4602157")

