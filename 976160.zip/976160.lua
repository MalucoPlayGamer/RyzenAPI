-- Lua provided by RyzenAPI
-- Game: AppID 976160

-- MAIN APPLICATION
addappid(976160)
-- Game: addappid(976160)

-- MAIN APP DEPOTS / PACKAGES
addappid(976161, 1, "675c942b3b71bb743aa88d46bdabee917c1a96e14f270dced938699d24e2839f")
addappid(1035480, 0, "f54db6fd6a269df31830b0de31d136ac83e196c5f2d09e42bf32105703487325")
