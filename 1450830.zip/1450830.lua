-- Lua provided by RyzenAPI
-- Game: 1450830

-- MAIN APPLICATION
addappid(1450830)
-- Game: addappid(1450830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450833,0,"689848687df5b5e6cddc5923794ef11c47bad56f0336fc5fb93f183bd18f9d6a")
