-- Lua provided by RyzenAPI
-- Game: Deus Ex: The Fall

-- MAIN APPLICATION
addappid(258180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(258181, 1, "90d44aae0c5af33785837bf690187aea666a8640a402d04c27a87b6256ee04d2")

