-- Lua provided by RyzenAPI
-- Game: 258180

-- MAIN APPLICATION
addappid(258180)
-- Game: addappid(258180)

-- MAIN APP DEPOTS / PACKAGES
addappid(258181, 1, "90d44aae0c5af33785837bf690187aea666a8640a402d04c27a87b6256ee04d2")
