-- 2371060's Lua and Manifest Created by Hubcap Manifest
-- It Consumes
-- Created: August 05, 2026 at 13:23:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2371060) -- It Consumes
-- MAIN APP DEPOTS
addappid(2371061, 1, "d494837d76b34833922999f97687081f997b16dce7023ab6ef3d5bab3b592386") -- Depot 2371061
setManifestid(2371061, "7211392416124905191", 1782216604)