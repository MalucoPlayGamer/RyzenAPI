-- Lua provided by RyzenAPI
-- Game: It Consumes

-- MAIN APPLICATION
addappid(2371060) -- It Consumes

-- MAIN APP DEPOTS / PACKAGES
addappid(2371061, 1, "d494837d76b34833922999f97687081f997b16dce7023ab6ef3d5bab3b592386") -- Depot 2371061

