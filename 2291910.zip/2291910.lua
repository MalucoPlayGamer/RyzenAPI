-- Lua provided by RyzenAPI
-- Game: Robo Rob

-- MAIN APPLICATION
addappid(2291910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291912,0,"bca3c1e0ecc98bf86ce8afbd8a266b3de270e7bce484383593252d125d414c9d")

