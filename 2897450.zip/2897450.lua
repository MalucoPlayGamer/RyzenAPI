-- Lua provided by RyzenAPI
-- Game: 2897450

-- MAIN APPLICATION
addappid(2897450)
-- Game: addappid(2897450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897451, 1, "eb6cfeea9797d3af8e97cc985c2827d4b9749ea0dff21f96737cd49ca6076175")
