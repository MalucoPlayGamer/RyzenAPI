-- Lua provided by RyzenAPI
-- Game: AppID 2897450

-- MAIN APPLICATION
addappid(2897450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2897451, 1, "eb6cfeea9797d3af8e97cc985c2827d4b9749ea0dff21f96737cd49ca6076175")

