-- Lua provided by RyzenAPI
-- Game: Wilford

-- MAIN APPLICATION
addappid(1646050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646051, 1, "527f0a25415b161ac1af457ff7b699ff4b6e9887bf533838d88847f37cd9aef9")

