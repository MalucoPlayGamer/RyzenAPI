-- Lua provided by RyzenAPI
-- Game: Disney•Pixar Cars: Radiator Springs Adventures

-- MAIN APPLICATION
addappid(343140)

-- MAIN APP DEPOTS / PACKAGES
addappid(343141, 1, "2ca3c28da47f6e73eab691d1efe3bceae7be7c0b837c52c7a63d0ab1cdf45288")
addappid(343142, 1, "ce7b24ba9b67ea0208bc07e1ec7b44465f114603fe94bcdbf09c2ce0a6319eb5")
addappid(343143, 1, "32cc12d2b365735951b6a2fa274836a3d5a552e096d3ea953bf55b8713d361d8")
addappid(343144, 1, "a9c624f1631afe83aa1cf5ff1d6192dec2e30dfb0abbb8a858d7179f801a9b1d")
addappid(343145, 1, "edad3c89a97f017eeb5f23a562ff144eaec1ea013cc2187bb0cb216f32e7748b")
addappid(343146, 1, "274f71782d076763df83204e7f134943fb8b3cd5697f9d33c371519f73f0b459")
addappid(343147, 1, "de3427de94e8b66a9de63f2f38a74bb9e0cc1ab10d3eb9bc87df1c5b82648c15")
