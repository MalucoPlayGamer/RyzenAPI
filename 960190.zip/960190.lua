-- Lua provided by SkyAPI 
-- Game: AppID 960190
addappid(960190)
addappid(960191, 1, "04435ba72638ce16ecfaaa71df9c82ff459f8aa0f5290c3ec04fd323d74f06a2")
