-- Lua provided by RyzenAPI
-- Game: Maytroid. I swear it's a nice game too

-- MAIN APPLICATION
addappid(960190)

-- MAIN APP DEPOTS / PACKAGES
addappid(960191, 1, "04435ba72638ce16ecfaaa71df9c82ff459f8aa0f5290c3ec04fd323d74f06a2")
