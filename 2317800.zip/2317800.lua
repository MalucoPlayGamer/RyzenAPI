-- Lua provided by RyzenAPI
-- Game: Rogue Voltage Demo

-- MAIN APPLICATION
addappid(2317800)
-- Game: addappid(2317800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317801, 1, "30e7189f5b1c25036eb1907be1590a4be5fecfc5b1108d3ee4017203a7f2d809")
