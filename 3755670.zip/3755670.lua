-- Lua provided by RyzenAPI
-- Game: Car Dealer Life Simulator

-- MAIN APPLICATION
addappid(3755670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3755671, 1, "0dcfad74fbb20e3f8b2357b5b288087ac9d8cd9963c1be34532a933f60eaac3c")
