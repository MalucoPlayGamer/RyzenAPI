-- Lua provided by RyzenAPI
-- Game: Car Dealer Life Simulator

-- MAIN APPLICATION
addappid(3755670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3755671, 1, "0dcfad74fbb20e3f8b2357b5b288087ac9d8cd9963c1be34532a933f60eaac3c")

