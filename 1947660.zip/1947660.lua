-- Lua provided by RyzenAPI
-- Game: LiMiT's Escape Room Games

-- MAIN APPLICATION
addappid(1947660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947661, 1, "5f8d20f88e6d54e23decbf50cf4ee49b28b18dab609f4406d17cb33c5aae4a10")

