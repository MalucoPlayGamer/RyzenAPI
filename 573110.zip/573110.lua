-- Lua provided by SkyAPI 
-- Game: AppID 573110
addappid(573110)
addappid(573111, 1, "8677cbf46c1d4da0b6c94ac215f6bc6b5bfeb8757ea781ddc80965c18239541d")
