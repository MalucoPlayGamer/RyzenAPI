-- Lua provided by RyzenAPI
-- Game: AppID 573110

-- MAIN APPLICATION
addappid(573110)
-- Game: addappid(573110)

-- MAIN APP DEPOTS / PACKAGES
addappid(573111, 1, "8677cbf46c1d4da0b6c94ac215f6bc6b5bfeb8757ea781ddc80965c18239541d")
