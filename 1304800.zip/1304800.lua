-- Lua provided by RyzenAPI
-- Game: FOREST OF THE DEAD

-- MAIN APPLICATION
addappid(1304800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304801, 1, "4130d0e900bdffcd8b1130d73ed75626de2cedad6b561852120da9255d91ac5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
