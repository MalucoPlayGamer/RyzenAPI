-- Lua provided by RyzenAPI
-- Game: Game: FOREST OF THE DEAD

-- MAIN APPLICATION
addappid(1304800)
-- Game: addappid(1304800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304801, 1, "4130d0e900bdffcd8b1130d73ed75626de2cedad6b561852120da9255d91ac5f")
