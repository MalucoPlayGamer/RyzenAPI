-- Lua provided by RyzenAPI 
-- Game: FOREST OF THE DEAD
addappid(1304800)
addappid(1304801, 1, "4130d0e900bdffcd8b1130d73ed75626de2cedad6b561852120da9255d91ac5f")
