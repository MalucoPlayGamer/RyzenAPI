-- Lua provided by RyzenAPI
-- Game: Spoxel

-- MAIN APPLICATION
addappid(746880)

-- MAIN APP DEPOTS / PACKAGES
addappid(746881,0,"1d856cb737c6673daaacea342cafcc0e8514ccef2d2a2e09a8cf551e71740773")
addappid(746882,0,"9572c44636128e3093ac39e4109f58f92d9f02d41f72c873d0a113cdedb22a74")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
