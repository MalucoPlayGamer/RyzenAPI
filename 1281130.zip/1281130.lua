-- Lua provided by SkyAPI 
-- Game: AppID 1281130
addappid(1281130)
addappid(1281131, 1, "abb54b4c086baf6c342a6a9903a591b7511ede544adc36c400d43e6127498131")
