-- Lua provided by RyzenAPI
-- Game: Meet Your Maker

-- MAIN APPLICATION
addappid(1194810)
addappid(2313691)
addappid(2448580)
addappid(2448581)
addappid(2561840)
addappid(2561850)
addappid(2692690)
addappid(2692700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194811,0,"17f8c8a9b91c20321eab82f296993f16e3ad089ab4d2a51016ba67ec875004a5")

