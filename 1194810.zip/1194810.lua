-- Lua provided by RyzenAPI
-- Game: addappid(1194810)

-- MAIN APPLICATION
addappid(1194810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194811, 1, "17f8c8a9b91c20321eab82f296993f16e3ad089ab4d2a51016ba67ec875004a5")
