-- Lua provided by RyzenAPI
-- Game: Meet Your Maker

-- MAIN APPLICATION
addappid(1194810)
addappid(2313691)
addappid(2448580)
addappid(2448581)
addappid(2561840)
addappid(2561850)
addappid(2692690)
addappid(2692700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1194811,0,"17f8c8a9b91c20321eab82f296993f16e3ad089ab4d2a51016ba67ec875004a5")

