-- Lua provided by RyzenAPI
-- Game: Zomborg

-- MAIN APPLICATION
addappid(729720)
-- Game: addappid(729720)

-- MAIN APP DEPOTS / PACKAGES
addappid(729721, 1, "423220192ef9cd70a5523613d455def1448456796c59956a2daf3278c353d9ae")
