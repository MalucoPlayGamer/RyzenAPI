-- Lua provided by RyzenAPI
-- Game: addappid(3243540)

-- MAIN APPLICATION
addappid(3243540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243540,0,"0ed23120ccc01db25ec20caeed3986fd721bae6750916f7f5ab41e824c8533b7")
