-- Lua provided by RyzenAPI
-- Game: Game: Vagabond

-- MAIN APPLICATION
addappid(1673090)
-- Game: addappid(1673090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673091, 1, "af5cc57efa3622e800fe024b54a426ada7a4eab5c15993cb11ea8c296683ae83")
