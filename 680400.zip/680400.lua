-- Lua provided by RyzenAPI
-- Game: Light Tracer

-- MAIN APPLICATION
addappid(680400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(680401, 1, "0fdbb0b4bfc2287aafea26c7ab578736261380e11f1cbd2c7684d77e9f993a76")

