-- Lua provided by RyzenAPI
-- Game: AppID 680400

-- MAIN APPLICATION
addappid(680400)

-- MAIN APP DEPOTS / PACKAGES
addappid(680401, 1, "0fdbb0b4bfc2287aafea26c7ab578736261380e11f1cbd2c7684d77e9f993a76")
