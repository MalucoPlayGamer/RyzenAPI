-- Lua provided by RyzenAPI
-- Game: Malpractice

-- MAIN APPLICATION
addappid(3203040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3203041, 1, "f0f3f8e082858675f9ad114050de56444260b9d25862ddd1015e55ca721b49aa")

