-- Lua provided by RyzenAPI 
-- Game: Darold The Doomer: Psychedelic Lucid Dreams
addappid(1928010)
addappid(1928011, 1, "6dacdaf25d127869bfdcc6068b389315524cf5ca24ea91ac97e6bd4778ef4b58")
