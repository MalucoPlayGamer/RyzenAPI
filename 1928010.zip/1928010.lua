-- Lua provided by RyzenAPI
-- Game: Game: Darold The Doomer: Psychedelic Lucid Dreams

-- MAIN APPLICATION
addappid(1928010)
-- Game: addappid(1928010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928011, 1, "6dacdaf25d127869bfdcc6068b389315524cf5ca24ea91ac97e6bd4778ef4b58")
