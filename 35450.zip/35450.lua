-- Lua provided by RyzenAPI
-- Game: Red Orchestra 2: Heroes of Stalingrad with Rising Storm

-- MAIN APPLICATION
addappid(35450)

-- MAIN APP DEPOTS / PACKAGES
addappid(35451, 1, "acfb6981d8b8b135187540d01e0708042a72725f6341556fb14641b7bdf4a3d8")
addappid(35455, 1, "d75ebc8c08f3b027cfad05d5b257c41c445bb35504478e5080a66b43ee238a02")
addappid(35456, 1, "877b1122f711045e08d7c23896436f2880cf87ad2b9ab4a57e0faf45124dca0a")
addappid(35457, 1, "975643ab308f69c99ab514644b4327cf178ceafafea8cfd54637ca2f13170c97")
addappid(35458, 1, "b89c99592750723d726f581a5319251d4cee95f0da648e159bdce3373548a9de")
addappid(35459, 1, "dc52ddc9230bc4c325f44ab6c9c52a8f729c07aef8b6fbaf5c07924bf6cb695f")
addappid(234511, 0, "ed9a75de4551094adf1c9085f6721a9ce7b727bb2b74a10b1df1eda53e0434be")
addappid(234512, 0, "46d9318be2b53b8dbb68d60e37f4690b09d929a93da0e0c8533027a1fafc776c")
