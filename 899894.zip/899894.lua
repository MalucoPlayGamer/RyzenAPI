-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(899894)

-- MAIN APP DEPOTS / PACKAGES
addappid(899894,0,"f971be8d8af02363e4edb9e3b5631473e0fc7b5d8f2474aa8fe038da92632647")

