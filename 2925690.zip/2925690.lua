-- Lua provided by RyzenAPI
-- Game: Hentai room: Deep galactic penetration

-- MAIN APPLICATION
addappid(2925690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925691, 1, "a89792e2d9da6a58215b139567c9c2f343cfe9438e490de5014b543f773173fb")
