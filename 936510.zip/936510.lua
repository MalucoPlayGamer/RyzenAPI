-- Lua provided by RyzenAPI
-- Game: 2nd Circle - Powerful Magic

-- MAIN APPLICATION
addappid(936510)
-- Game: addappid(936510)

-- MAIN APP DEPOTS / PACKAGES
addappid(936511, 1, "8763f73e71b5d1ef226c1033fb69ec7b3d73388dedc33bfe498cbfcdcb14e7ae")
