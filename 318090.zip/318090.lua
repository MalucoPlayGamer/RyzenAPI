-- Lua provided by RyzenAPI
-- Game: Dicetiny

-- MAIN APPLICATION
addappid(318090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(318091, 1, "fbc7a08f066f6aabee9a5fc134138c0954f59ccab5ef4c98f6705a3dab9a5f31")
addappid(318092, 1, "426b065470472a07af47a467a4c3482aa39334c0fc98d373828d342aaf1e9769")
addappid(318093, 1, "c848588d824a342fcae4e478da24e1e9582409b6fe43555bf12706bd499e418e")

