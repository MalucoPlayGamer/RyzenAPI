-- Lua provided by RyzenAPI
-- Game: Three Quarters Space Station

-- MAIN APPLICATION
addappid(2106540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106541, 1, "380ca35e865678aae97ade657021b4d268ed2aad2d8fe3cb3664892cb18009c4")
