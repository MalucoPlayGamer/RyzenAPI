-- Lua provided by RyzenAPI
-- Game: Him & Her Collection

-- MAIN APPLICATION
addappid(1942390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942391, 1, "46836f99ac922c563d932c635a94eb8f26454c6c51275cbe0391bb3e47d392bf")
