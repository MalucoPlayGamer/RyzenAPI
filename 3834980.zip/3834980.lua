-- Lua provided by RyzenAPI
-- Game: The Pet Whisperer

-- MAIN APPLICATION
addappid(3834980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3834981,0,"2a0032612d56b96d337f92e93d1ba1811003ea92b979cc46c0628268a7ca24a0")

