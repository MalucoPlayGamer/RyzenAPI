-- Lua provided by RyzenAPI
-- Game: Kota`s New Journey - Supporter Pack

-- MAIN APPLICATION
addappid(3333030)
-- Game: addappid(3333030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333030,0,"37227ecbaf51bf7689af5a278c09b55105c66e9ad55c531c4568f808b08b6790")
