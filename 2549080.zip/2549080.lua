-- Lua provided by RyzenAPI
-- Game: 2549080

-- MAIN APPLICATION
addappid(2549080)
-- Game: addappid(2549080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549081, 1, "415fc2469b72fc81f4450c48d7ae72daebe1e4ffd3523cfd9f612b601263c88a")
