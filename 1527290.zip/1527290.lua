-- Lua provided by RyzenAPI
-- Game: Company of Heroes: Back to Basics

-- MAIN APPLICATION
addappid(1527290)
-- Game: addappid(1527290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527293,0,"e11fe9e9f7bd70114dc37f35ddee3cb93b8363c1186025d72c162c84561dbf6f")
