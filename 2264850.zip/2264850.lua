-- Lua provided by RyzenAPI
-- Game: A Guidebook of Babel Soundtrack

-- MAIN APPLICATION
addappid(2264850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264851, 1, "5f596477927db7a62c2e05a787d24f187e7685aafe145371d9dcd8c626786609")
addappid(2264852, 1, "0393ae6efeeb5827ab0d388538a52625b28d641467b1c7fc7ea64e93608e8500")
