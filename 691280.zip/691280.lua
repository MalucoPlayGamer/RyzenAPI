-- Lua provided by RyzenAPI
-- Game: 691280

-- MAIN APPLICATION
addappid(228986)
addappid(228987)
addappid(228990)
addappid(691280)

-- MAIN APP DEPOTS / PACKAGES
addappid(691283,0,"eeff68b72864fc4d625126d08ddca431d5160c08cac41b4502c6c560d2e527c1")

