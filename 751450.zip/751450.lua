-- Lua provided by RyzenAPI
-- Game: Nanairo Reincarnation

-- MAIN APPLICATION
addappid(751450)

-- MAIN APP DEPOTS / PACKAGES
addappid(751451, 1, "a17f669f71d998f9e29d1ffb1e9d154472399097d769e83c96377cc0f0e274f8")
