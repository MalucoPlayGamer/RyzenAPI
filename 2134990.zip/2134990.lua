-- Lua provided by RyzenAPI
-- Game: AppID 2134990

-- MAIN APPLICATION
addappid(2134990)
-- Game: addappid(2134990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134991, 1, "c870e11d641c19a37461e50052495adfb9cc1b9e0cea894cec91d34cb5191188")
