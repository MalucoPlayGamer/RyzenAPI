-- Lua provided by RyzenAPI
-- Game: Game: Squishy the Suicidal Pig

-- MAIN APPLICATION
addappid(318430)
-- Game: addappid(318430)

-- MAIN APP DEPOTS / PACKAGES
addappid(318431, 1, "78b3a26772b1547679447d263dcb75cec48b4551d6518688887d8d212ccdee9a")
