-- Lua provided by SkyAPI 
-- Game: Escape From Lavender Island
addappid(2164310)
addappid(2164311, 1, "b8e2d93043198b095f32ee6a60fcac8d6ac1e2a01de48a927adc36ea279cd7ac")
addappid(2164312, 1, "78913506cd63f080ce97b84e26a5b325885df177870d9f43d48deaecafa0b6f8")
addappid(2164313, 1, "2f7865eede4dd2b638294358db4a0989b75f3c16b1bd6492a083ace8d377f0a5")
