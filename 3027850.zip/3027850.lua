-- Lua provided by RyzenAPI
-- Game: 9to9 Museum

-- MAIN APPLICATION
addappid(3027850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027851, 1, "8ba82c948966cd786e48e258adc81c880b7e435e4091633419f9fc203e204a1e")
