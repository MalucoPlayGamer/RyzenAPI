-- Lua provided by RyzenAPI
-- Game: Voyage: Journey to the Moon

-- MAIN APPLICATION
addappid(302180)

-- MAIN APP DEPOTS / PACKAGES
addappid(302181, 1, "aa53492851ae9f060905ab40f8c75b70d38e22f6487c7f6faa8da66f9b1c8b90")
addappid(302182, 1, "4ef04f1cf23b0ccde36a43fd02185fa1484233b5187cca03c410d3e72b23cd89")
addappid(302183, 1, "ce89899d171dcbb3255c41a01649c517ca677a6bc05f8bf7fa06ef2f3c1e0ae6")
addappid(302184, 1, "f0232bcb5f3c957194bc385f965b4f24f24d990d250cc914db75aef1041983a4")
addappid(302185, 1, "3f88cb681edb29582406b374c08ac9d9bdfd38366c25658209d895ea21dd5446")
addappid(302186, 1, "6bb78e79da515e3ceaf8a4153c0d30aa92778f268b4c0e9f58a9bc27992efb8d")
