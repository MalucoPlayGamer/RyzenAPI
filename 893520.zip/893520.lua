-- Lua provided by RyzenAPI
-- Game: Creative Destruction

-- MAIN APPLICATION
addappid(893520)

-- MAIN APP DEPOTS / PACKAGES
addappid(893521, 1, "c5f928f8444af9accbe358b8e1e5771673881eff15cd8b6b44eef3154c6aa8fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
