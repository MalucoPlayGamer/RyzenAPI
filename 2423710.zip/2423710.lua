-- Lua provided by SkyAPI 
-- Game: Eldritchvania
addappid(2423710)
addappid(2423711, 1, "d22c16d8e4e26fe7c2e9667b23fd76554765db3b07e872074db039d0aa9b1694")
