-- Lua provided by RyzenAPI
-- Game: Dark Tales: Edgar Allan Poe's The Fall of the House of Usher Collector's Edition

-- MAIN APPLICATION
addappid(678400)

-- MAIN APP DEPOTS / PACKAGES
addappid(678401,0,"6c0e00e26016279fa41ca4420acf37963bf5e41c1444d0cc49766d16a1c10f86")

