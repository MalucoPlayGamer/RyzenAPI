-- Lua provided by RyzenAPI
-- Game: Save Daddy Trump 4: Maga 2024

-- MAIN APPLICATION
addappid(2985950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985951, 1, "618c4cbabb2d10b59ac1647fef07fe0085fa5b78f16394fee0f7a548a308d04d")
