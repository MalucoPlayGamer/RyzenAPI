-- Lua provided by RyzenAPI
-- Game: female swordsman

-- MAIN APPLICATION
addappid(3847040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3847041, 1, "c6a0450a8ae7ad64af3467cd5dc18f9e77358945e568d73561be04ca4471aa3c")

