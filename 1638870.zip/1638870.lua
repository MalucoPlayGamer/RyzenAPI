-- Lua provided by SkyAPI 
-- Game: Zombie Wars
addappid(1638870)
addappid(1638871, 1, "542fd1e936163ab9669fa089dfe45892e4ab5dde54d8130bd61525a960f4f7c0")
