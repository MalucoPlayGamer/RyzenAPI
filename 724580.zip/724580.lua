-- Lua provided by RyzenAPI
-- Game: Domino

-- MAIN APPLICATION
addappid(724580)

-- MAIN APP DEPOTS / PACKAGES
addappid(724581,0,"e3c7f76d80af9fcf06dda5633cc1abc513520b2c07051aaeea4d128879be3c1a")

