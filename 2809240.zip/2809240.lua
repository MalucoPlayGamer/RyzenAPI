-- Lua provided by RyzenAPI
-- Game: Elemental Exiles

-- MAIN APPLICATION
addappid(2809240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809241, 1, "b0f47ffede2aba422e887f4e0c0a738a43a0d79d6391ee6b1d456f6811eb9603")

