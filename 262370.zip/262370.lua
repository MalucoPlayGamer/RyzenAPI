-- Lua provided by RyzenAPI
-- Game: addappid(262370)

-- MAIN APPLICATION
addappid(262370)

-- MAIN APP DEPOTS / PACKAGES
addappid(262378,0,"46082ac700a0dde4d9c9625ec2b67b07800441f75802fd1ac9793e56cea66256")
