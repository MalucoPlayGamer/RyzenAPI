-- Lua provided by RyzenAPI
-- Game: Train Planet Demo

-- MAIN APPLICATION
addappid(2804760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804761, 1, "77fba1176e681939430b039bf39e9c056f046b3aeed431966f20236db3525569")

