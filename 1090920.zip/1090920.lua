-- Lua provided by RyzenAPI
-- Game: Gubble

-- MAIN APPLICATION
addappid(1090920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090921, 1, "9abb332393552ef9c2454c9c8f36ee284ccb35a0f5bebeca3d3289351957ae29")

