-- Lua provided by RyzenAPI 
-- Game: Gubble
addappid(1090920)
addappid(1090921, 1, "9abb332393552ef9c2454c9c8f36ee284ccb35a0f5bebeca3d3289351957ae29")
