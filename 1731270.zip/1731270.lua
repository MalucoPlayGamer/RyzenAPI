-- Lua provided by SkyAPI 
-- Game: Global City
addappid(1731270)
addappid(1731271, 1, "895f481fe53e28b61d0e677175f6c33ff522e58f4a1cfa018683e65bf5c60a3b")
addappid(1731272, 1, "eeefb73f5c17e0217f84dda666d2ae3455885ba196dac65d739d15f51b200e58")
addappid(1731275, 1, "c81c05cbcc0c109e71c3cf650f8a28ad968b0b61570af873902ab1d8d1d75e88")
