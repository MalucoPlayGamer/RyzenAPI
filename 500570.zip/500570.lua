-- Lua provided by RyzenAPI
-- Game: Game: Mahjong Deluxe 2: Astral Planes

-- MAIN APPLICATION
addappid(500570)
-- Game: addappid(500570)

-- MAIN APP DEPOTS / PACKAGES
addappid(500571, 1, "c816431f9cbe5b298bf89b65ac2fdb30a4c8ceab060207f43a4c2b7d3f8c7d3a")
