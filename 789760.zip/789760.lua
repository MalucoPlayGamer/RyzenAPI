-- Lua provided by RyzenAPI
-- Game: Game: DEAD OR SCHOOL

-- MAIN APPLICATION
addappid(789760)
-- Game: addappid(789760)

-- MAIN APP DEPOTS / PACKAGES
addappid(789761, 1, "7820543c7eb4f72c87abb1ea8fa1263d413f7b453c5da9370a2a6a233dd5984b")
