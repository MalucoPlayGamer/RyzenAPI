-- Lua provided by SkyAPI 
-- Game: DEAD OR SCHOOL
addappid(789760)
addappid(789761, 1, "7820543c7eb4f72c87abb1ea8fa1263d413f7b453c5da9370a2a6a233dd5984b")
