-- Lua provided by RyzenAPI
-- Game: Box Cats Puzzle

-- MAIN APPLICATION
addappid(751980)

-- MAIN APP DEPOTS / PACKAGES
addappid(751982,0,"8b99d23a933d0af26612380673ea5eb69010c0c2f65366aaa2a4ad3784232d41")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1788240)
addappid(1848880)
