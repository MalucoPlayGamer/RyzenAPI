-- Lua provided by RyzenAPI
-- Game: 751980

-- MAIN APPLICATION
addappid(751980)
-- Game: addappid(751980)

-- MAIN APP DEPOTS / PACKAGES
addappid(751982,0,"8b99d23a933d0af26612380673ea5eb69010c0c2f65366aaa2a4ad3784232d41")
