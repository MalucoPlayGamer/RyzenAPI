-- Lua provided by RyzenAPI
-- Game: addappid(1353470)

-- MAIN APPLICATION
addappid(1353470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353471, 1, "83bc4e6ffbaaccccf5fab3988c1369733d42ad3692f5ac71caffd2622ecbe87a")
