-- Lua provided by RyzenAPI
-- Game: Chernobylite - Charity Pack

-- MAIN APPLICATION
addappid(1935250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935250,0,"941ebb09831816d7e374e710c049522e83cea8d0369312ba6b8884dcccbaedfa")
