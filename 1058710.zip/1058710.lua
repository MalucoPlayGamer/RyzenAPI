-- Lua provided by RyzenAPI
-- Game: Monarch : Medieval Remastered

-- MAIN APPLICATION
addappid(1058710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058711, 1, "38fbc0d3f950e52b250083320bc51463b7ac6996443c641b41152fd3bbe34a16")

