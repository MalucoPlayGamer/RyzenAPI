-- Lua provided by RyzenAPI
-- Game: Monarch : Medieval Remastered

-- MAIN APPLICATION
addappid(1058710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1058711, 1, "38fbc0d3f950e52b250083320bc51463b7ac6996443c641b41152fd3bbe34a16")

