-- Lua provided by RyzenAPI
-- Game: The Silent Swan

-- MAIN APPLICATION
addappid(1898880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898881, 1, "cc339d1c753c2fc5cc1340c49a888c7328434186f9d6093ac6274132623bf376")
