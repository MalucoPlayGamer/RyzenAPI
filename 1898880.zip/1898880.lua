-- Lua provided by RyzenAPI
-- Game: The Silent Swan

-- MAIN APPLICATION
addappid(1898880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898881, 1, "cc339d1c753c2fc5cc1340c49a888c7328434186f9d6093ac6274132623bf376")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2616300)
