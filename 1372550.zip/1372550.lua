-- Lua provided by RyzenAPI
-- Game: The Nightmare

-- MAIN APPLICATION
addappid(1372550)
-- Game: addappid(1372550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372551, 1, "3b9130d393e603fee0151b7ef7f7240d8a8494f1340923e3180746e9acc68827")
