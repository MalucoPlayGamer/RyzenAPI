-- Lua provided by RyzenAPI
-- Game: MegaSphere

-- MAIN APPLICATION
addappid(386340)
-- Game: addappid(386340)

-- MAIN APP DEPOTS / PACKAGES
addappid(386341, 1, "23b416f3fef8a3dc35296b27a9937ec07590a55ea472140edb260063d8fc8e1a")
