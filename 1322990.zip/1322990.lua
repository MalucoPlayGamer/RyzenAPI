-- Lua provided by RyzenAPI
-- Game: Just Die Already Demo

-- MAIN APPLICATION
addappid(1322990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322991, 1, "6817b78e9f2d2464771f883564400197ebfbb137b0b69b26f87fa759a1232f28")
