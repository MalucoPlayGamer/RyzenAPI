-- Lua provided by SkyAPI 
-- Game: AppID 1322990
addappid(1322990)
addappid(1322991, 1, "6817b78e9f2d2464771f883564400197ebfbb137b0b69b26f87fa759a1232f28")
