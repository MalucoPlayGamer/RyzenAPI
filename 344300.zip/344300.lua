-- Lua provided by RyzenAPI
-- Game: AppID 344300

-- MAIN APPLICATION
addappid(344300)

-- MAIN APP DEPOTS / PACKAGES
addappid(344301, 1, "a86c0bca54d9dc2c1bc5069c1002599c7ccf1e5a50a0cbad7fc56a21c85ff6f0")
addappid(346280, 0, "0609d6fdfa3a96ea978ce078b1c063aa0c9801dcb9eeaddf6b613e64cb4df605")
