-- 3445540's Lua and Manifest Created by Hubcap Manifest
-- SherloCAT Nonogram Rio
-- Created: August 03, 2026 at 02:50:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3445540, 1, "580504a01b915d5517f7f1cf00ccad4644ab3b732e2a7927ba424314a7761acf") -- SherloCAT Nonogram Rio
-- MAIN APP DEPOTS
addappid(3445541, 1, "cd9c7e4e79d247a67931966cb9863e9d1e4d5930402084a067241b32a4155bb7") -- Depot 3445541
setManifestid(3445541, "5359383733793379370", 245339991)
addappid(3445542, 1, "05379053495806959d59f7e518a28e3d6e927c6d2c44d8acae400388cf0f86c9") -- Depot 3445542
setManifestid(3445542, "7442719728757553187", 247060957)