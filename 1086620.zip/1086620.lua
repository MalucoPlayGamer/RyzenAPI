-- Lua provided by RyzenAPI
-- Game: Selfloss

-- MAIN APPLICATION
addappid(1086620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086621, 1, "6e4e3de29233e4ee26c94144b2cdbf6678f449e985835a13f6c857ab11f593c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
