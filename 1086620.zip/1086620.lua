-- Lua provided by RyzenAPI
-- Game: Game: Selfloss

-- MAIN APPLICATION
addappid(1086620)
-- Game: addappid(1086620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086621, 1, "6e4e3de29233e4ee26c94144b2cdbf6678f449e985835a13f6c857ab11f593c3")
