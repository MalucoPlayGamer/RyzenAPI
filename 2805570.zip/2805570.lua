-- Lua provided by RyzenAPI
-- Game: 2805570

-- MAIN APPLICATION
addappid(2805570)
-- Game: addappid(2805570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805571, 1, "1677636f55005d9ca5ef1830914b2d214fef542cfd58f8989faaef72f5c09b13")
