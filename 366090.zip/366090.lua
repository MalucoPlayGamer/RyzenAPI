-- Lua provided by RyzenAPI
-- Game: Colony Survival

-- MAIN APPLICATION
addappid(366090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(366091, 1, "9ec618701a0e4539e52db97cba3d1b5848d9c9821ed3ba40d8175c18ba4da50b")
addappid(366092, 1, "6bce22756e979b001ce91ce94cf0a90ab5ed8ddd6603be8139dea6cd69bcd12b")
addappid(366093, 1, "4124822435fd86d9f9a5b13bf27e193f64ab899659265996f13fd04d917958c3")
addappid(366095, 1, "e829591abe38a04dd0eccb725a73dfda89d12ebcc953ff9c571ab63441824a52")
addappid(366096, 1, "b251de5137c42223518ecc6b233a8d0a34afd3f5027483ce8a2a4b5fe4acd423")

