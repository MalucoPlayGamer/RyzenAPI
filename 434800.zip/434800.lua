-- Lua provided by RyzenAPI
-- Game: Game: AppID 434800

-- MAIN APPLICATION
addappid(434800)
-- Game: addappid(434800)

-- MAIN APP DEPOTS / PACKAGES
addappid(434801, 1, "59f93e89fc5a6fb28bf009900076f58ecff3549831d991c6b1c6216c3fa17422")
