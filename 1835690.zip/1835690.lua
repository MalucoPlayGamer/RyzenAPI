-- Lua provided by RyzenAPI
-- Game: ShawnCena121

-- MAIN APPLICATION
addappid(1835690)
-- Game: addappid(1835690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835691, 1, "d88147022f8468b83d29f1c047462bfd486350b047489a87ec9361173cbb9ccf")
