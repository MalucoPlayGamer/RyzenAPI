-- Lua provided by RyzenAPI
-- Game: Squad 51 vs. the Flying Saucers

-- MAIN APPLICATION
addappid(1378800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1378801, 1, "9cd00bb325a2d44e6ba089dd9c012c3d5bb2f34798b03b8b0065b9827991516e")

