-- Lua provided by RyzenAPI
-- Game: Squad 51 vs. the Flying Saucers

-- MAIN APPLICATION
addappid(1378800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378801, 1, "9cd00bb325a2d44e6ba089dd9c012c3d5bb2f34798b03b8b0065b9827991516e")

