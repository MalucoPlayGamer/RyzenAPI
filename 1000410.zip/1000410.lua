-- Lua provided by RyzenAPI 
-- Game: AppID 1000410
addappid(1000410)
addappid(1000411, 1, "1cbbf1c9d6b1d0aee69b3d4114d5b5b5ebe60f335599cc50eb08bfaffa7b0efc")
