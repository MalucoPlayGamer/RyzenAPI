-- Lua provided by RyzenAPI
-- Game: AppID 1000410

-- MAIN APPLICATION
addappid(1000410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1000411, 1, "1cbbf1c9d6b1d0aee69b3d4114d5b5b5ebe60f335599cc50eb08bfaffa7b0efc")

