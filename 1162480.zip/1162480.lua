-- Lua provided by RyzenAPI
-- Game: AppID 1162480

-- MAIN APPLICATION
addappid(1162480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162481, 1, "deec8909fde86aca3cc59dcbb51a932ec2a7dd4845244fd73a5204f3905574cd")

