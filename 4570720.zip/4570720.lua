-- Lua provided by RyzenAPI
-- Game: DragonSword Awakening

-- MAIN APPLICATION
addappid(4742640)
addappid(4742660) -- DragonSword  Awakening - Familiar  Abyssal Direwolf
addappid(4785980) -- DragonSword  Awakening - Familiar  Viola Flying Squirrel
addappid(4785990) -- DragonSword  Awakening - Familiar  Cotton Flying Squirrel
addappid(4786000) -- DragonSword  Awakening - Familiar  Orchid Wing Cat
addappid(4786010) -- DragonSword  Awakening - Familiar  Timid Hummingbird
addappid(4786020) -- DragonSword  Awakening - Familiar  Gale Sky Wolf
addappid(4786030) -- DragonSword  Awakening - Familiar  Frost Sky Wolf
addappid(4786050) -- DragonSword  Awakening - Familiar  Holy Knightage Griffon
addappid(4786220) -- DragonSword  Awakening - Costume  Ophelias Oath
addappid(4786230) -- DragonSword  Awakening - Costume  Roderick Royal Uniform
addappid(4786240) -- DragonSword  Awakening - Costume  Phantom Thief of Dawn
addappid(4786270) -- DragonSword  Awakening - Costume  Wild Strawberry Waitress
addappid(4872640) -- DragonSword  Awakening - Familiar  Flame Spirit Fox
addappid(4872650) -- DragonSword  Awakening - Familiar  War Direwolf

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4570720, 1, "1479788b29b18f4924dc12f1ac3c2c7a8afbc734c3b8a5774d4ba64995651725")
addappid(4570720, 1, "1479788b29b18f4924dc12f1ac3c2c7a8afbc734c3b8a5774d4ba64995651725") -- DragonSword : Awakening
addappid(4570721, 1, "bcfd9b5aa6729364b267af933d75e064c35ed2dfee9d3529186bed1713221251") -- Depot 4570721
addappid(4570722, 1, "3061e4e1f78023461c0fb8fdf5e9368efd7b0d77c114546e038ebd6749408ab9") -- Depot 4570722
addappid(4742641, 1, "1b66d546a7e756f5dbdf86fefdc35f338217b02efbe352c2f85518d9398a4835") -- DragonSword  Awakening - Deluxe Pack
addappid(4742641, 1, "1b66d546a7e756f5dbdf86fefdc35f338217b02efbe352c2f85518d9398a4835") -- DragonSword  Awakening - Deluxe Pack - Depot 4742641

