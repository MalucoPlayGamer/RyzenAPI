-- Lua provided by RyzenAPI
-- Game: Red Cap Squad: Zombie Source

-- MAIN APPLICATION
addappid(3340120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3340122,0,"d1c0099086e33fa495a50936110453cc05e1a9db530f3d8866224a7a12abbdc1")

