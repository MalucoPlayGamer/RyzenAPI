-- Lua provided by RyzenAPI
-- Game: 255280

-- MAIN APPLICATION
addappid(255280)
-- Game: addappid(255280)

-- MAIN APP DEPOTS / PACKAGES
addappid(255281, 1, "9a936d1a3369c6c122140d715c5f91f58c97a06f66951def0edcee77b3d416ad")
addappid(255282, 1, "e69af4d43b86ade2525f4abf07044dbdf51b951213fef55af60effacac3f413c")
addappid(255283, 1, "c7fb2ed0c5964b73e6d937841fa39df35889d2482da761865737cddd5e632367")
addappid(255284, 1, "85671c814e728712ad5b6e2cbeccd121899c958e777caf2e6c85915ae4c4d12b")
