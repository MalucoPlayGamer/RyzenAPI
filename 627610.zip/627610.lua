-- Lua provided by RyzenAPI
-- Game: Get To The Orange Door Demo

-- MAIN APPLICATION
addappid(627610)

-- MAIN APP DEPOTS / PACKAGES
addappid(627611, 1, "e8158c19407f4700689626a6886380ab3a942195ff20e0d4505167833053dfd0")

