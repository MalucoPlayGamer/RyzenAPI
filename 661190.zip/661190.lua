-- Lua provided by RyzenAPI
-- Game: UNDEFINED

-- MAIN APPLICATION
addappid(661190)

-- MAIN APP DEPOTS / PACKAGES
addappid(661191, 1, "abf71e9cce3ecf5fdca42e42e1992172ae30c464820e43cff8633b71dadf122f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
