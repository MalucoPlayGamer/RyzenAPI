-- Lua provided by RyzenAPI 
-- Game: UNDEFINED
addappid(661190)
addappid(661191, 1, "abf71e9cce3ecf5fdca42e42e1992172ae30c464820e43cff8633b71dadf122f")
