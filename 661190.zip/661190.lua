-- Lua provided by RyzenAPI
-- Game: UNDEFINED

-- MAIN APPLICATION
addappid(661190)

-- MAIN APP DEPOTS / PACKAGES
addappid(661191, 1, "abf71e9cce3ecf5fdca42e42e1992172ae30c464820e43cff8633b71dadf122f")
