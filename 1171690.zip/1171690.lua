-- Lua provided by RyzenAPI
-- Game: AppID 1171690

-- MAIN APPLICATION
addappid(1171690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171691, 1, "b6cb674fb5083cf930aa7e0b0f245eeb14068f7cd60c8fdeafa3f4f5c8bd66e2")

