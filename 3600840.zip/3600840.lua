-- Lua provided by RyzenAPI
-- Game: 3600840

-- MAIN APPLICATION
addappid(3600840)
-- Game: addappid(3600840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3600842,0,"dfd77e262b2141c88ba294f30ef9a282e125e437dc749dae72e461f2527004e5")
