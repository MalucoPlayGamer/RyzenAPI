-- Lua provided by RyzenAPI
-- Game: 2647810

-- MAIN APPLICATION
addappid(2647810)
-- Game: addappid(2647810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2647810,0,"039a5b79e1e5d200d26bf20e35f47fcd977d5e4dca873c10bd85dca5238754a7")
