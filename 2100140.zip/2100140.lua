-- Lua provided by RyzenAPI
-- Game: Summon Masters

-- MAIN APPLICATION
addappid(2100140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100142,0,"02dcbd0641d893a62b6e4806f9fb3937c2084a6ed540203c5c77a8d6d2d5c508")
