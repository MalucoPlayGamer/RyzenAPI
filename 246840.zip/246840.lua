-- Lua provided by RyzenAPI
-- Game: 246840

-- MAIN APPLICATION
addappid(246840)
-- Game: addappid(246840)

-- MAIN APP DEPOTS / PACKAGES
addappid(246841, 1, "f90c1e202135d7cb129082a42b2b9878af4f00810fc3ccd1ae999cb4695d3a56")
