-- Lua provided by RyzenAPI
-- Game: Game: AppID 1913910

-- MAIN APPLICATION
addappid(1913910)
-- Game: addappid(1913910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913911, 1, "2d29fd7e712e27081addb7061ce970292ffbc3a7bb5caa1a339cc652d9cd71dd")
