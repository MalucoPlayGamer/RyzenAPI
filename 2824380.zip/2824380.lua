-- Lua provided by RyzenAPI
-- Game: Exotica 2: Pet Shop Simulator

-- MAIN APPLICATION
addappid(2824380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824381,0,"8c97d323d1bf95a6f1568141d8f474c6499e8df543bad47d5c249a49a6129f07")

