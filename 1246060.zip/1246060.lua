-- Lua provided by RyzenAPI
-- Game: 1246060

-- MAIN APPLICATION
addappid(1246060)
-- Game: addappid(1246060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246061, 1, "1fb633782880a67b7b936c4b49dc703ea44dcce7fc68f73daf23b533d3e58a96")
