-- Lua provided by RyzenAPI
-- Game: AppID 752590

-- MAIN APPLICATION
addappid(752590)

-- MAIN APP DEPOTS / PACKAGES
addappid(752591, 1, "31c0eb1a38b3926e0e589c25300225886ac653a8415d3612864cd26664681460")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(967380)
