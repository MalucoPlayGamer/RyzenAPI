-- Lua provided by RyzenAPI 
-- Game: AppID 752590
addappid(752590)
addappid(752591, 1, "31c0eb1a38b3926e0e589c25300225886ac653a8415d3612864cd26664681460")
