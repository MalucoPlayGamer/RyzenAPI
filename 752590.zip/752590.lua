-- Lua provided by RyzenAPI
-- Game: A Plague Tale: Innocence

-- MAIN APPLICATION
addappid(752590)
-- Game: addappid(752590)

-- MAIN APP DEPOTS / PACKAGES
addappid(752591, 1, "31c0eb1a38b3926e0e589c25300225886ac653a8415d3612864cd26664681460")
