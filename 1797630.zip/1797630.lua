-- Lua provided by RyzenAPI
-- Game: Dance of Cards

-- MAIN APPLICATION
addappid(1797630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797631, 1, "e660c631aa4cb02a59cad385c4047b09a42d9195174eb430e14589dec09fc89a")

