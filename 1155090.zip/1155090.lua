-- Lua provided by RyzenAPI
-- Game: 1155090

-- MAIN APPLICATION
addappid(1155090)
-- Game: addappid(1155090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155091, 1, "cf69454a33a178f22f9a8926049bda69eac0fd853d16609b595e722cc9906ac5")
