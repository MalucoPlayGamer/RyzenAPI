-- Lua provided by RyzenAPI
-- Game: FallNation Lost Stories

-- MAIN APPLICATION
addappid(2774800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774801, 1, "264faa1660012ea8bbb763a2d801bec5f52679a2280e8205353301ea162e7323")
