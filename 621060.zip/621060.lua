-- Lua provided by RyzenAPI
-- Game: pc builder simulator

-- MAIN APPLICATION
addappid(621060)
addappid(823720)
addappid(973910)
addappid(982590)
addappid(982600)
addappid(1067590)
addappid(1198960)
addappid(1252990)
addappid(1295800)
addappid(1416670)
addappid(1591920)
addappid(1642950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(621060, 1, "a8ecc84565d7b4f97cbe6a4c1cdd06169a0066fdaf9e0221a24b0ca7c3d9b45e") -- PC Building Simulator
addappid(621061, 1, "1d1b57e233552bf36e85de21663fda41d1160d3d446649bf0f1013a8d344ef01")
addappid(621061, 1, "1d1b57e233552bf36e85de21663fda41d1160d3d446649bf0f1013a8d344ef01") -- PC Building Simulator PC - 32bit
addappid(621062, 1, "d762715b8415a1f887f261e5a1736c7e86ad1fe5f77d2e945fcd61b255689df4")
addappid(621062, 1, "d762715b8415a1f887f261e5a1736c7e86ad1fe5f77d2e945fcd61b255689df4") -- PC Building Simulator PC - 64bit
addappid(621064, 1, "99c73cc41569fc2a0dcf0a31e01100910dbc13d02796e59d4690779c435b3e69")
addappid(621064, 1, "99c73cc41569fc2a0dcf0a31e01100910dbc13d02796e59d4690779c435b3e69") -- PC Building Simulator - NZXT Workshop - New Workshop PC
addappid(621066, 1, "3f4ffa558cfb78f1d55d918c35023414f578b0e4e5bb46521b5e6bccf312e5fe")
addappid(621066, 1, "3f4ffa558cfb78f1d55d918c35023414f578b0e4e5bb46521b5e6bccf312e5fe") -- PC Building Simulator - Fractal Design Workshop - Gothenburg
addappid(823721, 0, "df05eaae0ca49058c5fa7ded79d21ac2171492bedd24043a4e20c0f481046f87")
addappid(823721, 1, "df05eaae0ca49058c5fa7ded79d21ac2171492bedd24043a4e20c0f481046f87") -- PC Building Simulator - Good Company Case - Good Company Edition PC
addappid(973911, 0, "a8d8b7263cd12d4e507235de6387d9836de57c8b5db216718fc39efd10ce4fa3")
addappid(973911, 1, "a8d8b7263cd12d4e507235de6387d9836de57c8b5db216718fc39efd10ce4fa3") -- PC Building Simulator - Overclocked Edition Content - Collectors Edition Content PC
addappid(973913, 0, "158dc9df98251a4f530488d790133a004eca4e54662ce3af07e281d09877ccf6")
addappid(973913, 1, "158dc9df98251a4f530488d790133a004eca4e54662ce3af07e281d09877ccf6") -- PC Building Simulator - Razer Workshop - Razer PC
addappid(982601, 0, "c139ec855f8d547eca7c9a7cf04684b233ad77dcf7b3eb1cde27e72653620522")
addappid(982601, 1, "c139ec855f8d547eca7c9a7cf04684b233ad77dcf7b3eb1cde27e72653620522") -- PC Building Simulator - Deadstick Case - Deadstick Edition PC
addappid(1067591, 0, "6f7750fbf846134738d1cc1217eb3fd4c3b2ab8b01b72632418bab461bd567a9")
addappid(1067591, 1, "6f7750fbf846134738d1cc1217eb3fd4c3b2ab8b01b72632418bab461bd567a9") -- PC Building Simulator - Republic of Gamers Workshop - ASUS PC
addappid(1252991, 0, "81f5c96180e9d56dc4420bc2a12234569b73ee31ed2f2caa32cb7e0f6c64422e")
addappid(1252991, 1, "81f5c96180e9d56dc4420bc2a12234569b73ee31ed2f2caa32cb7e0f6c64422e") -- PC Building Simulator - Esports Expansion - CareerMode2
addappid(1295801, 0, "399e0f27eb31954c73fd4dab64bc4bdf6f9f52296c83dd359c9b5701d30cd883")
addappid(1295801, 1, "399e0f27eb31954c73fd4dab64bc4bdf6f9f52296c83dd359c9b5701d30cd883") -- PC Building Simulator - Overclockers UK Workshop - OC Workshop PC
addappid(1416671, 0, "5009289fe0dffa35b19502e8a4c051eba4c86568544c752b14f9bc45893755a3")
addappid(1416671, 1, "5009289fe0dffa35b19502e8a4c051eba4c86568544c752b14f9bc45893755a3") -- PC Building Simulator - AORUS Workshop - GBA Workshop PC
addappid(1591921, 0, "fdc918ec5412354aac886f088b9effeba01f8cd808aca3b20ac8d1cea92aae26")
addappid(1591921, 1, "fdc918ec5412354aac886f088b9effeba01f8cd808aca3b20ac8d1cea92aae26") -- PC Building Simulator - EVGA Workshop - Cooper
addtoken(621060, "8473074716846024589")

