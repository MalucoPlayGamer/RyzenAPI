-- Lua provided by RyzenAPI
-- Game: addappid(1774220)

-- MAIN APPLICATION
addappid(1774220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774221, 1, "39e57da87d1f429f0d085a9075fc7a341537e5dd73ab619d2ffc47e9a427203e")
