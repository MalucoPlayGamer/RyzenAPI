-- Lua provided by RyzenAPI
-- Game: Goddess Of Card War 2

-- MAIN APPLICATION
addappid(1999030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999031, 1, "df437e3ad9f944f42852b8c6f775ee0e8d3c90bf9ef726b393c9f2af2a99effe")

