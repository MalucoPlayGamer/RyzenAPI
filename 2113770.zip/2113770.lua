-- Lua provided by RyzenAPI 
-- Game: In Woods
addappid(2113770)
addappid(2113771, 1, "c721c72df588535be17618b5a496e1d8609d7399affc72736fc96f74c79372c7")
