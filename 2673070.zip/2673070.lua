-- Lua provided by RyzenAPI 
-- Game: Ardem Playtest
addappid(2673070)
addappid(2673071, 1, "4a20d554b654cc89b64c1657f1ceb9adef191d26460c851d7ec28eb145849fee")
addappid(2673072, 1, "a3c3e16bf4525b8d64b4f48a4d1a9766759bb79f13f1f005ad653d13997bad87")
