-- Lua provided by RyzenAPI
-- Game: World Fighting Soccer 22

-- MAIN APPLICATION
addappid(1465610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465612,0,"43291d22394ec7992767ad5274d2286de5e58c28ee62935cc73c2a96e957a200")

