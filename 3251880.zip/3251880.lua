-- Lua provided by RyzenAPI
-- Game: 3251880

-- MAIN APPLICATION
addappid(3251880)
-- Game: addappid(3251880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251881, 1, "400bf7bd2f7324f3887a8bc0e1610ed75b24583cdbc8315382b9e26635d39bb6")
