-- Lua provided by RyzenAPI
-- Game: Like a Dragon: Ishin!

-- MAIN APPLICATION
addappid(1805480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805481, 1, "b6865a3777287943bedd9ec78a50d638f0eea4d711441035e656bcc633a83765")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2104730)
addappid(2104731)
addappid(2104732)
addappid(2104733)
addappid(2104734)
addappid(2104735)
addappid(2104736)
addappid(2163170)
addappid(2163171)
addappid(2202540)
addappid(2223050)
