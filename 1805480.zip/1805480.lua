-- Lua provided by RyzenAPI
-- Game: Like a Dragon: Ishin!

-- MAIN APPLICATION
addappid(1805480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805481, 1, "b6865a3777287943bedd9ec78a50d638f0eea4d711441035e656bcc633a83765")

