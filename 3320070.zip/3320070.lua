-- Lua provided by RyzenAPI 
-- Game: Progress Knight: Multiplayer
addappid(3320070)
addappid(3320071, 1, "1be48b42ad33a9540044646b78310841379008c934b929fa6bb4346faa4cb30f")
