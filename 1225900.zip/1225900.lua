-- Lua provided by RyzenAPI
-- Game: AppID 1225900

-- MAIN APPLICATION
addappid(1225900)
-- Game: addappid(1225900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1225901, 1, "95dcaa5b493b851bca1650132a35adf0ec32da29d240b63fe6ae82ff9dc61fe7")
