-- Lua provided by RyzenAPI
-- Game: SOS: SPECIAL OPERATIVE STORIES

-- MAIN APPLICATION
addappid(501410)

-- MAIN APP DEPOTS / PACKAGES
addappid(501411, 1, "925465e4d906db1cdd0ffa7406ade59491663fcad9ff7c49294a7fc24f68d603")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
