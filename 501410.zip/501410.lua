-- Lua provided by RyzenAPI
-- Game: Game: SOS: SPECIAL OPERATIVE STORIES

-- MAIN APPLICATION
addappid(501410)
-- Game: addappid(501410)

-- MAIN APP DEPOTS / PACKAGES
addappid(501411, 1, "925465e4d906db1cdd0ffa7406ade59491663fcad9ff7c49294a7fc24f68d603")
