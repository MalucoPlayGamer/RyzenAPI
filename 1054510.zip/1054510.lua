-- Lua provided by RyzenAPI
-- Game: Survivalist: Invisible Strain

-- MAIN APPLICATION
addappid(1054510)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(1054511, 1, "4bb6f2708dc837f78156fadb98d5d7e0c06e598c26f6a4dac7a3711064372e7c")

