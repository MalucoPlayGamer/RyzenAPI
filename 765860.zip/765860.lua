-- Lua provided by RyzenAPI
-- Game: Game: Leisure Suit Larry 5 - Passionate Patti Does a Little Undercover Work

-- MAIN APPLICATION
addappid(765860)
-- Game: addappid(765860)

-- MAIN APP DEPOTS / PACKAGES
addappid(765861, 1, "c8c7ac5c51ee0aeef978acd2ea21fa22bc6faa110c672f217287de6d2e0699ab")
