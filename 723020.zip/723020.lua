-- Lua provided by RyzenAPI
-- Game: 3571 The Game

-- MAIN APPLICATION
addappid(723020)

-- MAIN APP DEPOTS / PACKAGES
addappid(723022,0,"cc0f336429ebe7069f104e8e5577aaab0e9e21e0847c8b3e150467103b3b0fb1")
