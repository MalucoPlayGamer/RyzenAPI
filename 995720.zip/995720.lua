-- Lua provided by RyzenAPI
-- Game: 995720

-- MAIN APPLICATION
addappid(995720)
-- Game: addappid(995720)

-- MAIN APP DEPOTS / PACKAGES
addappid(995721, 1, "1e34c76a127fa031ff947301ae870dcd89eb568ac61385da66ae73662b375633")
