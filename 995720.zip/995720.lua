-- Lua provided by RyzenAPI
-- Game: Coffee VendoR

-- MAIN APPLICATION
addappid(995720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(995721, 1, "1e34c76a127fa031ff947301ae870dcd89eb568ac61385da66ae73662b375633")

