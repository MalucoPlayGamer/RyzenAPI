-- Lua provided by SkyAPI 
-- Game: DUNGEON RAZE
addappid(3281300)
addappid(3281301, 1, "d547f63d43db6049c62db057e621be11aaf1a81b662aea9773f878ce278ea7d7")
