-- Lua provided by RyzenAPI
-- Game: Game: DUNGEON RAZE

-- MAIN APPLICATION
addappid(3281300)
-- Game: addappid(3281300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3281301, 1, "d547f63d43db6049c62db057e621be11aaf1a81b662aea9773f878ce278ea7d7")
