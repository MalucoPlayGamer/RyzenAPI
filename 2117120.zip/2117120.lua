-- Lua provided by RyzenAPI
-- Game: Horror Girls

-- MAIN APPLICATION
addappid(2117120)
-- Game: addappid(2117120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117121, 1, "7aec71525fd4a9a69fa58e1b7b256ee9fc5a28301c28f773aca569a5228a36fa")
