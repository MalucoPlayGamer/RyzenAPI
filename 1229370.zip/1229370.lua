-- Lua provided by SkyAPI 
-- Game: AppID 1229370
addappid(1229370)
addappid(1229371, 1, "287d1f5248e126e4f9f82e640087ce4ae1c26dfe74eb4afb94a0250edd91a9dd")
addappid(1229372, 1, "1128e869c6369db2e1046d1d64408bda31c43c3568db8d89ecddb2cc92b4d751")
