-- Lua provided by RyzenAPI 
-- Game: STARS ERA: ABYSS FRONTIER
addappid(1833540)
addappid(1833541, 1, "e5fb7c960cbb61665875bfc5d2e0b190833355aacea76a4332310b4930184b41")
