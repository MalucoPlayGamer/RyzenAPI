-- Lua provided by RyzenAPI
-- Game: addappid(1833540)

-- MAIN APPLICATION
addappid(1833540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833541, 1, "e5fb7c960cbb61665875bfc5d2e0b190833355aacea76a4332310b4930184b41")
