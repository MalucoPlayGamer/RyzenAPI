-- Lua provided by RyzenAPI
-- Game: STARS ERA: ABYSS FRONTIER

-- MAIN APPLICATION
addappid(1833540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1833541, 1, "e5fb7c960cbb61665875bfc5d2e0b190833355aacea76a4332310b4930184b41")

