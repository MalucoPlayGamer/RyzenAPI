-- Lua provided by RyzenAPI 
-- Game: Vibrant Frame
addappid(3016890)
addappid(3016891, 1, "9501d006a8a1d0c2336b472c408e18f877e01a35bf94fafd5012824dd221382e")
