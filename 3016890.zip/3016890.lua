-- Lua provided by RyzenAPI
-- Game: Game: Vibrant Frame

-- MAIN APPLICATION
addappid(3016890)
-- Game: addappid(3016890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016891, 1, "9501d006a8a1d0c2336b472c408e18f877e01a35bf94fafd5012824dd221382e")
