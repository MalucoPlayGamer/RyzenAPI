-- Lua provided by RyzenAPI
-- Game: Game: Adventure Paws Demo

-- MAIN APPLICATION
addappid(3261350)
-- Game: addappid(3261350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261351, 1, "bb30cbff3298775731e0968d980b7fa854082817d5d2119c0037a3b886f0cb94")
