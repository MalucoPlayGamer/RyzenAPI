-- Lua provided by RyzenAPI
-- Game: Guinea Pig Runaway Together

-- MAIN APPLICATION
addappid(4244190)
addappid(4789840)
addappid(5001950)

-- MAIN APP DEPOTS / PACKAGES
addappid(4244191,0,"da143e961f58b3b1a671dd460dd66056378ccd1d7b62df28546b558a77af58b8")

