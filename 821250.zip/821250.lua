-- Lua provided by RyzenAPI
-- Game: addappid(821250)

-- MAIN APPLICATION
addappid(821250)
addappid(4661240)

-- MAIN APP DEPOTS / PACKAGES
addappid(821251, 1, "56d2732aafc44c77401e0dfc97a9374d19b16610b85b9446aadcbaccdfaf7c20")
