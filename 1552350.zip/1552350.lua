-- Lua provided by RyzenAPI
-- Game: The Jackbox Party Pack 8

-- MAIN APPLICATION
addappid(1552350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1552351, 1, "3fcbabe634b9311927fc01de2915337010516cdf3041407ee4e396b2d335922a")
addappid(1552352, 1, "1afa6142bdb5c265ef54a70ff8159a444ea3470a1459de25af87efe7ac04e2e5")
addappid(1552353, 1, "35bee064e29bbd9de7b7d646e73a96dd2e60b76018c4b7255339483c9d6c7862")
addappid(1552354, 1, "3575bd82918a9966ef7db1a31a9ded6985b17fb9650fad28347c00afecf6ef0f")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")

