-- Lua provided by RyzenAPI
-- Game: Vinecard

-- MAIN APPLICATION
addappid(2649800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2649801, 1, "9684e996016beca183f204ee7259982a0db5674359252e46dc60f16ecac407f5")
