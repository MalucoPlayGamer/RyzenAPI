-- Lua provided by SkyAPI 
-- Game: Vinecard
addappid(2649800)
addappid(2649801, 1, "9684e996016beca183f204ee7259982a0db5674359252e46dc60f16ecac407f5")
