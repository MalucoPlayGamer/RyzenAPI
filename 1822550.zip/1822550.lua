-- Lua provided by RyzenAPI
-- Game: Game: Microcivilization

-- MAIN APPLICATION
addappid(1822550)
-- Game: addappid(1822550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822551, 1, "5421787f055413ef0f211e428a21df76c11bc65dac24967e5d50375c786b9044")
