-- Lua provided by RyzenAPI
-- Game: AppID 292600

-- MAIN APPLICATION
addappid(292600)
addappid(386250)

-- MAIN APP DEPOTS / PACKAGES
addappid(292601, 1, "e5312040eccc20d6e2a7ea11b4b592242ca828b2bb80c8db1a7234c74e487624")
addappid(292602, 1, "d0aaea7daddb90e29aee1fff9ce502fce6654d025e79233772b0206120d985d4")
addappid(292603, 1, "8b140ae1be829c877594db576e938c9d460ee447d0c0a1b9c71ac592421b1369")
addappid(292604, 1, "77c7068a9ff1019db210caa5d848941faff0a81f498e7781030c781affbf1db6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
