-- Lua provided by RyzenAPI
-- Game: Duet

-- MAIN APPLICATION
addappid(292600)
addappid(386250)
-- Game: addappid(292600)

-- MAIN APP DEPOTS / PACKAGES
addappid(292601, 1, "e5312040eccc20d6e2a7ea11b4b592242ca828b2bb80c8db1a7234c74e487624")
addappid(292602, 1, "d0aaea7daddb90e29aee1fff9ce502fce6654d025e79233772b0206120d985d4")
addappid(292603, 1, "8b140ae1be829c877594db576e938c9d460ee447d0c0a1b9c71ac592421b1369")
addappid(292604, 1, "77c7068a9ff1019db210caa5d848941faff0a81f498e7781030c781affbf1db6")
