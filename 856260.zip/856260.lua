-- Lua provided by RyzenAPI 
-- Game: AppID 856260
addappid(856260)
addappid(856261, 1, "1228670be808a81a535a5a20349592f5c970bca7c14f54f5964a1d51e5d5a7d6")
