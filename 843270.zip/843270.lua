-- Lua provided by RyzenAPI
-- Game: AppID 843270

-- MAIN APPLICATION
addappid(843270)

-- MAIN APP DEPOTS / PACKAGES
addappid(843271, 1, "47560b9b6e4b2c165ae38a264498181393b01074ca98f794798193a79b3014a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
