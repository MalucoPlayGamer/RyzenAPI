-- Lua provided by RyzenAPI
-- Game: Unforgiven VR

-- MAIN APPLICATION
addappid(546210)

-- MAIN APP DEPOTS / PACKAGES
addappid(546211, 1, "f83f0b7d814c960b3588ac4ad200511153e903db979ca34073c458beb61e1139")
