-- Lua provided by RyzenAPI
-- Game: Dark Train

-- MAIN APPLICATION
addappid(532290)
addappid(645040)
-- Game: addappid(532290)

-- MAIN APP DEPOTS / PACKAGES
addappid(532291, 1, "ded4065bd4d16dcff28f95399eac054594f15c8c5264832bad9669c90590cf7a")
addappid(532292, 1, "280fa49d2b378f96771983b440ee004e5427f10e720df6cd9bcbf66002c21413")
