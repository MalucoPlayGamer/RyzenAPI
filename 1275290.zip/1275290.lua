-- Lua provided by RyzenAPI
-- Game: Game: Dream Catcher

-- MAIN APPLICATION
addappid(1275290)
-- Game: addappid(1275290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275291, 1, "8e9c54db4f70cd76d9dce9ede103be912fa5c2c1e3f921009cee1d8f5dbe36ac")
