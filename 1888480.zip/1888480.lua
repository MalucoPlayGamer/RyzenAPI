-- Lua provided by SkyAPI 
-- Game: Wild Radio Flux
addappid(1888480)
addappid(1888481, 1, "cff657f0f500c17adfe04abcfba5f8d7ed00d46e9e332d988429c446309cf8f6")
