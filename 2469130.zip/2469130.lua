-- Lua provided by RyzenAPI
-- Game: Game: Cybertrash STATYX

-- MAIN APPLICATION
addappid(2469130)
-- Game: addappid(2469130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469131, 1, "289d764fb0b939f20b539b7e113731287eeb85c3bd06605abe0cc911fd84bba1")
