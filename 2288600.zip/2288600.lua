-- Lua provided by RyzenAPI
-- Game: Son of a Gun

-- MAIN APPLICATION
addappid(2288600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288601, 1, "ef10397de74874a2ca319895e1387c75b7e375a273a1af536cf27da7c3aca32c")
