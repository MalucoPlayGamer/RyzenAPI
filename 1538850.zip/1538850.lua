-- Lua provided by RyzenAPI
-- Game: Grotto

-- MAIN APPLICATION
addappid(1538850)
-- Game: addappid(1538850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538851, 1, "69629389524d2198d599323189e9fec1349d1ac0a09d572e94238dcec7f6516e")
