-- Lua provided by RyzenAPI 
-- Game: AppID 310990
addappid(310990)
addappid(310991, 1, "14f0a2f93298d5deb3f0219d55169900f8d1d396bb59be5ff3232a96c673c42a")
