-- Lua provided by RyzenAPI
-- Game: Man in a Maze: Deathmatch

-- MAIN APPLICATION
addappid(310990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(310991, 1, "14f0a2f93298d5deb3f0219d55169900f8d1d396bb59be5ff3232a96c673c42a")
