-- Lua provided by RyzenAPI
-- Game: Game of seduction

-- MAIN APPLICATION
addappid(1925060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925061, 1, "5f63de0d852c03df13a34b95d04297a412dd9aa51c22fc0ac49227aa70231e8f")
