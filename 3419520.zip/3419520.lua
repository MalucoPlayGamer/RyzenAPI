-- Lua provided by RyzenAPI
-- Game: Quarantine Zone: The Last Check

-- MAIN APPLICATION
addappid(3419520)
addappid(3960620)
addappid(3960630)
addappid(3960640)
addappid(3960650)
addappid(3960660)
addappid(4312380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3419521, 1, "7763e89ed36372394d459530e45e7dab3aca85588166e1c59d3bd1f7993bfac6")

