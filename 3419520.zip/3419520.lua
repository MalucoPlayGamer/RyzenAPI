-- Lua provided by RyzenAPI
-- Game: Quarantine Zone: The Last Check

-- MAIN APPLICATION
addappid(3419520)
addappid(3960620)
addappid(3960630)
addappid(3960640)
addappid(3960650)
addappid(3960660)
addappid(4312380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3419521, 1, "7763e89ed36372394d459530e45e7dab3aca85588166e1c59d3bd1f7993bfac6")
