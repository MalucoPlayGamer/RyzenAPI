-- Lua provided by RyzenAPI
-- Game: addappid(1642960)

-- MAIN APPLICATION
addappid(1642960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642961, 1, "f22deb2af0cf7c23e57374d7209a07c84c743a9731900e30d340fecd66197223")
