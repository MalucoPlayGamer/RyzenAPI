-- Lua provided by RyzenAPI
-- Game: Nevertales: Legends Collector's Edition

-- MAIN APPLICATION
addappid(758640)

-- MAIN APP DEPOTS / PACKAGES
addappid(758641,0,"aed93b53eec6a67875baa92e9ca575f147052708eda70ec4b4d56f140cdd4c79")

