-- Lua provided by RyzenAPI
-- Game: Hot Milf

-- MAIN APPLICATION
addappid(1800950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800951, 1, "fa683ccf38940fa141c7b0659972f31583efd7107336518cfcbdbefdef11781e")
