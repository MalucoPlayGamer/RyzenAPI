-- Lua provided by RyzenAPI
-- Game: Game: TIMORE REMAKE

-- MAIN APPLICATION
addappid(2150970)
-- Game: addappid(2150970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150971, 1, "807ebb5bb42143da627dedc88215c97fcd77c89603364fe52ceb5971d423da6d")
