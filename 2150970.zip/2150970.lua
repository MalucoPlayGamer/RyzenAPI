-- Lua provided by RyzenAPI
-- Game: 2150970

-- MAIN APPLICATION
addappid(2150970)
-- Game: addappid(2150970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150971, 1, "807ebb5bb42143da627dedc88215c97fcd77c89603364fe52ceb5971d423da6d")
