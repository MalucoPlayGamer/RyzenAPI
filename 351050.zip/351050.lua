-- Lua provided by RyzenAPI
-- Game: Cricket Captain 2015

-- MAIN APPLICATION
addappid(351050)

-- MAIN APP DEPOTS / PACKAGES
addappid(351051, 1, "90cac4d9d1af35b03d09b3f3ca6a82df494b12eb52c627001b4ee9874dd7c7aa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
