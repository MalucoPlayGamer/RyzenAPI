-- Lua provided by SkyAPI 
-- Game: Cricket Captain 2015
addappid(351050)
addappid(351051, 1, "90cac4d9d1af35b03d09b3f3ca6a82df494b12eb52c627001b4ee9874dd7c7aa")
