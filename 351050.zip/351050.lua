-- Lua provided by RyzenAPI
-- Game: Cricket Captain 2015

-- MAIN APPLICATION
addappid(351050)

-- MAIN APP DEPOTS / PACKAGES
addappid(351051, 1, "90cac4d9d1af35b03d09b3f3ca6a82df494b12eb52c627001b4ee9874dd7c7aa")
