-- Lua provided by RyzenAPI
-- Game: Aim Hero

-- MAIN APPLICATION
addappid(518030)

-- MAIN APP DEPOTS / PACKAGES
addappid(518031, 1, "fe0bca43c08b69a43f4658b555e6ea290e19472bee0a9d185ae5179e0a266467")

