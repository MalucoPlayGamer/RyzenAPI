-- Lua provided by RyzenAPI
-- Game: Sex Wheel - An Erotic Game

-- MAIN APPLICATION
addappid(1327870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327871,0,"f4011111691367165439b5760a574d5b6302e4aaab36d0e08ee9841ab1b3eb7d")

