-- Lua provided by RyzenAPI
-- Game: Puzzle Art: Reptiles

-- MAIN APPLICATION
addappid(1786290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786291, 1, "a4d3f04d56f7532960b5236f2dba49466d432771d527dddc14d34d210ac90f29")

