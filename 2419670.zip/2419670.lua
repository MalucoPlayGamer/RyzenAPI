-- Lua provided by RyzenAPI
-- Game: Eclipsium

-- MAIN APPLICATION
addappid(2419670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419671, 1, "c41e1728cc55c498046c15e73e08dca0970c9dbb67d95bb5231e4f1e53166437")
