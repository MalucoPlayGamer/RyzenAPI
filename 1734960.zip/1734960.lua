-- Lua provided by RyzenAPI
-- Game: 1734960

-- MAIN APPLICATION
addappid(1734960)
-- Game: addappid(1734960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734961, 1, "6e499ee7742fa863b2d13bf1310775957385a0cc164b02fdccf015ac8f5f41fa")
addappid(1734963, 1, "6f46cae777e3caca6f52e4237364eb6e120836a27806f67c59ecb55eb9c75a72")
