-- Lua provided by RyzenAPI
-- Game: Cursed Order

-- MAIN APPLICATION
addappid(2674270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674271, 1, "b171fa908c1012f3049b28a509425f117b37b047700da209ad0b6b18e7d89b69")

