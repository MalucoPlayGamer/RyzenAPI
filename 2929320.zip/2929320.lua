-- Lua provided by RyzenAPI
-- Game: Firefighter Connor - Digital CG Image Pack

-- MAIN APPLICATION
addappid(2929320)
-- Game: addappid(2929320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929321, 1, "193f22a7b0a4e1fbefbb273957ea0cffff10d8d840797463defcf154f5734462")
