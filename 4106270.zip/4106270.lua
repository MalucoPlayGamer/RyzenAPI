-- Lua provided by RyzenAPI
-- Game: Ecrazeus Castle

-- MAIN APP DEPOTS / PACKAGES
addappid(4106270, 1, "adb868d3edb15c4d74e3cfdb8d94446a44859b6895c0019b4d2840caf2e15d02") -- Ecrazeus Castle
addappid(4106271, 1, "c736864a0302fe9b9fdae8d6353dc48e1830ade0da690cab7eec1efcf52c5276") -- Depot 4106271

