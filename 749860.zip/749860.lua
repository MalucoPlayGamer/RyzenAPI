-- Lua provided by SkyAPI 
-- Game: AppID 749860
addappid(749860)
addappid(749861, 1, "3e714dd7ec35c5c8a5826fee31600edba267a0a7b01e59b8384b1502641c6c4a")
