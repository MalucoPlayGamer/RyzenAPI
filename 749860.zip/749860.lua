-- Lua provided by RyzenAPI
-- Game: Game: AppID 749860

-- MAIN APPLICATION
addappid(749860)
-- Game: addappid(749860)

-- MAIN APP DEPOTS / PACKAGES
addappid(749861, 1, "3e714dd7ec35c5c8a5826fee31600edba267a0a7b01e59b8384b1502641c6c4a")
