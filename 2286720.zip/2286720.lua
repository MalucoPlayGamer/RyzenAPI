-- Lua provided by RyzenAPI
-- Game: 2286720

-- MAIN APPLICATION
addappid(2286720)
-- Game: addappid(2286720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286721, 1, "051f960125053b2c6f741bfe9b5638dea0622e4ff15aa12a0131d8976b90f42f")
