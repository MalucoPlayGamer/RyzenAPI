-- Lua provided by RyzenAPI 
-- Game: Glimmer Chain
addappid(2286720)
addappid(2286721, 1, "051f960125053b2c6f741bfe9b5638dea0622e4ff15aa12a0131d8976b90f42f")
