-- Lua provided by RyzenAPI
-- Game: Game: Life is Strange Remastered

-- MAIN APPLICATION
addappid(1265920)
addappid(1537870)
-- Game: addappid(1265920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265921, 1, "1d3906ef8fa5305f9430e0cdb7db5a577fe38da35a49dba3ec73ad9468f65807")
