-- Lua provided by RyzenAPI
-- Game: Life is Strange Remastered

-- MAIN APPLICATION
addappid(1265920)
addappid(1537870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265921, 1, "1d3906ef8fa5305f9430e0cdb7db5a577fe38da35a49dba3ec73ad9468f65807")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
