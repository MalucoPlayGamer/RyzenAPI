-- Lua provided by RyzenAPI
-- Game: addappid(2371130)

-- MAIN APPLICATION
addappid(2371130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371131, 1, "9fa429be135ef766077096ef93b94eebb94c41c82c522f990a734e328d452a6a")
