-- Lua provided by RyzenAPI
-- Game: The Confines Of The Crown

-- MAIN APPLICATION
addappid(356530)

-- MAIN APP DEPOTS / PACKAGES
addappid(356532,0,"0face67b90ebe285020c3cc53f953fb6e0e7216d95e9fc437ccbd412693df8b9")
addappid(356535,0,"45b383c93bddf387e96c887780806d0420b55977bfe6505fb29406c62ce984fd")
