-- Lua provided by RyzenAPI
-- Game: Game: Scifi Racing Team

-- MAIN APPLICATION
addappid(3026180)
-- Game: addappid(3026180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026181, 1, "7b009c5e7117b924a1680744de8ac938620573516f4292fccf005671738b0d9d")
