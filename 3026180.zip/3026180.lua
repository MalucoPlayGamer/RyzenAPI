-- Lua provided by SkyAPI 
-- Game: Scifi Racing Team
addappid(3026180)
addappid(3026181, 1, "7b009c5e7117b924a1680744de8ac938620573516f4292fccf005671738b0d9d")
