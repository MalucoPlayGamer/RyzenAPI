-- Lua provided by RyzenAPI
-- Game: addappid(834060)

-- MAIN APPLICATION
addappid(834060)

-- MAIN APP DEPOTS / PACKAGES
addappid(834061, 1, "ffe3a01a055482849c15662853de94cb1c9c5e24f6e10878aa13825697f778cc")
