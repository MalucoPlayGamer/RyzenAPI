-- Lua provided by RyzenAPI
-- Game: Remnants

-- MAIN APPLICATION
addappid(1121680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121681, 1, "7ecf197c4074c7d0a234e2dcbae6257418247c95afd75719532f98690d4184a1")
