-- Lua provided by RyzenAPI
-- Game: Game: Carmageddon TDR 2000

-- MAIN APPLICATION
addappid(331650)
-- Game: addappid(331650)

-- MAIN APP DEPOTS / PACKAGES
addappid(331651, 1, "bb0c627ad9ca4e4d1e4c8155aa545290b5ac67dd2b68b19ce40e6e3a90e755d2")
