-- Lua provided by RyzenAPI
-- Game: Game: AppID 573190

-- MAIN APPLICATION
addappid(573190)
-- Game: addappid(573190)

-- MAIN APP DEPOTS / PACKAGES
addappid(573191, 1, "5f24927041184cdd53a52a34abd4f83d3bde306f938028937714b1455ffe1e2f")
