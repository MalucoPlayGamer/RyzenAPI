-- Lua provided by RyzenAPI 
-- Game: AppID 573190
addappid(573190)
addappid(573191, 1, "5f24927041184cdd53a52a34abd4f83d3bde306f938028937714b1455ffe1e2f")
