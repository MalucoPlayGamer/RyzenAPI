-- Lua provided by RyzenAPI
-- Game: 495290

-- MAIN APPLICATION
addappid(495290)
-- Game: addappid(495290)

-- MAIN APP DEPOTS / PACKAGES
addappid(495291, 1, "018315541766bcf30b7d1e2d4f0c07516e22de4bbdfdb4bb91e717014caa849d")
