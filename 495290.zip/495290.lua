-- Lua provided by RyzenAPI
-- Game: AccuRC 2

-- MAIN APPLICATION
addappid(495290)

-- MAIN APP DEPOTS / PACKAGES
addappid(495291, 1, "018315541766bcf30b7d1e2d4f0c07516e22de4bbdfdb4bb91e717014caa849d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
