-- Lua provided by RyzenAPI
-- Game: Haunted House 2

-- MAIN APPLICATION
addappid(2865220)
-- Game: addappid(2865220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865221, 1, "ba5f700ef19a6c7e3bd1e33635781bd73ef7d6a2b00ece15a0756db7e3324e8e")
