-- Lua provided by RyzenAPI
-- Game: addappid(530550)

-- MAIN APPLICATION
addappid(530550)

-- MAIN APP DEPOTS / PACKAGES
addappid(530551, 1, "1aa8cb3a185555e4157cb0917a6186b8397c1071e2e020e3f47a554db9b0132f")
