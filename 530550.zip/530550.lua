-- Lua provided by RyzenAPI
-- Game: Bubble Jungle ® Super Chameleon Platformer World

-- MAIN APPLICATION
addappid(530550)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(530551, 1, "1aa8cb3a185555e4157cb0917a6186b8397c1071e2e020e3f47a554db9b0132f")

