-- Lua provided by RyzenAPI
-- Game: Movavi Video Suite 2024 - Neon Vlog Pack

-- MAIN APPLICATION
addappid(2690560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690560,0,"8ff9c0407fec08364b895929651918a49cfead4b9e909c34e6245a790108f3a6")

