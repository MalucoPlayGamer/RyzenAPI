-- Lua provided by RyzenAPI
-- Game: Rhythm Zone

-- MAIN APPLICATION
addappid(38900)
addappid(38920)
addappid(38921)
addappid(38922)
addappid(38923)
addappid(38924)
addappid(38925)
addappid(38926)
addappid(38927)

-- MAIN APP DEPOTS / PACKAGES
addappid(38901, 1, "e501ecbc918b551fbf7d7e4767e9d3b4cef495f3173f7c37b75d4cdc2e98377b")

