-- Lua provided by RyzenAPI
-- Game: addappid(1792750)

-- MAIN APPLICATION
addappid(1792750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792750,0,"321dd0bd6e467195d8890c9073d183075de7f8a4faf082155b08ef85bea618fe")
