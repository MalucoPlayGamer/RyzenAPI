-- Lua provided by RyzenAPI
-- Game: Dreambound Demo

-- MAIN APPLICATION
addappid(2077510)
-- Game: addappid(2077510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077511, 1, "3710471ae450b2c141096248789eec40af255470a7213aa72355aa9675eebdad")
