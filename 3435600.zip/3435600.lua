-- Lua provided by RyzenAPI
-- Game: PEXIT 8

-- MAIN APPLICATION
addappid(3435600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3435601, 1, "a8be0494e51459fb5811496b27266e115f7664e5d18279531c164e58ec8b15a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
