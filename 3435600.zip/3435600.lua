-- Lua provided by RyzenAPI 
-- Game: PEXIT 8
addappid(3435600)
addappid(3435601, 1, "a8be0494e51459fb5811496b27266e115f7664e5d18279531c164e58ec8b15a9")
