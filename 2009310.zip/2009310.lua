-- Lua provided by RyzenAPI
-- Game: Goi: Spooky Run

-- MAIN APPLICATION
addappid(2009310)
-- Game: addappid(2009310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009311, 1, "c5af7d21667e96d3d1c3b646298840d6b862e59f7c92ad3638284903885c997a")
