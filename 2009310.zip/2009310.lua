-- Lua provided by SkyAPI 
-- Game: Goi: Spooky Run
addappid(2009310)
addappid(2009311, 1, "c5af7d21667e96d3d1c3b646298840d6b862e59f7c92ad3638284903885c997a")
