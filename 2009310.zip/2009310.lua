-- Lua provided by RyzenAPI
-- Game: Goi: Spooky Run

-- MAIN APPLICATION
addappid(2009310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2009311, 1, "c5af7d21667e96d3d1c3b646298840d6b862e59f7c92ad3638284903885c997a")

