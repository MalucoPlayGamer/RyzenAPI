-- Lua provided by RyzenAPI
-- Game: 2017580

-- MAIN APPLICATION
addappid(2017580)
-- Game: addappid(2017580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017581, 1, "b72790b9b22ef375a9f054d161b11d3e906ba2a7fa2a4762c060937fd88d9e37")
