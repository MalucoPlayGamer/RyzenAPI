-- Lua provided by RyzenAPI
-- Game: addappid(1584030)

-- MAIN APPLICATION
addappid(1584030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584031, 1, "e9878173a618c4dd7edb7f64a45a60a490ca6fb60d21e5b69afc157273225929")
