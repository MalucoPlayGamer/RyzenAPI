-- Lua provided by RyzenAPI
-- Game: AppID 380770

-- MAIN APPLICATION
addappid(380770)
addappid(383370)
addappid(384340)
addappid(384520)
addappid(386910)
addappid(386911)
addappid(386913)
addappid(386920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(380771, 1, "7f39a8b6f1a0260b2120eee094dd7fbf208916b838b5db8e07ad01c8361f80f4")

