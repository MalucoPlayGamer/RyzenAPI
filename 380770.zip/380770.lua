-- Lua provided by RyzenAPI 
-- Game: AppID 380770
addappid(380770)
addappid(380771, 1, "7f39a8b6f1a0260b2120eee094dd7fbf208916b838b5db8e07ad01c8361f80f4")
addappid(383370)
addappid(384520)
addappid(386910)
addappid(386911)
