-- Lua provided by RyzenAPI
-- Game: Virtual Surfing

-- MAIN APPLICATION
addappid(228987)
addappid(993340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(993342,0,"9d034170c4ccedfddfcf2c6fc82163e22b4a2ac12bee78f70f30175d6eb00445")

