-- Lua provided by RyzenAPI
-- Game: Great Permutator

-- MAIN APPLICATION
addappid(319270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(319271, 1, "089e263cfdfde1a3d545b9832659dc54b19ef2b00300a15ecd623c0eb9bb4e46")
addappid(319272, 1, "da735747a8ea81cd05ab69d0b5bc5e4d67d98a7fe133f2ef002f4cc820268776")
addappid(319273, 1, "6ba47c98cc7a102a0b84af0b24a002a3353973fa6b78b86e5dad81f60c78e595")

