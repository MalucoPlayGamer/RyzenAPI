-- Lua provided by RyzenAPI
-- Game: AppID 365680

-- MAIN APPLICATION
addappid(365680)

-- MAIN APP DEPOTS / PACKAGES
addappid(365681, 1, "6666731fde48754ee205b098a99cfa2fc8f968480a478af21a8ebdb6720d9a3a")
addappid(365682, 1, "907752fb938c9812dd39380f03156e48dcf7ff06eaf63ce72db16409a7032d98")
addappid(365683, 1, "f5271be9957fba48f6c6662c5daf8ae3e4d3de5363273cfb09760df455d44e15")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
