-- Lua provided by RyzenAPI
-- Game: Eldevin

-- MAIN APPLICATION
addappid(298160)
addappid(315050)
addappid(337400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(298161, 1, "ba0367dc5b21502be38e7076f2c0c133cf29367447acc0d0a08381ce17d717f0")
addappid(298162, 1, "63adfb16e23ddaf2b8ba8d591ba1768e0c00f790e8b181994cd6db82744a9985")
addappid(298163, 1, "8a96bbd0855132e878a5a676c2771aadd60ab85f66a45953327b0387d7600c63")
addappid(298164, 1, "f2ef017e245510a0d2efc51cc95cff9a2161a3c2484ee3cceff34d385eca84fa")

