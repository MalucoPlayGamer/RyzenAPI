-- Lua provided by RyzenAPI
-- Game: AppID 1155460

-- MAIN APPLICATION
addappid(1155460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155461, 1, "3eb9a1a172f2056f52707dec2f52c516c29387ced84c45e33d8688d9f839f34e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
