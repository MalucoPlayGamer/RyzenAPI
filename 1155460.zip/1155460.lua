-- Lua provided by RyzenAPI 
-- Game: AppID 1155460
addappid(1155460)
addappid(1155461, 1, "3eb9a1a172f2056f52707dec2f52c516c29387ced84c45e33d8688d9f839f34e")
