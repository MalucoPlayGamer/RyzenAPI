-- Lua provided by RyzenAPI
-- Game: Mass Effect™ 3 Resurgence

-- MAIN APPLICATION
addappid(1317487)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317487,0,"fb9a46610848a0bb8a7d512955c54c1b1a05f962d42034e57554febebe72e2cf")
addappid(1317630,0,"0395af8171fd2517c795de2413a35faff189be7681df8dadf9e77d5e9f03b391")
addappid(1317631,0,"d14155f4a59aac011438296b27f067af082b7eca91d55e32e000ba100d840223")
addappid(1317634,0,"8b1d45af9dc386f139a88eddfafcef77e497e94f5a6af00c841f1a5f3b17f681")

