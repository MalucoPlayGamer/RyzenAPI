-- Lua provided by RyzenAPI
-- Game: 2505090

-- MAIN APPLICATION
addappid(2505090)
-- Game: addappid(2505090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505091, 1, "6427d7370c8f8c024c73182b894288af18828f0e0fdfc61dfff7e715319be024")
