-- Lua provided by RyzenAPI
-- Game: Boogeyman 3

-- MAIN APPLICATION
addappid(2505090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2505091, 1, "6427d7370c8f8c024c73182b894288af18828f0e0fdfc61dfff7e715319be024")
