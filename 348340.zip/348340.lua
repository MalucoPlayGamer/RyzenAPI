-- Lua provided by RyzenAPI
-- Game: Siege Wars

-- MAIN APPLICATION
addappid(348340)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(348341, 1, "d312653f9ddc578bb001fb6349374366e86cfff15201983e8df6b86c921ecf37")
addappid(348342, 1, "f93592994c244656d678ea601ab8e64d25287a1b1cbd82b8fb2eda11031c086f")
addappid(348343, 1, "3ac352e9e4eacb8f4748e4ab582a4ccc109eb9a05912d8fc936b580f2409dbb8")
