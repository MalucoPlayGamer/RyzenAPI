-- Lua provided by RyzenAPI
-- Game: Nullvein: Incremental Mining Evolution

-- MAIN APPLICATION
addappid(4659340) -- Nullvein: Incremental Mining Evolution
-- addappid(4659341) -- Depot 4659341 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4659342, 1, "08d03dbeff1a5f5d4c833409830d9b02150ec34c89e5cf1bcdfeef5f99e8e64e") -- Depot 4659342

