-- 4659340's Lua and Manifest Created by Hubcap Manifest
-- Nullvein: Incremental Mining Evolution
-- Created: August 18, 2026 at 13:32:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4659340) -- Nullvein: Incremental Mining Evolution
-- MAIN APP DEPOTS
addappid(4659342, 1, "08d03dbeff1a5f5d4c833409830d9b02150ec34c89e5cf1bcdfeef5f99e8e64e") -- Depot 4659342
setManifestid(4659342, "4337352174284225408", 202509157)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4659341) -- Depot 4659341 (empty depot)