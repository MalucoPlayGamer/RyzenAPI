-- Lua provided by RyzenAPI
-- Game: Bulanci

-- MAIN APPLICATION
addappid(1732920)
addappid(2400030)
addappid(2553060)
addappid(2553070)
addappid(3097980)
addappid(4167270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1732921, 1, "34f187241217260273ebc2a4bc3f681001c5c60ab91c63eba6e1a40ad25748e0")

