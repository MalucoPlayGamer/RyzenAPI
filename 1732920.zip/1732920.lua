-- Lua provided by RyzenAPI
-- Game: Bulanci

-- MAIN APPLICATION
addappid(1732920)
-- Game: addappid(1732920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732921, 1, "34f187241217260273ebc2a4bc3f681001c5c60ab91c63eba6e1a40ad25748e0")
