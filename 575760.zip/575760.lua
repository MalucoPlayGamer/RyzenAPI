-- Lua provided by RyzenAPI
-- Game: Project: R.E.B.O.O.T 2

-- MAIN APPLICATION
addappid(575760)

-- MAIN APP DEPOTS / PACKAGES
addappid(575761, 1, "468a350edcaf85295dee5a66a33e550b4897d1f02c21fc2dcc4752e3f0ed366c")
