-- 4450190's Lua and Manifest Created by Hubcap Manifest
-- ConsoleMe
-- Created: July 16, 2026 at 07:45:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4450190) -- ConsoleMe
-- MAIN APP DEPOTS
addappid(4450191, 1, "26a62d5cd6e09b787826498bd28e6c05052612f7fb16420e6c2137332ca0e9a3") -- Depot 4450191
setManifestid(4450191, "8912082671599662571", 1955634328)