-- Lua provided by RyzenAPI
-- Game: Game: Arco

-- MAIN APPLICATION
addappid(2366970)
-- Game: addappid(2366970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366971, 1, "137082a90d91f5559809c7165ff97810b93e27a86cf0719258cc77525f758523")
