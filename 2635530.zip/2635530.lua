-- Lua provided by RyzenAPI
-- Game: 2635530

-- MAIN APPLICATION
addappid(2635530)
-- Game: addappid(2635530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635531, 1, "87bb21b950f1db8c6fa4187061fba88677cd20aab9f5132730dba6e0c087e401")
