-- Lua provided by RyzenAPI
-- Game: Food Monster and Animals Memory Match

-- MAIN APPLICATION
addappid(784040)

-- MAIN APP DEPOTS / PACKAGES
addappid(784041, 1, "328e51ba9d7dbb2704c07673faa3893a2c5c772695f5675494a3e08e3aad0b17")
