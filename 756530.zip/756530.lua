-- Lua provided by RyzenAPI
-- Game: AppID 756530

-- MAIN APPLICATION
addappid(756530)

-- MAIN APP DEPOTS / PACKAGES
addappid(756531, 1, "802ade737f719929dc331cdd738dbae2fde8d894e218605cc06d07e1a5fa703f")

