-- Lua provided by RyzenAPI
-- Game: addappid(2939520)

-- MAIN APPLICATION
addappid(2939520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2939521, 1, "edc7e57b0578adff4fe1f26897c15b4c1b2691aff1f7fa83117fe91c2e959781")
