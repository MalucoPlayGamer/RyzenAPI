-- Lua provided by RyzenAPI
-- Game: DAMA GALLERIA

-- MAIN APPLICATION
addappid(1654730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654731, 1, "4838efb2c0680e48cd4d3b69e03bc10c803730a5cdc26f74ec2b569793838882")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
