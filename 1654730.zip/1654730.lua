-- Lua provided by RyzenAPI
-- Game: 1654730

-- MAIN APPLICATION
addappid(1654730)
-- Game: addappid(1654730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654731, 1, "4838efb2c0680e48cd4d3b69e03bc10c803730a5cdc26f74ec2b569793838882")
