-- Lua provided by RyzenAPI
-- Game: 1983690

-- MAIN APPLICATION
addappid(1983690)
-- Game: addappid(1983690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983691, 1, "cefc8bd66fa5e15686664090834f54fb00875e0e7dea9a8701dd0eef03b9ad4d")
