-- Lua provided by RyzenAPI
-- Game: addappid(3722590)

-- MAIN APPLICATION
addappid(3722590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3722591, 1, "b32398882a27f8debe975d9290481abe7edbb7c7990a1291d64cd473ca597dc4")
