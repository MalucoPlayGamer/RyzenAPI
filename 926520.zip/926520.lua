-- Lua provided by RyzenAPI
-- Game: Game: Love Letter

-- MAIN APPLICATION
addappid(926520)
-- Game: addappid(926520)

-- MAIN APP DEPOTS / PACKAGES
addappid(926521, 1, "3ed6cf33670c9cf3d474bee987f5f1f775a818d2e4c37bc772adc0d30c754395")
addappid(926522, 1, "73485edb61044e1168ba72e97ddd7de15c5046eba3f95afd461164dcdcc88e2e")
addappid(926523, 1, "3757d52f0e5d2873f3d8854f03a7da456a0a4a92ce830e50514647b8e70cd955")
