-- Lua provided by RyzenAPI
-- Game: Epic Flail

-- MAIN APPLICATION
addappid(500180)

-- MAIN APP DEPOTS / PACKAGES
addappid(500181, 1, "26a5bab6b327e97cf255d861bd71ae3d8e5665f5eb55db65204d1473ea4a75c6")

