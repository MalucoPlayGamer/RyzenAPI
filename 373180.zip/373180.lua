-- Lua provided by RyzenAPI
-- Game: AppID 373180

-- MAIN APPLICATION
addappid(373180)

-- MAIN APP DEPOTS / PACKAGES
addappid(373181, 1, "a6b838ebe750fdf307f3123ab8118ca48f81bd988722d19a9e58781456e630a9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1789150)
addappid(1805330)
