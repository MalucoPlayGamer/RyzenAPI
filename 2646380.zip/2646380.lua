-- Lua provided by RyzenAPI
-- Game: Game: AppID 2646380

-- MAIN APPLICATION
addappid(2646380)
-- Game: addappid(2646380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646381, 1, "d20a6e964f26ab03c807eec61544c7988987e08249fca8c8af7d4243265968e9")
