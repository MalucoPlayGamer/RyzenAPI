-- Lua provided by RyzenAPI 
-- Game: Nobody - The Turnaround
addappid(1810580)
addappid(1810581, 1, "0243ab0a120d40649c6fd221a81db41c79f57303cdcffdd17db18a783a72e39d")
addappid(1810582, 1, "ab709f0af30451d1986923a218be8c2617fe0a1baeb043ace923e2c683bf951f")
