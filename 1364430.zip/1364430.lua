-- Lua provided by RyzenAPI
-- Game: 1364430

-- MAIN APPLICATION
addappid(1364430)
-- Game: addappid(1364430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364431, 1, "1b482e693f011ce0c24aefae08842d24a1f24a33aae59106e07ff2ac0af870d3")
