-- Lua provided by SkyAPI 
-- Game: AppID 214820
addappid(214820)
addappid(214821, 1, "e88032d63ed9861dd396e9e86eb23e6a6d84d82b4b8ae1ba70b7b5db93cdc4d8")
