-- Lua provided by RyzenAPI
-- Game: Game: Flow:The Sliding

-- MAIN APPLICATION
addappid(661000)
-- Game: addappid(661000)

-- MAIN APP DEPOTS / PACKAGES
addappid(661001, 1, "81b064d7a04716ec8cc4e7cb1096a7c85fcc8415264c75d206e4a1376e7c7eb7")
