-- Lua provided by RyzenAPI
-- Game: 1107960

-- MAIN APPLICATION
addappid(1107960)
-- Game: addappid(1107960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107961, 1, "fd6aa712a082b6cb4884a3fcf5ddda8cc1ccf4b7ca6ce0da402386a8e76c34e5")
