-- Lua provided by RyzenAPI
-- Game: The Roy Game

-- MAIN APPLICATION
addappid(1373670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373671, 1, "ad4972c8b53715ae160dc547b6497ae21f590d02cc394864c08a4dc7f17cd852")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
