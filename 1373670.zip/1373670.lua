-- Lua provided by RyzenAPI
-- Game: The Roy Game

-- MAIN APPLICATION
addappid(1373670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373671, 1, "ad4972c8b53715ae160dc547b6497ae21f590d02cc394864c08a4dc7f17cd852")

