-- Lua provided by RyzenAPI
-- Game: Classroom Aquatic Demo

-- MAIN APPLICATION
addappid(317560)

-- MAIN APP DEPOTS / PACKAGES
addappid(317561, 1, "4b9fe0d94dc770f1129fb246e195ecb8c7f37b9e7d65e67f3b2a5411a1c51cbc")
