-- Lua provided by SkyAPI 
-- Game: Classroom Aquatic Demo
addappid(317560)
addappid(317561, 1, "4b9fe0d94dc770f1129fb246e195ecb8c7f37b9e7d65e67f3b2a5411a1c51cbc")
