-- Lua provided by RyzenAPI
-- Game: Game: AMPLITUDE: A Visual Novel

-- MAIN APPLICATION
addappid(704680)
-- Game: addappid(704680)

-- MAIN APP DEPOTS / PACKAGES
addappid(704681, 1, "fba61bdff264f689476bb4b75ba7b26551641757d1dbbf377abe11abe4609051")
