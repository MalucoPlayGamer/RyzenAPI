-- Lua provided by RyzenAPI
-- Game: Adventurer Liz and the Erotic Dungeon

-- MAIN APPLICATION
addappid(1652220)
addappid(2260810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652221, 1, "f30885c22f648ef8af161d5a7520c5b750d327c3bdbc973d3da7fc26dcde702a")
