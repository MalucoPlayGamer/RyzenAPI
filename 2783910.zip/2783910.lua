-- Lua provided by RyzenAPI
-- Game: Hospital 666 Demo

-- MAIN APPLICATION
addappid(2783910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783911, 1, "3ae20acd06bf0219fd1ba6c8a3703af6f45ea3be0b8080dc2954250ddfbfd639")

