-- Lua provided by RyzenAPI
-- Game: Game: AppID 1284150

-- MAIN APPLICATION
addappid(1284150)
-- Game: addappid(1284150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284151, 1, "bfc47c470c9aea4543c12cd9d00a7fb5fdffeb9ca3e302bd1009a5333c488d22")
