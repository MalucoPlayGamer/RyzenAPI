-- Lua provided by RyzenAPI 
-- Game: Survival Machine Demo
addappid(3100460)
addappid(3100461, 1, "5d455ed314b58f60f4f1f687561d24949e1d0bbd73302a27186306f3b9de9c29")
