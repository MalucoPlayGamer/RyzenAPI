-- Lua provided by RyzenAPI
-- Game: European Mystery: Flowers of Death Collector's Edition

-- MAIN APPLICATION
addappid(805040)

-- MAIN APP DEPOTS / PACKAGES
addappid(805041,0,"6453cb39436471d88a2c8eeaf76bf8c9a35fb4ec9fbd986064bd61a52ef1ffa5")

