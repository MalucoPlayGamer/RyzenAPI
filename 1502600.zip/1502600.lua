-- Lua provided by SkyAPI 
-- Game: Alien X
addappid(1502600)
addappid(1502601, 1, "1aea4c007a13845eadb4cde83d26f179ea6e4c18c0bb05d8d92a16453077857d")
