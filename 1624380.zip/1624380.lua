-- Lua provided by RyzenAPI
-- Game: Horny Sekai

-- MAIN APPLICATION
addappid(1624380)
-- Game: addappid(1624380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624381, 1, "7947fd79d5fc9cb252f5435c750b714f7d865cb2dee07c6b447a3a9685e47c5d")
addappid(1624382, 1, "bf330fea34f3746f4b52e0f66d47f8874a429932ead7d41d489ca5660406909e")
addappid(1624383, 1, "fef6d40a81beae12604dc3a299e34a3ce763d697f7f2ea7bfc623fd37f0bfdf3")
addappid(1624384, 1, "2bdcc6d56aa4e66115e3bc5ae0b181641d03eac72ae7c04ec64d10649fa91531")
addappid(1729680, 0, "e82679bb60531f2c9f7a523ce4aa0b84be11db8c9deae56967b999365d2b5d1d")
