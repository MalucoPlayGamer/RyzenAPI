-- Lua provided by RyzenAPI
-- Game: Project Rogue

-- MAIN APPLICATION
addappid(2519470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2519471, 1, "51d96b6cacff23290f366d487f5ca030bfa301eb47efb4333e44f504dc4afbed")

