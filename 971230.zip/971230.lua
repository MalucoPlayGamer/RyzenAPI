-- Lua provided by RyzenAPI 
-- Game: Daedalic Complex
addappid(971230)
addappid(971231, 1, "6154541a1efdb3211bfffd0ac0d43ecfe1879deb61c767a1df3406c03867bcbe")
