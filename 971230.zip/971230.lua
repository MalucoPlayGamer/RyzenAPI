-- Lua provided by RyzenAPI
-- Game: 971230

-- MAIN APPLICATION
addappid(971230)
-- Game: addappid(971230)

-- MAIN APP DEPOTS / PACKAGES
addappid(971231, 1, "6154541a1efdb3211bfffd0ac0d43ecfe1879deb61c767a1df3406c03867bcbe")
