-- Lua provided by RyzenAPI
-- Game: EXS2 Support package-Plus

-- MAIN APPLICATION
addappid(2280760)
-- Game: addappid(2280760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280761, 1, "8b0481cecb6bcd5afa0a1ebe2d00332a69ce7c35e8d16968ebf506b13b3cb059")
