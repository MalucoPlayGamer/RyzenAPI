-- Lua provided by RyzenAPI
-- Game: The Nine Tailed Celestial Fox

-- MAIN APPLICATION
addappid(1987260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987261, 1, "cfa793a7c3fd5479a95d4ec4dafbf93522567425a2fdb7db334c8270748500e2")
