-- Lua provided by RyzenAPI
-- Game: Ambition of the SLIMES 2 Demo

-- MAIN APPLICATION
addappid(2174960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174961, 1, "d5e97a1929f7a4ae70ad0cec331ddce4613b961c4f9dd80beae3e8c536c9165f")
