-- Lua provided by SkyAPI 
-- Game: AppID 2174960
addappid(2174960)
addappid(2174961, 1, "d5e97a1929f7a4ae70ad0cec331ddce4613b961c4f9dd80beae3e8c536c9165f")
