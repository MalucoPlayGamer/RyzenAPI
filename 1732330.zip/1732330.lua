-- Lua provided by RyzenAPI
-- Game: Ys IX -Monstrum NOX-

-- MAIN APPLICATION
addappid(1732330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732331, 1, "24193ac2bad2747e22948a5f20a863077064cc603f414b81cc592822b62c7bf7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
