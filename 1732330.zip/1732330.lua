-- Lua provided by RyzenAPI 
-- Game: Ys IX -Monstrum NOX-
addappid(1732330)
addappid(1732331, 1, "24193ac2bad2747e22948a5f20a863077064cc603f414b81cc592822b62c7bf7")
