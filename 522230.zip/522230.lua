-- Lua provided by RyzenAPI
-- Game: addappid(522230)

-- MAIN APPLICATION
addappid(522230)

-- MAIN APP DEPOTS / PACKAGES
addappid(522232,0,"8252d066638aab40540b78f7c423412106f6b7c4a7c9aa2d31e930e0f2bcd89c")
