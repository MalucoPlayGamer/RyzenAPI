-- Lua provided by RyzenAPI
-- Game: Resistance Element

-- MAIN APPLICATION
addappid(1054600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1054601, 1, "a56034ea19c8cfecccaa6a07d001cc1ea5f91dbf1c0ebbd68f9b2e64a6dcecae")

