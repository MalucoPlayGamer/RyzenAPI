-- Lua provided by RyzenAPI
-- Game: 寄居隅怪奇事件簿 Hermitage Strange Case Files

-- MAIN APPLICATION
addappid(228990)
addappid(836640)
addappid(836641)
addappid(836642)
addappid(836643)
addappid(836647)
addappid(836648)

-- MAIN APP DEPOTS / PACKAGES
addappid(836644,0,"66a71c95fb9f067bac8f2fdc2f7f14d7d79d14afedf3715296edf037a4a0d61e")
addappid(836645,0,"79a6911022d6a3761b41bfe73f29914fc0e53b8eab35e43da9b8b88b8ae6bdd8")
addappid(836646,0,"d9568e1506395a7de386de0947436098dabf834145d65abb42e1ed35e1f895d8")
