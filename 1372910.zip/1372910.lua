-- Lua provided by RyzenAPI
-- Game: addappid(1372910)

-- MAIN APPLICATION
addappid(1372910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372911, 1, "b7a926c71b179ef0de6a28e0a891a3de824dc483ef9a4fbc41edfb984ff7fa2c")
addappid(1372912, 1, "8029acf59f4bc934ac30e5d2d05f9fdef5ccc8cc0e99628934f69cfe72a444ae")
