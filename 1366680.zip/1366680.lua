-- Lua provided by RyzenAPI
-- Game: San Diablos

-- MAIN APPLICATION
addappid(1366680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366681, 1, "33c9d2e30ff72eb40731f941d2998448cec4b694434d84961ce1d320d8f015a4")
