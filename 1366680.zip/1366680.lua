-- Lua provided by RyzenAPI
-- Game: San Diablos

-- MAIN APPLICATION
addappid(1366680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1366681, 1, "33c9d2e30ff72eb40731f941d2998448cec4b694434d84961ce1d320d8f015a4")

