-- Lua provided by RyzenAPI
-- Game: SONIC X SHADOW GENERATIONS: Extra Content Pack

-- MAIN APPLICATION
addappid(2909770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909770,0,"45c41ebbd5561b69146ab5f7ecc497f31ee3e82db476188d8af2ae31537ae58a")

