-- Lua provided by RyzenAPI
-- Game: AppID 2367560

-- MAIN APPLICATION
addappid(2367560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367561, 1, "68aa7576296a2be10e57b09ef6a592829c6cef5ed0cb862fa6f1f8470b219ddc")

