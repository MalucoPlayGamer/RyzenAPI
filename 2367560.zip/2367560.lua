-- Lua provided by RyzenAPI
-- Game: AppID 2367560

-- MAIN APPLICATION
addappid(2367560)
addappid(2442350)
addappid(2443930)
addappid(2447360)
addappid(2447361)
addappid(2447362)
addappid(2447363)
addappid(2581460)
addappid(2624780)
addappid(2624800)
addappid(2624810)
addappid(2624820)
addappid(2719050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2367561, 1, "68aa7576296a2be10e57b09ef6a592829c6cef5ed0cb862fa6f1f8470b219ddc")

