-- Lua provided by RyzenAPI
-- Game: 1234270

-- MAIN APPLICATION
addappid(1234270)
-- Game: addappid(1234270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234271, 1, "4b6bf217f9ed7c19e53df68ced0bdf47b9464df21f11005979c9e22b9c4699d8")
