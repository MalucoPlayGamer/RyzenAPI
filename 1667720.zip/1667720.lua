-- Lua provided by RyzenAPI
-- Game: 1667720

-- MAIN APPLICATION
addappid(1667720)
addappid(2238060)
-- Game: addappid(1667720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667721, 1, "3ec984e5d010951154f8e1c6f881d421a3e99c2bfc2a719b0da1ead414178cc7")
