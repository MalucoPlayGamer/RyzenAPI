-- Lua provided by RyzenAPI
-- Game: Game: 渡灵师-Demon Subduing Master

-- MAIN APPLICATION
addappid(2377990)
-- Game: addappid(2377990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377991, 1, "dd85a93845e86e92581c7dfd5a5fec1821fdb4c3901c5322fa98d58780b9a98e")
