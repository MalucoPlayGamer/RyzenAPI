-- Lua provided by RyzenAPI
-- Game: The Castles of Dr. Creep

-- MAIN APPLICATION
addappid(517930)

-- MAIN APP DEPOTS / PACKAGES
addappid(517931,0,"64a3b10762bb9754ae82af73db7cef51e7d482d4fd9812fa3add934dde284d0e")
addappid(517932,0,"c86bf891a6b9f802ba5aa89f25869f60f8e9f4da94230ee7375416ebdc4e906c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
