-- Lua provided by RyzenAPI
-- Game: Dungeon Arena

-- MAIN APPLICATION
addappid(1705540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705541, 1, "87eea2c7f361da91b40be9df43ad7b3808556d67158485a394cdd4803f0d0306")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1707910)
addappid(1707920)
addappid(1707921)
addappid(1707922)
addappid(1707930)
addappid(1707931)
addappid(1707932)
addappid(1707933)
