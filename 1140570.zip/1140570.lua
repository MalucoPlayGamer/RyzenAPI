-- Lua provided by RyzenAPI
-- Game: A Street Cat's Tale

-- MAIN APPLICATION
addappid(1140570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140571, 1, "afa18d6ba1ba5df0972b08a7a8854c2679ec54bf0a641abea448c6368f6e2e87")

