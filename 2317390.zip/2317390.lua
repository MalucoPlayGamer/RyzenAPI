-- Lua provided by RyzenAPI
-- Game: addappid(2317390)

-- MAIN APPLICATION
addappid(2317390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317391, 1, "5dfc31101d2a0d138d9d8823e469257dc23f45979e6cb2b6b628ce0ad041a1a9")
