-- Lua provided by RyzenAPI
-- Game: ToyLand

-- MAIN APPLICATION
addappid(2317390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317391, 1, "5dfc31101d2a0d138d9d8823e469257dc23f45979e6cb2b6b628ce0ad041a1a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
