-- Lua provided by RyzenAPI
-- Game: Cute Nurses - Artbook 18+

-- MAIN APPLICATION
addappid(1793870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793870,0,"4901c337cf05b07c0bc76cec635ec0e82ecf8eb9d4ba37fe8b65eb78bb61ed67")

