-- Lua provided by RyzenAPI
-- Game: Book of Shadows

-- MAIN APPLICATION
addappid(1442380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442381, 1, "2d2913f02cee86786f9a2171b275b3d40655235ed8587882d6af2153346e3bf5")
