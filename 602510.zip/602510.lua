-- Lua provided by RyzenAPI
-- Game: Gettysburg: The Tide Turns

-- MAIN APPLICATION
addappid(602510)

-- MAIN APP DEPOTS / PACKAGES
addappid(602511,0,"cd72bd8bd3c05f267c675d072e8c978b496322079f4277db59e3348184794031")

