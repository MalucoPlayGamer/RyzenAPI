-- Lua provided by RyzenAPI
-- Game: Game: Furry Orgasm

-- MAIN APPLICATION
addappid(2012540)
-- Game: addappid(2012540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012541, 1, "7b74866f401f86753ef2cf1c4779512b5158af3f001a26e6a44349175a670bf1")
