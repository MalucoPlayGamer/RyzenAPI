-- Lua provided by RyzenAPI
-- Game: Game: A Legionary's Life

-- MAIN APPLICATION
addappid(1058430)
-- Game: addappid(1058430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058431, 1, "a4639f18171710c06949989ca646ff020c0d98193d450a166543e6902f617712")
