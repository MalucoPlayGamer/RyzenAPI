-- Lua provided by RyzenAPI
-- Game: 3057410

-- MAIN APPLICATION
addappid(3057410)
-- Game: addappid(3057410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057411, 1, "1ea34118b8f46445e19bc0fab21225d96648db634ab6655ed4d47c6ac0879eb9")
