-- Lua provided by RyzenAPI 
-- Game: Sing Together: VR Karaoke
addappid(1781140)
addappid(1781141, 1, "5a1acbe1fb91e874944334e8c814f7485a0a8cededc01fb24eb13e5264b09550")
