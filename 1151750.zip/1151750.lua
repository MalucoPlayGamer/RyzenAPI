-- Lua provided by RyzenAPI
-- Game: Game: mmmmm donuts arhhh......

-- MAIN APPLICATION
addappid(1151750)
-- Game: addappid(1151750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151751, 1, "09a4117aa31c601fc6a3f23450984c0e0fe5c9b1f9c1b301757d2ffc55a2af6a")
