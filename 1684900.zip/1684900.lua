-- Lua provided by RyzenAPI
-- Game: AppID 1684900

-- MAIN APPLICATION
addappid(1684900)
-- Game: addappid(1684900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684901, 1, "34fefdbdbb34ed1b3763c3f9480c95070c885830b1eb6a1b55666c0533ed0cc7")
