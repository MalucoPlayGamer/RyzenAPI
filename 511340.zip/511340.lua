-- Lua provided by RyzenAPI
-- Game: 511340

-- MAIN APPLICATION
addappid(511340)
addappid(537190)
-- Game: addappid(511340)

-- MAIN APP DEPOTS / PACKAGES
addappid(511345,0,"c1f10f222c87011b395e0d19b961130baeadaaa1d633cc3902b71c71d5cdbbd9")
addtoken(511340,7430152587261191724)
