-- Lua provided by RyzenAPI 
-- Game: Gladiators: Survival in Rome
addappid(2295520)
addappid(2295521, 1, "fb2c8f6ff8e62f1ac26d86aa94da77f16e50acf09d5825ed97ff18e4400d1db0")
