-- Lua provided by RyzenAPI
-- Game: Game: Gladiators: Survival in Rome

-- MAIN APPLICATION
addappid(2295520)
-- Game: addappid(2295520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2295521, 1, "fb2c8f6ff8e62f1ac26d86aa94da77f16e50acf09d5825ed97ff18e4400d1db0")
