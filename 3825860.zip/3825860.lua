-- Lua provided by RyzenAPI
-- Game: Dominion Of The Forgotten

-- MAIN APPLICATION
addappid(3825860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3825861,0,"94c39412f81dc64af2c8a57b548fef4fa89dad6a70aa5c81fd1ce9fe1db82e90")

