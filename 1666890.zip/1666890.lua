-- Lua provided by RyzenAPI
-- Game: Puppet Play 🎬

-- MAIN APPLICATION
addappid(1666890)
-- Game: addappid(1666890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666891, 1, "ba7c9755b73d8191da3d57ee332621785190325593556f3b2c5588d9ce47928f")
