-- Lua provided by RyzenAPI
-- Game: 2924410

-- MAIN APPLICATION
addappid(2924410)
-- Game: addappid(2924410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924410,0,"f874d47604752cc8683b1f01d6c0af1ba2e70fe2f0b05bb24c9dda0f216f2f6e")
