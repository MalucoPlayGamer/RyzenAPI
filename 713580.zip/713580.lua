-- Lua provided by SkyAPI 
-- Game: AppID 713580
addappid(713580)
addappid(713581, 1, "b5bc481feab688fe81dac2b405e607257a7be7362cc657d70830d58b0e93a33f")
