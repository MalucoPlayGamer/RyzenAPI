-- Lua provided by RyzenAPI
-- Game: AppID 713580

-- MAIN APPLICATION
addappid(713580)
-- Game: addappid(713580)

-- MAIN APP DEPOTS / PACKAGES
addappid(713581, 1, "b5bc481feab688fe81dac2b405e607257a7be7362cc657d70830d58b0e93a33f")
