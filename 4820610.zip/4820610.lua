-- Lua provided by RyzenAPI
-- Game: Project Threshold

-- MAIN APPLICATION
addappid(4820610)

-- MAIN APP DEPOTS / PACKAGES
addappid(4820611,0,"2e44451cbd0b90454e5ccb5b994c631c09d6f3156197150f7540a6430c9eba66")

