-- Lua provided by RyzenAPI
-- Game: addappid(636740)

-- MAIN APPLICATION
addappid(636740)

-- MAIN APP DEPOTS / PACKAGES
addappid(636741, 1, "91912607a6bedbd20e33187a5f29af2e06a07a1ecbe894e9d3e93fe185a82d63")
