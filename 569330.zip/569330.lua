-- Lua provided by RyzenAPI
-- Game: Flight Simulator: VR

-- MAIN APPLICATION
addappid(569330)

-- MAIN APP DEPOTS / PACKAGES
addappid(569331, 1, "a4b6b42a36805129235897f327e627fb064c4bbe663718774dcaa728baafc3f8")

