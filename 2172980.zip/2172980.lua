-- Lua provided by RyzenAPI
-- Game: Fading Light VR: Antiworld

-- MAIN APPLICATION
addappid(2172980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172981, 1, "0350ede7fb28536783fec89be02b0c4a317e74df32f846c2e18df7c02b956b88")

