-- Lua provided by RyzenAPI
-- Game: AppID 770740

-- MAIN APPLICATION
addappid(770740)
-- Game: addappid(770740)

-- MAIN APP DEPOTS / PACKAGES
addappid(770741, 1, "ae0149fe592ce603353592e2f88b34f1473fcfa97e93f59b1ff6c4013080e326")
