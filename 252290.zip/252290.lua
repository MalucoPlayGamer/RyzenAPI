-- Lua provided by RyzenAPI
-- Game: Game: Elegy for a Dead World

-- MAIN APPLICATION
addappid(252290)
-- Game: addappid(252290)

-- MAIN APP DEPOTS / PACKAGES
addappid(252291, 1, "e8cc8733d285738ef025175c02b8b09a54e2a38560fe44cb7a7e9a86547d9056")
addappid(252292, 1, "df8d380d0b1fa9e5fed4e85aaf8df154941250c8160a4ac9e5b4e5c9c1a89307")
addappid(252293, 1, "118f4afd779c838f4166cdbd7b5976fb544238b04d08a675102c6813d42cbd3a")
