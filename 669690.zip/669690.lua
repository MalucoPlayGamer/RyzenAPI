-- Lua provided by RyzenAPI
-- Game: setManifestid(669692,"2075897269490430835")

-- MAIN APPLICATION
addappid(669690)

-- MAIN APP DEPOTS / PACKAGES
addappid(669692,0,"6cae3e1f4dcc02e301896e87902d2ffc7fe0464baa766af8e56a699f4f444e3e")

