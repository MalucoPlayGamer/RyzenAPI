-- Lua provided by RyzenAPI
-- Game: Game: The Die Is Cast Demo

-- MAIN APPLICATION
addappid(3250840)
-- Game: addappid(3250840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3250841, 1, "ba5ddbefcae42a8371391ae7c678c9a803c1740879c33d9a4ad9b522818bdce4")
