-- Lua provided by RyzenAPI 
-- Game: Little Inner Monsters - Card Game
addappid(1813190)
addappid(1813191, 1, "f1a3ac1e867ce7fa8b19ff832fdc0f7f62748c0289523ebdfdea95f60575c95f")
