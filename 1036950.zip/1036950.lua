-- 1036950's Lua and Manifest Created by Hubcap Manifest
-- Super Jigsaw Puzzle: Generations
-- Created: July 30, 2026 at 16:29:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 49
-- Total DLCs: 48 (142 excluded)

-- MAIN APPLICATION
addappid(1036950, 1, "5780b7d04bcc5d5565ea44d00e4cdfa147361d27ada60f54baf114844a308ec5") -- Super Jigsaw Puzzle: Generations
-- MAIN APP DEPOTS
addappid(1036951, 1, "420685f06ea1e75534e03251131cece961352d7def59b4a4ea277091d22dfed2") -- Super Jigsaw Puzzle: Generations Content
setManifestid(1036951, "5233294672769733442", 3648759045)
-- DLCS WITH DEDICATED DEPOTS
-- Super Jigsaw Puzzle Generations - Original SJP Puzzles (AppID: 1051520)
addappid(1051520)
addappid(1051520, 1, "54a1aacef02c75a9ea7a6f297899a4917f0b920fceba9b98b7eeb358b800d15c") -- Super Jigsaw Puzzle Generations - Original SJP Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Original SJP Puzzles (1051520)
setManifestid(1051520, "6123882604827204944", 409468037)
-- Super Jigsaw Puzzle Generations - SJP Cities Puzzles (AppID: 1056620)
addappid(1056620)
addappid(1056620, 1, "1893eb85fa4e7d3647161c659301b90f460d38dda25470566bd3e3a89d3a3212") -- Super Jigsaw Puzzle Generations - SJP Cities Puzzles - Repositorio Super Jigsaw Puzzle: Generations - SJP Cities Puzzles (1056620)
setManifestid(1056620, "2636597861281064898", 397697137)
-- Super Jigsaw Puzzle Generations - SJP Monuments Puzzles (AppID: 1056621)
addappid(1056621)
addappid(1056621, 1, "94b26e46282cf029bf5b976bd4d3e6b4814d247af6d39fdc1e2301c722c2efad") -- Super Jigsaw Puzzle Generations - SJP Monuments Puzzles - Repositorio Super Jigsaw Puzzle: Generations - SJP Monuments Puzzles (1056621)
setManifestid(1056621, "7213101172393321328", 403020111)
-- Super Jigsaw Puzzle Generations - SJP Space Puzzles (AppID: 1056622)
addappid(1056622)
addappid(1056622, 1, "9ddb2c04f1f7da8b648f5701fde202ed2e1bd04ca5405010a7d8180be60a1ced") -- Super Jigsaw Puzzle Generations - SJP Space Puzzles - Repositorio Super Jigsaw Puzzle: Generations - SJP Space Puzzles (1056622)
setManifestid(1056622, "5577534861345572817", 350072726)
-- Super Jigsaw Puzzle Generations - SJP Anime Reloaded Puzzles (AppID: 1056623)
addappid(1056623)
addappid(1056623, 1, "8308bd6d0f762095b771e51ee8d6832ba667edbe053d3a4ea56360f45f94cba5") -- Super Jigsaw Puzzle Generations - SJP Anime Reloaded Puzzles - Repositorio Super Jigsaw Puzzle: Generations - SJP Anime Reloaded Puzzles (1056623)
setManifestid(1056623, "1432007996172415181", 356130808)
-- Super Jigsaw Puzzle Generations - Beaches Puzzles (AppID: 1056628)
addappid(1056628)
addappid(1056628, 1, "92e9d6b195193360e779d2c6c50d3105dc93fe8911d244192f67d0825ebb27f8") -- Super Jigsaw Puzzle Generations - Beaches Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Beaches Puzzles (1056628)
setManifestid(1056628, "8954339041353817205", 190841880)
-- Super Jigsaw Puzzle Generations - Sealife Puzzles (AppID: 1056630)
addappid(1056630)
addappid(1056630, 1, "3286aa31126b560ee62b5aa7d20b2776ac6df6da1524c99dc908e7ae5ebef0ca") -- Super Jigsaw Puzzle Generations - Sealife Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Sealife Puzzles (1056630)
setManifestid(1056630, "3971340505876522771", 115470814)
-- Super Jigsaw Puzzle Generations - Abandoned Places Puzzles (AppID: 1073681)
addappid(1073681)
addappid(1073681, 1, "99143f7de08d3c849a035ed13601edc6bb8bbddb9e75b2b27e4dd1138e64cf6c") -- Super Jigsaw Puzzle Generations - Abandoned Places Puzzles - Repositorio Super Jigsaw Puzzle Generations - Abandoned Places Puzzles (1073681)
setManifestid(1073681, "4923639990608823593", 116765395)
-- Super Jigsaw Puzzle Generations - Motorbikes Puzzles (AppID: 1076091)
addappid(1076091)
addappid(1076091, 1, "673c6bf64bf51cafc8f560cd225e295a674676fb7efd09bbee0db13aecdc448f") -- Super Jigsaw Puzzle Generations - Motorbikes Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Motorbikes Puzzles (1076091)
setManifestid(1076091, "5161191317602393946", 165800015)
-- Super Jigsaw Puzzle Generations - Sunsets (AppID: 1076170)
addappid(1076170)
addappid(1076170, 1, "906803dcec804bfb95f57510c1d82b327827ce023763327dfe5f67a8108faeb7") -- Super Jigsaw Puzzle Generations - Sunsets - Repositorio Super Jigsaw Puzzle: Generations - Sunsets (1076170)
setManifestid(1076170, "3851758063407827927", 207801956)
-- Super Jigsaw Puzzle Generations - Random Puzzles (AppID: 1076761)
addappid(1076761)
addappid(1076761, 1, "4c51219ab99469c4c1185aa3cbbaf6623d3caa06b811ac33b6e1f6e7ad4d1448") -- Super Jigsaw Puzzle Generations - Random Puzzles - Repositorio Super Jigsaw  Puzzle: Generations - Random Puzzles (1076761)
setManifestid(1076761, "8142781627572329010", 356608069)
-- Super Jigsaw Puzzle Generations - Autumn Puzzles (AppID: 1080031)
addappid(1080031)
addappid(1080031, 1, "ad10b234d011d02fd59b29c8646bd35f04f463e5478ab932084a9dcce4c396c2") -- Super Jigsaw Puzzle Generations - Autumn Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Autumn Puzzles (1080031)
setManifestid(1080031, "8115742779281477554", 211968021)
-- Super Jigsaw Puzzle Generations - Halloween Puzzles (AppID: 1080591)
addappid(1080591)
addappid(1080591, 1, "de4322471b8a73594a1ce897d7aca1abcf207577082d324f0e78406de3b515b2") -- Super Jigsaw Puzzle Generations - Halloween Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Halloween Puzzles (1080591)
setManifestid(1080591, "3659496308199586413", 127769568)
-- Super Jigsaw Puzzle Generations - Mexico Puzzles (AppID: 1082030)
addappid(1082030)
addappid(1082030, 1, "3ba000b388d8b7fd68dd8eacce763fbcfe9aeffe6f67d635b0a03d31bae30925") -- Super Jigsaw Puzzle Generations - Mexico Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Mexico Puzzles (1082030)
setManifestid(1082030, "4436501216036929892", 194330357)
-- Super Jigsaw Puzzle Generations - Winter Puzzles (AppID: 1082031)
addappid(1082031)
addappid(1082031, 1, "f315b7f189cdd19ddfd0377703b390b4c3cbef5678b8e1ebe0d6ef406abba293") -- Super Jigsaw Puzzle Generations - Winter Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Winter Puzzles (1082031)
setManifestid(1082031, "6892924990442377116", 311772513)
-- Super Jigsaw Puzzle Generations - Random Puzzles 2 (AppID: 1204090)
addappid(1204090)
addappid(1204090, 1, "0b978a2a0bb75a7738c9024c7382147ac059575367cf5f9d43cd846313a54e2f") -- Super Jigsaw Puzzle Generations - Random Puzzles 2 - Repositorio Super Jigsaw Puzzle: Generations - Random Puzzles 2 (1204090)
setManifestid(1204090, "7977122631726264403", 351473544)
-- Super Jigsaw Puzzle Generations - Landscapes Puzzles (AppID: 1205310)
addappid(1205310)
addappid(1205310, 1, "9b3e01c43e0073d8c5d46245818de8928b29a03ecfdac900a60bb1a0eb44a1ca") -- Super Jigsaw Puzzle Generations - Landscapes Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Landscapes Puzzles (1205310)
setManifestid(1205310, "6969851152114972090", 279304378)
-- Super Jigsaw Puzzle Generations - China Puzzles (AppID: 1213490)
addappid(1213490)
addappid(1213490, 1, "7b0c67a1a07e50d03bd0d4412237709221a4456a7b4846cde76e33af21ce0b39") -- Super Jigsaw Puzzle Generations - China Puzzles - Repositorio Super Jigsaw Puzzle: Generations - China Puzzles (1213490)
setManifestid(1213490, "9089316678414178386", 208939603)
-- Super Jigsaw Puzzle Generations - Bugs Puzzles (AppID: 1213560)
addappid(1213560)
addappid(1213560, 1, "1aacc4e9712ce2c5679cd1adb86915d1f2641ddf2f44f68d12ded08c9ea438a5") -- Super Jigsaw Puzzle Generations - Bugs Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Bugs Puzzles (1213560)
setManifestid(1213560, "2107273532766549116", 252273361)
-- Super Jigsaw Puzzle Generations - Spain Puzzles (AppID: 1238210)
addappid(1238210)
addappid(1238210, 1, "b575ae014ab85a11a64989b96953cfdacaa02caf379d470ef6d9daba62fdc77a") -- Super Jigsaw Puzzle Generations - Spain Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Spain Puzzles (1238210)
setManifestid(1238210, "5081678207859224957", 183281801)
-- Super Jigsaw Puzzle Generations - Castles Puzzles (AppID: 1241490)
addappid(1241490)
addappid(1241490, 1, "a3fbb104e9ca4858650da11c7b3f9a218195c813ebd5adbf05ead9e3746e168a") -- Super Jigsaw Puzzle Generations - Castles Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Castles Puzzles (1241490)
setManifestid(1241490, "4963866778823070945", 103097703)
-- Super Jigsaw Puzzle Generations - Boats Puzzles (AppID: 1243680)
addappid(1243680)
addappid(1243680, 1, "d57514302ca39700eb04011684c2c2ff10cf93ece28804ffed1ab0e7313c0bff") -- Super Jigsaw Puzzle Generations - Boats Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Boats Puzzles (1243680)
setManifestid(1243680, "5721809316636702850", 195617503)
-- Super Jigsaw Puzzle Generations - Brazil Puzzles (AppID: 1246180)
addappid(1246180)
addappid(1246180, 1, "bf0d764761d1468feb6c20dd711618105e5ebcd985a4bdadcb7aa1334b383789") -- Super Jigsaw Puzzle Generations - Brazil Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Brazil Puzzles (1246180)
setManifestid(1246180, "1755941917521372560", 136122285)
-- Super Jigsaw Puzzle Generations - France Puzzles (AppID: 1246182)
addappid(1246182)
addappid(1246182, 1, "d535e918917fbe5b0da91602a13484421352df1e77095b6647443469d6364248") -- Super Jigsaw Puzzle Generations - France Puzzles - Repositorio Super Jigsaw Puzzle: Generations - France Puzzles (1246182)
setManifestid(1246182, "8295985413485445577", 196124848)
-- Super Jigsaw Puzzle Generations - Paintings Puzzles (AppID: 1246183)
addappid(1246183)
addappid(1246183, 1, "4d3f8ed3d9f13208a815a58630659b0ceca415c17fb22600e696d8a23d2cdfb1") -- Super Jigsaw Puzzle Generations - Paintings Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Paintings Puzzles (1246183)
setManifestid(1246183, "550828345251169607", 210590951)
-- Super Jigsaw Puzzle Generations - Russia Puzzles (AppID: 1246192)
addappid(1246192)
addappid(1246192, 1, "cb810aa85ef72069046a5bd62ae88d4a876dd95fbbbb7884a42c8bdc4080ecfb") -- Super Jigsaw Puzzle Generations - Russia Puzzles - Repositorio Super Jigsaw Puzzle: Generations - Russia Puzzles (1246192)
setManifestid(1246192, "9196969682909473977", 177427346)
-- Super Jigsaw Puzzle Generations - First Anniversary (AppID: 1261310)
addappid(1261310)
addappid(1261310, 1, "4f4b37d4f2f72641ca338830da41900f8e70f483a5412457eb1f1b426ab2b1b7") -- Super Jigsaw Puzzle Generations - First Anniversary - Repositorio Super Jigsaw Puzzle: Generations - First Anniversary (1261310)
setManifestid(1261310, "1069952873513542281", 78743028)
-- Super Jigsaw Puzzle Generations - Summer 2020 (AppID: 1413750)
addappid(1413750)
addappid(1413750, 1, "3c97621fcc3b4757176e6af2fa8e23f3d7d0f19cb9889a3bafd556e0d224f007") -- Super Jigsaw Puzzle Generations - Summer 2020 - Repositorio Super Jigsaw Puzzle: Generations - Summer 2020 (1413750)
setManifestid(1413750, "6218753876684265925", 58974142)
-- Super Jigsaw Puzzle Generations - Autumn 2020 (AppID: 1451400)
addappid(1451400)
addappid(1451400, 1, "3ec7e0f7b5656f4e329690107fbd6f197fb57df1da08b05976e872eb480e5490") -- Super Jigsaw Puzzle Generations - Autumn 2020 - Repositorio Super Jigsaw Puzzle: Generations - Autumn 2020 (1451400)
setManifestid(1451400, "2131585969279959217", 59210309)
-- Super Jigsaw Puzzle Generations - Anime Puzzles 2 (AppID: 1454860)
addappid(1454860)
addappid(1454860, 1, "6c47f3b09ac600aa986aedb3905b41161335b7e1136066e5f91ceea8f6c68b8f") -- Super Jigsaw Puzzle Generations - Anime Puzzles 2 - Repositorio Super Jigsaw Puzzle: Generations - Anime Puzzles 2 (1454860)
setManifestid(1454860, "8667973064304724550", 308079972)
-- Super Jigsaw Puzzle Generations - Abandoned Places 2 (AppID: 1501460)
addappid(1501460)
addappid(1501460, 1, "58b30c1a537fa861c609a3400ab0323e26e5a93d99c932b238dc9279385d1056") -- Super Jigsaw Puzzle Generations - Abandoned Places 2 - Repositorio Super Jigsaw Puzzle: Generations - Abandoned Places 2 (1501460)
setManifestid(1501460, "9142629288987637609", 150306940)
-- Super Jigsaw Puzzle Generations - Second Anniversary (AppID: 1542310)
addappid(1542310)
addappid(1542310, 1, "94daa8abe04b9b344a3a40c6b7737383cc73079f6b71748f710426f79e2ca494") -- Super Jigsaw Puzzle Generations - Second Anniversary - Repositorio Super Jigsaw Puzzle: Generations - Second Anniversary (1542310)
setManifestid(1542310, "5809221439339683692", 69265353)
-- Super Jigsaw Puzzle Generations - New Zealand (AppID: 1592960)
addappid(1592960)
addappid(1592960, 1, "6c8fabc4391d78886f57b21525a08fb5819bd27617e594ee960f0a400c168331") -- Super Jigsaw Puzzle Generations - New Zealand - Repositorio Super Jigsaw Puzzle: Generations - New Zealand (1592960)
setManifestid(1592960, "674904146577942873", 242625515)
-- Super Jigsaw Puzzle Generations - Anime Puzzles 3 (AppID: 1620780)
addappid(1620780)
addappid(1620780, 1, "c62efa9967b3e291fc5bb474958e85126dad8b70ae844cef055258848b938f0f") -- Super Jigsaw Puzzle Generations - Anime Puzzles 3 - Repositorio Super Jigsaw Puzzle: Generations - Anime Puzzles 3 (1620780)
setManifestid(1620780, "7244155971690482603", 315095687)
-- Super Jigsaw Puzzle Generations - Beaches 2 (AppID: 1629020)
addappid(1629020)
addappid(1629020, 1, "b6d0f21ba862911fe04609044ca7a2a18aeeca78733e904805043c3cd7506558") -- Super Jigsaw Puzzle Generations - Beaches 2 - Repositorio Super Jigsaw Puzzle: Generations - Beaches 2 (1629020)
setManifestid(1629020, "1060484694723717297", 370104681)
-- Super Jigsaw Puzzle Generations - Switzerland (AppID: 1674910)
addappid(1674910)
addappid(1674910, 1, "bec3b7c0da910742e740d7c79e917ddd0a110726ba1815d3fcd33c748b789c11") -- Super Jigsaw Puzzle Generations - Switzerland - Repositorio Super Jigsaw Puzzle: Generations - Switzerland (1674910)
setManifestid(1674910, "8425996034531404530", 299473419)
-- Super Jigsaw Puzzle Generations - Winter 2021 (AppID: 1737632)
addappid(1737632)
addappid(1737632, 1, "1e6578b94124d568e613d6558927cebee8d7bbde00e49d76c49f31906128980c") -- Super Jigsaw Puzzle Generations - Winter 2021 - Repositorio Super Jigsaw Puzzle: Generations - Winter 2021 (1737632)
setManifestid(1737632, "3509765035745583652", 210834814)
-- Super Jigsaw Puzzle Generations - Waves (AppID: 1840600)
addappid(1840600)
addappid(1840600, 1, "4afce520eb2a4e6085b65b3af9c51b4d1a2c8974b950cef0c12415eaa1db61d8") -- Super Jigsaw Puzzle Generations - Waves - Depot 1840600
setManifestid(1840600, "7220384675526461146", 234750684)
-- Super Jigsaw Puzzle Generations - Greece (AppID: 1907500)
addappid(1907500)
addappid(1907500, 1, "cac08f837d74528f1d361e6cd516488130994380ccd5f46611733a80d5ce15a7") -- Super Jigsaw Puzzle Generations - Greece - Depot 1907500
setManifestid(1907500, "6666683771922619436", 334760814)
-- Super Jigsaw Puzzle Generations - Technology (AppID: 1907501)
addappid(1907501)
addappid(1907501, 1, "5b2bd26575704157588fd1cccb150a2e4ed11441cf2741329aeb472dae04f4b4") -- Super Jigsaw Puzzle Generations - Technology - Depot 1907501
setManifestid(1907501, "1476187639799805203", 232719497)
-- Super Jigsaw Puzzle Generations - Big Cats 2 (AppID: 1939080)
addappid(1939080)
addappid(1939080, 1, "7cb27fb2427a9f266c75e74c26f10b1a767e96f13394a0b27f95a496ac662598") -- Super Jigsaw Puzzle Generations - Big Cats 2 - Depot 1939080
setManifestid(1939080, "5030305846153802843", 303031541)
-- Super Jigsaw Puzzle Generations - Kenya (AppID: 1939082)
addappid(1939082)
addappid(1939082, 1, "60e01ab4067fc1e1716c69dceae29cbfc18b38931b70e0805edd8173aaae7955") -- Super Jigsaw Puzzle Generations - Kenya - Depot 1939082
setManifestid(1939082, "8195323926293669895", 198281744)
-- Super Jigsaw Puzzle Generations - Anime 4 (AppID: 2089811)
addappid(2089811)
addappid(2089811, 1, "38cd76a66d79c90ed90c4a8ab66c2c2de2288fd1d31a4b593a35ceb343ce4535") -- Super Jigsaw Puzzle Generations - Anime 4 - Depot 2089811
setManifestid(2089811, "1340170698712109610", 305879139)
-- Super Jigsaw Puzzle Generations - Cities 2 (AppID: 2234581)
addappid(2234581)
addappid(2234581, 1, "ae37b8562ea7696849d81da96057a9b65589b41c3c6e87f097fa59159a8d3a9b") -- Super Jigsaw Puzzle Generations - Cities 2 - Depot 2234581
setManifestid(2234581, "5289122184195276930", 394466873)
-- Super Jigsaw Puzzle Generations - Malaysia (AppID: 2400090)
addappid(2400090)
addappid(2400090, 1, "14540803ebc9518296487a65e0961deca34c6d784f1025f2282296db80ddeced") -- Super Jigsaw Puzzle Generations - Malaysia - Depot 2400090
setManifestid(2400090, "8611125384055022316", 248648497)
-- Super Jigsaw Puzzle Generations - Portugal (AppID: 2601460)
addappid(2601460)
addappid(2601460, 1, "76fb20d1c9128ab0899eb34ed12cdec06c4f15f75f126309047190e5ed7dda80") -- Super Jigsaw Puzzle Generations - Portugal - Depot 2601460
setManifestid(2601460, "301628412898616499", 403636818)
-- Super Jigsaw Puzzle Generations - Landscapes 4 (AppID: 2601480)
addappid(2601480)
addappid(2601480, 1, "7adaafc31eeebf814e255a9e708004ab7d08181771bb1f5aeffe0ff9dd3b9241") -- Super Jigsaw Puzzle Generations - Landscapes 4 - Depot 2601480
setManifestid(2601480, "7151058769710814067", 439225844)
-- Super Jigsaw Puzzle Generations - Winter 2023 (AppID: 2601490)
addappid(2601490)
addappid(2601490, 1, "1e1678741bbbc89c7a352e60afc56c391e041d241768609db7d2d92b108cf7f9") -- Super Jigsaw Puzzle Generations - Winter 2023 - Depot 2601490
setManifestid(2601490, "2142456663518973724", 405022119)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Super Jigsaw Puzzle Generations - Kittens Puzzles (AppID: 1056624) - missing depot keys
-- addappid(1056624)
-- Super Jigsaw Puzzle Generations - Puppies Puzzles (AppID: 1056625) - missing depot keys
-- addappid(1056625)
-- Super Jigsaw Puzzle Generations - Big Cats Puzzles (AppID: 1056626) - missing depot keys
-- addappid(1056626)
-- Super Jigsaw Puzzle Generations - Waterfalls Puzzles (AppID: 1056627) - missing depot keys
-- addappid(1056627)
-- Super Jigsaw Puzzle Generations - Trains Puzzles (AppID: 1056629) - missing depot keys
-- addappid(1056629)
-- Super Jigsaw Puzzle Generations - Spring Puzzles (AppID: 1073680) - missing depot keys
-- addappid(1073680)
-- Super Jigsaw Puzzle Generations - Birds Puzzles (AppID: 1076090) - missing depot keys
-- addappid(1076090)
-- Super Jigsaw Puzzle Generations - USA Puzzles (AppID: 1076092) - missing depot keys
-- addappid(1076092)
-- Super Jigsaw Puzzle Generations - Fruits Puzzles (AppID: 1076760) - missing depot keys
-- addappid(1076760)
-- Super Jigsaw Puzzle Generations - Italy Puzzles (AppID: 1080030) - missing depot keys
-- addappid(1080030)
-- Super Jigsaw Puzzle Generations - Bears Puzzles (AppID: 1080032) - missing depot keys
-- addappid(1080032)
-- Super Jigsaw Puzzle Generations - Airplanes Puzzles (AppID: 1080590) - missing depot keys
-- addappid(1080590)
-- Super Jigsaw Puzzle Generations - Cats Puzzles (AppID: 1082020) - missing depot keys
-- addappid(1082020)
-- Super Jigsaw Puzzle Generations - Christmas Puzzles (AppID: 1082032) - missing depot keys
-- addappid(1082032)
-- Super Jigsaw Puzzle Generations - Cars Puzzles (AppID: 1213491) - missing depot keys
-- addappid(1213491)
-- Super Jigsaw Puzzle Generations - Sweets Puzzles (AppID: 1234150) - missing depot keys
-- addappid(1234150)
-- Super Jigsaw Puzzle Generations - Dogs Puzzles (AppID: 1243681) - missing depot keys
-- addappid(1243681)
-- Super Jigsaw Puzzle Generations - Flowers Puzzles (AppID: 1243682) - missing depot keys
-- addappid(1243682)
-- Super Jigsaw Puzzle Generations - Australia Puzzles (AppID: 1244700) - missing depot keys
-- addappid(1244700)
-- Super Jigsaw Puzzle Generations - Sports Puzzles (AppID: 1244701) - missing depot keys
-- addappid(1244701)
-- Super Jigsaw Puzzle Generations - Streets Puzzles (AppID: 1246181) - missing depot keys
-- addappid(1246181)
-- Super Jigsaw Puzzle Generations - Snakes Puzzles (AppID: 1246184) - missing depot keys
-- addappid(1246184)
-- Super Jigsaw Puzzle Generations - Japan Puzzles (AppID: 1246185) - missing depot keys
-- addappid(1246185)
-- Super Jigsaw Puzzle Generations - Random Animals Puzzles (AppID: 1246186) - missing depot keys
-- addappid(1246186)
-- Super Jigsaw Puzzle Generations - Germany Puzzles (AppID: 1246187) - missing depot keys
-- addappid(1246187)
-- Super Jigsaw Puzzle Generations - Horses Puzzles (AppID: 1246188) - missing depot keys
-- addappid(1246188)
-- Super Jigsaw Puzzle Generations - New York Puzzles (AppID: 1246189) - missing depot keys
-- addappid(1246189)
-- Super Jigsaw Puzzle Generations - Monkeys  Apes Puzzles (AppID: 1246190) - missing depot keys
-- addappid(1246190)
-- Super Jigsaw Puzzle Generations - Bikes Puzzles (AppID: 1246191) - missing depot keys
-- addappid(1246191)
-- Super Jigsaw Puzzle Generations - United Kingdom (AppID: 1501700) - missing depot keys
-- addappid(1501700)
-- Super Jigsaw Puzzle Generations - Reptiles (AppID: 1502320) - missing depot keys
-- addappid(1502320)
-- Super Jigsaw Puzzle Generations - Fantasy (AppID: 1542230) - missing depot keys
-- addappid(1542230)
-- Super Jigsaw Puzzle Generations - Iceland (AppID: 1542570) - missing depot keys
-- addappid(1542570)
-- Super Jigsaw Puzzle Generations - Rodents (AppID: 1542571) - missing depot keys
-- addappid(1542571)
-- Super Jigsaw Puzzle Generations - Vegetables (AppID: 1543350) - missing depot keys
-- addappid(1543350)
-- Super Jigsaw Puzzle Generations - Random Puzzles 3 (AppID: 1543600) - missing depot keys
-- addappid(1543600)
-- Super Jigsaw Puzzle Generations - Colorful (AppID: 1592250) - missing depot keys
-- addappid(1592250)
-- Super Jigsaw Puzzle Generations - Baby Animals (AppID: 1625320) - missing depot keys
-- addappid(1625320)
-- Super Jigsaw Puzzle Generations - Mushrooms (AppID: 1674911) - missing depot keys
-- addappid(1674911)
-- Super Jigsaw Puzzle Generations - Autumn 2021 (AppID: 1700820) - missing depot keys
-- addappid(1700820)
-- Super Jigsaw Puzzle Generations - Kittens 2 (AppID: 1700821) - missing depot keys
-- addappid(1700821)
-- Super Jigsaw Puzzle Generations - Canada (AppID: 1737630) - missing depot keys
-- addappid(1737630)
-- Super Jigsaw Puzzle Generations - Street Art (AppID: 1737631) - missing depot keys
-- addappid(1737631)
-- Super Jigsaw Puzzle Generations - Clocks (AppID: 1781410) - missing depot keys
-- addappid(1781410)
-- Super Jigsaw Puzzle Generations - Norway (AppID: 1804660) - missing depot keys
-- addappid(1804660)
-- Super Jigsaw Puzzle Generations - Puppies 2 (AppID: 1817090) - missing depot keys
-- addappid(1817090)
-- Super Jigsaw Puzzle Generations - Imagination (AppID: 1840601) - missing depot keys
-- addappid(1840601)
-- Super Jigsaw Puzzle Generations - Random Puzzles 4 (AppID: 1840602) - missing depot keys
-- addappid(1840602)
-- Super Jigsaw Puzzle Generations - Love (AppID: 1887300) - missing depot keys
-- addappid(1887300)
-- Super Jigsaw Puzzle Generations - Butterflies (AppID: 1939081) - missing depot keys
-- addappid(1939081)
-- Super Jigsaw Puzzle Generations - Trains 2 (AppID: 1939090) - missing depot keys
-- addappid(1939090)
-- Super Jigsaw Puzzle Generations - Bridges (AppID: 2023090) - missing depot keys
-- addappid(2023090)
-- Super Jigsaw Puzzle Generations - Ice Creams (AppID: 2023091) - missing depot keys
-- addappid(2023091)
-- Super Jigsaw Puzzle Generations - Paris (AppID: 2023092) - missing depot keys
-- addappid(2023092)
-- Super Jigsaw Puzzle Generations - Random Animals 2 (AppID: 2089810) - missing depot keys
-- addappid(2089810)
-- Super Jigsaw Puzzle Generations - Furniture (AppID: 2089812) - missing depot keys
-- addappid(2089812)
-- Super Jigsaw Puzzle Generations - Chile (AppID: 2097000) - missing depot keys
-- addappid(2097000)
-- Super Jigsaw Puzzle Generations - Landscapes 2 (AppID: 2098300) - missing depot keys
-- addappid(2098300)
-- Super Jigsaw Puzzle Generations - Food (AppID: 2102380) - missing depot keys
-- addappid(2102380)
-- Super Jigsaw Puzzle Generations - Jellyfishes (AppID: 2102381) - missing depot keys
-- addappid(2102381)
-- Super Jigsaw Puzzle Generations - India (AppID: 2212540) - missing depot keys
-- addappid(2212540)
-- Super Jigsaw Puzzle Generations - Winter 2022 (AppID: 2212541) - missing depot keys
-- addappid(2212541)
-- Super Jigsaw Puzzle Generations - Paintings 2 (AppID: 2212542) - missing depot keys
-- addappid(2212542)
-- Super Jigsaw Puzzle Generations - Random 5 (AppID: 2234580) - missing depot keys
-- addappid(2234580)
-- Super Jigsaw Puzzle Generations - Finland (AppID: 2234582) - missing depot keys
-- addappid(2234582)
-- Super Jigsaw Puzzle Generations - Fantasy 2 (AppID: 2234583) - missing depot keys
-- addappid(2234583)
-- Super Jigsaw Puzzle Generations - Illustrations (AppID: 2234584) - missing depot keys
-- addappid(2234584)
-- Super Jigsaw Puzzle Generations - Sci-Fi (AppID: 2234585) - missing depot keys
-- addappid(2234585)
-- Super Jigsaw Puzzle Generations - Random Animals 3 (AppID: 2234586) - missing depot keys
-- addappid(2234586)
-- Super Jigsaw Puzzle Generations - Toys (AppID: 2234587) - missing depot keys
-- addappid(2234587)
-- Super Jigsaw Puzzle Generations - Colorful 2 (AppID: 2400091) - missing depot keys
-- addappid(2400091)
-- Super Jigsaw Puzzle Generations - Drones (AppID: 2400092) - missing depot keys
-- addappid(2400092)
-- Super Jigsaw Puzzle Generations - Desert (AppID: 2400093) - missing depot keys
-- addappid(2400093)
-- Super Jigsaw Puzzle Generations - Landscapes 3 (AppID: 2457070) - missing depot keys
-- addappid(2457070)
-- Super Jigsaw Puzzle Generations - Egypt (AppID: 2457071) - missing depot keys
-- addappid(2457071)
-- Super Jigsaw Puzzle Generations - Street Art 2 (AppID: 2457072) - missing depot keys
-- addappid(2457072)
-- Super Jigsaw Puzzle Generations - Tools (AppID: 2457073) - missing depot keys
-- addappid(2457073)
-- Super Jigsaw Puzzle Generations - Amusements (AppID: 2457074) - missing depot keys
-- addappid(2457074)
-- Super Jigsaw Puzzle Generations - Baby Animals 2 (AppID: 2457075) - missing depot keys
-- addappid(2457075)
-- Super Jigsaw Puzzle Generations - Random 6 (AppID: 2601470) - missing depot keys
-- addappid(2601470)
-- Super Jigsaw Puzzle Generations - Colorful 3 (AppID: 2601500) - missing depot keys
-- addappid(2601500)
-- Super Jigsaw Puzzle Generations - Peru (AppID: 2681430) - missing depot keys
-- addappid(2681430)
-- Super Jigsaw Puzzle Generations - Anime 5 (AppID: 2681440) - missing depot keys
-- addappid(2681440)
-- Super Jigsaw Puzzle Generations - Waterfalls 2 (AppID: 2681450) - missing depot keys
-- addappid(2681450)
-- Super Jigsaw Puzzle Generations - Cats 2 (AppID: 2681460) - missing depot keys
-- addappid(2681460)
-- Super Jigsaw Puzzle Generations - Dogs 2 (AppID: 2681470) - missing depot keys
-- addappid(2681470)
-- Super Jigsaw Puzzle Generations - South Korea (AppID: 2831100) - missing depot keys
-- addappid(2831100)
-- Super Jigsaw Puzzle Generations - Birds 2 (AppID: 2831110) - missing depot keys
-- addappid(2831110)
-- Super Jigsaw Puzzle Generations - Illustrations 2 (AppID: 2831120) - missing depot keys
-- addappid(2831120)
-- Super Jigsaw Puzzle Generations - Music (AppID: 2831130) - missing depot keys
-- addappid(2831130)
-- Super Jigsaw Puzzle Generations - Red Things (AppID: 2986120) - missing depot keys
-- addappid(2986120)
-- Super Jigsaw Puzzle Generations - Random Animals 4 (AppID: 2986130) - missing depot keys
-- addappid(2986130)
-- Super Jigsaw Puzzle Generations - Croatia (AppID: 2986140) - missing depot keys
-- addappid(2986140)
-- Super Jigsaw Puzzle Generations - Flowers 2 (AppID: 2986150) - missing depot keys
-- addappid(2986150)
-- Super Jigsaw Puzzle Generations - Agriculture (AppID: 2986160) - missing depot keys
-- addappid(2986160)
-- Super Jigsaw Puzzle Generations - Colorful 4 (AppID: 3153970) - missing depot keys
-- addappid(3153970)
-- Super Jigsaw Puzzle Generations - Morocco (AppID: 3153980) - missing depot keys
-- addappid(3153980)
-- Super Jigsaw Puzzle Generations - Random 7 (AppID: 3153990) - missing depot keys
-- addappid(3153990)
-- Super Jigsaw Puzzle Generations - Beaches 3 (AppID: 3154000) - missing depot keys
-- addappid(3154000)
-- Super Jigsaw Puzzle Generations - Sunsets 2 (AppID: 3154010) - missing depot keys
-- addappid(3154010)
-- Super Jigsaw Puzzle Generations - Nepal (AppID: 3154020) - missing depot keys
-- addappid(3154020)
-- Super Jigsaw Puzzle Generations - Anime 6 (AppID: 3154030) - missing depot keys
-- addappid(3154030)
-- Super Jigsaw Puzzle Generations - Landscapes 5 (AppID: 3378470) - missing depot keys
-- addappid(3378470)
-- Super Jigsaw Puzzle Generations - Ireland (AppID: 3378480) - missing depot keys
-- addappid(3378480)
-- Super Jigsaw Puzzle Generations - Sweets 2 (AppID: 3378490) - missing depot keys
-- addappid(3378490)
-- Super Jigsaw Puzzle Generations - Bugs 2 (AppID: 3378500) - missing depot keys
-- addappid(3378500)
-- Super Jigsaw Puzzle Generations - Rivers (AppID: 3378510) - missing depot keys
-- addappid(3378510)
-- Super Jigsaw Puzzle Generations - Turkey (AppID: 3378520) - missing depot keys
-- addappid(3378520)
-- Super Jigsaw Puzzle Generations - Ruins (AppID: 3543780) - missing depot keys
-- addappid(3543780)
-- Super Jigsaw Puzzle Generations - Scenic Villages (AppID: 3543790) - missing depot keys
-- addappid(3543790)
-- Super Jigsaw Puzzle Generations - Argentina (AppID: 3543800) - missing depot keys
-- addappid(3543800)
-- Super Jigsaw Puzzle Generations - Cars 2 (AppID: 3543810) - missing depot keys
-- addappid(3543810)
-- Super Jigsaw Puzzle Generations - Rome (AppID: 3543820) - missing depot keys
-- addappid(3543820)
-- Super Jigsaw Puzzle Generations - Random Animals 5 (AppID: 3543830) - missing depot keys
-- addappid(3543830)
-- Super Jigsaw Puzzle Generations - Forests (AppID: 3543840) - missing depot keys
-- addappid(3543840)
-- Super Jigsaw Puzzle Generations - Sweden (AppID: 3802190) - missing depot keys
-- addappid(3802190)
-- Super Jigsaw Puzzle Generations - Trucks (AppID: 3802200) - missing depot keys
-- addappid(3802200)
-- Super Jigsaw Puzzle Generations - Cats 3 (AppID: 3802210) - missing depot keys
-- addappid(3802210)
-- Super Jigsaw Puzzle Generations - Dogs 3 (AppID: 3802220) - missing depot keys
-- addappid(3802220)
-- Super Jigsaw Puzzle Generations - Colorful 5 (AppID: 3802230) - missing depot keys
-- addappid(3802230)
-- Super Jigsaw Puzzle Generations - South Africa (AppID: 3802240) - missing depot keys
-- addappid(3802240)
-- Super Jigsaw Puzzle Generations - Random 8 (AppID: 3802250) - missing depot keys
-- addappid(3802250)
-- Super Jigsaw Puzzle Generations - Food 2 (AppID: 4088170) - missing depot keys
-- addappid(4088170)
-- Super Jigsaw Puzzle Generations - Tokyo (AppID: 4088180) - missing depot keys
-- addappid(4088180)
-- Super Jigsaw Puzzle Generations - Beaches 4 (AppID: 4088190) - missing depot keys
-- addappid(4088190)
-- Super Jigsaw Puzzle Generations - Winter 5 (AppID: 4088200) - missing depot keys
-- addappid(4088200)
-- Super Jigsaw Puzzle Generations - Thailand (AppID: 4088210) - missing depot keys
-- addappid(4088210)
-- Super Jigsaw Puzzle Generations - Landscapes 6 (AppID: 4088230) - missing depot keys
-- addappid(4088230)
-- Super Jigsaw Puzzle Generations - Big Cats 3 (AppID: 4277360) - missing depot keys
-- addappid(4277360)
-- Super Jigsaw Puzzle Generations - Abandoned Places 3 (AppID: 4277370) - missing depot keys
-- addappid(4277370)
-- Super Jigsaw Puzzle Generations - USA 2 (AppID: 4277380) - missing depot keys
-- addappid(4277380)
-- Super Jigsaw Puzzle Generations - Boats 2 (AppID: 4277390) - missing depot keys
-- addappid(4277390)
-- Super Jigsaw Puzzle Generations - Parrots (AppID: 4277400) - missing depot keys
-- addappid(4277400)
-- Super Jigsaw Puzzle Generations - Vegetables 2 (AppID: 4277410) - missing depot keys
-- addappid(4277410)
-- Super Jigsaw Puzzle Generations - Madagascar (AppID: 4569550) - missing depot keys
-- addappid(4569550)
-- Super Jigsaw Puzzle Generations - Waterfalls 3 (AppID: 4569560) - missing depot keys
-- addappid(4569560)
-- Super Jigsaw Puzzle Generations - Sunsets 3 (AppID: 4569570) - missing depot keys
-- addappid(4569570)
-- Super Jigsaw Puzzle Generations - Random Animals 6 (AppID: 4569580) - missing depot keys
-- addappid(4569580)
-- Super Jigsaw Puzzle Generations - Denmark (AppID: 4569590) - missing depot keys
-- addappid(4569590)
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4569600) -- Super Jigsaw Puzzle: Generations - Colorful 6 (unreleased)
-- addappid(4569610) -- Super Jigsaw Puzzle: Generations - Random 9 (unreleased)
-- addappid(4969860) -- Super Jigsaw Puzzle: Generations - Street Art 3 (unreleased)