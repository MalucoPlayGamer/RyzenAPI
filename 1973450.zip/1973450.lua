-- Lua provided by RyzenAPI
-- Game: Personal Space

-- MAIN APPLICATION
addappid(1973450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973451, 1, "701ccf271a59ac45ef22f8832ae0603afd3c2cefd7f07c7216de666cdb2cabdf")
