-- Lua provided by RyzenAPI 
-- Game: Personal Space
addappid(1973450)
addappid(1973451, 1, "701ccf271a59ac45ef22f8832ae0603afd3c2cefd7f07c7216de666cdb2cabdf")
