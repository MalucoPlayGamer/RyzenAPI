-- Lua provided by RyzenAPI
-- Game: 1964640

-- MAIN APPLICATION
addappid(1964640)
-- Game: addappid(1964640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964641, 1, "0855a1bde32d99ed33bedebe035d8ae21eae10626bbd8adfdbb770f60ddd0328")
