-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Seraph Circle Monster Pack 1

-- MAIN APPLICATION
addappid(1523060)
-- Game: addappid(1523060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523060,0,"096b29f56a9587117cf6a3b8f7bde8e9f42479da912c57ee1570a1dcf79374ad")
