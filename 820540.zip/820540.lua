-- Lua provided by RyzenAPI
-- Game: addappid(820540)

-- MAIN APPLICATION
addappid(820540)

-- MAIN APP DEPOTS / PACKAGES
addappid(820541, 1, "1965a4a3401eb5613fe867b6284894f7065ea5e7b87710a0fb0c5b8f12c242aa")
