-- Lua provided by RyzenAPI
-- Game: Game: C.A.R.D.S. RPG: The Misty Battlefield Demo

-- MAIN APPLICATION
addappid(2684320)
-- Game: addappid(2684320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684321, 1, "a615177f684a7ff36af8e9b238785dd3d4e19a5334f2471a9fb3c262e729919c")
