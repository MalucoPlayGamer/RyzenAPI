-- Lua provided by RyzenAPI
-- Game: We Are One

-- MAIN APPLICATION
addappid(1669500)
-- Game: addappid(1669500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669501, 1, "436a4fad0081855e15f915841047d84777c1b2458f0864c4609aa0ed55cf4d9e")
