-- Lua provided by SkyAPI 
-- Game: We Are One
addappid(1669500)
addappid(1669501, 1, "436a4fad0081855e15f915841047d84777c1b2458f0864c4609aa0ed55cf4d9e")
