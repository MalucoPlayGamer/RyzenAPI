-- Lua provided by RyzenAPI
-- Game: addappid(781260)

-- MAIN APPLICATION
addappid(781260)

-- MAIN APP DEPOTS / PACKAGES
addappid(781261, 1, "573708796e41f5f44154875ab13b833df11c9c49e75aab4fe89fda1b31854b6d")
