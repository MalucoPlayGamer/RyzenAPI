-- Lua provided by RyzenAPI
-- Game: Third Crisis

-- MAIN APPLICATION
addappid(1260820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260821, 1, "852ca57fa9da1bba259bddd26ebf6114b9ee327ffaa4c4e7197e7e30596cc99f")

