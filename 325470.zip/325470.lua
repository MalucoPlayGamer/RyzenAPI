-- Lua provided by RyzenAPI
-- Game: 1953: NATO vs Warsaw Pact

-- MAIN APPLICATION
addappid(325470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(325471, 1, "75aa1e809d2c4ba74c1725dcbaa0108f528a30fbe259053252149f385ae14ca2")

