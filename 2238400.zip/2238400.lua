-- 2238400's Lua and Manifest Created by Hubcap Manifest
-- PizzaBoy
-- Created: August 15, 2026 at 05:52:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2238400) -- PizzaBoy
-- MAIN APP DEPOTS
addappid(2238401, 1, "b9b9f109a8a9f502f99e885c57cfe766a7e01d6fc9d9701bf04453bfd5d236f1") -- Depot 2238401
setManifestid(2238401, "100001808075437939", 43032175)
addappid(2238402, 1, "bcda01a5ab013fab81b4102a2e9d64515b320ca93844fed483842e023ee78635") -- Depot 2238402
setManifestid(2238402, "1091556676507734354", 335270297)