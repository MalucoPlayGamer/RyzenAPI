-- 4178810's Lua and Manifest Created by Hubcap Manifest
-- Datacenter Simulator
-- Created: July 21, 2026 at 13:38:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4178810) -- Datacenter Simulator
-- MAIN APP DEPOTS
addappid(4178811, 1, "e2cbe410e1b4d805c39f54b6c7c589c42752534c177548e2aef222c0f85ad3b0") -- Depot 4178811
setManifestid(4178811, "6638753431883653524", 158965132)