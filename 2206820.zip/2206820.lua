-- Lua provided by SkyAPI 
-- Game: Tokyo Pinball
addappid(2206820)
addappid(2206821, 1, "d3d6a67699a04c5fc7592bea196336a9f7fda676cb2a33a5c77d5ed01ae717e9")
