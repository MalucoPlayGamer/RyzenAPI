-- Lua provided by RyzenAPI
-- Game: addappid(1778560)

-- MAIN APPLICATION
addappid(1778560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778561, 1, "6d5fbfd532a3df1a3e530613f6771fcd8276a8d1be5c463f8d225b77abf41084")
