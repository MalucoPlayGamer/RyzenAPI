-- Lua provided by RyzenAPI
-- Game: PONG Quest™

-- MAIN APPLICATION
addappid(1177030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177031, 1, "74b28899f4b4b54d02bc6dedb41eefadcf47dd668912d2c6a0c7d3ddec184cfe")
