-- Lua provided by RyzenAPI
-- Game: Drealegy

-- MAIN APPLICATION
addappid(2761580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2761581, 1, "66625bbac3d5b8d307f5d503eb8514a836ebabbd774598fadd47c2f0a0897e78")
