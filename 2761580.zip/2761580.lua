-- Lua provided by RyzenAPI 
-- Game: AppID 2761580
addappid(2761580)
addappid(2761581, 1, "66625bbac3d5b8d307f5d503eb8514a836ebabbd774598fadd47c2f0a0897e78")
