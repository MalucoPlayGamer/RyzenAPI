-- Lua provided by RyzenAPI
-- Game: CortexGear:AngryDroids

-- MAIN APPLICATION
addappid(375620)

-- MAIN APP DEPOTS / PACKAGES
addappid(375621, 1, "0c56548f0fc96e259eb1f89e3d86e11876ca26cae9ca99963287a14b5671bf3e")
addappid(375622, 1, "427056cf71be66e26abdf390acd39e1c6d66dd58835c336628e304bd774ec42a")
addappid(375623, 1, "144473cd94c3bcdee29a47fffa367576908211875b4504b8109deb8a7af9e09a")

