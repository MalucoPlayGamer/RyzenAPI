-- Lua provided by RyzenAPI
-- Game: Vampirates

-- MAIN APPLICATION
addappid(3623280)
-- Game: addappid(3623280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3623281, 1, "dc7d91568d8c2fb564969c25f137e890fdf1cdf6fcd2d7b8f1b42d6167ddc4bb")
