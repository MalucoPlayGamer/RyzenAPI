-- Lua provided by RyzenAPI
-- Game: To the Top

-- MAIN APPLICATION
addappid(2244920)
-- Game: addappid(2244920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244921, 1, "4a2631eb8bef57d5e66d442dfedb30ec949d9ef414a5982a368a40b2870c2047")
addappid(2244922, 1, "dc8b52dd4e1193a894a15264bcdf0b1a7c95d028eec90b853175a8d9c948a3a7")
