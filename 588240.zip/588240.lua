-- Lua provided by RyzenAPI
-- Game: 588240

-- MAIN APPLICATION
addappid(588240)
-- Game: addappid(588240)

-- MAIN APP DEPOTS / PACKAGES
addappid(588241, 1, "f80ef8ed2d027e6da76f1f0d60c56e5e1e59a75e84b0912c31d25d67355dbcc5")
addappid(588243, 1, "33921d285a9d652bb21ae00186de5462723c730e19dea071bc3517f3b0bc8041")
