-- Lua provided by RyzenAPI 
-- Game: AppID 694370
addappid(694370)
addappid(694371, 1, "7b238b0e54b0de21693621f618ace3401751abc0b54ad97d17e69279b22d0743")
