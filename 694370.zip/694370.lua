-- Lua provided by RyzenAPI
-- Game: Space Pilgrim Academy: Year 1

-- MAIN APPLICATION
addappid(694370)

-- MAIN APP DEPOTS / PACKAGES
addappid(694371, 1, "7b238b0e54b0de21693621f618ace3401751abc0b54ad97d17e69279b22d0743")
