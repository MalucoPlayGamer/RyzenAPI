-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Time Fantasy Ships

-- MAIN APPLICATION
addappid(1468920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468920,0,"d0df0ef2ac2e830ffd9a0f40b6ff404424a1f73585668c4d174fb0b20f3b02d3")
