-- Lua provided by RyzenAPI
-- Game: Game: Imprisoned Queen

-- MAIN APPLICATION
addappid(1528550)
-- Game: addappid(1528550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528551, 1, "12bb48ed067e974f76806b9de60a1bd54f98fed5032b6e2300bbae16e9dfb9a2")
