-- Lua provided by RyzenAPI
-- Game: addappid(748610)

-- MAIN APPLICATION
addappid(748610)

-- MAIN APP DEPOTS / PACKAGES
addappid(748611, 1, "fa0b2f44a38db28fd5f6ec77b1aa3da70d21a7bde10e166722d4d27bf228ddca")
