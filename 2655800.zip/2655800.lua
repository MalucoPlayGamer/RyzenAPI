-- Lua provided by RyzenAPI
-- Game: 2655800

-- MAIN APPLICATION
addappid(2655800)
-- Game: addappid(2655800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655801, 1, "57f0049386ec49d8c15d07987c145544ecfefa2fcfe3c73693696c2e240a6055")
