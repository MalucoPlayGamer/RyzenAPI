-- Lua provided by RyzenAPI
-- Game: Only High

-- MAIN APPLICATION
addappid(2655800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655801, 1, "57f0049386ec49d8c15d07987c145544ecfefa2fcfe3c73693696c2e240a6055")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
