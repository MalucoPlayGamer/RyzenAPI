-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2555280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555280,0,"95c1d2964b23f8c5260d4a087ecddef5488a914db167e2be2734356deadb9302")

