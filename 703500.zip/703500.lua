-- Lua provided by RyzenAPI
-- Game: 703500

-- MAIN APPLICATION
addappid(703500)
-- Game: addappid(703500)

-- MAIN APP DEPOTS / PACKAGES
addappid(703501, 1, "ffaa43d6e1ae3c40f58787add0a9d1316f134641f62a5281565160e924be7a50")
