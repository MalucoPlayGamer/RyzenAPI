-- Lua provided by RyzenAPI
-- Game: ReThink | Evolved

-- MAIN APPLICATION
addappid(703500)

-- MAIN APP DEPOTS / PACKAGES
addappid(703501, 1, "ffaa43d6e1ae3c40f58787add0a9d1316f134641f62a5281565160e924be7a50")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
