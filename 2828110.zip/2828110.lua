-- Lua provided by RyzenAPI
-- Game: addappid(2828110)

-- MAIN APPLICATION
addappid(2828110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828111, 1, "453b14292db84253ddfe465b9ecdf0af980b73eaa8bedb379e41b95c183b856e")
