-- Lua provided by RyzenAPI
-- Game: Dough or Die Demo

-- MAIN APPLICATION
addappid(3516390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3516391, 1, "caa081e34762c8ba0aa43270c5b773b5720cb22bf601cedae0a71dc48475f8c4")

