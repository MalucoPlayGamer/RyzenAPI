-- Lua provided by RyzenAPI
-- Game: The Thing With Mistletoes

-- MAIN APPLICATION
addappid(587290)

-- MAIN APP DEPOTS / PACKAGES
addappid(587291, 1, "c454143130fdbbaee7e8738b29327122fbb44c9f44a3ce1c75d82680e2ae4c73")
