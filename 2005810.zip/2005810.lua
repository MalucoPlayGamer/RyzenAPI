-- Lua provided by RyzenAPI
-- Game: Game: Project Sundown

-- MAIN APPLICATION
addappid(2005810)
-- Game: addappid(2005810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005811, 1, "61ed1737c14722a8112e30f9b055ef6271a28526ba9c962837170e512388d3bf")
