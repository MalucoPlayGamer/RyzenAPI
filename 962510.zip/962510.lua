-- Lua provided by RyzenAPI
-- Game: The Darkest Woods 2

-- MAIN APPLICATION
addappid(962510)

-- MAIN APP DEPOTS / PACKAGES
addappid(962514,0,"5ddc55b232777226ed985370ff9d3910380855b227a4be03ef668842e7a50961")

