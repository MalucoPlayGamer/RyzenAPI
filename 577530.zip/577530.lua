-- Lua provided by RyzenAPI
-- Game: Pixel Ripped 1989

-- MAIN APPLICATION
addappid(577530)

-- MAIN APP DEPOTS / PACKAGES
addappid(577531, 1, "82d1b019123b32da4699d2ce93671d7771f4b238bded3272c200f810eca7927a")

