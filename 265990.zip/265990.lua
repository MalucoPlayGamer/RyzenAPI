-- Lua provided by RyzenAPI
-- Game: Rogue's Tale

-- MAIN APPLICATION
addappid(265990)
-- Game: addappid(265990)

-- MAIN APP DEPOTS / PACKAGES
addappid(265991, 1, "8ec50c018e0677c4efaafe76f8bde7c9bcbe7354fa4e2003a1a8d0e85341f346")
addappid(1123270, 0, "c507245a8d0b7e7467cdcd3fb6f97c96e4e1dd62389af9da56ca9b980ba706a4")
addappid(1618410, 0, "9d811911ba4fcd9d7542f63d997843065dd9418b2030da9e797c698538ced649")
addappid(2335700, 0, "8f1be7c77dda5638aad88fbcc3c8fb822d3044a67f76a2212ec646179e33277f")
