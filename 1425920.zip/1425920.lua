-- Lua provided by RyzenAPI
-- Game: Crazy Engineer

-- MAIN APPLICATION
addappid(1425920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425921, 1, "3252f4be4d96b49773dcccb0035d5bdc57a5ff5fa36d4742b4322e45b671e36f")

