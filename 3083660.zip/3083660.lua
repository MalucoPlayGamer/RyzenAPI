-- Lua provided by SkyAPI 
-- Game: Backrooms: The Labyrinth
addappid(3083660)
addappid(3083661, 1, "00147aa7051e54e3dcb6d7b6633fb2c22e2312adc7efe5688d66e1872d6dce83")
