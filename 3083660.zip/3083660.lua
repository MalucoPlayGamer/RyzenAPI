-- Lua provided by RyzenAPI
-- Game: Backrooms: The Labyrinth

-- MAIN APPLICATION
addappid(3083660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3083661, 1, "00147aa7051e54e3dcb6d7b6633fb2c22e2312adc7efe5688d66e1872d6dce83")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
