-- Lua provided by RyzenAPI
-- Game: Furry Femboys

-- MAIN APPLICATION
addappid(2386870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386871, 1, "f025080f8f95c28508da89d1f041d7f3de1d06c7e4bd3daf35bfb810a5167f81")
addappid(2426720, 0, "0f88a817e6d3df1d03cb55e291738b558b5eece68efe874dadcf5203d58d9bd3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2799480)
