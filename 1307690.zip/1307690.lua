-- Lua provided by RyzenAPI
-- Game: The Darkest Tales

-- MAIN APPLICATION
addappid(1307690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307691, 1, "a6de5c8f5a58a8c2ac8c4d62646112e53cba20619d1590399eb48d0ab28af126")
