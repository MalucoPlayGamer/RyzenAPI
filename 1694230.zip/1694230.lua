-- Lua provided by RyzenAPI
-- Game: Abtos Covert

-- MAIN APPLICATION
addappid(1694230)
-- Game: addappid(1694230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694232,0,"6809610cbb9a456a7777532c192a46c215b95e7f4cae9c1faeed290ed8c4489a")
