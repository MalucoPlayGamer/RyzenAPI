-- Lua provided by RyzenAPI 
-- Game: AppID 3678550
addappid(3678550)
addappid(3678551, 1, "7d12ed9c5fcc5d2016546dd0b1eb4d1e700b580cbdacccc98d7821dfb79e1003")
addappid(3678552, 1, "3a693b4367b93605053d071216d75730034a5f6b0dc2f7da41ff989e2e4c1a15")
