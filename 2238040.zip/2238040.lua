-- Lua provided by RyzenAPI
-- Game: Tiny Terry's Turbo Trip

-- MAIN APPLICATION
addappid(2238040)
-- Game: addappid(2238040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2238041, 1, "3c1d1d4caaa8d017d27db9d6188ea500a8f1725ef14f3edf7fcbefc7cfe86a83")
