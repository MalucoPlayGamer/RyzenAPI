-- Lua provided by RyzenAPI
-- Game: addappid(699130)

-- MAIN APPLICATION
addappid(699130)

-- MAIN APP DEPOTS / PACKAGES
addappid(699131, 1, "8e1c37df6ec32e30f09ea256f8732eb98b7955ec82c51c49960f0d078d057fbb")
