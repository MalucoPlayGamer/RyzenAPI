-- Lua provided by RyzenAPI
-- Game: World War Z

-- MAIN APPLICATION
addappid(699130)
addappid(1640650)
addappid(1708020)
addappid(2170270)
addappid(2226070)
addappid(2243210)
addappid(2313390)
addappid(2475060)
addappid(2540380)
addappid(2614650)
addappid(2614660)
addappid(2962180)
addappid(3100200)
addappid(3245120)
addappid(3245130)
addappid(3699420)
addappid(3699430)
addappid(3930030)
addappid(3930040)
addappid(4057370)
addappid(4197300)
addappid(4383600)
addappid(4383610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(699131, 1, "8e1c37df6ec32e30f09ea256f8732eb98b7955ec82c51c49960f0d078d057fbb")

