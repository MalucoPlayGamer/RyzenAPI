-- Lua provided by RyzenAPI
-- Game: Wolfenstein II: The New Colossus German Edition

-- MAIN APPLICATION
addappid(650500)

-- MAIN APP DEPOTS / PACKAGES
addappid(650502,0,"f9fe06d5fc7130069d5287d707a650ed400f80f462ff85ddf36630dccba01e07")
addappid(650503,0,"acc7778c0190707ae2f8f143cc7eeaad51f5aa6500ad1bd6e3bb7fdd24d2107b")
addappid(650504,0,"61ad73c12829708b42c314966498d1ce206690c07a2e7698e4c256d8c23cc548")
addappid(650505,0,"9264eaff66a065ec05f5616a3084f30833e9f430f5bfa6826579f0fa148b1809")
addappid(650506,0,"ca8a22874fd921ec0063ba8256d5d63e847d22c6dc176c7ee152f2595b9fe0cc")
addappid(650507,0,"15258101f5e9cc37f20331325c0e9c0065377d540b66ce5277980a6b1d2e6ddc")
addappid(650508,0,"028cdf3b95f65f816f1e99c01236490533249ac611cb7053380c4c5f8355ef9e")
addappid(650509,0,"21161a126ca8f7882d9c575647deeb1773421e0a8f6c9bd516185ad39eecfd05")
addappid(650526,0,"2adc1cfc74a6989b0415132605b0ac6fabc634586861cde5dc517ebdfb4af37a")
addappid(650527,0,"162ed3ec7b8a10aa5b0014b259a26f8abbacdf5ccb2eb884beb7198877a385b0")
addappid(650528,0,"aca8846b44375495ebbd561f01964d87129dee23ca3f5c65128a2b7c0791856f")
addappid(650529,0,"60732a2f5fcb4ad16bfdd50c084d55ffa48dca66e0f10a3d033fcaa1f31dd0a1")
addappid(719991,0,"4c1fa286fdd0402ab84f5bf12e9a70d490da5855b74f571378ead4aca57d1cb4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(650520)
addappid(650521)
addappid(650522)
addappid(650523)
addappid(650524)
addappid(719990)
