-- Lua provided by SkyAPI 
-- Game: AppID 1632210
addappid(1632210)
addappid(1632211, 1, "78032e8748045c036f3888d6f19c9b20d6022af28f598ff157644edca00b1025")
