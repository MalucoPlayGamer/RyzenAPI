-- Lua provided by RyzenAPI
-- Game: Everlasting Flowers Soundtrack Side A

-- MAIN APPLICATION
addappid(3114260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114262,0,"49146c6612804d877fe81afd8511e63f20d7f0a6f86b832ee34b6c705db568e6")
addappid(3114263,0,"387b254e2c6a6e8a7670fe7b137d371510d12bd4c969406ecb275ed9c183e97a")

