-- Lua provided by RyzenAPI
-- Game: AppID 1258080

-- MAIN APPLICATION
addappid(1258080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258081, 1, "18f6857be8fe6619967839c91b7a7c2e82bf8db7a0c34c6486ce0cd42607c590")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
