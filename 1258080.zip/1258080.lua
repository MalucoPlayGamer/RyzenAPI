-- Lua provided by SkyAPI 
-- Game: AppID 1258080
addappid(1258080)
addappid(1258081, 1, "18f6857be8fe6619967839c91b7a7c2e82bf8db7a0c34c6486ce0cd42607c590")
