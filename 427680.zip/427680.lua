-- Lua provided by RyzenAPI
-- Game: Zwei: The Arges Adventure

-- MAIN APPLICATION
addappid(427680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(427681, 1, "4d8d0d55de089ed506538763b717f1af2407603165f5776e9cdbb07676f05213")

