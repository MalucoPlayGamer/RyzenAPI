-- Lua provided by RyzenAPI
-- Game: Zwei: The Arges Adventure

-- MAIN APPLICATION
addappid(427680)

-- MAIN APP DEPOTS / PACKAGES
addappid(427681, 1, "4d8d0d55de089ed506538763b717f1af2407603165f5776e9cdbb07676f05213")
