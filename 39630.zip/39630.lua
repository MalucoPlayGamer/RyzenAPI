-- Lua provided by RyzenAPI
-- Game: AquaNox

-- MAIN APPLICATION
addappid(39630)
-- Game: addappid(39630)

-- MAIN APP DEPOTS / PACKAGES
addappid(39631, 1, "7d956cb2c8cdc75e35f890bfbd0050da16a7a4cc1a1bb8ba2c67be6444f2d02a")
addappid(39632, 1, "c86e2d05fdeb9bf1d4e28ea2299ecf9979cd4ef42e8f76af2262262331d7c536")
addappid(39633, 1, "9e1e81206f97d70fd78927ed9154898889ac5a0c8ffbdf59960075ada87efcc1")
addappid(39634, 1, "13c86a0baacdcbb3e05003b9a57102aad2f1787dee04c5319104503acadd9aff")
