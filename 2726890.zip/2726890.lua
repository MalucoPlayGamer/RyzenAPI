-- Lua provided by RyzenAPI
-- Game: Tomorrow's Love Puzzle

-- MAIN APPLICATION
addappid(2726890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726891, 1, "294bda221d4642787797dae2d1d979e24afb2c54fb277a6d9fa920b521200bb7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
