-- Lua provided by SkyAPI 
-- Game: Tomorrow's Love Puzzle
addappid(2726890)
addappid(2726891, 1, "294bda221d4642787797dae2d1d979e24afb2c54fb277a6d9fa920b521200bb7")
