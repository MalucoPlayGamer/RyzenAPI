-- Lua provided by RyzenAPI
-- Game: Tomorrow's Love Puzzle

-- MAIN APPLICATION
addappid(2726890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726891, 1, "294bda221d4642787797dae2d1d979e24afb2c54fb277a6d9fa920b521200bb7")
