-- Lua provided by RyzenAPI
-- Game: Start11 v2

-- MAIN APPLICATION
addappid(1694750)
addappid(2779080)
-- Game: addappid(1694750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694751, 1, "aaab6a7226c7f2782f255d376263b1ed31758d973f3c856b602f7aed03ef1b5e")
