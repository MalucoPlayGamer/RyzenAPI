-- Lua provided by RyzenAPI
-- Game: Hell Survivors

-- MAIN APPLICATION
addappid(2841510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841511, 1, "1032287b6c2a300b2e1f60fb98fbaa7eafa7fe0807c0d2d5e6d67cf3dc675eb1")
