-- Lua provided by RyzenAPI
-- Game: Arachnophobia

-- MAIN APPLICATION
addappid(1915410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915411,0,"6165f6dc8974623988c8f30519a0b545bb812fb5bc71cff639d1b2343ff2f5fa")

