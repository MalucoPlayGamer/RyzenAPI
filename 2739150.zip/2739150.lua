-- Lua provided by RyzenAPI
-- Game: I Want to Believe

-- MAIN APPLICATION
addappid(2739150) -- I Want to Believe

-- MAIN APP DEPOTS / PACKAGES
addappid(2739151, 1, "d500aba2fdd97c1f87c5ccb630135be8aead762659fb90b4270bda2631cecc4d") -- Depot 2739151

