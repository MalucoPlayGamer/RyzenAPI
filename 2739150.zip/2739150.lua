-- 2739150's Lua and Manifest Created by Hubcap Manifest
-- I Want to Believe
-- Created: October 02, 2025 at 15:12:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2739150) -- I Want to Believe
-- MAIN APP DEPOTS
addappid(2739151, 1, "d500aba2fdd97c1f87c5ccb630135be8aead762659fb90b4270bda2631cecc4d") -- Depot 2739151
setManifestid(2739151, "2260589346497749993", 8998414364)