-- Lua provided by RyzenAPI
-- Game: A Night In Berlin

-- MAIN APPLICATION
addappid(1338420)
addappid(1389290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1338421, 1, "c5c0ea3fc118d170766cfacfb1f8f5f82641f5eadfcbebb11e90dcda5c12481c")
