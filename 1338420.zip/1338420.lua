-- Lua provided by RyzenAPI
-- Game: AppID 1338420

-- MAIN APPLICATION
addappid(1338420)
addappid(1389290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338421, 1, "c5c0ea3fc118d170766cfacfb1f8f5f82641f5eadfcbebb11e90dcda5c12481c")
