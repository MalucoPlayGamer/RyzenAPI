-- Lua provided by RyzenAPI
-- Game: Bunny - The Horror Game

-- MAIN APPLICATION
addappid(911040)

-- MAIN APP DEPOTS / PACKAGES
addappid(911041, 1, "3bf4d1a559a514e5075bd7898830865df0d29cfbd9f6c90788838764a1943296")

