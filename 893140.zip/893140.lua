-- Lua provided by RyzenAPI
-- Game: AppID 893140

-- MAIN APPLICATION
addappid(893140)

-- MAIN APP DEPOTS / PACKAGES
addappid(893141, 1, "9024ac107ef102cf24d2f2927aa3b0ced4f7dda8e0f1d30dffcc28c7fcd0880c")

