-- Lua provided by RyzenAPI
-- Game: Sonic Lost World

-- MAIN APPLICATION
addappid(329440)

-- MAIN APP DEPOTS / PACKAGES
addappid(329441, 1, "f04a41b8c03dadf5c23fe09d6eb014cb62f632aadd68c1a7a3b3b2afb34c3d9c")
addappid(377210, 0, "74a425b244d1f5f37e0ed874d89d2e5d708a588709c2c3d5036cd46ad77ad109")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
