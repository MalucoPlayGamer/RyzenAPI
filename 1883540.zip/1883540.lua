-- Lua provided by RyzenAPI
-- Game: Game: AppID 1883540

-- MAIN APPLICATION
addappid(1883540)
-- Game: addappid(1883540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883541, 1, "87d73758e3d277ad6d5159f32eed4dd49374b464fbcacd69eaf87dbee1ee9d10")
