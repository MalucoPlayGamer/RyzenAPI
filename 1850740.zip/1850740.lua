-- Lua provided by RyzenAPI
-- Game: Ghost Watchers

-- MAIN APPLICATION
addappid(1850740)
addappid(3876090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850741, 1, "a830d518fb69395dfac8536575b35f141dc0ccb74f84bb08dad20556b7050c1e")
