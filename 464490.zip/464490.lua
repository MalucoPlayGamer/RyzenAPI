-- Lua provided by RyzenAPI
-- Game: 464490

-- MAIN APPLICATION
addappid(464490)
-- Game: addappid(464490)

-- MAIN APP DEPOTS / PACKAGES
addappid(464491, 1, "5c4a517abfe1cfb88d272ffdf071a0bf825bb1a1faa11375d28e91ed2d2939c7")
addappid(464492, 1, "7aa1d5bfc0599cf7559e25179e5287782b994d80bc22478166a1a0b23147df3d")
