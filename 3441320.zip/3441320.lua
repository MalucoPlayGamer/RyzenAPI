-- Lua provided by RyzenAPI
-- Game: Hyperdrive Horizon

-- MAIN APPLICATION
addappid(3441320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441322,0,"869f2d1f298e4d01a4beaf71817903c30d80a96d018fcfcf8f662883b3da2e83")
