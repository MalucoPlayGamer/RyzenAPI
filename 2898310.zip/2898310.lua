-- Lua provided by RyzenAPI
-- Game: 2898310

-- MAIN APPLICATION
addappid(2898310)
-- Game: addappid(2898310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2898311, 1, "4d3891154382bce636b01bd29ca65a283489671abf209ffcb94f891f25c9d281")
