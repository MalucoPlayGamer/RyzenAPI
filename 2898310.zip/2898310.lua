-- Lua provided by SkyAPI 
-- Game: EXOcars
addappid(2898310)
addappid(2898311, 1, "4d3891154382bce636b01bd29ca65a283489671abf209ffcb94f891f25c9d281")
