-- Lua provided by RyzenAPI
-- Game: SaGa SCARLET GRACE: AMBITIONS™

-- MAIN APPLICATION
addappid(686720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(686721, 1, "93aef7b79e2e4c44fa14a46f749c53e1f69352d676dbccf37773ad036bbd41bb")
addappid(686723, 1, "4cb3cc6501416c3773d5dc319822d503859e92c71bab61eb303bfa3b5a9fac9f")

