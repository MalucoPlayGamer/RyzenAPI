-- Lua provided by RyzenAPI
-- Game: addappid(3518150)

-- MAIN APPLICATION
addappid(3518150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3518151, 1, "911d8423bc856e0f46e95dec60b325dbea8d08ed624a47b639da58d467dcbba5")
