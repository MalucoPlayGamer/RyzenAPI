-- Lua provided by RyzenAPI
-- Game: DISSIDIA FINAL FANTASY NT Free Edition

-- MAIN APPLICATION
addappid(921590) -- DISSIDIA FINAL FANTASY NT Free Edition
addappid(1022330)
addappid(1022340)
addappid(1022343)
addappid(1022344)
addappid(1022345)
addappid(1022360)
addappid(1022361)
addappid(1022362)
addappid(1022365)
addappid(1022366)
addappid(1022367)
addappid(1022391)
addappid(1022392)
addappid(1022393)
addappid(1022394)
addappid(1022395)
addappid(1022396)
addappid(1022397)
addappid(1022400)
addappid(1022401)
addappid(1022402)
addappid(1022410)
addappid(1022411)
addappid(1022412)
addappid(1022413)
addappid(1022414)
addappid(1022415)
addappid(1022416)
addappid(1022417)
addappid(1022418)
addappid(1022419)
addappid(1022420)
addappid(1022421)
addappid(1022422)
addappid(1022423)
addappid(1022424)
addappid(1022425)
addappid(1022426)
addappid(1022427)
addappid(1022428)
addappid(1022429)
addappid(1022430)
addappid(1022431)
addappid(1022432)
addappid(1022433)
addappid(1022435)
addappid(1022436)
addappid(1022437)
addappid(1022438)
addappid(1022439)
addappid(1022440)
addappid(1022441)
addappid(1022442)
addappid(1022443)
addappid(1022444)
addappid(1022445)
addappid(1022446)
addappid(1022447)
addappid(1022448)
addappid(1022449)
addappid(1022460)
addappid(1022461)
addappid(1022462)
addappid(1022463)
addappid(1022464)
addappid(1022465)
addappid(1022466)
addappid(1022467)
addappid(1022468)
addappid(1022469)
addappid(1022470)
addappid(1022471)
addappid(1022472)
addappid(1022473)
addappid(1022474)
addappid(1022475)
addappid(1022476)
addappid(1022477)
addappid(1022478)
addappid(1022479)
addappid(1022490)
addappid(1022491)
addappid(1022492)
addappid(1022493)
addappid(1022494)
addappid(1022495)
addappid(1022496)
addappid(1022497)
addappid(1022498)
addappid(1022499)
addappid(1022500)
addappid(1022501)
addappid(1022502)
addappid(1022503)
addappid(1022504)
addappid(1022505)
addappid(1022506)
addappid(1022507)
addappid(1022508)
addappid(1022509)
addappid(1022510)
addappid(1022511)
addappid(1022512)
addappid(1022513)
addappid(1022514)
addappid(1048460) -- DFFNT Season Pass
addappid(1052700) -- DFFNT The Espers Progeny App. Set  5th Weapon for Terra Branford
addappid(1052701) -- DFFNT Fallen One Appearance Set  5th Weapon for Kefka Palazzo
addappid(1056400)
addappid(1056670) -- DFFNT 3rd Appearance Special Set for Terra  Kefka
addappid(1075380) -- DFF NT The Soldier of Fortune Appearance Set  5th Weapon for Zidane Tribal
addappid(1075381) -- DFF NT The Unlikely Hero Appearance Set  5th Weapon for Ramza
addappid(1075382) -- DFF NT 3rd Appearance Special Set for Zidane  Ramza
addappid(1096450) -- DFF NT 3rd Appearance Special Set for Cloud  Squall
addappid(1096451) -- DFF NT Sky-Soarer Cloud App. Set.  5th Weapon for Cloud Strife
addappid(1096460) -- DFF NT Sleeping Lion App. Set.  5th Weapon for Squall Leonhart
addappid(1103740)
addappid(1103741)
addappid(1103742)
addappid(1103750)
addappid(1103751)
addappid(1103752)
addappid(1134560) -- DFF NT 3rd Appearance Special Set for Bartz  Ace
addappid(1134561) -- DFF NT Samurai App. Set  5th Weapon for Bartz Klauser
addappid(1134562) -- DFF NT Combat Overcoat App. Set  5th Weapon for Ace
addappid(1146140) -- DFF NT Songstresss Garb Appearance Set  5th Weapon for Yuna
addappid(1146141) -- DFF NT Midnight Mauve Appearance Set  5th Weapon for Lightning
addappid(1146142) -- DFF NT 3rd Appearance Special Set for Yuna  Lightning
addappid(1163400)
addappid(1163401)
addappid(1163402)
addappid(1176680) -- DFF NT Wedding Dress App. Set  5th Weapon for Shantotto
addappid(1176681) -- DFF NT Otherworldly Garb App. Set  5th Weapon for Noctis
addappid(1176682) -- DFF NT 3rd Appearance Special Set for Shantotto and Noctis
addappid(1195330) -- DFF NT Knight in Shining Armor App. Set  Weapon for Warrior of Light
addappid(1195331) -- DFF NT Scion Sorceresss Robe App. Set  5th Weapon for Yshtola
addappid(1195332) -- DFF NT 3rd Appearance Special Set for Warrior of Light and Yshtola
addappid(1213330)
addappid(1213331)
addappid(1213332)
addappid(1213353) -- DFF NT Safer Sephiroth Appearance Set  5th Weapon for Sephiroth
addappid(1213354) -- DFF NT Wings of Love Appearance Set  5th Weapon for Rinoa Heartilly
addappid(1213355) -- DFF NT 3rd Appearance Special Set for Sephiroth and Rinoa Heartilly
addappid(1229950) -- DFF NT The Wanderer Appearance Set  5th Weapon for Kain Highwind
addappid(1229951) -- DFF NT Sky Pirate Garb Appearance Set  5th Weapon for Vaan
addappid(1229952) -- DFF NT 3rd Appearance Special Set for Kain Highwind and Vaan
addappid(1250620) -- DFF NT Hells Remnant Appearance Set  5th Weapon for Emperor
addappid(1250621) -- DFF NT Void Ruler Appearance Set  5th Weapon for Cloud of Darkness
addappid(1250622) -- DFF NT 3rd Appearance Special Set for Emperor and Cloud of Darkness

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(921591, 1, "9a4019318c2ce18690c2586fb626a05ae3b0e18dfac9a28863cae2bacbfb8218") -- DISSIDIA FINAL FANTASY NT Content
addappid(1022330, 1, "1f8c03f19c046acb51439c94de63846c2db11971cb55114c392dfcf2d90d0e4d") -- DFF NT Vayne Carudas Solidor Starter Pack - DFF NT: Vayne Carudas Solidor Starter Pack デポ
addappid(1022340, 1, "00a0fa978cae7913fad461a452023c79b994fff7b32edf2fb91eb2d2febb8d1e") -- DFF NT Novus Appearance Set for Vayne Carudas Solidor - DFF NT: Novus Appearance Set for Vayne Carudas Solidor デポ
addappid(1022343, 1, "88bbe0cffb0bc6afc8887f5ff65ca32d08149e6881d088f3fc0c7194c1a035da") -- DFF NT Recompense, Vayne Carudas Solidors 4th Weapon - DFF NT: Recompense, Vayne Carudas Solidor's 4th Weapon デポ
addappid(1022344, 1, "59425e0f41926e16c8e7eb08e344866843b20337c4d7f00014948473ccb747f0") -- DFF NT Locke Cole Starter Pack - DFF NT: Locke Cole Starter Pack デポ
addappid(1022345, 1, "ff4962749718e06ee2b887e0f5195d04db476dcf50ac9798ea25748fd3753573") -- DFF NT Devoted Returner Appearance Set for Locke Cole - DFF NT: Devoted Returner Appearance Set for Locke Cole デポ
addappid(1022360, 1, "4114ac5ff7a5b6e52fbbc7971f372e992694360c637318b222ec7bf24fa5a5dd") -- DFF NT Valiant Knife, Locke Coles 4th Weapon - DFF NT: Valiant Knife, Locke Cole's 4th Weapon デポ
addappid(1022361, 1, "502ad81a5fe4107c6629f8d961d46acccd49268b1997a42bea96b2ed36f0f644") -- DFF NT Rinoa Heartilly Starter Pack - DFF NT: Rinoa Heartilly Starter Pack デポ
addappid(1022362, 1, "fca2438cada9fa9d7c5af0bea5c62183fae901bb1cb04b2288f6b346ac7e8583") -- DFF NT Party Dress Appearance Set for Rinoa Heartilly - DFF NT: Party Dress Appearance Set for Rinoa Heartilly デポ
addappid(1022365, 1, "9f4ccd0026127ecd824743629b28c8d41059ccb22584c4375f0b363c9d9e12ad") -- DFF NT Cardinal, Rinoa Heartillys 4th Weapon - DFF NT: Cardinal, Rinoa Heartilly's 4th Weapon デポ
addappid(1022366, 1, "82667ad825b4e11edc27797d04a319b28cd57a3bc7b7281334aece8814aa839b") -- DFF NT Kamlanaut Starter Pack - DFF NT: Kam'lanaut Starter Pack デポ
addappid(1022367, 1, "85f168028dc4a5ebc991fbc4b1f2b3485dccc996953bead37c6cc7752101e420") -- DFF NT Archduke of Jeuno Appearance Set for Kamlanaut - DFF NT: Archduke of Jeuno Appearance Set for Kam'lanaut デポ
addappid(1022391, 1, "070a37fd322338c16f694912ea51b9ccf0fb849e27621d4e0145d32b513d265f") -- DFF NT Divine Blade, Kamlanauts 4th Weapon - DFF NT: Divine Blade, Kam'lanaut's 4th Weapon デポ
addappid(1022392, 1, "1acba40e07edff86b6e0fbdcc765892aafa73f33a8c8b9483cb97c55434422a9") -- DFF NT Yuna Starter Pack - DFF NT: Yuna Starter Pack デポ
addappid(1022393, 1, "a9ac1e0707def69f1bc9d1b59ab1742a1a03f6369a9264a3647641260d248a1d") -- DFF NT Wedding Gown Appearance Set for Yuna - DFF NT: Wedding Gown Appearance Set for Yuna デポ
addappid(1022394, 1, "6b8362476679c8ba8d2ae88810fefe800dcbf08d0c62adcfac1b2ccdce3b5f87") -- DFF NT Astral Rod, Yunas 4th Weapon - DFF NT: Astral Rod, Yuna's 4th Weapon デポ
addappid(1022395, 1, "d55dbb5b886b288cb777e4aa7bd3abb4956acfc66cbac34bb773fbcb22f26f18") -- DFF NT Snow Villiers Starter Pack - DFF NT: Snow Villiers Starter Pack デポ
addappid(1022396, 1, "732b3f6f6797eedbba71e01a5ce432ad947d9c7bb8b1d1a0305594d8c25e5874") -- DFF NT Wild Bear Appearance Set for Snow Villiers - DFF NT: Wild Bear Appearance Set for Snow Villiers デポ
addappid(1022397, 1, "11cf21077c58dab9bd5e4ba694073dc7ba11e7deb5a3f7e64fa87508c047c61c") -- DFF NT Glacial Guard, Snow Villiers 4th Weapon - DFF NT: Glacial Guard, Snow Villiers' 4th Weapon デポ
addappid(1022400, 1, "cd56a0b33eedb36f8aa34a29394b504e9f6242aa0c7ea49b6a787c1de75dd3e0") -- DFF NT Sun Blade  Diamond Shield, Warrior of Lights 4th Weapon Set - DFF NT: Sun Blade / Diamond Shield, Warrior of Light's 4th Weapon Set デポ
addappid(1022401, 1, "a26f0c64d8680eed67cd7df8613d3fb11e47e70b1c1f8fe1a399c74d88f980f4") -- DFF NT Zanmato, Garlands 4th Weapon - DFF NT: Zanmato, Garland's 4th Weapon デポ
addappid(1022402, 1, "88b88a509035e9ab53d56cbd1293c17b6f0dfeea1ddeb3d6018ce373dfdb38d0") -- DFF NT Arsenal IV, Firions 4th Weapon Set - DFF NT: Arsenal IV, Firion's 4th Weapon Set デポ
addappid(1022410, 1, "b777b816105c728909c6a707714f3ae75156f7dd914c11c5541120120fa4ff99") -- DFF NT Rod of Censure, the Emperors 4th Weapon - DFF NT: Rod of Censure, the Emperor's 4th Weapon デポ
addappid(1022411, 1, "5b1ab6078c9289d50d9ba8a49b0bca9a7f25406de4d1a03f9abb19585ad98a5e") -- DFF NT Golden Sword  Omnirod  Kiku-ichimonji, O. Knights 4th Weap. - DFF NT: Golden Sword / Omnirod / Kiku-ichimonji, O. Knight's 4th Weap. デポ
addappid(1022412, 1, "4946e4b33ba539e3b01866ce3306481ae7150d2cc2e9af57772d0d46b1d450ed") -- DFF NT Destructive Tentacles, Cloud of Darknesss 4th Weapon Set - DFF NT: Destructive Tentacles, Cloud of Darkness's 4th Weapon Set デポ
addappid(1022413, 1, "57127dc03b79077d4c31bdedfdc4545b6fcced686986341ea6d200e05890a269") -- DFF NT Waning Blade  Waxing Blade, Cecil Harveys 4th Weapon Set - DFF NT: Waning Blade / Waxing Blade, Cecil Harvey's 4th Weapon Set デポ
addappid(1022414, 1, "15e42ac0981e21cf2ccc2bc288ba5a9d083333fb8fd3a7d0c114e10e35304780") -- DFF NT Lance of Ordeals, Kain Highwinds 4th Weapon - DFF NT: Lance of Ordeals, Kain Highwind's 4th Weapon デポ
addappid(1022415, 1, "50d4394512a920ac970e41632b79d53b95359449021caf92bbb9b69e86a8c0cf") -- DFF NT Obsidian Scales, Golbezs 4th Weapon - DFF NT: Obsidian Scales, Golbez's 4th Weapon デポ
addappid(1022416, 1, "1e584979ea0db0adeb2766b056f58473079a1e80824998f10e1db207d81faa1e") -- DFF NT Arsenal IV, Bartz Klausers 4th Weapon Set - DFF NT: Arsenal IV, Bartz Klauser's 4th Weapon Set デポ
addappid(1022417, 1, "eec2ed23ac6a9a2df7c844f1b1f23abb6a51a6752b7ee3f14c80e0726bb6b0c5") -- DFF NT Void Sword, Exdeaths 4th Weapon - DFF NT: Void Sword, Exdeath's 4th Weapon デポ
addappid(1022418, 1, "ff973691af2630c5b0737cc696db9abd03ec37fcd947f7151ff30c0d538a845d") -- DFF NT Zantetsuken, Terra Branfords 4th Weapon - DFF NT: Zantetsuken, Terra Branford's 4th Weapon デポ
addappid(1022419, 1, "fc06b385a3b6ced236375810ec9c34448b14a59c3c95fd206b8ad3f396026045") -- DFF NT Thinking Cap, Kefka Palazzos 4th Weapon - DFF NT: Thinking Cap, Kefka Palazzo's 4th Weapon デポ
addappid(1022420, 1, "9df645b7ee299660be82154273c56f5ba656cfc29a4a40680d8a238a26dd10f9") -- DFF NT Organyx, Cloud Strifes 4th Weapon - DFF NT: Organyx, Cloud Strife's 4th Weapon デポ
addappid(1022421, 1, "138687dc42e47646b1a17f6934e41bd98cb6fad75863df6700fa186418b416c8") -- DFF NT Second Coming, Sephiroths 4th Weapon - DFF NT: Second Coming, Sephiroth's 4th Weapon デポ
addappid(1022422, 1, "77f00f1a016a9fdc72b71fa329af4548fafbcc2189f998d818c8e7bd390ddab1") -- DFF NT Hyperion, Squall Leonharts 4th Weapon - DFF NT: Hyperion, Squall Leonhart's 4th Weapon デポ
addappid(1022423, 1, "0a998c16befd37bcac9585987d525c863effe927f305023126dcf4c4a5de392b") -- DFF NT Nightmare, Ultimecias 4th Weapon - DFF NT: Nightmare, Ultimecia's 4th Weapon デポ
addappid(1022424, 1, "971e1076465934759cabfad7451f40708382e925b749d30294c6258b49e57713") -- DFF NT Orichalcum, Zidane Tribals 4th Weapon - DFF NT: Orichalcum, Zidane Tribal's 4th Weapon デポ
addappid(1022425, 1, "f7f167e9636545f24f54c15b8fa4eb0a40d668c961f591981e556dafacd18d17") -- DFF NT Turbid Cores, Kujas 4th Weapon Set - DFF NT: Turbid Cores, Kuja's 4th Weapon Set デポ
addappid(1022426, 1, "4ed397e1bbec5cd929206c4eafe8dde4d101ce7d2e8f8c8e259c65b0d24c70c7") -- DFF NT Arc Sword, Tiduss 4th Weapon - DFF NT: Arc Sword, Tidus's 4th Weapon デポ
addappid(1022427, 1, "c10a927db8fdf52121ab21621de5eb5a0a8e969a0490f59b0db4c2f4cf09cb44") -- DFF NT Sins Spur, Jechts 4th Weapon - DFF NT: Sin's Spur, Jecht's 4th Weapon デポ
addappid(1022428, 1, "07433bda7eb414c814ae3df8de68e9a5d6edc6f3d78888252250198e4c299111") -- DFF NT Laevateinn, Shantottos 4th Weapon - DFF NT: Laevateinn, Shantotto's 4th Weapon デポ
addappid(1022429, 1, "c641d0b38ab9a3f523f8366f35c1d5da115ecbb4d6f3f3171c03382e867ffba0") -- DFF NT Platinum Sword, Vaans 4th Weapon - DFF NT: Platinum Sword, Vaan's 4th Weapon デポ
addappid(1022430, 1, "2ff8bf0e570f1c404c8fae4717ef04c87004c4f22d9d8c238d6054b9bb012872") -- DFF NT Shire Crook, Yshtolas 4th Weapon - DFF NT: Shire Crook, Y'shtola's 4th Weapon デポ
addappid(1022431, 1, "6a98f023178d022ac1ecef6e2fb0fed22961831f081582a7921283286359528a") -- DFF NT Armaments IV, Noctis Lucis Caelums 4th Weapon Set - DFF NT: Armaments IV, Noctis Lucis Caelum's 4th Weapon Set デポ
addappid(1022432, 1, "49e9aed7bb3d3e59e2e881fd90a15d5ba3b6773c99167cfe922914ee8fa10487") -- DFF NT Excalibur, Ramza Beoulves 4th Weapon - DFF NT: Excalibur, Ramza Beoulve's 4th Weapon デポ
addappid(1022433, 1, "d983b4934b4a06925e700bc931c05f3f597a71c7318ac5ad6823ee158f1a6e8e") -- DFF NT Magicians Deck, Aces 4th Weapon - DFF NT: Magician's Deck, Ace's 4th Weapon デポ
addappid(1022435, 1, "cbec80ae0e12bdd22d241e67066e27713bfcd91f66d76754e48e70651bcedba0") -- DFF NT Warrior of Light Starter Pack - DFF NT: Warrior of Light Starter Pack デポ
addappid(1022436, 1, "6133ff2d76fc7ca0f45be76f32cc37fde71d9edc9236fe23b136ad4cf21c1db2") -- DFF NT Garland Starter Pack - DFF NT: Garland Starter Pack デポ
addappid(1022437, 1, "9d49566135be2254e648766a3b615201c505b77de427b824e93fc99d9a84b02d") -- DFF NT Firion Starter Pack - DFF NT: Firion Starter Pack デポ
addappid(1022438, 1, "de4fe21ae82f450b2b530b31d007ac17f4ad42e3d57724a1c3c5e964b1aa2d97") -- DFF NT Emperor Starter Pack - DFF NT: Emperor Starter Pack デポ
addappid(1022439, 1, "dc92aaadcea5b4f7ab1e5786b4435fd49e85a776087128bc43328bfd3f125b78") -- DFF NT Onion Knight Starter Pack - DFF NT: Onion Knight Starter Pack デポ
addappid(1022440, 1, "fc8fc2ba7d9fcda184013a334d7706b31cfd5f65f57eac1893a6aa070c27117b") -- DFF NT Cloud of Darkness Starter Pack - DFF NT: Cloud of Darkness Starter Pack デポ
addappid(1022441, 1, "a4ac604b2f02ed355a1c50dc164ac34c86402c411f8ed4684ca8f2e985174947") -- DFF NT Cecil Harvey Starter Pack - DFF NT: Cecil Harvey Starter Pack デポ
addappid(1022442, 1, "59929ef44bbceac94db18ba8d1421fe3dde75cc72044003b0991bab257d4c247") -- DFF NT Kain Highwind Starter Pack - DFF NT: Kain Highwind Starter Pack デポ
addappid(1022443, 1, "3bb64e35fb08df98478bb52d8ccecc8b004d52f3bc8c0ad3b9e4131c94455495") -- DFF NT Golbez Starter Pack - DFF NT: Golbez Starter Pack デポ
addappid(1022444, 1, "90285e9c51620e725bfcec04ec5c6d255a03fad59256add66f97945be8f23df2") -- DFF NT Bartz Klauser Starter Pack - DFF NT: Bartz Klauser Starter Pack デポ
addappid(1022445, 1, "02395496f464caf9015ca2e72a7bff42546fefae25376b48dd5c2a7379e4cd8b") -- DFF NT Exdeath Starter Pack - DFF NT: Exdeath Starter Pack デポ
addappid(1022446, 1, "1700f3d071229dd592f4663fbb6879bde0f1c73b43d59d86b5b0c8bc04a21aa4") -- DFF NT Terra Branford Starter Pack - DFF NT: Terra Branford Starter Pack デポ
addappid(1022447, 1, "b36879658111ccd42e7aa8b5ea3371f1d5f965cb6a8dcff03863d1926375a351") -- DFF NT Kefka Palazzo Starter Pack - DFF NT: Kefka Palazzo Starter Pack デポ
addappid(1022448, 1, "6153973cb229e22bf55669b1d742c28c77f26ea7833d52b91ffff929644c8183") -- DFF NT Cloud Strife Starter Pack - DFF NT: Cloud Strife Starter Pack デポ
addappid(1022449, 1, "d51ecfcfc99a3ecafcde78cf4150bd39c8b8c9e681dc8bc564d9c4996617b1e3") -- DFF NT Sephiroth Starter Pack - DFF NT: Sephiroth Starter Pack デポ
addappid(1022460, 1, "1a2aa7eb0f3fe4de5e21dacc91b97e92716e1e3cb994d6927a471be36c0c1afc") -- DFF NT Squall Leonhart Starter Pack - DFF NT: Squall Leonhart Starter Pack デポ
addappid(1022461, 1, "a893e76d268701a0927116bacdf26c3844307a3bde83415b9b89f68ca3a64105") -- DFF NT Ultimecia Starter Pack - DFF NT: Ultimecia Starter Pack デポ
addappid(1022462, 1, "fb231ef569b6dd8d8dfac8f1bd0abc140781bad3211ad7e050962f76d35c14b8") -- DFF NT Zidane Tribal Starter Pack - DFF NT: Zidane Tribal Starter Pack デポ
addappid(1022463, 1, "05ac5d4e76ef69df59596f11e782496e95623707d76b7482db477cfa1dfa0033") -- DFF NT Kuja Starter Pack - DFF NT: Kuja Starter Pack デポ
addappid(1022464, 1, "ae7be3d303b8235bb7b66ee6ee002cd53c0be7dcfe8f18f16132d2da093eded6") -- DFF NT Tidus Starter Pack - DFF NT: Tidus Starter Pack デポ
addappid(1022465, 1, "15b3ab1743c8800cc55a2b956dcdb8352ab72d4b7ed87066f85820d54adc15bf") -- DFF NT Jecht Starter Pack - DFF NT: Jecht Starter Pack デポ
addappid(1022466, 1, "09b593c18c3ef5d7649c46353fc91e4e22c85bf53b724a0d0f4a210ec688b8ac") -- DFF NT Shantotto Starter Pack - DFF NT: Shantotto Starter Pack デポ
addappid(1022467, 1, "7663408cb28c4df4248d39c4597ac00e3288c93a3d1b6a878162486fa0548fc4") -- DFF NT Vaan Starter Pack - DFF NT: Vaan Starter Pack デポ
addappid(1022468, 1, "eb206b3bcf585c9d9e0f818d360b180acce20c3c9881c6213c190143c0577152") -- DFF NT Lightning Starter Pack - DFF NT: Lightning Starter Pack デポ
addappid(1022469, 1, "dc423d96702c1164fffdbb8dcf0d8ce2e7e2e513f02a7198bb9cefc059ab271f") -- DFF NT Yshtola Starter Pack - DFF NT: Y'shtola Starter Pack デポ
addappid(1022470, 1, "79fb43e9b0d390fa8c017378aa01d6abd5ba3302431a5e36f9965ce82a3aa3cc") -- DFF NT Noctis Lucis Caelum Starter Pack - DFF NT: Noctis Lucis Caelum Starter Pack デポ
addappid(1022471, 1, "fdf956417f8356ad2e2021a329c251f73264c37bfbe8ad5f25b24dfd3c0b0cfb") -- DFF NT Ramza Beoulve Starter Pack - DFF NT: Ramza Beoulve Starter Pack デポ
addappid(1022472, 1, "e6dd3bbcc894ccaac13d56ef548155548a69c10605cf202d004deca7e8143dd5") -- DFF NT Ace Starter Pack - DFF NT: Ace Starter Pack デポ
addappid(1022473, 1, "3d2e10f2a0ee398157fd88ddb0c29886943099d7113668a30d66a159d5e014ee") -- DFF NT Fledgling Warrior Appearance Set for Warrior of Light - DFF NT: Fledgling Warrior Appearance Set for Warrior of Light デポ
addappid(1022474, 1, "4da27c1f0c2e65a700d7d159724944d5aba5d209cc0bd7704c7d3f737044063a") -- DFF NT Hardened Zealot Appearance Set for Garland - DFF NT: Hardened Zealot Appearance Set for Garland デポ
addappid(1022475, 1, "6969717cb642b5c9ae9287decdcfb63d95a5cb18c0d096c34f172f62dc6decd7") -- DFF NT Resolute Rebel Appearance Set for Firion - DFF NT: Resolute Rebel Appearance Set for Firion デポ
addappid(1022476, 1, "95e5e5674a22d243462422b5a8353eb5b61fdabb11b1d8f169dac7344d5c194d") -- DFF NT Violet Robe Appearance Set for the Emperor - DFF NT: Violet Robe Appearance Set for the Emperor デポ
addappid(1022477, 1, "e972fea559d661f1d563c5482bd8b853cd07d7908ef880b79391fa32397cc90d") -- DFF NT Bladewielder Appearance Set for Onion Knight - DFF NT: Bladewielder Appearance Set for Onion Knight デポ
addappid(1022478, 1, "ec4bc59b1e7eff44b2c02727b82e154b71c6332724e99203132b76006bbe0e80") -- DFF NT Lucent Robe Appearance Set for Cloud of Darkness - DFF NT: Lucent Robe Appearance Set for Cloud of Darkness デポ
addappid(1022479, 1, "06862c5f570a34d8f0d69cec27f74835ecd973f4b8ae254be92ba345812fa120") -- DFF NT Cecil Reimagined Appearance Set for Cecil Harvey - DFF NT: Cecil Reimagined Appearance Set for Cecil Harvey デポ
addappid(1022490, 1, "24ed949f7a53d59212677346352ae2aa4ffee5ddcae315dd9b93cdb027693155") -- DFF NT Sanctifying Dragoon Appearance Set for Kain Highwind - DFF NT: Sanctifying Dragoon Appearance Set for Kain Highwind デポ
addappid(1022491, 1, "06cc892fb2da4fefa565d7215023b2c9b2d729e387703029e3f06002bba3717a") -- DFF NT Golbez Reimagined Appearance Set for Golbez - DFF NT: Golbez Reimagined Appearance Set for Golbez デポ
addappid(1022492, 1, "44c3675f2d28b4eb6842cd5612f9dd629d9b447ce77e700bf81b7f46f6807c7b") -- DFF NT Freelancer Appearance Set for Bartz Klauser - DFF NT: Freelancer Appearance Set for Bartz Klauser デポ
addappid(1022493, 1, "f40402f7ff6e34060d33aaa0f36eed7a4ad27f0f39e9731e3f7b991fb521a684") -- DFF NT Root of Evil Appearance Set for Exdeath - DFF NT: Root of Evil Appearance Set for Exdeath デポ
addappid(1022494, 1, "bcef6de57b5e7ddb4f6c8b7fb91dab9aed381cbe24297d52dfbcb1e42980ab51") -- DFF NT Benevolent Maiden Appearance Set for Terra Branford - DFF NT: Benevolent Maiden Appearance Set for Terra Branford デポ
addappid(1022495, 1, "869e87e6f08cfcd62ebab8d2a858cd1fcf88c3e430b33d4e5d618eb64955c316") -- DFF NT Snobbish Turban Appearance Set for Kefka Palazzo - DFF NT: Snobbish Turban Appearance Set for Kefka Palazzo デポ
addappid(1022496, 1, "3f1a9c44a822fc583cf807541a2f1b5ea1108a98887ec8fb2261434a478ed0a6") -- DFF NT Cloudy Wolf Appearance Set for Cloud Strife - DFF NT: Cloudy Wolf Appearance Set for Cloud Strife デポ
addappid(1022497, 1, "5b660130e6b657973561471d1d5cd7cb7e1db2cc23300db87e33f44f1fbfe9cc") -- DFF NT One-Winged Angel Appearance Set for Sephiroth - DFF NT: One-Winged Angel Appearance Set for Sephiroth デポ
addappid(1022498, 1, "586fe17f15a2f03f1aa66538a8d2954f0584ee6c3db7aec90e6bb182a9d6d035") -- DFF NT SeeD Uniform Appearance Set for Squall Leonhart - DFF NT: SeeD Uniform Appearance Set for Squall Leonhart デポ
addappid(1022499, 1, "37ae3c6f7c7eaf6e3212cbc8911b754c9b80b93e81522f9d6b1c17aacf70afcc") -- DFF NT Edeas Corpse Appearance Set for Ultimecia - DFF NT: Edea's Corpse Appearance Set for Ultimecia デポ
addappid(1022500, 1, "f06ce4220f6f0ede23b9e7fd63755dd6e62c45763132dad1b22f74b206b55247") -- DFF NT Pluto Uniform Appearance Set for Zidane Tribal - DFF NT: Pluto Uniform Appearance Set for Zidane Tribal デポ
addappid(1022501, 1, "2d8bcaf05c9fe695b0df21d7fa6cbdf7e4a70dd19bf66e26a2709c630f98732d") -- DFF NT Cloaked Anchorite Appearance Set for Kuja - DFF NT: Cloaked Anchorite Appearance Set for Kuja デポ
addappid(1022502, 1, "175c0eae9ec06ed2c3a8ddadc135a69408d4b9e2117780e3c9c6a33a527a8953") -- DFF NT Zanarkand Abes Uniform Appearance Set for Tidus - DFF NT: Zanarkand Abes Uniform Appearance Set for Tidus デポ
addappid(1022503, 1, "37da81c869a28ae17524fec02c127da9cf3f0b08c0f2fa577b736ae964bb3b62") -- DFF NT Away Uniform Appearance Set for Jecht - DFF NT: Away Uniform Appearance Set for Jecht デポ
addappid(1022504, 1, "793e2a409ab63a27ffba9585cf41b0fee863da6cc620d7d346148d45b1bccd32") -- DFF NT Ministerial Vestiture Appearance Set for Shantotto - DFF NT: Ministerial Vestiture Appearance Set for Shantotto デポ
addappid(1022505, 1, "2b170e54f370defa81c0658c60870f8f6308bbb55079ebc4f05dd74bee3037ec") -- DFF NT Conflicted Hero Appearance Set for Vaan - DFF NT: Conflicted Hero Appearance Set for Vaan デポ
addappid(1022506, 1, "9a048b25b68d9a4e5978ee9b6356320e4dcaffe4d7215ad359d35a0e67c9b730") -- DFF NT Knight of Etro Appearance Set for Lightning - DFF NT: Knight of Etro Appearance Set for Lightning デポ
addappid(1022507, 1, "97414cab8c67387cfbd67c8220827159feb1c18c2ea3e43288491e4a94f37b1f") -- DFF NT Scion Healers Robe Appearance Set for Yshtola - DFF NT: Scion Healer's Robe Appearance Set for Y'shtola デポ
addappid(1022508, 1, "3e8aff1949eb046656707a9463e0fd6581732a4398c94202b315355aecc9a228") -- DFF NT Kingly Raiment Appearance Set for Noctis Lucis Caelum - DFF NT: Kingly Raiment Appearance Set for Noctis Lucis Caelum デポ
addappid(1022509, 1, "774532824feda3cc9e06b0691f76daf62ec78cdddb8fd1de0032726ce75f4eed") -- DFF NT Virtuous Mercenary Appearance Set for Ramza Beoulve - DFF NT: Virtuous Mercenary Appearance Set for Ramza Beoulve デポ
addappid(1022510, 1, "3f56dc17672aae8390440f1ecc4e6f38db1aced5cd5c414bdbcc1fb84e9aadcd") -- DFF NT Akademeia Summer Uniform Appearance Set for Ace - DFF NT: Akademeia Summer Uniform Appearance Set for Ace デポ
addappid(1022511, 1, "b5136c8460730ae12ae8863968ee4f1bc2d46a3f4f158354eb9e7317ef4f1a1e") -- DFF NT Fusion Sword, Cloud Strifes EX weapon - DFF NT: Fusion Sword, Cloud Strife's EX weapon デポ
addappid(1022512, 1, "36a8bba4333e6c7a4c68a65a6e8cd28946b28b081e8ad8f9a6030245005f8123") -- DFF NT Overture, Lightnings EX weapon - DFF NT: Overture, Lightning's EX weapon デポ
addappid(1022513, 1, "ab7dfc6574da8282d364a0468a71e4860e6376a911f51145ec587abc730011af") -- DFF NT Crimson Blitz, Lightnings 4th Weapon - DFF NT: Crimson Blitz, Lightning's 4th Weapon デポ
addappid(1022514, 1, "b6d9b2c4f01ca996ac67c755c725f9c8ceff3c7c4024010c2d8f8882ad3917c5") -- DFF NT Truth Seeker, Yshtolas EX weapon - DFF NT: Truth Seeker, Y'shtola's EX weapon デポ
addappid(1056400, 1, "8d38abdf1909ef64dcb35080cf81821f3cb99c274e883f0dc5e2b5470858bd1f") -- DFF NT Zenos yae Galvus Starter Pack - DFF NT: Zenos yae Galvus Starter Pack デポ
addappid(1103740, 1, "807fbb14e8abafc8d083d29b87e166958b4136a6f5b33b1f0c9d8cd2ef05b22d") -- DFF NT Tifa Lockhart Starter Pack - DFF NT: Tifa Lockhart Starter Pack デポ
addappid(1103741, 1, "383512740098072bf14894d26e69f439d28a73cbd427c012d44341ffad503acb") -- DFF NT Leather Suit Appearance Set for Tifa Lockhart - DFF NT: Leather Suit Appearance Set for Tifa Lockhart デポ
addappid(1103742, 1, "a6218e78146c0e9167ba362ca6c9503d007fa32361ae4a9b7583f2de746baebe") -- DFF NT Platinum Fists, Tifa Lockharts 4th Weapon - DFF NT: Platinum Fists, Tifa Lockhart's 4th Weapon デポ
addappid(1103750, 1, "f30724dd9a18335e167f41aaa21bad8a222251f80a049d8858acd97ec7523a7b") -- DFF NT Legatus of the XIIth,  Zenos yae Galvuss Extra Appearance - DFF NT: Legatus of the XIIth,  Zenos yae Galvus's Extra Appearance デポ
addappid(1103751, 1, "a0f09030848aa20a9ef3ad7edc96a71e3ea5a4dacc7312a40270142309555bb1") -- DFF NT Imperial Court Attire Appearance Set for Zenos yae Galvus - DFF NT: Imperial Court Attire Appearance Set for Zenos yae Galvus デポ
addappid(1103752, 1, "ce06e979b2ac6b107d1e95fe6c412b3c4f77255c781a7107ac02da2fb715268f") -- DFF NT Omega Samurai Blade, Zenos yae Galvuss 4th Weapon - DFF NT: Omega Samurai Blade, Zenos yae Galvus's 4th Weapon デポ
addappid(1163400, 1, "d32f65cd7fba164030f93367ac175819b547a62a2a43e94321747bb1be6196c3") -- DFF NT Gabranth Starter Pack - DFF NT: Gabranth Starter Pack デポ
addappid(1163401, 1, "1ad7a857d87841c9c677e3a5c6c6477c75f370f8213b7a3205961ac7712c1d25") -- DFF NT The False General Appearance Set for Gabranth - DFF NT: The False General Appearance Set for Gabranth デポ
addappid(1163402, 1, "607bfe074df97f5d7c8988edc82a203de4df5f584dfd00abb82f0e2a1f2f9c4f") -- DFF NT Mace of ThemisRedemption, Gabranths 4th Weapon - DFF NT: Mace of Themis/Redemption, Gabranth's 4th Weapon デポ
addappid(1213330, 1, "c98868a1a7e6957aa0c70259cf3dfeb15ab7a8d196c24a3b8bd750dbe54e5ff0") -- DFF NT Ardyn Izunia Starter Pack - DFF NT: Ardyn Izunia Starter Pack デポ
addappid(1213331, 1, "57ce3c465db5fa9c9818e4d2dd6f2d9be899072b329c26cf38b9af18aa7f186f") -- DFF NT The Devotees Raiment Appearance Set for Ardyn Izunia - DFF NT: The Devotee's Raiment Appearance Set for Ardyn Izunia デポ
addappid(1213332, 1, "fa85b195570d49f6f1dd8707ba7ffcce3ecadcfc90cfcde7681f7ed90ac73a33") -- DFF NT Blade of Ruin, Ardyn Izunias 4th Weapon - DFF NT: Blade of Ruin, Ardyn Izunia's 4th Weapon デポ

