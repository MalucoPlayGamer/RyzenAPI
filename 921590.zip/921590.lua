-- Lua provided by RyzenAPI
-- Game: DISSIDIA FINAL FANTASY NT Free Edition

-- MAIN APPLICATION
addappid(921590)

-- MAIN APP DEPOTS / PACKAGES
addappid(921591, 1, "9a4019318c2ce18690c2586fb626a05ae3b0e18dfac9a28863cae2bacbfb8218")

