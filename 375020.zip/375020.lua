-- Lua provided by RyzenAPI
-- Game: addappid(375020)

-- MAIN APPLICATION
addappid(375020)

-- MAIN APP DEPOTS / PACKAGES
addappid(375021, 1, "1c5cb3ebfe1c41ddf73f64fb763d977fbec90df860afbc134126335471a0ca5b")
