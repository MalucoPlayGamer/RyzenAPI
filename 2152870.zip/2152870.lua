-- Lua provided by SkyAPI 
-- Game: GOHOME Demo
addappid(2152870)
addappid(2152871, 1, "8072231b880406d98f87f0e4c4a67a4890cfe837118ab07193ac67790bacd145")
