-- Lua provided by RyzenAPI
-- Game: GOHOME Demo

-- MAIN APPLICATION
addappid(2152870)
-- Game: addappid(2152870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152871, 1, "8072231b880406d98f87f0e4c4a67a4890cfe837118ab07193ac67790bacd145")
