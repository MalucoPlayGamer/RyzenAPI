-- Lua provided by RyzenAPI
-- Game: Secret Relationship with Subordinate's Cocky Gal Wife

-- MAIN APPLICATION
addappid(2506410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506411, 1, "1ffa09c2bf1a761f2bdedeaeb15b7c6ccdeb137e651dfc4029c4f6e7fa9f56fe")

