-- Lua provided by RyzenAPI
-- Game: The Last Shape

-- MAIN APPLICATION
addappid(1757090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757091, 1, "1eebd72102b960850480ab1f280e769d926d6849edf31a7fb018520892e54bc2")
