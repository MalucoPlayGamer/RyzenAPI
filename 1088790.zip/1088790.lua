-- Lua provided by RyzenAPI
-- Game: Rebel Inc: Escalation

-- MAIN APPLICATION
addappid(1088790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088791, 1, "a04085dbd60c4f3505ae81ad1701e9ab8a9804184fafa9c8e31cc160f0315810")
addappid(1088792, 1, "091b2d5ce532a4f270ec898cefed77d63be6be8dfeefabee852eb02bd821990d")
addappid(1088793, 1, "1491e889a9ffaa46a416e62ac5e5a4ce4a87eedca6e622f7c258591c525e7bb4")
addappid(1088794, 1, "0f8ee2e16b509a3239228ab2dea38122c302f625f315b813142c707259f31c06")

