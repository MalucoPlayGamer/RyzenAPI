-- Lua provided by RyzenAPI
-- Game: Super Kakuro - Cross Sums

-- MAIN APPLICATION
addappid(1781040)
-- Game: addappid(1781040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781041, 1, "22a1398d77c0063c1a82e5e41f32b4b4453f2d3723d9f07614791253712e7ef7")
