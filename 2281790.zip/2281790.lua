-- Lua provided by RyzenAPI
-- Game: 視靈

-- MAIN APPLICATION
addappid(2281790)
-- Game: addappid(2281790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281791, 1, "4eb169cd96168d8c5b97c3e18e843724d2d0ae6a69c50444206449931e82429c")
