-- Lua provided by RyzenAPI
-- Game: AppID 316830

-- MAIN APPLICATION
addappid(316830)

-- MAIN APP DEPOTS / PACKAGES
addappid(316831, 1, "9f1297554423afbe89c212a2c43c4072f6d35739aa4cc5983d6ad2ee1a9a3816")
addappid(316833, 1, "149958f2eb614be3f4793ff2ec97766a2cfcf841e196a004cb44c6cdc668a463")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(318830)
