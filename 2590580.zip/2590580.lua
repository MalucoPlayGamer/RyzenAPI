-- Lua provided by RyzenAPI
-- Game: 3D Chess Online

-- MAIN APPLICATION
addappid(2590580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590581, 1, "9697ca5366c532597d753d5c570efcc848cb44677feaba3b9f60cc573185f1c2")
