-- Lua provided by RyzenAPI
-- Game: 1449080

-- MAIN APPLICATION
addappid(1449080)
-- Game: addappid(1449080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449081, 1, "c0a3d03b40e7ae21314c3f02251407a3be9393bea8d44f57110c9d76b35ac3fe")
