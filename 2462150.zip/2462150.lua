-- Lua provided by RyzenAPI
-- Game: The Richmond Rut (In Search of Fenton)

-- MAIN APPLICATION
addappid(2462150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462151, 1, "2379bef342fbaa50063609c65b6fa8d6f855ee1719203dda5080d24bea58bb1b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
