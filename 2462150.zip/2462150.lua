-- Lua provided by RyzenAPI
-- Game: The Richmond Rut (In Search of Fenton)

-- MAIN APPLICATION
addappid(2462150)
-- Game: addappid(2462150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462151, 1, "2379bef342fbaa50063609c65b6fa8d6f855ee1719203dda5080d24bea58bb1b")
