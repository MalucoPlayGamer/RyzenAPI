-- Lua provided by RyzenAPI 
-- Game: A Date with Death
addappid(2415010)
addappid(2415011, 1, "613d651db4abc6681f394e414aef667e7812c245238c23abd9aa9daf57351de4")
addappid(2696090, 0, "e642f64bfab46ea985ab05bbe020bdae3514198c7dfd9bc20566df49cbf63d8d")
addappid(2799720, 0, "0d547f332ea9a77f21f5eec002b79ee885c23e29cbbb6888f7ea1de557bd6528")
