-- Lua provided by RyzenAPI
-- Game: Game: AppID 1864210

-- MAIN APPLICATION
addappid(1864210)
-- Game: addappid(1864210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864211, 1, "cd954114116c6e78d1ac2fbf290de0c52504f2dc81cfa5dc188e3c4342b418cb")
