-- Lua provided by RyzenAPI
-- Game: Tofas Sahin: Online Car Driving

-- MAIN APPLICATION
addappid(2304680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304681, 1, "a5568944096039ca0c9961618d2954db92cfc74974a397cf9abbcb5e1ef30fd2")
