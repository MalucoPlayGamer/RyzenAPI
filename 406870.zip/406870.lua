-- Lua provided by RyzenAPI
-- Game: addappid(406870)

-- MAIN APPLICATION
addappid(406870)

-- MAIN APP DEPOTS / PACKAGES
addappid(406871, 1, "a570623bf46fc61a6450a8b5263c61723fdfa2f395f9a2467894a3b8cf4eaa1a")
