-- Lua provided by RyzenAPI
-- Game: Mushihimesama OST

-- MAIN APPLICATION
addappid(387921)
-- Game: addappid(387921)

-- MAIN APP DEPOTS / PACKAGES
addappid(387921,0,"3c80f25c7cf6fd573f7662676b8865921a01a85d0dccffccbfca45f2b50223d8")
addappid(1288120,0,"dc1c6f5f771c10129fb5ecc1874b4c64c668162b937bab7a594600b574c06159")
