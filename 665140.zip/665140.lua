-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(665140)
addappid(665141)
addappid(665143)
-- Game: addappid(665140)

-- MAIN APP DEPOTS / PACKAGES
addappid(665142,0,"652328e3ff0c3f4db811e9e46501f1184e8f083d24119727420599218937babb")
