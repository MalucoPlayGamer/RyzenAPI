-- Lua provided by RyzenAPI
-- Game: Radical Relocation Demo

-- MAIN APPLICATION
addappid(1325600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325601, 1, "15a2a337e753b0b60abb7e01feea53c0b2cca4ab82ce64a063686639e73deb94")
