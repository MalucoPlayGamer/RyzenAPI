-- Lua provided by RyzenAPI
-- Game: 1729700

-- MAIN APPLICATION
addappid(1729700)
-- Game: addappid(1729700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729701, 1, "c8e614fe3fee910e50f93bd8c55f42775eb130c770c262c2e35df05692e6da9b")
