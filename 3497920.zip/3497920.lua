-- Lua provided by SkyAPI 
-- Game: Maze of Perdition
addappid(3497920)
addappid(3497921, 1, "e41ccd2d06af111251fff8922fc6753c5856b50841885b1ae7e4123b6be047fa")
