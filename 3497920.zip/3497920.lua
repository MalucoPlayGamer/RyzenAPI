-- Lua provided by RyzenAPI
-- Game: Game: Maze of Perdition

-- MAIN APPLICATION
addappid(3497920)
-- Game: addappid(3497920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3497921, 1, "e41ccd2d06af111251fff8922fc6753c5856b50841885b1ae7e4123b6be047fa")
