-- Lua provided by RyzenAPI
-- Game: Egression

-- MAIN APPLICATION
addappid(1384940)
-- Game: addappid(1384940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384942,0,"eec404155c8415e28380708029b2715800506f1b10a4521cb4a6ec5b5b9bb9ca")
