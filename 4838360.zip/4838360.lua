-- Lua provided by RyzenAPI
-- Game: Construction Company

-- MAIN APP DEPOTS / PACKAGES
addappid(4838360, 1, "ee374e8fe599b5e5a3e0aff7467023c13517b979019101777aadc81a300066f2") -- Construction Company
addappid(4838361, 1, "25ff9031e893fbf293f9635707467d32177c150050d79a649fa5774f867ce597") -- Depot 4838361
