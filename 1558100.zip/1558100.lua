-- Lua provided by RyzenAPI
-- Game: addappid(1558100)

-- MAIN APPLICATION
addappid(1558100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558101, 1, "304a8fca886d457c4effd6f7f6a9eec5d3f2d992f89f94ed3e319191c0ba68f6")
