-- Lua provided by RyzenAPI
-- Game: PixPhys

-- MAIN APPLICATION
addappid(1558100)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1558101, 1, "304a8fca886d457c4effd6f7f6a9eec5d3f2d992f89f94ed3e319191c0ba68f6")

