-- Lua provided by SkyAPI 
-- Game: The Sisters - Party of the Year
addappid(1502540)
addappid(1502541, 1, "051373540d43428fff673bc2ed9cde254db60277c4cec9915263ba68d0a48e83")
