-- Lua provided by RyzenAPI
-- Game: addappid(1502540)

-- MAIN APPLICATION
addappid(1502540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502541, 1, "051373540d43428fff673bc2ed9cde254db60277c4cec9915263ba68d0a48e83")
