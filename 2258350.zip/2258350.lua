-- Lua provided by RyzenAPI
-- Game: Alive

-- MAIN APPLICATION
addappid(2258350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258351, 1, "aaefcfe66df816e84fd7d9d97340f9d58929dcc6e81c477dd9c0e259867f250d")
addappid(2406300, 0, "eaf7839c9d2610993b5a7ccf1536034e7e49e537a174751cfc9f70633ff42d18")

