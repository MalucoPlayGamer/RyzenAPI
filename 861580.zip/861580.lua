-- Lua provided by RyzenAPI
-- Game: Delve

-- MAIN APPLICATION
addappid(861580)

-- MAIN APP DEPOTS / PACKAGES
addappid(861581, 1, "223b72c4fef0969e289e91d0c87a3c9e12457b569fbf1733b24e4acdb987aece")

