-- Lua provided by RyzenAPI
-- Game: Candy Arkanoid

-- MAIN APPLICATION
addappid(2257580)
addappid(2257583)
-- Game: addappid(2257580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257582,0,"a7824ee88ddb5a9e21a9d3ba21ead5c37ed78d4053274482cdfe4cdee083b19c")
