-- Lua provided by RyzenAPI
-- Game: AppID 1790460

-- MAIN APPLICATION
addappid(1790460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1790461, 1, "923ed8da01ec58c82a183c869b88459ac820b3d939a84a69fdf0b7de2f71e72b")
addappid(1790462, 1, "f6d3e8ef9bba85303fcedb8298bdd93ab7673a8ee61a73b36706a0eb60c511f0")

