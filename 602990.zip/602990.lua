-- Lua provided by RyzenAPI
-- Game: addappid(602990)

-- MAIN APPLICATION
addappid(602990)

-- MAIN APP DEPOTS / PACKAGES
addappid(602991, 1, "e7c0aed012aea9fabe7c960e72f35f7718e04a334fd8ae37a5af7281583f9948")
