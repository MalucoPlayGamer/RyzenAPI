-- Lua provided by RyzenAPI
-- Game: 2886720

-- MAIN APPLICATION
addappid(2886720)
-- Game: addappid(2886720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2886721, 1, "ac0a48bac02189bb4ecaa51e9f467768586eb1f765034fcc3c2d92ccdbeb4472")
addappid(2960780, 0, "c80f53fd70bad423700673a5c713102637c98e16c61fccee65bf7c5687944b5a")
