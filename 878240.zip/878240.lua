-- Lua provided by RyzenAPI
-- Game: Adva-lines

-- MAIN APPLICATION
addappid(878240)

-- MAIN APP DEPOTS / PACKAGES
addappid(878241, 1, "90feee9b37e5b4526e638673b9ef17bfd7f03b9025f71c02339ce33cce33d4c5")
addappid(878242, 1, "629580860a9930e01dba139e94410baef6b59e67cc85aab90ea2cdb25b361f0c")
