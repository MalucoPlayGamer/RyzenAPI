-- Lua provided by RyzenAPI
-- Game: Ninja Rift

-- MAIN APPLICATION
addappid(3095380)

