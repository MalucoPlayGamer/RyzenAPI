-- Lua provided by RyzenAPI
-- Game: 1796360

-- MAIN APPLICATION
addappid(1796360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796360,0,"16ca52911ed4496a71ca45c382ba3b66f8b9ab2f5fbb5f576efdf51ee018c5f6")

