-- Lua provided by RyzenAPI
-- Game: 1779760

-- MAIN APPLICATION
addappid(1779760)
-- Game: addappid(1779760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779762,0,"418b3ed10be1429623605f46ed0ea135be1d2249421cb4c9df3502ee15fc2734")
