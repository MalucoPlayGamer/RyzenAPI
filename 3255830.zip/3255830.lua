-- Lua provided by RyzenAPI
-- Game: Milf Selena and the Dungeon of Magic Stones

-- MAIN APPLICATION
addappid(3255830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3255831, 1, "03cefda2182dea4a98c95c90c56bcec2c2aaf373feb8030ef9a4b46147a587be")
