-- Lua provided by RyzenAPI
-- Game: AppID 2233190

-- MAIN APPLICATION
addappid(2233190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233191, 1, "43adecfabcd119318e7b4ff97b4bd61db2cc955fec7bcd588f00ebeef0459fe2")
