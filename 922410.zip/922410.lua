-- Lua provided by RyzenAPI 
-- Game: DinoKnights
addappid(922410)
addappid(922411, 1, "663b165226da37b67d9733594ca72f8f631fdabf794307a7af5c89b8d4a6b5b7")
