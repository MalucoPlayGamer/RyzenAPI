-- Lua provided by RyzenAPI
-- Game: addappid(1667440)

-- MAIN APPLICATION
addappid(1667440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667441, 1, "13747b61bf026eeabe76b038f9031a65624e6a2438e8f5b5e86bc8bbe93dae46")
