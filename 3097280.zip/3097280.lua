-- Lua provided by RyzenAPI
-- Game: Sweet Hospital

-- MAIN APPLICATION
addappid(3097280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097281, 1, "d2394330c3a71193cbeb66ddf9b7e3a5bffbbaabe9d5dffeecbc67c89e46e325")

