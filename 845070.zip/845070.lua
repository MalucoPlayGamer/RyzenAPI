-- Lua provided by RyzenAPI
-- Game: addappid(845070)

-- MAIN APPLICATION
addappid(845070)

-- MAIN APP DEPOTS / PACKAGES
addappid(845071, 1, "e1570d809e9d1fe1bcf65f2b2230d737d3aa5448e9b3863b9f7c5756cb82c241")
