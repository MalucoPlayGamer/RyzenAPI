-- Lua provided by SkyAPI 
-- Game: The Awesome Adventures of Captain Spirit
addappid(845070)
addappid(845071, 1, "e1570d809e9d1fe1bcf65f2b2230d737d3aa5448e9b3863b9f7c5756cb82c241")
