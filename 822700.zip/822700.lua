-- Lua provided by RyzenAPI
-- Game: Beer and Skittls VR

-- MAIN APPLICATION
addappid(822700)

-- MAIN APP DEPOTS / PACKAGES
addappid(822701, 1, "0c9cd62ee95eaae419d963d2f249b64e8d41d0f7dbec8fee429ce415527e1a3f")
