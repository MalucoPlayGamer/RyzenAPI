-- Lua provided by RyzenAPI
-- Game: Kanpeki Demo

-- MAIN APPLICATION
addappid(1987390)
-- Game: addappid(1987390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987391, 1, "05e38f83d44aee59171251186d007a131e21e20ad2306f0da1698772223588c6")
