-- Lua provided by RyzenAPI
-- Game: Avorion

-- MAIN APPLICATION
addappid(445220)

-- MAIN APP DEPOTS / PACKAGES
addappid(445221, 1, "55ccc086bea16d58746ae8b1113bd05122353b45ec9d1b4862b1427930188cfc")
addappid(445222, 1, "dd56ad52ed455cbfa5b624888c0e1da46b020933af789188920cf3d9ba62da7d")
addappid(445223, 1, "d5c6126cd10bb77be40ab9f78024206a487acd8577976c0c493d572fc81e9ac4")
addappid(445224, 1, "38ce0691103155f7adc69b3012d968b547659e6d5c01d72eca9fac74472f82e4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1357160)
addappid(1905970)
addappid(2591780)
