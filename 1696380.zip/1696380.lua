-- Lua provided by RyzenAPI
-- Game: Mr.Knight

-- MAIN APPLICATION
addappid(1696380)
-- Game: addappid(1696380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696381, 1, "2a0bb3b323d51ab4c3ef8dd024d097bd47b69bf914db3e39d6187df17bfb32ef")
