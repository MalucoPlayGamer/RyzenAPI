-- Lua provided by SkyAPI 
-- Game: Mr.Knight
addappid(1696380)
addappid(1696381, 1, "2a0bb3b323d51ab4c3ef8dd024d097bd47b69bf914db3e39d6187df17bfb32ef")
