-- Lua provided by RyzenAPI
-- Game: Mr.Knight

-- MAIN APPLICATION
addappid(1696380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696381, 1, "2a0bb3b323d51ab4c3ef8dd024d097bd47b69bf914db3e39d6187df17bfb32ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
