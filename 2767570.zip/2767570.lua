-- Lua provided by RyzenAPI
-- Game: Satellite engineer

-- MAIN APPLICATION
addappid(2767570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767571, 1, "e9dd6636987148f05e621fc572568d58c1ece48642eec6f0cfc6f228120a74f5")

