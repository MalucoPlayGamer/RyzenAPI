-- Lua provided by RyzenAPI 
-- Game: Vampire Survivors: Tides of the Foscari
addappid(2313550)
addappid(2313551, 1, "adde095c43621ed1f47b4d76bc65191b5bb3cf09a92e70cd11c97c46350fc378")
addappid(2313552, 1, "a7b5b861ccf517e0c14ce63f873786764694c151a527fe75ec81e02d2c4078a3")
addappid(2313553, 1, "da82ac8729e1fe259dfdd0201ec6c0844448797142f1a16ad4161057eb8666be")
