-- Lua provided by RyzenAPI
-- Game: AppID 2653080

-- MAIN APPLICATION
addappid(2653080)
addappid(2663090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653081, 1, "cd7132ad3563be4f1d99b98ce08c737c0cba518ebc68970a1f8e32e05fbcce8a")

