-- Lua provided by RyzenAPI 
-- Game: AppID 3600350
addappid(3600350)
addappid(3600351, 1, "5134397291f76caf0c4ca4fc445d9656d51a0f395e8ca52e138842ababc05214")
