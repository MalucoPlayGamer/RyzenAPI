-- Lua provided by RyzenAPI 
-- Game: Airport Administrator Simulator
addappid(1974310)
addappid(1974311, 1, "6de0424f37d65fb0748404852b42871a0b01a262e12616680e84de660e297213")
