-- Lua provided by RyzenAPI
-- Game: Airport Administrator Simulator

-- MAIN APPLICATION
addappid(1974310)
-- Game: addappid(1974310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1974311, 1, "6de0424f37d65fb0748404852b42871a0b01a262e12616680e84de660e297213")
