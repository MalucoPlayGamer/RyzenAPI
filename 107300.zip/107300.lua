-- Lua provided by RyzenAPI
-- Game: Breath of Death VII

-- MAIN APPLICATION
addappid(107300)

-- MAIN APP DEPOTS / PACKAGES
addappid(107301, 1, "31c5809f43b6b4e7f0a011928a82a117fce7ffb56bf2f0f67e2b878fc668e80a")
