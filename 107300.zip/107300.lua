-- Lua provided by SkyAPI 
-- Game: Breath of Death VII
addappid(107300)
addappid(107301, 1, "31c5809f43b6b4e7f0a011928a82a117fce7ffb56bf2f0f67e2b878fc668e80a")
