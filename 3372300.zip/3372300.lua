-- Lua provided by RyzenAPI
-- Game: Game: DEATH UNTO DAWN: FINAL FANTASY XIV Original Soundtrack

-- MAIN APPLICATION
addappid(3372300)
-- Game: addappid(3372300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372301, 1, "f4e83bdab52983439158ed3757c976f72bd0857222842bfa797d808715e4ea04")
