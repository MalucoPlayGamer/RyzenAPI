-- Lua provided by RyzenAPI
-- Game: addappid(1750740)

-- MAIN APPLICATION
addappid(1750740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750741, 1, "42afce852c588676f4d42c9dfb753d6c0f9bf57021a30dfed83ce611409457da")
