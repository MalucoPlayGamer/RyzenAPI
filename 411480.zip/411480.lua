-- Lua provided by RyzenAPI
-- Game: BATTLECREW Space Pirates

-- MAIN APPLICATION
addappid(411480)
addappid(653090)
addappid(658860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(411481, 1, "cada994e419c3db0dfb475b9f3fe13610f7ec5dda0f219f14c53c1d4e5b480ab")

