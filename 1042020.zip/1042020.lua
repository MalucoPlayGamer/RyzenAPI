-- Lua provided by RyzenAPI
-- Game: Game: AppID 1042020

-- MAIN APPLICATION
addappid(1042020)
-- Game: addappid(1042020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042021, 1, "bdd0c19a9dbda3bd14d662fa042aaa4157e5403a9b4d75817d9988c8fd8f0276")
addappid(1042022, 1, "9748096f90dc38fc06fc89c9556b09560cf1403d3054ad55fa592cc1069b5fc8")
