-- Lua provided by RyzenAPI
-- Game: addappid(306830)

-- MAIN APPLICATION
addappid(306830)

-- MAIN APP DEPOTS / PACKAGES
addappid(306831, 1, "fe9633e84ec0ed3e33add17026ee4301c0d774c009fe7c4445f2862112300a3c")
