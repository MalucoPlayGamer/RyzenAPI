-- Lua provided by RyzenAPI
-- Game: 1949980

-- MAIN APPLICATION
addappid(1949980)
addappid(1949983)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949982,0,"fc9fa0a58dd5e86ab21c4c3aa5dd53d397841e9b97140498a95dcb329204bc92")

