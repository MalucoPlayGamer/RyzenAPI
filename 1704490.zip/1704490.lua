-- Lua provided by RyzenAPI 
-- Game: Inferno
addappid(1704490)
addappid(1704491, 1, "3f3bf1c648833d52b44a5aa0bf6ff311bee8414c6dd0ec9dc36d3c6177daa255")
