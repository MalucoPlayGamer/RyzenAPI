-- Lua provided by RyzenAPI
-- Game: Inferno

-- MAIN APPLICATION
addappid(1704490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704491, 1, "3f3bf1c648833d52b44a5aa0bf6ff311bee8414c6dd0ec9dc36d3c6177daa255")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
