-- Lua provided by RyzenAPI
-- Game: Magic Potion Explorer

-- MAIN APPLICATION
addappid(442890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(442891, 1, "9122fe267cd963a4d09712244b38451a86c5592c1a2fd1714ab6b98c6388b5cb")
addappid(442892, 1, "0e62e5afd84c53a4355658b71d192312024be7a3c348cb5b36e06b879fc75348")

