-- Lua provided by RyzenAPI
-- Game: A Shot in the Dark - Walkthrough & Guide

-- MAIN APPLICATION
addappid(2707830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707830,0,"b8cd2797ed3df83f6d7820ef091f3c8611a6ba185df9548b61e5c07d3fe6e68e")

