-- Lua provided by RyzenAPI
-- Game: DOLL INC

-- MAIN APPLICATION
addappid(3722760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3722761, 1, "b81e26766e0d775d8304402f7463f38f94ac18208d7df146553487c3ad3c49b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
