-- Lua provided by RyzenAPI
-- Game: Game: DOLL INC

-- MAIN APPLICATION
addappid(3722760)
-- Game: addappid(3722760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3722761, 1, "b81e26766e0d775d8304402f7463f38f94ac18208d7df146553487c3ad3c49b7")
