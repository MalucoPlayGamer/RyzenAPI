-- Lua provided by RyzenAPI
-- Game: Dead in Antares

-- MAIN APPLICATION
addappid(2511800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511801,0,"fd5fd833afbe1b8612a2865bb8ca09f4a32af0a36e661a3c38f2bc9712e59764")

