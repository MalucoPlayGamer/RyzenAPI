-- Lua provided by SkyAPI 
-- Game: Chaperon Demo
addappid(3286690)
addappid(3286691, 1, "e835cf81474532ab772514b88183209c695c39a9c2b10c99bd2dad4560873e5f")
