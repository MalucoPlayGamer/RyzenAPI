-- Lua provided by RyzenAPI
-- Game: addappid(3587260)

-- MAIN APPLICATION
addappid(3587260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3587261, 1, "e4ab09e8b79b76f7a1bf9d97096306bacfbcc0249799901c628abe5b5b955b90")
