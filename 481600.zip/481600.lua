-- Lua provided by RyzenAPI
-- Game: AppID 481600

-- MAIN APPLICATION
addappid(481600)
-- Game: addappid(481600)

-- MAIN APP DEPOTS / PACKAGES
addappid(481601, 1, "6282dc484aa48aa997c80937392e83f9f39b7f4e8f0ced975fcc7cd0f64eb09e")
