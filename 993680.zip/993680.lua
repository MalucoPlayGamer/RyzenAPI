-- Lua provided by RyzenAPI
-- Game: 东方驾考模拟器|Chinese Driving License Test

-- MAIN APPLICATION
addappid(993680)

-- MAIN APP DEPOTS / PACKAGES
addappid(993681, 1, "8daaf178c1c86965519d3a86f4dc48e872ba1f32600ec9f28362a91590b12487")
addappid(993682, 1, "2915672586e1e0b04f069d709ed9a2bda2d0aeeecdf9ddd23a368eb12e65bfaa")
