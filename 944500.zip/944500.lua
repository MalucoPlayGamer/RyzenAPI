-- Lua provided by RyzenAPI
-- Game: Game: AppID 944500

-- MAIN APPLICATION
addappid(944500)
-- Game: addappid(944500)

-- MAIN APP DEPOTS / PACKAGES
addappid(944501, 1, "b028271a976673870384fb39aa85be40a96d1e4ba3d8d896923959152d51180a")
