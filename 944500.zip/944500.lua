-- Lua provided by RyzenAPI
-- Game: AppID 944500

-- MAIN APPLICATION
addappid(944500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(944501, 1, "b028271a976673870384fb39aa85be40a96d1e4ba3d8d896923959152d51180a")

