-- Lua provided by SkyAPI 
-- Game: AppID 944500
addappid(944500)
addappid(944501, 1, "b028271a976673870384fb39aa85be40a96d1e4ba3d8d896923959152d51180a")
