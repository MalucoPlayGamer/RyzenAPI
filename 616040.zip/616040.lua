-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(616040)

-- MAIN APP DEPOTS / PACKAGES
addappid(616042,0,"e257a17faea18307e917108d1f654769fa16637a20e35adb1d0251304e10d6a0")
addappid(616043,0,"58e8ba7c41723ec33d86a1b4b48adc9a5ce9c923b29636ccafb3e51249b7f774")
addappid(616044,0,"73a6cff8abebefcd10a5d61235b641431e8738a444ec945033aff41b2d1de32b")

