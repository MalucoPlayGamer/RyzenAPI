-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(616040)
addappid(616042,0,"e257a17faea18307e917108d1f654769fa16637a20e35adb1d0251304e10d6a0")
-- setManifestid(616042,"8470022673919338267")
addappid(616043,0,"58e8ba7c41723ec33d86a1b4b48adc9a5ce9c923b29636ccafb3e51249b7f774")
-- setManifestid(616043,"6127740696817307708")
addappid(616044,0,"73a6cff8abebefcd10a5d61235b641431e8738a444ec945033aff41b2d1de32b")
-- setManifestid(616044,"5153821181632016304")