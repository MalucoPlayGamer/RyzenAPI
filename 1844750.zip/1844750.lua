-- Lua provided by RyzenAPI
-- Game: addappid(1844750)

-- MAIN APPLICATION
addappid(1844750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844751, 1, "29c3a4c9258c449c25f4ee8cf4385232c7b6e721fba151b2c96229eb13f8a964")
