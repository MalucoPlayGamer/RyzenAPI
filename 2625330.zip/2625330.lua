-- Lua provided by RyzenAPI
-- Game: Game: UpWorld - Multiplayer

-- MAIN APPLICATION
addappid(2625330)
-- Game: addappid(2625330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625331, 1, "0229317411d4db191edbad8683d99e653762438c97cfc8a13c6afc4a41a8bde4")
