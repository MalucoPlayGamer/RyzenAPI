-- Lua provided by RyzenAPI
-- Game: Game: 52赫兹 Demo

-- MAIN APPLICATION
addappid(2980040)
-- Game: addappid(2980040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2980041, 1, "1049c50602baed7a0c2a767c42b8bd4140d2b0c3608c9f6907f9c446bf4520ac")
