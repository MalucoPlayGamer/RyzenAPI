-- Lua provided by RyzenAPI
-- Game: Moékuri: Adorable + Tactical SRPG

-- MAIN APPLICATION
addappid(529160)

-- MAIN APP DEPOTS / PACKAGES
addappid(529161, 1, "ccada32be07bbb339c491d5d8241e175d0bd84d96d9c39d48f11988e5109289a")
addappid(529162, 1, "9f7b8c78b4b934eef68a6c3424f80b8b13f2ac6e4bc7b005d8c410e3dddf96d5")
addappid(529163, 1, "e9ba9f24c5d5f99c57287529026a79654305b7af9618b7c74d3e4f8a7d047079")
addappid(529164, 1, "c86c00c78ac709e004eb1506d10a5b0967be5a2cb4680e5e1ce6a542bdf3f987")
