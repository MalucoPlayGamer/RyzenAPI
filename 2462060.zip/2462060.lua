-- Lua provided by RyzenAPI
-- Game: Game: Graveyard Gunslingers

-- MAIN APPLICATION
addappid(2462060)
-- Game: addappid(2462060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462061, 1, "e63dbdfbdf3072159788b8a50467771e5f72e8447d73185a29169f3c1c68445d")
