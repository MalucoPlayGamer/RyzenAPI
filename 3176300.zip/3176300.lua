-- Lua provided by RyzenAPI
-- Game: Newlywed female teacher Miri

-- MAIN APPLICATION
addappid(3176300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176301, 1, "0bd4586e15636864dc0c76dd9bb04429aa2eeabdbe5af0f692cb34b40e1bd665")
