-- Lua provided by RyzenAPI
-- Game: Swipe Right for Sugar Mama Sensei

-- MAIN APPLICATION
addappid(3528490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3528491, 1, "8c677c9138fdc8975b87b443690800448c2c012e7f7045d4491f01a4b7bf0f5d")
