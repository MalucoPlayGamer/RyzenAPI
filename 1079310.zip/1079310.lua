-- Lua provided by RyzenAPI
-- Game: Elemental Girls

-- MAIN APPLICATION
addappid(1079310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079311, 1, "e63607a594600f385dc1b69aced1ccdf2a1448d1923a5231c52c71f4d55ab2b2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1079920)
addappid(1080710)
