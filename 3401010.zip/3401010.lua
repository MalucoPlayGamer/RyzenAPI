-- Lua provided by SkyAPI 
-- Game: Car Mechanic Shop Simulator Demo
addappid(3401010)
addappid(3401011, 1, "6bf8a7f276f9fd44ecb2cf5c9e9d48c536338083eaa43c5c8844add9f581bbed")
