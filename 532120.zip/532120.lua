-- Lua provided by RyzenAPI
-- Game: AppID 532120

-- MAIN APPLICATION
addappid(532120)
-- Game: addappid(532120)

-- MAIN APP DEPOTS / PACKAGES
addappid(532121, 1, "3387de562bb3386a17ad5279fc9404a36a74f25906c757fc92d1b5b521479bab")
