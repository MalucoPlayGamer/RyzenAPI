-- Lua provided by RyzenAPI
-- Game: 1164440

-- MAIN APPLICATION
addappid(1164440)
-- Game: addappid(1164440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164441, 1, "0bebf1d244da7b76a86011ae7dde136d4147f8250c9042b0e189a1eb260cacba")
