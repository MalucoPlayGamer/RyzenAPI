-- Lua provided by SkyAPI 
-- Game: AppID 1164440
addappid(1164440)
addappid(1164441, 1, "0bebf1d244da7b76a86011ae7dde136d4147f8250c9042b0e189a1eb260cacba")
