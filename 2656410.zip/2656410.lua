-- Lua provided by SkyAPI 
-- Game: SCP: Bloodwater
addappid(2656410)
addappid(2656411, 1, "0cf36082a77bb954183b0479435127cf69a97c47a1a18010feab90dcf1e788ed")
