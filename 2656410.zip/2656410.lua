-- Lua provided by RyzenAPI
-- Game: addappid(2656410)

-- MAIN APPLICATION
addappid(2656410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656411, 1, "0cf36082a77bb954183b0479435127cf69a97c47a1a18010feab90dcf1e788ed")
