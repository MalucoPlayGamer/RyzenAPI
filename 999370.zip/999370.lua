-- Lua provided by RyzenAPI
-- Game: Agent A: A puzzle in disguise Demo

-- MAIN APPLICATION
addappid(999370)
-- Game: addappid(999370)

-- MAIN APP DEPOTS / PACKAGES
addappid(999371, 1, "755a677085c07eab317acaf5c15fff55d0ab0ff5ab9d55605959f2a9b94ae9db")
