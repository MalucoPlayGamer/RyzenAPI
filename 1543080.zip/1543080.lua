-- Lua provided by RyzenAPI 
-- Game: AppID 1543080
addappid(1543080)
addappid(1543081, 1, "7348c2169f4a8671a53c389e7d5b331788d40d4b17c28930769c5f6f8c4a070f")
addappid(1574650, 0, "f1abc5c677efd7ba4e57c482057677a7c5ee3b02876caa8cc122d1f886ad09e7")
