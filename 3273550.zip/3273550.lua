-- Lua provided by RyzenAPI
-- Game: AppID 3273550

-- MAIN APPLICATION
addappid(3273550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3273551, 1, "ff9bd1cc80ae8a8f5b9b95b319bf8ec06316150b77ae09245ff757c6bddb97fc")

