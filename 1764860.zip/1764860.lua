-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1764860)
addappid(1764866)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764869,0,"46db5e60c9ee4874a7e6a73a8e062bb832a6a39930964232a38400c18a4a2ce4")
