-- Lua provided by SkyAPI 
-- Game: DESTROY Simulator
addappid(1869890)
addappid(1869891, 1, "ed5c2d1dbb29cd1d4667e730d89f7cfbe3c3e74a90d40f255354e367385cccc6")
