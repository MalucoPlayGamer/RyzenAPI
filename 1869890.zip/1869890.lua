-- Lua provided by RyzenAPI
-- Game: DESTROY Simulator

-- MAIN APPLICATION
addappid(1869890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869891, 1, "ed5c2d1dbb29cd1d4667e730d89f7cfbe3c3e74a90d40f255354e367385cccc6")
