-- Lua provided by RyzenAPI
-- Game: Game: Romestead

-- MAIN APPLICATION
addappid(1805320)
-- Game: addappid(1805320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805321, 1, "ea667c299933261c2a9c4bc7cacdfb85edcacd2ace53d6724caf767ba25ee827")
