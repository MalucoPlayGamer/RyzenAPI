-- Lua provided by RyzenAPI
-- Game: Game: Milking Mira!

-- MAIN APPLICATION
addappid(3049460)
-- Game: addappid(3049460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3049461, 1, "d861a99dfd5210f1b9478097fd7e737640e1500b28485d9dae567387720882ab")
addappid(3320570, 0, "9aa73b7e3eba8229096c9ec01cfd9206d0dd1f1ec3ebde0724f0b1f231e45588")
