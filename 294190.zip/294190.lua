-- Lua provided by RyzenAPI 
-- Game: A-Men 2
addappid(294190)
addappid(294191, 1, "dc902fa3902c91426c569ae9c5ccb50d2771ec69620915de2987bfccb8ac55a1")
