-- Lua provided by RyzenAPI
-- Game: Wizordum

-- MAIN APPLICATION
addappid(1715590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715591, 1, "8568263432c963194015f895f9a5eea7abea645f6c010f408eff7f063af3a312")
