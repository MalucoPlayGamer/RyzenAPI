-- 967240's Lua and Manifest Created by Hubcap Manifest
-- MONKEY KING: HERO IS BACK
-- Created: September 30, 2025 at 01:27:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 15
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(967240) -- MONKEY KING: HERO IS BACK
-- MAIN APP DEPOTS
addappid(967241, 1, "2202eb5ce917d02aebfc672e071df05ef84f56435460eda8794b8232681f43c5") -- Monkey King: Hero is Back Content
setManifestid(967241, "1262329886933295616", 18759060344)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- MONKEY KING HERO IS BACK - China OST (AppID: 1163430)
addappid(1163430)
addtoken(1163430, "8566577845857355545")
addappid(1163431, 1, "8c45163dab62960a5e4f5e1a3444f1fe0e125a4f7b0ba3e598473add2aafdd48") -- MONKEY KING HERO IS BACK - China OST - Depot 1163431
setManifestid(1163431, "775292685684019320", 847607416)
-- MONKEY KING HERO IS BACK - Pre Wallpaper (AppID: 1163440)
addappid(1163440)
addtoken(1163440, "12705807734072294791")
addappid(1163442, 1, "5c4798203a215c0ca3d6699889e53556c56883e3c9504a70a4bed2f69c9e287c") -- MONKEY KING HERO IS BACK - Pre Wallpaper - Depot 1163442
setManifestid(1163442, "7296575870483184336", 3969019)
-- MONKEY KING HERO IS BACK - Exclusive Wallpapers (AppID: 1179330)
addappid(1179330)
addtoken(1179330, "2849176231242294358")
addappid(1179331, 1, "13d54351d41a39a1e62ba765c9b5f22a9abaa8a920c4f1c9698ead11cc5f00f1") -- MONKEY KING HERO IS BACK - Exclusive Wallpapers - Depot 1179331
setManifestid(1179331, "3190158320603297014", 7811576)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1157380) -- MONKEY KING HERO IS BACK DLC - Dasheng Doll Outfit
addappid(1157420) -- MONKEY KING HERO IS BACK DLC - Tuxedo Outfit
addappid(1157430) -- MONKEY KING HERO IS BACK DLC - Lotus (In-game Item)
addappid(1157440) -- MONKEY KING HERO IS BACK DLC - Guanyin Bodhisattva Amulet (In-game Item)
addappid(1157450) -- MONKEY KING HERO IS BACK DLC - Soul Charming Necklace (In-game Item)
addappid(1157460) -- MONKEY KING HERO IS BACK DLC - Secret Scroll Purge (In-game Item)
addappid(1157470) -- MONKEY KING HERO IS BACK DLC - Purple Incense Burner (In-game Item)
addappid(1157480) -- MONKEY KING HERO IS BACK DLC - UPROAR IN HEAVEN (EPISODE)
addappid(1157490) -- MONKEY KING HERO IS BACK DLC - MIND PALACE (EPISODE)
addappid(1157500) -- MONKEY KING HERO IS BACK DLC - Paradise Mode
addappid(1157510) -- MONKEY KING HERO IS BACK DLC - Desperation Mode
addappid(1177280) -- MONKEY KING HERO IS BACK - Season Pass