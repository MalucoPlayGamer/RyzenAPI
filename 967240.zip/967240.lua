-- Lua provided by RyzenAPI
-- Game: 967240

-- MAIN APPLICATION
addappid(967240)
-- Game: addappid(967240)

-- MAIN APP DEPOTS / PACKAGES
addappid(967241, 1, "2202eb5ce917d02aebfc672e071df05ef84f56435460eda8794b8232681f43c5")
