-- Lua provided by RyzenAPI
-- Game: European Ship Simulator

-- MAIN APPLICATION
addappid(299250)
-- Game: addappid(299250)

-- MAIN APP DEPOTS / PACKAGES
addappid(299251, 1, "4c5f10ebef040ade09061324cd6d9a0140ac43b7633005ae5cb93ca4123f6018")
addappid(299252, 1, "b814bb263829ac4a55acd761d69f478e2508497b30fb54c54f76046816ca2bb1")
