-- Lua provided by RyzenAPI
-- Game: European Ship Simulator

-- MAIN APPLICATION
addappid(299250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(299251, 1, "4c5f10ebef040ade09061324cd6d9a0140ac43b7633005ae5cb93ca4123f6018")
addappid(299252, 1, "b814bb263829ac4a55acd761d69f478e2508497b30fb54c54f76046816ca2bb1")

