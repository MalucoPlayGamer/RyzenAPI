-- Lua provided by RyzenAPI
-- Game: 769340

-- MAIN APPLICATION
addappid(769340)
-- Game: addappid(769340)

-- MAIN APP DEPOTS / PACKAGES
addappid(769341, 1, "2dbdc8b07252b21816dca3b525a32f9be1e3ffd7d217905830f052c6d0548252")
