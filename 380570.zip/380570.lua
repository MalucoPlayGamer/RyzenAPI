-- Lua provided by RyzenAPI
-- Game: AppID 380570

-- MAIN APPLICATION
addappid(380570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(380571, 1, "cc1897e6bb0b8d7e958bb27086ee43cf0057bf00680d02c5fbd98175a9d75d94")

