-- Lua provided by RyzenAPI
-- Game: Game: The Last of Waifus

-- MAIN APPLICATION
addappid(1359650)
addappid(1365990)
-- Game: addappid(1359650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359651, 1, "21961243a333075c0cba93bd4f6bc5f0ee121b0b83220cca72f44d65abb90ea2")
