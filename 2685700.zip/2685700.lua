-- Lua provided by RyzenAPI
-- Game: 2685700

-- MAIN APPLICATION
addappid(2685700)
-- Game: addappid(2685700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685701, 1, "c56d582d2535b5f0bd9594d791edae979c70f27a110ee31595049e4a8c4b8b72")
