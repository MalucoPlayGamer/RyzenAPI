-- Lua provided by SkyAPI 
-- Game: Learning Factory Soundtrack
addappid(1545760)
addappid(1545761, 1, "4d9761626b10e53bb303e503f92fbe3621a902037be9973dcc1e8b8f77789d6c")
addappid(1545762, 1, "98b9362c2019882d195709975df1c3111720681464898a1aa9a6f4459642e119")
