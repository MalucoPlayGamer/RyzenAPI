-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1432176)
-- Game: addappid(1432176)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432176,0,"8c7bcdeedcdab877309658b81f7535eee3f32987dcb9a94bfcd497c837894ffe")
