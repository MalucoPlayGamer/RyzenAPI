-- Lua provided by RyzenAPI
-- Game: addappid(1432176)

-- MAIN APPLICATION
addappid(1432176)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432176,0,"8c7bcdeedcdab877309658b81f7535eee3f32987dcb9a94bfcd497c837894ffe")
