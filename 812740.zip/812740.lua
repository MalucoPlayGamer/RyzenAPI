-- Lua provided by RyzenAPI
-- Game: Game: The Plus Point

-- MAIN APPLICATION
addappid(812740)
-- Game: addappid(812740)

-- MAIN APP DEPOTS / PACKAGES
addappid(812741, 1, "d9c73b450a16475e989c75f805d6d7bdd6f8add8834618ab9b5186b9e03cfd4e")
