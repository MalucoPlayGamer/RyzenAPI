-- Lua provided by RyzenAPI
-- Game: Datascape

-- MAIN APPLICATION
addappid(1873080)
addappid(2745890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1873081, 1, "3dcf74332c2589faf52df19e0e16ba714ffb8c422d848da4840ceb329805f9b1")
addappid(1873083, 1, "1457405817351834ebc3ee6f9c5e0712d0359fc192f08ec3da74a32ae666f9f2")

