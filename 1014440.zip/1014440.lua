-- Lua provided by RyzenAPI
-- Game: 1014440

-- MAIN APPLICATION
addappid(1014440)
-- Game: addappid(1014440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014441, 1, "9ea3bf28b6e7567e8637fc48d5d1c9e3adc7bfcf19c8f107699246f6d9aa136b")
