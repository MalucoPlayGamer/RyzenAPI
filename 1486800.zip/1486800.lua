-- Lua provided by RyzenAPI
-- Game: Game: Chess Knights: High Noon

-- MAIN APPLICATION
addappid(1486800)
-- Game: addappid(1486800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486801, 1, "1438339472b2362937a1342f2191afed060d474571571c38ab34774ccc3926c7")
