-- Lua provided by RyzenAPI
-- Game: Hand Simulator: Aliens

-- MAIN APPLICATION
addappid(2216970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216971, 1, "001cc9a0a06b29db7549092d91d41b5a037ef5c5164c66bfb8c31041383d0975")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
