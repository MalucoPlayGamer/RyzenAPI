-- Lua provided by RyzenAPI
-- Game: Game: Hand Simulator: Aliens

-- MAIN APPLICATION
addappid(2216970)
-- Game: addappid(2216970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216971, 1, "001cc9a0a06b29db7549092d91d41b5a037ef5c5164c66bfb8c31041383d0975")
