-- Lua provided by RyzenAPI
-- Game: 1324410

-- MAIN APPLICATION
addappid(1324410)
-- Game: addappid(1324410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324411, 1, "ee2bf60b1fea866da39c16f5ad15f2f87377c07d2acc04609b59fad11f7cd89c")
