-- Lua provided by RyzenAPI
-- Game: ChatFight!

-- MAIN APPLICATION
addappid(2095570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095572,0,"a5be89fd8760e937fdf565ec2a8be716ad9be015a7dcc5f9ec10754041d77c5d")
addappid(2095573,0,"a594bd1001cec7784e3105ef9c267fa6dc7bac3b2f9bc34b958695cee66e1f28")

