-- Lua provided by RyzenAPI
-- Game: Game: Precept Demo

-- MAIN APPLICATION
addappid(3439180)
-- Game: addappid(3439180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439181, 1, "30d8c83d1e6066e42665184d1bdbd6df5ad1324d5a47287d3a87adbdb417c443")
