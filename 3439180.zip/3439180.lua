-- Lua provided by RyzenAPI 
-- Game: Precept Demo
addappid(3439180)
addappid(3439181, 1, "30d8c83d1e6066e42665184d1bdbd6df5ad1324d5a47287d3a87adbdb417c443")
