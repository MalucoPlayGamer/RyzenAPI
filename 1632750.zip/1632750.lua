-- Lua provided by RyzenAPI
-- Game: 1632750

-- MAIN APPLICATION
addappid(1632750)
-- Game: addappid(1632750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632752,0,"6706c417a8f4e42eb7b6e345b8d9bbebb280e830ac8a1617baba3b703daa64ac")
