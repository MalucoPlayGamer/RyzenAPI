-- Lua provided by RyzenAPI
-- Game: AppID 1268860

-- MAIN APPLICATION
addappid(1268860)
addappid(1569960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268861, 1, "eb2376df8f76bd6bf1c764c431960b9d29baf032388283ad741e9e1c5d0a25ec")

