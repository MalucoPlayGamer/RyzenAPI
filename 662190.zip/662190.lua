-- Lua provided by RyzenAPI
-- Game: addappid(662190)

-- MAIN APPLICATION
addappid(662190)

-- MAIN APP DEPOTS / PACKAGES
addappid(662191, 1, "4e702e9295689d7921fc37facb954e4a2c4ad933e50bf5e48420e1f983005109")
