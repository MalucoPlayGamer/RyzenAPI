-- Lua provided by RyzenAPI
-- Game: Margonem

-- MAIN APPLICATION
addappid(898590)

-- MAIN APP DEPOTS / PACKAGES
addappid(898591, 1, "55151b99907ec5ea09a93491d18b02cd57f82a9333204ae8e3797ecf0daa02bc")

