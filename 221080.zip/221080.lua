-- Lua provided by RyzenAPI
-- Game: AppID 221080

-- MAIN APPLICATION
addappid(221080)

-- MAIN APP DEPOTS / PACKAGES
addappid(221081, 1, "0e0c3e12e69cec3d28c16e1570344c6f68b8d79e67c82027fac1fb6982fb33cd")

