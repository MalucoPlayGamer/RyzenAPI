-- Lua provided by RyzenAPI
-- Game: Game: Cult of PiN Demo

-- MAIN APPLICATION
addappid(3202550)
-- Game: addappid(3202550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202551, 1, "e5a1259467539fa50f5df610d6e42acdcfd1179412fe7dcbb6c80b27a508c1df")
