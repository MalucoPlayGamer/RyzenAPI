-- Lua provided by RyzenAPI
-- Game: addappid(1925970)

-- MAIN APPLICATION
addappid(1925970)
addappid(2197350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925971, 1, "254043307faa3213d0dfc1a82dad0cabd6e19f971124584e152c4eb447129307")
