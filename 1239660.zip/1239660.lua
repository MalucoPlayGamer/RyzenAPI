-- Lua provided by RyzenAPI
-- Game: addappid(1239660)

-- MAIN APPLICATION
addappid(1239660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239661, 1, "c016bdc03a2e18d1eaef6f75d6ddcc87b31a4c4b7dec28f7835ab7afe5f85582")
