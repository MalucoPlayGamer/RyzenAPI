-- Lua provided by RyzenAPI
-- Game: Dagger Froggy

-- MAIN APPLICATION
addappid(3046050)
-- Game: addappid(3046050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046051, 1, "e5fce13f031957deddbda7b56c7e2d32364b5ae381142fee3177920017add9c6")
