-- Lua provided by RyzenAPI 
-- Game: Devolverland Expo
addappid(1283220)
addappid(1283221, 1, "98c2d428ee9e04fb0c017f3d0411ee2c767e7585891bc3f3fb22cbce223ae72a")
