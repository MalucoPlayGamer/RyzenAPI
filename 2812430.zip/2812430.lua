-- Lua provided by RyzenAPI
-- Game: 2812430

-- MAIN APPLICATION
addappid(2812430)
-- Game: addappid(2812430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812431, 1, "9f942fc2243b35a047effc28020aa208ca769821e0af5462d9a480f02bd5ad6c")
