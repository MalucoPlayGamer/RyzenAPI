-- Lua provided by RyzenAPI
-- Game: The Last Stop

-- MAIN APPLICATION
addappid(2812430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2812431, 1, "9f942fc2243b35a047effc28020aa208ca769821e0af5462d9a480f02bd5ad6c")

