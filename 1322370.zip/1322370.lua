-- Lua provided by SkyAPI 
-- Game: Uphold The Realm
addappid(1322370)
addappid(1322371, 1, "f0087b6714c0a15cc280c5c37b3e078e1729b5f44e229f7b1fe829604fdd2f05")
