-- Lua provided by RyzenAPI
-- Game: 1322370

-- MAIN APPLICATION
addappid(1322370)
-- Game: addappid(1322370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322371, 1, "f0087b6714c0a15cc280c5c37b3e078e1729b5f44e229f7b1fe829604fdd2f05")
