-- Lua provided by RyzenAPI
-- Game: Uphold The Realm

-- MAIN APPLICATION
addappid(1322370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322371, 1, "f0087b6714c0a15cc280c5c37b3e078e1729b5f44e229f7b1fe829604fdd2f05")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
