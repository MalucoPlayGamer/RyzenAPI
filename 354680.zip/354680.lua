-- Lua provided by RyzenAPI
-- Game: AppID 354680

-- MAIN APPLICATION
addappid(354680)
-- Game: addappid(354680)

-- MAIN APP DEPOTS / PACKAGES
addappid(354681, 1, "291df70289bc9192f906b3a34ce1af863feb31a7398b2ba566408757bb29a484")
