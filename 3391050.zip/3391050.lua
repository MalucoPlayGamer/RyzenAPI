-- Lua provided by RyzenAPI
-- Game: Game: AppID 3391050

-- MAIN APPLICATION
addappid(3391050)
-- Game: addappid(3391050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3391051, 1, "30f9dfb6c17340d725b4a5ad647866294907b1131b1711151cbd0b7ff3943eb3")
