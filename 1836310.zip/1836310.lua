-- Lua provided by RyzenAPI
-- Game: Game: Apotheorasis • Lab of the Blind Gods | Prologue

-- MAIN APPLICATION
addappid(1836310)
-- Game: addappid(1836310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836311, 1, "1537138ea16e14e0cf2066d7a0416380f477baedde46766946f1d1f650e3bc6d")
