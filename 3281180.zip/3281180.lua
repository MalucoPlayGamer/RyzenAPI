-- Lua provided by RyzenAPI
-- Game: AppID 3281180

-- MAIN APPLICATION
addappid(3281180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3281181, 1, "973cb0dfd39feb5dfe062b542fd3b087908fff49a7cabec5e6ee465c08033357")

