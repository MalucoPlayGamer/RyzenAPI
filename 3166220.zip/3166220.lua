-- Lua provided by RyzenAPI
-- Game: Harukuru HD. - Spring has come true? -

-- MAIN APPLICATION
addappid(3166220)
-- Game: addappid(3166220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3166221, 1, "87e1456180671ce3d138f8d2a69c0cd620506faed1e13778ca2016bc3c6004b6")
