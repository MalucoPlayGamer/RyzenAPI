-- Lua provided by RyzenAPI
-- Game: addappid(2133700)

-- MAIN APPLICATION
addappid(2133700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133701, 1, "b8384d6be44447f83156f027e938d5fd2c9e9a478c8e496c93818fef3fc8269c")
