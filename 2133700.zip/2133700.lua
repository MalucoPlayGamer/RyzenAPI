-- Lua provided by RyzenAPI 
-- Game: AppID 2133700
addappid(2133700)
addappid(2133701, 1, "b8384d6be44447f83156f027e938d5fd2c9e9a478c8e496c93818fef3fc8269c")
