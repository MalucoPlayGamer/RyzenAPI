-- Lua provided by RyzenAPI 
-- Game: Choco Pixel 2
addappid(1229590)
addappid(1229591, 1, "1e8d58099bf269219427258fe169fdef22f212e0c3f3ec69a2362059cf735e65")
