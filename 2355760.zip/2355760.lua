-- Lua provided by RyzenAPI
-- Game: 密閉Airtight Demo

-- MAIN APPLICATION
addappid(2355760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355761, 1, "38b2456021a4943d2302df201c412726e5b57f5a41097ac9bcfa64a13067117b")
