-- Lua provided by RyzenAPI
-- Game: Super Saurio Fly

-- MAIN APPLICATION
addappid(818060)

-- MAIN APP DEPOTS / PACKAGES
addappid(818061, 1, "965f83699d8ea1ad138646d90535bf1fed0e72fe40ccbdb332c241d6a8d90479")

