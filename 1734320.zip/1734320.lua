-- Lua provided by RyzenAPI
-- Game: Brutal Orchestra

-- MAIN APPLICATION
addappid(1734320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734321, 1, "605e144f17f31e41c7d192c2f35f94bd1a52fb6754923aea7488eb8057a1f84e")
addappid(1734322, 1, "31acfcfac25f749463baef49c0df27deac3fee6fffae9d2c38512b22b7152c6f")

