-- Lua provided by RyzenAPI
-- Game: Paintballers Playtest

-- MAIN APPLICATION
addappid(2923450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923451, 1, "32efd194dd4e13777d4b542b5614741e214f8c534a92e6040c8ea46dbfd361db")

