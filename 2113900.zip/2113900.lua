-- Lua provided by RyzenAPI
-- Game: Touge Shakai

-- MAIN APPLICATION
addappid(2113900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113901, 1, "d03fdcdcf28115c77266a7bf1d508c6d652c3363082bcf0a9253513570db4285")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
