-- Lua provided by RyzenAPI
-- Game: Touge Shakai

-- MAIN APPLICATION
addappid(2113900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113901, 1, "d03fdcdcf28115c77266a7bf1d508c6d652c3363082bcf0a9253513570db4285")

