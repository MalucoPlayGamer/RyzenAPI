-- Lua provided by SkyAPI 
-- Game: AppID 1015940
addappid(1015940)
addappid(1015941, 1, "e34b9f3ae429fb44020170a4c224d34a0b5320e1c0e5104ce1a8ce93c88e60d7")
addappid(1015942, 1, "943aeb11c108880da0b2b1ffb31ab3df51f12a1b866dd8576a2d8550a3060f85")
