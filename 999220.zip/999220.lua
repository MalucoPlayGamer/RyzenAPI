-- 999220's Lua and Manifest Created by Hubcap Manifest
-- Amnesia: Rebirth
-- Created: September 28, 2025 at 22:18:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(999220, 1, "d87a3bf157fdd1fc689683e5eddd46c9474453a342184b3c2e202aa1ca68e9f8") -- Amnesia: Rebirth
-- MAIN APP DEPOTS
addappid(999221, 1, "16e1b3abd66452bc21db04d4031cfe2aafa0911774a821ad984b59c2ac02ffb5") -- Content
setManifestid(999221, "6367385268830867872", 31951098807)
addappid(999222, 1, "d0cd0d43c40b0c8a06e16f35ae8ad6f3d6320ef1e54d773b7e908af80a21cf40") -- Core Depot
setManifestid(999222, "2499092913725044937", 21415439)
addappid(999223, 1, "e5bce2686aeb821e62762643c2a20a365fd2e24ea827e4dc0a9929659600da5f") -- Scripts and Maps Depot
setManifestid(999223, "5654132178725832886", 5124323112)
addappid(999224, 1, "7528ff0d2564969c57a0e465d368a962a750b3ceaab7c97e6023ef3b2e4e9f5b") -- Windows Depot
setManifestid(999224, "4592770642210317741", 276682323)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)