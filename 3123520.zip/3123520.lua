-- Lua provided by RyzenAPI
-- Game: リア充爆発しろ！ Normies Should Burn!

-- MAIN APPLICATION
addappid(3123520)
-- Game: addappid(3123520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123521, 1, "9c6508bc8141f7d6a4647fd0f1a6defd0fb5809ff2626342d0c6c3ab599481e3")
