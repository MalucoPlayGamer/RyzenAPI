-- Lua provided by RyzenAPI
-- Game: Drive-By Cop

-- MAIN APPLICATION
addappid(1324630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324631, 1, "370c13a19b928a357f3320a0911c090d6ed3a1a52f0dc642bd7e0568c18ee1a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
