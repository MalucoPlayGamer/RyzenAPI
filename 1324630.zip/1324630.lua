-- Lua provided by SkyAPI 
-- Game: Drive-By Cop
addappid(1324630)
addappid(1324631, 1, "370c13a19b928a357f3320a0911c090d6ed3a1a52f0dc642bd7e0568c18ee1a3")
