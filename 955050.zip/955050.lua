-- Lua provided by RyzenAPI
-- Game: 955050

-- MAIN APPLICATION
addappid(228987)
addappid(228988)
addappid(228990)
addappid(229004)
addappid(955050)

-- MAIN APP DEPOTS / PACKAGES
addappid(955054,0,"a47e6f05e75feb7e74364cd96a700ce849d593a03f8a46f07ea0e39d61c9ee88")

