-- Lua provided by RyzenAPI
-- Game: Differences Online

-- MAIN APPLICATION
addappid(3462600)
