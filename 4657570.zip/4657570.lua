-- Generated with Luie @ https://lua.tools/
-- 4657570 - SEXOPHOBIA 🔞
-- Generated 2026-08-18 05:25:14 UTC
-- # Depots (Total/DLC/Shared): 4/1/0

-- Main AppID
addappid(4657570)

-- Main Depots
addappid(4657571, 1, "6e7bdc2c99cf31c2498389ce49ac13504429eacd16eb76f0795e208156cb0858") -- (windows)
setManifestid(4657571, "2347012095186308223", 1666839393)
addappid(4657572, 1, "3fb29a36dacc0869fbe42d1a8ab23ba493381a62cabebe44b7a72548805557a2") -- (macos)
setManifestid(4657572, "8293850249846595295", 4942525627)
addappid(4657573, 1, "0afc27e6b6ce5412280795f24081cc2558e65992a9a571a4a66164d70b0d938c") -- (linux)
setManifestid(4657573, "5886111233828365340", 1702702178)

-- DLC's (with depot keys)
-- SEXOPHOBIA-WALLPAPERS 🔞 (AppID: 5032240)
addappid(5032240)
addappid(5032240, 1, "9b3ac16cfbafd7c9b848b16b8e67abdb4b75237f86817ee7c3e00085c0e6b9b2")
setManifestid(5032240, "1507795993869004356", 177337368)
