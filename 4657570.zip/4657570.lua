-- Lua provided by RyzenAPI
-- Game: SEXOPHOBIA 🔞

-- MAIN APPLICATION
addappid(4657570)
addappid(5032240)

-- MAIN APP DEPOTS / PACKAGES
addappid(4657571, 1, "6e7bdc2c99cf31c2498389ce49ac13504429eacd16eb76f0795e208156cb0858") -- (windows)
addappid(4657572, 1, "3fb29a36dacc0869fbe42d1a8ab23ba493381a62cabebe44b7a72548805557a2") -- (macos)
addappid(4657573, 1, "0afc27e6b6ce5412280795f24081cc2558e65992a9a571a4a66164d70b0d938c") -- (linux)
addappid(5032240, 1, "9b3ac16cfbafd7c9b848b16b8e67abdb4b75237f86817ee7c3e00085c0e6b9b2")

