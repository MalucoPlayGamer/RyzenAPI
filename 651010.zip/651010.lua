-- Lua provided by RyzenAPI
-- Game: Nurbits

-- MAIN APPLICATION
addappid(651010)

-- MAIN APP DEPOTS / PACKAGES
addappid(651011,0,"580a65310ddc8ac9c76b7066e4efd62548a34f754ade0f36af1b3d11c21cf979")

