-- Lua provided by RyzenAPI 
-- Game: AppID 1259760
addappid(1259760)
addappid(1259761, 1, "e2df3f0a443aaded332f85b432a2f72c85c5fbe012773d1e7057b1aa0ff7ce97")
