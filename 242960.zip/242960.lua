-- Lua provided by RyzenAPI
-- Game: Game: AppID 242960

-- MAIN APPLICATION
addappid(242960)
-- Game: addappid(242960)

-- MAIN APP DEPOTS / PACKAGES
addappid(242961, 1, "133f9b4c0ab7e7dc91d0ffcf874bf034b7ed459091a39ae7203ca397bb8be54f")
