-- Lua provided by RyzenAPI
-- Game: EarWorm

-- MAIN APPLICATION
addappid(2765340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765341, 1, "408eb85093c3d9c252240473fed9be0d32f5c6287a90cb287ad3014658c8f44f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
