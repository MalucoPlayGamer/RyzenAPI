-- Lua provided by RyzenAPI
-- Game: addappid(2765340)

-- MAIN APPLICATION
addappid(2765340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765341, 1, "408eb85093c3d9c252240473fed9be0d32f5c6287a90cb287ad3014658c8f44f")
