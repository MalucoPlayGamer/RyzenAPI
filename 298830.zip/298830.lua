-- Lua provided by RyzenAPI
-- Game: Millennium 3 - Cry Wolf

-- MAIN APPLICATION
addappid(298830)
addappid(357080)

-- MAIN APP DEPOTS / PACKAGES
addappid(298831, 1, "c2e18a184c07ce1f5c8bcfeb6a9e9f84b8d460d2cc239a5f6767a47c33837e5e")
