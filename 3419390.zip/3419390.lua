-- Lua provided by RyzenAPI
-- Game: Game: Gelluloid Domination

-- MAIN APPLICATION
addappid(3419390)
-- Game: addappid(3419390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3419391, 1, "a9f8bdd4e630be5e020dfd70de3ce24c0dde1a81295aadd4fa64a958d30e1eb6")
