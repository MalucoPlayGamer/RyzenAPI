-- 3294440's Lua and Manifest Created by Hubcap Manifest
-- Memoirium
-- Created: August 13, 2026 at 13:21:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3294440) -- Memoirium
-- MAIN APP DEPOTS
addappid(3294441, 1, "44eb4a1a50591844eb76cf15e66c31a1397975896f4c2fd0015bff9b101ee1f5") -- Depot 3294441
setManifestid(3294441, "1512191508838659876", 875720843)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)