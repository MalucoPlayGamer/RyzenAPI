-- Lua provided by RyzenAPI
-- Game: FlappyParrot

-- MAIN APPLICATION
addappid(2567340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567341, 1, "882916934f9157fb474df442c6725bba402ce498bfa2340008a4fab0b0bf3f86")
