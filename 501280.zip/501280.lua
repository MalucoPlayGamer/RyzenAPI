-- Lua provided by RyzenAPI
-- Game: VirZOOM Gamepad Emulator

-- MAIN APPLICATION
addappid(501280)

-- MAIN APP DEPOTS / PACKAGES
addappid(501281, 1, "491d94ff29c06dc6419cfb98a5738f0dbe404cf8d69bd71d9582d851e789d0bb")

