-- Lua provided by RyzenAPI
-- Game: Ragnarock

-- MAIN APPLICATION
addappid(1345820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345821, 1, "237c808fac720391a4b5aaa3414f50b6f7331189972658c386ccbb969f231ef4")

