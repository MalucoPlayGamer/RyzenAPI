-- Lua provided by RyzenAPI
-- Game: Ragnarock

-- MAIN APPLICATION
addappid(1345820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345821, 1, "237c808fac720391a4b5aaa3414f50b6f7331189972658c386ccbb969f231ef4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1918840)
addappid(1918841)
addappid(1918842)
addappid(1918843)
addappid(1918844)
addappid(1918845)
addappid(2000140)
addappid(2000141)
addappid(2000142)
addappid(2000143)
addappid(2000144)
addappid(2000145)
addappid(2000146)
addappid(2000147)
addappid(2021460)
addappid(2021461)
addappid(2021462)
addappid(2242990)
addappid(2242991)
addappid(2242992)
addappid(2242993)
addappid(2242994)
addappid(2242995)
addappid(2242996)
addappid(2242997)
addappid(2242998)
addappid(2449480)
addappid(2449481)
addappid(2449482)
addappid(2449483)
addappid(2449484)
addappid(2449485)
addappid(2716060)
addappid(2716070)
addappid(2716080)
addappid(2716090)
addappid(2716100)
addappid(2721330)
addappid(3559760)
addappid(3559770)
addappid(3846850)
addappid(3846860)
