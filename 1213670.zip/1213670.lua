-- Lua provided by RyzenAPI
-- Game: Solitaire Forever II

-- MAIN APPLICATION
addappid(1213670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213671, 1, "2b8659fafee8ae952dd6ffe726c4fd07986d5655ee6aabf2a14e3d0bf13a000f")

