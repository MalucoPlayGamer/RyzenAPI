-- Lua provided by RyzenAPI
-- Game: 1716770

-- MAIN APPLICATION
addappid(1716770)
-- Game: addappid(1716770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716771, 1, "893c28f7ee6941b81ecef950d86550fd13a365f6d20974e20526b97266bcffce")
