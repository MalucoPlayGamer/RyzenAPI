-- Lua provided by RyzenAPI
-- Game: addappid(1941310)

-- MAIN APPLICATION
addappid(1941310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941311, 1, "45a20eb54eaaa409ceb46c5ebb2270e0b4aac4be46062c2d6e58a1ad8c7ab40a")
