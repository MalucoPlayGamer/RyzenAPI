-- Lua provided by RyzenAPI
-- Game: Sleep Paralysis: The Uncanny Valley

-- MAIN APPLICATION
addappid(1941310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1941311, 1, "45a20eb54eaaa409ceb46c5ebb2270e0b4aac4be46062c2d6e58a1ad8c7ab40a")

