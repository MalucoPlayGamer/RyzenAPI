-- Lua provided by RyzenAPI
-- Game: Firework War

-- MAIN APPLICATION
addappid(3424740)
addappid(3466780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3424741, 1, "013638a60d0bcf7c1ca3379f8fdc23dea7a4a484d359ec2d4be704023e68daeb")

