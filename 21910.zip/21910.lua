-- Lua provided by RyzenAPI
-- Game: AppID 21910

-- MAIN APPLICATION
addappid(21910)
-- Game: addappid(21910)

-- MAIN APP DEPOTS / PACKAGES
addappid(21911, 1, "22aecea17c17d5ce9e58a71f15c59158df7216fc625ada08c9c12cb81e1e52b5")
