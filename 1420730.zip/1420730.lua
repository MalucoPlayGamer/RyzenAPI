-- Lua provided by RyzenAPI
-- Game: Save the Planet

-- MAIN APPLICATION
addappid(1420730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420731, 1, "2d3ae15a9e623994b486df52247d9d8777ea3c2d2a807855c48a9341605e36a3")
