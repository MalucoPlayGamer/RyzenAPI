-- Lua provided by RyzenAPI
-- Game: 625950

-- MAIN APPLICATION
addappid(625950)
-- Game: addappid(625950)

-- MAIN APP DEPOTS / PACKAGES
addappid(625951, 1, "276035906ed5dc70a4b2b6c8a5a143a43d0635acbb54522683532b519ac202f8")
