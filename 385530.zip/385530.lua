-- Lua provided by RyzenAPI
-- Game: AppID 385530

-- MAIN APPLICATION
addappid(385530)

-- MAIN APP DEPOTS / PACKAGES
addappid(385531, 1, "55af2cdef4eb4006cc2b8f49bdf4aee7ee3920e9501ce543040a11b4a1246813")
addappid(385532, 1, "82ff2210523b3a5ed69bc67d7702a452ef935ac4ead81894b6862fc80be3b462")
addappid(385533, 1, "1f876ba7bb13713dc492524b3cc58c8a83323b09afdf2d1268112865f74b3812")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(417190)
addappid(428770)
addappid(431050)
addappid(431060)
addappid(461090)
addappid(461110)
addappid(461120)
addappid(485170)
addappid(485180)
addappid(485190)
