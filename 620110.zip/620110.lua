-- Lua provided by RyzenAPI
-- Game: 620110

-- MAIN APPLICATION
addappid(620110)
addappid(620111)
addappid(620113)

-- MAIN APP DEPOTS / PACKAGES
addappid(620112,0,"60cf0d241f0b257f9208bd2b4934d12158e5e2e35561204a400734c7c1d408f7")
addappid(620114,0,"5bdecdf7c373d3de81aace9a709f7d5447fe503cba84ba764c55159f2db61fea")
