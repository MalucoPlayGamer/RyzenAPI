-- Lua provided by RyzenAPI
-- Game: Axiom Verge

-- MAIN APPLICATION
addappid(332200)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(332201, 1, "56a3188cc53d8620265205faf40ea99e5b99dc2c2f6139de9053a88cefd1d7f9")
addappid(332203, 1, "0f3335bc5cc32fdca374d13eb1a3f67252a8acec3ff97d13abc61b6f819db842")
addappid(332204, 1, "ac838b060d2c4612e7cd5ab318d5df36779b38a04f3b10c26cef68fe26622636")

