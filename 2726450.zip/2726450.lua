-- Lua provided by SkyAPI 
-- Game: Windowkill
addappid(2726450)
addappid(2726451, 1, "395c4804d47282f4081571ceed4fb5c59a21704398b49eb59455ccbbe92d0384")
addappid(2726452, 1, "c819d596759c7f388838e23cc89d1b295eb17e6beb84cd7d843773d3c902c405")
