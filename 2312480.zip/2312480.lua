-- Lua provided by RyzenAPI
-- Game: addappid(2312480)

-- MAIN APPLICATION
addappid(2312480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312481, 1, "19e4b57380c7c7cdac028289c74ec33576e0a60f180663b4fdf9277f77006c4a")
