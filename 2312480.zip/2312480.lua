-- Lua provided by RyzenAPI 
-- Game: AppID 2312480
addappid(2312480)
addappid(2312481, 1, "19e4b57380c7c7cdac028289c74ec33576e0a60f180663b4fdf9277f77006c4a")
