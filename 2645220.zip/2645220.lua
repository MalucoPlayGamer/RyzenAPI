-- Lua provided by RyzenAPI 
-- Game: The Bunker
addappid(2645220)
addappid(2645221, 1, "8d3f1d42784e110b63e3c15a171cda131cf8d9c95c0d63e27ad926fd1ba4fa35")
