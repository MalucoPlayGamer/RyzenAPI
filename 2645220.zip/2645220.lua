-- Lua provided by RyzenAPI
-- Game: Game: The Bunker

-- MAIN APPLICATION
addappid(2645220)
-- Game: addappid(2645220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645221, 1, "8d3f1d42784e110b63e3c15a171cda131cf8d9c95c0d63e27ad926fd1ba4fa35")
