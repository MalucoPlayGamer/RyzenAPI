-- Lua provided by RyzenAPI
-- Game: 1407890

-- MAIN APPLICATION
addappid(1407890)
-- Game: addappid(1407890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407891, 1, "288d06c1aee2af7feb16bd41ff6ad130809f8a998c012384654c2212651cad66")
