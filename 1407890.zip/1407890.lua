-- Lua provided by RyzenAPI
-- Game: hexurb

-- MAIN APPLICATION
addappid(1407890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407891, 1, "288d06c1aee2af7feb16bd41ff6ad130809f8a998c012384654c2212651cad66")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
