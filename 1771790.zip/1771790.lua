-- Lua provided by RyzenAPI
-- Game: Game: 与神相伴的末日 Soundtrack

-- MAIN APPLICATION
addappid(1771790)
-- Game: addappid(1771790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771791, 1, "b0ba9ab603f09b9425283cb987cea764d5fae2d3381a42531de73d05d02b5c21")
