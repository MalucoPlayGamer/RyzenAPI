-- Lua provided by RyzenAPI
-- Game: The Patient S Remedy

-- MAIN APPLICATION
addappid(1730190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730191, 1, "fd056f74f1313495c21fe2cf52726048e01a372013af39d17b011611bb490b78")

