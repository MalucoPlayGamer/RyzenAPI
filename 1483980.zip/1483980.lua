-- Lua provided by RyzenAPI
-- Game: AppID 1483980

-- MAIN APPLICATION
addappid(1483980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483981, 1, "9278a17fa104304a47892cb59484874f499803b1c41692c495d00969edc2372a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
