-- Lua provided by RyzenAPI
-- Game: Game: The Detroit After

-- MAIN APPLICATION
addappid(1926810)
-- Game: addappid(1926810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926811, 1, "64ed74a11c00d8bc4a66558709d1930fbce18ef43d77d232805939af6d7a3634")
