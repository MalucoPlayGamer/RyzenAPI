-- Lua provided by RyzenAPI
-- Game: Lucy Got Problems

-- MAIN APPLICATION
addappid(879510)
addappid(1822690)

-- MAIN APP DEPOTS / PACKAGES
addappid(879511, 1, "45097b49097cadac506f5fb0e1879ee6743d4a45324dbb7c340f7a3a41962aff")
addappid(956490, 0, "c15983a99db25c745d047114ac9d6367b56f388d677c19df0d6dcb9739ed43cc")
addappid(1436850, 0, "d07e855228e8a3b6c009eafcc33b80c7757c32f5a54afd2f3648ce7189c79856")
