-- Lua provided by RyzenAPI
-- Game: Razgovor Playtest

-- MAIN APPLICATION
addappid(1985230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985231, 1, "cbdb48dd65492603f02c559e7f2b29bc5bd971597ace20a66083d59cef7c6584")
