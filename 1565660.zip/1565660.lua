-- Lua provided by RyzenAPI
-- Game: S.P.A.T.

-- MAIN APPLICATION
addappid(1565660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565661, 1, "4c0cbf9530814f95b8f703f11cdbea408a9361ffcaec1997dcf87e7ec869b9b2")
