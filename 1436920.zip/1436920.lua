-- Lua provided by RyzenAPI
-- Game: Tandem: A Tale of Shadows

-- MAIN APPLICATION
addappid(1436920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436921, 1, "479d8d48f777a4dfa26db3c0d6ed115657330d3eacf73b64d183315857ee825d")
