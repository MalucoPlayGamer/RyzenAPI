-- Lua provided by SkyAPI 
-- Game: Security: The Horrible Nights
addappid(2911390)
addappid(2911391, 1, "c54fe80dbc1f0aadce30925544bc1c32f7bec72c25d37d8154d0711447e12446")
