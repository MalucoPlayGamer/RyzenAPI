-- Lua provided by RyzenAPI
-- Game: Security: The Horrible Nights

-- MAIN APPLICATION
addappid(2911390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911391, 1, "c54fe80dbc1f0aadce30925544bc1c32f7bec72c25d37d8154d0711447e12446")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3338870)
addappid(3462400)
