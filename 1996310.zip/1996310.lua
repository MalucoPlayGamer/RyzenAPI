-- Lua provided by RyzenAPI
-- Game: Succubus - Issabel Cosplay

-- MAIN APPLICATION
addappid(1996310)
-- Game: addappid(1996310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996310,0,"cea3c22cd4c03d7394bfa41b99d64e0fbf0fbbc7155437edca456a939b3e7a77")
