-- Lua provided by RyzenAPI
-- Game: 正宗台灣十六張麻將2

-- MAIN APPLICATION
addappid(1508660)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1508661, 1, "da5da5e56fa0b6715459ef9c5fec68f7478416d7caf8b8d397a9554607c76ee3")

