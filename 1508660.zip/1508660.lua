-- Lua provided by RyzenAPI
-- Game: Game: AppID 1508660

-- MAIN APPLICATION
addappid(1508660)
-- Game: addappid(1508660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508661, 1, "da5da5e56fa0b6715459ef9c5fec68f7478416d7caf8b8d397a9554607c76ee3")
