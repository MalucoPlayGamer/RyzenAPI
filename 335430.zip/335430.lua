-- Lua provided by RyzenAPI
-- Game: Grimoire: Manastorm

-- MAIN APPLICATION
addappid(335430)

-- MAIN APP DEPOTS / PACKAGES
addappid(335431, 1, "817af3ad49ee2d820b362a60b8f9d62e1dc17a6aa85b935ad660a9eb9ad26ed6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(426960)
addappid(426980)
addappid(428820)
addappid(428821)
addappid(428840)
addappid(436920)
