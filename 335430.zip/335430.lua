-- Lua provided by RyzenAPI 
-- Game: Grimoire: Manastorm
addappid(335430)
addappid(335431, 1, "817af3ad49ee2d820b362a60b8f9d62e1dc17a6aa85b935ad660a9eb9ad26ed6")
