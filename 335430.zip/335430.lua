-- Lua provided by RyzenAPI
-- Game: Game: Grimoire: Manastorm

-- MAIN APPLICATION
addappid(335430)
-- Game: addappid(335430)

-- MAIN APP DEPOTS / PACKAGES
addappid(335431, 1, "817af3ad49ee2d820b362a60b8f9d62e1dc17a6aa85b935ad660a9eb9ad26ed6")
