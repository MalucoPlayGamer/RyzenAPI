-- Lua provided by SkyAPI 
-- Game: Hermes: Sibyls' Prophecy
addappid(1388330)
addappid(1388331, 1, "147661c24ac70f99c76c56d1d6ed2fc443d0910d5e8632d7b76b68ae1de7c9d9")
addappid(1388332, 1, "e312197fd21c5893292dc6e7e5ddc734fc666a3ec76faf0fb522082d702cb1f6")
addappid(1388333, 1, "8549af753ddb548263efb6b9053ba91d02f0495f5ebbb6094e365bc7f8403e71")
