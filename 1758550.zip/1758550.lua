-- Lua provided by RyzenAPI
-- Game: 契约唤灵师

-- MAIN APPLICATION
addappid(1758550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758551, 1, "9fb948b5168dcef470186a525b09f4750f8979c076dcd24698ef156e454c1a24")
