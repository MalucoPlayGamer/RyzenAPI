-- Lua provided by SkyAPI 
-- Game: Xiangsheng Simulator
addappid(2734310)
addappid(2734311, 1, "48a189982b8c0cc48447c668a04f2747f626c00688aa07ca3c540005e4e7032c")
