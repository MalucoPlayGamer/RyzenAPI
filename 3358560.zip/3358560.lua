-- Lua provided by RyzenAPI
-- Game: Hardware Store Simulator

-- MAIN APPLICATION
addappid(3358560)
-- Game: addappid(3358560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358561, 1, "f77e94c66fa108542545c5b4da2509660814b7ec9a293206476b4ac22d531b1c")
