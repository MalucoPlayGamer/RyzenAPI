-- Lua provided by RyzenAPI
-- Game: Eras Rising

-- MAIN APPLICATION
addappid(2326990)
-- Game: addappid(2326990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326991, 1, "0433e6c10dd8caad11a3edf8ae26125b66f397d7b4fe650577388ea0c4793c7f")
