-- Lua provided by RyzenAPI
-- Game: Angry Bunny 2: Lost hole

-- MAIN APPLICATION
addappid(1235460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1235461, 1, "b0a059d823b7a86cf8c0680cb7dda3f68287e832c22af7cdb32883b23df55a9b")

