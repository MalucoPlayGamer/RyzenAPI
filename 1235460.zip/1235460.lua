-- Lua provided by RyzenAPI
-- Game: addappid(1235460)

-- MAIN APPLICATION
addappid(1235460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235461, 1, "b0a059d823b7a86cf8c0680cb7dda3f68287e832c22af7cdb32883b23df55a9b")
