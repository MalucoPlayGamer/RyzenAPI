-- Lua provided by RyzenAPI
-- Game: 登阶 Demo

-- MAIN APPLICATION
addappid(2804360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804361, 1, "f25eae65b92757edbdd76c6d4e385f151b240e084cfa34a9f86f066c285c1393")
