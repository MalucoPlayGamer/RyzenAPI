-- Lua provided by SkyAPI 
-- Game: AppID 2804360
addappid(2804360)
addappid(2804361, 1, "f25eae65b92757edbdd76c6d4e385f151b240e084cfa34a9f86f066c285c1393")
