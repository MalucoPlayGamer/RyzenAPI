-- Lua provided by RyzenAPI
-- Game: ALIENS INVADED OUR PLANET

-- MAIN APPLICATION
addappid(873930)
addappid(880460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(873931,0,"15af3bf5b1c58278a9f1c9f3d29747d5f58b9f93d0d386cd9e25938dada71a6f")

