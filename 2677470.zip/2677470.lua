-- Lua provided by RyzenAPI
-- Game: POOLS Demo

-- MAIN APPLICATION
addappid(2677470)
-- Game: addappid(2677470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677471, 1, "c6c6661659c356be2d7c8b903f60a78bf21b7aa699b72370e397ce24804a41fe")
