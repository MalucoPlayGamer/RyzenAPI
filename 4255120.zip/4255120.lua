-- 4255120's Lua and Manifest Created by Hubcap Manifest
-- 缴费与香烟
-- Created: August 15, 2026 at 05:53:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4255120) -- 缴费与香烟
-- MAIN APP DEPOTS
addappid(4255121, 1, "f72f9f5f2c534243da20cc705065f86c374f7cee350ffa3faa1272a9e911f216") -- Depot 4255121
setManifestid(4255121, "639558560161533739", 1770976329)