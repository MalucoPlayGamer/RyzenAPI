-- Lua provided by RyzenAPI
-- Game: Created: August 15, 2026 at 05:53:26 EDT

-- MAIN APPLICATION
addappid(4255120) -- 缴费与香烟

-- MAIN APP DEPOTS / PACKAGES
addappid(4255121, 1, "f72f9f5f2c534243da20cc705065f86c374f7cee350ffa3faa1272a9e911f216") -- Depot 4255121

