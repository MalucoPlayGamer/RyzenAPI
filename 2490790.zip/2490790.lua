-- Lua provided by RyzenAPI
-- Game: Joyville

-- MAIN APPLICATION
addappid(2490790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490791, 1, "bd813302f4660e7926f21580023d1f38456e6c3e2fa86ef168d83be8093c2cd2")
