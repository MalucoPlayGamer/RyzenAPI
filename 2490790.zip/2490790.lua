-- Lua provided by RyzenAPI
-- Game: Joyville

-- MAIN APPLICATION
addappid(2490790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490791, 1, "bd813302f4660e7926f21580023d1f38456e6c3e2fa86ef168d83be8093c2cd2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
