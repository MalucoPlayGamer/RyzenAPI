-- Lua provided by RyzenAPI
-- Game: Archmage Idle

-- MAIN APPLICATION
addappid(4557350)

