-- Lua provided by RyzenAPI
-- Game: addappid(1277390)

-- MAIN APPLICATION
addappid(1277390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277391, 1, "99f1b1dc33164af0942fd41c57a57bf562ff29a496f89165c7874ed500f55ed4")
