-- Lua provided by RyzenAPI
-- Game: Death World

-- MAIN APPLICATION
addappid(1277390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1277391, 1, "99f1b1dc33164af0942fd41c57a57bf562ff29a496f89165c7874ed500f55ed4")

