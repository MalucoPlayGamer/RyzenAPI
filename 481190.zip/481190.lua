-- Lua provided by RyzenAPI
-- Game: Stable Orbit

-- MAIN APPLICATION
addappid(481190)

-- MAIN APP DEPOTS / PACKAGES
addappid(481191, 1, "35651bec30257c3d64a971d7226a14592f15ef0566904feda61e1e1c1f1cc093")
