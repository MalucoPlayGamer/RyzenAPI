-- Lua provided by RyzenAPI
-- Game: Game: The Walking Fish 2: Final Frontier

-- MAIN APPLICATION
addappid(1281200)
-- Game: addappid(1281200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281201, 1, "ce0de5c0625ce41e6d42c3b5bf5b82fc9f37979471a13a306d6bb776e7f5bba4")
