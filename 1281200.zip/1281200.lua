-- Lua provided by RyzenAPI
-- Game: The Walking Fish 2: Final Frontier

-- MAIN APPLICATION
addappid(1281200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281201, 1, "ce0de5c0625ce41e6d42c3b5bf5b82fc9f37979471a13a306d6bb776e7f5bba4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
