-- Lua provided by RyzenAPI
-- Game: My Jigsaw Adventures - Roads of Life

-- MAIN APPLICATION
addappid(1224450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224451, 1, "5c3b4003f691e5b81c1db5accdeb27adee965c58f6b8803dd64fa45f10338ebf")
