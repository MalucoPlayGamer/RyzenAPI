-- Lua provided by RyzenAPI
-- Game: No Knock

-- MAIN APPLICATION
addappid(3860450) -- No Knock

-- MAIN APP DEPOTS / PACKAGES
addappid(3860451, 1, "4f9a0dbc0f733a2b3689620fa5740757d1e834e65dcfd541bec0bfa39faabf12") -- Depot 3860451

