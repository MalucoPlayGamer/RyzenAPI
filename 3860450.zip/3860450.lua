-- 3860450's Lua and Manifest Created by Hubcap Manifest
-- No Knock
-- Created: August 12, 2026 at 22:54:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3860450) -- No Knock
-- MAIN APP DEPOTS
addappid(3860451, 1, "4f9a0dbc0f733a2b3689620fa5740757d1e834e65dcfd541bec0bfa39faabf12") -- Depot 3860451
setManifestid(3860451, "6911245280417179353", 5151053037)