-- Lua provided by RyzenAPI
-- Game: addappid(740340)

-- MAIN APPLICATION
addappid(740340)

-- MAIN APP DEPOTS / PACKAGES
addappid(740341, 1, "0634d515d3a38977fd9a377c21acee6c778d3f4c7c203afee21b1e9734a2f2fb")
