-- Lua provided by RyzenAPI
-- Game: AppID 530630

-- MAIN APPLICATION
addappid(530630)

-- MAIN APP DEPOTS / PACKAGES
addappid(530631, 1, "3315000ad66bc2e7bdc522334e74e4cd8d86320acfa7d103ee6f659138dc955e")
addappid(821210, 0, "0f52e323b1a84bb3526d547290b11189cf9b4f12bdd27f0a3135749ee4412f92")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(912830)
addappid(912831)
addappid(912832)
addappid(912833)
addappid(912834)
addappid(912835)
addappid(965930)
