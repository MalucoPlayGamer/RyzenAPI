-- Lua provided by RyzenAPI
-- Game: Game: AppID 530630

-- MAIN APPLICATION
addappid(530630)
-- Game: addappid(530630)

-- MAIN APP DEPOTS / PACKAGES
addappid(530631, 1, "3315000ad66bc2e7bdc522334e74e4cd8d86320acfa7d103ee6f659138dc955e")
addappid(821210, 0, "0f52e323b1a84bb3526d547290b11189cf9b4f12bdd27f0a3135749ee4412f92")
