-- Lua provided by RyzenAPI
-- Game: Insanity Clicker

-- MAIN APPLICATION
addappid(393530)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(498790)
