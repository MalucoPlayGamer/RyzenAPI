-- Lua provided by RyzenAPI
-- Game: Insanity Clicker

-- MAIN APPLICATION
addappid(393530)
