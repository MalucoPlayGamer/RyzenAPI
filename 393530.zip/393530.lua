-- Lua provided by RyzenAPI
-- Game: Insanity Clicker

-- MAIN APPLICATION
addappid(393530)
addappid(498790)

