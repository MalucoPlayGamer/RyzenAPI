-- Lua provided by RyzenAPI
-- Game: AppID 2131800

-- MAIN APPLICATION
addappid(2131800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2131801, 1, "3be4e18e853386772a731c4c142aaa09de49aeb9eca4a725fd29c288d8a82b85")

