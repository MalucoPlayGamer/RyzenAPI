-- Lua provided by RyzenAPI
-- Game: Game: Six Cabins in Serpent Ridge National Forest

-- MAIN APPLICATION
addappid(2767180)
-- Game: addappid(2767180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767181, 1, "f158e0c94212b36b63a0bc22517562da5c0f92f12e9596dc539ef5883ffff940")
