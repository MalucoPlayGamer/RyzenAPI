-- Lua provided by RyzenAPI
-- Game: 956751

-- MAIN APPLICATION
addappid(956751)

-- MAIN APP DEPOTS / PACKAGES
addappid(956751,0,"ddb3d9acb99288d755d3e1a4ad2358dae5d07a179bb3694956b8dbb1bb8d709e")
