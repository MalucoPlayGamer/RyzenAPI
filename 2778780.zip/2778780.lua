-- Lua provided by RyzenAPI
-- Game: 2778780

-- MAIN APPLICATION
addappid(2778780)
-- Game: addappid(2778780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778781, 1, "a68992db63dc62a430f08b8ac1c1fe722fef1c4dd9a5a4317b9c4f0fc4ac05b1")
