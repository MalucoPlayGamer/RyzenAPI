-- Lua provided by RyzenAPI
-- Game: Wizard Of Walls

-- MAIN APPLICATION
addappid(1548800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548801, 1, "a0a065565de8d48b6bc4f331c5e257efc749ffb3361fb4c83779ce83554753fc")

