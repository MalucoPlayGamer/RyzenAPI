-- Lua provided by RyzenAPI 
-- Game: AppID 35420
addappid(35420)
addappid(35421, 1, "251bb8119dc310c23cf212514e11ad81e09abb477f325de1a7100feaf6643a09")
addappid(35422, 1, "e0351bb4fd9c7085aa4e37159aaeebc8d0588afe2468a06a3aad793158e05021")
