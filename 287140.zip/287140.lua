-- Lua provided by RyzenAPI
-- Game: 287140

-- MAIN APPLICATION
addappid(287140)
-- Game: addappid(287140)

-- MAIN APP DEPOTS / PACKAGES
addappid(287141, 1, "417e293600ae6104081e451defaa864b4c49487c88d2d2e14ef52289eb53abc3")
