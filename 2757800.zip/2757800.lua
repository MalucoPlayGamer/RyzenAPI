-- Lua provided by RyzenAPI
-- Game: addappid(2757800)

-- MAIN APPLICATION
addappid(2757800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757801, 1, "0ee6aa66e49a6209d417581c3135b030fc762d37f3bb39b43e64be152a6b4d8e")
