-- Lua provided by RyzenAPI
-- Game: 1984 Rewired

-- MAIN APPLICATION
addappid(1151580)
-- Game: addappid(1151580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151581, 1, "237bae5b7dfccbc1774397c3c64221f8e24c5eca44e727ca2eb5c55d3aed20cf")
