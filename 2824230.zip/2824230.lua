-- Lua provided by RyzenAPI
-- Game: last seen online

-- MAIN APPLICATION
addappid(2824230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824232,0,"f23460271f5ce3066f8e0f8b19329577121c4bf56bc43f028d38967225fc6bba")
addappid(2824233,0,"849a1f413fbfb287cf5bbb051da43d0038f8dfa02f7af90be3c297dc1fe2c505")
