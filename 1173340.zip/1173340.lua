-- Lua provided by RyzenAPI
-- Game: War Trains

-- MAIN APPLICATION
addappid(1173340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173341, 1, "bc0529a723030087336b6e92fbeefae854c615700181de16862636bdd9c12b97")

