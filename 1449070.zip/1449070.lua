-- Lua provided by RyzenAPI
-- Game: 1449070

-- MAIN APPLICATION
addappid(1449070)
-- Game: addappid(1449070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449071, 1, "c456f9618b01e443fe6335403be2cb31891a949eac078764eb206fa5e6a63d79")
addappid(1449072, 1, "a3a3caafc30e9b4840ed6d499e3ab0f099d613b6b6ae491dd2c36897daada0fe")
