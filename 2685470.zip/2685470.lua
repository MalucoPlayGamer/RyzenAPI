-- Lua provided by RyzenAPI
-- Game: Shadow of the Depth Demo

-- MAIN APPLICATION
addappid(2685470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685471, 1, "023bd19b6dfc6c64a056c4174ddb9e85397ffaa44d402fc8bc2104fb1df2f5b1")
