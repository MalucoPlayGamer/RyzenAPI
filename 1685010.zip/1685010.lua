-- Lua provided by RyzenAPI
-- Game: 1685010

-- MAIN APPLICATION
addappid(1685010)
-- Game: addappid(1685010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685011, 1, "b84f399946f10eba3a51da89513a91b444e109e0b37fedeb9ccf488228a8f994")
