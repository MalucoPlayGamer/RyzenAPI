-- Lua provided by RyzenAPI
-- Game: Lifeless Moon

-- MAIN APPLICATION
addappid(1147330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147331, 1, "42c1122a13a5eb32f475204afd6698c8926661c885081f634c912e540dbd9a43")

