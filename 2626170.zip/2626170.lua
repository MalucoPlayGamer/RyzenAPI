-- Lua provided by RyzenAPI
-- Game: Dungeon No Dungeon: Tyrant's Endgame Demo

-- MAIN APPLICATION
addappid(2626170)
-- Game: addappid(2626170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626171, 1, "f9b4a87e5331662e36800c0d614e0e510aae488f5f17c7212143213d48a2a962")
