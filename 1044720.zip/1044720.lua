-- Lua provided by RyzenAPI
-- Game: Farthest Frontier

-- MAIN APPLICATION
addappid(1044720)
addappid(4242820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044721, 1, "2a605d9a2257c347b93162b67aa9844b9719d858501c8df4bcf4982565069ab7")
