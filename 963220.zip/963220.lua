-- Lua provided by RyzenAPI
-- Game: The Bluecoats: North & South

-- MAIN APPLICATION
addappid(963220)
-- Game: addappid(963220)

-- MAIN APP DEPOTS / PACKAGES
addappid(963221, 1, "b2cc42d06603760d200006d293aba4a73353c949bbed7735186913bcf33263c3")
