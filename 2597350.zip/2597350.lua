-- Lua provided by RyzenAPI
-- Game: 2597350

-- MAIN APPLICATION
addappid(2597350)
addappid(3319830)
-- Game: addappid(2597350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597351, 1, "226bef2ae337e6fd78aaced990d4aef44608cd5aea82d0997159bc3b6757bfd0")
