-- Lua provided by SkyAPI 
-- Game: Allison's Diary: Rebirth
addappid(979890)
addappid(979891, 1, "4e2a73cbc41ab3ff2e6c8482c44f520ad5bb56619a4f17e9a74bc75ab928da3c")
