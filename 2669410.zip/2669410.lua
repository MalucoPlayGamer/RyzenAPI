-- 2669410's Lua and Manifest Created by Hubcap Manifest
-- Metro Awakening
-- Created: January 15, 2026 at 03:19:43 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 4
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2669410, 1, "f5d5debdb53f9a6ceff64878160dc0ac710ee72f82591850a97d2864e160b785") -- Metro Awakening
-- MAIN APP DEPOTS
addappid(2669411, 1, "e66acc7d1c34d04e8258937dc45248f754652968f377d3bb4447273880f07363") -- Depot 2669411
setManifestid(2669411, "6925264499529975413", 30141890044)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2841900) -- Metro Awakening - Deluxe Upgrade
addappid(2841920) -- Metro Awakening - Concept Art Gallery
addappid(2841930) -- Metro Awakening - Field Medic Pack
addappid(2841940) -- Metro Awakening - Memories of Polyanka Pack