-- Lua provided by RyzenAPI
-- Game: Metro Awakening

-- MAIN APPLICATION
addappid(2669410)
addappid(2841900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669411, 1, "e66acc7d1c34d04e8258937dc45248f754652968f377d3bb4447273880f07363")

