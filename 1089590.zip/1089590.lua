-- Lua provided by RyzenAPI
-- Game: Ashes 2

-- MAIN APPLICATION
addappid(1089590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089591, 1, "e3b5113b007492dbc4eaa068e1e63f39a8707bccba6d81d5f4b0fa87fc382512")
