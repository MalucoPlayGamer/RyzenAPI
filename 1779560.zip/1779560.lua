-- Lua provided by RyzenAPI
-- Game: Donut Dodo

-- MAIN APPLICATION
addappid(1779560)
-- Game: addappid(1779560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779561, 1, "13cb912e248f53c6d18fab808ea03261b225b891c86ff8f5837e29e93fd25ea3")
