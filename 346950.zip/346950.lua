-- Lua provided by RyzenAPI
-- Game: addappid(346950)

-- MAIN APPLICATION
addappid(346950)

-- MAIN APP DEPOTS / PACKAGES
addappid(346951, 1, "ddff6abf16e26a96310b38a215bda10b3dc9c606e7e612c4bb91675cb30e6595")
