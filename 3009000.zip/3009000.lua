-- Lua provided by RyzenAPI
-- Game: 3009000

-- MAIN APPLICATION
addappid(3009000)
-- Game: addappid(3009000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009003,0,"65c5b9c6e0403b42dbb9e0a9bc9849da79a7e3dbef6a4edc81881531bb0273fa")
