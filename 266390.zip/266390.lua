-- Lua provided by RyzenAPI
-- Game: 266390

-- MAIN APPLICATION
addappid(266390)
-- Game: addappid(266390)

-- MAIN APP DEPOTS / PACKAGES
addappid(266391, 1, "c472a3ff32095ad86f5749c65bb7736794f9d4ccddd3a781cbcadf28f7b67a00")
addappid(266392, 1, "1d02c709a22a145ccf2f433bde290ae126da5b81cb88a5d5651caf4f00a27014")
addappid(266393, 1, "5c7d776678c7257e9c05182b9fe18fa9935cfb9164875c4eaebc53742152c3f5")
