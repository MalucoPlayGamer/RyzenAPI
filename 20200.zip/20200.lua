-- Lua provided by RyzenAPI
-- Game: 20200

-- MAIN APPLICATION
addappid(20200)
-- Game: addappid(20200)

-- MAIN APP DEPOTS / PACKAGES
addappid(20201, 1, "48dc4ac1a2ed15c9d4e91a90e1673addd27cb62e90b2361370a1d9cfc0de234f")
