-- Lua provided by RyzenAPI
-- Game: Empire Eleven 2026

-- MAIN APPLICATION
addappid(4502700) -- Empire Eleven 2026

-- MAIN APP DEPOTS / PACKAGES
addappid(4502701, 1, "66dc2e613bed3d05cc240481794fd892752ec9d28989a680130805bbd0c936f9") -- Depot 4502701
addappid(4502702, 1, "408290b427a5525f4003ba57410da2d3efc8face8b873264b1cdee30d5c8bfe4") -- Depot 4502702
