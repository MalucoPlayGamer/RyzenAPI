-- Lua provided by RyzenAPI
-- Game: CosmoOdyssey:Trip to Mars

-- MAIN APPLICATION
addappid(2084010)
-- Game: addappid(2084010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084011, 1, "a17b0dd75bafcc900675e81c2bd8036aec038f873e26fe0034827fdedae42326")
