-- Lua provided by SkyAPI 
-- Game: Get To Work, Succubus-Chan!
addappid(1104340)
addappid(1104341, 1, "023f1d3fca0d4dbd646b329477b3909d31ae90f7608f1a49aceba59bf05acbfc")
addappid(1104342, 1, "65c510a8a53464ffc6223034e25778152c116853f06779a5707151ac0ff7cf53")
