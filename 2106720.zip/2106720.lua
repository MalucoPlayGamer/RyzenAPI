-- Lua provided by RyzenAPI
-- Game: Game: Port Cranes : Container Age

-- MAIN APPLICATION
addappid(2106720)
-- Game: addappid(2106720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106721, 1, "e83c3feb942faa4c01d1d3c60d94d169dab86953e8ee5edbbc6f80e0ff2d521e")
