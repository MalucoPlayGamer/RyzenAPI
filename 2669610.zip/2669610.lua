-- Lua provided by RyzenAPI
-- Game: Western Redemption

-- MAIN APPLICATION
addappid(2669610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669611, 1, "0d0948b71f2224a5efd963edd90d5824d269a12648049f5684829c907c9ed1a7")

