-- Lua provided by RyzenAPI
-- Game: Haven & Hearth

-- MAIN APPLICATION
addappid(3051280)

