-- Lua provided by RyzenAPI 
-- Game: Martha
addappid(1443300)
addappid(1443301, 1, "085151b111579f1e308d9e66f9889ac11ef247bf4b79d245e9b3d8ad708cdac5")
addappid(1443302, 1, "18600aac86d70426ad135f5ad9229c84b074a44096e13c13e572764868109eb4")
