-- Lua provided by RyzenAPI
-- Game: Game: AppID 347940

-- MAIN APPLICATION
addappid(347940)
-- Game: addappid(347940)

-- MAIN APP DEPOTS / PACKAGES
addappid(347941, 1, "a57687ac7f499c08f3a909dc5fe7b3c135251895de800aba09cd451c8a2f11a3")
