-- Lua provided by RyzenAPI
-- Game: Pantazil

-- MAIN APPLICATION
addappid(2177820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177821, 1, "5f874d5d7a5f15c3fce8c96f1d7ade0f2ebd4c893723dd3f96239ebe98545488")

