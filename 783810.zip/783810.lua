-- Lua provided by RyzenAPI 
-- Game: 牧剑：化神书(Tale Of Swords: Mystery Scroll)
addappid(783810)
addappid(783811, 1, "a89bf559fbd51af214d9cbf6ff1001a2f84d048d4f10f9eb21f9c68709332b9f")
