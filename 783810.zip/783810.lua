-- Lua provided by RyzenAPI
-- Game: 783810

-- MAIN APPLICATION
addappid(783810)
-- Game: addappid(783810)

-- MAIN APP DEPOTS / PACKAGES
addappid(783811, 1, "a89bf559fbd51af214d9cbf6ff1001a2f84d048d4f10f9eb21f9c68709332b9f")
