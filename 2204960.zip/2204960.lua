-- Lua provided by RyzenAPI
-- Game: Null G

-- MAIN APPLICATION
addappid(2204960)
addappid(2288270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204961, 1, "47da357335201ab5d3502d1276b4610b9758d49aef65ad59cbdffcbe36604d3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
