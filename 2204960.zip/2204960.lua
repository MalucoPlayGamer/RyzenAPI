-- Lua provided by RyzenAPI
-- Game: Null G

-- MAIN APPLICATION
addappid(2204960)
addappid(2288270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204961, 1, "47da357335201ab5d3502d1276b4610b9758d49aef65ad59cbdffcbe36604d3c")

