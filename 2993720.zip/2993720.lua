-- Lua provided by SkyAPI 
-- Game: Cage of Roses
addappid(2993720)
addappid(2993721, 1, "6f96c8a193127ad50c6dfcf2be462b2177adad318d889e718762efe13beaee9c")
addappid(3456510)
