-- Lua provided by RyzenAPI
-- Game: Rescue Team: Attack of the Atom

-- MAIN APPLICATION
addappid(3572870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3572871,0,"2c538539c9c61cf12b913cedbad61d70ae88e790029f4a4cc3e51473f6852b5f")

