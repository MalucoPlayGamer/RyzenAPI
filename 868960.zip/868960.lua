-- Lua provided by SkyAPI 
-- Game: AridFortress
addappid(868960)
addappid(868961, 1, "334990b5159a6460c91b40fe0d138dc198ae79ad38e167b2208d5a8db4e2adef")
