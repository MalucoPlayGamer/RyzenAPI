-- Lua provided by RyzenAPI
-- Game: addappid(2180210)

-- MAIN APPLICATION
addappid(2180210)
addappid(2929620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180211, 1, "7294fd7748f854a31fa2e0b55fb676d78ff5eae2f722b9e14f874b5855cc52b3")
