-- Lua provided by RyzenAPI
-- Game: Pichi Girl

-- MAIN APPLICATION
addappid(2214150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214151, 1, "2e932775d54400df63f27ec3a62d6c348e169d4f95962fd92c1c11d17a33d406")

