-- Lua provided by RyzenAPI
-- Game: Game: METAL SLUG X Soundtrack

-- MAIN APPLICATION
addappid(1940630)
-- Game: addappid(1940630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940631, 1, "3ecc0aacb590f100dbecda8c511fc6c744658ee7c4b5d98ef07002f30cbed5ef")
addappid(1940632, 1, "116fd054946d0ed59f7345e73070b9102295892c848963d0777ff89397ee28d3")
