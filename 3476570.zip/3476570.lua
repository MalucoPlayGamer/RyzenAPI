-- Lua provided by RyzenAPI 
-- Game: AppID 3476570
addappid(3476570)
addappid(3476571, 1, "2e8fdbf757075e69b462b7498b2c170f44f0bcf67bb1a0d58219d44308d0178e")
