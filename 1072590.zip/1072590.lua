-- Lua provided by RyzenAPI
-- Game: AppID 1072590

-- MAIN APPLICATION
addappid(1072590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072591, 1, "a85d9d4c1c60872cb88a13825a46ca0be80b14bdb1ebe7e74557d31f43ac7e2e")
