-- Lua provided by RyzenAPI
-- Game: The Backrooms Regret Demo

-- MAIN APPLICATION
addappid(2745940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2745941, 1, "af87399038163685b1bbc5980275a766ca69412a33ae88567afd531706f437a2")

