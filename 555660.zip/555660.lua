-- Lua provided by RyzenAPI
-- Game: 555660

-- MAIN APPLICATION
addappid(555660)
-- Game: addappid(555660)

-- MAIN APP DEPOTS / PACKAGES
addappid(555661, 1, "7f6eb6b1520e80950a221ea5f3bd0116344f8ca72585c99c8f1e45b5d5b2da0e")
