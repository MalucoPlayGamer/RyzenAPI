-- Lua provided by RyzenAPI
-- Game: Tales of the Mirror

-- MAIN APPLICATION
addappid(1649830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649831, 1, "86d0cba690a38d79d1c3c4c5649fd761dcb35e7c4ed2256d110f7614ac1c501d")
addappid(1649832, 1, "adae7a9b1874980586bba2e2cd950b45a8f2dcf6b4e6b404435dc71b4f85d75c")

