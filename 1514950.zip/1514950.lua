-- Lua provided by RyzenAPI
-- Game: addappid(1514950)

-- MAIN APPLICATION
addappid(1514950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1514951, 1, "e037d9239a9d6fd8c03fd5949bc3b7301d15a9d58906a7b9851dbd76b68af279")
