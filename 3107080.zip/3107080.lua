-- Lua provided by RyzenAPI
-- Game: Five Laps at Freddy's Demo

-- MAIN APPLICATION
addappid(3107080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107081, 1, "c5a7bf1257e8521762cde5a3e8113c417a6548ccf55f23f921080545d4ac08a4")
