-- Lua provided by RyzenAPI 
-- Game: AppID 714270
addappid(714270)
addappid(714271, 1, "c2900f8b94209eda82ddd6f9dddf9a72797222c02f264c1ec338172e34ba6df0")
