-- Lua provided by RyzenAPI
-- Game: imos LOFT

-- MAIN APPLICATION
addappid(714270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(714271, 1, "c2900f8b94209eda82ddd6f9dddf9a72797222c02f264c1ec338172e34ba6df0")

