-- Lua provided by RyzenAPI
-- Game: Nobodies: After Death

-- MAIN APPLICATION
addappid(1816950)
-- Game: addappid(1816950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816952,0,"2a10649d69ce02c4d5bd46276da32b7303b42afc070e7aa299f7700881a0bb7c")
