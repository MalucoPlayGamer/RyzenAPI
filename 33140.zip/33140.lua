-- Lua provided by RyzenAPI
-- Game: Alien Shooter Demo

-- MAIN APPLICATION
addappid(33140)

-- MAIN APP DEPOTS / PACKAGES
addappid(33141, 1, "0b0bd40eb0393e8c283c351079f9a0589e8f72871d266851a34ca4ed09202229")
