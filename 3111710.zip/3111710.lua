-- Lua provided by RyzenAPI
-- Game: 3111710

-- MAIN APPLICATION
addappid(3111710)
-- Game: addappid(3111710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111712,0,"cb399e2b2359bd26fae16a31ee5bc0bb5c7867273342efac49c506409dc88181")
