-- Lua provided by RyzenAPI
-- Game: 1345440

-- MAIN APPLICATION
addappid(1345440)
-- Game: addappid(1345440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345441, 1, "37dd62596d98e2e4751c938633b2a0a579764586d36cf70ff8fca193a38d8cff")
