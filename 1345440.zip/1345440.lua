-- Lua provided by RyzenAPI 
-- Game: Toy Tanks
addappid(1345440)
addappid(1345441, 1, "37dd62596d98e2e4751c938633b2a0a579764586d36cf70ff8fca193a38d8cff")
