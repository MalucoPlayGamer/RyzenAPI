-- Lua provided by RyzenAPI
-- Game: Taiji

-- MAIN APPLICATION
addappid(1141580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141581, 1, "7fc312e566fb2642b3c65e9c6fef9b339763dc11adc81664630917f9babe73f7")

