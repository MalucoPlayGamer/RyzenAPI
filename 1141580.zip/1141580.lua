-- Lua provided by SkyAPI 
-- Game: Taiji
addappid(1141580)
addappid(1141581, 1, "7fc312e566fb2642b3c65e9c6fef9b339763dc11adc81664630917f9babe73f7")
