-- Lua provided by RyzenAPI
-- Game: Kudamono Party

-- MAIN APPLICATION
addappid(2755870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755873,0,"7b934b61d789b643df076667cea58eca5f41130042b4df9c81875ede728fd30c")
addappid(2755874,0,"4340f6cabb598639aa65c611f0097cf3dbc21008fd66b8f7a0d1ec219c36e099")
