-- Lua provided by RyzenAPI
-- Game: addappid(876910)

-- MAIN APPLICATION
addappid(876910)

-- MAIN APP DEPOTS / PACKAGES
addappid(876911, 1, "58c7f23a0456e62a9a64898c38869d96666ef8ced0efc9b4d33c381350266e33")
