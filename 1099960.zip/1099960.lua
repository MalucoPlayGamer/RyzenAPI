-- Lua provided by RyzenAPI
-- Game: Mini Tone - Minimalist Puzzle

-- MAIN APPLICATION
addappid(1099960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099961, 1, "bde1caa231fe525403c594e1f9518b8c7bdf23ec0c55c62a583129d179274e35")
addappid(1099962, 1, "499cd2d770fae98b3e941eeb8e4d93be339395930bf5093a20aa903b18c232fb")

