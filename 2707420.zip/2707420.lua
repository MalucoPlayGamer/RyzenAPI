-- Lua provided by RyzenAPI
-- Game: 2707420

-- MAIN APPLICATION
addappid(2707420)
-- Game: addappid(2707420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707421, 1, "affab90ea176c4f4451aa06b9f0b9bcb316f527bc7a46bf16489a3fa606b5393")
addappid(2707422, 1, "89aac3ea9f039778b84638eae6795d8f76a3cd73cc4d17c5685b6a2dc96215fe")
