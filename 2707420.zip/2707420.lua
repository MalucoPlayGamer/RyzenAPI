-- Lua provided by RyzenAPI
-- Game: 3D Watermelon Game

-- MAIN APPLICATION
addappid(2707420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2707421, 1, "affab90ea176c4f4451aa06b9f0b9bcb316f527bc7a46bf16489a3fa606b5393")
addappid(2707422, 1, "89aac3ea9f039778b84638eae6795d8f76a3cd73cc4d17c5685b6a2dc96215fe")