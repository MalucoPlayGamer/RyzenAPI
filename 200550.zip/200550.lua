-- Lua provided by RyzenAPI 
-- Game: AppID 200550
addappid(200550)
addappid(200551, 1, "a9ff3aa2654221de969b16b66d52fbb3430131bf7434b08d3642df0efb4e79c1")
addappid(200552, 1, "bab84eceecebeaecb0b12e23cbe75cb8bfd5b15f0f8a923a4365b7452c3c4c66")
addappid(200553, 1, "d48808b47cc2090f4d6953d5c29f36064e6eb2c03435c4846d4dc000bdedcaf2")
addappid(200554, 1, "57ff6e0be3b122f4f4a14d91521aa449fb9a83768223cbfda521417c8f4724e9")
