-- 4414400's Lua and Manifest Created by Hubcap Manifest
-- UNIT 42: Adrift in Space
-- Created: August 24, 2026 at 11:00:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4414400, 1, "83a1bea9f962f01cffcf50ea9c48c9c04ccee08e841e5023bf0887ddc99dc7d0") -- UNIT 42: Adrift in Space
-- MAIN APP DEPOTS
addappid(4414401, 1, "5ca977a337781d16a4aa35224449a76b6f1d81c589ae5c2f6fc0d178dd760798") -- Depot 4414401
setManifestid(4414401, "3864122232981318958", 1023846276)
addappid(4414402, 1, "067e440fcb67eafbb519aed1564808180175daa7662454c1d18badda1bd4459d") -- Depot 4414402
setManifestid(4414402, "5640856014504509353", 995165352)