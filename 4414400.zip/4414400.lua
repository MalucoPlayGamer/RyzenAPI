-- Lua provided by RyzenAPI
-- Game: UNIT 42: Adrift in Space

-- MAIN APP DEPOTS / PACKAGES
addappid(4414400, 1, "83a1bea9f962f01cffcf50ea9c48c9c04ccee08e841e5023bf0887ddc99dc7d0") -- UNIT 42: Adrift in Space
addappid(4414401, 1, "5ca977a337781d16a4aa35224449a76b6f1d81c589ae5c2f6fc0d178dd760798") -- Depot 4414401
addappid(4414402, 1, "067e440fcb67eafbb519aed1564808180175daa7662454c1d18badda1bd4459d") -- Depot 4414402

