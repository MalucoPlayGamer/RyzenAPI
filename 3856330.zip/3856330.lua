-- Lua provided by RyzenAPI
-- Game: AppID 3856330

-- MAIN APPLICATION
addappid(3856330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3856331, 1, "057b718ed4c6de51a2c77aad43ba17734a0419b31c2ff2eae063a98d7c2e95d3")

