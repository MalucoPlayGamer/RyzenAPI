-- Lua provided by RyzenAPI
-- Game: Surge

-- MAIN APPLICATION
addappid(951690)

-- MAIN APP DEPOTS / PACKAGES
addappid(951691, 1, "813c9e0c73400b8a0d4d9f21fdf7ac5193edc05cf9d3a649c593e81977fc5aaf")

