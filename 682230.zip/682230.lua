-- Lua provided by RyzenAPI
-- Game: addappid(682230)

-- MAIN APPLICATION
addappid(682230)

-- MAIN APP DEPOTS / PACKAGES
addappid(682231, 1, "ae5d86c59508dcbaf964c206545d768903a8e451de69812c718525bdf62f1448")
