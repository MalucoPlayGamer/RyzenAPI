-- Lua provided by RyzenAPI
-- Game: Cubiscape 2

-- MAIN APPLICATION
addappid(1441570)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1470400)
