-- Lua provided by RyzenAPI
-- Game: Cubiscape 2

-- MAIN APPLICATION
addappid(1441570)

