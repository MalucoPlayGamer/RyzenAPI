-- Lua provided by RyzenAPI
-- Game: NOBUNAGA'S AMBITION: Tenkasousei with Power Up Kit

-- MAIN APPLICATION
addappid(628140)

-- MAIN APP DEPOTS / PACKAGES
addappid(628141, 1, "db7b2db2a65d2ba82ad9e66301bc5375eb926cb37f79b438b747c5ce644f5499")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
