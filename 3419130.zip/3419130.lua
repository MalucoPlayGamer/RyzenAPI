-- Lua provided by RyzenAPI
-- Game: Game: Deadly Quiet

-- MAIN APPLICATION
addappid(3419130)
-- Game: addappid(3419130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3419131, 1, "5c1294557826bc32403944e266054195d8544dd2bfe71d870b21f6b05dc68186")
