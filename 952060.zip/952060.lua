addappid(952060)
addappid(952062, 1, "fdfbc9447d8302b8a7b325ec2bccaa81e77cef9d8289ead20348a702cce53e40")
-- setManifestid(952062, "8863028453226553691", 0)
addappid(952063, 1, "e5e87afc561b9663966c6f3fb6a9de1dac7466dfb32db183fbcfbeb5f011257b")
-- setManifestid(952063, "7504296696893507629", 0)
addappid(952064, 1, "438a8c22458963cec5059bec6e195c24b9988cf2c2d2a33298db12146597812c")
-- setManifestid(952064, "4916965303803227400", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]