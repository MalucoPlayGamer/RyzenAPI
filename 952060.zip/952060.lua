-- Lua provided by RyzenAPI
-- Game: Resident Evil 3

-- MAIN APPLICATION
addappid(1108280)
addappid(1158730)
addappid(1295160)
addappid(1295350)
addappid(1348140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(952060, 1, "33f1f38944fcd86f77d1c0efcf06ea0f892a2997c6912166a5445f486137670c")
addappid(952061, 1, "59cd6a454139aeaf999cc3dde8aeb2e0c4dd0e1264c9d87bf0a7e702d892e68a") -- (windows, 64-bit)
addappid(952062, 1, "fdfbc9447d8302b8a7b325ec2bccaa81e77cef9d8289ead20348a702cce53e40") -- (windows, 64-bit)
addappid(952063, 1, "e5e87afc561b9663966c6f3fb6a9de1dac7466dfb32db183fbcfbeb5f011257b") -- (windows, 64-bit)
addappid(952064, 1, "438a8c22458963cec5059bec6e195c24b9988cf2c2d2a33298db12146597812c") -- (windows, 64-bit)
addappid(1108280, 1, "2c80f9e638cea673510ec5562456040bb00c6ef138fb7be77c691ecab6118199") -- (windows)
addappid(1295161, 1, "1b2d845f146b02222cb7b6356e33b08f6ddebd1dd4a80f72a13dca595c653195")
addappid(1295162, 1, "6a51fcfe3d19507c47e01b8af456faf19ebb973b8a0ad44aa4fe8283a6a66ae4")
addappid(1295163, 1, "ff01056c3ea3e3351ebc34addfcce478f69352fff3aec42833878649decc968c")
addappid(1295164, 1, "2028ac8dcda1d545c85a4377c099117ce59d6dc8e7bd6f6b7a543b0a28ddaec3") -- Japanese
addappid(1295165, 1, "a2d72fa757340931403176e139f35d9076553663031a45fd70d76875c2c21384") -- Japanese
addappid(1295166, 1, "f7e6c8bcdc4151485d804f5d3d1b7db7b10ea29fd70f663370eaff3d3a2d1637") -- Japanese
addappid(1295350, 1, "dbe021a1825f0f53da71272f5fd0f4e37669b27d0e00393fcc472b70f515dce7") -- (windows)

