-- Lua provided by RyzenAPI
-- Game: n-body

-- MAIN APPLICATION
addappid(1519770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519771, 1, "250224a42d174c2eda7642f8532a1ddc6428084674d1417c0d7e395f4d6c7e8f")
addappid(1519772, 1, "e5bd400e092a52acadddb1d1e794e5d9b435d6eace5eab593613284b90154f73")

