-- Lua provided by RyzenAPI
-- Game: Lost Ark

-- MAIN APPLICATION
addappid(1599340)
addappid(1656220)
addappid(1656221)
addappid(1656222)
addappid(1697950)
addappid(1869700)
addappid(1869701)
addappid(1869702)
addappid(2283590)
addappid(2283591)
addappid(2283592)
addappid(2471310)
addappid(2471311)
addappid(2471312)
addappid(2612160)
addappid(2612170)
addappid(2612180)
addappid(2638590)
addappid(2968750)
addappid(3166380)
addappid(3200700)
addappid(3200710)
addappid(3200720)
addappid(3200730)
addappid(3346540)
addappid(3346550)
addappid(3346560)
addappid(3346570)
addappid(3735360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1599341,0,"a92b3dd6eedf5645374d5361557211ba7628c6f23185ea14b47bbaa46722b993")
addappid(1877840,0,"c912c072640806601f0d8959272feb7dd6a7eb97f5bea6afcce84c6b16a3c6a6")

