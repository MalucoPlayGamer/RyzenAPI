-- Lua provided by RyzenAPI
-- Game: Lost Ark

-- MAIN APPLICATION
addappid(1599340)
-- Game: addappid(1599340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599341, 1, "a92b3dd6eedf5645374d5361557211ba7628c6f23185ea14b47bbaa46722b993")
