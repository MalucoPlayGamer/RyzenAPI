-- Lua provided by RyzenAPI
-- Game: addappid(1608450)

-- MAIN APPLICATION
addappid(1608450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608451, 1, "d0cdc438b04d2b7111117e749a08137f5aa9d11b1a474fb2628e3629a8b4fd0d")
