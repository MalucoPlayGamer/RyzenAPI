-- Lua provided by RyzenAPI
-- Game: Army General

-- MAIN APPLICATION
addappid(606950)

-- MAIN APP DEPOTS / PACKAGES
addappid(606951, 1, "3e905ca23ef9dfa2798b8e66e9bc239fa33bb7298962def90576ea5cf4ce676b")
addappid(606952, 1, "91a4fb38ee518f2ceb53fe9e69f218e757a0429dc8f4de0a80900248079b955a")
