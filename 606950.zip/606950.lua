-- Lua provided by RyzenAPI
-- Game: Army General

-- MAIN APPLICATION
addappid(606950)

-- MAIN APP DEPOTS / PACKAGES
addappid(606951, 1, "3e905ca23ef9dfa2798b8e66e9bc239fa33bb7298962def90576ea5cf4ce676b")
addappid(606952, 1, "91a4fb38ee518f2ceb53fe9e69f218e757a0429dc8f4de0a80900248079b955a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
