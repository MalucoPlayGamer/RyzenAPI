-- Lua provided by RyzenAPI 
-- Game: Marble Land
addappid(503280)
addappid(503281, 1, "7502f6fbbee1ce5d1568389766d7ed8f605301bb2e5542957cc9978d6dcba071")
addappid(503282, 1, "1b223b87ba78d62a3fb65cde7bdc28c84581dc59108e2d7ac3849cdf7b20f0be")
addappid(503283, 1, "17280f740142e8e26807eb4c5b29347fa181dc341e38514d871096eccb56a074")
