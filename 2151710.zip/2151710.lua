-- Lua provided by RyzenAPI
-- Game: Game: Singularity Runner

-- MAIN APPLICATION
addappid(2151710)
addappid(2167000)
-- Game: addappid(2151710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151711, 1, "17bbfe352faafc9cbe8399e8403f5aa4e6227bf49cf0087f9d2752e4c4db09c8")
addappid(2151712, 1, "a186588321cc964790540209057f720cd0754bf15870a9837ed51d346fe6e175")
