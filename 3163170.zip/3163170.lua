-- Lua provided by RyzenAPI 
-- Game: A Few Nights With : Francesca
addappid(3163170)
addappid(3163171, 1, "298ee9ee6b1571e825d581b05b69760489711500e3d601b7ae4d3cb658b51e84")
