-- Lua provided by RyzenAPI
-- Game: A Few Nights With : Francesca

-- MAIN APPLICATION
addappid(3163170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163171, 1, "298ee9ee6b1571e825d581b05b69760489711500e3d601b7ae4d3cb658b51e84")

