-- Lua provided by RyzenAPI 
-- Game: KAMI
addappid(272040)
addappid(272041, 1, "029b941583dbf6ae6d37ca657216b42b5e1a8cec8b6952f9c2684706406e3582")
addappid(272042, 1, "be9cfb2e3501612eba77d4198ad63311315eaf637c1f40cde2559cff0dffcb39")
