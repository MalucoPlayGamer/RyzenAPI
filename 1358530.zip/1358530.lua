-- Lua provided by RyzenAPI
-- Game: 1358530

-- MAIN APPLICATION
addappid(1358530)
-- Game: addappid(1358530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358531, 1, "30f7e82266c7691384d3c6ea7dc5037f45b7b7a08e923e62cd9dc049ff7420a5")
addappid(1358532, 1, "6a22b8a6a201f7beb113f17b7c5fab7d86b8ed0e4ae29d4691ed06540cd2d77b")
addappid(1358533, 1, "3b4b1ee9cf3de69f37d06fdd40b72cec4e1839fcfb0d0b4bf160ce5c745efd5f")
