-- Lua provided by RyzenAPI
-- Game: Game: AppID 736510

-- MAIN APPLICATION
addappid(736510)
-- Game: addappid(736510)

-- MAIN APP DEPOTS / PACKAGES
addappid(736511, 1, "7ca48d1c29b13065bada9678e915718818cf08742c3982f36d7b0721c4230717")
