-- Lua provided by RyzenAPI
-- Game: Adrorium Playtest

-- MAIN APPLICATION
addappid(1641400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641402,0,"6200745a5d3f726e89ac1092ecdeeede162a39b197e25dd1e87aad5fb9cf6197")

