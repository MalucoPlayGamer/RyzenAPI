-- Lua provided by RyzenAPI
-- Game: addappid(1441300)

-- MAIN APPLICATION
addappid(1441300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441301, 1, "5e07c588f05f0b7f16aa752da77bb3b5db795c8bf87c5e86f5c73cda05e70e2e")
