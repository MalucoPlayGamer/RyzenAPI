-- Lua provided by RyzenAPI
-- Game: The Cesspit

-- MAIN APPLICATION
addappid(3003470)
-- Game: addappid(3003470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3003471, 1, "3421ba580fefbba3dcc187a6ae030916d2eb928bdce7d04f149dd2bf5d4bfcd3")
