-- Lua provided by RyzenAPI
-- Game: A Dark Room ®

-- MAIN APPLICATION
addappid(2460660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460662,0,"9ce1f7311aefa7b06525771adc548ae78364eb1fbf3f605a4f367a26aeea64b8")
addappid(2460663,0,"4053dece6802159e6bc255f78dac08c93c01fa763844eec9932a86183db85d23")
addappid(2460664,0,"6779fb5c8471a94884d4145f50153f03817bb4320c01975fcfbc4daa0f0a5ed0")

