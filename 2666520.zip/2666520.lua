-- Lua provided by RyzenAPI
-- Game: End Of Life

-- MAIN APPLICATION
addappid(2666520)
-- Game: addappid(2666520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666521, 1, "654ff7781cf60669274277c247f30b9fe37727bbb283ee1d045253bc04c561b9")
