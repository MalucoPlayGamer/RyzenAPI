-- Lua provided by RyzenAPI
-- Game: setManifestid(2550462,"4998634541176325371")

-- MAIN APPLICATION
addappid(2550460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550462,0,"c185ed15c68c5d48f48ceb89ecf01a6f2c2884b7a0060dbd5d348ebeceabe764")

