-- Lua provided by RyzenAPI
-- Game: Maze Burrow

-- MAIN APPLICATION
addappid(1244190)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1244191, 1, "46f585f9b3634d2c334d73b5e15a4b368993597dc3f9e6665f0284cb4d77cdf0")

