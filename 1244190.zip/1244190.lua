-- Lua provided by RyzenAPI
-- Game: Maze Burrow

-- MAIN APPLICATION
addappid(1244190)
-- Game: addappid(1244190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244191, 1, "46f585f9b3634d2c334d73b5e15a4b368993597dc3f9e6665f0284cb4d77cdf0")
