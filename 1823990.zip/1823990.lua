-- Lua provided by RyzenAPI
-- Game: 1823990

-- MAIN APPLICATION
addappid(1823990)
-- Game: addappid(1823990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823991, 1, "59aab942d9821df15cd3b042a7faf96222812f5afd2be7ae1eda30961ef4bccf")
