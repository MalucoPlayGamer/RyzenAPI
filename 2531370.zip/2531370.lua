-- Lua provided by RyzenAPI
-- Game: Blacksmith. Song of two Kings.

-- MAIN APPLICATION
addappid(2531370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531371, 1, "af1d525587fc37634d93a7cf23dbb57a98eaecf599c821a4b169ae0cd0542ca2")

