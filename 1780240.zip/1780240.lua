-- Lua provided by RyzenAPI
-- Game: Game: AppID 1780240

-- MAIN APPLICATION
addappid(1780240)
-- Game: addappid(1780240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780241, 1, "7e1beb98bb278ce12759aa53ba447aae3cf05ba98e6ca90bd7f4d61e3faa7dec")
