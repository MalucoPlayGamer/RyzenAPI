-- Lua provided by RyzenAPI
-- Game: Game: Hellblade: Senua's Sacrifice VR Edition

-- MAIN APPLICATION
addappid(747350)
-- Game: addappid(747350)

-- MAIN APP DEPOTS / PACKAGES
addappid(747351, 1, "5aca67e1bb0eb403e42a8b138a8fa7f7b77b10bc864372214cdaa87457ae6f11")
