-- Lua provided by RyzenAPI
-- Game: addappid(415240)

-- MAIN APPLICATION
addappid(415240)

-- MAIN APP DEPOTS / PACKAGES
addappid(415242,0,"cbfd32d4e7d7daab20be352e7bd5d10243b314b710b4f70beb235b03271d047f")
addappid(415245,0,"be75ff4352b77480c7e90600cfd49ce7ae625b2fa6c851277d1fd3349a0e2777")
