-- Lua provided by RyzenAPI
-- Game: Arizona Derby

-- MAIN APPLICATION
addappid(661290)
-- Game: addappid(661290)

-- MAIN APP DEPOTS / PACKAGES
addappid(661292,0,"0c7dc66a285350052b00ec26ba894cd1090424226d129f6e15aefc4947a95681")
addappid(1123120,0,"c29ba5de3485dba1114b8d2f86357cbfeba1c61d43636b583589629b596b4a95")
