-- Lua provided by RyzenAPI
-- Game: Arizona Derby

-- MAIN APPLICATION
addappid(661290)

-- MAIN APP DEPOTS / PACKAGES
addappid(661292,0,"0c7dc66a285350052b00ec26ba894cd1090424226d129f6e15aefc4947a95681")
addappid(1123120,0,"c29ba5de3485dba1114b8d2f86357cbfeba1c61d43636b583589629b596b4a95")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
