-- Lua provided by RyzenAPI
-- Game: addappid(411680)

-- MAIN APPLICATION
addappid(411680)

-- MAIN APP DEPOTS / PACKAGES
addappid(411682,0,"ce4909f4c2e95ee3770db8482c3f0d75d5d882aa7be8bec35fb1a153435ea53d")
addappid(411683,0,"b991dd748af9f5564439d6b22d7bb45e6e7e6fd5e82663d5804420aecbabc382")
