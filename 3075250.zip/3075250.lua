-- Lua provided by RyzenAPI
-- Game: The Haunting Eyes

-- MAIN APPLICATION
addappid(3075250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075251, 1, "69563a67975bbae970e6f8a0b6754e75e4da4f20a4b6295b3fd0c860af9ff565")

