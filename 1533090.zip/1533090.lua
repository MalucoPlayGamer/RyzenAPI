-- Lua provided by RyzenAPI
-- Game: addappid(1533090)

-- MAIN APPLICATION
addappid(1533090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533091, 1, "1ae5943af80d3f2e296aab8462b9a4cd30946e91d86f0a8f709af324273c6fd5")
