-- Lua provided by RyzenAPI
-- Game: addappid(1871000)

-- MAIN APPLICATION
addappid(1871000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871001, 1, "210576d6353ecebe0a5c19170288fa8f9aa061b07c7ee59acbe27db87e16b8b2")
