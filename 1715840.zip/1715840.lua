-- Lua provided by RyzenAPI
-- Game: 25 Layers of Pain

-- MAIN APPLICATION
addappid(1715840)
-- Game: addappid(1715840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715841, 1, "b3026817b83572e310d9478ee34b94dd4e0fc4512a04f92587f0f1425022d88d")
addappid(1715842, 1, "17645988b13ec05ceeaaac5afe762f1f48aa966a2f9fc1bb31f15a0103944ea0")
