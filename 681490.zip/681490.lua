-- Lua provided by RyzenAPI
-- Game: dontbegrey

-- MAIN APPLICATION
addappid(681490)

-- MAIN APP DEPOTS / PACKAGES
addappid(681491,0,"102a13ef4fcf795a3a0778d979351365f4fc1b9b2eed60e8a78e8029183ccb24")
addappid(681492,0,"c794ba26a380779ee669ac8fa2cd00106dcaf4861d6eb2fcf08cdea23f070642")
addappid(681493,0,"e632aa367111b7c2cfe7f14fcc0ee1e61b0488c872f8f22065e26ea26f3ffb69")
addappid(681494,0,"2e64e1a3b02000d3c6cf0df0138192effce846c3d74de7428bc307a365595bec")

