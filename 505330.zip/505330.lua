-- Lua provided by RyzenAPI
-- Game: Apocalipsis

-- MAIN APPLICATION
addappid(505330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(505331, 1, "54f38b36afe49fa81bb071378374cbfe1d97c50b7727080ef88f77caf44fd033")
addappid(505332, 1, "01a289d5834eefb1479b8aa1706902563045c1f7f1216b6929a629f52936b476")
addappid(813500, 0, "56d3c4870da02b608aaf7d5cc0add46aeb545643c6bb8e6f07d1d4779987d29e")

