-- Lua provided by SkyAPI 
-- Game: Lust Theory Season 2
addappid(1754870)
addappid(1754871, 1, "6a27d099a708f5ea95f72c6e16857cded16565e8bf7003e54d8d1f17f7ec7112")
addappid(2358650, 0, "9e5a1b514474459edfb8fcba69e648ab5eabd47712c5bad9cd1a24657c7146f2")
