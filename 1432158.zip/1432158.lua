-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1432158)
-- Game: addappid(1432158)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432158,0,"39d2ba8f74db0cfea29f51f9c86c4149b4b0920fc0a3c9caddf12daf5bcf2a21")
