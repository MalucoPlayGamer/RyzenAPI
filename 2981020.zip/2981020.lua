-- Lua provided by RyzenAPI
-- Game: Game: AppID 2981020

-- MAIN APPLICATION
addappid(2981020)
-- Game: addappid(2981020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981021, 1, "53b433e58b19e03fbaea6a6497fb550dda23e2b7d980f0f467abf30291b3a8db")
