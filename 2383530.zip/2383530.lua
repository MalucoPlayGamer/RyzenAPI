-- Lua provided by RyzenAPI
-- Game: 2383530

-- MAIN APPLICATION
addappid(2383530)
-- Game: addappid(2383530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383531, 1, "bdd7403d1bef75f14eac6cdee7ac174ae9265952c5bdc700d3f8475800e0a0a2")
