-- Lua provided by RyzenAPI
-- Game: 659250

-- MAIN APPLICATION
addappid(659250)
-- Game: addappid(659250)

-- MAIN APP DEPOTS / PACKAGES
addappid(659251, 1, "81f7d5ad325857831c711b1d540a1336b22973ad6a5a8351f93ae93a2fc61edd")
