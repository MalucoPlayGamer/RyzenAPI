-- Lua provided by RyzenAPI
-- Game: Genesis - 创世争霸

-- MAIN APPLICATION
addappid(755080)

-- MAIN APP DEPOTS / PACKAGES
addappid(755081, 1, "30990d8ff9a975c45a51d6042cbfc63da426066747ab6fd9246e7fb2b48af3c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
