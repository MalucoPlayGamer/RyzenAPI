-- Lua provided by RyzenAPI
-- Game: Game: Genesis - 创世争霸

-- MAIN APPLICATION
addappid(755080)
-- Game: addappid(755080)

-- MAIN APP DEPOTS / PACKAGES
addappid(755081, 1, "30990d8ff9a975c45a51d6042cbfc63da426066747ab6fd9246e7fb2b48af3c1")
