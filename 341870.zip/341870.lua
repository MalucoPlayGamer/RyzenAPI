-- Lua provided by RyzenAPI
-- Game: addappid(341870)

-- MAIN APPLICATION
addappid(341870)

-- MAIN APP DEPOTS / PACKAGES
addappid(341871, 1, "f842648b5645e393c252d0f640da581301c98b7cffa6049b4ca047f27c6835d3")
