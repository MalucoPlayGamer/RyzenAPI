-- Lua provided by RyzenAPI
-- Game: Game: Resident Evil (1996)

-- MAIN APPLICATION
addappid(4249100)
-- Game: addappid(4249100)

-- MAIN APP DEPOTS / PACKAGES
addappid(4249101, 1, "53fc73ab0ec4b9e6fa4c415e4613c5bdc044ae2462c6c4d898c070822af245e0")
addappid(4249102, 1, "cb84cbcb9b6a7d9781651ff812f235d78189a6b8603a6a8d55e23029b727b5d6")
addappid(4249103, 1, "f118404bcd07c1213340ef0763197e9fcbce44aaeb046f5c467ffae95d585f20")
