-- Lua provided by RyzenAPI 
-- Game: METAL EDEN
addappid(990380)
addappid(990381, 1, "8609143fc4bd7b68bc154ba5e0ca2a7f6a148b3ff593cbaf70b9938821696267")
