-- Lua provided by RyzenAPI 
-- Game: AppID 963490
addappid(963490)
addappid(963491, 1, "141344a0ec0cecfe2c63c622aa4db2ee996c8203884dc9c9515e293fb7bc9eb1")
