-- Lua provided by RyzenAPI
-- Game: 619550

-- MAIN APPLICATION
addappid(619550)
addappid(802280)
-- Game: addappid(619550)

-- MAIN APP DEPOTS / PACKAGES
addappid(619551, 1, "9799fc0e6fbbad8dd2ed34e762095e4c5c32819af69a3e734c8faa29b0537f1f")
