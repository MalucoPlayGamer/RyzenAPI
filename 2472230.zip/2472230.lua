-- Lua provided by RyzenAPI
-- Game: Game: The Inner Demons

-- MAIN APPLICATION
addappid(2472230)
-- Game: addappid(2472230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472231, 1, "7441f52422ae0fbf939ab91195bd6680ce14c8f79250587a2ffab66844863342")
