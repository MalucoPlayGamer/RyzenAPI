-- Lua provided by RyzenAPI 
-- Game: The Inner Demons
addappid(2472230)
addappid(2472231, 1, "7441f52422ae0fbf939ab91195bd6680ce14c8f79250587a2ffab66844863342")
