-- Lua provided by RyzenAPI
-- Game: 1418080

-- MAIN APPLICATION
addappid(1418080)
-- Game: addappid(1418080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418081, 1, "84e8d653380e7460ad96ae84b0ba8c5f69d59003831e74247f461afb02e812da")
