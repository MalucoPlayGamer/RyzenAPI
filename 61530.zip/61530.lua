-- Lua provided by RyzenAPI
-- Game: addappid(61530)

-- MAIN APPLICATION
addappid(61530)

-- MAIN APP DEPOTS / PACKAGES
addappid(61531, 1, "bc12df52f29d94cd867dd0fd6aa025ea339e2994c7814a7c9ef4b5f95c35ffea")
