-- Lua provided by RyzenAPI
-- Game: Game: PLANETOIDS

-- MAIN APPLICATION
addappid(2090630)
-- Game: addappid(2090630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090631, 1, "b59743056d58be8e760d34e7a4e99ece45a962afd7a7d7b2bfdd2cec027db0a8")
