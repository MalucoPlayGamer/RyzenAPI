-- Lua provided by SkyAPI 
-- Game: Altar
addappid(3448320)
addappid(3448321, 1, "53be4d3023dcf75935b58ec55b574dd122486b6d38eed5db9ecac26cb61bc8ad")
