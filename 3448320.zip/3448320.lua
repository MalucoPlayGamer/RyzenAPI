-- Lua provided by RyzenAPI
-- Game: Altar

-- MAIN APPLICATION
addappid(3448320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3448321, 1, "53be4d3023dcf75935b58ec55b574dd122486b6d38eed5db9ecac26cb61bc8ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
