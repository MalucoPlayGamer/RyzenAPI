-- Lua provided by RyzenAPI
-- Game: 3448320

-- MAIN APPLICATION
addappid(3448320)
-- Game: addappid(3448320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3448321, 1, "53be4d3023dcf75935b58ec55b574dd122486b6d38eed5db9ecac26cb61bc8ad")
