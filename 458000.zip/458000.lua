-- Lua provided by RyzenAPI
-- Game: March of the Living

-- MAIN APPLICATION
addappid(458000)
addappid(470230)
addappid(502560)

-- MAIN APP DEPOTS / PACKAGES
addappid(458001, 1, "4fc6f1347d9b4c8a21ed37df3443957495dd0e1b1f0426b894b3ffa5afbec848")

