-- Lua provided by RyzenAPI
-- Game: Just Sign!

-- MAIN APPLICATION
addappid(2062910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062911, 1, "25946d9284f56d258eacca7c5977674beb109f255a3c1fa17e0df9eb81d05d10")
