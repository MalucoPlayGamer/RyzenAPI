-- Lua provided by RyzenAPI
-- Game: Bubble Tea : game for thinking and imagination

-- MAIN APPLICATION
addappid(1311690)
addappid(1314370)
addappid(1414450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(1311691, 1, "eedd6520bad6936dba75cdb7c0bd855c204459706a14502f247a0fe9d959468c")
addappid(1311692, 1, "d19a4f3809f2ec76c2cdfa10f5c20e575b46f023b7824e3034a6b892c40b1279")

