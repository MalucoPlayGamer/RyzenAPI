-- Lua provided by RyzenAPI
-- Game: Game: Bubble Tea : game for thinking and imagination

-- MAIN APPLICATION
addappid(1311690)
-- Game: addappid(1311690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311691, 1, "eedd6520bad6936dba75cdb7c0bd855c204459706a14502f247a0fe9d959468c")
addappid(1311692, 1, "d19a4f3809f2ec76c2cdfa10f5c20e575b46f023b7824e3034a6b892c40b1279")
