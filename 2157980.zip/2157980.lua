-- Lua provided by RyzenAPI
-- Game: DinoBlits

-- MAIN APPLICATION
addappid(2157980)
-- Game: addappid(2157980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157981, 1, "45d0a7816cc64b6b1dd795a49690acf9446a633c703246cfe13098eb01898ae4")
