-- Lua provided by RyzenAPI
-- Game: RoboArena

-- MAIN APPLICATION
addappid(1051870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051871, 1, "7d428cd37630374e2df70ff7fa8666f2622ec01b41a9fc9b5af06266ef93b75b")
