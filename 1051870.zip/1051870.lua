-- Lua provided by RyzenAPI 
-- Game: AppID 1051870
addappid(1051870)
addappid(1051871, 1, "7d428cd37630374e2df70ff7fa8666f2622ec01b41a9fc9b5af06266ef93b75b")
