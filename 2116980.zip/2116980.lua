-- Lua provided by RyzenAPI
-- Game: 2116980

-- MAIN APPLICATION
addappid(2116980)
-- Game: addappid(2116980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116981, 1, "dfeb03eeaa6fa6c1722ce473b5eaffab86f171284444e70fa217905ef3c77f28")
