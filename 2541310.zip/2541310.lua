-- Lua provided by RyzenAPI
-- Game: The Cable Guy

-- MAIN APPLICATION
addappid(2541310)
-- Game: addappid(2541310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541311, 1, "4554769ca81fd9a66f8f10c9f4c63521ab7c53d86badc6d43b9549deee817fd3")
