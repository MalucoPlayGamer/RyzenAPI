-- Lua provided by RyzenAPI
-- Game: The Cable Guy

-- MAIN APPLICATION
addappid(2541310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2541311, 1, "4554769ca81fd9a66f8f10c9f4c63521ab7c53d86badc6d43b9549deee817fd3")

