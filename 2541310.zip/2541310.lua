-- Lua provided by SkyAPI 
-- Game: The Cable Guy
addappid(2541310)
addappid(2541311, 1, "4554769ca81fd9a66f8f10c9f4c63521ab7c53d86badc6d43b9549deee817fd3")
