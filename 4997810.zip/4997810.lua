-- Lua provided by RyzenAPI
-- Game: My Tiny Pickaxe

-- MAIN APPLICATION
addappid(4997810) -- My Tiny Pickaxe

-- MAIN APP DEPOTS / PACKAGES
addappid(4997811, 1, "af1d8a9feeec8fdd5d950dfda411fee2f4d13666e1bea07b5734c35f8532deb0") -- Depot 4997811
