-- Lua provided by RyzenAPI
-- Game: Game: BERENICE: Videogame

-- MAIN APPLICATION
addappid(3629550)
-- Game: addappid(3629550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629551, 1, "599435a40efd7f77df11f8084d27bb40132b165c273056ea50649c4dc4014a98")
