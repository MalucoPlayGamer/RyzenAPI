-- Lua provided by RyzenAPI
-- Game: AppID 1312710

-- MAIN APPLICATION
addappid(1312710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312711, 1, "2f84513dffa15f5243af058c45b75be9dd7ecb69828c14bd09579a9ed2beb8a6")
