-- Lua provided by RyzenAPI
-- Game: Frequency Dissonance

-- MAIN APPLICATION
addappid(1884390)
-- Game: addappid(1884390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884391, 1, "bc7a266ef6f7f56c3a49848ef3966ba4c3725022735467ef6833041d05f19384")
