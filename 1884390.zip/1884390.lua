-- Lua provided by SkyAPI 
-- Game: Frequency Dissonance
addappid(1884390)
addappid(1884391, 1, "bc7a266ef6f7f56c3a49848ef3966ba4c3725022735467ef6833041d05f19384")
