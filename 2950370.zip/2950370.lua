-- Lua provided by RyzenAPI
-- Game: 2950370

-- MAIN APPLICATION
addappid(2950370)
-- Game: addappid(2950370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2950371, 1, "3426c415e32a21308ca2fd30b629f1afb17b570da3de38b324b0c641fb77c61d")
