-- Lua provided by RyzenAPI
-- Game: One Dreamer: Prologue

-- MAIN APPLICATION
addappid(1274140)

