-- Lua provided by RyzenAPI
-- Game: Alien Marauder

-- MAIN APPLICATION
addappid(1516750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516751, 1, "6ee2b95f52ea309379a204cef8795a6912fd32c5bbfc9277fa5adcefd6c89be9")
addappid(1799390, 0, "9b7bde8199efc33326298c04d5d85ea508a216a2c4f14ccbc1885d278fb9bad3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
