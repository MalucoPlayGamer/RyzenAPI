-- Lua provided by RyzenAPI
-- Game: Union of Gnomes

-- MAIN APPLICATION
addappid(2097030)
addappid(3080140)
-- Game: addappid(2097030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097031, 1, "5e527f73477ad45f62fe2cf46c642bcf811fd38317c6f02d84d08d1aa61f6122")
