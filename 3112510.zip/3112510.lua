-- Lua provided by RyzenAPI 
-- Game: Lust Theory Season 3 Demo
addappid(3112510)
addappid(3112511, 1, "cd7fd9a9d031f432ba2fa1cf234e3e6cbf1c0e25ce89f98980dc071406e332b9")
