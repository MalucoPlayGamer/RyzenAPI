-- Lua provided by RyzenAPI
-- Game: Sam & Max 301: The Penal Zone

-- MAIN APPLICATION
addappid(31220)
-- Game: addappid(31220)

-- MAIN APP DEPOTS / PACKAGES
addappid(31221, 1, "805c09785139538781806520caf251ee5904d7e12464ecbde373239c16bf1b7f")
addappid(31222, 1, "ee5975295232e58ba5dfd7a50e3b133d1d6a76528c378a639af18667bd495f39")
