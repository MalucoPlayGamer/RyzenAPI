-- Lua provided by RyzenAPI
-- Game: addappid(2777590)

-- MAIN APPLICATION
addappid(2777590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777590,0,"afea7dc34a33a69b347aaab328a1a6ba496d224df46ed27afcca5330f1ceeb05")
