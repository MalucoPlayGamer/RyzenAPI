-- Lua provided by SkyAPI 
-- Game: PumPum Demo
addappid(1853910)
addappid(1853911, 1, "423006d4c5eed60fd75145ba2129c52c0796c2794195a080e195b8da7ca5a73a")
