-- Lua provided by SkyAPI 
-- Game: AppID 999890
addappid(999890)
addappid(999891, 1, "5c0a0df1f2f8fa8568d57fa66077b9ab7ab691a1cde05751e80d1981a2ecc515")
