-- Lua provided by RyzenAPI
-- Game: 1677190

-- MAIN APPLICATION
addappid(1677190)
-- Game: addappid(1677190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677191, 1, "209655031e547ee92ffa3eb8cfd9e262a706249ffcd25c14a9d30b35037b8cda")
