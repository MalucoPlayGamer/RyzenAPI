-- Lua provided by RyzenAPI
-- Game: Noita

-- MAIN APPLICATION
addappid(881100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(881101, 1, "c766a099c7245b97c23cf08b9e88e0460813214fde82ce8cc2b80034ec0d1848")

