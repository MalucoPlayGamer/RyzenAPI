-- Lua provided by RyzenAPI
-- Game: Noita

-- MAIN APPLICATION
addappid(881100)

-- MAIN APP DEPOTS / PACKAGES
addappid(881101, 1, "c766a099c7245b97c23cf08b9e88e0460813214fde82ce8cc2b80034ec0d1848")
