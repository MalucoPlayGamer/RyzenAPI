-- Lua provided by RyzenAPI
-- Game: Game: Expedia Cenote VR

-- MAIN APPLICATION
addappid(858380)
-- Game: addappid(858380)

-- MAIN APP DEPOTS / PACKAGES
addappid(858381, 1, "feee5125c9a992a7f75298a589fe9dc50a0ec7c82e4176bf859a08586cd72a9f")
