-- Lua provided by RyzenAPI
-- Game: Expedia Cenote VR

-- MAIN APPLICATION
addappid(858380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(858381, 1, "feee5125c9a992a7f75298a589fe9dc50a0ec7c82e4176bf859a08586cd72a9f")

