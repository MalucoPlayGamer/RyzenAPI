-- Lua provided by RyzenAPI
-- Game: Sketchbox

-- MAIN APPLICATION
addappid(568640)

-- MAIN APP DEPOTS / PACKAGES
addappid(568641, 1, "3287966db80f868ae10624b331af72a2c5d21c0b020af52aa9debe402502f188")

