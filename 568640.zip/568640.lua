-- Lua provided by RyzenAPI
-- Game: Sketchbox

-- MAIN APPLICATION
addappid(568640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(568641, 1, "3287966db80f868ae10624b331af72a2c5d21c0b020af52aa9debe402502f188")

