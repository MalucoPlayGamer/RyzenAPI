-- Lua provided by RyzenAPI
-- Game: Star Sign

-- MAIN APPLICATION
addappid(1860540)
-- Game: addappid(1860540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860541, 1, "37fbedced883029d6a2f685a01cd13d7b7717303a0e8bb24bb9716d7d00a5dc2")
