-- Lua provided by RyzenAPI
-- Game: addappid(547910)

-- MAIN APPLICATION
addappid(547910)

-- MAIN APP DEPOTS / PACKAGES
addappid(547911, 1, "16b144f149ceab55ec41de7cd952207f3fb99592fcfe2b7c56adccc59edcfeaf")
