-- Lua provided by RyzenAPI
-- Game: Thea 2: The Shattering

-- MAIN APPLICATION
addappid(606230)

-- MAIN APP DEPOTS / PACKAGES
addappid(606231, 1, "5754652c6de544c1e1321fd2a67780530dfbb232408056f838525e47d390c5e0")
addappid(1212890, 0, "ba14aa3ffca927a3af770a061a450e728ba59b9b1b261db77ad5ce52e37e9e38")
addappid(1240020, 0, "b134e22fc9a62ccde60af88058580de49386f85dba3f11abebf1950888cbf53b")
