-- Lua provided by RyzenAPI
-- Game: Violet Cycle

-- MAIN APPLICATION
addappid(595010)

-- MAIN APP DEPOTS / PACKAGES
addappid(595013,0,"6ebcb8e06a65207880824781317f816a1ad139b9e7c4728ad71f8b415c6fd930")

