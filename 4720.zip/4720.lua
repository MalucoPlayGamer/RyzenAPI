-- Lua provided by RyzenAPI
-- Game: Condemned: Criminal Origins

-- MAIN APPLICATION
addappid(4720)
-- Game: addappid(4720)

-- MAIN APP DEPOTS / PACKAGES
addappid(4721, 1, "c2083cb1aece8efb25415edade9f2c27feaca519bd74b53d3066baed41457557")
addappid(4722, 1, "bb2648007705bfa3657375de8c3e20806455e96447d871dadb6deb56c650c9bb")
addappid(4723, 1, "0310ee1f7f0a7eaa7d930a9c53b268b2f5b572457454cd135f33bdf943807015")
addappid(4724, 1, "93273e569372b39b967019e0daf236e215a3de515d8c109f3f5a194a44c0f5ba")
addappid(4725, 1, "ec953b8566b44b31ce70824c8c30f6eadd36d9c6bb2a618dbc7098077715a6a3")
addappid(4726, 1, "c93ce9f63d6b4b63e789a8e7f2259f9144d2875ccfbe16eeeed4edafdc055b49")
