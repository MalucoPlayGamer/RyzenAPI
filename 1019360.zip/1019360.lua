-- Lua provided by RyzenAPI
-- Game: Game: AppID 1019360

-- MAIN APPLICATION
addappid(1019360)
-- Game: addappid(1019360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019361, 1, "58f35073ea0d1850636ec29db89f03cd3a50544d2448cb6de1df0d3ecf6d4ba8")
