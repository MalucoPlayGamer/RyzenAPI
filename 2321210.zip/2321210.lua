-- Lua provided by RyzenAPI
-- Game: 2321210

-- MAIN APPLICATION
addappid(2321210)
-- Game: addappid(2321210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321211, 1, "a877a212a1f3c9c9ea9192793c7b064ea1c8475f2b77ec8da0020bda426aca9b")
