-- Lua provided by RyzenAPI
-- Game: Not My Day!

-- MAIN APPLICATION
addappid(951320)

-- MAIN APP DEPOTS / PACKAGES
addappid(951321, 1, "f7a2ad91fe58e9c5db07a66dcc7c173cee97d27b27143ec30c83e5aa2028806f")
