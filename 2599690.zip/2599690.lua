-- Lua provided by RyzenAPI
-- Game: Better than Dead

-- MAIN APPLICATION
addappid(2599690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2599692,0,"0a0fefd8dd1858b402ca615385cc45515e507284cac4fce433441209664fd80a")

