-- Lua provided by RyzenAPI
-- Game: Better than Dead

-- MAIN APPLICATION
addappid(2599690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599692,0,"0a0fefd8dd1858b402ca615385cc45515e507284cac4fce433441209664fd80a")

