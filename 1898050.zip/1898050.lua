-- Lua provided by RyzenAPI
-- Game: Buried

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1898050)
-- Game: addappid(1898050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898058,0,"cdced85ce82b9637c8d9a65e5026b6dae4099cbb8ed9f982dfd5f0dfddb13abf")
