-- Lua provided by RyzenAPI 
-- Game: Cube War
addappid(2748100)
addappid(2748101, 1, "eb03d9de5673144206b22b3a1a641c9db5bb6e2f11c5353068cc678a976138bd")
