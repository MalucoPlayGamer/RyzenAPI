-- Lua provided by RyzenAPI
-- Game: Cube War

-- MAIN APPLICATION
addappid(2748100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2748101, 1, "eb03d9de5673144206b22b3a1a641c9db5bb6e2f11c5353068cc678a976138bd")
