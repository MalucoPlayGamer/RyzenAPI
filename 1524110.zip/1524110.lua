-- Lua provided by RyzenAPI
-- Game: Stories of Liane

-- MAIN APPLICATION
addappid(1524110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524111, 1, "04b778f7cb83f26ac673d52c63e0f280225b1126bf9c9b058dcee237ef2ba96f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
