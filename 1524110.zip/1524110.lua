-- Lua provided by RyzenAPI
-- Game: addappid(1524110)

-- MAIN APPLICATION
addappid(1524110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524111, 1, "04b778f7cb83f26ac673d52c63e0f280225b1126bf9c9b058dcee237ef2ba96f")
