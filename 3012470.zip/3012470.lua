-- Lua provided by RyzenAPI
-- Game: SickWay VR

-- MAIN APPLICATION
addappid(3012470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012471, 1, "f2175d41e1eb8acd0ff26c6a32b37c2699b46c820723136bf03399076ea3ce63")

