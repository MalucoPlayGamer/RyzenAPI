-- Lua provided by RyzenAPI
-- Game: Game: Infinite Jump

-- MAIN APPLICATION
addappid(1547160)
-- Game: addappid(1547160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547161, 1, "7d9297175dbe3d29799924992e1fd71c316f95fe742805de404c9f85e30a68b5")
addappid(1571850, 0, "77a058ee457621fb916c5c6e0c98ca132153b104060f7ad9c6f10f602339a00a")
