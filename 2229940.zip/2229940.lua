-- Lua provided by RyzenAPI
-- Game: [REDACTED]

-- MAIN APPLICATION
addappid(2229940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229942,0,"90d8946d112621e524c43310fcfdd85e186c283857d67fc48e2d51b7733656ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
