-- Lua provided by RyzenAPI
-- Game: Escape from Skull Dungeon

-- MAIN APPLICATION
addappid(1379200)
-- Game: addappid(1379200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379201, 1, "fcfc06b0514378fdff6d7bdf3df34b4ae01f53230cebcb4a53c91101ef675087")
