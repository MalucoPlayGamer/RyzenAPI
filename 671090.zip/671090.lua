-- Lua provided by RyzenAPI
-- Game: Oik Memory

-- MAIN APPLICATION
addappid(671090)
-- Game: addappid(671090)

-- MAIN APP DEPOTS / PACKAGES
addappid(671091, 1, "9447a0e30225f423a464834c8b709cc0fdd0e5c1252d1db3a7657fa219829b18")
