-- Lua provided by RyzenAPI
-- Game: Batora: Lost Haven - Original Soundtrack

-- MAIN APPLICATION
addappid(2190560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190561, 1, "a3970c775f7535ba41bfacdbb7f26a75b1da3795d2cb70a97cc395ada019ad1f")
