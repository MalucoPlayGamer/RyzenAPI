-- Lua provided by RyzenAPI
-- Game: Grand Theft Auto: Vice City – The Definitive Edition

-- MAIN APPLICATION
addappid(1546990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1546991, 1, "8ffae608bee3a6766651bc7b0b2122f7248955251de38eafb6161ea30434979d")
addappid(1899671, 0, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")

