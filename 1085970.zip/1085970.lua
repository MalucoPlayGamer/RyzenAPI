-- Lua provided by RyzenAPI
-- Game: The Makings of a Lady - Purity Yours to Defile -

-- MAIN APPLICATION
addappid(1085970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085971, 1, "5f4cade1a9fffa5c52cba58d82967ba1fab63494c0d46b29832713597b20f513")
