-- Lua provided by RyzenAPI
-- Game: LoliTower

-- MAIN APPLICATION
addappid(1160780)
addappid(1184130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160781, 1, "efcdb63d0c4e91b1da451dfcefb1fab096ddeeaa2ae6e4ebc1b5799a34ad6f1b")
addappid(1160782, 1, "0a5ae114a4ca8a64fd180cf340f3c71517c3d3f7868069054354f2bb2a72773b")

