-- Lua provided by RyzenAPI
-- Game: 2111780

-- MAIN APPLICATION
addappid(2111780)
-- Game: addappid(2111780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111781, 1, "6ea0e575ffe89cac463ec18f3b08998c8ec6c161bbe937fd28272b570a512a3d")
addappid(2111782, 1, "baab43dd9ded7b2a731fcaed61b00be674be3c613d81b16f80cb5b104b310cf2")
