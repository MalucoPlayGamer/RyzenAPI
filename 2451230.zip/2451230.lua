-- Lua provided by RyzenAPI
-- Game: Starship Traders MMO

-- MAIN APPLICATION
addappid(2451230)
-- Game: addappid(2451230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451231, 1, "663f93343f3957d14686f23d44ed82020a07868f945b4f5fa4f9916097541b7e")
