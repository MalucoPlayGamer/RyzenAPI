-- Lua provided by SkyAPI 
-- Game: AppID 2451230
addappid(2451230)
addappid(2451231, 1, "663f93343f3957d14686f23d44ed82020a07868f945b4f5fa4f9916097541b7e")
