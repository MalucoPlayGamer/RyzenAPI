-- Lua provided by RyzenAPI
-- Game: Showdown at Willow Creek

-- MAIN APPLICATION
addappid(772340)
-- Game: addappid(772340)

-- MAIN APP DEPOTS / PACKAGES
addappid(772341, 1, "90676e58cf82dde612a526bc520f30b07a48e58d0d326f57201721424bdce053")
