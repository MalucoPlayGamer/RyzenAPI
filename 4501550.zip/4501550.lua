-- Lua provided by RyzenAPI
-- Game: Hentai Succubus Aura

-- MAIN APPLICATION
addappid(4501550) -- Hentai Succubus Aura

-- MAIN APP DEPOTS / PACKAGES
addappid(4501551, 1, "54c714adede17b6ba3feb79e584c8ffbc36f8fd33b569d7b59680d2d3305beab") -- Depot 4501551

