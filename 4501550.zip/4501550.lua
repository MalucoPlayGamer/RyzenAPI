-- 4501550's Lua and Manifest Created by Hubcap Manifest
-- Hentai Succubus Aura
-- Created: August 17, 2026 at 14:34:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4501550) -- Hentai Succubus Aura
-- MAIN APP DEPOTS
addappid(4501551, 1, "54c714adede17b6ba3feb79e584c8ffbc36f8fd33b569d7b59680d2d3305beab") -- Depot 4501551
setManifestid(4501551, "5322513229806286393", 235927136)