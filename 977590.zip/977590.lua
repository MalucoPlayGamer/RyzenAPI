-- Lua provided by RyzenAPI
-- Game: バインドを解除する(unbind)

-- MAIN APPLICATION
addappid(977590)
addappid(993410)

-- MAIN APP DEPOTS / PACKAGES
addappid(977591, 1, "886df2bb52466ff51608ecf9c2101f853b83232964026fe41569be7dae59afd7")

