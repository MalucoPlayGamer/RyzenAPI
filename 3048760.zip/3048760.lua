-- Lua provided by RyzenAPI
-- Game: addappid(3048760)

-- MAIN APPLICATION
addappid(3048760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048761, 1, "f25ed2e0ccc2359e14fbf86075683509ed8358decd0716c9b3685659732c2d36")
