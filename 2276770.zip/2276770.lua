-- Lua provided by RyzenAPI
-- Game: Possible One: Lunar Industries

-- MAIN APPLICATION
addappid(2276770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276771,0,"bfd8b5f2543e0533c89cb2b17f6689518b1b61cf1108f4f7af9087027c7d2dfd")

