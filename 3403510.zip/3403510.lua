-- Lua provided by RyzenAPI
-- Game: Winter Clothing

-- MAIN APPLICATION
addappid(3403510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3403511, 1, "51562582a55930d23fe120742cc755a8f397d306bc83f521c5404d39c2fe3547")
