-- Lua provided by RyzenAPI
-- Game: Bodyless

-- MAIN APPLICATION
addappid(1202100)
-- Game: addappid(1202100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202101, 1, "a8a87fc3bd294f4904924a3dbe14e053b89ac5c37e262d2666b88dc40d2b0ad8")
