-- Lua provided by RyzenAPI
-- Game: The Day They Landed

-- MAIN APPLICATION
addappid(761880)

-- MAIN APP DEPOTS / PACKAGES
addappid(761882,0,"f6538587a0567b5f7733446ee8e9407e51e845bbb0fe16daae61ce8840da6043")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
