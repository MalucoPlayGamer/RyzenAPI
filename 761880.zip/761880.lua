-- Lua provided by RyzenAPI
-- Game: The Day They Landed

-- MAIN APPLICATION
addappid(761880)

-- MAIN APP DEPOTS / PACKAGES
addappid(761882,0,"f6538587a0567b5f7733446ee8e9407e51e845bbb0fe16daae61ce8840da6043")

