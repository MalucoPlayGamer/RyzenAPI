-- Lua provided by RyzenAPI
-- Game: Elections Simulator 2018

-- MAIN APPLICATION
addappid(654650)

-- MAIN APP DEPOTS / PACKAGES
addappid(654651, 1, "83abbe29cc653d06fa0db91cb7bb3946d5cfc8d6227541a002486526b1b6b459")

