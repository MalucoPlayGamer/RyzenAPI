-- Lua provided by RyzenAPI
-- Game: Hypermarket Tycoon Manager

-- MAIN APPLICATION
addappid(2364250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364251, 1, "38f768852750473a0b42b3460944f7f88f5c8b6f7d3573021ec039fb5633df62")
