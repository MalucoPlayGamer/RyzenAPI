-- Lua provided by RyzenAPI
-- Game: 1527280

-- MAIN APPLICATION
addappid(1527280)
-- Game: addappid(1527280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527281, 1, "a5dc4191571afdc2c56f44e346762f3cd515d90406140acfddb9b3c088f0fca8")
