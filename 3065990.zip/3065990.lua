-- Lua provided by RyzenAPI
-- Game: FANTASIAN Neo Dimension Vibran Secret Stone

-- MAIN APPLICATION
addappid(3065990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3065990,0,"278317e535fe90bfeb9f314c76749d635ffa7e09ae9e62132eeecd325467dc30")

