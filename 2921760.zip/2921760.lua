-- Lua provided by RyzenAPI
-- Game: 2921760

-- MAIN APPLICATION
addappid(2921760)
-- Game: addappid(2921760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921761, 1, "e26d738a0d73bf2cf750f1ece781c2a85bcfdea069a9f00cda9540b87cfb815c")
