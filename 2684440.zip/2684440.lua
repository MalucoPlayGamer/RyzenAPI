-- Lua provided by RyzenAPI
-- Game: Game: AppID 2684440

-- MAIN APPLICATION
addappid(2684440)
-- Game: addappid(2684440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684441, 1, "33cf7ede2e87e1b1f5e65f9cbd5d1d785c118876fabb23283481f1becbbcc7fc")
