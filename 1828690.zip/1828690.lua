-- Lua provided by RyzenAPI
-- Game: Game: Security Booth: Director's Cut

-- MAIN APPLICATION
addappid(1828690)
-- Game: addappid(1828690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828691, 1, "b209e2eb3ced2f0f73dc4af8e0a59d6d0c15e631d17a64bafa5725393b9e6a5a")
