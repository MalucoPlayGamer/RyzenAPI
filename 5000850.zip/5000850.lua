-- Lua provided by RyzenAPI
-- Game: Game Shop Panic

-- MAIN APPLICATION
addappid(5000850) -- Game Shop Panic

-- MAIN APP DEPOTS / PACKAGES
addappid(5000851, 1, "60009191a4d0d4ee07e750af4bd58e2ffbed33a5961884ecab7998cf77787878") -- Depot 5000851

