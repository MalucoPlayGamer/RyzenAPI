-- 5000850's Lua and Manifest Created by Hubcap Manifest
-- Game Shop Panic
-- Created: August 14, 2026 at 06:00:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5000850) -- Game Shop Panic
-- MAIN APP DEPOTS
addappid(5000851, 1, "60009191a4d0d4ee07e750af4bd58e2ffbed33a5961884ecab7998cf77787878") -- Depot 5000851
setManifestid(5000851, "3887635362069231120", 528609863)