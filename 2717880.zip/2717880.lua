-- Lua provided by RyzenAPI
-- Game: The Rogue Prince of Persia

-- MAIN APPLICATION
addappid(2717880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717881, 1, "4f68e98dcd0e02d77029d74ec41d2bb82ac62a486db69b9a034683ae1bddbf41")
addappid(2717882, 1, "9cf88420d3b56db810785d1f9254e8368b15540c6441246024469862221f7edd")
