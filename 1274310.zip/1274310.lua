-- Lua provided by RyzenAPI
-- Game: Game: 东方鬼神玉 ~ I wanna be the Yin-Yang orb

-- MAIN APPLICATION
addappid(1274310)
-- Game: addappid(1274310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274311, 1, "01f6767487abb2a3e719d8134db41c25a7ba57061af433eb17c74c9f619d68e4")
