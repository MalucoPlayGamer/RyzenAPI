-- Lua provided by RyzenAPI 
-- Game: 东方鬼神玉 ~ I wanna be the Yin-Yang orb
addappid(1274310)
addappid(1274311, 1, "01f6767487abb2a3e719d8134db41c25a7ba57061af433eb17c74c9f619d68e4")
