-- Lua provided by RyzenAPI
-- Game: The Journey - Episode 1: Whatever This Is

-- MAIN APPLICATION
addappid(1587090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587091, 1, "e62e54c7d0786fd131a2331467bf00c37d54db0349b0693776b4d4f1e15e0fd6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
