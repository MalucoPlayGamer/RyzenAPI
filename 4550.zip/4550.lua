-- Lua provided by RyzenAPI
-- Game: Game: AppID 4550

-- MAIN APPLICATION
addappid(4550)
addappid(228981)
addappid(228982)
addappid(228990)
addappid(449430)
addappid(449431)
addappid(449432)
addappid(449433)
addappid(450162)
addappid(450163)
addappid(450164)
-- Game: addappid(4550)

-- MAIN APP DEPOTS / PACKAGES
addappid(4551, 1, "abd5f20d12a601872a6818d9a819e1f9eed318b882bf595371f22c8182d9b110")
addappid(4552, 1, "f2368efe0abf134f42feb9212a159c81db1e124bd321756a9a94e2eb0a27839c")
addappid(4553, 1, "1107328df59332a3f29253d8a454caaf4f5f93b29b0e7ac29b15ac92713369dc")
addappid(4554, 1, "ebdc8da81ac115a87165d5e0ae2cdeb61c825d9eeca7bcc17f0a872048b89e32")
addappid(4555, 1, "444a393d27ca6654e1cc53312883742217032d51048c0ed5abf41e673f0d99e3")
addappid(4556, 1, "75eb93979aee66d5a766c4bc1883276f450e47c88c0baba1bef95b9e0c112663")
addappid(4557, 1, "3df9c7300940a865e59f65cd292a5980e0ed9824459a9663fd6da9727f8269dc")
addappid(450160, 0, "01abc50ac63f50999c3c25e12ff7ad1aa06112b0b2f1308323dc950fa3ff454d")
addappid(450161, 0, "a3a75b4e0ac4ba4285e72e0446568ca990653b781e8e689e122231e6a847d2f0")
