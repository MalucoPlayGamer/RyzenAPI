-- Lua provided by RyzenAPI
-- Game: 2206340

-- MAIN APPLICATION
addappid(2206340)
-- Game: addappid(2206340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206341, 1, "3cf7b2f6fc251306379a119c7226fa829732cf862d1dad5c32eddf60c11b5984")
