-- Lua provided by RyzenAPI
-- Game: Stab

-- MAIN APPLICATION
addappid(2542600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542601, 1, "fa179fd402313e56c223adb47adef8b3796a3a3c91b01aedcb98ec5771539fc3")
