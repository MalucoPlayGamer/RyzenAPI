-- Lua provided by RyzenAPI
-- Game: Acan's Call: Act 1

-- MAIN APPLICATION
addappid(501180)

-- MAIN APP DEPOTS / PACKAGES
addappid(501181, 1, "3081289ad40f881e4d8f3af4dc51716e5321b438d868ac0854dbf48ffe3c65a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
