-- Lua provided by RyzenAPI
-- Game: Acan's Call: Act 1

-- MAIN APPLICATION
addappid(501180)
-- Game: addappid(501180)

-- MAIN APP DEPOTS / PACKAGES
addappid(501181, 1, "3081289ad40f881e4d8f3af4dc51716e5321b438d868ac0854dbf48ffe3c65a4")
