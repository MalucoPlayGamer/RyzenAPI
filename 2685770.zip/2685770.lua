-- Lua provided by RyzenAPI
-- Game: Idle Progress

-- MAIN APPLICATION
addappid(2685770)
-- Game: addappid(2685770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685771, 1, "53a09c36fb40be8fc47c2b170c194340d1db35294cff277802441f21799908b0")
