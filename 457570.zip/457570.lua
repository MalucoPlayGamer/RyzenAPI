-- Lua provided by RyzenAPI
-- Game: Game: Camp Sunshine

-- MAIN APPLICATION
addappid(457570)
-- Game: addappid(457570)

-- MAIN APP DEPOTS / PACKAGES
addappid(457571, 1, "7f23aa523091ccdc8da41c59c0677a140e315255d617461d77e0e82d6e964ba6")
addappid(457572, 1, "3db4eac0e7c7962008c2f5b5de115112abf2a193531054610e990f12630b0ce9")
