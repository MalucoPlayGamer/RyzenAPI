-- Lua provided by RyzenAPI
-- Game: 1022450

-- MAIN APPLICATION
addappid(1022450)
-- Game: addappid(1022450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022451, 1, "bbe80a187d38ae7befda4786399c52ec7188f8383f9cf7f71daf8b0f53469b1e")
addappid(1022452, 1, "117dbed75d8dc6cd70ac20fe13c2446e70b1df81a0cef9509b2add84113a6c73")
addappid(1022453, 1, "34f6b22e1757f0ad2b764c8c110491003c6041e40bf4ce1b67ad43d6903029cf")
