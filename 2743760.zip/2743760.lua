-- Lua provided by RyzenAPI
-- Game: Real Anime Situation! DT

-- MAIN APPLICATION
addappid(2743760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743761, 1, "79bab48bc291acb59a2a7c5e06dcc04bb3de87dabe0529b8dbe11496b64799f6")
