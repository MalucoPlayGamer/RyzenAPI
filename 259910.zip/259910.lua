-- Lua provided by RyzenAPI
-- Game: Farming Giant

-- MAIN APPLICATION
addappid(259910)

-- MAIN APP DEPOTS / PACKAGES
addappid(259911, 1, "23ddc7f1f4bb29a1cd570117112f19614d657443b3bd6d8cc7e637100de5b0f9")
addappid(259912, 1, "5e547888cde2d2b0c7c7ccb054e88d6fc6062a9916227907ea4df1dc3c478baa")
addappid(259913, 1, "e7187648f99a8d647093b2dc21c4ed4aa13b04ccb92f5bf3feeb68513feed63f")
addappid(259914, 1, "154f31d4aaf51a3be9fdd3ba83d707da7a17b2586122751be5eb891fe02bee10")
addappid(259915, 1, "bfc7b35f3357d9cf561f14a11a3bb3878326b69b670d62746fe8971e67afe09c")
addappid(259916, 1, "b56f11bec6d0bae9efee410fc75f54ce46acf95b67e499ca8fb1bbc414cb15dc")
addappid(259917, 1, "f60824ea743cf06501def9ecc1627ba2cbe7ccf670ea8937c3f101e6351dfceb")
addappid(259918, 1, "65f1ef56d2f023012aca0e374ae073c84f3b34d9b561a2f2370fd4f64968fe9e")
addappid(259919, 1, "2f5bb76b84f3be6b0a77c08a88bd1e7470b760a9544b270154b8665d4596e3ff")
