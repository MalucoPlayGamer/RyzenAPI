-- Lua provided by RyzenAPI
-- Game: Farlanders Demo

-- MAIN APPLICATION
addappid(1414880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414881, 1, "49aba45f2343ede10ee03a95a5d0b3c3b72210061fbb3867bc5f7b2b147e5a66")

