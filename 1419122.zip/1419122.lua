-- Lua provided by RyzenAPI
-- Game: VR Hentai Girl 4

-- MAIN APPLICATION
addappid(1419122)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419122,0,"3699edfea935a71037a7eedbc5a40afa55354a25d15647734263fffc34c5f27f")
