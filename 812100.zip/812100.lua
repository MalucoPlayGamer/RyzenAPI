-- Lua provided by RyzenAPI
-- Game: addappid(812100)

-- MAIN APPLICATION
addappid(812100)

-- MAIN APP DEPOTS / PACKAGES
addappid(812101, 1, "46c39a1f2ac3e20c886ad3ff0a872306269a9f0241ef1354f92a64033a7c4d44")
