-- Lua provided by RyzenAPI
-- Game: 规则怪谈：梦核密室逃脱

-- MAIN APPLICATION
addappid(3436840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3436841, 1, "9d9bd492c88b1a88592981143337bee94cc5afaafd090d2d0fa127128d0cf497")

