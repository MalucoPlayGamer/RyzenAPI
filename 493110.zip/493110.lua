-- Lua provided by SkyAPI 
-- Game: KOTH
addappid(493110)
addappid(493111, 1, "9b89ef4ea8cf052d92201164a9394f582e1f7e74480c60593bb4d06cfde3a61d")
