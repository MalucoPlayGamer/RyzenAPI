-- Lua provided by RyzenAPI
-- Game: KOTH

-- MAIN APPLICATION
addappid(493110)

-- MAIN APP DEPOTS / PACKAGES
addappid(493111, 1, "9b89ef4ea8cf052d92201164a9394f582e1f7e74480c60593bb4d06cfde3a61d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
