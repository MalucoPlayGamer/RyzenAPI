-- Lua provided by RyzenAPI 
-- Game: Ann
addappid(1511270)
addappid(1511271, 1, "0f3c82b4ce8f6453ac42b1adfa80adfef01d009e8c12a4ea4135437a538eca87")
addappid(1581630)
