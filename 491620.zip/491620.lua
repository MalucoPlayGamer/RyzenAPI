-- Lua provided by RyzenAPI
-- Game: AppID 491620

-- MAIN APPLICATION
addappid(491620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(491621, 1, "b040761dec0bd8cffb503de5ca85786019fd7e03c64ccac596b17df185248437")

