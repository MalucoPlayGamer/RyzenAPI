-- Lua provided by RyzenAPI
-- Game: Game: 猫神牧场：恐龙纪元（Cat God Ranch:​​Age of Dinosaurs​）

-- MAIN APPLICATION
addappid(3795220)
-- Game: addappid(3795220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3795221, 1, "2e89963ffcab13efa5665387c67d010a7f27006209b5a2fb3a6428c5273d55b9")
