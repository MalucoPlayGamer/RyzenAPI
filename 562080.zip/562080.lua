-- Lua provided by RyzenAPI
-- Game: Hello Neighbor Demo

-- MAIN APPLICATION
addappid(562080)
-- Game: addappid(562080)

-- MAIN APP DEPOTS / PACKAGES
addappid(562082,0,"f92a00cbe1f24041b377569c729dce6d2419a55a5d401e323a87203da111bc30")
