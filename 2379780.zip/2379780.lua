-- Lua provided by RyzenAPI 
-- Game: Balatro
addappid(2379780)
addappid(2379781, 1, "16261e41d3e864018778d4a1d81658521a67d9ffb8543ea7e3e21f0685721af1")
addappid(2379782, 1, "d0d563bdb51d625d0ed3a3234be0282f8d9a25d81dce599cdcace7b88c3b4719")
