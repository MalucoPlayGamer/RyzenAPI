-- Lua provided by RyzenAPI
-- Game: Balatro

-- MAIN APPLICATION
addappid(2379780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2379781, 1, "16261e41d3e864018778d4a1d81658521a67d9ffb8543ea7e3e21f0685721af1")
addappid(2379782, 1, "d0d563bdb51d625d0ed3a3234be0282f8d9a25d81dce599cdcace7b88c3b4719")

