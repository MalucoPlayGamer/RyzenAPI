-- Lua provided by RyzenAPI
-- Game: addappid(688790)

-- MAIN APPLICATION
addappid(688790)

-- MAIN APP DEPOTS / PACKAGES
addappid(688791, 1, "6f3b18e396206fd3d515698dcedc562511365e67afbb29eaf5909e717ca3459b")
