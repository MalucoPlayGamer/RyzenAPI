-- Lua provided by RyzenAPI
-- Game: The Men of Yoshiwara: Ohgiya

-- MAIN APPLICATION
addappid(447200)
addappid(449930)

-- MAIN APP DEPOTS / PACKAGES
addappid(447201, 1, "e4f663c11b91e5f2159d737317abdba674dd9df7d5c59857d2cb6a0863fe44df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
