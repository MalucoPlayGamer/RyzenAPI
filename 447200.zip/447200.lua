-- Lua provided by RyzenAPI
-- Game: The Men of Yoshiwara: Ohgiya

-- MAIN APPLICATION
addappid(447200)
addappid(449930)
-- Game: addappid(447200)

-- MAIN APP DEPOTS / PACKAGES
addappid(447201, 1, "e4f663c11b91e5f2159d737317abdba674dd9df7d5c59857d2cb6a0863fe44df")
