-- Lua provided by SkyAPI 
-- Game: AppID 238260
addappid(238260)
addappid(238261, 1, "9ef15d26286184d0726927b4b48aabb76cda2368c0749eff06b0d0c0d3a47a71")
addappid(238262, 1, "deac391c192de62175d2a181c4043177a749c51b70d1967ab841bc133b55cafd")
