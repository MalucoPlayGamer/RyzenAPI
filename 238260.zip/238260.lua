-- 238260's Lua and Manifest Created by Hubcap Manifest
-- Pinball Arcade
-- Created: September 30, 2025 at 06:41:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 24
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(238260) -- Pinball Arcade
-- MAIN APP DEPOTS
addappid(238261, 1, "9ef15d26286184d0726927b4b48aabb76cda2368c0749eff06b0d0c0d3a47a71") -- Pinball Arcade Content
setManifestid(238261, "6601832109856305996", 20461593304)
addappid(238262, 1, "deac391c192de62175d2a181c4043177a749c51b70d1967ab841bc133b55cafd") -- Pinball Arcade OSX Depot
setManifestid(238262, "1843759413542542912", 143000975)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(238270) -- Pinball Arcade Season One Table Pack
addappid(238271) -- Pinball Arcade Season One Pro Pack
addappid(238272) -- Pinball Arcade Season Two Table Pack
addappid(238273) -- Pinball Arcade Season Two Pro Pack
addappid(268280) -- Pinball Arcade Season Three Pack
addappid(268281) -- Pinball Arcade Season Three Pro Pack
addappid(326600) -- Pinball Arcade Season Four Pack
addappid(326610) -- Pinball Arcade Season Four Pro Pack
addappid(394560) -- Pinball Arcade Season Five Pack
addappid(394561) -- Pinball Arcade Season Five Pro Pack
addappid(493300) -- Pinball Arcade Season Six Pack
addappid(493301) -- Pinball Arcade Season Six Pro Pack
addappid(639890) -- Pinball Arcade Season Seven Table Pack
addappid(639891) -- Pinball Arcade Season Seven Pro Pack
addappid(908220) -- Pinball Arcade Gottlieb Pack 1
addappid(908221) -- Pinball Arcade Gottlieb Pack 2
addappid(908222) -- Pinball Arcade Gottlieb Pack 3
addappid(908223) -- Pinball Arcade Gottlieb EM Pack
addappid(908224) -- Pinball Arcade Stern Pack 1
addappid(908225) -- Pinball Arcade Stern Pack 2
addappid(908226) -- Pinball Arcade Alvin G. and Co. Pack
addappid(908227) -- Pinball Arcade Doctor Who Master of Time
addappid(929880) -- Pinball Arcade Stern Pack 3
addappid(1093040) -- Pinball Arcade Stern Pack 1