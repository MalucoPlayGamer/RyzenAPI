-- Lua provided by RyzenAPI
-- Game: Project Borealis: Prologue

-- MAIN APPLICATION
addappid(2215490)
-- Game: addappid(2215490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215491, 1, "4e4781569a227c900e7b5d69f7957830d1a6cb03fec3f94fdb6201117322ebcf")
