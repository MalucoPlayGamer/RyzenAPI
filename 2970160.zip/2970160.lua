-- Lua provided by SkyAPI 
-- Game: AppID 2970160
addappid(2970160)
addappid(2970161, 1, "826dc2a36ea64270af08bbf588aea068270fb42b0041820c6e8b08eade1cb8ca")
