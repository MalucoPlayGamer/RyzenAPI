-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3410970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3410970,0,"77e707a64d42f4075c4ce76d761c8493a518dc3426764fe950426b482fa7af84")

