-- Lua provided by RyzenAPI
-- Game: AppID 791770

-- MAIN APPLICATION
addappid(791770)
-- Game: addappid(791770)

-- MAIN APP DEPOTS / PACKAGES
addappid(791771, 1, "6501d1bf5430dedfe48fe97f17ffa6c04c56b7453053ee6f776165b4ed72697c")
