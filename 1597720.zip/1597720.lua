-- Lua provided by RyzenAPI
-- Game: Feed All Monsters

-- MAIN APPLICATION
addappid(1597720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597721, 1, "c0b6bcb89fbaf10f302f686c35b35c7c45235e2c0def560f0a9862704c5c1c01")
