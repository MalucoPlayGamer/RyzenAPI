-- Lua provided by RyzenAPI
-- Game: 548240

-- MAIN APPLICATION
addappid(548240)
-- Game: addappid(548240)

-- MAIN APP DEPOTS / PACKAGES
addappid(548242,0,"3bd62d2b5bc2b3fd68ce530dc23a0946ce1dd0f93f244b942fa88c545f9fcd25")
