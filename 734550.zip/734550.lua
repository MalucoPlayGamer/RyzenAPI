-- Lua provided by RyzenAPI
-- Game: AppID 734550

-- MAIN APPLICATION
addappid(734550)
-- Game: addappid(734550)

-- MAIN APP DEPOTS / PACKAGES
addappid(734551, 1, "3cfb3fa817ae1eb081beb200f8c8f1ca05b3787f124e129768bb4680ab1da6fe")
