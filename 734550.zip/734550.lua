-- Lua provided by RyzenAPI
-- Game: AppID 734550

-- MAIN APPLICATION
addappid(734550)
addappid(746080)
addappid(758450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(734551, 1, "3cfb3fa817ae1eb081beb200f8c8f1ca05b3787f124e129768bb4680ab1da6fe")

