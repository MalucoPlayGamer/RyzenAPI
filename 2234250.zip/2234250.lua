-- Lua provided by RyzenAPI
-- Game: BattleReign

-- MAIN APPLICATION
addappid(2234250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234251, 1, "f3fe68b205c3b70200feda0927e32dba82b7ddeb1d5e3d4e98026259739cef7b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
