-- Lua provided by RyzenAPI
-- Game: addappid(2234250)

-- MAIN APPLICATION
addappid(2234250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234251, 1, "f3fe68b205c3b70200feda0927e32dba82b7ddeb1d5e3d4e98026259739cef7b")
