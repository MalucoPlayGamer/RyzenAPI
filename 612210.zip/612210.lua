-- Lua provided by RyzenAPI
-- Game: 612210

-- MAIN APPLICATION
addappid(612210)
-- Game: addappid(612210)

-- MAIN APP DEPOTS / PACKAGES
addappid(612211, 1, "6e8da019b1df81345043f47fc4756fb823e9976492e098b6acfc2462a28d65ad")
