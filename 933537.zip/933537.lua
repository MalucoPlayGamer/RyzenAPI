-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Weapons Wu Pack 1

-- MAIN APPLICATION
addappid(933537)
-- Game: addappid(933537)

-- MAIN APP DEPOTS / PACKAGES
addappid(933537,0,"1ad878552bde51a09d4c3aa9ce05616be78908455a8a9132a3dad6dea2c9bb65")
