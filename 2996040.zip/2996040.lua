-- Generated with Luie @ https://lua.tools/
-- 2996040 - Teenage Mutant Ninja Turtles: Splintered Fate
-- Generated 2026-08-09 02:03:37 UTC
-- # Depots (Total/DLC/Shared): 5/3/1

-- Main AppID
addappid(2996040, 1, "96891d9b2870a84c54bb996262f721b1299c79885486e6feb249653388a2d127")

-- Main Depots
addappid(2996041, 1, "e93c99408425422103d746643c24b3bc8c717cd5110c9f0b876225db50cc6671")
setManifestid(2996041, "6298699032273826769", 2025741707)

-- DLC's (no depot keys required)
addappid(3316670) -- TMNT: Splintered Fate - Casey Jones & the Junkyard Jam
addappid(3784190) -- TMNT: Splintered Fate - Metalhead
addappid(4152390) -- TMNT: Splintered Fate - Alopex

-- DLC's (with depot keys)
-- TMNT: Splintered Fate Soundtrack (AppID: 3247420)
addappid(3247420)
addappid(3247421, 1, "e0fa92800392485535c849929c56e0f55d0fc0f57ede311b0794448ae9564d69")
setManifestid(3247421, "3305484005623763783", 861743858)
addappid(3247422, 1, "83a069ffe8d6e373c15ea06e16652993927d88b27e9846ec9a09221b1d44ed1b")
setManifestid(3247422, "1037294614611919146", 164184224)
-- TMNT Splintered Fate - Artbook (AppID: 3255900)
addappid(3255900)
addappid(3255900, 1, "200f77802a15d4f75f7441e2bb4dbbdbd90e6419e42bd8e66715b12bb0452284")
setManifestid(3255900, "4587529972681717957", 545320540)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
