-- Lua provided by RyzenAPI
-- Game: Teenage Mutant Ninja Turtles: Splintered Fate

-- MAIN APPLICATION
addappid(2996040)
-- Game: addappid(2996040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996041, 1, "e93c99408425422103d746643c24b3bc8c717cd5110c9f0b876225db50cc6671")
addappid(3255900, 0, "200f77802a15d4f75f7441e2bb4dbbdbd90e6419e42bd8e66715b12bb0452284")
