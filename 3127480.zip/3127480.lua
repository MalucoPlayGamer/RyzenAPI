-- Lua provided by RyzenAPI
-- Game: addappid(3127480)

-- MAIN APPLICATION
addappid(3127480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127481, 1, "fe5b41723d774146cb24cc327b990c032ccd57e429cdcf1d067a31bb4f2a9441")
