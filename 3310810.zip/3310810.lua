-- Lua provided by RyzenAPI
-- Game: Game: AppID 3310810

-- MAIN APPLICATION
addappid(3310810)
-- Game: addappid(3310810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3310811, 1, "a53b1b3336d22672f51642f81d6d80149c8baa6e4e795747bd3083792e25dc9d")
