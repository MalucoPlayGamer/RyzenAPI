-- Lua provided by RyzenAPI
-- Game: 1654381

-- MAIN APPLICATION
addappid(1654381)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654381,0,"37ce013b723ae53a5d1ed1c2c6eb2e34df4fead677daac43e6436fdbeb937339")
