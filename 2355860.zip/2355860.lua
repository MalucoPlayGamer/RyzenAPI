-- Lua provided by RyzenAPI
-- Game: Eggstraction

-- MAIN APPLICATION
addappid(2355860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2355861, 1, "2bff72a96cd3aa38adaa26ca9620e01bd36e5ebb30091e93bda763f5666e0aa5")

