-- Lua provided by RyzenAPI
-- Game: Eggstraction

-- MAIN APPLICATION
addappid(2355860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355861, 1, "2bff72a96cd3aa38adaa26ca9620e01bd36e5ebb30091e93bda763f5666e0aa5")

