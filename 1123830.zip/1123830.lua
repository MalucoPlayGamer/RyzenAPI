-- Lua provided by RyzenAPI
-- Game: addappid(1123830)

-- MAIN APPLICATION
addappid(1123830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123831, 1, "5da5856d56413eaf4fad6261fd4f9303892bae6d3cca1762a62cf737c7980c33")
