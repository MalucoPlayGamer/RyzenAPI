-- Lua provided by RyzenAPI
-- Game: Farm Manager 2021

-- MAIN APPLICATION
addappid(1123830)
addappid(1707430)
addappid(1741390)
addappid(2159830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123831,0,"5da5856d56413eaf4fad6261fd4f9303892bae6d3cca1762a62cf737c7980c33")

