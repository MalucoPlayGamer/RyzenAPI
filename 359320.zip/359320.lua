-- Lua provided by RyzenAPI
-- Game: Game: Elite Dangerous

-- MAIN APPLICATION
addappid(359320)
addappid(419273)
-- Game: addappid(359320)

-- MAIN APP DEPOTS / PACKAGES
addappid(359321, 1, "cec5201155953964f0b83154d29be92bb978b6b0db972a1f4d210b23162e6cdb")
addappid(359322, 1, "f3174f2ed57ea611b2682901429c9a285a33dabb75cf26280e6c69be7ae6dbe1")
addappid(359323, 1, "dc615f1e5758dc4ff89c1985995b25bdc7238a49726a3f639a9d2ddde5a39ddb")
addappid(359324, 1, "891f9abd8e6ed212425c48005e65784d9e7d1b204e691271d73c9c736714cec1")
addappid(359325, 1, "457b272b6b12782ece60fcd1fed6f86a74c60b9053df86dea2b0eac2f88183eb")
addappid(359326, 1, "2568f041e13fd928942f174860ae6a65ae30aef95b668dca52c27bf475d5b36c")
addappid(359327, 1, "a98a4bd6326ed8692adf82a6b67d53ca1f6ccb53bc7fd9a74d3b45c20b7b2881")
addappid(359328, 1, "f06fa7a0326382c6d5baf97af70246b7817eb34676cd186f41119b8ed7ff588a")
