-- Lua provided by RyzenAPI
-- Game: Game: PETIT GLASS Part.2

-- MAIN APPLICATION
addappid(2205990)
-- Game: addappid(2205990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205991, 1, "3a4a419b3a86fffccddb8a0274bacba43336d42a342357253327fc6834e58df3")
addappid(2205992, 1, "92f9ac3f5f3b3482ff91cbb23a1be29cb8b9d5353416d7dd1367abcc80a8d5a2")
