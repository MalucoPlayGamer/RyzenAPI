-- Lua provided by RyzenAPI
-- Game: AppID 907350

-- MAIN APPLICATION
addappid(907350)

-- MAIN APP DEPOTS / PACKAGES
addappid(907351, 1, "d7a40d6a340b23febbb1b214631b9934028c6a8eff91f6d95383e8cd7cd3b2d0")
addappid(907352, 1, "4033092f4c9d546a2e577ab973f0cd759c8d8314b854101491a586a4746d7821")
addappid(907353, 1, "5e7ff7cf0f87f8eeec587354049162255b2ebec93c6c9f8930564cc85b7ff0e1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(931600)
addappid(1021250)
addappid(1052780)
