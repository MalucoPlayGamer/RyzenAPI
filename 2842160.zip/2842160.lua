-- Lua provided by RyzenAPI
-- Game: Game: Half-Life: ESCAPE 2.0

-- MAIN APPLICATION
addappid(2842160)
-- Game: addappid(2842160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842161, 1, "f50f4a1c5f7ad6215a6693bf82d66a48e188677248124d11ed3a6151f5810e55")
