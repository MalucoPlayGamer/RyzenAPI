-- Lua provided by RyzenAPI
-- Game: 666940

-- MAIN APPLICATION
addappid(666940)

-- MAIN APP DEPOTS / PACKAGES
addappid(666942,0,"dcbda7901be36cbd303d804a3c3b5df70f8de9336e1498e38b2e54f6d946db0e")

