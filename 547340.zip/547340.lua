-- Lua provided by RyzenAPI
-- Game: LoveKami -Divinity Stage-

-- MAIN APPLICATION
addappid(547340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(547341, 1, "5192f6611ab0e0b626a19e96e47bed7bd6bfcb939285eb818ceffe382cefb5cb")
addappid(547342, 1, "9d78c4ab0e2ca4b0a05835cfbc6357616d29c38dab4aacf269b239b347a1fe39")
addappid(881830, 0, "725281fb86c9038b860207652242349db9f4c91a599601e6cbb095d803f69159")

