-- Lua provided by RyzenAPI
-- Game: Game: LoveKami -Divinity Stage-

-- MAIN APPLICATION
addappid(547340)
-- Game: addappid(547340)

-- MAIN APP DEPOTS / PACKAGES
addappid(547341, 1, "5192f6611ab0e0b626a19e96e47bed7bd6bfcb939285eb818ceffe382cefb5cb")
addappid(547342, 1, "9d78c4ab0e2ca4b0a05835cfbc6357616d29c38dab4aacf269b239b347a1fe39")
addappid(881830, 0, "725281fb86c9038b860207652242349db9f4c91a599601e6cbb095d803f69159")
