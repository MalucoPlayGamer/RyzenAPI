-- Lua provided by RyzenAPI
-- Game: 彼岸画廊/Nether Gallery

-- MAIN APPLICATION
addappid(1039830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039831, 1, "9a99b104ef785f3c30fd0337a09f1f418123c4adee73068a9e6cd1c1991d9782")

