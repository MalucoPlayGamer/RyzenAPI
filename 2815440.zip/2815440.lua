-- Lua provided by RyzenAPI
-- Game: Game: The Sims™ 4 Comfy Gamer Kit

-- MAIN APPLICATION
addappid(2815440)
-- Game: addappid(2815440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815441, 1, "605ac27227317d68a3425bf7cd7ac39d085f6577d6751db20654b11247ba6b30")
addappid(2815442, 1, "b9789e909412b50a662c6986d634e6137068876dbbc99259b005bbd2a9b3a65f")
addappid(2815443, 1, "1614a8d7d1e3565aa3f25bf55f982078acae0eb79cad4720194ad5c5d007b2f0")
addappid(2815446, 1, "c08415c7f0f113525f4dd0e7008f40ac9182b00a4bf1d1c5ca4dc4c2a14548bd")
addappid(2815447, 1, "d29a818bc33ff4323bc7c4cf91d7a4c0deb6ecc04ee54011983b75dde2563aba")
addappid(3401191, 0, "32b187fd6ebfa1f81d81ec0febdbd7e02885ade83f9172a607a62c9c47c95d4e")
