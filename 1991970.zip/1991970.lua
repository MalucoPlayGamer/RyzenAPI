-- Lua provided by RyzenAPI
-- Game: 雀姬的異想世界【音樂與美術集】

-- MAIN APPLICATION
addappid(1991970)
-- Game: addappid(1991970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991971, 1, "de4f590f1b0d8e6b8b0e35927a221e0d9e54b3821d9e975230a1035f2e39eaa1")
