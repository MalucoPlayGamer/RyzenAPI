-- Lua provided by RyzenAPI
-- Game: 2703070

-- MAIN APPLICATION
addappid(2703070)
-- Game: addappid(2703070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703072,0,"2095c9334d6681c68c52ce2dcd16c3ce7d433b1a7b18dc00eb8396067fe94c8c")
