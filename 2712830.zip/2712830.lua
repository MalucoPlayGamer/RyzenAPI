-- Lua provided by RyzenAPI
-- Game: 2712830

-- MAIN APPLICATION
addappid(2712830)
-- Game: addappid(2712830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712831, 1, "c7e1570e22f804cf27d2d41eeb61270052622f1a8e18ed4de02db91ec18c5043")
