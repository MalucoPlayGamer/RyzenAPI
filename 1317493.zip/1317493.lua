-- Lua provided by RyzenAPI
-- Game: addappid(1317493)

-- MAIN APPLICATION
addappid(1317493)
addappid(1317572)
addappid(1317573)
addappid(1317575)
addappid(1317576)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317493,0,"ed4bd989a3eea1bbbcf4dbff23ee8bc9285fd8ceef63ffdf50b1711812969d18")
addappid(1317570,0,"f701af55986ea65ec4445b82309db0b3079ec05693360f0dd5a033a7b55d717f")
addappid(1317571,0,"3c701402a583f4c34a9fccb0eb8f5229b8ae3994d8b98fd803b44e716a166e81")
addappid(1317574,0,"684ec781ca0639a4b695715ac35cfc47cb7d8bde24c108041aa62bf363d0b061")
