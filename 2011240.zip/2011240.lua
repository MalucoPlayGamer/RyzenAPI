-- Lua provided by RyzenAPI
-- Game: 2011240

-- MAIN APPLICATION
addappid(2011240)
-- Game: addappid(2011240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011241, 1, "a30d26204a8404ef8c9008b14427a65f1ea96a4a52085cb7b219c1b1cbcfb247")
