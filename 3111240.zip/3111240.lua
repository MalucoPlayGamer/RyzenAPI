-- Lua provided by RyzenAPI
-- Game: Agent Horny - Season 1

-- MAIN APPLICATION
addappid(3111240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111241, 1, "f5e61931aaa6d6a0d9f3be337ce7f0652802ba9bf8ea94c64251f4f38e6e26c7")
