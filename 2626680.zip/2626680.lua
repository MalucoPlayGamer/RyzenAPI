-- Lua provided by RyzenAPI
-- Game: You Are Liam: Shadow Memories

-- MAIN APPLICATION
addappid(2626680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626681, 1, "50297dd50cf89483229493803e8542e205af5970eae39d97223608abc4594e29")
