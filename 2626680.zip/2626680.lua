-- Lua provided by RyzenAPI
-- Game: You Are Liam: Shadow Memories

-- MAIN APPLICATION
addappid(2626680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2626681, 1, "50297dd50cf89483229493803e8542e205af5970eae39d97223608abc4594e29")

