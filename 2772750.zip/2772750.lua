-- Lua provided by RyzenAPI 
-- Game: AppID 2772750
addappid(2772750)
addappid(2772751, 1, "1ba0a188cd6a0fd66ff7664712ff982f4dbd0400ff82ebe3297a8d12a940be37")
