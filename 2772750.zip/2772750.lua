-- Lua provided by RyzenAPI
-- Game: Age of History 3

-- MAIN APPLICATION
addappid(2772750)
addappid(3238550)
addappid(3250400)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(2772751, 1, "1ba0a188cd6a0fd66ff7664712ff982f4dbd0400ff82ebe3297a8d12a940be37")

