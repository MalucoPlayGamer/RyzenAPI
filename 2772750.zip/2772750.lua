-- Lua provided by RyzenAPI
-- Game: 2772750

-- MAIN APPLICATION
addappid(2772750)
-- Game: addappid(2772750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772751, 1, "1ba0a188cd6a0fd66ff7664712ff982f4dbd0400ff82ebe3297a8d12a940be37")
