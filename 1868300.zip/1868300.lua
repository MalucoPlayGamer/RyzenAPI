-- Lua provided by RyzenAPI
-- Game: American Theft 80s: Prologue

-- MAIN APPLICATION
addappid(1868300)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1868301, 1, "417eaa9365b63a59f8755f80e7627f38c485a2e1038c1e72f0e398208ba7752d")

