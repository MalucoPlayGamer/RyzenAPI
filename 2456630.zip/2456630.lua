-- Lua provided by RyzenAPI
-- Game: Love n Life: Lucky Teacher Demo

-- MAIN APPLICATION
addappid(2456630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2456631, 1, "3b94459e7bf81fa0b9f069e4b94b8d6e9f4844f71f5062620462076ebc07a333")
