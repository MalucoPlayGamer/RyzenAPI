-- Lua provided by RyzenAPI
-- Game: Maidens of the Ocean Solitaire

-- MAIN APPLICATION
addappid(1333900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333901, 1, "5766b23db7776e56778c497bd4db382b86a62cc2225f85e914fb1f5af0160606")
