-- Lua provided by RyzenAPI
-- Game: Game: ~Be a maid in the Demon World~ The Secret Café of the Demon Angel Hero.

-- MAIN APPLICATION
addappid(1377550)
-- Game: addappid(1377550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377551, 1, "ab2a8bf9e78f7764b620e24cbf4bf5f84eb72d571bac1fd28c5d598cf89e7c57")
addappid(1484220, 0, "73aadf8d6cc464110ce3831601e41f389b5739c478ff493359da7eff12bd81b6")
