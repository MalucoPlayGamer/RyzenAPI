-- Lua provided by RyzenAPI
-- Game: Game: HOPE LEFT ME

-- MAIN APPLICATION
addappid(2268470)
-- Game: addappid(2268470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2268471, 1, "bb1eeaa2223aacb42d3a26364ec6cc2035b540878abcfee8650b587f250d91ac")
