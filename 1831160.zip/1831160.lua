-- Lua provided by RyzenAPI
-- Game: Monkey Barrels

-- MAIN APPLICATION
addappid(1831160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831161, 1, "68409a0fea18973409d0e245e8fe283b649e1d33cae4b751d298ade13e7aa8fd")
