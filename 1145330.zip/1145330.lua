-- Lua provided by RyzenAPI
-- Game: Skeleton Crew

-- MAIN APPLICATION
addappid(1145330)
addappid(2052530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145331, 1, "bf67d840b19b93baa740266f1a49e184219c48bdb312a6568f8319c02e0b8579")

