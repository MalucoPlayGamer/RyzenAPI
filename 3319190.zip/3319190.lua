-- Lua provided by RyzenAPI
-- Game: Hlína Demo

-- MAIN APPLICATION
addappid(3319190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319191, 1, "6e06bbd43ec6b3b86cbe6fece808b7d1a11bc3ac32b67e5002b7c65d21fce6f6")

