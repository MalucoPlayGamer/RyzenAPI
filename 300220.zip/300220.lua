-- Lua provided by RyzenAPI
-- Game: addappid(300220)

-- MAIN APPLICATION
addappid(300220)

-- MAIN APP DEPOTS / PACKAGES
addappid(300221, 1, "04c4b10af597adf34b44513456755c8ca47a529f0a9f1024863f881bc0ef166e")
