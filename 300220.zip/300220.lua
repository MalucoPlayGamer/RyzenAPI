-- Lua provided by SkyAPI 
-- Game: Victim of Xen
addappid(300220)
addappid(300221, 1, "04c4b10af597adf34b44513456755c8ca47a529f0a9f1024863f881bc0ef166e")
