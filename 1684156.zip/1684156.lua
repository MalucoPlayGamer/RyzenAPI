-- Lua provided by RyzenAPI
-- Game: addappid(1684156)

-- MAIN APPLICATION
addappid(1684156)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684156,0,"8e5909b7951cdd480bfb8d85925209b365de23f35c03bf0a2a4ab2ea4b60429d")
