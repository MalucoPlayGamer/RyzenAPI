-- Lua provided by SkyAPI 
-- Game: Initiation
addappid(2388170)
addappid(2388171, 1, "1c96bb3e86bd02b43aab0c004175f90b1610919bf6bf7917649e4e82882ad1d0")
