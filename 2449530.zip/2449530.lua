-- Lua provided by RyzenAPI
-- Game: Gehenna

-- MAIN APPLICATION
addappid(2449530) -- Gehenna

-- MAIN APP DEPOTS / PACKAGES
addappid(2449532, 1, "ddb96ea7fad3dcd812d654bbfe9391883cacdb2255b9d690283d0d0e9eba583b") -- Depot 2449532
