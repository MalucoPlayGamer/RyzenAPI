-- Lua provided by RyzenAPI
-- Game: NTR by my Younger Childhood Friend!? His size Ruined Me for My Boyfriend!!

-- MAIN APPLICATION
addappid(4583830)

-- MAIN APP DEPOTS / PACKAGES
addappid(4583831,0,"839eaa729362713c055e242b70f7375e5c0f0d6ac0c73c455ed2786cc27102ee")

