-- Lua provided by RyzenAPI
-- Game: AppID 579820

-- MAIN APPLICATION
addappid(579820)
-- Game: addappid(579820)

-- MAIN APP DEPOTS / PACKAGES
addappid(579821, 1, "526733615aa7bf8ca7e12dfdb9440be0878aced38412a20be7811b8de95bea67")
