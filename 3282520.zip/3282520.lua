-- Lua provided by RyzenAPI
-- Game: Game: GARDEN&BIRD

-- MAIN APPLICATION
addappid(3282520)
-- Game: addappid(3282520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3282521, 1, "0a5454454b269380e45a9f23e3c3d6cb45070190b80b3d97654c501ad9ed5ea5")
