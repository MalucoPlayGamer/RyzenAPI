-- Lua provided by SkyAPI 
-- Game: GARDEN&BIRD
addappid(3282520)
addappid(3282521, 1, "0a5454454b269380e45a9f23e3c3d6cb45070190b80b3d97654c501ad9ed5ea5")
