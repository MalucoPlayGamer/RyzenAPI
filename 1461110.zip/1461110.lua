-- Lua provided by SkyAPI 
-- Game: AppID 1461110
addappid(1461110)
addappid(1461111, 1, "467d4f9c0d78159fb8c6caf10aafd81e2b4e3f7a7305cb03da29c5dc41942fec")
