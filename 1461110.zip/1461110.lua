-- Lua provided by RyzenAPI
-- Game: AppID 1461110

-- MAIN APPLICATION
addappid(1461110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461111, 1, "467d4f9c0d78159fb8c6caf10aafd81e2b4e3f7a7305cb03da29c5dc41942fec")

