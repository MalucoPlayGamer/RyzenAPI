-- Lua provided by RyzenAPI
-- Game: Game: 101 Cats in Los Angeles

-- MAIN APPLICATION
addappid(3213720)
-- Game: addappid(3213720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213721, 1, "fddd2512dd56d3961c2d8f4d9670083f916ef8ca73e9a8c05c0e6f133f6ad4da")
