-- Lua provided by RyzenAPI
-- Game: SLUDGE LIFE 2 Demo

-- MAIN APPLICATION
addappid(2275160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275161, 1, "3a3db96edfb030c11c3bdf6e1cc49097d844a00ba4658292b322f3ea9323ee05")

