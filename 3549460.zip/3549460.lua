-- Lua provided by RyzenAPI
-- Game: Game: Dark Deity 2 Soundtrack

-- MAIN APPLICATION
addappid(3549460)
-- Game: addappid(3549460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3549461, 1, "a004562894a56f171e66e42994b5c61febd254c5fc176a196afaf4a2844e2dd1")
