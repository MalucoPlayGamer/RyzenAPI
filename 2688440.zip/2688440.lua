-- Lua provided by RyzenAPI
-- Game: Fimbul's Gemboree

-- MAIN APPLICATION
addappid(2688440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688441, 1, "2bc08100b4d6cd28f4ba3a147a3c8f159167ba0818461fb41e1fce5fdfd78cb2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
