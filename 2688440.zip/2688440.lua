-- Lua provided by RyzenAPI 
-- Game: Fimbul's Gemboree
addappid(2688440)
addappid(2688441, 1, "2bc08100b4d6cd28f4ba3a147a3c8f159167ba0818461fb41e1fce5fdfd78cb2")
