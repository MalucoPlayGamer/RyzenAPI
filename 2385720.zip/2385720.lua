-- Lua provided by RyzenAPI
-- Game: The Police Mystery

-- MAIN APPLICATION
addappid(2385720)
-- Game: addappid(2385720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385721, 1, "23b256fcb1ae41dcbea59c8be70e8ad07d531c47d8ba063cc78ce5907ec12c5c")
