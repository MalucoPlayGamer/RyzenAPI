-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1624830)
-- Game: addappid(1624830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624833,0,"e8af25921ebeb24d72737f3cb39e8979f93222028d05b1e98267d3daf1f82013")
addappid(1624834,0,"be776895417cefb2513ce1835f5aace141b112366afef95fcb0727c80d06fc81")
