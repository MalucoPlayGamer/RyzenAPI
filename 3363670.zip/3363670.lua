-- Lua provided by RyzenAPI
-- Game: Shard Squad Demo

-- MAIN APPLICATION
addappid(3363670)
-- Game: addappid(3363670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3363671, 1, "f3ca74ae1dcdf31ea49caf8c8e3a0731bd49da327560640369911ef99161df63")
