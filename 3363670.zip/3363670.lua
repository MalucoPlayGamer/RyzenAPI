-- Lua provided by SkyAPI 
-- Game: Shard Squad Demo
addappid(3363670)
addappid(3363671, 1, "f3ca74ae1dcdf31ea49caf8c8e3a0731bd49da327560640369911ef99161df63")
