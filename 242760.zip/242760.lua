-- Lua provided by RyzenAPI
-- Game: The Forest

-- MAIN APPLICATION
addappid(242760)

-- MAIN APP DEPOTS / PACKAGES
addappid(242761, 1, "786dfb9db41be351c888b4a930d5295dfe6c8c4bbc4e442f0e1ced301c4d24df")

