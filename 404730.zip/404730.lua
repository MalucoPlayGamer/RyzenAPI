-- Lua provided by RyzenAPI
-- Game: Wasteland 2: Director's Cut

-- MAIN APPLICATION
addappid(404730)

-- MAIN APP DEPOTS / PACKAGES
addappid(404731, 1, "8a43acccae69eaf92ea38d8f0c0cb9355f25cb77b827c5a937b74d6784203749")
addappid(404732, 1, "01f5aaa92342a9403d926c0fc95b5822c00fed3d797337ce5724abafa5042e1f")
addappid(404733, 1, "db9cd37feb586be00ebd7c058fbb988166786802dcca812078b302accae705d4")
addappid(410641, 0, "de5452a4ad75060d378081835c1e66b2549dcf87bfa31f941f99258561548d55")
addappid(410650, 0, "c8cba2ad89980df14568e2a48cf5b024f1b9b6e135e29948e25efa4b3bdaa289")
addappid(410651, 0, "4d973b1fc19d292d2eed52126b4f166c1f7845b3ce9418396823c945e13bdb2f")
addappid(410652, 0, "a4cbb1f7767bdffb4948897a680f1fadfee4dd2f344b6e400755551c0553a5e4")
addappid(410653, 0, "e8b7af2eb03e67117267042cfe6b3ab5f1c9f3d33717e3dfd43349f50bcc432a")
addappid(410654, 0, "e059b7d71b3940f42ce86680484cdabe327d76b5b7a7b09d054110c08f71a49f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(410640)
addappid(410690)
