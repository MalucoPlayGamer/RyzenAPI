-- Lua provided by RyzenAPI
-- Game: Skillwood Demo

-- MAIN APPLICATION
addappid(2783410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783411, 1, "f95e60be88996a65aafc8d24c834b15a2bd2a0296dfc21ab1069608d7efb1f7c")
