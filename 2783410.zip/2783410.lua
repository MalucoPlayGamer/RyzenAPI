-- Lua provided by SkyAPI 
-- Game: Skillwood Demo
addappid(2783410)
addappid(2783411, 1, "f95e60be88996a65aafc8d24c834b15a2bd2a0296dfc21ab1069608d7efb1f7c")
