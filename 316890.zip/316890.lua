-- Lua provided by RyzenAPI 
-- Game: AppID 316890
addappid(316890)
addappid(316891, 1, "3acaa321392e32f5161e28d4e657e2b409daebd87a3342b244378964568fbba7")
