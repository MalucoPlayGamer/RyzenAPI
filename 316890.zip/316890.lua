-- Lua provided by RyzenAPI
-- Game: Game: AppID 316890

-- MAIN APPLICATION
addappid(316890)
-- Game: addappid(316890)

-- MAIN APP DEPOTS / PACKAGES
addappid(316891, 1, "3acaa321392e32f5161e28d4e657e2b409daebd87a3342b244378964568fbba7")
