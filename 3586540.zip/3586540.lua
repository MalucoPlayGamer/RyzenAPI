-- Lua provided by RyzenAPI
-- Game: Grit and Valor - 1949: Original Soundtrack

-- MAIN APPLICATION
addappid(3586540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586541, 1, "22f65cfc6923998132fd5bf4346fc252e2e1c940050d99153aaada334ef2804b")
