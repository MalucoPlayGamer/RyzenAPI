-- Lua provided by RyzenAPI
-- Game: Sakura MMO 3

-- MAIN APPLICATION
addappid(1064130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064131, 1, "4fa768d8af336643ab4e1024f0fe10f8833e7223f2b71797246191cba9b0d6d8")

