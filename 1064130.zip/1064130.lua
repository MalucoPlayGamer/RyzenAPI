-- Lua provided by RyzenAPI 
-- Game: AppID 1064130
addappid(1064130)
addappid(1064131, 1, "4fa768d8af336643ab4e1024f0fe10f8833e7223f2b71797246191cba9b0d6d8")
