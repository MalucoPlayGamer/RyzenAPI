-- Lua provided by RyzenAPI
-- Game: Guns of Succubus 2

-- MAIN APPLICATION
addappid(2474830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474832,0,"c4f732b1eab28d1e2adb39760326aaa04317272dcc708f0aeb967a0cc247b840")
addappid(2474833,0,"a9505ad27fadc41598b01a47b373f311e3fd83ad42768a3e9e7ede74e3febd98")
