-- Lua provided by RyzenAPI
-- Game: DiveReal (inactive, stopped)

-- MAIN APPLICATION
addappid(865200)
-- Game: addappid(865200)

-- MAIN APP DEPOTS / PACKAGES
addappid(865201, 1, "ae5cc48ea37ee59a7a8c86a8081e911b1bcdcbc77812426d6a558b61e15c4008")
