-- Lua provided by RyzenAPI
-- Game: 796470

-- MAIN APPLICATION
addappid(796470)
-- Game: addappid(796470)

-- MAIN APP DEPOTS / PACKAGES
addappid(796471, 1, "155eaa3c774eeb22420e6fd3d73ffbe286a1c268e9940614f7648eaf1ca26a68")
