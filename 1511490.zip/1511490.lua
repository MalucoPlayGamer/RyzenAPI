-- Lua provided by RyzenAPI
-- Game: Happy Valentine's Day

-- MAIN APPLICATION
addappid(1511490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511491, 1, "f8686bbfc3bc000ff509a6d1fc29ba30e3f7389513ab1f21895ff9963ce7a12c")
