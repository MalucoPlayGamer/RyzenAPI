-- Lua provided by RyzenAPI 
-- Game: AppID 1511490
addappid(1511490)
addappid(1511491, 1, "f8686bbfc3bc000ff509a6d1fc29ba30e3f7389513ab1f21895ff9963ce7a12c")
