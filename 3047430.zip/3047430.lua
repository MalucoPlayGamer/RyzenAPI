-- Lua provided by SkyAPI 
-- Game: Men against Lizards
addappid(3047430)
addappid(3047431, 1, "43075a870719fd6326745b732e71cd1bf39ed995771aeb528f4c7ba5b4c9091d")
