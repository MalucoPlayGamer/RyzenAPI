-- Lua provided by RyzenAPI
-- Game: GUNHEAD

-- MAIN APPLICATION
addappid(704000)
-- Game: addappid(704000)

-- MAIN APP DEPOTS / PACKAGES
addappid(704001, 1, "571a303fee1a42d1121bb33f4bfb5917f96ea44376f7044c780ee0050ec488ee")
