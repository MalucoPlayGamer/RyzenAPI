-- Lua provided by RyzenAPI
-- Game: 2386660

-- MAIN APPLICATION
addappid(2386660)
-- Game: addappid(2386660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386661, 1, "482d6de1454a2e3602fc046e3c93795d62102ca7b9ab2e4559ffc109a1d16cd3")
