-- Lua provided by RyzenAPI
-- Game: 1228320

-- MAIN APPLICATION
addappid(1228320)
-- Game: addappid(1228320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228321, 1, "a0c6221db82d65b5e494caf461748b9720a3237ef798fdcf13e6ce2b9e00bab8")
