-- Lua provided by SkyAPI 
-- Game: Dungeon Looter
addappid(1228320)
addappid(1228321, 1, "a0c6221db82d65b5e494caf461748b9720a3237ef798fdcf13e6ce2b9e00bab8")
