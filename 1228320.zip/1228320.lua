-- Lua provided by RyzenAPI
-- Game: Dungeon Looter

-- MAIN APPLICATION
addappid(1228320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1228321, 1, "a0c6221db82d65b5e494caf461748b9720a3237ef798fdcf13e6ce2b9e00bab8")

