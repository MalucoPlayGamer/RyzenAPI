-- Lua provided by RyzenAPI
-- Game: Color Guardian

-- MAIN APPLICATION
addappid(937130)
addappid(938530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(937131, 1, "111f4460bbcbcdadaa9f9dc5e5e4b87675b863e85960aa3471b9ba853cb1acfc")

