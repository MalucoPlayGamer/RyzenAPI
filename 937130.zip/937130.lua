-- Lua provided by RyzenAPI
-- Game: addappid(937130)

-- MAIN APPLICATION
addappid(937130)
addappid(938530)

-- MAIN APP DEPOTS / PACKAGES
addappid(937131, 1, "111f4460bbcbcdadaa9f9dc5e5e4b87675b863e85960aa3471b9ba853cb1acfc")
