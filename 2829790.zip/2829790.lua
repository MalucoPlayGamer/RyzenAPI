-- Lua provided by RyzenAPI
-- Game: 2829790

-- MAIN APPLICATION
addappid(2829790)
addappid(3145870)
-- Game: addappid(2829790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2829791, 1, "f205e2369971a3648f4ecfa09318f96511a707f005a067f90384a8dedc8c1d34")
