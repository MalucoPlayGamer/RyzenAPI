-- Lua provided by RyzenAPI
-- Game: Windstorm: Start of a Great Friendship - Remastered

-- MAIN APPLICATION
addappid(2829790)
addappid(3145870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2829791, 1, "f205e2369971a3648f4ecfa09318f96511a707f005a067f90384a8dedc8c1d34")
