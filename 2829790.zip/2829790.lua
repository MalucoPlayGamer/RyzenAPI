-- Lua provided by RyzenAPI
-- Game: Windstorm: Start of a Great Friendship - Remastered

-- MAIN APPLICATION
addappid(2829790)
addappid(3145870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2829791, 1, "f205e2369971a3648f4ecfa09318f96511a707f005a067f90384a8dedc8c1d34")

