-- Lua provided by RyzenAPI
-- Game: 异世界的回响千雪之歌

-- MAIN APPLICATION
addappid(2093100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093101, 1, "7e45b7a151a1d99391d9452ba6a85dc6d76837d38373c38c28b3a73cf8258fbe")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2137210)
