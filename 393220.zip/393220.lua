-- Lua provided by RyzenAPI
-- Game: Super Man Or Monster

-- MAIN APPLICATION
addappid(393220)

-- MAIN APP DEPOTS / PACKAGES
addappid(393221, 1, "887a53cdd5f05ea24d070df1c48925e254dd55c2caa94467ea5e1e9a2a56d687")

