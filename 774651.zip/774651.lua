-- Lua provided by RyzenAPI
-- Game: MIGHTY GUNVOLT BURST

-- MAIN APPLICATION
addappid(774651)

-- MAIN APP DEPOTS / PACKAGES
addappid(774652, 1, "e13601809c9dda902b2f1127acf3b5f64c82fbf424e4f54623df5e316d5514f3")
addappid(1117940, 0, "89c5e7ad89e852e4fe0f4695edbab0c97804f08d9d968b780c415dfbde623246")
addappid(1117950, 0, "b2402b1f9541f7418c208217d5932bf837024ebb272b5a38f210ac7e60ce4cf9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
