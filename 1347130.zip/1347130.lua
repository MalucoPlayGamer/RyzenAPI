-- Lua provided by RyzenAPI 
-- Game: AppID 1347130
addappid(1347130)
addappid(1347131, 1, "bb007735179de591ef7481ecb739304165982acc7c16870575ab57ef5c19ddd2")
