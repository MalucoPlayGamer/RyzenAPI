-- Lua provided by RyzenAPI
-- Game: 1347130

-- MAIN APPLICATION
addappid(1347130)
-- Game: addappid(1347130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347131, 1, "bb007735179de591ef7481ecb739304165982acc7c16870575ab57ef5c19ddd2")
