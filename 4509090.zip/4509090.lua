-- Lua provided by RyzenAPI
-- Game: Room Craft

-- MAIN APPLICATION
addappid(4509090)

-- MAIN APP DEPOTS / PACKAGES
addappid(4509091,0,"d58f650a42395271646a3d6709f57453c76315ec2869dbe785b2e5bcbddb0a24")

