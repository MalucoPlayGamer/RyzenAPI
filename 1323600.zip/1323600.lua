-- Lua provided by RyzenAPI
-- Game: Game: Johnny Mystery and The Halloween Killer

-- MAIN APPLICATION
addappid(1323600)
-- Game: addappid(1323600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323601, 1, "980457b0b465e977b1018674e53f9e3139f5339277fb968f7a4e00a68f5fb705")
