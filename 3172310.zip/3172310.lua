-- Lua provided by RyzenAPI
-- Game: Sex Desert: Mad Lust

-- MAIN APPLICATION
addappid(3172310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172311, 1, "e00d93bf5a25fff5de35f341dae52e61922bbde6debb7529c93bfcbe7eeda48c")

