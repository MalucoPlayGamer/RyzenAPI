-- Lua provided by RyzenAPI
-- Game: 1591450

-- MAIN APPLICATION
addappid(1591450)
-- Game: addappid(1591450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591451, 1, "2d16de30e0dea4008e59aabac4b3cff65bae888c1489c4b281778c365d1105c5")
