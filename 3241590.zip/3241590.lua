-- Lua provided by RyzenAPI
-- Game: Game of Fate 2 : A Century's Promise-4K Texture Enhancement Pack

-- MAIN APPLICATION
addappid(3241590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241591, 1, "a283795f23d8e5ffc931b994da708659eee4cf540890ada3b6dd477933631c6e")

