-- Lua provided by RyzenAPI
-- Game: LEGO® Voyagers

-- MAIN APPLICATION
addappid(1538550)
addappid(3669480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538551, 1, "4480fe48e0c0f27c257acff9ec6ed18d2b126796054fb578c1c717e94dd33f82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
