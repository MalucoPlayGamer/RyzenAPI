-- Lua provided by RyzenAPI 
-- Game: LEGO® Voyagers
addappid(1538550)
addappid(1538551, 1, "4480fe48e0c0f27c257acff9ec6ed18d2b126796054fb578c1c717e94dd33f82")
addappid(3669480)
