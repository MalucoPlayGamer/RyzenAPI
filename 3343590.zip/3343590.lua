-- Lua provided by RyzenAPI
-- Game: 3343590

-- MAIN APPLICATION
addappid(3343590)
addappid(3343610)
-- Game: addappid(3343590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343591, 1, "17acc426d3fb9a390b5f29f03e715292d122e99d8bdf80bd79b8e1203c329e42")
addappid(3343592, 1, "daab6671c81d8ecb14d705c763c4cb9358eff39b09d759b3c10eefa6c98c9103")
addappid(3343593, 1, "f13e3191dd1a2ebcf89c03c65e4caea004fdddb656b3b188dcaebd15fcea876d")
