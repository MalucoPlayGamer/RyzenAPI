-- Lua provided by RyzenAPI
-- Game: Game: Maximum Override

-- MAIN APPLICATION
addappid(389220)
-- Game: addappid(389220)

-- MAIN APP DEPOTS / PACKAGES
addappid(389221, 1, "6c2c9b3fefe256ae8a6d24709cd7f89440ab6ac31b5bdd8fb36f6815f0518d60")
