-- Lua provided by RyzenAPI
-- Game: Disney Infinity 2.0: Gold Edition

-- MAIN APPLICATION
addappid(541660)
-- Game: addappid(541660)

-- MAIN APP DEPOTS / PACKAGES
addappid(541661, 1, "599196c25d2e4ec7f144042099c4008e772cbe9b27ec8141528921e911708b22")
