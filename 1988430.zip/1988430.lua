-- Lua provided by RyzenAPI
-- Game: Slaughter Cannon 2

-- MAIN APPLICATION
addappid(1988430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988431, 1, "f0a3cef1aecd3e1a8dd0cccc70429708b6ee8eda273eae0e5d51fc34e79290d6")

