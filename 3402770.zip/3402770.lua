-- Lua provided by SkyAPI 
-- Game: AppID 3402770
addappid(3402770)
addappid(3402771, 1, "46b9eb6a39a74db8e6c069067f2451324d6fa53ce74e640d0bdb22b8583fd739")
