-- Lua provided by RyzenAPI
-- Game: Badlands Crew Demo

-- MAIN APPLICATION
addappid(3402770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402771, 1, "46b9eb6a39a74db8e6c069067f2451324d6fa53ce74e640d0bdb22b8583fd739")
