-- Lua provided by RyzenAPI
-- Game: Game: Empress Of The Deep 2: Song Of The Blue Whale

-- MAIN APPLICATION
addappid(299160)
-- Game: addappid(299160)

-- MAIN APP DEPOTS / PACKAGES
addappid(299161, 1, "00083ae1915f1e6c462a3c56b4de7d82b7137c99a0b39f990886224d05385bde")
