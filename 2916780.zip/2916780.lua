-- Lua provided by RyzenAPI
-- Game: Digital Audio Wasteland

-- MAIN APPLICATION
addappid(2916780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2916781, 1, "b6e7b5cce81f690ec3e6d2d313628fc2eff67910e5df2406639adabc66d403bf")

