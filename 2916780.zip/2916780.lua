-- Lua provided by RyzenAPI 
-- Game: Digital Audio Wasteland
addappid(2916780)
addappid(2916781, 1, "b6e7b5cce81f690ec3e6d2d313628fc2eff67910e5df2406639adabc66d403bf")
