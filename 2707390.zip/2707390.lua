-- Lua provided by RyzenAPI 
-- Game: Sicaria
addappid(2707390)
addappid(2707391, 1, "9ad5ecef7607cb864682ec20c1a5931b0bbd99049956156f25dbe6fedb643fd0")
