-- Lua provided by RyzenAPI
-- Game: AppID 870680

-- MAIN APPLICATION
addappid(870680)

-- MAIN APP DEPOTS / PACKAGES
addappid(870681, 1, "5befdda2a43f33aab393a3b3c6dc4a1faafaab4c5e46b8133a8eda1304abdf0e")
