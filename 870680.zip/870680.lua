-- Lua provided by RyzenAPI
-- Game: AppID 870680

-- MAIN APPLICATION
addappid(870680)

-- MAIN APP DEPOTS / PACKAGES
addappid(870681, 1, "5befdda2a43f33aab393a3b3c6dc4a1faafaab4c5e46b8133a8eda1304abdf0e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
