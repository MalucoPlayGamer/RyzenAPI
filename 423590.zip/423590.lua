-- Lua provided by RyzenAPI
-- Game: addappid(423590)

-- MAIN APPLICATION
addappid(423590)

-- MAIN APP DEPOTS / PACKAGES
addappid(423591, 1, "7bfdce1a68a2d5141d0a505fc031e983169cee973a5907ab3d7c66271b2d55ea")
addappid(423592, 1, "5e84b683cf0099165d4a9c96dcfc4ee5e7acdc8647651409241c0c886b594df1")
addappid(423593, 1, "4ab2dc1a6941a513bb9f2d47bc6f58f3a99cbfbee410c4190786dcb81f4af1a7")
addappid(554340, 0, "876c11b7d6e580cbba99ee0406bba9c1a0ac671a24498b629e4195bd3e0383fb")
