-- Lua provided by RyzenAPI
-- Game: Game: Assassin's Belief

-- MAIN APPLICATION
addappid(2918730)
-- Game: addappid(2918730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918731, 1, "387abfaf116eb15c9ecc2e7bf1e2b53ceeb6551bd1a84ce3eebd2935c78f49ca")
