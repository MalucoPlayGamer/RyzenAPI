-- Lua provided by SkyAPI 
-- Game: AppID 2889770
addappid(2889770)
addappid(2889771, 1, "3386f919bf168324150dbc4f4907862d7f39ab6108d1081736d027ad35b5bd13")
