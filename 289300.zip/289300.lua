-- Lua provided by RyzenAPI
-- Game: Faces of War

-- MAIN APPLICATION
addappid(289300)

-- MAIN APP DEPOTS / PACKAGES
addappid(289301, 1, "cdbcb149cc4aca35c5cb9ae1d48841c15dd40134c3e2bd18edf1d30facd7dace")
addappid(289302, 1, "44f55853e3a5c97e045ebb81533d23fe14d86684d4f42e5b71a96fd4a017003c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
