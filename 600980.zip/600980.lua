-- Lua provided by RyzenAPI
-- Game: addappid(600980)

-- MAIN APPLICATION
addappid(600980)

-- MAIN APP DEPOTS / PACKAGES
addappid(600981, 1, "4058ae8a5d4c47d88888dc665630ee47b649fe962c70c4e11b2dcdc6039d8106")
