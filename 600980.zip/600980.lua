-- Lua provided by SkyAPI 
-- Game: AppID 600980
addappid(600980)
addappid(600981, 1, "4058ae8a5d4c47d88888dc665630ee47b649fe962c70c4e11b2dcdc6039d8106")
