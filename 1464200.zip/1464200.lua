-- Lua provided by RyzenAPI
-- Game: Divine Stone

-- MAIN APPLICATION
addappid(1464200)
-- Game: addappid(1464200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464201, 1, "e1447768de804375becc972fbc56fd60af0f8b58d33a5d49865029efd4439f95")
