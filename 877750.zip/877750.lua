-- Lua provided by RyzenAPI
-- Game: Coinon

-- MAIN APPLICATION
addappid(877750)

-- MAIN APP DEPOTS / PACKAGES
addappid(877751,0,"b5c55cba4064ee1c8d10f156899434a919feb19ed347f7432b9c3c175c4847ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
