-- Lua provided by RyzenAPI
-- Game: Coinon

-- MAIN APPLICATION
addappid(877750)

-- MAIN APP DEPOTS / PACKAGES
addappid(877751,0,"b5c55cba4064ee1c8d10f156899434a919feb19ed347f7432b9c3c175c4847ef")

