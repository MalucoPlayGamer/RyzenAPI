-- Lua provided by RyzenAPI
-- Game: Rosenkreuzstilette Freudenstachel

-- MAIN APPLICATION
addappid(564160)

-- MAIN APP DEPOTS / PACKAGES
addappid(564162,0,"336c067743e174c2d5745817ce1d57275c7e25f9f60a49e62596aa4954a63801")
addappid(564163,0,"75371a2c02bcd59e840ee1c7795b8a13c0d21803c0b8e01402fe00091692b5f5")

