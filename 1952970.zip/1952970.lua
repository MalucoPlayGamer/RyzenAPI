-- Lua provided by RyzenAPI 
-- Game: Reality Simulator
addappid(1952970)
addappid(1952971, 1, "8c62e3903de213e212be28b05ab493c4d4f24271f03017b241f0c6572515e06b")
