-- Lua provided by RyzenAPI
-- Game: In Stars And Time Demo

-- MAIN APPLICATION
addappid(2126290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126291, 1, "3842a32cbd8b1408a581cb488e2328ba1ef5d3ead58672a9ed4332b75e2ba209")

