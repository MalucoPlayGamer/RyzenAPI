-- Lua provided by RyzenAPI
-- Game: addappid(3309720)

-- MAIN APPLICATION
addappid(3309720)
addappid(3336090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3309721, 1, "f3007d1aca15ea7eb1ca3e476590acb84e24f5edea85af8a2d3bc544d58e98f5")
