-- Lua provided by RyzenAPI
-- Game: Game: o-o

-- MAIN APPLICATION
addappid(2287040)
-- Game: addappid(2287040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287041, 1, "6df577fe3d008839579905d6953325920c176a805ca5c0732e964f1005b2f805")
