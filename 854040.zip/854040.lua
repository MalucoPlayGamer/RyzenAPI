-- Lua provided by RyzenAPI
-- Game: AppID 854040

-- MAIN APPLICATION
addappid(854040)
-- Game: addappid(854040)

-- MAIN APP DEPOTS / PACKAGES
addappid(854041, 1, "9d3b2f33a91b959466e25ed540fbb87c31ac3fa1349bfa08e41fc7a122775943")
