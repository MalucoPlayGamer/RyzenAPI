-- Lua provided by RyzenAPI
-- Game: Game: When The Devil Takes Hold

-- MAIN APPLICATION
addappid(2274970)
-- Game: addappid(2274970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274971, 1, "4ee44ce4208fec10ca927660f32b511af52aa42a00849dffa4b1cd47e080d2b1")
