-- Lua provided by RyzenAPI
-- Game: Game: Hospital Tycoon

-- MAIN APPLICATION
addappid(11590)
-- Game: addappid(11590)

-- MAIN APP DEPOTS / PACKAGES
addappid(11591, 1, "13630f82f9ab80654b04452602e770eac027f4d9a9debd9d3fe399c7ec116967")
