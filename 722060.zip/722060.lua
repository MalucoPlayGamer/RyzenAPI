-- Lua provided by RyzenAPI
-- Game: Dominions 5

-- MAIN APPLICATION
addappid(722060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(722061, 1, "40ebac3276fadce4a824a5b1b65378300d3ccd8d0389b1a2641c9e06ba7b464b")
