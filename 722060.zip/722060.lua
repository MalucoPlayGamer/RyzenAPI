-- Lua provided by RyzenAPI
-- Game: AppID 722060

-- MAIN APPLICATION
addappid(722060)
-- Game: addappid(722060)

-- MAIN APP DEPOTS / PACKAGES
addappid(722061, 1, "40ebac3276fadce4a824a5b1b65378300d3ccd8d0389b1a2641c9e06ba7b464b")
