-- Lua provided by RyzenAPI
-- Game: Game: Exhausted Man

-- MAIN APPLICATION
addappid(1598580)
-- Game: addappid(1598580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598581, 1, "a6c71c2a1dcc4131c8219664d80d45e4309708fff2df9e42d3e00d7e34e32dff")
