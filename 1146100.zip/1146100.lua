-- Lua provided by RyzenAPI
-- Game: 1146100

-- MAIN APPLICATION
addappid(1146100)
-- Game: addappid(1146100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146101, 1, "6c67c003295621ca50dee83afdc7cff8f7f88475ba6be87be53e7a7b4aacb35c")
addappid(1146102, 1, "30aa7207a1dfc1e6cc87f9652df1bcf77e48938a9e7c3bf0ea781ffe78f8231f")
addappid(1146104, 1, "4e1596145bc792853a6e67201be2b21d0b72e89a2478165890024f5e7d5f93af")
