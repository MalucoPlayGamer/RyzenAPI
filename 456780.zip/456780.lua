-- Lua provided by RyzenAPI
-- Game: DUCATI - 90th Anniversary

-- MAIN APPLICATION
addappid(456780)

-- MAIN APP DEPOTS / PACKAGES
addappid(456781, 1, "fd04e1640803dc5d5a2396558c399ae30261f39c37ff705b5f275317feaf436a")
