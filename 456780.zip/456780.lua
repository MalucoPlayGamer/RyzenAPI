-- Lua provided by RyzenAPI
-- Game: DUCATI - 90th Anniversary

-- MAIN APPLICATION
addappid(456780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(456781, 1, "fd04e1640803dc5d5a2396558c399ae30261f39c37ff705b5f275317feaf436a")

