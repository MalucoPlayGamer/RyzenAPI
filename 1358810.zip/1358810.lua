-- Lua provided by RyzenAPI
-- Game: Metal Force: Tank Games Online

-- MAIN APPLICATION
addappid(1358810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358811, 1, "fd53c415aa0d4e6c208e8a980b76bfea7e7674a294e6acf7ef24f097bcf05ce6")
addappid(1358812, 1, "7eeea82fdbb56215a74716beed1adc0175beeb4ad89d91bb9ef44447f2ded661")
addappid(1358813, 1, "4b3959bac7eb62e9672d6f84a53ab4115f8c21086236afd6c8ee4769120b8ee2")

