-- Lua provided by RyzenAPI
-- Game: Neckbeards: Basement Arena

-- MAIN APPLICATION
addappid(693380)
-- Game: addappid(693380)

-- MAIN APP DEPOTS / PACKAGES
addappid(693382,0,"f365873effce169155e0fbc4608c366f13fc1150d5ec995b09f1d7b7f1262627")
