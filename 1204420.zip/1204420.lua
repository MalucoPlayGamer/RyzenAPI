-- Lua provided by RyzenAPI 
-- Game: FlyManMissile Demo
addappid(1204420)
addappid(1204421, 1, "9744a1eee48ea4092e7c8417a9ee82d51b3a9a6d7ed12b2dec369d74bd9dc378")
