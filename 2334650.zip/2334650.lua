-- Lua provided by RyzenAPI
-- Game: MeiQi:Phoenix and the Chamber of Secrets

-- MAIN APPLICATION
addappid(2334650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2334651, 1, "4a47482378852f02b20a4e06437adb55eb8caa3c6c590082f6b2da591925b3a8")
