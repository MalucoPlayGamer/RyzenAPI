-- Lua provided by RyzenAPI
-- Game: 2334650

-- MAIN APPLICATION
addappid(2334650)
-- Game: addappid(2334650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334651, 1, "4a47482378852f02b20a4e06437adb55eb8caa3c6c590082f6b2da591925b3a8")
