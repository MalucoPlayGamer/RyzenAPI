-- Lua provided by RyzenAPI
-- Game: Gamble Fight Plus

-- MAIN APPLICATION
addappid(1028130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1028131, 1, "7743d352c4f59004fc3cf72f3572e9140ff3fad11c7adf0e4868ab91eb6abefd")
addappid(1028134, 1, "6deb9dffe57de06b02c4137ecbfda70955c49163a4883e609ef92fb762c1d6f8")

