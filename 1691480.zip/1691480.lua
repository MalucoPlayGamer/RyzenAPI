-- Lua provided by RyzenAPI
-- Game: World Titans War

-- MAIN APPLICATION
addappid(1691480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1691481, 1, "aa3e63c0bc7de344fdee4b59ecc0ff1f6fb41d9f8f1b5b541f39c51386b301e5")

