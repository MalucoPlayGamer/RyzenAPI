-- Lua provided by RyzenAPI
-- Game: Secret Agent

-- MAIN APPLICATION
addappid(358350)

-- MAIN APP DEPOTS / PACKAGES
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070") -- (windows)
addappid(358351, 1, "994c494affdbe2ec87ba1ae4dc5d9dbd4e95f156c7c58140b41d0f632524233e")
addappid(358352, 1, "61ce681cbc682814d077c32fb6b417e536c4b4431d2c76480713cfa834853dc7")

