-- Lua provided by RyzenAPI
-- Game: 358350

-- MAIN APPLICATION
addappid(358350)
-- Game: addappid(358350)

-- MAIN APP DEPOTS / PACKAGES
addappid(358351, 1, "994c494affdbe2ec87ba1ae4dc5d9dbd4e95f156c7c58140b41d0f632524233e")
addappid(358352, 1, "61ce681cbc682814d077c32fb6b417e536c4b4431d2c76480713cfa834853dc7")
