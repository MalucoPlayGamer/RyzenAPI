-- Lua provided by RyzenAPI
-- Game: Wreckfest

-- MAIN APPLICATION
addappid(228380)
addappid(228988)
addappid(228990)
addappid(272830)
addappid(272910)
addappid(884740)
addappid(893310)
addappid(1131170)
addappid(1135430)
addappid(1135431)
addappid(1135432)
addappid(1135433)
addappid(1135434)
addappid(1135435)
addappid(1135436)
addappid(1135437)
addappid(1135438)
addappid(1399410)
addappid(1399411)
addappid(1399412)
addappid(1413450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228381, 1, "0271ea41a7c1be1719138e5a1f9b0693cb88c1e55c6422b47179d559b95c9440")
addappid(272880, 0, "744ba266e5b45c9877051c47ee9d2fb3e9f50559bce63d86ff7ee7fcb6cdd196")

