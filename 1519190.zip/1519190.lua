-- Lua provided by RyzenAPI
-- Game: Game: Duck Flight Simulator 2021

-- MAIN APPLICATION
addappid(1519190)
-- Game: addappid(1519190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519191, 1, "2861cd7522f401a9b8321e9a4beafc9cf2be4176a0ed2237357a437e766f6e07")
