-- Lua provided by RyzenAPI
-- Game: Game: Galactic Defense: Automation Demo

-- MAIN APPLICATION
addappid(2455200)
-- Game: addappid(2455200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455201, 1, "eca2e760993e3c7bd69b9bcf88023d4214b2bad5686b2e6e2a1a63e8d7deae73")
