-- Lua provided by RyzenAPI
-- Game: No Way Home

-- MAIN APPLICATION
addappid(3246090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3246093,0,"fa1b3bce1c41a09246b7b51e393edd5082151e20dc0d37f1cb98f9b500e1fd39")
