-- Lua provided by RyzenAPI
-- Game: Paper io 2

-- MAIN APPLICATION
addappid(2751310)
addappid(2854570)
addappid(2854580)
addappid(4196620)
addappid(4196630)
addappid(4196640)
addappid(4196650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751311,0,"9e680af08a8345fdb5300f3eb28d13991dec5d63a5d73c5a0d0546fd24bba757")
addappid(2854570,0,"ab49c978e88c3464c93793fbaa47d0dfb445829052edb4a7e2eefef61e1eaa4b")
addappid(2854580,0,"6357cc7f86809b6f72a9489a80447287098df7f9eb10db798b3d268a1574ac93")

