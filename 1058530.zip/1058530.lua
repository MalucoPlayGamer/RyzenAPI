-- Lua provided by RyzenAPI
-- Game: H-Rescue

-- MAIN APPLICATION
addappid(1058530)
addappid(1221340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058531, 1, "e1242c838d1436b5f4d5d6f154642821469a0742e696c5dc0ae6df058050813a")

