-- Lua provided by RyzenAPI
-- Game: Poker Night 2

-- MAIN APPLICATION
addappid(234710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(234711, 1, "9ad519dab570d657bd85cf3ed5e4c76a6e8ec58c3b98a389f4e0f32e45e05d0b")
addappid(234712, 1, "17fec2573b771a3c9e485b965b30e173fc80a5886dfdd82fe8d20b7edd2bbc84")

