-- Lua provided by RyzenAPI 
-- Game: AppID 234710
addappid(234710)
addappid(234711, 1, "9ad519dab570d657bd85cf3ed5e4c76a6e8ec58c3b98a389f4e0f32e45e05d0b")
addappid(234712, 1, "17fec2573b771a3c9e485b965b30e173fc80a5886dfdd82fe8d20b7edd2bbc84")
