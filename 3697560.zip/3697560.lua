-- Lua provided by RyzenAPI
-- Game: Pizza Deathlivery

-- MAIN APPLICATION
addappid(3697560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3697561, 1, "28e16ddfef9d67bfb8b578b9f9b550db30f88545de88b7162f9b2f6d4867da57")
