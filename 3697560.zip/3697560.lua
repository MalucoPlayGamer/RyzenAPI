-- Lua provided by SkyAPI 
-- Game: Pizza Deathlivery
addappid(3697560)
addappid(3697561, 1, "28e16ddfef9d67bfb8b578b9f9b550db30f88545de88b7162f9b2f6d4867da57")
