-- Lua provided by RyzenAPI
-- Game: Lollipop Knight Rebaked

-- MAIN APPLICATION
addappid(1908660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908661, 1, "7fef9ef0ed2830997f55feb66a433827d6e1c41b29df2bab4d5186dd0b6efa10")
