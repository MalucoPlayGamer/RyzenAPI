-- Lua provided by RyzenAPI
-- Game: addappid(1012940)

-- MAIN APPLICATION
addappid(1012940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012941, 1, "2b05006466fcbdcb29a1dc1fb666579020b06aaa4dec5f807437ddfa13097581")
