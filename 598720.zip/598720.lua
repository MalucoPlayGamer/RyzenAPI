-- Lua provided by RyzenAPI
-- Game: A Country Of One

-- MAIN APPLICATION
addappid(598720)

-- MAIN APP DEPOTS / PACKAGES
addappid(598721,0,"79c8866db33033120b7c92bf4679cbcf046ef2e38a1e9f7d4ccad0fcb92ddafe")

