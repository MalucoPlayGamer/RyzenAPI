-- Lua provided by RyzenAPI
-- Game: addappid(3498550)

-- MAIN APPLICATION
addappid(3498550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3498551, 1, "db844c99f5e53cf7590ddb23f3bf2b643fda1770c2bdcddf7f258ebf9a0cd76a")
