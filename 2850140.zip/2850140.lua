-- Lua provided by RyzenAPI
-- Game: Rosetta Demo

-- MAIN APPLICATION
addappid(2850140)
-- Game: addappid(2850140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850141, 1, "34eab6c66163359c294814f62006e30e5a9264343d0937ff265798f887378920")
