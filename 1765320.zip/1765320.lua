-- Lua provided by RyzenAPI
-- Game: KTGAME

-- MAIN APPLICATION
addappid(1765320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1765321, 1, "6352914c1ce63f166fbc26bffa2c53bf78a14d4a198c620f9f4662578c95ddd7")

