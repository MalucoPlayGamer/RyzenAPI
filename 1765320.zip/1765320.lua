-- Lua provided by RyzenAPI 
-- Game: KTGAME
addappid(1765320)
addappid(1765321, 1, "6352914c1ce63f166fbc26bffa2c53bf78a14d4a198c620f9f4662578c95ddd7")
