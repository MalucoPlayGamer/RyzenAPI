-- Lua provided by RyzenAPI
-- Game: Anima: Gate of Memories - The Nameless Chronicles

-- MAIN APPLICATION
addappid(850060)

-- MAIN APP DEPOTS / PACKAGES
addappid(850062,0,"9e7bd81ee8c17085c2ccb5d38ee6ebe492545d64094fc9f8dcfc2bd9e4ef97f4")

