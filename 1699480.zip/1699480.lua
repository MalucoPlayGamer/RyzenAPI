-- Lua provided by RyzenAPI
-- Game: Game: KLETKA

-- MAIN APPLICATION
addappid(1699480)
-- Game: addappid(1699480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699481, 1, "c68d3843c14b9584d5c8707632ad7c1876efeb1528e0b97802b47663295ec466")
