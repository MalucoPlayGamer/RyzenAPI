-- Lua provided by RyzenAPI
-- Game: On Board 4 PC

-- MAIN APPLICATION
addappid(840180)
-- Game: addappid(840180)

-- MAIN APP DEPOTS / PACKAGES
addappid(840181, 1, "0f51095675b7f30c8bd3d99dbbcb1e2ca7143e1eafbf13d0513c1963d01d98ec")
