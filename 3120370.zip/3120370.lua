-- Lua provided by RyzenAPI
-- Game: Click on clocks together

-- MAIN APPLICATION
addappid(3120370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3120371, 1, "6558fc0c224fe00275c4b1f5a517164ecfdc461d3cc293727468a38d33c57400")

