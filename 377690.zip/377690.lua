-- Lua provided by RyzenAPI
-- Game: Game: Starlight Vega

-- MAIN APPLICATION
addappid(377690)
-- Game: addappid(377690)

-- MAIN APP DEPOTS / PACKAGES
addappid(377691, 1, "2a4a4c0304879c557bb36444d86a1dc667f4a87ce1de68c92085a7457340cade")
