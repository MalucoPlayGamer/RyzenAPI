-- Lua provided by RyzenAPI
-- Game: That Dragon, Cancer

-- MAIN APPLICATION
addappid(419460)
-- Game: addappid(419460)

-- MAIN APP DEPOTS / PACKAGES
addappid(419461, 1, "0e6ed9d3b72a5d7912d673c612f791654d3b736e92c3ad38bd4ff106efaf243b")
addappid(419462, 1, "91eae29f1a49a940ed0d220538bfa3d5bc5ebf6aa4d2a53d65a119ba7ea06e74")
addappid(419463, 1, "1f487c8c9e5322f9cf0b2b98fe13ae6383b0be1d2f5a9670dc694da134487b89")
addappid(419464, 1, "af3772646973882986f65bb68781f6df86f91f3c44abd0d9ec1c72447406c95a")
