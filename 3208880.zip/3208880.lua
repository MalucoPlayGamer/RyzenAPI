-- Lua provided by RyzenAPI
-- Game: Game: Aquilon's Sex Quest

-- MAIN APPLICATION
addappid(3208880)
-- Game: addappid(3208880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3208881, 1, "34dd01ace890a6f94ea75e377325d639a05a11a09ff8deff3a690ef1e5d96225")
