-- Lua provided by RyzenAPI
-- Game: Game: Bandit Playtest

-- MAIN APPLICATION
addappid(3823810)
-- Game: addappid(3823810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3823811, 1, "70f985c85f1a4cad6f4667ecd17d3a6fad61137fc7dd7b227e467b4410335ff6")
