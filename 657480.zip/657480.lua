-- Lua provided by RyzenAPI
-- Game: Dark Skies: The Nemansk Incident

-- MAIN APPLICATION
addappid(657480)

-- MAIN APP DEPOTS / PACKAGES
addappid(657481, 1, "dbd02f369894307ae83964df076882716296495f3959809ee4ea3919396e8b04")

