-- Lua provided by RyzenAPI
-- Game: Eye of death

-- MAIN APPLICATION
addappid(2750800)
-- Game: addappid(2750800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2750801, 1, "1e082e1e6bbdd3993457fb6d2a9c916bef7af46b0737cd931df77311cf2af7aa")
