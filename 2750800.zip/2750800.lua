-- Lua provided by RyzenAPI 
-- Game: Eye of death
addappid(2750800)
addappid(2750801, 1, "1e082e1e6bbdd3993457fb6d2a9c916bef7af46b0737cd931df77311cf2af7aa")
