-- Lua provided by RyzenAPI
-- Game: addappid(2351590)

-- MAIN APPLICATION
addappid(228990)
addappid(2351590)

