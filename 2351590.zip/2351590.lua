-- Lua provided by RyzenAPI
-- Game: ONE WAY HOME Demo

-- MAIN APPLICATION
addappid(228990)
addappid(2351590)

