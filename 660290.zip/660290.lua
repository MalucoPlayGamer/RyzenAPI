-- Lua provided by RyzenAPI
-- Game: Dungeons & Geese

-- MAIN APPLICATION
addappid(660290)
addappid(666370)

-- MAIN APP DEPOTS / PACKAGES
addappid(660291, 1, "ecdddc624b714a25fd8b557e1c547975a5bfa91b7b55bb8312e4d6422e5ed566")

