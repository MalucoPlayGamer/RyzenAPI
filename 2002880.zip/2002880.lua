-- Lua provided by RyzenAPI
-- Game: 2002880

-- MAIN APPLICATION
addappid(2002880)
addappid(2517660)
-- Game: addappid(2002880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002881, 1, "f492dfd5f7053776bf8fe86784666ac35da69fb8f2a7d543b4f5a4a065b78873")
