-- Lua provided by RyzenAPI
-- Game: Rhapsody III: Memories of Marl Kingdom

-- MAIN APPLICATION
addappid(2002880)
addappid(2517660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002881, 1, "f492dfd5f7053776bf8fe86784666ac35da69fb8f2a7d543b4f5a4a065b78873")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2547340)
