-- Lua provided by RyzenAPI
-- Game: Ravenswatch

-- MAIN APPLICATION
addappid(2071280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071281, 1, "708c675853989cbd400455e166d30f9dec051473847f4577ef48f7c9331edb97")
