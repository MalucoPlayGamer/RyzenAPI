-- Lua provided by RyzenAPI
-- Game: Ravenswatch

-- MAIN APPLICATION
addappid(2071280)
addappid(3113100)
addappid(3113110)
addappid(3113120)
addappid(3393430)
addappid(3607920)
addappid(3607930)
addappid(3607940)
addappid(3607950)
addappid(4406950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071281,0,"708c675853989cbd400455e166d30f9dec051473847f4577ef48f7c9331edb97")
addappid(3113130,0,"d599bff2a5cf7c111a24f0fdceff1571f319bd064f49239e640c15c6356b8fd7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
