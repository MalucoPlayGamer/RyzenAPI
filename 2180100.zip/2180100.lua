-- Lua provided by RyzenAPI
-- Game: Game: AppID 2180100

-- MAIN APPLICATION
addappid(2180100)
-- Game: addappid(2180100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180101, 1, "b3d890b258520e34c7483c6658634ebc2406dbdd52e86287aa289f305ac32365")
