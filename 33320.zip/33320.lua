-- Lua provided by SkyAPI 
-- Game: Prince of Persia: The Forgotten Sands™
addappid(33320)
addappid(33321, 1, "ce398c4390cf88380278389c8cf0354b7e63b1f268a78acdf79f293ed1098a5e")
addappid(33322, 1, "f3ba72f4a9067c90953dde471bb8b48547fe609799f35ac14b23fd6d6b067086")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
