-- Lua provided by RyzenAPI
-- Game: The Rough Guide to Sea of Thieves eBook

-- MAIN APPLICATION
addappid(2838640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838640,0,"68937ad2c3fcbdd9f020ab2a0bf862931c990fafd559f2fd67a362a76f4569ec")
