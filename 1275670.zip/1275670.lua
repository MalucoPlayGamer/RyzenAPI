-- Lua provided by RyzenAPI 
-- Game: Outcore: Desktop Adventure
addappid(1275670)
addappid(1275671, 1, "6e4c52d37803e8746c663ed29c6cc3327092874e8f92a62deacdf53ada8778f8")
