-- Lua provided by RyzenAPI
-- Game: Outcore

-- MAIN APPLICATION
addappid(2128470) -- Outcore Desktop Adventure The Amazing Super Duper Ultra Hyper Five Shekel Falafel Deluxe Extra Sugoi Mega Kawaii Gold Diamond Nirosta Plastic Directors Cut Special Edition Supporter Pack Plus PLUS
addappid(2133270) -- Outcore Clown Nose Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1275670, 1, "bdf71321cbc06d2a4de9a2960a2a24651c4bdd22526f51e03ff6247dc4a4f02f") -- Outcore
addappid(1275671, 1, "6e4c52d37803e8746c663ed29c6cc3327092874e8f92a62deacdf53ada8778f8") -- Depot 1275671
