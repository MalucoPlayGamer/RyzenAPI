-- Lua provided by RyzenAPI
-- Game: I AM BUTTER VR

-- MAIN APPLICATION
addappid(1849190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849193,0,"f252e32db386858498aa5729865ba3454895087d07ac46e462166481d968c2bc")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1981340)
