-- Lua provided by RyzenAPI
-- Game: AppID 1127900

-- MAIN APPLICATION
addappid(1127900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127901, 1, "e575bcd6d8b3176a459ea0387f58ae3a7237740071b70349e29b79332570d488")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1169320)
