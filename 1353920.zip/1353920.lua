-- Lua provided by RyzenAPI
-- Game: Game: High School Odyssey

-- MAIN APPLICATION
addappid(1353920)
-- Game: addappid(1353920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353921, 1, "09863d656c3ca80488ce04a23d76546aa53fbc88ee70257a890ec0a17d765cb8")
