-- Lua provided by RyzenAPI
-- Game: High School Odyssey

-- MAIN APPLICATION
addappid(1353920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1353921, 1, "09863d656c3ca80488ce04a23d76546aa53fbc88ee70257a890ec0a17d765cb8")

