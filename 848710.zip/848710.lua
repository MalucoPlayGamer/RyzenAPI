-- Lua provided by RyzenAPI
-- Game: Defendion

-- MAIN APPLICATION
addappid(848710)

-- MAIN APP DEPOTS / PACKAGES
addappid(848711,0,"8e437e95fae3852ebf213559298b69c00b50c7978bad1d9e19c716b70485783a")

