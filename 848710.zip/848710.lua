-- Lua provided by RyzenAPI
-- Game: Defendion

-- MAIN APPLICATION
addappid(848710)

-- MAIN APP DEPOTS / PACKAGES
addappid(848711,0,"8e437e95fae3852ebf213559298b69c00b50c7978bad1d9e19c716b70485783a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
