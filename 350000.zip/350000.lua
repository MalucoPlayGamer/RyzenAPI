-- Lua provided by RyzenAPI 
-- Game: AppID 350000
addappid(350000)
addappid(350001, 1, "882d65f176c1ec0a4bffa798437d0b6c8f2e6bf29cbc952ab107d707aa88bae9")
