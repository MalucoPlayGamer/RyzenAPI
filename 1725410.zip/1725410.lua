-- 1725410's Lua and Manifest Created by Hubcap Manifest
-- Talespinner
-- Created: August 06, 2026 at 23:45:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1725410) -- Talespinner
-- MAIN APP DEPOTS
addappid(1725411, 1, "917cf5c0dd8557bc39604546f698034bcc3bfe441361913e744111b989b799c9") -- Depot 1725411
setManifestid(1725411, "2551547130563786430", 543750695)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)