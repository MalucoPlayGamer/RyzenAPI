-- Lua provided by RyzenAPI
-- Game: 末代侠客

-- MAIN APPLICATION
addappid(1339260)
-- Game: addappid(1339260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339261, 1, "13f775c2341e92d332b808febef5ff61f81a73a323b3e1b873667e74bff91e81")
