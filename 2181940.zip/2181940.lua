-- Lua provided by RyzenAPI
-- Game: CivIdle

-- MAIN APPLICATION
addappid(2181940)
-- Game: addappid(2181940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181941, 1, "9e92101116da086f1ae243d5106e9a14e396d4939f7fb6478e24ce44fcf91cc6")
addappid(2181942, 1, "27dce31b28acfaa09f802887dda334ba1e219af107871d3f76c80e78ade80675")
