-- Lua provided by RyzenAPI
-- Game: CivIdle

-- MAIN APPLICATION
addappid(2181940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181941, 1, "9e92101116da086f1ae243d5106e9a14e396d4939f7fb6478e24ce44fcf91cc6")
addappid(2181942, 1, "27dce31b28acfaa09f802887dda334ba1e219af107871d3f76c80e78ade80675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2788080)
addappid(3399010)
addappid(4777130)
