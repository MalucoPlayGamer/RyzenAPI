-- Lua provided by RyzenAPI
-- Game: Garbage

-- MAIN APPLICATION
addappid(1253710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253711, 1, "22d686c77d42e908a9f1322181caf6efed0e819dd763f4fc601d8ba1033ebed9")
addappid(1253712, 1, "8aa27d9358b99bf9a68e579b2b050f209d28b67ab1dcebb66faf75e3c355a7c7")
