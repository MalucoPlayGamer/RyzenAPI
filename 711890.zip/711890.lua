-- Lua provided by RyzenAPI
-- Game: addappid(711890)

-- MAIN APPLICATION
addappid(711890)

-- MAIN APP DEPOTS / PACKAGES
addappid(711891, 1, "1d0b04097089e68d804a4ec3808b5e8fde40ad4ef0f91cf3cefbb058c685754e")
