-- Lua provided by RyzenAPI
-- Game: Game: AppID 1125760

-- MAIN APPLICATION
addappid(1125760)
addappid(1126530)
addappid(1126540)
-- Game: addappid(1125760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125761, 1, "063b1b306f6a713124686ef3ee9d1e626bd41dd45de2a480301e7a67ec83b36d")
