-- Lua provided by RyzenAPI
-- Game: California Games (C64/DOS/Atari/Lynx/NES/SMS/Genesis)

-- MAIN APPLICATION
addappid(1399480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399481, 1, "2c4b15794909d0bb8dbe6188fdc57a07091a3ef5bbd35fd750c77d8cffe9fb36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
