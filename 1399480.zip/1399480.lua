-- Lua provided by RyzenAPI
-- Game: addappid(1399480)

-- MAIN APPLICATION
addappid(1399480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399481, 1, "2c4b15794909d0bb8dbe6188fdc57a07091a3ef5bbd35fd750c77d8cffe9fb36")
