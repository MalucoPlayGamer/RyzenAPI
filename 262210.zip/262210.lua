-- Lua provided by RyzenAPI
-- Game: Last Knight: Rogue Rider Edition

-- MAIN APPLICATION
addappid(262210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(262211, 1, "8050f39bbec5df133b475b9f6eaa0c7c885553310d1edb3f95584e0c90b52599")
addappid(262221, 1, "1196a8c110a03ac82acf13395470ea4aaebf3f3f56f650431cc2b38041323f5e")

