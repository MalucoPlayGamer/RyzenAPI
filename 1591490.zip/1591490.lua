-- Lua provided by RyzenAPI
-- Game: Distant Memoraĵo

-- MAIN APPLICATION
addappid(1591490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591491, 1, "3c378b37395a5b19186965c2a10e44844f4a9fbaf268670f93db5c650378bae4")
