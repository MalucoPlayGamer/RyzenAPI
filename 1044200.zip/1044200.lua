-- Lua provided by RyzenAPI
-- Game: 1044200

-- MAIN APPLICATION
addappid(228986)
addappid(1044200)
addappid(1044201)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044202,0,"3b86075645d8a2f1d2a3de7dfe2c11e29ae7e25fa73efc7ca9d2c7536ad2c96f")
