-- Lua provided by RyzenAPI
-- Game: Tactical Three Kingdoms (T3K) - Strategy and War

-- MAIN APPLICATION
addappid(1166310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166311, 1, "d5abe3de398c874b14f069266633016bf4fb92bf623fd749e709a87d56341375")
