-- Lua provided by RyzenAPI
-- Game: Love of Dragons

-- MAIN APPLICATION
addappid(1636270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636271, 1, "8f076b9186d1c75131acb01094414f4fc6757949f903b2d2d1254ef3b29ce2b6")
