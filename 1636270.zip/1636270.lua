-- Lua provided by SkyAPI 
-- Game: Love of Dragons
addappid(1636270)
addappid(1636271, 1, "8f076b9186d1c75131acb01094414f4fc6757949f903b2d2d1254ef3b29ce2b6")
