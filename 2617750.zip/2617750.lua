-- Lua provided by RyzenAPI
-- Game: Mech Academy Demo

-- MAIN APPLICATION
addappid(2617750)
-- Game: addappid(2617750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617751, 1, "b76ab84eef652e12dc57c368a50d34f042ff0c26f6eadb6d681c975ade7c9d6c")
