-- Lua provided by RyzenAPI
-- Game: InfraSpace

-- MAIN APPLICATION
addappid(1511460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511461, 1, "b8ff14bde204344aa40d036eb187eb405e45fc8387ef3cbf28869c6cc3d1e475")
addappid(1511462, 1, "e4d355d76566116dff2fa228d13a27048bb05fe1c07b6ea019a64d61ce7cacff")

