-- Lua provided by SkyAPI 
-- Game: AppID 42750
addappid(42750)
addappid(42751, 1, "e4783770e4077079218b1a3a09582fb3be1e3e426322ae3df2b78c35343d3d9e")
