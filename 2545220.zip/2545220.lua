-- Lua provided by RyzenAPI
-- Game: addappid(2545220)

-- MAIN APPLICATION
addappid(2545220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545221, 1, "2866d00eebe1decf4aee05e78150b88d0c6c72b8457157f35865e1a844e100c4")
