-- Lua provided by RyzenAPI
-- Game: Ashen

-- MAIN APPLICATION
addappid(649950)

-- MAIN APP DEPOTS / PACKAGES
addappid(649951, 1, "139ea76d3b728f54d748d042fdf1f19c6be1604e445f39ade21123e633a5d22f")
addappid(1116060, 0, "7f903a89ca392c764dc671228577542fe5f12dc80e1d8dcc6b7fa2cdf1fb7f8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
