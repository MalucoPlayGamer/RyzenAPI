-- Lua provided by RyzenAPI
-- Game: Ashen

-- MAIN APPLICATION
addappid(649950)

-- MAIN APP DEPOTS / PACKAGES
addappid(649951, 1, "139ea76d3b728f54d748d042fdf1f19c6be1604e445f39ade21123e633a5d22f")
addappid(1116060, 0, "7f903a89ca392c764dc671228577542fe5f12dc80e1d8dcc6b7fa2cdf1fb7f8a")
