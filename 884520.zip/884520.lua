-- Lua provided by SkyAPI 
-- Game: AppID 884520
addappid(884520)
addappid(884521, 1, "b7673a9fd154ecfde20c1d111bd575bc60010e64db57b94395f3a50ff965a362")
