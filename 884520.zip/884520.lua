-- Lua provided by RyzenAPI
-- Game: Game: AppID 884520

-- MAIN APPLICATION
addappid(884520)
-- Game: addappid(884520)

-- MAIN APP DEPOTS / PACKAGES
addappid(884521, 1, "b7673a9fd154ecfde20c1d111bd575bc60010e64db57b94395f3a50ff965a362")
