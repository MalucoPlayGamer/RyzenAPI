-- Lua provided by RyzenAPI
-- Game: AppID 401280

-- MAIN APPLICATION
addappid(401280)
-- Game: addappid(401280)

-- MAIN APP DEPOTS / PACKAGES
addappid(401281, 1, "627e82bf98ccf7a20f724a6534493461f2c68ffafea22c2bff329aff965a4e27")
