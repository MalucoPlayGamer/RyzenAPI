-- Lua provided by RyzenAPI
-- Game: Game: Cybernetic Fault

-- MAIN APPLICATION
addappid(1409740)
-- Game: addappid(1409740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409741, 1, "08b41dab281f27feecb5d8d99bd15362520df84abd0fad0b462e782f307f52ce")
