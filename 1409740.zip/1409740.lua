-- Lua provided by SkyAPI 
-- Game: Cybernetic Fault
addappid(1409740)
addappid(1409741, 1, "08b41dab281f27feecb5d8d99bd15362520df84abd0fad0b462e782f307f52ce")
