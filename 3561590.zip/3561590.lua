-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Isekai Uncle Reversal

-- MAIN APPLICATION
addappid(3561590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561591, 1, "187aec4f10eb678d903b2e79d1434cc31fcb74fec485d6eebc919cd396090bf5")
