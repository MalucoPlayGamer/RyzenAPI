-- Lua provided by RyzenAPI
-- Game: addappid(2774120)

-- MAIN APPLICATION
addappid(2774120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774121, 1, "ef41f2068aa77f8f85ac087d47da228239c3c11d14f65be019c2470ca54850bc")
