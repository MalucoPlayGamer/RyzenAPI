-- Lua provided by RyzenAPI
-- Game: Vstar

-- MAIN APPLICATION
addappid(2774120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2774121, 1, "ef41f2068aa77f8f85ac087d47da228239c3c11d14f65be019c2470ca54850bc")

