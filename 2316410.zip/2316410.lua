-- Lua provided by RyzenAPI
-- Game: Game: Universe in Cum 💦 🌎

-- MAIN APPLICATION
addappid(2316410)
-- Game: addappid(2316410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316411, 1, "525c5536791d620412b06d77872c9652b7ce6cf6991ba3cab26456c3443d75ed")
