-- 4768660's Lua and Manifest Created by Hubcap Manifest
-- Slice To Meet You
-- Created: June 24, 2026 at 13:33:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4768660) -- Slice To Meet You
-- MAIN APP DEPOTS
addappid(4768661, 1, "e8023e857d8d58fdbbabc6737992cc1b99c6e1c2ada1ba2b1c87f8ee95f158c3") -- Depot 4768661
-- setManifestid(4768661, "7935331913603966470", 368196185)