-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 × NEKO WORKS: NEKOPARA - Coconut casual clothes & maid clothes set

-- MAIN APPLICATION
addappid(1913840)
-- Game: addappid(1913840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913841, 1, "cdbd50a02a6054288a0806d4fd360f90d781f652098353737bb82c37d465a80b")
addappid(1913842, 1, "ad92caac3695a6925417c767e14afd938247646f3374f261e31b48127a2012c1")
