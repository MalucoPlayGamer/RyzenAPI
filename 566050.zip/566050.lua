-- Lua provided by RyzenAPI
-- Game: Zeus + Poseidon

-- MAIN APPLICATION
addappid(566050)

-- MAIN APP DEPOTS / PACKAGES
addappid(566051, 1, "debf57c732641268b169bfbe2b75a878f7bebf523ff7034b6f629def6ed9a035")
