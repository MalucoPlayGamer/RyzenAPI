-- Lua provided by RyzenAPI
-- Game: Last Half of Darkness - Society of the Serpent Moon

-- MAIN APPLICATION
addappid(384910)

-- MAIN APP DEPOTS / PACKAGES
addappid(384911, 1, "454883ac8b24a138c73f0302ddc7bf54e74193f162f97c440060c103a3240fb4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
