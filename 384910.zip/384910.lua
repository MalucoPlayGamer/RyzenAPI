-- Lua provided by RyzenAPI
-- Game: Last Half of Darkness - Society of the Serpent Moon

-- MAIN APPLICATION
addappid(384910)
-- Game: addappid(384910)

-- MAIN APP DEPOTS / PACKAGES
addappid(384911, 1, "454883ac8b24a138c73f0302ddc7bf54e74193f162f97c440060c103a3240fb4")
