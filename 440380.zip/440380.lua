-- Lua provided by RyzenAPI
-- Game: Super Kitty Boing Boing

-- MAIN APPLICATION
addappid(440380)
-- Game: addappid(440380)

-- MAIN APP DEPOTS / PACKAGES
addappid(440381, 1, "0f3ca3934078cd632c9f0a865f507b7b87891330f1d05c2a80dceb2e585640c0")
