-- Lua provided by SkyAPI 
-- Game: Super Kitty Boing Boing
addappid(440380)
addappid(440381, 1, "0f3ca3934078cd632c9f0a865f507b7b87891330f1d05c2a80dceb2e585640c0")
