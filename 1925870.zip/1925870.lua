-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1925870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925870,0,"bc021fff1a452bce94df7196780509efd1dcc08b0e3bf9845324133fc4254804")

