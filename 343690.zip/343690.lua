-- Lua provided by RyzenAPI
-- Game: Game: AppID 343690

-- MAIN APPLICATION
addappid(343690)
-- Game: addappid(343690)

-- MAIN APP DEPOTS / PACKAGES
addappid(343691, 1, "d86f544f76c1af51b285bfa45ccdc0892d9154a81a2524f4fe0fa3a0815fabe8")
addappid(343692, 1, "ae2df48c6ad4047db17f812e6d9e4b6b58b3f7b8429c2cf514069908c779d111")
addappid(343693, 1, "1fa81f78dec732345070cfb1a0ab57e7173e667ee3db5246d3839761e1e73f8a")
addappid(343694, 1, "454e40cd4ad83dbdcda897b885887ac0c0d0a0bfdec484408f29a091d009d52a")
addappid(343695, 1, "2ccd5715bb169fec76d90763bed696f756e0e9f82cb9ce5cd140706032a59ed6")
