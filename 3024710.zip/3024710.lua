-- Lua provided by RyzenAPI
-- Game: Game: Black Submarine: deep seek

-- MAIN APPLICATION
addappid(3024710)
-- Game: addappid(3024710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3024711, 1, "5cf7a8574c4445a4d5b65f89fbdfae6357a21c0d23a27df5b3e489d2203521db")
