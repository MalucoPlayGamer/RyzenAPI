-- Lua provided by SkyAPI 
-- Game: Rugösi
addappid(905510)
addappid(905511, 1, "a9d4af8f45b88e0d0197f879a4e0b96304312fbcd60f237e6a7c62bfa9355332")
addappid(3960680)
