-- Lua provided by RyzenAPI
-- Game: Game: Rugösi

-- MAIN APPLICATION
addappid(905510)
addappid(3960680)
-- Game: addappid(905510)

-- MAIN APP DEPOTS / PACKAGES
addappid(905511, 1, "a9d4af8f45b88e0d0197f879a4e0b96304312fbcd60f237e6a7c62bfa9355332")
