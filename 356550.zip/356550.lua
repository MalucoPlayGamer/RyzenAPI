-- Lua provided by RyzenAPI
-- Game: Game: East Tower - Kuon (East Tower Series Vol. 3)

-- MAIN APPLICATION
addappid(356550)
-- Game: addappid(356550)

-- MAIN APP DEPOTS / PACKAGES
addappid(356551, 1, "bccc606e729cdec88d931c42b6ac8be3476b5c6fa44c0d1d13228153a0f15f70")
addappid(356552, 1, "a6fa59b19939e38cd3518533d28db3989e30689a6a47f097343c832d0d68a240")
addappid(356553, 1, "6bb78aaa960733fc9250f393b1aa477510795c150575242e8307985c840a6334")
addappid(356554, 1, "ebf23e9cb409bc8e484bdd517a40b7ec11dadc90e9ec05c4e2195959208abad0")
addappid(356555, 1, "0c229797eaa341628e551534ab930ef42cdda3ab6dad5f5d8552201109429b3c")
addappid(356556, 1, "5e05c899e7adecdef8189b29f62ed02df0723a4eb9cde2cce500d78c281bb3d6")
