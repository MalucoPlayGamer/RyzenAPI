-- Lua provided by RyzenAPI
-- Game: Game: Kaiju Princess 2 Artbook

-- MAIN APPLICATION
addappid(3350770)
-- Game: addappid(3350770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3350771, 1, "6a742ed9433fdae3a6672cad8164d006a18603cf0e55d63109d7704000df7ede")
