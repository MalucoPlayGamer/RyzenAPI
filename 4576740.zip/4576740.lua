-- 4576740's Lua and Manifest Created by Hubcap Manifest
-- Black Flower
-- Created: August 17, 2026 at 09:19:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4576740) -- Black Flower
-- MAIN APP DEPOTS
addappid(4576742, 1, "7f112f48f0456b4ebd4a84e9158ee12bcd762758c013f275929dd4c96e007bfc") -- Depot 4576742
setManifestid(4576742, "6808772580372447457", 448759643)
addappid(4576743, 1, "5929c04e69d5399c12e1751782fc7e122ce51ce9083a74f12b23bb8a963c2522") -- Depot 4576743
setManifestid(4576743, "2899974719610320598", 464945348)
addappid(4576744, 1, "b3817492aaca61b9c17aeb1ce924accd1878dc4fe71ed70b80fbf1f8b90eefc5") -- Depot 4576744
setManifestid(4576744, "8919669101715774654", 445053238)