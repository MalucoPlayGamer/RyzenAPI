-- Lua provided by RyzenAPI
-- Game: addappid(743450)

-- MAIN APPLICATION
addappid(743450)

-- MAIN APP DEPOTS / PACKAGES
addappid(743451, 1, "349c7a16dcf1466589140fccce5be20986fea759a6ec3dc60ee251b84734863a")
addappid(743452, 1, "c6f76ef16da8a4ff8a131f9145edd0aaf4064bae85c5b720efeb5ba75df7af01")
addappid(743453, 1, "3bd800ce7f4db8838c7ef2a162a32f848f25be3aed641d18fe9dfefa9d38f789")
addappid(958370, 0, "7d7ffe0b9192c982a1bfbbd2b8c320d7e386f21bfc7d683cbae23e9ff2f28297")
