-- Lua provided by RyzenAPI
-- Game: Detective Hayseed - Hollywood

-- MAIN APPLICATION
addappid(504380)

-- MAIN APP DEPOTS / PACKAGES
addappid(504381, 1, "3331eeccbd4b4706413ef305c4a565f477b8ed09a6c74b1126c26d88557eafaa")

