-- Lua provided by RyzenAPI
-- Game: Sid Meier's Civilization IV: Colonization

-- MAIN APPLICATION
addappid(16810)

-- MAIN APP DEPOTS / PACKAGES
addappid(16811, 1, "ea311a036a2e4ca8eceb8e8778eb730f9b24ab744db729683fc3840178d60dfd")
addappid(16812, 1, "deba2bf70e820bf1225cb2c31820245b8a0e106a452605af4e8b4f3f7685dbd4")
addappid(16813, 1, "a978ccd2728487636bc4ece2380d11e8a797f4d4534d823626068974b4899fed")
addappid(16814, 1, "5feb1fd92ce940a7c9266e0a8cc3f7e8d315220f87f66c41959eacc45d0972d3")
addappid(16815, 1, "ac02a2e0237eb1b02106b1d4344f1697b46614d8d99a89cf20ec748f547a9e8d")
addappid(16816, 1, "bccce273554bbdcddf844d385cf45a0a4a1f98bdfbbbcadeb9a542073b8169b1")
addappid(34471, 0, "916deb73a865e862f519c88638a3adb6279dc28541b6f7251301917ceaf312ed")
