-- Lua provided by RyzenAPI
-- Game: 1953 - KGB Unleashed

-- MAIN APPLICATION
addappid(248490)

-- MAIN APP DEPOTS / PACKAGES
addappid(248491, 1, "a9fee1239d8711972e660e67b5cce086289038d9317975f6581dea2443cf633a")
addappid(248492, 1, "fb6e7f2f06a36f2e3233dc064284a1be430f3bf4165e75d6e2f54cbcb50e9c6b")
addappid(248493, 1, "3089930b9bd8512507e33cc60dea99087ae0aa02ea777dcb3625d6dba4be6a5c")
addappid(248494, 1, "f021e3197963e473b3cea9c184d9c6615cb17231c82d00d76cb48052539680bd")
addappid(248495, 1, "c6c34568d8a5032b06ff7193ad09271958aa6a2a61417de6d049b7e5e92a90eb")
addappid(248496, 1, "92af5677a14743c2848457546ccb35fb7ef5f2f742afb105e200df61495af4cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
