-- Lua provided by SkyAPI 
-- Game: AppID 497770
addappid(497770)
addappid(497771, 1, "dc26bcdf22c1168ce13e2a218a31f11df671477404eac1ddb5fc381730400114")
