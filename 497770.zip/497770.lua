-- Lua provided by RyzenAPI
-- Game: AppID 497770

-- MAIN APPLICATION
addappid(497770)
-- Game: addappid(497770)

-- MAIN APP DEPOTS / PACKAGES
addappid(497771, 1, "dc26bcdf22c1168ce13e2a218a31f11df671477404eac1ddb5fc381730400114")
