-- Lua provided by RyzenAPI
-- Game: Game: AppID 2617230

-- MAIN APPLICATION
addappid(2617230)
-- Game: addappid(2617230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617231, 1, "4ce1e186da594a4f7b13a5075436e4e5858b414b4de154c5a804ce45848b37b7")
