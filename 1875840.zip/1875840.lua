-- Lua provided by RyzenAPI
-- Game: Illusion OST

-- MAIN APPLICATION
addappid(1875840)
-- Game: addappid(1875840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875841, 1, "f965ef4e5d53b287565b3a30075c8745fd64379c8457081f6ef32712c1e1c414")
