-- Lua provided by RyzenAPI
-- Game: 1227453

-- MAIN APPLICATION
addappid(1227453)
-- Game: addappid(1227453)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227453,0,"eb86e28d4fe9a6d574761b1e70b45fd6794059da2e51b4e7cb1778ca690068a1")
addappid(1790010,0,"f7b98c8d971d771ab05330a3b4b4fc8d58229f3bae9c0dd7bf7104f5ebdb63a2")
