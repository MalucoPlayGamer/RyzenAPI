-- Lua provided by RyzenAPI
-- Game: Mecha Blade

-- MAIN APPLICATION
addappid(2254310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254311, 1, "90b13028483fc42c0aeee55580578303b93a1d9d3a1a59c0b855d22e67b64825")

