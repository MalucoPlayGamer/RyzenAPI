-- Lua provided by RyzenAPI
-- Game: Orcs Must Die! 2

-- MAIN APPLICATION
addappid(201790)

-- MAIN APP DEPOTS / PACKAGES
addappid(201791, 1, "07e18a6715cee99f3c872f9fc3f7484243f7bf6c8dcbf57bebd21c3ed7e8e08a")
addappid(201792, 1, "24b955c5a69bda6840283d4d6d351aa49bf7d716e87a5f0dcfa6bac01207b0ae")
addappid(201793, 1, "2dbba655bfdae3cc7f4ade5c6a05fbccbc6be75c54ded871ff40a129c7cbb1a5")
addappid(201794, 1, "d63a503d0718bfaae34966038de70ee777822db3537fa62ea65baab03582e022")
addappid(201795, 1, "f9d8bf9eac7799bfb412c9c502ceee042791ddc7a70d921cef956f3b2d21ca21")
addappid(201796, 1, "9684df6aa535c2331227192c48e0a6f55425cc25ce27ceb3db05413be403d139")
addappid(201797, 1, "15173dfa7da1a0c7ea1481240e2fb239358dc1d06b77113ec33ae537b211a122")
addappid(201798, 1, "1e6d89c3a008814d5025dd913efda457f5bfd217471418abdb4f813a655252e0")
addappid(201799, 1, "2dd2125a2c1502fbeecfe7edda8f9066bbd5bef43564c9505cfbc04939b04298")
addappid(201800, 1, "1e47ab0b8d6b65f8faed3a4dbebdad520da658bfab79801f6502334a2f3094e9")
addappid(201801, 1, "6562837df47f63927d5ed52c4dd96d44910f51c13169108627e765dff17fb785")
addappid(201802, 1, "27593169f85653c5c64d7b65bc9ff24d6a52de7d444bc723bab47543f3aeff09")
addappid(201804, 1, "9de3ecfafa96d7397039099c0ee0e7571d26b8a472a2a6d22850cc9bbcad8673")
addappid(201805, 1, "f3df57843e40b1f8222a3bba1186d64b6bf88bc90edeee4eface36307cf5d137")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(201803)
addappid(201806)
addappid(201807)
addappid(201808)
