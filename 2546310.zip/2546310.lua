-- Lua provided by RyzenAPI
-- Game: 2546310

-- MAIN APPLICATION
addappid(2546310)
-- Game: addappid(2546310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546311, 1, "68cbb1f7b0b3014f7efaf528a1ed5f9cfca34070ae013bd90db547d5bd4e4d80")
