-- Lua provided by RyzenAPI 
-- Game: malViolence - Definitive Edition
addappid(2403570)
addappid(2403571, 1, "17575f1303249101fe0320ffddd75b5c36e6598d99bd5cdc89b63634dc9385d8")
