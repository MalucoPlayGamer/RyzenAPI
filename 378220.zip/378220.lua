-- Lua provided by RyzenAPI
-- Game: Football Manager 2016 Resource Archiver

-- MAIN APPLICATION
addappid(378220)

-- MAIN APP DEPOTS / PACKAGES
addappid(378221, 1, "844d09ac2d720a1478fc48c8a977acab03ab8f5d63e0557f282f673e57ce0dd4")

