-- Lua provided by SkyAPI 
-- Game: AppID 378220
addappid(378220)
addappid(378221, 1, "844d09ac2d720a1478fc48c8a977acab03ab8f5d63e0557f282f673e57ce0dd4")
