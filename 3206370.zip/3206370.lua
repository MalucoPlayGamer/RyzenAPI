-- Lua provided by RyzenAPI
-- Game: Island Treasure Chase

-- MAIN APPLICATION
addappid(3206370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206371, 1, "5de79dce5510594867faf9bd7d2aab7f0c255899bd2fb216d1a51a1c652c8620")

