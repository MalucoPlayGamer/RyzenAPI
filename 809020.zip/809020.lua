-- Lua provided by RyzenAPI
-- Game: AppID 809020

-- MAIN APPLICATION
addappid(809020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(809021, 1, "ee33b397c22eb9fe906658dec6bb09c9abb8e85f3cbd562cd585db56fc96a0d0")

