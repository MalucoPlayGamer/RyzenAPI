-- Lua provided by RyzenAPI
-- Game: Game: AppID 809020

-- MAIN APPLICATION
addappid(809020)
-- Game: addappid(809020)

-- MAIN APP DEPOTS / PACKAGES
addappid(809021, 1, "ee33b397c22eb9fe906658dec6bb09c9abb8e85f3cbd562cd585db56fc96a0d0")
