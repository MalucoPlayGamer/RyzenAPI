-- Lua provided by RyzenAPI
-- Game: 滴るあの娘 ～Drenched Girls～

-- MAIN APPLICATION
addappid(2614220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614221, 1, "4496b50ae01e5ab5a092e7773c8a097fbaf011b25c22a10d347dbae7b3576c2a")
