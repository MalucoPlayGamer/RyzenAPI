-- Lua provided by RyzenAPI
-- Game: Game: The Masked Mage

-- MAIN APPLICATION
addappid(953750)
-- Game: addappid(953750)

-- MAIN APP DEPOTS / PACKAGES
addappid(953751, 1, "2300d95adbcb33495f104d62b985987175693c7656ccd69f051a3dc17df91e78")
