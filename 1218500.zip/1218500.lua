-- Lua provided by RyzenAPI
-- Game: Galactic Mining Corp

-- MAIN APPLICATION
addappid(1218500)
-- Game: addappid(1218500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218501, 1, "9fd830972653a6c63415f1e45a7c4a5c644b3aa288d561ebce1ca744df0facfd")
