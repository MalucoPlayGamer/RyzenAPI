-- Lua provided by RyzenAPI
-- Game: Nunholy

-- MAIN APPLICATION
addappid(2854740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854741, 1, "0e7a850b48b129deb2aaad37ecfe891a75e20b415134fcefefd010fff8c8936a")

