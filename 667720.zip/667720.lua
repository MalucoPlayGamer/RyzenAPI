-- Lua provided by RyzenAPI
-- Game: addappid(667720)

-- MAIN APPLICATION
addappid(667720)

-- MAIN APP DEPOTS / PACKAGES
addappid(667721, 1, "7d664ec0727ba7449d61d7c972d30e1d4eaba976dc62a458a596fa60576836ab")
addappid(667722, 1, "90f4b9ced49ecd987ebc786d93782d89be38b0d4f322dd6746d11733c3eed893")
