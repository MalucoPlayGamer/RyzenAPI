-- Lua provided by RyzenAPI
-- Game: Red Faction Guerrilla Re-Mars-tered

-- MAIN APPLICATION
addappid(667720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(667721, 1, "7d664ec0727ba7449d61d7c972d30e1d4eaba976dc62a458a596fa60576836ab")
addappid(667722, 1, "90f4b9ced49ecd987ebc786d93782d89be38b0d4f322dd6746d11733c3eed893")

