-- Lua provided by RyzenAPI
-- Game: Gal Mothers and Daughters who love sex

-- MAIN APPLICATION
addappid(2911660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911661, 1, "65a752c07334bc5fb3069ba91d60de5045b56991d1eac27ee23dc41e32e56c38")
addappid(2958040, 0, "0035d32094a0d874b2c0d3d9b77ad34815c734466a29ed9f1722707b208bbc47")
