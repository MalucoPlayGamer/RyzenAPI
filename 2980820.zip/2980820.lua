-- Lua provided by SkyAPI 
-- Game: Escape Zombie Maze Demo
addappid(2980820)
addappid(2980821, 1, "df88970c6043893e294a11286965a985080683eda6ba14bae8b97d7f7c7e9d7b")
