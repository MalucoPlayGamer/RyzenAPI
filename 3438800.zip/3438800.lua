-- Lua provided by RyzenAPI 
-- Game: Doodle Empires
addappid(3438800)
addappid(3438801, 1, "d7c3577cfbad3d5beb7a8dc46c1305693679a43e287b97f73599ea233100113b")
