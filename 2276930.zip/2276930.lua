-- Lua provided by RyzenAPI
-- Game: 2276930

-- MAIN APPLICATION
addappid(2276930)
-- Game: addappid(2276930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276931, 1, "fcf9662feff7e3607308854557baac65fd6d346455c261c4e38942e597c48b93")
addappid(2276932, 1, "f79b4b156ec43b6dbe920d70058fd28f9d0637a540db8f1c18518fbbcd1fadfe")
