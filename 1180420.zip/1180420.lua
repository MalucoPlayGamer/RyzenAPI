-- Lua provided by RyzenAPI
-- Game: Game: AppID 1180420

-- MAIN APPLICATION
addappid(1180420)
-- Game: addappid(1180420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180421, 1, "eb898618ba1a67a51ea2f2be791443992ada3f364badbaf9d43482ea16e6af49")
