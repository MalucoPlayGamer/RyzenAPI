-- Lua provided by RyzenAPI
-- Game: Game: AppID 402980

-- MAIN APPLICATION
addappid(402980)
-- Game: addappid(402980)

-- MAIN APP DEPOTS / PACKAGES
addappid(402981, 1, "8d7926fca88a3de8f2a7bb95fa50c2dba94da0542923a7ca673c9e014b49781b")
addappid(402982, 1, "ef372cc96885f0851eb001cb1d32dcd66157c61b728597336f9d5a92821fb23e")
addappid(402983, 1, "f9704743f5b627befb545cf5bcfc385290d0cf093253acbcc62dfcf483a7c768")
addappid(402984, 1, "83cf55af7e875401610bcb6be0919e0f3e2a11c6d84267d4b71d9f7b9abc0a07")
