-- Lua provided by RyzenAPI
-- Game: Vectromirror 0™

-- MAIN APPLICATION
addappid(1296560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1296561, 1, "06203267f90c0b575bbcc270056d8a8711627068d0241a6e1eda7a8609b90bda")

