-- Lua provided by RyzenAPI
-- Game: Vectromirror 0™

-- MAIN APPLICATION
addappid(1296560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296561, 1, "06203267f90c0b575bbcc270056d8a8711627068d0241a6e1eda7a8609b90bda")

