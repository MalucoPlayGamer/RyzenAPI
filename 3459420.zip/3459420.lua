-- Lua provided by RyzenAPI
-- Game: addappid(3459420)

-- MAIN APPLICATION
addappid(3459420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3459421, 1, "37b5faa64efca4669d28ed2fc4f28325c608e0692b4b57fd7753e936452cc1c0")
