-- Lua provided by RyzenAPI
-- Game: 2276350

-- MAIN APPLICATION
addappid(2276350)
-- Game: addappid(2276350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276352,0,"9a67aeff48263502ac0f6b7970b0ac72f8df28ece67428c71c17011e4a9f974d")
