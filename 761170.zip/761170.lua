-- Lua provided by RyzenAPI
-- Game: Radical Dungeon Sweeper

-- MAIN APPLICATION
addappid(761170)

-- MAIN APP DEPOTS / PACKAGES
addappid(761171, 1, "58c55043dd591c8a61fe0fbd08d3c1476308fc70cf6887e46f14b23a3df8e642")

