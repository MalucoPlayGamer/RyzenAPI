-- Lua provided by RyzenAPI
-- Game: Grey Bones

-- MAIN APPLICATION
addappid(1559960)
-- Game: addappid(1559960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559961, 1, "fea2eff3d2ecb4debf0c1ff315c1c30eccefc6f328c8e1e0178b1e83425cceb8")
