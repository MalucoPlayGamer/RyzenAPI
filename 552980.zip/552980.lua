-- Lua provided by RyzenAPI
-- Game: AppID 552980

-- MAIN APPLICATION
addappid(552980)

-- MAIN APP DEPOTS / PACKAGES
addappid(552981, 1, "5116ee24eee2e075b1255a0c0b01794decc364633e1eca497bed8da6a9546f3a")
