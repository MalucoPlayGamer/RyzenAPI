-- Lua provided by RyzenAPI
-- Game: AppID 756490

-- MAIN APPLICATION
addappid(756490)

-- MAIN APP DEPOTS / PACKAGES
addappid(756491, 1, "c68df4c96fbe8617ed4187a5a973cd6fcaceae8896e9018936ba9c629729d4bb")

