-- Lua provided by RyzenAPI
-- Game: addappid(258220)

-- MAIN APPLICATION
addappid(258220)

-- MAIN APP DEPOTS / PACKAGES
addappid(258221, 1, "7d4aff0acebfc71e9602807238111c3f82547b5aef7418ecf7e18e9244801273")
addappid(258222, 1, "fe779ebf1e75b3fe8a0c3108dff4f1d9efdc8b711fc715d3deee4944a745c92e")
addappid(258223, 1, "695a2e58a1f0f78c61d6af21b90b9ca28e0eef3bf6829b48c42e7cba36deb73a")
addappid(258224, 1, "eb8e4e620f55caf96965bfa165418f58feaa9bca69d65a424a9175be62221c05")
addappid(258225, 1, "a30d8e60468b3e75dccd3f6f23273044fcb8f884bd38597b224fde5b8edff33a")
addappid(258226, 1, "f67b213bcb658b5ae41fb9e9bbaa5582f374d1d51fec9a76a2c2556cf10ed1fb")
