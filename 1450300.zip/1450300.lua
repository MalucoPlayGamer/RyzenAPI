-- Lua provided by RyzenAPI
-- Game: Battleships: Command of the Sea

-- MAIN APPLICATION
addappid(1450300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450301, 1, "3c2cbc1960be226322e76d8d01bff2901adcf111b9e438402de1ba9eba1634ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
