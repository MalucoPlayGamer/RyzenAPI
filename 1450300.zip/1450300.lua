-- Lua provided by RyzenAPI
-- Game: Game: Battleships: Command of the Sea

-- MAIN APPLICATION
addappid(1450300)
-- Game: addappid(1450300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450301, 1, "3c2cbc1960be226322e76d8d01bff2901adcf111b9e438402de1ba9eba1634ac")
