-- Lua provided by SkyAPI 
-- Game: Gold Rush! Anniversary
addappid(319230)
addappid(319231, 1, "e328c07612d585d9b68c2d7398864b78cfd0a57a37e3eac6c9634ae60fce485f")
addappid(319232, 1, "c00a3a4f7ce5977ff0b34c85771b46a5a04d0b1ab64aabc5a139b7a3e2f5f57c")
addappid(319233, 1, "454a8eec20a23e43499599e1c3a5b5464f66bc8245b403238ed5a78e746a29fe")
addappid(319234, 1, "07147bf7e43ff998d96f02a98365e51e8ecacbdc69000925d5f3287f79ba88b6")
addappid(328690)
