-- Lua provided by RyzenAPI
-- Game: UnderParty

-- MAIN APPLICATION
addappid(1144440)
-- Game: addappid(1144440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144441, 1, "7b12d649630ee7d2c2aa0e58c720f8a4404b1c6b9b60d3a964d732b22fc85377")
