-- Lua provided by RyzenAPI
-- Game: Killing Floor 3

-- MAIN APPLICATION
addappid(1430190)
addappid(2843460)
addappid(2843470)
addappid(3271050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430191, 1, "11bafea87b92cd63bda029f9db46b362caffe0be7a4617072ee4a6ed83bbb7fe")

