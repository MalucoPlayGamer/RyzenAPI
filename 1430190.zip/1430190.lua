-- Lua provided by RyzenAPI
-- Game: Killing Floor 3

-- MAIN APPLICATION
addappid(1430190)
addappid(2843460)
addappid(2843470)
addappid(3271050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430191, 1, "11bafea87b92cd63bda029f9db46b362caffe0be7a4617072ee4a6ed83bbb7fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
