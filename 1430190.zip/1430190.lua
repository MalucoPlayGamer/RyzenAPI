-- Lua provided by SkyAPI 
-- Game: Killing Floor 3
addappid(1430190)
addappid(1430191, 1, "11bafea87b92cd63bda029f9db46b362caffe0be7a4617072ee4a6ed83bbb7fe")
addappid(2843460)
addappid(2843470)
addappid(3271050)
