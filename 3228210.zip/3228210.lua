-- Lua provided by RyzenAPI
-- Game: Meow Moments: Comic Cat Con

-- MAIN APPLICATION
addappid(3228210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228211, 1, "dee3cf270fe84eeb35a2fcb39f527bd58dec8203f83583daa7baad4d84aed966")
