-- Lua provided by RyzenAPI
-- Game: 2791240

-- MAIN APPLICATION
addappid(2791240)
-- Game: addappid(2791240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791241, 1, "7a831fdc71d7f10d4defb416ddb3dfdaf24dbeccdb09b0b21c7b89fecbc35b43")
