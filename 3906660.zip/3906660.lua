-- Lua provided by RyzenAPI
-- Game: Sacred 2 Remaster

-- MAIN APPLICATION
addappid(3906660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3906661,0,"a651552e85e2ba4a6f071d51a9260c165ef3ce2a4b80e4175a911af797e79391")

