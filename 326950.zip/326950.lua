-- Lua provided by RyzenAPI
-- Game: Game: Sword of Asumi

-- MAIN APPLICATION
addappid(326950)
-- Game: addappid(326950)

-- MAIN APP DEPOTS / PACKAGES
addappid(326951, 1, "23c6474b42ff0653934f860d387d63eba70ef7f18e7aa5709550f3cd676277f7")
addappid(331490, 0, "84dc9036be59cb7637a8b59ca567a0705122b08b1c8ed179cfb4c533438596db")
addappid(331491, 0, "2fd1030f1136527097421cb3c352918cabdf2cdcdef95b73f0163f99aae57c6b")
addappid(331492, 0, "1695ffdde1a2c2d0591089fbfc055343de7a62bb0f202c32d672d54bb665159f")
