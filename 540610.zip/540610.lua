-- Lua provided by RyzenAPI
-- Game: Delicious! Pretty Girls Mahjong Solitaire

-- MAIN APPLICATION
addappid(540610)

-- MAIN APP DEPOTS / PACKAGES
addappid(540611, 1, "c84179569643756f1c54b2041e1be516c6bf429b2f2af587df4f8e12e1eed29a")
addappid(540612, 1, "6cd10fff7c983ee23a8628debd615f38613d5f22c467131e4a61ec010b25599c")
