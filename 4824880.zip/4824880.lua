-- Lua provided by RyzenAPI
-- Game: Design Studio Simulator: Print Your Empire

-- MAIN APPLICATION
addappid(4824880) -- Design Studio Simulator: Print Your Empire

-- MAIN APP DEPOTS / PACKAGES
addappid(4824881, 1, "6cda9763c58a83d7a2674c9fe4790b0c2318740206771b3ae718adf0349d545a") -- Depot 4824881

