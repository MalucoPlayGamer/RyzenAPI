-- 4824880's Lua and Manifest Created by Hubcap Manifest
-- Design Studio Simulator: Print Your Empire
-- Created: August 22, 2026 at 00:25:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4824880) -- Design Studio Simulator: Print Your Empire
-- MAIN APP DEPOTS
addappid(4824881, 1, "6cda9763c58a83d7a2674c9fe4790b0c2318740206771b3ae718adf0349d545a") -- Depot 4824881
setManifestid(4824881, "6558392449624079684", 1030424291)