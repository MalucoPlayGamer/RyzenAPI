-- Lua provided by RyzenAPI
-- Game: Murderous Pursuits

-- MAIN APPLICATION
addappid(638070)
-- Game: addappid(638070)

-- MAIN APP DEPOTS / PACKAGES
addappid(638071, 1, "a7ceadf6703cb7ca56fad74f7eea0fe3c48acb00d67acae55837aefa1ef583ac")
addappid(820010, 0, "8ced74fd88d8ee5643d92f0c7328966c9f9438cbd3e378f8d7d234db147d64f1")
addappid(938610, 0, "463869f4647134d767715f966c4bb8631cf7ff4e1fdfa36632bfa5eecc7ea92d")
