-- Lua provided by RyzenAPI
-- Game: Kandagawa Jet Girls

-- MAIN APPLICATION
addappid(1233800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233801, 1, "884e87a02f51f4ce9d6c6bdbbb7148a3cd8f812750ce3b3ac57c76743a34bb05")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1280120)
addappid(1280121)
addappid(1280123)
addappid(1280124)
addappid(1280125)
addappid(1280126)
addappid(1280127)
addappid(1280128)
addappid(1280129)
addappid(1364521)
