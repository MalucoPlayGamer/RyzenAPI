-- Lua provided by RyzenAPI
-- Game: Kandagawa Jet Girls

-- MAIN APPLICATION
addappid(1233800)
-- Game: addappid(1233800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233801, 1, "884e87a02f51f4ce9d6c6bdbbb7148a3cd8f812750ce3b3ac57c76743a34bb05")
