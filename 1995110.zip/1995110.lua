-- Lua provided by RyzenAPI
-- Game: 1995110

-- MAIN APPLICATION
addappid(1995110)
-- Game: addappid(1995110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995111, 1, "6b1ce13bcb5347b0e81962dee8e07c9980a542e679a8b5f5e5cf7c5afa4a2076")
