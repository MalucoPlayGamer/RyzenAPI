-- Lua provided by RyzenAPI 
-- Game: Pixel Pileup Party
addappid(1243040)
addappid(1243041, 1, "9dae25e302d359bfc917eef7a27abfc124299cac9e554290f4954db16f503535")
