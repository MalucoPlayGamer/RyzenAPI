-- Lua provided by RyzenAPI
-- Game: Pixel Pileup Party

-- MAIN APPLICATION
addappid(1243040)
-- Game: addappid(1243040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243041, 1, "9dae25e302d359bfc917eef7a27abfc124299cac9e554290f4954db16f503535")
