-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 4

-- MAIN APPLICATION
addappid(1621680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621681, 1, "704ae1f6299bed04f2ed05c67b89aef5d68d76ab41ac40d6bb5a0f9f8f0eec9b")

