-- Lua provided by RyzenAPI
-- Game: 爱上火车-Pure Station- 原声音乐歌曲集（5CD）

-- MAIN APPLICATION
addappid(978070)

-- MAIN APP DEPOTS / PACKAGES
addappid(978070,0,"eeaf229a30f3683fdbae2d3fc5489cdea41d3a2e875d8367a4184c2692a78d89")
