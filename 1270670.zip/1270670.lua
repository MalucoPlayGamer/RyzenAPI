-- Lua provided by RyzenAPI
-- Game: Touhou Double Focus

-- MAIN APPLICATION
addappid(1270670)
addappid(1379780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270671, 1, "bb1ef854af65110f867b6f0102f845fc2504c5770481339232e768c669e28dda")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
