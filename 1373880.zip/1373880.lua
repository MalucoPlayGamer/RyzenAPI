-- Lua provided by RyzenAPI
-- Game: Hello Neighbor 2 Alpha 1

-- MAIN APPLICATION
addappid(1373880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1373881, 1, "347cd235e921626e36b3aa7cc46bbf987d31329c05875307e7ddbdc2c162e128")

