-- Lua provided by RyzenAPI
-- Game: addappid(1373880)

-- MAIN APPLICATION
addappid(1373880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373881, 1, "347cd235e921626e36b3aa7cc46bbf987d31329c05875307e7ddbdc2c162e128")
