-- Lua provided by SkyAPI 
-- Game: Hello Neighbor 2 Alpha 1
addappid(1373880)
addappid(1373881, 1, "347cd235e921626e36b3aa7cc46bbf987d31329c05875307e7ddbdc2c162e128")
