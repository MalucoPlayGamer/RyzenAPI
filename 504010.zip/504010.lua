-- Lua provided by RyzenAPI
-- Game: AppID 504010

-- MAIN APPLICATION
addappid(504010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(504011, 1, "2f2e0a68b65f049c47059eed61328d9153d0c357498d1acebc74545791c2f611")
addappid(504013, 1, "02740426612597cfa2ad68ff9e7cada0e4237005ef147cfe46020813d56f84d7")

