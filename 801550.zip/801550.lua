-- Lua provided by SkyAPI 
-- Game: VAIL
addappid(801550)
addappid(801551, 1, "728061a23095cca7547013f02f30eb273a145d3f9c601be56f719c439c127ab5")
