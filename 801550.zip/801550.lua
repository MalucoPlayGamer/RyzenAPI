-- Lua provided by RyzenAPI
-- Game: VAIL

-- MAIN APPLICATION
addappid(801550)
addappid(2222440)
addappid(2260410)
addappid(2880720)
addappid(3289320)
addappid(3730470)
addappid(3730480)
addappid(3730490)
addappid(3922740)
addappid(3992960)
addappid(4143950)
addappid(4182980)
addappid(4182990)
addappid(4558140)
addappid(4642170)
addappid(4756810)
addappid(4784370)
addappid(4892880)
addappid(5038250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(801551, 1, "728061a23095cca7547013f02f30eb273a145d3f9c601be56f719c439c127ab5")

