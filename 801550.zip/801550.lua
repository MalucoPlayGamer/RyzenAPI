-- Lua provided by RyzenAPI
-- Game: VAIL

-- MAIN APPLICATION
addappid(801550)
-- Game: addappid(801550)

-- MAIN APP DEPOTS / PACKAGES
addappid(801551, 1, "728061a23095cca7547013f02f30eb273a145d3f9c601be56f719c439c127ab5")
