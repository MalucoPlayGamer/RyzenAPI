-- Lua provided by RyzenAPI
-- Game: G-Darius HD

-- MAIN APPLICATION
addappid(1640160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1640161, 1, "37d573faa8c19707f6a50d6c55fe1e34cc80cfce680a78b36ac3da60130f0919")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
