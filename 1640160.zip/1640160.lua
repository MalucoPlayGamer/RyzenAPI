-- Lua provided by SkyAPI 
-- Game: G-Darius HD
addappid(1640160)
addappid(1640161, 1, "37d573faa8c19707f6a50d6c55fe1e34cc80cfce680a78b36ac3da60130f0919")
