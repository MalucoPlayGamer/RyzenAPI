-- Lua provided by SkyAPI 
-- Game: 海伦的神迹
addappid(2264050)
addappid(2264051, 1, "7e0c9dc49d4f27bf7acc60fd3661ac47ac9e78f7331ba32e91593c2e6250c296")
