-- Lua provided by RyzenAPI
-- Game: 宇宙大战

-- MAIN APPLICATION
addappid(2941600)

