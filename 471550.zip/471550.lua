-- Lua provided by RyzenAPI
-- Game: Game: AppID 471550

-- MAIN APPLICATION
addappid(471550)
-- Game: addappid(471550)

-- MAIN APP DEPOTS / PACKAGES
addappid(471551, 1, "6e74fcf75e2ec0d2cb0503d3ebcdfafa5c1e46d784307f42245f3ee8ec517ad1")
