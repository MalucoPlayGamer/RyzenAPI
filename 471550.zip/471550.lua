-- Lua provided by RyzenAPI
-- Game: AppID 471550

-- MAIN APPLICATION
addappid(471550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(471551, 1, "6e74fcf75e2ec0d2cb0503d3ebcdfafa5c1e46d784307f42245f3ee8ec517ad1")

