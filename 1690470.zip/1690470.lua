-- Lua provided by RyzenAPI
-- Game: addappid(1690470)

-- MAIN APPLICATION
addappid(1690470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690470,0,"9037c3a3c8fe0a70f3be56451a5a973c62ec49ba8c8e32702d1f345bbc081171")
