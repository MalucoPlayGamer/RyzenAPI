-- Lua provided by RyzenAPI
-- Game: Soundart

-- MAIN APPLICATION
addappid(1144460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144461, 1, "0f55b7c437619121033ee9afec32b356565890cd5578a7f7810a47fd9d8a12e6")

