-- Lua provided by RyzenAPI
-- Game: Natsu-Mon: 20th Century Summer Kid: Broadcast Over Sunset

-- MAIN APPLICATION
addappid(2913330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913330,0,"77217da454f17cb71823d83ccab084c20356dfe54ce50434be0d486ef697034c")

