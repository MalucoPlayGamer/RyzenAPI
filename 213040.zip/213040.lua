-- Lua provided by RyzenAPI
-- Game: 213040

-- MAIN APPLICATION
addappid(213040)
-- Game: addappid(213040)

-- MAIN APP DEPOTS / PACKAGES
addappid(213041, 1, "f16f1fb1b412dfef34c7aca4003407740332f29a3999a50243b0f783c04eefb7")
