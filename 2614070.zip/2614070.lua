-- Lua provided by RyzenAPI
-- Game: Game: AppID 2614070

-- MAIN APPLICATION
addappid(2614070)
-- Game: addappid(2614070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614071, 1, "85b2e14de3f99250e09830257b8ce9b7344187e52cacf34930d5c218667b6b94")
