-- Lua provided by RyzenAPI
-- Game: AppID 2614070

-- MAIN APPLICATION
addappid(2614070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614071, 1, "85b2e14de3f99250e09830257b8ce9b7344187e52cacf34930d5c218667b6b94")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3936700)
