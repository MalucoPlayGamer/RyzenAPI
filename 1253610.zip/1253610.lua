-- Lua provided by RyzenAPI
-- Game: Knights of Braveland

-- MAIN APPLICATION
addappid(1253610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253611, 1, "3bfebdd43248d658a1001b36087a126fac229e5a2a5314cf9c722fd03c79ae17")
addappid(2145110, 0, "1c659c50dc3e2918f65b85852e70a9d8e682717cb45b4278c23e9e57f0d513b5")
addappid(2411220, 0, "bd9bdf423bee3c9739ccf99d3da0f3e734d708f9156d8fa6d72fc9a5746f76f1")
addappid(2438580, 0, "16877cb932d14c80717b3e8ce5a91a2127c6eee3f23b1e8cbd0ed22851fe3c6e")
addappid(2461900, 0, "1ba5515ba6163daf81ff49aea020267113d4d1a85d4d2ab02bf60e9b5b1eb5b9")
