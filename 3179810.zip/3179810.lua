-- Lua provided by RyzenAPI
-- Game: addappid(3179810)

-- MAIN APPLICATION
addappid(3179810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179811, 1, "5cd551a2cf589edb61616942a5ef65e8da886f9a7c0d131da7922c3fbf47e1ac")
