-- Lua provided by RyzenAPI
-- Game: addappid(1560770)

-- MAIN APPLICATION
addappid(1560770)
addappid(1639270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560771, 1, "3aa02449c5684f32c58b4adaa2a9637f6eef2cb6e120b14f1289a3cd7f4bb889")
