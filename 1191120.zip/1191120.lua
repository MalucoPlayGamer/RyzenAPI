-- Lua provided by RyzenAPI
-- Game: AppID 1191120

-- MAIN APPLICATION
addappid(1191120)
-- Game: addappid(1191120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191121, 1, "5913b2917b96d71e339e9175199aeba99a578f4fe1df7822e476fa8bd4ce03d9")
addappid(1191122, 1, "0ae86d85871673b844b3a53a3d2bd424bbe59d8b15d67c4bcbd4fbb096da3a93")
