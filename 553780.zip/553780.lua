-- Lua provided by RyzenAPI
-- Game: 553780

-- MAIN APPLICATION
addappid(553780)
-- Game: addappid(553780)

-- MAIN APP DEPOTS / PACKAGES
addappid(553781, 1, "86dc86ad0e78109d644ac353cf1489838b95fdcf2cb93fe5921a2e4deb2cb192")
