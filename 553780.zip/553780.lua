-- Lua provided by RyzenAPI
-- Game: ARK BOX Unlimited

-- MAIN APPLICATION
addappid(553780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(553781, 1, "86dc86ad0e78109d644ac353cf1489838b95fdcf2cb93fe5921a2e4deb2cb192")

