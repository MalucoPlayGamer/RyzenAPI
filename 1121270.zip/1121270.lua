-- Lua provided by RyzenAPI
-- Game: Game: Impossible Soaring

-- MAIN APPLICATION
addappid(1121270)
-- Game: addappid(1121270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121271, 1, "e5c80506313ae8a1acb9afc862ecd07a2e5f77d447ff355a0a64d176ceb249e5")
