-- Lua provided by RyzenAPI 
-- Game: Impossible Soaring
addappid(1121270)
addappid(1121271, 1, "e5c80506313ae8a1acb9afc862ecd07a2e5f77d447ff355a0a64d176ceb249e5")
