-- Lua provided by RyzenAPI
-- Game: addappid(593700)

-- MAIN APPLICATION
addappid(593700)

-- MAIN APP DEPOTS / PACKAGES
addappid(593701, 1, "82cd74a968549e2fba06f1caaab6af520f0ecee3e4b56f49689812f58e7a357f")
