-- Lua provided by RyzenAPI
-- Game: Tower Fortress

-- MAIN APPLICATION
addappid(593700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(593701, 1, "82cd74a968549e2fba06f1caaab6af520f0ecee3e4b56f49689812f58e7a357f")

