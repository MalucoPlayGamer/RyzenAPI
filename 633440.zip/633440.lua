-- Lua provided by RyzenAPI
-- Game: addappid(633440)

-- MAIN APPLICATION
addappid(633440)

-- MAIN APP DEPOTS / PACKAGES
addappid(633441, 1, "33ba55dc4f7acee53a88914e0c42b78de56f952c9b0afd590592b331faaac42b")
