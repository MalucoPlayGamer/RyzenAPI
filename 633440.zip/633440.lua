-- Lua provided by RyzenAPI
-- Game: Unit 4

-- MAIN APPLICATION
addappid(633440)
addappid(809100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(633441, 1, "33ba55dc4f7acee53a88914e0c42b78de56f952c9b0afd590592b331faaac42b")

