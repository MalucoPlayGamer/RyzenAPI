-- Lua provided by RyzenAPI
-- Game: 582230

-- MAIN APPLICATION
addappid(582230)

-- MAIN APP DEPOTS / PACKAGES
addappid(582230,0,"3b7b0506ccefa6deb03f29f8ace1cd046b6cd656a750fd4c819132109e1709fc")

