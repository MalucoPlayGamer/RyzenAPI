-- Lua provided by RyzenAPI
-- Game: Sonority

-- MAIN APPLICATION
addappid(1432390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432391, 1, "d7b96adc574b9ce4df0cfdb8d4e640063a6d15f57b90c8277666c6492cea2b7a")
