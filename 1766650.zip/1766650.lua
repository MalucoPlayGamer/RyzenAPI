-- Lua provided by SkyAPI 
-- Game: AppID 1766650
addappid(1766650)
addappid(1766651, 1, "b757cf8caa4601b64531b0a5c12c613359c433cfa73c824773b1363148d3f2c0")
