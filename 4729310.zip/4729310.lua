-- 4729310's Lua and Manifest Created by Hubcap Manifest
-- Playing Prague
-- Created: August 07, 2026 at 07:24:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(4729310) -- Playing Prague
-- MAIN APP DEPOTS
addappid(4729311, 1, "afe54275376f623ec7a6252ec80e321a7e09646054b96b799a977542fe11ded1") -- Depot 4729311
setManifestid(4729311, "7452024190636443205", 354122383)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4729430) -- Playing Prague Boats  Pears
addappid(4729440) -- Playing Prague Bells  Unicorns