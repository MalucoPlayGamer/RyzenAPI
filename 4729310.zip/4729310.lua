-- Lua provided by RyzenAPI
-- Game: Playing Prague

-- MAIN APPLICATION
addappid(4729310) -- Playing Prague
addappid(4729430) -- Playing Prague Boats  Pears
addappid(4729440) -- Playing Prague Bells  Unicorns

-- MAIN APP DEPOTS / PACKAGES
addappid(4729311, 1, "afe54275376f623ec7a6252ec80e321a7e09646054b96b799a977542fe11ded1") -- Depot 4729311

