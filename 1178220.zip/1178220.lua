-- Lua provided by RyzenAPI
-- Game: AppID 1178220

-- MAIN APPLICATION
addappid(1178220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178221, 1, "6d8589ce125219ad40ae4d658a1b63d9eb4f129d63d3cec68611be8635e64aee")
addappid(1178222, 1, "84d5a9d0372359667d9f7564f96b0b52d68693626f1016534f7b1be12b1c5f21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
