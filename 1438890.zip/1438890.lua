-- Lua provided by RyzenAPI
-- Game: AppID 1438890

-- MAIN APPLICATION
addappid(1438890)
-- Game: addappid(1438890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438891, 1, "2ff6f899fb3e84ea174eee80c564730c279e9a526d1327a6a5736081ec7c15ca")
