-- Lua provided by RyzenAPI
-- Game: 1113040

-- MAIN APPLICATION
addappid(1113040)
-- Game: addappid(1113040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113040,0,"5679927debc1cd9eb65f55dcb1ad7f663ada42f3e1d1a80a9a90635af0b3814e")
