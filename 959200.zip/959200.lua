-- Lua provided by RyzenAPI
-- Game: Battleships and Carriers - WW2 Battleship Game

-- MAIN APPLICATION
addappid(959200)
-- Game: addappid(959200)

-- MAIN APP DEPOTS / PACKAGES
addappid(959201, 1, "f91ac06e7d607e9a41880727a3db22beb8f76983afcb1693126c925447ed29aa")
