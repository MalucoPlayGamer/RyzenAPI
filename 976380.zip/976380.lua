-- Lua provided by RyzenAPI
-- Game: Never Split the Party Dedicated Server

-- MAIN APPLICATION
addappid(976380)

-- MAIN APP DEPOTS / PACKAGES
addappid(976381, 1, "1c84ff4824a0df64f26924cc0d7a3413a14e1b90f0b047545417401cf94de082")

