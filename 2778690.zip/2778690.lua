-- Lua provided by RyzenAPI
-- Game: Game: Challenger's Odyssey

-- MAIN APPLICATION
addappid(2778690)
-- Game: addappid(2778690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778691, 1, "70ae544882f2610bae50dad50f0ff5850e0d77e6525c62f59ef35b140bf21bfd")
