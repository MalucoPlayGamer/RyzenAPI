-- Lua provided by RyzenAPI
-- Game: Challenger's Odyssey

-- MAIN APPLICATION
addappid(2778690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778691, 1, "70ae544882f2610bae50dad50f0ff5850e0d77e6525c62f59ef35b140bf21bfd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
