-- Lua provided by RyzenAPI
-- Game: Game: Puny BOB

-- MAIN APPLICATION
addappid(2167900)
-- Game: addappid(2167900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167901, 1, "af8ab947c05c9540ea265a72dcd2c7f5285c759279e296669543181d1e425235")
