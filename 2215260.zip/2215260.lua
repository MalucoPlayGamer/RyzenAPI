-- Lua provided by RyzenAPI
-- Game: Scott Pilgrim vs. The World™: The Game – Complete Edition

-- MAIN APPLICATION
addappid(2215260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215261, 1, "3277ddd400b44f1f72fbadb0eb9d2e384948f881240704ac72b99c1ea07aa127")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2221240)
