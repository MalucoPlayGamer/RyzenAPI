-- Lua provided by RyzenAPI
-- Game: Scott Pilgrim vs. The World™: The Game – Complete Edition

-- MAIN APPLICATION
addappid(2215260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215261, 1, "3277ddd400b44f1f72fbadb0eb9d2e384948f881240704ac72b99c1ea07aa127")
