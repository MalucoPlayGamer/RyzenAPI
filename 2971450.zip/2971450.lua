-- Lua provided by RyzenAPI
-- Game: Unicopia

-- MAIN APPLICATION
addappid(2971450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2971451,0,"be7ec730cbb8275d4fcb2e56a6a9a3aa0fc04d8fc88bd9c7fa0f17e97c16b9f3")

