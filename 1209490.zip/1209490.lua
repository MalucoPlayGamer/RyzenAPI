-- Lua provided by RyzenAPI 
-- Game: Exit the Gungeon
addappid(1209490)
addappid(1209491, 1, "c62fffd4494265f0d61a5c37829f4c4637c4fc6628a25dc6230300533449aaaa")
