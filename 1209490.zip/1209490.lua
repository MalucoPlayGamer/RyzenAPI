-- Lua provided by RyzenAPI
-- Game: Exit the Gungeon

-- MAIN APPLICATION
addappid(1209490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209491, 1, "c62fffd4494265f0d61a5c37829f4c4637c4fc6628a25dc6230300533449aaaa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
