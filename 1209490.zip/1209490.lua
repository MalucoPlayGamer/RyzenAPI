-- Lua provided by RyzenAPI
-- Game: Game: Exit the Gungeon

-- MAIN APPLICATION
addappid(1209490)
-- Game: addappid(1209490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209491, 1, "c62fffd4494265f0d61a5c37829f4c4637c4fc6628a25dc6230300533449aaaa")
