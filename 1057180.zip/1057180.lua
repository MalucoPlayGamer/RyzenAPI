-- Lua provided by SkyAPI 
-- Game: AppID 1057180
addappid(1057180)
addappid(1057181, 1, "e8e53b29d71fa343af5fe185aa53f0f72df65e7996745dd4fdb7883d6247e51e")
