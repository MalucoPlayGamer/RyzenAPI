-- Lua provided by RyzenAPI
-- Game: Feel Up a Sexy Lifeguard!

-- MAIN APPLICATION
addappid(1438870)
-- Game: addappid(1438870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438871, 1, "717d719f10a5c4e0384c602448601a902fa74545144de9507133911a3127c1f9")
addappid(1438872, 1, "1b0121b9f7b97c9307800f5b2d6de2cad567dd03796f08300b6ab261bca44d6f")
