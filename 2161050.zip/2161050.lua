-- Lua provided by SkyAPI 
-- Game: Boti: Byteland Overclocked
addappid(2161050)
addappid(2161051, 1, "f5aaffa0d070e7d43b932d3514f1a82b0f8eea99d4a82004c723cdd0fda67cc0")
