-- Lua provided by RyzenAPI
-- Game: Boti: Byteland Overclocked

-- MAIN APPLICATION
addappid(2161050)
addappid(2649360)
addappid(2729630)
addappid(2729700)
addappid(2736460)
addappid(2777280)
addappid(2777290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2161051, 1, "f5aaffa0d070e7d43b932d3514f1a82b0f8eea99d4a82004c723cdd0fda67cc0")

