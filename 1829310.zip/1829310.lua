-- Lua provided by RyzenAPI
-- Game: Corsair`s Madness

-- MAIN APPLICATION
addappid(1829310)
-- Game: addappid(1829310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829311, 1, "84a7d1a48ceb0e9bb4ae0b2d059884db7df3fb418dd193b4ed4ebc23ecd26908")
