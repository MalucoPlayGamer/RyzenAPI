-- Lua provided by RyzenAPI
-- Game: addappid(740270)

-- MAIN APPLICATION
addappid(740270)

-- MAIN APP DEPOTS / PACKAGES
addappid(740271, 1, "950f59d18e796a60ff43e46a6e6bb0481d7cb97e403cb848d51912686e144cff")
