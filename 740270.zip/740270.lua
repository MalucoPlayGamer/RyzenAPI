-- Lua provided by RyzenAPI 
-- Game: MusicWave
addappid(740270)
addappid(740271, 1, "950f59d18e796a60ff43e46a6e6bb0481d7cb97e403cb848d51912686e144cff")
