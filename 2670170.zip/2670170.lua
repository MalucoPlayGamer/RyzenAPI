-- Lua provided by RyzenAPI
-- Game: 2670170

-- MAIN APPLICATION
addappid(2670170)
-- Game: addappid(2670170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670170,0,"5a69d4bd15a5e7128b1593b9baab53fe3d36cc325c62c43d007c368836b6d3ad")
