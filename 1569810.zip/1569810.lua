-- Lua provided by RyzenAPI
-- Game: Game: 24 Solar Terms

-- MAIN APPLICATION
addappid(1569810)
addappid(3253120)
addappid(3253121)
addappid(3253122)
-- Game: addappid(1569810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569811, 1, "ea2915fdf8438aa9041489ab0dead9148e8d877937cfbbef46fbfdb7709b6dbf")
