-- Lua provided by RyzenAPI
-- Game: Tales of Vesperia: Definitive Edition

-- MAIN APPLICATION
addappid(738540)
addappid(821740)
addappid(821750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(738541, 1, "a3f1c2ec60b0cd236e6cb1f1c9de6d37cf14d204bf20276da3515d80b71b9bc9")
addappid(738542, 1, "6104766022368d570119bbb4cf30a070b3f8a1e95258b02b03310603b6804208")
addappid(738543, 1, "895d98bae335d00b33b13fef21108f005f023761c00fc52e6e1ac3a583c14242")

