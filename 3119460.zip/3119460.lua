-- Lua provided by RyzenAPI
-- Game: addappid(3119460)

-- MAIN APPLICATION
addappid(3119460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3119461, 1, "e4f50fa3e340d4d317bfd7745d43c701957e367890cfce6c7796807c1e4236f5")
