-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(597190)
addappid(597191)
addappid(597193)

-- MAIN APP DEPOTS / PACKAGES
addappid(597192,0,"dcb69a41ea627e6cdba0b2a96d1d27e9ea46e11060e9fc67335f5a738ea3ece4")
