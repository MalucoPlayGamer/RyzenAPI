-- Lua provided by RyzenAPI
-- Game: For The Warp

-- MAIN APPLICATION
addappid(1201830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201831, 1, "aa6751cc1ec8d57e3e9a04a44ea6489b57a0016b9bfaab5b1068bb539e256a4f")

