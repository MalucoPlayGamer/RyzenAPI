-- Lua provided by RyzenAPI
-- Game: Trollge The Incidents Maker - Demo

-- MAIN APPLICATION
addappid(3083850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3083851, 1, "841b00353316973cd7621e469186c712f0002e9a330c3a3c54a779b8e7bf46e8")

