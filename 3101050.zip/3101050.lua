-- Lua provided by RyzenAPI
-- Game: Parasitic Descent

-- MAIN APPLICATION
addappid(3101050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3101051, 1, "bdc089a37811cb52263c9f6a7b0664f0bbd2e44294ee32f85062ba53b5a428bd")

