-- Lua provided by RyzenAPI
-- Game: Ties

-- MAIN APPLICATION
addappid(1362390)
-- Game: addappid(1362390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362391, 1, "b3844554027f4f23e67d4971861868f62cc367b1bf522d20cc94d592f8061786")
