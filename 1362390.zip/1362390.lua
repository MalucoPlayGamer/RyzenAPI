-- Lua provided by RyzenAPI
-- Game: Ties

-- MAIN APPLICATION
addappid(1362390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362391, 1, "b3844554027f4f23e67d4971861868f62cc367b1bf522d20cc94d592f8061786")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
