-- Lua provided by RyzenAPI
-- Game: RedSun RTS

-- MAIN APPLICATION
addappid(758880)
addappid(927780)
addappid(928540)
addappid(928550)
addappid(928560)
addappid(928570)

-- MAIN APP DEPOTS / PACKAGES
addappid(758881,0,"e35bb9b348c76b5820b308ba6670567ac2f964cc29275bcd30bcb631b46c7a03")

