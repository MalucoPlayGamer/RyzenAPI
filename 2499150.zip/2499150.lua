-- Lua provided by RyzenAPI
-- Game: 2499150

-- MAIN APPLICATION
addappid(2499150)
-- Game: addappid(2499150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499151, 1, "a968b7b6a39ae428af82e9af68e515a9a82b98745c44cd23e813495d1462ceea")
