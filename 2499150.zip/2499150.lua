-- Lua provided by RyzenAPI
-- Game: Aonar

-- MAIN APPLICATION
addappid(2499150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2499151, 1, "a968b7b6a39ae428af82e9af68e515a9a82b98745c44cd23e813495d1462ceea")

