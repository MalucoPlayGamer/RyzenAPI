-- Lua provided by RyzenAPI
-- Game: Starlight of Aeons

-- MAIN APPLICATION
addappid(644200)
-- Game: addappid(644200)

-- MAIN APP DEPOTS / PACKAGES
addappid(644201, 1, "662e1c277d3116ba73e0496b1568f375a6bfec905e569a32519f001107a971ac")
addappid(644202, 1, "33ff243e7624c9a7cb6d1b38867073930a1ca3991c349c7ff7c3bcc55e62a270")
addappid(644203, 1, "c9d8943f956c917fc8a269e62ac5aa3965a638b493235c830de723b9fcca90e8")
addappid(644204, 1, "88afe16d49a84abd8439cfc53e7f4ebdce5aa11985a080a6ba2bb67f57105619")
