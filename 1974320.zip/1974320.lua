-- Lua provided by RyzenAPI
-- Game: Colors! Platform

-- MAIN APPLICATION
addappid(1974320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1974321, 1, "1b11972a35b54adaa81fc61a3c8abe91b6c9c011fb3b6fd8e5cda66b11c33f6c")

