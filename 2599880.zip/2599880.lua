-- Lua provided by RyzenAPI
-- Game: Happiness! Sakura Celebration!

-- MAIN APPLICATION
addappid(2599880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2599881, 1, "f6ab47742cfaf002c00e585b23c69769e6250c672135cc5d5d5b93afd68f18e5")

