-- Lua provided by RyzenAPI
-- Game: Game: Happiness! Sakura Celebration!

-- MAIN APPLICATION
addappid(2599880)
-- Game: addappid(2599880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2599881, 1, "f6ab47742cfaf002c00e585b23c69769e6250c672135cc5d5d5b93afd68f18e5")
