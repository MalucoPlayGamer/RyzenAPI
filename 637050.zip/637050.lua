-- Lua provided by RyzenAPI
-- Game: AppID 637050

-- MAIN APPLICATION
addappid(637050)

-- MAIN APP DEPOTS / PACKAGES
addappid(637051, 1, "a4b62b338d0017fe1b08d003de4ac2a73ace00d7a64b5041c908626f10cecd1c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1774730)
