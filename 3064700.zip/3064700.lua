-- Lua provided by RyzenAPI
-- Game: Darkest Dungeon® II: Mod Tools

-- MAIN APPLICATION
addappid(3064700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064701, 1, "91bf97a9c24b4c5d94ca4b30371c8e55c5b64ce038baa4c90f54a74060d3a6ba")
