-- Lua provided by RyzenAPI
-- Game: DxR -A Better Tomorrow-

-- MAIN APPLICATION
addappid(2755900)
-- Game: addappid(2755900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755901, 1, "baf51a533915e999dd99f21c30f7a2b04de431a1398c986b5d3f958858f2484e")
addappid(2755902, 1, "45b0064420e8e086ef2ab8099c37a07a82e0b4481fb0d827489194f6cd03baf4")
addappid(2755903, 1, "21cf25030f9ae495baf0561e46f2d0e821d4d15e7ca6fff3d8df09cd9bf8564b")
