-- Lua provided by RyzenAPI
-- Game: Game: NIRO

-- MAIN APPLICATION
addappid(1448610)
-- Game: addappid(1448610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448611, 1, "276be4ec19b60090beea9ea2eb387d5a70adb99d220be49de2dfe6af814d512e")
