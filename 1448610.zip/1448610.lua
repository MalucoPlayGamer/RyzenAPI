-- Lua provided by RyzenAPI
-- Game: NIRO

-- MAIN APPLICATION
addappid(1448610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448611, 1, "276be4ec19b60090beea9ea2eb387d5a70adb99d220be49de2dfe6af814d512e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1844220)
