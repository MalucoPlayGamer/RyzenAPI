-- Lua provided by RyzenAPI
-- Game: Game: AppID 3372240

-- MAIN APPLICATION
addappid(3372240)
-- Game: addappid(3372240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372241, 1, "f202db7298fe0db750b8841b286d6fec20ad24822a2488a62a9f4377046f61d9")
