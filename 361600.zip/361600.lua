-- Lua provided by RyzenAPI 
-- Game: Luna Sky
addappid(361600)
addappid(361601, 1, "71bf1b7c0ba96f9986f5db9bd6af5d34014a02f3958ab17e9035f433e481fef4")
addappid(361602, 1, "f8869d3d2ed10ec248af28db6f7d7cc798ec708476823f90c6ce3ffdef74c766")
addappid(361603, 1, "fd490c67e302450d0faf588093d340a499d6eed8cbd41a4df37677a3b436a51a")
