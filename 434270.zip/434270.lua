-- Lua provided by RyzenAPI
-- Game: Game: AppID 434270

-- MAIN APPLICATION
addappid(434270)
-- Game: addappid(434270)

-- MAIN APP DEPOTS / PACKAGES
addappid(434271, 1, "8cb90b39ad71cc72019b0d2550c817f78e0b913b624cff93b605658efa92ee32")
