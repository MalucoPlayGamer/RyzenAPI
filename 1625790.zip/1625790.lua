-- Lua provided by RyzenAPI
-- Game: Unicorn and Sweets

-- MAIN APPLICATION
addappid(1625790)
-- Game: addappid(1625790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625791, 1, "62518aa1ac93e9211251ad08230f98d0f5b4728d62bbabe8742ad7bb877b698e")
