-- Lua provided by RyzenAPI
-- Game: Game: Last Time I Saw You - Soundtrack

-- MAIN APPLICATION
addappid(3240960)
-- Game: addappid(3240960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3240961, 1, "c24378c26f17fc10b905a6f3a04f876f65aac6ed50cc12ad3d66ee2901b39288")
