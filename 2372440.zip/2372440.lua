-- Lua provided by SkyAPI 
-- Game: Aphelion Headhunters
addappid(2372440)
addappid(2372441, 1, "165ea09438a9e0777ccc47b830a2aa278b1104ce99f708c40a39a0492bdfc2d9")
