-- Lua provided by RyzenAPI
-- Game: Aphelion Headhunters

-- MAIN APPLICATION
addappid(2372440)
-- Game: addappid(2372440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372441, 1, "165ea09438a9e0777ccc47b830a2aa278b1104ce99f708c40a39a0492bdfc2d9")
