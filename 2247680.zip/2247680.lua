-- Lua provided by RyzenAPI
-- Game: Read Clock Time

-- MAIN APPLICATION
addappid(2247680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247681, 1, "df0b07b0cb7293a3992a61de9f384f53610da740932658f5944d8701a10de2dc")
