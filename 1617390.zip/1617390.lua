-- Lua provided by RyzenAPI 
-- Game: FLOW
addappid(1617390)
addappid(1617391, 1, "286bd5380c12bffb738280e68ff46c25dbd0debbaa51dd69e970e374affb6cd7")
