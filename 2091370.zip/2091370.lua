-- Lua provided by RyzenAPI
-- Game: Songs from the Iron Sea

-- MAIN APPLICATION
addappid(2091370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091371, 1, "bda07a85f690d374920302085e2bb33f328d508c6f61829354e8a697e0ee70fd")

