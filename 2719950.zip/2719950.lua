-- Lua provided by RyzenAPI
-- Game: Unveiling

-- MAIN APPLICATION
addappid(2719950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719951, 1, "27541fc6c2d5d2abb806083350a4c7681717f7f3c28d5566d385b526fe28930d")

