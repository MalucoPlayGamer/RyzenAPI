-- Lua provided by RyzenAPI
-- Game: addappid(2188200)

-- MAIN APPLICATION
addappid(2188200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2188201, 1, "8a83f1cb7eafce5f1921f7cd209030dfedd2724216028658811d9f208d7486cc")
