-- Lua provided by RyzenAPI
-- Game: Beers and Boomerangs

-- MAIN APPLICATION
addappid(1588610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588611, 1, "4e26131bdf5914cfb33850f62b683d335f413c7e9589fa3bcc1b95837c620d7d")
