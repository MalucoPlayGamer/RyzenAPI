-- Lua provided by RyzenAPI
-- Game: Game: Bot Gaiden

-- MAIN APPLICATION
addappid(925560)
-- Game: addappid(925560)

-- MAIN APP DEPOTS / PACKAGES
addappid(925561, 1, "3f8bfe137a5b22f53536c9e09352ca2dbbb4594bc05c111e765a4260ba7d453e")
