-- Lua provided by RyzenAPI
-- Game: Rage Of Towers

-- MAIN APPLICATION
addappid(2567680)
-- Game: addappid(2567680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567681, 1, "a0da015cb28f766b4d4a1e33fb09926b42a3d94319db711df91c461f8a40465d")
