-- Lua provided by RyzenAPI
-- Game: Rage Of Towers

-- MAIN APPLICATION
addappid(2567680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2567681, 1, "a0da015cb28f766b4d4a1e33fb09926b42a3d94319db711df91c461f8a40465d")

