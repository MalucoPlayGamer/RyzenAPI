-- Lua provided by SkyAPI 
-- Game: Timberborn Soundtrack
addappid(1752670)
addappid(1752671, 1, "09d280d511a68a0d8dca917c8c57f40fc00f5dbf9b287958e66ce44238661740")
addappid(1752672, 1, "a7f67da01e16bc74b5402c81867dbe7b126330c758b7b6e49e267f9be628473a")
