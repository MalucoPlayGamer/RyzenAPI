-- Lua provided by RyzenAPI
-- Game: Toybox Turbos

-- MAIN APPLICATION
addappid(287260)

-- MAIN APP DEPOTS / PACKAGES
addappid(287261, 1, "1b54b4983e5a4831e808fa1adfb07b5c150523ecb38e46a8d21c397956da7ea8")
addappid(287262, 1, "9c6978768f801d19730cdaf882f39f022ba00bb152e15461e00e581c0b4e8969")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
