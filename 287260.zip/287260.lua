-- Lua provided by RyzenAPI
-- Game: Game: Toybox Turbos

-- MAIN APPLICATION
addappid(287260)
-- Game: addappid(287260)

-- MAIN APP DEPOTS / PACKAGES
addappid(287261, 1, "1b54b4983e5a4831e808fa1adfb07b5c150523ecb38e46a8d21c397956da7ea8")
addappid(287262, 1, "9c6978768f801d19730cdaf882f39f022ba00bb152e15461e00e581c0b4e8969")
