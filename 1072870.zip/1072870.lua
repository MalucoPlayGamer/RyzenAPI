-- Lua provided by RyzenAPI
-- Game: AppID 1072870

-- MAIN APPLICATION
addappid(1072870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1072871, 1, "ede19687495bea3d42d99eaf5665d2f03f7eb43a3eee83cb46a6988204a5c7ad")

