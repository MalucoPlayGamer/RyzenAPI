-- Lua provided by RyzenAPI
-- Game: Mr Blaster

-- MAIN APPLICATION
addappid(618490)
-- Game: addappid(618490)

-- MAIN APP DEPOTS / PACKAGES
addappid(618491, 1, "ca2f065ffef74385d84ec3620a7653baf3d9e0153a5e7b502857b63dfcb973bb")
addappid(618492, 1, "2bef123e8373fd58c3966c0580ab15f48d8f2904691e826517d8b94b1d524ff4")
