-- Lua provided by RyzenAPI
-- Game: Really Trash Game

-- MAIN APPLICATION
addappid(1313470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313471, 1, "765694688df7f3d07b30ae0ba739f5609479aba4ebf4c9055c68a5b30e0a3b41")

