-- Lua provided by RyzenAPI
-- Game: addappid(311080)

-- MAIN APPLICATION
addappid(311080)

-- MAIN APP DEPOTS / PACKAGES
addappid(311081, 1, "1d7e23755e0433b0f0edd862143940aa7e5699af4e2e7d98e5ed5bef66233d73")
