-- Lua provided by RyzenAPI
-- Game: Game: AppID 918180

-- MAIN APPLICATION
addappid(918180)
-- Game: addappid(918180)

-- MAIN APP DEPOTS / PACKAGES
addappid(918181, 1, "d4dd94c5fcde3e79c3a474e5265e11d5408ed9c01e5a74c7c4e8d2d80a04b3d8")
