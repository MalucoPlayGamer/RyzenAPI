-- Lua provided by SkyAPI 
-- Game: AppID 918180
addappid(918180)
addappid(918181, 1, "d4dd94c5fcde3e79c3a474e5265e11d5408ed9c01e5a74c7c4e8d2d80a04b3d8")
