-- Lua provided by RyzenAPI
-- Game: Tanks Meet Zombies

-- MAIN APPLICATION
addappid(743340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(743341,0,"202d5faf6e7e9ec6884127be40fed46bcd37d1a91fd197c100b6a5a3b043436b")

