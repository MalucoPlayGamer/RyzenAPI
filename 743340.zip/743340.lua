-- Lua provided by RyzenAPI
-- Game: Tanks Meet Zombies

-- MAIN APPLICATION
addappid(743340)

-- MAIN APP DEPOTS / PACKAGES
addappid(743341,0,"202d5faf6e7e9ec6884127be40fed46bcd37d1a91fd197c100b6a5a3b043436b")

