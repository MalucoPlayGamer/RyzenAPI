-- Lua provided by RyzenAPI
-- Game: Off-Road: Redneck Racing

-- MAIN APPLICATION
addappid(2742010)
addappid(2802270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742011, 1, "0cbcb5c209cf5b99f225956e105a2bc417b72c171cb0c3e042062785e31e3573")
