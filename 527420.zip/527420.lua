-- Lua provided by RyzenAPI
-- Game: Demon Hunter 3: Revelation

-- MAIN APPLICATION
addappid(527420)

-- MAIN APP DEPOTS / PACKAGES
addappid(527421, 1, "0ec409c3ca206a9a48133fb949cdd8444934c8b1e57fc05273b47d41a77d40e3")
