-- Lua provided by RyzenAPI
-- Game: Eldrea: SEX Saga 🔞

-- MAIN APPLICATION
addappid(3044550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044551, 1, "0e2d106c15c99f7de40b6c155b15b1efbf330fc9d39caa929949b6af82b97c6d")
