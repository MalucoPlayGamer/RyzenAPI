-- Lua provided by RyzenAPI 
-- Game: Mechanibot
addappid(1842510)
addappid(1842511, 1, "0ad176c0ba39310bce5b973c1997f20a3c9b2f13a979ca6d0b600de6f27d547c")
