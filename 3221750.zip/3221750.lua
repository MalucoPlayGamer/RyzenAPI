-- Lua provided by RyzenAPI
-- Game: The RPG Demo

-- MAIN APPLICATION
addappid(3221750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3221751, 1, "0b6910f420a6cd6287a244295fd0f0229f1c69fc5befaeb02564438af67b4abb")
