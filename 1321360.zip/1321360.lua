-- Lua provided by RyzenAPI
-- Game: AppID 1321360

-- MAIN APPLICATION
addappid(1321360)
-- Game: addappid(1321360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321361, 1, "2ff32a904b7722c91bdae917a7c69f19ed4470881171a0728cdc311be4feb008")
