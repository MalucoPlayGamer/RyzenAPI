-- Lua provided by RyzenAPI
-- Game: addappid(3380050)

-- MAIN APPLICATION
addappid(3380050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380051, 1, "e804a734e84737edd03a2960472c93653f32686abde0ec83a6e68c44b232d4d6")
