-- Lua provided by RyzenAPI
-- Game: Macrotis: A Mother's Journey

-- MAIN APPLICATION
addappid(823840)

-- MAIN APP DEPOTS / PACKAGES
addappid(823841,0,"199efaeb2ef73234c54f62f86b491af7aadfc1ee819f986b398296516b521d11")

