-- Lua provided by RyzenAPI
-- Game: AquaHero

-- MAIN APPLICATION
addappid(2280630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280631, 1, "82259c5360c1ce20e775c11f5e55e1e23138088bf9f90d5ca82c0bf7b4ce4961")

