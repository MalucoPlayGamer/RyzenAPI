-- Lua provided by SkyAPI 
-- Game: Dal Segno
addappid(638930)
addappid(638931, 1, "492677c8825aa526b9fef36249bce39e5d7b3bb85cd4e0b6d6d828944e561130")
addappid(638932, 1, "b664a34a1820a101bf45e06d96f18252c1252c3ef816348c97bb083413433503")
