-- Lua provided by RyzenAPI
-- Game: TealGrounds

-- MAIN APPLICATION
addappid(1767590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767591,0,"9b4b2b994dfdf9c84a8e23872e2682ea8e8b8b1ec6a56f23e0b0cdaf3b84cb85")

