-- Lua provided by RyzenAPI
-- Game: Path of Vidya

-- MAIN APPLICATION
addappid(1676450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676451, 1, "81e84430a96928c58dd38d1ec5a512f3e45ea999f683e3b05571bafda03ce34b")
