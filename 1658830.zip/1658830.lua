-- Lua provided by RyzenAPI
-- Game: Game: Vampire Slave 1: A Yaoi Visual Novel

-- MAIN APPLICATION
addappid(1658830)
-- Game: addappid(1658830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658831, 1, "f193b94c8010a0773994728b0d554b09329c05faccd41aa4ce632abdb76f6b56")
addappid(1724750, 0, "c7031497e6427b80444c49b87e784d11a02ffc7ecae3026721143aa9c44767da")
addappid(1724751, 0, "bda42dc7dc50f74f8b9b62fc0ba46b746b6a7bbea112de52518a6b5dbe29e559")
addappid(1724752, 0, "19a9df9d0576de8efc80622d68fbac9d08f9a827b9ca20742d40953fc64695d1")
addappid(1725720, 0, "f990c2a15ca88cc3ecbbeb16e20ecea00e2570c42b3914f169059319eb61249a")
addappid(1725721, 0, "78b311a9d7d1b44da69dab8ae3a20e306b4f9894ce2161ae1722d0985010810b")
