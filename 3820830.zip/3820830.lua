-- Lua provided by SkyAPI 
-- Game: Anime Dream Match: Primates
addappid(3820830)
addappid(3820831, 1, "ae70adf5d205beef586f52c3926468055bf3abc44f51685e3eb63f7fa4faa9b9")
