-- Lua provided by RyzenAPI
-- Game: Tesla vs Lovecraft

-- MAIN APPLICATION
addappid(636100)

-- MAIN APP DEPOTS / PACKAGES
addappid(636101, 1, "ae49cc673b8c6dfe79f678b6dd3f8edf06a691ff77301badbe6390b4cf1564aa")
addappid(636102, 1, "efc18e56a4e1b82c329c524817586420ee2e207391bd4b61e66ea5100c1f7465")
addappid(636103, 1, "a60e532ad0e83d4157c38180cee27f4898cc8d5d8d6ee42a8425a73ecfd98eb0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(885960)
