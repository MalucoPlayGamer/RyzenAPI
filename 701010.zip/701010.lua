-- Lua provided by RyzenAPI
-- Game: AppID 701010

-- MAIN APPLICATION
addappid(701010)
-- Game: addappid(701010)

-- MAIN APP DEPOTS / PACKAGES
addappid(701011, 1, "40c6dbcebd365ef8570f45b786e4e309fe038c4137ab220d2bf31972d8ed5d60")
