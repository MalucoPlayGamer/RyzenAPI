-- 2310260's Lua and Manifest Created by Hubcap Manifest
-- Super Smash Asteroids
-- Created: August 08, 2026 at 22:54:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2310260) -- Super Smash Asteroids
-- MAIN APP DEPOTS
addappid(2310261, 1, "e8bd1b3a7ac72e203a494e4db911ee56fef0e17d36a7ec59b864a2b9cbaa1444") -- Depot 2310261
setManifestid(2310261, "1202298787906339870", 237121057)