-- Lua provided by RyzenAPI
-- Game: Super Smash Asteroids

-- MAIN APPLICATION
addappid(2310260) -- Super Smash Asteroids

-- MAIN APP DEPOTS / PACKAGES
addappid(2310261, 1, "e8bd1b3a7ac72e203a494e4db911ee56fef0e17d36a7ec59b864a2b9cbaa1444") -- Depot 2310261

