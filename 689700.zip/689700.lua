-- Lua provided by RyzenAPI
-- Game: Mad Crown

-- MAIN APPLICATION
addappid(689700)

-- MAIN APP DEPOTS / PACKAGES
addappid(689701,0,"7f52d4f173207c39b4b671ac49197bbbd5a5f76d9d50e8833e8b8df679a273e1")

