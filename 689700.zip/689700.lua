-- Lua provided by RyzenAPI
-- Game: Mad Crown

-- MAIN APPLICATION
addappid(689700)

-- MAIN APP DEPOTS / PACKAGES
addappid(689701,0,"7f52d4f173207c39b4b671ac49197bbbd5a5f76d9d50e8833e8b8df679a273e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
