-- Lua provided by RyzenAPI
-- Game: 1364040

-- MAIN APPLICATION
addappid(1364040)
-- Game: addappid(1364040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364041, 1, "7f001f415b8d6fe3f4bbebdf30a454dd66e8182044957282e4cb6c98c1753618")
