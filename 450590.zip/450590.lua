-- Lua provided by RyzenAPI
-- Game: Safety Driving Simulator: Car

-- MAIN APPLICATION
addappid(450590)
-- Game: addappid(450590)

-- MAIN APP DEPOTS / PACKAGES
addappid(450591, 1, "441c082098ed05235f4df9b66681b4d42224e07d36397115f096ddadd404c6c8")
