-- Lua provided by RyzenAPI
-- Game: Safety Driving Simulator: Car

-- MAIN APPLICATION
addappid(450590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(450591, 1, "441c082098ed05235f4df9b66681b4d42224e07d36397115f096ddadd404c6c8")

