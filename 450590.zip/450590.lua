-- Lua provided by SkyAPI 
-- Game: Safety Driving Simulator: Car
addappid(450590)
addappid(450591, 1, "441c082098ed05235f4df9b66681b4d42224e07d36397115f096ddadd404c6c8")
