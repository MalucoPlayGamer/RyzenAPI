-- Lua provided by RyzenAPI
-- Game: Missing Mildred

-- MAIN APPLICATION
addappid(1847030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847031, 1, "c616880821820c98a6101c1d17d019479853868d720c62ca33db8b18c59bd6ec")
