-- Lua provided by RyzenAPI
-- Game: 1249060

-- MAIN APPLICATION
addappid(1249060)
-- Game: addappid(1249060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249061, 1, "e4033fa05d7b9611fc5818a4dfc6475a8fc541852ef512a1cabab72fb6c2f5c6")
