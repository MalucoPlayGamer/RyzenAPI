-- Lua provided by RyzenAPI
-- Game: The Curse of the Egyptian Pyramid "Remaster Edition"

-- MAIN APPLICATION
addappid(2708710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708712,0,"c770ad60a580d218250f629c5b397e422f238b2e450de99346ea662890724aa7")
