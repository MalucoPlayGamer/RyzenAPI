-- Lua provided by RyzenAPI
-- Game: 1474100

-- MAIN APPLICATION
addappid(1474100)
addappid(1491890)
-- Game: addappid(1474100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474101, 1, "395727da1d8aea813838d84b4a162f748a69b84b551b556446f0ea7d08fb9bf7")
