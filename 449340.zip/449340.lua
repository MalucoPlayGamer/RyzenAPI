-- Lua provided by RyzenAPI
-- Game: setManifestid(449342,"3981054469328450632")

-- MAIN APPLICATION
addappid(449340)
-- Game: addappid(449340)

-- MAIN APP DEPOTS / PACKAGES
addappid(449342,0,"d2f76af598b01c4caf4c53b2971a8fe34a8382ad78780ad3439c716c6d8a21e3")
