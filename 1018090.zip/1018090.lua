-- Lua provided by RyzenAPI
-- Game: 2100

-- MAIN APPLICATION
addappid(1018090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018091, 1, "f2523f1a01e2289f75a748b6c98f7c9547da7cab84af49fbd2500efeee4177a4")

