-- Lua provided by RyzenAPI
-- Game: Warplanes: Air Corp

-- MAIN APPLICATION
addappid(2583320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2583321,0,"6a15e157df7f58ee1d1d8f6b064a4202e74b9acdcd55bf1615d7ac74b58c12c5")

