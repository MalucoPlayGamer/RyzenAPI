-- Lua provided by RyzenAPI
-- Game: Platform

-- MAIN APPLICATION
addappid(3206240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206241, 1, "9295c379075098543b08e4fbe2bf80eda1c1d677f3044b935ef99085fef27a1d")

