-- Lua provided by RyzenAPI
-- Game: addappid(1696410)

-- MAIN APPLICATION
addappid(1696410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696411, 1, "880b0216af3840e83df00ff6eba4ca6493ddbc9e8d0b21e86ea3d27749573ef8")
