-- Lua provided by RyzenAPI
-- Game: Buccaneer: The Pursuit of Infamy

-- MAIN APPLICATION
addappid(23100)

-- MAIN APP DEPOTS / PACKAGES
addappid(23101, 1, "471b81534782b3e29c7920a0246225b5e5501463f097f04d16d901511bbc62b0")

