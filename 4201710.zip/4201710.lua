-- Lua provided by RyzenAPI
-- Game: Meow My Crop!

-- MAIN APPLICATION
addappid(4201710)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4502090)
