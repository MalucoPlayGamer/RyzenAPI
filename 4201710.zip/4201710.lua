-- Lua provided by RyzenAPI
-- Game: Meow My Crop!

-- MAIN APPLICATION
addappid(4201710)
