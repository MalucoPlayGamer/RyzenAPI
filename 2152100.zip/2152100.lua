-- Lua provided by RyzenAPI
-- Game: Big Bad Futanari Wolf

-- MAIN APPLICATION
addappid(2152100)
-- Game: addappid(2152100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152101, 1, "be7035e77e9f84ee467615156686d088eabd1d247503b463e4658463a31dc5bb")
