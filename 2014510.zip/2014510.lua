-- Lua provided by RyzenAPI
-- Game: Game: COLORIDER

-- MAIN APPLICATION
addappid(2014510)
-- Game: addappid(2014510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014511, 1, "84f3c0773fc22945d943957d734b9b8d1c5121a4b6021fb6ee65b4fd62ef8118")
