-- Lua provided by RyzenAPI
-- Game: Game: Dream fish

-- MAIN APPLICATION
addappid(2895120)
-- Game: addappid(2895120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895121, 1, "27988401391f7d8fb595881c1f61428702d88c67a6f009d89b0d4848f496f02c")
