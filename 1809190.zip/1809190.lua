-- Lua provided by RyzenAPI
-- Game: 1809190

-- MAIN APPLICATION
addappid(1809190)
-- Game: addappid(1809190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809190,0,"3a02d2b2b621b12bbcc4745c3bcd3a5e07a05a978c0d80cab308f32d9b53fab4")
