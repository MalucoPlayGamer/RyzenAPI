-- Lua provided by RyzenAPI
-- Game: 813440

-- MAIN APPLICATION
addappid(813440)

-- MAIN APP DEPOTS / PACKAGES
addappid(813443,0,"c0b66dbb0588929eceb8d299b26e7c0fe7578cb469f3fc04272d7fde426686e4")

