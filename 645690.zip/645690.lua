-- Lua provided by RyzenAPI
-- Game: Fantasia of the Wind - 风之幻想曲

-- MAIN APPLICATION
addappid(645690)
-- Game: addappid(645690)

-- MAIN APP DEPOTS / PACKAGES
addappid(645691, 1, "58733f189a51fadcbaab80dddab51512924a0df1ae4919efb25b197897589547")
addappid(645692, 1, "24bf71dfd287fa01c3f584cb6bdbbed7410c1d9d30dec974dd8c1fa654905455")
