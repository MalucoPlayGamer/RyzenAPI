-- Lua provided by RyzenAPI
-- Game: DFF NT: Devoted Returner Appearance Set for Locke Cole

-- MAIN APPLICATION
addappid(1022345)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022345,0,"ff4962749718e06ee2b887e0f5195d04db476dcf50ac9798ea25748fd3753573")
