-- Lua provided by RyzenAPI
-- Game: 1862070

-- MAIN APPLICATION
addappid(1862070)
-- Game: addappid(1862070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862071, 1, "c832a7e866f5f5b28de7186304f7157d0151b6aad22fb5ffd4017f7c59a84e30")
