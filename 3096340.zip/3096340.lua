-- Lua provided by RyzenAPI
-- Game: Game: Family Friends: Beyond Home

-- MAIN APPLICATION
addappid(3096340)
-- Game: addappid(3096340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3096341, 1, "165b7392fb55a6b5faca135d7bc1075c93302e4d2017ab7862c107d539d69d37")
