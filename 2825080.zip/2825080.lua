-- Lua provided by RyzenAPI
-- Game: addappid(2825080)

-- MAIN APPLICATION
addappid(2825080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825081, 1, "52fd3ebf3be6ce3f1e4a77b4489702ab16a0782985c6a6ae9c775b61f9d5f6fc")
