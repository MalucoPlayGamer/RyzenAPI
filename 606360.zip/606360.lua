-- Lua provided by RyzenAPI
-- Game: addappid(606360)

-- MAIN APPLICATION
addappid(606360)

-- MAIN APP DEPOTS / PACKAGES
addappid(606361, 1, "90341e85d2dc64ddc256d4e65271c8c6ec4787216793af5015abf0f3b4f017dd")
