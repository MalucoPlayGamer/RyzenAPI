-- Lua provided by RyzenAPI 
-- Game: The Surfeit: Episode 1
addappid(1432260)
addappid(1432261, 1, "73d68209a2e4dc0c9cde1dcda0d1f8bae9620f11c792b634f2110d2b2937ee27")
