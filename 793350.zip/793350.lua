-- Lua provided by RyzenAPI
-- Game: Swarmlake

-- MAIN APPLICATION
addappid(793350)

-- MAIN APP DEPOTS / PACKAGES
addappid(793351, 1, "32ab997b8266adc956ec34dae06f6e42ca33bf3d35384f1296c57c9e16646c54")

