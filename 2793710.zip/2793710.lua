-- Lua provided by RyzenAPI
-- Game: AppID 2793710

-- MAIN APPLICATION
addappid(2793710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793711, 1, "cb06d10deaa77ef399d3d5a07908cac2237f31d38a47a83adba03f9f4f5884c4")

