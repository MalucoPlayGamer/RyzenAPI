-- Lua provided by SkyAPI 
-- Game: Strange Seed Demo
addappid(3224660)
addappid(3224661, 1, "a8da0624a071648dde9a55c18335eef9f201663697e4158c1366a068cfc93bd7")
