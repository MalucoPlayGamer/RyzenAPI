-- Lua provided by RyzenAPI
-- Game: 415430

-- MAIN APPLICATION
addappid(415430)
-- Game: addappid(415430)

-- MAIN APP DEPOTS / PACKAGES
addappid(415430,0,"b3039eb56ea9f37506f991ee06e4ac78c626fe98b19ab9c1316004ba422dbb9f")
