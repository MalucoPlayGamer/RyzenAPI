-- Lua provided by RyzenAPI
-- Game: 重檐 Playtest

-- MAIN APPLICATION
addappid(2941860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941861, 1, "591afbca9c36c7273bfcd3aa9edfa55e005ed530d2b3da5d438de0750a4cf852")

