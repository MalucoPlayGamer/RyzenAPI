-- Lua provided by RyzenAPI
-- Game: If My Heart Had Wings -Flight Diary-

-- MAIN APPLICATION
addappid(923810)

-- MAIN APP DEPOTS / PACKAGES
addappid(923811, 1, "4c139a01907a4138844ea79e942c0e64ea3259d45d90d904620bef66c8e2fd49")
addappid(923812, 1, "e96f81161f1ebb4c22b00f35716881e17223d6e54c860d07f360940edc7dc2be")
addappid(1038710, 0, "66b82c976b026702533546a4ef71613301ddf2430dec580ffb269e25893c2479")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
