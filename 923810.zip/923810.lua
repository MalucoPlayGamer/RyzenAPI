-- Lua provided by RyzenAPI
-- Game: If My Heart Had Wings -Flight Diary-

-- MAIN APPLICATION
addappid(923810)
-- Game: addappid(923810)

-- MAIN APP DEPOTS / PACKAGES
addappid(923811, 1, "4c139a01907a4138844ea79e942c0e64ea3259d45d90d904620bef66c8e2fd49")
addappid(923812, 1, "e96f81161f1ebb4c22b00f35716881e17223d6e54c860d07f360940edc7dc2be")
addappid(1038710, 0, "66b82c976b026702533546a4ef71613301ddf2430dec580ffb269e25893c2479")
