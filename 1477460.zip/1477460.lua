-- Lua provided by RyzenAPI
-- Game: Game: Angels Pact: Reversal World

-- MAIN APPLICATION
addappid(1477460)
-- Game: addappid(1477460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477461, 1, "aef800c5cf2c0fa8cb3674ea9b204643226a994aed58d19440087f6c1d91e115")
