-- Lua provided by RyzenAPI
-- Game: AppID 1032090

-- MAIN APPLICATION
addappid(1032090)
-- Game: addappid(1032090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032091, 1, "f01e0bc2b5582f774d1d2e7ce96359d953200ab8b2892e2d3e787a2311f5779b")
