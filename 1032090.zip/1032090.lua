-- Lua provided by RyzenAPI
-- Game: AppID 1032090

-- MAIN APPLICATION
addappid(1032090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1032091, 1, "f01e0bc2b5582f774d1d2e7ce96359d953200ab8b2892e2d3e787a2311f5779b")

