-- Lua provided by RyzenAPI
-- Game: AppID 1093330

-- MAIN APPLICATION
addappid(1093330)
addappid(1109850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093331, 1, "b557d2cebbb434ffdf02c47865bb4bf1762f23a056d9756a8f2da3e42c0de1e4")

