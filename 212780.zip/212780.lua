-- Lua provided by RyzenAPI
-- Game: New Star™ Soccer 5

-- MAIN APPLICATION
addappid(212780)

-- MAIN APP DEPOTS / PACKAGES
addappid(212781, 1, "1a4b954bce1b7a598b1719dc13d23be18d4eadde2d145b14b2f264d80acdfce6")
addappid(212782, 1, "104b8b7eceb2cd2e38c1d90fb36d5bd3b2cdca030a377a4a8adcd6020af5eef8")

