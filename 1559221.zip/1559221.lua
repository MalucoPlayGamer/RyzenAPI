-- Lua provided by RyzenAPI
-- Game: 1559221

-- MAIN APPLICATION
addappid(1559221)
-- Game: addappid(1559221)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559221,0,"37de2ba41a8b25af6d986915fbd6500460fa8467e37f02841f88aef3133df870")
