-- Lua provided by RyzenAPI
-- Game: 593100

-- MAIN APPLICATION
addappid(593100)
-- Game: addappid(593100)

-- MAIN APP DEPOTS / PACKAGES
addappid(593101, 1, "d7cd74fbb418640121c03233ac97cc436dac530b6391c316fd23c752704faa92")
