-- Lua provided by RyzenAPI
-- Game: Radiant Crusade

-- MAIN APPLICATION
addappid(613850)

-- MAIN APP DEPOTS / PACKAGES
addappid(613851,0,"ca81b1b0a3ae5ae581a6ea615499a41a2804f68d23c7509d5c881e8e81b235f4")

