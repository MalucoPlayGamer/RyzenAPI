-- Lua provided by RyzenAPI
-- Game: Radiant Crusade

-- MAIN APPLICATION
addappid(613850)

-- MAIN APP DEPOTS / PACKAGES
addappid(613851,0,"ca81b1b0a3ae5ae581a6ea615499a41a2804f68d23c7509d5c881e8e81b235f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
