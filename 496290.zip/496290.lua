-- Lua provided by SkyAPI 
-- Game: Deep Dark Dungeon
addappid(496290)
addappid(496291, 1, "64f8c67f10a93d09126dae0025532e659cfc32f9b75feb2462d7c7174d5213ba")
addappid(496292, 1, "cbcd8da9422e88da527a1dd3a20bb66b848365e692d0511e4628f109a8c73763")
addappid(629980)
