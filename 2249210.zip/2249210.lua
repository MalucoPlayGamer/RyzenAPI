-- Lua provided by RyzenAPI
-- Game: Heavenly Peaks Cultivation

-- MAIN APPLICATION
addappid(2249210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249211, 1, "d3d0e485b9c160bd5f07b29c8682316c62a2fe4e38a0f9e6baa4075334bb080a")

