-- Lua provided by RyzenAPI
-- Game: Painting VR

-- MAIN APPLICATION
addappid(1905940)
-- Game: addappid(1905940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905941, 1, "d8c0e303bc1738d4015c11ac8d6217ce4fcb68ad35f7555872f7a5802dc5118a")
