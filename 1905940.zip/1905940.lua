-- Lua provided by RyzenAPI
-- Game: Painting VR

-- MAIN APPLICATION
addappid(1905940)
addappid(2891340)
addappid(3114580)
addappid(3213140)
addappid(3976800)
addappid(3978740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905941, 1, "d8c0e303bc1738d4015c11ac8d6217ce4fcb68ad35f7555872f7a5802dc5118a")

