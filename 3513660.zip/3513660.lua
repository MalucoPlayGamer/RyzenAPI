-- Lua provided by RyzenAPI
-- Game: STEAM-HEART'S Saturn Tribute Yumeiro Tsushin Extra issue ver.SH

-- MAIN APPLICATION
addappid(3513660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3513661, 1, "618a0cb4cdc71a191c47c470d7060e6b87a39684bca6fe89a4bed00ab772a285")
