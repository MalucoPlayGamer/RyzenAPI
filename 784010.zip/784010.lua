-- Lua provided by RyzenAPI
-- Game: 784010

-- MAIN APPLICATION
addappid(784010)
-- Game: addappid(784010)

-- MAIN APP DEPOTS / PACKAGES
addappid(784011, 1, "2e201e35b9cb792b233cc36778a1fb8bf7666104e517ca9d05ea9280e2bc1b1d")
