-- Lua provided by RyzenAPI
-- Game: Game of Lust

-- MAIN APPLICATION
addappid(1702670)
-- Game: addappid(1702670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702671, 1, "014b60600ed663f399479cb97baa555d37d817f067219513082ed8dbbe712e9d")
