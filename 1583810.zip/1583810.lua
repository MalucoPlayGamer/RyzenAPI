-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - EVFX Sanctuary

-- MAIN APPLICATION
addappid(1583810)
-- Game: addappid(1583810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583810,0,"f28a43fe5427f2d13e989f380d7461dc375020b109d88d6f134b7d63451b7d34")
