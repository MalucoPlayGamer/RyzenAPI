-- Lua provided by RyzenAPI
-- Game: 法医探案团之碎嘴小诗

-- MAIN APPLICATION
addappid(3128570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3128571, 1, "f9570382bc6e398c8c6a6871d3672a14212c5391c71d5438e6c3396364404cae")

