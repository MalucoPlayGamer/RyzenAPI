-- Lua provided by RyzenAPI
-- Game: 1079210

-- MAIN APPLICATION
addappid(1079210)
-- Game: addappid(1079210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079211, 1, "b66b4d48ca7dd7c86b002e9f7e6d95db926a5306ed4f5b3aa9c5cc8458480ebe")
