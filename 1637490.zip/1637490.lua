-- Lua provided by RyzenAPI
-- Game: Alone on Mars

-- MAIN APPLICATION
addappid(1637490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637491, 1, "59657277c511e001f3097e19a622d9936dc563339463ac7b55ac915dab886ab8")

