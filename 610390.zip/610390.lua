-- Lua provided by RyzenAPI 
-- Game: AppID 610390
addappid(610390)
addappid(610391, 1, "728ec4e1309b294555a9200884aaa61e40f02c804b1c6cc69a0ed934594d0bd3")
