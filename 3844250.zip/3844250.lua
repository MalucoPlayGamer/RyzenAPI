-- Lua provided by RyzenAPI
-- Game: Game: AppID 3844250

-- MAIN APPLICATION
addappid(3844250)
-- Game: addappid(3844250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3844251, 1, "21ce0b288d71848aeb4967548873db4023de065d026c448c1f28ce326ea2d114")
