-- Lua provided by RyzenAPI
-- Game: addappid(2399080)

-- MAIN APPLICATION
addappid(2399080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399081, 1, "f293152b003ee0dfbed22e9f267175f1ef95d9ba2a6d9386a273f5a97d2359f7")
