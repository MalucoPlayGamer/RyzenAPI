-- Lua provided by RyzenAPI
-- Game: Game: AppID 480770

-- MAIN APPLICATION
addappid(480770)
-- Game: addappid(480770)

-- MAIN APP DEPOTS / PACKAGES
addappid(480771, 1, "c70eb554c86729c3972e15b9c2cf814e40c1ca8f77783bad2ff8a42d88d1f1b2")
