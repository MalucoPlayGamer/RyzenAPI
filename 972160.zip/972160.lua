-- Lua provided by RyzenAPI
-- Game: Game: AppID 972160

-- MAIN APPLICATION
addappid(972160)
-- Game: addappid(972160)

-- MAIN APP DEPOTS / PACKAGES
addappid(972161, 1, "a77ed090ae1a637858712641d654312c589bf467e445ba4472309dcfd2b7c17e")
