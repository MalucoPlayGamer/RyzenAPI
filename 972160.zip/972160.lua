-- Lua provided by RyzenAPI
-- Game: The Witch's Love Diary

-- MAIN APPLICATION
addappid(972160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(972161, 1, "a77ed090ae1a637858712641d654312c589bf467e445ba4472309dcfd2b7c17e")
