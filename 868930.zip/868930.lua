-- Lua provided by RyzenAPI
-- Game: Nobunaga's Shadow

-- MAIN APPLICATION
addappid(868930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(868931, 1, "973c37e8b7e255d769f082d7e8ec50f52118492492686ee4ff7be8219972de35")
