-- Lua provided by RyzenAPI
-- Game: AppID 868930

-- MAIN APPLICATION
addappid(868930)
-- Game: addappid(868930)

-- MAIN APP DEPOTS / PACKAGES
addappid(868931, 1, "973c37e8b7e255d769f082d7e8ec50f52118492492686ee4ff7be8219972de35")
