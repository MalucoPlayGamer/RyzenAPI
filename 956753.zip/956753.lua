-- Lua provided by RyzenAPI
-- Game: addappid(956753)

-- MAIN APPLICATION
addappid(956753)

-- MAIN APP DEPOTS / PACKAGES
addappid(956753,0,"1bc8ada9d3ed0c04b1bc4dd4f7ee9eba1acfc4ad522596731e2e6e632a9d3c00")
