-- Lua provided by RyzenAPI
-- Game: Battle of the Bulge

-- MAIN APPLICATION
addappid(365560)
-- Game: addappid(365560)

-- MAIN APP DEPOTS / PACKAGES
addappid(365561, 1, "31d6e17bbdc871922f1c75361de8ceccd72be72b15793b29e363549b711180cf")
