-- Lua provided by RyzenAPI
-- Game: AppID 302240

-- MAIN APPLICATION
addappid(302240)
-- Game: addappid(302240)

-- MAIN APP DEPOTS / PACKAGES
addappid(302241, 1, "e6959f0725b02dd81e519e729702ded7bae56f8927798da886608118128c5aa7")
