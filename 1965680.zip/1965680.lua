-- Lua provided by RyzenAPI
-- Game: Game: HopDodge

-- MAIN APPLICATION
addappid(1965680)
-- Game: addappid(1965680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965681, 1, "b9f1432168482db3a1f7dbee622244e444ac276711f144a92b847cc2f2f4ea50")
