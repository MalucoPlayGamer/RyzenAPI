-- Lua provided by RyzenAPI
-- Game: Discs of Steel Party

-- MAIN APPLICATION
addappid(859660)

-- MAIN APP DEPOTS / PACKAGES
addappid(859661,0,"b526ead8bfc432cde68cf3b4ef9bbec4ad79999fa3daaf00d463251fcc0ba3c6")

