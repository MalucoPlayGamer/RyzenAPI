-- Lua provided by RyzenAPI
-- Game: The Undergrounders

-- MAIN APPLICATION
addappid(3364120)
-- Game: addappid(3364120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3364121, 1, "6a7c9c9232bad3cd06a0470b15c4d0c02d76986b63ab02f4009fd1a94f638c2b")
