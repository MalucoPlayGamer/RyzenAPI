-- Lua provided by RyzenAPI
-- Game: The Undergrounders

-- MAIN APPLICATION
addappid(3364120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3364121, 1, "6a7c9c9232bad3cd06a0470b15c4d0c02d76986b63ab02f4009fd1a94f638c2b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
