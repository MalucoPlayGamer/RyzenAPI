-- Lua provided by RyzenAPI
-- Game: Island Paradise

-- MAIN APPLICATION
addappid(2392400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392401, 1, "4f4c4219b2f7f11b31aa32ae417fb569c06f00549caaa80b4341d008d37d2ad1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
