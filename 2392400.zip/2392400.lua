-- Lua provided by RyzenAPI
-- Game: 2392400

-- MAIN APPLICATION
addappid(2392400)
-- Game: addappid(2392400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392401, 1, "4f4c4219b2f7f11b31aa32ae417fb569c06f00549caaa80b4341d008d37d2ad1")
