-- Lua provided by RyzenAPI
-- Game: Station 5

-- MAIN APPLICATION
addappid(2735060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2735061, 1, "831dba296794e9d3a8803fd40878e0585633f67e705d94d8f84c7f134f123c86")

