-- Lua provided by RyzenAPI
-- Game: Exoprimal

-- MAIN APPLICATION
addappid(1286320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286321, 1, "7dca2ec4a3b1293b6a3230145715e7624d9462d28ca25665190baa0cc05ba160")
