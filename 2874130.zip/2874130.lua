-- Lua provided by RyzenAPI 
-- Game: Berserk or Die
addappid(2874130)
addappid(2874131, 1, "5ec5d7cebcd47f39bda56d4344f939d79aa357ed7fb5cdeb6b5b16ceaf539c94")
