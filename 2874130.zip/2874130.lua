-- Lua provided by RyzenAPI
-- Game: 2874130

-- MAIN APPLICATION
addappid(2874130)
-- Game: addappid(2874130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2874131, 1, "5ec5d7cebcd47f39bda56d4344f939d79aa357ed7fb5cdeb6b5b16ceaf539c94")
