-- Lua provided by RyzenAPI
-- Game: The Last Hero of Nostalgaia Demo

-- MAIN APPLICATION
addappid(1993490)
-- Game: addappid(1993490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993491, 1, "91928ab1ce721bbbc5ab3d989e956e18791d8e94354894e3ab9010c888b2911b")
