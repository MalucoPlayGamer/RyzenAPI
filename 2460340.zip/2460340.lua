-- Lua provided by RyzenAPI
-- Game: AppID 2460340

-- MAIN APPLICATION
addappid(2460340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460341, 1, "3c41c163fa29e6f3c16773ee9e61e41dd37db4dd672dfcdd0474ff7ae039820c")
