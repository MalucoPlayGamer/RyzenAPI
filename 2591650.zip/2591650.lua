-- Lua provided by RyzenAPI
-- Game: Cuisineer - Artbook

-- MAIN APPLICATION
addappid(2591650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591650,0,"ac8aa054da9f69b8af5ee1fc8d333d2704fb096c1dc952d1e3294702d390d7ba")
