-- Lua provided by RyzenAPI
-- Game: Game: AppID 932870

-- MAIN APPLICATION
addappid(932870)
-- Game: addappid(932870)

-- MAIN APP DEPOTS / PACKAGES
addappid(932871, 1, "4eedf77766644e824103c4c0af2c08b657a77d8ebf3249ed1786fc7c4241104a")
