-- Lua provided by SkyAPI 
-- Game: AppID 932870
addappid(932870)
addappid(932871, 1, "4eedf77766644e824103c4c0af2c08b657a77d8ebf3249ed1786fc7c4241104a")
