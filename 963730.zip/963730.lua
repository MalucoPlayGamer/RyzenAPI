-- Lua provided by RyzenAPI
-- Game: It Lurks! A Noir Horror RPG.

-- MAIN APPLICATION
addappid(963730)

-- MAIN APP DEPOTS / PACKAGES
addappid(963731, 1, "fffd52eb4ad02e26d6d8ff6be842b71c1482de455bf68a927aae7b158bc80d07")

