-- Lua provided by RyzenAPI
-- Game: Something To Write About: Unbroken: Book One

-- MAIN APPLICATION
addappid(3338660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3338661, 1, "d26eb638b1e94e361d6d07cc67b269cb882d6e67e2fb2e5cae16e414ff01acb2")
