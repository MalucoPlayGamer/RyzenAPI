-- Lua provided by RyzenAPI
-- Game: MekaFighters

-- MAIN APPLICATION
addappid(958670)

-- MAIN APP DEPOTS / PACKAGES
addappid(976511,0,"977157138bc895138f8c393859d8006eafa5a3259148566adfaff7cd52967ed5")

