-- Lua provided by RyzenAPI
-- Game: MekaFighters

-- MAIN APPLICATION
addappid(958670)
addappid(1893720)
addappid(1893721)
addappid(1893740)
addappid(1893741)
addappid(1893742)
addappid(1893744)
addappid(1893745)
addappid(1893746)
addappid(1893747)
addappid(1893748)
addappid(1893749)
addappid(1893760)
addappid(1893761)
addappid(1893762)
addappid(1893764)
addappid(1893765)
addappid(1893766)
addappid(1893767)
addappid(1893769)
addappid(1893780)
addappid(1893781)
addappid(1893782)
addappid(1893783)
addappid(1893784)
addappid(1893785)
addappid(1893786)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(976511,0,"977157138bc895138f8c393859d8006eafa5a3259148566adfaff7cd52967ed5")

