-- Lua provided by RyzenAPI
-- Game: 399720

-- MAIN APPLICATION
addappid(399720)
-- Game: addappid(399720)

-- MAIN APP DEPOTS / PACKAGES
addappid(399721, 1, "c50df04976a697e1bf3b3edbaa50fe46dae9134e0d22d7ef381e6ca8524119ac")
