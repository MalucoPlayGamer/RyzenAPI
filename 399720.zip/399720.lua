-- Lua provided by RyzenAPI
-- Game: XO

-- MAIN APPLICATION
addappid(399720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(399721, 1, "c50df04976a697e1bf3b3edbaa50fe46dae9134e0d22d7ef381e6ca8524119ac")

