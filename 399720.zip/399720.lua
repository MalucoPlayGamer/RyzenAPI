-- Lua provided by RyzenAPI 
-- Game: XO
addappid(399720)
addappid(399721, 1, "c50df04976a697e1bf3b3edbaa50fe46dae9134e0d22d7ef381e6ca8524119ac")
