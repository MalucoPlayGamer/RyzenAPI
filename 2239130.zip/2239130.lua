-- Lua provided by SkyAPI 
-- Game: AppID 2239130
addappid(2239130)
addappid(2239131, 1, "3c515e3bacdab3c6b9f4d2f6b931323a91bb716431e023ca05b0f66607e9f68e")
