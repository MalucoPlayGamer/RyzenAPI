-- Lua provided by RyzenAPI
-- Game: 2239130

-- MAIN APPLICATION
addappid(2239130)
-- Game: addappid(2239130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2239131, 1, "3c515e3bacdab3c6b9f4d2f6b931323a91bb716431e023ca05b0f66607e9f68e")
