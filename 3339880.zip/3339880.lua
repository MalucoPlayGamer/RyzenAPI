-- Lua provided by RyzenAPI
-- Game: OFF

-- MAIN APPLICATION
addappid(3339880)
-- Game: addappid(3339880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339881, 1, "b732299b6e450bca3e311e71d4c18bff5bc825566f0b6a76f010019e1a96bfc3")
