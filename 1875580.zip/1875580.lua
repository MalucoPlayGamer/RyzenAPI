-- Lua provided by RyzenAPI
-- Game: AppID 1875580

-- MAIN APPLICATION
addappid(1875580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875581, 1, "4b564e5c98b9b3813becf9cce3759f649a5c9f1a912f49aa1b003e4378674428")
addappid(1875582, 1, "413c4c1b115d4862272593db196e15a8a03b03761b8d10ba98fa2b4ebb68a196")
addappid(1875583, 1, "8d37117d10114689d88f20ef82ae628d49b1d835148bc1849f020693931cd91e")
addappid(1875584, 1, "a6d9cec62ca9a286f40d7acc0b27719153b579f9bd2b7b52e2653eca8a8d2321")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
