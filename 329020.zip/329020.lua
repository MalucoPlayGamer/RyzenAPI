-- Lua provided by RyzenAPI
-- Game: Battlegrounds of Eldhelm

-- MAIN APPLICATION
addappid(329020)

-- MAIN APP DEPOTS / PACKAGES
addappid(329021, 1, "759da763ec9b514fe54360f80ec1566300794d6d4680db3db316f8de4a60f541")
