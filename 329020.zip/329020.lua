-- Lua provided by RyzenAPI
-- Game: Game: AppID 329020

-- MAIN APPLICATION
addappid(329020)
-- Game: addappid(329020)

-- MAIN APP DEPOTS / PACKAGES
addappid(329021, 1, "759da763ec9b514fe54360f80ec1566300794d6d4680db3db316f8de4a60f541")
