-- Lua provided by RyzenAPI
-- Game: addappid(1082930)

-- MAIN APPLICATION
addappid(1082930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082931, 1, "553e921b25e671919b403d536245861ee14d6ac6a3ba68fd3a9165eba981b2df")
