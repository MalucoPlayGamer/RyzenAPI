-- Lua provided by RyzenAPI
-- Game: Grappling Gunners: Arena FPS

-- MAIN APPLICATION
addappid(2652750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2652751, 1, "270fde28a2e3ac2f421d9a1880027b6a426aa70212edba3c2488dfe1d7040ec8")

