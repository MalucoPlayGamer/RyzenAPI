-- Lua provided by RyzenAPI
-- Game: Grappling Gunners: Arena FPS

-- MAIN APPLICATION
addappid(2652750)
-- Game: addappid(2652750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2652751, 1, "270fde28a2e3ac2f421d9a1880027b6a426aa70212edba3c2488dfe1d7040ec8")
