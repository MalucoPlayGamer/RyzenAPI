-- Lua provided by RyzenAPI
-- Game: The Forgotten Village of Gondomayit

-- MAIN APPLICATION
addappid(2589820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2589821, 1, "645d3cf9c7e24c84f861e22bfc2f93554967af472c63d347ff3fac12c4819f4c")

