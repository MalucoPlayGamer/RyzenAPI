-- Lua provided by RyzenAPI
-- Game: The Forgotten Village of Gondomayit

-- MAIN APPLICATION
addappid(2589820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589821, 1, "645d3cf9c7e24c84f861e22bfc2f93554967af472c63d347ff3fac12c4819f4c")
