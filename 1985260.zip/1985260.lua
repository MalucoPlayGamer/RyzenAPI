-- Lua provided by RyzenAPI
-- Game: addappid(1985260)

-- MAIN APPLICATION
addappid(1985260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985261, 1, "f9a771a15d6886dfa12afffeb17d359f054566f486696ab291ce032a6c1b9ef4")
