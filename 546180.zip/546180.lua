-- Lua provided by RyzenAPI
-- Game: Starry Nights : Helix

-- MAIN APPLICATION
addappid(546180)

-- MAIN APP DEPOTS / PACKAGES
addappid(546181, 1, "ef9777f922228848cb53c60fc618b1bc99008de5e2bf9a2eb30b1b1906ecd80f")
