-- Lua provided by RyzenAPI
-- Game: Game: The Complex

-- MAIN APPLICATION
addappid(1107790)
-- Game: addappid(1107790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107791, 1, "f2b8fb872084651bfba73537b78e56c11014f716d6b79d79dd48cbfd02619cf3")
addappid(1107792, 1, "65b2699a4be79b6af4a7cebd6b38225f7414955726aedbd706728adeb7995466")
addappid(1107793, 1, "5723490a7e214e8897ac622ebbd2e0d9a20c65f0965f7be4cf9c7b0d8931d542")
addappid(1107794, 1, "176ba1e220cd1ab43b4cb5c8d53a26d2ae372a878b86f14db1edf02747e68a3d")
