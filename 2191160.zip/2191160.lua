-- Lua provided by RyzenAPI 
-- Game: BOWLOUT
addappid(2191160)
addappid(2191161, 1, "1a2d1884392312fa32206c7313dfb8980b9100bf73f3b19648f13e32305911f8")
