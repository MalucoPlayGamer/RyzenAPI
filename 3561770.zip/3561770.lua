-- Lua provided by RyzenAPI
-- Game: Irudo

-- MAIN APPLICATION
addappid(3561770)
addappid(4650660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561771, 1, "7e348a4267151d68fa1b4bd51cab9d743124e9865d4dcb6f78728d5e40c14992")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
