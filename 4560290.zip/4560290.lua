-- Lua provided by RyzenAPI
-- Game: Sweet Dance

-- MAIN APPLICATION
addappid(4560290)
