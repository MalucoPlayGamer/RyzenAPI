-- Lua provided by RyzenAPI
-- Game: No Man's Home

-- MAIN APPLICATION
addappid(3626760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3626761,0,"662eefd4220218e7b048af2f50ed627a1a840f145f646bb3116f741a9c029c04")

