-- Lua provided by RyzenAPI 
-- Game: Furry Boys Jigsaw
addappid(1863700)
addappid(1863701, 1, "54578561c0d67aa62cd695d92b6a015eb9bc04eaf5e6ff743b1b370bd76ea24e")
