-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2864490)
-- Game: addappid(2864490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864490,0,"68048533b47368140ae441d9b452bc3e7fa1b770780fe8438693b1e968095365")
