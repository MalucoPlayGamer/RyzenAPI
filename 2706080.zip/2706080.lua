-- Lua provided by RyzenAPI
-- Game: United Penguin Kingdom Demo

-- MAIN APPLICATION
addappid(2706080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706081, 1, "4dd0e727425288068721afe25f00a6178fc9a783723fd48a4751131e83b4e6ea")
