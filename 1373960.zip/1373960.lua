-- Lua provided by RyzenAPI
-- Game: INDIKA

-- MAIN APPLICATION
addappid(1373960)
-- Game: addappid(1373960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373961, 1, "fa22d6df0c690d7d4a42377918c6b733be2f835f4372e79c8a021fee6df68849")
addappid(1373962, 1, "49d9fff6a7534e18846a8583110a2c9cc33c2fc63091fb91673af0bfcecfbc57")
addappid(2789960, 0, "7349caf1f5147ec22fdb7f3051c9edc2e16ccef2ac6c31946a64686b46ea7410")
