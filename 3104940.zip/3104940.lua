-- Lua provided by RyzenAPI
-- Game: 3104940

-- MAIN APPLICATION
addappid(3104940)
-- Game: addappid(3104940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3104941, 1, "2e5893d6dc0982e729c77a29cb84deaf4a4edf6a608904779241b8bff5b5c28d")
