-- Lua provided by RyzenAPI
-- Game: The Forever Winter

-- MAIN APPLICATION
addappid(2828860)
addappid(3651820)
addappid(3977550)
addappid(4266400)
addappid(4630200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2828861, 1, "e333c16789028087fd8925929beb0a6117f7fdb30559fa9f02677adfd32b076c")

