-- Lua provided by RyzenAPI
-- Game: The Forever Winter

-- MAIN APPLICATION
addappid(2828860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828861, 1, "e333c16789028087fd8925929beb0a6117f7fdb30559fa9f02677adfd32b076c")
