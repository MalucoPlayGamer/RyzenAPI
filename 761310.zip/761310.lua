-- Lua provided by RyzenAPI
-- Game: Game: AppID 761310

-- MAIN APPLICATION
addappid(761310)
-- Game: addappid(761310)

-- MAIN APP DEPOTS / PACKAGES
addappid(761311, 1, "3516b2a8a9862ffcf6efa17972997474e3aa79d2f74e00299174e91a3a3a536f")
