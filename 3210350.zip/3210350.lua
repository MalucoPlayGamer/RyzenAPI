-- Lua provided by RyzenAPI
-- Game: Vampire Survivors: Ode to Castlevania

-- MAIN APPLICATION
addappid(3210350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3210351, 1, "20bd752769ea846ec3f34122e7dd6f794271ddd9b92b26d40fff8ec626b96712")
addappid(3210352, 1, "06faab96cfe4d11f9039207877895bfc277af9fc1170a9aca3526a454b673f81")
addappid(3210353, 1, "742b108aa899a7b540833b12635802c7af80429baec59fda51e5872ea0bb0462")
