-- Lua provided by RyzenAPI 
-- Game: Richman 4
addappid(2059810)
addappid(2059811, 1, "0983030e8f908fed85c5ec47188a3a581f71177f6b4adc2c5a1428bcfcb99ef7")
addappid(2093880, 0, "456f773d5bf53a65fac881202e37944e1879c036963b5f006276b2eb92c239d6")
