-- Lua provided by RyzenAPI
-- Game: Vehicle VR

-- MAIN APPLICATION
addappid(648810)

-- MAIN APP DEPOTS / PACKAGES
addappid(648811, 1, "c6cb42dc7d6eb40fc595c779532da98d1e66013cd299825002139523bd3bef36")

