-- Lua provided by SkyAPI 
-- Game: Samorost 1
addappid(1580970)
addappid(1580971, 1, "ff2650c301bc0beb8d5f0ff37c37ae2f359018a769e8b33ccac1a5bb308ab627")
addappid(1580972, 1, "7511989c3e6314f08ac31df666f0685db37ae231dcabcff8a011b4c06b0e4401")
