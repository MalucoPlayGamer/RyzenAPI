-- Lua provided by RyzenAPI 
-- Game: Sloppy Fields
addappid(3409760)
addappid(3409761, 1, "e8df2ceb56e365d1936a53e2f4e8181e68e5831c932108c733f7ab2927c2ee83")
