-- Lua provided by RyzenAPI
-- Game: addappid(1431160)

-- MAIN APPLICATION
addappid(1431160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431160,0,"dbe2c2009d2eab8ced340c709e2ff3eb3039a27e48610a121d658b45c43f5063")
