-- Lua provided by RyzenAPI
-- Game: Cats Hidden in Bali Demo

-- MAIN APPLICATION
addappid(2449590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449591, 1, "142e1458c51e69fed6e1f02d9d98fb39d96e96e167a2fd82cbbb5731a70954b9")
