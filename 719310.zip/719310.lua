-- Lua provided by RyzenAPI
-- Game: King's Table - The Legend of Ragnarok

-- MAIN APPLICATION
addappid(719310)

-- MAIN APP DEPOTS / PACKAGES
addappid(719311, 1, "32415fc8185304b2d6271f9392dd82a27b16cce068f407cb74fc50a5496a91c1")
addappid(719312, 1, "2c4ca9149041d8cee664ff09881d935c4e9ecfa32c21a5722cb3d39adcec44fc")
addappid(719313, 1, "6b34dfc96dd929dde4911f32a097a5f16b94bdcc66426eff068463d561f16336")
addappid(719314, 1, "2d66abca831a612993c8e3ef5276a74167e676167a888bef7f5396ae5e071340")
addappid(719315, 1, "42287fdd8d1b4f73960157d3cb84abc1712d232214d4d37f66ccbddcf3d2de60")

