-- Lua provided by RyzenAPI
-- Game: Lakeview Cabin 1

-- MAIN APPLICATION
addappid(2458820)
-- Game: addappid(2458820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458821, 1, "81b9014ee3e1a53b223cd8204e9a1090f40849eaa8ced4d543dfab8846d9e44b")
