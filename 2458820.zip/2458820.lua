-- Lua provided by SkyAPI 
-- Game: Lakeview Cabin 1
addappid(2458820)
addappid(2458821, 1, "81b9014ee3e1a53b223cd8204e9a1090f40849eaa8ced4d543dfab8846d9e44b")
