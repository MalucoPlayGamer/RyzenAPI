-- Lua provided by SkyAPI 
-- Game: Bad cat Sam
addappid(2256230)
addappid(2256231, 1, "075ec69946d6236ce51d66a622ed0929347aeec2237b0c195a67654b61d80e95")
