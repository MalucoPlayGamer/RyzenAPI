-- Lua provided by RyzenAPI
-- Game: Bad cat Sam

-- MAIN APPLICATION
addappid(2256230)
-- Game: addappid(2256230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256231, 1, "075ec69946d6236ce51d66a622ed0929347aeec2237b0c195a67654b61d80e95")
