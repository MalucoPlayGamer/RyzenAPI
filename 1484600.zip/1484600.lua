-- Lua provided by RyzenAPI
-- Game: addappid(1484600)

-- MAIN APPLICATION
addappid(1484600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484601, 1, "94f771e92b2fc0571f5ca6c889612098fb583ca3b9ffea0a54017ec4e31a3c37")
