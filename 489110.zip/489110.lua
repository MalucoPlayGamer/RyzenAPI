-- Lua provided by RyzenAPI
-- Game: Putty Pals

-- MAIN APPLICATION
addappid(228990)
addappid(489110)
addappid(489111)
-- Game: addappid(489110)

-- MAIN APP DEPOTS / PACKAGES
addappid(489112,0,"99a2fa9e9344f0ba3b07d695f03c7ee3924f2261a26c09d530fc516c2f50b7d0")
addappid(489113,0,"bd36f4bdedd7af926c9886fa04a84033909f5dad8905b00a60338c1f99a1b415")
addappid(489114,0,"eca1d849815f6c78f5c5c42837b50c3833329ec699dab4f65a32aefaa4d578f8")
