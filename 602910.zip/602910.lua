-- Lua provided by RyzenAPI 
-- Game: One Wish
addappid(602910)
addappid(602911, 1, "17d18c7f50820f0dd18e405ec91704fa82e90334e0f4e0ad6bac9f719181a4fd")
