-- Lua provided by RyzenAPI
-- Game: Game: Lizard Slayer

-- MAIN APPLICATION
addappid(2984230)
-- Game: addappid(2984230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984231, 1, "8e065451c1296e7e4f4ec0eb2f545b3633222b5261992603da8caa777ed92a28")
