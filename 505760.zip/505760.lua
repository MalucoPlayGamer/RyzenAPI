-- Lua provided by RyzenAPI
-- Game: Whispers

-- MAIN APPLICATION
addappid(505760)

-- MAIN APP DEPOTS / PACKAGES
addappid(505761, 1, "68c291045051c147e19f8933ef88b5fc5bf033842364f1cb3b1d9bdd8bd7d071")
addappid(505762, 1, "85eb6e30fbe6db2fc1719aabead8a99485f7c3123573ddfb4fed199c80791bd7")

