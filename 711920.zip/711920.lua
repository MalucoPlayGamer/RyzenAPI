-- Lua provided by RyzenAPI
-- Game: Detective Case and Clown Bot in: The Express Killer

-- MAIN APPLICATION
addappid(711920)

-- MAIN APP DEPOTS / PACKAGES
addappid(711921, 1, "56213e604e50029f575a31758ebeb1a90cb23656718c9d9b1042140a10a5bf7e")
addappid(715390, 0, "ef16afa961f8acaa6149868bfa8916214e8d2d26e1e658d8a7823e09c45e0153")

