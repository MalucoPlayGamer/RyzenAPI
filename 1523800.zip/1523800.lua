-- Lua provided by RyzenAPI
-- Game: Mighty Forest

-- MAIN APPLICATION
addappid(1523800)
-- Game: addappid(1523800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523801, 1, "1f06c4c37e9ba439b6334bc022419e6f1d82ae5900424476f58dfb3dbd14324c")
