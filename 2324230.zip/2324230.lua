-- Lua provided by RyzenAPI
-- Game: Project Liminal Redux

-- MAIN APPLICATION
addappid(2324230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324231, 1, "6dc517b7b64ac4b517c86a6c9be4bd12bb767833cff0044238b82114d6e79727")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
