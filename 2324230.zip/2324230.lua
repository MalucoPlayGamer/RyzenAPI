-- Lua provided by RyzenAPI
-- Game: addappid(2324230)

-- MAIN APPLICATION
addappid(2324230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324231, 1, "6dc517b7b64ac4b517c86a6c9be4bd12bb767833cff0044238b82114d6e79727")
