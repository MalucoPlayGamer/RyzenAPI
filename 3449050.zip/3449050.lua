-- Lua provided by RyzenAPI
-- Game: 3449050

-- MAIN APPLICATION
addappid(3449050)
-- Game: addappid(3449050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3449051, 1, "92827aa1132161e09de64b04b51fe0c86978a48f9ee30f3e175c57786a7b35eb")
