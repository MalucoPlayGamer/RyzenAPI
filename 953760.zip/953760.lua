-- Lua provided by RyzenAPI
-- Game: Game: Gravity Spin

-- MAIN APPLICATION
addappid(953760)
-- Game: addappid(953760)

-- MAIN APP DEPOTS / PACKAGES
addappid(953761, 1, "7ca7b9c54e33914bdc9efdfcad0e821f6d923835ade0aae5f99d60f8211a83d3")
