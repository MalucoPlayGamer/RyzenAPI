-- Lua provided by RyzenAPI
-- Game: Her New Memory - Hentai Simulator

-- MAIN APPLICATION
addappid(1296770)
addappid(1988620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1296771, 1, "ebeadb87d544a26505a8ea7dc5469440bc6dd4955e4b6f9ac5ac5e8cadb50d62")

