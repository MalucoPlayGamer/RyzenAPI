-- Lua provided by RyzenAPI
-- Game: Her New Memory - Hentai Simulator

-- MAIN APPLICATION
addappid(1296770)
addappid(1988620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296771, 1, "ebeadb87d544a26505a8ea7dc5469440bc6dd4955e4b6f9ac5ac5e8cadb50d62")
