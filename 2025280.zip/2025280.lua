-- Lua provided by RyzenAPI
-- Game: addappid(2025280)

-- MAIN APPLICATION
addappid(2025280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025281, 1, "ae5fd05290bee8ede94e89b84d7a00dc09f2ef5e35d94b9a084a5b24c01aab78")
