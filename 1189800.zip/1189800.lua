-- Lua provided by RyzenAPI
-- Game: Bleeding Edge

-- MAIN APPLICATION
addappid(1189800)
addappid(1189840)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1189801, 1, "c4f55177ff1d26905371a7bc54f14321e8404c1c100823e3816003a39228aac5")

