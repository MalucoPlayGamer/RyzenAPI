-- Lua provided by RyzenAPI
-- Game: Game: Bleeding Edge

-- MAIN APPLICATION
addappid(1189800)
addappid(1189840)
-- Game: addappid(1189800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189801, 1, "c4f55177ff1d26905371a7bc54f14321e8404c1c100823e3816003a39228aac5")
