-- Lua provided by SkyAPI 
-- Game: Bleeding Edge
addappid(1189800)
addappid(1189801, 1, "c4f55177ff1d26905371a7bc54f14321e8404c1c100823e3816003a39228aac5")
addappid(1189840)
