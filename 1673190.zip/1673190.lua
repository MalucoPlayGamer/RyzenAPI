-- Lua provided by RyzenAPI
-- Game: Game: Bahamut2-dragon's bride

-- MAIN APPLICATION
addappid(1673190)
-- Game: addappid(1673190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673191, 1, "75c6d5f7828956c11fa41dbb3c0f5c53eb5622154bbaf623766aee436c7292f3")
addappid(1673192, 1, "048158686aa59345e50a63b01de625e02430e59d533a9491a88dca5fa4236a82")
addappid(1673195, 1, "9d82a5f08fb3c9bdb47a698b6c29891392448bab20be52bf72e14cc7c4f07115")
addappid(1673197, 1, "27e45281de3cc74261cd1df99f16c185d13a6504174b9faeb110efd1e8d6af6e")
