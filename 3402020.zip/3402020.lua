-- Lua provided by RyzenAPI
-- Game: Sexy Furry - Deer Furry DLC

-- MAIN APPLICATION
addappid(3402020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402020,0,"05ce7d9771a7652ba041aa09a3f11ecd0c8cc4af19764cd1adc88d4822bfca37")

