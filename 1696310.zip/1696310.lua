-- Lua provided by RyzenAPI
-- Game: Starveling Way

-- MAIN APPLICATION
addappid(1696310)
-- Game: addappid(1696310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696311, 1, "76c1cda0d1f321c483fc398c286bc8154adcd3cc0fd2201a68b9a9d00f7cd383")
