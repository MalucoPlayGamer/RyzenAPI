-- Lua provided by SkyAPI 
-- Game: Wildcard Playtest
addappid(3509620)
addappid(3509621, 1, "3750c3f467f435d10ed73d8874ec4281451800f3979304fb67990d134009bcb0")
