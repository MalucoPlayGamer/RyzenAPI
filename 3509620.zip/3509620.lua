-- Lua provided by RyzenAPI
-- Game: Wildcard Playtest

-- MAIN APPLICATION
addappid(3509620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3509621, 1, "3750c3f467f435d10ed73d8874ec4281451800f3979304fb67990d134009bcb0")

