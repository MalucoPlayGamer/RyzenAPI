-- Lua provided by RyzenAPI
-- Game: 我的文字修仙世界

-- MAIN APPLICATION
addappid(4226370)

