-- Lua provided by RyzenAPI
-- Game: Drums Rock

-- MAIN APPLICATION
addappid(1906020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906021, 1, "71625ccc26c54523aca402bba21808bb3473b5fe3428f415a43052c54335af7a")
