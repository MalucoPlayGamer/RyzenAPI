-- Lua provided by RyzenAPI
-- Game: addappid(756600)

-- MAIN APPLICATION
addappid(756600)

-- MAIN APP DEPOTS / PACKAGES
addappid(756601, 1, "dc6b98608f5a6bc2c5a73f2e702483420b0fcedce587cbc1126270607db9779d")
