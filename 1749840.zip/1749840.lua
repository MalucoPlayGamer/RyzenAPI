-- Lua provided by RyzenAPI
-- Game: 二狗子历险记

-- MAIN APPLICATION
addappid(1749840)
-- Game: addappid(1749840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749841, 1, "58fd9fb21fcf001ae9274ff056d17d7becb49565e43e07ed4ec7a84f6a20a12d")
