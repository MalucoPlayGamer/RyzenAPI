-- Lua provided by SkyAPI 
-- Game: Score the Fear
addappid(3500750)
addappid(3500751, 1, "a78c222203dce1b96f629a58df15b5bbc4374005221321a9c547a7542f19ffd0")
