-- Lua provided by RyzenAPI
-- Game: Score the Fear

-- MAIN APPLICATION
addappid(3500750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3500751, 1, "a78c222203dce1b96f629a58df15b5bbc4374005221321a9c547a7542f19ffd0")

