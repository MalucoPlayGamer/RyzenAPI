-- Lua provided by RyzenAPI
-- Game: Overlook Trail

-- MAIN APPLICATION
addappid(817800)

-- MAIN APP DEPOTS / PACKAGES
addappid(817801,0,"919c248eb5a9111e764aeb2a3c844bf9cfce5b39b4547f9b4e4749f31449369b")

