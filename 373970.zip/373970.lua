-- Lua provided by RyzenAPI
-- Game: Letter Quest: Grimm's Journey Remastered

-- MAIN APPLICATION
addappid(373970)

-- MAIN APP DEPOTS / PACKAGES
addappid(373971, 1, "b68e37dbe1451040dbce4c82c7125460249cfa2823e50056ee9760f42114954b")
addappid(373972, 1, "3db1b56d7f972f95d6d836ec5125229f885bfe2a4f825646b7660db37fda6478")
addappid(373973, 1, "8df5bd072cb34575184f3cfd460db46e1cedc6b5629e7f4b38ea761ed05625bc")
