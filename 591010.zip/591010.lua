-- Lua provided by RyzenAPI
-- Game: Game: AppID 591010

-- MAIN APPLICATION
addappid(591010)
-- Game: addappid(591010)

-- MAIN APP DEPOTS / PACKAGES
addappid(591011, 1, "36f77f2661252f848d96871da366f8eeb95205dc91f0d1e358b28407f5cae7c2")
