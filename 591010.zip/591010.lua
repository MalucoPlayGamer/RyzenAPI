-- Lua provided by SkyAPI 
-- Game: AppID 591010
addappid(591010)
addappid(591011, 1, "36f77f2661252f848d96871da366f8eeb95205dc91f0d1e358b28407f5cae7c2")
