-- Lua provided by RyzenAPI
-- Game: Pipe Escape

-- MAIN APPLICATION
addappid(2835410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2835411, 1, "91b0ff125cffdf2df727ebe7d0f3a89e0ce02cae6bd4ea2f5f58b80d0019bbbd")
