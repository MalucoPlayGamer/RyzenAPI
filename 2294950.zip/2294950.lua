-- Lua provided by RyzenAPI
-- Game: Kill The Cute

-- MAIN APPLICATION
addappid(2294950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294951, 1, "6d0af90b0bd63e44842d2025924641f0ae4b56973b3761114a08c27eaa1410f9")
