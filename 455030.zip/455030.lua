-- Lua provided by RyzenAPI
-- Game: Save the Dodos! Soundtrack

-- MAIN APPLICATION
addappid(455030)

-- MAIN APP DEPOTS / PACKAGES
addappid(455030,0,"708083e1af2fbc7d3a4552d3b3dfb1cf2ae0c80de757618dad5baf91c445f449")
