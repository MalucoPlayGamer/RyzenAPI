-- Lua provided by RyzenAPI 
-- Game: CONTORTED
addappid(2575120)
addappid(2575121, 1, "3eb65eb0dd319c4731c7817c83e3ef155f6adf66741b9d8402cf28b6d8cfea6d")
