-- Lua provided by RyzenAPI
-- Game: StarbaseSim

-- MAIN APPLICATION
addappid(3333060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333061, 1, "946458da0792ff578e012f377ddc27825e89aa94ecbfc03ced93d7bf1bd11e9b")

