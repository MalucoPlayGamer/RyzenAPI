-- Lua provided by RyzenAPI
-- Game: StarbaseSim

-- MAIN APPLICATION
addappid(3333060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333061, 1, "946458da0792ff578e012f377ddc27825e89aa94ecbfc03ced93d7bf1bd11e9b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
