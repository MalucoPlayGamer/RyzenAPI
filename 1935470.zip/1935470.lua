-- Lua provided by RyzenAPI
-- Game: The Tales of Bayun

-- MAIN APPLICATION
addappid(1935470)
-- Game: addappid(1935470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935471, 1, "805a73c53205586b640abcdb7af078778524d369fd31be407596ec136c9ccc9e")
