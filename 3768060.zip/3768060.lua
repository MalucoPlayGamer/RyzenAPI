-- Lua provided by RyzenAPI
-- Game: Game: Happy Piggy 2

-- MAIN APPLICATION
addappid(3768060)
-- Game: addappid(3768060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3768061, 1, "ada3b4b549c90e53103492a87f86846fdcf19a00b3a439abdcda26d89daf5238")
