-- Lua provided by SkyAPI 
-- Game: Third World: The Bottom Dimension
addappid(2154250)
addappid(2154251, 1, "63d1ef7c2a32993dbe98f961a0cb957d03a7d9c0ea1fdbc6ea54337bd58ad6d2")
