-- Lua provided by RyzenAPI
-- Game: 2154250

-- MAIN APPLICATION
addappid(2154250)
-- Game: addappid(2154250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154251, 1, "63d1ef7c2a32993dbe98f961a0cb957d03a7d9c0ea1fdbc6ea54337bd58ad6d2")
