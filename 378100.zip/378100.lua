-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(378100)
addappid(378101)

-- MAIN APP DEPOTS / PACKAGES
addappid(378102,0,"5af467096fce3c27603f38d3a433baf209c11740b94ded46f6b0f036962236e8")

