-- Lua provided by RyzenAPI
-- Game: Trinity Building Editor

-- MAIN APPLICATION
addappid(2140810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140811, 1, "F7325CA2EF86D153D5917708B987506402CA53282667B6AB8C7D1923CB95BCFD")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
