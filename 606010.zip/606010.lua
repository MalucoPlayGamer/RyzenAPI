-- Lua provided by RyzenAPI
-- Game: addappid(606010)

-- MAIN APPLICATION
addappid(606010)

-- MAIN APP DEPOTS / PACKAGES
addappid(606011, 1, "b15ff6efd4cc38f28577cb180c669a117aa9462f4e231a0939cbf567c7c3e3aa")
