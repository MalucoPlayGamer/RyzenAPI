-- Lua provided by RyzenAPI
-- Game: NUTS

-- MAIN APPLICATION
addappid(768450)
addappid(768454)
-- Game: addappid(768450)

-- MAIN APP DEPOTS / PACKAGES
addappid(768452,0,"3196618592e1d89aa428d72c2c3261b325f704c18eb4f6efbdac3d0b7168bac3")
addappid(768453,0,"684cbbcf045ac9ca81bfc75d91e973c4545b40dd19078eee22d04521b2c986cc")
