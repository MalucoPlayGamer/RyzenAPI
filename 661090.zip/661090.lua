-- Lua provided by RyzenAPI
-- Game: Tank Battle Mania

-- MAIN APPLICATION
addappid(661090)

-- MAIN APP DEPOTS / PACKAGES
addappid(661091, 1, "1a9e8045b57882dbbe655ae1568b731a024a3e1d21cb90d605fda2c06f3733df")

