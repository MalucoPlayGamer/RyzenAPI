-- Lua provided by RyzenAPI 
-- Game: Gunvolt Chronicles: Luminous Avenger iX
addappid(1085180)
addappid(1085181, 1, "4da2a352ce7e30e129036f97faa7a9a8494ff954bd1ab2b071435d2f38955694")
addappid(1140640, 0, "1d0516bdd4a532e09e449a4c0d0267122ac042c04fb34f201d11a90ce33cec4c")
addappid(1192340, 0, "f64df63c9890872c5117d9c72edd4d67061a09b4cc8b378e5eef2e645a2b3659")
addappid(1192350, 0, "c0ea3b9490a7ad7b37bd0766e030ba11b7eb4d6dc871b579111e99db8259a8f8")
