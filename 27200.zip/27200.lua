-- Lua provided by RyzenAPI
-- Game: Summer Athletics

-- MAIN APPLICATION
addappid(27200)

-- MAIN APP DEPOTS / PACKAGES
addappid(27201, 1, "1bb6c09cb60ebc1608540485b611e9010de071d2bc8353a8f52930ea3b187f7f")
