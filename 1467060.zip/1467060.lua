-- Lua provided by RyzenAPI
-- Game: Secrets of Magic 4: Potion Master

-- MAIN APPLICATION
addappid(1467060)
-- Game: addappid(1467060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467061, 1, "78cc333b3eadf44457fdb29f566930f2adbe080ad4677e2d661590598f204f7c")
