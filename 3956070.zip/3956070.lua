-- Lua provided by RyzenAPI
-- Game: The Succubus Trap Island

-- MAIN APPLICATION
addappid(3956070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3956073,0,"129794af64f398b2cd08c712ff9b4771cae9bf94f627ceb3ba346eceff51f7df")

