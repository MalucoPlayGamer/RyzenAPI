-- Lua provided by RyzenAPI
-- Game: Meet the Miner - WDR VR Bergwerk

-- MAIN APPLICATION
addappid(916130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(916131, 1, "33c8bdc67c8843906413aec51842d96631bb09407fd1287d1171bd554da7efae")

