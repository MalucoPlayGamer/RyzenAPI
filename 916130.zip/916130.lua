-- Lua provided by RyzenAPI
-- Game: 916130

-- MAIN APPLICATION
addappid(916130)
-- Game: addappid(916130)

-- MAIN APP DEPOTS / PACKAGES
addappid(916131, 1, "33c8bdc67c8843906413aec51842d96631bb09407fd1287d1171bd554da7efae")
