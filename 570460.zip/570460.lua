-- Lua provided by RyzenAPI
-- Game: addappid(570460)

-- MAIN APPLICATION
addappid(570460)
addappid(770480)

-- MAIN APP DEPOTS / PACKAGES
addappid(570461, 1, "2811c0008214d58e6624621a3e32082da84be9cc52f3a47250d3974dae6eae22")
