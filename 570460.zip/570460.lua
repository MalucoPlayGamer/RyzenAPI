-- Lua provided by RyzenAPI
-- Game: Laser League: World Arena

-- MAIN APPLICATION
addappid(570460)
addappid(770480)
addappid(790000)
addappid(1695050)
addappid(1818920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(570461, 1, "2811c0008214d58e6624621a3e32082da84be9cc52f3a47250d3974dae6eae22")
