-- Lua provided by RyzenAPI 
-- Game: Distorted Reality
addappid(681780)
addappid(681781, 1, "c55e22b587a0b03a65223ce8c4460fb3c32e04ac59b6da8a2e2914cf3132db6f")
