-- Lua provided by RyzenAPI 
-- Game: AppID 786180
addappid(786180)
addappid(786181, 1, "52f5003501df4d5278613ba9b18f02f5e66da5233c56a56fa72191c18a84fec1")
addappid(786870, 0, "431e9fdfa31f6627abf3cbb2ceaab294fe488b656882e5c408822ca401efe2a0")
