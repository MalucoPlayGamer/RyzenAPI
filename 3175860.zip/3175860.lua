-- Lua provided by RyzenAPI 
-- Game: AppID 3175860
addappid(3175860)
addappid(3175861, 1, "1f54e0f21259d580e51e729346b6575b40001019724d7f2079cac7b0deb65172")
