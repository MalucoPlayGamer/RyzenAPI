-- Lua provided by SkyAPI 
-- Game: Rainbow Rage Squad
addappid(549780)
addappid(549781, 1, "b8a1cf531967f37b5be9437412c34f7e083ba289845d81c172d7877bfbc519a5")
