-- Lua provided by RyzenAPI
-- Game: addappid(549780)

-- MAIN APPLICATION
addappid(549780)

-- MAIN APP DEPOTS / PACKAGES
addappid(549781, 1, "b8a1cf531967f37b5be9437412c34f7e083ba289845d81c172d7877bfbc519a5")
