-- Lua provided by RyzenAPI 
-- Game: ENDO
addappid(1507620)
addappid(1507621, 1, "04997a199ce0eea1b3fd1e6ae0f5ad5f2282e013f894c816a1fc6dc5e327da5f")
