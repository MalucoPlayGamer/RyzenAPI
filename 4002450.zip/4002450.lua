-- 4002450's Lua and Manifest Created by Hubcap Manifest
-- Italian Pizza Simulator
-- Created: August 14, 2026 at 10:22:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4002450) -- Italian Pizza Simulator
-- MAIN APP DEPOTS
addappid(4002451, 1, "7321deb7f58344373c7fe78cd7d2425e7515c27434085c7149df17a61bf86d29") -- Depot 4002451
setManifestid(4002451, "4974128646317631189", 3669444958)