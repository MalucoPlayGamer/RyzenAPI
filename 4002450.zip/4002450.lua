-- Lua provided by RyzenAPI
-- Game: Italian Pizza Simulator

-- MAIN APPLICATION
addappid(4002450) -- Italian Pizza Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4002451, 1, "7321deb7f58344373c7fe78cd7d2425e7515c27434085c7149df17a61bf86d29") -- Depot 4002451

