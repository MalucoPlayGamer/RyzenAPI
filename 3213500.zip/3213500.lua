-- Lua provided by RyzenAPI
-- Game: Summer For You Soundtrack

-- MAIN APPLICATION
addappid(3213500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213501, 1, "06b07bcb77d95a450eddc2c060ae29796739446d0e2cd2dd4c3eaa751b9a6caa")

