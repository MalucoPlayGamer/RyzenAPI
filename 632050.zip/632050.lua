-- Lua provided by RyzenAPI
-- Game: addappid(632050)

-- MAIN APPLICATION
addappid(632050)
addappid(869740)

-- MAIN APP DEPOTS / PACKAGES
addappid(632051, 1, "40fed663fa8deb259e13f1df39c3dac3d9ca984a9d5c1fb6fc3411d6aef75323")
