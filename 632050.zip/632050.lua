-- Lua provided by RyzenAPI
-- Game: The Village

-- MAIN APPLICATION
addappid(632050)
addappid(869740)

-- MAIN APP DEPOTS / PACKAGES
addappid(632051, 1, "40fed663fa8deb259e13f1df39c3dac3d9ca984a9d5c1fb6fc3411d6aef75323")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
