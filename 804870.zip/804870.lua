-- Lua provided by RyzenAPI
-- Game: AppID 804870

-- MAIN APPLICATION
addappid(804870)

-- MAIN APP DEPOTS / PACKAGES
addappid(804871, 1, "5cb7331be6d778a86c82b5633470cf1ccdde42b0da3e52caf2931dc94fb8bd86")

