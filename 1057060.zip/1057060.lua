-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1057060)
-- Game: addappid(1057060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057060,0,"89d52ee86a4532b622ff93507c4093d0476985e1f35479fe8fccd5a04ce5c57a")
