-- Lua provided by RyzenAPI
-- Game: addappid(2829060)

-- MAIN APPLICATION
addappid(2829060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2829061, 1, "00791d0ea17073b83dbc6e3751a8c9409c43c30663ee604dab72d257ffccdde2")
