-- 4137450's Lua and Manifest Created by Hubcap Manifest
-- Mimicry!
-- Created: July 30, 2026 at 14:21:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4137450) -- Mimicry!
-- MAIN APP DEPOTS
addappid(4137451, 1, "b7b3f549d58b124a1a4b6c83bacaddde73728ce2f330bf9e6967ca880cb50383") -- Depot 4137451
setManifestid(4137451, "6837276028514193121", 855634529)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)