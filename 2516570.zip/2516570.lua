-- Lua provided by RyzenAPI
-- Game: Infinite Borders

-- MAIN APPLICATION
addappid(2516570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516571, 1, "06b988495728f2003794a2bf9e5e421981119b5af75f255818a2059599dcabf6")

