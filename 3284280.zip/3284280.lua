-- Lua provided by RyzenAPI
-- Game: 幸运农场 Demo

-- MAIN APPLICATION
addappid(228988)
addappid(3284280)
addappid(3284283)

-- MAIN APP DEPOTS / PACKAGES
addappid(3284282,0,"8b882b0f684f80e98265604bc459239fe004835f4b3fca919cea2c9cb6f5a57a")

