-- Lua provided by RyzenAPI
-- Game: Tiny House Simulator

-- MAIN APPLICATION
addappid(3191990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191991, 1, "076200295f3d07625c86f08efb85eb774810fea7f38b09d735e157448aebe1a4")
