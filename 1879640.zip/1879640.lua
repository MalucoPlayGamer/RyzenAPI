-- Lua provided by RyzenAPI
-- Game: 甜點王子2 典藏版

-- MAIN APPLICATION
addappid(1879640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879641, 1, "49891bb41c81a0da3087167ab3d6f9ffaf256202c400d3c5f2e10dc98453030a")

