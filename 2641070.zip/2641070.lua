-- Lua provided by RyzenAPI
-- Game: Black Beacon Hill

-- MAIN APPLICATION
addappid(2641070)
-- Game: addappid(2641070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641072,0,"f0efc2210516506f250ba400adf167e7007a7057377d2653c90783e7562f9a01")
