-- Lua provided by RyzenAPI
-- Game: AppID 3467420

-- MAIN APPLICATION
addappid(3467420)
-- Game: addappid(3467420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3467421, 1, "e311fa4f0d2a7eb5d77bd9b17f9fa208e7397c9726b1a27816c0069d35ce8818")
