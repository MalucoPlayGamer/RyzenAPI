-- Lua provided by RyzenAPI
-- Game: addappid(1467360)

-- MAIN APPLICATION
addappid(1467360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467361, 1, "bc99120d30c13d6a271f546838b210710fea7e246a0d576a7762ea8e80e16cb9")
