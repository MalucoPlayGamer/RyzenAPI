-- Lua provided by RyzenAPI
-- Game: NBA 2K22

-- MAIN APPLICATION
addappid(1644960)
addappid(1692530)
addappid(1692531)
addappid(1692532)
addappid(1749550)
addappid(1766870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1644961, 1, "7bd16fd362dc178163d8afa11b87e3fe72a6c53a23d000d8b4671c601f1c5d95")

