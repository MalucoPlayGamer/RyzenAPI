-- Lua provided by RyzenAPI
-- Game: Vanguard Exiles

-- MAIN APPLICATION
addappid(2745490)
-- Game: addappid(2745490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2745491, 1, "4ef3f410bc39562932d06009f76ca8661485e1efae3b7ff54c55e998056c1f28")
addappid(2745492, 1, "666f8c861ddf15b3cc782dbc06657a282de9016f9d71c507bc1528c6741bfea5")
