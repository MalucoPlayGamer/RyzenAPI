-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost in China Find & Color

-- MAIN APPLICATION
addappid(3809590)
addappid(4045630)

