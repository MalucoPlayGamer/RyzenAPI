-- Lua provided by RyzenAPI
-- Game: Last Hope - Tower Defense

-- MAIN APPLICATION
addappid(434020)
-- Game: addappid(434020)

-- MAIN APP DEPOTS / PACKAGES
addappid(434021, 1, "6509759d726f9058257dfdbc9c56a90bf5829202d464d8b908616d9a874fa2e0")
addappid(434022, 1, "aaa59f73434b53dfbb48c4662e64b9a6883a0daf0edf5b48bbe200a3f0e4b451")
addappid(434023, 1, "e7a7f4f7fd5c38dc79785b7bef6afb17f4c52c4cc7e6f2a0e1250ac49ab6898c")
