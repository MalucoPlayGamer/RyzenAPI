-- Lua provided by RyzenAPI
-- Game: addappid(3616820)

-- MAIN APPLICATION
addappid(3616820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3616821, 1, "86da4964cc560d43755670a437afe0ad5693fb1d52bdb87456cd5d7bd65793b4")
