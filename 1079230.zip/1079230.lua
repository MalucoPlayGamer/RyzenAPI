-- Lua provided by SkyAPI 
-- Game: Himno - The Silent Melody
addappid(1079230)
addappid(1079231, 1, "d559b22b4e9648ab2608d4cc534901daf21dd5f35c20c526604faa1dbcdf57da")
