-- Lua provided by RyzenAPI
-- Game: Himno - The Silent Melody

-- MAIN APPLICATION
addappid(1079230)
-- Game: addappid(1079230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079231, 1, "d559b22b4e9648ab2608d4cc534901daf21dd5f35c20c526604faa1dbcdf57da")
