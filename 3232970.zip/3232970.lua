-- Lua provided by RyzenAPI
-- Game: AppID 3232970

-- MAIN APPLICATION
addappid(3232970)
-- Game: addappid(3232970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3232971, 1, "fed37be9c33e1057be43a1028c1166a19be9606bfbe17731525b040dd636960c")
