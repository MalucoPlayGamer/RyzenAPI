-- Lua provided by RyzenAPI
-- Game: 无尽守卫

-- MAIN APPLICATION
addappid(1940910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940911, 1, "9ca72d0d36dd2aabf5e7342dd7aedf035e2d89a098cf615f66c41f6a5d4d1233")
