-- Lua provided by RyzenAPI
-- Game: Command & Control 3

-- MAIN APPLICATION
addappid(1175800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175801, 1, "aecad4e04ac8a7a3ae6851d81aeeb5557612c393e289195c4b3c0792617e2d6e")

