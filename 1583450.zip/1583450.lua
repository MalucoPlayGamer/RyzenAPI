-- Lua provided by RyzenAPI
-- Game: 1583450

-- MAIN APPLICATION
addappid(1583450)
-- Game: addappid(1583450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583451, 1, "1a4f145ab23da7de5cea8faf41655f6e5fa15a17b3557f4c1375725c4a445205")
