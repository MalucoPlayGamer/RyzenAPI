-- Lua provided by RyzenAPI
-- Game: 1313000

-- MAIN APPLICATION
addappid(1313000)
-- Game: addappid(1313000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313001, 1, "c691c9799149b4370d313c4bc815c2e20b27556146e8141eecbae77c5b899ea1")
