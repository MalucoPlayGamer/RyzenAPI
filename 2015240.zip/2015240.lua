-- Lua provided by RyzenAPI
-- Game: addappid(2015240)

-- MAIN APPLICATION
addappid(2015240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015241, 1, "af9571cc8c6e975247efca0a6cda92a974e384ce0ad7420bcfd110a941ee981f")
