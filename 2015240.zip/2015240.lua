-- Lua provided by RyzenAPI
-- Game: Dwarven Realms

-- MAIN APPLICATION
addappid(2015240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2015241, 1, "af9571cc8c6e975247efca0a6cda92a974e384ce0ad7420bcfd110a941ee981f")

