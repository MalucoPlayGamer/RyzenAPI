-- Lua provided by RyzenAPI
-- Game: addappid(956737)

-- MAIN APPLICATION
addappid(956737)

-- MAIN APP DEPOTS / PACKAGES
addappid(956737,0,"f561244c46a92200f40a9fc6db007eed57ec0f1e8f97368478242ee7590a91ea")
