-- Lua provided by SkyAPI 
-- Game: Hogogeist
addappid(1402380)
addappid(1402381, 1, "4b9f72edc7ac12ec60663aed9277a4c908b34230eef27bd1bc5bc15176fe78ef")
