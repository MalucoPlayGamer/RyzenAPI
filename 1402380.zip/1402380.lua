-- Lua provided by RyzenAPI
-- Game: addappid(1402380)

-- MAIN APPLICATION
addappid(1402380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402381, 1, "4b9f72edc7ac12ec60663aed9277a4c908b34230eef27bd1bc5bc15176fe78ef")
