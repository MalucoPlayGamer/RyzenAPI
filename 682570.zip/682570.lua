-- Lua provided by RyzenAPI
-- Game: SG/ZH: School Girl/Zombie Hunter

-- MAIN APPLICATION
addappid(682570) -- SG/ZH: School Girl/Zombie Hunter
addappid(826490) -- Onechanbara Red Kagura
addappid(826491) -- Onechanbara Black Kagura
addappid(826492) -- Onechanbara Blue Kagura
addappid(826493) -- Micro Thong Red
addappid(826494) -- Micro Thong Yellow
addappid(826495) -- Micro Thong White
addappid(826496) -- Lingerie Blue
addappid(826497) -- Lingerie Red
addappid(826498) -- Lingerie Black
addappid(826499) -- Cherry Tomatoes  Cabbage A
addappid(826500) -- Cherry Tomatoes  Cabbage B
addappid(826501) -- Cherry Tomatoes  Cabbage C
addappid(826502) -- Avocados  Watermelon A
addappid(826503) -- Avocados  Watermelon B
addappid(826504) -- Avocados  Watermelon C
addappid(826505) -- Starfruit  Melon A
addappid(826506) -- Starfruit  Melon B
addappid(826507) -- Starfruit  Melon C

-- MAIN APP DEPOTS / PACKAGES
addappid(682571, 1, "9ef8275b1185089f63084a95d4bd095e36913ea570ea0040b4d72b76c59d9c5f") -- SH Content
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
