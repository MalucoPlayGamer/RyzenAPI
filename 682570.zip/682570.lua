-- Lua provided by RyzenAPI
-- Game: addappid(682570)

-- MAIN APPLICATION
addappid(682570)

-- MAIN APP DEPOTS / PACKAGES
addappid(682571, 1, "9ef8275b1185089f63084a95d4bd095e36913ea570ea0040b4d72b76c59d9c5f")
