-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Shu Pack 2

-- MAIN APPLICATION
addappid(933512)
-- Game: addappid(933512)

-- MAIN APP DEPOTS / PACKAGES
addappid(933512,0,"94cdda7fa1f15d44eac879b470fd109748178bb291647e8e4fb13cc7a8e851a2")
