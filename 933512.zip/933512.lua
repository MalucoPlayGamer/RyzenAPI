-- Lua provided by RyzenAPI
-- Game: 933512

-- MAIN APPLICATION
addappid(933512)
-- Game: addappid(933512)

-- MAIN APP DEPOTS / PACKAGES
addappid(933512,0,"94cdda7fa1f15d44eac879b470fd109748178bb291647e8e4fb13cc7a8e851a2")
