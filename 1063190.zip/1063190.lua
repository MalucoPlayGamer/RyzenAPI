-- Lua provided by RyzenAPI
-- Game: 1063190

-- MAIN APPLICATION
addappid(1063190)
-- Game: addappid(1063190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063191, 1, "78cb6391410c80a4592401bde811262b449db2d7e0bb40b9ac7e8890a3c768c6")
