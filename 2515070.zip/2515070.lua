-- Lua provided by RyzenAPI
-- Game: 2515070

-- MAIN APPLICATION
addappid(2515070)
-- Game: addappid(2515070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515071, 1, "109dc37a050e38f79e2ea23b98e1f417725291e9b5ada1539db0d0525ed7aa72")
