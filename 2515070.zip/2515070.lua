-- Lua provided by RyzenAPI
-- Game: AQUARIUM

-- MAIN APPLICATION
addappid(2515070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2515071, 1, "109dc37a050e38f79e2ea23b98e1f417725291e9b5ada1539db0d0525ed7aa72")

