-- Lua provided by SkyAPI 
-- Game: Untold Winter Playtest
addappid(3587130)
addappid(3587131, 1, "42cbe9f7c33f899821bde9b20424c940ceb965a9ffc45e4b2dc3b56cab42b4cc")
