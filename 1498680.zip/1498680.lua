-- Lua provided by RyzenAPI
-- Game: 1498680

-- MAIN APPLICATION
addappid(1498680)
-- Game: addappid(1498680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498681, 1, "a92917a7844d90d2f255b2095538b1651ccf9dbfe5bdd43214967dfc3e80b997")
