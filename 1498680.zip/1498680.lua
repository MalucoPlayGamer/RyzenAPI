-- Lua provided by RyzenAPI 
-- Game: Poker Pretty Girls Battle : Fantasy World Edition
addappid(1498680)
addappid(1498681, 1, "a92917a7844d90d2f255b2095538b1651ccf9dbfe5bdd43214967dfc3e80b997")
