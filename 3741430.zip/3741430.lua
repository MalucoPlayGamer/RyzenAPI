-- Lua provided by SkyAPI 
-- Game: CHAMBER X
addappid(3741430)
addappid(3741431, 1, "3a2996627eddd19621e5241cf2ddc1063ec6f9409875d6cf7a3f791dc30ea38e")
