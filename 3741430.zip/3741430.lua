-- Lua provided by RyzenAPI
-- Game: CHAMBER X

-- MAIN APPLICATION
addappid(3741430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3741431, 1, "3a2996627eddd19621e5241cf2ddc1063ec6f9409875d6cf7a3f791dc30ea38e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
