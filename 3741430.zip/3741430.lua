-- Lua provided by RyzenAPI
-- Game: 3741430

-- MAIN APPLICATION
addappid(3741430)
-- Game: addappid(3741430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3741431, 1, "3a2996627eddd19621e5241cf2ddc1063ec6f9409875d6cf7a3f791dc30ea38e")
