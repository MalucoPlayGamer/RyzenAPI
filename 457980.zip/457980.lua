-- Lua provided by RyzenAPI
-- Game: AppID 457980

-- MAIN APPLICATION
addappid(457980)
-- Game: addappid(457980)

-- MAIN APP DEPOTS / PACKAGES
addappid(457981, 1, "6997a0506130d6cdff6fa6ab78c86986bb81fa2dcef7b8ce8638d5c700c9de40")
