-- Lua provided by RyzenAPI
-- Game: Steel Ocean

-- MAIN APPLICATION
addappid(390670)
addappid(430110)
addappid(430120)
addappid(460240)
addappid(546880)
addappid(546890)
addappid(557350)
addappid(557380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(390671, 1, "9c719c87c078d0509d51d104fd52203226ca4e56a8e2a504117b9521b2430b95")
addappid(398310, 0, "b129b90a83c642f6bfd8a67a1c78795f9beed9aa1d4cf7c1eb3753217b9beee7")

