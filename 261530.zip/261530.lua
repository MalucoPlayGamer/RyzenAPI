-- Lua provided by RyzenAPI
-- Game: addappid(261530)

-- MAIN APPLICATION
addappid(261530)

-- MAIN APP DEPOTS / PACKAGES
addappid(261531, 1, "dd21f24d863de400699de49521cdb6459eeaac5ec851d48a3c95a7317143ffd5")
addappid(261532, 1, "d2487dd415e9fe078b6bcf0ad2bef9022bc72c3764eaa9831fe97bd8e044bc08")
addappid(261533, 1, "17a33e08292abe646b0ebdc55d7f5ae5c24310dc76c0eedc033d1dde4ce4a80d")
