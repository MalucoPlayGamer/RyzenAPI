-- Lua provided by RyzenAPI
-- Game: Spinning Scarecrow

-- MAIN APPLICATION
addappid(3409660) -- Spinning Scarecrow

-- MAIN APP DEPOTS / PACKAGES
addappid(3409661, 1, "96f9082e5ee46e5e4053162d946b26918ce9c443256fc04798c5920c4fa05c98") -- Depot 3409661

