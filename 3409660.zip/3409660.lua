-- 3409660's Lua and Manifest Created by Hubcap Manifest
-- Spinning Scarecrow
-- Created: August 04, 2026 at 14:29:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3409660) -- Spinning Scarecrow
-- MAIN APP DEPOTS
addappid(3409661, 1, "96f9082e5ee46e5e4053162d946b26918ce9c443256fc04798c5920c4fa05c98") -- Depot 3409661
setManifestid(3409661, "801925315855723787", 1058224795)