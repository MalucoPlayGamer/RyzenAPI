-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Sun Temple

-- MAIN APPLICATION
addappid(3079410)
-- Game: addappid(3079410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3079411, 1, "3f514e13e991e5c8a129ed2d662953bcb620d2e7c70ad39f0a5ede3648528565")
