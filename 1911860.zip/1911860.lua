-- Lua provided by RyzenAPI
-- Game: 1911860

-- MAIN APPLICATION
addappid(1911860)
-- Game: addappid(1911860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911861, 1, "c924b130e02468d91c44bbd60d41ae87def8e9a7d9eb42d622281b7da9d04819")
addappid(3570560, 0, "0f4d2c6b372f3c291b2ddffb17f50fe515be94a2a5ec6cd0154bc7151995cf4b")
