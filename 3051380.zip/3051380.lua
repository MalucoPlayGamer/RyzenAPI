-- Lua provided by RyzenAPI
-- Game: Lofi aquarium

-- MAIN APPLICATION
addappid(3051380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3051381, 1, "5fcfb32effeb4f67d8a9f23bb27db5e3c5cbda63e30f12615b70f40ea8c7771d")

