-- Lua provided by RyzenAPI
-- Game: 3051380

-- MAIN APPLICATION
addappid(3051380)
-- Game: addappid(3051380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3051381, 1, "5fcfb32effeb4f67d8a9f23bb27db5e3c5cbda63e30f12615b70f40ea8c7771d")
