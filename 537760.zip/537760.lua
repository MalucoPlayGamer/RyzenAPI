-- Lua provided by RyzenAPI
-- Game: Arizona Rose and the Pirates' Riddles

-- MAIN APPLICATION
addappid(537760)

-- MAIN APP DEPOTS / PACKAGES
addappid(537761, 1, "d739edf0395e9979b889dcb10c64063ff73d24ffbf926045f2e352eeba959628")
