-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1754695)
-- Game: addappid(1754695)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754695,0,"1b285977b0be3b48b8cf640aa63c0d8b85e853d670aa2acd5d7ccb1a05440fad")
