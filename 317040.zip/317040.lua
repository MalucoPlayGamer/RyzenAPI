-- Lua provided by RyzenAPI
-- Game: Strife: Veteran Edition

-- MAIN APPLICATION
addappid(317040)
-- Game: addappid(317040)

-- MAIN APP DEPOTS / PACKAGES
addappid(317041, 1, "2e884cbbc1e0553a037588cf84e8340a905c17f23dfd21b72f3edced7ac6e760")
addappid(317042, 1, "449078170067b80106b5c9d1df3f5c26fadccea02f0a609c1bd96f879caef9e3")
addappid(317043, 1, "50d15459c275ec85441d91627e65305868bf1772e93bbb9fcf49e2d29cdd308f")
addappid(317044, 1, "5d0b3637b9d6ce32f804c4a66934e9179a8894630e1ec9dd3446d3772bdb27b6")
