-- Lua provided by RyzenAPI
-- Game: 1728560

-- MAIN APPLICATION
addappid(1728560)
-- Game: addappid(1728560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728561, 1, "a1e326322048e3af1d9f4ca9633ff467cce7893d5a0aafbd1607d85d493bc017")
