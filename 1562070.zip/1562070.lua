-- Lua provided by RyzenAPI
-- Game: Pirate Story

-- MAIN APPLICATION
addappid(1562070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562071, 1, "eefacfc4a6f4d8ca074af709f62432b678d92ff871186c95e1f55585c54db641")
