-- Lua provided by RyzenAPI
-- Game: Game: Oblivity - Find your perfect Sensitivity

-- MAIN APPLICATION
addappid(1389990)
-- Game: addappid(1389990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389991, 1, "749e442c5d97a877110de0e7f78bff99891b1b90c8a3270c7544ab040165df8d")
