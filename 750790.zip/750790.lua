-- Lua provided by RyzenAPI 
-- Game: Hollow Throne
addappid(750790)
addappid(750791, 1, "163a19eafd9fa5c49792ebb88710168cf77e4c8a613cf963a8a47a18eff16b1b")
