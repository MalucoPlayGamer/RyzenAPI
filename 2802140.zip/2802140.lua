-- Lua provided by RyzenAPI
-- Game: Hello World

-- MAIN APPLICATION
addappid(2802140)
-- Game: addappid(2802140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802141, 1, "a9ffb26cf488603865b76d8179935b5a251e2d38f9451ffe834fd20e0661d3e7")
