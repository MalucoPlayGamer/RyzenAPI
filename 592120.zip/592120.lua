-- Lua provided by RyzenAPI
-- Game: Glyphs Apprentice

-- MAIN APPLICATION
addappid(592120)

-- MAIN APP DEPOTS / PACKAGES
addappid(592121, 1, "59ac858b28b174f2f7fc706b1e11124a555fadd6c6fe070600f38de9b4c6cd98")

