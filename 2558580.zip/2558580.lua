-- Lua provided by RyzenAPI
-- Game: The Backrooms: Unbounded

-- MAIN APPLICATION
addappid(2558580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2558581, 1, "01115f09a0460056f1683225d8b742bfb5e14b9737c407f512e9a2221604cbb6")

