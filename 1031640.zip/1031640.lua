-- Lua provided by RyzenAPI 
-- Game: AppID 1031640
addappid(1031640)
addappid(1031641, 1, "3558e9a9d1121cc8203822a75c4b915ceb348bedebb654eabb303747bbd52858")
addappid(1039670, 0, "c0b80328ae400cd1ce4bd2e179fe544ae1fc47a15fde344c4e31a7545f56b167")
