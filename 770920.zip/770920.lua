-- Lua provided by RyzenAPI
-- Game: Haunted Legends: The Undertaker Collector's Edition

-- MAIN APPLICATION
addappid(770920)

-- MAIN APP DEPOTS / PACKAGES
addappid(770921,0,"701fef57d65938d3f5a6674107b13511454abca382f5bbde0fb4e28fc9528711")

