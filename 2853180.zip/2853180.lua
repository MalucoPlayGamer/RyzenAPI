-- Lua provided by RyzenAPI
-- Game: Game: Seal the Rift

-- MAIN APPLICATION
addappid(2853180)
-- Game: addappid(2853180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853181, 1, "3db6b214181e9c0c55c5bf3d16a6f8d081cc49678f58770659772e2f90f51846")
