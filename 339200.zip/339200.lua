-- Lua provided by SkyAPI 
-- Game: Oceanhorn: Monster of Uncharted Seas
addappid(339200)
addappid(339201, 1, "6f31e2f91386aa771ee8def2025b780b72428388b01c05437468f27710072b34")
addappid(339202, 1, "f219d7a54465dd2139f0ac46db94e675d0f73b215407046bb1332cb343103207")
