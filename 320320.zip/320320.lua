-- Lua provided by RyzenAPI
-- Game: Darkstone

-- MAIN APPLICATION
addappid(320320)

-- MAIN APP DEPOTS / PACKAGES
addappid(320321, 1, "7b3420951a4705240fc0124075c85592a295ab0b52a995d211a9d2d5e0eb9512")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
