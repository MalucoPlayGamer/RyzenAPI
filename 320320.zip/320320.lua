-- Lua provided by RyzenAPI
-- Game: Darkstone

-- MAIN APPLICATION
addappid(320320)
-- Game: addappid(320320)

-- MAIN APP DEPOTS / PACKAGES
addappid(320321, 1, "7b3420951a4705240fc0124075c85592a295ab0b52a995d211a9d2d5e0eb9512")
