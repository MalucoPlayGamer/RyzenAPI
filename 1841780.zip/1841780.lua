-- Lua provided by RyzenAPI
-- Game: addappid(1841780)

-- MAIN APPLICATION
addappid(1841780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841781, 1, "e50dbe8ed183a326a32eddb8a7950a07ba410e51f06abc964d6e1b6100fc8141")
