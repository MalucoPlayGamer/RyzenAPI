-- Lua provided by SkyAPI 
-- Game: It follows you
addappid(1841780)
addappid(1841781, 1, "e50dbe8ed183a326a32eddb8a7950a07ba410e51f06abc964d6e1b6100fc8141")
