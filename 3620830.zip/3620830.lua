-- Lua provided by RyzenAPI
-- Game: addappid(3620830)

-- MAIN APPLICATION
addappid(3620830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3620831, 1, "1f663ee95a6b131742737d1abb355bf44971eb5d4ed2b6b7edbd7ddfa74b89db")
