-- Lua provided by RyzenAPI
-- Game: addappid(684470)

-- MAIN APPLICATION
addappid(684470)

-- MAIN APP DEPOTS / PACKAGES
addappid(684471, 1, "89ae8880aa881a3fec560df59028f81a78deac3483c4c54ea83bfd714af67681")
