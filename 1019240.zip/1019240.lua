-- Lua provided by RyzenAPI
-- Game: 1019240

-- MAIN APPLICATION
addappid(1019240)
-- Game: addappid(1019240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019241, 1, "bb5514f3c58ae0c8d1dd78cefcd4ba98987d6aceca9f3f809cade743340c9ba1")
