-- Lua provided by RyzenAPI
-- Game: Game: TaniNani

-- MAIN APPLICATION
addappid(1196800)
-- Game: addappid(1196800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196801, 1, "2e0ec620f7fc53ad66eb26ce16bb8c3caca52973dde625ec6180a1285b1d22e8")
addappid(1196802, 1, "d3a57d5c4157ca964199bd65c2d0de25f91949ab22864711b041bfc3abe08488")
addappid(1196803, 1, "369b02a2e2d0c64d0e7439ef8c9367baa94b869457b67d009a82437875af489c")
