-- Lua provided by RyzenAPI
-- Game: addappid(1780830)

-- MAIN APPLICATION
addappid(1780830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780830,0,"c5ecca9e6946653619c5d9d421f4b5a7ba4bca9132af8acdd8b8c304c400765c")
