-- Lua provided by RyzenAPI
-- Game: TRY AGAIN

-- MAIN APPLICATION
addappid(2448340)

