-- Lua provided by RyzenAPI
-- Game: 101 Cats in Berlin

-- MAIN APPLICATION
addappid(3122950)
-- Game: addappid(3122950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122951, 1, "0a55e182094a9160e77f5a733f1db4f44d0eb8b956686045cc822bd6d6ffd592")
