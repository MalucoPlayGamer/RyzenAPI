-- Lua provided by RyzenAPI
-- Game: Doki Doki AI Interrogation

-- MAIN APPLICATION
addappid(2844700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844701, 1, "c1ecad58e52a5844a7f799f249947f30d38cd4de4cfd4ff68404bdf23ca27c8c")

