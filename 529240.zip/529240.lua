-- Lua provided by RyzenAPI
-- Game: Creature Clicker - Capture, Train, Ascend!

-- MAIN APPLICATION
addappid(529240)

-- MAIN APP DEPOTS / PACKAGES
addappid(529241, 1, "4b5f89ddbd8f793ee76c576d37a898308a93027539a72f044991860341aa165a")

