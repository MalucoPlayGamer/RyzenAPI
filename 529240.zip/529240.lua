-- Lua provided by RyzenAPI
-- Game: Creature Clicker - Capture, Train, Ascend!

-- MAIN APPLICATION
addappid(529240)

-- MAIN APP DEPOTS / PACKAGES
addappid(529241, 1, "4b5f89ddbd8f793ee76c576d37a898308a93027539a72f044991860341aa165a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(631330)
addappid(631331)
addappid(631332)
addappid(1302520)
addappid(1302521)
addappid(1302522)
addappid(1303080)
addappid(1303081)
addappid(1303082)
addappid(1312410)
addappid(1312411)
addappid(1312412)
addappid(1312413)
addappid(1312414)
addappid(1312720)
addappid(1331000)
addappid(1331001)
addappid(1331002)
addappid(1334790)
addappid(1334791)
addappid(1334792)
addappid(1348720)
addappid(1350600)
addappid(1350601)
addappid(1350602)
addappid(1350603)
addappid(1350604)
addappid(1354430)
addappid(1354431)
addappid(1444200)
addappid(1444201)
addappid(1444202)
addappid(1444203)
