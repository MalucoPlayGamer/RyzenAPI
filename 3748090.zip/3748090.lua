-- Lua provided by RyzenAPI
-- Game: 3748090

-- MAIN APPLICATION
addappid(3748090)
-- Game: addappid(3748090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3748091, 1, "748a884b2f571138a0268e6565d758bfa95fbb9e7a7b5d5c007f1e718b96755d")
