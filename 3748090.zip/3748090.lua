-- Lua provided by RyzenAPI
-- Game: Seven Hearts

-- MAIN APPLICATION
addappid(3748090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3748091, 1, "748a884b2f571138a0268e6565d758bfa95fbb9e7a7b5d5c007f1e718b96755d")

