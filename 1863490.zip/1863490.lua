-- Lua provided by RyzenAPI
-- Game: Protecting Santa

-- MAIN APPLICATION
addappid(1863490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863491, 1, "63bbb4226f4a349b3f0c78e0d398c0924adaf1ac9a1dec5d5de87f38c57984f7")

