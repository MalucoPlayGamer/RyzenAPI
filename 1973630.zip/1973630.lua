-- Lua provided by RyzenAPI
-- Game: Godless tower

-- MAIN APPLICATION
addappid(1973630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973631, 1, "0f667c4ef14a1b253bcc1b18890c42c9f1b411a71c16bc76d600588ef6932eac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
