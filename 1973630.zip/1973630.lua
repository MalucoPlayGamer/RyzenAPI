-- Lua provided by RyzenAPI 
-- Game: Godless tower
addappid(1973630)
addappid(1973631, 1, "0f667c4ef14a1b253bcc1b18890c42c9f1b411a71c16bc76d600588ef6932eac")
