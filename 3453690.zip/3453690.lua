-- Lua provided by RyzenAPI
-- Game: AppID 3453690

-- MAIN APPLICATION
addappid(3453690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453691, 1, "e0e50e12f886866b64f1a4cccc3ab8cb8d8418814f45da3abf88e50aad0a409e")
