-- Lua provided by RyzenAPI
-- Game: AppID 739690

-- MAIN APPLICATION
addappid(739690)

-- MAIN APP DEPOTS / PACKAGES
addappid(739691, 1, "4f76f41cd80a0d6e70f8ec5f603df9f83ded885803db79d9294626b2b62dd2eb")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(765420)
addappid(765440)
