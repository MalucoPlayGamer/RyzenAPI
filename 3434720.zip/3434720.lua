-- Lua provided by RyzenAPI
-- Game: Shy Cats Hidden Orchestra 2

-- MAIN APPLICATION
addappid(3434720) -- Shy Cats Hidden Orchestra 2

-- MAIN APP DEPOTS / PACKAGES
addappid(3434721, 1, "2c33aae33403260496e60fc4e43d38309e7094283443a74ef47c3eea3b089883") -- Depot 3434721

