-- 3434720's Lua and Manifest Created by Hubcap Manifest
-- Shy Cats Hidden Orchestra 2
-- Created: August 07, 2026 at 22:56:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3434720) -- Shy Cats Hidden Orchestra 2
-- MAIN APP DEPOTS
addappid(3434721, 1, "2c33aae33403260496e60fc4e43d38309e7094283443a74ef47c3eea3b089883") -- Depot 3434721
setManifestid(3434721, "4599526039397780093", 1114921109)