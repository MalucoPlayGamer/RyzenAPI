-- Lua provided by RyzenAPI
-- Game: Time Carnage VR

-- MAIN APPLICATION
addappid(554280)

-- MAIN APP DEPOTS / PACKAGES
addappid(554281, 1, "7ad3ae2ddea6f55e6d160ea3bd53a10d8ebba332d73ff66cf8c1dd109520b4d0")
