-- Lua provided by RyzenAPI
-- Game: Time Carnage VR

-- MAIN APPLICATION
addappid(554280)

-- MAIN APP DEPOTS / PACKAGES
addappid(554281, 1, "7ad3ae2ddea6f55e6d160ea3bd53a10d8ebba332d73ff66cf8c1dd109520b4d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
