-- Lua provided by RyzenAPI
-- Game: Game: Maze Art: Yellow

-- MAIN APPLICATION
addappid(1818840)
-- Game: addappid(1818840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818841, 1, "61a7e6e14d392f83fb7b5819b9be55892f0564f4618069cf4c07ca05967394d2")
