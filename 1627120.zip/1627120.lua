-- Lua provided by RyzenAPI 
-- Game: Operation Body Count
addappid(1627120)
addappid(1627121, 1, "642ceb43e50c7aeeb9a257b59ec01546bcdaa71fe0d7d5fa7babafca60182235")
addappid(1627122, 1, "251a12d879105f9045d853f1b2bf1349e71604c7f6d5d2fb5ba371fffcdbcb23")
