-- Lua provided by SkyAPI 
-- Game: The Symbiant
addappid(1883090)
addappid(1883091, 1, "2ed3e6e43f9e58ad0b7f6f43d7f62b9e4dcce79030941d7c3a64d945412d254e")
