-- Lua provided by RyzenAPI
-- Game: The Symbiant

-- MAIN APPLICATION
addappid(1883090)
addappid(2261480)
addappid(2261490)
addappid(2277880)
addappid(2326980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883091, 1, "2ed3e6e43f9e58ad0b7f6f43d7f62b9e4dcce79030941d7c3a64d945412d254e")

