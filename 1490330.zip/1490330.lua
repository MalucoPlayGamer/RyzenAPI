-- Lua provided by RyzenAPI
-- Game: 1490330

-- MAIN APPLICATION
addappid(1490330)
-- Game: addappid(1490330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490331, 1, "5fe63bc4b3973c37f505c57eca8230527db19b8c6326bcb305fb142f5cca7be1")
