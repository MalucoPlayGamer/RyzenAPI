-- Lua provided by SkyAPI 
-- Game: AppID 3199480
addappid(3199480)
addappid(3199481, 1, "be962c1a32b22b7feab040a05899412363b7246e14f22f22d2511cedefc9cb1b")
