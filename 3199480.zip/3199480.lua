-- Lua provided by RyzenAPI
-- Game: Aurora Defense Demo

-- MAIN APPLICATION
addappid(3199480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3199481, 1, "be962c1a32b22b7feab040a05899412363b7246e14f22f22d2511cedefc9cb1b")
