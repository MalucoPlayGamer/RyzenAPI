-- Lua provided by RyzenAPI
-- Game: addappid(366270)

-- MAIN APPLICATION
addappid(366270)

-- MAIN APP DEPOTS / PACKAGES
addappid(366271, 1, "e382c4b05df86bd36efdb646ba061f6a8467102dc186374bd513f642b0a89d89")
