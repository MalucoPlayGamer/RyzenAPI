-- Lua provided by RyzenAPI 
-- Game: AppID 2786180
addappid(2786180)
addappid(2786181, 1, "73be4595c86e18eeff7f0394211d6db5f84d7a0151e90ce85978c760753a2c52")
