-- Lua provided by RyzenAPI
-- Game: Bully: Scholarship Edition

-- MAIN APPLICATION
addappid(12200)

-- MAIN APP DEPOTS / PACKAGES
addappid(12201, 1, "b02e549a49b9318ee8352042cb5cfe08a4d103eb6a7a3526c27e4e6ec86ed57b")

