-- Lua provided by RyzenAPI
-- Game: One Last Hand

-- MAIN APPLICATION
addappid(4209830) -- One Last Hand

-- MAIN APP DEPOTS / PACKAGES
addappid(4209831, 1, "a55418e80d365b141892fdf2e13b7179a226fcae7c7b4453bed4df876ebd3a8e") -- Depot 4209831

