-- 4209830's Lua and Manifest Created by Hubcap Manifest
-- One Last Hand
-- Created: August 14, 2026 at 09:16:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4209830) -- One Last Hand
-- MAIN APP DEPOTS
addappid(4209831, 1, "a55418e80d365b141892fdf2e13b7179a226fcae7c7b4453bed4df876ebd3a8e") -- Depot 4209831
setManifestid(4209831, "26309749977907359", 741650670)