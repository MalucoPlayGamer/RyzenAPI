-- Lua provided by RyzenAPI
-- Game: OVIVO

-- MAIN APPLICATION
addappid(597700)

-- MAIN APP DEPOTS / PACKAGES
addappid(597702,0,"e3e1d1562c835b03136bc4c25674e6d31f575fd66666823643c215a9e197f1ce")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(635870)
