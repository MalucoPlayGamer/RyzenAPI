-- Lua provided by RyzenAPI
-- Game: AppID 685690

-- MAIN APPLICATION
addappid(685690)

-- MAIN APP DEPOTS / PACKAGES
addappid(685691, 1, "1969da04eeb78b7c6a58c2161cf5636d9fff2eb7001b03abcd7b4157032b8f8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
