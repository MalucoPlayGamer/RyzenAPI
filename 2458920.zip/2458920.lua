-- Lua provided by RyzenAPI
-- Game: Game: WAGON

-- MAIN APPLICATION
addappid(2458920)
-- Game: addappid(2458920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458921, 1, "fa5884ee0863fe369eabe15d05b262d8679038ee00c9582819a92a644a3e85f6")
