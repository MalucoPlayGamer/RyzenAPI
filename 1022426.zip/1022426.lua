-- Lua provided by RyzenAPI
-- Game: DFF NT: Arc Sword, Tidus's 4th Weapon

-- MAIN APPLICATION
addappid(1022426)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022426,0,"4ed397e1bbec5cd929206c4eafe8dde4d101ce7d2e8f8c8e259c65b0d24c70c7")

