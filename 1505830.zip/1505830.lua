-- Lua provided by RyzenAPI
-- Game: Game: Evil Shogun

-- MAIN APPLICATION
addappid(1505830)
-- Game: addappid(1505830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505831, 1, "78e7472501d7a53056fd814084d78b9bdad4de43f4df002b76b7752eb8d604c2")
