-- Lua provided by RyzenAPI
-- Game: addappid(3857280)

-- MAIN APPLICATION
addappid(3857280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3857281, 1, "170e007f3a8a97a5b79949ec9b13050ceddaa6e90a4cdf9c987b591afb8885c3")
