-- 4031460's Lua and Manifest Created by Hubcap Manifest
-- Harem vs Zombies
-- Created: August 07, 2026 at 23:03:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(4031460, 1, "2676ae7c733cda747820f90c4d5db21722ee0375349714ae882dbff3fec1dd04") -- Harem vs Zombies
-- MAIN APP DEPOTS
addappid(4031461, 1, "f5ba8e61baa2bd251b7300364dee3d2bbef0405f08fe4c38d29554fff2dd5dcf") -- Depot 4031461
setManifestid(4031461, "5984815464172625617", 4441102232)
-- DLCS WITH DEDICATED DEPOTS
-- Harem vs Zombies - Artbook (AppID: 4630310)
addappid(4630310)
addappid(4630311, 1, "8180f914d3358829ecb6d09d4ae80df6ed7877280de6a4c06ce6530991a22df3") -- Harem vs Zombies - Artbook - Depot 4630311
setManifestid(4630311, "1742684713930903693", 42235033)
-- Harem vs Zombies - Wallpapers Pack (AppID: 4630320)
addappid(4630320)
addappid(4630321, 1, "336f52d0d473edde670f83b637246a748edf55a7ea735abdf1d102a6e983b59b") -- Harem vs Zombies - Wallpapers Pack - Depot 4630321
setManifestid(4630321, "192665762715836157", 241499287)
-- Harem vs Zombies - Animations Pack (AppID: 4630330)
addappid(4630330)
addappid(4630331, 1, "77c7fb79ff9ae04e2c1605e0c6059232b459f8154ce0c0b6ee8e939d00c01ea4") -- Harem vs Zombies - Animations Pack - Depot 4630331
setManifestid(4630331, "4053204173320264697", 1524053773)