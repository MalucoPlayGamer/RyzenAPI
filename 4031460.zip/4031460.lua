-- Lua provided by RyzenAPI
-- Game: Harem vs Zombies

-- MAIN APPLICATION
addappid(4630310)
addappid(4630320)
addappid(4630330)

-- MAIN APP DEPOTS / PACKAGES
addappid(4031460, 1, "2676ae7c733cda747820f90c4d5db21722ee0375349714ae882dbff3fec1dd04") -- Harem vs Zombies
addappid(4031461, 1, "f5ba8e61baa2bd251b7300364dee3d2bbef0405f08fe4c38d29554fff2dd5dcf") -- Depot 4031461
addappid(4630311, 1, "8180f914d3358829ecb6d09d4ae80df6ed7877280de6a4c06ce6530991a22df3") -- Harem vs Zombies - Artbook - Depot 4630311
addappid(4630321, 1, "336f52d0d473edde670f83b637246a748edf55a7ea735abdf1d102a6e983b59b") -- Harem vs Zombies - Wallpapers Pack - Depot 4630321
addappid(4630331, 1, "77c7fb79ff9ae04e2c1605e0c6059232b459f8154ce0c0b6ee8e939d00c01ea4") -- Harem vs Zombies - Animations Pack - Depot 4630331

