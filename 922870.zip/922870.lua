-- Lua provided by RyzenAPI
-- Game: Final Hope

-- MAIN APPLICATION
addappid(922870)

-- MAIN APP DEPOTS / PACKAGES
addappid(922871, 1, "b24e7ce5581a0b3cf2dd663a72e3a1a2d3ebb1e5152c826a934d13054edf2920")
