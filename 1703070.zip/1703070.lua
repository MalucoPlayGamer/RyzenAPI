-- Lua provided by RyzenAPI
-- Game: Airborne Ranger

-- MAIN APPLICATION
addappid(1703070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703071, 1, "bee44a663179c140484f40a31814e0304de4661d62df917018a02db67d6aa995")
addappid(1703072, 1, "a8060d5ac693007c264334e739a88fbb986e8a49cce57eef4bdd644f37bf90a0")

