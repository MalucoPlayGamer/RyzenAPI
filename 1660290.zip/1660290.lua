-- Lua provided by RyzenAPI
-- Game: Monmusu Gladiator

-- MAIN APPLICATION
addappid(1660290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660291, 1, "810fb68d74fe9736b0e3e5b12317f4d37345aae1caee162b441af10361137487")

