-- Lua provided by RyzenAPI
-- Game: addappid(1599410)

-- MAIN APPLICATION
addappid(1599410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599411, 1, "a1f5762febef38421efe15caefca9bb2cb4b112be7b417db42a2aa64ae685788")
