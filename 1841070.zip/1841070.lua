-- Lua provided by RyzenAPI
-- Game: 1841070

-- MAIN APPLICATION
addappid(1841070)
-- Game: addappid(1841070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841071, 1, "05a76bfdc96085a9addf13dbcdaf2e22522ada9de25e925147072de9e0773c66")
