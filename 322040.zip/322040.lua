-- Lua provided by RyzenAPI
-- Game: 322040

-- MAIN APPLICATION
addappid(322040)
-- Game: addappid(322040)

-- MAIN APP DEPOTS / PACKAGES
addappid(322041, 1, "283ca71d874ddb54ffb92b21310231c9b19896c825f52811e0b1ddb254a14741")
