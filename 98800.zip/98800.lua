-- Lua provided by RyzenAPI
-- Game: Game: Dungeons of Dredmor

-- MAIN APPLICATION
addappid(98800)
-- Game: addappid(98800)

-- MAIN APP DEPOTS / PACKAGES
addappid(98801, 1, "f2fdd1c79c4fa60e730b17e4d532e7805da7a7c3e4ec1d131f77ff69265651f7")
addappid(98802, 1, "4026482385f48e9dad18fcb50dd3323719bde219d0f56c1449caa88134a282a5")
addappid(98803, 1, "dad26f78b7353eee200b3ae1698b544a1f117134167549ba84b74e675c1c9e10")
addappid(98820, 1, "f19b59bce695036ec726c1968627ab86484be4abca76e89e96596cea16d14ea6")
addappid(98821, 0, "60fc5e86e42d8a00cd81d7fa7deb090af3bc573a3ec14a8016efc207de3e2604")
addappid(98822, 0, "f5c6e6d71bb85078203a7d9f262ff26a124f7f440dd4f2b47269242a9ea7d839")
