-- Lua provided by RyzenAPI
-- Game: Serious Sam Classics: Revolution

-- MAIN APPLICATION
addappid(227780)
addappid(228983)
addappid(228985)
addappid(228990)
addappid(229003)
-- Game: addappid(227780)

-- MAIN APP DEPOTS / PACKAGES
addappid(227781, 1, "6ed9b14a08787ef23980d57124a670df48bc35feb1642ce6857b9e4a035853ed")
addappid(227782, 1, "08c08404f83375b1a687457640efc658ef722cca9fc933fd5bbe12ec3a20c6f1")
