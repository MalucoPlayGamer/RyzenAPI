-- Lua provided by RyzenAPI
-- Game: addappid(2128720)

-- MAIN APPLICATION
addappid(2128720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128721, 1, "65a8d1168e78107156e0fb9b1f4ebd59aa0435708ef2e42a729b54f7744ac665")
addappid(2128722, 1, "58a441f8c5d2e66ddab7ab0552007032d2352d892cdfdc2ccdfe2a4588e8a9df")
