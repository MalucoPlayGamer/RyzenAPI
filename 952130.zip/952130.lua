-- Lua provided by RyzenAPI
-- Game: Origin of Decay

-- MAIN APPLICATION
addappid(952130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(952131, 1, "277c8e9ab3557582c9f0160c2509941d27e2dd488d593892aeb3738ef8dceddf")

