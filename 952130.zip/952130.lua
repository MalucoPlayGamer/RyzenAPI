-- Lua provided by RyzenAPI
-- Game: AppID 952130

-- MAIN APPLICATION
addappid(952130)
-- Game: addappid(952130)

-- MAIN APP DEPOTS / PACKAGES
addappid(952131, 1, "277c8e9ab3557582c9f0160c2509941d27e2dd488d593892aeb3738ef8dceddf")
