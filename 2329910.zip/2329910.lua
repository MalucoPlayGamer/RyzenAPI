-- Lua provided by RyzenAPI
-- Game: Game: SCP Operations

-- MAIN APPLICATION
addappid(2329910)
-- Game: addappid(2329910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2329911, 1, "a2352b45bbee10d7434f0c963fe4da8947ef4b71916933352a75aea9448b41f4")
