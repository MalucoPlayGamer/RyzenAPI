-- Lua provided by RyzenAPI
-- Game: Vibe Clicker

-- MAIN APPLICATION
addappid(3813330)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4044800)
