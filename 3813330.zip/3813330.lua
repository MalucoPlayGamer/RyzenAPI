-- Lua provided by RyzenAPI
-- Game: Vibe Clicker

-- MAIN APPLICATION
addappid(3813330)
