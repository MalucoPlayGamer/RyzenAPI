-- Lua provided by RyzenAPI
-- Game: Dolly Wars - Auto Tactics

-- MAIN APPLICATION
addappid(1119480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119481, 1, "8f5863aad477030774cf998e6dd008a9b5ef4362063ad081a73b7280a553aa4a")
addappid(1119482, 1, "2fa8fa9e13525d4651de4b5e09db1db68f1f9ba524816021a889b8a9cfdf0b68")
addappid(2213080, 0, "d7f0234395990e46f643d17f5caad382cb88ccb49fa089d76137f99d102c0a1d")
