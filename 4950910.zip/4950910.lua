-- 4950910's Lua and Manifest Created by Hubcap Manifest
-- 异星弹雨
-- Created: August 05, 2026 at 13:23:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4950910) -- 异星弹雨
-- MAIN APP DEPOTS
addappid(4950911, 1, "5ff3815e2b4baf8c02d9534bb213f6d1f80b2c332f99eee587885830141b3b98") -- Depot 4950911
setManifestid(4950911, "4655770034163007574", 244761746)