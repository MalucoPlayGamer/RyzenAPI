-- Lua provided by SkyAPI 
-- Game: Lutnak·Quest
addappid(2766940)
addappid(2766941, 1, "fe7fc8a54a7e6af6d261d6f258d8a83cb7d441a181ca6c3e480c8277637027c9")
addappid(2766942, 1, "7d1e17f9eab10d36b46553e0befa9ce8fda7a62004cc89777ffa37b730dce806")
addappid(2766943, 1, "a58c0b21ccecaa79733257b88cb92c704318d1487bce989050b7f3adfcfae3cc")
