-- Lua provided by RyzenAPI
-- Game: Among Trees

-- MAIN APPLICATION
addappid(897730)

-- MAIN APP DEPOTS / PACKAGES
addappid(897731, 1, "72759c9bdf97c55274415c971be24807e7de2583b2c80b47de1658981ac1dca4")

