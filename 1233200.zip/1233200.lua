-- Lua provided by RyzenAPI
-- Game: addappid(1233200)

-- MAIN APPLICATION
addappid(1233200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233201, 1, "a52e98e8a98ac324f73b30a1789c95a9d819bd8e3c3283d3d09695eed89ea440")
