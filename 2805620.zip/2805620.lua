-- Lua provided by RyzenAPI
-- Game: Animals vs Animals

-- MAIN APPLICATION
addappid(2805620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805621, 1, "f8745cd04f193e1151eeb4b88ad7a70f692146921eed6fe0b29c50b213f41a7b")
