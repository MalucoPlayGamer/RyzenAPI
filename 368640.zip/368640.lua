-- Lua provided by RyzenAPI
-- Game: htoL#NiQ: The Firefly Diary

-- MAIN APPLICATION
addappid(368640)

-- MAIN APP DEPOTS / PACKAGES
addappid(368641, 1, "3ec9a8f870e0d220f32a59071e1c995b0849989f02f3f1243e297fd3f8c10751")
addappid(535970, 0, "bf59c04cbfae53a205fc5633dfb89f16b194182f51add5a4d0b8dee96241eff5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
