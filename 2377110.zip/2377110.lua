-- Lua provided by RyzenAPI 
-- Game: Pocket Waifu Rekindled 🔞[ADULT NSFW]
addappid(2377110)
addappid(2377111, 1, "8e769cebc5a855d1d3b70dad3fa2a956bd4f8c5afaf97a8ff68e1f0ca904e878")
