-- Lua provided by RyzenAPI
-- Game: Game: Pocket Waifu Rekindled 🔞[ADULT NSFW]

-- MAIN APPLICATION
addappid(2377110)
-- Game: addappid(2377110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377111, 1, "8e769cebc5a855d1d3b70dad3fa2a956bd4f8c5afaf97a8ff68e1f0ca904e878")
