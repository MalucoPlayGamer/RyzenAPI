-- Lua provided by RyzenAPI
-- Game: Tiny Football

-- MAIN APPLICATION
addappid(1887010)
-- Game: addappid(1887010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887011, 1, "d3397a602387302442226d20e158b18ec8f0c58c76a13dda14afe9860477bfa7")
