-- Lua provided by RyzenAPI
-- Game: WARRIORS: Abyss - SAMURAI WARRIORS Western Japan Classic Costume Set

-- MAIN APPLICATION
addappid(3358140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358140,0,"5d84acaacba8f481033a57f86abbc5d6d025f677f8a05544851fcc83c47c11cc")
