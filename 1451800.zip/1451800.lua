-- Lua provided by RyzenAPI
-- Game: Super vs. World

-- MAIN APPLICATION
addappid(1451800)
-- Game: addappid(1451800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451801, 1, "00fc2d5a5948020d04fd3254fa29aa3c88b0ce663f1f313246388cfaac46e7ef")
