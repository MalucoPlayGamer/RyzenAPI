-- Lua provided by RyzenAPI
-- Game: addappid(1270910)

-- MAIN APPLICATION
addappid(1270910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270911, 1, "ab97f602b6244e6d158445abd6f9206d73e502d00eb578cd0605525dc2b5bfd3")
