-- Lua provided by RyzenAPI
-- Game: AppID 1181000

-- MAIN APPLICATION
addappid(1181000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181001, 1, "d992b7d6ab154273e037bab25437a36c2fcec57a14ca0cccededcf92896e9ce7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
