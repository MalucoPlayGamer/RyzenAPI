-- Lua provided by RyzenAPI
-- Game: addappid(1181000)

-- MAIN APPLICATION
addappid(1181000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181001, 1, "d992b7d6ab154273e037bab25437a36c2fcec57a14ca0cccededcf92896e9ce7")
