-- Lua provided by RyzenAPI
-- Game: addappid(1694700)

-- MAIN APPLICATION
addappid(1694700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694701, 1, "e7d309cebaa11a34351fa89125f789d5598e9ce04b254d484410af483aa75c73")
