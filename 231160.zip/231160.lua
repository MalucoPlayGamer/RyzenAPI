-- Lua provided by RyzenAPI
-- Game: The Swapper

-- MAIN APPLICATION
addappid(231160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(231161, 1, "e6812325d6c6299b4f4c2af217c1061b5ef6a50bebc4707cd49ec680ac9fcfc7")
addappid(231163, 1, "fd030fd481bc1dab38c113c92e3b65ff30e650454ee193454e2991d5dfeebf8c")

