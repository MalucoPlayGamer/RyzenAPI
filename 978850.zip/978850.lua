-- Lua provided by RyzenAPI
-- Game: addappid(978850)

-- MAIN APPLICATION
addappid(978850)

-- MAIN APP DEPOTS / PACKAGES
addappid(978850,0,"64502944ca1b11a96cf44ee30baca62d702e190064d295f60f28e97485e083cb")
