-- Lua provided by RyzenAPI
-- Game: HENTAI PUZZLE

-- MAIN APPLICATION
addappid(914850)
-- Game: addappid(914850)

-- MAIN APP DEPOTS / PACKAGES
addappid(914851, 1, "e8f5a7499de06086cd672285c728e58b23ac58c8eaca5de51724b70a7d830de0")
