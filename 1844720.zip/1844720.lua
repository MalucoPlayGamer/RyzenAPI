-- Lua provided by RyzenAPI
-- Game: Friendsim 2

-- MAIN APPLICATION
addappid(1844720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844721, 1, "22e68ae9f8b3c3eb5605cc1ee153cc94053c4cb6d14addea50090684f572d357")
addappid(1844722, 1, "aea927dee7d715b899d5d876c89b686b02d10c3b71066c5150f4508b20d85e6f")
