-- Lua provided by RyzenAPI
-- Game: Superhero Girls

-- MAIN APPLICATION
addappid(2113650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2113651, 1, "e1be8da66d0d6e7da49a38197e76f0e7a86beab40e72a41356d6377b78fa1a2b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2129770)
