-- Lua provided by RyzenAPI
-- Game: Mocap Fusion [ VR ]

-- MAIN APPLICATION
addappid(1540000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540001,0,"a2845dcecdc62cbb20da8e256535fb77bf7738d08bed5a1abd7457d05a1376be")

