-- Lua provided by RyzenAPI
-- Game: The Legend of Dark Witch Renovation

-- MAIN APPLICATION
addappid(1160790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160791, 1, "563ba0e09bf2094ac91b72f06927bbeee4cc089c68dc371039c00f42d645cd60")
