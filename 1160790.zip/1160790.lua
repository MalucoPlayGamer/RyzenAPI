-- Lua provided by SkyAPI 
-- Game: The Legend of Dark Witch Renovation
addappid(1160790)
addappid(1160791, 1, "563ba0e09bf2094ac91b72f06927bbeee4cc089c68dc371039c00f42d645cd60")
