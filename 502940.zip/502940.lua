-- Lua provided by SkyAPI 
-- Game: AppID 502940
addappid(502940)
addappid(502941, 1, "72d5bd980198dee8fc87b7ad8863f9395de33885b57ed8b7ecfecdbf193d8155")
addappid(502942, 1, "eddbe0d807b98933a1f1fdd89fd6ca5ed7305aee8a69d4aeff83d9b93ec869d9")
addappid(502943, 1, "c3223d15b6931ae2092cef3ea206bff401c619096d8cfd4cc020201e80283f73")
