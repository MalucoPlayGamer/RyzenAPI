-- Lua provided by RyzenAPI
-- Game: AppID 502940

-- MAIN APPLICATION
addappid(502940)

-- MAIN APP DEPOTS / PACKAGES
addappid(502941, 1, "72d5bd980198dee8fc87b7ad8863f9395de33885b57ed8b7ecfecdbf193d8155")
addappid(502942, 1, "eddbe0d807b98933a1f1fdd89fd6ca5ed7305aee8a69d4aeff83d9b93ec869d9")
addappid(502943, 1, "c3223d15b6931ae2092cef3ea206bff401c619096d8cfd4cc020201e80283f73")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
