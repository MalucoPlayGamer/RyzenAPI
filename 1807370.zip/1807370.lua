-- Lua provided by RyzenAPI
-- Game: Game: Maverta City

-- MAIN APPLICATION
addappid(1807370)
-- Game: addappid(1807370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807371, 1, "a6fb728fe1e83d7c947a2093840298699cbe2b7b00e50394ca34fb887572ebf2")
addappid(1807372, 1, "033ef535075ac0dd276791ab1f3995c2a25888942b9c46214d818dab364d6dca")
