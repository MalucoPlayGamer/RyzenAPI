-- Lua provided by RyzenAPI
-- Game: addappid(475100)

-- MAIN APPLICATION
addappid(475100)

-- MAIN APP DEPOTS / PACKAGES
addappid(475101, 1, "3e9fe8a1aea91be872c5ba57b2ce63a9fac437db18bcdfc0aebf3e38251f6a26")
