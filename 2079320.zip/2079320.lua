-- Lua provided by RyzenAPI
-- Game: 异世界幸存者 Other World Survivors

-- MAIN APPLICATION
addappid(2079320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079321, 1, "14faddd94af3abac8e53f57459a14542b3e5f2c63035010324d0a38df51fcacf")
