-- Lua provided by RyzenAPI
-- Game: 3205400

-- MAIN APPLICATION
addappid(3205400)
-- Game: addappid(3205400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205401, 1, "30449905fe4e3960351653aa93ddbbcf1802dcfa7e727da4de6fe4b554ece9e6")
