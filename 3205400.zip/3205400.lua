-- Lua provided by SkyAPI 
-- Game: Hers' Alms
addappid(3205400)
addappid(3205401, 1, "30449905fe4e3960351653aa93ddbbcf1802dcfa7e727da4de6fe4b554ece9e6")
