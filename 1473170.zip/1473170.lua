-- Lua provided by SkyAPI 
-- Game: Aircraft Sketch Shooter
addappid(1473170)
addappid(1473171, 1, "952337b759766fb64f581d3350b8621845ca2d907fe760f69395e31ad1352c9d")
