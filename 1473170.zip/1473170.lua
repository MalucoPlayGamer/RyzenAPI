-- Lua provided by RyzenAPI
-- Game: Aircraft Sketch Shooter

-- MAIN APPLICATION
addappid(1473170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473171, 1, "952337b759766fb64f581d3350b8621845ca2d907fe760f69395e31ad1352c9d")
