-- Lua provided by RyzenAPI
-- Game: Blood: Refreshed Supply™

-- MAIN APPLICATION
addappid(3884520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3884521,0,"44cfbee662c5cc15f9ac8eab8502b783c8a900f07a4ad7a041c7164f96f436c6")
addappid(3884522,0,"9fec710d8fde9145e3b21c5ac58c865f913f7c295032c57827af89794d62de17")

