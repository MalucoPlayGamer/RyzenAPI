-- Lua provided by RyzenAPI
-- Game: Apex Heroines - Game Grape	电玩葡萄

-- MAIN APPLICATION
addappid(2743680)
-- Game: addappid(2743680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743680,0,"edca05a66f667d9c427c13366185b074d9444828f0c03c7fe6e0764239e8a4a5")
