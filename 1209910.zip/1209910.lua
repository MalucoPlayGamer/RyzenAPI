-- Lua provided by RyzenAPI
-- Game: Game: Britannic

-- MAIN APPLICATION
addappid(1209910)
-- Game: addappid(1209910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209911, 1, "89e85784a05e31d84722efc0b108e9253d5587fb2e55f2ff16002c146c7c8390")
