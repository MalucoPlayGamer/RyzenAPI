-- Lua provided by RyzenAPI
-- Game: RACCOIN: Coin Pusher Roguelike

-- MAIN APPLICATION
addappid(3784030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3784031,0,"b7bfd29859fb8492a8b2cd4c476184e3ade362bbc50eaec4a7be6b45a02e0d4d")

