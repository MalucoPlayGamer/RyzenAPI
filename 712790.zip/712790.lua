-- Lua provided by RyzenAPI
-- Game: Crimson Memories

-- MAIN APPLICATION
addappid(712790)

-- MAIN APP DEPOTS / PACKAGES
addappid(712791, 1, "d330ca5603c9c057e96fecc4c38de298a667ed8432f04614ce037a2b2ef4bb9d")
