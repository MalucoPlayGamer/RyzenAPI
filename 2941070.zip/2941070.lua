-- Lua provided by RyzenAPI
-- Game: Meme Mayhem Demo

-- MAIN APPLICATION
addappid(2941070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941071, 1, "63e4409fba8594b07fa9bbe8f2ac619e0a82a39a20d7b1e96e46e46d0aa703bf")

