-- Lua provided by RyzenAPI
-- Game: Project Heartbeat

-- MAIN APPLICATION
addappid(1216230)
-- Game: addappid(1216230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216231, 1, "874c2f5429e5d76c0493db0ef7b9da3dc62913e6a64d8371d192a31b573fefbf")
