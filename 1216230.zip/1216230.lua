-- Lua provided by RyzenAPI
-- Game: Project Heartbeat

-- MAIN APPLICATION
addappid(1216230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(1216231, 1, "874c2f5429e5d76c0493db0ef7b9da3dc62913e6a64d8371d192a31b573fefbf")

