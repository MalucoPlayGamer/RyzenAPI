-- Lua provided by RyzenAPI
-- Game: Miasma Chronicles

-- MAIN APPLICATION
addappid(1649010)
addappid(2586980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649011, 1, "37e12969216f3718cbc3da5252107bb96e8ea10bea2e65c6edc91b5d632345ec")

