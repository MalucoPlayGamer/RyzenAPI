-- Lua provided by RyzenAPI
-- Game: The Wizards

-- MAIN APPLICATION
addappid(586950)
addappid(729500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(586951, 1, "59480c61807ec36e897fc85582adefe74e22fdf6715e3de266db2554ce2af8af")
addappid(586952, 1, "303dee7108059e631397fd5d029455ba55e40333c21d2dd1f7573f28f6b148ff")
addappid(586953, 1, "afa961f03e84a603bd7a4c67d78f3fe597c3571e6c902e3069156e8c71af7325")

