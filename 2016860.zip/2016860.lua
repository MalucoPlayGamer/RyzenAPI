-- Lua provided by RyzenAPI
-- Game: The Backrooms World Demo

-- MAIN APPLICATION
addappid(2016860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016861, 1, "8529d26ecbcee782acf1d92a7c466ec8c3409392340bc8ceb8050bb01d842887")

