-- Lua provided by RyzenAPI
-- Game: Game: The Citadel Demo

-- MAIN APPLICATION
addappid(1378300)
-- Game: addappid(1378300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378301, 1, "37866d17e3c9bb57a10929f513628c0274c40541d7c5ef14b3e2df9059085343")
