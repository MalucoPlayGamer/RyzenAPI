-- Lua provided by RyzenAPI
-- Game: 1757640

-- MAIN APPLICATION
addappid(1757640)
-- Game: addappid(1757640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757641, 1, "2db3dcfdebdb61de007f96f815b2763dea289f1961bb8c66ab9e75c4f2df06fe")
