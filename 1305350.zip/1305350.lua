-- Lua provided by SkyAPI 
-- Game: C-4
addappid(1305350)
addappid(1305351, 1, "141eb3ef8ffb87dda2c1b499a8295f327231567d2b2de3c95d2e5362c86a8378")
