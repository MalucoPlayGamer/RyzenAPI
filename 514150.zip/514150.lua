-- Lua provided by RyzenAPI
-- Game: Line of Sight: Vietnam

-- MAIN APPLICATION
addappid(514150)

-- MAIN APP DEPOTS / PACKAGES
addappid(514151, 1, "fb346e6d679560d67838926f6dac71a6e39e9041486d916435409c3355010d82")

