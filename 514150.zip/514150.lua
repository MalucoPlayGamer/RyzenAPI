-- Lua provided by RyzenAPI
-- Game: Line of Sight: Vietnam

-- MAIN APPLICATION
addappid(514150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(514151, 1, "fb346e6d679560d67838926f6dac71a6e39e9041486d916435409c3355010d82")

