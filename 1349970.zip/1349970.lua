-- Lua provided by RyzenAPI
-- Game: Tomai

-- MAIN APPLICATION
addappid(1349970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349973,0,"ad715064101f2f8e1302b20cc448a61f9ad5dc25fe5a41d6633aa0112b352c5a")
addappid(1349974,0,"5558ed5454f38ec74eaf841cd7063afe72319a569247a43b0445b63796a4b03a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1395590)
