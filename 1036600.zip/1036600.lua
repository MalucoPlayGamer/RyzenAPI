-- Lua provided by RyzenAPI
-- Game: Junglex

-- MAIN APPLICATION
addappid(1036600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036601, 1, "ce20068d2d27cfd1bb3267deb3212908f930c16387f7a227f868b758991be0d9")

