-- Lua provided by SkyAPI 
-- Game: IT Simulator
addappid(1903730)
addappid(1903731, 1, "6fc09268771552b1bbb529ac51ab0f9909a8beb111dba9c55066a14500b77804")
