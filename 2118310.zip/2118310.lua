-- Lua provided by SkyAPI 
-- Game: AppID 2118310
addappid(2118310)
addappid(2118311, 1, "87efb1417ca40d31dd49fc8b74dee6b2fa2293d2f2f6de1d2dcfefcf87a6983b")
