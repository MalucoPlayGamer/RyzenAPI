-- Lua provided by RyzenAPI
-- Game: Game: AppID 2118310

-- MAIN APPLICATION
addappid(2118310)
-- Game: addappid(2118310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118311, 1, "87efb1417ca40d31dd49fc8b74dee6b2fa2293d2f2f6de1d2dcfefcf87a6983b")
