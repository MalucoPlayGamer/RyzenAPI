-- Lua provided by RyzenAPI
-- Game: Game: AppID 1297140

-- MAIN APPLICATION
addappid(1297140)
-- Game: addappid(1297140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297141, 1, "99e800aaf578bbdc32b44bc101d35f03a85a177740f8598229ea9869f2a6d4f1")
