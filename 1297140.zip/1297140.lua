-- Lua provided by RyzenAPI 
-- Game: AppID 1297140
addappid(1297140)
addappid(1297141, 1, "99e800aaf578bbdc32b44bc101d35f03a85a177740f8598229ea9869f2a6d4f1")
