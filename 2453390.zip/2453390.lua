-- Lua provided by RyzenAPI
-- Game: Settler's Odyssey

-- MAIN APPLICATION
addappid(2453390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453391, 1, "a5bae7a85957ead291304a35b30e9a5db6dc3f64b2f6e20ea856d1ea9f9b48e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
