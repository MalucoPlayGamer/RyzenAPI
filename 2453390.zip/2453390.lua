-- Lua provided by RyzenAPI
-- Game: addappid(2453390)

-- MAIN APPLICATION
addappid(2453390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453391, 1, "a5bae7a85957ead291304a35b30e9a5db6dc3f64b2f6e20ea856d1ea9f9b48e2")
