-- Lua provided by RyzenAPI
-- Game: Existence

-- MAIN APPLICATION
addappid(806550)

-- MAIN APP DEPOTS / PACKAGES
addappid(806551, 1, "58b83d800b4a2cd8401b1298bd8b9a26ad2746974dd4e5f599b085e738de5b47")
