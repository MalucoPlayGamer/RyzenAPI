-- Lua provided by SkyAPI 
-- Game: CosmoPirates
addappid(2466240)
addappid(2466241, 1, "a2b7da018a5253d773438a827c250027115cb4dec967fdbe6ef3d61442ce4627")
