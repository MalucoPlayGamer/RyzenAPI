-- Lua provided by RyzenAPI
-- Game: Nebula Within Soundtrack

-- MAIN APPLICATION
addappid(1507460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507461, 1, "af5380426b2e1bcda83290368c6d5f90075ee4b5ab3c9c95018ea3e0c0d214d7")
addappid(1507462, 1, "7c965fd7fb40f830968e6aca8a7d77e6a9ab72261197ada00f929b997e9156b1")

