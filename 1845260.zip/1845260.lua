-- Lua provided by RyzenAPI
-- Game: addappid(1845260)

-- MAIN APPLICATION
addappid(1845260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845261, 1, "63d77a8119da21090fa736840707e367b4c2f0593ff25e0cb37a46523d8ecbae")
