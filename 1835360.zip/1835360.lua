-- Lua provided by RyzenAPI
-- Game: addappid(1835360)

-- MAIN APPLICATION
addappid(1835360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835361, 1, "156c3d39cafe498787294bdb5e83fd36a120578b1a81b9c36009eec6164cb3c9")
