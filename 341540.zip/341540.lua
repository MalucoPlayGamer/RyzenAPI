-- Lua provided by RyzenAPI
-- Game: TRIP Steam Edition

-- MAIN APPLICATION
addappid(341540)

-- MAIN APP DEPOTS / PACKAGES
addappid(341541, 1, "4f4c561785f0396e1ea9d338da11d92bd4c75231990cbe6cedf8a62a9b2243e1")
