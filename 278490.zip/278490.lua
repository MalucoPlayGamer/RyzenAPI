-- Lua provided by RyzenAPI
-- Game: addappid(278490)

-- MAIN APPLICATION
addappid(278490)

-- MAIN APP DEPOTS / PACKAGES
addappid(278491, 1, "ed1688697193bf6ba264db949da867e06d2235442d77175a45a8727a6daf0fab")
