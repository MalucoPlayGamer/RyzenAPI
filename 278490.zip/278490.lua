-- Lua provided by SkyAPI 
-- Game: Aveyond 3-2: Gates of Night
addappid(278490)
addappid(278491, 1, "ed1688697193bf6ba264db949da867e06d2235442d77175a45a8727a6daf0fab")
