-- Lua provided by RyzenAPI
-- Game: addappid(3530120)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(3530120)
addappid(3530125)

-- MAIN APP DEPOTS / PACKAGES
addappid(3530123,0,"0933170051dc2bd6b4024c08e8c0ed12685fde478ddade850ef61af02c865ec7")
