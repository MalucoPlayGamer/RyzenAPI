-- Lua provided by RyzenAPI
-- Game: Aztlan Uncovered: Prologue

-- MAIN APPLICATION
addappid(1873510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873511, 1, "d659c417aa3971da331e0d604697fe8f189b4166ab38b27677e43cbe1f1fdd16")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
