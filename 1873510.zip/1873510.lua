-- Lua provided by RyzenAPI
-- Game: 1873510

-- MAIN APPLICATION
addappid(1873510)
-- Game: addappid(1873510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873511, 1, "d659c417aa3971da331e0d604697fe8f189b4166ab38b27677e43cbe1f1fdd16")
