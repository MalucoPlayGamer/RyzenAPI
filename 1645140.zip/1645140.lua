-- Lua provided by RyzenAPI
-- Game: Apple Bang!

-- MAIN APPLICATION
addappid(1645140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645141, 1, "ed7b6764748560cfa7243049da02a36e9042a0be60ff2f58648f5abee228bf5d")

