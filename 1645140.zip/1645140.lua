-- Lua provided by RyzenAPI
-- Game: Apple Bang!

-- MAIN APPLICATION
addappid(1645140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1645141, 1, "ed7b6764748560cfa7243049da02a36e9042a0be60ff2f58648f5abee228bf5d")

