-- Lua provided by RyzenAPI
-- Game: Age of Giants

-- MAIN APPLICATION
addappid(817390)

-- MAIN APP DEPOTS / PACKAGES
addappid(817391,0,"fc545de703a8b507dc49b7b74b89d5aa4cc0d7ed6e092b9b323eb1df350de6a3")

