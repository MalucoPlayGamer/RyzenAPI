-- Lua provided by RyzenAPI
-- Game: VPet - ModMaker

-- MAIN APPLICATION
addappid(2639250)
-- Game: addappid(2639250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639250,0,"ea76ffc614979026368548287258e7c179eba210d6b7b9b1136fc47888eae322")
