-- Lua provided by RyzenAPI
-- Game: addappid(447920)

-- MAIN APPLICATION
addappid(447920)

-- MAIN APP DEPOTS / PACKAGES
addappid(447921, 1, "1a8a0afd095d0a3dc6d470f5dfdd409aa6d0488b8392c79dda08f67b33de0d0f")
