-- Lua provided by RyzenAPI
-- Game: Game: Femboy Aim Trainer

-- MAIN APPLICATION
addappid(2415960)
-- Game: addappid(2415960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415961, 1, "136ca349937c558c370282d1d8a8a3826d4b3c7e92b0444cf49c9d5f3d6b301c")
