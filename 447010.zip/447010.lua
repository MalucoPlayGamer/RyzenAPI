-- Lua provided by RyzenAPI
-- Game: Bird of Light

-- MAIN APPLICATION
addappid(447010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(447011, 1, "977accd50098deca48fb4e6ef2d06261abd2336967b3aff68bf12344c2445f87")

