-- Lua provided by RyzenAPI
-- Game: Game: Bird of Light

-- MAIN APPLICATION
addappid(447010)
-- Game: addappid(447010)

-- MAIN APP DEPOTS / PACKAGES
addappid(447011, 1, "977accd50098deca48fb4e6ef2d06261abd2336967b3aff68bf12344c2445f87")
