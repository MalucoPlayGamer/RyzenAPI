-- Lua provided by RyzenAPI
-- Game: Doorways: Prelude

-- MAIN APPLICATION
addappid(248470)
addappid(526570)
addappid(526571)
addappid(526572)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(248471, 1, "e38e692f21a18e454003b85f16d27ac1bc011b9311387a7e0264500fa137835e")
addappid(248472, 1, "732fffb75f492623cee787e16761e1b907e07b122508b14c7d53a44f613c9f18")
addappid(248473, 1, "84d4e3f47bcd46ab3814bbc0d9ad4f4b5e7820561b5d10e641d288612aa235cc")

