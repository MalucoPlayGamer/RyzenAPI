-- Lua provided by RyzenAPI
-- Game: Back to Bed

-- MAIN APPLICATION
addappid(308040)

-- MAIN APP DEPOTS / PACKAGES
addappid(308041, 1, "78f6c4a5a78ec140925404aead896a89ceee94848f70f74f7d86c2409585bcb6")
addappid(308042, 1, "ee420bb58d06645a20292a78ee7b72a0361df687613859094b25923609d789bd")
addappid(308043, 1, "d7cfa81fa1de48053f1d0a79653df58a94298c5b860a8b8372618629b39dce81")
addappid(308044, 1, "4a5b3b71fc15ef42adce73ac0221e6db645c8a043830639c05f32203b48f6ba9")
addappid(308046, 1, "f30e5e7d0dfa5f7e69f25e553eecb37f5acac19f841af7b5a6a06d2f812f76d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
