-- Lua provided by RyzenAPI
-- Game: Drop Duchy Demo

-- MAIN APPLICATION
addappid(3112480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3112481, 1, "310e7da4cc49bfa0df0ead64b54f13c9bcc229dbcfa5d24a2eee72a47a824019")
