-- Lua provided by RyzenAPI
-- Game: Fashioning Little Miss Lonesome

-- MAIN APPLICATION
addappid(640990)

-- MAIN APP DEPOTS / PACKAGES
addappid(640991, 1, "ae9738498a3341254adf3b39241cd0e9183bce2f8a5e745ac79fd0960f64a6fe")
addappid(945760, 0, "0b17ed8089b152734715929c62afdfb2872dd1ce7f172b339d3e7b0f757b8b42")
