-- Lua provided by RyzenAPI
-- Game: Fashioning Little Miss Lonesome

-- MAIN APPLICATION
addappid(640990)

-- MAIN APP DEPOTS / PACKAGES
addappid(640991, 1, "ae9738498a3341254adf3b39241cd0e9183bce2f8a5e745ac79fd0960f64a6fe")
addappid(945760, 0, "0b17ed8089b152734715929c62afdfb2872dd1ce7f172b339d3e7b0f757b8b42")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
