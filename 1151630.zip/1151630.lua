-- Lua provided by RyzenAPI
-- Game: House of 1000 Doors: Family Secrets

-- MAIN APPLICATION
addappid(1151630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151631, 1, "9722152882c687ebcf39f8989bc4158b4460c95e7565758dc0fd13d4e474ca0b")

