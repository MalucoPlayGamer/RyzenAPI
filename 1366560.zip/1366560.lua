-- Lua provided by SkyAPI 
-- Game: MiLE HiGH TAXi
addappid(1366560)
addappid(1366561, 1, "a6e67362a2a2de8688a7b1b39f1f804441676321ba3b8f8272b7832166c85d89")
addappid(2510140)
