-- Lua provided by RyzenAPI
-- Game: MiLE HiGH TAXi

-- MAIN APPLICATION
addappid(1366560)
addappid(2510140)
-- Game: addappid(1366560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366561, 1, "a6e67362a2a2de8688a7b1b39f1f804441676321ba3b8f8272b7832166c85d89")
