-- Lua provided by RyzenAPI
-- Game: Game: Bigfield 2042

-- MAIN APPLICATION
addappid(1902120)
-- Game: addappid(1902120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902121, 1, "76b1f3d449f17d6cf481eef6be5afb8db9960afa49b1c9f725209f40ec578f85")
