-- Lua provided by RyzenAPI
-- Game: Please, Touch The Artwork 2

-- MAIN APPLICATION
addappid(2600140)
addappid(3350980)
addappid(3350990)
addappid(3351000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600141, 1, "1ba43b825e452eaa7cc26e080b46373491dbaa1201591556a747d8add784d85b")
addappid(2600142, 1, "2495db116ebbbc6aa97ca47dd1da39842dd1e3ea76daba50ba5a2fa0f73f0f9e")
addappid(2600143, 1, "89d5bce5a5251260540743531d07c85d6abd526b3a6e444f13b9f8e12eed4e81")

