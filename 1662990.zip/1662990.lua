-- Lua provided by RyzenAPI 
-- Game: Explosiver
addappid(1662990)
addappid(1662991, 1, "3bb6d6efbb73cca284e464cc71964e04bba14edea2dd630c8d241a41525c28ea")
