-- Lua provided by RyzenAPI
-- Game: 1662990

-- MAIN APPLICATION
addappid(1662990)
-- Game: addappid(1662990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662991, 1, "3bb6d6efbb73cca284e464cc71964e04bba14edea2dd630c8d241a41525c28ea")
