-- Lua provided by RyzenAPI
-- Game: addappid(499460)

-- MAIN APPLICATION
addappid(499460)

-- MAIN APP DEPOTS / PACKAGES
addappid(499461, 1, "a67acfca3f08bce854106051f54b148712dc23d22f93d0a55e7badda2df30a62")
