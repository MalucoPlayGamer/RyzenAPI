-- Lua provided by RyzenAPI
-- Game: Dark Dominance ~Chain Control~

-- MAIN APPLICATION
addappid(3122890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122891, 1, "2eaef0c5bd436a30169b775378846c1e0e1b1e2288682a4e7374ad13f3354dd8")
