-- Lua provided by RyzenAPI
-- Game: Game: AppID 3122890

-- MAIN APPLICATION
addappid(3122890)
-- Game: addappid(3122890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122891, 1, "2eaef0c5bd436a30169b775378846c1e0e1b1e2288682a4e7374ad13f3354dd8")
