-- Lua provided by RyzenAPI 
-- Game: AppID 810730
addappid(810730)
addappid(810731, 1, "0c97ff9eaf52dfbc976a0027462617e86b82008eb3d4e789aad45e639413d159")
