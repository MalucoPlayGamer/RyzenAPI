-- Lua provided by RyzenAPI
-- Game: Tanks!!!

-- MAIN APPLICATION
addappid(810730)

-- MAIN APP DEPOTS / PACKAGES
addappid(810731, 1, "0c97ff9eaf52dfbc976a0027462617e86b82008eb3d4e789aad45e639413d159")

