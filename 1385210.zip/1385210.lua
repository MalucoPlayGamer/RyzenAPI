-- Lua provided by RyzenAPI
-- Game: Game: AppID 1385210

-- MAIN APPLICATION
addappid(1385210)
-- Game: addappid(1385210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385211, 1, "e46ae70d0a5d621ce38131ca62c22bc98774e2b98269096a8ab9d197203d5ac2")
