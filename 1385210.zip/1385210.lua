-- Lua provided by RyzenAPI
-- Game: AppID 1385210

-- MAIN APPLICATION
addappid(1385210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385211, 1, "e46ae70d0a5d621ce38131ca62c22bc98774e2b98269096a8ab9d197203d5ac2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
