-- Lua provided by RyzenAPI
-- Game: Rock God Tycoon

-- MAIN APPLICATION
addappid(410840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(410841, 1, "ecd2db7e09e6dae9ca68c66fabb9d81f4de12f8d7ef0852fd36b9d2da1d68819")
addappid(410842, 1, "8e91009368d638e711c60b26ffb25cb9bcaa03e48acd2c68b519fafdfbf0661b")

