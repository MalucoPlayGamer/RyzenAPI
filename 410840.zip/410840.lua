-- Lua provided by RyzenAPI
-- Game: Game: AppID 410840

-- MAIN APPLICATION
addappid(410840)
-- Game: addappid(410840)

-- MAIN APP DEPOTS / PACKAGES
addappid(410841, 1, "ecd2db7e09e6dae9ca68c66fabb9d81f4de12f8d7ef0852fd36b9d2da1d68819")
addappid(410842, 1, "8e91009368d638e711c60b26ffb25cb9bcaa03e48acd2c68b519fafdfbf0661b")
