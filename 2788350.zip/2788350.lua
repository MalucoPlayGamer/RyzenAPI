-- Lua provided by RyzenAPI
-- Game: Game: JR EAST Train Simulator: Koumi Line (Kobuchizawa to Komoro) Kiha E200 series

-- MAIN APPLICATION
addappid(2788350)
-- Game: addappid(2788350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788351, 1, "673ee3f402804e26d36038cf8000975aa618a77b8ca21280fd1530829c17251b")
addappid(2788352, 1, "85549cd223e9ed9e3b851960dd2e6ff5136ac3d80e0127507bfd5d74aee380de")
