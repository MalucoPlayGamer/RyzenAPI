-- Lua provided by RyzenAPI
-- Game: addappid(2435800)

-- MAIN APPLICATION
addappid(2435800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435801, 1, "b42efaea8e4359aeb0aa78c933b8ab08c5c955f420857d1b4250798f4982da27")
