-- Lua provided by RyzenAPI
-- Game: Kenny 7

-- MAIN APPLICATION
addappid(2435800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2435801, 1, "b42efaea8e4359aeb0aa78c933b8ab08c5c955f420857d1b4250798f4982da27")

