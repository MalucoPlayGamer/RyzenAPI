-- Lua provided by RyzenAPI
-- Game: Aura Wallpaper

-- MAIN APPLICATION
addappid(2726120)
-- Game: addappid(2726120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726121, 1, "cfec4dcea1c17050536b2ed35193297d96656d684642f5014090f08b42391139")
