-- Lua provided by RyzenAPI
-- Game: addappid(1450030)

-- MAIN APPLICATION
addappid(1450030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450031, 1, "2dab0097bcb73a32b73cea2198a19c6511a851d10a0941afbc7579202ff27b72")
