-- Lua provided by RyzenAPI
-- Game: addappid(2869790)

-- MAIN APPLICATION
addappid(2869790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869791, 1, "d0185c3b624d2cfb70febc8b17963bbd4e72f9e059ff4f0c9e033ae46e74987b")
