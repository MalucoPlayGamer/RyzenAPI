-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Celebrity Trivia

-- MAIN APPLICATION
addappid(849620)

-- MAIN APP DEPOTS / PACKAGES
addappid(849621, 1, "31f89a3f4439c364509d3f36b95007e556c99c629f5b8f2d6dbfbe7a405dd76b")

