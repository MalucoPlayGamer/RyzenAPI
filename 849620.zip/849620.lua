-- Lua provided by RyzenAPI 
-- Game: AppID 849620
addappid(849620)
addappid(849621, 1, "31f89a3f4439c364509d3f36b95007e556c99c629f5b8f2d6dbfbe7a405dd76b")
