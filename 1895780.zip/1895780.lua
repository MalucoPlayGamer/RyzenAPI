-- Lua provided by RyzenAPI
-- Game: Sexy Space Airlines

-- MAIN APPLICATION
addappid(1895780)
-- Game: addappid(1895780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895781, 1, "6d05487340f623a325941d29fc85e8bb3dc9fa2ac7d7285659a7d0ad34b8c6a2")
