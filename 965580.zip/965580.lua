-- Lua provided by RyzenAPI
-- Game: Root

-- MAIN APPLICATION
addappid(965580)
addappid(1462460)
addappid(1586100)
addappid(1935900)
addappid(2253060)
addappid(3346620)
addappid(3874110)

-- MAIN APP DEPOTS / PACKAGES
addappid(965581,0,"3369a4492dbd5b23bb12fb1ffddfcadaae9719b6dcf01026327b2321f308ca00")
addappid(965582,0,"3bba89f33d517589841bde268e67c538ff94436d447ece2b01dd669f9e722431")

