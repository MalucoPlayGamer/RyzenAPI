-- Lua provided by SkyAPI 
-- Game: Knot
addappid(575990)
addappid(575991, 1, "ec4b79ce5761f22c967686f0e7fa95ac21160e44a62f39d75e76581900a5424d")
addappid(589230)
