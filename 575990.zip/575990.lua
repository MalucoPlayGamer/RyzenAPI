-- Lua provided by RyzenAPI
-- Game: Knot

-- MAIN APPLICATION
addappid(575990)
addappid(589230)

-- MAIN APP DEPOTS / PACKAGES
addappid(575991, 1, "ec4b79ce5761f22c967686f0e7fa95ac21160e44a62f39d75e76581900a5424d")

