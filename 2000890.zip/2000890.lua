-- Lua provided by RyzenAPI
-- Game: MechWarrior 5: Clans

-- MAIN APPLICATION
addappid(2000890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000891, 1, "2e57d475d5e205a6ad926d2b6817b2585d9698098c141a54af8e60e6489bb444")

