-- Lua provided by RyzenAPI
-- Game: MechWarrior 5: Clans

-- MAIN APPLICATION
addappid(2000890)
addappid(3170420)
addappid(3170430)
addappid(3323880)
addappid(3463200)
addappid(4128140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2000891, 1, "2e57d475d5e205a6ad926d2b6817b2585d9698098c141a54af8e60e6489bb444")

