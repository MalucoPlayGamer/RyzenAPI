-- Lua provided by RyzenAPI
-- Game: Worlds

-- MAIN APPLICATION
addappid(304850)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(304851, 1, "c3f5bd870235e699aebe716ab348984ddc4ce5dd2f9e12976c87397daae01a7b")
addappid(304852, 1, "4d09344d832e9fba47a8ffab5be7d4f2e3733f28109d8c3b823128a094092519")

