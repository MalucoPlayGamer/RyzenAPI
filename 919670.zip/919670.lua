-- Lua provided by RyzenAPI
-- Game: addappid(919670)

-- MAIN APPLICATION
addappid(919670)

-- MAIN APP DEPOTS / PACKAGES
addappid(919671, 1, "f589d9a255a8b64a300da4c2cf2d60fd9c714527e3f94a22be8319b1385c2090")
