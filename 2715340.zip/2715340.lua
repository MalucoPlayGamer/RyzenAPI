-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2715340)
-- Game: addappid(2715340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715340,0,"be6e552c3de6ae837ec8d57603f51a19bc364155031d2e6e8355d185fba3c832")
