-- Lua provided by RyzenAPI
-- Game: addappid(2097620)

-- MAIN APPLICATION
addappid(2097620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097621, 1, "ddb7294385c31c06fc1c0bc860e95a5b9f4820cfb6f73303b3d6029b95a9ba42")
