-- Lua provided by RyzenAPI
-- Game: COGEN: Sword of Rewind - Additional Story ＆ Playable Character: Yuji Otori / COGEN: 大鳥こはくと刻の剣 - 追加シナリオ＆プレイ可能キャラクター：大鳥ゆうじ編

-- MAIN APPLICATION
addappid(1644061)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644061,0,"eb5b84d3e3029b3bb66d7266e0464ce5e6947ea4893420de72893089ce20a23a")

