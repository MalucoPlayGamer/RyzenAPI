-- Lua provided by RyzenAPI
-- Game: Pacremental

-- MAIN APPLICATION
addappid(4599460)

-- MAIN APP DEPOTS / PACKAGES
addappid(4599461,0,"0c3f13262499c5ea5e31666b5f295fff63aea88005a6d29bba8ab13fc483d1a8")

