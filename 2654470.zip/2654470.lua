-- Lua provided by SkyAPI 
-- Game: BUNNY GARDEN
addappid(2654470)
addappid(2654471, 1, "e9ebdceb944e6e95b40971f899e83b4fd9cb31fa2272b155945dda0ce4f99944")
