-- Lua provided by RyzenAPI
-- Game: Sexual Summer

-- MAIN APPLICATION
addappid(2180680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180681, 1, "a40e093ff71012d928337b5aaa9670ffb70ba092debe2c072b636e6b3670afaf")

