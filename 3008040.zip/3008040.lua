-- Lua provided by RyzenAPI
-- Game: Into The Darkness VR Playtest

-- MAIN APPLICATION
addappid(3008040)
-- Game: addappid(3008040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3008041, 1, "803c8993e2d854fa641ca7b6010ff80e43fb6fe91299fecfdef09b50f22901de")
