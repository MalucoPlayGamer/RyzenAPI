-- Lua provided by SkyAPI 
-- Game: Into The Darkness VR Playtest
addappid(3008040)
addappid(3008041, 1, "803c8993e2d854fa641ca7b6010ff80e43fb6fe91299fecfdef09b50f22901de")
