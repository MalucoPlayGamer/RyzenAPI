-- Lua provided by RyzenAPI 
-- Game: Paper Beast - Folded Edition
addappid(1403830)
addappid(1403831, 1, "6ee8d8bb4460e8ca916fae2c3a6372db24820971ab4014eaefdd6f120f40da05")
addappid(1529050)
