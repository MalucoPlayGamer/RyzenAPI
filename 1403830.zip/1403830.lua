-- Lua provided by RyzenAPI
-- Game: 1403830

-- MAIN APPLICATION
addappid(1403830)
addappid(1529050)
-- Game: addappid(1403830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403831, 1, "6ee8d8bb4460e8ca916fae2c3a6372db24820971ab4014eaefdd6f120f40da05")
