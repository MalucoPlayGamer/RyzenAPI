-- Lua provided by RyzenAPI
-- Game: Cannibal Abduction Soundtrack

-- MAIN APPLICATION
addappid(2254320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254321, 1, "38f126e2ab98dfa683a76db3c29cca8c55aee6bcd7d2525bc507ea1183bef7d1")

