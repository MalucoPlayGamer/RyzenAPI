-- Lua provided by RyzenAPI 
-- Game: The Elder Scrolls IV: Oblivion® Game of the Year Edition (2009)
addappid(22330)
addappid(22331, 1, "3d9d5b4a4675be6981285ac5c1d08fab79e194eff4ade8c11c2788ea2a96cda8")
addappid(22333, 1, "244e0256c60f9fe31ae1c8263670595db76091793618ec6e6db7096a84d3ee26")
addappid(22334, 1, "7d47110a2a269d519332d43f0daf05c6e1404d29d76e51ed8a36f4490a6a8cb7")
addappid(22335, 1, "b8e736e122378c10c199437f7522ef579477619cc99abafbbf656c49e5d0ed42")
addappid(22336, 1, "50a2e885cf832658b972a08433eca7135b1c1ae1f76a62f95e0ca142eb61bfd6")
addappid(22337, 1, "b48729265bb248aee367daf9b401a81edd86896ae6bbed5c3725e79ba2e5364f")
