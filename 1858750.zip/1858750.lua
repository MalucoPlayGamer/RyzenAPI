-- Lua provided by RyzenAPI
-- Game: SpriteMancer

-- MAIN APPLICATION
addappid(1858750)
-- Game: addappid(1858750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858752,0,"8121d139dad19173b6426a13239b74a577d876675a76b102bc8c61ea63bedcb6")
