-- Lua provided by RyzenAPI
-- Game: AppID 585910

-- MAIN APPLICATION
addappid(585910)
-- Game: addappid(585910)

-- MAIN APP DEPOTS / PACKAGES
addappid(585911, 1, "a196e066c062115037a097b4e1571e6beda2a96c5b156cbb1023f47a2e4359af")
