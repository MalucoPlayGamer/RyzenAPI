-- Lua provided by RyzenAPI
-- Game: Call of Boba

-- MAIN APPLICATION
addappid(2342690)
-- Game: addappid(2342690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342691, 1, "8524186567e4fec57aff20fd2038618969b7f28370989336e7e6416599cf1c4b")
