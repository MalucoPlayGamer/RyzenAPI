-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1295727)
addappid(1295727,0,"d3f1b9ed27509de468a2c55f25f60e934fb1d4450a95aef4334eb239cec86f30")
-- setManifestid(1295727,"2353633132125377200")
addappid(1296170,0,"8cf87e7e361e4a7b97a7f436e59057324ce9e63f5a391cec2d588a5a60b5f2ad")
-- setManifestid(1296170,"6480062387033168544")
addappid(1296171,0,"94e4e06c3406326adf034be48ca91f8b72eb65e1e67a11c0662fd936874cac2d")
-- setManifestid(1296171,"2426482505790577949")
addappid(1296172,0,"6f89ba577ef799da9feeb185cb45514d60e1f968a1d36e4d91522823af777f54")
-- setManifestid(1296172,"5150365368150759650")
addappid(1296173,0,"d949c6239985c21e7f11db4fcef498cb4c8f18c4a6316e762e7737a9344a8c33")
-- setManifestid(1296173,"2119980144318238112")
addappid(1296174,0,"04811779423c002f1e2f239687593fb3cbdbe39f9acd64160dc10faadb57c836")
-- setManifestid(1296174,"9052224409528587145")
addappid(1296175,0,"179ce4e8960edf8e9e2d2e2d22ff3fb07572e20dab08a9d7019195bf90e35ffa")
-- setManifestid(1296175,"2173122463003051344")
addappid(1296176,0,"12e5c27c07bfbcb5975eb6ee165a44d522e7e05179f434b930d2e491e8167143")
-- setManifestid(1296176,"5239013068145639336")