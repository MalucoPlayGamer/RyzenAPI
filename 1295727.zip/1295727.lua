-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1295727)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295727,0,"d3f1b9ed27509de468a2c55f25f60e934fb1d4450a95aef4334eb239cec86f30")
addappid(1296170,0,"8cf87e7e361e4a7b97a7f436e59057324ce9e63f5a391cec2d588a5a60b5f2ad")
addappid(1296171,0,"94e4e06c3406326adf034be48ca91f8b72eb65e1e67a11c0662fd936874cac2d")
addappid(1296172,0,"6f89ba577ef799da9feeb185cb45514d60e1f968a1d36e4d91522823af777f54")
addappid(1296173,0,"d949c6239985c21e7f11db4fcef498cb4c8f18c4a6316e762e7737a9344a8c33")
addappid(1296174,0,"04811779423c002f1e2f239687593fb3cbdbe39f9acd64160dc10faadb57c836")
addappid(1296175,0,"179ce4e8960edf8e9e2d2e2d22ff3fb07572e20dab08a9d7019195bf90e35ffa")
addappid(1296176,0,"12e5c27c07bfbcb5975eb6ee165a44d522e7e05179f434b930d2e491e8167143")

