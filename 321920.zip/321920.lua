-- Lua provided by RyzenAPI
-- Game: Schein

-- MAIN APPLICATION
addappid(321920)

-- MAIN APP DEPOTS / PACKAGES
addappid(321921, 1, "320e57c84b9adfa4271ec5a353b9d19a50dde63472da8849de49217c6ed69006")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
