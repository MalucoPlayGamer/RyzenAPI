-- Lua provided by RyzenAPI
-- Game: Game: Schein

-- MAIN APPLICATION
addappid(321920)
-- Game: addappid(321920)

-- MAIN APP DEPOTS / PACKAGES
addappid(321921, 1, "320e57c84b9adfa4271ec5a353b9d19a50dde63472da8849de49217c6ed69006")
