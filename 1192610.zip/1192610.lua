-- Lua provided by RyzenAPI
-- Game: addappid(1192610)

-- MAIN APPLICATION
addappid(1192610)
addappid(1205380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192611, 1, "3f817f30830506a454e5ae7fd811b64b9b4e308043ac238db1a3584d2883766b")
