-- Lua provided by RyzenAPI
-- Game: Game: 3D Ultra™ Minigolf Adventures

-- MAIN APPLICATION
addappid(10140)
-- Game: addappid(10140)

-- MAIN APP DEPOTS / PACKAGES
addappid(10141, 1, "0e3b0abada689184aa504c76571f9e57293f4211e1fc6b2d47ad92380cee2eb6")
