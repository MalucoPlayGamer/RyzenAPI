-- Lua provided by RyzenAPI 
-- Game: Songs of Life Soundtrack
addappid(3554730)
addappid(3554731, 1, "1b14e419267769bb7405cbeb94eeb04c77a09203d5f4b6d59db5b6b97305ce12")
addappid(3554732, 1, "9bd8101bf13fbd16756e61e8d8240f9e6de8685a90fa0c5d9ab1b97ea3475495")
