-- Lua provided by RyzenAPI 
-- Game: AppID 982450
addappid(982450)
addappid(982451, 1, "d130cb503377440c9247519438a6ceef00af45c5c35c4eefe80f5d2da3b2244c")
