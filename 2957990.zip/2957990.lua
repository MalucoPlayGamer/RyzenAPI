-- Lua provided by RyzenAPI
-- Game: addappid(2957990)

-- MAIN APPLICATION
addappid(2957990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957991, 1, "239086651d338efcb0ecd686f1f779b6c3b0e7e38ae465c50f85a4c755e45422")
