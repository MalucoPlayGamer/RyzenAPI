-- Lua provided by RyzenAPI
-- Game: addappid(1812889)

-- MAIN APPLICATION
addappid(1812889)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812889,0,"36758cda4f77cf221cae530b8799fd2b6bdd7115b4e5d200f78221e75b735329")
