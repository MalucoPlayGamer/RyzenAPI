-- Lua provided by RyzenAPI
-- Game: Liber Prologue

-- MAIN APPLICATION
addappid(2163190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163191, 1, "a6f6fc75547833b8c62d3bab781206a0435fccca465c141c8f1d656402203fa8")

