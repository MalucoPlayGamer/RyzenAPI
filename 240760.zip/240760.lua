-- Lua provided by RyzenAPI
-- Game: Wasteland 2: Director's Cut

-- MAIN APPLICATION
addappid(240760)

-- MAIN APP DEPOTS / PACKAGES
addappid(240761, 1, "37fdf0fc02f0505ecf17814f22ba7188b99da324091fd9a73ff0c5017b6619ea")
addappid(240762, 1, "f1499f1c44315ea4cdc2e6b879f8a67e0e78959e4a68179384ac46fd2d95f3b5")
addappid(240763, 1, "9ebf3b7995c65b4c4a9ec579fd925ab486c0d137eb711d9ed3d9a002e85d7bd6")
addappid(272290, 0, "4b222a813eddb22bd47b68ec72f7146e8bca05b31c98d6d85b6c90f6a1cbdeb0")
addappid(305540, 0, "3265b6fb456f47d582059eca11072320374fc5edde185f22fc65425a21e80ed0")
addappid(324180, 0, "f33082c2ac113229f3bd53b2563e59e48d9b9a6de6d219ae9f1d5015d65fd70b")
addappid(324200, 0, "a22105f14c22e9f100b1f779e03bfe45e6e8af5fe2c31890ee311130155fdb44")
addappid(332990, 0, "243b4f6e62fe1c8ddef7960d0c747846b7f32a0a4a541f6a22b54e4dbe8fe270")
addappid(333000, 0, "c177f60aa069328acb34c84466717d3caa3c245e78ad93c6e3edf926552057de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(271080)
