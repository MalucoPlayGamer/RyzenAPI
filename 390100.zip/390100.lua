-- Lua provided by RyzenAPI
-- Game: 9Dragons

-- MAIN APPLICATION
addappid(390100)
addappid(720910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(390101, 1, "f8fde4caf5e819f86e5b50a30a74b30fbe8ef5414e40e13a8544cbf1151c45e0")