-- Lua provided by SkyAPI 
-- Game: AppID 390100
addappid(390100)
addappid(390101, 1, "f8fde4caf5e819f86e5b50a30a74b30fbe8ef5414e40e13a8544cbf1151c45e0")
addappid(720910)
