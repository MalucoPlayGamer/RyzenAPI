-- Lua provided by RyzenAPI
-- Game: AppID 390100

-- MAIN APPLICATION
addappid(390100)
addappid(720910)
-- Game: addappid(390100)

-- MAIN APP DEPOTS / PACKAGES
addappid(390101, 1, "f8fde4caf5e819f86e5b50a30a74b30fbe8ef5414e40e13a8544cbf1151c45e0")
