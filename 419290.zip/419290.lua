-- Lua provided by RyzenAPI
-- Game: Epic Battle Fantasy 4 Soundtrack

-- MAIN APPLICATION
addappid(419290)

-- MAIN APP DEPOTS / PACKAGES
addappid(419290,0,"859c41876a29dd0f1de79342a99ac6aa296a622dd14e64c02350d9b56b600cfb")
