-- Lua provided by RyzenAPI
-- Game: Game: Combo Card Clashers Playtest

-- MAIN APPLICATION
addappid(2865290)
-- Game: addappid(2865290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865291, 1, "88a764ea43fd2643d092f64614c96ebdd860920411e36a079d6b898b62e236bb")
