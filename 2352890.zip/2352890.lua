-- Lua provided by SkyAPI 
-- Game: Hentai Ariel
addappid(2352890)
addappid(2352891, 1, "e4dca9cb83a7f448b859ed592e4a8eae87dee5a498c1c8db05eba889bf1e69e3")
