-- Lua provided by RyzenAPI
-- Game: 98210

-- MAIN APPLICATION
addappid(98210)
-- Game: addappid(98210)

-- MAIN APP DEPOTS / PACKAGES
addappid(98203,0,"61120452b252aeb1e7ee68fb1f5224f61570368811ed3bc5d5391b01a00e5fe7")
