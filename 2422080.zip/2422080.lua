-- Lua provided by RyzenAPI
-- Game: Ajax’s Trial

-- MAIN APPLICATION
addappid(2422080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422081, 1, "e84bcbc724a3ba199473809763141d174bde9866034b784a7d4484d85eb2352e")
