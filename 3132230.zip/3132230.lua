-- Lua provided by RyzenAPI
-- Game: 3132230

-- MAIN APPLICATION
addappid(3132230)
-- Game: addappid(3132230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132231, 1, "4a587a5e26cb089a988c742c54f0e3f8e69874cb38bf6329c6a83098aab5e031")
