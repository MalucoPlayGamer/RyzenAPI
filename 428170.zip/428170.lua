-- Lua provided by RyzenAPI
-- Game: 428170

-- MAIN APPLICATION
addappid(428170)

-- MAIN APP DEPOTS / PACKAGES
addappid(428172,0,"9a6f92d834af41c59b6c3dfcd0ec25f5a30ea8cbb5a3121608598c6c68ef83e9")

