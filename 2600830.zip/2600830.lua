-- Lua provided by RyzenAPI
-- Game: Lost Hope: Backrooms

-- MAIN APPLICATION
addappid(2600830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600831, 1, "2d253b5fdad13bb9120850d538af08f445e198f194d265fe95e5abd49bba8c9b")
