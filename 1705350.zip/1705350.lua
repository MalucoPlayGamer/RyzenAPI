-- Lua provided by SkyAPI 
-- Game: DarkCoating
addappid(1705350)
addappid(1705351, 1, "1dab2e7aca51ab73ab7f2368c17d2c91bdf844fb9a86d009d9c9ae3232b631f1")
