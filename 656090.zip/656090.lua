-- Lua provided by RyzenAPI
-- Game: 656090

-- MAIN APPLICATION
addappid(656090)
-- Game: addappid(656090)

-- MAIN APP DEPOTS / PACKAGES
addappid(656091, 1, "4781b96f3fa8138f11810d9e200ed09fb75c7a746b62a609b6cdec3132c7b060")
addappid(656092, 1, "19c6f97112da6580311b9f378cae1e75d52f12fef4beb3d426515be2e7c77d79")
