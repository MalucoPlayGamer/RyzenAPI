-- Lua provided by RyzenAPI 
-- Game: Weable
addappid(683830)
addappid(683831, 1, "34d7aab505e4e2ea83162559d5837bb958e8ddfe380ac6e53f265f94165a79f6")
