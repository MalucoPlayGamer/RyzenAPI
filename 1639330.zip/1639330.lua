-- Lua provided by RyzenAPI
-- Game: Pain Party Playtest

-- MAIN APPLICATION
addappid(1639330)
-- Game: addappid(1639330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639331, 1, "d5c69e99a44755c03e6d80292a268cedecad17962dfbd5c939957c85f94676e2")
