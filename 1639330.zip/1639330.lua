-- Lua provided by SkyAPI 
-- Game: Pain Party Playtest
addappid(1639330)
addappid(1639331, 1, "d5c69e99a44755c03e6d80292a268cedecad17962dfbd5c939957c85f94676e2")
