-- Lua provided by RyzenAPI
-- Game: Stuffo the Puzzle Bot

-- MAIN APPLICATION
addappid(1068460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068461, 1, "a7e43420e692138a390ede0b97a5fbc14583aab6592408564afa0e430d988097")

