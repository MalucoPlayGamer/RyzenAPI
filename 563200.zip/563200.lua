-- Lua provided by RyzenAPI
-- Game: AppID 563200

-- MAIN APPLICATION
addappid(563200)

-- MAIN APP DEPOTS / PACKAGES
addappid(563201, 1, "340b6df77bf09192b34332fce2cc94c1b5b51d253cc60749616383ca3980a696")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
