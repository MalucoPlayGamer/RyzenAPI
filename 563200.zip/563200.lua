-- Lua provided by RyzenAPI
-- Game: 563200

-- MAIN APPLICATION
addappid(563200)
-- Game: addappid(563200)

-- MAIN APP DEPOTS / PACKAGES
addappid(563201, 1, "340b6df77bf09192b34332fce2cc94c1b5b51d253cc60749616383ca3980a696")
