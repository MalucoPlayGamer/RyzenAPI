-- Lua provided by RyzenAPI
-- Game: KINGDOMS

-- MAIN APPLICATION
addappid(409590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(409591, 1, "5fff08c563f6401dbb7074f9c799aa07b3dd719195009eb3d5fffda2c6b0da9a")
addappid(409592, 1, "19a46b152dd80e69cabaf62aa0055cd786dc17ac7fd3260753efa8eb8d53cf74")

