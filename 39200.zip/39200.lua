-- Lua provided by RyzenAPI
-- Game: AppID 39200

-- MAIN APPLICATION
addappid(39200)

-- MAIN APP DEPOTS / PACKAGES
addappid(39201, 1, "4b6f829d6048e6ea844a5b920b83db19bfc6e736eee9ee0c20500629807ce02d")
addappid(39202, 1, "1bb2b4828efede9e560539a31c1642bfb59db0729caec84f23685556e14b2325")
addappid(39203, 1, "05bbf4f6a2638daaf863031a70045ecacaeb160192a774a433ed7e0f2f2861a6")
addappid(39204, 1, "82066a0f0e7791d84d16b6a134ab64960a7ce849da42a227b5b9c7f1ad684fb5")
addappid(39205, 1, "d0790852ef8280ec87368944153865509edf673b23212e49ad5e3b012330974e")
addappid(39206, 1, "a1fc7750db11837f6fe54dda903b3ccb166346f63aa8ed64f191e9578f234743")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
