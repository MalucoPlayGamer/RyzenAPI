-- Lua provided by RyzenAPI
-- Game: They That Feast

-- MAIN APPLICATION
addappid(963910)
-- Game: addappid(963910)

-- MAIN APP DEPOTS / PACKAGES
addappid(963911, 1, "7399335ed3169cae62adfd51f7953e86b521c99b21c305df4dc6c9c6349c0b1c")
