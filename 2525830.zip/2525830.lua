-- Lua provided by RyzenAPI
-- Game: The Lost Prince

-- MAIN APPLICATION
addappid(2525830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525831, 1, "a173d661a9feb42a6c2146efffc7082d1ad4daf0ec0b1e852c7efeca52f19706")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2701530)
