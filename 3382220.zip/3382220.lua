-- Lua provided by RyzenAPI 
-- Game: OVERDOSE
addappid(3382220)
addappid(3382221, 1, "60ea7d00dbfb59b6307e021799d637007b59c1bf36a58af463de7be5ec20c23a")
