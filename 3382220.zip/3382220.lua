-- Lua provided by RyzenAPI
-- Game: addappid(3382220)

-- MAIN APPLICATION
addappid(3382220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3382221, 1, "60ea7d00dbfb59b6307e021799d637007b59c1bf36a58af463de7be5ec20c23a")
