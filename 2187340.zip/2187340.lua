-- Lua provided by RyzenAPI
-- Game: ExoColony: Planet Survival

-- MAIN APPLICATION
addappid(2187340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187341, 1, "10b61fae4cb71137e08660f55926e106512e427e8fc0838a952d2787395c1dbd")
