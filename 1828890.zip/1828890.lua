-- Lua provided by RyzenAPI
-- Game: Murder of the Bear lake

-- MAIN APPLICATION
addappid(1828890)
-- Game: addappid(1828890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828891, 1, "f2544468e6efbffcb7c9396249b3b257ec7d4c9df1c45d730aaa97ad51fe9e42")
