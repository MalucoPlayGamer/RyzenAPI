-- Lua provided by RyzenAPI
-- Game: Zero Caliber VR

-- MAIN APPLICATION
addappid(877200)
-- Game: addappid(877200)

-- MAIN APP DEPOTS / PACKAGES
addappid(877201, 1, "e3af59530243fadb7275d47eb8ed18e8462d03c3da80e1ceca4967c26539b107")
