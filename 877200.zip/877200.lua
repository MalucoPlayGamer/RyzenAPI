-- Lua provided by RyzenAPI
-- Game: Zero Caliber VR

-- MAIN APPLICATION
addappid(877200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(877201, 1, "e3af59530243fadb7275d47eb8ed18e8462d03c3da80e1ceca4967c26539b107")

