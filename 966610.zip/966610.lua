-- Lua provided by RyzenAPI
-- Game: AppID 966610

-- MAIN APPLICATION
addappid(966610)
-- Game: addappid(966610)

-- MAIN APP DEPOTS / PACKAGES
addappid(966611, 1, "6e831f76f28e24710cc7727d44dcf814c54e3ecc7bf39030aa075c194c0eb204")
