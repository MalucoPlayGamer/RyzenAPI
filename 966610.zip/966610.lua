-- Lua provided by SkyAPI 
-- Game: AppID 966610
addappid(966610)
addappid(966611, 1, "6e831f76f28e24710cc7727d44dcf814c54e3ecc7bf39030aa075c194c0eb204")
