-- Lua provided by RyzenAPI
-- Game: Nightfall Comes

-- MAIN APPLICATION
addappid(1935100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935101, 1, "11a84ea2ff6ee45724792c73131c10d761ac94ce4a964a072ff69ee74dd2ed72")

