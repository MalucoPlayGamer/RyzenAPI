-- Lua provided by RyzenAPI
-- Game: addappid(1748050)

-- MAIN APPLICATION
addappid(1748050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748051, 1, "165d6f17c74110ae1eac6235de1eb958ae4838781f07cecccc67d78ceb24ad80")
