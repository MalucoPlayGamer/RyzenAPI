-- Lua provided by RyzenAPI 
-- Game: Strike Solitaire 2
addappid(1329460)
addappid(1329461, 1, "ee6e944d2c0634f97c462a0b50c3760c8805ebe35c00171d2ea914a1812b65dd")
addappid(1329464, 1, "503918e2322bcdc93c970750e55d94e24cf9e3f3f59364f7a42f9a7ec6d45680")
