-- Lua provided by RyzenAPI
-- Game: 2838550

-- MAIN APPLICATION
addappid(2838550)
-- Game: addappid(2838550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838551, 1, "45cca730b11eda3d2a8f229fba2b28dcd9d067bfc909a719371f06c5b944ba0d")
