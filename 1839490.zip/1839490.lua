-- Lua provided by RyzenAPI
-- Game: GigaBash Demo

-- MAIN APPLICATION
addappid(1839490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839491, 1, "66c650ce3a8d0e5501eb13a46ad2af291053311726bb9c7481a649e5b6c65eb1")

