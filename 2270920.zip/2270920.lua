-- Lua provided by RyzenAPI
-- Game: 2270920

-- MAIN APPLICATION
addappid(2270920)
-- Game: addappid(2270920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270921, 1, "0f8766f0297c213ffc01d5c01974ff162cc3b5e6ddaf397fb9a78af8d0175292")
