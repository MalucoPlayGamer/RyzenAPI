-- Lua provided by RyzenAPI
-- Game: Game: Zombie Apocalypse

-- MAIN APPLICATION
addappid(589160)
-- Game: addappid(589160)

-- MAIN APP DEPOTS / PACKAGES
addappid(589161, 1, "dd8f51cd3c474620a1d482dc689b4ed5627a8b84606fabc7fd383f8a071be9e3")
