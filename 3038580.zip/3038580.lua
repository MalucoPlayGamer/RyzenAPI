-- Lua provided by RyzenAPI
-- Game: Game: Art Shop Simulator

-- MAIN APPLICATION
addappid(3038580)
-- Game: addappid(3038580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3038581, 1, "38306b0f1b843ef6c6c64b093d2bac93f83e8946935bf265ebf68359afcf1ce9")
