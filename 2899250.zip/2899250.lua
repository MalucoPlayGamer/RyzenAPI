-- Lua provided by RyzenAPI
-- Game: Nolgorb's Ordeal

-- MAIN APPLICATION
addappid(2899250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899251,0,"332d6c393cecbb7c5acdbe78af45768ff4eae33399e070a75a6d652ba0640700")

