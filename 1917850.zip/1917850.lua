-- Lua provided by RyzenAPI
-- Game: Game: Haunted House Renovator

-- MAIN APPLICATION
addappid(1917850)
-- Game: addappid(1917850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917851, 1, "000fc9e34caba5f3aab6e7f398e9b18bfb3fe19cdb3cddb65c4ed2403b748f50")
