-- Lua provided by RyzenAPI
-- Game: Game: Hotel Mogul: Las Vegas

-- MAIN APPLICATION
addappid(1061850)
-- Game: addappid(1061850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061851, 1, "02f7cd873a525d7c998339638768404b2abe1194345fcb62e0ff172b489086ea")
