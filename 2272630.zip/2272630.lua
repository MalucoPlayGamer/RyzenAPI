-- Lua provided by RyzenAPI
-- Game: PEAK.53

-- MAIN APPLICATION
addappid(2272630)
-- Game: addappid(2272630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272631, 1, "16e1d48dade3a012de98eed2f411fbf6ac67f4991bef34fb1d71edb83c3363f1")
