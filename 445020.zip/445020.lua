-- Lua provided by RyzenAPI
-- Game: 445020

-- MAIN APPLICATION
addappid(445020)
addappid(914840)
-- Game: addappid(445020)

-- MAIN APP DEPOTS / PACKAGES
addappid(445021, 1, "9228a5718d9b477ea4d56ac8db0bfbc82b36af1ab05081edd69991b4d08cfe18")
