-- Lua provided by RyzenAPI
-- Game: Game: AppID 1092650

-- MAIN APPLICATION
addappid(1092650)
-- Game: addappid(1092650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092651, 1, "27678c98eee3d8584429f529f6a96d27b35eeffe0d56489c6ab407875ed20849")
