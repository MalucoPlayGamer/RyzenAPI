-- Lua provided by RyzenAPI
-- Game: LINES AND KNOTS 1 DEMO

-- MAIN APPLICATION
addappid(1235780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235781, 1, "73cfdb6f560a86b54a0eca9cddd547e01b9fceb4b8da9740750a2be1e970efbe")

