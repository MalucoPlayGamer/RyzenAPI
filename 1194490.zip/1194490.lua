-- Lua provided by RyzenAPI
-- Game: 1194490

-- MAIN APPLICATION
addappid(1194490)
-- Game: addappid(1194490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194491, 1, "a283a28ac285c0a00c54c4e0c599f8044fd499d5f1e1f987180b7f3f935aeef4")
