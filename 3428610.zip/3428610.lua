-- Lua provided by RyzenAPI
-- Game: Game: Beer Runner

-- MAIN APPLICATION
addappid(3428610)
-- Game: addappid(3428610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428611, 1, "a7664efea16b07312225594d69c002f2567948419d81cb64bc214f9df9dc6a0c")
