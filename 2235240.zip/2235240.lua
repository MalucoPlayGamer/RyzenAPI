-- Lua provided by RyzenAPI
-- Game: TaskPals

-- MAIN APPLICATION
addappid(2235240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235242,0,"05046ec3d8b53df97b43dcb362c833686820df319204be4406e52290b345244b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2236150)
addappid(2604380)
addappid(2745810)
addappid(2890040)
