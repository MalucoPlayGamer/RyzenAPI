-- Lua provided by RyzenAPI
-- Game: TaskPals

-- MAIN APPLICATION
addappid(2235240)
-- Game: addappid(2235240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235242,0,"05046ec3d8b53df97b43dcb362c833686820df319204be4406e52290b345244b")
