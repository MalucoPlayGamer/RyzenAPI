-- Lua provided by RyzenAPI
-- Game: Food Fight

-- MAIN APPLICATION
addappid(1965640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965641, 1, "8ea7fc8bf8866632e68a677286eaeda582907a6c7ad0a003b54c46764b30e5a0")

