-- Lua provided by RyzenAPI
-- Game: My Little Life

-- MAIN APPLICATION
addappid(2834600)
addappid(3469580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834601, 1, "62ae7fadc4e1253f5eae565b2eb6548b98c5f0c4485357983c7243e4ba5561d9")

