-- Lua provided by RyzenAPI 
-- Game: PIGEONS
addappid(2721260)
addappid(2721261, 1, "6acc7baf7fb97b112a61c578fed6a34650b3bc50f1f211e8968dee57aa4e0ca9")
