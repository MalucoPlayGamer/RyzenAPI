-- Lua provided by RyzenAPI
-- Game: addappid(1044260)

-- MAIN APPLICATION
addappid(1044260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044260,0,"c85a84e4bab6242e80643ebb3d75a805f7e049fe93fe97505dc1d4df46345d7b")
