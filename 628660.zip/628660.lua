-- Lua provided by RyzenAPI
-- Game: 628660

-- MAIN APPLICATION
addappid(628660)
-- Game: addappid(628660)

-- MAIN APP DEPOTS / PACKAGES
addappid(628661, 1, "7750f9ea0b46c57bbc03266446f9193d495af55bc41a823bf43c456995a5b03f")
