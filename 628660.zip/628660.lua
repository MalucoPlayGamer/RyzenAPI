-- Lua provided by RyzenAPI
-- Game: Lode Runner Legacy

-- MAIN APPLICATION
addappid(628660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(628661, 1, "7750f9ea0b46c57bbc03266446f9193d495af55bc41a823bf43c456995a5b03f")
