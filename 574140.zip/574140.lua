-- Lua provided by RyzenAPI
-- Game: Game: AppID 574140

-- MAIN APPLICATION
addappid(574140)
-- Game: addappid(574140)

-- MAIN APP DEPOTS / PACKAGES
addappid(574141, 1, "82d97201d2a2333f35c1c7155424ee3bd16147087231c324844c76da31d636ee")
