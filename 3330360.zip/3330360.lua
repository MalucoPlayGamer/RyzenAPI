-- Lua provided by RyzenAPI
-- Game: addappid(3330360)

-- MAIN APPLICATION
addappid(3330360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3330361, 1, "0ed070c946dc017780b7c3f1c58a6be76df943798d71f27f663708e36ffcd5d6")
