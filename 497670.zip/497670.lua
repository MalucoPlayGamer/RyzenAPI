-- Lua provided by RyzenAPI
-- Game: Line/Dash

-- MAIN APPLICATION
addappid(497670)

-- MAIN APP DEPOTS / PACKAGES
addappid(497671, 1, "dea2a7bceea39cef4ae2bc9e2033d4d86127ab57a01bf2d7ccaf56c8a23b245e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
