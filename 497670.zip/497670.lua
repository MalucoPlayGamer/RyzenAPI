-- Lua provided by RyzenAPI
-- Game: Line/Dash

-- MAIN APPLICATION
addappid(497670)
-- Game: addappid(497670)

-- MAIN APP DEPOTS / PACKAGES
addappid(497671, 1, "dea2a7bceea39cef4ae2bc9e2033d4d86127ab57a01bf2d7ccaf56c8a23b245e")
