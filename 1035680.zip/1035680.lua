-- Lua provided by RyzenAPI
-- Game: Pain Train Sound Track

-- MAIN APPLICATION
addappid(1035680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035681, 1, "9fa54f2172ba98258a5094021f9cfa287c5027067d872d0f7276ef988ee9dd68")

