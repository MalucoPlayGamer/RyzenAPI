-- Lua provided by RyzenAPI
-- Game: Game: AppID 1232150

-- MAIN APPLICATION
addappid(1232150)
-- Game: addappid(1232150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232151, 1, "a52dea00b9b393e46c2386f5c95f4ad5a90b0bc553422182308741950b2530a7")
