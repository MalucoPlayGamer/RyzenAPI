-- Lua provided by RyzenAPI
-- Game: AppID 3327950

-- MAIN APPLICATION
addappid(3327950)
-- Game: addappid(3327950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3327951, 1, "145b68930d44bb5137edead51223ff490e752c1fea95fcbf5da8429b5a092c14")
