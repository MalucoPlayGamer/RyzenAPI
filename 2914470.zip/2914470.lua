-- Lua provided by RyzenAPI
-- Game: Armored Suit Solgante

-- MAIN APPLICATION
addappid(2914470)
addappid(3466730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914471, 1, "1f7c50aa90a37dd9789be472809ec449796aaeeb638c675a9875a7de04212bba")
addappid(2914472, 1, "8f904b563d3cb619bebb9a4f053b99fdc719af68ebd6a8eef9372aaf3239fb18")
