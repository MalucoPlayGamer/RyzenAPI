-- Lua provided by RyzenAPI
-- Game: War Theatre: Blood of Winter

-- MAIN APPLICATION
addappid(1150650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150651, 1, "03737dc8b44fd3f866d1983ba709a9f1231ec8beb41460c415675314fb7be29a")
addappid(1150652, 1, "d01154985ddccaaba56a17ea8f8a497d196c29ad12ebac96d7216d63c4dce93c")
addappid(1150653, 1, "81c4aa16621f48b93a7ac808f79bd5e6c6ccdda96a3c20d224a0c60c0d802a64")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1155380)
addappid(1155381)
