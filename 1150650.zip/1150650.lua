-- Lua provided by SkyAPI 
-- Game: War Theatre: Blood of Winter
addappid(1150650)
addappid(1150651, 1, "03737dc8b44fd3f866d1983ba709a9f1231ec8beb41460c415675314fb7be29a")
addappid(1150652, 1, "d01154985ddccaaba56a17ea8f8a497d196c29ad12ebac96d7216d63c4dce93c")
addappid(1150653, 1, "81c4aa16621f48b93a7ac808f79bd5e6c6ccdda96a3c20d224a0c60c0d802a64")
