-- Lua provided by RyzenAPI
-- Game: Hotel Lust

-- MAIN APPLICATION
addappid(3644940)
-- Game: addappid(3644940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3644941, 1, "2bfba507afabe0f4f1f5bce18fafeb0564a7a0b0d3e52d698ff27a978060f1f3")
