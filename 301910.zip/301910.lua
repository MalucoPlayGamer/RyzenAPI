-- Lua provided by RyzenAPI
-- Game: Saints Row: Gat out of Hell

-- MAIN APPLICATION
addappid(301910)
addappid(318850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(301911, 1, "33e5e82540f1c1e20249a0e8e38f334a1439f8b3f52c1e4a5d729cdce62a83e6")
addappid(301912, 1, "2ff392f852c025167f33519a40e1e110d452f17081a1a675e8e29372246bf932")
addappid(301914, 1, "b2c01ab336676537a5d9810e962013d686c098ed4df126aa786b90de9c8777df")

