-- Lua provided by RyzenAPI
-- Game: 沙雕之路

-- MAIN APPLICATION
addappid(1092590)
addappid(4763290)
-- Game: addappid(1092590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092591, 1, "161bc3555bcf1331651c16764c70b0ae0f5510f8328cc69f66b1580854259e68")
