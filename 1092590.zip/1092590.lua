-- Lua provided by RyzenAPI
-- Game: 沙雕之路

-- MAIN APPLICATION
addappid(1092590)
addappid(4763290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092591, 1, "161bc3555bcf1331651c16764c70b0ae0f5510f8328cc69f66b1580854259e68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
