-- Lua provided by RyzenAPI
-- Game: Fly in the House

-- MAIN APPLICATION
addappid(350500)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(350501, 1, "3cfef061c4cce7a5ee4032f680bcde1f016c387de503b9ee6829a8917e625ea2")

