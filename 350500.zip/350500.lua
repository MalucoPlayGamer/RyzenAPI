-- Lua provided by RyzenAPI 
-- Game: Fly in the House
addappid(350500)
addappid(350501, 1, "3cfef061c4cce7a5ee4032f680bcde1f016c387de503b9ee6829a8917e625ea2")
