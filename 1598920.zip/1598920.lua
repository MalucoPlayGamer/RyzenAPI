-- Lua provided by RyzenAPI
-- Game: Farmer Life Simulator

-- MAIN APPLICATION
addappid(1598920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598921, 1, "9ae6e6d08df347babdf580dfe0aab02a20e36c79fcbe548480d8c9375877a219")

