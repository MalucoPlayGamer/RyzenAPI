-- Lua provided by RyzenAPI
-- Game: Nusantara: Legend of The Winged Ones

-- MAIN APPLICATION
addappid(986710)

-- MAIN APP DEPOTS / PACKAGES
addappid(986711, 1, "fe3ec5febf7da8183c8e228e14d20def6039e1877be0c3abdad815c4c380c060")

