-- Lua provided by RyzenAPI
-- Game: 1712670

-- MAIN APPLICATION
addappid(1712670)
-- Game: addappid(1712670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712671, 1, "33d97f3767d0449853cda01562521ec5bee38cc458abbe9b6d9ff545b4879eac")
