-- Lua provided by RyzenAPI 
-- Game: Idle Trading Simulator
addappid(1712670)
addappid(1712671, 1, "33d97f3767d0449853cda01562521ec5bee38cc458abbe9b6d9ff545b4879eac")
