-- Lua provided by SkyAPI 
-- Game: Albatroz
addappid(2171880)
addappid(2171881, 1, "fdbb725b63c40c0f42638252833e0e0d39cb39473d6dd22bbe799b1563855c83")
