-- Lua provided by RyzenAPI
-- Game: Game: Albatroz

-- MAIN APPLICATION
addappid(2171880)
-- Game: addappid(2171880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171881, 1, "fdbb725b63c40c0f42638252833e0e0d39cb39473d6dd22bbe799b1563855c83")
