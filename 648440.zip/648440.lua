-- Lua provided by RyzenAPI
-- Game: addappid(648440)

-- MAIN APPLICATION
addappid(648440)

-- MAIN APP DEPOTS / PACKAGES
addappid(648441, 1, "b72acadc2dcdc906fdf1821f93eaecbc7a69b815a6a225183b523ff6a192545f")
