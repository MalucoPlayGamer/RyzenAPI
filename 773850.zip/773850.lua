-- Lua provided by RyzenAPI 
-- Game: AppID 773850
addappid(773850)
addappid(773851, 1, "436146a27f42ad39dc7e978e0b36bfed4e3f5dfca11045a720efe09d48bf1054")
addappid(773852, 1, "16a696335ae213ec72e95bd6f0f4b8bec1d759d2bcc0a9bb42c99a40fafaa5fd")
