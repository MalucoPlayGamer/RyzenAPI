-- Lua provided by RyzenAPI
-- Game: 卜卦 / Divination

-- MAIN APPLICATION
addappid(3408480)
addappid(4567350)
-- Game: addappid(3408480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408481, 1, "ddb2e6b08e5ada555ebfad4e2e77aa352e021afca928e4bb449cb7689451c728")
