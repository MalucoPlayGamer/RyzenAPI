-- Lua provided by RyzenAPI
-- Game: Game: Backrooms Doors

-- MAIN APPLICATION
addappid(2526580)
-- Game: addappid(2526580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526581, 1, "b35cfcecb2634060c67d4daeb09a1b56c5a6da4271e387d16efd2970c1d7b135")
