-- Lua provided by RyzenAPI
-- Game: 2696120

-- MAIN APPLICATION
addappid(2696120)
-- Game: addappid(2696120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696121, 1, "f58ea4282f0cd5be1dcc2581acbf049c0d38aa47437f6987d5fb217901d33160")
