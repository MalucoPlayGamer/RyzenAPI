-- Lua provided by SkyAPI 
-- Game: Shadow Album
addappid(2696120)
addappid(2696121, 1, "f58ea4282f0cd5be1dcc2581acbf049c0d38aa47437f6987d5fb217901d33160")
