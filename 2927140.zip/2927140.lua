-- Lua provided by RyzenAPI
-- Game: addappid(2927140)

-- MAIN APPLICATION
addappid(2927140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927141, 1, "4e015e448694df0af51ec93c85355add9393cf23d569a25dbacd49415f2b82ef")
