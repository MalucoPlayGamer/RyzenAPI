-- Lua provided by RyzenAPI
-- Game: AppID 858840

-- MAIN APPLICATION
addappid(858840)

-- MAIN APP DEPOTS / PACKAGES
addappid(858841, 1, "c05e22f544d9703863b927a682bd06f3c9b4df4f73fc2cc182ec88eb3f175f9c")
