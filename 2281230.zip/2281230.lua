-- Lua provided by RyzenAPI
-- Game: Endless

-- MAIN APPLICATION
addappid(2281230)
-- Game: addappid(2281230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281232,0,"df5ed8c03004898add5864883c98871106ab948aec9e152f54f6b5f803aa69f9")
addappid(2281233,0,"813024572f59a1bc6a5c5d5d4be3b42b311847cc8357eb8b4c537dc565dc38ee")
