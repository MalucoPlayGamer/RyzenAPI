-- Lua provided by SkyAPI 
-- Game: Oil Coin
addappid(2724810)
addappid(2724811, 1, "09e3c5c0508eb26ce81e9d7882c37d210c0eb5d67a6392a89e7f322da59ab8a2")
