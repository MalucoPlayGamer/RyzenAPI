-- Lua provided by RyzenAPI
-- Game: Game: Sea Legends: Phantasmal Light Collector's Edition

-- MAIN APPLICATION
addappid(323280)
-- Game: addappid(323280)

-- MAIN APP DEPOTS / PACKAGES
addappid(323281, 1, "b0f55731e374cbfc624a7457c8b365da7fda2e0eced5326ddc59d9605bf9205d")
