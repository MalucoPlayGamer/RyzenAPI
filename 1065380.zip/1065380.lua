-- Lua provided by RyzenAPI
-- Game: Lesbian Breakout

-- MAIN APPLICATION
addappid(1065380)
-- Game: addappid(1065380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065381, 1, "49c49c78ff1a60b94134386c2ddaef6d51131e1eb3ab122eca0edda9ec81a431")
