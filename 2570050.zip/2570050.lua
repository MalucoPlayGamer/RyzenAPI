-- Lua provided by RyzenAPI
-- Game: 2570050

-- MAIN APPLICATION
addappid(2570050)
-- Game: addappid(2570050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570051, 1, "bfa7ac8d005dd92ca344ecd948df85d3f9165674b9bf585e8c19d1a8d90239c7")
