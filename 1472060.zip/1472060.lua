-- Lua provided by RyzenAPI
-- Game: Game: Apollyon: River of Life

-- MAIN APPLICATION
addappid(1472060)
-- Game: addappid(1472060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472061, 1, "9a63033db1061686fd3408847380d25ad9a2edf945396400fd582021de71143b")
