-- Lua provided by RyzenAPI
-- Game: Game: AppID 816120

-- MAIN APPLICATION
addappid(816120)
-- Game: addappid(816120)

-- MAIN APP DEPOTS / PACKAGES
addappid(816121, 1, "42f1b0b4824bfb4aa11998b87a5875fd677c6c968433683dad139726f3cb2409")
