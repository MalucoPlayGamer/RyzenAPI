-- Lua provided by RyzenAPI
-- Game: Game: Thomaz

-- MAIN APPLICATION
addappid(668560)
-- Game: addappid(668560)

-- MAIN APP DEPOTS / PACKAGES
addappid(668561, 1, "68863e8faccfbf2d34ca06a9a314795ee73195bcd2b714a43fe4e5413b923619")
