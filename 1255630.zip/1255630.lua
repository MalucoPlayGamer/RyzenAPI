-- Lua provided by RyzenAPI
-- Game: WWE 2K22

-- MAIN APPLICATION
addappid(1255630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255631, 1, "b007a1653790676fe5be33fe530f9fc7c28d0837b268088f2fd79a24685839df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1591110)
addappid(1882860)
addappid(1882861)
addappid(1882862)
addappid(1882863)
addappid(1882864)
addappid(1882865)
addappid(1882866)
addappid(1882867)
addappid(1882868)
addappid(1882870)
