-- Lua provided by RyzenAPI 
-- Game: WWE 2K22
addappid(1255630)
addappid(1255631, 1, "b007a1653790676fe5be33fe530f9fc7c28d0837b268088f2fd79a24685839df")
