-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2389760)
-- Game: addappid(2389760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389760,0,"82e74a016a0417c1572824dc83213ed03f32f3fc77e63c6d4d1e9911d30a73df")
