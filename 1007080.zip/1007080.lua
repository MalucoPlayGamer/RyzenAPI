-- Lua provided by RyzenAPI
-- Game: Death Rpg

-- MAIN APPLICATION
addappid(1007080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007081, 1, "17b413b8413f0c88ef7954bb7b92452e4da391d5a7e889b0cefb4e6a13907109")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
