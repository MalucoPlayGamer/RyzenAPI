-- Lua provided by RyzenAPI
-- Game: I Am Part-time Worker!!

-- MAIN APPLICATION
addappid(2985930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985931, 1, "3ca33f740cfdb2bd8f1bbcc4bf9ffd1c2e77c18f518030e35af44de3f7edb263")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
