-- Lua provided by RyzenAPI
-- Game: addappid(2985930)

-- MAIN APPLICATION
addappid(2985930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985931, 1, "3ca33f740cfdb2bd8f1bbcc4bf9ffd1c2e77c18f518030e35af44de3f7edb263")
