-- Lua provided by RyzenAPI
-- Game: AppID 502280

-- MAIN APPLICATION
addappid(502280)

-- MAIN APP DEPOTS / PACKAGES
addappid(502281, 1, "c7a22d692a5d4cf67b291b69245e19fe8e39d821a8447befde2e09f5c4a45503")
addappid(569710, 0, "9347f1b7bcd6f854feb5d9cb4aea70cd058d9bea4f477f2f244578f70f618d5b")
addappid(569711, 0, "2ed9308e6f152a3de13993abbc36f5490dac478341e0c62ad6ef983872c2c30a")
addappid(569712, 0, "df483f2d6915c598126d60e40b303bbbd2228ebb84692a98335c9a4fa689ad6c")
addappid(569713, 0, "438971a6e6fdbed01b6f3eecd5dbe76ff701f80e14cbcfa3874eea57ba42fa8e")
addappid(569714, 0, "8658ea8e34a7bcb854206153c2ddb93d63a57e8ae430b638475a707d52116f45")
addappid(569715, 0, "d66b4ff26df4867771d389fc230b17d44fffb2a32d0256c50933a12cf5cdf92d")
addappid(569716, 0, "fb8f10cc60c3d670a5a72f3ca57b83903955610493fd28a27f036e678c881ff1")
addappid(569717, 0, "120c2bb01b8a56f77b90e7306dad60454ae40482df36ded1c48086c3a411a6f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
