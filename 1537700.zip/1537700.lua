-- Lua provided by RyzenAPI
-- Game: Plasma Spheres

-- MAIN APPLICATION
addappid(1537700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537701, 1, "801b5edf7e6bc0132b61cd5b61c4fae431d192c2057d58f6cd8edabe32e3a202")

