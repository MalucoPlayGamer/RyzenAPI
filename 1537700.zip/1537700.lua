-- Lua provided by RyzenAPI
-- Game: Plasma Spheres

-- MAIN APPLICATION
addappid(1537700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537701, 1, "801b5edf7e6bc0132b61cd5b61c4fae431d192c2057d58f6cd8edabe32e3a202")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
