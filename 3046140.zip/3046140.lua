-- Lua provided by RyzenAPI
-- Game: Game: Haunted Property

-- MAIN APPLICATION
addappid(3046140)
-- Game: addappid(3046140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046141, 1, "6c414685cef06c7314017eb2d02b84e346f8af3b82b20b9450fe400bb97f25cc")
