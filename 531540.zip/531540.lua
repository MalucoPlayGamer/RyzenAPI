-- Lua provided by RyzenAPI
-- Game: Hidden Dimensions 3

-- MAIN APPLICATION
addappid(531540)

-- MAIN APP DEPOTS / PACKAGES
addappid(531541, 1, "af7899ee8c019c649ceac3fa2c82b1ba4de9c915b1764b394ce182128f63f76a")

