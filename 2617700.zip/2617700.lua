-- Lua provided by RyzenAPI
-- Game: Tinkerlands

-- MAIN APPLICATION
addappid(2617700)
addappid(3710880)
-- Game: addappid(2617700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617701, 1, "0151b8692c144b2d131cb45001d70cedfc16ae266e9857a28673d3db89e962ea")
