-- Lua provided by RyzenAPI
-- Game: addappid(1247880)

-- MAIN APPLICATION
addappid(1247880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247881, 1, "be437262832092be8461a6f22360a5a82ff817b9fc11a657ec5be0e5ad9a36d8")
