-- Lua provided by RyzenAPI
-- Game: Killing Floor SDK

-- MAIN APPLICATION
addappid(1260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261, 1, "2567fe45e54f11f5e0859301383b4a08a39c02668395e7ce1c58dfc05c67bf4b")

