-- Lua provided by RyzenAPI
-- Game: GhostHunter

-- MAIN APPLICATION
addappid(1715830)
-- Game: addappid(1715830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715831, 1, "9069c04570af473f28efa71f97c6ee9f25727ab750a6da3ece98307684c5fcb8")
