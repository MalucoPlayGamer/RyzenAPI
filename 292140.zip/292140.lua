-- Lua provided by RyzenAPI
-- Game: AppID 292140

-- MAIN APPLICATION
addappid(292140)

-- MAIN APP DEPOTS / PACKAGES
addappid(292141, 1, "549a471e372538d6e666807a2c77be950ad2fe1c6f2023fa8351a8a16942e913")
addappid(292142, 1, "9dc2e5803adb867ad7ab36d54856c4746af9d8f61a6ddfe1fffe1441e50380d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
