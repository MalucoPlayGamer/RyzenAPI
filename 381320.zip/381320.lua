-- Lua provided by RyzenAPI 
-- Game: Bezier
addappid(381320)
addappid(381321, 1, "d51caf4c6d7739924d70d5e4df086cf7b0755252d6aac691c675686f280a9fb4")
addappid(456560, 0, "819655545fb511695eeb2a073193eb6f4b53a3bfb8dbf8d58484c30e9e415dda")
