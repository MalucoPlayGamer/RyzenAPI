-- Lua provided by RyzenAPI
-- Game: Space Food Truck

-- MAIN APPLICATION
addappid(397390)

-- MAIN APP DEPOTS / PACKAGES
addappid(397391, 1, "71c3262d8eb2cf81dbdd816355e313d32cd8ce1f515dac98c53c52fc170765bc")
addappid(397392, 1, "adc408f490011f4801b7118bb5f41a0a1ce6545b51c89dc9b90c926e66be3bac")
addappid(397393, 1, "5f6bac82a5be1e1af5e5c6841270d42e0d30a38fe6f5876bbe8812ea540c3e42")

