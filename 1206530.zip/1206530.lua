-- Lua provided by RyzenAPI
-- Game: 1206530

-- MAIN APPLICATION
addappid(1206530)
-- Game: addappid(1206530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206532,0,"d47a8a892e04e8f6222d89c02d5a5dd587ecabf2084cd9adcae9e39a58b71e9e")
