-- Lua provided by RyzenAPI
-- Game: Game: Egg

-- MAIN APPLICATION
addappid(2784840)
-- Game: addappid(2784840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784841, 1, "42eef758b86a50a86995d956fc50c0fe1940b2600c471c414e5c3d68e4f0b8d6")
