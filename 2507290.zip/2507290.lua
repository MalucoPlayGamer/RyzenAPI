-- Lua provided by RyzenAPI
-- Game: 2507290

-- MAIN APPLICATION
addappid(2507290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507290,0,"adbd36c456d596217b9f5e17d9bd350ac1dcf6ebfa6f9b267283cd04f25f8c7e")
