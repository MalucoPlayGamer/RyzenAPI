-- Lua provided by RyzenAPI
-- Game: addappid(860540)

-- MAIN APPLICATION
addappid(860540)

-- MAIN APP DEPOTS / PACKAGES
addappid(860540,0,"499cff106925c027657394f3ffb35b408ddad25bd05cf975d438bc6831210c80")
