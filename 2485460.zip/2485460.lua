-- Lua provided by RyzenAPI
-- Game: Game: State of Survival

-- MAIN APPLICATION
addappid(2485460)
-- Game: addappid(2485460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485461, 1, "1e993f12c5ed7b57cd86fce5d77ee12d66fca99f3422fc0adbbabc62ec336ade")
