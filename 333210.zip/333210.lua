-- Lua provided by RyzenAPI
-- Game: Kaiju-A-GoGo

-- MAIN APPLICATION
addappid(333210)
addappid(363590)
addappid(376800)
addappid(393990)
addappid(415220)
addappid(415221)
addappid(544240)
addappid(544250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(333211, 1, "73124dc42f75cd47091b00dbc33ef32f6365f04cbf39d8b157e2057518622ad8")
addappid(363591, 0, "ba942ce34957afc12817fa01453330893fcd2ef734e035baafaf7d5a7a5e9fe8")

