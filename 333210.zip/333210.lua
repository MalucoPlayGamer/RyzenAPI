-- Lua provided by RyzenAPI 
-- Game: Kaiju-A-GoGo
addappid(333210)
addappid(333211, 1, "73124dc42f75cd47091b00dbc33ef32f6365f04cbf39d8b157e2057518622ad8")
addappid(363590)
addappid(363591, 0, "ba942ce34957afc12817fa01453330893fcd2ef734e035baafaf7d5a7a5e9fe8")
addappid(376800)
addappid(393990)
addappid(415220)
addappid(415221)
addappid(544240)
addappid(544250)
