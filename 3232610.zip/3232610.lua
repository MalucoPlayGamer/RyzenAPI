-- Lua provided by RyzenAPI
-- Game: Bendy: Lone Wolf

-- MAIN APPLICATION
addappid(3232610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3232611, 1, "3df3f8133026f900fd7efef895cb3ed98ad3567c0ba2c9ed5992c881b264d51b")

