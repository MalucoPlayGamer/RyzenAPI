-- Lua provided by RyzenAPI
-- Game: addappid(2949020)

-- MAIN APPLICATION
addappid(2949020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949021, 1, "363287db8d9e0d85db9972e5e7d6d3f1cd88f2f2adef8d52b799c91b8f3896e6")
