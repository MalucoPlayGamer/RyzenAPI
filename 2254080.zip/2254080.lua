-- Lua provided by RyzenAPI
-- Game: 篝火与尾巴 Demo

-- MAIN APPLICATION
addappid(2254080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254081, 1, "d2aeffd1bef4db28e64e30aefcd1fd623e8128e23540d8bbdc85f3631c51b07b")
