-- Lua provided by RyzenAPI
-- Game: AppID 2254080

-- MAIN APPLICATION
addappid(2254080)
-- Game: addappid(2254080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254081, 1, "d2aeffd1bef4db28e64e30aefcd1fd623e8128e23540d8bbdc85f3631c51b07b")
