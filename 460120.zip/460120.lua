-- Lua provided by RyzenAPI
-- Game: AppID 460120

-- MAIN APPLICATION
addappid(460120)
addappid(476860)
addappid(476861)
addappid(476862)
addappid(476863)
addappid(476864)
addappid(476865)
addappid(476866)
addappid(476867)
addappid(476868)
addappid(476869)
addappid(476870)
addappid(476871)
addappid(479240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(460121, 1, "77fb7a5c6fd3cefe6400f9b578917f38e2503c9610d656befc08f26ecfc388b0")
addappid(488340, 0, "a5fc37db26e3b60b91f14761a14af0b60b4c8c641f90af4831b2d80e90fad0e8")

