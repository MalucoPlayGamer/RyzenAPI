-- Lua provided by RyzenAPI
-- Game: 2087000

-- MAIN APPLICATION
addappid(2087000)
-- Game: addappid(2087000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087001, 1, "fa56d198777afd547c0e74ebb511869811f718670fc8a53ceed3b91a1ad188a1")
