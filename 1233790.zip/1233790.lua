-- Lua provided by SkyAPI 
-- Game: AppID 1233790
addappid(1233790)
addappid(1233791, 1, "ac52be6f310ff36b668c75205ad1d20800bbe716be467d9b2028dd107fb0b21e")
