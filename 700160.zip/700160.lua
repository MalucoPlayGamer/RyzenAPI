-- Lua provided by RyzenAPI
-- Game: addappid(700160)

-- MAIN APPLICATION
addappid(700160)

-- MAIN APP DEPOTS / PACKAGES
addappid(700161, 1, "820987c9112e222a193ad0411e36ea8ef6a0ad996057d4a46fe172d662e9425b")
