-- Lua provided by SkyAPI 
-- Game: FREE DUROV
addappid(3110010)
addappid(3110011, 1, "d03f6986d839d4e4985f1e72ca84c58a1964a311e1064b28bc5426d3a2e4a66a")
