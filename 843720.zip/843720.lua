-- Lua provided by RyzenAPI
-- Game: Dissimilated Land

-- MAIN APPLICATION
addappid(843720)
-- Game: addappid(843720)

-- MAIN APP DEPOTS / PACKAGES
addappid(843721, 1, "809c20ca8299a841d6ff347100b9eda4666e0aef91e7c9a1cdd8d77928640f5c")
