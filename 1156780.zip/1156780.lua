-- Lua provided by RyzenAPI
-- Game: Game: Teragard

-- MAIN APPLICATION
addappid(1156780)
-- Game: addappid(1156780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156781, 1, "3415f95c1d18b5fae76ae802a20c720683f3ec91bacc86edd3177c02eccf5d1b")
