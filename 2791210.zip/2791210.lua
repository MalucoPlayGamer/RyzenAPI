-- Lua provided by RyzenAPI
-- Game: DeadNeverStop

-- MAIN APPLICATION
addappid(2791210)
-- Game: addappid(2791210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791211, 1, "04257a5a987214ac01dd99e3b532485335e9ada05e73b4e6889d17bb070f8125")
