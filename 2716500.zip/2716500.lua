-- Lua provided by RyzenAPI
-- Game: 2716500

-- MAIN APPLICATION
addappid(2716500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716502,0,"87b2d2022d62ec8bee9e9779a73acd2081814fbddf51bbf3152d9a2ff4d3ab0e")

