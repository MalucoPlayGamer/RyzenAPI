-- Lua provided by RyzenAPI
-- Game: Game: Ship Graveyard Simulator 2 Demo

-- MAIN APPLICATION
addappid(2290080)
-- Game: addappid(2290080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290081, 1, "7e0dcabf6ceba46fbb042502b02232f059fe1af8c38d124590058089af869f35")
