-- Lua provided by RyzenAPI
-- Game: Help Will Come Tomorrow

-- MAIN APPLICATION
addappid(1119600)
addappid(1314150)
-- Game: addappid(1119600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119601, 1, "bc5a1ee5b785f82760dbf9b0211e1af5ab6f378f7e284005f2138d3876706295")
addappid(1119602, 1, "eb0f513829886e50ddeac5b029c79d0eb5531df48cf73cf536cbf65762522c88")
