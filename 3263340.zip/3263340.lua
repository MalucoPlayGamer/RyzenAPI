-- Lua provided by RyzenAPI
-- Game: Fishing On My Desktop

-- MAIN APPLICATION
addappid(3263340)
-- Game: addappid(3263340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263341, 1, "ef2c16ec94d0064925d9aaee07d5ac56162db479e8b0113ac3dcfada97f8df8c")
