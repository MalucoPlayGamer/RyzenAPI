-- Lua provided by SkyAPI 
-- Game: Fishing On My Desktop
addappid(3263340)
addappid(3263341, 1, "ef2c16ec94d0064925d9aaee07d5ac56162db479e8b0113ac3dcfada97f8df8c")
