-- Lua provided by RyzenAPI
-- Game: addappid(2559290)

-- MAIN APPLICATION
addappid(2559290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2559291, 1, "e9deefa0367a0f06c58ed9536c0540b4217dde5d77d95573c3184b0ed056d3f5")
