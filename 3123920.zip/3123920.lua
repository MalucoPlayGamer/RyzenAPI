-- Lua provided by RyzenAPI
-- Game: 3123920

-- MAIN APPLICATION
addappid(3123920)
-- Game: addappid(3123920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123921, 1, "988269828c61b640d49a5dd524119e5b8eff4b2553ae5a95b9ee29d2267571df")
