-- Lua provided by RyzenAPI 
-- Game: Zombie Shooter Demo
addappid(33170)
addappid(33171, 1, "a812f6a3e85977b10d5e77d48e7c65e5deee3999c64b5e22c55c9549c07b710c")
