-- Lua provided by RyzenAPI
-- Game: Zombie Shooter Demo

-- MAIN APPLICATION
addappid(33170)
-- Game: addappid(33170)

-- MAIN APP DEPOTS / PACKAGES
addappid(33171, 1, "a812f6a3e85977b10d5e77d48e7c65e5deee3999c64b5e22c55c9549c07b710c")
