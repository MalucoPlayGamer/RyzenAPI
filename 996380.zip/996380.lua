-- Lua provided by RyzenAPI
-- Game: Smartphone Tycoon

-- MAIN APPLICATION
addappid(996380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(996381, 1, "e8ca3b69ab30fe7b2ba3cf52799399c124d8ce1dfd30d4ecbb5d8ab46a43e2dc")
addappid(1045100, 0, "62776cb92973b4599b5ee2c0a4d882c7513208f8032f44d6ddf874adea770311")

