-- Lua provided by RyzenAPI
-- Game: Smartphone Tycoon

-- MAIN APPLICATION
addappid(996380)

-- MAIN APP DEPOTS / PACKAGES
addappid(996381, 1, "e8ca3b69ab30fe7b2ba3cf52799399c124d8ce1dfd30d4ecbb5d8ab46a43e2dc")
addappid(1045100, 0, "62776cb92973b4599b5ee2c0a4d882c7513208f8032f44d6ddf874adea770311")
