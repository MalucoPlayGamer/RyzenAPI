-- Lua provided by SkyAPI 
-- Game: AppID 860910
addappid(860910)
addappid(860911, 1, "254734a6d7e2c5e807aee05e7696629f521350846b2553beb9fe3bc8615e608b")
