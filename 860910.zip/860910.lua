-- Lua provided by RyzenAPI
-- Game: 860910

-- MAIN APPLICATION
addappid(860910)
-- Game: addappid(860910)

-- MAIN APP DEPOTS / PACKAGES
addappid(860911, 1, "254734a6d7e2c5e807aee05e7696629f521350846b2553beb9fe3bc8615e608b")
