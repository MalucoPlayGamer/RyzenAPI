-- Lua provided by RyzenAPI 
-- Game: Fastro Dude
addappid(3471980)
addappid(3471981, 1, "255ba73e9c294d988d0e40637964c723cac3a1c17a803c64e204e162205b5fa3")
