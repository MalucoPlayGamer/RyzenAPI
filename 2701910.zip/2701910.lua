-- Lua provided by RyzenAPI
-- Game: Ancient Russian Life Simulator

-- MAIN APPLICATION
addappid(2701910)
-- Game: addappid(2701910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701911, 1, "c9aa823e8eb644487f50615b3b0512080793a74f5a6e4e02c7406681465a3393")
