-- Lua provided by RyzenAPI
-- Game: Cuban Missile Crisis

-- MAIN APPLICATION
addappid(356270)
-- Game: addappid(356270)

-- MAIN APP DEPOTS / PACKAGES
addappid(356271, 1, "233b054b3a962bd9d19d37a1d50571784465fdd51db7d0e5210db58da658f9a7")
addappid(356272, 1, "f3a0a863e27bbb6f890b99ebf61a5cce34c054eb3b159c258b4e9562a2d6d679")
addappid(356273, 1, "528bae4c51405bf7cd9c9e24c4d7ca1d74f76ec82db062f7c4a7825da5640bc5")
addappid(356274, 1, "64b9376ffc32560bed786888fe9f8b2bf7a2e97f5584fb177bda0e84581b562a")
