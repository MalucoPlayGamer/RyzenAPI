-- Lua provided by RyzenAPI
-- Game: Holy Potatoes! We’re in Space?!

-- MAIN APPLICATION
addappid(505730)
addappid(593431)

-- MAIN APP DEPOTS / PACKAGES
addappid(505731, 1, "9588223cbd5a8950a1a48211cfffd8c6cc3ad1903e9dc97638a36b8b94ad181b")
addappid(505732, 1, "a4408b0daed90eabd61f0717a8028a2588400d16d293cb3a69e577e4fb52a623")
addappid(505733, 1, "e3e10a7d3955d7d4ca9eb535307f5d221d901f90cbda32b45fcfe7a0aac09f08")

