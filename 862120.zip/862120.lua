-- Lua provided by RyzenAPI
-- Game: Deconstructor

-- MAIN APPLICATION
addappid(862120)

-- MAIN APP DEPOTS / PACKAGES
addappid(862121, 1, "b530fb7189871d3a25e4f0e9a2276cad179740b537cd50ba7fe79a8133d8ac05")
