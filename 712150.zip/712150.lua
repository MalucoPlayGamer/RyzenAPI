-- Lua provided by RyzenAPI
-- Game: TankVR

-- MAIN APPLICATION
addappid(712150)
-- Game: addappid(712150)

-- MAIN APP DEPOTS / PACKAGES
addappid(712151, 1, "0ac5c534383693bee165cc597426fb87aa5d0e764bcab30ba79dfa045bb37dc5")
