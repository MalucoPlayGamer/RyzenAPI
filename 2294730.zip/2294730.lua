-- Lua provided by RyzenAPI
-- Game: MILFs of Sunville - Season 2

-- MAIN APPLICATION
addappid(2294730)
addappid(3987020)
-- Game: addappid(2294730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294731, 1, "e585d86495aaf9d25291a15b2389af5ecc83d2616f07fe22d221b268e00ec84e")
