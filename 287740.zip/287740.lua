-- Lua provided by RyzenAPI
-- Game: addappid(287740)

-- MAIN APPLICATION
addappid(287740)

-- MAIN APP DEPOTS / PACKAGES
addappid(287741, 1, "bb52e011b320363ecfdf3a394fdfa38d389029befbeb418b4fc36b63d4a481b1")
addappid(287742, 1, "b8402a52525b9d931dd1fcdc97c79c5b5241511f6ae00e97d567d504675ed364")
