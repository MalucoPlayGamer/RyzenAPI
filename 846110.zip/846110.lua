-- Lua provided by RyzenAPI
-- Game: The friends of Ringo Ishikawa

-- MAIN APPLICATION
addappid(846110)

-- MAIN APP DEPOTS / PACKAGES
addappid(846111, 1, "261a631717fd0ecdbbda226e47ae772965623a68eb6434094ae373350b25c3c4")
addappid(846112, 1, "3411a992b299cf6b845d0d804ad2903d1b31b1beb5126b4a3a4724f2052b482e")
addappid(1428220, 0, "9dbc7d45020d2b82792477ef4357b1c85bea4edbba12841d15f076d9afba0308")
