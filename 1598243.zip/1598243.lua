-- Lua provided by RyzenAPI
-- Game: FUSER™ - Haddaway - "What Is Love"

-- MAIN APPLICATION
addappid(1598243)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598243,0,"6140246430e03014f96b00e56700a935c92b91ffa7e36d2b33032b96c53f8345")

