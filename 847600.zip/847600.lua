-- Lua provided by RyzenAPI
-- Game: SEG Collection

-- MAIN APPLICATION
addappid(847600)

-- MAIN APP DEPOTS / PACKAGES
addappid(847601, 1, "230cf32bce492ce647be5171f9e13cddb717f84c1351745a94e8213e8c07cbf7")
