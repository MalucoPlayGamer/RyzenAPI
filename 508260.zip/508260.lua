-- Lua provided by RyzenAPI
-- Game: Game: Treasure of a Blizzard

-- MAIN APPLICATION
addappid(508260)
-- Game: addappid(508260)

-- MAIN APP DEPOTS / PACKAGES
addappid(508261, 1, "2cde30c828cb3def450667e4268d175740aca0cdd3b860a069e1bb67b2f5f60b")
