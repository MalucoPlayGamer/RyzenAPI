-- Lua provided by RyzenAPI
-- Game: Wings Of WW2

-- MAIN APPLICATION
addappid(1742900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742901, 1, "7dbcb3e5c9dadf879a22e72edb32c03fa912c039e640e53537ecfbcbc4a3dfe7")

