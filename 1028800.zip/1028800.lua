-- Lua provided by RyzenAPI
-- Game: Game: Survival Camp

-- MAIN APPLICATION
addappid(1028800)
-- Game: addappid(1028800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028801, 1, "6a591bf319af17dae407359bfad7db9cb9961ae020e11b9c66d99157422f23df")
