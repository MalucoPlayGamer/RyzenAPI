-- Lua provided by RyzenAPI 
-- Game: AppID 765320
addappid(765320)
addappid(765321, 1, "b2ac42ee8e1d0898aeab4544352f6826302a2c4205ac63f506bc931069362509")
