-- Lua provided by RyzenAPI
-- Game: Backrooms: The Silence

-- MAIN APPLICATION
addappid(3592170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3592171, 1, "e36b2330ba2a705d93479629d25169a944d58f73383995c14008fd0fbad578e7")

