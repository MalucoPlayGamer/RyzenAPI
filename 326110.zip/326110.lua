-- Lua provided by RyzenAPI
-- Game: addappid(326110)

-- MAIN APPLICATION
addappid(326110)

-- MAIN APP DEPOTS / PACKAGES
addappid(326111, 1, "96681f1d3b76ef23365f999d42adee7b7919ab4eae4e0fe16e48710d538e1c0e")
