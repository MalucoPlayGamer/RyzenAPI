-- Lua provided by RyzenAPI
-- Game: Wooden Ocean

-- MAIN APPLICATION
addappid(684000)

-- MAIN APP DEPOTS / PACKAGES
addappid(684001,0,"c05623f5c54333faa067b191056fcc01d490ed7dd0d870ce290a392b21df8458")

