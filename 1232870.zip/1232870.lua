-- Lua provided by RyzenAPI
-- Game: 1232870

-- MAIN APPLICATION
addappid(1232870)
-- Game: addappid(1232870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232872,0,"f8d4f3ef53d425b5fd1348f304bbdfe8ebae97533f9ab40b200d2d70d714b0a0")
addappid(2745020,0,"d0daf434b69f4c82c9c9478f8f341db41ad775695af17171b21794d51b9b82a3")
