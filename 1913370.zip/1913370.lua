-- Lua provided by RyzenAPI
-- Game: OPERATOR

-- MAIN APPLICATION
addappid(1913370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913371, 1, "14e1d60b03f5511ee5e4a550d5f3d5a71dd6317cf8b974cd3aec8077798ecdaf")

