-- Lua provided by RyzenAPI
-- Game: addappid(1677970)

-- MAIN APPLICATION
addappid(1677970)
addappid(3283470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677971, 1, "afba9fdf829512712bcba4a5ab6ec10b963c9b6ff125c36b33df8a0135d83932")
