-- Lua provided by RyzenAPI
-- Game: addappid(1094182)

-- MAIN APPLICATION
addappid(1094182)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094182,0,"d8f90f8c125dfb1d5670eaaf4fa62b053d4844f0027af6a40c414f1743538679")
