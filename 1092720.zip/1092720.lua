-- Lua provided by SkyAPI 
-- Game: Hello Neighbor Alpha 2
addappid(1092720)
addappid(1092721, 1, "68117c366cd4f723e9b7f0ab9c4c659207ee2d88ac89295ec8d7bdb279b5238b")
