-- Lua provided by RyzenAPI
-- Game: Hello Neighbor Alpha 2

-- MAIN APPLICATION
addappid(1092720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1092721, 1, "68117c366cd4f723e9b7f0ab9c4c659207ee2d88ac89295ec8d7bdb279b5238b")

