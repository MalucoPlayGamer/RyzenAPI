-- Lua provided by RyzenAPI
-- Game: addappid(1791080)

-- MAIN APPLICATION
addappid(1791080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791081, 1, "82f7762af1d1071d4ffdc43b448f160e95f1f8f7a21f5b0f6f42bb8be50656ac")
