-- Lua provided by RyzenAPI
-- Game: Game: CRAPPY ZOMBIE GAME

-- MAIN APPLICATION
addappid(516470)
-- Game: addappid(516470)

-- MAIN APP DEPOTS / PACKAGES
addappid(516471, 1, "1a440bfbfeb8aa60e0b44de21c17f813a67f3d71d64fb2ce1ac63fa424fd3f1a")
