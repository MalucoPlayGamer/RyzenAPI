-- Lua provided by RyzenAPI
-- Game: CRAPPY ZOMBIE GAME

-- MAIN APPLICATION
addappid(516470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(516471, 1, "1a440bfbfeb8aa60e0b44de21c17f813a67f3d71d64fb2ce1ac63fa424fd3f1a")

