-- Lua provided by RyzenAPI
-- Game: REFLEXIA Prototype ver.

-- MAIN APPLICATION
addappid(1997680)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2266310)
