-- Lua provided by RyzenAPI
-- Game: REFLEXIA Prototype ver.

-- MAIN APPLICATION
addappid(1997680)
addappid(2266310)

