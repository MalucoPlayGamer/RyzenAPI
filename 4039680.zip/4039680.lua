-- Lua provided by RyzenAPI
-- Game: Craft. Sell. Goblin. Repeat.

-- MAIN APPLICATION
addappid(5064040) -- Goblin skins - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4039680, 1, "b483b458dd12f7f473918a76880a3f67e1c806dbaa7bbf62d02ab0b1907ce05a") -- Craft. Sell. Goblin. Repeat.
addappid(4039681, 1, "3065eee2bccc93453140eb43be5f1ae1970a1b5f751a39c26aba7b0c43b8c8dd") -- Depot 4039681
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
