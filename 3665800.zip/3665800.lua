-- Lua provided by RyzenAPI
-- Game: The Communist Manifesto ~ A Visual Novel

-- MAIN APPLICATION
addappid(3665800)

