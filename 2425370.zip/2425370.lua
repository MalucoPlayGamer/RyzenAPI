-- Lua provided by RyzenAPI
-- Game: Game: Plum Blossom Divination

-- MAIN APPLICATION
addappid(2425370)
-- Game: addappid(2425370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425371, 1, "35dcaa44f2938cbeec7a27310d94192409873712744b185f06d845fd49b1832b")
