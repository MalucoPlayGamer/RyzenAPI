-- Lua provided by SkyAPI 
-- Game: Plum Blossom Divination
addappid(2425370)
addappid(2425371, 1, "35dcaa44f2938cbeec7a27310d94192409873712744b185f06d845fd49b1832b")
