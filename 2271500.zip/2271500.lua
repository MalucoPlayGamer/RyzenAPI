-- Lua provided by RyzenAPI
-- Game: Emplacement

-- MAIN APPLICATION
addappid(2271500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271502,0,"afb92bbd9fb13b3ba411574385c835bd89352f253becddeef9a6fb8fa3a675cb")
addappid(2271503,0,"5ab0073904b9f234a80f1d9fe8dd579caf19b32593298466fa1535da661e5af8")

