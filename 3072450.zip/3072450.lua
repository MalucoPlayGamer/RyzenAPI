-- Lua provided by RyzenAPI
-- Game: FAKEBOOK

-- MAIN APPLICATION
addappid(3072450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3072451, 1, "b4de1aa5137d6688358891715edcf7cb168c0c255ec52103c6d350db00617530")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5019230)
