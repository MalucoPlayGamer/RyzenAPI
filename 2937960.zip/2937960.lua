-- Lua provided by RyzenAPI
-- Game: Game: AppID 2937960

-- MAIN APPLICATION
addappid(2937960)
-- Game: addappid(2937960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937961, 1, "2590ef24e61c84ba83bb74e6a35c98ba75be053c5c98188474c11d6e78264436")
