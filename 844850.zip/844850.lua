-- Lua provided by RyzenAPI
-- Game: Tower Hunter: Erza's Trial

-- MAIN APPLICATION
addappid(844850)

-- MAIN APP DEPOTS / PACKAGES
addappid(844851, 1, "5c5c04ea58636e5a5d58daf4e989c197fd085a71373a1f9863d5e3ca29ef1021")
addappid(961630, 0, "5a03343c44e226c340b33a8020a27cbe42d3269fbee928d7cf16a6f71ab4351c")
addappid(1202080, 0, "007826f7d8390f0ba17a2d3399fcaffab700cd09e70c333a2a528edb0981209c")

