-- Lua provided by SkyAPI 
-- Game: AppID 2894940
addappid(2894940)
addappid(2894941, 1, "e4107699c22962672c79a95a8c09f87fe53609c7d331d2111705c579f6549d67")
