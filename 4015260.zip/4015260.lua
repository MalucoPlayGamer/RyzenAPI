-- Lua provided by SkyAPI 
-- Game: Slinkie Dinkie
addappid(4015260)
addappid(4015261, 1, "63d82c9d75460b4ba4f8d8a2784c971ce68554f7f51493526a859f4dca46e7d3")
