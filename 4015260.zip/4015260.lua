-- Lua provided by RyzenAPI
-- Game: addappid(4015260)

-- MAIN APPLICATION
addappid(4015260)

-- MAIN APP DEPOTS / PACKAGES
addappid(4015261, 1, "63d82c9d75460b4ba4f8d8a2784c971ce68554f7f51493526a859f4dca46e7d3")
