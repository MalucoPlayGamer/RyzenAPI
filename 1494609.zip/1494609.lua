-- Lua provided by RyzenAPI
-- Game: 1494609

-- MAIN APPLICATION
addappid(1494609)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494609,0,"77f2138a30d66bb6d9b77760c0a475931dfa23d00fb4f0bf6e5197eadf8bcbf9")

