-- Lua provided by SkyAPI 
-- Game: Farming & Supermarket Simulator Demo
addappid(3479320)
addappid(3479321, 1, "601e9c9ebe22dfbdbf3bc70d4bbfb9c55738e7f39a4d7c1f19741c7af73833a8")
