-- Lua provided by RyzenAPI
-- Game: 2864370

-- MAIN APPLICATION
addappid(2864370)
-- Game: addappid(2864370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864371, 1, "6cfbf31f2f512019547ad0a65ed1adc2009a986c43ec4c2884bb30d98b04e410")
