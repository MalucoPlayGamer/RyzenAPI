-- Lua provided by RyzenAPI
-- Game: Симулятор Сидения на Крыше

-- MAIN APPLICATION
addappid(1544510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544511, 1, "80038f645f45711db740c937c7953e34228306867f37c9aab6438fe0ba36f246")

