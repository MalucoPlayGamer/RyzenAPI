-- Lua provided by RyzenAPI
-- Game: Nobodies: After Death Demo

-- MAIN APPLICATION
addappid(1899840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899842,0,"6b9a9608eab4350f059e4f1f517773a02cc787e84cd682b567e99c0a7146e636")

