-- Lua provided by RyzenAPI
-- Game: Goddess Of Card War

-- MAIN APPLICATION
addappid(1537390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537391, 1, "d0ab3e18d2aee1a8b782295e2ef3ed91c2860bba2aae70ef0f6547b6b71b8656")

