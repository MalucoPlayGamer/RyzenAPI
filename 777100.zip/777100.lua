-- Lua provided by RyzenAPI
-- Game: 777100

-- MAIN APPLICATION
addappid(777100)
-- Game: addappid(777100)

-- MAIN APP DEPOTS / PACKAGES
addappid(777101, 1, "0f3b26ca3dd0a93651f361b88fcf723117692a3700ca78d0421b4900eb073487")
