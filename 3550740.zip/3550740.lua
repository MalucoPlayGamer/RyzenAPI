-- Lua provided by RyzenAPI
-- Game: Low-Budget Repairs Playtest

-- MAIN APPLICATION
addappid(3550740)
-- Game: addappid(3550740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3550741, 1, "93e27e2f74824c39e36e8a18cd85bf116f565d07b914d8a8094313256ca60f05")
