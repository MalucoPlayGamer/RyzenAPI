-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor 15 Plus

-- MAIN APPLICATION
addappid(969020)
addappid(969030) -- DLC 969030
addappid(969040) -- DLC 969040
addappid(969041) -- DLC 969041
addappid(969042) -- DLC 969042
addappid(969043) -- DLC 969043
addappid(969044) -- DLC 969044
addappid(969045) -- DLC 969045
addappid(971491) -- DLC 971491

-- MAIN APP DEPOTS / PACKAGES
addappid(969021, 1, "f5562c50e8bf8ee2b1c640c76a514f8861f34e1084eeb296bbbaa17f9ae29b66") -- (windows)

