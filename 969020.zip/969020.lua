-- Lua provided by RyzenAPI
-- Game: AppID 969020

-- MAIN APPLICATION
addappid(969020)
-- Game: addappid(969020)

-- MAIN APP DEPOTS / PACKAGES
addappid(969021, 1, "f5562c50e8bf8ee2b1c640c76a514f8861f34e1084eeb296bbbaa17f9ae29b66")
