-- Lua provided by SkyAPI 
-- Game: Catgirl & Doggirl Cafe
addappid(1142270)
addappid(1142271, 1, "6d7265f72472f7e2a0a28b852c34e256af58dd8d1a92ada54a0ad341baa94db7")
