-- Lua provided by RyzenAPI
-- Game: 1142270

-- MAIN APPLICATION
addappid(1142270)
-- Game: addappid(1142270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142271, 1, "6d7265f72472f7e2a0a28b852c34e256af58dd8d1a92ada54a0ad341baa94db7")
