-- Lua provided by RyzenAPI
-- Game: The Last Companion-Music&Art Collection

-- MAIN APPLICATION
addappid(1175820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175820,0,"c8a3e3b10201bd0ac36bed594814a34351f4e1a0b5b3342d2d4b287f66b5532d")

