-- Lua provided by RyzenAPI
-- Game: Game: SPY×ANYA: Operation Memories

-- MAIN APPLICATION
addappid(2170370)
-- Game: addappid(2170370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170371, 1, "b8bbfb60f43b86802b10a8c324e9efac6695acac5321c6c86b349f83d87d4e87")
