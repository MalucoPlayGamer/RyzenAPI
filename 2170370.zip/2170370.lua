-- Lua provided by RyzenAPI
-- Game: SPY×ANYA: Operation Memories

-- MAIN APPLICATION
addappid(2170370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170371, 1, "b8bbfb60f43b86802b10a8c324e9efac6695acac5321c6c86b349f83d87d4e87")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2541230)
addappid(2541240)
addappid(2541250)
addappid(2541260)
addappid(2541270)
addappid(3094060)
addappid(3094070)
addappid(3094080)
addappid(3094090)
addappid(3094100)
