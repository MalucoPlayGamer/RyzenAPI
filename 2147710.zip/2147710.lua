-- Lua provided by RyzenAPI
-- Game: Forest Spring

-- MAIN APPLICATION
addappid(2147710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147711, 1, "eb976c0abbbf33a1a20e822558ad3bcbc49fcf63bfa12443d37362060601fb5c")
