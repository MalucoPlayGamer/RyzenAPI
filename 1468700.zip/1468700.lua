-- Lua provided by RyzenAPI
-- Game: 1468700

-- MAIN APPLICATION
addappid(1468700)
-- Game: addappid(1468700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468701, 1, "cf41f55900bc8b15601d11eb4af533e94a1c6fd160fcd3a2680aad04ef691b34")
