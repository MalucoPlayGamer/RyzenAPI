-- Lua provided by RyzenAPI
-- Game: MIMIC

-- MAIN APPLICATION
addappid(759980)

-- MAIN APP DEPOTS / PACKAGES
addappid(759981, 1, "c9c84ecb7b9437bb2e690915e2d2152b3a1bd5527145933e7e9e5d92fdda65e0")

