-- Lua provided by RyzenAPI
-- Game: Hentai Fantasy Chicks

-- MAIN APPLICATION
addappid(2277050)
-- Game: addappid(2277050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277051, 1, "eaec97aea9cfc7c6b677bf4a8585ad2c4c0a6e49b79814bbfdb981fc1ee85b52")
