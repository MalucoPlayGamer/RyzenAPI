-- Lua provided by RyzenAPI
-- Game: Banebush

-- MAIN APPLICATION
addappid(2992240)
-- Game: addappid(2992240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2992241, 1, "6aea3eb091c0195f08b50456ba5d9b35d83f8b9839e4e5d5aeb4f07ba643f728")
