-- Lua provided by RyzenAPI
-- Game: Chrono Ark

-- MAIN APPLICATION
addappid(1188930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188931, 1, "2569525f62e7ec50cd4c99a87ac4c92412b017bef46ec0ebdee283c482bf438e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2780000)
addappid(3193720)
