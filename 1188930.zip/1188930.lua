-- Lua provided by RyzenAPI
-- Game: Chrono Ark

-- MAIN APPLICATION
addappid(1188930)
-- Game: addappid(1188930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188931, 1, "2569525f62e7ec50cd4c99a87ac4c92412b017bef46ec0ebdee283c482bf438e")
