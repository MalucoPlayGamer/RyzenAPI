-- Lua provided by SkyAPI 
-- Game: City Zoomer
addappid(1745790)
addappid(1745791, 1, "cc1905210192c75af9f88ed3d8b25b101bee1a466a937a2e85ab0276aed5baa7")
addappid(1745792, 1, "180ee105a48468f8baff480c3172ecd621079557b9f709c537e7f66a7c4333f9")
addappid(1745793, 1, "faf320b46532ff22041ee0b220e8dacdab4dd48e1dc095e62354a5d8bd9d7db5")
