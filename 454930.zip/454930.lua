-- Lua provided by RyzenAPI
-- Game: AppID 454930

-- MAIN APPLICATION
addappid(454930)

-- MAIN APP DEPOTS / PACKAGES
addappid(454931, 1, "cb760b0962f3af354d7f7e43be95479ac5c0a65cf28752f62cda42071df05af8")

