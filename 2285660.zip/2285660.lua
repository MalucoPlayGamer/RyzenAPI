-- Lua provided by SkyAPI 
-- Game: Richman 8 Soundtrack
addappid(2285660)
addappid(2285661, 1, "86fc07b76aff685f2def70b986051b5ba3cbdbd487af29b733373c6af803d3ea")
addappid(2285662, 1, "25edf02afaf4dc178c7faae1100d5192c23d7ca4d666e97236ce02855115a48b")
