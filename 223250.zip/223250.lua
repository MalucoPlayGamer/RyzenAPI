-- Lua provided by RyzenAPI
-- Game: Red Orchestra Linux Dedicated Server

-- MAIN APPLICATION
addappid(223250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201,0,"d3de5443d18a2f1c50dbe0e92674d93eb680a8dcfc3f531bb99e12895e5312c4")
addappid(1204,0,"d40994a03aad1b039788c2fe4c381b7115ce8b4ad59ee4c39eb8b2edb9fb7384")

