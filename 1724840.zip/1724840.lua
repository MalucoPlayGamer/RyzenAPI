-- Lua provided by SkyAPI 
-- Game: Maken-shi Sara
addappid(1724840)
addappid(1724841, 1, "149900ef25cfcaf4c4b4e306cf90fc4f0429f6ac12a9270b37becaa6e924a2d4")
