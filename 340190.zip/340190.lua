-- Lua provided by RyzenAPI
-- Game: Game: Night Crisis

-- MAIN APPLICATION
addappid(340190)
-- Game: addappid(340190)

-- MAIN APP DEPOTS / PACKAGES
addappid(340191, 1, "df3291ba28990177e41625bf85130e6789b3edddd05cfa5b7f70089209b2b223")
