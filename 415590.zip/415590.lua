-- Lua provided by RyzenAPI
-- Game: Game: Earthfall

-- MAIN APPLICATION
addappid(415590)
-- Game: addappid(415590)

-- MAIN APP DEPOTS / PACKAGES
addappid(415591, 1, "aea7b15d78d3bf150bc12d1c108701613ef7280234d444654423ddc03b0dbe35")
