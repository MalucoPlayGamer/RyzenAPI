-- Lua provided by RyzenAPI
-- Game: Stress explosion

-- MAIN APPLICATION
addappid(1291640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291641, 1, "6272393b01a556b16b4dae4ce29f52c6077a950f6b7e231f7429f6bd47c80705")
