-- Lua provided by RyzenAPI
-- Game: Game: Dragon Age: Origins - Ultimate Edition

-- MAIN APPLICATION
addappid(47810)
-- Game: addappid(47810)

-- MAIN APP DEPOTS / PACKAGES
addappid(47811, 1, "58cf3d349c0649f97ca5aed4cd4e341076b4ff75a6186983e4cf5b60337680e9")
addappid(47812, 1, "8ef7c9ef5552fdff433695f3ca71dbafbe172b3e850caead594040ea27817f9d")
addappid(47813, 1, "a5c3c9751b75af08e3c66ee80b9209bdef0006232d4944d4c6a52dbe09fabb55")
addappid(47814, 1, "02ed4d296b3c2ec5cf6b22952b99a61b16cf6a9bede1d109be60cf690a5ac629")
addappid(47816, 1, "f5fda9023a5198150e38326e1b6f6d85079dd67e2b42a078d8f1eff24084fb35")
