-- Lua provided by RyzenAPI
-- Game: addappid(2807450)

-- MAIN APPLICATION
addappid(2807450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807452,0,"c2e57234cde130d2ab596cf9f63357f52fbe42c3a3a0855e8d2d17c944cac8b7")
