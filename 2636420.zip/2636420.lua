-- Lua provided by RyzenAPI
-- Game: 2636420

-- MAIN APPLICATION
addappid(2636420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636425,0,"22c0ee329bb2967db72ffaa18a15a1afed9b6bfa6fd69e722d1c6d06bb70ddc3")
