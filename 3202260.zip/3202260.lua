-- Lua provided by RyzenAPI
-- Game: 15th Prison

-- MAIN APPLICATION
addappid(3202260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202261, 1, "045a2288eb0fcb34d59dd2be1bdf26e2d5262ff248f37161c2925cf42fe8e9d2")
