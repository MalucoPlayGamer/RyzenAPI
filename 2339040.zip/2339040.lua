-- Lua provided by RyzenAPI
-- Game: Landnama

-- MAIN APPLICATION
addappid(2339040)
-- Game: addappid(2339040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339041, 1, "46789bf5b7b445274bd3e5f4e35e2a26254ed0824ed96b19a003632f6e45e864")
addappid(2339042, 1, "4201aad31aedcd46c280ee5ce88dfe18fa08d3a5138f88ccf2b358a03c026dd5")
addappid(2339043, 1, "fa9a86cdea13ba8e744be2c38e2159753fbadb3a3b5abbbbbe694971384ea2d3")
