-- Lua provided by SkyAPI 
-- Game: Noosphere
addappid(1161430)
addappid(1161431, 1, "4740eef64e09f0c38cf814c5c4e30c29171631c896f5b516d7ad2d90703bccb9")
