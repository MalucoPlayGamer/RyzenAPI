-- Lua provided by RyzenAPI
-- Game: 1556960

-- MAIN APPLICATION
addappid(1556960)
-- Game: addappid(1556960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556961, 1, "31339dcf65372eba73f6fd9a1ae4ef2ec5852605208fbb03b3aa3a7bf24cb7e7")
