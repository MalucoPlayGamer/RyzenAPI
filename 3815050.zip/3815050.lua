-- Lua provided by RyzenAPI
-- Game: RESTORER

-- MAIN APPLICATION
addappid(3815050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3815051, 1, "d0cbdcb7ee8a2a23d4f386d1d690116de26c3e7eb323476a8101ef68a9b2d1c0")

