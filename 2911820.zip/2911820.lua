-- Lua provided by RyzenAPI
-- Game: addappid(2911820)

-- MAIN APPLICATION
addappid(2911820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911821, 1, "51f102d0748201eff0418679b9fde82d8ae8f177a895cebc35c099efc4173a15")
