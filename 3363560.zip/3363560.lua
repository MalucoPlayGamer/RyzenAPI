-- 3363560's Lua and Manifest Created by Hubcap Manifest
-- Shard Squad
-- Created: April 22, 2026 at 00:04:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3363560, 1, "c7e71dc5be1e95607c9b8b24318519c19b3034717fec061a635e79aab55eaf4c") -- Shard Squad
-- MAIN APP DEPOTS
addappid(3363561, 1, "b49c73d108547ae2a9f19d3fe028a70469935d039d0773082deb450ac461001e") -- Depot 3363561
-- setManifestid(3363561, "8805493178408425276", 1766710231)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4398470) -- Shard Squad - Wind