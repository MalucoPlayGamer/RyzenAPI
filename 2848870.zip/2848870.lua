-- Lua provided by RyzenAPI
-- Game: Terra Memoria Artbook

-- MAIN APPLICATION
addappid(2848870)
-- Game: addappid(2848870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848870,0,"3abf934e923319e27f1e07ba89f65129da8a9be7957e6f5a7bc8b6a2b468c743")
