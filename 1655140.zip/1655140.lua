-- Lua provided by RyzenAPI
-- Game: Alpaca Stacka

-- MAIN APPLICATION
addappid(1655140)

