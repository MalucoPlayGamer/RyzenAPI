-- Lua provided by RyzenAPI
-- Game: Game: Stay Close

-- MAIN APPLICATION
addappid(455120)
-- Game: addappid(455120)

-- MAIN APP DEPOTS / PACKAGES
addappid(455121, 1, "98bee7b2e46088f269ad19f4ec91ed2728c209b97501761504a6203f73379704")
