-- Lua provided by RyzenAPI
-- Game: Stay Close

-- MAIN APPLICATION
addappid(455120)

-- MAIN APP DEPOTS / PACKAGES
addappid(455121, 1, "98bee7b2e46088f269ad19f4ec91ed2728c209b97501761504a6203f73379704")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
