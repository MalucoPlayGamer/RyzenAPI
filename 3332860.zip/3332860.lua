-- Lua provided by RyzenAPI
-- Game: Sexual Sealing Dungeon: Eronest

-- MAIN APPLICATION
addappid(3332860)
-- Game: addappid(3332860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3332861, 1, "0de0253fe5191b8d81344add736cc696230499580761f70e2ce50a5672950d2d")
