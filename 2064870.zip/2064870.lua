-- Lua provided by RyzenAPI
-- Game: addappid(2064870)

-- MAIN APPLICATION
addappid(2064870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064871, 1, "b0f8bc90f762c42a1f9272a155af3c7fd5ec0c0d2b08572bda4353fd8450c827")
