-- Lua provided by RyzenAPI 
-- Game: AppID 2064870
addappid(2064870)
addappid(2064871, 1, "b0f8bc90f762c42a1f9272a155af3c7fd5ec0c0d2b08572bda4353fd8450c827")
