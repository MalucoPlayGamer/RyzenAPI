-- Lua provided by RyzenAPI
-- Game: Deceit 2

-- MAIN APPLICATION
addappid(2064870)
addappid(2783310)
addappid(3061260)
addappid(3238110)
addappid(3729090)
addappid(4010600)
addappid(4635740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2064871, 1, "b0f8bc90f762c42a1f9272a155af3c7fd5ec0c0d2b08572bda4353fd8450c827")
