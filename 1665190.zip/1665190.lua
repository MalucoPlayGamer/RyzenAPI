-- Lua provided by RyzenAPI
-- Game: Monster Prom 3: Monster Roadtrip

-- MAIN APPLICATION
addappid(1665190)
addappid(2147630)
addappid(2147631)
addappid(2147632)
addappid(2147633)
addappid(2251130)
addappid(2337900)
addappid(4072720)
addappid(4216590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665191, 1, "54444609941985bf7d7f7c095d22cbb84fcaf9a90492a369d7ca6fbee58894df")
addappid(1665192, 1, "9e3965f53b97be5d25b0dacb749767c5007d4e808866e25aff08fe238898144c")
addappid(1665193, 1, "af9a91209fc9081c4c092e660f46208968a99a131d18fd876f676c74879a2464")

