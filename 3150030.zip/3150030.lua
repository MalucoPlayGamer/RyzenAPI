-- Lua provided by RyzenAPI
-- Game: Paper Battlefield

-- MAIN APPLICATION
addappid(3150030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150031, 1, "82ab9d792128d4df020c20713de0ae3156f6e011d543f11dad9fbadf534a42f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
