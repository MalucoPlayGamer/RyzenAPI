-- Lua provided by RyzenAPI
-- Game: Paper Battlefield

-- MAIN APPLICATION
addappid(3150030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150031, 1, "82ab9d792128d4df020c20713de0ae3156f6e011d543f11dad9fbadf534a42f7")
