-- Lua provided by RyzenAPI
-- Game: FUCK HITLER

-- MAIN APPLICATION
addappid(2157110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157111, 1, "22e0f43f0752cc32700a72fd164e119a1dd89455de526334172661ad38cb89f6")
addappid(2157112, 1, "dbad6cedeef0f1f22f30e39e7f34d632880cac7b18d19b15bba26c1cd79c5959")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
