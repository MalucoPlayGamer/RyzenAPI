-- Lua provided by RyzenAPI
-- Game: Game: 刀剑竞技场 Weapons Arena Demo

-- MAIN APPLICATION
addappid(3211940)
-- Game: addappid(3211940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3211941, 1, "c1fb4e3b7d64cd64f2acab30c00146f3a60d222c0c40bece28323727c8da8ff1")
