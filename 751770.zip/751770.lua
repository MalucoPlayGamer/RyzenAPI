-- Lua provided by RyzenAPI
-- Game: addappid(751770)

-- MAIN APPLICATION
addappid(751770)

-- MAIN APP DEPOTS / PACKAGES
addappid(751771, 1, "6efe304d9babd1ea1d36a9fd7a91101c22f7b7f7b3db14bf6a07b773687dc2b2")
addappid(751775, 1, "22de72dafdad852f24eb00d2d2b185821f33fc1c87a59d9729de20e1ace2a892")
