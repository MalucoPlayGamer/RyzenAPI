-- Lua provided by RyzenAPI
-- Game: Mulite Sword Man

-- MAIN APPLICATION
addappid(1168800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1168801, 1, "5236ec7d9f55093f169277dd792ab4b9830d7e26888a36b518c09777d6487c1d")

