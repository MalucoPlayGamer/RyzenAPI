-- Lua provided by RyzenAPI
-- Game: Mulite Sword Man

-- MAIN APPLICATION
addappid(1168800)
-- Game: addappid(1168800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168801, 1, "5236ec7d9f55093f169277dd792ab4b9830d7e26888a36b518c09777d6487c1d")
