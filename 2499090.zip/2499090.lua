-- Lua provided by RyzenAPI
-- Game: Underworld Adventures

-- MAIN APPLICATION
addappid(2499090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499091, 1, "d399bbb53dc6358bf7aaa3ca23ff53ec2998b7286f4dec19070f238e70eed26b")

