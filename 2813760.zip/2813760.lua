-- Lua provided by SkyAPI 
-- Game: Anomaly Loop
addappid(2813760)
addappid(2813761, 1, "32b6052f5117fc62d142b413ba5f8233a7c1389504f07db8c924f0300bb29466")
