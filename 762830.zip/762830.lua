-- Lua provided by RyzenAPI
-- Game: 762830

-- MAIN APPLICATION
addappid(762830)
-- Game: addappid(762830)

-- MAIN APP DEPOTS / PACKAGES
addappid(762831, 1, "f281602fab8d90e65025236caf97bf0f68c4c7fe17d2354ac2581531b28825e6")
addappid(762832, 1, "c1fd5587d120754a50adfb8aa73bef7bf5e29c2625e7eeafbb143f43909e9736")
addappid(762833, 1, "b884779d0845792a768c8e5eaeb6fe114d83a1a87fa1f2b19dd8780e23b1d3fb")
