-- Lua provided by RyzenAPI
-- Game: Blood of Titans

-- MAIN APPLICATION
addappid(1451230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451231, 1, "9139503d404202494b685cd0c153da7c40d4955e09c88f86b4d285e243d2d58d")

