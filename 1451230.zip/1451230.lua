-- Lua provided by RyzenAPI
-- Game: Blood of Titans

-- MAIN APPLICATION
addappid(1451230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451231, 1, "9139503d404202494b685cd0c153da7c40d4955e09c88f86b4d285e243d2d58d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
