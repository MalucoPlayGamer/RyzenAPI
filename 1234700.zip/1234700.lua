-- Lua provided by RyzenAPI 
-- Game: Hornet Virus: Steel Alcimus II
addappid(1234700)
addappid(1234701, 1, "a7395da54c6ad01eec7ced204f244dbf850422003f87ca3a3d13f47cdc937a68")
