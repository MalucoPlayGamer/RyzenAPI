-- Lua provided by RyzenAPI
-- Game: Game: Hot Pinball Thrills

-- MAIN APPLICATION
addappid(373810)
-- Game: addappid(373810)

-- MAIN APP DEPOTS / PACKAGES
addappid(373811, 1, "a79af531ea26f906e39436b02fce7c3202803b727813d3491bdb2a7a52c56feb")
addappid(373812, 1, "69aedc8d743007224c3143b03156ea47228690dd4bd430984b28397633f16597")
addappid(373813, 1, "d6b28cd80526cd2902534f13dc761ca1d1c73c32f8c788fc83dc3092145e5dd2")
