-- Lua provided by RyzenAPI
-- Game: Autocard - Your RPG Adventure

-- MAIN APP DEPOTS / PACKAGES
addappid(4187110, 1, "fb8a090e4b6c47d619dd53f13bdc3cef796fbc86aabd3e582626fbd4c2891ca3") -- Autocard - Your RPG Adventure
addappid(4187111, 1, "4a6f862813e68a890208886c143e4e900f09af81bfe2aa8f7a972b0d4ecf2c8b") -- Depot 4187111
addappid(4187112, 1, "13a7f949665c25608028173f299923c87c3b6058d8b55f770069d4fb833c444e") -- Depot 4187112

