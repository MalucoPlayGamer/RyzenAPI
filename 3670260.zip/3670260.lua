-- 3670260's Lua and Manifest Created by Hubcap Manifest
-- Frebbventure Alliance
-- Created: August 03, 2026 at 12:23:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3670260) -- Frebbventure Alliance
-- MAIN APP DEPOTS
addappid(3670261, 1, "bf398d39f012dda2adf8b41a11b1454ebd7a3d4bc3e9aa4a356a397a7e1039d1") -- Depot 3670261
setManifestid(3670261, "8961329682449256621", 1660938239)