-- Lua provided by RyzenAPI
-- Game: Frebbventure Alliance

-- MAIN APPLICATION
addappid(3670260) -- Frebbventure Alliance

-- MAIN APP DEPOTS / PACKAGES
addappid(3670261, 1, "bf398d39f012dda2adf8b41a11b1454ebd7a3d4bc3e9aa4a356a397a7e1039d1") -- Depot 3670261

