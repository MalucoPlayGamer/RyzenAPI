-- Lua provided by RyzenAPI
-- Game: 560570

-- MAIN APPLICATION
addappid(560570)
-- Game: addappid(560570)

-- MAIN APP DEPOTS / PACKAGES
addappid(560571, 1, "11148745ee92ee295acab3dc2c8fc6cc606050aacd9d0609d4dd67553e25f79a")
