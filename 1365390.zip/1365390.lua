-- Lua provided by RyzenAPI
-- Game: Facility 47

-- MAIN APPLICATION
addappid(1365390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365391, 1, "9f9af785c4980493bc1f7b20ff86f9c5d6e5db4a60f2537fa85560e6c7daff10")

