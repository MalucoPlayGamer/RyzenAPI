-- Lua provided by RyzenAPI
-- Game: Family curse

-- MAIN APPLICATION
addappid(2166640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166641, 1, "b44378717d9c1fb3e917603ef1cd49eeb98c900e3989d23d27fd5829f647149f")
