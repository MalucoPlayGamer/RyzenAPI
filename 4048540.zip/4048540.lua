-- Lua provided by RyzenAPI
-- Game: Victor Space Program

-- MAIN APPLICATION
addappid(4048540) -- Victor Space Program

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4048542, 1, "494a198954bde04403c790a825e519446f8ccec28eb4553d6e1a1ec1c403a171") -- Depot 4048542

