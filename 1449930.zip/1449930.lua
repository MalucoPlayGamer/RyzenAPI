-- Lua provided by RyzenAPI
-- Game: 1449930

-- MAIN APPLICATION
addappid(1449930)
-- Game: addappid(1449930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449930,0,"46cb564224d92ab2bd490b3ec506f485f5a7cff2aebdd691c30f230c83526208")
