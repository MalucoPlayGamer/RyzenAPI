-- Lua provided by RyzenAPI
-- Game: AppID 776580

-- MAIN APPLICATION
addappid(776580)

-- MAIN APP DEPOTS / PACKAGES
addappid(776581, 1, "76f29de31c779ffe557ca4da9b4fb4689fdde2ddb31fe06c712fcaa66a281e14")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
