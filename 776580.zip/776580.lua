-- Lua provided by SkyAPI 
-- Game: AppID 776580
addappid(776580)
addappid(776581, 1, "76f29de31c779ffe557ca4da9b4fb4689fdde2ddb31fe06c712fcaa66a281e14")
