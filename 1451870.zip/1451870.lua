-- Lua provided by RyzenAPI
-- Game: Sunset Drive 1986

-- MAIN APPLICATION
addappid(1451870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451871, 1, "ef6ec7c72856e4f9bab9f8d5ab04bd23e210ec51d337dff539a77086452cffef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
