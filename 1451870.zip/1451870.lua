-- Lua provided by RyzenAPI 
-- Game: Sunset Drive 1986
addappid(1451870)
addappid(1451871, 1, "ef6ec7c72856e4f9bab9f8d5ab04bd23e210ec51d337dff539a77086452cffef")
