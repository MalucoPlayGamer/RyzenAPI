-- Lua provided by RyzenAPI
-- Game: 1451870

-- MAIN APPLICATION
addappid(1451870)
-- Game: addappid(1451870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451871, 1, "ef6ec7c72856e4f9bab9f8d5ab04bd23e210ec51d337dff539a77086452cffef")
