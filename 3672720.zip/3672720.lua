-- Lua provided by RyzenAPI
-- Game: Prison Escape Simulator: Dig Out

-- MAIN APPLICATION
addappid(3672720)
-- Game: addappid(3672720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3672722,0,"9b3449633eddd535ba0aa2b2b242cbe7f1bbedf545cec40ef03704ea188b19f7")
addappid(3672723,0,"5593eabd7a1b8562686afc1e18f41bbecffdacd9fd4a45e2ff681eeb0c2719cd")
