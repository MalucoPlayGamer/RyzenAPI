-- Lua provided by RyzenAPI
-- Game: Game: Sakura And The Airyvixen

-- MAIN APPLICATION
addappid(2710380)
-- Game: addappid(2710380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710381, 1, "0ca3d43eb5aa5a65418c319f841138c29fd543bdd2ac0ba985ff9245c9edf4b9")
