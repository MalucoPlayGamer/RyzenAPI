-- Lua provided by RyzenAPI
-- Game: addappid(609440)

-- MAIN APPLICATION
addappid(609440)

-- MAIN APP DEPOTS / PACKAGES
addappid(609440,0,"a089bb6f1c71102bd95d2419b112bf708c54cfd86cfe0b418a65ce0bdbb62130")
