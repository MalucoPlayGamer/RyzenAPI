-- Lua provided by RyzenAPI
-- Game: Rally Mechanic Simulator Demo

-- MAIN APPLICATION
addappid(2628090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628091, 1, "ec2c786fa2fce8b345bae268b7f626f8ca678a0b1dd6505d1a338f41c507845e")
