-- Lua provided by RyzenAPI
-- Game: addappid(1166980)

-- MAIN APPLICATION
addappid(1166980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166981, 1, "c34a9bf39f06f8b720735124b105c51707aee4b7fe2a937f679be5b987d4f467")
