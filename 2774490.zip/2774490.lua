-- Lua provided by RyzenAPI
-- Game: Dream Survivors

-- MAIN APPLICATION
addappid(2774490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774491, 1, "4795578d9ec5cc4ed9731a8e1bdd4dbc17e27139055b5ef36cc35c68531ac36f")
