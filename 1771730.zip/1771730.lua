-- Lua provided by RyzenAPI
-- Game: The City Must Grow

-- MAIN APPLICATION
addappid(1771730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771731, 1, "283b356c1d4b79271b93ab4a24bd79f0736d6ebd5dda0c3b751f729db30fa927")
addappid(1771733, 1, "8407368d2c31816b36b573c2415eec3c407ab09716c2e4b34346054b635845a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
