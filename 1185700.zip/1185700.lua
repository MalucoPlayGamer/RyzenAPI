-- Lua provided by RyzenAPI
-- Game: addappid(1185700)

-- MAIN APPLICATION
addappid(1185700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185701, 1, "9a07604ff2f0b408687ff8fc2e3a3e848e2aae17b12f4df789dd5b95d89db0d3")
