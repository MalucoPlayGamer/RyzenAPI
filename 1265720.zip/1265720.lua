-- Lua provided by RyzenAPI
-- Game: R.I.C.O. 2: London

-- MAIN APPLICATION
addappid(1265720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265721, 1, "6d835bf958bf3e489c0640f33282bc6d1788e6f8ec41dde36b07aa3249669706")

