-- Lua provided by RyzenAPI 
-- Game: AppID 1265720
addappid(1265720)
addappid(1265721, 1, "6d835bf958bf3e489c0640f33282bc6d1788e6f8ec41dde36b07aa3249669706")
