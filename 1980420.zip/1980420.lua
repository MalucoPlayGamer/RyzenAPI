-- Lua provided by RyzenAPI
-- Game: addappid(1980420)

-- MAIN APPLICATION
addappid(1980420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980421, 1, "c7a9eb3db6c7aeb90bfe90f68028d993d97ed795986b529816c4b8791a3deaef")
