-- Lua provided by RyzenAPI 
-- Game: Ranger Danger
addappid(2181980)
addappid(2181981, 1, "604658b8c0278ae333fce05cf25a2d50b91d53d5b73dab417d88908bbea1d80e")
