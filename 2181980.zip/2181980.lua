-- Lua provided by RyzenAPI
-- Game: Ranger Danger

-- MAIN APPLICATION
addappid(2181980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2181981, 1, "604658b8c0278ae333fce05cf25a2d50b91d53d5b73dab417d88908bbea1d80e")

