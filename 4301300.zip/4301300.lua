-- Lua provided by RyzenAPI
-- Game: Incrempire

-- MAIN APPLICATION
addappid(4776290) -- Incrempire - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4301300, 1, "93119126249171570e8aa22f4a0f800b93c3434617f7e09dfeee63ecc6b999d9") -- Incrempire
addappid(4301301, 1, "5919ce340c7ab32e559c6c5cc89166e2bddb56c50aea2241f6b96bceff0960ed") -- Depot 4301301
addappid(4301302, 1, "fb1a59711141c303d5c79cf8047ffc19d2330bbdc198294d112d1f9f4c8151bb") -- Depot 4301302
addappid(4301303, 1, "f2fbb9bb3ad198445dd7f761ff6a7edae346f75fed2bc347f95700f1dde67859") -- Depot 4301303

