-- Lua provided by RyzenAPI
-- Game: Game: KILL IT WITH FIRE! 2

-- MAIN APPLICATION
addappid(2357000)
-- Game: addappid(2357000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357001, 1, "0dd7f5515621a34cfe7b442968604f3f84f8036b9cfd507eff7e86e3cec4013a")
