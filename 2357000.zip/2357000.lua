-- Lua provided by RyzenAPI
-- Game: KILL IT WITH FIRE! 2

-- MAIN APPLICATION
addappid(2357000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357001, 1, "0dd7f5515621a34cfe7b442968604f3f84f8036b9cfd507eff7e86e3cec4013a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
