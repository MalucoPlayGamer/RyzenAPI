-- Lua provided by RyzenAPI
-- Game: Starbase Test Universe

-- MAIN APPLICATION
addappid(2651360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651361, 1, "6b397773c912211986b9c52beaecd06ef6ae70d86b46039d9d3d9b12f1612f36")
