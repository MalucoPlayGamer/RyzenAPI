-- Lua provided by RyzenAPI
-- Game: DFF NT: Zantetsuken, Terra Branford's 4th Weapon

-- MAIN APPLICATION
addappid(1022418)
-- Game: addappid(1022418)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022418,0,"ff973691af2630c5b0737cc696db9abd03ec37fcd947f7151ff30c0d538a845d")
