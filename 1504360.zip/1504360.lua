-- Lua provided by RyzenAPI
-- Game: Happy Day

-- MAIN APPLICATION
addappid(1504360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504361, 1, "5ed7dade9ada07f750de3c48aa891080117f4473f688b8da10edb281ce3c8967")
