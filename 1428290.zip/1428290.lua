-- Lua provided by RyzenAPI
-- Game: Game: Anime - Match The Memory

-- MAIN APPLICATION
addappid(1428290)
-- Game: addappid(1428290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428291, 1, "6285916ed4ee68a9fc9ea36e34d6bad40a6f0770196fec60ae3f1d4c9c62b976")
