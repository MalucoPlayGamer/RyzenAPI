-- Lua provided by RyzenAPI
-- Game: Orc Hunter VR

-- MAIN APPLICATION
addappid(494530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(494531, 1, "9e093088a0e21f77176e16d188aba73855d2ede52a5749465163f4a4b512e1ee")

