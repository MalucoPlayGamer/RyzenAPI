-- Lua provided by RyzenAPI
-- Game: Game: Orc Hunter VR

-- MAIN APPLICATION
addappid(494530)
-- Game: addappid(494530)

-- MAIN APP DEPOTS / PACKAGES
addappid(494531, 1, "9e093088a0e21f77176e16d188aba73855d2ede52a5749465163f4a4b512e1ee")
