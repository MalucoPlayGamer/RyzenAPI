-- Lua provided by RyzenAPI
-- Game: Game: Zero Orders Tactics Demo

-- MAIN APPLICATION
addappid(2978760)
-- Game: addappid(2978760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978761, 1, "ce5f5893c819e6cea269058b9e4d0fbfcc5b297480ff5a0add65675127cc78f8")
