-- Lua provided by RyzenAPI
-- Game: Zombie Hunter

-- MAIN APPLICATION
addappid(1723420)
-- Game: addappid(1723420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723421, 1, "96fb42fefb80bf5c65878b4b4ee6f1381ee64585e8b7005b35a4bd2bd3fc8e44")
addappid(1723422, 1, "5e74a47711bc1a2d048ff2783e8455e01f2b99873e7bc665acb81f8f61a285a8")
