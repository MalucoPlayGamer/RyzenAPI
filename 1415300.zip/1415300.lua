-- Lua provided by RyzenAPI
-- Game: addappid(1415300)

-- MAIN APPLICATION
addappid(1415300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415301, 1, "d96c1f0fa1ac1f32a62a4ddf250d37357bafb3f189a9fc97ec26e5b8dcbd5918")
