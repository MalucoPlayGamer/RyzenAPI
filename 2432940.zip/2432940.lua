-- Lua provided by RyzenAPI
-- Game: 2432940

-- MAIN APPLICATION
addappid(2432940)
-- Game: addappid(2432940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432941, 1, "6808a72b0196ba9740b81815674ec7dfe1716bb4f785ba4ef783ca29c0a221ed")
