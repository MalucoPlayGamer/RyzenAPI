-- Lua provided by RyzenAPI
-- Game: M.A.R.S.

-- MAIN APPLICATION
addappid(314430)
addappid(1668180)
addappid(1824340)
addappid(1824341)
addappid(1884930)
addappid(2198880)
addappid(2225540)
addappid(2225550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(314431, 1, "b4f7304c207ede9b4bc651a59f14982e031435414d40d3621f2ba7321eadc1eb")

