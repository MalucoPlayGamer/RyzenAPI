-- Lua provided by RyzenAPI 
-- Game: M.A.R.S.
addappid(314430)
addappid(314431, 1, "b4f7304c207ede9b4bc651a59f14982e031435414d40d3621f2ba7321eadc1eb")
