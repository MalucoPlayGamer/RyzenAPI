-- Lua provided by RyzenAPI
-- Game: Temple of the Apsara

-- MAIN APPLICATION
addappid(510910)

-- MAIN APP DEPOTS / PACKAGES
addappid(510911, 1, "85abd30b1032f15fc27aa787723edb199b345531e72a944d520616ba57298197")
