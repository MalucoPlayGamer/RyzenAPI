-- Lua provided by RyzenAPI
-- Game: 2959020

-- MAIN APPLICATION
addappid(2959020)
-- Game: addappid(2959020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959021, 1, "3fb1107c9c9886f4df8c4cdf5b6fabd24cb3ad925e1266bebde6e309c19cf7e1")
