-- Lua provided by RyzenAPI
-- Game: Yu-Gi-Oh! Duel Links

-- MAIN APPLICATION
addappid(601510)

-- MAIN APP DEPOTS / PACKAGES
addappid(601511, 1, "292e3fd64a6357401e23452f2a246e492143d4d43c954d64ad947da071dea8da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
