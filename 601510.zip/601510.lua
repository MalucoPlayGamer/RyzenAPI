-- Lua provided by RyzenAPI
-- Game: Yu-Gi-Oh! Duel Links

-- MAIN APPLICATION
addappid(601510)

-- MAIN APP DEPOTS / PACKAGES
addappid(601511, 1, "292e3fd64a6357401e23452f2a246e492143d4d43c954d64ad947da071dea8da")

