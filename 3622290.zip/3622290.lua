-- Lua provided by RyzenAPI
-- Game: Escape From kiss

-- MAIN APPLICATION
addappid(3622290)
-- Game: addappid(3622290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3622291, 1, "405d0209b99378439ff1f80df71350787833638ebb0d9e63a84b31000695bac1")
