-- Lua provided by RyzenAPI
-- Game: Game: ZombieVan Drive

-- MAIN APPLICATION
addappid(1521050)
-- Game: addappid(1521050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521051, 1, "51d8997e1f792a4b47e1907562ea267238418969cfc2411e86a415f5e749882e")
