-- Lua provided by SkyAPI 
-- Game: ZombieVan Drive
addappid(1521050)
addappid(1521051, 1, "51d8997e1f792a4b47e1907562ea267238418969cfc2411e86a415f5e749882e")
