-- Lua provided by RyzenAPI
-- Game: Game: Trials Fusion Demo

-- MAIN APPLICATION
addappid(294260)
-- Game: addappid(294260)

-- MAIN APP DEPOTS / PACKAGES
addappid(294261, 1, "fba45faa159d3a939c6401091db3c473c42a93ca39771adf4b7ce3d7b0fa1b83")
