-- Lua provided by RyzenAPI
-- Game: addappid(2845120)

-- MAIN APPLICATION
addappid(2845120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845122,0,"a156b134bb8d68379a738cf051c2c6cab26af1c88aac6a1186beed92a417eae0")
