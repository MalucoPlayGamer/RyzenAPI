-- Lua provided by RyzenAPI
-- Game: 1937820

-- MAIN APPLICATION
addappid(1937820)
addappid(1937821)
-- Game: addappid(1937820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937822,0,"2490b20d997cb282b1c52a648f6fb317cce2dfe9977de7ed4277067a81c0d288")
