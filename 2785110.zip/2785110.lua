-- Lua provided by RyzenAPI
-- Game: Evil Holiday

-- MAIN APPLICATION
addappid(2785110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2785111, 1, "3a5ef124cd4f8036c10b4e0e707e89912efb1af5f63e157c2581cdc64a9d7c75")

