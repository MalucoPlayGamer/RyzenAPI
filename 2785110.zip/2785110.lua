-- Lua provided by RyzenAPI
-- Game: addappid(2785110)

-- MAIN APPLICATION
addappid(2785110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785111, 1, "3a5ef124cd4f8036c10b4e0e707e89912efb1af5f63e157c2581cdc64a9d7c75")
