-- Lua provided by SkyAPI 
-- Game: MINT VR
addappid(811800)
addappid(811801, 1, "938532ade238cbca189e325d08c827d7418629cd19b1da68d77e0674375130b0")
