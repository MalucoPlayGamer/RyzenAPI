-- Lua provided by RyzenAPI
-- Game: Game: MINT VR

-- MAIN APPLICATION
addappid(811800)
-- Game: addappid(811800)

-- MAIN APP DEPOTS / PACKAGES
addappid(811801, 1, "938532ade238cbca189e325d08c827d7418629cd19b1da68d77e0674375130b0")
