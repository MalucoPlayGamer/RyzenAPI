-- Lua provided by RyzenAPI
-- Game: 864510

-- MAIN APPLICATION
addappid(864510)
addappid(868250)
-- Game: addappid(864510)

-- MAIN APP DEPOTS / PACKAGES
addappid(864511, 1, "740f02b1121780cb8342279bc3d90d6d0d899f93075d0289780a03fcceecb4dc")
