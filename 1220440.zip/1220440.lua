-- Lua provided by RyzenAPI
-- Game: addappid(1220440)

-- MAIN APPLICATION
addappid(1220440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220441, 1, "8319eae5be31083a8121e70e5e20fb6b2a61442cf18494fb22066c8dd0b86881")
