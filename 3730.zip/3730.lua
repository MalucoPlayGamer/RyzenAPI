-- Lua provided by RyzenAPI
-- Game: Aliens versus Predator Classic 2000

-- MAIN APPLICATION
addappid(3730)
addappid(228983)
addappid(228984)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3731, 1, "125ccc123d46be5f3c377bb97efd6b1be5a4a22ad36a791ed5f96f1391f4eefc")
addappid(3732, 1, "72372745093100cda3868c1bd8dad36e05f075e18f81fc4013a76999510d99dc")
addappid(3733, 1, "b0791d3c0e724456cfa8ed0d6d599193433de7042baec87deb2839984d697348")
addappid(3734, 1, "94cb3c80f648228652c43107ac8de2437046d62d9ef619cfdf3023fe6b5b9bf5")
addappid(3735, 1, "0c0dcbbedcfdfdb68502abf771158e2f52cbf14c732d3d9eb0a0775ae0b1b58a")
addappid(3736, 1, "a7350e2bdc4d47292d346ea05c2c896379941a246e20b768c20b3728219dfbf4")
addappid(3737, 1, "8ef6f71b7773c6237a2bb8be67e247b42d6aa61b7d85a1eb17df897df878bf28")
addappid(3738, 1, "030696c6c1b2f268cbbf25d7a713a125753763e173152137bbfd236b0322c5d0")

