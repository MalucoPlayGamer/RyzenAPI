-- Lua provided by RyzenAPI
-- Game: Demon Spore Demo

-- MAIN APPLICATION
addappid(2744940)
-- Game: addappid(2744940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744941, 1, "9691d16e1396b11f1c3dcd89222240e64c5be08cdf2869c27cc28c186667b5a9")
