-- Lua provided by RyzenAPI
-- Game: El Shaddai ASCENSION OF THE METATRON HD Remaster

-- MAIN APPLICATION
addappid(1581040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1581041, 1, "4cb5bfc0de7efce19116936e680bde99b0fb4973f017e7a0602f4df31d6694f0")
addappid(1658950, 0, "e4350e8f7b2da5093cf5fd27fa6eefbe72a9217f343147ff3b06cc4a6be025a6")

