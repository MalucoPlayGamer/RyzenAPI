-- Lua provided by RyzenAPI
-- Game: El Shaddai ASCENSION OF THE METATRON HD Remaster

-- MAIN APPLICATION
addappid(1581040)
-- Game: addappid(1581040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581041, 1, "4cb5bfc0de7efce19116936e680bde99b0fb4973f017e7a0602f4df31d6694f0")
addappid(1658950, 0, "e4350e8f7b2da5093cf5fd27fa6eefbe72a9217f343147ff3b06cc4a6be025a6")
