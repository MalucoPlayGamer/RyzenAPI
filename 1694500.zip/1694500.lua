-- Lua provided by RyzenAPI
-- Game: AppID 1694500

-- MAIN APPLICATION
addappid(1694500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694501, 1, "c941bca53e2f3ce6419db9ba54449eeb60db98807926db6dca2ab897a9b64eb3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
