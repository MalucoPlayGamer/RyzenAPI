-- Lua provided by RyzenAPI
-- Game: AppID 1694500

-- MAIN APPLICATION
addappid(1694500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694501, 1, "c941bca53e2f3ce6419db9ba54449eeb60db98807926db6dca2ab897a9b64eb3")
