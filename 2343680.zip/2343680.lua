-- Lua provided by RyzenAPI
-- Game: 2343680

-- MAIN APPLICATION
addappid(2343680)
-- Game: addappid(2343680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343681, 1, "6e1d582f0bf55e22390802551287df6f2018eb6dfa086a732f644b078d2d7f6b")
