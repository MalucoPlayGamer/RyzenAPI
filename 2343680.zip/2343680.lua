-- Lua provided by SkyAPI 
-- Game: Slave Princess Finne ~ IF Story 3
addappid(2343680)
addappid(2343681, 1, "6e1d582f0bf55e22390802551287df6f2018eb6dfa086a732f644b078d2d7f6b")
