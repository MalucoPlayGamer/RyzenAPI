-- Lua provided by RyzenAPI
-- Game: Idle Civilization

-- MAIN APPLICATION
addappid(418910)

-- MAIN APP DEPOTS / PACKAGES
addappid(418911, 1, "86e42881fa66a356f1aaaecabc0b0085cfed53ac823ae49310a861b5345e8add")
