-- Lua provided by RyzenAPI 
-- Game: Accident
addappid(852220)
addappid(852221, 1, "e602394d49906fbf17e3f4ccd81e4f256ec374b743e32810dd8c1b67e5ceaad3")
