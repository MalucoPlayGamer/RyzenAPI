-- Lua provided by RyzenAPI
-- Game: Game: Accident

-- MAIN APPLICATION
addappid(852220)
-- Game: addappid(852220)

-- MAIN APP DEPOTS / PACKAGES
addappid(852221, 1, "e602394d49906fbf17e3f4ccd81e4f256ec374b743e32810dd8c1b67e5ceaad3")
