-- Lua provided by RyzenAPI
-- Game: Red Door, Yellow Door Demo

-- MAIN APPLICATION
addappid(3070140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070141, 1, "94c8e962316164ad4a457f02dec31c9e40b7c288d81787cdbd89ecdff738f4bb")
