-- Lua provided by RyzenAPI
-- Game: Late photographer 4

-- MAIN APPLICATION
addappid(1972970)
addappid(1973200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972971, 1, "e6ed57932fa1bbff6bd0ea9cd19d7800545045d0bfd567677aedb9ffe891ebb1")
