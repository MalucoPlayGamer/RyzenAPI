-- Lua provided by SkyAPI 
-- Game: Late photographer 4
addappid(1972970)
addappid(1972971, 1, "e6ed57932fa1bbff6bd0ea9cd19d7800545045d0bfd567677aedb9ffe891ebb1")
addappid(1973200)
