-- Lua provided by RyzenAPI
-- Game: AppID 840130

-- MAIN APPLICATION
addappid(840130)
-- Game: addappid(840130)

-- MAIN APP DEPOTS / PACKAGES
addappid(840131, 1, "424734432c9bdcb59a3a257a9d1e14acba94b52cfe8d4b1439d1cea287c5bcad")
