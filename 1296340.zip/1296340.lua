-- Lua provided by RyzenAPI
-- Game: Game: AppID 1296340

-- MAIN APPLICATION
addappid(1296340)
-- Game: addappid(1296340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296341, 1, "d4bbf8c44d15026b566c8f6e9a16db572cb591601bf6a3ee539832f0bba9c419")
