-- Lua provided by RyzenAPI
-- Game: Legacy of Sin: The Father Sacrifice

-- MAIN APPLICATION
addappid(1240790)
addappid(1863580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240791, 1, "d8ad34fae1fa997887123941d18057479b0469c74cc52e578aa532d134067ca7")
addappid(1240792, 1, "cba6f39535686b0705bce3a072ecfe44a49488c52c424e4a161198678aa00c0c")
addappid(1240793, 1, "109c504065310ae593d86995f9a9b7ef0bac7d4634ca65044526c3d5d29bbbef")
