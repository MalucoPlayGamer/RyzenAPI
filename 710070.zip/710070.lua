-- Lua provided by SkyAPI 
-- Game: Helltown
addappid(710070)
addappid(710071, 1, "85166207c69b4c71cb6e31a65eddc2a36bf89aa72e6b9f694d7bd8a89bd82f4d")
