-- Lua provided by RyzenAPI
-- Game: Helltown

-- MAIN APPLICATION
addappid(710070)

-- MAIN APP DEPOTS / PACKAGES
addappid(710071, 1, "85166207c69b4c71cb6e31a65eddc2a36bf89aa72e6b9f694d7bd8a89bd82f4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
