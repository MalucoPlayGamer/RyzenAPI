-- Lua provided by RyzenAPI
-- Game: 灵魂筹码 Soul at Stake

-- MAIN APPLICATION
addappid(690530)
-- Game: addappid(690530)

-- MAIN APP DEPOTS / PACKAGES
addappid(690531, 1, "153fb427ee505c9f5974bfd0e50cd1e00790ac3def461dff49ff69bf7a0b1ed5")
