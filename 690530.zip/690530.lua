-- Lua provided by RyzenAPI
-- Game: addappid(690530)

-- MAIN APPLICATION
addappid(690530)

-- MAIN APP DEPOTS / PACKAGES
addappid(690531, 1, "153fb427ee505c9f5974bfd0e50cd1e00790ac3def461dff49ff69bf7a0b1ed5")
