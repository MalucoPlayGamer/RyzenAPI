-- Lua provided by RyzenAPI
-- Game: Riders Republic

-- MAIN APPLICATION
addappid(2290180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290181, 1, "87bb928cf12682614e38b33c1fdbcfe71c6473b5bad0c278583e2478ccf34f36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2389390)
addappid(2389391)
addappid(2389392)
addappid(2389393)
addappid(2389394)
addappid(2400940)
addappid(2466100)
addappid(2466110)
addappid(2468280)
addappid(2468281)
addappid(2550510)
addappid(2550520)
addappid(2550540)
addappid(2550550)
addappid(2550560)
addappid(2605010)
addappid(2605020)
addappid(2735800)
addappid(2735810)
addappid(4508860)
addappid(4508870)
addappid(4508890)
addappid(4508900)
addappid(4508910)
addappid(4508920)
addappid(4508930)
addappid(4508940)
addappid(4508950)
addappid(4508960)
