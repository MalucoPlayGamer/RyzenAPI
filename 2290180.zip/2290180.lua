-- Lua provided by RyzenAPI
-- Game: Riders Republic

-- MAIN APPLICATION
addappid(2290180)
-- Game: addappid(2290180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290181, 1, "87bb928cf12682614e38b33c1fdbcfe71c6473b5bad0c278583e2478ccf34f36")
