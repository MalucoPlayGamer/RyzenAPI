-- Lua provided by RyzenAPI
-- Game: Game: AppID 2149610

-- MAIN APPLICATION
addappid(2149610)
-- Game: addappid(2149610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149611, 1, "9c5a1c11193411216573c9213374f0f1f27f72d44dc00cbf81c654bb70b231dc")
