-- Lua provided by RyzenAPI
-- Game: Spoko and Poko

-- MAIN APPLICATION
addappid(365400)
-- Game: addappid(365400)

-- MAIN APP DEPOTS / PACKAGES
addappid(365401, 1, "1fb5cba5650ad7959fe0bbd11ce4f040dc9797b576f81c7f78a29b67e75f66cb")
addappid(365402, 1, "6a76d841877511f6bd055a32b45f2f8aea412ce0d1b35ead7a52b67748d5cc58")
