-- Lua provided by RyzenAPI
-- Game: Game: Boxing School 2

-- MAIN APPLICATION
addappid(2627410)
-- Game: addappid(2627410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2627411, 1, "e74ab9b45b305fdff87afcef0d6d1885727edffdf266e386b639d308bcbaa0b0")
