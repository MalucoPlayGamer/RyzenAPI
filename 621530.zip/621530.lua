-- Lua provided by RyzenAPI 
-- Game: AppID 621530
addappid(621530)
addappid(621531, 1, "c09aa9b0b78d81f593ec92a5c5f108917751f23238c02661212579d57ecad8e8")
addappid(621532, 1, "5935b95dc3fa7d31005529be0805aa2c5843fec218ea6e1a74e483de7f345572")
