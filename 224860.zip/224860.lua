-- Lua provided by RyzenAPI
-- Game: Arma Tactics

-- MAIN APPLICATION
addappid(224860)

-- MAIN APP DEPOTS / PACKAGES
addappid(224861, 1, "f832789db0e455a30977ab6e678bd23b766560119343171fdcfe9b96a4972aff")
addappid(224862, 1, "89a9e297e062d3fd31223aa9d7ceb6652fb57d8358fd3b1f48e69583a346a5c0")
addappid(224863, 1, "d2b83f270366c14d1ff31b3e91f1afead87724ac4b6095c531f3d1839880b0f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
