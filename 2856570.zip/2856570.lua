-- Lua provided by RyzenAPI
-- Game: 2856570

-- MAIN APPLICATION
addappid(2856570)
-- Game: addappid(2856570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856571, 1, "95e7a3d60cccd9ecb52ac3e2b92961b6f6028ecaccf486349dda7651e2210ab4")
