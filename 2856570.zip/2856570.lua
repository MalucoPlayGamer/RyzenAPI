-- Lua provided by RyzenAPI
-- Game: Dark Days

-- MAIN APPLICATION
addappid(2856570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856571, 1, "95e7a3d60cccd9ecb52ac3e2b92961b6f6028ecaccf486349dda7651e2210ab4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
