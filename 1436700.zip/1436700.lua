-- Lua provided by RyzenAPI
-- Game: Trine 5: A Clockwork Conspiracy

-- MAIN APPLICATION
addappid(1436700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1436701, 1, "bf5544a80247bd7318697c3a40ec6f81af90fd50855922b5fc7ebfc8bd320044")

