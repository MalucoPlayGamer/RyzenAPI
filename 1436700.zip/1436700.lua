-- Lua provided by RyzenAPI
-- Game: 1436700

-- MAIN APPLICATION
addappid(1436700)
-- Game: addappid(1436700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436701, 1, "bf5544a80247bd7318697c3a40ec6f81af90fd50855922b5fc7ebfc8bd320044")
