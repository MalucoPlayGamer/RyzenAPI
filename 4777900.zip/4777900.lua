-- Lua provided by RyzenAPI
-- Game: 樹世界：雲端庇護所

-- MAIN APPLICATION
addappid(4777900)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4942280)
addappid(4942290)
