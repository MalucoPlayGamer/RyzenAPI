-- Lua provided by RyzenAPI
-- Game: Pieces of Me: Northbound

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(1202090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202092,0,"11a38727b94f89112ec279c4dfa693a7c409a35c218918edd5287927d708e64a")

