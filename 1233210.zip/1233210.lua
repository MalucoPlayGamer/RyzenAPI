-- Lua provided by RyzenAPI
-- Game: Hentai Honeys Jigsaw

-- MAIN APPLICATION
addappid(1233210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233211, 1, "71297b52643f5691755185003b31d0d257f116b6706fb9a3425bdfdcbcfe5743")
