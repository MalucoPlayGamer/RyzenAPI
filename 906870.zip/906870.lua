-- Lua provided by RyzenAPI
-- Game: FurryFury: Smash & Roll

-- MAIN APPLICATION
addappid(906870)

-- MAIN APP DEPOTS / PACKAGES
addappid(906871, 1, "59c20ff802b73de1f52ff978ef371025a76d1a1b8c12fe475750db9db48f53e9")
