-- Lua provided by RyzenAPI
-- Game: FurryFury

-- MAIN APPLICATION
addappid(906870)
addappid(1116410)
addappid(2232670)

-- MAIN APP DEPOTS / PACKAGES
addappid(906871,0,"59c20ff802b73de1f52ff978ef371025a76d1a1b8c12fe475750db9db48f53e9")

