-- Lua provided by RyzenAPI
-- Game: Switchball HD

-- MAIN APPLICATION
addappid(1588760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1588761, 1, "631f7f8a64a6f4d7eed22b4db0d100b4ae3ce9ca24000ba47de96de81f66511f")

