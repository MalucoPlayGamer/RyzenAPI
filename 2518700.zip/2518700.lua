-- Lua provided by SkyAPI 
-- Game: The Mageseeker: A League of Legends Story™ Demo
addappid(2518700)
addappid(2518701, 1, "8c15a8e98ee351c57deb154a3391128436c33a261e25d4bbfd5da540a11c6e37")
