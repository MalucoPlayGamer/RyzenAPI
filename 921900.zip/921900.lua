-- Lua provided by RyzenAPI
-- Game: Game: My Burning Heart

-- MAIN APPLICATION
addappid(921900)
-- Game: addappid(921900)

-- MAIN APP DEPOTS / PACKAGES
addappid(921901, 1, "a4da1aaa73e1d268e914a2b8a4c9ef077b1491a7ae640806541bc792655de1ad")
