-- Lua provided by RyzenAPI 
-- Game: Conquest of Elysium 4
addappid(403950)
addappid(403951, 1, "502f9e4e4e51f6a37b84a127a1e25ec00ecffa8d1c659e2ba758082c0cea23cf")
