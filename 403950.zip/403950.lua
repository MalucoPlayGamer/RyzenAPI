-- Lua provided by RyzenAPI
-- Game: Conquest of Elysium 4

-- MAIN APPLICATION
addappid(403950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(403951, 1, "502f9e4e4e51f6a37b84a127a1e25ec00ecffa8d1c659e2ba758082c0cea23cf")

