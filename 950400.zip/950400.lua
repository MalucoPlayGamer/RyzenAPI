-- Lua provided by RyzenAPI
-- Game: Game: AppID 950400

-- MAIN APPLICATION
addappid(950400)
-- Game: addappid(950400)

-- MAIN APP DEPOTS / PACKAGES
addappid(950401, 1, "abebdee05d57d7bff538be01db0c472222c5fd3e214a1532fc137f25f3d20da8")
