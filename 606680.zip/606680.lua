-- Lua provided by RyzenAPI
-- Game: Silver

-- MAIN APPLICATION
addappid(606680)
addappid(647970)

-- MAIN APP DEPOTS / PACKAGES
addappid(606681, 1, "78de972bfd03082fd9a519c77c2f566c1f7785142d177136c9eb4e85723f7f63")
addappid(606682, 1, "ae8dec5326e5ea0c62b8cc17e1ac0157199f7867dbe4a7e6dbf4b22207cdb17f")
addappid(606683, 1, "a15c900487a0bee7b9c261caadb415fea52c6547271fa9e02befb74b6cc956ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
