-- Lua provided by SkyAPI 
-- Game: Silver
addappid(606680)
addappid(606681, 1, "78de972bfd03082fd9a519c77c2f566c1f7785142d177136c9eb4e85723f7f63")
addappid(606682, 1, "ae8dec5326e5ea0c62b8cc17e1ac0157199f7867dbe4a7e6dbf4b22207cdb17f")
addappid(606683, 1, "a15c900487a0bee7b9c261caadb415fea52c6547271fa9e02befb74b6cc956ec")
addappid(647970)
