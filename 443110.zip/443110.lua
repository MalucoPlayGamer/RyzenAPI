-- Lua provided by RyzenAPI 
-- Game: AppID 443110
addappid(443110)
addappid(443111, 1, "99104a5a92e76a1c16407c5cbad95a8635aa63c3b8dda1c80e88532819bf66b1")
