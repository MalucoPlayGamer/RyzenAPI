-- Lua provided by RyzenAPI
-- Game: Game: Space Dogfight

-- MAIN APPLICATION
addappid(1329400)
-- Game: addappid(1329400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329401, 1, "905c46bea1188deb95e04c8d7bb4e0852e221f9ea6ced7f7d6168590300f0c1c")
