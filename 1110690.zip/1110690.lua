-- Lua provided by RyzenAPI
-- Game: Banter Schooldays!!三〇一室无一人

-- MAIN APPLICATION
addappid(1110690)
-- Game: addappid(1110690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110691, 1, "76569965b650fccc5a6a269b5b14ab0b3362c10a71dba4c9142f787083d9e1c8")
addappid(1187040, 0, "d7e3b4fe255482f2e06104ad3657912b2af28c4036d449056558702ebcdf5a1d")
addappid(1187050, 0, "6e494185bf6390128c96027cc9d4b08a78260f2de83051eafe60e57e0c50fcdc")
addappid(1187060, 0, "dad03a5abaa32e4c9bd35116800138a4bf30b4edcf9387ec6059be04f17c6a45")
