-- Lua provided by RyzenAPI
-- Game: Katawa Shoujo

-- MAIN APPLICATION
addappid(3068300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3068301, 1, "29270bfd5109ae09f274f1fbf9932da3a6874689dc64fb8704e21e0ecf389992")
