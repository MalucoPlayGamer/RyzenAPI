-- Lua provided by RyzenAPI
-- Game: 1326310

-- MAIN APPLICATION
addappid(1326310)
-- Game: addappid(1326310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326311, 1, "a12f0747034dbd768866dfebe1d5d878fbc2438bf812c496efe8ebaa808f4caf")
