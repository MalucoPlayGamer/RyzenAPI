-- Lua provided by SkyAPI 
-- Game: For the GHOSTs
addappid(2487390)
addappid(2487391, 1, "f75a5b07a43a21c2ce9fd07ecf76967695301a5e49156727801b1aad3b08f871")
