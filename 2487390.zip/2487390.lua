-- Lua provided by RyzenAPI
-- Game: 2487390

-- MAIN APPLICATION
addappid(2487390)
-- Game: addappid(2487390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487391, 1, "f75a5b07a43a21c2ce9fd07ecf76967695301a5e49156727801b1aad3b08f871")
