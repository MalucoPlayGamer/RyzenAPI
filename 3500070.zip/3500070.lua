-- Lua provided by RyzenAPI
-- Game: PianoGlow Demo

-- MAIN APPLICATION
addappid(3500070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3500071, 1, "e00ab79eb86de3f3efc5fc41f8bdb6ef9d72dcfe45ea692833af5a9c30817beb")
