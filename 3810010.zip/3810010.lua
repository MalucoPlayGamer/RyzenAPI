-- Lua provided by RyzenAPI
-- Game: Overdrawn

-- MAIN APPLICATION
addappid(3810010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3810012,0,"270b35454b2659b4bcfa7cd43dd01f570ec937e42e4a7a1a3e40215a40fcf07a")

