-- Lua provided by SkyAPI 
-- Game: AppID 2237910
addappid(2237910)
addappid(2237911, 1, "66d1e387df410d06343a2b6a2fdddaf3e6269ffa6408bf4e02b11c77e65cdd3b")
