-- Lua provided by RyzenAPI 
-- Game: Hibernation Day
addappid(2331870)
addappid(2331871, 1, "fd979735f1fa145d184b8180581e95c87a09148d9f18c7a6bca099bb80ba5949")
addappid(2331872, 1, "7d3cf71c0420e3a359c4512bc13a2cd6509ad11a8940a738f2d0cb286e305846")
