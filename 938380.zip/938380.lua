-- Lua provided by RyzenAPI
-- Game: Townsmen - A Kingdom Rebuilt

-- MAIN APPLICATION
addappid(938380)
addappid(1176670)

-- MAIN APP DEPOTS / PACKAGES
addappid(938381,0,"e2343bc799cc70578f3f833d189447740e9824c230493046aec23b8698c5b545")

