-- Lua provided by RyzenAPI 
-- Game: AppID 938380
addappid(938380)
addappid(938381, 1, "e2343bc799cc70578f3f833d189447740e9824c230493046aec23b8698c5b545")
