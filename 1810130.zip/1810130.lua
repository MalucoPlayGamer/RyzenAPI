-- Lua provided by RyzenAPI
-- Game: Game: Classified Stories: Color Out of Space

-- MAIN APPLICATION
addappid(1810130)
-- Game: addappid(1810130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810131, 1, "d274e59de8a3a740bfe60b001789e85d7734afc45bd904d05d06fc592cdf0df8")
