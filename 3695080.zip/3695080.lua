-- Lua provided by RyzenAPI
-- Game: Beneath the Static

-- MAIN APPLICATION
addappid(3695080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3695081, 1, "941d3cff57c3e438e7c8d3c026049649bea8a317fdd48e43baf028c85e7d259b")
