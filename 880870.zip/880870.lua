-- Lua provided by RyzenAPI
-- Game: Donut Arena

-- MAIN APPLICATION
addappid(880870)

-- MAIN APP DEPOTS / PACKAGES
addappid(880872,0,"4a17bfab672bc0f8ba50b1af3533d55592c76811e7765c868a4688a93a1a8ef7")

