-- Lua provided by RyzenAPI
-- Game: addappid(1142850)

-- MAIN APPLICATION
addappid(1142850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142851, 1, "b374cdc13c3bf246e42b6b606940654263ac89ce87db133bf4854922b19455ba")
