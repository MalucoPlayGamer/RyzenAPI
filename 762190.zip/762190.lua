-- Lua provided by RyzenAPI
-- Game: Game: Epic Loon

-- MAIN APPLICATION
addappid(762190)
-- Game: addappid(762190)

-- MAIN APP DEPOTS / PACKAGES
addappid(762191, 1, "bea6c178297a499031d22a93c212d8fa52ab11dfb1e44de21486ee9ef376b014")
