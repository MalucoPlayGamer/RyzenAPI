-- Lua provided by RyzenAPI 
-- Game: AppID 1183720
addappid(1183720)
addappid(1183721, 1, "74ca0fa3b70310df1ae7729465d517fb27a2b03c23dd19e2d919bde7f346ef93")
