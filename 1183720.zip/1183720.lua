-- Lua provided by RyzenAPI
-- Game: Holoswitch

-- MAIN APPLICATION
addappid(1183720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183721, 1, "74ca0fa3b70310df1ae7729465d517fb27a2b03c23dd19e2d919bde7f346ef93")
