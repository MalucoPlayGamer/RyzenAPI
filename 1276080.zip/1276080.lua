-- Lua provided by RyzenAPI
-- Game: AppID 1276080

-- MAIN APPLICATION
addappid(1276080)
-- Game: addappid(1276080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276081, 1, "a495069ae300b14d097dc3cf493e920fb89de6f197275ac440e9bae149eb82e8")
