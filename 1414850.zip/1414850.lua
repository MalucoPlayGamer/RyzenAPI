-- Lua provided by RyzenAPI
-- Game: Nickelodeon All-Star Brawl

-- MAIN APPLICATION
addappid(1414850)
addappid(1944980)
addappid(1946940)
addappid(1967790)
addappid(1967791)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1414851, 1, "53e7f3936af23e3ded4233db79608e2ed462e5ee21cda975efd9925d88210af3")
addappid(1414853, 1, "f4705a3c9653ce0c59bfee78c7f817e574367b44c1878a1d3feeec8b161f494d")

