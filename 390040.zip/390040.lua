-- Lua provided by RyzenAPI
-- Game: Small Radios Big Televisions

-- MAIN APPLICATION
addappid(390040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(390041, 1, "19dd4f934abd6c9b888340c6e2e9f2b9574dd405542a012e48ec0d7030810acc")
addappid(520620, 0, "be551893dcb86042925c670ba56c9c7135021997305657042712ad1f431b1519")

