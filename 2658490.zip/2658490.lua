-- Lua provided by RyzenAPI
-- Game: The Dark Survivors

-- MAIN APPLICATION
addappid(2658490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658491, 1, "98aa05fe6fd3f2709dae0fd0d2e655d4f1164b5036da5d24486f752444543058")

