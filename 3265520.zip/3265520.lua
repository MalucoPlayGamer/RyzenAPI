-- Lua provided by RyzenAPI
-- Game: addappid(3265520)

-- MAIN APPLICATION
addappid(3265520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265521, 1, "0efce18e06434e39ecf275fedc0b8c14ccc8e89e4b91ccc05a46f29121fc0ce5")
