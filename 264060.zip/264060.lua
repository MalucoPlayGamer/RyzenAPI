-- Lua provided by RyzenAPI
-- Game: Full Bore

-- MAIN APPLICATION
addappid(264060)

-- MAIN APP DEPOTS / PACKAGES
addappid(264061, 1, "2427511e3e1ebb63a1c046ea832f55fd697502f7e257bab4ae667f4e32c60f96")
addappid(264062, 1, "a655ccc2021c9ed70c3dabef66cc9e49b89ac5f1f2c35b3635a28183a61bbbeb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
