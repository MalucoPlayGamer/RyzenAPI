-- Lua provided by RyzenAPI
-- Game: 264060

-- MAIN APPLICATION
addappid(264060)
-- Game: addappid(264060)

-- MAIN APP DEPOTS / PACKAGES
addappid(264061, 1, "2427511e3e1ebb63a1c046ea832f55fd697502f7e257bab4ae667f4e32c60f96")
addappid(264062, 1, "a655ccc2021c9ed70c3dabef66cc9e49b89ac5f1f2c35b3635a28183a61bbbeb")
