-- Lua provided by RyzenAPI
-- Game: Nekojishi

-- MAIN APPLICATION
addappid(570840)
addappid(754770)
addappid(848320)

-- MAIN APP DEPOTS / PACKAGES
addappid(570841, 1, "ef2b84a37bdc52a24d818c996942304bdf4e5eda3172d8f5d237182881d14699")

