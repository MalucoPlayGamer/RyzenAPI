-- Lua provided by RyzenAPI
-- Game: addappid(1048875)

-- MAIN APPLICATION
addappid(1048875)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048875,0,"77a7aa8a7e3fcd95c1870dacad1be2121d837338e93820df710e16463e5e529e")
