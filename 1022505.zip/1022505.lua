-- Lua provided by RyzenAPI
-- Game: DFF NT: Conflicted Hero Appearance Set for Vaan

-- MAIN APPLICATION
addappid(1022505)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022505,0,"2b170e54f370defa81c0658c60870f8f6308bbb55079ebc4f05dd74bee3037ec")

