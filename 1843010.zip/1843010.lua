-- Lua provided by SkyAPI 
-- Game: DJMAX RESPECT V - V EXTENSION II Original Soundtrack
addappid(1843010)
addappid(1843011, 1, "d5bcd4b32a99828fa08a155c81e08f30a4b0f5f6e22a8feb815ec3ed9590b71d")
addappid(1843012, 1, "02d603df82b9af5ea717d0c65104c5d23dbb5c9bd37b9a8a9abd7a72ff214872")
