-- Lua provided by RyzenAPI
-- Game: Game: AppID 586400

-- MAIN APPLICATION
addappid(586400)
-- Game: addappid(586400)

-- MAIN APP DEPOTS / PACKAGES
addappid(586401, 1, "ccf17e59ded4b956ab96a86996de6ec6a445a17658d4a158ae94af585911668e")
