-- Lua provided by RyzenAPI
-- Game: Game: Tap Ninja - Idle game

-- MAIN APPLICATION
addappid(1891700)
-- Game: addappid(1891700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891701, 1, "19070f5016e97e5ef04140e98d32d916719541d02b5957015389bc16986bae85")
addappid(1891702, 1, "c877b359f501fb7751bd7c1bf4abd2d8709929efb0d4a002a98ff88d5f0d1ee2")
addappid(1891703, 1, "f2708005db31290c68494077e125e80e53a12d701c2d28fba7ce834d1ebe9e78")
