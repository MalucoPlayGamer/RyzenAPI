-- Lua provided by RyzenAPI
-- Game: addappid(2617400)

-- MAIN APPLICATION
addappid(2617400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617401, 1, "9dc42a77ffb3824795ad6bfdc5f1334383fbce75b188877de69733654adf1283")
