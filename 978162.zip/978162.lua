-- Lua provided by RyzenAPI
-- Game: 978162

-- MAIN APPLICATION
addappid(978162)

-- MAIN APP DEPOTS / PACKAGES
addappid(978162,0,"de8fb2a174ff3d5d178465d1a2a8c4d04ccf4232bfa783b6eb361617f0013fc0")
