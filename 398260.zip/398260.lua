-- Lua provided by RyzenAPI
-- Game: Eyestorm

-- MAIN APPLICATION
addappid(398260)

-- MAIN APP DEPOTS / PACKAGES
addappid(398261, 1, "6fe34a6b1d4b99f76b51150c2c646c5f41c491f38daa9ea02cb0d0db11b3f7bf")

