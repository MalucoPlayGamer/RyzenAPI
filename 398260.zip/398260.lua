-- Lua provided by RyzenAPI
-- Game: Eyestorm

-- MAIN APPLICATION
addappid(398260)

-- MAIN APP DEPOTS / PACKAGES
addappid(398261, 1, "6fe34a6b1d4b99f76b51150c2c646c5f41c491f38daa9ea02cb0d0db11b3f7bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
