-- Lua provided by SkyAPI 
-- Game: Gynocracy
addappid(2493220)
addappid(2493221, 1, "2e0c26630226f97891cf51ed813f42648530bf8418dc782e5118e30ac4ef2ae5")
