-- Lua provided by RyzenAPI
-- Game: Gynocracy

-- MAIN APPLICATION
addappid(2493220)
-- Game: addappid(2493220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493221, 1, "2e0c26630226f97891cf51ed813f42648530bf8418dc782e5118e30ac4ef2ae5")
