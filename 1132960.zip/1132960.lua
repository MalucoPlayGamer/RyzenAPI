-- Lua provided by RyzenAPI
-- Game: At Home Alone II - Original_Soundtrack

-- MAIN APPLICATION
addappid(1132960)
-- Game: addappid(1132960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132963,0,"3180c6aa80ae8dd61e959d7786fc1c7d3f685468bc6957f85e38b1b8c5ab779d")
