-- Lua provided by RyzenAPI
-- Game: Platform 8

-- MAIN APPLICATION
addappid(2903560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903561, 1, "b7881ef4fccda50067ecd42b37a78456d65363f912a0e94cdf84aa05249b67c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
