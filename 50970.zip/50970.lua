-- Lua provided by RyzenAPI
-- Game: Game: AppID 50970

-- MAIN APPLICATION
addappid(50970)
-- Game: addappid(50970)

-- MAIN APP DEPOTS / PACKAGES
addappid(50971, 1, "8223f27229abaf237a3fe69dba34500045cebe08d665a74edd5fa4222b0635dc")
