-- Lua provided by RyzenAPI
-- Game: Honey, I Joined a Cult

-- MAIN APPLICATION
addappid(841190)
addappid(2145890)

-- MAIN APP DEPOTS / PACKAGES
addappid(841191, 1, "02bb3c1812922d5278fc25587e0d747005229a268087a7eed26c19fdf169e743")
addappid(2192050, 0, "8505f6a502cf7d8b626ffd40e9783c86e74fa0d5309554099ff3838155a30817")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
