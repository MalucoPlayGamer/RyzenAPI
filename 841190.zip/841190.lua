-- Lua provided by RyzenAPI 
-- Game: Honey, I Joined a Cult
addappid(841190)
addappid(841191, 1, "02bb3c1812922d5278fc25587e0d747005229a268087a7eed26c19fdf169e743")
addappid(2145890)
addappid(2192050, 0, "8505f6a502cf7d8b626ffd40e9783c86e74fa0d5309554099ff3838155a30817")
