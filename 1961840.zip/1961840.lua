-- Lua provided by RyzenAPI
-- Game: addappid(1961840)

-- MAIN APPLICATION
addappid(1961840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961841, 1, "9f2df94ce8cc2708a6702f35c9ff3b0e8e7486e318e02469865d654efe09f234")
