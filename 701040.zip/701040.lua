-- Lua provided by RyzenAPI
-- Game: CometStriker DX

-- MAIN APPLICATION
addappid(701040)

-- MAIN APP DEPOTS / PACKAGES
addappid(701041,0,"08f710bae5ab63b63a0143dfb35c7df98a6d6e477035eb368931ff1081a4fe72")
addappid(701044,0,"4cb1f39004ba8ebfd9d49e93f5f9ebcffcc54d255e6899ec729a718d8611f934")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
