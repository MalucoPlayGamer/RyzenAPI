-- Lua provided by RyzenAPI
-- Game: CometStriker DX

-- MAIN APPLICATION
addappid(701040)

-- MAIN APP DEPOTS / PACKAGES
addappid(701041,0,"08f710bae5ab63b63a0143dfb35c7df98a6d6e477035eb368931ff1081a4fe72")
addappid(701044,0,"4cb1f39004ba8ebfd9d49e93f5f9ebcffcc54d255e6899ec729a718d8611f934")

