-- Lua provided by RyzenAPI
-- Game: Bloons TD 6

-- MAIN APPLICATION
addappid(960090)
addappid(3377850)
addappid(4096360)

-- MAIN APP DEPOTS / PACKAGES
addappid(960091,0,"fa0fa5bda5003ddb011da9f8fd27d1680b2128487a5b03b752ad0772e0f52cd9")
addappid(960093,0,"dd1593b861e9bd1297c007a48bc6c5d6e2a6a8b3ba8808d76534e20afe5012d6")

