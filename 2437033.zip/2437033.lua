-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Svalbard XP

-- MAIN APPLICATION
addappid(2437033)
-- Game: addappid(2437033)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437033,0,"91967880149da6732c3863ed7ced26726aac24aaa5c1d9e48d1fa97d2ba9a6f8")
