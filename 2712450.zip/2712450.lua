-- Lua provided by RyzenAPI
-- Game: OnePunch

-- MAIN APPLICATION
addappid(2712450)
addappid(2897480)
addappid(2897630)
addappid(2897640)
addappid(2897650)
addappid(2897660)
addappid(2897670)
-- Game: addappid(2712450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712451, 1, "33f025b590f571b9190b0fc25c02d83958183d7753ebd59acf03be1aee075540")
