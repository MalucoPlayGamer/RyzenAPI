-- Lua provided by RyzenAPI
-- Game: The Eternal Cylinder Soundtrack

-- MAIN APPLICATION
addappid(2213630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213631, 1, "cf4f80f706e0df996d227bdb07d7325b8e6f110c6cbcaba8207d78d645f47c29")
addappid(2213632, 1, "8c53c68f8b73ad020660c2c296963da7d9763d91f539e43620c32c4496600157")
