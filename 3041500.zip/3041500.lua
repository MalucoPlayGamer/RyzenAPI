-- Lua provided by RyzenAPI
-- Game: 3041500

-- MAIN APPLICATION
addappid(3041500)
-- Game: addappid(3041500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041501, 1, "903064fbcd62fd88cf2aebcc3275533cbe8f920eb9506afe41c1cbc8c244d790")
