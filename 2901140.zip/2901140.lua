-- Lua provided by RyzenAPI
-- Game: 2901140

-- MAIN APPLICATION
addappid(2901140)
addappid(2993420)
-- Game: addappid(2901140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901141, 1, "093a5d86678e529aaa1387aa171e85a0ba6d0d79d2ffed11edf4a80342cad449")
