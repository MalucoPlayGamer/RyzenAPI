-- Lua provided by RyzenAPI
-- Game: Casino Roulette: Roulettist

-- MAIN APPLICATION
addappid(3601420)
