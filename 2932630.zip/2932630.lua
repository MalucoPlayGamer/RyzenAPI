-- Lua provided by RyzenAPI
-- Game: Manor Lords - Soundtrack

-- MAIN APPLICATION
addappid(2932630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932631, 1, "19d54cc71d9f34c8ab79b0c9b083021ccacf9efb02c70e8f3cf3d3c997779cc0")
addappid(2932633, 1, "d0c4ca72a290ec9043a3550a7f37b90000d4b60b44410a3ed75881a3cd0f7626")

