-- Lua provided by RyzenAPI
-- Game: Placid Plastic Desktop

-- MAIN APPLICATION
addappid(2852770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852771, 1, "984f7b650bf09395051e322ba6166457de119856a111487c5c86847e51f957de")

