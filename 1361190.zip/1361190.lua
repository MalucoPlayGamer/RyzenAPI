-- Lua provided by RyzenAPI
-- Game: Game: Brain Marmelade

-- MAIN APPLICATION
addappid(1361190)
-- Game: addappid(1361190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361191, 1, "c3d6995e6ca4153cd5cd5c13117036aa225aa3f1ed7dba6dd82008178dd3df90")
