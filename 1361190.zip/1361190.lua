-- Lua provided by RyzenAPI 
-- Game: Brain Marmelade
addappid(1361190)
addappid(1361191, 1, "c3d6995e6ca4153cd5cd5c13117036aa225aa3f1ed7dba6dd82008178dd3df90")
