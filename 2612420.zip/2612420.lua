-- Lua provided by RyzenAPI
-- Game: Virtu-Pilot

-- MAIN APPLICATION
addappid(2612420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612421, 1, "1531d273d11e7df218b9ace8fe1f321f1bcd9a26441b3f5e7c553eb6ebc080af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
