-- Lua provided by RyzenAPI
-- Game: addappid(2612420)

-- MAIN APPLICATION
addappid(2612420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612421, 1, "1531d273d11e7df218b9ace8fe1f321f1bcd9a26441b3f5e7c553eb6ebc080af")
