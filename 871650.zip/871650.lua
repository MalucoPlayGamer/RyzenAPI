-- Lua provided by RyzenAPI
-- Game: 871650

-- MAIN APPLICATION
addappid(871650)
-- Game: addappid(871650)

-- MAIN APP DEPOTS / PACKAGES
addappid(871650,0,"df672d0a119ea59fb1f18e47bc916d62b03ba388d8e51af554f626080de79cb5")
addappid(871653,0,"0773e75e22c2bc47a4edab5ec16b52e2b47fd69b8967379e3f826b573e4fe965")
addappid(871654,0,"8ae8799ef5fcedc9908b8abd6eb0ac3a8d2bb32249db91fb17c89ea080b108a6")
