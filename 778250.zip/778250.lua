-- Lua provided by RyzenAPI
-- Game: Battle of Kings VR

-- MAIN APPLICATION
addappid(778250)

-- MAIN APP DEPOTS / PACKAGES
addappid(778251, 1, "cd9b7f777156584133447550b046cca2942223104ced05eeb76c034a7e33bfbd")

