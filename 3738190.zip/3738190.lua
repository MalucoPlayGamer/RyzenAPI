-- Lua provided by RyzenAPI
-- Game: Game: Save stray cats

-- MAIN APPLICATION
addappid(3738190)
-- Game: addappid(3738190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3738191, 1, "cc0364dcddd17f14a8cf81517de49ef58627dc82eda24c4ff294e02c0c92e12f")
