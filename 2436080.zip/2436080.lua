-- Lua provided by RyzenAPI
-- Game: Lotte Forest Ambience

-- MAIN APPLICATION
addappid(2436080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436081, 1, "2c81891639c06355d12a6e97e3c240a5d1a9a10c5402419390442f8ecc6a86a1")
