-- Lua provided by RyzenAPI 
-- Game: Chimeraland
addappid(1913730)
addappid(1913731, 1, "c614df824196aa06a937d16ec86b629b1948bd191197d414a06269402709326b")
