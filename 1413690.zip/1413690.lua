-- Lua provided by RyzenAPI
-- Game: The Chrono Jotter Demo

-- MAIN APPLICATION
addappid(1413690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413691, 1, "8aa0fc9b1976a82970d3eaec209b5d791a56292fe9ce7440616f157784912ba2")
