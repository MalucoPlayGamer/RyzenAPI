-- Lua provided by RyzenAPI
-- Game: Game: WonderLang Polyglot

-- MAIN APPLICATION
addappid(3599480)
-- Game: addappid(3599480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3599481, 1, "c19e7e39c89d2e5d1c957d368cb94ed9d0b64b7c7a6e6ae001e4c2f05e8b84ce")
