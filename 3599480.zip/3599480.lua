-- Lua provided by SkyAPI 
-- Game: WonderLang Polyglot
addappid(3599480)
addappid(3599481, 1, "c19e7e39c89d2e5d1c957d368cb94ed9d0b64b7c7a6e6ae001e4c2f05e8b84ce")
