-- Lua provided by RyzenAPI
-- Game: KnightOut

-- MAIN APPLICATION
addappid(700360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(700361, 1, "bd0a827e5e2c51874265a13224c9261e25cb754693b1bbaad28b02a331ca9df5")
