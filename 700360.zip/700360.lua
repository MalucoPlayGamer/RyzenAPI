-- Lua provided by RyzenAPI
-- Game: addappid(700360)

-- MAIN APPLICATION
addappid(700360)

-- MAIN APP DEPOTS / PACKAGES
addappid(700361, 1, "bd0a827e5e2c51874265a13224c9261e25cb754693b1bbaad28b02a331ca9df5")
