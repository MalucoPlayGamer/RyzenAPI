-- Lua provided by RyzenAPI
-- Game: Run a Café Demo

-- MAIN APPLICATION
addappid(2596360)
-- Game: addappid(2596360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596361, 1, "bb5580c675ef8cd02e1e1eac440ef46987af442fa9e4d5aa050fec0ef2478fd2")
