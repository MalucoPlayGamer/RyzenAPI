-- Lua provided by RyzenAPI
-- Game: 1407230

-- MAIN APPLICATION
addappid(1407230)
-- Game: addappid(1407230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407231, 1, "30ce46c6d3e1edf76835186f96646025ebab3367919c3205b20be25cee210b56")
