-- Lua provided by RyzenAPI 
-- Game: AppID 1407230
addappid(1407230)
addappid(1407231, 1, "30ce46c6d3e1edf76835186f96646025ebab3367919c3205b20be25cee210b56")
