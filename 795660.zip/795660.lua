-- Lua provided by RyzenAPI 
-- Game: AppID 795660
addappid(795660)
addappid(795661, 1, "e5edfde92ebaba5c54dc241dc9f36976ee0ef3c9082f23adc1a23a5fed4da40d")
addappid(795662, 1, "0d209da9248e5dfe5d29face4e5857f42729b1b2b60675a83a01533eecfefcb9")
addappid(795663, 1, "c4efad3a3710d2b404d15133cd1935d0d28c9fb62c84960569e9592efe22bc05")
