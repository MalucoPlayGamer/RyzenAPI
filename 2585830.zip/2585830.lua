-- Lua provided by RyzenAPI
-- Game: Promise Mascot Agency

-- MAIN APPLICATION
addappid(2585830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585831, 1, "144bcb22da1983f95426c7e279453e0971d647bddbcc702a96257d602a2a2856")

