-- Lua provided by RyzenAPI
-- Game: Promise Mascot Agency

-- MAIN APPLICATION
addappid(2585830)
addappid(3899690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2585831, 1, "144bcb22da1983f95426c7e279453e0971d647bddbcc702a96257d602a2a2856")

