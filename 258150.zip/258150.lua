-- Lua provided by SkyAPI 
-- Game: AppID 258150
addappid(258150)
addappid(258151, 1, "d66d298a6c201f7d136546307e3d9fc6dedae6f66b8b936fcb194b8c40fb68cc")
