-- Lua provided by RyzenAPI
-- Game: Battle Squares

-- MAIN APPLICATION
addappid(3180450)
-- Game: addappid(3180450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180451, 1, "3111d829bfd580bae31dbaf2593914d19422cd781f0b64975fd3d0372a95b381")
