-- Lua provided by RyzenAPI
-- Game: The Viking Way

-- MAIN APPLICATION
addappid(1377540)
-- Game: addappid(1377540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377541, 1, "4d60caf27041cb35a801e5f7cc0a2516b6f9d7a29962445925b99d8237094d39")
