-- Lua provided by RyzenAPI 
-- Game: Cube
addappid(1404770)
addappid(1404771, 1, "0584ef5f7a90fd6c68cef840af1c6d22f6b25f6e0ad7419b0fc7c182e2980eaf")
