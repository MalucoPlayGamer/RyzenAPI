-- Lua provided by RyzenAPI
-- Game: Game: Cube

-- MAIN APPLICATION
addappid(1404770)
-- Game: addappid(1404770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404771, 1, "0584ef5f7a90fd6c68cef840af1c6d22f6b25f6e0ad7419b0fc7c182e2980eaf")
