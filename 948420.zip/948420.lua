-- Lua provided by RyzenAPI
-- Game: EXAPUNKS: TEC Redshift Player

-- MAIN APPLICATION
addappid(948420)
-- Game: addappid(948420)

-- MAIN APP DEPOTS / PACKAGES
addappid(948421, 1, "b25a3597f23ee6e88688f9ed241ddd21b50aca35979e73c9f13268e3c137cb22")
addappid(948422, 1, "f0c61b9827936a6efc5ff2bead39709b9c1d40e3ed9b260b99be9b35786c06b5")
addappid(948423, 1, "45880e1b5229550ee4bc13a5bff9004c5b0f662374a761de0b60609f8ea46f9f")
