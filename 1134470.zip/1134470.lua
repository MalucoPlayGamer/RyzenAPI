-- Lua provided by RyzenAPI
-- Game: addappid(1134470)

-- MAIN APPLICATION
addappid(1134470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134471, 1, "f99a78e43837b0ad197437e36125ed80f285d04ba3b2001448eab4e5a0a77bca")
