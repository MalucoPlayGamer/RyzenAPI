-- Lua provided by RyzenAPI
-- Game: addappid(1644510)

-- MAIN APPLICATION
addappid(1644510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644511, 1, "b54a4e21a380e1fd3165ef24803665250c04d28164f6f4be8b0621ca30c391ca")
