-- Lua provided by RyzenAPI
-- Game: Siberian experiment

-- MAIN APPLICATION
addappid(3627950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3627951, 1, "7b50d62763e10eb6f8475afaaaa8502c9a097df20cb015f4d61d68f143801ba2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
