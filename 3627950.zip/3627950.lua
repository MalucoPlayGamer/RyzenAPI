-- Lua provided by RyzenAPI 
-- Game: Siberian experiment
addappid(3627950)
addappid(3627951, 1, "7b50d62763e10eb6f8475afaaaa8502c9a097df20cb015f4d61d68f143801ba2")
