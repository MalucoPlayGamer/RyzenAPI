-- Lua provided by RyzenAPI
-- Game: AppID 2852380

-- MAIN APPLICATION
addappid(2852380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852381, 1, "eb0a35e863318c1bb7a49f861fd1dfa4804a63e8ee6fc0a022a14be43ffa83fa")
