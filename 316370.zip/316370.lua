-- Lua provided by RyzenAPI
-- Game: Wave of Darkness

-- MAIN APPLICATION
addappid(316370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(316371, 1, "b092d6bdcbbf8dd5de9e94d8753b3374ecf06d3c01c5db1cc7b310598b58d80c")

