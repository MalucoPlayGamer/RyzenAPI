-- Lua provided by RyzenAPI
-- Game: addappid(316370)

-- MAIN APPLICATION
addappid(316370)

-- MAIN APP DEPOTS / PACKAGES
addappid(316371, 1, "b092d6bdcbbf8dd5de9e94d8753b3374ecf06d3c01c5db1cc7b310598b58d80c")
