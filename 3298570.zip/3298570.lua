-- Lua provided by RyzenAPI
-- Game: Game: The Legend of Cyber Cowboy

-- MAIN APPLICATION
addappid(3298570)
-- Game: addappid(3298570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298571, 1, "aa24d87367dde72b58fb9635cd1a50b43f54a17aa1be1d041577eb698797f10d")
