-- Lua provided by RyzenAPI
-- Game: addappid(3000550)

-- MAIN APPLICATION
addappid(3000550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3000551, 1, "80dc10033069af93e8d41e696cea7fcabc93cb0a3f04e0a27433c4a0096afec0")
