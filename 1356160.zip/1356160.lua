-- Lua provided by RyzenAPI
-- Game: Andromeda One Zombies

-- MAIN APPLICATION
addappid(1356160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356161, 1, "f60c5950b6b9413d728e373c5a523a77f7420d0134ddaa93cfcb5975f58739e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
