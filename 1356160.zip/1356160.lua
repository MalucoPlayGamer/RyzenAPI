-- Lua provided by RyzenAPI
-- Game: addappid(1356160)

-- MAIN APPLICATION
addappid(1356160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356161, 1, "f60c5950b6b9413d728e373c5a523a77f7420d0134ddaa93cfcb5975f58739e2")
