-- Lua provided by RyzenAPI
-- Game: ALILIA 原画设定集

-- MAIN APPLICATION
addappid(1075210)
-- Game: addappid(1075210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075211, 1, "ca5926d5a8865646626412b1e99bbc582a4c1503ed3992911b5d88171a8102fd")
