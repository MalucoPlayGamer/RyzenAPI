-- Lua provided by RyzenAPI 
-- Game: AppID 595090
addappid(595090)
addappid(595091, 1, "53f9d1c0e4d00c65d440388515f1aeafe572c2abb3aeea1e6f9f0c7aeb5734e8")
