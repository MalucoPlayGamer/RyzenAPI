-- Lua provided by RyzenAPI
-- Game: AppID 595090

-- MAIN APPLICATION
addappid(595090)
-- Game: addappid(595090)

-- MAIN APP DEPOTS / PACKAGES
addappid(595091, 1, "53f9d1c0e4d00c65d440388515f1aeafe572c2abb3aeea1e6f9f0c7aeb5734e8")
