-- Lua provided by RyzenAPI
-- Game: Panzer Corps

-- MAIN APPLICATION
addappid(268400)
addappid(276550)
addappid(276551)
addappid(276552)
addappid(279960)
addappid(279961)
addappid(279962)
addappid(279963)
addappid(279964)
addappid(279965)
addappid(279966)
addappid(279967)
addappid(279968)
addappid(389420)
addappid(389421)
addappid(452980)
addappid(452981)
addappid(452982)

-- MAIN APP DEPOTS / PACKAGES
addappid(268401,0,"0818ccaebc82c87d762990717d10826685d3f20dafa15ff11e9f79ea4061e557")
addappid(268402,0,"577cebb1b03fee0edd5ae8b220b6aeda39b11e78b183b1f1c19888e735ebd53c")

