-- Lua provided by RyzenAPI
-- Game: Panzer Corps Gold

-- MAIN APPLICATION
addappid(268400)

-- MAIN APP DEPOTS / PACKAGES
addappid(268401, 1, "0818ccaebc82c87d762990717d10826685d3f20dafa15ff11e9f79ea4061e557")
