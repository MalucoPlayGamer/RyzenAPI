-- Lua provided by SkyAPI 
-- Game: 雙修武林
addappid(2421350)
addappid(2421351, 1, "172f94c002d3bb3a0e43f677287a18520f7c2543c8af3934ba5dce1eb2b303fc")
