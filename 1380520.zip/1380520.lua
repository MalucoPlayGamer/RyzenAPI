-- Lua provided by RyzenAPI 
-- Game: Racing Outlaws
addappid(1380520)
addappid(1380521, 1, "03ec21b6c03c5fe3c0f3b6536fee70fb03161952c95e413d8950482b6d1aca4c")
