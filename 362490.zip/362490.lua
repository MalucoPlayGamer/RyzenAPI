-- Lua provided by RyzenAPI
-- Game: AppID 362490

-- MAIN APPLICATION
addappid(362490)
-- Game: addappid(362490)

-- MAIN APP DEPOTS / PACKAGES
addappid(362491, 1, "e25ff2cd4c6780f244e88a8dae4fc0231f73cba3b62eb1fd1b541f99b2a15be5")
