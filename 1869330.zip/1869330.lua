-- Lua provided by RyzenAPI
-- Game: Game: Jigsaw Novel - Kinky Bondage

-- MAIN APPLICATION
addappid(1869330)
-- Game: addappid(1869330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869331, 1, "195f9530603095de69b76e0f87c3f10f932e4de2b16d0f07f4aa50ae64716bc3")
