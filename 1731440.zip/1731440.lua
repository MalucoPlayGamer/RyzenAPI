-- Lua provided by RyzenAPI
-- Game: Mahokenshi - The Samurai Deckbuilder DEMO

-- MAIN APPLICATION
addappid(1731440)
-- Game: addappid(1731440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731441, 1, "c11d4ed5c8a1ca9761a01f21ff7e6d8118d4f4358a43f0f7644336146653bc4c")
