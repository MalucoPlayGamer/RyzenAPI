-- Lua provided by SkyAPI 
-- Game: Mahokenshi - The Samurai Deckbuilder DEMO
addappid(1731440)
addappid(1731441, 1, "c11d4ed5c8a1ca9761a01f21ff7e6d8118d4f4358a43f0f7644336146653bc4c")
