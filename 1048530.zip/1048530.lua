-- Lua provided by RyzenAPI
-- Game: Rise of Humanity

-- MAIN APPLICATION
addappid(1048530)
-- Game: addappid(1048530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048531, 1, "3e6d5be61c4a02bb86034f03fae152dfda441e53039ad3011e455d40983e0bd7")
