-- Lua provided by RyzenAPI
-- Game: Game: Mall Craze Demo

-- MAIN APPLICATION
addappid(2250920)
-- Game: addappid(2250920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250921, 1, "edf794b3115e4ec337aba0c11f9830d8654faaf1948c7ae5e57117f0cd33d305")
