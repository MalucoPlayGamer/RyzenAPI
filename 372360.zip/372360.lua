-- Lua provided by RyzenAPI
-- Game: 372360

-- MAIN APPLICATION
addappid(372360)
-- Game: addappid(372360)

-- MAIN APP DEPOTS / PACKAGES
addappid(372361, 1, "494d815400fd79279c90c234e86be896ce24d1471accd1a3a1a5304f7b6c66ab")
