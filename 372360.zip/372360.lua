-- Lua provided by SkyAPI 
-- Game: Tales of Symphonia
addappid(372360)
addappid(372361, 1, "494d815400fd79279c90c234e86be896ce24d1471accd1a3a1a5304f7b6c66ab")
