-- Lua provided by RyzenAPI
-- Game: 2163810

-- MAIN APPLICATION
addappid(2163810)
-- Game: addappid(2163810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163811, 1, "993b4e7c5cab80f302d5a17e5809b0c35a7a654e29ab8f6970862ca8d68a1b7a")
