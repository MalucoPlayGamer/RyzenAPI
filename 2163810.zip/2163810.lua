-- Lua provided by RyzenAPI 
-- Game: NecroBouncer: Prologue
addappid(2163810)
addappid(2163811, 1, "993b4e7c5cab80f302d5a17e5809b0c35a7a654e29ab8f6970862ca8d68a1b7a")
