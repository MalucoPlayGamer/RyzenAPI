-- Lua provided by RyzenAPI
-- Game: addappid(3607120)

-- MAIN APPLICATION
addappid(3607120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3607121, 1, "6e56d1d6fc60adc2c6d3c5b086ba0bc98a3f07cb4fef5b8f2a582a496faea156")
