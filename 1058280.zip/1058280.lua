-- Lua provided by RyzenAPI
-- Game: AppID 1058280

-- MAIN APPLICATION
addappid(1058280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058281, 1, "408d78f00259b1d09f78a59fe685d4cd81ec8b259132b67ed9ece47bcb8ceb35")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1543220)
