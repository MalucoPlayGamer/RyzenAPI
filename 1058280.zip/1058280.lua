-- Lua provided by SkyAPI 
-- Game: AppID 1058280
addappid(1058280)
addappid(1058281, 1, "408d78f00259b1d09f78a59fe685d4cd81ec8b259132b67ed9ece47bcb8ceb35")
