-- Lua provided by RyzenAPI
-- Game: Crystal Shard Adventure Bundle

-- MAIN APPLICATION
addappid(551840)
-- Game: addappid(551840)

-- MAIN APP DEPOTS / PACKAGES
addappid(551841, 1, "67215f2910cc2f3ba8127b3a386bb20c4e1f10028f580c4629ffb9110dd50b5f")
addappid(787280, 0, "36ec107405133fbc29ed868338d4d7653e8ae9f05ce747818667cdf078b81221")
