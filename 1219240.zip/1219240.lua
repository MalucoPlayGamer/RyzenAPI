-- Lua provided by RyzenAPI
-- Game: 1219240

-- MAIN APPLICATION
addappid(1219240)
-- Game: addappid(1219240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219241, 1, "cd957a2de203b097e500729e4ed2071cf469711a22461c9aeeaba36858061e4e")
