-- Lua provided by RyzenAPI
-- Game: Crimson Waves on the Emerald Sea

-- MAIN APPLICATION
addappid(1804970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804971, 1, "b544b497678c5b13c7ef6c9c9e2cff9e60d5bbfb57ade86e73cb2abff2475f79")
