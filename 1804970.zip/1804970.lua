-- Lua provided by SkyAPI 
-- Game: Crimson Waves on the Emerald Sea
addappid(1804970)
addappid(1804971, 1, "b544b497678c5b13c7ef6c9c9e2cff9e60d5bbfb57ade86e73cb2abff2475f79")
