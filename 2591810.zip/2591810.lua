-- Lua provided by RyzenAPI
-- Game: addappid(2591810)

-- MAIN APPLICATION
addappid(2591810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591811, 1, "1bdcc29873ec9ffbb1270037691652057564f47e01f00745afbcf1d606115bac")
