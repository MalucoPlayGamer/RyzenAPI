-- Lua provided by RyzenAPI
-- Game: Something In The Well

-- MAIN APPLICATION
addappid(2591810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591811, 1, "1bdcc29873ec9ffbb1270037691652057564f47e01f00745afbcf1d606115bac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
