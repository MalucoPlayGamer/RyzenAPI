-- Lua provided by RyzenAPI
-- Game: Surface: The Soaring City Collector's Edition

-- MAIN APPLICATION
addappid(1051600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051601, 1, "b942a01a92ef24bfd309bc2c36e62f3b37f5d49d3a135090b94b85a66acfdb50")
