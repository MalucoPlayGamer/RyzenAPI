-- Lua provided by RyzenAPI
-- Game: addappid(2378720)

-- MAIN APPLICATION
addappid(2378720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378721, 1, "bd72db9859ead03f843339275741f27c651f2c9547dbc1b9173bdde5050abb8a")
