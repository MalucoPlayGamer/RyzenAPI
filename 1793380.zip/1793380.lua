-- Lua provided by SkyAPI 
-- Game: Roll The Cat
addappid(1793380)
addappid(1793381, 1, "7c8e73dc52b459afca50077693a45e0ab53789dca65d9bfbd4873a655d7d698a")
