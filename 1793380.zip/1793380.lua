-- Lua provided by RyzenAPI
-- Game: Roll The Cat

-- MAIN APPLICATION
addappid(1793380)
-- Game: addappid(1793380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793381, 1, "7c8e73dc52b459afca50077693a45e0ab53789dca65d9bfbd4873a655d7d698a")
