-- Lua provided by RyzenAPI
-- Game: 758330

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(758330)

-- MAIN APP DEPOTS / PACKAGES
addappid(758332,0,"c966324eeef6df9e481a2fabb4793656846ead18dc370c226898250226742a4f")
