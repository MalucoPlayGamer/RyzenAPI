-- Lua provided by RyzenAPI
-- Game: Nocturia The Game

-- MAIN APPLICATION
addappid(2355440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355441, 1, "daa8800af416adf66b40a84c031a9727cea7b387eb07a282757efc4710a714dc")
