-- Lua provided by SkyAPI 
-- Game: Whispers Left at Night
addappid(3393170)
addappid(3393171, 1, "0727378c36bb950542858e3c532932334ab62205d76d39600759db0c3489a4e3")
