-- Lua provided by RyzenAPI
-- Game: Game: Whispers Left at Night

-- MAIN APPLICATION
addappid(3393170)
-- Game: addappid(3393170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393171, 1, "0727378c36bb950542858e3c532932334ab62205d76d39600759db0c3489a4e3")
