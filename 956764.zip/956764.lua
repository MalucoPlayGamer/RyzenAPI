-- Lua provided by RyzenAPI
-- Game: Zhenji - Officer Ticket / 甄姫使用券

-- MAIN APPLICATION
addappid(956764)

-- MAIN APP DEPOTS / PACKAGES
addappid(956764,0,"70d9dbcfcd2b1d1718c4d48f170b69367ec23d78305629ebbcebb5246689efb8")
