-- Lua provided by RyzenAPI
-- Game: 956764

-- MAIN APPLICATION
addappid(956764)
-- Game: addappid(956764)

-- MAIN APP DEPOTS / PACKAGES
addappid(956764,0,"70d9dbcfcd2b1d1718c4d48f170b69367ec23d78305629ebbcebb5246689efb8")
