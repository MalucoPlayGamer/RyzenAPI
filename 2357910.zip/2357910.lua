-- Lua provided by RyzenAPI
-- Game: Home Safety Hotline

-- MAIN APPLICATION
addappid(2357910)
addappid(2914730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357911, 1, "57c05ae0ce63abf6588f641a1c36579e96e3191a194dbb98bd4c37555876f5d5")

