-- Lua provided by RyzenAPI 
-- Game: A Shot in the Dark - Part 1
addappid(1853830)
addappid(1853831, 1, "cf51b3c71578cf2f2cc6f716568a1c3f0accd01cc4ac6d9b04a8f48294ba13f6")
addappid(2707830)
