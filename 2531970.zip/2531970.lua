-- Lua provided by RyzenAPI
-- Game: Nobody's Home

-- MAIN APPLICATION
addappid(2531970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531971, 1, "4b14aa7e23b0053577289ef035c724ca02b341e6441ec03acdaf017ea842e862")
