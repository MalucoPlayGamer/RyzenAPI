-- Lua provided by RyzenAPI 
-- Game: AGO BRISTOL 1775: From Warship to Prison Hulk
addappid(2605210)
addappid(2605211, 1, "11e2ba1529d13116b104e3381d6e4ac3e45e750b38a9f37a33c85c330a626cb7")
