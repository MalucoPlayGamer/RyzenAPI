-- Lua provided by RyzenAPI
-- Game: AGO BRISTOL 1775: From Warship to Prison Hulk

-- MAIN APPLICATION
addappid(2605210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605211, 1, "11e2ba1529d13116b104e3381d6e4ac3e45e750b38a9f37a33c85c330a626cb7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
