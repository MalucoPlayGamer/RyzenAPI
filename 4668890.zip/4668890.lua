-- Lua provided by RyzenAPI
-- Game: Mall Together

-- MAIN APPLICATION
addappid(4668890)
addappid(4668890) -- Mall Together

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4668891, 1, "9dc3bedf92fa9b0a20fcd0fd74bd85b4985af941ea8db23d8a6ead97d7845a78") -- Depot 4668891

