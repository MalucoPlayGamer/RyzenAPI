-- Lua provided by SkyAPI 
-- Game: AppID 1054180
addappid(1054180)
addappid(1054181, 1, "18e8469d75559c37768ed542abc9dcdd24038f6363c39ed5016f1d9269d3a48a")
