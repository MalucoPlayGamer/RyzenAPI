-- Lua provided by RyzenAPI
-- Game: 1054180

-- MAIN APPLICATION
addappid(1054180)
-- Game: addappid(1054180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054181, 1, "18e8469d75559c37768ed542abc9dcdd24038f6363c39ed5016f1d9269d3a48a")
