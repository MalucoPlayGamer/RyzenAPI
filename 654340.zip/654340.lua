-- Lua provided by RyzenAPI
-- Game: Ambre - Original Soundtrack

-- MAIN APPLICATION
addappid(654340)

-- MAIN APP DEPOTS / PACKAGES
addappid(654340,0,"920b744448bbf683b76de252082211bab5f51405484903f3d744cbf98ec81fe9")

