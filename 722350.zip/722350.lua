-- Lua provided by RyzenAPI
-- Game: Game: Light of Mine

-- MAIN APPLICATION
addappid(722350)
-- Game: addappid(722350)

-- MAIN APP DEPOTS / PACKAGES
addappid(722351, 1, "b3059bf30ff992b86fdb164585df2c922a3527d1972da5106f2eb239ad55a2e1")
