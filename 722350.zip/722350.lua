-- Lua provided by RyzenAPI 
-- Game: Light of Mine
addappid(722350)
addappid(722351, 1, "b3059bf30ff992b86fdb164585df2c922a3527d1972da5106f2eb239ad55a2e1")
