-- Lua provided by RyzenAPI
-- Game: Light of Mine

-- MAIN APPLICATION
addappid(722350)

-- MAIN APP DEPOTS / PACKAGES
addappid(722351, 1, "b3059bf30ff992b86fdb164585df2c922a3527d1972da5106f2eb239ad55a2e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
