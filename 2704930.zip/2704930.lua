-- Lua provided by RyzenAPI
-- Game: 2704930

-- MAIN APPLICATION
addappid(2704930)
-- Game: addappid(2704930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704931, 1, "5440d9fe6ae60bcb99af8897b83875ac66ddd0391b2918ccfda4c0c646bde4c8")
