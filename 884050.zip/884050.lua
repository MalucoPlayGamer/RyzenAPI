-- Lua provided by RyzenAPI
-- Game: Game: AppID 884050

-- MAIN APPLICATION
addappid(884050)
-- Game: addappid(884050)

-- MAIN APP DEPOTS / PACKAGES
addappid(884051, 1, "a4090b5bf31f8ec7bb56374494f51b0beb296a2d9de6da2f08dc289c1fc2e09f")
