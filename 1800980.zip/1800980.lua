-- Lua provided by RyzenAPI 
-- Game: Fish Story
addappid(1800980)
addappid(1800981, 1, "6177f255398e66c61e25894f32ddac92a9373ca1fc6c0c4266e04ed7cfb4c623")
addappid(1800982, 1, "dd0a2696f3afaf5d19b65e616f8680eb7955a55ad250517bed42375a74837e9a")
