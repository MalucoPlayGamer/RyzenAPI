-- Lua provided by SkyAPI 
-- Game: Exorzine
addappid(1900790)
addappid(1900791, 1, "35f1877693a6f7f31a548622a2d28fc5eb0160e6b62b95c54907e895dc97e2ee")
