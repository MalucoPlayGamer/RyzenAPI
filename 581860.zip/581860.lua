-- Lua provided by RyzenAPI
-- Game: AppID 581860

-- MAIN APPLICATION
addappid(581860)

-- MAIN APP DEPOTS / PACKAGES
addappid(581861, 1, "b56fd2be4b0f3b872778cc9e43972a886af0b29dd9d14d3be21477ec60af9afb")
