-- Lua provided by RyzenAPI
-- Game: Kamiwaza: Way of the Thief

-- MAIN APPLICATION
addappid(1924810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1924811, 1, "18a194d765649adba7e364180292261d1045e3ec4c628de1435fe8bc30e1b907")

