-- Lua provided by RyzenAPI
-- Game: Kamiwaza: Way of the Thief

-- MAIN APPLICATION
addappid(1924810)
-- Game: addappid(1924810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924811, 1, "18a194d765649adba7e364180292261d1045e3ec4c628de1435fe8bc30e1b907")
