-- Lua provided by RyzenAPI
-- Game: Crewsaders

-- MAIN APPLICATION
addappid(540870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(540871, 1, "863a52dd87b54cd07d2e0adf097bde3aba526dc5c57bc442f350171e7ab65878")
addappid(540872, 1, "cd07bef7b436da977b8692e2fac1d2df8ecfc97447abe5bd0c82d4fcbe3d2a50")

