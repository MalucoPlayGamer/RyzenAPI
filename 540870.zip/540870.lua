-- Lua provided by RyzenAPI
-- Game: addappid(540870)

-- MAIN APPLICATION
addappid(540870)

-- MAIN APP DEPOTS / PACKAGES
addappid(540871, 1, "863a52dd87b54cd07d2e0adf097bde3aba526dc5c57bc442f350171e7ab65878")
addappid(540872, 1, "cd07bef7b436da977b8692e2fac1d2df8ecfc97447abe5bd0c82d4fcbe3d2a50")
