-- Lua provided by RyzenAPI
-- Game: Pixelorama

-- MAIN APPLICATION
addappid(2779170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779171,0,"67086831fffbc46087dc316d7cf7a0ef27328bd757c39f3d1ce523b5d146f9bc")

