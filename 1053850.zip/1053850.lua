-- Lua provided by RyzenAPI
-- Game: Last Hope Z - VR

-- MAIN APPLICATION
addappid(1053850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053851, 1, "b68f8812203a58c407b46da78f009834170c550fdf31f7edcd75298b20aeb5af")

