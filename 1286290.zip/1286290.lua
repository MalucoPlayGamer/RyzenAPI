-- Lua provided by RyzenAPI
-- Game: Once' Soundtrack

-- MAIN APPLICATION
addappid(1286290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286291, 1, "4a9326c06b215bcfc5eeb028f902a5e533d919ade2904127137949cf2d0cda57")

