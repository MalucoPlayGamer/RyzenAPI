-- Lua provided by RyzenAPI
-- Game: Sword and Spirit

-- MAIN APPLICATION
addappid(1321840)
-- Game: addappid(1321840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321841, 1, "ad83d04b3bc35c2998781e7229374b537285a3f81a9d23391905ed17af4e9b44")
