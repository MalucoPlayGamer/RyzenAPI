-- Lua provided by RyzenAPI
-- Game: Trick & Treat Remake

-- MAIN APPLICATION
addappid(1628440)
addappid(1759310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628441, 1, "ccfa2fce5da12afae1eaace0690091ad4d7497e9c6739a65000428536f4c983c")
