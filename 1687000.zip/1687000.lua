-- Lua provided by RyzenAPI
-- Game: Fading Afternoon

-- MAIN APPLICATION
addappid(1687000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687001, 1, "8ce200d96e5930094f1bed9d0d7c7d0fc0e396ad5f5bd9dd3c8ef1094bf1bef2")

