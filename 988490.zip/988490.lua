-- Lua provided by RyzenAPI
-- Game: AppID 988490

-- MAIN APPLICATION
addappid(988490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(988491, 1, "deea428deb2372702d0f8c3e7a09d0502c2357bac76a6ef1333adfcd6a653e44")

