-- Lua provided by RyzenAPI
-- Game: Game: AppID 988490

-- MAIN APPLICATION
addappid(988490)
-- Game: addappid(988490)

-- MAIN APP DEPOTS / PACKAGES
addappid(988491, 1, "deea428deb2372702d0f8c3e7a09d0502c2357bac76a6ef1333adfcd6a653e44")
