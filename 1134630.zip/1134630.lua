-- Lua provided by RyzenAPI
-- Game: Pear Quest

-- MAIN APPLICATION
addappid(1134630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1134631, 1, "53a2e89c1f5834d6cd71f9afc0203661ca76eb969a06bb84973072ea79a0ce73")
addappid(1134632, 1, "680090600f01836ec5079c92ca6eacaac3435492ccf866e75e237eed8ce068df")

