-- Lua provided by RyzenAPI
-- Game: Kādomon: Hyper Auto Battlers Prologue

-- MAIN APPLICATION
addappid(228990)
addappid(1985320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985322,0,"6f77cc748bd38c1034c2851f9bc0432c820dc91bb6c37fcf6ffdc538c8318633")

