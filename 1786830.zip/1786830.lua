-- Lua provided by RyzenAPI
-- Game: NecroBouncer

-- MAIN APPLICATION
addappid(1786830)
-- Game: addappid(1786830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786831, 1, "6e82b7c4a22878d126797cc084f3d2643a0051038fcb71ff6f2bca80bcb02e55")
