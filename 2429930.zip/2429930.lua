-- Lua provided by RyzenAPI
-- Game: 2429930

-- MAIN APPLICATION
addappid(2429930)
-- Game: addappid(2429930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429931, 1, "416795b8c9f34eb39e8d86f38f00c74dabc37ba04b7367601483890ec357f7ea")
