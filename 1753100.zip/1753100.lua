-- Lua provided by RyzenAPI
-- Game: 舔狗模拟器

-- MAIN APPLICATION
addappid(1753100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753101, 1, "3815e2452d69601bd0b627b587738b808e63560c25cbb17e44b5a2fe44acb0b0")
