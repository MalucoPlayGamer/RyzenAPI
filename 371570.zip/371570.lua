-- Lua provided by SkyAPI 
-- Game: Tap Heroes
addappid(371570)
addappid(371571, 1, "8f62fa3f04afc321fde2a9b7a4b8d14a54013c1f9bcfbe0f8228cfb5aeb0d2cb")
