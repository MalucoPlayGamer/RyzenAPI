-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY X/X-2 HD Remaster

-- MAIN APPLICATION
addappid(359870)
-- Game: addappid(359870)

-- MAIN APP DEPOTS / PACKAGES
addappid(359871, 1, "8e28e18ac8cc58c9c81ddd3022ad0bfcb15e378768d5fc713dcb0254e6d93fff")
