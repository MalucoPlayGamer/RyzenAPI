-- Lua provided by RyzenAPI
-- Game: STAR WARS™ Rebellion

-- MAIN APPLICATION
addappid(441550)
-- Game: addappid(441550)

-- MAIN APP DEPOTS / PACKAGES
addappid(441551, 1, "3f235a353285cd27d5e0f63a858cd6276e5ad8115aa8de304a94824ad2d1513d")
addappid(441552, 1, "ffcecf7ab5381744fdbc29767e4d52b7bcd440ada5e3cd5102ef49b04d6925a7")
addappid(441553, 1, "a54df2e161b313eb0bab2474c9da72ed368fcf8b6e3ad79fb4e097b4794de3e8")
addappid(441554, 1, "5955e4eed6c8b2846354b3f89b5d3565392e132d0dee9fbd151c8964f02d353b")
