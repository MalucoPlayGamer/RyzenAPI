-- Lua provided by RyzenAPI
-- Game: Fantasy Mosaics 23: Magic Forest

-- MAIN APPLICATION
addappid(797330)

-- MAIN APP DEPOTS / PACKAGES
addappid(797331,0,"548240f9db2824f8bbb6e4e87951dee6c44e4468edf45c1d37d706917fa373c7")

