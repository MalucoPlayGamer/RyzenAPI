-- Lua provided by RyzenAPI
-- Game: Game: Jack Axe: The Trial

-- MAIN APPLICATION
addappid(1502920)
-- Game: addappid(1502920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502921, 1, "e34245fa4dcd3be2bea37aaa9d2674e53e3ea05f65e1ca0ce027634b89038c05")
