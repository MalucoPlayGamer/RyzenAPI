-- Lua provided by RyzenAPI 
-- Game: Jack Axe: The Trial
addappid(1502920)
addappid(1502921, 1, "e34245fa4dcd3be2bea37aaa9d2674e53e3ea05f65e1ca0ce027634b89038c05")
