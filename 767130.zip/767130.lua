-- Lua provided by RyzenAPI
-- Game: addappid(767130)

-- MAIN APPLICATION
addappid(767130)

-- MAIN APP DEPOTS / PACKAGES
addappid(767131, 1, "55be8c744091b33e7e855754fe289528d221834e9bf4966ad54fad5fb3cac7e6")
