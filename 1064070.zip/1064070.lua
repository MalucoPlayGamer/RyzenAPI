-- Lua provided by RyzenAPI 
-- Game: OddBallers
addappid(1064070)
addappid(1064071, 1, "971cd1fcaac107fa34ba3c516489d893499c90c9936b56782985787d3b1f4e59")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
