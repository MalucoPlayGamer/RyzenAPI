-- Lua provided by RyzenAPI
-- Game: Closer the Distance

-- MAIN APPLICATION
addappid(1991300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991301, 1, "66f04961ec557f403f0cff042be6b415ae089cc588f10b7077d389dd029fc9d7")

