-- Lua provided by RyzenAPI
-- Game: addappid(788630)

-- MAIN APPLICATION
addappid(788630)

-- MAIN APP DEPOTS / PACKAGES
addappid(788631, 1, "4a0bca301314bfe912ba761211d51a78d46bdc7fac7c54900375228fe3ad5c5c")
