-- Lua provided by RyzenAPI
-- Game: Gaia Beyond

-- MAIN APPLICATION
addappid(788630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(788631, 1, "4a0bca301314bfe912ba761211d51a78d46bdc7fac7c54900375228fe3ad5c5c")
