-- Lua provided by RyzenAPI 
-- Game: AppID 343270
addappid(343270)
addappid(343271, 1, "e9fc98261661f7e413bc299f40794584055670a05bfb89f6b9ae87b951c5d04e")
addappid(343274, 1, "11eb153ee5e90714f0b0b98fc3f417016be3702548de22fc9739e4748ef6ef52")
