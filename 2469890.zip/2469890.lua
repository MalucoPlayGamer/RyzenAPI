-- Lua provided by RyzenAPI 
-- Game: The Wand Wizard
addappid(2469890)
addappid(2469891, 1, "c4ffbb7b9c26da19c99632aa6faf8001d6053d4452f77276fc10e1f2b3f1d5c5")
