-- Lua provided by RyzenAPI
-- Game: Game: GONE Fishing

-- MAIN APPLICATION
addappid(3645890)
-- Game: addappid(3645890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645891, 1, "1562ca138aa20e012036eec85835e73b8f24b6e89debfb9fd26e38348756ad8e")
