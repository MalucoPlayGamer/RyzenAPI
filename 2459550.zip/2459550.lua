-- Lua provided by RyzenAPI
-- Game: Emberward

-- MAIN APPLICATION
addappid(2459550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459551, 1, "da804a84952ce187ba4449fd2d61ff14c21ea7bd9bf5c20a3e81beda8423c8c7")

