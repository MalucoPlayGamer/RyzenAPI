-- Lua provided by RyzenAPI
-- Game: Game: AppID 754780

-- MAIN APPLICATION
addappid(754780)
-- Game: addappid(754780)

-- MAIN APP DEPOTS / PACKAGES
addappid(754781, 1, "6e13cb9d6de38926b248bf77e98439f63ff2c0576ea35527a521a1d5077e9c63")
