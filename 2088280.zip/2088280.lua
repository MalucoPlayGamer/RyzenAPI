-- Lua provided by RyzenAPI
-- Game: addappid(2088280)

-- MAIN APPLICATION
addappid(2088280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088281, 1, "c4975979d273f1d4fe0d7148f1eaffce0dc8794abf129d4d7126922a00d02af9")
