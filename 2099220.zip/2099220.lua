-- Lua provided by RyzenAPI
-- Game: AppID 2099220

-- MAIN APPLICATION
addappid(2099220)
-- Game: addappid(2099220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099221, 1, "cab7f4469883fe50112471f6474f015bbd9e629ecae651999d01c75d07868a9d")
