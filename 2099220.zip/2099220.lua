-- Lua provided by RyzenAPI
-- Game: Mobmania

-- MAIN APPLICATION
addappid(2099220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2099221, 1, "cab7f4469883fe50112471f6474f015bbd9e629ecae651999d01c75d07868a9d")
