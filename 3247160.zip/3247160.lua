-- Lua provided by RyzenAPI 
-- Game: Relics - The Card Game: Demo
addappid(3247160)
addappid(3247161, 1, "e0742bf8a959f5e8347f73c5ae695899cef6d97156b7e836716cbf935c9eb500")
