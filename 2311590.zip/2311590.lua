-- Lua provided by RyzenAPI
-- Game: 2311590

-- MAIN APPLICATION
addappid(2311590)
-- Game: addappid(2311590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311591, 1, "74837b9f7269a360b4ac11b928db88ac70ce621177c1c94b3f3dde364727a93e")
