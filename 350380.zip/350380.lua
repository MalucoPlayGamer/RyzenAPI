-- Lua provided by RyzenAPI
-- Game: addappid(350380)

-- MAIN APPLICATION
addappid(350380)

-- MAIN APP DEPOTS / PACKAGES
addappid(350381, 1, "1ee778c0ffd3b698c2b1cfc3228bdbb5a8ccf239dfd47f59464d8758ef60082d")
