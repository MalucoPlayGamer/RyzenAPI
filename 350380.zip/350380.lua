-- Lua provided by RyzenAPI 
-- Game: The Martian VR Experience
addappid(350380)
addappid(350381, 1, "1ee778c0ffd3b698c2b1cfc3228bdbb5a8ccf239dfd47f59464d8758ef60082d")
