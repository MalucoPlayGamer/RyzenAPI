-- Lua provided by RyzenAPI
-- Game: addappid(797160)

-- MAIN APPLICATION
addappid(797160)

-- MAIN APP DEPOTS / PACKAGES
addappid(797161, 1, "bb6373845bade285b33941cd1ae20601e9d4c4ffb0a2a0b216347bc693e63326")
