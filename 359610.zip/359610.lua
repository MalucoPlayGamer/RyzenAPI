-- Lua provided by RyzenAPI
-- Game: Game: Assassin’s Creed® Chronicles: India

-- MAIN APPLICATION
addappid(359610)
addappid(376420)
addappid(435180)
-- Game: addappid(359610)

-- MAIN APP DEPOTS / PACKAGES
addappid(359611, 1, "f88360f363227aeb88a346fdda243cf1d979fb91896616172483ae05d7296d8b")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
