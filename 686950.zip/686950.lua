-- Lua provided by RyzenAPI
-- Game: addappid(686950)

-- MAIN APPLICATION
addappid(686950)

-- MAIN APP DEPOTS / PACKAGES
addappid(686952,0,"e950d37f777b9de5b37be9d3b20043178abce82225990ea2ec601aa8baea76cd")
