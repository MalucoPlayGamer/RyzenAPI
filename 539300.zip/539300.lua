-- Lua provided by RyzenAPI
-- Game: Solitaire

-- MAIN APPLICATION
addappid(539300)
-- Game: addappid(539300)

-- MAIN APP DEPOTS / PACKAGES
addappid(539301, 1, "5a7b48f40db4ccbbfd2742d99726859d5582f9ba61f5ec9e75562db07a4c99d1")
