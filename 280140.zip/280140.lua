-- Lua provided by RyzenAPI
-- Game: Millennium - A New Hope

-- MAIN APPLICATION
addappid(280140)
-- Game: addappid(280140)

-- MAIN APP DEPOTS / PACKAGES
addappid(280141, 1, "a45818153e1ba27fe23dbbdd1b61e572ffbc11292e287b08b2657ef07182d395")
addappid(306100, 0, "1b033f0aae6427e907c80ae2138191180ba7eac0be16c9e9aa161bf53128ec44")
addappid(368410, 0, "32570ec8ed6300ff3115990911b2ba056c7a77e19c9d5c7484ed9832ad04e769")
