-- Lua provided by RyzenAPI
-- Game: 2086120

-- MAIN APPLICATION
addappid(2086120)
-- Game: addappid(2086120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086121, 1, "487dc372d24e3a71bd5cb6372913fe999cebc14abd8f15ab7a07d806ee34f14f")
