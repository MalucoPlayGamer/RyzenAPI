-- 3282420's Lua and Manifest Created by Hubcap Manifest
-- Zoominoes
-- Created: August 01, 2026 at 00:00:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3282420) -- Zoominoes
-- MAIN APP DEPOTS
addappid(3282421, 1, "236271bf4af0bfd2b0edfe59a9388148b0406d0fe8dbe135d75839780a179081") -- Depot 3282421
setManifestid(3282421, "8237651962185353892", 1094747137)