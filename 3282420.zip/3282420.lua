-- Lua provided by RyzenAPI
-- Game: Zoominoes

-- MAIN APPLICATION
addappid(3282420) -- Zoominoes

-- MAIN APP DEPOTS / PACKAGES
addappid(3282421, 1, "236271bf4af0bfd2b0edfe59a9388148b0406d0fe8dbe135d75839780a179081") -- Depot 3282421

