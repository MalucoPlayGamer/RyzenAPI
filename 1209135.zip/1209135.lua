-- Lua provided by RyzenAPI
-- Game: Beat Saber - Green Day - "Minority"

-- MAIN APPLICATION
addappid(1209135)
-- Game: addappid(1209135)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209135,0,"565b083b62aafc39f2569417caa49a45488e107a239386fd3c3efed82af7e49d")
