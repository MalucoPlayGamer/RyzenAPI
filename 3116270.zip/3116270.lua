-- Lua provided by RyzenAPI
-- Game: 3116270

-- MAIN APPLICATION
addappid(3116270)
-- Game: addappid(3116270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116271, 1, "4ec52d5456dfa2dc9fa64b4f2328eee88ce82bf7fd3c89ae1efd62c390a5f1c8")
