-- Lua provided by RyzenAPI
-- Game: Anime Girls Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1137070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137071, 1, "755bd6ce8e9444a26d1370deffeead07af2abda77e9e067e9f3cd3da59a32cee")

