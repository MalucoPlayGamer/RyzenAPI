-- Lua provided by RyzenAPI
-- Game: AppID 2535440

-- MAIN APPLICATION
addappid(2535440)
-- Game: addappid(2535440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2535441, 1, "fbf63413634eff3b13d9afbe47cf8a3637d69342e0fd556b01f3779ade41447a")
