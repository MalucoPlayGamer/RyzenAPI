-- Lua provided by RyzenAPI
-- Game: Shadows of the Damned: Hella Remastered

-- MAIN APPLICATION
addappid(2535440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2535441, 1, "fbf63413634eff3b13d9afbe47cf8a3637d69342e0fd556b01f3779ade41447a")
