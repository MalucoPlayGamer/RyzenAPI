-- Lua provided by RyzenAPI
-- Game: AppID 853060

-- MAIN APPLICATION
addappid(853060)

-- MAIN APP DEPOTS / PACKAGES
addappid(853061, 1, "d113d2322dbac2b9bba2d71af386755b0e2117e78a28f1bf54eb8ebcdf4af89f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
