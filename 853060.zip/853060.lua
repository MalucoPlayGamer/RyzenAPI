-- Lua provided by SkyAPI 
-- Game: AppID 853060
addappid(853060)
addappid(853061, 1, "d113d2322dbac2b9bba2d71af386755b0e2117e78a28f1bf54eb8ebcdf4af89f")
