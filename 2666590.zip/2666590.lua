-- Lua provided by RyzenAPI
-- Game: addappid(2666590)

-- MAIN APPLICATION
addappid(2666590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666591, 1, "f00e0809350faaf4e81c28b04a3be3e132d18d08f80001702c7f81f6debf4aaa")
