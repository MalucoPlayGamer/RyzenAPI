-- Lua provided by RyzenAPI
-- Game: DeepWeb Simulator Demo

-- MAIN APPLICATION
addappid(2980540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2980541, 1, "644c0e30868fcdef90e2b6a01cabda8506ee5866bc1a96115ea53e4aaa1a93e7")
