-- Lua provided by RyzenAPI
-- Game: 2972730

-- MAIN APPLICATION
addappid(2972730)
-- Game: addappid(2972730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2972732,0,"5ace716de92798f7d5c3c3036ae49b0ea0bfd29f56058cd16e037e1b4fd38f35")
