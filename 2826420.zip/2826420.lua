-- Lua provided by RyzenAPI
-- Game: Cute Suika: Big Watermelon Demo

-- MAIN APPLICATION
addappid(2826420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2826421, 1, "368c4e073516e269cac7bc65a1ec627135f4ac15277eaee8c079383dc562af3f")
