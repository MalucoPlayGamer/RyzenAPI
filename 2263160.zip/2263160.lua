-- Lua provided by RyzenAPI
-- Game: 传说之始

-- MAIN APPLICATION
addappid(2263160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263161, 1, "539d0c4eefe266e3ee277b99f768f2fcc866c6f2c0117076875003293d55c082")

