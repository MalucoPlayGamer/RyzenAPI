-- Lua provided by RyzenAPI
-- Game: 720010

-- MAIN APPLICATION
addappid(720010)
-- Game: addappid(720010)

-- MAIN APP DEPOTS / PACKAGES
addappid(720011, 1, "0a4f10b1569d3a4a229208b8f10c5450b7b7c298c4f93ad69b6152c83053647e")
