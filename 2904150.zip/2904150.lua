-- Lua provided by RyzenAPI
-- Game: addappid(2904150)

-- MAIN APPLICATION
addappid(2904150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904151, 1, "da9ade9221dc4e7c73d98164f578ce7a8f6454bef5ba322175316bae39147288")
