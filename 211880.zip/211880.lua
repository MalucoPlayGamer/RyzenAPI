-- Lua provided by RyzenAPI
-- Game: 211880

-- MAIN APPLICATION
addappid(211880)
-- Game: addappid(211880)

-- MAIN APP DEPOTS / PACKAGES
addappid(211881, 1, "c8abd02c79e0c59d33d8fc156e2d908065489b06105eb53e57371c826c379a9c")
