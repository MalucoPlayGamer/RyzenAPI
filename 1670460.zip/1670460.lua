-- Lua provided by RyzenAPI 
-- Game: GameMaker
addappid(1670460)
addappid(1670461, 1, "29b957e3d8917452949bc2c4be59583ccc1f53a29c14591dd1e64f792ae143f3")
addappid(1670462, 1, "a8be22eb1e8664ec24144643f9042277baa66f2ef3ec371e567650346ff580b5")
