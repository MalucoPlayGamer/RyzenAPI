-- Lua provided by RyzenAPI
-- Game: GameMaker

-- MAIN APPLICATION
addappid(1670460)
addappid(1687770)
addappid(1847410)
addappid(1847411)
addappid(2626900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1670461, 1, "29b957e3d8917452949bc2c4be59583ccc1f53a29c14591dd1e64f792ae143f3")
addappid(1670462, 1, "a8be22eb1e8664ec24144643f9042277baa66f2ef3ec371e567650346ff580b5")

