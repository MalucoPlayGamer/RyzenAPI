-- Lua provided by RyzenAPI
-- Game: 3226190

-- MAIN APPLICATION
addappid(3226190)
-- Game: addappid(3226190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226191, 1, "b4abd2588a37fa811397cab88491976314116b06eeb449c56ff4a322d16cd355")
