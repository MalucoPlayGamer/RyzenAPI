-- Lua provided by RyzenAPI
-- Game: AppID 308600

-- MAIN APPLICATION
addappid(308600)
addappid(978140)
addappid(2194030)
addappid(4172540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(308601, 1, "85752a33e9947f9cb2f45664482a34cd0e439f8e33e0cb8e338fc02c8c5ff327")
addappid(308602, 1, "7675f0067cc6aa5251ff6a360fc3e9bf60a88ebd79d5b77970f172c192e33046")
addappid(308603, 1, "b8112ee7f1bd47600e357569468c0d1decc2dd2e7fd1ba17502d4cb3052af8e5")

