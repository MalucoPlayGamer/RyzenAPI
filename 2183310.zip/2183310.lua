-- Lua provided by RyzenAPI
-- Game: addappid(2183310)

-- MAIN APPLICATION
addappid(2183310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183311, 1, "24bb3c97d369d0659b3644a5923394ef887029f3a37030aa2ff53bbf6e4c46e4")
