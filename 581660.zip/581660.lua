-- Lua provided by RyzenAPI
-- Game: Super Meat Boy Forever

-- MAIN APPLICATION
addappid(581660)

-- MAIN APP DEPOTS / PACKAGES
addappid(581661, 1, "b05261871667166e3174b6a2ebd0729989cc1e573c892c4b5676332bfe6aad91")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
