-- Lua provided by RyzenAPI
-- Game: Guardians of Victoria

-- MAIN APPLICATION
addappid(385080)

-- MAIN APP DEPOTS / PACKAGES
addappid(385081, 1, "6567a9cd5c434406f512ee9193da718432cbaf009abecdde9821aa0c643282f4")
addappid(385082, 1, "63db5bbea92c0baaf91f8505ba9f25e2478d48fd18d08386ae6e82a5c4ce828d")
addappid(385083, 1, "38e17b6d66d429253691c257e28d307617dae1fa6fcc4a0a3c8291c0b283cd30")
addappid(385084, 1, "3562066dddc7c9a463c82165ce3a65a9c42af8c03d6abbb632c60bedf3cea34f")
addappid(385085, 1, "07864f95d2f525cbce331fae988daaa4812cf70db7d410284bf453f44e881f0f")
addappid(385086, 1, "7631d014537b35689fdbd69b3fa03d41ab512989ba942e214885ffcbd0a63f9d")
