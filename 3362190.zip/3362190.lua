-- Lua provided by RyzenAPI
-- Game: 料理乱斗

-- MAIN APPLICATION
addappid(3362190)
-- Game: addappid(3362190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362192,0,"2ec6d1df968ace63a5b41a685dc47a5ca4f28a8c426d4b9169628850d3dd5f41")
