-- Lua provided by RyzenAPI
-- Game: DFF NT: Ministerial Vestiture Appearance Set for Shantotto

-- MAIN APPLICATION
addappid(1022504)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022504,0,"793e2a409ab63a27ffba9585cf41b0fee863da6cc620d7d346148d45b1bccd32")

