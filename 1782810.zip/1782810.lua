-- Lua provided by RyzenAPI
-- Game: Software Company

-- MAIN APPLICATION
addappid(1782810)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1782811, 1, "b3ca99829645034b61c3e8be0cdf80bcc59983372a34b3567899cc21c562ba19")
addappid(1782813, 1, "a7ae17631548bfd6d1fffd2ac5465ca83db14cfd14b557ecb5d12ddc9997e230")

