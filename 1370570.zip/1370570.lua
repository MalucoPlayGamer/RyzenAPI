-- Lua provided by RyzenAPI
-- Game: First Person Shooter Kit Showcase

-- MAIN APPLICATION
addappid(1370570)
-- Game: addappid(1370570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370572,0,"093b5ab20b0f588036610f922348a514fea753d76338cf7325a5935a596183d6")
