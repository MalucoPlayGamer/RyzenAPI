-- Lua provided by RyzenAPI
-- Game: First Person Shooter Kit Showcase

-- MAIN APPLICATION
addappid(1370570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370572,0,"093b5ab20b0f588036610f922348a514fea753d76338cf7325a5935a596183d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
