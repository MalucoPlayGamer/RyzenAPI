-- Lua provided by SkyAPI 
-- Game: Touhou Mystia's Izakaya DLC2.5 Pack
addappid(2122050)
addappid(2122051, 1, "7feb14a9d8b871b77147f0bb18733c0f858070cb0d33dd0f215b59f4674dcf8a")
addappid(2122052, 1, "2aa2b3238105af8023e856070cf91316c0ab7c02db593f0fa806d3134f57e86d")
