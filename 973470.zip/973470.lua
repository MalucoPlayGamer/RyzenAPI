-- Lua provided by RyzenAPI
-- Game: 973470

-- MAIN APPLICATION
addappid(973470)
-- Game: addappid(973470)

-- MAIN APP DEPOTS / PACKAGES
addappid(973471, 1, "4ab6b73dd4d33cc50cb2ab0e112b82991a135b879cbcefb5d30dadc9ff361c39")
