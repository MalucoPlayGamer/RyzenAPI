-- Lua provided by RyzenAPI
-- Game: Narco Strike

-- MAIN APPLICATION
addappid(1020410)
addappid(1094860)
addappid(1319870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1020411, 1, "3fe5c23947ed8708b6384dd1d698ff5bdf58f80768c9be4fb19c36916ae01c73")

