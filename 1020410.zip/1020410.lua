-- Lua provided by RyzenAPI 
-- Game: Narco Strike
addappid(1020410)
addappid(1020411, 1, "3fe5c23947ed8708b6384dd1d698ff5bdf58f80768c9be4fb19c36916ae01c73")
