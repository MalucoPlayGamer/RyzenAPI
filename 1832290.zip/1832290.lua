-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1832290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832290,0,"813ff8ecff251177ca5a647b8895ecde4443917033917c758e81785a4c23ac4e")
