-- Lua provided by RyzenAPI
-- Game: Alcohol Empire

-- MAIN APPLICATION
addappid(1921270)
-- Game: addappid(1921270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921271, 1, "f4c1d76113b47e42ac3efcf2cade1e016578e0f9007a5c4d41dbaf2b03e3ab68")
