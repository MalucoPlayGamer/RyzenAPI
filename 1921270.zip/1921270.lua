-- Lua provided by RyzenAPI
-- Game: Alcohol Empire

-- MAIN APPLICATION
addappid(1921270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1921271, 1, "f4c1d76113b47e42ac3efcf2cade1e016578e0f9007a5c4d41dbaf2b03e3ab68")

