-- Lua provided by RyzenAPI
-- Game: Hello Neighbor Alpha 4

-- MAIN APPLICATION
addappid(1096710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1096711, 1, "697752c08abac9ec4a0bc0b2f76372923b648dd314107d3951669ab861c2d20f")

