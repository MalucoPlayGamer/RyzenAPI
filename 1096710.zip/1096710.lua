-- Lua provided by RyzenAPI
-- Game: addappid(1096710)

-- MAIN APPLICATION
addappid(1096710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096711, 1, "697752c08abac9ec4a0bc0b2f76372923b648dd314107d3951669ab861c2d20f")
