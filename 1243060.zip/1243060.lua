-- Lua provided by RyzenAPI
-- Game: Game: Infiniball

-- MAIN APPLICATION
addappid(1243060)
-- Game: addappid(1243060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243061, 1, "6c3e4c84074d1f12bcb91b8667117183fae7dd8d2d06718a7515f5d13a9a9c29")
