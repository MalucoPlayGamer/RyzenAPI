-- Lua provided by RyzenAPI
-- Game: nanos world™ Assets Development Kit

-- MAIN APPLICATION
addappid(1988780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988781, 1, "6d78e1eef0198148c397a09288113632788cc279b3b4047a06e7ccf27dc7456f")
