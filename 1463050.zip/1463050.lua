-- Lua provided by RyzenAPI
-- Game: setManifestid(1463052,"1779502192150754197")

-- MAIN APPLICATION
addappid(1463050)
-- Game: addappid(1463050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463052,0,"dd1834fef51bd2a50c293f0cce65105f90240c39363319d8a872a8b78e0dcbd4")
