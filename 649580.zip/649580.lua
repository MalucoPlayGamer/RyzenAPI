-- Lua provided by SkyAPI 
-- Game: Twins of the Pasture
addappid(649580)
addappid(649581, 1, "0151218f5b595d806083a8411d6075647d2baeb8e430557d71882d51903b5f0b")
