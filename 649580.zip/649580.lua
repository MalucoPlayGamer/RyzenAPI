-- Lua provided by RyzenAPI
-- Game: Twins of the Pasture

-- MAIN APPLICATION
addappid(649580)

-- MAIN APP DEPOTS / PACKAGES
addappid(649581, 1, "0151218f5b595d806083a8411d6075647d2baeb8e430557d71882d51903b5f0b")
