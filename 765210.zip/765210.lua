-- Lua provided by RyzenAPI
-- Game: Your Royal Gayness

-- MAIN APPLICATION
addappid(765210)

-- MAIN APP DEPOTS / PACKAGES
addappid(765211,0,"99ed6c2df0958d7ffc8745370e1a8de9d7e094304ed87e69d36321d47b0aeb4a")

