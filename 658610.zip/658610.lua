-- Lua provided by RyzenAPI
-- Game: 位面穿越者-三国传(A Bit Crosser-Three Kingdoms)

-- MAIN APPLICATION
addappid(658610)
addappid(768010)
-- Game: addappid(658610)

-- MAIN APP DEPOTS / PACKAGES
addappid(658611, 1, "3d92e0cf06232ed5ca33b02c40849eb95d7ee610f9850fcfa6d1bc3bb701bf33")
addappid(658612, 1, "dfb7534648b0a9a404148103e1d8023771f4a1ebfdf678ebf86a786edb81d6ce")
