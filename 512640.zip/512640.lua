-- Lua provided by RyzenAPI
-- Game: addappid(512640)

-- MAIN APPLICATION
addappid(512640)

-- MAIN APP DEPOTS / PACKAGES
addappid(512641, 1, "5d55e21ce5d68128d4e5b4e5f053fca23a35dbc6f2f1c68aeb33491021468e2a")
