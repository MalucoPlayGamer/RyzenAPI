-- Lua provided by RyzenAPI
-- Game: AppID 409890

-- MAIN APPLICATION
addappid(409890)
-- Game: addappid(409890)

-- MAIN APP DEPOTS / PACKAGES
addappid(409891, 1, "96d8274858338aed469a4b6ea7ce896bd44aed50b86b9bde5377319d443bb2c5")
