-- Lua provided by RyzenAPI
-- Game: Game: Ancient Gods

-- MAIN APPLICATION
addappid(1716940)
-- Game: addappid(1716940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716941, 1, "b53ea8999219c35aaaa0091af711397dfea5647a98ef98e9111442edb639eb5c")
