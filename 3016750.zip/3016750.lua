-- Lua provided by RyzenAPI
-- Game: 3016750

-- MAIN APPLICATION
addappid(3016750)
addappid(3217920)
-- Game: addappid(3016750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016751, 1, "e5423efe3de5218c11ef4479cee30368f4c767da361cba8b99fac34c4a8b0b19")
addappid(3016752, 1, "db21abaeeade79023bc54788467498fc7de3299b01c6d85e71ca2065625845d3")
