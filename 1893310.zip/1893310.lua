-- Lua provided by RyzenAPI
-- Game: Steel Shell

-- MAIN APPLICATION
addappid(1893310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1893311, 1, "e3d0d32503676c2fe5a8a1ed5084ebcfec2fd4f665b42d0848613bcbe13b3a90")

