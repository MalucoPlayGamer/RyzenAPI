-- Lua provided by RyzenAPI
-- Game: Steel Shell

-- MAIN APPLICATION
addappid(1893310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893311, 1, "e3d0d32503676c2fe5a8a1ed5084ebcfec2fd4f665b42d0848613bcbe13b3a90")
