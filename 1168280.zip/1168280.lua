-- Lua provided by SkyAPI 
-- Game: Resident Evil 2 "R.P.D. Demo"
addappid(1168280)
addappid(1168281, 1, "e44fa5e8bbd41f5c809931f0e5a1919d41f3a5072f265d6c36599d5c38663d3c")
