-- Lua provided by RyzenAPI
-- Game: Hold Your King

-- MAIN APPLICATION
addappid(3564340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564342,0,"e90cbf63b9585418d94497473cfcd7ade207a7d857a301aa5705422daf1c9f34")

