-- Lua provided by RyzenAPI
-- Game: 仙剑诀网络版

-- MAIN APPLICATION
addappid(1654120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654121, 1, "d68fc5ef8b769329e0c517f8ec9ca3b9db58b4f1ef8628a9a146063c2e3a46fd")

