-- Lua provided by RyzenAPI
-- Game: The Haunting of Joni Evers

-- MAIN APPLICATION
addappid(2828590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828592,0,"c708ebad3a1d08782776212b9ada6eb6dfd79f6a15ba841493b5407dfb2c5e60")

