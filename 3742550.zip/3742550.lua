-- Lua provided by RyzenAPI
-- Game: Atelier Yumia - "Boba Tea" Costume for Flammi

-- MAIN APPLICATION
addappid(3742550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742550,0,"fe2c61f8ad7b7b923eac440aa29de36362579438e4683dda4c0351cb404fcb4b")

