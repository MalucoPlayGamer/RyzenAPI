-- Lua provided by RyzenAPI
-- Game: Party of Sin Demo

-- MAIN APPLICATION
addappid(224660)
addappid(224661)
-- Game: addappid(224660)

-- MAIN APP DEPOTS / PACKAGES
addappid(212701,0,"dcf023fdc64666286ad8f4930f3e6754f69d41cda25b1d1dc61474161dbd691c")
addappid(212702,0,"e8777c365ce11b6f48d96241242ad0c66a8196609b73e87d5db23eab58bfe4b2")
