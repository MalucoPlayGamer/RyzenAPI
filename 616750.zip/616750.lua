-- Lua provided by RyzenAPI
-- Game: 1943 Deadly Desert

-- MAIN APPLICATION
addappid(616750)

-- MAIN APP DEPOTS / PACKAGES
addappid(616751, 1, "38247684d702b755c4e200627c73b1a64b430dafe64b74d6320535b577962dcf")
addappid(616752, 1, "376812d0f19069385935919f0751cd673f3d2a79c0f236b5cca86f6c53fb29cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
