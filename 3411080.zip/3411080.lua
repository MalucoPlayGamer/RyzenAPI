-- Lua provided by RyzenAPI
-- Game: 3411080

-- MAIN APPLICATION
addappid(3411080)
-- Game: addappid(3411080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3411081, 1, "ad875fd47e3bcd0e190a05b29e764dc94e5a59c81eaad1f350bee4e57654d98a")
