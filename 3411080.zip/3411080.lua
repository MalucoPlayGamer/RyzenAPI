-- Lua provided by SkyAPI 
-- Game: Cultural Exchange
addappid(3411080)
addappid(3411081, 1, "ad875fd47e3bcd0e190a05b29e764dc94e5a59c81eaad1f350bee4e57654d98a")
