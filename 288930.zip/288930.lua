-- Lua provided by RyzenAPI
-- Game: addappid(288930)

-- MAIN APPLICATION
addappid(288930)
addappid(288940)

-- MAIN APP DEPOTS / PACKAGES
addappid(288931, 1, "615f28eb4ee58fcd411b6a2c8b2fb987106184672585c81ee1b5084bf79641cf")
addappid(288932, 1, "74c5428e6f856338d797bd7b6360a68f33ecdf5fd75d85f440902ec2ed4bbd97")
