-- Lua provided by SkyAPI 
-- Game: Heavy Burger
addappid(922250)
addappid(922251, 1, "fb72c310dfe002caf81fcbb58c4cf49f9ba9c2ff504b5660c59614068b60f6d5")
addappid(922252, 1, "d60c346e061d1010ec5665ad19f2c57a84b2fe7d9be3a15030c0a2b8a7d882e4")
