-- Lua provided by RyzenAPI
-- Game: 922250

-- MAIN APPLICATION
addappid(922250)
-- Game: addappid(922250)

-- MAIN APP DEPOTS / PACKAGES
addappid(922251, 1, "fb72c310dfe002caf81fcbb58c4cf49f9ba9c2ff504b5660c59614068b60f6d5")
addappid(922252, 1, "d60c346e061d1010ec5665ad19f2c57a84b2fe7d9be3a15030c0a2b8a7d882e4")
