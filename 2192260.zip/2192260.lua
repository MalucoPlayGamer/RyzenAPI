-- Lua provided by RyzenAPI
-- Game: Game: Infinadeck Stonehenge

-- MAIN APPLICATION
addappid(2192260)
-- Game: addappid(2192260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192261, 1, "a7cd42443636e52f406f689fa1912463220a86e2ac52b130e734b17a2ab790ec")
