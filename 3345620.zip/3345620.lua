-- Lua provided by RyzenAPI
-- Game: addappid(3345620)

-- MAIN APPLICATION
addappid(3345620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345621, 1, "149acd67c537ff568756a08591ef2cd334c51d83e269bee597ba938e532d6aa7")
