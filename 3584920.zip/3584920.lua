-- 3584920's Lua and Manifest Created by Hubcap Manifest
-- Chinese Street Food Legend
-- Created: August 14, 2026 at 08:22:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3584920) -- Chinese Street Food Legend
-- MAIN APP DEPOTS
addappid(3584921, 1, "946ea666a855377effa39e81886fd373d6c9f0d98cc13e57b5592bc34fe773d1") -- Depot 3584921
setManifestid(3584921, "2969997023309799372", 1469084775)