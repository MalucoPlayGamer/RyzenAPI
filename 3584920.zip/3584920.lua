-- Lua provided by RyzenAPI
-- Game: Chinese Street Food Legend

-- MAIN APPLICATION
addappid(3584920) -- Chinese Street Food Legend

-- MAIN APP DEPOTS / PACKAGES
addappid(3584921, 1, "946ea666a855377effa39e81886fd373d6c9f0d98cc13e57b5592bc34fe773d1") -- Depot 3584921

