-- Lua provided by RyzenAPI
-- Game: Buddy Simulator 1984 Demo

-- MAIN APPLICATION
addappid(1280740)
-- Game: addappid(1280740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280741, 1, "6e684b222c95c66a60a3bd174a50102249dcb418f1bb11a7cec85314033a4d24")
