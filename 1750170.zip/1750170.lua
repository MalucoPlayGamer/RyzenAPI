-- Lua provided by RyzenAPI
-- Game: Fragmented Memories - Arc One

-- MAIN APPLICATION
addappid(1750170)
-- Game: addappid(1750170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750171, 1, "12a321b18fcc8bc02dc9935a99a2df80d193c0a9da952f866214cc1b909b0a3f")
