-- Lua provided by RyzenAPI
-- Game: Game: AppID 1962250

-- MAIN APPLICATION
addappid(1962250)
-- Game: addappid(1962250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962251, 1, "55832649b7924186f861d23ceca82c5d69564317c08426de28319bc2f93ae1da")
