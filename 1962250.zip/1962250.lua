-- Lua provided by SkyAPI 
-- Game: AppID 1962250
addappid(1962250)
addappid(1962251, 1, "55832649b7924186f861d23ceca82c5d69564317c08426de28319bc2f93ae1da")
