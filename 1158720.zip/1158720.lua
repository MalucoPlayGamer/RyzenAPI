-- Lua provided by RyzenAPI
-- Game: Game: Causality

-- MAIN APPLICATION
addappid(1158720)
-- Game: addappid(1158720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158721, 1, "e56bb783b83a73d5a184afe7298905975891f61ac26e5f38140daf5f25179391")
