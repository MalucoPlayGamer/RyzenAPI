-- Lua provided by RyzenAPI
-- Game: Undead West Demo

-- MAIN APPLICATION
addappid(3241950)
-- Game: addappid(3241950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241951, 1, "edeb0e919b1d6ee3a985fd3bebd3194b5ba3812290023090feecb7c6494bc59a")
