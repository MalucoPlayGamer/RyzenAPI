-- Lua provided by RyzenAPI
-- Game: Whispered Secrets: Golden Silence Collector's Edition

-- MAIN APPLICATION
addappid(896980)

-- MAIN APP DEPOTS / PACKAGES
addappid(896981, 1, "67a19160a24300ef1928c01c486f16fbf4d0356cb719c6c1c18065a684a169d2")
