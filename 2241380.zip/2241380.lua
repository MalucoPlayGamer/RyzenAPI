-- Lua provided by SkyAPI 
-- Game: Ancient Kingdoms
addappid(2241380)
addappid(2241381, 1, "ab5171b37a9c9646a992af3a861922b53c021caac43ebf80eea6d58712669eee")
