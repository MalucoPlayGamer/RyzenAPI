-- Lua provided by RyzenAPI
-- Game: Game: Ancient Kingdoms

-- MAIN APPLICATION
addappid(2241380)
-- Game: addappid(2241380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241381, 1, "ab5171b37a9c9646a992af3a861922b53c021caac43ebf80eea6d58712669eee")
