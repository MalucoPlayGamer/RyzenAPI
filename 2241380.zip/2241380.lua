-- Lua provided by RyzenAPI
-- Game: Ancient Kingdoms

-- MAIN APPLICATION
addappid(2241380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2241381, 1, "ab5171b37a9c9646a992af3a861922b53c021caac43ebf80eea6d58712669eee")

