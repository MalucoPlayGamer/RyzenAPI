-- Lua provided by RyzenAPI
-- Game: Aven Colony

-- MAIN APPLICATION
addappid(484900)
addappid(645900)
addappid(685820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(484901, 1, "c6427e354872f0e6b5d23e892151ece17151c7648e6e2c7a6756a5bee28d0173")

