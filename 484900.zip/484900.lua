-- Lua provided by RyzenAPI
-- Game: AppID 484900

-- MAIN APPLICATION
addappid(484900)
-- Game: addappid(484900)

-- MAIN APP DEPOTS / PACKAGES
addappid(484901, 1, "c6427e354872f0e6b5d23e892151ece17151c7648e6e2c7a6756a5bee28d0173")
