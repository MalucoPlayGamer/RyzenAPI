-- Lua provided by RyzenAPI
-- Game: 1847780

-- MAIN APPLICATION
addappid(1847780)
-- Game: addappid(1847780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847781, 1, "df5ccfeec2b8c501eb596b1a9d5712567c51697bc28666dbcde4e4af783d34f7")
