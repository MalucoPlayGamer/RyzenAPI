-- Lua provided by RyzenAPI 
-- Game: Racine Demo
addappid(1847780)
addappid(1847781, 1, "df5ccfeec2b8c501eb596b1a9d5712567c51697bc28666dbcde4e4af783d34f7")
