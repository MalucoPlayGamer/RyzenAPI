-- Lua provided by RyzenAPI
-- Game: addappid(2918130)

-- MAIN APPLICATION
addappid(2918130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918131, 1, "bbca5a618028e2e4a48cbf3a8c7ab3bf8ffdd9637ab97b096551ad7fae2ca721")
