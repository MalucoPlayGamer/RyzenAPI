-- Lua provided by RyzenAPI
-- Game: PowersVR

-- MAIN APPLICATION
addappid(589250)

-- MAIN APP DEPOTS / PACKAGES
addappid(589251, 1, "093f8d0296852e46d7aad15eabeaeba678ff4f84569de9ba9977145b8085b843")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
