-- Lua provided by RyzenAPI
-- Game: addappid(589250)

-- MAIN APPLICATION
addappid(589250)

-- MAIN APP DEPOTS / PACKAGES
addappid(589251, 1, "093f8d0296852e46d7aad15eabeaeba678ff4f84569de9ba9977145b8085b843")
