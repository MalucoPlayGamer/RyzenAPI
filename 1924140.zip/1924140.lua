-- Lua provided by RyzenAPI
-- Game: Game: ISEKAI FRONTLINE

-- MAIN APPLICATION
addappid(1924140)
-- Game: addappid(1924140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924141, 1, "bf3ae84c04ed171cde0d22d2539d383938e3dcf0350a52a8b7b111283ad1e563")
