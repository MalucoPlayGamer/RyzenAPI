-- Lua provided by RyzenAPI 
-- Game: ISEKAI FRONTLINE
addappid(1924140)
addappid(1924141, 1, "bf3ae84c04ed171cde0d22d2539d383938e3dcf0350a52a8b7b111283ad1e563")
