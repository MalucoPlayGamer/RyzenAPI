-- Lua provided by RyzenAPI
-- Game: Lost Castle 2: Original Soundtrack

-- MAIN APPLICATION
addappid(3063440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3063441, 1, "c1d21ca1858801ffae2c9192fb45d3bdd99237ca7e8618c1219ff376a3a71d2b")
addappid(3063442, 1, "29d2548be087391509e333ae33590454d6a4cf74613834d2f0f1aad240ec9adb")
