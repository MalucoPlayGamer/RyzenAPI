-- Lua provided by SkyAPI 
-- Game: Reveal The Deep
addappid(411560)
addappid(411561, 1, "7370feca5a57a571879f630ca9bc26bb077ffd1134fe5e99c6c896c01f0443b4")
