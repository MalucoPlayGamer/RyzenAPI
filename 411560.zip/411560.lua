-- Lua provided by RyzenAPI
-- Game: Reveal The Deep

-- MAIN APPLICATION
addappid(411560)
-- Game: addappid(411560)

-- MAIN APP DEPOTS / PACKAGES
addappid(411561, 1, "7370feca5a57a571879f630ca9bc26bb077ffd1134fe5e99c6c896c01f0443b4")
