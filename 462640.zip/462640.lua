-- Lua provided by RyzenAPI
-- Game: Game: AppID 462640

-- MAIN APPLICATION
addappid(462640)
-- Game: addappid(462640)

-- MAIN APP DEPOTS / PACKAGES
addappid(462641, 1, "1460e70a6c7809d348763b002b1a25e81500e7cc6a0585b0716aa9da49919a88")
