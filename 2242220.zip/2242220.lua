-- Lua provided by RyzenAPI
-- Game: Forest Fire

-- MAIN APPLICATION
addappid(2242220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242221, 1, "cb8075ab41951fda772e851100a701109fbcd412efcc7afe3a640a119f1fe909")
