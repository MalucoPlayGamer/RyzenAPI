-- Lua provided by RyzenAPI
-- Game: Queen's Wish 2: The Tormentor

-- MAIN APPLICATION
addappid(1947750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947751, 1, "f87cc46fa52619dc3a3c7cba431017b190fbf1d0255806846afe4fb7d425b183")
addappid(1947752, 1, "8f8edf2a905f3d02c3e7eb766851caeebfb8b5ae6d4a7daf9e64f2c310a246b3")
addappid(2071930, 0, "40f7b0e478ceb818e73c88616d05330b53cdfcbf157815f63b8d87b2ff1ecb9d")
