-- Lua provided by SkyAPI 
-- Game: Shortcuit Demo
addappid(2130580)
addappid(2130581, 1, "170a5ac534a655aa6b460d56615e8db929b71c0182cca5891e1226db9ac6f208")
