-- Lua provided by SkyAPI 
-- Game: Black Gunner Wukong
addappid(2270750)
addappid(2270751, 1, "815b369604a5e1ed1f9111ef02423865d347af0ed6f2de20eb6bace6fbd31f78")
