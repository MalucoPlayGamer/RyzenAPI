-- Lua provided by RyzenAPI
-- Game: Black Gunner Wukong

-- MAIN APPLICATION
addappid(2270750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270751, 1, "815b369604a5e1ed1f9111ef02423865d347af0ed6f2de20eb6bace6fbd31f78")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
