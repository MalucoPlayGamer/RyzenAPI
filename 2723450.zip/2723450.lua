-- Lua provided by RyzenAPI
-- Game: Lovely Defenders

-- MAIN APPLICATION
addappid(2723450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2723451, 1, "4892dec30b5fab6d6c243f13d7eb6ae7ee5f7b21f7cde2232c0dcaa92e0df9e0")

