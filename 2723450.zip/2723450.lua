-- Lua provided by RyzenAPI 
-- Game: AppID 2723450
addappid(2723450)
addappid(2723451, 1, "4892dec30b5fab6d6c243f13d7eb6ae7ee5f7b21f7cde2232c0dcaa92e0df9e0")
