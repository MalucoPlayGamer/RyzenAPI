-- Lua provided by RyzenAPI
-- Game: addappid(1968320)

-- MAIN APPLICATION
addappid(1968320)
addappid(1968321)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968322,0,"cfc4b4c029ca3c165474fd7f46b37e09f5a3336fb26f75cb9173166b924351a5")
