-- Lua provided by RyzenAPI
-- Game: addappid(773580)

-- MAIN APPLICATION
addappid(773580)
addappid(1224000)

-- MAIN APP DEPOTS / PACKAGES
addappid(773581, 1, "9fbd4427bb2219a98c08153980e42df041c4efcb89a0621b6465d238c3a5cb82")
addappid(773582, 1, "2abbe553a0c4857c4a6b0d6dac0d08fbf5c78e142833ed219952e0f943c94def")
addappid(1224001, 1, "68945e4d95012da440bba9dabab61422573d1acc9ecf2f801ceff32bb12744bd")
