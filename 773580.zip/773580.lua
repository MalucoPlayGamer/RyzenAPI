-- Lua provided by RyzenAPI
-- Game: Game Dev Studio

-- MAIN APPLICATION
addappid(773580)
addappid(1224000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(773581, 1, "9fbd4427bb2219a98c08153980e42df041c4efcb89a0621b6465d238c3a5cb82")
addappid(773582, 1, "2abbe553a0c4857c4a6b0d6dac0d08fbf5c78e142833ed219952e0f943c94def")
addappid(1224001, 1, "68945e4d95012da440bba9dabab61422573d1acc9ecf2f801ceff32bb12744bd")

