-- Lua provided by RyzenAPI
-- Game: Icarus Beta

-- MAIN APPLICATION
addappid(1671080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1671081, 1, "938788808a1ec43064153e12b3d696a8ad64f32f6b7e4227cc1eacdfdb9a3a16")

