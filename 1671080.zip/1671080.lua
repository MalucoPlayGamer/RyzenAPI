-- Lua provided by SkyAPI 
-- Game: AppID 1671080
addappid(1671080)
addappid(1671081, 1, "938788808a1ec43064153e12b3d696a8ad64f32f6b7e4227cc1eacdfdb9a3a16")
