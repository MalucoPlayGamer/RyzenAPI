-- Lua provided by RyzenAPI
-- Game: Hypership Out of Control 2

-- MAIN APPLICATION
addappid(371700)

-- MAIN APP DEPOTS / PACKAGES
addappid(371701, 1, "a75a102b631ad65b35b9135d1bde76b26710442e04d0ececfdd1a04df2d25502")

