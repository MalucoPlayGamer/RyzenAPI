-- Lua provided by RyzenAPI
-- Game: Hypership Out of Control 2

-- MAIN APPLICATION
addappid(371700)

-- MAIN APP DEPOTS / PACKAGES
addappid(371701, 1, "a75a102b631ad65b35b9135d1bde76b26710442e04d0ececfdd1a04df2d25502")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
