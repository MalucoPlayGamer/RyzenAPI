-- Lua provided by RyzenAPI
-- Game: Game: AppID 1255520

-- MAIN APPLICATION
addappid(1255520)
-- Game: addappid(1255520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255521, 1, "b11ba3deabf8c89ac32dccb2cad2e2f2e68baaf20ddd66bfea72ed1f7bf7b7a8")
