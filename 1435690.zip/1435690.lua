-- Lua provided by RyzenAPI
-- Game: Home defender

-- MAIN APPLICATION
addappid(1435690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435691, 1, "3113bebfcc6cc4127f4ca3df88ea2e6f4780fee322c58a63a6ce9918b614e987")
