-- Lua provided by RyzenAPI
-- Game: 1433100

-- MAIN APPLICATION
addappid(1433100)
-- Game: addappid(1433100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433101, 1, "01b9b32fa46f2943b4af9b37246d137d16d5c386b7f1eb4d936cf77c7eeebbf9")
