-- Lua provided by RyzenAPI
-- Game: 1306960

-- MAIN APPLICATION
addappid(1306960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306964,0,"75e64ce44ffe0d59f18bb3b87a7bfb0bf874d50ea8b6988b17a3660bf689bf32")
