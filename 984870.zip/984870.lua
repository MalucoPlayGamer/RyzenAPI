-- Lua provided by RyzenAPI
-- Game: addappid(984870)

-- MAIN APPLICATION
addappid(984870)

-- MAIN APP DEPOTS / PACKAGES
addappid(984871, 1, "733208669fca999da8c70a2e08aae40ded77d38ae293aef59037de98ac7540b3")
