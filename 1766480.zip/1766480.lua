-- Lua provided by RyzenAPI
-- Game: 1766480

-- MAIN APPLICATION
addappid(1766480)
-- Game: addappid(1766480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766481, 1, "126793699de55f2c21ed1747c4838e7919ed6a2f0d04af0dc3aeeb760982cbff")
