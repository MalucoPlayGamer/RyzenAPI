-- Lua provided by SkyAPI 
-- Game: AppID 1766480
addappid(1766480)
addappid(1766481, 1, "126793699de55f2c21ed1747c4838e7919ed6a2f0d04af0dc3aeeb760982cbff")
