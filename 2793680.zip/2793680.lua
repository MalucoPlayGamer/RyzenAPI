-- Lua provided by RyzenAPI
-- Game: Game: AppID 2793680

-- MAIN APPLICATION
addappid(2793680)
-- Game: addappid(2793680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793681, 1, "be56fc0b28b3596af3796ac45441de1c132007288e7f685d86123b2e88f37236")
