-- Lua provided by RyzenAPI
-- Game: addappid(2452010)

-- MAIN APPLICATION
addappid(2452010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452012,0,"29aeceb12333cfe23137c838f957b19d5d2d27758ceb55b80990d797d11e2fd6")
