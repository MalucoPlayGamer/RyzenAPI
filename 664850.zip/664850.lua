-- Lua provided by RyzenAPI
-- Game: addappid(664850)

-- MAIN APPLICATION
addappid(664850)

-- MAIN APP DEPOTS / PACKAGES
addappid(664851, 1, "f8d349c2c6c1e8f1793a4098700fa0393ea6f641d45964082d1836cf16afa14c")
