-- Lua provided by RyzenAPI
-- Game: Polterguys: Possession Party

-- MAIN APPLICATION
addappid(1043520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043521, 1, "2fcb4a325ee6a1562f214ef53711da2466da674f0876b01eef55487ea632b82a")
