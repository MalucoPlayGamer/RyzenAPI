-- Lua provided by SkyAPI 
-- Game: Peekaboo Lite
addappid(1514690)
addappid(1514691, 1, "2ab0191c1833fe039fa4bcadaee53c5aad41d58bf7f398d0215797cf768f4ace")
