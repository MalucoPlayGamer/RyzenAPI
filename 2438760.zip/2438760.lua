-- Lua provided by RyzenAPI
-- Game: Game: EOS-503

-- MAIN APPLICATION
addappid(2438760)
-- Game: addappid(2438760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438761, 1, "54a8efc04156da003cc88da661d11373a8f5b0780a1f7940bb6187ad2ceac4ec")
