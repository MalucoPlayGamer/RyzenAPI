-- Lua provided by RyzenAPI
-- Game: Stick It to the Stickman

-- MAIN APPLICATION
addappid(2085540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085541, 1, "770f40e40d880628981e51726a0b14c9516704fc8154041d894b7fd0257b4050")
