-- Lua provided by RyzenAPI
-- Game: Cards We're Dealt: Prologue

-- MAIN APPLICATION
addappid(2473150)
-- Game: addappid(2473150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2473151, 1, "3252e0d60dd98b359e176181e88259260fd60026efbf50afbd40c30b346ae3ba")
addappid(2473152, 1, "412c633a6c050dd567b84c65798bea529342a1d4cf68bd1265ce86f2abe895a7")
addappid(2473153, 1, "aa4437559df75355d52e421a81ee359faf87cae41c7463e256fd7e4968271957")
