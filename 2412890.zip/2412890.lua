-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Rogue Trader Playtest

-- MAIN APPLICATION
addappid(2412890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2412891, 1, "fcfecd2d421a7cc50018bd817f76deddc79d089bd1fff6a8ba414cd03ac5d2f4")
