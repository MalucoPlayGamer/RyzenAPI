-- Lua provided by RyzenAPI
-- Game: AppID 1797790

-- MAIN APPLICATION
addappid(1797790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797791, 1, "8704705951cd03b4d0109f2c878d63bf80b02fabbb4ee287c8bceee229d80f6d")
