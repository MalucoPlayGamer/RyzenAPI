-- Lua provided by RyzenAPI
-- Game: AppID 1797790

-- MAIN APPLICATION
addappid(1797790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797791, 1, "8704705951cd03b4d0109f2c878d63bf80b02fabbb4ee287c8bceee229d80f6d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4854800)
addappid(4854810)
addappid(4854820)
addappid(4854830)
addappid(4854840)
addappid(4854850)
addappid(4854860)
addappid(4854870)
addappid(4854880)
addappid(4854890)
addappid(4854900)
addappid(4854910)
addappid(4854920)
addappid(4854930)
addappid(4854940)
addappid(4854950)
addappid(4854960)
addappid(4854970)
addappid(4854980)
addappid(4854990)
addappid(4855000)
addappid(4855010)
addappid(4855020)
addappid(4855030)
addappid(4855040)
addappid(4855050)
addappid(4855060)
addappid(4855070)
addappid(4855080)
addappid(4855090)
addappid(4855100)
addappid(4855110)
addappid(4855120)
