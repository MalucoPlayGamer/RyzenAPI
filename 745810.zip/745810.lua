-- Lua provided by RyzenAPI
-- Game: addappid(745810)

-- MAIN APPLICATION
addappid(745810)

-- MAIN APP DEPOTS / PACKAGES
addappid(745811, 1, "205116f5783374fe9cd80c8fe3d51e33ec168796a74c034b39706f425cbf0c30")
