-- Lua provided by RyzenAPI
-- Game: KoboldKare

-- MAIN APPLICATION
addappid(1102930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102931, 1, "156789d38368b415ab2b476dc6bb2a96e5753a2f99f6db4d8b55493032d4a864")
addappid(1102932, 1, "0af71db0f694bbef1cb048c278090e404a16345ee43ba8a1b25fbea88555e54e")
addappid(1102933, 1, "d9a8e2992c18cdd625ad8d93dbf1b365a3e3b0a5c3a77beec0c7b1bd6aaed232")
addappid(1102934, 1, "980979c6ec45a736ca3bcdd0a4f1e5b3c450c7865aebff012c44d08e21704bda")
