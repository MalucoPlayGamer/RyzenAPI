-- Lua provided by RyzenAPI
-- Game: Game: Fatermyth

-- MAIN APPLICATION
addappid(2530420)
-- Game: addappid(2530420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530421, 1, "19f837423fecf6afc66f0f4cf6c816e5a4cd111f1a154efcecd98f88325ea53c")
addappid(2916730, 0, "a41230426a43aa3949e67e2681728abfe1eb339b11568fb62f61120c307c10bf")
