-- Lua provided by RyzenAPI
-- Game: Game: Guns of Icarus Alliance

-- MAIN APPLICATION
addappid(608800)
-- Game: addappid(608800)

-- MAIN APP DEPOTS / PACKAGES
addappid(608801, 1, "59f1efb5bbc29b7c24a5f2130f0d4355135b3ab5a87e8c17f9ae2f3e04602723")
addappid(608807, 1, "adafa7403625b62cb97d3201e5d42fd93bb065d0a89484a11c896ba0cca641a0")
addappid(608808, 1, "c2827d7754d8fc76cf30b8d864dd9bb0b19a369fd477fef788a25fd5f1ff49b1")
