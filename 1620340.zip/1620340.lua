-- Lua provided by RyzenAPI
-- Game: addappid(1620340)

-- MAIN APPLICATION
addappid(1620340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620341, 1, "95908f582152d4aca02b760eafea03c451e47277cfaaabddf0f1fc0c046cfb2c")
