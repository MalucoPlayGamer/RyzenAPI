-- Lua provided by SkyAPI 
-- Game: Wrestling Empire
addappid(1620340)
addappid(1620341, 1, "95908f582152d4aca02b760eafea03c451e47277cfaaabddf0f1fc0c046cfb2c")
