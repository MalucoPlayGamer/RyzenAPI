-- Lua provided by RyzenAPI
-- Game: Melobot - A Last Song

-- MAIN APPLICATION
addappid(1937670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937671, 1, "f50f1eca68496223d4ad7bd27bca0d19011139b8f829464c4eb28b088576f3d1")
addappid(3223540, 0, "701e0eba235c09a5a7f4415d708e62dc51d1f817e2242c980631e8ff4c4f2a06")
