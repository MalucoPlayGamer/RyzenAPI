-- Lua provided by RyzenAPI 
-- Game: Melody's Escape
addappid(270210)
addappid(270211, 1, "0c14ff0f7ba1bb141663da7be79e051d67dd85b4829f36415dbef6b9129a25b7")
addappid(270212, 1, "a619b15e58764a3fb5b9ce28c08dc572627eca10f7271fb090d25d8708f7618b")
addappid(270213, 1, "06c628cb50a8e0d05f0fc4169dd65413217e437d607f44abb49f7f6436c2921a")
