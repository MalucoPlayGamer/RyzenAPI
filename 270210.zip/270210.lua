-- Lua provided by RyzenAPI
-- Game: Melody's Escape

-- MAIN APPLICATION
addappid(270210)

-- MAIN APP DEPOTS / PACKAGES
addappid(270211, 1, "0c14ff0f7ba1bb141663da7be79e051d67dd85b4829f36415dbef6b9129a25b7")
addappid(270212, 1, "a619b15e58764a3fb5b9ce28c08dc572627eca10f7271fb090d25d8708f7618b")
addappid(270213, 1, "06c628cb50a8e0d05f0fc4169dd65413217e437d607f44abb49f7f6436c2921a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
