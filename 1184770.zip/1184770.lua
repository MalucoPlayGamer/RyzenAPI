-- Lua provided by RyzenAPI
-- Game: 1184770

-- MAIN APPLICATION
addappid(1184770)
-- Game: addappid(1184770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184771, 1, "0e04445810a9e2966305c43ec0a2c8c692ccdf5456ba0935bcae277bf4c2eadf")
