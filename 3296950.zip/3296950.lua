-- Lua provided by RyzenAPI
-- Game: Awaken: Hentai Dice - Animation Pack

-- MAIN APPLICATION
addappid(3296950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296950,0,"480bfc3f2eb8b7a604b9582ccba095654d7c6142f76e356e336a2979a6fa74db")
