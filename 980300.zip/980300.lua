-- Lua provided by RyzenAPI
-- Game: One Finger Death Punch 2

-- MAIN APPLICATION
addappid(980300)

-- MAIN APP DEPOTS / PACKAGES
addappid(980301, 1, "d4caf6e62301b386a22a2a4a519a5299fe3a1d1df7d699670988e8c4daca9d61")
