-- Lua provided by RyzenAPI
-- Game: Game: Moonstone Crossroads

-- MAIN APPLICATION
addappid(1044840)
-- Game: addappid(1044840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044841, 1, "bed40ed36f2ba5d14be82b005a02ac6c10db872af116b7289150ea7bc804a694")
