-- Lua provided by RyzenAPI 
-- Game: Eira
addappid(1860960)
addappid(1860961, 1, "e410dce151afddd7ffc912ea169b5e8a85f09ef47334e29c0dfe20a434160b50")
