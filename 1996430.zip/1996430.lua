-- Lua provided by RyzenAPI 
-- Game: Dicefolk
addappid(1996430)
addappid(1996431, 1, "b04355c28f36d3615484980648771c6193f3b90eef02a0a2464bee14a0ceea96")
