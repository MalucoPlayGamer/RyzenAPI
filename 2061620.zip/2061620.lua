-- Lua provided by RyzenAPI
-- Game: addappid(2061620)

-- MAIN APPLICATION
addappid(2061620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061621, 1, "c51df7f097c070bad0b9114729138129b0fb6b422041033f5f0173aeee660ae5")
