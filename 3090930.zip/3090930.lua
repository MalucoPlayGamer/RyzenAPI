-- Lua provided by RyzenAPI
-- Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.15「逢魔が刻の狂詩曲」

-- MAIN APPLICATION
addappid(3090930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3090931, 1, "1cff1a8342085558e8e76504820b5a36b21385504e2a9564717ec72572ff706a")

