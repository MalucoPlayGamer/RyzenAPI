-- Lua provided by SkyAPI 
-- Game: AppID 3090930
addappid(3090930)
addappid(3090931, 1, "1cff1a8342085558e8e76504820b5a36b21385504e2a9564717ec72572ff706a")
