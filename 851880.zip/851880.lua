-- Lua provided by RyzenAPI
-- Game: 851880

-- MAIN APPLICATION
addappid(851880)
-- Game: addappid(851880)

-- MAIN APP DEPOTS / PACKAGES
addappid(851881, 1, "5c960851f0f6565ddb12126e1dcd34f514cd423af8e2983e97b5f0fd6fcdcf8a")
