-- Lua provided by RyzenAPI
-- Game: Fishermurs

-- MAIN APPLICATION
addappid(564210)

-- MAIN APP DEPOTS / PACKAGES
addappid(564211, 1, "f39ff8b637377339877fdcf01b7d6e49b940051644d7e1bc34b985564088b384")

