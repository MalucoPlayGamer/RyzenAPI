-- Lua provided by RyzenAPI
-- Game: addappid(2712560)

-- MAIN APPLICATION
addappid(2712560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712561, 1, "85640aa1858a25534190e726deee5940cbf2681ad8ede7ffe9d4628f0e253e57")
