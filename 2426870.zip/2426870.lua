-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 It's a Night Magic Forbidden Yotogi All in Pack

-- MAIN APPLICATION
addappid(2426870)
-- Game: addappid(2426870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426871, 1, "374f33132517c9fb668d755d91337e26d4b05d9851e9727154fcc18883929b8e")
