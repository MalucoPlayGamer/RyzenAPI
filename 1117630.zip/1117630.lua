-- Lua provided by SkyAPI 
-- Game: I got a cat maid
addappid(1117630)
addappid(1117631, 1, "4677c2e2197c037e12062042afac819c656c4567e727139007f94c968df81bbc")
addappid(1141040, 0, "5a05d9e509a6439ceccf261a8d2adbb9262bf730ed55d19956ff6ad7e807c05e")
