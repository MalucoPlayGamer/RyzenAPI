-- Lua provided by RyzenAPI
-- Game: Beat Saber - BTS - "MIC Drop (Steve Aoki Remix)"

-- MAIN APPLICATION
addappid(1463261)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463261,0,"7f59bba9f2c81e96f94a91806e10ba5badeafcd94b59e86635a1507458145c7a")
addappid(3030900,0,"716e6be29f2d2dc88d80a46e18bd9ce55242c5134055e5b8bfdf7a40e842e066")

