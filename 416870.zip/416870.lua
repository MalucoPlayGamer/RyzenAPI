-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228990)
addappid(416870)
addappid(416871)
addappid(416873)
addappid(416874)

-- MAIN APP DEPOTS / PACKAGES
addappid(416872,0,"54468b4c1ff39b399f75f1c9f0aa3eb423599e0ef54e216be2aa5e081dd1042e")

