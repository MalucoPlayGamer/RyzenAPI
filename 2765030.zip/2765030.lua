-- Lua provided by RyzenAPI 
-- Game: Ground Zero Hero PROLOGUE
addappid(2765030)
addappid(2765031, 1, "d19a5198eb59931c4437e7fc49cd79d40069a0255cc7a5cd1710648b47b9390f")
addappid(2765032, 1, "ba4171cc1bf52f932d248eeb4e01a0fc1f9d8f54a8ba5285c1cf04c301542e81")
