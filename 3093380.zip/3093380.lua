-- Lua provided by RyzenAPI
-- Game: Deadlock Station Demo

-- MAIN APPLICATION
addappid(3093380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3093381, 1, "ee8f9268838bf89038e1421f0b474e989ad6566444971107eee5556122f2cd2f")
