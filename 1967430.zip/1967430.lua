-- Lua provided by RyzenAPI
-- Game: Ghost Trick: Phantom Detective

-- MAIN APPLICATION
addappid(1967430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967431, 1, "ef7589c5444c9766ccd3e2cb0e66dafdca7b6eec90068702be49b085059b790a")
addappid(1971250, 0, "48da8f6e1314d4ba91b51ce020582c936fdb55a5ced2f4d5a08a3b1be01f6d73")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
