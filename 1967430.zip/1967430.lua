-- Lua provided by RyzenAPI
-- Game: Ghost Trick: Phantom Detective

-- MAIN APPLICATION
addappid(1967430)
-- Game: addappid(1967430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967431, 1, "ef7589c5444c9766ccd3e2cb0e66dafdca7b6eec90068702be49b085059b790a")
addappid(1971250, 0, "48da8f6e1314d4ba91b51ce020582c936fdb55a5ced2f4d5a08a3b1be01f6d73")
