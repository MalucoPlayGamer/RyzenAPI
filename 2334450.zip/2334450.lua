-- Lua provided by RyzenAPI
-- Game: GhostCatcher

-- MAIN APPLICATION
addappid(2334450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2334451, 1, "7ca368ff574a0441f206d39d259433a3ba6792b2ca00030507caa86c5d7ae3a4")

