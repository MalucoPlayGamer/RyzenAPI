-- Lua provided by RyzenAPI
-- Game: GhostCatcher

-- MAIN APPLICATION
addappid(2334450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334451, 1, "7ca368ff574a0441f206d39d259433a3ba6792b2ca00030507caa86c5d7ae3a4")
