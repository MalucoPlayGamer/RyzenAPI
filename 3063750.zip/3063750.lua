-- Lua provided by RyzenAPI
-- Game: Pixel Dungeon VR

-- MAIN APPLICATION
addappid(3063750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3063751, 1, "6265f528576bd352c2a35a18154ed52fa3972a61b67e16e84abfff989d64a837")

