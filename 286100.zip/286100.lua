-- Lua provided by RyzenAPI
-- Game: addappid(286100)

-- MAIN APPLICATION
addappid(286100)

-- MAIN APP DEPOTS / PACKAGES
addappid(286101, 1, "1210131ed45546bd486be0675af242fd0be49e712a9ee27c935abd091c69b10a")
addappid(286102, 1, "2b64ae0d7bd890d3a12ebb4d778321fada7f341aaf353e716ef3d65ea6aaaa52")
addappid(286103, 1, "e21913704fe5ce2335fecf1a789a12c6d4aa0e46e9fc10b9a9f73b016c93f358")
