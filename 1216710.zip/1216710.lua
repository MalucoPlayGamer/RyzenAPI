-- Lua provided by RyzenAPI
-- Game: Cyber Manhunt

-- MAIN APPLICATION
addappid(1216710)
-- Game: addappid(1216710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216711, 1, "93a2ef4da7abb3c0a21988e44cc9c7a8abba823766701bbd016a218893bacab8")
addappid(1216712, 1, "594356827386d034c3c0bf64a180639b10f2a1f44a2f9c9efd2a5a7c8a3f245c")
addappid(1216713, 1, "7a026571cabf6b38bdb81c7a515f04c4570fb146ab53cac1c3ec18217927c0e0")
