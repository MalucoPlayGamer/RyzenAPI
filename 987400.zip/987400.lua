-- Lua provided by RyzenAPI
-- Game: AppID 987400

-- MAIN APPLICATION
addappid(987400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(987401, 1, "881cc4e21372856e779b95ad4b3c25bd30fcec8bbdaf67e59ffa1a6b474ae7a2")

