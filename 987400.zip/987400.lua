-- Lua provided by SkyAPI 
-- Game: AppID 987400
addappid(987400)
addappid(987401, 1, "881cc4e21372856e779b95ad4b3c25bd30fcec8bbdaf67e59ffa1a6b474ae7a2")
