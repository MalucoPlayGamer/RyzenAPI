-- Lua provided by RyzenAPI
-- Game: 2915870

-- MAIN APPLICATION
addappid(2915870)
-- Game: addappid(2915870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2915872,0,"ff4408d09d99ff0916e96b4eff7c97d087077dbfcf18a72cb6d35a5fd7966918")
