-- Lua provided by RyzenAPI
-- Game: The Centennial Case: A Shijima Story Mini-Soundtrack

-- MAIN APPLICATION
addappid(1906030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906030,0,"be504dfde9b2032645ed5eebffda7828354ea4c0bb5728ab590963a324f7b91a")

