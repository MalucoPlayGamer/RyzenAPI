-- Lua provided by RyzenAPI
-- Game: Tower! 3D

-- MAIN APPLICATION
addappid(1278500)
addappid(1369100)
addappid(1369120)
addappid(1369190)
addappid(1369210)
addappid(1369220)
addappid(1369230)
addappid(1369250)
addappid(1369260)
addappid(1369270)
addappid(1369280)
addappid(1369290)
addappid(1369310)
addappid(1484500)
addappid(1484540)
addappid(1493510)
addappid(1562960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278501, 1, "240fe4ff3392bd0717b56644a97dea7a1e2935e86b95ea66079cd69f53d122b9")

