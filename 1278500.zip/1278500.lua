-- Lua provided by RyzenAPI
-- Game: Tower! 3D

-- MAIN APPLICATION
addappid(1278500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278501, 1, "240fe4ff3392bd0717b56644a97dea7a1e2935e86b95ea66079cd69f53d122b9")
