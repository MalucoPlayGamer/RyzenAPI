-- Lua provided by RyzenAPI
-- Game: MapleStory M

-- MAIN APPLICATION
addappid(3969080)

