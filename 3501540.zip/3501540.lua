-- Lua provided by RyzenAPI
-- Game: Spiritstead

-- MAIN APPLICATION
addappid(3501540) -- Spiritstead

-- MAIN APP DEPOTS / PACKAGES
addappid(3501541, 1, "c45c42428f98241fe8d4517d9b739b95b1fa81208c70c16e9729b84a57388061") -- Depot 3501541



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5065260)
