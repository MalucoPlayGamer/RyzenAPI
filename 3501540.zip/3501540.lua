-- 3501540's Lua and Manifest Created by Hubcap Manifest
-- Spiritstead
-- Created: August 06, 2026 at 23:45:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3501540) -- Spiritstead
-- MAIN APP DEPOTS
addappid(3501541, 1, "c45c42428f98241fe8d4517d9b739b95b1fa81208c70c16e9729b84a57388061") -- Depot 3501541
setManifestid(3501541, "7554801614367442232", 1408453058)