-- Lua provided by RyzenAPI
-- Game: AppID 1478370

-- MAIN APPLICATION
addappid(1478370)
-- Game: addappid(1478370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478371, 1, "687ee70adb532fc84040e313d557bedba33105a40a9c8146e5a959f3247e4732")
