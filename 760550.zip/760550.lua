-- Lua provided by RyzenAPI
-- Game: kakusankibou / 扩散希望

-- MAIN APPLICATION
addappid(760550)

-- MAIN APP DEPOTS / PACKAGES
addappid(760551, 1, "986dfdca87a4b34bc2a13704e79c1a47d7a76a2ec8d552bdcde5a28a59c2bc99")
