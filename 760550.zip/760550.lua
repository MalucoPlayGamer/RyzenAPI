-- Lua provided by SkyAPI 
-- Game: AppID 760550
addappid(760550)
addappid(760551, 1, "986dfdca87a4b34bc2a13704e79c1a47d7a76a2ec8d552bdcde5a28a59c2bc99")
