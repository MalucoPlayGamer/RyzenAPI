-- Lua provided by RyzenAPI
-- Game: Game: AppID 202860

-- MAIN APPLICATION
addappid(202860)
-- Game: addappid(202860)

-- MAIN APP DEPOTS / PACKAGES
addappid(202861, 1, "56a1d1c1cfe4d5a52ecec5f2b547a76a0fa2be8ada8a3e959a54d007daac1d1b")
addappid(202862, 1, "379b2df6c978bfb4adf223fec072c18dd46e8fe075000d3697cf88d947158197")
addappid(202863, 1, "362e2b5a3b91639d23d52f6b658acc62b9781546642fbdb608000617754aaf32")
addappid(202864, 1, "3d7cc93f640b9ac8bfcc20c5eda8c4b3c952dea74cab2918d1a6fb376396b471")
