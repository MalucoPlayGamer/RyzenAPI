-- Lua provided by RyzenAPI 
-- Game: AppID 1300960
addappid(1300960)
addappid(1300961, 1, "19636b7e3b42b141d03f254e78ec4247f62cbdfd41993bdfd8288c21a695852a")
