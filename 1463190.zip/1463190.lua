-- Lua provided by RyzenAPI
-- Game: Beat Saber - BTS - "Boy With Luv (feat. Halsey)"

-- MAIN APPLICATION
addappid(1463190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463191, 1, "5c87b2cfb38e01418b9f228129ab11ee29c2a70f7e84be7757b1718223dcc743")
