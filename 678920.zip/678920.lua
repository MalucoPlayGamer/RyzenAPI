-- Lua provided by RyzenAPI
-- Game: Symploké: La Leyenda de Gustavo Bueno (Capítulo 2)

-- MAIN APPLICATION
addappid(678920)

-- MAIN APP DEPOTS / PACKAGES
addappid(678921,0,"4e76e1b8379f26b684054907bf870d423ce6f680bb13fadfef5f334ad315f976")
addappid(678922,0,"0d197c00e40f87dbd920d5a52f20537e0df984033ad7bd3e02e5daf71b7e3e6a")

