-- Lua provided by RyzenAPI
-- Game: addappid(2287820)

-- MAIN APPLICATION
addappid(2287820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287820,0,"bcbe57f411ac18b942d215a79a1aba82e147df5d27ffae5a52dfdebb8e3c10b0")
