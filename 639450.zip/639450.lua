-- Lua provided by RyzenAPI
-- Game: addappid(639450)

-- MAIN APPLICATION
addappid(639450)

-- MAIN APP DEPOTS / PACKAGES
addappid(639451, 1, "4f9ae37267fb16a552dd186aafc998f5878e5c0f50be3e454edc63058ca42692")
