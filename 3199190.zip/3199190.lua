-- Lua provided by RyzenAPI
-- Game: Magic Cats Pots

-- MAIN APPLICATION
addappid(3199190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3199191, 1, "c3b9748e41c19410eadd6294878168a86a889a5a38a3d2ccfa63d8d2ec3728cf")

