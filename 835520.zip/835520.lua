-- Lua provided by RyzenAPI
-- Game: Dodge Show

-- MAIN APPLICATION
addappid(835520)

-- MAIN APP DEPOTS / PACKAGES
addappid(835521, 1, "3fdd981cd05b208700be5f5f40c77df32a7b1d254c8f69c6857f4774cfe48f44")
