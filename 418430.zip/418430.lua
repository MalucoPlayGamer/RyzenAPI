-- Lua provided by RyzenAPI
-- Game: addappid(418430)

-- MAIN APPLICATION
addappid(418430)

-- MAIN APP DEPOTS / PACKAGES
addappid(418431, 1, "d562a0d707989357001ff38ace6f33a6cdbb914c97851ac8332ccab9ba1aca7d")
