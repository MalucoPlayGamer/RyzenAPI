-- Lua provided by RyzenAPI
-- Game: Science:The world is in your hands

-- MAIN APPLICATION
addappid(863670)

-- MAIN APP DEPOTS / PACKAGES
addappid(863671,0,"895db9c25bc6f2fe08b276fc0175a5f83a74a3489530a12381d5a5b3acd37505")

