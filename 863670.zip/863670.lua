-- Lua provided by RyzenAPI
-- Game: Science:The world is in your hands

-- MAIN APPLICATION
addappid(863670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(863671,0,"895db9c25bc6f2fe08b276fc0175a5f83a74a3489530a12381d5a5b3acd37505")

