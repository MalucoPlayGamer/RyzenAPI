-- Lua provided by RyzenAPI
-- Game: Brother Wings

-- MAIN APPLICATION
addappid(576540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(576541, 1, "ad9736786a97046c133ac15c65c124e035cbe0dc96c9201ba0aab35392d593f3")

