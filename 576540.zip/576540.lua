-- Lua provided by RyzenAPI
-- Game: Brother Wings

-- MAIN APPLICATION
addappid(576540)
-- Game: addappid(576540)

-- MAIN APP DEPOTS / PACKAGES
addappid(576541, 1, "ad9736786a97046c133ac15c65c124e035cbe0dc96c9201ba0aab35392d593f3")
