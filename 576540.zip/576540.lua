-- Lua provided by RyzenAPI 
-- Game: Brother Wings
addappid(576540)
addappid(576541, 1, "ad9736786a97046c133ac15c65c124e035cbe0dc96c9201ba0aab35392d593f3")
