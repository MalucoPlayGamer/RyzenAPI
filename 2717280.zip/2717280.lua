-- Lua provided by RyzenAPI
-- Game: Sniper Simulator

-- MAIN APPLICATION
addappid(2717280)
-- Game: addappid(2717280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717281, 1, "a770472e2d38a616677c3e304c2fb06e1022334cd2f62c209af2508d7138e2cf")
