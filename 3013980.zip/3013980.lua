-- Lua provided by RyzenAPI
-- Game: 3013980

-- MAIN APPLICATION
addappid(3013980)
-- Game: addappid(3013980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3013981, 1, "e04912510b45392e29b5b04bc510a5c66c50d65ce6b3d2bf2b59f5d1cf476e35")
