-- Lua provided by RyzenAPI
-- Game: The Day Of Survival

-- MAIN APPLICATION
addappid(3013980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3013981, 1, "e04912510b45392e29b5b04bc510a5c66c50d65ce6b3d2bf2b59f5d1cf476e35")

