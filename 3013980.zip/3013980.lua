-- Lua provided by RyzenAPI 
-- Game: The Day Of Survival
addappid(3013980)
addappid(3013981, 1, "e04912510b45392e29b5b04bc510a5c66c50d65ce6b3d2bf2b59f5d1cf476e35")
