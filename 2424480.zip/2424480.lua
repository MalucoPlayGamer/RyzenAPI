-- Lua provided by RyzenAPI
-- Game: No Heroes Here 2

-- MAIN APPLICATION
addappid(2424480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424481, 1, "99e221a590529d5b988e92592fd9dd4b1405db0b453d07610b6fa6168c04f1bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
