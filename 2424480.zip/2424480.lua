-- Lua provided by RyzenAPI
-- Game: addappid(2424480)

-- MAIN APPLICATION
addappid(2424480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424481, 1, "99e221a590529d5b988e92592fd9dd4b1405db0b453d07610b6fa6168c04f1bb")
