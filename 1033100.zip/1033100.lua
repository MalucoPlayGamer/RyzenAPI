-- Lua provided by RyzenAPI
-- Game: Mobler

-- MAIN APPLICATION
addappid(1033100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033101, 1, "271a2126f0d74e27e06f9c07507f0052139fed0b0815b66fb3bcb89b05694711")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
