-- Lua provided by RyzenAPI
-- Game: Mobler

-- MAIN APPLICATION
addappid(1033100)
-- Game: addappid(1033100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033101, 1, "271a2126f0d74e27e06f9c07507f0052139fed0b0815b66fb3bcb89b05694711")
