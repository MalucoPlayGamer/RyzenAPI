-- Lua provided by SkyAPI 
-- Game: AppID 1029990
addappid(1029990)
addappid(1029991, 1, "2559783734b87588eb842c2e5198733643c44c27df24feca63fabca48ffb1b3f")
