-- Lua provided by RyzenAPI
-- Game: Game: AppID 1029990

-- MAIN APPLICATION
addappid(1029990)
-- Game: addappid(1029990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029991, 1, "2559783734b87588eb842c2e5198733643c44c27df24feca63fabca48ffb1b3f")
