-- Lua provided by RyzenAPI
-- Game: addappid(1384540)

-- MAIN APPLICATION
addappid(1384540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384541, 1, "0961fd2148a5c59a1ffaaf4b989f2522ad51cc9d075513356e842817f56e1ce4")
