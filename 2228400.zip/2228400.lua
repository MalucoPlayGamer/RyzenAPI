-- Lua provided by RyzenAPI 
-- Game: Unsolved Case: Fatal Clue Collector's Edition
addappid(2228400)
addappid(2228401, 1, "1afde5e5e4f0c7815134241326d2f4d7a2d616676e1f641cd6782915c225da1c")
addappid(2229130, 0, "2203be9f05d31d5da43e6924ccf7e485ce6e9aa2566739c26f12ca3fa9ec0329")
