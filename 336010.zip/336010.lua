-- Lua provided by RyzenAPI
-- Game: 336010

-- MAIN APPLICATION
addappid(336010)
-- Game: addappid(336010)

-- MAIN APP DEPOTS / PACKAGES
addappid(336011, 1, "502112d4687ab50e780d484ea54b1c114f7e7afc44beb62fac9775eb0c7b7e68")
