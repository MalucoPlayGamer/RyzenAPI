-- Lua provided by RyzenAPI
-- Game: DEAD OR ALIVE 6

-- MAIN APPLICATION
addappid(1033460) -- DOA6 Character Ayane
addappid(1033470) -- DOA6 Character Tina
addappid(1033471) -- DOA6 Character Leifang
addappid(1033472) -- DOA6 Character Helena
addappid(1033473) -- DOA6 Character Christie
addappid(1033474) -- DOA6 Character Kokoro
addappid(1033475) -- DOA6 Character La Mariposa
addappid(1033476) -- DOA6 Character Mila
addappid(1033477) -- DOA6 Character Marie Rose
addappid(1033478) -- DOA6 Character Honoka
addappid(1033479) -- DOA6 Character NiCO
addappid(1033480) -- DOA6 Character Hayabusa
addappid(1033481) -- DOA6 Character Hayate
addappid(1033482) -- DOA6 Character Jann Lee
addappid(1033483) -- DOA6 Character Zack
addappid(1033484) -- DOA6 Character Bayman
addappid(1033485) -- DOA6 Character Brad Wong
addappid(1033486) -- DOA6 Character Eliot
addappid(1033487) -- DOA6 Character Rig
addappid(1033488) -- DOA6 Character Raidou
addappid(1033489) -- DEAD OR ALIVE 6 Core Fighters 20 Character Set
addappid(1033490) -- DOA6 Season Pass 1
addappid(1033491) -- DOA6 Season Pass 1 Bonus Costume NiCO
addappid(1033492) -- DOA6 Season Pass 1 Bonus Costume Nyotengu
addappid(1034470) -- DOA6 Story Unlock Key
addappid(1034471) -- DOA6 Character Nyotengu
addappid(1034480) -- DOA6 Character Phase4
addappid(1034481) -- DOA6 Early Purchase Bonus Costume - Kasumi
addappid(1034482) -- DOA6 Digital Deluxe Edition Bonus Costume - Kasumi
addappid(1034483) -- DOA6 Deluxe BGM (3 tracks)
addappid(1034484) -- DOA6 Deluxe Costume Set
addappid(1042850) -- DOA6 Happy Wedding Costume Vol.1 Set
addappid(1042851) -- DOA6 Happy Wedding Costume Vol.2 Set
addappid(1048380) -- DEAD OR ALIVE 6 Core Fighters - Male Fighters Set
addappid(1048381) -- DEAD OR ALIVE 6 Core Fighters - Female Fighters Set
addappid(1054330) -- DEAD OR ALIVE 6 - Full Game
addappid(1058120) -- DOA6 Pirates of the 7 Seas Costumes Vol.1 Set
addappid(1058121) -- DOA6 Pirates of the 7 Seas Costumes Vol.2 Set
addappid(1074260) -- DOA6 Character Mai Shiranui
addappid(1074261) -- DOA6 Happy Wedding Costume - Mai Shiranui
addappid(1074262) -- DOA6 Pirates of the 7 Seas Costume - Mai Shiranui
addappid(1074263) -- DOA6 Nurse Costume - Mai Shiranui
addappid(1074264) -- DOA6 Maid Costume - Mai Shiranui
addappid(1074265) -- DOA6 Bunny Costume - Mai Shiranui
addappid(1074266) -- DOA6 Mai Shiranui Debut Costume Set
addappid(1074267) -- DOA6 Mai Shiranui  Debut Costume Set
addappid(1074270) -- DOA6 Character Kula Diamond
addappid(1074271) -- DOA6 Happy Wedding Costume - Kula Diamond
addappid(1074272) -- DOA6 Pirates of the 7 Seas Costume - Kula Diamond
addappid(1074273) -- DOA6 Nurse Costume - Kula Diamond
addappid(1074274) -- DOA6 Maid Costume - Kula Diamond
addappid(1074275) -- DOA6 Bunny Costume - Kula Diamond
addappid(1074276) -- DOA6 Kula Diamond Debut Costume Set
addappid(1074277) -- DOA6 Kula Diamond  Debut Costume Set
addappid(1092291) -- DOA6  THE KING OF FIGHTERS XIV Mashup Content Set
addappid(1099190) -- DOA6 Happy Wedding Costume Vol.1 - Kasumi
addappid(1099191) -- DOA6 Happy Wedding Costume Vol.1 - Kokoro
addappid(1099200) -- DOA6 Happy Wedding Costume Vol.1 - Leifang
addappid(1099201) -- DOA6 Happy Wedding Costume Vol.1 - Hitomi
addappid(1099202) -- DOA6 Happy Wedding Costume Vol.1 - Marie Rose
addappid(1099203) -- DOA6 Happy Wedding Costume Vol.1 - Nyotengu
addappid(1099210) -- DOA6 Happy Wedding Costume Vol.1 - NiCO
addappid(1099211) -- DOA6 Happy Wedding Costume Vol.1 - Jann Lee
addappid(1099212) -- DOA6 Happy Wedding Costume Vol.1 - Hayabusa
-- addappid(838383) -- Depot 838383 (empty depot)
-- addappid(838384) -- Depot 838384 (empty depot)
-- addappid(838385) -- Depot 838385 (empty depot)
-- addappid(838386) -- Depot 838386 (empty depot)
-- addappid(838387) -- Depot 838387 (empty depot)
-- addappid(838388) -- Depot 838388 (empty depot)
-- addappid(838389) -- Depot 838389 (empty depot)
-- addappid(1033461) -- Depot 1033461 (empty depot)
-- addappid(1033462) -- Depot 1033462 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(838380, 1, "3954db49a58b078fc001215df5238df61508f6378227a2850de379c95c8aaddb") -- DEAD OR ALIVE 6
addappid(838381, 1, "92fb6d22798bdbc124409edb818c41c9c3fd9d61ecbe63da822938138e9c402f") -- Release Data
addappid(838382, 1, "260f44b05ec60bbf5e68d67ddd4ae78e648bb292eae12f9da97193fc00d5ffbe") -- Release App
addtoken(1033460, "13360269898889445960")
addtoken(1033470, "15238142599178128341")
addtoken(1033471, "5361349451755515067")
addtoken(1033472, "9045571180509599884")
addtoken(1033473, "5439780443710653218")
addtoken(1033474, "15499212216936538789")
addtoken(1033475, "17663208581071504597")
addtoken(1033476, "7740829313818471305")
addtoken(1033477, "12771691015090539907")
addtoken(1033478, "8959876260361863512")
addtoken(1033479, "12509055989826031019")
addtoken(1033480, "8305488345013854960")
addtoken(1033481, "15785577573015868638")
addtoken(1033482, "1640183750935869019")
addtoken(1033483, "12274165726822007132")
addtoken(1033484, "5130655573315924963")
addtoken(1033485, "16375660702228433484")
addtoken(1033486, "16674356462863386661")
addtoken(1033487, "13341369112030840651")
addtoken(1033488, "3022472106970559785")
addtoken(1033489, "15000446146281457064")
addtoken(1033491, "14124309683048313497")
addtoken(1033492, "15443703180519279047")
addtoken(1034470, "12926584720767900251")
addtoken(1034471, "6158735455868223595")
addtoken(1034480, "8946727556844140187")
addtoken(1034481, "11326258888400566827")
addtoken(1034482, "17136858179616171006")
addtoken(1034483, "4490832916617145503")
addtoken(1034484, "9382758591433291531")
addtoken(1054330, "9632757680028342101")

