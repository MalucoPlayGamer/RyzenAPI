-- Lua provided by RyzenAPI
-- Game: AppID 920550

-- MAIN APPLICATION
addappid(920550)
-- Game: addappid(920550)

-- MAIN APP DEPOTS / PACKAGES
addappid(920551, 1, "8b4e2cec33255bde2c33ef8a4c927e32a7e109dd13bec58d5381285a8fc6c353")
