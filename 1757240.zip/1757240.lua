-- Lua provided by RyzenAPI
-- Game: Ghost Case

-- MAIN APPLICATION
addappid(1757240)
-- Game: addappid(1757240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757241, 1, "c178d903625856a40fe159f28aa1eb9b870bcc240467a615d669ff2bd639181d")
