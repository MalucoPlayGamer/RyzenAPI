-- Lua provided by RyzenAPI
-- Game: Game: Tokyo College Girls : The Nerd  &  Queen Bees

-- MAIN APPLICATION
addappid(3171000)
-- Game: addappid(3171000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171001, 1, "5b0f4dfd477c8f0e812932181ad19b1b9c7bd5b74186361dfcf8aa2ea9dbf783")
