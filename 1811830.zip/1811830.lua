-- Lua provided by RyzenAPI
-- Game: 1811830

-- MAIN APPLICATION
addappid(1811830)
-- Game: addappid(1811830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811830,0,"c3b3f1bcc0ea3d44d016791ed8e878afec5d5549b5c7808e5c60341749a0fdc2")
