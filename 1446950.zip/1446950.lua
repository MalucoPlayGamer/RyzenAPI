-- Lua provided by RyzenAPI
-- Game: AppID 1446950

-- MAIN APPLICATION
addappid(1446950)
addappid(2585680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1446951, 1, "dd08eaccfbad8f41c8e46d3c58d3bb7d66065d5dc01372db9a86271345e34f8f")
addappid(1446952, 1, "45e170afa7d52576c27444a1efe2c3f0c5e1d7c4b0a0a11699aaed2f22a9c203")
addappid(1446953, 1, "8127fbb54bf148756fa59849784729edd2b734c53805a8e2d75d185c142251db")

