-- Lua provided by RyzenAPI
-- Game: TGV Voyages Train Simulator

-- MAIN APPLICATION
addappid(443910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(443911, 1, "1aa1a33ad1b9d46f1688aff101ae9a73a555b2215037f1af6a362e0ad7fbe647")
addappid(443912, 1, "77f97da4e3eb71d9fc3ab1b46f182969cdd02474545b86ed251ea6df839c3ede")
addappid(443913, 1, "9292151582dcce3269fef0ae5265ca9b4ef2cfaacae16821aedd5ee3c7961ad1")

