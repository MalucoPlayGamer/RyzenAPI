-- Lua provided by RyzenAPI
-- Game: Sigh of the Abyss

-- MAIN APPLICATION
addappid(2025310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025311, 1, "9cbbb5223cbf580119372f8909a69f7609d460041599ab18e35a3f355e7f8697")
addappid(3240980, 0, "04de96bf59a8d68ad832541dadd5f28cff98abcbe07e4939734f9473773a407d")
addappid(3241000, 0, "343fcb41a43982b98d17f089397b7c23fe0f1ea35f841a21fbfd4d46f4fd6b99")
addappid(3348320, 0, "22eb2a44719bc3f3dde27f9ee29a0ed0a4075cf135f9cd8e930f8b73c51413fc")
addappid(3348330, 0, "1c8e2529842c5e1acafb077a6ced8ec8ebf92ad78af291e3ad01e465ae37da8c")
