-- Lua provided by RyzenAPI
-- Game: The Light of the Darkness: Origins DEMO

-- MAIN APPLICATION
addappid(2659260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659261, 1, "c8402fa600238e9ff7b9ab5847ea45a5d0a3c0e288d63a222792c169093c8660")

