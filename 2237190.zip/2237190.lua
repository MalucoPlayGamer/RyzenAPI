-- Lua provided by RyzenAPI
-- Game: Hellfire

-- MAIN APPLICATION
addappid(2237190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2237191, 1, "416aa208e4d681b9745da724a8fccef806101ac4138fd9117aa006409bf9cdbb")

