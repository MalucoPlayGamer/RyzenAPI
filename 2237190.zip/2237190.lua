-- Lua provided by RyzenAPI
-- Game: Game: Hellfire

-- MAIN APPLICATION
addappid(2237190)
-- Game: addappid(2237190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237191, 1, "416aa208e4d681b9745da724a8fccef806101ac4138fd9117aa006409bf9cdbb")
