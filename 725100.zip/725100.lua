-- Lua provided by RyzenAPI
-- Game: Exoblast

-- MAIN APPLICATION
addappid(725100)

-- MAIN APP DEPOTS / PACKAGES
addappid(725101, 1, "f8819f439534be036b6e0d1022cb7b1d3338f11f70bdf1f381f211c087f9753e")
addappid(725102, 1, "fb47ae47af2685a2fa1025ba119126365f0839b432e40eab09e2e6a8431809e6")
addappid(725103, 1, "91f5d40592edcfc658cc5b76659c46f4ac4d0d9a5cdd8b64c6cba39e6fbcde67")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1811100)
addappid(1811101)
