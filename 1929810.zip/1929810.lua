-- Lua provided by RyzenAPI
-- Game: addappid(1929810)

-- MAIN APPLICATION
addappid(1929810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929811, 1, "5ae69b3ad52c8f7acfc9599f4cad3a8a4d896975954260ed8412e0193129bffa")
