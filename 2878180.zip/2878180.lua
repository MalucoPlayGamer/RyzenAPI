-- Lua provided by RyzenAPI
-- Game: Game: Barnacles Beers and Brawls

-- MAIN APPLICATION
addappid(2878180)
-- Game: addappid(2878180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878181, 1, "2048df0926553be0bde58f437befb890293529a7c27c6175484955d86acb7758")
