-- Lua provided by RyzenAPI
-- Game: Barnacles Beers and Brawls

-- MAIN APPLICATION
addappid(2878180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878181, 1, "2048df0926553be0bde58f437befb890293529a7c27c6175484955d86acb7758")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
