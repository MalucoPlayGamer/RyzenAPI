-- Lua provided by RyzenAPI
-- Game: addappid(243020)

-- MAIN APPLICATION
addappid(243020)

-- MAIN APP DEPOTS / PACKAGES
addappid(243021, 1, "f96e7e2d443199ef1c39fa9bd093887b1a213afb2f4f6da397e96ba8b4aee9f2")
