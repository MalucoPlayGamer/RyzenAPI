-- Lua provided by RyzenAPI
-- Game: Pandemonium

-- MAIN APPLICATION
addappid(243020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(243021, 1, "f96e7e2d443199ef1c39fa9bd093887b1a213afb2f4f6da397e96ba8b4aee9f2")

