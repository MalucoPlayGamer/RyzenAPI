-- Lua provided by RyzenAPI 
-- Game: AppID 2366940
addappid(2366940)
addappid(2366941, 1, "d93ac7c2dfd74258fe96f7ecb33e2368861189953028c1fcdb82184d047a8903")
