-- Lua provided by RyzenAPI 
-- Game: AppID 619620
addappid(619620)
addappid(619621, 1, "3fadb7326d57f23693fdd06f49e3b012250d2d83fb311daa637c047a0a5fe37b")
