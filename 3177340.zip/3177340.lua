-- Lua provided by RyzenAPI
-- Game: Tower of Madness

-- MAIN APP DEPOTS / PACKAGES
addappid(3177340, 1, "ca8a5333c4dab198a81ffb788d16199f6fd3b821b034129e4137a5ad9ab6e2cf") -- Tower of Madness
addappid(3177341, 1, "99142729db2fa51e5bdadfafeeb1ff76b9c4835cedc80f89d5c5be86f87a7f9f") -- Depot 3177341
