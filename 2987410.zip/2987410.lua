-- Lua provided by RyzenAPI
-- Game: Dog And Goblin Demo

-- MAIN APPLICATION
addappid(2987410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987411, 1, "c7afe8f516253a2ac75259598bd5251c7424307dce9247cc8e94be200bb007c2")
