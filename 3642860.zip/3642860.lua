-- Lua provided by RyzenAPI
-- Game: VR Naughty

-- MAIN APPLICATION
addappid(3642860)
-- Game: addappid(3642860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3642861, 1, "77c673916b4b93dcb00202eaf45d48c6ae7a265789cde0e2f8f02c8e300a3d34")
