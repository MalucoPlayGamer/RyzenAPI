-- Lua provided by RyzenAPI
-- Game: Deep Sea Valentine

-- MAIN APPLICATION
addappid(1536720)
addappid(1719520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536721, 1, "f446fd75ffdaeaf3617080500fa952fd91c50d7401c50f026c8b8e3533e9990f")
