-- Lua provided by RyzenAPI
-- Game: Danganronpa: Trigger Happy Havoc

-- MAIN APPLICATION
addappid(413410)

-- MAIN APP DEPOTS / PACKAGES
addappid(413411, 1, "8efa4d33a528bc35de5a1620f0841b1d6d449fc5921b3c085e4f10bfdb152828")
addappid(413412, 1, "ad97e969943918e26de898974125ab8431f09f5a1572732d937335a03b413519")
addappid(413413, 1, "bf875d034930944b68e0575d5c483da643627f1fafa8822763431ffdbed482e7")
addappid(413414, 1, "741ffa94eaf9b9954f32b06e3a41f869f09e5bdf5f545c152295d1ba29e58fa5")
addappid(413415, 1, "4fe568108d121484d7783723c682d01a1f19b6bfdd579bb5f4f0c9586c0be8bb")
addappid(440400, 0, "423294a009c1b711d7c6faa1d691a34cc2c98685bc9ad44e5ec7753dbac8eab2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
