-- Lua provided by RyzenAPI
-- Game: addappid(41050)

-- MAIN APPLICATION
addappid(41050)

-- MAIN APP DEPOTS / PACKAGES
addappid(41051, 1, "bfbefa6017a1844cd197f681d98dfe5103a5ae1dadd356b47bcee44d34ae1d23")
