-- Lua provided by RyzenAPI
-- Game: Beat Saber - Lizzo - "Cuz I Love You"

-- MAIN APPLICATION
addappid(2122142)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122142,0,"df3c761f3f727596b3ac707fead29377e6f1f48885c675ebe31ddc60101bfa3a")

