-- Lua provided by RyzenAPI
-- Game: addappid(2679430)

-- MAIN APPLICATION
addappid(2679430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679431, 1, "b5377f44999b2de2da6d3eb180bba1eda0c028f729e2b0666158cac58f9c8be4")
