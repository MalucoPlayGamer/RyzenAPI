-- Lua provided by RyzenAPI
-- Game: DYO

-- MAIN APPLICATION
addappid(791470)
addappid(806050)

-- MAIN APP DEPOTS / PACKAGES
addappid(791471, 1, "4faff434e8901e99bfafbe0ce1bd1ca0750f90172cce2cda6183c7cb5ae36800")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
