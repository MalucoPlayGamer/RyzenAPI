-- Lua provided by SkyAPI 
-- Game: DYO
addappid(791470)
addappid(791471, 1, "4faff434e8901e99bfafbe0ce1bd1ca0750f90172cce2cda6183c7cb5ae36800")
addappid(806050)
