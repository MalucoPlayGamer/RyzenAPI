-- Lua provided by RyzenAPI
-- Game: DYO

-- MAIN APPLICATION
addappid(791470)
addappid(806050)

-- MAIN APP DEPOTS / PACKAGES
addappid(791471, 1, "4faff434e8901e99bfafbe0ce1bd1ca0750f90172cce2cda6183c7cb5ae36800")

