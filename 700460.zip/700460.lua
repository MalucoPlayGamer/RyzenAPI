-- Lua provided by RyzenAPI
-- Game: Nine Worlds - A Viking saga

-- MAIN APPLICATION
addappid(700460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(700461, 1, "3636e9dc941084d3d05d952bd7301c545b8c85a0e2cea6f48c47dc95ff6b0286")
