-- Lua provided by RyzenAPI
-- Game: Game: AppID 700460

-- MAIN APPLICATION
addappid(700460)
-- Game: addappid(700460)

-- MAIN APP DEPOTS / PACKAGES
addappid(700461, 1, "3636e9dc941084d3d05d952bd7301c545b8c85a0e2cea6f48c47dc95ff6b0286")
