-- Lua provided by SkyAPI 
-- Game: AppID 742240
addappid(742240)
addappid(742241, 1, "a5aeb04d7c640ef649b80624dd1e68c6da54f9881c77a7994eb87e69012cc815")
addappid(742242, 1, "b746c5a4c7614f444289033cdd94f161cb6e4f0ba9fdc75463efba4eee86173c")
