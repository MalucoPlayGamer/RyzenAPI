-- Lua provided by RyzenAPI
-- Game: Game: The Rake

-- MAIN APPLICATION
addappid(2668530)
-- Game: addappid(2668530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668531, 1, "3a8447dfffb17f85a96a9974cc585ec2420439d52580897e8ca908565f1a41c5")
