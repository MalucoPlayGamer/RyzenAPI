-- Lua provided by RyzenAPI
-- Game: The Rake

-- MAIN APPLICATION
addappid(2668530)
addappid(3099440)
addappid(3099460)
addappid(4101330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2668531, 1, "3a8447dfffb17f85a96a9974cc585ec2420439d52580897e8ca908565f1a41c5")

