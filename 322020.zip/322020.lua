-- Lua provided by RyzenAPI
-- Game: The Talos Principle: Soundtrack

-- MAIN APPLICATION
addappid(322020)

-- MAIN APP DEPOTS / PACKAGES
addappid(322020,0,"e9ad80482e373344f378195184d34acc835c461d2562ecb412af57c83ebd1926")
addappid(322023,0,"e98c10c99224092e206902cce3494e4b95a23a138fc00841bb2840b54eb3edf0")

