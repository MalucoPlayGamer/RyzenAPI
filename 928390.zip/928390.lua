-- Lua provided by RyzenAPI
-- Game: R-Type Dimensions EX

-- MAIN APPLICATION
addappid(928390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(928391, 1, "9dd53ad79e64ca413e7586708a57b277200db780d2fb8589ff3329edec49bc7c")

