-- Lua provided by RyzenAPI
-- Game: R-Type Dimensions EX

-- MAIN APPLICATION
addappid(928390)

-- MAIN APP DEPOTS / PACKAGES
addappid(928391, 1, "9dd53ad79e64ca413e7586708a57b277200db780d2fb8589ff3329edec49bc7c")
