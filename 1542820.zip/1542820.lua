-- Lua provided by RyzenAPI
-- Game: Roguely

-- MAIN APPLICATION
addappid(1542820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542821, 1, "d2662ee4ee1381211568ce0749f4c86217962f0cf5f19ab21afb3a2e830470a1")
