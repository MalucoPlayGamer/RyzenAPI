-- Lua provided by SkyAPI 
-- Game: Project Venus.RP
addappid(1678710)
addappid(1678711, 1, "5942c4c13bf689bfb693168b31aa62f7ff26a21ea03c4d771577bb1d4f98fde0")
