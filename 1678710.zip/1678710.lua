-- Lua provided by RyzenAPI
-- Game: Game: Project Venus.RP

-- MAIN APPLICATION
addappid(1678710)
-- Game: addappid(1678710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678711, 1, "5942c4c13bf689bfb693168b31aa62f7ff26a21ea03c4d771577bb1d4f98fde0")
