-- Lua provided by RyzenAPI 
-- Game: Ludo Supremo
addappid(487580)
addappid(487581, 1, "67ee57883917d1642e65ceea3a009f9ea35e28bf20f2a03f797f3a1c37eb8b2f")
