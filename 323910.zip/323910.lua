-- Lua provided by SkyAPI 
-- Game: SteamVR Performance Test
addappid(323910)
addappid(323911, 1, "04a34a5877f2a6a40c2eded4dc4f40b80892b4482d4dbdd2e6c62bff5620b917")
addappid(323912, 1, "2a64a6269a1f16270a04e9a2b91efdd9ce7e68b06a821e00ae14dd247662911f")
