-- Lua provided by RyzenAPI
-- Game: 2778870

-- MAIN APPLICATION
addappid(2778870)
-- Game: addappid(2778870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778871, 1, "f380d1c2e1778afbe2a04fac31ac473383a5439f9b908e7e9407d11a79b745a8")
