-- Lua provided by RyzenAPI
-- Game: Hans

-- MAIN APPLICATION
addappid(2616420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616421, 1, "c955bc2ec203438354cb6f35da4f51e5f40a0632074921faf975d8d58ed33145")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
