-- Lua provided by RyzenAPI 
-- Game: Hans
addappid(2616420)
addappid(2616421, 1, "c955bc2ec203438354cb6f35da4f51e5f40a0632074921faf975d8d58ed33145")
