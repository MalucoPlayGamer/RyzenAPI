-- Lua provided by SkyAPI 
-- Game: AppID 375000
addappid(375000)
addappid(375001, 1, "f8461d25c7dfc7615898f87a151b0e73577f23a45e8985a751968f51fb2d3c74")
