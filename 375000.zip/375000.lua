-- Lua provided by RyzenAPI
-- Game: Icarus-X: Tides of Fire

-- MAIN APPLICATION
addappid(375000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(375001, 1, "f8461d25c7dfc7615898f87a151b0e73577f23a45e8985a751968f51fb2d3c74")
