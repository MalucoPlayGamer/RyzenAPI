-- Lua provided by RyzenAPI
-- Game: 2805130

-- MAIN APPLICATION
addappid(2805130)
-- Game: addappid(2805130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805131, 1, "13da88e45b54956532f3c39aeae37c4b55e0dec313619be5ec6ed2c70eeddbae")
