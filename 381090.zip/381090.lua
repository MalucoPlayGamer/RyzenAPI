-- Lua provided by RyzenAPI
-- Game: Ted by Dawn

-- MAIN APPLICATION
addappid(381090)

-- MAIN APP DEPOTS / PACKAGES
addappid(381091, 1, "afe79e1009bd4d98c02ab56ee5022a254cde82b456618a6d0a18cc47b56a4652")

