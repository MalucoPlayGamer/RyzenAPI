-- Lua provided by RyzenAPI
-- Game: Incremental Adventures

-- MAIN APPLICATION
addappid(1371630)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1372490)
addappid(1379310)
addappid(1379311)
