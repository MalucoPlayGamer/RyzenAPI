-- Lua provided by RyzenAPI
-- Game: Incremental Adventures

-- MAIN APPLICATION
addappid(1371630)

