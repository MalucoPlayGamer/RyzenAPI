-- Lua provided by RyzenAPI
-- Game: Game: Resident Evil Village Original Soundtrack

-- MAIN APPLICATION
addappid(1608280)
-- Game: addappid(1608280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608281, 1, "555674ef85c403570c5d053a3f218bcbcd5a1a76ac0d9474a57c1f2a9ce6d654")
addappid(1608282, 1, "d6f2af14f5f29a0b31bfe21ce318c38f9f3069a293235f80f3245034be5cd8b4")
addappid(1608283, 1, "42602529decdad2e6e1baa4cbc078be8ef604912036487806865cf684288265a")
