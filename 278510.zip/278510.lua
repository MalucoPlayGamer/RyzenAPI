-- Lua provided by RyzenAPI
-- Game: AppID 278510

-- MAIN APPLICATION
addappid(278510)

-- MAIN APP DEPOTS / PACKAGES
addappid(278511, 1, "63dba9ae7852977c79780827a4f1b8c24a3ac0d28422e479bd96fd21fb35a668")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
