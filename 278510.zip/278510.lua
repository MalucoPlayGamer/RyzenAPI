-- Lua provided by RyzenAPI
-- Game: Game: AppID 278510

-- MAIN APPLICATION
addappid(278510)
-- Game: addappid(278510)

-- MAIN APP DEPOTS / PACKAGES
addappid(278511, 1, "63dba9ae7852977c79780827a4f1b8c24a3ac0d28422e479bd96fd21fb35a668")
