-- Lua provided by RyzenAPI
-- Game: Pleasure Cruise

-- MAIN APPLICATION
addappid(3987810)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4155780)
