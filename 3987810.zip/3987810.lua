-- Lua provided by RyzenAPI
-- Game: Pleasure Cruise

-- MAIN APPLICATION
addappid(3987810)
