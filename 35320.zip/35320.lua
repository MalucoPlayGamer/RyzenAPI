-- Lua provided by RyzenAPI
-- Game: AppID 35320

-- MAIN APPLICATION
addappid(35320)

-- MAIN APP DEPOTS / PACKAGES
addappid(35321, 1, "2a3008a0259b2da1a6fbdb098220b663be82ecadacd1ed2ef93acd13f79df3f8")

