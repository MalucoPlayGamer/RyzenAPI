-- Lua provided by RyzenAPI
-- Game: Game: Milf Toys 3

-- MAIN APPLICATION
addappid(2076390)
-- Game: addappid(2076390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076391, 1, "35b076d908d2bed595880162ee27ba70a3a2456e64b2b5129792488159bf74f3")
