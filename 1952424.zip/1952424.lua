-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Furnitures & Ornaments Pack Vol.2

-- MAIN APPLICATION
addappid(1952424)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952424,0,"edbeb4e449aaa88857855ae58083839668e672b746955cb58999dd7c5581cb55")

