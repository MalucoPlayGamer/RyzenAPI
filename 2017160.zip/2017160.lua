-- Lua provided by RyzenAPI
-- Game: Hot Milf 6

-- MAIN APPLICATION
addappid(2017160)
-- Game: addappid(2017160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017161, 1, "647ceb87cd2a366d60b28ae2fd8fa1b7d5976903be06c42a55f65de5db9cc59c")
