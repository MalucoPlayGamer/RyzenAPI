-- Lua provided by RyzenAPI
-- Game: Incredible Mandy

-- MAIN APPLICATION
addappid(857950)

-- MAIN APP DEPOTS / PACKAGES
addappid(857951, 1, "0f1fc6c3625b5fcfb46ea605e9608646b46824e6e8868a23f0f982a7f94ad8e8")

