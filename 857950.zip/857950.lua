-- Lua provided by RyzenAPI 
-- Game: AppID 857950
addappid(857950)
addappid(857951, 1, "0f1fc6c3625b5fcfb46ea605e9608646b46824e6e8868a23f0f982a7f94ad8e8")
