-- Lua provided by RyzenAPI 
-- Game: Ys VIII: Lacrimosa of DANA
addappid(579180)
addappid(579181, 1, "31d9c6b793e7119501f27acde3eb75748facee4c7708c44b9f432c8f1daebab3")
addappid(579182, 1, "b0a69215e48ef5ba197b4363532701e3b86e561c0dbaedd5a6b9ddf8a27a184c")
addappid(677691, 0, "31efb3e1909213ce670db3feb5d8625367fc924fc834640c6cede41b93fce04b")
addappid(677692, 0, "a7cfdede3d687513e47c4b03a3824adb2f4c4f25280e46f5f813b3810d6c9a46")
