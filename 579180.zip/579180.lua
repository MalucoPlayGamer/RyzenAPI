-- Lua provided by RyzenAPI
-- Game: Ys VIII: Lacrimosa of DANA

-- MAIN APPLICATION
addappid(579180)

-- MAIN APP DEPOTS / PACKAGES
addappid(579181, 1, "31d9c6b793e7119501f27acde3eb75748facee4c7708c44b9f432c8f1daebab3")
addappid(579182, 1, "b0a69215e48ef5ba197b4363532701e3b86e561c0dbaedd5a6b9ddf8a27a184c")
addappid(677691, 0, "31efb3e1909213ce670db3feb5d8625367fc924fc834640c6cede41b93fce04b")
addappid(677692, 0, "a7cfdede3d687513e47c4b03a3824adb2f4c4f25280e46f5f813b3810d6c9a46")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(677690)
addappid(707170)
addappid(707172)
addappid(707173)
addappid(707174)
addappid(707175)
addappid(707176)
addappid(707177)
addappid(707178)
addappid(707179)
addappid(707180)
addappid(707181)
addappid(707182)
addappid(707183)
addappid(707184)
addappid(707185)
addappid(707186)
addappid(707187)
addappid(707188)
addappid(707190)
addappid(707191)
addappid(707192)
addappid(707193)
addappid(707194)
addappid(707195)
