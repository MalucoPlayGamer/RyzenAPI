-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228985)
addappid(228988)
addappid(2561940)
addappid(2561941)
addappid(2561943)
-- Game: addappid(2561940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2561942,0,"af1b786e519cdd68cce232de7f5b868383ac2196d6158c82643cf7c63bb1d787")
