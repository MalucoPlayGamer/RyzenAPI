-- Lua provided by RyzenAPI
-- Game: Jenni's DONG has got it GOIN' ON: The Jenni Trilogy

-- MAIN APPLICATION
addappid(2148850)
-- Game: addappid(2148850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148851, 1, "f8556167d9272befd6d0f02d906462b487d063c1e6a5650ae81c173a2c90796b")
