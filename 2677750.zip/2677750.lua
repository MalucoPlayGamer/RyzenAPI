-- Lua provided by RyzenAPI 
-- Game: VRidge
addappid(2677750)
addappid(2677751, 1, "91ea9b47c5e7f5a0d687007a4492d1ad388b3577ad5129afaeefb0489b98fa49")
addappid(2677770)
