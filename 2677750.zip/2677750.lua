-- Lua provided by RyzenAPI
-- Game: VRidge

-- MAIN APPLICATION
addappid(2677750)
addappid(2677770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677751, 1, "91ea9b47c5e7f5a0d687007a4492d1ad388b3577ad5129afaeefb0489b98fa49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
