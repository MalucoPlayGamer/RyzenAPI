-- Lua provided by RyzenAPI
-- Game: Break Chance Memento

-- MAIN APPLICATION
addappid(432130)

-- MAIN APP DEPOTS / PACKAGES
addappid(432131, 1, "8dc04b2c6b71f3bbc6d1aa24624a59124f16e2107cc2a8fe4ea657c41ae10a63")
