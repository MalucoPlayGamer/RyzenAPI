-- Lua provided by RyzenAPI
-- Game: Game: AppID 504000

-- MAIN APPLICATION
addappid(504000)
-- Game: addappid(504000)

-- MAIN APP DEPOTS / PACKAGES
addappid(504001, 1, "ab314cf7e3babeaba946c054364d4bed73571682fd3ec9fd4d8c5e17a837db70")
