-- Lua provided by RyzenAPI
-- Game: addappid(1728550)

-- MAIN APPLICATION
addappid(1728550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728551, 1, "e98356be4d38971f69653fa9a1e75198407a2b100d4d955a7ff1ceac8a973bd6")
