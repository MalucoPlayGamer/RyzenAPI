-- Lua provided by SkyAPI 
-- Game: Phantom Thief Sylphy
addappid(1728550)
addappid(1728551, 1, "e98356be4d38971f69653fa9a1e75198407a2b100d4d955a7ff1ceac8a973bd6")
