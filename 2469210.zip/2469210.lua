-- Lua provided by RyzenAPI
-- Game: Outcast - A New Beginning Soundtrack

-- MAIN APPLICATION
addappid(2469210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469211, 1, "e3d19946f53a8fc85b0a675fad7ac40bb3260ca06f804a50bffce1acd2e6802c")
addappid(2469212, 1, "425dd42033fabf43b9192af23ffd3e481516b56e14e0f30aae2073c2e6613576")

