-- Lua provided by SkyAPI 
-- Game: IIslands of War
addappid(1162470)
addappid(1162471, 1, "6e4f526407f94a57067775a102380ddcb67406a856e0e480e57bb689f1416c39")
