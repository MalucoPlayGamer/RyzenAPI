-- Lua provided by RyzenAPI
-- Game: Game: IIslands of War

-- MAIN APPLICATION
addappid(1162470)
-- Game: addappid(1162470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162471, 1, "6e4f526407f94a57067775a102380ddcb67406a856e0e480e57bb689f1416c39")
