-- Lua provided by RyzenAPI
-- Game: 382990

-- MAIN APPLICATION
addappid(382990)
-- Game: addappid(382990)

-- MAIN APP DEPOTS / PACKAGES
addappid(382991, 1, "e2970e4ea59499d379e6a1a3474407cab0dbba01fe67e9c340f69ee37e1ab65f")
