-- Lua provided by RyzenAPI
-- Game: addappid(2302890)

-- MAIN APPLICATION
addappid(2302890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302890,0,"e1e6947c89bdac7882e1d6de61a59d18e5e1fa13688dc9df74db057d89fab786")
