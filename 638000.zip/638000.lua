-- Lua provided by RyzenAPI
-- Game: When Ski Lifts Go Wrong

-- MAIN APPLICATION
addappid(638000)
-- Game: addappid(638000)

-- MAIN APP DEPOTS / PACKAGES
addappid(638001, 1, "99cd590a0ddd231e2af01c439d21c9facfba6a02a760f903582685c2c3270338")
addappid(638002, 1, "264e1b92d65cca303d330d4876abed30e14e8aa38eb7e1f5bb2801b138c2ea42")
addappid(729230, 0, "2a728a98cd2715264209245713ddf8c1e1ba812e648ba50fadec4c514c47a5a6")
