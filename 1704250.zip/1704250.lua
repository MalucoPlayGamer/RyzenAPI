-- Lua provided by RyzenAPI
-- Game: Pirated Code: Admin Edition

-- MAIN APPLICATION
addappid(1704250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704251, 1, "120417faa6240f43ab4943d096cf038317a4853ef6048bb65f75c516f7ab011c")

