-- Lua provided by RyzenAPI
-- Game: 梦塔防

-- MAIN APPLICATION
addappid(1091740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091741, 1, "88e5eaefce698a9af95cbff3a25fe878f56cf6085b880ca138e8eabc7a3b7117")
