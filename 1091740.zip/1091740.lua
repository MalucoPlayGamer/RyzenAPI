-- Lua provided by SkyAPI 
-- Game: 梦塔防
addappid(1091740)
addappid(1091741, 1, "88e5eaefce698a9af95cbff3a25fe878f56cf6085b880ca138e8eabc7a3b7117")
