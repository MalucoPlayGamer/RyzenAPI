-- Lua provided by RyzenAPI
-- Game: addappid(404600)

-- MAIN APPLICATION
addappid(404600)

-- MAIN APP DEPOTS / PACKAGES
addappid(404601, 1, "750a3acfe1490c872019466ae5e1bf597245372ebbd4e3a0f81b0374e0278dd0")
