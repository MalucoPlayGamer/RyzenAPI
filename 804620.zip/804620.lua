-- Lua provided by RyzenAPI
-- Game: AppID 804620

-- MAIN APPLICATION
addappid(804620)

-- MAIN APP DEPOTS / PACKAGES
addappid(804621, 1, "71d5d1afa9ac4a73b173ba9e73dafb798826488c3ed881253ebb0c63aa873fc8")

