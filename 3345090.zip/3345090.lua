-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin PixelScapes Castle Pack

-- MAIN APPLICATION
addappid(3345090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345090,0,"a5069f3daab1e2b3c8b7860276383ee595918cec1061e4b7b2acc9f998d25a4f")
