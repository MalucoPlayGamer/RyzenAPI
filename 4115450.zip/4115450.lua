-- Lua provided by RyzenAPI
-- Game: addappid(4115450)

-- MAIN APPLICATION
addappid(4115450)

-- MAIN APP DEPOTS / PACKAGES
addappid(41115451,1,"?")
