-- Lua provided by RyzenAPI
-- Game: Royal Alchemist

-- MAIN APPLICATION
addappid(939790)
-- Game: addappid(939790)

-- MAIN APP DEPOTS / PACKAGES
addappid(939792,0,"5548af0daf1ad459bad9f156468df64f5d0bf607699bba53005057b4327e9cd3")
addappid(939793,0,"6d89a81800ea529920bc44a60b73d0abd5c5dbfc47bcbeab95ec7a0b42ba2a4a")
addappid(939794,0,"23e4f1a7eda58ebcd957eb3825cee9054f260933faa60f34a701099d3e5f0193")
