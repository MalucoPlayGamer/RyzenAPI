-- Lua provided by RyzenAPI
-- Game: Iterum Playtest

-- MAIN APPLICATION
addappid(2247470)
-- Game: addappid(2247470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247471, 1, "6afde9f288261091a8bf0e4342747a816df2d7e4269c58bd142597206e621e74")
