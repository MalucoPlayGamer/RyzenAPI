-- Lua provided by RyzenAPI
-- Game: 1159580

-- MAIN APPLICATION
addappid(1159580)
-- Game: addappid(1159580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159581, 1, "6c9506fce0bb98a12b1f1654ed3927a14aa901bb12b027b4037aeffaba80c661")
