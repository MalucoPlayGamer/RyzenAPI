-- Lua provided by RyzenAPI 
-- Game: AppID 796480
addappid(796480)
addappid(796481, 1, "51bb3cf22642af9bd46e3958ed2e9df6bbfc01bb2225c5d717568b165232bf04")
