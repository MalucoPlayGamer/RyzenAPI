-- Lua provided by RyzenAPI
-- Game: Rento Fortune - Multiplayer Board Game

-- MAIN APPLICATION
addappid(663390)
addappid(1544590)
addappid(1734580)
addappid(2922310)
addappid(3853770)
addappid(4563500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(663391, 1, "26c84387339d2e7df9f8ba26354f03a44c2e8059c06d945827a6f0e23cd9b084")
addappid(663392, 1, "5ec3436f9d64f05088ff8de11bea3c314974e16a501c06dc05ef15022842a213")
addappid(663399, 1, "247cb16d932fdfff084dac38b09ea5a8eef69ba3df10fdb8e7496483544c290c")
addappid(1074660, 0, "5d39bc1fb162e28f91a1821dfcb652a89624a0e6a8d33a32e0e521744af45111")

