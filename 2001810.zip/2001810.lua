-- Lua provided by RyzenAPI
-- Game: Tricky Machines Demo

-- MAIN APPLICATION
addappid(2001810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001811, 1, "c51123103cd89d40eb4807e39cbdb505bf6800be968806aecbd1accf4864f039")
