-- Lua provided by RyzenAPI
-- Game: AppID 2096320

-- MAIN APPLICATION
addappid(2096320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096321, 1, "e4657b1739bc3ce6bc8ba38e91e7deb0eb4e776be94e60956d1f6246f80d5b48")

