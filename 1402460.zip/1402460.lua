-- Lua provided by RyzenAPI
-- Game: Game: BattleStick 2

-- MAIN APPLICATION
addappid(1402460)
-- Game: addappid(1402460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402461, 1, "ed2ccc8058673ed660140d71687f6d220078980f2d3ebb2544933343c84570fc")
