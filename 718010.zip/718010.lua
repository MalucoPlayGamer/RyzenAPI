-- Lua provided by RyzenAPI
-- Game: Game: Robbie Swifthand and the Orb of Mysteries

-- MAIN APPLICATION
addappid(718010)
-- Game: addappid(718010)

-- MAIN APP DEPOTS / PACKAGES
addappid(718011, 1, "dca072b2151a1f645010a9125d92a7714f6f59e6d7bfe02b9fa0daa0d33d241c")
addappid(984130, 0, "eda87435421b3899a54305320f13c3005a15f4c02b75c45f14f63b1cb78b5c5f")
