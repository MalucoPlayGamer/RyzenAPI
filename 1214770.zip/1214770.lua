-- Lua provided by RyzenAPI
-- Game: Game: AppID 1214770

-- MAIN APPLICATION
addappid(1214770)
-- Game: addappid(1214770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214771, 1, "8b75c0a0899e37a7602a8fba09bbe035c73ec178a962bf6a40f490d1c70504bd")
