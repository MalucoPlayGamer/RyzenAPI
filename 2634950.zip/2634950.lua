-- Lua provided by RyzenAPI
-- Game: Tokyo Xtreme Racer

-- MAIN APPLICATION
addappid(2634950)
-- Game: addappid(2634950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2634951, 1, "0f27021c9467560d6fd421ba480ebc674efa20375f8a2af71fc51e28345005f5")
