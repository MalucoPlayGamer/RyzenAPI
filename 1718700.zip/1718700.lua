-- Lua provided by RyzenAPI
-- Game: inAntrum - Prototype

-- MAIN APPLICATION
addappid(1718700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718701, 1, "052c98727d6f9f7bf2cc2905c89f577ed8f8ca8684cdc8c6ade72f6e10a64618")
