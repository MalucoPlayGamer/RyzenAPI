-- Lua provided by RyzenAPI
-- Game: Lords of Football

-- MAIN APPLICATION
addappid(230650)

-- MAIN APP DEPOTS / PACKAGES
addappid(230651, 1, "2831fd9468f22cc0cbccb8e4b9cab886202a2d925ffedb84fc440115dad6a9c2")
addappid(230690, 0, "15af2966faaf0a33879fd7edd9c94c8859a3aec9f187e4dfefa9c320d5892c4f")
addappid(230691, 0, "4148b6c186aa4e3d7febfe712c0d417cd16e1cdbb8fc542eaf34ecb4f9ba4412")
addappid(230692, 0, "f2381cad528665a127407a2674d267eb1bf9cc5c366cbfac4f1c7606594998df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
