-- Lua provided by RyzenAPI
-- Game: addappid(230650)

-- MAIN APPLICATION
addappid(230650)

-- MAIN APP DEPOTS / PACKAGES
addappid(230651, 1, "2831fd9468f22cc0cbccb8e4b9cab886202a2d925ffedb84fc440115dad6a9c2")
addappid(230690, 0, "15af2966faaf0a33879fd7edd9c94c8859a3aec9f187e4dfefa9c320d5892c4f")
addappid(230691, 0, "4148b6c186aa4e3d7febfe712c0d417cd16e1cdbb8fc542eaf34ecb4f9ba4412")
addappid(230692, 0, "f2381cad528665a127407a2674d267eb1bf9cc5c366cbfac4f1c7606594998df")
