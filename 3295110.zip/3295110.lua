-- Lua provided by RyzenAPI
-- Game: Game: LEVEL 37

-- MAIN APPLICATION
addappid(3295110)
-- Game: addappid(3295110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3295111, 1, "67f7ae688f4600d3777d67cab957633c1243a40d1ad2b734463a5763627f721c")
