-- Lua provided by RyzenAPI
-- Game: Game: UNI

-- MAIN APPLICATION
addappid(1011300)
-- Game: addappid(1011300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011301, 1, "745b06ad37bf07447add7d2bff6808bca39c599a66a9227ed47cfd6f7616079e")
