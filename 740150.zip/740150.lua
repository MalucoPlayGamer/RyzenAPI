-- Lua provided by RyzenAPI
-- Game: AppID 740150

-- MAIN APPLICATION
addappid(740150)

-- MAIN APP DEPOTS / PACKAGES
addappid(740151, 1, "2d17a2ef7fb7a1db633860e6af7c93178695c18b38c9188bb022707dfe7ef2c9")
addappid(740152, 1, "adbc156e330b489fed41641c6009d358ce0333adcc8d8c3ccacf97d6b3d2d785")
