-- Lua provided by RyzenAPI
-- Game: Burn, Clown, Burn!

-- MAIN APPLICATION
addappid(740150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(740151, 1, "2d17a2ef7fb7a1db633860e6af7c93178695c18b38c9188bb022707dfe7ef2c9")
addappid(740152, 1, "adbc156e330b489fed41641c6009d358ce0333adcc8d8c3ccacf97d6b3d2d785")
