-- Lua provided by RyzenAPI
-- Game: Blue-Collar Astronaut

-- MAIN APPLICATION
addappid(414760)

-- MAIN APP DEPOTS / PACKAGES
addappid(414761, 1, "dc27c53a5701b6893d35ece8060767c18ad0f7d946f64d38ce9cfae2c6cca9e7")
addappid(414762, 1, "e4578c358dee7dee00f463f216e52d515ec2df3f87462b4b5d9bf5d7f451ec3c")
addappid(414763, 1, "afc7a9899952023dbbfde63361bda01c129edf82118388b75e1fc4a087743d35")
addappid(616600, 0, "9c02786b72dfe9bf7536ac6f537ca650efc0903063f5ba19b98ac73a7189fe07")
