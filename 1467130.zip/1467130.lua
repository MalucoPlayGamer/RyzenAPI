-- Lua provided by RyzenAPI
-- Game: White Dandelion

-- MAIN APPLICATION
addappid(1467130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467131, 1, "3d862fab89025d4f933b66a5abb4a3e748365dd9ac5ce436df551d06b0eadc0b")

