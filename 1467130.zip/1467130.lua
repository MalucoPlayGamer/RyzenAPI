-- Lua provided by RyzenAPI 
-- Game: AppID 1467130
addappid(1467130)
addappid(1467131, 1, "3d862fab89025d4f933b66a5abb4a3e748365dd9ac5ce436df551d06b0eadc0b")
