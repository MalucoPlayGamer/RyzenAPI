-- Lua provided by RyzenAPI
-- Game: Game: AppID 3009390

-- MAIN APPLICATION
addappid(3009390)
-- Game: addappid(3009390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009391, 1, "14b2ff8651e5fe59481c5659455e65d6cc6c2df8f3ac4cffe84478e6ac909590")
