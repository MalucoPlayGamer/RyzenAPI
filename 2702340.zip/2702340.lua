-- Lua provided by RyzenAPI
-- Game: addappid(2702340)

-- MAIN APPLICATION
addappid(2702340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702341, 1, "05a8143a15eab5df9e125fb722b9e6ebd337c320aaa1f29c7acdb815a5f1e000")
