-- Lua provided by RyzenAPI
-- Game: RogueJack: Roguelike Blackjack

-- MAIN APPLICATION
addappid(1302440)
-- Game: addappid(1302440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302441, 1, "ddce3ed9a111d94fbcff502d90c75a4cf4274156a2884dcf9b85573414553e34")
