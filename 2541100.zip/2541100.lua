-- Lua provided by RyzenAPI
-- Game: addappid(2541100)

-- MAIN APPLICATION
addappid(2541100)
addappid(2542180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541101, 1, "642449b507293d2df72087f049c3e1a81a12675a14dacf68c47285c3f04a10d0")
