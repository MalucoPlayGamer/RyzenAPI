-- Lua provided by RyzenAPI
-- Game: Loot Run

-- MAIN APPLICATION
addappid(733570)

-- MAIN APP DEPOTS / PACKAGES
addappid(733571, 1, "045ba22a3f706a54309bcba25269810b559a514901608d6826e8a40aec1b67ef")
