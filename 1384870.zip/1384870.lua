-- Lua provided by SkyAPI 
-- Game: Drifters Loot the Galaxy - Beta
addappid(1384870)
addappid(1384871, 1, "7d0b49281f72fb2153ba302d36e2500beb92fb11f46b08c2c07fff0f67fe88b3")
