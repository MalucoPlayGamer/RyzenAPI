-- Lua provided by RyzenAPI
-- Game: Game: Drifters Loot the Galaxy - Beta

-- MAIN APPLICATION
addappid(1384870)
-- Game: addappid(1384870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384871, 1, "7d0b49281f72fb2153ba302d36e2500beb92fb11f46b08c2c07fff0f67fe88b3")
