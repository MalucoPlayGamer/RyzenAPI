-- Lua provided by RyzenAPI
-- Game: Legends Demo

-- MAIN APPLICATION
addappid(2567250)
-- Game: addappid(2567250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567251, 1, "c1408761b118bba9414d741224553e67655846a224c0540867c119975cbc54a8")
