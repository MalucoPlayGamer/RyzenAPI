-- Lua provided by RyzenAPI
-- Game: Ryte: The Eye Of Atlantis

-- MAIN APPLICATION
addappid(855390)

-- MAIN APP DEPOTS / PACKAGES
addappid(855391,0,"b7de86ca1a6801fab80c4a408a4c894a573b79e86ad67b1bafd6c66170ec1c44")

