-- Lua provided by RyzenAPI 
-- Game: Keep It Lit
addappid(3483270)
addappid(3483271, 1, "725f4eb4fd9f9e17087f7a11d2f1c1b08be6759dcadca294d3cc54006c8e8e3c")
addappid(3483272, 1, "5ff2dc90243a8f6a32419fdf7c601ed94968ddfc929ce3febb59398b0bd16151")
addappid(3483273, 1, "6a08da961c652436bc7b397515e9549279183ab8fcc29207b16f8570050dcc21")
addappid(3567110)
