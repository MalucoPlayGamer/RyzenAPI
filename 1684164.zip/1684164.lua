-- Lua provided by RyzenAPI
-- Game: addappid(1684164)

-- MAIN APPLICATION
addappid(1684164)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684164,0,"83253e1bd3bbd6959be5c0acf0b4b3c800c85b80bd73f5b902215b5042a4ecee")
