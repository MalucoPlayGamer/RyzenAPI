-- Lua provided by RyzenAPI
-- Game: Chubby Cats

-- MAIN APPLICATION
addappid(3588660)
-- Game: addappid(3588660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3588662,0,"feae275dbd84c16447b613cbb178af6eefe9a96532545225c2183a7b7d3ea1a7")
