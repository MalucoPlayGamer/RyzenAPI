-- Lua provided by RyzenAPI
-- Game: Game: AppID 530820

-- MAIN APPLICATION
addappid(530820)
-- Game: addappid(530820)

-- MAIN APP DEPOTS / PACKAGES
addappid(530821, 1, "20566aa8319dc21960abcd6e5305186c61adf6417b9b08806419f4266193b230")
