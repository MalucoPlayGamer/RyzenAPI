-- Lua provided by RyzenAPI
-- Game: addappid(2485430)

-- MAIN APPLICATION
addappid(2485430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485431, 1, "f7ab3dac04877e10e656b6e5114a7dce37213f95ad80741f46d2b10513e0b74b")
