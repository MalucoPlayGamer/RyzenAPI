-- Lua provided by RyzenAPI
-- Game: addappid(1181774)

-- MAIN APPLICATION
addappid(1181774)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181774,0,"cddb39d5e07ec2b224cb225ae5b5a3d531d23d146637185ea9e1a208b517395d")
