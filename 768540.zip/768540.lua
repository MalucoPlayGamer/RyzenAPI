-- Lua provided by RyzenAPI
-- Game: Dinosaurs Prehistoric Survivors

-- MAIN APPLICATION
addappid(768540)

-- MAIN APP DEPOTS / PACKAGES
addappid(768541, 1, "8dd5697c0cd86bba32ce9b03ccd7c62bdf65fffdd2a9e9df4f2d9f69781294f6")
