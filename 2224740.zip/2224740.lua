-- Lua provided by RyzenAPI
-- Game: DreamWorks All-Star Kart Racing

-- MAIN APPLICATION
addappid(2224740)
addappid(2518390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2224741, 1, "f406519329155b7eef28b776311e4162923233f07b2c0955cf5c5322bc007c1f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
