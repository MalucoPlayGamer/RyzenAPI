-- Lua provided by SkyAPI 
-- Game: Midnight Caravan
addappid(849140)
addappid(849141, 1, "a2237f90848ccdee44736b2e373c8d7add86f30733f9ed8c3a9a6f00f8038add")
