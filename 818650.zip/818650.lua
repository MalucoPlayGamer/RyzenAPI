-- Lua provided by RyzenAPI
-- Game: Evil Cogs

-- MAIN APPLICATION
addappid(818650)

-- MAIN APP DEPOTS / PACKAGES
addappid(818651,0,"f3b0f767d33afadb2afcaf8d7ed6a3b50e345949d3f4fdc71d3b786e61bc5834")

