-- Lua provided by RyzenAPI
-- Game: Rise Of A Hero

-- MAIN APPLICATION
addappid(2122010)
addappid(3326240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2122011, 1, "8aff9d96f9bf99a5787b9543383493263aec46a3e65c5a9cef984b53a7d36c9c")

