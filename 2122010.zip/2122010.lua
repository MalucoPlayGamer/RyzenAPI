-- Lua provided by RyzenAPI
-- Game: Rise Of A Hero

-- MAIN APPLICATION
addappid(2122010)
-- Game: addappid(2122010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122011, 1, "8aff9d96f9bf99a5787b9543383493263aec46a3e65c5a9cef984b53a7d36c9c")
