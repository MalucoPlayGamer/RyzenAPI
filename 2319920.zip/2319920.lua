-- Lua provided by RyzenAPI
-- Game: setManifestid(2319925,"8808144161705791463")

-- MAIN APPLICATION
addappid(2319920)
-- Game: addappid(2319920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319925,0,"c1afa07ab9a901d3abdf045af8fce845b279697c73f827195c37a5051ef5b72b")
