-- Lua provided by RyzenAPI 
-- Game: AppID 605510
addappid(605510)
addappid(605511, 1, "3f6429c53bf5fca21ca14a21e90eda20b7de185b9e5da0ff7166a429317d37f5")
