-- Lua provided by RyzenAPI
-- Game: addappid(605510)

-- MAIN APPLICATION
addappid(605510)

-- MAIN APP DEPOTS / PACKAGES
addappid(605511, 1, "3f6429c53bf5fca21ca14a21e90eda20b7de185b9e5da0ff7166a429317d37f5")
