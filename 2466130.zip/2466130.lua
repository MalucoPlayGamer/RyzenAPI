-- Lua provided by RyzenAPI
-- Game: Bonnie Bear Saves Frogtime

-- MAIN APPLICATION
addappid(2466130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466131,0,"c46049fa8f930379ce0fc457bd54ae37eea14152bc0c545f21760eac45f75b72")

