-- Lua provided by RyzenAPI
-- Game: What is in the Black Box?

-- MAIN APPLICATION
addappid(3226720)
-- Game: addappid(3226720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226721, 1, "5c2eb5f45bdf40ee16aa0e3c51e0d55a48e1727710f4e7f495a0e72e1e548356")
