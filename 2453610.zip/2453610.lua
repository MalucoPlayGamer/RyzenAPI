-- Lua provided by RyzenAPI
-- Game: addappid(2453610)

-- MAIN APPLICATION
addappid(2453610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453611, 1, "1d9ef26f27e93e0c8d38abf685a9c354625f81fc6bcae79d9383b35b2346c7cb")
