-- Lua provided by RyzenAPI
-- Game: Super Volley Blast

-- MAIN APPLICATION
addappid(822040)

-- MAIN APP DEPOTS / PACKAGES
addappid(822041, 1, "a03febe1b450186f006b2e9a721bfd16b10ba13c40350638b84ce37832f9f7c8")

