-- Lua provided by RyzenAPI
-- Game: addappid(1099562)

-- MAIN APPLICATION
addappid(1099562)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099562,0,"7bf1ce2aebe26324990ba096700ae2c0d7acf5e51e8e4e238d9488b148cdd99c")
