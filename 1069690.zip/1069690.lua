-- Lua provided by RyzenAPI
-- Game: Rogue Lords

-- MAIN APPLICATION
addappid(1069690)
addappid(1556061)
addappid(1556062)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1069691, 1, "b0b62c3ca8b5fdeae36530e7baa52e37ed21aee3ba813044d12e4458ff5c4240")

