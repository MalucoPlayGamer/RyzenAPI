-- Lua provided by RyzenAPI
-- Game: Push Blox 2

-- MAIN APPLICATION
addappid(894430)

-- MAIN APP DEPOTS / PACKAGES
addappid(894431, 1, "fd3cdbd3b7a84a23232189839cb85b05cee55909d8008894e2ed5982c6a51967")
addappid(894432, 1, "98ae73ee8b4a3c84cb4c53ea0700ca62b47310b75cc1b394870c5e7eac7d18f2")
