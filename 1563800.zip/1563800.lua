-- Lua provided by RyzenAPI
-- Game: AppID 1563800

-- MAIN APPLICATION
addappid(1563800)
-- Game: addappid(1563800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563801, 1, "b9c63dca439ab1315ff36e2846b6ecd3cbe3981dccedc6a65721b428b585bb64")
