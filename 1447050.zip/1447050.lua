-- Lua provided by RyzenAPI
-- Game: Game: Enoki

-- MAIN APPLICATION
addappid(1447050)
-- Game: addappid(1447050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447051, 1, "e274d0ca59ab7c7318334472165221699c422dc1d1f344b9a4b9a51d8dcd3b99")
