-- Lua provided by RyzenAPI
-- Game: Old School RuneScape

-- MAIN APPLICATION
addappid(1343370)
addappid(1401460)
addappid(1401461)
addappid(1401462)
addappid(1474630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1343371, 1, "cacd3ac83c57cc56f952845b5044580599d8a268f8bbb3d3c72378bddb6e6f17")
addappid(1343374, 1, "0feff1a3db1ad149ffb7b2514437b4680dab11da7ba2898c1ed65afd5532365e")

