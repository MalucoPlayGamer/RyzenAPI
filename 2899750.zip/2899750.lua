-- Lua provided by SkyAPI 
-- Game: My Boyfriend is a Martian👰❤️👽
addappid(2899750)
addappid(2899751, 1, "00596dd061bbb9ce53a009bd4bae808c08ce7e6ab4633b5a88c45843ff893883")
