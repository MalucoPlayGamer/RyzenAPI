-- Lua provided by RyzenAPI
-- Game: My Boyfriend is a Martian👰❤️👽

-- MAIN APPLICATION
addappid(2899750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899751, 1, "00596dd061bbb9ce53a009bd4bae808c08ce7e6ab4633b5a88c45843ff893883")
