-- Lua provided by RyzenAPI
-- Game: Deathground

-- MAIN APPLICATION
addappid(1200770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200771, 1, "e5765b9e9753b6845acf30d81995371d101ac52f412ad63148fbce1a52057fa2")
