-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VIII - REMASTERED

-- MAIN APPLICATION
addappid(1026680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026681, 1, "2a49f44a8153e4e505ded49c5844e54320aa082a9a1812f987644e6dac5863f2")
addappid(1152240, 0, "85f2fe46d3930f2ec95b072cdfd11ede2ba8e33bd11fa8e8dc2836db2a880073")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
