-- Lua provided by RyzenAPI
-- Game: Road 96 Demo

-- MAIN APPLICATION
addappid(1597690)
-- Game: addappid(1597690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597691, 1, "11dad913601fd92dfd2d05e357818bb1065ec687028540d5021b2f6e01dbb996")
