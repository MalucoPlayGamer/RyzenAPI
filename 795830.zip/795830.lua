-- Lua provided by RyzenAPI
-- Game: 795830

-- MAIN APPLICATION
addappid(795830)
-- Game: addappid(795830)

-- MAIN APP DEPOTS / PACKAGES
addappid(795831, 1, "20e5cbbd65ada0dbc2dc330ff15e973cdadd859ce8a0e43a9ee40b6c9efbfa6b")
addappid(795832, 1, "92785b75879dda8fa01cb317ca089bd4bed6cd7f179ea24c4187ca88726ce3af")
addappid(795833, 1, "2cd46a278aac3b6e0ee21fcfc4b42a1ef93e6a393d7bb8d8808da55a2c86d960")
