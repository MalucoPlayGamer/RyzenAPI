-- Lua provided by RyzenAPI
-- Game: Game: Transporter

-- MAIN APPLICATION
addappid(2614550)
-- Game: addappid(2614550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614551, 1, "88705157eb12fcc1b60eaae0e66850987e52e2a2a1025dfa86e397f78ba26bc7")
