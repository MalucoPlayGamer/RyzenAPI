-- Lua provided by RyzenAPI
-- Game: Futanari Sex - BDSM Room

-- MAIN APPLICATION
addappid(1990190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990191, 1, "aa42f39fded637a2f3601f30a675dad61bae4ec0da48bbd2edd95f6a7705ad54")

