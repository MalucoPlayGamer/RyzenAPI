-- Lua provided by RyzenAPI
-- Game: Transliminal: Beyond The Backrooms

-- MAIN APPLICATION
addappid(2176070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176071, 1, "7105bcc02d5c97c50d6f9a81889421e8651154676eb79f8e1c6f4760ab45b952")

