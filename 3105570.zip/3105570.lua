-- Lua provided by RyzenAPI
-- Game: Game: 👑选王之剑：零 Demo💕（Idle Calibur：Zero）

-- MAIN APPLICATION
addappid(3105570)
-- Game: addappid(3105570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3105571, 1, "c0cde43b6f5b0eebae14e79419c43cee43bcb474029b486e5d14bb22df140cac")
