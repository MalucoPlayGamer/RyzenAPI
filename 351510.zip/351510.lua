-- Lua provided by RyzenAPI
-- Game: Quiplash

-- MAIN APPLICATION
addappid(351510)

-- MAIN APP DEPOTS / PACKAGES
addappid(351511, 1, "26c2ce0cee796869f982e6979cda4fad4271f3251e7bba2f1da90d6c349a9f68")
addappid(351512, 1, "f9d6ed0e02ec0d899329ec06496f7e80e322660ceeab7b36103c6ea40171af0b")
addappid(351513, 1, "ca0f19e3b488816b8a54383c73d665e7b6ee492d07c27e188fb066a9445001bd")
addappid(351514, 1, "918b324b0b83085872b50eac31d7e02dbb52bcda6ff07d5a6595ebb623493032")
addappid(351515, 1, "f1375521718da64dba2e3ef41a6476e45158ac479c6028e305939d3575586a78")
addappid(359570, 0, "5286b571639d80955b08c623b3c14ae581852f1e8a8352f5f3cc2d4b3094d69c")
addappid(2828508, 1, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
