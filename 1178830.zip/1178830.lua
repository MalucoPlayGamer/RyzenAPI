-- Lua provided by RyzenAPI
-- Game: 1178830

-- MAIN APPLICATION
addappid(1178830)
-- Game: addappid(1178830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554699,0,"bf04ebda1d1572665a129889cd9333e1f272a3fb37c2eb8cc58fe6dab1a08f7b")
