-- Lua provided by RyzenAPI
-- Game: SOK PRO

-- MAIN APPLICATION
addappid(1399300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399301, 1, "063ea1ee10ae431eb4072a0725002e53b76e9e996176f285048568cd90c2dc67")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1404640)
addappid(1404641)
addappid(1407710)
addappid(1507470)
