-- Lua provided by RyzenAPI
-- Game: Bitcoin Trader

-- MAIN APPLICATION
addappid(837900)
addappid(856630)

-- MAIN APP DEPOTS / PACKAGES
addappid(837901,0,"6f5289ef6ddb52bc94096aa21ba040acf269efbfe051044b76e788e753a4695e")
addappid(856630,0,"0965c1c18cd64566b71ad0c7be8b9957bc2cc97c0d5e1a26b3c6ff772462ed08")

