-- Lua provided by RyzenAPI
-- Game: Game: AppID 837900

-- MAIN APPLICATION
addappid(837900)
-- Game: addappid(837900)

-- MAIN APP DEPOTS / PACKAGES
addappid(837901, 1, "6f5289ef6ddb52bc94096aa21ba040acf269efbfe051044b76e788e753a4695e")
