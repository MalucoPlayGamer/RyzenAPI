-- Lua provided by RyzenAPI
-- Game: 中国足球模拟器

-- MAIN APPLICATION
addappid(3304320)
addappid(4012700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3304320,0,"489df7bd84d502fd2966bb836aa94d7dd8c542ea80fcfc3709c1c4b879585d9d")
addappid(3304321,0,"27cbbb192ac92d805e680435d0ad958abd9735478520a56476b3d855d9456c5d")

