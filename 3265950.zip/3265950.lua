-- Lua provided by SkyAPI 
-- Game: AppID 3265950
addappid(3265950)
addappid(3265951, 1, "c13f0e7d1168476027289425dccb87abf9825f8e5601c4675c59add3084ce6c2")
