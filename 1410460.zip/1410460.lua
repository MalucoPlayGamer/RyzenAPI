-- Lua provided by RyzenAPI
-- Game: 1410460

-- MAIN APPLICATION
addappid(1410460)
-- Game: addappid(1410460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410461, 1, "e75213e1750a8f4a3c89b56955fb87cd23b71b679da8501eb54a22dbab04e9d4")
