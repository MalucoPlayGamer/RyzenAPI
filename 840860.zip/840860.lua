-- Lua provided by RyzenAPI
-- Game: I Pay No Rent

-- MAIN APPLICATION
addappid(840860)

-- MAIN APP DEPOTS / PACKAGES
addappid(840861,0,"eef5b6c29bddd97fae9982cb9493486c3d1961cfd746ff334e7307291f710a57")

