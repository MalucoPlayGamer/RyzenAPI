-- Lua provided by RyzenAPI
-- Game: Akatori: Сhapter One

-- MAIN APPLICATION
addappid(2524680)
-- Game: addappid(2524680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524681, 1, "75f2ffa2aeb2119aa6cfa2b0c741c4705e768a5a976d7cb83674afaa587c0744")
