-- Lua provided by RyzenAPI 
-- Game: AppID 1684820
addappid(1684820)
addappid(1684821, 1, "40082e8a394cec10e720dcaff5ed8e8a9777c01d547532a6a5c9d462dc937e61")
