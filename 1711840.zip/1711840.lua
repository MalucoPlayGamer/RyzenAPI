-- Lua provided by SkyAPI 
-- Game: Ninja Stealth 4
addappid(1711840)
addappid(1711841, 1, "023f794bc733025be51141779c886eae72f70d3fa648dee20fbd71b4d55761a9")
addappid(1711842, 1, "62243f84275d3f1572ee2f006905e4fd9ef67822777afe0634424270379b43f1")
