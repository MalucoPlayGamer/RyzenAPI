-- Lua provided by RyzenAPI
-- Game: Illusion 幻覚

-- MAIN APPLICATION
addappid(2005320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005321, 1, "4c87e9894343067fdcb23baec00d508ca1c7276d4abb5050c5bc7f8d425558d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
