-- Lua provided by RyzenAPI
-- Game: Illusion 幻覚

-- MAIN APPLICATION
addappid(2005320)
-- Game: addappid(2005320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005321, 1, "4c87e9894343067fdcb23baec00d508ca1c7276d4abb5050c5bc7f8d425558d6")
