-- Lua provided by RyzenAPI
-- Game: Wasting Away

-- MAIN APPLICATION
addappid(1409560)
-- Game: addappid(1409560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409561, 1, "c5ba9336d7adb7badb36ab560987fd47ce4eeb721f28b526c8c72965ee267475")
