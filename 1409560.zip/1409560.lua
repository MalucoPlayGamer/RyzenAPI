-- Lua provided by RyzenAPI
-- Game: Wasting Away

-- MAIN APPLICATION
addappid(1409560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409561, 1, "c5ba9336d7adb7badb36ab560987fd47ce4eeb721f28b526c8c72965ee267475")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
