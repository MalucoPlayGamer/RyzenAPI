-- Lua provided by RyzenAPI
-- Game: 落日山丘 Demo

-- MAIN APPLICATION
addappid(2057440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057441, 1, "e1985921bbc302d8c5499ea578eb0b428b0fe11e9831d06a007b8564531be608")
