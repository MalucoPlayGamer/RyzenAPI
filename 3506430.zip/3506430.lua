-- Lua provided by SkyAPI 
-- Game: Peak
addappid(3506430)
addappid(3506431, 1, "69da36b0d72b84caed88c36ce4770b1f85e1d7d0d2d5b44ad838eaa453fdff13")
