-- Lua provided by RyzenAPI
-- Game: 3506430

-- MAIN APPLICATION
addappid(3506430)
-- Game: addappid(3506430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3506431, 1, "69da36b0d72b84caed88c36ce4770b1f85e1d7d0d2d5b44ad838eaa453fdff13")
