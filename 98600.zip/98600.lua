-- Lua provided by RyzenAPI
-- Game: Demolition Inc.

-- MAIN APPLICATION
addappid(98600)
addappid(98609)

-- MAIN APP DEPOTS / PACKAGES
addappid(98601, 1, "01af06b05969ffdf63a968410784055a25bf641a66a687eccb90642f4d019eb3")
addappid(98602, 1, "c40d6c950696fd8561b96f84ddb4fad56f29739c923f2fac77a674801825e2e4")
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

