-- Lua provided by RyzenAPI
-- Game: 2010790

-- MAIN APPLICATION
addappid(2010790)
-- Game: addappid(2010790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010791, 1, "66cb2d4fbdeaf5a7e43f74fad1c67e2cf77211d65273da327682e025f694c064")
