-- 2430310's Lua and Manifest Created by Hubcap Manifest
-- Mighty Marbles
-- Created: August 09, 2026 at 01:52:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2430310) -- Mighty Marbles
-- MAIN APP DEPOTS
addappid(2430312, 1, "9764c5cd550a411d95a7505e901691e74ebb5273441794290ca3c3c08b7ee749") -- Depot 2430312
setManifestid(2430312, "7614135400864745841", 1428272689)