-- Lua provided by RyzenAPI
-- Game: Mighty Marbles

-- MAIN APPLICATION
addappid(2430310) -- Mighty Marbles

-- MAIN APP DEPOTS / PACKAGES
addappid(2430312, 1, "9764c5cd550a411d95a7505e901691e74ebb5273441794290ca3c3c08b7ee749") -- Depot 2430312

