-- Lua provided by RyzenAPI
-- Game: Game: Drink More Glurp

-- MAIN APPLICATION
addappid(1056690)
-- Game: addappid(1056690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056691, 1, "1f9981aaa7daa4018070b6713c0d0dcac106705301af0f9410b72b8c8c729106")
addappid(1056692, 1, "8dc90c0803467004fa877725104d942353f6753245070b42594fb8ee4d9ff127")
addappid(1056693, 1, "5af022c95f537febb2f9b0add6b65b114ce03214c0eed7bf8aeb647959f1eed1")
