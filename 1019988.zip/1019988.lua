-- Lua provided by RyzenAPI
-- Game: 1019988

-- MAIN APPLICATION
addappid(1019988)
-- Game: addappid(1019988)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019988,0,"6076c1eb38ac9e09581243f8b2afb0856efe465e153178e6524d1e4ebb3e0d62")
