-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Xin Xianying "Knight Costume" / 辛憲英「騎士風コスチューム」

-- MAIN APPLICATION
addappid(1019988)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019988,0,"6076c1eb38ac9e09581243f8b2afb0856efe465e153178e6524d1e4ebb3e0d62")
