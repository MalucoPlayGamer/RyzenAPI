-- Lua provided by SkyAPI 
-- Game: AppID 521620
addappid(521620)
addappid(521621, 1, "36e28983708473ea6644a4752d4960ecff93966cdb8356ac3ea02d5f30f9d3ca")
