-- Lua provided by RyzenAPI
-- Game: Magic Construct

-- MAIN APPLICATION
addappid(3176980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176981, 1, "d27d89ebe68c00f5e5a01e58ab09f5b944f200b27011bbc945ac8f2a2e09b91a")
