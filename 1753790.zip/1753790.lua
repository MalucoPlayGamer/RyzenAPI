-- Lua provided by RyzenAPI
-- Game: She Will Shoot

-- MAIN APPLICATION
addappid(1753790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1753791, 1, "d88d43e224731319693048f0cf5810a45162a87e9d1276a9eeb1103266fc8df1")

