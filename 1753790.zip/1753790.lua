-- Lua provided by RyzenAPI
-- Game: She Will Shoot

-- MAIN APPLICATION
addappid(1753790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753791, 1, "d88d43e224731319693048f0cf5810a45162a87e9d1276a9eeb1103266fc8df1")

