-- Lua provided by RyzenAPI
-- Game: addappid(835710)

-- MAIN APPLICATION
addappid(835710)

-- MAIN APP DEPOTS / PACKAGES
addappid(835711, 1, "e2339cdddada5f158c303fdb64c23aae34be32ebfe96fd47b318af228de0d7cc")
