-- Lua provided by RyzenAPI
-- Game: OBS Studio

-- MAIN APPLICATION
addappid(1905180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905181, 1, "9893ce20679d91040e3ac618d31a5de675e18fa1462dd41962812a2a18b4c2ca")
addappid(1905182, 1, "57c87ca72a249265959763d8e435e45d4ac968d958c98b7f6ffb5a78e1ab8d9d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
