-- Lua provided by RyzenAPI
-- Game: Greenwood the Last Ritual

-- MAIN APPLICATION
addappid(536410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(536411, 1, "8eb7621cfb72eb88219b47cd356062accdcc0cfe9ec2821c05ec8108c3be8ac5")
addappid(536412, 1, "410e165d9f8a595208655fb49d414f98fe0efd55f6f42852039c7222549c2b61")
addappid(536413, 1, "a3d32f1ee170d325255a665f8f7e0ca750d5864c6ab4aa6eb435df469a298929")
addappid(536414, 1, "7b1f1165c944bfd29f3b4b80284bdbe802a603e76b7819a3d889cdead0f2b7b0")

