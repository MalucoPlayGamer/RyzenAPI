-- Lua provided by RyzenAPI
-- Game: AppID 3005670

-- MAIN APPLICATION
addappid(3005670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3005671, 1, "f0ebff44dbf053c04502a8dd1944d741aab95daee3e96822c63c5d021965be69")
