-- Lua provided by RyzenAPI
-- Game: addappid(1006170)

-- MAIN APPLICATION
addappid(1006170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006171, 1, "9006eabfc4f23d8ce394a734f83c27b21ff392129288a988ca89e21b360126a4")
