-- Lua provided by RyzenAPI
-- Game: Sovietpunk: Chapter one

-- MAIN APPLICATION
addappid(1534550)
-- Game: addappid(1534550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534551, 1, "f7dac57151da7db354dc5aaa357450761d624bc622a1ecf8080e4009d0418a44")
