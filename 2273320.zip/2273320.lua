-- Lua provided by RyzenAPI
-- Game: Gal Guardians: Demon Purge Demo

-- MAIN APPLICATION
addappid(2273320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273321, 1, "0d5372881909d71567f707007da83ff49ab7cb6091ac42249cce2a4bbfaa293c")
