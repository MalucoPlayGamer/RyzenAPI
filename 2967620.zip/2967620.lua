-- Lua provided by RyzenAPI
-- Game: Gatekeeper - Supporter Pack

-- MAIN APPLICATION
addappid(2967620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967620,0,"51627f4bbb1aacbdae1721d28a86576389b54b4953819b8347387cb000877884")

