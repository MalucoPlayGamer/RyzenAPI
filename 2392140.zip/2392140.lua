-- Lua provided by RyzenAPI
-- Game: 2392140

-- MAIN APPLICATION
addappid(2392140)
addappid(2434430)
-- Game: addappid(2392140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392141, 1, "a4820f63957a6df5bdac59af8df8da2c8f1a9afea80b7c272ef0590e2b685e2d")
