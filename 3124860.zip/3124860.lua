-- Lua provided by SkyAPI 
-- Game: Lunara: Planet IX
addappid(3124860)
addappid(3124861, 1, "7365831bae8193dec0612a9954594c155806ade8a73832e119ad120823d8d6c9")
