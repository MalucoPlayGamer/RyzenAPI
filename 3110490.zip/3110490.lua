-- Lua provided by RyzenAPI
-- Game: Pixel Restorer

-- MAIN APPLICATION
addappid(3110490)
