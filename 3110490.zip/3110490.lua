-- Lua provided by RyzenAPI
-- Game: Pixel Restorer

-- MAIN APPLICATION
addappid(3110490)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3215930)
addappid(3215940)
addappid(3215950)
addappid(3215960)
addappid(3215970)
addappid(3215980)
addappid(3215990)
addappid(3329750)
addappid(3329760)
addappid(3329770)
addappid(3329780)
addappid(3329790)
addappid(3329800)
addappid(3329810)
addappid(3329870)
addappid(3329880)
addappid(3329890)
addappid(3329900)
addappid(3329910)
addappid(3329920)
addappid(3329930)
addappid(3329940)
addappid(3329950)
addappid(3329960)
