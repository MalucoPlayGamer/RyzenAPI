-- Lua provided by RyzenAPI 
-- Game: ISLAND 404
addappid(993330)
addappid(993331, 1, "b0aef96c72f71663c4c7d77fba0fb19e9e468993fa182d2fb8171cffc1e6925d")
