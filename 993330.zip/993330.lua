-- Lua provided by RyzenAPI
-- Game: Game: ISLAND 404

-- MAIN APPLICATION
addappid(993330)
-- Game: addappid(993330)

-- MAIN APP DEPOTS / PACKAGES
addappid(993331, 1, "b0aef96c72f71663c4c7d77fba0fb19e9e468993fa182d2fb8171cffc1e6925d")
