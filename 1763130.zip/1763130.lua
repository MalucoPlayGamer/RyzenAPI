-- Lua provided by RyzenAPI
-- Game: Game: AppID 1763130

-- MAIN APPLICATION
addappid(1763130)
-- Game: addappid(1763130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763131, 1, "e85af729b914493507850ab42500be321de6abbfdfd6279945fa40f608d22810")
addappid(1763132, 1, "80c186fc16bda36aed33b2a18a2f1ed4bf38c50dc69ff6a1ea8a4d731298f1b0")
addappid(1763136, 1, "a2bea875c0d40a750492ae56d8cefcaa5fe94854ac3302097b5bf91a9261f90e")
