-- Lua provided by RyzenAPI
-- Game: Who Takes The Crown?

-- MAIN APPLICATION
addappid(2550290)
-- Game: addappid(2550290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550291, 1, "4e280bcd961fcdd3577bc2638622f3c9c4a0bd52a4c3c054734c4a0ae3658f33")
