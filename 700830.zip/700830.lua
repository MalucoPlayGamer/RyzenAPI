-- Lua provided by RyzenAPI 
-- Game: AppID 700830
addappid(700830)
addappid(700831, 1, "b2f1936d4035c20ae22871c7880d116535b286956e515a7522288448449b2819")
