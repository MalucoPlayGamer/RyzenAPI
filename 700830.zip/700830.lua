-- Lua provided by RyzenAPI
-- Game: AppID 700830

-- MAIN APPLICATION
addappid(700830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(700831, 1, "b2f1936d4035c20ae22871c7880d116535b286956e515a7522288448449b2819")

