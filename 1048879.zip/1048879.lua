-- Lua provided by RyzenAPI
-- Game: 1048879

-- MAIN APPLICATION
addappid(1048879)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048879,0,"bd8eeea3496e9df99455fbd5ef8685e0b12aad5a9be99aefe25043808463164d")
