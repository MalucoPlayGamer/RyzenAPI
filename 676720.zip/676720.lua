-- Lua provided by RyzenAPI
-- Game: Game: Bug Killers

-- MAIN APPLICATION
addappid(676720)
-- Game: addappid(676720)

-- MAIN APP DEPOTS / PACKAGES
addappid(676721, 1, "786369e0e1d9b7fb9697e203c64f210b17f1f4001a52bcb8406d7e211d485013")
addappid(676722, 1, "a8e755f63ad0f6a18e03adbfa5b739da7436e71043d3a93c01213b2bdab8331f")
addappid(676723, 1, "776080a04ab8aee4619d6ff3eeb95ed335735a9279e1598173c8f3545302f624")
