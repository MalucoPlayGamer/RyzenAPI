-- Lua provided by RyzenAPI
-- Game: High On Life

-- MAIN APPLICATION
addappid(1583230)
addappid(2447000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1583231, 1, "a1246164a71713be03e1d57a313af03ac5bbde4a6a16962178bce5f74be271e4")

