-- Lua provided by RyzenAPI
-- Game: High On Life

-- MAIN APPLICATION
addappid(1583230)
addappid(2447000)
-- Game: addappid(1583230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583231, 1, "a1246164a71713be03e1d57a313af03ac5bbde4a6a16962178bce5f74be271e4")
