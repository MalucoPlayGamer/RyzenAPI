-- Lua provided by RyzenAPI 
-- Game: AppID 1011030
addappid(1011030)
addappid(1011031, 1, "30906a51870de7e11d394c65a5a4bef444e6e4b63e82d40b76dd0574cb39bbe6")
addappid(1035580, 0, "7948b871fc4ac8d379897f4dd1c4f22b7280ab26b53e5007fa0d09328d2a57ba")
