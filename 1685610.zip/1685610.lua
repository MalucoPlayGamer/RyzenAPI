-- Lua provided by RyzenAPI
-- Game: Jigsaw Frame: Relax

-- MAIN APPLICATION
addappid(1685610)
-- Game: addappid(1685610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685611, 1, "7751fbc6c33438fe73c41847839a5db66108422a37c2d6dea86da9dba945cdac")
