-- Lua provided by SkyAPI 
-- Game: Jigsaw Frame: Relax
addappid(1685610)
addappid(1685611, 1, "7751fbc6c33438fe73c41847839a5db66108422a37c2d6dea86da9dba945cdac")
