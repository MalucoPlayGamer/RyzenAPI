-- Lua provided by RyzenAPI
-- Game: DeeperRed2028-WeAreEscape-

-- MAIN APPLICATION
addappid(1215120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215121, 1, "cf8b6f9e118d859a53c9dd4b88030e670437c98d73f216fe68cad0fcdf7c6bae")
