-- Lua provided by RyzenAPI
-- Game: 240580

-- MAIN APPLICATION
addappid(240580)
-- Game: addappid(240580)

-- MAIN APP DEPOTS / PACKAGES
addappid(240581, 1, "627b128b2c3dc6950ddc2b6a415100c5a73cd4657964e906e6ffbf4aa625db8f")
