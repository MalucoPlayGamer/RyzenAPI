-- Lua provided by RyzenAPI
-- Game: 1804610

-- MAIN APPLICATION
addappid(1804610)
-- Game: addappid(1804610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804611, 1, "32d6abd1e8649cd80efd4a6b27c0ba268363f0eaeabab9d0aa55aa76be48950a")
