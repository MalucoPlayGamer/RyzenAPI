-- Lua provided by SkyAPI 
-- Game: Recollection
addappid(1804610)
addappid(1804611, 1, "32d6abd1e8649cd80efd4a6b27c0ba268363f0eaeabab9d0aa55aa76be48950a")
