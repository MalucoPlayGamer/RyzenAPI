-- Lua provided by RyzenAPI 
-- Game: 99 Waves
addappid(2773640)
addappid(2773641, 1, "6af5f50055a793f5cf68ef6c0a1494ab16b0c3698379907c3d50186738e5175c")
