-- Lua provided by RyzenAPI
-- Game: addappid(3034380)

-- MAIN APPLICATION
addappid(3034380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034381, 1, "68bc533596c9c1e4c177d7c89d6ebc1afa0c5de995b8fc6f0834c5ebc72d5291")
