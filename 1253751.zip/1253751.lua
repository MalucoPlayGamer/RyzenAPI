-- Lua provided by RyzenAPI
-- Game: 1253751

-- MAIN APPLICATION
addappid(1253751)
-- Game: addappid(1253751)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253751,0,"ae9b1e768ab1ec68b9b6f0c820f73e9b798122407f0991919f4d87f9d07a25d1")
