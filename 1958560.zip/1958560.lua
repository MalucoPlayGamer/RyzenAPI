-- Lua provided by RyzenAPI
-- Game: addappid(1958560)

-- MAIN APPLICATION
addappid(1958560)
addappid(1958561)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958562,0,"202498ce0ad778a6bb1d7d6796f66526abd8108b453f6fe8f3a75fe97b64de3b")
