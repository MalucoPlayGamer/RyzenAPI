-- Lua provided by RyzenAPI
-- Game: addappid(503450)

-- MAIN APPLICATION
addappid(503450)

-- MAIN APP DEPOTS / PACKAGES
addappid(503451, 1, "8ffb455edce985f9855201cf681b627d5864c0906952529988fca8604b34eabc")
