-- Lua provided by RyzenAPI
-- Game: Space Rangers: Quest

-- MAIN APPLICATION
addappid(503450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(503451, 1, "8ffb455edce985f9855201cf681b627d5864c0906952529988fca8604b34eabc")

