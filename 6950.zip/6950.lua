-- Lua provided by RyzenAPI
-- Game: Hitman Blood Money Demo

-- MAIN APPLICATION
addappid(6950)

-- MAIN APP DEPOTS / PACKAGES
addappid(6951, 1, "7656e0710996b2c79f74042c4d617c4fe8ba93f0520fb36893f37918281ef73d")
