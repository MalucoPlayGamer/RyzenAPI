-- Lua provided by RyzenAPI
-- Game: addappid(3760260)

-- MAIN APPLICATION
addappid(3760260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3760261, 1, "3cc2d16595bd7bde9f5b3223babec96864447551dd1ee65c0d4dfd2b39bb2e71")
addappid(3760262, 1, "087283dde2136da75d061dc624f607da956e3632d8048faf4aa134e275a46f8b")
