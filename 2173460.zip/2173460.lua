-- Lua provided by RyzenAPI
-- Game: addappid(2173460)

-- MAIN APPLICATION
addappid(2173460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173463,0,"12c1c726e7809567efad86b441ad93c58f64a159ecfb67748f301f11b29a00f2")
