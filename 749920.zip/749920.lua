-- Lua provided by RyzenAPI
-- Game: addappid(749920)

-- MAIN APPLICATION
addappid(749920)

-- MAIN APP DEPOTS / PACKAGES
addappid(749921, 1, "3e48792cd9b1ec17f99e4085624904c17f285215d087feaa3541e277cbfc1f01")
