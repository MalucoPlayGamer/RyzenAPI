-- Lua provided by RyzenAPI
-- Game: Scamper

-- MAIN APPLICATION
addappid(2481930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481931, 1, "636e938dd4f44d714e3841a958c52141d1f3b6574139e9a7bb82728dde9bded9")

