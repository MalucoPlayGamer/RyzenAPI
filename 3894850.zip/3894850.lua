-- 3894850's Lua and Manifest Created by Hubcap Manifest
-- Nothing To Declare
-- Created: July 25, 2026 at 12:25:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3894850) -- Nothing To Declare
-- MAIN APP DEPOTS
addappid(3894851, 1, "21b002d1c6681f6e2c0eb05344ba13d3c0fddb54e97476318d0820dc84e23198") -- Depot 3894851
setManifestid(3894851, "6419645411460227001", 4552462608)
addappid(3894852, 1, "6c1fb3c8ec7f13fcf377cb5c2d2c0941eaca44c91447586bd8ce130c6217a78b") -- Depot 3894852
setManifestid(3894852, "6621626219277249290", 4568763104)
addappid(3894853, 1, "bc9c054629b553dffd5fb17ca45031762693ce7d638c266c3a0ebf7bb1d3d626") -- Depot 3894853
setManifestid(3894853, "9158106475548667086", 4548471164)