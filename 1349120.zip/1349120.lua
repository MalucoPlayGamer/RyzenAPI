-- Lua provided by RyzenAPI
-- Game: 球球少女/Pinball Girls

-- MAIN APPLICATION
addappid(1349120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349121, 1, "0ffdfb4f70eec018125a9161d471fad79743d22ea5a3797c5a01eeb3a0e81cda")
addappid(1424950, 0, "5318f3d6e4c8c314a646acfe321f57aaf926e231ae2e4e38ed730d91b00e01f6")
addappid(1431392, 0, "07ebbf5dd7acc0cbfa7057e81c825e9da51d4bd252275d1e7599f4c9aae068e6")

