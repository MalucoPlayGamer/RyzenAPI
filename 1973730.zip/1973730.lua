-- Lua provided by RyzenAPI
-- Game: addappid(1973730)

-- MAIN APPLICATION
addappid(228989)
addappid(1973730)
addappid(1973731)
addappid(1973733)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973732,0,"9c354b87420da0327703f9ab63507b9263ad8f81055693607ce74dd4908d2d69")
