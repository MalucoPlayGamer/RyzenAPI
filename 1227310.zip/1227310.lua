-- Lua provided by RyzenAPI
-- Game: addappid(1227310)

-- MAIN APPLICATION
addappid(1227310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227311, 1, "355ecb04c96158a03c68c5dfce7cc838b47d83e12f93c8dd531116abcfbfc4c8")
