-- Lua provided by SkyAPI 
-- Game: AppID 1227310
addappid(1227310)
addappid(1227311, 1, "355ecb04c96158a03c68c5dfce7cc838b47d83e12f93c8dd531116abcfbfc4c8")
