-- Lua provided by RyzenAPI
-- Game: 古神模拟器ElderGods Simulator

-- MAIN APPLICATION
addappid(2808320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808321, 1, "9d5a3d1992ef0954d38d35332c831d8988eede331799bb0939bbe827ea4627cc")
