-- Lua provided by SkyAPI 
-- Game: AppID 2808320
addappid(2808320)
addappid(2808321, 1, "9d5a3d1992ef0954d38d35332c831d8988eede331799bb0939bbe827ea4627cc")
