-- Lua provided by RyzenAPI
-- Game: Void Sols

-- MAIN APPLICATION
addappid(2736690)
addappid(3323400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736691, 1, "b0479c3008de76723ac5c4ff4fd349a623673c9c8f13ac89b87ea752937ba049")

