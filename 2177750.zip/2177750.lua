-- Lua provided by RyzenAPI
-- Game: Half-Life 2: VR Mod - Episode One

-- MAIN APPLICATION
addappid(2177750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177751, 1, "ba639b085c51e6acb7f0b228253b91fa5e0dc5afb6aff447e641cc16f88bff74")
addappid(2177752, 1, "7e19d5603cf46dc95769d529513f675203c05666027726ce17b09da0da69b5e2")
addappid(2177753, 1, "346438ea0f5fe6462d49f8decf619dcc499f1210627577eca04b6a23ae97dcbc")
addappid(2177754, 1, "673ff097c56430d760849def004fcd7833daf4fc9a9143136a9151d58021ca86")
addappid(2177755, 1, "1697285885238d5074bcae4153a3afda1409937a901c2a87d0165424a3ac9154")
addappid(2177756, 1, "e6b1b2f5abdafe574fff2551d99d2f12fca84aad6b2ab3e4276fc828f4398863")
addappid(2177757, 1, "644a51f53e695c895b59113d21b5b69ffcdd171bc831bfdab4127dd66afabea0")
addappid(2177758, 1, "2e1d475ea1bd3467c75cecb878390f71d7e418258a9a8eadabefde82105d1752")
addappid(2177759, 1, "db4582f681cb3d0343c765fce1afa48ba4acedbcad3a858b4fac5bea5918c3c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
