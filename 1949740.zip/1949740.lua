-- Lua provided by RyzenAPI 
-- Game: Banana Shooter
addappid(1949740)
addappid(1949741, 1, "ea504668994076884b48aa6fedf0d71decbcc22a08432a54edb0f0cadfd61452")
addappid(2238100)
