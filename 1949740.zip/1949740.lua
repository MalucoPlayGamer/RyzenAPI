-- Lua provided by RyzenAPI
-- Game: Banana Shooter

-- MAIN APPLICATION
addappid(1949740)
addappid(2238100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1949741, 1, "ea504668994076884b48aa6fedf0d71decbcc22a08432a54edb0f0cadfd61452")

