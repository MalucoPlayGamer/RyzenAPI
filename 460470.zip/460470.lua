-- Lua provided by RyzenAPI
-- Game: 460470

-- MAIN APPLICATION
addappid(460470)
-- Game: addappid(460470)

-- MAIN APP DEPOTS / PACKAGES
addappid(460471, 1, "20a9cdc39f773fc3a632f17126e025f151103e8cf6d38be8975338a9445282ea")
