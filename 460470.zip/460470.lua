-- Lua provided by RyzenAPI
-- Game: Hindenburg VR

-- MAIN APPLICATION
addappid(460470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(460471, 1, "20a9cdc39f773fc3a632f17126e025f151103e8cf6d38be8975338a9445282ea")

