-- Lua provided by SkyAPI 
-- Game: Hindenburg VR
addappid(460470)
addappid(460471, 1, "20a9cdc39f773fc3a632f17126e025f151103e8cf6d38be8975338a9445282ea")
