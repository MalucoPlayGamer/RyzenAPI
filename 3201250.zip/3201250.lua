-- Lua provided by RyzenAPI
-- Game: addappid(3201250)

-- MAIN APPLICATION
addappid(3201250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3201251, 1, "f833f03802456976abf2e9ee20e119a0db9ee813e787d55ca1d140a8a3e12e84")
