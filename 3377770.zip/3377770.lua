-- Lua provided by RyzenAPI
-- Game: Game: Haunting Havens

-- MAIN APPLICATION
addappid(3377770)
-- Game: addappid(3377770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3377771, 1, "66d9fcae2691745f33f9d4c65e97e53e6b10a4923be5ec52b6930ae92f65f758")
