-- Lua provided by RyzenAPI
-- Game: The UnderGarden

-- MAIN APPLICATION
addappid(9980)

-- MAIN APP DEPOTS / PACKAGES
addappid(9981, 1, "4848605b3c5a714d11cdb3d69e48a2590397f3a29a165620df7099138c74a247")
