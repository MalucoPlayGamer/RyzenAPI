-- Lua provided by RyzenAPI
-- Game: 336080

-- MAIN APPLICATION
addappid(336080)
-- Game: addappid(336080)

-- MAIN APP DEPOTS / PACKAGES
addappid(336081, 1, "628f73819313f87e61a063df18ee305ef5c740b0872dc5375b87f7bcd67fea6c")
