-- Lua provided by SkyAPI 
-- Game: Zoo Simulator: Prologue
addappid(2610810)
addappid(2610811, 1, "b6731b6eeb1140cd93bbe675b35b67c43dff5aa28557c2a0f10de0ef54320543")
