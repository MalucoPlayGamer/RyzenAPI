-- Lua provided by RyzenAPI
-- Game: Game: Zoo Simulator: Prologue

-- MAIN APPLICATION
addappid(2610810)
-- Game: addappid(2610810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610811, 1, "b6731b6eeb1140cd93bbe675b35b67c43dff5aa28557c2a0f10de0ef54320543")
