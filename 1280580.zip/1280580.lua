-- Lua provided by RyzenAPI
-- Game: addappid(1280580)

-- MAIN APPLICATION
addappid(1280580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280582,0,"0bbbbe656b78e45bbf909632d2b0b4338476f842ff8098fccaa3c1b8a47d12c1")
