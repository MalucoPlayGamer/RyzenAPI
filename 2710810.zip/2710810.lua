-- Lua provided by RyzenAPI
-- Game: addappid(2710810)

-- MAIN APPLICATION
addappid(2710810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710811, 1, "91d36a9054316f91b9affb9504371ba81ca64441b3bbac882096f47f0ba8b6ec")
