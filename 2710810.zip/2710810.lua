-- Lua provided by RyzenAPI 
-- Game: Republic of Pirates Demo
addappid(2710810)
addappid(2710811, 1, "91d36a9054316f91b9affb9504371ba81ca64441b3bbac882096f47f0ba8b6ec")
