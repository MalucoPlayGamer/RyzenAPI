-- Lua provided by RyzenAPI
-- Game: 2624940

-- MAIN APPLICATION
addappid(2624940)
-- Game: addappid(2624940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624940,0,"c9cde00dfe170935fb41098db3d9b98cbd154fd7edcdddaf7dca5f9205896498")
