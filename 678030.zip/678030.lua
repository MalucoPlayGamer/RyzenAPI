-- Lua provided by RyzenAPI
-- Game: FAST & FURIOUS CROSSROADS

-- MAIN APPLICATION
addappid(678030)

-- MAIN APP DEPOTS / PACKAGES
addappid(678031, 1, "2dc9318055284186b91d05f77e97d7994df2758fa16d688bd02b2f5b4705e2fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1337900)
addappid(1337901)
addappid(1337902)
addappid(1337904)
addappid(1337905)
