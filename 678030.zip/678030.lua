-- Lua provided by RyzenAPI
-- Game: 678030

-- MAIN APPLICATION
addappid(678030)
-- Game: addappid(678030)

-- MAIN APP DEPOTS / PACKAGES
addappid(678031, 1, "2dc9318055284186b91d05f77e97d7994df2758fa16d688bd02b2f5b4705e2fd")
