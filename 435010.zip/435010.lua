-- Lua provided by RyzenAPI
-- Game: addappid(435010)

-- MAIN APPLICATION
addappid(435010)

-- MAIN APP DEPOTS / PACKAGES
addappid(435011, 1, "aecba019adfd994a3ba041f29bda7335c24a821c99efa4971dac4ab4bedb007a")
