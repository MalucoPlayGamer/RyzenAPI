-- Lua provided by RyzenAPI
-- Game: My Sweet! Housemate

-- MAIN APPLICATION
addappid(3100210)
-- Game: addappid(3100210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100211, 1, "003a89c396001a7a83f5879e0cdd7518cc0930fac17008d802b5a47df45f2a36")
