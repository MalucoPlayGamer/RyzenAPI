-- Lua provided by RyzenAPI
-- Game: AppID 286940

-- MAIN APPLICATION
addappid(286940)
addappid(317500)
addappid(317501)
addappid(373590)
addappid(542830)
addappid(562000)
addappid(624940)
addappid(641020)
addappid(741440)
addappid(792630)

-- MAIN APP DEPOTS / PACKAGES
addappid(286941, 1, "ab3d1eb2df1a3ac2547824660b3808aca9b9aa04ab4751ed587c242e3c72ce3b")

