-- Lua provided by RyzenAPI
-- Game: 286940

-- MAIN APPLICATION
addappid(286940)
-- Game: addappid(286940)

-- MAIN APP DEPOTS / PACKAGES
addappid(286941, 1, "ab3d1eb2df1a3ac2547824660b3808aca9b9aa04ab4751ed587c242e3c72ce3b")
