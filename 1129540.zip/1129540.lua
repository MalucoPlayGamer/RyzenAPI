-- Lua provided by RyzenAPI
-- Game: Orc Massage

-- MAIN APPLICATION
addappid(1129540)
-- Game: addappid(1129540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129541, 1, "b1352d91104d7a3c4a4402d664ca5eaf0471b69d4483c5e37ca40d47416ae6ae")
