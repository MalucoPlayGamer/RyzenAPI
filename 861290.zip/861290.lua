-- Lua provided by RyzenAPI
-- Game: Shooter Game

-- MAIN APPLICATION
addappid(861290)

-- MAIN APP DEPOTS / PACKAGES
addappid(861291,0,"64dfe5566c0c12fd78969f126f72dd543f6b67feae0dcafa7726be104289734e")

