-- Lua provided by RyzenAPI
-- Game: addappid(2675850)

-- MAIN APPLICATION
addappid(2675850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675851, 1, "e0554ebe6b04afcc315ddd002f055bfb7ebd27245679dc93f71a5116546ca11a")
