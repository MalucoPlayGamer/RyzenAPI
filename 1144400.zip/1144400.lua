-- Lua provided by SkyAPI 
-- Game: AppID 1144400
addappid(1144400)
addappid(1144401, 1, "0a108eb0b9a0eda8f2877f8445935437a7a9e9e62de17813cf34e0535593eb3a")
