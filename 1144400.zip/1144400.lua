-- Lua provided by RyzenAPI
-- Game: Senren＊Banka

-- MAIN APPLICATION
addappid(1144400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1144401, 1, "0a108eb0b9a0eda8f2877f8445935437a7a9e9e62de17813cf34e0535593eb3a")
