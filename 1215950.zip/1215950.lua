-- Lua provided by RyzenAPI 
-- Game: Getaway Storm
addappid(1215950)
addappid(1215951, 1, "f8ec971dce3bacbe89eb06022ac87c39761aa291af3033c23c92b0aa1de4b8fe")
addappid(1215952, 1, "6b719133e9d2da2f684bfbfcfa0536092dbd4be273544663a8edb39998c584d9")
