-- Lua provided by RyzenAPI
-- Game: Getaway Storm

-- MAIN APPLICATION
addappid(1215950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1215951, 1, "f8ec971dce3bacbe89eb06022ac87c39761aa291af3033c23c92b0aa1de4b8fe")
addappid(1215952, 1, "6b719133e9d2da2f684bfbfcfa0536092dbd4be273544663a8edb39998c584d9")

