-- Lua provided by RyzenAPI
-- Game: Wild Adventures

-- MAIN APPLICATION
addappid(1928940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928941, 1, "b2ec42ed15be35a5f8f7d4627bdb420302b2ff591d99325c307d5cc163fc5d34")
