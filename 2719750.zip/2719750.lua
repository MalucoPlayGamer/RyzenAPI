-- Lua provided by RyzenAPI
-- Game: Star Birds

-- MAIN APPLICATION
addappid(2719750)
addappid(4005820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719752,0,"14b66813cc3109312baf1d0c3fe4a3a5383c7d481d10f24a289cdcab933598fe")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3957040)
