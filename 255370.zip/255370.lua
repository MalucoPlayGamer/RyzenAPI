-- Lua provided by RyzenAPI
-- Game: addappid(255370)

-- MAIN APPLICATION
addappid(255370)

-- MAIN APP DEPOTS / PACKAGES
addappid(255371, 1, "29daa62cb0831ac0d112ad4dcf7a64cca7cb40e5fdcadf05597f9940361d9c06")
