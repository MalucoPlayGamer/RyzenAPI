-- Lua provided by RyzenAPI
-- Game: KickBeat Steam Edition

-- MAIN APPLICATION
addappid(255370)

-- MAIN APP DEPOTS / PACKAGES
addappid(255371, 1, "29daa62cb0831ac0d112ad4dcf7a64cca7cb40e5fdcadf05597f9940361d9c06")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
