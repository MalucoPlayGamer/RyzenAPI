-- Lua provided by RyzenAPI
-- Game: Game: Chefy-Chef

-- MAIN APPLICATION
addappid(1798810)
-- Game: addappid(1798810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798811, 1, "4cb3f79acd37d708b264a67f5ce21981e88c6a8b359e000c53ec29ba0d9ca5f1")
