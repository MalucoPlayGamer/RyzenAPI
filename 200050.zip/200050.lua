-- Lua provided by RyzenAPI
-- Game: AppID 200050

-- MAIN APPLICATION
addappid(200050)
addappid(228983)
addappid(229001)

-- MAIN APP DEPOTS / PACKAGES
addappid(200051, 1, "4c2bbd387f58478f359bc0bd37f5f534b39e052a3af99cf3246b95a066d35816")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(220640)
