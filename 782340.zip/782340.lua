-- Lua provided by RyzenAPI
-- Game: Lake of Voices

-- MAIN APPLICATION
addappid(782340)
