-- Lua provided by RyzenAPI 
-- Game: Ib
addappid(1901370)
addappid(1901371, 1, "5ac436bf278ecac2ba5ebba796474a0b87a297317bfa3f4a62932cf10e608f28")
