-- Lua provided by RyzenAPI
-- Game: Geometry Rush

-- MAIN APPLICATION
addappid(861710)

-- MAIN APP DEPOTS / PACKAGES
addappid(861711, 1, "51bde640942d747162d288e2e1f712a2720e9988b5bae00c7f6ca015fd5e94e7")

