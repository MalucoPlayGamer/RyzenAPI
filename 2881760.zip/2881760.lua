-- Lua provided by RyzenAPI
-- Game: Diamond Drone

-- MAIN APPLICATION
addappid(2881760)
-- Game: addappid(2881760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881761, 1, "e7ec5890830e902f4349f07fcbac85628389d5bf56ab2bd3f90b0ee9f3c34406")
