-- Lua provided by RyzenAPI
-- Game: Game: Mini Island: Cosmos

-- MAIN APPLICATION
addappid(1952550)
-- Game: addappid(1952550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952551, 1, "50d3c1de155d87f6a2f8573f1b1ba79d461b6ced845ca968809a85bf650f49bd")
