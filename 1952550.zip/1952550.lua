-- Lua provided by SkyAPI 
-- Game: Mini Island: Cosmos
addappid(1952550)
addappid(1952551, 1, "50d3c1de155d87f6a2f8573f1b1ba79d461b6ced845ca968809a85bf650f49bd")
