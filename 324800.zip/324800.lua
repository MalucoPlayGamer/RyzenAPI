-- Lua provided by RyzenAPI
-- Game: Shadow Warrior 2

-- MAIN APPLICATION
addappid(324800)
addappid(508970)
addappid(522330)
addappid(522331)
addappid(522332)
addappid(522333)
addappid(522334)
addappid(565840)
addappid(592460)
addappid(592461)

-- MAIN APP DEPOTS / PACKAGES
addappid(324801, 1, "c7d42c521529297c5a3a3174a89a1fb9084a0ec10f56c3de7c0a5c5c9d9134f1")
addappid(522335, 0, "2d94068eca43f9b19c6d3910e732094c9579796e5a6581d1d72e53c4f8c972ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
