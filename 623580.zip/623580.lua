-- Lua provided by RyzenAPI
-- Game: POBEDA

-- MAIN APPLICATION
addappid(623580)

-- MAIN APP DEPOTS / PACKAGES
addappid(623581, 1, "f81503ccf2a1ee5648d9e4ece6c0f9db85e869a2f826b0728c46603e9d8660ef")
addappid(624390, 0, "6749d590e84e37bc36fd7a31131e119658f719d472450d5c18156d8989a7ce78")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
