-- Lua provided by RyzenAPI
-- Game: Game: Simple Fish Adventure

-- MAIN APPLICATION
addappid(1698520)
-- Game: addappid(1698520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698521, 1, "1ba46e121f94a6501ca8ee88a268766c50db8b149a6e803033a19266921a5537")
