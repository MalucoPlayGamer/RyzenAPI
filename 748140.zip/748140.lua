-- Lua provided by RyzenAPI
-- Game: 748140

-- MAIN APPLICATION
addappid(748140)
-- Game: addappid(748140)

-- MAIN APP DEPOTS / PACKAGES
addappid(748140,0,"11b142b38d213cdf5c1a46e2125d024d432811b4c80faa6ce6ab0cadb6c82229")
