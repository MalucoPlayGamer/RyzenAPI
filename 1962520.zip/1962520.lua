-- Lua provided by RyzenAPI
-- Game: addappid(1962520)

-- MAIN APPLICATION
addappid(1962520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962521, 1, "e0abc5cc707a102dbfc2b2746353abddac3cd94e1d0dc84b69b47980b1483b7e")
