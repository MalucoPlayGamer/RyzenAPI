-- Lua provided by SkyAPI 
-- Game: Rise of Fox Hero
addappid(1962520)
addappid(1962521, 1, "e0abc5cc707a102dbfc2b2746353abddac3cd94e1d0dc84b69b47980b1483b7e")
