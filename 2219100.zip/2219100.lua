-- Lua provided by RyzenAPI
-- Game: AppID 2219100

-- MAIN APPLICATION
addappid(2219100)
-- Game: addappid(2219100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219101, 1, "0b0dd2b75ce76b6cd873e46fb3214e5dcf276915cad0d47c5aa05b3fb44f3dd8")
