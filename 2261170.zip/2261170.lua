-- Lua provided by RyzenAPI
-- Game: AppID 2261170

-- MAIN APPLICATION
addappid(2261170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261171, 1, "e239760de7e9a3fd331c1fc28f9f0e5a2e7c7193cceca17dbe8e0cccf0b77856")
