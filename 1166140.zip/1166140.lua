-- Lua provided by RyzenAPI
-- Game: Forbidden Art

-- MAIN APPLICATION
addappid(1166140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166141, 1, "ac93df928e571e2b35a96a3b8a6793750bf69715ed66a0f3feed37864a9ad067")

