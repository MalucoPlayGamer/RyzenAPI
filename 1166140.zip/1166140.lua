-- Lua provided by RyzenAPI
-- Game: Forbidden Art

-- MAIN APPLICATION
addappid(1166140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166141, 1, "ac93df928e571e2b35a96a3b8a6793750bf69715ed66a0f3feed37864a9ad067")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
