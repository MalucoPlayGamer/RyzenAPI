-- Lua provided by RyzenAPI
-- Game: ШХД: ЗИМА / IT'S WINTER

-- MAIN APPLICATION
addappid(1003360)
-- Game: addappid(1003360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003362,0,"957aa98835462af3863234d86e2e841c4e647aa6a8720be9175a932dd309e97d")
