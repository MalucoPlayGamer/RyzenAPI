-- Lua provided by RyzenAPI
-- Game: BULK

-- MAIN APP DEPOTS / PACKAGES
addappid(4122620, 1, "83c17d68502fbdfb239bd6c5b6a8b4476317c6a63df77ff89ab4a3e6cd5471c2") -- BULK
addappid(4122621, 1, "81d8cd1734dd0bc5670425e314f5f6abaf6d64155d8b24cec3868fa8c2ddd1f8") -- Depot 4122621
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
