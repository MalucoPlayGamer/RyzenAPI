-- Lua provided by RyzenAPI
-- Game: addappid(2768580)

-- MAIN APPLICATION
addappid(2768580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768581, 1, "848dfcc023195f1a379651a142b33b329746af47d6e5ac4c8da5a92ee97a15a1")
