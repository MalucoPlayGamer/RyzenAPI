-- Lua provided by RyzenAPI
-- Game: addappid(905050)

-- MAIN APPLICATION
addappid(905050)

-- MAIN APP DEPOTS / PACKAGES
addappid(905050,0,"64e95063358bf22f6ae8619f47cfc435539bcb54e8c77ac730ff5af890d0128e")
