-- Lua provided by RyzenAPI
-- Game: 甜点恋人 / Pastry Lovers

-- MAIN APPLICATION
addappid(568750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(568751, 1, "d397cd63b7b54b7e501ae43baedb96c56d4b8f8f9f71ec761cd8f3d189e6579a")

