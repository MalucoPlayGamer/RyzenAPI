-- Lua provided by RyzenAPI
-- Game: addappid(568750)

-- MAIN APPLICATION
addappid(568750)

-- MAIN APP DEPOTS / PACKAGES
addappid(568751, 1, "d397cd63b7b54b7e501ae43baedb96c56d4b8f8f9f71ec761cd8f3d189e6579a")
