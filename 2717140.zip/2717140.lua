-- Lua provided by RyzenAPI
-- Game: No Way Out

-- MAIN APPLICATION
addappid(2717140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717141, 1, "20cffa019a351b283407eba2ca105ac09d7644fb3590e5d681c4e1b90a206eff")
