-- Lua provided by RyzenAPI
-- Game: Game: Arcane Golf

-- MAIN APPLICATION
addappid(897800)
-- Game: addappid(897800)

-- MAIN APP DEPOTS / PACKAGES
addappid(897801, 1, "9169f0d366fba281a9463ae2ff15cfe81a4562fe8cabb71c70bb2929aff1747c")
