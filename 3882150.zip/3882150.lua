-- 3882150's Lua and Manifest Created by Hubcap Manifest
-- Grim Axiom
-- Created: August 07, 2026 at 00:28:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3882150, 1, "eb660ea4786c24853dee9f2d3d3f0d803e2e8519bfebd9a5cf7db0a08c869164") -- Grim Axiom
-- MAIN APP DEPOTS
addappid(3882151, 1, "f8e71eec5fea76a8f4aff9bfe169120d991658d3f316b913374f0a545f161654") -- Depot 3882151
setManifestid(3882151, "7400658999100936926", 3650683616)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)