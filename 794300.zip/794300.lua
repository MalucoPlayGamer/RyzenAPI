-- Lua provided by RyzenAPI
-- Game: AppID 794300

-- MAIN APPLICATION
addappid(794300)
addappid(823000)

-- MAIN APP DEPOTS / PACKAGES
addappid(794301, 1, "52865b06f37ecd38a52e320d633562fe17b694b95ede1f7956ee5e6b7e9a0fc4")

