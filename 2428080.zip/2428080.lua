-- Lua provided by RyzenAPI
-- Game: addappid(2428080)

-- MAIN APPLICATION
addappid(2428080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428081, 1, "c0a7cb3923233614940e7c836954daa4a3f45059b6c8b8152d546bbaa7e7d084")
