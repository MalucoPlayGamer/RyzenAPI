-- Lua provided by RyzenAPI
-- Game: AppID 593250

-- MAIN APPLICATION
addappid(593250)
-- Game: addappid(593250)

-- MAIN APP DEPOTS / PACKAGES
addappid(593251, 1, "b351fe72dc5ebecb34a7770dc4307aa1ac447999d679b14b75931884b084c1a3")
addappid(593253, 1, "ae608c53858f3a46c7cb9c14b6bbe1cdec71cabe5b536a65445cd18f361eb321")
