-- Lua provided by SkyAPI 
-- Game: MicroTown
addappid(931270)
addappid(931271, 1, "135bce9edd7f818b93dbc8461d60d376cc73fd2c2984972e12f7af5a09531175")
addappid(931272, 1, "128c15532e08b47df7829f21fec1e28dd2715e416e3690e4f4f661ad1c393e0d")
addappid(931273, 1, "bcaed9a5c3d000a416ca93c7fb925862a166f38f3c9d56691ab175b3262ba0a1")
