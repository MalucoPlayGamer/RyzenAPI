-- Lua provided by RyzenAPI
-- Game: 2322520

-- MAIN APPLICATION
addappid(2322520)
-- Game: addappid(2322520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322521, 1, "018f1d88217eb7db42af4474111d2d047d26ecc1e63d21d64703bb305f9a2b5b")
