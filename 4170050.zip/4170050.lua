-- 4170050's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Selena is streaming
-- Created: May 17, 2026 at 12:05:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4170050) -- Hentai Clicker: Selena is streaming
-- MAIN APP DEPOTS
addappid(4170051, 1, "c506266416ef26070ac0cc3550b65bcab41454814278a0489516b21f2c889895") -- Depot 4170051
setManifestid(4170051, "3263534147610642620", 171353001)