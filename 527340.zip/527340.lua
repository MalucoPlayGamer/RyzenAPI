-- Lua provided by RyzenAPI
-- Game: What The Box?

-- MAIN APPLICATION
addappid(527340)
-- Game: addappid(527340)

-- MAIN APP DEPOTS / PACKAGES
addappid(527341, 1, "62f44f3a3f249704509c3b7b6630d9f84bbc48da9cab13f7c1d7b77f1a9329b8")
