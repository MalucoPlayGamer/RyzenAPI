-- Lua provided by RyzenAPI
-- Game: Self-Delusion

-- MAIN APPLICATION
addappid(1590190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590191, 1, "ab997772a93e5e05bd05270da8ef242023dedf34708932abdf89cace134e45af")

