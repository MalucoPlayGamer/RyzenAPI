-- Lua provided by SkyAPI 
-- Game: AppID 342480
addappid(342480)
addappid(342481, 1, "02fbf2a8cdb771ea3ff5b7c92a9b48d5efd086aa38f2ac863c204d479cc0aee1")
addappid(342482, 1, "83c391174ec93dd9cebfb2a53fb5cbeb7f58cf1e45b0ee909cd1422941f5ea86")
addappid(342483, 1, "8ba353a8a57a7048420aeaa558e3b02d6761f022533c7b5fe738edfafe8824ba")
addappid(441300, 0, "b5b1bc89859fe38390c6146404f1e44af1093639411ab251275c393c17e07678")
addappid(441301)
addappid(442090)
addappid(703560)
