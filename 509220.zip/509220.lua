-- Lua provided by RyzenAPI
-- Game: Save Jesus

-- MAIN APPLICATION
addappid(509220)

-- MAIN APP DEPOTS / PACKAGES
addappid(509221, 1, "a1cd46f3f18d50725739ade1e2e77cbda203356a3f6f881da285f4acd4d75661")
