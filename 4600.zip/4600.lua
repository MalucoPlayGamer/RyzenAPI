-- Lua provided by RyzenAPI
-- Game: Full Pipe

-- MAIN APPLICATION
addappid(4600)

-- MAIN APP DEPOTS / PACKAGES
addappid(4601, 1, "62cef128891a7ac943a117990d798e4e1d06b9e9e12d2538211df7d2e8bbff46")
addappid(4602, 1, "54400b58c4b72fcae6ea78b6e991f8aad996db37c05311e7e1f373f5b5411569")
addappid(4603, 1, "e04a5f0dc456eb28efff561b2b2a487ffa25882e940126094873c6e374d7f2ad")
