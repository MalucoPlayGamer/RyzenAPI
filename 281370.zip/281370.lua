-- Lua provided by RyzenAPI
-- Game: Real Horror Stories Ultimate Edition

-- MAIN APPLICATION
addappid(281370)

-- MAIN APP DEPOTS / PACKAGES
addappid(281371, 1, "cf2eceef9ca8870348178a27fc33dd1b72a2f1ac3af6eaee097688e787758477")

