-- Lua provided by RyzenAPI
-- Game: 魔導聖戰:風色幻想

-- MAIN APPLICATION
addappid(2020480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020481, 1, "28e158fc5d9d4119dd2af72d740ec6bbad8253798b30adbfda1c1f135f4cd4ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
