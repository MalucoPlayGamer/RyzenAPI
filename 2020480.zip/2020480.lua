-- Lua provided by RyzenAPI
-- Game: 2020480

-- MAIN APPLICATION
addappid(2020480)
-- Game: addappid(2020480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020481, 1, "28e158fc5d9d4119dd2af72d740ec6bbad8253798b30adbfda1c1f135f4cd4ba")
