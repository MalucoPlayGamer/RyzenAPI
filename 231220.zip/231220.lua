-- Lua provided by RyzenAPI
-- Game: 231220

-- MAIN APPLICATION
addappid(231220)
-- Game: addappid(231220)

-- MAIN APP DEPOTS / PACKAGES
addappid(231221, 1, "180816104f64a66d7b87d2d3ce55ad3c378b1e50d1b6a24c66ef72641fda4526")
