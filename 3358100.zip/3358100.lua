-- Lua provided by RyzenAPI
-- Game: addappid(3358100)

-- MAIN APPLICATION
addappid(3358100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358100,0,"c0c507bc3f9d4633c5839394fa0af8e7467e111fbd99fc015f1f6caa887cc374")
