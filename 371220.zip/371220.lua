-- Lua provided by RyzenAPI
-- Game: AppID 371220

-- MAIN APPLICATION
addappid(371220)

-- MAIN APP DEPOTS / PACKAGES
addappid(371221, 1, "98fdb91b8ed4a6ad22ef472d4b56285d9f0311f03412cbaa21a5474d5dab9b3d")
addappid(563720, 0, "35ecf4a7053192fe2ef26c050a8d10bc8ce650f5d93023f5b06cb59aee6489b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
