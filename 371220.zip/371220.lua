-- Lua provided by RyzenAPI
-- Game: AppID 371220

-- MAIN APPLICATION
addappid(371220)

-- MAIN APP DEPOTS / PACKAGES
addappid(371221, 1, "98fdb91b8ed4a6ad22ef472d4b56285d9f0311f03412cbaa21a5474d5dab9b3d")
addappid(563720, 0, "35ecf4a7053192fe2ef26c050a8d10bc8ce650f5d93023f5b06cb59aee6489b6")

