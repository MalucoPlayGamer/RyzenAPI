-- Lua provided by RyzenAPI
-- Game: Natsumi and the Absurd Academy

-- MAIN APPLICATION
addappid(3326920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3326924,0,"2276bfcc9518e4f925719ba073cc7182d3d307aecc1e2c206db7abe135d49732")
