-- Lua provided by RyzenAPI
-- Game: Mini Golf Arena

-- MAIN APPLICATION
addappid(485670)

-- MAIN APP DEPOTS / PACKAGES
addappid(485671, 1, "3b6d25a461efda7e3363c5cb6d0d4097d3d3212301a8b7a5d6ca66dddb5aab74")
addappid(485672, 1, "d3890ee31b8df2e284b06d5e966e7999bc2391e073e67f9ec981df9278bb6c7f")
addappid(485673, 1, "8814d280d4c2b0d2ee2a4b021ce26be4945ac810f259ab1895d064e355ab4a8b")
addappid(485674, 1, "cfb5b61fb9f84b543948ba490d96c189e74c56e5372e1a6cb60ef8a30f565b66")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
