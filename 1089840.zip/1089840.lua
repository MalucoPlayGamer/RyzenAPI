-- Lua provided by RyzenAPI
-- Game: Armored Brigade

-- MAIN APPLICATION
addappid(1089840)
addappid(1101590)
addappid(1153600)
addappid(1427160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089840,0,"2c72ecf9f94c10a1cb7d739549082da2467feec7cc97884ed9d1f5c3a50df444")
addappid(1089841,0,"4574322e0ad0109926ea7fcbb7ac31ae4fe081399519ec9e2840b73bf7fd3a2c")
addappid(1089842,0,"fc3c78cd9d66463be346b2859dd7515e638526a9ae410ee1cc76f4d86cd17de8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
