-- Lua provided by RyzenAPI
-- Game: Game: Armored Brigade

-- MAIN APPLICATION
addappid(1089840)
-- Game: addappid(1089840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089841, 1, "4574322e0ad0109926ea7fcbb7ac31ae4fe081399519ec9e2840b73bf7fd3a2c")
addappid(1089842, 1, "fc3c78cd9d66463be346b2859dd7515e638526a9ae410ee1cc76f4d86cd17de8")
