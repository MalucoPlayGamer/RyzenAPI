-- Lua provided by RyzenAPI
-- Game: Osmos Demo

-- MAIN APPLICATION
addappid(29200)

-- MAIN APP DEPOTS / PACKAGES
addappid(29201, 1, "251acab7fdb40e9686337bcb084f5f0a95d31245171fb7b3a695789543f2b60c")

