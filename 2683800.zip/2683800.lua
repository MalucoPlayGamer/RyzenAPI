-- Lua provided by RyzenAPI
-- Game: Game: AppID 2683800

-- MAIN APPLICATION
addappid(2683800)
-- Game: addappid(2683800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2683801, 1, "3e8c312a45c08cfaf89a586118e4e3cb19c0f3f52d9f0a49a4dcb98047ddc3f6")
