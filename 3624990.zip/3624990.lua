-- Lua provided by RyzenAPI
-- Game: 3624990

-- MAIN APPLICATION
addappid(3624990)
-- Game: addappid(3624990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3624990,0,"95509dc4a951e21dc6d60e48b5ae02ae3aae93de32e030e49cd165129f55617f")
