-- Lua provided by RyzenAPI
-- Game: Nordenfelt

-- MAIN APPLICATION
addappid(428740)
-- Game: addappid(428740)

-- MAIN APP DEPOTS / PACKAGES
addappid(428741, 1, "d2a66ef14804d4866237156545d8d73057561e7f587cdb9a43e3d8ff189fef9d")
