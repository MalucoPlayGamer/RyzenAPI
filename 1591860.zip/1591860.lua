-- Lua provided by RyzenAPI
-- Game: 审判者

-- MAIN APPLICATION
addappid(1591860)
addappid(1620660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591861, 1, "db872ff7996d8aed07cfb420caa8b7779d3c483c90dbe2cdab922929cb2d4909")

