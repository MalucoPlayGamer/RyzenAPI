-- Lua provided by SkyAPI 
-- Game: STRIKERS 1945
addappid(1261960)
addappid(1261961, 1, "682af0184a0a6b49e06564b101ac30002f54e641117d6069d4ba965f7861d910")
