-- Lua provided by RyzenAPI
-- Game: Date Warp

-- MAIN APPLICATION
addappid(301380)
-- Game: addappid(301380)

-- MAIN APP DEPOTS / PACKAGES
addappid(301382,0,"d1ff97bb93e3d139953e4a39ccf0d55a908b767677f2ee5fb751ae22873fbf19")
addappid(301385,0,"112c127f2132313681d5d8adfdadc0ac10b6255123864eb3b70e093e20b5ff71")
