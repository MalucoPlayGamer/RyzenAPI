-- Lua provided by RyzenAPI
-- Game: Elisa: the Innkeeper

-- MAIN APPLICATION
addappid(576400)

-- MAIN APP DEPOTS / PACKAGES
addappid(576401,0,"4d5c62fe2860f03de1927afe7800fa39ee5b0980d982c1154419d10fd3fbb461")

