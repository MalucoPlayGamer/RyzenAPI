-- Lua provided by RyzenAPI 
-- Game: Mini Pipes - A Logic Puzzle Pipes Game
addappid(1888660)
addappid(1888661, 1, "c40cb2eaf188247b027c42a6dcca44aead6c3f42a39e425662a58507b31c9ad6")
