-- Lua provided by RyzenAPI
-- Game: Game: Mini Pipes - A Logic Puzzle Pipes Game

-- MAIN APPLICATION
addappid(1888660)
-- Game: addappid(1888660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888661, 1, "c40cb2eaf188247b027c42a6dcca44aead6c3f42a39e425662a58507b31c9ad6")
