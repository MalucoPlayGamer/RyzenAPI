-- Lua provided by RyzenAPI
-- Game: Wife Quest

-- MAIN APPLICATION
addappid(1554600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1554601, 1, "c0a93fda0e71a078a9293ce6cf3015997cfb69f9ae137c84df2b7decf31cb43d")
addappid(1554603, 1, "dc1b53045678fd3587503967a221a8a75786af82d9ae2015b4e01f37cd3170c5")
addappid(1744540, 0, "5287664570dad14ed7d7b9c4d9d36458952006a8ae2e6f4bd7e8df7cf21698ad")

