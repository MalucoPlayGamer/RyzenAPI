-- Lua provided by RyzenAPI
-- Game: Wife Quest

-- MAIN APPLICATION
addappid(1554600)
-- Game: addappid(1554600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554601, 1, "c0a93fda0e71a078a9293ce6cf3015997cfb69f9ae137c84df2b7decf31cb43d")
addappid(1554603, 1, "dc1b53045678fd3587503967a221a8a75786af82d9ae2015b4e01f37cd3170c5")
addappid(1744540, 0, "5287664570dad14ed7d7b9c4d9d36458952006a8ae2e6f4bd7e8df7cf21698ad")
