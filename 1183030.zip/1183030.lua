-- Lua provided by RyzenAPI
-- Game: Layers of Fear VR

-- MAIN APPLICATION
addappid(1183030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183031, 1, "01480c5a88100ba6149fa888ab2a226bcce91ce3b469da6f30c240b83d66e231")

