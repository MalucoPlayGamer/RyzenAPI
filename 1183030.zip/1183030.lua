-- Lua provided by RyzenAPI 
-- Game: AppID 1183030
addappid(1183030)
addappid(1183031, 1, "01480c5a88100ba6149fa888ab2a226bcce91ce3b469da6f30c240b83d66e231")
