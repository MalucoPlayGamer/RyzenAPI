-- Lua provided by RyzenAPI
-- Game: 1257850

-- MAIN APPLICATION
addappid(1257850)
-- Game: addappid(1257850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257851, 1, "ecb0a051b03b68ccdc5ed81d61b18a9a25e2e91c02ac552033261a8cf4a602eb")
