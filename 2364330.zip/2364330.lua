-- Lua provided by RyzenAPI
-- Game: Secrets of Magonia

-- MAIN APPLICATION
addappid(2364330)
-- Game: addappid(2364330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364332,0,"f31e75bb0fe9e0d12ffe04e9a9ccbb8ee44f0e8cc16fd32f0f093ec84953cbf5")
