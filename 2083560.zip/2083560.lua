-- Lua provided by RyzenAPI
-- Game: addappid(2083560)

-- MAIN APPLICATION
addappid(2083560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083561, 1, "84f8ea74e5103cf93627e41f72377960d847b5660f243197aac65bb2ab242dba")
