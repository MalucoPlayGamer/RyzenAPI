-- Lua provided by RyzenAPI 
-- Game: AppID 2083560
addappid(2083560)
addappid(2083561, 1, "84f8ea74e5103cf93627e41f72377960d847b5660f243197aac65bb2ab242dba")
