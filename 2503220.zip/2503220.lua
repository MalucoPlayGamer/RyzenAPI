-- Lua provided by RyzenAPI
-- Game: Karting Superstars

-- MAIN APPLICATION
addappid(2503220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2503221, 1, "e79806fdba62774a1958fe291ef6f130f06709d01cab58084434246c99c0bf71")
