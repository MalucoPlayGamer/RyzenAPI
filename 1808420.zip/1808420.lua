-- Lua provided by RyzenAPI
-- Game: Alien Abduction Experience PC HD

-- MAIN APPLICATION
addappid(1808420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808422,0,"e1ddc4878d4ea3e029c496ea44703ac91b7ccdb60f5d3d707c66edb69247c3e1")

