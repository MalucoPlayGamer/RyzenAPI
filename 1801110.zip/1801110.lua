-- Lua provided by SkyAPI 
-- Game: BOKURA
addappid(1801110)
addappid(1801111, 1, "91e21c61b7cfb3e646a2b2291c2ca81bedeaf29d5651c356fd184fd82331e7b7")
addappid(1801112, 1, "ede54de4e30f22de00a8396cfe1e4188c3faaa75acd9e987362f433f8d47991a")
