-- Lua provided by RyzenAPI
-- Game: Covenant Tower

-- MAIN APPLICATION
addappid(3049700) -- Covenant Tower

-- MAIN APP DEPOTS / PACKAGES
addappid(3049701, 1, "ae2bc72e5cf7661d2cedc528ef9c8cf17758b04c017b7352a7a487e2c3c33785") -- Depot 3049701

