-- 3049700's Lua and Manifest Created by Hubcap Manifest
-- Covenant Tower
-- Created: August 10, 2026 at 14:55:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3049700) -- Covenant Tower
-- MAIN APP DEPOTS
addappid(3049701, 1, "ae2bc72e5cf7661d2cedc528ef9c8cf17758b04c017b7352a7a487e2c3c33785") -- Depot 3049701
setManifestid(3049701, "256467815993439690", 124035832)