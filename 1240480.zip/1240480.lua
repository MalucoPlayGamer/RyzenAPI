-- Lua provided by RyzenAPI
-- Game: -The Sacrificial Girl of the Fantasy 3 Kingdoms-

-- MAIN APPLICATION
addappid(1240480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240481, 1, "7ee5bd3403b216e856fdda34cd8f7dce9e586638a2bb5515f396ae07bf2b5cc0")

