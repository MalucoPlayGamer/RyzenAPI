-- Lua provided by RyzenAPI
-- Game: VEGA Conflict

-- MAIN APPLICATION
addappid(339600)
addappid(471390)
addappid(472810)
addappid(472811)
addappid(558080)
addappid(558081)
addappid(558082)
addappid(558083)
addappid(558084)
addappid(558085)
addappid(638890)
addappid(638891)
addappid(639520)
addappid(639521)
addappid(639522)
addappid(639523)
addappid(639524)
addappid(639525)
addappid(745800)
addappid(745801)
addappid(745802)
addappid(753000)
addappid(753001)
addappid(753002)
addappid(753003)
addappid(753004)
addappid(856970)
addappid(856971)
addappid(856972)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(339601, 1, "723ebe2d43dc5cc84d5e3d3f8674aac8c95b796c1d7b0e19574deb887a191989")
addappid(339602, 1, "4248d02393c25890bf50441f3b26e610aedc7accd32e8c9c8d493a0a0268b48f")

