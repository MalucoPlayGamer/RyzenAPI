-- Lua provided by RyzenAPI 
-- Game: AppID 339600
addappid(339600)
addappid(339601, 1, "723ebe2d43dc5cc84d5e3d3f8674aac8c95b796c1d7b0e19574deb887a191989")
addappid(339602, 1, "4248d02393c25890bf50441f3b26e610aedc7accd32e8c9c8d493a0a0268b48f")
