-- Lua provided by RyzenAPI
-- Game: Game: High Spirits

-- MAIN APPLICATION
addappid(3080290)
-- Game: addappid(3080290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080291, 1, "b9aceeafb3c05b97cab8216b02b817091db20832c0cfacaba3d588dabc56342b")
