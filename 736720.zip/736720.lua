-- Lua provided by RyzenAPI
-- Game: BAAM SQUAD

-- MAIN APPLICATION
addappid(736720)

-- MAIN APP DEPOTS / PACKAGES
addappid(736721, 1, "d7a9fa11a3cd81c52e667579eaa50fcb455dc5ab6a2ee8202ec5bb29584cb922")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
