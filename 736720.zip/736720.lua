-- Lua provided by RyzenAPI
-- Game: BAAM SQUAD

-- MAIN APPLICATION
addappid(736720)

-- MAIN APP DEPOTS / PACKAGES
addappid(736721, 1, "d7a9fa11a3cd81c52e667579eaa50fcb455dc5ab6a2ee8202ec5bb29584cb922")
