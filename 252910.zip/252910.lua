-- Lua provided by RyzenAPI
-- Game: Skyscraper Simulator

-- MAIN APPLICATION
addappid(252910)

-- MAIN APP DEPOTS / PACKAGES
addappid(252911, 1, "724c1f599e3144736ba05f991c481186fa5b90a496f0038e8d51ea65b4e337eb")
addappid(252912, 1, "9ba28b8af4914c3f78d3b86044d0e3384fd25a56091b524f4d2435d4f2b69b8f")
addappid(252913, 1, "c22dd83c9f89ee36dfa5e15bd7c1aad3d7841c37e90749515af37e11d5758150")
addappid(252914, 1, "d940071ef81d2c0db7933faf86bc1d57ef934d5070237d3316524a5129c767d6")
addappid(252915, 1, "1435bcac0567653b2eb9c4dc472b27a027748f31a24d391d7496a1aba806901e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
