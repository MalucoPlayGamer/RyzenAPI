-- Lua provided by RyzenAPI
-- Game: Until Then Demo

-- MAIN APPLICATION
addappid(2296400)
-- Game: addappid(2296400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296401, 1, "7cd49fba46f03b83ce47953ecfd846b48a112e9851a2884ff04bb317b8f94669")
