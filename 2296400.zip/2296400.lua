-- Lua provided by RyzenAPI 
-- Game: Until Then Demo
addappid(2296400)
addappid(2296401, 1, "7cd49fba46f03b83ce47953ecfd846b48a112e9851a2884ff04bb317b8f94669")
