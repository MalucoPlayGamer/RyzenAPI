-- Lua provided by RyzenAPI
-- Game: Poon Puzzle Demo

-- MAIN APPLICATION
addappid(2618910)
-- Game: addappid(2618910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618911, 1, "6208c47e8b2c45953b0470ca91ae399a3526ff0a4d9146446033d4dac15be355")
