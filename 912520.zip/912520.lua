-- Lua provided by RyzenAPI
-- Game: AppID 912520

-- MAIN APPLICATION
addappid(912520)

-- MAIN APP DEPOTS / PACKAGES
addappid(912521, 1, "fe5ac9fa0e7436bbdaf5908b4d5a77d57f7f0145cb5063f0d40deaaef11811c8")
