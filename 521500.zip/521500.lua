-- Lua provided by RyzenAPI
-- Game: Sakura Space

-- MAIN APPLICATION
addappid(521500)

-- MAIN APP DEPOTS / PACKAGES
addappid(521501, 1, "dc37989fc6bda96ab4bfc54ed99834d9cbb6667ebb78797f6d7af62bc2ac3e9b")
