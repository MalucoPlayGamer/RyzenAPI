-- Lua provided by SkyAPI 
-- Game: AppID 521500
addappid(521500)
addappid(521501, 1, "dc37989fc6bda96ab4bfc54ed99834d9cbb6667ebb78797f6d7af62bc2ac3e9b")
