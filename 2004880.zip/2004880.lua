-- Lua provided by RyzenAPI
-- Game: Lustful Pussies

-- MAIN APPLICATION
addappid(2004880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004881, 1, "a430a08a49aa3537fd8734fab5e5fa64d327d78f1a97c618ad70401776eb72f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
