-- Lua provided by RyzenAPI
-- Game: 2004880

-- MAIN APPLICATION
addappid(2004880)
-- Game: addappid(2004880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004881, 1, "a430a08a49aa3537fd8734fab5e5fa64d327d78f1a97c618ad70401776eb72f9")
