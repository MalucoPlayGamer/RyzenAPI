-- Lua provided by RyzenAPI
-- Game: Cosmic Cleaner

-- MAIN APPLICATION
addappid(2368810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368811, 1, "2825b7059973361ccfd60a24a7d73da444c2ca777635c1b60dbeb7599e02e80e")
