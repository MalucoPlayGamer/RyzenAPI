-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Digger

-- MAIN APPLICATION
addappid(3015140)
-- Game: addappid(3015140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015141, 1, "32a390e961d2af8e86c7d8a6076b708b065974377b4006eb264700f37570ef00")
