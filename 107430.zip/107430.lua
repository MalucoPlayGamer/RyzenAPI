-- Lua provided by SkyAPI 
-- Game: ARMA X: Anniversary Edition
addappid(107430)
addappid(107431, 1, "0b2041d33294e3ecbfa89c4fa307364aaa615658e4c279504dc62d582630dfbd")
