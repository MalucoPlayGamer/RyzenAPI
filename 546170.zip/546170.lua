-- Lua provided by RyzenAPI
-- Game: AppID 546170

-- MAIN APPLICATION
addappid(546170)

-- MAIN APP DEPOTS / PACKAGES
addappid(546171, 1, "8e6cedcf6bafa394a6a23ec007cc27e0ca4d5edf8cc30bd7507e8e0196b80b3b")
addappid(546172, 1, "a8c88acc9b4f8183fdd6c6f209c7c9dd7d67bffd7e72b4c2a92cce1646c2d9b7")

