-- Lua provided by RyzenAPI
-- Game: Game: AppID 1772490

-- MAIN APPLICATION
addappid(1772490)
-- Game: addappid(1772490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772491, 1, "b33d11255e8a6aa4f253bc93bfd3a08d67e59de992c75165a69d9f1471c26e92")
