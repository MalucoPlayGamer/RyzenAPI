-- Lua provided by RyzenAPI
-- Game: addappid(1023810)

-- MAIN APPLICATION
addappid(1023810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023811, 1, "c047d8922688a1db731d34d79ab488959fe83e706f9cea1f8b2688c7a1fef566")
