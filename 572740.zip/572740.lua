-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: The Secret of Shadow Ranch

-- MAIN APPLICATION
addappid(572740)
-- Game: addappid(572740)

-- MAIN APP DEPOTS / PACKAGES
addappid(572741, 1, "6e623ec6983106146ac387afe926c6ba5c518a4ccfcc8597db9d66346309f3a4")
