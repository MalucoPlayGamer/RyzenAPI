-- Lua provided by RyzenAPI
-- Game: 2454940

-- MAIN APPLICATION
addappid(2454940)
-- Game: addappid(2454940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2454941, 1, "12d4dd2d408016cf745fa75444dc7ba9c131f44b447ec46913ed2c9dc6ecdae2")
