-- Lua provided by SkyAPI 
-- Game: THE FANGS HUNTRESS
addappid(1624460)
addappid(1624461, 1, "4a25344033e50125e6b21faa0f42658f6db39bf007ac0bda06d4171f3c8f4aa7")
