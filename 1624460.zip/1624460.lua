-- Lua provided by RyzenAPI
-- Game: THE FANGS HUNTRESS

-- MAIN APPLICATION
addappid(1624460)
-- Game: addappid(1624460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624461, 1, "4a25344033e50125e6b21faa0f42658f6db39bf007ac0bda06d4171f3c8f4aa7")
