-- Lua provided by RyzenAPI
-- Game: addappid(502770)

-- MAIN APPLICATION
addappid(502770)

-- MAIN APP DEPOTS / PACKAGES
addappid(502771, 1, "846ed219a5c93fba5c9e8dfff4793e9b43fce411def2c6f92ee90bac2139a168")
