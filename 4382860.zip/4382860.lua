-- 4382860's Lua and Manifest Created by Hubcap Manifest
-- Loot Goblin
-- Created: August 04, 2026 at 14:13:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4382860) -- Loot Goblin
-- MAIN APP DEPOTS
addappid(4382862, 1, "44f1b0053d600558a7fb6ffde60e1ffbd9d0e7d437b390840ef203f1423e4902") -- Depot 4382862
setManifestid(4382862, "5330404501469655865", 652355807)
addappid(4382863, 1, "5bab42e1edad6a9f7129bd4fba126dc591de4dc4fa97342902c3e4cf646915a4") -- Depot 4382863
setManifestid(4382863, "3674499288815105110", 814126724)