-- Lua provided by RyzenAPI
-- Game: Loot Goblin

-- MAIN APPLICATION
addappid(4382860) -- Loot Goblin

-- MAIN APP DEPOTS / PACKAGES
addappid(4382862, 1, "44f1b0053d600558a7fb6ffde60e1ffbd9d0e7d437b390840ef203f1423e4902") -- Depot 4382862
addappid(4382863, 1, "5bab42e1edad6a9f7129bd4fba126dc591de4dc4fa97342902c3e4cf646915a4") -- Depot 4382863

