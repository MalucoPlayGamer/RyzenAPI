-- Lua provided by SkyAPI 
-- Game: Alcyone
addappid(1972230)
addappid(1972231, 1, "5026afe51647cf40b8c1c4d6173d0f4b0802541575b4baaa148562eea4f8374f")
addappid(1972232, 1, "df2950c6048dd33b14b655473a6a166c15ad537ad41513f528c973d9278cd29b")
