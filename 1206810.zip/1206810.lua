-- Lua provided by RyzenAPI
-- Game: AppID 1206810

-- MAIN APPLICATION
addappid(1206810)
-- Game: addappid(1206810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206811, 1, "412ece14380ff996999c97a0ee97b618ecdd3b43cfe1249abb2c9364c947bd8b")
