-- Lua provided by RyzenAPI
-- Game: AppID 1206810

-- MAIN APPLICATION
addappid(1206810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1206811, 1, "412ece14380ff996999c97a0ee97b618ecdd3b43cfe1249abb2c9364c947bd8b")

