-- Lua provided by RyzenAPI
-- Game: Agatha Christie - Murder on the Orient Express

-- MAIN APPLICATION
addappid(1904790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904791, 1, "25bb01484e678e55e914566a2aae96951823935444176bbdf2f13ae8bce932e4")
addappid(2633660, 0, "5627ce400e6f4b87bd6e786f64c2780b10d11600e2579484811f38fc89c6ad00")

