-- Lua provided by RyzenAPI
-- Game: Game: BackSlap

-- MAIN APPLICATION
addappid(3666470)
-- Game: addappid(3666470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3666471, 1, "985467b07c86442749285d5785afd00df99586a2936a1f3461abec85b10d4431")
