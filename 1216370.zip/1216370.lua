-- Lua provided by RyzenAPI
-- Game: DarkLight

-- MAIN APPLICATION
addappid(1216370)
-- Game: addappid(1216370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216371, 1, "3f0fe2d058878b1a0a2319d792b75fdd866be901b12bb2f1cd2291ca118414ae")
addappid(1216690, 0, "7301199d675b6f092f49d071a6ef025d6d8f8f7e909325fd7bb6d5c23f88ebc4")
