-- Lua provided by RyzenAPI
-- Game: 3056150

-- MAIN APPLICATION
addappid(3056150)
-- Game: addappid(3056150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056151, 1, "318a9819c067a06f766dddcb10f40183d3ce5b8891396d33c8de01dd74c080c0")
