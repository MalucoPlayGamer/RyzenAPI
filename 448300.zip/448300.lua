-- Lua provided by RyzenAPI
-- Game: Game: AppID 448300

-- MAIN APPLICATION
addappid(448300)
-- Game: addappid(448300)

-- MAIN APP DEPOTS / PACKAGES
addappid(448301, 1, "56c4aef3cab61597ca185aac640974ef4bb25a487102c26578113c1e8826e572")
