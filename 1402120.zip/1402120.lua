-- Lua provided by RyzenAPI
-- Game: 9 Years of Shadows

-- MAIN APPLICATION
addappid(1402120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402121, 1, "523c2a31a7404cd2f56d4396eee97a063c56d21792843befd04d02e962aef91e")

