-- Lua provided by RyzenAPI
-- Game: 879610

-- MAIN APPLICATION
addappid(879610)
-- Game: addappid(879610)

-- MAIN APP DEPOTS / PACKAGES
addappid(879611, 1, "65a7dc467c1e61873fdad41507a6af8d58aea04d800f5b3aa681785e1083125f")
