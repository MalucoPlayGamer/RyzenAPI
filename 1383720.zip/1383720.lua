-- Lua provided by RyzenAPI
-- Game: 1383720

-- MAIN APPLICATION
addappid(1383720)
-- Game: addappid(1383720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383721, 1, "d8f85f6bc7703c3745683beab295f2cce66681e6d3a0ef81a26287cfb94de813")
