-- Lua provided by RyzenAPI
-- Game: Wayfinder Playtest

-- MAIN APPLICATION
addappid(2287610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171691,0,"b6cb674fb5083cf930aa7e0b0f245eeb14068f7cd60c8fdeafa3f4f5c8bd66e2")
addtoken(2287610,"1101290451706895212")

