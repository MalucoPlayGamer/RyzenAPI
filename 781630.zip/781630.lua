-- Lua provided by RyzenAPI
-- Game: addappid(781630)

-- MAIN APPLICATION
addappid(781630)

-- MAIN APP DEPOTS / PACKAGES
addappid(781631, 1, "18d86da8082441020586dc8ecaf22f355425ae803765634cba104035e2fa2e8b")
