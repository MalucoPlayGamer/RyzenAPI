-- Lua provided by RyzenAPI
-- Game: AppID 915760

-- MAIN APPLICATION
addappid(915760)
-- Game: addappid(915760)

-- MAIN APP DEPOTS / PACKAGES
addappid(915761, 1, "0ad0f0521c5f48ecc7e568fe7d3fd8538d274ea674a114852e4c8677c2472aa8")
