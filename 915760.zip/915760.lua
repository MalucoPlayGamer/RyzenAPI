-- Lua provided by RyzenAPI
-- Game: Aether Drift

-- MAIN APPLICATION
addappid(915760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(915761, 1, "0ad0f0521c5f48ecc7e568fe7d3fd8538d274ea674a114852e4c8677c2472aa8")

