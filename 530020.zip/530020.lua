-- Lua provided by RyzenAPI
-- Game: World to the West

-- MAIN APPLICATION
addappid(530020)

-- MAIN APP DEPOTS / PACKAGES
addappid(530021, 1, "c9cdfe0d4f09a55d62196efd535b369569277d34f6d47eabdd724f36b8ab25a2")
addappid(530022, 1, "f880163d1144b77d7fe73f6b650f28c06298a4284dcbf2e6082d0fe8c97b5bf5")
addappid(530023, 1, "9b1a157c4c9cbcd835e3a5ddd75a528427fb01c470cad2cfffdb837ee0dafcab")
addappid(530024, 1, "cda2a94efe55f296263dfb241613272906e63b66b64194bc49f76d012e4d6aef")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(646800)
