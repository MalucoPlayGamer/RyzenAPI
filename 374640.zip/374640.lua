-- Lua provided by RyzenAPI
-- Game: addappid(374640)

-- MAIN APPLICATION
addappid(374640)

-- MAIN APP DEPOTS / PACKAGES
addappid(374641, 1, "ee288f40c6ce27a93dcfc88b83a3dfdff74840e17b50fb4d401ca7c7c40eeb4a")
addappid(374642, 1, "4863006a96a6470635f6ccdd58fbfd9ff2b0ece417d7edd84ea991f86bfd6593")
addappid(374643, 1, "b64cfc6c132a29d2720f2e4673d1994b361770aaba2314408a55153e5cd4f194")
addappid(374644, 1, "0efa273b5b5c93bf573a636cada8050eac57f528fb3eb139bc4bce6a8220a2c7")
