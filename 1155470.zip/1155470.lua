-- Lua provided by SkyAPI 
-- Game: AppID 1155470
addappid(1155470)
addappid(1155471, 1, "b6ff1dbbcde7f491cff7d389c483e9cbae8aafdf7e37b51e497f65ce90946e5e")
