-- 4862450's Lua and Manifest Created by Hubcap Manifest
-- Don't Knock Again, Sabrina!
-- Created: August 12, 2026 at 00:06:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4862450) -- Don't Knock Again, Sabrina!
-- MAIN APP DEPOTS
addappid(4862451, 1, "22b323ebb529744b64b760ba0b8ad2c93e0e2e1a7ef3f769e83ed3aba7f7e1ae") -- Depot 4862451
setManifestid(4862451, "4688231947879770875", 8185459526)