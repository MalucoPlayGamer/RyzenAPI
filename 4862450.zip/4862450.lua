-- Lua provided by RyzenAPI
-- Game: Don't Knock Again, Sabrina!

-- MAIN APP DEPOTS / PACKAGES
addappid(4862450) -- Don't Knock Again, Sabrina!
addappid(4862451, 1, "22b323ebb529744b64b760ba0b8ad2c93e0e2e1a7ef3f769e83ed3aba7f7e1ae") -- Depot 4862451

