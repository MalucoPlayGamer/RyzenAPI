-- Lua provided by RyzenAPI
-- Game: Tales of Sintra: The Dark Vortex Demo

-- MAIN APPLICATION
addappid(3102140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3102141, 1, "6765d28c02cc1ba2153556ff7fe0fb927abc1795ca8060cac2e8f5e703c758cc")
