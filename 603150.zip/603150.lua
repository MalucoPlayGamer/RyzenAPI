-- Lua provided by RyzenAPI
-- Game: 603150

-- MAIN APPLICATION
addappid(603150)
-- Game: addappid(603150)

-- MAIN APP DEPOTS / PACKAGES
addappid(603151, 1, "8be297c94e712417e94e72ebce223735eac44d6d1cfc76764c73f4d46c850cfa")
