-- Lua provided by RyzenAPI
-- Game: SHENZHEN SOLITAIRE

-- MAIN APPLICATION
addappid(570490)
-- Game: addappid(570490)

-- MAIN APP DEPOTS / PACKAGES
addappid(570491, 1, "b3df362db3a2077ee1fad24becac7c5d86d3c949ae3ac515b3524b8333416add")
