-- Lua provided by RyzenAPI
-- Game: SHENZHEN SOLITAIRE

-- MAIN APPLICATION
addappid(570490)

-- MAIN APP DEPOTS / PACKAGES
addappid(570491, 1, "b3df362db3a2077ee1fad24becac7c5d86d3c949ae3ac515b3524b8333416add")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
