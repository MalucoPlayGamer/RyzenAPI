-- Lua provided by RyzenAPI
-- Game: Game: AppID 726250

-- MAIN APPLICATION
addappid(726250)
-- Game: addappid(726250)

-- MAIN APP DEPOTS / PACKAGES
addappid(726251, 1, "dd437a770e9915fdf62e23b64e2da9593c166e4c79b8821b0f936ce101ce12dd")
