-- Lua provided by RyzenAPI
-- Game: 252190

-- MAIN APPLICATION
addappid(252190)
-- Game: addappid(252190)

-- MAIN APP DEPOTS / PACKAGES
addappid(252192,0,"202c3aabd5508bd3c3f1557f404cd6eb8428454a81f93d85761215c20ec5904d")
