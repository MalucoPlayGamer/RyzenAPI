-- Lua provided by RyzenAPI
-- Game: Defender's Quest 2: Mists of Ruin

-- MAIN APPLICATION
addappid(252190)

-- MAIN APP DEPOTS / PACKAGES
addappid(252192,0,"202c3aabd5508bd3c3f1557f404cd6eb8428454a81f93d85761215c20ec5904d")
