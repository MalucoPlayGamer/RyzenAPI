-- Lua provided by RyzenAPI
-- Game: 1065650

-- MAIN APPLICATION
addappid(1065650)
-- Game: addappid(1065650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065651, 1, "f4dcbd194fd06f395af8c42474a3859f32b7d48edcfd356ee977a37d31e3929d")
