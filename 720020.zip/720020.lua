-- Lua provided by RyzenAPI
-- Game: AppID 720020

-- MAIN APPLICATION
addappid(720020)
-- Game: addappid(720020)

-- MAIN APP DEPOTS / PACKAGES
addappid(720021, 1, "2adce0e0316edc0fe9bb4cbae879234d635f90c9a41ea65e48fa98fab003b37a")
