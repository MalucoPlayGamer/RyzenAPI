-- Lua provided by RyzenAPI
-- Game: 2431010

-- MAIN APPLICATION
addappid(2431010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431010,0,"688e0151ec52c82eb6a9dcb9506765c07e3d80e323db7e5ee23d5cfaa7ec55e3")

