-- Lua provided by RyzenAPI
-- Game: addappid(874270)

-- MAIN APPLICATION
addappid(874270)

-- MAIN APP DEPOTS / PACKAGES
addappid(874271, 1, "eeae667f987b3dde51bf4b496b53a804b100f1c4c0d9309fcabf3e0a9ab99ff3")
