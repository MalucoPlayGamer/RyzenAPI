-- Lua provided by SkyAPI 
-- Game: Sphaera
addappid(874270)
addappid(874271, 1, "eeae667f987b3dde51bf4b496b53a804b100f1c4c0d9309fcabf3e0a9ab99ff3")
