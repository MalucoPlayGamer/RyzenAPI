-- Lua provided by RyzenAPI
-- Game: AppID 787530

-- MAIN APPLICATION
addappid(787530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(787531, 1, "6876483c4fc1a5db3249a63d0448ef642f7d70520e7adcf46d46a0bf438e1b79")

