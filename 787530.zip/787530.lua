-- Lua provided by RyzenAPI
-- Game: 787530

-- MAIN APPLICATION
addappid(787530)
-- Game: addappid(787530)

-- MAIN APP DEPOTS / PACKAGES
addappid(787531, 1, "6876483c4fc1a5db3249a63d0448ef642f7d70520e7adcf46d46a0bf438e1b79")
