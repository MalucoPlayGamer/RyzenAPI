-- Lua provided by RyzenAPI
-- Game: 3376830

-- MAIN APPLICATION
addappid(3376830)
-- Game: addappid(3376830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376831, 1, "bd3eda03474fd55f929dd642db1aacde84b5ce620bd5ba0b9ec614e61ae70000")
