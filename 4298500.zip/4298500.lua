-- Lua provided by RyzenAPI
-- Game: Last Breath

-- MAIN APPLICATION
addappid(4298500) -- Last Breath

-- MAIN APP DEPOTS / PACKAGES
addappid(4298501, 1, "8f6a36d642f08f18e19f5bdb7525cb614acf9c9fb31298a9346cd2f09384b786") -- Depot 4298501

