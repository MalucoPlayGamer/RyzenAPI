-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3124440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124440,0,"5e5fe8829907e57c8d5c1c7a4fe0b54508623d0209237e8d2a11f073beae7932")
