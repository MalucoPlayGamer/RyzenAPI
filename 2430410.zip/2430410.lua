-- Lua provided by RyzenAPI
-- Game: Myth

-- MAIN APPLICATION
addappid(2430410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430411, 1, "4215060d547d5578347bf86842d60b286505c021ea35c37dd140d5a14543d422")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
