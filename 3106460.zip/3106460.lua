-- Lua provided by RyzenAPI
-- Game: Wobbly Life Soundtrack

-- MAIN APPLICATION
addappid(3106460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106461, 1, "c4e05dc23c4bd4fbb8ac04b9f8e9f6bf92067182615b17a010ab9a62acae6032")
