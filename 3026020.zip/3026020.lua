-- Lua provided by RyzenAPI
-- Game: Klaroro - Abyss of the Soul Demo

-- MAIN APPLICATION
addappid(3026020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026021, 1, "13a381cf6c2adb45c6c5fb2f057e76f77e5e0f7afde7485677fbe4d8f2623539")

