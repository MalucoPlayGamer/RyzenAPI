-- Lua provided by RyzenAPI
-- Game: addappid(1095740)

-- MAIN APPLICATION
addappid(1095740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095741, 1, "01948d5390a0cbea33679bb042578587b39aa2c980aeda0634cad29124fb895e")
