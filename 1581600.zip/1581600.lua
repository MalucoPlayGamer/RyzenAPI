-- Lua provided by SkyAPI 
-- Game: AppID 1581600
addappid(1581600)
addappid(1581601, 1, "0f566fbc25c6b1cdcacbbc039115946c6c7e3376e653dfbb9a7ce824ae2bc7b8")
