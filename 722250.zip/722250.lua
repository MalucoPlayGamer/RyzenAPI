-- Lua provided by RyzenAPI
-- Game: Feeding The Monster

-- MAIN APPLICATION
addappid(722250)

-- MAIN APP DEPOTS / PACKAGES
addappid(722251, 1, "d278606111b3e7524bb0a8980ddc3eff369146c7068aa9b1d0d81cdd8c8c4146")

