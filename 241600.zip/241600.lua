-- Lua provided by RyzenAPI
-- Game: Rogue Legacy

-- MAIN APPLICATION
addappid(241600)

-- MAIN APP DEPOTS / PACKAGES
addappid(241601, 1, "89e4dbdeb969e3449ef7a74b752dce6916234e4e8c433df9581fedbc02f9f9a8")
addappid(241602, 1, "a802459ed35573315c9056cc418932aed67b70e4f694a42f17ca0688bfe14505")
addappid(241603, 1, "6d5ece4209088e4feafe00351d28f99e332b1edf7a98c016aba9797b5ba34cba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
