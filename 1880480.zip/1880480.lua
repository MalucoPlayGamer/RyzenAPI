-- Lua provided by SkyAPI 
-- Game: AppID 1880480
addappid(1880480)
addappid(1880481, 1, "f866c8a66eb3ce03bb7a86aa3ba00464ae8e2c63c9a0ee4181f70dd0aa5ea5b8")
