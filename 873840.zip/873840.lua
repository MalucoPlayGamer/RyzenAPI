-- Lua provided by RyzenAPI
-- Game: Truck & Logistics Simulator

-- MAIN APPLICATION
addappid(873840)
-- Game: addappid(873840)

-- MAIN APP DEPOTS / PACKAGES
addappid(873841, 1, "30b2c3f522af72ce2cd442603a860f70c745e193edd37f4fc12c502862dd162e")
