-- Lua provided by SkyAPI 
-- Game: AppID 910050
addappid(910050)
addappid(910051, 1, "661f12fd599363960024026b5eb6a16da692a9a1b168a186e790a0febe52398d")
