-- Lua provided by RyzenAPI
-- Game: Kingdom Clicker

-- MAIN APPLICATION
addappid(816060)

-- MAIN APP DEPOTS / PACKAGES
addappid(816061, 1, "f9f40a44a9234d8da20cacd660d4b53e3a5de3ae24cf8e8de7f10358b81ef360")
