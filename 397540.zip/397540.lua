-- Lua provided by RyzenAPI
-- Game: Borderlands 3

-- MAIN APPLICATION
addappid(397540)
addappid(1232240)
addappid(1232250)
addappid(1232251)
addappid(1232252)
addappid(1232253)
addappid(1232254)
addappid(1232255)
addappid(1233062)
addappid(1256890)
addappid(1396470)
addappid(1396471)
addappid(1396472)
addappid(1396473)
addappid(1396474)
addappid(1537990)
addappid(1537991)
addappid(1537992)
addappid(1537993)

-- MAIN APP DEPOTS / PACKAGES
addappid(397541, 1, "88f77a801ca63cd0492b040858a57b62b748c774c5a1046d397b58b0c2cf836c")
addappid(397542, 1, "64915689531d1c5e242ad493e198ee1a61a5757f84de8ed77e09f08a76c30847")
addappid(1232256, 0, "7de46f8b2674a72ce84a910d86a255f02e6225ba00490119d3281e7dc2a4bcfa")
addappid(1232257, 0, "201e40a8cc715029d3b43ea2fc07f83de91ddf73484115ed3225014584d6e6b4")
addappid(1233060, 0, "f9f0b5e50d586c47ec01453408ce945c3038a22649a7b87505bf8bc91bc90486")
addappid(1233061, 0, "72210c059f9f275f8f1c144209d5aa3a37c079f001ab59cabb1a114e606773cf")
addappid(1361830, 0, "b601b7eb94614a5eb2b6f877b86e12c6fb79f7527ff4b1b7bf59d0a8b5b088aa")
addappid(1361831, 0, "4a0968e321be58b271250dc3ab2ada1f3917b543d06f70e18f6da4a425844e5c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
