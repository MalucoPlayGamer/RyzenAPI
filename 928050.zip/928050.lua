-- Lua provided by RyzenAPI
-- Game: Between the Stars Demo

-- MAIN APPLICATION
addappid(928050)

-- MAIN APP DEPOTS / PACKAGES
addappid(928051, 1, "c5855d1836359623f690f5f8ec895a9639b37e7a7379866819768184ba0ef295")
