-- Lua provided by RyzenAPI
-- Game: Game: Femida

-- MAIN APPLICATION
addappid(1167640)
-- Game: addappid(1167640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167641, 1, "633f6cd24e4fbc604989adcc6d03c715b2e87d756949ad8329e491201694d0ca")
