-- Lua provided by RyzenAPI
-- Game: 1181470

-- MAIN APPLICATION
addappid(1181470)
-- Game: addappid(1181470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181471, 1, "07bef5360c4040aedcb6b6b0ba05a43ad472c40a91e72b4fd9b9f4e1a0a18195")
