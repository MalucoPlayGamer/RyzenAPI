-- Lua provided by RyzenAPI
-- Game: addappid(1659590)

-- MAIN APPLICATION
addappid(1659590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659591, 1, "41e275df09817ca72e52bdc7985efc8c09ade705ba220fbae43d9bafbb3e9bd9")
