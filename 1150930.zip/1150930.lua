-- Lua provided by RyzenAPI
-- Game: 1150930

-- MAIN APPLICATION
addappid(1150930)
-- Game: addappid(1150930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150931, 1, "832039f7111ddb64fa224b41b2a0a176e3424b495cedfdd3654f7f765058722f")
