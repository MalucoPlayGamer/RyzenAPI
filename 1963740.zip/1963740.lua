-- Lua provided by RyzenAPI
-- Game: Succubus Puttel

-- MAIN APPLICATION
addappid(1963740)
addappid(2436270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963741, 1, "4fce33cedddc26150bcc9f3c4e75e0358d4dceff561a3c64f094ed749252e536")

