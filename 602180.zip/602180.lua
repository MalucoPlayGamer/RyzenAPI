-- Lua provided by RyzenAPI
-- Game: Free Towns

-- MAIN APPLICATION
addappid(602180)

-- MAIN APP DEPOTS / PACKAGES
addappid(602182,0,"14c0c484d6792a4029ffe41e05c2afb4ce43fec5662ad7936c99770243f72c39")

