-- Lua provided by RyzenAPI
-- Game: addappid(2564500)

-- MAIN APPLICATION
addappid(2564500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564501, 1, "563a30c6cef13e32912e50d210bb8a9e5bfdf333b2698075ae63675c9142a2b5")
