-- Lua provided by RyzenAPI
-- Game: McBelle Manor Demo

-- MAIN APPLICATION
addappid(3271640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271641, 1, "94dceec1ed2af84f50080513bf76d98a2915af004f934bfeec28d510deea290a")

