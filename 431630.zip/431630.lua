-- Lua provided by RyzenAPI
-- Game: Action Legion

-- MAIN APPLICATION
addappid(431630)

-- MAIN APP DEPOTS / PACKAGES
addappid(431631, 1, "343ff33d779ce788ffa89674d5f1b0eb8dcfa3cd7dcc20d76fdafa9d4d8274e3")
addappid(464640, 0, "61b2e56c7aab320b61926f72016396f2b8ac4f1c4fdce41871ba18f8c954a31f")

