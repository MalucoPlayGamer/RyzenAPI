-- Lua provided by RyzenAPI
-- Game: Tales of Formentera

-- MAIN APPLICATION
addappid(3919390) -- Tales of Formentera

-- MAIN APP DEPOTS / PACKAGES
addappid(3919391, 1, "e7d4c35ebbe1cfc00654ec47af25fced6b5c2997674effb5339cbae80a3b7cb9") -- Depot 3919391

