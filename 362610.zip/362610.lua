-- Lua provided by RyzenAPI
-- Game: High On Racing

-- MAIN APPLICATION
addappid(362610)

-- MAIN APP DEPOTS / PACKAGES
addappid(362611, 1, "442617f555c47e5c71c873752cb58687dc9ca507a5ee5513090ed9e78a569887")

