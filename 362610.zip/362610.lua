-- Lua provided by RyzenAPI
-- Game: High On Racing

-- MAIN APPLICATION
addappid(362610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(362611, 1, "442617f555c47e5c71c873752cb58687dc9ca507a5ee5513090ed9e78a569887")

