-- Lua provided by RyzenAPI
-- Game: Forspoken Digital Mini Soundtrack

-- MAIN APPLICATION
addappid(1819224)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819224,0,"22d839a475940c1e3b4988b450533b75d17b662e25892b0c0bdfd2eccec337ed")

