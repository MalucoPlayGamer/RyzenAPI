-- Lua provided by RyzenAPI
-- Game: Game: Avaria: Chains of Lust

-- MAIN APPLICATION
addappid(1224690)
-- Game: addappid(1224690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224691, 1, "40c2cb7eee8e66c047f307038bfeef7661aa409541d1ceaafe7a986ea79ef96a")
