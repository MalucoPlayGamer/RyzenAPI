-- Lua provided by RyzenAPI
-- Game: Game: Palladise Island

-- MAIN APPLICATION
addappid(1569650)
-- Game: addappid(1569650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569651, 1, "8b0d629029a799b68e28972f4c0866f8a3e5bb670fff8fb010bd09b6ca05457e")
addappid(1569652, 1, "7c101e282c529065ea1d0fe88073c25f6ff644faa3a34600178db008204baea4")
