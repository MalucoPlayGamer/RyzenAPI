-- Lua provided by RyzenAPI
-- Game: Immersive APM

-- MAIN APPLICATION
addappid(3624760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3624761, 1, "aea121f67e62e7990db7565f9b7a060b00c5d4fb9d75137ae9d94022e99e235c")

