-- Lua provided by SkyAPI 
-- Game: 合成大西瓜 | Big watermelon
addappid(1564670)
addappid(1564671, 1, "637955c56da2990b807e8ae7c56e13a47b72854466c4a7c0617b8262943a327c")
addappid(1592570)
