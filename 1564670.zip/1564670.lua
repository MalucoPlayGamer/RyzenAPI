-- Lua provided by RyzenAPI
-- Game: 合成大西瓜 | Big watermelon

-- MAIN APPLICATION
addappid(1564670)
addappid(1592570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564671, 1, "637955c56da2990b807e8ae7c56e13a47b72854466c4a7c0617b8262943a327c")

