-- Lua provided by SkyAPI 
-- Game: Achilles: Survivor
addappid(2922410)
addappid(2922411, 1, "b9589ac336959faef6c6ef10cab6174bc34627b307d10cf57a6a05c645320ad6")
