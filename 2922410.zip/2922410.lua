-- 2922410's Lua and Manifest Created by Hubcap Manifest
-- Achilles: Survivor
-- Created: July 24, 2026 at 03:06:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 5
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(2922410, 1, "ebf08137aeaceaf14dcd6a8f7394b5902cdf788ca6ef79507cac4c58b4a232b7") -- Achilles: Survivor
-- MAIN APP DEPOTS
addappid(2922411, 1, "b9589ac336959faef6c6ef10cab6174bc34627b307d10cf57a6a05c645320ad6") -- Depot 2922411
setManifestid(2922411, "9137524809771073922", 6252970353)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Achilles - Immortal Legend Model (AppID: 3557650)
addappid(3557650)
addappid(3557650, 1, "76ae17e187eb0b7e04c670a5c90905bdb4934751e5f93655e766bd11920b89ad") -- Achilles - Immortal Legend Model - Depot 3557650
setManifestid(3557650, "3304827900205140196", 748405068)
-- Achilles Survivor - The Beast of the Labyrinth (AppID: 4315660)
addappid(4315660)
addappid(4315660, 1, "bfbf023536c30dac8447f1d507828c46727c14fef81cbe238103027845ac5dc5") -- Achilles Survivor - The Beast of the Labyrinth - Depot 4315660
setManifestid(4315660, "8629789049382213532", 47259269)
-- Achilles Survivor - The Cursed Necromancer (AppID: 4651480)
addappid(4651480)
addappid(4651480, 1, "766eed252a49fd39d1afac5b8cedee512f3612406b97563e87ae8d48e846b4fd") -- Achilles Survivor - The Cursed Necromancer - Depot 4651480
setManifestid(4651480, "1925144090309592442", 5143152)
-- Achilles Survivor - Odysseus The King of Ithaca (AppID: 4844140)
addappid(4844140)
addappid(4844140, 1, "53f483a942cb583133945589bbeccb3a48776145e4fe00071bb57eb3a51ae156") -- Achilles Survivor - Odysseus The King of Ithaca - Depot 4844140
setManifestid(4844140, "2532499311506871448", 2333258)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3950710) -- Achilles Survivor - Supporter Pack