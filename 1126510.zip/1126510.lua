-- Lua provided by RyzenAPI 
-- Game: AppID 1126510
addappid(1126510)
addappid(1126511, 1, "60b541b3fc4401ac8e814a98c5ebe32dcc7aa8312d4bd9e82c0b07a2c3263c5f")
