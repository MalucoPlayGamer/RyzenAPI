-- Lua provided by RyzenAPI
-- Game: AppID 1126510

-- MAIN APPLICATION
addappid(1126510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126511, 1, "60b541b3fc4401ac8e814a98c5ebe32dcc7aa8312d4bd9e82c0b07a2c3263c5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
