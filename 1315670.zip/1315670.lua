-- Lua provided by RyzenAPI
-- Game: addappid(1315670)

-- MAIN APPLICATION
addappid(1315670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315671, 1, "d270150ae3bb254260997e4fbee2022340d7e4cd6a3a50adf7f30d573b60aed7")
