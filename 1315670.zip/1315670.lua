-- Lua provided by RyzenAPI
-- Game: Asteroids 44 (For Four)

-- MAIN APPLICATION
addappid(1315670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1315671, 1, "d270150ae3bb254260997e4fbee2022340d7e4cd6a3a50adf7f30d573b60aed7")

