-- Lua provided by SkyAPI 
-- Game: AppID 1990120
addappid(1990120)
addappid(1990121, 1, "ed2260f1b550b29a7709f0fa13f85c03e6ba9c298f7e35239ea3d38d3763c102")
