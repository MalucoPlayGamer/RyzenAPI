-- Lua provided by RyzenAPI
-- Game: 697860

-- MAIN APPLICATION
addappid(697860)
-- Game: addappid(697860)

-- MAIN APP DEPOTS / PACKAGES
addappid(697861, 1, "8d59f362fd940d9a10dedaac97dc60854eb0aeb3480e0b420e8859c215e0817c")
