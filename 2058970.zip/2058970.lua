-- Lua provided by RyzenAPI
-- Game: For What Will Come

-- MAIN APPLICATION
addappid(2058970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058971, 1, "bafe9995c4e6304cadd2299d9be5837c969bed311a7c65b14bda832c81ac97e8")
