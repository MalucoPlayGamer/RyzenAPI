-- Lua provided by RyzenAPI
-- Game: For What Will Come

-- MAIN APPLICATION
addappid(2058970)
addappid(3182220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2058971, 1, "bafe9995c4e6304cadd2299d9be5837c969bed311a7c65b14bda832c81ac97e8")

