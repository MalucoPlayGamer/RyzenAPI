-- Lua provided by RyzenAPI
-- Game: Sex Adventures - Mile High Club

-- MAIN APPLICATION
addappid(1925230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925231, 1, "7cbe6c2ff75799e634165ff2786ec65949fc42a4ab433c207b30ed3f742d3b65")

