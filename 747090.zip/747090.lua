-- Lua provided by RyzenAPI
-- Game: Game: AppID 747090

-- MAIN APPLICATION
addappid(747090)
-- Game: addappid(747090)

-- MAIN APP DEPOTS / PACKAGES
addappid(747091, 1, "151c7c48484586ef28edef55f04dea2486937618e1d023921952cbe3cb652474")
