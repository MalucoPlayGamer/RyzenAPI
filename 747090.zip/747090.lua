-- Lua provided by RyzenAPI
-- Game: Deep Space: Unknown Universe

-- MAIN APPLICATION
addappid(747090)

-- MAIN APP DEPOTS / PACKAGES
addappid(747091, 1, "151c7c48484586ef28edef55f04dea2486937618e1d023921952cbe3cb652474")
