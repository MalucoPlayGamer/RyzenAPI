-- Lua provided by RyzenAPI
-- Game: addappid(1892400)

-- MAIN APPLICATION
addappid(1892400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892401, 1, "1a68eff2af9c61d9a1b2825e24073cc3d6205c48da983e7dbdfb53678465e1a4")
