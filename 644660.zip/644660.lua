-- Lua provided by RyzenAPI 
-- Game: AppID 644660
addappid(644660)
addappid(644661, 1, "09f6f918ee099bb25354d46a231021d0fe2c2740718190de32792bdc222e2107")
