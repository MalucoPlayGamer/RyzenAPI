-- Lua provided by RyzenAPI
-- Game: Lathe Safety Simulator

-- MAIN APPLICATION
addappid(644660)
-- Game: addappid(644660)

-- MAIN APP DEPOTS / PACKAGES
addappid(644661, 1, "09f6f918ee099bb25354d46a231021d0fe2c2740718190de32792bdc222e2107")
