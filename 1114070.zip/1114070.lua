-- Lua provided by RyzenAPI
-- Game: Game: My Child Lebensborn

-- MAIN APPLICATION
addappid(1114070)
-- Game: addappid(1114070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114071, 1, "235574d618fb28b276a232772f092c74e4dc15843be671a8fc8fd05bb4c870b5")
