-- Lua provided by RyzenAPI
-- Game: TANGLEWOOD

-- MAIN APPLICATION
addappid(837190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(837191,0,"fb5e398bb1657426412956978dc17486e2c19de9f3ea259c98e5579c23acd282")

