-- Lua provided by RyzenAPI
-- Game: Lianshi - Officer Ticket / 練師使用券

-- MAIN APPLICATION
addappid(956890)

-- MAIN APP DEPOTS / PACKAGES
addappid(956890,0,"d0b87846d81f96ac7ea277dfd5b73af68eb04695ecd8b8134c7525a5f46a66a6")

