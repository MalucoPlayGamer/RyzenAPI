-- Lua provided by RyzenAPI
-- Game: To Hell with Hell

-- MAIN APPLICATION
addappid(860660)

-- MAIN APP DEPOTS / PACKAGES
addappid(860661,0,"6cdf3e344704e367b9fd4702d529c34e869adf67ec076caf1683976f9d463eca")

