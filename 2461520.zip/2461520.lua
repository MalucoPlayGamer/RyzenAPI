-- Lua provided by RyzenAPI
-- Game: 2461520

-- MAIN APPLICATION
addappid(2461520)
-- Game: addappid(2461520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461521, 1, "1e122eca22fc3acc735416fef7c128d981ae085ff85813d616a9a47bb0cc5f21")
