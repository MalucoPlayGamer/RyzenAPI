-- Lua provided by RyzenAPI
-- Game: addappid(2426931)

-- MAIN APPLICATION
addappid(2426931)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426931,0,"30b65ae5700ef23c64e451ca5eef1569c408cde1e62c32a5fc69176acd1dcab6")
