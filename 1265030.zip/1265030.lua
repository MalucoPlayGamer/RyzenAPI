-- Lua provided by RyzenAPI
-- Game: addappid(1265030)

-- MAIN APPLICATION
addappid(1265030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265032,0,"1cd4be8c6d26c178c71746a0572ea3ca044b69eca169ce14403df38913acd64f")
