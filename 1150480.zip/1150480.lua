-- Lua provided by RyzenAPI
-- Game: AppID 1150480

-- MAIN APPLICATION
addappid(1150480)
-- Game: addappid(1150480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150481, 1, "dcb5a3bfb37b0559c96489f117add9160457e22cc3f795d802d6e4fbe0d6b4e0")
