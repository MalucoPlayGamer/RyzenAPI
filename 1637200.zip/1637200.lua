-- Lua provided by RyzenAPI
-- Game: addappid(1637200)

-- MAIN APPLICATION
addappid(1637200)
addappid(1637201)
addappid(1637203)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637202,0,"afe121e19cbd0f85b7a23e8d0a8cb84ec9f3c8e943ac76cd8b5c7d1f532fa131")
