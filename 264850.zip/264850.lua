-- Lua provided by RyzenAPI
-- Game: 264850

-- MAIN APPLICATION
addappid(264850)
-- Game: addappid(264850)

-- MAIN APP DEPOTS / PACKAGES
addappid(264851, 1, "c06dc36e08c4def18355d454ef6e0c720157411f1924913a0600bf0fdaa642da")
