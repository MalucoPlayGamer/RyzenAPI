-- Lua provided by RyzenAPI
-- Game: Heroes Of Maidan 2

-- MAIN APPLICATION
addappid(1010070)
-- Game: addappid(1010070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010071, 1, "ae557b6d5594230a6659d29fbb523b0c795f5140ad25de68311b32ab7085d786")
