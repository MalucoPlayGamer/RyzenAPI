-- Lua provided by RyzenAPI
-- Game: Exodus

-- MAIN APPLICATION
addappid(313960)

-- MAIN APP DEPOTS / PACKAGES
addappid(313961, 1, "00efa568ccea66ceb25e83d2a41fa6927e9284ab78b43a667477f769e64b3e04")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
