-- Lua provided by RyzenAPI
-- Game: Exodus

-- MAIN APPLICATION
addappid(313960)

-- MAIN APP DEPOTS / PACKAGES
addappid(313961, 1, "00efa568ccea66ceb25e83d2a41fa6927e9284ab78b43a667477f769e64b3e04")

