-- Lua provided by RyzenAPI
-- Game: Heroes of Mount Dragon Playtest

-- MAIN APPLICATION
addappid(3655220)
-- Game: addappid(3655220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655221, 1, "d6bede9f044beee33a3502430ef3ebeef51854eda36f1ea0f456d84238b21606")
