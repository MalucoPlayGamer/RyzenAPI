-- Lua provided by RyzenAPI
-- Game: Peaky Blinders: The King's Ransom Complete Edition

-- MAIN APPLICATION
addappid(1903670)
-- Game: addappid(1903670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903671, 1, "e6fd5798589620a9bf2e7ee18050e92e7748c673d294f16105f7f194c8713e7a")
