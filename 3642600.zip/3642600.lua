-- Lua provided by RyzenAPI
-- Game: 3642600

-- MAIN APPLICATION
addappid(3642600)
-- Game: addappid(3642600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3642601, 1, "a27e0fdcdb0500628722dce0da306d103685da2322351a2d15c0b0a5ef139b59")
