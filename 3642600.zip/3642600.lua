-- Lua provided by RyzenAPI
-- Game: Forest

-- MAIN APPLICATION
addappid(3642600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3642601, 1, "a27e0fdcdb0500628722dce0da306d103685da2322351a2d15c0b0a5ef139b59")

