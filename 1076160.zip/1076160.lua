-- Lua provided by RyzenAPI
-- Game: addappid(1076160)

-- MAIN APPLICATION
addappid(1076160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076162,0,"180fe6de8201be6c1ab969105660e0ecd48339b08119cbf85b0dd48096faee67")
