-- Lua provided by RyzenAPI
-- Game: Command: Modern Operations

-- MAIN APPLICATION
addappid(1076160)
addappid(1178900)
addappid(1182290)
addappid(1182291)
addappid(1182292)
addappid(1182293)
addappid(1182294)
addappid(1182300)
addappid(1182301)
addappid(1182302)
addappid(1182303)
addappid(1182304)
addappid(1182305)
addappid(1182306)
addappid(1182307)
addappid(1182308)
addappid(1182309)
addappid(1228660)
addappid(1309690)
addappid(1438050)
addappid(1594140)
addappid(1712070)
addappid(2141010)
addappid(2306370)
addappid(2516830)
addappid(2516840)
addappid(2676020)
addappid(3979120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076160,0,"6776ff97399d0a2139ca691c4d9e166e010135a8daa679b1847c2d76781148b1")
addappid(1076161,0,"7382251e4b0b939ed609909546aa5b1f2eba470796291b9b7a586fc7be38612d")
addappid(1076162,0,"180fe6de8201be6c1ab969105660e0ecd48339b08119cbf85b0dd48096faee67")

