-- Lua provided by RyzenAPI
-- Game: 東方霊守祀 ~ Consciousness' Unity of Opposites Demo

-- MAIN APPLICATION
addappid(1728920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728921, 1, "8b02b645e24186c897afaf6f22e9426cfc6705063aefcfa7ad76696919ab7904")

