-- Lua provided by RyzenAPI
-- Game: 1864080

-- MAIN APPLICATION
addappid(1864080)
-- Game: addappid(1864080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864081, 1, "9eab772e4fc945c1339c524b58c69993cc3e111d357036eaba8e4c34eaefddb3")
