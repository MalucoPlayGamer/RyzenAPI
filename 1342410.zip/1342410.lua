-- Lua provided by RyzenAPI
-- Game: 1342410

-- MAIN APPLICATION
addappid(1342410)
-- Game: addappid(1342410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342411, 1, "a104d17a1b51371e37842330a08e2cf48dfff15aec2552964e44a99642cc98e8")
