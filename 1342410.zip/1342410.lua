-- Lua provided by RyzenAPI
-- Game: [TDA02] Muv-Luv Unlimited: THE DAY AFTER - Episode 02 REMASTERED

-- MAIN APPLICATION
addappid(1342410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1342411, 1, "a104d17a1b51371e37842330a08e2cf48dfff15aec2552964e44a99642cc98e8")

