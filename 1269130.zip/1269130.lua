-- Lua provided by RyzenAPI
-- Game: Memories Off -Innocent Fille- Sound Collection

-- MAIN APPLICATION
addappid(1269130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269131, 1, "5b87cf1c57bbf59a27df5db850271aaa8060a9f49c0034e47df09a3b6b330377")
