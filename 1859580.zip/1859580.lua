-- Lua provided by SkyAPI 
-- Game: Full Void
addappid(1859580)
addappid(1859581, 1, "ee8af646e98107cfd11315fbfd2d4a6ff66f483751c6babd98cf4a311e9725e5")
addappid(1859582, 1, "70293326a9453d2bea02b93411aae3c0eb49aa217aaca38c75caabee10a8bc77")
addappid(1859583, 1, "3cca4db1a995e16246f699ae4dbd01908398edd922f848d5d39099d5f6d8e110")
