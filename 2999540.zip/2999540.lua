-- Lua provided by RyzenAPI
-- Game: Pixelitos - Spritle Royale

-- MAIN APPLICATION
addappid(2999540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999541, 1, "1617b724baf82d246521b5029a1210c690d4f798fc0c72c2a9091adde9eef13e")

