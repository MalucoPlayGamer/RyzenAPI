-- Lua provided by RyzenAPI
-- Game: Heartless & Dreadful : Return by 72 Hours

-- MAIN APPLICATION
addappid(1701890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701891, 1, "5bd4396ec404fe7ca4ae33cb91574681b58e83322372a060e8e9da339165e874")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
