-- Lua provided by RyzenAPI
-- Game: Heartless & Dreadful : Return by 72 Hours

-- MAIN APPLICATION
addappid(1701890)
-- Game: addappid(1701890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701891, 1, "5bd4396ec404fe7ca4ae33cb91574681b58e83322372a060e8e9da339165e874")
