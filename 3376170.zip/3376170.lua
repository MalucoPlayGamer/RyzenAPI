-- Lua provided by RyzenAPI 
-- Game: KLETKA - Original Soundtrack
addappid(3376170)
addappid(3376171, 1, "dfc3d945444d68cb1f4bca48d6b68dc7b814c0a6270d1105e51698db708c8d27")
