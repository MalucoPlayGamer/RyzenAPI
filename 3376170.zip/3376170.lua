-- Lua provided by RyzenAPI
-- Game: 3376170

-- MAIN APPLICATION
addappid(3376170)
-- Game: addappid(3376170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376171, 1, "dfc3d945444d68cb1f4bca48d6b68dc7b814c0a6270d1105e51698db708c8d27")
