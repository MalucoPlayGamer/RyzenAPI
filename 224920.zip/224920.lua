-- Lua provided by SkyAPI 
-- Game: AppID 224920
addappid(224920)
addappid(224921, 1, "22fda304b32c7e481e4c941e0d281a4fa890587404ae35b475397705d6dcdc23")
