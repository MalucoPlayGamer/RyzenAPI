-- Lua provided by RyzenAPI
-- Game: AppID 224920

-- MAIN APPLICATION
addappid(224920)
-- Game: addappid(224920)

-- MAIN APP DEPOTS / PACKAGES
addappid(224921, 1, "22fda304b32c7e481e4c941e0d281a4fa890587404ae35b475397705d6dcdc23")
