-- Lua provided by RyzenAPI
-- Game: Line of Sight

-- MAIN APPLICATION
addappid(436520)
addappid(520900)
addappid(557290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(436521, 1, "15196299f4f3afa220f0fb7ee281470ebd1cb8b612fb0e894dc357ecb73ac301")
