-- Lua provided by RyzenAPI
-- Game: addappid(436520)

-- MAIN APPLICATION
addappid(436520)

-- MAIN APP DEPOTS / PACKAGES
addappid(436521, 1, "15196299f4f3afa220f0fb7ee281470ebd1cb8b612fb0e894dc357ecb73ac301")
