-- Lua provided by RyzenAPI
-- Game: GUILTY GEAR

-- MAIN APPLICATION
addappid(850980)

-- MAIN APP DEPOTS / PACKAGES
addappid(850981, 1, "995d2b238434ddfaf5cc75daf92385f9dbb15a351b451e27eb8be2f33fa71373")

