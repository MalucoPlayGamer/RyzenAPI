-- Lua provided by RyzenAPI 
-- Game: Hashihime of the Old Book Town
addappid(1039940)
addappid(1039941, 1, "fe366551e99490c94afdcd69f68536072f203461dbd46dfa93748e612e6f4218")
