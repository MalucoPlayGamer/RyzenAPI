-- Lua provided by RyzenAPI
-- Game: Ancestors Legacy Dedicated Server

-- MAIN APPLICATION
addappid(983360)

-- MAIN APP DEPOTS / PACKAGES
addappid(983361, 1, "551b51af8fb4a88bb5de331f359e2578f43e305e877ceb98bd75613c8a979f38")
