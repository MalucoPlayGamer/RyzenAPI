-- Lua provided by RyzenAPI
-- Game: Peaches and Dreams

-- MAIN APPLICATION
addappid(2839010)
-- Game: addappid(2839010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839011, 1, "896198516cfaaa7b9d806ba7c7d92c3ef0645335e0a0dce4934528a096b3f016")
addappid(2839012, 1, "f09912d97c68bc914a85ab83536192e67216c44f3345938fee849130ac42cf7d")
