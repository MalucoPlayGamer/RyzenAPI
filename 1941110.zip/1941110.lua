-- Lua provided by RyzenAPI
-- Game: Higurashi When They Cry Hou - Rei

-- MAIN APPLICATION
addappid(1941110)
-- Game: addappid(1941110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941111, 1, "5ca0bd42a5fc7976a40740b737ee987291e62dbc0307b9a699a59f7ce22a0c58")
