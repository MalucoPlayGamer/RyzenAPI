-- Lua provided by RyzenAPI
-- Game: AppID 575550

-- MAIN APPLICATION
addappid(575550)
-- Game: addappid(575550)

-- MAIN APP DEPOTS / PACKAGES
addappid(575551, 1, "521995f7ba32d81ffd95c47c201dd86e633adca13c70144e1d811ce88cc4901e")
addappid(575552, 1, "96a051ffc7c273c8d1c8ce04135a72e2c7c28f918349c35f8c1f51dd9e635a91")
