-- Lua provided by RyzenAPI
-- Game: Game: The Sims™ 4 Sweet Allure Kit

-- MAIN APPLICATION
addappid(3415990)
addappid(3500140)
addappid(3500142)
addappid(3500143)
addappid(3500144)
addappid(3500145)
addappid(3500146)
addappid(3500147)
-- Game: addappid(3415990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3415991, 1, "62b9af30db973b20b8b076f88da3cf1f0710016aca5f7be83b368e841edf332a")
addappid(3415993, 1, "073cb14cb71d0844d9844018d258792c064c786d1231b2ab9da5f63b35663977")
addappid(3415996, 1, "93b8db100aad4d485915eb04e9ee2b7dd1b95d32c1ffbcfc2c116600a8cd3624")
addappid(3415997, 1, "c0a79b05544f3b7b2dbcb6bd7eff96a0ef85c0d9d9461b64e4aa859badfe603d")
addappid(3415998, 1, "87a2d5893553a8e0b91bbd11deaa7afa9735966b9e689e881d36ef0210b4a7e4")
addappid(3500141, 0, "a902c90e4866806749fa4a0464d4a16d9ff0a992213156a1837bb8f5c533cbfa")
addappid(3500148, 0, "254dc343ed5ec38e81fa9ac8f0a81fd494189a6b79229a5cfbe91116b79ccf86")
