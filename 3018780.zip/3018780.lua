-- Lua provided by RyzenAPI
-- Game: 辩经 Demo

-- MAIN APPLICATION
addappid(3018780)
-- Game: addappid(3018780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3018781, 1, "9b81e6bb79919a612628cc9c4ed14f8a4ba60da0f8853d9e307c126af82dbc62")
