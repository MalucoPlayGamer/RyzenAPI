-- Lua provided by RyzenAPI
-- Game: Brigador - Vol. I

-- MAIN APPLICATION
addappid(1239510)
-- Game: addappid(1239510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239512,0,"36f97465608c9aa4feccc769dba708cb9ee56ab1302a5827a30e3aeb5a084b25")
addappid(1239515,0,"be3550b26366df457f2f6ff4dd52d4b4b5541b859d006a625d740905c78a1662")
addappid(1239518,0,"9bd0818ab09ad93f61fb41174d32f6b9fff6e6f81e59600aaa58f0d2ec772dad")
