-- Lua provided by RyzenAPI
-- Game: 侠客风云传(Tale of Wuxia)

-- MAIN APPLICATION
addappid(377530)
-- Game: addappid(377530)

-- MAIN APP DEPOTS / PACKAGES
addappid(377531, 1, "baf580e3a4f63f18f5640acbf9ebaf0e9176853b3d5fcd1e83045e2b0a830cb4")
addappid(377532, 1, "5d275e85cd7052337770853853867646c2e4c88cca71dc5124f96e52bed4fd2c")
addappid(377533, 1, "cd7bf09731b3a80e18602c62dd6276b069f6ef001a0574a136bd3750eaef685d")
