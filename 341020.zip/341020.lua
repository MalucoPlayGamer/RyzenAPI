-- Lua provided by RyzenAPI
-- Game: Chronicles of Teddy

-- MAIN APPLICATION
addappid(341020)

-- MAIN APP DEPOTS / PACKAGES
addappid(341025,0,"fde138a4dab447bf7720948899f3628a4d55f0e87d07f21ee0e32ae3c5969b93")
addappid(355830,0,"eee4d621085bc95b21dfd8c0ce03c1998b92756f9a56dad542650294af695b9e")

