-- Lua provided by RyzenAPI 
-- Game: 三国志猛将传
addappid(1295230)
addappid(1295231, 1, "d8e3353736d0fef58af2fbd09af389ca5dd1459965e6e02fbbd840fee3fc6973")
