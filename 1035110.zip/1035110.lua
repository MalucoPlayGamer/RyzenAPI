-- Lua provided by RyzenAPI
-- Game: Moonrise Fall

-- MAIN APPLICATION
addappid(1035110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035111, 1, "425d98056999ba9684d17a1e86966adc2d2e2e21491165744f8b662a23d9d828")
addappid(1168780, 0, "d42758f3e12f81e0cd114ecbf420345e190e942501e947a315072e1e086564d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
