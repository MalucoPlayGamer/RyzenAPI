-- Lua provided by RyzenAPI
-- Game: Natsuno-Kanata: Beyond Summer Demo

-- MAIN APPLICATION
addappid(2977470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2977471, 1, "baaea750282a9c9fa9d203e8db4429b660127f094a1146fbc60549fe3434b720")

