-- Lua provided by RyzenAPI
-- Game: Nickelodeon All-Star Brawl 2

-- MAIN APPLICATION
addappid(2017080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017081, 1, "0d1771cbda6e61241391465fd9657ccf0f556b6cee9a7d201c8c9ac02ab45bf8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2587090)
addappid(2587100)
addappid(2587120)
addappid(2750040)
addappid(2750050)
addappid(2750060)
addappid(2750070)
