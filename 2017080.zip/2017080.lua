-- Lua provided by SkyAPI 
-- Game: Nickelodeon All-Star Brawl 2
addappid(2017080)
addappid(2017081, 1, "0d1771cbda6e61241391465fd9657ccf0f556b6cee9a7d201c8c9ac02ab45bf8")
