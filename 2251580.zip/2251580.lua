-- Lua provided by RyzenAPI
-- Game: I, the Forgotten One

-- MAIN APPLICATION
addappid(2251580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251581, 1, "c211cb7c048179c80e164b87c8359ee3e18dc550fff08e51ef064896ab79ee8d")

