-- Lua provided by RyzenAPI
-- Game: Lost Cosmonauts ARG

-- MAIN APPLICATION
addappid(933050)

-- MAIN APP DEPOTS / PACKAGES
addappid(933051, 1, "c37b59a7ac95f7f669f788e2ffd6890d21aee1e1bf8f19ca375356bd1b5f3c82")
