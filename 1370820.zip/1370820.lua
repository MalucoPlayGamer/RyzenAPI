-- Lua provided by RyzenAPI
-- Game: Game: Welcome to the Polyverse

-- MAIN APPLICATION
addappid(1370820)
-- Game: addappid(1370820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370821, 1, "8f7b23e1ef5c0efc6e6d86c86aa2eee06cb2dbac6d8466c07541bd1cc74ff912")
