-- Lua provided by RyzenAPI 
-- Game: Welcome to the Polyverse
addappid(1370820)
addappid(1370821, 1, "8f7b23e1ef5c0efc6e6d86c86aa2eee06cb2dbac6d8466c07541bd1cc74ff912")
