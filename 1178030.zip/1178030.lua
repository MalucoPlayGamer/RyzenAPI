-- Lua provided by RyzenAPI
-- Game: Game: Star Fetchers

-- MAIN APPLICATION
addappid(1178030)
-- Game: addappid(1178030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178031, 1, "bdcb16b0b270b507d9380f58e881487decb980d28f679f58461c81e389c115eb")
addappid(1178032, 1, "c3ddd4f52609dc2d46e8c484ad495085161321b8d262f919e8ffc18051aba5ac")
addappid(1178035, 1, "d85764370bc41ef151aea19f73ba98fcd7ff8743de8a8d6ad00c52d01edb2dff")
