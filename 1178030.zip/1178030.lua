-- Lua provided by RyzenAPI
-- Game: Star Fetchers

-- MAIN APPLICATION
addappid(1178030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178031, 1, "bdcb16b0b270b507d9380f58e881487decb980d28f679f58461c81e389c115eb")
addappid(1178032, 1, "c3ddd4f52609dc2d46e8c484ad495085161321b8d262f919e8ffc18051aba5ac")
addappid(1178035, 1, "d85764370bc41ef151aea19f73ba98fcd7ff8743de8a8d6ad00c52d01edb2dff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1234570)
addappid(2869630)
