-- Lua provided by RyzenAPI
-- Game: Mage of the Olekta Desert

-- MAIN APPLICATION
addappid(1342110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342111, 1, "586703cb6807315d38d5150cf9f95b06f7e49af4897bffb06518395cfbc4ea64")
addappid(1342112, 1, "95754d7ed5af1f17812ff37634cdf900bfcd9fb7b1cad549824c874ab3829847")
addappid(1342113, 1, "dbcc1217334e27c36b1ff6841f3a8ed8144460ec63c0f0866607e0d8c39bfdd5")
