-- Lua provided by RyzenAPI
-- Game: addappid(1454460)

-- MAIN APPLICATION
addappid(1454460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454461, 1, "ae5248fa08988845f5d09c09dcdccae6ec67867cc35e872a48e36d23b2dff653")
addappid(1454462, 1, "d8b137a3619297e16efb13204c1572ac6eb75ad44fbaedd304dd07948f488974")
