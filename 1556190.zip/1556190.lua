-- Lua provided by RyzenAPI
-- Game: Game: My Married Cousin's Need for Seed

-- MAIN APPLICATION
addappid(1556190)
-- Game: addappid(1556190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556191, 1, "aefae3c5c997b1cef34e9d2905f4d3b864a28af02584c8660c2d5707607117a2")
