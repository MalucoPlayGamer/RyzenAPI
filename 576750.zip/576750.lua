-- Lua provided by RyzenAPI
-- Game: Ropes And Dragons VR

-- MAIN APPLICATION
addappid(576750)
-- Game: addappid(576750)

-- MAIN APP DEPOTS / PACKAGES
addappid(576751, 1, "c3a3dbfb062b2c52fede7150c0e383cfcc69fadd4cd859c0588183e4b9d6d0e4")
