-- Lua provided by RyzenAPI
-- Game: 3015270

-- MAIN APPLICATION
addappid(3015270)
-- Game: addappid(3015270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015271, 1, "1bb4faf6bc3ed9dffb3076d3bdbff16c13cc693a57982a85929e8d9df3458645")
