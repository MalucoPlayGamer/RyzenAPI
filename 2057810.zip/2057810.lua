-- Lua provided by RyzenAPI
-- Game: Chef: Pizza & Baked Goods

-- MAIN APPLICATION
addappid(2057810)
-- Game: addappid(2057810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057812,0,"88a5874ae682fd9ad13de6caeb924de1253a0b7515fb5e844d15d6351f84fa59")
