-- Lua provided by RyzenAPI
-- Game: Call of Duty: Black Ops III – Mod Tools

-- MAIN APPLICATION
addappid(455130)

-- MAIN APP DEPOTS / PACKAGES
addappid(455131, 1, "b01eac23abbea7eb2aa2dd1ae6b14f35a7284a4bdab649ffc00a93aad54646a5")
addappid(499270, 0, "521ae6cae58616250ad8e1630b676ead0d31ba92e67ff835170b7dd8fc61484d")

