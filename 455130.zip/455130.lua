-- Lua provided by SkyAPI 
-- Game: AppID 455130
addappid(455130)
addappid(455131, 1, "b01eac23abbea7eb2aa2dd1ae6b14f35a7284a4bdab649ffc00a93aad54646a5")
addappid(499270, 0, "521ae6cae58616250ad8e1630b676ead0d31ba92e67ff835170b7dd8fc61484d")
