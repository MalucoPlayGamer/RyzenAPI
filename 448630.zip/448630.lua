-- Lua provided by RyzenAPI
-- Game: Rabiez: Epidemic

-- MAIN APPLICATION
addappid(448630)

-- MAIN APP DEPOTS / PACKAGES
addappid(448631, 1, "ec1ab7eca5d492492124e645ca839f6afb2137703e02b51e765b62e461306c10")

