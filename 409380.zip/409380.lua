-- Lua provided by RyzenAPI
-- Game: Among the Heavens

-- MAIN APPLICATION
addappid(409380)

-- MAIN APP DEPOTS / PACKAGES
addappid(409381, 1, "2ee2cef992798a2f6a894e33ee5fed21304f6868af7b347d5573244cb15a3d1a")
addappid(409382, 1, "639c61dd3cb6e89196c98cb791abd85735a5fd17721937998c1abd690ccd49b7")
addappid(409383, 1, "0932fa9fbb873c5b236b42688d52de9e61a8017ac7f0ab4bec9f71c0bae488d1")

