-- Lua provided by RyzenAPI
-- Game: Viking Chronicles: Tale of the lost Queen

-- MAIN APPLICATION
addappid(1344140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344141, 1, "5e74308a8910041b2496232f71ef4124e22739dbf19fe41c2aff4ec26349a74d")
