-- Lua provided by RyzenAPI
-- Game: Ticy Adventure Club : Queen of the Spring

-- MAIN APPLICATION
addappid(2448980)
