-- Lua provided by RyzenAPI
-- Game: addappid(410490)

-- MAIN APPLICATION
addappid(410490)

-- MAIN APP DEPOTS / PACKAGES
addappid(410492,0,"d0aee839792a027cafb999550cafa20e2d3f571d1587e7c2c480062918a9e13d")
