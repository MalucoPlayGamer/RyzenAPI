-- Lua provided by RyzenAPI
-- Game: setManifestid(410492,"8722353797813860694")

-- MAIN APPLICATION
addappid(410490)
-- Game: addappid(410490)

-- MAIN APP DEPOTS / PACKAGES
addappid(410492,0,"d0aee839792a027cafb999550cafa20e2d3f571d1587e7c2c480062918a9e13d")
