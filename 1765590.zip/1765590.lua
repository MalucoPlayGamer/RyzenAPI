-- Lua provided by RyzenAPI
-- Game: addappid(1765590)

-- MAIN APPLICATION
addappid(1765590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765591, 1, "a106fc65c194d24a857b4fabc65320337b7cd8d5da53f2145fa7fcf6a1a52577")
