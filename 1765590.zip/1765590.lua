-- Lua provided by RyzenAPI
-- Game: Workshop Tools

-- MAIN APPLICATION
addappid(1765590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765591, 1, "a106fc65c194d24a857b4fabc65320337b7cd8d5da53f2145fa7fcf6a1a52577")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
