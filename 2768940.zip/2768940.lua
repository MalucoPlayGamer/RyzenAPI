-- Lua provided by RyzenAPI
-- Game: AppID 2768940

-- MAIN APPLICATION
addappid(2768940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768941, 1, "4c1595465c88ce8ee34eb59be830d2af4e69cb445b47e40e9ecacbf9b21eacbc")
