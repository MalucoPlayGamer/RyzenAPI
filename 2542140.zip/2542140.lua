-- Lua provided by RyzenAPI
-- Game: Ketz: Galactic Overlords

-- MAIN APPLICATION
addappid(2542140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542141, 1, "50e47ffab2488aef15a16475f5b3c90cf9940a35cf1d789bfa26aeb431cd9fbf")
