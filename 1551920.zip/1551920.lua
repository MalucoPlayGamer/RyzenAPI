-- Lua provided by RyzenAPI
-- Game: Whisper Trip

-- MAIN APPLICATION
addappid(1551920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551921, 1, "f4a8533443c697a6e38d4b06d03f6188c9b98e0b4f03859d6fb1f09e85fc821c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
