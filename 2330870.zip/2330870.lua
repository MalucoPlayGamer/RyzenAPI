-- Lua provided by RyzenAPI
-- Game: CD 2: Trap Master

-- MAIN APPLICATION
addappid(2330870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330871, 1, "de92f1d5e030e05bc7534ad3e45745a9bd0c0fbfb525ff03a153d74c5b720abf")
addappid(2330872, 1, "b29e0598c6ffdfa5989af5390f83dfaa03fa6c105cd108dafde284cd59de38d1")

