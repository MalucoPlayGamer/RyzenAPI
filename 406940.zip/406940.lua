-- Lua provided by RyzenAPI
-- Game: Dub Dash

-- MAIN APPLICATION
addappid(406940)
-- Game: addappid(406940)

-- MAIN APP DEPOTS / PACKAGES
addappid(406941, 1, "641f7fdb9b95b51d702b54583e73cf48770b1da18c272dd8362fe13f69a30a47")
