-- Lua provided by RyzenAPI
-- Game: Dub Dash

-- MAIN APPLICATION
addappid(406940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(406941, 1, "641f7fdb9b95b51d702b54583e73cf48770b1da18c272dd8362fe13f69a30a47")

