-- Lua provided by RyzenAPI
-- Game: Successor Playtest

-- MAIN APPLICATION
addappid(1671450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671451, 1, "9eddc76fcd0dc898c425fc049cdbcc1395d07ab679ee6b5b607957a075feaacf")
