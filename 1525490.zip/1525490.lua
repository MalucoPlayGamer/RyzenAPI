-- Lua provided by RyzenAPI
-- Game: Game: 异世界攻略组 Another World Adventure

-- MAIN APPLICATION
addappid(1525490)
-- Game: addappid(1525490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525491, 1, "398276cb21c4fc9e3f8ebd67e03946ccc79a90f2535e0075dc1479f007afceef")
