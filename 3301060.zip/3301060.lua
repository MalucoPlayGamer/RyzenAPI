-- Lua provided by RyzenAPI
-- Game: Desktop Mate

-- MAIN APPLICATION
addappid(3359730)
addappid(3465160)
addappid(3533450)
addappid(3681410)
addappid(3681420)
addappid(3681430)
addappid(3833190)
addappid(3833210)
addappid(3929250)
addappid(3941450)
addappid(3941610)
addappid(3941620)
addappid(3941630)
addappid(3941640)
addappid(4018660)
addappid(4018670)
addappid(4018680)
addappid(4018690)
addappid(4018700)
addappid(4018720)
addappid(4145000)
addappid(4145010)
addappid(4145020)
addappid(4145030)
addappid(4145040)
addappid(4145050)
addappid(4145060)
addappid(4145070)
addappid(4145080)
addappid(4161240)
addappid(4270570)
addappid(4474310)
addappid(4474320)
addappid(4640380)
addappid(4640430)
addappid(4745480)
addappid(4791000)
addappid(4791010)
addappid(4791020)
addappid(4981520)
addappid(5040200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3301060, 1, "7582f4d3aa17a74002ff5373a59c7a4faa600ecbe3162f0845a504a69da2a7b4") -- Desktop Mate
addappid(3301061, 1, "6e7d44d14db1b1b4e5d43a64af62fb4845066fe0ccacef125ac6390978ac97d0") -- Depot 3301061
addappid(3301062, 1, "80e1494f7b41bcdb59504add641b5540154af4d2c4d74ea25df0638a4ba69e25") -- Depot 3301062
addappid(3301063, 1, "a90a3958a9f182f069687978652932ee43753d136e90105c614ad7d0db312187") -- Depot 3301063
addappid(3301064, 1, "855f21c9ccfb04a528d68e9c6eb558a2c4cd6544eb765ea592c9b9b8a66cc31e") -- Depot 3301064
addappid(3301065, 1, "17525bb791b65f27141029c690f539921babba494d52f3ee7fc827bd9f191c5a") -- Depot 3301065
addappid(3301066, 1, "b31ce31a092f4be163a597c92c0bdd2cb19be9b35a5aa746e41a57a6df7478a7") -- Depot 3301066
addappid(3359730, 1, "0f11d40d2674cb19a055d6d65f4d4d845bec01167e0977aba91558bb93d4cad6") --  DLC - Depot 3359730
addappid(3359731, 1, "710e4264f662de5749ea8159b26a30b7b11112fd89d6a7134e96cdd62b7e4e8e") --  DLC - Depot 3359731
addappid(3465160, 1, "7a1e4b009760e36441de4593f40020f18b3372217a998f459694bcc43b371cbd") -- SNOW MIKU 2025 Ver. DLC - Depot 3465160
addappid(3533450, 1, "9c3422e204117b9185c9474c97cfb09cc8f9dffd5bf40704c2747623474dea8f") --  DLC - Depot 3533450
addappid(3681410, 1, "7a880bdfe13f29abdf6a96274f626bd68a61ad086dcd43103ca211cfa84c8045") --  DLC - Depot 3681410
addappid(3681411, 1, "567609210ed2ddefcb69159c9e054c7c83cfbfa0dcae9a5eb224be74c8fc91e8") --  DLC - Depot 3681411
addappid(3681420, 1, "247082f549736c99225e7848a5bda6d76f6f5ac2347c7d96069be603706ded39") --  DLC - Depot 3681420
addappid(3681421, 1, "c63b68961b39e1adb643cef30a32c8e5be80032df4eb20b3d1525e12b1841b32") --  DLC - Depot 3681421
addappid(3681422, 1, "fbebde290c826ee4f1ee0e70d23a4da21220b9cd0c3e9327cbdaf6ffeca20d93") --  DLC - Depot 3681422
addappid(3681423, 1, "02a93a2b553fe3207deb09840943d71a87d18f59977c613eccadf4b2c42c02d8") --  DLC - Depot 3681423
addappid(3681430, 1, "bc1fa6c98b2ad97cf9ab1a691e2c396a5d7e7b76263d28111c6bae98ccba3098") -- DLC - Depot 3681430
addappid(3833190, 1, "b19428f0edbab561ac55237c743f18d91f83dd698740666127321f663f12e74a") -- 2025 Ver.DLC - Depot 3833190
addappid(3833191, 1, "43273934c060b7bb2d64f4487d807e38ad4bdde53608c37f4b94c1a9b5bf220a") -- 2025 Ver.DLC - Depot 3833191
addappid(3833210, 1, "f90abd8cb837d9efc5bd1fbcfa480a6f903ed1c51b78d3c629318efb41bc4535") --  DLC - Depot 3833210
addappid(3929250, 1, "65bd74de67ba0e4366d2d17a03fd10008e4b190145aa22975f0894fbf0f49f9e") --  DLC - Depot 3929250
addappid(3929251, 1, "5c85518dfede6a2a7896b9bb01f88ca409b0e52ae00759acd95db1faaf087bea") --  DLC - Depot 3929251
addappid(3929252, 1, "40ade464143c4f8304b59b8b2715213e2c6533a7b28a58bfb50699eb19048f99") --  DLC - Depot 3929252
addappid(3929253, 1, "29b90eac349792e7dc395a3cea4e2234185ec99c8be40582eb04cb8adde679c2") --  DLC - Depot 3929253
addappid(3941450, 1, "2b9e14a4010fadedff3c140c0ce5d5f70dfe3bdd9e312d2eca11b7674d84928e") -- NieRAutomata B DLC - Depot 3941450
addappid(3941451, 1, "03979a81d9f1ac1d9a019cc879c138d7cd8bf14519f692e1c15c36fa16bf576c") -- NieRAutomata B DLC - Depot 3941451
addappid(3941610, 1, "bc5e96572e7d4812c0dab01ad3198c56a99b3635f693890cc4167e4dd67cfd9e") -- Desktop Mate NEEDY GIRL OVERDOSE  DLC - Depot 3941610
addappid(3941611, 1, "78fe5e67e873e1ae74eb4bed8c0ee757cd7c22af5d878570077da03c07bebea8") -- Desktop Mate NEEDY GIRL OVERDOSE  DLC - Depot 3941611
addappid(3941620, 1, "6817286a76fd8bac6af8a642d36a989d1e1920de5ab86ab91eb00dc3a3d04237") -- Desktop Mate NEEDY GIRL OVERDOSE  DLC - Depot 3941620
addappid(3941621, 1, "3a0c03bc87e3fd27747f03ae8e8ed469c5abe0f569faa5e7615207de60d0cee7") -- Desktop Mate NEEDY GIRL OVERDOSE  DLC - Depot 3941621
addappid(3941630, 1, "5073f090e72ffdc9aac93f6463da199f9f5fe92da2370778a0d874eef27bcdd5") -- Desktop Mate  DLC - Depot 3941630
addappid(3941631, 1, "d6f29697006753ffec6b39528c32a011fa29ce675a41b6577085be499947522a") -- Desktop Mate  DLC - Depot 3941631
addappid(3941632, 1, "9c4946fc527cba1e8f0635b8fd8094a5dc51d19b0f90ee306f5dc02eef9328fd") -- Desktop Mate  DLC - Depot 3941632
addappid(3941633, 1, "ca5d1dfc80d1efac9a597e184c187901fc68b4d17049b6ce6e403ce526fbec0c") -- Desktop Mate  DLC - Depot 3941633
addappid(3941640, 1, "005c682274373b4b0fb1c9c98a9acd078220e0102c635dc9cceaac6741b07026") -- Desktop Mate  DLC - Depot 3941640
addappid(3941641, 1, "b4176a3dee9657a63f22bd0ce8ac3e9a813241ae4ad1e8b46680dc95e915e460") -- Desktop Mate  DLC - Depot 3941641
addappid(4018660, 1, "fa2fe690b2c3d63c42c3f43bbf638e9204978e2c714c00fabaa4867bcdb37b7e") -- Desktop Mate Project  DLC - Depot 4018660
addappid(4018661, 1, "7afac0b847badd65480a9449c793aa797eea581b64ea00c67ddc21dbe93a1a21") -- Desktop Mate Project  DLC - Depot 4018661
addappid(4018670, 1, "1b6e6b85ffd4d6250086477fc92fc54292531746d5eccfcffa9385152b09649d") -- Desktop Mate Project  DLC - Depot 4018670
addappid(4018680, 1, "c54ee505917cdbd65b958a0d61c26cfb8ed36c62c463fecef987cf2f150e97df") -- Desktop Mate  DLC - Depot 4018680
addappid(4018681, 1, "2de10684e78ee32ff693239ae72a714e7ac234b38779384566ecabb9310fa7c5") -- Desktop Mate  DLC - Depot 4018681
addappid(4018690, 1, "c86007f733c6178892ab5af423c641c52829cbf3435c8e1de6c62fee7861c136") -- Desktop Mate  DLC - Depot 4018690
addappid(4018691, 1, "43ce2ef72955c8910e6cf35a4ecb778f513bc9f9e7fbd4d41ec0a443fb86cc8c") -- Desktop Mate  DLC - Depot 4018691
addappid(4018700, 1, "8b2dc3ee7c05332c223eebb63bc0c684de3081e9f347259cbbf1ecde744c3c32") -- Desktop Mate  DLC - Depot 4018700
addappid(4018701, 1, "82c072b8ebae87493e354bb3835223fd7cdb517fd228178a88dde28fbac401ea") -- Desktop Mate  DLC - Depot 4018701
addappid(4018720, 1, "8106467aa40ae844bd26fc0f014b576b49942325219fa81425ccf4572399c21c") -- Desktop Mate SNOW MIKU 2026 Ver.DLC - Depot 4018720
addappid(4018721, 1, "cf715e230f959c2d053f1bdf3250c25fe6086e25415d97eb4ffbce5bc0c22af8") -- Desktop Mate SNOW MIKU 2026 Ver.DLC - Depot 4018721
addappid(4145000, 1, "518eda425238ad30e947a0817d782ceac71d9fa5064b154fa1b70b41842d9285") -- Desktop Mate GUMI DLC - Depot 4145000
addappid(4145010, 1, "a656f2df2ece85be82eb2bd0de631171cc239f5521be18a1a63b01f581b60d85") -- Desktop Mate  DLC - Depot 4145010
addappid(4145011, 1, "e473ecd4131a40f3e7485df7f6598aa9443b93314ea405a737e856c2dd8da458") -- Desktop Mate  DLC - Depot 4145011
addappid(4145020, 1, "c0c445d4426072ffba1b2c935b9d71241d1f94c4f19c68c220b51711e25ef03d") -- Desktop Mate JR Ver. DLC - Depot 4145020
addappid(4145030, 1, "a51239be92cdae0d177f0b1eee6ce60f4c9cf3ffac27ea8a55fce258d02aca0f") -- Desktop Mate  DLC - Depot 4145030
addappid(4145040, 1, "c254339e12b4488dae00ec5a008e907512dbc770a4e1d753956d39288f6c0d42") -- Desktop Mate  DLC - Depot 4145040
addappid(4145050, 1, "8e3e116a0361734fccf85fb246282e8265c48506b804160c40b097aa24ee8336") -- Desktop Mate  DLC - Depot 4145050
addappid(4145060, 1, "f996879dab8fbc7f8602f6f2d6090a5991ff32b36e65d2e83d574e62ca69cac6") -- Desktop Mate  DLC - Depot 4145060
addappid(4145070, 1, "778166fd8b43baeb2c1b656d145a13b89dd62885a6ff5d3f5450f998f708dd9f") -- Desktop Mate  DLC - Depot 4145070
addappid(4145080, 1, "97f8f0324ced67fb14d204f6347be2fd8fb1e912397b502ae6b0513c01def30e") -- Desktop Mate  DLC - Depot 4145080
addappid(4161240, 1, "f7387a9f2f09d542d10a77e34ff19c73982b97b59fefb97464cd002a0530286e") -- Desktop Mate Project  DLC - Depot 4161240
addappid(4270570, 1, "d4fa97690bbbeda93ba54546a354145189ef6e573330a56d5502c4178c949024") -- Desktop Mate Project  DLC - Depot 4270570
addappid(4474310, 1, "65ad4fe94e11704145e1e1100c2b62daec952fb14f84e09977c0363335489434") -- Desktop Mate  DLC - Depot 4474310
addappid(4474320, 1, "0c9a0c76e40478716dcfe59a82fa369bb981a99de0943446db155c7b152488d9") -- Desktop Mate  DLC - Depot 4474320
addappid(4474321, 1, "b0301e9bb80758e1bcef313bdba5d4f9bd970531fce31028117485e91418403b") -- Desktop Mate  DLC - Depot 4474321
addappid(4640380, 1, "73d5a271aa1606942512055a9db8dbb9c4ab571914354c62dd4b0b30e6a9aa66") -- Desktop Mate  DLC - Depot 4640380
addappid(4640381, 1, "aa00a408d1d48a59ea983f63abbdb20c30b29fabbef30ecb9f74b15b366946f0") -- Desktop Mate  DLC - Depot 4640381
addappid(4640430, 1, "2ed18bc5fb0e7873f07fd854f0808b9b0c89d75bc30d7730ef0ef7127cb38973") -- Desktop Mate  DLC - Depot 4640430
addappid(4640431, 1, "77c94378a6e364d80d58c2b5719be7f59cae934a3866fb1b574d3a91723aca91") -- Desktop Mate  DLC - Depot 4640431
addappid(4745480, 1, "4cfb38359a0c60f9c73609f819a3d45ad9435dd27b18485ebb66033e921cb00d") -- Desktop Mate  DLC - Depot 4745480
addappid(4745481, 1, "68c014f44ff0936795e74c65fe49989632b9c7bb8c12e56762e510b22024e149") -- Desktop Mate  DLC - Depot 4745481
addappid(4791000, 1, "e48fb5c24968355d494b36778f2e1aad44becdd4a67598a910f99d4dd31dcc12") -- Desktop Mate KAITO DLC - Depot 4791000
addappid(4791001, 1, "538a33809d9fcab383b847e9441a64e6c4ef5f158b606431c9585711a227d935") -- Desktop Mate KAITO DLC - Depot 4791001
addappid(4791010, 1, "abf2f8307909dd5291ee3e80001f851c5302848c3164083abd5d8edd832c304a") -- Desktop Mate MEIKO DLC - Depot 4791010
addappid(4791011, 1, "53d827f3ed828871426917e68e5aab3f0f7f419231ce864952d93f252db69b28") -- Desktop Mate MEIKO DLC - Depot 4791011
addappid(4791020, 1, "3f696b56609fe3e816cd6e8accfc9e10d1b78bb206ad6eb154095cd5d2a6b6f6") -- Desktop Mate  2026 Ver.DLC - Depot 4791020
-- addappid(3465161, 1, "MISSING_KEY") -- SNOW MIKU 2025 Ver. DLC - Depot 3465161 (no key available)
-- addappid(3533451, 1, "MISSING_KEY") --  DLC - Depot 3533451 (no key available)
-- addappid(3681431, 1, "MISSING_KEY") -- DLC - Depot 3681431 (no key available)
-- addappid(3833211, 1, "MISSING_KEY") --  DLC - Depot 3833211 (no key available)
-- addappid(4018671, 1, "MISSING_KEY") -- Desktop Mate Project  DLC - Depot 4018671 (no key available)
-- addappid(4145001, 1, "MISSING_KEY") -- Desktop Mate GUMI DLC - Depot 4145001 (no key available)
-- addappid(4145021, 1, "MISSING_KEY") -- Desktop Mate JR Ver. DLC - Depot 4145021 (no key available)
-- addappid(4145031, 1, "MISSING_KEY") -- Desktop Mate  DLC - Depot 4145031 (no key available)
-- addappid(4145041, 1, "MISSING_KEY") -- Desktop Mate  DLC - Depot 4145041 (no key available)
-- addappid(4145051, 1, "MISSING_KEY") -- Desktop Mate  DLC - Depot 4145051 (no key available)
-- addappid(4145061, 1, "MISSING_KEY") -- Desktop Mate  DLC - Depot 4145061 (no key available)
-- addappid(4145071, 1, "MISSING_KEY") -- Desktop Mate  DLC - Depot 4145071 (no key available)
-- addappid(4145081, 1, "MISSING_KEY") -- Desktop Mate  DLC - Depot 4145081 (no key available)
-- addappid(4161241, 1, "MISSING_KEY") -- Desktop Mate Project  DLC - Depot 4161241 (no key available)
-- addappid(4270571, 1, "MISSING_KEY") -- Desktop Mate Project  DLC - Depot 4270571 (no key available)
-- addappid(4474311, 1, "MISSING_KEY") -- Desktop Mate  DLC - Depot 4474311 (no key available)
-- addappid(4791021, 1, "MISSING_KEY") -- Desktop Mate  2026 Ver.DLC - Depot 4791021 (no key available)

