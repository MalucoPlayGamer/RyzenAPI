-- Lua provided by RyzenAPI 
-- Game: Desktop Mate
addappid(3301060)
addappid(3301061, 1, "6e7d44d14db1b1b4e5d43a64af62fb4845066fe0ccacef125ac6390978ac97d0")
addappid(3359730)
addappid(3465160)
addappid(3533450)
addappid(3681410)
addappid(3681420)
addappid(3833190)
addappid(3833210)
addappid(3929250)
addappid(3941450)
