-- Lua provided by RyzenAPI
-- Game: Beer Pong League

-- MAIN APPLICATION
addappid(642190)

-- MAIN APP DEPOTS / PACKAGES
addappid(642191, 1, "c22dd0010d4770446f6b7309e048d5a41370624d184ad5d083ef039e30515d94")

