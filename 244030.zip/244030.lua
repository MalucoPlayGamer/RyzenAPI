-- Lua provided by RyzenAPI 
-- Game: Take On Mars
addappid(244030)
addappid(244031, 1, "74ffea748254b02c4d1769e29f57e05c590edbea1430b2d69ba07230ef326893")
addappid(244032, 1, "a084fe4f40e22aabade51336e4aaef889d52b4021d3441768f70680a4c7ae30f")
