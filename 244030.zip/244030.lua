-- Lua provided by RyzenAPI
-- Game: Take On Mars

-- MAIN APPLICATION
addappid(244030)

-- MAIN APP DEPOTS / PACKAGES
addappid(244031, 1, "74ffea748254b02c4d1769e29f57e05c590edbea1430b2d69ba07230ef326893")
addappid(244032, 1, "a084fe4f40e22aabade51336e4aaef889d52b4021d3441768f70680a4c7ae30f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
