-- Lua provided by RyzenAPI
-- Game: addappid(1844030)

-- MAIN APPLICATION
addappid(1844030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844031, 1, "e85e53e1485be9ef5dbf9f974ce780edce4c93d3ce6c076b4a05621aafb4b2d3")
