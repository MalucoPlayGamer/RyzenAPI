-- Lua provided by RyzenAPI
-- Game: Cricket 22 - Academy Creation Tools

-- MAIN APPLICATION
addappid(1844030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1844031, 1, "e85e53e1485be9ef5dbf9f974ce780edce4c93d3ce6c076b4a05621aafb4b2d3")

