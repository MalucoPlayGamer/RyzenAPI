-- Lua provided by RyzenAPI
-- Game: 2231710

-- MAIN APPLICATION
addappid(2231710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231710,0,"bd8ebf4ee2d324ff05bc90aecbc3f93d955989dde175c09401c294c6e9fd804e")

