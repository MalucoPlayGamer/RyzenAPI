-- Lua provided by RyzenAPI
-- Game: Light Bearers

-- MAIN APPLICATION
addappid(765710)
addappid(954560)

-- MAIN APP DEPOTS / PACKAGES
addappid(765711, 1, "31198402653fbc25749bc732e099d6bfe36d07aa5c17df4771860162ec6f576d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
