-- Lua provided by RyzenAPI
-- Game: Light Bearers

-- MAIN APPLICATION
addappid(765710)
addappid(954560)
-- Game: addappid(765710)

-- MAIN APP DEPOTS / PACKAGES
addappid(765711, 1, "31198402653fbc25749bc732e099d6bfe36d07aa5c17df4771860162ec6f576d")
