-- Lua provided by SkyAPI 
-- Game: Toffee Cats
addappid(3601120)
addappid(3601121, 1, "1f5a4f7b8c904b8e0a7d17c1cb421528571f974e084e2a7f602483adb04014b7")
