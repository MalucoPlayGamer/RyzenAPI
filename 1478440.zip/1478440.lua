-- Lua provided by RyzenAPI 
-- Game: Perfect Decision
addappid(1478440)
addappid(1478441, 1, "21ffc38f6a2b6d9270e22a23ae2f62aa1af342e373c317743b1c2b1d3142f118")
