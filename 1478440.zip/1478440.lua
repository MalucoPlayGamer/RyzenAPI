-- Lua provided by RyzenAPI
-- Game: 1478440

-- MAIN APPLICATION
addappid(1478440)
-- Game: addappid(1478440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478441, 1, "21ffc38f6a2b6d9270e22a23ae2f62aa1af342e373c317743b1c2b1d3142f118")
