-- Lua provided by RyzenAPI
-- Game: APEX Tournament

-- MAIN APPLICATION
addappid(656260)
-- Game: addappid(656260)

-- MAIN APP DEPOTS / PACKAGES
addappid(656261, 1, "158f7bd5f72456805e434ef138744646f90b3f1a3b887e158f14204a1349c041")
