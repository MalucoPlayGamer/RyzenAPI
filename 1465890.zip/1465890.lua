-- Lua provided by RyzenAPI
-- Game: addappid(1465890)

-- MAIN APPLICATION
addappid(1465890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465891, 1, "3553568aab6a139f1d3cc0c0b923dcff734ba48821a605874f6180c76d27ac38")
