-- Lua provided by RyzenAPI
-- Game: Aces in the Dust

-- MAIN APPLICATION
addappid(1658080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1658081, 1, "0f406f4228d4404fd2ba367625f31572b9f670c70410deb741392e1a0d3204eb")

