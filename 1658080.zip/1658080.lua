-- Lua provided by RyzenAPI
-- Game: Aces in the Dust

-- MAIN APPLICATION
addappid(1658080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658081, 1, "0f406f4228d4404fd2ba367625f31572b9f670c70410deb741392e1a0d3204eb")

