-- Lua provided by RyzenAPI
-- Game: AppID 1133420

-- MAIN APPLICATION
addappid(1133420)
-- Game: addappid(1133420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133421, 1, "7d81c8b12cc402842bdc76cdd534fba405ed4fd0ea2a42650b65d6a56f90a2d5")
