-- Lua provided by RyzenAPI 
-- Game: AppID 1133420
addappid(1133420)
addappid(1133421, 1, "7d81c8b12cc402842bdc76cdd534fba405ed4fd0ea2a42650b65d6a56f90a2d5")
