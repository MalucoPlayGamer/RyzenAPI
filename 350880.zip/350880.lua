-- Lua provided by RyzenAPI
-- Game: Archamon

-- MAIN APPLICATION
addappid(350880)

-- MAIN APP DEPOTS / PACKAGES
addappid(350881, 1, "58095cd074aabd779cbe67eefec9f8a5a7ddbcb7b1afdddad873d0968e73c8cd")
