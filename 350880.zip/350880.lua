-- Lua provided by RyzenAPI
-- Game: Archamon

-- MAIN APPLICATION
addappid(350880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(350881, 1, "58095cd074aabd779cbe67eefec9f8a5a7ddbcb7b1afdddad873d0968e73c8cd")

