-- Lua provided by RyzenAPI
-- Game: addappid(2057380)

-- MAIN APPLICATION
addappid(2057380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057381, 1, "3feaa20db247e395e87c02f47ac5fb58cd8136996322726495191dbd723b516d")
