-- Lua provided by RyzenAPI
-- Game: Game: Linia Super

-- MAIN APPLICATION
addappid(2411140)
-- Game: addappid(2411140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411141, 1, "5a3b7843780b64a7a2df3a2e6b6a520061fbd86b7327459eb0561260de07cad4")
