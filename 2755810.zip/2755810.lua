-- Lua provided by RyzenAPI
-- Game: 2755810

-- MAIN APPLICATION
addappid(2755810)
-- Game: addappid(2755810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755811, 1, "29be6608d3c52723a27a714f36f4d9f80ad6e4e3263bc090127b2afd19fa2209")
