-- Lua provided by RyzenAPI
-- Game: Office Sluts: Act 0

-- MAIN APPLICATION
addappid(5036550) -- Office Sluts: Act 0

-- MAIN APP DEPOTS / PACKAGES
addappid(5036551, 1, "228ff304784121c31cf7d73b3586d3640137faa569810f39260fb97fb4f5ffbd") -- Depot 5036551

