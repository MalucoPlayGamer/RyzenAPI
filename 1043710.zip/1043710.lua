-- Lua provided by RyzenAPI
-- Game: Game: Unlanded

-- MAIN APPLICATION
addappid(1043710)
-- Game: addappid(1043710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043711, 1, "976c3aeec9871dc0ede3e01056362da326ecd2bfae2c400b58471f1d38ffa522")
