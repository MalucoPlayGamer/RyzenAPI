-- Lua provided by RyzenAPI
-- Game: 7 Years' War

-- MAIN APPLICATION
addappid(1567580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567582,0,"a3cf23836bb4716551d2044e2d9266f65461c003c5c9e77bb923b99f925ed68b")

