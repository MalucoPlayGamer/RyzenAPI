-- Lua provided by RyzenAPI
-- Game: 2724540

-- MAIN APPLICATION
addappid(2724540)
-- Game: addappid(2724540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2724541, 1, "8bfbe2f498c3ee6cebff6291775682d570d9cdf7baf413ea24710cbc2cdfd1a6")
