-- Lua provided by RyzenAPI
-- Game: Cybernetic Seduction

-- MAIN APPLICATION
addappid(2724540)
addappid(3552650)
addappid(4555920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2724541,0,"8bfbe2f498c3ee6cebff6291775682d570d9cdf7baf413ea24710cbc2cdfd1a6")
addappid(2724542,0,"ba31170de91c40d7a605412ce5a2a2f0fa2fe60b07775073d4447b56b33f9b28")
addappid(3552650,0,"c328db17ea47c2db0d73ffdcc3f020d428e7a7b37097f924619a51338abc5948")

