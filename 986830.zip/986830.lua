-- Lua provided by RyzenAPI
-- Game: The Legacy: The Tree of Might

-- MAIN APPLICATION
addappid(986830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(986831, 1, "1af0798913bad1601fbab30726bed78964acdf2701889f1d3afe48ddb12021b9")
addappid(986833, 1, "afc4af9f85e95bb693f78080eb540ba1dec7c000627a8700727ebbd62819fe93")
addappid(986834, 1, "46f711e2a4f7412c43d57596e9737ed969d289af7bc8a9ca1928fefd762f1c34")
