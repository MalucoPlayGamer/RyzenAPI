-- Lua provided by RyzenAPI
-- Game: Solasta: Crown of the Magister

-- MAIN APPLICATION
addappid(1096530)
addappid(1581690)
addappid(1581691)
addappid(1581692)
addappid(1722280)
addappid(1723950)
addappid(2100430)
addappid(2100431)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096530,0,"16022b541c53d839a28e07c63d1ee347f256990f4da9360d34081688e5b55896")
addappid(1096531,0,"0b1e859ef0a9c257b2a834870286df53270b88a3abd8f95a817fb8bb736857d6")
addappid(1096532,0,"d87907e100a8dcf41c56bbef38a931a4ed1e9323b70b02ade4db75b1022d7731")
addappid(1438980,0,"82e68e4ef18583850066c57d580bc90c49e593a751276f5ee53dcc22b6259dcf")

