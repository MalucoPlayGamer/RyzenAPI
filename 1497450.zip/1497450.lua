-- Lua provided by RyzenAPI
-- Game: A Memoir Blue

-- MAIN APPLICATION
addappid(1497450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497451, 1, "d239a886111fb748629ec4778748df7fcb0adf321b1ae313e395922c711d1e94")

