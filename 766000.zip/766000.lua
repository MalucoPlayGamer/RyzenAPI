-- Lua provided by RyzenAPI
-- Game: 766000

-- MAIN APPLICATION
addappid(766000)
-- Game: addappid(766000)

-- MAIN APP DEPOTS / PACKAGES
addappid(766001, 1, "6bbbf4bc43c8d6eaa225d820b11c9a1b6109dcb0e8c839995c88b97aeac8cd0c")
