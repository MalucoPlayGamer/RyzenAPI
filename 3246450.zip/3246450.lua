-- Lua provided by RyzenAPI
-- Game: Game: Dismantling Workshop of Bio-Girl

-- MAIN APPLICATION
addappid(3246450)
-- Game: addappid(3246450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3246451, 1, "1414f2b67b961a693dfba680c4d3f37b42ae88b6a7515a85394802437ae562c5")
addappid(3246452, 1, "dd240b6a7380c636b62caf55225167e0403cd7851b0545039f90721482755fd3")
addappid(3246453, 1, "278c6fd4e5c499c30a7dc6cb3d6c1470c549b463d192a506a7b8a468790d3ed6")
addappid(3246454, 1, "b1c49de547fd17cdb0c1f7bce050856384d523841ef8353b9c1dfd4ca9a3be44")
