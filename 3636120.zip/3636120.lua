-- Lua provided by RyzenAPI
-- Game: VR Hentai MMA

-- MAIN APPLICATION
addappid(3636120)
-- Game: addappid(3636120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3636125,0,"1008d4a6d35c5c6a1bcdf87584765df650ad9057f7bf949c4243b188217171a7")
