-- Lua provided by RyzenAPI
-- Game: Steven the Sperm

-- MAIN APPLICATION
addappid(928350)

-- MAIN APP DEPOTS / PACKAGES
addappid(928351, 1, "38565a446fdcd3f2c3f7ee45f05ea62a22412270190ed63aa0081a5dab05c846")

