-- Lua provided by RyzenAPI
-- Game: MATH EXPRESSions

-- MAIN APPLICATION
addappid(1953970)
addappid(1976070)
-- Game: addappid(1953970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953971, 1, "7db320d81cb0d46998783444c9d992fe258c0a50941967f95b90e04a65615cf8")
