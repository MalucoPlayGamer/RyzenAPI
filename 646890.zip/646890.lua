-- Lua provided by RyzenAPI
-- Game: Distant Nightmare

-- MAIN APPLICATION
addappid(646890)

-- MAIN APP DEPOTS / PACKAGES
addappid(646891,0,"f3f07f35cffe812c92ba591ca170f52092754414b0bcb0a752c24eb2290a0e67")

