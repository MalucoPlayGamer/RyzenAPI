-- Lua provided by RyzenAPI
-- Game: Trip In Another World

-- MAIN APPLICATION
addappid(1826960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826961, 1, "69d4d44785d96f3a966f10fe546cd7636b348fb5d26022be9604fd13f30f6870")

