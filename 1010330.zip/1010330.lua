-- Lua provided by RyzenAPI
-- Game: addappid(1010330)

-- MAIN APPLICATION
addappid(1010330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010331, 1, "930d77f3777d9f3fc6b659eee2a88efea0c93f920d24d59ab04214fe1ee4b07e")
