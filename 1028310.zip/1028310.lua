-- Lua provided by RyzenAPI
-- Game: BOOK OF HOURS

-- MAIN APPLICATION
addappid(1028310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028311, 1, "90a2074504473e457d4987a217b18cc60a1cf27ed5994153e3fdc75799eeaf53")
addappid(1028312, 1, "6092c0a48d45bd760a70d966631a34ceb157f605bb3705a50a32fd4040b38c30")
addappid(1028313, 1, "ea5afdaf53a8a26ddefdd16d16e01994027664c76ef488a766fd54d76b9e8b29")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2500320)
addappid(2834350)
