-- Lua provided by RyzenAPI
-- Game: Blade Symphony Dedicated Server

-- MAIN APPLICATION
addappid(228780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228781, 1, "92ab1b66f1205bc082b5fdb11495cf4101fdf614072e3537208c391d07a0782e")
addappid(228782, 1, "be2a205f5f5500816892a3f0150f882dc4ae86fa631877b311229b57f403201c")
addappid(228783, 1, "d32032ead3e7b321b8f3da35942d5e2e45fe0b25923a47883ea4d3b3aa2f08cf")

