-- Lua provided by RyzenAPI
-- Game: Slay the Dragon! Soundtrack

-- MAIN APPLICATION
addappid(1472670)
-- Game: addappid(1472670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472673,0,"7a5130ecd0f911a310eafd8ca7cd76f62d73ad1333cd1a365e975e1814823ead")
