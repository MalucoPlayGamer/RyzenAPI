-- 4838630's Lua and Manifest Created by Hubcap Manifest
-- My Fox Tomboy
-- Created: August 15, 2026 at 22:25:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4838630) -- My Fox Tomboy
-- MAIN APP DEPOTS
addappid(4838631, 1, "32925aa8dea67ca7849b8854fb8f96fd1c310a81631715a4c304079d42493b29") -- Depot 4838631
setManifestid(4838631, "4617396023898838272", 197193160)