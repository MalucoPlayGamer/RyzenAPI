-- Lua provided by RyzenAPI
-- Game: My Fox Tomboy

-- MAIN APPLICATION
addappid(4838630) -- My Fox Tomboy

-- MAIN APP DEPOTS / PACKAGES
addappid(4838631, 1, "32925aa8dea67ca7849b8854fb8f96fd1c310a81631715a4c304079d42493b29") -- Depot 4838631

