-- Lua provided by RyzenAPI
-- Game: Turbo Golf Racing

-- MAIN APPLICATION
addappid(1324350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324351, 1, "2a66da81a770c7d6659ed3ff913144e90e49337fab84b9240bbd05d225fee11a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2156660)
addappid(2156670)
addappid(2376950)
addappid(2376951)
