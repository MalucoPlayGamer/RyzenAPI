-- Lua provided by RyzenAPI
-- Game: addappid(1324350)

-- MAIN APPLICATION
addappid(1324350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324351, 1, "2a66da81a770c7d6659ed3ff913144e90e49337fab84b9240bbd05d225fee11a")
