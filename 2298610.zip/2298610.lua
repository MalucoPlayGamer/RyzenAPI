-- Lua provided by RyzenAPI
-- Game: addappid(2298610)

-- MAIN APPLICATION
addappid(2298610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298611, 1, "db74e074805ead9f802abcb0736f9c7c654ba67d56e99ff7e084785097ccea03")
