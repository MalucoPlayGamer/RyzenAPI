-- Lua provided by RyzenAPI
-- Game: The World of Labyrinths: Labyronia

-- MAIN APPLICATION
addappid(864740)

-- MAIN APP DEPOTS / PACKAGES
addappid(864741, 1, "8bb54cee8c1a2c3f59653fe89d7da1a7f518d86f47c2c4aaa2a3e1372fe4df2b")

