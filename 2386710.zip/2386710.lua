-- Lua provided by RyzenAPI
-- Game: Game: Everlasting Abundance

-- MAIN APPLICATION
addappid(2386710)
-- Game: addappid(2386710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386711, 1, "0caf9fe0167d3bf5588802732a8008e4643b9496f74e23539fcb6ffecaea98a9")
