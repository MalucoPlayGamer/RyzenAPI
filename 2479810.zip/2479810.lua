-- Lua provided by RyzenAPI
-- Game: Gray Zone Warfare

-- MAIN APPLICATION
addappid(2479810)
addappid(2633470)
addappid(2914230)
addappid(2955580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2479811, 1, "c89db92b0e186d8c1e9db781270fc739b23f152b3e11ed7733f93bba19ce6716")

