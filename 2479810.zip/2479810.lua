-- Lua provided by SkyAPI 
-- Game: Gray Zone Warfare
addappid(2479810)
addappid(2479811, 1, "c89db92b0e186d8c1e9db781270fc739b23f152b3e11ed7733f93bba19ce6716")
