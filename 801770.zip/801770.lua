-- Lua provided by RyzenAPI
-- Game: Brutalism

-- MAIN APPLICATION
addappid(801770)

-- MAIN APP DEPOTS / PACKAGES
addappid(801771,0,"77327f415ddff1b74ffb3923a135648e426472a9bc81ab4ad27025519a689635")

