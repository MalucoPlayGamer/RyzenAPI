-- Lua provided by RyzenAPI
-- Game: Ship Simulator Extremes

-- MAIN APPLICATION
addappid(48800)

-- MAIN APP DEPOTS / PACKAGES
addappid(48801, 1, "88fe395d5c353eb6dbaee6eeff516a04535570a0968f2134b7665486b428f18b")
addappid(48802, 1, "17420476491fe0700ab3dbc254227b510c51a7ce5e55cf8374c916261d1b10b1")
addappid(48803, 1, "1847032018edfe128d036a7f3ccd1044334b269f03937355195b1bc4ef58c4da")
addappid(48804, 1, "85abb9c51b7f57ecd6d29031d003a32cad9ff8dea4c4338f39ec05da1d29b344")
addappid(48805, 1, "af577eeebedd32687c051be76b6326b17a9e77a52b779e0df569a46ba75a1214")
addappid(48806, 1, "0360716eef3ecbd290da7f7a69e865c1c7be454738ed3970a3964f24964ae93e")
addappid(48830, 0, "52909b531ffa84e5cc68ebca6c503ffcef4edd7ac76651503355e624e6c344c1")
addappid(250930, 0, "38a78b3fa7a21928a68f6ee6f7b8a49acba03bf9582652848241b9c528f2f74d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
