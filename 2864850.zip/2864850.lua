-- Lua provided by RyzenAPI
-- Game: Lilith Rising - Season 2

-- MAIN APPLICATION
addappid(2864850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864851, 1, "e64110ccad294d5dc376e976ba4dc5c45a9fb8b6a2245d7a4b0cdd43ff2cea9c")
