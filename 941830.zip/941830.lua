-- Lua provided by RyzenAPI
-- Game: Game: AppID 941830

-- MAIN APPLICATION
addappid(941830)
-- Game: addappid(941830)

-- MAIN APP DEPOTS / PACKAGES
addappid(941831, 1, "a15d4cfea713ac650f8908f7819e7c9d4bd5f158f7086998387051844c2e9c80")
