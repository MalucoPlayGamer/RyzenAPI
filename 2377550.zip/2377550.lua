-- Lua provided by RyzenAPI
-- Game: Tribes of Midgard - Original Soundtrack

-- MAIN APPLICATION
addappid(2377550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377551, 1, "0a24b77c07cd5faa4a2dfff6311936947247a056bffb44fd4d1b9392d83b2146")

