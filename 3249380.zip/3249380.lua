-- Lua provided by RyzenAPI
-- Game: Piece by Piece

-- MAIN APPLICATION
addappid(3249380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249381,0,"97a5101f9c4f7740bcc155a7254346dd6aa03de707b7a14582902c1c95a7108b")

