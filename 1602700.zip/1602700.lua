-- Lua provided by RyzenAPI
-- Game: Teabat!

-- MAIN APPLICATION
addappid(1602700)
-- Game: addappid(1602700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602701, 1, "a3f72898a5b6ddaf0b8c716e024ea6d3f891465856f426154fc69d289d2b3a22")
addappid(1602702, 1, "73ed7b0363b31a05a227e157f658a6cc250a4b4cbfebb653b21a851cf6819548")
