-- Lua provided by SkyAPI 
-- Game: AppID 364910
addappid(364910)
addappid(364911, 1, "eb027b0f0b2eecf508ec02f4ebe8b04e58b8eff5c5b0f48c04cb4fa516ad9c43")
