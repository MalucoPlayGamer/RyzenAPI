-- Lua provided by RyzenAPI
-- Game: addappid(2656650)

-- MAIN APPLICATION
addappid(2656650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656651, 1, "2f46d8bbb85ce1195f88540e14f73d932be222682e1417d5c55feab48000adf6")
