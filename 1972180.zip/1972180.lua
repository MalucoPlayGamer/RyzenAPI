-- Lua provided by RyzenAPI
-- Game: Dub Club

-- MAIN APPLICATION
addappid(1972180)
addappid(2003530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972181, 1, "c4d7749d4e7a1e5fd8a5c746127559cc51bf58550c5daf57e571258480ff171d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
