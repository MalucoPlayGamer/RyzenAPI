-- Lua provided by RyzenAPI
-- Game: addappid(1972180)

-- MAIN APPLICATION
addappid(1972180)
addappid(2003530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972181, 1, "c4d7749d4e7a1e5fd8a5c746127559cc51bf58550c5daf57e571258480ff171d")
