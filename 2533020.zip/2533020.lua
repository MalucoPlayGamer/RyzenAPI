-- Lua provided by SkyAPI 
-- Game: Renaissance Kingdom Wars
addappid(2533020)
addappid(2533021, 1, "2835f591bac054c0c681e3a68b9bb53e26f47ea1109561870c989deda3d8815a")
