-- Lua provided by RyzenAPI
-- Game: 2533020

-- MAIN APPLICATION
addappid(2533020)
-- Game: addappid(2533020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533021, 1, "2835f591bac054c0c681e3a68b9bb53e26f47ea1109561870c989deda3d8815a")
