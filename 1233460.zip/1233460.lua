-- Lua provided by RyzenAPI
-- Game: Star Escape

-- MAIN APPLICATION
addappid(1233460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233461, 1, "6e6b4be5d3bdda36d1842bfbec670475e1e6c409968b9ed3736844c776ab218e")

