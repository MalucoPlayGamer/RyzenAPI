-- Lua provided by RyzenAPI
-- Game: While Waiting

-- MAIN APPLICATION
addappid(2449160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449161, 1, "472e86d5f1dcbd82d64aa29cf6a41e9db578257a7080a16320a03b6be8c859aa")
addappid(2449162, 1, "bfdf50fa75800487e5d90198ae264e0aae18eddb653eafe2c9701816a8c1ff1b")
