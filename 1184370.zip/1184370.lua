-- Lua provided by RyzenAPI
-- Game: Pathfinder: Wrath of the Righteous - Enhanced Edition

-- MAIN APPLICATION
addappid(1184370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184372,0,"ea7fd1b6040ce4614445d86c6cf179d3e3c88d92dcd8e852cca95976158d8eb0")
addappid(1184373,0,"7023e90824b69f90df991ce7e60655ac446116e69a3906281e1e529eb6ec2e01")
addappid(1694800,0,"ac772dc768799bced9179e74639ff640f005ac536bc0c4db35a9854bdebfda48")
