-- Lua provided by RyzenAPI
-- Game: Game: HuniePop 2: Double Date

-- MAIN APPLICATION
addappid(930210)
-- Game: addappid(930210)

-- MAIN APP DEPOTS / PACKAGES
addappid(930211, 1, "ee621ac854b3597ed70ea6db3f346087c82acc559037dcc06d05cfe43648b83b")
addappid(930212, 1, "7102c0da60003320034fa6f50446e4110cc33e3fe7e6d14f8e48222845ca729c")
addappid(930213, 1, "b5fcf181ba97a160cdb29dfa70528c4ae8fc92164359053fcb4bc0c6ba2c30f6")
addappid(1928520, 0, "897835df97fe65e0653d1debd328928ef2ee127a200403504fc7c60882992b1a")
