-- Lua provided by RyzenAPI
-- Game: Dumb Roguelike-like RPG

-- MAIN APPLICATION
addappid(1304360)
-- Game: addappid(1304360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304361, 1, "3d56fff44e1412d4582006d556ee1f0800e2cd14b4f07cd65ea159a227af4003")
