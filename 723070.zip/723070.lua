-- Lua provided by RyzenAPI
-- Game: AppID 723070

-- MAIN APPLICATION
addappid(723070)

-- MAIN APP DEPOTS / PACKAGES
addappid(723071, 1, "f461facb0b584221c1ff78d895dabaea2af69a71441a36c28171725a00851c3f")

