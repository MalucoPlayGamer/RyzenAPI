-- Lua provided by RyzenAPI
-- Game: Scrolls of the Lord

-- MAIN APPLICATION
addappid(723070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(723071, 1, "f461facb0b584221c1ff78d895dabaea2af69a71441a36c28171725a00851c3f")
