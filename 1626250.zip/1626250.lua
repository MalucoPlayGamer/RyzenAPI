-- Lua provided by RyzenAPI
-- Game: 1626250

-- MAIN APPLICATION
addappid(1626250)
-- Game: addappid(1626250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1626250,0,"04cd8c260229beeab0478af5f3e3848f371ec6c38dcfb8365325e2d07e6e0040")
