-- Lua provided by RyzenAPI
-- Game: 1651610

-- MAIN APPLICATION
addappid(1651610)
-- Game: addappid(1651610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651611, 1, "d0970de65423c761d32a04920eeffba43b1f77e94c4761128a9d140d606909cb")
