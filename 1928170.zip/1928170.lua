-- Lua provided by RyzenAPI
-- Game: addappid(1928170)

-- MAIN APPLICATION
addappid(1928170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928171, 1, "f77b635c6e753dfbeafa84c1351c9c05fcfdf490441141dab60a7a47ec921e4e")
