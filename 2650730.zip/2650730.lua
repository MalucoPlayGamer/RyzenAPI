-- Lua provided by RyzenAPI
-- Game: SEDAP! A Culinary Adventure

-- MAIN APPLICATION
addappid(2650730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650731, 1, "2b2452e01ad2d464d8f111ed1e500e28dbc76f75fd350c6fbd3935aea0b3bb90")

