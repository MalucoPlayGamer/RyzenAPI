-- Lua provided by RyzenAPI 
-- Game: Adventure With Succubus Demo
addappid(3347740)
addappid(3347741, 1, "e43c3ab635c202446fa16f7927c955e7385069cc7e41c544ae196655a51df064")
