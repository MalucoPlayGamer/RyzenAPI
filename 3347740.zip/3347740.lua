-- Lua provided by RyzenAPI
-- Game: Game: Adventure With Succubus Demo

-- MAIN APPLICATION
addappid(3347740)
-- Game: addappid(3347740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347741, 1, "e43c3ab635c202446fa16f7927c955e7385069cc7e41c544ae196655a51df064")
