-- Lua provided by SkyAPI 
-- Game: SHIPS AT WAR
addappid(1557420)
addappid(1557421, 1, "faa6e7890386ee063c72b019abbb70e480b4c3e8bc42d3198a2611a37b82a644")
