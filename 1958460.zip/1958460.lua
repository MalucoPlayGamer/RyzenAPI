-- Lua provided by RyzenAPI
-- Game: AppID 1958460

-- MAIN APPLICATION
addappid(1958460)
-- Game: addappid(1958460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958461, 1, "35eea8114dfbc39feafcedd6db9207eb332aaaaca15fe946e11ba10b3db2c084")
