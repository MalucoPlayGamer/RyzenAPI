-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Smile Objects Vol.1

-- MAIN APPLICATION
addappid(2339440)
-- Game: addappid(2339440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339440,0,"b70296b6916dbca93dfa649be7729cc4f97e6798e6bf86b64068fabea05f08cd")
