-- Lua provided by RyzenAPI
-- Game: addappid(500360)

-- MAIN APPLICATION
addappid(500360)

-- MAIN APP DEPOTS / PACKAGES
addappid(500361, 1, "5b69a50b53aebf843edfd379c6e906c9ffe0c88a0ebab5cc15ca2d05451380cf")
