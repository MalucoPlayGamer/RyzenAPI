-- Lua provided by RyzenAPI 
-- Game: AppID 322460
addappid(322460)
addappid(322461, 1, "7fddd6fa7e6905db8a68c6cdfd1e13c637e2b93c732382d67dc27840492b434f")
