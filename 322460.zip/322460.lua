-- Lua provided by RyzenAPI
-- Game: Game: AppID 322460

-- MAIN APPLICATION
addappid(322460)
-- Game: addappid(322460)

-- MAIN APP DEPOTS / PACKAGES
addappid(322461, 1, "7fddd6fa7e6905db8a68c6cdfd1e13c637e2b93c732382d67dc27840492b434f")
