-- Lua provided by RyzenAPI
-- Game: addappid(1457990)

-- MAIN APPLICATION
addappid(1457990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457991, 1, "0236d16f0be66cc9cdf4a1c8769fe3af2ee4e9954e6558ae5ee7cf2badccbcf8")
addappid(1457992, 1, "e7079f3a57bb18495dda5672d4b5e427233b6ec4e6ef5f8b35da597c1f6b2839")
addappid(1457993, 1, "1bf555de62c19ec2bbe0d31cca15b30cf5e7faa8275ea143e7ba6a897f365b0c")
