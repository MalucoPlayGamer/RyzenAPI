-- Lua provided by RyzenAPI
-- Game: Game: AppID 2122960

-- MAIN APPLICATION
addappid(2122960)
-- Game: addappid(2122960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122961, 1, "deeaacadde214385f9de99030105e500fd1e460899b498c412e6757523e4ebe9")
