-- Lua provided by SkyAPI 
-- Game: PULSOR
addappid(1066670)
addappid(1066671, 1, "2e2016572711d5e8e050d1945f1086e745135d14789b878be2cffdd942864990")
