-- Lua provided by RyzenAPI
-- Game: GRAVEN

-- MAIN APPLICATION
addappid(1371690)
addappid(2779320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371691, 1, "d4ee796bdaf448e2658d8f36b5edf7e6900fbc267d86eecf9c153be8d51f8bc0")

