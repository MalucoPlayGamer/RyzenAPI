-- Lua provided by RyzenAPI
-- Game: 1646370

-- MAIN APPLICATION
addappid(1646370)
-- Game: addappid(1646370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646371, 1, "680666d7a4a03c065cffd770b43cf1b0ab3ab544bf2152f91edb1af4b4d49d3a")
