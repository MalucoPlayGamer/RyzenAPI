-- Lua provided by RyzenAPI
-- Game: Game: Isle of Swaps Demo

-- MAIN APPLICATION
addappid(2466170)
-- Game: addappid(2466170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466171, 1, "12fde6ce26d8027ed79865dc6fdc90d5d0f1d9e50b4dbe2bdc7392c3372373b7")
