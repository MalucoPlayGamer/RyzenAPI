-- Lua provided by RyzenAPI 
-- Game: Isle of Swaps Demo
addappid(2466170)
addappid(2466171, 1, "12fde6ce26d8027ed79865dc6fdc90d5d0f1d9e50b4dbe2bdc7392c3372373b7")
