-- Lua provided by SkyAPI 
-- Game: DAY OF DRIFT
addappid(3650050)
addappid(3650051, 1, "14848553b163be31bd759eb125ada8e1e6ce1351dade3e1c9a08d723434e826d")
