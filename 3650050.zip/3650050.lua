-- Lua provided by RyzenAPI
-- Game: 3650050

-- MAIN APPLICATION
addappid(3650050)
-- Game: addappid(3650050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3650051, 1, "14848553b163be31bd759eb125ada8e1e6ce1351dade3e1c9a08d723434e826d")
