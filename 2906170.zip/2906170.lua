-- Lua provided by RyzenAPI
-- Game: 2906170

-- MAIN APPLICATION
addappid(2906170)
addappid(3375690)
-- Game: addappid(2906170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906171, 1, "1c439fd50d3fbf5387bb6168aa9a04c424a52a0a2a42df67c86fb80c888eb20d")
addappid(2906172, 1, "1e9a60b09018c9dd4a92c26e1f2acec986442bbad65cce30db3f0dddc313de70")
