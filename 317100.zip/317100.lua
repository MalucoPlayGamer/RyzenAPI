-- Lua provided by RyzenAPI
-- Game: AppID 317100

-- MAIN APPLICATION
addappid(317100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(317101, 1, "47188c31bf705659e6a58bb72bff7db2f5ec9ab1f4023645f5c1f275f4e82581")
addappid(317102, 1, "2a43e0e6aaaa6501005491602f95eb1ff6c09d829dce5eeda3803cb085fa0645")
addappid(319241, 0, "7b5c25ae3d04a26598ee730d6d4dd9b26a1bbdb358a522ac6d6976c12a4a31cb")
addappid(319242, 0, "a23ebcc8fc04b1cda83d5d5e5c4d1e46f0df092cba397882628ae9f905dd51bf")

