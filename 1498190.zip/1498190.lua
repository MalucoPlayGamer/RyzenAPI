-- Lua provided by SkyAPI 
-- Game: AppID 1498190
addappid(1498190)
addappid(1498191, 1, "0a886568c35e96020cfa5c4368c109b28bcff95464cd7a1d0971d3f330244d55")
