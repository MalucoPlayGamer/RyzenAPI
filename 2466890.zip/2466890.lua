-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Medieval Inn

-- MAIN APPLICATION
addappid(2466890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466891, 1, "1fec422e2694f6cdb335d0d337c5e41bba2241562869823cea6bc374289a351a")
