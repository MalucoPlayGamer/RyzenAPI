-- Lua provided by RyzenAPI
-- Game: Hentai Asmodeus

-- MAIN APPLICATION
addappid(1147510)
addappid(1176490)
-- Game: addappid(1147510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147511, 1, "e4f92b8ebe218cac2da5e8e27c754230ec6d71f627f0fa58aed4cae2b9239eeb")
