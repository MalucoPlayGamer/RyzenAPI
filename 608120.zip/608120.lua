-- Lua provided by RyzenAPI
-- Game: 608120

-- MAIN APPLICATION
addappid(608120)
-- Game: addappid(608120)

-- MAIN APP DEPOTS / PACKAGES
addappid(608121, 1, "48e91fe6500039cd9d90441770f2a8d432e66b361b4b87c73d0387f3af80f7f6")
