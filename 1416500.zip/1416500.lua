-- Lua provided by RyzenAPI
-- Game: 发条 免费版

-- MAIN APPLICATION
addappid(1416500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416501, 1, "0622d5c9e85622be87aec7188423bbb6c093a765d64d90bd115a791eb7caad5a")

