-- Lua provided by SkyAPI 
-- Game: girl friend simulator
addappid(1096910)
addappid(1096911, 1, "e7da2097bc1a714c49d28afcf32c78d8b8b9be009840e3d8828e24e281d22c62")
