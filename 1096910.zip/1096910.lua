-- Lua provided by RyzenAPI
-- Game: girl friend simulator

-- MAIN APPLICATION
addappid(1096910)
-- Game: addappid(1096910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096911, 1, "e7da2097bc1a714c49d28afcf32c78d8b8b9be009840e3d8828e24e281d22c62")
