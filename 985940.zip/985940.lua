-- Lua provided by RyzenAPI
-- Game: addappid(985940)

-- MAIN APPLICATION
addappid(985940)

-- MAIN APP DEPOTS / PACKAGES
addappid(985941, 1, "6da56f8d166d4562c9e59beb1b98b7dc755653c509cd9fa5af83490a921ff6b9")
