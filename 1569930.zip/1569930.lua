-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 5

-- MAIN APPLICATION
addappid(1569930)
-- Game: addappid(1569930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569931, 1, "3a62bfa6b7338a077fa2735f0ad07bbb5aa0a40cfc5ba8b82d260b6fe1fced84")
