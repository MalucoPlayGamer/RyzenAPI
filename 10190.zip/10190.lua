-- Lua provided by RyzenAPI
-- Game: Call of Duty®: Modern Warfare® 2 - Multiplayer

-- MAIN APPLICATION
addappid(10190)

-- MAIN APP DEPOTS / PACKAGES
addappid(10182,0,"98e730672197195300951a3d2f198c16ddfd4cc6d6f882d51d4451e07e1f56d4")
addappid(10183,0,"9d6d7892bb063f0994946afbf4e2dbe2376c4e38fd5499197b04d9739e755eab")
addappid(10184,0,"57b7539e22d6fdf82a9be1382cab21501e8c34f9995efd2aceabf18d23a5f53a")
addappid(10195,0,"ccbd9c0e70f88c30ec8776f3838f2cc1e3529f9660601292a76df918971424bf")
addappid(10196,0,"0229b7d5cea8696ae4be6f67a42aff53404f7cce39063ebff05da8dc7d10a895")
addappid(278300,0,"e61f0098429dfaa4cd4a91e9c247a48e52ff9e5d261700912111949e490cf9a0")
addappid(278301,0,"f31c5cb84b9f6c8d60b3963c885a85e68ac34923e3fb2320980ce3bd85a03fd9")
addappid(278302,0,"21523d64d443e41a7e18754347e53a481b0bcee9fd78d7fb505d460f0ad74f78")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(10197)
