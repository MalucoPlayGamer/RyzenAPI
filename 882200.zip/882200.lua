-- Lua provided by RyzenAPI
-- Game: addappid(882200)

-- MAIN APPLICATION
addappid(882200)

-- MAIN APP DEPOTS / PACKAGES
addappid(882201, 1, "7a173fbfbcdae4ad51c91459c21ced75843b5129b6219b52e33a8d83500efb73")
