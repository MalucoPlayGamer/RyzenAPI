-- Lua provided by RyzenAPI
-- Game: Game: Bahamian Rhapsody

-- MAIN APPLICATION
addappid(1471940)
-- Game: addappid(1471940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471941, 1, "4c56e25b67f9e8c205f9e253bb7e41c0d4f87f11df697fc7e3bb94a51bf4f6b0")
addappid(1471942, 1, "99cf1e6423f278e07088a5df6cfe1055eda5f2c1aea4b92b7d08b30c3d18c944")
