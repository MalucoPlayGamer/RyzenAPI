-- Lua provided by RyzenAPI
-- Game: addappid(425720)

-- MAIN APPLICATION
addappid(425720)

-- MAIN APP DEPOTS / PACKAGES
addappid(425721, 1, "3bd7d9ac733943dea4526df2cffefc3f78e7895268db611d1d899455fdcd1280")
