-- Lua provided by RyzenAPI
-- Game: Game: Castle Life

-- MAIN APPLICATION
addappid(1778090)
-- Game: addappid(1778090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778091, 1, "b8017cfbfad104dd218c75b0454c6d45ecf0ba0e1e9027093c2fd5aa1e29447b")
