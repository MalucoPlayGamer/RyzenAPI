-- Lua provided by RyzenAPI 
-- Game: Castle Life
addappid(1778090)
addappid(1778091, 1, "b8017cfbfad104dd218c75b0454c6d45ecf0ba0e1e9027093c2fd5aa1e29447b")
