-- Lua provided by RyzenAPI
-- Game: Game: War Tortoise

-- MAIN APPLICATION
addappid(2120250)
-- Game: addappid(2120250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120251, 1, "a395c64e34d78ab6882baf18e6116b7a0260357ed026e053d5ae87e4387ca6cc")
addappid(2120252, 1, "a44c27cce10172c3e2faebc514ac221c4540013ba385105339f0146e1d83909b")
