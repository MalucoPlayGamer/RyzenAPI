-- Lua provided by RyzenAPI
-- Game: Game: Tank Hunter

-- MAIN APPLICATION
addappid(2957440)
-- Game: addappid(2957440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957441, 1, "2c02c4cca1f6f78079e0f0f27efcca8c14fe89af5a304fec6bfbe6adb5feb971")
