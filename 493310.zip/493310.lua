-- Lua provided by RyzenAPI
-- Game: AppID 493310

-- MAIN APPLICATION
addappid(493310)
-- Game: addappid(493310)

-- MAIN APP DEPOTS / PACKAGES
addappid(493311, 1, "d105245860c4e07530c104df221da16ef3ef1b30d3a34346111b08c3072e7ce3")
