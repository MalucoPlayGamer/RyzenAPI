-- Lua provided by RyzenAPI
-- Game: Anti Terrorist Shooting Game

-- MAIN APPLICATION
addappid(3251690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251691, 1, "2014879a0120fdf7430ed27b31a1417820aee82a4aaade5a73e8b511aeba3687")

