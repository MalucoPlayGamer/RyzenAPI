-- Lua provided by RyzenAPI
-- Game: Resident Evil Revelations

-- MAIN APPLICATION
addappid(222480)
addappid(229621)
addappid(229622)
addappid(229626)
addappid(229627)
addappid(229628)
addappid(229629)
addappid(229630)
addappid(229631)
addappid(229632)

-- MAIN APP DEPOTS / PACKAGES
addappid(222481, 1, "65e75d906613ce658af73b8db0772cf9f6fa3905427161dd1c0482572da72c0d")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

