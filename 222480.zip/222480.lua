-- Lua provided by SkyAPI 
-- Game: Resident Evil Revelations
addappid(222480)
addappid(222481, 1, "65e75d906613ce658af73b8db0772cf9f6fa3905427161dd1c0482572da72c0d")
