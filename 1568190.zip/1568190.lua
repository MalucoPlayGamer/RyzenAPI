-- Lua provided by RyzenAPI
-- Game: 1568190

-- MAIN APPLICATION
addappid(1568190)
-- Game: addappid(1568190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568191, 1, "7abe53eb17ba9cfbce2d53a461623b146a23aaf8e482a0923033baccb178ee04")
