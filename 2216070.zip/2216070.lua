-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Darktide Soundtrack

-- MAIN APPLICATION
addappid(2216070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216071, 1, "16dec830831b4fb98c4c7c2110e34ac619f7211369b15eaa934d3517489a4cf3")
addappid(2216072, 1, "49b8ab52cb8db195fae2f9757a232f82a0a93febe79016a96b556bdac0a713de")
