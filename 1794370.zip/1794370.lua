-- Lua provided by RyzenAPI
-- Game: Game: Philosopher's Stone and Minerva

-- MAIN APPLICATION
addappid(1794370)
-- Game: addappid(1794370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794371, 1, "2d32325079609c8b7a5bda3912bc0620976f79be2dee258beb928b6359476b20")
addappid(1794372, 1, "6226c499b1424a7375ee1b8c5620f5afa455d5da3c973a99736e43a5b81a40a3")
addappid(1794373, 1, "8c82cc49e9982e7d152a0d0be4206163870e2008ec8871da2f53041b3f564805")
