-- Lua provided by RyzenAPI
-- Game: 2160480

-- MAIN APPLICATION
addappid(2160480)
-- Game: addappid(2160480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2160481, 1, "3fcbcdcb0104e1848803bf02e785e547ef5c2d7040bb4a3c0e240a143c4b2502")
