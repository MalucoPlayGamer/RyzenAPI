-- Lua provided by RyzenAPI
-- Game: Evenicle

-- MAIN APPLICATION
addappid(955560)

-- MAIN APP DEPOTS / PACKAGES
addappid(955561, 1, "4302d4b219ee51cc39d5de83f693269737cf3d4a79176214b8641cba2454040e")
