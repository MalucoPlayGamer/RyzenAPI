-- Lua provided by RyzenAPI
-- Game: addappid(520270)

-- MAIN APPLICATION
addappid(520270)

-- MAIN APP DEPOTS / PACKAGES
addappid(520271, 1, "24b2d2b2103b46f5453b6ef2913385da32db3ceb0785b1fbb3518c0836e22d66")
