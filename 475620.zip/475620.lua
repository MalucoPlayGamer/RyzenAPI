-- Lua provided by RyzenAPI 
-- Game: MOAI 4: Terra Incognita Collector’s Edition
addappid(475620)
addappid(475621, 1, "4594b7ea495270f8aafd3f7c740db929152fb7b0ff273475a432d6f931819063")
addappid(475622, 1, "01269260e48e379a41bd9933e271c85368b84bbd98fa341227330507894039de")
addappid(475623, 1, "83343e3885bb0034bbe2899b8695841821380cfc12b3b9465c59e7aa919cd27c")
