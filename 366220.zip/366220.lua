-- Lua provided by RyzenAPI
-- Game: 366220

-- MAIN APPLICATION
addappid(366220)
-- Game: addappid(366220)

-- MAIN APP DEPOTS / PACKAGES
addappid(366221, 1, "88a5656bddfe9dfb208be586caca61428f1a9e15e6eacd68c7eacb73f4e89cc3")
addappid(366222, 1, "64658a74fb907bb343fe187ce6626eef96e9261ff24dc222c44ad99cf51ec524")
addappid(366223, 1, "fdb772603d6d87ebd068b556bc66e19a4022a414ae60ce8d5bb3d275f01bfbaa")
addappid(366224, 1, "c7476fe42a7af3f578529e35e949ee71f7ed9c00a82f106e677b6c3a8506dc91")
addappid(366225, 1, "0bca2f81ddbe6979c865c807096dca6cd0d321ffb6c49f44c806a428843e3819")
