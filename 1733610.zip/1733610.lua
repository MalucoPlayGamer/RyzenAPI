-- Lua provided by RyzenAPI
-- Game: addappid(1733610)

-- MAIN APPLICATION
addappid(1733610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733611, 1, "f36ab018917ac636038ca422367dd6becbab11ec200e3f7e5ba9cdd6c4146f4a")
