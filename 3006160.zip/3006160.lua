-- Lua provided by RyzenAPI
-- Game: T-深渊病毒:起源 Demo

-- MAIN APPLICATION
addappid(3006160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3006161, 1, "b03697eccb794c1360a90476db3ecf6be1e9e66d7ea1a43293f1764de70fbc5a")
