-- Lua provided by SkyAPI 
-- Game: AppID 1179330
addappid(1179330)
addappid(1179331, 1, "13d54351d41a39a1e62ba765c9b5f22a9abaa8a920c4f1c9698ead11cc5f00f1")
