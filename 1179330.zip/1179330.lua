-- Lua provided by RyzenAPI
-- Game: 1179330

-- MAIN APPLICATION
addappid(1179330)
-- Game: addappid(1179330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179331, 1, "13d54351d41a39a1e62ba765c9b5f22a9abaa8a920c4f1c9698ead11cc5f00f1")
