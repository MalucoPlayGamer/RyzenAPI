-- Lua provided by RyzenAPI 
-- Game: Vrifier
addappid(640080)
addappid(640081, 1, "c6f93102976ab4332e6d5fa1eb33d9e2dcbaa370c5462c6f86babebcdca774e2")
addappid(1356430, 0, "530e531800e37ee9cfa1b6113224c4ce8cb073ea0bf76d6b7528a22138cb45f9")
