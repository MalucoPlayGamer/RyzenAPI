-- Lua provided by RyzenAPI
-- Game: Vrifier

-- MAIN APPLICATION
addappid(640080)

-- MAIN APP DEPOTS / PACKAGES
addappid(640081, 1, "c6f93102976ab4332e6d5fa1eb33d9e2dcbaa370c5462c6f86babebcdca774e2")
addappid(1356430, 0, "530e531800e37ee9cfa1b6113224c4ce8cb073ea0bf76d6b7528a22138cb45f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
