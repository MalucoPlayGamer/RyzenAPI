-- Lua provided by RyzenAPI
-- Game: Figmin XR

-- MAIN APPLICATION
addappid(1890220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890221,0,"fbdca9ca7f99889ff400ebd08ea8b48a5c3f65e6570dc558364fbe5af25c1fb6")

