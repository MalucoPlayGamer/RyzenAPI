-- Lua provided by RyzenAPI
-- Game: Game: AppID 2064530

-- MAIN APPLICATION
addappid(2064530)
-- Game: addappid(2064530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064531, 1, "5c08712fc37d03c4b41623106bba35b13c22eeb247c3e0032f55d08c4ff9541e")
