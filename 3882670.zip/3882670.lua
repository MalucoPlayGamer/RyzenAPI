-- Lua provided by RyzenAPI
-- Game: LUNATHREN

-- MAIN APPLICATION
addappid(3882670) -- LUNATHREN

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3882671, 1, "f6aed5619ffa9374957d7cac00891e70e4db83339f4b2d01cfb734bc45f9a37e") -- Depot 3882671

