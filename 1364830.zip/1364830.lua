-- Lua provided by RyzenAPI
-- Game: TinyPoker

-- MAIN APPLICATION
addappid(1364830)
-- Game: addappid(1364830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364831, 1, "0bfadfd30fe6d6e65111c3e04a430a2f39bae13659e4a0ccda458fb2225c6238")
