-- Lua provided by SkyAPI 
-- Game: Pill Baby
addappid(1765560)
addappid(1765561, 1, "2f9b8884b6c68bb07e00cc674d6a2d620fc196147f9eb4dcc3e9c48f3e52463b")
addappid(1765562, 1, "dc346c941f98ea0659a29ac08b0b36bd1fd2ce873fbd3f275315c880ff3d1958")
addappid(1765563, 1, "afb75da6307f5636c3bb5b6434f3d54f7a09a0dcb07eaac438c795b152a4fa96")
