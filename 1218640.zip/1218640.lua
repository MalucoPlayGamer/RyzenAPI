-- Lua provided by RyzenAPI
-- Game: Draco Knight

-- MAIN APPLICATION
addappid(1218640)
-- Game: addappid(1218640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218642,0,"4aa6b2f4ad28ab9ece6a8f74843e6286d5de9d0623e3e1ebbbfcb3a52adb19e9")
