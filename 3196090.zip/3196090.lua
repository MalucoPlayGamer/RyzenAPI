-- Lua provided by RyzenAPI
-- Game: 赫雷斯的角鬥場 Ⅲ Demo

-- MAIN APPLICATION
addappid(3196090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196091, 1, "25a06001f5fc898f5c38addbcade9fabdd880c637b591d651b54bcc735f5507d")

