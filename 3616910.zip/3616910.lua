-- Lua provided by RyzenAPI
-- Game: BACKROOMS: We Escape Forever

-- MAIN APPLICATION
addappid(3616910)
-- Game: addappid(3616910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3616911, 1, "51025fbf15fd39032d10f162d9e460b4f89c06365e6699638a2d65aba62919bb")
