-- Lua provided by SkyAPI 
-- Game: DunHero
addappid(2270210)
addappid(2270211, 1, "4b348a196e018fa4551e46350301b1962fcf013d1d52312c905a163fa92c949e")
