-- Lua provided by RyzenAPI
-- Game: DunHero

-- MAIN APPLICATION
addappid(2270210)
-- Game: addappid(2270210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270211, 1, "4b348a196e018fa4551e46350301b1962fcf013d1d52312c905a163fa92c949e")
