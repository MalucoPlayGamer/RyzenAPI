-- Lua provided by RyzenAPI
-- Game: Rad Rocket

-- MAIN APPLICATION
addappid(1388160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388161, 1, "822611a07e5b75230dc4ee9292427cfb9a6099a6f4c787242b5dd246ca3f49eb")

