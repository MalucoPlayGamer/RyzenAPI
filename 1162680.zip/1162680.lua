-- Lua provided by RyzenAPI
-- Game: 1162680

-- MAIN APPLICATION
addappid(1162680)
-- Game: addappid(1162680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162681, 1, "60d9432930d437183ede89e315f21a62ad1b6e8fca04cd9b0c91e1e25d280f90")
