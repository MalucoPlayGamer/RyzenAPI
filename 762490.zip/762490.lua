-- Lua provided by RyzenAPI
-- Game: Naked Sun

-- MAIN APPLICATION
addappid(762490)

-- MAIN APP DEPOTS / PACKAGES
addappid(762491, 1, "801d54e4f9f773fb9e137e1d7fe09d29cc448be85ef63baa0330671ddf92cfd6")

