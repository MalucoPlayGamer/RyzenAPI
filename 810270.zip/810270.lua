-- Lua provided by RyzenAPI
-- Game: 810270

-- MAIN APPLICATION
addappid(810270)
-- Game: addappid(810270)

-- MAIN APP DEPOTS / PACKAGES
addappid(810271, 1, "bec88cf176509d2ca29524e63c5cc858096a34e17759667e41eacaa1bc6bdb15")
