-- Lua provided by RyzenAPI
-- Game: addappid(381990)

-- MAIN APPLICATION
addappid(381990)

-- MAIN APP DEPOTS / PACKAGES
addappid(381991, 1, "8530bb457570721ee736cb9a931a1748e12c5692abb50b2dde19eb2863ba3ce6")
