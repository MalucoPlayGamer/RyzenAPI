-- Lua provided by SkyAPI 
-- Game: Robber Knight
addappid(1887020)
addappid(1887021, 1, "aed35018bec8dfba32cbcfbd28652714ae1771399e50c048f0cbb15aaee7119f")
