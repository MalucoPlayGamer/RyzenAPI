-- Lua provided by RyzenAPI
-- Game: Robber Knight

-- MAIN APPLICATION
addappid(1887020)
-- Game: addappid(1887020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887021, 1, "aed35018bec8dfba32cbcfbd28652714ae1771399e50c048f0cbb15aaee7119f")
