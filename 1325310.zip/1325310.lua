-- Lua provided by RyzenAPI
-- Game: Endless Voyage / 无尽航线

-- MAIN APPLICATION
addappid(1325310)
-- Game: addappid(1325310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325311, 1, "975d06cfb1a77cd2f1b552829e381330d06a77e6a4a866c73b91165637e8501a")
addappid(1325312, 1, "30a84d112f3e94c596718068336ec4568aaf58b55b5985a61d6365e866000cdb")
