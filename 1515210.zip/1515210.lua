-- Lua provided by RyzenAPI
-- Game: 1515210

-- MAIN APPLICATION
addappid(1515210)
-- Game: addappid(1515210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515211, 1, "bfd6a3c58a0830a1eb930ce88de60f4825317d69ee09c1bb3e86ea5edc7062cb")
addappid(1515212, 1, "e209f2d09625305477ce055a82cc5be737ef4284fdde3dd5e99c5384462de607")
