-- Lua provided by RyzenAPI
-- Game: addappid(2319470)

-- MAIN APPLICATION
addappid(2319470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319471, 1, "2feb57cc36b4d3c3e24028f23124ee02b8d429d8e4f4ac37c33153e271f4644e")
