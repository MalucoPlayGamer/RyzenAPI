-- Lua provided by RyzenAPI
-- Game: 3402010

-- MAIN APPLICATION
addappid(3402010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402010,0,"ca6f1145d7d99f2edc02cfedf796c59ca479bdb8ec92839be98279306f58fbb1")
