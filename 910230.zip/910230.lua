-- Lua provided by RyzenAPI
-- Game: Fortified Swiss

-- MAIN APPLICATION
addappid(910230)

-- MAIN APP DEPOTS / PACKAGES
addappid(910231, 1, "c252f1eb92b5791408bf88f229d0de08ac7dd48343dbe63925cb2eb4d9d17ff4")
