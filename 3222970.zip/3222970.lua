-- Lua provided by RyzenAPI
-- Game: Find 100 Ducks and Blast Them!

-- MAIN APPLICATION
addappid(3222970)

