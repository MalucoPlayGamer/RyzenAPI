-- Lua provided by RyzenAPI
-- Game: Game: AppID 2452250

-- MAIN APPLICATION
addappid(2452250)
-- Game: addappid(2452250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452251, 1, "1078ad122ebb81baa618a5756e462fe9101c9e738186ad83fb02ffa446343523")
