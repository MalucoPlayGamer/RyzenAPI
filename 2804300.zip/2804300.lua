-- Lua provided by RyzenAPI
-- Game: addappid(2804300)

-- MAIN APPLICATION
addappid(2804300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804301, 1, "bbf20d63fa0571a5ce945f65ec497dc2cdf90af792170f5db7b654bf70b7f1f5")
