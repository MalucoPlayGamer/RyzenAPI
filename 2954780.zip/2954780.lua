-- Lua provided by RyzenAPI
-- Game: Nightmare House: The Original Mod

-- MAIN APPLICATION
addappid(2954780)

