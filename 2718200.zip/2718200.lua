-- Lua provided by RyzenAPI
-- Game: 2718200

-- MAIN APPLICATION
addappid(2718200)
-- Game: addappid(2718200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718201, 1, "179a0227ff66b948910c5dc47b6a3e35e3b43d5af15b524739a663ed6cdcce6b")
