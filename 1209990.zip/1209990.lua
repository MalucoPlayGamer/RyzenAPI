-- Lua provided by RyzenAPI
-- Game: 1209990

-- MAIN APPLICATION
addappid(1209990)
-- Game: addappid(1209990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209991, 1, "6eb5c4f4b1d78a9d19ea7c11e70fc000950e4c92a998a961ea8093165b54c2b5")
addappid(1493330, 0, "562d3f2d615b4d295936f33c8cdbf95738ab090abda2c6ef6aeea64dad86b052")
