-- Lua provided by RyzenAPI
-- Game: Simple Increment

-- MAIN APPLICATION
addappid(2318820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318821, 1, "02afc96ef7a119f68401de1df3c32aed42433f8e2f2b0e97acc8c929cd676a54")

