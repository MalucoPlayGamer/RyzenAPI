-- Lua provided by RyzenAPI
-- Game: Game: AppID 2709230

-- MAIN APPLICATION
addappid(2709230)
-- Game: addappid(2709230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709231, 1, "a3a4a3193275f343359929db3c2464c72b02d7c13938a0c2f71df34f631d93d3")
