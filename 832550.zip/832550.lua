-- Lua provided by RyzenAPI
-- Game: AppID 832550

-- MAIN APPLICATION
addappid(832550)

-- MAIN APP DEPOTS / PACKAGES
addappid(832551, 1, "880fabb8457f1f5ab915b6b5768a553f563e1053343afd95601bce341604e06c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
