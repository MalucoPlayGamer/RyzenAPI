-- Lua provided by RyzenAPI
-- Game: AppID 832550

-- MAIN APPLICATION
addappid(832550)
-- Game: addappid(832550)

-- MAIN APP DEPOTS / PACKAGES
addappid(832551, 1, "880fabb8457f1f5ab915b6b5768a553f563e1053343afd95601bce341604e06c")
