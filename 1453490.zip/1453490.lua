-- Lua provided by RyzenAPI
-- Game: Deducto

-- MAIN APPLICATION
addappid(1453490)
addappid(1891490)
addappid(1950380)
addappid(2065040)
addappid(2561100)

