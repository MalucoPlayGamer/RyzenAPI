-- Lua provided by RyzenAPI
-- Game: Deducto

-- MAIN APPLICATION
addappid(1453490)

