-- Lua provided by SkyAPI 
-- Game: AppID 1962140
addappid(1962140)
addappid(1962141, 1, "b8f9ee47752529fb59dd58af99ab3cac7d0a7b3ce91221a750e5493210588055")
