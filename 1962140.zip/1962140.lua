-- Lua provided by RyzenAPI
-- Game: 海贼王街机Idle

-- MAIN APPLICATION
addappid(1962140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962141, 1, "b8f9ee47752529fb59dd58af99ab3cac7d0a7b3ce91221a750e5493210588055")

