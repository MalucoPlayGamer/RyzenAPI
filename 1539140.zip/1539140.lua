-- Lua provided by RyzenAPI
-- Game: STONKS-9800: Stock Market Simulator

-- MAIN APPLICATION
addappid(1539140)
addappid(3554550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539141, 1, "88024941c78a93e10cc766fd33a92863fcb184a7c95ec37ba2562bcce041b055")
