-- Lua provided by RyzenAPI
-- Game: Game: BoxEngine

-- MAIN APPLICATION
addappid(814890)
-- Game: addappid(814890)

-- MAIN APP DEPOTS / PACKAGES
addappid(814891, 1, "40676f1e5a4de6a13a660784ee3a28f5f6aea47335b9f0192a978e4b99223027")
