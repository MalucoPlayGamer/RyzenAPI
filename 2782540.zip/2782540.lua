-- Lua provided by RyzenAPI
-- Game: 2782540

-- MAIN APPLICATION
addappid(2782540)
-- Game: addappid(2782540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782541, 1, "e7a655e8e6d85f7eca94a90bc44053ee1b1b476df0f8bbd5f941171232c5c845")
