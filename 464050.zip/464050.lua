-- Lua provided by RyzenAPI
-- Game: AppID 464050

-- MAIN APPLICATION
addappid(464050)

-- MAIN APP DEPOTS / PACKAGES
addappid(464051, 1, "0a1aec38421581e3caa0a06343c82bed0723a739aa5a1796f214aa9c16093c82")
addappid(464052, 1, "f08ae25d29cd90851accec7a1a9c5f467287fd3c3e5b642e9fd0a050c0bbdf27")

