-- Lua provided by RyzenAPI
-- Game: Heavy Metal Machines

-- MAIN APPLICATION
addappid(331360)
addappid(630110)
addappid(896480)
addappid(977970)
addappid(1007170)
addappid(1061950)

-- MAIN APP DEPOTS / PACKAGES
addappid(331361, 1, "e944ac13a91eee77c2fba3c5330b5b0472c47c1c590e91d9931390942ede0df9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(583220)
addappid(587410)
addappid(587411)
addappid(587412)
addappid(587413)
addappid(587414)
addappid(742770)
addappid(945031)
addappid(945032)
addappid(945033)
addappid(945380)
addappid(978530)
addappid(978531)
addappid(978532)
addappid(988730)
addappid(1015220)
addappid(1015221)
addappid(1015222)
addappid(1072220)
addappid(1072221)
addappid(1072222)
addappid(1114590)
addappid(1114591)
addappid(1167980)
addappid(1425930)
addappid(1425931)
addappid(1425932)
addappid(1425933)
addappid(1550170)
