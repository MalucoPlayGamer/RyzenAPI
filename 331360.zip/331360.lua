-- Lua provided by SkyAPI 
-- Game: Heavy Metal Machines
addappid(331360)
addappid(331361, 1, "e944ac13a91eee77c2fba3c5330b5b0472c47c1c590e91d9931390942ede0df9")
addappid(630110)
addappid(896480)
addappid(977970)
addappid(1007170)
addappid(1061950)
