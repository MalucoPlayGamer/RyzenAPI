-- Lua provided by RyzenAPI 
-- Game: AppID 265590
addappid(265590)
addappid(265591, 1, "1683eb111ecf5633b4ba15a15110e57e9c4479b174b584a2cda72aa82f9ecd7b")
addappid(403910, 0, "046893a8e72f119be064a63da9e8488930592380947a7c5ad6a3780c24a01f00")
