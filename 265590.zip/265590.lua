-- Lua provided by RyzenAPI
-- Game: AppID 265590

-- MAIN APPLICATION
addappid(265590)
addappid(411460)
addappid(790180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(265591, 1, "1683eb111ecf5633b4ba15a15110e57e9c4479b174b584a2cda72aa82f9ecd7b")
addappid(403910, 0, "046893a8e72f119be064a63da9e8488930592380947a7c5ad6a3780c24a01f00")

