-- Lua provided by RyzenAPI
-- Game: 3831090

-- MAIN APPLICATION
addappid(3831090)
-- Game: addappid(3831090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3831091, 1, "a180dea0c133a7c03b16d9419aba8b7d1a5d89be1ce45dca2aa7c754fb7d4ed1")
