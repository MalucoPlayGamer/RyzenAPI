-- Lua provided by RyzenAPI
-- Game: addappid(581130)

-- MAIN APPLICATION
addappid(581130)

-- MAIN APP DEPOTS / PACKAGES
addappid(581131, 1, "892d98caddf02cabe047250f5e3a85737f49cc35552f14c11461265dad31c1aa")
