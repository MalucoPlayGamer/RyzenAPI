-- Lua provided by RyzenAPI
-- Game: Metal Waltz: Anime tank girls

-- MAIN APPLICATION
addappid(581130)

-- MAIN APP DEPOTS / PACKAGES
addappid(581131, 1, "892d98caddf02cabe047250f5e3a85737f49cc35552f14c11461265dad31c1aa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
