-- Lua provided by RyzenAPI
-- Game: 820870

-- MAIN APPLICATION
addappid(820870)

-- MAIN APP DEPOTS / PACKAGES
addappid(820870,0,"080b5893ce0936e403bdc0d457c0386d74b9ca4af8f1fd76fed50c6c96abde9a")

