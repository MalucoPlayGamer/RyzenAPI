-- Lua provided by SkyAPI 
-- Game: AppID 776890
addappid(776890)
addappid(776891, 1, "c4533292a5befa9f0da637d536e2d58b0dab34a54e1a0b9bf85c61d4aad0f183")
