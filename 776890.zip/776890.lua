-- Lua provided by RyzenAPI
-- Game: Clicker: Mining Simulator

-- MAIN APPLICATION
addappid(776890)
addappid(818190)

-- MAIN APP DEPOTS / PACKAGES
addappid(776891, 1, "c4533292a5befa9f0da637d536e2d58b0dab34a54e1a0b9bf85c61d4aad0f183")
