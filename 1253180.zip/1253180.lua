-- Lua provided by RyzenAPI
-- Game: addappid(1253180)

-- MAIN APPLICATION
addappid(1253180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253181, 1, "b61c050ee43cf3387bf350983bc8e58a6f0b6d09c2b7f7200a574eebc99c266b")
