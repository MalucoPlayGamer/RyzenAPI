-- Lua provided by RyzenAPI
-- Game: Dark Disharmony

-- MAIN APPLICATION
addappid(1253180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1253181, 1, "b61c050ee43cf3387bf350983bc8e58a6f0b6d09c2b7f7200a574eebc99c266b")

