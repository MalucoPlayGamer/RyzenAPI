-- Lua provided by RyzenAPI
-- Game: 1032570

-- MAIN APPLICATION
addappid(1032570)
-- Game: addappid(1032570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032571, 1, "cb907790f842c02d67faed0ba392bf53b32225017ba978a91fe7d43b3e84a351")
