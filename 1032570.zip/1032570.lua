-- Lua provided by RyzenAPI
-- Game: Pilot Unknown

-- MAIN APPLICATION
addappid(1032570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032571, 1, "cb907790f842c02d67faed0ba392bf53b32225017ba978a91fe7d43b3e84a351")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
