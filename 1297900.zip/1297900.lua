-- Lua provided by RyzenAPI
-- Game: Game: AppID 1297900

-- MAIN APPLICATION
addappid(1297900)
-- Game: addappid(1297900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297901, 1, "63fe67b675132ec13ab1579e4a9b13f877167ef3b2a7fb4f101e85ca42c42814")
