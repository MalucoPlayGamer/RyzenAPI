-- Lua provided by RyzenAPI
-- Game: Gothic 1 Remake

-- MAIN APPLICATION
addappid(1297900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1297901, 1, "63fe67b675132ec13ab1579e4a9b13f877167ef3b2a7fb4f101e85ca42c42814")
