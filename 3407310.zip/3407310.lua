-- Lua provided by RyzenAPI
-- Game: Consumables

-- MAIN APPLICATION
addappid(3407310)
-- Game: addappid(3407310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3407311, 1, "6ef1ad943ac077def22e5bb2288116f7076edca908413462b9cce6063006fa97")
