-- Lua provided by RyzenAPI
-- Game: addappid(2757500)

-- MAIN APPLICATION
addappid(2757500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757501, 1, "deaecaecaef4fafddf869270d37f028fe8ee702c687433c7a21feca26c54a210")
