-- Lua provided by RyzenAPI 
-- Game: Park assault
addappid(1085240)
addappid(1085241, 1, "92257cc44092f51fbf67e1b86fc31839f80a0c56c4154907219e531047ad7732")
