-- Lua provided by RyzenAPI
-- Game: Hira Hira Hihiru

-- MAIN APPLICATION
addappid(2314820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314821, 1, "c44a622674c25080008679ae62c41278af91a53baa5b42ebb05e6c65163e030c")
