-- Lua provided by RyzenAPI
-- Game: Girl X Island

-- MAIN APPLICATION
addappid(2593400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593401, 1, "e6d112a6cbed8296901c5062f0e855c169125ad6abca553ea12cd8ee726083a9")

