-- Lua provided by RyzenAPI 
-- Game: AppID 468150
addappid(468150)
addappid(468151, 1, "e3a4719c071e030dda9377cd6f28d13c2ad5fe9f178420bdf973b1bf175e5c02")
addappid(504070, 0, "05fcfe3c90c6b11cb88965aabe38d3a389b51f775d81df9a6e2b40865c979f2f")
