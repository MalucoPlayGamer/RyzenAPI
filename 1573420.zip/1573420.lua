-- Lua provided by RyzenAPI
-- Game: AppID 1573420

-- MAIN APPLICATION
addappid(1573420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573421, 1, "c7b847a5913e7c293bacd14e75f171ac79164602f5b2924341139e68a3367148")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1687110)
