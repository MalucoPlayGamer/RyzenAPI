-- Lua provided by RyzenAPI
-- Game: The Shadowland

-- MAIN APPLICATION
addappid(498620)

-- MAIN APP DEPOTS / PACKAGES
addappid(498621, 1, "2230433ea0f63cd3a687d665f5900c8ddc58120567d1e9cbe56e0c4f4f695ba2")
