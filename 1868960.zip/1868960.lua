-- Lua provided by RyzenAPI
-- Game: Game: Monster Hunter Stories 2: Wings of Ruin Original Soundtrack

-- MAIN APPLICATION
addappid(1868960)
-- Game: addappid(1868960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868961, 1, "61def15eb898b89294304d031c2b7e3ce72211758eb97d5ea86187811308db96")
addappid(1868962, 1, "fc4268bc15d1273c1f5e043e968fdf5fb626cfe96119ffb6843b607e74e028c2")
addappid(1868963, 1, "6329a6a0bb6f8dfa347c6f1f16a9dbc569a59124c52c849b3488be85e87f1db1")
