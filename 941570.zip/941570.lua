-- Lua provided by SkyAPI 
-- Game: AppID 941570
addappid(941570)
addappid(941571, 1, "207c6c1477184940ed4d80fe4027f12e13d81302442396d21f121d447fc61a20")
