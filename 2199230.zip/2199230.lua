-- Lua provided by RyzenAPI
-- Game: The Winter Tower

-- MAIN APPLICATION
addappid(2199230)
addappid(2210910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199231, 1, "1dbfe4a22b075ae32b033b6598e0ea561a7a795d93062ac16fc4fbac164ede89")
