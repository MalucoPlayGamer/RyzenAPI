-- Lua provided by RyzenAPI
-- Game: Workplace Fantasy

-- MAIN APPLICATION
addappid(2544720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544721, 1, "8efd5e37dbb85b2b655f5332cb3c5060ffa02e17f594658dfb45a8fad670b98b")

