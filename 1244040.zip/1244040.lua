-- Lua provided by RyzenAPI
-- Game: Game: Crocotile 3D

-- MAIN APPLICATION
addappid(1244040)
-- Game: addappid(1244040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244041, 1, "8877a5d1d085f8bd3e30d677f45757104a120dafa811cf8b8a7d94e0d6cd2bf8")
addappid(1244044, 1, "ac90285d5c5308df897fabd50d4683ed2641b00ddf71bb98fdf07e72f3343708")
