-- Lua provided by RyzenAPI
-- Game: 1079460

-- MAIN APPLICATION
addappid(1079460)
-- Game: addappid(1079460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079460,0,"3bb3fac221d19f4e93bd16c8d7edde3a750d564569c7f45eb2a117be5210a752")
