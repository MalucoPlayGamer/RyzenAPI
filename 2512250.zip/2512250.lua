-- Lua provided by RyzenAPI
-- Game: Potions & Emotions

-- MAIN APPLICATION
addappid(2512250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2512251, 1, "c4b6fe82442afa7e19ea84c3f24c6cdd2d5a60ff578982e9d90e0ad71aa0abe5")

