-- Lua provided by RyzenAPI
-- Game: addappid(2512250)

-- MAIN APPLICATION
addappid(2512250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512251, 1, "c4b6fe82442afa7e19ea84c3f24c6cdd2d5a60ff578982e9d90e0ad71aa0abe5")
