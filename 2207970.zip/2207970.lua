-- Lua provided by RyzenAPI
-- Game: Game: Interior Worlds

-- MAIN APPLICATION
addappid(2207970)
-- Game: addappid(2207970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207971, 1, "7b21f828b8181c8f737e0b84a486f178eb42e0cd3c0c04cec6f29356c0ba420b")
addappid(2207972, 1, "ccaaebed50ea7bca15d3f9ff0d7fbea8acd059ad35186c4288c07fb125d73ed0")
addappid(2207973, 1, "b5441832c01a2441eaefa77ff88f54aa6c438ac1147a0c03e88e8eac281be3a2")
