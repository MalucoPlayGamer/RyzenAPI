-- Lua provided by RyzenAPI
-- Game: Game: Deathstreak

-- MAIN APPLICATION
addappid(2355960)
-- Game: addappid(2355960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355961, 1, "bc71e0480b1de8f3981c36e0ebd098085cb8f35240e09a14e00aa3e36efdbe40")
