-- Lua provided by RyzenAPI 
-- Game: Veritex
addappid(695360)
addappid(695361, 1, "11d0426926a6c4544377d9bd3a6e286b348617b390094d3b1d903d7b0e6b3028")
