-- Lua provided by RyzenAPI
-- Game: Veritex

-- MAIN APPLICATION
addappid(695360)
-- Game: addappid(695360)

-- MAIN APP DEPOTS / PACKAGES
addappid(695361, 1, "11d0426926a6c4544377d9bd3a6e286b348617b390094d3b1d903d7b0e6b3028")
