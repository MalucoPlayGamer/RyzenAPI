-- Lua provided by RyzenAPI
-- Game: 1890480

-- MAIN APPLICATION
addappid(1890480)
-- Game: addappid(1890480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890481, 1, "70d6cf7fa79d0ec1ddf4940f555339bd9df5f626d06ae32c904bf717fbe68910")
