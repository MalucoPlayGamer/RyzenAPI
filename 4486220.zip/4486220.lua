-- Lua provided by RyzenAPI
-- Game: Touhou Brawl

-- MAIN APPLICATION
addappid(4486220) -- Touhou Brawl

-- MAIN APP DEPOTS / PACKAGES
addappid(4486221, 1, "0664b9e0b2b6c57b447fd9ac8b3b0b04a0f23035e5f3795b447b3450556096ed") -- Depot 4486221

