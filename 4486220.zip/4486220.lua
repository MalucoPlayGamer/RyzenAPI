-- 4486220's Lua and Manifest Created by Hubcap Manifest
-- Touhou Brawl
-- Created: August 12, 2026 at 01:03:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4486220) -- Touhou Brawl
-- MAIN APP DEPOTS
addappid(4486221, 1, "0664b9e0b2b6c57b447fd9ac8b3b0b04a0f23035e5f3795b447b3450556096ed") -- Depot 4486221
setManifestid(4486221, "3509655277362654456", 1788187065)