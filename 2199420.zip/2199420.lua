-- Lua provided by RyzenAPI
-- Game: Brickadia

-- MAIN APPLICATION
addappid(2199420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199421, 1, "dd5d3a0060c907a988b6971044f22aaef92eb8ae98c17a52646265fc2f11b95f")
