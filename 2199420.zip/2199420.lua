-- Lua provided by RyzenAPI
-- Game: Brickadia

-- MAIN APPLICATION
addappid(2199420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199421, 1, "dd5d3a0060c907a988b6971044f22aaef92eb8ae98c17a52646265fc2f11b95f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
