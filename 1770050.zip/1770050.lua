-- Lua provided by RyzenAPI 
-- Game: Total Tank Generals
addappid(1770050)
addappid(1770051, 1, "bf432590813abe5a0bd3d4730399c64740da3d54e84e25cda88c78352717f4e6")
