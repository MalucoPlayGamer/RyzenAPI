-- Lua provided by RyzenAPI
-- Game: addappid(1025890)

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(1025890)
addappid(1025910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025898,0,"7be56338e394c64985e671ba3d992f1cc23cb6af48b1d9565f24764dd8ac15be")
