-- Lua provided by RyzenAPI
-- Game: Tom the Postgirl Demo

-- MAIN APPLICATION
addappid(2707660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707661, 1, "5478b66223654d0e3ec32869dcafa6a961e5211b015006733240b65d882c5d8e")

