-- Lua provided by RyzenAPI
-- Game: Game: Puppet House

-- MAIN APPLICATION
addappid(1707710)
-- Game: addappid(1707710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707711, 1, "44c116d640021ee56853c4d656e498e6e7c7f8340169d0eedc313e8be7ae0f74")
