-- Lua provided by RyzenAPI
-- Game: Puppet House

-- MAIN APPLICATION
addappid(1707710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1707711, 1, "44c116d640021ee56853c4d656e498e6e7c7f8340169d0eedc313e8be7ae0f74")

