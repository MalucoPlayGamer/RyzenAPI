-- Lua provided by RyzenAPI
-- Game: Game: AppID 1454730

-- MAIN APPLICATION
addappid(1454730)
-- Game: addappid(1454730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454731, 1, "e36d0c4ea6df8d1381f39f9faed47e09c560670cd76387048605404e3115694d")
