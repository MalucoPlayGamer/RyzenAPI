-- Lua provided by RyzenAPI
-- Game: A Park Full of Cats: Haunted Ride

-- MAIN APPLICATION
addappid(2673390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673390,0,"6720a28747b5bfd62383f583a2b2d90f0d477fdc907941350b1a87a880d47ecf")

