-- Lua provided by RyzenAPI
-- Game: addappid(3096010)

-- MAIN APPLICATION
addappid(3096010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3096011, 1, "3c32f0eb40215b699768dfa4f1b0bc9b18dbe848b99436949b89f45e6989f8b8")
