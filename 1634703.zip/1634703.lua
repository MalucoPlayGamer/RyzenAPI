-- Lua provided by RyzenAPI
-- Game: addappid(1634703)

-- MAIN APPLICATION
addappid(1634703)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634703,0,"7e31fc47493700d03064b0591cd862ab01b9e341a08bc2831d89c36ebd36ffc3")
