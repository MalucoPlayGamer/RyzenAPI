-- Lua provided by RyzenAPI
-- Game: Internet Simulator

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(229006)
addappid(758050)
-- Game: addappid(758050)

-- MAIN APP DEPOTS / PACKAGES
addappid(758057,0,"2a246c9ad3cbd57a04e3a55abf1df5b62d42013dc4e9db203ec08600c28684c0")
