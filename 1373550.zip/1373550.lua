-- Lua provided by RyzenAPI
-- Game: BloodRayne 2: Terminal Cut

-- MAIN APPLICATION
addappid(1373550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373551, 1, "a6654e02d3102fdd94c34601cb157943167510f0971228f403f41783988c65bf")
addappid(1373552, 1, "58a4242332e6a0b27ad94bbb62d2cd7f004c50e31e48bbb707c3cf2979047a7d")
addappid(1373553, 1, "966346629cdfda4b45f83b7de0b791fd03f0f102d4ee9beaac631e23308900cc")
addappid(1373554, 1, "818fa66186af9c5ca3b00655860d89b83c0ef916b1b41758b50032e85b0d75f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
