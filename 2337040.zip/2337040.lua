-- Lua provided by RyzenAPI
-- Game: Wall World Original Soundtrack

-- MAIN APPLICATION
addappid(2337040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337041, 1, "d2b57c782e18687ab300bb0fc38aff1214b02d860b529650a485dd75e8c6023f")
addappid(2337042, 1, "9825d714b22e6dc5db941190cb1bdd94c057119956f0fffb8bc3f1cc0befb6b4")

