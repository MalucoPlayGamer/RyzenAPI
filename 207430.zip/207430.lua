-- Lua provided by RyzenAPI
-- Game: Game: Hack, Slash, Loot

-- MAIN APPLICATION
addappid(207430)
-- Game: addappid(207430)

-- MAIN APP DEPOTS / PACKAGES
addappid(207431, 1, "e1b35c6d3ea8c70832df0bdaf1a3b9ac2cd12134761b65b9b17ecd4d091a948a")
addappid(207432, 1, "48b5eec6313bc3a4bdaf91fef87a36718eea0319b09899bdea9ed4cee522f047")
addappid(207433, 1, "9ba81ce95a05c2b39af6c5e295eba516c17c48c5632e776710458c27b69f1842")
addappid(207434, 1, "2b4b09df5a2cf4ae2ec4c3d417626057f4f3e532ec5e8b54f7aadb030a4a10af")
addappid(207435, 1, "027631bb984226d54b450e3554d8931dd89d2d07a3618ee590e77666d3d9c93a")
addappid(207436, 1, "3f2648f6be52775229ac2498108bc327b4f6c33cda5e26e11a6c838a602a8010")
