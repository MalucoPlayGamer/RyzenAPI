-- Lua provided by RyzenAPI
-- Game: addappid(2700230)

-- MAIN APPLICATION
addappid(2700230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700231, 1, "6b61d22f5375e0302ead3a4d9f5490be7510ae53e44ce051de429d9942fe3e30")
