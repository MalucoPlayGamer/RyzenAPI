-- Lua provided by RyzenAPI
-- Game: Game: AppID 562680

-- MAIN APPLICATION
addappid(562680)
-- Game: addappid(562680)

-- MAIN APP DEPOTS / PACKAGES
addappid(562681, 1, "e4c067e7b4461908e2f5e4112fb6d98804e737fa3d4e07ca694bc5bf0815b368")
addappid(562682, 1, "f41cd3666166e315805163ff1e46610685553ea0e6d9acfe4db906c9dbcb3692")
addappid(562683, 1, "9c4e644e81232d64f18599ccbb9dcd4acbd8e5b6d745ffff7c02214fcc8fab2e")
