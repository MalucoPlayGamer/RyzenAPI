-- Lua provided by RyzenAPI
-- Game: Game: AppID 629840

-- MAIN APPLICATION
addappid(629840)
-- Game: addappid(629840)

-- MAIN APP DEPOTS / PACKAGES
addappid(629841, 1, "a06b5b854d9108dcc31e700a4a905a89a5f1712b523b0681d18274ec5a32394f")
