-- Lua provided by RyzenAPI
-- Game: AppID 1144040

-- MAIN APPLICATION
addappid(1144040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144041, 1, "ee4ef9698bb44e05dfba27fd15415c4949ecc4de8adc7c95d19d64462c055d71")

