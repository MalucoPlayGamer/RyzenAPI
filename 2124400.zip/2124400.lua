-- Lua provided by RyzenAPI
-- Game: Egression Demo

-- MAIN APPLICATION
addappid(2124400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124401, 1, "f7e60e511457a690bc2184472f5ba533592b891bc08e3a51a66d7b9f9d371684")

