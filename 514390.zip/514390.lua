-- Lua provided by RyzenAPI
-- Game: 514390

-- MAIN APPLICATION
addappid(514390)
-- Game: addappid(514390)

-- MAIN APP DEPOTS / PACKAGES
addappid(514391, 1, "c3e11a7655b5b7cbad9c016b9d89fecbcc181acf25256e77a4b57aa0620e569a")
