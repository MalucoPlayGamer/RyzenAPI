-- Lua provided by RyzenAPI
-- Game: 2772460

-- MAIN APPLICATION
addappid(2772460)
-- Game: addappid(2772460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772461, 1, "b54e4b2ad070987fcc25263fff60da241b5822835933302e4e6cdda1210cece4")
