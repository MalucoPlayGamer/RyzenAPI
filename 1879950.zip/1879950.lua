-- Lua provided by RyzenAPI
-- Game: Game: Psychroma

-- MAIN APPLICATION
addappid(1879950)
-- Game: addappid(1879950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879951, 1, "ca0459a2a86d27cfc530091fa46a367d52f30ea10967ac6f548446372dd86a28")
