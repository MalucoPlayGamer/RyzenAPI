-- Lua provided by RyzenAPI
-- Game: Momentum

-- MAIN APPLICATION
addappid(1755980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755981, 1, "57b5c60d9dc61af6dbd1b0da1b969ebafde03e43b2db7b067d9f7809693132b2")
