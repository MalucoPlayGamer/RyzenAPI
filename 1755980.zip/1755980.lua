-- Lua provided by SkyAPI 
-- Game: Momentum
addappid(1755980)
addappid(1755981, 1, "57b5c60d9dc61af6dbd1b0da1b969ebafde03e43b2db7b067d9f7809693132b2")
