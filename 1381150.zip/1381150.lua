-- Lua provided by RyzenAPI
-- Game: Game: Desirable

-- MAIN APPLICATION
addappid(1381150)
-- Game: addappid(1381150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381151, 1, "5e6f7bf016aeb7fd827b88fd2c17b85b64b4edf8beb5b3d7b835ac71a27cf474")
