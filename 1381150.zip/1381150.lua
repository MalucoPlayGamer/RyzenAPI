-- Lua provided by RyzenAPI
-- Game: Desirable

-- MAIN APPLICATION
addappid(1381150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1381151, 1, "5e6f7bf016aeb7fd827b88fd2c17b85b64b4edf8beb5b3d7b835ac71a27cf474")

