-- Lua provided by SkyAPI 
-- Game: Herder
addappid(1583170)
addappid(1583171, 1, "b7548bff9d443c5260cf4ba593c723f86104f29fdf8f20a7cb1f8a74eb6cf686")
