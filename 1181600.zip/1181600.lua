-- Lua provided by RyzenAPI
-- Game: Game: Jetboard Joust

-- MAIN APPLICATION
addappid(1181600)
-- Game: addappid(1181600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181601, 1, "490995167ca51a626c96cdc688125846855fda8f8dda16a2fa44f7b2ff8b4754")
addappid(1181602, 1, "983bf954acf5431ec10aa6800aef31c0d873d79f1f82525a76640fab5e533d7a")
addappid(1181603, 1, "fd8f344d7fd9d625d5628c814f4a716f98ea09eb320707134c2c92243a70ebc0")
