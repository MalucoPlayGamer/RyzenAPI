-- Lua provided by RyzenAPI
-- Game: Kingdom Eighties: Art Book

-- MAIN APPLICATION
addappid(2434240)
-- Game: addappid(2434240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434240,0,"2e59bb7db6c9eef9dc82fd15437b7e0e9a7bba4e601ab00136a754510f7f161a")
