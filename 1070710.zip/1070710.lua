-- Lua provided by RyzenAPI
-- Game: addappid(1070710)

-- MAIN APPLICATION
addappid(1070710)
addappid(1129440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070711, 1, "6701bf413ec218d98086b3f2e3c667ac7eabf90e73f152befca258f278a1e77c")
addappid(1070712, 1, "d9587e963d5ad65ed46f8f2579a3c09f9965abdabd551e7f0e49b357463b8c3c")
addappid(1070713, 1, "0c0f38a808262d76195b78fe48b131e65d54cc7ad49ce5aaccd6fb2d63d144ec")
