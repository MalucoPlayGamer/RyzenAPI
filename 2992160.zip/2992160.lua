-- Lua provided by RyzenAPI
-- Game: Counterpick Labs Demo

-- MAIN APPLICATION
addappid(2992160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2992161, 1, "4e9bbb79e8d4507410f3bef009b101e8524f1c1c1e8f2283eafcc201334ec850")
