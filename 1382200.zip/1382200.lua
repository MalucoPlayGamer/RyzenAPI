-- Lua provided by RyzenAPI
-- Game: 1382200

-- MAIN APPLICATION
addappid(1382200)
-- Game: addappid(1382200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382201, 1, "92f62d9409b4a1cea30e0888d83e9e55687d319d4a1c7411da4e6e96a0df2027")
