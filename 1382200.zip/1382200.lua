-- Lua provided by RyzenAPI
-- Game: Liquidators

-- MAIN APPLICATION
addappid(1382200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382201, 1, "92f62d9409b4a1cea30e0888d83e9e55687d319d4a1c7411da4e6e96a0df2027")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
