-- Lua provided by RyzenAPI
-- Game: Planet Lander

-- MAIN APPLICATION
addappid(1183140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183141, 1, "9d43c784ba0000c2c32799d0772eb437a4b4d70aadaf9e3f5f76a53a22c8f30f")
addappid(1183142, 1, "c55814b22632215ba0372ae2a79ad12512ad5a7587988970c25bed47cb9844b4")
addappid(1185260, 0, "b656e27cd9baf8f7cc3371550ccdcbb19d3602bbe4eb05be8e62e66d17c183e7")

