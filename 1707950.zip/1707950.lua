-- Lua provided by RyzenAPI
-- Game: Wisper

-- MAIN APPLICATION
addappid(1707950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1707951,0,"86bcbdd7f4c158dca20b97288dd4209227dc818a142b96ee8ae14af05a27c34e")

