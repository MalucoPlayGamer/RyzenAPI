-- Lua provided by RyzenAPI
-- Game: Wisper

-- MAIN APPLICATION
addappid(1707950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707951,0,"86bcbdd7f4c158dca20b97288dd4209227dc818a142b96ee8ae14af05a27c34e")

