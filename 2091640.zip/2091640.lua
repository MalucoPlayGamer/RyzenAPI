-- Lua provided by RyzenAPI
-- Game: addappid(2091640)

-- MAIN APPLICATION
addappid(2091640)
addappid(2091641)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091642,0,"1710de2d3b5071642e505c2dca00c547e78e58cd91b9f7a22ee84df198f835e2")
