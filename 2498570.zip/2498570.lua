-- Lua provided by RyzenAPI
-- Game: 2498570

-- MAIN APPLICATION
addappid(2498570)
-- Game: addappid(2498570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498571, 1, "b95d7418891b98794ab983f736cc64f95fec58eba0df86b971cfc802bce7721b")
