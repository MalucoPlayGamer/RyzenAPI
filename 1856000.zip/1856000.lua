-- Lua provided by RyzenAPI
-- Game: DIKDIK Video Kit 2025

-- MAIN APPLICATION
addappid(1856000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856001, 1, "536eae2d21dc0e4a17afaaff3e945d070224c6e870c18e4c20d08f21976c8c33")
