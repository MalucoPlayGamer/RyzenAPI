-- Lua provided by RyzenAPI
-- Game: Iron Danger

-- MAIN APPLICATION
addappid(899310)
addappid(1130871)
addappid(1130872)

-- MAIN APP DEPOTS / PACKAGES
addappid(899311, 1, "5b50ebc0fc1d646c5f81e18a0bab004b12c658ea3d57fdc5065a2cf21e4a5254")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
