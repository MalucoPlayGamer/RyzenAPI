-- Lua provided by RyzenAPI
-- Game: 899310

-- MAIN APPLICATION
addappid(899310)
addappid(1130871)
addappid(1130872)
-- Game: addappid(899310)

-- MAIN APP DEPOTS / PACKAGES
addappid(899311, 1, "5b50ebc0fc1d646c5f81e18a0bab004b12c658ea3d57fdc5065a2cf21e4a5254")
