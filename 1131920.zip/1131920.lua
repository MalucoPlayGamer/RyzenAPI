-- Lua provided by RyzenAPI
-- Game: AppID 1131920

-- MAIN APPLICATION
addappid(1131920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131921, 1, "113fec35ed7ecf818a476aaaf4595f4ba4d1e2ca3dd8a51037ff10cfdfafd93d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
