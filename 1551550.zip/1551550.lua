-- Lua provided by RyzenAPI
-- Game: Philana and the Elixir of Life

-- MAIN APPLICATION
addappid(1551550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551551, 1, "a486db06ce10b4e58e2687ae045b03c7333f3e4482a4fdaec8fa4c8468a686e9")
addappid(1551552, 1, "9e50c15214381f2050c2c713981a92db9f25f83867522b678b91b0dd05946ec8")
addappid(1551553, 1, "61655f953aded91e11f8f5c0a06e65a38b10ab5ba759da8166795dca21d7967e")

