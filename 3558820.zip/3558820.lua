-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3558820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558820,0,"ab5ed1844b76e916ea4ee72419ba812c40aa5ee6454c80c008ce407bbb6c3787")
addtoken(3558820,17041046302464287435)

