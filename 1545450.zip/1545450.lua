-- Lua provided by RyzenAPI
-- Game: Incredibox

-- MAIN APPLICATION
addappid(1545450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545451, 1, "59a399e17aace3e46fb1c7d7dead965a78c15b5b077b014e0b80247f51a08e5c")
addappid(1545452, 1, "7c052a610f702e815b778ce422340dc38c5f0079b5c127790261fd7ff385eb2e")
