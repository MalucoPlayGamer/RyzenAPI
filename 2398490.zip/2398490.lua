-- Lua provided by RyzenAPI
-- Game: Classic Marathon 2

-- MAIN APPLICATION
addappid(2398490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398491, 1, "39bd9e72d2b6e7aa833adb5a4f319d2959725563e271740f810e2d8f8ace2202")
addappid(2398492, 1, "3de463a2f2c27cd70d900c62ac7456985965b6c0fb90b0754b1aa95e1b09d994")
addappid(2398493, 1, "18e722fbff508c0c85a3054ecb98bb832efe081f5fa28b69dce2b2a8d6f9c2a8")
addappid(3060640, 0, "f0e71d050efa47c460b5824160dcdfdbef6185b73ac613f67f8b7a8ba19e98a2")

