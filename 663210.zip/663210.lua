-- Lua provided by RyzenAPI
-- Game: 12 Labours of Hercules VII: Fleecing the Fleece

-- MAIN APPLICATION
addappid(663210)

-- MAIN APP DEPOTS / PACKAGES
addappid(663211, 1, "82ab63a8b3c4e774bb0b7e7bc178053208a5d634d248a4be2d44d9f5605ae862")

