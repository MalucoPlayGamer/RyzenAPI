-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] The Night Way Home | 帰り道

-- MAIN APPLICATION
addappid(1671550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671551, 1, "a90450ca8cdad91e953978cc2d5645458747bebdb7f8ac5f896ab74b2366fb5a")

