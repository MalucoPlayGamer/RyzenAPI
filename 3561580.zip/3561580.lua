-- Lua provided by RyzenAPI
-- Game: Hauntrick

-- MAIN APPLICATION
addappid(3561580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561581, 1, "e966c23bde534662f299f35df3f30c5c4bc672a6da13ad235680ecb308839c49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
