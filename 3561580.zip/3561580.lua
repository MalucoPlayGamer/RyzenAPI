-- Lua provided by RyzenAPI
-- Game: addappid(3561580)

-- MAIN APPLICATION
addappid(3561580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561581, 1, "e966c23bde534662f299f35df3f30c5c4bc672a6da13ad235680ecb308839c49")
