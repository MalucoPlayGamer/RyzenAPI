-- Lua provided by RyzenAPI
-- Game: Sport Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1378610)
-- Game: addappid(1378610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378610,0,"bf8dd34ec617a0db9a29386244f386c5f741c3787c672d09b5654d08245463f1")
