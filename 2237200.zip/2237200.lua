-- Lua provided by RyzenAPI
-- Game: Fire Shark

-- MAIN APPLICATION
addappid(2237200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2237201, 1, "0bbf7122d35ea2b5ab1532bf1ce8c06b5141a2328ba62fa8ac25dd50d4fef93f")

