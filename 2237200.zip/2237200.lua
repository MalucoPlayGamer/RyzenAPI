-- Lua provided by RyzenAPI
-- Game: Fire Shark

-- MAIN APPLICATION
addappid(2237200)
-- Game: addappid(2237200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237201, 1, "0bbf7122d35ea2b5ab1532bf1ce8c06b5141a2328ba62fa8ac25dd50d4fef93f")
