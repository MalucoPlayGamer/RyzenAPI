-- Lua provided by RyzenAPI 
-- Game: Brave Battle Saga - The Legend of The Magic Warrior
addappid(1028520)
addappid(1028521, 1, "16f7d82c0a7feb2e10a380e16a927d1b9ff339270d05bcc1c07901fde3c8a82d")
