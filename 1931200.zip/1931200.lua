-- Lua provided by RyzenAPI
-- Game: Bleeding Abyss

-- MAIN APPLICATION
addappid(1931200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931201, 1, "f60139b28aae3ce349b84251fba600466c9c2e7c50d76023409bfbbadaf9e53d")
