-- Lua provided by RyzenAPI
-- Game: AppID 416190

-- MAIN APPLICATION
addappid(416190)

-- MAIN APP DEPOTS / PACKAGES
addappid(416191, 1, "c9e72b83e1698ada097a81be19d2d807bbd5d85c0ffe00c59c4785e81b0c3687")
addappid(420340, 0, "af98a4824eac34482b467988b419bfe6297e866516c9eecc949e33c981571be5")
addappid(425750, 0, "b5b0d8c62372f770eea61c46a4cdb6f35612630f318ea10d42df95e3ab568002")
addappid(425910, 0, "73a943583bde8cdf6fd176bf0662a94877b5f2e92e6f932b7761a4a020f239e2")
addappid(425920, 0, "877762494d4baa37a83ab1132de7dd25f9f289ddf643eb3224c0df967ebef2ef")
addappid(425930, 0, "37ae9899e32068dbf11b1d636ff89d89fd9aef9df30f0c4ca23146584737b6dc")
addappid(425940, 0, "7001693a54b9322e68b260a048338b4f061bd5a507caf5259f7ef425a55ff5ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(427740)
