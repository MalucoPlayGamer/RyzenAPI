-- Lua provided by RyzenAPI
-- Game: Game: Chronicle Keepers: The Dreaming Garden

-- MAIN APPLICATION
addappid(377120)
-- Game: addappid(377120)

-- MAIN APP DEPOTS / PACKAGES
addappid(377121, 1, "966930712a07f2753cd6951822ed46deb36551cb32169846ed13ae535358bccd")
