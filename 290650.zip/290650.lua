-- Lua provided by RyzenAPI
-- Game: Time Ramesside (A New Reckoning)

-- MAIN APPLICATION
addappid(290650)

-- MAIN APP DEPOTS / PACKAGES
addappid(290651, 1, "9e4e41a9c172f7ea0af7bd05516b61ee236d5ef05fdd989d4357e5389210c81e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
