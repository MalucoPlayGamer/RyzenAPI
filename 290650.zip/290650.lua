-- Lua provided by RyzenAPI
-- Game: Time Ramesside (A New Reckoning)

-- MAIN APPLICATION
addappid(290650)

-- MAIN APP DEPOTS / PACKAGES
addappid(290651, 1, "9e4e41a9c172f7ea0af7bd05516b61ee236d5ef05fdd989d4357e5389210c81e")

