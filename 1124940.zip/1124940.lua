-- Lua provided by RyzenAPI 
-- Game: AppID 1124940
addappid(1124940)
addappid(1124941, 1, "b5992c620e081ddfe85d8b86847f0948adc8e8535c245d19260c33634521714a")
