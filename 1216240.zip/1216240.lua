-- Lua provided by RyzenAPI
-- Game: 1216240

-- MAIN APPLICATION
addappid(1216240)
-- Game: addappid(1216240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216241, 1, "af0187bafa4ff063e20770d94efd042147ed36af19dbb10b69d3b7838494c0c0")
