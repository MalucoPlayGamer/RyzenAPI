-- Lua provided by RyzenAPI
-- Game: 1724770

-- MAIN APPLICATION
addappid(1724770)
-- Game: addappid(1724770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724771, 1, "11df170a07e820b570926cef24458f4bae5f93d2fe798173b2b7c274910fbde1")
