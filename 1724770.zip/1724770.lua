-- Lua provided by SkyAPI 
-- Game: Castle Of Alchemists
addappid(1724770)
addappid(1724771, 1, "11df170a07e820b570926cef24458f4bae5f93d2fe798173b2b7c274910fbde1")
