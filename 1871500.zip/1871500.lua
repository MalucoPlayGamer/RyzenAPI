-- Lua provided by RyzenAPI
-- Game: One Line: Letters and Codes

-- MAIN APPLICATION
addappid(1871500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871501, 1, "00607d68588e3a8530716e85c96d234f71d3435fc183f2c47f8b26d882b41bd6")
