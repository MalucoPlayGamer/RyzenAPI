-- Lua provided by RyzenAPI
-- Game: 1501980

-- MAIN APPLICATION
addappid(1501980)
-- Game: addappid(1501980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501981, 1, "546d8a78774bcc937abedebfc880c30f243313f6e856cf5aae078b4002cf790e")
