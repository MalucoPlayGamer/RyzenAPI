-- Lua provided by RyzenAPI
-- Game: 15320

-- MAIN APPLICATION
addappid(15320)
-- Game: addappid(15320)

-- MAIN APP DEPOTS / PACKAGES
addappid(15321, 1, "6531d3a11c55db1c7b0cec3247f98052192c83fd94a40c2fdaaff0505657f21e")
addappid(15322, 1, "ebde747d47d1ea0a21f2cddda8e8fb79b7cfa1a76eb430626d5536b148e9afa7")
