-- Lua provided by RyzenAPI
-- Game: Habitat

-- MAIN APPLICATION
addappid(299340)

-- MAIN APP DEPOTS / PACKAGES
addappid(299341, 1, "87bd2e520354cb2513193da54ca77e40f8ec527092d5ed5ee058277594c70524")
addappid(299342, 1, "08f6df620b19af72081c2a03042f281a012821571d30b9b1318d5e493141889d")
addappid(299343, 1, "966d9c1abb54c1cbedef98ea80c291cf61f91efeca666adbf1b9f2148191b6f0")
addappid(299344, 1, "a3049381d3a5b533ddfda87a8261ec267339a152bca69e1b791b5826a564b034")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
