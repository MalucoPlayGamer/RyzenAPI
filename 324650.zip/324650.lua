-- Lua provided by SkyAPI 
-- Game: Gemini: Heroes Reborn
addappid(324650)
addappid(324651, 1, "47ebba61c1ede522966a4f5769b40141514c7e41edb87259b4e971e67a28140a")
addappid(324652, 1, "fbcfac9b3203bece2f4b7480e1880dcae8757377e638afbf51fb422cba989b56")
