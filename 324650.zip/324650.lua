-- Lua provided by RyzenAPI
-- Game: Gemini: Heroes Reborn

-- MAIN APPLICATION
addappid(324650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(324651, 1, "47ebba61c1ede522966a4f5769b40141514c7e41edb87259b4e971e67a28140a")
addappid(324652, 1, "fbcfac9b3203bece2f4b7480e1880dcae8757377e638afbf51fb422cba989b56")

