-- Lua provided by RyzenAPI
-- Game: Game: Aethermancer Demo

-- MAIN APPLICATION
addappid(3462260)
-- Game: addappid(3462260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3462261, 1, "41f778836a9554baea47e7307b581c0d01af86432ca79b48a49c0fb997416587")
