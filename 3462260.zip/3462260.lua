-- Lua provided by SkyAPI 
-- Game: Aethermancer Demo
addappid(3462260)
addappid(3462261, 1, "41f778836a9554baea47e7307b581c0d01af86432ca79b48a49c0fb997416587")
