-- Lua provided by RyzenAPI
-- Game: AppID 3343220

-- MAIN APPLICATION
addappid(3343220)
-- Game: addappid(3343220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343221, 1, "7ce75873309e98bbe2cf27a07c7ebee90e9c91450b671d5deb29bdc29afffafb")
