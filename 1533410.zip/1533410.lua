-- Lua provided by RyzenAPI
-- Game: 1533410

-- MAIN APPLICATION
addappid(1533410)
-- Game: addappid(1533410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533412,0,"817caa36fc9380382b76e89d94c8ebc1bbce134c9f9f2e90732c845ee3db5f5b")
