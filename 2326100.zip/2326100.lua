-- Lua provided by SkyAPI 
-- Game: Reclusive
addappid(2326100)
addappid(2326101, 1, "03ce60d171a9dc99f075054191fb93dbb4277340256975067cbc5b36254852e0")
