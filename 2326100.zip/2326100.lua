-- Lua provided by RyzenAPI
-- Game: Game: Reclusive

-- MAIN APPLICATION
addappid(2326100)
-- Game: addappid(2326100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326101, 1, "03ce60d171a9dc99f075054191fb93dbb4277340256975067cbc5b36254852e0")
