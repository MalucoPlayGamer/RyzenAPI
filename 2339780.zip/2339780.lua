-- Lua provided by SkyAPI 
-- Game: Dickland
addappid(2339780)
addappid(2339781, 1, "6b0015310730c00f4a1f7a4d7ba34ea926751fc3448b3e639182daeb0b1acb52")
