-- Lua provided by RyzenAPI
-- Game: Dickland

-- MAIN APPLICATION
addappid(2339780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2339781, 1, "6b0015310730c00f4a1f7a4d7ba34ea926751fc3448b3e639182daeb0b1acb52")

