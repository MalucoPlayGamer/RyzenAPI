-- Lua provided by RyzenAPI
-- Game: Craftopia - Soundtrack

-- MAIN APPLICATION
addappid(1412690)
-- Game: addappid(1412690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412691, 1, "7fd210f023f080dd28a81280aaede6446f2919889c3cc2650f83ff9d2e7616ac")
