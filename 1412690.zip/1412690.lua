-- Lua provided by RyzenAPI 
-- Game: Craftopia - Soundtrack
addappid(1412690)
addappid(1412691, 1, "7fd210f023f080dd28a81280aaede6446f2919889c3cc2650f83ff9d2e7616ac")
