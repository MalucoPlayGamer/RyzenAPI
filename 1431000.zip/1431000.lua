-- Lua provided by RyzenAPI
-- Game: addappid(1431000)

-- MAIN APPLICATION
addappid(1431000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431001, 1, "cde7b8047aa19d466a707672e570f6c4c22447bc2aca8dac9fe13a568602d012")
