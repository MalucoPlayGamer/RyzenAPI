-- Lua provided by RyzenAPI
-- Game: addappid(2589880)

-- MAIN APPLICATION
addappid(2589880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589881, 1, "678102340c78c3980ae48766ab41313ff41b3a8b5bddbaafbf7408c97d37b419")
