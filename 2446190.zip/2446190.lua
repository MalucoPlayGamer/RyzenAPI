-- Lua provided by RyzenAPI
-- Game: 晨晨力量人 Adventure of Roger

-- MAIN APPLICATION
addappid(2446190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446191, 1, "6606d010d79090be39dcdf7552eed49585229b2bc5705a62786eba9f50f68b76")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
