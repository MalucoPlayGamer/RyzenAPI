-- Lua provided by SkyAPI 
-- Game: 晨晨力量人 Adventure of Roger
addappid(2446190)
addappid(2446191, 1, "6606d010d79090be39dcdf7552eed49585229b2bc5705a62786eba9f50f68b76")
