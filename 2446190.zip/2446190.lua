-- Lua provided by RyzenAPI
-- Game: 晨晨力量人 Adventure of Roger

-- MAIN APPLICATION
addappid(2446190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446191, 1, "6606d010d79090be39dcdf7552eed49585229b2bc5705a62786eba9f50f68b76")

