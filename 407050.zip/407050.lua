-- Lua provided by RyzenAPI
-- Game: Game: AppID 407050

-- MAIN APPLICATION
addappid(407050)
-- Game: addappid(407050)

-- MAIN APP DEPOTS / PACKAGES
addappid(407051, 1, "5c8f6de7de7bc95c4a8b80cc371c39d2cc2bb5695204d48889bda58b18102ed2")
