-- Lua provided by RyzenAPI
-- Game: AppID 407050

-- MAIN APPLICATION
addappid(407050)

-- MAIN APP DEPOTS / PACKAGES
addappid(407051, 1, "5c8f6de7de7bc95c4a8b80cc371c39d2cc2bb5695204d48889bda58b18102ed2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
