-- Lua provided by RyzenAPI
-- Game: Ragdoll: Fall Simulator

-- MAIN APPLICATION
addappid(1524400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524401, 1, "bfcccabdc8cfdc4fbb74866d2ac717240cebe3f331525c7242a3e500b8495017")
