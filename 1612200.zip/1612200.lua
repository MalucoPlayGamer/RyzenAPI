-- Lua provided by RyzenAPI
-- Game: Blokker: Orange

-- MAIN APPLICATION
addappid(1612200)
-- Game: addappid(1612200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612201, 1, "abbb009060f24e016132d297ff4d188c3bfd6a3f156793ecc4c0988997f82364")
