-- Lua provided by RyzenAPI
-- Game: 1512790

-- MAIN APPLICATION
addappid(1512790)
-- Game: addappid(1512790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512791, 1, "486b5d52e8cd3ba70e660bdeb1b3fc8b8b83b719c6fb2570c4aca9224de7a244")
