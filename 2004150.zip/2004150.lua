-- Lua provided by SkyAPI 
-- Game: AppID 2004150
addappid(2004150)
addappid(2004151, 1, "386b1d061e2683de6df76146f35cab528d0d2377351afdf1ce8114730aa1ebca")
