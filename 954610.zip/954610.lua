-- Lua provided by RyzenAPI
-- Game: AppID 954610

-- MAIN APPLICATION
addappid(954610)

-- MAIN APP DEPOTS / PACKAGES
addappid(954611, 1, "c4fabfae670d48570126ac47985ee4cb90d57d625de5f6e5589f253fe7247e58")

