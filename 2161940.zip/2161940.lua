-- Lua provided by RyzenAPI
-- Game: Anime Girls Trample

-- MAIN APPLICATION
addappid(2161940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161941, 1, "5c616161562e5990e981e2d70e2586271994c2a81d7c6df5352a0185b131c6a3")

