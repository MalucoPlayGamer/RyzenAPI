-- Lua provided by RyzenAPI
-- Game: HecatoncheirStory

-- MAIN APPLICATION
addappid(916640)

-- MAIN APP DEPOTS / PACKAGES
addappid(916641, 1, "7720cd5eb2720ea819b447dfdb84d9ecea7fb11f53b4ddedf7c0b761f6a1737f")
addappid(918460, 0, "0617e542b43f75a09754d5ed5374c178f5bbd9f6e7f83587081f27e158aca838")

