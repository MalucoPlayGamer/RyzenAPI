-- Lua provided by RyzenAPI
-- Game: Swords and Sandals Pirates

-- MAIN APPLICATION
addappid(957440)

-- MAIN APP DEPOTS / PACKAGES
addappid(957441, 1, "b4d4f4483ae856cd744e461552430333cefc532bc1ccd42dd9db30e60337e1ce")

