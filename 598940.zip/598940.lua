-- Lua provided by SkyAPI 
-- Game: Doodle Mafia
addappid(598940)
addappid(598941, 1, "e406ff83039ca1030063ca3f24b694872ac04f7dc412a4e3dba20e7b780a8fe8")
addappid(598942, 1, "76dcfd6bca19d458b65eb6abb2711c4512d61e95d245ba35f08c168baeb4487f")
