-- Lua provided by RyzenAPI
-- Game: Game: AppID 1261980

-- MAIN APPLICATION
addappid(1261980)
-- Game: addappid(1261980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261981, 1, "28fb9bf1496b327c6ec5fca8afa3fb2683436c22e18d1037ce1b61110afc6f85")
