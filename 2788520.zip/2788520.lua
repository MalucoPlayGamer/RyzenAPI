-- Lua provided by SkyAPI 
-- Game: Cozy Caravan
addappid(2788520)
addappid(2788521, 1, "d1abc794622a6959ea21d5f615e3d55fc44df6fd3a5495307aa97188d9ad0f96")
