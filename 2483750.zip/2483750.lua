-- Lua provided by RyzenAPI
-- Game: Research Story Soundtrack

-- MAIN APPLICATION
addappid(2483750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483751, 1, "e4c05ff6a5c598fd10597c7f7ef972580117cb4af60cc8ac3237a77470001ebc")

