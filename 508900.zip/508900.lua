-- Lua provided by RyzenAPI
-- Game: Zup! X

-- MAIN APPLICATION
addappid(508900)

-- MAIN APP DEPOTS / PACKAGES
addappid(508901, 1, "0c5b224880abe4b39763e15d6b1c90aff9d9cbbcb37d41ec0148b8df26d340d0")

