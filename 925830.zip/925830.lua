-- Lua provided by RyzenAPI
-- Game: VR Anatomy

-- MAIN APPLICATION
addappid(925830)

-- MAIN APP DEPOTS / PACKAGES
addappid(925831, 1, "7b3802b4c3b99171696f322c19b10bc8b045c0a634ba48392bc8c734cacc83fa")

