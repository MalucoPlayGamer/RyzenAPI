-- Lua provided by SkyAPI 
-- Game: VR Anatomy
addappid(925830)
addappid(925831, 1, "7b3802b4c3b99171696f322c19b10bc8b045c0a634ba48392bc8c734cacc83fa")
