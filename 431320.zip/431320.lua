-- Lua provided by RyzenAPI 
-- Game: Recourse Demo
addappid(431320)
addappid(431321, 1, "ee61a97b3cfac209daf767c227f70a1882977302e218aa68e5b26c1164ba7395")
