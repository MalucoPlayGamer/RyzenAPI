-- Lua provided by RyzenAPI
-- Game: Game: Tropico Reloaded

-- MAIN APPLICATION
addappid(33530)
-- Game: addappid(33530)

-- MAIN APP DEPOTS / PACKAGES
addappid(33531, 1, "79dbf5973e0f7c2db109252f74d2add84f1f8fe57692a218dd77503d7ff9845a")
addappid(33532, 1, "e1b3bdc8941754979f0a133a6b8f611929513a2bfc93a3b32d207cc41aa23d18")
addappid(33533, 1, "8fa6abfea6f9bbe574c4ad4357cfb2a727075d369ce7eb86aea4bad4c02fa9fa")
