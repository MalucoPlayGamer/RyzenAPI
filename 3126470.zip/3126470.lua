-- Lua provided by SkyAPI 
-- Game: Ice World
addappid(3126470)
addappid(3126471, 1, "f5674e6a4fc06d34a8eee7891aa12473f31c101960f355de3b82e60e159c3fed")
