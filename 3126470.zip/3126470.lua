-- Lua provided by RyzenAPI
-- Game: Ice World

-- MAIN APPLICATION
addappid(3126470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3126471, 1, "f5674e6a4fc06d34a8eee7891aa12473f31c101960f355de3b82e60e159c3fed")

