-- Lua provided by RyzenAPI
-- Game: FOOTSIES Rollback Edition

-- MAIN APPLICATION
addappid(1344740)
-- Game: addappid(1344740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344741, 1, "68e8beea6a5252d177d3b0a6c10e5c7f25fbe085f8ae06e50b78b0474feb62ee")
