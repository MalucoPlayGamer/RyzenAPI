-- Lua provided by RyzenAPI
-- Game: Game: 山：临界幸存者

-- MAIN APPLICATION
addappid(1787500)
-- Game: addappid(1787500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787501, 1, "934d2fdea2ced86914a1a731f681796a0ca8d152f5d1eb35831f9ad7d64f2b44")
addappid(2419080, 0, "4d8a0c211f288e096b5082345ff3a3829da7adaccfd866016d1f458a359a2ead")
