-- Lua provided by RyzenAPI 
-- Game: Turn the Line!
addappid(1670120)
addappid(1670121, 1, "82ab42187e819596d306eef59faae2a75b4352a8ea58935a4578af276ac9dbfc")
addappid(1670122, 1, "023fea05cf1a8a981b52ad29eb4b583bd720a59c61e74d97571111a904535f03")
