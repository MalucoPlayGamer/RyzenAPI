-- Lua provided by RyzenAPI
-- Game: Swords of Gurrah

-- MAIN APPLICATION
addappid(833090)

-- MAIN APP DEPOTS / PACKAGES
addappid(833091, 1, "008e52ad3f48720f0c84b78b62e39da8c1f31d5f23d3ce9e6c7c6be3cbc68b4d")
