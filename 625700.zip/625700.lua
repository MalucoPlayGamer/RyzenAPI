-- Lua provided by RyzenAPI
-- Game: Global Soccer: A Management Game 2017

-- MAIN APPLICATION
addappid(625700)

-- MAIN APP DEPOTS / PACKAGES
addappid(625701,0,"bd7e963a584b851e79fabcc1d7b836f8c70b925e2c13bcba082ff1a7826b82b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
