-- Lua provided by RyzenAPI
-- Game: WORLD OF FINAL FANTASY®

-- MAIN APPLICATION
addappid(552700)

-- MAIN APP DEPOTS / PACKAGES
addappid(552701, 1, "0c61be69b784337efbe818582525d23c6ef18172a9dc3476709356cc378567f5")
addappid(552702, 1, "940f09f5c4c517e39d24c1c22dcaff8a0bc91b9458b3cdb78cfd0e674d709773")
addappid(597780, 1, "db5c1dcf3e4c248737287349fa9a19bcf5c925f4e0ea2bdcc34e9cf45e6cac55")
addappid(752970, 1, "673100648ec622080edd8eaa7bd6eab3e7caef6279a378442c646deb27b39f20")
addappid(896680, 0, "7b95813acc55e9672540726b555269d416d8c1db7a3aada80ad82715c7ff0b1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
