-- 464470's Lua and Manifest Created by Hubcap Manifest
-- BloodGate
-- Created: July 26, 2026 at 14:04:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(464470) -- BloodGate
-- MAIN APP DEPOTS
addappid(464471, 1, "bc974011cd6bc71fbece4b393bc3a06559922b5de5a5f3e19b1b7662451f738b") -- BloodGate Windows
setManifestid(464471, "732177904906741375", 1866872023)
addappid(464472, 1, "dd79886cc2fa8bc4fdce9206f0c28bd372fa4f58c9dd67882906811964350e6a") -- BloodGate OSX
setManifestid(464472, "7738616662193651561", 1894327455)
addappid(464473, 1, "80fcc45341938bcc427b37016490c94ff71fc9def5813cbbc1305fa981a76ead") -- BloodGate Linux
setManifestid(464473, "8373369527944142698", 1877826244)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)