-- Lua provided by RyzenAPI
-- Game: 2433100

-- MAIN APPLICATION
addappid(2433100)
-- Game: addappid(2433100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2433101, 1, "fbb81af5ea5902b173ced7dcf882b705f39c4a57847368149262018045b56eb7")
