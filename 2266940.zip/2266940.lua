-- Lua provided by RyzenAPI
-- Game: 2266940

-- MAIN APPLICATION
addappid(2266940)
-- Game: addappid(2266940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266941, 1, "6b66cfd6e663073525a37e48f5b7b1e830725b2a0b47d87df7336f371a4c2ad3")
