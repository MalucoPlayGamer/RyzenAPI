-- Lua provided by RyzenAPI
-- Game: Survival In Africa

-- MAIN APPLICATION
addappid(1502070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502071, 1, "b70f1e2543331fa202e097b35aec8661e1535db7420eb952718af2eba7549ab5")
