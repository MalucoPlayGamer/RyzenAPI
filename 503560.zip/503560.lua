-- Lua provided by RyzenAPI
-- Game: 911 Operator

-- MAIN APPLICATION
addappid(503560)
addappid(580730)
addappid(606970)

-- MAIN APP DEPOTS / PACKAGES
addappid(503561, 1, "a95779f4bbf8535d668e35bc55d3a4853a05bd3cb36bf520cbefae7f769577bc")
addappid(503562, 1, "15534f873ff89549daf55ded5d38983103075108cdf3646e361f02d098d50d64")
addappid(580731, 0, "fee91c3513a59aa5e39cee4557b7d09fe5d0263d76bbfbcb49d48dc83b5f3b02")
addappid(606971, 0, "3b0cf0bf7d79345c130f87adb6b81ec3c85d0c81672c64a86958fc41dde8c2a8")
