-- Lua provided by RyzenAPI
-- Game: Dungeon Siege III

-- MAIN APPLICATION
addappid(39160)

-- MAIN APP DEPOTS / PACKAGES
addappid(39161, 1, "ef4b2ec1809f4fb746e11ea68553eb3a2bf7d0a892ed7429de46bf74fdeb3936")
addappid(39162, 1, "6f7abee4a1cacc97ee46065dad4fcc346209f0fbfe144ff49a8feed5ed12dc6f")
addappid(39163, 1, "3ddda389c8897a83efb051257a604e7e6800ddf3b485f3ce8935d4b2458d9bae")
addappid(39164, 1, "7faec9c48d5c7c672eb59c783421e3b6a07bba59c97d91483e7893cc89f1b0f4")
addappid(39165, 1, "acb16fd469be6011bc1a3cacdf752c9af67743fe858e3910de85363821e76bf2")
addappid(39166, 1, "58ffa91ae7b6728920a5e2f1d42a2ad04c2a9df87ae311920bcc66fd9273967c")
addappid(39167, 1, "2b9e6d0ecd08149166bb9baf85afc4d394c80b0f4ad4bab8eeb806ead210df9e")
addappid(39168, 1, "4e47dcbe3fc3e7ae6bbe10d8bc8b20cd7c221cadf740498a09cbc049fead0d53")
addappid(39169, 1, "328e98d6467afd9f62ecbe177bac392a7dedd3ead5db6b6a002c6b42f899ea17")
addappid(39180, 1, "27b1f0b3417a26b9d1b6d38b12d80bdaee3bb3aa40bba1cba1281ea06bb32a25")
addappid(39181, 1, "f43b30d167ad6cae08294548d9d614b8a3af3eaeac5c7649d98b0687095ca478")
addappid(39182, 1, "e03970e745b7e2bb0dd481a43acfd8a9df499aaa3e9d7f81f3fa430bfef4cf7e")
addappid(39183, 1, "2d36be9575bcebe8c001f6622dd91b622cfcb6496064205588d105478f87fc80")
addappid(39270, 0, "ebfa2a7a9871bad37ae747fe477e3cdbe9f627e427a3a084f82fb5c0cb3e06e7")
addappid(39271, 1, "8a6d1b7e355de1a0befd3013e9d65fd0b92e9233ee8fe3dbec9df5fcc6a0e929")
addappid(39272, 1, "9acc8c315d1dd71157a4b19f0aff0fce15362e4b0a32e215676f7da8d4ac14ca")
addappid(39273, 1, "be5eff204f39467fc89bdbdb7d391cceef6ad0749bc4f15fb3a1d01e7dc99467")
addappid(39274, 1, "2a9a00ee3d6327485f558e77655a3f5f9f59f52135539f0cb5abffca8fd08428")
addappid(39275, 1, "dfcfefc1862283272007d6edffd11ad267a14ef630cc9f6fe8a224627c50f3a0")
addappid(39276, 1, "60edb9afb5c32208caa61aea51b7633cf97eb6e0eb5552036f8bd5c9b782fbf4")
addappid(39277, 1, "8beff5002ec6c38ae0eb82be05c8a087350e4536f7e7068a46e4d6901771e338")
addappid(39278, 1, "5cea2dbf0b4aa3faad4837e000bcc84695a2a412e6f3645350e5efe479305c79")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(39184)
addappid(39185)
