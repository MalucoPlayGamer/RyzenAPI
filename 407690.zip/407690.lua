-- Lua provided by RyzenAPI
-- Game: Game: AppID 407690

-- MAIN APPLICATION
addappid(407690)
-- Game: addappid(407690)

-- MAIN APP DEPOTS / PACKAGES
addappid(407691, 1, "35f51cc941298aedcc5f54f0bb958408c1b7492f4a1ef44d16f646407fe7f68e")
addappid(407692, 1, "6ef461e1b61e20f6b109c788db432c32917263bfffbe026440bf3777d3cf9b5f")
