-- Lua provided by RyzenAPI
-- Game: ENTITY: THE BLACK DAY

-- MAIN APPLICATION
addappid(2517220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517221, 1, "172154d86126f1a6c064d6901fd4f1a346dc8a781f9e3e35eb98973b29574d93")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
