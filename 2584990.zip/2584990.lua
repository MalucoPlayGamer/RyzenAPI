-- Lua provided by RyzenAPI
-- Game: Shadowverse: Worlds Beyond

-- MAIN APPLICATION
addappid(2584990)
addappid(3244010)
addappid(3483340)
addappid(3483350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

