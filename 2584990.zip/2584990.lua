-- Lua provided by RyzenAPI
-- Game: Shadowverse: Worlds Beyond

-- MAIN APPLICATION
addappid(2584990)

