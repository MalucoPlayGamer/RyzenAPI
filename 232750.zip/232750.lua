-- Lua provided by RyzenAPI
-- Game: AppID 232750

-- MAIN APPLICATION
addappid(232750)

-- MAIN APP DEPOTS / PACKAGES
addappid(232751, 1, "abfb7322f5057145cfba914c59fee0bbbf7d788ce52c36ecf48cc28afd0ef87b")
addappid(232752, 1, "c457938451d2894280161545585d136782cfc2cd3a33b15710f71c34bb319e9d")
addappid(232753, 1, "c00753b53b38cfce9c53aa5f953be1de0101dbc723bc206c265569c04ffb6fc5")
addappid(232754, 1, "85dad7366806c481cbcfd8bab6703bed558e7b1d4321e4a9d50739ab773f1426")
addappid(232755, 1, "e9de53d1f523ee0a944643734a41924f67d255a26fe48bab94f935acc65091ff")
addappid(232756, 1, "8884383dfaf4649c8b986db6c2a71a4688a7a5cfde9f0ad3c68145e843f0c3fe")
addappid(232758, 1, "64fb8ef322f684a629751023fe1ff29d1d2f044976e1d63bd0a8e0c924b42977")
addappid(232759, 1, "ce27540188e7bf9c154683a53a51b6b0f2c9fc68700a7a425c3cb92af86dee39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
