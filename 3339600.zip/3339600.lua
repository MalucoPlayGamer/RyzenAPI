-- Lua provided by RyzenAPI
-- Game: Game: HO-HOP! - Christmas Board Game

-- MAIN APPLICATION
addappid(3339600)
-- Game: addappid(3339600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339601, 1, "b2fc1c24d94180b7a3e621214e6cce4f8ba981f06005c2918f8cb19800715467")
