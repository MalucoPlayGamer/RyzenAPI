-- Lua provided by RyzenAPI
-- Game: HO-HOP! - Christmas Board Game

-- MAIN APPLICATION
addappid(3339600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3339601, 1, "b2fc1c24d94180b7a3e621214e6cce4f8ba981f06005c2918f8cb19800715467")

