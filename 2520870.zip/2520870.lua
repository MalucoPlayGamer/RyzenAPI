-- Lua provided by RyzenAPI
-- Game: Game: Love In The Dark

-- MAIN APPLICATION
addappid(2520870)
-- Game: addappid(2520870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520871, 1, "5e99a533e68149d9b8e4c822627118dfcce6fc5b819d4197f7ea4b2c23c8d514")
