-- Lua provided by SkyAPI 
-- Game: Love In The Dark
addappid(2520870)
addappid(2520871, 1, "5e99a533e68149d9b8e4c822627118dfcce6fc5b819d4197f7ea4b2c23c8d514")
