-- Lua provided by RyzenAPI
-- Game: Love In The Dark

-- MAIN APPLICATION
addappid(2520870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2520871, 1, "5e99a533e68149d9b8e4c822627118dfcce6fc5b819d4197f7ea4b2c23c8d514")

