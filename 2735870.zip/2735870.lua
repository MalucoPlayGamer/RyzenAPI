-- Lua provided by RyzenAPI
-- Game: Underminer

-- MAIN APPLICATION
addappid(2735870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735871, 1, "c2eee8e9da2baf286a5cad2beef939bfe8f512b604306be1e54a3a9efad492bb")

