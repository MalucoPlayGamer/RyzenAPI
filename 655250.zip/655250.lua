-- Lua provided by RyzenAPI
-- Game: Game: AppID 655250

-- MAIN APPLICATION
addappid(655250)
-- Game: addappid(655250)

-- MAIN APP DEPOTS / PACKAGES
addappid(655251, 1, "ebd05bc933be1ce6e13b20dc028e6ad9972ff85d46cdf1495d6bfe603e4502fe")
