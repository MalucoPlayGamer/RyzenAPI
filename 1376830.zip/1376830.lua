-- Lua provided by RyzenAPI
-- Game: Bankrupt Heroines

-- MAIN APPLICATION
addappid(1376830)
-- Game: addappid(1376830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376831, 1, "0a12f72394758451b2612d13718503144cbb06bcf1e9d9d0a4d26207c526eb17")
