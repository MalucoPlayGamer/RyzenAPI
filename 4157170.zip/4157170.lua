-- 4157170's Lua and Manifest Created by Hubcap Manifest
-- Sports Card Shop Simulator
-- Created: June 11, 2026 at 15:07:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4157170, 1, "8904bcb82acf8df0a1c5d54f4ae41f84c5b2eed76d606bd9a2bb598a2a413652") -- Sports Card Shop Simulator
-- MAIN APP DEPOTS
addappid(4157171, 1, "5ec406e77646a02992959df91498e9f28f02e692c09a44ee1d05a09906a3b62e") -- Depot 4157171
setManifestid(4157171, "4162554533632835947", 4737783500)