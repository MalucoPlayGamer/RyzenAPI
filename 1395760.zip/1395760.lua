-- Lua provided by RyzenAPI 
-- Game: Reshaping Mars
addappid(1395760)
addappid(1395761, 1, "758fdf91a59261be0e8aee59f20affd885abafa75557f366806b84fddc83760a")
