-- Lua provided by RyzenAPI
-- Game: addappid(1395760)

-- MAIN APPLICATION
addappid(1395760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395761, 1, "758fdf91a59261be0e8aee59f20affd885abafa75557f366806b84fddc83760a")
