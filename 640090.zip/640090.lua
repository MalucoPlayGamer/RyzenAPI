-- Lua provided by RyzenAPI
-- Game: Game: AppID 640090

-- MAIN APPLICATION
addappid(640090)
-- Game: addappid(640090)

-- MAIN APP DEPOTS / PACKAGES
addappid(640091, 1, "56c49c22abc1ffe94eed521c8ae2549dedb9857a3a2c4e3a03618c0219da3809")
