-- Lua provided by RyzenAPI
-- Game: FX Football - The Manager for Every Football Fan

-- MAIN APPLICATION
addappid(265400)
addappid(288780)

-- MAIN APP DEPOTS / PACKAGES
addappid(265401, 1, "e23a07f2a09a7af90b429ea749f7f3b9b7dbce73544d364b4cb03361b66a2788")
addappid(265402, 1, "e1905c1b9ddfa68d471b77eda3fd552248f9a9878dc73987ee8de76555cced08")
addappid(265403, 1, "8218041a4f45b7be3a5743b36214a4d020da9f056e5ba4a3eface9af20b185db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
