-- Lua provided by RyzenAPI
-- Game: Pixross

-- MAIN APPLICATION
addappid(1489680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489682,0,"33da99c93b14b477fb4b5acdc4665fdbcb01bcf812888e46ca6ee202f8d9a808")
addappid(1489683,0,"18a2d8848e4922f534baf50dce003cd67a855f3132ac610db97b89871811b7f9")

