-- Lua provided by RyzenAPI
-- Game: Chroma Zero Demo

-- MAIN APPLICATION
addappid(3270130)
-- Game: addappid(3270130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3270131, 1, "4c177dca2c27a814ef8bc93fba2a348b6bde21eb640899ac934cd23cb8f343ab")
