-- Lua provided by RyzenAPI
-- Game: Diorama Builder - Medieval Castle

-- MAIN APPLICATION
addappid(2668590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668590,0,"3897a841d410df91668f7966e582a0259c37ff29c9589f65f915178b3069c890")

