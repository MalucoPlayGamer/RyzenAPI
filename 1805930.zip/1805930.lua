-- Lua provided by RyzenAPI
-- Game: Game: Pumpkin Eater

-- MAIN APPLICATION
addappid(1805930)
-- Game: addappid(1805930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805931, 1, "6a5e966db50611b0174cfbf211a16371191a77c7a87cfcd9ba875a66ffc9d53a")
