-- Lua provided by RyzenAPI
-- Game: Game: Hold The Noise

-- MAIN APPLICATION
addappid(2860220)
-- Game: addappid(2860220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2860221, 1, "dcabc021583beba8a310e70da39456fd98f065bed313d3e93b449e82c5fb5d4e")
