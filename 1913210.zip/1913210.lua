-- Lua provided by RyzenAPI 
-- Game: AppID 1913210
addappid(1913210)
addappid(1913211, 1, "dafeb193d22df56bd1c00d0b7b03acdb89dcbc967b865d5018c7d7d34add1dea")
