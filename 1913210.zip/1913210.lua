-- Lua provided by RyzenAPI
-- Game: AppID 1913210

-- MAIN APPLICATION
addappid(1913210)
addappid(2154880)
addappid(2252020)
addappid(2252040)
addappid(2436720)
addappid(2436721)
addappid(2611250)
addappid(2611260)
addappid(2611270)
addappid(2611450)
addappid(2611460)
addappid(2717640)
addappid(2717650)
addappid(2717660)
addappid(2717670)
addappid(2806280)
addappid(2806290)
addappid(2806300)
addappid(2806310)
addappid(2806320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1913211, 1, "dafeb193d22df56bd1c00d0b7b03acdb89dcbc967b865d5018c7d7d34add1dea")

