-- Lua provided by RyzenAPI
-- Game: Game: Storage Hunter Simulator Demo

-- MAIN APPLICATION
addappid(3037090)
-- Game: addappid(3037090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037091, 1, "7a8243b0785be764f9a1d1da0a2b7c814a601745f667a922683da5343bdc64c2")
