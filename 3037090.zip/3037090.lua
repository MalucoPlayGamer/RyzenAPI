-- Lua provided by SkyAPI 
-- Game: Storage Hunter Simulator Demo
addappid(3037090)
addappid(3037091, 1, "7a8243b0785be764f9a1d1da0a2b7c814a601745f667a922683da5343bdc64c2")
