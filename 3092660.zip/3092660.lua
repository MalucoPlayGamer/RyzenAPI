-- Lua provided by RyzenAPI 
-- Game: Reverse: 1999
addappid(3092660)
addappid(3092661, 1, "cfb503d7b2ff2226a3deaf93976effa66a5a20be58712a6667f32ca31b0d303d")
