-- Lua provided by RyzenAPI
-- Game: 3092660

-- MAIN APPLICATION
addappid(3092660)
-- Game: addappid(3092660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092661, 1, "cfb503d7b2ff2226a3deaf93976effa66a5a20be58712a6667f32ca31b0d303d")
