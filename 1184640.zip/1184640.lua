-- Lua provided by RyzenAPI
-- Game: Hide and Secret: The Lost World

-- MAIN APPLICATION
addappid(1184640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184641, 1, "f249361fa3d6d632e37bee17d7431f10c385718e3cd9b0850b4711543602fe11")

