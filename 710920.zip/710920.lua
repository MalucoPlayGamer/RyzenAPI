-- Lua provided by RyzenAPI
-- Game: Darksiders Genesis

-- MAIN APPLICATION
addappid(710920)

-- MAIN APP DEPOTS / PACKAGES
addappid(710921, 1, "0b2f1d1915ac05d7b6e430c1fba60087cbad90ca8c93c9008df1d94255a56974")
addappid(1203440, 0, "2d0142227179b2656dbddaf685d3cfb706280ba1bb722a29f356e286b6f4c59d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
