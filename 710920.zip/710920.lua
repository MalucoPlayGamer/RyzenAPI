-- Lua provided by SkyAPI 
-- Game: Darksiders Genesis
addappid(710920)
addappid(710921, 1, "0b2f1d1915ac05d7b6e430c1fba60087cbad90ca8c93c9008df1d94255a56974")
addappid(1203440, 0, "2d0142227179b2656dbddaf685d3cfb706280ba1bb722a29f356e286b6f4c59d")
