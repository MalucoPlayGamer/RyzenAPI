-- Lua provided by RyzenAPI
-- Game: Monster Boy and the Cursed Kingdom

-- MAIN APPLICATION
addappid(449610)

-- MAIN APP DEPOTS / PACKAGES
addappid(449611, 1, "24d7750e30b9a220ce28b6f1a9844204d2b2387402eebb565b0034a39f512879")
