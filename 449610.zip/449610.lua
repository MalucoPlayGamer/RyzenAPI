-- Lua provided by RyzenAPI
-- Game: Monster Boy and the Cursed Kingdom

-- MAIN APPLICATION
addappid(449610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(449611, 1, "24d7750e30b9a220ce28b6f1a9844204d2b2387402eebb565b0034a39f512879")

