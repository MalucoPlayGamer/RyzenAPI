-- Lua provided by RyzenAPI
-- Game: 1995830

-- MAIN APPLICATION
addappid(1995830)
-- Game: addappid(1995830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995831, 1, "39f2ff08508847f06506f097ec12dba24cf5a94ad116b5617ebf1d7ee262874f")
