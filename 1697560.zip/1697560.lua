-- Lua provided by SkyAPI 
-- Game: County Hospital
addappid(1697560)
addappid(1697561, 1, "56da2add3f1347ea5286931329a9b6cdbfc109e58ac6316edd2591b0b1d6f93c")
