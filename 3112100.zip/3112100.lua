-- Lua provided by RyzenAPI
-- Game: 3112100

-- MAIN APPLICATION
addappid(3112100)
-- Game: addappid(3112100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3112101, 1, "a0e63902a03dce2751c253052aeaca5be0a4259b0e077bb3b95e53a7aeb55d57")
