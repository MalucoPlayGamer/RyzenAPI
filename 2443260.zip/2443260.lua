-- Lua provided by RyzenAPI
-- Game: Black Gunner Wukong Demo

-- MAIN APPLICATION
addappid(2443260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443261, 1, "93cd9a9720709a67194260be20dc93e0f4f14f76ee8d99d34b1f872b04b00617")

