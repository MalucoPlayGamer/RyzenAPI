-- Lua provided by RyzenAPI
-- Game: Deathtrap Dungeon

-- MAIN APPLICATION
addappid(245010)

-- MAIN APP DEPOTS / PACKAGES
addappid(245011, 1, "c950645581c5fca3b1f563caab412816cd47d0e4b157f8131f2920ecaf06732a")
