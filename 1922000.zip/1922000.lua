-- Lua provided by RyzenAPI
-- Game: addappid(1922000)

-- MAIN APPLICATION
addappid(1922000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922001, 1, "9237d12453e52dc1f5a0c57e39e9671f53a25ef124e3ad1d47e7ca8860a07473")
