-- Lua provided by RyzenAPI
-- Game: The Lodge

-- MAIN APPLICATION
addappid(1507650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1507651, 1, "c2722a02032246a49bacb5e26c49b724a81b0942acbeed484a2f60697b300f2b")

