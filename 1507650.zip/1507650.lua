-- Lua provided by RyzenAPI
-- Game: Game: The Lodge

-- MAIN APPLICATION
addappid(1507650)
-- Game: addappid(1507650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507651, 1, "c2722a02032246a49bacb5e26c49b724a81b0942acbeed484a2f60697b300f2b")
