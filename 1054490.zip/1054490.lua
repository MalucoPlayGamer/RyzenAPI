-- Lua provided by RyzenAPI
-- Game: Wingspan

-- MAIN APPLICATION
addappid(1054490)
addappid(1741470)
addappid(1816700)
addappid(1962870)
addappid(2924770)
addappid(3320750)
addappid(3362880)
addappid(4677530)
addappid(4683500)
addappid(4847570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054491,0,"347a8b113d88977a6ec7e417992bfd7cfbf382b1d9714b52aa70e230797321b0")
addappid(1054492,0,"9119cbd5d0bd0c15a1ffd03638a0c9d265e8156f2d30736abd0741a41df186bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4847610)
