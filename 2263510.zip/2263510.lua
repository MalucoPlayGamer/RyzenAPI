-- Lua provided by RyzenAPI
-- Game: The Simulacrum

-- MAIN APPLICATION
addappid(2263510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263511, 1, "18feac3d3becb2088e143b3eb67c964249e066642f29e1e224676bec790d8dbf")
