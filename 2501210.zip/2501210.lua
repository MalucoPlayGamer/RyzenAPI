-- Lua provided by RyzenAPI
-- Game: addappid(2501210)

-- MAIN APPLICATION
addappid(2501210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2501211, 1, "e00a32b2f423f2b4796055c7e2eeb795d78835a2e3f1f6231fb877b756af70e0")
