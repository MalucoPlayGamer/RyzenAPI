-- Lua provided by RyzenAPI
-- Game: Magical Girl Konoha

-- MAIN APPLICATION
addappid(2529520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529521, 1, "923f1d3c205f8dbc1eef8e6cbee1095b0be2947bc6ef19da25d2e7a7720bab6c")
addappid(2529522, 1, "3ea483ce0b2468f630399edde9043207a90bc1ed1cdb05c10c1c4adf2e4a2d69")
addappid(2529523, 1, "bd087c4d33428d6d5d53f233c147502651ed8bef4a0c894b20c99e0393013a90")

