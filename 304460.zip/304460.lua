-- Lua provided by RyzenAPI
-- Game: AppID 304460

-- MAIN APPLICATION
addappid(304460)

-- MAIN APP DEPOTS / PACKAGES
addappid(304461, 1, "5f4b43d3501ba4f5a66513edf3f22324e4123067504a0887808816efdce409d9")
addappid(304462, 1, "ac4292766dd03a1957df049179753ed848b463fe011666802a9dfdd2b94a76a8")
addappid(323290, 0, "bb64407593b98d39ead5b41642a6d98c5e734910b97cd1023b042e8274ddf884")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
