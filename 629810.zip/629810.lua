-- Lua provided by RyzenAPI
-- Game: addappid(629810)

-- MAIN APPLICATION
addappid(629810)

-- MAIN APP DEPOTS / PACKAGES
addappid(629811, 1, "eceacb323d00b188b7a9cbfd2855387763982ef2b56b3bb0ee89c46998b223be")
addappid(629812, 1, "93c7c3ed58770e81fd378fd7fd81f20c0e30771152e69df664b25f6dcd9a4692")
addappid(629813, 1, "cfd63f58ac4d561f904ec73b93f0f0fc18d0bf93d9fc68f5be668998c30dc0a6")
addappid(629814, 1, "b7e26952e2c35d9e7e0d69ed50e4dba505abbea5dfc06e1676d3b736286806af")
addappid(629815, 1, "fff67a562951a6fecbe87b00894938de6b6f9f2c96c21cd9f849ca5dda40141e")
addappid(629816, 1, "1d187de0267828f2cf1844c32ca2a7bb5ecfa6be2dada5ce65c01dbb032cb3bc")
addappid(629817, 1, "d272496d2153023589ca942e289a695aefb41a95171333aa0dcdb83d28aceac6")
