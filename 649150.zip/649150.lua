-- Lua provided by RyzenAPI 
-- Game: Phobia
addappid(649150)
addappid(649151, 1, "5f0d3b9a965c838c499ace65c54387fb96f16d12c20bdaf4c320ef687506ed2f")
