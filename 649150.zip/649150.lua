-- Lua provided by RyzenAPI
-- Game: Phobia

-- MAIN APPLICATION
addappid(649150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(649151, 1, "5f0d3b9a965c838c499ace65c54387fb96f16d12c20bdaf4c320ef687506ed2f")

