-- Lua provided by RyzenAPI
-- Game: Hentai Words

-- MAIN APPLICATION
addappid(875430)
-- Game: addappid(875430)

-- MAIN APP DEPOTS / PACKAGES
addappid(875431, 1, "4773965b5b507a4b25777fa21262543057ee11701d58dd24fcecf91f2b237b7f")
addappid(875432, 1, "c6e4e89a8f517fd02384d10caac69d1900072a1c655af2d62fc031d98719a18e")
