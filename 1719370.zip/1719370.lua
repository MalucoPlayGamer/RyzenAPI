-- Lua provided by RyzenAPI
-- Game: 极简地牢 Simple Killer Demo

-- MAIN APPLICATION
addappid(1719370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719371, 1, "77d83b6681cf5034dc241b5008f84fc9471f7f778c3971883b4dbee3667982af")

