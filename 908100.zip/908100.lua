-- Lua provided by RyzenAPI
-- Game: 九州：商旅（Nine Provinces: Caravan）

-- MAIN APPLICATION
addappid(908100)
-- Game: addappid(908100)

-- MAIN APP DEPOTS / PACKAGES
addappid(908101, 1, "177ab6dc2e5a6af89116c3054c37ef720848f89907be116c65e1e1300fcd9923")
