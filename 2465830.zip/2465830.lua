-- Lua provided by RyzenAPI
-- Game: Robin Hood - Sherwood Builders - Bandit's Trail

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(2465830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465832,0,"24882003a60370c68c0daed85a99654bc7ef226786feeaf878cb3bbd1aa52d2c")

