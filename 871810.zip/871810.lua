-- Lua provided by SkyAPI 
-- Game: AppID 871810
addappid(871810)
addappid(871811, 1, "4ef8ef0be4baebe995acc77192f3bc8efc78447817a729f6bab2b955f07f51b9")
