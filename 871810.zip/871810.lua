-- Lua provided by RyzenAPI
-- Game: AppID 871810

-- MAIN APPLICATION
addappid(871810)

-- MAIN APP DEPOTS / PACKAGES
addappid(871811, 1, "4ef8ef0be4baebe995acc77192f3bc8efc78447817a729f6bab2b955f07f51b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
