-- Lua provided by RyzenAPI
-- Game: AppID 871810

-- MAIN APPLICATION
addappid(871810)

-- MAIN APP DEPOTS / PACKAGES
addappid(871811, 1, "4ef8ef0be4baebe995acc77192f3bc8efc78447817a729f6bab2b955f07f51b9")

