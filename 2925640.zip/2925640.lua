-- Lua provided by RyzenAPI
-- Game: Game: Nuclear Sub Demo

-- MAIN APPLICATION
addappid(2925640)
-- Game: addappid(2925640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925641, 1, "11651cea8fbde2d0be292c18aa1055e62a0d158754a3f7e8ee2985cb972e805d")
