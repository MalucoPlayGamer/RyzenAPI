-- Lua provided by RyzenAPI
-- Game: Game: Left in the Dark: No One on Board

-- MAIN APPLICATION
addappid(284890)
-- Game: addappid(284890)

-- MAIN APP DEPOTS / PACKAGES
addappid(284891, 1, "6362ff2a9efbc87efb0447b6c3b7996797a679913035b5bcff872b1301763a7e")
addappid(284892, 1, "490178f33d5a7789c5a59deef114b84c5574310f8900e77fc461ac9897aee2ad")
addappid(284893, 1, "41054847256c2da5e49152a2559da20b9b99c65443488ea1b22f52a7f96277b2")
