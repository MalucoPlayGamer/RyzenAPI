-- Lua provided by RyzenAPI
-- Game: You've been banished.

-- MAIN APPLICATION
addappid(2098120)
addappid(2394360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098121, 1, "0b8f03ce2dcaf6850c4ae580aa4fc71b01af523e7411377f167c4a271778a943")

