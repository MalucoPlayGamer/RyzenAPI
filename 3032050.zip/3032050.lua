-- Lua provided by RyzenAPI
-- Game: Erogoddess: Olympus - Digital Artbook

-- MAIN APPLICATION
addappid(3032050)
-- Game: addappid(3032050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032050,0,"65242595a8971c61d3e2d42010a54434675a7bba9b0a2c6dca37e3511e3e45be")
