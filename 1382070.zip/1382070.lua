-- Lua provided by RyzenAPI
-- Game: Viewfinder

-- MAIN APPLICATION
addappid(1382070) -- Viewfinder

-- MAIN APP DEPOTS / PACKAGES
addappid(1382073, 1, "91db9b94243c9fa25520ef73ded5d2c2cc4345c27b38f36f4d110545dcaaa4d5") -- Depot 1382073
