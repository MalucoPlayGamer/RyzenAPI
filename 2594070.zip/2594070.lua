-- Lua provided by RyzenAPI
-- Game: Beat Saber - Linkin Park - Lost

-- MAIN APPLICATION
addappid(2594070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594070,0,"6edbda3ad8916ce00ab78e8872cbfb8aa72f74f773dce326d1fa2f071a7cf042")

