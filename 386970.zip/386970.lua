-- Lua provided by RyzenAPI
-- Game: Memory's Dogma CODE:01

-- MAIN APPLICATION
addappid(386970)
addappid(570800)
addappid(570801)
addappid(4050730)
addappid(4050740)
addappid(4050750)
addappid(4050760)
addappid(4050770)

-- MAIN APP DEPOTS / PACKAGES
addappid(386971, 1, "b523111ef0f3e7fa899d73896357e7be7ea630ba7ed7484384362b964ba4055c")

