-- Lua provided by RyzenAPI
-- Game: addappid(386970)

-- MAIN APPLICATION
addappid(386970)
addappid(570800)
addappid(570801)

-- MAIN APP DEPOTS / PACKAGES
addappid(386971, 1, "b523111ef0f3e7fa899d73896357e7be7ea630ba7ed7484384362b964ba4055c")
