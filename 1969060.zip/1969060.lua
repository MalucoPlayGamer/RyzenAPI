-- Lua provided by RyzenAPI
-- Game: 1969060

-- MAIN APPLICATION
addappid(1969060)
-- Game: addappid(1969060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969061, 1, "a4ce751221b376120ed86d9d9ceea01aab38793cd516052c48d334d1b7d6d537")
