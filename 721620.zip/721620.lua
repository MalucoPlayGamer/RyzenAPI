-- Lua provided by RyzenAPI
-- Game: 721620

-- MAIN APPLICATION
addappid(721620)
-- Game: addappid(721620)

-- MAIN APP DEPOTS / PACKAGES
addappid(721620,0,"09dd0a1b8cb425be2a9cc5d79cbe578c05a5f9f088641c9a66d85b5b7a4a5c13")
