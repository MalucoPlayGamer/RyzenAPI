-- Lua provided by SkyAPI 
-- Game: AppID 3265530
addappid(3265530)
addappid(3265531, 1, "ca8f59a626a96e78e89242ec81ebf5e0b9ca45f576129f8f59779e194128c575")
