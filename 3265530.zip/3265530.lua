-- Lua provided by RyzenAPI
-- Game: NTR Sexy girl with Cold-hearded

-- MAIN APPLICATION
addappid(3265530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265531, 1, "ca8f59a626a96e78e89242ec81ebf5e0b9ca45f576129f8f59779e194128c575")

