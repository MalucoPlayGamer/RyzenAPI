-- Lua provided by RyzenAPI
-- Game: AppID 2727650

-- MAIN APPLICATION
addappid(2727650)
-- Game: addappid(2727650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727651, 1, "38b9b13f02f1364f6559e2e54c1ed8bf72c0022dba9dc433df0a351779500a28")
