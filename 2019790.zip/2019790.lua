-- Lua provided by RyzenAPI
-- Game: Liftoff® - Slipstream

-- MAIN APPLICATION
addappid(2019790)
-- Game: addappid(2019790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019791, 1, "1051ab2c812f27beb32e2ce9fd5a4db6422576fcdb6f349dee1e9c0861356af1")
addappid(2019792, 1, "daa8f7e42649a06883c48ea3d1d15be0638a0bad59eb26fc3defa624219e54ae")
addappid(2019793, 1, "f8f340d15cb05436b21faf323b9d4190eab5673bae1d404decd1c388368f004a")
