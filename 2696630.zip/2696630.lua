-- Lua provided by RyzenAPI
-- Game: 2696630

-- MAIN APPLICATION
addappid(2696630)
-- Game: addappid(2696630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696631, 1, "4ffce8bc14cf5dcbce4501361e1eef7358b6cb8bb58d3212d6ef4da2879fcc11")
