-- Lua provided by RyzenAPI
-- Game: AppID 248650

-- MAIN APPLICATION
addappid(248650)

-- MAIN APP DEPOTS / PACKAGES
addappid(248651, 1, "a27e8c60f327e05d6be677727a85b6285ce322287657c0dd6d1e36d69e37f382")
addappid(435570, 0, "ae04dd4efc6f8ccb1abe74380c41f2be45e8d82bbc147da8bb317ca1d7049c08")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
