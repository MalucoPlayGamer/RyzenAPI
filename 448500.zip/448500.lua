-- Lua provided by RyzenAPI
-- Game: AppID 448500

-- MAIN APPLICATION
addappid(448500)
addappid(460440)

-- MAIN APP DEPOTS / PACKAGES
addappid(448501, 1, "01dc2cf74607201e87ee2a9cb1073fde3dbccf93cb9acd9d9930f6445ff5c2cc")

