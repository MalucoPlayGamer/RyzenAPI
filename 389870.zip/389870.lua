-- Lua provided by RyzenAPI
-- Game: Mugen Souls

-- MAIN APPLICATION
addappid(389870)
addappid(403450)
addappid(403451)
addappid(403452)
addappid(403453)
addappid(403454)
addappid(403455)
addappid(403456)
addappid(403457)

-- MAIN APP DEPOTS / PACKAGES
addappid(389871, 1, "65127c1a59ac68b8c03e9f672972ae421cd148447780db0c3669444ed939985c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
