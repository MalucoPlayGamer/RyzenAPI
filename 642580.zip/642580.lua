-- Lua provided by RyzenAPI
-- Game: AppID 642580

-- MAIN APPLICATION
addappid(642580)
addappid(762090)
-- Game: addappid(642580)

-- MAIN APP DEPOTS / PACKAGES
addappid(642581, 1, "e36d6bc9280b2607a8068588fa16b7d191344c710e7f95d8ad34eb5142b2ef52")
