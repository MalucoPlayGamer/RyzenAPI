-- Lua provided by RyzenAPI
-- Game: BACKROOMS LIMINAL ESCAPE

-- MAIN APPLICATION
addappid(3657530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3657531, 1, "82b57d6bca95c3ddc7767ebd156fa32a1123b619cf6039e0b84188468d266493")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
