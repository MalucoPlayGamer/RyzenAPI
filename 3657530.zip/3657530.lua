-- Lua provided by RyzenAPI
-- Game: addappid(3657530)

-- MAIN APPLICATION
addappid(3657530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3657531, 1, "82b57d6bca95c3ddc7767ebd156fa32a1123b619cf6039e0b84188468d266493")
