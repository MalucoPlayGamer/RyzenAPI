-- Lua provided by RyzenAPI
-- Game: 내 여동생과 친구의 여동생을 교환해 보았다

-- MAIN APPLICATION
addappid(2527700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527701, 1, "6c92eb2dd32e85cd5685c568ef9bbba6916b221739f4b2c5b980d1531e689552")

