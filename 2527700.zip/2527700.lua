-- Lua provided by RyzenAPI
-- Game: 2527700

-- MAIN APPLICATION
addappid(2527700)
-- Game: addappid(2527700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527701, 1, "6c92eb2dd32e85cd5685c568ef9bbba6916b221739f4b2c5b980d1531e689552")
