-- Lua provided by SkyAPI 
-- Game: Medieval Trader Simulator
addappid(1777670)
addappid(1777671, 1, "beb1dc4b751465e7751a45c8f18657a10f9efb4ab21b4f11cae41eea2e338575")
