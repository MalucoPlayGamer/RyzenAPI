-- Lua provided by RyzenAPI
-- Game: Game: Remnants of a Beautiful Day

-- MAIN APPLICATION
addappid(466830)
-- Game: addappid(466830)

-- MAIN APP DEPOTS / PACKAGES
addappid(466831, 1, "d36097871b4598f07778767d1f6eebbb911258b71b66cb6c4404d7f29dc441a7")
