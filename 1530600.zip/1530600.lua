-- Lua provided by RyzenAPI 
-- Game: AppID 1530600
addappid(1530600)
addappid(1530601, 1, "312a5dfb676d11eb30cc1e48e294d42de0e1a0088038e1cc2a582d8eac0bc01b")
