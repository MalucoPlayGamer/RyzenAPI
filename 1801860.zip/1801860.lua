-- Lua provided by RyzenAPI 
-- Game: WOLF RIOT
addappid(1801860)
addappid(1801861, 1, "5ce26cdc295aa86168813ba6d14548ea1f62cb90dacb713f95a68ca2661a0486")
