-- Lua provided by RyzenAPI
-- Game: Game: WOLF RIOT

-- MAIN APPLICATION
addappid(1801860)
-- Game: addappid(1801860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801861, 1, "5ce26cdc295aa86168813ba6d14548ea1f62cb90dacb713f95a68ca2661a0486")
