-- Lua provided by RyzenAPI
-- Game: Monster Hunter: World Original Soundtrack

-- MAIN APPLICATION
addappid(912540)

-- MAIN APP DEPOTS / PACKAGES
addappid(912541, 1, "a2cc9c4397c1aba71953063b342b2638b301f795798475a721e0a5a6a1364433")
addappid(912542, 1, "76df1f76ea37dc51a168f5a67bd7c40065400547a8718e720e95ea62c31b74ad")
addappid(912543, 1, "6df3b3c4def3325e47ce14e517a6c73f67fe4ffb21de65aff6f86436ed6fcf04")
addappid(912544, 1, "e4bffdaf951a478e6d7dedb9debb6df4c15f5fc1eb192ea202cfd62429302784")
addappid(912545, 1, "10ea07ab2bb68959b90c669ef9095ae987df86ec1a52c2c5288bbf53c65e8211")
addappid(912546, 1, "9ec2135cac5b243039cb39f5f870348f507caba7abc5f5f4fe4526cadefd0fc3")
