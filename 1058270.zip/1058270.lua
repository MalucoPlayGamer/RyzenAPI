-- Lua provided by RyzenAPI
-- Game: Game: AppID 1058270

-- MAIN APPLICATION
addappid(1058270)
-- Game: addappid(1058270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058271, 1, "42708362915e26ad4bd08e6b7a009f8e3a1b12c46dae354c832b34da01443865")
