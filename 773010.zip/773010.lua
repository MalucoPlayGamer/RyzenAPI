-- Lua provided by RyzenAPI 
-- Game: Hunahpu Quest. Mechanoid
addappid(773010)
addappid(773011, 1, "8ea649325bf2636b5653e8b2631b86ced496148e5ed381d644efd15442102b85")
