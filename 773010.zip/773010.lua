-- Lua provided by RyzenAPI
-- Game: Hunahpu Quest. Mechanoid

-- MAIN APPLICATION
addappid(773010)
-- Game: addappid(773010)

-- MAIN APP DEPOTS / PACKAGES
addappid(773011, 1, "8ea649325bf2636b5653e8b2631b86ced496148e5ed381d644efd15442102b85")
