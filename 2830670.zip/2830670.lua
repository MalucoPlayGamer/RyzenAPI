-- Lua provided by RyzenAPI
-- Game: addappid(2830670)

-- MAIN APPLICATION
addappid(2830670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830671, 1, "a4eabdfc142caa988c3491692bf17d614b33e112788ef24cf7f941bed08e23dc")
