-- Lua provided by RyzenAPI 
-- Game: Fabulous Field Trip
addappid(2316880)
addappid(2316881, 1, "05515d5c94d1bfcf6a6bd7874e148bba2c2de79b4fd4549fce1c4b9baca8b34b")
