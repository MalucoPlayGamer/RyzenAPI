-- Lua provided by RyzenAPI
-- Game: Fabulous Field Trip

-- MAIN APPLICATION
addappid(2316880)
-- Game: addappid(2316880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316881, 1, "05515d5c94d1bfcf6a6bd7874e148bba2c2de79b4fd4549fce1c4b9baca8b34b")
