-- Lua provided by RyzenAPI
-- Game: Work And Girls

-- MAIN APPLICATION
addappid(1315860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315861, 1, "66a7931e206b8cab7532a7f53796e34c592f62be2ce0645a8a11e7119acffd6a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1335650)
