-- Lua provided by SkyAPI 
-- Game: Work And Girls
addappid(1315860)
addappid(1315861, 1, "66a7931e206b8cab7532a7f53796e34c592f62be2ce0645a8a11e7119acffd6a")
