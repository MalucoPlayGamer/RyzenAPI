-- Lua provided by RyzenAPI
-- Game: Your Majesty

-- MAIN APPLICATION
addappid(2699740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699741, 1, "8e0838597b2775a37e246b54985b8cda38876ef6abb900ecc69d35c48a4f8934")

