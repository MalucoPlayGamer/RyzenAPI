-- Lua provided by SkyAPI 
-- Game: Your Majesty
addappid(2699740)
addappid(2699741, 1, "8e0838597b2775a37e246b54985b8cda38876ef6abb900ecc69d35c48a4f8934")
