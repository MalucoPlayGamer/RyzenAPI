-- Lua provided by RyzenAPI 
-- Game: コモラ・リアルワールドエスケープ
addappid(1350820)
addappid(1350821, 1, "1fb7c0af18ec5c2f40b1b5a55600155da09638e98c63efa4012f24809e810abd")
