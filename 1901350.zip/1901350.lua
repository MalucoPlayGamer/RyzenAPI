-- Lua provided by RyzenAPI
-- Game: 武动苍穹

-- MAIN APPLICATION
addappid(1901350)
-- Game: addappid(1901350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901352,0,"09c85186529de951dd6d846cab618f4591e7f5f69b983873885672aa015c37df")
