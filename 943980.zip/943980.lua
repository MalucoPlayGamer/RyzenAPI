-- Lua provided by RyzenAPI
-- Game: addappid(943980)

-- MAIN APPLICATION
addappid(943980)

-- MAIN APP DEPOTS / PACKAGES
addappid(943981, 1, "b944b60395f08d499214daac445a820e431be475d02e7ac0de28daba8401c4da")
addappid(943982, 1, "687f5b417a8e194863aa87fec240fc7d7f0bc7b9906fccfea98c7962caa9c533")
addappid(961590, 0, "aa402817b887fdd00119311ce856a857c3ccad956654bfde2f7dc00e9b3a5670")
