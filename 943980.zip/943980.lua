-- Lua provided by RyzenAPI
-- Game: The logic of the miniature garden

-- MAIN APPLICATION
addappid(943980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(943981, 1, "b944b60395f08d499214daac445a820e431be475d02e7ac0de28daba8401c4da")
addappid(943982, 1, "687f5b417a8e194863aa87fec240fc7d7f0bc7b9906fccfea98c7962caa9c533")
addappid(961590, 0, "aa402817b887fdd00119311ce856a857c3ccad956654bfde2f7dc00e9b3a5670")

