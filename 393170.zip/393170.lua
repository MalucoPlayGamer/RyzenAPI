-- Lua provided by RyzenAPI
-- Game: Game: Bit Shifter

-- MAIN APPLICATION
addappid(393170)
addappid(415580)
-- Game: addappid(393170)

-- MAIN APP DEPOTS / PACKAGES
addappid(393171, 1, "22b9da83394bd2113cbea71cee45970f7136e3a47842e2db5a2630e458c2f105")
addappid(393172, 1, "1268c14dcef5cf3073ece24fdf92c6695ff48f5fd58e87255afc4befc15d2734")
addappid(393173, 1, "ecc4e93a30deb69580928ab881c5c923722b03ff188d29327dff30a7d23ad047")
