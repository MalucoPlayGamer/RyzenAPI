-- Lua provided by RyzenAPI
-- Game: Game: Metrophobia Demo

-- MAIN APPLICATION
addappid(3279510)
-- Game: addappid(3279510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279511, 1, "c2eeccef133abd255db712c337503be459a6d76db257c810d87ca08cb7f92514")
