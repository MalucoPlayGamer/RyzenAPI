-- Lua provided by RyzenAPI
-- Game: Ragdolls Playground: The Sandbox

-- MAIN APPLICATION
addappid(1812950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812955,0,"0c84ccdf1f4b74a2e1b5c0e8501d8b4d56dd1a25eef2aad96aabdff81634620a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
