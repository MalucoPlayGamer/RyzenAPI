-- Lua provided by RyzenAPI
-- Game: 1812950

-- MAIN APPLICATION
addappid(1812950)
-- Game: addappid(1812950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812955,0,"0c84ccdf1f4b74a2e1b5c0e8501d8b4d56dd1a25eef2aad96aabdff81634620a")
