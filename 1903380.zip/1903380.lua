-- Lua provided by RyzenAPI
-- Game: Game: AppID 1903380

-- MAIN APPLICATION
addappid(1903380)
-- Game: addappid(1903380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903381, 1, "424051aba8aaf903f0de15208488391504145d12d6b86abc2dee5afbd467cb76")
