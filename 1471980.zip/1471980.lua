-- Lua provided by RyzenAPI
-- Game: AppID 1471980

-- MAIN APPLICATION
addappid(1471980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471981, 1, "92b4af804d2e87a3d050e032801ac041f1f53deb62c7de6ba2f5a4d153a764db")

