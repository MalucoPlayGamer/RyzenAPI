-- Lua provided by RyzenAPI
-- Game: 100 hidden snails

-- MAIN APPLICATION
addappid(1446330)
-- Game: addappid(1446330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446331, 1, "0f73532b6c7343d321ea2baf6aaeed33f6fd0f9d7b4cebaa2096b7950a0dd890")
