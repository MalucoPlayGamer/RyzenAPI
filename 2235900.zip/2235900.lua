-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Another World Heroine Generator 3 for MZ

-- MAIN APPLICATION
addappid(2235900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235900,0,"de7b3cdf2eec73bdd62a563411d404ca2ce64ec2c48f813566686ac6474803b7")

