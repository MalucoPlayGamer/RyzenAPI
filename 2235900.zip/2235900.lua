-- Lua provided by RyzenAPI
-- Game: 2235900

-- MAIN APPLICATION
addappid(2235900)
-- Game: addappid(2235900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235900,0,"de7b3cdf2eec73bdd62a563411d404ca2ce64ec2c48f813566686ac6474803b7")
