-- Lua provided by RyzenAPI
-- Game: Mad Experiments: Escape Room 2

-- MAIN APPLICATION
addappid(1816930)
addappid(2142740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816931, 1, "93ca31b0ccbb10ae9ebe485d6fb2c60b80e6c1f40fb8dfd8b92f6a248b398666")
