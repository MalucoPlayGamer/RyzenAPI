-- Lua provided by RyzenAPI
-- Game: Game: 2310 seconds in HELL

-- MAIN APPLICATION
addappid(1814980)
-- Game: addappid(1814980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814981, 1, "220b6cedb9fef0519dd38f994f74f950baf32caccedd79422a9d8d69a9139062")
addappid(1814982, 1, "21e0c5ff232ef06959cb80a13027c6a266ccc6a4c1d5c16d880f825afc2b615a")
addappid(1814983, 1, "c054015c69f5eb66ace0eeaffc101df9dddc84c752c1885b23f7e9dc305e59bb")
