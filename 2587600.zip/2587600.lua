-- Lua provided by RyzenAPI
-- Game: Talents Demo

-- MAIN APPLICATION
addappid(2587600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587601, 1, "c633914accc1ebb0c84cb23287e10391fa250a6dc3b6b97cb3354073182bf15b")

