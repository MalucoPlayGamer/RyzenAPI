-- Lua provided by RyzenAPI
-- Game: Project: Mirror

-- MAIN APPLICATION
addappid(2171840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171841, 1, "38e16c2482c22da86a113f79022473163f69f45373d172e13dd22508ffac6cbe")
