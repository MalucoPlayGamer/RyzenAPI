-- Lua provided by RyzenAPI
-- Game: 功德木鱼

-- MAIN APPLICATION
addappid(2609320)
-- Game: addappid(2609320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2609321, 1, "4d9d9273878137b7f22b8aaee7b85787a809e0a7b7ba9b5a2ee3cd0e9830cc31")
