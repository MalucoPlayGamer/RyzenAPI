-- Lua provided by RyzenAPI
-- Game: The Last Yandere: Cursed Dark

-- MAIN APPLICATION
addappid(1660570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660571, 1, "7584ab005d84085e438daabdf387dc51838aae2bef66b89ce5043bc01a293e21")
