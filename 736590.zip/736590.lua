-- Lua provided by RyzenAPI
-- Game: Game: AppID 736590

-- MAIN APPLICATION
addappid(736590)
-- Game: addappid(736590)

-- MAIN APP DEPOTS / PACKAGES
addappid(736591, 1, "d824bdacf3a6af9ddc2d2074f44ca51e60066c2f0586a1d054e3589d7996adb3")
