-- Lua provided by RyzenAPI
-- Game: Operation: Harsh Doorstop

-- MAIN APPLICATION
addappid(736590)
addappid(1517200)
addappid(1517201)
addappid(1517202)
addappid(1517203)
addappid(2605190)
addappid(3213620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(736591, 1, "d824bdacf3a6af9ddc2d2074f44ca51e60066c2f0586a1d054e3589d7996adb3")
