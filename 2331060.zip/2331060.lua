-- Lua provided by SkyAPI 
-- Game: Gambit Shifter
addappid(2331060)
addappid(2331061, 1, "a3eefe4e42f6d3dcf52afaf45c6470dcd2dd2dcab45056c4956f893efad2f5b5")
