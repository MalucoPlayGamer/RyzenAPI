-- Lua provided by RyzenAPI
-- Game: Gambit Shifter

-- MAIN APPLICATION
addappid(2331060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331061, 1, "a3eefe4e42f6d3dcf52afaf45c6470dcd2dd2dcab45056c4956f893efad2f5b5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2936270)
