-- Lua provided by RyzenAPI
-- Game: Game: AppID 794690

-- MAIN APPLICATION
addappid(794690)
-- Game: addappid(794690)

-- MAIN APP DEPOTS / PACKAGES
addappid(794691, 1, "aee0c2545727b92609e10c4768d2414bf841e83bf0ba81de6417f006ff7a80b0")
