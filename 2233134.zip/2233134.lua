-- Lua provided by RyzenAPI
-- Game: Beat Saber - The White Stripes - "Seven Nation Army"

-- MAIN APPLICATION
addappid(2233134)
-- Game: addappid(2233134)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233134,0,"5db837b7887af7975a6f9d826e66cd23ddbedb3e6c106e645661adb4cd19f818")
