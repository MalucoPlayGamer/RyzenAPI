-- Lua provided by RyzenAPI
-- Game: Blood Field | Cỏ Máu

-- MAIN APPLICATION
addappid(1673000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673001, 1, "b3384a6a6ed53e4b613cf703386c5a278a2401733e0c4ddf7835b6758348022b")
