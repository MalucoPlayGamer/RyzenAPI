-- Lua provided by RyzenAPI
-- Game: Torchlight: Infinite

-- MAIN APPLICATION
addappid(1974050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1974051, 1, "3690b94ae7c28ed65557579848f21a68b4162cad7643f7af179e64761bea02ed")

