-- Lua provided by RyzenAPI
-- Game: 1047040

-- MAIN APPLICATION
addappid(1047040)
addappid(1047041)
addappid(1047042)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047040,0,"f51a6d7d1b27352ce61350cedebaa25df5bca3b0f6a3f2fdd1d665941dd5ffc9")
addtoken(1047040,6040030866190519494)
