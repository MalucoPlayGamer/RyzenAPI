-- Lua provided by RyzenAPI
-- Game: addappid(507390)

-- MAIN APPLICATION
addappid(507390)

-- MAIN APP DEPOTS / PACKAGES
addappid(507391, 1, "6fbe2ee3fbaf6f28a450c1e7b03589639d2deff4e5f8de1d569907d7a3a40a9e")
addappid(511240, 0, "680d045efc43a47df291f835f0580878371b1491ed0a61dcb4f967118964f8b9")
