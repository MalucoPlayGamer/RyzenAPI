-- Lua provided by RyzenAPI
-- Game: AppID 839820

-- MAIN APPLICATION
addappid(839820)
addappid(867630)

-- MAIN APP DEPOTS / PACKAGES
addappid(839821, 1, "aa86b16eadcd63b53ed4e1533f6b38a629e79b7c7411047cfc8bcc6daf36650e")

