-- Lua provided by RyzenAPI
-- Game: Divide

-- MAIN APPLICATION
addappid(687270)

-- MAIN APP DEPOTS / PACKAGES
addappid(687271,0,"0a147177a8831b427095f63494cf02222c75d3adfbfa1e3839a7a84db1a5c233")

