-- Lua provided by RyzenAPI
-- Game: Boyfriend's Rescue -  Gay Platform Game

-- MAIN APPLICATION
addappid(1280640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280645,0,"fbb8d282084b9d7774747f8c08d5589333206a9162f2872b09e816c64088306e")
addappid(1327896,0,"b635b2c948fc0b5803b680455039b6d0180d2587019d05879dee87c0516f0f05")
addappid(1327897,0,"2c9d65de961148e5b8c6bda0ab62a5e5c722dd26061c79dcf8bac8d62c99822e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1327890)
addappid(1327891)
