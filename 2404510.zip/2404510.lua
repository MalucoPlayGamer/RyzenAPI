-- Lua provided by RyzenAPI
-- Game: Game: Lucky Hero

-- MAIN APPLICATION
addappid(2404510)
-- Game: addappid(2404510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404511, 1, "a880041e6b77f54aff1226a70c7c8cb744bc68e971252a99ba249f3894a039e6")
