-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2133190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133190,0,"9f392c626ebacf0ec8e8c2cb45ef6cf9b834def9872ad1fd648af426da4d30cd")

