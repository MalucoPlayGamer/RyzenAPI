-- Lua provided by RyzenAPI
-- Game: Game: Be My Girlfriends

-- MAIN APPLICATION
addappid(1631210)
-- Game: addappid(1631210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631211, 1, "18765b795dbecdf7c96b68f8c62fc28a6bdcea9c64eeabc83ce5d2ae0cfa835f")
addappid(1935200, 0, "d61e1bc066dacf7b4f4d5449fda8aaba18a11c5f8268410f9abf5e8ef5021502")
