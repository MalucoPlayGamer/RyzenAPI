-- Lua provided by RyzenAPI
-- Game: Party Hard Remastered OST

-- MAIN APPLICATION
addappid(554790)

-- MAIN APP DEPOTS / PACKAGES
addappid(554792,0,"86bd3d0819c545fff8c36b42923a9ee12a75e7fd76fc68602c4d57971fd4d5cf")
