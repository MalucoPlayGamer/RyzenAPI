-- Lua provided by RyzenAPI
-- Game: addappid(2091250)

-- MAIN APPLICATION
addappid(2091250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091251, 1, "070bc5bd81c704e395c3725b9c0f5f10f29e61e7d532bfc15d27db5af226046c")
