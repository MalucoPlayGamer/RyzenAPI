-- Lua provided by RyzenAPI
-- Game: Koishi Navigation Desktop Youkai

-- MAIN APPLICATION
addappid(2091250)
addappid(2180320)
addappid(3617260)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2091251, 1, "070bc5bd81c704e395c3725b9c0f5f10f29e61e7d532bfc15d27db5af226046c")

