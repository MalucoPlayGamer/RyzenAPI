-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1952430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952430,0,"2043bc5052db81584345e74a02e935207d0e63f4f10a4e53ad9ae18bf9d2d719")
