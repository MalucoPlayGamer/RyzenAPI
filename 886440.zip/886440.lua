-- Lua provided by RyzenAPI
-- Game: Super Versus Server

-- MAIN APPLICATION
addappid(886440)

-- MAIN APP DEPOTS / PACKAGES
addappid(886441, 1, "0d015ac444ae1fd7136af346367b24a65cec57de9fa709b4129fcf7ee5173a87")
addappid(886443, 1, "ce0e1f5e6e226e5795811ad4343e2e8c04a00428c8341196442cf11af86f51ee")

