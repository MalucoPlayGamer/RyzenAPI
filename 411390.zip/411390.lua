-- Lua provided by RyzenAPI
-- Game: 411390

-- MAIN APPLICATION
addappid(411390)
-- Game: addappid(411390)

-- MAIN APP DEPOTS / PACKAGES
addappid(411391, 1, "3e6909688e8681d6528a7b849f524180e9e30e8490c5af490fd7e9f00acd8902")
