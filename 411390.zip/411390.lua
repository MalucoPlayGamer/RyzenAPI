-- Lua provided by RyzenAPI
-- Game: Getsuei Gakuen -kou-

-- MAIN APPLICATION
addappid(411390)

-- MAIN APP DEPOTS / PACKAGES
addappid(411391, 1, "3e6909688e8681d6528a7b849f524180e9e30e8490c5af490fd7e9f00acd8902")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
