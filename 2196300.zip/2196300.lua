-- Lua provided by RyzenAPI
-- Game: 2196300

-- MAIN APPLICATION
addappid(2196300)
-- Game: addappid(2196300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196301, 1, "ec064d10a433dbf5501caf5837ae9027aba170ab6f77e89510d1c3e5b8b9d6ac")
