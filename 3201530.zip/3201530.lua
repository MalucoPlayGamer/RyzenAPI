-- Lua provided by RyzenAPI 
-- Game: 巴哈姆特1-REMAKE(BAHAMUT1-REMAKE)
addappid(3201530)
addappid(3201531, 1, "1c4cc15a9a68c5537fd1664584221c97218cbeb6e6de332e78230c22bfe48564")
addappid(3201532, 1, "0c21277054bb723c6770cf1cf9f04ac0ec79b9d23e9d8d3e8f31b41e163a7a53")
addappid(3499120)
