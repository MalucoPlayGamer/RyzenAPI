-- Lua provided by RyzenAPI
-- Game: Game: LIFE EFFECT (Retired Version)

-- MAIN APPLICATION
addappid(2191050)
-- Game: addappid(2191050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191051, 1, "a5531f89d3d387199451384d45aa610e759ba522e8e9916328245e3d75a2f39c")
