-- Lua provided by RyzenAPI
-- Game: LIFE EFFECT (Retired Version)

-- MAIN APPLICATION
addappid(2191050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191051, 1, "a5531f89d3d387199451384d45aa610e759ba522e8e9916328245e3d75a2f39c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
