-- Lua provided by RyzenAPI 
-- Game: Hunt and Fight
addappid(2882830)
addappid(2882831, 1, "c1b7da29d7742345f3f15e7c9481fc4a24f5e2ecf1c5f490d5a5f9e34ca4c247")
