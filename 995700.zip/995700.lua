-- Lua provided by RyzenAPI
-- Game: 995700

-- MAIN APPLICATION
addappid(995700)
-- Game: addappid(995700)

-- MAIN APP DEPOTS / PACKAGES
addappid(995701, 1, "e467edad3674622b431aea67538050a61a4edebd09e870d1d857a3ba4763d0c1")
