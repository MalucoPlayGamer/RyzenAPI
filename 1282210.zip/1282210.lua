-- Lua provided by RyzenAPI
-- Game: DEEMO -Reborn-

-- MAIN APPLICATION
addappid(1282210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282211, 1, "87b70e59bb345b1a37c8e83083cf172190b287e0e03c1e8da21ffba9d11514d1")
addappid(1282212, 1, "846bdee8e19907273928653d7d236e876b0cc55cf3a6e4833e5b3e30a8bcafd2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1299090)
addappid(1307540)
addappid(1333390)
addappid(1459820)
addappid(1460620)
