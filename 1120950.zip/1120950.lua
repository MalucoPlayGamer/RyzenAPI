-- Lua provided by RyzenAPI
-- Game: Chameleon Run Deluxe Edition

-- MAIN APPLICATION
addappid(1120950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120951, 1, "333325ee4606f730f1a8cec7a28dbf88e6ee918786c37b4fdcdc27cedfba0520")
