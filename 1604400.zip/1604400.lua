-- Lua provided by RyzenAPI
-- Game: Out Bike the Tsunami™

-- MAIN APPLICATION
addappid(1604400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604401, 1, "5e5262fecc2e159dbedacfecb86f31275f32fe9a8591106a0680e9fc33dd2535")
