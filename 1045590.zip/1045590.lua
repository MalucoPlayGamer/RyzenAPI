-- Lua provided by RyzenAPI
-- Game: Game: AppID 1045590

-- MAIN APPLICATION
addappid(1045590)
-- Game: addappid(1045590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045591, 1, "7fd3d2b9f8b34ddc5fa35dc98377b8ba4076d170415c5308b8b49b3e72300169")
