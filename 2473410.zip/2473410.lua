-- Lua provided by RyzenAPI
-- Game: Deckbane

-- MAIN APPLICATION
addappid(2473410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2473412,0,"88b36a01fa352ac325f3d50580daf206a65793f8cfcbc977b1d60137825ae763")

