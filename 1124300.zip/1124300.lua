-- Lua provided by RyzenAPI
-- Game: HUMANKIND™

-- MAIN APPLICATION
addappid(1124300)
addappid(1633650)
addappid(1633651)
addappid(1704220)
addappid(1819400)
addappid(1819410)
addappid(1833990)
addappid(1838710)
addappid(2320210)
addappid(2320211)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1124300,0,"4d092aea0cdc3bc272cb80eb0511617bc474b5cdafcebae2408b700eadf9ce84")
addappid(1124301,0,"31824a528b21cc0a39767df59e54f348eea747f224c7df02c059dceeb02d744a")
addappid(1124302,0,"a69d865390db19a0c3c7a5a141b33fbbb1b732aff23e1b9cc0f5b7bc706aa623")
addappid(1124303,0,"5193634fe68221a87011d503d6041e6f94ecd34252547c4e9a7bd2dfd3d9cdc7")

