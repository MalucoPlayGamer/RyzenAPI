-- Lua provided by RyzenAPI
-- Game: 1124300

-- MAIN APPLICATION
addappid(1124300)
addappid(1633651)
addappid(1704220)
addappid(1819400)
addappid(1819410)
addappid(1833990)
addappid(1838710)
addappid(2320210)
addappid(2320211)
-- Game: addappid(1124300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124301, 1, "31824a528b21cc0a39767df59e54f348eea747f224c7df02c059dceeb02d744a")
addappid(1124302, 1, "a69d865390db19a0c3c7a5a141b33fbbb1b732aff23e1b9cc0f5b7bc706aa623")
addappid(1124303, 1, "5193634fe68221a87011d503d6041e6f94ecd34252547c4e9a7bd2dfd3d9cdc7")
