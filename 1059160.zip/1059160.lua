-- Lua provided by RyzenAPI
-- Game: 1059160

-- MAIN APPLICATION
addappid(1059160)
-- Game: addappid(1059160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059161, 1, "ca146e433ca4ad903713a0b1eea244c9fcf1866f1f2b8dd20205f90dd3d1df8a")
