-- Lua provided by RyzenAPI
-- Game: AppID 1067540

-- MAIN APPLICATION
addappid(1067540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067541, 1, "e347e083c86a9572f0e8d2221c2382d2821488a4359c841371f26839e9c32103")
addappid(1067542, 1, "b1ea89da87ef88ae5869d6b6f0a8819f556a88248db30ff43230bece5de1bfb7")
addappid(1067543, 1, "c9397af1ff2ccc0d8cf586e6c47b67b13915986ddb3f53c49748f4e64ba5d13f")
addappid(1402610, 0, "886c1d4da026da531c5933d5b0c387f1c88d591577eb23bcf2d00705cf5a6617")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1402620)
