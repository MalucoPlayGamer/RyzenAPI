-- Lua provided by RyzenAPI
-- Game: addappid(718220)

-- MAIN APPLICATION
addappid(718220)

-- MAIN APP DEPOTS / PACKAGES
addappid(718221, 1, "d166eca4e3cbdd5e296d64a45ef7d810bcc408c3b01612ea252d969239178713")
