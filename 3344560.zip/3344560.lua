-- Lua provided by RyzenAPI
-- Game: World Drawn

-- MAIN APPLICATION
addappid(3344560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3344561, 1, "7750acffa3ce1084229d4ba37099eda4f748daaa120b0c6622a4880edcf82024")
