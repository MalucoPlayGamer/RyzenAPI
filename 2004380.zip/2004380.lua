-- Lua provided by RyzenAPI
-- Game: addappid(2004380)

-- MAIN APPLICATION
addappid(2004380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004381, 1, "2ae6438eeb02f27f63754dcb9083240ddf097702a10d72e888fd2b0d636b9efc")
