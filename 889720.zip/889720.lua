-- Lua provided by RyzenAPI
-- Game: 889720

-- MAIN APPLICATION
addappid(889720)
-- Game: addappid(889720)

-- MAIN APP DEPOTS / PACKAGES
addappid(889721, 1, "4e7d80651405a754f6b29f46c0fa6b4b7a6ceef2d102ec3dc252c2c1cae7c5f2")
addappid(889722, 1, "5c90bc226480a30fbd47d58f15d6b0452bfc8ae4177ee34277dd7266a67a74ad")
addappid(889723, 1, "b46f35a7b84b32a76b67cbee108329aae2c5712264c1cff83fa814d231bd9389")
