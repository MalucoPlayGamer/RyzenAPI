-- Lua provided by RyzenAPI
-- Game: Game: Cat Bait: Demo

-- MAIN APPLICATION
addappid(3129690)
-- Game: addappid(3129690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3129691, 1, "78488f62e863fc48ef96287407312d4595ef99a344a1d11a4e3142555c2233c2")
