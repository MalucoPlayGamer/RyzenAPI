-- Lua provided by RyzenAPI 
-- Game: Cat Bait: Demo
addappid(3129690)
addappid(3129691, 1, "78488f62e863fc48ef96287407312d4595ef99a344a1d11a4e3142555c2233c2")
