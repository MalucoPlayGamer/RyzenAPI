-- Lua provided by RyzenAPI
-- Game: Zagu Espionage

-- MAIN APPLICATION
addappid(1643490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643491, 1, "4fe1016c8d53280e4695e792ef064a090488be34c12c962d7604a146a08c4b06")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
