-- Lua provided by RyzenAPI
-- Game: Zagu Espionage

-- MAIN APPLICATION
addappid(1643490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643491, 1, "4fe1016c8d53280e4695e792ef064a090488be34c12c962d7604a146a08c4b06")
