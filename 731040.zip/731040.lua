-- Lua provided by RyzenAPI
-- Game: The Invincible

-- MAIN APPLICATION
addappid(731040)

-- MAIN APP DEPOTS / PACKAGES
addappid(731041, 1, "82179143c4f409cdc0851cf2530e75f827cc5ce893e9eb95859146139ecf7f01")
addappid(2622920, 0, "14917a90d1ac4fc46a4819fac3edaa31e63643f67fa7e33af624d7893a36e89a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
