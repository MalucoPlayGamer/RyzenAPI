-- Lua provided by SkyAPI 
-- Game: The Invincible
addappid(731040)
addappid(731041, 1, "82179143c4f409cdc0851cf2530e75f827cc5ce893e9eb95859146139ecf7f01")
addappid(2622920, 0, "14917a90d1ac4fc46a4819fac3edaa31e63643f67fa7e33af624d7893a36e89a")
