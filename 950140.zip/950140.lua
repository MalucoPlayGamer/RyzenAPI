-- Lua provided by RyzenAPI
-- Game: Game: Hiding Spot

-- MAIN APPLICATION
addappid(950140)
-- Game: addappid(950140)

-- MAIN APP DEPOTS / PACKAGES
addappid(950141, 1, "e83370b29321b5f727137c4a45ce8a3e975a944a21d0b62d3ce781896a040c40")
