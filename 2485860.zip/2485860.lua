-- Lua provided by RyzenAPI 
-- Game: AppID 2485860
addappid(2485860)
addappid(2485861, 1, "66b12e9f1260ad7cd3176fc37b1a2446c8a41cb94f29fbdbb857818df9151d53")
