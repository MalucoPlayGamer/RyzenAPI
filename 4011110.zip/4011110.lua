-- Lua provided by RyzenAPI
-- Game: Pirate Ships

-- MAIN APPLICATION
addappid(4011110)

