-- Lua provided by RyzenAPI
-- Game: addappid(2550760)

-- MAIN APPLICATION
addappid(2550760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550761, 1, "f35a25b61622fee90ff9a5610d6b3bf107660aeb6673693f7260ac3afcfb7599")
