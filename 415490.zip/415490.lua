-- Lua provided by RyzenAPI
-- Game: AppID 415490

-- MAIN APPLICATION
addappid(415490)
addappid(463990)

-- MAIN APP DEPOTS / PACKAGES
addappid(415491, 1, "2df0e72e888bdad959770694b925b6ed99031ff153b3ca63fad3bbb06f16a55e")
