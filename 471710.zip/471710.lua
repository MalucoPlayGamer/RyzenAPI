-- Lua provided by RyzenAPI
-- Game: Rec Room

-- MAIN APPLICATION
addappid(471710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(471711, 1, "34f5ec907095edfc605a68bb1ed56d6df884b1932fcbe7d2b26b91222384775e")

