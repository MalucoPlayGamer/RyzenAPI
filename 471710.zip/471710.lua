-- Lua provided by RyzenAPI
-- Game: 471710

-- MAIN APPLICATION
addappid(471710)
-- Game: addappid(471710)

-- MAIN APP DEPOTS / PACKAGES
addappid(471711, 1, "34f5ec907095edfc605a68bb1ed56d6df884b1932fcbe7d2b26b91222384775e")
