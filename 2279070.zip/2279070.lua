-- Lua provided by RyzenAPI
-- Game: Riot Operator Demo

-- MAIN APPLICATION
addappid(2279070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279071, 1, "45bf7965f01a4f66cfa397b03d667c70725a4f433f176b17c76d435007dbd4c8")

