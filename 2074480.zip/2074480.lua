-- Lua provided by SkyAPI 
-- Game: Sunset Routes
addappid(2074480)
addappid(2074481, 1, "cefe87ec5db887549741aeecc7c5f8240240c325f2cf90864c5d3f20bb729a2f")
