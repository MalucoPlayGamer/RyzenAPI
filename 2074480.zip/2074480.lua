-- Lua provided by RyzenAPI
-- Game: addappid(2074480)

-- MAIN APPLICATION
addappid(2074480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074481, 1, "cefe87ec5db887549741aeecc7c5f8240240c325f2cf90864c5d3f20bb729a2f")
