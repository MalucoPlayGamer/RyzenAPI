-- Lua provided by RyzenAPI
-- Game: Architect Simulator

-- MAIN APPLICATION
addappid(2977070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2977071, 1, "a46d19ec372a5ce4ff4dc1fc781e0c3150ec0ab4025eb8c05d9a3f4a486b4cc9")
