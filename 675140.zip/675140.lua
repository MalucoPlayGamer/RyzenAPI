-- Lua provided by RyzenAPI
-- Game: Laika 2.0 - Sekret Pravda

-- MAIN APPLICATION
addappid(675140)
addappid(1400580)
-- Game: addappid(675140)

-- MAIN APP DEPOTS / PACKAGES
addappid(675141, 1, "238ea7b7e7d49591d5fb91beaab8bb7767a5d6c2920c0afe9195a0878e17bae0")
