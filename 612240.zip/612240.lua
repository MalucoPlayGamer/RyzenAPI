-- Lua provided by RyzenAPI
-- Game: 612240

-- MAIN APPLICATION
addappid(612240)
-- Game: addappid(612240)

-- MAIN APP DEPOTS / PACKAGES
addappid(612241, 1, "3e4ead2901de716c4d0b52eed3534d1e948329d21d5cc1c7d8230748c39a5a2a")
