-- Lua provided by RyzenAPI
-- Game: Cellfish

-- MAIN APPLICATION
addappid(2814280)
-- Game: addappid(2814280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814281, 1, "a9bce63f0feea3563669a621d2d0eaf899afda9e647805313e64e1deba758dcc")
