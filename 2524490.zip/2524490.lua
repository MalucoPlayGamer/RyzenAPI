-- Lua provided by RyzenAPI
-- Game: addappid(2524490)

-- MAIN APPLICATION
addappid(2524490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524491, 1, "926b1592ee3b3fe09c72f2ce08f762a03789349a9473cb7fb0d3d6db0fda195e")
