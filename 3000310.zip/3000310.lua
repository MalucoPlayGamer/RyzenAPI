-- Lua provided by RyzenAPI
-- Game: 3000310

-- MAIN APPLICATION
addappid(3000310)
-- Game: addappid(3000310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3000311, 1, "7a967ded598b767a80e704eb7cc937b0ba9f9bf17aafe82e8fb230e402001f01")
