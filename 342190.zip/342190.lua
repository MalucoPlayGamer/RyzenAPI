-- Lua provided by RyzenAPI
-- Game: Skyworld

-- MAIN APPLICATION
addappid(342190)
addappid(734500)

-- MAIN APP DEPOTS / PACKAGES
addappid(342191, 1, "037ffacc8204745dd6fe8909c77fe221b8fc03f29d1ccdba63f431f551ba5c44")

