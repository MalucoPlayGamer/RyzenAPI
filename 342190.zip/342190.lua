-- Lua provided by RyzenAPI
-- Game: Skyworld

-- MAIN APPLICATION
addappid(342190)
addappid(734500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(342191, 1, "037ffacc8204745dd6fe8909c77fe221b8fc03f29d1ccdba63f431f551ba5c44")

