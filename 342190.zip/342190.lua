-- Lua provided by SkyAPI 
-- Game: Skyworld
addappid(342190)
addappid(342191, 1, "037ffacc8204745dd6fe8909c77fe221b8fc03f29d1ccdba63f431f551ba5c44")
addappid(734500)
