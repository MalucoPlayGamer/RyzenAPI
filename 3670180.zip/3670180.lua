-- 3670180's Lua and Manifest Created by Hubcap Manifest
-- Baby Kings
-- Created: August 14, 2026 at 00:44:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3670180) -- Baby Kings
-- MAIN APP DEPOTS
addappid(3670181, 1, "d0039526f5b8fee4809690becf9a1488a5f6021b2e083295e3877595388146af") -- Depot 3670181
setManifestid(3670181, "1026781144670810481", 1971330314)
addappid(3670182, 1, "a2ba0a47dd851dff1059a4f2adf13683db62fe97215869643ca92aba70926264") -- Depot 3670182
setManifestid(3670182, "6969923275418948333", 1988764760)
addappid(3670183, 1, "36506163a953eaf9bc2cd46ed300bee4b6f97f5ba763aa6d0993ae27896ae08f") -- Depot 3670183
setManifestid(3670183, "6942771688901158636", 2014713687)