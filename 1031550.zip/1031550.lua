-- Lua provided by RyzenAPI
-- Game: Lovers ' Smiles 2

-- MAIN APPLICATION
addappid(1031550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031551, 1, "edb550c5267ac433b33ea28819cb1cb88b3b79680f3bbe7c4e37385151bce6ee")
