-- Lua provided by RyzenAPI
-- Game: 1646350

-- MAIN APPLICATION
addappid(1646350)
addappid(2100000)
addappid(2106630)
-- Game: addappid(1646350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646351, 1, "7a9a396503355e3335e8ab1c587106b9492ef64187421c413b3c2aa43544bdd5")
