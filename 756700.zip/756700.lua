-- Lua provided by RyzenAPI
-- Game: Neon Seoul: Outrun

-- MAIN APPLICATION
addappid(756700)

-- MAIN APP DEPOTS / PACKAGES
addappid(756701, 1, "80e49adf58a05a80a0dd8f0a9d5d47e7ea3e84b1c8888f0312803a5b2ac53cca")

