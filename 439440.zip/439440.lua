-- Lua provided by RyzenAPI
-- Game: Game: Of Carrots And Blood

-- MAIN APPLICATION
addappid(439440)
-- Game: addappid(439440)

-- MAIN APP DEPOTS / PACKAGES
addappid(439441, 1, "443298336c8cda23aad5143c7dd0b6633c4828b92b39c66e8001a51ef4382a87")
