-- Lua provided by SkyAPI 
-- Game: Of Carrots And Blood
addappid(439440)
addappid(439441, 1, "443298336c8cda23aad5143c7dd0b6633c4828b92b39c66e8001a51ef4382a87")
