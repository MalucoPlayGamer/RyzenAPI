-- Lua provided by SkyAPI 
-- Game: Sneak In: a sphere matcher game
addappid(1061550)
addappid(1061551, 1, "f61e3d4520c5950ff64262f2b892d044a546d6ec49f16540d615e12304da304b")
addappid(1061554, 1, "742e35e67a737b834e8ef2aee507c1d97691e4aea84a5c0909c6c07889a70512")
