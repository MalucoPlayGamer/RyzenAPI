-- Lua provided by RyzenAPI
-- Game: FUSER™ - Mase - "Feels So Good"

-- MAIN APPLICATION
addappid(1432177)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432177,0,"d4973656d0b22a6278e18001052de961cb917d034d54cf6e188ca552333b7e43")
