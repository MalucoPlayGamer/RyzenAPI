-- Lua provided by RyzenAPI
-- Game: Game: Misericorde Volume Two: White Wool & Snow

-- MAIN APPLICATION
addappid(3035990)
-- Game: addappid(3035990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035991, 1, "8e696fb9ce036481817ea1999984a164d2a750b0d63520a0097cca9d0c8381e1")
