-- Lua provided by RyzenAPI
-- Game: StudyX - Save Game Codes & Study Any Subject

-- MAIN APPLICATION
addappid(714030)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(714031, 1, "1d8d59c7b56ca6cb7298baa30d62ff2f51afd36a0afdf8f7af7b92d1ce9464eb")

