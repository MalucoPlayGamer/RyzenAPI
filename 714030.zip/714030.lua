-- Lua provided by RyzenAPI 
-- Game: StudyX - Save Game Codes & Study Any Subject
addappid(714030)
addappid(714031, 1, "1d8d59c7b56ca6cb7298baa30d62ff2f51afd36a0afdf8f7af7b92d1ce9464eb")
