-- Lua provided by RyzenAPI
-- Game: 714030

-- MAIN APPLICATION
addappid(714030)
-- Game: addappid(714030)

-- MAIN APP DEPOTS / PACKAGES
addappid(714031, 1, "1d8d59c7b56ca6cb7298baa30d62ff2f51afd36a0afdf8f7af7b92d1ce9464eb")
