-- Lua provided by RyzenAPI
-- Game: 892395

-- MAIN APPLICATION
addappid(892395)
-- Game: addappid(892395)

-- MAIN APP DEPOTS / PACKAGES
addappid(892395,0,"94212f4d82e1fd418fc5d300898edf2bfb92ed3da9325cb7673da0a4968c354d")
