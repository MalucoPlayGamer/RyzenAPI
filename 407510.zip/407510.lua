-- Lua provided by RyzenAPI
-- Game: 407510

-- MAIN APPLICATION
addappid(407510)
addappid(407511)
addappid(407512)

-- MAIN APP DEPOTS / PACKAGES
addappid(845241,0,"9cbac5fd5355370c3b656df7c5b596aa9bb794cb3cfc2bdc56e9581580a102f2")

