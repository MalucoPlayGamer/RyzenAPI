-- Lua provided by RyzenAPI
-- Game: Devilian

-- MAIN APPLICATION
addappid(407510)
addappid(407511)
addappid(407512)

-- MAIN APP DEPOTS / PACKAGES
addappid(845241,0,"9cbac5fd5355370c3b656df7c5b596aa9bb794cb3cfc2bdc56e9581580a102f2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(418900)
addappid(425980)
addappid(425981)
addappid(425982)
addappid(426810)
addappid(441780)
addappid(441781)
addappid(441782)
addappid(498220)
addappid(498221)
addappid(498222)
addappid(498223)
addappid(542610)
addappid(542611)
addappid(542612)
addappid(545260)
addappid(642160)
