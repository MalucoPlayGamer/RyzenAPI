-- Lua provided by RyzenAPI
-- Game: Iron Decree

-- MAIN APPLICATION
addappid(3216790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216791, 1, "991cd54b9e3362781d12b18d71e9f8b7f87a67dbc0b3314256b0f0a2931eb5a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
