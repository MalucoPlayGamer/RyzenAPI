-- Lua provided by RyzenAPI
-- Game: Cosplay Fever!!

-- MAIN APPLICATION
addappid(2185730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185731, 1, "291ff514b52bff899ffa8d070a93ab72766d3553731bd418bd4cfdf705c23140")

