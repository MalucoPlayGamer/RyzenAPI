-- Lua provided by SkyAPI 
-- Game: The Mahjong Huntress
addappid(474910)
addappid(474911, 1, "0cb2793e1d8bc46918720ac01833dccca40962ba5e0bd075bca6ae322cd4587e")
addappid(474912, 1, "30dfb70646111efe778c4c20e4586b2a33e2fdccb8ea0c5b3a6ecd530bb8ccc4")
addappid(474913, 1, "27cedb631b51255929926a8d13049ea50babbf53ced5b8ddebe1b6a077c6abcb")
