-- Lua provided by SkyAPI 
-- Game: AppID 447890
addappid(447890)
addappid(447891, 1, "a1dc78f109bb77039a2de787699f78db9d6920af81b149373ab1c40a585390d0")
