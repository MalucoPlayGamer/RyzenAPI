-- Lua provided by RyzenAPI
-- Game: addappid(447890)

-- MAIN APPLICATION
addappid(447890)

-- MAIN APP DEPOTS / PACKAGES
addappid(447891, 1, "a1dc78f109bb77039a2de787699f78db9d6920af81b149373ab1c40a585390d0")
