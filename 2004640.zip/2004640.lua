-- Lua provided by SkyAPI 
-- Game: Svarog's Dream
addappid(2004640)
addappid(2004641, 1, "0cbfa48fad8c957ca5430a95eced5102d9f5d397bffc7a6f1a59657b440c3c42")
addappid(2982030)
