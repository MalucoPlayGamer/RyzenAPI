-- Lua provided by SkyAPI 
-- Game: AppID 2248630
addappid(2248630)
addappid(2248631, 1, "dab1aa81d81bc2c7ce2ab34c723aa7be69f25a4d2872a4b8c8d6fc4ebc83e76b")
