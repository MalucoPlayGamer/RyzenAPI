-- Lua provided by RyzenAPI
-- Game: Game: Bioysque

-- MAIN APPLICATION
addappid(2384020)
-- Game: addappid(2384020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384021, 1, "d452dc67ccec0a957a44b98966346acd96bfee7516f59566ff5b483b17910374")
