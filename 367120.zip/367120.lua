-- Lua provided by RyzenAPI
-- Game: 367120

-- MAIN APPLICATION
addappid(367120)
-- Game: addappid(367120)

-- MAIN APP DEPOTS / PACKAGES
addappid(367121, 1, "e1682983a98bbc2e75f551c087535b3f916f491fea1e047f03800a6b39678ae0")
