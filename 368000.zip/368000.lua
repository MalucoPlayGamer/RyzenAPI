-- Lua provided by RyzenAPI
-- Game: 100ft Robot Golf

-- MAIN APPLICATION
addappid(368000)

-- MAIN APP DEPOTS / PACKAGES
addappid(368001, 1, "cf729ca7b1db71e740f48e37edcf65b178726ae4ba368add72373aac94e5eedd")