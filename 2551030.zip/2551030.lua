-- Lua provided by RyzenAPI
-- Game: The Balls

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2551030)
-- Game: addappid(2551030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551032,0,"b086e5facc67906aed8bb52539d4f5dbf264ace9596c3e4208ec2a25029a7f83")
