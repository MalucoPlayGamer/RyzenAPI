-- Lua provided by RyzenAPI
-- Game: Individual Investor Tycoon

-- MAIN APPLICATION
addappid(796460)

-- MAIN APP DEPOTS / PACKAGES
addappid(796462,0,"36e688f5d1994bf853f524a21c5476ae06d3872b4b12a4bd630dfedebdbd1c13")
