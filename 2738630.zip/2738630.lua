-- Lua provided by RyzenAPI
-- Game: AppID 2738630

-- MAIN APPLICATION
addappid(2738630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738631, 1, "e5b933ee1484218c14744f2cd290d7f9be7a1b76b6f12f82b2164c566c7e95e7")
addappid(2738632, 1, "887ad38cf68594a0dd601c040e05aab634071f3d006e7d60022e3fa871ca3110")
addappid(2738633, 1, "f6e4dfa86dd91eeec9b72b52dd017c93130ec9a1bb3c76d79bf792dd88b1eaa5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
