-- Lua provided by RyzenAPI
-- Game: 阴桃花 (The Flowers of Yin)

-- MAIN APPLICATION
addappid(2116000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116001, 1, "d119204c2f50cadb39401ff8e374236758a0de15800bbdf4eab916767422f081")

