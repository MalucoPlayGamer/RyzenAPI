-- Lua provided by RyzenAPI
-- Game: 阴桃花 (The Flowers of Yin)

-- MAIN APPLICATION
addappid(2116000)
addappid(2190830)
addappid(3048600)
addappid(3057800)
addappid(3102150)
addappid(3356470)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(2116001, 1, "d119204c2f50cadb39401ff8e374236758a0de15800bbdf4eab916767422f081")

