-- Lua provided by RyzenAPI
-- Game: Game: Space Empires III

-- MAIN APPLICATION
addappid(1430200)
-- Game: addappid(1430200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430201, 1, "dbeb794fd91961f4b589c78c91533acff3337ec4ebf0f113b22636b9794d3bf9")
