-- Lua provided by RyzenAPI
-- Game: addappid(933556)

-- MAIN APPLICATION
addappid(933556)

-- MAIN APP DEPOTS / PACKAGES
addappid(933556,0,"dca8c862bcf9fcfa1f4540e16f8ede638681cb2eaa9ae66810727762605d7797")
