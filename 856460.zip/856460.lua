-- Lua provided by RyzenAPI
-- Game: addappid(856460)

-- MAIN APPLICATION
addappid(856460)

-- MAIN APP DEPOTS / PACKAGES
addappid(856461, 1, "2470f07c3423047cfc3fe16bdd2a1dc829c14dbf2670b92ec75cdf3f4432b98b")
