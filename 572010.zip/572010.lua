-- Lua provided by RyzenAPI
-- Game: addappid(572010)

-- MAIN APPLICATION
addappid(572010)

-- MAIN APP DEPOTS / PACKAGES
addappid(572011, 1, "38b4a9f767f3b076c8a619a1359c0773d384fa8784b09824ec99496a7a56ae2e")
