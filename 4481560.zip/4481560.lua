-- Lua provided by RyzenAPI
-- Game: CORGI & WOOLLY - Little Horizon -

-- MAIN APPLICATION
addappid(4481560)
