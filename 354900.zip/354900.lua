-- Lua provided by RyzenAPI
-- Game: Headcrab Frenzy!

-- MAIN APPLICATION
addappid(354900)
-- Game: addappid(354900)

-- MAIN APP DEPOTS / PACKAGES
addappid(354901, 1, "a9dcb830744442106cc2c147d58c7a696584886e5d2ae29d63473a049e11b69d")
addappid(354902, 1, "b17a91b2e8212ced4db5b39f8d4145c1356a6a068e51cad25465e7f40aff9bd5")
addappid(354903, 1, "25592aba4b1feb50815ebd353b45fa4a97c965fa1aad80d99d416bb13472a1dc")
