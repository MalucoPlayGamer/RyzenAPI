-- Lua provided by SkyAPI 
-- Game: Three Kingdoms Zhao Yun
addappid(2201710)
addappid(2201711, 1, "7eb486f61d982d82e0005758c194897205c1ae6fae2d4563cfb4b0e6fa1f6163")
addappid(2541420)
addappid(2708550)
addappid(2780830, 0, "3e647fcc837c11a11f603de9ba432b0188cd530ba21777a952ab49cef8b63986")
