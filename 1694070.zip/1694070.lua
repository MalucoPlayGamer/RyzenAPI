-- Lua provided by RyzenAPI
-- Game: Game: GLASS-Frina Ciel 18+ Adult Only

-- MAIN APPLICATION
addappid(1694070)
-- Game: addappid(1694070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694071, 1, "ab6aabee374df5d9479267c2f8a5fa206862f3db51bbe10fb0262204bb5ad59d")
addappid(1694072, 1, "835880017360474d947330061fb2ff51caf166fe0ec67a408731d57edf87de3c")
