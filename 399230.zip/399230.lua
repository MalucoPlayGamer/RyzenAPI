-- Lua provided by RyzenAPI
-- Game: 399230

-- MAIN APPLICATION
addappid(399230)
-- Game: addappid(399230)

-- MAIN APP DEPOTS / PACKAGES
addappid(399231, 1, "a804b763cd3fa45c68b6f017d5f4d34570262378ddad7ba36742c31f156bf73a")
