-- Lua provided by RyzenAPI
-- Game: AppID 399230

-- MAIN APPLICATION
addappid(399230)

-- MAIN APP DEPOTS / PACKAGES
addappid(399231, 1, "a804b763cd3fa45c68b6f017d5f4d34570262378ddad7ba36742c31f156bf73a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
