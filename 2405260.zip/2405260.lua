-- Lua provided by RyzenAPI
-- Game: Strip'Em III Demo

-- MAIN APPLICATION
addappid(2405260)
-- Game: addappid(2405260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405261, 1, "315938aa1f819786a9d7ebaff81fdda21e65940003aa91fe0e7c671a9b299834")
