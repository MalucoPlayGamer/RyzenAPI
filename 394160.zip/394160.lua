-- Lua provided by RyzenAPI
-- Game: AppID 394160

-- MAIN APPLICATION
addappid(394160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(394161, 1, "ea0003096fe445305ea99b789d968df2fe1bdb1702443ed7e0fd58cfb525f948")

