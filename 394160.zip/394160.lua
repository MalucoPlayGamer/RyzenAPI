-- Lua provided by RyzenAPI
-- Game: AppID 394160

-- MAIN APPLICATION
addappid(394160)
-- Game: addappid(394160)

-- MAIN APP DEPOTS / PACKAGES
addappid(394161, 1, "ea0003096fe445305ea99b789d968df2fe1bdb1702443ed7e0fd58cfb525f948")
