-- Lua provided by RyzenAPI
-- Game: Colosso Crystal Skulls

-- MAIN APPLICATION
addappid(840840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(840841,0,"f0b9bb6c5d6683016921383da5ceaec6c49700b892b8494c86d3cdf8a14cbfe7")

