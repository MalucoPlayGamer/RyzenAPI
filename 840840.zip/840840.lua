-- Lua provided by RyzenAPI
-- Game: Colosso Crystal Skulls

-- MAIN APPLICATION
addappid(840840)

-- MAIN APP DEPOTS / PACKAGES
addappid(840841,0,"f0b9bb6c5d6683016921383da5ceaec6c49700b892b8494c86d3cdf8a14cbfe7")

