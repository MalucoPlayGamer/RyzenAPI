-- Lua provided by RyzenAPI
-- Game: Shire Scopes

-- MAIN APPLICATION
addappid(2477440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477441, 1, "e200bb744d7e1aec625854590619a0614402216b04502f6fe1ccb6bb202196f8")

