-- Lua provided by RyzenAPI
-- Game: addappid(1977960)

-- MAIN APPLICATION
addappid(1977960)
addappid(1984900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977961, 1, "df1d45ccc7696fc41397de4059e8d6ffee669ce1b211e83d66f04c1fac789249")
