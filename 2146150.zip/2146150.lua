-- Lua provided by RyzenAPI
-- Game: AppID 2146150

-- MAIN APPLICATION
addappid(2146150)
-- Game: addappid(2146150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146151, 1, "c69707839a038bffbc7cc7a5213785333562cc3045a41a8bcf3a32f61e773de2")
