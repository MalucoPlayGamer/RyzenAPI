-- Lua provided by SkyAPI 
-- Game: AppID 2146150
addappid(2146150)
addappid(2146151, 1, "c69707839a038bffbc7cc7a5213785333562cc3045a41a8bcf3a32f61e773de2")
