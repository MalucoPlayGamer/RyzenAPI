-- Lua provided by RyzenAPI
-- Game: AppID 1178130

-- MAIN APPLICATION
addappid(1178130)
-- Game: addappid(1178130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178131, 1, "b72bdd87d99c3674bda30ff0be99a04cfc270f1d19f17690a8972152deb893b3")
