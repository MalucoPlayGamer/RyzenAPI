-- Lua provided by RyzenAPI
-- Game: Game: 手办模特

-- MAIN APPLICATION
addappid(3371330)
-- Game: addappid(3371330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3371331, 1, "8928a4535a92e7a8bcd91fefbd994941f67066f72e662756f72f944357973c6e")
