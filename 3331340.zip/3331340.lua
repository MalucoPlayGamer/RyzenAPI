-- Lua provided by RyzenAPI 
-- Game: Falling for Yaoguais Demo
addappid(3331340)
addappid(3331341, 1, "5a2cffc3c30c2315c41caf5e7d922fd70add7cbaa925185ba898523d5b0aff11")
