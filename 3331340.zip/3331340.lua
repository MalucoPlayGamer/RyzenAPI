-- Lua provided by RyzenAPI
-- Game: Falling for Yaoguais Demo

-- MAIN APPLICATION
addappid(3331340)
-- Game: addappid(3331340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331341, 1, "5a2cffc3c30c2315c41caf5e7d922fd70add7cbaa925185ba898523d5b0aff11")
