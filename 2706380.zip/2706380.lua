-- Lua provided by RyzenAPI
-- Game: Cat at Home Demo

-- MAIN APPLICATION
addappid(2706380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706381, 1, "ee7a0071071c066f109e23c42faa85086e4eaef8568fa7e811f5974e82cae957")
