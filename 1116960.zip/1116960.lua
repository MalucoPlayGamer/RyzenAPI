-- Lua provided by SkyAPI 
-- Game: AppID 1116960
addappid(1116960)
addappid(1116961, 1, "f9504493c08a80d87c7bc369ad43238c6b047c7eb55a802b44c200cfebc256f9")
