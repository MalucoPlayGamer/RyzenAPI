-- Lua provided by RyzenAPI
-- Game: Builderment

-- MAIN APPLICATION
addappid(2414110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2414112,0,"24c35fb69a20736d8da6b8e9dcb00ba0b8e5825d67c5694b5cb46b4c6f34f65b")
addappid(2414113,0,"fd7f142416da58d76fdba7b4ca5aa7c13479213a3f8683914bc2e9f948849ca0")

