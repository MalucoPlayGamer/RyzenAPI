-- Lua provided by RyzenAPI
-- Game: Builderment

-- MAIN APPLICATION
addappid(2414110)
-- Game: addappid(2414110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2414112,0,"24c35fb69a20736d8da6b8e9dcb00ba0b8e5825d67c5694b5cb46b4c6f34f65b")
addappid(2414113,0,"fd7f142416da58d76fdba7b4ca5aa7c13479213a3f8683914bc2e9f948849ca0")
