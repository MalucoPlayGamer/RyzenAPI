-- Lua provided by RyzenAPI
-- Game: The Untitled Tower

-- MAIN APPLICATION
addappid(3567030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3567031, 1, "fe23f5f2428f6c4306d20a144e3b28617224ea6332b3e1534546431b679766e4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3612310)
