-- Lua provided by RyzenAPI
-- Game: 1 to 1 humanoid edible toys

-- MAIN APPLICATION
addappid(2976720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976721, 1, "4411262ea2ebacc16990d35aa9ebded7a5d36abeb4be5f77add4a9b325696cd6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
