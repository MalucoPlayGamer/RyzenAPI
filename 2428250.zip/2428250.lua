-- Lua provided by RyzenAPI 
-- Game: AppID 2428250
addappid(2428250)
addappid(2428251, 1, "2d2efbeb0cc799a6b26f9b55a27268822b3e27abf9c1f9d36e072549c2b792ec")
