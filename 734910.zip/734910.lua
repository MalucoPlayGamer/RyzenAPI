-- Lua provided by RyzenAPI
-- Game: Eternal Hour: Golden Hour

-- MAIN APPLICATION
addappid(734910)
-- Game: addappid(734910)

-- MAIN APP DEPOTS / PACKAGES
addappid(734912,0,"ab2126681862b48550b66988090785ee927217a1dc39874708957fa7e543971c")
