-- Lua provided by RyzenAPI
-- Game: Cat Needs

-- MAIN APPLICATION
addappid(2341050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341052,0,"01a1353544598d7c76877a83b7c1ba25ecdd222657c154c337dad3b7eb1c24c9")
