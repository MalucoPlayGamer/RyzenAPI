-- Lua provided by RyzenAPI
-- Game: 973390

-- MAIN APPLICATION
addappid(973390)
-- Game: addappid(973390)

-- MAIN APP DEPOTS / PACKAGES
addappid(973391, 1, "a9e626a5144065b51005aa120ba54ed8eb8149ad1720ea35bcfbeac0e2db893e")
