-- Lua provided by RyzenAPI 
-- Game: AppID 1786010
addappid(1786010)
addappid(1786011, 1, "a4aa0eb4c6f041fe94f24f894cde973661bc9859672d02f5fce83cc7f0f6169f")
addappid(1786012, 1, "79d4d2c977829bd504375685a203e57886eaa0092d2b7b5e2f88e60e7b079952")
