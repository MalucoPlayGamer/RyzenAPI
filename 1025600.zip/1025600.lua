-- Lua provided by RyzenAPI
-- Game: 1025600

-- MAIN APPLICATION
addappid(1025600)
-- Game: addappid(1025600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025601, 1, "4fcdfcbad24c7f621af25f25edd05bfd7d5061b6b698e3b4634b53f7003f1341")
