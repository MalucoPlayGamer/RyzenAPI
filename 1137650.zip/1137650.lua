-- Lua provided by RyzenAPI
-- Game: AppID 1137650

-- MAIN APPLICATION
addappid(1137650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137651, 1, "f4f11c9f2387a47a29f457ebaf9f8aa814c1cf180060cf3bd0bd0c732b20fff1")
