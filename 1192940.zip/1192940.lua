-- Lua provided by RyzenAPI
-- Game: Game: AppID 1192940

-- MAIN APPLICATION
addappid(1192940)
-- Game: addappid(1192940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192941, 1, "92a19e63955c4b1aeab59f659568df43d591df6c51de681f23cb92d4e9032d40")
