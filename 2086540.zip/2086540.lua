-- Lua provided by RyzenAPI
-- Game: Alchemist Tris's Desire

-- MAIN APPLICATION
addappid(2086540)
-- Game: addappid(2086540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086541, 1, "69a5410489a1388acb2058f2f11a4c58525a86325e72d7fab4b42bafa2266ef4")
addappid(2086542, 1, "596b31b98fc30c00c8971351e9069d45a98a8a42b6d4352b0185f776842d275c")
