-- Lua provided by RyzenAPI
-- Game: Game: Cat Lady - The Card Game

-- MAIN APPLICATION
addappid(869690)
-- Game: addappid(869690)

-- MAIN APP DEPOTS / PACKAGES
addappid(869691, 1, "9aaad84b27422f3e5ddca0c411886791c678ec60321832e0a1e0a97f5b631b71")
