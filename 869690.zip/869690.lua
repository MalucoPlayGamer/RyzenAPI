-- Lua provided by RyzenAPI
-- Game: Cat Lady - The Card Game

-- MAIN APPLICATION
addappid(869690)

-- MAIN APP DEPOTS / PACKAGES
addappid(869691, 1, "9aaad84b27422f3e5ddca0c411886791c678ec60321832e0a1e0a97f5b631b71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
