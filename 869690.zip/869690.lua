-- Lua provided by SkyAPI 
-- Game: Cat Lady - The Card Game
addappid(869690)
addappid(869691, 1, "9aaad84b27422f3e5ddca0c411886791c678ec60321832e0a1e0a97f5b631b71")
