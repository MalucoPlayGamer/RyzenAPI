-- Lua provided by RyzenAPI
-- Game: Solarpunk™

-- MAIN APPLICATION
addappid(1805110)
addappid(4668630)
addappid(4668720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1805111, 1, "c5241defefa1914cda91f5f5949ef7a14cf01e428d6de753f4e398eff41a632f")
addappid(4668631, 1, "0f8807c47861f68f2a1190bdc12707cf161c7800e47c547c473793e714a060ef")
addappid(4668721, 1, "9e0e0cb216c26305c299ca3a0f91b1e57f0b75fd9fc569eeeb03f7fc8c40b536")

