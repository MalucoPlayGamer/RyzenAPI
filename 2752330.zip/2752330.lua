-- Lua provided by RyzenAPI
-- Game: Game: NINJA SLAYER NEO-SAITAMA IN FLAMES(ニンジャスレイヤー ネオサイタマ炎上)

-- MAIN APPLICATION
addappid(2752330)
-- Game: addappid(2752330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752331, 1, "f84a65286a6656eedd9bc215a743a151257f8adc27f213b67ac62767ce5c265f")
