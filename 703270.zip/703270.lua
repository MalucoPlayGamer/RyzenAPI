-- Lua provided by RyzenAPI
-- Game: Run, my little pixel

-- MAIN APPLICATION
addappid(703270)

-- MAIN APP DEPOTS / PACKAGES
addappid(703271, 1, "925abf4b79e6b16bd14ad5fac8b6c7cfb101824c74bda35ae25284c519547112")

