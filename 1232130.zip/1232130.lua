-- Lua provided by RyzenAPI
-- Game: BEAR, VODKA, STALINGRAD! 🐻

-- MAIN APPLICATION
addappid(1232130)
addappid(1246590)
addappid(1246591)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232131, 1, "e965a087dad3c477fb5b8357a12c6c9d8d379aa03624e22c4e2bac2e59ea9ef0")
