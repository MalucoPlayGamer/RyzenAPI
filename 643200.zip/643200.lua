-- Lua provided by RyzenAPI
-- Game: Game: Keep in Mind: Remastered

-- MAIN APPLICATION
addappid(643200)
-- Game: addappid(643200)

-- MAIN APP DEPOTS / PACKAGES
addappid(643201, 1, "8ed3b691238656ef1f9be4f21ad1d021f0032481172aeb44dad48cf4a1915d13")
addappid(643202, 1, "31641b939e5afbb084f76ea807230080e61b89772c86970d658052522a8841fb")
addappid(804590, 0, "efd8a8987768a83b81a01cc3bed1780105cfea882a2e3e945a527c3c68949ad1")
