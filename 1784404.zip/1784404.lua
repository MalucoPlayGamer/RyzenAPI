-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Halloween 2021 - Free Asset for MZ

-- MAIN APPLICATION
addappid(1784404)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784404,0,"437896bf5923d7109c4d810b8278f9e64f0f4d86a5e7465cec47a44d37cf43e5")
