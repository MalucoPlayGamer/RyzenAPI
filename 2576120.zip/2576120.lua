-- Lua provided by SkyAPI 
-- Game: Memories: Millennium Girl Demo
addappid(2576120)
addappid(2576121, 1, "32c333ceb5e2a7208c123ec8b6be65a87a104210feb35840e576adb59164cc82")
