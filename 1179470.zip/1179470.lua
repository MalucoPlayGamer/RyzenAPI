-- Lua provided by RyzenAPI
-- Game: Krumit's Tale Soundtrack

-- MAIN APPLICATION
addappid(1179470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179470,0,"956011abcdc67ae1185d3d830abc5489a0a1b9aaf797f6d94372920275a1d448")
