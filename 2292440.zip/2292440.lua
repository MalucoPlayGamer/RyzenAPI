-- Lua provided by RyzenAPI
-- Game: inRun

-- MAIN APPLICATION
addappid(2292440)
-- Game: addappid(2292440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292441, 1, "d0e9bb5925252fc616c29bfa27d8a8ba19b85a08d6e71174c45027506bf9405e")
