-- Lua provided by RyzenAPI
-- Game: addappid(1199910)

-- MAIN APPLICATION
addappid(1199910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199911, 1, "87485a7fc3ce077ba38f7ece21e6347ac5e70480d39f68b262ab11bdf5768663")
