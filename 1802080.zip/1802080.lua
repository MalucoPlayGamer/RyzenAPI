-- Lua provided by SkyAPI 
-- Game: SGS Operation Hawaii
addappid(1802080)
addappid(1802081, 1, "a3b0e9ae10a917e9dba31d167b63cd0869a93102af2d48f004b1988506019444")
addappid(1802082, 1, "bafaf01025e8de3bab6ff3e31792021a32c86723dcd69c8ed244a35b9eb931b1")
