-- Lua provided by RyzenAPI
-- Game: Missy's Transformation Tournament

-- MAIN APPLICATION
addappid(1219060)
addappid(1219440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219061, 1, "09a04e884c26c892ce1e09425ab60cd2e19e30dc461005cecc1f743574a1a83e")

