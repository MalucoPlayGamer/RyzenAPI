-- Lua provided by RyzenAPI 
-- Game: Midnight
addappid(431460)
addappid(431461, 1, "253727893b6cbc4356ec94d44097dbb85652970f13bf6903a490758d17f5837f")
addappid(431462, 1, "a50e0f8283e3cf2bcbc21dfdbcd629db01430d68e495782bc5ab8e17ec133d72")
