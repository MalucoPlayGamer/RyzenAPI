-- 4240080's Lua and Manifest Created by Hubcap Manifest
-- BONEREADER
-- Created: August 06, 2026 at 11:24:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4240080) -- BONEREADER
-- MAIN APP DEPOTS
addappid(4240081, 1, "555400bb0bf7cc446f4724f6b62a94c4c16ba7cdd1276c2204b4f3fdef05312f") -- Depot 4240081
setManifestid(4240081, "5493909003952718630", 704126970)
-- DLCS WITH DEDICATED DEPOTS
-- BONEREADER Digital Artbook (AppID: 4894490)
addappid(4894490)
addappid(4894490, 1, "462433e0ba21d07c9abc617285593e204cb636add268422f7780ad68f77573ca") -- BONEREADER Digital Artbook - Depot 4894490
setManifestid(4894490, "9166775167664910023", 235408940)