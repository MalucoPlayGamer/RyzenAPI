-- Lua provided by RyzenAPI
-- Game: [DE:]Fanastasis

-- MAIN APPLICATION
addappid(2882080)
-- Game: addappid(2882080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2882081, 1, "dae9388de5dfb6a3d5217a26e31b8a0e8da36feb21d3fbc60e29387fa06364e8")
