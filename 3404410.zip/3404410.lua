-- Lua provided by RyzenAPI
-- Game: Game: The New Apartment

-- MAIN APPLICATION
addappid(3404410)
-- Game: addappid(3404410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3404411, 1, "640be821b48f54a2495d403bd674ed1a7184058f0e596b9c2122b13c39e81d4a")
