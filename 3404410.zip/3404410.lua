-- Lua provided by SkyAPI 
-- Game: The New Apartment
addappid(3404410)
addappid(3404411, 1, "640be821b48f54a2495d403bd674ed1a7184058f0e596b9c2122b13c39e81d4a")
