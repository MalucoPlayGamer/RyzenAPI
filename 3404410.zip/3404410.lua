-- Lua provided by RyzenAPI
-- Game: The New Apartment

-- MAIN APPLICATION
addappid(3404410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3404411, 1, "640be821b48f54a2495d403bd674ed1a7184058f0e596b9c2122b13c39e81d4a")

