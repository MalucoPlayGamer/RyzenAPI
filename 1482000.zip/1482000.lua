-- Lua provided by RyzenAPI
-- Game: LineArt Jigsaw Puzzle - Erotica 2

-- MAIN APPLICATION
addappid(1482000)
-- Game: addappid(1482000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482001, 1, "97d5e805169b8d7305f3a621268feab8c4be7b1865a74fbaa0dc60f6855d196a")
addappid(1536330, 0, "ecd0f1ef17583385f7b384c1ae35ce0aedb1d378ed170f88562fc6a40a2bfa88")
