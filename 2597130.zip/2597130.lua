-- Lua provided by RyzenAPI
-- Game: Uncle Chuck Incorporated

-- MAIN APPLICATION
addappid(2597130)
-- Game: addappid(2597130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597131, 1, "73f9bf3774e00c633617137fdb968c5f6bb3d7f7ddbcd149e09838565c670145")
