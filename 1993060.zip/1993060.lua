-- Lua provided by RyzenAPI
-- Game: Game: IMAGO: Beyond the Nightmares

-- MAIN APPLICATION
addappid(1993060)
-- Game: addappid(1993060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993061, 1, "6b2dd3cba5c49dd10b368d62f37332b3451dfa38d0a27e8cf8a31445375fe904")
