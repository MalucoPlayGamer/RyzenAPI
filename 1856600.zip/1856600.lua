-- Lua provided by RyzenAPI
-- Game: Rewrite Harvest festa!

-- MAIN APPLICATION
addappid(1856600)
-- Game: addappid(1856600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856601, 1, "28f674f2e7c3db6ab601c9d399513126ec06bfdd24cf9172be53b89d7aefc663")
