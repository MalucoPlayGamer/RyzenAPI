-- Lua provided by RyzenAPI
-- Game: AppID 983820

-- MAIN APPLICATION
addappid(983820)

-- MAIN APP DEPOTS / PACKAGES
addappid(983821, 1, "9da4464483ae17ccd4af2d1eec37669611a0fef0adc9a69c571da3118f72ff38")

