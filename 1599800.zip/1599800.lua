-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack2

-- MAIN APPLICATION
addappid(1599800)
-- Game: addappid(1599800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599800,0,"1932a21c52a90ae80b9d1196b239c2f582b505546edc3b0847a069028b679237")
