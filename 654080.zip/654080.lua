-- Lua provided by RyzenAPI
-- Game: addappid(654080)

-- MAIN APPLICATION
addappid(654080)

-- MAIN APP DEPOTS / PACKAGES
addappid(654082,0,"43d475fd2c52beb664dd6aa094a20e453c7f1f7da40d6484ee27843f1f244829")
