-- Lua provided by RyzenAPI
-- Game: AppID 512300

-- MAIN APPLICATION
addappid(512300)
addappid(525960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(512301, 1, "c7ac9125b3c33dffc1752457900f0681589234e911241c417d1eca3b60976f54")
addappid(512302, 1, "a61486d74864ae4b211bcbf7bcfbfbb6c7d4b3bc9b204fae559276cf29768366")

