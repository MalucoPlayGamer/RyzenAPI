-- Lua provided by RyzenAPI
-- Game: Tractor Cargo Driving Simulator

-- MAIN APPLICATION
addappid(1140070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140071, 1, "0cb0ea1595de3ec6bfee4ec7b0f9d1a540f18acf48a5c8df5aecdce1049738bf")
