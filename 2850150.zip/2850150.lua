-- Lua provided by RyzenAPI
-- Game: Game: G-MODEアーカイブス+ ペルソナ3 アイギス THE FIRST MISSION

-- MAIN APPLICATION
addappid(2850150)
-- Game: addappid(2850150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850151, 1, "8d14d1dfe60ee2ea14649c010e376f3d75f02423f948f0e897cef5cd33abef2b")
