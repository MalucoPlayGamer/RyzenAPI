-- Lua provided by RyzenAPI
-- Game: BMX Bastards Demo

-- MAIN APPLICATION
addappid(2630490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2630491, 1, "822938ae400942cdbc9398a5ec9909a49834a83d03b5f9ff4e41bbb488a0abbd")
