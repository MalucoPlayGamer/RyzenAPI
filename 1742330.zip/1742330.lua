-- Lua provided by RyzenAPI
-- Game: TARAKAN - Mystery Point & Click Adventure

-- MAIN APPLICATION
addappid(1742330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742331, 1, "0a8d744dd8adf2c95feab89e78284cdb8c738dfc9ba3ba92a028e3f2965039d7")

