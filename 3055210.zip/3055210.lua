-- Lua provided by RyzenAPI
-- Game: addappid(3055210)

-- MAIN APPLICATION
addappid(3055210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3055211, 1, "5fa47d2ac65a015465f1d671ea0fbdce4b18a72f707383041c7efb66c6fa3f6c")
