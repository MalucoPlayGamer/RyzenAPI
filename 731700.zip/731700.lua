-- Lua provided by RyzenAPI
-- Game: Wild Downtown

-- MAIN APPLICATION
addappid(731700)

-- MAIN APP DEPOTS / PACKAGES
addappid(731701,0,"2438a5b7922595e78b16f61c5fcf1bede69689eca7effb19ee1403f32cc349b0")

