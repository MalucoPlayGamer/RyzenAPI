-- Lua provided by RyzenAPI
-- Game: Wild Downtown

-- MAIN APPLICATION
addappid(731700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(731701,0,"2438a5b7922595e78b16f61c5fcf1bede69689eca7effb19ee1403f32cc349b0")

