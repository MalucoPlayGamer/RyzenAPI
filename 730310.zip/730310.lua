-- Lua provided by RyzenAPI
-- Game: 730310

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(730310)
-- Game: addappid(730310)

-- MAIN APP DEPOTS / PACKAGES
addappid(730313,0,"308703da76d059553e5f6c9354d62a54caf6f4efc45ce54dcc1a79766a5a6139")
addappid(730315,0,"a90f00f3030ebba61278889b992de81f8fe971fa81252078c10cfab5a14de47f")
addappid(776521,0,"883ee56f3eedbff5d386b4ef6ac92ed215cc5c6428f934d6b8f1a12f9dd2df2f")
addappid(776523,0,"91ca2dae4d9119f53448a6277b5b987bce6ca35b63b6d4444f448b4341f1a558")
