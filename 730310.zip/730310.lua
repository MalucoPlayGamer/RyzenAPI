-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9

-- MAIN APPLICATION
addappid(776530)
addappid(798860)
addappid(798870)
addappid(798880)
addappid(835590)
addappid(892390)
addappid(892391)
addappid(892392)
addappid(892393)
addappid(892394)
addappid(892395)
addappid(892396)
addappid(892397)
addappid(892398)
addappid(892399) -- Special Costume Set
addappid(956700)
addappid(956701)
addappid(956702)
addappid(956703)
addappid(956704)
addappid(956705)
addappid(956706)
addappid(956707)
addappid(956708)
addappid(956709)
addappid(956720)
addappid(956721)
addappid(956722)
addappid(956723)
addappid(956724)
addappid(956725)
addappid(956726)
addappid(956727)
addappid(956728)
addappid(956729)
addappid(956730)
addappid(956731)
addappid(956732)
addappid(956733)
addappid(956734)
addappid(956735)
addappid(956736)
addappid(956737)
addappid(956738)
addappid(956739)
addappid(956750)
addappid(956751)
addappid(956752)
addappid(956753)
addappid(956760)
addappid(956761)
addappid(956762)
addappid(956763)
addappid(956764)
addappid(956765)
addappid(956766)
addappid(956767)
addappid(956768)
addappid(956769)
addappid(956770)
addappid(956771)
addappid(956772)
addappid(956860)
addappid(956861)
addappid(956862)
addappid(956863)
addappid(956864)
addappid(956865)
addappid(956866)
addappid(956867)
addappid(956868)
addappid(956869)
addappid(956890)
addappid(956891)
addappid(956892)
addappid(956893)
addappid(956894)
addappid(956895)
addappid(956896)
addappid(956897)
addappid(956898)
addappid(956899)
addappid(956920)
addappid(956921)
addappid(956922)
addappid(956923)
addappid(956924)
addappid(956930)
addappid(956940)
addappid(956941)
addappid(956942)
addappid(956943)
addappid(956944)
addappid(956945)
addappid(956946)
addappid(956947)
addappid(956948)
addappid(956949)
addappid(962300)
addappid(962301)
addappid(962302)
addappid(962303)
addappid(962304)
addappid(962305)
addappid(962306)
addappid(964930)
addappid(964931)
addappid(964932)
addappid(964933)
addappid(964934)
addappid(964935)
addappid(964936)
addappid(964937)
addappid(964938)
addappid(978850)
addappid(978851)
addappid(978852)
addappid(978853)
addappid(978854)
addappid(978855)
addappid(978856)
addappid(978857)
addappid(978858)
addappid(978859)
addappid(978860)
addappid(978861)
addappid(978862)
addappid(978863)
addappid(978864)
addappid(978865)
addappid(978866)
addappid(978867)
addappid(1019960)
addappid(1019961)
addappid(1019962)
addappid(1019963)
addappid(1019964)
addappid(1019965)
addappid(1019966)
addappid(1019967)
addappid(1019968)
addappid(1019969)
addappid(1019970)
addappid(1019971)
addappid(1019980)
addappid(1019981)
addappid(1019982)
addappid(1019983)
addappid(1019984)
addappid(1019985)
addappid(1019986)
addappid(1019987)
addappid(1019988)
addappid(1019989)
addappid(1019990)
addappid(1019991)
addappid(1019992)
addappid(1019993)
addappid(1019994)
-- addappid(730314) -- Depot 730314 (empty depot)
-- addappid(730317) -- Depot 730317 (empty depot)
-- addappid(730318) -- Depot 730318 (empty depot)
-- addappid(776522) -- Depot 776522 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(730310, 1, "00b2a539e97d84621e7e0c20b8865409b7ef84cf70a4be56446383a0531bb6d2") -- DYNASTY WARRIORS 9
addappid(730313, 1, "308703da76d059553e5f6c9354d62a54caf6f4efc45ce54dcc1a79766a5a6139") -- cmndepot
addappid(730315, 1, "a90f00f3030ebba61278889b992de81f8fe971fa81252078c10cfab5a14de47f") -- lnkdepot
addappid(776521, 1, "883ee56f3eedbff5d386b4ef6ac92ed215cc5c6428f934d6b8f1a12f9dd2df2f") -- blddepot_Master
addappid(776523, 1, "91ca2dae4d9119f53448a6277b5b987bce6ca35b63b6d4444f448b4341f1a558") -- patdepot
addappid(776530, 1, "95a02a65c2a411225aa20e646c17a50358fcb0cabc60348896aa0ed14254227e") -- DYNASTY WARRIORS 9Season Pass - Epic - Season Pass 個のデポ
addappid(798860, 1, "038527fbfc4b71919808521fb7105da29f56ff8c8e4db34ae6e6101f3b767229") -- Additional Scenarios Pack - Additional Scenarios Pack/追加シナリオパック デポ
addappid(798870, 1, "680393c44baee691054a6e27404226e9504ae85eb46fcab200b5ddc6a2288d43") -- Additional Weapons Pack - Additional Weapons Pack/追加武器パック デポ
addappid(798880, 1, "e93184e1084c21e08fdf30e4ba3bc50ad166d284790b4e8bc8558532ed1be543") -- Hideaway Customization - Hideaway Customization/隠れ処カスタマイズパック デポ
addappid(835590, 1, "713d67329656d6275eed859cd81329338400d24444ac721fa3812c11353dd55b") -- DYNASTY WARRIORS 9 Useful Gems  Materials Set - DYNASTY WARRIORS 9 - Free DLC デポ
addappid(892390, 1, "358e1929492d8b81c62dcaf388a8f40a3124be3f182d30df64d59e0cf17613c2") -- Zhao Yun (Beijing Opera-Style Costume) - Zhao Yun (Beijing Opera-Style Costume)/趙雲「京劇風コスチューム」 デポ
addappid(892391, 1, "915b8fbf5be6565291b202ce4c1a979acd3d647210687ca5799b1d65297366bd") -- Sun Shangxiang (Dudou Costume) - Sun Shangxiang (Dudou Costume)
addappid(892392, 1, "13c3fc1f15dec088f5391a254ff6d943c7524c995c439e64a4f2ddc4026be8ab") -- Diaochan (Dudou Costume) - Diaochan (Dudou Costume)
addappid(892393, 1, "ed546f4dca38a532e2f8991a3243dabe0c5a6309b60b472a1cbbdedc2759c67e") -- Wang Yuanji (Dudou Costume) - Wang Yuanji (Dudou Costume)
addappid(892394, 1, "3832dc80a47763d4e04df32f49ee2a7451bae345662a104671223e7f344a784a") -- Wang Yi (Dudou Costume) - Wang Yi (Dudou Costume)
addappid(892395, 1, "94212f4d82e1fd418fc5d300898edf2bfb92ed3da9325cb7673da0a4968c354d") -- Guan Yinping (Dudou Costume) - Guan Yinping (Dudou Costume)
addappid(892396, 1, "5482f5ecde1d0b051caac191bc329321d49fee4f8b06a296633a3e196d2e0aa3") -- Lu Lingqi (Dudou Costume) - Lu Lingqi (Dudou Costume)
addappid(892397, 1, "8320bb19338a719e91c1f744d8351f0ea0fcf4243402edb8546a70f575578543") -- Xin Xianying (Special Costume) - Xin Xianying (Special Costume)
addappid(892398, 1, "100e3c632a058cb029ffed30b38b9a4f5314713a8a52fbff18b853d4b9f69b9e") -- Xin Xianying (Dudou Costume) - Xin Xianying (Dudou Costume)
addappid(956700, 1, "fba263a6935b15c4a7305a039e333f3a451d2457cf8a45ca150142bd0c4a17a9") -- Xiahou Dun - Officer Ticket   - Xiahou Dun - Officer Ticket デポ
addappid(956701, 1, "7a4db1b2a41daca4733b80091831a6b4a173e518a52cc7b5eaac3bc6f70869d7") -- Dian Wei - Officer Ticket   - Dian Wei - Officer Ticket デポ
addappid(956702, 1, "d3150aea50eb8da6ad4f2609eea552521dc4b4d052f731660b2e5dc918df1cf1") -- Sima Yi - Officer Ticket   - Sima Yi - Officer Ticket デポ
addappid(956703, 1, "2851d9f234b6772d6f8e0b090f8a810af99f5d55d45d9dcd8de51742d8504ebb") -- Zhang Liao - Officer Ticket   - Zhang Liao - Officer Ticket デポ
addappid(956704, 1, "1b1b5abe9f0e00edb2a6803eb22c6880c2017f8a37a94240c9cbaa03525e61ac") -- Cao Cao - Officer Ticket   - Cao Cao - Officer Ticket デポ
addappid(956705, 1, "4084331d93aeef171cd673001ea1e38d6f64f0590e11690cf1246de65310c92c") -- Zhou Yu - Officer Ticket   - Zhou Yu - Officer Ticket デポ
addappid(956706, 1, "7bf13137ec29cd68df774933b81828520eef4c7bdae11388973b392b5d2cac7f") -- Lu Xun - Officer Ticket   - Lu Xun - Officer Ticket デポ
addappid(956707, 1, "f30902f9fd904bf59c257b054c35970a56ebda0cb98a7702e8a5baff2bc8630b") -- Sun Shangxiang - Officer Ticket   - Sun Shangxiang - Officer Ticket デポ
addappid(956708, 1, "b637468afdf667a31d9e888d0cd16e23b83f80aee8e0522cd42795df4dddb320") -- Gan Ning - Officer Ticket   - Gan Ning - Officer Ticket デポ
addappid(956709, 1, "0debf4e31570d0e8b57e88a09d8b6e906903449d8bfbbcd67146627aed1718bc") -- Sun Jian - Officer Ticket   - Sun Jian - Officer Ticket デポ
addappid(956720, 1, "77e6cf963e320439624402033c0e603f200890aa1c620dce6dce70df7b436e3e") -- Zhao Yun - Officer Ticket   - Zhao Yun - Officer Ticket / 趙雲使用券 デポ
addappid(956721, 1, "2471ac3b89b7a73517971c658d0c5e3a38ec7375cc7391c5be34561cc6a31e8e") -- Guan Yu - Officer Ticket   - Guan Yu - Officer Ticket / 関羽使用券 デポ
addappid(956722, 1, "477dcd7e8cf7778f1492cbeaadaf0b271b9880c0d2daeee2248e190493577a74") -- Zhang Fei - Officer Ticket   - Zhang Fei - Officer Ticket / 張飛使用券 デポ
addappid(956723, 1, "3464dfdef50d053f7120de7aabfb251b5ab771528e346f3542f81d604e0fbcf8") -- Zhuge Liang - Officer Ticket   - Zhuge Liang - Officer Ticket / 諸葛亮使用券 デポ
addappid(956724, 1, "7579fe01cb58b2b59d64b5ba466ae4be86fca8db30f9954750699f48bc08e4d2") -- Liu Bei - Officer Ticket   - Liu Bei - Officer Ticket / 劉備使用券 デポ
addappid(956725, 1, "9f09c4d4e323e5f909a5b9f2816ffbb9f0417f40bff8efc8b4e6afe9c8f7ddd7") -- Diaochan - Officer Ticket   - Diaochan - Officer Ticket / 貂蝉使用券 デポ
addappid(956726, 1, "78e7c479bd4234984e800008c428673d90d35ca5616773ec98ccebb6e209f0e3") -- Lu Bu - Officer Ticket   - Lu Bu - Officer Ticket / 呂布使用券 デポ
addappid(956727, 1, "189278a8aa472f4f4b83f94f779f481e838e25b39127f67061885fbe08b82ce5") -- Xu Zhu - Officer Ticket   - Xu Zhu - Officer Ticket / 許褚使用券 デポ
addappid(956728, 1, "20fad3949e7f6362b97cbfeb0f20990d5470272233f23af2aa2cc2dde2a91d90") -- Xiahou Yuan - Officer Ticket   - Xiahou Yuan - Officer Ticket / 夏侯淵使用券 デポ
addappid(956729, 1, "50a8c76d42d7a53e78d0dbe3310962a19f85d88c104a7e760e2450007385a04a") -- Xu Huang - Officer Ticket   - Xu Huang - Officer Ticket / 徐晃使用券 デポ
addappid(956730, 1, "be22fa953036466ceb8acb51fbf7ce23a6bf51aa5e88350457af91903b140c35") -- Zhang He - Officer Ticket   - Zhang He - Officer Ticket / 張郃使用券 デポ
addappid(956731, 1, "6319423811b2b1899d428f570a7c73946a88df111fcd9812c970cee624ce5d88") -- Cao Ren - Officer Ticket   - Cao Ren - Officer Ticket / 曹仁使用券 デポ
addappid(956732, 1, "9b5026756fac28b38b5563b28421be97c9621706b766faa642c19cd780926841") -- Cao Pi - Officer Ticket   - Cao Pi - Officer Ticket / 曹丕使用券 デポ
addappid(956733, 1, "c0c618e65156475cb227c92760466bd2dcaf3c59e3144d9a61298adcf72fa61f") -- Taishi Ci - Officer Ticket   - Taishi Ci - Officer Ticket / 太史慈使用券 デポ
addappid(956734, 1, "0d2d440517018a2cf867f6b86c01bda04f25b015af12c9b4085c240796e5e690") -- Lu Meng - Officer Ticket   - Lu Meng - Officer Ticket / 呂蒙使用券 デポ
addappid(956735, 1, "852d5b1f0a498b712c1b171aff4b70fde0000935f65220817ab384ee1e12c487") -- Huang Gai - Officer Ticket   - Huang Gai - Officer Ticket / 黄蓋使用券 デポ
addappid(956736, 1, "2b0f1edbe2baa5c9211292f0eb41f4798a7ba0187d9c8098af9f6b93894aee63") -- Zhou Tai - Officer Ticket   - Zhou Tai - Officer Ticket / 周泰使用券 デポ
addappid(956737, 1, "f561244c46a92200f40a9fc6db007eed57ec0f1e8f97368478242ee7590a91ea") -- Ling Tong - Officer Ticket   - Ling Tong - Officer Ticket / 凌統使用券 デポ
addappid(956738, 1, "ba8aff5f0c3c547f05586ff50f725761c074a0e7eb9ff89c158afb2ad35a9614") -- Sun Ce - Officer Ticket   - Sun Ce - Officer Ticket / 孫策使用券 デポ
addappid(956739, 1, "afc6557b77caa43ec4d7fb1bdc1dd603dbfca20556458edd04e169ad1bf99aa1") -- Sun Quan - Officer Ticket   - Sun Quan - Officer Ticket / 孫権使用券 デポ
addappid(956750, 1, "3eabce7ffde1e12de1088e33a535f5bc18c8996f91599cad25301ac49c42c656") -- Ma Chao - Officer Ticket   - Ma Chao - Officer Ticket / 馬超使用券 デポ
addappid(956751, 1, "ddb3d9acb99288d755d3e1a4ad2358dae5d07a179bb3694956b8dbb1bb8d709e") -- Huang Zhong - Officer Ticket   - Huang Zhong - Officer Ticket / 黄忠使用券 デポ
addappid(956752, 1, "6ead28ae250a8047a06b6311cca3c245f421d22cee0f1c02c8a33847366cfe11") -- Wei Yan - Officer Ticket   - Wei Yan - Officer Ticket / 魏延使用券 デポ
addappid(956753, 1, "1bc8ada9d3ed0c04b1bc4dd4f7ee9eba1acfc4ad522596731e2e6e632a9d3c00") -- Guan Ping - Officer Ticket   - Guan Ping - Officer Ticket / 関平使用券 デポ
addappid(956760, 1, "f67695cdc5ee74559ae16e8a3a3e7159f45bc14db2e251a008c0e10a989f391e") -- Pang Tong - Officer Ticket   - Pang Tong - Officer Ticket / 龐統使用券 デポ
addappid(956761, 1, "9faf84c21c8711f93c9be9c26ac1b963d4355cfce3d3da939bda6fc2c070848e") -- Dong Zhuo - Officer Ticket   - Dong Zhuo - Officer Ticket / 董卓使用券 デポ
addappid(956762, 1, "7453ac3827589a51c8550fdb4ead2ac1fb46473d729510fc3edb131d9dacf059") -- Yuan Shao - Officer Ticket   - Yuan Shao - Officer Ticket / 袁紹使用券 デポ
addappid(956763, 1, "c18484f94f36d1ddb78ec8073ae1a3f5b504ea6c1e94f09670a239de601a7e22") -- Zhang Jiao - Officer Ticket   - Zhang Jiao - Officer Ticket / 張角使用券 デポ
addappid(956764, 1, "70d9dbcfcd2b1d1718c4d48f170b69367ec23d78305629ebbcebb5246689efb8") -- Zhenji - Officer Ticket   - Zhenji - Officer Ticket / 甄姫使用券 デポ
addappid(956765, 1, "56f549b3c6c8b21195dad08d3ff9c865edca582b93cedb944793b37c182f7f32") -- Xiaoqiao - Officer Ticket   - Xiaoqiao - Officer Ticket / 小喬使用券 デポ
addappid(956766, 1, "8c5179176440813b88541dbe01713760a3aca81c43e32955166d149a29fc9629") -- Yueying - Officer Ticket   - Yueying - Officer Ticket / 月英使用券 デポ
addappid(956767, 1, "a7deea0f66bc85053f33fd4d0d3b72de79bf02cc0bc169eb388f8edcdbcc7c51") -- Meng Huo - Officer Ticket   - Meng Huo - Officer Ticket / 孟獲使用券 デポ
addappid(956768, 1, "b5ee986e890e2db56294be6c938148bcffb618c6db09492630405ed96817c1da") -- Cai Wenji - Officer Ticket   - Cai Wenji - Officer Ticket / 蔡文姫使用券 デポ
addappid(956769, 1, "c8509e10f1301f53c33a3dce54c673c9ce92dcfcc730b162a479342aa21fa3ce") -- Daqiao - Officer Ticket   - Daqiao - Officer Ticket / 大喬使用券 デポ
addappid(956770, 1, "0519a532a24bb13252554db6c7064719ff1c05f46e0b6c2fad29d59c73ea72f6") -- Jiang Wei - Officer Ticket   - Jiang Wei - Officer Ticket / 姜維使用券 デポ
addappid(956771, 1, "dbf25bf323ace20b80d09afc5f0d1e80f6fe0dbd50886218af7759bff8e4ee8e") -- Jia Xu - Officer Ticket   - Jia Xu - Officer Ticket / 賈詡使用券 デポ
addappid(956772, 1, "eae3cfcd478a45cd8627e48c0a251831c00def73d7b6afcbc5fcf3791e39a697") -- Sima Shi - Officer Ticket   - Sima Shi - Officer Ticket / 司馬師使用券 デポ
addappid(956860, 1, "9a193de86cf06fdc298d0bbef8e28309b2990ab80adc0f6010f024c29dacf1a6") -- Sima Zhao - Officer Ticket   - Sima Zhao - Officer Ticket / 司馬昭使用券 デポ
addappid(956861, 1, "ca07ad4e20695315b498da58d45306a3f27a042e1d990fc7e94ddfdf07e19afa") -- Deng Ai - Officer Ticket   - Deng Ai - Officer Ticket / 鄧艾使用券 デポ
addappid(956862, 1, "89529c80e86eabd1dbafba6db12cf463f43f63e13066d24d7d6b59a116395a52") -- Wang Yuanji - Officer Ticket   - Wang Yuanji - Officer Ticket / 王元姫使用券 デポ
addappid(956863, 1, "b0ccd31266300c79465e1f27ebcdcd549c4ec0931db309874907c83a7fd3250a") -- Zhong Hui - Officer Ticket   - Zhong Hui - Officer Ticket / 鍾会使用券 デポ
addappid(956864, 1, "a502c7afe79318548a89634cace6ce674a3fad2cb2ca79fac48b32d424c71f04") -- Zhuge Dan - Officer Ticket   - Zhuge Dan - Officer Ticket / 諸葛誕使用券 デポ
addappid(956865, 1, "fad2ef32bfb8c29008d97b2ed17f7dd802ce0e379c7e1120d5230c1c5f6dbe5f") -- Xiahou Ba - Officer Ticket   - Xiahou Ba - Officer Ticket / 夏侯覇使用券 デポ
addappid(956866, 1, "95bc5ca5bf1492413459aab8be16d5017f08a1b3bb21ce6e1fa9448bb883d541") -- Guo Huai - Officer Ticket   - Guo Huai - Officer Ticket / 郭淮使用券 デポ
addappid(956867, 1, "edb70a1e6d47a238cf1773d8d102fd11f2bf9539789619061472bd71bd0edf51") -- Ding Feng - Officer Ticket   - Ding Feng - Officer Ticket / 丁奉使用券 デポ
addappid(956868, 1, "c28f00b0b1ae615445563d1c8867a36a33acdd9df5428e3bc930f59dc012187c") -- Liu Shan - Officer Ticket   - Liu Shan - Officer Ticket / 劉禅使用券 デポ
addappid(956869, 1, "8b910d757ec6004ae628f589d8ca29cb99699256994e834b20e47e60a0307f33") -- Xingcai - Officer Ticket   - Xingcai - Officer Ticket / 星彩使用券 デポ
addappid(956890, 1, "d0b87846d81f96ac7ea277dfd5b73af68eb04695ecd8b8134c7525a5f46a66a6") -- Lianshi - Officer Ticket   - Lianshi - Officer Ticket / 練師使用券 デポ
addappid(956891, 1, "68afe4e6c113be39cd547505876351b58507de7543f1ef86fabe88274f47d74d") -- Ma Dai - Officer Ticket   - Ma Dai - Officer Ticket / 馬岱使用券 デポ
addappid(956892, 1, "05c202350aee5bab39c3123a393a61e3ee59bb9c6dd98952d0d63d3cecd2b89a") -- Zhurong - Officer Ticket   - Zhurong - Officer Ticket / 祝融使用券 デポ
addappid(956893, 1, "a40ec02bebfe87562ca1867e5443958a6aef27f76f7ae494df08e745225c9bce") -- Guan Suo - Officer Ticket   - Guan Suo - Officer Ticket / 関索使用券 デポ
addappid(956894, 1, "56132c9ae9d2210391e6149ed5ebf787d7215d62d4b514476303c87b753a0e05") -- Bao Sanniang - Officer Ticket   - Bao Sanniang - Officer Ticket / 鮑三娘使用券 デポ
addappid(956895, 1, "a71e9a4bc4b006ea1d1d4883cda58862f948b6ef197e20d13b4142ab2e52f69b") -- Pang De - Officer Ticket   - Pang De - Officer Ticket / 龐徳使用券 デポ
addappid(956896, 1, "2f6c110f0d7536791edc582315307bd16d078f0fea5b9b4c61d650216c82fcfd") -- Wang Yi - Officer Ticket   - Wang Yi - Officer Ticket / 王異使用券 デポ
addappid(956897, 1, "8cc210beb59192128f63f6313a4c7c6b3e6b1872087b9169b518ee956e5e3782") -- Guo Jia - Officer Ticket   - Guo Jia - Officer Ticket / 郭嘉使用券 デポ
addappid(956898, 1, "fea9b6a3e14ae60906b4a0824a6b6080d3c0fabb4cb4dd7406a9bbe281ef7b6a") -- Xu Shu - Officer Ticket   - Xu Shu - Officer Ticket / 徐庶使用券 デポ
addappid(956899, 1, "d214d2d9b4d3f1f4ffd95c6528dd745fce72a9985f2d1411547effb1ab3b38b8") -- Zuo Ci - Officer Ticket   - Zuo Ci - Officer Ticket / 左慈使用券 デポ
addappid(956920, 1, "f59453acfad5aa76634f50769015c8ba155af3d9887a244a3cb2cc593e912057") -- Yue Jin - Officer Ticket   - Yue Jin - Officer Ticket / 楽進使用券 デポ
addappid(956921, 1, "17d57c8fa0dbbc14094bffe9b381c151aa4089b585233a988a5522a7d5acd6ea") -- Li Dian - Officer Ticket   - Li Dian - Officer Ticket / 李典使用券 デポ
addappid(956922, 1, "2a4447f2601ad0c9871496d5bca896c9a78c13af1c6508a90f60c4bac5e8f926") -- Lu Su - Officer Ticket   - Lu Su - Officer Ticket / 魯粛使用券 デポ
addappid(956923, 1, "d77f6b2bb40aeec092cb8e56452bd5a2b4466d29cca31032bdf2035548192b7b") -- Han Dang - Officer Ticket   - Han Dang - Officer Ticket / 韓当使用券 デポ
addappid(956924, 1, "af670691b806805311ade1e8ee3aafa776e8f11a5678184022364d55127557d2") -- Guan Xing - Officer Ticket   - Guan Xing - Officer Ticket / 関興使用券 デポ
addappid(956930, 1, "d9f17ec71f6046f8e21719497c3ee2826151d03e0e5d29cdcb3248c70e2e7565") -- Zhang Bao - Officer Ticket   - Zhang Bao - Officer Ticket / 張苞使用券 デポ
addappid(956940, 1, "81099d72f7e443216b8dd51b71c36b00e45225e656c643eed9ef2084093a8599") -- Guan Yinping - Officer Ticket   - Guan Yinping - Officer Ticket / 関銀屏使用券 デポ
addappid(956941, 1, "e241be9ac9650224ae69977e15d8edbaca710f77a00fba3551b779c762ac1190") -- Jia Chong - Officer Ticket   - Jia Chong - Officer Ticket / 賈充使用券 デポ
addappid(956942, 1, "36038e0380306dc1a3abe3bec39f31994808f3ab69eec730e0d9e9e42c719b68") -- Wen Yang - Officer Ticket   - Wen Yang - Officer Ticket / 文鴦使用券 デポ
addappid(956943, 1, "7556986eda7fe6c6176e1bc2bec5314d58566790d501cbaff71ed83dd417925e") -- Zhang Chunhua - Officer Ticket   - Zhang Chunhua - Officer Ticket / 張春華使用券 デポ
addappid(956944, 1, "fa46250a270d45108875da2e7ba9fff6a9ae271dd59a4b8e0cd1fccf05c9cd04") -- Yu Jin - Officer Ticket   - Yu Jin - Officer Ticket / 于禁使用券 デポ
addappid(956945, 1, "8e4f21b3472163cbd37cd362eba71138fd02e580dbc6fcc67ef3808502c50acf") -- Zhu Ran - Officer Ticket   - Zhu Ran - Officer Ticket / 朱然使用券 デポ
addappid(956946, 1, "47021608db29d399338fddbc5d6243eaeb499283580fbfc379078e619bbefe9f") -- Fa Zheng - Officer Ticket   - Fa Zheng - Officer Ticket / 法正使用券 デポ
addappid(956947, 1, "3946d1548d963f40cfdb9fc20b9e7f889b968b578ac1d28f3f4da2347a838330") -- Chen Gong - Officer Ticket   - Chen Gong - Officer Ticket / 陳宮使用券 デポ
addappid(956948, 1, "c20d3a5d08dcbfd20dd9a3ff7496fbe8b2acc753a8b10017edac36ad6e31cbaa") -- Lu Lingqi - Officer Ticket   - Lu Lingqi - Officer Ticket / 呂玲綺使用券 デポ
addappid(956949, 1, "8cf21a5e2ed606d7089bbde792d72df0a42e81c170f068eacf129da5f7482e02") -- Xun Yu - Officer Ticket   - Xun Yu - Officer Ticket / 荀彧使用券 デポ
addappid(962300, 1, "08c507339b9b5c64543a8e5a683e7b504343eb0a4975ed35ea3ec975855f52db") -- Cao Xiu - Officer Ticket   - Cao Xiu - Officer Ticket / 曹休使用券 デポ
addappid(962301, 1, "c8ef36e68d5068762a3701e8188c552ac0edf4ca1fe28bc50654f689b50c084b") -- Man Chong - Officer Ticket   - Man Chong - Officer Ticket / 満寵使用券 デポ
addappid(962302, 1, "dad6a3951d5338d125926c8361e890810054a6edb17578730da34a9d7c8b4cf8") -- Xun You - Officer Ticket   - Xun You - Officer Ticket / 荀攸使用券 デポ
addappid(962303, 1, "b19a64b21f3168579d38871ba62158b621c6382900187f5707cf96ae7607f32f") -- Cheng Pu - Officer Ticket   - Cheng Pu - Officer Ticket / 程普使用券 デポ
addappid(962304, 1, "6924d8d552441aae4c57ac5bca2372d2dcd71c63182bb1b2a7a3ec72030bd6d5") -- Xu Sheng - Officer Ticket   - Xu Sheng - Officer Ticket / 徐盛使用券 デポ
addappid(962305, 1, "b0e60987c2d0bb79a10dee7b8add758ec6af78b8eed0c3852aad8b1c7bd813bf") -- Zhou Cang - Officer Ticket   - Zhou Cang - Officer Ticket / 周倉使用券 デポ
addappid(962306, 1, "f77350d88eb3c277cba9dfc442693f305f68fd81602fe7edba38a5705be89243") -- Xin Xianying - Officer Ticket   - Xin Xianying - Officer Ticket / 辛憲英使用券 デポ
addappid(964930, 1, "8d6e1a8b596db24106b4cd82eece26e010f10b926c0bb21bf5b1e381c3825cfb") -- DYNASTY WARRIORS 9 Season Pass 2   - DYNASTY WARRIORS 9: Season Pass 2 / シーズンパス２ デポ
addappid(964931, 1, "d412a7729a307c5cbfcb7788c13324628528b83c60ab1b4a22537e8ea199c671") -- DYNASTY WARRIORS 9 Sun Shangxiang (High school girls Costume)    - DYNASTY WARRIORS 9: Sun Shangxiang (High school girls Costume) / 孫尚香 「女子高生風コスチューム」 デポ
addappid(964932, 1, "798d36c9c506c1d9d08db439a038c7cd59ddb7bab9f12ca30c408a104828d251") -- DYNASTY WARRIORS 9 Daqiao (High school girls Costume)    - DYNASTY WARRIORS 9: Daqiao (High school girls Costume) / 大喬 「女子高生風コスチューム」 デポ
addappid(964933, 1, "b880a1329de2b8053ebaf9cfbfbd849abc6f8a16a916ffe1f65ce65825df610c") -- DYNASTY WARRIORS 9 Lianshi (Police officers Costume)    - DYNASTY WARRIORS 9: Lianshi (Police officers Costume) / 練師 「警官風コスチューム」 デポ
addappid(964934, 1, "f6a11222ee748bb85a57f1402882272ee1292f43dfb0686d04ab9dfe2f009e83") -- DYNASTY WARRIORS 9 Xiaoqiao (High school girls Costume)    - DYNASTY WARRIORS 9: Xiaoqiao (High school girls Costume) / 小喬 「女子高生風コスチューム」 デポ
addappid(964935, 1, "24a7c337dd027d8c88e17500727c6433e415ee91e7b74d8c43589743348ab29d") -- DYNASTY WARRIORS 9 Xingcai (High school girls Costume)    - DYNASTY WARRIORS 9: Xingcai (High school girls Costume) / 星彩 「女子高生風コスチューム」 デポ
addappid(964936, 1, "32c8dbad4baae70dcb5ad167497df1cd04b0c0ae0a061cb904dcf52c573c9059") -- DYNASTY WARRIORS 9 Bao Sanniang (Cheerleaders Costume)    - DYNASTY WARRIORS 9: Bao Sanniang (Cheerleaders Costume) / 鮑三娘 「チアガール風コスチューム」 デポ
addappid(964937, 1, "377de828c064e482b93038826ba77f98b4971205197706ee8986febdc2c6fad5") -- DYNASTY WARRIORS 9 Guan Yinping (High school girls Costume)    - DYNASTY WARRIORS 9: Guan Yinping (High school girls Costume) / 関銀屏 「女子高生風コスチューム」 デポ
addappid(964938, 1, "40d1b6fd1d52d7af6be994d9bf3e84847558b2ad47b88b09a63785fff4645bf2") -- DYNASTY WARRIORS 9 Xiahouji (New wife Costume)    - DYNASTY WARRIORS 9: Xiahouji (New wife Costume) / 夏侯姫 「新妻風コスチューム」 デポ
addappid(978850, 1, "64502944ca1b11a96cf44ee30baca62d702e190064d295f60f28e97485e083cb") -- DYNASTY WARRIORS 9 Zhenji (Flight Attendant Costume)   CA - DYNASTY WARRIORS 9: Zhenji (Flight Attendant Costume) / 甄姫 「CA風コスチューム」 デポ
addappid(978851, 1, "5cfaa00da61dc3cfe9c3a83391ed6a45c060e3245ac8cd3dd866f122e38fd0b0") -- DYNASTY WARRIORS 9 Cai Wenji (Maid Costume)    - DYNASTY WARRIORS 9: Cai Wenji (Maid Costume) / 蔡文姫 「メイド風コスチューム」 デポ
addappid(978852, 1, "8af37620ba80bdd730001144e286cfa5c9d1a5a2a2f58c4a602aee08b9a35e11") -- DYNASTY WARRIORS 9 Wang Yi (Sommelier Costume)    - DYNASTY WARRIORS 9: Wang Yi (Sommelier Costume) / 王異 「ソムリエ風コスチューム」 デポ
addappid(978853, 1, "f108a313d2f9bf5736e6d57183af302cc5353ca0d650324e51028f1025e7a54b") -- DYNASTY WARRIORS 9 Xin Xianying (Concierge Costume)    - DYNASTY WARRIORS 9: Xin Xianying (Concierge Costume) / 辛憲英 「コンシェルジュ風コスチューム」 デポ
addappid(978854, 1, "80d2b72918a28373cda3f794480193981b3b39d7d6cbb2a23e28412522c7f6a8") -- DYNASTY WARRIORS 9 Wang Yuanji (Nurse Costume)    - Wang Yuanji (Nurse Costume) / 王元姫 「ナース風コスチューム」
addappid(978855, 1, "acfae41f6ecf0099bd7cf74069c31a1edc47fc000963bf6cab72b7bca0ec0a57") -- DYNASTY WARRIORS 9 Diaochan (Bride Costume)    - Diaochan (Bride Costume) / 貂蝉 「花嫁風コスチューム」
addappid(978856, 1, "3412eced9e0e923698a1e3209a61f0a8f1bca550b6cdff63ca0da8740188aa7a") -- DYNASTY WARRIORS 9 Lu Lingqi (High School Girls Costume)    - Lu Lingqi (High School Girls Costume) / 呂玲綺 「女子高生風コスチューム」
addappid(978857, 1, "9a9042a6ae6f49481afbcd1b630c55f57f2875484934251d3d79bcdef217c2c7") -- DYNASTY WARRIORS 9 Dong Bai (Cutesy Goth Costume)    - Dong Bai (Cutesy Goth Costume) / 董白 「ゴスロリ制服風コスチューム」
addappid(978858, 1, "1ac9007668daaa7b047c100b670f87a0e69e768fdf68dd7315980b7e632243d5") -- DYNASTY WARRIORS 9 Additional Weapon Inferno Voulge   - DYNASTY WARRIORS 9: Fire Dust Dual Blade / 追加武器「火塵双刀」 デポ
addappid(978859, 1, "6282336e7d1f2db555d652d0c80bb00632ed2c8dd007802a84d5ab92779988b3") -- DYNASTY WARRIORS 9 Additional Weapon Serpent Blade   - DYNASTY WARRIORS 9: Serpent Blade / 追加武器「蛇矛」 デポ
addappid(978860, 1, "b5b39146817d59484d352e1badda65bcdb9ae159e25066b204fd2b3bea682363") -- DYNASTY WARRIORS 9 Additional Weapon Curved Sword   - DYNASTY WARRIORS 9: Curved Sword / 追加武器「弧刀」 デポ
addappid(978861, 1, "420aa58748331d7d1ea95965ab9d059f482d78647d113edd55b9d376fa52dc69") -- DYNASTY WARRIORS 9 Additional Weapon Crescent Edge   - Crescent Edge / 追加武器「月牙鏟」
addappid(978862, 1, "0288eeaad9131f322165721f1f6d230c96a2fd998ee28db8b889978d9ee1b1f0") -- DYNASTY WARRIORS 9 Additional Weapon Lightning Sword   - Lightning Sword / 追加武器「迅雷剣」
addappid(978863, 1, "b315ec666186e8b6d801c5e664bd999d987ac634a51fd9133e65f752df1c8bad") -- DYNASTY WARRIORS 9 Additional Weapon Dual Hookblades   - Dual Hookblades / 追加武器「双鉤」
addappid(978864, 1, "95f67c3c5fb24458b6f6c43a02e4eb390f52718e6a3a279fea6c1b331829116d") -- DYNASTY WARRIORS 9 Guo Jia Additional Hypothetical Scenarios Set   - DYNASTY WARRIORS 9: Guo Jia Special Scenario / 郭嘉「追加ＩＦシナリオ」 デポ
addappid(978865, 1, "9bcecd8f1b1d064e59fd918451aa1710bb5fa14b9ead813cd3f4fb5b234e48a3") -- DYNASTY WARRIORS 9 Zhou Yu Additional Hypothetical Scenarios Set   - DYNASTY WARRIORS 9: Zhou Yu Special Scenario / 周瑜「追加ＩＦシナリオ」 デポ
addappid(978866, 1, "f619a8980d5968fb40661dcfdbea7c4473d16b4fe649056380cfde2e11ccbe9b") -- DYNASTY WARRIORS 9 Xu Shu Additional Hypothetical Scenarios Set  - DYNASTY WARRIORS 9: Xu Shu Special Scenario / 徐庶「追加ＩＦシナリオ」 デポ
addappid(978867, 1, "833dcb7dee5638e60be6bc2883fa275f888f5de3c6ed67200ebacbf576ec91a9") -- DYNASTY WARRIORS 9 Chen Gong Additional Hypothetical Scenarios Set   - DYNASTY WARRIORS 9: Chen Gong Special Scenario / 陳宮「追加ＩＦシナリオ」 デポ
addappid(1019960, 1, "892347771f99acc691323b006b5c5a1ea6ae850d713ab3f7437eeb41ae5c948a") -- DYNASTY WARRIORS 9 Season Pass 3   - DYNASTY WARRIORS 9: Season Pass 3 / シーズンパス３ デポ
addappid(1019961, 1, "e79dffed0c941b1267b1534a9edaf27876cb25ef2fdc92db2a8d8527ddfa2b22") -- DYNASTY WARRIORS 9 Lu Xun Knight Costume   - DYNASTY WARRIORS 9: Lu Xun &quot;Knight Costume&quot; / 陸遜「騎士風コスチューム」 デポ
addappid(1019962, 1, "8def513740f507b7a700f3921da1cb82d31c2a4753783c549f025788bf84491b") -- DYNASTY WARRIORS 9 Xingcai Knight Costume   - DYNASTY WARRIORS 9: Xingcai &quot;Knight Costume&quot; / 星彩「騎士風コスチューム」 デポ
addappid(1019963, 1, "4626d27594ebea378a66f8d08b917bc3c7faf34de06fc753b2d7018c38d54e7c") -- DYNASTY WARRIORS 9 Xun Yu Knight Costume   - DYNASTY WARRIORS 9: Xun Yu &quot;Knight Costume&quot; / 荀彧「騎士風コスチューム」 デポ
addappid(1019964, 1, "6cb115fab352eed480ad135d74111966c9696bb29be8322b42b8e96f1dcfbdf8") -- DYNASTY WARRIORS 9 Guan Yinping Knight Costume   - DYNASTY WARRIORS 9: Guan Yinping &quot;Knight Costume&quot; / 関銀屏「騎士風コスチューム」 デポ
addappid(1019965, 1, "4f376206268a2ca83e65f4c6723248fd4f1cf398f5a0268eeebe061f46ca2ec7") -- DYNASTY WARRIORS 9 Additional Weapon Tripartite Nunchucks   - DYNASTY WARRIORS 9: Additional Weapon &quot;Tripartite Nunchucks&quot; / 追加武器「三結棍」 デポ
addappid(1019966, 1, "0eb600f4ca81a67a4d4a1af63b18d0aceb184849ecf02c39aeb6062c1f66faed") -- DYNASTY WARRIORS 9 Additional Weapon Tooth  Nail   - DYNASTY WARRIORS 9: Additional Weapon &quot;Tooth &amp; Nail&quot; / 追加武器「投牙弓」 デポ
addappid(1019967, 1, "27397d650ffd59c48921f66f3039b1bd336117803b7366abddf822e7eaca9fcc") -- DYNASTY WARRIORS 9 Additional Weapon Crossed Pike   - DYNASTY WARRIORS 9: Additional Weapon &quot;Crossed Pike&quot; / 追加武器「十字戟」 デポ
addappid(1019968, 1, "941c9368a2eb3f6ec0ea8bb558847f580b16e24cbee51768461a96b77b66895c") -- DYNASTY WARRIORS 9 Wang Yuanji Knight Costume   - DYNASTY WARRIORS 9: Wang Yuanji &quot;Knight Costume&quot; / 王元姫「騎士風コスチューム」 デポ
addappid(1019969, 1, "626262e30ecd3a506376a27793e3fe45a55d02600e21dd30e31dc6b93831f2f9") -- DYNASTY WARRIORS 9 Diaochan Knight Costume   - DYNASTY WARRIORS 9: Diaochan &quot;Knight Costume&quot; / 貂蝉「騎士風コスチューム」 デポ
addappid(1019970, 1, "681b9ef0e97ccd7b6cdd439670675efa68bf2e59ccdface966077c382aae13bf") -- DYNASTY WARRIORS 9 Yue Jin Knight Costume   - DYNASTY WARRIORS 9: Yue Jin &quot;Knight Costume&quot; / 楽進「騎士風コスチューム」 デポ
addappid(1019971, 1, "0d4eebd735332052095d6f4781cbe24bc2b2a5831c0bc13d9a1aa7bdbd8817e3") -- DYNASTY WARRIORS 9 Li Dian Knight Costume   - DYNASTY WARRIORS 9: Li Dian &quot;Knight Costume&quot; / 李典「騎士風コスチューム」 デポ
addappid(1019980, 1, "7751200422b001850e422155085150b50b6b1eecb217eff50c8ee632b712b9b8") -- DYNASTY WARRIORS 9 Cao Pi Special Scenario   - DYNASTY WARRIORS 9: Cao Pi Special Scenario / 曹丕「追加ＩＦシナリオセット」 デポ
addappid(1019981, 1, "01a76e18abf5c2d1a5db9ceffeed1b7b3f85017c675f4a5960adf8fb9820e1ac") -- DYNASTY WARRIORS 9 Lu Su Special Scenario   - DYNASTY WARRIORS 9: Lu Su Special Scenario / 魯粛「追加ＩＦシナリオセット」 デポ
addappid(1019982, 1, "4e7873685bc38986589e041284bcbf96ca424975227652c05e1d5c41a5dc2d07") -- DYNASTY WARRIORS 9 Fa Zheng Special Scenario   - DYNASTY WARRIORS 9: Fa Zheng Special Scenario / 法正「追加ＩＦシナリオセット」 デポ
addappid(1019983, 1, "0c0b3b05158288f1971157f50a0c38eb47982c46063a85bcf9ac9db731e8b3df") -- DYNASTY WARRIORS 9 Zhong Hui Special Scenario  IF - DYNASTY WARRIORS 9: Zhong Hui Special Scenario / 鍾会「追加IFシナリオセット」 デポ
addappid(1019984, 1, "71cc2cca2e915ef997fc6208616e1581beb973660553b8f940cf73bf9d136ee7") -- DYNASTY WARRIORS 9 Sun Shangxiang Knight Costume   - DYNASTY WARRIORS 9: Sun Shangxiang &quot;Knight Costume&quot; / 孫尚香「騎士風コスチューム」 デポ
addappid(1019985, 1, "459a8b0cee68845f49ca08be9df76eaafd5f7c6daaecf2f1fb392099c485aca4") -- DYNASTY WARRIORS 9 Lianshi Knight Costume   - DYNASTY WARRIORS 9: Lianshi &quot;Knight Costume&quot; / 練師「騎士風コスチューム」 デポ
addappid(1019986, 1, "2bc1ca8b55ccd70f3e3f0ee493d40baa477bed0d4c932f32ec1a1774a2d535fa") -- DYNASTY WARRIORS 9 Ma Dai Knight Costume   - DYNASTY WARRIORS 9: Ma Dai &quot;Knight Costume&quot; / 馬岱「騎士風コスチューム」 デポ
addappid(1019987, 1, "df85bb74092dd648fabbd7be39fad2d952f1d01d60c9f3f83207449af7e800a5") -- DYNASTY WARRIORS 9 Jia Chong Knight Costume   - DYNASTY WARRIORS 9: Jia Chong &quot;Knight Costume&quot; / 賈充「騎士風コスチューム」 デポ
addappid(1019988, 1, "6076c1eb38ac9e09581243f8b2afb0856efe465e153178e6524d1e4ebb3e0d62") -- DYNASTY WARRIORS 9 Xin Xianying Knight Costume   - DYNASTY WARRIORS 9: Xin Xianying &quot;Knight Costume&quot; / 辛憲英「騎士風コスチューム」 デポ
addappid(1019989, 1, "45ac1e458deeb336095cad5f0362c3bd7aa07123cf26408fa4fa0e943c5e7d45") -- DYNASTY WARRIORS 9 Wang Yi Knight Costume   - DYNASTY WARRIORS 9: Wang Yi &quot;Knight Costume&quot; / 王異「騎士風コスチューム」 デポ
addappid(1019990, 1, "ac399c92f4f52c31ca8765f9fb9151a31a9951b2549e9c9bbb04463654d95e1d") -- DYNASTY WARRIORS 9 Gan Ning Samurai Costume   - DYNASTY WARRIORS 9: Gan Ning &quot;Samurai Costume&quot; / 甘寧「武者風コスチューム」 デポ
addappid(1019991, 1, "20fa9d8f177f83d027719b6dd208490b36ec4c64ee8704981a3fa4b04022a438") -- DYNASTY WARRIORS 9 Ling Tong Samurai Costume   - DYNASTY WARRIORS 9: Ling Tong &quot;Samurai Costume&quot; / 凌統「武者風コスチューム」 デポ
addappid(1019992, 1, "ab543be4da40040c398b2870c79ba30a1a6c60c9fd30ce81895f8a86e1a66fdd") -- DYNASTY WARRIORS 9 Additional Weapon Iron Flute   - DYNASTY WARRIORS 9: Additional Weapon &quot;Iron Flute&quot; / 追加武器「鉄笛」 デポ
addappid(1019993, 1, "8ccf5a72f3fb6b44aa524d77503779485feded804c45b63f6c11ea0cfb105568") -- DYNASTY WARRIORS 9 Additional Weapon Tempest Mace   - DYNASTY WARRIORS 9: Additional Weapon &quot;Tempest Mace&quot; / 追加武器「昊転錘」 デポ
addappid(1019994, 1, "d1ba283f99d35ded7684e6e8b9411335ca206eb7a10a62492976f396073d28ae") -- DYNASTY WARRIORS 9 Additional Weapon Bow  Rod   - DYNASTY WARRIORS 9: Additional Weapon &quot;Bow &amp; Rod&quot; / 追加武器「鞭箭弓」 デポ

