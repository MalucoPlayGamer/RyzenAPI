-- Lua provided by RyzenAPI
-- Game: Deadfall Adventures

-- MAIN APPLICATION
addappid(231330)

-- MAIN APP DEPOTS / PACKAGES
addappid(231331, 1, "3a99e14118eca1236ae84410fd325a4bcdd66e378d07c9d01cb2563758897e6c")
addappid(231333, 1, "75c6d8f2b259327112b0cd3422c88126b59a2674525b49fc05e81d19ec9b76fa")
addappid(231334, 1, "d0be3e551ff91501df3178f74173846a9f8e4876ae5160f9446fc83c261c9317")
addappid(231336, 1, "7818a45db96315f2c3d25c7d37e60ed82b328961df03e49e95e0fc87a6ff1348")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(231340)
addappid(267580)
