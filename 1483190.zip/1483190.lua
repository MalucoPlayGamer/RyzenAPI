-- Lua provided by RyzenAPI
-- Game: Memory Lost

-- MAIN APPLICATION
addappid(1483190)
-- Game: addappid(1483190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483191, 1, "c5fdf8ae630789fcf4b3a4dbca845f462cb7e8144363e0110465566cead25ccf")
