-- Lua provided by RyzenAPI
-- Game: Game: Me and myself

-- MAIN APPLICATION
addappid(1207010)
-- Game: addappid(1207010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207011, 1, "81085417ee3f8cd3792acdff2a6dedaafc530299834c6a4d397929775419ae3e")
