-- Lua provided by SkyAPI 
-- Game: AppID 732810
addappid(732810)
addappid(732811, 1, "aa2e0693551c22e4058c45eddc73768d09bc6897fecaaede573746b1601f4eaa")
addappid(732812, 1, "9ea54cd5a04e2570aa85cd6c3d20411edb078af329fcbd2bc3ffa7fc89a23a02")
addappid(732813, 1, "5b37ac549e3d82669f657a705b0dc95440f1c3c9825ba3e74eca086d7f23012d")
addappid(2334980, 0, "2d417384939c2c9a8fe66ba5d6bb64beb1c2b88f692dacf55f1653a88dfc855c")
