-- Lua provided by RyzenAPI
-- Game: Echo Grotto

-- MAIN APPLICATION
addappid(705870)
-- Game: addappid(705870)

-- MAIN APP DEPOTS / PACKAGES
addappid(705871, 1, "d283fc3dc41815f9dd25bcb72e679d9848bc21d56d1008586ad6934243cf10cc")
