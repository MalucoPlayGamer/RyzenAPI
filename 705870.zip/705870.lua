-- Lua provided by SkyAPI 
-- Game: Echo Grotto
addappid(705870)
addappid(705871, 1, "d283fc3dc41815f9dd25bcb72e679d9848bc21d56d1008586ad6934243cf10cc")
