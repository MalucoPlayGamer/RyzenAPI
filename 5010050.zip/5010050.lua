-- Lua provided by RyzenAPI
-- Game: Questmonger

-- MAIN APPLICATION
addappid(5010050) -- Questmonger

-- MAIN APP DEPOTS / PACKAGES
addappid(5010051, 1, "de4b96638c8c0fa6972b851dfc3ba23a031f8eaa5bb714da92fd55bef77e585b") -- Depot 5010051

