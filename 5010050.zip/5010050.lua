-- 5010050's Lua and Manifest Created by Hubcap Manifest
-- Questmonger
-- Created: August 15, 2026 at 00:10:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5010050) -- Questmonger
-- MAIN APP DEPOTS
addappid(5010051, 1, "de4b96638c8c0fa6972b851dfc3ba23a031f8eaa5bb714da92fd55bef77e585b") -- Depot 5010051
setManifestid(5010051, "2373255091507242905", 743779323)