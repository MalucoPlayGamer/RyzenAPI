-- Lua provided by RyzenAPI
-- Game: 464070

-- MAIN APPLICATION
addappid(464070)
-- Game: addappid(464070)

-- MAIN APP DEPOTS / PACKAGES
addappid(464071, 1, "a9f5e77fc53669f99be554bce75663d941685abbec27b7446118b299cfbef5fc")
