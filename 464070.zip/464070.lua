-- Lua provided by RyzenAPI
-- Game: Diorama Battle of NINJA　虚拟3D世界 忍者之战

-- MAIN APPLICATION
addappid(464070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(464071, 1, "a9f5e77fc53669f99be554bce75663d941685abbec27b7446118b299cfbef5fc")

