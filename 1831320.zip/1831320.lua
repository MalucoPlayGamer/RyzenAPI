-- Lua provided by RyzenAPI
-- Game: Rescue Team: Power Eaters

-- MAIN APPLICATION
addappid(1831320)
-- Game: addappid(1831320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831321, 1, "a0e15e6350a24013505d93e94e678c88b65d6d889c79c96708f50d020d9a12da")
