-- Lua provided by RyzenAPI
-- Game: My Friend Peppa Pig

-- MAIN APPLICATION
addappid(1635590)
addappid(1840890)
-- Game: addappid(1635590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635591, 1, "ed4326a44d4a8aa99c822d8ff8e2adb9ef9befbb781b0d39172b1757d69cb66b")
