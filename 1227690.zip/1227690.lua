-- Lua provided by RyzenAPI
-- Game: Game: Severed Steel

-- MAIN APPLICATION
addappid(1227690)
-- Game: addappid(1227690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227691, 1, "3be8c18f70577f9b144fe8d86509526469d04d1158eadd101ab884027342f019")
addappid(1754230, 0, "6d97c56331877a75aae2999186d701176e3b67930cfbb382fee4f5af3627cc94")
