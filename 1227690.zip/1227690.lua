-- Lua provided by RyzenAPI
-- Game: Severed Steel

-- MAIN APPLICATION
addappid(1227690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227691, 1, "3be8c18f70577f9b144fe8d86509526469d04d1158eadd101ab884027342f019")
addappid(1754230, 0, "6d97c56331877a75aae2999186d701176e3b67930cfbb382fee4f5af3627cc94")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
