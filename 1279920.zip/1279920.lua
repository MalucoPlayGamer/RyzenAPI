-- Lua provided by SkyAPI 
-- Game: Cobra Kai: The Karate Kid Saga Continues
addappid(1279920)
addappid(1279921, 1, "9980fa112d6a19b2f5c115be40334f4a64649bc8c1ff584cdc8c66bbc1578bec")
