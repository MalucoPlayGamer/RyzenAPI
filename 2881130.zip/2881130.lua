-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 Soft Cuddly Girl GP-01fb

-- MAIN APPLICATION
addappid(2881130)
-- Game: addappid(2881130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881131, 1, "cf37577e65b7cb5c28e2d66ee9b42f7d0d00ace3863c58eac8cb105ff5f64b13")
