-- Lua provided by RyzenAPI
-- Game: Game: AppID 1037690

-- MAIN APPLICATION
addappid(1037690)
-- Game: addappid(1037690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037691, 1, "0a8326d941c6db187458e8dd3733673e15fd42d9a5c55c096d5cb0da74e065a7")
