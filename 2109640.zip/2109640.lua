-- Lua provided by RyzenAPI
-- Game: Cross Concerto

-- MAIN APPLICATION
addappid(2109640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109641, 1, "7529321148582795d5ef0f9e07e58867e0d2260cb76001824a3a2be5b06c836d")
addappid(2109642, 1, "243302d9c5ea6d73bf9dc265f84fc7b18395e1a6f11da9841f8c0c03b7098201")
addappid(2109643, 1, "2f2c337dee0a67c05d394a4af975a03f674f374a854fed62957e87dd4310d259")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
