-- Lua provided by RyzenAPI
-- Game: 3088440

-- MAIN APPLICATION
addappid(3088440)
-- Game: addappid(3088440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088441, 1, "68fe26605c52a9ce3d5c749045d4d9b1d243eb8540328d1d7cf486a34ea9bb99")
