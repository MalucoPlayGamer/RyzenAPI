-- Lua provided by RyzenAPI
-- Game: Behind The Backrooms

-- MAIN APPLICATION
addappid(3088440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088441, 1, "68fe26605c52a9ce3d5c749045d4d9b1d243eb8540328d1d7cf486a34ea9bb99")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
