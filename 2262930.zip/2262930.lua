-- Lua provided by RyzenAPI
-- Game: Bombe

-- MAIN APPLICATION
addappid(2262930)
-- Game: addappid(2262930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262932,0,"a4988f49f480c7124865b393dbd99b5d8ee316574f6d4168ee3fb0d5063bcff4")
