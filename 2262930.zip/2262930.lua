-- Lua provided by RyzenAPI
-- Game: Bombe

-- MAIN APPLICATION
addappid(2262930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262932,0,"a4988f49f480c7124865b393dbd99b5d8ee316574f6d4168ee3fb0d5063bcff4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
