-- Lua provided by RyzenAPI
-- Game: Zombie Hunter, Inc.

-- MAIN APPLICATION
addappid(387130)
-- Game: addappid(387130)

-- MAIN APP DEPOTS / PACKAGES
addappid(387131, 1, "55d72f24e136548e7aba66cd185c472ad3f3f554defe786d656a1d732db0546a")
