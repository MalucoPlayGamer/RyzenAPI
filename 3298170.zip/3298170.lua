-- Lua provided by RyzenAPI
-- Game: Game: S.E.X. Z.O.N.E. ☢️

-- MAIN APPLICATION
addappid(3298170)
-- Game: addappid(3298170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298171, 1, "c97c78d0a28de86914f3a202160326f8af316958da81877faf0c496319be7111")
