-- Lua provided by RyzenAPI
-- Game: Everything is Crab

-- MAIN APPLICATION
addappid(3526710) -- Everything is Crab
addappid(4540950) -- Everything is Crab - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(3526711, 1, "ed639283b231e8c9cf3f2809bafb053eca94f9edd0d68f2678b1b9ecbc100e83") -- Depot 3526711

