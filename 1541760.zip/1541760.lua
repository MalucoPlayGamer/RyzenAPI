-- Lua provided by RyzenAPI 
-- Game: AppID 1541760
addappid(1541760)
addappid(1541761, 1, "f2b1c1243a0e2de7bdd53a3fb5fcd6c8e559c86de7126b017ab1b0e126b348a7")
