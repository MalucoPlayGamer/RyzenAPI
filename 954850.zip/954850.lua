-- Lua provided by RyzenAPI
-- Game: Kerbal Space Program 2

-- MAIN APPLICATION
addappid(954850)

-- MAIN APP DEPOTS / PACKAGES
addappid(954851, 1, "b3d85137cd7daf7ba9a3a458cc4e30a3995a66db4127d1b50a4d62d28b612975")
