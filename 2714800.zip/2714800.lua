-- Lua provided by RyzenAPI
-- Game: Peeping Dorm Manager ArtBook

-- MAIN APPLICATION
addappid(2714800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2714801, 1, "5e83179df14d7e1a1ac7b82df9a72198fe26a5b6edfb1faa9bb8778059f86eda")
