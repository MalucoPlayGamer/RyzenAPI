-- Lua provided by RyzenAPI
-- Game: PuppetShow™: Souls of the Innocent Collector's Edition

-- MAIN APPLICATION
addappid(631260)

-- MAIN APP DEPOTS / PACKAGES
addappid(631261,0,"cb6cff5ca494e857fb34cf435ced71df9c96feb18d979effd37531cfb994ed3a")

