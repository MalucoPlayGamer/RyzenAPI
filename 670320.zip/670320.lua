-- Lua provided by RyzenAPI
-- Game: 670320

-- MAIN APPLICATION
addappid(670320)
-- Game: addappid(670320)

-- MAIN APP DEPOTS / PACKAGES
addappid(670321, 1, "c3ea17adf87fc4358f288fef0ef132ffa438fb981d0b6c03168c3691a5beeebf")
