-- Lua provided by RyzenAPI 
-- Game: PAPA'S TIME MACHINE
addappid(670320)
addappid(670321, 1, "c3ea17adf87fc4358f288fef0ef132ffa438fb981d0b6c03168c3691a5beeebf")
