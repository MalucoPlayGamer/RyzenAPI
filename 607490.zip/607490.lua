-- Lua provided by RyzenAPI
-- Game: HAUNTED: Halloween '86

-- MAIN APPLICATION
addappid(607490)

-- MAIN APP DEPOTS / PACKAGES
addappid(607492,0,"3c7a09baea84bb3892ebf9080f8ffe40591e4b1f25582cd19b674569d6183edd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
