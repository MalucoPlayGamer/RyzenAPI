-- Lua provided by RyzenAPI
-- Game: Sins of a Solar Empire®: Rebellion - Original Soundtrack

-- MAIN APPLICATION
addappid(228600)
-- Game: addappid(228600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228602,0,"41938cc942d44e4e60a06858c41d8284e120d1e67a0ce4968e026816edece8db")
addappid(228603,0,"c4eae53929cdf2082a211f199fa94930cc513b9a10e58a8382b08158c85ac28d")
