-- Lua provided by RyzenAPI
-- Game: Memory Puzzle - Sexy Fairies

-- MAIN APPLICATION
addappid(1852760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852761, 1, "d9779facad24e084802928282d148fb18a8df74faa02af7f7813779d25616a2c")
addappid(1858870, 0, "c4b7b35fe4c79d1d905d17fdbe4f7405f906c4497274ae2c06144fffd677c904")

