-- Lua provided by RyzenAPI 
-- Game: Moot District
addappid(992040)
addappid(992041, 1, "ca535dce298d95bfd8a2a8229616089d175e108d92658cfdff3d31e50f2fcbc9")
