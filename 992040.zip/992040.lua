-- Lua provided by RyzenAPI
-- Game: Game: Moot District

-- MAIN APPLICATION
addappid(992040)
-- Game: addappid(992040)

-- MAIN APP DEPOTS / PACKAGES
addappid(992041, 1, "ca535dce298d95bfd8a2a8229616089d175e108d92658cfdff3d31e50f2fcbc9")
