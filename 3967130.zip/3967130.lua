-- Lua provided by RyzenAPI
-- Game: Wild West Miner Simulator

-- MAIN APPLICATION
addappid(3967130) -- Wild West Miner Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(3967131, 1, "e6bfa693bd107a9e47308beabbb6f36993804fc6324b58c1074a51e3c007b60e") -- Depot 3967131

