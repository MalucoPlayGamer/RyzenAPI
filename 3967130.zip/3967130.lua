-- 3967130's Lua and Manifest Created by Hubcap Manifest
-- Wild West Miner Simulator
-- Created: August 13, 2026 at 10:30:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3967130) -- Wild West Miner Simulator
-- MAIN APP DEPOTS
addappid(3967131, 1, "e6bfa693bd107a9e47308beabbb6f36993804fc6324b58c1074a51e3c007b60e") -- Depot 3967131
setManifestid(3967131, "3200802314899834140", 8139370985)