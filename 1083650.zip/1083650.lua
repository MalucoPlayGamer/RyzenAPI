-- Lua provided by RyzenAPI
-- Game: Super Naughty Maid

-- MAIN APPLICATION
addappid(1083650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083651, 1, "ca80d17760939245912f0c05eb0e420629c548a45862d3fabffdd7d5b613955e")
