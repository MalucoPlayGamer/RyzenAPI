-- Lua provided by SkyAPI 
-- Game: AppID 1880350
addappid(1880350)
addappid(1880351, 1, "e6f1b416ed4386dc07ce601b9c9724c8677a0a1112267d8369778142aba1aa13")
