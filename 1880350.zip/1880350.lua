-- Lua provided by RyzenAPI
-- Game: Yokai Art: Night Parade of One Hundred Demons Demo

-- MAIN APPLICATION
addappid(1880350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880351, 1, "e6f1b416ed4386dc07ce601b9c9724c8677a0a1112267d8369778142aba1aa13")
