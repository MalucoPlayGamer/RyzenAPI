-- Lua provided by RyzenAPI
-- Game: Chinese style school

-- MAIN APPLICATION
addappid(3578710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3578711, 1, "1e97c84479256425638d86f622caadf18ae6eb7304fcd60fcb788b9bdd761cd3")

