-- Lua provided by RyzenAPI
-- Game: Chinese style school

-- MAIN APPLICATION
addappid(3578710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3578711, 1, "1e97c84479256425638d86f622caadf18ae6eb7304fcd60fcb788b9bdd761cd3")

