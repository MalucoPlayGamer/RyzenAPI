-- Lua provided by RyzenAPI
-- Game: 1529010

-- MAIN APPLICATION
addappid(1529010)
-- Game: addappid(1529010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529011, 1, "941c294d242272a3ed18e3c815e15ffad3193e383d3a1ab416f64fda6890a5cd")
