-- Lua provided by RyzenAPI
-- Game: Game: 云玩家:口口

-- MAIN APPLICATION
addappid(2513090)
-- Game: addappid(2513090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2513091, 1, "82318b2bcbf2b140527cf3cb98322f76768d33063c8f11e59e4eb53464eb523e")
