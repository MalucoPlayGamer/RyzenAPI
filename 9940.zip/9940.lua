-- Lua provided by RyzenAPI
-- Game: Blade Kitten

-- MAIN APPLICATION
addappid(9940)
addappid(228983)
addappid(228990)
addappid(357171)
-- Game: addappid(9940)

-- MAIN APP DEPOTS / PACKAGES
addappid(9941, 1, "eae5f71dc145afd9d2d2b4fde95c96444aa2429888164cb95faf3cdb38360a94")
addappid(300120, 0, "6f3612f07d3196a1edb58a08d7d7d7d84dbe382e902de0ddb019a7ffdda74244")
addappid(357170, 0, "de627c232ebc3c2705bd1ce85b8557e8230a19c7f2944a90b92c13fe22b16162")
