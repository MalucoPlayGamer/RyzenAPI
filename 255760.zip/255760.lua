-- Lua provided by RyzenAPI
-- Game: PAC-MAN MUSEUM Demo

-- MAIN APPLICATION
addappid(228990)
addappid(255760)
addappid(255761)
-- Game: addappid(255760)

-- MAIN APP DEPOTS / PACKAGES
addappid(236471,0,"c718e845a54d4b808ebf687f05009ffc74970f708bc597a9b5279bafe16115ad")
