-- Lua provided by SkyAPI 
-- Game: AppID 1697860
addappid(1697860)
addappid(1697861, 1, "66fdcc429fcc9f229ab94d1afa8465dd33605d3293d3f7a4b2a234f5657e5092")
