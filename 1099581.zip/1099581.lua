-- Lua provided by RyzenAPI
-- Game: Beat Saber - Imagine Dragons - "Natural"

-- MAIN APPLICATION
addappid(1099581)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099581,0,"f34871b9b43f5092c20f76aeca3609872db33fb28ebbf43018d8e0cf74d791d4")

