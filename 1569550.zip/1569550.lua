-- Lua provided by RyzenAPI
-- Game: 1569550

-- MAIN APPLICATION
addappid(1569550)
-- Game: addappid(1569550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569551, 1, "fa2dde7f49e11a01b8007f0d7b43c05cf90401d83542a52fa692680c7272e82a")
