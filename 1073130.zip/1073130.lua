-- Lua provided by RyzenAPI
-- Game: Game: AppID 1073130

-- MAIN APPLICATION
addappid(1073130)
-- Game: addappid(1073130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073131, 1, "472330d255083c968cea0a5f0caba528e88ce843485637490ced90fd30934102")
