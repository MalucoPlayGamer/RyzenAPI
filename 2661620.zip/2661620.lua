-- Lua provided by RyzenAPI
-- Game: Love in Login

-- MAIN APPLICATION
addappid(2661620)
addappid(3203660)
addappid(3203670)
addappid(3203680)
addappid(3203690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661621, 1, "a9d63ca835d39699956ec59274a2669953e5e45303ebe5e3578c60a8ae525c18")
