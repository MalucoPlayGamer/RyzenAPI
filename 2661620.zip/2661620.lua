-- Lua provided by RyzenAPI
-- Game: Game: AppID 2661620

-- MAIN APPLICATION
addappid(2661620)
-- Game: addappid(2661620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661621, 1, "a9d63ca835d39699956ec59274a2669953e5e45303ebe5e3578c60a8ae525c18")
