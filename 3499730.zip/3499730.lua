-- Lua provided by RyzenAPI
-- Game: addappid(3499730)

-- MAIN APPLICATION
addappid(3499730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499731, 1, "cd998086d0dd6ba1bf568045d6ce66408de36a062b02d41e5715e6c75d60d07b")
