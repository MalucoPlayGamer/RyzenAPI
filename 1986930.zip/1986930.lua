-- Lua provided by RyzenAPI
-- Game: Game: Elspell

-- MAIN APPLICATION
addappid(1986930)
-- Game: addappid(1986930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986931, 1, "384aca5f2cfef2218d7dfa3423d066b0ac7f42c0b087c08f3f5dfa2fbb84af52")
