-- Lua provided by RyzenAPI
-- Game: 001 Game Creator Demo

-- MAIN APPLICATION
addappid(515880)

-- MAIN APP DEPOTS / PACKAGES
addappid(347401,0,"3b7940247a68bcd03fe6fea16b52132e6250e07b85edfef9405a0c795602e92b")
