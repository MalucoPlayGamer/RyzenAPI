-- Lua provided by RyzenAPI
-- Game: Voodoo Vince: Remastered

-- MAIN APPLICATION
addappid(545980)

-- MAIN APP DEPOTS / PACKAGES
addappid(545981, 1, "c43569944424f46704b691696abf45aeb24af8065c15990eddbe0acfb24a3609")

