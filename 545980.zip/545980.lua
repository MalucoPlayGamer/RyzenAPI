-- Lua provided by RyzenAPI
-- Game: Voodoo Vince: Remastered

-- MAIN APPLICATION
addappid(545980)

-- MAIN APP DEPOTS / PACKAGES
addappid(545981, 1, "c43569944424f46704b691696abf45aeb24af8065c15990eddbe0acfb24a3609")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
