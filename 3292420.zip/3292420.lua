-- Lua provided by RyzenAPI
-- Game: AppID 3292420

-- MAIN APPLICATION
addappid(3292420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3292421, 1, "cfe7ed63bed06a12b6fcbdc7f5a88a90bab781f455d95b5598e01656b51af48a")
