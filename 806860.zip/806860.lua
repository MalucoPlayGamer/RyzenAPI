-- Lua provided by RyzenAPI
-- Game: They Are Hundreds

-- MAIN APPLICATION
addappid(806860)
-- Game: addappid(806860)

-- MAIN APP DEPOTS / PACKAGES
addappid(806862,0,"1e62f68c690376e9088d219838d3b79304011939c90d7c0a256fcb0e165d3311")
