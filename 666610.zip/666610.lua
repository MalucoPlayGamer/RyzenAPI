-- Lua provided by RyzenAPI
-- Game: 666610

-- MAIN APPLICATION
addappid(666610)
-- Game: addappid(666610)

-- MAIN APP DEPOTS / PACKAGES
addappid(666611, 1, "4bd82fb2b44fea728aa1ce65940b711987e7fde5ed9dfc0ed9c96262a400171f")
