-- Lua provided by RyzenAPI
-- Game: Endless ATC

-- MAIN APPLICATION
addappid(666610)

-- MAIN APP DEPOTS / PACKAGES
addappid(666611, 1, "4bd82fb2b44fea728aa1ce65940b711987e7fde5ed9dfc0ed9c96262a400171f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
