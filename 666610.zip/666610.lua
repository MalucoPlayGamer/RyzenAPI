-- Lua provided by RyzenAPI 
-- Game: Endless ATC
addappid(666610)
addappid(666611, 1, "4bd82fb2b44fea728aa1ce65940b711987e7fde5ed9dfc0ed9c96262a400171f")
