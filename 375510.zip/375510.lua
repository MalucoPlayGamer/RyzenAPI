-- Lua provided by RyzenAPI
-- Game: addappid(375510)

-- MAIN APPLICATION
addappid(375510)

-- MAIN APP DEPOTS / PACKAGES
addappid(375511, 1, "0022d6193f318b75c7cd28d06f4af31701e6cd2eaad9f47fdc23e825aff90761")
