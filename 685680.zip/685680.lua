-- Lua provided by RyzenAPI
-- Game: 685680

-- MAIN APPLICATION
addappid(685680)
-- Game: addappid(685680)

-- MAIN APP DEPOTS / PACKAGES
addappid(685681, 1, "92958d2c169327a2a9774f61efb357e01faf772c9da59509ff5316e670ad3af0")
