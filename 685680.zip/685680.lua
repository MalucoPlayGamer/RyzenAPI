-- Lua provided by RyzenAPI
-- Game: Sakura Gamer

-- MAIN APPLICATION
addappid(685680)

-- MAIN APP DEPOTS / PACKAGES
addappid(685681, 1, "92958d2c169327a2a9774f61efb357e01faf772c9da59509ff5316e670ad3af0")
