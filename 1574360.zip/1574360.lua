-- Lua provided by RyzenAPI
-- Game: Uncharted Waters Origin

-- MAIN APPLICATION
addappid(1574360)

