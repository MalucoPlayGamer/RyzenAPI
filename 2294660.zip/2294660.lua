-- Lua provided by RyzenAPI
-- Game: Game: The Quinfall

-- MAIN APPLICATION
addappid(2294660)
-- Game: addappid(2294660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294661, 1, "39cbd76774d7cd7e3a7638344169ac77056c44361a66db94cb7e59fac501c576")
