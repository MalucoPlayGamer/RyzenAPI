-- Lua provided by RyzenAPI
-- Game: Mugen RPG

-- MAIN APPLICATION
addappid(2344570)
-- Game: addappid(2344570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2344571, 1, "0c7f5616b26620eb3c7f102b5af03947a450445ae8c1968b683a3597ef5f8ead")
