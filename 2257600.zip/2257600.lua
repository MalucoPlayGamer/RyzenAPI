-- Lua provided by RyzenAPI
-- Game: 2257600

-- MAIN APPLICATION
addappid(2257600)
-- Game: addappid(2257600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257601, 1, "528768e39ba1553d40c64b94f4c5a91c5f4fff295e8abaea23360302363218e2")
