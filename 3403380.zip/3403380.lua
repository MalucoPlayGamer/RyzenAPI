-- Lua provided by RyzenAPI
-- Game: Sisyphus The Game

-- MAIN APPLICATION
addappid(3403380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3403381, 1, "81493299ac51cccaad63ed18008be99c269aabc266d4ba8291e59b7816554d66")

