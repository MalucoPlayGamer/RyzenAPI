-- Lua provided by RyzenAPI
-- Game: Lords of the Realm

-- MAIN APPLICATION
addappid(254920)
-- Game: addappid(254920)

-- MAIN APP DEPOTS / PACKAGES
addappid(254921, 1, "0afd4a46b595f8f7c4d139decb2c8c560096f503b59c707fad519f2a8cb14e3d")
