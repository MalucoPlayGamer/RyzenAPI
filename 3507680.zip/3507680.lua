-- Lua provided by RyzenAPI 
-- Game: Stone 4 Souls
addappid(3507680)
addappid(3507681, 1, "8ec772263dd585f5361df441e55341b44736ae1bd0ab6819a12f7bd3f75e3f35")
