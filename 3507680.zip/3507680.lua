-- Lua provided by RyzenAPI
-- Game: Stone 4 Souls

-- MAIN APPLICATION
addappid(3507680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3507681, 1, "8ec772263dd585f5361df441e55341b44736ae1bd0ab6819a12f7bd3f75e3f35")

