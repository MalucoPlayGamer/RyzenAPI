-- Lua provided by RyzenAPI
-- Game: 狩魔之旅：万界仙踪

-- MAIN APPLICATION
addappid(4486210)

-- MAIN APP DEPOTS / PACKAGES
addappid(4486211,0,"e2ad8b7cc6980b6f1cc1194dbfd5183fb34c7dff2f7ecfff51f5f64688146b5e")

