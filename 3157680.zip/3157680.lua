-- Lua provided by RyzenAPI
-- Game: Card of Legend

-- MAIN APPLICATION
addappid(3157680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3157681, 1, "c33b29b176ff21c2969e945942105e636107b7229801716fdb95683df17cfc04")

