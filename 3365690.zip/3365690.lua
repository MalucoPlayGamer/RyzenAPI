-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VII REMAKE INTERGRADE Original Soundtrack

-- MAIN APPLICATION
addappid(3365690)
-- Game: addappid(3365690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365691, 1, "595b8379fecbb70f577632cd4551268aae9b01dffbf90fd224950d8d884a3ce6")
