-- Lua provided by RyzenAPI
-- Game: Game: Fallen Lean

-- MAIN APPLICATION
addappid(3166140)
-- Game: addappid(3166140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3166141, 1, "465d1cf0d5d96a125e4949619a8510b6123cc95c6154ed987e9a73922807dd80")
