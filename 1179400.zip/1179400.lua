-- Lua provided by RyzenAPI
-- Game: addappid(1179400)

-- MAIN APPLICATION
addappid(1179400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179401, 1, "fea0d07e4946bb7008e231ea8243df50cd22609f3c4c5a439837ff5f79cb6ab4")
