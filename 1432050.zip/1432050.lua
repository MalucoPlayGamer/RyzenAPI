-- Lua provided by RyzenAPI
-- Game: addappid(1432050)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1432050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432052,0,"6b92b195e94eda5f196d54c2c8c92900e8acbd81445885e66b5490772ba61a23")
