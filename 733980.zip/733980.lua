-- Lua provided by RyzenAPI
-- Game: addappid(733980)

-- MAIN APPLICATION
addappid(733980)

-- MAIN APP DEPOTS / PACKAGES
addappid(733981, 1, "c447afbb812fc29a10eb59052624d8cc1ce0c43336f9ae4004d2d8bbbfbda7db")
