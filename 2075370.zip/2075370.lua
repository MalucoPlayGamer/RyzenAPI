-- Lua provided by RyzenAPI
-- Game: Game: Old Tunnel

-- MAIN APPLICATION
addappid(2075370)
-- Game: addappid(2075370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075371, 1, "84d0669bc8d1dd62e4df3020fe1b300c1330e5fcddb06477d7cf7b172d943430")
