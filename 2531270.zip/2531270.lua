-- Lua provided by RyzenAPI
-- Game: Game: AppID 2531270

-- MAIN APPLICATION
addappid(2531270)
-- Game: addappid(2531270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531271, 1, "2aa446e36567ee3e4864a36c8686260df275488cb3a19527c47bb617e34f5a00")
