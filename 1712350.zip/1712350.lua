-- Lua provided by RyzenAPI 
-- Game: Riven
addappid(1712350)
addappid(1712351, 1, "0a9409019faf1d8890bd1c24f3c848bdcc9fdb2c09f391963b4dda9a9d3e4168")
addappid(1712352, 1, "92d88dd07fd53407c32cf59987cf9d51c367b48d5f51796b0006c19e1bf1261c")
