-- Lua provided by RyzenAPI
-- Game: Riven

-- MAIN APPLICATION
addappid(1712350)
addappid(3060810)
addappid(3060820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1712351, 1, "0a9409019faf1d8890bd1c24f3c848bdcc9fdb2c09f391963b4dda9a9d3e4168")
addappid(1712352, 1, "92d88dd07fd53407c32cf59987cf9d51c367b48d5f51796b0006c19e1bf1261c")

