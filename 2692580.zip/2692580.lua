-- Lua provided by RyzenAPI
-- Game: Scary Mine VR

-- MAIN APPLICATION
addappid(2692580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692581,0,"271c116e062f773bbe9ddcfaa8cdeb777ac5e7823e78b58e5a56943a548e881f")

