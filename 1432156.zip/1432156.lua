-- Lua provided by RyzenAPI
-- Game: 1432156

-- MAIN APPLICATION
addappid(1432156)
-- Game: addappid(1432156)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432156,0,"c1526a5d6378eea19ac7a5bef6a87c028f23a058e1c5d20ae14369522bf2f310")
