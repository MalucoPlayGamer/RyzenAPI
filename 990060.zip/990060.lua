-- Lua provided by RyzenAPI
-- Game: War Online: Pacific

-- MAIN APPLICATION
addappid(990060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(990061, 1, "bc182df9b0513fa1a886342bd94b4ce2b58065f0ebe2d85c39a739a698659f59")
