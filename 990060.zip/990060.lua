-- Lua provided by RyzenAPI 
-- Game: AppID 990060
addappid(990060)
addappid(990061, 1, "bc182df9b0513fa1a886342bd94b4ce2b58065f0ebe2d85c39a739a698659f59")
