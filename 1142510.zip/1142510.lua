-- Lua provided by RyzenAPI
-- Game: Cucumber Defense VR

-- MAIN APPLICATION
addappid(1142510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1142511, 1, "25b3ab5d431eea92e6d6a0bde96b7f0e2480a825acdd59211ab41cf6718ab6e3")
