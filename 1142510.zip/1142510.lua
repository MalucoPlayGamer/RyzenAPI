-- Lua provided by RyzenAPI
-- Game: addappid(1142510)

-- MAIN APPLICATION
addappid(1142510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142511, 1, "25b3ab5d431eea92e6d6a0bde96b7f0e2480a825acdd59211ab41cf6718ab6e3")
