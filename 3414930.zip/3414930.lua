-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Taboo Sisters

-- MAIN APPLICATION
addappid(3414930)
-- Game: addappid(3414930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3414931, 1, "685cd547ba81807cad4da8344f21007f14027e3f0db3496992b9cc881446e779")
