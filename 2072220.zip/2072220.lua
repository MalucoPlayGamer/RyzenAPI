-- Lua provided by SkyAPI 
-- Game: AppID 2072220
addappid(2072220)
addappid(2072221, 1, "f5f36dad772f8424bea329fbf5d69d5052c7fc8c5d63d24b4fa7d16f527b2e2d")
