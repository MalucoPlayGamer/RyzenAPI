-- Lua provided by RyzenAPI
-- Game: 2072220

-- MAIN APPLICATION
addappid(2072220)
-- Game: addappid(2072220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072221, 1, "f5f36dad772f8424bea329fbf5d69d5052c7fc8c5d63d24b4fa7d16f527b2e2d")
