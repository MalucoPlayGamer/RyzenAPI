-- Lua provided by RyzenAPI
-- Game: 1398720

-- MAIN APPLICATION
addappid(1398720)
addappid(1711821)
addappid(1711822)
-- Game: addappid(1398720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398721, 1, "901ae5f718f3af7f31956a95a6372e92a03ef4451cfa1b17f2bd8daedff806a7")
addappid(1711820, 0, "9092fb22146c5b37988430a5aa27ee1886f84a01f2d751b719cff3f22a67db65")
