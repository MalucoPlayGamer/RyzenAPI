-- Lua provided by RyzenAPI
-- Game: PHAGEBORN online card game

-- MAIN APPLICATION
addappid(1037990)
addappid(1244030)
addappid(2502440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1037991, 1, "003c538dba097cd3b322969887a9a37f0002166032a1d98e28424b7bb24cfcdf")

