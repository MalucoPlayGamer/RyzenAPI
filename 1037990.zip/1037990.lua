-- Lua provided by RyzenAPI 
-- Game: AppID 1037990
addappid(1037990)
addappid(1037991, 1, "003c538dba097cd3b322969887a9a37f0002166032a1d98e28424b7bb24cfcdf")
addappid(1244030)
