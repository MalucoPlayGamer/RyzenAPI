-- Lua provided by RyzenAPI
-- Game: AppID 1037990

-- MAIN APPLICATION
addappid(1037990)
addappid(1244030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037991, 1, "003c538dba097cd3b322969887a9a37f0002166032a1d98e28424b7bb24cfcdf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2502440)
