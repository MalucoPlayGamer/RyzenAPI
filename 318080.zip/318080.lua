-- Lua provided by RyzenAPI 
-- Game: AppID 318080
addappid(318080)
addappid(318081, 1, "497dd8eabca7d0bae0379dc77fb7314e97a3d0853921aef9803329e008e8011c")
