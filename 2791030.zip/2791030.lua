-- Lua provided by RyzenAPI
-- Game: 后室重生Backrooms Rebirth

-- MAIN APPLICATION
addappid(2791030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791031, 1, "c097acd5ede1b91572956119c3c8cd88e31840ad2c4544b23c647546bb11fdec")

