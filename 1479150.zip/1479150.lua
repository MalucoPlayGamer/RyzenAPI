-- Lua provided by RyzenAPI
-- Game: Aeon Drive: Tournament

-- MAIN APPLICATION
addappid(1479150)
-- Game: addappid(1479150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479151, 1, "603dba0f168011dd98faa2defd2e484182cc5ab011304e0e2e412bd5aa58cff9")
