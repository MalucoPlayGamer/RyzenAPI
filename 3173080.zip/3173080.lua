-- Lua provided by RyzenAPI
-- Game: Game: AppID 3173080

-- MAIN APPLICATION
addappid(3173080)
-- Game: addappid(3173080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173081, 1, "a83c0b1332a3c6636040422666ae9aa49ed0ea41fba0144650ddd9c3bf532c53")
