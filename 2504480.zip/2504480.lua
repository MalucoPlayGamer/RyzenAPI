-- Lua provided by RyzenAPI
-- Game: Indigo Park: Chapter 1

-- MAIN APPLICATION
addappid(2504480)
addappid(3722130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2504481, 1, "ef0b248a2f1c7fa262566d9bb4f241e1b72cd390b5966a2085ea7f4cdb744749")

