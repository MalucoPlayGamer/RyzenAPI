-- Lua provided by RyzenAPI
-- Game: Indigo Park: Chapter 1

-- MAIN APPLICATION
addappid(2504480)
addappid(3722130)
-- Game: addappid(2504480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504481, 1, "ef0b248a2f1c7fa262566d9bb4f241e1b72cd390b5966a2085ea7f4cdb744749")
