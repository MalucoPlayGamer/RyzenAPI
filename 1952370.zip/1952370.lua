-- Lua provided by RyzenAPI
-- Game: Oblivion Override

-- MAIN APPLICATION
addappid(1952370)
-- Game: addappid(1952370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952371, 1, "ce80cd97e0c733f0417e2e358d8d5f9eeeac30ecb7abe74214cbd1636ba7e5eb")
addappid(1952372, 1, "176cb0d8dbe9fe036346cd14e5f050ebd4d6fa979400736c877a56ec0b15427e")
