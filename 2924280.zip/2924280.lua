-- Lua provided by RyzenAPI
-- Game: addappid(2924280)

-- MAIN APPLICATION
addappid(2924280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924281, 1, "991d763b437b133f80ea5225f79ab8fc2e9eaf560efc7c71f3b0235b9169c638")
