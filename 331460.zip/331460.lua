-- Lua provided by RyzenAPI
-- Game: ROOMS: The Toymaker's Mansion

-- MAIN APPLICATION
addappid(331460)

-- MAIN APP DEPOTS / PACKAGES
addappid(331461, 1, "351b8b459cd20f9869afbffc7306bb706b5aab7c110ab6d3c094f7e5f1ca433d")
addappid(331462, 1, "29e547168fa3cb2e71806464a8a76645fb6314cf642edcb89f1aee9f687b587c")
addappid(331463, 1, "dfb240b12feeb3af3c42d27b69f8239ac262c33189194ba1f98217b0a6b2f4be")
addappid(331466, 1, "3aea070e5790a35060f5e694ac9c98664efe344e5e0c12943c9e300d60475f99")
addappid(374750, 0, "82fab962226e97b7ea0919e3c71c3f5dd0738fbfdd223ab464abada85e11ca2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
