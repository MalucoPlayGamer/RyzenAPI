-- Lua provided by RyzenAPI
-- Game: NINJA GAIDEN 4

-- MAIN APPLICATION
addappid(2627260)
addappid(3717100)
addappid(3717110)
addappid(4191490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2627261, 1, "1dbbfa4a1302ac713af5d572bd94e7d0708ba581ca184c4124588ff3fdc06481")

