-- Lua provided by RyzenAPI
-- Game: 1223680

-- MAIN APPLICATION
addappid(1223680)
-- Game: addappid(1223680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223681, 1, "4b8de1795b0f4788ed593f2098838a67aa43125f240982d2cb438ed17cfb72d0")
