-- Lua provided by RyzenAPI
-- Game: 华夏五千年

-- MAIN APPLICATION
addappid(2220590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2220591, 1, "366a432822ccb1d529fb55988c9e2bfbc0fe51f80dae71967c48158c2729b57c")

