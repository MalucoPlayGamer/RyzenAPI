-- Lua provided by RyzenAPI
-- Game: Game: 华夏五千年

-- MAIN APPLICATION
addappid(2220590)
-- Game: addappid(2220590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220591, 1, "366a432822ccb1d529fb55988c9e2bfbc0fe51f80dae71967c48158c2729b57c")
