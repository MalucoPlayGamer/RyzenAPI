-- Lua provided by SkyAPI 
-- Game: AppID 2414860
addappid(2414860)
addappid(2414861, 1, "db7d28ad196180b35c4ab6df6a07af22e5e288c4aef124da4fb745a4793fb2f9")
