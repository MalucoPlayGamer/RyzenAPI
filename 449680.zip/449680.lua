-- Lua provided by RyzenAPI
-- Game: 449680

-- MAIN APPLICATION
addappid(449680)
addappid(459240)
-- Game: addappid(449680)

-- MAIN APP DEPOTS / PACKAGES
addappid(449681, 1, "30e511a8656ee9cdc64243952cf8f2b4440a4b991f13b2d27cd2b2237373b8e9")
