-- Lua provided by RyzenAPI
-- Game: AppID 339110

-- MAIN APPLICATION
addappid(339110)

-- MAIN APP DEPOTS / PACKAGES
addappid(339111, 1, "4c9af0314111e20721f8d50efe4b5a55db4ecd885ef805b42ba45ccdab525627")
