-- Lua provided by RyzenAPI
-- Game: Call of Duty: Black Ops - Rezurrection Mac Edition

-- MAIN APPLICATION
addappid(214649)

-- MAIN APP DEPOTS / PACKAGES
addappid(214649,0,"7aa1998611367715c053d2f57dcd29ad635b6f7a1abfb012bf95e3ec914974ce")
