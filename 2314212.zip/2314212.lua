-- Lua provided by RyzenAPI
-- Game: METAL GEAR SOLID - Master Collection Version European Pack

-- MAIN APPLICATION
addappid(2314212)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314212,0,"c2905c5640fde8855cb314b8a55650eb6625c631a1047fca98dff7a43125b691")

