-- Lua provided by RyzenAPI
-- Game: Romance of the Three Kingdoms XII with Power Up Kit

-- MAIN APPLICATION
addappid(628080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(628081, 1, "e4820793439d1bfe70bb28b37b282fb20767a29cf691ddf9160bd9fb7247db63")
addappid(628082, 1, "33c6f8d486577c96c0074817d091f196b2fc2eb88226fa4a524c6fcf870a74cc")

