-- Lua provided by RyzenAPI 
-- Game: AppID 681100
addappid(681100)
addappid(681101, 1, "11d7fb7a3e895f392f0f9dbd3254296ba21c3f7a5a69e93e9ec8478d7e2fed5a")
addappid(691950, 0, "3413414620e54c0629ceac00cc549641476350c3f06510dc5180103c8f2364d2")
