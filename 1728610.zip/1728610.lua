-- Lua provided by RyzenAPI
-- Game: Beyond The Darkness

-- MAIN APPLICATION
addappid(1728610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1728611, 1, "b15036aa0f8ed11ec0def673887aea7ed7337a2223c7c9ac91366b70b4e4d5b6")

