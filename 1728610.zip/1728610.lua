-- Lua provided by RyzenAPI 
-- Game: Beyond The Darkness
addappid(1728610)
addappid(1728611, 1, "b15036aa0f8ed11ec0def673887aea7ed7337a2223c7c9ac91366b70b4e4d5b6")
