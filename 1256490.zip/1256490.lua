-- Lua provided by RyzenAPI
-- Game: Othello Let's Go

-- MAIN APPLICATION
addappid(1256490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1256491, 1, "cab5c0bb240a5219abb549964b0aec5a1dfcc04d1902e7b9f918241f66c578c8")
addappid(1256492, 1, "d9b7f59fa9c610dbf8620e60de5f8a9a369c2a7b82e4259f45fbe15b76d23030")
