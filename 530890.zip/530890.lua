-- Lua provided by RyzenAPI
-- Game: Haydee

-- MAIN APPLICATION
addappid(530890)

-- MAIN APP DEPOTS / PACKAGES
addappid(530891, 1, "5500145de28bdb917d68bb5dee5a681fb54fc9acb56249c6e35cf390273b6b8f")
