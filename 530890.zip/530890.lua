-- Lua provided by RyzenAPI
-- Game: Haydee

-- MAIN APPLICATION
addappid(530890)

-- MAIN APP DEPOTS / PACKAGES
addappid(530891, 1, "5500145de28bdb917d68bb5dee5a681fb54fc9acb56249c6e35cf390273b6b8f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
