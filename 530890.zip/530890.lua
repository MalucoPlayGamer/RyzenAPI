-- Lua provided by RyzenAPI 
-- Game: Haydee
addappid(530890)
addappid(530891, 1, "5500145de28bdb917d68bb5dee5a681fb54fc9acb56249c6e35cf390273b6b8f")
