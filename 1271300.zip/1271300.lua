-- Lua provided by RyzenAPI 
-- Game: Methods: The Detective Competition
addappid(1271300)
addappid(1271301, 1, "b740f8363259ff194adc8af9854fe87559eaffd66559fe63ce2a6f00f767eabc")
