-- Lua provided by RyzenAPI
-- Game: The Alien Cube

-- MAIN APPLICATION
addappid(1099220)
addappid(1790910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1099221, 1, "d78c1a5cb7820e28c04db7842ab82a5373fc61faf4de155a9e25a92f6d9b9f73")
