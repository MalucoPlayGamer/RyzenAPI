-- Lua provided by RyzenAPI
-- Game: Car Mechanic: City Driving

-- MAIN APPLICATION
addappid(2577910)
-- Game: addappid(2577910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577911, 1, "24077e39a489f174e3ef60b00926eb9edc920ffbe7f21beb9e40f83a7c059ddb")
