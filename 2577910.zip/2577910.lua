-- Lua provided by SkyAPI 
-- Game: Car Mechanic: City Driving
addappid(2577910)
addappid(2577911, 1, "24077e39a489f174e3ef60b00926eb9edc920ffbe7f21beb9e40f83a7c059ddb")
