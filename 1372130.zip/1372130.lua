-- Lua provided by RyzenAPI
-- Game: Touhou Blooming Chaos 2 - Soundtrack 2

-- MAIN APPLICATION
addappid(1372130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372131, 1, "ad11d5643c0cd9138261c2e2f1ecd970619303e01505fef800762fbf9e122089")
