-- Lua provided by RyzenAPI
-- Game: addappid(1062020)

-- MAIN APPLICATION
addappid(1062020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062021, 1, "030546a860e158279e3ef802a359a3fdfe6ce5e11fe98a2fbc5cd27f8fb37daa")
