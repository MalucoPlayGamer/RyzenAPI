-- Lua provided by RyzenAPI
-- Game: self-indulgence

-- MAIN APPLICATION
addappid(2595090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595091, 1, "2ba72b268e1d2550c62fa46f6879146424661c139b3a51059cd87fa0445f1e43")
