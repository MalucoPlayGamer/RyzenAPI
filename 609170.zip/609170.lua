-- Lua provided by RyzenAPI
-- Game: Drummer Talent VR

-- MAIN APPLICATION
addappid(609170)

-- MAIN APP DEPOTS / PACKAGES
addappid(609171,0,"98e38c3236e79937bf2fb6c0e9171f72db4659b898ae774f431b08a13bf29c34")

