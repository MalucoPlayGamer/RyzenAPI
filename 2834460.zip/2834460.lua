-- Lua provided by SkyAPI 
-- Game: Balatro Soundtrack
addappid(2834460)
addappid(2834461, 1, "4f3bc0746cd896ec3e138561b98b1d1b0e8a1e0d771c8f013f5badb7cd39dc32")
