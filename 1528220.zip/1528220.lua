-- Lua provided by RyzenAPI
-- Game: Gordian Rooms 2: A curious island

-- MAIN APPLICATION
addappid(1528220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528221, 1, "74fdc835a5464cc5478feb51fe39906b4387d2628ddf60aef0fc1cafd0ee3bd5")
addappid(1528222, 1, "fca187893de45e9932d281cc69f9a8cdc2503d25f14725f015cae59f244ae55d")

