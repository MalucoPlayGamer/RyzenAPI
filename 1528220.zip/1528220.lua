-- Lua provided by RyzenAPI
-- Game: Gordian Rooms 2: A curious island

-- MAIN APPLICATION
addappid(1528220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1528221, 1, "74fdc835a5464cc5478feb51fe39906b4387d2628ddf60aef0fc1cafd0ee3bd5")
addappid(1528222, 1, "fca187893de45e9932d281cc69f9a8cdc2503d25f14725f015cae59f244ae55d")

