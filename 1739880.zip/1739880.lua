-- Lua provided by RyzenAPI
-- Game: Blood And Zombies

-- MAIN APPLICATION
addappid(1739880)
-- Game: addappid(1739880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739881, 1, "232601fea03677e16edf8de2e407856fce14f8433762ab5a91e46f777eb585d1")
