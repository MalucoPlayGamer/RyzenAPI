-- Lua provided by RyzenAPI
-- Game: 414580

-- MAIN APPLICATION
addappid(414580)
-- Game: addappid(414580)

-- MAIN APP DEPOTS / PACKAGES
addappid(414581, 1, "fc97b43538a26e538878a81f055d4ae882aa9182b7f2681033bab857df5eb88d")
