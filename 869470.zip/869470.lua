-- Lua provided by RyzenAPI
-- Game: Game: AppID 869470

-- MAIN APPLICATION
addappid(869470)
-- Game: addappid(869470)

-- MAIN APP DEPOTS / PACKAGES
addappid(869471, 1, "b81037dc5673c5fa21b8674b6aba2a3ea98ab6f4930cf91f4667d2149c577d22")
