-- Lua provided by RyzenAPI
-- Game: Ascender

-- MAIN APPLICATION
addappid(598230)
addappid(816620)
-- Game: addappid(598230)

-- MAIN APP DEPOTS / PACKAGES
addappid(598231, 1, "40ff2eab95a7063b4a27251393c729b351cabf31460e9fcee69c80cc6d8076e6")
addappid(598232, 1, "64a833f461dd98625a83c85a204195379decc58bd6eff212df1af1fa7bf7652e")
addappid(598233, 1, "53a0ad6038de4d246802744ed94f866ea9397d96740dc23f3b11739d7734af3f")
