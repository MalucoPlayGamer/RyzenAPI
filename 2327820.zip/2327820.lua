-- Lua provided by RyzenAPI
-- Game: 2327820

-- MAIN APPLICATION
addappid(2327820)
-- Game: addappid(2327820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327821, 1, "f960eeca32a97f29a71e4bec6c6bfa1e7c74a1b00b8f5b5418c3f63fd754de79")
