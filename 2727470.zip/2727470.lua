-- Lua provided by RyzenAPI
-- Game: 2727470

-- MAIN APPLICATION
addappid(2727470)
-- Game: addappid(2727470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727471, 1, "fc5e958b3848120c76a1fa57ea7ed690ddf2eaacd0dec852fa81d69216a03f60")
