-- Lua provided by RyzenAPI
-- Game: Sacra Terra: Kiss of Death Collector’s Edition

-- MAIN APPLICATION
addappid(560760)

-- MAIN APP DEPOTS / PACKAGES
addappid(560761, 1, "f8069aa654199d94c00fb3a95e9f61cc75523a9a705e6084674e785393b71fa4")
