-- Lua provided by RyzenAPI
-- Game: addappid(1695793)

-- MAIN APPLICATION
addappid(1695793)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701260,0,"ab4763ba8a1a308fde1dcfae9d6d3465d0263cb2381a6946a45bdc6d513e7832")
