-- Lua provided by RyzenAPI
-- Game: Game: LightBall

-- MAIN APPLICATION
addappid(1288070)
-- Game: addappid(1288070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288071, 1, "758957a38b2e25e23a1f16922f1de59401388753d8001b52f2ae254d1b11b191")
