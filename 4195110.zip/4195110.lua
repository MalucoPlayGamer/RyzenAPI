-- Lua provided by RyzenAPI
-- Game: Ultrapool

-- MAIN APP DEPOTS / PACKAGES
addappid(4195110, 1, "fa66c90d6ff7eef1f28e5c9c29235e5e2d0e8969366dacc0e54b22b1020ebae9") -- Ultrapool
addappid(4195111, 1, "cb470cb890485dcb6f086eafe768a609ca9c71f671f995c57cc18ab0f7fe97b7") -- Depot 4195111

