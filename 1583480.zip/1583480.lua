-- Lua provided by RyzenAPI
-- Game: Game: Until We Die Demo

-- MAIN APPLICATION
addappid(1583480)
-- Game: addappid(1583480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583481, 1, "9fde3057cf5f3f2623c862fc1af3b461830a938111005c4a4415879548393a54")
