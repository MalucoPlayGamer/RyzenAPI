-- Lua provided by RyzenAPI
-- Game: Warhammer® 40,000: Dawn of War® - Soulstorm

-- MAIN APPLICATION
addappid(9450)
addappid(228981)
-- Game: addappid(9450)

-- MAIN APP DEPOTS / PACKAGES
addappid(9451, 1, "477db55d6c15b28de148b66ce7ddeec414186bdc346977abab98037eaeeb4cac")
addappid(9452, 1, "04888da06c535124dd51c4f0ce5e0eaf55a180b141d079fc3e5a6f05429bb2a7")
addappid(9453, 1, "c286f05c5b6967c03d8db959764a67f3319414dde66370c257709c571dd8ad61")
addappid(9454, 1, "3330a269eb0bfc01b9c2d12cc4e9cf598d9b347b99852004acd3056a1813ac85")
addappid(9455, 1, "169c41e2641c6d2d64f42694e7be06195f9e10c54724f3a8855bc7b9b0057601")
addappid(9456, 1, "ec86938425d5b7f7358ad2bb4298c9b976878c43b0a3d97935b5ce828ccf5e4c")
addappid(9457, 1, "439ed8865876be5486a742d02b86ecfdcb258d6d1bf59467d63a67cda0709667")
