-- Lua provided by RyzenAPI
-- Game: PongPong Girl

-- MAIN APPLICATION
addappid(2088040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088041, 1, "8d24c65724568cb506053aa6f58074f0f109d10214a6259addf7bf18cbc8dca7")
addappid(2098980, 0, "170b355155c5e28f0c681f99dc61ddc0a16bfedb4e651f71672b300bac4a9e18")
