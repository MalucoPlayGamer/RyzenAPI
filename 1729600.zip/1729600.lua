-- Lua provided by SkyAPI 
-- Game: Intense Love Shot
addappid(1729600)
addappid(1729601, 1, "fda04aaee6a52ae6770182fe7ff334429f04c944da0e7fba10ff58d4ab29ce77")
