-- Lua provided by RyzenAPI
-- Game: Game: Intense Love Shot

-- MAIN APPLICATION
addappid(1729600)
-- Game: addappid(1729600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729601, 1, "fda04aaee6a52ae6770182fe7ff334429f04c944da0e7fba10ff58d4ab29ce77")
