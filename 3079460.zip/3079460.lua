-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Deserted Village

-- MAIN APPLICATION
addappid(3079460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3079461, 1, "0f9006662c3753a650cb98884b4e7661e332825cc10485865ce6e7bc6fa9fade")
