-- Lua provided by RyzenAPI
-- Game: addappid(1968750)

-- MAIN APPLICATION
addappid(1968750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968751, 1, "897dad077cf3fc77cf8fd635e3ba8f50f99b5e30d64ec5da87286e0b58a3d539")
