-- Lua provided by RyzenAPI
-- Game: Littlstar VR Cinema

-- MAIN APPLICATION
addappid(392230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(392231, 1, "00f344bfaf8a877b36176cb73bc03d80234d567169496eb75bd3d31d034a0a06")

