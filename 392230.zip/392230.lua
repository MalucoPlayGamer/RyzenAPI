-- Lua provided by RyzenAPI
-- Game: 392230

-- MAIN APPLICATION
addappid(392230)
-- Game: addappid(392230)

-- MAIN APP DEPOTS / PACKAGES
addappid(392231, 1, "00f344bfaf8a877b36176cb73bc03d80234d567169496eb75bd3d31d034a0a06")
