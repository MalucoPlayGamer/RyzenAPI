-- Lua provided by RyzenAPI
-- Game: Mecha Harem: Bonds of the Abyss

-- MAIN APPLICATION
addappid(3949900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3949901,0,"f2f517796cdef1d5b8d57f6e6b4a8854d586e8551928916483a2038bbb2af9be")

