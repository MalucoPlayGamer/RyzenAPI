-- Lua provided by RyzenAPI
-- Game: AppID 883810

-- MAIN APPLICATION
addappid(883810)
-- Game: addappid(883810)

-- MAIN APP DEPOTS / PACKAGES
addappid(883811, 1, "6c2b986e05622ba36b429ee537ad60e43dc34e510692e9d87f3ca69cd4da209e")
