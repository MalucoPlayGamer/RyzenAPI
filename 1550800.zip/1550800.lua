-- Lua provided by RyzenAPI
-- Game: Omega-Altro

-- MAIN APPLICATION
addappid(1550800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550801, 1, "54bdd4290695149749af8a6e1bb4d30dc3a7c10c2278d1354673206683cbef94")

