-- Lua provided by RyzenAPI
-- Game: Magical Eyes - Red is for Anguish

-- MAIN APPLICATION
addappid(366780)

-- MAIN APP DEPOTS / PACKAGES
addappid(366781, 1, "72517077716776f80768653182d9b3419f43c1d386a1fa6174060dc64726e627")

