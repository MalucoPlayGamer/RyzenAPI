-- Lua provided by RyzenAPI
-- Game: Smart Moves

-- MAIN APPLICATION
addappid(1209520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209521, 1, "4cdd407d9caa42a3883d58918baa02d111694216bdee6e2fa64964290680baff")

