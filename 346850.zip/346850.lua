-- Lua provided by RyzenAPI
-- Game: 346850

-- MAIN APPLICATION
addappid(346850)
-- Game: addappid(346850)

-- MAIN APP DEPOTS / PACKAGES
addappid(346851, 1, "6ec29318a940bab149b389bd990d1ce6e9a8ed7072f2d0bfa3bca155b50b3716")
