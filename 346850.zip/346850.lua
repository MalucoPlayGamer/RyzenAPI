-- Lua provided by RyzenAPI
-- Game: AppID 346850

-- MAIN APPLICATION
addappid(346850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(346851, 1, "6ec29318a940bab149b389bd990d1ce6e9a8ed7072f2d0bfa3bca155b50b3716")

