-- Lua provided by RyzenAPI
-- Game: Sporadic Spire

-- MAIN APPLICATION
addappid(1346240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346241, 1, "6df0eebd3cafc56951ec0c6cb7b89ed88a0eb34f95231b5f9dbfa7444fc5ca4f")

