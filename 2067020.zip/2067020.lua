-- Lua provided by RyzenAPI
-- Game: 2067020

-- MAIN APPLICATION
addappid(2067020)
-- Game: addappid(2067020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067021, 1, "ff4ff7dfbe08a2101899761b57b96fbeb1b8f44167f3ca2c5fe5e99e2b041107")
