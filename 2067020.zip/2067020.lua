-- Lua provided by SkyAPI 
-- Game: Polygeddon
addappid(2067020)
addappid(2067021, 1, "ff4ff7dfbe08a2101899761b57b96fbeb1b8f44167f3ca2c5fe5e99e2b041107")
