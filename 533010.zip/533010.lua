-- Lua provided by SkyAPI 
-- Game: Filthy Lucre
addappid(533010)
addappid(533011, 1, "f6480af0c01f6b27a50f8cd1c3a6aedd831505111dfd503d2db7b1ea6a6e39ca")
