-- Lua provided by RyzenAPI
-- Game: 被黑手浸染的玫瑰与百合

-- MAIN APPLICATION
addappid(4370020)

-- MAIN APP DEPOTS / PACKAGES
addappid(4370021,0,"15a81e6fa7da57e411590a5d9715514bb5baa45f9f780ce56ef5d540baeaff83")

