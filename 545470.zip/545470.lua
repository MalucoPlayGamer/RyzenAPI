-- Lua provided by RyzenAPI
-- Game: AppID 545470

-- MAIN APPLICATION
addappid(545470)

-- MAIN APP DEPOTS / PACKAGES
addappid(545471, 1, "0b9384f1985dc71b06cc5c4e10ca75f2decb5a7db6d082f6b62e2fd6c2b3958a")
