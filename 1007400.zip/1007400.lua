-- Lua provided by RyzenAPI
-- Game: Alien Shooter 2 - The Legend

-- MAIN APPLICATION
addappid(1007400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1007401, 1, "911737a3337743d0bf91d546fa2460041eb90b8b73837604f9a15ad63ee7819a")
addappid(1007402, 1, "6918a7a634980daa66f80afaee5bf099c1ea7b1b09b5b1f4ae99123d67b11b6e")
addappid(1007403, 1, "2513a4d1e89d8780903aa025949efb4053227c64129cef626627897955b1ae8b")
