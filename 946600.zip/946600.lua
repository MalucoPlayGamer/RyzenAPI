-- Lua provided by RyzenAPI
-- Game: Girl with a big SWORD

-- MAIN APPLICATION
addappid(946600)

-- MAIN APP DEPOTS / PACKAGES
addappid(946601, 1, "0eb5c9e25c9bab24a916c390aacf87b076afd62178a0f4a268c93a90e536beba")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(948780)
addappid(948810)
addappid(973500)
addappid(3305780)
