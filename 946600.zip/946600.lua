-- Lua provided by RyzenAPI
-- Game: 946600

-- MAIN APPLICATION
addappid(946600)
-- Game: addappid(946600)

-- MAIN APP DEPOTS / PACKAGES
addappid(946601, 1, "0eb5c9e25c9bab24a916c390aacf87b076afd62178a0f4a268c93a90e536beba")
