-- Lua provided by RyzenAPI
-- Game: Reflections

-- MAIN APPLICATION
addappid(352360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(352361, 1, "63c06b73fa5c140f289f1b3ba47763e80e483ed7d7a188a10f17175bd4cbebc9")
addappid(352362, 1, "01c597281f9d482914b6721066a5082a7f9478c1c9486a13cd9a69b3233d4c2b")
addappid(352363, 1, "a5eaa4a1c7d695b20508ca0e97ee4a8bdc045053000f4eb92a64104f404a9ffd")
addappid(352364, 1, "f1a1d1c7461828882595847d541edfec6d1be861830ab7b74ceac22df0f5bb74")

