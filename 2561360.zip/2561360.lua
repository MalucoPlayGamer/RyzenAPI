-- Lua provided by RyzenAPI
-- Game: Steampunk Jigsaw Puzzles

-- MAIN APPLICATION
addappid(2561360)
addappid(2565030)
addappid(2565040)
addappid(2565050)
addappid(2565060)
addappid(2565070)
addappid(2565080)
addappid(2565090)
addappid(2565100)
addappid(2565110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2561361, 1, "e624c5cfb77d4788302eb083175b1b1fdd54da12af36d2857aefa404c94f1e6d")

