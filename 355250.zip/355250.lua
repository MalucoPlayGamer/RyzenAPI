-- Lua provided by RyzenAPI 
-- Game: STAR WARS™: TIE Fighter Special Edition
addappid(355250)
addappid(355251, 1, "910ea3ee179942a1396763fbabf190df592b8154c865a5a342565e465d6fe5ae")
addappid(355253, 1, "b1ee19e58e36188718d1cd0e3e1e11442f7e4de264bd96b8d1dda4cf35c33a65")
addappid(355254, 1, "4125644e724ca6b0ce69b2a9560b31b5e14b9337a673c3523bbab53d2cbede35")
