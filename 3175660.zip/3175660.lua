-- Lua provided by RyzenAPI
-- Game: Avian Colony Demo

-- MAIN APPLICATION
addappid(3175660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3175661, 1, "7984a2c4dec1e2c3f6700fb65642c950004c10a2c8a1da16dc2b5efa168e8fb8")
