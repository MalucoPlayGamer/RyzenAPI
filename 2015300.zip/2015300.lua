-- Lua provided by RyzenAPI
-- Game: Soulstice Demo

-- MAIN APPLICATION
addappid(2015300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015301, 1, "09c9037f9394b24bc40f1260528b8ab301168dda3c9d9558e23f8109f124d9e6")
