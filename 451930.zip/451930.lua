-- Lua provided by RyzenAPI
-- Game: Game: qrth-phyl

-- MAIN APPLICATION
addappid(451930)
-- Game: addappid(451930)

-- MAIN APP DEPOTS / PACKAGES
addappid(451931, 1, "ae5d3f75ef7de3d8d7547ec9cdc4674967df7c1d64753929c8f621ff6a0c3a23")
