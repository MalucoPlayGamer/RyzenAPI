-- Lua provided by RyzenAPI
-- Game: qrth-phyl

-- MAIN APPLICATION
addappid(451930)

-- MAIN APP DEPOTS / PACKAGES
addappid(451931, 1, "ae5d3f75ef7de3d8d7547ec9cdc4674967df7c1d64753929c8f621ff6a0c3a23")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
