-- Lua provided by RyzenAPI
-- Game: Yoku's Island Express

-- MAIN APPLICATION
addappid(334940)
-- Game: addappid(334940)

-- MAIN APP DEPOTS / PACKAGES
addappid(334941, 1, "ad2d8aa3597c16fc0d453fae441551b9e88a4faceaa4e4ba53c2f02a6c92fe1a")
