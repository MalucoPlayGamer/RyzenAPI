-- Lua provided by RyzenAPI
-- Game: Yoku's Island Express

-- MAIN APPLICATION
addappid(334940)

-- MAIN APP DEPOTS / PACKAGES
addappid(334941, 1, "ad2d8aa3597c16fc0d453fae441551b9e88a4faceaa4e4ba53c2f02a6c92fe1a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
