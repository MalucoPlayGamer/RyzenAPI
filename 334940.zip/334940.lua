-- Lua provided by SkyAPI 
-- Game: Yoku's Island Express
addappid(334940)
addappid(334941, 1, "ad2d8aa3597c16fc0d453fae441551b9e88a4faceaa4e4ba53c2f02a6c92fe1a")
