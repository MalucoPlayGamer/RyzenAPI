-- Lua provided by RyzenAPI
-- Game: Survisland / 实境求生

-- MAIN APPLICATION
addappid(839630)

-- MAIN APP DEPOTS / PACKAGES
addappid(839632,0,"83ec6ce4f152923f755cf7d5d9a7c2c480c09d600302e5caac0932702cf23a75")
