-- Lua provided by RyzenAPI
-- Game: addappid(347170)

-- MAIN APPLICATION
addappid(347170)

-- MAIN APP DEPOTS / PACKAGES
addappid(347171, 1, "792e85f0d54e935198565e9ebc2abaaa913bd995265f4d2cb0909eac08f3844e")
