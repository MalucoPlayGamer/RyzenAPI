-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2437032)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437032,0,"d68428d70fa74e7c7a58327ef390ae9bea18924301cb4613b5c0d99153b04cfe")
