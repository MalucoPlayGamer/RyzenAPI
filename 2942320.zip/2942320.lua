-- Lua provided by RyzenAPI
-- Game: addappid(2942320)

-- MAIN APPLICATION
addappid(2942320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942321, 1, "ca6ba1e3a186efaeca72b49e2db0ff0361105c8c6a7101e83fc8426309b716d1")
