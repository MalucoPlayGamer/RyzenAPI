-- Lua provided by SkyAPI 
-- Game: Candy Hentai
addappid(2942320)
addappid(2942321, 1, "ca6ba1e3a186efaeca72b49e2db0ff0361105c8c6a7101e83fc8426309b716d1")
