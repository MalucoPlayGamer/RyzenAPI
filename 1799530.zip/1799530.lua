-- Lua provided by RyzenAPI
-- Game: Smelogs Playground

-- MAIN APPLICATION
addappid(1799530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1799531, 1, "b067ea3b473633494284345fba7e25bf9c3c542e25a15b4f8ee8b7ab7bfbd01b")

