-- Lua provided by RyzenAPI 
-- Game: Smelogs Playground
addappid(1799530)
addappid(1799531, 1, "b067ea3b473633494284345fba7e25bf9c3c542e25a15b4f8ee8b7ab7bfbd01b")
