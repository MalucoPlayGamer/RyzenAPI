-- Lua provided by RyzenAPI
-- Game: Game: Medal of Honor: Airborne

-- MAIN APPLICATION
addappid(24840)
-- Game: addappid(24840)

-- MAIN APP DEPOTS / PACKAGES
addappid(24841, 1, "495cfc3400f673614b5cfa1bbe80f546df9412c0c5dff804e902c429a80a5e66")
addappid(24842, 1, "66913f0f3f95f33e63d1aec8064c07b6691cf33c836af16701efda5ae0c8af6e")
addappid(24843, 1, "ab4d9b75ed0f6f23ead41c32da58e951df77b4c7e441d56755dcf75fe4d2ab6c")
addappid(24844, 1, "7cf210bc726f110ff4a4addd5147dc7721edc83994c46e4c70b5d12cf0516503")
addappid(24845, 1, "1025084c6e3b8901a3661c9545e7fcf0d86cd35239c607b3e5db606a0fab2c0f")
addappid(24846, 1, "c6d57d0f0b33844967b146e10f92d271aa64b26d6ff8d981cbaf7b0fe04c88f2")
addappid(24847, 1, "3716b2db96cf9017997660cd70fff81d0f825900b8132a4c54612a462ee62c9d")
addappid(24848, 1, "174cb0df0dfa90246a3b17c7817e12923efa32e40d792a7d6b3a38ce8a7d76af")
addappid(24849, 1, "54f524743bfa34403ec53c6df85648d92028468dfd2a8a262772cbea0ace233c")
