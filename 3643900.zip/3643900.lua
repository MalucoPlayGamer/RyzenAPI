-- Lua provided by RyzenAPI
-- Game: addappid(3643900)

-- MAIN APPLICATION
addappid(3643900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3643901, 1, "d6f81233f30ce3870e22f137ae10f561c3ba304508a87fb8d6c416cbf34a91cc")
