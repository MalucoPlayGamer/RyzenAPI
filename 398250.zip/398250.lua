-- Lua provided by RyzenAPI
-- Game: 398250

-- MAIN APPLICATION
addappid(398250)
-- Game: addappid(398250)

-- MAIN APP DEPOTS / PACKAGES
addappid(398251, 1, "c733d8a3e5390055275278d00b1fddef8075cdc761f8633df842e95388b8b2ee")
