-- Lua provided by RyzenAPI
-- Game: Scarred Stars: Traumatic Edition

-- MAIN APPLICATION
addappid(1754760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754761, 1, "079c8f643c345baaec09ac81cd9cd182db0971d7b5963833b111ab2b9020f699")
addappid(1754762, 1, "1a1eb885f831d68ca73c748671d5ae5f6a73c356744caf740071cd747429b756")

