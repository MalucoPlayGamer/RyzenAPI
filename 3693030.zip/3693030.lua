-- Lua provided by RyzenAPI
-- Game: King of Bones

-- MAIN APPLICATION
addappid(3693030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3693031, 1, "2aacb90613d03d9744cb7880e3f243a3054c29165f6feb0ac42036c74a80a223")

