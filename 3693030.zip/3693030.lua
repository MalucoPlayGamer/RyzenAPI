-- Lua provided by RyzenAPI
-- Game: Game: King of Bones

-- MAIN APPLICATION
addappid(3693030)
-- Game: addappid(3693030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3693031, 1, "2aacb90613d03d9744cb7880e3f243a3054c29165f6feb0ac42036c74a80a223")
