-- Lua provided by RyzenAPI
-- Game: addappid(2072890)

-- MAIN APPLICATION
addappid(2072890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072891, 1, "96f9dfc236e855f658ec1e171d53e6df11b24fbfde99db16dfe1877fb11351e2")
