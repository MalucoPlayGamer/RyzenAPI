-- Lua provided by RyzenAPI
-- Game: On Your Tail

-- MAIN APPLICATION
addappid(2132560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2132561, 1, "f64906a2242a7bb6295820f99607472150630b50b51272171e29228365db4e5b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3352920)
