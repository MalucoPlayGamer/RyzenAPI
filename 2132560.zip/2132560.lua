-- Lua provided by SkyAPI 
-- Game: On Your Tail
addappid(2132560)
addappid(2132561, 1, "f64906a2242a7bb6295820f99607472150630b50b51272171e29228365db4e5b")
