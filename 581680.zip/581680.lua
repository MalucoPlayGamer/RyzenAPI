-- Lua provided by RyzenAPI
-- Game: To the home

-- MAIN APPLICATION
addappid(581680)

-- MAIN APP DEPOTS / PACKAGES
addappid(581681, 1, "05ed6b3d6e69bad9cbff9945a5ccc0140b3773c03c2e84e07e110b1697cf8e12")

