-- Lua provided by RyzenAPI
-- Game: 581680

-- MAIN APPLICATION
addappid(581680)
-- Game: addappid(581680)

-- MAIN APP DEPOTS / PACKAGES
addappid(581681, 1, "05ed6b3d6e69bad9cbff9945a5ccc0140b3773c03c2e84e07e110b1697cf8e12")
