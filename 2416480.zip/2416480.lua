-- Lua provided by RyzenAPI
-- Game: 缘起

-- MAIN APPLICATION
addappid(2416480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2416481, 1, "4c9182e65b0e9cc231a9cf17de5631f8c62f96195334ac398781423c08109a95")
