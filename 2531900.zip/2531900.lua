-- Lua provided by RyzenAPI 
-- Game: AppID 2531900
addappid(2531900)
addappid(2531901, 1, "ef66e09ab7e39b6bd2d167193d505b4d35c9420e40ff4236a76bd7be1320a2d2")
