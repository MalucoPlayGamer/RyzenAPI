-- Lua provided by RyzenAPI
-- Game: Stellar Tactics

-- MAIN APPLICATION
addappid(465490)

-- MAIN APP DEPOTS / PACKAGES
addappid(465492,0,"ac918fe0ba06171c5c4e54f51907d68cc905204dd68ff689929ba1af3f3435e4")
