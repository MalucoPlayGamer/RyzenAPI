-- Lua provided by RyzenAPI
-- Game: Rugida

-- MAIN APPLICATION
addappid(1352180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352181, 1, "8855a5f52b765e1913934b43e0ba205feefa14b31328254c6de7cf43f810f6ba")

