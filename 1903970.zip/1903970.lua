-- Lua provided by SkyAPI 
-- Game: World Championship Boxing Manager™ 2
addappid(1903970)
addappid(1903971, 1, "ed5cfb2b0c2e61aa4c5b56dfd3568ea68f3222fe4021a2006f08846158728980")
