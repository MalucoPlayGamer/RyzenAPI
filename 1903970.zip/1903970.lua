-- Lua provided by RyzenAPI
-- Game: Game: World Championship Boxing Manager™ 2

-- MAIN APPLICATION
addappid(1903970)
-- Game: addappid(1903970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903971, 1, "ed5cfb2b0c2e61aa4c5b56dfd3568ea68f3222fe4021a2006f08846158728980")
