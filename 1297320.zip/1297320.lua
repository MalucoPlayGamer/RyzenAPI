-- Lua provided by SkyAPI 
-- Game: ACT
addappid(1297320)
addappid(1297321, 1, "0b6f9d5b3805609386fd24eaa3542ead55db2d2b40a20a2756714982e136b426")
