-- Lua provided by RyzenAPI
-- Game: Game: ACT

-- MAIN APPLICATION
addappid(1297320)
-- Game: addappid(1297320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297321, 1, "0b6f9d5b3805609386fd24eaa3542ead55db2d2b40a20a2756714982e136b426")
