-- Lua provided by RyzenAPI
-- Game: ACT

-- MAIN APPLICATION
addappid(1297320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297321, 1, "0b6f9d5b3805609386fd24eaa3542ead55db2d2b40a20a2756714982e136b426")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
