-- Lua provided by SkyAPI 
-- Game: Beauty Solitaire
addappid(3016120)
addappid(3016121, 1, "4283b1cc5b70fe5ba4f4f38073897f16fc33d136ba95290ab6b6a3fe8acc838f")
