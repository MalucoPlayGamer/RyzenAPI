-- Lua provided by RyzenAPI
-- Game: 1 Screen Platformer: Prologue

-- MAIN APPLICATION
addappid(1271540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271541, 1, "7b289ca4fa0ec7960cfd2e9ce95667dab832dc6e1d7ef0576c33b33bcfe310f0")

