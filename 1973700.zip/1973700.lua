-- Lua provided by RyzenAPI
-- Game: Lianhai Casino

-- MAIN APPLICATION
addappid(1973700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973701, 1, "0f5ba8e244309840a2746d3aad34a9fb9ca12a517cbbc32ae8d8375d6541db43")

