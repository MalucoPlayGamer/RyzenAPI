-- Lua provided by RyzenAPI
-- Game: XING: The Land Beyond

-- MAIN APPLICATION
addappid(299400)

-- MAIN APP DEPOTS / PACKAGES
addappid(299401, 1, "f6aa243a527dbdea4642d8094bd4268c3f3b3aa7606cd9bc3264fe9518518a57")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
