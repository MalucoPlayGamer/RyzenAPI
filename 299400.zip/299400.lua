-- Lua provided by RyzenAPI
-- Game: XING: The Land Beyond

-- MAIN APPLICATION
addappid(299400)

-- MAIN APP DEPOTS / PACKAGES
addappid(299401, 1, "f6aa243a527dbdea4642d8094bd4268c3f3b3aa7606cd9bc3264fe9518518a57")

