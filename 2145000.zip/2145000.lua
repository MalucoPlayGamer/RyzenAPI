-- Lua provided by RyzenAPI
-- Game: Twilight Of The Gods

-- MAIN APPLICATION
addappid(2145000)
-- Game: addappid(2145000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2145001, 1, "a1ce616ab342c643a569516170653bd1432e89db9d8291920fbe70d60fae2a04")
