-- Lua provided by RyzenAPI
-- Game: AppID 639780

-- MAIN APPLICATION
addappid(639780)

-- MAIN APP DEPOTS / PACKAGES
addappid(639781, 1, "7e5d164187ca1108a9ac6ca5dd4e0b91c134fea23fd8a3e5ca62bbe490f5f016")

