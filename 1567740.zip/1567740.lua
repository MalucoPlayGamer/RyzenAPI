-- Lua provided by RyzenAPI
-- Game: AppID 1567740

-- MAIN APPLICATION
addappid(1567740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1567741, 1, "7bbdea53ade358208e05f7bfdced94bc1fd1d3086366798e92a86d278ac3a136")

