-- Lua provided by RyzenAPI
-- Game: 1567740

-- MAIN APPLICATION
addappid(1567740)
-- Game: addappid(1567740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567741, 1, "7bbdea53ade358208e05f7bfdced94bc1fd1d3086366798e92a86d278ac3a136")
