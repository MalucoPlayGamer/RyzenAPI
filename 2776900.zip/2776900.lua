-- Lua provided by RyzenAPI
-- Game: 2776900

-- MAIN APPLICATION
addappid(2776900)
-- Game: addappid(2776900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776902,0,"1d0f7dce0e53a1f623fb03eb946b17eff8928d950aa53cd15da6a3d4b86983eb")
