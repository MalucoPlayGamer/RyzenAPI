-- Lua provided by RyzenAPI
-- Game: The Eminence in Shadow: Master of Garden

-- MAIN APPLICATION
addappid(2776900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2776902,0,"1d0f7dce0e53a1f623fb03eb946b17eff8928d950aa53cd15da6a3d4b86983eb")

