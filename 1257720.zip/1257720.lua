-- Lua provided by RyzenAPI
-- Game: addappid(1257720)

-- MAIN APPLICATION
addappid(1257720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257721, 1, "b4c86748d4c62d692773e8acc6b1c05ec88ee240b1716e63cce4f4f8c00ba331")
