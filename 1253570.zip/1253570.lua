-- Lua provided by SkyAPI 
-- Game: AppID 1253570
addappid(1253570)
addappid(1253571, 1, "f253f9aea1e55c60fc932a743b664ef1da312a7c7a1f6a68fa0ca20e17c7d187")
