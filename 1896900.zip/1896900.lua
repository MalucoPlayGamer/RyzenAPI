-- Lua provided by RyzenAPI 
-- Game: Rail Route: The Story of Jozic
addappid(1896900)
addappid(1896901, 1, "99fca9ef986aaf070d53f5bf9d62f686a4ea93cd7cac3e50b2ae93e9fc3ecee6")
addappid(1896902, 1, "23a564c571085157ce07eb5726a540745db71c5623a0c5440d19f878042fe9d0")
addappid(1896903, 1, "032a0c5420357a36454fafc4f446402c169750432a2bd8c049593122e8cc8f7c")
