-- Lua provided by RyzenAPI
-- Game: AppID 660990

-- MAIN APPLICATION
addappid(660990)
-- Game: addappid(660990)

-- MAIN APP DEPOTS / PACKAGES
addappid(660991, 1, "3db9953cfeae629913fe8892c0d9e92bb75359269a08b2627630de653542de9d")
