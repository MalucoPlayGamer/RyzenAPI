-- Lua provided by RyzenAPI
-- Game: AppID 1901940

-- MAIN APPLICATION
addappid(1901940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901941, 1, "3067a47aee017984c26eb75da9a70bdf7fd3ecc1938fe3c8067f0f37dfb45008")

