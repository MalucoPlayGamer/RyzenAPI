-- Lua provided by RyzenAPI
-- Game: Astro Mission: Moon

-- MAIN APPLICATION
addappid(1901940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1901941, 1, "3067a47aee017984c26eb75da9a70bdf7fd3ecc1938fe3c8067f0f37dfb45008")

