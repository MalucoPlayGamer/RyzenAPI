-- Lua provided by RyzenAPI 
-- Game: AppID 1061180
addappid(1061180)
addappid(1061181, 1, "07c1ea7a3699f405b685b10e092960354fc34ed36d80ffa6e7fda7b5cd003d6a")
addappid(1061182, 1, "7dfaaae2c3878bc172be4b6190b25c3ff38fcef8d127b3b58ef4b2c7397c5b36")
addappid(1061183, 1, "5e11ff0fd23f48ab31f1fb81473786e0b0de031f800a73ba83e74e59e993ba71")
