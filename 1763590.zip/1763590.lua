-- Lua provided by RyzenAPI
-- Game: Chair Spinning Simulator

-- MAIN APPLICATION
addappid(1763590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763591, 1, "f8335fd8ce770b6e8bfe149843aec20d277f39256c818843e012dc55bcde91e3")
