-- Lua provided by RyzenAPI
-- Game: AppID 709940

-- MAIN APPLICATION
addappid(709940)

-- MAIN APP DEPOTS / PACKAGES
addappid(709941, 1, "94f91032156cb84312e88388f4fc9feba155c80d79fcca7295c150a36cfa1f4e")

