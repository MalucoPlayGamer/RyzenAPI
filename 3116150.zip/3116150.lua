-- Lua provided by RyzenAPI
-- Game: Butterfly Dream Demo

-- MAIN APPLICATION
addappid(3116150)
-- Game: addappid(3116150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116151, 1, "e6c48dd4bf110a83368a755eb82574d662594cd6741f75cb1c664f343b75c864")
