-- Lua provided by RyzenAPI
-- Game: My Dear Can't Speak

-- MAIN APPLICATION
addappid(3382360)
-- Game: addappid(3382360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3382361, 1, "2384c0b61180ec1bc78da7c5427fdcae4ed05eb8574ae81f9a5749950a5ff8b6")
