-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2231716)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231716,0,"d0f767f275064271a829ac9c8ff7118ca38b620269287df2a5abd0093e25b1d4")
