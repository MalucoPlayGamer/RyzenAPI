-- Lua provided by RyzenAPI
-- Game: Car Mechanic Simulator 2021 Demo

-- MAIN APPLICATION
addappid(1585850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585851, 1, "9b09e2a1c0f322f7680bac53cc6b5e947d9f6384209ed2e446d5b00cbf400737")

