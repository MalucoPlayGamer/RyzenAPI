-- Lua provided by RyzenAPI
-- Game: Monster Harvest Demo

-- MAIN APPLICATION
addappid(1648890)
-- Game: addappid(1648890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648891, 1, "92a9690652a015bc34285deee746c39e2e3b7de1895fad75eeb478f63b90af58")
