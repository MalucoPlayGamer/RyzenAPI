-- Lua provided by RyzenAPI
-- Game: TRI: Of Friendship and Madness

-- MAIN APPLICATION
addappid(293660)

-- MAIN APP DEPOTS / PACKAGES
addappid(293661, 1, "22145edf6b5ee6bafe9b3f94f52eb922c546479dde8490243e532df89e0a0195")
addappid(293662, 1, "51ed66435e94e36f7e762bd6432b627cb52b907500ce235da10ffaf047f51d3e")
addappid(293663, 1, "6af519b79066ccd4a45708e025d4fa7df365970c6f524fb187c0804c2bbcbdf0")
addappid(323730, 0, "05e7e98abbf3e21b4df6989d58b5d68bed339cb4738617814ca1e32d9ba6c275")

