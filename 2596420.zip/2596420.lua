-- Lua provided by RyzenAPI 
-- Game: Arranger: A Role-Puzzling Adventure
addappid(2596420)
addappid(2596421, 1, "ae84f4e4ca0c3a8d7bca05077b7ce8921bd61f514f93665a19f4d5b100a206d0")
