-- Lua provided by RyzenAPI
-- Game: SEX Route 69

-- MAIN APPLICATION
addappid(3213090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213091, 1, "fae45df9ac7fff8c49a55e92892492c24e1a7837e77d03e77b87e729d5625b6b")

