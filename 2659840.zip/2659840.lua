-- Lua provided by RyzenAPI
-- Game: 2659840

-- MAIN APPLICATION
addappid(2659840)
-- Game: addappid(2659840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659843,0,"29689285982a1a61b4465f82e17a5cf562caeb773cb8bc875e71ebf9b4d6cff1")
