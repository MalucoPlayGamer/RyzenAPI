-- 4858190's Lua and Manifest Created by Hubcap Manifest
-- A Game About Shooting Ducks
-- Created: August 26, 2026 at 17:43:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4858190) -- A Game About Shooting Ducks
-- MAIN APP DEPOTS
addappid(4858191, 1, "fe44f4d59e88c26637d38620c08e6ba7a0e6e2b09dfb0dfec517ec6bbf2b2f4a") -- Depot 4858191
setManifestid(4858191, "2606059597867543692", 62776585)