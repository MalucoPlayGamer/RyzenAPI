-- Lua provided by RyzenAPI
-- Game: A Game About Shooting Ducks

-- MAIN APPLICATION
addappid(4858190) -- A Game About Shooting Ducks

-- MAIN APP DEPOTS / PACKAGES
addappid(4858191, 1, "fe44f4d59e88c26637d38620c08e6ba7a0e6e2b09dfb0dfec517ec6bbf2b2f4a") -- Depot 4858191

