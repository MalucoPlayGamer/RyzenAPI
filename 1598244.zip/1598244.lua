-- Lua provided by RyzenAPI
-- Game: addappid(1598244)

-- MAIN APPLICATION
addappid(1598244)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598244,0,"46cd2ee60b50507368d4cc0ef2ac88bfce907ce65838e2979d4bbf87883058b8")
