-- Lua provided by RyzenAPI
-- Game: AppID 956010

-- MAIN APPLICATION
addappid(956010)

-- MAIN APP DEPOTS / PACKAGES
addappid(956011, 1, "aebddfd6fd08ddeb9e5397e903cc85f42329602002f56cd8d4959298686acd81")
