-- Lua provided by RyzenAPI
-- Game: Larry The Unlucky Part 2

-- MAIN APPLICATION
addappid(1705590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705591, 1, "d489e8c7f9b9f039976e1533f7f7f37b275a70323d2789f43115504c650c3041")

