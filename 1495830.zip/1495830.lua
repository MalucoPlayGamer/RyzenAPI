-- Lua provided by RyzenAPI
-- Game: Rokka

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1495830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495832,0,"a50b904774c570765f4b820e3c34b53f5b392389ee67c0e1de02473f11412df8")

