-- Lua provided by RyzenAPI
-- Game: addappid(881500)

-- MAIN APPLICATION
addappid(881500)

-- MAIN APP DEPOTS / PACKAGES
addappid(881501, 1, "060f942ba17b22274d397f64c784d35edbd16a65f0be30958016c3a95eb470b5")
