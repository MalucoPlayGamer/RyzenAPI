-- Lua provided by RyzenAPI 
-- Game: AppID 2274480
addappid(2274480)
addappid(2274481, 1, "2a6a202c8bf7638e09d4c64f11dbe5cf532111eef587fd43e0f0e9a94c7b4554")
