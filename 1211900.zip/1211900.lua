-- Lua provided by RyzenAPI
-- Game: LiEat Rearrange Soundtrack

-- MAIN APPLICATION
addappid(1211900)

-- MAIN APP DEPOTS / PACKAGES
addappid(373779,0,"7128141f0bf8458be2191971b848597b4ea6795089c22d9fcf08670d954b41c1")

