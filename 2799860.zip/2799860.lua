-- Lua provided by RyzenAPI
-- Game: addappid(2799860)

-- MAIN APPLICATION
addappid(2799860)
addappid(3550790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799861, 1, "da70d57902dfb9488ab7546791fe906d239062bb3b209db909eda0a17e4745c3")
