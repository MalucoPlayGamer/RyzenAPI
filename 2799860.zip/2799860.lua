-- Lua provided by RyzenAPI
-- Game: INAZUMA ELEVEN: Victory Road

-- MAIN APPLICATION
addappid(3550790) -- INAZUMA ELEVEN Victory Road - Edition Upgrade (Deluxe Edition)
addappid(3801700) -- INAZUMA ELEVEN Victory Road - Pre-order Bonus

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
addappid(2799860, 1, "3296a7a5303d5f4229c6caaf5bd49da707f74e00af99fd116894f74ba0ce79c9") -- INAZUMA ELEVEN: Victory Road
addappid(2799861, 1, "da70d57902dfb9488ab7546791fe906d239062bb3b209db909eda0a17e4745c3") -- Depot 2799861
addtoken(3801700, "14660639349074866851")

