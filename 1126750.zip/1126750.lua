-- Lua provided by RyzenAPI
-- Game: Mr. DRILLER DrillLand

-- MAIN APPLICATION
addappid(1126750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1126751, 1, "6ba63ca6bef82478c054f4200884a8474a1aae8d5b51a7452e7db06bb129936c")

