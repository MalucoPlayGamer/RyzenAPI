-- Lua provided by RyzenAPI 
-- Game: Sipssassin
addappid(2820190)
addappid(2820191, 1, "aba37d9e3c98a2cc729f1162c67ae8e68c11ec737a37ae198e0182c5d7342386")
