-- Lua provided by RyzenAPI
-- Game: addappid(867750)

-- MAIN APPLICATION
addappid(228986)
addappid(867750)

-- MAIN APP DEPOTS / PACKAGES
addappid(867752,0,"8c1a3ea318619f7c2c1698c802772334f0d2e182f8871e1f6195fd9fd57869bc")
