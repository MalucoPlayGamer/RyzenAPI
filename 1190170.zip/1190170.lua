-- Lua provided by RyzenAPI
-- Game: OlliOlli World

-- MAIN APPLICATION
addappid(1190170)
addappid(1836410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190171, 1, "be0f92c1bd6bf8e87ad2d9a5b62cde5dd359a56a6e27abca823da99d6dd5ebab")
addappid(1759190, 0, "fca4144e580ff875cbaff6c452adfada2feb7ebe7e41b207eb436ef5419c527c")
addappid(1829830, 0, "14e847c0eae8f6032d6f90083c278f510e907e03d0d76e5a2020a00ff1a4abf2")
addappid(1829831, 0, "a6a7fc0692ed617e9fb5a99def74551a0a26776170abecaf7425ca5e7f9d62c5")
