-- Lua provided by RyzenAPI
-- Game: Pandum online

-- MAIN APPLICATION
addappid(469930)
-- Game: addappid(469930)

-- MAIN APP DEPOTS / PACKAGES
addappid(469932,0,"69503ae1730e032c9d6e5ed9013ea230c57140eef1b14a83fb35d1df9a35e80b")
addappid(469933,0,"1c40df891021ae5f7d0e20f065b66ec7b7e3e3e309e886756711bc483adb62e5")
