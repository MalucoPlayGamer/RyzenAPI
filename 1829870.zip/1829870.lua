-- Lua provided by RyzenAPI
-- Game: RetroArch - UAE

-- MAIN APPLICATION
addappid(1829870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829871, 1, "497be3a2aa49229b9b6897400c8161a05ad4343d0e6ad07fb5ebc4d5e669bc2a")
addappid(1829872, 1, "cc1e754f26111c3dbba68acf2917d54218f7882e47daaa1924e18b5a1fc0a688")

