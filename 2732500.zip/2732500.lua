-- Lua provided by RyzenAPI
-- Game: AppID 2732500

-- MAIN APPLICATION
addappid(2732500)
-- Game: addappid(2732500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732501, 1, "7387ef1edfa96b047c3a3f4a96f47213f3d8040da122d7cabc247452236fa332")
addappid(2916720, 0, "aa617d8e93f59e2defbb262834884fbabc63105468584f44e0df44f812fdb82d")
