-- Lua provided by RyzenAPI
-- Game: Game: Capitalism 2

-- MAIN APPLICATION
addappid(638200)
-- Game: addappid(638200)

-- MAIN APP DEPOTS / PACKAGES
addappid(638201, 1, "1c2856db4edbc9df5640dcf525f7d14c3a24451268fc6ce7993e87d6319a7a45")
