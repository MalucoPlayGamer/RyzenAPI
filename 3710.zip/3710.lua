-- Lua provided by SkyAPI 
-- Game: Judge Dredd: Dredd vs. Death
addappid(3710)
addappid(3711, 1, "d06482355b2ff5cba9b594df453b44a94738d0c2c409a7c1e9a85fae3ccf0ff9")
