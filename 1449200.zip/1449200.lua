-- Lua provided by RyzenAPI
-- Game: AI: THE SOMNIUM FILES - nirvanA Initiative

-- MAIN APPLICATION
addappid(1449200) -- AI: THE SOMNIUM FILES - nirvanA Initiative
addappid(1794870) -- AI THE SOMNIUM FILES - nirvanA Initiative DLC Kimono Set
addappid(1794871) -- AI THE SOMNIUM FILES - nirvanA Initiative DLC Monochrome Set
addappid(1794872) -- AI THE SOMNIUM FILES - nirvanA Initiative DLC Hot Dog Costume Set
addappid(1794873) -- AI THE SOMNIUM FILES - nirvanA Initiative DLC 3 Pattern T-Shirt Set
addappid(1794874) -- AI THE SOMNIUM FILES - nirvanA Initiative DLC B-Movie Horror Set

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1449201, 1, "5be9ee1d6234f48cc1ee8a81cbc2ba650cea6ac78ef459b4d55457942a5c0a3e") -- Depot 1449201

