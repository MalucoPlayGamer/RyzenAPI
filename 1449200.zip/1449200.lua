-- Lua provided by RyzenAPI
-- Game: AI: THE SOMNIUM FILES - nirvanA Initiative

-- MAIN APPLICATION
addappid(1449200)
-- Game: addappid(1449200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449201, 1, "5be9ee1d6234f48cc1ee8a81cbc2ba650cea6ac78ef459b4d55457942a5c0a3e")
