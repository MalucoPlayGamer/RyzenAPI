-- Lua provided by RyzenAPI 
-- Game: Sniper Hunter Shooter
addappid(2584470)
addappid(2584471, 1, "9795f7c8971bdf5f5cf72990cd106f18bc80de6e9b19a4560ad74dd9f0e5ec60")
