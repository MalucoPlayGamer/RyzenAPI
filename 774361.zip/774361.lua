-- Lua provided by RyzenAPI
-- Game: Blasphemous

-- MAIN APPLICATION
addappid(774361)
addappid(1143853)

-- MAIN APP DEPOTS / PACKAGES
addappid(774362, 1, "3c0c23fe108b94cd3807435b2bc40180ca3b94536b58e0c39accee663fed16bb")
addappid(774363, 1, "d993ef6a175b97835fad06b6a121a239090b64f1af4301e21a277f7f72e8f89a")
addappid(774364, 1, "95c96562c2ca7d1a11075a78297194a2012a6b4dc3e795f3604c305717fc6e17")
addappid(774365, 1, "bab5ef14e351920c47897af01aa779ee7cd40e781f30acf4090c8d7bbbea62a0")
addappid(774366, 1, "f4cd54024c406a8d40ad60806ebdab94a7dd83dfd7a6440e044d3906517ab6ea")
addappid(774367, 1, "57fe84004caab7f31c8e3aa070d594f60d9fc847aaec1a8279fe5d96e008e66a")
addappid(1143850, 0, "de17e7ba029ac0ab3018562633b8542f7336481472c8789b26ec665192b68cd4")
addappid(1143851, 0, "5069e7a80c60cb1e87e237739720a7dee49178f81b14c5290401aed931c8b9e1")
addappid(1143854, 0, "7d3b229e73e5756b4152675ce1fd12d0318ca3f4f74269d6b93fa41f1cb6a6c3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1146990)
