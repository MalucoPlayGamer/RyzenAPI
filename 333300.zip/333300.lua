-- Lua provided by RyzenAPI
-- Game: ADOM (Ancient Domains Of Mystery)

-- MAIN APPLICATION
addappid(333300)

-- MAIN APP DEPOTS / PACKAGES
addappid(333301, 1, "01aea7db00cafa7e83ce258c2bc3bb23f1ae6a47b90907b78be6167de29d204a")
addappid(333302, 1, "5006c22bd49ff282888ec1c21968cca5e09b300f709d19ab83474f25a4e60274")
addappid(333303, 1, "86581c8b50fdaefef545b48cf98b61dbda767ac9c3dd3b6135c26eb4e2f18c02")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
