-- Lua provided by RyzenAPI 
-- Game: AppID 2493910
addappid(2493910)
addappid(2493911, 1, "25f4eb33e784ec7d3ac9a5c8d856bd3b8bffb738deac73bc7a7285b2f6788031")
