-- Lua provided by RyzenAPI
-- Game: Christmas Race 2

-- MAIN APPLICATION
addappid(801890)
-- Game: addappid(801890)

-- MAIN APP DEPOTS / PACKAGES
addappid(801891, 1, "47e2c848b07a3d13a48377f39789b7c9eac49aed4ac03e3ed3d6f7a06af1c08b")
