-- Lua provided by RyzenAPI 
-- Game: AppID 691890
addappid(691890)
addappid(691891, 1, "735f43fe512539fe3bf90dc2911d85ff2ea149f4002d4d4862c309b3241718e6")
