-- Lua provided by RyzenAPI
-- Game: 陨星危机

-- MAIN APPLICATION
addappid(691890)

-- MAIN APP DEPOTS / PACKAGES
addappid(691891, 1, "735f43fe512539fe3bf90dc2911d85ff2ea149f4002d4d4862c309b3241718e6")
