-- Lua provided by RyzenAPI
-- Game: 3626160

-- MAIN APPLICATION
addappid(3626160)
-- Game: addappid(3626160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3626161, 1, "674d4d7feb7dfd6e7441874ea6b912b803d6c631a95956cb0584567d41b5bf1f")
