-- Lua provided by RyzenAPI
-- Game: Dropkick Navvy: First Step

-- MAIN APPLICATION
addappid(2530500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530501, 1, "d7e23d461b9faf29c2e3ec9d975f114cff06316e356fe47fe01c972038b6bd30")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
