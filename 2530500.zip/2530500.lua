-- Lua provided by RyzenAPI
-- Game: Game: Dropkick Navvy: First Step

-- MAIN APPLICATION
addappid(2530500)
-- Game: addappid(2530500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530501, 1, "d7e23d461b9faf29c2e3ec9d975f114cff06316e356fe47fe01c972038b6bd30")
