-- Lua provided by RyzenAPI
-- Game: Game: Age of Goblins

-- MAIN APPLICATION
addappid(2555570)
-- Game: addappid(2555570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555571, 1, "07d2086a027647ce62711f2c22f7752b368a0022e9248ebc413970fe23005412")
