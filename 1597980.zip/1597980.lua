-- Lua provided by RyzenAPI
-- Game: City 20

-- MAIN APPLICATION
addappid(1597980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597985,0,"69bc62e3db157c7aa6c2630c3e39c77f0bfe909eef1ee33952712b8ff79fb593")
