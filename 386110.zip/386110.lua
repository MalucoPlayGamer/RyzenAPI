-- Lua provided by RyzenAPI
-- Game: Raywin

-- MAIN APPLICATION
addappid(386110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(386111, 1, "2c0ec9a15abb650edf7b31b5784246179b5bbc310744464e9a92c5f680b3d6df")

