-- Lua provided by RyzenAPI
-- Game: AppID 386110

-- MAIN APPLICATION
addappid(386110)

-- MAIN APP DEPOTS / PACKAGES
addappid(386111, 1, "2c0ec9a15abb650edf7b31b5784246179b5bbc310744464e9a92c5f680b3d6df")

