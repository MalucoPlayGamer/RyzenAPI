-- Lua provided by RyzenAPI
-- Game: Gamers Unknown Survival

-- MAIN APPLICATION
addappid(677870)

-- MAIN APP DEPOTS / PACKAGES
addappid(677871, 1, "2ae1da746310af78153d2c6e302414ab6813d191d0988f79616aad7acb21dec0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
