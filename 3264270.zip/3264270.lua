-- Lua provided by RyzenAPI
-- Game: Twin-Stick Survivors Demo

-- MAIN APPLICATION
addappid(3264270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264271, 1, "b0447f11b9802d01f3877bba26b94cb7ce290b143f0f35663b80868437e355ec")
