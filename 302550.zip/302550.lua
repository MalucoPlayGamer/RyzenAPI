-- Lua provided by RyzenAPI
-- Game: AppID 302550

-- MAIN APPLICATION
addappid(302550)
-- Game: addappid(302550)

-- MAIN APP DEPOTS / PACKAGES
addappid(302551, 1, "70f5a6b59d33bd33a9e1680a6cc644b8e6f7a90d36ce6edfe1c82a2b7db957bd")
