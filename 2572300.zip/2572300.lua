-- Lua provided by RyzenAPI
-- Game: Row Divers

-- MAIN APPLICATION
addappid(2572300)
-- Game: addappid(2572300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572302,0,"cb83162efadc88261d050224bcec539efaec61d86175febcb480ea8189e4bbab")
