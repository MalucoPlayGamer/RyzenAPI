-- Lua provided by RyzenAPI 
-- Game: Room 817: Director's Cut
addappid(2907870)
addappid(2907871, 1, "9144a62f859eeba20e54fb2cf3c5e0c9d3f52476a21eb9862fe06088fe237d82")
