-- Lua provided by RyzenAPI
-- Game: Game: Room 817: Director's Cut

-- MAIN APPLICATION
addappid(2907870)
-- Game: addappid(2907870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2907871, 1, "9144a62f859eeba20e54fb2cf3c5e0c9d3f52476a21eb9862fe06088fe237d82")
