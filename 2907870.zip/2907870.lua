-- Lua provided by RyzenAPI
-- Game: Room 817: Director's Cut

-- MAIN APPLICATION
addappid(2907870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2907871, 1, "9144a62f859eeba20e54fb2cf3c5e0c9d3f52476a21eb9862fe06088fe237d82")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
