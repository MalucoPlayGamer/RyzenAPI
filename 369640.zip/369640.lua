-- Lua provided by RyzenAPI
-- Game: Treeker: The Lost Glasses

-- MAIN APPLICATION
addappid(369640)

-- MAIN APP DEPOTS / PACKAGES
addappid(369641, 1, "4b07b479a9c7cf631b3fe1cf647cea902acd4f9a5f692e7382998ab0a40242eb")

