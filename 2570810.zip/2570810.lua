-- Lua provided by RyzenAPI
-- Game: Game: Ys X: Nordics

-- MAIN APPLICATION
addappid(2570810)
-- Game: addappid(2570810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570811, 1, "632b952fc96fea8272f531a7a8b186927c081ce1228916809d6b7e6ace47379d")
