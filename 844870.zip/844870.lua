-- Lua provided by RyzenAPI
-- Game: 844870

-- MAIN APPLICATION
addappid(844870)
-- Game: addappid(844870)

-- MAIN APP DEPOTS / PACKAGES
addappid(844871, 1, "eb8ad17673a927da57a2982ebc8737cad0569a22446c56ba81365000da68ff9e")
