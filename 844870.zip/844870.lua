-- 844870's Lua and Manifest Created by Hubcap Manifest
-- KurtzPel
-- Created: August 23, 2026 at 02:22:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 54
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(844870, 1, "b5ba71da3032d342c6c41e1a6f3966905a0b301064ed5f17ecc053ce59834c62") -- KurtzPel
-- MAIN APP DEPOTS
addappid(844871, 1, "eb8ad17673a927da57a2982ebc8737cad0569a22446c56ba81365000da68ff9e") -- KurtzPel Content
setManifestid(844871, "4819182874103212568", 28860911366)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1004220) -- KurtzPel - Karma  Diabolic Witch
addappid(1061700) -- KurtzPel - Karma  Blazing Fist
addappid(1069580) -- KurtzPel - Starter Pack
addappid(1069581) -- KurtzPel - Vanguard Combat Suit Set
addappid(1069600) -- KurtzPel - Vanguard Combat Weapon Set
addappid(1071670) -- KurtzPel - Rebirth Ticket
addappid(1092330) -- KurtzPel - Essential Pack
addappid(1099120) -- KurtzPel - Silver Wing Knights Costume Suit
addappid(1099121) -- KurtzPel - Silver Wing Knights Weapon Set
addappid(1099122) -- KurtzPel - Silver Wing Knights Undergarment
addappid(1105360) -- KurtzPel - Karma  Dual Soul
addappid(1112480) -- KurtzPel - Guardian Yakshas Weapon Set
addappid(1112481) -- KurtzPel - Guardian Yakshas Costume Set
addappid(1112482) -- KurtzPel - Guardian Yakshas Undergarment
addappid(1112483) -- KurtzPel - Vanguard Dual Sword
addappid(1112484) -- KurtzPel - Silver Wing Knights Dual Sword
addappid(1112485) -- KurtzPel - Guardian Yakshas Dual Sword
addappid(1120670) -- KurtzPel - Essential Summer Pack
addappid(1132870) -- KurtzPel - Rash Guard Costume Set
addappid(1132871) -- KurtzPel - Hawaiian Beachwear Costume Set
addappid(1132872) -- KurtzPel - Aqua Basic Weapon Set
addappid(1132873) -- KurtzPel - Aqua Dual Sword
addappid(1132920) -- KurtzPel - Gold Ring Swimsuit Costume Set
addappid(1153350) -- KurtzPel - Battlesuit Weapon Set
addappid(1153351) -- KurtzPel - Battlesuit Outfit Set
addappid(1153352) -- KurtzPel - Battlesuit Undergarment
addappid(1153353) -- KurtzPel - Battlesuit Dual Sword
addappid(1170710) -- KurtzPel - Karma  Sacred Guardian
addappid(1170711) -- KurtzPel - Vanguard Giant Hammer
addappid(1170712) -- KurtzPel - Aqua Giant Hammer
addappid(1170713) -- KurtzPel - Battlesuit Giant Hammer
addappid(1170714) -- KurtzPel - Holy Bellatos Costume Set
addappid(1170715) -- KurtzPel - Holy Bellatos Accessory Set
addappid(1170730) -- KurtzPel - Holy Bellatos Giant Hammer
addappid(1170731) -- KurtzPel - Bellatos of Judgment Costume Set
addappid(1170732) -- KurtzPel - Bellatos of Judgment Accessory Set
addappid(1170733) -- KurtzPel - Bellatos of Judgment Giant Hammer
addappid(1179490) -- KurtzPel - Halloween Vampire Basic Weapon Set
addappid(1179491) -- KurtzPel - Halloween Vampire Dual Sword
addappid(1179492) -- KurtzPel - Halloween Vampire Giant Hammer
addappid(1179493) -- KurtzPel - Halloween Vampire Costume Set
addappid(1179494) -- KurtzPel - Halloween Vampire Undergarment
addappid(1187150) -- KurtzPel - King Dragon Basic Weapon Set
addappid(1187151) -- KurtzPel - King Dragon Dual Sword
addappid(1187152) -- KurtzPel - King Dragon Giant Hammer
addappid(1187153) -- KurtzPel - King Dragon Costume Set
addappid(1187154) -- KurtzPel - King Dragon Accessory Set
addappid(1187155) -- KurtzPel - King Dragon Undergarment
addappid(1202010) -- KurtzPel - Christmas Basic Weapon Set
addappid(1202011) -- KurtzPel - Christmas Candy Cane Dual Sword
addappid(1202012) -- KurtzPel - Christmas Gift Giant Hammer
addappid(1202013) -- KurtzPel - Christmas Rudolph Costume Set
addappid(1202014) -- KurtzPel - Christmas Rudolph Accessory Set
addappid(1209900) -- KurtzPel - Essential Winter Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1004220) -- Depot 1004220 (empty depot)
-- addappid(1061700) -- Depot 1061700 (empty depot)