-- Lua provided by SkyAPI 
-- Game: KurtzPel
addappid(844870)
addappid(844871, 1, "eb8ad17673a927da57a2982ebc8737cad0569a22446c56ba81365000da68ff9e")
