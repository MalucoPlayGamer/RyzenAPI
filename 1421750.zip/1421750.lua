-- Lua provided by RyzenAPI
-- Game: addappid(1421750)

-- MAIN APPLICATION
addappid(1421750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421754,0,"4bbd7ccb049456575e8e4181aab1c390586fd4b1d0abeeca96ce5de9b50b55f6")
