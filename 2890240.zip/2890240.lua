-- Lua provided by RyzenAPI
-- Game: Capy Castaway

-- MAIN APPLICATION
addappid(4974190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890240, 1, "fa622450b327b400be3e4ba5e41426c35d5ea7e00b0bc6d0e9c0c7dbb3f80f4f") -- Capy Castaway
addappid(2890241, 1, "3ee6a104752c90fb95351b58b20453f0498280f56c58b43567c0d99612ca0674") -- Depot 2890241
addappid(2890242, 1, "0a2cb2dc2de56a2b31383a5a882ef2176df534d0128940e2114d233cadabe9a0") -- Depot 2890242
addappid(2890244, 1, "003404f610b2dc2dfad47a6f112675b50f61464da66ce0f412e5d1440662c3e8") -- Depot 2890244
addappid(4974190, 1, "7e949d4fa9a76470e0cb282fd7c5a9f6a1df62954ad4f2b1dfd6a5355664adc2") -- Capy Castaway Digital Artbook - Depot 4974190

