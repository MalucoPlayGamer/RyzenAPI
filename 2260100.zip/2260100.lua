-- Lua provided by RyzenAPI
-- Game: Borderwatch: Dark Armada

-- MAIN APPLICATION
addappid(2260100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260101, 1, "aa282465d1a9f1fa9d1a08963d872a6945f7b091c84ed657089965f26a08ec08")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
