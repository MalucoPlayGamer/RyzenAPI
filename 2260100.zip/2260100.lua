-- Lua provided by RyzenAPI
-- Game: Borderwatch: Dark Armada

-- MAIN APPLICATION
addappid(2260100)
-- Game: addappid(2260100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260101, 1, "aa282465d1a9f1fa9d1a08963d872a6945f7b091c84ed657089965f26a08ec08")
