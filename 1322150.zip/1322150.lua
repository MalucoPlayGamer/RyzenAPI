-- Lua provided by RyzenAPI 
-- Game: Undercat Demo
addappid(1322150)
addappid(1322151, 1, "46f255fcefc4bc6dec105885d8e87d3f483c8390a1fedd3c436682c7474573c7")
