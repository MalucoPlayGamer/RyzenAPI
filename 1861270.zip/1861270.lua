-- Lua provided by RyzenAPI
-- Game: 埃拉的呼喚 Demo

-- MAIN APPLICATION
addappid(1861270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861271, 1, "75f6541ffd6a3306de0556dc505992fdfc09a016d267fcacfd5db2cec1d12fbd")

