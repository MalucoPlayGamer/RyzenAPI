-- Lua provided by RyzenAPI
-- Game: 554660

-- MAIN APPLICATION
addappid(554660)
-- Game: addappid(554660)

-- MAIN APP DEPOTS / PACKAGES
addappid(554661, 1, "6a3cb3489701279717e71c33841c49df2b0c58e45e7e17e251dc73426a544bb1")
