-- Lua provided by RyzenAPI
-- Game: addappid(2015730)

-- MAIN APPLICATION
addappid(2015730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015731, 1, "4dab6053d626b0c332719ae6ca467906c149b5e32dbe1d9d894facee2e111f3e")
