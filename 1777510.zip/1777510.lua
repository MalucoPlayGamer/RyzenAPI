-- Lua provided by RyzenAPI
-- Game: Game Pauser by Jase

-- MAIN APPLICATION
addappid(1777510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1777511, 1, "b7416bc6644c6b4918d000ee850df361697c97dff139def664f9ae12a50455f6")

