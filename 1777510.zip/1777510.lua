-- Lua provided by RyzenAPI
-- Game: Game Pauser by Jase

-- MAIN APPLICATION
addappid(1777510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777511, 1, "b7416bc6644c6b4918d000ee850df361697c97dff139def664f9ae12a50455f6")

