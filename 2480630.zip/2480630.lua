-- Lua provided by RyzenAPI
-- Game: MacroWin

-- MAIN APPLICATION
addappid(2480630)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(2480631, 1, "8408ee47e685a2b7e142f2fa292ee030d9e0ccde84ebac3204227142ca6fbc27")

