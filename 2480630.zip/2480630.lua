-- Lua provided by RyzenAPI
-- Game: MacroWin

-- MAIN APPLICATION
addappid(2480630)
-- Game: addappid(2480630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2480631, 1, "8408ee47e685a2b7e142f2fa292ee030d9e0ccde84ebac3204227142ca6fbc27")
