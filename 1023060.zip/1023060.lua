-- Lua provided by RyzenAPI
-- Game: addappid(1023060)

-- MAIN APPLICATION
addappid(1023060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023061, 1, "d6975228161bd96df68fd9af50d223e9715eaf57a97b476148e8cc93cb9f11ab")
