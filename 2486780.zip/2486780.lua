-- Lua provided by SkyAPI 
-- Game: Glaciered Demo
addappid(2486780)
addappid(2486781, 1, "a0705d3680c6e40d3fc41673a76f26a8a01cab2be90be853c44e77db3eba7f05")
