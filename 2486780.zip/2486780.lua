-- Lua provided by RyzenAPI
-- Game: Game: Glaciered Demo

-- MAIN APPLICATION
addappid(2486780)
-- Game: addappid(2486780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486781, 1, "a0705d3680c6e40d3fc41673a76f26a8a01cab2be90be853c44e77db3eba7f05")
