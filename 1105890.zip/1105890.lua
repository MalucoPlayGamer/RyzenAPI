-- Lua provided by RyzenAPI
-- Game: Tilesetter

-- MAIN APPLICATION
addappid(1105890)
-- Game: addappid(1105890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105891, 1, "53af9792f4da827557a58e15dfecc819a024eeb8c8043e7ee16d7b3ea7d14c9a")
