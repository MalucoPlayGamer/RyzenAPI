-- Lua provided by RyzenAPI
-- Game: Game: AppID 1372240

-- MAIN APPLICATION
addappid(1372240)
-- Game: addappid(1372240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372241, 1, "20cbb26e637eada35f7fcfa525fffc8673325d4de271355936970d4688871462")
