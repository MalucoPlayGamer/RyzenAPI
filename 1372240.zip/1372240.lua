-- Lua provided by SkyAPI 
-- Game: AppID 1372240
addappid(1372240)
addappid(1372241, 1, "20cbb26e637eada35f7fcfa525fffc8673325d4de271355936970d4688871462")
