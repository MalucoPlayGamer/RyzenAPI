-- Lua provided by RyzenAPI
-- Game: addappid(3028640)

-- MAIN APPLICATION
addappid(3028640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028641, 1, "e1ae6cf0911ca765ac73099d459abcd1ba1976949c473f63d7cb8cccb517ba6f")
