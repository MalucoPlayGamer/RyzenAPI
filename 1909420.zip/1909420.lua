-- Lua provided by RyzenAPI
-- Game: Tinyfolks

-- MAIN APPLICATION
addappid(1909420)
-- Game: addappid(1909420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909421, 1, "a8f7371a4af993ae2d78fef76fc4c1dcb26235e5f2713294f3688d4897dd077b")
