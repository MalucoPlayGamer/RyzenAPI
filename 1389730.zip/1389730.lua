-- Lua provided by RyzenAPI 
-- Game: AppID 1389730
addappid(1389730)
addappid(1389731, 1, "af59433640c78922b3ea19b0e6ae4441922c7733664ed6efc53d41a761cb2a0c")
