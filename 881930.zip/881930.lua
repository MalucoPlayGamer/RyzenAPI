-- Lua provided by RyzenAPI
-- Game: Business Tycoon Billionaire

-- MAIN APPLICATION
addappid(881930)
-- Game: addappid(881930)

-- MAIN APP DEPOTS / PACKAGES
addappid(881931, 1, "adb5faa850fcc242171ea36965894736a7adbf884443f4c54ecd0bc7c3b00a75")
