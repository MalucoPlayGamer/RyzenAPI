-- Lua provided by SkyAPI 
-- Game: Sex Detective [18+]
addappid(2732510)
addappid(2732511, 1, "be4d1f9b427b79394d504ce78355bb319e552c98cfa4230d83571b2e9789fbce")
