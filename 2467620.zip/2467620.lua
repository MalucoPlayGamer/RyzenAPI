-- Lua provided by RyzenAPI
-- Game: Fear Underground Demo

-- MAIN APPLICATION
addappid(2467620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467621, 1, "56cd183ed02fd9dd23fa2c5268d1762405a7f37de1562270c8c3c2dff36e0dc5")
