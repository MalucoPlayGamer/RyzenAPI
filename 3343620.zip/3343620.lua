-- Lua provided by RyzenAPI
-- Game: Game: AppID 3343620

-- MAIN APPLICATION
addappid(3343620)
-- Game: addappid(3343620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343621, 1, "f9f9cf19e6dc6b86ca758a75dbde5fbe91e985cc9dc1ff69ffcfba9f70c0035e")
