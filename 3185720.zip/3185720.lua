-- Lua provided by RyzenAPI
-- Game: Game: 像素旅人-Pixel Traveler

-- MAIN APPLICATION
addappid(3185720)
-- Game: addappid(3185720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3185721, 1, "60e1d6496df4061c829dd3f469277d399d7214c69cca6ea84608f81818feea34")
