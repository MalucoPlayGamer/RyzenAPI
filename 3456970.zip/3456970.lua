-- Lua provided by RyzenAPI
-- Game: addappid(3456970)

-- MAIN APPLICATION
addappid(3456970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456971, 1, "ad0b84d9b8c443cb10cc5a44ee0876ba2d4bad6fedf185258678719f80302758")
