-- Lua provided by RyzenAPI
-- Game: addappid(2303350)

-- MAIN APPLICATION
addappid(2303350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303351, 1, "e1e5834a839e5d6d19511a78badedf71f87df39381b487d0bf337e5604d59ca0")
addappid(2303352, 1, "9b953b84db48d1acf9b0e66758a8a8fdcbbda684ab8bfceffa73b10e9040b0ff")
