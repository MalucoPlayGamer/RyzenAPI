-- Lua provided by RyzenAPI 
-- Game: Unwelcome
addappid(1838340)
addappid(1838341, 1, "afe2b49ea13db1f8d34c7aef8ad470b35d8dee455e624766b4fa466f440943bb")
