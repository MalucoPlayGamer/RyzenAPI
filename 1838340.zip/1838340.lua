-- Lua provided by RyzenAPI
-- Game: 1838340

-- MAIN APPLICATION
addappid(1838340)
-- Game: addappid(1838340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838341, 1, "afe2b49ea13db1f8d34c7aef8ad470b35d8dee455e624766b4fa466f440943bb")
