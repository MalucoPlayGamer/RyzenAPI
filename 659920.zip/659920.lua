-- Lua provided by RyzenAPI
-- Game: Transports

-- MAIN APPLICATION
addappid(659920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(659921, 1, "a6e56167ad76e8d6c35053b4955a90c4b438fef2ae7d815bdd55115609e41c35")

