-- Lua provided by RyzenAPI
-- Game: Transports

-- MAIN APPLICATION
addappid(659920)
-- Game: addappid(659920)

-- MAIN APP DEPOTS / PACKAGES
addappid(659921, 1, "a6e56167ad76e8d6c35053b4955a90c4b438fef2ae7d815bdd55115609e41c35")
