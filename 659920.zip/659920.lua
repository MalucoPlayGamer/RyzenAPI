-- Lua provided by SkyAPI 
-- Game: Transports
addappid(659920)
addappid(659921, 1, "a6e56167ad76e8d6c35053b4955a90c4b438fef2ae7d815bdd55115609e41c35")
