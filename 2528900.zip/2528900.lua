-- Lua provided by RyzenAPI
-- Game: The CEO Love Me

-- MAIN APPLICATION
addappid(2528900)
addappid(2614740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2528901, 1, "9b711f05ce500e535caef460a7537254c0cb5ed96ef483be3bed30d550b29832")

