-- Lua provided by RyzenAPI
-- Game: The CEO Love Me

-- MAIN APPLICATION
addappid(2528900)
addappid(2614740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2528901, 1, "9b711f05ce500e535caef460a7537254c0cb5ed96ef483be3bed30d550b29832")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
