-- Lua provided by RyzenAPI
-- Game: AppID 1177400

-- MAIN APPLICATION
addappid(1177400)
-- Game: addappid(1177400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177401, 1, "2c80f89e112a29390d650a79c75cb2c0a7251ecca9d6b6dbf52b4f30345a5d80")
