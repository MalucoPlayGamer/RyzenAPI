-- Lua provided by RyzenAPI
-- Game: Chess Pills

-- MAIN APPLICATION
addappid(2016540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016541, 1, "eb6100dd0a7efa133b885d618a6327089dee0bfb049cbe899efba311df3d2e09")
