-- Lua provided by RyzenAPI
-- Game: AppID 990030

-- MAIN APPLICATION
addappid(990030)

-- MAIN APP DEPOTS / PACKAGES
addappid(990031, 1, "ce230fc27d73d88670cfed51b26c7df47e69f8d1a6cf67dfc20519ada7b3ceda")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1096080)
addappid(1096081)
addappid(1115600)
