-- Lua provided by RyzenAPI
-- Game: Deep Diving Simulator

-- MAIN APPLICATION
addappid(990030)
addappid(1096080)
addappid(1096081)
addappid(1115600)

-- MAIN APP DEPOTS / PACKAGES
addappid(990031, 1, "ce230fc27d73d88670cfed51b26c7df47e69f8d1a6cf67dfc20519ada7b3ceda")

