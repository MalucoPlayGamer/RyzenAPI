-- Lua provided by RyzenAPI
-- Game: Dead by Backrooms Anomaly

-- MAIN APPLICATION
addappid(3639500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3639501, 1, "9e161cae8bc58d83c2b1af05b5d4445751a5c4cb4746eb94ea55f1a138a19cdc")
