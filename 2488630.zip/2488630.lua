-- Lua provided by RyzenAPI
-- Game: Game: Mannequin

-- MAIN APPLICATION
addappid(2488630)
-- Game: addappid(2488630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488631, 1, "dbcc0453a042119a66460104f72cb4c2246f6250c5d32b70e9691d871e735d83")
