-- Lua provided by RyzenAPI
-- Game: Game: UfoPilot : The Phadt Menace - Steam Edition

-- MAIN APPLICATION
addappid(1512290)
-- Game: addappid(1512290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512291, 1, "5629f96d4d5f459bcf6e1feeefd9319704a9e58c901f48cf03a5db12a93311f5")
