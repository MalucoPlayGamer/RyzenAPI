-- Lua provided by RyzenAPI
-- Game: Daddy

-- MAIN APPLICATION
addappid(2177030)
-- Game: addappid(2177030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177031, 1, "765256da4629de81c6782301265f4893f0f0a798834ebe8c3fff9f792c0963aa")
