-- Lua provided by SkyAPI 
-- Game: The Madness
addappid(3419720)
addappid(3419721, 1, "32f10e4dedc7cf247aeec1b29b34bf762327a8b6c61ad47d25c603d9948349b8")
