-- Lua provided by RyzenAPI
-- Game: Chrysalis Inc.

-- MAIN APPLICATION
addappid(1919320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1919321, 1, "576942f61ec7e0a81f6e1def5d1d6e1e0dd9d3a9ce8ee80b468a129d78060558")

