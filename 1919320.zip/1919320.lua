-- Lua provided by SkyAPI 
-- Game: Chrysalis Inc.
addappid(1919320)
addappid(1919321, 1, "576942f61ec7e0a81f6e1def5d1d6e1e0dd9d3a9ce8ee80b468a129d78060558")
