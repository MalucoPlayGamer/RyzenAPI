-- Lua provided by RyzenAPI
-- Game: 71340

-- MAIN APPLICATION
addappid(71340)
addappid(200590)
addappid(228983)
addappid(228990)
-- Game: addappid(71340)

-- MAIN APP DEPOTS / PACKAGES
addappid(71341, 1, "e9a94a9cea6b1e07fb4ab98e4186c7af965a32ace868d3ed5bf8151adc2016e0")
