-- Lua provided by SkyAPI 
-- Game: VR Hentai Hot
addappid(1831130)
addappid(1831131, 1, "98f394657223ff7b7706009df974723927f2ec8b6863caa70e6d90887eea23a9")
