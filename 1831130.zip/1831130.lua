-- Lua provided by RyzenAPI
-- Game: Game: VR Hentai Hot

-- MAIN APPLICATION
addappid(1831130)
-- Game: addappid(1831130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831131, 1, "98f394657223ff7b7706009df974723927f2ec8b6863caa70e6d90887eea23a9")
