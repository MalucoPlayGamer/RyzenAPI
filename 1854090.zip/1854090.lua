-- Lua provided by RyzenAPI 
-- Game: Peach Territory
addappid(1854090)
addappid(1854091, 1, "a2097472062995e08423506045af73c67c6534415076052d685c7ccef9efb563")
addappid(1885240, 0, "96ac561b4cf67388992cfde78f5e717760ea1355d9f97dcfb4d9680af6608bd5")
