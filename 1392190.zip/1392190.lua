-- Lua provided by RyzenAPI
-- Game: Rock Paper Sock

-- MAIN APPLICATION
addappid(1392190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392191, 1, "82fdd535e240a286fb6b0052b40a555c48a0f0e1d916359bf114cd2aa60e1f67")

