-- Lua provided by RyzenAPI
-- Game: Card Crawl Adventure Demo

-- MAIN APPLICATION
addappid(2203330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203332,0,"0c2f10533f590316c3d7f8a49c873a2e579b564bb3c8f2f295cb68d42e1a5127")
