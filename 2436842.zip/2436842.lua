-- Lua provided by RyzenAPI
-- Game: RoboCop: Rogue City - Digital Artbook

-- MAIN APPLICATION
addappid(2436842)
-- Game: addappid(2436842)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436842,0,"7429f5a3d4c7fa42b6d594040def2e00bd50c410843d7ac9e33b7f5c70081f6b")
