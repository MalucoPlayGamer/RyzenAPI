-- Lua provided by RyzenAPI
-- Game: Game: AppID 1184500

-- MAIN APPLICATION
addappid(1184500)
-- Game: addappid(1184500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184501, 1, "3e77842d415e92327c245eec7c462113dd8e8a3a12bc69b8607588a21c4496bc")
