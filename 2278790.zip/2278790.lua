-- Lua provided by RyzenAPI
-- Game: Game: Grapple Dogs: Cosmic Canines

-- MAIN APPLICATION
addappid(2278790)
-- Game: addappid(2278790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278791, 1, "51c5d816924aa96e2f7d0ae8d6808b0709ce3a329b67680812edff5bb445d2d4")
