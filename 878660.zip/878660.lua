-- Lua provided by RyzenAPI
-- Game: Build buildings

-- MAIN APPLICATION
addappid(878660)

-- MAIN APP DEPOTS / PACKAGES
addappid(878661, 1, "c4d27f3f21df6d3dd6b744afd88043cdc8b527ee47e8b12a4e4c41246ebf55ec")
