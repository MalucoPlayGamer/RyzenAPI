-- Lua provided by RyzenAPI
-- Game: Occupational Hazards: Episode 1

-- MAIN APPLICATION
addappid(1148980)
-- Game: addappid(1148980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148981, 1, "1a8a60035e95b8e2cdd9755bfba2989b14052b444cae07ba1ed84e6764f0d02c")
