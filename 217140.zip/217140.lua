-- Lua provided by RyzenAPI
-- Game: AppID 217140

-- MAIN APPLICATION
addappid(217140)
addappid(228983)
addappid(228990)
addappid(229002)
-- Game: addappid(217140)

-- MAIN APP DEPOTS / PACKAGES
addappid(217141, 1, "ce7f68c334ffbb4bdbcc87bead275192d0deac89520baa7aa5d0ae9ebc9fc6c2")
