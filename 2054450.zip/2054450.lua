-- Lua provided by RyzenAPI
-- Game: Zombies Midnight

-- MAIN APPLICATION
addappid(2054450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054451, 1, "5e5f4fde352a48a7055e11b1697373f761e07117242166a5f4c50753be5a8851")
