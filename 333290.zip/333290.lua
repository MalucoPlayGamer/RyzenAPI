-- Lua provided by RyzenAPI
-- Game: Mos Speedrun 2

-- MAIN APPLICATION
addappid(333290)

-- MAIN APP DEPOTS / PACKAGES
addappid(333291, 1, "79f0fe6d993baf81e3615695c31c6b8ed4e4b4cb4110d0f496a1059bf73ba746")

