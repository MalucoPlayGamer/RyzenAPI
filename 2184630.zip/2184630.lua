-- Lua provided by RyzenAPI
-- Game: addappid(2184630)

-- MAIN APPLICATION
addappid(2184630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184631, 1, "18e5bd84f06c88f04089e72cc12877ddcc907af6547854e7f63a978ead15eb6f")
