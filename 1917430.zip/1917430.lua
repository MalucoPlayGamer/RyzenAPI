-- Lua provided by RyzenAPI
-- Game: 天狐札记 Demo

-- MAIN APPLICATION
addappid(1917430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917431, 1, "4abaf9142635828d0f3f3172dd43528a76233efa654cfe6f7a8913be0b576a46")

