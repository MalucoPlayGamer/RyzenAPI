-- Lua provided by SkyAPI 
-- Game: Who Dies First ?
addappid(3208550)
addappid(3208551, 1, "fc2bce8517cdcbea08d73c54f385192db2aed880b8931c07329f37667ba051f1")
