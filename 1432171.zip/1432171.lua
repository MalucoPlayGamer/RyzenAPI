-- Lua provided by RyzenAPI
-- Game: addappid(1432171)

-- MAIN APPLICATION
addappid(1432171)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432171,0,"573f74a8ca02661caa16b143706b98269ab7ac1e00f151edfdb5e3d5908c13b0")
