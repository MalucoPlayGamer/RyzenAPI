-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1432171)
-- Game: addappid(1432171)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432171,0,"573f74a8ca02661caa16b143706b98269ab7ac1e00f151edfdb5e3d5908c13b0")
