-- Lua provided by SkyAPI 
-- Game: 【VR】Physical Exam / イタズラ身体測定
addappid(2262110)
addappid(2262111, 1, "00e57558787f0db6d101e7494fc9fe8beed914ce9e666e2d98eae5793a95870b")
