-- Lua provided by RyzenAPI
-- Game: AppID 1116170

-- MAIN APPLICATION
addappid(1116170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116171, 1, "0a8e6d26608d6b4e3848c00bfc00da06c7a7efff396b34bab1820c5ab12fed8b")

