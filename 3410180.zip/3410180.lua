-- Lua provided by RyzenAPI
-- Game: addappid(3410180)

-- MAIN APPLICATION
addappid(3410180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3410181, 1, "33f13a8dd3ec7bd2c9d62b87c7c8019846ea07dbf82abb2bdb3d21ee064b68e7")
