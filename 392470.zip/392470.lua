-- Lua provided by RyzenAPI
-- Game: NOBUNAGA'S AMBITION: Sphere of Influence

-- MAIN APPLICATION
addappid(392470)
addappid(392630)
addappid(392640)
addappid(392641)
addappid(392642)
addappid(392643)
addappid(392644)
addappid(392645)
addappid(392646)
addappid(392647)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(392471, 1, "5f45e75de1f346139e23aa01161a4f06b5dccba1343bfdb88c642ad62c3ce700")

