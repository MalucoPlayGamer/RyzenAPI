-- Lua provided by RyzenAPI
-- Game: Forrader Hero

-- MAIN APPLICATION
addappid(2056490)
-- Game: addappid(2056490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056491, 1, "c8b134679e3ce0d0b62daf4bfa5ad0c12d9b502f15df110b750e18e49ed0439d")
