-- Lua provided by SkyAPI 
-- Game: Forrader Hero
addappid(2056490)
addappid(2056491, 1, "c8b134679e3ce0d0b62daf4bfa5ad0c12d9b502f15df110b750e18e49ed0439d")
