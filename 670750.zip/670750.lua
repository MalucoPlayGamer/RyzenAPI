-- Lua provided by RyzenAPI
-- Game: 0°N 0°W

-- MAIN APPLICATION
addappid(670750)

-- MAIN APP DEPOTS / PACKAGES
addappid(670751, 1, "4d7a9a1cc79e7923967ae00c123b3b9d94eb4f56480a2713a0ea669c8af47133")
addappid(830570, 0, "9279c716e60538a7c5152ce6e7a1e7e35f1d9a1180bd8c8038bdb0ed0d361677")
addappid(835140, 0, "e57c09305b6e1135699dc5340b1118644afef25cf303f201145475554552e95c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
