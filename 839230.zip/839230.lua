-- Lua provided by RyzenAPI 
-- Game: Mr. Sweet
addappid(839230)
addappid(839231, 1, "a12f9046bfd41b8ed00bbc358775da2adb8222bb4a69c839e1668e6f00b6b23d")
