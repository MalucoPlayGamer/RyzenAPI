-- Lua provided by RyzenAPI
-- Game: Mr. Sweet

-- MAIN APPLICATION
addappid(839230)
-- Game: addappid(839230)

-- MAIN APP DEPOTS / PACKAGES
addappid(839231, 1, "a12f9046bfd41b8ed00bbc358775da2adb8222bb4a69c839e1668e6f00b6b23d")
