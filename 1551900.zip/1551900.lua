-- Lua provided by SkyAPI 
-- Game: Alan's Automaton Workshop Demo
addappid(1551900)
addappid(1551901, 1, "9690d418446d202e63b75b32b4094ddf20214ae9a1f5fbcb8d77fd8e56aa3dd3")
