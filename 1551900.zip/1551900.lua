-- Lua provided by RyzenAPI
-- Game: Alan's Automaton Workshop Demo

-- MAIN APPLICATION
addappid(1551900)
-- Game: addappid(1551900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551901, 1, "9690d418446d202e63b75b32b4094ddf20214ae9a1f5fbcb8d77fd8e56aa3dd3")
