-- Lua provided by RyzenAPI
-- Game: Shadows Over Loathing

-- MAIN APPLICATION
addappid(1939160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939162,0,"87b35d1851cb833a062b542380412362da7d34c0a0506c5490bd5426b1b8f870")
addappid(1939163,0,"5050a9e390aa51015705e5a6c6f1184df7ba6ec86f796612af1be3e2e55394fb")

