-- Lua provided by RyzenAPI
-- Game: addappid(2675430)

-- MAIN APPLICATION
addappid(2675430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675432,0,"c82c15684c023ec0a83b5cce240465df7813374cb670fa2be4f65d06b5af9806")
