-- Lua provided by RyzenAPI
-- Game: Queen's Coast Casino - Uncut

-- MAIN APPLICATION
addappid(1289440)
addappid(1570530)
-- Game: addappid(1289440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289441, 1, "87bffbc537d4ec4b8f5144e11dd4335827fb4640e86cd22db60d1759e2bfe7bc")
