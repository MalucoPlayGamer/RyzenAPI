-- Lua provided by RyzenAPI 
-- Game: Paper Trail
addappid(1889740)
addappid(1889741, 1, "fcece0896fc8c4b0e1053c43314190f3215f24d89fc0d83419b5f1c80719618e")
addappid(1889742, 1, "3703162bf6f5e59fbef4d3dd3cb6609ed9a11a2d9da59a7227dd69c0b455ac87")
