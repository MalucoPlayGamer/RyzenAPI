-- Lua provided by RyzenAPI
-- Game: The Darkblade

-- MAIN APPLICATION
addappid(3731570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3731571, 1, "20debd54f8c75ef599025f5f4d056f8b1d41ffb4ac17f6f422af40128934bdfd")

