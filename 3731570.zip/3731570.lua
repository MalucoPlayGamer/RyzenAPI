-- Lua provided by RyzenAPI
-- Game: The Darkblade

-- MAIN APPLICATION
addappid(3731570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3731571, 1, "20debd54f8c75ef599025f5f4d056f8b1d41ffb4ac17f6f422af40128934bdfd")

