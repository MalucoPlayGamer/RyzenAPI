-- Lua provided by RyzenAPI
-- Game: Game: Theseus

-- MAIN APPLICATION
addappid(677330)
-- Game: addappid(677330)

-- MAIN APP DEPOTS / PACKAGES
addappid(677331, 1, "d6b0ec56e49935a6f4fb7473ec1af635d2400117c93df5a578116d61b60a53e4")
