-- Lua provided by SkyAPI 
-- Game: AppID 2027230
addappid(2027230)
addappid(2027231, 1, "750b4b900b6a00b3e4833c92b79491f4ec4adaa76c0e20ed0d79a2fb75707136")
