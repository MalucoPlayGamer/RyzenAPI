-- Lua provided by RyzenAPI
-- Game: AppID 857130

-- MAIN APPLICATION
addappid(857130)

-- MAIN APP DEPOTS / PACKAGES
addappid(857131, 1, "e03c55f3d4d5b99d824e8bcf61c52898b591915d40f75f0e2b24d0b9cba6a3b6")
