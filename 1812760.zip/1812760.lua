-- Lua provided by RyzenAPI
-- Game: Game: 白花 the white flower

-- MAIN APPLICATION
addappid(1812760)
-- Game: addappid(1812760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812761, 1, "aad97c4726b6631f9ee9253466b624d4f783b1360f68e74c4d799aafea0a2b7a")
