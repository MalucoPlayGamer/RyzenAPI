-- 4894010's Lua and Manifest Created by Hubcap Manifest
-- PHANTOM TAG: MANIFEST
-- Created: August 21, 2026 at 11:30:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4894010) -- PHANTOM TAG: MANIFEST
-- MAIN APP DEPOTS
addappid(4894011, 1, "9878250deeecc03b47588baa67cd97ec5cd2aa7ddea8b2c833e62d1a95706438") -- Depot 4894011
setManifestid(4894011, "6153614966157232530", 1170185424)