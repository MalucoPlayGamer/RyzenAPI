-- Lua provided by RyzenAPI
-- Game: 692960

-- MAIN APPLICATION
addappid(692960)
-- Game: addappid(692960)

-- MAIN APP DEPOTS / PACKAGES
addappid(692961, 1, "029d94dc80d16d5a7b5c5de9fc78f975bd64c18d15f13d44a262e22914eaec7b")
