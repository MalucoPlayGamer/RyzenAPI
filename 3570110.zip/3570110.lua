-- Lua provided by RyzenAPI
-- Game: Summoner's Gambit

-- MAIN APPLICATION
addappid(3570110) -- Summoner's Gambit

-- MAIN APP DEPOTS / PACKAGES
addappid(3570111, 1, "ff9de3a74610c416d8fd320dfcb9d1f8fa9874ed3bee931eee92d6cb6d2ec3ec") -- Depot 3570111

