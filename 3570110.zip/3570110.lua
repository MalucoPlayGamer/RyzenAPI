-- 3570110's Lua and Manifest Created by Hubcap Manifest
-- Summoner's Gambit
-- Created: August 07, 2026 at 22:55:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3570110) -- Summoner's Gambit
-- MAIN APP DEPOTS
addappid(3570111, 1, "ff9de3a74610c416d8fd320dfcb9d1f8fa9874ed3bee931eee92d6cb6d2ec3ec") -- Depot 3570111
setManifestid(3570111, "6373718853071169282", 1099715146)