-- Lua provided by RyzenAPI
-- Game: AppID 1978320

-- MAIN APPLICATION
addappid(1978320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978321, 1, "38cc29c0cd3c5a0585b7b36cdb754efd677e1abbac72bcad164ed391dbda1578")

