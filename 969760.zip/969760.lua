-- Lua provided by RyzenAPI
-- Game: 969760

-- MAIN APPLICATION
addappid(969760)
-- Game: addappid(969760)

-- MAIN APP DEPOTS / PACKAGES
addappid(969761, 1, "a7bfd6046fe29a07ab511899cfeb58721b5d3512159fe1d1c2926d38e8f0a2c5")
