-- Lua provided by RyzenAPI
-- Game: YinYang Street Demo

-- MAIN APPLICATION
addappid(2339010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339011, 1, "1b1b497cbf3088a8676f46cd38e6e001c6aeee19479c1f27a945942b1a90c434")
