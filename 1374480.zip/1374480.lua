-- Lua provided by RyzenAPI
-- Game: Game: 爱人 Lover

-- MAIN APPLICATION
addappid(1374480)
-- Game: addappid(1374480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374481, 1, "39419a9f70aef41dc24e06e0fa065bb384b970fea4d3405b3494033cc4af4eb8")
