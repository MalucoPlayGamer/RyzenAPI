-- Lua provided by RyzenAPI
-- Game: Valley Peaks Demo

-- MAIN APPLICATION
addappid(2208970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208971, 1, "c0838ba4106585ff770405aca844fba2e58cb98aff319a9ed4e50ff8aad7a6ba")
