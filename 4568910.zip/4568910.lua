-- 4568910's Lua and Manifest Created by Hubcap Manifest
-- FragMiner
-- Created: July 21, 2026 at 06:17:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4568910) -- FragMiner
-- MAIN APP DEPOTS
addappid(4568911, 1, "e3a4795e124d14ec12e0838a72f1aea5cfc366df7f12ef1652b3d4f153e837e7") -- Depot 4568911
setManifestid(4568911, "4005813643701843490", 112490712)