-- 4706340's Lua and Manifest Created by Hubcap Manifest
-- Bubbly
-- Created: July 22, 2026 at 08:03:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4706340, 1, "9a5d4b2777ed0a5ecb56fa99f31b4c2134c845a9a0d760d519d310b6e5cc41af") -- Bubbly
-- MAIN APP DEPOTS
addappid(4706341, 1, "7b2d45d4caa7024bcd98e9d5a517fd817063475e6a24e314d0e7c0fe95006b4d") -- Depot 4706341
setManifestid(4706341, "3303404007404436050", 169187208)