-- Lua provided by RyzenAPI
-- Game: Game: Remnant Records

-- MAIN APPLICATION
addappid(1916310)
addappid(2781130)
-- Game: addappid(1916310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916311, 1, "c15fc1641b06961cce20b338388106482b2b58047fc4a139aa1c75fe574ef8f6")
