-- Lua provided by RyzenAPI
-- Game: Game: Chrono Rift

-- MAIN APPLICATION
addappid(2303910)
-- Game: addappid(2303910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303911, 1, "6bbf736974125e7c581f3945256d0433a6f281eeccdd09cf70bda5d6cea472f1")
