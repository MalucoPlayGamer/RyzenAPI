-- Lua provided by RyzenAPI
-- Game: Chrono Rift

-- MAIN APPLICATION
addappid(2303910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2303911, 1, "6bbf736974125e7c581f3945256d0433a6f281eeccdd09cf70bda5d6cea472f1")

