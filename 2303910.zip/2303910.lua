-- Lua provided by SkyAPI 
-- Game: Chrono Rift
addappid(2303910)
addappid(2303911, 1, "6bbf736974125e7c581f3945256d0433a6f281eeccdd09cf70bda5d6cea472f1")
