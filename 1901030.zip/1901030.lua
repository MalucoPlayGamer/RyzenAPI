-- Lua provided by RyzenAPI
-- Game: Dungeon Reels Tactics

-- MAIN APPLICATION
addappid(1901030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901031, 1, "f583f05cf2cb3b3a7c5d20f2fde9ef7e325226ac030220860da9e195fc499db9")
