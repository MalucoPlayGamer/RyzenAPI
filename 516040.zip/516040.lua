-- Lua provided by RyzenAPI
-- Game: AppID 516040

-- MAIN APPLICATION
addappid(516040)

-- MAIN APP DEPOTS / PACKAGES
addappid(516041, 1, "ad4c4f8cd6e5765f39990aff22fbff48e2faf8750f3dfba24dd01b99235d7255")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
