-- Lua provided by RyzenAPI
-- Game: 516040

-- MAIN APPLICATION
addappid(516040)
-- Game: addappid(516040)

-- MAIN APP DEPOTS / PACKAGES
addappid(516041, 1, "ad4c4f8cd6e5765f39990aff22fbff48e2faf8750f3dfba24dd01b99235d7255")
