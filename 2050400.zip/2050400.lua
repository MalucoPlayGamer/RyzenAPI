-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Japan

-- MAIN APPLICATION
addappid(2050400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050401, 1, "061975c072ce10d67069baaf9fa8e6a8a1fe562f2fe9e80ba2eb77169246b89c")
