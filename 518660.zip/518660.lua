-- Lua provided by RyzenAPI 
-- Game: AppID 518660
addappid(518660)
addappid(518661, 1, "2dca1b9bc8521104d878243b7f930ddee6423b4d0dbf8df38e4d9257b4372e4f")
