-- Lua provided by RyzenAPI
-- Game: AppID 518660

-- MAIN APPLICATION
addappid(518660)

-- MAIN APP DEPOTS / PACKAGES
addappid(518661, 1, "2dca1b9bc8521104d878243b7f930ddee6423b4d0dbf8df38e4d9257b4372e4f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
