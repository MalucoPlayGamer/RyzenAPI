-- Lua provided by RyzenAPI
-- Game: Game: light path

-- MAIN APPLICATION
addappid(2839790)
-- Game: addappid(2839790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839791, 1, "8fe97d8154158d874607acfafd6ac1862291c20d5408c902a7d1264ffc92eeaa")
