-- Lua provided by RyzenAPI
-- Game: addappid(3023670)

-- MAIN APPLICATION
addappid(3023670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023671, 1, "911c236f28acd9b1a14143ba3d8be7e72cfaddff4c01768797c3c959f4e5fac5")
