-- Lua provided by RyzenAPI
-- Game: Naught Bots

-- MAIN APPLICATION
addappid(1623850)
-- Game: addappid(1623850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623851, 1, "ca26d9955edd7287fead48b0647d623bd1619afab3bb0eecd9c277e6706965a8")
