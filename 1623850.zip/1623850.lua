-- Lua provided by RyzenAPI
-- Game: Naught Bots

-- MAIN APPLICATION
addappid(1623850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1623851, 1, "ca26d9955edd7287fead48b0647d623bd1619afab3bb0eecd9c277e6706965a8")

