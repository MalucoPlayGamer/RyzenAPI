-- Lua provided by SkyAPI 
-- Game: Naught Bots
addappid(1623850)
addappid(1623851, 1, "ca26d9955edd7287fead48b0647d623bd1619afab3bb0eecd9c277e6706965a8")
