-- Lua provided by RyzenAPI
-- Game: BRXKEN INSIDE

-- MAIN APPLICATION
addappid(2186690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186691, 1, "afbc80da095beb2ae45fafb7efa2f7adf9b135f20102e3326fa3446316f59245")

