-- Lua provided by RyzenAPI 
-- Game: BRXKEN INSIDE
addappid(2186690)
addappid(2186691, 1, "afbc80da095beb2ae45fafb7efa2f7adf9b135f20102e3326fa3446316f59245")
