-- Lua provided by RyzenAPI
-- Game: Game: The Backrooms: Expedition

-- MAIN APPLICATION
addappid(3162000)
-- Game: addappid(3162000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3162001, 1, "667d1450e1e7243815f31972c2e791ad614e5b603b222f7e12716b81ae26290b")
