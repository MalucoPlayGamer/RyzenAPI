-- Lua provided by RyzenAPI
-- Game: 798820

-- MAIN APPLICATION
addappid(798820)
-- Game: addappid(798820)

-- MAIN APP DEPOTS / PACKAGES
addappid(798821, 1, "2d998ffa62b3e389fde66834913568b26d0abd0797352f4a9392a5bfc6ddb429")
