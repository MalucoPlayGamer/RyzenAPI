-- Lua provided by RyzenAPI
-- Game: 2181450

-- MAIN APPLICATION
addappid(2181450)
-- Game: addappid(2181450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181451, 1, "ee56be68d61bae28fe5135762564818bd97c128332066cd6a89fbb0321be65c6")
