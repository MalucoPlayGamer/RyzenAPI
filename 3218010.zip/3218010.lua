-- Lua provided by RyzenAPI
-- Game: 少女 X 愛 X 麻將 Demo

-- MAIN APPLICATION
addappid(3218010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3218011, 1, "97eaefa2c6f0965c0e183f45fffdd350c2d2a44e4108388808ed9b09b34771f3")
