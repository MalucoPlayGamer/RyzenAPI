-- Lua provided by RyzenAPI
-- Game: Game: Banana Hunter

-- MAIN APPLICATION
addappid(1903480)
-- Game: addappid(1903480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903481, 1, "4d9e4e0e09640c1444fb921d76d9d026970f11bbaa278dee715c4b6886c93195")
