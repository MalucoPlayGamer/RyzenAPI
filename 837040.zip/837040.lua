-- Lua provided by RyzenAPI
-- Game: Game: AppID 837040

-- MAIN APPLICATION
addappid(837040)
-- Game: addappid(837040)

-- MAIN APP DEPOTS / PACKAGES
addappid(837041, 1, "20ce5cd10dd7f8af83495f0844f591fcbbcf7e7fd4ac9d399d1893987b223bc4")
addappid(837042, 1, "38b8623e694564d71b4120f02178e68b7dbed6381ecc0db7d0e2490c3c2fb7e9")
addappid(837045, 1, "1c75fe3bd724179c638a64e7a3f7dc13cf01aaba76496eeb3c79ed31be14047e")
addappid(837046, 1, "01ad99aaa4db640af329f0a6e949e703c4afb887b83384cef87d7a69b6a2e55c")
addappid(837047, 1, "516eb3fdce7cb9a29bf90661224a4600c34213e233e0fd6f13824ade076e967d")
