-- Lua provided by RyzenAPI
-- Game: Dead Pedal

-- MAIN APPLICATION
addappid(2250160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250161, 1, "7c69213250327ef6d6b5af0ead428d3f34ee38811f4558cd8681badb4c08f23f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
