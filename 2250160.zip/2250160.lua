-- Lua provided by RyzenAPI
-- Game: Dead Pedal

-- MAIN APPLICATION
addappid(2250160)
-- Game: addappid(2250160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250161, 1, "7c69213250327ef6d6b5af0ead428d3f34ee38811f4558cd8681badb4c08f23f")
