-- Lua provided by RyzenAPI
-- Game: Atelier Ryza 3 - Additional Area "Ashra-am Baird Outlying Areas"

-- MAIN APPLICATION
addappid(2156255)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156255,0,"51945db025e75d9d8d3ab8c472a58156fabf726384c7d409e64b8a2ca1b9e11a")
