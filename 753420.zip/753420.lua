-- Lua provided by RyzenAPI
-- Game: Dungreed

-- MAIN APPLICATION
addappid(753420)

-- MAIN APP DEPOTS / PACKAGES
addappid(753421, 1, "a3d04de1c70f4a9559bcbeb3fc09a699bd4777b925b10407e9e66c3c9f6a967c")
addappid(753422, 1, "e8d3859addb15a816b80b52abc1dc55fafe68aad0b803e40f3b316303c0d9ca9")
addappid(753424, 1, "748058b15575371c17a385fffe907be3db514a9059d7187bf6967b0e65deb350")
