-- Lua provided by RyzenAPI
-- Game: League of Maidens

-- MAIN APPLICATION
addappid(557180)
addappid(1484230)
addappid(1484231)
addappid(1484232)
addappid(2618230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(557181, 1, "6673a8517cf661636a10977cc242bec610ee32e553a38c57603bc4cc7280e1ed")
