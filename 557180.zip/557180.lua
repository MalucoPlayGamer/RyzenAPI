-- Lua provided by RyzenAPI
-- Game: addappid(557180)

-- MAIN APPLICATION
addappid(557180)

-- MAIN APP DEPOTS / PACKAGES
addappid(557181, 1, "6673a8517cf661636a10977cc242bec610ee32e553a38c57603bc4cc7280e1ed")
