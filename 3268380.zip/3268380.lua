-- Lua provided by RyzenAPI
-- Game: 双生木 Demo

-- MAIN APPLICATION
addappid(3268380)
-- Game: addappid(3268380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3268381, 1, "cd073f1c30af1bf99db391ed2b6096e2697c04aa296db284e19a86b45c3f5d70")
