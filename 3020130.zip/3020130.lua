-- Lua provided by RyzenAPI
-- Game: 3020130

-- MAIN APPLICATION
addappid(3020130)
-- Game: addappid(3020130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020131, 1, "14054302617bc4156895b69a6adfbfea741f9eb96c5c5bb0b8de8862dc8f8d54")
