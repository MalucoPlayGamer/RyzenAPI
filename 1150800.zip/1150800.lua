-- Lua provided by RyzenAPI
-- Game: Breeza Budgie Bill

-- MAIN APPLICATION
addappid(1150800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150801,0,"76556077b12ada1835a72d09725e2e8c0ee63fdc683a4ed57e07335da3014e64")

