-- Lua provided by RyzenAPI
-- Game: Beat Banger

-- MAIN APPLICATION
addappid(1813430)
-- Game: addappid(1813430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813432,0,"e090f238c1fa9a1fb11219efcf2dcbf2cdd0fa0a71aeb1a4fce85bbdeaed7958")
addappid(1813433,0,"f4348c6ff06847c732db52d9eb8ff6390cbf0b1e149450203a3eeb59de017caa")
addappid(1813434,0,"af400a0b339be84f58d07d25388124333b6b9883b2caca6618fe224144f3162c")
