-- Lua provided by RyzenAPI
-- Game: Hunt: Showdown 1896 - Port Sulphur Band - The Sinners Songbook

-- MAIN APPLICATION
addappid(3389670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3389673,0,"870face54530bc853652e0ab73f45bf7eb5f23c602b2cb8752850b2446a2170b")
addappid(3389674,0,"af42f18bc8ea4a353109bcf32602ce17581d360a5062d426339439d82b5d3014")
