-- Lua provided by RyzenAPI
-- Game: The War of the Worlds: Andromeda

-- MAIN APPLICATION
addappid(910430)
-- Game: addappid(910430)

-- MAIN APP DEPOTS / PACKAGES
addappid(910431, 1, "24ae072e96cccdd81b6ac5a415c534b68abd57eaf8de0176ebdccb3f30c8d23d")
