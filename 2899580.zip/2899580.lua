-- Lua provided by SkyAPI 
-- Game: 3番線 | Sanbansen
addappid(2899580)
addappid(2899581, 1, "035ca8fe1e49026ed01c694ec6ec194cff20359965d02176b7c49fac276632db")
