-- Lua provided by RyzenAPI
-- Game: Game: 3番線 | Sanbansen

-- MAIN APPLICATION
addappid(2899580)
-- Game: addappid(2899580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899581, 1, "035ca8fe1e49026ed01c694ec6ec194cff20359965d02176b7c49fac276632db")
