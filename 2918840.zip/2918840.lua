-- Lua provided by RyzenAPI
-- Game: 2918840

-- MAIN APPLICATION
addappid(2918840)
-- Game: addappid(2918840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918841, 1, "fff72a08b02f0b87e7ab729b82fd5c0c92fa62d12e133a4c341b0de12396dcb1")
