-- Lua provided by RyzenAPI
-- Game: 史莱姆的抉择：The Slime's Choice：TSC

-- MAIN APPLICATION
addappid(2918840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918841, 1, "fff72a08b02f0b87e7ab729b82fd5c0c92fa62d12e133a4c341b0de12396dcb1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
