-- Lua provided by RyzenAPI
-- Game: Midpoint Playtest

-- MAIN APPLICATION
addappid(3403820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3403821, 1, "3241ba51d6a0f38b5aa2570cfffd53fd2f3154a532008843d00ea604cda17740")
