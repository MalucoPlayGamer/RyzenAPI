-- Lua provided by RyzenAPI
-- Game: addappid(1837630)

-- MAIN APPLICATION
addappid(1837630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837631, 1, "a6d7d8fe86ac7321c5c1de4d9e0e70eb7bc0be61d4f135a86a094ae389e6c9cf")
