-- Lua provided by SkyAPI 
-- Game: Box's Dream
addappid(1837630)
addappid(1837631, 1, "a6d7d8fe86ac7321c5c1de4d9e0e70eb7bc0be61d4f135a86a094ae389e6c9cf")
