-- Lua provided by RyzenAPI
-- Game: Dirty Fighter 1

-- MAIN APPLICATION
addappid(674980)
-- Game: addappid(674980)

-- MAIN APP DEPOTS / PACKAGES
addappid(674981, 1, "fde72baeb68431ffe92eeb2025ef88e0d960d3938dadb036f9fdae73b5f20cf1")
