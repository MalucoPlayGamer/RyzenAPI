-- Lua provided by RyzenAPI
-- Game: Dirty Fighter 1

-- MAIN APPLICATION
addappid(674980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(674981, 1, "fde72baeb68431ffe92eeb2025ef88e0d960d3938dadb036f9fdae73b5f20cf1")

