-- Lua provided by RyzenAPI
-- Game: Adventure Climb VR

-- MAIN APPLICATION
addappid(1040430)
addappid(2071880)
-- Game: addappid(1040430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040431, 1, "56b10c2d3675d0893fcebbb7ae1116e9123f2c3de984b0eafbe3e77f6ef939f4")
