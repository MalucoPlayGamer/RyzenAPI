-- Lua provided by RyzenAPI
-- Game: Puzzles At Mystery Manor

-- MAIN APPLICATION
addappid(489890)

-- MAIN APP DEPOTS / PACKAGES
addappid(489891, 1, "a74b3e03e4317a8da8f38a17c2d3d411f99f48f6930579c87b9bf03592cf1e4e")
