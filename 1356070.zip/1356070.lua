-- Lua provided by RyzenAPI
-- Game: Game: 模拟练枪

-- MAIN APPLICATION
addappid(1356070)
-- Game: addappid(1356070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356071, 1, "ab38ff7470c93abf908b7f15b3586f30ab9478854474161689baf060d9534ce8")
