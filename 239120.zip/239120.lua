-- Lua provided by RyzenAPI
-- Game: Final Fantasy III (3D Remake)

-- MAIN APPLICATION
addappid(239120)

-- MAIN APP DEPOTS / PACKAGES
addappid(239121, 1, "7515afd187db98571f0743d86cdcb572feb05944b0bf6990445bdccc4702b054")
addappid(239122, 1, "b52f8ac663e7030a903486f61bc5bd7b3f2a10a3982d0ecb08f09167bd2ce2e3")
addappid(239127, 1, "952a424b8bb7031be5dd6f035828e167605876201c2997bc2df6e04b73427080")
addappid(239128, 1, "6804d618129737a392840575841566b0613ee7a1050091cb6efc3427512c84a7")
addappid(239129, 1, "bb537a8a8721e32e90500c151a3808c06f4b68d47a7f27e0f13e3a351d0506e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
