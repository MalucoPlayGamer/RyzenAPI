-- Lua provided by RyzenAPI
-- Game: Game: God Of Death

-- MAIN APPLICATION
addappid(2643850)
-- Game: addappid(2643850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643851, 1, "1dab725782ff41b61a6d080d98711dfcf6c9517eef124120b8cc128cf0ba4329")
