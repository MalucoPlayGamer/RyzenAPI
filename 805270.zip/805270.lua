-- Lua provided by RyzenAPI
-- Game: Playcraft

-- MAIN APPLICATION
addappid(805270)
addappid(1135520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(805271, 1, "82c17132124a039d4e9c66f7382657c819256a016c1c1a4db0873ac332efe864")

