-- Lua provided by RyzenAPI
-- Game: Game: Kawaii Girls

-- MAIN APPLICATION
addappid(1600260)
-- Game: addappid(1600260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600261, 1, "07b4594dcdbe95b7aeb9ba75069239feaa0b58ed09ffa46ce35f183628414caa")
