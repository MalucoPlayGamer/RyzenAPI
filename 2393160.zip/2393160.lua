-- Lua provided by RyzenAPI
-- Game: addappid(2393160)

-- MAIN APPLICATION
addappid(2393160)
addappid(3473650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393161, 1, "fd1b1e8ba61ee5a6f764f0ca607521e07d765a6dceeb54e0c8ec0aebb47a02a3")
