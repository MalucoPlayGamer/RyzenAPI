-- Lua provided by RyzenAPI
-- Game: Unsolved Case: Above the Law Collector's Edition

-- MAIN APPLICATION
addappid(2602810)
addappid(2605770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602811, 1, "e844b1dfaa23a32d67b1f83245dc3f1f9d7ec480beef1abdbb2ab7f1ad68a096")
