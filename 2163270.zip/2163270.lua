-- Lua provided by RyzenAPI
-- Game: 2163270

-- MAIN APPLICATION
addappid(2163270)
-- Game: addappid(2163270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163271, 1, "ba1fa683a5c4193f719608e524c1475caaa19fd5901cfab8a1d7531dde901ed0")
