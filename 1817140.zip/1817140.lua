-- Lua provided by RyzenAPI 
-- Game: Ending Way
addappid(1817140)
addappid(1817141, 1, "5d128ce607cd75d2f06cdb5bc10ee12254c45f46d29e16238624b398cfa3aa15")
