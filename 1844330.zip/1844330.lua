-- Lua provided by RyzenAPI
-- Game: 1844330

-- MAIN APPLICATION
addappid(1844330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844333,0,"b2d3258661271a891dfcfad22cd2b548a2becb4bba69c23058a7f7c6af382b1e")

