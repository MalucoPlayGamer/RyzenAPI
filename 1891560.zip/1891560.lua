-- Lua provided by RyzenAPI
-- Game: Climax Heroines

-- MAIN APPLICATION
addappid(1891560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1891561, 1, "d20afe3e1884bbffa8954adc12142908301196d14d137998b40fe928af21588e")
addappid(1891562, 1, "0d5e82fb7a54a99c9a34293a7b1bc6614184cc268cf7697f8da8a6fa2ac2a1a5")
addappid(1891563, 1, "06da7ef1eb5e9f85e18f04b92bfdefff04e99f1c4e2a0c844b47faaf183bc3ff")

