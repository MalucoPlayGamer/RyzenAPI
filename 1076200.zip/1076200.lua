-- Lua provided by RyzenAPI
-- Game: Roguebook

-- MAIN APPLICATION
addappid(1076200)
addappid(1518150)
addappid(1518151)
addappid(1518152)
addappid(1518153)
addappid(1704470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076201,0,"50ee1eeed9965f82ead8a6be6c534afef4ac5991a57be019e7c2f479e1442d14")
addappid(1076202,0,"37a9c8bdb3dc21a8955368d58448ee07ec2c23e089ed50893aadef75fd40a7dd")
addappid(1076203,0,"1a13c15ae96dec51ce59c1881ad86035c73e1e83452499a1c74b7e765860a70a")
addappid(1518153,0,"e0201f4c7f897b67ae6e591bc1a50ccd0b583b8dbe427900d97381bb0b47ea08")

