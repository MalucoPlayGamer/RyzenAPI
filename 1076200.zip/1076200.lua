-- Lua provided by RyzenAPI 
-- Game: Roguebook
addappid(1076200)
addappid(1076201, 1, "50ee1eeed9965f82ead8a6be6c534afef4ac5991a57be019e7c2f479e1442d14")
addappid(1076202, 1, "37a9c8bdb3dc21a8955368d58448ee07ec2c23e089ed50893aadef75fd40a7dd")
addappid(1076203, 1, "1a13c15ae96dec51ce59c1881ad86035c73e1e83452499a1c74b7e765860a70a")
