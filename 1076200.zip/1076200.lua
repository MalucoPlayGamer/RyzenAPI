-- Lua provided by RyzenAPI
-- Game: Roguebook

-- MAIN APPLICATION
addappid(1076200)
addappid(1518150)
addappid(1518151)
addappid(1518152)
addappid(1518153)
addappid(1704470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076201,0,"50ee1eeed9965f82ead8a6be6c534afef4ac5991a57be019e7c2f479e1442d14")
addappid(1076202,0,"37a9c8bdb3dc21a8955368d58448ee07ec2c23e089ed50893aadef75fd40a7dd")
addappid(1076203,0,"1a13c15ae96dec51ce59c1881ad86035c73e1e83452499a1c74b7e765860a70a")
addappid(1518153,0,"e0201f4c7f897b67ae6e591bc1a50ccd0b583b8dbe427900d97381bb0b47ea08")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
