-- Lua provided by RyzenAPI
-- Game: Voltage High Society

-- MAIN APPLICATION
addappid(2063480)
-- Game: addappid(2063480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063481, 1, "cd600a63a9234e1797f4c5e30d51c4b224e7f32a3636a2825e16362bb91f70a2")
