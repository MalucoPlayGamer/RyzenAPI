-- Lua provided by RyzenAPI
-- Game: Dreadful River Demo

-- MAIN APPLICATION
addappid(2262720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262721, 1, "a2708383b52ef219753ce5688736dfd5402e71b6b28177a6df5789dc2f0f1af7")
