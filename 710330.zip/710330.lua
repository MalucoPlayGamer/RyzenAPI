-- Lua provided by RyzenAPI
-- Game: 710330

-- MAIN APPLICATION
addappid(710330)
-- Game: addappid(710330)

-- MAIN APP DEPOTS / PACKAGES
addappid(710331, 1, "5a1b14b39b1f5872a9ad25b7e61febef9e65e6ae0244fbe71d6a94f38e288677")
