-- Lua provided by RyzenAPI 
-- Game: AFL 26
addappid(3468640)
addappid(3468641, 1, "54b5a9f3588ad385739af2f66921a9c534d8df0b56643b96b60d5ef37583584d")
