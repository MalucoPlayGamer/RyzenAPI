-- Lua provided by RyzenAPI
-- Game: Game: AFL 26

-- MAIN APPLICATION
addappid(3468640)
-- Game: addappid(3468640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3468641, 1, "54b5a9f3588ad385739af2f66921a9c534d8df0b56643b96b60d5ef37583584d")
