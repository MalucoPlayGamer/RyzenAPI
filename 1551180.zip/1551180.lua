-- Lua provided by RyzenAPI
-- Game: TF Visualizer

-- MAIN APPLICATION
addappid(1551180)
-- Game: addappid(1551180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551181, 1, "dbc46f93f11069ddc8ed3487fd3c390a67af78c29c642dec8326677bbdce45f4")
