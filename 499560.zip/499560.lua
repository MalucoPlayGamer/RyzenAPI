-- Lua provided by RyzenAPI
-- Game: Game: Fourtex Jugo

-- MAIN APPLICATION
addappid(499560)
-- Game: addappid(499560)

-- MAIN APP DEPOTS / PACKAGES
addappid(499561, 1, "c1c86a2c77464b975e089468bf695308039b57f69e44bd659b8a9586a91f16f0")
addappid(499562, 1, "58b977f4584dc97a4048c5b9b05f274ac1026e826a8a19a8e484beef9b57a187")
addappid(499563, 1, "b072a137387ae3cb76a9175bc53d628986eb25056b181ce57bc3be2ac4e8f31b")
