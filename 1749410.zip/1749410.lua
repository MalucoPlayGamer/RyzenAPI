-- Lua provided by RyzenAPI 
-- Game: DARK MAGIC 2
addappid(1749410)
addappid(1749411, 1, "427dd25884d4ddf55be7b68d6c9456daf4cb952c540c5ab71d18f4730c241fb7")
