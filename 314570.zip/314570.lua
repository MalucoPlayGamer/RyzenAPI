-- Lua provided by RyzenAPI
-- Game: The Sun at Night

-- MAIN APPLICATION
addappid(314570)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(314571, 1, "859ae1f76253d2a0f7f2423ed92c111ddf3a69a282c290823bbe64c2595054ff")

