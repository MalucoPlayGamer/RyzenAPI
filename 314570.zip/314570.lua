-- Lua provided by RyzenAPI
-- Game: addappid(314570)

-- MAIN APPLICATION
addappid(314570)

-- MAIN APP DEPOTS / PACKAGES
addappid(314571, 1, "859ae1f76253d2a0f7f2423ed92c111ddf3a69a282c290823bbe64c2595054ff")
