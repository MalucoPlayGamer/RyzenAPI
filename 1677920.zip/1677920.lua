-- Lua provided by RyzenAPI
-- Game: 1677920

-- MAIN APPLICATION
addappid(1677920)
-- Game: addappid(1677920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677921, 1, "fa4dd9ed8c315fe187a1f78715e347d841994cfa9d51a2b4485a54b23e8508ca")
