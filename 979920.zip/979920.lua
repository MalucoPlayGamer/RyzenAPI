-- Lua provided by RyzenAPI
-- Game: Supremacy: 1914

-- MAIN APPLICATION
addappid(979920)
