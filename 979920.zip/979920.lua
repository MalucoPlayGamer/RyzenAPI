-- Lua provided by RyzenAPI
-- Game: Supremacy: 1914

-- MAIN APPLICATION
addappid(979920)
addappid(1004280)
addappid(1004290)
addappid(1004300)
addappid(1004301)

