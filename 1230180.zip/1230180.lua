-- Lua provided by RyzenAPI
-- Game: General Practitioner: Teaching Medicine

-- MAIN APPLICATION
addappid(1230180)
-- Game: addappid(1230180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230180,0,"7a7247ccea9faa3e3ca13adf1830231dde171fbd22294f5cf50bdabac1c18e05")
