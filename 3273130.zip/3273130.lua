-- Lua provided by RyzenAPI
-- Game: 3273130

-- MAIN APPLICATION
addappid(3273130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3273134,0,"beec775ddb2b4a3805c322365a7dbecbeac03b43f7dea07a0462160a78e42093")
