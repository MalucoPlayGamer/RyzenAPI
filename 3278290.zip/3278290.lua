-- Lua provided by RyzenAPI
-- Game: Feed The Pit

-- MAIN APPLICATION
addappid(3278290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278291,0,"b1a6c91368c46d44b4634bb6d0167bf8e9a1fdc37e106ecd00efb5fe70cb0219")

