-- Lua provided by RyzenAPI
-- Game: Seablip Soundtrack

-- MAIN APPLICATION
addappid(2829810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2829811, 1, "a745a9f73abb807db91f94971953df856f0c58a8e7f23851fad890489e791b33")
