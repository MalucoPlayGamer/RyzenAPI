-- Lua provided by RyzenAPI
-- Game: Pets Sniper Shooting

-- MAIN APPLICATION
addappid(1219320)
-- Game: addappid(1219320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219321, 1, "bdab73593126439a2c6b57ccaf761db7bcbf0bd6d072fb114aebd7fc4bad5c1c")
