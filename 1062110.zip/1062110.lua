-- Lua provided by RyzenAPI
-- Game: AppID 1062110

-- MAIN APPLICATION
addappid(1062110)
-- Game: addappid(1062110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062111, 1, "91d28e7fda6e11329087d3281bdc015c6ff473f6184e07e17c8549c0b6161bd3")
