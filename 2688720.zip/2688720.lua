-- Lua provided by RyzenAPI
-- Game: Game: Hidden Cats: Magic Forest

-- MAIN APPLICATION
addappid(2688720)
-- Game: addappid(2688720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2688721, 1, "e7311b39bccce2bce477205e1e85132502079f5c9ffd0ecc5505fabd1b435b9b")
