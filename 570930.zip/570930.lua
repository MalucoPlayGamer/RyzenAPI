-- Lua provided by RyzenAPI
-- Game: addappid(570930)

-- MAIN APPLICATION
addappid(570930)

-- MAIN APP DEPOTS / PACKAGES
addappid(570930,0,"15ff006515b1db59f60da067025006e16a932b51152a1e9410dcf5d3e9fd8a25")
