-- Lua provided by RyzenAPI
-- Game: addappid(3329190)

-- MAIN APPLICATION
addappid(3329190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3329191, 1, "7e89aa8fe9ff09494cc02ab1404c8d656b1826fecd802e294c7d6c44d80fc0fb")
