-- Lua provided by RyzenAPI
-- Game: University King

-- MAIN APPLICATION
addappid(2700620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700621, 1, "bb80622d41fb321b72589bffb7b8869a40b0fa14fb8ea3e733e508bfbbc3a867")

