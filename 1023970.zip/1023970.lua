-- Lua provided by RyzenAPI
-- Game: addappid(1023970)

-- MAIN APPLICATION
addappid(1023970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023971, 1, "e2c0937cd59b4a254618888298b7dee6a14dee81add48eae05516c7cce90b412")
