-- Lua provided by RyzenAPI
-- Game: addappid(209610)

-- MAIN APPLICATION
addappid(209610)

-- MAIN APP DEPOTS / PACKAGES
addappid(209611, 1, "9034fd22d9c4548e268401384be30bb0213631ca7c5be3f56ce8e493f5ccf2ed")
