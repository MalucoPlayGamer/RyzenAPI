-- Lua provided by RyzenAPI
-- Game: Game: Dad's Coming

-- MAIN APPLICATION
addappid(1527350)
-- Game: addappid(1527350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527351, 1, "cc9ac2d35c4d08b8e03f57502936b5c7b32d46ad81ede37993c78bf3feafc3b0")
