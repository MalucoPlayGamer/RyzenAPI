-- Lua provided by RyzenAPI
-- Game: Space Ranger ASK

-- MAIN APPLICATION
addappid(449560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(449561, 1, "5f98e9c3120ef12199834d384b599b007c6f00a3f44bca896716a3ca11965426")

