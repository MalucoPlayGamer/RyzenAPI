-- Lua provided by RyzenAPI
-- Game: Dream celestial body

-- MAIN APPLICATION
addappid(2654570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654571, 1, "818af257d102b12e1509ac820a0a43c6524541d72e9692df79b6948e34ea9d38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
