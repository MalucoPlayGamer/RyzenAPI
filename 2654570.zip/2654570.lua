-- Lua provided by RyzenAPI
-- Game: Game: Dream celestial body

-- MAIN APPLICATION
addappid(2654570)
-- Game: addappid(2654570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654571, 1, "818af257d102b12e1509ac820a0a43c6524541d72e9692df79b6948e34ea9d38")
