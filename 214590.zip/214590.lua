-- Lua provided by SkyAPI 
-- Game: Fairy Bloom Freesia
addappid(214590)
addappid(214591, 1, "4d3220798365174ada8d755dc2bceb965fc2c8977b665b9d2ba9b39b5e44ad32")
addappid(331260, 0, "a1a8b0c9372ff78705848dcd1fa3d7760ab17fdac67f46be942390efbb5b739d")
