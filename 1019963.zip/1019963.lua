-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Xun Yu "Knight Costume" / 荀彧「騎士風コスチューム」

-- MAIN APPLICATION
addappid(1019963)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019963,0,"4626d27594ebea378a66f8d08b917bc3c7faf34de06fc753b2d7018c38d54e7c")

