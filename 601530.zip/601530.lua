-- Lua provided by RyzenAPI
-- Game: Darkarta: A Broken Heart's Quest Collector's Edition

-- MAIN APPLICATION
addappid(228984)
addappid(228990)
addappid(601530)
addappid(601537)
addappid(601538)

-- MAIN APP DEPOTS / PACKAGES
addappid(601536,0,"d4685457b71eb3b83791cdd139a43f00134ba77275250452aa1e30ce639df073")
addappid(601539,0,"ba3c6715239b11f50c563b2d06f74061a8b9ceeaeda833e9a49f8b93f3782320")
addappid(629310,0,"e513c163f67806db3f85dc6fe80826a676649db02efb22bbd2749eb0f4e58934")
