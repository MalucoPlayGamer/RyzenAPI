-- Lua provided by RyzenAPI
-- Game: Game: Cryptid Farm

-- MAIN APPLICATION
addappid(1892140)
-- Game: addappid(1892140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892141, 1, "9a3e4bcb7ee383a8d1fde22c4f94ccec8f457f8aa6adc8f427699a6cc52cf303")
