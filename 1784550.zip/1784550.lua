-- Lua provided by RyzenAPI
-- Game: addappid(1784550)

-- MAIN APPLICATION
addappid(1784550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784551, 1, "a781f588e96e3f797d127e4a8fb09776b6ff81958e8fad97c105b6795b4d222a")
