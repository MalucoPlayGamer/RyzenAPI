-- Lua provided by RyzenAPI
-- Game: SQUID GIRLS 18+

-- MAIN APPLICATION
addappid(1881140)
-- Game: addappid(1881140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881141, 1, "bb0cb3fc095a2551fb84db057aca6ab8750186104c4bf4529221b9abdfc01b51")
