-- Lua provided by RyzenAPI
-- Game: addappid(552960)

-- MAIN APPLICATION
addappid(552960)

-- MAIN APP DEPOTS / PACKAGES
addappid(552961, 1, "c14ed4c87e6a1900299c3af2b5fcafab3630a8bf1a044d382339f75b3a19be43")
