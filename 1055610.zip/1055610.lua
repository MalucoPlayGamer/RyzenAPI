-- Lua provided by SkyAPI 
-- Game: AppID 1055610
addappid(1055610)
addappid(1055611, 1, "a564f8a62b98ed9ac2b6de6fcc2611fc97885d1394c20ef1be4f6b16f598f2f6")
