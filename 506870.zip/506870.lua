-- Lua provided by RyzenAPI
-- Game: Unexplored

-- MAIN APPLICATION
addappid(506870)
addappid(633411)
addappid(639031)
addappid(913921)

-- MAIN APP DEPOTS / PACKAGES
addappid(506871, 1, "6c69cbe96d3cc4e9c7d1418441d9274912e4b6119bfe5fd84732b826baab8494")
addappid(506872, 1, "7313ad1381e6d867b36a8c3214e6ef0780c115819d2317545f6446b6ad0d9046")
addappid(506873, 1, "5845037e2c8fca1a0839799870a6e2069e29de39b8b69cb512f9ed961cc6cc00")
addappid(633410, 0, "4ee1eea324a56174567e70bfb743af59e5f0340f5874f9af8e233b31137ed473")
addappid(639030, 0, "7a99526c12dedd8dd06b5b4ec048b83d2fff1a7e05165c13beee4d532705903d")
addappid(913920, 0, "d479c5021b9f0b2d58709798f862d660d5afb04536d5fa168cebde30ea4ec870")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(613680)
