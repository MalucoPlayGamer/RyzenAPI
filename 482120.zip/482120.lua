-- Lua provided by RyzenAPI
-- Game: 482120

-- MAIN APPLICATION
addappid(482120)
-- Game: addappid(482120)

-- MAIN APP DEPOTS / PACKAGES
addappid(482121, 1, "3ca3c17fbbb1ece432d920b311c24bf0a20799dcb42021e5d8a2d2a2a8f18164")
