-- Lua provided by RyzenAPI
-- Game: addappid(1688310)

-- MAIN APPLICATION
addappid(1688310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688311, 1, "04e51b7b001698d429206d90990099b6c42861d06c7b4fe3cfc0c89d91cf9aee")
