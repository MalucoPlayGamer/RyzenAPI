-- Lua provided by RyzenAPI
-- Game: 2238900

-- MAIN APPLICATION
addappid(2238900)
-- Game: addappid(2238900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2238901, 1, "67cb73b183e7b5251669ae7065e69ae7e541ae57d56e19105e12323adcc2f42e")
