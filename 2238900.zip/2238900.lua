-- Lua provided by RyzenAPI
-- Game: STAR OCEAN THE SECOND STORY R

-- MAIN APPLICATION
addappid(2238900)
addappid(2428850)
addappid(2428851)
addappid(2428852)
addappid(2428853)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2238901, 1, "67cb73b183e7b5251669ae7065e69ae7e541ae57d56e19105e12323adcc2f42e")

