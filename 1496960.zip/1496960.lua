-- Lua provided by RyzenAPI
-- Game: Game: AppID 1496960

-- MAIN APPLICATION
addappid(1496960)
-- Game: addappid(1496960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496961, 1, "283404f893a26cf74d9241fb9478f32654efbab04217edf99e58396d955eaa8d")
addappid(1496962, 1, "e5922efb7b12bbfadf766763259071c1fd58849f825f9e1b0dfdfc6b6b76ac31")
