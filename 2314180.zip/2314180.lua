-- Lua provided by RyzenAPI
-- Game: Game: AppID 2314180

-- MAIN APPLICATION
addappid(2314180)
-- Game: addappid(2314180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314181, 1, "da21ad931a2c28e3aad3a35854e17d122c4fa0f9764abfba40cf200e031ef300")
