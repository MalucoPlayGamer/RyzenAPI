-- Lua provided by RyzenAPI
-- Game: Silent Nights

-- MAIN APPLICATION
addappid(2314180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2314181, 1, "da21ad931a2c28e3aad3a35854e17d122c4fa0f9764abfba40cf200e031ef300")

