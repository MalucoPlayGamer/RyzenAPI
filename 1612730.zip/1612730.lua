-- Lua provided by RyzenAPI
-- Game: GunFu Fighter

-- MAIN APPLICATION
addappid(1612730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612731, 1, "d75d6ad9874019bf4d9496a4abfdbdeaacbb1d8dc9d44064521cc3c8af2b5003")

