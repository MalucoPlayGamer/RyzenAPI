-- Lua provided by RyzenAPI
-- Game: addappid(1477730)

-- MAIN APPLICATION
addappid(1477730)
addappid(1529130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477731, 1, "1b80a6ae76c9ac363e06e6a74d23769492013458f92c2797bca44fc8516b4566")
