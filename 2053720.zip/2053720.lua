-- Lua provided by RyzenAPI
-- Game: Game: Mad Chess Demo

-- MAIN APPLICATION
addappid(2053720)
-- Game: addappid(2053720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053721, 1, "b1626ea3089a97dfff588f6e6fbf8525ac2ac8f498aa92b71b635b16fcbb7d2c")
