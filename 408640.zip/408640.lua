-- Lua provided by RyzenAPI
-- Game: Game: AppID 408640

-- MAIN APPLICATION
addappid(408640)
-- Game: addappid(408640)

-- MAIN APP DEPOTS / PACKAGES
addappid(408641, 1, "a74d6f3fb0b6d87d1dff1c3ee045881e345c3a7a68ac2e0bee8d3e987537150f")
