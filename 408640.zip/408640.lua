-- Lua provided by RyzenAPI
-- Game: CODE OF PRINCESS

-- MAIN APPLICATION
addappid(408640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(408641, 1, "a74d6f3fb0b6d87d1dff1c3ee045881e345c3a7a68ac2e0bee8d3e987537150f")

