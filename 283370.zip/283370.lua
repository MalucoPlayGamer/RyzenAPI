-- Lua provided by RyzenAPI
-- Game: Marine Sharpshooter II: Jungle Warfare

-- MAIN APPLICATION
addappid(283370)
-- Game: addappid(283370)

-- MAIN APP DEPOTS / PACKAGES
addappid(283371, 1, "80fdbf0b968ba3b1406beacf01bdeb0bc3461bfca07c79cd7de605b1fcde8d27")
