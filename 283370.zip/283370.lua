-- Lua provided by RyzenAPI
-- Game: Marine Sharpshooter II: Jungle Warfare

-- MAIN APPLICATION
addappid(283370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(283371, 1, "80fdbf0b968ba3b1406beacf01bdeb0bc3461bfca07c79cd7de605b1fcde8d27")

