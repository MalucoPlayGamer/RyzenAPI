-- Lua provided by SkyAPI 
-- Game: Otherside
addappid(1446420)
addappid(1446421, 1, "6697841ce8988d08a998d8269b108160c3ca6a29bb07311b752a771f3b5a1857")
