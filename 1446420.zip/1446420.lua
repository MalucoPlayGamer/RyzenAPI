-- Lua provided by RyzenAPI
-- Game: Otherside

-- MAIN APPLICATION
addappid(1446420)
-- Game: addappid(1446420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446421, 1, "6697841ce8988d08a998d8269b108160c3ca6a29bb07311b752a771f3b5a1857")
