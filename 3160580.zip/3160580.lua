-- Lua provided by RyzenAPI
-- Game: Trade Conquest

-- MAIN APPLICATION
addappid(3160580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3160581, 1, "17789ab3d4d840be90a638edbe0fc40cba5f38448c3f2e5083ad4e1d7883af66")

