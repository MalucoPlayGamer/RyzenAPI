-- Lua provided by RyzenAPI
-- Game: Game: Trade Conquest

-- MAIN APPLICATION
addappid(3160580)
-- Game: addappid(3160580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3160581, 1, "17789ab3d4d840be90a638edbe0fc40cba5f38448c3f2e5083ad4e1d7883af66")
