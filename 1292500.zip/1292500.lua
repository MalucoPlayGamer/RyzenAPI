-- Lua provided by RyzenAPI
-- Game: AppID 1292500

-- MAIN APPLICATION
addappid(1292500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292501, 1, "52534dd810b76039aac1068984a178df357e9f66e09ce0b1cb3e379fd66cb40b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2972440)
