-- Lua provided by SkyAPI 
-- Game: AppID 1292500
addappid(1292500)
addappid(1292501, 1, "52534dd810b76039aac1068984a178df357e9f66e09ce0b1cb3e379fd66cb40b")
