-- Lua provided by RyzenAPI
-- Game: Partless Ron

-- MAIN APPLICATION
addappid(1560750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560751, 1, "8fd738592c05cc0cfc8c6e50e764e68085a61a6b2430779853e85d747f75120c")
