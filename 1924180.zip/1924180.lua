-- Lua provided by RyzenAPI
-- Game: addappid(1924180)

-- MAIN APPLICATION
addappid(1924180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924181, 1, "c77ef21c05c0594f56440365c538930a455167accd0532f26d1ff957db53ccf2")
