-- Lua provided by RyzenAPI 
-- Game: Phantom Spark
addappid(1924180)
addappid(1924181, 1, "c77ef21c05c0594f56440365c538930a455167accd0532f26d1ff957db53ccf2")
