-- Lua provided by RyzenAPI
-- Game: Randy Blaster 3D

-- MAIN APPLICATION
addappid(1591960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591961, 1, "bf0f37f4979e42462af23c28fc9d86d4e655ce3343dc09502e05487f421de1d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
