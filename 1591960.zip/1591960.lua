-- Lua provided by RyzenAPI
-- Game: 1591960

-- MAIN APPLICATION
addappid(1591960)
-- Game: addappid(1591960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591961, 1, "bf0f37f4979e42462af23c28fc9d86d4e655ce3343dc09502e05487f421de1d6")
