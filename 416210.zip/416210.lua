-- Lua provided by RyzenAPI
-- Game: Game: Block'hood

-- MAIN APPLICATION
addappid(416210)
-- Game: addappid(416210)

-- MAIN APP DEPOTS / PACKAGES
addappid(416211, 1, "b6ad8ea18e6ce21d3448086f9148b497e6dbedcfac83cf47186926d5866baae8")
