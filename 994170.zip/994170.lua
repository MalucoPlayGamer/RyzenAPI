-- Lua provided by RyzenAPI
-- Game: Statue Defender

-- MAIN APPLICATION
addappid(994170)

-- MAIN APP DEPOTS / PACKAGES
addappid(994171, 1, "7d37f2df9329af38530061be62164bb1b2e66187d69b334caadadac6ba9d690a")
