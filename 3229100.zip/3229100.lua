-- Lua provided by RyzenAPI
-- Game: Game: Teenage Mutant Ninja Turtles: Tactical Takedown

-- MAIN APPLICATION
addappid(3229100)
-- Game: addappid(3229100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3229101, 1, "c746340bf45568e7851fe49c2f2f99f13fdd29e7743597ab018cc1a62ee1c503")
