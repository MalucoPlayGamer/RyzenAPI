-- Lua provided by SkyAPI 
-- Game: Teenage Mutant Ninja Turtles: Tactical Takedown
addappid(3229100)
addappid(3229101, 1, "c746340bf45568e7851fe49c2f2f99f13fdd29e7743597ab018cc1a62ee1c503")
