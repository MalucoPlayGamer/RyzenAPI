-- Lua provided by RyzenAPI
-- Game: AppID 1510610

-- MAIN APPLICATION
addappid(1510610)
-- Game: addappid(1510610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510611, 1, "872e1cde93e0bf4150aa9526118160ab8d8b6c8c99ea318f191bdf222c458e5e")
