-- Lua provided by SkyAPI 
-- Game: AppID 1510610
addappid(1510610)
addappid(1510611, 1, "872e1cde93e0bf4150aa9526118160ab8d8b6c8c99ea318f191bdf222c458e5e")
