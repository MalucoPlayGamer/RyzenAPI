-- Lua provided by RyzenAPI
-- Game: Hidden Build Top-Down 3D

-- MAIN APPLICATION
addappid(1915910)
-- Game: addappid(1915910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915911, 1, "b4c786b25b82336aaec4f9aa5c78b0cbc8f54d9affc937d4299e65305f1a64c2")
