-- Lua provided by RyzenAPI
-- Game: Streets of Red : Devil's Dare Deluxe

-- MAIN APPLICATION
addappid(946650)

-- MAIN APP DEPOTS / PACKAGES
addappid(946651, 1, "63ea597b8bd91474332609ac8019262445b844efcf27d5c669a8c5ce0ad0ee7d")
addappid(946652, 1, "17b6bd511104918c080605b7abe289c4b38ce74be21703a3904cd65e160d358e")
addappid(946653, 1, "25fbfc8d1c6256efa566934726432cedc0aa4b48a36414730cff541275ab6d9e")

