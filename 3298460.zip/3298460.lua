-- Lua provided by RyzenAPI
-- Game: Pushing it! Together - Sisyphus Co-op

-- MAIN APPLICATION
addappid(3298460)
-- Game: addappid(3298460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3298461, 1, "ae6787b8a8070514e34870990b3546280cd1594d0c8a6e5c3857bacc39c287f9")
