-- Lua provided by RyzenAPI
-- Game: 3384880

-- MAIN APPLICATION
addappid(3384880)
-- Game: addappid(3384880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3384881, 1, "0b2fda9fdc1f1b4e214030bea7fd07872df1f9bf373684b024e243140dbdf825")
