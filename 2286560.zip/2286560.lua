-- Lua provided by RyzenAPI
-- Game: 2286560

-- MAIN APPLICATION
addappid(2286560)
-- Game: addappid(2286560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286561, 1, "ac358b34d70b33e33d614d54ef9fdd88a01819c9d0b60896afa5dc929ad8a866")
