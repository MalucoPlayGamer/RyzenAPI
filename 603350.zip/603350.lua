-- Lua provided by RyzenAPI
-- Game: Don't cut your hand

-- MAIN APPLICATION
addappid(603350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(603351, 1, "82a2f75c9726b03df60779fdfb4ce861304f42468e3caae99dc74dd10d04aa44")

