-- Lua provided by RyzenAPI
-- Game: Kick-Ass 2

-- MAIN APPLICATION
addappid(304170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(304171, 1, "7b5ad0a6f5a717864420e3d72174595da9cdc299671c7f51601d01e7301311fe")

