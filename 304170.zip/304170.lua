-- Lua provided by SkyAPI 
-- Game: Kick-Ass 2
addappid(304170)
addappid(304171, 1, "7b5ad0a6f5a717864420e3d72174595da9cdc299671c7f51601d01e7301311fe")
