-- Lua provided by RyzenAPI
-- Game: Combat Cat

-- MAIN APPLICATION
addappid(2925730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925731, 1, "843ba45c7d871d9c2d699589f8909b8061a47522b1fb7aec3196794c12277c70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
