-- Lua provided by SkyAPI 
-- Game: Combat Cat
addappid(2925730)
addappid(2925731, 1, "843ba45c7d871d9c2d699589f8909b8061a47522b1fb7aec3196794c12277c70")
