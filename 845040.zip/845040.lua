-- Lua provided by RyzenAPI
-- Game: Aegis Legends

-- MAIN APPLICATION
addappid(845040)
-- Game: addappid(845040)

-- MAIN APP DEPOTS / PACKAGES
addappid(845041, 1, "5c98df5fc4dcece7e0df780491802cf556b60699be1c9969c3b747ee8823fa40")
