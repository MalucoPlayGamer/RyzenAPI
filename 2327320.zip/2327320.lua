-- Lua provided by RyzenAPI
-- Game: Game: Wipe Girls 0

-- MAIN APPLICATION
addappid(2327320)
-- Game: addappid(2327320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327321, 1, "71d6cd6c322262db65d40db43d819022c83bf2fc7955e9f3d5995aaa83ed43b9")
