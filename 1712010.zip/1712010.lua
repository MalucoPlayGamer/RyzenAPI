-- Lua provided by RyzenAPI
-- Game: Matchpoint Demo

-- MAIN APPLICATION
addappid(1712010)
-- Game: addappid(1712010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712011, 1, "3b479128e769bbe2e2661a90dc40a0b0241d57abb9848a88ceeebc0614e60219")
