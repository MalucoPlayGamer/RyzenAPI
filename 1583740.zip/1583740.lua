-- Lua provided by RyzenAPI
-- Game: Suicide Guy Deluxe Edition

-- MAIN APPLICATION
addappid(1583740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583741, 1, "39c29c5cd319a5289be722b9f1b37005fd5826d046e018123d47a0a2031074ef")
addappid(1583742, 1, "b6dcbc662496a7eefe2e6e854dfb10396fc317516650f801d3dfbac2f0f9a33e")
addappid(1583743, 1, "45f50aa7909a62aaff7dbf83218bc1a85fb4c0e568b689735e87eb527068c2a5")
