-- Lua provided by RyzenAPI 
-- Game: PROJECT TACHYON
addappid(2905790)
addappid(2905791, 1, "8f41a9226ab0785dc4ad5763b2076b36932750036b451d81e802d445f6e3996e")
