-- Lua provided by RyzenAPI
-- Game: Game: YOU and ME and HER: A Love Story

-- MAIN APPLICATION
addappid(1293820)
-- Game: addappid(1293820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293821, 1, "1176da3dd5dff5613cc4a3ee5de01bcaa3c0bafaad5da05e5a3c677ddb5d8c43")
addappid(1293822, 1, "507af5d90a51c20c1cd90b867d9b4c918d262d20644d65e5021fd15816c141f7")
addappid(1293823, 1, "aa27c51a92804367933052431b8da114d35cf2e83ba0d1023708a468394dabcb")
