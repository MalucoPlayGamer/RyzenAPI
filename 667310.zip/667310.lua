-- Lua provided by RyzenAPI
-- Game: AppID 667310

-- MAIN APPLICATION
addappid(667310)

-- MAIN APP DEPOTS / PACKAGES
addappid(667311, 1, "a276f028d935abdfa52a6c72c14472caba4e77f3a46f43fe2db684810dd51af4")
