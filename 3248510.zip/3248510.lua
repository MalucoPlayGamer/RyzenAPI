-- Lua provided by RyzenAPI
-- Game: Game: Your wife oh

-- MAIN APPLICATION
addappid(3248510)
-- Game: addappid(3248510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3248511, 1, "d0c11d23609412802e88507651aa8d63cdfc5aecfd8a97b5e787995a2ac707e5")
