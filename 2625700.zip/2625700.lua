-- Lua provided by RyzenAPI
-- Game: addappid(2625700)

-- MAIN APPLICATION
addappid(2625700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625701, 1, "b67a89a2ec50c34726b50b298d8f754c07f9544b7b846e4632aac93d5bb453d0")
