-- Lua provided by RyzenAPI
-- Game: Step By Step

-- MAIN APPLICATION
addappid(2361080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361081, 1, "2e16a1daef7db71a8f801cea335249ef31f1cee2635dc6dafc2d109eb67c2f79")
