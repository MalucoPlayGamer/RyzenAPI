-- Lua provided by RyzenAPI
-- Game: addappid(3242870)

-- MAIN APPLICATION
addappid(3242870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3242871, 1, "cf249cb0bbba7d51782283029f0abe0dde052b455e17b2c7ec583cc7f5dbafa0")
