-- Lua provided by RyzenAPI
-- Game: Sail

-- MAIN APPLICATION
addappid(1684010)
-- Game: addappid(1684010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684011, 1, "79417be054384f46d85104683e86aed77cd2db1df566865286ac267208efc097")
