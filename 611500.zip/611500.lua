-- Lua provided by RyzenAPI
-- Game: Game: Quake Champions

-- MAIN APPLICATION
addappid(611500)
-- Game: addappid(611500)

-- MAIN APP DEPOTS / PACKAGES
addappid(611501, 1, "3e77832feb2c02f7e18ad6c5b24a0e4bd69402c075cd9d1625a5ba0b9bff65e1")
