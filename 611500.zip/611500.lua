-- Lua provided by RyzenAPI
-- Game: Quake Champions

-- MAIN APPLICATION
addappid(611500)
addappid(679310)
addappid(682890)
addappid(750140)
addappid(758540)
addappid(771940)
addappid(874720)
addappid(922310)
addappid(922311)
addappid(922312)
addappid(922313)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(611501,0,"3e77832feb2c02f7e18ad6c5b24a0e4bd69402c075cd9d1625a5ba0b9bff65e1")

