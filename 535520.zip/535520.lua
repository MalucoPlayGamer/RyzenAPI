-- Lua provided by RyzenAPI
-- Game: Game: Nidhogg 2

-- MAIN APPLICATION
addappid(535520)
-- Game: addappid(535520)

-- MAIN APP DEPOTS / PACKAGES
addappid(535521, 1, "c7bde878b201e0ac69b8431c894b333fe26adbd6f6f47455075720c4f29bb7c0")
addappid(535523, 1, "9b4544ad9def191245378605522a34516e54473a1cb0b5b96e71ff718c5105fb")
addappid(683740, 0, "49594b56ff5790ccfaf0950b5f9281cd4f5ef63c826489d16b998addf32478f8")
