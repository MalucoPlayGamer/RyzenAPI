-- Lua provided by RyzenAPI
-- Game: Nidhogg 2

-- MAIN APPLICATION
addappid(535520)

-- MAIN APP DEPOTS / PACKAGES
addappid(535521, 1, "c7bde878b201e0ac69b8431c894b333fe26adbd6f6f47455075720c4f29bb7c0")
addappid(535523, 1, "9b4544ad9def191245378605522a34516e54473a1cb0b5b96e71ff718c5105fb")
addappid(683740, 0, "49594b56ff5790ccfaf0950b5f9281cd4f5ef63c826489d16b998addf32478f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
