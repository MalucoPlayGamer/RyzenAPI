-- Lua provided by RyzenAPI
-- Game: Finger Ninja

-- MAIN APPLICATION
addappid(750040)

-- MAIN APP DEPOTS / PACKAGES
addappid(750041, 1, "e2ca5b1c8d51bd8f66e473ed89900e3e8a1f9d64afa9b91e554603d2d4bd8048")

