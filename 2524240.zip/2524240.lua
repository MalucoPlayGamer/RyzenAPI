-- Lua provided by RyzenAPI
-- Game: Heaven's Dream - DLC01

-- MAIN APPLICATION
addappid(2524240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524240,0,"bde4b9667f5b08504febbedbb0c40e9c37e6968f91287a418f025434edbe12b3")

