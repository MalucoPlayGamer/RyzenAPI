-- Lua provided by RyzenAPI
-- Game: Alder Forge

-- MAIN APPLICATION
addappid(1575590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575593,0,"daa45b2893d1396aee41486a93eb0bbfc6253a23789ebb2397d9eb37e1e95cc0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
