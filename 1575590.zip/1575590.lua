-- Lua provided by RyzenAPI
-- Game: 1575590

-- MAIN APPLICATION
addappid(1575590)
-- Game: addappid(1575590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575593,0,"daa45b2893d1396aee41486a93eb0bbfc6253a23789ebb2397d9eb37e1e95cc0")
