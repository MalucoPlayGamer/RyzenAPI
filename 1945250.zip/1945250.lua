-- Lua provided by RyzenAPI
-- Game: addappid(1945250)

-- MAIN APPLICATION
addappid(1945250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945251, 1, "58e2afec7101d1db3a6fe93deec804625355925861e1a0e26e85d70ea4ce1949")
