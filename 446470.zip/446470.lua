-- Lua provided by RyzenAPI
-- Game: addappid(446470)

-- MAIN APPLICATION
addappid(446470)

-- MAIN APP DEPOTS / PACKAGES
addappid(446471, 1, "4faf0ebc90bd8b82fdb4e33f7b71827973acf9b818e7580d30254e0ae553d41d")
