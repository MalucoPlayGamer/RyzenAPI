-- Lua provided by RyzenAPI
-- Game: New York Taxi Simulator

-- MAIN APPLICATION
addappid(446470)

-- MAIN APP DEPOTS / PACKAGES
addappid(446471, 1, "4faf0ebc90bd8b82fdb4e33f7b71827973acf9b818e7580d30254e0ae553d41d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
