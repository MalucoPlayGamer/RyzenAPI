-- Lua provided by SkyAPI 
-- Game: AppID 2992820
addappid(2992820)
addappid(2992821, 1, "45455e7fcb64a8099b2f1daaa19c18c76f5ac5955b3255187e96c1e1668850fd")
