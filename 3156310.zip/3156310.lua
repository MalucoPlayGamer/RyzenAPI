-- Lua provided by RyzenAPI
-- Game: Skygard Arena Demo

-- MAIN APPLICATION
addappid(3156310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156311, 1, "98fd9c4f85482291bd11da3ca16d637ea363023db4e91dfa16fb560c94743b1c")

