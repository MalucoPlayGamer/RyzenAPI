-- Lua provided by RyzenAPI
-- Game: Game: AppID 285290

-- MAIN APPLICATION
addappid(285290)
-- Game: addappid(285290)

-- MAIN APP DEPOTS / PACKAGES
addappid(285291, 1, "dc9a38e29b1a1e2b2ceb5088290da067d15155c6dbbc0642dba2edfd74d6f86c")
