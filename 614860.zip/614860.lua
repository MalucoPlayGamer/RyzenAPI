-- Lua provided by RyzenAPI
-- Game: XAOC

-- MAIN APPLICATION
addappid(614860)
addappid(650260)
addappid(650261)
addappid(650280)
addappid(695500)
addappid(702330)
addappid(704160)

-- MAIN APP DEPOTS / PACKAGES
addappid(614863,0,"37a610c98714c7eaa61f492ae4bc29e83d3086b97487f4d6e4181d83454ef8b3")

