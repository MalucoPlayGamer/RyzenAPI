-- Lua provided by RyzenAPI
-- Game: 614860

-- MAIN APPLICATION
addappid(614860)
-- Game: addappid(614860)

-- MAIN APP DEPOTS / PACKAGES
addappid(614863,0,"37a610c98714c7eaa61f492ae4bc29e83d3086b97487f4d6e4181d83454ef8b3")
