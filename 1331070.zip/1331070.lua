-- Lua provided by RyzenAPI
-- Game: Game: AppID 1331070

-- MAIN APPLICATION
addappid(1331070)
-- Game: addappid(1331070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331071, 1, "8303279ac1f8e680f4033dbd07f14e8ef289e597d7dabafa6f6d6173a8623eb7")
