-- Lua provided by RyzenAPI 
-- Game: Electronic Shop Simulator
addappid(3711360)
addappid(3711361, 1, "3040b62bfe13f5b1e0ff13a0b15812c96173a3149ce7949624c2941baafc32c5")
