-- Lua provided by RyzenAPI
-- Game: Game: Oil Enterprise

-- MAIN APPLICATION
addappid(353630)
-- Game: addappid(353630)

-- MAIN APP DEPOTS / PACKAGES
addappid(353631, 1, "439e13c26abf9e8f299a44c3bba7061f739bdafcfd7d09337bf759c3e49fa864")
addappid(353632, 1, "e2eeea8eef2cceed91598200053c2b4c6d70b1678254198f7ca0d1745d41dc8e")
addappid(353633, 1, "8a168da237e0aa5dba17dbf59b8885a90e03e6c37eff4ae073db3e435b040548")
addappid(353634, 1, "9a9610101d09ccd1029a971004241ea5ab3b66880e7940fb350137067efc8ace")
addappid(353635, 1, "24c59e4f74dc1991a3a0fdd936d2c3da30525efb1ac25896b5913492a1534eb0")
addappid(353636, 1, "c93f5ee154da9df7a117f26a38515975bb3db4438ebd1b2e7521d2d937f6e85c")
