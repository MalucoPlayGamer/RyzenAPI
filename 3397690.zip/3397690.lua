-- Lua provided by SkyAPI 
-- Game: Westfall
addappid(3397690)
addappid(3397691, 1, "3565b7de51abc33f324d790c092e5b372826bf00f429445d2192d76a269a482c")
