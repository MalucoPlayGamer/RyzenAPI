-- Lua provided by RyzenAPI
-- Game: Westfall

-- MAIN APPLICATION
addappid(3397690)
-- Game: addappid(3397690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3397691, 1, "3565b7de51abc33f324d790c092e5b372826bf00f429445d2192d76a269a482c")
