-- Lua provided by RyzenAPI
-- Game: Lingotopia

-- MAIN APPLICATION
addappid(860640)

-- MAIN APP DEPOTS / PACKAGES
addappid(860641,0,"b0be19b0051a2eae0d6a858be7c004e88cc013faf24c89ebcb2561cb4dff5d1e")

