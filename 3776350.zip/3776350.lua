-- Lua provided by RyzenAPI
-- Game: NEKRO3

-- MAIN APPLICATION
addappid(3776350)
-- Game: addappid(3776350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3776351, 1, "8c70dcf735fc077fb804c4ee8bef27b6e1a70e82e324d58284f43cd35e6d0536")
