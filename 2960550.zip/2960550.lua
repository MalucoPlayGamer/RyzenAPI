-- Lua provided by RyzenAPI
-- Game: addappid(2960550)

-- MAIN APPLICATION
addappid(2960550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2960551, 1, "4f02da55e60d4440f7680a8ab03d519d253f54ca39dc4aa91afa03de04ebfb01")
addappid(2960552, 1, "f171ef2e4d659ccd90a59cd805d817bcb6eba9f67f92b5feef95c1fc74808716")
