-- Lua provided by RyzenAPI 
-- Game: 2MD:VR Football Unleashed ALL✰STAR
addappid(2091930)
addappid(2091931, 1, "96e7b25e1704780ddd8fd2c95fb3f8986e56e900155d7ac05eefafd7dbc831d3")
