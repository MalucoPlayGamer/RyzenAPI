-- Lua provided by RyzenAPI
-- Game: Call of Senpai: Waifu Warfare

-- MAIN APPLICATION
addappid(1786800)
-- Game: addappid(1786800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786801, 1, "38ed54a80400d68b14cefeeddd29fbebc8004244e8727d6b730632f370827e54")
