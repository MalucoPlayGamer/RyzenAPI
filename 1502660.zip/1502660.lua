-- Lua provided by RyzenAPI
-- Game: Untrusted

-- MAIN APPLICATION
addappid(1502660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502661, 1, "1f7312a881c7375e1d486db0d93fb64cccbdfa22f2131176eeae87c059bac30e")
