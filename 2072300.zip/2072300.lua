-- Lua provided by RyzenAPI
-- Game: addappid(2072300)

-- MAIN APPLICATION
addappid(2072300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072301, 1, "b0b24e23890426cbdfa499cbd5ba11ebf6537f6095e5869219c7a2adea6834ad")
