-- Lua provided by RyzenAPI
-- Game: Game: The Grim Gamble / グリムギャンブル

-- MAIN APPLICATION
addappid(3739360)
-- Game: addappid(3739360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3739361, 1, "ddb4860af4740e65d44b719efbe5bc212ac9053636e5f0c7341c245a52819075")
