-- Lua provided by RyzenAPI
-- Game: addappid(2753550)

-- MAIN APPLICATION
addappid(2753550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753553,0,"e8516c5b8349ec10fadae709d3d77d389147b4e9de0e22ee10f48bc3c2bbfbde")
