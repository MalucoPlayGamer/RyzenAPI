-- Lua provided by RyzenAPI
-- Game: AppID 1204740

-- MAIN APPLICATION
addappid(1204740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204741, 1, "d7f9bbc905a3bb9a65332b16a27efa1c40a1a750b0ce4c393dc3acddfa8af09d")
