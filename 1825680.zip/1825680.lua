-- Lua provided by RyzenAPI
-- Game: Game: Gedda Cake Demo

-- MAIN APPLICATION
addappid(1825680)
-- Game: addappid(1825680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825681, 1, "104a919d8f9597a5522df2854d4287f0a9ca5b278680a7588052818c858568e6")
