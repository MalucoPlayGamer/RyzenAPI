-- Lua provided by RyzenAPI
-- Game: addappid(1126850)

-- MAIN APPLICATION
addappid(1126850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126851, 1, "fffa0dadc1b48be223ab5d26b0085054e8263b355bcaf68f30ed72e023c3e7e2")
