-- Lua provided by SkyAPI 
-- Game: AppID 1126850
addappid(1126850)
addappid(1126851, 1, "fffa0dadc1b48be223ab5d26b0085054e8263b355bcaf68f30ed72e023c3e7e2")
