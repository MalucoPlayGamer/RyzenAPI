-- Lua provided by SkyAPI 
-- Game: Poseidon
addappid(2994850)
addappid(2994851, 1, "edec95a81b0f523d9153407fec1117905641b46f836f38162a3ac0caf8eece09")
