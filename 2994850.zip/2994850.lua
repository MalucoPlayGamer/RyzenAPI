-- Lua provided by RyzenAPI
-- Game: Poseidon

-- MAIN APPLICATION
addappid(2994850)
-- Game: addappid(2994850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994851, 1, "edec95a81b0f523d9153407fec1117905641b46f836f38162a3ac0caf8eece09")
