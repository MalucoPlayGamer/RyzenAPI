-- Lua provided by RyzenAPI
-- Game: Poseidon

-- MAIN APPLICATION
addappid(2994850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2994851, 1, "edec95a81b0f523d9153407fec1117905641b46f836f38162a3ac0caf8eece09")

