-- Lua provided by RyzenAPI
-- Game: Cozy Aquarium

-- MAIN APPLICATION
addappid(3476790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3476791, 1, "1c90ae0aa93a71554ac4a07089a0f70e8149c6c357b2392451329e2c73eb0ae4")
