-- Lua provided by RyzenAPI
-- Game: Export Simulator

-- MAIN APPLICATION
addappid(856790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(856791, 1, "28354d3090d2e49666d3cfbf1f617c8dbff545586e149c8a312137bd45defa65")

