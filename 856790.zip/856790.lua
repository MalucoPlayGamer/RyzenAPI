-- Lua provided by RyzenAPI
-- Game: Export Simulator

-- MAIN APPLICATION
addappid(856790)

-- MAIN APP DEPOTS / PACKAGES
addappid(856791, 1, "28354d3090d2e49666d3cfbf1f617c8dbff545586e149c8a312137bd45defa65")

