-- Lua provided by RyzenAPI
-- Game: Bike Mechanic Simulator 2023 Demo

-- MAIN APPLICATION
addappid(2170280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170281, 1, "e4a90c9c25814a546a8abff4ea3892b94d4d75c1cddfd995b5e937676764d6f2")

