-- Lua provided by RyzenAPI
-- Game: Game: Desktop Bowling

-- MAIN APPLICATION
addappid(2193760)
-- Game: addappid(2193760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193761, 1, "0f5e6da2f3d2bcf70b097d72833d0bf00997e7137a2279be93aa51cb77fcf154")
