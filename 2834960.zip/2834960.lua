-- Lua provided by RyzenAPI
-- Game: World of Stickman Demo

-- MAIN APPLICATION
addappid(2834960)
-- Game: addappid(2834960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834961, 1, "5e750da4aef00ab05730433b3aed35d5265f9fbad20b7950b27d503795a634ff")
