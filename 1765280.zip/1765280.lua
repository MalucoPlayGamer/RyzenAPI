-- Lua provided by SkyAPI 
-- Game: Pleim
addappid(1765280)
addappid(1765281, 1, "3b88636ab2858eeb9b04152e343a3a2a004bc5fdae801798d061e7c1656e0eba")
