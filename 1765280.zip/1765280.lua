-- Lua provided by RyzenAPI
-- Game: Game: Pleim

-- MAIN APPLICATION
addappid(1765280)
-- Game: addappid(1765280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765281, 1, "3b88636ab2858eeb9b04152e343a3a2a004bc5fdae801798d061e7c1656e0eba")
