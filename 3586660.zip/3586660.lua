-- Lua provided by RyzenAPI
-- Game: Game: Word Play

-- MAIN APPLICATION
addappid(3586660)
-- Game: addappid(3586660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586661, 1, "4f1667feeacbd336630460f2ae039beecb8d251babd41cb4141feee56ab46032")
