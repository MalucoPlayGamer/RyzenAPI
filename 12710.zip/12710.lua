-- Lua provided by RyzenAPI
-- Game: Game: Overlord™: Raising Hell

-- MAIN APPLICATION
addappid(12710)
-- Game: addappid(12710)

-- MAIN APP DEPOTS / PACKAGES
addappid(12711, 1, "6f7705b9a87154362430033353b5fda3e5cdb75c88b004a707c7c34f4ef74365")
addappid(12712, 1, "245f65067ee671daab6ae1c54c2082c39ced407a27efcfc5d6c4cb8e470a5d1d")
addappid(12713, 1, "354e2b10021882d688e3106438df00d0fc964fbd5ca5b66b019bc24bf6f2a42f")
addappid(12714, 1, "28ae89ac0751f80543072543ba378f947257df8ded55efe926e1b958cc6eaf7f")
addappid(12715, 1, "459f8cd763cf828b603887bef64c0ed2d00e896ce4bda0dbdbccd5d79e5b38ea")
addappid(12716, 1, "d1849bc79863703f70ae173c6f67467754b91d2adcd8c05ca2adc408f98b3426")
