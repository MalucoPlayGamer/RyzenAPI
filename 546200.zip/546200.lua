-- Lua provided by RyzenAPI
-- Game: Game: Gnomes Garden 3: The thief of castles

-- MAIN APPLICATION
addappid(546200)
-- Game: addappid(546200)

-- MAIN APP DEPOTS / PACKAGES
addappid(546201, 1, "0adba1881bafe63452fbb7e656eb80114fb2d6c6dd16e26a56b1adadf1f949ce")
