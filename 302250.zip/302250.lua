-- Lua provided by RyzenAPI
-- Game: Manhunter

-- MAIN APPLICATION
addappid(302250)

-- MAIN APP DEPOTS / PACKAGES
addappid(302251, 1, "04732ac5fa66b91e03a51464c655aaea14e619b3964c8d7a2822a0b15c0b3166")
