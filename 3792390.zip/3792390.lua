-- Lua provided by RyzenAPI
-- Game: Trials of Mana Remake Original Soundtrack

-- MAIN APPLICATION
addappid(3792390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3792391, 1, "1da984acc9ca5e652a5bb43b519eb4ea6e2efe910ba30c5d468bb5f417868198")

