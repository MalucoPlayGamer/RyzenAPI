-- Lua provided by RyzenAPI
-- Game: Hot Office: Sex Story 🔞

-- MAIN APPLICATION
addappid(2727440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727441, 1, "ca6b5387f331a18c36ab30258678ccabe51e0e0a5ec09566d425d4eecf8ddffe")
