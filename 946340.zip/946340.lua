-- Lua provided by RyzenAPI
-- Game: Game: LOST CAVE

-- MAIN APPLICATION
addappid(946340)
-- Game: addappid(946340)

-- MAIN APP DEPOTS / PACKAGES
addappid(946341, 1, "26f222dcc2cb206775b5c7b2c1d543acc448b2922f8ae94bd7ba1bd1dbd64ad2")
