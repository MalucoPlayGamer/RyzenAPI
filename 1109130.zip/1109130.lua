-- Lua provided by RyzenAPI
-- Game: 1109130

-- MAIN APPLICATION
addappid(1109130)
-- Game: addappid(1109130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1109131, 1, "5060cc8a934e47349ee67a071e9a22964c8f0df7e7a9c59e42dadeea97d72c8c")
