-- Lua provided by RyzenAPI
-- Game: addappid(1838363)

-- MAIN APPLICATION
addappid(1838363)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838363,0,"390f6947bf5c4d935e4c5ec0161d955b79cbc53bce8e0bcc9a813a8a3cda60b8")
