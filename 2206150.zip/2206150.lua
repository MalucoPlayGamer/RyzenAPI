-- Lua provided by RyzenAPI
-- Game: Hot And Lovely ：Charm

-- MAIN APPLICATION
addappid(2206150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206151, 1, "ee95042ca80742ea6309818c5f2342bc2fd6fcb42fdbc2f9bc11c4bd46f27598")
addappid(2221720, 0, "3514222fe0ab8950f1320f475916c2015c8c2a3c004346b8fb82e8919ca72e0f")

