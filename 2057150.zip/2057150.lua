-- Lua provided by RyzenAPI
-- Game: Tower Escape Demo

-- MAIN APPLICATION
addappid(2057150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057151, 1, "3da0402a8ef116a07132d9674a0ca09985ec49a87f85002c6e9a0e56f7416458")
