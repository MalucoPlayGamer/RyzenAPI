-- Lua provided by RyzenAPI
-- Game: addappid(2689500)

-- MAIN APPLICATION
addappid(2689500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2689501, 1, "2ff1e1fdf85f8282b4e48e0596e17724c300586ade32f279494cdec2a59ec64e")
