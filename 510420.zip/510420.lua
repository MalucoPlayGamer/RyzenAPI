-- Lua provided by RyzenAPI
-- Game: AppID 510420

-- MAIN APPLICATION
addappid(510420)
-- Game: addappid(510420)

-- MAIN APP DEPOTS / PACKAGES
addappid(510421, 1, "1b8becb9f94f907abf7a2fb7cf0edc16e1784987549d98c1319a7366b8149a06")
addappid(510422, 1, "cdb5a1fdf0a15f35fb5f942d3f3449a2ff09f5ce472f9daa4cb63f34f198b48d")
addappid(510423, 1, "76d6917d1bf20358b902bdfc4f4136edad4f9d508862db517ab80b11f85b65dc")
