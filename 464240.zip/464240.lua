-- Lua provided by RyzenAPI
-- Game: 464240

-- MAIN APPLICATION
addappid(464240)
-- Game: addappid(464240)

-- MAIN APP DEPOTS / PACKAGES
addappid(464241, 1, "d036a03c97ffe192a09bf3633a06eea3e135c392c46c4c15b1bfd097941ee735")
