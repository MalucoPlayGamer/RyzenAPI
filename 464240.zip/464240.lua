-- Lua provided by RyzenAPI
-- Game: Detective Hunt - Crownston City PD

-- MAIN APPLICATION
addappid(464240)

-- MAIN APP DEPOTS / PACKAGES
addappid(464241, 1, "d036a03c97ffe192a09bf3633a06eea3e135c392c46c4c15b1bfd097941ee735")

