-- Lua provided by RyzenAPI
-- Game: The hardest game in the universe 2-New songs

-- MAIN APPLICATION
addappid(2827320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827320,0,"c1386e5977a680e9f11cd206844898ce35359d2200b68f583b55735b87a2b9c7")

