-- Lua provided by RyzenAPI
-- Game: Penko Park

-- MAIN APPLICATION
addappid(852090)

-- MAIN APP DEPOTS / PACKAGES
addappid(852091, 1, "bb5ce402c7bc3f67bc237ecde0a948e3518c2611e93b26c615e5e1522dbd16ca")
