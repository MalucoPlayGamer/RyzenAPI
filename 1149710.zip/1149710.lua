-- Lua provided by RyzenAPI
-- Game: Tesla Force

-- MAIN APPLICATION
addappid(1149710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1149711, 1, "794855333ba41d1668da57050f62e5346547eedca0f9e07fb33b9103a4de951a")

