-- Lua provided by RyzenAPI
-- Game: addappid(1149710)

-- MAIN APPLICATION
addappid(1149710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149711, 1, "794855333ba41d1668da57050f62e5346547eedca0f9e07fb33b9103a4de951a")
