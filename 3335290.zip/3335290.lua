-- Lua provided by RyzenAPI 
-- Game: AppID 3335290
addappid(3335290)
addappid(3335291, 1, "5ae4f0d2ee5daa776bb6c12cfcd44af04129fcfac9f4e18ab2f3a2a357c319b5")
