-- Lua provided by RyzenAPI
-- Game: 3335290

-- MAIN APPLICATION
addappid(3335290)
-- Game: addappid(3335290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3335291, 1, "5ae4f0d2ee5daa776bb6c12cfcd44af04129fcfac9f4e18ab2f3a2a357c319b5")
