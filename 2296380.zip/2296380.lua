-- Lua provided by RyzenAPI
-- Game: I Expect You To Die 3: Cog in the Machine

-- MAIN APPLICATION
addappid(2296380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296381, 1, "5c56adfc0430f57a91fa5aebc3a3c15287fb45dbcb682242543654f0095b0d80")

