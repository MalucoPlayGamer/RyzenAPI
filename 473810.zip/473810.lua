-- Lua provided by RyzenAPI 
-- Game: AppID 473810
addappid(473810)
addappid(473811, 1, "aeb6d8e7c7269085e56d6170116fe557387e868c4ffda17e9c165909652b30f1")
