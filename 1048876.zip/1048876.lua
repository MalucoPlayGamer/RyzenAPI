-- Lua provided by RyzenAPI
-- Game: Beat Saber - Stonebank - "Stronger (feat. Emel)"

-- MAIN APPLICATION
addappid(1048876)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048876,0,"932aeb970c6d75812d576c0473e1cd0cda8ab6d9fd153b6bc8b644aaf2d54134")

