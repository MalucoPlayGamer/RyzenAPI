-- Lua provided by RyzenAPI
-- Game: Juicy Army: Prologue

-- MAIN APPLICATION
addappid(1153060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153061, 1, "57cfef729cc7f90d5a58eac5fe089956333ed59b47acc1efa4017acf1cbcf5af")
