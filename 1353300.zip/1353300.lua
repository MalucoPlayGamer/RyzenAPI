-- Lua provided by RyzenAPI
-- Game: AppID 1353300

-- MAIN APPLICATION
addappid(1353300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353301, 1, "f91d768e30ad4481e09f9c4069c812642eb5f5721f043726cb1d46b6ccaacd21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
