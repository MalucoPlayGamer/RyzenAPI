-- Lua provided by RyzenAPI
-- Game: 1353300

-- MAIN APPLICATION
addappid(1353300)
-- Game: addappid(1353300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353301, 1, "f91d768e30ad4481e09f9c4069c812642eb5f5721f043726cb1d46b6ccaacd21")
