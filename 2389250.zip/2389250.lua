-- Lua provided by RyzenAPI
-- Game: MailPop

-- MAIN APPLICATION
addappid(2389250)
-- Game: addappid(2389250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389251, 1, "5f3c6129c7b946749db39f32979ada9896d5f4c174558db59ed38f6e69fc0598")
