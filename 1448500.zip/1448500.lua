-- Lua provided by RyzenAPI
-- Game: Game: Star Dynasties Demo

-- MAIN APPLICATION
addappid(1448500)
-- Game: addappid(1448500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448501, 1, "860f0b2f9eb6a733c0182cc030dab642407db26996c0d5e05795a0ac1909cdd7")
