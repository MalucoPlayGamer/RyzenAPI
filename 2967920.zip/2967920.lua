-- Lua provided by RyzenAPI
-- Game: 2967920

-- MAIN APPLICATION
addappid(2967920)
-- Game: addappid(2967920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967921, 1, "dbfad17db53b23804ed7dc4435d7096aa8ee46bdf644032706ede801df2abf74")
