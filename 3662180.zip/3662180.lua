-- Lua provided by RyzenAPI
-- Game: Omanah

-- MAIN APPLICATION
addappid(3662180)
-- Game: addappid(3662180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3662181, 1, "e6ecf095cf19d031bcb7c6a49b4cff617ea226fee3c07642e2b45adb35015c59")
