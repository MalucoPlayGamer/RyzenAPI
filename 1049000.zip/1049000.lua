-- Lua provided by RyzenAPI
-- Game: Chronoraptor

-- MAIN APPLICATION
addappid(1049000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049002,0,"a9159f52a657e3b8dd8c5de6e61eb2e585d7fd6e49d634ded15fca493e1162d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
