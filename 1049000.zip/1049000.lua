-- Lua provided by RyzenAPI
-- Game: 1049000

-- MAIN APPLICATION
addappid(1049000)
-- Game: addappid(1049000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049002,0,"a9159f52a657e3b8dd8c5de6e61eb2e585d7fd6e49d634ded15fca493e1162d0")
