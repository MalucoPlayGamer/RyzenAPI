-- Lua provided by RyzenAPI
-- Game: My Life In A Monster Girl Paradise Demo

-- MAIN APPLICATION
addappid(2736510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736511, 1, "d06b376c93c7d4a9c20f0f6eb9f3b740cdd591bdc01b375d693eef6122e76b29")

