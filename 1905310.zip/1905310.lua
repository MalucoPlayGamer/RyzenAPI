-- Lua provided by RyzenAPI
-- Game: addappid(1905310)

-- MAIN APPLICATION
addappid(1905310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905311, 1, "db5db86ede013246c59cfd935e4b979319c8f8245b9b18a633120967c95dc9fa")
