-- Lua provided by RyzenAPI
-- Game: Asterix & Obelix Slap Them All! 2

-- MAIN APPLICATION
addappid(2360250)
-- Game: addappid(2360250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360251, 1, "b7185423149cdba7d25f0e1077bf81dc2fce56efec82ffad9a1bec65a7a4ed5b")
