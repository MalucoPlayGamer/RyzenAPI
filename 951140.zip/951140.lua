-- Lua provided by RyzenAPI
-- Game: addappid(951140)

-- MAIN APPLICATION
addappid(951140)
addappid(1004630)

-- MAIN APP DEPOTS / PACKAGES
addappid(951141, 1, "3ec1cb6f46edb38745f4cc6a8333e387b7a6c144e7ec881654ab089048f215b0")
