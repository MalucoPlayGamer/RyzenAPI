-- Lua provided by RyzenAPI
-- Game: Super Jigsaw Puzzle: Cities

-- MAIN APPLICATION
addappid(862110)

-- MAIN APP DEPOTS / PACKAGES
addappid(862111, 1, "a7eb424c63aab79e5ee796d2c6eb13461620cc9d19ccfbffbb54709f6a80e786")
addappid(1056620, 0, "1893eb85fa4e7d3647161c659301b90f460d38dda25470566bd3e3a89d3a3212")

