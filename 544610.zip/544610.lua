-- Lua provided by RyzenAPI
-- Game: AppID 544610

-- MAIN APPLICATION
addappid(544610)
-- Game: addappid(544610)

-- MAIN APP DEPOTS / PACKAGES
addappid(544611, 1, "8218309c22098c48817733fcb6cd6ce958cb65bd67963da1e84ccf1c5ab41f3d")
