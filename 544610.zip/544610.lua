-- Lua provided by RyzenAPI
-- Game: Battlestar Galactica Deadlock

-- MAIN APPLICATION
addappid(544610)
addappid(692080)
addappid(726560)
addappid(879240)
addappid(1001150)
addappid(1083890)
addappid(1143820)
addappid(1315350)
addappid(1353080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(544611, 1, "8218309c22098c48817733fcb6cd6ce958cb65bd67963da1e84ccf1c5ab41f3d")
