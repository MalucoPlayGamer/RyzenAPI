-- Lua provided by RyzenAPI
-- Game: Game: AppID 688740

-- MAIN APPLICATION
addappid(688740)
-- Game: addappid(688740)

-- MAIN APP DEPOTS / PACKAGES
addappid(688741, 1, "3f7ec0c49bb0a32bef77730fe1a925c1f74a3e46296c8bed8ffeef10d9bce2ee")
