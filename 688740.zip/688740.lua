-- Lua provided by RyzenAPI 
-- Game: AppID 688740
addappid(688740)
addappid(688741, 1, "3f7ec0c49bb0a32bef77730fe1a925c1f74a3e46296c8bed8ffeef10d9bce2ee")
