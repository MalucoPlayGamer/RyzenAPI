-- Lua provided by RyzenAPI
-- Game: The Dead City

-- MAIN APPLICATION
addappid(2166290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166291, 1, "d727ea227d6f5ef143e976fb86a02871452db9ff4336c071dfc1d1feb91a7571")

