-- Lua provided by RyzenAPI 
-- Game: n2222
addappid(1733140)
addappid(1733141, 1, "0f74a0f0ef6d16003f560414e8875e6360a12dd1dae56110b246363cf55677df")
