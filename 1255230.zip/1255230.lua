-- Lua provided by RyzenAPI
-- Game: Saranity

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(229000)
addappid(1255230)
addappid(1255231)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255233,0,"a91dc2aa4e931d86b74349c7130d27f001bf7bdacd8e80c9a0436017cf0d5dff")

