-- Lua provided by RyzenAPI
-- Game: Game: Still be a Human

-- MAIN APPLICATION
addappid(1896810)
-- Game: addappid(1896810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896811, 1, "d90938ed694ab164e36f61ee068f507fdf6d8f77911f9e75d1933b5d07453376")
