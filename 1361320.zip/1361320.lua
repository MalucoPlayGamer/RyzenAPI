-- Lua provided by RyzenAPI
-- Game: The Room 4: Old Sins

-- MAIN APPLICATION
addappid(1361320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361321, 1, "2131923e63354f700e55aed8daf3fffe5e05e516cc4cb247d0130020f94e8219")
