-- Lua provided by RyzenAPI
-- Game: Terminal ESC

-- MAIN APPLICATION
addappid(2809460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809461, 1, "1ad3d3efdc7dd4ce85520bee0e96aa91e5804c06359f8f89c05074914a1e3541")
addappid(2809462, 1, "842e35784570995cea771cf22d296e6caa999c7747f63fcb32dfd1b7fb007b9e")

