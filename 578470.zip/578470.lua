-- Lua provided by RyzenAPI
-- Game: AppID 578470

-- MAIN APPLICATION
addappid(578470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(578471, 1, "9a05536efe1cdf1f4108b9491eb7507df9df5d65c67ce9b8aa11fb75767071d5")

