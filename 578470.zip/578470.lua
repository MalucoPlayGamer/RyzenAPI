-- Lua provided by RyzenAPI
-- Game: 578470

-- MAIN APPLICATION
addappid(578470)
-- Game: addappid(578470)

-- MAIN APP DEPOTS / PACKAGES
addappid(578471, 1, "9a05536efe1cdf1f4108b9491eb7507df9df5d65c67ce9b8aa11fb75767071d5")
