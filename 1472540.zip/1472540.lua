-- Lua provided by RyzenAPI
-- Game: Game: Save me Mr Tako: Definitive Edition

-- MAIN APPLICATION
addappid(1472540)
-- Game: addappid(1472540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472541, 1, "2a478ac2312e7c27687a1ed1598b9d0523ef763ad60eb421fa4bc7c0c3fa270f")
