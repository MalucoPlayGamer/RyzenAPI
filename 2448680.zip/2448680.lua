-- Lua provided by RyzenAPI
-- Game: addappid(2448680)

-- MAIN APPLICATION
addappid(2448680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448681, 1, "0264ef11335260858246bae24de9cfa3be12783c4045033ce0231e6a6f9c7ee5")
