-- Lua provided by RyzenAPI
-- Game: Duck Life 7: Battle

-- MAIN APPLICATION
addappid(914170)

-- MAIN APP DEPOTS / PACKAGES
addappid(914171, 1, "2040e2c20099af3f63051ef0990c0e303e806aa94c3dcd28867ee3c0c0f7de6a")
