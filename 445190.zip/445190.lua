-- Lua provided by RyzenAPI 
-- Game: Expeditions: Viking
addappid(445190)
addappid(445191, 1, "682d06a2c1a5f09369743113b9daba8518c52793f48dcbe1f6a19341450bc871")
addappid(592820, 0, "9b7c56d46d045a76b3df540940245fcaa94aa8ff0a4cf4058b75caa9da55da0f")
