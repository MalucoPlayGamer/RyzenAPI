-- Lua provided by RyzenAPI
-- Game: flappy dragoon

-- MAIN APPLICATION
addappid(2278800)
-- Game: addappid(2278800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278802,0,"c43176ed7266f26f2f662f1a207e59e326a45a6e093cf0e7e0057266c112500f")
