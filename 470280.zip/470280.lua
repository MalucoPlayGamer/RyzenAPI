-- Lua provided by RyzenAPI
-- Game: Game: Lost Route

-- MAIN APPLICATION
addappid(470280)
-- Game: addappid(470280)

-- MAIN APP DEPOTS / PACKAGES
addappid(470281, 1, "8fdb1264f7c0073cdfc18be24d00ea10703fe3a9a846da5338e38b30283c99ba")
