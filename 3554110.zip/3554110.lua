-- Lua provided by RyzenAPI
-- Game: 3554110

-- MAIN APPLICATION
addappid(3554110)
-- Game: addappid(3554110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3554111, 1, "ee4701b923b8bc706fc84f5ce3271d25416aefa3b852235bf1f19dff75a1b73e")
