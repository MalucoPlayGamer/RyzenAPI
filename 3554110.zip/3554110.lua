-- Lua provided by RyzenAPI
-- Game: Scrap Dealer Simulator

-- MAIN APPLICATION
addappid(3554110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3554111, 1, "ee4701b923b8bc706fc84f5ce3271d25416aefa3b852235bf1f19dff75a1b73e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
