-- Lua provided by SkyAPI 
-- Game: Scrap Dealer Simulator
addappid(3554110)
addappid(3554111, 1, "ee4701b923b8bc706fc84f5ce3271d25416aefa3b852235bf1f19dff75a1b73e")
