-- Lua provided by RyzenAPI
-- Game: Warhammer: End Times - Vermintide

-- MAIN APPLICATION
addappid(235540)
addappid(410400)
addappid(412500)
addappid(412501)
addappid(412502)
addappid(412503)
addappid(419070)
addappid(437070)
addappid(440980)
addappid(453280)
addappid(463790)
addappid(463791)
addappid(463792)
addappid(463794)
addappid(463795)
addappid(463796)
addappid(463797)
addappid(463798)
addappid(463799)
addappid(569790)
addappid(741420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(235541, 1, "4bbee43e456e56921a35f988865155aa4f518229000db6d56aaf98d118134d9a")
addappid(235542, 1, "f64ffed41a8b3776d43946910c5b43921553400e092da49cb38b169f8604c82f")
addappid(235543, 1, "21a1c3b6dfcf0d12bca8d530bef13721529f81d7fafef4bab743299cb84521d6")
addappid(235544, 1, "d60767d0f76f6e41506ab7002054cb69cac1a55c24a4287a412c20cd97f532c1")
addappid(373540, 0, "f2f1744decba1820bab329a30c6c3709cde101e36c1d6580ebfa26cc3f5f696b")

