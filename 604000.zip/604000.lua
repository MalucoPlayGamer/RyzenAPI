-- Lua provided by RyzenAPI
-- Game: Like Clay

-- MAIN APPLICATION
addappid(604000)

-- MAIN APP DEPOTS / PACKAGES
addappid(604001, 1, "cb02a4bc13e277f7f6011709808f678886fe55188bc43466d6b04df1bf3fe030")
