-- Lua provided by RyzenAPI
-- Game: addappid(3519370)

-- MAIN APPLICATION
addappid(3519370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3519371, 1, "4468446b8b3558b97dda4bf819bce3feeb900c0fd846f747c3dafd3650d9d0c7")
