-- Lua provided by RyzenAPI
-- Game: The Chronicles of Lancelot GOLD

-- MAIN APPLICATION
addappid(2819110)
-- Game: addappid(2819110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819111, 1, "d4c4c228f5009e148df6852c15059b0bfba355fa435e57161eb46adba130a461")
