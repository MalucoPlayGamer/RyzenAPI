-- Lua provided by RyzenAPI
-- Game: addappid(2744840)

-- MAIN APPLICATION
addappid(2744840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744841, 1, "42eb8a54c430ddac897e4c86daea7700c72d84b452b45e2b8541dcf3b46316a8")
