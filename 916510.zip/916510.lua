-- Lua provided by RyzenAPI
-- Game: Running Man 3D Part2

-- MAIN APPLICATION
addappid(916510)

-- MAIN APP DEPOTS / PACKAGES
addappid(916511, 1, "463b9c40ab1ccc273856da428e75107c6217b6611f88caf6e8bb61cc2c8d4959")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
