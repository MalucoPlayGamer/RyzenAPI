-- Lua provided by RyzenAPI
-- Game: Revenge on the Streets 2

-- MAIN APPLICATION
addappid(1449640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449641, 1, "ac2c0644e073da6a3e1dafa954da5629d5832ad93bf432a355b2f817509c8ffb")
