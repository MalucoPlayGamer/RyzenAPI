-- 4448490's Lua and Manifest Created by Hubcap Manifest
-- Planet Harvester: Incremental Odyssey
-- Created: August 17, 2026 at 14:11:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4448490) -- Planet Harvester: Incremental Odyssey
-- MAIN APP DEPOTS
addappid(4448491, 1, "49e9386df88d47fac4c5fd81657de51f5dc86b5a46e072640d523138a0e72ebd") -- Depot 4448491
setManifestid(4448491, "4083472967207588433", 716837290)