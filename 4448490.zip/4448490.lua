-- Lua provided by RyzenAPI
-- Game: Planet Harvester: Incremental Odyssey

-- MAIN APPLICATION
addappid(4448490) -- Planet Harvester: Incremental Odyssey

-- MAIN APP DEPOTS / PACKAGES
addappid(4448491, 1, "49e9386df88d47fac4c5fd81657de51f5dc86b5a46e072640d523138a0e72ebd") -- Depot 4448491

