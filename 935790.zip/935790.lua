-- Lua provided by RyzenAPI
-- Game: 935790

-- MAIN APPLICATION
addappid(935790)

-- MAIN APP DEPOTS / PACKAGES
addappid(935792,0,"bbf0cabe4772b4f40e5f66002012bb8440ac7b70e445b47f6e9db67e812eb0d2")

