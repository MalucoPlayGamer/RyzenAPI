-- Lua provided by RyzenAPI
-- Game: Game: Searching For Rest Demo

-- MAIN APPLICATION
addappid(2426700)
-- Game: addappid(2426700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426701, 1, "8a10e782b7ef1822e6b8b0f5c5b5970040ff868d2615b3dea9d233889335ce95")
