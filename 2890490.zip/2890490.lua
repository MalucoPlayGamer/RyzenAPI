-- Lua provided by RyzenAPI
-- Game: Asurya's Embers - The Art of Asurya's Embers

-- MAIN APPLICATION
addappid(2890490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890490,0,"84792ba621f54ff565feebd09ae29f77d023a0d6f02049b572728683daf39791")
