-- Lua provided by RyzenAPI
-- Game: addappid(1160360)

-- MAIN APPLICATION
addappid(1160360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160361, 1, "101dfe3ee84e38ecdc1742899737dbfae887a4d4f318fa09a8d160366750c63f")
