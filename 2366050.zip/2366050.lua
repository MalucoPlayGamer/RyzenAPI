-- Lua provided by RyzenAPI
-- Game: 2366050

-- MAIN APPLICATION
addappid(2366050)
-- Game: addappid(2366050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366051, 1, "0b08b71fa217f530cb6cf72ddc2a4e8dd201ce67c3eb7b5b65b64f17d151e22c")
