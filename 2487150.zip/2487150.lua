-- Lua provided by RyzenAPI
-- Game: Deconstruction Simulator

-- MAIN APPLICATION
addappid(2487150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2487151,0,"734bff9aed757224ce32fdd52d7ef669c41d5e8d0c6f972006e554f1b8e0bbc1")

