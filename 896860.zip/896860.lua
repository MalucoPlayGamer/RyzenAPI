-- Lua provided by RyzenAPI 
-- Game: Trekking and Camping Sketch Edition
addappid(896860)
addappid(896861, 1, "29bdaca78dd0aba6f9f235545f00c99bf14b79eda1cb6ceccb8998a83e5a6fb3")
