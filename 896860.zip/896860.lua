-- Lua provided by RyzenAPI
-- Game: addappid(896860)

-- MAIN APPLICATION
addappid(896860)

-- MAIN APP DEPOTS / PACKAGES
addappid(896861, 1, "29bdaca78dd0aba6f9f235545f00c99bf14b79eda1cb6ceccb8998a83e5a6fb3")
