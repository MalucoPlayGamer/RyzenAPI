-- Lua provided by RyzenAPI
-- Game: Witanlore: Dreamtime

-- MAIN APPLICATION
addappid(554570)
addappid(573010)

-- MAIN APP DEPOTS / PACKAGES
addappid(554571,0,"6ea2e49c92bcbe243dd0d958631dd767a1c312ab339e182c60e5b69d2b985a05")

