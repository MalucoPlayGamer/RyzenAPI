-- Lua provided by RyzenAPI
-- Game: Witanlore: Dreamtime

-- MAIN APPLICATION
addappid(554570)
addappid(573010)

-- MAIN APP DEPOTS / PACKAGES
addappid(554571,0,"6ea2e49c92bcbe243dd0d958631dd767a1c312ab339e182c60e5b69d2b985a05")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
