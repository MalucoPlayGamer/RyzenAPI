-- Lua provided by RyzenAPI
-- Game: addappid(1089760)

-- MAIN APPLICATION
addappid(1089760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089761, 1, "ead1af4cfcac05d7a2a344e92cdcd25721326476b197cae8f93eadcf4ffcaf1c")
addappid(1089762, 1, "0bb2ea8a6e7e8d6bcce93bae53e0fd1309f6fe281a9c00bb26a831a60a2ba41a")
