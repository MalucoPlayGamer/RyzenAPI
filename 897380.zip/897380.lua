-- Lua provided by RyzenAPI
-- Game: Reptiles: In Hunt

-- MAIN APPLICATION
addappid(897380)
-- Game: addappid(897380)

-- MAIN APP DEPOTS / PACKAGES
addappid(897381, 1, "076bbe220a288fcb66020365afed093082449ff8db2bc3aab1e0ca68bf63292d")
