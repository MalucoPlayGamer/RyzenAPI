-- Lua provided by RyzenAPI
-- Game: Smalland: Survive the Wilds

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(229006)
addappid(229020)
addappid(768200)
-- Game: addappid(768200)

-- MAIN APP DEPOTS / PACKAGES
addappid(768202,0,"9dbfe6d2596f2071851cb558e8df59bfc3a4eddc77009d6dd5601d549b68e060")
