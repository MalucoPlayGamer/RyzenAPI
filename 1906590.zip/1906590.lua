-- Lua provided by RyzenAPI
-- Game: Game: WW2 Rebuilder: Germany Prologue

-- MAIN APPLICATION
addappid(1906590)
-- Game: addappid(1906590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906591, 1, "d29e4239d391391a6f78fd21db232a2a9aa908627e708a5dc830a0f0420f1642")
