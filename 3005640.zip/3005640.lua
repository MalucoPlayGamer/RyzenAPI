-- Lua provided by RyzenAPI 
-- Game: Hungry Noemi
addappid(3005640)
addappid(3005641, 1, "58ded1823f09c37ccc4a32bb09116f079aabd78c09303fafdbf4dcefda5dd632")
