-- Lua provided by RyzenAPI
-- Game: 3005640

-- MAIN APPLICATION
addappid(3005640)
-- Game: addappid(3005640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3005641, 1, "58ded1823f09c37ccc4a32bb09116f079aabd78c09303fafdbf4dcefda5dd632")
