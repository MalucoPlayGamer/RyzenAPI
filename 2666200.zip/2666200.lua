-- Lua provided by RyzenAPI
-- Game: SEX Massage 🔞

-- MAIN APPLICATION
addappid(2666200)
-- Game: addappid(2666200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666201, 1, "03e4d09c61a93a599c0394ddbf180dafd3be1c66009270b3135fa0c631e81758")
