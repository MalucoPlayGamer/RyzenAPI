-- Lua provided by RyzenAPI
-- Game: Witch Rise

-- MAIN APPLICATION
addappid(2193090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193091, 1, "ee723ecee4869a8443639feadb6f10805239e69ab1a1bb1698fcc0a52ccc0a30")

