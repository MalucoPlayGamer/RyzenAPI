-- Lua provided by SkyAPI 
-- Game: Horny Holiday Demo
addappid(3013180)
addappid(3013181, 1, "f469d3c10c2dad75a79733ee53f9393b240ecb29257262ab505ef653ebd554a9")
