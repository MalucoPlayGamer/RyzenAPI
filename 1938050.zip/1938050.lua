-- Lua provided by RyzenAPI
-- Game: addappid(1938050)

-- MAIN APPLICATION
addappid(1938050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938051, 1, "29ddb0db6b08315d1d9e9574c35349e938d5d50d4d6a65a7c2d50af52c87b99d")
