-- Lua provided by RyzenAPI
-- Game: Unbridled: That Horse Game

-- MAIN APPLICATION
addappid(1938050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938051, 1, "29ddb0db6b08315d1d9e9574c35349e938d5d50d4d6a65a7c2d50af52c87b99d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
