-- Lua provided by RyzenAPI
-- Game: MiniLAW: Ministry of Law

-- MAIN APPLICATION
addappid(503180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216810,0,"159c38afb07325a9711ca8986db1c59cf0bf420bdb95694cd4aee6c7b258f7a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
