-- Lua provided by RyzenAPI
-- Game: Courier Bay

-- MAIN APPLICATION
addappid(3781940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3781941,0,"6ed8f265298f7b53deb184c22e8ce36dda89c1ab91f4237f30cbb3425847942a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
