-- Lua provided by RyzenAPI
-- Game: Courier Bay

-- MAIN APPLICATION
addappid(3781940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3781941,0,"6ed8f265298f7b53deb184c22e8ce36dda89c1ab91f4237f30cbb3425847942a")

