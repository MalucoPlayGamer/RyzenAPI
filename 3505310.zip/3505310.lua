-- Lua provided by RyzenAPI
-- Game: addappid(3505310)

-- MAIN APPLICATION
addappid(3505310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3505312,0,"f6d1b55bdfc4f930fb571e4da0e5171ee4f2006d757e8ce091e81a641f28573b")
