-- Lua provided by RyzenAPI
-- Game: Moebious: Endless Dream

-- MAIN APPLICATION
addappid(3505310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3505312,0,"f6d1b55bdfc4f930fb571e4da0e5171ee4f2006d757e8ce091e81a641f28573b")

