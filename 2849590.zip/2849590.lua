-- Lua provided by RyzenAPI
-- Game: Barricade Demo

-- MAIN APPLICATION
addappid(2849590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2849593,0,"74b7329f216a5064ef8de8b7df87e84cc9fd5998dfb7a9d9f2b3f415b139151e")

