-- Lua provided by RyzenAPI
-- Game: Fuzz Force: Spook Squad

-- MAIN APPLICATION
addappid(1422190)
-- Game: addappid(1422190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422191, 1, "a0ecce0deb1ec3c933341531c00d7e6bbc5e5c0188646a9385b7899d6f40c089")
