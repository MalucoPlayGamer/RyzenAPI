-- Lua provided by RyzenAPI
-- Game: Arisen Force: Vonimir Demo

-- MAIN APPLICATION
addappid(2359820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359821, 1, "bce9522dd962ddc997f8cf7131f8176510599035c6a6638f909b32bbf62df1e1")

