-- Lua provided by RyzenAPI
-- Game: CubeHub

-- MAIN APPLICATION
addappid(1184590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184591, 1, "03eec6acc322e799dde8fdcfac728afd9c6c5aa265f48b8b367fcce02efca715")

