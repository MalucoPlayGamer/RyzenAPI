-- Lua provided by RyzenAPI
-- Game: Game: Wallace & Gromit’s Grand Adventures, Episode 3: Muzzled!

-- MAIN APPLICATION
addappid(31120)
-- Game: addappid(31120)

-- MAIN APP DEPOTS / PACKAGES
addappid(31121, 1, "ccb858572fa76531ab10f1a43b60604ed2921d16e1aaa67f5286d957aecdfd67")
