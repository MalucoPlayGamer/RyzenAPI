-- Lua provided by RyzenAPI
-- Game: addappid(1310960)

-- MAIN APPLICATION
addappid(1310960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310961, 1, "498cb11d845ebcc2a17f6a9825fcfe71d431d8ef88e4c60ea9583d665756c419")
