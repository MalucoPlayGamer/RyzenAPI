-- Lua provided by RyzenAPI
-- Game: 1089630

-- MAIN APPLICATION
addappid(1089630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089632,0,"7a7f95fd2faa2d2f7ae92a9e5dc2592d073ca327e6399a432a658070b297620f")
addappid(1496070,0,"bd2a41eb134fff6a6efd91a3d2671a8bf36eebbc7fbbaa8cfeeb8a36ee797d8c")
