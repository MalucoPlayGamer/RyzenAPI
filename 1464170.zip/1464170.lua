-- Lua provided by RyzenAPI
-- Game: Touhou Eternal Spell Cards

-- MAIN APPLICATION
addappid(1464170)
-- Game: addappid(1464170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464171, 1, "d38478e155a1b09b8c6fc5860e701c2997547ba72782d781a7ca9286e58cddc8")
