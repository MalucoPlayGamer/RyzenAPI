-- 4306460's Lua and Manifest Created by Hubcap Manifest
-- Endless TD
-- Created: July 05, 2026 at 18:08:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4306460) -- Endless TD
-- MAIN APP DEPOTS
addappid(4306461, 1, "2b07a5aab72b308878cfe12a7525a64e84ee25dd17af4452adfe0ce16203ee95") -- Depot 4306461
-- setManifestid(4306461, "2379738663708891319", 3770081420)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
-- setManifestid(228989, "3514306556860204959", 39590283)