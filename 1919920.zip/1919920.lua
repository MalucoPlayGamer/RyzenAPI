-- Lua provided by RyzenAPI
-- Game: 眼球大師 Eyeball Master

-- MAIN APPLICATION
addappid(1919920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919921, 1, "f68bcb20f0b3f9df67961d9ef1eeb30c34c969145ef0beed928d09f5498a99cd")

