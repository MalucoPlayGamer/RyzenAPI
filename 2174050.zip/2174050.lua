-- Lua provided by RyzenAPI
-- Game: addappid(2174050)

-- MAIN APPLICATION
addappid(2174050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174051, 1, "e50a3f9eb9b8c25bcb18b10cd90d661a91a9486aa2a8ffdabdc739eb2d9a72e9")
