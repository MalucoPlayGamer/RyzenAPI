-- Lua provided by RyzenAPI
-- Game: Promethium

-- MAIN APPLICATION
addappid(624680)

-- MAIN APP DEPOTS / PACKAGES
addappid(624681,0,"a1322657a5cdc341e0a2cdfa10ad6aebdfbb925819841328e8744911aa49c1b5")

