-- Lua provided by RyzenAPI
-- Game: Fury Unleashed: Prologue

-- MAIN APPLICATION
addappid(1262960)
-- Game: addappid(1262960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262961, 1, "0fac6e186c875162cbbd24550f8b758f063d352db50eea161d95ac1600dfaa39")
