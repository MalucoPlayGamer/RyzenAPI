-- Lua provided by RyzenAPI
-- Game: Miss Neko: Pirates

-- MAIN APPLICATION
addappid(2695270)
addappid(2824300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695271, 1, "2a96571ddde236385169574854f8eb25a15a715b5da5674059492fe0a7ae57cd")

