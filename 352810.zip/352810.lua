-- Lua provided by RyzenAPI
-- Game: Game: Yukie: A Japanese Winter Fairy Tale

-- MAIN APPLICATION
addappid(352810)
-- Game: addappid(352810)

-- MAIN APP DEPOTS / PACKAGES
addappid(352811, 1, "7c28492dea3b40bfa0822726f1d69bf3100edbc9b829307604eabab9dbd1f831")
