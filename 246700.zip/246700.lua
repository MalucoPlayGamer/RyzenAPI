-- Lua provided by RyzenAPI
-- Game: addappid(246700)

-- MAIN APPLICATION
addappid(246700)

-- MAIN APP DEPOTS / PACKAGES
addappid(246701, 1, "9892314e62f04bab597f6c780cf40dca4eb09afcaab94af972ad927fd777b413")
