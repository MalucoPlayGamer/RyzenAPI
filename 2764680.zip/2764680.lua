-- Lua provided by RyzenAPI
-- Game: Dungeon Chamber

-- MAIN APPLICATION
addappid(2764680)
addappid(2776010)
-- Game: addappid(2764680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764681, 1, "b2a255ff73612d8f17c05d1ce9f0410ef6ea733e01abbb42c9c345a91fe338e8")
