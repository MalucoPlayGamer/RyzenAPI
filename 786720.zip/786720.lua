-- Lua provided by RyzenAPI 
-- Game: AppID 786720
addappid(786720)
addappid(786721, 1, "39ffa397c216ad9ee11d4f624b423c029044d69e1857f58a637a1ca995d953cc")
