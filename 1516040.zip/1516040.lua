-- Lua provided by RyzenAPI
-- Game: Workers & Resources: Soviet Republic Demo

-- MAIN APPLICATION
addappid(1516040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516041, 1, "3371a90012cc546c6104efb55f04eb6581d5f62915a90ed171e384c24c237cd2")
