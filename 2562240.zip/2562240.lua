-- Lua provided by RyzenAPI
-- Game: Only Up!

-- MAIN APPLICATION
addappid(2562240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562241, 1, "9e5f9c074ee6c5b6c0e09cf2c822245a1308e9bb08b13a819af611aefa55e108")
