-- Lua provided by RyzenAPI
-- Game: FUSER™ - Talking Heads - "Burning Down The House"

-- MAIN APPLICATION
addappid(1734182)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734182,0,"57655c1d53a8045403286f893e6cdcb3a8224616721a46ce7edab7f4fc140c24")
