-- Lua provided by RyzenAPI
-- Game: Celtic Heroes

-- MAIN APPLICATION
addappid(2829820)

