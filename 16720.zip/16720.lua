-- Lua provided by SkyAPI 
-- Game: Velvet Assassin
addappid(16720)
addappid(16721, 1, "5f182f10d3ff4bf24fd00e5e86d7b03fa52c0e1ad3a27228f36c0ce38c44d08d")
addappid(16722, 1, "153f2b8bff47e78c0f21b593b872cf3929bddb3f31102180ede432152b45863c")
