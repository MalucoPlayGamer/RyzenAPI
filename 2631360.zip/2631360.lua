-- Lua provided by RyzenAPI
-- Game: 2631360

-- MAIN APPLICATION
addappid(2631360)
-- Game: addappid(2631360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631361, 1, "ac0970cade3ef1c084f6ee59e8a9f28cd518ff5809943daba2f10d895566affd")
