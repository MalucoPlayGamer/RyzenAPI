-- Lua provided by RyzenAPI
-- Game: Hypnosis Card 2

-- MAIN APPLICATION
addappid(2863310)
addappid(2914310)
-- Game: addappid(2863310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863311, 1, "477a372552e2a07d12432f3b91fe00422edd77f705d100d375388c912f752193")
