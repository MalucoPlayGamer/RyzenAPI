-- Lua provided by RyzenAPI
-- Game: Arcane Assembly

-- MAIN APPLICATION
addappid(2356150)
-- Game: addappid(2356150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356151, 1, "3061395ab01738e6770d6b9d069f772ef613dfa197d38c259a7602e5f1e6d8d8")
