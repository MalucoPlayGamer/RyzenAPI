-- Lua provided by RyzenAPI
-- Game: Fantasy Mosaics 15: Ancient Land

-- MAIN APPLICATION
addappid(656660)

-- MAIN APP DEPOTS / PACKAGES
addappid(656661,0,"95cd0bba170e22242ca25114126d45ef23aad93c379a4a36386c0a661909c6a0")

