-- Lua provided by RyzenAPI
-- Game: Country Tales: Wild West

-- MAIN APPLICATION
addappid(394270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(394271, 1, "422a0b9b6bb9a1a2986d18d2b2b8fc42581fa7bf3c5b7db9e04d6edb05bdce1f")

