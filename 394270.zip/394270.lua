-- Lua provided by RyzenAPI
-- Game: Country Tales: Wild West

-- MAIN APPLICATION
addappid(394270)
-- Game: addappid(394270)

-- MAIN APP DEPOTS / PACKAGES
addappid(394271, 1, "422a0b9b6bb9a1a2986d18d2b2b8fc42581fa7bf3c5b7db9e04d6edb05bdce1f")
