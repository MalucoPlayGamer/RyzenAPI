-- Lua provided by RyzenAPI
-- Game: Lost Base Escape

-- MAIN APPLICATION
addappid(578180)

-- MAIN APP DEPOTS / PACKAGES
addappid(578181, 1, "69933d9c033d52ceb65ac98f172f0dc9c960e26f38c27741a9101a64ad0518c8")
