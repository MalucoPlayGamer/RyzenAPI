-- Lua provided by RyzenAPI
-- Game: SuperSorry

-- MAIN APPLICATION
addappid(3236010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3236011, 1, "7af87c709b9133a3c269125d2d5e0243c3b323092d7299a23a70ae7d257e70c5")

