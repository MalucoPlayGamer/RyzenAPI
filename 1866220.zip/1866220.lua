-- Lua provided by RyzenAPI
-- Game: HexoJago

-- MAIN APPLICATION
addappid(1866220)
addappid(1870560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1866221, 1, "b3233aa787da6c15173d402b9bb65aecbe29e02f0eff19c8f239b96e1dd28ca5")
addappid(1866222, 1, "0262e34b8be90d906ec321a47e1f406a726c1d303d50c9433e04037997780749")
addappid(1866223, 1, "215a32b9c56d816ace099ee881ce67ce2b44d8ce934542e8348839d9548b15d1")

