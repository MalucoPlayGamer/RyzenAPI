-- Lua provided by RyzenAPI
-- Game: Scars of Summer

-- MAIN APPLICATION
addappid(1405470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405471, 1, "0a670f29a2eec80c067a251685a043e746ff3979abf570bb2ae4ab6f689f6981")
addappid(1405472, 1, "5f6951c9bdb0b74325a57fbcfcfe90a378b2639c634a20d8d913d53bbe5c2116")
addappid(1405473, 1, "55592f37abff0861d55855a15f75c1c685c9d2a6eed3d89bafb714f6bf5146a4")
