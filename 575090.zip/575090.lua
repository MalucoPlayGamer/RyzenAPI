-- Lua provided by RyzenAPI
-- Game: Flame of Memory

-- MAIN APPLICATION
addappid(575090)

-- MAIN APP DEPOTS / PACKAGES
addappid(575091, 1, "61620851e4117188115bbaece694527494d2d578634b7101557e480629b79017")
addappid(575092, 1, "1da7d5dd359d597ad59bbdb906dc748cb4eae2d885e1320c033d878d64d2e037")
addappid(575093, 1, "a23567e216c3f7bd0003c3cdc59a2d184582d8d2f3ef489a36086cd09ba2851d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
