-- Lua provided by RyzenAPI
-- Game: AppID 733050

-- MAIN APPLICATION
addappid(733050)

-- MAIN APP DEPOTS / PACKAGES
addappid(733051, 1, "9d7710ddc1da2c4079d49a7edecaefc631d4804bfa57ec1dbc9b3abcb0ccebcf")
