-- Lua provided by RyzenAPI
-- Game: Seed of Heroes Demo

-- MAIN APPLICATION
addappid(2955160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955161, 1, "e7b7eb1e734cff6e74661051e1ac12327e47f1d4bd87b8918f19d26f60947d1f")

