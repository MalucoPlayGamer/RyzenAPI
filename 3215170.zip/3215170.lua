-- Lua provided by RyzenAPI
-- Game: addappid(3215170)

-- MAIN APPLICATION
addappid(3215170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215171, 1, "983ceef418a421992aa7d6d884623b194adade1c6fcd2e42d12719632356d21f")
