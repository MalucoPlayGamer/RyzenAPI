-- Lua provided by RyzenAPI
-- Game: Game: Hook 2 Demo

-- MAIN APPLICATION
addappid(2006850)
-- Game: addappid(2006850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2006851, 1, "12e9c12d8299943952f5ad509352bbaf02924761364c6eccd7640b060759c7f8")
