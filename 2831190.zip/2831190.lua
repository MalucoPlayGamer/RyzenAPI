-- Lua provided by RyzenAPI
-- Game: Snow White Ashes Demo

-- MAIN APPLICATION
addappid(2831190)
-- Game: addappid(2831190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2831192,0,"6b3f5b9592d1e6ca52dcb82ee1a0649ee4869acd9d14bb6b88ff0ad26c503399")
