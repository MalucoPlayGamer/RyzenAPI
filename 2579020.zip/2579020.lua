-- Lua provided by RyzenAPI
-- Game: Game: Idol VS Furries

-- MAIN APPLICATION
addappid(2579020)
-- Game: addappid(2579020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579021, 1, "038f1695f8629910971b35d4711e09846cee4195173ce49d6c08d718d898bae1")
