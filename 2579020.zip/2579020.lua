-- Lua provided by RyzenAPI 
-- Game: Idol VS Furries
addappid(2579020)
addappid(2579021, 1, "038f1695f8629910971b35d4711e09846cee4195173ce49d6c08d718d898bae1")
