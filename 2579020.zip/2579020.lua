-- Lua provided by RyzenAPI
-- Game: Idol VS Furries

-- MAIN APPLICATION
addappid(2579020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579021, 1, "038f1695f8629910971b35d4711e09846cee4195173ce49d6c08d718d898bae1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
