-- Lua provided by RyzenAPI
-- Game: Game: Alpha & Beta

-- MAIN APPLICATION
addappid(968320)
-- Game: addappid(968320)

-- MAIN APP DEPOTS / PACKAGES
addappid(968321, 1, "f068c2e73b2cefa5945c362c1f669e986841b3093344bcb1aa8220bff9e16b31")
