-- Lua provided by RyzenAPI
-- Game: 925900

-- MAIN APPLICATION
addappid(925900)
-- Game: addappid(925900)

-- MAIN APP DEPOTS / PACKAGES
addappid(925901, 1, "2648c4e54a7b2bc7d0304d5f4404b1fdfc5fb5e370c5f08fd15d13eb71d187e7")
