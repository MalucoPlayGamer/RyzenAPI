-- Lua provided by RyzenAPI
-- Game: Game: 我的纸片人女友/Make butter together!

-- MAIN APPLICATION
addappid(1070020)
-- Game: addappid(1070020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070021, 1, "293e7476a9c259d51a4d5173ed7f4ff23039f7c5ca4957232903bf095b4d52cd")
addappid(1126350, 0, "63bb407b7063e20a5a32180256a115d3d0751ff3435987cf64093190bbae8be7")
