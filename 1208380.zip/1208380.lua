-- Lua provided by RyzenAPI
-- Game: addappid(1208380)

-- MAIN APPLICATION
addappid(1208380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208381, 1, "b75728f31b3e963e3c7f75dd965cc8289fc04ed0e8bbff9786a674c709a44ee7")
