-- Lua provided by RyzenAPI
-- Game: 2325170

-- MAIN APPLICATION
addappid(2325170)
-- Game: addappid(2325170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325171, 1, "cf93cd4aff9b280afc62577c723c9e7d16665e1750c45f68286c6057b8dd1b85")
