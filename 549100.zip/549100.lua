-- Lua provided by SkyAPI 
-- Game: GravNewton
addappid(549100)
addappid(549101, 1, "9767110ecb91b9a140382701bba631262017e55597912132cabca28532944d2d")
