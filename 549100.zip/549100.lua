-- Lua provided by RyzenAPI
-- Game: Game: GravNewton

-- MAIN APPLICATION
addappid(549100)
-- Game: addappid(549100)

-- MAIN APP DEPOTS / PACKAGES
addappid(549101, 1, "9767110ecb91b9a140382701bba631262017e55597912132cabca28532944d2d")
