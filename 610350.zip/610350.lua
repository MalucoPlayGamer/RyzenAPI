-- Lua provided by RyzenAPI
-- Game: AppID 610350

-- MAIN APPLICATION
addappid(610350)

-- MAIN APP DEPOTS / PACKAGES
addappid(610351, 1, "20f7b57994b19fd77f748cffde9b5fabd910cf1629f88803e40ededcec5e0fdb")
