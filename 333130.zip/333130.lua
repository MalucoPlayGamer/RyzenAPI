-- Lua provided by RyzenAPI
-- Game: Do Not Fall

-- MAIN APPLICATION
addappid(333130)

-- MAIN APP DEPOTS / PACKAGES
addappid(333131, 1, "7454380bf512a3d357f18913da7225efe164a9d483f267ac87877c68e5ff730f")

