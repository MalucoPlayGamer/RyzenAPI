-- Lua provided by RyzenAPI
-- Game: The Good Book VN

-- MAIN APPLICATION
addappid(1408960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408961, 1, "5870dbc1848b23b0f8c7ed7c08e7439cf3a774b25e83f0112626d593c89f7cc1")

