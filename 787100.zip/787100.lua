-- Lua provided by RyzenAPI
-- Game: addappid(787100)

-- MAIN APPLICATION
addappid(787100)

-- MAIN APP DEPOTS / PACKAGES
addappid(787101, 1, "ede70c7022a1d3267d68091d73247d5f7ebac86bc6df40b262c223a2e655bf96")
