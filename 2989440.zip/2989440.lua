-- Lua provided by RyzenAPI
-- Game: Game: Mind Over Magnet Demo

-- MAIN APPLICATION
addappid(2989440)
-- Game: addappid(2989440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989441, 1, "63b80d38b56f4a9edefb95889b1a1a0098fa14360d66dc04a21c41c5fbec3be1")
