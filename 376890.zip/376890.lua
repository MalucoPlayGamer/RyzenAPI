-- Lua provided by RyzenAPI
-- Game: AppID 376890

-- MAIN APPLICATION
addappid(376890)

-- MAIN APP DEPOTS / PACKAGES
addappid(376891, 1, "3e6a0053d15dcfc8de6b1a9e3c733da62ca2d79bb89e3ba0420c1f29d17ea3c2")
