-- Lua provided by RyzenAPI
-- Game: Rampage Agents

-- MAIN APPLICATION
addappid(2492600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492601, 1, "99e464b03588520e1d0bbf789c1e97b77e440b402f2e6e89aa9540d5a556ef65")

