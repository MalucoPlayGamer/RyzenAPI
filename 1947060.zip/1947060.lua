-- Lua provided by RyzenAPI
-- Game: On the Wings - Birth of a Hero

-- MAIN APPLICATION
addappid(1947060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947061, 1, "27f01cbe22952ff2a9057860c6cc7239b70a2c0a7cf734a3cec3a5cec5acd69d")
addappid(1947062, 1, "dd1761dd325ca85f4bd03756305725c970970ec9b8a1c3d37728387f6ffb5203")

