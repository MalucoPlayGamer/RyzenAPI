-- Lua provided by RyzenAPI 
-- Game: Trine Demo
addappid(35710)
addappid(35711, 1, "e28589152f4fc098a869585b360a1b9126624eb2e4e454f5754d1209df467ce6")
