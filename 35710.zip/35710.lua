-- Lua provided by RyzenAPI
-- Game: 35710

-- MAIN APPLICATION
addappid(35710)
-- Game: addappid(35710)

-- MAIN APP DEPOTS / PACKAGES
addappid(35711, 1, "e28589152f4fc098a869585b360a1b9126624eb2e4e454f5754d1209df467ce6")
