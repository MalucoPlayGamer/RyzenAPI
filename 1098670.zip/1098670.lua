-- Lua provided by RyzenAPI
-- Game: Game: AppID 1098670

-- MAIN APPLICATION
addappid(1098670)
-- Game: addappid(1098670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098671, 1, "254ba8b768b299ebe768489e6f0182cd32057b7bc99094d70a07d1b52a4d9477")
