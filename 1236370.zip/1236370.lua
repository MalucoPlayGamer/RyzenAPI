-- Lua provided by RyzenAPI
-- Game: Northgard - The Official Soundtrack

-- MAIN APPLICATION
addappid(1236370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236371, 1, "5df18af649cbbe0facf2c0b6d17150b3003f03b1a9bd5bf3b1cbff38837fef74")

