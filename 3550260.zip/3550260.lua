-- Lua provided by RyzenAPI
-- Game: addappid(3550260)

-- MAIN APPLICATION
addappid(3550260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3550261, 1, "d589ee7b53e966d702f9e70c1cc3e2e872c131a1010e751ed2c44c71c354b015")
