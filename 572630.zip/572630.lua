-- Lua provided by RyzenAPI 
-- Game: LyraVR
addappid(572630)
addappid(572631, 1, "8f773dc3cc8c4f329fc0985ca3e1ce51bc5e6049fe076162628f4291844ce1a0")
