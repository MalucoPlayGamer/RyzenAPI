-- Lua provided by RyzenAPI
-- Game: Snowed Under | 雪葬

-- MAIN APPLICATION
addappid(4938200) -- Snowed Under | 雪葬

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4938201, 1, "6a4710af4a9d241971466c1ac2c668aec10bbd7a520caef2713c3617e253439b") -- Depot 4938201

