-- Lua provided by RyzenAPI
-- Game: addappid(1436890)

-- MAIN APPLICATION
addappid(1436890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436890,0,"ed94cc6c803726e83de5085e7f0b659bef8d3765e70c31c81a3e3aa28ce0351d")
