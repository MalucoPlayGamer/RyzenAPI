-- Lua provided by RyzenAPI
-- Game: addappid(1327520)

-- MAIN APPLICATION
addappid(1327520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327521, 1, "2dfa340bf32b866bd25932b36fbb81d55897dbfb6e7948088e540e9531f0bd2a")
