-- Lua provided by RyzenAPI
-- Game: Kagura Genesis: Kuon's Story

-- MAIN APPLICATION
addappid(2668840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668841, 1, "366ea31bc03bd1f1e750f709038b62830aec53750f9b3fd2ea04db6fe1408653")
