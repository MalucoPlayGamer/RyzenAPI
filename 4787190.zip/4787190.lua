-- 4787190's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Mala Tokmachka
-- Created: August 15, 2026 at 22:59:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4787190, 1, "bbdef0c602d5aa0f1eb96d3606cba2eeb396638705e8572c9dd64b187267a3d0") -- The Legend of Mala Tokmachka
-- MAIN APP DEPOTS
addappid(4787191, 1, "131344ba2746ef33f22e27aef34be65dd83bbcafb117d58236215f9446839a16") -- Depot 4787191
setManifestid(4787191, "2814859761348711591", 627891573)