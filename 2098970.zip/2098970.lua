-- Lua provided by RyzenAPI
-- Game: 2098970

-- MAIN APPLICATION
addappid(2098970)
-- Game: addappid(2098970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098971, 1, "762c9c0ecd7f62492d262f85125c04deade509b417a9fb0f76d43165ff48f353")
