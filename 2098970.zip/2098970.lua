-- Lua provided by RyzenAPI
-- Game: Future & Girls

-- MAIN APPLICATION
addappid(2098970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098971, 1, "762c9c0ecd7f62492d262f85125c04deade509b417a9fb0f76d43165ff48f353")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2130820)
