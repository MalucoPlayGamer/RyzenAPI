-- Lua provided by SkyAPI 
-- Game: ToaZZle
addappid(817470)
addappid(817471, 1, "af8d784f20f46d13d05e4e94430b84dd17043c57c90ca3bd1a7bcfcf9b6dc5a0")
