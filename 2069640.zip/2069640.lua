-- Lua provided by RyzenAPI
-- Game: Hero's Journey

-- MAIN APPLICATION
addappid(2069640)
-- Game: addappid(2069640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069641, 1, "1e1f09869084e661446538b39b15e2e3e1e227133f3d992f6e1930387ab7871a")
