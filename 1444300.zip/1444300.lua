-- Lua provided by RyzenAPI
-- Game: 1444300

-- MAIN APPLICATION
addappid(1444300)
-- Game: addappid(1444300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444301, 1, "bb2674be3d6ff9c366f6059c0bec827c8cb344e0f68dad3ebbd58874daf02848")
