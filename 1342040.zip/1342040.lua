-- Lua provided by RyzenAPI
-- Game: Sylphy and the Sleepless Island

-- MAIN APPLICATION
addappid(1342040)
-- Game: addappid(1342040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342041, 1, "6b28c4deca24e2deba9339633efc4549492c94ad835fe6ee9987aef298f4ff8a")
addappid(1342042, 1, "54d5a5400f0b3a4c2c320fcddb7a96273b47cc0be76d648ccb5f95bd2cc2968e")
addappid(1342043, 1, "c987c3ab4a9fe6d189a7f0f84a725366f4a9c8f9fc7a55da87c33826315b5f38")
