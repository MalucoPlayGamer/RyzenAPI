-- Lua provided by SkyAPI 
-- Game: AppID 984110
addappid(984110)
addappid(984111, 1, "3601d277dc3796b8a9a3c42b514bf07d5b314dcdeb7700e40b87b6022a6ff06c")
