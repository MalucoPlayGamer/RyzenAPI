-- Lua provided by RyzenAPI
-- Game: AppID 453650

-- MAIN APPLICATION
addappid(453650)

-- MAIN APP DEPOTS / PACKAGES
addappid(453651, 1, "d17aac9c6dfc0204e10c36c8fa65cb50e1d3b1c7844968bd87f0a2b85b644cb7")
addappid(453652, 1, "cb613a9e32fd7735e4be0228fb6167df517469d97b0a33f72a2a598cd5e21c31")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
