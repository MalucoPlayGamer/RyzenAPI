-- Lua provided by RyzenAPI
-- Game: AppID 752330

-- MAIN APPLICATION
addappid(752330)

-- MAIN APP DEPOTS / PACKAGES
addappid(752331, 1, "61039c480e5b5cfae137b3769bc3f7879232ba4dc95fde5ca3ce3b8bac6c110c")

