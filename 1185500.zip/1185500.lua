-- Lua provided by RyzenAPI
-- Game: Mega Balls

-- MAIN APPLICATION
addappid(1185500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185501, 1, "eea4c05bdda562fda6f50f54c7698521dae3d7a615a2082fc9832bae559bd5f9")

