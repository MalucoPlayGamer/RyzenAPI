-- Lua provided by RyzenAPI
-- Game: The Cable Center - Virtual Archive

-- MAIN APPLICATION
addappid(612440)

-- MAIN APP DEPOTS / PACKAGES
addappid(612441, 1, "455cf313b63a02fcccc495175ee80cd0ecff63c822621c91fade3c44068ccc3a")
