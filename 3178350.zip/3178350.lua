-- Lua provided by RyzenAPI
-- Game: WARRIORS: Abyss

-- MAIN APPLICATION
addappid(3178350)
addappid(3358130)
addappid(3480130)
addappid(3480140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3178351, 1, "50d5b19878cdd566dccd7b3f0042e13d42e13d32f5be8c88e71ea45a4d38323d")
addappid(3358070, 0, "7f29a98df78d333fa66611c3d323c6312f0c42aacd986b5459db60dee34ac7fa")
addappid(3358080, 0, "6146f8b9ef4662268b7ebbe73c86f084c6b391aabecbfdc0c2586cbc59fa0594")
addappid(3358090, 0, "b435576191cc296a2c028424739cb9736645d34a1ec08a28d3099401d923172b")
addappid(3358100, 0, "c0c507bc3f9d4633c5839394fa0af8e7467e111fbd99fc015f1f6caa887cc374")
addappid(3358110, 0, "2f525b2ffbe129a613aa2a8d468d4aeed107e092c88d8ab33c53654d6794bb89")
addappid(3358120, 0, "0abef5f189b4ff09f6ce15796aa9bbb502493c3f8cd9d38cf01319b93564b26b")
addappid(3358140, 0, "5d84acaacba8f481033a57f86abbc5d6d025f677f8a05544851fcc83c47c11cc")
addappid(3358160, 0, "92e45e04b2863544247f5e07ec54e39a35f2a27d0d234bfba0336d799a16f1f3")
addappid(3480150, 0, "e423e85e8c584a65695d96890aeddf854bc742a32a1a71fa6002d160b51e2350")
addappid(3480160, 0, "3a59daf7f9721792286915ce6ddcfbbd504b646b31cc1681b874e9cdc0acfe3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4239840)
addappid(4239850)
addappid(4239860)
addappid(4239870)
addappid(4239880)
addappid(4239900)
addappid(4239910)
addappid(4239920)
addappid(4239930)
addappid(4239940)
addappid(4337620)
addappid(4337630)
addappid(4347120)
