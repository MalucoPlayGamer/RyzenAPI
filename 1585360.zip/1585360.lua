-- Lua provided by SkyAPI 
-- Game: AppID 1585360
addappid(1585360)
addappid(1585361, 1, "4757c2f2ad5cb2b6098ac4e3ca5b72f2c19ba5822d7d579af52e77ef17e6cc23")
