-- Lua provided by RyzenAPI
-- Game: addappid(771410)

-- MAIN APPLICATION
addappid(771410)

-- MAIN APP DEPOTS / PACKAGES
addappid(771411, 1, "b5b09239724b0ed77e11741fb147efd088fe8e191aee43f449b324aabddf275f")
