-- Lua provided by RyzenAPI
-- Game: Koumajou Remilia: Scarlet Symphony

-- MAIN APPLICATION
addappid(1229880)
-- Game: addappid(1229880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229881, 1, "4095ea24e6f3200efea96b2c012ba24343d976053fbd6592e9a61121d0ef62ec")
