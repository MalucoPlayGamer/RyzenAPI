-- Lua provided by RyzenAPI
-- Game: The Chosen RPG

-- MAIN APPLICATION
addappid(434420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(434421, 1, "193ce930b2fc99a52fd0d67bac780b40cd83c3d0adbb94ec2e67b4aba54c28c4")

