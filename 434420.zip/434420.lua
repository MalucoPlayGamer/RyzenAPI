-- Lua provided by RyzenAPI
-- Game: The Chosen RPG

-- MAIN APPLICATION
addappid(434420)

-- MAIN APP DEPOTS / PACKAGES
addappid(434421, 1, "193ce930b2fc99a52fd0d67bac780b40cd83c3d0adbb94ec2e67b4aba54c28c4")

