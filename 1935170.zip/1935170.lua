-- Lua provided by RyzenAPI
-- Game: Game: AppID 1935170

-- MAIN APPLICATION
addappid(1935170)
-- Game: addappid(1935170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935171, 1, "e1757101fc0adc02aa121790a5bb83055229cc8815fe4b6d37a7152db04d09c2")
