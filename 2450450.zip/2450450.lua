-- Lua provided by RyzenAPI
-- Game: Game: MEGATON MUSASHI W: WIRED

-- MAIN APPLICATION
addappid(2450450)
addappid(2726880)
-- Game: addappid(2450450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2450451, 1, "e9f62112fdedacb65194d410b7a1cf22ae36f7b86a698c1f04ea7c4ac7a3806a")
