-- Lua provided by RyzenAPI
-- Game: MEGATON MUSASHI W: WIRED

-- MAIN APPLICATION
addappid(2450450) -- MEGATON MUSASHI W: WIRED
addappid(2726880) -- MEGATON MUSASHI W WIRED - Edition Upgrade (Deluxe)
addappid(2760000) -- MEGATON MUSASHI W WIRED - V Navigator Korone Inugami
addappid(2760010) -- MEGATON MUSASHI W WIRED - V Navigator Jibanyan
addappid(2760020) -- MEGATON MUSASHI W WIRED - V Navigator Dragon
addappid(2760030) -- MEGATON MUSASHI W WIRED - Riding Board Color Set
addappid(2760040) -- MEGATON MUSASHI W WIRED - Riding Board Effect Set 1
addappid(2760050) -- MEGATON MUSASHI W WIRED - Riding Board Effect Set 2
addappid(2760060) -- MEGATON MUSASHI W WIRED - Fashionable Pack Vol. 1
addappid(2760070) -- MEGATON MUSASHI W WIRED - Fashionable Pack Vol. 2
addappid(2760090) -- MEGATON MUSASHI W WIRED - Fashionable Pack Vol. 3
addappid(2760100) -- MEGATON MUSASHI W WIRED - Fashionable Pack Vol. 4
addappid(2760110) -- MEGATON MUSASHI W WIRED - Attire Yamato (Student Uniform)
addappid(2760120) -- MEGATON MUSASHI W WIRED - Attire Masamune (Casual)
addappid(2760130) -- MEGATON MUSASHI W WIRED - Attire Yamato (Yukata)
addappid(2760140) -- MEGATON MUSASHI W WIRED - Attire Victor (Yukata)
addappid(2760150) -- MEGATON MUSASHI W WIRED - Attire Momoka (Yukata)
addappid(2760160) -- MEGATON MUSASHI W WIRED - Attire Arshem (Yukata)
addappid(2760170) -- MEGATON MUSASHI W WIRED - Attire Arshem (Dress)
addappid(2760180) -- MEGATON MUSASHI W WIRED - Attire Arshem (Captains Uniform)
addappid(2760190) -- MEGATON MUSASHI W WIRED - Rogue Musashi (Samurai Red)
addappid(2760210) -- MEGATON MUSASHI W WIRED - Rogue Sparkman Wave (Zeus White)
addappid(2760220) -- MEGATON MUSASHI W WIRED - Rogue Arthur Riser (Dragon Green)
addappid(2760230) -- MEGATON MUSASHI W WIRED - Rogue Kaiser (Castle Snow)
addappid(2760240) -- MEGATON MUSASHI W WIRED - Rogue Mad Bison (Demon Bordeaux)
addappid(2760250) -- MEGATON MUSASHI W WIRED - Rogue Brahms Knight (Night Black)
addappid(2760260) -- MEGATON MUSASHI W WIRED - Rogue Bloody Zelle
addappid(2760270) -- MEGATON MUSASHI W WIRED - Rogue Cybane (Tamahagane Silver)
addappid(2760280) -- MEGATON MUSASHI W WIRED - Victory Pose Kabuki
addappid(2760290) -- MEGATON MUSASHI W WIRED - Victory Pose Badass
addappid(2760300) -- MEGATON MUSASHI W WIRED - Victory Pose Hero
addappid(2760310) -- MEGATON MUSASHI W WIRED - Victory Pose Fist Pump
addappid(2760320) -- MEGATON MUSASHI W WIRED - Victory Pose Bodybuilder
addappid(2760330) -- MEGATON MUSASHI W WIRED - Victory Pose Drums
addappid(2760340) -- MEGATON MUSASHI W WIRED - Victory Pose Karate
addappid(2760350) -- MEGATON MUSASHI W WIRED - Victory Pose Boxing
addappid(2760360) -- MEGATON MUSASHI W WIRED - Victory Pose Robot Dance
addappid(2760370) -- MEGATON MUSASHI W WIRED - Victory Pose Squad Pose
addappid(2760380) -- MEGATON MUSASHI W WIRED - Victory Pose Hoodlum
addappid(2760390) -- MEGATON MUSASHI W WIRED - Victory Pose Mystery

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
addappid(2450451, 1, "e9f62112fdedacb65194d410b7a1cf22ae36f7b86a698c1f04ea7c4ac7a3806a") -- Depot 2450451

