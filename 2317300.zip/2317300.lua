-- Lua provided by RyzenAPI
-- Game: Access Denied: Escape

-- MAIN APPLICATION
addappid(2317300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317301, 1, "54407ae4913487adfc0509a02ebdcbcc951099ca1ea7c88b5040bb0694f3cbce")

