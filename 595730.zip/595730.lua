-- Lua provided by RyzenAPI
-- Game: addappid(595730)

-- MAIN APPLICATION
addappid(595730)

-- MAIN APP DEPOTS / PACKAGES
addappid(595732,0,"0e5f93fabd2c1cdac15616226e038c4c5e31d9dbe3760052dec502a6835752f5")
