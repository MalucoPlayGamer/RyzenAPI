-- Lua provided by RyzenAPI
-- Game: Longshot Universe

-- MAIN APPLICATION
addappid(459770)

-- MAIN APP DEPOTS / PACKAGES
addappid(459771, 1, "188c2393d325b66a1e0ef43d88c27ca1a4757d2bdcd78daeb6bbf7bac6d83018")
addappid(459772, 1, "26391b11ed8265b1dc43ff5c270786be7e0a1be41f91a44301a03fca4081653d")
addappid(459773, 1, "3495092549547b340aabcbaea5abe657e8b11fb79c0019099d8f3d62e008129c")
addappid(459774, 1, "cadb91354ad7f2bce264613ba6de017e68e592656cc09d769bbe79dc8101e15a")

