-- Lua provided by RyzenAPI
-- Game: Camera Obscura

-- MAIN APPLICATION
addappid(341500)

-- MAIN APP DEPOTS / PACKAGES
addappid(341501, 1, "521fec7a4ed6db55282686c682ceb88ab13ef2334b8a1895fe2dd07eed6cdb96")
