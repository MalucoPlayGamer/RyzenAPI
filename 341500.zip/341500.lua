-- Lua provided by RyzenAPI
-- Game: Camera Obscura

-- MAIN APPLICATION
addappid(341500)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(341501, 1, "521fec7a4ed6db55282686c682ceb88ab13ef2334b8a1895fe2dd07eed6cdb96")

