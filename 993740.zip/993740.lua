-- Lua provided by RyzenAPI
-- Game: Hentai Mosaique Puzzle

-- MAIN APPLICATION
addappid(993740)

-- MAIN APP DEPOTS / PACKAGES
addappid(993741, 1, "9e9dde6702a095cfa76b4aaba14da84cf97fee6ab2f194fca3a2453ff726d067")
addappid(993742, 1, "90b77c57705a50503e152ecc9b14d23fe9e78a0476695296fcdd3d83cffc9e46")
