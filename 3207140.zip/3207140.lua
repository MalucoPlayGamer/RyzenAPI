-- Lua provided by RyzenAPI
-- Game: 3207140

-- MAIN APPLICATION
addappid(3207140)
-- Game: addappid(3207140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207141, 1, "4edb10a3cb704b0d49187cccf317739dc19bfbfca981f179d67ba45c985b4bee")
