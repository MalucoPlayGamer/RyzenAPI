-- Lua provided by SkyAPI 
-- Game: ENDLESS DAYS Z
addappid(3146500)
addappid(3146501, 1, "f4bcb70bdb592e32c871061e8d031b78cd8fafed09ed0c4e5a024a26ac60ee8f")
