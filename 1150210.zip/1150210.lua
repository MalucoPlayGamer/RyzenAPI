-- Lua provided by RyzenAPI
-- Game: Blind Spot / 盲点 Demo

-- MAIN APPLICATION
addappid(1150210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150211, 1, "416eb9328992c295dd4f40f0478d9c450b067c09649a5a67f51cd6afc3509546")
