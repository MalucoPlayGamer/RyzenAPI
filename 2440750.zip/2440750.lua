-- Lua provided by RyzenAPI
-- Game: 2440750

-- MAIN APPLICATION
addappid(2440750)
-- Game: addappid(2440750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440752,0,"00d9dd15a98f0c7e647e9ee304b158435db7197fb839bf49fd0b09a37de22f9f")
