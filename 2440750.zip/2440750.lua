-- Lua provided by RyzenAPI
-- Game: Silent North

-- MAIN APPLICATION
addappid(2440750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440752,0,"00d9dd15a98f0c7e647e9ee304b158435db7197fb839bf49fd0b09a37de22f9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
