-- Lua provided by SkyAPI 
-- Game: AppID 3442690
addappid(3442690)
addappid(3442691, 1, "f0fbfb4b3449c5eacbca51095e504786460bb13212e89021ff7f1950fe4e6949")
