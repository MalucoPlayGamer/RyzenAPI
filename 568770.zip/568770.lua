-- Lua provided by RyzenAPI
-- Game: Cinderella Phenomenon - Otome/Visual Novel

-- MAIN APPLICATION
addappid(568770)
addappid(653580)

