-- Lua provided by RyzenAPI
-- Game: The Garden Path

-- MAIN APPLICATION
addappid(1638500)
-- Game: addappid(1638500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638501, 1, "1906609e5c5659ef042d29aeadc5d21bcc0b24529fef2d33cffc9f35d537f089")
