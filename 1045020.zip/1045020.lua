-- Lua provided by RyzenAPI
-- Game: Game: AppID 1045020

-- MAIN APPLICATION
addappid(1045020)
-- Game: addappid(1045020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045021, 1, "64968921f150b624f6464fe682dbd454337484d73fa6ccccf3c11e9308e683ee")
