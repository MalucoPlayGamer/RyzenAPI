-- Lua provided by RyzenAPI 
-- Game: AppID 1045020
addappid(1045020)
addappid(1045021, 1, "64968921f150b624f6464fe682dbd454337484d73fa6ccccf3c11e9308e683ee")
