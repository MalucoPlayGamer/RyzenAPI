-- Lua provided by RyzenAPI
-- Game: Biters & Bullets Demo

-- MAIN APPLICATION
addappid(2099540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099541, 1, "dd3107b7d092b960cbfd0054731dd306c834c1cae9d2cb5d306a0b996b03ff21")

