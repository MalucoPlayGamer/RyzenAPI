-- Lua provided by RyzenAPI
-- Game: Game: KUUKIYOMI Original Soundtrack

-- MAIN APPLICATION
addappid(1710270)
-- Game: addappid(1710270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710271, 1, "2b307065f604800649b8863e95d242b0d13aee49f392fde9ca6f8f3d41ac9e0a")
