-- Lua provided by RyzenAPI
-- Game: Game: Raiden NOVA | 雷電NOVA | 雷電新星

-- MAIN APPLICATION
addappid(2842710)
-- Game: addappid(2842710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842711, 1, "92783109901c705382576ae3bbf51ffbe272890d89b288c9c4f3cf0e38b52a10")
