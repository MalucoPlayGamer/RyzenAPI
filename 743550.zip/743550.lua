-- Lua provided by RyzenAPI
-- Game: COSMONAUT

-- MAIN APPLICATION
addappid(743550)
addappid(796870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(743551, 1, "32c16fdbc7175c4d7b3787566bb4e2638e3872c96856574dd10beaa4694cffcf")

