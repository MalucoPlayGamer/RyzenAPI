-- Lua provided by RyzenAPI
-- Game: COSMONAUT

-- MAIN APPLICATION
addappid(743550)
addappid(796870)
-- Game: addappid(743550)

-- MAIN APP DEPOTS / PACKAGES
addappid(743551, 1, "32c16fdbc7175c4d7b3787566bb4e2638e3872c96856574dd10beaa4694cffcf")
