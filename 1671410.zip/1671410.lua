-- Lua provided by SkyAPI 
-- Game: Somerville
addappid(1671410)
addappid(1671411, 1, "66bb5b9b67ea07b7fb8d3c6f3524894d5a247a537648d5c1519aaac821ae00f3")
