-- Lua provided by RyzenAPI
-- Game: Memento Mori Soundtrack

-- MAIN APPLICATION
addappid(200496)

-- MAIN APP DEPOTS / PACKAGES
addappid(200496,0,"0fe5a6a0395f98689aadcdc0899bd8dcf6909cd23864e818fdc82bbb435c0f6e")

