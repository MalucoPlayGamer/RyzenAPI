-- Lua provided by RyzenAPI
-- Game: addappid(426310)

-- MAIN APPLICATION
addappid(426310)

-- MAIN APP DEPOTS / PACKAGES
addappid(426311, 1, "206b2f658c85e7c4728b6d3f21beab0437ff8d37d9f84e692dc9a776933919dd")
