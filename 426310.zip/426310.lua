-- Lua provided by RyzenAPI
-- Game: AppID 426310

-- MAIN APPLICATION
addappid(426310)

-- MAIN APP DEPOTS / PACKAGES
addappid(426311, 1, "206b2f658c85e7c4728b6d3f21beab0437ff8d37d9f84e692dc9a776933919dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
