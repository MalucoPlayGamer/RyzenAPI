-- Lua provided by RyzenAPI
-- Game: addappid(1494608)

-- MAIN APPLICATION
addappid(1494608)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494608,0,"8876a93fdb513ecbd0aacdcb69b1901199d83b3a3750ad0d6c7075d368203af6")
