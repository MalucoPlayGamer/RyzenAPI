-- Lua provided by RyzenAPI
-- Game: AppID 648590

-- MAIN APPLICATION
addappid(648590)

-- MAIN APP DEPOTS / PACKAGES
addappid(648591, 1, "5c28dea4e54df8f1103d34dde9da24b2ec1934112073ef6e5fdd1fc504fb75c4")
addappid(648593, 1, "27779f1514acf8b3479394aa53e7959eab73a178c29f22a8c54800bcb0c0303f")
addappid(648594, 1, "36107be5c3c45548564b778e1f9a9f65cb62451c33a6c69a0e28c95976736581")
addappid(648595, 1, "9086faa4a86ae0ad848e04db749c8674f29efce9470e5306241d499acf0d93c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
