-- Lua provided by RyzenAPI
-- Game: Sweet and Cute

-- MAIN APPLICATION
addappid(1374500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374501, 1, "b97b3f68291e9c3653b02b700168e360394722406988525acd1695cae30c46b2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1377750)
