-- Lua provided by RyzenAPI
-- Game: Game: Idle Planets

-- MAIN APPLICATION
addappid(2768260)
-- Game: addappid(2768260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768261, 1, "67587112e669b4c9cd803933f0c269d1aeb3b174696dc8d86ccc9ccbd27ce8c3")
