-- Lua provided by SkyAPI 
-- Game: Idle Planets
addappid(2768260)
addappid(2768261, 1, "67587112e669b4c9cd803933f0c269d1aeb3b174696dc8d86ccc9ccbd27ce8c3")
