-- Lua provided by RyzenAPI
-- Game: 823360

-- MAIN APPLICATION
addappid(823360)
-- Game: addappid(823360)

-- MAIN APP DEPOTS / PACKAGES
addappid(823361, 1, "b1b683b179ab84fa3950428d0bbc72f0793c5c689915964c3ee0f2a3013559d8")
