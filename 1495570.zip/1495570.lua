-- Lua provided by SkyAPI 
-- Game: Hentai GIF Puzzle
addappid(1495570)
addappid(1495571, 1, "a871333bf3f8d856922acd24991b7ecf598c54798207e55ffbe32799ac73657c")
