-- Lua provided by RyzenAPI
-- Game: Vague Lizards

-- MAIN APPLICATION
addappid(2941170)
addappid(2979090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941171, 1, "d5d61d459115e111cee85282e3c421af49d85c7b38a9fcda83dfd4ffe558eb84")

