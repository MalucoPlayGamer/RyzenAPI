-- Lua provided by RyzenAPI
-- Game: 3179400

-- MAIN APPLICATION
addappid(3179400)
-- Game: addappid(3179400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179401, 1, "fcac6602c6772a4704fbd11939d7a483fc9b1980c20d4e195e675ccd0a14b9b4")
