-- Lua provided by RyzenAPI
-- Game: Rushmore

-- MAIN APPLICATION
addappid(1534950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534951, 1, "4d12a2d507168516607777b204bc8cb78783adc7bf4aac608efefd83223ff7f2")

