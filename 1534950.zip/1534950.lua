-- Lua provided by RyzenAPI
-- Game: Rushmore

-- MAIN APPLICATION
addappid(1534950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534951, 1, "4d12a2d507168516607777b204bc8cb78783adc7bf4aac608efefd83223ff7f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
