-- Lua provided by RyzenAPI
-- Game: 1982940

-- MAIN APPLICATION
addappid(1982940)
-- Game: addappid(1982940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982942,0,"461ca38a3daea4fe2ad59789d20a0a9fbf313dbf40e7293f8ea6db233544ebfa")
addappid(1982943,0,"71183e6d5de9598b94abca1bced1e16ff15396a84ec1f7db45e8bd07c0c65c94")
addappid(1982944,0,"dafde2a08b2ea7fe6c1a1fbfad0282550ee31eeb91537928d3247c7f963b7283")
