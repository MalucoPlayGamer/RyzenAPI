-- Lua provided by RyzenAPI
-- Game: addappid(1592490)

-- MAIN APPLICATION
addappid(1592490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592491, 1, "41878009fe7dfc5b0ca5249d63febb6843af41f800e24539a6957a4238ce70f3")
