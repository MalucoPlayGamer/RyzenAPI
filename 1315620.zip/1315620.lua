-- Lua provided by RyzenAPI
-- Game: EndlessShinyBlues

-- MAIN APPLICATION
addappid(1315620)
-- Game: addappid(1315620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315621, 1, "990238109f3091933e065b431fd8175162194b6571c3f22bf40090acd32fe5a2")
