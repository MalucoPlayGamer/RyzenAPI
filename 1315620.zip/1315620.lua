-- Lua provided by RyzenAPI
-- Game: EndlessShinyBlues

-- MAIN APPLICATION
addappid(1315620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315621, 1, "990238109f3091933e065b431fd8175162194b6571c3f22bf40090acd32fe5a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
