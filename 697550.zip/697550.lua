-- Lua provided by RyzenAPI
-- Game: addappid(697550)

-- MAIN APPLICATION
addappid(697550)

-- MAIN APP DEPOTS / PACKAGES
addappid(697551, 1, "f6aa1307f9795f078290aa9fdfc5d81b2a912f3d9cd18efb7daa90496a588c45")
