-- Lua provided by RyzenAPI 
-- Game: AppID 697550
addappid(697550)
addappid(697551, 1, "f6aa1307f9795f078290aa9fdfc5d81b2a912f3d9cd18efb7daa90496a588c45")
