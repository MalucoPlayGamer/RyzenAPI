-- Lua provided by RyzenAPI
-- Game: addappid(2216660)

-- MAIN APPLICATION
addappid(2216660)
addappid(2973140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216661, 1, "76ef1545e653200f1dbedefe70a3c5bf32def32852fc69f1cbf8856ea3d141ea")
