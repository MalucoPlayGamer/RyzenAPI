-- Lua provided by RyzenAPI
-- Game: Synergy Dedicated Server

-- MAIN APPLICATION
addappid(17525)

-- MAIN APP DEPOTS / PACKAGES
addappid(206,0,"15a624d389f3b12993eafaea17f4304957d13aa116f561faf36c4dd97a664123")
addappid(207,0,"cc9eeb827bbf37b90172eb6a19d04568a00bcb01ac03a168b3f09a2e4ca48be0")
addappid(208,0,"f5da5520e5d11228bb9e146324c9dc2b2387d00eb0df7829ad787bc7d299066a")
addappid(305,0,"87f5b172a392e11d80facf1239bc315d21f903af56ddd6da5d6cb497c78c7bdb")
addappid(306,0,"b49ba7a68678b69ffec8330ebf7212bdbc962eff1b7691e8933ef9654dc6c2bf")
addappid(307,0,"3e2b9d08c74433d95f72d7f5037e02a0837c510fe4a53c8c542cbea99694d3ce")
addappid(310,0,"67d970f8b29249c7550b52eaf6d007725e0e2aef06c449359e6c8e1fc30480e1")
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
addappid(17522,0,"79dec28a9ccea607779ffdd986dd6244ef741815c934b5b6d5f9e4e04531e179")

