-- Lua provided by RyzenAPI
-- Game: Kakenuke★Forward to Our Sparking Youth!

-- MAIN APPLICATION
addappid(3027620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027621, 1, "0793cd57dd6eaff1bd8fdd054c72023a3f47e1da8675a256f8505783ca963441")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
