-- Lua provided by RyzenAPI
-- Game: Kakenuke★Forward to Our Sparking Youth!

-- MAIN APPLICATION
addappid(3027620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027621, 1, "0793cd57dd6eaff1bd8fdd054c72023a3f47e1da8675a256f8505783ca963441")
