-- Lua provided by RyzenAPI
-- Game: Game: 幻世九州

-- MAIN APPLICATION
addappid(2153640)
-- Game: addappid(2153640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153641, 1, "c6bc82deafd4a09c6189dd706a015ad5528556c95d2fb69b70ca29603a5ff53f")
