-- Lua provided by RyzenAPI
-- Game: 3023190

-- MAIN APPLICATION
addappid(3023190)
-- Game: addappid(3023190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023191, 1, "03a84ec9238c4bc03114f70e0c53f778349e5b4c19320de613a7e3d680bc9b31")
