-- Lua provided by RyzenAPI
-- Game: Deduce Together

-- MAIN APPLICATION
addappid(3023190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023191, 1, "03a84ec9238c4bc03114f70e0c53f778349e5b4c19320de613a7e3d680bc9b31")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
