-- Lua provided by RyzenAPI
-- Game: 3699540

-- MAIN APPLICATION
addappid(3699540)
-- Game: addappid(3699540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3699541, 1, "213cadc9974edb8cc49b85e38d5e0892b9e9c3b644282260c6751b6f67172ebc")
