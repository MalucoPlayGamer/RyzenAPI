-- Lua provided by RyzenAPI
-- Game: Rubbings

-- MAIN APPLICATION
addappid(2819030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819031, 1, "981caf1fada14e2e96986a4e7fa70a48900777cee55ef2995c32fd630e27cf08")

