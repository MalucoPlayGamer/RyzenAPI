-- Lua provided by RyzenAPI
-- Game: 2819030

-- MAIN APPLICATION
addappid(2819030)
-- Game: addappid(2819030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819031, 1, "981caf1fada14e2e96986a4e7fa70a48900777cee55ef2995c32fd630e27cf08")
