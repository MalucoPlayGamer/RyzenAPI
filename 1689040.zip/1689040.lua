-- Lua provided by RyzenAPI
-- Game: The Last Oricru Demo

-- MAIN APPLICATION
addappid(1689040)
-- Game: addappid(1689040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689041, 1, "5d4bcd719eac83fbe0f201c012488ff8139c3da4e345407e5df1a03bbed913ea")
