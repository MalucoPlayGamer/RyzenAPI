-- Lua provided by RyzenAPI 
-- Game: The Last Oricru Demo
addappid(1689040)
addappid(1689041, 1, "5d4bcd719eac83fbe0f201c012488ff8139c3da4e345407e5df1a03bbed913ea")
