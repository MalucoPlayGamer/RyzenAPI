-- Lua provided by RyzenAPI
-- Game: Survival Revelation: End of Days

-- MAIN APPLICATION
addappid(2408700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408701, 1, "ed04d9a53c53e863fe818600cf78380ace42bc8bdc962fc8ee504a95e7634256")
