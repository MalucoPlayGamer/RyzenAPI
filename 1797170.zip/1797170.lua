-- Lua provided by RyzenAPI
-- Game: Thunder Tier One Dedicated Server

-- MAIN APPLICATION
addappid(1797170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797171, 1, "b127ed340264a1a7c861b960b208efa1afc9b450954bc06611e0b1a80daabfab")

