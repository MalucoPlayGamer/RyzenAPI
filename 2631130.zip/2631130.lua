-- Lua provided by RyzenAPI
-- Game: Idle Exorcism Hero

-- MAIN APPLICATION
addappid(2631130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631131, 1, "bce289eca3b0edb31796ffd365d254123dba1a06626e0ec53eec570a3d9f1017")
