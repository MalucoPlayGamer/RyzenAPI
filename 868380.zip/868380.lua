-- Lua provided by RyzenAPI
-- Game: Sexbot Quality Assurance Simulator

-- MAIN APPLICATION
addappid(868380)
-- Game: addappid(868380)

-- MAIN APP DEPOTS / PACKAGES
addappid(868381, 1, "ae3aa73f65f85b0ed5098c5579a21ee80f63b8d18e95fbe931c9b9452fe8d89d")
