-- Lua provided by RyzenAPI
-- Game: Escape the City

-- MAIN APPLICATION
addappid(1404150)
-- Game: addappid(1404150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404151, 1, "180d7d6f15a196b24eb31fffe73eb05e65ce00d7a4ef8abce93142b72bf2923d")
