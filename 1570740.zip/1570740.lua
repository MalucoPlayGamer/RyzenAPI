-- Lua provided by RyzenAPI
-- Game: Sacred Cubes

-- MAIN APPLICATION
addappid(1570740)
-- Game: addappid(1570740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1570741, 1, "beb8770164ff57545d38f4c9b74b26bb00128c3a189e50117b3dd3b1c1e076e3")
