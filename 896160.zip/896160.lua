-- Lua provided by RyzenAPI
-- Game: Evil Bank Manager

-- MAIN APPLICATION
addappid(896160)
-- Game: addappid(896160)

-- MAIN APP DEPOTS / PACKAGES
addappid(896161, 1, "869c6a05eacbbca7f9216094bc808e7466b583d8ada8ccb4f38931d34c574e75")
addappid(896162, 1, "32314fa0c459d7a395c93297699ab2bc8e6f93d7c142070fa749c99b35be43ed")
