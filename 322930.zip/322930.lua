-- Lua provided by RyzenAPI
-- Game: aerofly RC 7

-- MAIN APPLICATION
addappid(322930)
-- Game: addappid(322930)

-- MAIN APP DEPOTS / PACKAGES
addappid(322931, 1, "09bfb77561cd4c9d4f15844d25680eb2fed5408553d479f9d93ea0f7ba20e9f2")
