-- Lua provided by RyzenAPI
-- Game: Idle Knight

-- MAIN APPLICATION
addappid(4579750)
