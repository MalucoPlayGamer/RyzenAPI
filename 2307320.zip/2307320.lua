-- Lua provided by RyzenAPI
-- Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.6「対交錯事件」

-- MAIN APPLICATION
addappid(2307320)
-- Game: addappid(2307320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307321, 1, "8920a2852b96bb2bd1c387567f52b412ae71686c1106855c1db7f1305e8c5311")
