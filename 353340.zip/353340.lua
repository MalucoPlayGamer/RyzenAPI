-- Lua provided by RyzenAPI
-- Game: setManifestid(353342,"7341236617343171232")

-- MAIN APPLICATION
addappid(353340)
-- Game: addappid(353340)

-- MAIN APP DEPOTS / PACKAGES
addappid(353342,0,"29125004bfd85721d0c761f1bd57c851bb53931dcbdb99e26986b508cfe5e527")
