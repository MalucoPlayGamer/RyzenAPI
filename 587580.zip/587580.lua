-- Lua provided by RyzenAPI
-- Game: Game: Nature Treks VR

-- MAIN APPLICATION
addappid(587580)
-- Game: addappid(587580)

-- MAIN APP DEPOTS / PACKAGES
addappid(587581, 1, "cd07e04ba67198c6cb4f7d4eaea783202bdb87262d1014f6a28f2e87f3c69083")
