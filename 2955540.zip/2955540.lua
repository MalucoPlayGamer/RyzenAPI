-- Lua provided by RyzenAPI
-- Game: Jeepney Simulator 2 Demo

-- MAIN APPLICATION
addappid(2955540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955541, 1, "30a764ae37763eb5f16f93226867004e5a975ee318a307919a1db5d26d7d7c03")
