-- Lua provided by RyzenAPI
-- Game: 397810

-- MAIN APPLICATION
addappid(397810)
-- Game: addappid(397810)

-- MAIN APP DEPOTS / PACKAGES
addappid(397811, 1, "b265ce008b344c74dafdf6dd9bd382edac20f1044c0cf6d4d67bd8031281e909")
