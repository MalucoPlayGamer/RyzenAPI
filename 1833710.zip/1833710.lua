-- Lua provided by RyzenAPI 
-- Game: My Museum: Treasure Hunter
addappid(1833710)
addappid(1833711, 1, "6d32069928ccd6680c01e49852f5213f702fa50c52a795b272bf81370e543070")
