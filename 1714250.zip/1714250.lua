-- Lua provided by RyzenAPI
-- Game: Pets Hotel

-- MAIN APPLICATION
addappid(1714250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714251, 1, "4466eb71b021c2a38048a1ab4772f37dc6b1f2f6f143742d64034d10cd086d5f")
