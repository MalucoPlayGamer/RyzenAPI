-- Lua provided by SkyAPI 
-- Game: Pets Hotel
addappid(1714250)
addappid(1714251, 1, "4466eb71b021c2a38048a1ab4772f37dc6b1f2f6f143742d64034d10cd086d5f")
