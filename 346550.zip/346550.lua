-- Lua provided by RyzenAPI
-- Game: AppID 346550

-- MAIN APPLICATION
addappid(346550)

-- MAIN APP DEPOTS / PACKAGES
addappid(346551, 1, "da6c3f27978e67285abe52feae77c2c8665e3fe4fb785983512ea0ba29171de3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
