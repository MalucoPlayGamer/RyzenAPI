-- Lua provided by RyzenAPI
-- Game: addappid(346550)

-- MAIN APPLICATION
addappid(346550)

-- MAIN APP DEPOTS / PACKAGES
addappid(346551, 1, "da6c3f27978e67285abe52feae77c2c8665e3fe4fb785983512ea0ba29171de3")
