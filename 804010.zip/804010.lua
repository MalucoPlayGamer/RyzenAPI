-- Lua provided by RyzenAPI
-- Game: SteamWorld Quest: Hand of Gilgamech

-- MAIN APPLICATION
addappid(804010)

-- MAIN APP DEPOTS / PACKAGES
addappid(804011, 1, "0958333bf4e3231c5df2e71794735288cce841197a2e50886ab364f165f3ba75")
addappid(804012, 1, "83c1fe330be108230bfef869cae2c5dfd0098fa5288ca47016c367a6969c1405")
addappid(804013, 1, "c49a6b6b8e0dd148dc8bbf0d094987d1c54219a06d60a222e42edea639802412")
