-- Lua provided by RyzenAPI
-- Game: SteamWorld Quest: Hand of Gilgamech

-- MAIN APPLICATION
addappid(804010)

-- MAIN APP DEPOTS / PACKAGES
addappid(804011, 1, "0958333bf4e3231c5df2e71794735288cce841197a2e50886ab364f165f3ba75")
addappid(804012, 1, "83c1fe330be108230bfef869cae2c5dfd0098fa5288ca47016c367a6969c1405")
addappid(804013, 1, "c49a6b6b8e0dd148dc8bbf0d094987d1c54219a06d60a222e42edea639802412")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
