-- Lua provided by RyzenAPI
-- Game: Fat Mask

-- MAIN APPLICATION
addappid(516790)

-- MAIN APP DEPOTS / PACKAGES
addappid(516791, 1, "46c4b304b18034841892c70115d7f35af3f69dad04b91ea9e2d9cf3722c1e3d3")

