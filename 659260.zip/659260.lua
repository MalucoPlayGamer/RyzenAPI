-- Lua provided by RyzenAPI
-- Game: Canvas Quest

-- MAIN APPLICATION
addappid(659260)

-- MAIN APP DEPOTS / PACKAGES
addappid(659261, 1, "482342a4cd4c9bea3c645aa7bb4055104d1400b1969aaaf9ea25c5b3902c01bc")
