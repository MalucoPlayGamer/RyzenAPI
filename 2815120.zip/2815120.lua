-- Lua provided by SkyAPI 
-- Game: E-Startup 2 : Business Tycoon Prologue
addappid(2815120)
addappid(2815121, 1, "3e5bb73841a983889a1f27919fa0826d3a5dae006f5e01c456e9807603f528de")
