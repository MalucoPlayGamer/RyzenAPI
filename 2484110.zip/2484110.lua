-- Lua provided by RyzenAPI
-- Game: addappid(2484110)

-- MAIN APPLICATION
addappid(2484110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484111, 1, "b3a968d9a6cc78c6beb8210974b098248155fb4c1381c8ee468f6dc99d7f0a9d")
