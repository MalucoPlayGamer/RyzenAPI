-- 2213700's Lua and Manifest Created by Hubcap Manifest
-- Sintopia
-- Created: May 28, 2026 at 13:29:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2213700, 1, "9952eca0e31a7bd8afe828786115631220c54e3a9d91f6174f3c6354950ed4a8") -- Sintopia
addtoken(2213700, "15646133038759125871")
-- MAIN APP DEPOTS
addappid(2213701, 1, "92993b60326b46a95c1559344bd5f1c66048450cafd4bb635948b3a5a99c7d4e") -- Depot 2213701
-- setManifestid(2213701, "5081633652896960035", 10470191666)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
-- setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Sintopia - Digital Artbook (AppID: 3497180)
addappid(3497180)
addappid(3497181, 1, "4cb37865617d3c0e9b39efb522bc2f991625993f87865858876112b63852c3b8") -- Sintopia - Digital Artbook - Depot 3497181
-- setManifestid(3497181, "8714545793029603986", 147717461)