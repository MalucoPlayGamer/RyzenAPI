-- Lua provided by RyzenAPI
-- Game: The Tower

-- MAIN APPLICATION
addappid(696580)

-- MAIN APP DEPOTS / PACKAGES
addappid(696581,0,"d9fa8d904c9fce5547a0e315c478a1104427bfdfdcf959da5d79146a94ea9a0c")

