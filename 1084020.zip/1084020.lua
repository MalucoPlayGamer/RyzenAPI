-- Lua provided by SkyAPI 
-- Game: TheoTown
addappid(1084020)
addappid(1084021, 1, "53cf5369fb7f8fcacfe7efc6a6a640c7eeaddaa4cbcc283666eab8fbb1e0bd95")
addappid(1084022, 1, "763370776404b2a8d74f827a2c6d2d78c3c78f09f1c84716c6132cea41ec391b")
addappid(1084023, 1, "cc1ec45db95ff8755bdce02c1ecc91357a849f489c8bc19660d0d960cd77bd0a")
