-- Lua provided by RyzenAPI
-- Game: addappid(794940)

-- MAIN APPLICATION
addappid(794940)

-- MAIN APP DEPOTS / PACKAGES
addappid(794941, 1, "15c52c6557a5efffc87b5a06acd875f91bdf6db723abd6bd873da84033385ad9")
