-- Lua provided by RyzenAPI
-- Game: Autogun Heroes: Supercharged

-- MAIN APPLICATION
addappid(3328730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3328731, 1, "2eb28c860b074a6729fde3e0dd4def575d4032ba7ba862f8435c0d026c20337d")
