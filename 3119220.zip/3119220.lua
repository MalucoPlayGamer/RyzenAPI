-- Lua provided by RyzenAPI
-- Game: 3119220

-- MAIN APPLICATION
addappid(3119220)
-- Game: addappid(3119220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3119221, 1, "37d15e5881bd9ef1940ee2986b3f22a9d3bc7dc451c2fbccc81747dfc410eca8")
