-- Lua provided by RyzenAPI
-- Game: Beacon Patrol: First Horizons

-- MAIN APPLICATION
addappid(2554990)
-- Game: addappid(2554990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2554991, 1, "908e76746f9bed413be8942e3627f4398ed94c310aa756deb144522e45032770")
addappid(2554992, 1, "72eb809958a9bc2009af368ca66fdf63e04dd0fd6071d4ad75e93cfb7ab8869a")
addappid(2554993, 1, "8eb5c42a6d658b853cebaaafed295194c42de561bb2ee91fdc9cd84169afea5e")
