-- Lua provided by RyzenAPI
-- Game: DFF NT: Second Coming, Sephiroth's 4th Weapon

-- MAIN APPLICATION
addappid(1022421)
-- Game: addappid(1022421)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022421,0,"138687dc42e47646b1a17f6934e41bd98cb6fad75863df6700fa186418b416c8")
