-- Lua provided by RyzenAPI
-- Game: Mosaic Chronicles

-- MAIN APPLICATION
addappid(1034150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034152,0,"33f530debcfb18646751aab61bf8cbfef40678fa9bd1abc5fb2ced2fe7b1dca3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2579940)
