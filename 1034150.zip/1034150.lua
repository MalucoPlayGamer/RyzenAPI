-- Lua provided by RyzenAPI
-- Game: Mosaic Chronicles

-- MAIN APPLICATION
addappid(1034150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034152,0,"33f530debcfb18646751aab61bf8cbfef40678fa9bd1abc5fb2ced2fe7b1dca3")

