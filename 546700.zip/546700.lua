-- Lua provided by RyzenAPI
-- Game: The Butterfly Sign

-- MAIN APPLICATION
addappid(546700)
addappid(552760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(546701, 1, "b7b4d1be771a28baaece469e5807bdb415aae9bb242bdfa20c0e7893f3dec2b1")

