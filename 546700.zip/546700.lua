-- Lua provided by RyzenAPI
-- Game: Game: The Butterfly Sign

-- MAIN APPLICATION
addappid(546700)
addappid(552760)
-- Game: addappid(546700)

-- MAIN APP DEPOTS / PACKAGES
addappid(546701, 1, "b7b4d1be771a28baaece469e5807bdb415aae9bb242bdfa20c0e7893f3dec2b1")
