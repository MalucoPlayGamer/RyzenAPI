-- Lua provided by RyzenAPI
-- Game: Game: Planet Coaster

-- MAIN APPLICATION
addappid(493340)
addappid(520710)
addappid(540750)
addappid(540751)
addappid(540752)
addappid(540760)
addappid(611400)
addappid(611420)
addappid(611421)
addappid(710490)
addappid(710500)
addappid(710530)
addappid(768830)
addappid(821090)
addappid(891230)
addappid(953660)
addappid(995780)
addappid(1061350)
addappid(1092880)
addappid(1094160)
addappid(2171430)
-- Game: addappid(493340)

-- MAIN APP DEPOTS / PACKAGES
addappid(493341, 1, "09a4f06e0ef8de8d1caf20ff08c96103f36c42117bfbada84788bbbb1e6fb540")
addappid(493359, 1, "38c45d793c46bac67e42f1a20ba64fc3d92edeb7dd9fda970d75db772a664520")
addappid(553770, 0, "89104dad5e5c9353db7da2a99242c14b9da5fa15e5e838953b4c2ca13e9cf43a")
addappid(553771, 0, "8f009b27cac943465ce5619ce1fb47db51d461407158065897ee58150490f9d1")
