-- Lua provided by RyzenAPI
-- Game: AppID 1233590

-- MAIN APPLICATION
addappid(1233590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233591, 1, "a79f197954dc5c6d8534965c4013453a38eca5ffd578e921d4042f5ff6653c52")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1405940)
