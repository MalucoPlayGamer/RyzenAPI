-- Lua provided by RyzenAPI
-- Game: Game: AppID 1233590

-- MAIN APPLICATION
addappid(1233590)
-- Game: addappid(1233590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233591, 1, "a79f197954dc5c6d8534965c4013453a38eca5ffd578e921d4042f5ff6653c52")
