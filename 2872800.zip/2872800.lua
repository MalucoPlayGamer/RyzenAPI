-- Lua provided by RyzenAPI
-- Game: Wacky Burgers

-- MAIN APPLICATION
addappid(2872800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2872801, 1, "8c633954dc4c1a68446f5f88870241f5d7e8c91ba3896803442f23e9a98465ab")

