-- Lua provided by RyzenAPI
-- Game: Infiltrating a Cult

-- MAIN APPLICATION
addappid(1901450)
addappid(2378850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901451, 1, "e07c8015c8fd681293f57e2ba6084aa32ab64f49cd61a1c22e38685b77ec73a1")

