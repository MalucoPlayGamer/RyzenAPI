-- Lua provided by RyzenAPI
-- Game: 3782150

-- MAIN APPLICATION
addappid(3782150)
-- Game: addappid(3782150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3782151, 1, "968517484bef53c848de9b5ad85620cba9f9055dd59ffb1d9f74333e5a779beb")
