-- Lua provided by RyzenAPI
-- Game: Blockworks

-- MAIN APPLICATION
addappid(1825970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825971, 1, "789ca8d87443a557253d003884893a7dceba12808f0be353411f0c76f018b11f")
