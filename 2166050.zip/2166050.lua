-- Lua provided by RyzenAPI
-- Game: Moonleap

-- MAIN APPLICATION
addappid(2166050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166051, 1, "c215095d0a87616b8c5beb0ab58c81002843f3727ac71e8680b0d374256acddd")
