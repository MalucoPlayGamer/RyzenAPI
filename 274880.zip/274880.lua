-- Lua provided by RyzenAPI
-- Game: addappid(274880)

-- MAIN APPLICATION
addappid(274880)

-- MAIN APP DEPOTS / PACKAGES
addappid(274881, 1, "1e7eec99797ff3f76e9acda0900fb750fd6cc71f6a30bcae5d27a00c56f4a71e")
