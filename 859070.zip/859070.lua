-- Lua provided by RyzenAPI
-- Game: AppID 859070

-- MAIN APPLICATION
addappid(859070)

-- MAIN APP DEPOTS / PACKAGES
addappid(859071, 1, "df888b8c3058b9fd77d12c913c79be7b2d5c0faf790875bbcea6e3991d3a70aa")
