-- Lua provided by RyzenAPI
-- Game: Crazy Oddballs: Idle RPG

-- MAIN APPLICATION
addappid(4507620)

