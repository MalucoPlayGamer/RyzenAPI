-- Lua provided by RyzenAPI
-- Game: Crazy Oddballs: Idle RPG

-- MAIN APPLICATION
addappid(4507620)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4528360)
addappid(4528370)
