-- Lua provided by RyzenAPI
-- Game: Seek Etyliv

-- MAIN APPLICATION
addappid(805920)

-- MAIN APP DEPOTS / PACKAGES
addappid(805921,0,"e23bd60630b4f64eabad2b8e2675d268b36afdc7b4247259d4fb56c16ad1032e")
addappid(805924,0,"9263df9eb5cb4653631379dda9429bd1fe579238a1834ca032b22ddf8f14f89c")

