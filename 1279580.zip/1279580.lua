-- Lua provided by RyzenAPI
-- Game: Fortress V2

-- MAIN APPLICATION
addappid(1279580)
-- Game: addappid(1279580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279581, 1, "2e0d568a0a3697a89adbe7c0d0e00af490fa12f2990b2f8ac8127bd300c9c7dc")
