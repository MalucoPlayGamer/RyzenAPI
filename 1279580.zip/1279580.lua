-- Lua provided by RyzenAPI
-- Game: Fortress V2

-- MAIN APPLICATION
addappid(1279580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279581, 1, "2e0d568a0a3697a89adbe7c0d0e00af490fa12f2990b2f8ac8127bd300c9c7dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1483290)
addappid(1708440)
