-- Lua provided by RyzenAPI
-- Game: Retro Drift

-- MAIN APPLICATION
addappid(1222180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222181, 1, "4c1326fa0d64d1ca313b012a8e47ec9f12e80c0436d42fe891c778435b32598b")
