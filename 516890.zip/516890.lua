-- Lua provided by RyzenAPI
-- Game: Alchemic Jousts

-- MAIN APPLICATION
addappid(516890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(516891, 1, "a26ca1822f4ce597a3c7be4193e96e1e7a3477db247f1dac50f8e9d64fc3d7b5")
