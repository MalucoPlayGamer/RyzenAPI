-- Lua provided by RyzenAPI
-- Game: Game: AppID 516890

-- MAIN APPLICATION
addappid(516890)
-- Game: addappid(516890)

-- MAIN APP DEPOTS / PACKAGES
addappid(516891, 1, "a26ca1822f4ce597a3c7be4193e96e1e7a3477db247f1dac50f8e9d64fc3d7b5")
