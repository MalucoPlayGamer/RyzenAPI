-- Lua provided by RyzenAPI
-- Game: 1726130

-- MAIN APPLICATION
addappid(1726130)
-- Game: addappid(1726130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726131, 1, "b2a6e1b03d3993d322e9df6ce92c370c2eded9c6311e4af8e6ed287473606f11")
