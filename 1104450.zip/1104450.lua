-- Lua provided by RyzenAPI
-- Game: Bombergrounds: Reborn

-- MAIN APPLICATION
addappid(1104450)

