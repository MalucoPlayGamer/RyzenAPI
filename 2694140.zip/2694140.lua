-- Lua provided by RyzenAPI 
-- Game: Zooplop
addappid(2694140)
addappid(2694141, 1, "bf2d6edc6474139c5fb99224daeca5905a108e3ef7678acef9878eece974597f")
