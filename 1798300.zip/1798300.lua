-- Lua provided by RyzenAPI
-- Game: Game: 1940

-- MAIN APPLICATION
addappid(1798300)
-- Game: addappid(1798300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798301, 1, "e7006f83249132c30cc308efb374e1dace6c17f0849b816764f0659857940052")
