-- Lua provided by RyzenAPI
-- Game: The Alto Collection

-- MAIN APPLICATION
addappid(2837600)
-- Game: addappid(2837600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837601, 1, "4974008f7d63c9253123c8e4e775b49757d6cc4914c119d24437a25cd3819b14")
