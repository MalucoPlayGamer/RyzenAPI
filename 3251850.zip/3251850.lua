-- Lua provided by RyzenAPI
-- Game: Bound by Desire 🍆👩

-- MAIN APPLICATION
addappid(3251850)
-- Game: addappid(3251850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3251851, 1, "94f3b7e9593b31d9a1d930a171e0fdb8e4c9a4e2f452393d7a668e4c7ffd6d49")
