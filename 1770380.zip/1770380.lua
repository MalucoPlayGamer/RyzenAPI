-- Lua provided by RyzenAPI
-- Game: SEX Prison [18+]

-- MAIN APPLICATION
addappid(1770380)
-- Game: addappid(1770380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770381, 1, "a7a6822c30d46344b3186a5d279d49eb532df37d7937abe927ec12a031974255")
