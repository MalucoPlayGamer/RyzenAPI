-- Lua provided by RyzenAPI
-- Game: Glass Cannon

-- MAIN APPLICATION
addappid(3325030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3325031, 1, "6759c366d12a3b0c6b4cf7acb1f7943ff63e6992dc3c2ad13dcd7cb8972ce958")

