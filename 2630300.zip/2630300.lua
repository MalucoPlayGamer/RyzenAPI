-- Lua provided by RyzenAPI
-- Game: The Imperial Capital Burns - Muv-Luv Alternative Total Eclipse

-- MAIN APPLICATION
addappid(2630300)
-- Game: addappid(2630300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2630301, 1, "2fef28f6c1ccfd256395d290d9363a52027e64307e9074afcf61f7edd3fb41f6")
