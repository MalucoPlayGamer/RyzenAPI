-- Lua provided by RyzenAPI
-- Game: The Imperial Capital Burns - Muv-Luv Alternative Total Eclipse

-- MAIN APPLICATION
addappid(2630300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2630301, 1, "2fef28f6c1ccfd256395d290d9363a52027e64307e9074afcf61f7edd3fb41f6")

