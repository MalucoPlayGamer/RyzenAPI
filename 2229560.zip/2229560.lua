-- Lua provided by RyzenAPI
-- Game: Zet Zillions

-- MAIN APPLICATION
addappid(2229560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229561, 1, "91161aebcfa29bf039b624a2c81f097793db4455287bda944179623d65bc535a")
