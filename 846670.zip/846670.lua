-- Lua provided by RyzenAPI
-- Game: AppID 846670

-- MAIN APPLICATION
addappid(846670)

-- MAIN APP DEPOTS / PACKAGES
addappid(846671, 1, "ea41296ff95c02f177c769c60a3af5f404f5498e8227aa464e39897655c10750")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(939570)
