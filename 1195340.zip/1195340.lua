-- Lua provided by RyzenAPI
-- Game: Game: Hermes: Rescue Mission

-- MAIN APPLICATION
addappid(1195340)
-- Game: addappid(1195340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195341, 1, "045023698758676fdf78b46692a15ed29e85c94a07096014a169f23dc7347369")
