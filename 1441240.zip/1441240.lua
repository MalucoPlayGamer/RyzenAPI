-- Lua provided by RyzenAPI
-- Game: Paradiso Guardian

-- MAIN APPLICATION
addappid(1441240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441241, 1, "15b860d9ef7f54520e7294b91a27354376c1d5fe51563fd7a0597b50d0ad3494")

