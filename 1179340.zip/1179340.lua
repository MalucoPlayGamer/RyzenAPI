-- Lua provided by RyzenAPI
-- Game: Kōmori Fruit Rush

-- MAIN APPLICATION
addappid(1179340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179341, 1, "77a321a148d062fef589438c69569aa12d7bc03ad5d311680d9d28605cc5e183")

