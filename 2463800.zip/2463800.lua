-- Lua provided by RyzenAPI
-- Game: Iron Saga VS

-- MAIN APPLICATION
addappid(2463800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2463801, 1, "8cdcbb70a237c9400218b90880a7eabf73d24271972575a40238baa5ba28f3bb")
addappid(3777150, 0, "5fb4a9bd50f3e5b05794919bfb65e7e533447855014ff42356adbff86d31c8dc")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4264760)
addappid(4894280)
