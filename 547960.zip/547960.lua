-- Lua provided by RyzenAPI
-- Game: 547960

-- MAIN APPLICATION
addappid(547960)
-- Game: addappid(547960)

-- MAIN APP DEPOTS / PACKAGES
addappid(547961, 1, "bfd1821e762f0aea786ed363aee98400a8751c7bedd400696069bf6e6ffd2ef7")
