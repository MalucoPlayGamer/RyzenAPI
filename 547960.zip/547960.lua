-- Lua provided by RyzenAPI 
-- Game: Space Beret
addappid(547960)
addappid(547961, 1, "bfd1821e762f0aea786ed363aee98400a8751c7bedd400696069bf6e6ffd2ef7")
