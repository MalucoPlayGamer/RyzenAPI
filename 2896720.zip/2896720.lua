-- Lua provided by RyzenAPI
-- Game: Everhood 2 Soundtrack

-- MAIN APPLICATION
addappid(2896720)
-- Game: addappid(2896720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2896721, 1, "2ef2f472693a87abf1e8a8f9c854cb232a69465abda49c9c9be082a4c3ed91fc")
