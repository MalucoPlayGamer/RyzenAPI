-- Lua provided by RyzenAPI
-- Game: Pixel Stories of Dungeon

-- MAIN APPLICATION
addappid(590820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(590821,0,"50c0afc3c03186dfbbfed1d24aa56ab67a555e1d36dfe40b04ef229892c6cdc0")

