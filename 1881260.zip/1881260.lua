-- Lua provided by RyzenAPI
-- Game: Greedy Rabbit

-- MAIN APPLICATION
addappid(1881260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881261, 1, "70e24d7ce2c7e0f1b3aff877593a3a05533a4d79be6bd6e76728b7003b44077e")

