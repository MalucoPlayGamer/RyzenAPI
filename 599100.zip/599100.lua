-- Lua provided by RyzenAPI
-- Game: AppID 599100

-- MAIN APPLICATION
addappid(599100)

-- MAIN APP DEPOTS / PACKAGES
addappid(599101, 1, "010183ad5350f9ec95ddacc00995f664d8027108c2381014c6bef2eaca36a6eb")

