-- Lua provided by RyzenAPI
-- Game: Wyv and Keep: The Temple of the Lost Idol

-- MAIN APPLICATION
addappid(263960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(263961, 1, "5f6b2796d68ac8ca1572dd239f2663ede14ad7c411595293a7bf4f17cac1361e")
addappid(263964, 1, "a3eb8bb24a388c9ba8ab9b56f4bbc44b1db1a0869e4b70dcf530ad5adf0174a3")
addappid(263965, 1, "78ea1d07127ff89e37d87c778348cbeda5eaef981c75fd1804224008887aa59a")
addappid(263966, 1, "ddfad8e38a92bf49509c76145660c201866553b13f75c8ec9e83d946c3e7224b")
addappid(263967, 1, "9415116f7a3ae259d74dd9873d1e76038fd1dda9e22f41660a819b4e3c855563")
addappid(263968, 1, "19025c98803d376aceefbde2dc5c982952cd14752bfba2ee7328fa6f56cdd1c2")
addappid(263969, 1, "a8923bda23265bc7daf1cfab930f9e9682cf7d54a7f2215edc2fe70c1d1e26d3")
addappid(263970, 1, "73ce565391639049fbe3f7e6781533f4336112cd6e1eefcdbcaba0986c2094f1")
addappid(263971, 1, "d4e27cc2110bd63c9440016ff18af34641c7ca4211bae33281dd813d0924fbca")

