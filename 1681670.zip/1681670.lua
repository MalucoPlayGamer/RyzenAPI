-- Lua provided by RyzenAPI
-- Game: 人妻痴汉电车

-- MAIN APPLICATION
addappid(1681670)
-- Game: addappid(1681670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681671, 1, "45295448c1f166a334947946f77e10d16a2e941f4518336c5b36afd123a8eec7")
