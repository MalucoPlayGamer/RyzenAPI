-- Lua provided by RyzenAPI
-- Game: 2068920

-- MAIN APPLICATION
addappid(2068920)
-- Game: addappid(2068920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068921, 1, "1377810fab1841b950a8e282cfe9f72427a9305fc67037baf170bd79289bdaab")
