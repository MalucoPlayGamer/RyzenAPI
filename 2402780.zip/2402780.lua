-- Lua provided by RyzenAPI
-- Game: Lil' Guardsman Demo

-- MAIN APPLICATION
addappid(2402780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402781, 1, "0243ab025f81535deb2fef66335c364071ad30145fce050f2140726bcedafe8e")

