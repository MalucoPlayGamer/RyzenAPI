-- Lua provided by RyzenAPI
-- Game: 426210

-- MAIN APPLICATION
addappid(426210)
addappid(426211)
addappid(426213)

-- MAIN APP DEPOTS / PACKAGES
addappid(426212,0,"fde686026b4fd1c0b754328228a010f496adc94cd60f8f7484753594cc6c304a")
