-- Lua provided by RyzenAPI
-- Game: Their Majesties' Pleasure

-- MAIN APPLICATION
addappid(2396340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396341, 1, "ae341ebfaa7692bdaa749ec65ed152ceef96fa2b2cd69a4b3d1c2a8a84d68fdb")

