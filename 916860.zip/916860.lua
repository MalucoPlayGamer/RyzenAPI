-- Lua provided by RyzenAPI
-- Game: addappid(916860)

-- MAIN APPLICATION
addappid(916860)

-- MAIN APP DEPOTS / PACKAGES
addappid(916861, 1, "5c8a2f9d48dfc681caca080cc5932a64af8b129d9559b037bc1fd54792b16d54")
