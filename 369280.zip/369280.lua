-- Lua provided by RyzenAPI
-- Game: 369280

-- MAIN APPLICATION
addappid(369280)
-- Game: addappid(369280)

-- MAIN APP DEPOTS / PACKAGES
addappid(369281, 1, "5e4827aeb47df0c48ff6a77ad44696d1f0a9feff253072c7c93fe19562c4db91")
