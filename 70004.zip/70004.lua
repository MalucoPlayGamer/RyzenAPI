-- Lua provided by RyzenAPI
-- Game: Dino D-Day SDK

-- MAIN APPLICATION
addappid(70001)
addappid(70002)
addappid(70004)

-- MAIN APP DEPOTS / PACKAGES
addappid(70003,0,"3a93d1c614f89d4bdf5399ddaada34475d54372cab3efdd4dea722a634b501ca")

