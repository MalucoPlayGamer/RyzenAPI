-- Lua provided by RyzenAPI
-- Game: Game: AppID 1963520

-- MAIN APPLICATION
addappid(1963520)
-- Game: addappid(1963520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963521, 1, "9715e37af2e7eacb456eebef6924ee23e34a48a1456559e68f8d101bff3c68b9")
