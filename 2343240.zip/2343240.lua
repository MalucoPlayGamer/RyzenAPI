-- Lua provided by RyzenAPI
-- Game: Wretched Depths

-- MAIN APPLICATION
addappid(2343240)

