-- Lua provided by RyzenAPI
-- Game: addappid(1276530)

-- MAIN APPLICATION
addappid(1276530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276532,0,"d25b0fc74b57cbd688f54641c64e4b1a560f6359b51ae3cf315bdc89f4bafad8")
