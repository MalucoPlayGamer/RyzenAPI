-- Lua provided by RyzenAPI
-- Game: Arrow

-- MAIN APPLICATION
addappid(1190180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1190181, 1, "8704d4bfd7d3ff24125b30d0251b3b2b40016dccc6c9335bf34ab52eb81efaa4")

