-- Lua provided by RyzenAPI
-- Game: Arrow

-- MAIN APPLICATION
addappid(1190180)
-- Game: addappid(1190180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190181, 1, "8704d4bfd7d3ff24125b30d0251b3b2b40016dccc6c9335bf34ab52eb81efaa4")
