-- Lua provided by RyzenAPI
-- Game: RoboSquad Revolution (Beta)

-- MAIN APPLICATION
addappid(2363620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2363621, 1, "690151d5fc73230ddb74b7ff0ad694f9bcb2c34b978d5ef8aaa2c262272af38c")
