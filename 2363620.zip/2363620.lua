-- Lua provided by RyzenAPI
-- Game: RoboSquad Revolution (Beta)

-- MAIN APPLICATION
addappid(2363620)
addappid(2851230)
addappid(2933970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2363621, 1, "690151d5fc73230ddb74b7ff0ad694f9bcb2c34b978d5ef8aaa2c262272af38c")

