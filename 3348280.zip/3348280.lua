-- Lua provided by RyzenAPI
-- Game: A Few Days With : Bianca

-- MAIN APPLICATION
addappid(3348280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3348281, 1, "6b148f77f81e69160b706a56bbe3247fa65c715e7651f0d591cafa1d028cc832")
