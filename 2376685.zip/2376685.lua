-- Lua provided by RyzenAPI
-- Game: SONIC SUPERSTARS - Sonic Holiday Costume

-- MAIN APPLICATION
addappid(2376685)
-- Game: addappid(2376685)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376685,0,"505e7d01852a3491ba27f47a39654981b5d226637188c38cc6ab624441e74e09")
