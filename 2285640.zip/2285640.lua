-- Lua provided by RyzenAPI
-- Game: addappid(2285640)

-- MAIN APPLICATION
addappid(2285640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285641, 1, "ba80759ac250554fe881721f821ef8fad32832f9e6bbf4993cf258a57a63462d")
