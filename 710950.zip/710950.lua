-- Lua provided by RyzenAPI
-- Game: addappid(710950)

-- MAIN APPLICATION
addappid(710950)

-- MAIN APP DEPOTS / PACKAGES
addappid(710951, 1, "1ed2751f790d4f4dbff84c2331f4dd06287d77d40a5135ec498cbf785722108d")
