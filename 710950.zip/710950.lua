-- Lua provided by SkyAPI 
-- Game: Pinewood Island
addappid(710950)
addappid(710951, 1, "1ed2751f790d4f4dbff84c2331f4dd06287d77d40a5135ec498cbf785722108d")
