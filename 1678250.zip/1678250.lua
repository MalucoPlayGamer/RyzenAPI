-- Lua provided by RyzenAPI
-- Game: OLD Future: Post-Apocalyptic Times

-- MAIN APPLICATION
addappid(1678250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1678251, 1, "43f110bd72ee5015dfb3dddddf73b72eb248d2872366a3f5895696264e6c9fa1")
