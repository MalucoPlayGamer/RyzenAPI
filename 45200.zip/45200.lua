-- Lua provided by RyzenAPI 
-- Game: AppID 45200
addappid(45200)
addappid(45201, 1, "f930bcbb94caef89667879267f492c1dae5b9bc67814bce88a5012767fe737ad")
