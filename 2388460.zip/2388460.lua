-- Lua provided by RyzenAPI
-- Game: Pathfinder: Gallowspire Survivors

-- MAIN APPLICATION
addappid(2388460)
-- Game: addappid(2388460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388461, 1, "df5b531131bdde59e44e07763828b889d3808d09fd0e2b0daf678841ccde5f88")
