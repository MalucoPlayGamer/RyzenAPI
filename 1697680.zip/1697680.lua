-- Lua provided by RyzenAPI
-- Game: addappid(1697680)

-- MAIN APPLICATION
addappid(1697680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697681, 1, "ee5eaa00757bab0b1062d7b60463f2168ee925ba369685e726b938fce34a73b7")
