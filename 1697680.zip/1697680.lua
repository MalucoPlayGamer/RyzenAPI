-- Lua provided by RyzenAPI
-- Game: Fear Corporation

-- MAIN APPLICATION
addappid(1697680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1697681, 1, "ee5eaa00757bab0b1062d7b60463f2168ee925ba369685e726b938fce34a73b7")

