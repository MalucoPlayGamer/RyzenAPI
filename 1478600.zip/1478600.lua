-- Lua provided by RyzenAPI
-- Game: 1478600

-- MAIN APPLICATION
addappid(1478600)
-- Game: addappid(1478600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478601, 1, "18f0677fb40dd23989229571eaaba334b38f51494fdd1c19a4a40b9154dffcc5")
addappid(1478602, 1, "698b24ff03ab9c6fc6f6fba9538df74b27de5e5ad6598412842db500cf9d9820")
