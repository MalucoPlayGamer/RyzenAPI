-- Lua provided by RyzenAPI
-- Game: NALOGI

-- MAIN APPLICATION
addappid(810670)
addappid(971910)

-- MAIN APP DEPOTS / PACKAGES
addappid(810671,0,"c98a79d792c8d29fe03b962c67aefb4441772e2fb4d747f83dc93a5a44093c03")
addappid(971910,0,"3edffdeb3e183cfd06993a2a20169526fada077ead0b33ca90c267d48b58e16a")

