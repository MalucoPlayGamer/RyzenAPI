-- Lua provided by RyzenAPI
-- Game: addappid(810670)

-- MAIN APPLICATION
addappid(810670)

-- MAIN APP DEPOTS / PACKAGES
addappid(810671, 1, "c98a79d792c8d29fe03b962c67aefb4441772e2fb4d747f83dc93a5a44093c03")
