-- Lua provided by RyzenAPI 
-- Game: Edge of Space
addappid(238240)
addappid(238241, 1, "d5de59e8589984d83c87722a1b6977defe54b79b1cc51ce3db5f8178486cf3c5")
addappid(238242, 1, "0315c1d0a1bb6f77bf4bfa5108aae23d3a2f734b05d938351e8dfa4783f269fe")
