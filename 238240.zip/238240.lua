-- Lua provided by RyzenAPI
-- Game: Edge of Space

-- MAIN APPLICATION
addappid(238240)

-- MAIN APP DEPOTS / PACKAGES
addappid(238241, 1, "d5de59e8589984d83c87722a1b6977defe54b79b1cc51ce3db5f8178486cf3c5")
addappid(238242, 1, "0315c1d0a1bb6f77bf4bfa5108aae23d3a2f734b05d938351e8dfa4783f269fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(238250)
addappid(238251)
addappid(403630)
