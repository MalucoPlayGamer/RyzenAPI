-- Lua provided by RyzenAPI
-- Game: setManifestid(780582,"7335762470158908248")

-- MAIN APPLICATION
addappid(780580)
-- Game: addappid(780580)

-- MAIN APP DEPOTS / PACKAGES
addappid(780582,0,"60a2e33aed6dd38be6936ed0d70d987f4d367b0d8c373483559e7a9dd4119718")
