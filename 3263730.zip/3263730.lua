-- Lua provided by RyzenAPI
-- Game: Game: This Company Of Mine

-- MAIN APPLICATION
addappid(3263730)
-- Game: addappid(3263730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263731, 1, "bda1a4bf093d073ac35fb84166b895a29dbb9c8dd6e3b906aa06ab1c6f73f871")
