-- Lua provided by RyzenAPI
-- Game: addappid(1652862)

-- MAIN APPLICATION
addappid(1652862)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652862,0,"7fe335f864b62deea288a898c4dc12aac57c63bf9eb0b69e296bfad04998c21f")
