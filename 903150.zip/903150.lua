-- Lua provided by RyzenAPI
-- Game: FALL 坠落之后

-- MAIN APPLICATION
addappid(903150)
-- Game: addappid(903150)

-- MAIN APP DEPOTS / PACKAGES
addappid(903151, 1, "a160744d752db6ea058c19be4676ceb5c56ad718a1885bf7d5b8d827136d4154")
