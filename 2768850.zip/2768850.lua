-- Lua provided by RyzenAPI 
-- Game: AppID 2768850
addappid(2768850)
addappid(2768851, 1, "a516195d77ad4f9aeb11e0155303b0b11c61c4b6cc798017c525c59ee2d82d22")
