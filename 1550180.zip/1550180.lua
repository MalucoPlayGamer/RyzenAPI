-- Lua provided by RyzenAPI
-- Game: Game: 9th Dawn Remake

-- MAIN APPLICATION
addappid(1550180)
-- Game: addappid(1550180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550181, 1, "b1d6c894e0255957d57dae026f6c4892762708c8a52e38bdb49c0892285f349d")
addappid(3151950, 0, "54aa30b5a32fd01e9bde8487350e03933a9e32eea561da5c879b33ce42616aac")
