-- Lua provided by RyzenAPI
-- Game: My Demon Family

-- MAIN APPLICATION
addappid(2901060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901061, 1, "96f8f8931e76b033b411d453875f9e3ae9e505f2ef5f6d77e8125d7894d25457")

