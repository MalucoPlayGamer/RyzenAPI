-- Lua provided by RyzenAPI
-- Game: Game: AppID 656790

-- MAIN APPLICATION
addappid(656790)
-- Game: addappid(656790)

-- MAIN APP DEPOTS / PACKAGES
addappid(656791, 1, "93f68e7200ad5076bfd2c898fcac860c23f6409ee96cf728f68192c2ec87b04e")
