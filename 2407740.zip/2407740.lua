-- Lua provided by RyzenAPI
-- Game: Vampire: The Masquerade - Swansong BOSTON BY NIGHT

-- MAIN APPLICATION
addappid(2407740)
-- Game: addappid(2407740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407740,0,"3ad7f9a316a140f2f61c7102d8bd07a83290f1ee4ccb85708e51563e96f451c7")
