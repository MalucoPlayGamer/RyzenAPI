-- Lua provided by RyzenAPI
-- Game: Demolish & Build 2017

-- MAIN APPLICATION
addappid(470740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(470741, 1, "02f1e953202424ff3ff01e815c29ecb7d3c1ffb508bf7fc66094a6ddbc0648cd")
addappid(470742, 1, "53741e1421aa2df8d85cc519b92d6733cfbc8406d5730ff2fb9994d898212568")

