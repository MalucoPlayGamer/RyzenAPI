-- Lua provided by RyzenAPI
-- Game: Game: Chill the Piro

-- MAIN APPLICATION
addappid(437180)
-- Game: addappid(437180)

-- MAIN APP DEPOTS / PACKAGES
addappid(437181, 1, "faee1c5dd28b1aca6d2de69c3f249b1afa8938c744905cb1d64a7855675e7cc9")
addappid(437182, 1, "dcc547e5245ec907bc6b570a23ea5378203444cefcc82e2d4487e2bdf3e2d3e9")
addappid(437183, 1, "33ab8552118f8e919b3b0692564ab33736f9680623da003b5ed0a5d8d3bf5a53")
