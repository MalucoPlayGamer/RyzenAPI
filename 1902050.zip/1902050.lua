-- Lua provided by RyzenAPI
-- Game: the DEEP LOST

-- MAIN APPLICATION
addappid(1902050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1902051, 1, "4ead7f3bd86dd1bfba99df95b0525d0e2846329ca5c15224acdad6b3845db3c2")

