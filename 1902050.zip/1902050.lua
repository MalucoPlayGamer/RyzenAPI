-- Lua provided by RyzenAPI
-- Game: the DEEP LOST

-- MAIN APPLICATION
addappid(1902050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902051, 1, "4ead7f3bd86dd1bfba99df95b0525d0e2846329ca5c15224acdad6b3845db3c2")

