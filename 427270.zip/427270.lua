-- Lua provided by RyzenAPI
-- Game: Orcs Must Die! Unchained

-- MAIN APPLICATION
addappid(427270)
addappid(435890)
addappid(446740)
addappid(453630)
addappid(455610)
addappid(455611)
addappid(455612)
addappid(617040)
addappid(625030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(427271, 1, "198c24c4e922440b8254e23afa95223ddb0d7d9fa8df1dcdfc5a901c483280cb")

