-- Lua provided by RyzenAPI
-- Game: addappid(1358490)

-- MAIN APPLICATION
addappid(1358490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358491, 1, "de2cabde0fe6170e69964f24e78c316237a7c820236ee558c69eb700a5c1268d")
