-- Lua provided by RyzenAPI
-- Game: Stranded Alone

-- MAIN APPLICATION
addappid(780260)
-- Game: addappid(780260)

-- MAIN APP DEPOTS / PACKAGES
addappid(780261, 1, "e710547fdd1027fa2731b5af77b8af00dbce7a76c7f4b7fecee02011e8d9dba5")
