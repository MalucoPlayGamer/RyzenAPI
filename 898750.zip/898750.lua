-- Lua provided by SkyAPI 
-- Game: Super Robot Wars 30
addappid(898750)
addappid(898751, 1, "f553ceb7b38d428cab2a8122991fcc8906b1628f86a32f4a3639da017591703a")
