-- Lua provided by RyzenAPI
-- Game: 898750

-- MAIN APPLICATION
addappid(898750)
-- Game: addappid(898750)

-- MAIN APP DEPOTS / PACKAGES
addappid(898751, 1, "f553ceb7b38d428cab2a8122991fcc8906b1628f86a32f4a3639da017591703a")
