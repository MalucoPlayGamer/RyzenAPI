-- Lua provided by RyzenAPI
-- Game: Hybrids Arena

-- MAIN APPLICATION
addappid(448240)

-- MAIN APP DEPOTS / PACKAGES
addappid(448241, 1, "2093c0e447619cb135965636bed7acb1eb04134fe2d637ddce38ac5f06b1e298")

