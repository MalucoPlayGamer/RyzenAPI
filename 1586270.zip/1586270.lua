-- Lua provided by RyzenAPI
-- Game: Katja's Abyss: Tactics

-- MAIN APPLICATION
addappid(1586270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586271,0,"4fc6c3aaa1920f6d8eb4c455be4869aee14519651b575202d8fb788a110d0775")

