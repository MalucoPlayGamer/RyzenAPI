-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1111352)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111352,0,"ca61dd2500fdb66ad979d22d775aff718afea57f41be9b7a939279ed251fa4b2")

