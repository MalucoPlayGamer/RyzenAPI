-- Lua provided by RyzenAPI
-- Game: Experience: Colorblindness

-- MAIN APPLICATION
addappid(979100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(979101, 1, "7852fc0fbde03e4a5fe0a658f5770583ea5f1c63c9f29dedb66dc6eafe864808")

