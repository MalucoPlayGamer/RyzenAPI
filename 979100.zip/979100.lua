-- Lua provided by RyzenAPI
-- Game: addappid(979100)

-- MAIN APPLICATION
addappid(979100)

-- MAIN APP DEPOTS / PACKAGES
addappid(979101, 1, "7852fc0fbde03e4a5fe0a658f5770583ea5f1c63c9f29dedb66dc6eafe864808")
