-- Lua provided by RyzenAPI
-- Game: A Light in the Dark Demo

-- MAIN APPLICATION
addappid(766880)

-- MAIN APP DEPOTS / PACKAGES
addappid(766881, 1, "9512e7cd709d8181c00337bb33a7a2e3f01d5542a36408c480a5f860809f0a56")

