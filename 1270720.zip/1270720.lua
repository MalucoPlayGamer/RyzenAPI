-- Lua provided by RyzenAPI
-- Game: Spirit

-- MAIN APPLICATION
addappid(1270720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270721,0,"85a8aed4d50ae6149010ded93fa6a5b759edca2e087dbd740ac115ee2778bc92")

