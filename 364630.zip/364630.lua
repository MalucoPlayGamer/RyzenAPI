-- Lua provided by RyzenAPI
-- Game: Game: AirMech Command

-- MAIN APPLICATION
addappid(364630)
-- Game: addappid(364630)

-- MAIN APP DEPOTS / PACKAGES
addappid(364631, 1, "86c2ef3082bb30a3a3db85673aac8f5c8c41f28a06ef0125a3c73461d791449d")
