-- Lua provided by RyzenAPI
-- Game: addappid(1317950)

-- MAIN APPLICATION
addappid(1317950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317951, 1, "e484acc548e6fb2e6985d8706b0c7ac7604b05c28acbe470669c33f62bc22044")
