-- Lua provided by RyzenAPI
-- Game: Eternal Dreamers

-- MAIN APPLICATION
addappid(1317950)
addappid(1513870)
addappid(1513880)
addappid(1513890)
addappid(1513900)
addappid(1651900)
addappid(1727240)
addappid(1772190)
addappid(1794410)
addappid(1816540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317951, 1, "e484acc548e6fb2e6985d8706b0c7ac7604b05c28acbe470669c33f62bc22044")

