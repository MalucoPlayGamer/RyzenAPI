-- Lua provided by SkyAPI 
-- Game: Eternal Dreamers
addappid(1317950)
addappid(1317951, 1, "e484acc548e6fb2e6985d8706b0c7ac7604b05c28acbe470669c33f62bc22044")
