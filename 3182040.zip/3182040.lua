-- Lua provided by RyzenAPI
-- Game: 3182040

-- MAIN APPLICATION
addappid(3182040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182040,0,"8e4f7b0239b2ac799c57ecef9b796a31a0583fc5274e4b5ece12dea56aa823eb")

