-- Lua provided by SkyAPI 
-- Game: Seductive Tombs: Beach Love
addappid(1710880)
addappid(1710881, 1, "0da2d603f1012eff5aebe2277fc1b6303c6355bf811a5d05f38d637004992d7e")
