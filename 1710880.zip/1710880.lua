-- Lua provided by RyzenAPI
-- Game: Seductive Tombs: Beach Love

-- MAIN APPLICATION
addappid(1710880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1710881, 1, "0da2d603f1012eff5aebe2277fc1b6303c6355bf811a5d05f38d637004992d7e")

