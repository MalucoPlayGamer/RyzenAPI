-- Lua provided by RyzenAPI
-- Game: Game: Seductive Tombs: Beach Love

-- MAIN APPLICATION
addappid(1710880)
-- Game: addappid(1710880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710881, 1, "0da2d603f1012eff5aebe2277fc1b6303c6355bf811a5d05f38d637004992d7e")
