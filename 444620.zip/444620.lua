-- Lua provided by SkyAPI 
-- Game: SpellKnights
addappid(444620)
addappid(444621, 1, "d90a1ddc34af9eeed6ee5f39b018c82fa3ffaca41d4db7202f3f567a7f049d39")
addappid(494074)
