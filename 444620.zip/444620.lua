-- Lua provided by RyzenAPI
-- Game: SpellKnights

-- MAIN APPLICATION
addappid(444620)
addappid(494074)
-- Game: addappid(444620)

-- MAIN APP DEPOTS / PACKAGES
addappid(444621, 1, "d90a1ddc34af9eeed6ee5f39b018c82fa3ffaca41d4db7202f3f567a7f049d39")
