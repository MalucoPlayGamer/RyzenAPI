-- Lua provided by RyzenAPI
-- Game: SpellKnights

-- MAIN APPLICATION
addappid(444620)
addappid(494074)

-- MAIN APP DEPOTS / PACKAGES
addappid(444621, 1, "d90a1ddc34af9eeed6ee5f39b018c82fa3ffaca41d4db7202f3f567a7f049d39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
