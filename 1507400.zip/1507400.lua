-- Lua provided by RyzenAPI
-- Game: addappid(1507400)

-- MAIN APPLICATION
addappid(1507400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507401, 1, "352f2f4734434c4c71c42cf89192075f9bb35cf8a7ccca96c16b0a60fb7feed4")
