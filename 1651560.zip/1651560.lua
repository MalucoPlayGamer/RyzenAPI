-- Lua provided by RyzenAPI
-- Game: AppID 1651560

-- MAIN APPLICATION
addappid(1651560)
-- Game: addappid(1651560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651561, 1, "dbaf69374e2fa99d18be9c0ee9b803630ac5fdb318fff5a83637397db2576b99")
