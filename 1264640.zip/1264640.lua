-- Lua provided by RyzenAPI
-- Game: Wallpaper Master

-- MAIN APPLICATION
addappid(1264640)
-- Game: addappid(1264640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264641, 1, "ebd0ff7b79a6e7c66e0d48d7582b3ca037fdf311c4bbe84aed2e50e98ce3d4bf")
