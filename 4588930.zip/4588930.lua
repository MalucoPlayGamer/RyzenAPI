-- Lua provided by RyzenAPI
-- Game: The Old Flesh of Nuraga

-- MAIN APPLICATION
addappid(5100750) -- Wild Nuraga (Supporter Pack)

-- MAIN APP DEPOTS / PACKAGES
addappid(4588930, 1, "3092b7caaf93cf3e4d7fa9e563f02fc1158b51a2fca63402ce07f97379cd5491") -- The Old Flesh of Nuraga
addappid(4588931, 1, "39e5c6f8eca45abc50a45924f1f5b6abb8b1101d6d9108a9b2a94cfcb0412bd7") -- Depot 4588931

