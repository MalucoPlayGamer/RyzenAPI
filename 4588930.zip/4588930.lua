-- 4588930's Lua and Manifest Created by Hubcap Manifest
-- The Old Flesh of Nuraga
-- Created: August 27, 2026 at 13:30:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4588930, 1, "3092b7caaf93cf3e4d7fa9e563f02fc1158b51a2fca63402ce07f97379cd5491") -- The Old Flesh of Nuraga
-- MAIN APP DEPOTS
addappid(4588931, 1, "39e5c6f8eca45abc50a45924f1f5b6abb8b1101d6d9108a9b2a94cfcb0412bd7") -- Depot 4588931
setManifestid(4588931, "2646359892168059456", 669304312)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(5100750) -- Wild Nuraga (Supporter Pack)