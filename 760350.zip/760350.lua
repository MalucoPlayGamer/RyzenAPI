-- Lua provided by RyzenAPI
-- Game: Star Sweet

-- MAIN APPLICATION
addappid(760350)
-- Game: addappid(760350)

-- MAIN APP DEPOTS / PACKAGES
addappid(760351, 1, "f8dc6fb1b2c29364e559727965f9a75cc4efeea7c5fb9d3de21282657b03f3b5")
