-- Lua provided by SkyAPI 
-- Game: Star Sweet
addappid(760350)
addappid(760351, 1, "f8dc6fb1b2c29364e559727965f9a75cc4efeea7c5fb9d3de21282657b03f3b5")
