-- Lua provided by RyzenAPI
-- Game: Game: Operation Desert Road

-- MAIN APPLICATION
addappid(727320)
-- Game: addappid(727320)

-- MAIN APP DEPOTS / PACKAGES
addappid(727321, 1, "f2503e86d508424118d891823a19f652a209d4569bf264e46f843bb7d24cac9a")
