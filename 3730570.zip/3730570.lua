-- Lua provided by RyzenAPI
-- Game: Pixel Empires

-- MAIN APPLICATION
addappid(3730570) -- Pixel Empires

-- MAIN APP DEPOTS / PACKAGES
addappid(3730571, 1, "165590fad5b2a20824dca985dbdc14a81328cafffaa4fe185112185e54c3b5da") -- Depot 3730571

