-- 3730570's Lua and Manifest Created by Hubcap Manifest
-- Pixel Empires
-- Created: June 25, 2026 at 14:41:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3730570) -- Pixel Empires
-- MAIN APP DEPOTS
addappid(3730571, 1, "165590fad5b2a20824dca985dbdc14a81328cafffaa4fe185112185e54c3b5da") -- Depot 3730571
-- setManifestid(3730571, "3870265374226041770", 791540860)