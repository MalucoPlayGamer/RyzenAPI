-- Lua provided by RyzenAPI
-- Game: Mystery Manor: hidden objects

-- MAIN APPLICATION
addappid(3077660)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
