-- Lua provided by RyzenAPI
-- Game: Mystery Manor: hidden objects

-- MAIN APPLICATION
addappid(3077660)

