-- Lua provided by RyzenAPI
-- Game: SweetSin - Season 1

-- MAIN APP DEPOTS / PACKAGES
addappid(4952860, 1, "91535ee4b06bc9f554e96f60af4bc3997f3f773b2fb5559ca46bcaa399809309") -- SweetSin - Season 1
addappid(4952861, 1, "7c69bb6429d773a5b6ed53e645cdf3aa33de6d1379743f6d40cec72e56f38646") -- Depot 4952861

