-- Lua provided by RyzenAPI
-- Game: Space Panic: Room Escape (VR)

-- MAIN APPLICATION
addappid(649460)
-- Game: addappid(649460)

-- MAIN APP DEPOTS / PACKAGES
addappid(649461, 1, "54a3d2aa579df963c96ec8f1407603d58632599de11db5f1ca8fe180a73f72be")
