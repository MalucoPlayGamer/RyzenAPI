-- Lua provided by RyzenAPI
-- Game: The Blackwell Legacy

-- MAIN APPLICATION
addappid(80330)

-- MAIN APP DEPOTS / PACKAGES
addappid(80331, 1, "4d82aad9752fad23ee91d06374c23e26f12cd1c46c0a3cc5276b6660e315ac48")
addappid(80332, 1, "f2f2b9b300a6f986b5d6c82a26ca35a1b78ee3cb4e137d39d7b4b1ba58720ea9")
addappid(80333, 1, "9bd1891cc8ccca9815e3501268204ffaa76ad9897ae13790f25f90a501331b78")
addappid(2023580, 0, "36c537ea1ad36f55968d8cec07325ca42e37bd68af0558c76f34eb592f1940bb")
