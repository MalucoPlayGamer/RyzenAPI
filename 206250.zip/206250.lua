-- Lua provided by RyzenAPI
-- Game: Cladun X2

-- MAIN APPLICATION
addappid(206250)
-- Game: addappid(206250)

-- MAIN APP DEPOTS / PACKAGES
addappid(206251, 1, "5a94531e9729146b8b4963328c3303464f039e1af46925f67cce07e472bcf5bc")
