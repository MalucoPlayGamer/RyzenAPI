-- Lua provided by RyzenAPI
-- Game: Galactic Dominion

-- MAIN APPLICATION
addappid(871710)

-- MAIN APP DEPOTS / PACKAGES
addappid(871711,0,"bd5702a007adf861c18d62062fbb23744dfafd50b6ecf882fad1335fdb78f062")

