-- Lua provided by RyzenAPI 
-- Game: Islands of the Caliph
addappid(1845670)
addappid(1845671, 1, "47fafbca809c6659fe4374d211b300b0cace90be9f8e8769982c31cf7a8a07be")
