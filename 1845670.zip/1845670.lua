-- Lua provided by RyzenAPI
-- Game: Islands of the Caliph

-- MAIN APPLICATION
addappid(1845670)
-- Game: addappid(1845670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845671, 1, "47fafbca809c6659fe4374d211b300b0cace90be9f8e8769982c31cf7a8a07be")
