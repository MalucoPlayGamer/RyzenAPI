-- Lua provided by RyzenAPI
-- Game: Game: REYNATIS

-- MAIN APPLICATION
addappid(2738750)
-- Game: addappid(2738750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738751, 1, "3f6c8d14a4dc195981168e7a8567ddd765004cb9816417b8c29642c1aa9f0f20")
