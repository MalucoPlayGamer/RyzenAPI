-- Lua provided by RyzenAPI
-- Game: REYNATIS

-- MAIN APPLICATION
addappid(2738750)
addappid(3129450)
addappid(3129460)
addappid(3129470)
addappid(3129480)
addappid(3129490)
addappid(3129500)
addappid(3129510)
addappid(3129520)
addappid(3129530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738751,0,"3f6c8d14a4dc195981168e7a8567ddd765004cb9816417b8c29642c1aa9f0f20")
addappid(3129520,0,"8d55bf573b4a9d8a7ae7eeac014aa5282fa63edb7663939a2e3947b0a7617547")
addappid(3129530,0,"a247adcad5817ec3f49d84bfefa505bcc2d6a3750e6bce2670f939e752c811bc")

