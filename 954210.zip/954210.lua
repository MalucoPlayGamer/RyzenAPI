-- Lua provided by RyzenAPI
-- Game: Game: Symphonic Mayhem

-- MAIN APPLICATION
addappid(954210)
-- Game: addappid(954210)

-- MAIN APP DEPOTS / PACKAGES
addappid(954211, 1, "7d4069f542155b377d06630187e387a3db14a2ffda22d7e44f94ed319ec8475d")
