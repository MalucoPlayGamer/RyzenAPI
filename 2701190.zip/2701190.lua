-- Lua provided by RyzenAPI
-- Game: Game: Megalotrain

-- MAIN APPLICATION
addappid(2701190)
-- Game: addappid(2701190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701191, 1, "aac192bf8eabd9a85153aaba6383bd1786582d69ec86ea68c4f0c2a87dd9e96f")
