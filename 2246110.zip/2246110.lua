-- Lua provided by RyzenAPI
-- Game: Game: Q REMASTERED

-- MAIN APPLICATION
addappid(2246110)
-- Game: addappid(2246110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246111, 1, "5936d7242a8167b8aa3153615cee37f0f00e44f3a9e6f17247cd62bf4e4c2407")
