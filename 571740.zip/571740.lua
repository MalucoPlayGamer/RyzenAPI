-- Lua provided by RyzenAPI
-- Game: Golf It!

-- MAIN APPLICATION
addappid(571740)

-- MAIN APP DEPOTS / PACKAGES
addappid(571741, 1, "d4d913d1500f6fb2f6555dc308aa9d6dc8174a7fc345fec224d964c6ed298e8b")
addappid(571742, 1, "c035eba8156fad45f156d0941e520d8ba14372c9fd7ecac112734079a9cc6f01")
