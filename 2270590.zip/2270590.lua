-- Lua provided by RyzenAPI
-- Game: 《蜀山：初章》网络版

-- MAIN APPLICATION
addappid(2270590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270591, 1, "9146180ff9680c0772527afd9ea5fe97218f13eae7fe24b48818063cca96950b")

