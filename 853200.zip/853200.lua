-- Lua provided by RyzenAPI
-- Game: Shred! 2 - ft Sam Pilgrim

-- MAIN APPLICATION
addappid(853200)
-- Game: addappid(853200)

-- MAIN APP DEPOTS / PACKAGES
addappid(853201, 1, "917d79910b0cef5ff098e8548cab5167ca31d2e345d4dfd5742a8f053f0db1bd")
