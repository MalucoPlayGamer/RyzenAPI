-- Lua provided by RyzenAPI
-- Game: addappid(3163060)

-- MAIN APPLICATION
addappid(3163060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163061, 1, "f55e5b1245f45230a881e698cdd83780cc2f0bb0ab7bf1fcd288a1b3feafa11e")
