-- Lua provided by RyzenAPI
-- Game: Spectromancer

-- MAIN APPLICATION
addappid(22500)
addappid(22510)
addappid(22520)

-- MAIN APP DEPOTS / PACKAGES
addappid(22501, 1, "01f37b80b805c724aa23ae4aed5da740870cd5ac7343ba89522639ce057db1ae")
addappid(22502, 1, "67d798244ce1e00d8f6ea0290842f4f16e94f0e715c23f9468d17462265c1f6f")
addappid(22504, 1, "2ff099460d6813d085e0269cfb70219c11c9d0c506e75eaf767a3e155e57db08")
addappid(22521, 0, "eebdbd9c86375bd79e062f0ed87021f5fcea14e87ec9722e29ac022311b501af")
