-- Lua provided by RyzenAPI
-- Game: 1239800

-- MAIN APPLICATION
addappid(1239800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239802,0,"9e46daf31f52b75d211b3583ac9163c11c8c7dbaab27a6e425bbebc0e36a83cc")

