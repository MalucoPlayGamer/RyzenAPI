-- Lua provided by RyzenAPI
-- Game: Resident evil 7

-- MAIN APPLICATION
addappid(529930)
addappid(530590)
addappid(530591)
addappid(530592)
addappid(530593)
addappid(530594)
addappid(530595)
addappid(530596)
addappid(530597)
addappid(530598)
addappid(530599)
addappid(530610)
addappid(530611)
addappid(540340) -- Resident Evil 7 - Season Pass
addappid(564190)
addappid(584960) -- RESIDENT EVIL 7 biohazard - Original Soundtrack (FLAC)
-- addappid(543550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(418370, 1, "9218e61652ae85ea8525d97fd62535f61209b1dd13e3551a5114592281f01313") -- Resident Evil 7 Biohazard
addappid(418371, 1, "2df4ede71de8b8163daa12dbd679f25b89c131c806485d93fba323e47a2d8eb3") -- RESIDENT EVIL 7 biohazard
addappid(418372, 1, "5ffba65b1aa063765d2dec7582c23b09661a6b361fa9657a2508ab2f5fb15be5") -- BIOHAZARD 7 resident evil
addappid(418373, 1, "50c8b866482e9bd8c01be358b98eb68b599e62a0acd6e6e5ddb248a85440fddc") -- Banned Footage Vol.1 - DLC1(JP)
addappid(418374, 1, "8b767d7724397841d78757c440f109fd2eda309263dfab9fe8d2b44042c93428") -- Banned Footage Vol.2 - DLC2(JP)
addappid(418375, 1, "75ef17978e6091765555cc1c2fe83e7886cfe49121baa935e8e0b80b6fe98e3e") -- Banned Footage Vol.2 - DLC2(K)
addappid(418376, 1, "ad6230311dea128611a7f6616e116755175138b3a505a4e371a8a7e8f45ad437") -- Not A Hero - CP8(JP)
addappid(418377, 1, "2376c48c0daa86e1edabafd112cf1be3c96aad06d1b7df745ec4b8580f4c0775") -- Not A Hero - CP8(K)
addappid(418378, 1, "e781d67979d2e4c82368105a246b50a2a60d58975dbb028d391e843f1529ab02") -- End Of Zoe - DLC3(JP)
addappid(529930, 1, "f05d0430d570b49933e26bdf148b52ff2b68676636afc882087ed81b826de455") -- Banned Footage Vol.1 - DLC 1（WWD） (529930) 個のデポ
addappid(530590, 1, "06f0d9d9de44f84a3f255e0a3f500152f680761eb95e3cc2187947df324c0f80") -- Survival Pack A - Survival Pack A (530590) 個のデポ
addappid(530591, 1, "07761afe199d8438ba8b139f36a92a934b8bf18de5c222eede9a0877a1d2f8bc") -- Survival Pack B - Survival Pack B (530591) 個のデポ
addappid(530592, 1, "b877d348297442a4a20326c8eb10445ac7061410396c429e453ef38a1666fb68") -- Survival Pack C - Survival Pack C (530592) 個のデポ
addappid(530593, 1, "6bb179b124231858379b4cb30cf3c12e446e00b432632152e3f17a0352912f2b") -- Survival Pack D - Survival Pack D (530593) 個のデポ
addappid(530594, 1, "f40098295d34d0d2f2522b04dbd43268de116800d0a6b43d5b8a26e9db50c5d5") -- Survival Pack E - Survival Pack E (530594) 個のデポ
addappid(530595, 1, "f532e1f9272faaca708b0d54b4aa86b9b5bfccfb61c1376c6e984e2be6cdee4f") -- A Coin  Hard Mode - A Coin & Hard Mode (530595) 個のデポ
addappid(530596, 1, "05b334a227cbe67d789998bbdd2ab7726b891a1d7deff5349cb4938bc6304487") -- B Coin  Hard Mode - B Coin & Hard Mode (530596) 個のデポ
addappid(530597, 1, "5f791b96cace35bd231db330435ad45b3f3a608805f020a0add4f5c116193f4b") -- C Coin  Hard Mode - C Coin & Hard Mode (530597) 個のデポ
addappid(530598, 1, "01cd6f3745501d469f6193aa99becb7244a4b293031b09365d07e4f419c606d3") -- D Coin  Hard Mode - D Coin & Hard Mode (530598) 個のデポ
addappid(530599, 1, "acc89294725ca72de44fa2e7d060e1479794516963c1aa999c03df609dbd372f") -- E Coin  Hard Mode - E Coin & Hard Mode (530599) 個のデポ
addappid(530610, 1, "cc5848d208a6436651fa7875afd740c71bf799b0cc61e1677f7156ba27178e41") -- Banned Footage Vol.2 - DLC 2（WWD） (530610) 個のデポ
addappid(530611, 1, "32a01ec16f26a30cfbb8a309e864b0f6e22a2af0324100f0561857dcd8964e5d") -- End Of Zoe - DLC 3（WWD） (530611) 個のデポ
addappid(564190, 1, "3e28043753fe610017111a39a7a80aac705b7cfcddb1c420d50f388e6ea0b0b1") -- Not A Hero - CP8（WWD） (564190) 個のデポ
addtoken(530591, "14219514274219578439")
addtoken(530592, "137849144737045535")
addtoken(530593, "9657228074130537484")
addtoken(530594, "3083774502530847806")

