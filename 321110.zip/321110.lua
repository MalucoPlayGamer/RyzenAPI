-- Lua provided by RyzenAPI
-- Game: Fist of Jesus: the Bloody Gospel of Judas

-- MAIN APPLICATION
addappid(321110)

-- MAIN APP DEPOTS / PACKAGES
addappid(321111, 1, "46313c3f0c5e7e682cf82eb4fb2429a8a5ea53ea0d3a09d5875be946883a266d")
addappid(321112, 1, "303996bf93dd323a62b013fb6a6b91ce6444d223439fb1887585ae30d5c82031")
addappid(321113, 1, "5c599b1c537cfdc9d81c538a605e624c95059c2e4fa815a31252dd60baff14d0")
addappid(321114, 1, "1fc448b472c49b3fb9fdf1577577a5e5cbc95af3917aa8443657b0b0ab1c9881")
addappid(321115, 1, "4054a0dda89f68c3d00f11434974dd944e1f6503f1359cbd1eef4a6f2ccfd434")
addappid(321116, 1, "6cccddd37bcbad33cc10d151b76c48a930e03460234dfb71b08c63d2073533dd")
