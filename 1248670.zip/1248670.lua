-- Lua provided by RyzenAPI
-- Game: Game: Stanga

-- MAIN APPLICATION
addappid(1248670)
-- Game: addappid(1248670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248671, 1, "3c32759282541169fec19b3bba62c96d097ac9e30f807ba3370a71c362b0c087")
