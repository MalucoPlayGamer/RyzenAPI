-- Lua provided by RyzenAPI
-- Game: addappid(1301390)

-- MAIN APPLICATION
addappid(1301390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301391, 1, "f63307f73626558d67bc4e04d46b540a3c80d303dd086260350ea4af9570f1e5")
addappid(1301392, 1, "20bf40186abc538caa07df64a1a2161fe5d4d78c6dba27ad1d31ba638de9e0cf")
