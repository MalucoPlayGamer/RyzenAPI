-- Lua provided by RyzenAPI
-- Game: No Umbrellas Allowed

-- MAIN APPLICATION
addappid(1301390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1301391, 1, "f63307f73626558d67bc4e04d46b540a3c80d303dd086260350ea4af9570f1e5")
addappid(1301392, 1, "20bf40186abc538caa07df64a1a2161fe5d4d78c6dba27ad1d31ba638de9e0cf")

