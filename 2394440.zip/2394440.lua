-- Lua provided by RyzenAPI
-- Game: The Great Below

-- MAIN APPLICATION
addappid(2394440)
-- Game: addappid(2394440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394441, 1, "fa8c51b4a578e0da5f7916e0201fe727a31ab663955233c07ce142f781f92ffd")
