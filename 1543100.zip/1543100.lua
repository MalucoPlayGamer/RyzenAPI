-- Lua provided by RyzenAPI
-- Game: Farmer's Co-op:Out of This World

-- MAIN APPLICATION
addappid(1543100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543101, 1, "8698d8a4f8e2ef707ca0e452cc781b1a3cf5e7762071f5902b776523a23b1d06")
