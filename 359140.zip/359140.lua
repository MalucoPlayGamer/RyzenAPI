-- Lua provided by RyzenAPI
-- Game: addappid(359140)

-- MAIN APPLICATION
addappid(359140)

-- MAIN APP DEPOTS / PACKAGES
addappid(359141, 1, "4640e7edc6b3a61aea36aa4f7b1f2cd68a5da6054c4f3ee247449c29f5a91018")
addappid(359142, 1, "6400ddd25c38dcde4203a1febea4d9990f7dbd8937180b2bebafc93e46dc1803")
addappid(359143, 1, "2955e6b60fea8dc48c6a39b79120f568777333ed743fe3ce66b1c45d7c8f058f")
