-- Lua provided by RyzenAPI
-- Game: Blaster Master Zero 2

-- MAIN APPLICATION
addappid(1034910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034911, 1, "8161350751cb5d0036c9aaf6edf8eab5b74bc34e72678457f15df96663100364")
addappid(1185440, 0, "cef3f469dd165aa68136530a1b15a683093a12eb5385271046014a478b871bb3")
addappid(1242680, 0, "d8841a047917c65634b717daf3237fa74405c9151864a95a79605603b244bcde")
addappid(1254350, 0, "8d2739be5d6a55e8a58d9d59dd9f816f47e2f59d5a4890197591b93e2df65df9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
