-- Lua provided by RyzenAPI 
-- Game: Shrumblo and the Magical Grumblo
addappid(1847920)
addappid(1847921, 1, "094705da26eb9983864d78725abf0acc5422f94f4d6423a9bbd83bf956cc3a84")
