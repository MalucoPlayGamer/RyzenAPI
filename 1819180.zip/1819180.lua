-- Lua provided by RyzenAPI
-- Game: Game: Oxide Room 104

-- MAIN APPLICATION
addappid(1819180)
-- Game: addappid(1819180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819181, 1, "dce5c642fcde8cd5cc49f778ecfb3de40c212dc011d2e3244cad46739801c2c2")
