-- Lua provided by RyzenAPI
-- Game: 3286360

-- MAIN APPLICATION
addappid(3286360)
-- Game: addappid(3286360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3286361, 1, "f1bd9a9deac0829840c54b9f692a2d23576e1cfd57256403c9c110c75e2c88d1")
