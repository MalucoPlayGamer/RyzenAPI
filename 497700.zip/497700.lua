-- Lua provided by RyzenAPI
-- Game: Safety First!

-- MAIN APPLICATION
addappid(497700)

-- MAIN APP DEPOTS / PACKAGES
addappid(497701, 1, "05ad685b939eccc264672809fb8d1711488cac1707982c8157345d1a47a90d71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
