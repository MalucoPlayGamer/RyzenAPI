-- Lua provided by RyzenAPI
-- Game: Safety First!

-- MAIN APPLICATION
addappid(497700)

-- MAIN APP DEPOTS / PACKAGES
addappid(497701, 1, "05ad685b939eccc264672809fb8d1711488cac1707982c8157345d1a47a90d71")
