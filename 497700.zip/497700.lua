-- Lua provided by SkyAPI 
-- Game: Safety First!
addappid(497700)
addappid(497701, 1, "05ad685b939eccc264672809fb8d1711488cac1707982c8157345d1a47a90d71")
