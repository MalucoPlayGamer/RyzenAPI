-- Lua provided by RyzenAPI
-- Game: addappid(1520900)

-- MAIN APPLICATION
addappid(1520900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520903,0,"0d1d2b93615af0d80e0c3aa09ad14b07767b1bd9455841806c03b7fa324b262c")
