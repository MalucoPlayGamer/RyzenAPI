-- Lua provided by RyzenAPI
-- Game: Game: Kinetic Anatomy 3D

-- MAIN APPLICATION
addappid(2918430)
addappid(3164630)
-- Game: addappid(2918430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918431, 1, "3fcbdd6982acd4ffb56a0778e25ff4609ce1cd95098e758d71eb35ddfd1bcfc0")
