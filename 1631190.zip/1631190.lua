-- Lua provided by RyzenAPI
-- Game: 1631190

-- MAIN APPLICATION
addappid(1631190)
-- Game: addappid(1631190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631191, 1, "7185e2fa9c9ed90b80ec08c3e7548efb6e5103532cd520c408db23fd25c76a33")
