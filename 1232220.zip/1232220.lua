-- Lua provided by RyzenAPI
-- Game: Professional Fishing 2

-- MAIN APPLICATION
addappid(1232220)
-- Game: addappid(1232220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232222,0,"29d650500d0ce0447f1ac7261d7844feeb782a15e137ade5211c09dffdde0b6e")
