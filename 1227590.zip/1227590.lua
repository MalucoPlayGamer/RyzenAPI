-- Lua provided by RyzenAPI
-- Game: DominaTRIX - Hentai Storytelling Puzzle

-- MAIN APPLICATION
addappid(1227590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227591, 1, "639d849f32c867a1beec5248aae4437cd4434a16400bc1f654f08da56fb4b7bf")
addappid(1227593, 1, "e076c6c86c70b5e86e237150ae494a63dfa979d8fc71ec09b1c87885f5fdf08f")

