-- Lua provided by RyzenAPI
-- Game: Kingdom Rush Vengeance - Tower Defense

-- MAIN APPLICATION
addappid(1367550)
-- Game: addappid(1367550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367551, 1, "d1e9471104a4ea2d07be67a6352166d046779197b4b9b8f4f1a13073a2d23f54")
addappid(1367552, 1, "6dd002ff1dbc19423c66d76b1bcf01fa35234ab22f5e041322d8ede40b5de471")
addappid(1367553, 1, "7fd101ebe069b9b6318073235bf4fcfa6c307bb5546e15009096bb28b5af5ad8")
