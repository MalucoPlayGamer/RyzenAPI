-- Lua provided by RyzenAPI
-- Game: Kingdom Rush Vengeance - Tower Defense

-- MAIN APPLICATION
addappid(1367550)
addappid(2695220)
addappid(3118000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1367551, 1, "d1e9471104a4ea2d07be67a6352166d046779197b4b9b8f4f1a13073a2d23f54")
addappid(1367552, 1, "6dd002ff1dbc19423c66d76b1bcf01fa35234ab22f5e041322d8ede40b5de471")
addappid(1367553, 1, "7fd101ebe069b9b6318073235bf4fcfa6c307bb5546e15009096bb28b5af5ad8")

