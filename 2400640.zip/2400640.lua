-- Lua provided by RyzenAPI
-- Game: 2400640

-- MAIN APPLICATION
addappid(2400640)
-- Game: addappid(2400640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400641, 1, "7b7434476b362ddfd828e706bf0271cd1b87abcc5bc4d82201fbeeb743d2e164")
