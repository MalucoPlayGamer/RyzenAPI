-- Lua provided by RyzenAPI
-- Game: addappid(1450060)

-- MAIN APPLICATION
addappid(1450060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450061, 1, "446ba5bc57b9b711606ca54ce4903da4dbc31c217075bfcc062a865df9860378")
