-- Lua provided by RyzenAPI
-- Game: College Seduction Premium Edition

-- MAIN APPLICATION
addappid(1851480)
-- Game: addappid(1851480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851485,0,"7e5b919ae094b1459c6b4b849bcf55b401cdacf35facc637847e7d45775581a8")
addappid(1851486,0,"c1f3be1e53f98e0b02785c67a247e41cb89126f13d4c5038c0f7e5f6bd421932")
