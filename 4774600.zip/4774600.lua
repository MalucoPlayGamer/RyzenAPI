-- 4774600's Lua and Manifest Created by Hubcap Manifest
-- Farming Chillhood
-- Created: June 28, 2026 at 04:02:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4774600) -- Farming Chillhood
-- MAIN APP DEPOTS
addappid(4774601, 1, "e0477cacc763d684b3bc2233cc0c6fb9237b045fdd8929f0d85acb0af46899eb") -- Depot 4774601
-- setManifestid(4774601, "5207563055440259293", 386310230)