-- Lua provided by RyzenAPI
-- Game: 对弈五千年 Demo

-- MAIN APPLICATION
addappid(3277330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277331, 1, "7e1fee88be0880a94066d9017466084416b2db6b4db63e87442fc94d64dc5e11")

