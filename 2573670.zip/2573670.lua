-- Lua provided by RyzenAPI
-- Game: Fragment: A Story in Growing

-- MAIN APPLICATION
addappid(2573670)
-- Game: addappid(2573670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573671, 1, "2fbcb4d7755abf264fc38940404a22496aca025fccc5a653252342717998a771")
