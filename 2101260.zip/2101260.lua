-- Lua provided by RyzenAPI
-- Game: addappid(2101260)

-- MAIN APPLICATION
addappid(2101260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101261, 1, "7bb4104505000fdc5121c8ccfba473a7129634026dfaef287f067fecbed52f85")
