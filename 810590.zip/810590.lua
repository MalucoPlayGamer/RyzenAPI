-- Lua provided by RyzenAPI
-- Game: addappid(810590)

-- MAIN APPLICATION
addappid(810590)

-- MAIN APP DEPOTS / PACKAGES
addappid(810591, 1, "aa1b5991119609429a111eaf6e9b33b15ef06eb7644a82d1d8a1feac2130a64e")
