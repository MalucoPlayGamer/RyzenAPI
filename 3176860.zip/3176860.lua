-- Lua provided by RyzenAPI
-- Game: 3176860

-- MAIN APPLICATION
addappid(3176860)
-- Game: addappid(3176860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176861, 1, "6a52bfac112b836f249e3e2bfae66408a9cf5d5150252102bc6b778614449ec7")
