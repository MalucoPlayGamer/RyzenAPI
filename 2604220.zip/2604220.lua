-- Lua provided by RyzenAPI
-- Game: addappid(2604220)

-- MAIN APPLICATION
addappid(2604220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604221, 1, "bd8409deeb33891dba1e9b75cfd87d6e0a4d31f5842b0f40b19c81ee7d0bcc9f")
