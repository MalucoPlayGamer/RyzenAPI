-- Lua provided by RyzenAPI
-- Game: Ocean Pressure

-- MAIN APPLICATION
addappid(2604220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2604221, 1, "bd8409deeb33891dba1e9b75cfd87d6e0a4d31f5842b0f40b19c81ee7d0bcc9f")

