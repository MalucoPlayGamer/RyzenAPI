-- Lua provided by RyzenAPI
-- Game: Game: AppID 670820

-- MAIN APPLICATION
addappid(670820)
-- Game: addappid(670820)

-- MAIN APP DEPOTS / PACKAGES
addappid(670821, 1, "c35c6ed7057e30b157fcc9f04ca541fa90d4d64fb4c5e5cbbe00b065c5b9ce54")
