-- Lua provided by RyzenAPI
-- Game: Game: Saccharine Pale?

-- MAIN APPLICATION
addappid(2314090)
-- Game: addappid(2314090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314091, 1, "3417482c513a78ad446a4435a2e27ad257c7070776745bbf0833848770a77181")
