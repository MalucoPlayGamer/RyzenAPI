-- Lua provided by RyzenAPI
-- Game: Game: Gooning Aim Trainer

-- MAIN APPLICATION
addappid(3438040)
-- Game: addappid(3438040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3438041, 1, "f9b2369caa6242168cdb458b1cd0f681804c9463b9cfb531cfadc8b661d8ed10")
