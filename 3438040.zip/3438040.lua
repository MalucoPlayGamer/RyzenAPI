-- Lua provided by RyzenAPI
-- Game: Gooning Aim Trainer

-- MAIN APPLICATION
addappid(3438040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3438041, 1, "f9b2369caa6242168cdb458b1cd0f681804c9463b9cfb531cfadc8b661d8ed10")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3567640)
addappid(3975120)
addappid(4243080)
