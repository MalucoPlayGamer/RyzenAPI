-- Lua provided by RyzenAPI
-- Game: 1851530

-- MAIN APPLICATION
addappid(1851530)
-- Game: addappid(1851530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851532,0,"c7249cb06b9f9dcbe8d7edc98f75526a016709cd9cab810c9fcad6c382154918")
addappid(1851533,0,"b71898031f3bd2a743e64db031ec80ea82dc60f2dc7def5ef082f4053a7f0bca")
