-- Lua provided by RyzenAPI
-- Game: Talisman: Digital 5th Edition

-- MAIN APPLICATION
addappid(908060)
addappid(3387810)
addappid(3496590)
addappid(3640140)
addappid(3653350)
addappid(3653360)
addappid(3653370)
addappid(3970170)
addappid(4331630)
addappid(4576880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(908063,0,"36a7fa47189041fa5c63860d80a86158ab15b553a67e198216c38cd09e2a0c9f")

