-- Lua provided by RyzenAPI
-- Game: Talisman: Digital 5th Edition

-- MAIN APPLICATION
addappid(908060)

-- MAIN APP DEPOTS / PACKAGES
addappid(908063,0,"36a7fa47189041fa5c63860d80a86158ab15b553a67e198216c38cd09e2a0c9f")

