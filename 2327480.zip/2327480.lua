-- Lua provided by RyzenAPI
-- Game: Backrooms: Realm of Shadows

-- MAIN APPLICATION
addappid(2327480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327481, 1, "0c888b50f2605d7f5b2d6bd2526aa605395ff8187b31c0e20500851160124fd6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2773400)
addappid(2825590)
