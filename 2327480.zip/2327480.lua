-- Lua provided by RyzenAPI
-- Game: Backrooms: Realm of Shadows

-- MAIN APPLICATION
addappid(2327480)
-- Game: addappid(2327480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327481, 1, "0c888b50f2605d7f5b2d6bd2526aa605395ff8187b31c0e20500851160124fd6")
