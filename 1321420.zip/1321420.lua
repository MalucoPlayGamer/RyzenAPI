-- Lua provided by RyzenAPI 
-- Game: AppID 1321420
addappid(1321420)
addappid(1321421, 1, "fe5d54099a08a985cf3128a34ab875d36f032fcbe20e9e8984dab57e1e93111d")
