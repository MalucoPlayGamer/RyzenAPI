-- Lua provided by RyzenAPI
-- Game: 1321420

-- MAIN APPLICATION
addappid(1321420)
-- Game: addappid(1321420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321421, 1, "fe5d54099a08a985cf3128a34ab875d36f032fcbe20e9e8984dab57e1e93111d")
