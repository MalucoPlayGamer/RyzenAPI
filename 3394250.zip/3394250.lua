-- Lua provided by RyzenAPI
-- Game: DUET

-- MAIN APPLICATION
addappid(3394250)

