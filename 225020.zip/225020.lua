-- Lua provided by RyzenAPI
-- Game: addappid(225020)

-- MAIN APPLICATION
addappid(225020)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(225021, 1, "f053bab85fbebfaf8c64790c44595a3587db310479fb94867f895ddd9c70949e")
