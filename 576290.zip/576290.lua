-- Lua provided by RyzenAPI
-- Game: Game: Huckleberry Falls

-- MAIN APPLICATION
addappid(576290)
-- Game: addappid(576290)

-- MAIN APP DEPOTS / PACKAGES
addappid(576291, 1, "c398b4a82a647c2ac03944f8c5cc447e92a2eb323d746463891d580908915d62")
addappid(576292, 1, "9714d2f8d16cfc4127c53d478a6080eda860c4043c71ccfded90367bec6cf0c1")
addappid(576293, 1, "93823e6c641ecd6becd48a16e5877c169ff95ae918c0a48791b04284e183de16")
