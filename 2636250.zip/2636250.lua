-- Lua provided by RyzenAPI
-- Game: Hollowbody Demo

-- MAIN APPLICATION
addappid(2636250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636251, 1, "1204dd9fb2ac3568c93145d8a8b4cc7fd1fdf95fcbe72a1e8ebc6a1cff5b2c82")
