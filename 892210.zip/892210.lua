-- Lua provided by RyzenAPI
-- Game: GUNGRAVE VR

-- MAIN APPLICATION
addappid(892210)
-- Game: addappid(892210)

-- MAIN APP DEPOTS / PACKAGES
addappid(892211, 1, "76dd02908637d5f341348175606af92d52f5f31fbef14dbc8d5750d462742fb9")
