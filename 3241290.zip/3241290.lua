-- Lua provided by SkyAPI 
-- Game: AppID 3241290
addappid(3241290)
addappid(3241291, 1, "6368c75c2ebf22df972f5e582eb9824bc6e4dae77aeed9f59d061d5fc31b6327")
