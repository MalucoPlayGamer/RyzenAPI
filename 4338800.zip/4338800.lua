-- Lua provided by RyzenAPI
-- Game: 天道模拟器之放置修仙

-- MAIN APPLICATION
addappid(4338800)
