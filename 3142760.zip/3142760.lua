-- Lua provided by RyzenAPI
-- Game: 209

-- MAIN APPLICATION
addappid(3142760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142761, 1, "c35c95f9805a99211714e51dfc9eab5261fcf6a9a4df6da2fed480aab7a86ce3")
