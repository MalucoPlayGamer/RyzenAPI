-- Lua provided by RyzenAPI 
-- Game: Big Fish
addappid(1689530)
addappid(1689531, 1, "d75d0109dbc9e0dc5e9942fc3001bb27343dceb4fc168553cf4de46ca51e04f0")
