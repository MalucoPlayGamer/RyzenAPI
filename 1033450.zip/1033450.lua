-- Lua provided by RyzenAPI
-- Game: addappid(1033450)

-- MAIN APPLICATION
addappid(1033450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033451, 1, "ff4f0069372122440fd73bac0cb976a0db0aa009560b0e6fae30b2337fe25045")
