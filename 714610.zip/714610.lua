-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: Rain or Shine

-- MAIN APPLICATION
addappid(714610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(714611, 1, "2847c6f19308a8d94f37c70534d33796a23e38fd25c97f03271db45a2d4640af")
addappid(714612, 1, "9e5088ef87ea3516fd93cc7527d176cd28994c83c7eafccc9177ddc65eb8360b")

