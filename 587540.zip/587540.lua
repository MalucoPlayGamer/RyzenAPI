-- Lua provided by RyzenAPI
-- Game: 587540

-- MAIN APPLICATION
addappid(587540)
-- Game: addappid(587540)

-- MAIN APP DEPOTS / PACKAGES
addappid(587541, 1, "1d4949e76d49b45f6d11336abe55136700d4befd08729d2d72097ee2360ae77e")
