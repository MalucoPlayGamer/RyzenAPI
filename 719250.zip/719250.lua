-- Lua provided by RyzenAPI 
-- Game: Cove Point Fun Center VR
addappid(719250)
addappid(719251, 1, "da99277d91f94561a821119b6b0429b83ee0301ce27a55d37d9eec45312e72bd")
