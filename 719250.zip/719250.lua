-- Lua provided by RyzenAPI
-- Game: Cove Point Fun Center VR

-- MAIN APPLICATION
addappid(719250)

-- MAIN APP DEPOTS / PACKAGES
addappid(719251, 1, "da99277d91f94561a821119b6b0429b83ee0301ce27a55d37d9eec45312e72bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
