-- Lua provided by RyzenAPI
-- Game: Cove Point Fun Center VR

-- MAIN APPLICATION
addappid(719250)
-- Game: addappid(719250)

-- MAIN APP DEPOTS / PACKAGES
addappid(719251, 1, "da99277d91f94561a821119b6b0429b83ee0301ce27a55d37d9eec45312e72bd")
