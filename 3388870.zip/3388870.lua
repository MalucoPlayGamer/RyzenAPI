-- Lua provided by RyzenAPI
-- Game: addappid(3388870)

-- MAIN APPLICATION
addappid(3388870)
addappid(3841310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388871, 1, "9ea2b45c022bc4860fa857fecc09a14c1e815f2c0fe0ace4ab6ba91da7aae96d")
