-- Lua provided by RyzenAPI
-- Game: 1116100

-- MAIN APPLICATION
addappid(1116100)
-- Game: addappid(1116100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116101, 1, "1f76abfa83c8546ebbfa780d9720c2d2f52d600431c6c7874a49cb7757bf7125")
