-- Lua provided by RyzenAPI
-- Game: A Game About

-- MAIN APPLICATION
addappid(927990)
addappid(1018480)

