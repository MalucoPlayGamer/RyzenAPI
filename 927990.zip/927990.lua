-- Lua provided by RyzenAPI
-- Game: A Game About

-- MAIN APPLICATION
addappid(927990)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1018480)
