-- Lua provided by RyzenAPI
-- Game: Game: AppID 393950

-- MAIN APPLICATION
addappid(393950)
-- Game: addappid(393950)

-- MAIN APP DEPOTS / PACKAGES
addappid(393951, 1, "5d395cf16077813a81c5994c696d0b20f98bc99b03b5671629ff1d70c82698a8")
