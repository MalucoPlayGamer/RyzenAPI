-- Lua provided by RyzenAPI
-- Game: Game: Galaxy City®

-- MAIN APPLICATION
addappid(1800650)
-- Game: addappid(1800650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800651, 1, "60721a3630c992d5600808b788a69788431896d84dde0125b49de55937031253")
