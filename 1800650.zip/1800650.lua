-- Lua provided by SkyAPI 
-- Game: Galaxy City®
addappid(1800650)
addappid(1800651, 1, "60721a3630c992d5600808b788a69788431896d84dde0125b49de55937031253")
