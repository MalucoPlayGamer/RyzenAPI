-- Lua provided by RyzenAPI
-- Game: addappid(421830)

-- MAIN APPLICATION
addappid(421830)

-- MAIN APP DEPOTS / PACKAGES
addappid(421831, 1, "ca0ad8c9f07f499412108e089ad8b9452bebc5b5b48d0892632c3a2432b8d639")
