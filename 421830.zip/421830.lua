-- Lua provided by RyzenAPI 
-- Game: AppID 421830
addappid(421830)
addappid(421831, 1, "ca0ad8c9f07f499412108e089ad8b9452bebc5b5b48d0892632c3a2432b8d639")
