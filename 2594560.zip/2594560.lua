-- Lua provided by RyzenAPI
-- Game: Devil Seeds

-- MAIN APPLICATION
addappid(2594560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2594561, 1, "ac1575159cd876b35b57b6a7797b8350a20f30174a8bef02221fb756f2a32d2b")

