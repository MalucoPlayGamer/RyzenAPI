-- Lua provided by RyzenAPI
-- Game: Game: Devil Seeds

-- MAIN APPLICATION
addappid(2594560)
-- Game: addappid(2594560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594561, 1, "ac1575159cd876b35b57b6a7797b8350a20f30174a8bef02221fb756f2a32d2b")
