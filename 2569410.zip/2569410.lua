-- Lua provided by RyzenAPI
-- Game: War Of Castles

-- MAIN APPLICATION
addappid(2569410)
-- Game: addappid(2569410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569411, 1, "e03a55a3419134ed9d3914716713d44f3ccf722faa8265227a8a346ca9643c17")
