-- Lua provided by RyzenAPI
-- Game: Coloring Voxels

-- MAIN APPLICATION
addappid(3634590)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3969980)
addappid(4008230)
addappid(4094480)
addappid(4129850)
addappid(4129860)
addappid(4335710)
addappid(4400580)
addappid(4475660)
addappid(4557220)
addappid(4693760)
addappid(4743110)
addappid(4834660)
addappid(5058720)
