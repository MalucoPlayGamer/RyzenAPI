-- Lua provided by RyzenAPI
-- Game: Coloring Voxels

-- MAIN APPLICATION
addappid(3634590)

