-- Lua provided by RyzenAPI
-- Game: Scarlet Maiden

-- MAIN APPLICATION
addappid(1968840)
-- Game: addappid(1968840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968841, 1, "a1af508c18885b42388ec2960c468fd0012bba6ac9a4a955998c2975605617b8")
