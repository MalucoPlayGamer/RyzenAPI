-- Lua provided by SkyAPI 
-- Game: Scarlet Maiden
addappid(1968840)
addappid(1968841, 1, "a1af508c18885b42388ec2960c468fd0012bba6ac9a4a955998c2975605617b8")
