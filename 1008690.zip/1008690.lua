-- Lua provided by RyzenAPI
-- Game: Game: Lost Daughter

-- MAIN APPLICATION
addappid(1008690)
-- Game: addappid(1008690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008691, 1, "bbf7c7135f0dab142a30ccec9c96e2503a32888630b2ede6a4bb5bff5ce56e4a")
