-- Lua provided by RyzenAPI
-- Game: Artemis: God-Queen of The Hunt

-- MAIN APPLICATION
addappid(1081850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081851, 1, "a2daf35ed5760218dfb8129dedbdb11d41a113704f1a7092d86c359d797e0177")
