-- Lua provided by RyzenAPI 
-- Game: AppID 1081850
addappid(1081850)
addappid(1081851, 1, "a2daf35ed5760218dfb8129dedbdb11d41a113704f1a7092d86c359d797e0177")
