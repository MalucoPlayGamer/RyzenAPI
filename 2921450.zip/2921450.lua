-- Lua provided by RyzenAPI
-- Game: AppID 2921450

-- MAIN APPLICATION
addappid(2921450)
-- Game: addappid(2921450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921451, 1, "663e2813c37ed80b440a4f18d40a100a7b5d2f6591d5229a57c6b96f3df8f4c6")
