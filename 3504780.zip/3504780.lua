-- Lua provided by RyzenAPI
-- Game: Wildgate

-- MAIN APPLICATION
addappid(3504780)
addappid(3800280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3504781, 1, "71fdf4b05d1d3b5fed04a89cbda1c0cee0ec927de3b83af78809100038ae17ff")
