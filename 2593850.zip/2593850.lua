-- Lua provided by SkyAPI 
-- Game: Mech Academy
addappid(2593850)
addappid(2593851, 1, "0e9c4e511b98dbfd9c05645829b9804dd99922b9f366c4085c8fed9a6c3e3afa")
