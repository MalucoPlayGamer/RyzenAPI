-- Lua provided by RyzenAPI
-- Game: Mech Academy

-- MAIN APPLICATION
addappid(2593850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593851, 1, "0e9c4e511b98dbfd9c05645829b9804dd99922b9f366c4085c8fed9a6c3e3afa")
