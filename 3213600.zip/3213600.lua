-- Lua provided by RyzenAPI
-- Game: 3213600

-- MAIN APPLICATION
addappid(3213600)
-- Game: addappid(3213600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213601, 1, "8d35e1a5eb7262208acade7c3012822a00fce0a1415ee4795a0e2e00662a0f5e")
