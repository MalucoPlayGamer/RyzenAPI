-- Lua provided by RyzenAPI
-- Game: Parkour Tag

-- MAIN APPLICATION
addappid(1699860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699861, 1, "51bb6e8862c4004263ca7167c3e983d5dd2ed4827f76a73544e7608a6d2c657c")
