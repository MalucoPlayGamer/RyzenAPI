-- Lua provided by RyzenAPI
-- Game: 1629190

-- MAIN APPLICATION
addappid(1629190)
-- Game: addappid(1629190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629191, 1, "26a0aa420223e9bf369f2c821f7ce20a8ac29798b1b22608d20255ecbedbd2ba")
