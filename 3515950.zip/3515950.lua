-- Lua provided by RyzenAPI
-- Game: Star Wars Outlaws - Free Demo

-- MAIN APPLICATION
addappid(3515950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

