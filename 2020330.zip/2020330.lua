-- Lua provided by RyzenAPI
-- Game: RockSlide

-- MAIN APPLICATION
addappid(2020330)
-- Game: addappid(2020330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020331, 1, "66263e6571ec82b0eae77cfed11cf3b363cf92b0b68bd7e02cd98e82509271d9")
