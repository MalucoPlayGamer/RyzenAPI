-- Lua provided by RyzenAPI
-- Game: Arctic Wolves

-- MAIN APPLICATION
addappid(3326280)
-- Game: addappid(3326280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3326281, 1, "3a07b80bdb2d0b4a09f05302e1423791c992738bb47172ab1bb458da68306e89")
addappid(3326282, 1, "6bb73b3145b26db7cfc6a59ad4967fa16a118073e4c8f18a80f20647b61d7ef6")
