-- Lua provided by RyzenAPI
-- Game: Game: AppID 400450

-- MAIN APPLICATION
addappid(400450)
-- Game: addappid(400450)

-- MAIN APP DEPOTS / PACKAGES
addappid(400451, 1, "e933eda659bd773ff8ac240f4290241bbce6f8a798c0c07607cb18db7d643cb2")
addappid(400452, 1, "a21426f77947a000c0fd75e71d2047acf50b6593368b0c5704a52fb0b833eab4")
addappid(400453, 1, "542ccca0b4148ecc443d7316825c84277acbf226940ee711ac487c0dcb2c1a29")
