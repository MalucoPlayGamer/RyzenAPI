-- Lua provided by RyzenAPI
-- Game: NeuroVoider

-- MAIN APPLICATION
addappid(400450)
addappid(521010)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(400451, 1, "e933eda659bd773ff8ac240f4290241bbce6f8a798c0c07607cb18db7d643cb2")
addappid(400452, 1, "a21426f77947a000c0fd75e71d2047acf50b6593368b0c5704a52fb0b833eab4")
addappid(400453, 1, "542ccca0b4148ecc443d7316825c84277acbf226940ee711ac487c0dcb2c1a29")

