-- Lua provided by RyzenAPI 
-- Game: Facehand
addappid(2605600)
addappid(2605601, 1, "8619fde231a8d83951df7374ba9a9546e46b0d0d24a6554e4271c78eb0e2f1df")
