-- Lua provided by SkyAPI 
-- Game: AppID 1894310
addappid(1894310)
addappid(1894311, 1, "4a9cb514c504c79a21f31cb3ce72a4fdfc93f0dc345516aac536b1502fea829c")
