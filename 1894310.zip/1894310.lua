-- Lua provided by RyzenAPI
-- Game: 1894310

-- MAIN APPLICATION
addappid(1894310)
-- Game: addappid(1894310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894311, 1, "4a9cb514c504c79a21f31cb3ce72a4fdfc93f0dc345516aac536b1502fea829c")
