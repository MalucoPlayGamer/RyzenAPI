-- Lua provided by SkyAPI 
-- Game: Wildcard Demo
addappid(2909330)
addappid(2909331, 1, "c4d79eb666f6870eb22d82b1053e946b1af055a5048be7bef742c5098015e245")
