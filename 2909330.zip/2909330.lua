-- Lua provided by RyzenAPI
-- Game: Wildcard Demo

-- MAIN APPLICATION
addappid(2909330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909331, 1, "c4d79eb666f6870eb22d82b1053e946b1af055a5048be7bef742c5098015e245")

