-- Lua provided by RyzenAPI
-- Game: Mad Island

-- MAIN APPLICATION
addappid(2739590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739591, 1, "b4965a72b078a66e012d79a8af2548c3201e72b2fc234cc1e562863063dc42b8")

