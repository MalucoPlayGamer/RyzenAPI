-- Lua provided by RyzenAPI
-- Game: Crankies Workshop: Grizzbot Assembly 2

-- MAIN APPLICATION
addappid(719460)

-- MAIN APP DEPOTS / PACKAGES
addappid(719461, 1, "a6e4330ebe48ff0ba92273fa1a08f4956de31c7c16d7974823b9a0ddc1c8d6aa")

