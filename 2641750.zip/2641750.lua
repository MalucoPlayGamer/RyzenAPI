-- Lua provided by RyzenAPI
-- Game: Divine Frequency Demo

-- MAIN APPLICATION
addappid(2641750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641751, 1, "34e211cb649b869739254fc005d410c8e1d0557aa72a28b8654f6150aa595171")
