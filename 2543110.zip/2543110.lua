-- Lua provided by RyzenAPI
-- Game: Lucky Bastard

-- MAIN APPLICATION
addappid(2543110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543111, 1, "37f5d6897f8c51e31dccdea83890a1f5a166521a3e8e603bb6dbdc0a3358f7d5")
