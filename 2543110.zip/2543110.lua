-- Lua provided by SkyAPI 
-- Game: Lucky Bastard
addappid(2543110)
addappid(2543111, 1, "37f5d6897f8c51e31dccdea83890a1f5a166521a3e8e603bb6dbdc0a3358f7d5")
