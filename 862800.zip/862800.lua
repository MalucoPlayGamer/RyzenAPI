-- Lua provided by RyzenAPI
-- Game: Storm Chasers

-- MAIN APPLICATION
addappid(862800)
-- Game: addappid(862800)

-- MAIN APP DEPOTS / PACKAGES
addappid(862801, 1, "948429be9458f4b4721d6f7566bda5374644a310281e2635171f6d162e369b77")
