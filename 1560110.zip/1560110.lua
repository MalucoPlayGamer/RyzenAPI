-- Lua provided by RyzenAPI
-- Game: Game: PIRATECRAFT

-- MAIN APPLICATION
addappid(1560110)
-- Game: addappid(1560110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560111, 1, "59ceee3d18c633f84a3bed612155deaad8cf2015701074ffca4455b8ca3ed0c2")
