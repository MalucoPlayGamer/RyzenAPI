-- Lua provided by RyzenAPI 
-- Game: PIRATECRAFT
addappid(1560110)
addappid(1560111, 1, "59ceee3d18c633f84a3bed612155deaad8cf2015701074ffca4455b8ca3ed0c2")
