-- Lua provided by RyzenAPI
-- Game: Arthur's Reading Race

-- MAIN APPLICATION
addappid(2471160)
-- Game: addappid(2471160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471161, 1, "2949ea554910f02c4ba70084e7cdff03ccc1e1432df584b147c0be8b8e4ce019")
