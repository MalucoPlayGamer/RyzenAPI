-- Lua provided by RyzenAPI
-- Game: 305900

-- MAIN APPLICATION
addappid(305900)
-- Game: addappid(305900)

-- MAIN APP DEPOTS / PACKAGES
addappid(305901, 1, "69d5dc38a4c40b88a3470ea314de588fceb79bb213018f8d7a5e8edb44f20362")
