-- Lua provided by SkyAPI 
-- Game: AppID 305900
addappid(305900)
addappid(305901, 1, "69d5dc38a4c40b88a3470ea314de588fceb79bb213018f8d7a5e8edb44f20362")
