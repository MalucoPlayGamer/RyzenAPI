-- Lua provided by RyzenAPI
-- Game: AppID 305900

-- MAIN APPLICATION
addappid(305900)

-- MAIN APP DEPOTS / PACKAGES
addappid(305901, 1, "69d5dc38a4c40b88a3470ea314de588fceb79bb213018f8d7a5e8edb44f20362")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3298680)
