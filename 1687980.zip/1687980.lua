-- Lua provided by RyzenAPI
-- Game: addappid(1687980)

-- MAIN APPLICATION
addappid(1687980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687981, 1, "f22fd156662f7d536dc5eba6d685b6a3ea252d83848e5a71378d0063c6a052a3")
