-- Lua provided by RyzenAPI
-- Game: AppID 738880

-- MAIN APPLICATION
addappid(738880)
-- Game: addappid(738880)

-- MAIN APP DEPOTS / PACKAGES
addappid(738881, 1, "71e2e715807c3d530c64cd3af8894343e8a5ece45163e0a20372e904b054671f")
