-- Lua provided by RyzenAPI
-- Game: Pain of War

-- MAIN APPLICATION
addappid(738880)
addappid(774971)
addappid(1319810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(738881, 1, "71e2e715807c3d530c64cd3af8894343e8a5ece45163e0a20372e904b054671f")
