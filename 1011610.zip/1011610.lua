-- Lua provided by RyzenAPI
-- Game: Radio General

-- MAIN APPLICATION
addappid(1011610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011611, 1, "99ac22418370d95aada5e05174ca7b88a6697486463493a92363f247214fdff0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2110160)
