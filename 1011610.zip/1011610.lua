-- Lua provided by RyzenAPI
-- Game: Game: Radio General

-- MAIN APPLICATION
addappid(1011610)
-- Game: addappid(1011610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011611, 1, "99ac22418370d95aada5e05174ca7b88a6697486463493a92363f247214fdff0")
