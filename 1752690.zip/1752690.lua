-- Lua provided by RyzenAPI
-- Game: thEiAoLoGy

-- MAIN APPLICATION
addappid(1752690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752691, 1, "947735253aed5d187428ed957800fb8c5102217c860acc15c5208cab136dbead")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
