-- Lua provided by RyzenAPI
-- Game: Game: thEiAoLoGy

-- MAIN APPLICATION
addappid(1752690)
-- Game: addappid(1752690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752691, 1, "947735253aed5d187428ed957800fb8c5102217c860acc15c5208cab136dbead")
