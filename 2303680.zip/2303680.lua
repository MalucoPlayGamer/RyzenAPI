-- Lua provided by RyzenAPI
-- Game: Showgunners - Art Book

-- MAIN APPLICATION
addappid(2303680)
-- Game: addappid(2303680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303680,0,"4a2e4162088276b43536526a4294bf15c770f9517934542c0e8395968b819ec0")
