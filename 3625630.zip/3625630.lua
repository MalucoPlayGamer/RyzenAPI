-- Lua provided by RyzenAPI
-- Game: Lust Academy Final - Shadows Unleashed

-- MAIN APPLICATION
addappid(3625630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3625630,0,"46642d1567457ff9aa3f42b96262024fa77c6e60b7ddac850e7c7959c20d0f58")
