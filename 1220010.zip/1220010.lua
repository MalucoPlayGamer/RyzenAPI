-- Lua provided by RyzenAPI
-- Game: 1220010

-- MAIN APPLICATION
addappid(1220010)
-- Game: addappid(1220010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220011, 1, "c282e5aea5508168d72b73189b916ba008b9c13e82fad2a3e0cc00ab1dac1b7e")
addappid(1220012, 1, "0d6a07561c79cb1e2158055e6aae53a8562325b93819ca782fd9567b14ad15ae")
addappid(1220013, 1, "ded94c0129efe3e30efc76ebdd7bb1a952abbc9e8ab9f5ddba23174abbe48ec9")
addappid(1220014, 1, "5d1c6ff6bb56f51088116ec62f51e8b428b7ecfec5d892c323bbd22e09bfed95")
