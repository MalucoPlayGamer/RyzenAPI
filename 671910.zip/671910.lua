-- Lua provided by RyzenAPI
-- Game: Game: Endless ATC Demo

-- MAIN APPLICATION
addappid(671910)
-- Game: addappid(671910)

-- MAIN APP DEPOTS / PACKAGES
addappid(671911, 1, "0fb6eb4ac53cc756dae7954bea612135bb8b49b870b238ca44d72b7cb81e0b7d")
