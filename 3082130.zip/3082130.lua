-- Lua provided by RyzenAPI
-- Game: THE DESCENT Demo

-- MAIN APPLICATION
addappid(3082130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3082131, 1, "6a7a30248f50b12a6dce76b6ceff92cbe8cef765a5f6d8c1808b1c08490a1ceb")
