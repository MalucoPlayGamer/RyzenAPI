-- Lua provided by RyzenAPI
-- Game: Theory of Fear

-- MAIN APPLICATION
addappid(605180)

-- MAIN APP DEPOTS / PACKAGES
addappid(605181,0,"23de1a6224c45fae05411efe2fa64053dc2d999dade7d775d6168e74d807575e")
addappid(605182,0,"ca3f5fb98b960581347f5a7e31a72d94f161cbf9f41055ca630a7f8ccacd292d")

