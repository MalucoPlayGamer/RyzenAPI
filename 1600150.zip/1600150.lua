-- Lua provided by RyzenAPI
-- Game: Game: Tiny Bunny: Full Soundtrack

-- MAIN APPLICATION
addappid(1600150)
-- Game: addappid(1600150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600151, 1, "f2f965944a396799b2f9140bf9b825ecdb9e20b211d27b4fbaec7efc7c211200")
