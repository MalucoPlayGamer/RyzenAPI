-- Lua provided by RyzenAPI
-- Game: AppID 780010

-- MAIN APPLICATION
addappid(780010)

-- MAIN APP DEPOTS / PACKAGES
addappid(780011, 1, "78d9e94f3205bf4f4ba8c15fcbdcfbefcd8d7f94aecbfb7b4869d9e6849721dd")
