-- Lua provided by RyzenAPI
-- Game: 1686060

-- MAIN APPLICATION
addappid(1686060)
-- Game: addappid(1686060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686061, 1, "0b2eb871acd32c7c8557ed47ee6315f5821f703cb5cf71d161251c1d08005957")
