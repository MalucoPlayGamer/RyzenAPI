-- Lua provided by RyzenAPI 
-- Game: Rhythm Witch: Beat Death
addappid(2951580)
addappid(2951581, 1, "0eb91817f38b08e589a0c5a2cc41747e56ec3804b017b5337079a93380ab6872")
