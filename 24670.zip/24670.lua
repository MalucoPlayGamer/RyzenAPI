-- Lua provided by RyzenAPI
-- Game: Trainz™ Simulator 12

-- MAIN APPLICATION
addappid(24634)
addappid(24635)
addappid(24670)
addappid(24673)
addappid(24674)
addappid(24675)
addappid(24676)
addappid(24677)
addappid(24678)
addappid(24679)
addappid(238991)
addappid(317690)
addappid(318050)
addappid(318960)

-- MAIN APP DEPOTS / PACKAGES
addappid(24671,0,"d51c755897b76e4bd32f9902b407e9a3c6121ad14d2597aedb4c1329f4457f6f")
addappid(24672,0,"46c4f42d51da8b1510146eaec62314bb0f3a4fdffe792d242760ba0df602e105")
addappid(24674,0,"4b7510542aeb77a7f0bc7d89cbf36f9b3fe99a1ad4d3a0dc7119d5ba18988e4d")
addappid(24675,0,"315de7146d4a23c02a2237cf844a8b2f147aee8a977a14d4d8aaa79947eea421")
addappid(24676,0,"41d4db0e415b673579e3b54f9c45bf2e4a295e34aaf93f548c008b9a5132a1ae")

