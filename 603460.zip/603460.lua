-- Lua provided by RyzenAPI
-- Game: addappid(603460)

-- MAIN APPLICATION
addappid(603460)

-- MAIN APP DEPOTS / PACKAGES
addappid(603461, 1, "8894803decad18ad096800bd0030d1b684d7542db3626ecd8bf8777f8f306d8c")
