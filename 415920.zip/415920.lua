-- Lua provided by RyzenAPI
-- Game: AppID 415920

-- MAIN APPLICATION
addappid(415920)
-- Game: addappid(415920)

-- MAIN APP DEPOTS / PACKAGES
addappid(415921, 1, "dcfd27a129783e86b105535b2a736cb30cb3a88d3bc1d2c951ee6e2203e81fcb")
