-- Lua provided by RyzenAPI
-- Game: Might & Magic: Heroes VI

-- MAIN APPLICATION
addappid(48220)
addappid(48224)
addappid(48225)
addappid(48226)
addappid(48227)
addappid(48228)
addappid(48229)
addappid(48231)
addappid(48232)
addappid(48233)
addappid(48234)
addappid(228982)
addappid(229790)
addappid(229791)
addappid(229792)

-- MAIN APP DEPOTS / PACKAGES
addappid(48221, 1, "6d9193587f64a7e023700a2ec1baf12b915e3173c7adf61ebcc77ea8feb0ba44")
addappid(48222, 1, "1bf9637de966da9d2c3384cc13cb0a4f241c994c087b42bc4c91feb309402fa0")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

