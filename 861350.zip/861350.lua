-- Lua provided by RyzenAPI
-- Game: Game: Gym Simulator

-- MAIN APPLICATION
addappid(861350)
-- Game: addappid(861350)

-- MAIN APP DEPOTS / PACKAGES
addappid(861351, 1, "1f5068c5a0e1ddccc75520127edbb93388136dba000157ccab1dfeb88f1d1d16")
