-- Lua provided by RyzenAPI
-- Game: Return to the Skyway

-- MAIN APPLICATION
addappid(2066270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066271, 1, "5975f16d792df1fb728e5f20317177ed3b302c5c3b148a8f6880000dc19d07a0")
