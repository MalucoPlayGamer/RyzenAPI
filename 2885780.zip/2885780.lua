-- Lua provided by RyzenAPI
-- Game: AppID 2885780

-- MAIN APPLICATION
addappid(2885780)
-- Game: addappid(2885780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885781, 1, "39e4c4b273a59f825bdd07a4f9a4e7fad54afe14c80df34a5ce279d88bc0a710")
