-- Lua provided by SkyAPI 
-- Game: AppID 498290
addappid(498290)
addappid(498291, 1, "e9e64de897992d0c34cfc1c39439ebe2b05be73c25bd9079fa904ee535e8eed0")
