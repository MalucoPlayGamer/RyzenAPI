-- Lua provided by RyzenAPI
-- Game: AppID 498290

-- MAIN APPLICATION
addappid(498290)

-- MAIN APP DEPOTS / PACKAGES
addappid(498291, 1, "e9e64de897992d0c34cfc1c39439ebe2b05be73c25bd9079fa904ee535e8eed0")
