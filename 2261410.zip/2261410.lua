-- Lua provided by SkyAPI 
-- Game: AppID 2261410
addappid(2261410)
addappid(2261411, 1, "2518c27927f5233bdccb6ea9d8892c668a4ee4ca0eee9cc3055d1c447056383d")
