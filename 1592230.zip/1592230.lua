-- Lua provided by SkyAPI 
-- Game: AppID 1592230
addappid(1592230)
addappid(1592231, 1, "cf119f2943d3c1b2502c3aee01960ff75ea2e6cf7b412fb1656096f508451544")
