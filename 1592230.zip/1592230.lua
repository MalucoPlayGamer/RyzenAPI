-- Lua provided by RyzenAPI
-- Game: 1592230

-- MAIN APPLICATION
addappid(1592230)
-- Game: addappid(1592230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592231, 1, "cf119f2943d3c1b2502c3aee01960ff75ea2e6cf7b412fb1656096f508451544")
