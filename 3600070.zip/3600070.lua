-- Lua provided by RyzenAPI
-- Game: Casual Fishing

-- MAIN APPLICATION
addappid(3600070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3600071, 1, "e3a4987b6a8e25d8469e013e534ac9bddf035c8d7f8bb82bb0b83525abc3e1e3")

