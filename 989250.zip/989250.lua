-- Lua provided by RyzenAPI
-- Game: setManifestid(989252,"5065701776566113173")

-- MAIN APPLICATION
addappid(989250)
-- Game: addappid(989250)

-- MAIN APP DEPOTS / PACKAGES
addappid(989252,0,"1128e9e61347e24cf60319b868528e0bed2389693f1af43febf10cd7caacfd65")
