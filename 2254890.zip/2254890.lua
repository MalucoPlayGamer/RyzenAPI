-- Lua provided by RyzenAPI
-- Game: 2254890

-- MAIN APPLICATION
addappid(2254890)
-- Game: addappid(2254890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254891, 1, "729988b69fdd52990bafdf7bb4272df39dd5d2421cacb3e3ed9fe2d82354288f")
