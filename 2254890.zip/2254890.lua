-- Lua provided by RyzenAPI
-- Game: The Killing Antidote

-- MAIN APPLICATION
addappid(2254890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254891, 1, "729988b69fdd52990bafdf7bb4272df39dd5d2421cacb3e3ed9fe2d82354288f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4350520)
addappid(4350590)
