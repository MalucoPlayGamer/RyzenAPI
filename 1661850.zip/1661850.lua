-- Lua provided by SkyAPI 
-- Game: AppID 1661850
addappid(1661850)
addappid(1661851, 1, "a4aa5fb1950cbd674815a76d6232b61e117bcc9786bb921100c936c294ab3081")
