-- Lua provided by RyzenAPI
-- Game: addappid(1661850)

-- MAIN APPLICATION
addappid(1661850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661851, 1, "a4aa5fb1950cbd674815a76d6232b61e117bcc9786bb921100c936c294ab3081")
