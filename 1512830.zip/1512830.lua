-- Lua provided by RyzenAPI
-- Game: 黑巢姐妹

-- MAIN APPLICATION
addappid(1512830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512831, 1, "6354ee4f3748eb5a1bca5e638d7fe2d9a4c8835c848f52c6fff6d3c8c0dc4d34")

