-- Lua provided by SkyAPI 
-- Game: AppID 822530
addappid(822530)
addappid(822531, 1, "53ef5ae3dd3f1181a59714e93eb2ce8a065253b983803aacc751c0beb4580738")
