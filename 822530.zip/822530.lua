-- Lua provided by RyzenAPI
-- Game: 822530

-- MAIN APPLICATION
addappid(822530)
-- Game: addappid(822530)

-- MAIN APP DEPOTS / PACKAGES
addappid(822531, 1, "53ef5ae3dd3f1181a59714e93eb2ce8a065253b983803aacc751c0beb4580738")
