-- Lua provided by RyzenAPI
-- Game: Rival Rides

-- MAIN APPLICATION
addappid(1978380)
-- Game: addappid(1978380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978381, 1, "6c07d0677e63fb9604c2cd98aa8bf67f8e1e2edb628b83343a8de25bb93c0121")
