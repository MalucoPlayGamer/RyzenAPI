-- Lua provided by RyzenAPI
-- Game: Rival Rides

-- MAIN APPLICATION
addappid(1978380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978381, 1, "6c07d0677e63fb9604c2cd98aa8bf67f8e1e2edb628b83343a8de25bb93c0121")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
