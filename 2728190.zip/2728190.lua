-- Lua provided by RyzenAPI
-- Game: Rocket Knight Adventures: Re-Sparked

-- MAIN APPLICATION
addappid(2728190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2728191, 1, "0b48149fd762298af2bd6a82e03840527b043c4311d770267da17087ce75653f")
