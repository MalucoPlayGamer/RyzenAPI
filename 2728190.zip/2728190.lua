-- Lua provided by SkyAPI 
-- Game: Rocket Knight Adventures: Re-Sparked
addappid(2728190)
addappid(2728191, 1, "0b48149fd762298af2bd6a82e03840527b043c4311d770267da17087ce75653f")
