-- Lua provided by RyzenAPI 
-- Game: End of Edge
addappid(2450570)
addappid(2450571, 1, "96146de62482569003a99520cf9f3190324a9234f0de4d1f009b0dee9c03cb9d")
