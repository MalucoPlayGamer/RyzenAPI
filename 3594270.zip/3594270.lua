-- Lua provided by RyzenAPI
-- Game: addappid(3594270)

-- MAIN APPLICATION
addappid(3594270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3594271, 1, "b3d9ccdbacf0a7cb748ebc94c62a4e7ec92421fbaa257e998f13b3bfa2ef7df7")
