-- Lua provided by RyzenAPI
-- Game: Hazel Sky Demo

-- MAIN APPLICATION
addappid(1269160)
-- Game: addappid(1269160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269161, 1, "9c19f696b3c99d6398b77c9e052a79f6340ee8b9dd6ec091c3071222faf31787")
