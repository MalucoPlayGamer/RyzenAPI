-- Lua provided by RyzenAPI
-- Game: addappid(2888830)

-- MAIN APPLICATION
addappid(2888830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888831, 1, "55225d7487c7b84da18c76ad99b050d87ab56e5cf98a74997bc79ce011bd111d")
