-- Lua provided by RyzenAPI
-- Game: Garden In!

-- MAIN APPLICATION
addappid(1953860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953861, 1, "3af2e5afee9282705d8cad47e771c61a4d47482a90fcca913065986165a014dc")
addappid(1953862, 1, "956100e7243be7d95fdda97208770db49e12306b51652fdd870872e5a6c563b8")
addappid(1953863, 1, "cbd3a1f05130c5d482223bf62503512791f8b7376221f6c9fc64be276a3a5bc6")
addappid(1953864, 1, "67747360f871ee2b397398c7e040964a46d29899c2ad34f8a8c08109964efdf7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2720930)
