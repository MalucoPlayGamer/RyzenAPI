-- 1628760's Lua and Manifest Created by Hubcap Manifest
-- Kawaii Neko Girls
-- Created: July 03, 2026 at 13:47:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 7

-- MAIN APPLICATION
addappid(1628760, 1, "fe6b55c9cb74fa191f2f58c3efa0bc11b0ec105b396450f4ce87bed7fb6fc0b7") -- Kawaii Neko Girls
-- MAIN APP DEPOTS
addappid(1628761, 1, "66def9fe227f36ff5818749252a21f49ff0ae6191ae7afbc8e396282cd145a2d") -- Depot 1628761
setManifestid(1628761, "9108360555793615730", 1340628206)
addappid(1628762, 1, "9f7a5e56f8396ac497632e655a6cd4499ce995eaa27e115d6d2ec623b8cfe454") -- Depot 1628762
setManifestid(1628762, "5183910739522446968", 416951322)
-- DLCS WITH DEDICATED DEPOTS
-- Kawaii Neko Girls - Artbook 18 (AppID: 2424320)
addappid(2424320)
addappid(2424320, 1, "93b830227ed22653c88a16bc717f233aebcd83d92cd50675c81e4fdda037a13a") -- Kawaii Neko Girls - Artbook 18 - Depot 2424320
setManifestid(2424320, "777972748088395506", 89296343)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1785830) -- Kawaii Neko Girls - 18 Adult Only Content
addappid(1794050) -- Kawaii Neko Girls - Small donation
addappid(1794051) -- Kawaii Neko Girls - Medium donation
addappid(1794052) -- Kawaii Neko Girls - Big donation
addappid(1794053) -- Kawaii Neko Girls - Amazing donation
addappid(2333270) -- Kawaii Neko Girls - Ultimate donation