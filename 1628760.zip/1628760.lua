-- Lua provided by RyzenAPI 
-- Game: Kawaii Neko Girls
addappid(1628760)
addappid(1628761, 1, "66def9fe227f36ff5818749252a21f49ff0ae6191ae7afbc8e396282cd145a2d")
addappid(1628762, 1, "9f7a5e56f8396ac497632e655a6cd4499ce995eaa27e115d6d2ec623b8cfe454")
