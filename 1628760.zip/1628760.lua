-- Lua provided by RyzenAPI
-- Game: Kawaii Neko Girls

-- MAIN APPLICATION
addappid(1785830) -- Kawaii Neko Girls - 18 Adult Only Content
addappid(1794050) -- Kawaii Neko Girls - Small donation
addappid(1794051) -- Kawaii Neko Girls - Medium donation
addappid(1794052) -- Kawaii Neko Girls - Big donation
addappid(1794053) -- Kawaii Neko Girls - Amazing donation
addappid(2333270) -- Kawaii Neko Girls - Ultimate donation
addappid(2424320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628760, 1, "fe6b55c9cb74fa191f2f58c3efa0bc11b0ec105b396450f4ce87bed7fb6fc0b7") -- Kawaii Neko Girls
addappid(1628761, 1, "66def9fe227f36ff5818749252a21f49ff0ae6191ae7afbc8e396282cd145a2d") -- Depot 1628761
addappid(1628762, 1, "9f7a5e56f8396ac497632e655a6cd4499ce995eaa27e115d6d2ec623b8cfe454") -- Depot 1628762
addappid(2424320, 1, "93b830227ed22653c88a16bc717f233aebcd83d92cd50675c81e4fdda037a13a") -- Kawaii Neko Girls - Artbook 18 - Depot 2424320

