-- Lua provided by RyzenAPI
-- Game: Game: AppID 588730

-- MAIN APPLICATION
addappid(588730)
-- Game: addappid(588730)

-- MAIN APP DEPOTS / PACKAGES
addappid(588731, 1, "2356416e9e903afa1b9ae896fdeec8153d7bd6a38c66b5c48fc60b8f84a7c5e2")
addappid(588732, 1, "68db473e3a3e4fd13bfb2cb28f8b1dbae2449f4f4eddcfb32f1c5f74e6b0680d")
addappid(588733, 1, "d0b7c78270c3233444fb9be710895a0c2fd4df48667a7d6069674b13839e9fe2")
addappid(588734, 1, "efae171f8456df2cb3b6bddcce62cc44a0a685847912e410668c127f80ea7e0a")
