-- Lua provided by RyzenAPI
-- Game: Double Kick Heroes

-- MAIN APPLICATION
addappid(589670)

-- MAIN APP DEPOTS / PACKAGES
addappid(589671, 1, "ff77e03c0236d5dec7031181e107eb0f91f5015c419f7d3a42f0f9f1fdc107b1")
addappid(589672, 1, "35692772637ddbf38223e7df2e92838434dc64430307a56c0a64b17e48a75e38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
