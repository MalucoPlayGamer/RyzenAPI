-- Lua provided by SkyAPI 
-- Game: Double Kick Heroes
addappid(589670)
addappid(589671, 1, "ff77e03c0236d5dec7031181e107eb0f91f5015c419f7d3a42f0f9f1fdc107b1")
addappid(589672, 1, "35692772637ddbf38223e7df2e92838434dc64430307a56c0a64b17e48a75e38")
