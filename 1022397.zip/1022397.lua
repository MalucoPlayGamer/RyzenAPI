-- Lua provided by RyzenAPI
-- Game: DFF NT: Glacial Guard, Snow Villiers' 4th Weapon

-- MAIN APPLICATION
addappid(1022397)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022397,0,"11cf21077c58dab9bd5e4ba694073dc7ba11e7deb5a3f7e64fa87508c047c61c")
