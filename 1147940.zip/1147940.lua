-- Lua provided by RyzenAPI
-- Game: Game: AppID 1147940

-- MAIN APPLICATION
addappid(1147940)
-- Game: addappid(1147940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147941, 1, "06185e0ae3401095595cc30328a48f265d3c3400cd6bc253224b777ebdea7c12")
