-- Lua provided by RyzenAPI
-- Game: Game: AppID 3306800

-- MAIN APPLICATION
addappid(3306800)
-- Game: addappid(3306800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3306801, 1, "249b82a1bd5258357f0c00c28a5dbbc14fd773f340fff1f3ff0bbd8d77646b3a")
