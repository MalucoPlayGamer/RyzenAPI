-- Lua provided by RyzenAPI
-- Game: Notch - The Innocent LunA: Eclipsed SinnerS

-- MAIN APPLICATION
addappid(325120)
-- Game: addappid(325120)

-- MAIN APP DEPOTS / PACKAGES
addappid(325121, 1, "ff5850b3044ba7f4a42d627c542089bc7b0b5a7cdd621f6c4e0725c239baecc1")
addappid(325122, 1, "b316136e5cbcf628632282149973a128ef209a75da9d7991d3d583063b87d65f")
addappid(325123, 1, "5f9a57f4d46b0ef417e1141a887b48f20b01ae90f5c02d2b091d98b734d7925c")
addappid(325124, 1, "a01124292243b971a440161691e23f50465e2cef5cf0a5c59b9d3ad4cdbd8bd9")
addappid(414610, 0, "30c5748fbe6d7706e901cc6e0ca5e1751f71a294325beb92dfd1126157efe88f")
