-- Lua provided by RyzenAPI
-- Game: 1644610

-- MAIN APPLICATION
addappid(1644610)
-- Game: addappid(1644610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644610,0,"c4fc38eca921eed7cbd31fd20b632ee4c4a23a151bb1d33b4c3c67219cff2e52")
