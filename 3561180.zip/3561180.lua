-- Lua provided by RyzenAPI
-- Game: Waiting for you at the end of time

-- MAIN APPLICATION
addappid(3561180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561181, 1, "dafb45fbfa2c77ce69a102d1ab44552d4e2038fe0a78399ba6bcb0d79ca86846")
