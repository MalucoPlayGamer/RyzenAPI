-- Lua provided by RyzenAPI
-- Game: Game: Star Realms

-- MAIN APPLICATION
addappid(438140)
-- Game: addappid(438140)

-- MAIN APP DEPOTS / PACKAGES
addappid(438141, 1, "00567dbcbbd89a690bbea21139ef9bdca59c905002ba49337c375870959b93be")
