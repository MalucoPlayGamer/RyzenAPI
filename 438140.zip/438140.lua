-- Lua provided by RyzenAPI
-- Game: Star Realms

-- MAIN APPLICATION
addappid(438140)

-- MAIN APP DEPOTS / PACKAGES
addappid(438141, 1, "00567dbcbbd89a690bbea21139ef9bdca59c905002ba49337c375870959b93be")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(438150)
addappid(440030)
addappid(440040)
addappid(440050)
addappid(499550)
addappid(500080)
addappid(616500)
addappid(683990)
addappid(683991)
addappid(683992)
addappid(683993)
addappid(683994)
addappid(1032410)
addappid(1175130)
addappid(1279210)
addappid(1279211)
addappid(1642120)
addappid(1797640)
addappid(1797641)
addappid(1797642)
addappid(1797643)
addappid(1797644)
addappid(4325330)
addappid(4325350)
