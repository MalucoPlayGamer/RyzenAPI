-- Lua provided by RyzenAPI
-- Game: addappid(2138280)

-- MAIN APPLICATION
addappid(2138280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138281, 1, "2704d12c0f58f9e7f3ca0be4d83b061b887b9b9f35c7bae4196a8d3a5747946e")
