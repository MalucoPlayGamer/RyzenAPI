-- Lua provided by RyzenAPI
-- Game: 831570

-- MAIN APPLICATION
addappid(831570)
-- Game: addappid(831570)

-- MAIN APP DEPOTS / PACKAGES
addappid(831571, 1, "709ba6890d8f80d39b14aec9c0cdb3e45bb6ae90d6f20465d91f4365fcb70707")
addappid(831572, 1, "56fda88df8a05550dab5cf6ba819cc40e436b02e550f366bd59a3f4a8cfcc478")
