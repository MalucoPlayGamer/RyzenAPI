-- Lua provided by RyzenAPI
-- Game: Gunpowder on The Teeth: Arcade

-- MAIN APPLICATION
addappid(994860)
-- Game: addappid(994860)

-- MAIN APP DEPOTS / PACKAGES
addappid(994861, 1, "b8f357b2d6401f020b037925eb65b5edf18f88a9374cfe38eff5a7ff050ef842")
addappid(1225311, 0, "4dd60d28cdbeca0191da1d977deb26fc590cff9fdfcbc28590fe090749160d81")
