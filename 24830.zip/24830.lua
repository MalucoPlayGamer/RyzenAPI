-- Lua provided by RyzenAPI
-- Game: The Godfather 2

-- MAIN APPLICATION
addappid(24830)
-- Game: addappid(24830)

-- MAIN APP DEPOTS / PACKAGES
addappid(24831, 1, "372b0e03c877c6b41a30b59efa111b3d71f907ae3d0d1b13ceddab55f833271c")
addappid(24832, 1, "4b4a754d1a42c00c298d53e97216255f8bf483984d12aff74314b5d6f8cc3a53")
addappid(24833, 1, "e60eb1b115b1b41db16fcd425c95181b826d9466638a65c8c37cec6f2a4cd419")
addappid(24834, 1, "810c030867f4026aaea4c3aeffd06c103663e4f346016713067d8700b4da0971")
addappid(24835, 1, "fdb936425bbebc43aa8a710f2bccf7397f1f2c39aa418e2431bf01c719f3d6f7")
