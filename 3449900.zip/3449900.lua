-- Lua provided by RyzenAPI
-- Game: addappid(3449900)

-- MAIN APPLICATION
addappid(3449900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3449901, 1, "f179179e6135ba4b5b7a31de1bbcd54b0607db92a6b27cbd2fa69082f80b146d")
