-- Lua provided by RyzenAPI
-- Game: Dangerous Games: Illusionist Collector's Edition

-- MAIN APPLICATION
addappid(723920)

-- MAIN APP DEPOTS / PACKAGES
addappid(723921,0,"1d6616d3b7c7307b246cacab35a5960b50710887e43cb1dad6c2553ea623a649")

