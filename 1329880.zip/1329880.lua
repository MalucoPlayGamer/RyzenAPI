-- Lua provided by RyzenAPI
-- Game: Wild West Legacy

-- MAIN APPLICATION
addappid(1329880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329881, 1, "e7c4f5cdf6d3910ea059e38dcd706a986c99bc16b14ab0b9faeb43446a8e311c")
addappid(2286820, 0, "372d09cda5bc99a6145d99a6824925f8f786dd6ab58f1e199b66b94d370c77c5")
addappid(2286821, 0, "792b344ea973101bf07334cf243731ebf1410ff3f20cf23f817d3ff8bfa62472")

