-- Lua provided by RyzenAPI
-- Game: Game: - Mischief Dungeon Life - 異世界転生した俺のイタズラダンジョンライフ

-- MAIN APPLICATION
addappid(1961870)
-- Game: addappid(1961870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961871, 1, "f0eb5d97b0fc5478a20ba69c23cd78e79d7d5b665928d2cc8c437d09d918a6ed")
