-- Lua provided by SkyAPI 
-- Game: Super Clown Adventures
addappid(1537820)
addappid(1537821, 1, "2487a58a445793c5de41342e5043f219917d1d7e74a045d6a230ced58f0d8fbe")
