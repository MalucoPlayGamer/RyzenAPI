-- Lua provided by RyzenAPI
-- Game: Idle Hacking: An Inaction RPG

-- MAIN APPLICATION
addappid(4453290)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
