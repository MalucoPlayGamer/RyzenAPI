-- Lua provided by RyzenAPI
-- Game: Idle Hacking: An Inaction RPG

-- MAIN APPLICATION
addappid(4453290)

