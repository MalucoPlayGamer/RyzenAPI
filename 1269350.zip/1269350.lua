-- Lua provided by SkyAPI 
-- Game: AppID 1269350
addappid(1269350)
addappid(1269351, 1, "2707607597b15edf027cb5c752b9f2cb8f4198aaeb94562ecec248b16448d49a")
