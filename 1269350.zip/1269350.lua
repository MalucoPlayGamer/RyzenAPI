-- Lua provided by RyzenAPI
-- Game: 1269350

-- MAIN APPLICATION
addappid(1269350)
-- Game: addappid(1269350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269351, 1, "2707607597b15edf027cb5c752b9f2cb8f4198aaeb94562ecec248b16448d49a")
