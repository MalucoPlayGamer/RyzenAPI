-- Lua provided by RyzenAPI
-- Game: 2845510

-- MAIN APPLICATION
addappid(2845510)
-- Game: addappid(2845510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845511, 1, "8ceab5a8e3ac53f318ccf4d6485e1fc7d686b0689214d5ee34df8c87318aea67")
addappid(2845512, 1, "410e9629dd85f49e99615bec64eafe3185e4704d2094ba43202d40dd1b1bd978")
