-- Lua provided by RyzenAPI
-- Game: Game: Modern Air Combat: Beyond Visual Range

-- MAIN APPLICATION
addappid(2068550)
-- Game: addappid(2068550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068551, 1, "e57f325bc5eaf619d290d250cfa6003e67bb8a2a1d387f91461b5a948f135fa3")
