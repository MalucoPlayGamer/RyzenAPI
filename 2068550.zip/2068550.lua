-- Lua provided by RyzenAPI
-- Game: Modern Air Combat: Beyond Visual Range

-- MAIN APPLICATION
addappid(2068550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068551, 1, "e57f325bc5eaf619d290d250cfa6003e67bb8a2a1d387f91461b5a948f135fa3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
