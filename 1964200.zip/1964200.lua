-- Lua provided by RyzenAPI
-- Game: Phantom Rose 2 Sapphire

-- MAIN APPLICATION
addappid(1964200)
-- Game: addappid(1964200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964201, 1, "956f9c43cf6e654103c8c69d74c86302398f90392824459143f04b380f9e44f4")
