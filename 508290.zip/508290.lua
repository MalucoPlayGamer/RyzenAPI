-- Lua provided by RyzenAPI
-- Game: AppID 508290

-- MAIN APPLICATION
addappid(508290)
-- Game: addappid(508290)

-- MAIN APP DEPOTS / PACKAGES
addappid(508291, 1, "4702dd64c52519ffda7e6fef8cf4cb46ad6891aff55e2f9ca837bb6d7d063b2d")
