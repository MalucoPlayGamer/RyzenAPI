-- Lua provided by RyzenAPI
-- Game: 涨粉二维码

-- MAIN APPLICATION
addappid(1551030)
-- Game: addappid(1551030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551031, 1, "384ad3cd3f62d6be4358b428bce46be04876fc4e8535966dc8712cc1575f580f")
