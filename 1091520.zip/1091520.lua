-- Lua provided by RyzenAPI
-- Game: 鸿门一宴(Malicious Dinner)

-- MAIN APPLICATION
addappid(1091520)
-- Game: addappid(1091520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091521, 1, "50cfee12e9ef04cfce567fea142243a9f1a35e37d377259e825d33a33616ce28")
