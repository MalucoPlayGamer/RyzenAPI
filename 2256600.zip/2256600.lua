-- Lua provided by RyzenAPI
-- Game: Game: 希望之光1：灵菌涅槃

-- MAIN APPLICATION
addappid(2256600)
-- Game: addappid(2256600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256601, 1, "7374d5e1125dc0537f94a0fcee7cd5918e30d626f434c48ba7936e7665823037")
