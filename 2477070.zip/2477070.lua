-- Lua provided by RyzenAPI
-- Game: addappid(2477070)

-- MAIN APPLICATION
addappid(2477070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477071, 1, "76f8a5bd3af086684b8815050ef36f09a13e255a0fb994f4dd491a09decc1c13")
