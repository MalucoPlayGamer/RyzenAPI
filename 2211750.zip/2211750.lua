-- Lua provided by RyzenAPI
-- Game: 2211750

-- MAIN APPLICATION
addappid(2211750)
-- Game: addappid(2211750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211751, 1, "eca13e1715c3ca70671811e86680c33c90995b4f067290cd8a95bf41c95f03cf")
