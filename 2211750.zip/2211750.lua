-- Lua provided by RyzenAPI
-- Game: Bounty

-- MAIN APPLICATION
addappid(2211750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2211751, 1, "eca13e1715c3ca70671811e86680c33c90995b4f067290cd8a95bf41c95f03cf")

