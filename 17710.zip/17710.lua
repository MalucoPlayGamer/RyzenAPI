-- Lua provided by RyzenAPI
-- Game: Nuclear Dawn

-- MAIN APPLICATION
addappid(17710)
addappid(17714)

-- MAIN APP DEPOTS / PACKAGES
addappid(17711, 1, "3b968757c8a3ff7b16cb4771e65dc58ceb3109ea3fbb7b3a3d97002812fd518d")
addappid(17712, 1, "a4912ee34265e04ff8ba5ff86cff85e3554618bf5a53b0b4cd8dcb1c40731bd2")
addappid(17713, 1, "56569845b1d349406a847ae769637cffc03c400e26b32d1aebb079c944b698c6")
addappid(17715, 1, "329b082e1cec65a04065bdca53f2e1d92fdbb6a171ba493cd122cfdfad196706")
addappid(17716, 1, "2a128eea413c77a0ace52a9b41445032bf32eb8edda6507ae7075dccc16dc009")
addappid(17717, 1, "344bc43bf12bef17df21930dc40587b0784c61a044db53d88c6600b36a85c5cc")

