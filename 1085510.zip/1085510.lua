-- Lua provided by RyzenAPI
-- Game: Garfield Kart - Furious Racing

-- MAIN APPLICATION
addappid(1085510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1085511, 1, "917cc10e95098e199d09095d510346fa746bf2fe066d1730060488c43e8bd5ea")

