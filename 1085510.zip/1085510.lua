-- Lua provided by SkyAPI 
-- Game: Garfield Kart - Furious Racing
addappid(1085510)
addappid(1085511, 1, "917cc10e95098e199d09095d510346fa746bf2fe066d1730060488c43e8bd5ea")
