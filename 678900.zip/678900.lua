-- Lua provided by RyzenAPI
-- Game: Farmer's Dynasty - Final Harvest Edition

-- MAIN APPLICATION
addappid(678900)
addappid(1381790)
addappid(1381791)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(678901, 1, "7db9128b587a8d1c55382f39d671eb66234504ad5403e2fc8cebb05b15e959f9")
addappid(1855670, 0, "27aaa52aec39b5f4a44a0bece8210491e0d8c3b027d0f0ef2c28d1c69748bc22")

