-- Lua provided by RyzenAPI
-- Game: AppID 678900

-- MAIN APPLICATION
addappid(678900)
addappid(1381790)
addappid(1381791)

-- MAIN APP DEPOTS / PACKAGES
addappid(678901, 1, "7db9128b587a8d1c55382f39d671eb66234504ad5403e2fc8cebb05b15e959f9")
addappid(1855670, 0, "27aaa52aec39b5f4a44a0bece8210491e0d8c3b027d0f0ef2c28d1c69748bc22")
