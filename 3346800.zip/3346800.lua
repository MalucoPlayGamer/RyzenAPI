-- Lua provided by RyzenAPI
-- Game: addappid(3346800)

-- MAIN APPLICATION
addappid(3346800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3346801, 1, "b88ac2d51742424e8aea2ef465b46f875cf3c14044c7fce3564feab70525f77f")
