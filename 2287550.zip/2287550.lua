-- Lua provided by RyzenAPI
-- Game: Farm RPG

-- MAIN APPLICATION
addappid(2287550)

