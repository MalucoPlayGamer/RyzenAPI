-- Lua provided by RyzenAPI
-- Game: Baskhead

-- MAIN APPLICATION
addappid(495550)

-- MAIN APP DEPOTS / PACKAGES
addappid(495551, 1, "4152023f8a16f3b761c47ec1d017b22bdc18a2e1062600e2684a6aa47005bc3e")
