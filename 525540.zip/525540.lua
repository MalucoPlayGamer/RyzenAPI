-- Lua provided by RyzenAPI
-- Game: 525540

-- MAIN APPLICATION
addappid(525540)
-- Game: addappid(525540)

-- MAIN APP DEPOTS / PACKAGES
addappid(525541, 1, "55e2499f033d8f7c0397789bb83a3fefeb6e26d8f99e88507a37d50c3d18e441")
