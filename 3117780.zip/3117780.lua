-- Lua provided by RyzenAPI
-- Game: Yin-Yang Ping-Pong

-- MAIN APPLICATION
addappid(3117780)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3128540)
