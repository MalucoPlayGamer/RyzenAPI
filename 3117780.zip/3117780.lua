-- Lua provided by RyzenAPI
-- Game: Yin-Yang Ping-Pong

-- MAIN APPLICATION
addappid(3117780)
