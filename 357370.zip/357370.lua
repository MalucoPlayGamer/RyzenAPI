-- Lua provided by RyzenAPI
-- Game: Game: Return NULL - Episode 1

-- MAIN APPLICATION
addappid(357370)
addappid(402680)
-- Game: addappid(357370)

-- MAIN APP DEPOTS / PACKAGES
addappid(357371, 1, "b1b9f765d56027b3c2285a4dc5e10fd313ed152022ecf9c7d4821ae89eda89a1")
addappid(357372, 1, "6d610c7f4b6a4d50ef7da360ab794d9063f6ccbe72aa7b9f70db0ddb1f4feaf9")
addappid(357373, 1, "aa250f9c06081caf3e13bd60c84d713d2d33c8cc18610b713b1a360c5927a667")
addappid(357374, 1, "50a1058f775c281e5198c17bc125273b74f9ca36bccc3a0153c46f04052f11ea")
addappid(357375, 1, "45d65371b83a2f016418b302bdf7714b05bf68c33159f52ebd6eaeabfdfc1c7d")
addappid(357376, 1, "d0873041372ec454fc6b39e875b8a83350c63fb5908f20fef5afccc68e11532a")
