-- Lua provided by RyzenAPI
-- Game: addappid(549650)

-- MAIN APPLICATION
addappid(549650)

-- MAIN APP DEPOTS / PACKAGES
addappid(549651, 1, "1ae8eb7b779ca7962cd803974fb97c7d643f9271c711e6c1ab09865ef21dfd54")
