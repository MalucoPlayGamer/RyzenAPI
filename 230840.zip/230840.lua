-- Lua provided by RyzenAPI
-- Game: Daylight

-- MAIN APPLICATION
addappid(230840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(230841, 1, "7ad8bbc8a5d98cdb717e1542c972c12597367dfc1c668de9043f192c37f2d653")

