-- Lua provided by RyzenAPI
-- Game: addappid(1207000)

-- MAIN APPLICATION
addappid(1207000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207000,0,"50bb3ad1c86384222f45bf83b02ac1a94cae03f5d455bde756d5d5f4983de5ee")
