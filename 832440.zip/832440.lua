-- Lua provided by RyzenAPI
-- Game: 丰饶之角 不可思议之物居住的小镇 Demo

-- MAIN APPLICATION
addappid(832440)
-- Game: addappid(832440)

-- MAIN APP DEPOTS / PACKAGES
addappid(832441, 1, "3b2576a00e8118dac988fd3c8566dca1773e220d1467142ae198ff1bf0973829")
