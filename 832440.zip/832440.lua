-- Lua provided by RyzenAPI
-- Game: addappid(832440)

-- MAIN APPLICATION
addappid(832440)

-- MAIN APP DEPOTS / PACKAGES
addappid(832441, 1, "3b2576a00e8118dac988fd3c8566dca1773e220d1467142ae198ff1bf0973829")
