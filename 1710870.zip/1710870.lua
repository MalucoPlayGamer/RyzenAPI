-- Lua provided by RyzenAPI
-- Game: addappid(1710870)

-- MAIN APPLICATION
addappid(1710870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710871, 1, "89c9b9a21c5f359f7b80b3f68d61a01cbae93361e1827a81d112faac53a1aec9")
