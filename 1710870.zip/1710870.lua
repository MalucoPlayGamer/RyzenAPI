-- Lua provided by SkyAPI 
-- Game: Super Drag Race
addappid(1710870)
addappid(1710871, 1, "89c9b9a21c5f359f7b80b3f68d61a01cbae93361e1827a81d112faac53a1aec9")
