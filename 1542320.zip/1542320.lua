-- Lua provided by RyzenAPI
-- Game: addappid(1542320)

-- MAIN APPLICATION
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228988)
addappid(228990)
addappid(1542320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253411,0,"21c2698068395c2dc1e445c2286bd843ec63e59e5ff20e89e805ad36e4df4f54")
