-- Lua provided by RyzenAPI
-- Game: 787480

-- MAIN APPLICATION
addappid(787480)
-- Game: addappid(787480)

-- MAIN APP DEPOTS / PACKAGES
addappid(787481, 1, "21ec2f837fe1dfd3cb4acfb74871f9989d4d75fb292e7ab5b902cbc58f577a63")
addappid(787482, 1, "3c49d038e4a9825a77cb8e9756d0aeb6e4971363b027c52c6477cac104710a40")
