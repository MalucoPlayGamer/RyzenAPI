-- 3971290's Lua and Manifest Created by Hubcap Manifest
-- The Money Pit
-- Created: August 15, 2026 at 03:16:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3971290) -- The Money Pit
-- MAIN APP DEPOTS
addappid(3971291, 1, "e51ca099fc9bc1fae55da17843d23c0af8006cccca81b1e3bca22cc0b8f25d50") -- Depot 3971291
setManifestid(3971291, "1845101933570029625", 4649448655)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)