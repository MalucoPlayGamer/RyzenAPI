-- Lua provided by RyzenAPI
-- Game: The Money Pit

-- MAIN APPLICATION
addappid(3971290) -- The Money Pit

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3971291, 1, "e51ca099fc9bc1fae55da17843d23c0af8006cccca81b1e3bca22cc0b8f25d50") -- Depot 3971291

