-- Lua provided by RyzenAPI
-- Game: A Kobold Story: Trenchcoat Adventurer

-- MAIN APPLICATION
addappid(3989640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3989641, 1, "70d03e4552cdffeae20e14c04337398b96ebbb6b8aa32055e1a79a163b519fed")

