-- Generated with Luie @ https://lua.tools/
-- 3989640 - A Kobold Story: Trenchcoat Adventurer
-- Generated 2026-08-12 20:26:57 UTC
-- # Depots (Total/DLC/Shared): 2/0/0

-- Main AppID
addappid(3989640)

-- Main Depots
addappid(3989641, 1, "70d03e4552cdffeae20e14c04337398b96ebbb6b8aa32055e1a79a163b519fed")
setManifestid(3989641, "5640205211840685045", 928058857)

-- Missing Depots (We don't have the keys yet lol): 3989642
