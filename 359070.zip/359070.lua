-- Lua provided by RyzenAPI
-- Game: Hunter Gatherer

-- MAIN APPLICATION
addappid(359070)

-- MAIN APP DEPOTS / PACKAGES
addappid(359071, 1, "4be16f1afc1f3af8b25bd47000e9839a583876d8837179609b01b04d3e527c60")
