-- Lua provided by RyzenAPI
-- Game: Kena: Bridge of Spirits

-- MAIN APPLICATION
addappid(1954200)
addappid(1964240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1954201, 1, "dbc042174e03cba3e4b8b08266abefcc5d6b3aab5926133d77969966a45d8b3e")

