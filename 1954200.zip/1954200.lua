-- Lua provided by RyzenAPI
-- Game: Kena: Bridge of Spirits

-- MAIN APPLICATION
addappid(1954200)
-- Game: addappid(1954200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954201, 1, "dbc042174e03cba3e4b8b08266abefcc5d6b3aab5926133d77969966a45d8b3e")
