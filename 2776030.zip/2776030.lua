-- Lua provided by RyzenAPI 
-- Game: Prostitute Pimp
addappid(2776030)
addappid(2776031, 1, "6d486e40d32441de67ac26cf9aa73f44fb0d1f00cd2874361643f77d8799ab7f")
