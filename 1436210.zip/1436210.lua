-- Lua provided by RyzenAPI
-- Game: Requiem

-- MAIN APPLICATION
addappid(1436210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436211, 1, "e91dbeca7fa7f43858e1f475b2eb7586d4226834c5129deb90c785cc492e7fe5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
