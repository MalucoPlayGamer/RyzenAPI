-- Lua provided by SkyAPI 
-- Game: Requiem
addappid(1436210)
addappid(1436211, 1, "e91dbeca7fa7f43858e1f475b2eb7586d4226834c5129deb90c785cc492e7fe5")
