-- Lua provided by RyzenAPI
-- Game: Bounty game

-- MAIN APPLICATION
addappid(1805360)
-- Game: addappid(1805360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805361, 1, "9b7d51cb6e837d2fee33f4c3d8d0a022828b6106e44621d9464663b6c224c666")
