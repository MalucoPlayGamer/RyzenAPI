-- Lua provided by RyzenAPI
-- Game: ANTONBLAST: One Blast Demo

-- MAIN APPLICATION
addappid(2446460)
-- Game: addappid(2446460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446461, 1, "99c7de1c0c594f592a9b29b8e85951bf4c00ddd34070f0358110933869814643")
