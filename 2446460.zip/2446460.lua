-- Lua provided by SkyAPI 
-- Game: ANTONBLAST: One Blast Demo
addappid(2446460)
addappid(2446461, 1, "99c7de1c0c594f592a9b29b8e85951bf4c00ddd34070f0358110933869814643")
