-- Lua provided by RyzenAPI
-- Game: 8350

-- MAIN APPLICATION
addappid(8350)
-- Game: addappid(8350)

-- MAIN APP DEPOTS / PACKAGES
addappid(8351, 1, "de8e483b8f8e390b3df79b27cf2d07dcdab317cb9f2d1f59b075553f5fa9f990")
addappid(8352, 1, "09324a45654b1e84e2278a5be94fc377279a56af7f2f3b18be88ffbca582be16")
