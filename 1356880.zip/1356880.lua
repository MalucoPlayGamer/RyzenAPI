-- Lua provided by RyzenAPI
-- Game: AppID 1356880

-- MAIN APPLICATION
addappid(1356880)
-- Game: addappid(1356880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356881, 1, "899a314faddab5e934d3ad68e250ab4967be4c0a18754d4bbe084190126815c1")
