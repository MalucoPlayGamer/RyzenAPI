-- Lua provided by RyzenAPI
-- Game: Godstrike

-- MAIN APPLICATION
addappid(1476170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476171, 1, "2155a3cdf412b1497be223ccbe8827c974af889dd22b992000d6427f9056c224")
