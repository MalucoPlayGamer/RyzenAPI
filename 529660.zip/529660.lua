-- Lua provided by SkyAPI 
-- Game: Mages of Mystralia
addappid(529660)
addappid(529661, 1, "4661190b202dd7a42d3185c5d3f5e62c82187edee5adf25d90a65b37bb78d277")
addappid(587200, 0, "3d5fc2e37ecd14d162f1b82430a6b90b95b3e3c17f20d4e6af7ba06438978add")
