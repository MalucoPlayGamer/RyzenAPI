-- Lua provided by RyzenAPI
-- Game: Source of Survival Early Access

-- MAIN APPLICATION
addappid(1665600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665601, 1, "f80104198b87cef65e604a22c276b0bc3c01b54a519dde54c818b664ac57d7eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
