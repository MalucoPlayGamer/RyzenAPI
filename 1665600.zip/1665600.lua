-- Lua provided by RyzenAPI
-- Game: Source of Survival Early Access

-- MAIN APPLICATION
addappid(1665600)
-- Game: addappid(1665600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665601, 1, "f80104198b87cef65e604a22c276b0bc3c01b54a519dde54c818b664ac57d7eb")
