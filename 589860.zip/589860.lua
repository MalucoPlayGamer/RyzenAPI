-- Lua provided by RyzenAPI
-- Game: SoulSet

-- MAIN APPLICATION
addappid(589860)

-- MAIN APP DEPOTS / PACKAGES
addappid(589861, 1, "c4cdb29619e7fb23a37e801c9880faf08bdac8b24ef3927a9e52ce7eba66c6c1")
addappid(606100, 0, "d27bb4d80dba9b3d1d884c9743815d4141a1999d821ad699488af0164f5f7b81")
