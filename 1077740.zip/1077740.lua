-- Lua provided by RyzenAPI
-- Game: AppID 1077740

-- MAIN APPLICATION
addappid(1077740)
-- Game: addappid(1077740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077741, 1, "08a892f74c153a39f1902fe11e472d70aad63a279cb5f9383a943179d8aacb07")
