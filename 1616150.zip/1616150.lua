-- Lua provided by RyzenAPI
-- Game: WISH Paradise High Soundtrack

-- MAIN APPLICATION
addappid(1616150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1616151, 1, "096702506349ad2265d252c7ddbeb33d791c99ed5fb697b5823a2f1e9c7e7457")
addappid(1616152, 1, "d5d5c19fbfe3aead4cd7b1ea972fb6942f730451dd1f828cbe93b534eaaa8b36")
