-- Lua provided by RyzenAPI
-- Game: 东方栖霞园 ~ Blue devil in the Belvedere. Demo

-- MAIN APPLICATION
addappid(1402680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402681, 1, "eedd6ffa923990ff5e121920bca444136eab078aabe1acdb71e1afc22729c0a8")
