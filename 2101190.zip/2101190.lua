-- Lua provided by RyzenAPI
-- Game: ONI : Road to be the Mightiest Oni

-- MAIN APPLICATION
addappid(2101190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101191, 1, "8714d5d7eab03149854004eef2f06f701c54f371cfb1fa0b8a5199072530b0ed")

