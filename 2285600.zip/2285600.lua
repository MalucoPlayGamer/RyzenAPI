-- Lua provided by RyzenAPI
-- Game: 未尽行夜

-- MAIN APPLICATION
addappid(2285600)
addappid(2285601)
-- Game: addappid(2285600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285602,0,"2a4aa920d949b4c027ef842836fc935d91b8229dbab252510ffd376caac38ab2")
