-- Lua provided by RyzenAPI
-- Game: Shop Tycoon Soundtrack

-- MAIN APPLICATION
addappid(1456030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456031, 1, "bdd3c91126eb6956ee2bf3656e386f26d0ced2f8352735dcf0d4c726a77dd812")
addappid(1456032, 1, "65cbb87677177a54a32e55bf298c109fed03e316edb79e0c1995d87bcfe8e06a")
