-- Lua provided by RyzenAPI
-- Game: Game: CLOSER - anagnorisis

-- MAIN APPLICATION
addappid(1501160)
-- Game: addappid(1501160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501161, 1, "3e0edfba8534d11127e53bc4b5c732446116a02d7390d2c66a7876ca7755101c")
