-- Lua provided by RyzenAPI
-- Game: Hentai Best Girls

-- MAIN APPLICATION
addappid(1153690)
addappid(1160010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153691, 1, "f1d2997d1a43e018afb18b311371195df51f3254e0b34a5529b8e31c04f56c94")
