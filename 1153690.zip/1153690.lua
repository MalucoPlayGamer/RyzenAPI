-- Lua provided by RyzenAPI
-- Game: AppID 1153690

-- MAIN APPLICATION
addappid(1153690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153691, 1, "f1d2997d1a43e018afb18b311371195df51f3254e0b34a5529b8e31c04f56c94")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1160010)
