-- Lua provided by RyzenAPI
-- Game: 2111980

-- MAIN APPLICATION
addappid(2111980)
-- Game: addappid(2111980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111981, 1, "a686af93bb0f5abed57da4461414152981aae4ebfae5d60d5b6a78117153369c")
