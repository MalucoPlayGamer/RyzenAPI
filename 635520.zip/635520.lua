-- Lua provided by RyzenAPI
-- Game: Phantasmat: The Endless Night Collector's Edition

-- MAIN APPLICATION
addappid(635520)

-- MAIN APP DEPOTS / PACKAGES
addappid(635521,0,"5119e7d59bd3847a355f5891928810a83a9c278562defd90508e673c42e0057f")

