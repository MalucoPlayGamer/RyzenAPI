-- 3319070's Lua and Manifest Created by Hubcap Manifest
-- My  clinical death
-- Created: August 16, 2026 at 07:18:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3319070) -- My  clinical death
-- MAIN APP DEPOTS
addappid(3319071, 1, "b4a7d55742c705e45f1d01d1ee10841d9d28ba25174bfeaf61ba802c2f18e911") -- Depot 3319071
setManifestid(3319071, "7748640549495298867", 294646809)