-- Lua provided by RyzenAPI
-- Game: My  clinical death

-- MAIN APPLICATION
addappid(3319070) -- My  clinical death

-- MAIN APP DEPOTS / PACKAGES
addappid(3319071, 1, "b4a7d55742c705e45f1d01d1ee10841d9d28ba25174bfeaf61ba802c2f18e911") -- Depot 3319071

