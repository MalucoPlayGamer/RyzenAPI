-- Lua provided by RyzenAPI
-- Game: addappid(1350970)

-- MAIN APPLICATION
addappid(1350970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350970,0,"cc5c2c0891aed319d90545a852b239e3b437ee81d0baff9b8af9ad6d1ebda3f4")
