-- Lua provided by RyzenAPI
-- Game: addappid(1894320)

-- MAIN APPLICATION
addappid(1894320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894321, 1, "e2a67d1d178204b4a211e2e94c247ed66ba3b2197dea2b72a4e1e319e1e43f64")
