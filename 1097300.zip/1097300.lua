-- Lua provided by RyzenAPI
-- Game: Ostrofa

-- MAIN APPLICATION
addappid(1097300)
-- Game: addappid(1097300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097304,0,"dbc6951924c96db46ac594eac3d5130f4f5046e0a049fbd34ef73876441404f2")
addappid(1097305,0,"c8be72e82d65cc7c4e30673271b06f62c3d1d6e429a7d5025c693a00f0e94ca4")
