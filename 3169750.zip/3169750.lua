-- Lua provided by RyzenAPI
-- Game: TIME TO STARⅡ偶像之路终极版

-- MAIN APPLICATION
addappid(3169750)
-- Game: addappid(3169750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169751, 1, "51f55b7fb43af5d5c33ec6a9c86c1d4cfbdea7529e7789f4fe312d59a0ec5048")
