-- Lua provided by RyzenAPI
-- Game: Yoshitaka Amano VR Museum

-- MAIN APPLICATION
addappid(1853360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853361, 1, "458bfe3d07625c72cd4eab956f3ec689b9a027c79439c8bb9bb6ea5f33bb9971")
