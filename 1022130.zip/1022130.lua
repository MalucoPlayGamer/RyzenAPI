-- Lua provided by RyzenAPI 
-- Game: AppID 1022130
addappid(1022130)
addappid(1022131, 1, "43571c35a46f11e622b984904dc4050522190b2852a28c0e3ef02a158a541190")
