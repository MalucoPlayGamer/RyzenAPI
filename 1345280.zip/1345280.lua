-- Lua provided by RyzenAPI
-- Game: addappid(1345280)

-- MAIN APPLICATION
addappid(1345280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345281, 1, "59e64fb018b88dd4c50f5770f323dbeca16c2180b12ae25b0071435c1c952697")
