-- Lua provided by RyzenAPI 
-- Game: AppID 2719130
addappid(2719130)
addappid(2719131, 1, "9ef8a0aa60e4b7813e4ac0d322de7a658868f621046215669e4659698898e5a9")
