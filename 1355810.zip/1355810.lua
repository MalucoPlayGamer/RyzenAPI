-- Lua provided by RyzenAPI
-- Game: Game: Hentai beautiful girls 4

-- MAIN APPLICATION
addappid(1355810)
-- Game: addappid(1355810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355811, 1, "e9d76c7f61fd7d0a273e2947f14897482bf739c18e4fac2e7993fa3153a33102")
addappid(1356000, 0, "e61d39a49c0952c95a097ceb1f72a580b585bf2f2c0bf54dc787e3ada6266a95")
