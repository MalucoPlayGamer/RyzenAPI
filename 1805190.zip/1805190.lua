-- Lua provided by RyzenAPI
-- Game: addappid(1805190)

-- MAIN APPLICATION
addappid(1805190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805191, 1, "8ce09e548c47cc920972953f9c48f684ed0c3fd38d8ede6e0d48727cf9516150")
