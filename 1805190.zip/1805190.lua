-- Lua provided by RyzenAPI
-- Game: Galaxity : Korea VR

-- MAIN APPLICATION
addappid(1805190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1805191, 1, "8ce09e548c47cc920972953f9c48f684ed0c3fd38d8ede6e0d48727cf9516150")

