-- Lua provided by RyzenAPI
-- Game: addappid(692840)

-- MAIN APPLICATION
addappid(692840)
addappid(869980)
addappid(869981)
addappid(869982)
addappid(869984)
addappid(870220)

-- MAIN APP DEPOTS / PACKAGES
addappid(692841, 1, "369994d75489c1470cce9292474f5b40810c41732c8bf42e0515d86e2df931fc")
