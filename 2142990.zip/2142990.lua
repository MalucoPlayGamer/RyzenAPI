-- Lua provided by RyzenAPI
-- Game: addappid(2142990)

-- MAIN APPLICATION
addappid(2142990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142991, 1, "7bb79e22fd18c454fe8ca0aeff472f3e5460c5d08b43de947397199f24e93b07")
