-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Drafters Demo

-- MAIN APPLICATION
addappid(2123870)
-- Game: addappid(2123870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123871, 1, "d1be91ec06b6897bc0b0f82faab89408b4b5f093dfc12b583990a6b84da694af")
addappid(2123873, 1, "61e35f71123ffd151913a259be98e1b143440c862b679bea595e2d71c28eed49")
