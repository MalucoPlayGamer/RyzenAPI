-- Lua provided by RyzenAPI
-- Game: Game: Survive Planet Yubglub

-- MAIN APPLICATION
addappid(1869070)
-- Game: addappid(1869070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869071, 1, "7e60ecb89b435d6318d85cf4ed88a32a5ecebd6a487a222f83bc10289ebedf03")
