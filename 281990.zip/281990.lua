-- 281990's Lua and Manifest Created by Hubcap Manifest
-- Stellaris
-- Created: June 15, 2026 at 11:48:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 51
-- Total DLCs: 50 (3 excluded)
-- Shared Depots: 6

-- MAIN APPLICATION
addappid(281990, 1, "9f3e7feb17a97b529e54c128210775b97eddc78321652f0a7dd42b1774fd18bf") -- Stellaris
-- MAIN APP DEPOTS
addappid(281991, 1, "f7e7dc0ebbd8af57b97ebdf6a1c60cab11601c659735dec52b75c2041c253bbd") -- Main
setManifestid(281991, "7758718827201246454", 29455534260)
addappid(281992, 1, "e4875742b695f223ab3bfa079d2b2e33c6785bb1e31b88e82964f1391b63066a") -- Windows
setManifestid(281992, "829294590374068105", 226759755)
addappid(281993, 1, "d91e08fd5eb94b1d5dfe65bc3ff860a28d2142856c6df540c8fcb04e5f358b57") -- OSX
setManifestid(281993, "3770449643676798172", 517780222)
addappid(281994, 1, "40a3fc66b54ac44ad3bc479bddd05655e7a3a444003e9d8792fa8309f7184093") -- Linux
setManifestid(281994, "2878732758080836567", 319011120)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Stellaris Symbols of Domination (AppID: 447680)
addappid(447680)
addappid(447680, 1, "01d10eee648eebfb7b14598ac27e9f2fe08c69218951c65666b6403f76ec4b68") -- Stellaris Symbols of Domination - Stellaris: USS Enterprise (447680) Depot
setManifestid(447680, "3796462871416536945", 77011)
-- Stellaris Sign-up Campaign Bonus (AppID: 447681)
addappid(447681)
addappid(447681, 1, "29362c9059b9629893ffe6ab7b54ea3bcb25c79a8e9356747b7f1cb6cd48782c") -- Stellaris Sign-up Campaign Bonus - Stellaris: USS Voyager (447681) Depot
setManifestid(447681, "4635516424234970299", 77001)
-- Stellaris Digital Artbook (AppID: 447682)
addappid(447682)
addappid(447682, 1, "478f379303fd39b46379f3934eeac323a312c222d288f308f4328faa84a43cc3") -- Stellaris Digital Artbook - Stellaris: SSV Normandy (447682) Depot
setManifestid(447682, "8126759959369925319", 119359244)
-- Stellaris Arachnoid Portrait Pack (AppID: 447683)
addappid(447683)
addappid(447683, 1, "e07ca6dfe1f7d44a3400171c4f4e12464de3ecf0229dc1e22d9871822b56a0c1") -- Stellaris Arachnoid Portrait Pack - Stellaris: Normandy SR-2 (447683) Depot
setManifestid(447683, "6115058309987442461", 77003)
-- Stellaris Digital OST (AppID: 447684)
addappid(447684)
addappid(447684, 1, "89d6f99b01e90e6d02e690862d7eedf309161c03fc0bc4358c8b8adc70e6e359") -- Stellaris Digital OST - Stellaris: Destiny Ascension (447684) Depot
setManifestid(447684, "4984318181401498898", 1161285479)
-- Stellaris Signed High-res Wallpaper (AppID: 447685)
addappid(447685)
addappid(447685, 1, "88d963c939e159f0f2d93aaf3469749e0f336cd30f143a85686da78eb9e9bdd1") -- Stellaris Signed High-res Wallpaper - Stellaris: DS9 (447685) Depot
setManifestid(447685, "5616497098841117414", 5084430)
-- Stellaris Novel by Steven Savile (AppID: 447686)
addappid(447686)
addappid(447686, 1, "067f654a1c296e0a5ab71d6cdb46d63933bd983d08ec28f9601a25156234bdd9") -- Stellaris Novel by Steven Savile - Stellaris: Babylon 5 (447686) Depot
setManifestid(447686, "380104706699965241", 2398034)
-- Stellaris Ringtones (AppID: 447687)
addappid(447687)
addappid(447687, 1, "3f787826d200ce33a6456ef355ae925b18733d56cc04abf3fa4cbc3b2be700e9") -- Stellaris Ringtones - Stellaris: Coriolis (447687) Depot
setManifestid(447687, "8750895669882452148", 1302880)
-- Stellaris Creatures of the Void (AppID: 462720)
addappid(462720)
addappid(462720, 1, "210684f8095d1e4df92e410915e1bd9e83b156b94a2c86c7a460eebfd76d04ba") -- Stellaris Creatures of the Void - Stellaris: Space Station V (462720) Depot
setManifestid(462720, "5938010814972666580", 77025)
-- Stellaris Infinite Frontiers eBook (AppID: 497660)
addappid(497660)
addappid(497660, 1, "459e7efe1251b020dc372643a221ebff07634e8178dad5f2da6c6d98cf52e39d") -- Stellaris Infinite Frontiers eBook - Stellaris: Infinite Frontiers eBook (497660) Depot
setManifestid(497660, "8675625826638210993", 2321437)
-- Stellaris Plantoids Species Pack (AppID: 498870)
addappid(498870)
addappid(498870, 1, "f6a9a5906b514eabc056a3acc46c2faeced3b7633efc2c93610476b0878ad291") -- Stellaris Plantoids Species Pack - Stellaris: Plantoids (498870) Depot
setManifestid(498870, "5289062830139194176", 97319)
-- Stellaris Leviathans Story Pack (AppID: 518910)
addappid(518910)
addappid(518910, 1, "76afa9d8ed0308929d0d908cfa04f50ea3c5d523d4f474ed62b6d5f1b26aa74c") -- Stellaris Leviathans Story Pack - Stellaris: Leviathans Story Pack (518910) Depot
setManifestid(518910, "2771826165032019499", 59068563)
-- Stellaris Utopia (AppID: 553280)
addappid(553280)
addappid(553280, 1, "1b61d5fbaddbeaff663e5b3e9ffbde9d12400b117f5c0ed45bbf0e2aa08e3d3d") -- Stellaris Utopia - Stellaris: Alien Cooking Simulator (553280) Depot
setManifestid(553280, "94231584423973538", 76047634)
-- Stellaris Horizon Signal (AppID: 554350)
addappid(554350)
addappid(554350, 1, "5f56dd0a866a921ad460131939a68cd0362874fc1c074a8fe81f6ba246334bfb") -- Stellaris Horizon Signal - Stellaris: Horizon Signal (554350) Depot
setManifestid(554350, "6329361971126473517", 76984)
-- Stellaris Anniversary Portraits (AppID: 633310)
addappid(633310)
addappid(633310, 1, "01acfb94cc06164fd95aef8aa4dd39460a8b1860d235cd105fec4e88711f8538") -- Stellaris Anniversary Portraits - Stellaris: Blorg Birthday Party Bash (633310) Depot
setManifestid(633310, "3345875144006097969", 104543)
-- Stellaris Synthetic Dawn Story Pack (AppID: 642750)
addappid(642750)
addappid(642750, 1, "868699813b46aa012731439d87f3f0924de1d3f530b13bc8f35b3f3ecc5b1641") -- Stellaris Synthetic Dawn Story Pack - Stellaris: Synthetic Dawn (642750) Depot
setManifestid(642750, "8487770189849309225", 48642898)
-- Stellaris Apocalypse (AppID: 716670)
addappid(716670)
addappid(716670, 1, "74fe5949da9d7b5c70c4ea0bf21533a2a5aebdff4e23ce7b04316e848123713f") -- Stellaris Apocalypse - Pew Pew Peacemaker Pack (716670) Depot
setManifestid(716670, "2874777228579213431", 38026555)
-- Stellaris Humanoids Species Pack (AppID: 756010)
addappid(756010)
addappid(756010, 1, "0eb62d6b508d6fb887a04ccd1eeabdd1b709a5c15145dbda6b05d1e49f2478ee") -- Stellaris Humanoids Species Pack - Stellaris: Humanoids Species Pack (756010) Depot
setManifestid(756010, "7057785433501895820", 85948196)
-- Stellaris Distant Stars Story Pack (AppID: 844810)
addappid(844810)
addappid(844810, 1, "28da49ec9b8c4bdf7d08dc939ee1c30056ee40c3a8ae5f8b9217775a1abc3397") -- Stellaris Distant Stars Story Pack - Stellaris: On the Road Again Pack (844810) Depot
setManifestid(844810, "265938213461916546", 20572316)
-- Stellaris MegaCorp (AppID: 944290)
addappid(944290)
addappid(944290, 1, "3cee1514401df4f5b97ba233e1d180334891bea3c4fd11555fa4ff1c6904460d") -- Stellaris MegaCorp - Stellaris: More Platypi (944290) Depot
setManifestid(944290, "5027959061154273567", 91814524)
-- Stellaris Ancient Relics Story Pack (AppID: 1045980)
addappid(1045980)
addappid(1045980, 1, "0a54b9d6d342067cc9e9aa7ef5718eaa6ceb2eb4f15fc45bad8d2ed87e3a784b") -- Stellaris Ancient Relics Story Pack - Space Unicorn Pack (1045980) Depot
setManifestid(1045980, "6196140321844137812", 32765539)
-- Stellaris Lithoids Species Pack (AppID: 1140000)
addappid(1140000)
addappid(1140000, 1, "96e7ed9014e0bdad5829b21abf4dd870a6fdb1c6e43fd5827f01ce874753edba") -- Stellaris Lithoids Species Pack - Rockstarz Pack (1140000) Depot
setManifestid(1140000, "1707277670014098752", 25466841)
-- Stellaris Federations (AppID: 1140001)
addappid(1140001)
addappid(1140001, 1, "cce69ab58969ddf670853f847134f99af9153e1ac4733cc6499e3394e55723d8") -- Stellaris Federations - Hugbox Pack (1140001) Depot
setManifestid(1140001, "6552287492865536968", 14019696)
-- Stellaris Necroids Species Pack (AppID: 1341520)
addappid(1341520)
addappid(1341520, 1, "c39c85b4fbf86b0342c8b8eaa970add1e471c9590de93bcf8b87f86aeb85cc00") -- Stellaris Necroids Species Pack - Jeff (1341520) Depot
setManifestid(1341520, "3322127761481394644", 24718985)
-- Stellaris Nemesis (AppID: 1522090)
addappid(1522090)
addappid(1522090, 1, "72c347cf4b8dc0353239cba39e00e4dd1db8cf4185b5cee840a3ea94c25c6faf") -- Stellaris Nemesis - Stellaris: Nemesis (1522090) Depot
setManifestid(1522090, "1464825983963181123", 38704237)
-- Stellaris Aquatics Species Pack (AppID: 1749080)
addappid(1749080)
addappid(1749080, 1, "f722c721590152236fbf40c17aae16a1cadd7fa322f71923f7661ca1369f3eb7") -- Stellaris Aquatics Species Pack - Hachibi (1749080) Depot
setManifestid(1749080, "2352410094773288579", 29840672)
-- Stellaris Overlord (AppID: 1889490)
addappid(1889490)
addappid(1889490, 1, "b802bed9a094ed9150c06fa62024c77c973058320c8467a49630d286da40e47e") -- Stellaris Overlord - Depot 1889490
setManifestid(1889490, "1949988533210430480", 101497613)
-- Stellaris Toxoids Species Pack (AppID: 2115770)
addappid(2115770)
addappid(2115770, 1, "fedc5957c4d134dae2911d531a3dceab797095bdd7befc025509e54996016863") -- Stellaris Toxoids Species Pack - Depot 2115770
setManifestid(2115770, "1045801664911037736", 21759586)
-- Stellaris First Contact Story Pack (AppID: 2277860)
addappid(2277860)
addappid(2277860, 1, "ddfa43475c92d94ef82e6487618d43d641185f66bf5e387ed689f99f7acf1ab8") -- Stellaris First Contact Story Pack - Depot 2277860
setManifestid(2277860, "4930317276946265521", 92233)
-- Stellaris Galactic Paragons (AppID: 2380030)
addappid(2380030)
addappid(2380030, 1, "776a224f33c5fc9c5fd5ea7178b6034ffcd074101f356d203df55f57f2206a8f") -- Stellaris Galactic Paragons - Depot 2380030
setManifestid(2380030, "6939619431392031129", 92043)
-- Stellaris Astral Planes (AppID: 2534090)
addappid(2534090)
addappid(2534090, 1, "fa241287f452f70a1c00b82a578571438300be428b19d75f6f51f4b999305603") -- Stellaris Astral Planes - Depot 2534090
setManifestid(2534090, "3656631936342514829", 47152449)
-- Stellaris The Machine Age (AppID: 2840100)
addappid(2840100)
addappid(2840100, 1, "16e0b43a13dfd7e098808c8e7f73d40dd4a61f8bedca7ff3a8d713ea4129078e") -- Stellaris The Machine Age - Depot 2840100
setManifestid(2840100, "5013502338098449837", 102039534)
-- Stellaris Cosmic Storms (AppID: 2863060)
addappid(2863060)
addappid(2863060, 1, "439660ae0dd2b18c4ec7c6f2a6a2d824daa1a5125ddce5b5ce0f1ca14c2840b9") -- Stellaris Cosmic Storms - Depot 2863060
setManifestid(2863060, "8797712741214948916", 89148)
-- Stellaris Grand Archive Story Pack (AppID: 2863080)
addappid(2863080)
addappid(2863080, 1, "dd2337201fdc00d6a7949ca0315d688d284dba7cd25345b13ef6f5ebd833da66") -- Stellaris Grand Archive Story Pack - Depot 2863080
setManifestid(2863080, "8947542081300706521", 32768318)
-- Stellaris Rick the Cube Species Portrait (AppID: 2863180)
addappid(2863180)
addappid(2863180, 1, "22a665adae8ef88c495df237d54e8eb3035a0e711d68e7d12da74d242a1e2e4a") -- Stellaris Rick the Cube Species Portrait - Depot 2863180
setManifestid(2863180, "9052823765448867156", 78011)
-- Stellaris Infernals Species Pack (AppID: 3283220)
addappid(3283220)
addappid(3283220, 1, "87c315bfaa9f935d91135e325b796ddcc14a9d8179a965a7bfac33cd4e489336") -- Stellaris Infernals Species Pack - Depot 3283220
setManifestid(3283220, "4373441752470778623", 39485478)
-- Stellaris BioGenesis (AppID: 3417840)
addappid(3417840)
addappid(3417840, 1, "c017d1c54035b510479749be4c962ef16af0faffb11a8b9f3e243b9986814f6a") -- Stellaris BioGenesis - Depot 3417840
setManifestid(3417840, "8331750570302919154", 89871310)
-- Stellaris Shadows of the Shroud (AppID: 3417850)
addappid(3417850)
addappid(3417850, 1, "74081827e0c06682d458ae444bdbec331220a48ca8b1ca57c68d35da9304ffb0") -- Stellaris Shadows of the Shroud - Depot 3417850
setManifestid(3417850, "8092327340853379843", 75555373)
-- Stellaris Stargazer Species Portrait (AppID: 3417860)
addappid(3417860)
addappid(3417860, 1, "ea43c617350d094f3e4e1bc8f237e397f15d90468eda42799a1563fdca3824c1") -- Stellaris Stargazer Species Portrait - Depot 3417860
setManifestid(3417860, "3240748767659651608", 54472)
-- Vipra the Vapor Species Portrait (AppID: 4241410)
addappid(4241410)
addappid(4241410, 1, "53657c2cf107c24debd9b546fdd8da26650af6fe577171a7da4b3528220474f1") -- Vipra the Vapor Species Portrait - Depot 4241410
setManifestid(4241410, "8704462531518179024", 85917)
-- Stellaris Nomads (AppID: 4241420)
addappid(4241420)
addappid(4241420, 1, "b1316e4a62fec8210e7bb8a0848e599d99bda4e4f5eb50733958d53280b41d7f") -- Stellaris Nomads - Depot 4241420
setManifestid(4241420, "4308526494459266879", 110807753)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(461071) -- Stellaris (Pre-Order) (99330)
addtoken(461071, "14499378624197210244")
addappid(461073) -- Stellaris - Nova (Pre-Order) - Termination 99329
addtoken(461073, "10913968139036982872")
addappid(461461) -- Stellaris - Galaxy (Pre-Order) - Termination 100388
addtoken(461461, "4737354047198272564")
addappid(616190) -- Stellaris Nova Edition Upgrade Pack
addappid(616191) -- Stellaris Galaxy Edition Upgrade Pack
addappid(2729490) -- Stellaris Expansion Subscription
addappid(2863190) -- Stellaris Season 08 - Expansion Pass
addappid(3417870) -- Stellaris Season 09 - Expansion Pass
addappid(4241400) -- Stellaris Season 10
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4241440) -- DLC 4241440 (unreleased)
-- addappid(4241450) -- DLC 4241450 (unreleased)
-- addappid(4355700) -- DLC 4355700 (unreleased)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(447688) -- Depot 447688 (empty depot)