-- Lua provided by RyzenAPI
-- Game: Echo of Combats

-- MAIN APPLICATION
addappid(931070)

-- MAIN APP DEPOTS / PACKAGES
addappid(931071, 1, "a5072dba7ce127b6368d8c3157aeab88f1a5930ca0089ac5106e938d7f601cb5")
