-- Lua provided by RyzenAPI
-- Game: AppID 754350

-- MAIN APPLICATION
addappid(754350)

-- MAIN APP DEPOTS / PACKAGES
addappid(754351, 1, "a3987690dec03bacbb3131fd81ff4d4087728bbda115cfbfeac23fa9eb824ed6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
