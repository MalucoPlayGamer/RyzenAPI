-- Lua provided by RyzenAPI
-- Game: Game: AppID 754350

-- MAIN APPLICATION
addappid(754350)
-- Game: addappid(754350)

-- MAIN APP DEPOTS / PACKAGES
addappid(754351, 1, "a3987690dec03bacbb3131fd81ff4d4087728bbda115cfbfeac23fa9eb824ed6")
