-- Lua provided by RyzenAPI
-- Game: 忍者村大战2

-- MAIN APPLICATION
addappid(754350)
-- Game: addappid(754350)

-- MAIN APP DEPOTS / PACKAGES
addappid(754351, 1, "a3987690dec03bacbb3131fd81ff4d4087728bbda115cfbfeac23fa9eb824ed6")
