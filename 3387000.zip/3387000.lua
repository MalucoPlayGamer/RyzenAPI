-- Lua provided by RyzenAPI
-- Game: Game: Hentai Tales: Sweety Milf

-- MAIN APPLICATION
addappid(3387000)
-- Game: addappid(3387000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3387001, 1, "e15a02664c51c0bbdf6e2e309a46bd96bd826af28e6cc7e03603a7a858504bbd")
