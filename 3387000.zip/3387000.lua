-- Lua provided by RyzenAPI 
-- Game: Hentai Tales: Sweety Milf
addappid(3387000)
addappid(3387001, 1, "e15a02664c51c0bbdf6e2e309a46bd96bd826af28e6cc7e03603a7a858504bbd")
