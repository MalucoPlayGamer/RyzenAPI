-- Lua provided by RyzenAPI
-- Game: Game: New Retro Arcade: Neon

-- MAIN APPLICATION
addappid(465780)
addappid(494570)
-- Game: addappid(465780)

-- MAIN APP DEPOTS / PACKAGES
addappid(465781, 1, "b74ccf2fbf0d5ce99485901ea3efd6f27b335d1bd0064b5f8537fba493333acc")
