-- Lua provided by RyzenAPI
-- Game: New Retro Arcade: Neon

-- MAIN APPLICATION
addappid(465780)
addappid(494570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(465781, 1, "b74ccf2fbf0d5ce99485901ea3efd6f27b335d1bd0064b5f8537fba493333acc")

