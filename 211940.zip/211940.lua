-- Lua provided by RyzenAPI
-- Game: Game: AppID 211940

-- MAIN APPLICATION
addappid(211940)
-- Game: addappid(211940)

-- MAIN APP DEPOTS / PACKAGES
addappid(211941, 1, "09de8f9cf4413daafa8557950c5fd5a3af268d82063fc1fff0ec4953efedb9a9")
addappid(211942, 1, "48f0c7b78119b9787de8a5c2f545e7c52525857603bb6dc43c36d3141fb4abd3")
addappid(211944, 1, "b1a6f366d5fd13de5904aa784def7274040746ae3188e445c67711f57085a203")
