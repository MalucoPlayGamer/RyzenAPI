-- Lua provided by RyzenAPI
-- Game: Table Manners: Physics-Based Dating Game

-- MAIN APPLICATION
addappid(1019450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019451, 1, "3b503684b7825596d457a80bd9823856a0b5542e71b37d79e7cbd2da67f279c1")

