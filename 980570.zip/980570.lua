-- Lua provided by RyzenAPI
-- Game: Thronebreaker: Bonus Content

-- MAIN APPLICATION
addappid(980570)

-- MAIN APP DEPOTS / PACKAGES
addappid(980570,0,"cd107d1b0e1867d44ea7455a700008ab7bd519c3031a74e90cd9929b365760a6")
