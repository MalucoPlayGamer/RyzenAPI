-- Lua provided by RyzenAPI
-- Game: addappid(366700)

-- MAIN APPLICATION
addappid(366700)

-- MAIN APP DEPOTS / PACKAGES
addappid(366701, 1, "1d080e849f03072564ec2e6a6de6cd01c20052ecea9f97be7054c8b4f155966c")
