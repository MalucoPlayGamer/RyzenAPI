-- Lua provided by RyzenAPI
-- Game: addappid(1469540)

-- MAIN APPLICATION
addappid(1469540)
addappid(1469541)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469542,0,"04298d84e54fa5e9d01149d5c58b91504f74965b76c61dd1d355fc08a99028de")
