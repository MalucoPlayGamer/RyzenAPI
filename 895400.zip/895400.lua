-- Lua provided by RyzenAPI
-- Game: addappid(895400)

-- MAIN APPLICATION
addappid(895400)

-- MAIN APP DEPOTS / PACKAGES
addappid(895401, 1, "10e8c6628cb78fe20e8190863a7ce05f1b450c52f48a5820f8f172faf68c65a6")
