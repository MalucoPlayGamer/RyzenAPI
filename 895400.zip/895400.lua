-- Lua provided by SkyAPI 
-- Game: AppID 895400
addappid(895400)
addappid(895401, 1, "10e8c6628cb78fe20e8190863a7ce05f1b450c52f48a5820f8f172faf68c65a6")
