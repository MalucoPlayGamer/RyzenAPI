-- Lua provided by RyzenAPI
-- Game: Deadside

-- MAIN APPLICATION
addappid(1248380) -- Deadside Supporter Pack
addappid(2060120) -- Deadside "Hooligan" Skin Set
addappid(2060140) -- Deadside "Tribal" Skin Set
addappid(2911860) -- Deadside "DragonSkin" Skin Set
addappid(2911870) -- Deadside "Anatomical Atlas" Skin set
addappid(2911880) -- Deadside "Ass on Fire Team" Skin Set
addappid(2911890) -- Deadside "Ghost From The Deep" Skin Set
addappid(3363060) -- "Guerilla" Skin Set
addappid(3363070) -- "Dragonfly" Skin Set
addappid(3363090) -- "Sandstorm" Skin Set
addappid(3363100) -- "Royal flush" Skin Set
addappid(3363110) -- "Beehive" Skin Set
addappid(3363120) -- "Bushranger" Skin Set
addappid(3363130) -- "Salamander" Skin Set
addappid(3363140) -- "Jungle" Skin Set
addappid(3363150) -- Flags Set

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(895400, 1, "9426b19e518a058a301fc12cd67cfba028064b41345c71d269b12b4736113378")
addappid(895401, 1, "10e8c6628cb78fe20e8190863a7ce05f1b450c52f48a5820f8f172faf68c65a6")

