-- Lua provided by RyzenAPI
-- Game: Simplode Suite

-- MAIN APPLICATION
addappid(1242710)
addappid(1264101)
addappid(1264102)
addappid(1264103)
addappid(1264104)
addappid(1264105)
addappid(1264106)
addappid(1264110)
addappid(1264111)
addappid(1264112)
addappid(1264113)
addappid(1264114)
addappid(1291030)
addappid(1291031)
addappid(1291032)
addappid(1291033)
addappid(1291034)
addappid(1291035)
addappid(1291036)
addappid(1291037)
addappid(1291038)
addappid(1403380)
addappid(1404370)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1242711, 1, "991dc459c976019f0de69e24af428efa235952e947055de7afe3944cb0336cdc")
