-- Lua provided by RyzenAPI
-- Game: AppID 1242710

-- MAIN APPLICATION
addappid(1242710)
-- Game: addappid(1242710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242711, 1, "991dc459c976019f0de69e24af428efa235952e947055de7afe3944cb0336cdc")
