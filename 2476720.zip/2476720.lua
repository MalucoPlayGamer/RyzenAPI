-- Lua provided by RyzenAPI 
-- Game: MetaStrike
addappid(2476720)
addappid(2476721, 1, "ec0d14c2b3ae9dd92f35adab012980c7a8f24ff05fc427244166aa78ab1ae0bc")
