-- Lua provided by RyzenAPI
-- Game: MetaStrike

-- MAIN APPLICATION
addappid(2476720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476721, 1, "ec0d14c2b3ae9dd92f35adab012980c7a8f24ff05fc427244166aa78ab1ae0bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
