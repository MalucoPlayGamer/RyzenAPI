-- Lua provided by RyzenAPI
-- Game: Game: Synergy

-- MAIN APPLICATION
addappid(1989070)
-- Game: addappid(1989070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989071, 1, "acc053225619f523280f867bc4314633c93cae4e3852acc9ff63dfb12bc5104a")
addappid(1989072, 1, "cb38de04d4eaa1887862c4ccafec65aa47cc5fb5483caf9708060cb4bdd620fd")
addappid(2975170, 0, "cf405148c78a3ff4b03dae2559706245cc2c3d0d10e6b91b5bd0292f49c71c53")
