-- Lua provided by RyzenAPI
-- Game: 2169790

-- MAIN APPLICATION
addappid(2169790)
-- Game: addappid(2169790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169791, 1, "ac1a0f4f108d1cbc0408fec8610646807a6b7b8799f18b75436ff9a435d1a5e2")
