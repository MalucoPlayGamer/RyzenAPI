-- Lua provided by RyzenAPI
-- Game: Hexa Rhythm

-- MAIN APPLICATION
addappid(2169790)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(2169791, 1, "ac1a0f4f108d1cbc0408fec8610646807a6b7b8799f18b75436ff9a435d1a5e2")

