-- Lua provided by RyzenAPI
-- Game: Soul Land: Awakening World

-- MAIN APPLICATION
addappid(4584110)
