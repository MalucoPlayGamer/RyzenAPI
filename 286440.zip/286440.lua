-- Lua provided by SkyAPI 
-- Game: AppID 286440
addappid(286440)
addappid(286441, 1, "925e8ddaa6117e18ee631cda2b35a9229f94c3e19347c59381238aa0940d99e1")
