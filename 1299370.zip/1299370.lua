-- Lua provided by RyzenAPI
-- Game: Friendship with Benefits

-- MAIN APPLICATION
addappid(1299370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299371, 1, "717bfdc35e6703796fbda6057a790bc11f40b61d38aaa8b280b3f67d71390d0d")
