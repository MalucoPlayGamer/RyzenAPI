-- Lua provided by SkyAPI 
-- Game: Friendship with Benefits
addappid(1299370)
addappid(1299371, 1, "717bfdc35e6703796fbda6057a790bc11f40b61d38aaa8b280b3f67d71390d0d")
