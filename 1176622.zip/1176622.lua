-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Weapon `Traffic Signal`

-- MAIN APPLICATION
addappid(1176622)
-- Game: addappid(1176622)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176622,0,"6cbd3570bba472c3ef219edafc8832ac637563b0e4d600e5b625eb988ffdf2c6")
