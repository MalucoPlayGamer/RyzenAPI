-- Lua provided by RyzenAPI
-- Game: Block Legend

-- MAIN APPLICATION
addappid(602670)

-- MAIN APP DEPOTS / PACKAGES
addappid(602671,0,"ee8f8c721ebb1f032183402d40cd1a42d9ca6fcba61e9854185deb22ee9072d2")

