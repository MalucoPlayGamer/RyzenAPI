-- Lua provided by RyzenAPI
-- Game: Fleshcult

-- MAIN APPLICATION
addappid(1418720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418721, 1, "bee737e00cfdbeb07b203f9a1c128df6e695c50219c97e45dd28dbdaf7767695")

