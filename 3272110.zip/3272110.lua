-- Lua provided by RyzenAPI
-- Game: Game: AppID 3272110

-- MAIN APPLICATION
addappid(3272110)
-- Game: addappid(3272110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272111, 1, "50f934f86bb0909d4e11f77e3926fd54320d82ee2bcf80e1d602fb2eb882201f")
