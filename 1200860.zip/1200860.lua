-- Lua provided by RyzenAPI
-- Game: Game: AppID 1200860

-- MAIN APPLICATION
addappid(1200860)
-- Game: addappid(1200860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200861, 1, "f4cad2cacfac7a375ca0705ac024cdda24e049650c2e69cf68d8a908ced42fb8")
addappid(1200862, 1, "5a51ca82c0392ea40f965267c38bccf59ff130ddcf854b9daf63a27b44c3ffa9")
