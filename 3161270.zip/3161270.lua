-- Lua provided by RyzenAPI
-- Game: Tlatoani: Aztec Cities

-- MAIN APPLICATION
addappid(3161270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161271, 1, "99113437a694b959b1cd3c6664992d2bf4b3adf01d6c43962757a00ba09e3ab6")
