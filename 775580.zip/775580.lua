-- Lua provided by RyzenAPI 
-- Game: ITTA
addappid(775580)
addappid(775581, 1, "b8bae56580959a269003d044863c75e7477670d3b6e158eb4eb984b0629b76c0")
