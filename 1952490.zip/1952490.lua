-- Lua provided by RyzenAPI
-- Game: Alice | 愛莉澄

-- MAIN APPLICATION
addappid(1952490)
-- Game: addappid(1952490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952491, 1, "15665f03102e262ae0e159a6440a58b61c8c2f94bcd32ec61561693b5385b20d")
