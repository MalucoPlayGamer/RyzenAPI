-- Lua provided by RyzenAPI
-- Game: Chinese Ink Painting Puzzle & Creator / 國畫拼圖創作家

-- MAIN APPLICATION
addappid(767200)

-- MAIN APP DEPOTS / PACKAGES
addappid(767201, 1, "bc5598a5028d0199286d362fc37907a2d4a0ac169d4ec95baa6bf94288a5b088")
