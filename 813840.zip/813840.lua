-- Lua provided by RyzenAPI
-- Game: 813840

-- MAIN APPLICATION
addappid(813840)

-- MAIN APP DEPOTS / PACKAGES
addappid(813840,0,"2e914f073a9a56ca520a68fd74e6fcc97f53d3d0dd2449dba4aa3d6b174cad0c")

