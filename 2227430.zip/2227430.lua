-- Lua provided by RyzenAPI
-- Game: Game: 東方謎縁塔 ~ Forsaken Labyrinth. Demo

-- MAIN APPLICATION
addappid(2227430)
-- Game: addappid(2227430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227431, 1, "e93a7a42eff88288daad791c5e89ce94b0e5296f0487553911ef1375a5d4a78f")
