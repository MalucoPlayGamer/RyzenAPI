-- Lua provided by RyzenAPI
-- Game: Malody V

-- MAIN APPLICATION
addappid(1512940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512941, 1, "029c48acbc3b14085c811abd6bfb87dd070cfc070378992e738f4aae033c7296")

