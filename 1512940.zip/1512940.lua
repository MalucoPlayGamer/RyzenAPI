-- Lua provided by SkyAPI 
-- Game: AppID 1512940
addappid(1512940)
addappid(1512941, 1, "029c48acbc3b14085c811abd6bfb87dd070cfc070378992e738f4aae033c7296")
