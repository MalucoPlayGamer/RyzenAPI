-- Lua provided by RyzenAPI
-- Game: Bad Rats Show

-- MAIN APPLICATION
addappid(393200)

-- MAIN APP DEPOTS / PACKAGES
addappid(393201, 1, "9cbbc6bbc8f5e63c6ffaa273b2e38585f16fac99b6da3ed9e9958845325b6624")
