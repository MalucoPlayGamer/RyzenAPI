-- Lua provided by RyzenAPI
-- Game: Game: AppID 1549890

-- MAIN APPLICATION
addappid(1549890)
-- Game: addappid(1549890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549891, 1, "a6830e2dc13e18b410fc25eb1b32727a0fe0126230435279553f7acb44f70e64")
