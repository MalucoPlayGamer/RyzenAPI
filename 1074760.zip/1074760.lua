-- Lua provided by RyzenAPI
-- Game: 1074760

-- MAIN APPLICATION
addappid(1074760)
-- Game: addappid(1074760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074761, 1, "ee8db0c49deff882a016eefd178c5c6c60036071960c2f6f6b79e813941bc3b5")
