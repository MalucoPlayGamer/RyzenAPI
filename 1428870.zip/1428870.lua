-- Lua provided by RyzenAPI
-- Game: Grapple

-- MAIN APPLICATION
addappid(1428870)
-- Game: addappid(1428870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428872,0,"1511745260929e476b5530c34137086ae280e961a6537acb4ef08da35489cc25")
