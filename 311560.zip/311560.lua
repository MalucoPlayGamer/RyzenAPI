-- Lua provided by RyzenAPI
-- Game: AppID 311560

-- MAIN APPLICATION
addappid(311560)
addappid(339030)
addappid(339031)
addappid(339032)
addappid(339033)
addappid(339034)
addappid(352920)
addappid(352921)
addappid(352922)
addappid(352923)
addappid(352924)
addappid(352925)
addappid(352926)
addappid(352927)
addappid(352928)
addappid(352940)
addappid(352941)
addappid(352942)
addappid(352943)
addappid(352944)

-- MAIN APP DEPOTS / PACKAGES
addappid(311561, 1, "42bdf94957d5fccbb06dae4e835998ffaacee0eb6e08ffbbd77ad7d0be282380")
addappid(311562, 1, "2bcc03afbf14f7a2d4121ef3675f20cf48d8038648a0e3187702620bbcdac0cb")
addappid(311563, 1, "01ba3fc561b0e872c5abc7c280cc156824389c2cf677290c267ccf412a2cc2dd")
addappid(311564, 1, "b49726ea1d301607f3707bf48d31d1a5a10be3344879869e99b04544be782e53")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
