-- Lua provided by RyzenAPI
-- Game: Game: SWORDY

-- MAIN APPLICATION
addappid(467900)
-- Game: addappid(467900)

-- MAIN APP DEPOTS / PACKAGES
addappid(467901, 1, "59a538fa29f042126e2f191901691e376c9a150705b0a1c16821c8b84e07cd3a")
addappid(467902, 1, "0ad1165b7840ec63d58df72f290a34dd630e1feac0b157ed8e596f6ee21ba016")
