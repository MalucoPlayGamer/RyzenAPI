-- Lua provided by SkyAPI 
-- Game: Momo is Here
addappid(1845280)
addappid(1845281, 1, "a5484800a1d3f05e1c7ea406b470e2192d4fe5cd8d7ef1981a3c811af881aa5a")
