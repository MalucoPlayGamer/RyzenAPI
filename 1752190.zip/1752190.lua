-- Lua provided by RyzenAPI
-- Game: Cubicus

-- MAIN APPLICATION
addappid(1752190)
-- Game: addappid(1752190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752191, 1, "117249850f40f7c19e862a900fecc02bfc821798e613232fe687ca88b42848e5")
