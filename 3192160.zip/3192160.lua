-- Lua provided by RyzenAPI
-- Game: addappid(3192160)

-- MAIN APPLICATION
addappid(3192160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192161, 1, "90a59d37b59bcba1e113becf873d4e730197381067480ba7945ea67d5e0ab75d")
