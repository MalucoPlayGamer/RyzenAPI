-- Lua provided by RyzenAPI
-- Game: Hotel Overloop

-- MAIN APPLICATION
addappid(2955200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2955201, 1, "9252d0ddf3e7bd5f6ba0c30c8de63c476dcf25837465dbefe093a04e3b3d881f")

