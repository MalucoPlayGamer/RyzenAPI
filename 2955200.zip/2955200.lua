-- Lua provided by RyzenAPI
-- Game: Hotel Overloop

-- MAIN APPLICATION
addappid(2955200)
-- Game: addappid(2955200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955201, 1, "9252d0ddf3e7bd5f6ba0c30c8de63c476dcf25837465dbefe093a04e3b3d881f")
