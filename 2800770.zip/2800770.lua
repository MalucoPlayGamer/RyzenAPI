-- Lua provided by RyzenAPI
-- Game: addappid(2800770)

-- MAIN APPLICATION
addappid(2800770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800771, 1, "790192e5483564356d5cf8cf907c60abbf7d242b2f4afb5c5e901a46d6f93577")
