-- Lua provided by RyzenAPI
-- Game: Clickable Coffee Shop

-- MAIN APPLICATION
addappid(1103920)
-- Game: addappid(1103920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103921, 1, "911cb0d35c80cb528089e89ebf56a2c83f8b7b76ea35d81f2dca47ea3cd18eab")
