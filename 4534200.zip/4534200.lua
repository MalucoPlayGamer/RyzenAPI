-- 4534200's Lua and Manifest Created by Hubcap Manifest
-- Incremental Retro Racing
-- Created: July 28, 2026 at 14:08:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4534200, 1, "99b6788e78929505dc4ca3f288e728840756c26ed9c9fa39465054ecab050b26") -- Incremental Retro Racing
-- MAIN APP DEPOTS
addappid(4534201, 1, "7fdd460ac69c60b37b099b300cfb118e519bacb8fba6ef0bd2ac6d062c7ad2f0") -- Depot 4534201
setManifestid(4534201, "9148098155199191161", 511515372)
addappid(4534202, 1, "00c9887bb65ed7a03bff325e1d4111d5a45953fd08f7effafb5404be44dd9299") -- Depot 4534202
setManifestid(4534202, "4348214378152458739", 693921158)
addappid(4534203, 1, "58de9e325392ed0dcde57d2cbd314973c446ed9d0986d39d670f498c2b36370a") -- Depot 4534203
setManifestid(4534203, "8128981742009420628", 1366196859)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)