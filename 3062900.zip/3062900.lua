-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3062900)
-- Game: addappid(3062900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062900,0,"52b5cc4bfd6e98763aaeb91b85e8fbb7e16db8d0f940ab42d86dbeb5eee9bbb3")
