-- Lua provided by RyzenAPI
-- Game: Game: Aeon Command

-- MAIN APPLICATION
addappid(304670)
-- Game: addappid(304670)

-- MAIN APP DEPOTS / PACKAGES
addappid(304671, 1, "1ed33759ecaa751db49957d47620e5971f2bf5edc3e511a56d987ee58c174d06")
addappid(304672, 1, "7b2d83082f12a27bf352b152065ca962a4dfd133c88f30ee1fd63eb7ea4400c9")
addappid(304673, 1, "928e707923db2c5a3090d9974cdc7b2438bafce57140d8c693a09af9a7d12010")
addappid(304674, 1, "da457c9055efb1b1ea27bf7c17f83ea2447ec4620d76f858efe09e794f012da2")
