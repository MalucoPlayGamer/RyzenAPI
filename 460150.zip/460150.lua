-- Lua provided by RyzenAPI
-- Game: 460150

-- MAIN APPLICATION
addappid(460150)
addappid(460151)
addappid(460152)
addappid(460153)
addappid(460154)

-- MAIN APP DEPOTS / PACKAGES
addappid(460260,0,"d73097016eb9ea0620d358678c715446a0fd14c2cddd66ef27a35e9c0a2a6439")
