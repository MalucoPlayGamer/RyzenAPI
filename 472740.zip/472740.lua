-- Lua provided by SkyAPI 
-- Game: AppID 472740
addappid(472740)
addappid(472741, 1, "594bcb96143809f295739fdd4972541fd504435b1484016353bc42a83d665612")
