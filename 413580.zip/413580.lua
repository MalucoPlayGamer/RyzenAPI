-- Lua provided by RyzenAPI
-- Game: Reverse x Reverse

-- MAIN APPLICATION
addappid(413580)
-- Game: addappid(413580)

-- MAIN APP DEPOTS / PACKAGES
addappid(413581, 1, "d87560e8763864cbc3dd865b797ada12ff6cf5f2f9e3d03a6968bc3bb86d86b6")
addappid(413582, 1, "d95c2c3965407038a78b7b2e2b147b90c550d288365f6d8e01b7822045f19813")
