-- Lua provided by RyzenAPI
-- Game: Reverse x Reverse

-- MAIN APPLICATION
addappid(413580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(413581, 1, "d87560e8763864cbc3dd865b797ada12ff6cf5f2f9e3d03a6968bc3bb86d86b6")
addappid(413582, 1, "d95c2c3965407038a78b7b2e2b147b90c550d288365f6d8e01b7822045f19813")

