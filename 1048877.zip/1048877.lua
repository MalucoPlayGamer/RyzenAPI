-- Lua provided by RyzenAPI
-- Game: addappid(1048877)

-- MAIN APPLICATION
addappid(1048877)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048877,0,"74705c9bacd6f4d6d940c18ca54a8d350cfce9f98fca37128e4eb3c0a20891ee")
