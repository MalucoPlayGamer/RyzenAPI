-- Lua provided by RyzenAPI
-- Game: Without Within 2

-- MAIN APPLICATION
addappid(398980)
addappid(399021)

-- MAIN APP DEPOTS / PACKAGES
addappid(398981, 1, "95f66cfc9bb350f57f29591cc0e631d9c2a16d8fc7b1769ffe547b0c865b4f23")
addappid(398982, 1, "7accb5bb300542555b1b0aa1a440055f1f4d2f48bdf3589132d5a2bfdf8b9c6b")
addappid(398983, 1, "00f6d8166b4e49768bb9c3fcdc764a2d33173e08239c166a163a67404f599b75")

