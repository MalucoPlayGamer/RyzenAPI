-- Lua provided by RyzenAPI
-- Game: Alveole

-- MAIN APPLICATION
addappid(988930)
-- Game: addappid(988930)

-- MAIN APP DEPOTS / PACKAGES
addappid(988931, 1, "6f54c963fb483b9c270c5efb018adbd7b7e644c3b238ae4686c74e4a6c207f78")
