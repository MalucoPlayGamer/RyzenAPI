-- Lua provided by RyzenAPI
-- Game: Alveole

-- MAIN APPLICATION
addappid(988930)

-- MAIN APP DEPOTS / PACKAGES
addappid(988931, 1, "6f54c963fb483b9c270c5efb018adbd7b7e644c3b238ae4686c74e4a6c207f78")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
