-- Lua provided by RyzenAPI
-- Game: Dwarves  & Dungeons

-- MAIN APPLICATION
addappid(1457690)
-- Game: addappid(1457690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457691, 1, "b1e126dbb414518d645c020bc3e5cfd8b824b26cdf562588b7626626ffb20329")
