-- Lua provided by RyzenAPI
-- Game: Ori and the Blind Forest (Original Soundtrack)

-- MAIN APPLICATION
addappid(465980)

-- MAIN APP DEPOTS / PACKAGES
addappid(465980,0,"3ebeb57fc575aba316d19e27a787813044dddfb95ee036dab06fdf4f454550c1")

