-- Lua provided by RyzenAPI
-- Game: AppID 675110

-- MAIN APPLICATION
addappid(675110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(675111, 1, "8e788e4f5ba986ed07064352ca6df9343df378f72c2dd29d1f42ecfbf51aebc1")

