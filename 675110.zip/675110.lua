-- Lua provided by RyzenAPI
-- Game: AppID 675110

-- MAIN APPLICATION
addappid(675110)
-- Game: addappid(675110)

-- MAIN APP DEPOTS / PACKAGES
addappid(675111, 1, "8e788e4f5ba986ed07064352ca6df9343df378f72c2dd29d1f42ecfbf51aebc1")
