-- Lua provided by RyzenAPI
-- Game: 785660

-- MAIN APPLICATION
addappid(785660)
-- Game: addappid(785660)

-- MAIN APP DEPOTS / PACKAGES
addappid(785661, 1, "30a292d52a7193e71b615df42a7eceb831aa7cc620fe533bc6e55453f7963b29")
