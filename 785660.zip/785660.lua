-- Lua provided by RyzenAPI
-- Game: Subway Simulator

-- MAIN APPLICATION
addappid(785660)
addappid(829580)
addappid(829581)

-- MAIN APP DEPOTS / PACKAGES
addappid(785661, 1, "30a292d52a7193e71b615df42a7eceb831aa7cc620fe533bc6e55453f7963b29")

