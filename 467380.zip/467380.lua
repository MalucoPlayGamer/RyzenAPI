-- Lua provided by RyzenAPI
-- Game: Khimera: Destroy All Monster Girls

-- MAIN APPLICATION
addappid(467380)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(485280)
