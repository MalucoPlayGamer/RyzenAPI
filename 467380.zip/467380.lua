-- Lua provided by RyzenAPI
-- Game: Khimera: Destroy All Monster Girls

-- MAIN APPLICATION
addappid(467380)

