-- Lua provided by RyzenAPI
-- Game: Thank Goodness You're Here! Demo

-- MAIN APPLICATION
addappid(2902610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902611, 1, "81232c24aa2b4b818e31e20991657bf855499e9648f14cd5cf72393ea89772d3")

