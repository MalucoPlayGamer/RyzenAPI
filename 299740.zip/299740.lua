-- Lua provided by RyzenAPI
-- Game: addappid(299740)

-- MAIN APPLICATION
addappid(299740)
addappid(959470)

-- MAIN APP DEPOTS / PACKAGES
addappid(299741, 1, "374e2440029e9bcf547aaa4006a9bde588a14abf387104899ad1f756098b1df1")
