-- Lua provided by RyzenAPI
-- Game: 3665900

-- MAIN APPLICATION
addappid(3665900)
-- Game: addappid(3665900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3665901, 1, "2280997bf0f1ae7b876c67f97d7d8cd4fc6db1321716264b62f6d8b804d1d1d7")
