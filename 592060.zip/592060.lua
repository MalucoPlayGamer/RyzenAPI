-- Lua provided by RyzenAPI
-- Game: Game: Sons of Triskelion

-- MAIN APPLICATION
addappid(592060)
-- Game: addappid(592060)

-- MAIN APP DEPOTS / PACKAGES
addappid(592061, 1, "4d590bc0ca6f3fea77d0c17b53eafebcb1892221355bb8c3fb05374b8e4b861f")
