-- Lua provided by RyzenAPI
-- Game: Golf On The Moon Demo

-- MAIN APPLICATION
addappid(2234970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234971, 1, "4f762eaeacfb853ec1033a310b777500d1391a096f4fa6f6910c3f3cc95b8717")

