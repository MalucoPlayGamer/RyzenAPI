-- Lua provided by RyzenAPI
-- Game: Perfect World M

-- MAIN APPLICATION
addappid(2715240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715241, 1, "f663b6934346882624321ed8cbf1e12451a6dcfc41b4c34c5ab20ee3b360adf1")

