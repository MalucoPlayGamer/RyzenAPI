-- Lua provided by RyzenAPI
-- Game: AppID 619730

-- MAIN APPLICATION
addappid(619730)

-- MAIN APP DEPOTS / PACKAGES
addappid(619731, 1, "d95aeb4e6033bcae6a798ff8b3e0fb40f760e8802e4a3e31b04946e2cf299df7")
