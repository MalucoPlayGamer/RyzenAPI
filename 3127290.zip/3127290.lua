-- Lua provided by RyzenAPI
-- Game: Tiny Duck Hunt 3D

-- MAIN APPLICATION
addappid(3127290)
-- Game: addappid(3127290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127292,0,"eb61f4b3894f18cb8f4c33245ebb7c87653536f39fa373231a534b545e3b4451")
