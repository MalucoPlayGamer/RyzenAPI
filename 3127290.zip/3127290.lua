-- Lua provided by RyzenAPI
-- Game: Tiny Duck Hunt 3D

-- MAIN APPLICATION
addappid(3127290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127292,0,"eb61f4b3894f18cb8f4c33245ebb7c87653536f39fa373231a534b545e3b4451")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
