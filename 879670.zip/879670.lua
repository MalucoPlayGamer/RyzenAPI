-- Lua provided by SkyAPI 
-- Game: Battle Simulator
addappid(879670)
addappid(879671, 1, "5a3294fd1e464068f171054b1f5ae82e91a6b89e114c651f883c2d4deee3545b")
