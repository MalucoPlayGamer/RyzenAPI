-- Lua provided by RyzenAPI
-- Game: Battle Simulator

-- MAIN APPLICATION
addappid(879670)
-- Game: addappid(879670)

-- MAIN APP DEPOTS / PACKAGES
addappid(879671, 1, "5a3294fd1e464068f171054b1f5ae82e91a6b89e114c651f883c2d4deee3545b")
