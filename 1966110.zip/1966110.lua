-- Lua provided by RyzenAPI
-- Game: Game: Greed

-- MAIN APPLICATION
addappid(1966110)
-- Game: addappid(1966110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966111, 1, "6f04c401d5fa5d623b8e97585abfbedd1dff54a1455113341c6786a7bb22b15d")
