-- Lua provided by RyzenAPI
-- Game: Greed

-- MAIN APPLICATION
addappid(1966110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966111, 1, "6f04c401d5fa5d623b8e97585abfbedd1dff54a1455113341c6786a7bb22b15d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
