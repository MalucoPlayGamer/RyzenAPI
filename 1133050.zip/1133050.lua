-- Lua provided by RyzenAPI
-- Game: AppID 1133050

-- MAIN APPLICATION
addappid(1133050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1133051, 1, "01177a5dbfd01d118c863f6cfb1f9572dce383d044ee660204b02797713bbe6a")

