-- Lua provided by RyzenAPI
-- Game: Game: AppID 1133050

-- MAIN APPLICATION
addappid(1133050)
-- Game: addappid(1133050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133051, 1, "01177a5dbfd01d118c863f6cfb1f9572dce383d044ee660204b02797713bbe6a")
