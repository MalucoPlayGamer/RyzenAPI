-- Lua provided by RyzenAPI
-- Game: Game: Frog Detective 2: The Case of the Invisible Wizard

-- MAIN APPLICATION
addappid(1047220)
-- Game: addappid(1047220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047221, 1, "46ca23972e12bdf1ae084f71c0ba37370ada0980d1ed95de4241a9d422d7d6c1")
