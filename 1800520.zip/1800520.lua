-- Lua provided by RyzenAPI
-- Game: Wonky Wizard

-- MAIN APPLICATION
addappid(1800520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1800521, 1, "3a63347f4873ea21d3caac64a2b46edccd03391ab5e2515e92cd699a62bbb0ff")
addappid(1800522, 1, "9a3274e5e77adafe8ba7f7f193e71b157e398309ce5a26f13061f384fa3269d1")

