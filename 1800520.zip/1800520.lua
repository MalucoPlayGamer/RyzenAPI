-- Lua provided by RyzenAPI
-- Game: addappid(1800520)

-- MAIN APPLICATION
addappid(1800520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800521, 1, "3a63347f4873ea21d3caac64a2b46edccd03391ab5e2515e92cd699a62bbb0ff")
addappid(1800522, 1, "9a3274e5e77adafe8ba7f7f193e71b157e398309ce5a26f13061f384fa3269d1")
