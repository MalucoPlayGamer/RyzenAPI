-- Lua provided by RyzenAPI
-- Game: 2104600

-- MAIN APPLICATION
addappid(2104600)
-- Game: addappid(2104600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2104601, 1, "efa36dee8abb195b8ecb81cf8584f4228aca7d64482487d700f68c437955fa66")
