-- Lua provided by SkyAPI 
-- Game: FlowScape
addappid(1043390)
addappid(1043391, 1, "70e925a2533164259d26c201d11c5c4dbf64501f22a62bf7ce17a9ad3b55adaf")
