-- Lua provided by RyzenAPI
-- Game: FlowScape

-- MAIN APPLICATION
addappid(1043390)
-- Game: addappid(1043390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043391, 1, "70e925a2533164259d26c201d11c5c4dbf64501f22a62bf7ce17a9ad3b55adaf")
