-- Lua provided by RyzenAPI
-- Game: Beat Saber - Steppenwolf - "Born To Be Wild"

-- MAIN APPLICATION
addappid(2233130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233130,0,"3e61c3f1f097bec24d8be56a0cdd63beddb2b2eda60b1f8e7de7ff53a6f9b0d7")

