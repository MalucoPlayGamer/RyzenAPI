-- Lua provided by RyzenAPI 
-- Game: Knockout Master
addappid(2470860)
addappid(2470861, 1, "56aa7d21970278e132f55d2322a35f9cf613e485ff6f4e176bae2e7b831b498d")
