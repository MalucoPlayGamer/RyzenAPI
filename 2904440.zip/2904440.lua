-- Lua provided by RyzenAPI
-- Game: addappid(2904440)

-- MAIN APPLICATION
addappid(2904440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904441, 1, "bf578949b02835bd59bf73ff7ce247483d6b794f628e988815abcc7101ca996f")
