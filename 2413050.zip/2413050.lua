-- Lua provided by RyzenAPI
-- Game: Retrowave World

-- MAIN APPLICATION
addappid(2413050)
addappid(3000540)
addappid(3080320)
addappid(3262050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413051, 1, "bbe1dc17ed7b5b851678eada71dc5a0d0b9a64b0140263d12914ed92d30d5869")

