-- Lua provided by SkyAPI 
-- Game: Tree Simulator 2023
addappid(1916970)
addappid(1916971, 1, "25de8d676672e15a64e14e9d63c9cda85cbdcba17dfe302ccf6df143aa3fcdbe")
