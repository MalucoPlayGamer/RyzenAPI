-- Lua provided by RyzenAPI
-- Game: Tree Simulator 2023

-- MAIN APPLICATION
addappid(1916970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916971, 1, "25de8d676672e15a64e14e9d63c9cda85cbdcba17dfe302ccf6df143aa3fcdbe")
