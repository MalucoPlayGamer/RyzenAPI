-- Lua provided by RyzenAPI
-- Game: Neon Chrome

-- MAIN APPLICATION
addappid(428750)
addappid(568850)

-- MAIN APP DEPOTS / PACKAGES
addappid(428751, 1, "36a7de627692cd960ef56153846ea243de884e56de4ca6fb0cf5a90a753166fe")
addappid(428752, 1, "d02825259cc9d4411260356a1523294175fcf5e07d35ef241dbda3d6457291e3")
addappid(428753, 1, "7f3395501fcf9ad0b8f550e35ef6e26665f50de9ce6955938bc6d67dfcf91489")
addappid(453250, 0, "03f46c5f0ee0256f39f871c59f92c88cbd45d72d76881b45003d85517a85da1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
