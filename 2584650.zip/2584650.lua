-- Lua provided by RyzenAPI
-- Game: addappid(2584650)

-- MAIN APPLICATION
addappid(2584650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584651, 1, "724272ea155b938e60455e859b6b1dc0ed567508943b0e047d0e077bcf9fec16")
