-- Lua provided by RyzenAPI
-- Game: Ahros: One warrior chronicle

-- MAIN APPLICATION
addappid(518110)

-- MAIN APP DEPOTS / PACKAGES
addappid(518111,0,"265465fa4e0088554272ea660c3252da9e371a53229bdeadafe0289e9785dec4")

