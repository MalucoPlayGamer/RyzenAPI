-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS: ORIGINS - Protagonist's Costume "Nameless Warrior Garb"

-- MAIN APPLICATION
addappid(3319840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319840,0,"e3daad5e8a9c79487f8ea299232fe177f346a535339aced3dbb44b4123959142")
addtoken(3319840,"8824614407371289400")

