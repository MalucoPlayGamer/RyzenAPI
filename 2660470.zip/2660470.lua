-- Lua provided by RyzenAPI
-- Game: 2660470

-- MAIN APPLICATION
addappid(2660470)
-- Game: addappid(2660470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660471, 1, "7400391510526d05b914bf6e86cb5236fec4f8011d772ee20b0b37ce1bd69e24")
