-- Lua provided by RyzenAPI
-- Game: Game: Dimenshift

-- MAIN APPLICATION
addappid(2903100)
-- Game: addappid(2903100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903101, 1, "12f7cf7ea7efc12ec8fbaba3763fa71ce6197f46e876ee0e9a6d563c64df5fc2")
