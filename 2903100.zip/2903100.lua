-- Lua provided by SkyAPI 
-- Game: Dimenshift
addappid(2903100)
addappid(2903101, 1, "12f7cf7ea7efc12ec8fbaba3763fa71ce6197f46e876ee0e9a6d563c64df5fc2")
