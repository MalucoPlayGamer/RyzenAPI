-- Lua provided by SkyAPI 
-- Game: DesktopMMD4:Born to Dance
addappid(1968650)
addappid(1968651, 1, "a3b3fcc7a75fe202958217e583ffc257abbdafac84ccade0a005d6aa27e17264")
