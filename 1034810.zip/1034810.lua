-- Lua provided by RyzenAPI
-- Game: Pax Romana: Romulus

-- MAIN APPLICATION
addappid(1034810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034811, 1, "b43f95e3f18ae6d1776a93b0b68e71186f765dadd19efb8de77103446945e248")
addappid(1193440, 0, "fa7fe36e0711653ecc72584072f0bd3fac8afbb760f4823cec71119e8dd020e9")
