-- 4588700's Lua and Manifest Created by Hubcap Manifest
-- Monster Girls: You Can't Say No 🔞
-- Created: August 15, 2026 at 23:03:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4588700) -- Monster Girls: You Can't Say No 🔞
-- MAIN APP DEPOTS
addappid(4588701, 1, "39d3ce7afbfbac82a7a7fb7a12f9cf32ca44c3c0aa2fc298f16aba4259e47f48") -- Depot 4588701
setManifestid(4588701, "8261394324198423215", 7313673520)
addappid(4588702, 1, "dd40ac300073e1d01945bbd7cab7b9cbbb59fd7f7768cc3c0e21b216566a4042") -- Depot 4588702
setManifestid(4588702, "8577466386383605165", 7330535720)
addappid(4588703, 1, "c20f0e48a640f1d07759ad054c8b8000ce569e1be196288d65db95f0cad4a73d") -- Depot 4588703
setManifestid(4588703, "632559694938030529", 7310579632)
-- DLCS WITH DEDICATED DEPOTS
-- Monster Girls You Cant Say No - Wallpapers (AppID: 5054000)
addappid(5054000)
addappid(5054000, 1, "11998b2b4b69d8901039b2d2053942713338a338ce1d736583747e3c174f7f41") -- Monster Girls You Cant Say No - Wallpapers - Depot 5054000
setManifestid(5054000, "1920668810363759483", 219260698)