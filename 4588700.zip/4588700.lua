-- Lua provided by RyzenAPI
-- Game: Monster Girls: You Can't Say No 🔞

-- MAIN APPLICATION
addappid(4588700) -- Monster Girls: You Can't Say No 🔞
addappid(5054000)

-- MAIN APP DEPOTS / PACKAGES
addappid(4588701, 1, "39d3ce7afbfbac82a7a7fb7a12f9cf32ca44c3c0aa2fc298f16aba4259e47f48") -- Depot 4588701
addappid(4588702, 1, "dd40ac300073e1d01945bbd7cab7b9cbbb59fd7f7768cc3c0e21b216566a4042") -- Depot 4588702
addappid(4588703, 1, "c20f0e48a640f1d07759ad054c8b8000ce569e1be196288d65db95f0cad4a73d") -- Depot 4588703
addappid(5054000, 1, "11998b2b4b69d8901039b2d2053942713338a338ce1d736583747e3c174f7f41") -- Monster Girls You Cant Say No - Wallpapers - Depot 5054000

