-- Lua provided by RyzenAPI
-- Game: Game: AppID 3291690

-- MAIN APPLICATION
addappid(3291690)
-- Game: addappid(3291690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291691, 1, "ba9ead9e46f7aeb7ddad7bb8cca1686e84f7d95bfc2520b100803144749e15db")
