-- Lua provided by RyzenAPI
-- Game: Dinosaur Hunt Puzzle

-- MAIN APPLICATION
addappid(874400)

-- MAIN APP DEPOTS / PACKAGES
addappid(874401, 1, "7fa9b48caef000df5e7ffc65eadb71cd4e8254867db6af2b5e737a951c2852f1")
addappid(874402, 1, "70c9629f30366bc1a30f79c5fcb486fbf0e320449551bc59e2ebdf2f4561ee8b")
addappid(874403, 1, "693f4fcaf589afde82e38e490a03c6e8c258c1714ac70b3eb8a6890964249a37")
addappid(874404, 1, "efc3f87c6cec59ce3cf2b249ab7eac738829b521f3d5b8109be306ebcd85d42c")
