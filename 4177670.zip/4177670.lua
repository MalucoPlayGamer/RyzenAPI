-- 4177670's Lua and Manifest Created by Hubcap Manifest
-- Dragon Dragon Fire Fire Deluxe
-- Created: July 26, 2026 at 13:16:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4177670, 1, "f0a8b67736a995d23560c6b307e749a05e6a904a338d46ae8d474452f67efaa7") -- Dragon Dragon Fire Fire Deluxe
-- MAIN APP DEPOTS
addappid(4177671, 1, "0d82b863d2059591d54457a691f087e46974b614dc218555e659d082f05a282f") -- Depot 4177671
setManifestid(4177671, "4370095125810106098", 129050144)
addappid(4177672, 1, "1c7bdde0dfd1c6036bb56d952b52ac30fe21be64546243f4edab3a0c2dc82813") -- Depot 4177672
setManifestid(4177672, "7069974664472831752", 123784520)