-- Lua provided by RyzenAPI
-- Game: Slime 3K: Rise Against Despot

-- MAIN APPLICATION
addappid(2348610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348611, 1, "11edb21701e276d169c74c81375755f230347c1b535e79b34696ae6b7cde8f67")
addappid(2348612, 1, "50f2b84a5b6150be8acd5aad99ebbfe2cd98fb3dd8ef1ea25daca1c3071f9443")
addappid(2348613, 1, "c37398332e2062dd3a8a3a810ffa9aa975822b401257d6c596888ee733f27e9f")
