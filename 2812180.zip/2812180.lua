-- Lua provided by RyzenAPI
-- Game: Single By Choice

-- MAIN APPLICATION
addappid(2812180)
-- Game: addappid(2812180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812181, 1, "4e6de00903649446628c3e1cc0b29224cb9533184183228047145b50608e8edc")
