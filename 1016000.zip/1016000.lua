-- Lua provided by RyzenAPI 
-- Game: AppID 1016000
addappid(1016000)
addappid(1016001, 1, "fb364886048497e0657f66b8ee025a19c8c24d6214068073597965f4ba8da349")
