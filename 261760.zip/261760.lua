-- Lua provided by RyzenAPI 
-- Game: Lichdom: Battlemage
addappid(261760)
addappid(261761, 1, "9eb38e1789f99b45775e2d1cf48fce4a038af309bee227c8114e834fb6664eaa")
