-- Lua provided by RyzenAPI
-- Game: Game: Lichdom: Battlemage

-- MAIN APPLICATION
addappid(261760)
-- Game: addappid(261760)

-- MAIN APP DEPOTS / PACKAGES
addappid(261761, 1, "9eb38e1789f99b45775e2d1cf48fce4a038af309bee227c8114e834fb6664eaa")
