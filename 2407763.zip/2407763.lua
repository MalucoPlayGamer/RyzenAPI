-- Lua provided by RyzenAPI
-- Game: 2407763

-- MAIN APPLICATION
addappid(2407763)
-- Game: addappid(2407763)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407763,0,"ba2c4491ae27948577ebe22c8e2f8600b27fb84ded5b4b8b366b476c5a39bdd5")
