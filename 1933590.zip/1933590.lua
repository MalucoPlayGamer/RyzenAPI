-- Lua provided by RyzenAPI
-- Game: Game: AppID 1933590

-- MAIN APPLICATION
addappid(1933590)
-- Game: addappid(1933590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933591, 1, "69d1956f6954f01c7c1edda275703588d61545f6bd545a2f9a554cdd3675d839")
