-- Lua provided by RyzenAPI
-- Game: 1056860

-- MAIN APPLICATION
addappid(1056860)
-- Game: addappid(1056860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056861, 1, "34eb7a3c5fe6aef7cf17f5639e2e93d1bd89d9bcd53f7d805173ce7767cc6a5a")
