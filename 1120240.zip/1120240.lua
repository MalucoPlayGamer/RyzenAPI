-- Lua provided by RyzenAPI 
-- Game: Ded Inside
addappid(1120240)
addappid(1120241, 1, "f0f47b1e0136144a53e53959e53d6adf9dc8f5138745d722bd17a010ba948f8f")
