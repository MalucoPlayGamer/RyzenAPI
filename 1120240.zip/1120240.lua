-- Lua provided by RyzenAPI
-- Game: addappid(1120240)

-- MAIN APPLICATION
addappid(1120240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120241, 1, "f0f47b1e0136144a53e53959e53d6adf9dc8f5138745d722bd17a010ba948f8f")
