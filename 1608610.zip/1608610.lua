-- Lua provided by RyzenAPI
-- Game: 1608610

-- MAIN APPLICATION
addappid(1608610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608610,0,"8cea821d5f219ab4ecf1cfaf02e7098d5c390ba6f1cba8c93350792cc19d5366")

