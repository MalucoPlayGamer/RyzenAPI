-- Lua provided by RyzenAPI
-- Game: Times Of War

-- MAIN APPLICATION
addappid(2444600)
-- Game: addappid(2444600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444601, 1, "6c9caf638bbe5c0bc0d08dfeac434c67752097354af565a27819acc0f39957ca")
