-- Lua provided by RyzenAPI
-- Game: Times Of War

-- MAIN APPLICATION
addappid(2444600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444601, 1, "6c9caf638bbe5c0bc0d08dfeac434c67752097354af565a27819acc0f39957ca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
