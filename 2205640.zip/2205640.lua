-- Lua provided by RyzenAPI
-- Game: REAL MAN GOT 100

-- MAIN APPLICATION
addappid(2205640)
-- Game: addappid(2205640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205641, 1, "42b116916d4e7dfce7816ec97f7dd940f0d23965f14f78f0d68fb3f179820cf5")
