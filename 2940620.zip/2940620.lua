-- Lua provided by RyzenAPI
-- Game: addappid(2940620)

-- MAIN APPLICATION
addappid(2940620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940621, 1, "f4a3fabcc044fb38abc1a3ed0a523de7dfd07bd7142d9017a6bcc110ec23830e")
