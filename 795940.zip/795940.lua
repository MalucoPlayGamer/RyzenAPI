-- Lua provided by RyzenAPI
-- Game: Fantasy Mosaics 19: Edge of the World

-- MAIN APPLICATION
addappid(795940)

-- MAIN APP DEPOTS / PACKAGES
addappid(795941,0,"bf4246a9a42ed6595c446894eefd0dc0b2173503c255a043e50bb218f5886ded")

