-- Lua provided by SkyAPI 
-- Game: AppID 360450
addappid(360450)
addappid(360451, 1, "11867e1620c7d35de2311bb1dfc4033399bed9b62fdf689ad566e03820a9bd20")
