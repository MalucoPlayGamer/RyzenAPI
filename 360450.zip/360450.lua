-- Lua provided by RyzenAPI
-- Game: 360450

-- MAIN APPLICATION
addappid(360450)
-- Game: addappid(360450)

-- MAIN APP DEPOTS / PACKAGES
addappid(360451, 1, "11867e1620c7d35de2311bb1dfc4033399bed9b62fdf689ad566e03820a9bd20")
