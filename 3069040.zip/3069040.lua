-- Lua provided by RyzenAPI
-- Game: Little Life: Island Tales

-- MAIN APPLICATION
addappid(3069040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3069041, 1, "e09e1fc52a50e3d41c321a0c7d90f91e4ea7bebf974f089de6039884aff75d7e")
