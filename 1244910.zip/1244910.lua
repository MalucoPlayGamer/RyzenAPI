-- Lua provided by RyzenAPI
-- Game: AppID 1244910

-- MAIN APPLICATION
addappid(1244910)
-- Game: addappid(1244910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244911, 1, "d38c18f457a0af1c06bf5eff59e08cddee94a964a9d15a8e270cef9af3f454e6")
