-- Lua provided by RyzenAPI
-- Game: Endless Horizon

-- MAIN APPLICATION
addappid(847810)

-- MAIN APP DEPOTS / PACKAGES
addappid(847811, 1, "6b11d131894b7682aaf48d93f915e42530a7294e621f201d74fe3b7c66b62766")
