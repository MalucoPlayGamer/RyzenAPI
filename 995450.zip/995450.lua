-- Lua provided by RyzenAPI
-- Game: Geeksos

-- MAIN APPLICATION
addappid(995450)

-- MAIN APP DEPOTS / PACKAGES
addappid(995451, 1, "f2d38ffec75b87766853ce99f1245208f2852a2d18e009b5acc70df12b9b4f5c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
