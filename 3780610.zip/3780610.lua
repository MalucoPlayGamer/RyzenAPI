-- Lua provided by RyzenAPI
-- Game: Game: Alchemy Quest

-- MAIN APPLICATION
addappid(3780610)
-- Game: addappid(3780610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3780611, 1, "d4e91a705e11db247d5afdf42ecb703526e37c1ea1fa2366e7049d22ab20bdbf")
