-- Lua provided by RyzenAPI
-- Game: Dungeon Rush

-- MAIN APPLICATION
addappid(871230)

-- MAIN APP DEPOTS / PACKAGES
addappid(871231,0,"632de4cf82c47ca33c21f45e601e57fcc45f9245dc6ac188567d7658783e8f77")

