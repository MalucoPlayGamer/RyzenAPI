-- Lua provided by SkyAPI 
-- Game: Family Man
addappid(904360)
addappid(904361, 1, "3b70107ce2db84d0dad96b6fdd958a17fd378d385b05e37d7ee5526c0d39b43d")
