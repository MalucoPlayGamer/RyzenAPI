-- Lua provided by RyzenAPI
-- Game: Family Man

-- MAIN APPLICATION
addappid(904360)
-- Game: addappid(904360)

-- MAIN APP DEPOTS / PACKAGES
addappid(904361, 1, "3b70107ce2db84d0dad96b6fdd958a17fd378d385b05e37d7ee5526c0d39b43d")
