-- Lua provided by RyzenAPI
-- Game: Meme Run 2

-- MAIN APPLICATION
addappid(1235120)
-- Game: addappid(1235120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235128,0,"d665d5a15630eb2321b3ab61646931534906491d42889453b8fc8fe0c2262be8")
addappid(1235129,0,"e010f39d07a0eeab6e611b2fcd96127a62b9786f3e72ceaf2c58919bebcba6fe")
