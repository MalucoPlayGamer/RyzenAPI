-- Lua provided by RyzenAPI
-- Game: PHANTOM GALAXIES™

-- MAIN APPLICATION
addappid(1272550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1272551, 1, "ca18217883b6de95f186ca5d002141b2034b0e6e5b73001e1d800cf6f2c48a6b")

