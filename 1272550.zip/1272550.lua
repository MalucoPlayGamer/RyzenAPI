-- Lua provided by RyzenAPI
-- Game: addappid(1272550)

-- MAIN APPLICATION
addappid(1272550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272551, 1, "ca18217883b6de95f186ca5d002141b2034b0e6e5b73001e1d800cf6f2c48a6b")
