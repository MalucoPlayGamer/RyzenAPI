-- Lua provided by RyzenAPI
-- Game: Cannons Lasers Rockets

-- MAIN APPLICATION
addappid(265770)

-- MAIN APP DEPOTS / PACKAGES
addappid(265771, 1, "8e05f65bb7438213d4109b005ba7a0e585503b27295c65eceab2da127b3bce1c")
addappid(265772, 1, "7687540a116ea0cb9461f05a567bb78f725de199c61a771a936c3f696a82b7a4")
addappid(265773, 1, "fc8c0b0c29ef5251f202091c4a186d607d687b4e846aab09816e0dd09a7545ff")

