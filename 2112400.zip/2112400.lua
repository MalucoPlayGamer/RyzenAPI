-- Lua provided by RyzenAPI
-- Game: addappid(2112400)

-- MAIN APPLICATION
addappid(2112400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112401, 1, "4fab8ed03e72382b492d94dbc7c5b28cfe97d1f515fc541da97d0227c634028f")
