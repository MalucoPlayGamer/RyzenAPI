-- Lua provided by RyzenAPI
-- Game: 2838440

-- MAIN APPLICATION
addappid(2838440)
-- Game: addappid(2838440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838441, 1, "1a639821594e999eeb6045ce4e4bd142e161d5ccf942d529736dee433402bd82")
