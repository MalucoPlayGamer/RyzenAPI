-- Lua provided by RyzenAPI
-- Game: Grey Goo

-- MAIN APPLICATION
addappid(290790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(290791, 1, "d5a12f78da44e0c4c1c341a181363fb080b8fdc559118b3b5c2c9668d2592e08")
addappid(341810, 0, "0e0f9a6327f477c5b7b65d97306c8ae6c309c8466b2b20a1153bfe8ad7fb5965")
addappid(357180, 0, "c26f5eeeba373bf99ef4462ffeb25ac3ac2e3ec6b857e68bc95172a4d2b470c4")

