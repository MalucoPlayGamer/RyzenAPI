-- Lua provided by RyzenAPI
-- Game: AppID 496600

-- MAIN APPLICATION
addappid(496600)
-- Game: addappid(496600)

-- MAIN APP DEPOTS / PACKAGES
addappid(496601, 1, "c01b6619e0b719503237f81aec5f0007dd8697413b48129e871d926272ea4bed")
