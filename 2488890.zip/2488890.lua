-- Lua provided by RyzenAPI
-- Game: Game: The Telephone

-- MAIN APPLICATION
addappid(2488890)
-- Game: addappid(2488890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488891, 1, "dced85ab931a81a3df6e839c961122fd8a068ffa7874c56d33cec70b007fa8ae")
