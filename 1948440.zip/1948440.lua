-- Lua provided by RyzenAPI
-- Game: Frostbitten

-- MAIN APPLICATION
addappid(1948440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948441, 1, "d35a0cf9d15d0b7e23ace85368840a8af2777ce4d9a07ecfee76b4c1bbaf0305")

