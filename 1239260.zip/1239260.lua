-- Lua provided by SkyAPI 
-- Game: AppID 1239260
addappid(1239260)
addappid(1239261, 1, "62cce77026f2c740e7567af9aebe10619f73ea9118d3e701e8a43d81fa0d0772")
addappid(1239262, 1, "7325e93f226ba9cf6fd3d7ec1efcca163d9433bcba6040ea9ae77ad3028c4f9f")
