-- Lua provided by RyzenAPI
-- Game: Monster League

-- MAIN APPLICATION
addappid(767360)

-- MAIN APP DEPOTS / PACKAGES
addappid(767361,0,"9e41ba9f085a543e9f6b9673da223702dd76b38e26df987696901a76ecf34029")

