-- Lua provided by RyzenAPI
-- Game: Monster League

-- MAIN APPLICATION
addappid(767360)

-- MAIN APP DEPOTS / PACKAGES
addappid(767361,0,"9e41ba9f085a543e9f6b9673da223702dd76b38e26df987696901a76ecf34029")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
