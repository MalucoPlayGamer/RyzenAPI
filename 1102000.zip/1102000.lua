-- Lua provided by RyzenAPI
-- Game: Pillowheads: It's Party Time

-- MAIN APPLICATION
addappid(1102000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102001, 1, "90a64c683d96937cb5dcac20496154224d859aaae9d2d9e1d6eba3a18292c8f2")

