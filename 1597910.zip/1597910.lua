-- Lua provided by RyzenAPI
-- Game: 1597910

-- MAIN APPLICATION
addappid(1597910)
-- Game: addappid(1597910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597911, 1, "b1367be42fcf8b1fb014d20a9ff18e28b839a2710564a4035b513b66809cd5b6")
