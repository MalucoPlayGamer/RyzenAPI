-- Lua provided by RyzenAPI 
-- Game: FREERIDE
addappid(1597910)
addappid(1597911, 1, "b1367be42fcf8b1fb014d20a9ff18e28b839a2710564a4035b513b66809cd5b6")
