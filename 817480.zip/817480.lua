-- Lua provided by RyzenAPI
-- Game: Total War Saga: Thrones of Britannia - Assembly Kit BETA

-- MAIN APPLICATION
addappid(817480)

-- MAIN APP DEPOTS / PACKAGES
addappid(817481, 1, "96010d20b58018156131be3fdaca883c2f15787b98340a9bb75a224bd938bd23")
