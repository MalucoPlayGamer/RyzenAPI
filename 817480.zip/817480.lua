-- Lua provided by SkyAPI 
-- Game: AppID 817480
addappid(817480)
addappid(817481, 1, "96010d20b58018156131be3fdaca883c2f15787b98340a9bb75a224bd938bd23")
