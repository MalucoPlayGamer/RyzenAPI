-- Lua provided by RyzenAPI
-- Game: 1454200

-- MAIN APPLICATION
addappid(1454200)
-- Game: addappid(1454200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454201, 1, "020c0a4fd219b4af0d4204cd8bde8abf07a8ae5107523f52f48bec3f25b95eb2")
