-- Lua provided by RyzenAPI
-- Game: Star Farmer: Warlock of the Universe

-- MAIN APPLICATION
addappid(2398900)
-- Game: addappid(2398900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398901, 1, "7421ec7ead7da8b913a2e0340480b5da6df11760aa27122ddd7548c685e68350")
