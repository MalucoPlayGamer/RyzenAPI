-- Lua provided by RyzenAPI
-- Game: AppID 378830

-- MAIN APPLICATION
addappid(378830)

-- MAIN APP DEPOTS / PACKAGES
addappid(378831, 1, "ef834fe4b7416c064f095b96ecc067cf1bb2ebe50edc8449df1c54c750a605ab")
addappid(378832, 1, "f2d4099799911768d7394e8d86046fb3896df52f2583f0b92c818d6439a722d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
