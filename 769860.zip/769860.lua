-- Lua provided by RyzenAPI
-- Game: AppID 769860

-- MAIN APPLICATION
addappid(769860)

-- MAIN APP DEPOTS / PACKAGES
addappid(769861, 1, "aff03baedfb3abd6849e126595ba5038ab0c1e4ef4a08f8b5e3e2fce1b74e697")
