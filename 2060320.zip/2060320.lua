-- Lua provided by RyzenAPI
-- Game: Survive Till Morning

-- MAIN APPLICATION
addappid(2060320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060321, 1, "6938f8410e77048df25b65e5c928b499ad6745eba2fc12084dc46d16b2efa9d0")

