-- Lua provided by RyzenAPI
-- Game: Game: Yosumin!™

-- MAIN APPLICATION
addappid(23300)
-- Game: addappid(23300)

-- MAIN APP DEPOTS / PACKAGES
addappid(23301, 1, "adbde342aab49561d8b9a0b13918b01c182d10b19b331dfa8e57f513570c8a2c")
addappid(23302, 1, "69660689e142d88663b51b0c1c78320ac9d5e2e05bc1bacbee999708ba66c71f")
addappid(23303, 1, "8c85e40cba7c50c566d5380ff2373ed6a9f6c10d849550b559068426bdca10fe")
addappid(23304, 1, "5931826dfa59be343fb3294b703e400dda318c6bb4e346f0cde8f80f8f386d59")
addappid(23305, 1, "5e9b7c90c6471fb051aedebfd27d29ebe6afa973925169638be1f9152c706892")
addappid(23306, 1, "dc46c37f3809d87169a248ec7bc912caddc49cb7ff133d63d7bb1458e019c7ad")
addappid(23307, 1, "46998f581d0768210a1bb1a8fde951d98d446fd6e45a71f7390afb741e94baa9")
