-- Lua provided by SkyAPI 
-- Game: Space for Sale
addappid(1624060)
addappid(1624061, 1, "1f9c275a199d2649d00586346ba1f39dd583aa25787e10ecb3f1f497d4e1a767")
