-- Lua provided by RyzenAPI
-- Game: Game: Space for Sale

-- MAIN APPLICATION
addappid(1624060)
-- Game: addappid(1624060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624061, 1, "1f9c275a199d2649d00586346ba1f39dd583aa25787e10ecb3f1f497d4e1a767")
