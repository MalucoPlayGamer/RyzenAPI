-- Lua provided by RyzenAPI
-- Game: Space for Sale

-- MAIN APPLICATION
addappid(1624060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624061, 1, "1f9c275a199d2649d00586346ba1f39dd583aa25787e10ecb3f1f497d4e1a767")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3103030)
