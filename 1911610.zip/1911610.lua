-- Lua provided by RyzenAPI 
-- Game: Windblown
addappid(1911610)
addappid(1911611, 1, "b5c4bddd645cf434b93fe6fe8451160b95b68c9237ec33aa6387fedabe06ced9")
