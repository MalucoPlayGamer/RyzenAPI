-- Lua provided by RyzenAPI
-- Game: addappid(1911610)

-- MAIN APPLICATION
addappid(1911610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911611, 1, "b5c4bddd645cf434b93fe6fe8451160b95b68c9237ec33aa6387fedabe06ced9")
