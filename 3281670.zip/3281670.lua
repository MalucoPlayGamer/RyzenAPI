-- Lua provided by RyzenAPI 
-- Game: LEENIE'S TALE Demo
addappid(3281670)
addappid(3281671, 1, "18fe5b45b96cc5d775709e03ef9c3ca516c305229942f36c5dceb720114483e9")
