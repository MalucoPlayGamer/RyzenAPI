-- Lua provided by RyzenAPI
-- Game: Deer Hunter: Reloaded

-- MAIN APPLICATION
addappid(361370)

-- MAIN APP DEPOTS / PACKAGES
addappid(361371, 1, "c1eee3ede16bebd082fc78224f086a3fcaf00bd326fdbef5500385f280b59c0d")
