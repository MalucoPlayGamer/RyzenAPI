-- Lua provided by RyzenAPI
-- Game: Energy Tanks

-- MAIN APPLICATION
addappid(2621860)
-- Game: addappid(2621860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2621861, 1, "355313ec678691828c9eb169b54e75937a28163669a6343f303634af9cb014de")
