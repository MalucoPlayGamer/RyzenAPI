-- Lua provided by RyzenAPI
-- Game: Energy Tanks

-- MAIN APPLICATION
addappid(2621860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2621861, 1, "355313ec678691828c9eb169b54e75937a28163669a6343f303634af9cb014de")

