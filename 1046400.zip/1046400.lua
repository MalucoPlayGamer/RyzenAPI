-- Lua provided by RyzenAPI
-- Game: Astalon: Tears of the Earth

-- MAIN APPLICATION
addappid(1046400)
addappid(2452360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046401, 1, "88d23701c0154cf607d5f6cf3ee3d7f7c31138a55aa35807969c821f19647f55")
addappid(1046402, 1, "42f6560b6520b79f3707431f31f79ad95e670e28e3a916bd8c89676fa69accad")
addappid(1046403, 1, "cbf7ecba91080aa7941e12e15406d9c12aadac05227826de364c8ce66c5aa255")

