-- Lua provided by RyzenAPI
-- Game: Fiery Disaster

-- MAIN APPLICATION
addappid(538920)

-- MAIN APP DEPOTS / PACKAGES
addappid(538921, 1, "537eebbf3cf332d126ac3c7e1c2aadb26b91c6dbc33dc59dd857d269ef743536")
addappid(538922, 1, "fa0152d3f627cb37b9859ec3ea3a80f8e4c2389da55ad60c5641ba24541f0418")
