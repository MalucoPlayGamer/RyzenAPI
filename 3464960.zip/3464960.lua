-- Lua provided by SkyAPI 
-- Game: Skill Issue VR
addappid(3464960)
addappid(3464961, 1, "dae49f0e0734131d8e955e370f3ff523325b4aa3ba6340bce0585ec12a0196fa")
