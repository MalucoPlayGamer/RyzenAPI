-- Lua provided by RyzenAPI
-- Game: Skill Issue VR

-- MAIN APPLICATION
addappid(3464960)
-- Game: addappid(3464960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464961, 1, "dae49f0e0734131d8e955e370f3ff523325b4aa3ba6340bce0585ec12a0196fa")
