-- Lua provided by RyzenAPI
-- Game: Skill Issue VR

-- MAIN APPLICATION
addappid(3464960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3464961, 1, "dae49f0e0734131d8e955e370f3ff523325b4aa3ba6340bce0585ec12a0196fa")

