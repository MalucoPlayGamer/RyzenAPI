-- Lua provided by RyzenAPI
-- Game: 270 | Two Seventy US Election

-- MAIN APPLICATION
addappid(855010)
-- Game: addappid(855010)

-- MAIN APP DEPOTS / PACKAGES
addappid(855012,0,"79886c19c5179a9976e5f0690c5c0a39c12868857eba98c4eb0b09baf5858566")
addappid(855013,0,"cb79b861e38470db3add50ddd8be5b3b76f71427e9a687175677d711e536bac7")
