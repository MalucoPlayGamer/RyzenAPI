-- Lua provided by RyzenAPI
-- Game: 3112280

-- MAIN APPLICATION
addappid(3112280)
-- Game: addappid(3112280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3112281, 1, "8a1787ce374cb2ba72de205cdebd655424fbba6db8a652615f408c873ff9f5c9")
