-- Lua provided by RyzenAPI 
-- Game: Reclaiming the Lost
addappid(3112280)
addappid(3112281, 1, "8a1787ce374cb2ba72de205cdebd655424fbba6db8a652615f408c873ff9f5c9")
