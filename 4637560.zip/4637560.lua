-- 4637560's Lua and Manifest Created by Hubcap Manifest
-- BleepWare Incrementals
-- Created: July 08, 2026 at 15:41:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4637560) -- BleepWare Incrementals
-- MAIN APP DEPOTS
addappid(4637561, 1, "235307c24b2e2673a088f09cdbd28bdcbe0d8be029fd33f731257a15a0995fee") -- Depot 4637561
setManifestid(4637561, "2106826184113202418", 281000728)