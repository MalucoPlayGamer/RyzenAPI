-- Lua provided by RyzenAPI
-- Game: Game: Fraudster

-- MAIN APPLICATION
addappid(3193520)
-- Game: addappid(3193520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193521, 1, "56f0a8cb9ccff4ec14bec2741655de640f9246bd463d10a03276e4d5e0be5612")
