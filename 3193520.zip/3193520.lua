-- Lua provided by RyzenAPI
-- Game: Fraudster

-- MAIN APPLICATION
addappid(3193520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193521, 1, "56f0a8cb9ccff4ec14bec2741655de640f9246bd463d10a03276e4d5e0be5612")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
