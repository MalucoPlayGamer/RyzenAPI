-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 7: Xtreme Legends Definitive Edition

-- MAIN APPLICATION
addappid(968790)

-- MAIN APP DEPOTS / PACKAGES
addappid(968791, 1, "f0c83ac1f069b932c64611a27de2c4c3a215493ecc38a26a63ff9eb21821e9e9")
addappid(968792, 1, "974a477f41e213fb6e045f60ec541e18903c86c8a84a90c0df6b60c498809b19")
addappid(968794, 1, "fd5c56c8b1b8d3d6c8f42d5dfeed483707a491c6c0cb3e9cc71d5bb7cfe24732")
addappid(968795, 1, "8ce93841b952b77a5574065450d3126a862036068e9e1dc3220197118b3f4972")
addappid(968796, 1, "8dd0c2d3b7017aa51ed29843cb19bfdc775a4d6db21cf3b8c36ac32e1a6664b7")
addappid(968797, 1, "967aae3000d0fc3ec6b49b058b7f2b2b72c24071d80eadfdb678a88adae6e2ca")
addappid(970314, 0, "206ca15cccd6b95b4a26146694f900db833ccc068502da3a5e77670a0e1c13b8")
addappid(970315, 0, "6c66b5413ea1973efa03401c026e6d929f727149497b01c334759fb1728357d4")
addappid(970316, 0, "7e8ac2d6d61e6938889cc700bdd71692cc489cfbeb89cf28d66bcf8c533ee774")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
