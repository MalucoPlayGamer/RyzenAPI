-- Lua provided by RyzenAPI
-- Game: Game: The Warrior War

-- MAIN APPLICATION
addappid(882460)
addappid(891540)
-- Game: addappid(882460)

-- MAIN APP DEPOTS / PACKAGES
addappid(882461, 1, "384f60c0a2cb4406b79cba86ab1ae2c1f8f5180bbdbd87b3138aaa331964f71d")
