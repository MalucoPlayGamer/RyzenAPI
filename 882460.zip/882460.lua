-- Lua provided by SkyAPI 
-- Game: The Warrior War
addappid(882460)
addappid(882461, 1, "384f60c0a2cb4406b79cba86ab1ae2c1f8f5180bbdbd87b3138aaa331964f71d")
addappid(891540)
