-- Lua provided by RyzenAPI
-- Game: The Warrior War

-- MAIN APPLICATION
addappid(882460)
addappid(891540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(882461, 1, "384f60c0a2cb4406b79cba86ab1ae2c1f8f5180bbdbd87b3138aaa331964f71d")

