-- Lua provided by RyzenAPI
-- Game: Game: The Last Operator

-- MAIN APPLICATION
addappid(800650)
-- Game: addappid(800650)

-- MAIN APP DEPOTS / PACKAGES
addappid(800651, 1, "e7a3c18d59b68daaac743f796d5e87484a0755dff4790f129fb3034b628cf522")
