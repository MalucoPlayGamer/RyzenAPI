-- Lua provided by RyzenAPI
-- Game: DFF NT: Cloud Strife Starter Pack

-- MAIN APPLICATION
addappid(1022448)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022448,0,"6153973cb229e22bf55669b1d742c28c77f26ea7833d52b91ffff929644c8183")

