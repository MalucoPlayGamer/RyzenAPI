-- Lua provided by RyzenAPI
-- Game: Griddlers Legend Of The Pirates

-- MAIN APPLICATION
addappid(1148530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148531, 1, "e8663379e8f44d427febff9932fd1231d05542a9d5d457664b466fcd47355c8f")
addappid(1148534, 1, "ca9d8c1e5354ed0ad60b0589c9a8fe4cbb82f22ff9c59bc420ca0fe74a853b5d")
