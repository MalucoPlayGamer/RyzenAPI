-- Lua provided by RyzenAPI
-- Game: LEGO® Horizon Adventures™

-- MAIN APPLICATION
addappid(2428810)
addappid(2971640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428811, 1, "b736dc935b4daf6a78b341a34ecc87e55683c086b7ba22247ebb72fe5194c818")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2971710)
