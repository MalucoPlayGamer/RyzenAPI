-- Lua provided by RyzenAPI
-- Game: Game: LEGO® Horizon Adventures™

-- MAIN APPLICATION
addappid(2428810)
addappid(2971640)
-- Game: addappid(2428810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428811, 1, "b736dc935b4daf6a78b341a34ecc87e55683c086b7ba22247ebb72fe5194c818")
