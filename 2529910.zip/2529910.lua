-- Lua provided by RyzenAPI
-- Game: The Brittle Epoch

-- MAIN APPLICATION
addappid(2529910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529911, 1, "18a557de5f6983f78973af4c2c2b14d3c2109bd5fa36eeccca1c1b7678b565eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
