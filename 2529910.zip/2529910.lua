-- Lua provided by RyzenAPI
-- Game: The Brittle Epoch

-- MAIN APPLICATION
addappid(2529910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529911, 1, "18a557de5f6983f78973af4c2c2b14d3c2109bd5fa36eeccca1c1b7678b565eb")

