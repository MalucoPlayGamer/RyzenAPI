-- Lua provided by RyzenAPI
-- Game: Game: Tales [PC]

-- MAIN APPLICATION
addappid(416250)
-- Game: addappid(416250)

-- MAIN APP DEPOTS / PACKAGES
addappid(416251, 1, "b69e5a48e2acf61e4a834ad585394b8897d609c7d89cbe19b4b47acdcedbc7fd")
