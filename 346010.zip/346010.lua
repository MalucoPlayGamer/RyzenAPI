-- Lua provided by RyzenAPI
-- Game: Besiege

-- MAIN APPLICATION
addappid(346010)

-- MAIN APP DEPOTS / PACKAGES
addappid(346014,0,"64bf9e4846e135c5178842fd18a2b779b3ef6e93d2aa1556c8edba0db3b808c7")
addappid(346015,0,"7225b579e90a3c47c1860faffe37cd238c55c9d1614d68f4a757348bb9737328")
addappid(346016,0,"7af84e502d54827b9ed59359e55d3eab725c084db0f18b8ffa25cca4687f2ea5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2165710)
addappid(2959970)
addappid(3639470)
