-- Lua provided by RyzenAPI
-- Game: addappid(1486750)

-- MAIN APPLICATION
addappid(1486750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486751, 1, "4b5d888ffc80983fdb48e03afa5da4421a478010ed5cb8d1e1cffe9dad1d1a45")
