-- Lua provided by RyzenAPI
-- Game: Perceptions of the Dead 2

-- MAIN APPLICATION
addappid(817860)

-- MAIN APP DEPOTS / PACKAGES
addappid(817861,0,"d820c6e0105ec58a1f804dcfffe17c6273f5765f3b5434faca0fc9d327be2b43")

