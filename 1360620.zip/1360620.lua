-- Lua provided by RyzenAPI
-- Game: 20,000 Miles Under the Sea

-- MAIN APPLICATION
addappid(1360620)
-- Game: addappid(1360620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360621, 1, "b6fbf4b08522c7544624c0725e839a7fec0364a23a2408041e02fdb5a2d54848")
