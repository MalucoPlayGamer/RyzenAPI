-- Lua provided by RyzenAPI
-- Game: addappid(1851320)

-- MAIN APPLICATION
addappid(1851320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851321, 1, "3a0110f2e2ac3d312cf2856ace8cc1720ee573e3f58b804b056771d5e8e948e4")
