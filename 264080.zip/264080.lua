-- Lua provided by RyzenAPI
-- Game: 264080

-- MAIN APPLICATION
addappid(264080)
-- Game: addappid(264080)

-- MAIN APP DEPOTS / PACKAGES
addappid(264084,0,"f85dc66c424bffca186cc06ddf099e9b09e686996a2f07d4d59247a4b00722dd")
