-- Lua provided by RyzenAPI
-- Game: addappid(3395190)

-- MAIN APPLICATION
addappid(3395190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3395191, 1, "7eed9c62b9f3c0ae5865467b52645f5e5d3b21e227a32544bc4ead90013faee0")
