-- Lua provided by RyzenAPI
-- Game: 1540220

-- MAIN APPLICATION
addappid(1540220)
-- Game: addappid(1540220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540221, 1, "ec87bbba1cd17c85195c85f993c4a4d3ed46c83c7c2f48c55a295ab4a204ca50")
