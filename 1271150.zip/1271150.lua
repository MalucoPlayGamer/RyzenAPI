-- Lua provided by RyzenAPI
-- Game: Elsewhere

-- MAIN APPLICATION
addappid(1271150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271151,0,"c20b76e64afb755bb8145519cad5358cfacb78e6682bd8239adb0b05a4c267c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
