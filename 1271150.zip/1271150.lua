-- Lua provided by RyzenAPI
-- Game: Elsewhere

-- MAIN APPLICATION
addappid(1271150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271151,0,"c20b76e64afb755bb8145519cad5358cfacb78e6682bd8239adb0b05a4c267c8")

