-- Lua provided by RyzenAPI
-- Game: Game: AppID 696790

-- MAIN APPLICATION
addappid(696790)
-- Game: addappid(696790)

-- MAIN APP DEPOTS / PACKAGES
addappid(696791, 1, "b7ec5db2706b5303c8a4a1f3822c0ad0589840034fe9ea04184ec89800af0ca1")
addappid(696792, 1, "a6042b91a4f46ed3ddd06902e1a3fd9b8ef92533080ac744e59b3aaa1d980bcd")
addappid(696793, 1, "fb028e1843c08899a15ec1844e97ea3d135c824b7fc402521755c1c991b6be5d")
