-- Lua provided by RyzenAPI
-- Game: AppID 696790

-- MAIN APPLICATION
addappid(696790)

-- MAIN APP DEPOTS / PACKAGES
addappid(696791, 1, "b7ec5db2706b5303c8a4a1f3822c0ad0589840034fe9ea04184ec89800af0ca1")
addappid(696792, 1, "a6042b91a4f46ed3ddd06902e1a3fd9b8ef92533080ac744e59b3aaa1d980bcd")
addappid(696793, 1, "fb028e1843c08899a15ec1844e97ea3d135c824b7fc402521755c1c991b6be5d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
