-- Lua provided by SkyAPI 
-- Game: Atrio: The Dark Wild
addappid(1125390)
addappid(1125391, 1, "029efc0b824739a27a1b3db898233825c7da7207c99d87868ef9f92ed8f13e31")
