-- Lua provided by RyzenAPI
-- Game: Atrio: The Dark Wild

-- MAIN APPLICATION
addappid(1125390)
-- Game: addappid(1125390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125391, 1, "029efc0b824739a27a1b3db898233825c7da7207c99d87868ef9f92ed8f13e31")
