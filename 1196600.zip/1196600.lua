-- Lua provided by RyzenAPI
-- Game: AppID 1196600

-- MAIN APPLICATION
addappid(1196600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196601, 1, "957c9b3a067713fdd39cba656df6f3a99e3bd510c9df2f689554fb836103f666")
addappid(1196602, 1, "49b092664568ed978da97e2f559d9744746d9d071d6a46eee9faabc6b3e4eb29")
addappid(1456370, 0, "b8bdcee759e2ef3a00331c1fb080f4395594c767112c79472ab461397ffea333")
addappid(1456371, 0, "aae109c83c4d78576f383defdff71b5a0fe04a2fe1d4304fd7d8c052709ac922")
addappid(1456372, 0, "7ad8f7baff21f9f5f759e60b12d5dff3efee8d8e509e3527db127f3638ed510e")
addappid(1456373, 0, "23fabbad92fb1ce94ef3f5e70bda422b11fe56767eab4090706bcf0488e3c1d8")
addappid(1731100, 0, "5c55f651094fe924df69f4421e10a2b8b7826c8f22382b00291c8852ebb78646")
addappid(1731101, 0, "26707109fafa68ff2e14730e5a0606e5e99b123a6e12b1a9eb3105207a0cc794")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
