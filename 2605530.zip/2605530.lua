-- Lua provided by RyzenAPI
-- Game: FPVSIM Drone Simulator

-- MAIN APPLICATION
addappid(2605530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605531, 1, "7b758b1f4072150f953927649f19c4acfcfc8e75389a975fe45f63075dd7d0a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
