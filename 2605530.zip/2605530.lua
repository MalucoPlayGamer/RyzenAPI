-- Lua provided by RyzenAPI
-- Game: FPVSIM Drone Simulator

-- MAIN APPLICATION
addappid(2605530)
-- Game: addappid(2605530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605531, 1, "7b758b1f4072150f953927649f19c4acfcfc8e75389a975fe45f63075dd7d0a1")
