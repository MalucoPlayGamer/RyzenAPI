-- Lua provided by RyzenAPI
-- Game: AppID 286810

-- MAIN APPLICATION
addappid(286810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(286811, 1, "7296dee050b2e3a4d81874977711d96bc275e8a5e8d06c73dc0c044a3741fa20")
addappid(286812, 1, "137fc062cba9b1013a3a35c8fb2ef36e7c84b207a132caa2cf7d56c56ce8d5a5")

