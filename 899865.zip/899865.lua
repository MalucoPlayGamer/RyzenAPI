-- Lua provided by RyzenAPI
-- Game: 899865

-- MAIN APPLICATION
addappid(899865)
-- Game: addappid(899865)

-- MAIN APP DEPOTS / PACKAGES
addappid(899865,0,"073607cdad9c09fd747b6c7fdefa7eb351e0595b8b13e7c00662a91575eed251")
