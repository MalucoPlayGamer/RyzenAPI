-- Lua provided by RyzenAPI
-- Game: Game: Tengami

-- MAIN APPLICATION
addappid(299680)
-- Game: addappid(299680)

-- MAIN APP DEPOTS / PACKAGES
addappid(299681, 1, "005faa34aca2a19bc1b0a75bb06f60961e4c949c9a2352f6d9a268815f1c73f4")
addappid(299682, 1, "95f4eab4cbd1cdea33b55cd7c738872a9a1cefa8b9e7448c88ff078aa1098e74")
