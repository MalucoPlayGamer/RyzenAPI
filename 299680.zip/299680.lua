-- Lua provided by RyzenAPI
-- Game: Tengami

-- MAIN APPLICATION
addappid(299680)

-- MAIN APP DEPOTS / PACKAGES
addappid(299681, 1, "005faa34aca2a19bc1b0a75bb06f60961e4c949c9a2352f6d9a268815f1c73f4")
addappid(299682, 1, "95f4eab4cbd1cdea33b55cd7c738872a9a1cefa8b9e7448c88ff078aa1098e74")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
