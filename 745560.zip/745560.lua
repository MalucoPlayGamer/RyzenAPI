-- Lua provided by RyzenAPI
-- Game: Overclocked

-- MAIN APPLICATION
addappid(745560)

-- MAIN APP DEPOTS / PACKAGES
addappid(745561, 1, "b54949e0e4eb367d4ca0d8515fe8302a90b854eb9663d9a5820106fa0907c2e0")
addappid(745562, 1, "4587125afdb5e15186ce53e7962ce5fa622d04716933f3d3c7c08eabbb9badc9")
