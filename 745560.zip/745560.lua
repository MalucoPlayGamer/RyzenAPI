-- Lua provided by RyzenAPI
-- Game: Overclocked

-- MAIN APPLICATION
addappid(745560)
addappid(937510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(745561, 1, "b54949e0e4eb367d4ca0d8515fe8302a90b854eb9663d9a5820106fa0907c2e0")
addappid(745562, 1, "4587125afdb5e15186ce53e7962ce5fa622d04716933f3d3c7c08eabbb9badc9")

