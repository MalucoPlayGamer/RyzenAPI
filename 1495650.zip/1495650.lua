-- Lua provided by RyzenAPI 
-- Game: AppID 1495650
addappid(1495650)
addappid(1495651, 1, "00b5172b134bf210367f5c8985ba0144f00784129706e47049af3d01050038f6")
