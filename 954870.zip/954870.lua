-- Lua provided by RyzenAPI
-- Game: Game: Astrox Imperium

-- MAIN APPLICATION
addappid(954870)
-- Game: addappid(954870)

-- MAIN APP DEPOTS / PACKAGES
addappid(954871, 1, "0316377090b0230df16f192d34a02cc0c6b67934621c86cf077402e3ef967b02")
