-- Lua provided by RyzenAPI
-- Game: Crystalfall Playtest

-- MAIN APPLICATION
addappid(2620990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620991, 1, "6ef653e859b23d3648689125f2780ff31bba071234acb8a768b532639d8b9131")
