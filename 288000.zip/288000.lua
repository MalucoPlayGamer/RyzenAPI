-- Lua provided by RyzenAPI
-- Game: Oncoming Death Steam Edition

-- MAIN APPLICATION
addappid(288000)

-- MAIN APP DEPOTS / PACKAGES
addappid(288001, 1, "aa0b2fac48bc52f0e481994d98d2ad884be13a0588343c2f8459992049677214")
