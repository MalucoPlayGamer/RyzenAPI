-- Lua provided by RyzenAPI
-- Game: No Name Village Demo

-- MAIN APPLICATION
addappid(2310650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310651, 1, "b94cc6cbab18ab4c8d1e3839dac8144a8c05de372e5579a01c792a1bedca0210")

