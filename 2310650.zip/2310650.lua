-- Lua provided by SkyAPI 
-- Game: AppID 2310650
addappid(2310650)
addappid(2310651, 1, "b94cc6cbab18ab4c8d1e3839dac8144a8c05de372e5579a01c792a1bedca0210")
