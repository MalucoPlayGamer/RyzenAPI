-- Lua provided by RyzenAPI
-- Game: Driveland

-- MAIN APPLICATION
addappid(2611940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2611942,0,"eb2fe204df9d1db88fb3e63e2bbe16d59a9c42022ff0b441e57f6e9708babc39")

