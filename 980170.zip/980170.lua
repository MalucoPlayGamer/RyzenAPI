-- Lua provided by RyzenAPI
-- Game: Tenko's Magical Sword Quest

-- MAIN APPLICATION
addappid(980170)

-- MAIN APP DEPOTS / PACKAGES
addappid(980171, 1, "4c0239c9fa5e206540965f99eb74efdf2d3455947a2809af4276059531588333")
