-- Lua provided by RyzenAPI
-- Game: Phantom Brave: The Lost Hero

-- MAIN APPLICATION
addappid(3049990)
addappid(3486450)
addappid(3498450)
addappid(3498460)
addappid(3498470)
addappid(3498480)
addappid(3498490)
addappid(3526890)
addappid(3529060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3049992,0,"c66837576c962858096fcd26377b1784c8096993a5841386af499b42446cd8b0")
addappid(3529070,0,"b026350733364aae827ef7a7c5167c3ee7ee13282002f1996ed6bd765db6bc23")

