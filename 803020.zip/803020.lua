-- Lua provided by SkyAPI 
-- Game: Manny Boxing VR
addappid(803020)
addappid(803021, 1, "9088447b09fc12815cf65771e01e7baa7e2b0ef6928d2847dd8c6cc2814634ff")
