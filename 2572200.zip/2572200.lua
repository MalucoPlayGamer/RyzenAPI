-- Lua provided by RyzenAPI
-- Game: addappid(2572200)

-- MAIN APPLICATION
addappid(2572200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572201, 1, "1195eea08b73a10e77a912e8ff7a980cce74c26f036c9b9e50c1398729664f03")
