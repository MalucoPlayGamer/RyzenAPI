-- Lua provided by RyzenAPI
-- Game: Escape from Umbra

-- MAIN APPLICATION
addappid(4830970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4830971,0,"f0d9236e91af917c12749825c39fc1d4d24688685c7bb267d8e32bf9d0f0cd18")

