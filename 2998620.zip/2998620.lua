-- Lua provided by RyzenAPI
-- Game: 2998620

-- MAIN APPLICATION
addappid(2998620)
-- Game: addappid(2998620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998621, 1, "c2eed429e1f9ac6f55005790e365c2238b0dfaf432a147c2d3dd39d4d2342859")
