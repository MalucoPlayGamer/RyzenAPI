-- Lua provided by RyzenAPI
-- Game: 759000

-- MAIN APPLICATION
addappid(759000)
-- Game: addappid(759000)

-- MAIN APP DEPOTS / PACKAGES
addappid(759001, 1, "c484d9640659142bde08846ebde503306a84707df869ebf0d879287c6e4a1b03")
addappid(759002, 1, "2e3eb86eae76ba8ab267c0d715611d655ef162200f9a7fcfd9175aa73c24fc8d")
