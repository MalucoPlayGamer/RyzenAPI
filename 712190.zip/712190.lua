-- Lua provided by RyzenAPI
-- Game: Genesis Alpha One Deluxe Edition

-- MAIN APPLICATION
addappid(712190)
addappid(877140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(712191, 1, "046d7cbe9295a06da8abec2415474dfa5148d5ae93f3c8ab37a276ebcbebd2bd")
addappid(712192, 1, "33038319154ed35ba23e59c0fc3f7df8668dc2d6e64b52c766a22c0ef65dda2f")
addappid(712193, 1, "04b45aafa895558e6ed5a9e66d3f64156f280530dfc044ac662897094822e80c")
