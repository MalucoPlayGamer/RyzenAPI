-- Lua provided by RyzenAPI
-- Game: AppID 712190

-- MAIN APPLICATION
addappid(712190)
-- Game: addappid(712190)

-- MAIN APP DEPOTS / PACKAGES
addappid(712191, 1, "046d7cbe9295a06da8abec2415474dfa5148d5ae93f3c8ab37a276ebcbebd2bd")
addappid(712192, 1, "33038319154ed35ba23e59c0fc3f7df8668dc2d6e64b52c766a22c0ef65dda2f")
addappid(712193, 1, "04b45aafa895558e6ed5a9e66d3f64156f280530dfc044ac662897094822e80c")
