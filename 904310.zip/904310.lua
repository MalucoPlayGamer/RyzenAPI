-- Lua provided by RyzenAPI
-- Game: Initial 2 : New Stage

-- MAIN APPLICATION
addappid(904310)
addappid(965850)
-- Game: addappid(904310)

-- MAIN APP DEPOTS / PACKAGES
addappid(904311, 1, "5c56c8f7b0b1e6d1f48c16b733c10a0bd45b54ea734c3fd6e73cb7ae5a73b865")
