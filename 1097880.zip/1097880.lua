-- Lua provided by RyzenAPI
-- Game: Game: Super Naughty Maid 2

-- MAIN APPLICATION
addappid(1097880)
-- Game: addappid(1097880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097881, 1, "a94133fb02a55c215056d3c37e72dc3bf5b16973af0b0d34aa0a4d2dfeb9de00")
addappid(1097882, 1, "83517665a6987c203bba3671f211876cc58f4ae58af7065b2a97ccc6bfaf17e6")
addappid(1097883, 1, "e63fecc878172395faec1f69c12b5d6c1aca6af29f58725cc9be9c801d770f73")
addappid(1105800, 0, "27bfbac9ff498fdaed7bdcb029ccdd9e59675c4a7e705dce81dae637fd0ca5ae")
addappid(1148280, 0, "fc56ec75130ebcfea974314b0c445cb2f03ff3f3000967485aaef6165ab0dc79")
