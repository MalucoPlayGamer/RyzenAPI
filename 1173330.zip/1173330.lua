-- Lua provided by RyzenAPI
-- Game: VELVETIST: Prototype

-- MAIN APPLICATION
addappid(1173330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173331, 1, "06fabb3cedb575bb07c80eb66fcb3c66e7c066b0078c64fe14afcd7873454e18")
