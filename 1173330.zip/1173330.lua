-- Lua provided by RyzenAPI
-- Game: VELVETIST: Prototype

-- MAIN APPLICATION
addappid(1173330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1173331, 1, "06fabb3cedb575bb07c80eb66fcb3c66e7c066b0078c64fe14afcd7873454e18")

