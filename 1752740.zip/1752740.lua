-- Lua provided by RyzenAPI
-- Game: Game: Сollision Hero

-- MAIN APPLICATION
addappid(1752740)
-- Game: addappid(1752740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752741, 1, "d6a4bcfacf8c9023034cd6a723cc99425918b60e3bf50f89c930be486dc06c66")
