-- Lua provided by RyzenAPI
-- Game: Aim Master

-- MAIN APPLICATION
addappid(915540)

-- MAIN APP DEPOTS / PACKAGES
addappid(915541, 1, "f7cd144d49974b9efa723aead5eff24a4fc3a146aadbf530b154d5c2a2c9bb29")

