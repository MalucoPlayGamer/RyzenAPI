-- Lua provided by RyzenAPI
-- Game: Hexarchy

-- MAIN APPLICATION
addappid(1356810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1356811, 1, "fdb11225d1172bcb021bb060a7fe134c226f7a48205f600fd13d75f9603a23c1")
addappid(1356812, 1, "8377002d87d60574485cd29dd4a3f20b84b1a9d169288b17dc0ed74de2eaf0b8")

