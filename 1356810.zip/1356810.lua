-- Lua provided by SkyAPI 
-- Game: Hexarchy
addappid(1356810)
addappid(1356811, 1, "fdb11225d1172bcb021bb060a7fe134c226f7a48205f600fd13d75f9603a23c1")
addappid(1356812, 1, "8377002d87d60574485cd29dd4a3f20b84b1a9d169288b17dc0ed74de2eaf0b8")
