-- Lua provided by RyzenAPI
-- Game: AppID 3084720

-- MAIN APPLICATION
addappid(3084720)
-- Game: addappid(3084720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3084721, 1, "ce3abb97e0e1166937d02a166c54d5f4cc77c4b3ccb78de5d6dd6eb4fe5a6d60")
