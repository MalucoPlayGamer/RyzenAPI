-- Lua provided by RyzenAPI
-- Game: addappid(333510)

-- MAIN APPLICATION
addappid(333510)

-- MAIN APP DEPOTS / PACKAGES
addappid(333512,0,"74af75443638e9f150aa165e44f6d4a7e9d466b2eb412f2863b5d1144973aeb1")
