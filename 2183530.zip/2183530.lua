-- Lua provided by RyzenAPI
-- Game: 2183530

-- MAIN APPLICATION
addappid(2183530)
-- Game: addappid(2183530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183531, 1, "b813e604818bba09d5745ee5d2c204a3e767dcba230b23fabfcdc1d7fdf91df1")
