-- Lua provided by RyzenAPI
-- Game: Zabawa Karaoke

-- MAIN APPLICATION
addappid(2183530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183531, 1, "b813e604818bba09d5745ee5d2c204a3e767dcba230b23fabfcdc1d7fdf91df1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2194500)
addappid(2223490)
addappid(2658930)
addappid(2685890)
addappid(2685940)
addappid(2685950)
addappid(2685960)
addappid(2685970)
addappid(2685980)
addappid(2685990)
addappid(2686000)
addappid(2686010)
addappid(3309300)
addappid(3309310)
addappid(3309320)
addappid(3309330)
addappid(3309340)
