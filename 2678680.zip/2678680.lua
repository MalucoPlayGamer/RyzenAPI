-- Lua provided by RyzenAPI
-- Game: addappid(2678680)

-- MAIN APPLICATION
addappid(2678680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678681, 1, "74b1e64ddf7b1a05c4f204a088be50872a93936d3607a20b4f9180ace99124b8")
