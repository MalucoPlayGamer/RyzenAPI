-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1239513)
-- Game: addappid(1239513)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239570,0,"2f2ed6032ca4ad1b194df4f5dadec9d56aba6d05cadecb679287a4e134fdf822")
addappid(1239573,0,"399b2bdc234d995db3a16a929de0875504298ddd6e5207eb92176ea7c18a8018")
