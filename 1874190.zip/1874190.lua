-- Lua provided by RyzenAPI
-- Game: Vorax

-- MAIN APPLICATION
addappid(1874190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874191, 1, "d7fc5cf60313b3871aae27348dfac62e50e75d553ad2147119f06727a9c114fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
