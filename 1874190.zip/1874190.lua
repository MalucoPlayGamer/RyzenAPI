-- Lua provided by RyzenAPI
-- Game: Vorax

-- MAIN APPLICATION
addappid(1874190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874191, 1, "d7fc5cf60313b3871aae27348dfac62e50e75d553ad2147119f06727a9c114fc")
