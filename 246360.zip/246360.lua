-- Lua provided by RyzenAPI
-- Game: Game: Perfection.

-- MAIN APPLICATION
addappid(246360)
-- Game: addappid(246360)

-- MAIN APP DEPOTS / PACKAGES
addappid(246361, 1, "44f31618ba2bee1d39088bbb8522ec60020e24a93e166b383193d57a17d477b9")
addappid(246362, 1, "33f8eede27c49e53bbb35480609ce0b0cce23054a0d21074a734916f717bef09")
addappid(246363, 1, "c87ffc5439379a61b102047d4cd8f768267f0bfe697a25b9c539f855f9ee8a7f")
