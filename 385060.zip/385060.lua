-- Lua provided by RyzenAPI
-- Game: The Last Warlock

-- MAIN APPLICATION
addappid(385060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(385061, 1, "d39dbace6968f2ae4b41ba801776761c37509ed84691e64fe9b020d164969ce4")
addappid(385062, 1, "c0741f79f73a95b2ac6847407352236c0533465d9865a984a30750e288b71a37")
addappid(385063, 1, "13239172bfc31fbcc1434c7ce538cbb4c351174f2d9499df6311df4b0f91c83e")

