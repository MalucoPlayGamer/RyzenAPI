-- Lua provided by RyzenAPI
-- Game: addappid(2087910)

-- MAIN APPLICATION
addappid(2087910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087911, 1, "ce5c1c892cd980a4d1227bd5727c6cae314c2fbf6e3bbc8767d5ab1c44fc2bf2")
