-- Lua provided by RyzenAPI
-- Game: Game: Sudden Strike Gold

-- MAIN APPLICATION
addappid(612300)
-- Game: addappid(612300)

-- MAIN APP DEPOTS / PACKAGES
addappid(612301, 1, "b2869e24140c126a6a63aa0051e3f5e35afd31900c9a030371ef5c21c83a4f9f")
addappid(612302, 1, "0455c705f430b6f7264c37196d15dc3e5c9a8131f55ea970940c80562985df1f")
addappid(612303, 1, "b8a3f787333bf7d98d815640fffc21123953376e89b739df3da9514eba52fa75")
addappid(612304, 1, "9b06e14ae43558d3fdfeea422afc8c5646cd8e4d794eaa72eff271fb9b6b8375")
