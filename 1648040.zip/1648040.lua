-- Lua provided by RyzenAPI
-- Game: There You Are

-- MAIN APPLICATION
addappid(1648040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648041, 1, "e6292158f54c1e8aa5f4da77fba4084f7dd311e84cdd946c0ca198983182621f")
addappid(1648042, 1, "7b1af3f24209810cd744f938c1b6cc6e6db68c43fe567d0fc227d57d7745aa23")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
