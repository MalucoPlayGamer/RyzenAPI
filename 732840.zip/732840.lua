-- Lua provided by RyzenAPI
-- Game: Nullysun

-- MAIN APPLICATION
addappid(732840)
-- Game: addappid(732840)

-- MAIN APP DEPOTS / PACKAGES
addappid(732841, 1, "633300d53a2b40ec112d4c5975160f3a206ada2fadf541cf446fa1a10e196802")
addappid(734810, 0, "8dda9c2903b30406283385f0f5b5ae714bfe3279f6689595c32deffb27618c3a")
