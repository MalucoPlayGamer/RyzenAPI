-- Lua provided by RyzenAPI 
-- Game: Minecraft Dungeons Ultimate Edition Soundtrack
addappid(1717450)
addappid(1717451, 1, "537a4254a9eb6f712e387077aea3440baed45fecc5d77804bbae0186e98ba92b")
addappid(1717452, 1, "e24b4a2f0fc286cc4d2c8589889bccdf8735e4b9f76d4ee5bd9200e78baf25d0")
