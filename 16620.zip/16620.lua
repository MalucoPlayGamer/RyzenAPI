-- Lua provided by RyzenAPI 
-- Game: AppID 16620
addappid(16620)
addappid(16621, 1, "6b2f7306540ae60f4d9a2ebb64283945cbbc2916bcec489f7abc6281f1288729")
