-- Lua provided by RyzenAPI
-- Game: Dawnfolk Demo

-- MAIN APPLICATION
addappid(2423630)
-- Game: addappid(2423630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423631, 1, "1222bd24128c7509cce93ea7aff7c7c1317175ccda1ccc489217c63404bdef3c")
