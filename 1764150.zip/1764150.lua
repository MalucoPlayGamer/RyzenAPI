-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Urban Modern Tileset - Interiors

-- MAIN APPLICATION
addappid(1764150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764150,0,"3b149b700fa0abf6f5cd047fd423766870916d17acaf556e2b6bf331623bd7f8")

