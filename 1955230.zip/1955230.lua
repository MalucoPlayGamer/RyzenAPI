-- Lua provided by RyzenAPI 
-- Game: Penny’s Big Breakaway
addappid(1955230)
addappid(1955231, 1, "a78b34a2e413da7191f349d1954b63df72dd07f76b35ef57b7a01665b8e64358")
