-- Lua provided by RyzenAPI
-- Game: Penny’s Big Breakaway

-- MAIN APPLICATION
addappid(1955230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1955231, 1, "a78b34a2e413da7191f349d1954b63df72dd07f76b35ef57b7a01665b8e64358")

