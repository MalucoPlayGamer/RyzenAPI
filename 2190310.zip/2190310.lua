-- Lua provided by RyzenAPI
-- Game: 2190310

-- MAIN APPLICATION
addappid(2190310)
-- Game: addappid(2190310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190310,0,"9d331d7a9b13c62888421a7b0ce58182cacbba2d05525d4957a7d1aae239ada3")
