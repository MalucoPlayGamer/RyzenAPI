-- Lua provided by RyzenAPI
-- Game: Ms. Holmes: The Monster of the Baskervilles Collector's Edition

-- MAIN APPLICATION
addappid(1093130)
-- Game: addappid(1093130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093131, 1, "18ec37d576e0a34654474875277c3dc172d82f50db9778efcb393972b7b02fd1")
