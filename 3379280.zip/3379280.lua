-- Lua provided by RyzenAPI
-- Game: 3379280

-- MAIN APPLICATION
addappid(3379280)
-- Game: addappid(3379280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3379281, 1, "d90ed45433b95fd437246ff3174071cc1fb65c2e07f86e1d53c16d299a981dfb")
