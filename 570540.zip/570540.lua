-- Lua provided by RyzenAPI
-- Game: Amazon Odyssey

-- MAIN APPLICATION
addappid(570540)

-- MAIN APP DEPOTS / PACKAGES
addappid(570541,0,"55415325e366c9902f6fb2b6d5c8286fb1f6df1279be777edfa4831d2b4fed10")

