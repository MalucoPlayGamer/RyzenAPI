-- Lua provided by RyzenAPI
-- Game: Amazon Odyssey

-- MAIN APPLICATION
addappid(570540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(570541,0,"55415325e366c9902f6fb2b6d5c8286fb1f6df1279be777edfa4831d2b4fed10")

