-- Lua provided by RyzenAPI
-- Game: Unquiet Grey

-- MAIN APPLICATION
addappid(4309120)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4803550)
