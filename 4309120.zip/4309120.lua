-- Lua provided by RyzenAPI
-- Game: Unquiet Grey

-- MAIN APPLICATION
addappid(4309120)
addappid(4803550)

