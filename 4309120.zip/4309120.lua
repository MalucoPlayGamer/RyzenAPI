-- Lua provided by RyzenAPI
-- Game: Unquiet Grey

-- MAIN APPLICATION
addappid(4309120)
