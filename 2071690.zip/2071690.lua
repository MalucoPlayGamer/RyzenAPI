-- Lua provided by RyzenAPI
-- Game: 2071690

-- MAIN APPLICATION
addappid(2071690)
-- Game: addappid(2071690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071690,0,"3d03b40d4c2e36e12f7ade572c1e8800589c8ad8937d5b4c1d008dac51925b2a")
