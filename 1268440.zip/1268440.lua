-- Lua provided by RyzenAPI 
-- Game: AppID 1268440
addappid(1268440)
addappid(1268441, 1, "0ba023293c6821b45bf9e9c87de77972cd4a8298f8e351ce2f5f21a2cdab9eae")
