-- Lua provided by RyzenAPI
-- Game: 1384260

-- MAIN APPLICATION
addappid(1384260)
-- Game: addappid(1384260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384261, 1, "36f6f83f4ab6d1d391651957b07ff9499fabf57d2e1e3865059fb5086a580de0")
