-- Lua provided by RyzenAPI
-- Game: Corpse Party

-- MAIN APPLICATION
addappid(251270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(251271, 1, "665a364527f3f0ab2a5cbf967946df827610400239c9ce3da5565093078bb606")
addappid(251272, 1, "7bec28fea0361d7b1b81dab4ecf3bc0afce747c6276b276b1d5b0bbcf846bed3")
addappid(251273, 1, "d9148b0fc990c89869262f3794ae48409f356382252dbc4b1803a688effcfacc")

