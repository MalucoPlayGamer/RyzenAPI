-- Lua provided by RyzenAPI
-- Game: Corpse Party

-- MAIN APPLICATION
addappid(251270)

-- MAIN APP DEPOTS / PACKAGES
addappid(251271, 1, "665a364527f3f0ab2a5cbf967946df827610400239c9ce3da5565093078bb606")
addappid(251272, 1, "7bec28fea0361d7b1b81dab4ecf3bc0afce747c6276b276b1d5b0bbcf846bed3")
addappid(251273, 1, "d9148b0fc990c89869262f3794ae48409f356382252dbc4b1803a688effcfacc")

