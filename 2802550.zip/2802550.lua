-- Lua provided by RyzenAPI
-- Game: Game: Godrop:Prologue

-- MAIN APPLICATION
addappid(2802550)
-- Game: addappid(2802550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802551, 1, "9eca680d6aa1a30697ae883924d9971dcb0c01887daf2e96c7f767ea65749535")
