-- Lua provided by RyzenAPI
-- Game: Dentist Simulator 2

-- MAIN APPLICATION
addappid(3940820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3940821,0,"01ffe21d2dc4b032181d8bccb5515305b352420bfe2ef4a30fc0aa5e832986c6")

