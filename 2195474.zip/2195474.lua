-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Weeknd, Kendrick Lamar - "Pray For Me"

-- MAIN APPLICATION
addappid(2195474)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195474,0,"7045cb5df6a072cba59f0bff5b7d472a7970d36c3d98620487b94423ceda77c0")
