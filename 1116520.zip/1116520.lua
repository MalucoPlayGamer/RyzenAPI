-- Lua provided by RyzenAPI
-- Game: Game: The Backrooms

-- MAIN APPLICATION
addappid(1116520)
-- Game: addappid(1116520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116521, 1, "8a896065a838227eb32e5cc6db9515227630682b4eb365c6f8920a771e19a0e4")
