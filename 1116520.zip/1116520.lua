-- Lua provided by RyzenAPI
-- Game: The Backrooms

-- MAIN APPLICATION
addappid(1116520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1116521, 1, "8a896065a838227eb32e5cc6db9515227630682b4eb365c6f8920a771e19a0e4")

