-- Lua provided by RyzenAPI
-- Game: SAND: Raiders of Sophie

-- MAIN APPLICATION
addappid(1431300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1431301, 1, "dab01e2a8350400e46ea883519c66d89e80e9e2571aebf1c3e5b72b04bd0e7c1")

