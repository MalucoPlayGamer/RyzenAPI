-- Lua provided by RyzenAPI
-- Game: addappid(1431300)

-- MAIN APPLICATION
addappid(1431300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431301, 1, "dab01e2a8350400e46ea883519c66d89e80e9e2571aebf1c3e5b72b04bd0e7c1")
