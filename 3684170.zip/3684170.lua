-- Lua provided by RyzenAPI
-- Game: Interactive Sex - Futanari Incest - Episode 1

-- MAIN APPLICATION
addappid(3684170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3684171, 1, "1f2a6dda7631ca41f0d27abdca428712fa281567ab73d1f090c265b25687adde")

