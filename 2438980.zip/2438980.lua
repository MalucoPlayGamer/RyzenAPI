-- Lua provided by RyzenAPI
-- Game: The Isle of Cats

-- MAIN APPLICATION
addappid(2438980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438981, 1, "57422efef46a15f42274da70e2d30da27c95f4af5e151c043fd41008dda41f5d")

