-- Lua provided by RyzenAPI
-- Game: Lethis - Path of Progress

-- MAIN APPLICATION
addappid(359230)

-- MAIN APP DEPOTS / PACKAGES
addappid(359231, 1, "273356336a6ae128fe82f5643295783184454d7551b1bb0c800bc07bbe4b936a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
