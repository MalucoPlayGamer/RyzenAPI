-- Lua provided by RyzenAPI
-- Game: Lethis - Path of Progress

-- MAIN APPLICATION
addappid(359230)

-- MAIN APP DEPOTS / PACKAGES
addappid(359231, 1, "273356336a6ae128fe82f5643295783184454d7551b1bb0c800bc07bbe4b936a")
