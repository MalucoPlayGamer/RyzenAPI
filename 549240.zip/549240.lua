-- Lua provided by RyzenAPI
-- Game: Game: Beans: The Coffee Shop Simulator

-- MAIN APPLICATION
addappid(549240)
addappid(648080)
-- Game: addappid(549240)

-- MAIN APP DEPOTS / PACKAGES
addappid(549241, 1, "f8954c35da9c5b9f627e325ca31f24621e85adcf0eabce2f9d586a0fe393f058")
addappid(549242, 1, "03366739019e4d7a0b02fdadc8a97aeb448b088dbc2b5d64d730081f745c43ff")
