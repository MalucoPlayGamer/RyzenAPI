-- Lua provided by SkyAPI 
-- Game: Galactic Warship
addappid(2515950)
addappid(2515951, 1, "7faeb6c102e47d36d8a94c71945a8eb88678885bc0c4e2ec74aaefd92c2bccce")
