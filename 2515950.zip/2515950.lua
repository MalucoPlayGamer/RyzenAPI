-- Lua provided by RyzenAPI
-- Game: Galactic Warship

-- MAIN APPLICATION
addappid(2515950)
-- Game: addappid(2515950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515951, 1, "7faeb6c102e47d36d8a94c71945a8eb88678885bc0c4e2ec74aaefd92c2bccce")
