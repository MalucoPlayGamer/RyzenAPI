-- Lua provided by RyzenAPI
-- Game: Galactic Warship

-- MAIN APPLICATION
addappid(2515950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2515951, 1, "7faeb6c102e47d36d8a94c71945a8eb88678885bc0c4e2ec74aaefd92c2bccce")

