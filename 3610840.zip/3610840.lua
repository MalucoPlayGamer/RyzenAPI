-- Lua provided by RyzenAPI
-- Game: Gagged Love

-- MAIN APPLICATION
addappid(3610840)
-- Game: addappid(3610840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3610841, 1, "fe80d5993a2e6da2d79d59e64956683f51597ab8e5b0fd2b224668c259a4569c")
