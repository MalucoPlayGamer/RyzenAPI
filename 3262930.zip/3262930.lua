-- Lua provided by SkyAPI 
-- Game: VTumbler Demo
addappid(3262930)
addappid(3262931, 1, "47ee5d2cbf1a3637571cf04884406328ed171f0a427988e9bdb4f0aeade521a0")
