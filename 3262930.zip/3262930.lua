-- Lua provided by RyzenAPI
-- Game: Game: VTumbler Demo

-- MAIN APPLICATION
addappid(3262930)
-- Game: addappid(3262930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262931, 1, "47ee5d2cbf1a3637571cf04884406328ed171f0a427988e9bdb4f0aeade521a0")
