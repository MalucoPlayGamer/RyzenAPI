-- Lua provided by RyzenAPI 
-- Game: AppID 1936210
addappid(1936210)
addappid(1936211, 1, "0ca3a7747fa2e163d6506d17fadab7558e74966d8188749f665455d6214f25df")
