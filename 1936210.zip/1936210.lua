-- Lua provided by RyzenAPI
-- Game: Game: AppID 1936210

-- MAIN APPLICATION
addappid(1936210)
-- Game: addappid(1936210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1936211, 1, "0ca3a7747fa2e163d6506d17fadab7558e74966d8188749f665455d6214f25df")
