-- Lua provided by RyzenAPI
-- Game: Laundry Store Simulator

-- MAIN APPLICATION
addappid(3150440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150441, 1, "d6e3e5cb657c1847009f837d80ebfbf6a8bba4a76a8b2b5f3f4937762606aa61")

