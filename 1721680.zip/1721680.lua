-- Lua provided by RyzenAPI
-- Game: addappid(1721680)

-- MAIN APPLICATION
addappid(1721680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721681, 1, "9e9ea3add084440469efe37962db7df3cd3da9f40a83992f67e665db298bdadd")
