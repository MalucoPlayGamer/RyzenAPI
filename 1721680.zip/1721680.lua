-- Lua provided by SkyAPI 
-- Game: Pre Dusk
addappid(1721680)
addappid(1721681, 1, "9e9ea3add084440469efe37962db7df3cd3da9f40a83992f67e665db298bdadd")
