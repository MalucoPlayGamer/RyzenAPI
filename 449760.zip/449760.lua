-- Lua provided by RyzenAPI
-- Game: 449760

-- MAIN APPLICATION
addappid(449760)
addappid(457780)
-- Game: addappid(449760)

-- MAIN APP DEPOTS / PACKAGES
addappid(449761, 1, "021efcf34331fa21ccdc7409e8b8ba751c1be43c82423c4451d0caff76e84aa9")
addappid(449762, 1, "061cc8cd00554ffaa64e6c48c27e4f5894c4eaf56cb29965bfaaf4d25add5689")
addappid(449763, 1, "bd34157b0215dca5999cb399deacdb035b1ea846fd69bd811db18dc39b8e0a5e")
