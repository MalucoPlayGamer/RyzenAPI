-- Lua provided by RyzenAPI 
-- Game: Dungeon Rushers - Soundtrack and wallpapers
addappid(577630)
addappid(577631, 1, "54af889933b55d59f6166ae03a35ee106c7d5823fb48150dc0f57ab0ae1eacfb")
