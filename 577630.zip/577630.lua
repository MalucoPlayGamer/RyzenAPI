-- Lua provided by RyzenAPI
-- Game: 577630

-- MAIN APPLICATION
addappid(577630)
-- Game: addappid(577630)

-- MAIN APP DEPOTS / PACKAGES
addappid(577631, 1, "54af889933b55d59f6166ae03a35ee106c7d5823fb48150dc0f57ab0ae1eacfb")
