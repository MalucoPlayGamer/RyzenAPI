-- Lua provided by RyzenAPI
-- Game: JETBOUNCE

-- MAIN APPLICATION
addappid(1819950)
-- Game: addappid(1819950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819951, 1, "6ec52da354b92b18702ef2a0d0625848ff7dd16eeaad7d5f4e8182eb0ad08339")
