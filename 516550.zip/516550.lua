-- Lua provided by RyzenAPI
-- Game: Relativity

-- MAIN APPLICATION
addappid(516550)

-- MAIN APP DEPOTS / PACKAGES
addappid(516551,0,"f7a035cfcac932275e77350ac9736f56c4db7314587f8d13f0fb66997a6a0aca")

