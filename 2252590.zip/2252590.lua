-- Lua provided by RyzenAPI
-- Game: Football Manager 2024 Editor

-- MAIN APPLICATION
addappid(2252590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252591, 1, "1a000736fc1d86e6e99930fcc025c7059699536138b8248b857f66ebbfab74b7")
