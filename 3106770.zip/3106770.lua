-- Lua provided by RyzenAPI
-- Game: 3106770

-- MAIN APPLICATION
addappid(3106770)
-- Game: addappid(3106770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106771, 1, "0f63f9938d3a33214dde5dd358e69cc2a69e3f67e2ece8f76acf55c0a8cf1d07")
