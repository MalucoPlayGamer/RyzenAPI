-- Lua provided by SkyAPI 
-- Game: AppID 3106770
addappid(3106770)
addappid(3106771, 1, "0f63f9938d3a33214dde5dd358e69cc2a69e3f67e2ece8f76acf55c0a8cf1d07")
