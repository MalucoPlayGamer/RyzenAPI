-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Rdot monsters vol.4

-- MAIN APPLICATION
addappid(3386560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3386560,0,"5191465dc41cd45d7d0fb98018ed113a1e8112a54f605400c9e215fd8e91f855")

