-- Lua provided by RyzenAPI
-- Game: Game: AppID 3261980

-- MAIN APPLICATION
addappid(3261980)
-- Game: addappid(3261980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261981, 1, "95a6da8d65fa857bcbc9ec2b960388751c1f95ba75ffea095b0eb19d2cff1902")
