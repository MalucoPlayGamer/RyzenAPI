-- Lua provided by RyzenAPI
-- Game: 1358770

-- MAIN APPLICATION
addappid(1358770)
-- Game: addappid(1358770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358771, 1, "787030ca6e03fb978b1050209148df6addf5ca022d7ab74178d6bd7e84b2ea38")
