-- Lua provided by RyzenAPI
-- Game: AppID 424200

-- MAIN APPLICATION
addappid(424200)
-- Game: addappid(424200)

-- MAIN APP DEPOTS / PACKAGES
addappid(424201, 1, "60c349efe945bb06560bd294e7600c149647e63594e40ebf9b3f52a8569cfb85")
