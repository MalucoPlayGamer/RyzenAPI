-- Lua provided by SkyAPI 
-- Game: The Rabbit Hole Remastered
addappid(529630)
addappid(529631, 1, "8e17543439d1709b531698d78aa60245e5900dfe8a8f32cf840eda9c2bec09b4")
