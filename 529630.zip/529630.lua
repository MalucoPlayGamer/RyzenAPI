-- Lua provided by RyzenAPI
-- Game: Game: The Rabbit Hole Remastered

-- MAIN APPLICATION
addappid(529630)
-- Game: addappid(529630)

-- MAIN APP DEPOTS / PACKAGES
addappid(529631, 1, "8e17543439d1709b531698d78aa60245e5900dfe8a8f32cf840eda9c2bec09b4")
