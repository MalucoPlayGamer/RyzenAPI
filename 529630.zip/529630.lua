-- Lua provided by RyzenAPI
-- Game: The Rabbit Hole Remastered

-- MAIN APPLICATION
addappid(529630)

-- MAIN APP DEPOTS / PACKAGES
addappid(529631, 1, "8e17543439d1709b531698d78aa60245e5900dfe8a8f32cf840eda9c2bec09b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
