-- Lua provided by RyzenAPI
-- Game: Loud or Quiet

-- MAIN APPLICATION
addappid(731190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(731191, 1, "ee1d49a9618362ebbbeca2e13e6c2d93af2a7edf39c274712606f916c497cdb4")

