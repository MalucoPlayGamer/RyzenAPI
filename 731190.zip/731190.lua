-- Lua provided by RyzenAPI
-- Game: Loud or Quiet

-- MAIN APPLICATION
addappid(731190)

-- MAIN APP DEPOTS / PACKAGES
addappid(731191, 1, "ee1d49a9618362ebbbeca2e13e6c2d93af2a7edf39c274712606f916c497cdb4")

