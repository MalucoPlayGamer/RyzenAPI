-- Lua provided by RyzenAPI
-- Game: Rescue Team: Evil Genius

-- MAIN APPLICATION
addappid(1155340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155341, 1, "bc4710f43e7c62fa7034880de1b3adcb535aed3ea4f15696fe81709cb1f83701")
addappid(1155344, 1, "6f6e6eb9ed2bf5cf480be029f62ff6e382af4451d0216973604b77e9354d0c82")

