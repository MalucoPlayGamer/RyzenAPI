-- Lua provided by RyzenAPI
-- Game: Space Tail: Definitive Edition

-- MAIN APP DEPOTS / PACKAGES
addappid(3882980, 1, "659ebdcc60e21cf4b213fda84595ac0f21afa5037c3dca44f33fea4abab3f655") -- Space Tail: Definitive Edition
addappid(3882981, 1, "69e93a4e9766430874e8dc4558367a3d1e4a10cb3bf18b7479abc5009a1df855") -- Depot 3882981

