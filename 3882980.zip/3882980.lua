-- 3882980's Lua and Manifest Created by Hubcap Manifest
-- Space Tail: Definitive Edition
-- Created: August 03, 2026 at 22:43:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3882980, 1, "659ebdcc60e21cf4b213fda84595ac0f21afa5037c3dca44f33fea4abab3f655") -- Space Tail: Definitive Edition
-- MAIN APP DEPOTS
addappid(3882981, 1, "69e93a4e9766430874e8dc4558367a3d1e4a10cb3bf18b7479abc5009a1df855") -- Depot 3882981
setManifestid(3882981, "6028918498607269492", 13476519500)