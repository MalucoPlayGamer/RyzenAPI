-- Lua provided by RyzenAPI
-- Game: 1959350

-- MAIN APPLICATION
addappid(1959350)
-- Game: addappid(1959350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959351, 1, "7aa4e70d229c7e1f3b612a0580d0104b6838d0f20d08651e99ade091d0138cbe")
