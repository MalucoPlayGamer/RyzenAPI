-- Lua provided by SkyAPI 
-- Game: Lighthouse Simulator
addappid(2540980)
addappid(2540981, 1, "dd40eb4b4e542e68d83c8f48dc1e9711d1f38cecf4eb34a391367357041725ed")
