-- Lua provided by RyzenAPI
-- Game: addappid(2275020)

-- MAIN APPLICATION
addappid(2275020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275021, 1, "b329217cf9acf1faa28049bc399d5209cb8fd1c89f43c06c88bed59e19e3ca4e")
