-- Lua provided by RyzenAPI
-- Game: Super Robot Jump Jump

-- MAIN APPLICATION
addappid(422980)

-- MAIN APP DEPOTS / PACKAGES
addappid(422982,0,"2e107c3a6242a402bb25f57955df78d168318e40cc7053b4fdfc23af284f41d5")

