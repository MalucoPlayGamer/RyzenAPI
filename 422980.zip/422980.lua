-- Lua provided by RyzenAPI
-- Game: setManifestid(422982,"5642279819933567782")

-- MAIN APPLICATION
addappid(422980)
-- Game: addappid(422980)

-- MAIN APP DEPOTS / PACKAGES
addappid(422982,0,"2e107c3a6242a402bb25f57955df78d168318e40cc7053b4fdfc23af284f41d5")
