-- Lua provided by RyzenAPI
-- Game: Game: AppID 1679250

-- MAIN APPLICATION
addappid(1679250)
-- Game: addappid(1679250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679251, 1, "3c8227c2cb76d2e6e98a2453582d099e1cee8cba3d5321552a266704e488127a")
