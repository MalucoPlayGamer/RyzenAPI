-- Lua provided by RyzenAPI
-- Game: 624622

-- MAIN APPLICATION
addappid(624622)
-- Game: addappid(624622)

-- MAIN APP DEPOTS / PACKAGES
addappid(762730,0,"d9969fc225d52c22003bab9092a13b5b2b40e8b35aadd653952e68da0bc637b2")
