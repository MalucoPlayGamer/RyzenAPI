-- Lua provided by RyzenAPI
-- Game: Astral Quester

-- MAIN APPLICATION
addappid(2556050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556051, 1, "22c9383168d973bfc6ce3e6cf7af57ca4879c8d2bff7039c3d31ad9129db86a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
