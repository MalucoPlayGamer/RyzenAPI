-- Lua provided by RyzenAPI
-- Game: 2556050

-- MAIN APPLICATION
addappid(2556050)
-- Game: addappid(2556050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556051, 1, "22c9383168d973bfc6ce3e6cf7af57ca4879c8d2bff7039c3d31ad9129db86a0")
