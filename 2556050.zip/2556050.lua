-- Lua provided by SkyAPI 
-- Game: Astral Quester
addappid(2556050)
addappid(2556051, 1, "22c9383168d973bfc6ce3e6cf7af57ca4879c8d2bff7039c3d31ad9129db86a0")
