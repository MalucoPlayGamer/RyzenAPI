-- Lua provided by RyzenAPI
-- Game: 3052420

-- MAIN APPLICATION
addappid(3052420)
-- Game: addappid(3052420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052421, 1, "cde5d50fe9a5fa6d3203d173dea3a5e4caae84629c6a5f7de9af1fc87d701d89")
