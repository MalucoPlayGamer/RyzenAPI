-- Lua provided by RyzenAPI
-- Game: Inzo

-- MAIN APPLICATION
addappid(827950)

-- MAIN APP DEPOTS / PACKAGES
addappid(827951,0,"66722d4eab2fcfdaa1173bf923fae0e4f424829e9a3cd5f29caf51d99362f8d5")

