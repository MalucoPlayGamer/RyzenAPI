-- Lua provided by RyzenAPI
-- Game: addappid(668570)

-- MAIN APPLICATION
addappid(668570)

-- MAIN APP DEPOTS / PACKAGES
addappid(668572,0,"28357771216cb69704d913dc8192a5c610f0e670d7d5bf981bcac19ae0e02b99")
