-- Lua provided by RyzenAPI 
-- Game: AppID 1510700
addappid(1510700)
addappid(1510701, 1, "d41f4a30f663070c45100b3cfdca1986cc760869fc2b1f55e80409cd95fdaea6")
