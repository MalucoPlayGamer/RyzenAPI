-- Lua provided by RyzenAPI
-- Game: 1510700

-- MAIN APPLICATION
addappid(1510700)
-- Game: addappid(1510700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510701, 1, "d41f4a30f663070c45100b3cfdca1986cc760869fc2b1f55e80409cd95fdaea6")
