-- Lua provided by RyzenAPI
-- Game: Designated Driver Simulator

-- MAIN APPLICATION
addappid(1813640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813642,0,"167658aee46187f26e5750d1cc54f667f63be0695b4c90482443a3db840f457a")

