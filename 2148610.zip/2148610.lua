-- Lua provided by RyzenAPI
-- Game: 2148610

-- MAIN APPLICATION
addappid(2148610)
-- Game: addappid(2148610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148611, 1, "800e62f7a0e26410cb4fca2ee72c8dec440eadeece24e2031120728f27e1540c")
