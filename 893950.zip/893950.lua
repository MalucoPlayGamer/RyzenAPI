-- Lua provided by RyzenAPI
-- Game: AppID 893950

-- MAIN APPLICATION
addappid(893950)

-- MAIN APP DEPOTS / PACKAGES
addappid(893951, 1, "e79eeb63285c1ea8fcd38919ca5ada2a25a5acace8fc21c364da82497c5575ec")

