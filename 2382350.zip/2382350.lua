-- Lua provided by RyzenAPI
-- Game: Rainbow Rendezvous

-- MAIN APPLICATION
addappid(2382350)
-- Game: addappid(2382350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382351, 1, "89c3ba6cb49878d3764bcaee12d9e98bfb6c81c9a265df374c81d25baae013cd")
