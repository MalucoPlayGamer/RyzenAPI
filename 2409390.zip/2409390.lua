-- Lua provided by RyzenAPI
-- Game: Wheelie Life

-- MAIN APPLICATION
addappid(2409390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409391, 1, "7dc47961788254aabb884f30387519c2580d60e6a04ccbfe3b4d3ca83818f832")

