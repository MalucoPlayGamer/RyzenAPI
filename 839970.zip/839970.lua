-- Lua provided by RyzenAPI
-- Game: Mr Rabbit's Memory Game

-- MAIN APPLICATION
addappid(839970)
-- Game: addappid(839970)

-- MAIN APP DEPOTS / PACKAGES
addappid(839971, 1, "3ccd51ee17a7bb73c4b430431c1790798a3cc3b2d35aa8d6677a33b32b847ca0")
