-- Lua provided by RyzenAPI
-- Game: addappid(962950)

-- MAIN APPLICATION
addappid(962950)

-- MAIN APP DEPOTS / PACKAGES
addappid(962951, 1, "a053cbdc436025ad579dad2066be867c0c4fcb86bc836539a729b5dcaae88c64")
