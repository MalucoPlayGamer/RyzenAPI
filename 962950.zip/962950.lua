-- Lua provided by RyzenAPI
-- Game: 执行人 Executor

-- MAIN APPLICATION
addappid(962950)

-- MAIN APP DEPOTS / PACKAGES
addappid(962951, 1, "a053cbdc436025ad579dad2066be867c0c4fcb86bc836539a729b5dcaae88c64")

