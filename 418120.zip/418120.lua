-- Lua provided by RyzenAPI
-- Game: Game: Cally's Caves 3

-- MAIN APPLICATION
addappid(418120)
-- Game: addappid(418120)

-- MAIN APP DEPOTS / PACKAGES
addappid(418121, 1, "2326e7d2234622a1a1db41786510ed8ba6150d82bd1431aeb061166d5c6fb936")
addappid(422120, 0, "aedc8c73c7d5d332ea5dfd08cc0ff2e1d6c4d351e5999b5f91d4c968e97d20ab")
