-- Lua provided by RyzenAPI
-- Game: Submerged OST

-- MAIN APPLICATION
addappid(389830)
-- Game: addappid(389830)

-- MAIN APP DEPOTS / PACKAGES
addappid(389831, 1, "3fe6eeafb855a01cf1b51db28e0ae8ae9a372d514a6f03197dd9ce995295ea48")
