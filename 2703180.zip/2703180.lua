-- Lua provided by RyzenAPI
-- Game: addappid(2703180)

-- MAIN APPLICATION
addappid(2703180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703181, 1, "5d015c2718d275a82659e7982f81c4eb6e494e2f19e089c2ebc74de1baafdddd")
