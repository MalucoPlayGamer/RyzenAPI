-- Lua provided by RyzenAPI
-- Game: addappid(3608980)

-- MAIN APPLICATION
addappid(3608980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3608980,0,"a666d5ee95f80820bee172ddb777e93c1c7a08bd60a58ce964d67a521e7cac1b")
