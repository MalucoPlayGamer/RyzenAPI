-- Lua provided by RyzenAPI
-- Game: Magic Flute

-- MAIN APPLICATION
addappid(437710)

-- MAIN APP DEPOTS / PACKAGES
addappid(437711, 1, "5884855700794c619efb6c076ed0d4c01d48fa8f32f6b650d2d547455c1b2fb0")
addappid(437712, 1, "984abe536f3fa1ffd74989556e006df70bdfe9c689e070a2db2281b5769d75cd")
