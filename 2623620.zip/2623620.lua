-- Lua provided by RyzenAPI
-- Game: Feudal Baron: King's Land Demo

-- MAIN APPLICATION
addappid(2623620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623621, 1, "cf6d0a959651bb7b2ca08bc05ef24407b6b2d56c5b9b3cd7a8e774e1c41e1e8d")
