-- Lua provided by RyzenAPI
-- Game: Psikodelya

-- MAIN APPLICATION
addappid(742510)
addappid(1147230)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(742511, 1, "e7f757ba1eefa6a2145937e431b9016fb3a0032d898c826f6470e01eb423333f")

