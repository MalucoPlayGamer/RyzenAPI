-- Lua provided by RyzenAPI
-- Game: Psikodelya

-- MAIN APPLICATION
addappid(742510)
-- Game: addappid(742510)

-- MAIN APP DEPOTS / PACKAGES
addappid(742511, 1, "e7f757ba1eefa6a2145937e431b9016fb3a0032d898c826f6470e01eb423333f")
