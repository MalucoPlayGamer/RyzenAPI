-- Lua provided by RyzenAPI
-- Game: NinNinDays

-- MAIN APPLICATION
addappid(1075980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1075981, 1, "a12d065ed6e51cd8212c96f5d08fa845cdcf8f547b3c6d217a455a55ee406ef6")

