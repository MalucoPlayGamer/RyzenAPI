-- Lua provided by RyzenAPI
-- Game: 1075980

-- MAIN APPLICATION
addappid(1075980)
-- Game: addappid(1075980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075981, 1, "a12d065ed6e51cd8212c96f5d08fa845cdcf8f547b3c6d217a455a55ee406ef6")
