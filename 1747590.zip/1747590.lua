-- Lua provided by RyzenAPI
-- Game: Kenopsia

-- MAIN APPLICATION
addappid(1747590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747591, 1, "73452b28b673c255295b7ae1264ff6fb40ac4506593a5a4f056b8e5765c7f4c5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
