-- Lua provided by SkyAPI 
-- Game: Kenopsia
addappid(1747590)
addappid(1747591, 1, "73452b28b673c255295b7ae1264ff6fb40ac4506593a5a4f056b8e5765c7f4c5")
