-- Lua provided by RyzenAPI
-- Game: GWENT: Rogue Mage (Single-Player Expansion)

-- MAIN APPLICATION
addappid(1711950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711951, 1, "28677b3393cbc65a63af325e63ea4d312f46b352ea2311887fc8acd8906cb443")
addappid(1711952, 1, "698ac76435e63cdd1283afd4e89e28545bed45d3e972334c08819fa3b98508c9")
addappid(1711953, 1, "037e56e9298c4b9102863c5ced635b48b8cfb9f13fd6645efead26a3ebbefbcc")
addappid(1711954, 1, "6e2f48cc2105b377be09a1edacf260fb41f27619ae9baacde9dd5a1383c66494")
addappid(1711955, 1, "09097f0b0d3ecf439af8068aef085ea930e1a0809d4387902c279d5f2fa08bb6")
addappid(1711956, 1, "cfebff9f2fb85258e6d72d95275a31b24aa5c1020a073ebd45068aa3361ce0fc")

