-- Lua provided by RyzenAPI
-- Game: Pixel Heroes: Byte & Magic

-- MAIN APPLICATION
addappid(338320)
addappid(338323)

-- MAIN APP DEPOTS / PACKAGES
addappid(338322,0,"c8158fe7c86dfc4bd502083a838ebda557d446242618e1547e3e85b8cf85e1ec")
addappid(338324,0,"c268a4431488487f95c162829230ceb7ed40632fb988ffcbcbb5e14eadc9f298")

