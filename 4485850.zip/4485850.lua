-- 4485850's Lua and Manifest Created by Hubcap Manifest
-- Old Coin Pusher Gaiden
-- Created: August 12, 2026 at 22:54:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4485850) -- Old Coin Pusher Gaiden
-- MAIN APP DEPOTS
addappid(4485851, 1, "2afd844d866f74b1b769c73bae7db78452034add26cf9d814de6e5b7ad326079") -- Depot 4485851
setManifestid(4485851, "4609305808578969876", 1049455663)