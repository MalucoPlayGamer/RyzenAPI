-- Lua provided by RyzenAPI
-- Game: Old Coin Pusher Gaiden

-- MAIN APPLICATION
addappid(4485850) -- Old Coin Pusher Gaiden

-- MAIN APP DEPOTS / PACKAGES
addappid(4485851, 1, "2afd844d866f74b1b769c73bae7db78452034add26cf9d814de6e5b7ad326079") -- Depot 4485851

