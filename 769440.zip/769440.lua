-- Lua provided by RyzenAPI
-- Game: Beach Restaurant

-- MAIN APPLICATION
addappid(769440)

-- MAIN APP DEPOTS / PACKAGES
addappid(769441, 1, "f9b51b90c3c96fdd8438cd54f67e3444209fa6907153419c89f336fda2635e2b")

