-- Lua provided by RyzenAPI
-- Game: 820060

-- MAIN APPLICATION
addappid(820060)
-- Game: addappid(820060)

-- MAIN APP DEPOTS / PACKAGES
addappid(820061, 1, "74b6b78e67328d8b87e9d2a42c16741a0fdc0b8abac9dde3e1c9423eb181cb2c")
