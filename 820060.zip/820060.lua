-- Lua provided by SkyAPI 
-- Game: AppID 820060
addappid(820060)
addappid(820061, 1, "74b6b78e67328d8b87e9d2a42c16741a0fdc0b8abac9dde3e1c9423eb181cb2c")
