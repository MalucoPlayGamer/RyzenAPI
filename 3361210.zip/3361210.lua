-- Lua provided by RyzenAPI
-- Game: BROK - Natal Tail, A New Christmas

-- MAIN APPLICATION
addappid(3361210)
addappid(3365410)
-- Game: addappid(3361210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361211, 1, "046f7c835962865b40422da38a9ea34250e3f6c00745b9b6b27c014c07d01c42")
addappid(3361212, 1, "3f3d6350fa6f6e0ddb8a8b0dc5f0d63ffabcc1b54edb95cece73b397735c5778")
