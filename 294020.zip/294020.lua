-- Lua provided by RyzenAPI
-- Game: Merchants of Kaidan

-- MAIN APPLICATION
addappid(294020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(294021, 1, "0e59e7aefff7f894c7e597a27b36c67e5740f04e2544b0159e5d0c63d4bd871e")
addappid(294022, 1, "69a79fb97912c49503d4078a37890ce3bf1f687330ee8759ce45912fdd83e48a")
addappid(294023, 1, "679db09cd9db52c78b3cff7956d38be6e6b6c1fb60a67d64bef3b9854a480716")
addappid(294024, 1, "92761ff353e3257739eae34bad1b482ce1b78fc973eeb22aaa5d2523f03935d1")

