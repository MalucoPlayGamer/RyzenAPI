-- Lua provided by RyzenAPI
-- Game: Bottle Can Float

-- MAIN APPLICATION
addappid(2576600)
addappid(4044630)
-- Game: addappid(2576600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576601, 1, "f98a7893224d4014f198d6ca6bfe6a3299ed124b66f6bfd5deded0a76b682e28")
