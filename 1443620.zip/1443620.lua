-- Lua provided by RyzenAPI
-- Game: Pirates VR: Jolly Roger

-- MAIN APPLICATION
addappid(1443620)
-- Game: addappid(1443620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443621, 1, "1830a3a2b0baf49cc942d6979631b07c2b1ad486ef05ba95d2dd169c727312ee")
