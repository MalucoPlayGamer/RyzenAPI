-- Lua provided by RyzenAPI
-- Game: Resident Evil Re:Verse - Ada Skin: Still Kicking (The Umbrella Chronicles)

-- MAIN APPLICATION
addappid(1607013)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607013,0,"d8c652a69968a515baed2389fa1348eda69435b3b3e5be229afc0650a2303018")
