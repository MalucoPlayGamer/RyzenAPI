-- Lua provided by RyzenAPI
-- Game: AppID 698490

-- MAIN APPLICATION
addappid(698490)
-- Game: addappid(698490)

-- MAIN APP DEPOTS / PACKAGES
addappid(698491, 1, "6f99b5fcec76109ea2abeffe5169c902722e7201746b8f0d121b6ebebe743ee6")
