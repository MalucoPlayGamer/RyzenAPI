-- Lua provided by RyzenAPI 
-- Game: Smart Factory Tycoon: Beginnings
addappid(1810980)
addappid(1810981, 1, "45c09a2ccb7911a704e69c491756f9a0b57bed514b262d8f3ae91ff5f38efec9")
