-- Lua provided by RyzenAPI
-- Game: addappid(828350)

-- MAIN APPLICATION
addappid(828350)

-- MAIN APP DEPOTS / PACKAGES
addappid(828351, 1, "fc4a0e82a3de5d8de876c1b92bc1011742a693147d1e86825a938fc2dda15cc5")
