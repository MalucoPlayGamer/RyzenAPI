-- Lua provided by RyzenAPI 
-- Game: AppID 1155650
addappid(1155650)
addappid(1155651, 1, "14669bfbc48cd6c0ba4101eacf8dbea1d95e2538b26f061d15b6d7b1cab5200e")
