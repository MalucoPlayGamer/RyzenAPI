-- Lua provided by RyzenAPI
-- Game: Shady Knight

-- MAIN APPLICATION
addappid(1155650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155651, 1, "14669bfbc48cd6c0ba4101eacf8dbea1d95e2538b26f061d15b6d7b1cab5200e")
