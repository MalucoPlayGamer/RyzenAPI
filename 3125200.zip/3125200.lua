-- Lua provided by RyzenAPI
-- Game: Game: Maiden Cops Soundtrack

-- MAIN APPLICATION
addappid(3125200)
-- Game: addappid(3125200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125201, 1, "78ec23ff56555fca9df9aca4d2853d3d347e5819d2824117d1da2b03dac7e474")
