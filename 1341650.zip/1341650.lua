-- Lua provided by RyzenAPI
-- Game: addappid(1341650)

-- MAIN APPLICATION
addappid(1341650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341651, 1, "8618ba25cf0759fe75b027f8ff60b7b9e649adfc782f826145b82cad0ab97646")
