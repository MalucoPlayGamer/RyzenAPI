-- Lua provided by SkyAPI 
-- Game: Police Shootout: Prologue
addappid(1661280)
addappid(1661281, 1, "2b8701e69b5e61971735aa6bca4baab971ed48d552498737e63fc3e79488de3e")
