-- Lua provided by RyzenAPI
-- Game: Police Shootout: Prologue

-- MAIN APPLICATION
addappid(1661280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1661281, 1, "2b8701e69b5e61971735aa6bca4baab971ed48d552498737e63fc3e79488de3e")

