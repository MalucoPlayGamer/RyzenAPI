-- Lua provided by RyzenAPI
-- Game: AppID 1098080

-- MAIN APPLICATION
addappid(1098080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098081, 1, "d444d2f1fa20485f3ea9d1682185b6f9fb403eb761994e113ac2c01e11d07749")
addappid(1098082, 1, "aae9510256a58a5f4d8edfef2952a66665c65e4d9d0431877b3759a5a2ce2305")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1296790)
