-- Lua provided by RyzenAPI
-- Game: Touhou Kikamu ~ Elegant Impermanence of Sakura

-- MAIN APPLICATION
addappid(1252320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252321, 1, "0c1bbebd07a8afbcdd563aa6b8f458628fbb9b2642878fc239121f2a476f19ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
