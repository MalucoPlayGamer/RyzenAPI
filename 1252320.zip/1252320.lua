-- Lua provided by RyzenAPI
-- Game: Touhou Kikamu ~ Elegant Impermanence of Sakura

-- MAIN APPLICATION
addappid(1252320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252321, 1, "0c1bbebd07a8afbcdd563aa6b8f458628fbb9b2642878fc239121f2a476f19ba")

