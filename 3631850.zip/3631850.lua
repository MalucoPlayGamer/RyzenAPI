-- Lua provided by SkyAPI 
-- Game: Kyoto Anomaly
addappid(3631850)
addappid(3631851, 1, "47731a005e2bb4dab265a0a8ba8d12dbb8b2854da14cd538c6ab9b7e1f4465a3")
