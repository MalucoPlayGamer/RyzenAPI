-- Lua provided by RyzenAPI
-- Game: Game: The Eyes of Ara

-- MAIN APPLICATION
addappid(454250)
-- Game: addappid(454250)

-- MAIN APP DEPOTS / PACKAGES
addappid(454251, 1, "9e938a244e59c74c02090ef78720dca302b44ff1b8cc37f546f9b1b8d1489bb4")
addappid(454252, 1, "09496aedb0ae1d755378ad2e67f529fa7a47ccf3eed69e7bab8e1fbd318d6c0e")
addappid(534930, 0, "a772d275d17b9174a85cb507302bfd5df48f570ef10c2b0bc97929efead7b89d")
addappid(534931, 0, "698f3f8e2cff2c2e27844e44281b269eee327bc168d5f5ec6f1766d6b5393c40")
addappid(534938, 0, "b172359e707e4bbd0a7b4d64c4bd551a3bc508cf3ba74641b1000132a9cefabe")
addappid(695580, 0, "d035898841bcc4305657dc7f1e8c92348a3c4c0d2593e7ef344f246a8c66b8bd")
