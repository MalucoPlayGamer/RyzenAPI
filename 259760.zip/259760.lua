-- Lua provided by SkyAPI 
-- Game: Two Brothers
addappid(259760)
addappid(259761, 1, "13ed97c072371fb37e938385b6c3c525a456fb306c65ff0cfd34ebe15185221f")
