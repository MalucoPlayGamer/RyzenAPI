-- Lua provided by RyzenAPI
-- Game: Two Brothers

-- MAIN APPLICATION
addappid(259760)

-- MAIN APP DEPOTS / PACKAGES
addappid(259761, 1, "13ed97c072371fb37e938385b6c3c525a456fb306c65ff0cfd34ebe15185221f")
