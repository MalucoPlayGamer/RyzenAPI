-- Lua provided by RyzenAPI
-- Game: 心境 VR / Mind VR Exploration

-- MAIN APPLICATION
addappid(1383450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383451, 1, "4b675e74e9dff0211427bdc50e7690dabead5066dd65f2f00717fa6b77eb0d78")
