-- Lua provided by RyzenAPI
-- Game: 心境 VR / Mind VR Exploration

-- MAIN APPLICATION
addappid(1383450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1383451, 1, "4b675e74e9dff0211427bdc50e7690dabead5066dd65f2f00717fa6b77eb0d78")

