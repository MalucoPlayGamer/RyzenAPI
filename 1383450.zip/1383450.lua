-- Lua provided by SkyAPI 
-- Game: 心境 VR / Mind VR Exploration
addappid(1383450)
addappid(1383451, 1, "4b675e74e9dff0211427bdc50e7690dabead5066dd65f2f00717fa6b77eb0d78")
