-- Lua provided by SkyAPI 
-- Game: Alice: Madness Returns
addappid(19680)
addappid(19681, 1, "135ae209e08a706bf2c81cb002c4b9668d701c62691f592b8bea4733724f5ec3")
