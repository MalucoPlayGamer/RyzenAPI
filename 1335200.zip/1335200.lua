-- Lua provided by RyzenAPI
-- Game: Action Taimanin

-- MAIN APPLICATION
addappid(1335200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335201, 1, "4db5f4b059a7a18fd60a8c50d8ac74ed295bbb40a87e93eef2e9f05a814c8adb")

