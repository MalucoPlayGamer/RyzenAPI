-- Lua provided by RyzenAPI
-- Game: Action Taimanin

-- MAIN APPLICATION
addappid(1335200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1335201, 1, "4db5f4b059a7a18fd60a8c50d8ac74ed295bbb40a87e93eef2e9f05a814c8adb")

