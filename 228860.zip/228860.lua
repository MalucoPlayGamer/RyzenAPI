-- Lua provided by RyzenAPI
-- Game: 228860

-- MAIN APPLICATION
addappid(228860)
-- Game: addappid(228860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228861, 1, "727ea3553b5978097d0331c7412a4f5245efe72ff190f08d3980ab79f99b3dd5")
