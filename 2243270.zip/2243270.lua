-- Lua provided by SkyAPI 
-- Game: AppID 2243270
addappid(2243270)
addappid(2243271, 1, "d9f67b0884fba83267e9a785f91426cd2a96f298d01221c768a2a77489f5638d")
