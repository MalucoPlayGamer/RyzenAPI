-- Lua provided by RyzenAPI
-- Game: 722180

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(722180)
-- Game: addappid(722180)

-- MAIN APP DEPOTS / PACKAGES
addappid(722183,0,"a12548cea24c062b88263dea80ca2a80430660f118155d256b6436038442f3c5")
