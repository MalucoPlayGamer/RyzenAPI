-- Lua provided by RyzenAPI
-- Game: PROTON VR

-- MAIN APPLICATION
addappid(3143930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143931, 1, "a83fd48340ead14158dad6e3aad9ee6d54e0df65f89efbf57195b70fff7f564b")

