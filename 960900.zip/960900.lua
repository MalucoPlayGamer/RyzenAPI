-- Lua provided by RyzenAPI
-- Game: 960900

-- MAIN APPLICATION
addappid(960900)
-- Game: addappid(960900)

-- MAIN APP DEPOTS / PACKAGES
addappid(960901, 1, "2e9dbb5be336bc4974d3acde23dd0709b7cc37184a1980fbc3305fcf841896e6")
