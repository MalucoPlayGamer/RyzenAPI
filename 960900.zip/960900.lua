-- Lua provided by RyzenAPI
-- Game: Lornsword Winter Chronicle

-- MAIN APPLICATION
addappid(960900)

-- MAIN APP DEPOTS / PACKAGES
addappid(960901, 1, "2e9dbb5be336bc4974d3acde23dd0709b7cc37184a1980fbc3305fcf841896e6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
