-- Lua provided by RyzenAPI
-- Game: PROJECT 13 Perception Test

-- MAIN APPLICATION
addappid(3077130)
-- Game: addappid(3077130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077131, 1, "05ba87135d15b2713755588f2edf04970881d1f449badc285dba3020ac32296f")
