-- Lua provided by RyzenAPI
-- Game: Đồng Cỏ Lau - The Reed Field

-- MAIN APPLICATION
addappid(3985730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3985731,0,"ff89ee75756535bd73fcff4befa1e5b34deb8f91b3fb2fe103b3f7ea8d5f5a81")

