-- Lua provided by RyzenAPI
-- Game: Metal as Phuk

-- MAIN APPLICATION
addappid(662210)

-- MAIN APP DEPOTS / PACKAGES
addappid(662211, 1, "ed60e1660c3d330960c8c4ce33edd1e5dba57aa12d3a71a5f2ef8afa3ad9113c")
