-- Lua provided by RyzenAPI
-- Game: Total War: SHOGUN 2

-- MAIN APPLICATION
addappid(34330)
addappid(34342) -- Total War: SHOGUN 2 - Sengoku Jidai Unit Pack DLC
addappid(34343) -- Total War: SHOGUN 2 - Rise of the Samurai Campaign DLC
addappid(34344) -- Total War: Shogun 2 - Unused DLC
addappid(34345) -- Total War: SHOGUN 2 - Hattori Clan Pack DLC
addappid(34346) -- Total War: SHOGUN 2 - Battle Bonus DLC
addappid(34347) -- Total War: SHOGUN 2 - Currency Bonus DLC
addappid(34348) -- Total War: SHOGUN 2 - Ikko Ikki Clan Pack DLC
addappid(201270) -- Total War: SHOGUN 2
addappid(201271)
addappid(201272) -- Total War: SHOGUN 2 - Blood Pack DLC
addappid(201273) -- Total War: SHOGUN 2 - Fall of the Samurai - Saga Faction Pack DLC
addappid(201274) -- Total War: SHOGUN 2 - Fall of the Samurai - Obama Faction Pack DLC
addappid(201275) -- Total War: SHOGUN 2 - Fall of the Samurai - Tsu Faction Pack DLC
addappid(201276) -- Total War: SHOGUN 2 - Fall of the Samurai - Sendai Faction Pack DLC
addappid(201277) -- Total War: SHOGUN 2 - Dragon War Battle Pack
addappid(201278)
addappid(201279) -- Total War: SHOGUN 2 - Saints and Heroes DLC
addappid(203710) -- DLC 203710
addappid(223180) -- Total War: SHOGUN 2 - Otomo Clan Pack
addappid(223181) -- SHOGUN 2 Otomo Clan Pack DLC Pre-Purchase
addappid(2028023) -- A Total War Saga: FALL OF THE SAMURAI – Blood Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(34330, 1, "db752e6cae43e9d2d14ba61659d82c6484792aa8ca8d1fe37e386fed68195a22")
addappid(34331, 1, "331d98adf1f18ee81fafd99f9bc1217c5e9cde84c74d1995aecaa5f020dcd4a1") -- (windows)
addappid(34332, 1, "ae8ff60604d56d148c2491b100dd0d90572a0d2f218aa7b616d12fed2f35fcbf") -- (windows)
addappid(34333, 1, "940ffb223c110eb32e04fa8c97ed5514d9404540bdba0a1eb54621376d0741b7") -- (windows)
addappid(34334, 1, "0c50a3378b3489d46b8fa596974699e72201b403d91a9671b18de15057d6cd97") -- English (windows)
addappid(34335, 1, "7dec20909cba1c48e881b2adf5947dd0dca0f6832ffc87bc8b2c4be9e7477928") -- Czech (windows)
addappid(34336, 1, "be07942b438d659f16920e2288f7e881f4b9da7acad9b58c143c85fc3b1b309b") -- French (windows)
addappid(34337, 1, "03e859576ca29a73fc4000e3eb729dc8cc62aeeba54575dabe637c6b0175d124") -- German (windows)
addappid(34338, 1, "e639988f2850a5ed361758885dee750effc626a8ad28bcccd68d8bca60f7d5a0") -- Italian (windows)
addappid(34339, 1, "af670eeb71b75c233b51759222a20e8fe03a7b2c53c315aa8c9707457f21cb2e") -- Polish (windows)
addappid(34340, 1, "7001a192a51af7254a614ecf4ab4e3ca4d95d28570b9775ccdab99619aa2576c") -- Russian (windows)
addappid(34341, 1, "b04cc3eb897c57f6e0e1488458911bf583db9b4cb64b6aa17eeaff7c0262354b") -- Spanish (windows)
addappid(34349, 1, "5a60b1d4d4c5ae2bbec58750f4b7089e5c6f1ae432956d56b2c39cd26128a2f9") -- (macos)
addappid(34362, 1, "33b5f85834b61432e68195fd322d6d42ff585ec91e45e4310543460c9a1e80e2") -- Japanese (windows)
addappid(201271, 1, "d9c1f6504fc1063881c3d328b6c231251e6cb5a567a37dc599d1991958ffafc1") -- (windows)
addappid(201278, 1, "07e144f81158f5f1dfc5a12328f9b4d281a1e1eceb94835110df4a8f7a1a03e4") -- (windows)
addappid(203711, 1, "4b73f690b1c86e732c067e0dfecf42f96feb7b17a50d8accbca0ebfd4a2e1cc4") -- (macos)
addappid(203712, 1, "9ea52337e7702cc76a642f19c540b862db744bb3e0360be87e38f65f17ea3df8") -- (macos)
addappid(203713, 1, "fe152f1ba73f301708ab728e300e84168aff955f6bcf1ad6bfed340f800bb74a") -- (macos)
addappid(203714, 1, "54c7ac1c049d8da4f7b4561a07224edf666a369bdc158730bf48e44d8b4da81f") -- English (macos)
addappid(203715, 1, "212fd0d7856e4ea82d6a9cf12a6dddf97cf7e371b1e25838bf372defb7e92621") -- Czech (macos)
addappid(203716, 1, "a8c6f1c80cf18ab33527be8dea3855410606c9040506d023c9f594573bb93c9c") -- French (macos)
addappid(203717, 1, "1657a36b02cf3531ed74c8ddf0a4053134e9bd169aa64b630a9fa0a59294be76") -- German (macos)
addappid(203718, 1, "f3d16b521bab079af3811459de29a13e636933f7706dd3bf8f6c74004cb043f1") -- Italian (macos)
addappid(203719, 1, "58a5182f2ae80c73ffec51dbd161fa60380e6e2f5925b85038b285143265b98a") -- Polish (macos)
addappid(203720, 1, "dafa2a9bd663c866c4b708e2592288dd3416801e001c0a5dbe3f142e8247c74a") -- Russian (macos)
addappid(203721, 1, "1344d17cd26c43d849f1ba429c1aac2b10308703de3094bee7cc39df8cbb25d6") -- Spanish (macos)
addappid(203722, 1, "5ee59c1af92f6465272f8c5e0881d0c61be4cab151d8348c8b04243e03ffdcea") -- Japanese (macos)
addappid(203723, 1, "16e06bb282d3df7c391dde49701fd9ed4834274b6d5768e65d597bae2a158f57") -- (linux)
addappid(203724, 1, "655c88a48273c76d575a68e6f7399fead34eebf83f64791214c78f073ab2cfc4") -- (linux)
addappid(203726, 1, "cb5f59b89fbe7abeb2d78ef4324cf757f7f5d1ede2ea8f8a2ff38fad624af488") -- (linux)
addappid(203727, 1, "ac818ac96960f30d137514a48c355667eff1876beb7b07a028ddc327e54579dc") -- English (linux)
addappid(203728, 1, "0d1996856e41c7ecd1156eda87fd24d5634d18b964bcd17af2a6bb3a314831e4") -- Czech (linux)
addappid(203729, 1, "38342020bab4615065666ff949c637aee6fb2f09e08a3f6d6dd18f8398771160") -- French (linux)
addappid(223182, 1, "41bbf8b442b6d1963c6df75e35767131e5bb7a1dd84a2abb012b5739f7d5017d") -- German (linux)
addappid(223183, 1, "3c8b07f1e05541d51302fe250645d11ab3512413d17b6d00f47b0e84475c9a39") -- (linux)
addappid(223184, 1, "c3528ad73b32e277e66b751112033a892794eca22baff4655a87c3d9099713be") -- Italian (linux)
addappid(223185, 1, "7a3d3c700267f014d6c60f061189f49886baca6294abe0a79f903bec913f97c6") -- Polish (linux)
addappid(223186, 1, "645a0f186d6892cc27ebaab56da1b4360300107200e8b014fbe10053102631c2") -- Russian (linux)
addappid(223187, 1, "c099e44efdc1c821541613847a77f97125cc084a858a80bc0f505d4eebf6f606") -- Spanish (linux)
addappid(223188, 1, "4b5375a21105dd5f3e7e40986787c95b431b794628693b384263019427044d14") -- Japanese (linux)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(372531, 1, "85fd9e7e0a0f07b17dcb14263b94e436306270f02200d7a6669de0ba70602504") -- (windows)

