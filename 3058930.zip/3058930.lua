-- Lua provided by RyzenAPI 
-- Game: 剑箫行 Demo
addappid(3058930)
addappid(3058931, 1, "74781711c47f1a3ba267f38976353149676db38b12e1db7a5085f946ba24705d")
