-- Lua provided by RyzenAPI
-- Game: Valkeala Birds

-- MAIN APPLICATION
addappid(3331570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331571, 1, "cf0f3f3d7ab6e43d7591201244f3ed009da73897275bc7736cb690c76a446486")
