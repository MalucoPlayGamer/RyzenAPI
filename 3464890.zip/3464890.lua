-- Lua provided by RyzenAPI
-- Game: Bugtopia Demo

-- MAIN APPLICATION
addappid(3464890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464891, 1, "b3790d662f2b53a0447054933b7a4befcbb717b0ed1521615f4c365e1f5f4463")
