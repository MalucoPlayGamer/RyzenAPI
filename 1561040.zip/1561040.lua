-- Lua provided by RyzenAPI
-- Game: Diluvian Winds

-- MAIN APPLICATION
addappid(1561040)
addappid(2421930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561041, 1, "dd1a6519a91061b883989ef6d88b667a4966ef435d747182227dd712c0bfec97")
