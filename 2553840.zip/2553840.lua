-- Lua provided by RyzenAPI
-- Game: Blood, Fuel, Ammo & Speed

-- MAIN APPLICATION
addappid(2553840)
-- Game: addappid(2553840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553841, 1, "a45fc54f028ed8fc0a61c993e121fff8e216629d2a206a5de3348e5b64b11faf")
