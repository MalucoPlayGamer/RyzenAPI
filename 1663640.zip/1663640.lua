-- Lua provided by RyzenAPI
-- Game: Game: The Last Oricru - Final Cut

-- MAIN APPLICATION
addappid(1663640)
-- Game: addappid(1663640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663641, 1, "ed98535a6deba7c199d840867f451a59ec533a05306054c935ae6e33ef1ae9bc")
