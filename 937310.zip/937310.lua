-- Lua provided by RyzenAPI
-- Game: Infinitode 2 - Infinite Tower Defense

-- MAIN APPLICATION
addappid(937310)

