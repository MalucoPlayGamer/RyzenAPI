-- Lua provided by RyzenAPI
-- Game: Horror of Victim

-- MAIN APPLICATION
addappid(2800950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800951, 1, "6aa036c89d22c17ea384bd3951ba7019923e31b30450bce24dd8882c914ccd71")
