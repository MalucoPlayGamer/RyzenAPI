-- Lua provided by RyzenAPI
-- Game: Horror of Victim

-- MAIN APPLICATION
addappid(2800950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800951, 1, "6aa036c89d22c17ea384bd3951ba7019923e31b30450bce24dd8882c914ccd71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
