-- Lua provided by RyzenAPI 
-- Game: Fart King
addappid(3630870)
addappid(3630871, 1, "7715ef71c486dc8291d8ff83ca02625a84d143c7dde6ff42b1f3c7a23a292fb7")
