-- Lua provided by RyzenAPI 
-- Game: AppID 2122090
addappid(2122090)
addappid(2122091, 1, "1a85cca59ab42d72392cd3e2edac79ab499f7ddfca62510d6bd2fde853b2ad1d")
