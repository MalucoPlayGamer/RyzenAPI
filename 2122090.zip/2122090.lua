-- Lua provided by RyzenAPI
-- Game: 2122090

-- MAIN APPLICATION
addappid(2122090)
-- Game: addappid(2122090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122091, 1, "1a85cca59ab42d72392cd3e2edac79ab499f7ddfca62510d6bd2fde853b2ad1d")
