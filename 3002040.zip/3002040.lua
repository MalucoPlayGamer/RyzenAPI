-- Lua provided by RyzenAPI
-- Game: Dofamine VR

-- MAIN APPLICATION
addappid(3002040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002041, 1, "8392ed111a2fdfc5e436ad177d927c8ae338e05655603a03e6e0831a1ab2461a")
