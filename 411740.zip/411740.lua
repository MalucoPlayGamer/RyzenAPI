-- Lua provided by RyzenAPI
-- Game: Yet Another World

-- MAIN APPLICATION
addappid(411740)
-- Game: addappid(411740)

-- MAIN APP DEPOTS / PACKAGES
addappid(411741, 1, "48e957d6de630bd58bff2df57eab5dfdd3719e4907fb2897a10867c690183246")
addappid(411742, 1, "4700960a9e5c66798453506fdbb9329e26a326a000840546bc091f05d89b6c07")
addappid(411743, 1, "1b7ff7ca98fc4fa1bcfb0b4a53bbf209649fcf3508aff1cf867c0a6f835defdd")
addappid(411744, 1, "4f422100dc8fd979590f3f45ed26d8f61b3545f4ed9e8b33159e6b059726931f")
addappid(411745, 1, "bb6a95e0a4251f127ab4c4569b03901dd2872cb91feffccb0ff7e2a07fe7e0c7")
