-- Lua provided by RyzenAPI
-- Game: addappid(2460830)

-- MAIN APPLICATION
addappid(2460830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460832,0,"8efe982f9ad823559cbba1d12dcbdda2db24a384cfe4fffc66567cc5f530c87f")
