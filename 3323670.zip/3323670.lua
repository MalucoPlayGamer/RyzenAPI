-- Lua provided by RyzenAPI
-- Game: Last Shift

-- MAIN APPLICATION
addappid(3323670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3323671, 1, "cd89d5d6a9d7f284c37cfca75126d48d15787c3897a9529c56d8a8dd810e70b9")

