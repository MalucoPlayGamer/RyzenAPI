-- Lua provided by RyzenAPI
-- Game: Last Shift

-- MAIN APPLICATION
addappid(3323670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3323671, 1, "cd89d5d6a9d7f284c37cfca75126d48d15787c3897a9529c56d8a8dd810e70b9")

