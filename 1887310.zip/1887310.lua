-- Lua provided by RyzenAPI
-- Game: Paperman: Adventure Delivered

-- MAIN APPLICATION
addappid(1887310)
-- Game: addappid(1887310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887311, 1, "b62c22454ae3482be983a75b691907ae64ab73ab34266e741133c1f5c5472193")
