-- Lua provided by RyzenAPI
-- Game: Game: AppID 2156830

-- MAIN APPLICATION
addappid(2156830)
-- Game: addappid(2156830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156831, 1, "1b8ec325335d6abdaa16d99a75318d6a0ddbec08a0e1c3b7d1dfb2d188443c6c")
