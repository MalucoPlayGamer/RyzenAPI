-- Lua provided by RyzenAPI
-- Game: Game: AppID 899620

-- MAIN APPLICATION
addappid(899620)
-- Game: addappid(899620)

-- MAIN APP DEPOTS / PACKAGES
addappid(899621, 1, "87875032b58d649b9f39e1bc78d02a657385257749817de8f1eb28aa623cb617")
