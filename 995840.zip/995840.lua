-- Lua provided by RyzenAPI
-- Game: Road to Guangdong - Road Trip Car Driving Simulator Story-Based Indie Title (公路旅行驾驶游戏)

-- MAIN APPLICATION
addappid(995840)

-- MAIN APP DEPOTS / PACKAGES
addappid(995841, 1, "33a1227f4417ebcea100f4b0a34550c3425c836efcf56815e0c7436169fa4cb3")

