-- Lua provided by RyzenAPI
-- Game: AppID 805090

-- MAIN APPLICATION
addappid(805090)

-- MAIN APP DEPOTS / PACKAGES
addappid(805091, 1, "66ff0aa61592bfa0bba18f3a54e04d7d23cda452fd02dc18f24f2680b7a27675")
