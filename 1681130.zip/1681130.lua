-- Lua provided by RyzenAPI
-- Game: Warstride Challenges Demo

-- MAIN APPLICATION
addappid(1681130)
-- Game: addappid(1681130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681131, 1, "23a046f385118aa045c910221a5395a3752b6432c1d1238e644a77d615a81a5b")
