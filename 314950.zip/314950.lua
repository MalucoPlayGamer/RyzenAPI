-- Lua provided by RyzenAPI
-- Game: Game: Spectre

-- MAIN APPLICATION
addappid(314950)
-- Game: addappid(314950)

-- MAIN APP DEPOTS / PACKAGES
addappid(314951, 1, "78bc5e19b0bef0109997ea46afa7287d522d9a058c4d026af911b9559bd4258b")
addappid(314952, 1, "3070171f739fac7de4a0d71f167306795431d72793b1f624fecded8e36d9ae2e")
addappid(314953, 1, "41f849db4b6711751cfb83eba01acbd51066726c90f146287cf0247ff6656009")
