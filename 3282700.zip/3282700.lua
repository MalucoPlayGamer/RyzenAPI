-- Lua provided by RyzenAPI
-- Game: LIMINAL SHIFT

-- MAIN APPLICATION
addappid(3282700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3282701, 1, "168d492fbe75b6315d1a22bcc709e79c632578886152d8d5a6e9f4c2ca2bc7f0")

