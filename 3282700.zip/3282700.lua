-- Lua provided by RyzenAPI
-- Game: 3282700

-- MAIN APPLICATION
addappid(3282700)
-- Game: addappid(3282700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3282701, 1, "168d492fbe75b6315d1a22bcc709e79c632578886152d8d5a6e9f4c2ca2bc7f0")
