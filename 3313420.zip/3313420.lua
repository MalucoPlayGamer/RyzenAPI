-- Lua provided by RyzenAPI
-- Game: Game: 捱光：金瓶梅

-- MAIN APPLICATION
addappid(3313420)
-- Game: addappid(3313420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3313421, 1, "ca8dbb70072833b2dd42e00902caf16e9afeead04fabc282795d404b2ed0527b")
