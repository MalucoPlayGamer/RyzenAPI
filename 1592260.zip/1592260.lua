-- Lua provided by RyzenAPI
-- Game: Metamorphos

-- MAIN APPLICATION
addappid(1592260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592261, 1, "55eb08a52b6a2ca164bfd699e9e948e0d4dff8ea03efc0cbd391eda3487c727a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
