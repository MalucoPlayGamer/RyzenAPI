-- Lua provided by RyzenAPI
-- Game: Metamorphos

-- MAIN APPLICATION
addappid(1592260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592261, 1, "55eb08a52b6a2ca164bfd699e9e948e0d4dff8ea03efc0cbd391eda3487c727a")

