-- Lua provided by RyzenAPI
-- Game: 2877880

-- MAIN APPLICATION
addappid(2877880)
-- Game: addappid(2877880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877881, 1, "8557431596f8eb78915f8a13a1eb93abf4ca687ee49f318200f0bce081aa1a67")
