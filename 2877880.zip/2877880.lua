-- Lua provided by RyzenAPI
-- Game: Unbreaded

-- MAIN APPLICATION
addappid(2877880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877881, 1, "8557431596f8eb78915f8a13a1eb93abf4ca687ee49f318200f0bce081aa1a67")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
