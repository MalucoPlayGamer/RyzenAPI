-- Lua provided by RyzenAPI
-- Game: 1518153

-- MAIN APPLICATION
addappid(1518153)
-- Game: addappid(1518153)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518153,0,"e0201f4c7f897b67ae6e591bc1a50ccd0b583b8dbe427900d97381bb0b47ea08")
