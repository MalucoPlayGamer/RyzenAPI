-- Lua provided by RyzenAPI
-- Game: AppID 2557720

-- MAIN APPLICATION
addappid(2557720)
-- Game: addappid(2557720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2557721, 1, "00a83da9e7a157c200c568c5994cd13e826d70f5e28e322df759b0ede051e4fd")
