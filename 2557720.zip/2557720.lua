-- Lua provided by SkyAPI 
-- Game: AppID 2557720
addappid(2557720)
addappid(2557721, 1, "00a83da9e7a157c200c568c5994cd13e826d70f5e28e322df759b0ede051e4fd")
