-- Lua provided by RyzenAPI
-- Game: All Alone

-- MAIN APPLICATION
addappid(2557720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2557721, 1, "00a83da9e7a157c200c568c5994cd13e826d70f5e28e322df759b0ede051e4fd")

