-- Lua provided by RyzenAPI
-- Game: 2533590

-- MAIN APPLICATION
addappid(2533590)
-- Game: addappid(2533590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533591, 1, "d654dfcebf08536d1bda985945ebea5224df6c3bc84c226886a0aebe8f79485a")
