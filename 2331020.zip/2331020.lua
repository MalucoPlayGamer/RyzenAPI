-- Lua provided by RyzenAPI
-- Game: Tales of Berseria Remastered

-- MAIN APPLICATION
addappid(2331020)
addappid(3157570)
addappid(3157580)
addappid(3157590)
addappid(3157600)
addappid(3157610)
addappid(3157620)
addappid(3157630)
addappid(3157640)
addappid(3177880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2331021, 1, "4c296709f48c48bc8fb38dde91a407523d6563d56af48d5b741f79e4c088b990")
addappid(2928060, 0, "a155487ed7105b9c95c700d97886764d3724978fe369e84bffa0b5fb6c65b85e")
addappid(3157650, 0, "5ffac903e2bc90905dbead2653a94a129f37c64ccc8a0175f588649955ff0e82")
