-- Lua provided by RyzenAPI
-- Game: Game: Elements II: Hearts of Light

-- MAIN APPLICATION
addappid(448640)
-- Game: addappid(448640)

-- MAIN APP DEPOTS / PACKAGES
addappid(448641, 1, "a8bda33f58ec71723f5b2f29c28f1f9084d22108bb1fb9e622d61e41a6bb2dd1")
