-- Lua provided by RyzenAPI
-- Game: The Christmas Spirit: Journey Before Christmas Collector's Edition

-- MAIN APPLICATION
addappid(1498280)
-- Game: addappid(1498280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498281, 1, "54d0230b914a9a1d95fe70456907e17a6b5be1faa4f4ad6a8b0ffcb053cabfa1")
