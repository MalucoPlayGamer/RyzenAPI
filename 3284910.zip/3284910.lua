-- Lua provided by RyzenAPI
-- Game: Storm's Wrath

-- MAIN APPLICATION
addappid(3284910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3284911, 1, "d4bb0abc0f8137ee4c20ed403e36d25258f661fa3853c3a5b2ba1d963ef9d6fb")

