-- Lua provided by RyzenAPI 
-- Game: Storm's Wrath
addappid(3284910)
addappid(3284911, 1, "d4bb0abc0f8137ee4c20ed403e36d25258f661fa3853c3a5b2ba1d963ef9d6fb")
