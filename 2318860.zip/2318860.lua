-- Lua provided by RyzenAPI
-- Game: Architecture Zeitgeist: Architecture in your time

-- MAIN APPLICATION
addappid(2318860)
-- Game: addappid(2318860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318861, 1, "d45c04922e521ad192e85b39faf30a581ab691d6f60ba34572b188f5880b035d")
