-- Lua provided by RyzenAPI
-- Game: Architecture Zeitgeist: Architecture in your time

-- MAIN APPLICATION
addappid(2318860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318861, 1, "d45c04922e521ad192e85b39faf30a581ab691d6f60ba34572b188f5880b035d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
