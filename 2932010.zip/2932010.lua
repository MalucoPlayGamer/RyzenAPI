-- Lua provided by RyzenAPI
-- Game: TRADESMAN: Deal to Dealer Demo

-- MAIN APPLICATION
addappid(2932010)
-- Game: addappid(2932010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932011, 1, "6b4b5c32232f0fd2ac591cf43daa3ac5133dc35c5e34cfc35668f307f286b0e6")
