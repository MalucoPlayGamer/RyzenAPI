-- Lua provided by RyzenAPI
-- Game: Beat Cop

-- MAIN APPLICATION
addappid(461950)

-- MAIN APP DEPOTS / PACKAGES
addappid(461951, 1, "94ec83a8120b2bdb2828e8ce347f44b779ef42ed71c01febef198b9d1dc518f6")
addappid(461952, 1, "133ffdd781024e74cdec02b5b32b3e76c2c0a363fd685954fffd82d34d39cc80")
addappid(461953, 1, "e54eb1820052ca8ba4f3e9fb332c9d11c4ac4a13e4f0a85a3cdcd4cfac8975bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
