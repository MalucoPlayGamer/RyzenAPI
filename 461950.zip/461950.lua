-- Lua provided by RyzenAPI
-- Game: Beat Cop

-- MAIN APPLICATION
addappid(461950)

-- MAIN APP DEPOTS / PACKAGES
addappid(461951, 1, "94ec83a8120b2bdb2828e8ce347f44b779ef42ed71c01febef198b9d1dc518f6")
addappid(461952, 1, "133ffdd781024e74cdec02b5b32b3e76c2c0a363fd685954fffd82d34d39cc80")
addappid(461953, 1, "e54eb1820052ca8ba4f3e9fb332c9d11c4ac4a13e4f0a85a3cdcd4cfac8975bc")

