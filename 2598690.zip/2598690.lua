-- Lua provided by RyzenAPI
-- Game: addappid(2598690)

-- MAIN APPLICATION
addappid(2598690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598691, 1, "e016842d20ddad8f94db4bcbcb9e29f142a4f2def99b1d8f93016ead86967990")
