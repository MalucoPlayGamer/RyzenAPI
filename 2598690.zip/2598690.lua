-- Lua provided by SkyAPI 
-- Game: 10:16
addappid(2598690)
addappid(2598691, 1, "e016842d20ddad8f94db4bcbcb9e29f142a4f2def99b1d8f93016ead86967990")
