-- Lua provided by RyzenAPI
-- Game: Droplitz

-- MAIN APPLICATION
addappid(23120)

-- MAIN APP DEPOTS / PACKAGES
addappid(23121, 1, "4ee0750e4d57231f220b2415647ab0d50a19aada4a1831651ca18dd89f848d9d")

