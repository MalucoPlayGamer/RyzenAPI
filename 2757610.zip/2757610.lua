-- Lua provided by SkyAPI 
-- Game: Trans-Siberian Legends
addappid(2757610)
addappid(2757611, 1, "5f26e796885f80764ad6a29c855fed66181f8f94a56270805472dcb8b4c3a29f")
