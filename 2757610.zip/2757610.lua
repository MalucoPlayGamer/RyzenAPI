-- Lua provided by RyzenAPI
-- Game: Game: Trans-Siberian Legends

-- MAIN APPLICATION
addappid(2757610)
-- Game: addappid(2757610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757611, 1, "5f26e796885f80764ad6a29c855fed66181f8f94a56270805472dcb8b4c3a29f")
