-- Lua provided by RyzenAPI
-- Game: Trans-Siberian Legends

-- MAIN APPLICATION
addappid(2757610)
addappid(2886360)
addappid(2887110)
addappid(2887420)
addappid(2887440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757611,0,"5f26e796885f80764ad6a29c855fed66181f8f94a56270805472dcb8b4c3a29f")

