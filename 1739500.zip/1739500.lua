-- Lua provided by RyzenAPI
-- Game: CAGE-FACE | Case 2: The Sewer

-- MAIN APPLICATION
addappid(1739500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739501, 1, "366cfc2684193675848490ac7b6ab96be3c7ed871c3c34eb5014a01068a3cc36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
