-- Lua provided by RyzenAPI
-- Game: CAGE-FACE | Case 2: The Sewer

-- MAIN APPLICATION
addappid(1739500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739501, 1, "366cfc2684193675848490ac7b6ab96be3c7ed871c3c34eb5014a01068a3cc36")

