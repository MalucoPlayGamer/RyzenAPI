-- Lua provided by RyzenAPI
-- Game: Dwarfs - F2P

-- MAIN APPLICATION
addappid(213650)
addappid(213661)
addappid(213662)
addappid(213663)
addappid(213664)
addappid(213665)
addappid(213666)
addappid(213667)
addappid(213668)
addappid(213669)

