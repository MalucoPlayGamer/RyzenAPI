-- Lua provided by RyzenAPI
-- Game: Dwarfs - F2P

-- MAIN APPLICATION
addappid(213650)
