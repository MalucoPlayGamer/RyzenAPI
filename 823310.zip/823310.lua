-- Lua provided by RyzenAPI
-- Game: Alchemy Classic

-- MAIN APPLICATION
addappid(823310)

-- MAIN APP DEPOTS / PACKAGES
addappid(823311,0,"5d13f3f47e981a0ef5611bdd80de70e385bf836de8821478e33442faf9f24f1e")

