-- Lua provided by RyzenAPI
-- Game: 方解夢異聞 ～ Avant-Garde Discerning Paralleler (東方二次創作STG)

-- MAIN APPLICATION
addappid(1095590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095591, 1, "14e4b60fe966a618198e2a012eb987d8deab38ac1a97d59576be62638ab4db33")

