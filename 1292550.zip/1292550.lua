-- Lua provided by RyzenAPI
-- Game: Lockdown

-- MAIN APPLICATION
addappid(1292550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292551, 1, "56b9060e4867bd0b6ff9bda8167a8d931f2a4e9983ea2f9fb6cf2dac4ea3e095")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
