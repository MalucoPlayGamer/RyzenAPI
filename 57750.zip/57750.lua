-- Lua provided by RyzenAPI
-- Game: Game: Tropico 4 Demo

-- MAIN APPLICATION
addappid(57750)
-- Game: addappid(57750)

-- MAIN APP DEPOTS / PACKAGES
addappid(57751, 1, "585b451f4de23fd7d57094554d3c1d0007b33a4b3d2da131e29371462096ef4a")
