-- Lua provided by RyzenAPI
-- Game: Game: AppID 1145780

-- MAIN APPLICATION
addappid(1145780)
-- Game: addappid(1145780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145781, 1, "c37cb8979a050caea29c940fd13239f7cc0262ed371f7743e497f5fcb21c7e6d")
