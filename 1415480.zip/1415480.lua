-- Lua provided by RyzenAPI
-- Game: 10mg: Locked In

-- MAIN APPLICATION
addappid(1415480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415481, 1, "2a8984b6dbee425a151362f6ba57737e6ad7075117da23627aaea21b8425ebb2")