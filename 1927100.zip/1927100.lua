-- Lua provided by RyzenAPI
-- Game: 三国仁义传 The Righteousness: SanGuo

-- MAIN APPLICATION
addappid(1927100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1927101, 1, "5f1b50a5ed79920bac34674621d1a36e66f39c8e5e7db1a825f4dfc4ea4e75d6")

