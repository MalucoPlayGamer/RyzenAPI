-- Lua provided by RyzenAPI
-- Game: Game: 三国仁义传 The Righteousness: SanGuo

-- MAIN APPLICATION
addappid(1927100)
-- Game: addappid(1927100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927101, 1, "5f1b50a5ed79920bac34674621d1a36e66f39c8e5e7db1a825f4dfc4ea4e75d6")
