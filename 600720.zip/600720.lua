-- Lua provided by RyzenAPI
-- Game: 600720

-- MAIN APPLICATION
addappid(600720)
-- Game: addappid(600720)

-- MAIN APP DEPOTS / PACKAGES
addappid(600721, 1, "bd3978f2acd8a64b69bafd21693a608bdb3a0797488e3a205a4eefe190260222")
