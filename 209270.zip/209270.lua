-- Lua provided by RyzenAPI
-- Game: Game: Hero Academy

-- MAIN APPLICATION
addappid(209270)
-- Game: addappid(209270)

-- MAIN APP DEPOTS / PACKAGES
addappid(209271, 1, "9491a40e71656fdba42124f2296daae3e94e784887f314a5e4487eecea448da6")
addappid(209272, 1, "b16d340a2ad7ac92918404c93d119f1d57e9726ef923a79b786e83db05853ce4")
addappid(209273, 1, "b88755c76eed41005c866ae008f182e7d1fa08daa1301212b6bd59fef812a4cd")
