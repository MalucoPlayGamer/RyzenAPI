-- Lua provided by RyzenAPI
-- Game: Misteri Rumah Pak RT

-- MAIN APPLICATION
addappid(2301640)
-- Game: addappid(2301640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301641, 1, "dcfdbbe3099a01eb55122c03d3885fbd40b6297545b20f583d4dffc09781665a")
