-- Lua provided by RyzenAPI
-- Game: Misteri Rumah Pak RT

-- MAIN APPLICATION
addappid(2301640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2301641, 1, "dcfdbbe3099a01eb55122c03d3885fbd40b6297545b20f583d4dffc09781665a")

