-- Lua provided by RyzenAPI
-- Game: AppID 1053780

-- MAIN APPLICATION
addappid(1053780)
addappid(1059170)
addappid(1060780)
addappid(1109240)
addappid(1120450)
addappid(1121330)
addappid(1125320)
addappid(1131010)
addappid(1147250)
addappid(1155010)
addappid(1157030)
addappid(1157520)
addappid(1188230)
addappid(1188840)
addappid(1189390)
addappid(1216820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053781, 1, "72a2be0ddeb31bf13c5661f0187adf4b2bdf87e162f91d16fbf56a1f509a4448")

