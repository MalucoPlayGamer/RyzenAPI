-- Lua provided by RyzenAPI
-- Game: Glitchphobia Demo

-- MAIN APPLICATION
addappid(1312030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312031, 1, "d01d5f63de8cbc03c530a74bbe650db5b2e2815a03369b8c2da67e2b36e5e9cc")

