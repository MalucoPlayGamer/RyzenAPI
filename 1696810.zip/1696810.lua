-- Lua provided by RyzenAPI
-- Game: Railroads Online

-- MAIN APPLICATION
addappid(1696810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696811, 1, "afd20129bdc287c2b3af36aa95920169a8b17b1831aa81f8228801478e113dd0")
