-- Lua provided by RyzenAPI
-- Game: 3471060

-- MAIN APPLICATION
addappid(3471060)
addappid(3473860)
-- Game: addappid(3471060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471061, 1, "9463be2faae70be4243bca301c4fac4c3808ae3b342354281ca0f49341207c2f")
