-- Lua provided by RyzenAPI
-- Game: Star Tactics Redux

-- MAIN APPLICATION
addappid(503950)
addappid(799130)

-- MAIN APP DEPOTS / PACKAGES
addappid(503951, 1, "9ecacd86afcb22b798c1a93f9a1bd2d6638e2a55b08f57c72f50121f2df27248")
addappid(503952, 1, "ea55640d5a3bf01895886e33793752f2127f579b01b196d54aef8dbc59920a91")
addappid(503953, 1, "53bbab20699ff9feb880598f713bd524634e1dfda33f5210aacc8722de083b72")
addappid(503954, 1, "86619d56cf9476ed706a0dbc9ae7e58939eeb60fadc2b09050086a4d80fa30ab")
addappid(503955, 1, "00fd31111a6598bc2de2f205f53b1efa6c6c5e9b6b501f47a26f5cf9afad9916")
addappid(503956, 1, "ed315217af12557d3abbadd85df277a78a7dacbb2086d9a7c87f15cf1e980df6")
