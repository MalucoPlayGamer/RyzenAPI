-- Lua provided by RyzenAPI
-- Game: AppID 1379560

-- MAIN APPLICATION
addappid(1379560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379561, 1, "addeeefc87fad317c91677181dc941c48893ff4188609219bb27bbdd38f62ec7")
