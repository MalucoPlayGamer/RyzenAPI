-- Lua provided by RyzenAPI
-- Game: addappid(2444160)

-- MAIN APPLICATION
addappid(2444160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444161, 1, "894ec64efc616d66e8d350782b47d7bc57f06dc5bba80d4b41f30fa8f09c1509")
