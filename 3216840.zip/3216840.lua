-- Lua provided by RyzenAPI
-- Game: 3216840

-- MAIN APPLICATION
addappid(3216840)
-- Game: addappid(3216840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216840,0,"a21b3b1006ac0dd168b788865ae03cfc0b9cca83e1a78d5f539306d8beea10db")
