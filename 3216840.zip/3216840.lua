-- Lua provided by RyzenAPI
-- Game: Love n Life: Lucky Teacher - Light of a New Day

-- MAIN APPLICATION
addappid(3216840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216840,0,"a21b3b1006ac0dd168b788865ae03cfc0b9cca83e1a78d5f539306d8beea10db")
