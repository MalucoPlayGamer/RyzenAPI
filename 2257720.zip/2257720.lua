-- Lua provided by RyzenAPI 
-- Game: Above The Clouds - Episode 1
addappid(2257720)
addappid(2257721, 1, "5717a2fc6062598f71dacb4a009c0877d5e4282a0cfeb6eb5458b5e2e4134fc9")
