-- Lua provided by RyzenAPI
-- Game: setManifestid(2614083,"2057484784251520120")

-- MAIN APPLICATION
addappid(2614080)
-- Game: addappid(2614080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614083,0,"b614cc8bb6f4e3d9907608c89f916dbe5b4152209be0a1cb8bd0b173d7dcd9bf")
