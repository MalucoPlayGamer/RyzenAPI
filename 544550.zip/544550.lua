-- Lua provided by RyzenAPI
-- Game: AppID 544550

-- MAIN APPLICATION
addappid(544550)

-- MAIN APP DEPOTS / PACKAGES
addappid(544551, 1, "d1ac2705285c1f7d74d0a4ef441cc09605d7d0f5bb588fead0f781d2cffea960")
