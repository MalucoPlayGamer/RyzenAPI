-- Lua provided by RyzenAPI
-- Game: 死亡旅店

-- MAIN APPLICATION
addappid(1081880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081881, 1, "0afc94f7ac59f4e8245a43dafa0a84f75e3dce7bacefdd60bf9cc147a2c92469")
