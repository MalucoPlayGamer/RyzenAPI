-- Lua provided by SkyAPI 
-- Game: Roboquest: Soundtrack
addappid(1400490)
addappid(1400491, 1, "c2b4c2b3082b3217a46894196d074af38785b63b4aec46ad16b68f027d760a96")
addappid(1400492, 1, "d362780989623866b3833457d26c809cb34be7f803a8b2d9ebc7908f47382e43")
