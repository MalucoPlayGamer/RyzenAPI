-- Lua provided by RyzenAPI
-- Game: addappid(2422210)

-- MAIN APPLICATION
addappid(2422210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422211, 1, "b8a42c2f4bf2cef0343c46ea7753f17ea373096d133ecc1884e65fe119dd06d1")
