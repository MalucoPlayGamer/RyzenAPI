-- Lua provided by RyzenAPI
-- Game: Game: Tiny Rails

-- MAIN APPLICATION
addappid(614630)
-- Game: addappid(614630)

-- MAIN APP DEPOTS / PACKAGES
addappid(614631, 1, "0fe1154937123146116e7a21a569934706505780361c470d00ab68fe5f0e35da")
