-- Lua provided by RyzenAPI
-- Game: AppID 556050

-- MAIN APPLICATION
addappid(556050)

-- MAIN APP DEPOTS / PACKAGES
addappid(556051, 1, "6e8a82f1bf82a2f7e60f9423bf8b19ef1a54a47ae837af3283d358183e0f32d4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
