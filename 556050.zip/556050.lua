-- Lua provided by RyzenAPI
-- Game: AppID 556050

-- MAIN APPLICATION
addappid(556050)

-- MAIN APP DEPOTS / PACKAGES
addappid(556051, 1, "6e8a82f1bf82a2f7e60f9423bf8b19ef1a54a47ae837af3283d358183e0f32d4")

