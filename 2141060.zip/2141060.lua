-- Lua provided by RyzenAPI
-- Game: Forever Skies Demo

-- MAIN APPLICATION
addappid(2141060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141061, 1, "35cdd4da627a9e4b94a56e2ec8110de8e923fa32d36534815893b31edb08090e")

