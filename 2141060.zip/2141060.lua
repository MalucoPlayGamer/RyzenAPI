-- Lua provided by SkyAPI 
-- Game: AppID 2141060
addappid(2141060)
addappid(2141061, 1, "35cdd4da627a9e4b94a56e2ec8110de8e923fa32d36534815893b31edb08090e")
