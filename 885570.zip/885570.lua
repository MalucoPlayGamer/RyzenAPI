-- Lua provided by RyzenAPI
-- Game: Nova-Life: Amboise

-- MAIN APPLICATION
addappid(885570)

-- MAIN APP DEPOTS / PACKAGES
addappid(885571, 1, "c8ffd533c040f2aa31e09d0372cc1b870e3bfc1bc923c2b7f1a4c4a3ae9593fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
