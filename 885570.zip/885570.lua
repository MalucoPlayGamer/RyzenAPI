-- Lua provided by RyzenAPI 
-- Game: Nova-Life: Amboise
addappid(885570)
addappid(885571, 1, "c8ffd533c040f2aa31e09d0372cc1b870e3bfc1bc923c2b7f1a4c4a3ae9593fe")
