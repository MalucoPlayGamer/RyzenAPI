-- Lua provided by RyzenAPI
-- Game: Game: MASSAGE MY EX-BULLY

-- MAIN APPLICATION
addappid(3122900)
-- Game: addappid(3122900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122901, 1, "9dc10c99649df343d7e3a218ccfe2522e3c01c59de485cb279dff490b5f5e34b")
