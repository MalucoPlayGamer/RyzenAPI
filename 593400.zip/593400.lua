-- Lua provided by RyzenAPI
-- Game: Float Gallery

-- MAIN APPLICATION
addappid(593400)

-- MAIN APP DEPOTS / PACKAGES
addappid(593401, 1, "9ac51812abc4933ced741da82dfcf3b6f0db59658eaaf37baaf5ca22cb59a5e4")

