-- Lua provided by RyzenAPI
-- Game: AppID 1012260

-- MAIN APPLICATION
addappid(1012260)
-- Game: addappid(1012260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012261, 1, "0eb14cf0d43ba7c98880101fe848416a6acc9a155749a5ab4ca8e153dbf288cf")
