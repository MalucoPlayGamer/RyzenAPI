-- Lua provided by RyzenAPI
-- Game: My Days In Bel Air

-- MAIN APPLICATION
addappid(1984230)
-- Game: addappid(1984230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984231, 1, "d0d063e864523358d1a800cd048b36381f256302e0ef34be90f1f35892500690")
