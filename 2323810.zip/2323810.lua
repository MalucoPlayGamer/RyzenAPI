-- Lua provided by RyzenAPI
-- Game: 2323810

-- MAIN APPLICATION
addappid(2323810)
-- Game: addappid(2323810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2323811, 1, "7fd10d10433e59b5b267c45c87851ca23b47a12a1608f7729eca224f3cd4e633")
