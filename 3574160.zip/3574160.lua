-- Lua provided by RyzenAPI
-- Game: Shimagami

-- MAIN APPLICATION
addappid(3574160)
addappid(3603290)
addappid(3603300)
addappid(3603310)
addappid(3697740)
addappid(3698480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(3574161, 1, "3c680010b74129e7165873f5b5dc50a3ee95a4254cc2f5f206903aa396a582c4")

