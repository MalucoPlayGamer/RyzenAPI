-- Lua provided by RyzenAPI
-- Game: Game: Shimagami

-- MAIN APPLICATION
addappid(3574160)
-- Game: addappid(3574160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3574161, 1, "3c680010b74129e7165873f5b5dc50a3ee95a4254cc2f5f206903aa396a582c4")
