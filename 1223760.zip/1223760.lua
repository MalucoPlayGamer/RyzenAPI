-- Lua provided by RyzenAPI
-- Game: addappid(1223760)

-- MAIN APPLICATION
addappid(1223760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223761, 1, "e20bb6db85a0f7e8f544ed23ce3079e88ec90de1af8aaa62113d087214116c04")
