-- Lua provided by SkyAPI 
-- Game: Recoil
addappid(1223760)
addappid(1223761, 1, "e20bb6db85a0f7e8f544ed23ce3079e88ec90de1af8aaa62113d087214116c04")
