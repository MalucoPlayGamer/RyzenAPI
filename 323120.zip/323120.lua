-- Lua provided by RyzenAPI
-- Game: Free to Play Soundtrack

-- MAIN APPLICATION
addappid(323120)
-- Game: addappid(323120)

-- MAIN APP DEPOTS / PACKAGES
addappid(323121, 1, "83300ae93bfe0592136fb58f1f7d19f015ec8349e49259397a4ccae51776b67b")
