-- Lua provided by RyzenAPI
-- Game: Yusha Prototype

-- MAIN APPLICATION
addappid(2253970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253971, 1, "9f942330205627b5337c1edcd364f2b5fa55676802cf2f14cfbb3febcd2120a8")
