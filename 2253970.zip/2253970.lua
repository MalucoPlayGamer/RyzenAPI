-- Lua provided by RyzenAPI 
-- Game: Yusha Prototype
addappid(2253970)
addappid(2253971, 1, "9f942330205627b5337c1edcd364f2b5fa55676802cf2f14cfbb3febcd2120a8")
