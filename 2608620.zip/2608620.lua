-- Lua provided by RyzenAPI
-- Game: Game: Sex, Please

-- MAIN APPLICATION
addappid(2608620)
-- Game: addappid(2608620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2608621, 1, "028aaf876d4865b18a2f4b832aa4a64b93ca525fc6a93d68ace599882caed780")
