-- Lua provided by RyzenAPI
-- Game: Dead Rising 3 Apocalypse Edition

-- MAIN APPLICATION
addappid(265550)

-- MAIN APP DEPOTS / PACKAGES
addappid(265551, 1, "3b1663434bdcb2dc139e0a48c954ed4de6dc3805011678d53226bedcd1faf6c9")
addappid(265552, 1, "90a6686bb14ffd51ad40e620c66751695e7f27baf591752b26a66ba93f57fdc1")
addappid(265554, 1, "236544cc056a3d8363b38697d6713b5b0a3b3f98632324a219f97a380509ecef")
addappid(274110, 0, "c8eb772507c220d39605368974b5af392a62a83a8828ba5ec36d90eeaa415867")
addappid(274111, 0, "25497a53f2ad2727f6738f11dfbb9c7fe6b764e021939c5759a0b78c845f6e68")
addappid(274112, 0, "cf9e6ac0cbb6c2e2e487efaff6d2e4ed9ce4f9337de755e57301a63fcaeac122")
addappid(278140, 0, "8286b20af13ed015faa8e8431a6cf8371d041f5498245b39c03fc906358c20e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
