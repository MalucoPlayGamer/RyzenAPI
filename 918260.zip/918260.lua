-- Lua provided by RyzenAPI
-- Game: Pachansky Mathematics 2+2=8

-- MAIN APPLICATION
addappid(918260)
addappid(918270)
-- Game: addappid(918260)

-- MAIN APP DEPOTS / PACKAGES
addappid(918261, 1, "5428951aca2a692f94caa9cec3e62efc1df4451cc639acc6011b66387ac4ab7b")
