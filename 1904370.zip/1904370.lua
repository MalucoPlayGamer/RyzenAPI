-- Lua provided by RyzenAPI
-- Game: addappid(1904370)

-- MAIN APPLICATION
addappid(1904370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904370,0,"4b47e953b713a8bc2ae131563db8f5134180ae07dc1c448924ae8d5f19df8764")
