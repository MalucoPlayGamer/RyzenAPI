-- Lua provided by SkyAPI 
-- Game: AppID 405180
addappid(405180)
addappid(405181, 1, "f48138e7f0b864510c3511066f792b99570b7c7b38353775d6dc2a2c95a1e9c8")
