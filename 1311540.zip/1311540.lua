-- Lua provided by RyzenAPI
-- Game: The Wake: Mourning Father, Mourning Mother

-- MAIN APPLICATION
addappid(1311540)
-- Game: addappid(1311540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311541, 1, "4badd3d8e761dbe923b7262d34be2e4465027a93a292b67602c563f317a4182a")
