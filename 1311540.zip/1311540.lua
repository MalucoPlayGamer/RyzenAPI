-- Lua provided by RyzenAPI 
-- Game: The Wake: Mourning Father, Mourning Mother
addappid(1311540)
addappid(1311541, 1, "4badd3d8e761dbe923b7262d34be2e4465027a93a292b67602c563f317a4182a")
