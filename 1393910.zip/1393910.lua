-- Lua provided by RyzenAPI
-- Game: Jolly Good: Cakes and Ale

-- MAIN APPLICATION
addappid(1393910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393911, 1, "b6f23679eeab4723c7c9f8ba6c1e6fac3a75a9fda2f220ee6c66f28acac37081")
