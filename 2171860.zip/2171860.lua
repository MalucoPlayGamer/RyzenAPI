-- Lua provided by RyzenAPI
-- Game: Nayla's Castle Demo

-- MAIN APPLICATION
addappid(2171860)
-- Game: addappid(2171860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171861, 1, "8f8eb79c456744176ab1c703c2ce6c9285ddf6215011f4c453a92502a054beae")
