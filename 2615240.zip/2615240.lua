-- Lua provided by RyzenAPI
-- Game: Game: AppID 2615240

-- MAIN APPLICATION
addappid(2615240)
-- Game: addappid(2615240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615241, 1, "84a4bef3de493c661ae1c8bee7cceb688f42d34d74ab15a88c0883f1c10d8308")
