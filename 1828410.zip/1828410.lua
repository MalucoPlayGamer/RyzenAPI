-- Lua provided by RyzenAPI
-- Game: Survive The Island

-- MAIN APPLICATION
addappid(1828410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828411, 1, "20433d4c0f3bb5f2f7fe892fdfb5e98f09c489032dc5cd8ef5cd8d8f7de050c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1828420)
addappid(1833600)
addappid(1836810)
addappid(1884110)
