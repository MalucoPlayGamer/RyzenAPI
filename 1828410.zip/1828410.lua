-- Lua provided by RyzenAPI
-- Game: 1828410

-- MAIN APPLICATION
addappid(1828410)
-- Game: addappid(1828410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828411, 1, "20433d4c0f3bb5f2f7fe892fdfb5e98f09c489032dc5cd8ef5cd8d8f7de050c2")
