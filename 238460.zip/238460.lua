-- Lua provided by RyzenAPI
-- Game: Game: BattleBlock Theater®

-- MAIN APPLICATION
addappid(238460)
-- Game: addappid(238460)

-- MAIN APP DEPOTS / PACKAGES
addappid(238461, 1, "ebfec6760b63899efa5c83d0a4368e82197d675399e92010b76e520074612c8f")
addappid(238462, 1, "1f277a8a5b5641de8159790a95dede1e956022fb8f7193e1c8d1ed0e89a8de03")
addappid(238463, 1, "192bae8282b859b96aea1207d07011f64205366ce9f295e5d1970de1cbd7dc7b")
addappid(238465, 1, "a6b78631d335319ad1b06ff286d04c41710d2f32b71d88a68ca07118cade6b27")
