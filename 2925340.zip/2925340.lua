-- Lua provided by RyzenAPI
-- Game: addappid(2925340)

-- MAIN APPLICATION
addappid(2925340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925341, 1, "c034cc57e6ec27ee5d850b53ac56608de4bcc8605c2f7908e1a502c067e6d3dc")
