-- Lua provided by RyzenAPI
-- Game: Ruby Heart [Visual Novel / Otome]

-- MAIN APPLICATION
addappid(1460440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460441, 1, "a88201e30a02211ecfd80dee339bd0caa27baddac03ef2c1cac563c2d97a1364")
