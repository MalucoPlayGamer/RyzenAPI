-- Lua provided by RyzenAPI
-- Game: AppID 1299620

-- MAIN APPLICATION
addappid(1299620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299621, 1, "4c61a038d542ba57c8611f9798997544a73c28f4947fb96f0c6ca30e0bf612cd")
addappid(1299622, 1, "54578d4a2fe0c3c3631f70cec87812dfbff26f8433b05e099157b01ace495586")
addappid(1299623, 1, "e9f6c632db8548569ee325477789437e1f482b46fa820894ede27ee58e675b54")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2301070)
addappid(2918880)
addappid(4184260)
