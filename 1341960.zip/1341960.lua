-- Lua provided by RyzenAPI
-- Game: Fuhrer in LA - Special Edition

-- MAIN APPLICATION
addappid(1341960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341961, 1, "881861c72b40b5f3eccaaa3d8f064ad4bd762f61cc9c6bb9a77af1ccb10f4e04")

