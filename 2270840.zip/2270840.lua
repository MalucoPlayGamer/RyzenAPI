-- Lua provided by RyzenAPI
-- Game: AppID 2270840

-- MAIN APPLICATION
addappid(2270840)
-- Game: addappid(2270840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270841, 1, "3c3bf37a97ea31658438c03f64665cc444b0d984a493c918fb3f5b29ee44d265")
