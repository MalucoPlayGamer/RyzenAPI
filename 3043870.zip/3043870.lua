-- Lua provided by RyzenAPI
-- Game: Disney Epic Mickey: Rebrushed Demo

-- MAIN APPLICATION
addappid(3043870)
-- Game: addappid(3043870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043871, 1, "7e6ee76d23301bf2fff2965c34cf5dcd3c5e367f3006052d6a6320f8da4615eb")
