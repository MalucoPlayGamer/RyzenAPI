-- Lua provided by RyzenAPI 
-- Game: OBSCURA Demo
addappid(2472360)
addappid(2472361, 1, "60ed8c8d9fedaa1673e07fb4db7a3301cede593730edc8a79a86c1f54210f55c")
