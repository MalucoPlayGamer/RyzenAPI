-- Lua provided by RyzenAPI
-- Game: FUSER™ - Cap’n Spicy Dill - "Soon May The Wellerman Come"

-- MAIN APPLICATION
addappid(1598247)
-- Game: addappid(1598247)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598247,0,"87b9d5b724d62809b79b83a26467630fd5884116ffa5542ae5032781bcd14e98")
