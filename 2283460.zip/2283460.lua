-- Lua provided by RyzenAPI
-- Game: Game: SEX with HITLER: 2069

-- MAIN APPLICATION
addappid(2283460)
-- Game: addappid(2283460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283461, 1, "fd4f23d7edfa32aeec16968333387786b4788f63b1f065ab47694cab5da54678")
