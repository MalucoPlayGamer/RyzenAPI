-- Lua provided by RyzenAPI 
-- Game: SEX with HITLER: 2069
addappid(2283460)
addappid(2283461, 1, "fd4f23d7edfa32aeec16968333387786b4788f63b1f065ab47694cab5da54678")
