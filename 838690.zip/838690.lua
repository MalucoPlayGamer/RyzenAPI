-- Lua provided by RyzenAPI
-- Game: Unleashed

-- MAIN APPLICATION
addappid(838690)

-- MAIN APP DEPOTS / PACKAGES
addappid(838691,0,"122b2baf09c4d0d45016839b85d3ae84e9e84fd42109a6edeab8ffc894422134")

