-- Lua provided by RyzenAPI
-- Game: 1841520

-- MAIN APPLICATION
addappid(1841520)
-- Game: addappid(1841520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841521, 1, "016982737a4c2d95afab09a6b939342adf93adbf718abe561a6997e3afa46446")
