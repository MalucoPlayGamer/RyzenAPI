-- Lua provided by RyzenAPI
-- Game: Punk Wars

-- MAIN APPLICATION
addappid(1541790)
-- Game: addappid(1541790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1541791, 1, "aa8e37bfaf7af99143b1c3019149797e0cc5e6495f544940f5b15d53d995da2a")
addappid(1541792, 1, "b6db0f728f450087d15c8a1443e7789f50e315036b19ac0dc3ad58d18e133526")
addappid(1541793, 1, "eb313ee71b2b5f33a1307f27078b68fcec1f4156b6f63f9f13cf06d98b90e1fa")
addappid(1830660, 0, "0386c77129ec08b014eca32e532608aeacf1ddb96a8fbc7cf53f1af40cfa3a0e")
addappid(1932040, 0, "17fcdb195228f56c856addd4e7ec624e5819b0bb4de3c803a566e91519dcccc2")
