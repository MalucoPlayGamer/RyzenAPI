-- Lua provided by RyzenAPI
-- Game: The Pale Beyond

-- MAIN APPLICATION
addappid(1266030)
addappid(1266031)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266032,0,"fba59f2f20ac14cfbea51c8bcaeb89088f7656435f88e8c1be9300cfa278a6f1")
addappid(1266033,0,"f037374717dc3c91714c058a49c9c6e2d6ffb9db52e08e07c4a7fb17fffa3c8f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2168790)
