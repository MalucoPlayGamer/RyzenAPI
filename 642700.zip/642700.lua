-- Lua provided by SkyAPI 
-- Game: AppID 642700
addappid(642700)
addappid(642701, 1, "457109709b7c374929313247154f18b53de34268db0604a2245b4212a4f81e72")
