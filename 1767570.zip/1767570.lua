-- Lua provided by RyzenAPI
-- Game: Tour de France 2022

-- MAIN APPLICATION
addappid(1767570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767571, 1, "7e4ff6549b986616f059fdb8156cf0fc6bc596b6803b5687abcb035a53f7cd9e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
