-- Lua provided by RyzenAPI
-- Game: Tour de France 2022

-- MAIN APPLICATION
addappid(1767570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767571, 1, "7e4ff6549b986616f059fdb8156cf0fc6bc596b6803b5687abcb035a53f7cd9e")
