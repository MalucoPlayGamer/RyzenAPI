-- Lua provided by RyzenAPI
-- Game: Game: House of Rules

-- MAIN APPLICATION
addappid(1725440)
-- Game: addappid(1725440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725441, 1, "feb510657e749c93677b33a0f2001798c71a1b34832ef29703b5c98af8bd4113")
