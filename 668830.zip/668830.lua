-- Lua provided by RyzenAPI
-- Game: Raid On Coasts

-- MAIN APPLICATION
addappid(668830)
-- Game: addappid(668830)

-- MAIN APP DEPOTS / PACKAGES
addappid(668831, 1, "5827fabf38630441e70a3c2887ba4fdad0f8dcdc352577f53bc6bdfa2a4a7228")
addappid(668832, 1, "dc58f5c4884c4e555d69b7de39e6227edc8209a19832d1effc47fb00809f1d45")
