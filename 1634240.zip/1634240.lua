-- Lua provided by RyzenAPI
-- Game: Rytmos Demo

-- MAIN APPLICATION
addappid(1634240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634242,0,"a7539cd386b51e3ccd6b2554d770ea6a91341d59cba9a448d854a152616abb48")

