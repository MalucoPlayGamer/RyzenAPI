-- Lua provided by RyzenAPI
-- Game: Game: dotAGE  OST

-- MAIN APPLICATION
addappid(2593820)
-- Game: addappid(2593820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593821, 1, "4f73c36339a53e7d2390dc9f0f67d755dd162dff5f76dc9da5eddc1757903ac6")
