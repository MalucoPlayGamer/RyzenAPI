-- Lua provided by RyzenAPI 
-- Game: Candy Lattice
addappid(2379340)
addappid(2379341, 1, "455289256e9503aea26bb6c9ac20cc25d91af947c4ee79937627041e2f1b24af")
