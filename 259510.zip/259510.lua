-- Lua provided by RyzenAPI
-- Game: AppID 259510

-- MAIN APPLICATION
addappid(259510)

-- MAIN APP DEPOTS / PACKAGES
addappid(259511, 1, "96a3fec87313a06296e41c70c674379b092e399b4702904c263f8489b3d7559e")
addappid(259512, 1, "e37739be44a48b0fd3f2bac7f8e7ab61a5d2416f757766a5b2fa7ecb6d15dabd")
addappid(259513, 1, "42419ea202e96e24deb4de63ee8ceecf21f88095cc11ee080940990c726bac91")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
