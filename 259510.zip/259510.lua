-- Lua provided by RyzenAPI
-- Game: Game: AppID 259510

-- MAIN APPLICATION
addappid(259510)
-- Game: addappid(259510)

-- MAIN APP DEPOTS / PACKAGES
addappid(259511, 1, "96a3fec87313a06296e41c70c674379b092e399b4702904c263f8489b3d7559e")
addappid(259512, 1, "e37739be44a48b0fd3f2bac7f8e7ab61a5d2416f757766a5b2fa7ecb6d15dabd")
addappid(259513, 1, "42419ea202e96e24deb4de63ee8ceecf21f88095cc11ee080940990c726bac91")
