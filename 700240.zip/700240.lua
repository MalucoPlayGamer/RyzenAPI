-- Lua provided by RyzenAPI
-- Game: Project Genesis

-- MAIN APPLICATION
addappid(700240)
addappid(1336850)
addappid(1454350)
addappid(1651910)
addappid(1651911)
addappid(1651912)
addappid(1651913)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(700241, 1, "e20eb5bb0de5bd845a1e9ed9d534a9ed57c8a7600ee2888d3ef8f289007a1ee9")
addappid(700242, 1, "7d6de45469c2baf0c4c39873f5499ecab36b59193df980a3f1a3926dd9e288e3")

