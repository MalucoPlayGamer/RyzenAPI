-- Lua provided by RyzenAPI
-- Game: Game: Project Genesis

-- MAIN APPLICATION
addappid(700240)
-- Game: addappid(700240)

-- MAIN APP DEPOTS / PACKAGES
addappid(700241, 1, "e20eb5bb0de5bd845a1e9ed9d534a9ed57c8a7600ee2888d3ef8f289007a1ee9")
addappid(700242, 1, "7d6de45469c2baf0c4c39873f5499ecab36b59193df980a3f1a3926dd9e288e3")
