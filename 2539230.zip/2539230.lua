-- Lua provided by RyzenAPI
-- Game: The Sweetest Ring

-- MAIN APPLICATION
addappid(2539230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2539231, 1, "005d17fb17071b5e11f05ffb5fc1cf45e3f27e691a36070a9cf50cf175bdb57f")
