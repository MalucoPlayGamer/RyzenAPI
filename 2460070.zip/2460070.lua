-- Lua provided by RyzenAPI
-- Game: Half-Demon Shinobi

-- MAIN APPLICATION
addappid(2460070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460071, 1, "93a04e611c871594f0084a3866fb12bdebd033ac2cdecc94d596b9020313d7f3")
