-- Lua provided by RyzenAPI
-- Game: addappid(3873650)

-- MAIN APPLICATION
addappid(3873650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3873651, 1, "4e9b41beb1ea13ae98511181ffcc19e88150fb6f26a527ee0e2ce2889aac761d")
