-- Lua provided by RyzenAPI 
-- Game: AppID 562430
addappid(562430)
addappid(562431, 1, "8926947d673037bfe1894a017b3d0ab5f62199124e3ec6dde95eb9d54a46ed1d")
