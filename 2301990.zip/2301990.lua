-- Lua provided by RyzenAPI
-- Game: Rally31

-- MAIN APPLICATION
addappid(2301990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301991, 1, "5104caa1ea70d9dcacf477ae0850564d75fd57b5308b8d2b69fb0e3e07c1da87")
