-- Lua provided by RyzenAPI
-- Game: addappid(2161700)

-- MAIN APPLICATION
addappid(2161700)
addappid(2322840)
addappid(2334530)
addappid(2334531)
addappid(2334532)
addappid(2334533)
addappid(2334534)
addappid(2334535)
addappid(2334536)
addappid(2517300)
addappid(2517310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161701, 1, "9644c57e48eb13144cd26fa9423b85051e1c474221f8f6cfcb017478cd8f3503")
