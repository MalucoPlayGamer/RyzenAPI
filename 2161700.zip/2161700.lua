-- Lua provided by RyzenAPI
-- Game: Persona 3 Reload

-- MAIN APPLICATION
addappid(2161700)
addappid(2322840)
addappid(2334530)
addappid(2334531)
addappid(2334532)
addappid(2334533)
addappid(2334534)
addappid(2334535)
addappid(2334536)
addappid(2517300)
addappid(2517310)
addappid(2689210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2161701, 1, "9644c57e48eb13144cd26fa9423b85051e1c474221f8f6cfcb017478cd8f3503")

