-- Lua provided by RyzenAPI
-- Game: Space Roguelike Adventure

-- MAIN APPLICATION
addappid(1775860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775861, 1, "c0e42510f81c3d195df75f39949456dcd12b1153b385706f61d819638dd236ae")

