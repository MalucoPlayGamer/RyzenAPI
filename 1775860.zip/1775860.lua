-- Lua provided by SkyAPI 
-- Game: Space Roguelike Adventure
addappid(1775860)
addappid(1775861, 1, "c0e42510f81c3d195df75f39949456dcd12b1153b385706f61d819638dd236ae")
