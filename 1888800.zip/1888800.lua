-- Lua provided by RyzenAPI
-- Game: Game: SEARCH ALL - CRABS

-- MAIN APPLICATION
addappid(1888800)
-- Game: addappid(1888800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888801, 1, "c6001ee6496324e56c5adba63d00c4af532330b1795d520388a2163c6e5b15b9")
