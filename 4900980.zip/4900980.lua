-- 4900980's Lua and Manifest Created by Hubcap Manifest
-- Blob of Ink
-- Created: August 25, 2026 at 13:14:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4900980) -- Blob of Ink
-- MAIN APP DEPOTS
addappid(4900981, 1, "b6d4a481dd656eb1423c2dc34698d9c62a8ba3e961904963812331f21ef94d5b") -- Depot 4900981
setManifestid(4900981, "4301753986776508605", 1364860929)