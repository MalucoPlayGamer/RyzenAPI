-- Lua provided by RyzenAPI
-- Game: Blob of Ink

-- MAIN APPLICATION
addappid(4900980) -- Blob of Ink

-- MAIN APP DEPOTS / PACKAGES
addappid(4900981, 1, "b6d4a481dd656eb1423c2dc34698d9c62a8ba3e961904963812331f21ef94d5b") -- Depot 4900981

