-- Lua provided by SkyAPI 
-- Game: Girls Divers
addappid(2417140)
addappid(2417141, 1, "70210ac0cd0e4ad2d64f2b747744202161b0197a422d59dea224909747bb5f26")
