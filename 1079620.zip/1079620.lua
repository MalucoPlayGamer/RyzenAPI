-- Lua provided by RyzenAPI
-- Game: Game: Infinity: Battlescape

-- MAIN APPLICATION
addappid(1079620)
-- Game: addappid(1079620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079621, 1, "7d6fd42be97f375f0ebc01c829fe2de09a55a58935c1b889e2385d9649726985")
