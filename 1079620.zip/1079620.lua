-- Lua provided by RyzenAPI
-- Game: Infinity: Battlescape

-- MAIN APPLICATION
addappid(1079620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1079621, 1, "7d6fd42be97f375f0ebc01c829fe2de09a55a58935c1b889e2385d9649726985")

