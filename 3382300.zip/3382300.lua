-- Lua provided by RyzenAPI
-- Game: Game: Sovereign Brain Empire

-- MAIN APPLICATION
addappid(3382300)
-- Game: addappid(3382300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3382301, 1, "1171880ee4a605def006e04cbf42c6582b5b9231a161327d09d8b87c5245b5e4")
addappid(3382302, 1, "adb64108bc0e772fce0dc7058f96d577d73cb571c5166b0a80cbef38e44b6dd7")
addappid(3382303, 1, "23bc51ad45b55a9d3b815c9ce97ac6d3e80e87e50e260751ed6e788f35ad07a0")
addappid(3382304, 1, "be0aae823beb7fc1193f81cae21d74d6ab32713f0b730c1c1d3a6e7236c757aa")
