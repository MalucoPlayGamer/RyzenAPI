-- Lua provided by RyzenAPI
-- Game: Shining Resonance Refrain

-- MAIN APPLICATION
addappid(809890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(809891, 1, "9853520f57724bbaaa02f8b1464e230398b12a630a82fed17e17820fc90ba272")
addappid(809892, 1, "33bb80efb01ee8f874373294f7caf499a43f2423d8e2fb38d8aea99300e46ee6")
addappid(809893, 1, "67f66daf585f3f480c2d4483ea92d3f3d91c4094cd592d9f073764868a35b045")
addappid(809894, 1, "d4675f99b67aa708005eb1634cc4dbcf8b3e547b0be9dfdaa39b9da760c9eef2")
addappid(809895, 1, "c0dcd83f30dce18db0e840bffcdcf79180675fb580867f20f17d671218ec85f2")
addappid(809896, 1, "c08d5479480db739da5f9159fa5bcb9454bf3026b65cf2438e75b7f275fa8cac")

