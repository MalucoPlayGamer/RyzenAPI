-- Lua provided by RyzenAPI
-- Game: Evil Seal

-- MAIN APPLICATION
addappid(1516940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516941, 1, "580417d5e9a97042fbfc3ad78e6ab7a6ce462d2a11f89491f8856b576dc0caa3")

