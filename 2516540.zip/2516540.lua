-- Lua provided by RyzenAPI
-- Game: HeroTower

-- MAIN APPLICATION
addappid(2516540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516541, 1, "c5ec9a8b9ea40a7aa4a55f620de8923d5f9856884eebaf3176063afeab49aac5")

