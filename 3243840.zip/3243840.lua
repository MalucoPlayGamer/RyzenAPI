-- Lua provided by RyzenAPI
-- Game: addappid(3243840)

-- MAIN APPLICATION
addappid(3243840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243841, 1, "b3bf37dfe197a0a5531a9370485d520e7e292408bf7f2ff0ebaa5fe10768b813")
