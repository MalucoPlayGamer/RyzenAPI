-- Lua provided by RyzenAPI
-- Game: 1554260

-- MAIN APPLICATION
addappid(1554260)
-- Game: addappid(1554260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554261, 1, "f021768abc75d753fe480052bfb61d9e6cf6274bcab55b34a3ef65802c74e3cb")
