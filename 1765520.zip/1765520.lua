-- Lua provided by RyzenAPI 
-- Game: Flippin Misfits
addappid(1765520)
addappid(1765521, 1, "db876b8ec3f40e4b805511637f3d19f7436a098e2a3e14f13b7e6694f1faa2af")
