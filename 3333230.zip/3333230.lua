-- Lua provided by RyzenAPI
-- Game: addappid(3333230)

-- MAIN APPLICATION
addappid(3333230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333231, 1, "cf8fbb377b0238ad28ebf4b00faf3942bff4205d6bc8a9b2bd35072ed4bc2b37")
