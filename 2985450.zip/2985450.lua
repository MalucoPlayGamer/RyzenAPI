-- Lua provided by RyzenAPI
-- Game: Umigame

-- MAIN APPLICATION
addappid(2985450) -- Umigame

-- MAIN APP DEPOTS / PACKAGES
addappid(2985451, 1, "bef422aa302fb643ed1cbb71f99477cab451e94e79fabe9e7295885cea3015d7") -- Depot 2985451

