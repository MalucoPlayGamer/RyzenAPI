-- 2985450's Lua and Manifest Created by Hubcap Manifest
-- Umigame
-- Created: January 18, 2026 at 01:02:02 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2985450) -- Umigame
-- MAIN APP DEPOTS
addappid(2985451, 1, "bef422aa302fb643ed1cbb71f99477cab451e94e79fabe9e7295885cea3015d7") -- Depot 2985451
--setManifestid(2985451, "5461046118389474449", 5122863429)