-- Lua provided by RyzenAPI
-- Game: The Chasm - Mines Of Madness

-- MAIN APPLICATION
addappid(1140900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140901, 1, "68759384bd02ba98c91d904251d303b087a16805ddaaf7d2a31f1b1ecfa3e405")
addappid(1140902, 1, "9a5e5754691a485ba4126ca36ad2fc228ea34ca4614d64a42ae22336b05326f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
