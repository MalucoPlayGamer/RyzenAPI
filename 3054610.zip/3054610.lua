-- 3054610's Lua and Manifest Created by Hubcap Manifest
-- Artifact Seeker: Resurrection
-- Created: April 28, 2026 at 07:53:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 4

-- MAIN APPLICATION
addappid(3054610, 1, "1db90ee1538bc2f8067a93a1e65e0e86edb4a7db06dff7089551ce73ae86e14e") -- Artifact Seeker: Resurrection
-- MAIN APP DEPOTS
addappid(3054611, 1, "aa38570149979e30a8b798b4f967470137f962bb9a79df62d73faf1835612b36") -- Depot 3054611
setManifestid(3054611, "2161285190327913222", 1400388296)
-- DLCS WITH DEDICATED DEPOTS
-- Artifact Seeker - DLC 1 The Legacy of Mortia (AppID: 3065220)
addappid(3065220)
addappid(3065220, 1, "b731a39d7a24904946141ef151c14b75765b8103387e51a40c7dcacc03fe7084") -- Artifact Seeker - DLC 1 The Legacy of Mortia - Depot 3065220
setManifestid(3065220, "1285225276501497747", 188)
-- Artifact Seeker - DLC 2 Gems and Rifts (AppID: 3229410)
addappid(3229410)
addappid(3229410, 1, "6842450c88f588ecb798de89480059331221e6de7f2c077050bff27fc332a562") -- Artifact Seeker - DLC 2 Gems and Rifts - Depot 3229410
setManifestid(3229410, "6515440893715105439", 7)
-- Artifact Seeker - DLC 3 The Wandering Merchant (AppID: 3518900)
addappid(3518900)
addappid(3518900, 1, "e08c9bbc0e974916bb27cdf56513e2631392ac93bdd01dfa8e9a1816ddc1f5ca") -- Artifact Seeker - DLC 3 The Wandering Merchant - Depot 3518900
setManifestid(3518900, "878717891148742685", 23)
-- Artifact Seeker - DLC 4 The Shadow of Deep Sea (AppID: 3534930)
addappid(3534930)
addappid(3534930, 1, "76f5ead12e67c137a717d59f3fa02d66cb8150b4d69eaa244fcf30526a0585bb") -- Artifact Seeker - DLC 4 The Shadow of Deep Sea - Depot 3534930
setManifestid(3534930, "2797154343053210534", 7)