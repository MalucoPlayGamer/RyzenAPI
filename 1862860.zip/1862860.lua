-- Lua provided by RyzenAPI
-- Game: StreamAlertsTV

-- MAIN APPLICATION
addappid(1862860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862862,0,"e445ee58ad2ad8bde05e32d9bf34fda339a84dbd33e40b43bb90352c1716a268")

