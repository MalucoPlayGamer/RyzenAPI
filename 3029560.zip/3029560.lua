-- Lua provided by RyzenAPI
-- Game: The Photographer (Nymphs) - Demo

-- MAIN APPLICATION
addappid(3029560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029561, 1, "e56ffdcab9a610842658d86f037c127523e8d0c1bfcb7f412c7a879a22e8b596")

