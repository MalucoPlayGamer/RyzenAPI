-- Lua provided by RyzenAPI
-- Game: Save the settlers

-- MAIN APPLICATION
addappid(2474180)
-- Game: addappid(2474180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474181, 1, "341a74a52b2e9677ae9b0fc64f1042bf1d65881ab2be4d26dd7cf415e8d673ed")
