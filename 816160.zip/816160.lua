-- Lua provided by RyzenAPI
-- Game: Score a goal 2 (Physical football)

-- MAIN APPLICATION
addappid(816160)

-- MAIN APP DEPOTS / PACKAGES
addappid(816161, 1, "649e3fa0551f9ef3eedfe6c2a113ef8a497b7a0248b7348eabade0c998cfae99")
addappid(816162, 1, "0f93330297e24aa9d02b3023fa0dde7861fb880f3fb854ad1c861a626b8b69fb")

