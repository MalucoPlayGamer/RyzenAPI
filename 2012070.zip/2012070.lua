-- Lua provided by RyzenAPI
-- Game: Watch Your Back

-- MAIN APPLICATION
addappid(2012070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2012071, 1, "b73992d10b1eae84c3a46cb8b5c7c14910e869e2b9e0d41ea295469aec5e8441")

