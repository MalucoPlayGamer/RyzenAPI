-- Lua provided by RyzenAPI
-- Game: Game: Watch Your Back

-- MAIN APPLICATION
addappid(2012070)
-- Game: addappid(2012070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012071, 1, "b73992d10b1eae84c3a46cb8b5c7c14910e869e2b9e0d41ea295469aec5e8441")
