-- Lua provided by RyzenAPI 
-- Game: Watch Your Back
addappid(2012070)
addappid(2012071, 1, "b73992d10b1eae84c3a46cb8b5c7c14910e869e2b9e0d41ea295469aec5e8441")
