-- Lua provided by RyzenAPI
-- Game: Breathe With You

-- MAIN APPLICATION
addappid(2164630)
addappid(2533110)
-- Game: addappid(2164630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164631, 1, "856d957d7887498eb0f3384e33676bea8a0119f37e62e64eb159d172f91fe662")
