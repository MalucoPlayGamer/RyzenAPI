-- Lua provided by RyzenAPI
-- Game: SKYHILL: Black Mist

-- MAIN APPLICATION
addappid(990360)
-- Game: addappid(990360)

-- MAIN APP DEPOTS / PACKAGES
addappid(990361, 1, "47b5b3a59ac2aa51e5d216b63549f2811829b5eefe2a4c25d91990b2788f595b")
addappid(1321370, 0, "98ad7b99d56a1947a19f18e253dee6172c3493c89b6d24cfd98a80f0f79186d1")
