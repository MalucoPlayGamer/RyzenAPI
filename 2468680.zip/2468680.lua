-- Lua provided by RyzenAPI
-- Game: addappid(2468680)

-- MAIN APPLICATION
addappid(2468680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468681, 1, "ea9fdbb14176197861cdeb9387a22a3f9bc76750b123ad05fc8bdae16e69172a")
