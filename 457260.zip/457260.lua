-- Lua provided by RyzenAPI
-- Game: Omen of Sorrow

-- MAIN APPLICATION
addappid(457260)
-- Game: addappid(457260)

-- MAIN APP DEPOTS / PACKAGES
addappid(457261, 1, "cd6e65d452127ba31a24ce7470b805e240c96704fe1e729c9bd9456123a281eb")
