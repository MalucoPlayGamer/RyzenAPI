-- Lua provided by RyzenAPI
-- Game: addappid(2107710)

-- MAIN APPLICATION
addappid(2107710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107711, 1, "72da47a13832c802dbff01ee6c61ba07713db40ce6b9a5ba46ef6e0bb4e79618")
