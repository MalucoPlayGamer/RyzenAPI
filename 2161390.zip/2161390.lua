-- Lua provided by RyzenAPI
-- Game: 2161390

-- MAIN APPLICATION
addappid(2161390)
-- Game: addappid(2161390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161391, 1, "adb76f3ad9c7f4c95c59498f667d65b7bfad81c41b694adfdbfd22652067dc0d")
addappid(2161395, 1, "ed265f9dff9638276834957bc3aed74a221b084e7673afc8f03a3c419166c9c9")
