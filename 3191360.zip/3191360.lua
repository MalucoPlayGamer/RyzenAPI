-- Lua provided by RyzenAPI
-- Game: 3191360

-- MAIN APPLICATION
addappid(3191360)
-- Game: addappid(3191360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191361, 1, "a8c7387f7bc2987ed0189edb0e1210b5b31e0fe1abe7df6661df2e1a2b867b54")
