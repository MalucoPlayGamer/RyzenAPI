-- Lua provided by RyzenAPI
-- Game: Gremlins vs Automatons

-- MAIN APPLICATION
addappid(587670)

-- MAIN APP DEPOTS / PACKAGES
addappid(587671, 1, "dbc53249930ba56741caf2d6a541841aeed150695317fbd1cc1e17df7b683f55")
addappid(587672, 1, "b4e08e958f6a6f97e8a7f5199936f0e38124d98178e51f19017ce06d984df41c")
addappid(587673, 1, "17e4fc27a31fb0edece99d7868db230c4d0e69a631246ac586de1777f9ced46b")
