-- Lua provided by RyzenAPI
-- Game: addappid(1920780)

-- MAIN APPLICATION
addappid(1920780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920781, 1, "ab69a68ea42d807ebb87f9fa02c19b957d48112f0a8dfad2072f56d326c90e55")
