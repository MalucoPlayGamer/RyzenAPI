-- Lua provided by RyzenAPI
-- Game: Stray Gods: The Roleplaying Musical

-- MAIN APPLICATION
addappid(1920780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920781, 1, "ab69a68ea42d807ebb87f9fa02c19b957d48112f0a8dfad2072f56d326c90e55")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2807170)
