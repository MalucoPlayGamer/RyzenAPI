-- Lua provided by RyzenAPI
-- Game: addappid(368600)

-- MAIN APPLICATION
addappid(368600)

-- MAIN APP DEPOTS / PACKAGES
addappid(368601, 1, "e6f1e53d82c270183ea14619babbd1751856ee4b2b8b2fb7db50bd2f33dc9c41")
addappid(368602, 1, "4e514f7467864a9c7a7a0ab3cfcbcc9dae28cbbad567547f94a588ec0ad27685")
addappid(368603, 1, "5db9cebe8600f0c1ff16d889765de1e918b96441183fc2758c873b93d233e15e")
addappid(368604, 1, "ae30d00e4a47ed95e6ebc856cc217dc262484a317e950d4e852a0dc713ea232d")
addappid(368605, 1, "c77e82dbdccb0785ff385569ae6327e80239fb3cefd3a5c1d66136feb18a79e5")
addappid(368606, 1, "8be7849b26ae491ac0cee1f8e6b3ff6d4462b36b72f1380a1713b0aa1d08e9a8")
