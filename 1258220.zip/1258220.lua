-- Lua provided by RyzenAPI
-- Game: 1258220

-- MAIN APPLICATION
addappid(1258220)
-- Game: addappid(1258220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258221, 1, "b40453e15c36b7e80538b213509b93a7df04c53f82f8ab695713f5ef9c346caa")
