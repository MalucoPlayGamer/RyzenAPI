-- Lua provided by RyzenAPI
-- Game: Song of Iron

-- MAIN APPLICATION
addappid(1258220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1258221, 1, "b40453e15c36b7e80538b213509b93a7df04c53f82f8ab695713f5ef9c346caa")

