-- Lua provided by RyzenAPI
-- Game: 712900

-- MAIN APPLICATION
addappid(712900)
addappid(712901)
-- Game: addappid(712900)

-- MAIN APP DEPOTS / PACKAGES
addappid(712900,0,"7c75d34250e255708b38d182519d0798068b4d8fe113735eb16341fcb9f53dbf")
