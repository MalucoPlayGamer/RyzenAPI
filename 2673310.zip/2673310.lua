-- Lua provided by RyzenAPI
-- Game: addappid(2673310)

-- MAIN APPLICATION
addappid(2673310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673311, 1, "e6938321944f79b35d746a6d2dc06346b10cd88fbd09e4ad9e1a03e7fc2531ea")
