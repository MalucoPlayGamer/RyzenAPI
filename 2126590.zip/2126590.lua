-- Lua provided by RyzenAPI
-- Game: Brichi Quest

-- MAIN APPLICATION
addappid(2126590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126592,0,"68fbe115325b2d255cc2e083087cfdef9034f602abe35201c97215db183ca5e5")

