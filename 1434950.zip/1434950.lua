-- Lua provided by SkyAPI 
-- Game: HighFleet
addappid(1434950)
addappid(1434951, 1, "5602e4149942bb213b837b8f08d1af96485d9452f9f7854ccf686c16748c8c31")
