-- Lua provided by RyzenAPI
-- Game: Game: HighFleet

-- MAIN APPLICATION
addappid(1434950)
-- Game: addappid(1434950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434951, 1, "5602e4149942bb213b837b8f08d1af96485d9452f9f7854ccf686c16748c8c31")
