-- Lua provided by RyzenAPI
-- Game: 2863780

-- MAIN APPLICATION
addappid(2863780)
-- Game: addappid(2863780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863781, 1, "00ee94ef9fa308b130df6ed5f787a09c97a585c5fdb9b8913be13090e6777564")
