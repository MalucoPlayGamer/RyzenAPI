-- Lua provided by RyzenAPI
-- Game: The Simple Folder Management Tool

-- MAIN APPLICATION
addappid(1791990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791991, 1, "236b6ad26f89022f7961a218ce0bb8ce97d7e6f43befbbc39fefc5d7d6cce5a7")
