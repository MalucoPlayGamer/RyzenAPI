-- Lua provided by RyzenAPI
-- Game: Heckpoint

-- MAIN APPLICATION
addappid(731600)

-- MAIN APP DEPOTS / PACKAGES
addappid(731601, 1, "96bfda425adf7bd09708844b4f8737b4fd24cf880c1e565d8fa1a02b724b5b04")
