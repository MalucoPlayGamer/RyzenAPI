-- Lua provided by RyzenAPI
-- Game: Dragon Fist: VR Kung Fu

-- MAIN APPLICATION
addappid(1481780)
addappid(3352220)
addappid(3572340)
addappid(3955840)
addappid(3955850)
addappid(3955860)
addappid(4510290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481781,0,"2f1106e114498793212b9363df4b00bc36025813eee749045a460a7eedc4d00d")

