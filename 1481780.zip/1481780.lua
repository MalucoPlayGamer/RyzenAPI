-- Lua provided by RyzenAPI
-- Game: Dragon Fist: VR Kung Fu

-- MAIN APPLICATION
addappid(1481780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481781, 1, "2f1106e114498793212b9363df4b00bc36025813eee749045a460a7eedc4d00d")
