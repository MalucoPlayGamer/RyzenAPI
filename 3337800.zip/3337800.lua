-- Lua provided by RyzenAPI
-- Game: Pngify.me

-- MAIN APPLICATION
addappid(3337800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337801, 1, "119ed829c5089c54ddb03f89586ae4ff2d81558ff7550aa76bbebc09599959c3")
