-- Lua provided by RyzenAPI
-- Game: Comrade Quack

-- MAIN APPLICATION
addappid(1904050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904051, 1, "53a1e5d5c2107c79d7d0709bad6fed9a368645d30ae09639cfd7388c628566ac")
