-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Additional Music "Osaka Winter Campaign - Touken Ranbu Warriors"

-- MAIN APPLICATION
addappid(1912052)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912052,0,"e647a6323c487958a9c7ea6048647fad2fb7a1658444623ca87cdb822cd69902")
