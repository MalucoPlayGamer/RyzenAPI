-- Lua provided by RyzenAPI
-- Game: addappid(981540)

-- MAIN APPLICATION
addappid(981540)

-- MAIN APP DEPOTS / PACKAGES
addappid(981541, 1, "f9e895dba974136282455edfacaffd79cdaec13af2144e93dcbcf8b0009bfa7e")
