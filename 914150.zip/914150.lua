-- Lua provided by RyzenAPI
-- Game: 914150

-- MAIN APPLICATION
addappid(914150)
-- Game: addappid(914150)

-- MAIN APP DEPOTS / PACKAGES
addappid(914151, 1, "1c41b97fc19b41890ad013a422425bb3517a57d69b02a1f48bd127e00d4d17d4")
