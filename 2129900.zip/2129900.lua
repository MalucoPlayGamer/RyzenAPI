-- Lua provided by RyzenAPI
-- Game: 2129900

-- MAIN APPLICATION
addappid(2129900)
-- Game: addappid(2129900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129901, 1, "3aefa43af9064e3b49bf2a4f4a5a4752a30fba2226c790fbb775cfb91661e077")
