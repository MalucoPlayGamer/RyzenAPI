-- Lua provided by RyzenAPI
-- Game: Aces Under the Moonlight™

-- MAIN APPLICATION
addappid(1913550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913551, 1, "558cc6d0c92f5f5c290c21886d6bdde71a08549076385e87bb57a7ecce53f55b")
