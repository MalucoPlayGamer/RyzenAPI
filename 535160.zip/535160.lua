-- Lua provided by RyzenAPI
-- Game: Fire in the Goal "轰个球"

-- MAIN APPLICATION
addappid(535160)
-- Game: addappid(535160)

-- MAIN APP DEPOTS / PACKAGES
addappid(535161, 1, "b8ad6129f6af9f29804454b949fffff662e68ac07c7397452a8545df5d1ef4f1")
addappid(535162, 1, "59df303bce196549f2821b3e4c61814ceca0b1700b5d6d74f24533b28e19f3b1")
addappid(535163, 1, "7fac5b6022e7dc9eab79ddad7dd9b1e91d6995b0944c0c081f96b8e952438ac5")
addappid(535164, 1, "0b464ab66ca01d098aaa66bff41adee6b548dc2cec2b37d7d7b4b6deac74d9bb")
addappid(535165, 1, "7dc6531d543948dfea375168d13fa23c65551e273fcb9e57f895964ba8d14173")
