-- 3938640's Lua and Manifest Created by Hubcap Manifest
-- Ugoku Sushi Bar
-- Created: July 29, 2026 at 08:55:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3938640) -- Ugoku Sushi Bar
-- MAIN APP DEPOTS
addappid(3938641, 1, "0273ab2dc8703a3a60a94a8a1145cfb3c0e9418e66088b1754e618af892711cd") -- Depot 3938641
setManifestid(3938641, "520504865926471983", 1565777683)
addappid(3938642, 1, "f448fd2a949274159b33900908dc0ae874d4f31b453b49cef00aacd918357b87") -- Depot 3938642
setManifestid(3938642, "3443356383801863266", 1582406635)
addappid(3938643, 1, "8551351d89fd3b86c4132de374facbba19d0b2084eadb0254c67df6e61d6e11e") -- Depot 3938643
setManifestid(3938643, "2627617100699415411", 1561969347)