-- Lua provided by RyzenAPI
-- Game: Ugoku Sushi Bar

-- MAIN APPLICATION
addappid(3938640) -- Ugoku Sushi Bar

-- MAIN APP DEPOTS / PACKAGES
addappid(3938641, 1, "0273ab2dc8703a3a60a94a8a1145cfb3c0e9418e66088b1754e618af892711cd") -- Depot 3938641
addappid(3938642, 1, "f448fd2a949274159b33900908dc0ae874d4f31b453b49cef00aacd918357b87") -- Depot 3938642
addappid(3938643, 1, "8551351d89fd3b86c4132de374facbba19d0b2084eadb0254c67df6e61d6e11e") -- Depot 3938643

