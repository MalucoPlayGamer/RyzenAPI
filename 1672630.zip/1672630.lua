-- Lua provided by RyzenAPI
-- Game: addappid(1672630)

-- MAIN APPLICATION
addappid(1672630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672631, 1, "43b1457d0d0e10943a01cf880e4fd96f4f24d6c83983c434bdc9bc17881e829c")
