-- Lua provided by RyzenAPI
-- Game: Mononoke Slashdown

-- MAIN APPLICATION
addappid(1672630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672631, 1, "43b1457d0d0e10943a01cf880e4fd96f4f24d6c83983c434bdc9bc17881e829c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
