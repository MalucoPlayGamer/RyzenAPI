-- Lua provided by RyzenAPI
-- Game: AppID 2568000

-- MAIN APPLICATION
addappid(2568000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568001, 1, "fd09b6ed1a7091551efc61e20bdff542699a9829e33e20940f311f0bc2111c66")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
