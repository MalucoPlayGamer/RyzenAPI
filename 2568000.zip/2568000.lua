-- Lua provided by RyzenAPI
-- Game: 2568000

-- MAIN APPLICATION
addappid(2568000)
-- Game: addappid(2568000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568001, 1, "fd09b6ed1a7091551efc61e20bdff542699a9829e33e20940f311f0bc2111c66")
