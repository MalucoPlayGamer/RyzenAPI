-- Lua provided by RyzenAPI
-- Game: addappid(487370)

-- MAIN APPLICATION
addappid(487370)

-- MAIN APP DEPOTS / PACKAGES
addappid(487371, 1, "41a2ba8394f5189c18140403ef0219c7eb9e67949ea3708acfc13015870fea4e")
