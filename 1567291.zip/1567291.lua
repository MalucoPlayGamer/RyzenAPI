-- Lua provided by RyzenAPI
-- Game: 1567291

-- MAIN APPLICATION
addappid(1567291)
-- Game: addappid(1567291)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567291,0,"0a7133ecbc4404f93f5eba4e17f9dfd37c9b89b970477a118fbc5a6e46895d4c")
