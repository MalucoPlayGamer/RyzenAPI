-- Lua provided by RyzenAPI
-- Game: 3413330

-- MAIN APPLICATION
addappid(3413330)
-- Game: addappid(3413330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413331, 1, "6c91026a2af2b0ff52c0c25b7b17ebf0cebe87d0a28a9ae700dd4791c93a0434")
