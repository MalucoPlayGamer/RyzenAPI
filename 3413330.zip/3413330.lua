-- Lua provided by RyzenAPI
-- Game: AppID 3413330

-- MAIN APPLICATION
addappid(3413330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413331, 1, "6c91026a2af2b0ff52c0c25b7b17ebf0cebe87d0a28a9ae700dd4791c93a0434")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
