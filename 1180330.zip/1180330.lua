-- Lua provided by RyzenAPI
-- Game: addappid(1180330)

-- MAIN APPLICATION
addappid(1180330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180331, 1, "4b4ccd7d3c8150d14a44baa300b4d2ed9d5694c393a52655fdb6a89b835754bf")
