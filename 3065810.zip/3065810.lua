-- Lua provided by RyzenAPI
-- Game: One Room Dungeon

-- MAIN APPLICATION
addappid(3065810)
-- Game: addappid(3065810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3065811, 1, "e1b08aba9947af1cae1108f45aab20472d3ddccf83a59792f23e9d606b1d1620")
