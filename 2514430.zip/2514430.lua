-- Lua provided by SkyAPI 
-- Game: School Bus Driving Simulator
addappid(2514430)
addappid(2514431, 1, "c80a52aba3e7d433e4469f81f4e594b008b61fc724088b2ae575c004cd76dd05")
