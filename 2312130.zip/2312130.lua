-- Lua provided by RyzenAPI
-- Game: addappid(2312130)

-- MAIN APPLICATION
addappid(2312130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312131, 1, "4e5fbb99c1fc93f87f7fcd749a5aec64969361774ab2456423ab768e81bed99b")
