-- Lua provided by RyzenAPI
-- Game: AppID 2312130

-- MAIN APPLICATION
addappid(2312130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312131, 1, "4e5fbb99c1fc93f87f7fcd749a5aec64969361774ab2456423ab768e81bed99b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
