-- Lua provided by RyzenAPI
-- Game: Kapellmeister

-- MAIN APPLICATION
addappid(1909090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909091, 1, "b827e06509a32a12638a75a9f68c9dd422dd5c796d3dc1d5cabc1974c78255cd")

