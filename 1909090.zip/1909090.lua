-- Lua provided by SkyAPI 
-- Game: Kapellmeister
addappid(1909090)
addappid(1909091, 1, "b827e06509a32a12638a75a9f68c9dd422dd5c796d3dc1d5cabc1974c78255cd")
