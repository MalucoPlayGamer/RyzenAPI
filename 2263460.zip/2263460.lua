-- Lua provided by RyzenAPI
-- Game: ΔV: Rings of Saturn - Deep Weeb

-- MAIN APPLICATION
addappid(2263460)
-- Game: addappid(2263460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263460,0,"ae3dfa3698d2da7fb47602c9b9bda354244a9bf11ae13f8e180b12df384cca43")
