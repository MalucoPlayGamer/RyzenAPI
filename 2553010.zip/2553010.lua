-- Lua provided by RyzenAPI
-- Game: 2553010

-- MAIN APPLICATION
addappid(2553010)
-- Game: addappid(2553010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553011, 1, "03f7b19c3a6047b421e5418185fc15e0d7ce63c1057be9daf39e52d6a0c7158c")
