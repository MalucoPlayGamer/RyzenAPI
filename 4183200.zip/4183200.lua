-- Lua provided by RyzenAPI
-- Game: Pig Island 🐗

-- MAIN APPLICATION
addappid(4183200)

-- MAIN APP DEPOTS / PACKAGES
addappid(4183201,0,"830b194c2a0ba9ca67c6c4e1436bf81fa2ad088bee71897615c8a6d7e42b6749")

