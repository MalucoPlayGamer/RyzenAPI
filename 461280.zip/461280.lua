-- Lua provided by RyzenAPI
-- Game: Missileman Origins

-- MAIN APPLICATION
addappid(461280)

-- MAIN APP DEPOTS / PACKAGES
addappid(461281, 1, "bbd3f13b1d047e22f88ad1065023733239ce4c1a33ba3e91b721a4ea4e79d115")
