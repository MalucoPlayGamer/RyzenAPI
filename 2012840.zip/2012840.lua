-- Lua provided by RyzenAPI
-- Game: Portal with RTX

-- MAIN APPLICATION
addappid(2012840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012841, 1, "1e1cfddfae65b4dcb58dc80af760acf0c80c793d178c7e7406637f82a5f076cb")
addappid(2012842, 1, "b5eb4d08602ad47b81cfb91e638702b1bfd51b94c80652c805e939fb4147f1dd")
addappid(2012845, 1, "d7bdddc10ad83ab3d46c8403ff2a8d83688bda6ef6b3feda2ce7062ebea78b52")
addappid(2012846, 1, "06f05b85e3171898d6816a21a8d823640276c6cb77478681e98926017d961186")
addappid(2012847, 1, "0b9fea6807eb580ba9adf0e2dcba4ea5b9a599beb6b43aa09f920116125af90c")
addappid(2012848, 1, "7be3bd7eb9fb012c9b0f2d83a4f837e5161a9989ea7255a66d79045a35de7ada")
addappid(2012849, 1, "f9635127d02200459f36233f31e7c2f2b55679eeb168d83c5e7824b339f2e935")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
