-- Lua provided by RyzenAPI
-- Game: Game: AppID 501380

-- MAIN APPLICATION
addappid(501380)
-- Game: addappid(501380)

-- MAIN APP DEPOTS / PACKAGES
addappid(501381, 1, "0f8e470451b99d647fc43e62f4e1897210f89d8b6f09581a8a7bf344aaad0a4c")
