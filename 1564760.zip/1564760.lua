-- Lua provided by RyzenAPI
-- Game: Bro, where's My head???

-- MAIN APPLICATION
addappid(1564760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564761, 1, "943fee29f211c7f00a3cba930cafd5b2716e4ed3a734618c1b710dea20fecaee")
addappid(1564762, 1, "b5f8bc4fb0ab7a6d9a5f006530d207fe572f7399a896c3cfa7f2f12849e1b9ff")
