-- Lua provided by RyzenAPI
-- Game: 281860

-- MAIN APPLICATION
addappid(281860)
-- Game: addappid(281860)

-- MAIN APP DEPOTS / PACKAGES
addappid(281861, 1, "9e6c1a939e2b7daf1a0615bf9ca6f2eff098ae8be14107cf99945be23bc5bd69")
addappid(281862, 1, "edd5a8eb4371e6d52a9e044de014a1c442a28cd64fab9e2faf2a5b4d5b75b2fe")
