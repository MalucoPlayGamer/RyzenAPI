-- Lua provided by RyzenAPI
-- Game: AppID 285740

-- MAIN APPLICATION
addappid(285740)

-- MAIN APP DEPOTS / PACKAGES
addappid(285741, 1, "4eb8081b5b99f6a6ecaa6becaa0630e4615c8ceb08900ca68e1fe684a4e105cb")
addappid(285742, 1, "436fb9ebc02d7f27e468681d1b0d9cb24850e222c0012921055847e69ac4eb88")
addappid(285743, 1, "07ba61b6e71ad344eaec98b58b881bba6a11646ac79d8aec63ed11d9aed13d84")

