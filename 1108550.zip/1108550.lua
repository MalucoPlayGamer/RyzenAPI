-- Lua provided by RyzenAPI
-- Game: Game: Zen Chess: Blindfold Masters

-- MAIN APPLICATION
addappid(1108550)
-- Game: addappid(1108550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108551, 1, "94a73733927dafb6f0a605ddc73012a59956d5a88645ae5abbfb4ece69b35f0d")
