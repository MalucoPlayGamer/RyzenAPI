-- Lua provided by RyzenAPI
-- Game: addappid(3805060)

-- MAIN APPLICATION
addappid(3805060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3805061, 1, "4b6368d32fcb8371ea1a62658c3cb8b27f3ef15047a4668a687a43fac3ac9689")
