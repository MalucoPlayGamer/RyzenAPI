-- Lua provided by RyzenAPI 
-- Game: The Casting of Frank Stone™ Demo
addappid(3105370)
addappid(3105371, 1, "31d0281eb4d7984c7b88025a70255e72d76728f8320e58826b8f9cf64dbe5a89")
