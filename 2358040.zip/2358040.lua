-- Lua provided by RyzenAPI
-- Game: addappid(2358040)

-- MAIN APPLICATION
addappid(2358040)
addappid(4054140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358041, 1, "4964642b7d7c8cb0ddc126df9d808bc0410f2e64cc00b6c29728ead43011e71d")
