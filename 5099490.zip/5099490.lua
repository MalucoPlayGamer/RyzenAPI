-- Lua provided by RyzenAPI
-- Game: Oh My Hat

-- MAIN APPLICATION
addappid(5099490) -- Oh My Hat

-- MAIN APP DEPOTS / PACKAGES
addappid(5099491, 1, "90810897ee8c2e673d5b5d3b63301cc3cc7ad9307b63c0cb7ce7ef163b662f29") -- Depot 5099491

