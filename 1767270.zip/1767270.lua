-- Lua provided by SkyAPI 
-- Game: Forest adventure
addappid(1767270)
addappid(1767271, 1, "b3e29af005b77b55fb4e371fd4cadd66d67e6bc046c0a0ad3db085635c1c99c3")
