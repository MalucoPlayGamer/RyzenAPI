-- Lua provided by RyzenAPI
-- Game: Game: Forest adventure

-- MAIN APPLICATION
addappid(1767270)
-- Game: addappid(1767270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767271, 1, "b3e29af005b77b55fb4e371fd4cadd66d67e6bc046c0a0ad3db085635c1c99c3")
