-- Lua provided by RyzenAPI 
-- Game: AppID 2413770
addappid(2413770)
addappid(2413771, 1, "9379a7a48562b21aa2855edd015f470df4934fd82752184fb5e850386367312b")
