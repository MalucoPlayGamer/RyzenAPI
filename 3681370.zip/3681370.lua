-- Lua provided by RyzenAPI
-- Game: 3681370

-- MAIN APPLICATION
addappid(3681370)
-- Game: addappid(3681370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3681371, 1, "6f228a8ba06f8bfa9240b2d31cc5aa8921d08fe72a03a69772cc8dc262acaddb")
