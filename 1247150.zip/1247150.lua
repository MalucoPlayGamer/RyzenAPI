-- Lua provided by RyzenAPI
-- Game: addappid(1247150)

-- MAIN APPLICATION
addappid(1247150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247151, 1, "4f2a2b02c2bd060c77f55cafa375ad2844a70a954de2b49fac4445d788dd1d18")
addappid(1247152, 1, "eb08b43cf150d14d2cc5c3fc3dfb1a88081bf71882a12cc51d7959eaeea76879")
