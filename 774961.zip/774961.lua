-- Lua provided by RyzenAPI
-- Game: Squad - Public Test Dedicated Server

-- MAIN APPLICATION
addappid(774961)

-- MAIN APP DEPOTS / PACKAGES
addappid(774962, 1, "63618bb4520ddf0136d49d5b042450537f1bfc4a94c739226eb651e4231d220c")
addappid(774963, 1, "3fb1521421675b42b411e03bfd3fa9b719c30aa938da23d84557ee34d8f750b3")
