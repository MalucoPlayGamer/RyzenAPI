-- Lua provided by RyzenAPI
-- Game: The Legend of Legacy HD Remastered

-- MAIN APPLICATION
addappid(2516220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516221, 1, "46af2b2482af51cc318d5bbe40f2d2c1340f26195aff3ade3b15b58ec0319ccf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2728870)
addappid(2733170)
addappid(2781930)
