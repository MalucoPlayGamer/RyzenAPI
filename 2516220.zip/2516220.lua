-- Lua provided by RyzenAPI
-- Game: addappid(2516220)

-- MAIN APPLICATION
addappid(2516220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516221, 1, "46af2b2482af51cc318d5bbe40f2d2c1340f26195aff3ade3b15b58ec0319ccf")
