-- Lua provided by RyzenAPI
-- Game: All-In-One Summer Sports VR

-- MAIN APPLICATION
addappid(2074750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074751, 1, "bc4c67d126b112317091042cc816e2dad30124bec7610d0ab5086895fff0aa23")

