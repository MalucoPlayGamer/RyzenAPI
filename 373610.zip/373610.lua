-- Lua provided by RyzenAPI
-- Game: Game: Shoot 1UP DX

-- MAIN APPLICATION
addappid(373610)
-- Game: addappid(373610)

-- MAIN APP DEPOTS / PACKAGES
addappid(373611, 1, "1ae1747933275165a58ab7d04b56ed0fd765536074451fc776a31620174b5292")
