-- Lua provided by RyzenAPI
-- Game: Shoot 1UP DX

-- MAIN APPLICATION
addappid(373610)

-- MAIN APP DEPOTS / PACKAGES
addappid(373611, 1, "1ae1747933275165a58ab7d04b56ed0fd765536074451fc776a31620174b5292")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
