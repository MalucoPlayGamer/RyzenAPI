-- Lua provided by RyzenAPI 
-- Game: UBERSLAUGHTER
addappid(2595540)
addappid(2595541, 1, "af5a08bc18860f9dbc377baac9d62f6a8a072ad429a58718568bbf82123663f9")
