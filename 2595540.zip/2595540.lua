-- Lua provided by RyzenAPI
-- Game: UBERSLAUGHTER

-- MAIN APPLICATION
addappid(2595540)
-- Game: addappid(2595540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595541, 1, "af5a08bc18860f9dbc377baac9d62f6a8a072ad429a58718568bbf82123663f9")
