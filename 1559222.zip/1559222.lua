-- Lua provided by RyzenAPI
-- Game: FUSER™ - Lady Gaga & BLACKPINK - "Sour Candy"

-- MAIN APPLICATION
addappid(1559222)
-- Game: addappid(1559222)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559222,0,"0b0e8a48a8dc939fc7e9bbfdb731c3330695f779e4de55aeb7a62db4dbde5dd6")
