-- Lua provided by RyzenAPI
-- Game: 2280200

-- MAIN APPLICATION
addappid(2280200)
-- Game: addappid(2280200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280201, 1, "b3f601de2608c3de1513893dd8d3d8566c7f173afb91389dbd66d61df22bddb3")
