-- Lua provided by RyzenAPI
-- Game: Prisme 7

-- MAIN APPLICATION
addappid(1282500)
-- Game: addappid(1282500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282501, 1, "74e0ad0520b37b121d6af23837e02883b76fa70851c66f83d6157cf67fc3cef7")
