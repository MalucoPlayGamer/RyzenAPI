-- Lua provided by RyzenAPI 
-- Game: AppID 2272270
addappid(2272270)
addappid(2272271, 1, "e0d9ebce3754f996b270df2fb60684a2d37f4a854ad6184c6f4d81f4a8e2984a")
