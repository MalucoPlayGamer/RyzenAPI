-- Lua provided by RyzenAPI
-- Game: Situation TARFU

-- MAIN APPLICATION
addappid(2374210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374211, 1, "3e56b48035072cec7b5c7cd90cd2df32beaa2a7a019d85afb480c1059825d086")

