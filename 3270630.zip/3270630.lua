-- Lua provided by RyzenAPI
-- Game: Grimstone Survivors Demo

-- MAIN APPLICATION
addappid(3270630)
-- Game: addappid(3270630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3270631, 1, "712d75fd9cac2d84bc37e7a5f00451f59b2c2459ab083f08cff848435d19c711")
