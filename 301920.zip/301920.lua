-- Lua provided by RyzenAPI
-- Game: War of the Human Tanks - ALTeR

-- MAIN APPLICATION
addappid(301920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(301921, 1, "6125ff1a7b4eb5f0084c61b0408783f2df02248fd91d3ea2d7564742872dc2b0")

