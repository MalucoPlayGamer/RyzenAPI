-- Lua provided by RyzenAPI
-- Game: Game: War of the Human Tanks - ALTeR

-- MAIN APPLICATION
addappid(301920)
-- Game: addappid(301920)

-- MAIN APP DEPOTS / PACKAGES
addappid(301921, 1, "6125ff1a7b4eb5f0084c61b0408783f2df02248fd91d3ea2d7564742872dc2b0")
