-- Lua provided by RyzenAPI
-- Game: 714570

-- MAIN APPLICATION
addappid(714570)
-- Game: addappid(714570)

-- MAIN APP DEPOTS / PACKAGES
addappid(714571, 1, "553acc5b3d7d875c3e7c84c8e409e83acb7b8acb7d732bb80aae3adc6890c7ae")
