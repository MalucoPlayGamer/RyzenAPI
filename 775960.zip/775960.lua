-- Lua provided by RyzenAPI
-- Game: The Tower of Beatrice

-- MAIN APPLICATION
addappid(775960)

-- MAIN APP DEPOTS / PACKAGES
addappid(775961, 1, "2345b16e7057501fc85b50999d0918ae0395f20362bf390dd9a5353482faf148")
addappid(1040330, 0, "d4a64b55ef78b98da59718d6955bba9404587ace794c59f1bfa95a0dd5d6cd58")

