-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1247480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247480,0,"b3ba31a379a08759b8670d353529399a8c05dafcde3b02d2ca451b0988abc791")
