-- Lua provided by RyzenAPI
-- Game: Steampunk Tower 2

-- MAIN APPLICATION
addappid(622460)
-- Game: addappid(622460)

-- MAIN APP DEPOTS / PACKAGES
addappid(622461, 1, "a419f83c03039586bc385897c9df6ec7cc9194164978862b0bd435810d5025cf")
addappid(622462, 1, "22244397152b5bae087083b35b066577074e99ea5caa3bc141d73620deb8fa5f")
