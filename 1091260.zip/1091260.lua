-- Lua provided by RyzenAPI
-- Game: Crunch

-- MAIN APPLICATION
addappid(1091260)
addappid(4410140)
addappid(4502920)
addappid(4502930)
addappid(4502940)
addappid(4606710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091261, 1, "f199c3eac47435c70a23349ea91d7ef2812d69304a6c816bb3766ffa2a5799e7")
addappid(1091262, 1, "62c634761f802e60f9b005673ae6da0c2a541328c6883aa435df16873d332041")

