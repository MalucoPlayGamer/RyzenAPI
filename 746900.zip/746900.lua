-- Lua provided by RyzenAPI
-- Game: A song in the void

-- MAIN APPLICATION
addappid(746900)

-- MAIN APP DEPOTS / PACKAGES
addappid(746901,0,"3b438a8afab827e5622e7296abedfc24b26e508679f7aa8cd8b5c1590d327f19")

