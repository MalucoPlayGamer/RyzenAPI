-- Lua provided by RyzenAPI
-- Game: 1141220

-- MAIN APPLICATION
addappid(1141220)
addappid(1548200)
-- Game: addappid(1141220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141221, 1, "4eecb0dd5caf73aab793d017b553ce379da1a52832df33d9f0dd8d48b6cead55")
