-- Lua provided by RyzenAPI
-- Game: AppID 1708420

-- MAIN APPLICATION
addappid(1708420)
-- Game: addappid(1708420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708421, 1, "49b0236f8fd054ccdc48afbac1d0563d5adca7b0990977a71dc24f1db329005c")
