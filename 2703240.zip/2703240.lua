-- Lua provided by RyzenAPI
-- Game: Scream or Die - Virtual Circus

-- MAIN APPLICATION
addappid(2703240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703241, 1, "db881abba73d9a90de9807d541e6a40ac7254a775793bc256afce89b34eb1292")
