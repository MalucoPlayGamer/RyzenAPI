-- Lua provided by RyzenAPI 
-- Game: Sex Prison VR
addappid(1380620)
addappid(1380621, 1, "fecc13a1feb37a230f493ec9547f47924f2462473c1c0842ae6a19edf56561c1")
