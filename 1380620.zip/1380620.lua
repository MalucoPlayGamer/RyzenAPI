-- Lua provided by RyzenAPI
-- Game: Game: Sex Prison VR

-- MAIN APPLICATION
addappid(1380620)
-- Game: addappid(1380620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380621, 1, "fecc13a1feb37a230f493ec9547f47924f2462473c1c0842ae6a19edf56561c1")
