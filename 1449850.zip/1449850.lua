-- Lua provided by RyzenAPI
-- Game: Yu-Gi-Oh! Master Duel

-- MAIN APPLICATION
addappid(1449850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449853,0,"068dd00ef43bc982b5706b462dc417325371f29d557f9d0651d40aba06c1aaa6")
