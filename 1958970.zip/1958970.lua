-- Lua provided by RyzenAPI
-- Game: Idle Galaxy

-- MAIN APPLICATION
addappid(1958970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958971, 1, "f8849ee8d0b48bf04011c70a28322f649801b17c525be81859107d9cc9f180d1")

