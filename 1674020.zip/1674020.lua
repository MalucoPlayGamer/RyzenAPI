-- Lua provided by RyzenAPI
-- Game: Lost in Red Valley

-- MAIN APPLICATION
addappid(1674020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674021, 1, "78a08fcedbbfc40ab12b3fc6a02505ea7de26c4b2cb730d740eed572dc197c7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
