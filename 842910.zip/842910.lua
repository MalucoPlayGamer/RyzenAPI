-- Lua provided by RyzenAPI
-- Game: 842910

-- MAIN APPLICATION
addappid(842910)
-- Game: addappid(842910)

-- MAIN APP DEPOTS / PACKAGES
addappid(842911, 1, "4cb3b07281a03a850a09b8cf49dac43765b5243b4e481c8944c85ff028814c00")
