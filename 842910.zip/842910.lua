-- Lua provided by RyzenAPI
-- Game: The MISSING: J.J. Macfield and the Island of Memories

-- MAIN APPLICATION
addappid(842910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(842911, 1, "4cb3b07281a03a850a09b8cf49dac43765b5243b4e481c8944c85ff028814c00")

