-- Lua provided by RyzenAPI
-- Game: Game: Lorelei and the Laser Eyes

-- MAIN APPLICATION
addappid(2008920)
-- Game: addappid(2008920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008921, 1, "aaa44ef0454a32c89d1c1e187e13f74045752843b01b4c3bf168254ff8ea15d1")
