-- Lua provided by RyzenAPI 
-- Game: AppID 1488650
addappid(1488650)
addappid(1488651, 1, "aa26b0a1d4fef24747d5c63a176615868d5845d1761b7acdfca97e36d4ab6ad3")
