-- Lua provided by RyzenAPI
-- Game: Ascension to the Throne: Valkyrie

-- MAIN APPLICATION
addappid(281520)

-- MAIN APP DEPOTS / PACKAGES
addappid(281521, 1, "34e3242a0689ab3ac8c987fb644f9d2400dda05dcf51b0fe37b676aecea06549")
addappid(281522, 1, "3f841719a3ec293ed66f03ddba3fa3f2ada1f94963f51988d1508fec580e4ec1")
addappid(281525, 1, "de31786586cb773263d30da5258dd3d015f90ca74f21a2ab824774846ea44328")

