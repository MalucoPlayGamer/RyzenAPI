-- Lua provided by SkyAPI 
-- Game: Wooden Sen'SeY
addappid(259830)
addappid(259831, 1, "92982b36b628685f7ae3d08838dc4fcc06b5f0c7f4b5bcc85d5b5b6d5dcedf83")
addappid(259832, 1, "e972ea2111301123aac37a74eac7a85580b5cf39b29271dc3bcbb20ca02db402")
addappid(259833, 1, "0d52e474331269ce28535e072d69f76351aed10073e6db496cba02db5d13727c")
addappid(273700, 0, "e123ab3b030227aa48b12c73ecddc1feed8732b99f0eda8a122635f1bb9b3ded")
