-- Lua provided by RyzenAPI
-- Game: Game: AppID 1566600

-- MAIN APPLICATION
addappid(1566600)
-- Game: addappid(1566600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566601, 1, "9adc7a220591cecbaffdf057e74af047bbf3762c42c572ab6fb93a10c6cbef10")
