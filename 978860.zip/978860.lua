-- Lua provided by RyzenAPI
-- Game: 978860

-- MAIN APPLICATION
addappid(978860)
-- Game: addappid(978860)

-- MAIN APP DEPOTS / PACKAGES
addappid(978860,0,"b5b39146817d59484d352e1badda65bcdb9ae159e25066b204fd2b3bea682363")
