-- Lua provided by RyzenAPI
-- Game: Professor Watts Memory Match: Expressions

-- MAIN APPLICATION
addappid(932670)
-- Game: addappid(932670)

-- MAIN APP DEPOTS / PACKAGES
addappid(932671, 1, "2f4a4caf0245f9fa79e09f39a25838b44c86bd5a98ee5e7b2806bab942d9b870")
