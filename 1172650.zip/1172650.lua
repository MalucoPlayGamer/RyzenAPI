-- Lua provided by SkyAPI 
-- Game: INDUSTRIA
addappid(1172650)
addappid(1172651, 1, "17a7c09d7a646cc91072b4e15f029588f55a45d69e7d9d58d34c7b61442a19d8")
