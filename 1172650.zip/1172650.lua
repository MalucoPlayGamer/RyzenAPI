-- Lua provided by RyzenAPI
-- Game: Game: INDUSTRIA

-- MAIN APPLICATION
addappid(1172650)
-- Game: addappid(1172650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172651, 1, "17a7c09d7a646cc91072b4e15f029588f55a45d69e7d9d58d34c7b61442a19d8")
