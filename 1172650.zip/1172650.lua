-- Lua provided by RyzenAPI
-- Game: INDUSTRIA

-- MAIN APPLICATION
addappid(1172650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172651, 1, "17a7c09d7a646cc91072b4e15f029588f55a45d69e7d9d58d34c7b61442a19d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
