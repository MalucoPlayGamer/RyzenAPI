-- Lua provided by RyzenAPI
-- Game: addappid(2744230)

-- MAIN APPLICATION
addappid(2744230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744231, 1, "952bf80a1ffb148cf2e34ea0ea26e3e56289ab97128367d5809bec1d71f3bc7e")
