-- Lua provided by RyzenAPI 
-- Game: Alvara
addappid(2527640)
addappid(2527641, 1, "bdf6be11b5f5252aba637863a783d1edb53d21cb44dd49e392af2d09cd84c871")
