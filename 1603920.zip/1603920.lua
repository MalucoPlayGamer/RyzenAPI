-- Lua provided by RyzenAPI
-- Game: 暴れん坊天狗 & ZOMBIE NATION

-- MAIN APPLICATION
addappid(1603920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1603921, 1, "711b76713a92d03b876cf444f0183230886a26ffbce604a2283a7ee042c6e02c")

