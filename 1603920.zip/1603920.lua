-- Lua provided by RyzenAPI
-- Game: Game: 暴れん坊天狗 & ZOMBIE NATION

-- MAIN APPLICATION
addappid(1603920)
-- Game: addappid(1603920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603921, 1, "711b76713a92d03b876cf444f0183230886a26ffbce604a2283a7ee042c6e02c")
