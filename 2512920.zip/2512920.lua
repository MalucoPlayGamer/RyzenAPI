-- Lua provided by RyzenAPI
-- Game: Game: Garlic Builder

-- MAIN APPLICATION
addappid(2512920)
-- Game: addappid(2512920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512921, 1, "9fca7e78672c35d13dd1df10071697cbe1cf8f938044bfe426d03140d0491486")
