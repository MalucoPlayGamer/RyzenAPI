-- Lua provided by RyzenAPI
-- Game: A Smooth Game (Unlike... Life)

-- MAIN APPLICATION
addappid(2142100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142101, 1, "bcc3fe18a4cc6a8c52cdbec90ae05a40b7edc3db30ac34865e5d60873aabf6cb")

