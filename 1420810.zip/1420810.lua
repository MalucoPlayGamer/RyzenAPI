-- Lua provided by RyzenAPI
-- Game: Touhou Kaeizuka ～ Phantasmagoria of Flower View.

-- MAIN APPLICATION
addappid(1420810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420811, 1, "8e6c7823fc7bc4c140b641c402e601cc661985f8c219995e4534c5fa2a82e526")
