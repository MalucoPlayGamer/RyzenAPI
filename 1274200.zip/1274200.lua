-- Lua provided by RyzenAPI
-- Game: 1274200

-- MAIN APPLICATION
addappid(1274200)
-- Game: addappid(1274200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274201, 1, "34dda9d775ec41a8471a1e9a393fa484ed0587717b4ebfc7c5ff8c7acdfce0a8")
