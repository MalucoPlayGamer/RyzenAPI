-- Lua provided by RyzenAPI
-- Game: addappid(1581890)

-- MAIN APPLICATION
addappid(1581890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581891, 1, "a7e7f3007be0235e3cf957ed1ef021b2ea93300d39a9a7688ed835747c55bd28")
