-- Lua provided by RyzenAPI 
-- Game: The Magic of Three
addappid(1581890)
addappid(1581891, 1, "a7e7f3007be0235e3cf957ed1ef021b2ea93300d39a9a7688ed835747c55bd28")
