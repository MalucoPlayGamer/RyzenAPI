-- Lua provided by RyzenAPI
-- Game: Lilith Wants to Buy Your Soul

-- MAIN APPLICATION
addappid(2266820)

