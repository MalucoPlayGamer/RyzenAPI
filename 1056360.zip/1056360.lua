-- Lua provided by RyzenAPI
-- Game: TouHou Makuka Sai ~ Fantastic Danmaku Festival Part II OST

-- MAIN APPLICATION
addappid(1056360)
addappid(1056361)
addappid(1056362)
addappid(1056364)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056360,0,"47891ffded1659f7b4ed785e925337b0022b6ee94b449ad5f3ad6d54498e1481")
addappid(1056363,0,"b6fd51b32ac10432ae3846863e7bd890e9fbd878f29eceaab1c234b99fe04bd7")

