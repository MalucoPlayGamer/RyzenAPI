-- 4570770's Lua and Manifest Created by Hubcap Manifest
-- Blast'N Bounty
-- Created: July 22, 2026 at 14:43:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4570770) -- Blast'N Bounty
-- MAIN APP DEPOTS
addappid(4570771, 1, "07a325f6e6148b0f953fe8a99d2a02de76a139d8677012cfab50ea2f5ab0a187") -- Depot 4570771
setManifestid(4570771, "4884176267243692022", 1791477410)