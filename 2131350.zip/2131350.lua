-- Lua provided by RyzenAPI
-- Game: My Coworker is an Idiot

-- MAIN APPLICATION
addappid(2131350)
-- Game: addappid(2131350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131351, 1, "d76a684923c6f5b192fb66db174b1c77f210a7ed333f5437b7607e5d62c83031")
