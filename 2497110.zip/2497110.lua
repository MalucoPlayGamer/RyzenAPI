-- Lua provided by RyzenAPI
-- Game: Game: Idle Weaponshop

-- MAIN APPLICATION
addappid(2497110)
-- Game: addappid(2497110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497111, 1, "2cb79265dfd6bf278c3e1a788a7a7f28bf9fa123f6142c0c9c9937af0782cc55")
