-- Lua provided by SkyAPI 
-- Game: Idle Weaponshop
addappid(2497110)
addappid(2497111, 1, "2cb79265dfd6bf278c3e1a788a7a7f28bf9fa123f6142c0c9c9937af0782cc55")
