-- Lua provided by RyzenAPI
-- Game: Game: AppID 2405470

-- MAIN APPLICATION
addappid(2405470)
-- Game: addappid(2405470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405471, 1, "729fdd24fa9d3e0b9658612203391b4a60270a8e36995dc788710e89cde44a79")
