-- Lua provided by RyzenAPI
-- Game: IIN

-- MAIN APPLICATION
addappid(795110)
-- Game: addappid(795110)

-- MAIN APP DEPOTS / PACKAGES
addappid(795111, 1, "aa68093950cc8439be5967741ff3088b858a69d595a9621d5df06b9f4b0e7945")
