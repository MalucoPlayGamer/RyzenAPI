-- Lua provided by RyzenAPI
-- Game: Bedroom Battlegrounds Demo

-- MAIN APPLICATION
addappid(3015890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015891, 1, "78157b10239873354751da7d46a3d7df096b4384fd83cb90d33ed53df2d4a31c")
