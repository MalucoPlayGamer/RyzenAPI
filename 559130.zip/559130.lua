-- Lua provided by RyzenAPI
-- Game: Inner Voices

-- MAIN APPLICATION
addappid(559130)
addappid(643760)

-- MAIN APP DEPOTS / PACKAGES
addappid(559131, 1, "1f256d0f36ce1d89fc1a39d43d40c56854e152f22b76abe11976dafc43856a45")
addappid(559134, 1, "3a554f1540bb2a335a035666688d6575fd2191497dbb63a628aafbe97424c300")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
