-- Lua provided by RyzenAPI
-- Game: Inner Voices

-- MAIN APPLICATION
addappid(559130)
addappid(643760)

-- MAIN APP DEPOTS / PACKAGES
addappid(559131, 1, "1f256d0f36ce1d89fc1a39d43d40c56854e152f22b76abe11976dafc43856a45")
addappid(559134, 1, "3a554f1540bb2a335a035666688d6575fd2191497dbb63a628aafbe97424c300")
