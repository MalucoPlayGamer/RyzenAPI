-- Lua provided by RyzenAPI
-- Game: PATHOGEN X

-- MAIN APPLICATION
addappid(2508980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508982,0,"95a74e7c291260d0c939230773fe28e79b583253e8a3688dd295a129c9e27af6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4563470)
