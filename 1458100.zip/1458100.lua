-- Lua provided by RyzenAPI
-- Game: Cozy Grove

-- MAIN APPLICATION
addappid(1458100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458101, 1, "cc88233f6fa038e76138ab1766a46998a555d867ef3651f7419af88e3be2596c")

