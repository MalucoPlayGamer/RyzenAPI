-- Lua provided by RyzenAPI
-- Game: Glare

-- MAIN APPLICATION
addappid(228983)
addappid(228990)
addappid(243140)
addappid(243142)
addappid(243143)
addappid(243144)
addappid(243145)
addappid(243146)
addappid(243147)

-- MAIN APP DEPOTS / PACKAGES
addappid(243148,0,"c4fe5fdfbece58a4b835c747dd1dda3c13a668bd0b4d5ec37bf9e123c778f9d7")
addappid(243149,0,"c9d9f0a5cbb679331bd7c204085f88586d13265c68ddcb48279d80c877a4de1b")
addappid(243150,0,"5028da71c068f793c06ffffcd3eebe7c3f27ceb1c4ee4970785ab21fd3f466da")

