-- Lua provided by RyzenAPI
-- Game: Middle-earth™: Shadow of Mordor™

-- MAIN APPLICATION
addappid(311670)
addappid(313370)
addappid(313371)
addappid(313372)
addappid(313373)
addappid(313374)
addappid(313375)
addappid(313380)
addappid(313381)
addappid(318390)
addappid(318400)
addappid(318401)
addappid(318402)
addappid(318410)
addappid(318411)
addappid(318412)
addappid(318413)
addappid(318414)
addappid(318420)
addappid(318550) -- Middle-earth Shadow of Mordor - GOTY Edition Upgrade
addappid(319360) -- Middle-earth Shadow of Mordor - Bundle F
addappid(319361) -- Middle-earth Shadow of Mordor - Bundle G
addappid(322060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(241930, 1, "81bfee6e10cd4a6371dd4ab1c957fe8eb3b3a4ae3188880d100fefad1930b528") -- Middle-earth™: Shadow of Mordor™
addappid(241931, 1, "7c4e1815a9ce8c6e129cc22c57358f675b3df4a786012fd586c279052d33a0a0") -- Middle-earth: Shadow of Mordor
addappid(241933, 1, "7dbae5566c776defb9c115939ae4ba023fc8107c3abe7e7d6efdf0fb14672b95") -- Middle-earth: Shadow of Mordor Japanese Build Only
addappid(241934, 1, "512b0b2478b8bd7b62c88bcc0199069b43a9e214c4ba08832e2ff987232df6fa") -- Mac - Binary
addappid(241935, 1, "148a8f0fc1b2456ecf9d099cb8ebc65cbde52ff18838bad63f40fddfacbb7fa0") -- Mac - Main Game Data
addappid(241936, 1, "ff60b24da22ffd4c82766eeb04dc102b5f32121866cca9b579fd5805ab056cc9") -- Linux - Binary
addappid(241937, 1, "f5736ec91929e07ad2b17dc652e729e55a94c61b4e065abbc25b81e19698a1ac") -- Linux - Main Game Data
addappid(241938, 1, "2343c752576a4c6ed2fd261344d398ad8b77935ee5824433b2d9da483c88f1a7") -- Middle-earth Shadow of Mordor - Bright Lord - Mac - The Bright Lord
addappid(241939, 1, "b92b8c405edf8a193f73cf4e45102d724d978ec2b375dcf9c28746f6403e3748") -- Middle-earth Shadow of Mordor - Bright Lord - Linux - The Bright Lord
addappid(241940, 1, "ca88f001d4c03de73c1854355360d32ca1cffd5226dbdaee82982584589b5956") -- Middle-earth Shadow of Mordor - Test of Power - Mac - Test of Power
addappid(241941, 1, "91117e3ef5a014c5f65771b1682fa71a0cc4562b4de96a94ae64b8f2f072f8f5") -- Middle-earth Shadow of Mordor - Test of Power - Linux - Test of Power
addappid(241942, 1, "fd28f06ff22d6a8cb00f437c524a7aefb8dfaa0a5a55ae070562fdd9ead1f49e") -- Middle-earth Shadow of Mordor - Blood Hunters Warband - Mac - Blood Hunters Warband
addappid(241943, 1, "334bf0e38723bbcbcd1782cca799201a8525b32e773df100f133000a00993428") -- Middle-earth Shadow of Mordor - Blood Hunters Warband - Linux - Blood Hunters Warband
addappid(241944, 1, "bb1a217816b58973f791d47a1f92edac0daaf1ec58f041c88195dd4b794bc2fe") -- Middle-earth Shadow of Mordor - The Dark Ranger Character Skin - Mac - The Dark Ranger Character Skin
addappid(241945, 1, "e7265d761fda61321de8e7cdf8d6659d2464a583b22b5ec09b4a89e40e73485f") -- Middle-earth Shadow of Mordor - The Dark Ranger Character Skin - Linux - The Dark Ranger Character Skin
addappid(241946, 1, "13b8389b427ccfdd1515d9a136bcd35fd4a9bd0693e03d179806c61f7eac040b") -- Middle-earth Shadow of Mordor - Captain of the Watch Character Skin - Mac - Captain of the Watch Character Skin
addappid(241947, 1, "55a92ce00f8d357d1e0075e1058629eed90d4791af6a77a255b06dca3cf94828") -- Middle-earth Shadow of Mordor - Captain of the Watch Character Skin - Linux - Captain of the Watch Character Skin
addappid(241948, 1, "a2e5e4e8fa0cc99d81902c2a8ad5c9b50d6c83217caeb1794f752ea1b83c8d17") -- Middle-earth Shadow of Mordor - Orc Slayer Rune - Mac - Orc Slayer Rune
addappid(241949, 1, "cd3004efcbae9251008e44d06bca110adf9690fef35471e0170a003545e54450") -- Middle-earth Shadow of Mordor - Orc Slayer Rune - Linux - Orc Slayer Rune
addappid(311670, 1, "86d46a5a860445a99e60b022176f9589f94501f90898efdbd49a42a0f5dbcb12") -- Middle-earth Shadow of Mordor - HD Content - Middle-earth: Shadow of Mordor - HD Content (311670) Depot
addappid(311671, 1, "894fc089aa16f117bf74a359e42ac37cfbf8776d825f846479e4bc667cddd72f") -- Middle-earth Shadow of Mordor - Lord of the Hunt - Mac - Lord of the Hunt
addappid(311672, 1, "4f65ebf2c254f714fabb08a1190afa47a339d49d84c999729f01c3a9c278dbd3") -- Middle-earth Shadow of Mordor - Lord of the Hunt - Linux - Lord of the Hunt
addappid(311673, 1, "acd2aa7c66e7d771bb8a2dcb9782c25661ae6a302412295c4dbb6927ad03c1ee") -- Middle-earth Shadow of Mordor - Flame of Anor Rune - Mac - Flame of Anor Rune
addappid(311674, 1, "cdcc0d287207795b21f8f8632a4e12e8ab797e7d74f4599e8d7b5804933f665e") -- Middle-earth Shadow of Mordor - Flame of Anor Rune - Linux - Flame of Anor Rune
addappid(311675, 1, "ff4f3a1c90615ce4fa644caa962399538e1db17c2fb52d95f4808cf1a1635978") -- Middle-earth Shadow of Mordor - Flesh Burners Warband - Mac - Flesh Burners Warband
addappid(311676, 1, "6433f470fb79bf0060885d7c3d1f5647741a4773e3957702bcb1fdc7a19a4a10") -- Middle-earth Shadow of Mordor - Flesh Burners Warband - Linux - Flesh Burners Warband
addappid(311677, 1, "f4a8039cd205ce65479df355d2ae36d352bdd1c036b9ea85fa2cd63f3e70f33f") -- Middle-earth Shadow of Mordor - Berserks Warband - Mac - Berserks Warband
addappid(311678, 1, "7682c4646e432fd195c75022cda9e7d0de3ebc667b4c36eb635d02a85cf37850") -- Middle-earth Shadow of Mordor - Berserks Warband - Linux - Berserks Warband
addappid(311679, 1, "35de20988bc6b3e4a89edab7c6722cba9237611443937564e19d087883abb27d") -- Middle-earth Shadow of Mordor - Deadly Archer Rune - Mac - Deadly Archer Rune
addappid(313370, 1, "64dbfc5f47d8c9c95fbb59671f01927bbbc8ae72124036ac3b1d9d107d1f15f8") -- Middle-earth Shadow of Mordor - Captain of the Watch Character Skin - Middle-earth: Shadow of Mordor - Captain of the Watch Character Skin (313370) Depot
addappid(313371, 1, "396aacbf373726c368062115242ff1ea4cc119d62ab1eed1deb0abcb2a128eea") -- Middle-earth Shadow of Mordor - The Dark Ranger Character Skin - Middle-earth: Shadow of Mordor - The Dark Ranger Character Skin (313371) Depot
addappid(313372, 1, "67191741a00650fb214af4967537ee704bde35dbf0e77a58381cbd8ba7bebbfb") -- Middle-earth Shadow of Mordor - Test of Power - Middle-earth: Shadow of Mordor - Test of Power (313372) Depot
addappid(313373, 1, "18b28cd0c80c234a19313ebeb94576185007c2d591a8fd46256ac28c17badf62") -- Middle-earth Shadow of Mordor - Hidden Blade Rune - Middle-earth: Shadow of Mordor - Hidden Blade Rune (313373) Depot
addappid(313374, 1, "600902dd5d28afaa677adfa911b98c93a84a0d8752e64cdd823e382d76b25c19") -- Middle-earth Shadow of Mordor - Deadly Archer Rune - Middle-earth: Shadow of Mordor - Deadly Archer Rune (313374) Depot
addappid(313375, 1, "b5c547f8cc57ef1d1d5f2afccf3a2ecde0738bc2446dd6c885e4676812007162") -- Middle-earth Shadow of Mordor - Flame of Anor Rune - Middle-earth: Shadow of Mordor - Flame of Anor Rune (313375) Depot
addappid(313376, 1, "7ae25177411ddf63ee8db5f6c130d3d5c5f0143984fdd7f115425ff5b3322c18") -- Middle-earth Shadow of Mordor - Deadly Archer Rune - Linux - Deadly Archer Rune
addappid(313377, 1, "cc6cc4c393f24f1c6ca23ee1928e1510a7d94ee1eac919b8b21bd4c3ded3c398") -- Middle-earth Shadow of Mordor - Skull Crushers Warband - Mac - Skull Crushers Warband
addappid(313378, 1, "511baa3d7a6ba0ffebb76a56f446bf19e9437532c3aa48c80eb1f0827caaf915") -- Middle-earth Shadow of Mordor - Skull Crushers Warband - Linux - Skull Crushers Warband
addappid(313379, 1, "d1d79004cc5cbdd2c03d39d48e74f4d35773beecc8892c8234d6e57db86c5294") -- Middle-earth Shadow of Mordor - Hidden Blade Rune - Mac - Hidden Blade Rune
addappid(313380, 1, "19b93aa0d27186355edc00d7edbb02ab3ceeed3be032e443750bc083943e9f14") -- Middle-earth Shadow of Mordor - Orc Slayer Rune - Middle-earth: Shadow of Mordor - Orc Slayer Rune (313380) Depot
addappid(313381, 1, "74d7ef124f8edc0b7ca06e0253555499607382af0673f67063704cb85ed92322") -- Middle-earth Shadow of Mordor - Rising Storm Rune - Middle-earth: Shadow of Mordor - Rising Storm Rune (313381) Depot
addappid(313382, 1, "c01c9230f445d96de065a4b91b30690caa2f41210bce6d27cdf803f003cbce4f") -- Middle-earth Shadow of Mordor - Hidden Blade Rune - Linux - Hidden Blade Rune
addappid(313383, 1, "b8ac5cb133ccbdf703db2953886742048007a6bb8169593b9bcecf29458e0182") -- Middle-earth Shadow of Mordor - Rising Storm Rune - Mac - Rising Storm Rune
addappid(313384, 1, "84de28113086b1f7b8c07d39ee90cac5fd13a913730d296637e303a22098850c") -- Middle-earth Shadow of Mordor - Rising Storm Rune - Linux - Rising Storm Rune
addappid(313385, 1, "8d448889ed2bd3e02527c8352d9bdb92422e930c2d2ba3dc28014c2e45fccff3") -- Middle-earth Shadow of Mordor - Endless Challenge - Mac - Endless Challenge
addappid(313386, 1, "b9f78acfd93621452fc9797b6db58bc47c69b8c2b9745a36e025d29656654b57") -- Middle-earth Shadow of Mordor - Endless Challenge - Linux - Endless Challenge
addappid(313387, 1, "610d0a7b44ee949097f9b27c5a057f9276600f607766b6d3fa5deb3fd84de9c7") -- Middle-earth Shadow of Mordor - Test of Wisdom - Mac - Test of Wisdom
addappid(313388, 1, "42b5fb61463dbcf3569c25ac35e15024dbdca2533bc1616480484624f8a72040") -- Middle-earth Shadow of Mordor - Test of Wisdom - Linux - Test of Wisdom
addappid(313389, 1, "6e7992a6c641ac13357ec32016401cc24fbfa4a75130ae5a02e0e5f805be2d1a") -- Middle-earth Shadow of Mordor - Power of Shadow - Mac - Power of Shadow
addappid(318390, 1, "f18dd17b47f664b19a525f12ae27c04597a77da9c5e60af27bbfd6e36f61132b") -- Middle-earth Shadow of Mordor - Lord of the Hunt - Middle-earth: Shadow of Mordor - Lord of the Hunt (318390) Depot
addappid(318391, 1, "1eabd1b3848ac7c84dec1c160504edb5b8968dda8ecacd1ffabd5ee25aac6ad4") -- Middle-earth Shadow of Mordor - Power of Shadow - Linux - Power of Shadow
addappid(318392, 1, "abbc7a1ab617325f953a204b48f4fb550e174891583d4716a7cc14231249f4d2") -- Middle-earth Shadow of Mordor - Test of Speed - Mac - Test of Speed
addappid(318393, 1, "08c0bc109ac2ff714b0263b4a6d28665b17efdc0d81381369b995dd707c555e8") -- Middle-earth Shadow of Mordor - Test of Speed - Linux - Test of Speed
addappid(318394, 1, "0f3c5ba64416d5b72037ee55095fc27d046781338e7e4f600817f67bcbd321f9") -- Middle-earth Shadow of Mordor - HD Content - Mac - HD Content
addappid(318395, 1, "3ac1282385d9b5a5c08e2241c709299467bd8e5680825700c0da4717bf1720ab") -- Middle-earth Shadow of Mordor - HD Content - Linux - HD Content
addappid(318396, 1, "e83d5eab59596aa83748f3e4df5641b36fabbb8f2ebe4691bc8131ccf9b8cd9f") -- Middle-earth Shadow of Mordor - Guardians of the Flaming Eye - Mac - Guardians of the Flaming Eye
addappid(318397, 1, "cb5521f4890279cc126b76346f80eddd23249e326e066b00a4b1968c31e5374e") -- Middle-earth Shadow of Mordor - Guardians of the Flaming Eye - Linux - Guardians of the Flaming Eye
addappid(318398, 1, "f3c99b6d57b8981f4b23120cc19795e6e721179c1c2bb2a03085a7b0f54dd967") -- Mac - Forgotten Runes
addappid(318399, 1, "1ebfcf6d1b89d94279f67bb2568004d748a69f7a12c2640f040c8f2a29837969") -- Linux - Forgotten Runes
addappid(318400, 1, "0f11f5a2755926dd0ed5cbfcf541afd9ecf6aa8f387462b2ffd02ea8c15bf042") -- Middle-earth Shadow of Mordor - Test of Speed - Middle-earth: Shadow of Mordor - Test of Speed (318400) Depot
addappid(318401, 1, "e1cfa1ac581fd6418d817b2f52c7dbc4a87600343b44a880e1214ac720b7120d") -- Middle-earth Shadow of Mordor - Test of Wisdom - Middle-earth: Shadow of Mordor - Test of Wisdom (318401) Depot
addappid(318402, 1, "9c5b312c5d18010da3a6e0b8c4cc0fadfa7a0dd5fec7a9c6da356e7c3df147a0") -- Middle-earth Shadow of Mordor - Endless Challenge - Middle-earth: Shadow of Mordor - Endless Challenge (318402) Depot
addappid(318403, 1, "2916da63adf68fd4bbfd4bc864a36a6ef58872813c26f57a2441c334a01909e5") -- Linux - Launch Override
addappid(318410, 1, "976d70058cca25fa12a90dbfb259840f6abd70f585e51e9c44846d471a68af46") -- Middle-earth Shadow of Mordor - Berserks Warband - Middle-earth: Shadow of Mordor - Berserks Warband (318410) Depot
addappid(318411, 1, "66229f379ce074a72fe4ce52493ef1f7340b5e3e8b1f74e9f393dd00454266cd") -- Middle-earth Shadow of Mordor - Blood Hunters Warband - Middle-earth: Shadow of Mordor - Blood Hunters Warband (318411) Depot
addappid(318412, 1, "53eb6d34a7d885fad1128f7e1c45632ac0f912c96af24b3336d054b46227e7ba") -- Middle-earth Shadow of Mordor - Skull Crushers Warband - Middle-earth: Shadow of Mordor - Skull Crushers Warband (318412) Depot
addappid(318413, 1, "697a4af46b8e857bc47b83d088e03a374a5a7ec78554d070e1180df6aca783b0") -- Middle-earth Shadow of Mordor - Guardians of the Flaming Eye - Middle-earth: Shadow of Mordor - Guardians of the Flaming Eye (318413) Depot
addappid(318414, 1, "79a0b1099bdaf94927a1490acd1bfdfc5256fa7de53a97df17af2675c088e2ae") -- Middle-earth Shadow of Mordor - Flesh Burners Warband - Middle-earth: Shadow of Mordor - Flesh Burners Warband (318414) Depot
addappid(318420, 1, "a1fc909f24c5c877f03b3f7894296d05f1e65b2f46962b68bf9068536644d691") -- Middle-earth Shadow of Mordor - Bright Lord - Middle-earth: Shadow of Mordor - Bright Lord (318420) Depot
addappid(322060, 1, "376d39c6e535b3b86e978a7279a5a9c17b71d76397737dbc992212e5e270ad12") -- Middle-earth Shadow of Mordor - Power of Shadow - Middle-earth: Shadow of Mordor - Power of Shadow (322060) Depot
addappid(322061, 1, "f00a1b7fa94eef4ecd6199fed1e147dd745d135bdabfef48ad65bf7003441142") -- Middle-earth: Shadow of Mordor - Forgotten Runes (322061) Depot
addtoken(311670, "5867957274117655006")
addtoken(313370, "1168154938391366305")
addtoken(313371, "16085996130026299492")
addtoken(313372, "399986386970371985")
addtoken(313373, "13490608987146641089")
addtoken(313374, "8213909035351686530")
addtoken(313375, "2432580564690961838")
addtoken(313380, "17000693143313379839")
addtoken(318400, "16066113702663158462")
addtoken(318401, "17868683448414809077")
addtoken(318402, "16375660157213751064")
addtoken(318410, "10771226610455739711")
addtoken(318411, "13036980711745789694")
addtoken(318413, "3288353559581157825")
addtoken(318414, "2887865160447118272")
addtoken(318550, "12041716925911327689")
addtoken(319360, "6521601987940572899")
addtoken(319361, "5948478596417424934")
addtoken(322060, "15372843753691751540")

