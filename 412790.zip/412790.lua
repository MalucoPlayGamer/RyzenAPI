-- Lua provided by RyzenAPI
-- Game: Adventure Time: Magic Man's Head Games

-- MAIN APPLICATION
addappid(412790)

-- MAIN APP DEPOTS / PACKAGES
addappid(412791, 1, "121e4174b762fdf7fa032534b6b5884874748918724776d0c6067d964e3be515")

