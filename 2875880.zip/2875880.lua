-- Lua provided by RyzenAPI
-- Game: addappid(2875880)

-- MAIN APPLICATION
addappid(2875880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2875880,0,"30021199ca535a6bf2d84765eafc8ff5a921cfef504bef8388c4e15c6cc08aa3")
