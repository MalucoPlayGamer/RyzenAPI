-- Lua provided by RyzenAPI
-- Game: Danganronpa V3: Killing Harmony Demo Ver.

-- MAIN APPLICATION
addappid(589120)
-- Game: addappid(589120)

-- MAIN APP DEPOTS / PACKAGES
addappid(589121, 1, "6138ea59a0dbc3c0c1f296f72142883a199d501b439289be8657b79b1fcb6d8d")
addappid(589122, 1, "58573384f8ab74a1a57f0f47111365fa2138aa9faf3b52d7a25996e3c226f05c")
addappid(589123, 1, "811d5b8ef96b859f2d287f656b8382f276bc1f12fb38c18e92dc1f44e32d08c5")
addappid(589125, 1, "2b0639045e3309061402401deeb30f5e53e57ed6fee299f4df4223cd4fb9eb44")
addappid(589126, 1, "da643b89ef716ddb95fe53b9908f35397dc936b721feee0071216f3ae3bbe3c6")
