-- Lua provided by RyzenAPI
-- Game: Hoofobia

-- MAIN APPLICATION
addappid(2467300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467301, 1, "64b35ec4cfc5ea7768f54dbf456613f8b0ccaf4d8482efc2f9f0250eabf2cb9a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
