-- Lua provided by RyzenAPI
-- Game: addappid(1833490)

-- MAIN APPLICATION
addappid(1833490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833491, 1, "8f48ad66d95a04f9019f0002269a0de6c908b3a2f56b897130d9ee7cb342ddd9")
