-- Lua provided by RyzenAPI
-- Game: ShyChess

-- MAIN APPLICATION
addappid(894540)
-- Game: addappid(894540)

-- MAIN APP DEPOTS / PACKAGES
addappid(894541, 1, "8bf98832b448bb0ebdc160f48b2965da3f833450549c6405586383c26875040c")
