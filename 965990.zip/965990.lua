-- Lua provided by RyzenAPI
-- Game: Game: Destiny's Sword

-- MAIN APPLICATION
addappid(965990)
-- Game: addappid(965990)

-- MAIN APP DEPOTS / PACKAGES
addappid(965991, 1, "924a5a9360a527cfeb08f99ee0e9de9e22e87b08f24a2c092ff236a8bf06ace7")
