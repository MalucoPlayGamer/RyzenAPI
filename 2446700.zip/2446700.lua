-- Lua provided by RyzenAPI 
-- Game: Doomies (Damikira)
addappid(2446700)
addappid(2446701, 1, "da49926dfe23e68819691679e619d8562511d12af1cdc9346e1bde0302deb9e8")
