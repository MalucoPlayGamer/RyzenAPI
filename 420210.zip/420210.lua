-- Lua provided by RyzenAPI
-- Game: KRUM - Edge Of Darkness

-- MAIN APPLICATION
addappid(420210)

-- MAIN APP DEPOTS / PACKAGES
addappid(420211, 1, "e07cc932c927dde49047d6af684b38b9381603a1819eb527c4381f6569904304")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
