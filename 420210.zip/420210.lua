-- Lua provided by RyzenAPI
-- Game: Game: KRUM - Edge Of Darkness

-- MAIN APPLICATION
addappid(420210)
-- Game: addappid(420210)

-- MAIN APP DEPOTS / PACKAGES
addappid(420211, 1, "e07cc932c927dde49047d6af684b38b9381603a1819eb527c4381f6569904304")
