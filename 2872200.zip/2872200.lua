-- Lua provided by RyzenAPI
-- Game: Survive Ten Days Demo

-- MAIN APPLICATION
addappid(2872200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2872201, 1, "9c2bf54687278926d04202e561d3df64f509d9dc7fa7d3602241d68c30ff0753")

