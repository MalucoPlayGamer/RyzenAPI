-- Lua provided by RyzenAPI
-- Game: Siren's Well Demo

-- MAIN APPLICATION
addappid(3493440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3493441, 1, "efe322f08c0e5a84e2ea2f17ffd1f107bf9a39cc861fdc7c352ef381bce0ab6a")
