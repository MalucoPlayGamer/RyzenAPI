-- Lua provided by RyzenAPI
-- Game: Lost Child

-- MAIN APPLICATION
addappid(3540530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3540531, 1, "847a6752f7a4a051605c3db60b20ba646c28e935d1f5cf01ef2b5b01c2e64fe9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
