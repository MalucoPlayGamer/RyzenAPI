-- Lua provided by RyzenAPI
-- Game: Lost Child

-- MAIN APPLICATION
addappid(3540530)
-- Game: addappid(3540530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3540531, 1, "847a6752f7a4a051605c3db60b20ba646c28e935d1f5cf01ef2b5b01c2e64fe9")
