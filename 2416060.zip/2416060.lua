-- Lua provided by RyzenAPI
-- Game: The Last Frontier

-- MAIN APPLICATION
addappid(2416060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2416061, 1, "2e1a6e28f8ca8c2b49f16590745f0ff5109e51e2ca81a0adaf5190f6d8e2bd21")
