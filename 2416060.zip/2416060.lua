-- Lua provided by RyzenAPI
-- Game: AppID 2416060

-- MAIN APPLICATION
addappid(2416060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416061, 1, "2e1a6e28f8ca8c2b49f16590745f0ff5109e51e2ca81a0adaf5190f6d8e2bd21")

