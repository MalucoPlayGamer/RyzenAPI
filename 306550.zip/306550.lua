-- Lua provided by RyzenAPI
-- Game: Runers

-- MAIN APPLICATION
addappid(306550)

-- MAIN APP DEPOTS / PACKAGES
addappid(306551, 1, "bdb2e5b22c2aa8eb45e05c0971debc4d7546e40e46273644c67a506138339bba")
addappid(317880, 0, "627b5677d1bbf522ed1c7e66b895dc61ce1d9bb42fd8fd066e6f9e6edc9569ed")

