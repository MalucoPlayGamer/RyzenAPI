-- Lua provided by RyzenAPI
-- Game: Runers

-- MAIN APPLICATION
addappid(306550)

-- MAIN APP DEPOTS / PACKAGES
addappid(306551, 1, "bdb2e5b22c2aa8eb45e05c0971debc4d7546e40e46273644c67a506138339bba")
addappid(317880, 0, "627b5677d1bbf522ed1c7e66b895dc61ce1d9bb42fd8fd066e6f9e6edc9569ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
