-- Lua provided by RyzenAPI
-- Game: 3161730

-- MAIN APPLICATION
addappid(3161730)
-- Game: addappid(3161730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161731, 1, "2c5f28c9c298def089fa56f136b986ba8eeecd91738c413b391c28dc4ba077e4")
