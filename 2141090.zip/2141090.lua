-- Lua provided by RyzenAPI 
-- Game: Fit Puzzle Blocks
addappid(2141090)
addappid(2141091, 1, "ec4616ff68738b94f838afc97fba4c688d44edfb8edefcaddcab1513c9bfcb9c")
addappid(2141092, 1, "da6b75962ff3e162b2c371ac989bf2796ebef4d4b171bea643efd4ad6aa65db2")
addappid(2145140)
