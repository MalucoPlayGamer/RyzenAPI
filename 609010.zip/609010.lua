-- Lua provided by RyzenAPI
-- Game: Mech League Boxing

-- MAIN APPLICATION
addappid(609010)

-- MAIN APP DEPOTS / PACKAGES
addappid(609011,0,"9410fda0c30ccc96c11a9bdfefe12a7346ef112a39d02e0b48d272e14aca2503")

