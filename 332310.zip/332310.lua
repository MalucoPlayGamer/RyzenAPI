-- Lua provided by RyzenAPI
-- Game: LEGO® Worlds

-- MAIN APPLICATION
addappid(332310)
addappid(590410)
addappid(641000)
addappid(720960)
addappid(816880)
addappid(1046500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(332311, 1, "2a2e9283226d9f8629506901f7bc620ff108770740f463eb9a5c16c44dab0ed6")
addappid(551850, 0, "7c4c225d2602c9a2718f39c0dd3c8d0486c59092d822ecf6a5ad8be55c8052f8")
