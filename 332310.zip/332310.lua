-- Lua provided by RyzenAPI
-- Game: Game: AppID 332310

-- MAIN APPLICATION
addappid(332310)
addappid(590410)
-- Game: addappid(332310)

-- MAIN APP DEPOTS / PACKAGES
addappid(332311, 1, "2a2e9283226d9f8629506901f7bc620ff108770740f463eb9a5c16c44dab0ed6")
addappid(551850, 0, "7c4c225d2602c9a2718f39c0dd3c8d0486c59092d822ecf6a5ad8be55c8052f8")
