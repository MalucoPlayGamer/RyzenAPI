-- Lua provided by RyzenAPI
-- Game: Loot Frog

-- MAIN APPLICATION
addappid(4294860) -- Loot Frog
addappid(4751950) -- Loot Frog - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4294861, 1, "9f1bcc022d38b1131459e45aca40a6c924e20e457bb997708f40ae7529113ce7") -- Depot 4294861
addappid(4294862, 1, "f08c635e24e44d1deceaa2bd50c108ff7601d2cabad47e5faa0817b4c3aecd44") -- Depot 4294862

