-- 4294860's Lua and Manifest Created by Hubcap Manifest
-- Loot Frog
-- Created: August 24, 2026 at 14:45:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4294860) -- Loot Frog
-- MAIN APP DEPOTS
addappid(4294861, 1, "9f1bcc022d38b1131459e45aca40a6c924e20e457bb997708f40ae7529113ce7") -- Depot 4294861
setManifestid(4294861, "5631167207854222128", 189941665)
addappid(4294862, 1, "f08c635e24e44d1deceaa2bd50c108ff7601d2cabad47e5faa0817b4c3aecd44") -- Depot 4294862
setManifestid(4294862, "440236370588558903", 210049640)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4751950) -- Loot Frog - Supporter Pack