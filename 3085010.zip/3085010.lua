-- Lua provided by RyzenAPI
-- Game: Emoji Shooter

-- MAIN APPLICATION
addappid(3085010)
-- Game: addappid(3085010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085011, 1, "4dd1db2d667abc92b12d01713d0861c15911e7e31f99ffb7f5fbb5b4304531c9")
