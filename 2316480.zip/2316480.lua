-- Lua provided by RyzenAPI
-- Game: 擒贼先擒王

-- MAIN APPLICATION
addappid(2316480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2316481, 1, "6a1ccf23f308f8597d3f8a0a8645e5219b0f97ec964f6af3b75883bd23018503")

