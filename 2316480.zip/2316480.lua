-- Lua provided by RyzenAPI
-- Game: 2316480

-- MAIN APPLICATION
addappid(2316480)
-- Game: addappid(2316480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316481, 1, "6a1ccf23f308f8597d3f8a0a8645e5219b0f97ec964f6af3b75883bd23018503")
