-- Lua provided by RyzenAPI
-- Game: Annulus

-- MAIN APPLICATION
addappid(2445840)
