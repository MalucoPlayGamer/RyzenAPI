-- Lua provided by RyzenAPI
-- Game: addappid(2009720)

-- MAIN APPLICATION
addappid(2009720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009721, 1, "2e1f860fc2cdb1984408cea267908c9b6c5ba11ffd38272282f04bd7f49f68c7")
