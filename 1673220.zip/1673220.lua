-- Lua provided by RyzenAPI
-- Game: Meteor Genocide

-- MAIN APPLICATION
addappid(1673220)
-- Game: addappid(1673220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673221, 1, "84d45c2bcde69f551c5fdf70d61f508a986e98e1ae199400c16f801c68e02819")
