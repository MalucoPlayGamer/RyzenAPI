-- Lua provided by RyzenAPI
-- Game: Sword Smash

-- MAIN APPLICATION
addappid(2334050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334051, 1, "629a7dcf85a327ab2935e5d477c25e8b3ef03d12ca340bcf0544b34c8f9b04ae")

