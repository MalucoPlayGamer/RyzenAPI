-- Lua provided by SkyAPI 
-- Game: Sword Smash
addappid(2334050)
addappid(2334051, 1, "629a7dcf85a327ab2935e5d477c25e8b3ef03d12ca340bcf0544b34c8f9b04ae")
