-- Lua provided by SkyAPI 
-- Game: Cybersex Chronicles [18+]
addappid(2421820)
addappid(2421821, 1, "4bdbaf93d3b6a42b36dd59c5c630af7a3366f02456188aa4892f791ab7919104")
