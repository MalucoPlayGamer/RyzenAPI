-- Lua provided by RyzenAPI
-- Game: Escape: Underground

-- MAIN APPLICATION
addappid(1547320)
-- Game: addappid(1547320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547321, 1, "46d033b530c646b136bdef41867a1c34c84c62c3bfc0d079ef5c8558c2f580f3")
