-- Lua provided by RyzenAPI
-- Game: 2624930

-- MAIN APPLICATION
addappid(2624930)
-- Game: addappid(2624930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624931, 1, "2d72c0576dde5f9d457ecff7b4d47cfe61f9be83650d6281f83118309ce2775a")
