-- Lua provided by RyzenAPI
-- Game: 1960800

-- MAIN APPLICATION
addappid(1960800)
addappid(2060960)
addappid(2060961)
-- Game: addappid(1960800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960801, 1, "508ff6fc253cd91283789602d9ae59f0931481822d53f753e242517cb44f1fc9")
