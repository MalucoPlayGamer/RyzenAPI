-- Lua provided by RyzenAPI
-- Game: addappid(3263280)

-- MAIN APPLICATION
addappid(3263280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263281, 1, "0bbcab5cccfccc9a96d8d52c48a09e85fcee9e7e94b2d67462ac41960d2714eb")
