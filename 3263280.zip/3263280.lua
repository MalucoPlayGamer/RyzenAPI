-- Lua provided by RyzenAPI
-- Game: The Spire of Mech Zero

-- MAIN APPLICATION
addappid(3263280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3263281, 1, "0bbcab5cccfccc9a96d8d52c48a09e85fcee9e7e94b2d67462ac41960d2714eb")

