-- Lua provided by RyzenAPI
-- Game: 1721460

-- MAIN APPLICATION
addappid(1721460)
-- Game: addappid(1721460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721461, 1, "d19cc2bb0373db3cea74f0a39d9cfbfcda7e3ace9b191325a4141befe9b61f2e")
