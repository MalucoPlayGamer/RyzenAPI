-- Lua provided by RyzenAPI
-- Game: Little Green Girl BGM Collection

-- MAIN APPLICATION
addappid(3487290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487291, 1, "7f6877439552244b303c7dc81b124d0b6d1adc1feb14068e83f9b2979a9eb07c")

