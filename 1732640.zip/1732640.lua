-- Lua provided by RyzenAPI
-- Game: addappid(1732640)

-- MAIN APPLICATION
addappid(1732640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732640,0,"e811cf610fde821f67609f9e79cc9ad53afed75d5ffaffa01ef4dcb6f2848413")
