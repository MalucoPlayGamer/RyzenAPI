-- Lua provided by RyzenAPI
-- Game: Godspell Defender

-- MAIN APPLICATION
addappid(1580460)
-- Game: addappid(1580460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580461, 1, "618215ba5089a41f08d3884fd9968d1b7d26e1821f726ba3014b56f2b493edc9")
