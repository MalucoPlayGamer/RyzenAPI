-- Lua provided by RyzenAPI
-- Game: Fool!

-- MAIN APPLICATION
addappid(1080250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080251, 1, "11c095d69edaac25efc7ff34b10ad50e59545317a2eeacb6b39408fac7937a9d")

