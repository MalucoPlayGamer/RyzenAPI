-- Lua provided by RyzenAPI
-- Game: Game: Toy Tactics

-- MAIN APPLICATION
addappid(1772530)
-- Game: addappid(1772530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772531, 1, "a7db0e7fed65da3a4016e5186eecf985c1f053350f39f97b44bcd0cb00c13591")
