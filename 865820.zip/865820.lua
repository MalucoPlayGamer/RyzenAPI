-- Lua provided by RyzenAPI
-- Game: AppID 865820

-- MAIN APPLICATION
addappid(865820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(865821, 1, "50a055811f53ec83fce79c1955756d9738ece74cb38d1d3bfe16520edd4a6899")
addappid(865823, 1, "b22512f03d95beb738dff8170171c1bf6b1737e58839dce07b6d186cb3294c27")
addappid(967150, 0, "bd21a3772529cae7bfe18979bd0f4e69cf4e5df9766578c42089a3b01630cbac")

