-- Lua provided by RyzenAPI
-- Game: Game: Super Robolom

-- MAIN APPLICATION
addappid(783330)
-- Game: addappid(783330)

-- MAIN APP DEPOTS / PACKAGES
addappid(783331, 1, "2e59903964575bca26c6be662c87477f01f7e6538a5343e6d13893cb5d34c2f0")
