-- Lua provided by SkyAPI 
-- Game: Super Robolom
addappid(783330)
addappid(783331, 1, "2e59903964575bca26c6be662c87477f01f7e6538a5343e6d13893cb5d34c2f0")
