-- Lua provided by RyzenAPI
-- Game: Fear The Wolves

-- MAIN APPLICATION
addappid(819500)
addappid(889371)
addappid(889372)
addappid(889373)
addappid(889374)
addappid(889375)
addappid(889376)
addappid(889377)
addappid(889378)
addappid(889379)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(819501, 1, "4564782d13bceb3e2bc88e5ec1e23ccc9850e6e68ab12ec04996fde8aa7d610d")
addappid(819502, 1, "688691fd8f330218f03ddf510669f9049b65c36f1f1ea763e775c993479f6cc5")

