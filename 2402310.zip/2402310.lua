-- Lua provided by RyzenAPI
-- Game: addappid(2402310)

-- MAIN APPLICATION
addappid(2402310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402311, 1, "92a636b1f191263b0afe0ed863758d6fae2eb27b8357ba791ac5280f3e445a90")
