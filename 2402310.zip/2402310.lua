-- Lua provided by RyzenAPI
-- Game: Crazy Flasher 7 Mercenary Empire(stand-alone Version)

-- MAIN APPLICATION
addappid(2402310)
addappid(2402350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402311, 1, "92a636b1f191263b0afe0ed863758d6fae2eb27b8357ba791ac5280f3e445a90")
