-- Lua provided by RyzenAPI
-- Game: addappid(1976740)

-- MAIN APPLICATION
addappid(1976740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976741, 1, "3226589c6bbd36ec55af7d605c15188aa7e7b596b2ccaa98202e3ba78fecca79")
