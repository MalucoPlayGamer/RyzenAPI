-- Lua provided by RyzenAPI 
-- Game: 木偶公馆
addappid(1976740)
addappid(1976741, 1, "3226589c6bbd36ec55af7d605c15188aa7e7b596b2ccaa98202e3ba78fecca79")
