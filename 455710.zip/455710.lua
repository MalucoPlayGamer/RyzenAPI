-- Lua provided by RyzenAPI
-- Game: AppID 455710

-- MAIN APPLICATION
addappid(455710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(455711, 1, "b1532cac88f201528e3ad1e831874a89ef3a2b1c45755ad2198aa480ae39fde1")

