-- Lua provided by RyzenAPI 
-- Game: AppID 455710
addappid(455710)
addappid(455711, 1, "b1532cac88f201528e3ad1e831874a89ef3a2b1c45755ad2198aa480ae39fde1")
