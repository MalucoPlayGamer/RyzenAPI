-- Lua provided by RyzenAPI
-- Game: Cladmen

-- MAIN APPLICATION
addappid(1624140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624141, 1, "b4f47e7461e5db30db6dfac43e9dcb9c7800d0145b0d398704176b081d0c55c2")

