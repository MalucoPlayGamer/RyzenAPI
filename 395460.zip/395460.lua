-- Lua provided by RyzenAPI
-- Game: 395460

-- MAIN APPLICATION
addappid(395460)

-- MAIN APP DEPOTS / PACKAGES
addappid(395460,0,"3c4f73a5c891f9ba6aaac0ba7022745af1ae7ace69bacb8f02596a63a3427bf3")

