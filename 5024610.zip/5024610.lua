-- 5024610's Lua and Manifest Created by Hubcap Manifest
-- ONE MORE FISHING
-- Created: August 22, 2026 at 00:25:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5024610) -- ONE MORE FISHING
-- MAIN APP DEPOTS
addappid(5024611, 1, "8db2f2f708a1a0a8c58d7ecb0c4b61bb01605c70c55621a90347dc7d1b01a930") -- Depot 5024611
setManifestid(5024611, "8612745425824727551", 5334484912)
addappid(5024612, 1, "1fcfc1abaaead99d983c8c9c129dd14b665e6d9c824822b737f1878ca81054bc") -- Depot 5024612
setManifestid(5024612, "7111501066461636146", 5299433440)