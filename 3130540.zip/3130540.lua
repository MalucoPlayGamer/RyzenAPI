-- Lua provided by RyzenAPI
-- Game: 3130540

-- MAIN APPLICATION
addappid(3130540)
-- Game: addappid(3130540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130541, 1, "cf78eaf87f0a69d18b0c14d5f56f6d0186e38fe0b7d192d9a14b41e943219343")
