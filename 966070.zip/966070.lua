-- Lua provided by RyzenAPI
-- Game: Relow

-- MAIN APPLICATION
addappid(966070)
-- Game: addappid(966070)

-- MAIN APP DEPOTS / PACKAGES
addappid(966071, 1, "c40b96ae8ddb4434fd0fc849731143f777b083f5b423138830d967365cb7b415")
