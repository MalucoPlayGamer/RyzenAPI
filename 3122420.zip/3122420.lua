-- Lua provided by RyzenAPI
-- Game: Five Nights And VTBs Demo

-- MAIN APPLICATION
addappid(3122420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122421, 1, "c4715566e1aede13dac870d54771ea60d42a4181fbdc9aada3826fdea2542cc4")
