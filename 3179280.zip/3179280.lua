-- Lua provided by RyzenAPI
-- Game: Friendly Sheeps: A Cozy Simulator

-- MAIN APPLICATION
addappid(3179280)
-- Game: addappid(3179280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179281, 1, "9a68b88fa2a0c36f6f68c8cf4ad799bd867a4a64161b8dbf2d18551d1d964c31")
