-- Lua provided by RyzenAPI
-- Game: 1909840

-- MAIN APPLICATION
addappid(1909840)
-- Game: addappid(1909840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909841, 1, "e5d50367b0e533f638f41c3d0c53ba62d3e6f5832ba684c2a0720932e5b2a63e")
