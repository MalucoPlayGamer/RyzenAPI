-- Lua provided by RyzenAPI
-- Game: Game: The Phantom Keeper Demo

-- MAIN APPLICATION
addappid(1802180)
-- Game: addappid(1802180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802181, 1, "f0faf23cf452293bf855d5e68e93cbfd15496d877a655f1a0d4892b1fb86125c")
