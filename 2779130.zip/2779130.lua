-- Lua provided by RyzenAPI
-- Game: 2779130

-- MAIN APPLICATION
addappid(2779130)
-- Game: addappid(2779130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779131, 1, "65d92c919581a73012f1ea1a13dff249268f150b59172d191e3f35c2a4faed85")
