-- Lua provided by RyzenAPI
-- Game: Nautical Life

-- MAIN APPLICATION
addappid(817200)

-- MAIN APP DEPOTS / PACKAGES
addappid(817201, 1, "f70842a4b111efc017ac61d0668ffb44e79b56ac773d4dcb1da444fbfc416b33")

