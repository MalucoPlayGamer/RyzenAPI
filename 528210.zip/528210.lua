-- Lua provided by RyzenAPI
-- Game: addappid(528210)

-- MAIN APPLICATION
addappid(528210)

-- MAIN APP DEPOTS / PACKAGES
addappid(528211, 1, "2c14900501dc48537e09a0dbdce594bc813a3d9241635bdfa4c47b81a1995132")
