-- Lua provided by RyzenAPI
-- Game: Bejeweled Twist

-- MAIN APPLICATION
addappid(3560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561, 1, "9585d450f8a63b285dd63e337609b5a0799b126750cbc2d15aee27e5e48a4da6")

