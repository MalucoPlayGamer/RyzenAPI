-- 3505230's Lua and Manifest Created by Hubcap Manifest
-- Soulblaze
-- Created: August 12, 2026 at 00:03:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3505230, 1, "706cf2bbfcface5d98f80324060142c69d7ca09b63410d040dfaab1e6cf5ceb6") -- Soulblaze
-- MAIN APP DEPOTS
addappid(3505231, 1, "822fc0ddcd8899cac0554f45a2f169b52d3126e024794f008289bc8a744e3064") -- Depot 3505231
setManifestid(3505231, "7766283595374319742", 231108192)
addappid(3505232, 1, "6683954ba24e75dbf716fc014e86f95e3fb1962d0ba2e1f939a151edcf95b912") -- Depot 3505232
setManifestid(3505232, "4607868429675814218", 206819311)
addappid(3505233, 1, "68f164d39e5618ce6b331138c2f2c612e6e4f0da4ca764609c5181bab8fb0d24") -- Depot 3505233
setManifestid(3505233, "7437916593936676805", 298991934)
-- DLCS WITH DEDICATED DEPOTS
-- Soulblaze  Supporter Pack (AppID: 4771760)
addappid(4771760)
addappid(4771760, 1, "536b4a44a43adfddd6d4f588b1242dfc2c9218019831449f2f5680a812dce81f") -- Soulblaze  Supporter Pack - Depot 4771760
setManifestid(4771760, "8365237277557880286", 498008)