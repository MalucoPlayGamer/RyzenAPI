-- Lua provided by RyzenAPI
-- Game: Soulblaze

-- MAIN APPLICATION
addappid(4771760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3505230, 1, "706cf2bbfcface5d98f80324060142c69d7ca09b63410d040dfaab1e6cf5ceb6") -- Soulblaze
addappid(3505231, 1, "822fc0ddcd8899cac0554f45a2f169b52d3126e024794f008289bc8a744e3064") -- Depot 3505231
addappid(3505232, 1, "6683954ba24e75dbf716fc014e86f95e3fb1962d0ba2e1f939a151edcf95b912") -- Depot 3505232
addappid(3505233, 1, "68f164d39e5618ce6b331138c2f2c612e6e4f0da4ca764609c5181bab8fb0d24") -- Depot 3505233
addappid(4771760, 1, "536b4a44a43adfddd6d4f588b1242dfc2c9218019831449f2f5680a812dce81f") -- Soulblaze  Supporter Pack - Depot 4771760

