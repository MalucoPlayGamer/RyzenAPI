-- Lua provided by RyzenAPI
-- Game: Drone Sector

-- MAIN APPLICATION
addappid(3279440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279441,0,"66f000122b2ceffdc4bdaef8fcf24f22fbad160ed86e5830c480d7a3f0d54920")

