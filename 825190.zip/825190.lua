-- Lua provided by RyzenAPI
-- Game: MisBits

-- MAIN APPLICATION
addappid(825190)
-- Game: addappid(825190)

-- MAIN APP DEPOTS / PACKAGES
addappid(825192,0,"3ae5e245769c3a3cce61f95e08640e04ae588967dca4cc5024b4ec4625531123")
