-- Lua provided by RyzenAPI 
-- Game: To The Core
addappid(1988550)
addappid(1988551, 1, "5c60dd9dc9407618030a604d061e82fd2e92d999c0fd66edd1750c18e5c21452")
