-- Lua provided by RyzenAPI
-- Game: Game: Fable Hospital

-- MAIN APPLICATION
addappid(2726060)
-- Game: addappid(2726060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726061, 1, "5a144eca3affc9116b1e27db386aa0d17a8d441e825950084b8862a33cc122f8")
