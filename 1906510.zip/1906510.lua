-- Lua provided by RyzenAPI 
-- Game: Arto
addappid(1906510)
addappid(1906511, 1, "4573824071cd0e790038712977c67f62b5a2479c1d1a9efe061f4d548364a11b")
