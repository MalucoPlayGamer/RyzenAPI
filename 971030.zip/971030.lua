-- Lua provided by RyzenAPI
-- Game: addappid(971030)

-- MAIN APPLICATION
addappid(971030)

-- MAIN APP DEPOTS / PACKAGES
addappid(971031, 1, "9a10ab82e7a3e80b43a1cbfbcbdb3e1d4d91840de83dbfa87cdecc98d511f5d2")
