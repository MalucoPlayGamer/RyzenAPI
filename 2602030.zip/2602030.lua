-- Lua provided by RyzenAPI
-- Game: Game: Entropy Survivors

-- MAIN APPLICATION
addappid(2602030)
-- Game: addappid(2602030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602031, 1, "04c21a6801b86c72abdb8b5b9f276cbddee6ecc7e900f98e55b2d1bdd1fc6b2c")
