-- Lua provided by RyzenAPI
-- Game: Entropy Survivors

-- MAIN APPLICATION
addappid(2602030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2602031, 1, "04c21a6801b86c72abdb8b5b9f276cbddee6ecc7e900f98e55b2d1bdd1fc6b2c")

