-- Lua provided by SkyAPI 
-- Game: La-Mulana 2
addappid(835430)
addappid(835431, 1, "125afe137ac010a2771e77e32474a163e6199440eb1dc07c5da6abb5ef798490")
addappid(835432, 1, "d6863d07390d03db7737df30ff46dbc6cea73f2e843559d80ee1d712cbbaffa0")
addappid(1279290)
addappid(1279291)
addappid(1281910)
addappid(1591620, 0, "b2baaefb9a2fd6e154445f4424c0109c6c3404869de3ce46c71844fbfb30fe35")
addappid(1591621, 0, "69c31aaf6adf1a7acde1d34f274206ddc533888e8ff3af203309162f6d8e313c")
