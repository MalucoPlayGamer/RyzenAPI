-- 4664900's Lua and Manifest Created by Hubcap Manifest
-- Sunder Siege
-- Created: August 12, 2026 at 22:55:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4664900) -- Sunder Siege
-- MAIN APP DEPOTS
addappid(4664901, 1, "2839ee597caedae73e7b028c6871768ec0585c8c6f98e7150bfc6ec95594152d") -- Depot 4664901
setManifestid(4664901, "7241828300068942956", 49)
addappid(4664902, 1, "c5b09a6dd94920d1c4bdc4ee9b2f7af6c6b667da4c5a851a5432113a95131faa") -- Depot 4664902
setManifestid(4664902, "7838329539489278852", 153000804)
addappid(4664903, 1, "03aa8bb03b29c20a0aac23b02fc8cdae60d7e360d2d37b53a90b6ac8070da0ae") -- Depot 4664903
setManifestid(4664903, "7841769223438309748", 117711748)