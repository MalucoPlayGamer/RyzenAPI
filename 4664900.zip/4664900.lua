-- Lua provided by RyzenAPI
-- Game: Sunder Siege

-- MAIN APPLICATION
addappid(4664900) -- Sunder Siege

-- MAIN APP DEPOTS / PACKAGES
addappid(4664901, 1, "2839ee597caedae73e7b028c6871768ec0585c8c6f98e7150bfc6ec95594152d") -- Depot 4664901
addappid(4664902, 1, "c5b09a6dd94920d1c4bdc4ee9b2f7af6c6b667da4c5a851a5432113a95131faa") -- Depot 4664902
addappid(4664903, 1, "03aa8bb03b29c20a0aac23b02fc8cdae60d7e360d2d37b53a90b6ac8070da0ae") -- Depot 4664903

