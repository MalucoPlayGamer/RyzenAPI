-- Lua provided by RyzenAPI
-- Game: Jungle Juggle

-- MAIN APPLICATION
addappid(844580)

-- MAIN APP DEPOTS / PACKAGES
addappid(844581, 1, "8267bc7a5727c78ddb950290ecd0692c8fff588e19403646abaf694d52f14645")
