-- Lua provided by RyzenAPI
-- Game: BACK and BACK to Hell

-- MAIN APPLICATION
addappid(1841900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841901, 1, "789eff5ecca968bad048d0161dcd30c391cc32287f2393403e0d59e874b10f52")
