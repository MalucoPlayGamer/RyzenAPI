-- Lua provided by RyzenAPI
-- Game: F1 RACE STARS™

-- MAIN APPLICATION
addappid(203680)
addappid(211320)
addappid(211321)
addappid(211322)
addappid(220800)
addappid(220801)
addappid(220802)
addappid(220803)
addappid(220804)
addappid(220805)
addappid(220806)
addappid(220807)
addappid(220808)
addappid(220809)
addappid(220810)
addappid(220811)
addappid(220812)
addappid(220813)

-- MAIN APP DEPOTS / PACKAGES
addappid(203681, 1, "821f6e044d69bca1db7ecbc8fd73ea0bad0671a5a2a9ee81cc25a4c7fd514eff")
addappid(203682, 1, "6a97bf549e5193c01c63dbdd1e8abf36055134081c5e8f42f91adf32add700fd")
addappid(203684, 1, "76e7f1e3df270b7cf5e61ece9f1a2d2dfafa1391ade1c53a49ae7f12d2383953")
addappid(203685, 1, "8a6df4d6b95ebfc2e9db82dd15855fd86f3b9012d9a7f0d7ec0a7e71a9fe574a")
addappid(203686, 1, "f16ea91d0b98a06e38cc3684c76e627d37434b0527ca9fc355f9dc89628e6be8")
addappid(203687, 1, "7ad9ef50632877c379710b960eb3b16e78a5118153301324040b29a3eecad633")
addappid(203688, 1, "6eac1691f2e494ba683a74edd3c0c54be017242bee2c89de775a93309c06d367")
addappid(203689, 1, "57cdcb9dd4852b995e6bd250025f7457d447ff87910f32b58d4221e50d0764c0")
addappid(203690, 1, "7568bcd2f1f407d3846e6b136dd614e68ede99652a4a7c365b67e6c017102896")
addappid(203692, 1, "852b0ab0a41e0280e58df2afddbf614bd7a5f0cfb874d0a6872b1c1213554635")
