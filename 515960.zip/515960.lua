-- Lua provided by RyzenAPI
-- Game: 515960

-- MAIN APPLICATION
addappid(515960)
-- Game: addappid(515960)

-- MAIN APP DEPOTS / PACKAGES
addappid(515961, 1, "8f85a133ee59d68a74738f0d88d6dcc8b2f6612ca8e4e028fb6b7e7a732df699")
