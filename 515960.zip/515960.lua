-- Lua provided by RyzenAPI
-- Game: Martha Is Dead

-- MAIN APPLICATION
addappid(515960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(515961, 1, "8f85a133ee59d68a74738f0d88d6dcc8b2f6612ca8e4e028fb6b7e7a732df699")
