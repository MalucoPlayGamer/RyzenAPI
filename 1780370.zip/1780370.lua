-- Lua provided by RyzenAPI
-- Game: Mr. Rainer's Solve-It Service

-- MAIN APPLICATION
addappid(1780370)
-- Game: addappid(1780370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780371, 1, "edef1013f737f4a35a1d08aa8cba88c04a5946a3bafc048e8177ddeb9ce3e4d9")
addappid(1780375, 1, "10cf6f641b0b92b16fc9ee5f2469aca09dd76fc43243890544f0a09b1b29c269")
