-- Lua provided by RyzenAPI
-- Game: Ken ga Kimi: Momoyo Tsuzuri

-- MAIN APPLICATION
addappid(1387350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387351, 1, "8d200807c298022e9fcd03f9799a9cdf6a8d8fc00e10b890bef5955afa181c9c")
