-- Lua provided by RyzenAPI
-- Game: AppID 443600

-- MAIN APPLICATION
addappid(443600)
-- Game: addappid(443600)

-- MAIN APP DEPOTS / PACKAGES
addappid(443601, 1, "cf8b13d25d7310e9bfcdbcc506762206c8a6423aa17e7bf9dc3171130bfcc9d9")
