-- Lua provided by RyzenAPI
-- Game: Shoot Your Friends

-- MAIN APPLICATION
addappid(1484970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484971, 1, "21a5e863c7ee004995ed0da060293bc6931d53b606c4b15fa0ffc570c9ce052a")

