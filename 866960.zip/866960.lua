-- Lua provided by RyzenAPI
-- Game: Slime Kingdom

-- MAIN APPLICATION
addappid(866960)

-- MAIN APP DEPOTS / PACKAGES
addappid(866961, 1, "bb20e19a6d7f01b339e728859b89d6f37d3f5fdd9e0f5affdca9c7bdb5976ae4")
