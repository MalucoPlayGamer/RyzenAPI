-- Lua provided by RyzenAPI
-- Game: Game: BOBR SPRINT

-- MAIN APPLICATION
addappid(2467000)
-- Game: addappid(2467000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467001, 1, "8e145e404b62120c0fa6771ea81e3fb965d4952eae8166fd025e05c1f8ac090e")
