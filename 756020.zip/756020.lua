-- Lua provided by RyzenAPI
-- Game: Puppet Kings

-- MAIN APPLICATION
addappid(756020)

-- MAIN APP DEPOTS / PACKAGES
addappid(756021,0,"48e0563c7d644e24f67e3237d4d8b3adc7f79d2c7d9bdc992563e3fc26e0a402")

