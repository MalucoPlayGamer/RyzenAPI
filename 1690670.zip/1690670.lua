-- Lua provided by RyzenAPI
-- Game: Car Physics Simulator - Med-Size Car #1

-- MAIN APPLICATION
addappid(1690670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690670,0,"312582d6f29aed3f238560714a5b46522927c4fb0390bf934ce4acbfb03b9166")

