-- Lua provided by RyzenAPI
-- Game: addappid(2398430)

-- MAIN APPLICATION
addappid(2398430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398431, 1, "d06152d176454e809b81ec41119f58025f0c7dc5354cb04635d9ba5ec5a8b6a3")
