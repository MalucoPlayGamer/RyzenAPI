-- Lua provided by RyzenAPI 
-- Game: Perfect  Dice
addappid(2398430)
addappid(2398431, 1, "d06152d176454e809b81ec41119f58025f0c7dc5354cb04635d9ba5ec5a8b6a3")
