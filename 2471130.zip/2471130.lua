-- Lua provided by RyzenAPI
-- Game: Obsidian

-- MAIN APPLICATION
addappid(2471130)
-- Game: addappid(2471130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471131, 1, "613c0a6532d98b2c861062bfb6eaf8eac8b916d70a0b1765882b5513504bbf50")
addappid(2471133, 1, "67e08f70930115bfa0b0c3e554db799c1c9db0baf13af73f1122d0fe30a3b010")
addappid(2471136, 1, "8280ef423d1bd8de2c3a6e63d1f72b8b8913d421f48cb7702333b46478ab64c6")
