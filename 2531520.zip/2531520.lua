-- Lua provided by RyzenAPI
-- Game: Dreamcore Demo

-- MAIN APPLICATION
addappid(2531520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531521, 1, "8977efdedefb671b09939b8fe0faa51c065ebe038740bbff543495dfb66c5430")

