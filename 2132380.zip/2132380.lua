-- Lua provided by RyzenAPI
-- Game: Book of Korvald

-- MAIN APPLICATION
addappid(2132380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2132381, 1, "8782de171969f1be81976a6c3562295da523b11c1d60f4ddf42e5d91e2ab6fe1")
