-- Lua provided by RyzenAPI
-- Game: Game: Vida

-- MAIN APPLICATION
addappid(3408820)
-- Game: addappid(3408820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408821, 1, "b9ed1fe9b6d892cc7da1c7c3aeb7007fd78f355ae34ecd8d622b52c254cec857")
