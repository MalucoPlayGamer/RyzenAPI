-- Lua provided by RyzenAPI
-- Game: addappid(674750)

-- MAIN APPLICATION
addappid(674750)

-- MAIN APP DEPOTS / PACKAGES
addappid(674751, 1, "9d8be20f924b4717062e08d5c9d06cac99d7628d2c18d3b72b84e44683bd0593")
