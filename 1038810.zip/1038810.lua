-- Lua provided by SkyAPI 
-- Game: GOD WARS The Complete Legend
addappid(1038810)
addappid(1038811, 1, "740e12041bf4faf548aed5a2bc7edcd75f6d9bad1bc974af85819444b05331b2")
addappid(1038812, 1, "6917ff701117b195fdf051ce26f338a390a017e07fb9fc7b3d40ba2699e9a1bc")
addappid(1038813, 1, "742246d8d6abcaedd87afe0cfbf521ede3f1ee195fce28ae71f356567c53e9bb")
