-- Lua provided by RyzenAPI
-- Game: GOD WARS The Complete Legend

-- MAIN APPLICATION
addappid(1038810)
addappid(1066050)
addappid(1066060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038811,0,"740e12041bf4faf548aed5a2bc7edcd75f6d9bad1bc974af85819444b05331b2")
addappid(1038812,0,"6917ff701117b195fdf051ce26f338a390a017e07fb9fc7b3d40ba2699e9a1bc")
addappid(1038813,0,"742246d8d6abcaedd87afe0cfbf521ede3f1ee195fce28ae71f356567c53e9bb")
addappid(1071111,0,"34f4e1307be405bf1be2b0203e2705e0103ec2920123447a875b432063fbeac1")

