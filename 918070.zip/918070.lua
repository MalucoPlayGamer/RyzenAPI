-- Lua provided by RyzenAPI
-- Game: JQ: Beautiful Japan

-- MAIN APPLICATION
addappid(918070)

-- MAIN APP DEPOTS / PACKAGES
addappid(918071, 1, "4ecf58d2ed08dfe5a9a0586dfaf8c66f08bf6f077e162af40990e4e4ada75404")
