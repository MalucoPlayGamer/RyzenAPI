-- Lua provided by RyzenAPI
-- Game: AppID 370070

-- MAIN APPLICATION
addappid(370070)

-- MAIN APP DEPOTS / PACKAGES
addappid(370071, 1, "7733aa7dcb2fb0761c983eba90fa4b65c7e12971ad8dfb04547c5a206392cf84")
addappid(370072, 1, "86996e11a7f8835909caed4fcd4d2ad46984bb41a666a7301cb87b398af9ffae")

