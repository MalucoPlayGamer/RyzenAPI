-- Lua provided by RyzenAPI
-- Game: 1752860

-- MAIN APPLICATION
addappid(1752860)
-- Game: addappid(1752860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752861, 1, "2f4c21796577f824f06aa32c47c19e5c51fa48fd0c7690e1c5885d794ceb1ba0")
addappid(1752862, 1, "a8d902046edc00d31def6c915d00c7b2c0f43d59f68eb8a3b183cc4ab5bb3c5d")
