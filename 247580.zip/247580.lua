-- Lua provided by RyzenAPI
-- Game: Magicka: Wizards of the Square Tablet

-- MAIN APPLICATION
addappid(247580)

-- MAIN APP DEPOTS / PACKAGES
addappid(247581, 1, "d0f7afd40f21ce960b8379b2f70a45ac7198622106551a874e620e641aa98109")

