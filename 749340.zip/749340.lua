-- Lua provided by RyzenAPI
-- Game: Chocolate makes you happy

-- MAIN APPLICATION
addappid(749340)

-- MAIN APP DEPOTS / PACKAGES
addappid(749341, 1, "290602be1522693967bf12da5facb9256dee8e1626a85465b3081779688f597b")
