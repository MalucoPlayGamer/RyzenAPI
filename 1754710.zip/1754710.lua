-- Lua provided by RyzenAPI
-- Game: 我的侠客 试玩版

-- MAIN APPLICATION
addappid(1754710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754711, 1, "6c2dd13118ea31ce701fdafff9b9510b667a4636f96bc4ee2a41d6deda27af52")

