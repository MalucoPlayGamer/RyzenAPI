-- Lua provided by RyzenAPI
-- Game: 801320

-- MAIN APPLICATION
addappid(801320)
-- Game: addappid(801320)

-- MAIN APP DEPOTS / PACKAGES
addappid(801321, 1, "b60869ac3a5bf8f4c52d84e1fd1889118d9110800a745ef14e82d1b5659db00c")
