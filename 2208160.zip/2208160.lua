-- Lua provided by RyzenAPI 
-- Game: Cursed
addappid(2208160)
addappid(2208161, 1, "a2a3ce22ce1dd9bc4a67be5308b37f222c9434a7390281cf42c3bf1c034c8451")
