-- Lua provided by RyzenAPI
-- Game: Freak Hunter A Retro Type

-- MAIN APPLICATION
addappid(2397230)
addappid(2621100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397231, 1, "db6ae4a477fdb28a7964edfd57c398244e02aff552f6faa86cbd0c4f486c8b05")
