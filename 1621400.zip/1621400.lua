-- Lua provided by RyzenAPI
-- Game: Game: Cry of Athena Playtest

-- MAIN APPLICATION
addappid(1621400)
-- Game: addappid(1621400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621401, 1, "b013d38467dbe511f7c2171794728e698a48d927d965f9a6ed94438392c67311")
