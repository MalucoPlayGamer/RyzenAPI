-- Lua provided by RyzenAPI 
-- Game: The Persistence
addappid(1140100)
addappid(1140101, 1, "cb989c88983c10ee7c3998b37448396f903f09e8ef13dac57fa74be862e96caf")
addappid(1640440, 0, "6d8a6c8da9d6864ae284c6171002996e1d756e6c350b846bfd26e6fe1a8b5d2f")
