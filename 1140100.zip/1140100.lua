-- Lua provided by RyzenAPI
-- Game: The Persistence

-- MAIN APPLICATION
addappid(1140100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140101, 1, "cb989c88983c10ee7c3998b37448396f903f09e8ef13dac57fa74be862e96caf")
addappid(1640440, 0, "6d8a6c8da9d6864ae284c6171002996e1d756e6c350b846bfd26e6fe1a8b5d2f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
