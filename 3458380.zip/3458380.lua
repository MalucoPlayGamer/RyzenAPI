-- Lua provided by RyzenAPI
-- Game: The Week With Grugles

-- MAIN APPLICATION
addappid(3458380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3458381,0,"edfbf304cd23ca4e31ba9b245da8aac5c547e4c3fdd8b3ca2ee6dc9bec9ffee5")

