-- Lua provided by RyzenAPI
-- Game: 364190

-- MAIN APPLICATION
addappid(364190)
-- Game: addappid(364190)

-- MAIN APP DEPOTS / PACKAGES
addappid(364191, 1, "089042e613d136418e8c265fc2fc69290779ae6a0f8d5167feae62808cba76fa")
addappid(364193, 1, "61074927ef83abc8f8fefeaaea5722b51de6c893f1c90b8efc1672913612522d")
