-- Lua provided by RyzenAPI
-- Game: AppID 234490

-- MAIN APPLICATION
addappid(234490)

-- MAIN APP DEPOTS / PACKAGES
addappid(234491, 1, "67ef30da8c21f5a92e069619b56a2f5c623a3a05abb809464e9f7d036ab02176")
addappid(234492, 1, "bef796ac564668a5104b70ef369aba721561c2fcc55f1d063315b87724db5131")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
