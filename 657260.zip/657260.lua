-- Lua provided by RyzenAPI
-- Game: 救う(SHE SAVE)

-- MAIN APPLICATION
addappid(657260)

-- MAIN APP DEPOTS / PACKAGES
addappid(657261,0,"a541d52ec4fcfc20af8f9e9dcb8c11d3cca67cf00494948d10920509070ad41c")

