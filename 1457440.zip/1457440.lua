-- Lua provided by RyzenAPI
-- Game: 恋爱绮谭 不存在的夏天 Soundtrack

-- MAIN APPLICATION
addappid(1457440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457441, 1, "b7ef75587cdd827ac7e0b1875f3c2f5190f6327df5ec4564ff478b5d65814ef6")
addappid(1457442, 1, "2e309df333857d3251d8484ba16357ce12a5225362a9e14c75d2166ea3c47635")

