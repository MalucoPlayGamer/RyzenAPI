-- Lua provided by RyzenAPI
-- Game: Space Scavenger 2 Demo

-- MAIN APPLICATION
addappid(3029210)
-- Game: addappid(3029210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029211, 1, "55c0634d0580a3eff84f00b6edfcaeba35763531bd994bbd78d640c89af48408")
