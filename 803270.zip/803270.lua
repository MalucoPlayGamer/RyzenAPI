-- Lua provided by RyzenAPI
-- Game: One Bit Arena

-- MAIN APPLICATION
addappid(803270)

-- MAIN APP DEPOTS / PACKAGES
addappid(803271,0,"f2c7d23097ac73a1baee6b478990b7a4205d29f3f28adcfc0cc74fa9634a8e1f")

