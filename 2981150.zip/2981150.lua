-- Lua provided by RyzenAPI
-- Game: addappid(2981150)

-- MAIN APPLICATION
addappid(2981150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981151, 1, "9cfaf4ebf41b61092cd2ef59726abe7e8809fe3bc2f73bbb4789d57c138c0f2b")
