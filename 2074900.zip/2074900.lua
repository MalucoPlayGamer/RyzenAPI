-- Lua provided by RyzenAPI
-- Game: 只爱三国

-- MAIN APPLICATION
addappid(2074900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074901, 1, "9e8ac16ce01aa68f54fd57551a7cc93ff6d1b4f52a77bd4bf7ebcbcad7b2a58b")

