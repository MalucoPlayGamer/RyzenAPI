-- Lua provided by RyzenAPI
-- Game: Legend of Merchant 2 Demo

-- MAIN APPLICATION
addappid(2406390)
-- Game: addappid(2406390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406391, 1, "c4de3ea080b1b73d1505ccf88d9f6163d1796affa296a6f15e0e7bf0d897e5c2")
