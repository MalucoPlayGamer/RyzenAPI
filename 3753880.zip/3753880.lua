-- 3753880's Lua and Manifest Created by Hubcap Manifest
-- Game Saloon Simulator
-- Created: July 20, 2026 at 00:12:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3753880) -- Game Saloon Simulator
-- MAIN APP DEPOTS
addappid(3753881, 1, "4e925f5920ad875ffe943ec22f7374e9655afab8b86af6476d80a70f2eaf4ac1") -- Depot 3753881
setManifestid(3753881, "805406999297464714", 3429774905)