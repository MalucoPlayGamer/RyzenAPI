-- Lua provided by RyzenAPI
-- Game: Game Saloon Simulator

-- MAIN APPLICATION
addappid(3753880) -- Game Saloon Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(3753881, 1, "4e925f5920ad875ffe943ec22f7374e9655afab8b86af6476d80a70f2eaf4ac1") -- Depot 3753881

