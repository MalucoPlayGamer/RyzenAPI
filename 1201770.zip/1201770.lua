-- Lua provided by RyzenAPI
-- Game: 1201770

-- MAIN APPLICATION
addappid(1201770)
addappid(1240940)
-- Game: addappid(1201770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201771, 1, "10af987bc57f129914774f70409d50c8b7bf9105f6cc54b62d65ce4a8056fcda")
