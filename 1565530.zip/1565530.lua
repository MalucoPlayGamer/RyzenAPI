-- Lua provided by RyzenAPI
-- Game: Game: 避雨2🌧

-- MAIN APPLICATION
addappid(1565530)
-- Game: addappid(1565530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565531, 1, "7bcd596ba0eda51bea9d5f2c6ba28466b37cb2762771418dae228ee45e05cea5")
