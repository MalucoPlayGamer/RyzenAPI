-- Lua provided by RyzenAPI
-- Game: Game: AppID 373600

-- MAIN APPLICATION
addappid(373600)
-- Game: addappid(373600)

-- MAIN APP DEPOTS / PACKAGES
addappid(373601, 1, "f6747d16e935b63c3c5c81ec94ca39e0f42258542ef728a4241f9046e6492408")
