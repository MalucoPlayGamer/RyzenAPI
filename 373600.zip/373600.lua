-- Lua provided by RyzenAPI
-- Game: Weapon of Choice

-- MAIN APPLICATION
addappid(373600)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(373601, 1, "f6747d16e935b63c3c5c81ec94ca39e0f42258542ef728a4241f9046e6492408")
