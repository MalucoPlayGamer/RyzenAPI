-- Lua provided by RyzenAPI
-- Game: 1772090

-- MAIN APPLICATION
addappid(1772090)
-- Game: addappid(1772090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772093,0,"254ae5580673e5021de75fcf3bcdf18c272ae430653eab36c811d2efe292630f")
addappid(1772094,0,"c03f9d99c9c3d987dfbc8b9ca810aa76cfe40eca3f8ce4a65625b03cc1f950c3")
