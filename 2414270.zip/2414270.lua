-- Lua provided by RyzenAPI
-- Game: Sunderfolk

-- MAIN APPLICATION
addappid(2414270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2414271, 1, "11c783092bc9c87c77db620b29c6cef6c1d94cdb6ef43ef36a3559491fb6c894")
