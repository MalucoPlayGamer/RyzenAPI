-- Lua provided by RyzenAPI
-- Game: Sunderfolk

-- MAIN APPLICATION
addappid(2414270)
addappid(3579970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2414271, 1, "11c783092bc9c87c77db620b29c6cef6c1d94cdb6ef43ef36a3559491fb6c894")

