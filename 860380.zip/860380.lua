-- Lua provided by RyzenAPI
-- Game: addappid(860380)

-- MAIN APPLICATION
addappid(860380)

-- MAIN APP DEPOTS / PACKAGES
addappid(860381, 1, "f90e4f70ce1953cb394a4c0bc17242325476ed445da5054a85897f3a6b3fb617")
