-- Lua provided by RyzenAPI
-- Game: 2076740

-- MAIN APPLICATION
addappid(2076740)
-- Game: addappid(2076740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076741, 1, "b32536c69c3dc75f1b9dac8e274acb5b95a42575cd97c221066ab596426ee122")
