-- Lua provided by RyzenAPI
-- Game: 1914010

-- MAIN APPLICATION
addappid(1914010)
-- Game: addappid(1914010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914011, 1, "8eabfa4c75923d68edc69e39f020dfc5b4dd747a17df5e2dc69d4535a817a604")
