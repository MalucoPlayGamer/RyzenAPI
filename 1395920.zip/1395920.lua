-- Lua provided by RyzenAPI
-- Game: GrappleWell

-- MAIN APPLICATION
addappid(1395920)
-- Game: addappid(1395920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395921, 1, "8a934d8debf630e3769b8ec75f778a34cde3c0a87a8a62d065fc259c81992808")
