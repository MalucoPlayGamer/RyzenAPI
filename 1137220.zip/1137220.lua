-- Lua provided by RyzenAPI
-- Game: Elite Soldier: 3D Shooter

-- MAIN APPLICATION
addappid(1137220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137221, 1, "e6c29ef659ce6de92d9192528787d56101d24bb017be0f50c8cb599b0d5622c6")
