-- Lua provided by RyzenAPI
-- Game: Cyberia 2: Resurrection

-- MAIN APPLICATION
addappid(717720)

-- MAIN APP DEPOTS / PACKAGES
addappid(717722,0,"36840d40b4ecad681359d0e311995dc8a728387885e1165701d0f005c90d5d2a")

