-- Lua provided by RyzenAPI
-- Game: Fantôme

-- MAIN APPLICATION
addappid(2079710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079711, 1, "e01bf0509fcddd8f3ca854aa1a00a741d621a830b35569b9c4803b186c0c8ff6")
addappid(2079712, 1, "bd1759dba4118b07d034c6a825bc3d5d5acbc329c1990502816be0e1d7e57099")
