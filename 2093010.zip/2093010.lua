-- Lua provided by RyzenAPI
-- Game: Supernatural

-- MAIN APPLICATION
addappid(2093010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2093011, 1, "b6637ddb087b756038dd8de272d0ba61ee65613ef691deb09b2e2570628e8c1e")

