-- Lua provided by RyzenAPI
-- Game: Supernatural

-- MAIN APPLICATION
addappid(2093010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093011, 1, "b6637ddb087b756038dd8de272d0ba61ee65613ef691deb09b2e2570628e8c1e")
