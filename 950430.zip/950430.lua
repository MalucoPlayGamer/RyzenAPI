-- Lua provided by RyzenAPI
-- Game: Red Obsidian Remnant - Soundtrack

-- MAIN APPLICATION
addappid(950430)
addappid(950431)

-- MAIN APP DEPOTS / PACKAGES
addappid(950430,0,"722912fd813587d2455b9f5d8b4b7cac7f9c67d98f28cee85fe63e2c204f8973")

