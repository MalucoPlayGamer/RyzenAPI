-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2963010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963010,0,"a38fcf70df142b89f1aa1b56aa588599a3f04714e9e45c0d3e69a72b70e79ba4")

