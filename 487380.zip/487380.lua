-- Lua provided by RyzenAPI
-- Game: Tetradecagon

-- MAIN APPLICATION
addappid(487380)

-- MAIN APP DEPOTS / PACKAGES
addappid(487384,0,"70a738564aa00ff9874758664ff6e6ccec710237104c24c2b5c1f7e992838f1c")

