-- Lua provided by RyzenAPI
-- Game: Tetradecagon

-- MAIN APPLICATION
addappid(487380)
addappid(497910)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(487384,0,"70a738564aa00ff9874758664ff6e6ccec710237104c24c2b5c1f7e992838f1c")

