-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Guan Yinping (High school girls Costume) / 関銀屏 「女子高生風コスチューム」

-- MAIN APPLICATION
addappid(964937)

-- MAIN APP DEPOTS / PACKAGES
addappid(964937,0,"377de828c064e482b93038826ba77f98b4971205197706ee8986febdc2c6fad5")

