-- Lua provided by RyzenAPI
-- Game: 964937

-- MAIN APPLICATION
addappid(964937)
-- Game: addappid(964937)

-- MAIN APP DEPOTS / PACKAGES
addappid(964937,0,"377de828c064e482b93038826ba77f98b4971205197706ee8986febdc2c6fad5")
