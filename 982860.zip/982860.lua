-- Lua provided by RyzenAPI
-- Game: 8 Queens

-- MAIN APPLICATION
addappid(982860)

-- MAIN APP DEPOTS / PACKAGES
addappid(982861, 1, "5b298a71d9ddc4349e1e06eec32469bd55b89748dcb9cebc4990968445ca5358")
addappid(982862, 1, "fe5060d4b39f73ae2e529cd2c802eccc808e5bebb4321f913cffab9ee1278d89")
addappid(982863, 1, "65bb5e870cf391b592de78f5b8c4660b613c5e4d9507f7ae8b7ba57c837bac76")