-- Lua provided by RyzenAPI
-- Game: Karmaflow: The Rock Opera Videogame - Act I & Act II

-- MAIN APPLICATION
addappid(317940)
addappid(368550)

-- MAIN APP DEPOTS / PACKAGES
addappid(317941, 1, "f67977fcdf59bf92539f56e6b7be09cb4c5d1181dd445b15a62d050e4efef2a9")
addappid(317942, 1, "f08d542e457933ea985057f1c37ad083322cd3ca92e151f639db2b3b2f19a80c")
addappid(317943, 1, "f56cf093e10063bfde0ee0a9c61394f47cdfb327eda0c4eff4bca56d7bbc10bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
