-- Lua provided by RyzenAPI
-- Game: addappid(1122555)

-- MAIN APPLICATION
addappid(1122555)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122555,0,"42ddd8c70f94f6b43ffcc7fedea3f064b803919ff27fd254440dad4c371f5aca")
