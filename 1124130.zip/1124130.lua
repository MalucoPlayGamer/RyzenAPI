-- Lua provided by RyzenAPI
-- Game: Streets of Neotokio

-- MAIN APPLICATION
addappid(1124130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1124131, 1, "8fb45a551c5c011d8150dadc59f52d91f834559c1a55cef50a879593e07c6587")

