-- Lua provided by SkyAPI 
-- Game: Streets of Neotokio
addappid(1124130)
addappid(1124131, 1, "8fb45a551c5c011d8150dadc59f52d91f834559c1a55cef50a879593e07c6587")
