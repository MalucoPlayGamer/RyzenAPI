-- Lua provided by RyzenAPI
-- Game: Wolfskin's Curse

-- MAIN APPLICATION
addappid(2172420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(2172421, 1, "cf1ac46bc1e49afe13ca248d47984335913c7034ede89dc78d47038dceac148c")
addappid(2172423, 1, "2864112bf71421d71fd85234fba200e7c92d25bca90be78b7d23d2487ee75221")

