-- Lua provided by RyzenAPI 
-- Game: Wolfskin's Curse
addappid(2172420)
addappid(2172421, 1, "cf1ac46bc1e49afe13ca248d47984335913c7034ede89dc78d47038dceac148c")
addappid(2172423, 1, "2864112bf71421d71fd85234fba200e7c92d25bca90be78b7d23d2487ee75221")
