-- Lua provided by RyzenAPI
-- Game: Game: Elisa: Seduce the Innkeeper

-- MAIN APPLICATION
addappid(704690)
-- Game: addappid(704690)

-- MAIN APP DEPOTS / PACKAGES
addappid(704691, 1, "c2ac6d03707ca19fb4820fa394d351c093b5ade1ab67b85cf219565943e47c89")
