-- Lua provided by RyzenAPI
-- Game: Nekoview

-- MAIN APPLICATION
addappid(1197580)
addappid(1207290)
addappid(1214230)
addappid(1214880)
addappid(1214900)
addappid(1405030)
addappid(1426640)
addappid(1448580)
addappid(1448581)
addappid(1448582)
addappid(1504170)
addappid(1505870)
addappid(1509240)
addappid(1566260)
addappid(1651180)
addappid(1656910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1197581, 1, "efbed7d28f25c315417e6fd65cfcf6dc0111270d467333fed2d40d26247ffe45")

