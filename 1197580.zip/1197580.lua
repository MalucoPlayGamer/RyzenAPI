-- Lua provided by RyzenAPI
-- Game: 1197580

-- MAIN APPLICATION
addappid(1197580)
-- Game: addappid(1197580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197581, 1, "efbed7d28f25c315417e6fd65cfcf6dc0111270d467333fed2d40d26247ffe45")
