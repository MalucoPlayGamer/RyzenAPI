-- Lua provided by RyzenAPI
-- Game: addappid(2614610)

-- MAIN APPLICATION
addappid(2614610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614612,0,"64064790fa3714b6f0c22425fbed9cc1c1d0c7532cb3ec2e0d31da6f7c09baac")
