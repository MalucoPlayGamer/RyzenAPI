-- Lua provided by RyzenAPI
-- Game: Kingdom of Piss

-- MAIN APPLICATION
addappid(3445120)
-- Game: addappid(3445120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445121, 1, "a96f693cadbfc20ddbfd19c56ad2ae01e918888fda3b56af23f887fff0238c96")
