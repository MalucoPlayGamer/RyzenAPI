-- Lua provided by RyzenAPI
-- Game: addappid(1103752)

-- MAIN APPLICATION
addappid(1103752)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103752,0,"ce06e979b2ac6b107d1e95fe6c412b3c4f77255c781a7107ac02da2fb715268f")
