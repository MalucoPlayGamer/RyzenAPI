-- Lua provided by RyzenAPI
-- Game: The Ark Adult Game

-- MAIN APPLICATION
addappid(2940250)
-- Game: addappid(2940250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2940251, 1, "9ef0f8442dfd56f8c8f2e5b12dc696f19c5bee6c1b6cc75a0c96740926179980")
