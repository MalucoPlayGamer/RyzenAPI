-- Lua provided by RyzenAPI
-- Game: ThinkAhead

-- MAIN APPLICATION
addappid(655180)

-- MAIN APP DEPOTS / PACKAGES
addappid(655181,0,"001de8ccb8727349cb334f1a945d0a9894a20122a2b7bfb0e31df121983ba13c")
addappid(655182,0,"1409fb5f052b5f22c966cd9ed2ee99b38b6f37c03bc37f87d537e8c66fecd973")

