-- Lua provided by RyzenAPI
-- Game: AppID 370130

-- MAIN APPLICATION
addappid(370130)
-- Game: addappid(370130)

-- MAIN APP DEPOTS / PACKAGES
addappid(370131, 1, "4918214be2b8fdc272c0257b6bfeee27c911dd16ed165cbc0e1be3ffd5b9c375")
addappid(370133, 1, "c6b2a16253fea26456583d3d66c9a71108c30034b97853f4b1c9d1377a222c5c")
addappid(370134, 1, "ec37c9e8c7f9ee8d8915796e9ca4d30f4ec5c8ebf15963a1e4855b18ddbeed49")
addappid(370135, 1, "26d23c3a738f99d149236a07f69d74205e345f96ddcc32df07dd8e23a2bc7a72")
