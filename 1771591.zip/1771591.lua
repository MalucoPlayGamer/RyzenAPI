-- Lua provided by RyzenAPI
-- Game: addappid(1771591)

-- MAIN APPLICATION
addappid(1771591)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771591,0,"4b2af0f664ae3a07051d864c994bffa73b839f37358b4b8ba3ff118957b968b1")
