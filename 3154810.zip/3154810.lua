-- Lua provided by RyzenAPI
-- Game: 荷莱Horae主线剪辑版Demo

-- MAIN APPLICATION
addappid(3154810)
-- Game: addappid(3154810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3154811, 1, "38e02dee90b0b922d9c5f02fb7c200a59fcd0ef9f211fb8d036512d91a3851f2")
