-- Lua provided by RyzenAPI
-- Game: AppID 848310

-- MAIN APPLICATION
addappid(848310)

-- MAIN APP DEPOTS / PACKAGES
addappid(848311, 1, "0d59fdfeab242ef8e76bc2ba8e8c235909723a6759a641fb01eb724e61b49fb8")
