-- Lua provided by RyzenAPI
-- Game: Fish Season

-- MAIN APPLICATION
addappid(3602600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602601, 1, "56b386f8b667d00b297367e9ed5fe3093b284c49f61646b2081995ad5d2b11db")

