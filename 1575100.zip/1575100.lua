-- Lua provided by RyzenAPI
-- Game: addappid(1575100)

-- MAIN APPLICATION
addappid(1575100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575101, 1, "bc0224e4cdd10b945d26239859c24a9b25ec5cb4626b53aaafe2b842816f7b06")
