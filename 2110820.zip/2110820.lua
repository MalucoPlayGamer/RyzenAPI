-- Lua provided by RyzenAPI
-- Game: Game: Granny Remake

-- MAIN APPLICATION
addappid(2110820)
-- Game: addappid(2110820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2110821, 1, "917826f8e3f15caeaeaeac968cabcaf30fdba21f7cf0a47111a2f6ccfe178329")
