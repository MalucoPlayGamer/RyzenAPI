-- Lua provided by RyzenAPI
-- Game: The Hundred Line -Last Defense Academy- Artbook

-- MAIN APPLICATION
addappid(3319760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319760,0,"fe92de42a7232fcb703844d0f9644a24611561c408aa574d4dba47f3ee44b769")
