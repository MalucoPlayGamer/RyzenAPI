-- Lua provided by RyzenAPI
-- Game: Game: World Empire 2027 Demo

-- MAIN APPLICATION
addappid(1995900)
-- Game: addappid(1995900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995901, 1, "67244636c53c21ab24e947ae4b7f565906e521968593b80c31f84926ffa7117e")
