-- Lua provided by RyzenAPI
-- Game: Game: Obscura

-- MAIN APPLICATION
addappid(1699830)
-- Game: addappid(1699830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699831, 1, "783d36059e3357079d9bc9a45fee5b804e643628b2476fbdef3149924f5969a1")
