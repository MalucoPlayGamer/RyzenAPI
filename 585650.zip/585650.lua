-- Lua provided by RyzenAPI
-- Game: Zero G Arena development files

-- MAIN APPLICATION
addappid(585650)

-- MAIN APP DEPOTS / PACKAGES
addappid(585651, 1, "4352976c76ad0ab6ec74683b26707eba7fd3d47e0875b644c113e685a6667d73")
addappid(585652, 1, "fa1919e9d8df478853d172d9197418c7c0651ce2adce0098a55e7aaa3685a69f")
