-- Lua provided by RyzenAPI
-- Game: addappid(44680)

-- MAIN APPLICATION
addappid(44680)

-- MAIN APP DEPOTS / PACKAGES
addappid(44681, 1, "bb4b965271e4cabb645ecea0934efd1b8e90a0a7c6e714cfd2db9f0444523451")
