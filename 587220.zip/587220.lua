-- Lua provided by RyzenAPI
-- Game: Jet Island

-- MAIN APPLICATION
addappid(587220)

-- MAIN APP DEPOTS / PACKAGES
addappid(587221, 1, "c9f23f313b414546b162d2e62d7a33c24807b515cc6ba724e2170044d29d0cc0")

