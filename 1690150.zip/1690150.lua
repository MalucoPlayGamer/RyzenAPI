-- Lua provided by RyzenAPI 
-- Game: Futanari Vampire Girlfriend
addappid(1690150)
addappid(1690151, 1, "60ebe37e9562a035b704b546df28151ba15a04a58a86c9d89a1c3130243cb686")
