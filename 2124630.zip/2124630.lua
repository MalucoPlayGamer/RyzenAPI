-- Lua provided by RyzenAPI
-- Game: Cardfight!! Vanguard Dear Days Demo

-- MAIN APPLICATION
addappid(2124630)
-- Game: addappid(2124630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124631, 1, "86f4960a3d8fd7c55533300df2e6529fcca5b96cf506c5f1adb97dad8b4cab28")
