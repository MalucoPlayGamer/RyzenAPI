-- Lua provided by RyzenAPI 
-- Game: Demolish & Build 2018
addappid(577670)
addappid(577671, 1, "052ca2c509eb5527fcce41b6ad1c7c6afd998b0aea124044da27a7ffd0f36876")
addappid(577672, 1, "6307251d4e605e6b05c9c7f2c1298a40b2df84be01e71a526264048345571912")
