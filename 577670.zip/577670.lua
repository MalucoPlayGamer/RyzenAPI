-- Lua provided by RyzenAPI
-- Game: Demolish & Build 2018

-- MAIN APPLICATION
addappid(577670)

-- MAIN APP DEPOTS / PACKAGES
addappid(577671, 1, "052ca2c509eb5527fcce41b6ad1c7c6afd998b0aea124044da27a7ffd0f36876")
addappid(577672, 1, "6307251d4e605e6b05c9c7f2c1298a40b2df84be01e71a526264048345571912")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
