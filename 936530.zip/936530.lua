-- Lua provided by RyzenAPI
-- Game: Close Combat: Last Stand Arnhem

-- MAIN APPLICATION
addappid(936530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(936531, 1, "8b7dfdecdecfe11a48857d4ffdf790c5fd9caa34f66751c79b49dd30a529e1ef")

