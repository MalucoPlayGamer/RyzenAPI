-- Lua provided by RyzenAPI
-- Game: addappid(936530)

-- MAIN APPLICATION
addappid(936530)

-- MAIN APP DEPOTS / PACKAGES
addappid(936531, 1, "8b7dfdecdecfe11a48857d4ffdf790c5fd9caa34f66751c79b49dd30a529e1ef")
