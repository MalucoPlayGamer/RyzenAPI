-- Lua provided by RyzenAPI
-- Game: Game: Gods Of Fire

-- MAIN APPLICATION
addappid(1178590)
-- Game: addappid(1178590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178591, 1, "4a17ea5007ab7a972642206462f050fc16c1d4050621eb2b95d040d00c97247b")
