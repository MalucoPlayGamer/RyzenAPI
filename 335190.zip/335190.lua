-- Lua provided by RyzenAPI
-- Game: 200% Mixed Juice!

-- MAIN APPLICATION
addappid(335190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(335191, 1, "47c2706599db875f22404f3c7dd83220201c9af716eec21844ba01b54dd8bde6")

