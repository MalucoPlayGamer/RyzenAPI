-- Lua provided by RyzenAPI
-- Game: addappid(335190)

-- MAIN APPLICATION
addappid(335190)

-- MAIN APP DEPOTS / PACKAGES
addappid(335191, 1, "47c2706599db875f22404f3c7dd83220201c9af716eec21844ba01b54dd8bde6")
