-- Lua provided by RyzenAPI
-- Game: Game: Tank Slam

-- MAIN APPLICATION
addappid(782460)
-- Game: addappid(782460)

-- MAIN APP DEPOTS / PACKAGES
addappid(782461, 1, "750c6ddd960537cdf0cef6a6603a95f869dd7f9360f3a0819af5d56be9e793dd")
