-- Lua provided by RyzenAPI
-- Game: 3322370

-- MAIN APPLICATION
addappid(3322370)
addappid(3347260)
-- Game: addappid(3322370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3322371, 1, "5614ef21091cb61a7a9ef91b290c0630071c019eb816e2b01bba9195376de3b2")
