-- Lua provided by RyzenAPI
-- Game: 街机三国

-- MAIN APPLICATION
addappid(3322370)
addappid(3347260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3322371, 1, "5614ef21091cb61a7a9ef91b290c0630071c019eb816e2b01bba9195376de3b2")

