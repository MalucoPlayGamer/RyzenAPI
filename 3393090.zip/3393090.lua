-- Lua provided by RyzenAPI
-- Game: 3393090

-- MAIN APPLICATION
addappid(3393090)
-- Game: addappid(3393090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393091, 1, "8902d7f8d836c0fb0eb6d0f671eab15ea843357791875bad8ecf98e199aa59d0")
addappid(3393092, 1, "5edadb1e8f4cbf8afde357e881e526e3e4efdbb261078f513cda8d5b8608051e")
addappid(3393093, 1, "98a027125d2cb34d8f42a4db7b8714a39f52aa4f640bf5e2c879af13917c5fb9")
