-- Lua provided by RyzenAPI
-- Game: 2211810

-- MAIN APPLICATION
addappid(2211810)
-- Game: addappid(2211810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211811, 1, "8fb46491c01dd3ec1e0caf7b66990a21c3c4c828577f82433737c13c4a179f75")
