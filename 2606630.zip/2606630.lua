-- Lua provided by RyzenAPI
-- Game: addappid(2606630)

-- MAIN APPLICATION
addappid(2606630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2606631, 1, "9d528b3f1a87555e7df555ce804973f8f0c78bd88ff9ad16312d66f0fba7eefe")
