-- Lua provided by RyzenAPI
-- Game: Shadowrun Returns

-- MAIN APPLICATION
addappid(234650)
addappid(272031)
addappid(272032)

-- MAIN APP DEPOTS / PACKAGES
addappid(234651, 1, "009ac25728262c38d88343e270143bae2eb10c6fc7cac6739e57509c225baaa0")
addappid(234652, 1, "a0569808275cb19f60d017b479351e9bd6a7da7673aa85c67863fd936a8607a4")
addappid(234653, 1, "4ca92a28c4dcf1e2d56e261cce071dd79c160aaad1d1d4b9843d18e751ef845a")
addappid(237810, 0, "2be072853dc376ccca52ab324f70c115dabc11c24f5fb8b2c51c579801e09fef")
addappid(272030, 0, "c829d0a69e60564753ba384c4f24c821c42d19e932c09e33b780e9ca1edb145b")

