-- Lua provided by RyzenAPI
-- Game: addappid(790250)

-- MAIN APPLICATION
addappid(790250)

-- MAIN APP DEPOTS / PACKAGES
addappid(790251, 1, "f6a3513c763c96602890cbf68ada28b6aa9e670162b5eafd6fd90d7df9e4db52")
