-- Lua provided by RyzenAPI
-- Game: That Role Playing

-- MAIN APPLICATION
addappid(1673180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673181, 1, "2e83995ee79860ffee205d5d91e66d5a24a8adeeca9889f38d7899521b9163b5")
