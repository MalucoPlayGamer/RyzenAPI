-- Lua provided by RyzenAPI
-- Game: That Role Playing

-- MAIN APPLICATION
addappid(1673180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1673181, 1, "2e83995ee79860ffee205d5d91e66d5a24a8adeeca9889f38d7899521b9163b5")

