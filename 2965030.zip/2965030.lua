-- Lua provided by RyzenAPI
-- Game: Don't Die, Collect Loot Demo

-- MAIN APPLICATION
addappid(2965030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2965031, 1, "e5d99387bab992e773c8f61d30d72b2f4d55afdc78374c72722509b22a834980")

