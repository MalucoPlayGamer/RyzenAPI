-- Lua provided by SkyAPI 
-- Game: AppID 2965030
addappid(2965030)
addappid(2965031, 1, "e5d99387bab992e773c8f61d30d72b2f4d55afdc78374c72722509b22a834980")
