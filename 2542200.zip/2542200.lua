-- Lua provided by RyzenAPI
-- Game: Return to Shironagasu Island Vocal Song Collection

-- MAIN APPLICATION
addappid(2542200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542201, 1, "23f25a38acc90c642af331910b9778aa109078c91c7757a76c5089b954963da9")
addappid(2542202, 1, "989946fe7d1bf770319a8771f0bedaed5cb7a50ef587ab8f527fe197cc39a161")
