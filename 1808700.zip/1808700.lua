-- Lua provided by SkyAPI 
-- Game: Dead Man´s Diary
addappid(1808700)
addappid(1808701, 1, "e4deaa691426d23ee6e1d61a39021f4dd13fb1446c236093bd7d9e506adfe266")
