-- Lua provided by RyzenAPI
-- Game: Dead Man´s Diary

-- MAIN APPLICATION
addappid(1808700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808701, 1, "e4deaa691426d23ee6e1d61a39021f4dd13fb1446c236093bd7d9e506adfe266")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
