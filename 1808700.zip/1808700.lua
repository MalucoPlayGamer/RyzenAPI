-- Lua provided by RyzenAPI
-- Game: 1808700

-- MAIN APPLICATION
addappid(1808700)
-- Game: addappid(1808700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808701, 1, "e4deaa691426d23ee6e1d61a39021f4dd13fb1446c236093bd7d9e506adfe266")
