-- Lua provided by SkyAPI 
-- Game: FLAW Demo
addappid(2512400)
addappid(2512401, 1, "d01c1209a79c7f53a9196d05d74c4bc7f97124477718712d0c7a6a5e47382341")
