-- Lua provided by RyzenAPI
-- Game: aMAZE ZERO - New Levels

-- MAIN APPLICATION
addappid(852020)

-- MAIN APP DEPOTS / PACKAGES
addappid(852020,0,"36f58fdc296d98dffce3d0fdb115df7723486320964574d1bde0c488acbff78e")

