-- Lua provided by RyzenAPI
-- Game: John:Condemned

-- MAIN APPLICATION
addappid(959170)

-- MAIN APP DEPOTS / PACKAGES
addappid(959171, 1, "7c6e9f32311fbb67cf57295a23c1cdd75728fec2907e04291b1df7a0b65be15b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
