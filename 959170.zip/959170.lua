-- Lua provided by RyzenAPI 
-- Game: John:Condemned
addappid(959170)
addappid(959171, 1, "7c6e9f32311fbb67cf57295a23c1cdd75728fec2907e04291b1df7a0b65be15b")
