-- Lua provided by RyzenAPI
-- Game: John:Condemned

-- MAIN APPLICATION
addappid(959170)

-- MAIN APP DEPOTS / PACKAGES
addappid(959171, 1, "7c6e9f32311fbb67cf57295a23c1cdd75728fec2907e04291b1df7a0b65be15b")
