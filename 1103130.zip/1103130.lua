-- Lua provided by RyzenAPI
-- Game: Game: AppID 1103130

-- MAIN APPLICATION
addappid(1103130)
-- Game: addappid(1103130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103131, 1, "8c4a446cbdb625e53e94fe7de71b8827b2fd046f42a4618eec21d0a99060dfea")
