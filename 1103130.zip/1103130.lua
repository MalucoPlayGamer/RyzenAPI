-- Lua provided by SkyAPI 
-- Game: AppID 1103130
addappid(1103130)
addappid(1103131, 1, "8c4a446cbdb625e53e94fe7de71b8827b2fd046f42a4618eec21d0a99060dfea")
