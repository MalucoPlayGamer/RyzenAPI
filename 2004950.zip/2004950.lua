-- Lua provided by RyzenAPI
-- Game: DRAINUS Original Soundtrack

-- MAIN APPLICATION
addappid(2004950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004951, 1, "df77a509de32476017628adc4b09dd15ca1ae2748e24552049409a0f6fc0f926")
addappid(2004952, 1, "61602df57a9a9e08a63a613d9deee3c5d59d54dae3550c02502132af0332cf7b")

