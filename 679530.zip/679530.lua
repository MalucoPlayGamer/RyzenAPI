-- Lua provided by RyzenAPI
-- Game: Game: Professor Watts Memory Match: Shapes And Colors

-- MAIN APPLICATION
addappid(679530)
-- Game: addappid(679530)

-- MAIN APP DEPOTS / PACKAGES
addappid(679531, 1, "ff9838bb66754aedecedf48b2f6a4bd38adab582009d4c065b69b05096a33409")
