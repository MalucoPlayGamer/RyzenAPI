-- Lua provided by RyzenAPI
-- Game: 1499360

-- MAIN APPLICATION
addappid(1499360)
-- Game: addappid(1499360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499360,0,"553879fac35d3bbc1353896e13ab73ea52056d80bc70ae862248dfb5a5ae1995")
