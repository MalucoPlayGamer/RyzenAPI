-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Time Fantasy Add-on: Dwarves Vs Elves

-- MAIN APPLICATION
addappid(1499360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499360,0,"553879fac35d3bbc1353896e13ab73ea52056d80bc70ae862248dfb5a5ae1995")

