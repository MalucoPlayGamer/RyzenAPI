-- Lua provided by RyzenAPI
-- Game: Endless Suburbia

-- MAIN APPLICATION
addappid(2476070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476071, 1, "547468cd553ffc38630cab68f99f9450b6870efb06265572c84ab9681e2e74fe")
