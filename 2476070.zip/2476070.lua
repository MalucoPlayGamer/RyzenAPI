-- Lua provided by RyzenAPI
-- Game: Endless Suburbia

-- MAIN APPLICATION
addappid(2476070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476071, 1, "547468cd553ffc38630cab68f99f9450b6870efb06265572c84ab9681e2e74fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
