-- Lua provided by RyzenAPI
-- Game: Game: Harmony's Odyssey

-- MAIN APPLICATION
addappid(1531490)
-- Game: addappid(1531490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531491, 1, "9db9c201ff126f1d10049476437a29e4f235c73e477c9c249f80d36bd5b490bd")
addappid(1531492, 1, "9f750ba6b53b854bd15f9e0bd342e08c3151c5e2fa1a912688707e70bdbc8d39")
addappid(1531493, 1, "c7f4a2c4087d8b7c2837247697ddc2ccf08ff599f44fc0f7c7d1447eb4715706")
