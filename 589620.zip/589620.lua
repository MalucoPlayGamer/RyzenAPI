-- Lua provided by RyzenAPI 
-- Game: AppID 589620
addappid(589620)
addappid(589621, 1, "65c288681ee0cc59603c00146dc57a2fd23a268e68cf823d7a5ae3a9c1297e70")
