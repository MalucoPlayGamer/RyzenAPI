-- Lua provided by RyzenAPI
-- Game: AppID 589620

-- MAIN APPLICATION
addappid(589620)

-- MAIN APP DEPOTS / PACKAGES
addappid(589621, 1, "65c288681ee0cc59603c00146dc57a2fd23a268e68cf823d7a5ae3a9c1297e70")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(590880)
addappid(590881)
addappid(590882)
addappid(590883)
addappid(590884)
