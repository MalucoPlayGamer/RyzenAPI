-- Lua provided by RyzenAPI
-- Game: AppID 600160

-- MAIN APPLICATION
addappid(600160)
-- Game: addappid(600160)

-- MAIN APP DEPOTS / PACKAGES
addappid(600161, 1, "14af86643fa3e68f2aa748d453cef0b51ce6cc74d06c49f6de950cec052c948b")
addappid(600162, 1, "759633425737a478d146375b416efb0bfed16d06311e4dad603cee57183821df")
