-- Lua provided by RyzenAPI
-- Game: Game: AppID 916470

-- MAIN APPLICATION
addappid(916470)
-- Game: addappid(916470)

-- MAIN APP DEPOTS / PACKAGES
addappid(916471, 1, "46cbf9fb6171bbde757ec09a41d71933c2e9eb1bba6fc44ad2b6236ea0b94745")
