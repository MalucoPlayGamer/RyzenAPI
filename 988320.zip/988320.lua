-- Lua provided by RyzenAPI
-- Game: 988320

-- MAIN APPLICATION
addappid(988320)

-- MAIN APP DEPOTS / PACKAGES
addappid(988320,0,"f32427ec3673a242596d7dddef42ab60af5c76d1384205f8ccd0b2e2b3d986d7")

