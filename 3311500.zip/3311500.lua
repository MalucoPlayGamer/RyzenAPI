-- Lua provided by RyzenAPI
-- Game: addappid(3311500)

-- MAIN APPLICATION
addappid(3311500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311500,0,"5e0668e0b08cc28a87e3a72a316a550e7de73f8a60832f59b57e29a52c14f3fb")
