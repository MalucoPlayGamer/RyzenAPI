-- Lua provided by RyzenAPI
-- Game: addappid(1525890)

-- MAIN APPLICATION
addappid(1525890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525891, 1, "860decafe72c377f69723bcf7f2a743293af372aae7888ca60c36f774311a3db")
