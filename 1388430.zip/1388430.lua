-- Lua provided by SkyAPI 
-- Game: AppID 1388430
addappid(1388430)
addappid(1388431, 1, "9dd786f69b70eb57f2b2101a95357ec648b617bd43df6ca76fb63379a9804789")
