-- Lua provided by RyzenAPI
-- Game: Game: Beautiful Girls

-- MAIN APPLICATION
addappid(1583650)
-- Game: addappid(1583650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583651, 1, "15fcb4cfdc85e742bf94207388cea0d0c85b014687906bf4c53a798672d357cc")
