-- Lua provided by SkyAPI 
-- Game: AppID 33930
addappid(33930)
addappid(33931, 1, "3b324ca60026d263ac2c391af625442d40c7675e5f1894a9e340c0c435d1499e")
addappid(33934, 1, "e76a2c7fff33e0185e60063b7dadb06d7ecbac7eb586b3cf54bdbbd387afed56")
addappid(33937, 1, "309019a4078b23b7d63eb7869152b006789ba736c1badd1eeb6be1773d86c04c")
