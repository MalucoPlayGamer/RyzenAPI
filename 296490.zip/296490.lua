-- Lua provided by RyzenAPI
-- Game: addappid(296490)

-- MAIN APPLICATION
addappid(296490)

-- MAIN APP DEPOTS / PACKAGES
addappid(296491, 1, "617e640fdde0b23d8d9aee8731ae7ea16b3f6e9c9b6fb6e2a83ffb1b70e53983")
