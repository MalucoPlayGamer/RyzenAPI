-- Lua provided by RyzenAPI
-- Game: Game: Overkill VR: Action Shooter FPS

-- MAIN APPLICATION
addappid(518720)
-- Game: addappid(518720)

-- MAIN APP DEPOTS / PACKAGES
addappid(518721, 1, "a77b55836aaa6c660cd2a6944905ef056e12c8bd2c58ac5bff209d6e09835e5f")
