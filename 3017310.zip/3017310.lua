-- Lua provided by RyzenAPI
-- Game: Soulmask Dedicated Server For Windows

-- MAIN APPLICATION
addappid(3017310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017311, 1, "323816052101e88456be5159b54d13d7633c364d10b2d3e59f698a75c0a0184b")
