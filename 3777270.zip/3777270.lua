-- Lua provided by RyzenAPI
-- Game: Lots of Cats on an Adventure

-- MAIN APPLICATION
addappid(3777270)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3777280)
