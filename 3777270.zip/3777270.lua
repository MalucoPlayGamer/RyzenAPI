-- Lua provided by RyzenAPI
-- Game: Lots of Cats on an Adventure

-- MAIN APPLICATION
addappid(3777270)

