-- Lua provided by RyzenAPI
-- Game: Game: PROXIMATE

-- MAIN APPLICATION
addappid(2957800)
-- Game: addappid(2957800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957801, 1, "41b2a6fd3d4e2ba5542473816388869eaaec83730bf37f799c96eb81612eeace")
