-- Lua provided by RyzenAPI
-- Game: Thalassa: Edge of the Abyss

-- MAIN APPLICATION
addappid(1783680)
addappid(3003370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1783681, 1, "c3ed69d3c436385e05548d350634c2ca7e7ef9dc151490f13e576764cfe12284")

