-- Lua provided by SkyAPI 
-- Game: GeneRally 2
addappid(2104920)
addappid(2104921, 1, "f47400ca94fe2e483e5c1e87aa5669ff3acb799c032ca64623ebaba6b9d1bc3e")
