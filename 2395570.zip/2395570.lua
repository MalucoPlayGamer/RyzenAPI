-- Lua provided by RyzenAPI
-- Game: The Holy Gosh Darn Demo

-- MAIN APPLICATION
addappid(2395570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395571, 1, "2615abf0b26adac2b2332f56de02186e805a2b07bd3ae64bba5bed8c1707f0b0")

