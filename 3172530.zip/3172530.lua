-- Lua provided by RyzenAPI 
-- Game: Horror Prison
addappid(3172530)
addappid(3172531, 1, "6274ba1d7154e95fdbe84399c27d8bacd11a01feb5ee5562b57740c43372d910")
