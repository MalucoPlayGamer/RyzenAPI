-- Lua provided by RyzenAPI
-- Game: Horror Prison

-- MAIN APPLICATION
addappid(3172530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172531, 1, "6274ba1d7154e95fdbe84399c27d8bacd11a01feb5ee5562b57740c43372d910")
