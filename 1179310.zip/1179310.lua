-- Lua provided by RyzenAPI
-- Game: Drift Alone

-- MAIN APPLICATION
addappid(1179310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179311, 1, "b74415e7f8170a45644f0889a3e6d02ec30aaf1f4f81ed6f1879224ceb2b21c4")

