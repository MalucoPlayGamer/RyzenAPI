-- Lua provided by RyzenAPI
-- Game: Game: AppID 1339350

-- MAIN APPLICATION
addappid(1339350)
-- Game: addappid(1339350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339351, 1, "8a3029ed9c957ee94aa8d72fe62ca68265b6860b6833d3f82226a7f704766e41")
