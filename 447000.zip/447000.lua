-- Lua provided by RyzenAPI
-- Game: addappid(447000)

-- MAIN APPLICATION
addappid(447000)

-- MAIN APP DEPOTS / PACKAGES
addappid(447001, 1, "3980f489b1ba2fdc2baa8d8bb7d99ebce3e174fa2286a9a669e834f8304c4e89")
