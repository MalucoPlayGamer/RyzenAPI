-- Lua provided by RyzenAPI
-- Game: addappid(1378290)

-- MAIN APPLICATION
addappid(1378290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378291, 1, "56c8297bab4cf6a6db3dbcc2ab0c06243f3abbe6ffa9d2e664b8df71ec460d5a")
