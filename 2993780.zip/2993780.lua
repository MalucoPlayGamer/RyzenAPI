-- Lua provided by RyzenAPI
-- Game: FANTASY LIFE i: The Girl Who Steals Time

-- MAIN APPLICATION
addappid(2993780)
addappid(3464380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2993781, 1, "ad98d2baa7c277a9a3d59599e17cb30eb75781386d8c475317d4570b8dc72aaf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
