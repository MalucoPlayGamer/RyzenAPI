-- Lua provided by RyzenAPI
-- Game: FANTASY LIFE i: The Girl Who Steals Time

-- MAIN APPLICATION
addappid(2993780)
addappid(3464380)
-- Game: addappid(2993780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2993781, 1, "ad98d2baa7c277a9a3d59599e17cb30eb75781386d8c475317d4570b8dc72aaf")
