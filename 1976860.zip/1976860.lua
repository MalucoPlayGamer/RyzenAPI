-- Lua provided by RyzenAPI
-- Game: MORSE

-- MAIN APPLICATION
addappid(1976860)
