-- Lua provided by RyzenAPI
-- Game: 3201930

-- MAIN APPLICATION
addappid(3201930)
-- Game: addappid(3201930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3201931, 1, "3aa61419391587d3d5b7ed3c405442394da072df44d8cecfb4f3ae584a84a456")
