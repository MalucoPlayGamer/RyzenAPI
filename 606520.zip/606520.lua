-- Lua provided by RyzenAPI
-- Game: addappid(606520)

-- MAIN APPLICATION
addappid(606520)

-- MAIN APP DEPOTS / PACKAGES
addappid(606521, 1, "b9767d6da8e8118bede95cc1f26bddc7f00f6898c418eafd4034273cd6e7da3c")
addappid(606522, 1, "77e7614b92aadea6cc0f22976dfc8540202b06e865505bb67255ab8294b832dd")
