-- Lua provided by RyzenAPI
-- Game: AppID 606520

-- MAIN APPLICATION
addappid(606520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(606521, 1, "b9767d6da8e8118bede95cc1f26bddc7f00f6898c418eafd4034273cd6e7da3c")
addappid(606522, 1, "77e7614b92aadea6cc0f22976dfc8540202b06e865505bb67255ab8294b832dd")

