-- Lua provided by RyzenAPI
-- Game: 3230890

-- MAIN APPLICATION
addappid(3230890)
-- Game: addappid(3230890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3230891, 1, "33a1b1093286f0f63a788ac4a6e5391b6873cd8444cfe6a02b9169fc679d6cc6")
