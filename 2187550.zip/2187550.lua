-- Lua provided by RyzenAPI
-- Game: 贝丽尔养成计划 Soundtrack

-- MAIN APPLICATION
addappid(2187550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187553,0,"05de1897891cfe86aeb73c308c69872c09d9c4774bc2938e7de95ad6c3ce0c1c")
addappid(2187554,0,"ab3e4e5e0f2b1d0c9b5afc6cd05bd25e94c4456ce4bf02b68991275453113dcb")

