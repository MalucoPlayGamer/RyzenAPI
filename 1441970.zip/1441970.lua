-- Lua provided by RyzenAPI
-- Game: addappid(1441970)

-- MAIN APPLICATION
addappid(1441970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441970,0,"756dd39a2a18f0de1e5798d6f0976ac8f0f5ece4f38213dcaf669d8cdff48c33")
