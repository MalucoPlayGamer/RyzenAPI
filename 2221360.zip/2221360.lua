-- Lua provided by RyzenAPI
-- Game: Frozen Flame - Digital Artbook & Wallpapers

-- MAIN APPLICATION
addappid(2221360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221360,0,"cf70e6d7e0b70788d68f94419c99624352c248b7dc59be80a149846bf8865c85")
