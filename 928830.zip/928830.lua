-- Lua provided by RyzenAPI
-- Game: 928830

-- MAIN APPLICATION
addappid(928830)
-- Game: addappid(928830)

-- MAIN APP DEPOTS / PACKAGES
addappid(928831, 1, "ff7fbefe46ba4a2b50c93192d69dd123f94807d4ff66e3a54ac87ba3b99b3785")
