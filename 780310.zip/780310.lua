-- Lua provided by RyzenAPI
-- Game: AppID 780310

-- MAIN APPLICATION
addappid(780310)

-- MAIN APP DEPOTS / PACKAGES
addappid(780311, 1, "623a98fe4783fbd1075071352beb0f614db19e74f7b053d39b8114cec14a62ec")
addappid(1945600, 0, "9abbbaeddef36c0236dbe53d811a7a012bc98e038c97671c14ec33cbebb91c8e")
addappid(2108630, 0, "373f648aa286e886aa41f7e597a375905872e3b9a6c38b678b9360aacad9d7e8")
addappid(2506610, 0, "8a9a814543e835601c5e99b6227a5e73bf353036874b2d8e659526bc738cc5fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
