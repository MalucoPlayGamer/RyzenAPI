-- Lua provided by RyzenAPI
-- Game: 1366290

-- MAIN APPLICATION
addappid(1366290)
-- Game: addappid(1366290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366291, 1, "bf385f05de4ed218ab7df3ddb1fc957828c091052fbe22eca063e4709259e01f")
