-- Lua provided by RyzenAPI
-- Game: addappid(3360780)

-- MAIN APPLICATION
addappid(3360780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3360781, 1, "4edbe3ed0b27929f65b1691681213d395dc0bec9e90c8b0afb35ceca85f89bd4")
