-- Lua provided by RyzenAPI
-- Game: The Lost Art of Innkeeping

-- MAIN APPLICATION
addappid(1327820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327821, 1, "0cc778d81b8d42c864c7154089fab5b0da1a30e41306e434ca0c9d40b817cf30")

