-- Lua provided by RyzenAPI 
-- Game: AppID 2386940
addappid(2386940)
addappid(2386941, 1, "6fc2044f7ab9a44b31c1d34d0b5bb709b611e73f3737f438838ded44d4a23f11")
