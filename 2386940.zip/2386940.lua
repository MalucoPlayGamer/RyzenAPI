-- Lua provided by RyzenAPI
-- Game: 2386940

-- MAIN APPLICATION
addappid(2386940)
-- Game: addappid(2386940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386941, 1, "6fc2044f7ab9a44b31c1d34d0b5bb709b611e73f3737f438838ded44d4a23f11")
