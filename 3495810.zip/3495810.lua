-- Lua provided by RyzenAPI
-- Game: Game: Wet Passion

-- MAIN APPLICATION
addappid(3495810)
-- Game: addappid(3495810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3495811, 1, "777dd5c9a1943c458c606c71f54597277d616d6b3403778f4826407ef5639669")
