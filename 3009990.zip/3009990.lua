-- Lua provided by RyzenAPI
-- Game: addappid(3009990)

-- MAIN APPLICATION
addappid(3009990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009991, 1, "b1d6cd4b687d87ebe7e4f6904f6c5d4816142c4e263fb043084cd7b61c4fb95e")
