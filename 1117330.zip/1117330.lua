-- Lua provided by RyzenAPI
-- Game: AppID 1117330

-- MAIN APPLICATION
addappid(1117330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117331, 1, "8a2d8d2a2c92cdc24237cd9d92065262c30cfd9db1adaab35d0efc9afbf2eb70")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1187750)
