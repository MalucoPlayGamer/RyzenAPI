-- Lua provided by RyzenAPI
-- Game: Bravery and Greed Demo

-- MAIN APPLICATION
addappid(2127170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2127171, 1, "075150f759b90293a468cc8f42b5a8a712c0d9585a79699240bc97d8ade3c794")

