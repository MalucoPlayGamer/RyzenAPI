-- Lua provided by RyzenAPI
-- Game: Demon Slayer Shion

-- MAIN APPLICATION
addappid(2420620)
-- Game: addappid(2420620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420621, 1, "b3ff0f74222b07268172c442345ad1f7cab2c9e4496a6fa236f9857490ae76e9")
addappid(2420622, 1, "84812569a20de81dd4a9b4e6862ccf367b6c85fe1973048f06b32faabdce8c9f")
addappid(2420623, 1, "f5d30954feb6392b1985821417a8d49ce9da5a1d056ffc6ad0762233402e5b8b")
