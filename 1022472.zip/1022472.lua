-- Lua provided by RyzenAPI
-- Game: addappid(1022472)

-- MAIN APPLICATION
addappid(1022472)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022472,0,"e6dd3bbcc894ccaac13d56ef548155548a69c10605cf202d004deca7e8143dd5")
