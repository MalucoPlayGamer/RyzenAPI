-- Lua provided by SkyAPI 
-- Game: AppID 3282670
addappid(3282670)
addappid(3282671, 1, "ca04f5512f9def9d894fb8fa00d77dc3b58dc52bca901fcdf7ad02f358118d79")
