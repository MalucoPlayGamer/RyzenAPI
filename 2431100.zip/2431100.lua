-- Lua provided by RyzenAPI
-- Game: Game: That Which Gave Chase

-- MAIN APPLICATION
addappid(2431100)
-- Game: addappid(2431100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431101, 1, "5deefd5427353354a7633cf81f28f74a6add68c56960d60b9bf76e0da5a7f449")
