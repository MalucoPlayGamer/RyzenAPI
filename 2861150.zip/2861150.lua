-- Lua provided by RyzenAPI 
-- Game: Working Sakuya
addappid(2861150)
addappid(2861151, 1, "41b9db2fca8ffd897db2b0abd6bf7c724a32ddd741298db630740439645bd9a7")
