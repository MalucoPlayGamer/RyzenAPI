-- Lua provided by RyzenAPI
-- Game: Cashrooms

-- MAIN APPLICATION
addappid(3284020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3284021, 1, "e2c3a8c3527e6d87435bae1c27de35ee622636979a3a8c82943a54af771ad6a2")

