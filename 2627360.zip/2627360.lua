-- Lua provided by SkyAPI 
-- Game: Afterlife Gladiator Demo
addappid(2627360)
addappid(2627361, 1, "d0c8383a0189489902273cf5dd659aaafeea19471d1aacb7e8a1003218295564")
