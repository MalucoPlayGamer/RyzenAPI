-- Lua provided by RyzenAPI
-- Game: addappid(2627360)

-- MAIN APPLICATION
addappid(2627360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2627361, 1, "d0c8383a0189489902273cf5dd659aaafeea19471d1aacb7e8a1003218295564")
