-- Lua provided by RyzenAPI 
-- Game: Alzheimer's: Memories
addappid(1624990)
addappid(1624991, 1, "b9a2e90459437f80a645fb6f15bca24da1f8c96fa9b8e86280e90d7a40a3d8cc")
