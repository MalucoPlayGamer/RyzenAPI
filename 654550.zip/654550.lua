-- Lua provided by RyzenAPI
-- Game: addappid(654550)

-- MAIN APPLICATION
addappid(654550)

-- MAIN APP DEPOTS / PACKAGES
addappid(654551, 1, "99365e1cc64fded72d64fa62a3b71094e57ab756407062b297fdd8681fddbad4")
