-- Lua provided by RyzenAPI
-- Game: Football Game

-- MAIN APPLICATION
addappid(654550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(654551, 1, "99365e1cc64fded72d64fa62a3b71094e57ab756407062b297fdd8681fddbad4")

