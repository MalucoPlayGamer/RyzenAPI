-- Lua provided by RyzenAPI
-- Game: 2446340

-- MAIN APPLICATION
addappid(2446340)
-- Game: addappid(2446340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446341, 1, "ad062fbe4f9d00db09d8be6d10d1b5dfee5c544f97d4ee3c06a08ae71ca801f6")
