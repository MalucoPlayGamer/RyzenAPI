-- Lua provided by RyzenAPI
-- Game: Draft Day Sports: College Basketball 2018

-- MAIN APPLICATION
addappid(807730)

-- MAIN APP DEPOTS / PACKAGES
addappid(807731,0,"31362475d3d9b08ee6c3df28c1a18e9af486e5af13f6fec464593c5c8e4ac821")

