-- Lua provided by RyzenAPI
-- Game: 373110

-- MAIN APPLICATION
addappid(373110)
addappid(492000)
-- Game: addappid(373110)

-- MAIN APP DEPOTS / PACKAGES
addappid(373111, 1, "9c2326d0acb4204269926d777a8a1fd595af812eeb8a0865dfac5d467a689dc2")
