-- Lua provided by RyzenAPI
-- Game: Karos

-- MAIN APPLICATION
addappid(337410)

-- MAIN APP DEPOTS / PACKAGES
addappid(337411, 1, "4fb94611111797c6839cbb2c6071f307738128abd27befe0c63b48e6a1ea90f8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(437640)
addappid(437641)
addappid(437642)
addappid(2168010)
addappid(2168011)
addappid(2168012)
addappid(2197590)
addappid(2294110)
addappid(2791330)
addappid(2791340)
addappid(3174180)
addappid(3174190)
addappid(3174200)
addappid(3174210)
addappid(3174220)
