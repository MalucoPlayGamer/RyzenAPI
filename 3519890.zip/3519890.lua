-- Lua provided by RyzenAPI
-- Game: Game: Hentai Yumiko

-- MAIN APPLICATION
addappid(3519890)
-- Game: addappid(3519890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3519891, 1, "bd8a65da13752060d1f2d51ced8762aea433a5076cb8f5196ed30c9d5a8e4397")
