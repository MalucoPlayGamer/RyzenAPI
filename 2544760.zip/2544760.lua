-- Lua provided by RyzenAPI
-- Game: AppID 2544760

-- MAIN APPLICATION
addappid(2544760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544761, 1, "682c7601460a705d5841320d68100eb63eb6f0d4eb0259069fafbbad144ca4fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
