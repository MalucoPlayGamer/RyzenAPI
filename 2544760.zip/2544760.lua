-- Lua provided by RyzenAPI
-- Game: addappid(2544760)

-- MAIN APPLICATION
addappid(2544760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544761, 1, "682c7601460a705d5841320d68100eb63eb6f0d4eb0259069fafbbad144ca4fb")
