-- Lua provided by RyzenAPI
-- Game: RAILGRADE

-- MAIN APPLICATION
addappid(1355090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355091, 1, "daa3442e0de51069a1c33660f9b3a524a7d70f7fb852e47c4d158ecbb591aa6c")
addappid(1355092, 1, "01d3f395cc14327d8054b54315d6cd4973827357a976f8295e4ae20c15d556d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
