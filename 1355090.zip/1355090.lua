-- Lua provided by RyzenAPI 
-- Game: RAILGRADE
addappid(1355090)
addappid(1355091, 1, "daa3442e0de51069a1c33660f9b3a524a7d70f7fb852e47c4d158ecbb591aa6c")
addappid(1355092, 1, "01d3f395cc14327d8054b54315d6cd4973827357a976f8295e4ae20c15d556d7")
