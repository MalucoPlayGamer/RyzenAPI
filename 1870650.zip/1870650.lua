-- Lua provided by RyzenAPI
-- Game: addappid(1870650)

-- MAIN APPLICATION
addappid(1870650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870651, 1, "2177f5bbe85adedd65a48e8eb352be31d82ea3c7e35376a3ba413109d23fa93b")
