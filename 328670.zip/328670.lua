-- Lua provided by RyzenAPI
-- Game: Deer Hunt Legends

-- MAIN APPLICATION
addappid(328670)

-- MAIN APP DEPOTS / PACKAGES
addappid(328671, 1, "64eaeb43422778a3300819b6106ab27030d2cb5303af8c49e689ce26a9ee132d")
