-- Lua provided by RyzenAPI
-- Game: Game: CHARGED: RC Racing - Starter Edition

-- MAIN APPLICATION
addappid(2393660)
-- Game: addappid(2393660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2393661, 1, "3f80dacbb9dccfb01ab0c7f180bed5f6f8d6e36e4a70d182c5128c7b8589d8db")
