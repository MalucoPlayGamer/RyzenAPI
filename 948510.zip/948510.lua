-- Lua provided by RyzenAPI
-- Game: Monster Clicker : Idle Halloween Strategy

-- MAIN APPLICATION
addappid(948510)

-- MAIN APP DEPOTS / PACKAGES
addappid(948511, 1, "309ceac6def56fc4d1fe13211773827d660ee576264771b2e3d82e682acb19f5")
