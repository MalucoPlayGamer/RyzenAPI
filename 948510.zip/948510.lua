-- Lua provided by SkyAPI 
-- Game: Monster Clicker : Idle Halloween Strategy
addappid(948510)
addappid(948511, 1, "309ceac6def56fc4d1fe13211773827d660ee576264771b2e3d82e682acb19f5")
