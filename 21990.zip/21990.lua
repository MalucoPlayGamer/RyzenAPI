-- Lua provided by RyzenAPI
-- Game: Game: TMNT™

-- MAIN APPLICATION
addappid(21990)
-- Game: addappid(21990)

-- MAIN APP DEPOTS / PACKAGES
addappid(21991, 1, "a4770ecc679d9088e3ec922295f0d94d17b203649fc907921461587691910042")
