-- Lua provided by RyzenAPI
-- Game: Hidden Boxes

-- MAIN APPLICATION
addappid(2604980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604981, 1, "9b7da564d51e7ca2bf3460e539b9d28d4a1a9b254a6ebc132868a83d34444ab4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
