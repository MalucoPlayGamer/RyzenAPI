-- Lua provided by RyzenAPI
-- Game: Hidden Boxes

-- MAIN APPLICATION
addappid(2604980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604981, 1, "9b7da564d51e7ca2bf3460e539b9d28d4a1a9b254a6ebc132868a83d34444ab4")

