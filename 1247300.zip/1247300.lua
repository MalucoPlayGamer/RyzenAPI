-- Lua provided by RyzenAPI
-- Game: Population Zero Soundtrack

-- MAIN APPLICATION
addappid(1247300)
-- Game: addappid(1247300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247302,0,"3616eaf4a79695bbbcff9c8b275f640aba40f56897a16e1761e8389ed338a29a")
addappid(1247303,0,"9ecaaeb8ca06f489b4aa4423c061080857ad3a51db69153d60ed46f7e97e227e")
