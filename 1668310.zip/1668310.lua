-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1668310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668314,0,"2cf6b5eb23d3cd3b557ca209d90e75de26fe9b5eb1a6efe124d37302df4dc858")

