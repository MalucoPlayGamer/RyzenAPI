-- Lua provided by RyzenAPI
-- Game: Game: Star Dream Journey

-- MAIN APPLICATION
addappid(3373900)
-- Game: addappid(3373900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3373901, 1, "ac70fba6e37dc8438473dd6c82f89ddd22e67b3136a53149b997d23b8d792e01")
