-- Lua provided by RyzenAPI
-- Game: Black Trail Demo

-- MAIN APPLICATION
addappid(2132940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2132941, 1, "2edb20495fb02d5230a1934ea081d892abe354ea04807ecc770276c24bec7d26")
