-- Lua provided by RyzenAPI
-- Game: Game: Microbes and Machines

-- MAIN APPLICATION
addappid(2074710)
-- Game: addappid(2074710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074711, 1, "762ed283c5ebcb8ae86e0417670af39c94e45dc5ea2db067078ec8e073d0b10a")
