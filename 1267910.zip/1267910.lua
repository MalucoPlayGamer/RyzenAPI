-- Lua provided by RyzenAPI
-- Game: addappid(1267910)

-- MAIN APPLICATION
addappid(1267910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267911, 1, "2c7496aa9bd2af0b01037eb53e94883921ad093afa94350aee66e5e0b3c68a84")
addappid(1267912, 1, "4cac0974efa6ca62ab12d6ce7bc2dc45f33b7a6368b00626b1177a09b2d986e1")
addappid(1267913, 1, "a8450c2daf53c9f6d9c7cd6a3bc13e267df6255590d6aac15a16a4f951b20a0c")
