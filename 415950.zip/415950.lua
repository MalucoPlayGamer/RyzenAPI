-- Lua provided by RyzenAPI
-- Game: Yohjo Simulator

-- MAIN APPLICATION
addappid(415950)

-- MAIN APP DEPOTS / PACKAGES
addappid(415951, 1, "5683cb9b201ce29e22358445aa6b314b773c0e20936ac980dfcbb9cfcf11f4bd")

