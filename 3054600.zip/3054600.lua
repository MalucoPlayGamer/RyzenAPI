-- Lua provided by RyzenAPI
-- Game: addappid(3054600)

-- MAIN APPLICATION
addappid(3054600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054600,0,"55dce4f4963c6ada0f61e2463d2119564902936b80c33fd098569a290ebd5cad")
