-- Lua provided by RyzenAPI
-- Game: Game: AppID 655930

-- MAIN APPLICATION
addappid(655930)
-- Game: addappid(655930)

-- MAIN APP DEPOTS / PACKAGES
addappid(655931, 1, "bb12c43cc82058ff9faa4936aaf81fc00490c3c3fb1641a675341f642e6bd452")
