-- Lua provided by RyzenAPI
-- Game: Meow'n'Dash

-- MAIN APPLICATION
addappid(1684830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684831, 1, "689fcfa93aa638f64cd0ed01f933c05fa58ac7f52c79a930f36e04816fe2a917")

