-- Lua provided by RyzenAPI
-- Game: Lost:Antinomy

-- MAIN APPLICATION
addappid(2521180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521181, 1, "0d08c1a541dc361816efb1d2aee187fd512befa60d7d838d31220110ac24d7ce")

