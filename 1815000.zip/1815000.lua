-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Alone

-- MAIN APPLICATION
addappid(1815000)
-- Game: addappid(1815000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815001, 1, "a657ae33d7325d6d0e8a3632926986026f0c96bcb3b6761bc50e0b2960a95984")
