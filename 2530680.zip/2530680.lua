-- Lua provided by RyzenAPI
-- Game: 2530680

-- MAIN APPLICATION
addappid(2530680)
-- Game: addappid(2530680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530681, 1, "947442b2b82026f002bf7b29eb4a795f53691dfc4491d68cbfe790e72df41ee3")
