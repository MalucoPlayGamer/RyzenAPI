-- Lua provided by RyzenAPI
-- Game: addappid(850250)

-- MAIN APPLICATION
addappid(850250)

-- MAIN APP DEPOTS / PACKAGES
addappid(850251, 1, "e26eaf73171034113a6c638f8ae84f47a0075900a548b0ed8755caaf5f011152")
