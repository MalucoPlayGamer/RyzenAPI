-- Lua provided by RyzenAPI
-- Game: Cattle 101 -  Sample Library

-- MAIN APPLICATION
addappid(1722830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722831, 1, "6954d3d6aeba86423e810218d8c7b0c0e67ab549b014c661cbd9478108b033a1")

