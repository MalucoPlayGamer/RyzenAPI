-- Lua provided by RyzenAPI
-- Game: Cattle 101 -  Sample Library

-- MAIN APPLICATION
addappid(1722830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722831, 1, "6954d3d6aeba86423e810218d8c7b0c0e67ab549b014c661cbd9478108b033a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
