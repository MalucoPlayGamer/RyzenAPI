-- Lua provided by RyzenAPI
-- Game: Hentai Nana

-- MAIN APPLICATION
addappid(2755210)
-- Game: addappid(2755210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755211, 1, "ce1f512966bf7a69081078d7ae48bc897131d4a0db2d28974f82da625e879a5f")
