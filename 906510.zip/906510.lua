-- Lua provided by RyzenAPI
-- Game: AppID 906510

-- MAIN APPLICATION
addappid(906510)

-- MAIN APP DEPOTS / PACKAGES
addappid(906511, 1, "0d723d1846d4b30649dfa35106ae562c966162979d7c817c8c2c4757fcaff489")
addappid(906513, 1, "c839e4edf7f10292b16217697837c707dcd8547d692f3c54bf63449fd89e4a31")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(906610)
