-- Lua provided by RyzenAPI 
-- Game: Wolvesville
addappid(2502760)
addappid(2502761, 1, "e801d70ed9f782b27e3f76b7479d2e162f4cce321638e7723569f64271e8565d")
