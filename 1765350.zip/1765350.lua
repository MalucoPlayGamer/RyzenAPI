-- Lua provided by RyzenAPI
-- Game: 候鸟

-- MAIN APPLICATION
addappid(1765350)
-- Game: addappid(1765350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765351, 1, "514857331e1ed67e754101218dfb3d9b441588758a0c829acb849cb0d758d21e")
