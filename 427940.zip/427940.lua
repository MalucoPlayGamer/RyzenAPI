-- Lua provided by RyzenAPI
-- Game: AppID 427940

-- MAIN APPLICATION
addappid(427940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(427941, 1, "d301ef289590d899e6e1e55f66d5ceb292de012b2b7d17d86ece48b59cea9e93")

