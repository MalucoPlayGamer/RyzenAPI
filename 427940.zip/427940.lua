-- Lua provided by RyzenAPI
-- Game: addappid(427940)

-- MAIN APPLICATION
addappid(427940)

-- MAIN APP DEPOTS / PACKAGES
addappid(427941, 1, "d301ef289590d899e6e1e55f66d5ceb292de012b2b7d17d86ece48b59cea9e93")
