-- Lua provided by RyzenAPI
-- Game: addappid(2460770)

-- MAIN APPLICATION
addappid(2460770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460771, 1, "4a4674817ebf683a609bdc63933ffcfe74da1217f3480704916699ddf274bcb9")
