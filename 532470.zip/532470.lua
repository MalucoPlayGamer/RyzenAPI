-- Lua provided by RyzenAPI
-- Game: addappid(532470)

-- MAIN APPLICATION
addappid(532470)

-- MAIN APP DEPOTS / PACKAGES
addappid(532471, 1, "6c2009253f00458a155d5f4d7563f1ebe4fcf99212d0ba4a8da0f5762b7fa51e")
