-- Lua provided by RyzenAPI
-- Game: AppID 1342810

-- MAIN APPLICATION
addappid(1342810)
-- Game: addappid(1342810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342811, 1, "1ddf5904bfa9b854079491d165adce02ad5cd89b373b42c533d400701e90bbe9")
