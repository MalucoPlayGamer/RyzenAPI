-- Lua provided by RyzenAPI
-- Game: Skybreakers Demo

-- MAIN APPLICATION
addappid(2530780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530781, 1, "6eae754a9e384a88c8aa9676124ea20be97d4bb945b1d6c5fd374e40f14809aa")
