-- Lua provided by RyzenAPI
-- Game: Forsaken Uprising

-- MAIN APPLICATION
addappid(314700)

-- MAIN APP DEPOTS / PACKAGES
addappid(314701, 1, "49f1604941f06e5f2d86533b315e79625649db9fafefa415d52e198e8348d68c")
