-- Lua provided by RyzenAPI
-- Game: 1322490

-- MAIN APPLICATION
addappid(1322490)
-- Game: addappid(1322490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322491, 1, "825607502166c1f46ef49fbb02066d89aa8a7b31eeb080d2e008ad286b9ba2f2")
