-- Lua provided by RyzenAPI
-- Game: 沉默的蟋蟀 Playtest

-- MAIN APPLICATION
addappid(2216150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216151, 1, "bc85df754ffdab2bf4fbaede87d790e3e5c538b26563491eac633b7a80e2a4f7")
