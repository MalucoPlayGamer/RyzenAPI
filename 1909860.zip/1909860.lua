-- Lua provided by RyzenAPI
-- Game: 守护女神

-- MAIN APPLICATION
addappid(1909860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909861, 1, "d09e0e8bbe4ca22488f595dddaadad720fdb256d29a23d4e6e0fa7bc43b3ae9a")
