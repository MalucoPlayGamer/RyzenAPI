-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 Personality Pack Guarded, Blunt Girl

-- MAIN APPLICATION
addappid(1875640)
-- Game: addappid(1875640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875641, 1, "beb40e3eb632378bb0be4e78e725569632441933a952ca9406d368795514dcbf")
addappid(1875642, 1, "83fd9918a5fa659057698ce8e25e2c10f2e70d6316d17a98d4931346224b9919")
