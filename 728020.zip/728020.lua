-- Lua provided by RyzenAPI
-- Game: 728020

-- MAIN APPLICATION
addappid(728020)
-- Game: addappid(728020)

-- MAIN APP DEPOTS / PACKAGES
addappid(728021, 1, "af2b990d15e538ded0b402ccbb558579c066dba372cb8d583ede7cf944a6d308")
