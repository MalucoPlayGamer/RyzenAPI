-- Lua provided by RyzenAPI
-- Game: Game: AppID 3453220

-- MAIN APPLICATION
addappid(3453220)
-- Game: addappid(3453220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453221, 1, "5128586408019c9af23d4fc3d6a6ed435cfa5657c5900723a926af52b723f7af")
