-- Lua provided by RyzenAPI
-- Game: CityBeat: The Sorority Shuffle Demo

-- MAIN APPLICATION
addappid(1578360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1578361, 1, "cef23e941037d07f146c188195d105b610b65521174f649d7bc736da9b73b8d6")
