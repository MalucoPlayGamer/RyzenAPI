-- Lua provided by RyzenAPI
-- Game: Retro Mystery Club Vol.2: The Beppu Case

-- MAIN APPLICATION
addappid(2602210)
-- Game: addappid(2602210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602211, 1, "c08f4a6baceddf1f0915d42031ca46313b96bb9a8c277b10a74d4f863e7f0a89")
