-- Lua provided by RyzenAPI
-- Game: Krut: The Mythic Wings

-- MAIN APPLICATION
addappid(1649860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649861, 1, "c3815e18bc1242af49bd65ee0a81ecacbfeaf84bdf981d3126a06b843210d7a6")

