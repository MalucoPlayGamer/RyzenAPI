-- Lua provided by RyzenAPI
-- Game: addappid(1098560)

-- MAIN APPLICATION
addappid(1098560)
addappid(1482460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098561, 1, "ad1edea86e5807ee7c1161871247858c7db24155266b3b9a4b5851ccd5495077")
