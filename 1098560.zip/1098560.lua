-- Lua provided by SkyAPI 
-- Game: AppID 1098560
addappid(1098560)
addappid(1098561, 1, "ad1edea86e5807ee7c1161871247858c7db24155266b3b9a4b5851ccd5495077")
addappid(1482460)
