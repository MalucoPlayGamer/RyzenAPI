-- Lua provided by RyzenAPI
-- Game: 1886150

-- MAIN APPLICATION
addappid(1886150)
addappid(2260400)
-- Game: addappid(1886150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1886151, 1, "1c81dc47c48c9220cb172a6fa977416f1441b0f30d97b43d689b02deba051f35")
