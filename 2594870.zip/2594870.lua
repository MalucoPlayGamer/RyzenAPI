-- Lua provided by RyzenAPI
-- Game: Game: Lethal Beach

-- MAIN APPLICATION
addappid(2594870)
-- Game: addappid(2594870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594871, 1, "cbac0c3e50efd0e4240b35ea4b42c386134358b77207f78aed395c0f8da7c115")
