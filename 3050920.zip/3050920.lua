-- Lua provided by RyzenAPI
-- Game: Journey of Rune

-- MAIN APPLICATION
addappid(3050920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3050921, 1, "debc2452650ca69a26a1dbcff665a8b3e9f41cdc9f7f9953e138aa412f8f407d")

