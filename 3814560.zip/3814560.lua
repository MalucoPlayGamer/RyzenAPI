-- Lua provided by RyzenAPI
-- Game: addappid(3814560)

-- MAIN APPLICATION
addappid(3814560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3814561, 1, "32c19818a5f1e1db4b9fba96be2f17d2bc493303309f3b51aff0967b551ae251")
