-- Lua provided by SkyAPI 
-- Game: AppID 39520
addappid(39520)
addappid(39521, 1, "a305e846ce3cb3b7233c94b9e2dd5eaef24af2d573fc9a8031697b508397293a")
addappid(39522, 1, "a536f42d548f55de92a590f68585f149c4ee40c60df7975a2a8362ea7b59eeab")
addappid(39523, 1, "3cd6b76a1bdbbe2ae4247e3b288d5aeeaff654c27fcaa13a715c8b74a6401c04")
