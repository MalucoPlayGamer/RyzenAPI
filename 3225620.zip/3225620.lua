-- Lua provided by RyzenAPI
-- Game: Game: AppID 3225620

-- MAIN APPLICATION
addappid(3225620)
-- Game: addappid(3225620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3225621, 1, "3e75ab2a1f3c3ec571d22f6c1acc5663a663a7348b0e869174c04d2c25ac38d8")
