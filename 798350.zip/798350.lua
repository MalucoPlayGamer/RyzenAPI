-- Lua provided by RyzenAPI
-- Game: Capsule Jump

-- MAIN APPLICATION
addappid(798350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(798351, 1, "e1276d12c73ac78841f61a76373db4b0e5e5bf19620da5d2bd827b2550f694af")
addappid(798352, 1, "54e3521f67e71c898820768330e73f2d1502f7bb9bdf50866de45963795981d7")

