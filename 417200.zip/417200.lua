-- Lua provided by RyzenAPI
-- Game: Make Sail

-- MAIN APPLICATION
addappid(417200)
-- Game: addappid(417200)

-- MAIN APP DEPOTS / PACKAGES
addappid(417201, 1, "6e19faacbf0cd772df19364f29e79dc8c7281b7b8f6454c38cc2085388393e2b")
