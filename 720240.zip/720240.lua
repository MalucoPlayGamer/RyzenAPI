-- Lua provided by RyzenAPI
-- Game: Legend of Fainn Dynasty ～Battles of Beautiful Warlords～

-- MAIN APPLICATION
addappid(720240)

-- MAIN APP DEPOTS / PACKAGES
addappid(720241, 1, "8937497d4e481b2ad9a7aa6aaff0242efce19a9c06ba564508479fdbc38b77cc")

