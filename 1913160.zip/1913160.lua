-- Lua provided by RyzenAPI
-- Game: COPS 2170 The Power of Law

-- MAIN APPLICATION
addappid(1913160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913161, 1, "ed271b4d322750425839b477220e3ae205048cd98897a30b92455236711a5502")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
