-- Lua provided by RyzenAPI
-- Game: Game: COPS 2170 The Power of Law

-- MAIN APPLICATION
addappid(1913160)
-- Game: addappid(1913160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913161, 1, "ed271b4d322750425839b477220e3ae205048cd98897a30b92455236711a5502")
