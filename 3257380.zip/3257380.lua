-- Lua provided by RyzenAPI
-- Game: Fast Food Simulator Demo

-- MAIN APPLICATION
addappid(3257380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3257381, 1, "c3f2c669bb0381a564340353e52b7d3ee46ef268090057c94e7ba0bd808950a7")
