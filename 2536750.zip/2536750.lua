-- Lua provided by RyzenAPI
-- Game: Afterlife

-- MAIN APPLICATION
addappid(2536750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536751, 1, "72d36d11db889d4c1bbcf1d78542246ddd59304235009345018dfa482d0614e8")
