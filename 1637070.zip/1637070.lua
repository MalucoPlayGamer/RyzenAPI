-- Lua provided by SkyAPI 
-- Game: My New Memories
addappid(1637070)
addappid(1637071, 1, "ac33a09ea1ceccd2249ee407fd8c27fd1e35f3d73119ed43efba70a6e4e2a741")
