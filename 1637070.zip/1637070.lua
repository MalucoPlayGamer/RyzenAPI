-- Lua provided by RyzenAPI
-- Game: 1637070

-- MAIN APPLICATION
addappid(1637070)
-- Game: addappid(1637070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637071, 1, "ac33a09ea1ceccd2249ee407fd8c27fd1e35f3d73119ed43efba70a6e4e2a741")
