-- Lua provided by RyzenAPI
-- Game: Propagation VR

-- MAIN APPLICATION
addappid(1363430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363431, 1, "a60fcd8f86ea5f14805c6201b5021353343fa5e5f71f5aa206a45ca420aef1ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1487770)
addappid(3902190)
