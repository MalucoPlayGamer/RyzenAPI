-- Lua provided by RyzenAPI
-- Game: 1363430

-- MAIN APPLICATION
addappid(1363430)
-- Game: addappid(1363430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363431, 1, "a60fcd8f86ea5f14805c6201b5021353343fa5e5f71f5aa206a45ca420aef1ff")
