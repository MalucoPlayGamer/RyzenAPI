-- Lua provided by RyzenAPI 
-- Game: Drive 4 Survival
addappid(1206670)
addappid(1206671, 1, "b838b44a8a81d6f0df88fe795dd31829c652d084d82071ee3c9f9153083cdf79")
