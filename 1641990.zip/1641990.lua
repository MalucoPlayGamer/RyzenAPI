-- Lua provided by RyzenAPI
-- Game: Warhammer Combat Cards

-- MAIN APPLICATION
addappid(1641990)
-- Game: addappid(1641990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641991, 1, "a70812a5b36360e256f50ba617de81413a42e108705412c4b606658745a5e9db")
