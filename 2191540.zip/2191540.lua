-- Lua provided by RyzenAPI
-- Game: Morkull Ragast's Rage

-- MAIN APPLICATION
addappid(2191540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191541, 1, "c3de67996919e22de4f589ef2b90a66a715b8271cb758b3269cdd2f8dcb31010")
