-- Lua provided by RyzenAPI
-- Game: Hacker's Restart

-- MAIN APPLICATION
addappid(2238980)
-- Game: addappid(2238980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2238981, 1, "abd7254b4f55f8410c9832cadf3a9cb4149d3c12f822302e12c962d4b2c0729d")
