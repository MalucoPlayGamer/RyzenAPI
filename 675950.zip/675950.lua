-- Lua provided by RyzenAPI
-- Game: Peninsular War Battles

-- MAIN APPLICATION
addappid(675950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(675951,0,"fe63892ccde81f403cd5eeb4b64bebe6d9c8ce06a1a14b22fa5f6fdc9fea6173")
addappid(675952,0,"b7eea599b929d1f6c6f047d5040884901de217af59efeb749b21bc84f0a29498")

