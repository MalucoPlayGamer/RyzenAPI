-- Lua provided by RyzenAPI
-- Game: addappid(372970)

-- MAIN APPLICATION
addappid(372970)

-- MAIN APP DEPOTS / PACKAGES
addappid(372971, 1, "d757c385b231c56b6ad9e84037a4b83f4f59a5e7f50c101d141be3b9e294ce7b")
