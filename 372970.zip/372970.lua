-- Lua provided by RyzenAPI 
-- Game: AppID 372970
addappid(372970)
addappid(372971, 1, "d757c385b231c56b6ad9e84037a4b83f4f59a5e7f50c101d141be3b9e294ce7b")
