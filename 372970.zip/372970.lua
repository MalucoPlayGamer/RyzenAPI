-- Lua provided by RyzenAPI
-- Game: Cash_Out

-- MAIN APPLICATION
addappid(372970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(372971, 1, "d757c385b231c56b6ad9e84037a4b83f4f59a5e7f50c101d141be3b9e294ce7b")
