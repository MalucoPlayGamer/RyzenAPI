-- 4369490's Lua and Manifest Created by Hubcap Manifest
-- Soulbound
-- Created: July 21, 2026 at 14:55:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4369490, 1, "2d395b997f77b7a1cdf0f2ff2367c498e506a92af8a000620825e53ba7b8dded") -- Soulbound
-- MAIN APP DEPOTS
addappid(4369491, 1, "0763fd7fc69cd5b5b2f1c0d9815e98e41955c0e87d20f9e6749947bcf6145e3f") -- Depot 4369491
setManifestid(4369491, "7252417916299789232", 215435590)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)