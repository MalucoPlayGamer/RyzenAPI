-- 457140's Lua and Manifest Created by Hubcap Manifest
-- Oxygen Not Included
-- Created: June 12, 2026 at 03:43:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 22
-- Total DLCs: 6
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(457140, 1, "bd3469b4af420f761c8bc3b61e72d81466e5d75b5236e63471909ffc70656d69") -- Oxygen Not Included
-- MAIN APP DEPOTS
addappid(457141, 1, "1f77f3d9ef1b69fc77d28031a5ed6d04cc279101faa6ffe5f1e0915b4baab79c") -- NA Depot
setManifestid(457141, "8165727204303421444", 3921371830)
addappid(457142, 1, "16847f270c721a9adf7256bc88d288af678193f74c533f2cd44bccff1ceccdf4") -- NA Depot - OSX
setManifestid(457142, "1159141211776104707", 3893876875)
addappid(457143, 1, "3199b2ed10129547be0ba6efa9fbb4aa5c740f09fe158c1cf9b8879fc7aba8e4") -- NA Depot - Linux
setManifestid(457143, "1660680211840629103", 3908696635)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
-- DLCS WITH DEDICATED DEPOTS
-- Oxygen Not Included - Spaced Out (AppID: 1452490)
addappid(1452490)
addappid(1452491, 1, "65272efbc87a5b051b30af08129c729e7069bf5fb8152d68d21fa0588bdbaa42") -- Oxygen Not Included - Spaced Out - NA Depot - Spaced Out! - Windows
setManifestid(1452491, "7642536614308049437", 307642775)
addappid(1452492, 1, "0b9f63b77607bdc6f37c6bdb210dae04b2b0c754c15f23d35f821faedde16c18") -- Oxygen Not Included - Spaced Out - NA Depot - Spaced Out! - OSX
setManifestid(1452492, "8082254291574169839", 307637528)
addappid(1452493, 1, "c9535e00cac8b8233875f729e30bd590afc2e07204f78d4ba08391d690279210") -- Oxygen Not Included - Spaced Out - NA Depot - Spaced Out! - Linux
setManifestid(1452493, "8900723501213691017", 307638028)
-- Oxygen Not Included The Frosty Planet Pack (AppID: 2952300)
addappid(2952300)
addappid(2952301, 1, "0aac13130570a4cb9a749ceff82c255feee2a1bf65b45505327eed962cb26157") -- Oxygen Not Included The Frosty Planet Pack - Depot 2952301
setManifestid(2952301, "7506896286955087991", 75250431)
addappid(2952302, 1, "52efd7282b10c02fdbed47f79ab3fee394692e140b4a4f6772bed739e17ce4a1") -- Oxygen Not Included The Frosty Planet Pack - Depot 2952302
setManifestid(2952302, "2351716390942655166", 75252935)
addappid(2952303, 1, "734a56752faf870ec6a0658210b60aac3f13de253df76e86374e6682c65026af") -- Oxygen Not Included The Frosty Planet Pack - Depot 2952303
setManifestid(2952303, "9056121695222736195", 75252926)
-- Oxygen Not Included The Bionic Booster Pack (AppID: 3302470)
addappid(3302470)
addappid(3302471, 1, "f8bc05dcd9e0ee42b25f6aa97c7f85fc741c4d6ad98d739bdf60e771b00a3b8c") -- Oxygen Not Included The Bionic Booster Pack - Depot 3302471
setManifestid(3302471, "1822568966096086841", 28254356)
addappid(3302472, 1, "65bd88c7ebed08e9724c1a238b1f2ac37402acad5347a83dcd5ba1cc0305d452") -- Oxygen Not Included The Bionic Booster Pack - Depot 3302472
setManifestid(3302472, "6215920908828744077", 28256790)
addappid(3302473, 1, "48e8fc6672f49bfa71934a13a2f53e4846315340e22d7be691de099e7db4d87d") -- Oxygen Not Included The Bionic Booster Pack - Depot 3302473
setManifestid(3302473, "7813832438596765983", 28258085)
-- Oxygen Not Included The Prehistoric Planet Pack (AppID: 3655420)
addappid(3655420)
addappid(3655421, 1, "1e19f1c5c9d64d9892acde57b6b210141f37d8b0c605605eed1e8728be887dae") -- Oxygen Not Included The Prehistoric Planet Pack - Depot 3655421
setManifestid(3655421, "7403924655808661883", 34400292)
addappid(3655422, 1, "71fcc2ab0243b59a4258e8417c3018e4e57caf88df6027f367a215d5f756875c") -- Oxygen Not Included The Prehistoric Planet Pack - Depot 3655422
setManifestid(3655422, "94831728340486813", 34398683)
addappid(3655423, 1, "beb86fc4b7407f862c2263bbdd011cd6e7e49728d5adb2353cbbc02ef9185ff6") -- Oxygen Not Included The Prehistoric Planet Pack - Depot 3655423
setManifestid(3655423, "8076514314459493646", 34400292)
-- Oxygen Not Included Neutronium Cosmetics Pack (AppID: 4157740)
addappid(4157740)
addappid(4157741, 1, "04c156d9e73616823c80c5634127217788cbb95922569e51a3e873c38636e466") -- Oxygen Not Included Neutronium Cosmetics Pack - Depot 4157741
setManifestid(4157741, "7269192979546626522", 4441700)
addappid(4157742, 1, "8fa03d1af4ac72fc16c0927fb26ac8a0d0eba62ced20d18087bbd54838f46bbd") -- Oxygen Not Included Neutronium Cosmetics Pack - Depot 4157742
setManifestid(4157742, "2972396247022102742", 4441665)
addappid(4157743, 1, "5e9a9d5edb45852df67aefd8454d049c2c6413343a33793a7e2dffd09a64673a") -- Oxygen Not Included Neutronium Cosmetics Pack - Depot 4157743
setManifestid(4157743, "2888959302683286004", 4441736)
-- Oxygen Not Included The Aquatic Planet Pack (AppID: 4310080)
addappid(4310080)
addappid(4310081, 1, "69ad525535865eb4f4d299cf857ce34c5a03d9a7d3c7c0650188727434d30f27") -- Oxygen Not Included The Aquatic Planet Pack - Depot 4310081
setManifestid(4310081, "3418394443924894948", 206526601)
addappid(4310082, 1, "b93eda89a01fc823363bc727480225676a34d3f5d254a56dc605cc583483c4b9") -- Oxygen Not Included The Aquatic Planet Pack - Depot 4310082
setManifestid(4310082, "4321593211256717004", 206526601)
addappid(4310083, 1, "6890afaf54c40e6d8a14a021174846341a0d47ddca554775f5fc2a96830f98af") -- Oxygen Not Included The Aquatic Planet Pack - Depot 4310083
setManifestid(4310083, "7997829856128702404", 206526601)