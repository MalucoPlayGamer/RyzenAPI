-- Lua provided by RyzenAPI
-- Game: Game: AppID 437610

-- MAIN APPLICATION
addappid(437610)
-- Game: addappid(437610)

-- MAIN APP DEPOTS / PACKAGES
addappid(437611, 1, "4b222a4400e74e3e623ae8a4585c1aa6416941c10f780f20375ec36620a16075")
