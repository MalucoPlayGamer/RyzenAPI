-- Lua provided by RyzenAPI
-- Game: SQUIDS FROM SPACE

-- MAIN APPLICATION
addappid(437610)
addappid(1155040)
addappid(1155041)
addappid(1155042)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(437611, 1, "4b222a4400e74e3e623ae8a4585c1aa6416941c10f780f20375ec36620a16075")

