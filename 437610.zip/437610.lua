-- Lua provided by SkyAPI 
-- Game: AppID 437610
addappid(437610)
addappid(437611, 1, "4b222a4400e74e3e623ae8a4585c1aa6416941c10f780f20375ec36620a16075")
