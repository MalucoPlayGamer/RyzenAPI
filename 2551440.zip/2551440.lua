-- Lua provided by SkyAPI 
-- Game: Kill A Million Rats
addappid(2551440)
addappid(2551441, 1, "9dee934a8cd6b2c826ef11c01d94b776e79e0f217eb3744a56aff6b78308a185")
