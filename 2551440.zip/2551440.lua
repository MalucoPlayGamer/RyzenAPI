-- Lua provided by RyzenAPI
-- Game: Kill A Million Rats

-- MAIN APPLICATION
addappid(2551440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551441, 1, "9dee934a8cd6b2c826ef11c01d94b776e79e0f217eb3744a56aff6b78308a185")

