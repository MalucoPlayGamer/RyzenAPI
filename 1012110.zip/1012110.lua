-- Lua provided by RyzenAPI
-- Game: 1012110

-- MAIN APPLICATION
addappid(1012110)
-- Game: addappid(1012110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012112,0,"cbc5b812e9be7c6d177cef1dd0db8c45d057d2cc1b24bdde7fd70a011b394cdb")
