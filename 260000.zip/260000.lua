-- Lua provided by RyzenAPI
-- Game: addappid(260000)

-- MAIN APPLICATION
addappid(260000)

-- MAIN APP DEPOTS / PACKAGES
addappid(260001, 1, "34dbc0bda179150c6a5967ee735f4666b4a40c1beb3360d9485ed9275a0adf0c")
