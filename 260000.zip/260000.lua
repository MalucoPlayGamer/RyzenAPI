-- Lua provided by RyzenAPI
-- Game: YOU DON'T KNOW JACK MOVIES

-- MAIN APPLICATION
addappid(260000)

-- MAIN APP DEPOTS / PACKAGES
addappid(260001, 1, "34dbc0bda179150c6a5967ee735f4666b4a40c1beb3360d9485ed9275a0adf0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
