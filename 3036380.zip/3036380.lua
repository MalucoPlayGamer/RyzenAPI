-- Lua provided by RyzenAPI
-- Game: Turtle Champs

-- MAIN APPLICATION
addappid(3036380)

