-- Lua provided by RyzenAPI
-- Game: 1044130

-- MAIN APPLICATION
addappid(1044130)
-- Game: addappid(1044130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044131, 1, "c95a4f30599b196464ba9fedf5e59f71730e9f9b04aed2e01ca8dca528078ce6")
