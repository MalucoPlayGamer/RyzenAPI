-- Lua provided by RyzenAPI
-- Game: Game: fault - StP - LIGHTKRAVTE

-- MAIN APPLICATION
addappid(1917450)
-- Game: addappid(1917450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917451, 1, "ccc43e7198087a689da7c371d3899b67c43321bb51b0d19d0111231d61755a67")
