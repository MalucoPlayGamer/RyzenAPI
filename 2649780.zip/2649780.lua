-- Lua provided by RyzenAPI
-- Game: Nightmare Side: The Game

-- MAIN APPLICATION
addappid(2649780)
-- Game: addappid(2649780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2649781, 1, "561b8deae6eff546aeb3304cbfcd52c8f562304bafa25e680437efd635c82d9a")
