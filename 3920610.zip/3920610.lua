-- Lua provided by RyzenAPI
-- Game: FATAL FRAME II: Crimson Butterfly REMAKE

-- MAIN APPLICATION
addappid(3920610)
addappid(4122450)
addappid(4123350)
addappid(4123360)
addappid(4123370)
addappid(4423570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3920611, 1, "12bffaedca2f7ee446211ba60b97b8262a19e282d803fde20b020cdd0d8ab780")
addappid(4123380, 0, "373ac671ea014e7cf29c347bbb4f27efa8fb93238f339504fa412757e9bd6b0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
