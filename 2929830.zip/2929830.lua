-- Lua provided by RyzenAPI
-- Game: Megan's Adventure

-- MAIN APPLICATION
addappid(2929830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929831, 1, "f1aef5c784eeeafd0e129aa094ab3a0eb64d195d700fedc266b976dc3703a5b1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3626170)
addappid(3626180)
addappid(3626190)
addappid(3626200)
addappid(3626220)
addappid(3626230)
addappid(3626240)
addappid(3626250)
addappid(3626260)
addappid(3626270)
addappid(4509880)
