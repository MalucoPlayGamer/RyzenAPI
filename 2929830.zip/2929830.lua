-- Lua provided by RyzenAPI
-- Game: Megan's Adventure

-- MAIN APPLICATION
addappid(2929830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929831, 1, "f1aef5c784eeeafd0e129aa094ab3a0eb64d195d700fedc266b976dc3703a5b1")

