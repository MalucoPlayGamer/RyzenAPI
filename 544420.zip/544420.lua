-- Lua provided by RyzenAPI
-- Game: Game: VRCapture

-- MAIN APPLICATION
addappid(544420)
-- Game: addappid(544420)

-- MAIN APP DEPOTS / PACKAGES
addappid(544421, 1, "2dd842f249543cd4444bfc31fa27213896095433ae08820998d1ef878360c8e7")
