-- Lua provided by RyzenAPI
-- Game: VRCapture

-- MAIN APPLICATION
addappid(544420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(544421, 1, "2dd842f249543cd4444bfc31fa27213896095433ae08820998d1ef878360c8e7")

