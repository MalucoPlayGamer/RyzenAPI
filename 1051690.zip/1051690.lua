-- Lua provided by RyzenAPI
-- Game: Game: AppID 1051690

-- MAIN APPLICATION
addappid(1051690)
-- Game: addappid(1051690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051691, 1, "0b4c013aef26f5234b65aee2e1aca873f859ce37a8367891ebcd0932cd8fbd5f")
