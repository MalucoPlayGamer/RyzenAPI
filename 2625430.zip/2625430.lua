-- Lua provided by RyzenAPI
-- Game: Return to Northbury Grove

-- MAIN APPLICATION
addappid(2625430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625431, 1, "3492c45fe44aa40aab4538896efb7c08fa18b763f2ee4951ffba36ada84dfbcb")

