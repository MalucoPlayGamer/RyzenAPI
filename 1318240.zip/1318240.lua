-- Lua provided by RyzenAPI
-- Game: Game: Shields of Loyalty

-- MAIN APPLICATION
addappid(1318240)
-- Game: addappid(1318240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318241, 1, "9bffba70c1389e777dd2661c3f3fb6a24a786c551bee5ad51331cb5487ba5397")
