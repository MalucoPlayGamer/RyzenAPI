-- Lua provided by SkyAPI 
-- Game: AppID 1295810
addappid(1295810)
addappid(1295811, 1, "a755e0d8808dff80ab1a52966b10d1d8da889ee25895870a14200d294f0a0d9a")
