-- Lua provided by RyzenAPI
-- Game: AppID 1295810

-- MAIN APPLICATION
addappid(1295810)
-- Game: addappid(1295810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295811, 1, "a755e0d8808dff80ab1a52966b10d1d8da889ee25895870a14200d294f0a0d9a")
