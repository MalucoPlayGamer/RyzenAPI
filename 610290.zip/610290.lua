-- Lua provided by RyzenAPI
-- Game: Visual Novel Maker - Live2D DLC

-- MAIN APPLICATION
addappid(610290)

-- MAIN APP DEPOTS / PACKAGES
addappid(610290,0,"206b9d5c0d0299c077279465c13a3040dc6bd96db875a214b96d4fccee17d3d4")

