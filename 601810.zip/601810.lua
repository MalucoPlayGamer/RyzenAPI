-- Lua provided by RyzenAPI
-- Game: Spark the Electric Jester

-- MAIN APPLICATION
addappid(601810)
-- Game: addappid(601810)

-- MAIN APP DEPOTS / PACKAGES
addappid(601811, 1, "f50fff3dc913d5b7de40f575ac2c422c7d9cfea03a3956c2039919066f002be0")
