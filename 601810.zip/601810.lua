-- Lua provided by RyzenAPI
-- Game: Spark the Electric Jester

-- MAIN APPLICATION
addappid(601810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(601811, 1, "f50fff3dc913d5b7de40f575ac2c422c7d9cfea03a3956c2039919066f002be0")

