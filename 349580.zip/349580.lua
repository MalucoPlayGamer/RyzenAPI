-- Lua provided by RyzenAPI
-- Game: Game: Burstfire

-- MAIN APPLICATION
addappid(349580)
-- Game: addappid(349580)

-- MAIN APP DEPOTS / PACKAGES
addappid(349581, 1, "d168923bb4e739701aff7238bc33f4f9a80c3e3992845b3041c1f1c9fd42e2a1")
