-- Lua provided by RyzenAPI
-- Game: Lingo

-- MAIN APPLICATION
addappid(1814170)
-- Game: addappid(1814170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814171, 1, "132067ddd01779af18b86f833aae319a05bb86cba20eaaa77642229a2455cb21")
