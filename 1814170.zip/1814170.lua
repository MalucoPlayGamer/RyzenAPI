-- Lua provided by SkyAPI 
-- Game: Lingo
addappid(1814170)
addappid(1814171, 1, "132067ddd01779af18b86f833aae319a05bb86cba20eaaa77642229a2455cb21")
