-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: FSDG - Hurghada

-- MAIN APPLICATION
addappid(2969910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969910,0,"f34c3a85c15803924b62b3c2a043a550b5bafdb6ef751428fe178eb6734f1f22")
