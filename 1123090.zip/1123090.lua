-- Lua provided by RyzenAPI
-- Game: addappid(1123090)

-- MAIN APPLICATION
addappid(1123090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123091, 1, "1b09b9b78ff14530fc037db3b047df4e31eb85261195293e986527abeab89916")
