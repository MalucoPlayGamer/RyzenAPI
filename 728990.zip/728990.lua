-- Lua provided by RyzenAPI
-- Game: Game: AppID 728990

-- MAIN APPLICATION
addappid(728990)
-- Game: addappid(728990)

-- MAIN APP DEPOTS / PACKAGES
addappid(728991, 1, "33edaf5c92f00c591ca7beae9abd7555b5f56713012c7ab9590563606a563542")
