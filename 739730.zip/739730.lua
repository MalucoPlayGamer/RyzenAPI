-- Lua provided by RyzenAPI
-- Game: Awe of Despair

-- MAIN APPLICATION
addappid(739730)

-- MAIN APP DEPOTS / PACKAGES
addappid(739731,0,"928086b312957786a6fb85f8defc41ccd897a79d1b935552b90bb6310079fb83")
addappid(739732,0,"184e69c66ef6576de41556645b4516bcbccc80ea553a14ea617300fe6eecf784")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
