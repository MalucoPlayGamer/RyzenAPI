-- Lua provided by RyzenAPI 
-- Game: Agent Lovesdick
addappid(1054470)
addappid(1054471, 1, "ee14bf4ad52a8fdfb20d81aba8795728016c7c9d25cc8438362297faf27b8c0d")
addappid(1145850)
addappid(1145851)
