-- Lua provided by RyzenAPI
-- Game: ZeroChance

-- MAIN APPLICATION
addappid(1594490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594491, 1, "effd573d5464e37e555d96ce8a98ecd79823a4f37b2b6ac5b94ad2b330010815")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
