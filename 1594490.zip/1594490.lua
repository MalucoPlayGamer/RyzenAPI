-- Lua provided by RyzenAPI
-- Game: addappid(1594490)

-- MAIN APPLICATION
addappid(1594490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594491, 1, "effd573d5464e37e555d96ce8a98ecd79823a4f37b2b6ac5b94ad2b330010815")
