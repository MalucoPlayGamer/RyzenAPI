-- Lua provided by RyzenAPI
-- Game: The Broken Seal

-- MAIN APPLICATION
addappid(710170)

-- MAIN APP DEPOTS / PACKAGES
addappid(710171, 1, "ba2f4e62ae924af6e7dc8689e3c75069577752d2b7b9d6646ba458572f033b70")

