-- Lua provided by RyzenAPI
-- Game: Game: AppID 3032690

-- MAIN APPLICATION
addappid(3032690)
-- Game: addappid(3032690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032691, 1, "cd1fbbf1cb052ad1f81050f507c33341504b1157c0d032847baac6017a30b114")
