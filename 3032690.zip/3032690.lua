-- Lua provided by RyzenAPI 
-- Game: AppID 3032690
addappid(3032690)
addappid(3032691, 1, "cd1fbbf1cb052ad1f81050f507c33341504b1157c0d032847baac6017a30b114")
