-- Lua provided by SkyAPI 
-- Game: ❂ Hexaluga ❂ Weapon and Shield ☯
addappid(845200)
addappid(845201, 1, "56b726e62b2d497599deeb7abaee0d86df0646430350cdce3f80db35f8e01296")
