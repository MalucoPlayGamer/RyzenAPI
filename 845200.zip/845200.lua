-- Lua provided by RyzenAPI
-- Game: addappid(845200)

-- MAIN APPLICATION
addappid(845200)

-- MAIN APP DEPOTS / PACKAGES
addappid(845201, 1, "56b726e62b2d497599deeb7abaee0d86df0646430350cdce3f80db35f8e01296")
