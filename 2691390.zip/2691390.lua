-- Lua provided by SkyAPI 
-- Game: Smoking Simulator
addappid(2691390)
addappid(2691391, 1, "417b9f4409768cc3756cea5b7a062652f8f91ddb76e5c20da8f11e6881ca0d98")
