-- Lua provided by RyzenAPI
-- Game: Smoking Simulator

-- MAIN APPLICATION
addappid(2691390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2691391, 1, "417b9f4409768cc3756cea5b7a062652f8f91ddb76e5c20da8f11e6881ca0d98")

