-- Lua provided by RyzenAPI
-- Game: BoneTown: The Second Coming Edition - Kinks BDSM

-- MAIN APPLICATION
addappid(2963050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963050,0,"e281e9a1d2667681dd6bc7dd02ce23a8c05712457cd0b5912c6a1d66988dacbe")
