-- Lua provided by RyzenAPI
-- Game: Proton & Electron

-- MAIN APPLICATION
addappid(3334360) -- Proton & Electron

-- MAIN APP DEPOTS / PACKAGES
addappid(3334361, 1, "096146ba357149b6bb40d7885d5055df85d60204f021691f0aa8fcf4ad7256d7") -- Depot 3334361
addappid(3334362, 1, "3b2b4d5c030c6440d61c964b27f6fba4436dc1ac6b15b5b29cc5d24f38d22c10") -- Depot 3334362

