-- Lua provided by RyzenAPI
-- Game: Iconia Defenders

-- MAIN APPLICATION
addappid(2747820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747821, 1, "edd4aa1d21ad5612f6213a399a87f0b09b2e4005e8f42c32316b6084ea8cfc54")

