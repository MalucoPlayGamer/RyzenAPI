-- Lua provided by RyzenAPI 
-- Game: Mainlining
addappid(454950)
addappid(454951, 1, "8b94f7737538969d9e9a2908732d75d325b5765f5bf92a81bb79457921ad725d")
addappid(585130, 1, "b68a601f16f6079bd5ab8b767036d2591b891a2e84d1bd958cd6ebdd9c138bd6")
addappid(579100)
