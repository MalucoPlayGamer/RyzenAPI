-- Lua provided by RyzenAPI
-- Game: Chainsaw Warrior (Classic)

-- MAIN APPLICATION
addappid(251710)

-- MAIN APP DEPOTS / PACKAGES
addappid(251712,0,"417b824e861929478616a23ec9d1632029989acc2681bc79659fc20400a9361a")
addappid(251713,0,"1dd8b83ab5830944952efe3d2180b9a7b4c8f261ae152c1cbe06d439d403cb4f")
addappid(251715,0,"c2998ee0451d4a689c71038c1e9653c56995bea6f9c06b870ba3f8c07849fe48")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
