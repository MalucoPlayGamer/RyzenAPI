-- Lua provided by SkyAPI 
-- Game: マスターオブモンスターズSSB
addappid(3427170)
addappid(3427171, 1, "3d24c924006dcd10d4a0490c965f6892a46d44ab050a2712f0c328b78b7d8596")
addappid(3759570, 0, "3a150128f82e062b8bae66f0023efb0132e8754548cbec0fa9c3d908170785e2")
