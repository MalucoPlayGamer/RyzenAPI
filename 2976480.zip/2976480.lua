-- Lua provided by RyzenAPI
-- Game: addappid(2976480)

-- MAIN APPLICATION
addappid(2976480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976482,0,"58c2cc83933cc23ca1e7ddd32cf01f6227aff125454c50827de13a9dedc88c6f")
addappid(2976483,0,"8e48ad8e20f5bf3e0ee649dd6f0f084a0ab6ec067f8b6f657771699156e298f0")
