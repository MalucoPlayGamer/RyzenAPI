-- Lua provided by RyzenAPI
-- Game: addappid(2926810)

-- MAIN APPLICATION
addappid(2926810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926811, 1, "64f570674726d8fbb718d39fe5bf69fde1706d1b36fc10d6b66f7217c3ab505e")
