-- Lua provided by RyzenAPI
-- Game: 1313360

-- MAIN APPLICATION
addappid(1313360)
-- Game: addappid(1313360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313361, 1, "a3f6cd6b7d59cb0b16a48620d0175f5291f9dd9d4348b33d7636335c2a347ad8")
