-- Lua provided by RyzenAPI
-- Game: LineVox 2: Forward to the Past

-- MAIN APPLICATION
addappid(1758050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758051, 1, "7ee43002d41a938ac024e382f22a30470364d4e3cab908c7ba3d70d92fee3f4c")

