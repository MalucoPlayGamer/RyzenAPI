-- Lua provided by RyzenAPI
-- Game: LineVox 2: Forward to the Past

-- MAIN APPLICATION
addappid(1758050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1758051, 1, "7ee43002d41a938ac024e382f22a30470364d4e3cab908c7ba3d70d92fee3f4c")

