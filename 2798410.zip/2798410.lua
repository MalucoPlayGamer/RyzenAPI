-- Lua provided by RyzenAPI
-- Game: Game: uninhabited island

-- MAIN APPLICATION
addappid(2798410)
-- Game: addappid(2798410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2798411, 1, "cc35c1243c707defa59e8cc3efadb14039e9c7b9cfb183001f84d5f7ca1b943c")
