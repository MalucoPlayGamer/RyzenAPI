-- Lua provided by RyzenAPI
-- Game: Slackline VR

-- MAIN APPLICATION
addappid(1920270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920271, 1, "4bc614574c22adb0a5d44d90beb24edc63936995ad9f47d86e6217ec3a132adb")

