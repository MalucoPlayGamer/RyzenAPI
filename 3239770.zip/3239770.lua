-- Lua provided by RyzenAPI
-- Game: Metrogether

-- MAIN APPLICATION
addappid(3239770)
addappid(3644650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239771,0,"679b1077b2da02112c15f5f3549d3d26d356cb5a3ffe2f0900f1049d8f008c30")

