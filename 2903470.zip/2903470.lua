-- Lua provided by RyzenAPI
-- Game: 2903470

-- MAIN APPLICATION
addappid(2903470)
-- Game: addappid(2903470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903471, 1, "47b556634a32e6f2d101b0bd53d0d752034baca51585e0348bf6e5dca50acd85")
