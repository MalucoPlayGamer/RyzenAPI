-- Lua provided by RyzenAPI
-- Game: Guardians of Graxia

-- MAIN APPLICATION
addappid(90500)

-- MAIN APP DEPOTS / PACKAGES
addappid(90501, 1, "1579dab635b347bdd11f70b0861508bad5e94f1ef506d8742b7d3d6f1e6be3cc")
addappid(90502, 1, "3e1968342d9894e89a7b5fef77ef080bce47036c8eaa3e3c6f5c4541128a7751")
addappid(90503, 1, "b4fcaabe860f972c00dadbeb45a6e4cb4647ef2949740b239d1293b319d8cfae")
addappid(90504, 1, "809c2d89325d16fbb3fbe60247a6e8a228320d129bcdd96164a7d5cf54d16344")

