-- Lua provided by SkyAPI 
-- Game: Five Nights at Roner's 2
addappid(2972810)
addappid(2972811, 1, "204cce4526b9acb93b31691911cfcc9b9428807d77502c39a5dd7632ce55c3ff")
