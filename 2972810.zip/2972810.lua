-- Lua provided by RyzenAPI
-- Game: 2972810

-- MAIN APPLICATION
addappid(2972810)
-- Game: addappid(2972810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2972811, 1, "204cce4526b9acb93b31691911cfcc9b9428807d77502c39a5dd7632ce55c3ff")
