-- Lua provided by RyzenAPI
-- Game: Sympathia

-- MAIN APPLICATION
addappid(2619210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619211, 1, "85707d2f8473b577e0928896cf6ae0879b96e2f7ada044ceb8ff34b6dc72be9b")

