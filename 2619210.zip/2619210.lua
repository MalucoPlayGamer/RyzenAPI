-- Lua provided by SkyAPI 
-- Game: Sympathia
addappid(2619210)
addappid(2619211, 1, "85707d2f8473b577e0928896cf6ae0879b96e2f7ada044ceb8ff34b6dc72be9b")
