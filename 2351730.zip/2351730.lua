-- Lua provided by RyzenAPI
-- Game: 2351730

-- MAIN APPLICATION
addappid(2351730)
-- Game: addappid(2351730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351731, 1, "3fa05fd4856869ad9368559e347de76966c3a90feac8ac8d25be527694f47ddd")
