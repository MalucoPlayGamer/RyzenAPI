-- Lua provided by RyzenAPI
-- Game: Gleeb Glob

-- MAIN APPLICATION
addappid(2005790)
-- Game: addappid(2005790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005791, 1, "2208d6434dfa7182fd306142afb7f9a0a529fece45843c10384ceb3dc2b10618")
