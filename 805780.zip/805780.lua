-- Lua provided by RyzenAPI
-- Game: AppID 805780

-- MAIN APPLICATION
addappid(805780)

-- MAIN APP DEPOTS / PACKAGES
addappid(805781, 1, "94a208cc46f2909dfecfa32e6f6d926ec3ce01c350c4882bcbaf831288c14532")

