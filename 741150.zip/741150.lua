-- Lua provided by RyzenAPI
-- Game: ArtPose Pro

-- MAIN APPLICATION
addappid(741150)
-- Game: addappid(741150)

-- MAIN APP DEPOTS / PACKAGES
addappid(741151, 1, "2f9e7ee17de8a644ff848d5667ab18dac2d48a3eeeb91f276171ca8e6f9cc26c")
