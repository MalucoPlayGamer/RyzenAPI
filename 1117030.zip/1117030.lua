-- Lua provided by RyzenAPI
-- Game: 1117030

-- MAIN APPLICATION
addappid(1117030)
-- Game: addappid(1117030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117031, 1, "c0fdc21c75aca6f3a80041551ced32410190951b7f717f9e6931d36808bcbafb")
