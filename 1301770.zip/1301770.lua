-- Lua provided by RyzenAPI
-- Game: 1301770

-- MAIN APPLICATION
addappid(1301770)
-- Game: addappid(1301770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301771, 1, "380630beeff6af8aea9906801023aaeceed66c6c242952fd10c2b80a8e218561")
