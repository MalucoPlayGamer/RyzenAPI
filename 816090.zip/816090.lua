-- Lua provided by RyzenAPI
-- Game: Space Hulk: Deathwing - Enhanced Edition

-- MAIN APPLICATION
addappid(816090)
addappid(816100)
addappid(842330)
addappid(842331)
addappid(1303800)

-- MAIN APP DEPOTS / PACKAGES
addappid(816091,0,"7240983c8c31d0e390d54e20533c4f89774ef1007f8869f9e0b2f0077d229d9c")
addappid(816092,0,"ea6a89ced29c1a71cefbbd5e928ffaabdc81991605f6f50e575e5773156ae750")
addappid(816093,0,"637863e2bae8f8973ee3bee57d3d5a3c1d64850b2b3a47d6dd6b4bfd31289f4f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
