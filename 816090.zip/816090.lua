-- Lua provided by RyzenAPI 
-- Game: AppID 816090
addappid(816090)
addappid(816091, 1, "7240983c8c31d0e390d54e20533c4f89774ef1007f8869f9e0b2f0077d229d9c")
addappid(816092, 1, "ea6a89ced29c1a71cefbbd5e928ffaabdc81991605f6f50e575e5773156ae750")
addappid(816093, 1, "637863e2bae8f8973ee3bee57d3d5a3c1d64850b2b3a47d6dd6b4bfd31289f4f")
