-- Lua provided by RyzenAPI
-- Game: addappid(1313220)

-- MAIN APPLICATION
addappid(1313220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313221, 1, "539a586e65b42bb1a26dc9949e1b4448750dc652e0a9ad148136fd4243f53eb1")
