-- Lua provided by RyzenAPI
-- Game: 1177420

-- MAIN APPLICATION
addappid(1177420)
addappid(1501400)
-- Game: addappid(1177420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177421, 1, "382bd3c5475ffe32e1472b4ab62537038ecea26dcfa0ddfae97de494ba2cf0e9")
addappid(1177422, 1, "436e5452034c946e7fb756192c067c4f7057e07b754a8ec43e7ae22676db9714")
