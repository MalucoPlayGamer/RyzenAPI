-- Lua provided by RyzenAPI
-- Game: FOCUS on YOU

-- MAIN APPLICATION
addappid(1032670)
addappid(1102900)
addappid(1102901)
addappid(1102910)
addappid(1134690)
addappid(1169610)
addappid(1295340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032671,0,"91e94d90b4ed7d1ef4029dc850a62eca8be6f58c26023c40f0966bf256555f81")
addappid(1102901,0,"af418e87c5ccc41a75a8932bb2c7862af8255a4d887951b45c7aacd88f46da81")
addappid(1102910,0,"1e9c931df5c1031349520349398e9bc0b2060fdf832286dc675731ebf22c4061")
addappid(1169610,0,"97f0c92df6796e05ac6704d2d1e65dd26e7999d2fe1dfac78bdd105cd83d8ccc")
addappid(1295340,0,"863b067ae05d682b999345ff96858ea691e416678c2af724f5bf0102857ea0cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
