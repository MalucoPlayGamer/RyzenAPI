-- Lua provided by SkyAPI 
-- Game: FOCUS on YOU
addappid(1032670)
addappid(1032671, 1, "91e94d90b4ed7d1ef4029dc850a62eca8be6f58c26023c40f0966bf256555f81")
