-- Lua provided by RyzenAPI
-- Game: FOCUS on YOU

-- MAIN APPLICATION
addappid(1032670)
-- Game: addappid(1032670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032671, 1, "91e94d90b4ed7d1ef4029dc850a62eca8be6f58c26023c40f0966bf256555f81")
