-- 4529440's Lua and Manifest Created by Hubcap Manifest
-- FD 27: Direct Your Football Club
-- Created: August 14, 2026 at 10:44:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4529440) -- FD 27: Direct Your Football Club
-- MAIN APP DEPOTS
addappid(4529441, 1, "14d2cf87b5415c928932465d781b1d899dce854224d2a00d9c5d15c26c6bcc39") -- Depot 4529441
setManifestid(4529441, "5188187658377999125", 3708517130)