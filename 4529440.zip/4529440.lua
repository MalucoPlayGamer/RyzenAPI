-- Lua provided by RyzenAPI
-- Game: FD 27: Direct Your Football Club

-- MAIN APPLICATION
addappid(4529440) -- FD 27: Direct Your Football Club

-- MAIN APP DEPOTS / PACKAGES
addappid(4529441, 1, "14d2cf87b5415c928932465d781b1d899dce854224d2a00d9c5d15c26c6bcc39") -- Depot 4529441

