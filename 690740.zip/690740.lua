-- Lua provided by RyzenAPI
-- Game: AppID 690740

-- MAIN APPLICATION
addappid(690740)

-- MAIN APP DEPOTS / PACKAGES
addappid(690741, 1, "a250a0e328c41d55ee4e035c3bc7e19112ab66f818dc1b6462c3b6c60fcc8300")

