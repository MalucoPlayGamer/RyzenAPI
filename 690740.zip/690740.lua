-- Lua provided by RyzenAPI
-- Game: AppID 690740

-- MAIN APPLICATION
addappid(690740)

-- MAIN APP DEPOTS / PACKAGES
addappid(690741, 1, "a250a0e328c41d55ee4e035c3bc7e19112ab66f818dc1b6462c3b6c60fcc8300")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
