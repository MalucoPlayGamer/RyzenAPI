-- Lua provided by RyzenAPI
-- Game: Midnight Mysteries: Witches of Abraham - Collector's Edition

-- MAIN APPLICATION
addappid(332810)

-- MAIN APP DEPOTS / PACKAGES
addappid(332811, 1, "32744b6acd51f42dcf2e6ae6832b96907fd5ed0d141c369e19c90d0eaef61c8d")

