-- Lua provided by RyzenAPI
-- Game: 3601870

-- MAIN APPLICATION
addappid(1466982)
addappid(3601870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466981,0,"4a2bdca282438e71218eb4d09ccb6503ac77d130bf3f5d74ed74ef68a2aacc7a")
