-- Lua provided by RyzenAPI
-- Game: Braid

-- MAIN APPLICATION
addappid(26800)

-- MAIN APP DEPOTS / PACKAGES
addappid(26801, 1, "78430a8c849a5c4aca3ab55674cddfa8bfb5e59d5662465e2f06dbee0551da39")
addappid(26802, 1, "eb2a65cbd1643952b3470bb2e5d8fd522f5aff6c179c5d99040c2aeb4b64a2b0")
addappid(26804, 1, "b5c43ea96a902fb981bab45352432d19e8bbf6a187980bd06c9b648e44df3e26")
