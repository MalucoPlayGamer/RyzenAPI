-- Lua provided by RyzenAPI
-- Game: addappid(2999810)

-- MAIN APPLICATION
addappid(2999810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999811, 1, "7cc0f37954f37758b0e77bbc29d9274153a714a22b04979df8c2ecd78bde5467")
