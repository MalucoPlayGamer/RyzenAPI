-- Lua provided by SkyAPI 
-- Game: The Mythical City 3
addappid(2999810)
addappid(2999811, 1, "7cc0f37954f37758b0e77bbc29d9274153a714a22b04979df8c2ecd78bde5467")
