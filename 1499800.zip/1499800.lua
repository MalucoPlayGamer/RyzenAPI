-- Lua provided by RyzenAPI
-- Game: Game: Geometric Sniper - Blood in Paris

-- MAIN APPLICATION
addappid(1499800)
addappid(1584380)
-- Game: addappid(1499800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499801, 1, "45a825356343f842ab5a8f8a565fea77913c8e606474a8094e1e0d865cf65c53")
