-- Lua provided by SkyAPI 
-- Game: Geometric Sniper - Blood in Paris
addappid(1499800)
addappid(1499801, 1, "45a825356343f842ab5a8f8a565fea77913c8e606474a8094e1e0d865cf65c53")
addappid(1584380)
