-- Lua provided by RyzenAPI
-- Game: Das Balkonzimmer

-- MAIN APPLICATION
addappid(1472740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472741, 1, "ce9eb9af412b651da387a436d15012c65ee6723eaf06b2eead41304c4eb58bc3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
