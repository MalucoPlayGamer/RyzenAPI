-- Lua provided by RyzenAPI
-- Game: Das Balkonzimmer

-- MAIN APPLICATION
addappid(1472740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472741, 1, "ce9eb9af412b651da387a436d15012c65ee6723eaf06b2eead41304c4eb58bc3")
