-- Lua provided by RyzenAPI
-- Game: Camera Obscura Soundtrack

-- MAIN APPLICATION
addappid(343300)

-- MAIN APP DEPOTS / PACKAGES
addappid(343300,0,"8c37f7854949261586865d2c99466e6e9a764ab256ea8c06463624b5d9fe5e0b")

