-- Lua provided by RyzenAPI 
-- Game: METAL DOGS Soundtrack
addappid(1958380)
addappid(1958381, 1, "56ea011e557f9d46e6cfbd5da9b4d37fed4a3ab26bfbccc1dfc18e4f51cb9ddd")
