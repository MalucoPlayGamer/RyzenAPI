-- Lua provided by RyzenAPI
-- Game: Coral Island

-- MAIN APPLICATION
addappid(1158160)
addappid(2561700)
addappid(2626420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1158161, 1, "e9303b2124c42a0c9cfc882e92469d8ceb392056ec283045ac876c31df4f5e65")
addappid(2273380, 0, "f2946bf1df6964993d9597e6f2ac42e9aca3ef22d2f7c7145c3823b241966bf2")
addappid(2471180, 0, "61aa13efb38e3f9ffaf22c018bde687a97b95b559d21406a6bbc47da860be1ab")
addappid(2537800, 0, "2c18bb7df0d4f51d0d81f95eefaa22e3966f628e7f4defbc9d7d1978476a8b0b")
