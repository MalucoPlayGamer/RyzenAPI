-- Lua provided by RyzenAPI
-- Game: 7'scarlet

-- MAIN APPLICATION
addappid(839450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(839451, 1, "9caab3ef346d3443dd237b451b7ee7b5fe87a8ecdb5426ff9c6de2e4f7450f45")
addappid(839452, 1, "77a8cf349b65e89ef84eaaabe481127a08d7d5e8f4ed455861b68e618cf12ffc")

