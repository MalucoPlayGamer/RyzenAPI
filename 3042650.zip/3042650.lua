-- Lua provided by RyzenAPI
-- Game: Race Max Pro

-- MAIN APPLICATION
addappid(3042650)
