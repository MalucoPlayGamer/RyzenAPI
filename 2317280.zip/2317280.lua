-- Lua provided by RyzenAPI
-- Game: Game: My Familiar Demo

-- MAIN APPLICATION
addappid(2317280)
-- Game: addappid(2317280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317281, 1, "7ad70f6fe65008f3d979db39e257dd93648e427a09ebcfacfaab2533a425e3e4")
