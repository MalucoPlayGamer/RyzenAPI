-- Lua provided by RyzenAPI
-- Game: AppID 491030

-- MAIN APPLICATION
addappid(491030)
-- Game: addappid(491030)

-- MAIN APP DEPOTS / PACKAGES
addappid(491031, 1, "6475dc3528d6b86d9c0107a9e7b7ef039b88e0cb54e3b58ef0a85bd836e92580")
