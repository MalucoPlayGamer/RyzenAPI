-- Lua provided by RyzenAPI
-- Game: Useless Princess and the Village Renovation

-- MAIN APPLICATION
addappid(3455450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3455453,0,"a131d32d7704edab5bd7bddecbe83e35e9ea764d0b6be6e8cca726d20b00c63d")
addappid(3455454,0,"e3b4fb7a16fbce824888c566c8e67d00bdc4510d970d96ab78b59db83832ba8c")
