-- Lua provided by RyzenAPI
-- Game: addappid(2711030)

-- MAIN APPLICATION
addappid(2711030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711031, 1, "0f306d09a4ddc220d66412aeecb4ae31445760a1dd1f8132a821f67a5dda744f")
