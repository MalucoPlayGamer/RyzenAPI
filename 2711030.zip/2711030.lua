-- Lua provided by RyzenAPI
-- Game: Sugardew Island - Your cozy farm shop

-- MAIN APPLICATION
addappid(2711030)
addappid(3494110)
addappid(3954650)
addappid(3954660)
addappid(3954670)
addappid(3954680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711031,0,"0f306d09a4ddc220d66412aeecb4ae31445760a1dd1f8132a821f67a5dda744f")

