-- Lua provided by RyzenAPI
-- Game: The Seven Realms - Realm 1: Official Walkthrough

-- MAIN APPLICATION
addappid(2211370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211370,0,"b974e0ecedebc8a7321784754406ba87c1892a51e2183d6962dc3aea8c58ff00")
