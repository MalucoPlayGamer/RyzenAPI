-- Lua provided by RyzenAPI
-- Game: RX squad

-- MAIN APPLICATION
addappid(494120)

-- MAIN APP DEPOTS / PACKAGES
addappid(494121, 1, "7263efffa2d761867e46584969a92897993e4f1085e1ac00e4829dd7073dfba6")

