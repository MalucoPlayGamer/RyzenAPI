-- Lua provided by RyzenAPI
-- Game: 1342580

-- MAIN APPLICATION
addappid(1342580)
-- Game: addappid(1342580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342581, 1, "1cbde28bbba1f4310adca4749bab9b204f6e99aa753a5d7e8123c79252e56c1d")
addappid(1342582, 1, "0f4a3b6734db42c9dea352a6119a240471645399fd54569e3e2ec2288e81adf9")
