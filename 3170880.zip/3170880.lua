-- Lua provided by RyzenAPI
-- Game: MOBA Dodge Trainer

-- MAIN APPLICATION
addappid(3170880)
-- Game: addappid(3170880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170881, 1, "d29dac3a10518f7118c6302e23712d9ea0648bddcb696bb966af0a24793b96c3")
