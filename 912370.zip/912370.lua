-- Lua provided by RyzenAPI
-- Game: Mahjong Club

-- MAIN APPLICATION
addappid(912370)

-- MAIN APP DEPOTS / PACKAGES
addappid(912371, 1, "be71601713eb3e5423317a36466ad8b4304ab7f92e30436d0107826edfcb7c05")
addappid(912372, 1, "17583baafa36382a9322726261f34c0ce78c7cf4b7b6a828f215b32daaecf1bf")

