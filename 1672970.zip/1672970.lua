-- Lua provided by RyzenAPI
-- Game: Minecraft Dungeons

-- MAIN APPLICATION
addappid(1672970)
addappid(1776550)
addappid(1850660)
addappid(1979530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672971, 1, "b42295e44d98b2ed35338c9f96b4c65ad99a839023e9e4ddef8e19ddc7addac4")
addappid(1726570, 0, "0e89af5042b93fdac6bf07b8155a9addf8bc19a556fed00a326ece6e7c9e7a14")
