-- Lua provided by RyzenAPI
-- Game: Minecraft Dungeons

-- MAIN APPLICATION
addappid(1672970)
addappid(1672980)
addappid(1672981)
addappid(1672982)
addappid(1672983)
addappid(1672984)
addappid(1672985)
addappid(1672986)
addappid(1776550)
addappid(1850660)
addappid(1979530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1672971, 1, "b42295e44d98b2ed35338c9f96b4c65ad99a839023e9e4ddef8e19ddc7addac4")
addappid(1726570, 0, "0e89af5042b93fdac6bf07b8155a9addf8bc19a556fed00a326ece6e7c9e7a14")

