-- Lua provided by RyzenAPI
-- Game: RetroArch - Handy

-- MAIN APPLICATION
addappid(2062460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062461, 1, "1c94ea0786940ca66fa8aa06ffefba29af101415f2795ab0b9c7e6eed597c03f")
addappid(2062462, 1, "eade42475b0c4d0ae993156610186f72ec149a73879615c5a5c544f4e140f8db")

