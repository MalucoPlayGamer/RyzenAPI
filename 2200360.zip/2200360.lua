-- Lua provided by RyzenAPI
-- Game: Trap of MUSK:Arabia Night

-- MAIN APPLICATION
addappid(2200360)
-- Game: addappid(2200360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200361, 1, "9fe0668daf4925abc254ff2a05edd8ac6769de15ec8c99e31c59e7f73e139e2a")
