-- Lua provided by SkyAPI 
-- Game: 101 Cats
addappid(2775180)
addappid(2775181, 1, "7cd64a52a73333adf1ed2f588526e5003643ec9de71385bf314254d5200c2f04")
