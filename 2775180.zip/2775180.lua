-- Lua provided by RyzenAPI
-- Game: 101 Cats

-- MAIN APPLICATION
addappid(2775180)
-- Game: addappid(2775180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775181, 1, "7cd64a52a73333adf1ed2f588526e5003643ec9de71385bf314254d5200c2f04")
