-- Lua provided by RyzenAPI
-- Game: 1054590

-- MAIN APPLICATION
addappid(1054590)
-- Game: addappid(1054590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054591, 1, "86c854a982cdebdfc38df6b75fd6431c348ecc656f38797b939c80b9d70a1013")
