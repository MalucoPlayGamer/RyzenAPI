-- Lua provided by RyzenAPI
-- Game: Race Track Builder

-- MAIN APPLICATION
addappid(388980)

-- MAIN APP DEPOTS / PACKAGES
addappid(388981, 1, "b254c2a807e4c68fac47f91d74e7788f884eb4781862c65e0765bdaa6956e5f0")
addappid(388983, 1, "30128acac011e801d17e21018ca0e1c8c65d468231736e64310b188aab7d84cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
