-- Lua provided by RyzenAPI
-- Game: Halloween Chronicles: Evil Behind a Mask Collector's Edition

-- MAIN APPLICATION
addappid(1181910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181911, 1, "8b7a1c030f673166878af1d0a654697d58790dd0b3a858169e99b98b81c754e0")

