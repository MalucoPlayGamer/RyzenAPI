-- Lua provided by RyzenAPI
-- Game: Christmas Puzzle 3

-- MAIN APPLICATION
addappid(759650)

-- MAIN APP DEPOTS / PACKAGES
addappid(759651,0,"6c46edd12e9178ede39a604858f936dc16b3879df39adf940d3d40a3509ef630")

