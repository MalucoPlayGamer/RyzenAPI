-- Lua provided by RyzenAPI
-- Game: AppID 588870

-- MAIN APPLICATION
addappid(588870)
-- Game: addappid(588870)

-- MAIN APP DEPOTS / PACKAGES
addappid(588871, 1, "8a7c209fa626ae0cf15dae04fe8c8516220031c6ad4ed7d938a3922a1d077f42")
