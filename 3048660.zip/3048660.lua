-- Lua provided by RyzenAPI
-- Game: addappid(3048660)

-- MAIN APPLICATION
addappid(3048660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048661, 1, "1d714d70ad4f5946e357c2cfb84c31ff09cd0c2e63327185202dff2aa5757fab")
