-- Lua provided by RyzenAPI
-- Game: Game: Aquanox Deep Descent

-- MAIN APPLICATION
addappid(254370)
-- Game: addappid(254370)

-- MAIN APP DEPOTS / PACKAGES
addappid(254371, 1, "c271148d770f11cf880b81b0083e2cff0096bfbfc7c30b50bd249792cdea156f")
