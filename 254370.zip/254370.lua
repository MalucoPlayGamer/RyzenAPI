-- Lua provided by RyzenAPI
-- Game: Aquanox Deep Descent

-- MAIN APPLICATION
addappid(254370)
addappid(873780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(254371, 1, "c271148d770f11cf880b81b0083e2cff0096bfbfc7c30b50bd249792cdea156f")

