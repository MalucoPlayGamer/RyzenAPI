-- Lua provided by SkyAPI 
-- Game: The Two of Us
addappid(1820170)
addappid(1820171, 1, "bf0913182ef9dbf0328a8425672d54c85f2e5b3595821cefadae830838e5427c")
