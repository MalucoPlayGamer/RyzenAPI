-- Lua provided by RyzenAPI
-- Game: addappid(2487440)

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2487440)
addappid(2487441)
addappid(2487448)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487447,0,"13ced551c5994f9d6b8ead260d5c498f0cbc9e80ca4e128d30ad1cfc52c91145")
