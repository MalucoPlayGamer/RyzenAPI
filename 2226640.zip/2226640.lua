-- Lua provided by RyzenAPI
-- Game: Game: AppID 2226640

-- MAIN APPLICATION
addappid(2226640)
-- Game: addappid(2226640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226641, 1, "fb85f74908c407499cf9cf194a033964c94212dec4895df3a3fc78940227529d")
