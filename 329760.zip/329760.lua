-- Lua provided by RyzenAPI
-- Game: 329760

-- MAIN APPLICATION
addappid(329760)
-- Game: addappid(329760)

-- MAIN APP DEPOTS / PACKAGES
addappid(329760,0,"cc761dba7ec1c170b6b55d29ea4d6f36ff76beca3cadcbdf4285ba78a80dcffe")
