-- Lua provided by RyzenAPI
-- Game: Enoch: Underground

-- MAIN APPLICATION
addappid(703400)

-- MAIN APP DEPOTS / PACKAGES
addappid(703401,0,"c8b87b95f9f22f94c82dbbae39391bfe54154cdb02c23eee4edb69bfd8593c10")

