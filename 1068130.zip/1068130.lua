-- Lua provided by RyzenAPI
-- Game: 1068130

-- MAIN APPLICATION
addappid(1068130)
-- Game: addappid(1068130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068131, 1, "dbfdaa5f7f25864aa6540bfc9750cbcd1ecace754c90dca34fd8800010131124")
