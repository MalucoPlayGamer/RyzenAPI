-- Lua provided by SkyAPI 
-- Game: AppID 1068130
addappid(1068130)
addappid(1068131, 1, "dbfdaa5f7f25864aa6540bfc9750cbcd1ecace754c90dca34fd8800010131124")
