-- Lua provided by RyzenAPI
-- Game: 364390

-- MAIN APPLICATION
addappid(364390)
-- Game: addappid(364390)

-- MAIN APP DEPOTS / PACKAGES
addappid(364391, 1, "151b6f8710a16b058cfb070e3ef56bf176411489dea8aed917f3e63c20611c96")
