-- Lua provided by RyzenAPI
-- Game: Darkest Abyss Demo

-- MAIN APPLICATION
addappid(2638090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638091, 1, "0171f043133037c89012864d3fe275455700d4f56cec2fff807a81dad851aaa2")

