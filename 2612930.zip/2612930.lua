-- Lua provided by RyzenAPI
-- Game: Agatha Christie - Murder on the Orient Express Demo

-- MAIN APPLICATION
addappid(2612930)
-- Game: addappid(2612930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612931, 1, "9c2d1dd85e810b6c895519b87484ad6befc81ccc4c03676409283c67f880deb2")
