-- Lua provided by RyzenAPI
-- Game: Nowhere Near

-- MAIN APPLICATION
addappid(2976170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976171, 1, "bed53b5eff8b9a37a37fe875c1b869038756a9b5a8a22a0df5b70474ddc6f222")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
