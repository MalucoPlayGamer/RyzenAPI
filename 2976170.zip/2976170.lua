-- Lua provided by RyzenAPI
-- Game: 2976170

-- MAIN APPLICATION
addappid(2976170)
-- Game: addappid(2976170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976171, 1, "bed53b5eff8b9a37a37fe875c1b869038756a9b5a8a22a0df5b70474ddc6f222")
