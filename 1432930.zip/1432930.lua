-- Lua provided by RyzenAPI
-- Game: 1432930

-- MAIN APPLICATION
addappid(1432930)
-- Game: addappid(1432930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432931, 1, "eb7a8035ccf83592a4dd3e3c38f96f135c129629e5c91e5d1fd62c3684788ea5")
