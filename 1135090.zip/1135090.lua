-- Lua provided by RyzenAPI
-- Game: dino game

-- MAIN APPLICATION
addappid(1135090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1135091, 1, "047d8225e128b675e6c3ca36b4a1b9adfe09dab41f1484c15410391d4e55e786")
addappid(1135092, 1, "dea73ea0e28da01dd343e2b96cd77428aee27cf00d570e6cddb703e853f5f62e")

