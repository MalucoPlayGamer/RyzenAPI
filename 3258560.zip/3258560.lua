-- Lua provided by RyzenAPI
-- Game: Created: August 06, 2026 at 04:40:01 EDT

-- MAIN APPLICATION
addappid(3258560) -- 我不是魔王

-- MAIN APP DEPOTS / PACKAGES
addappid(3258561, 1, "28db195283cf08c37cb680cde5aa6881366edef903967a1b3515c88d9e7599f8") -- Depot 3258561
addappid(3258562, 1, "9ff76b0b370ecfaab48d56fb4a5f5b99254894ac796744cc1dac4789f020c6e2") -- Depot 3258562
addappid(3258563, 1, "cadad8473195b0de7c0e84b8e8103783f614bbbddf0cdc6480ac82d77502e056") -- Depot 3258563

