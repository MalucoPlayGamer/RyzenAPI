-- 3258560's Lua and Manifest Created by Hubcap Manifest
-- 我不是魔王
-- Created: August 06, 2026 at 04:40:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3258560) -- 我不是魔王
-- MAIN APP DEPOTS
addappid(3258561, 1, "28db195283cf08c37cb680cde5aa6881366edef903967a1b3515c88d9e7599f8") -- Depot 3258561
setManifestid(3258561, "6909628310637401506", 490602930)
addappid(3258562, 1, "9ff76b0b370ecfaab48d56fb4a5f5b99254894ac796744cc1dac4789f020c6e2") -- Depot 3258562
setManifestid(3258562, "283069706600692997", 490381045)
addappid(3258563, 1, "cadad8473195b0de7c0e84b8e8103783f614bbbddf0cdc6480ac82d77502e056") -- Depot 3258563
setManifestid(3258563, "540431657039199022", 455664411)