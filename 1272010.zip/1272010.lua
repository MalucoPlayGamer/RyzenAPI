-- Lua provided by RyzenAPI
-- Game: Destroyer: The U-Boat Hunter

-- MAIN APPLICATION
addappid(1272010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272011, 1, "2b204d83fff20d06c9b8a25156c60723c84b9422368c1d25e2683d0502c87abb")
addappid(1272012, 1, "514d448b02bdc9421c0431403f7b11360b07b820321054758277ce6cee39c325")
addappid(1272013, 1, "d32f28ab57f152b7fbef2d286f099b1b50667a90c4157de800f65c2a8edb2fb5")
addappid(2153660, 0, "5ab8fbd24ce978b9f4589fa67187a50003da3c280dabe165b3b027ec04d9d199")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
