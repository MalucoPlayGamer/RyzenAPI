-- Lua provided by RyzenAPI
-- Game: Skopje '83 Demo

-- MAIN APPLICATION
addappid(3012340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012341, 1, "0b75678c3b2e84b1ef580f4810f546f644aa23dcbee5ef43e8b22ced9b773b4a")
