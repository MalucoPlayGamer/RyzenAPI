-- Lua provided by RyzenAPI
-- Game: Mr. Rabbit Magic Show - Supporter Pack

-- MAIN APPLICATION
addappid(3701380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3701380,0,"74679874ade7f2bd48189eb7795309012c23556a44c71f2c1ffb50ef286a758a")
addappid(3701383,0,"5ce97a657113392e60960ca85a3321023a7764dbbddac67b9b10e8fbcda5f111")

