-- Lua provided by RyzenAPI
-- Game: addappid(963400)

-- MAIN APPLICATION
addappid(963400)

-- MAIN APP DEPOTS / PACKAGES
addappid(963401, 1, "0dcdc901fa060ef40b61347f16f0043463695dfac5e31cdec9383625050a9b54")
