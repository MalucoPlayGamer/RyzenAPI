-- Lua provided by RyzenAPI
-- Game: Game: AppID 750050

-- MAIN APPLICATION
addappid(750050)
-- Game: addappid(750050)

-- MAIN APP DEPOTS / PACKAGES
addappid(750051, 1, "2aaf38034ad4802d579bbf8a8bd94e39c23d2c0076d7be1aab00025d0c357604")
