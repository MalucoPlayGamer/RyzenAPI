-- Lua provided by RyzenAPI
-- Game: Diesel Brothers: Truck Building Simulator

-- MAIN APPLICATION
addappid(750050)
addappid(1045290)
addappid(1045291)
addappid(1046690)

-- MAIN APP DEPOTS / PACKAGES
addappid(750050,0,"c13c30b4913a16e23dcbe5148ab923acd4e40618a81511cdfec1a9d8ec6cd21d")
addappid(750051,0,"2aaf38034ad4802d579bbf8a8bd94e39c23d2c0076d7be1aab00025d0c357604")
addappid(1045290,0,"65d0cef71b2232c62d23a63236472ebf537a6880d2b4dca4d8f42eec80bfcf91")
addappid(1045291,0,"f14145fa899c5d9d138083b70b4519a0925e9385d85628a4a1f384651b80c94e")
addappid(1046690,0,"9341ed918c939ad6bc4a698c3fd769713d03a59a101ff3688180ce5d3fc3096d")

