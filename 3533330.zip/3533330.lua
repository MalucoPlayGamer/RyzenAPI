-- Lua provided by RyzenAPI
-- Game: addappid(3533330)

-- MAIN APPLICATION
addappid(3533330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3533331, 1, "5a9996b7f3081d68b19b470439c38a4859ebbbd50db7f66baabb82c4e55182a1")
