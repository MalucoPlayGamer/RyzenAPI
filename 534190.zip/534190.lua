-- Lua provided by RyzenAPI
-- Game: Blink the Bulb

-- MAIN APPLICATION
addappid(534190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(534191, 1, "3cf1ee3fbbe3d9b0d1f6ddb84223dc22ffcc85d5391a4a463f8499084eda6075")

