-- Lua provided by RyzenAPI
-- Game: Wobbly Life

-- MAIN APPLICATION
addappid(1211020)
-- Game: addappid(1211020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211023,0,"7b55e9caab84de4a05399572557f58ecac6abd4d5b31564b0d5356ac6e79807b")
