-- Lua provided by RyzenAPI 
-- Game: Catch them!
addappid(1862500)
addappid(1862501, 1, "ebe30634dc06820ebb5bfba126d9b65a997ca6346679220ceb409a3bfb439d35")
