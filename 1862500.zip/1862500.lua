-- Lua provided by RyzenAPI
-- Game: 1862500

-- MAIN APPLICATION
addappid(1862500)
-- Game: addappid(1862500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862501, 1, "ebe30634dc06820ebb5bfba126d9b65a997ca6346679220ceb409a3bfb439d35")
