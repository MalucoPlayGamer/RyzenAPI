-- Lua provided by RyzenAPI
-- Game: Type Your Fate

-- MAIN APPLICATION
addappid(2654160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654161, 1, "a00642ae00fcc3066caf90b042bbdbce0740adf684fc69789e13f2b5c1886973")

