-- Lua provided by RyzenAPI
-- Game: Bot Maker For Discord

-- MAIN APPLICATION
addappid(2592170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2592171, 1, "502ac6f41102a44486a938565251b4cfec23c49c691a0a6a34d25d1b38af47ca")

