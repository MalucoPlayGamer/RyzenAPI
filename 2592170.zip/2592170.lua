-- Lua provided by RyzenAPI
-- Game: Bot Maker For Discord

-- MAIN APPLICATION
addappid(2592170)
-- Game: addappid(2592170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2592171, 1, "502ac6f41102a44486a938565251b4cfec23c49c691a0a6a34d25d1b38af47ca")
