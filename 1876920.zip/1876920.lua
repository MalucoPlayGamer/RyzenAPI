-- Lua provided by RyzenAPI
-- Game: 1876920

-- MAIN APPLICATION
addappid(1876920)
-- Game: addappid(1876920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876921, 1, "03c21c200c2b243d2288fcfb17af80aa67a5daba39f4279c2b24b20912698f59")
