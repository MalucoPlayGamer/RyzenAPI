-- Lua provided by RyzenAPI
-- Game: Destroy All Humans!

-- MAIN APPLICATION
addappid(803330)
addappid(1254570)

-- MAIN APP DEPOTS / PACKAGES
addappid(803331, 1, "8548ae2dc9ed3193e4ebb386ea566523714b8ca47ab85919c5b0d58b8aa94c02")
addappid(803332, 1, "69762cce364c47101a23c7cc4fe695d0f3e73acf90abb0a8d4891a52bfa596e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
