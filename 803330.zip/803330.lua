-- Lua provided by RyzenAPI
-- Game: Destroy All Humans!

-- MAIN APPLICATION
addappid(803330)
addappid(1254570)
-- Game: addappid(803330)

-- MAIN APP DEPOTS / PACKAGES
addappid(803331, 1, "8548ae2dc9ed3193e4ebb386ea566523714b8ca47ab85919c5b0d58b8aa94c02")
addappid(803332, 1, "69762cce364c47101a23c7cc4fe695d0f3e73acf90abb0a8d4891a52bfa596e0")
