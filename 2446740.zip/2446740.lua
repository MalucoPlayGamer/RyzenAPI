-- Lua provided by RyzenAPI 
-- Game: X-Force Under Attack
addappid(2446740)
addappid(2446741, 1, "e8880521c86b5f71d14135a966316ed74d192928e9a355533fa708b6d988234a")
