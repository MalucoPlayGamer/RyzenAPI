-- Lua provided by RyzenAPI
-- Game: AppID 394760

-- MAIN APPLICATION
addappid(394760)

-- MAIN APP DEPOTS / PACKAGES
addappid(394761, 1, "68ce61235f41e0bafc878e571bfc34e8b04847d1abc5b326e2754888619d21a6")
addappid(394762, 1, "4ceeea45b1ec327c63fa503debb1969546348047c3e261057cbff4d2b9582923")
addappid(394769, 1, "8276e293bd9fed686912c38f4b0df4e98d0de1439c3dd900c45ffb8f09af3954")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1042730)
addappid(1042731)
