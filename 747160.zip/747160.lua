-- Lua provided by RyzenAPI
-- Game: addappid(747160)

-- MAIN APPLICATION
addappid(747160)

-- MAIN APP DEPOTS / PACKAGES
addappid(747161, 1, "b9e4774214776e408836b6d2a96aa9c5411b8bb80eaa490e20d55ec24c8d71c1")
