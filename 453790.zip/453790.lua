-- Lua provided by RyzenAPI
-- Game: Game: Candice DeBébé's Incredibly Trick Lifestyle

-- MAIN APPLICATION
addappid(453790)
-- Game: addappid(453790)

-- MAIN APP DEPOTS / PACKAGES
addappid(453791, 1, "3e43e32218032e02242ab1b626429926a5a145638973b0992ae016426a62ad29")
addappid(453792, 1, "0ec4b2bfad20dd0bdb1a8e908b85422e6c4d0d7ff5e854f07e2a5f688dc1b14a")
addappid(453793, 1, "a55b67d4651763318f5643918f5704196fd8027f128db4cca1a340fd7a5b1b6d")
addappid(453794, 1, "8059de0604daf7e075f62b32afc248c9ad7c48e3e9403375125ad8103b067710")
