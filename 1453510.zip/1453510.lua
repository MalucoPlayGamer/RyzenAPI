-- Lua provided by RyzenAPI
-- Game: Game: AppID 1453510

-- MAIN APPLICATION
addappid(1453510)
-- Game: addappid(1453510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453511, 1, "981df31aec65f27a16aa21b59565682001cfaa8aff868d81fd41831aed64e2e9")
addappid(1453512, 1, "2d5a2dbf93ddf76cbf016d5c106e8d66f9a5e18209804a13c5b8ebd277613abe")
