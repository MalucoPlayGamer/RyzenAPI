-- Lua provided by RyzenAPI
-- Game: addappid(4121170)

-- MAIN APPLICATION
addappid(4121170)

-- MAIN APP DEPOTS / PACKAGES
addappid(4121171, 1, "039dd5543221c7529bdaf1452fbb32fae552d67e608265c9cf39dc1b787ae6da")
