-- Lua provided by RyzenAPI
-- Game: Sweat Equity

-- MAIN APPLICATION
addappid(4852460) -- Sweat Equity

-- MAIN APP DEPOTS / PACKAGES
addappid(4852461, 1, "877a45c59d0a79ab102d8f17574cce837c490577ec704daa5bd882b91d3602df") -- Depot 4852461

