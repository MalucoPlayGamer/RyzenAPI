-- 4852460's Lua and Manifest Created by Hubcap Manifest
-- Sweat Equity
-- Created: August 15, 2026 at 03:16:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4852460) -- Sweat Equity
-- MAIN APP DEPOTS
addappid(4852461, 1, "877a45c59d0a79ab102d8f17574cce837c490577ec704daa5bd882b91d3602df") -- Depot 4852461
setManifestid(4852461, "2852984716208075253", 1065159384)