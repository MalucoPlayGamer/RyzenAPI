-- Lua provided by RyzenAPI
-- Game: AppID 3792580

-- MAIN APPLICATION
addappid(3792580)
-- Game: addappid(3792580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3792581, 1, "25703a8da541f9aabc2b6eed97f376007aad15edde1077eba0cd07c5940bf0ee")
