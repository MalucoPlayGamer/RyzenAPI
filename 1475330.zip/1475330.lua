-- Lua provided by RyzenAPI
-- Game: Peak Darkness

-- MAIN APPLICATION
addappid(1475330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1475331, 1, "69c2a58e9d40b61059c8d793939bee3a33b755e3c0a7d15502c178846c506382")

