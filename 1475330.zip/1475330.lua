-- Lua provided by SkyAPI 
-- Game: Peak Darkness
addappid(1475330)
addappid(1475331, 1, "69c2a58e9d40b61059c8d793939bee3a33b755e3c0a7d15502c178846c506382")
