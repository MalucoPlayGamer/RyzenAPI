-- Lua provided by RyzenAPI
-- Game: Peak Darkness

-- MAIN APPLICATION
addappid(1475330)
-- Game: addappid(1475330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475331, 1, "69c2a58e9d40b61059c8d793939bee3a33b755e3c0a7d15502c178846c506382")
