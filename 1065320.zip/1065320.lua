-- Lua provided by RyzenAPI
-- Game: Rekt!

-- MAIN APPLICATION
addappid(1065320)
addappid(1344090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065321, 1, "d84893ba345653f5b5415bc9a8437dd130d0f28a087031a92f09db062ed308e8")

