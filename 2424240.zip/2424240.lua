-- Lua provided by SkyAPI 
-- Game: Pudding: Lyre Knight
addappid(2424240)
addappid(2424241, 1, "8f477735defc67eaac9089afbb2fc09dc24325caf092df06e8bca0a0b42a2834")
addappid(2424242, 1, "210ea52c602677ae8b14596b5f48c6dd9ed600700a3927b41bfeb999c897cd68")
