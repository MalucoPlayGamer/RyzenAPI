-- Lua provided by SkyAPI 
-- Game: Perfect Jump
addappid(2027220)
addappid(2027221, 1, "cb045fb5acdf176854bbd6befc3a50050e7f17c02f6252b2c2362d2d08681381")
