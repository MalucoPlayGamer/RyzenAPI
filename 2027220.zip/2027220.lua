-- Lua provided by RyzenAPI
-- Game: Perfect Jump

-- MAIN APPLICATION
addappid(2027220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027221, 1, "cb045fb5acdf176854bbd6befc3a50050e7f17c02f6252b2c2362d2d08681381")
