-- Lua provided by RyzenAPI
-- Game: Taiwan Love Story⁵ Demo

-- MAIN APPLICATION
addappid(3044760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044761, 1, "9255c287c06e02d6d2ae424221b8291c831a513ca4c38a828bb95d03f2a91c33")

