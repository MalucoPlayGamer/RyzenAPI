-- Lua provided by RyzenAPI
-- Game: Slobbish Dragon Princess LOVE+PLUS

-- MAIN APPLICATION
addappid(1620110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620111, 1, "4d9c95ea6d15e3fa227d17448048a5fc33336c5374b51482d5dc94925d7a15ef")
