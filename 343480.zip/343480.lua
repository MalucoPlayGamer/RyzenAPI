-- Lua provided by RyzenAPI
-- Game: Typing of the Dead: Workshop Tool

-- MAIN APPLICATION
addappid(343480)

-- MAIN APP DEPOTS / PACKAGES
addappid(343481, 1, "b8471be657666cdb7db34e72e55d61fea7006ef5f767ec2e3667584786d17a1d")
