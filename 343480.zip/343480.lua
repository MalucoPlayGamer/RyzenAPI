-- Lua provided by RyzenAPI 
-- Game: AppID 343480
addappid(343480)
addappid(343481, 1, "b8471be657666cdb7db34e72e55d61fea7006ef5f767ec2e3667584786d17a1d")
