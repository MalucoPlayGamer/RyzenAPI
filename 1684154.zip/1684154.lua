-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9 Empires - School Gymnasium

-- MAIN APPLICATION
addappid(1684154)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684154,0,"86d44e10729bb74a9c4ace48ffc4e3a3ef264e4867250f65b9f7f40deff8151e")

