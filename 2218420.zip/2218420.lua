-- Lua provided by RyzenAPI
-- Game: addappid(2218420)

-- MAIN APPLICATION
addappid(2218420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218421, 1, "86766cc799a7ff2e8c6aa9255563b0e098673c358346dd09eef8c3fe5974b197")
