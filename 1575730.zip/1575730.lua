-- Lua provided by RyzenAPI
-- Game: Game: Descending I - House of Nightmares

-- MAIN APPLICATION
addappid(1575730)
-- Game: addappid(1575730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575731, 1, "77b341e2cc72fc5e9f712e380e7ca73d27441af18320b6fb2a6a4a01b3217723")
