-- Lua provided by RyzenAPI
-- Game: Artifact Seeker: Resurrection Demo

-- MAIN APPLICATION
addappid(3114330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114331, 1, "863de24dfc9181d11947cf07ac8a91b39fb37c4ed296e0420699898ba4303ec6")

