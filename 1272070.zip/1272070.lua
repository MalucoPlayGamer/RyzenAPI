-- Lua provided by RyzenAPI
-- Game: Silicon Dreams  |  cyberpunk interrogation

-- MAIN APPLICATION
addappid(1272070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272071, 1, "fb2f519625bef7b4fefbcf333596847b575645b6843758ff6c74dadfc97bd207")
addappid(1272072, 1, "398af9b58d55332cc78ed2fd8f4c55e12b54fbc1614bbeb54007aaee38e1ad3c")
addappid(1272073, 1, "e7500330809400dcd44dd98c901a227e38a6b4508fde518e2da5a80afafc5390")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
