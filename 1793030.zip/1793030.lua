-- Lua provided by SkyAPI 
-- Game: Romancing SaGa -Minstrel Song- Remastered
addappid(1793030)
addappid(1793031, 1, "c8b10e2a8d1ebbb1310fd527ec21aafb5aa447f11185e34154837fd6d52d51d6")
addappid(2148710, 0, "333a7b833aec4b3c75c74b9069c18963a8c24446082b30c8cd4e6f655222135b")
