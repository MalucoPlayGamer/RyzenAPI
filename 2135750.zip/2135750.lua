-- Lua provided by SkyAPI 
-- Game: PixageFX Demo
addappid(2135750)
addappid(2135751, 1, "b0e1837856e5a5f11ff5130e80f2ce95bcd278ac3988193eef310c60c794da0b")
