-- Lua provided by RyzenAPI
-- Game: AppID 458450

-- MAIN APPLICATION
addappid(458450)

-- MAIN APP DEPOTS / PACKAGES
addappid(458451, 1, "ba9bdc2b555513cefc1fe00476865b18b8a41f4650831b4a36e9fec31b451d84")

