-- Lua provided by RyzenAPI
-- Game: OrbusVR: Reborn

-- MAIN APPLICATION
addappid(746930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(746931, 1, "29e028b4b28a39737487f1e97e2c91ea8c74cdbaf8e8928b39a1b226fed7c6c3")

