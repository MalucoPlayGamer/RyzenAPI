-- Lua provided by RyzenAPI
-- Game: addappid(746930)

-- MAIN APPLICATION
addappid(746930)

-- MAIN APP DEPOTS / PACKAGES
addappid(746931, 1, "29e028b4b28a39737487f1e97e2c91ea8c74cdbaf8e8928b39a1b226fed7c6c3")
