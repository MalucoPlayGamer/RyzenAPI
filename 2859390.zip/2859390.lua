-- Lua provided by RyzenAPI
-- Game: Game: AppID 2859390

-- MAIN APPLICATION
addappid(2859390)
-- Game: addappid(2859390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859391, 1, "f1a0239daf48c3b38078c92d85db817f0aa01bcce368a39f7e44d2b0e7cb23de")
