-- Lua provided by RyzenAPI 
-- Game: SEX Hospital 💦
addappid(3238270)
addappid(3238271, 1, "e4817a99996ac68a9bdc4bc9b9d809be2ed9db91c18ef331ee9bb914762d96ae")
