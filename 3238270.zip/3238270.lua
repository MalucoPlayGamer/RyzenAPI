-- Lua provided by RyzenAPI
-- Game: SEX Hospital 💦

-- MAIN APPLICATION
addappid(3238270)
-- Game: addappid(3238270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3238271, 1, "e4817a99996ac68a9bdc4bc9b9d809be2ed9db91c18ef331ee9bb914762d96ae")
