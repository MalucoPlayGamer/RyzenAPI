-- Lua provided by RyzenAPI 
-- Game: AppID 1013540
addappid(1013540)
addappid(1013541, 1, "68a9f5033442626ccd2c4329e03cc2e791781329e391cfc4890da9e2fb693efe")
addappid(1013542, 1, "0c7769601554b4246c58180146a6d6e22c478f5cc326de9fd4cf98bedbd192d0")
