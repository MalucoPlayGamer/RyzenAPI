-- Lua provided by RyzenAPI
-- Game: AppID 1013540

-- MAIN APPLICATION
addappid(1013540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1013541, 1, "68a9f5033442626ccd2c4329e03cc2e791781329e391cfc4890da9e2fb693efe")
addappid(1013542, 1, "0c7769601554b4246c58180146a6d6e22c478f5cc326de9fd4cf98bedbd192d0")

