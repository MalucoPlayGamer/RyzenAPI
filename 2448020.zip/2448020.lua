-- Lua provided by SkyAPI 
-- Game: Yooka-Replaylee
addappid(2448020)
addappid(2448021, 1, "0087364299b86dce13084a6e34fc1292ca9587691740ac9b8b93fe737b8af5b0")
