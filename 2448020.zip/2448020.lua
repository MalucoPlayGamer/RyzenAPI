-- Lua provided by RyzenAPI
-- Game: Yooka-Replaylee

-- MAIN APPLICATION
addappid(2448020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448021, 1, "0087364299b86dce13084a6e34fc1292ca9587691740ac9b8b93fe737b8af5b0")
