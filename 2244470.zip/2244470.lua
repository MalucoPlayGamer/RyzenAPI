-- Lua provided by RyzenAPI
-- Game: Train Valley World

-- MAIN APPLICATION
addappid(2244470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244471, 1, "6f509a01137945096ec5fcf77eb769814e0054cfe4cc2f535e5cce54a2081dea")

