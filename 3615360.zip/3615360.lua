-- Lua provided by RyzenAPI
-- Game: Your StepSister

-- MAIN APPLICATION
addappid(3615360)
-- Game: addappid(3615360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3615361, 1, "d90d490cb9ee756daa844c05fd5e799653136fa7b20fa7428da7e3472af26989")
