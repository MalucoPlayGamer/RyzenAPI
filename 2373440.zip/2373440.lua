-- Lua provided by RyzenAPI
-- Game: Miners Settlement

-- MAIN APPLICATION
addappid(2373440)
-- Game: addappid(2373440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2373441, 1, "3c255a18d4c513f7c409a6fa2a322a09ae4d955f1c8a17aa293d875446252578")
