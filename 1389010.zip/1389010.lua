-- Lua provided by RyzenAPI
-- Game: Deathroids

-- MAIN APPLICATION
addappid(1389010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389011, 1, "67675ef9aa88b6ed23e715efedf9e01b3c1647196f777107bb4b0be9f41bcac6")
