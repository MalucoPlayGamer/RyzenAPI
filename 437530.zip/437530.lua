-- Lua provided by RyzenAPI
-- Game: Game: AppID 437530

-- MAIN APPLICATION
addappid(437530)
-- Game: addappid(437530)

-- MAIN APP DEPOTS / PACKAGES
addappid(437531, 1, "94561f8837ff0636981e3bb071c80108e21c703db6957aa72b8bb83be0ed6bbf")
addappid(437532, 1, "ab0f20c49190a8ca5383c36d9369fc96299fd1bf268f48b2f35380ef66f7df24")
