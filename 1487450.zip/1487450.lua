-- Lua provided by RyzenAPI
-- Game: 迷禁 Lost in Abyss

-- MAIN APPLICATION
addappid(1487450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487451, 1, "91752ef28df378f430f6cc5fbc7c425f41e66a3a55cd35275093605fc2432918")
