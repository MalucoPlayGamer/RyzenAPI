-- Lua provided by RyzenAPI
-- Game: Jelly Bubble

-- MAIN APPLICATION
addappid(4741070) --  -
addappid(4885170) --

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3659090, 1, "7b692d4d2861cc002f2bf1f7724fed1942666ff3df83c1d35861b49b65a754f8") -- Jelly Bubble
addappid(3659091, 1, "f073c5c3041f877bb1864e5aa245f42852a2b6865184d225f2e21c11a0234b79") -- Depot 3659091

