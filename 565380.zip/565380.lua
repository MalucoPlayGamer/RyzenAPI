-- Lua provided by RyzenAPI
-- Game: addappid(565380)

-- MAIN APPLICATION
addappid(565380)

-- MAIN APP DEPOTS / PACKAGES
addappid(565381, 1, "75cc0258e77e793a8c0ae1cfd00625da528157992039b0eb0c5be4466b260d01")
