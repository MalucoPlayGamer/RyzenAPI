-- Lua provided by RyzenAPI
-- Game: SIGNALIS

-- MAIN APPLICATION
addappid(1262350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1262351, 1, "854de643819bf303b7475a341b497bcccc2fe1f609f65ccf8b5fb38ce8bd76f8")
