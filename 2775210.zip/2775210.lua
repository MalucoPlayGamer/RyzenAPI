-- Lua provided by RyzenAPI
-- Game: Paragon Pioneers 2 Demo

-- MAIN APPLICATION
addappid(2775210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775212,0,"b9b32a00177e53e4f1e98ee8ab1dd05e5ef9c84d1e19644b7504c0cf16dad821")

