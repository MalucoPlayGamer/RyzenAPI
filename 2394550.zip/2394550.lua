-- Lua provided by RyzenAPI
-- Game: Gangs of Sherwood - Digital Artbook

-- MAIN APPLICATION
addappid(2394550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394550,0,"d030e61ab7e91b7f1c6428c34cd1db216097ce9f60610efcbfb0c50ee4b224cf")
addtoken(2394550,"484090685691247464")

