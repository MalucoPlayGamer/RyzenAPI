-- Lua provided by RyzenAPI
-- Game: President Yukino

-- MAIN APPLICATION
addappid(887530)

-- MAIN APP DEPOTS / PACKAGES
addappid(887531, 1, "d131c33ad8382b1a63a1fefd5cc716109b638328881bdfc85e02ee5d1ef662f4")
addappid(887532, 1, "4ba647821b0dff5ee7d27db99ce6b5840999c5723ceac12203a8657369004d92")
addappid(887533, 1, "0a106eb13604e2d6770b73dbba822b5fa3aae943a56162221b34cee1cd97f6ab")

