-- 4730180's Lua and Manifest Created by Hubcap Manifest
-- Hacker's Journey
-- Created: July 22, 2026 at 08:04:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4730180, 1, "cada6df0c607e51ca948c98ced97ca5904b9d57ddfe26a0405bef76054c46926") -- Hacker's Journey
-- MAIN APP DEPOTS
addappid(4730182, 1, "72037e5c9fb93301e580a2a6adfaac0138899e16e49ccbe60b6f423396214f8b") -- Depot 4730182
setManifestid(4730182, "9149826390034921141", 476697000)
addappid(4730183, 1, "5341fd59b513f6598f738b31b7ced8b05fcae7a5c4a182b05509dec48a4cd6a6") -- Depot 4730183
setManifestid(4730183, "1003811157168067091", 477499052)
addappid(4730184, 1, "c9706778fdc038925cb86e8ea4a957ccd97c43c1210778f52834525f1a54c20c") -- Depot 4730184
setManifestid(4730184, "9011063914774157641", 631528020)