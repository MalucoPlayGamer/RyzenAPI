-- Lua provided by RyzenAPI
-- Game: Zombie Birds First Encounter Halloween

-- MAIN APPLICATION
addappid(521110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(521111, 1, "68b520aa7d6ecbac636be27ac1a3a6815262f2af0b43e8039731d9e51337effa")

