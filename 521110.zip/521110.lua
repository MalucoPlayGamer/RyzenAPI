-- Lua provided by RyzenAPI
-- Game: 521110

-- MAIN APPLICATION
addappid(521110)
-- Game: addappid(521110)

-- MAIN APP DEPOTS / PACKAGES
addappid(521111, 1, "68b520aa7d6ecbac636be27ac1a3a6815262f2af0b43e8039731d9e51337effa")
