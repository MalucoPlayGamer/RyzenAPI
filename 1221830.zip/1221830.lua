-- Lua provided by RyzenAPI
-- Game: 1221830

-- MAIN APPLICATION
addappid(1221830)
-- Game: addappid(1221830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221831, 1, "065884fb3f50ae9996b196a5f9770dfe20fa376a3458ef513e72e84b9ae352b4")
