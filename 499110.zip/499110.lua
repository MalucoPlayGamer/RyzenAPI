-- Lua provided by RyzenAPI
-- Game: Dark Parables: Rise of the Snow Queen Collector's Edition

-- MAIN APPLICATION
addappid(499110)
-- Game: addappid(499110)

-- MAIN APP DEPOTS / PACKAGES
addappid(499111, 1, "bbbacbd5b8eec78621efad8b86dc55055a917bf210e8fdfb167ff6f0354534aa")
