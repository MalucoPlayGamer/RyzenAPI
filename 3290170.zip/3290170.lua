-- Lua provided by RyzenAPI
-- Game: Treasure 'n Trio Demo

-- MAIN APPLICATION
addappid(3290170)
-- Game: addappid(3290170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3290171, 1, "08544adc56367f0aa872019a258f7f32fb5e786b1fb8c18e3749fd9ffc73d20c")
