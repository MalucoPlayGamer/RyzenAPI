-- Lua provided by RyzenAPI
-- Game: Omega Mouse Zero

-- MAIN APPLICATION
addappid(2794470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794471, 1, "33599224907661df01ab720cf2f3d9c207a33e0d9678ced2524381127ee21fa7")

