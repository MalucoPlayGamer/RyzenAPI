-- Lua provided by RyzenAPI
-- Game: addappid(1727890)

-- MAIN APPLICATION
addappid(1727890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727891, 1, "f5065452e3d4eb17ee84e127fecb8e117b3d191c271ef2733cf1b1ece7cfadd8")
