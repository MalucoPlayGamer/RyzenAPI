-- Lua provided by RyzenAPI 
-- Game: Koropokkur in Love ~A Little Fairy’s Tale~
addappid(915560)
addappid(915561, 1, "9c113580688fcac1c3032a6300739b395020baf8bb87410917390d9765c9ab95")
addappid(915562, 1, "18afcbd8050e5a82b8a512ab0495cfcd4eae6ec0a9c13b493e61d0a88412f04c")
addappid(915563, 1, "567a6bc6102322f36a07ae11982302fa25da9000c0100e7040881eb18f0aabdb")
addappid(915564, 1, "6dfc57cac98d146bfa36303172ba2e290ae722594516835c89988dfa8451dab4")
