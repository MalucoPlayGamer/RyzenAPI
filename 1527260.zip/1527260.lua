-- Lua provided by RyzenAPI
-- Game: The Last Town: Excape

-- MAIN APPLICATION
addappid(1527260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527261, 1, "50d29fbfdc329c8fda2e0d0d0617f3ef9ff028fc13dc33fd446f4d5fc69289db")

