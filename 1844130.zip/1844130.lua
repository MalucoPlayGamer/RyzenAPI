-- Lua provided by RyzenAPI
-- Game: Game: Stellar Orphans

-- MAIN APPLICATION
addappid(1844130)
-- Game: addappid(1844130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844131, 1, "b579cfb8e9119e722a748a245fc8b934ac6a35553a8b93a448d044cdac4fd1e0")
