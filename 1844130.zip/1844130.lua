-- Lua provided by SkyAPI 
-- Game: Stellar Orphans
addappid(1844130)
addappid(1844131, 1, "b579cfb8e9119e722a748a245fc8b934ac6a35553a8b93a448d044cdac4fd1e0")
