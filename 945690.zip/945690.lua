-- Lua provided by RyzenAPI
-- Game: 945690

-- MAIN APPLICATION
addappid(945690)
-- Game: addappid(945690)

-- MAIN APP DEPOTS / PACKAGES
addappid(945691, 1, "7eb75ca6c8dbea83e2a6205e325f9bcabde8aaf8ca67f303729b07c439c4a32b")
