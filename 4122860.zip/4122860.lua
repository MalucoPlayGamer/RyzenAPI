-- Lua provided by RyzenAPI
-- Game: Z.A.T.O. // I Love the World and Everything In It

-- MAIN APPLICATION
addappid(4122860)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4122990)
