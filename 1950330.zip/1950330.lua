-- Lua provided by RyzenAPI
-- Game: Zodiacats - Supporter Pack

-- MAIN APPLICATION
addappid(1950330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950330,0,"36be600b6c31fbe5606072de1df6dcc07bab23394ca840ede4024ba4866915ee")

