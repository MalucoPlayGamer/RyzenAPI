-- Lua provided by RyzenAPI
-- Game: addappid(588210)

-- MAIN APPLICATION
addappid(588210)

-- MAIN APP DEPOTS / PACKAGES
addappid(588211, 1, "5adccf972c0313b145d006cf8b973fc61d91c2bf733198915c2a8aa5d4db7baa")
