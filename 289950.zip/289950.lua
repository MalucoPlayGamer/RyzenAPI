-- Lua provided by RyzenAPI
-- Game: AppID 289950

-- MAIN APPLICATION
addappid(289950)
addappid(320390)
addappid(325680)
addappid(325690)
addappid(325691)
addappid(325692)
addappid(325693)
addappid(329840)
addappid(333470)
addappid(333480)
addappid(333481)
addappid(334610)
addappid(334611)
addappid(359780)
addappid(359781)
addappid(359790)
addappid(404280)
addappid(404281)
addappid(404282)
addappid(404283)
addappid(404284)

-- MAIN APP DEPOTS / PACKAGES
addappid(289951, 1, "d10c2955fda3f4474d717f82c302b099f452a1d09565f837260b26fb6c41a26e")
addappid(289952, 1, "c63b4a8848ba573b8c5c8283b306965b97f2e17c2b5903fe153cd02324cdd54c")
addappid(289963, 1, "e3ddad94bb289fba3fc532dffb777de9ff8d6182a21e9d938e87e8e4d898f672")

