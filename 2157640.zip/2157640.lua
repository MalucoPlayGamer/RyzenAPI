-- Lua provided by RyzenAPI 
-- Game: AppID 2157640
addappid(2157640)
addappid(2157641, 1, "9f54841254578b1a464cf32d2139ad79da910d1c1de1b607001d2d1a3a3a9615")
