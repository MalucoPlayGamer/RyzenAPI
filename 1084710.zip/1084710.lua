-- Lua provided by RyzenAPI
-- Game: addappid(1084710)

-- MAIN APPLICATION
addappid(1084710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084711, 1, "11a85df59cec2474119d0c87f6e1b8d61427235bd0744b2b5702edb5a1b44ea8")
