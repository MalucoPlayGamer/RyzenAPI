-- Lua provided by RyzenAPI
-- Game: No Bugs On My Windshield

-- MAIN APPLICATION
addappid(2870510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870511, 1, "73c6d3eeec414fc2551a4685855683c83c5bc68f6c2375b401a3c8f72a3b84d1")

