-- Lua provided by RyzenAPI
-- Game: Evitania Online - Idle RPG

-- MAIN APPLICATION
addappid(4119420)

