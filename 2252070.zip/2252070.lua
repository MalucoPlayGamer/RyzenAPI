-- Lua provided by RyzenAPI
-- Game: [SUBJECT]

-- MAIN APPLICATION
addappid(2252070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252071, 1, "d2fd2eb3727e7459b00e6f73963b4c4b3444f419d3e3a84ffe1c19897177efa7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
