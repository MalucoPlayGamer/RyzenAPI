-- Lua provided by RyzenAPI 
-- Game: Shell Runner
addappid(2622280)
addappid(2622281, 1, "d57abfcd9dbd63893836c880df4c1d9d83d03840c29dd2e9066928f234529a7b")
