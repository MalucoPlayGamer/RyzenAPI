-- Lua provided by RyzenAPI
-- Game: Shell Runner

-- MAIN APPLICATION
addappid(2622280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2622281, 1, "d57abfcd9dbd63893836c880df4c1d9d83d03840c29dd2e9066928f234529a7b")

