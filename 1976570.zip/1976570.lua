-- Lua provided by RyzenAPI
-- Game: Swarm the City: Full Release Prologue

-- MAIN APPLICATION
addappid(1976570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976571, 1, "123974e763e65c0850d10eaf2f3d1783b97bd832f09de52ec5d3370c5918af2a")

