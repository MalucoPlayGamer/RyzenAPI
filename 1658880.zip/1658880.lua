-- Lua provided by RyzenAPI
-- Game: Game: 汉字大冒险

-- MAIN APPLICATION
addappid(1658880)
-- Game: addappid(1658880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658881, 1, "5c34826ed647d4890489887083be1d0745e52c7985c533f9494153f365b56324")
