-- Lua provided by RyzenAPI
-- Game: 2885700

-- MAIN APPLICATION
addappid(2885700)
-- Game: addappid(2885700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885701, 1, "720dab55dd3e5a19fcb5cf057767a3879be38cf3c7efb3fde14a486c75f6a687")
