-- Lua provided by RyzenAPI
-- Game: The Backrooms: Survival

-- MAIN APPLICATION
addappid(1889640)
-- Game: addappid(1889640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889641, 1, "8c76bdeb73096b96a9b836824d302780623cafcc5d675118785f1b06de8e0157")
