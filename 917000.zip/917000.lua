-- Lua provided by RyzenAPI
-- Game: WORLD  HENTAI

-- MAIN APPLICATION
addappid(917000)

-- MAIN APP DEPOTS / PACKAGES
addappid(917001, 1, "e5d0f3d58ae919aeecd03bdfb5927b0e58611d9083335fde57123c7aa800fca4")
