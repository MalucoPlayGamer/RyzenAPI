-- Lua provided by RyzenAPI
-- Game: 2783560

-- MAIN APPLICATION
addappid(2783560)
addappid(2882510)
-- Game: addappid(2783560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783561, 1, "33795240e11a05d5cc67f26955f39d6cfc7f3205d51c235d4d2b8870069e643e")
