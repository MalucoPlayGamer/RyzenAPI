-- Lua provided by RyzenAPI
-- Game: addappid(2347510)

-- MAIN APPLICATION
addappid(2347510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347510,0,"cc57ec5a3dfa59a5f67cca4892b0b26fac3cb1fc4c4008ce3d4b88eae82e7771")
