-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Fantasy Market - Weapons Tileset

-- MAIN APPLICATION
addappid(3766020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3766020,0,"a061d1d9608cb97e637766073ae212f09a6de2a8b7650125ceffc296a508a6a0")

