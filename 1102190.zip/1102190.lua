-- Lua provided by SkyAPI 
-- Game: AppID 1102190
addappid(1102190)
addappid(1102191, 1, "b5b7e523cc61fede07b8692d01b67a7acad5a821fe3542e442d8967b803d2fc7")
addappid(1359320, 0, "a0222facea570990a7261d9c2c4403261b6b0f52330bd28db28da633dfe62a68")
