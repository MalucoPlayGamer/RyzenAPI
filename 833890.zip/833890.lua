-- Lua provided by RyzenAPI
-- Game: addappid(833890)

-- MAIN APPLICATION
addappid(833890)

-- MAIN APP DEPOTS / PACKAGES
addappid(833891, 1, "fe6110cead518f9dacd64607bbb29a1bdc411a09117b09c282dca402a33d491d")
