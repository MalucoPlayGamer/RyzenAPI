-- Lua provided by RyzenAPI
-- Game: Demolish & Build 3 Prologue

-- MAIN APPLICATION
addappid(2803230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803231, 1, "45c70915679bcd25548821dc566d612fdb2d7a1132556c3073580ea924a9e95e")
