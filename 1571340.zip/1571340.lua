-- Lua provided by RyzenAPI 
-- Game: VR HOT
addappid(1571340)
addappid(1571341, 1, "ee0b8b28add459c0accd5b7a7df7a9fd3614b2790fea6cb28fd6430b726c7b10")
