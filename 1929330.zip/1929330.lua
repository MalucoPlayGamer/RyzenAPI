-- Lua provided by RyzenAPI
-- Game: addappid(1929330)

-- MAIN APPLICATION
addappid(1929330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929331, 1, "cefbaa8a552b01c0b7fe0f0d77120723567931dbd320fba854057b1ae6ca85e9")
