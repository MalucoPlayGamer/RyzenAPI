-- Lua provided by RyzenAPI
-- Game: Xiahou Yuan - Officer Ticket / 夏侯淵使用券

-- MAIN APPLICATION
addappid(956728)
-- Game: addappid(956728)

-- MAIN APP DEPOTS / PACKAGES
addappid(956728,0,"20fad3949e7f6362b97cbfeb0f20990d5470272233f23af2aa2cc2dde2a91d90")
