-- Lua provided by RyzenAPI
-- Game: addappid(1058110)

-- MAIN APPLICATION
addappid(1058110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058111, 1, "8c87a334a97bedb327c39fdd6c205655c95a32718139c327cd66524bf8c89f7a")
