-- Lua provided by RyzenAPI 
-- Game: Mortal Vessel
addappid(1979200)
addappid(1979201, 1, "064cd2f220404e7ca5ed4e0aa24baf48705186179203e07037ec74281cebb628")
