-- Lua provided by RyzenAPI
-- Game: Mortal Vessel

-- MAIN APPLICATION
addappid(1979200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979201, 1, "064cd2f220404e7ca5ed4e0aa24baf48705186179203e07037ec74281cebb628")

