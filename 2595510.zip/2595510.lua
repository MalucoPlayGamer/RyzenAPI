-- Lua provided by RyzenAPI
-- Game: Wildmender Soundtrack

-- MAIN APPLICATION
addappid(2595510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595511, 1, "ebaf1eac911a49176eba490564b9105045a96a6b539747367176c9317b6b2255")
addappid(2595512, 1, "701dfaf904df91ffc1d80de1c8b427ef744b8e51f6f88933ff397a8f21da8589")
