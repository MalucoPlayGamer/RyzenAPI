-- Lua provided by RyzenAPI
-- Game: Cataclismo

-- MAIN APPLICATION
addappid(1422440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422441, 1, "51c79f1c3edb01cb1da91dbf5f692f9417f0d24d9c1d058ed8adf8016604a890")

