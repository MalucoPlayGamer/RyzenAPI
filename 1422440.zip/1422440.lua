-- Lua provided by SkyAPI 
-- Game: Cataclismo
addappid(1422440)
addappid(1422441, 1, "51c79f1c3edb01cb1da91dbf5f692f9417f0d24d9c1d058ed8adf8016604a890")
