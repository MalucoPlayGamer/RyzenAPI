-- Lua provided by RyzenAPI
-- Game: Cataclismo

-- MAIN APPLICATION
addappid(1422440)
addappid(4396100)
addappid(5001640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1422441, 1, "51c79f1c3edb01cb1da91dbf5f692f9417f0d24d9c1d058ed8adf8016604a890")

