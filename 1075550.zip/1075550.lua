-- Lua provided by RyzenAPI
-- Game: addappid(1075550)

-- MAIN APPLICATION
addappid(1075550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075551, 1, "0df5eccc2a99ef4c2185525220bbe5283116dd68e69fe92dc6158c0e9fefa9a9")
