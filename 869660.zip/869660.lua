-- Lua provided by RyzenAPI
-- Game: addappid(869660)

-- MAIN APPLICATION
addappid(869660)

-- MAIN APP DEPOTS / PACKAGES
addappid(869661, 1, "8743c79507cdf682a47dd353a88777aa5e389aa99a34670effb9c4f087aceda9")
