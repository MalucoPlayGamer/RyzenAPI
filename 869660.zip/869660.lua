-- Lua provided by SkyAPI 
-- Game: AppID 869660
addappid(869660)
addappid(869661, 1, "8743c79507cdf682a47dd353a88777aa5e389aa99a34670effb9c4f087aceda9")
