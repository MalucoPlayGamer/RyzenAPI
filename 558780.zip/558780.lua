-- Lua provided by RyzenAPI
-- Game: Sonya: The Great Adventure

-- MAIN APPLICATION
addappid(558780)

-- MAIN APP DEPOTS / PACKAGES
addappid(558781,0,"f0f406b2549d956f924b22c26bd3ac8cfc1f4b3a056aae76b9a9e3ad9a34fdee")
addappid(558782,0,"1329bfba0d8feee0d152243719aaaec8b5f240c2a8fcf3b6420413d778a19f7d")

