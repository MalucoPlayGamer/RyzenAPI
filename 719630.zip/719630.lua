-- Lua provided by RyzenAPI
-- Game: AppID 719630

-- MAIN APPLICATION
addappid(719630)

-- MAIN APP DEPOTS / PACKAGES
addappid(719631, 1, "6c764ef1fdc6368ee7eed1c8db16e4184c7b2331ba069fbe9afa3571a015846b")
addappid(719634, 1, "8a6b8fabe3ab3be487dcb80dc3aad9f7d0930aecc81513df55b0318b7ff758ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
