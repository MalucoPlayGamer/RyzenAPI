-- Lua provided by RyzenAPI
-- Game: Fast Food Manager

-- MAIN APPLICATION
addappid(1519790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519791, 1, "b7ec514b6ee13a5242ec01428246148ce6e896db1c3528b8135ec4e6eda75dab")

