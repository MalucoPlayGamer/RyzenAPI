-- Lua provided by RyzenAPI
-- Game: Game: Clavis Kinkygate: Treasure of Danau River

-- MAIN APPLICATION
addappid(2651550)
-- Game: addappid(2651550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651551, 1, "a15109689d682e3ab4b899dde7c46635ec771a1a4b524cf9e3941e5ddcfd1180")
