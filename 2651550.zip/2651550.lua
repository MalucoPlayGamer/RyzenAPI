-- Lua provided by SkyAPI 
-- Game: Clavis Kinkygate: Treasure of Danau River
addappid(2651550)
addappid(2651551, 1, "a15109689d682e3ab4b899dde7c46635ec771a1a4b524cf9e3941e5ddcfd1180")
