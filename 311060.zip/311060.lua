-- Lua provided by RyzenAPI 
-- Game: Battle Mages: Sign of Darkness
addappid(311060)
addappid(311061, 1, "874110b68f35538dc23107fe6109ea87dc04f0325558cd094bd444f34ec46e0f")
addappid(311062, 1, "0cee85e6f240f119fa3cb6f9f1ce11a95e719eff82f4bce9a87e79bee45e796d")
addappid(311063, 1, "f068e0233ab882a56ca3d3ac677447675fd2a7f1ff72798c0b793933f0e6664f")
