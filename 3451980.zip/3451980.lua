-- 3451980's Lua and Manifest Created by Hubcap Manifest
-- Soul's Remnant
-- Created: August 13, 2026 at 15:27:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3451980) -- Soul's Remnant
-- MAIN APP DEPOTS
addappid(3451981, 1, "330c4b73b9094464ea250cf0ade3ed66b1b32de5a171ee4e9216dc807f7d6751") -- Depot 3451981
setManifestid(3451981, "4945797007931945556", 301605180)