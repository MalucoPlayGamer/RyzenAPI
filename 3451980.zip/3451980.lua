-- Lua provided by RyzenAPI
-- Game: Soul's Remnant

-- MAIN APPLICATION
addappid(3451980) -- Soul's Remnant

-- MAIN APP DEPOTS / PACKAGES
addappid(3451981, 1, "330c4b73b9094464ea250cf0ade3ed66b1b32de5a171ee4e9216dc807f7d6751") -- Depot 3451981

