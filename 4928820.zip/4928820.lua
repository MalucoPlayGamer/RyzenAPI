-- Lua provided by RyzenAPI
-- Game: Shelve the Potions!

-- MAIN APPLICATION
addappid(4928820) -- Shelve the Potions!

-- MAIN APP DEPOTS / PACKAGES
addappid(4928821, 1, "bedf4061c0001b4170822c800952df52ab1851831404a078962e6460a5ae0697") -- Depot 4928821

