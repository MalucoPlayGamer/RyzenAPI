-- 4928820's Lua and Manifest Created by Hubcap Manifest
-- Shelve the Potions!
-- Created: August 24, 2026 at 10:01:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4928820) -- Shelve the Potions!
-- MAIN APP DEPOTS
addappid(4928821, 1, "bedf4061c0001b4170822c800952df52ab1851831404a078962e6460a5ae0697") -- Depot 4928821
setManifestid(4928821, "3483007195938485622", 1036984147)