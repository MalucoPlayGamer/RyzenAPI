-- Lua provided by RyzenAPI
-- Game: Factory Outlet Simulator Demo

-- MAIN APPLICATION
addappid(3007810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007811, 1, "a0c3734d6fdaf312561d88f6ca925154a94cef90eed3a8030d6567bbf7a90a49")
