-- Lua provided by RyzenAPI 
-- Game: Border Pioneer Demo
addappid(2844770)
addappid(2844771, 1, "5eb08f71ad4220b22617149308b855dffba55eb73ecaa432c2319b9f6ce49492")
