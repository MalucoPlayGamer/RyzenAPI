-- Lua provided by RyzenAPI
-- Game: addappid(602880)

-- MAIN APPLICATION
addappid(602880)

-- MAIN APP DEPOTS / PACKAGES
addappid(602881, 1, "48d8c6db83cf76b01daeda6a356f409baf4326675f56ae62cd167ed8004faa28")
