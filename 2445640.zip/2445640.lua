-- Lua provided by RyzenAPI
-- Game: addappid(2445640)

-- MAIN APPLICATION
addappid(2445640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445641, 1, "fdd14a6f155b4ba82d1d2efea2697dbdc2777eca4fd7d23f28935e228927087e")
