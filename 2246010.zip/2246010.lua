-- Lua provided by RyzenAPI
-- Game: Kemps

-- MAIN APPLICATION
addappid(2246010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246011, 1, "e2bffdeeecb39be7d01ebeda111c702758cfb06aab29f6010fe4cd40dc66b1a3")
