-- Lua provided by RyzenAPI
-- Game: 2246010

-- MAIN APPLICATION
addappid(2246010)
-- Game: addappid(2246010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246011, 1, "e2bffdeeecb39be7d01ebeda111c702758cfb06aab29f6010fe4cd40dc66b1a3")
