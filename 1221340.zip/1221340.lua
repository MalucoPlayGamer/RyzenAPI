-- Lua provided by RyzenAPI
-- Game: 1221340

-- MAIN APPLICATION
addappid(1221340)
-- Game: addappid(1221340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221340,0,"9cdda93c1089dc5475ec0923d740cc0c95cd589dce1967fb4f124c3c4993b023")
