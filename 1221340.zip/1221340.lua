-- Lua provided by RyzenAPI
-- Game: H-Rescue : The True Of Magic (18+)

-- MAIN APPLICATION
addappid(1221340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221340,0,"9cdda93c1089dc5475ec0923d740cc0c95cd589dce1967fb4f124c3c4993b023")

