-- Lua provided by RyzenAPI
-- Game: 60900

-- MAIN APPLICATION
addappid(60900)
-- Game: addappid(60900)

-- MAIN APP DEPOTS / PACKAGES
addappid(60901, 1, "05107ed39fea36a00b6b0d43ef2a8d301854d4883530762be552075e9126f720")
