-- Lua provided by RyzenAPI 
-- Game: AppID 60900
addappid(60900)
addappid(60901, 1, "05107ed39fea36a00b6b0d43ef2a8d301854d4883530762be552075e9126f720")
