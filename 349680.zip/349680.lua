-- Lua provided by RyzenAPI
-- Game: AppID 349680

-- MAIN APPLICATION
addappid(349680)

-- MAIN APP DEPOTS / PACKAGES
addappid(349681, 1, "62f67fd4521274ea5726a619816c6fde4cfb4f4652522c37ffb58343bb5f8fc9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
