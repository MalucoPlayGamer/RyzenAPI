-- Lua provided by RyzenAPI 
-- Game: AppID 349680
addappid(349680)
addappid(349681, 1, "62f67fd4521274ea5726a619816c6fde4cfb4f4652522c37ffb58343bb5f8fc9")
