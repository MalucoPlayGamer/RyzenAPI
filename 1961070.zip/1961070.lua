-- Lua provided by RyzenAPI
-- Game: addappid(1961070)

-- MAIN APPLICATION
addappid(1961070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961071, 1, "91b40d39721caa2c77baed3fde591f66e084b54a58d4eb70fb73c4832c575343")
