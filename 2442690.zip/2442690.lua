-- Lua provided by RyzenAPI
-- Game: Gigachad Survivals

-- MAIN APPLICATION
addappid(2442690)
-- Game: addappid(2442690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442691, 1, "0f4c3d0abdbaf0cb23142a64fdd8d20d06a1773ce4cdca38921bc44e0f2dbaba")
