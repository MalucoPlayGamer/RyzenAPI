-- Lua provided by RyzenAPI 
-- Game: Fallen Leaf
addappid(1459010)
addappid(1459011, 1, "900f96286324c26718e105816b8799b56cc0ad4dfcfd45eee317884988a48001")
