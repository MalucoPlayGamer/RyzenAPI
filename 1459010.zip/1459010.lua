-- Lua provided by RyzenAPI
-- Game: Fallen Leaf

-- MAIN APPLICATION
addappid(1459010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459011, 1, "900f96286324c26718e105816b8799b56cc0ad4dfcfd45eee317884988a48001")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
