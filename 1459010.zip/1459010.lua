-- Lua provided by RyzenAPI
-- Game: Game: Fallen Leaf

-- MAIN APPLICATION
addappid(1459010)
-- Game: addappid(1459010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459011, 1, "900f96286324c26718e105816b8799b56cc0ad4dfcfd45eee317884988a48001")
