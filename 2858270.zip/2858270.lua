-- Lua provided by RyzenAPI
-- Game: The Storyteller

-- MAIN APPLICATION
addappid(2858270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858271, 1, "5f7f332f401b2f1a143ecfa5c47be92caac79412c21873f90c8e66570cc69743")
addappid(2858272, 1, "92be8450a3777e58ec197c09bc86cf492e8d2bb488ad710ad1684370a8e5e068")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
