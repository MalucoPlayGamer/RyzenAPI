-- Lua provided by RyzenAPI
-- Game: The Storyteller

-- MAIN APPLICATION
addappid(2858270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858271, 1, "5f7f332f401b2f1a143ecfa5c47be92caac79412c21873f90c8e66570cc69743")
addappid(2858272, 1, "92be8450a3777e58ec197c09bc86cf492e8d2bb488ad710ad1684370a8e5e068")
