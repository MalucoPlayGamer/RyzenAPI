-- Lua provided by RyzenAPI
-- Game: Steinstern: Spacewar

-- MAIN APPLICATION
addappid(1538030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538031, 1, "d1dd6510ba1b96965bbd58606471cd45c2435e3c3db1ebe9926c0ab8aa356134")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
