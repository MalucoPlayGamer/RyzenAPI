-- Lua provided by RyzenAPI
-- Game: Steinstern: Spacewar

-- MAIN APPLICATION
addappid(1538030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538031, 1, "d1dd6510ba1b96965bbd58606471cd45c2435e3c3db1ebe9926c0ab8aa356134")

