-- Lua provided by SkyAPI 
-- Game: Lirica
addappid(1733460)
addappid(1733461, 1, "6a598c4bf87ca2768ad77b0edbed0687f5f09c59c742f6d44d7e816597d984e2")
