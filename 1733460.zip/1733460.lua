-- Lua provided by RyzenAPI
-- Game: addappid(1733460)

-- MAIN APPLICATION
addappid(1733460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733461, 1, "6a598c4bf87ca2768ad77b0edbed0687f5f09c59c742f6d44d7e816597d984e2")
