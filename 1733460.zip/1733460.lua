-- Lua provided by RyzenAPI
-- Game: Lirica

-- MAIN APPLICATION
addappid(1733460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1733461, 1, "6a598c4bf87ca2768ad77b0edbed0687f5f09c59c742f6d44d7e816597d984e2")

