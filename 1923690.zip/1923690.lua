-- Lua provided by RyzenAPI
-- Game: Game: Pocket League Story

-- MAIN APPLICATION
addappid(1923690)
-- Game: addappid(1923690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923691, 1, "6ab24e13febf5d3c2016403955e02a8a978438a551c546c336aed2bbce2a206b")
