-- Lua provided by RyzenAPI
-- Game: Game: Devilish Lady Doctor - A Night of Domination and Seduction -

-- MAIN APPLICATION
addappid(3384860)
-- Game: addappid(3384860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3384861, 1, "95a4ec70e34535024dc7a8e2dc6dc66abd1703ae4b6a427ed8d1bc1446726707")
