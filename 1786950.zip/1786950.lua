-- Lua provided by RyzenAPI
-- Game: Klaus Veen's Treason

-- MAIN APPLICATION
addappid(1786950)
-- Game: addappid(1786950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786951, 1, "e9907e380e9ccfb4110a4d845137081b8780b7ac398193536fb0db0a8c962cd5")
