-- Lua provided by RyzenAPI
-- Game: Clutter Infinity: Joe's Ultimate Quest

-- MAIN APPLICATION
addappid(553330)

-- MAIN APP DEPOTS / PACKAGES
addappid(553331,0,"8d661a2f04348aa031558e75f28efd132970df5ff0220415a59462c3bf015f8f")

