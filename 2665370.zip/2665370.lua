-- Lua provided by SkyAPI 
-- Game: VIRTUAL LIVE ARENA
addappid(2665370)
addappid(2665371, 1, "fcc37a7d687de73755543de712c0f3f8a07d4916a66fb7c87f232b1a8a89e471")
