-- Lua provided by RyzenAPI
-- Game: addappid(2665370)

-- MAIN APPLICATION
addappid(2665370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2665371, 1, "fcc37a7d687de73755543de712c0f3f8a07d4916a66fb7c87f232b1a8a89e471")
