-- Lua provided by RyzenAPI
-- Game: Game: TRIZEAL Remix

-- MAIN APPLICATION
addappid(465070)
-- Game: addappid(465070)

-- MAIN APP DEPOTS / PACKAGES
addappid(465071, 1, "222abe2b63862f7f9e77dba22debcb190592069d416bb48c79ade4a509c32e59")
