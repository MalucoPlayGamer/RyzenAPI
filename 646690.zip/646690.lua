-- Lua provided by SkyAPI 
-- Game: AppID 646690
addappid(646690)
addappid(646691, 1, "92927a632622b961a38ea5d9aec591a84a5923a4237692a0ea36d094b8962101")
