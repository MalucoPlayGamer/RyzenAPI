-- Lua provided by RyzenAPI
-- Game: SUPER CRAZY RHYTHM CASTLE

-- MAIN APPLICATION
addappid(1812560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812561, 1, "cde8c07acbaef08a7bbba26a430df8c2b63baf2cef64c25f8cb2bed6bd7a7823")

