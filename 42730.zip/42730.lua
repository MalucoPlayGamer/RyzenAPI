-- Lua provided by RyzenAPI
-- Game: James Bond: Blood Stone

-- MAIN APPLICATION
addappid(42730)

-- MAIN APP DEPOTS / PACKAGES
addappid(42731, 1, "00109b15b04ce3ad9a821d279e40c185406963f0e0fcacf5a44ac03d5f673151")

