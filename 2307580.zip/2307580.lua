-- Lua provided by RyzenAPI
-- Game: 2307580

-- MAIN APPLICATION
addappid(2307580)
-- Game: addappid(2307580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307581, 1, "3beaa6313e5e8793fab1a0cc91b03e006aeba774fc6565964fd1448ab33f67f3")
