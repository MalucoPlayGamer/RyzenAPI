-- Lua provided by RyzenAPI
-- Game: Game: Big Bang Empire

-- MAIN APPLICATION
addappid(510660)
-- Game: addappid(510660)

-- MAIN APP DEPOTS / PACKAGES
addappid(510661, 1, "a573f5849a2a5eeb12da0fd6fa6e5f5b10ea3614f6e2c7cec502b8b76804cd3e")
