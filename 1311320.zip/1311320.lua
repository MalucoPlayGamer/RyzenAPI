-- Lua provided by RyzenAPI
-- Game: AppID 1311320

-- MAIN APPLICATION
addappid(1311320)
-- Game: addappid(1311320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311321, 1, "0c2511c9c3a471f6a00a3d4e25d4ecdc0f2a2822efc408669c51eb0a7793e0b4")
