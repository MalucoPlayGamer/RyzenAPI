-- Lua provided by RyzenAPI
-- Game: 1248150

-- MAIN APPLICATION
addappid(1248150)
-- Game: addappid(1248150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248151, 1, "855e6a51e172df9711affc3600644d24767b5eaa270535f5f2d2ce09ff6a8557")
addappid(1248153, 1, "fa0797daeeca2bb07a0fc22ad249d7c65a130c6db1a8536700255d0243737eee")
