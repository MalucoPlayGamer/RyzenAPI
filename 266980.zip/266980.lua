-- Lua provided by RyzenAPI 
-- Game: AppID 266980
addappid(266980)
addappid(266981, 1, "289a382d9042a509df950e4bead4707be4338ca67e651c3461a848eb5a82ce59")
addappid(266982, 1, "45484bf6d0c4c5339589c9ba30878ccad199c50212371fac10614662bbdba694")
