-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - FSM - Desert Town and Ruins Tiles

-- MAIN APPLICATION
addappid(1617520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617520,0,"7d5ceb0a3e113a29d5e886c8766e482fbc234d82d559d9d73dd4411ec065cc12")
