-- Lua provided by RyzenAPI
-- Game: addappid(635320)

-- MAIN APPLICATION
addappid(635320)

-- MAIN APP DEPOTS / PACKAGES
addappid(635321, 1, "6eb7981c7406b03afe39bf942b788b5db3d20c7e1918c40990abb1be24ea6a61")
