-- Lua provided by RyzenAPI 
-- Game: AppID 3316440
addappid(3316440)
addappid(3316441, 1, "819204961128283a0e791b2a477d9d1ddaa83bb987b54ab4e6b160aa65a6e030")
