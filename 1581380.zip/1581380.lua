-- Lua provided by RyzenAPI
-- Game: AppID 1581380

-- MAIN APPLICATION
addappid(1581380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581381, 1, "25b21371eae0a218d5d08d0a796a127c0b8215e0e1a8b7aaba5aa2a25552bb0e")
