-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1684146)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684146,0,"a35edab071067a1334254f11cb24728310b017e95b4a6f7e538e386a56f61aa5")

