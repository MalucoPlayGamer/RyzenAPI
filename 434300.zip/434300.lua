-- Lua provided by RyzenAPI
-- Game: AppID 434300

-- MAIN APPLICATION
addappid(434300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(434301, 1, "b30a75a036b71e53b7c01de6804439fdb3f27ba2e8a468e696a6cfbe9cc2a631")
addappid(434302, 1, "255246fa0d81689cb508a2f7ed419ea5943fbb73814ada0f86d71bfbf0dd72e9")

