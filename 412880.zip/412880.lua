-- Lua provided by SkyAPI 
-- Game: Drift Streets Japan
addappid(412880)
addappid(412881, 1, "841c6cd29ebe9e17cfada18202eb28697ad14468c19dd48bd4fc9237b3949d49")
