-- Lua provided by RyzenAPI
-- Game: 1582290

-- MAIN APPLICATION
addappid(1582290)
-- Game: addappid(1582290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582291, 1, "2ea8c75fe1e3cd3f29522ffc4bd1895df494849d581e5b55fe4b13cb696c1bad")
