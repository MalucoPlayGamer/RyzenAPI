-- Lua provided by RyzenAPI
-- Game: Emporea: Realms of War and Magic

-- MAIN APPLICATION
addappid(416450)

