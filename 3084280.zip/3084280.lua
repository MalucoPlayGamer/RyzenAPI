-- Lua provided by RyzenAPI
-- Game: Threefold Recital

-- MAIN APPLICATION
addappid(3084280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3084281, 1, "8992e70f6265e3afca1db65339f6132ed758d29b4517fd6e44039e6154082644")

