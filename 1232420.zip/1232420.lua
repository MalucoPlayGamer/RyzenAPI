-- Lua provided by RyzenAPI
-- Game: Atlantica Global

-- MAIN APPLICATION
addappid(1232420)
