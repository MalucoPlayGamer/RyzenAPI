-- Lua provided by RyzenAPI
-- Game: addappid(9340)

-- MAIN APPLICATION
addappid(4561)
addappid(4564)
addappid(4565)
addappid(4566)
addappid(4567)
addappid(4568)
addappid(9340)

-- MAIN APP DEPOTS / PACKAGES
addappid(9347,0,"6018fbdb83e6aec864f8857a73976ee605071e9656535138468238545a3cadda")
addappid(9348,0,"84121733ec0c9c0951c163e9d9ff773830750a89650c239abb445fac35525f8a")
addappid(9349,0,"2cd5e2176b30c83fd8d643d11115a375db95005356cfecd33fc205dea0e1fc72")
addappid(20546,0,"4a46f502c6199edce34f7392ca44427c82916d0f43a7ce2a1d6d0a05ffef1b7a")
addappid(20547,0,"20e529a1a26de671c367534f047c79e6edcce10140b8da88f5a7ac70a160b575")
addappid(20548,0,"afff5bec4d587b3003a82470d4527edb8fdeb51f005e43f31d7d1f87d395378b")
