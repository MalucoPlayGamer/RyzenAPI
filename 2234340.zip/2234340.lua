-- Lua provided by RyzenAPI
-- Game: RetroArch - ep128emu

-- MAIN APPLICATION
addappid(2234340)
-- Game: addappid(2234340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234341, 1, "4ed87e24947b99993da2ef537072341adc51ca298dfbe23bfeb7bb608650555e")
addappid(2234342, 1, "19f784f043bacc84f092948fc11aeb6f96f03daffcdf93e8502e98698b3f041a")
