-- Lua provided by RyzenAPI
-- Game: My Wife Sucked a Futanari's Toes

-- MAIN APPLICATION
addappid(3208360)
-- Game: addappid(3208360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3208361, 1, "2eab2fb1f2254bfba0a95cb12193d3de1611dacb2b59b2005b601309be9b785f")
