-- Lua provided by RyzenAPI
-- Game: Neptunia: Sisters VS Sisters

-- MAIN APPLICATION
addappid(1932160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932161, 1, "3335c0fd172d4ff643c469013cae0e956bc0603185df4999b5e57e3115fe1d6c")
