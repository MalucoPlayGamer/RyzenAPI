-- Lua provided by RyzenAPI 
-- Game: Hard Time III
addappid(3009850)
addappid(3009851, 1, "e92020d15750f186520ea5132e8c28e25b77f4d583725fc957e734ab28503e12")
