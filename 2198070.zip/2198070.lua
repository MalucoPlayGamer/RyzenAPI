-- Lua provided by RyzenAPI
-- Game: Cardboard Town

-- MAIN APPLICATION
addappid(2198070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198071, 1, "eb6fe6ec54d15a65f67f38378a6628b012ee5113d66834b0aac3725755ffbf39")
addappid(2198072, 1, "221fa3d5bd5cbb83e996719d27deb96d677e1d580adc32af5a56ff58cbdb2b22")
addappid(2198073, 1, "37797624ae4199ec0f588900bb7bd923c9720fe74fa1a8d79468cc36804a87f6")

