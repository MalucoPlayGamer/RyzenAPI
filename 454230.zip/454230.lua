-- Lua provided by RyzenAPI
-- Game: addappid(454230)

-- MAIN APPLICATION
addappid(454230)
addappid(561350)

-- MAIN APP DEPOTS / PACKAGES
addappid(454231, 1, "95b538f39fa1724f0e7d3e7caa6cf3f1c75650eb8aee30c9fe9d531ae021bbb9")
