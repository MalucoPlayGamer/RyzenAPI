-- Lua provided by RyzenAPI
-- Game: AppID 1304400

-- MAIN APPLICATION
addappid(1304400)
-- Game: addappid(1304400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304401, 1, "998c0599aacaed594dfb486f151467e0e57165053fc5d8d01f86da3d295b1585")
addappid(1304402, 1, "8226267dcbca27771d00ed1cc2524e3eb4fe47affe2ded6aed27669ad4ae1f0a")
