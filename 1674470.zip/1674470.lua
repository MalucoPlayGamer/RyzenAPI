-- Lua provided by RyzenAPI
-- Game: 1674470

-- MAIN APPLICATION
addappid(1674470)
-- Game: addappid(1674470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674471, 1, "780cae23b9a2d7b9bd451751e9256c430684173dfec48ea4485b3bb453b22925")
