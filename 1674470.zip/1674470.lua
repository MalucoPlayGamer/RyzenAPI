-- Lua provided by RyzenAPI
-- Game: ELYON

-- MAIN APPLICATION
addappid(1674470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674471, 1, "780cae23b9a2d7b9bd451751e9256c430684173dfec48ea4485b3bb453b22925")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1692370)
addappid(1692371)
addappid(1755900)
addappid(1782430)
addappid(1782431)
addappid(1782432)
addappid(1782433)
addappid(1782434)
addappid(1782435)
addappid(1782436)
addappid(1791370)
