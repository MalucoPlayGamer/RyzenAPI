-- Lua provided by RyzenAPI
-- Game: Looney Tunes: Wacky World of Sports

-- MAIN APPLICATION
addappid(2330430)
addappid(2874160)
addappid(3003840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2330431, 1, "75090224683ecd72357de130453cd94bcb08a61cacfab30311537de90969ad1e")

