-- Lua provided by RyzenAPI
-- Game: 2330430

-- MAIN APPLICATION
addappid(2330430)
addappid(2874160)
addappid(3003840)
-- Game: addappid(2330430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330431, 1, "75090224683ecd72357de130453cd94bcb08a61cacfab30311537de90969ad1e")
