-- Lua provided by RyzenAPI
-- Game: When The Devil Takes Hold Demo

-- MAIN APPLICATION
addappid(2480330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2480331, 1, "0594b25f712568de05bd8e1bfdcb9878644669971ec52359b199b8047f915b63")

