-- Lua provided by RyzenAPI
-- Game: Double Fine PsychOdyssey

-- MAIN APPLICATION
addappid(3245600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245600,0,"97164139d21ecf4706f9a240c1dcb2836ac7d533e2c434a027347281cd5422dd")
