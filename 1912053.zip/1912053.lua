-- Lua provided by RyzenAPI
-- Game: addappid(1912053)

-- MAIN APPLICATION
addappid(1912053)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912053,0,"05dc63cf78aa3e3e60f027ed83828b050a6e908df427039596c40faa77255fdb")
