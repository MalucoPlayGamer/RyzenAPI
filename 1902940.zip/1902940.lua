-- 1902940's Lua and Manifest Created by Hubcap Manifest
-- Snacktorio
-- Created: June 07, 2026 at 23:11:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1902940, 1, "c339561d6f4f6d836c8bc7912c6a5d2d7deb1c3f6983d03bf19212ea89bec844") -- Snacktorio
-- MAIN APP DEPOTS
addappid(1902942, 1, "c6af2748855969607b165d757fb7168f1c893dd0ad7bc8a484b15503dee72877") -- Depot 1902942
-- setManifestid(1902942, "1760532516647069821", 122179859)
addappid(1902943, 1, "c3e5a2db470667343465415e58761bd4587e67053b3e9b6a5f5cac4c88758089") -- Depot 1902943
-- setManifestid(1902943, "2331820771634906399", 147933406)
addappid(1902941, 1, "437e8bb61e8a0530dd388258bd9f5bb91d915933d1609d47768d45f3c02990a2") -- Depot 1902941
-- setManifestid(1902941, "3807436919677583510", 141793883)
addappid(1902944, 1, "7043f7909c8ab96db4fcb5ccd2fbd12c88e0a4740165b2eb4d4856a95481fbba") -- Depot 1902944
-- setManifestid(1902944, "4027035918047786067", 141821335)