-- Lua provided by RyzenAPI
-- Game: Game: HOT WHEELS UNLEASHED™

-- MAIN APPLICATION
addappid(1271700)
-- Game: addappid(1271700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271701, 1, "ff5665727b233ab8a0dca5d6d9eb0fb3be4a737fa3a73656f1290d9a132d6e6a")
