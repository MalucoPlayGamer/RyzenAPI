-- Lua provided by RyzenAPI
-- Game: AppID 586540

-- MAIN APPLICATION
addappid(586540)

-- MAIN APP DEPOTS / PACKAGES
addappid(586541, 1, "11def2dd290f5423ec5a1cc355529a99210f50671a9bd5fb0d5b5ef196e0ffc8")
