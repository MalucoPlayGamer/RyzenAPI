-- Lua provided by RyzenAPI
-- Game: Blood & Lust [18+]🩸

-- MAIN APPLICATION
addappid(3172270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172271, 1, "30232e38cc5f1ce612702bcbfb6aac63aec0c590a02c90bdb38d34ffcd7bb407")

