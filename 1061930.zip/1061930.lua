-- Lua provided by RyzenAPI 
-- Game: Cyber City
addappid(1061930)
addappid(1061931, 1, "845e60207967dd3a706daa16da27748c31a68d96f8930afcaebedbe061c3bb32")
