-- Lua provided by RyzenAPI
-- Game: 2505210

-- MAIN APPLICATION
addappid(2505210)
-- Game: addappid(2505210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505211, 1, "b519ce581921921c7392eb8a30d8a68bc22e52cc1980d42bb505cc4bea8992a6")
