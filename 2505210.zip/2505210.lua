-- Lua provided by RyzenAPI
-- Game: Awakening Sarah

-- MAIN APPLICATION
addappid(2505210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2505211, 1, "b519ce581921921c7392eb8a30d8a68bc22e52cc1980d42bb505cc4bea8992a6")

