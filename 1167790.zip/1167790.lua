-- Lua provided by RyzenAPI 
-- Game: AppID 1167790
addappid(1167790)
addappid(1167791, 1, "bc57885e749ba7cafe4f1fc64df2fbfb34854c6fc2d215bab6111063a681e2b3")
