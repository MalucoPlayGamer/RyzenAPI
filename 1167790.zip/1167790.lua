-- Lua provided by RyzenAPI
-- Game: 絶望プリズン

-- MAIN APPLICATION
addappid(1167790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167791, 1, "bc57885e749ba7cafe4f1fc64df2fbfb34854c6fc2d215bab6111063a681e2b3")

