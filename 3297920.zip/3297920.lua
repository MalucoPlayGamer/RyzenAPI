-- Lua provided by RyzenAPI
-- Game: Finity

-- MAIN APPLICATION
addappid(3297920)

