-- Lua provided by RyzenAPI
-- Game: City Rush

-- MAIN APPLICATION
addappid(609400)
-- Game: addappid(609400)

-- MAIN APP DEPOTS / PACKAGES
addappid(609401, 1, "1e5090fefcb78af28d66e0092d3df875a917f99ea97ec6eb0d99e9f833d8e44e")
