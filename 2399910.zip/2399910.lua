-- Lua provided by RyzenAPI
-- Game: Byakuya Museum

-- MAIN APPLICATION
addappid(2399910)
addappid(3763530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399911, 1, "4d4a0639998c5613ef27a316980a362bd1f2141af4ef27ada817b05c89b200b0")
