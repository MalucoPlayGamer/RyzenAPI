-- Lua provided by RyzenAPI
-- Game: 561970

-- MAIN APPLICATION
addappid(561970)
-- Game: addappid(561970)

-- MAIN APP DEPOTS / PACKAGES
addappid(561971, 1, "21d9066a708a2f36d5d64d72f82ab8d660b9fef5c702ee9c1336eea72a072d1a")
