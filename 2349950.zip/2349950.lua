-- Lua provided by RyzenAPI
-- Game: Riddles And Sieges

-- MAIN APPLICATION
addappid(2349950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349951, 1, "81ad29c4888fbfd7d8534cb008620b09ab15c0fe5b3140d6ab646ad837ac8531")
