-- Lua provided by RyzenAPI
-- Game: Game: Trucker Horror

-- MAIN APPLICATION
addappid(3565050)
-- Game: addappid(3565050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3565051, 1, "c6cd60b8e918145f798f96dbf1ae8ec140ec0a7425bfffc64cf8b56a5792629b")
