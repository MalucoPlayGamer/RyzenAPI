-- Lua provided by RyzenAPI
-- Game: Malevolent Madness

-- MAIN APPLICATION
addappid(3290550)
-- Game: addappid(3290550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3290551, 1, "52c7b0fda9f0f1fe19dde9739838f4b1d16f8ebd1d0dfd5a1ca6dbeb692fc8e4")
