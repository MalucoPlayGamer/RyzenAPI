-- Lua provided by RyzenAPI
-- Game: Malevolent Madness

-- MAIN APPLICATION
addappid(3290550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3290551, 1, "52c7b0fda9f0f1fe19dde9739838f4b1d16f8ebd1d0dfd5a1ca6dbeb692fc8e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
