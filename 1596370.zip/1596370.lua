-- Lua provided by RyzenAPI
-- Game: Beat Souls

-- MAIN APPLICATION
addappid(1596370)
-- Game: addappid(1596370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1596371, 1, "da2b78f89b15d6ee9f53e722a41316eb785da8257562c5067c1372ec6dcbe756")
