-- Lua provided by SkyAPI 
-- Game: Beat Souls
addappid(1596370)
addappid(1596371, 1, "da2b78f89b15d6ee9f53e722a41316eb785da8257562c5067c1372ec6dcbe756")
