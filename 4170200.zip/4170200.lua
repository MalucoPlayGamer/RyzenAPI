-- 4170200's Lua and Manifest Created by Hubcap Manifest
-- Data Center
-- Created: April 23, 2026 at 08:19:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4170200, 1, "ed87555792dae9a2071746836b8a575889f8684a85b7aabd360b160eba879d17") -- Data Center
-- MAIN APP DEPOTS
addappid(4170201, 1, "ad41cc3a2bf95bb5607b3d479a26ea1dd53d954aeb040c6a236b3b5e71380e7c") -- Depot 4170201
setManifestid(4170201, "4106044841750946927", 1822594655)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4540490) -- Supporter Pack