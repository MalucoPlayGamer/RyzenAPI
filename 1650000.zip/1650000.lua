-- Lua provided by RyzenAPI
-- Game: 1650000

-- MAIN APPLICATION
addappid(1650000)
addappid(1650004)
addappid(1650005)
-- Game: addappid(1650000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650000,0,"83d2b0c33c7e8ae35dde123957d089fd47574181e20b113cd4be6d21635c447b")
