-- Lua provided by SkyAPI 
-- Game: AppID 1124400
addappid(1124400)
addappid(1124401, 1, "72977830d28e5202484eaa383b0d19aad03322013834dd4bf3b780c9280339c0")
