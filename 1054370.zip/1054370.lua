-- Lua provided by RyzenAPI
-- Game: addappid(1054370)

-- MAIN APPLICATION
addappid(1054370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054373,0,"f6a7d3fd4812592ee2e1c3f2c81509f6467ea51e8e56ac26dd7ba9bbc927a6ab")
