-- Lua provided by RyzenAPI
-- Game: Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.5「昏い匣の上」

-- MAIN APPLICATION
addappid(2307100)
-- Game: addappid(2307100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307101, 1, "97ef41cfac931d1aa865763b83a547a75df6b1e79262301eff7c8162d6059bec")
