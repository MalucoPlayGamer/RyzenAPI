-- Lua provided by RyzenAPI
-- Game: 2307100

-- MAIN APPLICATION
addappid(2307100)
-- Game: addappid(2307100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307101, 1, "97ef41cfac931d1aa865763b83a547a75df6b1e79262301eff7c8162d6059bec")
