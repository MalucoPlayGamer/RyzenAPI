-- Lua provided by RyzenAPI
-- Game: Game: AppID 397980

-- MAIN APPLICATION
addappid(397980)
-- Game: addappid(397980)

-- MAIN APP DEPOTS / PACKAGES
addappid(397981, 1, "de55260647e8d77482f57e02c1452730af5b052b4765d3194f90992255d7eef8")
