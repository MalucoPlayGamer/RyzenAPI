-- Lua provided by RyzenAPI
-- Game: Game: THE SOUL HUNTER

-- MAIN APPLICATION
addappid(1047140)
-- Game: addappid(1047140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047141, 1, "107dc48d63285f21cabed1f8c10bc81a13bfde4c6dceb7337261c581c333e407")
