-- Lua provided by RyzenAPI
-- Game: Farewells clicker

-- MAIN APPLICATION
addappid(4264950) -- Farewells clicker

-- MAIN APP DEPOTS / PACKAGES
addappid(4264951, 1, "d4b68ad6e26c68a2a1a1728014be106e57ed8e6d2f25c90c003f353c6d4de8ab") -- Depot 4264951
addappid(4264952, 1, "1baaee488cfab9beb84ec01da52cab58a116d7852ac270c2ef7fe7384054f14f") -- Depot 4264952

