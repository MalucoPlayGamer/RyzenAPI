-- 4264950's Lua and Manifest Created by Hubcap Manifest
-- Farewells clicker
-- Created: August 17, 2026 at 10:31:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4264950) -- Farewells clicker
-- MAIN APP DEPOTS
addappid(4264951, 1, "d4b68ad6e26c68a2a1a1728014be106e57ed8e6d2f25c90c003f353c6d4de8ab") -- Depot 4264951
setManifestid(4264951, "6873064080116979332", 265484946)
addappid(4264952, 1, "1baaee488cfab9beb84ec01da52cab58a116d7852ac270c2ef7fe7384054f14f") -- Depot 4264952
setManifestid(4264952, "8226968253661068700", 338159523)