-- Lua provided by RyzenAPI 
-- Game: AppID 1720630
addappid(1720630)
addappid(1720631, 1, "2f96e5686daf2f5a7960bdc53280643cf55321b4d0ed43dd79a3b630baff4978")
addappid(1720632, 1, "708311406e514e6e51b6c8752584bc236bacc44d93beb2543871277b3dd28bd1")
