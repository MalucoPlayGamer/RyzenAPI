-- Lua provided by RyzenAPI
-- Game: Deal With Nyarlathotep

-- MAIN APPLICATION
addappid(2442260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442262,0,"68baab5e12c247f51f6caf755f61297430bd5e55ca42d32c3d35451968b2c81d")

