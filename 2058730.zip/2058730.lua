-- Lua provided by RyzenAPI
-- Game: addappid(2058730)

-- MAIN APPLICATION
addappid(2058730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058731, 1, "f3c7453bcd57bbbad6ba89fc2cf37a0d69922f0fdc6393b9a4b03b6434d61657")
