-- Lua provided by RyzenAPI
-- Game: The Darkest Files

-- MAIN APPLICATION
addappid(2058730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058731, 1, "f3c7453bcd57bbbad6ba89fc2cf37a0d69922f0fdc6393b9a4b03b6434d61657")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3612880)
addappid(4856260)
