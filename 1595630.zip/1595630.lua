-- Lua provided by RyzenAPI
-- Game: Game: Underwater Life

-- MAIN APPLICATION
addappid(1595630)
-- Game: addappid(1595630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595631, 1, "f31bc45234eb9439fdcbdf564cdc9cc4ab72bee935222bda832217219387fa5a")
