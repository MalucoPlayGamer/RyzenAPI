-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Weeknd - "Starboy" (feat. Daft Punk)

-- MAIN APPLICATION
addappid(2195477)
-- Game: addappid(2195477)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195477,0,"7c479592043b31d341ce4ce58f2554104eafb8e7de9d7b6c6a1ba1ca66b29b77")
