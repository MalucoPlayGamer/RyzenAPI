-- Lua provided by RyzenAPI
-- Game: addappid(2175510)

-- MAIN APPLICATION
addappid(2175510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175511, 1, "93333baba0c2d583b8b55e3be8ffa86db56b93a7cf3dd481b223c3952174e1fc")
