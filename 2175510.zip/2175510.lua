-- Lua provided by RyzenAPI 
-- Game: CampNight
addappid(2175510)
addappid(2175511, 1, "93333baba0c2d583b8b55e3be8ffa86db56b93a7cf3dd481b223c3952174e1fc")
