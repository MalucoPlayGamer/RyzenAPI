-- Lua provided by RyzenAPI
-- Game: Game: Drag Deal

-- MAIN APPLICATION
addappid(2112730)
-- Game: addappid(2112730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112731, 1, "2e20b84ac2fdf6c21bcaf5ac5292a86b0575426fe73f9fd401ad1389a5dba618")
