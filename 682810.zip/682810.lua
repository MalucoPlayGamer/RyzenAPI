-- Lua provided by RyzenAPI
-- Game: GUTS

-- MAIN APPLICATION
addappid(682810)
addappid(752870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(682811, 1, "1360149ed5debc1481cf3e7e2bf782dc7e41be5ebd9ff2b49233e162f0825959")

