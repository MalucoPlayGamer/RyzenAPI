-- Lua provided by RyzenAPI
-- Game: Game: GUTS

-- MAIN APPLICATION
addappid(682810)
addappid(752870)
-- Game: addappid(682810)

-- MAIN APP DEPOTS / PACKAGES
addappid(682811, 1, "1360149ed5debc1481cf3e7e2bf782dc7e41be5ebd9ff2b49233e162f0825959")
