-- Lua provided by RyzenAPI
-- Game: Planet B24

-- MAIN APPLICATION
addappid(1675640)
-- Game: addappid(1675640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675641, 1, "d02a16cd5993f77a96d9ca2ba848a1a5a9797535c56d2519e161fb1c9bad044b")
