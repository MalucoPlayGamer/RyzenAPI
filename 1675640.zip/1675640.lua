-- Lua provided by RyzenAPI
-- Game: Planet B24

-- MAIN APPLICATION
addappid(1675640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1675641, 1, "d02a16cd5993f77a96d9ca2ba848a1a5a9797535c56d2519e161fb1c9bad044b")

