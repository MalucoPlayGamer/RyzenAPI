-- Lua provided by RyzenAPI
-- Game: addappid(1506250)

-- MAIN APPLICATION
addappid(1506250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506251, 1, "9fd017fd56b23f0d2617b43d5b56fb24c47e6a504364d471f89ea6e9de44dc16")
