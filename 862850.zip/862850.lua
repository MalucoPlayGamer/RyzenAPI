-- Lua provided by RyzenAPI
-- Game: The Great Story of a Mighty Hero - Remastered

-- MAIN APPLICATION
addappid(862850)

-- MAIN APP DEPOTS / PACKAGES
addappid(862851, 1, "e7cf91a39da48129965e796de1755a23ce5edcada32544c9416308cc59a77363")
