-- Lua provided by RyzenAPI
-- Game: Wild Castle

-- MAIN APPLICATION
addappid(1034170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034175,0,"5e2ada32242e3b11bdf53c9d127e61b6f301adb339903264741615d1ed7725b5")

