-- Lua provided by RyzenAPI
-- Game: 家园（Home Land）

-- MAIN APPLICATION
addappid(1051170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051171, 1, "f5427600c03c3dcc63933d2dd2b0768c82c743e8c98a13bd21ed7faafa4c5cff")
