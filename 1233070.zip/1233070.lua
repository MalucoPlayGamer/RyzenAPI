-- Lua provided by RyzenAPI
-- Game: Game: Isles of Sea and Sky

-- MAIN APPLICATION
addappid(1233070)
-- Game: addappid(1233070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233071, 1, "917b879c12298a2d548833669d821a419b9e3b559872873f999d1969646e9c7f")
