-- Lua provided by SkyAPI 
-- Game: Lamia's Plan NSFW DLC
addappid(1674480)
addappid(1674481, 1, "3a44649e6d53ed17510f8db7a46c69f8c3cf85e308043bdcc0e20f76f8955f29")
