-- Lua provided by RyzenAPI
-- Game: Lamia's Plan NSFW DLC

-- MAIN APPLICATION
addappid(1674480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674481, 1, "3a44649e6d53ed17510f8db7a46c69f8c3cf85e308043bdcc0e20f76f8955f29")

