-- Lua provided by RyzenAPI
-- Game: Game: Mystical Maritime Adventure

-- MAIN APPLICATION
addappid(3137240)
-- Game: addappid(3137240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137241, 1, "28145c9aa9e1e4f2c08ef823c497f607835b02ce2186b57970ea46e3fcde27bd")
