-- Lua provided by RyzenAPI
-- Game: Parquet

-- MAIN APPLICATION
addappid(1662840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1662841, 1, "8b576122479cbe8a136e652ede790011ce57867852f4c10356c1be209f402137")

