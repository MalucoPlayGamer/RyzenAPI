-- Lua provided by RyzenAPI
-- Game: Game: Synthwave Hop

-- MAIN APPLICATION
addappid(1423280)
-- Game: addappid(1423280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423281, 1, "f61bb9566275fdfea0845c0462805343dad937c549953208eb37ae974220ab6c")
