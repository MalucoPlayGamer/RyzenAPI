-- Lua provided by RyzenAPI
-- Game: Larcenauts

-- MAIN APPLICATION
addappid(421190)

-- MAIN APP DEPOTS / PACKAGES
addappid(421191, 1, "5b33cfa0942c98ae6659a156b63c44d7b321879d2d4af4be52a4c1229b28c71f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
