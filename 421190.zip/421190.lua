-- Lua provided by RyzenAPI
-- Game: Game: Larcenauts

-- MAIN APPLICATION
addappid(421190)
-- Game: addappid(421190)

-- MAIN APP DEPOTS / PACKAGES
addappid(421191, 1, "5b33cfa0942c98ae6659a156b63c44d7b321879d2d4af4be52a4c1229b28c71f")
