-- Lua provided by RyzenAPI
-- Game: 1206200

-- MAIN APPLICATION
addappid(1206200)
-- Game: addappid(1206200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206200,0,"634db241a3f4000ce8cde76f15b56686f7dcd983aacae9869864dbdbc9afa4a0")
