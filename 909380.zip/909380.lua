-- Lua provided by RyzenAPI
-- Game: 中医模拟器

-- MAIN APPLICATION
addappid(909380)

-- MAIN APP DEPOTS / PACKAGES
addappid(909381, 1, "11b2423c116894db29d9a4ed0d0dc7d9df52cdb07cd38942833d463e06ba8e46")

