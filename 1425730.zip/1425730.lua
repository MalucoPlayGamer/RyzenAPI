-- Lua provided by SkyAPI 
-- Game: Gal*Gun Returns
addappid(1425730)
addappid(1425731, 1, "f7519fe85a81d89f6b80786cc9bfb57ee23e0bcd618aa623af64e55602cf57a3")
