-- Lua provided by RyzenAPI
-- Game: addappid(1425730)

-- MAIN APPLICATION
addappid(1425730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425731, 1, "f7519fe85a81d89f6b80786cc9bfb57ee23e0bcd618aa623af64e55602cf57a3")
