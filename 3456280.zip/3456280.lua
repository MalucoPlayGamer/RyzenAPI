-- Lua provided by RyzenAPI
-- Game: Game: Kickback Soundtrack

-- MAIN APPLICATION
addappid(3456280)
-- Game: addappid(3456280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456281, 1, "bfa20acc65b2a9920364f588875dc0518d81ce9c010f73449f2281c39013e691")
