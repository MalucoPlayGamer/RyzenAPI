-- Lua provided by RyzenAPI
-- Game: Unborne

-- MAIN APPLICATION
addappid(645150)

-- MAIN APP DEPOTS / PACKAGES
addappid(645151,0,"92e9d26aa148ded87b09bd11f96edc0401eb3473a54c01ebaabb7eeb87af1fba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
