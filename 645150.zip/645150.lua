-- Lua provided by RyzenAPI
-- Game: Unborne

-- MAIN APPLICATION
addappid(645150)

-- MAIN APP DEPOTS / PACKAGES
addappid(645151,0,"92e9d26aa148ded87b09bd11f96edc0401eb3473a54c01ebaabb7eeb87af1fba")

