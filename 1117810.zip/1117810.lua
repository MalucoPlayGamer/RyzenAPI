-- Lua provided by RyzenAPI
-- Game: Git Gud or Get Rekt

-- MAIN APPLICATION
addappid(1117810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117811, 1, "f09708031fda029e60ac183db40fdcc11135bb36aede3bfb51d9f0b90745f71f")
addappid(1117812, 1, "a15fa1a71b8fdf92b16217637d8ad1169dcbdd1d48444556143d10ae05c1b148")
addappid(1117813, 1, "c90691a569d6ef40ee8050fec7faf780b091972b571798f0f04bf2c00915e5d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
