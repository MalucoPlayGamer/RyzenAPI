-- Lua provided by RyzenAPI 
-- Game: Git Gud or Get Rekt
addappid(1117810)
addappid(1117811, 1, "f09708031fda029e60ac183db40fdcc11135bb36aede3bfb51d9f0b90745f71f")
addappid(1117812, 1, "a15fa1a71b8fdf92b16217637d8ad1169dcbdd1d48444556143d10ae05c1b148")
addappid(1117813, 1, "c90691a569d6ef40ee8050fec7faf780b091972b571798f0f04bf2c00915e5d7")
