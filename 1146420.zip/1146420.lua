-- Lua provided by RyzenAPI
-- Game: AppID 1146420

-- MAIN APPLICATION
addappid(1146420)
-- Game: addappid(1146420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146421, 1, "a44f6d0039da6584f371e7db0ac0d9a54735c8111da0a0a721b56da3fe229daf")
