-- Lua provided by RyzenAPI
-- Game: Town of Night

-- MAIN APPLICATION
addappid(546990)

-- MAIN APP DEPOTS / PACKAGES
addappid(546991, 1, "55fbc489e500d0e95d44ca62db8e5ff9d2dc5b518a5e884c064a7adf4214bd27")
