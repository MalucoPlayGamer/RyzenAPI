-- Lua provided by SkyAPI 
-- Game: AppID 546990
addappid(546990)
addappid(546991, 1, "55fbc489e500d0e95d44ca62db8e5ff9d2dc5b518a5e884c064a7adf4214bd27")
