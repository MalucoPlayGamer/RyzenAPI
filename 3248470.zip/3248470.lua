-- Lua provided by RyzenAPI
-- Game: Dollmare Demo

-- MAIN APPLICATION
addappid(3248470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3248471, 1, "bc24e4956343d43e57338f5d9c7b3423095fa7f9e3426cf46ea7eaa234835e75")

