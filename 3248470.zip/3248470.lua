-- Lua provided by RyzenAPI 
-- Game: AppID 3248470
addappid(3248470)
addappid(3248471, 1, "bc24e4956343d43e57338f5d9c7b3423095fa7f9e3426cf46ea7eaa234835e75")
