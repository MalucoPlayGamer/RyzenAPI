-- 4890280's Lua and Manifest Created by Hubcap Manifest
-- A Lucky Hunt With Rissa
-- Created: August 12, 2026 at 00:07:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4890280) -- A Lucky Hunt With Rissa
-- MAIN APP DEPOTS
addappid(4890281, 1, "45827f0fc1fd60d212f50e5ea1636618de03b1651d4e2df2b91dbe98cbb20726") -- Depot 4890281
setManifestid(4890281, "7987988069882659133", 233295633)