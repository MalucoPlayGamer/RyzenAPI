-- Lua provided by RyzenAPI
-- Game: A Lucky Hunt With Rissa

-- MAIN APPLICATION
addappid(4890280) -- A Lucky Hunt With Rissa

-- MAIN APP DEPOTS / PACKAGES
addappid(4890281, 1, "45827f0fc1fd60d212f50e5ea1636618de03b1651d4e2df2b91dbe98cbb20726") -- Depot 4890281

