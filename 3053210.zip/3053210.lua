-- Lua provided by RyzenAPI
-- Game: Sticker Delight

-- MAIN APPLICATION
addappid(3053210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3053211, 1, "1e53847b3e5c14d1b3de754695ce26db36c0cc55248578d4915904c05ab077d9")
