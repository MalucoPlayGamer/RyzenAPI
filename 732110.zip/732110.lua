-- Lua provided by RyzenAPI
-- Game: OneScreen Wagons

-- MAIN APPLICATION
addappid(732110)

-- MAIN APP DEPOTS / PACKAGES
addappid(732111, 1, "7c78863b337d4a7d1acd08d9b7cb40a3306da31f62a57723381c4d47f699eabd")

