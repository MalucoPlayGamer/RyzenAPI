-- Lua provided by RyzenAPI
-- Game: Utomah

-- MAIN APPLICATION
addappid(2076840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076841, 1, "321fee7ac44475686a5127893548826df307fa0f4e24dd1b3bf40b1b17ea3406")

