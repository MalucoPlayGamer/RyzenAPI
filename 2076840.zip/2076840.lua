-- Lua provided by RyzenAPI
-- Game: Utomah

-- MAIN APPLICATION
addappid(2076840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2076841, 1, "321fee7ac44475686a5127893548826df307fa0f4e24dd1b3bf40b1b17ea3406")

