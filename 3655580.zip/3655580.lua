-- Lua provided by RyzenAPI
-- Game: Four Divine Abidings

-- MAIN APPLICATION
addappid(3655580)
