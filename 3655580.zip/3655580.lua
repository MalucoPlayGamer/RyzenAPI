-- Lua provided by RyzenAPI
-- Game: Four Divine Abidings

-- MAIN APPLICATION
addappid(3655580)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3834680)
