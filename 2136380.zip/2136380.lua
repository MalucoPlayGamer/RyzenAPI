-- Lua provided by RyzenAPI
-- Game: HVS: Hitler VS Stalin - Battle Of Moscow

-- MAIN APPLICATION
addappid(2136380)
-- Game: addappid(2136380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136381, 1, "82968fc0f0c68969a8da7c56df1305e3efa60c9932a0eaf9e9ffae0cb5dc65b6")
