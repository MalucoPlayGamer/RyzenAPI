-- Lua provided by RyzenAPI
-- Game: 3057970

-- MAIN APPLICATION
addappid(3057970)
-- Game: addappid(3057970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057971, 1, "6b255ef9bac2102306687f17d2260f04d01f661c72d6ce4460eb74db5138f7ef")
