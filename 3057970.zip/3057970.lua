-- Lua provided by RyzenAPI 
-- Game: Time Re:Quest Demo
addappid(3057970)
addappid(3057971, 1, "6b255ef9bac2102306687f17d2260f04d01f661c72d6ce4460eb74db5138f7ef")
