-- Lua provided by RyzenAPI
-- Game: The Fabulous Fear Machine

-- MAIN APPLICATION
addappid(1540350)
-- Game: addappid(1540350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540351, 1, "c6d8e55952a2598c52b608ed99cacd12edabd01d4a40e8e23af056ac84ee1383")
addappid(1540352, 1, "d4d65c198991416d61796256c9804b3b697d60da2963b70b0602ef1a3f5a0894")
