-- Lua provided by RyzenAPI
-- Game: Palindrome Syndrome: Escape Room

-- MAIN APPLICATION
addappid(1374290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374291, 1, "b69f119b22090ef22b70e9e8134ff37f412dcaf8880326b3b5c0586fe63ad620")

