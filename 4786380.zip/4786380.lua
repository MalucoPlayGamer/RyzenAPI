-- Lua provided by RyzenAPI
-- Game: Spy Lady of Azure Sea

-- MAIN APPLICATION
addappid(4786380) -- Spy Lady of Azure Sea

-- MAIN APP DEPOTS / PACKAGES
addappid(4786381, 1, "6786337b5dc3bf6f2e5e2bcd8170cf63731fa6973c6e2f22163494adc6d77346") -- Depot 4786381
