-- Lua provided by RyzenAPI
-- Game: Game: Maze Sounds

-- MAIN APPLICATION
addappid(536630)
-- Game: addappid(536630)

-- MAIN APP DEPOTS / PACKAGES
addappid(536631, 1, "9275afe072d92a4eefbdb03e952e22e3eee86a71bee6edce82b4c2b2f2483c44")
