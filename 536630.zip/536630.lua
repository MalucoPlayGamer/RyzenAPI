-- Lua provided by RyzenAPI
-- Game: Maze Sounds

-- MAIN APPLICATION
addappid(536630)

-- MAIN APP DEPOTS / PACKAGES
addappid(536631, 1, "9275afe072d92a4eefbdb03e952e22e3eee86a71bee6edce82b4c2b2f2483c44")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
