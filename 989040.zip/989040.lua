-- Lua provided by RyzenAPI
-- Game: After Hours

-- MAIN APPLICATION
addappid(989040)
-- Game: addappid(989040)

-- MAIN APP DEPOTS / PACKAGES
addappid(989041, 1, "1371e4954b71094c30620a9cdebd82ce6d81a886e5c0f07b4787643c27a28602")
