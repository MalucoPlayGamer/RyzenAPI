-- Lua provided by RyzenAPI
-- Game: After Hours

-- MAIN APPLICATION
addappid(989040)

-- MAIN APP DEPOTS / PACKAGES
addappid(989041, 1, "1371e4954b71094c30620a9cdebd82ce6d81a886e5c0f07b4787643c27a28602")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
