-- Lua provided by RyzenAPI
-- Game: Dead Profit

-- MAIN APPLICATION
addappid(1908460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908461, 1, "263d0a07abddf2ddf8472124753a8b11e9a03f729034828204e477409b35ae5a")

