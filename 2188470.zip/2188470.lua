-- Lua provided by RyzenAPI
-- Game: Save the Queen

-- MAIN APPLICATION
addappid(2188470)
-- Game: addappid(2188470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2188471, 1, "651452003368e3714ee847903f0cdc6d2710724d30a2a8ef5166ae910fe066c7")
