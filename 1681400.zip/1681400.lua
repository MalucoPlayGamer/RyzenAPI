-- Lua provided by RyzenAPI
-- Game: Magic Adventures

-- MAIN APPLICATION
addappid(1681400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681401, 1, "65717784c28650e5e3012082df9e8cb9d02b6d5d6b1464631f13052b03a3ed4b")

