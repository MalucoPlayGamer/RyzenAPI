-- Lua provided by RyzenAPI
-- Game: Prop Hunt

-- MAIN APPLICATION
addappid(1509230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509231, 1, "1129e55d7d0e2e4ff82133e0ada1525bafad3607f85deb67a3a9980590ade596")

