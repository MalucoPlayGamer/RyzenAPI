-- Lua provided by RyzenAPI
-- Game: Game: Half-Life 2: Deathmatch

-- MAIN APPLICATION
addappid(320)
-- Game: addappid(320)

-- MAIN APP DEPOTS / PACKAGES
addappid(321, 1, "b0bec994f4c224673d9db802cbbeb979a0fa9f592177b931eea29b757afb1626")
addappid(232371, 0, "3fbbbe39644427c8246e493d36f688d88ea179b5b4ed7f4f793d470c1ae7b173")
addappid(232372, 0, "3bb7bc627ccb03b2ef3b7d84d2f16f7f5e666e20a70ce58279626f539a0b52f3")
addappid(232373, 0, "4b5b9f043f931fd4d508d962e00951f082e8a552ec8d866a2a13e1bbc8e57dde")
