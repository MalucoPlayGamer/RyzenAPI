-- Lua provided by SkyAPI 
-- Game: Lu[Idle]
addappid(3127870)
addappid(3127871, 1, "311de1dcb737273eb0b28a0cf2dafd565157472e93d67c03edf73e97077d60e8")
