-- Lua provided by RyzenAPI
-- Game: Lu[Idle]

-- MAIN APPLICATION
addappid(3127870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127871, 1, "311de1dcb737273eb0b28a0cf2dafd565157472e93d67c03edf73e97077d60e8")

