-- Lua provided by RyzenAPI
-- Game: addappid(3428850)

-- MAIN APPLICATION
addappid(3428850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428851, 1, "1ac5230aa363bdb36278e15b553704bf9be36a6e3138a020f873523079dbb3c1")
