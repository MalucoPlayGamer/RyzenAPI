-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2350250)
-- Game: addappid(2350250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350250,0,"c7c2fa61e87168d204834f88444d1332860e62d85193bb567b3c57920947444a")
