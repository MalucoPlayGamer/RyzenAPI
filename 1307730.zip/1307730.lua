-- Lua provided by RyzenAPI
-- Game: 1307730

-- MAIN APPLICATION
addappid(1307730)
-- Game: addappid(1307730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307731, 1, "09f9db9a7a124377205f6a5093651bc848aebe72339b62653cd16d84eabf5635")
