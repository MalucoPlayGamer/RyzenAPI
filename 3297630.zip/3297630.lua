-- Lua provided by RyzenAPI
-- Game: addappid(3297630)

-- MAIN APPLICATION
addappid(3297630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3297631, 1, "69f295c140b9d2d3557abc852cd21fc1635d8ea1c1cb47af8995dbc9bf5a460a")
