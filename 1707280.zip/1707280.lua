-- Lua provided by RyzenAPI
-- Game: ShiroKuro's Adventure

-- MAIN APPLICATION
addappid(1707280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1707281, 1, "b05895c13c29459da5c1300b9fb239c6cdfd7c0abfc95e7187ab1c9341f8534d")

