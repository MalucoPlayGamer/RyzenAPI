-- Lua provided by RyzenAPI
-- Game: Game: ShiroKuro's Adventure

-- MAIN APPLICATION
addappid(1707280)
-- Game: addappid(1707280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707281, 1, "b05895c13c29459da5c1300b9fb239c6cdfd7c0abfc95e7187ab1c9341f8534d")
