-- Lua provided by RyzenAPI
-- Game: Game: Last-Hit Defense

-- MAIN APPLICATION
addappid(2522530)
-- Game: addappid(2522530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522531, 1, "ffbaa512c13ae349dd925312d2c14b9f62f8549390629545cd5cd26e61c77683")
