-- Lua provided by RyzenAPI
-- Game: 1033130

-- MAIN APPLICATION
addappid(1033130)
-- Game: addappid(1033130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033131, 1, "c14fc36cb5ee5bde03c4f6bd2865413cd9843a5da8bd1b70edf27ff0c000f8fd")
