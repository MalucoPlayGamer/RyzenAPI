-- Lua provided by RyzenAPI
-- Game: Edge Islands

-- MAIN APPLICATION
addappid(2111020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111021,0,"6af5105dc0c8caa8845c7c6169d971798fdcf5d717aa87d52e4b2133bc2b6f24")

