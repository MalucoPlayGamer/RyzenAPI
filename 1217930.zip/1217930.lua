-- Lua provided by RyzenAPI
-- Game: VR Jetpack Game

-- MAIN APPLICATION
addappid(1217930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217931, 1, "30cdeaeb3d10abf90db7dcf9983df5f143c05d5391b2101c95e557ab747a9b7b")
