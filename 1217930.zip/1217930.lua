-- Lua provided by SkyAPI 
-- Game: VR Jetpack Game
addappid(1217930)
addappid(1217931, 1, "30cdeaeb3d10abf90db7dcf9983df5f143c05d5391b2101c95e557ab747a9b7b")
