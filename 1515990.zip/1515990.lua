-- Lua provided by RyzenAPI
-- Game: Dizzy Two

-- MAIN APPLICATION
addappid(1515990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515991, 1, "b7ee939a49ee53f0cd6834c81d7db607bc33932277946797d822ec036ae1b1b6")
