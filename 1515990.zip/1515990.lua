-- Lua provided by RyzenAPI
-- Game: Dizzy Two

-- MAIN APPLICATION
addappid(1515990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1515991, 1, "b7ee939a49ee53f0cd6834c81d7db607bc33932277946797d822ec036ae1b1b6")

