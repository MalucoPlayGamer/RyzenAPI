-- Lua provided by RyzenAPI 
-- Game: Tempo Mayhem
addappid(2456240)
addappid(2456241, 1, "3a8f13df2f7224088f229d8534ba78c93b993d0e7c65bc77aaa1aa0168daa08e")
