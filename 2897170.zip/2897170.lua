-- Lua provided by RyzenAPI
-- Game: Toubatsu

-- MAIN APPLICATION
addappid(2897170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897171, 1, "5929409caa8b197b507507eda310fd655f032de4bf528d4cce0852eda2deb624")
addappid(2897172, 1, "a960df8e3e90e0d923dc3d58b315a7edc8adaf94d1e50426f9298dfe19b42fd4")
addappid(2897173, 1, "8ce616c908caf3977bf7e8ddd24b92a4363623d8f8004ef29d035bf90bfbc768")
addappid(2897174, 1, "ac5c3c6004279fea492afa389d2d605adc1f52df9489b31273c7d8a9c00e9f60")

