-- Lua provided by RyzenAPI
-- Game: Strike Force Heroes Soundtrack

-- MAIN APPLICATION
addappid(2668820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668821, 1, "bd607535ea894307ca4b42e5b6082fffb245f7f353a6ccf7db3e91af69a710d5")

