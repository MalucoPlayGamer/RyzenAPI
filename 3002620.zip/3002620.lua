-- Lua provided by RyzenAPI
-- Game: Football Referee Simulator

-- MAIN APPLICATION
addappid(3002620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002621, 1, "7ebbf54c548bf412356905bbe77e7bea3d16190a7daa946b4d5ed8a0d263359e")

