-- Lua provided by RyzenAPI
-- Game: Arcane Waters

-- MAIN APPLICATION
addappid(1266340)
-- Game: addappid(1266340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266341, 1, "977fbc86445ca445bd722dfc08b470555952d46ec7e73254f3ec6384615d570f")
