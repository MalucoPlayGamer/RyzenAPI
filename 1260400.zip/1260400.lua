-- Lua provided by RyzenAPI
-- Game: Challenge Speedball

-- MAIN APPLICATION
addappid(1260400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1260401, 1, "48ec6ce81b06f0bf6e101b2d4812395d1bb486ca1bbebaa04ab0b7ecf370819a")

