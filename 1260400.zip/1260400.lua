-- Lua provided by RyzenAPI 
-- Game: Challenge Speedball
addappid(1260400)
addappid(1260401, 1, "48ec6ce81b06f0bf6e101b2d4812395d1bb486ca1bbebaa04ab0b7ecf370819a")
