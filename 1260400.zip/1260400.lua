-- Lua provided by RyzenAPI
-- Game: Challenge Speedball

-- MAIN APPLICATION
addappid(1260400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260401, 1, "48ec6ce81b06f0bf6e101b2d4812395d1bb486ca1bbebaa04ab0b7ecf370819a")
