-- Lua provided by SkyAPI 
-- Game: AppID 1511230
addappid(1511230)
addappid(1511231, 1, "2b5199abfacce51a01b6a0d3daed9a3d0f01b365eb448b580dcd331c0ed73c96")
