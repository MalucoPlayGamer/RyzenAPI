-- Lua provided by RyzenAPI
-- Game: Game: AppID 37800

-- MAIN APPLICATION
addappid(37800)
-- Game: addappid(37800)

-- MAIN APP DEPOTS / PACKAGES
addappid(37801, 1, "4db7a920dd979b555c3e4000a9edcdc1dae730639d86c727e8086dfbe3644817")
addappid(37802, 1, "56000aaca37c522bc7a2cfa71799ebdea27031b7d0588b502fd987d835298eac")
