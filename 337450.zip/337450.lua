-- Lua provided by RyzenAPI 
-- Game: Dream Tale
addappid(337450)
addappid(337451, 1, "dbdfcb02dba6a1ea8e936c548e96742c37ca390d8259f89a9197a4e3c672e50f")
