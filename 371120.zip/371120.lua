-- Lua provided by RyzenAPI
-- Game: Discouraged Workers

-- MAIN APPLICATION
addappid(371120)

-- MAIN APP DEPOTS / PACKAGES
addappid(371121, 1, "da11a662c55979af3d4557bf317e16c06f8442aba58fd3710c3497a195436856")
addappid(371122, 1, "cd22356bb920faa1979a13af17ff789f7af1899fe3796b7f10d9f7ce84c422b6")
addappid(371123, 1, "8587e8c9818ddb4ca901cfcd45fbf8e21ebc85de10c325132d91698d1113b28b")
addappid(382390, 0, "218fad1ed19d75be85804a52677dba5e0bfc475e78b8953c861a3187eec9db81")
addappid(384654, 0, "42c8e4f530bafaad8715ae2c27cfd705bfb0e00177de91ede4e34d657a7a7193")
addappid(404910, 0, "f69430c80e742d8b2690216311a23ec6d0aa469964cdd4f83866de65b06318d1")
addappid(407760, 0, "0bd8b2ec12c7bd838b34d276ee962ce78ea9a6c7ed7a528cbe1cc2c2a91d984f")
addappid(558690, 0, "8366a33f168cd22ead2f5d9b9edda6282b189b622c0ced2ad3b3069dc5735632")
addappid(1008420, 0, "212d296e00696366c7a3885557f05420f21514d1921fe6a5cbd01b5e5990d9d0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(375161)
addappid(384650)
addappid(663800)
addappid(663801)
addappid(663802)
addappid(663803)
addappid(663804)
