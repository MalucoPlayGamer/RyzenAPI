-- Lua provided by RyzenAPI
-- Game: 1194590

-- MAIN APPLICATION
addappid(1194590)
addappid(1852400)
-- Game: addappid(1194590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194591, 1, "5210f87556d612730defba328bc5015ed62ba4bbaa817bf204b60224fe20d898")
