-- Lua provided by SkyAPI 
-- Game: Star Dynasties
addappid(1194590)
addappid(1194591, 1, "5210f87556d612730defba328bc5015ed62ba4bbaa817bf204b60224fe20d898")
addappid(1852400)
