-- Lua provided by SkyAPI 
-- Game: AppID 2235150
addappid(2235150)
addappid(2235151, 1, "77857e65e8f502c6f6a2ad3b915108f9280f70097549d8d8d97646315a4b8c7d")
