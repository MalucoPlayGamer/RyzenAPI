-- Lua provided by RyzenAPI
-- Game: Game: Windah Horror Adventure 2

-- MAIN APPLICATION
addappid(2781500)
-- Game: addappid(2781500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2781501, 1, "5d52e12950e2a7bca7a700970b30bccf119b866aae6568a059d0ce38ca5225a7")
