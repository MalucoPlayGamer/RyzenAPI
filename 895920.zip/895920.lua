-- Lua provided by RyzenAPI
-- Game: addappid(895920)

-- MAIN APPLICATION
addappid(895920)

-- MAIN APP DEPOTS / PACKAGES
addappid(895921, 1, "5af493fd5d007354bf00d16f4b870e8f35e9d93a7aa24cde8a30988285ae0402")
