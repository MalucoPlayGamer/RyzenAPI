-- Lua provided by RyzenAPI
-- Game: addappid(567160)

-- MAIN APPLICATION
addappid(567160)
addappid(983470)

-- MAIN APP DEPOTS / PACKAGES
addappid(567161, 1, "556f23dfded7498c70678c6f9cee13bffb881536bc52143c806a3b2fd957d417")
