-- Lua provided by RyzenAPI
-- Game: Kopanito All-Stars Soccer

-- MAIN APPLICATION
addappid(399820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(399821, 1, "aae29de12c19a6805d9a8174d1b25b5920b6c9affd097750eb0cd27539ec5b97")
addappid(399822, 1, "7ee2333be87787e6e750a9a84fd5e991b7559669104aaf94fb0469186c10e75b")
addappid(399823, 1, "4e0b58675f582a54dd8a15a07071ba19b9c1cdac7ed9db2323d419367c24cf9f")
