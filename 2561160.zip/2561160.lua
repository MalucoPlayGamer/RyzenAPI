-- Lua provided by SkyAPI 
-- Game: AppID 2561160
addappid(2561160)
addappid(2561161, 1, "266a554446063c52a1a8062ba7e20ecfd415addcbca80888a640c5a4319f0ba5")
