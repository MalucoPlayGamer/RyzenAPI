-- Lua provided by RyzenAPI
-- Game: Only Down!

-- MAIN APPLICATION
addappid(1216870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1216872,0,"7f0685e7fdd6a5079a4a894761623f61012e07a06757a90ebd0cac0eb02eb5fb")

