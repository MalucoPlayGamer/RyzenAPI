-- Lua provided by RyzenAPI
-- Game: Only Down!

-- MAIN APPLICATION
addappid(1216870)
-- Game: addappid(1216870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216872,0,"7f0685e7fdd6a5079a4a894761623f61012e07a06757a90ebd0cac0eb02eb5fb")
