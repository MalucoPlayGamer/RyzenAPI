-- Lua provided by RyzenAPI
-- Game: Game: Last Tide

-- MAIN APPLICATION
addappid(858590)
-- Game: addappid(858590)

-- MAIN APP DEPOTS / PACKAGES
addappid(858591, 1, "c98a878e9f37c290d1f91f530098964a93101026473fec98c4e31387b9bb3042")
