-- Lua provided by RyzenAPI
-- Game: Secret Files: Tunguska

-- MAIN APPLICATION
addappid(40330)
-- Game: addappid(40330)

-- MAIN APP DEPOTS / PACKAGES
addappid(40331, 1, "e1da41cd4c864b9fc18e4273ea56dbcc3bd67eff2a6602e536a0a22f23d86c4c")
