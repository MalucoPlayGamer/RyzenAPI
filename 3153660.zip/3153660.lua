-- Lua provided by SkyAPI 
-- Game: AppID 3153660
addappid(3153660)
addappid(3153661, 1, "2999642865efdc82cc1518e20d7992f8bedc279b7ccd3bf887c2c22abb3ba07d")
