-- Lua provided by RyzenAPI
-- Game: Dwarfender

-- MAIN APPLICATION
addappid(2386590)
-- Game: addappid(2386590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386591, 1, "a0532500245737806132b04d7530f3d4c0e6387703cba4365b48fa986473c531")
