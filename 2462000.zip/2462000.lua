-- Lua provided by RyzenAPI 
-- Game: Roboom
addappid(2462000)
addappid(2462001, 1, "06bcaf7579cbaa09f72702bc7c9b2963ec872c0411d90673948d156592b92007")
