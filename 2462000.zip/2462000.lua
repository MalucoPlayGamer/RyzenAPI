-- Lua provided by RyzenAPI
-- Game: Game: Roboom

-- MAIN APPLICATION
addappid(2462000)
-- Game: addappid(2462000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462001, 1, "06bcaf7579cbaa09f72702bc7c9b2963ec872c0411d90673948d156592b92007")
