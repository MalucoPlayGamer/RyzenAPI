-- Lua provided by RyzenAPI 
-- Game: Shadow Tactics: Blades of the Shogun - Aiko's Choice - Soundtrack
addappid(1817050)
addappid(1817051, 1, "b3316ea27db83eec326fbcf63f5e622be26e49fe770de0260f5e3807f3d7049c")
addappid(1817052, 1, "aac96fe45a9a5b075c387c0c014e694dac48a739efcd1495b99e659cf444b74c")
