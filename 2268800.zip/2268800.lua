-- Lua provided by RyzenAPI
-- Game: Cockroach Simulator house of survive

-- MAIN APPLICATION
addappid(2268800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2268801, 1, "7d771048eeb5b7ce0c0ee47b0ba7c1786d4fcad0b3695e46a7e24035864eb294")
