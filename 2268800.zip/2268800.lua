-- Lua provided by RyzenAPI
-- Game: Game: AppID 2268800

-- MAIN APPLICATION
addappid(2268800)
-- Game: addappid(2268800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2268801, 1, "7d771048eeb5b7ce0c0ee47b0ba7c1786d4fcad0b3695e46a7e24035864eb294")
