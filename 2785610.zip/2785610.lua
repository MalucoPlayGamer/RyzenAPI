-- Lua provided by SkyAPI 
-- Game: Arcana Dimension Demo
addappid(2785610)
addappid(2785611, 1, "c23dc1e15baa752053b1524a37261d077f8f26966a061e7eda23b83b60a9b277")
