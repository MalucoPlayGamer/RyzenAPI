-- Lua provided by RyzenAPI
-- Game: Arcana Dimension Demo

-- MAIN APPLICATION
addappid(2785610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785611, 1, "c23dc1e15baa752053b1524a37261d077f8f26966a061e7eda23b83b60a9b277")

