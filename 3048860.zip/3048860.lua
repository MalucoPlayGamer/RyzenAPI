-- Lua provided by RyzenAPI
-- Game: Game: AppID 3048860

-- MAIN APPLICATION
addappid(3048860)
-- Game: addappid(3048860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3048861, 1, "efb4f26f327e37dc2831ab3a1674d1b091cf5c9eb648c12681ac78ad9163b8b7")
