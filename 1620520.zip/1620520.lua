-- Lua provided by RyzenAPI
-- Game: Mondealy

-- MAIN APPLICATION
addappid(1620520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1620521, 1, "eb1147614c1050062aa935ef864e8fed4aebf9ddf72e7aeb4fa715da5b09fd18")
