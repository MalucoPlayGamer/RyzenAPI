-- Lua provided by RyzenAPI
-- Game: AppID 1620520

-- MAIN APPLICATION
addappid(1620520)
-- Game: addappid(1620520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620521, 1, "eb1147614c1050062aa935ef864e8fed4aebf9ddf72e7aeb4fa715da5b09fd18")
