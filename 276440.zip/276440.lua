-- Lua provided by RyzenAPI
-- Game: Kingdom Tales: Dragons & Us

-- MAIN APPLICATION
addappid(276440)
-- Game: addappid(276440)

-- MAIN APP DEPOTS / PACKAGES
addappid(276441, 1, "032ba4071645d931aebba519796995f900afc569b07e2af38961b5ac3f46528f")
