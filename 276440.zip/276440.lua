-- Lua provided by RyzenAPI
-- Game: Kingdom Tales: Dragons & Us

-- MAIN APPLICATION
addappid(276440)

-- MAIN APP DEPOTS / PACKAGES
addappid(276441, 1, "032ba4071645d931aebba519796995f900afc569b07e2af38961b5ac3f46528f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
