-- Lua provided by RyzenAPI
-- Game: Game: AppID 1057580

-- MAIN APPLICATION
addappid(1057580)
-- Game: addappid(1057580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057581, 1, "dfbd523da2b80719c9a5c0de76ceab3033dfbdcae123d82df6852ba73d551a9a")
