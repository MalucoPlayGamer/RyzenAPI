-- Lua provided by SkyAPI 
-- Game: AppID 1057580
addappid(1057580)
addappid(1057581, 1, "dfbd523da2b80719c9a5c0de76ceab3033dfbdcae123d82df6852ba73d551a9a")
