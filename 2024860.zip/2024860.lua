-- Lua provided by RyzenAPI 
-- Game: Barista: Take Away
addappid(2024860)
addappid(2024861, 1, "a92277e85f5d186fc59f8f6d7475cc441d308c7f14875e7d052fa41e9e1166dd")
addappid(2024862, 1, "0a355a0473aa95e15171444f12e83a56154e73f7d038187a73b138bcf854828a")
addappid(2024863, 1, "b6bf10eeae28e87b78d3a3bc1a85973297e4e3dc90d5287ac1ab6b26b3544def")
