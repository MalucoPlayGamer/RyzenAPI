-- Lua provided by RyzenAPI
-- Game: Game: Girls Cairo Papyrus

-- MAIN APPLICATION
addappid(1745260)
-- Game: addappid(1745260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745261, 1, "09e2d126586c98c6b88cd840bd5eee31b226caa983c11ccd875d70199a5b2664")
addappid(1745262, 1, "c49809f9b674ac02067815c739251ed25c26a3bc622ba7f8b9f94763487fd64c")
addappid(1745263, 1, "8e4006939373d3ecf0e752871012fc13bce73115a084ab0ea37ed42896e02db6")
