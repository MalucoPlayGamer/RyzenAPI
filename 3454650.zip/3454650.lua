-- Lua provided by SkyAPI 
-- Game: BitCraft Online
addappid(3454650)
addappid(3454651, 1, "3028358ab23d74d07977119974af9ca2c729c3dd0f33b64916085b2b34a3b846")
