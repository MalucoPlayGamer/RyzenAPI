-- Lua provided by RyzenAPI
-- Game: Game: BitCraft Online

-- MAIN APPLICATION
addappid(3454650)
-- Game: addappid(3454650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3454651, 1, "3028358ab23d74d07977119974af9ca2c729c3dd0f33b64916085b2b34a3b846")
