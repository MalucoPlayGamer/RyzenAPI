-- Lua provided by RyzenAPI
-- Game: 335620

-- MAIN APPLICATION
addappid(335620)
-- Game: addappid(335620)

-- MAIN APP DEPOTS / PACKAGES
addappid(335621, 1, "678b3e7ff99c7a163c2ecf6c6ab19fc90e85bda2778f1aec6b47d5c7fad89cba")
addappid(335625, 1, "7a5ee5f16abd7018a3fff840da0f93cba2f72884cbd66f41f58ad673972f1cfe")
