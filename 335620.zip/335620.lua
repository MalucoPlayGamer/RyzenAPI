-- Lua provided by RyzenAPI
-- Game: Star Traders: Frontiers

-- MAIN APPLICATION
addappid(335620)

-- MAIN APP DEPOTS / PACKAGES
addappid(335621, 1, "678b3e7ff99c7a163c2ecf6c6ab19fc90e85bda2778f1aec6b47d5c7fad89cba")
addappid(335625, 1, "7a5ee5f16abd7018a3fff840da0f93cba2f72884cbd66f41f58ad673972f1cfe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3198060)
