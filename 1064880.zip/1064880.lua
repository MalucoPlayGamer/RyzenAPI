-- Lua provided by RyzenAPI
-- Game: Castle Of Cthulhu

-- MAIN APPLICATION
addappid(1064880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064881, 1, "8510d2fd002ae6af1d0de54e70c920ba328f56c73c2b65a01129669f4c13cd7a")
