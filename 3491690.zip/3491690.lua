-- 3491690's Lua and Manifest Created by Hubcap Manifest
-- lovebyte.exe
-- Created: August 24, 2026 at 11:37:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3491690) -- lovebyte.exe
-- MAIN APP DEPOTS
addappid(3491691, 1, "e9627fd04d019ee3b68140bb30a084e5ba88af14f333cce53efa1fc5e84c51cd") -- Depot 3491691
setManifestid(3491691, "4024678438705789088", 2174886656)
addappid(3491692, 1, "6bc8b0fded9beedc2b8ee13e6c15348eb40972de3a42d84c4b467c7e43cb8b55") -- Depot 3491692
setManifestid(3491692, "1683657132278159798", 2199533235)