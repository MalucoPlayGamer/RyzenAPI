-- Lua provided by RyzenAPI
-- Game: lovebyte.exe

-- MAIN APPLICATION
addappid(3491690) -- lovebyte.exe

-- MAIN APP DEPOTS / PACKAGES
addappid(3491691, 1, "e9627fd04d019ee3b68140bb30a084e5ba88af14f333cce53efa1fc5e84c51cd") -- Depot 3491691
addappid(3491692, 1, "6bc8b0fded9beedc2b8ee13e6c15348eb40972de3a42d84c4b467c7e43cb8b55") -- Depot 3491692

