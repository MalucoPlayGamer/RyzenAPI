-- Lua provided by RyzenAPI
-- Game: AppID 529420

-- MAIN APPLICATION
addappid(529420)
-- Game: addappid(529420)

-- MAIN APP DEPOTS / PACKAGES
addappid(529421, 1, "5c8014951b29172491102de31bf7970e4f35c85f00e8d8db37fc25b54d3fc9a5")
addappid(529423, 1, "9ca711dccf8fae52c3c7ece5a93392edc8ec6586e5b0315113c72d0f04db5ece")
addappid(529424, 1, "184abf18aba0cde48beac452cfff6b3fcd14e4e86b7093ba8173c025b43565b5")
