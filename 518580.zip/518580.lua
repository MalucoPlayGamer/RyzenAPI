-- Lua provided by SkyAPI 
-- Game: Accounting (Legacy)
addappid(518580)
addappid(518581, 1, "69d6329ebb44efab2d80ae5733060c73184f79cb6f0ba5cf6794ed8741d2685a")
