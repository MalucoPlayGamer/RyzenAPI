-- Lua provided by RyzenAPI
-- Game: Kingdom of Loot

-- MAIN APPLICATION
addappid(466220)

-- MAIN APP DEPOTS / PACKAGES
addappid(466221, 1, "0668d65e6a27ca6ca3a491b33647d178c1abe6ce40ddca460aa8d69d761a7a97")
addappid(466222, 1, "e4ae8b7d1dc8f2432119d152d1711b32253f5cfb03044715d4919a3f158cfeea")
