-- Lua provided by RyzenAPI
-- Game: Miles & Kilo

-- MAIN APPLICATION
addappid(669910)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(669911, 1, "d2698021ce575f018efc984359446cc517297e63027ca643377c3a2d1c90d0ac")
addappid(669912, 1, "d47220e4ca4d17196824585e93b2db2c2a3f012b0e8ed2d4435e2b77a6267381")

