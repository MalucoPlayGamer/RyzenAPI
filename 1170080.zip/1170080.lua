-- Lua provided by RyzenAPI
-- Game: AppID 1170080

-- MAIN APPLICATION
addappid(1170080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170081, 1, "1616174f8cdcddea4692dce9b0c7eb9ebbd16b1043ab81b14813ae8f3f67d8a6")
addappid(2080350, 0, "bd5151c3f04febcbf44e0d9600f5fbd7c1044f70eb4c4c0a1c1878eff1e6d007")
