-- Lua provided by RyzenAPI
-- Game: Corridor 15 Firts

-- MAIN APPLICATION
addappid(732040)
-- Game: addappid(732040)

-- MAIN APP DEPOTS / PACKAGES
addappid(732041, 1, "65ce5f75d07e919f91d22e025652ce394d1e74280c11364537351cf8be3469ba")
