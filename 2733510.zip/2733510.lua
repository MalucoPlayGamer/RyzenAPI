-- Lua provided by RyzenAPI
-- Game: Cardboard Fish Demo

-- MAIN APPLICATION
addappid(2733510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733511, 1, "c86f274963a4b79e84130ce652191ef592cf9198591190109eec36a89575dcf4")

