-- Lua provided by RyzenAPI
-- Game: Goat Simulator 3

-- MAIN APPLICATION
addappid(850190)
addappid(2666450)
addappid(2809180)
addappid(3204290)
addappid(3299590)
addappid(3708030)
addappid(4370220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(850191,0,"05fc8de1333cce70dc8b8f7f2e79735da8ba77bc8d8a05a2ab711bdda428c90f")

