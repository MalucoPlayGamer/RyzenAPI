-- Lua provided by RyzenAPI 
-- Game: AppID 850190
addappid(850190)
addappid(850191, 1, "05fc8de1333cce70dc8b8f7f2e79735da8ba77bc8d8a05a2ab711bdda428c90f")
