-- Lua provided by RyzenAPI
-- Game: Goat Simulator 3

-- MAIN APPLICATION
addappid(850190)
addappid(2666450)
addappid(2809180)
addappid(3204290)
addappid(3299590)
addappid(3708030)
addappid(4370220)

-- MAIN APP DEPOTS / PACKAGES
addappid(850191,0,"05fc8de1333cce70dc8b8f7f2e79735da8ba77bc8d8a05a2ab711bdda428c90f")

