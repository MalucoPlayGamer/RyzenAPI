-- Lua provided by RyzenAPI
-- Game: Ancient Gladiators Demo

-- MAIN APPLICATION
addappid(2136940)
-- Game: addappid(2136940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136941, 1, "9e966b6e8e344af51d809d29b94fb5796e46531f3478207ed047fb2c099f956b")
