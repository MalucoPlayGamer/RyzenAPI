-- Lua provided by RyzenAPI
-- Game: 그레텔과 윈슬로의 별장

-- MAIN APPLICATION
addappid(1767320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767322,0,"504b576ceaaa90173f03b98f07c414a68477bf3467561c589f46462c6dd03f99")
