-- Lua provided by SkyAPI 
-- Game: Orc Warchief: Strategy City Builder Demo
addappid(2630510)
addappid(2630511, 1, "decf9fafa4ba57c20b8d0bc30f96cc58edacd4a173453b09050d43e5447ab394")
