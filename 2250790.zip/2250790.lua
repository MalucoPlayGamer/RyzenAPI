-- Lua provided by RyzenAPI
-- Game: 東方幻想魔録W ～ The Devil of Decline

-- MAIN APPLICATION
addappid(2250790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250791, 1, "dc27977494055fbde0d337b57a3c6ee4d7177a21c8301da399c0ca94ce371029")
addappid(2250792, 1, "42cd5a900dd84baa39269bd36aec9cbd61e3417f4edd5218b7ccdbd18d8c0999")

