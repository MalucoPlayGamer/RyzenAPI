-- Lua provided by RyzenAPI
-- Game: 水箱

-- MAIN APPLICATION
addappid(2684280)
-- Game: addappid(2684280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684281, 1, "95f078d4276e7e3b09383f05bab2978ceaff0fed513d7e002ad75d541dbe82a7")
