-- Lua provided by RyzenAPI
-- Game: AppID 430410

-- MAIN APPLICATION
addappid(430410)

-- MAIN APP DEPOTS / PACKAGES
addappid(430411, 1, "6a10a32a278da0eb7ba179261bb5dfab8e857d8bd0822fd50e70f2da6e6af494")
addappid(430412, 1, "91d461126c385ffa5ff2cdaddb4e5b7f42d39ddd18835c708cc2ea8ac13c5723")
addappid(430413, 1, "4370a4a5827ef70df99d4702aea2e5dae16c598cd2f41b039a721ff6a672cff0")

