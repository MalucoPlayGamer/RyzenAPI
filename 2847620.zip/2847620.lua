-- Lua provided by RyzenAPI
-- Game: Golden Hand

-- MAIN APPLICATION
addappid(2847620) -- Golden Hand

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2847621, 1, "edfb7b1bb4aa3e1834e7718db2de0e9e7db7f79278fe18f64d5dded35a9816c0") -- Depot 2847621

