-- 2847620's Lua and Manifest Created by Hubcap Manifest
-- Golden Hand
-- Created: August 12, 2026 at 09:19:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2847620) -- Golden Hand
-- MAIN APP DEPOTS
addappid(2847621, 1, "edfb7b1bb4aa3e1834e7718db2de0e9e7db7f79278fe18f64d5dded35a9816c0") -- Depot 2847621
setManifestid(2847621, "7216078692238733846", 8017436257)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)