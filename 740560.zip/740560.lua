-- Lua provided by RyzenAPI 
-- Game: AppID 740560
addappid(740560)
addappid(740561, 1, "1da0a8b2a4704edb4c8ab34d873d8eccf38ac038a90a9591e29386a8d0617927")
