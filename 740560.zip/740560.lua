-- Lua provided by RyzenAPI
-- Game: AppID 740560

-- MAIN APPLICATION
addappid(740560)

-- MAIN APP DEPOTS / PACKAGES
addappid(740561, 1, "1da0a8b2a4704edb4c8ab34d873d8eccf38ac038a90a9591e29386a8d0617927")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
