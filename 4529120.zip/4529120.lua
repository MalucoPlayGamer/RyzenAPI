-- Lua provided by RyzenAPI
-- Game: Alice's Gaze

-- MAIN APP DEPOTS / PACKAGES
addappid(4529120, 1, "f2b35865af0ad8fba58c85f2eebe46d825158cdfb8062e07a82c6e76fcd3b018") -- Alice's Gaze
addappid(4529121, 1, "059a8acd1babf801a92d41e4273b5b3b1a023cd35e3ff0ef0480b5db5458776d") -- Depot 4529121

