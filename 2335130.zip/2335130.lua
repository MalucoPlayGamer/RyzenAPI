-- Lua provided by RyzenAPI 
-- Game: FROM ASHES, BLOOM
addappid(2335130)
addappid(2335131, 1, "192a9b612a6e3d0404b2453190a4d64a20e806d1778782265bf5d1895d82d0a8")
addappid(2335132, 1, "4b62bc67ceab06fbf279aa866b54438d5025cdf882833f12eda58476d6a2cdd0")
addappid(3003380)
