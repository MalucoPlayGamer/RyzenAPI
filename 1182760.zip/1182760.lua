-- Lua provided by RyzenAPI 
-- Game: Starlight
addappid(1182760)
addappid(1182761, 1, "0a4f148e01215955f75d09e48a54be59550ce966129b9874ece6f34573b528ca")
addappid(1195840, 0, "e2adbb1a7cecf4d264c5a7f63a75ccad1149df675fa1bb6d61309390dcaa9c4f")
