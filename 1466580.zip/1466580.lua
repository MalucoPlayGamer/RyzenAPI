-- Lua provided by RyzenAPI
-- Game: Tempus Bound

-- MAIN APPLICATION
addappid(1466580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466581, 1, "db3af90f9aace2c1c7c5ad9e04fbb80864e343f80407ff51bf03c080ad2648d8")
