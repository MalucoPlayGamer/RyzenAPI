-- Lua provided by SkyAPI 
-- Game: AppID 2160630
addappid(2160630)
addappid(2160631, 1, "f30d35fa1834df3c8564384c2078c4c5195f0a7281e8db93078e0bf098d3d342")
