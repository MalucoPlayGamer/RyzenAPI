-- Lua provided by RyzenAPI
-- Game: Game: AppID 2160630

-- MAIN APPLICATION
addappid(2160630)
-- Game: addappid(2160630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2160631, 1, "f30d35fa1834df3c8564384c2078c4c5195f0a7281e8db93078e0bf098d3d342")
