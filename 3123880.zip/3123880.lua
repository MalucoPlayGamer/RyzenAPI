-- Lua provided by RyzenAPI
-- Game: 3123880

-- MAIN APPLICATION
addappid(3123880)
-- Game: addappid(3123880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123881, 1, "93f7b3321e0ab5d6921e043b6cec9ab3574e1138b65f16b3802dff30de81c656")
