-- Lua provided by RyzenAPI
-- Game: Waifu Beach Bar

-- MAIN APPLICATION
addappid(3123880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123881, 1, "93f7b3321e0ab5d6921e043b6cec9ab3574e1138b65f16b3802dff30de81c656")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
