-- Lua provided by RyzenAPI
-- Game: Nothing to See Here

-- MAIN APPLICATION
addappid(4884050) -- Nothing to See Here

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(4884051, 1, "522987800f5c649bdf0440563c59d649090270368e97821c44cb9dce6617029a") -- Depot 4884051

