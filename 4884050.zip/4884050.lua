-- 4884050's Lua and Manifest Created by Hubcap Manifest
-- Nothing to See Here
-- Created: August 15, 2026 at 00:10:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4884050) -- Nothing to See Here
-- MAIN APP DEPOTS
addappid(4884051, 1, "522987800f5c649bdf0440563c59d649090270368e97821c44cb9dce6617029a") -- Depot 4884051
setManifestid(4884051, "2256671013448091706", 15805218892)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)