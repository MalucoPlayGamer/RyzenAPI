-- Lua provided by RyzenAPI
-- Game: BloodLust 2: Nemesis

-- MAIN APPLICATION
addappid(758080)

-- MAIN APP DEPOTS / PACKAGES
addappid(758081,0,"6ee99a0177f0f9cf1c78de1da1919d8ced4d239e84b7788543056005cbdd2531")

