-- Lua provided by RyzenAPI
-- Game: BloodLust 2: Nemesis

-- MAIN APPLICATION
addappid(758080)

-- MAIN APP DEPOTS / PACKAGES
addappid(758081,0,"6ee99a0177f0f9cf1c78de1da1919d8ced4d239e84b7788543056005cbdd2531")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
