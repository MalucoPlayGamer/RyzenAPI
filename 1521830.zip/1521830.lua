-- Lua provided by RyzenAPI
-- Game: AppID 1521830

-- MAIN APPLICATION
addappid(1521830)
-- Game: addappid(1521830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521831, 1, "246b31fcfd5a58deca53ae840fb361fdf3c96234600e145214fb3f159557de27")
