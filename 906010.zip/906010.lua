-- Lua provided by SkyAPI 
-- Game: AppID 906010
addappid(906010)
addappid(906011, 1, "dd27863c0fd14a1381ab010eb3a3e6e7a16ab3164df3f98d57481b999fa36133")
