-- Lua provided by RyzenAPI
-- Game: Game: AppID 906010

-- MAIN APPLICATION
addappid(906010)
-- Game: addappid(906010)

-- MAIN APP DEPOTS / PACKAGES
addappid(906011, 1, "dd27863c0fd14a1381ab010eb3a3e6e7a16ab3164df3f98d57481b999fa36133")
