-- Lua provided by RyzenAPI
-- Game: Super Star Path

-- MAIN APPLICATION
addappid(375120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(375121, 1, "13f22ead71d8887c4d538962d8438738e34ff41fe0ca0dd64575f44a43817cfc")
addappid(375122, 1, "eb100f0b80362c92528dc119317ac13d928b49d99d0b55ac0b10f11ae645d4fc")
addappid(375123, 1, "2e0fae9eb6304c483994f02ec8c4aa1945833e90de9e4fd04f2bdcff54a30f66")

