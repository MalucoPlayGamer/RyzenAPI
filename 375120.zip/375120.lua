-- Lua provided by SkyAPI 
-- Game: Super Star Path
addappid(375120)
addappid(375121, 1, "13f22ead71d8887c4d538962d8438738e34ff41fe0ca0dd64575f44a43817cfc")
addappid(375122, 1, "eb100f0b80362c92528dc119317ac13d928b49d99d0b55ac0b10f11ae645d4fc")
addappid(375123, 1, "2e0fae9eb6304c483994f02ec8c4aa1945833e90de9e4fd04f2bdcff54a30f66")
