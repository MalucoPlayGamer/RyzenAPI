-- Lua provided by RyzenAPI 
-- Game: AppID 1850270
addappid(1850270)
addappid(1850271, 1, "44fe6684f58c283ba25a7e134b777187b7f3bb36f8469bc91966106cad80f1d3")
