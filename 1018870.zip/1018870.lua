-- Lua provided by RyzenAPI
-- Game: Game: VR Racing

-- MAIN APPLICATION
addappid(1018870)
-- Game: addappid(1018870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018871, 1, "b9d6b68afa2a3cd53b84060c440e7c557f5784b65c10684123471f8f3fe435a8")
