-- Lua provided by RyzenAPI
-- Game: Game: 再苟一步 One More Step

-- MAIN APPLICATION
addappid(1425770)
-- Game: addappid(1425770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425771, 1, "bedac45b029374dc6feb1b4f7cadc1bb2511409f896f27690e42dbc419beda9e")
