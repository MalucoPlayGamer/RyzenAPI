-- Lua provided by SkyAPI 
-- Game: Martian Potato
addappid(1317850)
addappid(1317851, 1, "7bff7b8734e882f45c4f14f9d4e0779761995de345fe162273ad2aa0d83afd38")
