-- Lua provided by RyzenAPI
-- Game: Xenon-Runner

-- MAIN APPLICATION
addappid(2327130)
-- Game: addappid(2327130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327131, 1, "ddf2613e05acc9c325197d08968d983ddf5ff3645509cfd8324462d5aaa719bc")
