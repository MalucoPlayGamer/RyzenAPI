-- Lua provided by RyzenAPI 
-- Game: Xenon-Runner
addappid(2327130)
addappid(2327131, 1, "ddf2613e05acc9c325197d08968d983ddf5ff3645509cfd8324462d5aaa719bc")
