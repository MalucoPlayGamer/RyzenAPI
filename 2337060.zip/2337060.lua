-- Lua provided by RyzenAPI 
-- Game: Hentai Snowy
addappid(2337060)
addappid(2337061, 1, "e77d3f6f3d8ca10d9f41834b9a523b46df124f7297264853e0d4f31880b5602f")
