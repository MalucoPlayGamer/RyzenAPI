-- Lua provided by RyzenAPI 
-- Game: Speeder
addappid(1655560)
addappid(1655561, 1, "546ddb3fb5936709a8d36c17692c2eda98c6775819a65579beb806e7dd592527")
