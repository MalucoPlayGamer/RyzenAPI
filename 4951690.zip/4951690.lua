-- 4951690's Lua and Manifest Created by Hubcap Manifest
-- First Date
-- Created: August 11, 2026 at 00:20:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4951690) -- First Date
-- MAIN APP DEPOTS
addappid(4951691, 1, "266844e0e349194a236586ca29d8b95f0bf578ff30c123652faa7c96b7c2e87b") -- Depot 4951691
setManifestid(4951691, "3302186752900945485", 1382622172)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)