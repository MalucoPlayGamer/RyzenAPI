-- Lua provided by RyzenAPI
-- Game: First Date

-- MAIN APPLICATION
addappid(4951690) -- First Date

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4951691, 1, "266844e0e349194a236586ca29d8b95f0bf578ff30c123652faa7c96b7c2e87b") -- Depot 4951691

