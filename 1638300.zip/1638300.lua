-- Lua provided by RyzenAPI
-- Game: Solargene

-- MAIN APPLICATION
addappid(1638300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1638301, 1, "0642616772481bc9143398fa671663a44073b87df14e66053c1001ef32f2fecf")

