-- Lua provided by RyzenAPI 
-- Game: Solargene
addappid(1638300)
addappid(1638301, 1, "0642616772481bc9143398fa671663a44073b87df14e66053c1001ef32f2fecf")
