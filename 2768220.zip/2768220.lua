-- Lua provided by RyzenAPI
-- Game: 2768220

-- MAIN APPLICATION
addappid(2768220)
-- Game: addappid(2768220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768220,0,"d15b6fec494066fa9ecfbd19f48042c6db781c7db9336752a23b066d645c1607")
