-- Lua provided by RyzenAPI
-- Game: Last Week

-- MAIN APPLICATION
addappid(1216050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216051, 1, "a15b4809bfedf29b3b198d54053ac413fe3b0bc6781eb66fb46a8c04cc9bc0d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
