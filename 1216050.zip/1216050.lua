-- Lua provided by RyzenAPI
-- Game: Last Week

-- MAIN APPLICATION
addappid(1216050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216051, 1, "a15b4809bfedf29b3b198d54053ac413fe3b0bc6781eb66fb46a8c04cc9bc0d8")

