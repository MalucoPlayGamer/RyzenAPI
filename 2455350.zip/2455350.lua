-- Lua provided by RyzenAPI
-- Game: 2455350

-- MAIN APPLICATION
addappid(2455350)
-- Game: addappid(2455350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455351, 1, "6b56f33d8535e51297aac6ee5230beb5aa6a5d940322d29911cd8333aede9112")
