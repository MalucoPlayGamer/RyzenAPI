-- Lua provided by RyzenAPI
-- Game: VETITUM_VRC: DEMO EDITION? (Prologue)

-- MAIN APPLICATION
addappid(3213880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213881, 1, "3193502e6a3851fda77ac5e1d6b97ca9b1a808725cd33ec7af0ebbca551044c8")

