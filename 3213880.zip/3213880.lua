-- Lua provided by RyzenAPI
-- Game: 3213880

-- MAIN APPLICATION
addappid(3213880)
-- Game: addappid(3213880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213881, 1, "3193502e6a3851fda77ac5e1d6b97ca9b1a808725cd33ec7af0ebbca551044c8")
