-- Lua provided by RyzenAPI
-- Game: WW2 Rebuilder

-- MAIN APPLICATION
addappid(1573280)
addappid(4140430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573281, 1, "5f8227add21149b96e26a6c6b73cbac7f2110aeff03284c3b60be0c70f0d37fc")
addappid(2506150, 1, "94d18a67c4562d6263c4bf9927d03b5402be7e423dc5b09abb78830e9abe4034")
