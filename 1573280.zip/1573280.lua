-- Lua provided by RyzenAPI
-- Game: WW2 Rebuilder

-- MAIN APPLICATION
addappid(1573280)
addappid(4140430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1573281, 1, "5f8227add21149b96e26a6c6b73cbac7f2110aeff03284c3b60be0c70f0d37fc")
addappid(2506150, 1, "94d18a67c4562d6263c4bf9927d03b5402be7e423dc5b09abb78830e9abe4034")

