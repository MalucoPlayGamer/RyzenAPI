-- Lua provided by RyzenAPI
-- Game: setManifestid(652132,"8146377735260693572")

-- MAIN APPLICATION
addappid(652130)
-- Game: addappid(652130)

-- MAIN APP DEPOTS / PACKAGES
addappid(652132,0,"19e2fe8a00437fa60cfcb8ee12427fb9122df24a65f569bb5dc3c453e0c9b713")
