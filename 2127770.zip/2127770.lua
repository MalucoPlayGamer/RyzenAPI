-- Lua provided by RyzenAPI 
-- Game: Sagres Demo
addappid(2127770)
addappid(2127771, 1, "e1e9ec9f38a9956c16310e0c75b5e89b55ab7ff7aa904b8d29db8def143934df")
