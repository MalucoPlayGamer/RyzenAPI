-- Lua provided by RyzenAPI
-- Game: Kredolis

-- MAIN APPLICATION
addappid(1602110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1602112,0,"208c4f9524299b2864dd9477caa2165b7eb1b9f782d9482cf26be2948cca5722")

