-- Lua provided by RyzenAPI
-- Game: Kredolis

-- MAIN APPLICATION
addappid(1602110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602112,0,"208c4f9524299b2864dd9477caa2165b7eb1b9f782d9482cf26be2948cca5722")

