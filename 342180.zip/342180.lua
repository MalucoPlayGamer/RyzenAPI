-- Lua provided by RyzenAPI
-- Game: Arizona Sunshine® VR Legacy

-- MAIN APPLICATION
addappid(342180)
addappid(565280)
addappid(565800)
addappid(850210)
addappid(1074420)
addappid(1325790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(342181, 1, "bf74282e5c57cb13dca5fc0eb6251af6c8531626ccb80a0b9b591783c9684b09")
addappid(571770, 0, "7a963f638f436af0df2e6c1c77d1850f2936800395aa78930f27c0b663b11349")

