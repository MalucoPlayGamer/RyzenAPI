-- Lua provided by RyzenAPI 
-- Game: Arizona Sunshine® VR Legacy
addappid(342180)
addappid(342181, 1, "bf74282e5c57cb13dca5fc0eb6251af6c8531626ccb80a0b9b591783c9684b09")
addappid(565280)
addappid(565800)
addappid(571770, 0, "7a963f638f436af0df2e6c1c77d1850f2936800395aa78930f27c0b663b11349")
addappid(850210)
