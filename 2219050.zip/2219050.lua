-- Lua provided by RyzenAPI
-- Game: addappid(2219050)

-- MAIN APPLICATION
addappid(2219050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219051, 1, "665efb81f3b03cd04622812f9f1a740541c77ddaddd1ac3414e3fbb49f0f9684")
