-- Lua provided by RyzenAPI
-- Game: Game: Private Detective Punch Drunk

-- MAIN APPLICATION
addappid(743990)
-- Game: addappid(743990)

-- MAIN APP DEPOTS / PACKAGES
addappid(743991, 1, "2fa2bd5f9b7c00594e60406b3306eb732cf423a41f13e581bf2af8245649d81b")
