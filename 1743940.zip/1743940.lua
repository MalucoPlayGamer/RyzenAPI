-- Lua provided by RyzenAPI
-- Game: 誰是犯案者 Who is the Criminal

-- MAIN APPLICATION
addappid(1743940)
-- Game: addappid(1743940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743941, 1, "841dffe9c7959b80d18249be48b899b88f0aa25185465ce4a7088a668df1efef")
