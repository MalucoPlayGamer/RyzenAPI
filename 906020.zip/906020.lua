-- Lua provided by RyzenAPI
-- Game: AppID 906020

-- MAIN APPLICATION
addappid(906020)

-- MAIN APP DEPOTS / PACKAGES
addappid(906021, 1, "1f352821472de57c5b7a177dee89c4f8e2cbc9b0fa08d98541ecc3e44b6183e2")

