-- Lua provided by RyzenAPI
-- Game: AppID 876860

-- MAIN APPLICATION
addappid(876860)
-- Game: addappid(876860)

-- MAIN APP DEPOTS / PACKAGES
addappid(876861, 1, "d3cfed00928c9ce0bdd76ce5abc871651bd2a06c37abfd8adaf4bab41016be59")
addappid(876862, 1, "e11d9efe4673ef5983bc80ab99b1e223fc73120be70ea350664be3e593dc3355")
