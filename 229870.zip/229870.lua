-- Lua provided by RyzenAPI
-- Game: addappid(229870)

-- MAIN APPLICATION
addappid(229870)

-- MAIN APP DEPOTS / PACKAGES
addappid(229871, 1, "1f0110c33ee5269a86c4626aeb3714b2f43306d0f654c7bafae3c8ada587926b")
