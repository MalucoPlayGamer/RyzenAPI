-- 4414590's Lua and Manifest Created by Hubcap Manifest
-- Car Sales Simulator
-- Created: July 23, 2026 at 07:34:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4414590) -- Car Sales Simulator
-- MAIN APP DEPOTS
addappid(4414591, 1, "4236f7b5b806a1af95fd4b1d7a2cee7fa50cf060d53ee1a0f384e18eeae9050d") -- Depot 4414591
setManifestid(4414591, "5052789240263998400", 1920960837)
addappid(4414592, 1, "d01b4cc81431b8cbc9f41cb3711addcf1d9bdc3c7b9654d7a96e37ebb6a48acc") -- Depot 4414592
setManifestid(4414592, "3708308653985496666", 1442644048)