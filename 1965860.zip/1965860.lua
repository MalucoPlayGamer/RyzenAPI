-- Lua provided by RyzenAPI
-- Game: Let's Play Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1965860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965867,0,"0fb9d2e2e39f86e1273e14ac29806cc90ca27f48f12dd95fccb8f46ae906e7eb")
addappid(1965868,0,"776260c72ec843cffec8baccbe4f98b0d4844984e57d92ff1cd29537ed3d1eda")
addappid(1965869,0,"c27e2e8ab29220192f4cc7bb361e803c06297738f0ec63956202cf12257b426b")

