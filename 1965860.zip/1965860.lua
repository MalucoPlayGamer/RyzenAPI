-- Lua provided by RyzenAPI
-- Game: Let's Play Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1965860)
addappid(2250610)
addappid(2250611)
addappid(2250613)
addappid(2250630)
addappid(2250631)
addappid(2250632)
addappid(2250633)
addappid(2250634)
addappid(2250635)
addappid(2250636)
addappid(2250650)
addappid(2250651)
addappid(2253500)
addappid(2253501)
addappid(2253502)
addappid(2539370)
addappid(2699370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965867,0,"0fb9d2e2e39f86e1273e14ac29806cc90ca27f48f12dd95fccb8f46ae906e7eb")
addappid(1965868,0,"776260c72ec843cffec8baccbe4f98b0d4844984e57d92ff1cd29537ed3d1eda")
addappid(1965869,0,"c27e2e8ab29220192f4cc7bb361e803c06297738f0ec63956202cf12257b426b")

