-- Lua provided by RyzenAPI 
-- Game: PURGE - Three vs Blood
addappid(1843710)
addappid(1843711, 1, "72e8cb440f61a56e375e3740d7ca5702f08258666edf8bb04532e1c0960c7a25")
