-- Lua provided by SkyAPI 
-- Game: Against Great Darkness
addappid(2302150)
addappid(2302151, 1, "bcce0cf3665aac2a63fe60f1c9a60535773e447c48b8d10046615442f6a264a2")
