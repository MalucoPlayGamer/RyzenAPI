-- Lua provided by RyzenAPI
-- Game: Atelier Yumia - Recipe and Blueprint Expansion Pack "The Art of Aladiss"

-- MAIN APPLICATION
addappid(3742630)
-- Game: addappid(3742630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742630,0,"ec4a0d9dce9958c57d7f7f533243e61e1dd6f53180c4dfd6ac292951e0445386")
