-- Lua provided by RyzenAPI
-- Game: Who Knocks

-- MAIN APPLICATION
addappid(2211640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211641, 1, "7df5b809e7a89033f550f3016c9cca0b74e9c7af3cf6078b379e9c322fd73ccb")
