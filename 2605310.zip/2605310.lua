-- Lua provided by RyzenAPI 
-- Game: AppID 2605310
addappid(2605310)
addappid(2605311, 1, "10de239585c23186787d2e0cf53d7cb42cee0985507bda61237dce94d3db88d4")
