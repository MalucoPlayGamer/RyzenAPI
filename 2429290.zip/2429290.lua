-- Lua provided by RyzenAPI
-- Game: Game: AppID 2429290

-- MAIN APPLICATION
addappid(2429290)
-- Game: addappid(2429290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429291, 1, "a68b5803d25cff905ac9fdb8d81cc1c35b5c5e602255e2d9b5e4bdf4729650f6")
