-- Lua provided by RyzenAPI
-- Game: Protocol Delta

-- MAIN APPLICATION
addappid(2116690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116691, 1, "a89e70be8d29a952bcf21cc9607105fcf8bd84c3025a74ea436c5cfc1e4a7910")
