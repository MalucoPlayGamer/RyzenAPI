-- Lua provided by RyzenAPI
-- Game: Mutants: Genesis

-- MAIN APPLICATION
addappid(2138570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138571, 1, "b5e606dd475e60277c22b9470381613c56f7666f97419a6a2e5ea46bb9765e98")
