-- Lua provided by RyzenAPI
-- Game: Game: Axizon Labs: Zombies

-- MAIN APPLICATION
addappid(1280310)
-- Game: addappid(1280310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280311, 1, "6f3e71f1376095bd97811286668fa05e2fb387240afc94e381203bf26d7b5fec")
