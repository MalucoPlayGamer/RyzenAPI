-- Lua provided by RyzenAPI
-- Game: Ultimate Space Commando

-- MAIN APPLICATION
addappid(341910)

-- MAIN APP DEPOTS / PACKAGES
addappid(341911, 1, "5c13f54a17fc7d07b2d2fd9ad6fbf56e5dc9fb5b244fd169b1c240a28ae00f88")
