-- Lua provided by RyzenAPI
-- Game: Ultimate Space Commando

-- MAIN APPLICATION
addappid(341910)

-- MAIN APP DEPOTS / PACKAGES
addappid(341911, 1, "5c13f54a17fc7d07b2d2fd9ad6fbf56e5dc9fb5b244fd169b1c240a28ae00f88")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
