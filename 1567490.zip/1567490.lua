-- Lua provided by RyzenAPI
-- Game: Game: Alien Death Mob

-- MAIN APPLICATION
addappid(1567490)
-- Game: addappid(1567490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567491, 1, "c4df1a150169faf07e7354d3a8e895c2510ae3ccb5e1fc997d7737b0d1bdd586")
