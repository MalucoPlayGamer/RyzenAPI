-- Lua provided by RyzenAPI
-- Game: 西部幻想 WestFantasy

-- MAIN APPLICATION
addappid(2153390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153391, 1, "c6def9aefdef8ffaf782aef27005cdc9cc993d43591d250098b654ac89aa7b22")

