-- Lua provided by RyzenAPI 
-- Game: Paintball Playground
addappid(2808630)
addappid(2808631, 1, "cb09c93c5b73c59a6991d1fd214bd59331b6d509d88252eaf89060d93d59e059")
