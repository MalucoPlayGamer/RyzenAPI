-- Lua provided by RyzenAPI
-- Game: Rake Remastered

-- MAIN APPLICATION
addappid(2204270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204271, 1, "924738e93ecbec4740cc60bff757f79960403c13803bbcda3cd9ae45ff4f5396")
