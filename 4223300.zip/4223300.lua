-- Lua provided by RyzenAPI
-- Game: Birds of War

-- MAIN APPLICATION
addappid(4223300)

-- MAIN APP DEPOTS / PACKAGES
addappid(4223300,0,"4d526557db0c420f2297f3d0187af0457d41b1bbbefe4c3e273bfc403bf727b4")
addappid(4223301,0,"f10565d093f0b37a04379ae5c7e35d3135dc8bfe6ed4380c03e06369dac5c981")

