-- Lua provided by RyzenAPI
-- Game: Birds of War

-- MAIN APPLICATION
addappid(4223300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4223300,0,"4d526557db0c420f2297f3d0187af0457d41b1bbbefe4c3e273bfc403bf727b4")
addappid(4223301,0,"f10565d093f0b37a04379ae5c7e35d3135dc8bfe6ed4380c03e06369dac5c981")

