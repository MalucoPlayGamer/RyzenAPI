-- Lua provided by RyzenAPI
-- Game: Game: Rogue Trooper Redux

-- MAIN APPLICATION
addappid(529490)
addappid(710410)
-- Game: addappid(529490)

-- MAIN APP DEPOTS / PACKAGES
addappid(529491, 1, "d0f0670c9f1da596eb578bb109b38b25f562809e6ce027a48dc4248473e0ddfa")
