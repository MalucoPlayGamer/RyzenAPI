-- Lua provided by RyzenAPI
-- Game: Rogue Trooper Redux

-- MAIN APPLICATION
addappid(529490)
addappid(710410)

-- MAIN APP DEPOTS / PACKAGES
addappid(529491, 1, "d0f0670c9f1da596eb578bb109b38b25f562809e6ce027a48dc4248473e0ddfa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
