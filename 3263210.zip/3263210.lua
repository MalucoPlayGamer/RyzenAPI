-- Lua provided by SkyAPI 
-- Game: Subway Exorcist Girl
addappid(3263210)
addappid(3263211, 1, "d655269f17f8cf81bc9507fc7e3b8697150e175bc07e97e165744dbaa7019f5a")
