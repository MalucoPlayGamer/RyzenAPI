-- Lua provided by RyzenAPI
-- Game: Subway Exorcist Girl

-- MAIN APPLICATION
addappid(3263210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3263211, 1, "d655269f17f8cf81bc9507fc7e3b8697150e175bc07e97e165744dbaa7019f5a")

