-- Lua provided by RyzenAPI
-- Game: King's Quest

-- MAIN APPLICATION
addappid(345390)
addappid(360270)
addappid(360280)
addappid(373490)
addappid(373491)
addappid(384620)
addappid(384621)

-- MAIN APP DEPOTS / PACKAGES
addappid(345391, 1, "d4d4504b2125d6ce0354f6eabee56c58083191c70dc6d164de4701b2faef7844")
addappid(345392, 1, "b6876c56e183ab8f140817dea178ad5a2ecf805eda4721923235c431b346fc55")
addappid(345393, 1, "7a7d6785df36c4ccd3e2ccee6369dfd9299c8e34be78bac7b84575479659d448")
addappid(345394, 1, "2970194d74db9e005dcdb60191ec4a89775332a9236879aa7b36c4a15bd4d100")
addappid(345395, 1, "079f8d390405e86e9cf05e1a2bdc7e938c297d29b1f34e65c2dbca5dfee3322c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(385720)
addappid(385721)
