-- Lua provided by RyzenAPI
-- Game: Funtoon's World

-- MAIN APPLICATION
addappid(681090)
-- Game: addappid(681090)

-- MAIN APP DEPOTS / PACKAGES
addappid(681091, 1, "63f15df589e780f23186d77b17de60c6adc99c4186ab0546452a70f6a27dcd87")
