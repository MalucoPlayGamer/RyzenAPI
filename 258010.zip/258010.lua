-- Lua provided by RyzenAPI
-- Game: Ring Runner: Flight of the Sages

-- MAIN APPLICATION
addappid(258010)

-- MAIN APP DEPOTS / PACKAGES
addappid(258011, 1, "63012fac83ebd1ea98f00fa1d3f7d29d2512b9cc28b3cdd6ada833bdf9f85b08")

