-- Lua provided by RyzenAPI
-- Game: Ring Runner: Flight of the Sages

-- MAIN APPLICATION
addappid(258010)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(258011, 1, "63012fac83ebd1ea98f00fa1d3f7d29d2512b9cc28b3cdd6ada833bdf9f85b08")

