-- Lua provided by RyzenAPI
-- Game: addappid(352370)

-- MAIN APPLICATION
addappid(352370)

-- MAIN APP DEPOTS / PACKAGES
addappid(352371, 1, "4e4ae3b2276b67c30ca3256b0755e624d9fd6cfca3925e07c7b49ff92e80755c")
