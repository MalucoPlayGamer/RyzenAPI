-- Lua provided by RyzenAPI
-- Game: Game: Nemezis: Mysterious Journey III

-- MAIN APPLICATION
addappid(986350)
-- Game: addappid(986350)

-- MAIN APP DEPOTS / PACKAGES
addappid(986351, 1, "dabcebeb4f6456bf9c68a0eb13dd96c6ac62506a0186a8c2b4f1956ce10cad75")
