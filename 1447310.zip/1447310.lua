-- Lua provided by SkyAPI 
-- Game: Invisible Cock: They never saw it cumming!
addappid(1447310)
addappid(1447311, 1, "a0a35c89d317f06e42328e101a2dbe911b388da1a048b0b73ab8f076bcd524d1")
