-- Lua provided by RyzenAPI
-- Game: Skautfold: Usurper

-- MAIN APPLICATION
addappid(603020)
addappid(849130)

-- MAIN APP DEPOTS / PACKAGES
addappid(603021, 1, "6a4cfaa2f8f77f826785d05f9509f238731071eababec53615320283dad0a727")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
