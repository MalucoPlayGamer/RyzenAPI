-- Lua provided by RyzenAPI
-- Game: 603020

-- MAIN APPLICATION
addappid(603020)
addappid(849130)
-- Game: addappid(603020)

-- MAIN APP DEPOTS / PACKAGES
addappid(603021, 1, "6a4cfaa2f8f77f826785d05f9509f238731071eababec53615320283dad0a727")
