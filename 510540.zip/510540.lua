-- Lua provided by SkyAPI 
-- Game: Long Gone Days
addappid(510540)
addappid(510541, 1, "b43636ce0cf7eed111ff34001e7938998969bba5266a245e229d9c29616a3dc1")
