-- Lua provided by RyzenAPI
-- Game: SpaceBourne 2

-- MAIN APPLICATION
addappid(1646850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646851, 1, "ddb6bc7f65029e83bfb22da6f5f0f2cdc1a8889992ea53a1e1f9626657148ed1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
