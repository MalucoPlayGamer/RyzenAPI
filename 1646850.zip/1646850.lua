-- Lua provided by RyzenAPI
-- Game: Game: SpaceBourne 2

-- MAIN APPLICATION
addappid(1646850)
-- Game: addappid(1646850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646851, 1, "ddb6bc7f65029e83bfb22da6f5f0f2cdc1a8889992ea53a1e1f9626657148ed1")
