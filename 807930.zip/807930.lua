-- Lua provided by RyzenAPI
-- Game: War Of Spells

-- MAIN APPLICATION
addappid(807930)

-- MAIN APP DEPOTS / PACKAGES
addappid(807931, 1, "34a729b1b90df46a15a63e10930285f5e44442b8cb926d2272b1f41c59402ec4")

