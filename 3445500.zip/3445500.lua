-- Lua provided by RyzenAPI
-- Game: Perpetuo

-- MAIN APPLICATION
addappid(3445500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445501, 1, "716ae5c9e6106be19b2ce96720eaeac3b534a86916966ad236a8295bc779f6d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
