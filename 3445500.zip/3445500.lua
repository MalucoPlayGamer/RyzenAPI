-- Lua provided by RyzenAPI
-- Game: Perpetuo

-- MAIN APPLICATION
addappid(3445500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445501, 1, "716ae5c9e6106be19b2ce96720eaeac3b534a86916966ad236a8295bc779f6d9")
