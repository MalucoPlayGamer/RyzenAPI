-- Lua provided by RyzenAPI
-- Game: 2622260

-- MAIN APPLICATION
addappid(2622260)
addappid(2650530)
-- Game: addappid(2622260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622261, 1, "e633d037ce519e3343b9ca45b2804d31cf2fd00047a812a995fe576a92e4a385")
