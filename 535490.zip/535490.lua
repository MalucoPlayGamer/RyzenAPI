-- Lua provided by RyzenAPI
-- Game: AppID 535490

-- MAIN APPLICATION
addappid(535490)
-- Game: addappid(535490)

-- MAIN APP DEPOTS / PACKAGES
addappid(535491, 1, "ae43864cacd807c17bcd55dd630d8cb5cb86728655c8e2ab88ab98fd743e165a")
