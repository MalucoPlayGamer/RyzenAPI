-- Lua provided by RyzenAPI 
-- Game: AppID 40340
addappid(40340)
addappid(40341, 1, "49a1b64b14efc30b03a3b9882c4dce4bfacf3d957d70266c53cdbbeb3575b596")
addappid(40342, 1, "09bfbc17f1fe3195346385f1fab8f93a3d434a3b6e7aca1dbe7c6d9e34fe178c")
addappid(40343, 1, "155bb2d6e2c175c62dd93f3b9dafb20f35964592b8a15ad5cc298bf90cfc1832")
addappid(40344, 1, "6c428249f722f60439dbe80f9b40951d7e6888818f38491fdf2a4786f7a8f3c2")
addappid(40345, 1, "4ff5bd2a7e3579efeef288d06f04e76a5f1d75e9482edbed7f97876ebdae9309")
