-- Lua provided by RyzenAPI
-- Game: addappid(301950)

-- MAIN APPLICATION
addappid(301950)

-- MAIN APP DEPOTS / PACKAGES
addappid(301950,0,"262a5455ecdf5aeb1eb76ca8665e61aad81090aded5f9e26a9d2b8003f060728")
