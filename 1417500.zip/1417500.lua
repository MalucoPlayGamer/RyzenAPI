-- Lua provided by RyzenAPI
-- Game: Planet Station

-- MAIN APPLICATION
addappid(1417500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417501, 1, "e1d76d8c442701720436b1c6e13554360364fbf976d3d5322803a6486e58ac4e")

