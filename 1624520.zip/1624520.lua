-- Lua provided by RyzenAPI
-- Game: College Kings - Act II

-- MAIN APPLICATION
addappid(1624520)
-- Game: addappid(1624520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624520,0,"02bdd37c41154cda175aa55809762811fe8d4061b6b7351f864de901541a07af")
