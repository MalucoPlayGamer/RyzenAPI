-- Lua provided by RyzenAPI
-- Game: Just Chatting

-- MAIN APPLICATION
addappid(1221560)
addappid(1248900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221561, 1, "a0a5b419a121618d64d9c19386812fee05cca8e655c1b2cd5d70471277af9891")
