-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Cao Cao "Reinhard Costume" / 曹操「ラインハルト風コスチューム」

-- MAIN APPLICATION
addappid(1246840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246840,0,"aa5e0ff88ea1d20fe2c1ff4ec9675f03d6a385857f98cfd24840064608e528ae")

