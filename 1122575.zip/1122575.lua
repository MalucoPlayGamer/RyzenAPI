-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Advanced Linear Playing Exercise 2

-- MAIN APPLICATION
addappid(1122575)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122575,0,"dd20601d17c548861a488611f3a0620f36417f6a9767b2094237e67a79d69257")

