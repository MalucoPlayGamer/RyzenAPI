-- 873260's Lua and Manifest Created by Hubcap Manifest
-- Wizard Gold
-- Created: July 21, 2026 at 06:18:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(873260, 1, "5375442d1f738185482a337465323efa8c3f914b0c6f89b993925bcf3218ef02") -- Wizard Gold
-- MAIN APP DEPOTS
addappid(873262, 1, "9b4649ddbd98ae5ed7afbcdcf4aefb69da969f15e8fcf60c072004ddbea3e220") -- Depot 873262
setManifestid(873262, "3700969651587391030", 216924316)