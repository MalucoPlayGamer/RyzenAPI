-- Lua provided by RyzenAPI
-- Game: Impossible Moto Sim

-- MAIN APPLICATION
addappid(3621400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3621401, 1, "a546b303df27fc5bea2d45b00639a318e0eccc80f8a6d1bfebd066a852cb4c54")
