-- Lua provided by RyzenAPI
-- Game: AppID 312980

-- MAIN APPLICATION
addappid(312980)

-- MAIN APP DEPOTS / PACKAGES
addappid(312981, 1, "121143500e21d22fe5fa7b6bdb165e6667febc7c3515c7462095db579a26a0cd")
addappid(312982, 1, "48d2ef52490f96da3d2b2aa473f71051662bca483bcbb3a71c4b84d9147914b0")
addappid(501670, 0, "dc48e2cdf832cb28360f9da1b06165afb8aa73d277aaa598687bf3362bbb50a4")
addappid(501671, 0, "692fca99139ec27c15adf8a074328dc5371dd09cdf13f1198d41437a17a3e55d")
addappid(529690, 0, "81e1c8bd592e053308fd9e1e40063cd7898070f02f73595e4ccc562f17857782")
addappid(540820, 0, "c9094fe14d13ea1f047431a68266bb58c8a6368acb782e6c12c13311ae251047")
addappid(616290, 0, "6a71d3e0106bca5e228ead39c2d5c0facd450937c1b71be1d9c3e7422e67153b")
addappid(810380, 0, "0c2bf38371a3a3f78b4b1aee6a2580283b42f2a345257eff544744ca443bba3e")
addappid(876450, 0, "8ca06451ede48dcc48d3ca1f96f931c610c182bab2e22d07ad27683f742075eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(905050)
addappid(999490)
addappid(999550)
addappid(1057060)
addappid(1057070)
addappid(1158490)
addappid(1158491)
addappid(1246030)
addappid(1246031)
addappid(1246032)
addappid(1309230)
addappid(1534030)
addappid(1600800)
addappid(1688540)
addappid(1727300)
addappid(1752130)
addappid(1848420)
addappid(1848421)
addappid(1943790)
addappid(2349300)
addappid(2443610)
addappid(2476130)
addappid(2717580)
