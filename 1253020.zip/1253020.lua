-- Lua provided by RyzenAPI
-- Game: 1253020

-- MAIN APPLICATION
addappid(1253020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253020,0,"fb1cc13fb76b96caeeccced478f67a78588601f8f537448e5ae1d992aa559c6a")

