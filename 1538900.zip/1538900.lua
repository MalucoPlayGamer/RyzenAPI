-- Lua provided by RyzenAPI
-- Game: Untamed Tactics

-- MAIN APPLICATION
addappid(1538900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538902,0,"4b817ab658129476b7d6dc9406fea9e53c48b227ccab931eb756a574d01a66ad")

