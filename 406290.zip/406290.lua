-- Lua provided by RyzenAPI
-- Game: addappid(406290)

-- MAIN APPLICATION
addappid(406290)

-- MAIN APP DEPOTS / PACKAGES
addappid(406291, 1, "7bc940379466a56627ffaad9a453dfeef5f5077f7836e8113d7bf797e4086d10")
addappid(406292, 1, "2b5bcf0db63dfe9dcdae04b94358c24cb9487eaf004a876b3e05cef79452b516")
