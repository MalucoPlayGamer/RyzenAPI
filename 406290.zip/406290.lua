-- Lua provided by RyzenAPI
-- Game: Twilight Struggle

-- MAIN APPLICATION
addappid(406290)
addappid(558480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(406291, 1, "7bc940379466a56627ffaad9a453dfeef5f5077f7836e8113d7bf797e4086d10")
addappid(406292, 1, "2b5bcf0db63dfe9dcdae04b94358c24cb9487eaf004a876b3e05cef79452b516")

