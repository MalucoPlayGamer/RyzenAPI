-- Lua provided by RyzenAPI
-- Game: Game: AppID 1600440

-- MAIN APPLICATION
addappid(1600440)
-- Game: addappid(1600440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600441, 1, "fb95c506e09b55a2ccd326b5e0d19f990b3622265e3d76b76817d114df6c4159")
