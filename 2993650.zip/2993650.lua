-- Lua provided by RyzenAPI
-- Game: Game: AppID 2993650

-- MAIN APPLICATION
addappid(2993650)
-- Game: addappid(2993650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2993651, 1, "b075868eb8ed046c6f5239d63ccb14ffd52ad5a97bd35b837add89c426134ddc")
