-- Lua provided by RyzenAPI
-- Game: Centauri Sector

-- MAIN APPLICATION
addappid(228990)
addappid(355810)
addappid(355811)
addappid(355812)
-- Game: addappid(355810)

-- MAIN APP DEPOTS / PACKAGES
addappid(355813,0,"923da5343aa58c6004c6433891430ce0d86c84fc8cad5e70788d39cbaafadd7d")
