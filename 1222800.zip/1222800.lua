-- Lua provided by RyzenAPI
-- Game: VALKYRIE CONNECT

-- MAIN APPLICATION
addappid(1222800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222801, 1, "82e189c56319a0dda3351c528691d402764c981e8247b2202bf24f6645ee43ca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
