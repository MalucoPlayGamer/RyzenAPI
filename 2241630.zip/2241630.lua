-- Lua provided by RyzenAPI
-- Game: Julia: A Science Journey

-- MAIN APPLICATION
addappid(2241630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241631, 1, "a700a498f7343eec0715e462abbfdb262f69ae7563a41b37e65cb16e1c5dc233")
addappid(2241632, 1, "df2148a6435a097fd5adba883e7a920c2d85d08abdeb3d88a1f5d3ab8e4f518e")
addappid(2241633, 1, "3fcbb5e96f2fa02625130102e0d5325e076e1bb27d1017b0ee65fdf88542d049")

