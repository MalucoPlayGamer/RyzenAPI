-- Lua provided by RyzenAPI
-- Game: Undead City

-- MAIN APPLICATION
addappid(2675820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675821, 1, "f0bf6210c578f63d59302dc69cac7ae8d657520fdb54f4b0e6528801cdb6af1a")
