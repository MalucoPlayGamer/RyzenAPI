-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Xiahou Dun "Kircheis Costume" / 夏侯惇「キルヒアイス風コスチューム」

-- MAIN APPLICATION
addappid(1246841)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246841,0,"bee9942826ff4a03d65f8a5bbb6a61135876a4a59a1fc7ec6a6eb55089c62698")

