-- Lua provided by RyzenAPI
-- Game: Hentai Coloring Game

-- MAIN APPLICATION
addappid(1493720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493721, 1, "026404054d4ca7a89bca90abceaee086d994289aa609f2e8ab4feb4dbba24bfa")

