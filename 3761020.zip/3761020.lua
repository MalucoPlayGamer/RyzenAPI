-- Lua provided by RyzenAPI
-- Game: Game: ARK: Aquatica - Luminati Suns Song

-- MAIN APPLICATION
addappid(3761020)
-- Game: addappid(3761020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3761021, 1, "014f2af8839a4964cf5c957f5fd49833d9b22717887e02c132266b3ae74951b1")
