-- 3847250's Lua and Manifest Created by Hubcap Manifest
-- Mystery Trip
-- Created: August 06, 2026 at 11:26:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3847250) -- Mystery Trip
-- MAIN APP DEPOTS
addappid(3847251, 1, "f4667e733395daeb3f1b3eabdc470570a68af7f1cf5945789f62ecacfff9b02c") -- Depot 3847251
setManifestid(3847251, "5806950097597438457", 2019147106)