-- Lua provided by RyzenAPI
-- Game: Mystery Trip

-- MAIN APPLICATION
addappid(3847250) -- Mystery Trip

-- MAIN APP DEPOTS / PACKAGES
addappid(3847251, 1, "f4667e733395daeb3f1b3eabdc470570a68af7f1cf5945789f62ecacfff9b02c") -- Depot 3847251

