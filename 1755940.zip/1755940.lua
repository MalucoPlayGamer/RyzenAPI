-- Lua provided by RyzenAPI
-- Game: PlateUp! Demo

-- MAIN APPLICATION
addappid(1755940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755941, 1, "621dce345dee758766eedcd9e30d8100e141ccccf22b0ae3b35ad8e4a02d1c45")

