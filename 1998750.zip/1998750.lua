-- Lua provided by SkyAPI 
-- Game: Guilty Gear -Strive- Original Soundtrack Necessary Discrepancy Disc 2
addappid(1998750)
addappid(1998751, 1, "29417fd6ea45f6bdb66fecf96f126dc20637c62bcc6b2e5b3e8b786c42067acd")
addappid(1998752, 1, "5076468fb90c02c82c17c09be767d009319d147b2edb3938a81a8dbd2fb25d06")
