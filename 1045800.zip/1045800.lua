-- Lua provided by RyzenAPI
-- Game: 1045800

-- MAIN APPLICATION
addappid(1045800)
-- Game: addappid(1045800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045801, 1, "8fd577ff2348e258accd021d2098d73d31905c8951ec331632c5e83d7cbdc311")
