-- Lua provided by RyzenAPI
-- Game: A Street Cat's Tale 2: Outside is Dangerous (Demo)

-- MAIN APPLICATION
addappid(2391730)
-- Game: addappid(2391730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391731, 1, "7f3c88afc54f978c67d482ba715c543f2f68586d2d2ce7248643f249a7ba2dc6")
