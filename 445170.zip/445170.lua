-- Lua provided by RyzenAPI
-- Game: Game: The Haunting of Billy Classic

-- MAIN APPLICATION
addappid(445170)
-- Game: addappid(445170)

-- MAIN APP DEPOTS / PACKAGES
addappid(445171, 1, "f2ecd2ff49baf61bac1281f1d52957f5afbda422bcdae1e1327fdb1350d776c3")
