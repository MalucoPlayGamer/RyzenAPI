-- Lua provided by RyzenAPI
-- Game: addappid(3270310)

-- MAIN APPLICATION
addappid(3270310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3270311, 1, "2232894f311073238fcaffe4ec2aa717600db16d9241242b3ccce254f4277cea")
