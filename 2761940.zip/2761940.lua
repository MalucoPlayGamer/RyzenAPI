-- Lua provided by RyzenAPI
-- Game: Haunted Arcade

-- MAIN APPLICATION
addappid(2761940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761941,0,"6ef1c5fd49d4b248ecb85def4d108206e249027364616f1700c4e7ce4473e1c2")

