-- Lua provided by RyzenAPI
-- Game: addappid(2302530)

-- MAIN APPLICATION
addappid(2302530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302531, 1, "7dba9f80fae1b1ec524bd7ec86098c23496ba5af4b2c0e9cb2362152ea3ab646")
