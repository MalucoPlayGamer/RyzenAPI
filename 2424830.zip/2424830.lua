-- Lua provided by RyzenAPI
-- Game: addappid(2424830)

-- MAIN APPLICATION
addappid(2424830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424831, 1, "6b8feca175d888e5f439caa87a744a6fedb162a730c0aaff8fb2bd16f08d1262")
