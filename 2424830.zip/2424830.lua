-- Lua provided by RyzenAPI 
-- Game: BAMG2023
addappid(2424830)
addappid(2424831, 1, "6b8feca175d888e5f439caa87a744a6fedb162a730c0aaff8fb2bd16f08d1262")
