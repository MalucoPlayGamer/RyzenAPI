-- Lua provided by RyzenAPI
-- Game: Game: Sky Oceans: Wings for Hire

-- MAIN APPLICATION
addappid(1691750)
-- Game: addappid(1691750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691751, 1, "6884b21dca6e140b010827c9904e88b77584627f52d5540202d320b785e9855d")
