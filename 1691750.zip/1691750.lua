-- Lua provided by RyzenAPI 
-- Game: Sky Oceans: Wings for Hire
addappid(1691750)
addappid(1691751, 1, "6884b21dca6e140b010827c9904e88b77584627f52d5540202d320b785e9855d")
