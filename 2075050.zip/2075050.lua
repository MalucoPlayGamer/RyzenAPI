-- Lua provided by RyzenAPI
-- Game: Boom Slingers

-- MAIN APPLICATION
addappid(2075050)
-- Game: addappid(2075050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075051, 1, "334766d52ddf740f3c0115604b6778126549866caada5689e091da27c22b355a")
