-- Lua provided by RyzenAPI
-- Game: Saturn Menace

-- MAIN APPLICATION
addappid(1776000)
-- Game: addappid(1776000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776001, 1, "d460df5cc9eeda36da4ec06fbce3847f183d2733c5e9d1d5086ab11e4316c90d")
