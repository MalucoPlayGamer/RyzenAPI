-- Lua provided by RyzenAPI
-- Game: Saturn Menace

-- MAIN APPLICATION
addappid(1776000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776001, 1, "d460df5cc9eeda36da4ec06fbce3847f183d2733c5e9d1d5086ab11e4316c90d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
