-- Lua provided by RyzenAPI
-- Game: addappid(556280)

-- MAIN APPLICATION
addappid(556280)

-- MAIN APP DEPOTS / PACKAGES
addappid(556281, 1, "b5c05eecd58b0d7cdf3c22f189663df1bcea1c2c88f4bab07905a4ea8b96a57d")
addappid(556282, 1, "0ef9ff263f4ca1b6ca6d2e80c0e7ff8498eba8cfb4da280ff40f481af6c89dd4")
