-- Lua provided by RyzenAPI
-- Game: Revenant : In Memory Of The Day

-- MAIN APPLICATION
addappid(2230420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230421, 1, "99384958f3a38715de53bd4844840c39147281c6c7c816e91747382adfe6a2ca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
