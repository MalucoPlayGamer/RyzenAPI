-- Lua provided by RyzenAPI
-- Game: Revenant : In Memory Of The Day

-- MAIN APPLICATION
addappid(2230420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230421, 1, "99384958f3a38715de53bd4844840c39147281c6c7c816e91747382adfe6a2ca")

