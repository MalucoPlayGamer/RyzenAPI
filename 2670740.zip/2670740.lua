-- Lua provided by RyzenAPI
-- Game: 2670740

-- MAIN APPLICATION
addappid(2670740)
-- Game: addappid(2670740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670741, 1, "da3d07cee4f25d37021e70d1d8cc4c97d8bef4d0ac2c1fbc57bd2080a74bcd4d")
