-- Generated with Luie @ https://lua.tools/
-- 3817250 - CICADAMATA"
-- Generated 2026-08-22 15:48:37 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(3817250)

-- Main Depots
addappid(3817251, 1, "e61394571dfc42914d50142e33ec056b1a086d7739b8c9c9bec79e52e4b58e3d")
setManifestid(3817251, "5861825353973905849", 756614428)
