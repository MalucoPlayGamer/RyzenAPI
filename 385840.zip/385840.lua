-- Lua provided by RyzenAPI
-- Game: Game: The Beard in the Mirror

-- MAIN APPLICATION
addappid(385840)
-- Game: addappid(385840)

-- MAIN APP DEPOTS / PACKAGES
addappid(385841, 1, "03b1fcaaa30373fdf96f64589c50fff7dd9cc86c13b162e376008ac327a11bd7")
