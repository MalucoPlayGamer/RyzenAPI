-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Dawn of War III

-- MAIN APPLICATION
addappid(285190)
addappid(626800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(285191, 1, "61cb95500f7f309deee0cf3f496e1aa21591997a0817a79cec79c47a9b6ed6f8")
addappid(285193, 1, "19eda48eebf52834395dd54715e03cce001bbb7df4c17b106d6928c5f1ecab31")
addappid(285194, 1, "4be86101012a3ad449bb704d72bae7c38850c70a28860269389fd4af0fdfca0f")
addappid(285195, 1, "4cb0baf3198cb62f3c83ad15f54a2091e5ba089924fab46a6ce1dffc4e24b121")
addappid(285196, 1, "ba2b65c99a218abef8cd59322dde74cd3b02de61e010db33a6aa666674c6526b")
addappid(285199, 1, "1dfd5e0d10b716f1f8e0de351eaccf4cdb5c03158038641b3b4f5d31b9952b3e")
addappid(607143, 0, "c63b76c63fd6d9fddd163fb5a2dfefc6adbdf2f7bd392eb6348b0112557d4a38")

