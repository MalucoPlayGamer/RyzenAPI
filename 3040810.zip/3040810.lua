-- Lua provided by RyzenAPI
-- Game: Green Horizon: VR Golf

-- MAIN APPLICATION
addappid(3040810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040811, 1, "0f18c8dc78c0db23aa93e0f041f619d730cb98ce5972b6885afd2b0f28da54c5")
