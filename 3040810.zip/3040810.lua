-- Lua provided by RyzenAPI
-- Game: Green Horizon: VR Golf

-- MAIN APPLICATION
addappid(3040810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3040811, 1, "0f18c8dc78c0db23aa93e0f041f619d730cb98ce5972b6885afd2b0f28da54c5")

