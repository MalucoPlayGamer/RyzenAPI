-- Lua provided by RyzenAPI 
-- Game: Rain City
addappid(1307370)
addappid(1307371, 1, "ef9cedb34a38b880716984851b7e8ed13e674232799738fe689794959423de18")
addappid(1307372, 1, "767a24571bdb793b4fee8fe2ca0904405091b45d58e31490d9eb73bb7343cce4")
