-- Lua provided by RyzenAPI
-- Game: RFVR Demo

-- MAIN APPLICATION
addappid(1794080)
-- Game: addappid(1794080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794081, 1, "32eb4a0d2876a5f0e12d1a8a2ef50775e034eebac17e0d3bf83bbbabdc056f57")
