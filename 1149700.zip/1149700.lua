-- Lua provided by RyzenAPI
-- Game: 1149700

-- MAIN APPLICATION
addappid(1149700)
-- Game: addappid(1149700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149701, 1, "848106b52d3e63f9c4f37275bc24c302828ab2c8d8ebf129f7ea8772e5dd9f01")
