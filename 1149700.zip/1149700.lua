-- Lua provided by RyzenAPI
-- Game: Dark Veer

-- MAIN APPLICATION
addappid(1149700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1149701, 1, "848106b52d3e63f9c4f37275bc24c302828ab2c8d8ebf129f7ea8772e5dd9f01")
