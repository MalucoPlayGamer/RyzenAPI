-- Lua provided by RyzenAPI
-- Game: addappid(2636990)

-- MAIN APPLICATION
addappid(2636990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636991, 1, "34a43e19cc4ca40c895d3129a1b2081cfb07b6e5488f4b0d3ec14529044c4c3c")
