-- Lua provided by RyzenAPI 
-- Game: AppID 949030
addappid(949030)
addappid(949031, 1, "a2115122760a10b4ccebffcd94c3c08c88853ab7eda55c80108d96a852c90219")
