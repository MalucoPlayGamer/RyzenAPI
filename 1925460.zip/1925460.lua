-- Lua provided by RyzenAPI
-- Game: Truck Driver: The American Dream

-- MAIN APPLICATION
addappid(1925460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925461,0,"f7240b4e73479c116f3f0b95e56c602edfd1399b9791e299e5f7450784ca6443")
