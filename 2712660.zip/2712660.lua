-- Lua provided by RyzenAPI
-- Game: 2712660

-- MAIN APPLICATION
addappid(2712660)
-- Game: addappid(2712660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712661, 1, "e99d395d8c51fd579c4e52c8c238d2993128a2dd3e6ed8dd932016a161dafb48")
