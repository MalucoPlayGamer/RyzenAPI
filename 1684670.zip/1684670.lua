-- Lua provided by SkyAPI 
-- Game: Best Forklift Operator
addappid(1684670)
addappid(1684671, 1, "3b59451f30096b3b00f1a137df32d9f6909e997c46c0513d2a4119d5960a7448")
