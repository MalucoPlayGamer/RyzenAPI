-- Lua provided by RyzenAPI
-- Game: Test Lab Inc.

-- MAIN APPLICATION
addappid(2567530)
-- Game: addappid(2567530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567531, 1, "b245e8206f2f6cea6658f44990a268cbc2d184d304103e73b3e0c22c9c05053b")
