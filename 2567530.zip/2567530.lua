-- Lua provided by RyzenAPI
-- Game: Test Lab Inc.

-- MAIN APPLICATION
addappid(2567530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2567531, 1, "b245e8206f2f6cea6658f44990a268cbc2d184d304103e73b3e0c22c9c05053b")

