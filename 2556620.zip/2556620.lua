-- Lua provided by RyzenAPI
-- Game: True Boxing VR

-- MAIN APPLICATION
addappid(2556620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556621, 1, "4d6ce6eb37e6872a180f94ba37d3de9a46e8b26e30712b134fa8c46783e070af")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
