-- Lua provided by RyzenAPI
-- Game: 2556620

-- MAIN APPLICATION
addappid(2556620)
-- Game: addappid(2556620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556621, 1, "4d6ce6eb37e6872a180f94ba37d3de9a46e8b26e30712b134fa8c46783e070af")
