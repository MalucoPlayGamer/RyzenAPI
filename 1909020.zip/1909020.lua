-- Lua provided by RyzenAPI
-- Game: 三国記II

-- MAIN APPLICATION
addappid(1909020)
addappid(1909023)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909022,0,"d6f9f648203631d0033b7c330f1ffd352addca35426ed967a049980364511eae")
