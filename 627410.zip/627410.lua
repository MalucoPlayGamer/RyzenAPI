-- Lua provided by RyzenAPI
-- Game: AppID 627410

-- MAIN APPLICATION
addappid(627410)
-- Game: addappid(627410)

-- MAIN APP DEPOTS / PACKAGES
addappid(627411, 1, "b430194590b13fa4017f86dcd41408bc8df5077b75fc2d541bad2857374a8ce1")
