-- Lua provided by SkyAPI 
-- Game: AppID 1247760
addappid(1247760)
addappid(1247761, 1, "4fa6761fd2a4a5a07b91e0fb020d368a091d4bd081d20c5f0e258e245d01e296")
