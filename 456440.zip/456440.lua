-- Lua provided by RyzenAPI
-- Game: The Orphan Dreams

-- MAIN APPLICATION
addappid(456440)
addappid(463200)

-- MAIN APP DEPOTS / PACKAGES
addappid(456441, 1, "4fa6ab6c1e45f95211a118d4f289442ed135fd5e9cba494245fc663d316e00cb")

