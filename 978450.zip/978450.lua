-- Lua provided by RyzenAPI
-- Game: Data mining 3

-- MAIN APPLICATION
addappid(978450)
-- Game: addappid(978450)

-- MAIN APP DEPOTS / PACKAGES
addappid(978451, 1, "084a554f25b649cd6fca50773af09700edcca808608317dff8348600cd2e1600")
