-- Lua provided by RyzenAPI 
-- Game: Furry Hentai Jigsaw
addappid(1804740)
addappid(1804741, 1, "693892c82608c5cfac3e110d084eda493d0719090f8f319ac5c4a395f4e14a60")
