-- Lua provided by SkyAPI 
-- Game: Danmaku Unlimited 3
addappid(450950)
addappid(450951, 1, "cd9acb4aeb0e9e56c15f5e492e5b66fd5876fbda1624d3df0cd2c579721d57a1")
