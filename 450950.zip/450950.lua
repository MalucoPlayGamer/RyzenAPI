-- Lua provided by RyzenAPI
-- Game: Danmaku Unlimited 3

-- MAIN APPLICATION
addappid(450950)
-- Game: addappid(450950)

-- MAIN APP DEPOTS / PACKAGES
addappid(450951, 1, "cd9acb4aeb0e9e56c15f5e492e5b66fd5876fbda1624d3df0cd2c579721d57a1")
