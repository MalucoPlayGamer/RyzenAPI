-- Lua provided by RyzenAPI
-- Game: Danmaku Unlimited 3

-- MAIN APPLICATION
addappid(450950)

-- MAIN APP DEPOTS / PACKAGES
addappid(450951, 1, "cd9acb4aeb0e9e56c15f5e492e5b66fd5876fbda1624d3df0cd2c579721d57a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
