-- Lua provided by RyzenAPI
-- Game: 1582900

-- MAIN APPLICATION
addappid(1582900)
-- Game: addappid(1582900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582901, 1, "11049ac8b883d2f10b7f674aac8cd1e47136c58d674999c7b87cc7c86e8c6270")
