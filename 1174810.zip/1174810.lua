-- Lua provided by RyzenAPI 
-- Game: AppID 1174810
addappid(1174810)
addappid(1174811, 1, "d0e0d0eb299a62eb823f749fab37f2f34cb6649efb43d7ec5e7958326703f71c")
