-- Lua provided by RyzenAPI
-- Game: Curse of the dungeon

-- MAIN APPLICATION
addappid(1174810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1174811, 1, "d0e0d0eb299a62eb823f749fab37f2f34cb6649efb43d7ec5e7958326703f71c")

