-- Lua provided by RyzenAPI
-- Game: Aztec Tower

-- MAIN APPLICATION
addappid(1010930)
-- Game: addappid(1010930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010931, 1, "b7e5dcb8c3cd460cd827923afed262ca6f4420b8f2c50241ee15f35af2d7ac4c")
