-- Lua provided by RyzenAPI
-- Game: Aztec Tower

-- MAIN APPLICATION
addappid(1010930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1010931, 1, "b7e5dcb8c3cd460cd827923afed262ca6f4420b8f2c50241ee15f35af2d7ac4c")

