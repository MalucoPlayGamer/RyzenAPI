-- Lua provided by RyzenAPI
-- Game: AppGameKit Studio

-- MAIN APPLICATION
addappid(1033070)
addappid(1107700)
-- addappid(2123790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024640, 1, "af443c35c4af3c8cdecf455de066a84ee02342369230cb70abf79600001d9ecf") -- AppGameKit Studio
addappid(1024641, 1, "2cc293c4f5efc989dee5d5ef94a7a2ddc28500309f147c40d5ce44c984b1f4e3") -- AppGameKit Studio Windows Content
addappid(1024642, 1, "1a1242c431ef2e7081b099697fdc2a99ee164a9a829bfc2d9c19c63c646b0f97") -- AppGameKit Studio Mac Depot
addappid(1024643, 1, "0eaff4427d81810ae5400dfc575fd8ce8fb4fc3a5a5ce0143302529e9673ed91") -- AppGameKit Studio Linux Depot
addappid(1033070, 1, "0bff7c1457be536dfd5eea6f90cedfdfca110823b311ffcb0d5028aaac76d75d") -- AppGameKit Studio - Particle Editor - Particle Editor Common Depot
addappid(1033071, 1, "3c2a98c6eb3f7a8527c022b7bbc4d75baa9310d557f1d532ff0410ccda968d76") -- AppGameKit Studio - Particle Editor - Particle Editor Windows Depot
addappid(1107700, 1, "6c34ccbd06a212f91ce657b4111f5e6d2a05de411b576da741c5f84de903d31e") -- AppGameKit Studio MEGA Media Pack - Bonus Tutorials Pack for AppGameKit Studio Depot
-- addappid(1033072, 1, "MISSING_KEY") -- AppGameKit Studio - Particle Editor - Particle Editor Mac Depot (no key available)
-- addappid(1033073, 1, "MISSING_KEY") -- AppGameKit Studio - Particle Editor - Particle Editor Linux Depot (no key available)

