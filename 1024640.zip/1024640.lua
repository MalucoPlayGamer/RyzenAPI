-- Lua provided by RyzenAPI
-- Game: Game: AppID 1024640

-- MAIN APPLICATION
addappid(1024640)
-- Game: addappid(1024640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024641, 1, "2cc293c4f5efc989dee5d5ef94a7a2ddc28500309f147c40d5ce44c984b1f4e3")
