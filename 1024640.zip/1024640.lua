-- 1024640's Lua and Manifest Created by Hubcap Manifest
-- AppGameKit Studio
-- Created: May 18, 2026 at 12:58:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 2 (1 excluded)

-- MAIN APPLICATION
addappid(1024640, 1, "af443c35c4af3c8cdecf455de066a84ee02342369230cb70abf79600001d9ecf") -- AppGameKit Studio
-- MAIN APP DEPOTS
addappid(1024641, 1, "2cc293c4f5efc989dee5d5ef94a7a2ddc28500309f147c40d5ce44c984b1f4e3") -- AppGameKit Studio Windows Content
setManifestid(1024641, "540204709663536713", 1346452817)
addappid(1024642, 1, "1a1242c431ef2e7081b099697fdc2a99ee164a9a829bfc2d9c19c63c646b0f97") -- AppGameKit Studio Mac Depot
setManifestid(1024642, "5601382715187623968", 1045061596)
addappid(1024643, 1, "0eaff4427d81810ae5400dfc575fd8ce8fb4fc3a5a5ce0143302529e9673ed91") -- AppGameKit Studio Linux Depot
setManifestid(1024643, "8135775702077968524", 1308590750)
-- DLCS WITH DEDICATED DEPOTS
-- AppGameKit Studio - Particle Editor (AppID: 1033070)
addappid(1033070)
addappid(1033070, 1, "0bff7c1457be536dfd5eea6f90cedfdfca110823b311ffcb0d5028aaac76d75d") -- AppGameKit Studio - Particle Editor - Particle Editor Common Depot
setManifestid(1033070, "2736087506963583770", 16501864)
addappid(1033071, 1, "3c2a98c6eb3f7a8527c022b7bbc4d75baa9310d557f1d532ff0410ccda968d76") -- AppGameKit Studio - Particle Editor - Particle Editor Windows Depot
setManifestid(1033071, "5454538860938704782", 19553451)
-- addappid(1033072, 1, "MISSING_KEY") -- AppGameKit Studio - Particle Editor - Particle Editor Mac Depot (no key available)
-- addappid(1033073, 1, "MISSING_KEY") -- AppGameKit Studio - Particle Editor - Particle Editor Linux Depot (no key available)
-- AppGameKit Studio MEGA Media Pack (AppID: 1107700)
addappid(1107700)
addappid(1107700, 1, "6c34ccbd06a212f91ce657b4111f5e6d2a05de411b576da741c5f84de903d31e") -- AppGameKit Studio MEGA Media Pack - Bonus Tutorials Pack for AppGameKit Studio Depot
setManifestid(1107700, "6682172390948185704", 1264351584)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- AppGameKit Studio - The Animation Sheet Editor (AppID: 2123790) - missing depot keys
-- addappid(2123790)