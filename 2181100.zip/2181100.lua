-- Lua provided by RyzenAPI
-- Game: Nevermind This

-- MAIN APPLICATION
addappid(2181100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181101, 1, "9ca081abd1105121b7d2732b7428d09abbae4034761a8f9f6eb457ce5944399a")

