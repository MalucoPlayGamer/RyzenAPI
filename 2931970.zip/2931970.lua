-- Lua provided by RyzenAPI
-- Game: cultivation of the strong

-- MAIN APPLICATION
addappid(2931970)
-- Game: addappid(2931970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2931971, 1, "9f70635c4fbfe2628953c4ef983635d415d19f7ec25d38361c9ca2140d10c572")
