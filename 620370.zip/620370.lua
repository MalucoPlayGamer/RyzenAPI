-- Lua provided by RyzenAPI
-- Game: Game: OneShot Solstice OST

-- MAIN APPLICATION
addappid(620370)
-- Game: addappid(620370)

-- MAIN APP DEPOTS / PACKAGES
addappid(620371, 1, "17ae767bbbc14bc5381210d033031c58b586bf3c05ba5ab61eddda931d28cd2b")
