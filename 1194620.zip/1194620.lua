-- Lua provided by RyzenAPI 
-- Game: AppID 1194620
addappid(1194620)
addappid(1194621, 1, "508ce8bd66183afca70319f013731ed5d618f8426d31152177c3230e53ee35a9")
