-- Lua provided by RyzenAPI
-- Game: Game: AppID 1194620

-- MAIN APPLICATION
addappid(1194620)
-- Game: addappid(1194620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194621, 1, "508ce8bd66183afca70319f013731ed5d618f8426d31152177c3230e53ee35a9")
