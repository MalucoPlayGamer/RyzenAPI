-- 4950470's Lua and Manifest Created by Hubcap Manifest
-- Tidy Up Together
-- Created: August 14, 2026 at 11:15:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4950470, 1, "fb24f95b2be0459ce4a2633718ee3eeea838876f8a09de3671c36d18061105df") -- Tidy Up Together
-- MAIN APP DEPOTS
addappid(4950471, 1, "3313045e5d2480454255e5e25de88b4eb7926627e57e3cbf5c67ebf581cb8654") -- Depot 4950471
setManifestid(4950471, "1074579634603272319", 4314833717)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)