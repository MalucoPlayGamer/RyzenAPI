-- Lua provided by RyzenAPI
-- Game: Otherlights

-- MAIN APPLICATION
addappid(2666000)
-- Game: addappid(2666000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666001, 1, "d98a52e69bb15795e054c7183d0cdadc0282abec1fd5295d68f4445be39aec0f")
