-- Lua provided by RyzenAPI
-- Game: AppID 2309240

-- MAIN APPLICATION
addappid(2309240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2309241, 1, "78a1cc7982c1d342b647eeeeb068a1e141121ce986f39ef97100bc7d49b301a2")

