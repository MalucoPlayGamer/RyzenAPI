-- Lua provided by SkyAPI 
-- Game: Heartbound
addappid(567380)
addappid(567381, 1, "dc4a2ce8d7bf9c0300e2af4f041e35e33a9aa897758ee1317192e8e4d6915c3b")
