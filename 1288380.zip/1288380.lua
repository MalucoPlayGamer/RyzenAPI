-- Lua provided by RyzenAPI
-- Game: Game: Two Bit Hero

-- MAIN APPLICATION
addappid(1288380)
-- Game: addappid(1288380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288381, 1, "3351012e179e94c02e9919cfdd24d26e6b2401a490b2f1ba7d146e6b75d097a2")
