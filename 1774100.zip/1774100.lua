-- Lua provided by RyzenAPI 
-- Game: Pet idle
addappid(1774100)
addappid(1774101, 1, "d4590f8f21de19baafe1530c7c65bc6127ca5f74744b3689f85174a247b1a2e2")
