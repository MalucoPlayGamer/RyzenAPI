-- Lua provided by RyzenAPI
-- Game: Kingdom Rush 5: Alliance TD

-- MAIN APPLICATION
addappid(2849080)
addappid(3368630)
addappid(3732970)
addappid(4260510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2849081,0,"e00df48b38c967f303c37f758389ff8e15505ab4416c522ea62ef425884d3849")
addappid(2849082,0,"4982ecd61fd529c34e6519a1a5004121f93ebb0e60d14d161fa95e4851ea8a32")
addappid(2849083,0,"3d8ca2d9a2a948ec35d8046112d2bf42f03f46ae30dae1b842c8ec4dd26d285f")

