-- Lua provided by RyzenAPI 
-- Game: Kingdom Rush 5: Alliance TD
addappid(2849080)
addappid(2849081, 1, "e00df48b38c967f303c37f758389ff8e15505ab4416c522ea62ef425884d3849")
addappid(2849082, 1, "4982ecd61fd529c34e6519a1a5004121f93ebb0e60d14d161fa95e4851ea8a32")
addappid(2849083, 1, "3d8ca2d9a2a948ec35d8046112d2bf42f03f46ae30dae1b842c8ec4dd26d285f")
