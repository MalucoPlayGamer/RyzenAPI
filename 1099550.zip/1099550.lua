-- Lua provided by RyzenAPI
-- Game: 3D Organon

-- MAIN APPLICATION
addappid(1099550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099551, 1, "a5f1c62741607a0cb20569d7d52d5b8db55ab0daf879b43e7c79d69bb14959e3")
addappid(1099552, 1, "de0af5e0cad4ab0d4e74b3ebb7ad598f20cec958a6e85da9af417bf97e99ca65")

