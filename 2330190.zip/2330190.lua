-- Lua provided by SkyAPI 
-- Game: Chests, City, Clicker
addappid(2330190)
addappid(2330191, 1, "d93618276ae5bbbf930e33d2a4127427db1dcd61d7bdf0189b394e87c2b2b3ef")
