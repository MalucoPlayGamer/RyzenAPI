-- Lua provided by RyzenAPI
-- Game: addappid(2330190)

-- MAIN APPLICATION
addappid(2330190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330191, 1, "d93618276ae5bbbf930e33d2a4127427db1dcd61d7bdf0189b394e87c2b2b3ef")
