-- Lua provided by RyzenAPI
-- Game: Limbo Revolution

-- MAIN APPLICATION
addappid(2305930)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(2305932,0,"546be60adb818bfb72feb2132fee281f4214cec6656d2db5b7b98f196cc1ba36")

