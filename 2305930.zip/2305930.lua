-- Lua provided by RyzenAPI
-- Game: Limbo Revolution

-- MAIN APPLICATION
addappid(2305930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305932,0,"546be60adb818bfb72feb2132fee281f4214cec6656d2db5b7b98f196cc1ba36")

