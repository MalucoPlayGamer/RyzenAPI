-- Lua provided by RyzenAPI 
-- Game: AppID 738430
addappid(738430)
addappid(738431, 1, "cb8983ba8fd318d29f59f2cb8e02de13cc033ddf0f0bb7b9584c33b05676a8c0")
