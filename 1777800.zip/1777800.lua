-- Lua provided by RyzenAPI
-- Game: addappid(1777800)

-- MAIN APPLICATION
addappid(1777800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777801, 1, "025ac163928fd32b98cd4a756efac502c5079b5f163ef108133baaa9a2147687")
