-- Lua provided by RyzenAPI
-- Game: Deep Below

-- MAIN APPLICATION
addappid(526470)

-- MAIN APP DEPOTS / PACKAGES
addappid(526471, 1, "227573b0e4c4a5244193d88c03560d27127d18648b9e894bca673c35bcd22f7c")

