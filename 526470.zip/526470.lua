-- Lua provided by RyzenAPI 
-- Game: AppID 526470
addappid(526470)
addappid(526471, 1, "227573b0e4c4a5244193d88c03560d27127d18648b9e894bca673c35bcd22f7c")
