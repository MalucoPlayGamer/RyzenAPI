-- Lua provided by RyzenAPI
-- Game: AppID 2004920

-- MAIN APPLICATION
addappid(2004920)
-- Game: addappid(2004920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004921, 1, "f52715e88a0155a34d2c71ebc07be8a70b188b0a41bee9e43a0f5794d19ef1d9")
