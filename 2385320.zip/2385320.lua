-- Lua provided by RyzenAPI
-- Game: Virgin Knight is my Onahole Tonight

-- MAIN APPLICATION
addappid(2385320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385321, 1, "b96571bb4b08e7e4bee251f240ec6b9e65e44498599963cfe90c3729f854982f")
