-- Lua provided by SkyAPI 
-- Game: Helicopter Simulator
addappid(1133330)
addappid(1133331, 1, "3727b05850e975a5dfac553a521fd817c97c5b99a48ed39e22f68c17e701ce58")
