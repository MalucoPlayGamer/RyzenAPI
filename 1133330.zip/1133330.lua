-- Lua provided by RyzenAPI
-- Game: Helicopter Simulator

-- MAIN APPLICATION
addappid(1133330)
-- Game: addappid(1133330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133331, 1, "3727b05850e975a5dfac553a521fd817c97c5b99a48ed39e22f68c17e701ce58")
