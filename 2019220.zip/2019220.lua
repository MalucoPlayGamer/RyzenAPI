-- Lua provided by RyzenAPI
-- Game: addappid(2019220)

-- MAIN APPLICATION
addappid(2019220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019221, 1, "e55ac4af4df9da99b8d3e43b84f1cfe0841e08edfce2b7a497283f0ed7c40cde")
