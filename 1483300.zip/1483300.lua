-- Lua provided by RyzenAPI 
-- Game: AppID 1483300
addappid(1483300)
addappid(1483301, 1, "1b8cf974368697c52dd0d9e5e03d94bdc489839e6d50946c87949376b23d4895")
