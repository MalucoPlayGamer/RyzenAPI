-- Lua provided by RyzenAPI
-- Game: MazM: The Phantom of the Opera

-- MAIN APPLICATION
addappid(1483300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483301, 1, "1b8cf974368697c52dd0d9e5e03d94bdc489839e6d50946c87949376b23d4895")

