-- Lua provided by RyzenAPI
-- Game: Tiny and Big: Grandpa's Leftovers

-- MAIN APPLICATION
addappid(205910)
-- Game: addappid(205910)

-- MAIN APP DEPOTS / PACKAGES
addappid(205911, 1, "3624cc13a755316ec4b32a94fab8f4064a837f7d32efaf1f9038122f7a2034c6")
addappid(205912, 1, "7bf8cc96b0e0b793736c7c158f5034d12327f4fe13c7884392e52ee1ea53b20f")
addappid(205913, 1, "c0af3dd616a9b79aae4b53770b03c0737d34a3ab723953e497f4de2e255815a0")
addappid(205914, 1, "965af8de7dfc895a0ba38f129af3e20049a5b7271bde61cfd51cc0d196cf7f43")
addappid(205915, 1, "5efb31c0ff4f5f1cc4860b4751ad80bc3302c1a4b1d669f001d4d1c991478962")
addappid(205916, 1, "3749228234dc434dcd50bf21ed284b17dc334f481c4aec898ed858f2bcc0fe2c")
addappid(205917, 1, "3555f27a07c64d214e6be02f0790c42e52ddcfd80277bb0a65339a2c59efbabc")
addappid(205918, 1, "83e66bd94ca518b04157a31fe4a70bca6dbfd6d421fe12f83e98e692b92af844")
addappid(205919, 1, "5e252461b76c7a20f8debd4a489ff2fee6aaaf3779d20739edf134bc2a30e4fa")
