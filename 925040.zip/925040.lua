-- Lua provided by RyzenAPI
-- Game: Ero Date

-- MAIN APPLICATION
addappid(925040)

-- MAIN APP DEPOTS / PACKAGES
addappid(925041,0,"e216c0309ed7d73c5952dfcecb1bd9d00a436c5a52eaa2ba04078e1d720579c6")

