-- Lua provided by RyzenAPI
-- Game: Mount & Blade: With Fire & Sword

-- MAIN APPLICATION
addappid(48720)

-- MAIN APP DEPOTS / PACKAGES
addappid(48721, 1, "d324596215ef1b8090849ba8de83581948e186747079b8fa4bac51999f5ead22")
