-- Lua provided by RyzenAPI
-- Game: A Musical Story

-- MAIN APPLICATION
addappid(1546100)
addappid(1877540)
addappid(1877550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1546101, 1, "b23da0eab58a14544638327cf2062bbe7afd4e2b57429b60e77b094382d12b76")
addappid(1546102, 1, "4ce2e98c86decd4d9c705ce8f4192873d77ba5320b96246b15a31f9c5e86ba42")
addappid(1546103, 1, "d78fef51cd0209c352218d755340d59a53855e41ad27529fe6d0340e7815cb15")

