-- Lua provided by RyzenAPI
-- Game: Game: AppID 1482380

-- MAIN APPLICATION
addappid(1482380)
-- Game: addappid(1482380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482381, 1, "0aef693e6ad6e947bb44801b47a8aab5af3daebdfdecf54a95ec4d092a669fa6")
addappid(1482382, 1, "071d595bfd532b39a24f8f272b79c59559d5e15027fd0d9f5b8f0925a8ae6681")
addappid(1482383, 1, "ddc7f708a6417af0b1289571d4929b376c6c339d5fd10538634f24e6a2526a4e")
