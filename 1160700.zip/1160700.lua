-- Lua provided by RyzenAPI
-- Game: Game: Particle Wars

-- MAIN APPLICATION
addappid(1160700)
-- Game: addappid(1160700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160701, 1, "0eae76b53c3cda26e2a35ba2b07e04a76bcc33fb51f3fa3c01bf31814ef57996")
