-- Lua provided by RyzenAPI
-- Game: Shadow Siege

-- MAIN APPLICATION
addappid(3392780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3392781, 1, "115186b84f20ede09b8f330e868464bc65b3f2e39bae65e538bb18b1a1ed4b2f")

