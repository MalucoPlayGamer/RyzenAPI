-- Lua provided by RyzenAPI 
-- Game: AppID 2470900
addappid(2470900)
addappid(2470901, 1, "5ffa000b2e6d9a987a34e5b995a1b0f145dcb3439b4189b0b806cb70aba4a485")
addappid(2470902, 1, "5bd07b9d221039b972cff9af9074b1821b94059b7b15317a17f418d32f6f9e2e")
