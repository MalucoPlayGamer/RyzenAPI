-- Lua provided by RyzenAPI
-- Game: Bellfortis

-- MAIN APPLICATION
addappid(2532470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532471, 1, "bae7e5326f2bd8b1c72acd75f27564022a97d52775589b3afdabc4639ffe450d")

