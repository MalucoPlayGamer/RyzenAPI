-- Lua provided by RyzenAPI
-- Game: AppID 2850050

-- MAIN APPLICATION
addappid(2850050)
-- Game: addappid(2850050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850051, 1, "f0c79b5f92bac5b365ebc4882565773d4add9756dbc09f1594105979860fea95")
