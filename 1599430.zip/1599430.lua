-- Lua provided by RyzenAPI
-- Game: AppID 1599430

-- MAIN APPLICATION
addappid(1599430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599431, 1, "6f6bb6ac8145da6f4cb592182a3906f8ce870dfa20aad29fd495a10856c1a3cd")

