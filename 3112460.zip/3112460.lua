-- Lua provided by RyzenAPI 
-- Game: AppID 3112460
addappid(3112460)
addappid(3112461, 1, "e2b152f4eb834b8332a5d2971b0fe5eedd6d407074b5c096f99f45ce25c3e9d4")
