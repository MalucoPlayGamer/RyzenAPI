-- Lua provided by RyzenAPI
-- Game: 3112460

-- MAIN APPLICATION
addappid(3112460)
-- Game: addappid(3112460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3112461, 1, "e2b152f4eb834b8332a5d2971b0fe5eedd6d407074b5c096f99f45ce25c3e9d4")
