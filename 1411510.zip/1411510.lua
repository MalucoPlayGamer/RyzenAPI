-- Lua provided by RyzenAPI
-- Game: 1411510

-- MAIN APPLICATION
addappid(1411510)
-- Game: addappid(1411510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411510,0,"d9b8b33b06714619f81214cd3bb0016b7b7be1e40da74590453b116c1b0cdb97")
