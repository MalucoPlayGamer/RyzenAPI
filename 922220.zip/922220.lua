-- Lua provided by RyzenAPI
-- Game: addappid(922220)

-- MAIN APPLICATION
addappid(922220)

-- MAIN APP DEPOTS / PACKAGES
addappid(922221, 1, "6c04bcd66cff46adace8849ffd4fd5568855c6e07852c2f5337ba26f4990712b")
