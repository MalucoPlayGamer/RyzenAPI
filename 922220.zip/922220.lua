-- Lua provided by RyzenAPI
-- Game: Khospis

-- MAIN APPLICATION
addappid(922220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(922221, 1, "6c04bcd66cff46adace8849ffd4fd5568855c6e07852c2f5337ba26f4990712b")

