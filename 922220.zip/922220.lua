-- Lua provided by RyzenAPI 
-- Game: Khospis
addappid(922220)
addappid(922221, 1, "6c04bcd66cff46adace8849ffd4fd5568855c6e07852c2f5337ba26f4990712b")
