-- Lua provided by RyzenAPI
-- Game: addappid(1158470)

-- MAIN APPLICATION
addappid(1158470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158471, 1, "e40e50eecc497833f93b4bfb0bc45de97143f9af1c4c7296c42b740b68f28045")
addappid(1158472, 1, "0293a64f04f0b19d85e6de75640f3db5d4c9cfc9b26cb07a0205dbfcae45f40a")
