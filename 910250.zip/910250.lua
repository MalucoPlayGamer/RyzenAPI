-- Lua provided by SkyAPI 
-- Game: Professor Watts Memory Match: Fresh Fruit
addappid(910250)
addappid(910251, 1, "b63eb2d7a7eea790284097ccf7b78221b83a05e45512a4045b6b4949d69a0ada")
