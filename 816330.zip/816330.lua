-- Lua provided by RyzenAPI
-- Game: The Council of Hanwell

-- MAIN APPLICATION
addappid(816330)

-- MAIN APP DEPOTS / PACKAGES
addappid(816331, 1, "5f13fec66478f4a5f92f4ae3c46bf8bcc81067a29f8d6c3d9549d818bc9990d0")

