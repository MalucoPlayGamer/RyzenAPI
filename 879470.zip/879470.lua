-- Lua provided by RyzenAPI
-- Game: AppID 879470

-- MAIN APPLICATION
addappid(879470)

-- MAIN APP DEPOTS / PACKAGES
addappid(879471, 1, "32da680d9eedbf04617d01632f864ab4cd8ee5e89f2d459d27f907950af8175e")
addappid(879473, 1, "8fd1103c5bcbbb3027ec1bf074ab386db80944f5a03cfb4c0e8a4e53adaca0cc")

