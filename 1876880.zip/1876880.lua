-- Lua provided by RyzenAPI
-- Game: Game: Primitive Society Simulator

-- MAIN APPLICATION
addappid(1876880)
-- Game: addappid(1876880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876881, 1, "645131603cb7f183e2bdd59a28ef2cd45871d6ff310f3662d16544c468b3114a")
