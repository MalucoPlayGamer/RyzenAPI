-- Lua provided by RyzenAPI
-- Game: THE MULLER-POWELL PRINCIPLE: Foreword

-- MAIN APPLICATION
addappid(2671350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2671351, 1, "b1eee0e6a02f2e061deb0174c5805e330a1a28397daf101fb466894854b7118d")

