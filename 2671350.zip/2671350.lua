-- Lua provided by RyzenAPI 
-- Game: AppID 2671350
addappid(2671350)
addappid(2671351, 1, "b1eee0e6a02f2e061deb0174c5805e330a1a28397daf101fb466894854b7118d")
