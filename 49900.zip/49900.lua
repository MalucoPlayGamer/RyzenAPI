-- Lua provided by RyzenAPI 
-- Game: Plain Sight
addappid(49900)
addappid(49901, 1, "b819a13609f19a3ae2d66c8205e5498c55f9ace8e9c728dbee7b110757a9c8d5")
