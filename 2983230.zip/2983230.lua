-- Lua provided by RyzenAPI
-- Game: Legend of Mortal Soundtrack

-- MAIN APPLICATION
addappid(2983230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983231, 1, "9b8762790e765af1e5d55100f3775a69a97323aab412ad3127f6ca20cca61255")
addappid(2983232, 1, "5f9a79dbd3f2c9f56e23e4bbd15b65b9c97c4948d31a778d6820ea6f77c53eac")

