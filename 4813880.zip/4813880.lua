-- Lua provided by RyzenAPI
-- Game: Uptime: A Cloud Provider Sim

-- MAIN APPLICATION
addappid(4813880)

-- MAIN APP DEPOTS / PACKAGES
addappid(4813881,0,"acfa8e0bf5b10553847c8e2db6ed468f01dd53bd5c605b4cc8b8e1b91cb995f1")

