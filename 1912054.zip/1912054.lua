-- Lua provided by RyzenAPI
-- Game: addappid(1912054)

-- MAIN APPLICATION
addappid(1912054)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912054,0,"9285714b4140a0882d3185a6123737a7a814bd8d1dc47e6df6af6ae7512b7dea")
