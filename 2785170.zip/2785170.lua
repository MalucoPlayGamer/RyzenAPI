-- Lua provided by RyzenAPI 
-- Game: AppID 2785170
addappid(2785170)
addappid(2785171, 1, "5a987c11b9109f4d3a4359e95c3cc5f6bb7aba02e4fee81d901da6840768ad5f")
