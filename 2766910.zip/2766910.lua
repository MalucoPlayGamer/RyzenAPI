-- Lua provided by RyzenAPI
-- Game: PengPong

-- MAIN APP DEPOTS / PACKAGES
addappid(2766910, 1, "4122b6d603d1a5db28a9cc5be4e84db249113a46b9514d075a93c775f0b982aa") -- PengPong
addappid(2766911, 1, "72bad73ac24b174506018dcedd18542e615eed4a754004143692d24b6a36c835") -- Depot 2766911
addappid(2766914, 1, "3eda56f8f922ee0af2df8184451c629176a8f4ea8cabbee780094429a9c7cd37") -- Depot 2766914

