-- 2766910's Lua and Manifest Created by Hubcap Manifest
-- PengPong
-- Created: August 21, 2026 at 01:45:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2766910, 1, "4122b6d603d1a5db28a9cc5be4e84db249113a46b9514d075a93c775f0b982aa") -- PengPong
-- MAIN APP DEPOTS
addappid(2766914, 1, "3eda56f8f922ee0af2df8184451c629176a8f4ea8cabbee780094429a9c7cd37") -- Depot 2766914
setManifestid(2766914, "4655046527562942463", 3831689051)
addappid(2766911, 1, "72bad73ac24b174506018dcedd18542e615eed4a754004143692d24b6a36c835") -- Depot 2766911
setManifestid(2766911, "5622269489606359411", 2624033014)