-- Lua provided by RyzenAPI
-- Game: 864760

-- MAIN APPLICATION
addappid(864760)
-- Game: addappid(864760)

-- MAIN APP DEPOTS / PACKAGES
addappid(864761, 1, "79ce4b976cfaf2f0a28f32ca0e5e94df93179f3a4b696eeab53847cd0875a048")
