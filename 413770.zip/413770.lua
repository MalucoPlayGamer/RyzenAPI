-- Lua provided by SkyAPI 
-- Game: AppID 413770
addappid(413770)
addappid(413771, 1, "9a657dd10d12bcda5f2720bdb41e79685b271dd1c1b51f7c6b8dd1268924597b")
addappid(413772, 1, "917f5ecb87b9d8a620f3da2d2745162fd748124406f69362548c5fc5c9c43f00")
