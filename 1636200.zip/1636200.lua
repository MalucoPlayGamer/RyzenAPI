-- Lua provided by SkyAPI 
-- Game: Horny Fantasy Girl Hentai
addappid(1636200)
addappid(1636201, 1, "3a2e4405822f15bd573bbf81f087150b49686dc4beecc236931ccf56316a1631")
