-- Lua provided by RyzenAPI
-- Game: Horny Fantasy Girl Hentai

-- MAIN APPLICATION
addappid(1636200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636201, 1, "3a2e4405822f15bd573bbf81f087150b49686dc4beecc236931ccf56316a1631")
