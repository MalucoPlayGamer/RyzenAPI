-- Lua provided by RyzenAPI
-- Game: AppID 2321080

-- MAIN APPLICATION
addappid(2321080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321081, 1, "daa9d2e71135ffdae01a100fd14179dd3ac8bda2acf116b51dd9be3c2e0e5398")
