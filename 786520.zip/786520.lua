-- Lua provided by RyzenAPI
-- Game: SAO Utils: Beta

-- MAIN APPLICATION
addappid(786520)
addappid(787020)
addappid(787030)
addappid(787080)
addappid(795660)
addappid(795790)
addappid(795800)
addappid(795810)
addappid(795820)
addappid(795830)
addappid(795840)
addappid(795850)
addappid(795860)
addappid(795870)
addappid(795880)
addappid(795890)
addappid(795900)

-- MAIN APP DEPOTS / PACKAGES
addappid(786521, 1, "d5364f125e631463d60b44943b449ff1677c7ad2df602a916bde6c887485e752")
addappid(786522, 1, "6a946b05b80a12e0dc95a2628425c7a6cd768559f5fc481e8c2c842397e0968c")
addappid(786523, 1, "7f6f53a4160d6b35bf5671f7a8dc60bbdbb91de0f12186b1f7835513fb3e3fa2")
addappid(786524, 1, "300a4b8f8135bd12eeb4d2f94d9f69141753e8e1a4b332107f6bad37ac232531")
addappid(786525, 1, "6f15459a13b4ae24737cb2f8918a8f9008a83a750e07ddbf73dda5b4fa4e1afd")
addappid(786526, 1, "ad885be1fa6a4a6efaaa6c29f144dc683d3992c8092062e46e11889cfb236fba")
addappid(786527, 1, "ba0a511c237ac6aac322d428052ea5bc0b476f31f0450b73f657c7697d7299d0")
