-- Lua provided by RyzenAPI
-- Game: Reality Noclip: The Backrooms

-- MAIN APPLICATION
addappid(2177610)
-- Game: addappid(2177610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177611, 1, "bf3261426406663072224aa9750a7e8d5118c2b46d0427c057f092ffa1906ad3")
