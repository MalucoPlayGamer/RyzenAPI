-- Lua provided by RyzenAPI 
-- Game: AppID 2538950
addappid(2538950)
addappid(2538951, 1, "e9d6a792c180366cec3ffc2117efe7cd2d2fd103da38935fe9abeb6f9a2d04f4")
