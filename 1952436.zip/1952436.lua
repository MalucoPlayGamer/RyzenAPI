-- Lua provided by RyzenAPI
-- Game: 1952436

-- MAIN APPLICATION
addappid(1952436)
-- Game: addappid(1952436)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952436,0,"a8f9f880a2e2a846db7e2acdf197cc935ec30a794eb510225f31f6bf7de69ccf")
