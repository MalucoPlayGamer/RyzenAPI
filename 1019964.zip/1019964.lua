-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Guan Yinping "Knight Costume" / 関銀屏「騎士風コスチューム」

-- MAIN APPLICATION
addappid(1019964)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019964,0,"6cb115fab352eed480ad135d74111966c9696bb29be8322b42b8e96f1dcfbdf8")

