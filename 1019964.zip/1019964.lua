-- Lua provided by RyzenAPI
-- Game: 1019964

-- MAIN APPLICATION
addappid(1019964)
-- Game: addappid(1019964)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019964,0,"6cb115fab352eed480ad135d74111966c9696bb29be8322b42b8e96f1dcfbdf8")
