-- Lua provided by RyzenAPI 
-- Game: Arcane Lust 18+
addappid(3377320)
addappid(3377321, 1, "83e630b08daee6237e055f4e8bbaddb0c1cc1dc65d17c605605bc60f4a11912f")
