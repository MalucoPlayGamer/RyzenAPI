-- Lua provided by RyzenAPI
-- Game: Alone in the Dark

-- MAIN APPLICATION
addappid(1310410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310411, 1, "2d39fddfd2e106911e6b2163a3bad7f70ba00af107fe1e777f8768c28d16205a")
addappid(2450980, 0, "830385766c9907cd940ae7ed43a699dc2a0b711e2ee4010cb7ee2266083b7980")
addappid(2450981, 0, "4727b48ab9d30b5fb95ce96910bfcae1e51964b4415eabbb4d129b15497c77dd")
addappid(2450982, 0, "863e33498a4c3aeb954f799e797789e5964aa5f8072d77236637bd57c4d914ab")
addappid(2450983, 0, "1e3b4a0692e673e1db221cd86f537a88bff72856f78a90ab2f7b8eb1021c401d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
