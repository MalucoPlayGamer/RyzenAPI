-- Lua provided by RyzenAPI
-- Game: Rail Route - Soundtrack and Music Player

-- MAIN APPLICATION
addappid(2788780)
-- Game: addappid(2788780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788781, 1, "4262165e1a12d8a626843a0f60ed12b292278d56e806364c41e36ffd678ea987")
addappid(2788782, 1, "2262279722aa69bc36b435851eeb02d2c2ca074b5a2ae16987be5b3bdbb9ba9a")
