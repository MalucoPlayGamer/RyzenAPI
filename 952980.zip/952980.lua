-- Lua provided by RyzenAPI 
-- Game: AppID 952980
addappid(952980)
addappid(952981, 1, "e002da981341efd597576de27c8c9c8a846c4634adcf05c933731e6403e8beaa")
