-- Lua provided by RyzenAPI
-- Game: Torn Earth

-- MAIN APPLICATION
addappid(952980)

-- MAIN APP DEPOTS / PACKAGES
addappid(952981, 1, "e002da981341efd597576de27c8c9c8a846c4634adcf05c933731e6403e8beaa")
