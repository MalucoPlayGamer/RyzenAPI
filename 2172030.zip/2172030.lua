-- Lua provided by SkyAPI 
-- Game: Elong Plug
addappid(2172030)
addappid(2172031, 1, "37c6e23ffc7768887933b6a2cda60bc82da765fd5894bb6c569c41e7179c8775")
