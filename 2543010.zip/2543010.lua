-- Lua provided by RyzenAPI
-- Game: Withering Flowers Demo

-- MAIN APPLICATION
addappid(2543010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543011, 1, "fee6a6c08eaaeb3b3ea3be6cd017c4001c64914b8208ec1f7ddf6c6666e397f7")
