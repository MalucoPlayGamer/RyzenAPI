-- Lua provided by RyzenAPI
-- Game: Desktop Sex Doll

-- MAIN APPLICATION
addappid(2245080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245081, 1, "6684b7b293410f48e35d6c7b74c261d42e68e81b85902c150c66eaf57cbffef9")

