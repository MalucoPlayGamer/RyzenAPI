-- Lua provided by RyzenAPI
-- Game: Guns & Notes

-- MAIN APPLICATION
addappid(781320)

-- MAIN APP DEPOTS / PACKAGES
addappid(781321, 1, "a6a65eaad14c6160c05b3fff41f7a596c783a718f6d5c4c902ebdf926d02c6ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
