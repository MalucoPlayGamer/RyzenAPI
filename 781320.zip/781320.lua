-- Lua provided by RyzenAPI
-- Game: 781320

-- MAIN APPLICATION
addappid(781320)
-- Game: addappid(781320)

-- MAIN APP DEPOTS / PACKAGES
addappid(781321, 1, "a6a65eaad14c6160c05b3fff41f7a596c783a718f6d5c4c902ebdf926d02c6ce")
