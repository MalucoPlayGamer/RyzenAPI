-- Lua provided by RyzenAPI
-- Game: Book of Demons

-- MAIN APPLICATION
addappid(449960)
addappid(449970)
addappid(706770)
addappid(968890)

-- MAIN APP DEPOTS / PACKAGES
addappid(449961, 1, "c85e8ab29a95854075061035a04a70ab9a002a6c0f7a8fed6f331c560d43ee2b")
addappid(449962, 1, "f66efc8cbd53f29d3b9addf6e26c1f834edd08e31724df98618f78be3121ae60")
addappid(449965, 1, "425d7e4876bc1d0442530705a424b81337e5b5af59d985458db405c4ea4dc9c1")
addappid(449966, 1, "83d1f22339dedc27afd388ca01fa964f9fe4c084566914d5ee8d3c388cf741d6")
addappid(991890, 0, "fc7a30ba9cfe6bdf61023c64b566328f825c606a38c393176e0be98de48342f9")

