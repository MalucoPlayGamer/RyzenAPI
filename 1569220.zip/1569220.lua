-- Lua provided by RyzenAPI
-- Game: Abermore

-- MAIN APPLICATION
addappid(1569220)
-- Game: addappid(1569220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569221, 1, "d1cc140d4769a28d9117012f2651b93c8310989764fa319311280048efbbaabf")
