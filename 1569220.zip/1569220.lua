-- Lua provided by RyzenAPI 
-- Game: Abermore
addappid(1569220)
addappid(1569221, 1, "d1cc140d4769a28d9117012f2651b93c8310989764fa319311280048efbbaabf")
