-- Lua provided by RyzenAPI
-- Game: Abermore

-- MAIN APPLICATION
addappid(1569220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569221, 1, "d1cc140d4769a28d9117012f2651b93c8310989764fa319311280048efbbaabf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
