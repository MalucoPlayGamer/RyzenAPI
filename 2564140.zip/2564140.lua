-- Lua provided by RyzenAPI
-- Game: Your Cute Wife

-- MAIN APPLICATION
addappid(2564140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564141, 1, "076738c91d62917a2ac0ec97cd3931df01a36adb4935462896e8d0056ce1bd04")
