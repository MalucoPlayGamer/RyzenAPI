-- Lua provided by RyzenAPI
-- Game: Big Ambitions

-- MAIN APPLICATION
addappid(1331550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331551, 1, "f3b44da48f4335a1dad963250d348f21e38cb27fbe8264e2cd0ebf217849a089")
addappid(1331552, 1, "1547279019dc793ecffc735c9690f060ed6a8c2fd0145e1e4c605b795cc423d9")

