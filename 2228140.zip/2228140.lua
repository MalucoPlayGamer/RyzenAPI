-- Lua provided by RyzenAPI
-- Game: NOX: Chapter 1

-- MAIN APPLICATION
addappid(2228140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2228141, 1, "3cc2a7c903c48f6b6cb46d5fffa68eae0c642f1c07508eb5ba1c29ef60c65bc0")

