-- Lua provided by RyzenAPI
-- Game: NOX: Chapter 1

-- MAIN APPLICATION
addappid(2228140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2228141, 1, "3cc2a7c903c48f6b6cb46d5fffa68eae0c642f1c07508eb5ba1c29ef60c65bc0")

