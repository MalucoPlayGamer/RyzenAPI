-- Lua provided by RyzenAPI
-- Game: Wild Country

-- MAIN APPLICATION
addappid(1515000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515001, 1, "6ffc78575968fa5dd31dc3de66728cf505071b3cf5ec10024201b811c0905203")

