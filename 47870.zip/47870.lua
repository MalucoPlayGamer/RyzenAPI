-- Lua provided by RyzenAPI
-- Game: AppID 47870

-- MAIN APPLICATION
addappid(47870)
-- Game: addappid(47870)

-- MAIN APP DEPOTS / PACKAGES
addappid(47871, 1, "8fe5b3f77f42f03e38fe291e95d0ec715cd5d73b2b8153b854c3949801778ada")
