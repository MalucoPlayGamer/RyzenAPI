-- Lua provided by RyzenAPI
-- Game: Line Of Defense Tactics - Tactical Advantage

-- MAIN APPLICATION
addappid(267220)

-- MAIN APP DEPOTS / PACKAGES
addappid(278771,0,"107df1b096c94106d4579b0b127f788f2c9957bfe2c814ef2c46796ad2664d49")

