-- Lua provided by RyzenAPI
-- Game: Line Of Defense Tactics - Tactical Advantage

-- MAIN APPLICATION
addappid(267220)

-- MAIN APP DEPOTS / PACKAGES
addappid(278771,0,"107df1b096c94106d4579b0b127f788f2c9957bfe2c814ef2c46796ad2664d49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
