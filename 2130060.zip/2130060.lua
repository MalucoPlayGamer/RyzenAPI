-- Lua provided by RyzenAPI
-- Game: addappid(2130060)

-- MAIN APPLICATION
addappid(2130060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130061, 1, "fd6dc5d7aabac85d428b2993221bd54a6573139b86110f0493d0e215b9f35491")
