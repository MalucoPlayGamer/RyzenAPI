-- Lua provided by RyzenAPI
-- Game: Tower Walker: MMO Grind Simulator

-- MAIN APPLICATION
addappid(2130060)
addappid(2444870)
addappid(2444880)
addappid(2646230)
addappid(2693140)
addappid(2918010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130061, 1, "fd6dc5d7aabac85d428b2993221bd54a6573139b86110f0493d0e215b9f35491")

