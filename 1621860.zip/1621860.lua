-- Lua provided by RyzenAPI
-- Game: Game: NekoDice

-- MAIN APPLICATION
addappid(1621860)
-- Game: addappid(1621860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621861, 1, "2cac7f379a5748b385cb1c3517bec514a34c56b9cb5237044fd2503a9a8532f2")
