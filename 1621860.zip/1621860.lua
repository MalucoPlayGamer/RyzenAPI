-- Lua provided by SkyAPI 
-- Game: NekoDice
addappid(1621860)
addappid(1621861, 1, "2cac7f379a5748b385cb1c3517bec514a34c56b9cb5237044fd2503a9a8532f2")
