-- Lua provided by RyzenAPI
-- Game: NekoDice

-- MAIN APPLICATION
addappid(1621860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621861, 1, "2cac7f379a5748b385cb1c3517bec514a34c56b9cb5237044fd2503a9a8532f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1653720)
addappid(1658860)
addappid(1664460)
