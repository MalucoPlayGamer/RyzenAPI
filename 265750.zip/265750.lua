-- Lua provided by RyzenAPI
-- Game: addappid(265750)

-- MAIN APPLICATION
addappid(265750)
addappid(307470)
addappid(307660)
addappid(389750)

-- MAIN APP DEPOTS / PACKAGES
addappid(265751, 1, "9165cde6a5ee74a0fb34696daef05182d47526714b2df88c3d677a5b2feafb35")
addappid(265752, 1, "43010e6b9c3fb0573da318231046e9f368ae528a3994ad574c24f16901cc2fee")
