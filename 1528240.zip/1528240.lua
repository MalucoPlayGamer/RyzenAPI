-- Lua provided by RyzenAPI
-- Game: Super Dirt Racers

-- MAIN APPLICATION
addappid(1528240)
-- Game: addappid(1528240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528241, 1, "e046fe6f80c2a8bd9493804a31cd159cf481e4504a087c4411ddf90c1cb41330")
addappid(1528242, 1, "9c279abda834dae7a3d96e6e11b5dfde94e866548df95d2952c7218f55835a5b")
addappid(1528243, 1, "081c44daa5f5145c7bc187ba05cae1fbde9fde0c5db161b5048b4b91655ad391")
