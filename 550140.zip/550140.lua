-- Lua provided by RyzenAPI
-- Game: Call of Duty: Black Ops III - Remote Console

-- MAIN APPLICATION
addappid(550140)

-- MAIN APP DEPOTS / PACKAGES
addappid(550141, 1, "d4b392efdd7e0fd5389e139a136c3945b05fcd2faa9d0cc5811b9ccfb58c77fe")
