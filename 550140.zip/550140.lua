-- Lua provided by RyzenAPI
-- Game: AppID 550140

-- MAIN APPLICATION
addappid(550140)
-- Game: addappid(550140)

-- MAIN APP DEPOTS / PACKAGES
addappid(550141, 1, "d4b392efdd7e0fd5389e139a136c3945b05fcd2faa9d0cc5811b9ccfb58c77fe")
