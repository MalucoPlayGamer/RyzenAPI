-- Lua provided by RyzenAPI
-- Game: Game: The Love Boat

-- MAIN APPLICATION
addappid(748150)
-- Game: addappid(748150)

-- MAIN APP DEPOTS / PACKAGES
addappid(748151, 1, "d41a4ea5bc16721cfd19ffcd92e86a322fe140d5e6937630034737c65571a847")
