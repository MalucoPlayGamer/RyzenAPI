-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It’s a Night Magic Lucky Bag Ver. Luxury Adult

-- MAIN APPLICATION
addappid(2737690)
-- Game: addappid(2737690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737691, 1, "dcbcb03dd569b176ad14f859c5096f6333d7f81dde0688729f5474a51cce21d2")
