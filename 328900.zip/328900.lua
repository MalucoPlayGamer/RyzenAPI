-- Lua provided by SkyAPI 
-- Game: B-17 Flying Fortress: The Mighty 8th
addappid(328900)
addappid(328901, 1, "6ac70f48dfa3a5e33bf53d0ae6ca23d045c68882368df0c3dc114b380378ae62")
addappid(328902, 1, "25ad99564e82bc4ed05c8625ee0302b50ab84ee5aca5d49023d387b43e7d17fb")
