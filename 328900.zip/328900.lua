-- Lua provided by RyzenAPI
-- Game: B-17 Flying Fortress: The Mighty 8th

-- MAIN APPLICATION
addappid(328900)

-- MAIN APP DEPOTS / PACKAGES
addappid(328901, 1, "6ac70f48dfa3a5e33bf53d0ae6ca23d045c68882368df0c3dc114b380378ae62")
addappid(328902, 1, "25ad99564e82bc4ed05c8625ee0302b50ab84ee5aca5d49023d387b43e7d17fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
