-- 5000020's Lua and Manifest Created by Hubcap Manifest
-- That's Not My Mom
-- Created: August 05, 2026 at 13:41:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5000020) -- That's Not My Mom
-- MAIN APP DEPOTS
addappid(5000021, 1, "44edb6a52ef421e056230d61187e73e0ac59607c41d84dcd4daa231f6644320a") -- Depot 5000021
setManifestid(5000021, "2720369578960628263", 2043365690)