-- Lua provided by RyzenAPI
-- Game: That's Not My Mom

-- MAIN APPLICATION
addappid(5000020) -- That's Not My Mom

-- MAIN APP DEPOTS / PACKAGES
addappid(5000021, 1, "44edb6a52ef421e056230d61187e73e0ac59607c41d84dcd4daa231f6644320a") -- Depot 5000021

