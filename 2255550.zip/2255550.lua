-- Lua provided by RyzenAPI
-- Game: Taxi Copter

-- MAIN APPLICATION
addappid(2255550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255551, 1, "98b1100a9152a57005cb55f57dfc0c28471eb5e9b756ad9bd46eeff4ffd33502")

