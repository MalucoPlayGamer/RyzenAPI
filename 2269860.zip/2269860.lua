-- Lua provided by RyzenAPI
-- Game: addappid(2269860)

-- MAIN APPLICATION
addappid(2269860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269861, 1, "e847ca38c36b364acaebae69c5c15143c55a0e46db5bc5889e925f6c6e77660f")
