-- Lua provided by RyzenAPI
-- Game: AppID 461140

-- MAIN APPLICATION
addappid(461140)

-- MAIN APP DEPOTS / PACKAGES
addappid(461141, 1, "51d3f9ec6fc9ac423e1565ec54bfc714c4217528f3d9fdb8ec4c44234e9440b5")

