-- Lua provided by RyzenAPI
-- Game: AppID 2622140

-- MAIN APPLICATION
addappid(2622140)
-- Game: addappid(2622140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622141, 1, "f610f0d1e29f613aad524d2301d42bc97f4374dd5ec069fb52a0c226151d24f0")
