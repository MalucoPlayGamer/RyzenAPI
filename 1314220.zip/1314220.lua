-- Lua provided by RyzenAPI
-- Game: Game: Bonkies Demo

-- MAIN APPLICATION
addappid(1314220)
-- Game: addappid(1314220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314221, 1, "6bca563e2bee7b487ed296548e7e507c978d0988c18bc828605f3e5791b45dfd")
