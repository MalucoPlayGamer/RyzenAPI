-- Lua provided by RyzenAPI
-- Game: Secret Cats - Haunted Mansion

-- MAIN APPLICATION
addappid(3284640)
-- Game: addappid(3284640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3284641, 1, "268fc69a2189188bd5ab571c3ac38349489111b112836282b80c64a9f3b170f6")
