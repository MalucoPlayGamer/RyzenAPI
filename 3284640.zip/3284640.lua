-- Lua provided by SkyAPI 
-- Game: Secret Cats - Haunted Mansion
addappid(3284640)
addappid(3284641, 1, "268fc69a2189188bd5ab571c3ac38349489111b112836282b80c64a9f3b170f6")
