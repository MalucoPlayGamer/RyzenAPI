-- Lua provided by RyzenAPI
-- Game: Invasion Zero

-- MAIN APPLICATION
addappid(1003940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003941, 1, "5376a356aded8853f5611f55590a846d27adc65b71e09b54b12a4e68cdab3051")
addappid(1003942, 1, "65a888b55ff0f79f056cf8e3b7f3d73dad50bb27df6f6451eaf4e48cf45648bf")
addappid(1003943, 1, "27f096df80eed003657dd52dfbe48af0aa6e85518571590e8d36dc176c3d5e5f")
