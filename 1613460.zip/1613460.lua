-- Lua provided by RyzenAPI
-- Game: AppID 1613460

-- MAIN APPLICATION
addappid(1613460)
-- Game: addappid(1613460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1613461, 1, "f76a24564cfb79e9fe799a38685a3958249af1454a89fe226c2faaec9d571450")
