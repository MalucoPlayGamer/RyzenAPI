-- Lua provided by RyzenAPI
-- Game: addappid(6250)

-- MAIN APPLICATION
addappid(6250)

-- MAIN APP DEPOTS / PACKAGES
addappid(6252,0,"50571844364ab48b5792ded568bd5641e9c584e4050d970dc9c4e8ef55090733")
