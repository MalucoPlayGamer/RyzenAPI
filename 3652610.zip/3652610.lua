-- Lua provided by RyzenAPI
-- Game: addappid(3652610)

-- MAIN APPLICATION
addappid(3652610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652611, 1, "4016dd19b421097d1f3b37aa80f58e7639a14830d2a672ca3bac4a0fb230cdbd")
