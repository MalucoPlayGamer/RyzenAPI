-- Lua provided by SkyAPI 
-- Game: Trick or Treat
addappid(1787650)
addappid(1787651, 1, "01bc17d74efe1685e7037567053af1330559762d2dcf5489242ea91a818cd9b5")
