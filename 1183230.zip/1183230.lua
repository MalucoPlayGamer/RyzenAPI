-- Lua provided by RyzenAPI
-- Game: A Pirate's Pleasure

-- MAIN APPLICATION
addappid(1183230)
addappid(1796460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183231, 1, "7a1727db0be25108892839e9596e8e02036b86f2b04ddce223c3fdfb4a528e63")
