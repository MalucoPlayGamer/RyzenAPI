-- Lua provided by RyzenAPI
-- Game: AppID 307410

-- MAIN APPLICATION
addappid(307410)
-- Game: addappid(307410)

-- MAIN APP DEPOTS / PACKAGES
addappid(307411, 1, "e08391a8e96e9907f05bfce65ae4adcd4b2118a57eb5ec0d9f9e986192ddfdc4")
