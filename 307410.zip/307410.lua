-- Lua provided by RyzenAPI
-- Game: AppID 307410

-- MAIN APPLICATION
addappid(307410)

-- MAIN APP DEPOTS / PACKAGES
addappid(307411, 1, "e08391a8e96e9907f05bfce65ae4adcd4b2118a57eb5ec0d9f9e986192ddfdc4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
