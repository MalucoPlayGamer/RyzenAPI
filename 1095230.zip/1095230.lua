-- Lua provided by RyzenAPI 
-- Game: AppID 1095230
addappid(1095230)
addappid(1095231, 1, "5250c5c16fb2831e715b93e8d5755b2e948f710d4ce1d17bd8b32f6a9f3503dc")
