-- Lua provided by RyzenAPI
-- Game: Masterchef Chinese Food Edition

-- MAIN APPLICATION
addappid(1938460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938461, 1, "00eeff51b492206f52815e000800a63d34e5f66ff16d9f014557d7696276634f")
