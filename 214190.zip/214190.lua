-- Lua provided by RyzenAPI
-- Game: addappid(214190)

-- MAIN APPLICATION
addappid(214190)
addappid(228983)
addappid(228990)
addappid(229004)
addappid(229031)

-- MAIN APP DEPOTS / PACKAGES
addappid(214191, 1, "272cdca360f43d62d19d587ff195b854d5cffc242c8ceb74a0a9611287a4efaf")
