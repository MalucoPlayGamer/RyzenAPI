-- Lua provided by RyzenAPI
-- Game: Anykey Simulator

-- MAIN APPLICATION
addappid(513530)

-- MAIN APP DEPOTS / PACKAGES
addappid(513531, 1, "ac38fd5414a1c2f075e5a1646657607cc42bf4d324e192e7765eb783375bbeb9")
addappid(538520, 0, "2065599dd4da979ce83584216bdf0133e0e01e15089606410dc2255fd1b1aacb")

