-- Lua provided by RyzenAPI
-- Game: Wrath of Anias

-- MAIN APPLICATION
addappid(1906950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1906951, 1, "ee7ac27becf07db33f6e9e480d111fde9613c0a3a9ba9b6fb42d3724fcb8193e")

