-- Lua provided by RyzenAPI
-- Game: Wrath of Anias

-- MAIN APPLICATION
addappid(1906950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906951, 1, "ee7ac27becf07db33f6e9e480d111fde9613c0a3a9ba9b6fb42d3724fcb8193e")
