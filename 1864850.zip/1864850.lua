-- Lua provided by RyzenAPI
-- Game: Hidden Map

-- MAIN APPLICATION
addappid(1864850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864851, 1, "e1da0fb5a63a3b57d9e1dc402c4449ae15e1ff29b8bcd435a80008cfa0a3d804")
