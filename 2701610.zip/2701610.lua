-- Lua provided by SkyAPI 
-- Game: Lost Princess: Darkness
addappid(2701610)
addappid(2701611, 1, "35c712585204e3040b12afdd9351aa19067856b1b7007628b0741039cd436d43")
