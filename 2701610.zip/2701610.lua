-- Lua provided by RyzenAPI
-- Game: Lost Princess: Darkness

-- MAIN APPLICATION
addappid(2701610)
-- Game: addappid(2701610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701611, 1, "35c712585204e3040b12afdd9351aa19067856b1b7007628b0741039cd436d43")
