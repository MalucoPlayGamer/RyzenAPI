-- Lua provided by RyzenAPI
-- Game: addappid(1692290)

-- MAIN APPLICATION
addappid(1692290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692291, 1, "076d7379cfe40f564136b9254f81dea9ba97149f672a53c915b7b0e9e3fcdf80")
