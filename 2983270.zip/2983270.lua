-- Lua provided by RyzenAPI
-- Game: Game: SEX, Stocks & Cocks

-- MAIN APPLICATION
addappid(2983270)
-- Game: addappid(2983270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983271, 1, "7680d5504a44f1a812235e64124069e58f18ce4ae1774e6bdc4ed039b5223697")
