-- Lua provided by RyzenAPI
-- Game: AppID 359050

-- MAIN APPLICATION
addappid(359050)

-- MAIN APP DEPOTS / PACKAGES
addappid(359051, 1, "3046c43a7239870756d097db30996a5990383d5fd8b7766adc675b6a032f23b9")
addappid(359052, 1, "a02b2ec4881d6454fcb52399db3de289f3c9235254bc5784ef50011d6c6b938a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
