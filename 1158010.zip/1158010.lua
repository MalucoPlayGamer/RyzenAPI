-- Lua provided by RyzenAPI
-- Game: AppID 1158010

-- MAIN APPLICATION
addappid(1158010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1158011, 1, "9f53e0e76252f76897daf8b896f7e79dd55999bde079571135802cfcfeaaeac0")
addappid(1192360, 0, "1b64813f10c266dd31b3a5331f9609fe61c3b2df00171ebdb0007c2406f1af82")
addappid(1330070, 0, "7c0f40dc02a1bfbb69e73f0c6ff290d61753e329fd4af6c95e77c6aec6d4de79")

