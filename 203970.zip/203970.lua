-- Lua provided by RyzenAPI
-- Game: Kingdoms of Amalur: Reckoning™ Demo

-- MAIN APPLICATION
addappid(203970)

-- MAIN APP DEPOTS / PACKAGES
addappid(203971, 1, "ac91b34323cc16f62153ef964918925db6e9362499fa8dbfa51a3b539ef10185")

