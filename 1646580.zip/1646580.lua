-- Lua provided by RyzenAPI
-- Game: Project Demigod

-- MAIN APPLICATION
addappid(1646580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646581, 1, "85c6ca70e330f208008e25aba7476ebd78b0029856ce59c477ee9ca5a8b68fe6")
