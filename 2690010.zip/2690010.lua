-- Lua provided by RyzenAPI
-- Game: Handyman Fantasy

-- MAIN APPLICATION
addappid(2690010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690011, 1, "946fef02fba52477b88e087972a3ae4e300ea926c25fcc7ea0d6be4e8477fe8f")
addappid(3557260, 0, "ad120b9f38c2f7b3830f03119e96844f4ef5ee5a462e19e2dac8adfbea559e91")
