-- Lua provided by RyzenAPI 
-- Game: AppID 3028100
addappid(3028100)
addappid(3028101, 1, "98018528a69df4d636ef901d6a5e73d3160ea90a6eb20d831bfbcf6d48808746")
