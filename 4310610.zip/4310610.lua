-- Lua provided by RyzenAPI
-- Game: The Skin Stapler

-- MAIN APPLICATION
addappid(4310610)
addappid(4919860)

-- MAIN APP DEPOTS / PACKAGES
addappid(4310611,0,"7631ed578c4f89d04b52f880b1e53ba9ba9d017d2c9f971952b08a4a71c5c76e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
