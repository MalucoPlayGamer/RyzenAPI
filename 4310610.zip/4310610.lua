-- Lua provided by RyzenAPI
-- Game: The Skin Stapler

-- MAIN APPLICATION
addappid(4310610)
addappid(4919860)

-- MAIN APP DEPOTS / PACKAGES
addappid(4310611,0,"7631ed578c4f89d04b52f880b1e53ba9ba9d017d2c9f971952b08a4a71c5c76e")

