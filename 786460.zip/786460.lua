-- Lua provided by RyzenAPI
-- Game: Game: AppID 786460

-- MAIN APPLICATION
addappid(786460)
-- Game: addappid(786460)

-- MAIN APP DEPOTS / PACKAGES
addappid(786461, 1, "be0fde203b1601fac811fbf61a4c0f8c5c716f02364249f921db383983767ac0")
