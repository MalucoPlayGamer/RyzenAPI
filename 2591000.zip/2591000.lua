-- Lua provided by RyzenAPI
-- Game: Game: Kill The Topulus Demo

-- MAIN APPLICATION
addappid(2591000)
-- Game: addappid(2591000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591001, 1, "aaf2251c039e71bbc1d6d289209e8ee1b91ab80da193eed9d73de6566321de32")
