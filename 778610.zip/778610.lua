-- Lua provided by RyzenAPI
-- Game: Foto Flash

-- MAIN APPLICATION
addappid(778610)

-- MAIN APP DEPOTS / PACKAGES
addappid(778611, 1, "9ab38951f592ef0a32a686612453a4c6570e1cba1d3835c8bd82447a84ba7097")

