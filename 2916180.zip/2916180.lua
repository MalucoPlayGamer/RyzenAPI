-- Lua provided by RyzenAPI
-- Game: addappid(2916180)

-- MAIN APPLICATION
addappid(2916180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2916181, 1, "001b61a78bacb3ea0ae2c0898a0a926900da948ccd2d67404913427b7dbe8636")
