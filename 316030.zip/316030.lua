-- Lua provided by RyzenAPI
-- Game: Disney Alice in Wonderland

-- MAIN APPLICATION
addappid(316030)

-- MAIN APP DEPOTS / PACKAGES
addappid(316031, 1, "5a04f9a8eec42cf36cdd5b71f18548b23082db88929897df3aa4900af69e0abc")
addappid(316032, 1, "fdb8fe011e9f40d0af514cfb8224e761cb431240224a7f45699a7a36e388a160")
addappid(316033, 1, "634bc4437c0508fee4efe3109b4729c76643ddeb8f4c4ec93c7e94394e999511")
addappid(316034, 1, "eec0151a334aafe167f1197cb7098d2935c3913f792709ed6963e4f86008e85a")
addappid(316035, 1, "b5cd0fe19739938024c0b2d69000a612aac0003d772beb5e19cb33ee9a265259")
addappid(316036, 1, "6745b3b2b27aebd9f666b4f16485cac6ed122330b68181f6cb4dff672d6c6f40")
addappid(316037, 1, "b6a410cc8cec4fb9e04d7e1fd1f2fcd153e42d4302a2afbe938a8aa1c578f724")
addappid(316038, 1, "3c0422e482c3fe6315720d3dd4b78a2262853a7d1a6b6d4fbf1c9bc1c5710200")
addappid(316039, 1, "066f95d97f6435d0590b6f7f5c4cae517a7e4eb2a544fc642cab133128159c68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
