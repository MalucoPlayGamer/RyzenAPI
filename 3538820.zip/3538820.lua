-- 3538820's Lua and Manifest Created by Hubcap Manifest
-- Galactic Simulator2: Stargate
-- Created: August 07, 2026 at 23:03:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(3538820) -- Galactic Simulator2: Stargate
-- MAIN APP DEPOTS
addappid(3538821, 1, "8d7b7aec10b106b3f6c26881c29ee2297db00ee0e2dcd0df7c519c5b1a8a4ae6") -- Depot 3538821
setManifestid(3538821, "1506285354538484081", 4789907625)
addappid(3538822, 1, "2b93a09d9601cddc2146569e4815d0c2167b4d0e66b9cf097cf1b8a7afeae2eb") -- Depot 3538822
setManifestid(3538822, "3966108592414614275", 4928484015)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3680030) -- Galactic Simulator2 Realistic
addappid(4450140) -- Galactic Simulator2 Supporter Pack