-- Lua provided by RyzenAPI
-- Game: Galactic Simulator2: Stargate

-- MAIN APPLICATION
addappid(3538820) -- Galactic Simulator2: Stargate
addappid(3680030) -- Galactic Simulator2 Realistic
addappid(4450140) -- Galactic Simulator2 Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(3538821, 1, "8d7b7aec10b106b3f6c26881c29ee2297db00ee0e2dcd0df7c519c5b1a8a4ae6") -- Depot 3538821
addappid(3538822, 1, "2b93a09d9601cddc2146569e4815d0c2167b4d0e66b9cf097cf1b8a7afeae2eb") -- Depot 3538822

