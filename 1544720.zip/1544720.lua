-- Lua provided by RyzenAPI
-- Game: 4th & Inches

-- MAIN APPLICATION
addappid(1544720)
-- Game: addappid(1544720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544721, 1, "1b58e7e0e13d124ce9ec18d5c1f1e960fc4546a623d3bcf7a5adbe3df56c6ddb")
