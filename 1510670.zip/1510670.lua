-- Lua provided by RyzenAPI
-- Game: ZADETTE

-- MAIN APPLICATION
addappid(1510670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1510671, 1, "8f9c650ac661651cf9d4a3f2aa2026fd7dd0927867ea262e3f9adcf727e89e5e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
