-- Lua provided by RyzenAPI
-- Game: Game: AppID 2236480

-- MAIN APPLICATION
addappid(2236480)
-- Game: addappid(2236480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236481, 1, "912f4e879ec5de6685b2c502fef6244611619c4c588579ef380c9766d93ba66f")
