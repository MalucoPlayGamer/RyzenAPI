-- Lua provided by RyzenAPI
-- Game: 756980

-- MAIN APPLICATION
addappid(756980)
-- Game: addappid(756980)

-- MAIN APP DEPOTS / PACKAGES
addappid(756981, 1, "b5abb1748342f44fe38e395ee924913c4d96adc9c8b4334ee0846ee393792a04")
