-- Lua provided by RyzenAPI
-- Game: Game: Emissary Zero

-- MAIN APPLICATION
addappid(3176060)
-- Game: addappid(3176060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176061, 1, "87ccd43a7ff83224384228a50111bc6cfee10144e93af2284c27dcdae12d5e38")
