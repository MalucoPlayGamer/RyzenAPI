-- Lua provided by RyzenAPI
-- Game: addappid(2462790)

-- MAIN APPLICATION
addappid(2462790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462791, 1, "7319a90228971ec853edfd31a70f139222ca4b106a8fa984499ea4428b39cef1")
