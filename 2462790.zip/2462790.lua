-- Lua provided by RyzenAPI 
-- Game: Aether
addappid(2462790)
addappid(2462791, 1, "7319a90228971ec853edfd31a70f139222ca4b106a8fa984499ea4428b39cef1")
