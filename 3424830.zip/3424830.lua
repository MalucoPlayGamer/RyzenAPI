-- Lua provided by RyzenAPI
-- Game: 3424830

-- MAIN APPLICATION
addappid(3424830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3424832,0,"5f6f764d11a54bfe6ca4ff1225c02109fce3cbbc739739fa0e0b1f2d151a515e")
