-- Lua provided by RyzenAPI
-- Game: Backrooms Multi-Verses

-- MAIN APPLICATION
addappid(3424830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3424832,0,"5f6f764d11a54bfe6ca4ff1225c02109fce3cbbc739739fa0e0b1f2d151a515e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
