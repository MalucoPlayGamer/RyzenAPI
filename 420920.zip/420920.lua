-- Lua provided by RyzenAPI
-- Game: Game: Lost Labyrinth Extended Version

-- MAIN APPLICATION
addappid(420920)
-- Game: addappid(420920)

-- MAIN APP DEPOTS / PACKAGES
addappid(420921, 1, "663afda818753a52e025d40bc3f3cd37f9d4db56256533fba384009ecea6d081")
