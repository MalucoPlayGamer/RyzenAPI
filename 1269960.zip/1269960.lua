-- Lua provided by RyzenAPI
-- Game: Inferno Wizards

-- MAIN APPLICATION
addappid(1269960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269961, 1, "a51b8870867abb135cc081cdd96d0bb9dd0c43c0b233c844ab4c2b49b4acb99c")

