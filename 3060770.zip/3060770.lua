-- Lua provided by RyzenAPI
-- Game: Shiftall VR Manager

-- MAIN APPLICATION
addappid(3060770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3060771, 1, "4469933a0d5dffcbc8ebd99e90811ed55da3aeab1060dba7930740842bd9094e")

