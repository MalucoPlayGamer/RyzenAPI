-- Lua provided by RyzenAPI
-- Game: addappid(3060770)

-- MAIN APPLICATION
addappid(3060770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3060771, 1, "4469933a0d5dffcbc8ebd99e90811ed55da3aeab1060dba7930740842bd9094e")
