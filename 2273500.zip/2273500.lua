-- Lua provided by RyzenAPI
-- Game: JOIN tiles - Anatolian game to play

-- MAIN APPLICATION
addappid(2273500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273501, 1, "e3663f1514a00236f13f83e43b704ba315f4bb1ce55c973c6fcf524ed129f4f7")
