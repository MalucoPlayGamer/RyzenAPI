-- Lua provided by RyzenAPI
-- Game: Vault of Power

-- MAIN APPLICATION
addappid(2515050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515051, 1, "a54a7c7cf7275ef5173ea35413416caef4271c15291974ccfa58907d122e9117")

