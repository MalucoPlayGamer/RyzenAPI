-- Lua provided by RyzenAPI
-- Game: Jad

-- MAIN APPLICATION
addappid(1447060)
-- Game: addappid(1447060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447061, 1, "1a46a8857dbf361f83ad54106b028d8ec828df5b502869893bcd0df59379c264")
