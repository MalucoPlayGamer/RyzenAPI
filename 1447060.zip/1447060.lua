-- Lua provided by RyzenAPI
-- Game: Jad

-- MAIN APPLICATION
addappid(1447060)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1447061, 1, "1a46a8857dbf361f83ad54106b028d8ec828df5b502869893bcd0df59379c264")

