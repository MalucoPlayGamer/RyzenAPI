-- Lua provided by RyzenAPI
-- Game: Game: AppID 709630

-- MAIN APPLICATION
addappid(709630)
-- Game: addappid(709630)

-- MAIN APP DEPOTS / PACKAGES
addappid(709631, 1, "1fc5f97da9e865606638389a87cf95bb15602cad7ff1c9ef581d33eb3078761e")
