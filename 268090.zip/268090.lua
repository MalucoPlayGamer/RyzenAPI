-- Lua provided by RyzenAPI
-- Game: addappid(268090)

-- MAIN APPLICATION
addappid(268090)

-- MAIN APP DEPOTS / PACKAGES
addappid(268090,0,"5113a6432e32c1ef6474caf358c74e24c48bdfacf2a607a2c81257af514abf26")
