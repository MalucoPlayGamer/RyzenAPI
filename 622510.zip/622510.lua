-- Lua provided by RyzenAPI
-- Game: Lootfest Wars

-- MAIN APPLICATION
addappid(622510)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(622511, 1, "c2d9d1aa0b51bc9f9eea095c687cbb3e9640fbdc49e522ab8b1e03b7ca0cb3f9")

