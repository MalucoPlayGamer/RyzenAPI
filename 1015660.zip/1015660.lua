-- Lua provided by RyzenAPI
-- Game: addappid(1015660)

-- MAIN APPLICATION
addappid(1015660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015661, 1, "f68d06d75654966d0ac244faff57afcb2bcca82a07160ca05267e5399dc2db60")
