-- Lua provided by RyzenAPI
-- Game: Tales of Lyfael

-- MAIN APPLICATION
addappid(3613040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3613041, 1, "a82deaf79aff8bbb73ef8a508ba4392230455aae73385ed3b5b00c2689600143")
addappid(3648790, 0, "3c0e0f250f660360feda6200995360755c692d2fa4e20c18ac4bfe85e3d311d9")

