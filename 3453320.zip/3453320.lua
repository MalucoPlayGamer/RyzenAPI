-- Lua provided by RyzenAPI
-- Game: Squirreled Away Demo

-- MAIN APPLICATION
addappid(3453320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453321, 1, "2bd955dccbe493602075a0d8911294761671bf09438845f4a2d9ea65d0174d6b")
