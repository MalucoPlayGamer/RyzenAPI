-- Lua provided by RyzenAPI
-- Game: Game: AI Learns To Drive

-- MAIN APPLICATION
addappid(3312030)
-- Game: addappid(3312030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3312031, 1, "7ad30214c8a641abe2c259c892ec5d4e563e8cf2b1799cf748b8c5e596a112bb")
