-- Lua provided by RyzenAPI
-- Game: Game: AppID 1020650

-- MAIN APPLICATION
addappid(1020650)
-- Game: addappid(1020650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020651, 1, "494bcc4059c7778839c1b10025f4395cfa4f4d0912d52fb980d81d2232dbf05a")
