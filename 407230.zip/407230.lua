-- Lua provided by RyzenAPI
-- Game: 407230

-- MAIN APPLICATION
addappid(407230)
-- Game: addappid(407230)

-- MAIN APP DEPOTS / PACKAGES
addappid(407231, 1, "5f96962883e9826b9a4929db5642c3cc0afa45f3b3a5b8dea0d8e89eb08aba45")
