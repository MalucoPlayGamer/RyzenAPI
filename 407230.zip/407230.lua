-- Lua provided by RyzenAPI
-- Game: Legend of Mysteria RPG

-- MAIN APPLICATION
addappid(407230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(407231, 1, "5f96962883e9826b9a4929db5642c3cc0afa45f3b3a5b8dea0d8e89eb08aba45")

