-- Lua provided by RyzenAPI
-- Game: Secret Psychology

-- MAIN APPLICATION
addappid(2961340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2961341, 1, "caa70ee1cd316f73f80e4d03e6ceecb036d764dc1d3988daeacb3d1026e02855")
