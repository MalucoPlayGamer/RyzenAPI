-- Lua provided by RyzenAPI
-- Game: Gods of Savvarah | Part I

-- MAIN APPLICATION
addappid(2098870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098871, 1, "aca547a57de740bafe2aae6f361c714a64b81112e01049940ac7c11b7040ac74")
