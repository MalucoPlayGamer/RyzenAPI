-- Lua provided by RyzenAPI
-- Game: AppID 2849630

-- MAIN APPLICATION
addappid(2849630)
-- Game: addappid(2849630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2849631, 1, "70bc536364da4718c2e568912403fa2545531ae0857f872a358febbaf82fcd28")
