-- Lua provided by RyzenAPI
-- Game: addappid(230310)

-- MAIN APPLICATION
addappid(230310)

-- MAIN APP DEPOTS / PACKAGES
addappid(230311, 1, "2d6b6ec9f9b28c72692367089891aeb8de5649133fa7036ec856a766a091cb47")
