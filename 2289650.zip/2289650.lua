-- Lua provided by RyzenAPI
-- Game: Mini Airways - ATC simulator

-- MAIN APPLICATION
addappid(2289650)
addappid(4676210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289651, 1, "cd1f4ed0bf50ae85d7f8fbde2d41410ac016ab7ac9635308a0933c1f8090921c")
addappid(2289652, 1, "47da710eeb1bf191e01de1d300863dd33f3b942efad54fc3da7e029a33c3a52a")
addappid(2289653, 1, "4af34c62a8566a70932cb154fff77f889915e5e5e83675109c80227932c46321")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4829800)
