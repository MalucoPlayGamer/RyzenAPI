-- Lua provided by RyzenAPI
-- Game: Sumerian Six Demo

-- MAIN APPLICATION
addappid(2981640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981641, 1, "1ef19dfc52261feff8d025e60de609c03523a374c55c75d4b090870aefa7953b")

