-- Lua provided by RyzenAPI
-- Game: Coloring Book for Kids - Full Version

-- MAIN APPLICATION
addappid(1551950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551951, 1, "36fb80c3a7df6bad48bac0a868183fb4a6f187e60617f938664161d162a9d85a")

