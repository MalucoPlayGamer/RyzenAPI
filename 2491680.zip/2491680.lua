-- Lua provided by RyzenAPI 
-- Game: AppID 2491680
addappid(2491680)
addappid(2491681, 1, "41b79185b5a669a9a1a854ec4607060bc44ad1a3bd0a977db441c8234b2b5f6c")
