-- Lua provided by RyzenAPI
-- Game: 260040

-- MAIN APPLICATION
addappid(260040)
-- Game: addappid(260040)

-- MAIN APP DEPOTS / PACKAGES
addappid(260041, 1, "c33c9f0a651b505b89ebbe7d316118a257e3678e8894d40cbb50528fa3efca89")
