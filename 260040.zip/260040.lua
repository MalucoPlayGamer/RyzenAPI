-- Lua provided by RyzenAPI
-- Game: YOU DON'T KNOW JACK TELEVISION

-- MAIN APPLICATION
addappid(260040)

-- MAIN APP DEPOTS / PACKAGES
addappid(260041, 1, "c33c9f0a651b505b89ebbe7d316118a257e3678e8894d40cbb50528fa3efca89")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
