-- Lua provided by RyzenAPI
-- Game: 2312160

-- MAIN APPLICATION
addappid(2312160)
-- Game: addappid(2312160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312161, 1, "7c447c93275f152cf621fda520f90ce65e0e5423017c1ad18f516f6b8466edd2")
