-- Lua provided by RyzenAPI
-- Game: SAVAGE: The Shard of Gosen

-- MAIN APPLICATION
addappid(408060)

-- MAIN APP DEPOTS / PACKAGES
addappid(408061, 1, "9d04bbe2e9d4728142dd1ecd19f7b9b3580b0deff0b443db62ef903a58fb9577")

