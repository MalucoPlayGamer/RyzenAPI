-- Lua provided by RyzenAPI
-- Game: Magnet Block

-- MAIN APPLICATION
addappid(2092660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092661, 1, "b9c29cadd9ad6b49c41a2ba9a7997e9631a9ef907964b13644a318482a2ceee4")

