-- Lua provided by RyzenAPI
-- Game: Magnet Block

-- MAIN APPLICATION
addappid(2092660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2092661, 1, "b9c29cadd9ad6b49c41a2ba9a7997e9631a9ef907964b13644a318482a2ceee4")

