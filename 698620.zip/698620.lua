-- Lua provided by RyzenAPI
-- Game: Screamer 2

-- MAIN APPLICATION
addappid(698620)

-- MAIN APP DEPOTS / PACKAGES
addappid(698622,0,"cc9cbe947ec0363f8c6d1e611538ff39f84045d71df04619bca23e712b1df21a")

