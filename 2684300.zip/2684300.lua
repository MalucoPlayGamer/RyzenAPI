-- Lua provided by RyzenAPI
-- Game: Just skill shooter 2

-- MAIN APPLICATION
addappid(2684300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684301, 1, "094a4fbde2ce2f0715bd43c199fc50adfad92fb26c07999b1c5a5eb7fd767b0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
