-- Lua provided by RyzenAPI
-- Game: Just skill shooter 2

-- MAIN APPLICATION
addappid(2684300)
-- Game: addappid(2684300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684301, 1, "094a4fbde2ce2f0715bd43c199fc50adfad92fb26c07999b1c5a5eb7fd767b0a")
