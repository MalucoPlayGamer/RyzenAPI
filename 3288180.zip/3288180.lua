-- Lua provided by RyzenAPI
-- Game: Tales Beyond The Tomb - Pineville Night Stalker

-- MAIN APPLICATION
addappid(3288180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288181, 1, "a11565074848475045c24864577196bca60af1fca887aba73ab3cf99efde7f11")

