-- Lua provided by RyzenAPI
-- Game: Beat Saber: Lady Gaga - 'Paparazzi'

-- MAIN APPLICATION
addappid(1812884)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812884,0,"90c75c4e9d2796fa114c84d5a0b908c8f3c6e1512b5c5aadc3dc643c2d0f5419")
