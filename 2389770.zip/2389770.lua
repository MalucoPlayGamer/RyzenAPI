-- Lua provided by RyzenAPI
-- Game: Arobynn: Below The Surface

-- MAIN APPLICATION
addappid(2389770)
addappid(2510610)
addappid(2510620)
addappid(2510630)
addappid(2510640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2389771, 1, "a75a160d854a66c5380fbaa1a54832223888b613a61613f438905e4fc77fbf8a")

