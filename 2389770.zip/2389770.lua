-- Lua provided by RyzenAPI
-- Game: 2389770

-- MAIN APPLICATION
addappid(2389770)
addappid(2510610)
addappid(2510620)
addappid(2510630)
addappid(2510640)
-- Game: addappid(2389770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389771, 1, "a75a160d854a66c5380fbaa1a54832223888b613a61613f438905e4fc77fbf8a")
