-- Lua provided by RyzenAPI
-- Game: Runic Relay: The Trials

-- MAIN APPLICATION
addappid(1678050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678051, 1, "e27234c9f36151adb366d037e0bde5679377ea44feb052e94140cf52e88269fd")
