-- Lua provided by RyzenAPI
-- Game: Geneforge 2

-- MAIN APPLICATION
addappid(200980)

-- MAIN APP DEPOTS / PACKAGES
addappid(200981, 1, "89db589e071222a15802be28d21ae70d0a1b453b2f177b45a7d0f0fc1038f71a")
