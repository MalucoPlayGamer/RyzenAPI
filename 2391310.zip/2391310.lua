-- Lua provided by RyzenAPI
-- Game: Lies of Astaroth

-- MAIN APPLICATION
addappid(2391310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391311, 1, "efafbe4ba0845340d5c40c19645bedaa5efa57e0bb4f359c3a5aa7cc9b4b2d52")
