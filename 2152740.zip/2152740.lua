-- Lua provided by SkyAPI 
-- Game: ADEN
addappid(2152740)
addappid(2152741, 1, "811372d0db86d529dcb0b11a253e9164ec65c9a14a252f165fad85f9538b58fe")
