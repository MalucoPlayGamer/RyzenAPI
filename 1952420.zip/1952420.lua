-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1952420)
-- Game: addappid(1952420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952420,0,"62d98be7050b39dd1796470282a38f5581c0f52203c90d8f29e6bf081a518b7d")
