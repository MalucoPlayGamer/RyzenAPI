-- Lua provided by RyzenAPI
-- Game: Hentai Sweet Girls - Hard Levels DLC

-- MAIN APPLICATION
addappid(1128060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128060,0,"95e3ed78b30321b4b35e1b9208c9a73a44bdc1c1253ec7f8ac5a3fe0ca2d5224")

