-- Lua provided by RyzenAPI
-- Game: Song of Nunu: A League of Legends Story

-- MAIN APPLICATION
addappid(1333200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1333201, 1, "1ec4c98d5752ad071680b74caf54433e4f774b5b8d19b6a13c48440c57a7d493")
addappid(2475920, 0, "f13f7341c1df3a115ca9a960b367e86c768853f103a14130f8d4773522239d59")

