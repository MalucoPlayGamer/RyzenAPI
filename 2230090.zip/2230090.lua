-- Lua provided by RyzenAPI
-- Game: Game: Furry UwU

-- MAIN APPLICATION
addappid(2230090)
-- Game: addappid(2230090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230091, 1, "3fc3add27f40538765bc514503bd01125c1fc3e5ee4d03edda8c71db2076dc64")
