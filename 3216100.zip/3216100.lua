-- Lua provided by RyzenAPI
-- Game: Game: Decayed Evil 腐朽的邪恶

-- MAIN APPLICATION
addappid(3216100)
-- Game: addappid(3216100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216101, 1, "f5a532107015fa7706221a170be265185dfd2b55203f854b4da25723096ac52f")
