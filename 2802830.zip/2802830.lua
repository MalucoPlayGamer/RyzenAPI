-- Lua provided by RyzenAPI 
-- Game: AppID 2802830
addappid(2802830)
addappid(2802831, 1, "020c8754586ca86d76c189ce80b42a77dde00de89e3a589c95d847573ef76300")
