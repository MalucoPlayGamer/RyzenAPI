-- Lua provided by RyzenAPI
-- Game: FatalZone

-- MAIN APPLICATION
addappid(2488510)
-- Game: addappid(2488510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488511, 1, "8e879863873944727404d582b21dcbec4dedaf99ab95c33543eebbdfe05eaf16")
