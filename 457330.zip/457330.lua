-- Lua provided by RyzenAPI
-- Game: High Octane Drift

-- MAIN APPLICATION
addappid(457330)

-- MAIN APP DEPOTS / PACKAGES
addappid(457331, 1, "47663e7eed935d83a5b9a7e5908d14e50cc5f33499cb7cf24041e40dd5b5969d")
addappid(457332, 1, "a82ec9c729c6aa80687e055642c44baf4fe4a963d81c4a585fae97c5ca87630e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
