-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Food and Kitchenware Hard Pack

-- MAIN APPLICATION
addappid(1648413)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648413,0,"0bb9f54980859b861bfde350d162af0b6f8d69efca647d0e1417209f072f5ba7")
