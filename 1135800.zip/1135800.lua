-- 1135800's Lua and Manifest Created by Hubcap Manifest
-- Tiger Fighter 1931 Sunset
-- Created: October 01, 2025 at 01:43:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 100

-- MAIN APPLICATION
addappid(1135800) -- Tiger Fighter 1931 Sunset
-- MAIN APP DEPOTS
addappid(1135801, 1, "224ea21bba8b722b57a3c9f3efcc44f424ba2899f310a59b2c199940d35a9108") -- Tiger Fighter 1931 Sunset Content
setManifestid(1135801, "3481401069977895861", 6629507)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1704330) -- Tiger Fighter 1931 Sunset MP001
addappid(1704331) -- Tiger Fighter 1931 Sunset MP002
addappid(1704332) -- Tiger Fighter 1931 Sunset MP003
addappid(1704333) -- Tiger Fighter 1931 Sunset MP004
addappid(1704334) -- Tiger Fighter 1931 Sunset MP005
addappid(1704335) -- Tiger Fighter 1931 Sunset MP006
addappid(1704336) -- Tiger Fighter 1931 Sunset MP007
addappid(1704337) -- Tiger Fighter 1931 Sunset MP008
addappid(1704338) -- Tiger Fighter 1931 Sunset MP009
addappid(1704339) -- Tiger Fighter 1931 Sunset MP010
addappid(1704340) -- Tiger Fighter 1931 Sunset MP011
addappid(1704341) -- Tiger Fighter 1931 Sunset MP012
addappid(1704342) -- Tiger Fighter 1931 Sunset MP013
addappid(1704343) -- Tiger Fighter 1931 Sunset MP014
addappid(1704344) -- Tiger Fighter 1931 Sunset MP015
addappid(1704345) -- Tiger Fighter 1931 Sunset MP016
addappid(1704346) -- Tiger Fighter 1931 Sunset MP017
addappid(1704347) -- Tiger Fighter 1931 Sunset MP018
addappid(1704348) -- Tiger Fighter 1931 Sunset MP019
addappid(1704349) -- Tiger Fighter 1931 Sunset MP020
addappid(1704350) -- Tiger Fighter 1931 Sunset MP021
addappid(1704351) -- Tiger Fighter 1931 Sunset MP022
addappid(1704352) -- Tiger Fighter 1931 Sunset MP023
addappid(1704353) -- Tiger Fighter 1931 Sunset MP024
addappid(1704354) -- Tiger Fighter 1931 Sunset MP025
addappid(1704355) -- Tiger Fighter 1931 Sunset MP026
addappid(1704356) -- Tiger Fighter 1931 Sunset MP027
addappid(1704357) -- Tiger Fighter 1931 Sunset MP028
addappid(1704358) -- Tiger Fighter 1931 Sunset MP029
addappid(1704359) -- Tiger Fighter 1931 Sunset MP030
addappid(1704360) -- Tiger Fighter 1931 Sunset MP031
addappid(1704361) -- Tiger Fighter 1931 Sunset MP032
addappid(1704362) -- Tiger Fighter 1931 Sunset MP033
addappid(1704363) -- Tiger Fighter 1931 Sunset MP034
addappid(1704364) -- Tiger Fighter 1931 Sunset MP035
addappid(1704365) -- Tiger Fighter 1931 Sunset MP036
addappid(1704366) -- Tiger Fighter 1931 Sunset MP037
addappid(1704367) -- Tiger Fighter 1931 Sunset MP038
addappid(1704368) -- Tiger Fighter 1931 Sunset MP039
addappid(1704369) -- Tiger Fighter 1931 Sunset MP040
addappid(1704370) -- Tiger Fighter 1931 Sunset MP041
addappid(1704371) -- Tiger Fighter 1931 Sunset MP042
addappid(1704372) -- Tiger Fighter 1931 Sunset MP043
addappid(1704373) -- Tiger Fighter 1931 Sunset MP044
addappid(1704374) -- Tiger Fighter 1931 Sunset MP045
addappid(1704375) -- Tiger Fighter 1931 Sunset MP046
addappid(1704376) -- Tiger Fighter 1931 Sunset MP047
addappid(1704377) -- Tiger Fighter 1931 Sunset MP048
addappid(1704378) -- Tiger Fighter 1931 Sunset MP049
addappid(1704379) -- Tiger Fighter 1931 Sunset MP050
addappid(1704380) -- Tiger Fighter 1931 Sunset MP051
addappid(1704381) -- Tiger Fighter 1931 Sunset MP052
addappid(1704382) -- Tiger Fighter 1931 Sunset MP053
addappid(1704383) -- Tiger Fighter 1931 Sunset MP054
addappid(1704384) -- Tiger Fighter 1931 Sunset MP055
addappid(1704385) -- Tiger Fighter 1931 Sunset MP056
addappid(1704386) -- Tiger Fighter 1931 Sunset MP057
addappid(1704387) -- Tiger Fighter 1931 Sunset MP058
addappid(1704388) -- Tiger Fighter 1931 Sunset MP059
addappid(1704389) -- Tiger Fighter 1931 Sunset MP060
addappid(1704390) -- Tiger Fighter 1931 Sunset MP061
addappid(1704391) -- Tiger Fighter 1931 Sunset MP062
addappid(1704392) -- Tiger Fighter 1931 Sunset MP063
addappid(1704393) -- Tiger Fighter 1931 Sunset MP064
addappid(1704394) -- Tiger Fighter 1931 Sunset MP065
addappid(1704395) -- Tiger Fighter 1931 Sunset MP066
addappid(1704396) -- Tiger Fighter 1931 Sunset MP067
addappid(1704397) -- Tiger Fighter 1931 Sunset MP068
addappid(1704398) -- Tiger Fighter 1931 Sunset MP069
addappid(1704399) -- Tiger Fighter 1931 Sunset MP070
addappid(1704400) -- Tiger Fighter 1931 Sunset MP071
addappid(1704401) -- Tiger Fighter 1931 Sunset MP072
addappid(1704402) -- Tiger Fighter 1931 Sunset MP073
addappid(1704403) -- Tiger Fighter 1931 Sunset MP074
addappid(1704404) -- Tiger Fighter 1931 Sunset MP075
addappid(1704405) -- Tiger Fighter 1931 Sunset MP076
addappid(1704406) -- Tiger Fighter 1931 Sunset MP077
addappid(1704407) -- Tiger Fighter 1931 Sunset MP078
addappid(1704408) -- Tiger Fighter 1931 Sunset MP079
addappid(1704409) -- Tiger Fighter 1931 Sunset MP080
addappid(1704410) -- Tiger Fighter 1931 Sunset MP081
addappid(1704411) -- Tiger Fighter 1931 Sunset MP082
addappid(1704412) -- Tiger Fighter 1931 Sunset MP083
addappid(1704413) -- Tiger Fighter 1931 Sunset MP084
addappid(1704414) -- Tiger Fighter 1931 Sunset MP085
addappid(1704415) -- Tiger Fighter 1931 Sunset MP086
addappid(1704416) -- Tiger Fighter 1931 Sunset MP087
addappid(1704417) -- Tiger Fighter 1931 Sunset MP088
addappid(1704418) -- Tiger Fighter 1931 Sunset MP089
addappid(1704419) -- Tiger Fighter 1931 Sunset MP090
addappid(1704420) -- Tiger Fighter 1931 Sunset MP091
addappid(1704421) -- Tiger Fighter 1931 Sunset MP092
addappid(1704422) -- Tiger Fighter 1931 Sunset MP093
addappid(1704423) -- Tiger Fighter 1931 Sunset MP094
addappid(1704424) -- Tiger Fighter 1931 Sunset MP095
addappid(1704425) -- Tiger Fighter 1931 Sunset MP096
addappid(1704426) -- Tiger Fighter 1931 Sunset MP097
addappid(1704427) -- Tiger Fighter 1931 Sunset MP098
addappid(1704428) -- Tiger Fighter 1931 Sunset MP099
addappid(1704429) -- Tiger Fighter 1931 Sunset MP100