-- Lua provided by RyzenAPI 
-- Game: Tiger Fighter 1931 Sunset
addappid(1135800)
addappid(1135801, 1, "224ea21bba8b722b57a3c9f3efcc44f424ba2899f310a59b2c199940d35a9108")
