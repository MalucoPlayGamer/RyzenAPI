-- Lua provided by RyzenAPI
-- Game: Game: 蔚蓝月下的回忆~SAPPHIRE MOON-FOREVER MEMORIES 原画集

-- MAIN APPLICATION
addappid(2167710)
-- Game: addappid(2167710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167711, 1, "a0a5d16afd746972d3f8718bc7714c11910baa573914e19d87bf55995a15e3b4")
