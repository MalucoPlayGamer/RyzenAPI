-- Lua provided by RyzenAPI
-- Game: addappid(1076610)

-- MAIN APPLICATION
addappid(1076610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076611, 1, "ec65d5fef71421c6dfa0fce2ac9e23a54137f23e99c78d3fc2c4a9b78f295352")
