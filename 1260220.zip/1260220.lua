-- Lua provided by RyzenAPI
-- Game: Hentai Two Girls

-- MAIN APPLICATION
addappid(1260220)
addappid(1265100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260221, 1, "310916fb9e646420eaa6ddeae1a611109502cd662a9abe51e328c6dd2e50af6b")

