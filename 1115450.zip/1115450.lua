-- Lua provided by RyzenAPI
-- Game: AppID 1115450

-- MAIN APPLICATION
addappid(1115450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115451, 1, "9ed13205abec3ce6b09f0a8580f12411e3adc5ef7b0b65f544df81ad31bbb769")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
