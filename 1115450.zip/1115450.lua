-- Lua provided by SkyAPI 
-- Game: AppID 1115450
addappid(1115450)
addappid(1115451, 1, "9ed13205abec3ce6b09f0a8580f12411e3adc5ef7b0b65f544df81ad31bbb769")
