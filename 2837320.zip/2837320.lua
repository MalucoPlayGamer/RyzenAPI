-- Lua provided by RyzenAPI
-- Game: Unreal Physics

-- MAIN APPLICATION
addappid(2837320)
addappid(3066050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2837321, 1, "873ac7ebf1223e3efa64afcfcb0201085ac219d7df9083a7d38378943eff8f4b")

