-- Lua provided by RyzenAPI
-- Game: addappid(2837320)

-- MAIN APPLICATION
addappid(2837320)
addappid(3066050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2837321, 1, "873ac7ebf1223e3efa64afcfcb0201085ac219d7df9083a7d38378943eff8f4b")
