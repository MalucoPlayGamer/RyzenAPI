-- Lua provided by RyzenAPI
-- Game: Mad Experiments: Escape Room

-- MAIN APPLICATION
addappid(1201550)
addappid(1472800)
addappid(3290800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1201551, 1, "d7a1901dfb50b304fa1ef45cc743b495b83b1ad2a6c2ae78fdfa6c3a85cc7dcc")
addappid(1201552, 1, "ff6ae32e6eee7f4890d57829e97353de11e9cf51c26af75d909e878da7503554")
addappid(1201553, 1, "58eecb80fe988aa859e17fc18a7285292fba5d489385adbf41964bac8cabd5ab")

