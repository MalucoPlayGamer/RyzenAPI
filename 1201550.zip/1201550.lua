-- Lua provided by RyzenAPI
-- Game: 1201550

-- MAIN APPLICATION
addappid(1201550)
addappid(1472800)
-- Game: addappid(1201550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201551, 1, "d7a1901dfb50b304fa1ef45cc743b495b83b1ad2a6c2ae78fdfa6c3a85cc7dcc")
addappid(1201552, 1, "ff6ae32e6eee7f4890d57829e97353de11e9cf51c26af75d909e878da7503554")
addappid(1201553, 1, "58eecb80fe988aa859e17fc18a7285292fba5d489385adbf41964bac8cabd5ab")
