-- Lua provided by RyzenAPI
-- Game: Last Lesson

-- MAIN APPLICATION
addappid(2588610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2588611, 1, "5d44537c054750f4ac9bb6950b73d24dd6f964f0e164315729abdd7ecea0872d")

