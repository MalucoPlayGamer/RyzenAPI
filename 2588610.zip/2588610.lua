-- Lua provided by RyzenAPI
-- Game: Game: Last Lesson

-- MAIN APPLICATION
addappid(2588610)
-- Game: addappid(2588610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588611, 1, "5d44537c054750f4ac9bb6950b73d24dd6f964f0e164315729abdd7ecea0872d")
