-- Lua provided by RyzenAPI 
-- Game: Last Lesson
addappid(2588610)
addappid(2588611, 1, "5d44537c054750f4ac9bb6950b73d24dd6f964f0e164315729abdd7ecea0872d")
