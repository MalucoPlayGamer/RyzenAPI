-- Lua provided by RyzenAPI
-- Game: Escape Party Demo

-- MAIN APPLICATION
addappid(3027020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027021, 1, "b4bb44113d11d9f7bb7254a9a33a35325c255f02e734351ec7316ccb61b020d6")

