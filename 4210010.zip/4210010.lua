-- 4210010's Lua and Manifest Created by Hubcap Manifest
-- Incremental Infinity
-- Created: July 20, 2026 at 13:08:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4210010) -- Incremental Infinity
-- MAIN APP DEPOTS
addappid(4210011, 1, "ef3082e6c390f5852ad4a854b72dfbb24d7a678aa42bccd23a41740f502fc101") -- Depot 4210011
setManifestid(4210011, "5457240622027805020", 319464428)