-- Lua provided by RyzenAPI
-- Game: Shadowkin

-- MAIN APPLICATION
addappid(2212410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2212413,0,"17924b6636c39f867982238d5563ba38ea8115c67defb232f5ba11b55d35ec33")
