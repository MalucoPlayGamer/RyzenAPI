-- Lua provided by RyzenAPI
-- Game: 2999650

-- MAIN APPLICATION
addappid(2999650)
-- Game: addappid(2999650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999650,0,"a2ac12bbb27f3659bc064fef1f20c10644a81b66411a1a38a76da5d395f52b2f")
