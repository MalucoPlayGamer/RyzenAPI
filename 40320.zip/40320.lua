-- Lua provided by RyzenAPI
-- Game: Rush for Berlin Gold

-- MAIN APPLICATION
addappid(40320)

-- MAIN APP DEPOTS / PACKAGES
addappid(40321, 1, "735675534a9c22b2a6c1de1460c8c811006ea89209cc4f1843f65cbfd559455d")
addappid(40322, 1, "7d5ef1636c0c8a2450d6136b29573d94479a0eae06089ef9b1dff91c8346746f")
addappid(40323, 1, "c2b14b9161a1ca858acd310c1a911d52de1999a6ded4025d38079646c4ac27cc")
addappid(40324, 1, "a34d548234914080729295ac054c4c49370242105216cc6f6b2ee9e4bffbf4a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
