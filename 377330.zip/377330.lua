-- Lua provided by RyzenAPI
-- Game: Close Your Eyes [Old Version]

-- MAIN APPLICATION
addappid(377330)

