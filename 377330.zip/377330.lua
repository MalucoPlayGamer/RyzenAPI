-- Lua provided by RyzenAPI
-- Game: Close Your Eyes [Old Version]

-- MAIN APPLICATION
addappid(377330)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(377420)
addappid(645840)
