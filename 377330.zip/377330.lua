-- Lua provided by RyzenAPI
-- Game: Close Your Eyes [Old Version]

-- MAIN APPLICATION
addappid(377330)
addappid(377420)
addappid(645840)

