-- Lua provided by SkyAPI 
-- Game: FPS Chess
addappid(2021910)
addappid(2021911, 1, "5f5fa4c651ce6b4a32cae72b1eb5790b32d8587e870cacb32d5560613e940deb")
addappid(4695090)
