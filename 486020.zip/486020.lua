-- Lua provided by RyzenAPI
-- Game: AppID 486020

-- MAIN APPLICATION
addappid(486020)
addappid(569310)

-- MAIN APP DEPOTS / PACKAGES
addappid(486021, 1, "9a287363430bf17763c07429f4b92bcc2f90cddd1c7e753c91e7d8e8816e44bd")

