-- Lua provided by RyzenAPI
-- Game: 3352920

-- MAIN APPLICATION
addappid(3352920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3352920,0,"15279105a0ebc57a5588ed22812aea706faafa66bb6ea6cc0bf07b4186e8e16a")

