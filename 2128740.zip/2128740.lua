-- Lua provided by RyzenAPI 
-- Game: Staffer Case - Case1 & 2
addappid(2128740)
addappid(2128741, 1, "38b71ceafb4a53a3a9ef784083389231ec821d95b41b9c12e78ea3b250b8b1d4")
