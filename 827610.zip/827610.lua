-- Lua provided by RyzenAPI
-- Game: 827610

-- MAIN APPLICATION
addappid(827610)
-- Game: addappid(827610)

-- MAIN APP DEPOTS / PACKAGES
addappid(827611, 1, "a139f354a87b82a71c153df87dde88ec8e9f4075a60226ad8483a0a6eed6c700")
addappid(827613, 1, "a285c6022cf2ab5fe7ace1ee0a83b90e0e49d70a2694541780b11ff810f6f687")
