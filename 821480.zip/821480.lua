-- Lua provided by RyzenAPI
-- Game: Space Flowers

-- MAIN APPLICATION
addappid(821480)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(821481, 1, "1172de673875ece8b89277ec5ccf026eed246d11465841badcd6b74fbb96e5ac")

