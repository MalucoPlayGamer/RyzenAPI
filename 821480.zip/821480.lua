-- Lua provided by RyzenAPI
-- Game: Space Flowers

-- MAIN APPLICATION
addappid(821480)

-- MAIN APP DEPOTS / PACKAGES
addappid(821481, 1, "1172de673875ece8b89277ec5ccf026eed246d11465841badcd6b74fbb96e5ac")

