-- Lua provided by RyzenAPI
-- Game: addappid(1174680)

-- MAIN APPLICATION
addappid(1174680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174681, 1, "6e1c88979cffdc53bed721cb4888efab3cac98ee13944c9d13fde457c91bfc78")
