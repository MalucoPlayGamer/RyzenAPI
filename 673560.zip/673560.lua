-- Lua provided by RyzenAPI
-- Game: IOSoccer

-- MAIN APPLICATION
addappid(673560)

-- MAIN APP DEPOTS / PACKAGES
addappid(673561, 1, "e062c7bf5bc1bbac35a86c29ef5533e7421d3ca526aa5bdce668665fb8494812")
