-- Lua provided by RyzenAPI
-- Game: IOSoccer

-- MAIN APPLICATION
addappid(673560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(673561, 1, "e062c7bf5bc1bbac35a86c29ef5533e7421d3ca526aa5bdce668665fb8494812")

