-- Lua provided by RyzenAPI 
-- Game: Neon Warfield
addappid(3751470)
addappid(3751471, 1, "6690df52fe82278e5bc7e246c6ddfa553e0d0f1ae67df864ea1fb2647d82f9be")
