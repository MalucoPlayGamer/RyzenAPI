-- Lua provided by RyzenAPI
-- Game: 3751470

-- MAIN APPLICATION
addappid(3751470)
-- Game: addappid(3751470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751471, 1, "6690df52fe82278e5bc7e246c6ddfa553e0d0f1ae67df864ea1fb2647d82f9be")
