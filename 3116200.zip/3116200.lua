-- Lua provided by SkyAPI 
-- Game: Poker Tower Defense
addappid(3116200)
addappid(3116201, 1, "e23f04ac95e3a88998b6d570763649b32c4e754bfe1d187ea9fbb5dd78fa9d0f")
