-- Lua provided by RyzenAPI
-- Game: //SNOWFLAKE TATTOO//

-- MAIN APPLICATION
addappid(355430)

-- MAIN APP DEPOTS / PACKAGES
addappid(355431, 1, "c8130761facb0ed457bf0d94864419661d5b4aa0fdd536a6dcfc86ca5f5875dd")
