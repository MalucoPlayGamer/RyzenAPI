-- Lua provided by RyzenAPI
-- Game: addappid(1571820)

-- MAIN APPLICATION
addappid(1571820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571821, 1, "2377df26b7c9fa43a0cc970a08b1f87cac98193aa3c49ec12502b24472ae6207")
