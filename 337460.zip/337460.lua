-- Lua provided by RyzenAPI
-- Game: 18 Wheels of Steel: Pedal to the Metal

-- MAIN APPLICATION
addappid(337460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(337461, 1, "e29279f25befc273f19b56b83ede249d22523085b80682e0bbe2c903b760ff2d")
