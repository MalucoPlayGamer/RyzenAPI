-- Lua provided by RyzenAPI
-- Game: 337460

-- MAIN APPLICATION
addappid(337460)
-- Game: addappid(337460)

-- MAIN APP DEPOTS / PACKAGES
addappid(337461, 1, "e29279f25befc273f19b56b83ede249d22523085b80682e0bbe2c903b760ff2d")
