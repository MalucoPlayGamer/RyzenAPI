-- Lua provided by RyzenAPI
-- Game: Immortal: Unchained - Soundtrack

-- MAIN APPLICATION
addappid(933850)

-- MAIN APP DEPOTS / PACKAGES
addappid(933851, 1, "ffbbbb096d6a9a739df84162874d8b00de296b66ed99f313dd180830114774f5")

