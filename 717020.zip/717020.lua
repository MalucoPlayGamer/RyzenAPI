-- Lua provided by RyzenAPI
-- Game: Game: AppID 717020

-- MAIN APPLICATION
addappid(717020)
-- Game: addappid(717020)

-- MAIN APP DEPOTS / PACKAGES
addappid(717021, 1, "e65890acdb6646428d31bbb8c96155818adaa2724e0f7df8baf9ffe975b4eea4")
