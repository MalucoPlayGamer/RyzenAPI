-- Lua provided by RyzenAPI
-- Game: 1431050

-- MAIN APPLICATION
addappid(1431050)
-- Game: addappid(1431050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431051, 1, "f5d5f44cc618348ab45ce04196d55f46f44cfe24cac85f96abb8d2c582b28e6f")
addappid(1431052, 1, "391904929f222ef8abb8c3cdb9e5019737669a6d36336cdc7a79c49fcd40caaa")
