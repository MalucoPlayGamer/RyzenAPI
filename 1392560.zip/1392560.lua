-- Lua provided by RyzenAPI
-- Game: Game: Serious Fun Football

-- MAIN APPLICATION
addappid(1392560)
-- Game: addappid(1392560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392561, 1, "3a9c053cb6d7edc0d21c7a8deffb04626d0d142faad322861736b2143429977b")
