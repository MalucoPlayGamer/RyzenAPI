-- Lua provided by RyzenAPI 
-- Game: Serious Fun Football
addappid(1392560)
addappid(1392561, 1, "3a9c053cb6d7edc0d21c7a8deffb04626d0d142faad322861736b2143429977b")
