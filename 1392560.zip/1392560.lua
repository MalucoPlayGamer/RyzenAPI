-- Lua provided by RyzenAPI
-- Game: Serious Fun Football

-- MAIN APPLICATION
addappid(1392560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392561, 1, "3a9c053cb6d7edc0d21c7a8deffb04626d0d142faad322861736b2143429977b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
