-- Lua provided by RyzenAPI
-- Game: addappid(1217830)

-- MAIN APPLICATION
addappid(1217830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217831, 1, "94f539441d56e7fcd8f3a11a986b7e2c836f4b87bb628602dbef5925a3f41455")
