-- Lua provided by SkyAPI 
-- Game: Teddy Floppy Ear - Mountain Adventure
addappid(340300)
addappid(340301, 1, "33311c7f0e573be0010589d9fe5accc6b9f555a40f7e733ff2d5e8027a302777")
addappid(340302, 1, "59a984cba9cc4d6d960ac4893a89531d38fd54f888e260d8fe1ba80460649f26")
addappid(340303, 1, "f440e462a48c102c5bfdf8cc161efbc5eac947a85e4a6756be30c8dc9407f357")
