-- Lua provided by RyzenAPI
-- Game: addappid(2105910)

-- MAIN APPLICATION
addappid(2105910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2105911, 1, "6f37c7df68861c61298f0adb97a6295ee6d2bf6461cdf769bb29ce3e14ae9e8c")
