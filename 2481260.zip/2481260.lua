-- Lua provided by RyzenAPI
-- Game: 仙豆奇缘 MagicBeans

-- MAIN APPLICATION
addappid(2481260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2481261, 1, "cf1e370ea9aa1f7a82cc330d3f2409d19a25aae3741411a50b6aa899f7c826af")

