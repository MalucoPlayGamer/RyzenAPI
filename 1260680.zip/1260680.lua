-- Lua provided by RyzenAPI 
-- Game: Hentai Furry Soundtrack
addappid(1260680)
addappid(1260681, 1, "126cd05ec27df24aa2ecff979baf47f87bad06007db7ae019954b360a318c79f")
