-- Lua provided by RyzenAPI
-- Game: 1260680

-- MAIN APPLICATION
addappid(1260680)
-- Game: addappid(1260680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260681, 1, "126cd05ec27df24aa2ecff979baf47f87bad06007db7ae019954b360a318c79f")
