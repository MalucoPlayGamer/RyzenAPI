-- Lua provided by SkyAPI 
-- Game: Superbugs: Awaken
addappid(1393570)
addappid(1393571, 1, "182dabe98555b2a08e8b9be2beb195bd865e85fa39969ed9c1607164a673d322")
