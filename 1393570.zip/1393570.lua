-- Lua provided by RyzenAPI
-- Game: Superbugs: Awaken

-- MAIN APPLICATION
addappid(1393570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393571, 1, "182dabe98555b2a08e8b9be2beb195bd865e85fa39969ed9c1607164a673d322")
