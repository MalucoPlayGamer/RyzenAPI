-- Lua provided by RyzenAPI
-- Game: Exo One Soundtrack

-- MAIN APPLICATION
addappid(1595980)
-- Game: addappid(1595980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595981, 1, "c8bf3089b0df55339b03c81f895d66bdb448c545947be43a5136b58689365c89")
addappid(1595982, 1, "bbb50c206ca71bed307ddc9bbe0ba82e7df5529c3f5566a730b3c61224084808")
