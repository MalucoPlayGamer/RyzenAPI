-- Lua provided by RyzenAPI
-- Game: addappid(760580)

-- MAIN APPLICATION
addappid(760580)

-- MAIN APP DEPOTS / PACKAGES
addappid(760581, 1, "d4a2bbc76e4862cc94c8f8d13df6041a438f6ccd2e67447e47b2062f762d3eaa")
