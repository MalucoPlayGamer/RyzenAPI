-- Lua provided by RyzenAPI
-- Game: QUALIA 3: Multi Agent

-- MAIN APPLICATION
addappid(290440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(290441, 1, "7e0e91f5f085815770e2e9e2f8bb67d24ec7b1f0bb20304843e3468859e93716")
addappid(290442, 1, "bd395ba1885e10b8cffd4628e790cda971427e30eb2af9ae87db5800a4d74b35")

