-- Lua provided by RyzenAPI
-- Game: Game: Cubanoids

-- MAIN APPLICATION
addappid(934510)
-- Game: addappid(934510)

-- MAIN APP DEPOTS / PACKAGES
addappid(934511, 1, "ce7ef1ae24eff88c70bb7588e89a9e3ea545213ffdd52eecb94838b3308a128d")
