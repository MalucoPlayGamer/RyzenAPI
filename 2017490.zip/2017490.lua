-- Lua provided by SkyAPI 
-- Game: Hot Milf 7
addappid(2017490)
addappid(2017491, 1, "16dcb89e2e6c21413a2823ccf7dd35cc337aa7ea0a701685bea8d1420d766ad3")
