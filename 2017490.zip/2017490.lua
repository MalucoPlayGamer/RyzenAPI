-- Lua provided by RyzenAPI
-- Game: Hot Milf 7

-- MAIN APPLICATION
addappid(2017490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017491, 1, "16dcb89e2e6c21413a2823ccf7dd35cc337aa7ea0a701685bea8d1420d766ad3")
