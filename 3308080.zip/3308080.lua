-- Lua provided by RyzenAPI
-- Game: addappid(3308080)

-- MAIN APPLICATION
addappid(3308080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308080,0,"c141c6fc33a5bcd2f2866830d6c0d752c2c6d22a9062ec130ff622bf2a791c1a")
