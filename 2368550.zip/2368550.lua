-- Lua provided by RyzenAPI
-- Game: 2368550

-- MAIN APPLICATION
addappid(2368550)
-- Game: addappid(2368550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368551, 1, "c35233a1405b8ef5b9f9826970bd5f9337f2b8aa2f2c4eb456eab30afb146326")
