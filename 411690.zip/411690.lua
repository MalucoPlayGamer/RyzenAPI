-- Lua provided by RyzenAPI
-- Game: 411690

-- MAIN APPLICATION
addappid(411690)
-- Game: addappid(411690)

-- MAIN APP DEPOTS / PACKAGES
addappid(411691, 1, "3449c410c996305a06734839b1c6f347b1cd4005fd76d443653cbe0cd37eb814")
