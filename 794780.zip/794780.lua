-- Lua provided by RyzenAPI
-- Game: 794780

-- MAIN APPLICATION
addappid(794780)
-- Game: addappid(794780)

-- MAIN APP DEPOTS / PACKAGES
addappid(794781, 1, "ce33b7d2dac5d90d0864251a56603702157b1c54a3eaa0491c79164b0118eae4")
