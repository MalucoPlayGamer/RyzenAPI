-- Lua provided by RyzenAPI
-- Game: Cauldrons of War - Stalingrad Demo

-- MAIN APPLICATION
addappid(1698970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698971, 1, "f6e18b621ed4e6bc6a6d2f831bf28be4de521e5e6d775d11c046c89354f2d8d2")

