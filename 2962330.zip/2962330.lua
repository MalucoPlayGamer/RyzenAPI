-- Lua provided by RyzenAPI 
-- Game: Kitty Collapse
addappid(2962330)
addappid(2962331, 1, "a52eb792f5b39d4cde1b4dd56b1c3ee92ec7192c780d5374c96308862fd551b0")
