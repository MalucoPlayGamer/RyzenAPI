-- Lua provided by RyzenAPI
-- Game: Kitty Collapse

-- MAIN APPLICATION
addappid(2962330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962331, 1, "a52eb792f5b39d4cde1b4dd56b1c3ee92ec7192c780d5374c96308862fd551b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
