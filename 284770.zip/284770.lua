-- Lua provided by RyzenAPI
-- Game: Enigmatis 2: The Mists of Ravenwood

-- MAIN APPLICATION
addappid(284770)

-- MAIN APP DEPOTS / PACKAGES
addappid(284771, 1, "23a78b42899f7757947fcdff77adad4eb84c0164eb16dad51d8c740b0ae7a611")
addappid(284772, 1, "8a5a114587540097712dd5c592043a9da0b427012917aca942d6075671b21cbf")
addappid(284773, 1, "caf84ae42ce2bf81b9e84b74be6b2d648671faa90c232e9609d9176383cdb3a7")
