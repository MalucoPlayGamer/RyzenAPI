-- Lua provided by RyzenAPI
-- Game: AppID 1885570

-- MAIN APPLICATION
addappid(1885570)
-- Game: addappid(1885570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885571, 1, "eb12eea147eaa5fea358d18184ad1fec6f5290c827dd53bb5869418bbcba063e")
