-- Lua provided by RyzenAPI 
-- Game: AppID 1885570
addappid(1885570)
addappid(1885571, 1, "eb12eea147eaa5fea358d18184ad1fec6f5290c827dd53bb5869418bbcba063e")
