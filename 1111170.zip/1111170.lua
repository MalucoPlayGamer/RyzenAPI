-- Lua provided by RyzenAPI
-- Game: 1111170

-- MAIN APPLICATION
addappid(1111170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111170,0,"5fe6203e1f92d4911b3e85cbb3c021deceb87b367d15938a4d71ce0ffba792ce")

