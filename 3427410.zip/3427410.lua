-- Lua provided by RyzenAPI
-- Game: Wet City

-- MAIN APPLICATION
addappid(3427410)
-- Game: addappid(3427410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3427411, 1, "ede1fec504bc46b114b77fad38b62dc6a82d0c7b65cc354c96860b8372a3bdd7")
