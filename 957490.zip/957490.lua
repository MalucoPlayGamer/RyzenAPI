-- Lua provided by RyzenAPI
-- Game: My Cabin And I

-- MAIN APPLICATION
addappid(957490)
-- Game: addappid(957490)

-- MAIN APP DEPOTS / PACKAGES
addappid(957491, 1, "956091031bfd4e3463a46b79b940c2969296fb315f32b842667db42da3e5b818")
