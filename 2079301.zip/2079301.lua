-- Lua provided by RyzenAPI
-- Game: Sonic Frontiers: Explorer's Treasure Box

-- MAIN APPLICATION
addappid(2079301)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079301,0,"db37953f414051736b6e659e9146fa2e081148a94633fbea635610f79d6588da")

