-- Lua provided by RyzenAPI
-- Game: AppID 1798420

-- MAIN APPLICATION
addappid(1798420)
-- Game: addappid(1798420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798421, 1, "b5bd8c351b5000c16773e43920bf9fbe416ce971cf30d09fb3f1be22485cdff4")
