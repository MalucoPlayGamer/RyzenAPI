-- Lua provided by RyzenAPI
-- Game: AppID 1226990

-- MAIN APPLICATION
addappid(1226990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226991, 1, "39d101243f3e57cad4a6cd2110e45167df6dd32bf35d12e2414a5c8edf03d7be")
