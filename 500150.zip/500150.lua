-- Lua provided by RyzenAPI
-- Game: Time Gap

-- MAIN APPLICATION
addappid(500150)

-- MAIN APP DEPOTS / PACKAGES
addappid(500151, 1, "1dae1c08d7f20bd8b9a0a481fa76f7041e4919329537c48aff0a4de607d38bce")
