-- Lua provided by RyzenAPI
-- Game: Game: ALL IN ONE ADVENTURE VR

-- MAIN APPLICATION
addappid(3157790)
-- Game: addappid(3157790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3157791, 1, "a96a6df2ef9adeeb6ce1d36f4254fac3386c021742d8974b84a20005ab5c94fd")
