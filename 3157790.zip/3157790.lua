-- Lua provided by RyzenAPI
-- Game: ALL IN ONE ADVENTURE VR

-- MAIN APPLICATION
addappid(3157790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3157791, 1, "a96a6df2ef9adeeb6ce1d36f4254fac3386c021742d8974b84a20005ab5c94fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
