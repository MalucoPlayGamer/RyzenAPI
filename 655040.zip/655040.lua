-- Lua provided by RyzenAPI
-- Game: Game: Deltaplan Simulator

-- MAIN APPLICATION
addappid(655040)
-- Game: addappid(655040)

-- MAIN APP DEPOTS / PACKAGES
addappid(655041, 1, "68557585c0952c3186a890d330f3baf9509033542df4dd8926072f1a9562f948")
