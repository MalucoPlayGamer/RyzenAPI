-- Lua provided by SkyAPI 
-- Game: Deltaplan Simulator
addappid(655040)
addappid(655041, 1, "68557585c0952c3186a890d330f3baf9509033542df4dd8926072f1a9562f948")
