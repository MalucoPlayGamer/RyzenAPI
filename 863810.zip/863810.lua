-- Lua provided by RyzenAPI
-- Game: SMASH BOY Ver.KZ

-- MAIN APPLICATION
addappid(863810)

-- MAIN APP DEPOTS / PACKAGES
addappid(863812,0,"3ee5e08dccb1367199f9f06c7a059b381832784b0e868c1d6ca91ccdcec670ad")

