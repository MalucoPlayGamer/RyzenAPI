-- Lua provided by RyzenAPI
-- Game: Spinch

-- MAIN APPLICATION
addappid(794240)
-- Game: addappid(794240)

-- MAIN APP DEPOTS / PACKAGES
addappid(794241, 1, "eb22df60aab8a2d73fbc7426a326d499edbd6bb63cb8c902929dfe93d444c293")
