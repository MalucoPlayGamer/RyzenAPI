-- Lua provided by RyzenAPI
-- Game: addappid(1882510)

-- MAIN APPLICATION
addappid(1882510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882511, 1, "53a898d906c250911c7461f7b0679556d8a84bf26342fdd6be1db3e7a2f9555b")
