-- Lua provided by RyzenAPI
-- Game: A College of Thirst & Claws

-- MAIN APPLICATION
addappid(2944560) -- A College of Thirst & Claws
addappid(5045790)
addappid(5045800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2944561, 1, "d052f3316b6cdbf85e1724152ca69a8063aa81cdd996b3a005d59456daa826b6") -- Depot 2944561
addappid(5045790, 1, "a04d5c063380026511d371fda045d58ff2c8d9fc78814a3f335b56e5439e199f") -- A College of Thirst  Claws - Official Game Guide - Depot 5045790
addappid(5045800, 1, "2329239a63d86236472b1c8a545c4b91204d876e304373a86eaf1987191ca83d") -- A College of Thirst  Claws - Bonus Content - Depot 5045800

