-- 2944560's Lua and Manifest Created by Hubcap Manifest
-- A College of Thirst & Claws
-- Created: August 25, 2026 at 07:20:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2944560) -- A College of Thirst & Claws
-- MAIN APP DEPOTS
addappid(2944561, 1, "d052f3316b6cdbf85e1724152ca69a8063aa81cdd996b3a005d59456daa826b6") -- Depot 2944561
setManifestid(2944561, "7774375735685215663", 1759509871)
-- DLCS WITH DEDICATED DEPOTS
-- A College of Thirst  Claws - Official Game Guide (AppID: 5045790)
addappid(5045790)
addappid(5045790, 1, "a04d5c063380026511d371fda045d58ff2c8d9fc78814a3f335b56e5439e199f") -- A College of Thirst  Claws - Official Game Guide - Depot 5045790
setManifestid(5045790, "5173368630022046811", 778825)
-- A College of Thirst  Claws - Bonus Content (AppID: 5045800)
addappid(5045800)
addappid(5045800, 1, "2329239a63d86236472b1c8a545c4b91204d876e304373a86eaf1987191ca83d") -- A College of Thirst  Claws - Bonus Content - Depot 5045800
setManifestid(5045800, "2521450260183266526", 703636675)