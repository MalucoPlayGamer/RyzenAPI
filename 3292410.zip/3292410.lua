-- Lua provided by RyzenAPI
-- Game: Game: 转生魔塔

-- MAIN APPLICATION
addappid(3292410)
addappid(3430980)
-- Game: addappid(3292410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3292411, 1, "16d7ececf2db5ba5a981ed018dbc31e6def80aa76eb66c810161e377fa53e010")
