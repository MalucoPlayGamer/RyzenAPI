-- Lua provided by RyzenAPI 
-- Game: Hentai Girl
addappid(878750)
addappid(878751, 1, "7bbc0116a302d6304f564eeb42394fb801b787daf476785ff55c2fbe20c2be2c")
addappid(878752, 1, "e4488c397994d815df577ff8b4037ddd65d18aa9fcc3b352d105bbce5f411495")
