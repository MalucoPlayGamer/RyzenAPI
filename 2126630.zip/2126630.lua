-- Lua provided by RyzenAPI
-- Game: The Fantastic Kitty Rue

-- MAIN APPLICATION
addappid(2126630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2126631, 1, "7d60230da0a03c8316aeb670c6c5222d4658469ecc4ea9aad5efcf74363dde8b")

