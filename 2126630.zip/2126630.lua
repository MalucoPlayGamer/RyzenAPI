-- Lua provided by RyzenAPI
-- Game: addappid(2126630)

-- MAIN APPLICATION
addappid(2126630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126631, 1, "7d60230da0a03c8316aeb670c6c5222d4658469ecc4ea9aad5efcf74363dde8b")
