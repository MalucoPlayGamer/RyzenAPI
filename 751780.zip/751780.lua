-- Lua provided by RyzenAPI 
-- Game: Forager
addappid(751780)
addappid(751781, 1, "b096b7474197a6716373c7da14b6aeee481f4cb1b1c3f1f847e2bdbe90ef43f9")
addappid(751783, 1, "4b03431f19808b789191ace933f2fbf857b91c0d4371c44d0591c5cbe63208e7")
