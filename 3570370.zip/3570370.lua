-- Lua provided by RyzenAPI
-- Game: 3570370

-- MAIN APPLICATION
addappid(3570370)
-- Game: addappid(3570370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3570373,0,"4b19ddee3140df89a7334f21dc87be2ecebf8aa3acde63ecca13292eb2e694b5")
