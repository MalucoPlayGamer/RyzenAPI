-- Lua provided by RyzenAPI
-- Game: AppID 481110

-- MAIN APPLICATION
addappid(481110)

-- MAIN APP DEPOTS / PACKAGES
addappid(481111, 1, "4ff23ea20d5a810fd9d6cb76633f144c57c13915bb1930fff455bcc405e4dade")
addappid(481112, 1, "a1404aa73b36c7802ff56142f4317d5ca7523629070b9bac5349be4ae496f1b7")
addappid(481113, 1, "94fd4a03495a45b220493b2393c906a06a6fe19942af02199f2254f676062915")
addappid(481114, 1, "28eb199fd3ff30b3f3e846815f105ad48804fde4874bd8027eccc57a45d210b1")
addappid(530730, 0, "39aec2ca90a27cbf52acf259e6844a8b43510e0240b054d9224fda3616eb96d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
