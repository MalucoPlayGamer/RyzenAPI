-- Lua provided by RyzenAPI
-- Game: Game: Thorne - Death Merchants

-- MAIN APPLICATION
addappid(451920)
-- Game: addappid(451920)

-- MAIN APP DEPOTS / PACKAGES
addappid(451921, 1, "3954c152831d4b75f19157abe51f76a01448c04270e12d21afc19a95585d42b8")
