-- Lua provided by RyzenAPI
-- Game: addappid(1395900)

-- MAIN APPLICATION
addappid(1395900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395902,0,"d13cc8bcee663bcb236e341f9a65a7773cfea6ae53be6bdcfdda53155bb40dae")
