-- Lua provided by RyzenAPI
-- Game: Dino Delivery

-- MAIN APPLICATION
addappid(1109400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1109401, 1, "0ca7ef9f8c204d644b37b54c057d3a321a6968fa8d44cd2b295fd89e34d3d116")

