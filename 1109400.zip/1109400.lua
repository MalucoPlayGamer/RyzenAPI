-- Lua provided by RyzenAPI
-- Game: AppID 1109400

-- MAIN APPLICATION
addappid(1109400)
-- Game: addappid(1109400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1109401, 1, "0ca7ef9f8c204d644b37b54c057d3a321a6968fa8d44cd2b295fd89e34d3d116")
