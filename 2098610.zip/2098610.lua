-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails from Zero - SSS Classified Files Digital Art Book

-- MAIN APPLICATION
addappid(2098610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098610,0,"221110e4ec72b935c1482c20763910e118019c0e7368284a8185cb11352f4644")

