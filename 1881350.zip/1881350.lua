-- Lua provided by RyzenAPI
-- Game: The Odyssey of the Mammoth

-- MAIN APPLICATION
addappid(1881350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1881351, 1, "512d142b638a80b1f28df5400fed3d6bea390fd1fa15c90a842e7cef29a6c1f9")

