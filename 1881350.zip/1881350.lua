-- Lua provided by RyzenAPI 
-- Game: The Odyssey of the Mammoth
addappid(1881350)
addappid(1881351, 1, "512d142b638a80b1f28df5400fed3d6bea390fd1fa15c90a842e7cef29a6c1f9")
