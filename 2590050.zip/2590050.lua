-- Lua provided by RyzenAPI
-- Game: Relight The Dark

-- MAIN APPLICATION
addappid(2590050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590051, 1, "e56c9bea571331186732218d7df4a76b9ae1b01340c317e84fd83d31a4737e4b")

