-- Lua provided by RyzenAPI
-- Game: 236970

-- MAIN APPLICATION
addappid(236970)
-- Game: addappid(236970)

-- MAIN APP DEPOTS / PACKAGES
addappid(236971, 1, "0ea7e41d23fd7e05ff9e943f4b3ee41dd5cbafd56be4102fb22ddc579229115e")
addappid(236973, 1, "e632dc74c40cf25595e0e227eece6c9e12b145391c8c0368fee162a2b72da5a9")
