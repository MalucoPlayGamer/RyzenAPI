-- Lua provided by RyzenAPI
-- Game: Jack Keane 2 - The Fire Within

-- MAIN APPLICATION
addappid(236970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(236971, 1, "0ea7e41d23fd7e05ff9e943f4b3ee41dd5cbafd56be4102fb22ddc579229115e")
addappid(236973, 1, "e632dc74c40cf25595e0e227eece6c9e12b145391c8c0368fee162a2b72da5a9")

