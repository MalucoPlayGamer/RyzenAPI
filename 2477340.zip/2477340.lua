-- Lua provided by RyzenAPI 
-- Game: Expeditions: A MudRunner Game
addappid(2477340)
addappid(2477341, 1, "22d4226d21a2b7bd6a16784f1790c3905b675a00a531aaca94c7ea7f0ec706cb")
