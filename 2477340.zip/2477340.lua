-- Lua provided by RyzenAPI
-- Game: Expeditions: A MudRunner Game

-- MAIN APPLICATION
addappid(2477340)
addappid(2716240)
addappid(2716250)
addappid(2716260)
addappid(2722320)
addappid(2825980)
addappid(2825990)
addappid(2826000)
addappid(2826010)
addappid(2826020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477341,0,"22d4226d21a2b7bd6a16784f1790c3905b675a00a531aaca94c7ea7f0ec706cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
