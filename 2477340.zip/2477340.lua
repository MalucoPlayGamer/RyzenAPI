-- Lua provided by RyzenAPI
-- Game: Expeditions: A MudRunner Game

-- MAIN APPLICATION
addappid(2477340)
addappid(2716240)
addappid(2716250)
addappid(2716260)
addappid(2722320)
addappid(2825980)
addappid(2825990)
addappid(2826000)
addappid(2826010)
addappid(2826020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477341,0,"22d4226d21a2b7bd6a16784f1790c3905b675a00a531aaca94c7ea7f0ec706cb")

