-- Lua provided by RyzenAPI
-- Game: 古剑奇谭二(GuJian2)

-- MAIN APPLICATION
addappid(570770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(570771, 1, "5f05d40bc27a6f64830701eba2b8ef27e88a5c673bec6b85207e9fcc2a0ecb0e")

