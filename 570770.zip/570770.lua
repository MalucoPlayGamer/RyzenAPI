-- Lua provided by RyzenAPI
-- Game: addappid(570770)

-- MAIN APPLICATION
addappid(570770)

-- MAIN APP DEPOTS / PACKAGES
addappid(570771, 1, "5f05d40bc27a6f64830701eba2b8ef27e88a5c673bec6b85207e9fcc2a0ecb0e")
