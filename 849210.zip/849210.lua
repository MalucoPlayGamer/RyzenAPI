-- Lua provided by RyzenAPI
-- Game: 849210

-- MAIN APPLICATION
addappid(849210)
-- Game: addappid(849210)

-- MAIN APP DEPOTS / PACKAGES
addappid(849211, 1, "c11d517fc644e3e488333a3e48aaad646d44721889b3fdc16c2fff8ec48cd2f3")
