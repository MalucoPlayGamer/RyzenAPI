-- Lua provided by RyzenAPI
-- Game: Dialing

-- MAIN APPLICATION
addappid(775730)

-- MAIN APP DEPOTS / PACKAGES
addappid(775731, 1, "3a2d25902bd7c7e89d0709e17fd5bf1af2b0479bb140495f804177d118507057")
