-- Lua provided by RyzenAPI
-- Game: 2430450

-- MAIN APPLICATION
addappid(2430450)
-- Game: addappid(2430450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430451, 1, "28e4604ecf0063ad6faeec88f00e495e0e2963ca3930ea3db51461585ea45d1c")
