-- Lua provided by RyzenAPI
-- Game: addappid(1795430)

-- MAIN APPLICATION
addappid(1795430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795431, 1, "9c31dc4a55bcf6107ac354100edc864011294f7bfcc283c3a9e708e5f7cc30dd")
