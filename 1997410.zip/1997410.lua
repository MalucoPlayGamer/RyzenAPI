-- Lua provided by SkyAPI 
-- Game: AppID 1997410
addappid(1997410)
addappid(1997411, 1, "48e66757e1b8e6f413ed8a2cd1ae1744d2f6d6c9eecf7eb5c2d3c18948c6b1b3")
