-- Lua provided by RyzenAPI
-- Game: Game: AppID 1029210

-- MAIN APPLICATION
addappid(1029210)
-- Game: addappid(1029210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029211, 1, "2b3982987797a16b314fec2be1ad269d546b9d168096304e5939b774f6fd3dc7")
