-- Lua provided by RyzenAPI
-- Game: Sharpshooter

-- MAIN APPLICATION
addappid(2835310)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3275900)
