-- Lua provided by RyzenAPI
-- Game: Sharpshooter

-- MAIN APPLICATION
addappid(2835310)

