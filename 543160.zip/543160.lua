-- Lua provided by RyzenAPI
-- Game: SuperMoose

-- MAIN APPLICATION
addappid(543160)
-- Game: addappid(543160)

-- MAIN APP DEPOTS / PACKAGES
addappid(543161, 1, "a8285429c8ef36c1c11629b99c230787036290534174fc0a3fc996e3e1ba82d2")
