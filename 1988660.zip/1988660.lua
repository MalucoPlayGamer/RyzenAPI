-- Lua provided by RyzenAPI
-- Game: 1988660

-- MAIN APPLICATION
addappid(1988660)
-- Game: addappid(1988660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988661, 1, "8b10182c89ccf3c2a961bc96f728131f3149bed57fe3d07ef623b3c73b28ae40")
