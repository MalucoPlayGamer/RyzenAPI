-- Lua provided by SkyAPI 
-- Game: AppID 2971340
addappid(2971340)
addappid(2971341, 1, "d137af6ee4232c3e3d52bce550e12387f19ec110cb25462e0828e86a157ac368")
