-- Lua provided by RyzenAPI
-- Game: addappid(2971340)

-- MAIN APPLICATION
addappid(2971340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2971341, 1, "d137af6ee4232c3e3d52bce550e12387f19ec110cb25462e0828e86a157ac368")
