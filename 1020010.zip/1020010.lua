-- Lua provided by RyzenAPI
-- Game: Fantasy Island

-- MAIN APPLICATION
addappid(1020010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020011, 1, "02c4842017934b2471a859baf2947039458f77d366caaf6c6b1dcd5063a55901")

