-- Lua provided by RyzenAPI
-- Game: Little machines world

-- MAIN APPLICATION
addappid(1258620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258621, 1, "6f83cf035b7fee725502d90b53fec1d49d9dc311fa3d48df1e3c41b4d48b1114")
