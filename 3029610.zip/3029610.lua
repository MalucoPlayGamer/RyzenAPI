-- Lua provided by RyzenAPI
-- Game: Dark Prison 7th

-- MAIN APPLICATION
addappid(3029610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029611, 1, "8528e0d38b3af72a9ede77929cd5ab817d7d8a04c2d0b22e532a5095e7c5974b")
