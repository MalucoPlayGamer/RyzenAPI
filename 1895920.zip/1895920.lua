-- Lua provided by RyzenAPI
-- Game: addappid(1895920)

-- MAIN APPLICATION
addappid(1895920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895921, 1, "5ae6dcade1017382e45160d252a2726bd6565de2848637337e887bd3aaa3d1c8")
