-- Lua provided by RyzenAPI
-- Game: Game: AppID 2729930

-- MAIN APPLICATION
addappid(2729930)
-- Game: addappid(2729930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729931, 1, "810c65f51dd66429c9457134bd1b2552938e29b5844be2ebd7f6a3d4adac3cfa")
