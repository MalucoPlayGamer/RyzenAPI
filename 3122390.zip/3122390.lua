-- Lua provided by RyzenAPI
-- Game: 3122390

-- MAIN APPLICATION
addappid(3122390)
-- Game: addappid(3122390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3122391, 1, "abc264fdf0c95e7be2501218392b6e6da03b1c919dfb714f346df637cd1e7045")
