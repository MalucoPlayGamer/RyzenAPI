-- Lua provided by RyzenAPI
-- Game: HarmonEy

-- MAIN APPLICATION
addappid(1544150)
addappid(4532810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544151, 1, "50978d42b00f02eca89a2dc7172e964e8129a76afb354def2019620e3247527b")
