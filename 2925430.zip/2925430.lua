-- Lua provided by RyzenAPI
-- Game: Sandwich Sim

-- MAIN APPLICATION
addappid(2925430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925431, 1, "0e35acbe2386a52b8d3d94e1261973f99b5c0cd004f661b31bf5acf9b1bc5212")
addappid(2925432, 1, "351ab0af9c5b7a71e16c3dafd4ac0afe69e7be0017655db659e30bdac6517796")

