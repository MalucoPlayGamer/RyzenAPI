-- Lua provided by RyzenAPI
-- Game: Game: Bricks Frenzy

-- MAIN APPLICATION
addappid(1384350)
-- Game: addappid(1384350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384351, 1, "b71a5651427c2827d6828c69e86749f1591d3ab4bac56c55303ce5899c7d23ff")
