-- Lua provided by SkyAPI 
-- Game: Bricks Frenzy
addappid(1384350)
addappid(1384351, 1, "b71a5651427c2827d6828c69e86749f1591d3ab4bac56c55303ce5899c7d23ff")
