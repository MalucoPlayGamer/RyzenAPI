-- Lua provided by RyzenAPI
-- Game: Game: AppID 955170

-- MAIN APPLICATION
addappid(955170)
-- Game: addappid(955170)

-- MAIN APP DEPOTS / PACKAGES
addappid(955171, 1, "0c11f073090e1a85364dcfb0fb4fb8bfeb930ce4b3259a61d723a090f3082e99")
