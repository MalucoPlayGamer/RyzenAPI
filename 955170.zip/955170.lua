-- Lua provided by RyzenAPI
-- Game: 铁道物语：陆王（Railway Saga:Land King）

-- MAIN APPLICATION
addappid(955170)
addappid(1086400)
addappid(1729500)
addappid(1729550)

-- MAIN APP DEPOTS / PACKAGES
addappid(955171,0,"0c11f073090e1a85364dcfb0fb4fb8bfeb930ce4b3259a61d723a090f3082e99")
addappid(1086931,0,"22c376472344edda762fa56eb33e4637eb5c9181537c245148b9cd93129aa04f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
