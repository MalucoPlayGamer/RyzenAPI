-- Lua provided by RyzenAPI
-- Game: 铁道物语：陆王（Railway Saga:Land King）

-- MAIN APPLICATION
addappid(955170)
addappid(1086400)
addappid(1729500)
addappid(1729550)

-- MAIN APP DEPOTS / PACKAGES
addappid(955171,0,"0c11f073090e1a85364dcfb0fb4fb8bfeb930ce4b3259a61d723a090f3082e99")
addappid(1086931,0,"22c376472344edda762fa56eb33e4637eb5c9181537c245148b9cd93129aa04f")

