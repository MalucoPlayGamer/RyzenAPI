-- Lua provided by RyzenAPI
-- Game: Libe

-- MAIN APPLICATION
addappid(1330500)
-- Game: addappid(1330500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330501, 1, "9c0b99665c3c83d189186a4a2db823774d300cf9b8e235190511c198c896a962")
