-- Lua provided by SkyAPI 
-- Game: Libe
addappid(1330500)
addappid(1330501, 1, "9c0b99665c3c83d189186a4a2db823774d300cf9b8e235190511c198c896a962")
