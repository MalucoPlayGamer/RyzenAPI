-- Lua provided by RyzenAPI
-- Game: City Bus Simulator 2024 Demo

-- MAIN APPLICATION
addappid(2981870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981871, 1, "4187b0c02960880b68237f6a2ad68cbdd66d9780d9a627a25ea8d31de3f4ffd2")
