-- Lua provided by RyzenAPI 
-- Game: Tunche
addappid(887450)
addappid(887451, 1, "6ed931b760d25f3bf963d9a5036504a7173f477e73375381d8ccdd3abf5652cf")
addappid(1789240, 0, "a4bfb810401afc245153b7f795b32de96775781aa9f371792bfd48cc36ecb046")
