-- Lua provided by RyzenAPI
-- Game: Resident Evil Re:Verse - Hunk Skin: Grim Reaper (The Mercenaries 3D)

-- MAIN APPLICATION
addappid(1607018)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607018,0,"c1234f4f8886863bf4af6714d1638827cbf51dd84086cf4d3b484e6e939d99e7")
