-- Lua provided by RyzenAPI
-- Game: Guilty Me

-- MAIN APPLICATION
addappid(2476330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476331, 1, "135281cdee96b405c33524b56c8ff63f4cf5f0a3c28f4453e3a347c67a1ae085")
