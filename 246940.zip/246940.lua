-- Lua provided by RyzenAPI
-- Game: Lords of the Black Sun

-- MAIN APPLICATION
addappid(246940)

-- MAIN APP DEPOTS / PACKAGES
addappid(246941, 1, "d3c49518670ab3264a78ba7ebbeb5a93d9da11eccb48baab3ea540f2cd8250fe")
addappid(246942, 1, "1a21d9d9a62d5ee4d9905c1c874924f903c8e1ce89894c5e0e5044d9bd77d27f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
