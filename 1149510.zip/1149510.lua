-- Lua provided by RyzenAPI
-- Game: Game: The Leopard Catgirl in Miaoli

-- MAIN APPLICATION
addappid(1149510)
-- Game: addappid(1149510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149511, 1, "a905d8c67bafe2da5cae450827e29ab8dedbf680328a25245e2ad49c709a4bbb")
addappid(1165340, 0, "bee0ea8ebe000a50f676423513946e728025b86a81c18b20cb627e3e5b36a72e")
