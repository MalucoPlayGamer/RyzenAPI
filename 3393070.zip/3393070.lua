-- Lua provided by RyzenAPI
-- Game: KAIJU NO. 8 THE GAME

-- MAIN APPLICATION
addappid(3393070)

