-- Lua provided by RyzenAPI
-- Game: 1864620

-- MAIN APPLICATION
addappid(1864620)
-- Game: addappid(1864620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864621, 1, "f1e733d0d155b3fe61a092faf1d402f04586296a9496cd37eb43a84c768cd62c")
