-- Lua provided by RyzenAPI
-- Game: Endline

-- MAIN APPLICATION
addappid(1467330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467331, 1, "f8792eab16ddb13d89641ece34462aadccd7478ac9df020edbe5d635e7d13517")
addappid(1467332, 1, "7d30e69bf7125b02dcafd9a8dede76f0c09937d94c55e1cd549d0f5e9dde1548")
addappid(1467333, 1, "ec4b7dfb0af471d4c3bce7b0c3f3776c05f611e881da7d181b559d9593be1ca4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
