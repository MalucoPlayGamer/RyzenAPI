-- Lua provided by RyzenAPI
-- Game: Coloring Game: Little City

-- MAIN APPLICATION
addappid(1141810)
addappid(1141811)
addappid(1153620)
addappid(1173750)
addappid(1173751)
addappid(1173752)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132190, 1, "b675e7ac9a5d6406ad3bcfd18cdc8e9d968aef0e664a95138ac35bda9d142e53") -- Coloring Game: Little City
addappid(1132191, 1, "e556583e6565e68ea52611ce5425becd63d902cee359aaa53a6f23cf9611def6") -- Coloring Game: The Little City Content
addappid(1132192, 1, "dedf810bf4c017d4e53ce1dc13ba95416b78b42b031a1bf685bc9d539495033b") -- Coloring Game: Little City x32
addappid(1132193, 1, "84d30d3cd6fa14a2baea6813f7a703a3bccfee8e1ac6c5817db9ea855173efc9") -- Coloring Game: Little City x64
addappid(1141810, 1, "c7a1aa7d62bcef72f6249cee558ef7810d61fa393d0828f77d922392e87d8cf1") -- Coloring Game Little City - Season Pass - Coloring Game: Little City - Season Pass (1141810)
addappid(1141811, 1, "1071ad677e150bdd46186617cda50a8a986d04f92ac1f118c694662d208e49e7") -- Coloring Game Little City - No.1 - Coloring Game: Little City - No.1 (1141811)
addappid(1153620, 1, "0b82617ff103b18de22149a609f9e8043832e594d9f105644b71b7866e6bf986") -- Coloring Game Little City - No.2 - Coloring Game: Little City - No.2 (1153620)
addappid(1173750, 1, "98369d98979842967c58d735593e909d2ad1de86757f5296533a9f2197a0f99f") -- Coloring Game Little City - No.3 - Coloring Game: Little City - No.3 (1173750)
addappid(1173751, 1, "b52ed54bad3d3d7008b7d725ff58c66a172120d1dd848618d28adaebe645f38e") -- Coloring Game Little City - No.4 - Coloring Game: Little City - No.4 (1173751)
addappid(1173752, 1, "99d4f7c24ec7943b97080bf6aecd5b18a77f80a30ea009fab4627fb2fe0ddfa8") -- Coloring Game Little City - No.5 - Coloring Game: Little City - No.5 (1173752)

