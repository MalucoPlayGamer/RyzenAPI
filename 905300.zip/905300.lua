-- Lua provided by RyzenAPI
-- Game: addappid(905300)

-- MAIN APPLICATION
addappid(905300)

-- MAIN APP DEPOTS / PACKAGES
addappid(905301, 1, "ae26ccc53adeb0252477b3df255775c1db87d31eb24134d7bc4218c1baba2eb2")
addappid(905302, 1, "e186bfd7a03c18db02364019c32b774560740f78a27eecf610e39536637ae890")
addappid(905303, 1, "bfec6a0d61f73a5ae12bb26af01a450ff61341a09ba6d7b98113aae97eb2e5fb")
