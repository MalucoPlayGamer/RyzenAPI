-- Lua provided by RyzenAPI
-- Game: The Last Golfer

-- MAIN APPLICATION
addappid(2537630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537631, 1, "ec6ce4aeacd2d7daf92d98e783252b970cd208202499531b4fc0f077bad98be2")

