-- Lua provided by RyzenAPI
-- Game: setManifestid(1980012,"6564347380718055961")

-- MAIN APPLICATION
addappid(1980010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980012,0,"0a15064eb3de9b30ac4ace5469bb80bf956df77bacf3bb8cabb1167c302ac823")

