-- Lua provided by RyzenAPI
-- Game: addappid(618360)

-- MAIN APPLICATION
addappid(618360)
addappid(622130)

-- MAIN APP DEPOTS / PACKAGES
addappid(618361, 1, "7e03c3f4f14dd49d1f8155476f621919e876b3c87136afa6cd09c71eff67abed")
addappid(618362, 1, "42b5a11fb6dff41711d7d12ecf11627ddb144d2c21a6c2efee2a7dd309f1ada8")
addappid(618363, 1, "a79b5e561d67ae3af5f25bbbaf1288b13f689f5b90d5bd5c8ec2c9b5d479995c")
