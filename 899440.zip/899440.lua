-- Lua provided by RyzenAPI
-- Game: addappid(899440)

-- MAIN APPLICATION
addappid(899440)

-- MAIN APP DEPOTS / PACKAGES
addappid(899441, 1, "30c4861a2aef30de27e7c0113630be03c94e32709f5b4be93589095f04b5b7be")
