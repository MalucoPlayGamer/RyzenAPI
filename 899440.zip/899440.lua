-- Lua provided by RyzenAPI
-- Game: AppID 899440

-- MAIN APPLICATION
addappid(899440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(899441, 1, "30c4861a2aef30de27e7c0113630be03c94e32709f5b4be93589095f04b5b7be")

