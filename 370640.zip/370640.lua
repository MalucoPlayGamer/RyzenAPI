-- Lua provided by RyzenAPI
-- Game: Midnight's Blessing

-- MAIN APPLICATION
addappid(370640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(370641, 1, "4162e22db62f4804443c1b6e17699986bf4dfcddfb0ec11d7809cc68aa70dd69")
addappid(371110, 0, "e6ecc1786f10b276d859bba5d62d3ef48856fa717fb44a871a2157918a80ac31")

