-- Lua provided by RyzenAPI
-- Game: Game: Mining And Achievements 挖矿与成就

-- MAIN APPLICATION
addappid(3083900)
-- Game: addappid(3083900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3083901, 1, "15e9b8802e74f4470eaac95b11d0ae530300e74b138cc47db9b21c0443dd3428")
