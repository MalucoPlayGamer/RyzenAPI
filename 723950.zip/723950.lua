-- Lua provided by RyzenAPI
-- Game: 723950

-- MAIN APPLICATION
addappid(723950)
-- Game: addappid(723950)

-- MAIN APP DEPOTS / PACKAGES
addappid(723951, 1, "0f96175786c72db064877d2c42623c98eeca474d3e716d09ff1f9116a20e9409")
