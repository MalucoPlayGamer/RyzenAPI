-- Lua provided by RyzenAPI
-- Game: Spirits of Mystery: The Dark Minotaur Collector's Edition

-- MAIN APPLICATION
addappid(709340)
-- Game: addappid(709340)

-- MAIN APP DEPOTS / PACKAGES
addappid(709341, 1, "17007c378162565be62ddf268b1f8cc408bdc8871aea446781a68e375e863aae")
