-- Lua provided by RyzenAPI
-- Game: Quantum Tripper

-- MAIN APPLICATION
addappid(1965970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965971, 1, "d9cc56a3de485ca2444f94512aefd5d518767eef325bf6f47f648d865c2b2c98")
addappid(1965972, 1, "19e339821658db125cc1240a9d5a647292cd07846a5719d69d92f36e56f9b011")
addappid(1965973, 1, "b42f2aff6162f3a2a011ee881356a4f9c0b7b5064871dae4e562361011b35aa2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2554830)
addappid(2839490)
addappid(3164580)
