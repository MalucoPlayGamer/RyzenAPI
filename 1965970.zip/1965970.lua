-- Lua provided by RyzenAPI
-- Game: Quantum Tripper

-- MAIN APPLICATION
addappid(1965970) -- Quantum Tripper
addappid(1971840) -- Quantum Tripper - Nanofest
addappid(1971841) -- Quantum Tripper - Electrocrucify
addappid(1971842) -- Quantum Tripper - Trip City
addappid(1971843) -- Quantum Tripper - New Number
addappid(2166110) -- Quantum Tripper - Voyager
addappid(2166111) -- Quantum Tripper - Wetwash
addappid(2554830) -- Quantum Tripper - Math
addappid(2839490) -- Quantum Tripper - Max
addappid(3164580) -- Quantum Tripper - Mode

-- MAIN APP DEPOTS / PACKAGES
addappid(1965971, 1, "d9cc56a3de485ca2444f94512aefd5d518767eef325bf6f47f648d865c2b2c98") -- Depot 1965971
addappid(1965972, 1, "19e339821658db125cc1240a9d5a647292cd07846a5719d69d92f36e56f9b011") -- Depot 1965972
addappid(1965973, 1, "b42f2aff6162f3a2a011ee881356a4f9c0b7b5064871dae4e562361011b35aa2") -- Depot 1965973
