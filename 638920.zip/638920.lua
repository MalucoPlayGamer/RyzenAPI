-- Lua provided by RyzenAPI
-- Game: 638920

-- MAIN APPLICATION
addappid(638920)
-- Game: addappid(638920)

-- MAIN APP DEPOTS / PACKAGES
addappid(638921, 1, "c7a1571a6a5c43550b0fc0141430dd5e229f84bd07ef163484ab0f67e82e107f")
