-- Lua provided by RyzenAPI
-- Game: addappid(652990)

-- MAIN APPLICATION
addappid(652990)

-- MAIN APP DEPOTS / PACKAGES
addappid(652991, 1, "b0e3065f21cbc2b5f89767e5185d1fc8046cc644735eec9747f925fb0087e83b")
