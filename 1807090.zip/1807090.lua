-- Lua provided by RyzenAPI
-- Game: addappid(1807090)

-- MAIN APPLICATION
addappid(1807090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807091, 1, "16f2c0142601c223a06eb88eea94103dd6c4ac4dec5552cf5b00388851cb4689")
