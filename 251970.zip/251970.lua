-- Lua provided by SkyAPI 
-- Game: AppID 251970
addappid(251970)
addappid(251971, 1, "0f2934ad8ad462db28957fe7fbf1f934ba23af58d6c7e607bdbff7bb4ee38855")
