-- Lua provided by RyzenAPI
-- Game: Sins of a Dark Age

-- MAIN APPLICATION
addappid(251970)
addappid(270900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(251971, 1, "0f2934ad8ad462db28957fe7fbf1f934ba23af58d6c7e607bdbff7bb4ee38855")
