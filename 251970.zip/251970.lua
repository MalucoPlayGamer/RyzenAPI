-- Lua provided by RyzenAPI
-- Game: AppID 251970

-- MAIN APPLICATION
addappid(251970)

-- MAIN APP DEPOTS / PACKAGES
addappid(251971, 1, "0f2934ad8ad462db28957fe7fbf1f934ba23af58d6c7e607bdbff7bb4ee38855")
