-- Lua provided by RyzenAPI
-- Game: 最后四人-The last four

-- MAIN APPLICATION
addappid(2116840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116841, 1, "b81ccc90b631c1e781d9f2fc720756c44635c4e3e239957c63b97b959f4d4271")
