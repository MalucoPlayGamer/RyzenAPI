-- Lua provided by RyzenAPI 
-- Game: COMPOUND
addappid(615120)
addappid(615121, 1, "08e16ef93efa68d8ffed546f07d905c2e575a7f2480b9e2d56e2a7f29e9ce3e2")
