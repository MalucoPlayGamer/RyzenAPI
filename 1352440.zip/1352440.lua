-- Lua provided by RyzenAPI
-- Game: addappid(1352440)

-- MAIN APPLICATION
addappid(1352440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352441, 1, "c455c05e071c509698a1b624d3c3b8d639b98f05242efd736e7ac4e41504a13b")
addappid(1352442, 1, "9d6f7543e04e0df0b486398cf9e3da95ff84d3c920e3ff902ebb3f7ef0ec2cb2")
