-- Lua provided by RyzenAPI
-- Game: Brick Building

-- MAIN APPLICATION
addappid(1352440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352441, 1, "c455c05e071c509698a1b624d3c3b8d639b98f05242efd736e7ac4e41504a13b")
addappid(1352442, 1, "9d6f7543e04e0df0b486398cf9e3da95ff84d3c920e3ff902ebb3f7ef0ec2cb2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
