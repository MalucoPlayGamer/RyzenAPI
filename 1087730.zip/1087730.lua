-- Lua provided by RyzenAPI
-- Game: Iron Blade: Medieval RPG

-- MAIN APPLICATION
addappid(1087730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1087731, 1, "371a4f23d3a6a5330343403875db83de36cd3db0cd4354a9c32b2d1a19bcb7f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
