-- Lua provided by RyzenAPI
-- Game: Aim Master H

-- MAIN APPLICATION
addappid(1303820)
addappid(1360680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303821, 1, "b2c36b098ba74667e3dffc1d3c61c2f389e2dd312544cc7e84d3352d6b09ea19")

