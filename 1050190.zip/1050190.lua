-- Lua provided by SkyAPI 
-- Game: AppID 1050190
addappid(1050190)
addappid(1050191, 1, "10e3dd4e22a0aa59f8074bb8a9f4bc59ba77bb719ccf1757950b0edbd17f29a7")
