-- Lua provided by RyzenAPI
-- Game: Hoco Poco

-- MAIN APPLICATION
addappid(1135110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1135111, 1, "b0b052505eb3c82a17b042da96d01618dd87b77b5598da2aabfbcf4fc5828b7c")

