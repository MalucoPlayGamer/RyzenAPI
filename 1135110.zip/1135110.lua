-- Lua provided by RyzenAPI
-- Game: Hoco Poco

-- MAIN APPLICATION
addappid(1135110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135111, 1, "b0b052505eb3c82a17b042da96d01618dd87b77b5598da2aabfbcf4fc5828b7c")

