-- Lua provided by RyzenAPI
-- Game: AppID 1216540

-- MAIN APPLICATION
addappid(1216540)
-- Game: addappid(1216540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216541, 1, "829e2b3490ffec9c8d94fc8aa3d9e3e1700a0b345aa57d10945dfd6608883093")
