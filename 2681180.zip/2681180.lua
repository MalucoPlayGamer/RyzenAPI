-- Lua provided by RyzenAPI
-- Game: MULTIPLAYER CAVEMEN

-- MAIN APPLICATION
addappid(2681180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2681181, 1, "f102ecd9c097fcd503272fb3dc5ac5bcb96647d1908d4b0681d3a22c049fb352")

