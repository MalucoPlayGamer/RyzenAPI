-- Lua provided by RyzenAPI
-- Game: 2681180

-- MAIN APPLICATION
addappid(2681180)
-- Game: addappid(2681180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681181, 1, "f102ecd9c097fcd503272fb3dc5ac5bcb96647d1908d4b0681d3a22c049fb352")
