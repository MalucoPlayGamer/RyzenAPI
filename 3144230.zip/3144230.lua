-- Lua provided by RyzenAPI
-- Game: Modern Warships

-- MAIN APPLICATION
addappid(3144230)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4584640)
addappid(4584650)
addappid(4584660)
addappid(4584670)
addappid(4584680)
addappid(4584690)
