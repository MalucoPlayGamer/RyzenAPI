-- Lua provided by RyzenAPI
-- Game: Modern Warships

-- MAIN APPLICATION
addappid(3144230)

