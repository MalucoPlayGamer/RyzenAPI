-- Lua provided by RyzenAPI
-- Game: Cyber Girl - Zombie Hentai 💀💖

-- MAIN APP DEPOTS / PACKAGES
addappid(2195340, 1, "fb1368d4d917a8bd5ec0e10c717038973c1071e9ae83408d0fabf40e9f947f7c")
addappid(2195341, 1, "595c50f125b390e55a70dd365e51d158a277ce87dbe8f78694e7d6b1b114dee6") -- (windows)
