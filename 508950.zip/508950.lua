-- Lua provided by RyzenAPI
-- Game: Beerman

-- MAIN APPLICATION
addappid(508950)

-- MAIN APP DEPOTS / PACKAGES
addappid(508951, 1, "ed4c48ac608a92b0bc19acdeb21bb4236793058896a67cc4fb333db379ae728d")
