-- Lua provided by RyzenAPI
-- Game: 灵梦的激急击鸡祭 Reimu's Fighting Chicken Festival

-- MAIN APPLICATION
addappid(2871480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871481, 1, "5c0592c34bb926dd7f9bac1534850154c59b7ae82c524f39058145f734a61273")

