-- Lua provided by RyzenAPI
-- Game: Game: Monster 2

-- MAIN APPLICATION
addappid(2575840)
-- Game: addappid(2575840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2575841, 1, "b49c98caed7a7e6815c73079bcc30320118e8c097a28d07b4b316422abad247a")
