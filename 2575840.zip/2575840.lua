-- Lua provided by SkyAPI 
-- Game: Monster 2
addappid(2575840)
addappid(2575841, 1, "b49c98caed7a7e6815c73079bcc30320118e8c097a28d07b4b316422abad247a")
