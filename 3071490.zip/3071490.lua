-- Lua provided by RyzenAPI
-- Game: PoetryAdventure

-- MAIN APPLICATION
addappid(3071490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071491, 1, "853cd0140acec613b8c042ea5eaf35d6cb4745a80575513f45060f1d357ecb32")
