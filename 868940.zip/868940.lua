-- Lua provided by RyzenAPI
-- Game: The Curious Study of Dr. Blackwood:  A VR Tech Demo

-- MAIN APPLICATION
addappid(868940)

-- MAIN APP DEPOTS / PACKAGES
addappid(868941, 1, "28f957036373c2f80d09fa8fc3d4a8331900faa68eb5d1c5e4e54d9f3427c664")

