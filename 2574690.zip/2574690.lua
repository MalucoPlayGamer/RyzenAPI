-- Lua provided by RyzenAPI
-- Game: Game: Clarent Saga: Prologue

-- MAIN APPLICATION
addappid(2574690)
-- Game: addappid(2574690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574691, 1, "3746b1c06e6b4638b95221ebb1e7d9f5f1144ec928aa0822af23087079e32fd8")
