-- Lua provided by RyzenAPI
-- Game: addappid(587490)

-- MAIN APPLICATION
addappid(587490)

-- MAIN APP DEPOTS / PACKAGES
addappid(587491, 1, "81b531d6e4a96f3948a474d9a61497230798f57cb2ebb4adee88269cc2347e83")
