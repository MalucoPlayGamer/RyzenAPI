-- Lua provided by RyzenAPI
-- Game: 古剑奇闻录

-- MAIN APPLICATION
addappid(2324020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324021, 1, "7f6f71db6d19f9d10d4ec898d307201e62a792328a2b9f0982acb712b6fb4950")
