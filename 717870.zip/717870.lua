-- Lua provided by RyzenAPI
-- Game: An Adventurer's Gallantry

-- MAIN APPLICATION
addappid(717870)
-- Game: addappid(717870)

-- MAIN APP DEPOTS / PACKAGES
addappid(717872,0,"5b58f91a22c1e472fc011afa8eb514ed8827406fcc29609a0d56f53c6b0fa4f6")
addappid(717873,0,"42e6db24a60c66e1dcc01b6b61cc0f89603ac1d90cbfdb9c5d5a4de51f1984f3")
addappid(717874,0,"540898d141ce8046f6eab91baa93f0535d57cafa787419bd2c86a25d7cff1bf1")
addappid(717875,0,"883519da6abadbf93d2a9740102aa798a10b21e88574a82a175236022420501b")
addappid(717876,0,"1c8619d7816a93c0e2141c8af22b295a7d54a15d5fe962a4d0cac43ac4b7c02a")
