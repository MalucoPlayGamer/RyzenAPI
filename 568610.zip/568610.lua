-- Lua provided by RyzenAPI
-- Game: VERSUS: The Elite Trials

-- MAIN APPLICATION
addappid(568610)
addappid(568630)

-- MAIN APP DEPOTS / PACKAGES
addappid(568611, 1, "9477c7afa8783257ed2cd1b0df32a739f763a5de576a1efef65c10db5186d807")

