-- Lua provided by RyzenAPI
-- Game: Idle Skilling

-- MAIN APPLICATION
addappid(1048370)

