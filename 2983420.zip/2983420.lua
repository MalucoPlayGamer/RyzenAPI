-- Lua provided by RyzenAPI 
-- Game: Kinetic Anatomy 3D Demo
addappid(2983420)
addappid(2983421, 1, "e1821731babbbf79634c2ec2170c595b282d3cefd13fd93258131cf38d8dab41")
