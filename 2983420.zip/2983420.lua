-- Lua provided by RyzenAPI
-- Game: Game: Kinetic Anatomy 3D Demo

-- MAIN APPLICATION
addappid(2983420)
-- Game: addappid(2983420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983421, 1, "e1821731babbbf79634c2ec2170c595b282d3cefd13fd93258131cf38d8dab41")
