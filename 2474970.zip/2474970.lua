-- Lua provided by RyzenAPI
-- Game: 2474970

-- MAIN APPLICATION
addappid(2474970)
-- Game: addappid(2474970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474971, 1, "dd09af7c9f4d3c7c8d0e111d261318884ccf8a0496c7881417e22ac0740f7a2f")
