-- Lua provided by RyzenAPI
-- Game: Data mining 4

-- MAIN APPLICATION
addappid(993630)

-- MAIN APP DEPOTS / PACKAGES
addappid(993631, 1, "60bbbaa1ed5c369bc41330a51a02f7feb12be8267a013ad5c6eb5652cf06db5a")

