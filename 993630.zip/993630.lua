-- Lua provided by RyzenAPI 
-- Game: AppID 993630
addappid(993630)
addappid(993631, 1, "60bbbaa1ed5c369bc41330a51a02f7feb12be8267a013ad5c6eb5652cf06db5a")
