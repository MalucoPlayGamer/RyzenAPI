-- Lua provided by RyzenAPI
-- Game: Game: AppID 302160

-- MAIN APPLICATION
addappid(302160)
-- Game: addappid(302160)

-- MAIN APP DEPOTS / PACKAGES
addappid(302161, 1, "2a78f91c4da28fef65051dc043bf83d5cec64bf1f47b6eb1fd96f7f6e477c244")
addappid(302162, 1, "4b7cd698c62d4373936a496c04683c96924dbca3effbf9331ad595015aded7e5")
addappid(302163, 1, "b1ec77cca0c74a4240c6bcd014b47e88e843e2f6c4bc943a0ac5f4b6cafa4759")
addappid(302164, 1, "c55d10fad9be45a61bebda405f83ba764703c062327aa32963b7748350ef8bcb")
addappid(302165, 1, "84a550a46c61a052b72d2bd891fe789122d84aee25befa70cadcfd2365cab148")
addappid(302166, 1, "d5f0d12c35fd430a6999854d138ff40a401e142fccbb587f498f1ae9a749f9e5")
