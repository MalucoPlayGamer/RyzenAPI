-- Lua provided by RyzenAPI
-- Game: Melatonin

-- MAIN APPLICATION
addappid(1585220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585221, 1, "5ba9eb8215a9db5783ac81a4fc0d411d12c6b762266cb31023d3366dc14b92e3")
addappid(1585222, 1, "3c507e02fdd85927c760794d45338a77b41e6170c42b2b42b4a638fdcbf5cfe3")

