-- Lua provided by RyzenAPI
-- Game: Paradise Trails

-- MAIN APPLICATION
addappid(1746650)
-- Game: addappid(1746650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746651, 1, "57e5da46748bd62d2047612905298c6c9ccdb8c9253dcaea3369dd325a117ff4")
