-- Lua provided by RyzenAPI
-- Game: Patchouli's Adventure In Doll's House

-- MAIN APPLICATION
addappid(2299750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299752,0,"f5424fbfe224da6e04d6720f6c4cc47976229ecb785a6d306662ff078a660038")
addappid(2299754,0,"58a075e7e54ce9be7cc7167242b2fae98ca15ae3d8d28f26aea48579ba0914e4")

