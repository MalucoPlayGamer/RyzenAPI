-- Lua provided by RyzenAPI
-- Game: Game: AppID 553490

-- MAIN APPLICATION
addappid(553490)
-- Game: addappid(553490)

-- MAIN APP DEPOTS / PACKAGES
addappid(553491, 1, "22997e9ac426cd9cc17c89eb99f68f2f8c5d0601e3d3a214c58d358a34d04ef1")
