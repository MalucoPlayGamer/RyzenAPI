-- Lua provided by RyzenAPI 
-- Game: AppID 553490
addappid(553490)
addappid(553491, 1, "22997e9ac426cd9cc17c89eb99f68f2f8c5d0601e3d3a214c58d358a34d04ef1")
