-- Lua provided by RyzenAPI
-- Game: Final Hours of Tomb Raider

-- MAIN APPLICATION
addappid(233410)

-- MAIN APP DEPOTS / PACKAGES
addappid(233411, 1, "ec78d77ff11af08e2caccaea27ba9ec1b677d74062cad201496be0784de9ceb2")
addappid(233412, 1, "b859ae40c7547205f1d76226df37ba517f7c01936e340aeee387b23cc3cf0ae5")
