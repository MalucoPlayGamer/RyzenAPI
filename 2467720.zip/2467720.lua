-- Lua provided by RyzenAPI
-- Game: Block, Love, and Ancient Greece

-- MAIN APPLICATION
addappid(2467720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467721, 1, "f5927241fa8b2bce06109e8e558217675b735f8d0ebc3cb3226869889239ed94")
addappid(2467722, 1, "f04e2c879daaecb263e6a02c93352e5f19e8dc0ed7947fbbf1a1bc8d338d54ac")

