-- Lua provided by RyzenAPI
-- Game: Evil Orbs

-- MAIN APPLICATION
addappid(528420)
-- Game: addappid(528420)

-- MAIN APP DEPOTS / PACKAGES
addappid(528421, 1, "a24056a1a82bdacde2cf84961ab504fa8d88dc10f7cd33cb539afa37a5935106")
