-- Lua provided by RyzenAPI
-- Game: 2871590

-- MAIN APPLICATION
addappid(2871590)
-- Game: addappid(2871590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871591, 1, "6888ec854ee55074ebee492129a97ef3e8b5d2c36aa3b28fb86f3a3177c08961")
