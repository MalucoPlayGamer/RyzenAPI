-- Lua provided by RyzenAPI
-- Game: AppID 1217550

-- MAIN APPLICATION
addappid(1217550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217551, 1, "3d7e902c4371ff86516ced24cb590f3f944c4fdf004f384115004a0793c0629b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1424210)
addappid(1424211)
addappid(1424212)
addappid(1424213)
addappid(1424214)
addappid(1424215)
addappid(1424216)
addappid(1565410)
addappid(1565411)
addappid(1565412)
addappid(1565413)
addappid(1565414)
addappid(1565415)
addappid(1565416)
addappid(1565600)
addappid(1565601)
addappid(1565602)
addappid(1602070)
