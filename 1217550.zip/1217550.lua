-- Lua provided by RyzenAPI
-- Game: Game: AppID 1217550

-- MAIN APPLICATION
addappid(1217550)
-- Game: addappid(1217550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217551, 1, "3d7e902c4371ff86516ced24cb590f3f944c4fdf004f384115004a0793c0629b")
