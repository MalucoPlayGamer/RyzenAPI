-- Lua provided by RyzenAPI
-- Game: City of Broken Dreamers: Book One

-- MAIN APPLICATION
addappid(1358250)
-- Game: addappid(1358250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358251, 1, "2c4814db747d2278c49ba72c2001bb39a857bc26f980d9d54b3f31c027e7cc48")
addappid(1358252, 1, "9bd6786218cc737af10384d4404418c59dbee8450b0f820b38cd33c01ecf67ae")
addappid(1385850, 0, "b693ffdfe811030a735b70b587601ce26758aab13cfa40e674c08b117474bbbe")
addappid(3169990, 1, "5a6c1d1472aed2af663041e89fe0b461cc1358c503a0a65aad1554885234c4c8")
