-- Lua provided by RyzenAPI
-- Game: AppID 2781100

-- MAIN APPLICATION
addappid(2781100)
-- Game: addappid(2781100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2781101, 1, "2f96a147a248f233cefcd2c38fdb008e8833a0f876f308fdb26c925b7ffa1520")
