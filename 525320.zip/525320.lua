-- Lua provided by RyzenAPI
-- Game: 525320

-- MAIN APPLICATION
addappid(525320)
-- Game: addappid(525320)

-- MAIN APP DEPOTS / PACKAGES
addappid(525321, 1, "807e656d2af035e6ed7df274d8432210090cde06d93fb7ee3d32506c256a9e4f")
