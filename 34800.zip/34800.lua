-- Lua provided by SkyAPI 
-- Game: Chronicles of Mystery: The Scorpio Ritual
addappid(34800)
addappid(34801, 1, "33a367f29bcf1d39f0b6233fc74087534f432b250aadd9d934d7bc38a1c4d91e")
