-- Lua provided by RyzenAPI
-- Game: Chronicles of Mystery: The Scorpio Ritual

-- MAIN APPLICATION
addappid(34800)

-- MAIN APP DEPOTS / PACKAGES
addappid(34801, 1, "33a367f29bcf1d39f0b6233fc74087534f432b250aadd9d934d7bc38a1c4d91e")
