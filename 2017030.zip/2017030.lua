-- Lua provided by RyzenAPI
-- Game: 梦江湖音乐原声带

-- MAIN APPLICATION
addappid(2017030)
-- Game: addappid(2017030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017033,0,"1f4eec067e6b9821f3e1b95bb98d9ec58729a6568c436ec3d3ff4413156674b6")
addappid(2017034,0,"e6d85ae0259471aa7b945c80ea0816cc86446de953705124e7b6952cab1c72a7")
