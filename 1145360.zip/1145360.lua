-- Lua provided by RyzenAPI
-- Game: Hades

-- MAIN APPLICATION
addappid(1145360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1145361, 1, "e7db1a4f43363b9d751ed9e888334353425704ea0db26c8434015e516a482f4d")
addappid(1145363, 1, "b88219eb2aee190d115e532ef9feea08c69bbc53bb1f959a2c48f3739f871b31")
addappid(1145364, 1, "c70c6707a01507e124d35ac0e1644ee6210f383a1ae759aa252478cbd1ca7e0e")

