-- Lua provided by RyzenAPI
-- Game: Turbo Dismount™

-- MAIN APPLICATION
addappid(263760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(263761, 1, "8cc9b0f0af9878476d97c7c7e5c62d5af9ef79e3dd41cace2d398b970ddbb617")
addappid(263762, 1, "0674b66e044834d678dc96e98080efd05d6e55f19ffb75db0a0590dcae0e4368")

