-- Lua provided by RyzenAPI
-- Game: Game: Real Dive World

-- MAIN APPLICATION
addappid(2337090)
-- Game: addappid(2337090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337091, 1, "ffb0ad0231fbb8858705e7408218662ad87751b32d04fbcd91ce83277a398cec")
addappid(2337092, 1, "a60742e9aa9d0c22e9a41d56f1e0090309a7f62311bdc4d163b839669dd0ac59")
addappid(2337093, 1, "4b130638e381c0a0342fa3010bc13aa118812e519b01e4c03495ad4c045eba4b")
