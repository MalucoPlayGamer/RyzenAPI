-- Lua provided by RyzenAPI 
-- Game: Atomic Reconstruction
addappid(568500)
addappid(568501, 1, "ddec9a0992445553263356a1fe7cf744771c8d43126147c9e79f7f557db559ef")
addappid(568503, 1, "92c2c1f21106a04acb81097722b34db8ea90e847d1502578a3ee735b71f28283")
