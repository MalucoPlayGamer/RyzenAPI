-- Lua provided by RyzenAPI
-- Game: The girl in the clouds

-- MAIN APPLICATION
addappid(3825650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3825651, 1, "c51cbfd002da9f5dac0ef7c885b78192203278e6f4c58224dcfa9c36fe9d3587")

