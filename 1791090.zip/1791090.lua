-- Lua provided by RyzenAPI
-- Game: Timmy the Tiger's Big Adventure

-- MAIN APPLICATION
addappid(1791090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791091, 1, "5eaef1c7c9926500c82ed3f588fca921a685940aad63a90cc06f02492f303cc7")

