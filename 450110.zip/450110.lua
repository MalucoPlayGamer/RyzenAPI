-- Lua provided by RyzenAPI
-- Game: Game: AppID 450110

-- MAIN APPLICATION
addappid(450110)
-- Game: addappid(450110)

-- MAIN APP DEPOTS / PACKAGES
addappid(450111, 1, "4c3ad7535677a54b3bcb0d973e37fb4ad8406af25485d2fcb918c6d7286c0213")
