-- Lua provided by RyzenAPI
-- Game: Game: Backrooms Society

-- MAIN APPLICATION
addappid(2304620)
-- Game: addappid(2304620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304621, 1, "836b3c270ab84e955887426bd9602f72d42ef387c70d68997760c3bbdbae8a0a")
