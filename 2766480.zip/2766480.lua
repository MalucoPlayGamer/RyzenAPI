-- Lua provided by RyzenAPI
-- Game: AppID 2766480

-- MAIN APPLICATION
addappid(2766480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766481, 1, "380fd6d921c93824e593acf55f81e7aa6144a4b8ed0c55f8295097c7df589ef8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
