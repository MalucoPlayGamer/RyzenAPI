-- Lua provided by RyzenAPI
-- Game: addappid(2766480)

-- MAIN APPLICATION
addappid(2766480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766481, 1, "380fd6d921c93824e593acf55f81e7aa6144a4b8ed0c55f8295097c7df589ef8")
