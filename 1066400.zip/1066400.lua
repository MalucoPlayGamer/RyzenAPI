-- Lua provided by RyzenAPI
-- Game: AppID 1066400

-- MAIN APPLICATION
addappid(1066400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066401, 1, "efbd92e7f19e13ddf30445d374fccd1045b7ac53df21fc46f40cf33f1996428b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
