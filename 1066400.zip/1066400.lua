-- Lua provided by RyzenAPI
-- Game: AppID 1066400

-- MAIN APPLICATION
addappid(1066400)
-- Game: addappid(1066400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066401, 1, "efbd92e7f19e13ddf30445d374fccd1045b7ac53df21fc46f40cf33f1996428b")
