-- Lua provided by RyzenAPI
-- Game: West of Red

-- MAIN APPLICATION
addappid(709870)
-- Game: addappid(709870)

-- MAIN APP DEPOTS / PACKAGES
addappid(709871, 1, "2da2a01f2467b93433be090e41f2fbee0b22d7e1ec4c8bb117b852e0ed8dc4d6")
addappid(709872, 1, "24bfb10d253f26a49edfcef485dd1610a60c20ae4e488809c214b6d096905093")
addappid(709873, 1, "ca474e0900e82269650f7f4e7ce0f78f6319a37eced212289b389cfb6416a709")
addappid(709874, 1, "eb003213f3b38320b078967dd965cd38ef9203235bb2f858748cc36b8c1c1afe")
