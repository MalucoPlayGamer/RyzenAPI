-- Lua provided by RyzenAPI
-- Game: addappid(412010)

-- MAIN APPLICATION
addappid(412010)

-- MAIN APP DEPOTS / PACKAGES
addappid(412011, 1, "677c4b5f58a4ef21e6f29e6b290688803bfd601f82af81d3175a0e2c953be02f")
