-- Lua provided by RyzenAPI
-- Game: Hidden Animals: Photo Hunt - Worldwide Safari

-- MAIN APPLICATION
addappid(922700)
-- Game: addappid(922700)

-- MAIN APP DEPOTS / PACKAGES
addappid(922701, 1, "87fbfa44d9c7f519ab34b86c9789913cfae1d83fc0f42ace4279a7bf80e9f945")
