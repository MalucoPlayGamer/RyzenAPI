-- Lua provided by SkyAPI 
-- Game: AppID 792810
addappid(792810)
addappid(792811, 1, "646211adc0e2e4aca51d3e7dd77032c1efb7f00bae7aca7b34841e7c39bd4038")
