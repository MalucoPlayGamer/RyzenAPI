-- Lua provided by RyzenAPI
-- Game: addappid(792810)

-- MAIN APPLICATION
addappid(792810)

-- MAIN APP DEPOTS / PACKAGES
addappid(792811, 1, "646211adc0e2e4aca51d3e7dd77032c1efb7f00bae7aca7b34841e7c39bd4038")
