-- Lua provided by RyzenAPI
-- Game: Game: Crash Bandicoot™ 4: It’s About Time

-- MAIN APPLICATION
addappid(1378990)
-- Game: addappid(1378990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378991, 1, "f50ac282f4e8cd6aa1b2477faf75a2d4ac2257737e16ccc8c08533eed66df9c9")
addappid(1378992, 1, "0472c66839b11731f139af60a48c4d4295051038aa705924072f4f5931162592")
