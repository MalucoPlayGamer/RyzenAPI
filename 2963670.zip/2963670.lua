-- Lua provided by RyzenAPI
-- Game: Check Inn Demo

-- MAIN APPLICATION
addappid(2963670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963671, 1, "4ce58314b69234c24b965c64aa1e97a395a5874403af0509dbc2dc58940e391e")
