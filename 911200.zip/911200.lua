-- Lua provided by RyzenAPI
-- Game: AppID 911200

-- MAIN APPLICATION
addappid(911200)
-- Game: addappid(911200)

-- MAIN APP DEPOTS / PACKAGES
addappid(911201, 1, "7248089b4f2aa968a34a8d0c719d45b9745d0ce07b93db1961397c72760b101b")
