-- Lua provided by RyzenAPI
-- Game: Cats Catching Mice: The Black and White World

-- MAIN APPLICATION
addappid(3319150)
-- Game: addappid(3319150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319151, 1, "94de30687b186655358894921ce2d5b9e3bc8e4dc2047acdc18fb1a8f011c011")
addappid(3319153, 1, "cd6021152f061f3c5e1b5e482b2c6df98d53ae2f9cdd10736b6f5d485e38e05e")
