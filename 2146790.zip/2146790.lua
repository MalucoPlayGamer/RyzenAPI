-- Lua provided by RyzenAPI
-- Game: Passed Out: Prologue

-- MAIN APPLICATION
addappid(2146790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2146791, 1, "7c20296969f132a232fbf167e97f5c00bfbb5c3401f5cf3f921a02446d138091")

