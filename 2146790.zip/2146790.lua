-- Lua provided by RyzenAPI
-- Game: Passed Out: Prologue

-- MAIN APPLICATION
addappid(2146790)
-- Game: addappid(2146790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146791, 1, "7c20296969f132a232fbf167e97f5c00bfbb5c3401f5cf3f921a02446d138091")
