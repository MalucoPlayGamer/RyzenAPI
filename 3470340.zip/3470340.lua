-- Lua provided by SkyAPI 
-- Game: RogueCraft
addappid(3470340)
addappid(3470341, 1, "21e4d7f1e9430b34156c9fabf65798ddb74a9ec0f833678903918351873ebb3b")
