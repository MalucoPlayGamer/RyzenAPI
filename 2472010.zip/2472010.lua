-- Lua provided by RyzenAPI
-- Game: AppID 2472010

-- MAIN APPLICATION
addappid(2472010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472011, 1, "a0dcab69ac198aadce7faab91f01cbe87c43fee439ee3a060cd60fbac11b2547")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3702340)
