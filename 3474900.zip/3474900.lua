-- Lua provided by RyzenAPI
-- Game: Game: Anima Engine

-- MAIN APPLICATION
addappid(3474900)
-- Game: addappid(3474900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3474901, 1, "fbc9891a1c20a2a57931cc7ac38cec562cf9fb996f284e99863b13fb98f140d8")
