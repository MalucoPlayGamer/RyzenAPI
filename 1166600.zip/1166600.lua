-- Lua provided by RyzenAPI
-- Game: The Fog Knows Your Name

-- MAIN APPLICATION
addappid(1166600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166601, 1, "57259e27371eeb1ab7f7499017876553a28ba1b5f5fcef67dcd7b30d4ea8559c")
