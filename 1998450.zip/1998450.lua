-- Lua provided by SkyAPI 
-- Game: AppID 1998450
addappid(1998450)
addappid(1998451, 1, "099823601580b64b8673ebfabe89d86cdff8e4e3940d2ec1cce71619f95d6560")
