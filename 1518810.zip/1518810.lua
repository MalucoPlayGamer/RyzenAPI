-- Lua provided by RyzenAPI
-- Game: Game: Koi Farm

-- MAIN APPLICATION
addappid(1518810)
-- Game: addappid(1518810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518811, 1, "e98c51085fd53e20c763f8600cd14f251a51b2fa35a36f6d4981284ef2bff056")
addappid(1518812, 1, "840b1c59cb3827a4aac386c36fca6e7ed58b14de8d51380977c4817eab191ad0")
addappid(1518813, 1, "714310bf64ca872c9dee291f5d2e77cf91566f85405bf6e5105a34cc03a2a597")
