-- Lua provided by RyzenAPI
-- Game: Wheel World

-- MAIN APPLICATION
addappid(1497460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497461, 1, "1f50d4a90043eb3cb4bb778e342da07291d225d1b2f388fb30d58462e98f8cce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
