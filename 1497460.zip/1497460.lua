-- Lua provided by RyzenAPI 
-- Game: Wheel World
addappid(1497460)
addappid(1497461, 1, "1f50d4a90043eb3cb4bb778e342da07291d225d1b2f388fb30d58462e98f8cce")
