-- Lua provided by RyzenAPI
-- Game: 3223600

-- MAIN APPLICATION
addappid(3223600)
-- Game: addappid(3223600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3223601, 1, "ca93edff4861a5f241841b4cafb7b063e19af23255730eea3c7ba1b6e6c66aab")
