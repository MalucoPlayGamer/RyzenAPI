-- Lua provided by RyzenAPI
-- Game: Game: Clossure

-- MAIN APPLICATION
addappid(2851710)
-- Game: addappid(2851710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2851711, 1, "6449f57d3bb77e0d339e39a0dc3ee4b013b7d1bfd3f2323accce00b70fcb8281")
