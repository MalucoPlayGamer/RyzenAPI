-- Lua provided by RyzenAPI
-- Game: 2628620

-- MAIN APPLICATION
addappid(2628620)
-- Game: addappid(2628620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628621, 1, "52b09d2265a7b347edc3086387fcb330431400dcffd88b463a63758fa529f0bf")
