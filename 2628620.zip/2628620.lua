-- Lua provided by RyzenAPI
-- Game: Game: 人类动物园插画集 Human Zoo Illustrations

-- MAIN APPLICATION
addappid(2628620)
-- Game: addappid(2628620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628621, 1, "52b09d2265a7b347edc3086387fcb330431400dcffd88b463a63758fa529f0bf")
