-- Lua provided by RyzenAPI
-- Game: addappid(1222920)

-- MAIN APPLICATION
addappid(1222920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222921, 1, "1408c9ed84ddce8a6fcc9e4bd3317f0ea102e0c68d333cf2aae65c4f81ca90c1")
