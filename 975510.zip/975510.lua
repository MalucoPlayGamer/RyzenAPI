-- Lua provided by RyzenAPI
-- Game: AppID 975510

-- MAIN APPLICATION
addappid(975510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(975511, 1, "ccb177e7fc68693a3ad5229b846d45af16ed4b8bf2a6cb6075da1622e2bcfa8c")
addappid(975512, 1, "c80f31326819d960f857f32443c42bc0b22b8634fe56d533549fbaf8648fe312")
addappid(1379430, 0, "621c3b0102dd0554f07d424a55b60e59020c82933274dea324b6c06ad1a8fce5")

