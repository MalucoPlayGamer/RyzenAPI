-- Lua provided by RyzenAPI
-- Game: Hentai Pair

-- MAIN APPLICATION
addappid(1046650)
-- Game: addappid(1046650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046651, 1, "1f5576c030866b7cd192f8638b9943e9b9b10814f43ed96373f6c0cc100c674e")
