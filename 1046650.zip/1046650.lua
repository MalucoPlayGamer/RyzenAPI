-- Lua provided by RyzenAPI
-- Game: Hentai Pair

-- MAIN APPLICATION
addappid(1046650)
addappid(3862110)
addappid(3862120)
addappid(4845780)
addappid(4845790)
addappid(4845800)
addappid(4845810)
addappid(4845820)
addappid(4845830)
addappid(4845840)
addappid(4845850)
addappid(4845860)
addappid(4845870)
addappid(4845930)
addappid(4845940)
addappid(4845950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046651,0,"1f5576c030866b7cd192f8638b9943e9b9b10814f43ed96373f6c0cc100c674e")

