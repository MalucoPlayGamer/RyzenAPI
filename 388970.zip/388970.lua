-- Lua provided by RyzenAPI 
-- Game: AppID 388970
addappid(388970)
addappid(388971, 1, "e5cc601932ffbc3b2c2f14985c50f8d3d15677799f4c9f39f71029d2ac89c040")
