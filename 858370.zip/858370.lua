-- Lua provided by RyzenAPI
-- Game: AppID 858370

-- MAIN APPLICATION
addappid(858370)

-- MAIN APP DEPOTS / PACKAGES
addappid(858371, 1, "cb35f494add75909d7e15b640cec9ee7e5648ad4546ee53227dc6e6ad8730629")

