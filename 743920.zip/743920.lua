-- Lua provided by RyzenAPI
-- Game: AppID 743920

-- MAIN APPLICATION
addappid(743920)
-- Game: addappid(743920)

-- MAIN APP DEPOTS / PACKAGES
addappid(743921, 1, "d1d8e1bfd7dced06eb691299aa316ca22b23d6284e320f67165bfc6b0f6f341d")
