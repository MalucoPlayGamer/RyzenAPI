-- Lua provided by RyzenAPI
-- Game: AppID 743920

-- MAIN APPLICATION
addappid(743920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(743921, 1, "d1d8e1bfd7dced06eb691299aa316ca22b23d6284e320f67165bfc6b0f6f341d")

