-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Maple Hollow 🍂

-- MAIN APPLICATION
addappid(2551170)
addappid(2736010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551171, 1, "0c7bed8faf942d835af59207a5a9eec39ab46494f10720ea1f0b045d4fd4064d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
