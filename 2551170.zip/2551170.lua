-- Lua provided by RyzenAPI
-- Game: Game: Travellin Cats in Maple Hollow 🍂

-- MAIN APPLICATION
addappid(2551170)
addappid(2736010)
-- Game: addappid(2551170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551171, 1, "0c7bed8faf942d835af59207a5a9eec39ab46494f10720ea1f0b045d4fd4064d")
