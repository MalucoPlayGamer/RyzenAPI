-- Lua provided by RyzenAPI
-- Game: Kingdoms of Amalur: Re-Reckoning

-- MAIN APPLICATION
addappid(1041720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041721, 1, "dc263061e909d671e1ef975d8405074724bbdb4528043bf746f0b92609816114")
addappid(1278260, 0, "ffb3bd4a4a80e1c9ad24ece61bd05b4e830141fff5814bffaa0467bd0ad2be13")

