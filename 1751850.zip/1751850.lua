-- Lua provided by RyzenAPI
-- Game: Ghost Terminator

-- MAIN APPLICATION
addappid(1751850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751851, 1, "e8f2a589fe9816bd2a9bcb8968a25aa2d1a78ce1ff85d08408a4501023279182")
