-- Lua provided by RyzenAPI
-- Game: Tiny Car Mess

-- MAIN APPLICATION
addappid(2691200)
-- Game: addappid(2691200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691201, 1, "b6fa3f8ecf163090a1f812e97f42a116e927c25018543746c753fa849bdac330")
addappid(2691202, 1, "2f5a5de925c4b45d4c5c836e5b82b27e64e383928bce16c54c197488789a2882")
