-- Lua provided by SkyAPI 
-- Game: Bloons TD Battles
addappid(444640)
addappid(444641, 1, "059a521905bc834d23ee775fc43e5e3b6d78e91b4e7183f00219b874782ddcba")
addappid(444642, 1, "57f5cf626c8a448af5894b2fc626ea958ecc5ec3dfd2e3c1677a0dcd471b3df3")
addappid(472350)
