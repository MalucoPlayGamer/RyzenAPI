-- Lua provided by RyzenAPI
-- Game: Bloons TD Battles

-- MAIN APPLICATION
addappid(444640)
addappid(472350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(444641, 1, "059a521905bc834d23ee775fc43e5e3b6d78e91b4e7183f00219b874782ddcba")
addappid(444642, 1, "57f5cf626c8a448af5894b2fc626ea958ecc5ec3dfd2e3c1677a0dcd471b3df3")

