-- Lua provided by RyzenAPI
-- Game: 1397610

-- MAIN APPLICATION
addappid(228988)
addappid(1397610)
addappid(1397613)
addappid(1397614)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397612,0,"657d6be80dee6efeaf1a40532eb273380ecab12ad12d0f2ef8d92618f938be8a")

