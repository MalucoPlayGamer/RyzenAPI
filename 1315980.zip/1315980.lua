-- Lua provided by RyzenAPI
-- Game: Game: Tin Can

-- MAIN APPLICATION
addappid(1315980)
-- Game: addappid(1315980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315981, 1, "fc760633f505c981a24179342210f89be1be36ca4e17f7f4f1cd49567454e94c")
