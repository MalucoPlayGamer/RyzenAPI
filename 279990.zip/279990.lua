-- Lua provided by RyzenAPI
-- Game: 279990

-- MAIN APPLICATION
addappid(279990)
-- Game: addappid(279990)

-- MAIN APP DEPOTS / PACKAGES
addappid(279992,0,"0b3256d30def4aeb8d9b45c675e437ba17e842a469a3f1cba91a8ce760cdef8c")
addappid(279993,0,"dff04df1d5b30b7f9d4af6c523503e4de8ecb1a194ead2242ef3763ac956ad41")
addappid(279994,0,"7ee5b2481cc454c4cce98c47198d957571b4dc51dccda4f026a6f5406201abd0")
