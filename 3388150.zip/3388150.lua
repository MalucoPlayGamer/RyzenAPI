-- Lua provided by RyzenAPI
-- Game: 3388150

-- MAIN APPLICATION
addappid(3388150)
-- Game: addappid(3388150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388151, 1, "2f5368b770ff409c5a2d51ba12f9493a9e41ce98c33449bef18d4a341b0ec3d8")
