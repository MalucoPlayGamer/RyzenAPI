-- Lua provided by RyzenAPI
-- Game: Tides of Despair

-- MAIN APPLICATION
addappid(2467590) -- Tides of Despair

-- MAIN APP DEPOTS / PACKAGES
addappid(2467591, 1, "59a75311e6b3c61458a9889026ec1f152a0c3cf020d8148f073e75b55754bcd5") -- Depot 2467591

