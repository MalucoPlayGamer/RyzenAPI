-- 2467590's Lua and Manifest Created by Hubcap Manifest
-- Tides of Despair
-- Created: August 26, 2026 at 12:09:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2467590) -- Tides of Despair
-- MAIN APP DEPOTS
addappid(2467591, 1, "59a75311e6b3c61458a9889026ec1f152a0c3cf020d8148f073e75b55754bcd5") -- Depot 2467591
setManifestid(2467591, "4599288816214568266", 10731737419)