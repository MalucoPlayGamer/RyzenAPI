-- Lua provided by RyzenAPI
-- Game: Divider Dave

-- MAIN APP DEPOTS / PACKAGES
addappid(4463690, 1, "0a6cd36f9919c09f1a4bf8704cee952344a16b153e2267ac008572fa7597a987") -- Divider Dave
addappid(4463691, 1, "29e574becd760c61fb817380c144ab898c1424186ac3b7199cdd51b3dc01e72e") -- Depot 4463691
addappid(4463692, 1, "ac9273f1c82b04046259f8153729abf7c82c2ed141b9f0dfc24a1a68716f3900") -- Depot 4463692

