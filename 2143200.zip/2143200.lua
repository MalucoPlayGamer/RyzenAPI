-- Lua provided by RyzenAPI
-- Game: Meta Lines

-- MAIN APPLICATION
addappid(2143200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143202,0,"98cbfced76cc7e477825f807eb78515f9f68f9fe9bc005bb370e1453e3dc80e0")
