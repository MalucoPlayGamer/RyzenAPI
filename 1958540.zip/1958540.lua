-- Lua provided by RyzenAPI
-- Game: addappid(1958540)

-- MAIN APPLICATION
addappid(1958540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958541, 1, "c066c7ac65d2b4fe8d3a965aee683195cb2935f641b5cbd37cd4bb58e585620f")
