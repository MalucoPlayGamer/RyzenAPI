-- Lua provided by RyzenAPI
-- Game: 2106840

-- MAIN APPLICATION
addappid(2106840)
-- Game: addappid(2106840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106841, 1, "cc8b19ed64bc938af5a0b9eb2e1570addaab373a122a1b4126a75b0c9b51b05b")
