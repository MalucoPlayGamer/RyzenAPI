-- Lua provided by RyzenAPI
-- Game: Doomed'n Damned

-- MAIN APPLICATION
addappid(383810)

-- MAIN APP DEPOTS / PACKAGES
addappid(383811, 1, "1569b9e1566041b3dfc8ca21c38b1db639fa40be6c71f6c9922e7426f006e746")
