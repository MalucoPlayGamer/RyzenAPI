-- Lua provided by RyzenAPI
-- Game: Photographer

-- MAIN APPLICATION
addappid(1562800)
-- Game: addappid(1562800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562801, 1, "7ce64b2d3863d7c601559241cd63cd96c4ad1d5a63399535c0799a5fb75e5a26")
