-- Lua provided by RyzenAPI
-- Game: Photographer

-- MAIN APPLICATION
addappid(1562800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562801, 1, "7ce64b2d3863d7c601559241cd63cd96c4ad1d5a63399535c0799a5fb75e5a26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
