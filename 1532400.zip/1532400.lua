-- Lua provided by RyzenAPI
-- Game: 4 Witch Seasons & Convenant

-- MAIN APPLICATION
addappid(1532400)
-- Game: addappid(1532400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532401, 1, "9cdd787e4f334343ab171e7b47dad6378a2174bf213747670fafcd142c2dbb01")
