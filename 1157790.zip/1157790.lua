-- Lua provided by RyzenAPI
-- Game: I Can't Believe It's Not Gambling 2K GOTY Edition

-- MAIN APPLICATION
addappid(1157790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157791, 1, "7c11894097b861e28b6e2bdba08a312fa759665edc7eab96459628be8e2f42d5")
