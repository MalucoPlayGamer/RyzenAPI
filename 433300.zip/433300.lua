-- Lua provided by RyzenAPI
-- Game: Marvel: Ultimate Alliance

-- MAIN APPLICATION
addappid(433300)
-- Game: addappid(433300)

-- MAIN APP DEPOTS / PACKAGES
addappid(433301, 1, "11e0007bcc4ac069337203e2e1f572151eff6159cde863b2a509cd79604cbad5")
addappid(433302, 1, "33b856f560198f14667137e6aaca3c0ba045567e4525e6e5157c851a43475522")
