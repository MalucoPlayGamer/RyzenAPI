-- Lua provided by RyzenAPI
-- Game: 1144770

-- MAIN APPLICATION
addappid(1144770)
-- Game: addappid(1144770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144771, 1, "d50d39beda892aeb254fbfe7e4e2f5951a480a8f0d489e19ea7bc40c93308662")
