-- Lua provided by RyzenAPI
-- Game: Game: Your Chronicle

-- MAIN APPLICATION
addappid(1546320)
addappid(1682010)
-- Game: addappid(1546320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546321, 1, "c3a9e89d1f4e4fb13ecf909ae7531955958791f279509eca727ed6200510c045")
addappid(1546322, 1, "a8c5686b683b1a3881ed0cad672dbb423894303c6ce26ed5a1db6591e272bf63")
addappid(1546323, 1, "42c4edd12dea63044e5e0cc2919a0a097846d87c3c59d7554946539595fab6b3")
