-- Lua provided by SkyAPI 
-- Game: Achromatic
addappid(1990210)
addappid(1990211, 1, "c0e2abdbcb6940e8ef6f915ee4f746c258bd64def4eccb32a22c98f4397d5bdb")
