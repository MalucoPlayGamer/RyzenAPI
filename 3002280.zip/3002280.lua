-- Lua provided by RyzenAPI
-- Game: Game: Tiny Bookshop Demo

-- MAIN APPLICATION
addappid(3002280)
-- Game: addappid(3002280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002281, 1, "95ca9dcb9730839dd2471d29f263f6aec965f845d23e2f62081837e1e0f63c58")
