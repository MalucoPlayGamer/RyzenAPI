-- Lua provided by RyzenAPI 
-- Game: The Spiral Scouts
addappid(862480)
addappid(862481, 1, "33ebe36fb7c08dd37b81aae0916669f4c9f84506f95319e344ee3c6b78cf3053")
addappid(862482, 1, "5d9cdc8ce3cebfc6bbd807a7a4222312796be68bb34a8ff71e325852fb688112")
addappid(862483, 1, "bd8688887ed83dd355c4d64b9d409b27d466245c33117ff1dcdb40e6283691ee")
