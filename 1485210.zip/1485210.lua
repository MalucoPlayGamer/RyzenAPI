-- Lua provided by RyzenAPI
-- Game: Blackstar

-- MAIN APPLICATION
addappid(1485210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485211, 1, "587f540cfa0d6f8fb20e7dd8d9b4812680d5a61c3c98ddc6f3c0d6103a6a5316")
