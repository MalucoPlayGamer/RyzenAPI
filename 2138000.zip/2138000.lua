-- Lua provided by RyzenAPI
-- Game: Hoshizora no Memoria -Eternal Heart- HD

-- MAIN APPLICATION
addappid(2138000)
-- Game: addappid(2138000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138001, 1, "997d595f66b1196d3e0326c199aeadee0499c2f67bf545b49a1a4a0ab1c391d4")
