-- Lua provided by RyzenAPI
-- Game: Microsoft Flight Simulator 2024

-- MAIN APPLICATION
addappid(2537590)
addappid(3227340)
addappid(3245690)
addappid(3245700)
addappid(3245710)
addappid(3341960)
-- Game: addappid(2537590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537591, 1, "a149759cc259406fd0f2255297e089d9deb63fb59c263b7f2d1b7fcd7aded1a4")
