-- Lua provided by RyzenAPI
-- Game: Hoshizora no Memoria -Wish upon a Shooting Star- HD

-- MAIN APPLICATION
addappid(715580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(715581, 1, "8a42524b25568650c773f1584895951c1e11dd2c918344b1845e3ee750bf9186")
addappid(715582, 1, "e6ccbac929169dcd829466b5e2638cbec13aa86beaa899ba746cd08c8a92d818")
