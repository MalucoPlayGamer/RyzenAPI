-- Lua provided by RyzenAPI
-- Game: AppID 254440

-- MAIN APPLICATION
addappid(254440)
addappid(272080)
-- Game: addappid(254440)

-- MAIN APP DEPOTS / PACKAGES
addappid(254441, 1, "ab4a46fb5161661e788f8ad36a860eb66bf2cb5a2438c88593eb78a886f44531")
