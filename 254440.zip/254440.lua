-- Lua provided by RyzenAPI
-- Game: Pool Nation

-- MAIN APPLICATION
addappid(254440)
addappid(272080)
addappid(272082)
addappid(272083)
addappid(272084)
addappid(272090)
addappid(285730)
addappid(328280)
addappid(328290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(254441, 1, "ab4a46fb5161661e788f8ad36a860eb66bf2cb5a2438c88593eb78a886f44531")
