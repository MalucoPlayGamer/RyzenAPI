-- Lua provided by SkyAPI 
-- Game: e-act Catcher for Akpala
addappid(2344740)
addappid(2344741, 1, "1108f4f3d7956ac3dd18e5dcf15da4448cf7c7ee98022f13b089fb7620e6dc7b")
