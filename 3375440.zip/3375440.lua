-- Lua provided by RyzenAPI
-- Game: Game: Lingo 2 Demo

-- MAIN APPLICATION
addappid(3375440)
-- Game: addappid(3375440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3375441, 1, "848d2a82f39d62fb024185a5eec975f46061e199044a9344b4258c84e8989040")
