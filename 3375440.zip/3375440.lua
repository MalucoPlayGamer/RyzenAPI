-- Lua provided by SkyAPI 
-- Game: Lingo 2 Demo
addappid(3375440)
addappid(3375441, 1, "848d2a82f39d62fb024185a5eec975f46061e199044a9344b4258c84e8989040")
