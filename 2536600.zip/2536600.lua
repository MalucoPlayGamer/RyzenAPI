-- Lua provided by RyzenAPI
-- Game: Dusty Derby

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2536600, 1, "01064f407530cbf9aad47a96a571de55e995414014d9d4ab3e0d6ea3a4e0cdfa") -- Dusty Derby
addappid(2536601, 1, "f3e397f671e01ce5908c282f3cbda3e2c1aac6b73391b75b25ca4d7e550daddc") -- Depot 2536601

