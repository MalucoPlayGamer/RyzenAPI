-- Lua provided by RyzenAPI
-- Game: AppID 356030

-- MAIN APPLICATION
addappid(356030)
-- Game: addappid(356030)

-- MAIN APP DEPOTS / PACKAGES
addappid(356031, 1, "7e0907fec6bb6980d76024ef8faeac5e76fc4426d0f170baf6c36c37ee8918f4")
