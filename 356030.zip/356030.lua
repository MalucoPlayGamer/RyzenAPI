-- Lua provided by RyzenAPI
-- Game: The Survivor

-- MAIN APPLICATION
addappid(356030)

-- MAIN APP DEPOTS / PACKAGES
addappid(356031, 1, "7e0907fec6bb6980d76024ef8faeac5e76fc4426d0f170baf6c36c37ee8918f4")
