-- Lua provided by RyzenAPI
-- Game: addappid(3277940)

-- MAIN APPLICATION
addappid(3277940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277942,0,"bd8cff30ee2fdb34b89ec578e4753ff2107737998360281957be014feec3953a")
