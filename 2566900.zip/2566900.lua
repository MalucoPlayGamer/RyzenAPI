-- Lua provided by RyzenAPI
-- Game: addappid(2566900)

-- MAIN APPLICATION
addappid(2566900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566901, 1, "bf52cdeb5cb5806caa2ca34942767f7cf5bdcb001018e75a3f5009626c35825a")
