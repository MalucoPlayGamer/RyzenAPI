-- Lua provided by RyzenAPI
-- Game: addappid(1198990)

-- MAIN APPLICATION
addappid(1198990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198991, 1, "dad01674c1d3a72a845f01c0895e4570a8e07fc06de1ce73b2cbf6c254589187")
