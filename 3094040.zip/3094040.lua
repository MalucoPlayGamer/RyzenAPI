-- Lua provided by RyzenAPI
-- Game: Liminal Border Part III

-- MAIN APPLICATION
addappid(3094040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3094041, 1, "c69bfcc0b7843edf6ace89fc0266e0ce77a57d798177147242b4825ddb04db81")

