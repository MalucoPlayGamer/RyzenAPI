-- Lua provided by RyzenAPI
-- Game: addappid(584382)

-- MAIN APPLICATION
addappid(584382)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238690,0,"cfde1f36432a922e098c75e00ca1b60161d59cde0ee066ed0cb60bf1be68a15b")
addappid(1238691,0,"9d53fe72786792b44c03b079223207fcd15d8a9d3456cc16fbead0a1756c3e1f")
