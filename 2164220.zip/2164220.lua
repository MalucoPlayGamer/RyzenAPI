-- Lua provided by RyzenAPI
-- Game: Who is There?

-- MAIN APPLICATION
addappid(2164220)
addappid(2164221)
addappid(2164222)
addappid(2164223)
addappid(2164224)
addappid(2164225)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164226,0,"3a5c61b2ab62d67313ba191630cc6833511520d6766a4652e5ec03e2bea6650a")
