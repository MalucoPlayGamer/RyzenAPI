-- Lua provided by RyzenAPI
-- Game: Forgotten Seas

-- MAIN APPLICATION
addappid(2168260)
-- Game: addappid(2168260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168261, 1, "e87ba8c96036622a748b7a049ca375701dbcebfcc561de74eb0815ce807dc8d4")
