-- Lua provided by SkyAPI 
-- Game: Forgotten Seas
addappid(2168260)
addappid(2168261, 1, "e87ba8c96036622a748b7a049ca375701dbcebfcc561de74eb0815ce807dc8d4")
