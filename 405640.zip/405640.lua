-- Lua provided by RyzenAPI 
-- Game: Pony Island
addappid(405640)
addappid(405641, 1, "bc44e83e7c8ab9ae70ece7e31bab23c05344f3315ddc7036061c448c942c0386")
addappid(405642, 1, "7953588d0d439a9d9a760217f15b5e1d1c2817d43c160f7baf4df0c63abc67ce")
addappid(405643, 1, "50fcda5dfe621866a52eb341e129a885b825c29ecb7d515e2ce4a02678742553")
