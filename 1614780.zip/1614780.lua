-- Lua provided by RyzenAPI
-- Game: BAD DREAMS

-- MAIN APPLICATION
addappid(1614780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614781, 1, "a3087d368cdddc95ee4250291b438e85522e54cbe4b1a8deb0ce084f43b76bfe")
