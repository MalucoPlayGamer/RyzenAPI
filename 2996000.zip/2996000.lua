-- Lua provided by RyzenAPI
-- Game: Faun Town

-- MAIN APPLICATION
addappid(2996000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2996001, 1, "d7e3eac93b6415fc81b711105d4b221a3306aea306d44c8b6e0a5b4835480307")
