-- Lua provided by SkyAPI 
-- Game: Snow Plow Playtest
addappid(1902270)
addappid(1902271, 1, "9d000125d4454a7c23e94957e0275526c011770cfe57a5ff737a13a1b1bcbda9")
