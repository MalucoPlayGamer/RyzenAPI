-- Lua provided by SkyAPI 
-- Game: AppID 2606320
addappid(2606320)
addappid(2606321, 1, "d4bf34fad57cf03e9add4cc1c33a423e2de7d789fca49428bb833ab3f4af7fe6")
