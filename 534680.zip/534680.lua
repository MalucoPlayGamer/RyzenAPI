-- Lua provided by RyzenAPI
-- Game: addappid(534680)

-- MAIN APPLICATION
addappid(534680)

-- MAIN APP DEPOTS / PACKAGES
addappid(534681, 1, "4a46ecb580971e9958ea54dea232d116e45bcda2072b270166856a15018b2f42")
