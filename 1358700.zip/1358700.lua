-- Lua provided by RyzenAPI
-- Game: 1358700

-- MAIN APPLICATION
addappid(1358700)
addappid(2252280)
addappid(2337570)
-- Game: addappid(1358700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358701, 1, "882a9301f93fb1940dc1c638bf6f343c4c2513d29d3dd46fc5208976e9de966d")
