-- Lua provided by RyzenAPI
-- Game: STRANGER OF PARADISE FINAL FANTASY ORIGIN

-- MAIN APPLICATION
addappid(1358700)
addappid(2252280)
addappid(2337570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358701, 1, "882a9301f93fb1940dc1c638bf6f343c4c2513d29d3dd46fc5208976e9de966d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2191870)
