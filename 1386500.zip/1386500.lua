-- Lua provided by RyzenAPI
-- Game: cyan

-- MAIN APPLICATION
addappid(1386500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386501, 1, "98e96f62954a509293ffcd09706e4b67496fba5710ba1e1814ac91abf94460b2")

