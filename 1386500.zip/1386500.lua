-- Lua provided by RyzenAPI
-- Game: cyan

-- MAIN APPLICATION
addappid(1386500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386501, 1, "98e96f62954a509293ffcd09706e4b67496fba5710ba1e1814ac91abf94460b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
