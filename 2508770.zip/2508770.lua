-- Lua provided by RyzenAPI
-- Game: Game: Farmagia

-- MAIN APPLICATION
addappid(2508770)
-- Game: addappid(2508770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508771, 1, "a96c4c1f716a0801a418470a96fa94121f5f3ae8716a4139bc2b96303784b888")
