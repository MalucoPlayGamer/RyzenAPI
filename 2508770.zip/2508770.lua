-- Lua provided by RyzenAPI
-- Game: Farmagia

-- MAIN APPLICATION
addappid(2508770)
addappid(2858070)
addappid(3031480)
addappid(3031490)
addappid(3031500)
addappid(3031510)
addappid(3031520)
addappid(3031530)
addappid(3031540)
addappid(3031550)
addappid(3031560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508771,0,"a96c4c1f716a0801a418470a96fa94121f5f3ae8716a4139bc2b96303784b888")
addappid(2858070,0,"f03863c771b99b2003bf8ec90d5fcce93b03e25263b5709ef6ff26027ddf92d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
