-- Lua provided by RyzenAPI
-- Game: Escape The Pacific

-- MAIN APPLICATION
addappid(655290)

-- MAIN APP DEPOTS / PACKAGES
addappid(655291, 1, "37a68ff80d0a3339076308b39fca1e02bb59d26a7626e6e563a148c93cecd499")

