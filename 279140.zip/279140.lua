-- Lua provided by RyzenAPI
-- Game: Making History: The Great War

-- MAIN APPLICATION
addappid(279140)
addappid(402660)

-- MAIN APP DEPOTS / PACKAGES
addappid(279141, 1, "1a6c6c2f3fcf048bf74848e4f1873970a445d33a050f9669afe6d91709b9d976")
addappid(279142, 1, "320af04c28bc3b7caafaffe63dc5f342db7a36d5beeeadc1cfc3e2a6a13dd37e")
addappid(279143, 1, "ea6d328847e5106474ecf350a878c3fa95d0d25e66ba910fef6c85d19639f2f5")
