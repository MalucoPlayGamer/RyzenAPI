-- Lua provided by RyzenAPI
-- Game: Pls Kill it.

-- MAIN APPLICATION
addappid(1901300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901301, 1, "abef2aada7585bb5a2b75873dbf01ca856b977e4b17e2b0deeb5c052394169b9")
