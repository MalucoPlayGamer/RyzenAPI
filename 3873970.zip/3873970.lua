-- Lua provided by RyzenAPI
-- Game: NASCAR 25

-- MAIN APPLICATION
addappid(3873970)
addappid(4132390)
addappid(4132400)
addappid(4132410)
addappid(4132630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3873971, 1, "426d1f99b6979fafd74cccbfcf4d62638edfa295a3deaccffdbf15a58039d77f")

