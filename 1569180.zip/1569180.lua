-- Lua provided by RyzenAPI
-- Game: Game: The Kotonoha Sisters and the Legend of Lysant Island

-- MAIN APPLICATION
addappid(1569180)
-- Game: addappid(1569180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569181, 1, "6c73708211f77aad9666a10b32279c92059d64ce31c3194501b33b9f04829d68")
