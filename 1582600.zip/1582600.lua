-- Lua provided by RyzenAPI
-- Game: Game: AppID 1582600

-- MAIN APPLICATION
addappid(1582600)
-- Game: addappid(1582600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582601, 1, "3650feedd9a2efdb4b248e44f6fab86df4a4ab44a17f5fff380488b45bf8de73")
addappid(1582602, 1, "a11f8bf3e9bd4059e70aa1e23c5009de983d50ff206931193b43daf7205d612f")
