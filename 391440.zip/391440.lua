-- Lua provided by SkyAPI 
-- Game: AppID 391440
addappid(391440)
addappid(391441, 1, "b05243624eea2a2cee750c3f0ebdc1c228df93e1cc3da20e8f9ea7b4b972d27b")
