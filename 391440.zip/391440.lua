-- Lua provided by RyzenAPI
-- Game: AppID 391440

-- MAIN APPLICATION
addappid(391440)
-- Game: addappid(391440)

-- MAIN APP DEPOTS / PACKAGES
addappid(391441, 1, "b05243624eea2a2cee750c3f0ebdc1c228df93e1cc3da20e8f9ea7b4b972d27b")
