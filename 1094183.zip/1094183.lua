-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Cao Pi "Racing Suit Costume" / 曹丕「レーシングスーツ風コスチューム」

-- MAIN APPLICATION
addappid(1094183)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094183,0,"27a458d53a17513389c32f280a6c398dcaa0d3bed37c96748162c2c452592a36")

