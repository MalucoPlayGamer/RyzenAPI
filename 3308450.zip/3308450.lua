-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Soldier Character Pack 3

-- MAIN APPLICATION
addappid(3308450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308450,0,"e875bcc0a80100edd4543e58735c2acbf20c7bbd6c8198ed93475726c23ee88e")
