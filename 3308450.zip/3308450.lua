-- Lua provided by RyzenAPI
-- Game: 3308450

-- MAIN APPLICATION
addappid(3308450)
-- Game: addappid(3308450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308450,0,"e875bcc0a80100edd4543e58735c2acbf20c7bbd6c8198ed93475726c23ee88e")
