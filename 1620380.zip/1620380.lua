-- Lua provided by RyzenAPI
-- Game: addappid(1620380)

-- MAIN APPLICATION
addappid(1620380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620381, 1, "8da8fc762fc052153bea98dbd581079ecc6e7f9eec8048f23b3d3256ef01af32")
