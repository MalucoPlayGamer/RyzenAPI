-- Lua provided by RyzenAPI
-- Game: Cosmo Clash

-- MAIN APPLICATION
addappid(1481730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481731, 1, "5afd3f4601f97cf23a7a55e8237d94be558ce2b7c67f041b20c158612c5818e3")
