-- Lua provided by RyzenAPI
-- Game: 1096520

-- MAIN APPLICATION
addappid(1096520)
-- Game: addappid(1096520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096521, 1, "743ec6bd4f0afdd6f93f244aee462b16a26ab4cc2c9bcc76cbec396e5a18fe36")
