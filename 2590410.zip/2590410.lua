-- Lua provided by RyzenAPI
-- Game: Furry Necromancer 💀

-- MAIN APPLICATION
addappid(2590410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590411,0,"2f32978011c5bb6f1eee1386ec1a49ce2125de4cbddb5087b7c67351ff9a5154")
addappid(2613470,0,"485ea061cb2a141949a2bfa1dae46106c28e8b341b7d29c4b9de536bc24f1593")

