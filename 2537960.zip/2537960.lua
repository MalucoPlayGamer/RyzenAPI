-- Lua provided by RyzenAPI
-- Game: Dirt Bicycle Rider Simulator

-- MAIN APPLICATION
addappid(2537960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537961, 1, "edfe2c1664feecc09f6ba785d945e31d6c624683f27bb71ddeb5f34de3651725")
