-- Lua provided by RyzenAPI
-- Game: FromTheEarth VR

-- MAIN APPLICATION
addappid(1120600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1120601,0,"2ad5d9e7e773e547e113c249f4f5d9754721fb701eab5435826117354aa917e3")

