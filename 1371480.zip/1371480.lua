-- Lua provided by RyzenAPI
-- Game: addappid(1371480)

-- MAIN APPLICATION
addappid(1371480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371481, 1, "5ed5f7b5c62fffed62429a1218dbcc18427050c54a0e2d77c4ed26516bb4a7cc")
