-- Lua provided by RyzenAPI
-- Game: addappid(2990380)

-- MAIN APPLICATION
addappid(2990380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990381, 1, "b274d88da138255363934b277c3add8a74c9f5b68bc37fac372d68622fce5780")
