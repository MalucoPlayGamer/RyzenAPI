-- Lua provided by RyzenAPI 
-- Game: AppID 1091010
addappid(1091010)
addappid(1091011, 1, "97366dfd5caae2f750386c64de3c3b171f1796e79977800def71cf2786b86319")
