-- Lua provided by RyzenAPI
-- Game: Game: Five dreams

-- MAIN APPLICATION
addappid(1805150)
-- Game: addappid(1805150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805151, 1, "4f2d94c01124c182ea8d7e0b82ab8e4df2b8837efcc2a82b26100d1782196413")
