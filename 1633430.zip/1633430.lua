-- Lua provided by RyzenAPI
-- Game: OU

-- MAIN APPLICATION
addappid(1633430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633431, 1, "9f475147477295f08bd10d8ee1791c198040f54dcbe73478cdfe1bd414afef35")

