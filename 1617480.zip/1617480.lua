-- Lua provided by RyzenAPI
-- Game: Fight Party

-- MAIN APPLICATION
addappid(1617480)
-- Game: addappid(1617480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617481, 1, "930845e10067c7394753771915a1df6f74d2500fa27629a518a98b2744e4c6f4")
