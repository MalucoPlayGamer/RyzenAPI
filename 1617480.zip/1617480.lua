-- Lua provided by SkyAPI 
-- Game: Fight Party
addappid(1617480)
addappid(1617481, 1, "930845e10067c7394753771915a1df6f74d2500fa27629a518a98b2744e4c6f4")
