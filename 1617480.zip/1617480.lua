-- Lua provided by RyzenAPI
-- Game: Fight Party

-- MAIN APPLICATION
addappid(1617480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617481, 1, "930845e10067c7394753771915a1df6f74d2500fa27629a518a98b2744e4c6f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
