-- Lua provided by RyzenAPI 
-- Game: Edge Of Dead: Under A Uranium Sky
addappid(1466400)
addappid(1466401, 1, "f50131a0b900d23cf6c75f01e2c5b4c0792a6914b4c5b4e15dba969908f81c52")
