-- Lua provided by RyzenAPI
-- Game: DFF NT: Akademeia Summer Uniform Appearance Set for Ace

-- MAIN APPLICATION
addappid(1022510)
-- Game: addappid(1022510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022510,0,"3f56dc17672aae8390440f1ecc4e6f38db1aced5cd5c414bdbcc1fb84e9aadcd")
