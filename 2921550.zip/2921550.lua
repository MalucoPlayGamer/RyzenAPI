-- Lua provided by RyzenAPI
-- Game: Cedric & Odious

-- MAIN APPLICATION
addappid(2921550)
-- Game: addappid(2921550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921553,0,"67ca8460b31de9022041370ae346ae1a2d0f903cec0c30159c3f0a5a8042112f")
addappid(2921554,0,"63c40d6da31458c5ed6656088bc1c0da5deb678e9b139fc8e702f974c54aea5a")
