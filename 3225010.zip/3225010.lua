-- Lua provided by RyzenAPI
-- Game: AppID 3225010

-- MAIN APPLICATION
addappid(3225010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3225011, 1, "34cb2c0023c0b262527470556a20b848bd3d5e1b07b9bc8afacd2d9d23122a3f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3885550)
addappid(4361390)
addappid(4361400)
