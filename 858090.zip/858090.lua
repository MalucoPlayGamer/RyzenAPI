-- Lua provided by RyzenAPI
-- Game: Spellcastia

-- MAIN APPLICATION
addappid(858090)

-- MAIN APP DEPOTS / PACKAGES
addappid(858091,0,"b81a3e2e5996f20d9a58852f5158424972a609dda410605094272cabd535ef93")

