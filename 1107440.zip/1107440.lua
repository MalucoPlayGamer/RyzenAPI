-- Lua provided by RyzenAPI
-- Game: AppID 1107440

-- MAIN APPLICATION
addappid(1107440)
-- Game: addappid(1107440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107441, 1, "0360fcdca98bd9e6ba59535dcb13daa0f8e6090e5f5ecec2e6f7f598f4c2fc2c")
