-- Lua provided by RyzenAPI
-- Game: 3510940

-- MAIN APPLICATION
addappid(3510940)
-- Game: addappid(3510940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3510941, 1, "0072feb7c159e27e1faf93a6549630d9a1a284a7eb26c273b046b81228167f5c")
