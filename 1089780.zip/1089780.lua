-- Lua provided by RyzenAPI
-- Game: Tales Of Glory 2 - Retaliation

-- MAIN APPLICATION
addappid(1089780)
-- Game: addappid(1089780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089781, 1, "2267cf6d001bbf688ac503c0a98efea4dbb7e377373c7b7b4f70d7130c794ec8")
