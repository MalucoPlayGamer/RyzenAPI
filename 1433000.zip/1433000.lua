-- Lua provided by RyzenAPI
-- Game: Chronicles of cyberpunk - Deep sleep

-- MAIN APPLICATION
addappid(1433000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433001, 1, "85571c90df0a880538e34a2ddbafbc37de04635361657cbd10b5b2ca1ebf37b3")
addappid(1433002, 1, "32ead714362bf8d37f5823b2c39c8cb417916bc12a73cd667725c2fcbb1e870c")
addappid(1433003, 1, "1c7d344e057530b4470a27fa450456831d2050fa5a71e71b73f0028405be0516")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
