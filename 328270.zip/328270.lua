-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(328270)
addappid(328273)
addappid(328277)
addappid(452470)
addappid(503990)

-- MAIN APP DEPOTS / PACKAGES
addappid(328275,0,"99a9a9d147853ed04fae78ad5ac208d9ca66254693a1c60ec525ea7fc9374522")

