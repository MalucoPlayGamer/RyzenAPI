-- Lua provided by RyzenAPI
-- Game: Slashers

-- MAIN APPLICATION
addappid(1875810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1875811, 1, "00b11d3c0d3e4c4f2fd4be7ab736c1a0820f4cb766806545f3a5979e6eb040c0")

