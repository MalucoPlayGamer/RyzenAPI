-- Lua provided by RyzenAPI
-- Game: Game: Slashers

-- MAIN APPLICATION
addappid(1875810)
-- Game: addappid(1875810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875811, 1, "00b11d3c0d3e4c4f2fd4be7ab736c1a0820f4cb766806545f3a5979e6eb040c0")
