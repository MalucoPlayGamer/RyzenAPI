-- Lua provided by RyzenAPI
-- Game: 15930

-- MAIN APPLICATION
addappid(15930)
-- Game: addappid(15930)

-- MAIN APP DEPOTS / PACKAGES
addappid(15931, 1, "6d0dc89f7d045c37e0049ce546efb62e10555b1fec2b2f34f8071714ccea69e2")
