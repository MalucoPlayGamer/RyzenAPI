-- Lua provided by RyzenAPI 
-- Game: Luxor 3
addappid(15930)
addappid(15931, 1, "6d0dc89f7d045c37e0049ce546efb62e10555b1fec2b2f34f8071714ccea69e2")
