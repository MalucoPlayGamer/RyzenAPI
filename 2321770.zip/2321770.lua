-- Lua provided by RyzenAPI
-- Game: Game: AppID 2321770

-- MAIN APPLICATION
addappid(2321770)
-- Game: addappid(2321770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321771, 1, "121999bd5e2b97337b2c4731836baf2761f23277a1f184d9df2db1573379b22c")
