-- Lua provided by RyzenAPI
-- Game: addappid(329960)

-- MAIN APPLICATION
addappid(329960)

-- MAIN APP DEPOTS / PACKAGES
addappid(329961, 1, "ba9d38b4de4daab03f170461d2abd239c6bd2fad79deb3d7f05d20636b0aa522")
