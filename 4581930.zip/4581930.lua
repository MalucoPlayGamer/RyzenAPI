-- Lua provided by RyzenAPI
-- Game: S.A.L.A.M.E.

-- MAIN APPLICATION
addappid(4581930)

-- MAIN APP DEPOTS / PACKAGES
addappid(4581931,0,"d6dba97ee8e19e01ba277ad5b8ce13235a84b4a0a28e62d73b822ccd0420be55")

