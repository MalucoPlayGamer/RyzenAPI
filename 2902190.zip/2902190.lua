-- Lua provided by RyzenAPI
-- Game: SKALD: Against the Black Priory - Reinforcement Pack

-- MAIN APPLICATION
addappid(2902190)
-- Game: addappid(2902190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902190,0,"0678650bae7a8f2570b4be3b1eed7e7e46b5135f2d48f0398f01c6f80658d757")
