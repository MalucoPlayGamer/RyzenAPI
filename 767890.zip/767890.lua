-- Lua provided by RyzenAPI
-- Game: addappid(767890)

-- MAIN APPLICATION
addappid(767890)

-- MAIN APP DEPOTS / PACKAGES
addappid(767890,0,"f5ce9895942eef28d5a4afdb5770153acd41e107d3b15b1772979d8e251b517c")
