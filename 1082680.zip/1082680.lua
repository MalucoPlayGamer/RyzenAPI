-- Lua provided by RyzenAPI
-- Game: 1082680

-- MAIN APPLICATION
addappid(1082680)
-- Game: addappid(1082680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082681, 1, "ab6840a036b69f338315e2b0075158d6e87db40dcfb32e1ec1ef676aa9c5f88b")
