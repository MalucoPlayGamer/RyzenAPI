-- Lua provided by RyzenAPI
-- Game: The Walking Dead Onslaught

-- MAIN APPLICATION
addappid(1082680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082681, 1, "ab6840a036b69f338315e2b0075158d6e87db40dcfb32e1ec1ef676aa9c5f88b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1389080)
addappid(1391080)
