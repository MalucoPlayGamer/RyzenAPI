-- Lua provided by RyzenAPI
-- Game: addappid(1111790)

-- MAIN APPLICATION
addappid(1111790)
addappid(1111791)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111790,0,"68c9db7ac4e6281976b94e8aeb29b5b6243158a63802e22af15b8878cf7c1bbe")
