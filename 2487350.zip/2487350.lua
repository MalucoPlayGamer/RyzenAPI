-- Lua provided by RyzenAPI
-- Game: Alex Jones: NWO Wars

-- MAIN APPLICATION
addappid(2487350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487351, 1, "df41b2cc20182194317f9968c72690cb4a8307ba8c9a507042a6a953115771cf")

