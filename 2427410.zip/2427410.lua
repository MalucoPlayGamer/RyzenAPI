-- Lua provided by RyzenAPI
-- Game: addappid(2427410)

-- MAIN APPLICATION
addappid(2427410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427411, 1, "b846b553ca61c86d7281f7f121dab3628adebb5655e6bb80262c1a06780f14a6")
