-- Lua provided by RyzenAPI
-- Game: Gordian Rooms 2: A curious island Prologue

-- MAIN APPLICATION
addappid(2117290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2117291, 1, "1652c5ed922840e465981ebfcc5952a7b83c43f2fbcca786ccd4d3fc14ea3564")
addappid(2117292, 1, "0a9132cec0feca23b4071330f052c280cf86be7d026ad7f8f8072440a596136b")

