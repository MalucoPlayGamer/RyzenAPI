-- Lua provided by RyzenAPI
-- Game: Game: Monsters In The Shadows

-- MAIN APPLICATION
addappid(1949700)
-- Game: addappid(1949700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949701, 1, "9ebf51a83b10a68072ed7316d84c9a6632088efc9f117e01e15abe4a1d642a42")
