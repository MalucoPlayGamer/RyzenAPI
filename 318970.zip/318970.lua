-- Lua provided by RyzenAPI
-- Game: AppID 318970

-- MAIN APPLICATION
addappid(318970)

-- MAIN APP DEPOTS / PACKAGES
addappid(318971, 1, "7af69452245f97f35b286e9a5adaf2d044dfa0f1ccddcf620d5b8aa74f0b1f3b")
