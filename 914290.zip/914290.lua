-- Lua provided by RyzenAPI
-- Game: Game: Welcome to Princeland

-- MAIN APPLICATION
addappid(914290)
addappid(978150)
-- Game: addappid(914290)

-- MAIN APP DEPOTS / PACKAGES
addappid(914291, 1, "4b0e8280b0a2eceaa16c5707018f87f77c9e88ff9e1c2ea65019830415364e95")
