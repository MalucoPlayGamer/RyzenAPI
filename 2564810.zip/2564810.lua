-- Lua provided by SkyAPI 
-- Game: Phantom Thief Sylphy 2 - The Collector
addappid(2564810)
addappid(2564811, 1, "ab97532a1acac36f67edc3e2706e36d2d4066b93ce9c633803a81805c99280a7")
