-- Lua provided by RyzenAPI
-- Game: BrightGunner

-- MAIN APPLICATION
addappid(3470190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3470191, 1, "fd8c9f29950a6dc9afa7f7b441bd5b4b397d7ca1b540f8f540bcd04360bbf40f")

