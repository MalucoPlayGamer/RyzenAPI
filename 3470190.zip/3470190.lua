-- Lua provided by RyzenAPI 
-- Game: BrightGunner
addappid(3470190)
addappid(3470191, 1, "fd8c9f29950a6dc9afa7f7b441bd5b4b397d7ca1b540f8f540bcd04360bbf40f")
