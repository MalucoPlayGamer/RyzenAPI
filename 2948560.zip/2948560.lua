-- Lua provided by RyzenAPI
-- Game: 2948560

-- MAIN APPLICATION
addappid(2948560)
-- Game: addappid(2948560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2948561, 1, "470074ad7ca3cb3acaabbff55452951a6b80679114ae05aaece7d926dd9ef19d")
