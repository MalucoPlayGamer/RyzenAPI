-- Lua provided by RyzenAPI
-- Game: Zombie Panic! Source

-- MAIN APPLICATION
addappid(17500)

-- MAIN APP DEPOTS / PACKAGES
addappid(17501, 1, "5541066063cc4e123fc86d0c899bf83da9454969e3dacfc1581e7bd3465c11b6")
addappid(17502, 1, "20b7f29567bd45523e80c451dd7c6d0a3b99e5af101aff87867f9ab973e0d089")
addappid(17503, 1, "4618a11332ecdf8017de0bad75897125e1d1e33b9570448e34d7a073257c7331")
addappid(17504, 1, "6292c7361fd84097baa784abf62870b83cec74344ad9aeee6dcb8abcd47c9e0c")
addappid(17505, 1, "5be1ea9935907cdcdb9d57a933378ff6b3c034c0720ac5f9c68c1088b44495ef")
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

