-- Lua provided by SkyAPI 
-- Game: AppID 1169460
addappid(1169460)
addappid(1169461, 1, "2e77df935dd1b10cf4b5e23f2350b949eab8fec6348514b0ef19b6c5a33fe944")
