-- Lua provided by RyzenAPI
-- Game: AppID 1169460

-- MAIN APPLICATION
addappid(1169460)
-- Game: addappid(1169460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169461, 1, "2e77df935dd1b10cf4b5e23f2350b949eab8fec6348514b0ef19b6c5a33fe944")
