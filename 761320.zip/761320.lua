-- Lua provided by RyzenAPI
-- Game: addappid(761320)

-- MAIN APPLICATION
addappid(761320)

-- MAIN APP DEPOTS / PACKAGES
addappid(761321, 1, "5ada8b0c3213d19dfc7de4c571e18516b05c14163bf17756590d9fcba849a695")
