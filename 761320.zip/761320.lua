-- Lua provided by RyzenAPI 
-- Game: Black Jewel
addappid(761320)
addappid(761321, 1, "5ada8b0c3213d19dfc7de4c571e18516b05c14163bf17756590d9fcba849a695")
