-- Lua provided by RyzenAPI
-- Game: 294550

-- MAIN APPLICATION
addappid(294550)
addappid(303030)
addappid(303031)
addappid(303032)
addappid(303033)
addappid(303034)
addappid(303035)
addappid(303036)
addappid(303037)
addappid(303038)
addappid(303039)
addappid(303040)
addappid(303041)
addappid(303042)
addappid(303043)
addappid(303044)
addappid(303045)
addappid(303046)
addappid(303047)
-- Game: addappid(294550)

-- MAIN APP DEPOTS / PACKAGES
addappid(294551, 1, "a80ba36bd93f8f84863cb36f610f0ea2a676ebf5e294fb2961e02dc5af635683")
addappid(294554, 1, "b0c4c68ad9eeb2266089054c6d25b660aa3bab6c7881c8310be343dec5e9a754")
addappid(294555, 1, "1102ff4d1ee1ed3d6614b2c072626056c8d05d1f9bd0f1a140f8b5770b4660a2")
