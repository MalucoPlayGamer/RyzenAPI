-- Lua provided by RyzenAPI
-- Game: War Commander

-- MAIN APPLICATION
addappid(4336770)
