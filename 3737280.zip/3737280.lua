-- Lua provided by RyzenAPI
-- Game: addappid(3737280)

-- MAIN APPLICATION
addappid(3737280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3737281, 1, "a001803c1e549a8ecfacb45de68a78a6ca820fc5015330c9df3a9a21372852b1")
addappid(3737282, 1, "a1a6c6766a50aebf9926cd9dc652cc327074dce74ee95a53e36ef439f852d9b9")
