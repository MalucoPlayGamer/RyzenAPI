-- Lua provided by RyzenAPI
-- Game: AppID 1183700

-- MAIN APPLICATION
addappid(1183700)
-- Game: addappid(1183700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183701, 1, "55cdc3a721df7c7fecd9b2170168eabad017c22005737c925f5b01d8f4292b96")
