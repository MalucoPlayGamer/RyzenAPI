-- Lua provided by SkyAPI 
-- Game: AppID 1183700
addappid(1183700)
addappid(1183701, 1, "55cdc3a721df7c7fecd9b2170168eabad017c22005737c925f5b01d8f4292b96")
