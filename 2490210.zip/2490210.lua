-- Lua provided by RyzenAPI
-- Game: Blitz Runner

-- MAIN APPLICATION
addappid(2490210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490211, 1, "c2b31f77b9453ea7a336ac062a1fd8a8402b18061ca0bac9b97d8c6fbe3272a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
