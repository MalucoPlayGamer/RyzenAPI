-- Lua provided by RyzenAPI
-- Game: Game: Blitz Runner

-- MAIN APPLICATION
addappid(2490210)
-- Game: addappid(2490210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490211, 1, "c2b31f77b9453ea7a336ac062a1fd8a8402b18061ca0bac9b97d8c6fbe3272a5")
