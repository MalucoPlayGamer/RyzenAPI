-- Lua provided by SkyAPI 
-- Game: Wild Wolf
addappid(749540)
addappid(749541, 1, "ab56482d75872208176f42276dbe260dfa3342ac23a59553bd93d9e0e5994170")
