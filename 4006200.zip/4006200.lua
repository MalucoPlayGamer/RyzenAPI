-- Lua provided by RyzenAPI
-- Game: Tileweaver

-- MAIN APPLICATION
addappid(4006200) -- Tileweaver

-- MAIN APP DEPOTS / PACKAGES
addappid(4006201, 1, "1ebec55a22a4cb8cce64d0c4419dbc3ad11b8f806fc5e90d7534180bd0c4c42b") -- Depot 4006201

