-- 4006200's Lua and Manifest Created by Hubcap Manifest
-- Tileweaver
-- Created: August 13, 2026 at 04:05:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4006200) -- Tileweaver
-- MAIN APP DEPOTS
addappid(4006201, 1, "1ebec55a22a4cb8cce64d0c4419dbc3ad11b8f806fc5e90d7534180bd0c4c42b") -- Depot 4006201
setManifestid(4006201, "8094553020922294195", 61372594)