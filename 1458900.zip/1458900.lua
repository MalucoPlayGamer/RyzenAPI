-- Lua provided by RyzenAPI
-- Game: 1458900

-- MAIN APPLICATION
addappid(1458900)
-- Game: addappid(1458900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458901, 1, "c121656466c266ddab65309c63fa5dc765b4729ced681b2170a07161f523cb8f")
addappid(1458903, 1, "b263623c0cf457ecb927dd4fee2af8e6b22efa433647eae8e58831ae56a12f3b")
