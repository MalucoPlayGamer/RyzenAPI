-- Lua provided by RyzenAPI
-- Game: 438300

-- MAIN APPLICATION
addappid(438300)
-- Game: addappid(438300)

-- MAIN APP DEPOTS / PACKAGES
addappid(438301, 1, "d47b1b23ab85a34b7abd3b35770e10282c104e501690decd2b95eca50aa9c732")
addappid(438302, 1, "4aeec75729f57af13e63fe7784a1b57f313f72bd5f272a94eaa1869e1839ef7b")
