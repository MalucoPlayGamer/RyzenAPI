-- Lua provided by RyzenAPI
-- Game: Game: Rescue Operation

-- MAIN APPLICATION
addappid(1593490)
-- Game: addappid(1593490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593491, 1, "ae0f343e52458b0991ed13cb52c5f9297ad4c191f94119e95973c3955a3b82a6")
