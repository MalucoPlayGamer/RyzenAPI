-- Lua provided by RyzenAPI
-- Game: FILL IT

-- MAIN APPLICATION
addappid(4835130) -- FILL IT

-- MAIN APP DEPOTS / PACKAGES
addappid(4835131, 1, "91ba2522d9f7abea77fc7d5bbdc2940270b73e608d02c607819fe4e1b9ce1f09") -- Depot 4835131

