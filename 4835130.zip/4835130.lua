-- 4835130's Lua and Manifest Created by Hubcap Manifest
-- FILL IT
-- Created: August 03, 2026 at 02:50:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4835130) -- FILL IT
-- MAIN APP DEPOTS
addappid(4835131, 1, "91ba2522d9f7abea77fc7d5bbdc2940270b73e608d02c607819fe4e1b9ce1f09") -- Depot 4835131
setManifestid(4835131, "5141910225291586776", 152766932)