-- Lua provided by RyzenAPI
-- Game: Game: Krunker

-- MAIN APPLICATION
addappid(1408720)
-- Game: addappid(1408720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408721, 1, "7defe92e4d68e6c93e16b0d3d75569daf223dcf177b365d280d6e0b7e22a1e7a")
addappid(1408722, 1, "3c6ee69c5a3e6a2a645e743d2b1683cb5b14fdd514a3b5c36c0338303e303e40")
addappid(1408723, 1, "c0b4c3aa13a814652e56d07e10f0d041e3641bf72e5f43ee5655ef9a6318fa47")
