-- Lua provided by RyzenAPI
-- Game: 3517040

-- MAIN APPLICATION
addappid(3517040)
-- Game: addappid(3517040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3517041, 1, "d5ab82c41eaab44b0f74c8cc50277870a80ee1a13a2fa8515619dd42ea98bc3a")
