-- Lua provided by RyzenAPI
-- Game: 2314570

-- MAIN APPLICATION
addappid(2314570)
-- Game: addappid(2314570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314571, 1, "5c8ad41778dd6e25b83ab027c04512cb7c04b48037e9a2718f30bf34a4c6c29a")
