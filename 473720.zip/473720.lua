-- Lua provided by RyzenAPI
-- Game: 473720

-- MAIN APPLICATION
addappid(473720)
-- Game: addappid(473720)

-- MAIN APP DEPOTS / PACKAGES
addappid(473721, 1, "287685584986ce98aeb4a7847e2e3104ba3950cdc35934422d410a20ef264eed")
