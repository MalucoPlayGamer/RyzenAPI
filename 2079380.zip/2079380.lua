-- Lua provided by SkyAPI 
-- Game: Old Retro Shooter
addappid(2079380)
addappid(2079381, 1, "48c96bfd1b3d6d348c9a7bdc26c0961b8787a08184308efa671f50cd7e0acaae")
