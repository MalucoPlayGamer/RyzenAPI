-- Lua provided by RyzenAPI
-- Game: Old Retro Shooter

-- MAIN APPLICATION
addappid(2079380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079381, 1, "48c96bfd1b3d6d348c9a7bdc26c0961b8787a08184308efa671f50cd7e0acaae")

