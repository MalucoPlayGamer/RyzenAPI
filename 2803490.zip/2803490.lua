-- 2803490's Lua and Manifest Created by Hubcap Manifest
-- Atomcraft
-- Created: July 23, 2026 at 09:10:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2803490) -- Atomcraft
-- MAIN APP DEPOTS
addappid(2803491, 1, "fd16ebfb5ff34a373679eba0a2c761e21f54f79ff3f0ffcc57f56f3f4e0b4458") -- Depot 2803491
setManifestid(2803491, "3456836800610500405", 412632259)