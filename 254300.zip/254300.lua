-- Lua provided by RyzenAPI
-- Game: Dofus

-- MAIN APPLICATION
addappid(254300)

-- MAIN APP DEPOTS / PACKAGES
addappid(254302,0,"c5e3d8cca1c66c9b79f22e91b2e39efd8b2cd0321378958f1a9a0ffe3148783d")
addappid(254303,0,"f248a454276224f542e4dd9e20c032b7bee59a1758435169013d9249e51be11b")
addappid(254304,0,"f5a3eccf18b5ba17cc5dddda5723ff07e57008e4c51261b25e4cd3213fef3096")
addappid(254305,0,"b86bffa98577318de14d241013bbce67c434ef06b595e34242518a87937d1684")
addappid(254306,0,"383044ee518deedc9cc372c30cd15085b0e79977567263d2364bb9745a555e03")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(552010)
addappid(552011)
addappid(553120)
addappid(849230)
