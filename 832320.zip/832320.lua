-- Lua provided by RyzenAPI
-- Game: Mighty Switch Force! Collection

-- MAIN APPLICATION
addappid(832320)

-- MAIN APP DEPOTS / PACKAGES
addappid(832321, 1, "95c13e4ec5f6daca3f98a7909f93f66beacc0f18c0aea729f7993b6f68ab68d1")

