-- Lua provided by RyzenAPI
-- Game: Courtyard Broomball

-- MAIN APPLICATION
addappid(592400)

-- MAIN APP DEPOTS / PACKAGES
addappid(592401,0,"4747fc6dd95a7cc230b066bb73213cf2344ace7a70b4900715507b37cdd33249")

