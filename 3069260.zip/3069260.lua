-- Lua provided by RyzenAPI 
-- Game: RMP: Role Music Player
addappid(3069260)
addappid(3069261, 1, "a9b1921cabc2a11130413fefdfa3956748d20ef2d42b24853c9efca766cc6756")
addappid(3559600, 0, "c98daa2936294dc861792a5d0404b434b73a3c5b457614a4cb0561c833b97941")
