-- Lua provided by RyzenAPI
-- Game: 771420

-- MAIN APPLICATION
addappid(771420)
-- Game: addappid(771420)

-- MAIN APP DEPOTS / PACKAGES
addappid(771422,0,"077b12ccf694462257f617e582daa0c7088617d127e2ea07c7adac6334bf5c31")
