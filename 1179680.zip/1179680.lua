-- Lua provided by RyzenAPI
-- Game: AppID 1179680

-- MAIN APPLICATION
addappid(1179680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179681, 1, "88e62c47104476f9a7f4b652a769128c2a0f6cd15ce79430ba732bf894d30d4e")
addappid(1179682, 1, "7eb85208995648d57a571a2bfe88557282fc1af5c03871e79f34076695b99350")
addappid(1179684, 1, "02e39c26bdebf4adb9226ab135b6ce49e1333fb25b9877c64009ca5d28eb1fbb")
addappid(1179685, 1, "f36fcc6f9d0f7c08c8bb6dc8db2465f05cea6b3aa64c8fbd2bfe23b596eeacdd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
