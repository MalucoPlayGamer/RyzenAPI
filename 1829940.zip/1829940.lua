-- Lua provided by RyzenAPI
-- Game: Downfall of Krynto

-- MAIN APPLICATION
addappid(1829940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829941, 1, "fd07c21220f03b346dc979863bfa7bcc7e1de9dcacc9f024fa44c762aa2106ca")
