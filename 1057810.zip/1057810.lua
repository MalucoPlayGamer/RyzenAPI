-- 1057810's Lua and Manifest Created by Hubcap Manifest
-- Wolfenstein: Youngblood Deutsche Version
-- Created: October 02, 2025 at 09:13:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1057810) -- Wolfenstein: Youngblood Deutsche Version
-- MAIN APP DEPOTS
addappid(1057811, 1, "7d8b46b2bd4970ae9dabc3a3a990f49330f8f34811f12fb3ee98a3a64c116adc") -- Game Resources
setManifestid(1057811, "6820061605114712160", 28517853407)
addappid(1057812, 1, "ed874035763a08c1f3cd88ce8e7247305040414ac0631662cfc5da3efa761631") -- Lightmaps
setManifestid(1057812, "465173436051315716", 13618981120)
addappid(1057813, 1, "b731eaba4a5b116ba2e551baa2fc24671559a87809864a1e7f74db734e0eb0ba") -- Soundbanks (German)
setManifestid(1057813, "1631123797454483891", 132)
addappid(1057814, 1, "b47f4a69cdc1800b6a8302bf9b7b2c21b3270e96e820e9d7f56b5f4f9a72ee98") -- Binary
setManifestid(1057814, "6454762572812340534", 80081560)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1057840) -- Wolfenstein Youngblood Deutsche Version - Legacy Pack
addappid(1057841) -- Wolfenstein Youngblood Deutsche Version - Deluxe Edition Contents
addappid(1068000) -- Wolfenstein Youngblood Deutsche Version - Gold Bars