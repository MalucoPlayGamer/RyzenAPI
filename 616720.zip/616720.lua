-- Lua provided by RyzenAPI
-- Game: Game: AppID 616720

-- MAIN APPLICATION
addappid(616720)
addappid(1350680)
-- Game: addappid(616720)

-- MAIN APP DEPOTS / PACKAGES
addappid(616721, 1, "34f7b93e924c5d236bba8833fd04d9489e5a55fc76bda6992d5e65eb4cfce6c3")
addappid(616722, 1, "9e382fdb223d32adfcb889f34734eb3e9d6097b029872159427c233d04928ff3")
