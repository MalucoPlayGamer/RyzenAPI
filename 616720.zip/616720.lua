-- Lua provided by RyzenAPI
-- Game: Live2DViewerEX

-- MAIN APPLICATION
addappid(616720)
addappid(641880)
addappid(642270)
addappid(652840)
addappid(1350680)
addappid(1732010)

-- MAIN APP DEPOTS / PACKAGES
addappid(616720,0,"99529225ccd19a436d52b19894a9a5d24f0559ec79e9384570a58f11d9871727")
addappid(616721,0,"34f7b93e924c5d236bba8833fd04d9489e5a55fc76bda6992d5e65eb4cfce6c3")
addappid(616722,0,"9e382fdb223d32adfcb889f34734eb3e9d6097b029872159427c233d04928ff3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
