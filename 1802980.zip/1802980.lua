-- Lua provided by RyzenAPI
-- Game: Yihongyuan

-- MAIN APPLICATION
addappid(1802980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802981, 1, "ce79d48911d88af9e08e9e2ac469e6a7d51ef3b8c7f980846fc70fa3544f65cb")
addappid(2247300, 0, "c8c394dd9b6596ad31644470cf6dbbd5084890ea500050059d7cdcb2551dd2c2")

