-- Lua provided by RyzenAPI
-- Game: Ashes of the Singularity: Escalation - Soundtrack DLC

-- MAIN APPLICATION
addappid(520641)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224400,0,"a1bb19c1e4647167dafd61cbb695d5509b5a7900259f9eecc3bf02e9aa49bd7a")
addappid(1224401,0,"acde6265534f4a71fec35397d217b88131fa5c60cae55ed8201e1eb7bfc83637")

