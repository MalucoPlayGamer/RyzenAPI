-- Lua provided by RyzenAPI
-- Game: New York Bus Simulator

-- MAIN APPLICATION
addappid(446480)

-- MAIN APP DEPOTS / PACKAGES
addappid(446481, 1, "166c34c7516156b0bc4684cbca6c4b1783930d5102fb8c9c7d4e8c787c6f4579")
