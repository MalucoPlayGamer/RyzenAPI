-- Lua provided by RyzenAPI
-- Game: New York Bus Simulator

-- MAIN APPLICATION
addappid(446480)

-- MAIN APP DEPOTS / PACKAGES
addappid(446481, 1, "166c34c7516156b0bc4684cbca6c4b1783930d5102fb8c9c7d4e8c787c6f4579")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
