-- Lua provided by RyzenAPI
-- Game: Insider Threat

-- MAIN APPLICATION
addappid(2796460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2796461, 1, "0db0821c10963375b4ba8675b13869de1bbb551d98875e29f030a435219e43fe")

