-- Lua provided by RyzenAPI
-- Game: Insider Threat

-- MAIN APPLICATION
addappid(2796460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796461, 1, "0db0821c10963375b4ba8675b13869de1bbb551d98875e29f030a435219e43fe")
