-- Lua provided by RyzenAPI
-- Game: The Centennial Case: A Shijima Story 4K Video Pack

-- MAIN APPLICATION
addappid(2012970)
-- Game: addappid(2012970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012970,0,"fa8c048e27d1d258097fe7ac270f82920e9d6049c154575d5431693981f88d49")
