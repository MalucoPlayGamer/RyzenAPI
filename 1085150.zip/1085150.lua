-- Lua provided by RyzenAPI
-- Game: Golf Defied

-- MAIN APPLICATION
addappid(1085150)
-- Game: addappid(1085150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085151, 1, "706c01207b1e34f384949a9e0e3276122e28ca193c176e7da11cc3285d5849a4")
