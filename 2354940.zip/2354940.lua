-- Lua provided by RyzenAPI
-- Game: Catch & Cook: Fishing Adventure

-- MAIN APPLICATION
addappid(2354940)
-- Game: addappid(2354940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354941, 1, "0a2920cbf450bc17501b57c59802049a7b474e0ad17989d87ad393b882291f0e")
