-- Lua provided by SkyAPI 
-- Game: Nightwalker
addappid(1263700)
addappid(1263701, 1, "96237475fae0a0bafcc32295058b7a46e19d6ca1cd4e2d8dc1fb117011eb8f4c")
