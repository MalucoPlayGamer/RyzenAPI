-- Lua provided by RyzenAPI
-- Game: Paint Puzzle Quest

-- MAIN APPLICATION
addappid(3195070)
-- Game: addappid(3195070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195071, 1, "93433a9fe721b1f83d34ad2bc3decd7e0aa54436746c53c53132f1fc3d5348af")
