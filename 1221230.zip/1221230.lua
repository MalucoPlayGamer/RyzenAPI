-- Lua provided by RyzenAPI
-- Game: Derange

-- MAIN APPLICATION
addappid(1221230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221231, 1, "01570f81907ea45d3f1ba47fd28709f78fced9334d8223df02f3aec421c8d1af")

