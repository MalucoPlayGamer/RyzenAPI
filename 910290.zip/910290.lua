-- Lua provided by RyzenAPI
-- Game: 910290

-- MAIN APPLICATION
addappid(910290)
-- Game: addappid(910290)

-- MAIN APP DEPOTS / PACKAGES
addappid(910291, 1, "8c47ce0149266c53c3e5e12390767427e981add33650a50edcf012447d978dba")
