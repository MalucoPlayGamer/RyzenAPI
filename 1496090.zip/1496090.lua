-- Lua provided by RyzenAPI
-- Game: Urban Street Fighter

-- MAIN APPLICATION
addappid(1496090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496091,0,"7e4a573251a29bf6d9ed9248cccee09e18217c9cc4ce412375f0b6f826585d53")

