-- Lua provided by RyzenAPI
-- Game: 893720

-- MAIN APPLICATION
addappid(893720)
-- Game: addappid(893720)

-- MAIN APP DEPOTS / PACKAGES
addappid(893721, 1, "f447239b909809ebe6119d4de31f2a7be07a8faa6f714f2738c67ea5733d516b")
