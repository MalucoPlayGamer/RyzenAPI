-- Lua provided by RyzenAPI
-- Game: Game: Rogue Wizards

-- MAIN APPLICATION
addappid(392260)
-- Game: addappid(392260)

-- MAIN APP DEPOTS / PACKAGES
addappid(392261, 1, "91b28216fb64b17827ef760f1ddc5df8977732ef4781801d8f4b72e624ca7c44")
addappid(392262, 1, "eb6f82dfd0a5805f433b09e8a362a289282ff32fea83c30918171addc9028d8e")
