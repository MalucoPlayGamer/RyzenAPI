-- Lua provided by RyzenAPI
-- Game: 793230

-- MAIN APPLICATION
addappid(793230)
-- Game: addappid(793230)

-- MAIN APP DEPOTS / PACKAGES
addappid(793231, 1, "187a40408532bee6e5dc6c47fa23a275f3eaf17a57e851ca89777054ea255eb7")
