-- Lua provided by RyzenAPI
-- Game: The House in Fata Morgana

-- MAIN APPLICATION
addappid(303310)

-- MAIN APP DEPOTS / PACKAGES
addappid(303311, 1, "f049ad455996455a675a2369ab1d7acdf1caf7c449acaa6c84624814ceb6a109")
addappid(919340, 0, "0c0026799b6a54efad320ac12a1a462f336d43e900d2a5d5caf9e35eaad160a1")
addappid(2525730, 0, "fcb710faa1fc505e00b019e4ce49afe3ca40739e10daf92ff3ab574fddce5557")

