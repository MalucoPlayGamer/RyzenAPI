-- Lua provided by RyzenAPI
-- Game: Moo Who?

-- MAIN APPLICATION
addappid(4948000)

-- MAIN APP DEPOTS / PACKAGES
addappid(4948001, 1, "030610fee4a0d13bbc99e06c4e90d278d6c68c3634a56305e2930c8883c9a63a")

