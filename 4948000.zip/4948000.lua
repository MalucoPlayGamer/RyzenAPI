-- Generated with Luie @ https://lua.tools/
-- 4948000 - Moo Who?
-- Generated 2026-08-22 04:48:40 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4948000)

-- Main Depots
addappid(4948001, 1, "030610fee4a0d13bbc99e06c4e90d278d6c68c3634a56305e2930c8883c9a63a")
setManifestid(4948001, "7971484691438762714", 2034696443)
