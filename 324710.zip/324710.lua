-- Lua provided by RyzenAPI
-- Game: AppID 324710

-- MAIN APPLICATION
addappid(324710)

-- MAIN APP DEPOTS / PACKAGES
addappid(324711, 1, "b316f8347fd6040b4bc6ca74c431f85ecc79b29bd1e8612987d66bc67f232c99")
addappid(324712, 1, "818390bfd0ea2acebef5c5b1197d7226f3096361f8aa50256c26095a6e1f1493")
addappid(324713, 1, "2570378f2ad484d0a570d8cb32fe7971b26598b978e5ccf70f7cbe61c34f91b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
