-- Lua provided by RyzenAPI
-- Game: Game: AppID 633350

-- MAIN APPLICATION
addappid(633350)
-- Game: addappid(633350)

-- MAIN APP DEPOTS / PACKAGES
addappid(633351, 1, "dfd829070da61b5224e977955e03c3f16dc4b06c909966433ae1cc4b8a1719fd")
