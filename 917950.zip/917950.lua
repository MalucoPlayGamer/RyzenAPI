-- Lua provided by RyzenAPI
-- Game: Game: Vellum

-- MAIN APPLICATION
addappid(917950)
-- Game: addappid(917950)

-- MAIN APP DEPOTS / PACKAGES
addappid(917951, 1, "782dc04cd840b972d5f38b24f8e6190b7935018e7dfee5516cbe431927c12af0")
