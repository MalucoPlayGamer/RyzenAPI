-- Lua provided by RyzenAPI
-- Game: Glamour Riot

-- MAIN APPLICATION
addappid(3557370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3557371, 1, "3594ed5f9065f294c8b05201147626f87fd81c07d438b70567beafdf496252c8")
