-- Lua provided by RyzenAPI
-- Game: MOBA Esport Manager 25 Playtest

-- MAIN APPLICATION
addappid(3113320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3113321, 1, "8422064a8843f3a011545cb539e5eabf2c69e3081865a791770ae7a1870d6f21")
