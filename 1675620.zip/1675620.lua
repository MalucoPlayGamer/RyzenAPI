-- Lua provided by RyzenAPI
-- Game: Last Light

-- MAIN APPLICATION
addappid(1675620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675621, 1, "40f120d10c72414b86ad36d95b058c4a99ac02ff9d8f34983b4ebf7941fa2a7f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1685670)
addappid(1827070)
