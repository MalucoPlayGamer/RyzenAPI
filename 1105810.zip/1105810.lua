-- Lua provided by RyzenAPI
-- Game: Onset

-- MAIN APPLICATION
addappid(1105810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1105811, 1, "12f6dcaa07ed6c9d6b2bc4d013b977263a32b36ca2bcbe22502b192a250f2f83")
