-- Lua provided by RyzenAPI
-- Game: Game: AppID 1105810

-- MAIN APPLICATION
addappid(1105810)
-- Game: addappid(1105810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105811, 1, "12f6dcaa07ed6c9d6b2bc4d013b977263a32b36ca2bcbe22502b192a250f2f83")
