-- Lua provided by SkyAPI 
-- Game: AppID 1105810
addappid(1105810)
addappid(1105811, 1, "12f6dcaa07ed6c9d6b2bc4d013b977263a32b36ca2bcbe22502b192a250f2f83")
