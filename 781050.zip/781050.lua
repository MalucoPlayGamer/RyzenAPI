-- Lua provided by RyzenAPI
-- Game: addappid(781050)

-- MAIN APPLICATION
addappid(781050)

-- MAIN APP DEPOTS / PACKAGES
addappid(781051, 1, "c7effca1a425d6cf1dc1f8269c8ce6749b56cb578c1546a1b1b08c052f6f7606")
