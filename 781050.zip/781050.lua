-- Lua provided by SkyAPI 
-- Game: Evie
addappid(781050)
addappid(781051, 1, "c7effca1a425d6cf1dc1f8269c8ce6749b56cb578c1546a1b1b08c052f6f7606")
