-- Lua provided by RyzenAPI
-- Game: PASKA BATTLE STYLE!

-- MAIN APPLICATION
addappid(979760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(979761, 1, "afadfd6e0e3c9922124886ee2dc63b3ef7ec80bc83783842987cf684ec5a7535")

