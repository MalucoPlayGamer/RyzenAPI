-- Lua provided by SkyAPI 
-- Game: AppID 979760
addappid(979760)
addappid(979761, 1, "afadfd6e0e3c9922124886ee2dc63b3ef7ec80bc83783842987cf684ec5a7535")
