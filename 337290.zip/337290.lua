-- Lua provided by RyzenAPI
-- Game: Still Not Dead

-- MAIN APPLICATION
addappid(337290)

-- MAIN APP DEPOTS / PACKAGES
addappid(337291, 1, "a030ce7291d39d0e2ab3f2a780a099d41cb0f03d2489f6e7373de533f55c194f")
