-- Lua provided by RyzenAPI 
-- Game: Projekt: Passion - Season 2
addappid(2863160)
addappid(2863161, 1, "e97eb5b66a535f88819a709ca5238ca540aabd3f076c6b1169429a9c9190c4d3")
addappid(3589570, 0, "976849195b5d6b2efe1f0a139042c4588a426385c46442bd66ad94c2575fba83")
