-- Lua provided by RyzenAPI
-- Game: Clair Obscur: Expedition 33 – Original Soundtrack

-- MAIN APPLICATION
addappid(3405480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3405510,0,"d05c5a4e1666b64375d849a60b8f3694548fd5f756513928e1458c033101b848")
addappid(3405511,0,"8cb3c5d263faf7383c63bcb27fb60e3f0a4de6b3a8c8f1fac33c9d12f41848ee")

