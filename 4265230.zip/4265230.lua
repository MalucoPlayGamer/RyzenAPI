-- Lua provided by RyzenAPI
-- Game: Immortal Clan: Grandmastery

-- MAIN APPLICATION
addappid(4265230)
