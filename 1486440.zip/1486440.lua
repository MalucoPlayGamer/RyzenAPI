-- Lua provided by RyzenAPI
-- Game: Graze Counter GM

-- MAIN APPLICATION
addappid(1486440)
-- Game: addappid(1486440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486441, 1, "993326c25114ba124a1655e89e06e7ccacc74135ab72678daa895a1e2d31f7ae")
