-- Lua provided by RyzenAPI
-- Game: Київ: з ранку до світанку з Lenovo Explorer

-- MAIN APPLICATION
addappid(926720)

-- MAIN APP DEPOTS / PACKAGES
addappid(926721, 1, "b33613894ae7e5234d83d5b1e633b05f55d4397fb14752a728283c8eba8171fa")
addappid(926722, 1, "851b419f9c16f1cb1e983ca989673332a671585374287cb44b14abb044786817")
addappid(926723, 1, "7737975b30923e86d6f70e1ed005abd640aa9efff473e905307eb6e9ef7fc745")

