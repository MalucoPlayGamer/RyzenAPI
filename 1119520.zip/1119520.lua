-- Lua provided by RyzenAPI
-- Game: Game: HITOTSU NO MORI

-- MAIN APPLICATION
addappid(1119520)
-- Game: addappid(1119520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119521, 1, "8cacc6a9ab798139431cefcf4f310d8d8b65463881c9b9ea2d1b5d596ffb0c59")
