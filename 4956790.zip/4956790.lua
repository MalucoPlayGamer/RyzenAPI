-- Lua provided by RyzenAPI
-- Game: Built From Nothing

-- MAIN APPLICATION
addappid(4956790) -- Built From Nothing
-- addappid(4956793) -- Depot 4956793 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(4956791, 1, "f1e129d11d1166368a80f444c9eac8a932e2b02be8a78537576abb89b38aa527") -- Depot 4956791

