-- 4956790's Lua and Manifest Created by Hubcap Manifest
-- Built From Nothing
-- Created: August 12, 2026 at 00:07:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4956790) -- Built From Nothing
-- MAIN APP DEPOTS
addappid(4956791, 1, "f1e129d11d1166368a80f444c9eac8a932e2b02be8a78537576abb89b38aa527") -- Depot 4956791
setManifestid(4956791, "7154561016572033014", 236796166)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4956793) -- Depot 4956793 (empty depot)