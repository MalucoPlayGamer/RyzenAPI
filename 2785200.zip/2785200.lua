-- Lua provided by RyzenAPI
-- Game: Unknown Tapes

-- MAIN APPLICATION
addappid(2785200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785201, 1, "523d5e0049cd57f34ec10424505a647df1107a7cb42fdc7aec2e60c9d7e613c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
