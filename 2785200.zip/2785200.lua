-- Lua provided by RyzenAPI
-- Game: Unknown Tapes

-- MAIN APPLICATION
addappid(2785200)
-- Game: addappid(2785200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2785201, 1, "523d5e0049cd57f34ec10424505a647df1107a7cb42fdc7aec2e60c9d7e613c3")
