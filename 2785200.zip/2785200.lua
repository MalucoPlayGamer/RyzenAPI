-- Lua provided by SkyAPI 
-- Game: Unknown Tapes
addappid(2785200)
addappid(2785201, 1, "523d5e0049cd57f34ec10424505a647df1107a7cb42fdc7aec2e60c9d7e613c3")
