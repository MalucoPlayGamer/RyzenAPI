-- Lua provided by RyzenAPI
-- Game: Hidden World 4 Top-Down 3D

-- MAIN APPLICATION
addappid(2349010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349011, 1, "f6b811e42586c430a3f42c26253691ca7ba31a410ca269eed442306e9f7f0bd1")
