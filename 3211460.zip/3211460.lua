-- Lua provided by RyzenAPI
-- Game: ABYSS SEEKERーーWhat Do You See Deep in The Abyss

-- MAIN APPLICATION
addappid(3211460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3211461, 1, "53dadb659e0c0bfb9e51d1808ecaa8883051d33420e73a7619caa7638fe52a2b")

