-- Lua provided by RyzenAPI
-- Game: 100 Radioactive Cats

-- MAIN APPLICATION
addappid(4212340)
addappid(4212840)
addappid(4212850)

