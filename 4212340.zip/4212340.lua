-- Lua provided by RyzenAPI
-- Game: 100 Radioactive Cats

-- MAIN APPLICATION
addappid(4212340)
