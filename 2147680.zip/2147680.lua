-- Lua provided by RyzenAPI 
-- Game: Card Survival: Tropical Island - The First Days
addappid(2147680)
addappid(2147681, 1, "8b36eb6a2976db4d41e1f6e25eabcde0724fef24f0b486539c9467126808afbe")
addappid(2147682, 1, "23a0d6066be8713f57fae275230eb23f6366de2f86f0aed5c21d214a5b6a9724")
