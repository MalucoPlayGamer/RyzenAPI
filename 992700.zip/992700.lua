-- Lua provided by RyzenAPI
-- Game: Lighter

-- MAIN APPLICATION
addappid(992700)
-- Game: addappid(992700)

-- MAIN APP DEPOTS / PACKAGES
addappid(992701, 1, "acf9bb3503ed570dd7fee43c026552fa3bf50a9ef3bf1a3d28dffba411fb08c9")
addappid(1026640, 0, "ce921ee164788f0039b2e9c0071685b7d80d91f5ef5a54029333341ac468125f")
