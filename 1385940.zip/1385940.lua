-- Lua provided by RyzenAPI
-- Game: 1385940

-- MAIN APPLICATION
addappid(1385940)
-- Game: addappid(1385940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385941, 1, "993643d8600cede876d6dc1c31cefba508f7458aaf62dac63bcfe1ad7c9e6aac")
