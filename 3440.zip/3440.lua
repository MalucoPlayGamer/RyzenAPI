-- Lua provided by RyzenAPI
-- Game: Rocket Mania Deluxe

-- MAIN APPLICATION
addappid(3440)
-- Game: addappid(3440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441, 1, "767589cc85bd91df69cf16ad91caa554228d6fff599bbf0eae82320a6d5aef58")
