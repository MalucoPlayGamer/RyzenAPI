-- Lua provided by RyzenAPI 
-- Game: GirlHub - adult puzzle game
addappid(1806110)
addappid(1806111, 1, "9d5fe4a8c212d126d07c996b6c3eeeea12ea57a568e23ba644403ef7c6091ac8")
