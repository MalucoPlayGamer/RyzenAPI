-- Lua provided by RyzenAPI
-- Game: 809360

-- MAIN APPLICATION
addappid(809360)
-- Game: addappid(809360)

-- MAIN APP DEPOTS / PACKAGES
addappid(809361, 1, "d041c2520d498dccfbf7946a08970ab7993e29787ff367233331d6e1d2fb4a1d")
