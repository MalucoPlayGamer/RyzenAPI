-- Lua provided by RyzenAPI
-- Game: Cosmic Snake 8473/3671

-- MAIN APPLICATION
addappid(809360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(809361, 1, "d041c2520d498dccfbf7946a08970ab7993e29787ff367233331d6e1d2fb4a1d")

