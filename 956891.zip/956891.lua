-- Lua provided by RyzenAPI
-- Game: Ma Dai - Officer Ticket / 馬岱使用券

-- MAIN APPLICATION
addappid(956891)

-- MAIN APP DEPOTS / PACKAGES
addappid(956891,0,"68afe4e6c113be39cd547505876351b58507de7543f1ef86fabe88274f47d74d")

