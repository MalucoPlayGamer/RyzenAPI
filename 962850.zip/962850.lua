-- Lua provided by RyzenAPI
-- Game: AppID 962850

-- MAIN APPLICATION
addappid(962850)

-- MAIN APP DEPOTS / PACKAGES
addappid(962851, 1, "c06950b3e1c1e6d3b8b79657f8a14be620dff9c5b2bf565dda1260203ef17e9b")
