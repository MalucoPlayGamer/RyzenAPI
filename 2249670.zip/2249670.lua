-- Lua provided by RyzenAPI
-- Game: addappid(2249670)

-- MAIN APPLICATION
addappid(2249670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249670,0,"ba19afd01a4ba4c1fa503aae33bb5287a1427806032f3f9541c587060e0aaa88")
