-- Lua provided by RyzenAPI
-- Game: Basement

-- MAIN APPLICATION
addappid(340150)
addappid(1201030)

-- MAIN APP DEPOTS / PACKAGES
addappid(340151, 1, "2f5f95b2d1d728a9e21dcebc93addd3491ae1ae97c66c06d1d13063b7c02c8c5")
addappid(340152, 1, "53386611abce2da8bed3ac41cc043abc706408fa6318f00e70d270585c9ed42e")
addappid(340153, 1, "6cf7e42f35d3e334c8c5c8299c7492db99b01a68b1482716ddd730ab7b45baad")
addappid(340154, 1, "5125e5d9f5026207a682ff19352e583eb4e9095f068f274d137cba864fcb42a8")

