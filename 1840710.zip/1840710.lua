-- Lua provided by RyzenAPI 
-- Game: These Doomed Isles
addappid(1840710)
addappid(1840711, 1, "0d711e432dc694b1094355fa6689ebffb840e98c9e8351f36a3fd2ca95740a5e")
