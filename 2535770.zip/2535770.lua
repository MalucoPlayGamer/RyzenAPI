-- Lua provided by RyzenAPI 
-- Game: 黄毛漂流记
addappid(2535770)
addappid(2535771, 1, "e63408e639d3e5bac5344c02be0a9a0b2afdff7fbcc07353212f91fbf0efab01")
addappid(2767190, 0, "f00d963fb6b766112946037767cecf16d02ffc74076949ec7439406dc6049f0f")
