-- Lua provided by RyzenAPI
-- Game: Frog & Roll

-- MAIN APPLICATION
addappid(4355750) -- Frog & Roll

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4355751, 1, "e850b97519267af7a4ef0efcae60538137f26cfe1ff0711e61f1424bd03241dd") -- Depot 4355751

