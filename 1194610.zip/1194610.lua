-- Lua provided by RyzenAPI
-- Game: Game: Knights of the Temple: Infernal Crusade

-- MAIN APPLICATION
addappid(1194610)
-- Game: addappid(1194610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194611, 1, "02723370984598477fbe6cf750e2b1e5577f31fffdeda9592344fedb8e9c167e")
