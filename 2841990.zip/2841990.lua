-- Lua provided by RyzenAPI
-- Game: 2841990

-- MAIN APPLICATION
addappid(2841990)
-- Game: addappid(2841990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2841991, 1, "f23b1daed0ac12d6a795aa5c7fc15d18d63da7de4b2857e3228f6ad993fbd87d")
