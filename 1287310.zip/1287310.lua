-- Lua provided by SkyAPI 
-- Game: AppID 1287310
addappid(1287310)
addappid(1287311, 1, "4bf6e82b5d63f74bc8c2194ef25a4d8cca27f0d65f21f94427c23806ad78375a")
