-- Lua provided by RyzenAPI
-- Game: Game: AppID 1072000

-- MAIN APPLICATION
addappid(1072000)
-- Game: addappid(1072000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072001, 1, "2b9da332d04498acb8bb76dbc27c6a937f050307d793497bc8adac6d5565724d")
