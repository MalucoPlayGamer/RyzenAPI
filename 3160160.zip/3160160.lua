-- Lua provided by RyzenAPI
-- Game: Six-Ear Macaque: Awakening

-- MAIN APPLICATION
addappid(3160160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3160161, 1, "8c30dc66c5bf6a09a789d02bf09fb0fc36f73c35e07a83e506c6e0e1b1c2a4f5")

