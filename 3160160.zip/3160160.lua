-- Lua provided by SkyAPI 
-- Game: Six-Ear Macaque: Awakening
addappid(3160160)
addappid(3160161, 1, "8c30dc66c5bf6a09a789d02bf09fb0fc36f73c35e07a83e506c6e0e1b1c2a4f5")
