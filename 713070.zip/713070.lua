-- Lua provided by RyzenAPI
-- Game: Pray for Death

-- MAIN APPLICATION
addappid(713070)

-- MAIN APP DEPOTS / PACKAGES
addappid(713071, 1, "f3a2f33d17d253b934f0e86f101c4647118bf4e80ffc25c2e8cd5d7bce0ada36")

