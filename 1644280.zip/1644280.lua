-- Lua provided by RyzenAPI
-- Game: The Jewel of Monostructure

-- MAIN APPLICATION
addappid(1644280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644281, 1, "23ac9112eb95555e56338e0558388c33e2c86b93b350186c17988c7d1dcc1b66")
