-- Lua provided by RyzenAPI
-- Game: Original soundtrack of Koi Musubi

-- MAIN APPLICATION
addappid(605030)

-- MAIN APP DEPOTS / PACKAGES
addappid(605030,0,"391550f9965e01ff55ea5d44e296c978de8ed585068a22e7362722feb641ca5b")
