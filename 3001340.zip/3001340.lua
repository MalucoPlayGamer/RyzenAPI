-- Lua provided by SkyAPI 
-- Game: ▼スライム娘は人間と友達になりたいようだ+
addappid(3001340)
addappid(3001341, 1, "8877cced9b0e7f2be6b9cdf98a38346c28824e36c8446355df57b9edc2bfd32a")
