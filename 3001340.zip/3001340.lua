-- Lua provided by RyzenAPI
-- Game: ▼スライム娘は人間と友達になりたいようだ+

-- MAIN APPLICATION
addappid(3001340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001341, 1, "8877cced9b0e7f2be6b9cdf98a38346c28824e36c8446355df57b9edc2bfd32a")

