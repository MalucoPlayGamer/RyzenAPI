-- Lua provided by RyzenAPI
-- Game: addappid(678010)

-- MAIN APPLICATION
addappid(678010)

-- MAIN APP DEPOTS / PACKAGES
addappid(678011, 1, "1c6e3e8e2ccc5efb80045d738e4868b2e81a561409b51b61d0aca99c1ee800ed")
