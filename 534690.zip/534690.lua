-- Lua provided by RyzenAPI
-- Game: AppID 534690

-- MAIN APPLICATION
addappid(534690)

-- MAIN APP DEPOTS / PACKAGES
addappid(534691, 1, "76dd22ccdb6b2241260f0314a80b3e0a69cdbdfcf0fe6ff69d568f1519567923")
