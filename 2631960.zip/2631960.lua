-- Lua provided by RyzenAPI
-- Game: Game: 14 Minesweeper Variants 2

-- MAIN APPLICATION
addappid(2631960)
-- Game: addappid(2631960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631961, 1, "c267129dc5245007be49c81d8c69d7291f7dedd482cf95dd2aeb40b7072f3abf")
addappid(2631962, 1, "56d24db7ace671986c83dea4fd611f14b508a3bdc9cfafd2701bd39b5a32578e")
