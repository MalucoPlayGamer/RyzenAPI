-- Lua provided by RyzenAPI
-- Game: Crescent Quest

-- MAIN APPLICATION
addappid(2421510)
-- Game: addappid(2421510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421511, 1, "f3728c3b05f8b26648b84187c0eccb67706f9629b4180994a8402e75e2808f49")
