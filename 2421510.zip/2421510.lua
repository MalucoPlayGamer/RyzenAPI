-- Lua provided by RyzenAPI
-- Game: Crescent Quest

-- MAIN APPLICATION
addappid(2421510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2421511, 1, "f3728c3b05f8b26648b84187c0eccb67706f9629b4180994a8402e75e2808f49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2648680)
addappid(2648690)
addappid(4019110)
