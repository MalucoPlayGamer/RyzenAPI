-- Lua provided by RyzenAPI
-- Game: Smutty Scrolls

-- MAIN APPLICATION
addappid(885510)

-- MAIN APP DEPOTS / PACKAGES
addappid(885511, 1, "4e7da215512ddf537cc43bdc42f5db2ae14cb6b71728d67f90be293395d7e74c")

