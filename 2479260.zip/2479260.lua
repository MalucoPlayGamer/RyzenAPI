-- Lua provided by RyzenAPI
-- Game: AppID 2479260

-- MAIN APPLICATION
addappid(2479260)
-- Game: addappid(2479260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479261, 1, "6bf8b819db2c035af8bc21a6dda923721fb94454af058cb5d8c85abed18b532f")
