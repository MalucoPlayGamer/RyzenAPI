-- Lua provided by RyzenAPI
-- Game: 2011930

-- MAIN APPLICATION
addappid(2011930)
-- Game: addappid(2011930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011931, 1, "e640096e2c8664efea24224581b665bd3f6cfad4d51f132e028624c2fa48c176")
