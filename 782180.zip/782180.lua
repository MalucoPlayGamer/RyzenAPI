-- Lua provided by RyzenAPI
-- Game: The way to defeat the Archfiend / 打倒魔王的方法

-- MAIN APPLICATION
addappid(782180)
-- Game: addappid(782180)

-- MAIN APP DEPOTS / PACKAGES
addappid(782181, 1, "50c55e6f2687b00278c8565765b8e4d9c30bd67f1c2669cbf885ae402fe9eda8")
addappid(782183, 1, "01c85dfdae528d4472311a1ca7bc7dbbed6471afff37897a43f58dcdfd8ae89e")
