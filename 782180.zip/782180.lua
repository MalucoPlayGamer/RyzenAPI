-- Lua provided by RyzenAPI
-- Game: The way to defeat the Archfiend / 打倒魔王的方法

-- MAIN APPLICATION
addappid(782180)

-- MAIN APP DEPOTS / PACKAGES
addappid(782181, 1, "50c55e6f2687b00278c8565765b8e4d9c30bd67f1c2669cbf885ae402fe9eda8")
addappid(782183, 1, "01c85dfdae528d4472311a1ca7bc7dbbed6471afff37897a43f58dcdfd8ae89e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
