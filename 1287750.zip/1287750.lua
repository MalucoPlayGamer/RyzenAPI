-- Lua provided by RyzenAPI
-- Game: RC Flight Simulator 2020 VR

-- MAIN APPLICATION
addappid(1287750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287751, 1, "6179e0093e5bbfd17ba26e99c374be127ee5f66175d1a79103fd65fa65fbec3e")

