-- Lua provided by SkyAPI 
-- Game: The Wisbey Mystery
addappid(575960)
addappid(575961, 1, "4fe583d1869080c84b1c81abffd744241b0e36435a6664d5f364841986f1e532")
addappid(575962, 1, "518988361222162e334464c9b9981357f74e97a757b77fc28ceedb32b0414c67")
