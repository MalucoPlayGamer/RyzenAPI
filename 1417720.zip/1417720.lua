-- Lua provided by RyzenAPI
-- Game: 1417720

-- MAIN APPLICATION
addappid(1417720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417722,0,"2a68f67fd08b2f4067fea6e3f03cf7afd60a255bacd6ec2cd829e5ad1b3b5883")

