-- Lua provided by RyzenAPI
-- Game: Castle Flipper

-- MAIN APPLICATION
addappid(944250)

-- MAIN APP DEPOTS / PACKAGES
addappid(944251, 1, "848a0fe49196cc5800b399f3839cda022212a24c9ecacf86c3b084e91d04930d")

