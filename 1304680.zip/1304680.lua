-- Lua provided by RyzenAPI
-- Game: Game: Voidigo

-- MAIN APPLICATION
addappid(1304680)
-- Game: addappid(1304680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304681, 1, "d52a70b62a1a587192af6f5fc216f073dd656cc32be413ad0a430f52961a3daf")
