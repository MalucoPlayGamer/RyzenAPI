-- Lua provided by RyzenAPI
-- Game: Voidigo

-- MAIN APPLICATION
addappid(1304680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1304681, 1, "d52a70b62a1a587192af6f5fc216f073dd656cc32be413ad0a430f52961a3daf")

