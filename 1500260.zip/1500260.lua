-- Lua provided by RyzenAPI
-- Game: Game: Desert Mystery

-- MAIN APPLICATION
addappid(1500260)
-- Game: addappid(1500260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500261, 1, "d865b8f12927e3e3801cdae6b8c244c2445e33dce718e6ac5ed8807aff4a6ae5")
