-- Lua provided by RyzenAPI
-- Game: Party Pirates Demo

-- MAIN APPLICATION
addappid(2771160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771161, 1, "d6d59e0930b32521e089b3b7e9206f393177475117667b744f25c99e68aa1f30")

