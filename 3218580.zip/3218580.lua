-- Lua provided by RyzenAPI
-- Game: Cellveillance

-- MAIN APPLICATION
addappid(3218580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3218581, 1, "27bfae9c397eaea78b053380126998b8b4e8b569cdb063fcd8c584bb9eb94646")
