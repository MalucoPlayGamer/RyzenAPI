-- Lua provided by RyzenAPI
-- Game: Cat Hits the Deck

-- MAIN APPLICATION
addappid(4489000) -- Cat Hits the Deck

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4489001, 1, "dbe7d1ad544af9f44c02f4e6e8c127f55c66f0dd4f3c306c2bb0ecf6a792add6") -- Depot 4489001

