-- Lua provided by RyzenAPI
-- Game: WindowBlinds 11

-- MAIN APPLICATION
addappid(2294630)
-- Game: addappid(2294630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294631, 1, "cf6248dbf8076c26632af280b88060fa36e03ec34b50ff2c184f8de45f01710f")
addappid(2339630, 0, "b70a5cf4cb24284a16675e683bc64f5d2b8b50887c7f5ba9c593ee7abe116694")
