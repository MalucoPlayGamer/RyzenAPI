-- Lua provided by RyzenAPI
-- Game: Game: R.O.O.T.S

-- MAIN APPLICATION
addappid(357930)
-- Game: addappid(357930)

-- MAIN APP DEPOTS / PACKAGES
addappid(357931, 1, "2bb721d094767a9b1e1f5248182568290d38b08c4ce3eec2f8cca004385dbb21")
addappid(357932, 1, "7538abc47700cb0467f269d6c72a4611de478453a56fd5c4385fd51c231f1122")
addappid(357933, 1, "16a4dbac7dc1cf3fe9a866592db200af35a32f73f20a87ed739d1fb81f31d4a5")
