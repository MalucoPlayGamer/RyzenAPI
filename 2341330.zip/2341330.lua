-- Lua provided by RyzenAPI
-- Game: Lost Alone Ultimate

-- MAIN APPLICATION
addappid(2341330)
addappid(2571440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341331, 1, "7241e82b6812d2e59c662f51d93cbb67799e5f67d403c7372f2140381a32c804")

