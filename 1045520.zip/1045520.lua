-- Lua provided by RyzenAPI 
-- Game: Acting Lessons
addappid(1045520)
addappid(1045521, 1, "b6a955f1d728cf529a0de7fe6e219eebf725e4b19a8c6359b587f8367d4e812b")
addappid(1045522, 1, "cb5d0d0cd68f180addbdfacb11aeb2841a2d0b94c9ea2463088895e1dd709139")
addappid(1045524, 1, "47a77590bbadbe0117af18c00ddcb270b1b6d8d5add3fe30a26f6a19c80350f7")
