-- Lua provided by RyzenAPI
-- Game: 2435450

-- MAIN APPLICATION
addappid(2435450)
-- Game: addappid(2435450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435451, 1, "ba334ddc1f296d553a909083b9fd857f49dc3dff71e8f8f10f1ded413a9d4c56")
