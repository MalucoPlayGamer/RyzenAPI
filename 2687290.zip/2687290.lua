-- Lua provided by RyzenAPI
-- Game: 2687290

-- MAIN APPLICATION
addappid(2687290)
-- Game: addappid(2687290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687291, 1, "66224c2fa0df009cb7e8699b64046110b6edc0464b50cddbc349cfd149685aac")
