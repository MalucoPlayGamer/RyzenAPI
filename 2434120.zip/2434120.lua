-- Lua provided by RyzenAPI
-- Game: PISTA Motorsport

-- MAIN APPLICATION
addappid(2434120)
-- Game: addappid(2434120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434121, 1, "ea2b9c91d3581818e9f6a075fd32a825b6d3285c4022645271a646ad90897787")
