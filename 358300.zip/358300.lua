-- Lua provided by RyzenAPI
-- Game: Major Stryker

-- MAIN APPLICATION
addappid(358300)

-- MAIN APP DEPOTS / PACKAGES
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070")
addappid(358301, 1, "1bbb7824fa227b3fcd6d2c39df1cd1e493c7365d5cc0486a56120bf15761aaf9") -- (windows)
addappid(358302, 1, "6a9799aaa019d2075766e7cb036162ac4f1f77d90f6a2df296acfd769b0f41f3") -- (macos)

