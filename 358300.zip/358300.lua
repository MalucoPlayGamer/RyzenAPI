-- Lua provided by RyzenAPI 
-- Game: Major Stryker
addappid(358300)
addappid(358301, 1, "1bbb7824fa227b3fcd6d2c39df1cd1e493c7365d5cc0486a56120bf15761aaf9")
addappid(358302, 1, "6a9799aaa019d2075766e7cb036162ac4f1f77d90f6a2df296acfd769b0f41f3")
