-- Generated with Luie @ https://lua.tools/
-- 358300 - Major Stryker
-- Generated 2026-08-29 03:25:48 UTC
-- # Depots (Total/DLC/Shared): 4/0/1

-- Main AppID
addappid(358300)

-- Main Depots
addappid(358301, 1, "1bbb7824fa227b3fcd6d2c39df1cd1e493c7365d5cc0486a56120bf15761aaf9") -- (windows)
setManifestid(358301, "4234364669001166710", 32811938)
addappid(358302, 1, "6a9799aaa019d2075766e7cb036162ac4f1f77d90f6a2df296acfd769b0f41f3") -- (macos)
setManifestid(358302, "1951672371918033842", 10818473)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070")

-- Missing Depots (We don't have the keys yet lol): 358303
