-- Lua provided by RyzenAPI
-- Game: Rise of the Eternal

-- MAIN APPLICATION
addappid(2731900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2731901, 1, "a05c0bb8f849c9818ff6d1c98799c28e28d361b999c50974d6015567f90610bd")

