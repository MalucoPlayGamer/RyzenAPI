-- Lua provided by RyzenAPI
-- Game: Rise of the Eternal

-- MAIN APPLICATION
addappid(2731900)
-- Game: addappid(2731900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731901, 1, "a05c0bb8f849c9818ff6d1c98799c28e28d361b999c50974d6015567f90610bd")
