-- Lua provided by RyzenAPI 
-- Game: Shoulders of Giants: Ultimate
addappid(2283880)
addappid(2283881, 1, "78f0541f08a3cbaae81c345d2973eb1350102dc7222423f82be7bb2dcb874468")
