-- Lua provided by RyzenAPI
-- Game: True or False 2

-- MAIN APPLICATION
addappid(581760)
-- Game: addappid(581760)

-- MAIN APP DEPOTS / PACKAGES
addappid(581761, 1, "5b080afdcdda53c3872f3162c28b2aa2a0c7cf0d80832457b474276f43ba06b8")
