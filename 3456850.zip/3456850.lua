-- Lua provided by SkyAPI 
-- Game: Bloom Thrice Soundtrack
addappid(3456850)
addappid(3456851, 1, "898e444a732f6d1c702f981d1e1d32e2904fa5d8049a9adeddd4ec0b4d35677d")
