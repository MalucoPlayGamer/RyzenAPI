-- Lua provided by RyzenAPI
-- Game: Bloom Thrice Soundtrack

-- MAIN APPLICATION
addappid(3456850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456851, 1, "898e444a732f6d1c702f981d1e1d32e2904fa5d8049a9adeddd4ec0b4d35677d")

