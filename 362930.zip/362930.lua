-- Lua provided by RyzenAPI
-- Game: Garfield Kart

-- MAIN APPLICATION
addappid(362930)

-- MAIN APP DEPOTS / PACKAGES
addappid(362931, 1, "655f861cbc910208a23b256e9c936a98b9481f22c902c3bcf0e8c0f85ef04915")
addappid(362932, 1, "04f2c8a4846618e824f451ac5a05d54ad0e0a01c3d0b39b15f8e81c2c2ebc219")

