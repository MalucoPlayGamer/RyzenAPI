-- Lua provided by RyzenAPI
-- Game: KarmaZoo

-- MAIN APPLICATION
addappid(1661630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661631, 1, "3df84994234aeeabe1560a3021763a3ecd231c6c5d53267e67a2e7282d17155c")

