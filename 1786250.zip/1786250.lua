-- Lua provided by RyzenAPI
-- Game: Puzzle Art: Artiodactyls

-- MAIN APPLICATION
addappid(1786250)
-- Game: addappid(1786250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786251, 1, "e7f8456063cb02c4bd0351308a2ed9e6463d5b9f05e26e7bfbdd75d48277ba19")
