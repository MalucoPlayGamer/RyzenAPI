-- Lua provided by SkyAPI 
-- Game: Ancient Farm
addappid(1933930)
addappid(1933931, 1, "4ad19164d0b1dec9888f8c25c4d436d1ad590eba26a2089b30c1a9acefe62590")
