-- Lua provided by RyzenAPI
-- Game: 1933930

-- MAIN APPLICATION
addappid(1933930)
-- Game: addappid(1933930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933931, 1, "4ad19164d0b1dec9888f8c25c4d436d1ad590eba26a2089b30c1a9acefe62590")
