-- Lua provided by RyzenAPI
-- Game: Fairyland: Fairy Power

-- MAIN APPLICATION
addappid(555940)

-- MAIN APP DEPOTS / PACKAGES
addappid(555941, 1, "6aa9d6f055317426f77ba5d1c4e119637959b4060416344e7eaf2c4e1b948a3c")
addappid(555942, 1, "1ea50f19fe335b9562c8178a7d8b73cbfab9a60f4b6816374b7133d3e597cd01")
addappid(555943, 1, "4e55316a56e824501a667fdaec7c06aabb20fd6f0948e6ed22c4551a9b9c77be")
addappid(555944, 1, "236a73537c32592df7ae55db4fd374a4abaf57b2ded884a2b6235f17d4d0a21e")
