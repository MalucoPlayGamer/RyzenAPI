-- Lua provided by RyzenAPI
-- Game: Hop Step Sing! Kisekiteki Shining! (HQ Edition)

-- MAIN APPLICATION
addappid(538000)

-- MAIN APP DEPOTS / PACKAGES
addappid(538001, 1, "1fab456f4977d87079aa20fce7ea79b196a79ec0c9c60b61cb7a3828af0b9939")

