-- Lua provided by RyzenAPI
-- Game: Skin and Bones

-- MAIN APPLICATION
addappid(1252450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252451, 1, "098716f21f5bbd29bc66688cf325d30e1c584071ce8e5a2c96bd298e3d54dc5e")
