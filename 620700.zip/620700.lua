-- Lua provided by RyzenAPI
-- Game: EVIL POSSESSION

-- MAIN APPLICATION
addappid(620700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(620701, 1, "fac6985208e54f8ca42465e22b7a3d9422686712a4fa97c04a63f60e621a0c4b")
addappid(620702, 1, "8ae72c0dbb2e0ad032f121bcb3163928ad5bb14e6d200c68c2d51ba117a33b52")
addappid(620703, 1, "4cab7a63b5a98a6fb0e7e9f3b1c1a5eafbc603c0bf91ea4b4176b9fbf787d0b8")

