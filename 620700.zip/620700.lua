-- Lua provided by RyzenAPI
-- Game: 620700

-- MAIN APPLICATION
addappid(620700)
-- Game: addappid(620700)

-- MAIN APP DEPOTS / PACKAGES
addappid(620701, 1, "fac6985208e54f8ca42465e22b7a3d9422686712a4fa97c04a63f60e621a0c4b")
addappid(620702, 1, "8ae72c0dbb2e0ad032f121bcb3163928ad5bb14e6d200c68c2d51ba117a33b52")
addappid(620703, 1, "4cab7a63b5a98a6fb0e7e9f3b1c1a5eafbc603c0bf91ea4b4176b9fbf787d0b8")
