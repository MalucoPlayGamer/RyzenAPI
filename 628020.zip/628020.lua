-- Lua provided by RyzenAPI
-- Game: 628020

-- MAIN APPLICATION
addappid(628020)
-- Game: addappid(628020)

-- MAIN APP DEPOTS / PACKAGES
addappid(628021, 1, "ada7f5494e8c6435c0b64ba25a4a9704dbf359dd08a7b46a350bc413a6231c0d")
