-- Lua provided by RyzenAPI
-- Game: Apocalypse Express

-- MAIN APPLICATION
addappid(3223160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3223161, 1, "cc2c1008c60777b10e1f580b2944b3a7e50aabb5a3d396b2877d2f859712c9f2")
