-- Lua provided by RyzenAPI
-- Game: SD Shin Kamen Rider Rumble Shin Ultraman Pack

-- MAIN APPLICATION
addappid(2231717)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231717,0,"f0568718e1bcf75e8efc2f0269249e7558c67a5d33f149448972507f4eb9c62e")

