-- Lua provided by RyzenAPI
-- Game: 1157230

-- MAIN APPLICATION
addappid(1157230)
-- Game: addappid(1157230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157230,0,"d11a1682bf5ef74c412d84bc31da9eace38258ca0f0036f87feaf28fde2a69d2")
