-- Lua provided by RyzenAPI
-- Game: Follow the Black Kitten

-- MAIN APPLICATION
addappid(1805390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1805391, 1, "f7c5a16d1511d78838228f2a1ef6cfd59f04483e041595808ddb2355d1180770")

