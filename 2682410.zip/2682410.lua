-- Lua provided by RyzenAPI
-- Game: Sex Christmas

-- MAIN APPLICATION
addappid(2682410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682411, 1, "6a452bc8981db37ba37375843edb547d628214c8f094f04cf7b2246e8f44b585")

