-- Lua provided by RyzenAPI
-- Game: A Femboy Polished My Knob

-- MAIN APPLICATION
addappid(3320770)
-- Game: addappid(3320770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320771, 1, "e17f5a4f2e8d02a5b345ab485df3167388b1ea1b78d9bcc54ca3f6a1b348fbe5")
