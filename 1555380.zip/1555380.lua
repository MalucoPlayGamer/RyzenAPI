-- Lua provided by RyzenAPI
-- Game: Game: RPG IDLE

-- MAIN APPLICATION
addappid(1555380)
-- Game: addappid(1555380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555381, 1, "6221b75820f877b329b61103c9215fbbe91ac16a8806da2690cbb53e59a95832")
