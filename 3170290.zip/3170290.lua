-- Lua provided by RyzenAPI
-- Game: addappid(3170290)

-- MAIN APPLICATION
addappid(3170290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170291, 1, "5b42f13bc3c8bdc7852d566333cb56ef5eb63e8e6f62cdb69de70edca57a0188")
