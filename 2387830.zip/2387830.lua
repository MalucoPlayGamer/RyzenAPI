-- Lua provided by RyzenAPI
-- Game: People Jumping Tower

-- MAIN APPLICATION
addappid(2387830)
-- Game: addappid(2387830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387831, 1, "da1c7913025e51cda708775fdc5b112a82e5473ae203ae6987ef446b10540d5a")
