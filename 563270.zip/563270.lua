-- Lua provided by RyzenAPI
-- Game: Game: AppID 563270

-- MAIN APPLICATION
addappid(563270)
-- Game: addappid(563270)

-- MAIN APP DEPOTS / PACKAGES
addappid(563271, 1, "a1dcd0320b2988f85b257ca7350513d8b67525de6efde9f77c60fcce455a64a6")
addappid(563272, 1, "68e0dccebd3c0b2fab9b47948e8ee44dab141d2bdae58aec96fcd67ac3a4c3e3")
