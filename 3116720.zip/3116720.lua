-- Lua provided by RyzenAPI
-- Game: Five Nights At Skibidi Toilets

-- MAIN APPLICATION
addappid(3116720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116721, 1, "00ea8a923f665487de7ba632cc2ddb16a5d210b1d7ee5ce5572bf4f8619b87b7")

