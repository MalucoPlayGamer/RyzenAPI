-- Lua provided by RyzenAPI
-- Game: Five Nights At Skibidi Toilets

-- MAIN APPLICATION
addappid(3116720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3116721, 1, "00ea8a923f665487de7ba632cc2ddb16a5d210b1d7ee5ce5572bf4f8619b87b7")

