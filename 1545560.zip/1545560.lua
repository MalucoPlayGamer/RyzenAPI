-- Lua provided by RyzenAPI 
-- Game: Shadow Gambit: The Cursed Crew
addappid(1545560)
addappid(1545561, 1, "c9d50c94293025191fbb84ba06e8c755d529767197b2b642bc8a922a8a20b9a4")
addappid(2505850, 0, "968e0fc74bd31aa95a7542bfdd737ecebe2abc837f0e06a266eb4fff4036073b")
