-- Lua provided by RyzenAPI
-- Game: Shadow Gambit: The Cursed Crew

-- MAIN APPLICATION
addappid(1545560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545561, 1, "c9d50c94293025191fbb84ba06e8c755d529767197b2b642bc8a922a8a20b9a4")
addappid(2505850, 0, "968e0fc74bd31aa95a7542bfdd737ecebe2abc837f0e06a266eb4fff4036073b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2304810)
addappid(2576620)
