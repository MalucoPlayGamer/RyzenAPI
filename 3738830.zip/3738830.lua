-- Lua provided by RyzenAPI
-- Game: FIRE STATE

-- MAIN APPLICATION
addappid(3738830) -- FIRE STATE

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3738831, 1, "f7cfa2e0e1a6b6940b155923613b25849fd38a098f80a6876b0f124b76e6be86") -- Depot 3738831
addtoken(3738830, "16207906861055397030")

