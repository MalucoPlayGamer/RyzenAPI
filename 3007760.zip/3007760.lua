-- Lua provided by RyzenAPI
-- Game: Innocent Grape - Animations & Wallpapers

-- MAIN APPLICATION
addappid(3007760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007760,0,"bbfe96c3d73802644d2d8298b7ad91a08e056a0f3282eed0b721796b9b95dc4d")
