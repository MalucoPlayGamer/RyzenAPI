-- Lua provided by RyzenAPI
-- Game: Wartheon

-- MAIN APPLICATION
addappid(3214320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214321,0,"6b96607ad42b819d0cbca4ab1fb1172940819ae9cffa98c5a79a6485110cfad6")

