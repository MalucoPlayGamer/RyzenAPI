-- Lua provided by RyzenAPI
-- Game: Granblue Fantasy Versus: Rising Free Edition

-- MAIN APPLICATION
addappid(2667960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667961, 1, "ad7bcc52fb0cb22fd55fbacf8d872e9a305a122d38509469565985175252927a")

