-- Lua provided by RyzenAPI
-- Game: AURA: Hentai Cards - Full Animations Pack

-- MAIN APPLICATION
addappid(3188410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3188410,0,"29eed0351cf04624e5f6efa1da0e5b2c2754b656a6f0c4731ae7365e006b221f")
