-- Lua provided by RyzenAPI
-- Game: Game: AppID 350570

-- MAIN APPLICATION
addappid(350570)
-- Game: addappid(350570)

-- MAIN APP DEPOTS / PACKAGES
addappid(350571, 1, "66fb981cbf3a49c62d1370c248ae78e011c070a4bbc4da1e0be8062dfcf2c16e")
