-- Lua provided by RyzenAPI
-- Game: Soft Wind

-- MAIN APPLICATION
addappid(1494220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494221, 1, "2139c512c7a7037aecdbeab1089c8a74e93a6f972a81202e829af17e314f2846")

