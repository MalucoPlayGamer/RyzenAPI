-- Lua provided by SkyAPI 
-- Game: Cafe Dash: Cooking, Diner Game
addappid(3306780)
addappid(3306781, 1, "ce3a6db654b8ab6348a019663ad083f6057bd7e49b86a21f0de33581b1592210")
