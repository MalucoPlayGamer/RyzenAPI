-- Lua provided by RyzenAPI
-- Game: Cafe Dash: Cooking, Diner Game

-- MAIN APPLICATION
addappid(3306780)
addappid(3804570)
addappid(3804580)
addappid(3804590)
addappid(3804600)
addappid(3804610)
addappid(3804620)
addappid(3804630)
addappid(3804650)
addappid(3804660)
addappid(3804670)
addappid(3804680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3306781, 1, "ce3a6db654b8ab6348a019663ad083f6057bd7e49b86a21f0de33581b1592210")

