-- Lua provided by RyzenAPI
-- Game: Forgotton Anne

-- MAIN APPLICATION
addappid(542050)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(542051, 1, "303d4db1ef7e3e611a2e037b5dcff88676d29ee98e1c6225f8a8ffe5ef079149")
addappid(630420, 0, "017d9168266d5ace3a4f844e885d714802f3674a4c90cdb3dc3f38892d2ffe2f")
