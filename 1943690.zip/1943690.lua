-- Lua provided by RyzenAPI
-- Game: Until the Night

-- MAIN APPLICATION
addappid(1943690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1943691, 1, "751080225cc9da78b49e2b11282c5d7790551eddda2d982a6a3f043a61e7b5c2")

