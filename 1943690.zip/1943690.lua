-- Lua provided by RyzenAPI 
-- Game: AppID 1943690
addappid(1943690)
addappid(1943691, 1, "751080225cc9da78b49e2b11282c5d7790551eddda2d982a6a3f043a61e7b5c2")
