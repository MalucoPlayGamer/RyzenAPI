-- Lua provided by RyzenAPI
-- Game: addappid(2485180)

-- MAIN APPLICATION
addappid(2485180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485181, 1, "666c7d74962d7e2b2652d6bcf8e14aadf6a833c47dbed050d33a715d81d64d88")
