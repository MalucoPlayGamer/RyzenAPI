-- Lua provided by RyzenAPI
-- Game: Travellin Cats in Georgia

-- MAIN APPLICATION
addappid(2485180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2485181, 1, "666c7d74962d7e2b2652d6bcf8e14aadf6a833c47dbed050d33a715d81d64d88")

