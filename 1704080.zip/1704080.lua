-- Lua provided by RyzenAPI
-- Game: addappid(1704080)

-- MAIN APPLICATION
addappid(1704080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704081, 1, "d444d0c5724c88eaa89305f5f7805f7fa7a00d3366984294d84ff0adfecaae0b")
