-- Lua provided by RyzenAPI
-- Game: The Rumble Fish +

-- MAIN APPLICATION
addappid(2499990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2499991,0,"a03f0256e323e23471ae1ac447833c53287dbce8838c0297299003aea8af5ccf")

