-- Lua provided by RyzenAPI
-- Game: Game: Mahsung Deluxe

-- MAIN APPLICATION
addappid(542690)
-- Game: addappid(542690)

-- MAIN APP DEPOTS / PACKAGES
addappid(542691, 1, "a98684f35b2d1b5001eeab802fe6d988982a0b5cc0ea7766d120ff3bc82c4d15")
