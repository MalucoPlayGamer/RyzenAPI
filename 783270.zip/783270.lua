-- Lua provided by RyzenAPI
-- Game: Seek & Destroy - Steampunk Arcade

-- MAIN APPLICATION
addappid(783270)

-- MAIN APP DEPOTS / PACKAGES
addappid(783271,0,"95db24f8f618f5c6b6fa132651484be79380de1289458629603e683d58170973")

