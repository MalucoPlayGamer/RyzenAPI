-- Lua provided by RyzenAPI
-- Game: Where is my cat Demo

-- MAIN APPLICATION
addappid(2468580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468582,0,"6d59c7d3b1d754c9647b9e80f6f68c9f1b4a8bf533f765a0e97881aa9e1628de")

