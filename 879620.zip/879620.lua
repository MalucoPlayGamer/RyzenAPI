-- Lua provided by RyzenAPI
-- Game: addappid(879620)

-- MAIN APPLICATION
addappid(879620)

-- MAIN APP DEPOTS / PACKAGES
addappid(879621, 1, "d4a4253644c617113cf0aaae97272810af6337266b25b5a93f2365c2f8cd2c42")
