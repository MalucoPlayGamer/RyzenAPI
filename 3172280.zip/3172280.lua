-- Lua provided by RyzenAPI
-- Game: SEX Amnesia - Lover Sim 🔞

-- MAIN APPLICATION
addappid(3172280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172281, 1, "1646a77a092a374a2be5cbe417ef498dbd02bd3ea4567fb3d6907e14b46bb04e")

