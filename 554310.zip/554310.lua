-- Lua provided by RyzenAPI
-- Game: Game: Rage Wars

-- MAIN APPLICATION
addappid(554310)
-- Game: addappid(554310)

-- MAIN APP DEPOTS / PACKAGES
addappid(554311, 1, "d165b901e4aeb307758f867955152a5a5434b3cd13841cc7c67fa6f5589f1e31")
addappid(554312, 1, "b49afe56f9a3b93233ac2ca08a8377d6049f021c2606148db4391ec0a366ba2a")
addappid(554313, 1, "b760abbf77cbe1f65a98cfe2fb378d4bd0227789cfcfed88e1424f6761a6ccf9")
addappid(554314, 1, "f42ba4a005fc3c8fbbd7665bd36773a4e68ec22b6ac6198ccb2a75514db27011")
addappid(554315, 1, "8eda991735806e208344a7f0bef1f33df66e0c15482d0b9ff3dfb3c0a0177e00")
