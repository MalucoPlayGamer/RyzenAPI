-- Lua provided by RyzenAPI
-- Game: Game: Loader

-- MAIN APPLICATION
addappid(806970)
-- Game: addappid(806970)

-- MAIN APP DEPOTS / PACKAGES
addappid(806971, 1, "070b478cce8fc65153423d149afc1377e83420c894adb548e0744479a6887746")
