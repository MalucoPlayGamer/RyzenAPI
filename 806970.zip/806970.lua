-- Lua provided by RyzenAPI
-- Game: Loader

-- MAIN APPLICATION
addappid(806970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(806971, 1, "070b478cce8fc65153423d149afc1377e83420c894adb548e0744479a6887746")

