-- Lua provided by RyzenAPI
-- Game: 2149030

-- MAIN APPLICATION
addappid(2149030)
-- Game: addappid(2149030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149031, 1, "12f5a77c2d6550eec723082444fb12b3bf6ad35442903889bccacf2ce0cdfd34")
