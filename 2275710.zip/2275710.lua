-- Lua provided by RyzenAPI
-- Game: Akari and the Abyss

-- MAIN APPLICATION
addappid(2275710)
-- Game: addappid(2275710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275711, 1, "7d566c549112273e0dc050e864fd5597ce59f83bfc247cc6bacb13f61e95778b")
addappid(2275712, 1, "f7584faa9d41c0509f0c8dc966a11f3e1c69ec6ee0aee061774bbae1f08c7255")
addappid(2275713, 1, "3c152d77d16ad5515433e9d9b1b3ce88b5ced407bc027a03d716424789537d15")
addappid(2275714, 1, "b41a8893949f8df17b39de297b3a9fa9839727b3e467da6bf3bc2dab55f45f0f")
