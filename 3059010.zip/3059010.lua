-- Lua provided by RyzenAPI
-- Game: 3059010

-- MAIN APPLICATION
addappid(3059010)
-- Game: addappid(3059010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3059011, 1, "0f60e5e2e1c7e3a45d14d6b1fcf6c228e0102bfe05e325313c53b9cfed38f8a7")
