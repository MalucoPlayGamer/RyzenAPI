-- Lua provided by RyzenAPI
-- Game: Game: AppID 506540

-- MAIN APPLICATION
addappid(506540)
-- Game: addappid(506540)

-- MAIN APP DEPOTS / PACKAGES
addappid(506541, 1, "615db3b5aec78b8cbc573caef8b45d365eabef40598c45f45d8653fd05a0f704")
