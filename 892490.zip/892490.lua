-- Lua provided by RyzenAPI
-- Game: AppID 892490

-- MAIN APPLICATION
addappid(892490)
-- Game: addappid(892490)

-- MAIN APP DEPOTS / PACKAGES
addappid(892491, 1, "d944de865a63f6d791de5a15d6e2c45815a41f2c8142cb13c453c6efbbf0010e")
