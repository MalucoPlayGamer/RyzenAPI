-- Lua provided by RyzenAPI
-- Game: Hyper Fighters

-- MAIN APPLICATION
addappid(267960)

-- MAIN APP DEPOTS / PACKAGES
addappid(267961, 1, "6239ad476536cb157c50d604753b3a3fb461aa34755b7eb635d9df3daa9541ba")

