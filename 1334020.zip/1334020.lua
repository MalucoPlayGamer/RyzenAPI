-- Lua provided by RyzenAPI
-- Game: Game: Aeon on Mosaic: Anemone 时间碎片：奇迹

-- MAIN APPLICATION
addappid(1334020)
-- Game: addappid(1334020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334021, 1, "6e347d434ff4bbbf51f1bc72bdb6f0658ab34864509d8b502f5ca01038c9fb7a")
