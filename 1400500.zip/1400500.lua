-- Lua provided by RyzenAPI
-- Game: Contraband Police Demo

-- MAIN APPLICATION
addappid(1400500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400501, 1, "d2f4342483adaec583dd04232434a75eeed357054efc4bc7d338ae32a4009f80")
