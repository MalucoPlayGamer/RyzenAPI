-- Lua provided by RyzenAPI
-- Game: Game: Painkiller: Resurrection

-- MAIN APPLICATION
addappid(39560)
-- Game: addappid(39560)

-- MAIN APP DEPOTS / PACKAGES
addappid(39561, 1, "571d8cc6a20c308d5cd062d2f1944b03ddc21124a4d9c61c046f4e0ae2e95c9c")
addappid(39562, 1, "91a07d900d46b6a9d2af5d44d3780746bee9baeb5e163995f154fcbfaabef018")
addappid(39563, 1, "df623d7e35efc5f041e7d30b6844add3d808bd229a846e3d200a0b38b9d3209a")
addappid(39564, 1, "5a89c058838aac48259eab09457484d5586f3c19e9b69d0a6dded38d6dd61706")
addappid(39565, 1, "89e485c5fa7d05afab79cf602350fd3991da53788eec0a5a75e45a37646985ec")
addappid(39566, 1, "76d35d557badb8a9536487a96f2d482cc0b8f0e2108308c0f5afbd208dff763a")
