-- Lua provided by RyzenAPI
-- Game: The 9th Day - CG+单图豪华合集

-- MAIN APPLICATION
addappid(989480)

-- MAIN APP DEPOTS / PACKAGES
addappid(989480,0,"0611b726ceb1c2951097589efddd44e16bf8ed48b832e13e9a1e6f800b2baa83")

