-- Lua provided by RyzenAPI
-- Game: Game: AppID 521880

-- MAIN APPLICATION
addappid(521880)
-- Game: addappid(521880)

-- MAIN APP DEPOTS / PACKAGES
addappid(521881, 1, "7f70ed2f8ac0ae4116593da3a4396bab1f4956ac2d6a0e7d2ccb180d87b2776f")
addappid(521882, 1, "506ae1da563552975b3c809a91536e0d5c26c90421fb620094f8558a44e221d6")
