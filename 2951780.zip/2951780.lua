-- Lua provided by RyzenAPI
-- Game: Until Chloe, the New Wife, Falls

-- MAIN APPLICATION
addappid(2951780)
-- Game: addappid(2951780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951781, 1, "e623cd4f90bcfb324a392717849a2bdfea209e53a7435f90dbfa2b1e446ce44f")
addappid(2951782, 1, "e6725a3db39ed07d6830baab4e52bfaea4f7f9320920bc6b3b30279012c5c5ba")
addappid(2951783, 1, "cd8fcfc8b306344fb9e91a12bf78c9b88d2d596b9332ef3ac7be12af529893fe")
addappid(2951784, 1, "38a5d40ad236363f25772f2af0d8810afce90bf9d46721794bff30a7944b031c")
