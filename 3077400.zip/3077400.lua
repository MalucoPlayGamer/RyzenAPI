-- Lua provided by RyzenAPI
-- Game: 3077400

-- MAIN APPLICATION
addappid(3077400)
-- Game: addappid(3077400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077401, 1, "da77e403122e1d282aa69c5a6e69f5c0d556d1b0b1fd5de5fe2e7feb49b794c2")
