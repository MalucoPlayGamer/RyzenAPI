-- Lua provided by RyzenAPI
-- Game: Real Boxing™

-- MAIN APPLICATION
addappid(296770)

-- MAIN APP DEPOTS / PACKAGES
addappid(296771, 1, "55b41a278404890147ed595bc2e69a04e18f3f5e2ca2cc594e409ffe11a5d250")

