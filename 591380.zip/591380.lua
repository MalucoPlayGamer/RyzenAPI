-- Lua provided by RyzenAPI
-- Game: Bomb Squad Academy

-- MAIN APPLICATION
addappid(591380)

-- MAIN APP DEPOTS / PACKAGES
addappid(591381, 1, "ac21a251cf35d73c0f14a382dcc69f7d46abdd408674751fbe00f66c5d22a2d1")

