-- Lua provided by RyzenAPI
-- Game: BANNED TAPES

-- MAIN APPLICATION
addappid(3501370)
-- Game: addappid(3501370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3501371, 1, "d96e1ae7fc69fd872be44fde05a37bd811d8879c69c6dbdba41c66618d6ac631")
