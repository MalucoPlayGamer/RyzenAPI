-- Lua provided by SkyAPI 
-- Game: Research Story
addappid(1629830)
addappid(1629831, 1, "c44015fcaaf42ef956e92da590db8940b4edeef9783f87ca52b6c242346fa1bd")
