-- Lua provided by RyzenAPI
-- Game: addappid(1629830)

-- MAIN APPLICATION
addappid(1629830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629831, 1, "c44015fcaaf42ef956e92da590db8940b4edeef9783f87ca52b6c242346fa1bd")
