-- Lua provided by RyzenAPI
-- Game: Demon Slayer -Kimetsu no Yaiba- Sweep the Board!

-- MAIN APPLICATION
addappid(2424110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424111, 1, "bde7a6acfa104ae59b9442eec2ec9cc5269aa69b63264eefc8ba08470c36194f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2815480)
addappid(2815490)
