-- Lua provided by RyzenAPI
-- Game: Demon Slayer -Kimetsu no Yaiba- Sweep the Board!

-- MAIN APPLICATION
addappid(2424110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424111, 1, "bde7a6acfa104ae59b9442eec2ec9cc5269aa69b63264eefc8ba08470c36194f")

