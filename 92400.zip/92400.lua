-- Lua provided by RyzenAPI
-- Game: addappid(92400)

-- MAIN APPLICATION
addappid(92400)

-- MAIN APP DEPOTS / PACKAGES
addappid(92401, 1, "a3cb349f67008279743962f451c8fdaf30a1655cc905d4118f45447d4661fe8f")
