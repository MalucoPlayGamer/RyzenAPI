-- Lua provided by RyzenAPI
-- Game: NationWar:Annals

-- MAIN APPLICATION
addappid(1494960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494961, 1, "053386afff854cee10bf08d8072b8272318f9b1397be0ad6ef967fd91d38c833")

