-- Lua provided by RyzenAPI
-- Game: addappid(1770570)

-- MAIN APPLICATION
addappid(1770570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770572,0,"2101bb3395c2e5c5f1cb09a7b50426dbe106992a56d7c49fc06a9c2d37ce6ed4")
