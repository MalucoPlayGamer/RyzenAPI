-- Lua provided by RyzenAPI
-- Game: Wonder Ball

-- MAIN APPLICATION
addappid(2640030)
addappid(4446890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2640031, 1, "0d4d84e8de9ffde0f6cf5ba432051ece266603477d39b1c154da2ad562870aeb")
