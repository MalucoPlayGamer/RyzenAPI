-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228988)
addappid(228989)
addappid(2819550)
-- Game: addappid(2819550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510961,0,"6298e19f83a2a76669f5695059fbdd6bb50c0bd28a05a54f178486de4283e7c4")
