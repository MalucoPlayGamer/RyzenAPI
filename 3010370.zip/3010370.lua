-- Lua provided by RyzenAPI
-- Game: Metal Slug Tactics Demo

-- MAIN APPLICATION
addappid(3010370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3010371, 1, "cf12e945ba4748d0553c1817bacd8912f278d5a589d7ed707afb6912e938bc26")
