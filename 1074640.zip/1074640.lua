-- Lua provided by RyzenAPI
-- Game: addappid(1074640)

-- MAIN APPLICATION
addappid(1074640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074641, 1, "e331b0bc10de0f0175de01314f5913a7c5001e3f7414ed17dc7e5efb6e220c89")
