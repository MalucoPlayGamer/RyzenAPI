-- Lua provided by RyzenAPI
-- Game: Don't Touch The Zombies

-- MAIN APPLICATION
addappid(563370)

-- MAIN APP DEPOTS / PACKAGES
addappid(563371,0,"28bc3d7bdc77c7c7cb61152aa495b0d7f1ab5a7677eef8eb3c1f1a49d467f2b3")
addappid(563372,0,"0ba905b328300fa3a15db7f11584baacb550cf3a540da90b434fcc67f2a42af5")

