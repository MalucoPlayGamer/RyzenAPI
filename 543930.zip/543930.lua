-- Lua provided by RyzenAPI
-- Game: Koi Musubi

-- MAIN APPLICATION
addappid(543930)
-- Game: addappid(543930)

-- MAIN APP DEPOTS / PACKAGES
addappid(543931, 1, "afdfa1a3a404d9dc5ff22ae6c781e3bfb8c06df0b66ba8b8248a364f741e0a70")
addappid(543933, 1, "9706a87f211b1a4a13f90c8f8cc00d7d403e471648bc6258b282d15c6e39e589")
addappid(605030, 0, "391550f9965e01ff55ea5d44e296c978de8ed585068a22e7362722feb641ca5b")
