-- Lua provided by RyzenAPI 
-- Game: Shining Plume
addappid(536420)
addappid(536421, 1, "4b76449c0761146801037679d27e9a3ac8e987f2072d701461cdaea8b331ac18")
