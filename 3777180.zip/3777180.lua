-- Lua provided by SkyAPI 
-- Game: SAEKO: Giantess Dating Sim Soundtrack
addappid(3777180)
addappid(3777181, 1, "2a01d6da6f37d9d64d1fe468160fa6e019739f99ed6cdbdd792207649525642a")
