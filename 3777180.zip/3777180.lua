-- Lua provided by RyzenAPI
-- Game: addappid(3777180)

-- MAIN APPLICATION
addappid(3777180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3777181, 1, "2a01d6da6f37d9d64d1fe468160fa6e019739f99ed6cdbdd792207649525642a")
