-- Lua provided by RyzenAPI
-- Game: Yasha: Legends of the Demon Blade

-- MAIN APPLICATION
addappid(2169950)
-- Game: addappid(2169950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169951, 1, "abf41543840ce6e00b0c343f72d66ae59ca452df07e68b85836ba7a4eec7cb5f")
