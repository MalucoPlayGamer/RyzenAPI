-- Lua provided by SkyAPI 
-- Game: AMID EVIL Demo
addappid(1633340)
addappid(1633341, 1, "b8d0e547afea576af53106849ae7a366778c3c584bbb36f36385a8f674c53ada")
