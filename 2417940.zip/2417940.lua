-- Lua provided by RyzenAPI
-- Game: Hero Emblems II

-- MAIN APPLICATION
addappid(2417940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2417941, 1, "5be21f715f7a879a7c80319e86e48809fe52e04cdf7890f023d89ca2e3daa4ca")

