-- Lua provided by RyzenAPI 
-- Game: Hero Emblems II
addappid(2417940)
addappid(2417941, 1, "5be21f715f7a879a7c80319e86e48809fe52e04cdf7890f023d89ca2e3daa4ca")
