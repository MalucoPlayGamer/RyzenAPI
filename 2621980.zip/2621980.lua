-- Lua provided by RyzenAPI
-- Game: SD Dungeons

-- MAIN APPLICATION
addappid(2621980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2621981,0,"8a8072fae0d86a937feca9c844bb9f6135fe6b10f7b693174b073544f2a2cb4a")

