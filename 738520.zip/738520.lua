-- Lua provided by RyzenAPI
-- Game: Breathedge

-- MAIN APPLICATION
addappid(738520)

-- MAIN APP DEPOTS / PACKAGES
addappid(738521, 1, "4c18853b78cacf0c4cba33d0c37b2d60aa1833ad25fb7604f9b517607d994e63")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
