-- Lua provided by RyzenAPI
-- Game: Game: Ninja Soul

-- MAIN APPLICATION
addappid(1848710)
-- Game: addappid(1848710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848711, 1, "2fe21e0b28df9283d1ce5962b6fdff98f79ea28815e8e874dc9e97208f23a228")
