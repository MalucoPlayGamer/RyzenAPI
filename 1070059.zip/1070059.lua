-- Lua provided by RyzenAPI
-- Game: 1070059

-- MAIN APPLICATION
addappid(1070059)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070059,0,"f337f9f7ca38556f8e7e9c46236ac4dadb4e8fc43decc8e29c2a352611e0a447")
