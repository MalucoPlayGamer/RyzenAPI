-- Lua provided by RyzenAPI
-- Game: addappid(482210)

-- MAIN APPLICATION
addappid(482210)

-- MAIN APP DEPOTS / PACKAGES
addappid(482211, 1, "d735dd53e44c3e6efa7e9685fb82482766de5f5331f12f9a8935b83bd81b8b8a")
