-- Lua provided by RyzenAPI
-- Game: addappid(3085640)

-- MAIN APPLICATION
addappid(3085640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085641, 1, "7a5eff2d30643526f645c30926fecbd461dd96b55a645a6aa25746f1333f742e")
