-- Lua provided by RyzenAPI
-- Game: Archaelund

-- MAIN APPLICATION
addappid(1082970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082971, 1, "cc8ee1eb22d1d974bd03dfb6b10ca78189cfcf7abee76ac3d528b9c45e47c0d5")
