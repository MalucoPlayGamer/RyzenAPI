-- Lua provided by SkyAPI 
-- Game: Dino Quake
addappid(3342430)
addappid(3342431, 1, "793b409ca5c56c639ea3c19439627d1a0f64354db2fe46f0a13aee9ba78c508e")
