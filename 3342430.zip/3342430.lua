-- Lua provided by RyzenAPI
-- Game: Game: Dino Quake

-- MAIN APPLICATION
addappid(3342430)
-- Game: addappid(3342430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342431, 1, "793b409ca5c56c639ea3c19439627d1a0f64354db2fe46f0a13aee9ba78c508e")
