-- Lua provided by RyzenAPI
-- Game: Game: AppID 446270

-- MAIN APPLICATION
addappid(446270)
-- Game: addappid(446270)

-- MAIN APP DEPOTS / PACKAGES
addappid(446271, 1, "c5b3943e0521d7911373705a855a9c2682811efe72483314957293725406c01e")
addappid(446272, 1, "cca0edda3294d4a12a98c4812ad4e6ab52a658f9eec96696e5154b4d1cb0a2a8")
addappid(713270, 0, "7af504ba89b8ac23ac7f2ca4f9a2e1bab39f3b8c733ca7ca4c660111aeb75f8f")
