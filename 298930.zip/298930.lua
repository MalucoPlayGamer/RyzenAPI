-- Lua provided by RyzenAPI
-- Game: Darkness Within 1: In Pursuit of Loath Nolder

-- MAIN APPLICATION
addappid(298930)
addappid(414680)

-- MAIN APP DEPOTS / PACKAGES
addappid(298931, 1, "73d498fd75ddfdc7315e130c1b8adc93e8a1d09761e98e8151cd19232030b5d4")
addappid(298932, 1, "2dc7235f0fe5f01391751498f8324a37b19b95f74c2bfcb08785ad7d03e52dc6")

