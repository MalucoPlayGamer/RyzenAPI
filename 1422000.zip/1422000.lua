-- Lua provided by RyzenAPI
-- Game: Game: Space Alliance: Frontier

-- MAIN APPLICATION
addappid(1422000)
-- Game: addappid(1422000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422001, 1, "88aff73628a0d4d95410075cbe75773f47364df36f1760fc746f4f455b8855d6")
