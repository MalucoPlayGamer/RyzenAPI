-- Lua provided by RyzenAPI
-- Game: TerraTech - Official Soundtrack

-- MAIN APPLICATION
addappid(917190)
-- Game: addappid(917190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243970,0,"6e09c104d074b60f24441690ac37b377b6c05247701fbfbc4f334f91a751933d")
