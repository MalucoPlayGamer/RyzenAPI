-- Lua provided by RyzenAPI 
-- Game: AppID 33990
addappid(33990)
addappid(33991, 1, "b6a59532d522bf71935d28c76356c2a72a1ab52551d1049a7946a895f4806b49")
