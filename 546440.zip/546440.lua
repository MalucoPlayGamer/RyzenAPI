-- Lua provided by RyzenAPI
-- Game: addappid(546440)

-- MAIN APPLICATION
addappid(546440)

-- MAIN APP DEPOTS / PACKAGES
addappid(546441, 1, "15d2f5ded70bc3995f5ee13e26ffbddad7c8a8707cb46876b02e9296e9d2113b")
