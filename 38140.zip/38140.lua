-- Lua provided by RyzenAPI
-- Game: AppID 38140

-- MAIN APPLICATION
addappid(38140)

-- MAIN APP DEPOTS / PACKAGES
addappid(38141, 1, "6f3f5ee74654506b2041e72e8fcba7e94fba947ee7bca54177fec8fd61bfe642")

