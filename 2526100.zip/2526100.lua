-- Lua provided by RyzenAPI
-- Game: Rune Gate Demo

-- MAIN APPLICATION
addappid(2526100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526101, 1, "784cd3e01a9e77b888ee9c6381def25641b7234aae316e494d587124847bee25")
