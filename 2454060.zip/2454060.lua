-- Lua provided by RyzenAPI 
-- Game: MAZEMAZE
addappid(2454060)
addappid(2454061, 1, "187c45ae61c83b36131f11e4d6d4007bbe79f77eca6c43731ee3f65e8c2ddf04")
addappid(2454063, 1, "8b8b85e6b25e9473e835d275aef0fc84e329b702f8116f7e191112aea8b7360a")
