-- Lua provided by RyzenAPI
-- Game: CRYMACHINA

-- MAIN APPLICATION
addappid(2258500)
addappid(2534690)
addappid(2534700)
addappid(2534710)
addappid(2534720)
addappid(2534730)
addappid(2534740)
addappid(2940390)
addappid(2940400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2258501, 1, "154490d1c27e744f8beab95dddee5f7dced661b8b8ebb30a9c984772d5cbbd2e")

