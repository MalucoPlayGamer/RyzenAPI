-- Lua provided by RyzenAPI
-- Game: Bullet Destroyer

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2209500)
-- Game: addappid(2209500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209502,0,"caa5318b8880154411a5471d19ae7013ddff3147dab4cd58b5859cbc3e9ad107")
