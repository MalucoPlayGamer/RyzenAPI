-- Lua provided by RyzenAPI 
-- Game: fault - milestone one
addappid(286260)
addappid(286261, 1, "634ec92f2ab2aa4880fd8b44b6eb21f082b59749b350e1c6a48b2145118a7726")
addappid(408350)
addappid(441270, 0, "ea0fcdd4ec650d626f896128d64797f087d208041a1b435dab44b27dc83e72a0")
