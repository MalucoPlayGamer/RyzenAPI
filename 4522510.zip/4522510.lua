-- Lua provided by RyzenAPI
-- Game: Kill the Lich Idle

-- MAIN APPLICATION
addappid(4522510)
