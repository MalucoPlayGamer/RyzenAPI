-- Lua provided by RyzenAPI
-- Game: Masked Forces 2: Mystic Demons

-- MAIN APPLICATION
addappid(655000)

-- MAIN APP DEPOTS / PACKAGES
addappid(655001,0,"6f04eebb95bcaaeef0b16bb60e71db828cc2917e16e0f4809dda250343759a9f")
addappid(655002,0,"9ff2b3b95e99aba96abffbd0462cdbb1f8141f4f8f3ac9a0ac2207c7d4dfb825")
addappid(777120,0,"83c2bee6f81f06f3ad99a61de469f77f4a238ff0d6d72f78fd5a99cf5568fd76")
addappid(777121,0,"dc4be9bba2ab2fd83a2835a023aa7d912d9059d3b471a7965894a6f361481c02")

