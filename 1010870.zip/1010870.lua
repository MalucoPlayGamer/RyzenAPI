-- Lua provided by RyzenAPI
-- Game: AppID 1010870

-- MAIN APPLICATION
addappid(1010870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010871, 1, "0b22dfe28f4e2c8868299f0e4b4dbafaef286d67afd51c00cec174017798040e")

