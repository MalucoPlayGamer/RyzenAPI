-- Lua provided by SkyAPI 
-- Game: AppID 1157750
addappid(1157750)
addappid(1157751, 1, "c43d0be5853485b5c760a31329809bc456184a1f7296f1652670336b5317c846")
addappid(1162270, 0, "4e1e80681fc779f084e4b2e59e2eb9dfaf03b4b05cabebababa94ccfc1b9b8bc")
