-- Lua provided by RyzenAPI
-- Game: AppID 679030

-- MAIN APPLICATION
addappid(679030)
-- Game: addappid(679030)

-- MAIN APP DEPOTS / PACKAGES
addappid(679031, 1, "c45911c718b04b3635dcea4926eda3e1286785251b46580ff4728a410c2fdedc")
