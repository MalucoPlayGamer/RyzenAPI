-- Lua provided by SkyAPI 
-- Game: AppID 679030
addappid(679030)
addappid(679031, 1, "c45911c718b04b3635dcea4926eda3e1286785251b46580ff4728a410c2fdedc")
