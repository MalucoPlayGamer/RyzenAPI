-- Lua provided by RyzenAPI
-- Game: Killers and Thieves

-- MAIN APPLICATION
addappid(382330)

-- MAIN APP DEPOTS / PACKAGES
addappid(382331, 1, "5bb64245fbeeaa58cde0e8064903c8a4f1e5ba1266818f8ffc1838b6731e92da")
