-- Lua provided by RyzenAPI
-- Game: 470590

-- MAIN APPLICATION
addappid(470590)
-- Game: addappid(470590)

-- MAIN APP DEPOTS / PACKAGES
addappid(470591, 1, "5bcdd771bb53a7d06591c211fddb971c57dcfd28a69de05a40474ec89d410fdd")
