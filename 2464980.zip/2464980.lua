-- Lua provided by RyzenAPI
-- Game: inFINIte Robotics

-- MAIN APPLICATION
addappid(2464980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464981, 1, "1e7791d3fe9e97a84759a1e558abae80533d41f1008f2aa9bce964fb6d919ae6")

