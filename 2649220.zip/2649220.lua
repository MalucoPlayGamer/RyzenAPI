-- Lua provided by SkyAPI 
-- Game: Run Pizza Run
addappid(2649220)
addappid(2649221, 1, "58151cef58cc8faf0ed3d14b38dacd88565fd5c9749d1d8931201895cdb3693e")
