-- Lua provided by RyzenAPI
-- Game: Run Pizza Run

-- MAIN APPLICATION
addappid(2649220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2649221, 1, "58151cef58cc8faf0ed3d14b38dacd88565fd5c9749d1d8931201895cdb3693e")
