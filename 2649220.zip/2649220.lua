-- Lua provided by RyzenAPI
-- Game: Run Pizza Run

-- MAIN APPLICATION
addappid(2649220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2649221, 1, "58151cef58cc8faf0ed3d14b38dacd88565fd5c9749d1d8931201895cdb3693e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
