-- Lua provided by RyzenAPI
-- Game: Schrödinger's Cat and the Raiders of the Lost Quark

-- MAIN APPLICATION
addappid(295490)

-- MAIN APP DEPOTS / PACKAGES
addappid(295491, 1, "5352d0d86ad223f937aa9f7b4c55c50db155138f66d69287e11a6d774fc2ba26")
addappid(295492, 1, "8af1f8d5e159e464b127f70ba3633e7de6ebbfc831ad9ca869c3e27b9df1e907")
addappid(295493, 1, "ba09a9fc28461f8efc0b539c338f70bc2668c343d2e9e6d44ed5da8fdab910ae")
