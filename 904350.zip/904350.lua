-- Lua provided by RyzenAPI
-- Game: AppID 904350

-- MAIN APPLICATION
addappid(904350)
-- Game: addappid(904350)

-- MAIN APP DEPOTS / PACKAGES
addappid(904351, 1, "910899b133e4b83f0fb35414143a357d8f48615be277eca30aa224f3c902dd19")
