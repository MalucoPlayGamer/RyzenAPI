-- Lua provided by RyzenAPI
-- Game: Army War: Shooting Simulator

-- MAIN APPLICATION
addappid(2290070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290071, 1, "59e6c91feb58137dc68c18b209e823897290896ed0e4141975115eca3a313d37")
