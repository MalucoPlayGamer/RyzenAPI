-- Lua provided by RyzenAPI
-- Game: 2462810

-- MAIN APPLICATION
addappid(2462810)
-- Game: addappid(2462810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462811, 1, "56cf254ec507491a967fae882b6ca682f33279159bd39ea2b95fd24be53500fb")
