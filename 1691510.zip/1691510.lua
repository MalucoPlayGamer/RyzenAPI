-- Lua provided by RyzenAPI
-- Game: Monster Wilds

-- MAIN APPLICATION
addappid(1691510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1691511, 1, "d5d7391bc1200ee409187fe041d12b069f278f6de697801f4a9a1e08ec0312be")

