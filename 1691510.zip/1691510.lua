-- Lua provided by RyzenAPI
-- Game: Monster Wilds

-- MAIN APPLICATION
addappid(1691510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691511, 1, "d5d7391bc1200ee409187fe041d12b069f278f6de697801f4a9a1e08ec0312be")

