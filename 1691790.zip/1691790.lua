-- Lua provided by RyzenAPI
-- Game: addappid(1691790)

-- MAIN APPLICATION
addappid(1691790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691791, 1, "3f0a02c59a55e588c9e0593a2e7ba7b034ebeee7c4ec8cd8703fa33dd3d082be")
