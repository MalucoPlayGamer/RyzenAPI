-- Lua provided by RyzenAPI
-- Game: The Cube Factory

-- MAIN APPLICATION
addappid(1611150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611151, 1, "63ceaa728df8ce79f71fb843bfd5b97a48eaf4f703981d03c9612dc9e2333f3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
