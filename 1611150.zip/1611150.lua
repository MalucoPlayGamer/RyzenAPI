-- Lua provided by RyzenAPI
-- Game: 1611150

-- MAIN APPLICATION
addappid(1611150)
-- Game: addappid(1611150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611151, 1, "63ceaa728df8ce79f71fb843bfd5b97a48eaf4f703981d03c9612dc9e2333f3d")
