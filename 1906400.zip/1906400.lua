-- Lua provided by RyzenAPI
-- Game: Kedama's Adventure

-- MAIN APPLICATION
addappid(1906400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906401, 1, "76f5ef65f24fca581d7ff8a865880ded15538edeb9531d35bebb883e67f4cd56")

