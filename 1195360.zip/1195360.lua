-- Lua provided by RyzenAPI
-- Game: AppID 1195360

-- MAIN APPLICATION
addappid(1195360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195361, 1, "65383cb0dbe8dff2942ae908dbb3156be8211da3b7b4acf08006be86dba8b98c")
