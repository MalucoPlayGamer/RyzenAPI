-- Lua provided by RyzenAPI
-- Game: Z.O.N.A: Origin

-- MAIN APPLICATION
addappid(2539520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2539521, 1, "eb0aca695321a6ad5cdd682ec2eac7d6bab978d2560cf40503730048d0cb8a43")

