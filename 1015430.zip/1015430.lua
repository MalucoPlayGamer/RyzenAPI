-- Lua provided by RyzenAPI
-- Game: The Dead Tree of Ranchiuna

-- MAIN APPLICATION
addappid(1015430)
addappid(1015600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1015431, 1, "0cdf13134af24377289d91b832b2706352c40a7df3a7e4cc9985acde654e8058")
addappid(1015432, 1, "b4e6405c1d689df2dd6758ffc08ea985ec93c5eab6d43e3427a32c7c9da62f69")

