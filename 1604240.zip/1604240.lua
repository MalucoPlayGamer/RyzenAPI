-- Lua provided by RyzenAPI
-- Game: AppID 1604240

-- MAIN APPLICATION
addappid(1604240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604241, 1, "4f71fc9397ccb0b402980d2bbbfe72d3d6d40a15ea56abc5af827b8abcdaa2fd")
