-- Lua provided by SkyAPI 
-- Game: AppID 1604240
addappid(1604240)
addappid(1604241, 1, "4f71fc9397ccb0b402980d2bbbfe72d3d6d40a15ea56abc5af827b8abcdaa2fd")
