-- 4109480's Lua and Manifest Created by Hubcap Manifest
-- MA 2 – President Simulator
-- Created: July 26, 2026 at 03:35:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4109480) -- MA 2 – President Simulator
-- MAIN APP DEPOTS
addappid(4109481, 1, "1992c4cbedc056569f7cad670b91b22d1f289da7659d18ec8f75afa5f0c885fc") -- Depot 4109481
setManifestid(4109481, "5090000193446731572", 3592922090)