-- Lua provided by RyzenAPI
-- Game: Beyond Hanwell

-- MAIN APPLICATION
addappid(2565550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565551, 1, "97e08dc9c8a92304c49389b9890893ffa3dace77807e9ff785390076133b4dc0")

