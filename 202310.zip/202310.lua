-- Lua provided by RyzenAPI
-- Game: Ridge Racer™ Unbounded

-- MAIN APPLICATION
addappid(202310)

-- MAIN APP DEPOTS / PACKAGES
addappid(202311, 1, "3db4398bef927b476744cecb16888a22adf3a07244d0193df95dda99ab1e7fdd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(207110)
addappid(207111)
addappid(207112)
addappid(207113)
addappid(207114)
addappid(207115)
