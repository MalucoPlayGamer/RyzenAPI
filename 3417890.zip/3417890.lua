-- Lua provided by RyzenAPI
-- Game: Game: AppID 3417890

-- MAIN APPLICATION
addappid(3417890)
-- Game: addappid(3417890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3417891, 1, "50a74fe040265efff9c00a86ff5e4e766e04fc6e8c0bd8075a4e7c46906ebc9a")
