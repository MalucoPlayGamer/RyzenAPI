-- Lua provided by RyzenAPI
-- Game: 1388580

-- MAIN APPLICATION
addappid(1388580)
-- Game: addappid(1388580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388581, 1, "ef4b49ecc1bb8c0b0d2a11cfdf26c21ad1e097b9c331d4384e37ffcf48913135")
