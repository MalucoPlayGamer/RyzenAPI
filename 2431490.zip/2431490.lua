-- Lua provided by RyzenAPI
-- Game: 英雄之旅

-- MAIN APPLICATION
addappid(2431490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431491, 1, "fd7745215f5360b7a0c2d8c632e42d71dc48065032f2afbcb4933be32b8aa6f6")
