-- Lua provided by RyzenAPI
-- Game: Darkness and Flame: Enemy in Reflection Collector's Edition

-- MAIN APPLICATION
addappid(1195230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195231, 1, "eba1127da94ba537b6808f7213b01451793620fcdc7b28273a2c92ae9f0fb07d")
addappid(1195232, 1, "d0a8e3f7be0973ad8bdb4cae99017af05d716e8e75484c99aa62f2282fd148d7")
addappid(1195233, 1, "67b733e76de4c8749a6dc7746b0d37b6aff827296a32014533feb6c7012d94e8")

