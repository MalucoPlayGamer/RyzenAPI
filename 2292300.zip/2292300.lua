-- Lua provided by RyzenAPI
-- Game: 2292300

-- MAIN APPLICATION
addappid(2292300)
-- Game: addappid(2292300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292302,0,"4f1155e9d0be958042c9e3e60db0958aca7fc8deb6af0f9355c3ec87dfe06b1a")
