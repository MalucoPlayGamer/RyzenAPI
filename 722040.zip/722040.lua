-- Lua provided by RyzenAPI
-- Game: 722040

-- MAIN APPLICATION
addappid(722040)
-- Game: addappid(722040)

-- MAIN APP DEPOTS / PACKAGES
addappid(722041, 1, "f885c11d259c0b1d150a3d30ec3a102cd8c0b4f23a323389379f353c0ee69393")
