-- Lua provided by RyzenAPI
-- Game: Cloud Meadow

-- MAIN APPLICATION
addappid(1223750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223751, 1, "88d74738f99c281635e93487fe2dd2868ccb7c88dbf1c87dcbb748da80e3e8db")
addappid(1223752, 1, "de4a25bf0aad5f39e9c95f5f55a504bb2bf6aa283f335d47b9213474109c6db1")
