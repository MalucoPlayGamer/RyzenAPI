-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Diaochan (Bride Costume) / 貂蝉 「花嫁風コスチューム」

-- MAIN APPLICATION
addappid(978855)

-- MAIN APP DEPOTS / PACKAGES
addappid(978855,0,"acfae41f6ecf0099bd7cf74069c31a1edc47fc000963bf6cab72b7bca0ec0a57")
