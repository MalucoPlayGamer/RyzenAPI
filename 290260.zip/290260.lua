-- Lua provided by RyzenAPI
-- Game: Game: Sokobond

-- MAIN APPLICATION
addappid(290260)
-- Game: addappid(290260)

-- MAIN APP DEPOTS / PACKAGES
addappid(290261, 1, "ca5455d2146485f2e8fee1662236f810c4ba24b5a5ac85facfcc87db83920ecc")
addappid(290262, 1, "72ca53d0e0624c4d2a494aa9e442afb26c5454ea0a402a71ae472c67938c3e9f")
