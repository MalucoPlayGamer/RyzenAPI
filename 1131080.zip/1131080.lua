-- 1131080's Lua and Manifest Created by Hubcap Manifest
-- Deadswitch 3
-- Created: March 16, 2026 at 17:04:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 6

-- MAIN APPLICATION
addappid(1131080, 1, "77764fd72b796f76afdc5b12bc2c7dbb6fd8b7cb02eb8915f4969d0f7a6cd2e4") -- Deadswitch 3
-- MAIN APP DEPOTS
addappid(1131081, 1, "7fa94ca10d2497f54d0c17fc609ae725af601a09cd3f0b06ef4725303e7b5f2b") -- Deadswitch 3 Content
setManifestid(1131081, "5728837172407452147", 582439452)
addappid(1131082, 1, "da7f7fe4022655e438f641db5030fdbbabc881664254354b6a9faac1c9349776") -- Deadswitch 3 Win32
setManifestid(1131082, "246773246854334759", 504439740)
addappid(1131083, 1, "00925d19822d1ea427ee37af23d1dc4fc710d5b17e9fd06b3e730113d5fcc838") -- Depot 1131083
setManifestid(1131083, "735554731511437659", 703669155)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1641200) -- Deadswitch 3 OpFor Supply Cache
addappid(1641201) -- Deadswitch 3 GIGN Supply Cache
addappid(1641202) -- Deadswitch 3 Militia Supply Cache
addappid(1641203) -- Deadswitch 3 GSG 9 Supply Cache
addappid(1641204) -- Deadswitch 3 Spetsnaz Supply Cache
addappid(1641205) -- Deadswitch 3 Delta Force Supply Cache
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1131084) -- Depot 1131084 (empty depot)