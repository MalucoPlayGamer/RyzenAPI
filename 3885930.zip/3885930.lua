-- Lua provided by RyzenAPI
-- Game: SandTable War: Three Kingdoms

-- MAIN APPLICATION
addappid(3885930)
addappid(4821970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3885931,0,"9b6481c802021cbeb5a31cbe0b9aae244cf26628564bc56fc6ced93dbab503ae")

