-- Lua provided by SkyAPI 
-- Game: Risk of Pain
addappid(2701050)
addappid(2701051, 1, "7864edb8b6458432c3bb6fe80aa4946ce59e97646174c2fc8db6c2494bd53056")
