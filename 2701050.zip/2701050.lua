-- Lua provided by RyzenAPI
-- Game: 2701050

-- MAIN APPLICATION
addappid(2701050)
-- Game: addappid(2701050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701051, 1, "7864edb8b6458432c3bb6fe80aa4946ce59e97646174c2fc8db6c2494bd53056")
