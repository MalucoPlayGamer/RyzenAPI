-- Lua provided by RyzenAPI
-- Game: CubeLoop Demo

-- MAIN APPLICATION
addappid(2012640)
-- Game: addappid(2012640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012641, 1, "70baa27966c1b39f6dc07bdf7bbeba675f3379d51caf86cca218715353ca4dc5")
