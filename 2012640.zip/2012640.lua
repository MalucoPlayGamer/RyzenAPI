-- Lua provided by RyzenAPI 
-- Game: CubeLoop Demo
addappid(2012640)
addappid(2012641, 1, "70baa27966c1b39f6dc07bdf7bbeba675f3379d51caf86cca218715353ca4dc5")
