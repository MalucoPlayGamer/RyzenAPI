-- Lua provided by RyzenAPI
-- Game: Midnight Witch

-- MAIN APPLICATION
addappid(2336180)
