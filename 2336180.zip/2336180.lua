-- Lua provided by RyzenAPI
-- Game: Midnight Witch

-- MAIN APPLICATION
addappid(2336180)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2452880)
