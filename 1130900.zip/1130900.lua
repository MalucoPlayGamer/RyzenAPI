-- Lua provided by RyzenAPI
-- Game: 黎明霞光

-- MAIN APPLICATION
addappid(1130900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1130901, 1, "d43276f0f30ba9da7f5c095735d83cdb230354188cbdccfc35bcdc400cba6986")
