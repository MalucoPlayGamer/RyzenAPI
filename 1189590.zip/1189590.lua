-- Lua provided by RyzenAPI 
-- Game: DEUS EX MACHINA: Stage Zero
addappid(1189590)
addappid(1189591, 1, "a566b1ec4d4fb8d07c6638715969e6c267809e03270ba8082b58d7b71ced0c1b")
