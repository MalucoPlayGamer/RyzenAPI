-- Lua provided by RyzenAPI
-- Game: DEUS EX MACHINA: Stage Zero

-- MAIN APPLICATION
addappid(1189590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189591, 1, "a566b1ec4d4fb8d07c6638715969e6c267809e03270ba8082b58d7b71ced0c1b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
