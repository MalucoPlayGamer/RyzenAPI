-- Lua provided by RyzenAPI
-- Game: Picross for a Cause

-- MAIN APPLICATION
addappid(1373440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373441, 1, "8aa7577f0115c1ba1fa9c09b912f2c249b68fdb6662f9f7c4e204e0e72d5ff6d")

