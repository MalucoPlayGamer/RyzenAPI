-- Lua provided by SkyAPI 
-- Game: Hero's Hour
addappid(1656780)
addappid(1656781, 1, "37cddf2853d31ece5c8318b58d1ff89c02ce22cb6b91c1fc0a5ef8d24ad05779")
addappid(1783690, 0, "1ad0d97edefd2b314e03eee0267dbe7504847834cf62378df09955f00c35fef5")
addappid(2007040)
