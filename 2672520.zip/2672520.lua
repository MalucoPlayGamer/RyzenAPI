-- Lua provided by RyzenAPI
-- Game: 2672520

-- MAIN APPLICATION
addappid(2672520)
-- Game: addappid(2672520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672521, 1, "dc0f909d3f73330ff043de0fc1e562e7776f4dc0f1e443332de1d501c5c2ff35")
