-- Lua provided by RyzenAPI
-- Game: PMC Promiscuity

-- MAIN APPLICATION
addappid(2738670)
-- Game: addappid(2738670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738671, 1, "1a90107a65dd2558c3929d4f7223b6aa8585a2173994c65751f6f4360c17aa9c")
