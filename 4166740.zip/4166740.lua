-- 4166740's Lua and Manifest Created by Hubcap Manifest
-- Ore & Odds
-- Created: August 02, 2026 at 13:07:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4166740, 1, "3ab68e4f1735e1bc9788c16df10ce01e7b6572d0f0d0f05bf4fb07fbd719c42c") -- Ore & Odds
-- MAIN APP DEPOTS
addappid(4166741, 1, "c7c358dc17013b1c9ece3c0e96e6d9d271ca4810eee4cfe250e8c2d774797dea") -- Depot 4166741
setManifestid(4166741, "7297057919748574743", 299745291)