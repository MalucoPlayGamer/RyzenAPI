-- Lua provided by RyzenAPI
-- Game: Ore & Odds

-- MAIN APP DEPOTS / PACKAGES
addappid(4166740, 1, "3ab68e4f1735e1bc9788c16df10ce01e7b6572d0f0d0f05bf4fb07fbd719c42c") -- Ore & Odds
addappid(4166741, 1, "c7c358dc17013b1c9ece3c0e96e6d9d271ca4810eee4cfe250e8c2d774797dea") -- Depot 4166741

