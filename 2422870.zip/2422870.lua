-- Lua provided by RyzenAPI
-- Game: Bronzebeard's Tavern

-- MAIN APPLICATION
addappid(2422870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422871, 1, "5e12c568d89f839c61851e113b653f37285a1c4073f65d40d338cbf0e8c34061")
