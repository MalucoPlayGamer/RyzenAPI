-- Lua provided by RyzenAPI
-- Game: Bronzebeard's Tavern

-- MAIN APPLICATION
addappid(2422870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422871, 1, "5e12c568d89f839c61851e113b653f37285a1c4073f65d40d338cbf0e8c34061")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2800670)
addappid(2899290)
addappid(3277600)
addappid(3402350)
addappid(3402360)
addappid(3650640)
addappid(3650660)
addappid(3650750)
addappid(3828540)
