-- Lua provided by RyzenAPI 
-- Game: Bronzebeard's Tavern
addappid(2422870)
addappid(2422871, 1, "5e12c568d89f839c61851e113b653f37285a1c4073f65d40d338cbf0e8c34061")
