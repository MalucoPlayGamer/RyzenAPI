-- Lua provided by RyzenAPI
-- Game: Undead Realm：Ego

-- MAIN APPLICATION
addappid(3258390)
addappid(3258391)
addappid(3258393)

-- MAIN APP DEPOTS / PACKAGES
addappid(3258392,0,"8e99d447fd16d1350e4e86c7cd40020966e7cb00fdd9de7334f958fc5522c45c")

