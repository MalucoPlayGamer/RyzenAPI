-- Lua provided by RyzenAPI
-- Game: AppID 285270

-- MAIN APPLICATION
addappid(285270)

-- MAIN APP DEPOTS / PACKAGES
addappid(285271, 1, "a81990505a89afd58921f5a848904f6a33e2947f307ee4fd552aeeac1c0be8ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
