-- Lua provided by RyzenAPI
-- Game: AppID 285270

-- MAIN APPLICATION
addappid(285270)

-- MAIN APP DEPOTS / PACKAGES
addappid(285271, 1, "a81990505a89afd58921f5a848904f6a33e2947f307ee4fd552aeeac1c0be8ba")

