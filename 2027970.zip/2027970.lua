-- Lua provided by RyzenAPI
-- Game: Sole Saga

-- MAIN APPLICATION
addappid(2027970)
-- Game: addappid(2027970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027972,0,"04341296658d8d9dcfba616b8db4ccb19b5645fd799fd74ea8cb44293d231bb4")
