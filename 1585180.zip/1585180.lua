-- Lua provided by RyzenAPI
-- Game: Drova - Forsaken Kin

-- MAIN APPLICATION
addappid(229006)
addappid(1585180)
-- Game: addappid(1585180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585182,0,"e3f3f5b9271ecc5008846fdb91f891cfec142053bee010982ef6927466254c52")
