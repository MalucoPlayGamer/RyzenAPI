-- Lua provided by RyzenAPI
-- Game: AppID 887860

-- MAIN APPLICATION
addappid(887860)

-- MAIN APP DEPOTS / PACKAGES
addappid(887861, 1, "0894866fa75d2d330eaf7b86fdb5dd86c30e99ad2e465b425a482cc3fd396ae6")
