-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Movie Trivia

-- MAIN APPLICATION
addappid(845970)

-- MAIN APP DEPOTS / PACKAGES
addappid(845971, 1, "7658bf1a15e9628873ca0e385044db972ec2beaf64543f0e7758ee4d5d52ed13")
