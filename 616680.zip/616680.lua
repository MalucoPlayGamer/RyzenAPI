-- Lua provided by RyzenAPI
-- Game: addappid(616680)

-- MAIN APPLICATION
addappid(616680)

-- MAIN APP DEPOTS / PACKAGES
addappid(616681, 1, "f4ee170c189d8aab26cc40a795d4878489a6f2d9636d66f2d996acb3823db6b1")
