-- Lua provided by RyzenAPI
-- Game: AppID 616680

-- MAIN APPLICATION
addappid(616680)

-- MAIN APP DEPOTS / PACKAGES
addappid(616681, 1, "f4ee170c189d8aab26cc40a795d4878489a6f2d9636d66f2d996acb3823db6b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
