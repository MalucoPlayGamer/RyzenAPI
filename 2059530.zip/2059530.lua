-- Lua provided by RyzenAPI
-- Game: Game: Dawn of Defiance

-- MAIN APPLICATION
addappid(2059530)
addappid(3133780)
-- Game: addappid(2059530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059531, 1, "0e4801f0b0692f017a25532160e3efd4f0607c8ed1d179218d615d77de1fc9c0")
