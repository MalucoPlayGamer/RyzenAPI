-- Lua provided by RyzenAPI
-- Game: Dawn of Defiance

-- MAIN APPLICATION
addappid(2059530)
addappid(3133780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059531, 1, "0e4801f0b0692f017a25532160e3efd4f0607c8ed1d179218d615d77de1fc9c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
