-- Lua provided by RyzenAPI
-- Game: Into The Flames

-- MAIN APPLICATION
addappid(1222300)
-- Game: addappid(1222300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222301, 1, "21dd651ba7ff6d43543c53112d5dfe96d4e425d31065d714776233eb737aa3b6")
