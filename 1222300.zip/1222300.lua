-- Lua provided by RyzenAPI
-- Game: Into The Flames

-- MAIN APPLICATION
addappid(1222300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222301, 1, "21dd651ba7ff6d43543c53112d5dfe96d4e425d31065d714776233eb737aa3b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1381670)
addappid(2406820)
addappid(2406821)
addappid(2560300)
addappid(2641290)
addappid(2664030)
addappid(2752060)
addappid(2752070)
addappid(2763100)
addappid(2942360)
