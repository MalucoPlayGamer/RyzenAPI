-- Lua provided by SkyAPI 
-- Game: 风铃物语 Playtest
addappid(3227050)
addappid(3227051, 1, "1f040046650aa4380ff13411fa588beeabad6a4fd3ced01fe322ba4cf38f95af")
