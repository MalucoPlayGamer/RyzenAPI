-- Lua provided by RyzenAPI
-- Game: addappid(3227050)

-- MAIN APPLICATION
addappid(3227050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227051, 1, "1f040046650aa4380ff13411fa588beeabad6a4fd3ced01fe322ba4cf38f95af")
