-- Lua provided by RyzenAPI
-- Game: Deadzone Haunt

-- MAIN APPLICATION
addappid(3229040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3229041, 1, "f83b433ddaf61a1a4a479cc548140908671e59c52e92f60c0620133fac17c87f")

