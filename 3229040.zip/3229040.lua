-- Lua provided by RyzenAPI 
-- Game: Deadzone Haunt
addappid(3229040)
addappid(3229041, 1, "f83b433ddaf61a1a4a479cc548140908671e59c52e92f60c0620133fac17c87f")
