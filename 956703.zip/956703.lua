-- Lua provided by RyzenAPI
-- Game: Zhang Liao - Officer Ticket / 張遼使用券

-- MAIN APPLICATION
addappid(956703)

-- MAIN APP DEPOTS / PACKAGES
addappid(956703,0,"2851d9f234b6772d6f8e0b090f8a810af99f5d55d45d9dcd8de51742d8504ebb")

