-- Lua provided by RyzenAPI
-- Game: Way to Go!

-- MAIN APPLICATION
addappid(336230)

-- MAIN APP DEPOTS / PACKAGES
addappid(336231, 1, "c25c95d0bd73343c462a45cbfac998e59aa4b6e0cefcb1824310cf767bbb157e")
addappid(336232, 1, "8f9ee48647a58c402d64f0600fca9745e6a10f4c1deb518b5fe7e8a8c8929d0f")
addappid(336233, 1, "f0a5e6cb356adc84cbe99d7873d5577ab005ce2f4019395453428982933dd330")
addappid(336234, 1, "9968863626c45077b414e87338dd48187c464bbfeb7a74ca31376f8a5413639d")
addappid(336235, 1, "38fef7d5b5c8348be9a3a5e500b3a0957f6d5e3906992e6313d72663ce5fb890")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
