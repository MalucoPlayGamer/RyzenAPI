-- Lua provided by RyzenAPI
-- Game: The 9th Gate

-- MAIN APPLICATION
addappid(697130)
addappid(970590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(697131, 1, "347927fa0843e9368782f7c93e2c845859be16b7ea0743ffd3bd064f3971d9ff")

