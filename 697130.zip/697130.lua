-- Lua provided by RyzenAPI
-- Game: addappid(697130)

-- MAIN APPLICATION
addappid(697130)
addappid(970590)

-- MAIN APP DEPOTS / PACKAGES
addappid(697131, 1, "347927fa0843e9368782f7c93e2c845859be16b7ea0743ffd3bd064f3971d9ff")
