-- Lua provided by RyzenAPI
-- Game: addappid(1529890)

-- MAIN APPLICATION
addappid(1529890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529890,0,"a2830afc74dc80370445be9999f6ccbb873a8551efb34a7a72869f40bc9382a5")
