-- Lua provided by RyzenAPI
-- Game: Express 404

-- MAIN APPLICATION
addappid(4329710) -- Express 404

-- MAIN APP DEPOTS / PACKAGES
addappid(4329711, 1, "0f242024efc0140be19490cad79026fc8d7250cfca3a1af58058bdd1e479825e") -- Depot 4329711
