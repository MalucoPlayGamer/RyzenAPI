-- Lua provided by RyzenAPI
-- Game: Supermarket Security Simulator

-- MAIN APPLICATION
addappid(2453380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2453381, 1, "4acdeb8ca024dadf7c80bc20c2854b49fbba914598d9b6510d62a7170f2e112c")

