-- Lua provided by RyzenAPI
-- Game: Supermarket Security Simulator

-- MAIN APPLICATION
addappid(2453380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453381, 1, "4acdeb8ca024dadf7c80bc20c2854b49fbba914598d9b6510d62a7170f2e112c")
