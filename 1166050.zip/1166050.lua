-- Lua provided by SkyAPI 
-- Game: 零下记忆
addappid(1166050)
addappid(1166051, 1, "b57b72aecaed23da533ea40371907726cef49b7847d4de909f1ea8b3994ceaf3")
