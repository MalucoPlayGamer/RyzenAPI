-- Lua provided by RyzenAPI
-- Game: Game: AppID 495800

-- MAIN APPLICATION
addappid(495800)
-- Game: addappid(495800)

-- MAIN APP DEPOTS / PACKAGES
addappid(495801, 1, "448f9b136e21d84e116f0836346fccef91ff6c1a7ab3f64d2ee883c7fe22291c")
