-- Lua provided by RyzenAPI
-- Game: Flipside Studio

-- MAIN APPLICATION
addappid(495800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(495801, 1, "448f9b136e21d84e116f0836346fccef91ff6c1a7ab3f64d2ee883c7fe22291c")

