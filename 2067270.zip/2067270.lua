-- Lua provided by RyzenAPI 
-- Game: Herogue
addappid(2067270)
addappid(2067271, 1, "b228aa4679bc80105f5af1b023e1d487cb8a81bbacb95a6954e89447d7c62dd4")
