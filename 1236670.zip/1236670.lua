-- Lua provided by RyzenAPI
-- Game: Codename: Terranova

-- MAIN APPLICATION
addappid(1236670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1236671, 1, "7c9e713d236ef93923a0221bc8ef984cb2755b8cb8e0b4b835fd856766712a02")
addappid(1236673, 1, "a1bc3d2752ce7905ffdd849bf56df4ea4fc3b33fea20747b43e579b12b363319")

