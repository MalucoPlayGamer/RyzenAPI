-- Lua provided by RyzenAPI
-- Game: Sex Apocalypse

-- MAIN APPLICATION
addappid(1351970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351971, 1, "1a0336e83ca3c3e04efbe82875e4e74a8f469a73f69183f722d275392d0ad972")

