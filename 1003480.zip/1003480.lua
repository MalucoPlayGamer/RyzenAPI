-- Lua provided by RyzenAPI
-- Game: Fireboy & Watergirl: Elements

-- MAIN APPLICATION
addappid(1003480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003482,0,"3fb803dd9fa8204446142208c6ee512b904dd9e53c76ad4ac17c9dc987fe5d41")
addappid(1003483,0,"07a967050b7c6ae61aae1fcec1bd04bc9610f8eeff84b68de6a9ee2a7b61cb23")

