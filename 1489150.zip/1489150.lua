-- Lua provided by SkyAPI 
-- Game: Don't Give Up: Not Ready to Die
addappid(1489150)
addappid(1489151, 1, "ef277b81be540e87e71e3987de2f0f5997d7188fb33417b95e6416b5cbf364c0")
