-- Lua provided by RyzenAPI
-- Game: addappid(1489150)

-- MAIN APPLICATION
addappid(1489150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489151, 1, "ef277b81be540e87e71e3987de2f0f5997d7188fb33417b95e6416b5cbf364c0")
