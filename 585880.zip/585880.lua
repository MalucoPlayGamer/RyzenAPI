-- Lua provided by RyzenAPI
-- Game: Once on a windswept night

-- MAIN APPLICATION
addappid(585880)
-- Game: addappid(585880)

-- MAIN APP DEPOTS / PACKAGES
addappid(585881, 1, "16c204b50bd53fef8362bef9265c51ffdf20830fd5a7e26151007fc2028aa80e")
