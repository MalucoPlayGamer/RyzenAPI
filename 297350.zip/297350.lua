-- Lua provided by RyzenAPI
-- Game: The Old City: Leviathan

-- MAIN APPLICATION
addappid(297350)

-- MAIN APP DEPOTS / PACKAGES
addappid(297351, 1, "c038dc10bcc39442673275a08df77b083079a630e786b2fe0ad2f4109536ce2b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
