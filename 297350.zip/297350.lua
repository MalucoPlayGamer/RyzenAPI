-- Lua provided by RyzenAPI
-- Game: Game: The Old City: Leviathan

-- MAIN APPLICATION
addappid(297350)
-- Game: addappid(297350)

-- MAIN APP DEPOTS / PACKAGES
addappid(297351, 1, "c038dc10bcc39442673275a08df77b083079a630e786b2fe0ad2f4109536ce2b")
