-- Lua provided by RyzenAPI
-- Game: Uncharted Waters Origin Demo

-- MAIN APPLICATION
addappid(2208510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208511, 1, "3083c2c9797cab5a1df903716395b0314defac69f408c50df50a7924675efea8")

