-- Lua provided by RyzenAPI
-- Game: Defenders of Ardania

-- MAIN APPLICATION
addappid(73060)

-- MAIN APP DEPOTS / PACKAGES
addappid(73061, 1, "2151496cc77074faff9c6ffd14d90370b2543e8b6acb7e63dd1aaacc4be794cc")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(200300)
addappid(200310)
