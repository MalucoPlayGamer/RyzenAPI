-- Lua provided by RyzenAPI 
-- Game: Defenders of Ardania
addappid(73060)
addappid(73061, 1, "2151496cc77074faff9c6ffd14d90370b2543e8b6acb7e63dd1aaacc4be794cc")
