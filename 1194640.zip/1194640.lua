-- Lua provided by RyzenAPI
-- Game: addappid(1194640)

-- MAIN APPLICATION
addappid(1194640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194641, 1, "a90c6022d11d1729fc93c42d7ec525f98fdbdf62dc36b00fb7c2a5d4e3e25a02")
