-- Lua provided by RyzenAPI
-- Game: Game: AppID 864410

-- MAIN APPLICATION
addappid(864410)
-- Game: addappid(864410)

-- MAIN APP DEPOTS / PACKAGES
addappid(864411, 1, "1f5054375738d283ea2a81217c245253a2f638e5fdba905a817c73c33d328036")
