-- Lua provided by RyzenAPI
-- Game: DFF NT: Leather Suit Appearance Set for Tifa Lockhart

-- MAIN APPLICATION
addappid(1103741)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103741,0,"383512740098072bf14894d26e69f439d28a73cbd427c012d44341ffad503acb")
