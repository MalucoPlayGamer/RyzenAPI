-- Lua provided by RyzenAPI 
-- Game: Weird and Unfortunate Things Are Happening
addappid(2274410)
addappid(2274411, 1, "a79d52f7ebc9e841be34fb98d7f31bc391b95af2d395d99f004cc9a488b61aad")
