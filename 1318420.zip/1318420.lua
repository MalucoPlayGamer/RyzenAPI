-- Lua provided by RyzenAPI
-- Game: Summer in Mara Prologue

-- MAIN APPLICATION
addappid(1318420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318421, 1, "0c4e4b359cadee4470a20ac326dbd561890c64b4a8a72a349fa3978aa9c23dd7")
