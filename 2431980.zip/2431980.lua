-- Lua provided by RyzenAPI
-- Game: 2431980

-- MAIN APPLICATION
addappid(2431980)
-- Game: addappid(2431980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431981, 1, "b0c98d66718adab3a4c72613304f9fab77f44443b8f367d4d77bdb64651bd370")
