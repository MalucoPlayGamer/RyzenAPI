-- Lua provided by RyzenAPI
-- Game: addappid(3064410)

-- MAIN APPLICATION
addappid(3064410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064411, 1, "3b77e528c6221d0ef283f34c30e6c2f58857ea0b40d686f9ff8d2f9e88288feb")
