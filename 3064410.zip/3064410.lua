-- Lua provided by RyzenAPI
-- Game: 10:59

-- MAIN APPLICATION
addappid(3064410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3064411, 1, "3b77e528c6221d0ef283f34c30e6c2f58857ea0b40d686f9ff8d2f9e88288feb")