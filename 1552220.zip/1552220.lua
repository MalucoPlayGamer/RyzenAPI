-- Lua provided by RyzenAPI
-- Game: LakeSide

-- MAIN APPLICATION
addappid(1552220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552221, 1, "81df78a900617f8ba32fdd112f5b2b8f394d4f054f97df52bf41a82e3953008d")

