-- Lua provided by RyzenAPI
-- Game: Virtual Home Theater VR Video Player Demo

-- MAIN APPLICATION
addappid(1107280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107281, 1, "b9f7dcd31c9f550627c07cfe85bb7ca22e9b70d68377a22fe2145f1fc007307c")

