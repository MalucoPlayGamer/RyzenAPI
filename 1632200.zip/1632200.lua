-- Lua provided by RyzenAPI
-- Game: addappid(1632200)

-- MAIN APPLICATION
addappid(1632200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632201, 1, "d5112992d5a17853baad69a51f7546cec3877ae8deb2afe96befa20eb5f63add")
