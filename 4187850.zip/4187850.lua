-- 4187850's Lua and Manifest Created by Hubcap Manifest
-- The Sculptor
-- Created: August 11, 2026 at 00:21:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4187850) -- The Sculptor
-- MAIN APP DEPOTS
addappid(4187851, 1, "3529457c6764fdc2c2856af33f0b3348fd0a20948f7869d2550db289bdfe7f66") -- Depot 4187851
setManifestid(4187851, "8433655374543829187", 289712356)