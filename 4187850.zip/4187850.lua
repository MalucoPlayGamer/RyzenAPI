-- Lua provided by RyzenAPI
-- Game: The Sculptor

-- MAIN APPLICATION
addappid(4187850) -- The Sculptor

-- MAIN APP DEPOTS / PACKAGES
addappid(4187851, 1, "3529457c6764fdc2c2856af33f0b3348fd0a20948f7869d2550db289bdfe7f66") -- Depot 4187851

