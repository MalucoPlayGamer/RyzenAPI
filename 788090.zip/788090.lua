-- Lua provided by RyzenAPI
-- Game: addappid(788090)

-- MAIN APPLICATION
addappid(788090)
addappid(854200)

-- MAIN APP DEPOTS / PACKAGES
addappid(788091, 1, "b3db951dad05d5ad95d0efb7ab1cad65568567941ac9ad8ce055ff929de83904")
addappid(788093, 1, "06226978f412fcfb79480713ab9de581b8b16475a40059d4ab0e2b257528c5e3")
addappid(788094, 1, "071f230f5da181e0a456f48fcf7aa56c0d867c8d1d4cbcce367138ce1c028460")
addappid(788095, 1, "8f6524819ab2857becc13bdb6ceb697f60d4c5887c7c46ffbb3686f37a06eafd")
