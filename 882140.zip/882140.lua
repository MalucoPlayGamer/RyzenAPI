-- Lua provided by RyzenAPI
-- Game: Reentry - A Space Flight Simulator

-- MAIN APPLICATION
addappid(882140)
-- Game: addappid(882140)

-- MAIN APP DEPOTS / PACKAGES
addappid(882141, 1, "e8a4c82b074733e47bfb4b00964684c992162a8e9eede0fdc716002daa074833")
