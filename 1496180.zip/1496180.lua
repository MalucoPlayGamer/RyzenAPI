-- Lua provided by RyzenAPI
-- Game: Game: Cinderella Phenomenon: Evermore

-- MAIN APPLICATION
addappid(1496180)
-- Game: addappid(1496180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496181, 1, "119e505572252bd3631ab06489a07910d446220c6bde283026c37c7797ebd446")
