-- Lua provided by RyzenAPI 
-- Game: Astrodle Demo
addappid(3003440)
addappid(3003441, 1, "b11e8fc6b9aa8bc44fa92746f80e29d5bfc975bdac441d04b594c5de9f8c48ce")
