-- Lua provided by RyzenAPI 
-- Game: Angel Light The Elven Truce
addappid(772730)
addappid(772731, 1, "0559757a00d272e092cc7ee124e0a4485e35e594767767e3afacf6d09126b61c")
