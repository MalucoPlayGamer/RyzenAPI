-- Lua provided by RyzenAPI
-- Game: 1152390

-- MAIN APPLICATION
addappid(1152390)
addappid(1152391)
-- Game: addappid(1152390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091261,0,"f199c3eac47435c70a23349ea91d7ef2812d69304a6c816bb3766ffa2a5799e7")
