-- Lua provided by RyzenAPI
-- Game: NanoApostle Soundtrack

-- MAIN APPLICATION
addappid(3181990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181991, 1, "198103a23abeca0bded567d8ab9e8bc2744418c4608626ad5d4c3fe9784549b5")
addappid(3181993, 1, "76723193500033b269f38428eea54f29b005b17141b9bef9179dba3f0264e8c3")
