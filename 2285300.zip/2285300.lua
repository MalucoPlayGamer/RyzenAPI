-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2285300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285302,0,"991aed3358752af150f90334090e0d46b7568e394ad52863b1b45fbec11e7987")
