-- Lua provided by RyzenAPI
-- Game: Bus Bound

-- MAIN APPLICATION
addappid(2095420)
addappid(3777100)
addappid(3796390)
addappid(3796400)
addappid(4028530)
addappid(4539690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095421,0,"8c8b97a2cf80ee584aecffb4d2b5ff76c013144d7abf34d7e3c0bbc1c3b8065f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
