-- Lua provided by RyzenAPI
-- Game: Bus Bound

-- MAIN APPLICATION
addappid(2095420)
addappid(3777100)
addappid(3796390)
addappid(3796400)
addappid(4028530)
addappid(4539690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095421,0,"8c8b97a2cf80ee584aecffb4d2b5ff76c013144d7abf34d7e3c0bbc1c3b8065f")

