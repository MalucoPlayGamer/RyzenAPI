-- Lua provided by RyzenAPI
-- Game: addappid(323410)

-- MAIN APPLICATION
addappid(323410)

-- MAIN APP DEPOTS / PACKAGES
addappid(323411, 1, "a739217898941864ad292fa12dff85e2bdbfda34fb2c9d9b9514a17632d8a108")
