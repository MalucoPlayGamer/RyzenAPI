-- Lua provided by RyzenAPI
-- Game: 607040

-- MAIN APPLICATION
addappid(607040)
-- Game: addappid(607040)

-- MAIN APP DEPOTS / PACKAGES
addappid(607041, 1, "966032434b6d53d6a7a5b253f25259af7eae556c7679e5c024dacb6e08c611f2")
