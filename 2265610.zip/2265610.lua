-- Lua provided by RyzenAPI
-- Game: Ashes of War

-- MAIN APPLICATION
addappid(2265610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265612,0,"70c74648aefb505fb944c42431911cb8d8f6e7bcb13b1dd17c89553ca8816ebc")

