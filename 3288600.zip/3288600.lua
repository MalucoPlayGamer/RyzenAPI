-- Lua provided by RyzenAPI 
-- Game: SKIBIDI GYATROOMS
addappid(3288600)
addappid(3288601, 1, "5f5b765fe91a578fb0ba7aa721f349246ce7eb6b914e51d58ec7bf4c7fcf63ec")
