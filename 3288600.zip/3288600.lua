-- Lua provided by RyzenAPI
-- Game: 3288600

-- MAIN APPLICATION
addappid(3288600)
-- Game: addappid(3288600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288601, 1, "5f5b765fe91a578fb0ba7aa721f349246ce7eb6b914e51d58ec7bf4c7fcf63ec")
