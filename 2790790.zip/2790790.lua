-- Lua provided by RyzenAPI
-- Game: 2790790

-- MAIN APPLICATION
addappid(2790790)
-- Game: addappid(2790790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2790791, 1, "d72029dcd6742d6f87e20f983547f63e32e3c1685da8360ea37703fbbc1088c4")
