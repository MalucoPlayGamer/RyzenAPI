-- Lua provided by RyzenAPI
-- Game: Star Stuff Demo

-- MAIN APPLICATION
addappid(1990410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990411, 1, "997575bae1a57605b010b9355f99dd06b84001d602cb33ffc7a231102f207147")

