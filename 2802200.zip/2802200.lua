-- Lua provided by RyzenAPI
-- Game: addappid(2802200)

-- MAIN APPLICATION
addappid(2802200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802201, 1, "f9e56a40a9bb4dfe002cb2276b5b0ad86d931d159109a6df3d88d4a9458b94ae")
