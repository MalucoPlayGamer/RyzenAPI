-- Lua provided by RyzenAPI
-- Game: Dead Link: Pages Torn

-- MAIN APPLICATION
addappid(740070)

-- MAIN APP DEPOTS / PACKAGES
addappid(740071, 1, "cacbcf17802d601d430c1b95838cc4ea5fa8ad55271e185b216b1226cd93fb6e")
