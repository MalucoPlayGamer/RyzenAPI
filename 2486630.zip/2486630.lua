-- Lua provided by RyzenAPI
-- Game: Siren's Call: Escape Velocity Demo

-- MAIN APPLICATION
addappid(2486630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486631, 1, "65524835219991afd2b480db9dffca206169b950893fceaab1eea5738117f86b")
