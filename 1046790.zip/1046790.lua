-- Lua provided by SkyAPI 
-- Game: AppID 1046790
addappid(1046790)
addappid(1046791, 1, "d3b0780aab287c8ca801bc2785c462c71c83815453f795f4c74849e78336c82b")
