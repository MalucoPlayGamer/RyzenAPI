-- Lua provided by RyzenAPI
-- Game: Game: AppID 1046790

-- MAIN APPLICATION
addappid(1046790)
-- Game: addappid(1046790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046791, 1, "d3b0780aab287c8ca801bc2785c462c71c83815453f795f4c74849e78336c82b")
