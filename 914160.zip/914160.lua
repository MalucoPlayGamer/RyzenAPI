-- Lua provided by RyzenAPI
-- Game: Zup! Arena

-- MAIN APPLICATION
addappid(914160)

-- MAIN APP DEPOTS / PACKAGES
addappid(914161, 1, "c733312564a8637b0ff106cf1783ebef4cef1329b3fbaeefc079cf785f1c8eef")
