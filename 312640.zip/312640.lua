-- Lua provided by RyzenAPI
-- Game: Game: Power-Up

-- MAIN APPLICATION
addappid(312640)
-- Game: addappid(312640)

-- MAIN APP DEPOTS / PACKAGES
addappid(312641, 1, "1234439ed6bec6862553cebc893c096758d20627a9da8d4df29db4091571c1f6")
