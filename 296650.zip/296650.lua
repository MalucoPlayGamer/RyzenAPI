-- Lua provided by RyzenAPI
-- Game: The Great Jitters: Pudding Panic

-- MAIN APPLICATION
addappid(296650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(296651, 1, "40625ec73dce5ec5bed995a674c24970f971d40b37fa989b4246785fa2ceb5b0")

