-- Lua provided by SkyAPI 
-- Game: Neon Knights
addappid(3154390)
addappid(3154391, 1, "927d30feb940c700ada2700474a9e25c647606826660ed2f32903cbdc783b9ca")
