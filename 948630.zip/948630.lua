-- Lua provided by RyzenAPI
-- Game: addappid(948630)

-- MAIN APPLICATION
addappid(948630)
addappid(948631)
addappid(948633)
addappid(948634)
addappid(968880)

-- MAIN APP DEPOTS / PACKAGES
addappid(948632,0,"71983f2482360c474ba450cd4e8c0c2eb5fd36e981506dccb77fb455c217d3e4")
