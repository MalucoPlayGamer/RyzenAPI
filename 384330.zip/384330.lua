-- Lua provided by RyzenAPI
-- Game: PolyRace

-- MAIN APPLICATION
addappid(384330)

-- MAIN APP DEPOTS / PACKAGES
addappid(384331, 1, "e7d460470cc923f90d498d6af3cb8e27760d11f1f23f79b07d463239c90ca1c5")

