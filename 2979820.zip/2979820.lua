-- Lua provided by RyzenAPI
-- Game: Chaser of Light

-- MAIN APPLICATION
addappid(2979820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2979821, 1, "8998c7763f7022f8cf7a901b8c73726af892f41d78fe4aa98a01e7330e50ec81")
