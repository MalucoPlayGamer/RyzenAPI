-- Lua provided by RyzenAPI
-- Game: Yawnoc

-- MAIN APPLICATION
addappid(2824730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2824731, 1, "843fe88e06bf58dcfdc9b679923242691eef5bf49b805ad4a690c8782f360b3c")
addappid(2824732, 1, "7d926edc6ed4d99e868b4a5371eecff469d7dc286201bd2f5351229cf4cfbf3b")

