-- Lua provided by RyzenAPI
-- Game: Package Rush

-- MAIN APPLICATION
addappid(1972400)
-- Game: addappid(1972400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972401, 1, "5460324fa05bd300fbacd6cc94e0cbb058e8d74ddc4d39c8f80442a38f8426e5")
