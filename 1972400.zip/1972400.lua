-- Lua provided by RyzenAPI 
-- Game: Package Rush
addappid(1972400)
addappid(1972401, 1, "5460324fa05bd300fbacd6cc94e0cbb058e8d74ddc4d39c8f80442a38f8426e5")
