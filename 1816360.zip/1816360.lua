-- Lua provided by RyzenAPI
-- Game: Game: AppID 1816360

-- MAIN APPLICATION
addappid(1816360)
-- Game: addappid(1816360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816361, 1, "4abb914a0704a882974fde6047b26a978e63a74a17cd0ffad61a7f57436ea38e")
