-- Lua provided by RyzenAPI
-- Game: 2220550

-- MAIN APPLICATION
addappid(2220550)
-- Game: addappid(2220550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220551, 1, "b3604133f4a0713a4665e71e0e3025f5b52e0fae0c17325720fc6949ffe0b11d")
