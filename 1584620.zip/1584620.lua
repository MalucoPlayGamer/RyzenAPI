-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 3: Soundtrack Collection

-- MAIN APPLICATION
addappid(1584620)
-- Game: addappid(1584620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584621, 1, "355620b0f6765ad5356b64d33a682e8ef73ecf9048eea61c86336a7f8c764b4e")
addappid(1584622, 1, "d40dc6c95dd9c65eaa5a8ed21ed1036cc498b25b6603c3ee4eb06f7b5764d7b7")
addappid(1584623, 1, "701e9e0b6e0d008431f9946b1e7fd6ce30b382a38b3d617ba16dc0fd71d1eb53")
addappid(1584624, 1, "5490297f832083fa67be43e936b2456242bfa5f5fb13fa5e00ef22040f5e7bc8")
addappid(1584625, 1, "e40202235f4e41bac172325004b00c33602e9f83cb8b3242637f73102851085c")
addappid(1584626, 1, "db995e4afe9f23824cdb37f9af86121e9345ca7fc6b2fddfbe2270ad61f48c6b")
