-- Lua provided by RyzenAPI
-- Game: Shadow Rebirth

-- MAIN APPLICATION
addappid(2588430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588431, 1, "b1c4825b682108cf75d2b0b8445d871dc00338af6c4890b22423dfc75b986427")
