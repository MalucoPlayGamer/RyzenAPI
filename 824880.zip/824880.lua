-- Lua provided by RyzenAPI
-- Game: addappid(824880)

-- MAIN APPLICATION
addappid(824880)

-- MAIN APP DEPOTS / PACKAGES
addappid(824881, 1, "b59b6749fe5650ac6b4679ccfbe06d1a9e4433dd62e754eae247daa48a67b6ca")
