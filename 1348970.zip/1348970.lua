-- Lua provided by RyzenAPI
-- Game: Ego In A Coma (自我、状態、昏睡。)

-- MAIN APPLICATION
addappid(1348970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348972,0,"d8226f419cca784f4eca42c80c1f0c1de2d5b6e532304bd318b2798731dc15fb")
addappid(1348973,0,"19e75a4e125db5d71c8be19ae8730573e926a646149331d5d7b832840ce8f9d4")

