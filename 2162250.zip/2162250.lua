-- Lua provided by RyzenAPI
-- Game: Lost Eidolons - Artbook & World Map

-- MAIN APPLICATION
addappid(2162250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162250,0,"b32e42fd464f44311079f0f8ea2719cd74d37fcba56832e3654306f08ce7307a")
