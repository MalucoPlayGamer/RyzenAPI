-- Lua provided by RyzenAPI
-- Game: A Turd's Life

-- MAIN APPLICATION
addappid(804400)

-- MAIN APP DEPOTS / PACKAGES
addappid(804401, 1, "d1e675d16b2ddf688f1e0643fa7f02cb34f694425bdb665bc3cb1d7cb9f163ff")
