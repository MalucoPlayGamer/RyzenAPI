-- Lua provided by SkyAPI 
-- Game: AppID 1154810
addappid(1154810)
addappid(1154811, 1, "004d248577aee3f63697e7541f6106753323a90761db6fb0c049ed956650ea66")
