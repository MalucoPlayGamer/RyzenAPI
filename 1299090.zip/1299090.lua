-- Lua provided by RyzenAPI
-- Game: DEEMO -Reborn- Prime Pack I

-- MAIN APPLICATION
addappid(1299090)
-- Game: addappid(1299090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299091, 1, "8770bcbd1a726ee1214b675723010b0de4de0208cc217de705967ee3bae2f091")
addappid(1299092, 1, "434616267002059d021073d8e7ddbc9ac51be14ee99be754fdb22392ff39ed93")
