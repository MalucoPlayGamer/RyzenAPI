-- Lua provided by SkyAPI 
-- Game: Pajama Sam: Games to Play on Any Day
addappid(317020)
addappid(317021, 1, "2496c465a8ed623d0f0abaa5fa43bcee712bc833903c11ddfe729e244e91debd")
addappid(317024, 1, "1e28656463e3353037eddbe38a34ffce91c197404a68aaf234efa628f7227eb4")
addappid(317025, 1, "5ecfe8d8bae7651368af75a63755cf55c04ae5332e1b70980180210d4817775d")
