-- Lua provided by SkyAPI 
-- Game: Witch's Rhythm Puzzle Original Soundtrack
addappid(2509000)
addappid(2509001, 1, "b9fc22de66770592723d170622ad923ffa633a8551dd9790d4103407436b709a")
addappid(2509002, 1, "09f3d0ad7a434ba146d0582d6be9046f2bc084a86da0cc4aa88cd3db59b5dd60")
