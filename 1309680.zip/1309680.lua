-- Lua provided by RyzenAPI
-- Game: Fantastic Petty

-- MAIN APPLICATION
addappid(1309680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309682,0,"09020d5aeaf839afdd51d801331af89123e4149a16eea3a3d7c9748ad0a26f3a")

