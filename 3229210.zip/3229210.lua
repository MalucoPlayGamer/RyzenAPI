-- Lua provided by RyzenAPI
-- Game: Game: Game Of Thrallan

-- MAIN APPLICATION
addappid(3229210)
addappid(3265080)
-- Game: addappid(3229210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3229211, 1, "68c329d8bbd01518cdef6949fcb8301dec46a5ab2bb2e55e3356ffac0fa6fde7")
