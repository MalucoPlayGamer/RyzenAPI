-- Lua provided by RyzenAPI
-- Game: 3280600

-- MAIN APPLICATION
addappid(3280600)
-- Game: addappid(3280600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3280600,0,"393c5e207b5f65ede5c5cc4b83074e5e2ddf683b5b036e90fc3c84ad3e7250b2")
