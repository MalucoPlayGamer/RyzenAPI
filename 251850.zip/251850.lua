-- Lua provided by RyzenAPI 
-- Game: AppID 251850
addappid(251850)
addappid(251851, 1, "8e1833504452ff1a8dd4c81f40ffe6851ea16b2141624cdab1b0d488c8664587")
addappid(251852, 1, "a294b2b6b58374afa5861060080331a52cc92b5c44b7557edb4ef3daec67e1ad")
addappid(271100, 0, "53a2dcc7bfecf9dd2992c931eae89794e9845f0c9cb91ee47f2b1b9a7672a473")
