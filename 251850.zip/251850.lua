-- Lua provided by RyzenAPI
-- Game: Master Reboot

-- MAIN APPLICATION
addappid(251850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(251851, 1, "8e1833504452ff1a8dd4c81f40ffe6851ea16b2141624cdab1b0d488c8664587")
addappid(251852, 1, "a294b2b6b58374afa5861060080331a52cc92b5c44b7557edb4ef3daec67e1ad")
addappid(271100, 0, "53a2dcc7bfecf9dd2992c931eae89794e9845f0c9cb91ee47f2b1b9a7672a473")
