-- Lua provided by RyzenAPI
-- Game: Arctic Combat

-- MAIN APPLICATION
addappid(212370)

-- MAIN APP DEPOTS / PACKAGES
addappid(212374,0,"dcc6411fa1de0612dc0bf827c274206678b860f0e90218e64c7e3751772fca79")

