-- Lua provided by RyzenAPI
-- Game: addappid(419520)

-- MAIN APPLICATION
addappid(419520)

-- MAIN APP DEPOTS / PACKAGES
addappid(419521, 1, "42314d9310116e59e1986d8c7dfbc0354b12d0f11f42f337b1d4adf889e069c0")
