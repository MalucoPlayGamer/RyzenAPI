-- Lua provided by RyzenAPI
-- Game: The You Testament: The 2D Coming

-- MAIN APPLICATION
addappid(2266320)
-- Game: addappid(2266320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266321, 1, "2deae71298e17e1a0b5aaaf8b2e883cbff1c8db9c2958ea521da630e5545d601")
