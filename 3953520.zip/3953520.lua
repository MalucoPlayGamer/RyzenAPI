-- Lua provided by RyzenAPI
-- Game: MU: Dark Epoch

-- MAIN APPLICATION
addappid(3953520)
