-- Lua provided by RyzenAPI
-- Game: The Walking Dead: Saints & Sinners - Chapter 2: Retribution

-- MAIN APPLICATION
addappid(1947500)
addappid(2341660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947501, 1, "3e113ec5caeaabe59a05798925fc253f0d1e16b6bd978ab02787883ed500cb4f")
