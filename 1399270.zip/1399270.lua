-- Lua provided by RyzenAPI
-- Game: Game: The Arena Guy

-- MAIN APPLICATION
addappid(1399270)
-- Game: addappid(1399270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399271, 1, "c129b940fca30f5cb1486ed16612171581e8165e803d3edf296e031517485a30")
