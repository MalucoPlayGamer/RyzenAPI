-- Lua provided by SkyAPI 
-- Game: The Arena Guy
addappid(1399270)
addappid(1399271, 1, "c129b940fca30f5cb1486ed16612171581e8165e803d3edf296e031517485a30")
