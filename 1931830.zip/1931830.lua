-- Lua provided by RyzenAPI
-- Game: Full Service - Healthy Alternative (Doctor Ken) Pack

-- MAIN APPLICATION
addappid(1931830)
addappid(1931831)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931830,0,"1639a6bed3fdecfcb74e8e306e9032ee9f430d20fff1ee48d6eb09bc6ca5311f")
