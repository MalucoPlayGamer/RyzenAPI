-- Lua provided by RyzenAPI
-- Game: addappid(2907190)

-- MAIN APPLICATION
addappid(2907190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2907191, 1, "cf73b509236992139ea197f54a8c5985d8e36271496cf78f5c5fe9c3beda709d")
