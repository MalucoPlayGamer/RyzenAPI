-- Lua provided by RyzenAPI
-- Game: Game: AppID 864940

-- MAIN APPLICATION
addappid(864940)
-- Game: addappid(864940)

-- MAIN APP DEPOTS / PACKAGES
addappid(864941, 1, "62e8f9039e0c952068a837f57a54f1c5cd6dba8e1ffb007543156b7221a81bc6")
