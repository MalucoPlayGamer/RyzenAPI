-- Lua provided by RyzenAPI
-- Game: 1754270

-- MAIN APPLICATION
addappid(1754270)
-- Game: addappid(1754270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754271, 1, "f38e25f58bb339a71882e34dab081ac2f8d76b9b0bfe4f373fb11f7cff63d435")
