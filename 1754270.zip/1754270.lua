-- Lua provided by SkyAPI 
-- Game: AppID 1754270
addappid(1754270)
addappid(1754271, 1, "f38e25f58bb339a71882e34dab081ac2f8d76b9b0bfe4f373fb11f7cff63d435")
