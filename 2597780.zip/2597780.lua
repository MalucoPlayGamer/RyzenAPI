-- Lua provided by RyzenAPI
-- Game: Succubuzz App Demo

-- MAIN APPLICATION
addappid(2597780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597781, 1, "7354b11fe78a0e6a671970347f5b53ddcb05c704c2c1c9cbe9f68bfb78f83044")
