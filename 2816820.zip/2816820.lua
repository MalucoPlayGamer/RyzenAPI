-- Lua provided by RyzenAPI
-- Game: VR Harem Sex ~Fucking the All Girls Around Me~ Demo

-- MAIN APPLICATION
addappid(2816820)
-- Game: addappid(2816820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2816821, 1, "9791604dba0d353060aed4159a2013c294c7e1310c27f533ad49c7f18a36398e")
