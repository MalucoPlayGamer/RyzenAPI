-- Lua provided by SkyAPI 
-- Game: Island Farmer - Jigsaw Puzzle
addappid(1564560)
addappid(1564561, 1, "8577e9a90bd7d2867b6e3da1e27d8625723a6befe5f41553657f6ae6a98c612c")
addappid(1564562, 1, "ee810fe496c0a9edf24d15152aad98bc14b090efd70ef739ab2c7239f06d88d7")
