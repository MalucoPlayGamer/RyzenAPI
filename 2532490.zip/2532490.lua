-- Lua provided by RyzenAPI
-- Game: Rise of Industry 2

-- MAIN APPLICATION
addappid(2532490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532492,0,"409afe57adf3e9b4dc87096612038823adc44f1e83a42b6713e79306bf8d81d3")
addappid(3751110,0,"9b41ba112ee70b935a13d9bfc9ac2bd6a45d092fb4f185d8b65d7a1a8770302c")
