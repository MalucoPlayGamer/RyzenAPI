-- Lua provided by SkyAPI 
-- Game: Vicky Saves the Big Dumb World
addappid(404660)
addappid(404661, 1, "06b0ef2c228a89448ef197528cc2a6432e66e739a37dee3899dc656872fc930f")
