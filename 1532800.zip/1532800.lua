-- Lua provided by RyzenAPI
-- Game: addappid(1532800)

-- MAIN APPLICATION
addappid(1532800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532801, 1, "e1c18b2b2556ade6eeede8aad3f3f54f08574c360b83b263c2d0a085334d2bf9")
