-- Lua provided by RyzenAPI
-- Game: The Dark Pictures Anthology: Little Hope Demo

-- MAIN APPLICATION
addappid(1269060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269061, 1, "0b5431a091494fcb0dfd05a0449416e917560ee76fae142cd524b8832d9c7843")

