-- Lua provided by RyzenAPI
-- Game: Game: Flock!

-- MAIN APPLICATION
addappid(21640)
-- Game: addappid(21640)

-- MAIN APP DEPOTS / PACKAGES
addappid(21641, 1, "199c7dde79c3af4b1b4e5184a3ee8226a97bac461b342b36bf527650a094f3cd")
