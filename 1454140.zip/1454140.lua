-- Lua provided by RyzenAPI
-- Game: SUPERCHICOS

-- MAIN APPLICATION
addappid(1454140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1454141, 1, "f84d1a00354f6ad47bd127e88eeb1ad32cc82a7c2052b7773cbee0025ef9047d")
addappid(1454142, 1, "d611a627b8ae4753705973f60df6ed8b8b0f6f16b30db877e653aaa8eb9fe945")

