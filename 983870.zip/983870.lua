-- Lua provided by RyzenAPI
-- Game: FOUNDRY

-- MAIN APPLICATION
addappid(983870)
addappid(2830490)

-- MAIN APP DEPOTS / PACKAGES
addappid(983870,0,"2ced29f8acc253f69face242ce601e37135dc86e1bf4ce0fef452007ea28b8b9")
addappid(983872,0,"02b02434bbf6af2846d16a87ae33b7f7afe40754b260232f86761b1d16594aaf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
