-- Lua provided by RyzenAPI
-- Game: Mot De Pass

-- MAIN APPLICATION
addappid(1855710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855711, 1, "ce63ad1c740fc04252678392a6d64dfa3d5d8c2f4ffbe6849bc49be110846ac7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
