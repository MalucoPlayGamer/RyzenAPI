-- Lua provided by RyzenAPI
-- Game: Mot De Pass

-- MAIN APPLICATION
addappid(1855710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855711, 1, "ce63ad1c740fc04252678392a6d64dfa3d5d8c2f4ffbe6849bc49be110846ac7")

