-- Lua provided by RyzenAPI
-- Game: Temple of Horror

-- MAIN APPLICATION
addappid(2109700)
-- Game: addappid(2109700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109701, 1, "97cf22c5f475e94540ae499be41741b378eed7a38cc9ab942bf100cfe5c286fb")
