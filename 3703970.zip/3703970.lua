-- Lua provided by RyzenAPI
-- Game: 3703970

-- MAIN APPLICATION
addappid(3703970)
-- Game: addappid(3703970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3703971, 1, "7f4dffa123280c823eb1c769e766d0a607b0294e5567e0abad643a789b575e38")
