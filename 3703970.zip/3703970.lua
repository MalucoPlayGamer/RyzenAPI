-- Lua provided by SkyAPI 
-- Game: Extraordinary Ball
addappid(3703970)
addappid(3703971, 1, "7f4dffa123280c823eb1c769e766d0a607b0294e5567e0abad643a789b575e38")
