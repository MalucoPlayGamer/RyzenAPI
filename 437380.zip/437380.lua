-- Lua provided by RyzenAPI
-- Game: AppID 437380

-- MAIN APPLICATION
addappid(437380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(437381, 1, "82d088d0cc853e6e02254132b128a6afefca57e9d5c898a3825f63e93dbf99a2")

