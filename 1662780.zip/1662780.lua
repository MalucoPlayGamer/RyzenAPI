-- Lua provided by RyzenAPI
-- Game: addappid(1662780)

-- MAIN APPLICATION
addappid(1662780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662781, 1, "d9a592954d64fc75af7fc0cc93e9b825fd7123030dcd586f9c2c0151ecb635f9")
