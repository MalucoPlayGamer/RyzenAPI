-- Lua provided by RyzenAPI
-- Game: Centralia: Homecoming

-- MAIN APPLICATION
addappid(1166740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166741, 1, "49e855d837ed72233d9a82756f905e47a6acfd08874a09e5f2511a46bc13c050")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
