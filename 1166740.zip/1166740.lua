-- Lua provided by RyzenAPI
-- Game: Centralia: Homecoming

-- MAIN APPLICATION
addappid(1166740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166741, 1, "49e855d837ed72233d9a82756f905e47a6acfd08874a09e5f2511a46bc13c050")
