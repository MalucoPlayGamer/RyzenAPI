-- Lua provided by RyzenAPI
-- Game: Pretty Girls Panic!

-- MAIN APPLICATION
addappid(565720)

-- MAIN APP DEPOTS / PACKAGES
addappid(565721, 1, "d269a765beb030c8f55dc191c11d6159353a7514b0f5b94a58055439b7b341f8")
addappid(565722, 1, "d4c8195fe232c606ce07fe91d7270e8a751dde1344bfd31bdff0c7f40f36a176")
