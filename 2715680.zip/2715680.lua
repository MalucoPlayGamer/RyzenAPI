-- Lua provided by RyzenAPI
-- Game: Dangerous Coins

-- MAIN APPLICATION
addappid(2715680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715681, 1, "601ec981d6d07c066ad28b6c78640f6d672f2bd0aa2515ccc349d93f3affe136")
