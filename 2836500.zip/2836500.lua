-- 2836500's Lua and Manifest Created by Hubcap Manifest
-- Mattami Restaurant & Cafe Tycoon
-- Created: July 30, 2026 at 00:13:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2836500) -- Mattami Restaurant & Cafe Tycoon
-- MAIN APP DEPOTS
addappid(2836501, 1, "6f9ed2f9a0880f740c8882876011f24427c0336e47fcca16b88f48bfe8081486") -- Depot 2836501
setManifestid(2836501, "2313039699670073158", 789701223)