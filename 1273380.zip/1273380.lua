-- Lua provided by RyzenAPI 
-- Game: AppID 1273380
addappid(1273380)
addappid(1273381, 1, "43499b68f67ceded0b80a44fc39778b9c07edbe7b5b0f9fb33184859da9ccb16")
