-- Lua provided by RyzenAPI
-- Game: Wholesome - Out and About Playtest

-- MAIN APPLICATION
addappid(3787370)
-- Game: addappid(3787370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3787371, 1, "efd64f1593218c3ec17724b1f470dcaab38675290a409e2df61208d41c19d1a6")
