-- Lua provided by RyzenAPI
-- Game: Hentai Milf Quiz

-- MAIN APPLICATION
addappid(1339890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339891, 1, "a005dccbff4285d53d27c8553d69855f2151a1650dc94ee55d87bf96079e30a0")

