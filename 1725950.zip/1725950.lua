-- Lua provided by RyzenAPI
-- Game: 魔塔地牢

-- MAIN APPLICATION
addappid(1725950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725951, 1, "84a861d76b157b4729f0bffbd15255b98bad47300252ab0e88221f7a375eb3f5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1726320)
addappid(2402970)
addappid(2402971)
