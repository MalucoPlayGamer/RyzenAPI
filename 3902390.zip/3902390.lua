-- Lua provided by RyzenAPI
-- Game: Tokyo Hotel

-- MAIN APPLICATION
addappid(3902390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3902391, 1, "7a0788032783668a19f153a698afb64c6e0f6c88ee156a6900b4656cf8a76db2")
