-- Lua provided by RyzenAPI
-- Game: Fallen valiant-Loopy

-- MAIN APPLICATION
addappid(1096120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096121, 1, "34df61c1902b52cbc045f982fe2b2a3fe7057e6b86ead30908713bbd17847ae5")
