-- Lua provided by RyzenAPI
-- Game: Game: AppID 2056920

-- MAIN APPLICATION
addappid(2056920)
-- Game: addappid(2056920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056921, 1, "f53cb57fd8732715fc5b44339f38465f389e330225928ffff93fd5ee825513a3")
