-- Lua provided by RyzenAPI
-- Game: addappid(234980)

-- MAIN APPLICATION
addappid(234980)

-- MAIN APP DEPOTS / PACKAGES
addappid(234981, 1, "7b264bd7741e480079e2518bfee84529f8a0935e9d08d2278d9bc0cc83ea354c")
