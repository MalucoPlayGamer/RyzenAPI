-- Lua provided by RyzenAPI
-- Game: Legends of Dawn

-- MAIN APPLICATION
addappid(234980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(234981, 1, "7b264bd7741e480079e2518bfee84529f8a0935e9d08d2278d9bc0cc83ea354c")
