-- Lua provided by RyzenAPI
-- Game: Quarantine Zone: The Last Check Playtest

-- MAIN APPLICATION
addappid(3494970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3494971, 1, "352a45ecf2c7bcfcf9a97e5315c5a6d750cfc85c97e95ff198e8c9e811fb478d")
