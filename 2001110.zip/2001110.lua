-- Lua provided by RyzenAPI
-- Game: Roguematch : The Extraplanar Invasion

-- MAIN APPLICATION
addappid(2001110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001111, 1, "36fa70172a0686669127410e8ba9b4f42a519d771ff3c850f4b0e89d2d469938")

