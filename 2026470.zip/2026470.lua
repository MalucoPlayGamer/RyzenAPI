-- Lua provided by RyzenAPI
-- Game: Game: Cyber Blades - Demo

-- MAIN APPLICATION
addappid(2026470)
-- Game: addappid(2026470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026471, 1, "7de44a8ebe901ff6e16536c77baccde5006418645a2a9cf6d925b69fad87c0f6")
