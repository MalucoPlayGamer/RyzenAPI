-- Lua provided by RyzenAPI
-- Game: StepX

-- MAIN APPLICATION
addappid(711210)

-- MAIN APP DEPOTS / PACKAGES
addappid(711211, 1, "3d87174492d4b178f520a54afa3cc88aa486e1effc8277be6535f8c1d545f906")
