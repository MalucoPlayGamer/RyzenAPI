-- Lua provided by RyzenAPI
-- Game: California Swingers Club - Season 1: Sea Swap

-- MAIN APPLICATION
addappid(2804310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804311, 1, "1156be0f2d0d8034493e9a232a6b2a9b88956433f10d91c591267342e2fe5cbe")

