-- Lua provided by RyzenAPI
-- Game: Nine Hentai Babes

-- MAIN APPLICATION
addappid(999290)

-- MAIN APP DEPOTS / PACKAGES
addappid(999291, 1, "be906f1dcacd1af50519b731f558350a38f300e96e90d4500dac58724b5a40c8")

