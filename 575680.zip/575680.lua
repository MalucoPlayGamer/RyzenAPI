-- Lua provided by RyzenAPI
-- Game: Game: AppID 575680

-- MAIN APPLICATION
addappid(575680)
-- Game: addappid(575680)

-- MAIN APP DEPOTS / PACKAGES
addappid(575681, 1, "0a3e75968aacffc777844101637d8582e22925ede37fc86cdb93908db92b8795")
