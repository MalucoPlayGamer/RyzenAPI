-- Lua provided by RyzenAPI
-- Game: Luxury Supermarket Simulator

-- MAIN APPLICATION
addappid(3403920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3403921, 1, "96843d1216958ee47c8cccbd853d8d6815626853b15bcad33276b983996f3b41")
