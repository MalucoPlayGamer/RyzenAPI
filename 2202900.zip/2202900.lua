-- Lua provided by RyzenAPI
-- Game: Out of the ground

-- MAIN APPLICATION
addappid(2202900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202901, 1, "0bf9144ce0b0aa0e9c55c6fb54781a03c22cafedf584cef512e28994bcc5b306")
