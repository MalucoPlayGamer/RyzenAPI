-- Lua provided by RyzenAPI
-- Game: Spellmasons

-- MAIN APPLICATION
addappid(1618380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618381, 1, "73b59d122bc607f560ad7ec96098492cc814e8422218ddabad14a17a4503cb92")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4026960)
addappid(4866100)
