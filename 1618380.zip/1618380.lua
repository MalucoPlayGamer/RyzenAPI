-- Lua provided by SkyAPI 
-- Game: Spellmasons
addappid(1618380)
addappid(1618381, 1, "73b59d122bc607f560ad7ec96098492cc814e8422218ddabad14a17a4503cb92")
