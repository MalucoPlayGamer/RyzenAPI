-- Lua provided by RyzenAPI
-- Game: Police Helicopter Simulator

-- MAIN APPLICATION
addappid(803890)

-- MAIN APP DEPOTS / PACKAGES
addappid(803891, 1, "6e6af1192f63497aaac2365f55069482976c25c1709112100e952e8aef7986bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
