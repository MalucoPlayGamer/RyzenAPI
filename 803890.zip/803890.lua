-- Lua provided by RyzenAPI
-- Game: Police Helicopter Simulator

-- MAIN APPLICATION
addappid(803890)
-- Game: addappid(803890)

-- MAIN APP DEPOTS / PACKAGES
addappid(803891, 1, "6e6af1192f63497aaac2365f55069482976c25c1709112100e952e8aef7986bf")
