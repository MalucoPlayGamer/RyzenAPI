-- Lua provided by RyzenAPI
-- Game: Game: AppID 721090

-- MAIN APPLICATION
addappid(721090)
-- Game: addappid(721090)

-- MAIN APP DEPOTS / PACKAGES
addappid(721091, 1, "2ee99b3c051f5c5307da6bd71a8024d0b01313d2c3a829cbcd007e3eaa76e573")
