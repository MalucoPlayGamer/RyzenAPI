-- Lua provided by RyzenAPI
-- Game: SKYBOX VR Video Player

-- MAIN APPLICATION
addappid(721090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(721091, 1, "2ee99b3c051f5c5307da6bd71a8024d0b01313d2c3a829cbcd007e3eaa76e573")
