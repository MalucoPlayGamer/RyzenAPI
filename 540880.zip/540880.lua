-- Lua provided by RyzenAPI
-- Game: Rose of Winter

-- MAIN APPLICATION
addappid(540880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(540881, 1, "346587bbb7ed92ef72638d7da70aa7f39f85a7d6608441da59f85e7cbbcf4b81")
addappid(540885, 1, "688db78d016410bb8b4a249150936a4a14be0b6f64b8e343c72f17abc7a419e7")
