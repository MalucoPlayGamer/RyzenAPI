-- Lua provided by RyzenAPI
-- Game: 赫炎的印加诺克 Fullvoice ReBORN

-- MAIN APPLICATION
addappid(982400)
addappid(1268210)

-- MAIN APP DEPOTS / PACKAGES
addappid(982401,0,"296cd35ec5171a0e73bde69733b199724f27d16bd9ffedeaa8b066ac3652b1d9")
addappid(982402,0,"4de741b516f629d1eabf953647f7d6dd4aa2409c2f144f130bbd9bfc405fdbf2")

