-- Lua provided by RyzenAPI
-- Game: 982400

-- MAIN APPLICATION
addappid(982400)
-- Game: addappid(982400)

-- MAIN APP DEPOTS / PACKAGES
addappid(982401, 1, "296cd35ec5171a0e73bde69733b199724f27d16bd9ffedeaa8b066ac3652b1d9")
addappid(982402, 1, "4de741b516f629d1eabf953647f7d6dd4aa2409c2f144f130bbd9bfc405fdbf2")
