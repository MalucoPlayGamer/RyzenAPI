-- Lua provided by RyzenAPI
-- Game: Space Maze

-- MAIN APPLICATION
addappid(873500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(873501, 1, "c526da2afe5584eaf6b59f78db02d8ff427f780db0f9d33fe0fd05a24eb22bd9")

