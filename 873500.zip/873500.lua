-- Lua provided by RyzenAPI
-- Game: Space Maze

-- MAIN APPLICATION
addappid(873500)
-- Game: addappid(873500)

-- MAIN APP DEPOTS / PACKAGES
addappid(873501, 1, "c526da2afe5584eaf6b59f78db02d8ff427f780db0f9d33fe0fd05a24eb22bd9")
