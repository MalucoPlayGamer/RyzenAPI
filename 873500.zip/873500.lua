-- Lua provided by SkyAPI 
-- Game: Space Maze
addappid(873500)
addappid(873501, 1, "c526da2afe5584eaf6b59f78db02d8ff427f780db0f9d33fe0fd05a24eb22bd9")
