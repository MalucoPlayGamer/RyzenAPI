-- Lua provided by RyzenAPI 
-- Game: The Dream Collector
addappid(750850)
addappid(750851, 1, "a46ad887fd73861728564d512d102d8cde232409a98daa5a92d0a7875aa36fcd")
