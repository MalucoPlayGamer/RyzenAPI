-- Lua provided by RyzenAPI
-- Game: AppID 1233990

-- MAIN APPLICATION
addappid(1233990)
-- Game: addappid(1233990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233991, 1, "9d171e893e0765967a6ae54785145c87b50ca21ddaed0f456b30ca12875c064f")
