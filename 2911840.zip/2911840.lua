-- Lua provided by RyzenAPI
-- Game: Game: Descensus Demo

-- MAIN APPLICATION
addappid(2911840)
-- Game: addappid(2911840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911841, 1, "05feb3276004b1c0e7b3caebd29bf1540c28c92f14530cc4c83e2217de120b9c")
