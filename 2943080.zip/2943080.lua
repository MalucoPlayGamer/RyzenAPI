-- Lua provided by RyzenAPI
-- Game: C.A.R.D.S. RPG: The Misty Battlefield  - Artbook

-- MAIN APPLICATION
addappid(2943080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943080,0,"e219447084019890ffaa6af2c551a70d2806f44d68321148ede162b69a60b09c")
