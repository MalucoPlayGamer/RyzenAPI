-- Lua provided by RyzenAPI
-- Game: Game: DARK SPHERE

-- MAIN APPLICATION
addappid(1500120)
addappid(2273360)
-- Game: addappid(1500120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500121, 1, "ef416e5832a654825fd87a67008064199bdc6bb162ef62582f3f4d542a063593")
