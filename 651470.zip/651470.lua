-- Lua provided by RyzenAPI
-- Game: Onirim - Solitaire Card Game

-- MAIN APPLICATION
addappid(651470)
addappid(651480)
addappid(651481)

