-- Lua provided by RyzenAPI
-- Game: Onirim - Solitaire Card Game

-- MAIN APPLICATION
addappid(651470)
