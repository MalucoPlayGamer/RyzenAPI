-- Lua provided by RyzenAPI
-- Game: Onirim - Solitaire Card Game

-- MAIN APPLICATION
addappid(651470)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(651480)
addappid(651481)
