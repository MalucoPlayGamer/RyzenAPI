-- Lua provided by RyzenAPI
-- Game: Firebird - Steam version

-- MAIN APPLICATION
addappid(829490)

-- MAIN APP DEPOTS / PACKAGES
addappid(829491, 1, "e209334e6fdccaf54b756542dc0eeddb4da34ec5427f698045a76ab88fe7240a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
