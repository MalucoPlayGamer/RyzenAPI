-- Lua provided by RyzenAPI
-- Game: 829490

-- MAIN APPLICATION
addappid(829490)
-- Game: addappid(829490)

-- MAIN APP DEPOTS / PACKAGES
addappid(829491, 1, "e209334e6fdccaf54b756542dc0eeddb4da34ec5427f698045a76ab88fe7240a")
