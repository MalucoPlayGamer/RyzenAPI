-- Lua provided by RyzenAPI
-- Game: AppID 1310080

-- MAIN APPLICATION
addappid(1310080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310081, 1, "c0079c42938cec168675356ab15c03b0aff09e1355079a3578f7b7100d3336cf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
