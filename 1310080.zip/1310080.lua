-- Lua provided by RyzenAPI
-- Game: Game: AppID 1310080

-- MAIN APPLICATION
addappid(1310080)
-- Game: addappid(1310080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310081, 1, "c0079c42938cec168675356ab15c03b0aff09e1355079a3578f7b7100d3336cf")
