-- Lua provided by RyzenAPI
-- Game: Game: AppID 1623860

-- MAIN APPLICATION
addappid(1623860)
-- Game: addappid(1623860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623861, 1, "857e841aba03765d3ae2407d50bb0747b519e548c856f5d228f1163172f5a9de")
