-- Lua provided by SkyAPI 
-- Game: Missing Banban
addappid(3113680)
addappid(3113681, 1, "174d479a2c0657ad7755534a7a005230bebfbedd36f2ee0607d3354b5ea0b9b2")
