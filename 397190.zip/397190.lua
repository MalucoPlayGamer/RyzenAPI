-- Lua provided by RyzenAPI
-- Game: addappid(397190)

-- MAIN APPLICATION
addappid(397190)

-- MAIN APP DEPOTS / PACKAGES
addappid(397191, 1, "58780f55bedd88037c768589b72bc21702d20e80bb378324f28eaf7e58b6db5c")
