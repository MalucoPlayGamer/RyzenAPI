-- Lua provided by RyzenAPI 
-- Game: Sengoku Jidai: Shadow of the Shogun
addappid(397190)
addappid(397191, 1, "58780f55bedd88037c768589b72bc21702d20e80bb378324f28eaf7e58b6db5c")
