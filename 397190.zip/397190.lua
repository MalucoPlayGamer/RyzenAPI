-- Lua provided by RyzenAPI
-- Game: Sengoku Jidai: Shadow of the Shogun

-- MAIN APPLICATION
addappid(397190)

-- MAIN APP DEPOTS / PACKAGES
addappid(397191, 1, "58780f55bedd88037c768589b72bc21702d20e80bb378324f28eaf7e58b6db5c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(461930)
addappid(461931)
addappid(461932)
addappid(461933)
addappid(461934)
addappid(461935)
addappid(502360)
addappid(502361)
