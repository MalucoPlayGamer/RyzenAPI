-- Lua provided by RyzenAPI 
-- Game: Space Scumbags
addappid(660270)
addappid(660271, 1, "812983a33ad256d6918caeb094954d5c5b0a204eb705945f0924cdb30586342a")
