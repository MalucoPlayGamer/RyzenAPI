-- Lua provided by RyzenAPI
-- Game: Space Scumbags

-- MAIN APPLICATION
addappid(660270)
-- Game: addappid(660270)

-- MAIN APP DEPOTS / PACKAGES
addappid(660271, 1, "812983a33ad256d6918caeb094954d5c5b0a204eb705945f0924cdb30586342a")
