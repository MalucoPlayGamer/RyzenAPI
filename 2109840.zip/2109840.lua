-- Lua provided by RyzenAPI 
-- Game: the Shadow of Swallow
addappid(2109840)
addappid(2109841, 1, "31cdb5162adf1c805e93fb10342aa1cec6431f9516706a4f078c272badba573d")
