-- Lua provided by RyzenAPI
-- Game: Game: the Shadow of Swallow

-- MAIN APPLICATION
addappid(2109840)
-- Game: addappid(2109840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109841, 1, "31cdb5162adf1c805e93fb10342aa1cec6431f9516706a4f078c272badba573d")
