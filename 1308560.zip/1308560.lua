-- Lua provided by RyzenAPI
-- Game: The Legend of HyperStar

-- MAIN APPLICATION
addappid(1308560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308561, 1, "0583fbaf5eb0b743f1881c019da3ca39f62a62bfbdf9d6ade1c7ec72ac105a3d") -- (windows)
