-- Lua provided by RyzenAPI
-- Game: 1433960

-- MAIN APPLICATION
addappid(1433960)
-- Game: addappid(1433960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433961, 1, "3741b336e8acb15911c92c9ff472be32f8fc735f5bda7d75e36048735a39ed4c")
