-- Lua provided by RyzenAPI
-- Game: Merge & Blade

-- MAIN APPLICATION
addappid(1446930)
addappid(2327290)
addappid(2381120)
addappid(2381121)
addappid(2381130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446931, 1, "17f9315af84898ae542da0e94c1c97e34b7cd337f04243e9eaf7b135eb5c8434")

