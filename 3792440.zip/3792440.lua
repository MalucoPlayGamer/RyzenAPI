-- Lua provided by RyzenAPI
-- Game: VISIONS of MANA Original Soundtrack

-- MAIN APPLICATION
addappid(3792440)
-- Game: addappid(3792440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3792441, 1, "3fa6754a5f4c1a90418caa9cbf231ced4c87a88d05cebdf70f278c31c0537edb")
