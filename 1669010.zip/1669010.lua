-- Lua provided by RyzenAPI
-- Game: Game: Virtual Driving School Demo

-- MAIN APPLICATION
addappid(1669010)
-- Game: addappid(1669010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669011, 1, "a6dccf07e8f01edda06a4589bc272a77f7e7a88428da1522d58fb162f903abde")
