-- Lua provided by RyzenAPI
-- Game: AppID 227700

-- MAIN APPLICATION
addappid(227700)
addappid(228982)
addappid(228985)
addappid(228990)
addappid(229000)
addappid(310090)
addappid(310091)
addappid(334400)
addappid(334401)
addappid(334402)
addappid(432880)

-- MAIN APP DEPOTS / PACKAGES
addappid(227701, 1, "dfd265efd149b5faf48f88bb7f1162f802ace723ff0c734c2f943bfee80d5111")

