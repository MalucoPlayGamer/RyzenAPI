-- Lua provided by RyzenAPI
-- Game: Game: Failed Adventurer

-- MAIN APPLICATION
addappid(1349850)
-- Game: addappid(1349850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349851, 1, "52eeeedad4c8cfaf8cc858c0fc8e3795acb64ec5f71d97ce2f27d6f9fe70873b")
