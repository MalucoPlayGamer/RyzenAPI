-- Lua provided by RyzenAPI
-- Game: 1926630

-- MAIN APPLICATION
addappid(1926630)
-- Game: addappid(1926630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926631, 1, "ba03d753b23221b88f8cd05767fb4cbafed0451fcb30869dc7f5da730650e903")
