-- Lua provided by RyzenAPI
-- Game: Arrive In Time

-- MAIN APPLICATION
addappid(3071060)
-- Game: addappid(3071060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071061, 1, "d286d7a0eef4cace8320708d4f61b9df8b0408c1c3b75781ed02bd9245ed41c5")
