-- Lua provided by RyzenAPI
-- Game: Game: TRUFFLE: Classic

-- MAIN APPLICATION
addappid(1815550)
-- Game: addappid(1815550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815551, 1, "aef17780d6ba89f058f81a182e56357e0ecdb43f9684965f87dbec13e47a8a8e")
