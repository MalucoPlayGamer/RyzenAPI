-- Lua provided by RyzenAPI 
-- Game: TRUFFLE: Classic
addappid(1815550)
addappid(1815551, 1, "aef17780d6ba89f058f81a182e56357e0ecdb43f9684965f87dbec13e47a8a8e")
