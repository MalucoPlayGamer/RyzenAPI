-- Lua provided by RyzenAPI
-- Game: 1093790

-- MAIN APPLICATION
addappid(1093790)
-- Game: addappid(1093790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093791, 1, "df2a935844efaba089fc8e4b44fb077c36721e82601658ba36739616e5a08b47")
