-- Lua provided by RyzenAPI
-- Game: The Adventures of LinShanHai - Chapter4:Vanishing Masterpiece

-- MAIN APPLICATION
addappid(2389880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2389881, 1, "643dc71106ea1186dab8b8fa55a0b16fbd8463a9cb1978110a8987e7972117c5")

