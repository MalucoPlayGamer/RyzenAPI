-- Lua provided by RyzenAPI
-- Game: The Adventures of LinShanHai - Chapter4:Vanishing Masterpiece

-- MAIN APPLICATION
addappid(2389880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389881, 1, "643dc71106ea1186dab8b8fa55a0b16fbd8463a9cb1978110a8987e7972117c5")
