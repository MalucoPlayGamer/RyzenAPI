-- Lua provided by RyzenAPI
-- Game: Space Hat

-- MAIN APPLICATION
addappid(2805210)
-- Game: addappid(2805210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805212,0,"e7ade5f01b79a44e36788102d5461cb54f04972c2448051b4b6e8d9f8def2784")
