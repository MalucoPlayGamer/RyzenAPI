-- Lua provided by RyzenAPI
-- Game: 2920830

-- MAIN APPLICATION
addappid(2920830)
-- Game: addappid(2920830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920831, 1, "ff3684e53a4ae3709b620503aa0f80abcd054af61d153dc2f4555cc1f562dbf6")
