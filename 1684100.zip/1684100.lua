-- Lua provided by RyzenAPI
-- Game: Halluci-Sabbat of Koishi

-- MAIN APPLICATION
addappid(1684100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684101, 1, "5f25649f14ebfebeb81cc617218e9ed5418475d0241f6d6cf70664969c648774")
