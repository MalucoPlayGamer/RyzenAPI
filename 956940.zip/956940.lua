-- Lua provided by RyzenAPI
-- Game: Guan Yinping - Officer Ticket / 関銀屏使用券

-- MAIN APPLICATION
addappid(956940)

-- MAIN APP DEPOTS / PACKAGES
addappid(956940,0,"81099d72f7e443216b8dd51b71c36b00e45225e656c643eed9ef2084093a8599")

