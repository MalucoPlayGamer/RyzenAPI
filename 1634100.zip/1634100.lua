-- Lua provided by RyzenAPI
-- Game: No More Rainbows

-- MAIN APPLICATION
addappid(1634100)
-- Game: addappid(1634100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634101, 1, "9a701dbda26a7b7ceb858f9764c02a22580898fd2651191d19c36c9e61c23078")
