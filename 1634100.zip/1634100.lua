-- Lua provided by SkyAPI 
-- Game: No More Rainbows
addappid(1634100)
addappid(1634101, 1, "9a701dbda26a7b7ceb858f9764c02a22580898fd2651191d19c36c9e61c23078")
