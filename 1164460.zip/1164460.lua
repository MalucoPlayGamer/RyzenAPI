-- Lua provided by RyzenAPI
-- Game: Monospaced Lovers

-- MAIN APPLICATION
addappid(1164460)
-- Game: addappid(1164460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164461, 1, "5976e5100687ece68fbf04e72718f40a652659e7d2984fa76773fd538d9a7e0f")
