-- Lua provided by RyzenAPI
-- Game: AppID 489580

-- MAIN APPLICATION
addappid(489580)
-- Game: addappid(489580)

-- MAIN APP DEPOTS / PACKAGES
addappid(489581, 1, "3d05377b5dc5c6163d6dee0ea3576b9e09079f5fa5b6365dc68f4d5bbd4aead4")
