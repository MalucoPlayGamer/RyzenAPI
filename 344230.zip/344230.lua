-- Lua provided by RyzenAPI 
-- Game: Pixel Puzzles 2: Birds
addappid(344230)
addappid(344231, 1, "f1dc57986fab6c00460e2503fad777909c0c17d43d2a75f7fde0a285c6fdd24b")
