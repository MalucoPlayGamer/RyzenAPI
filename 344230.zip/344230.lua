-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles 2: Birds

-- MAIN APPLICATION
addappid(344230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(344231, 1, "f1dc57986fab6c00460e2503fad777909c0c17d43d2a75f7fde0a285c6fdd24b")

