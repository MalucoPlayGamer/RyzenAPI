-- Lua provided by RyzenAPI
-- Game: Prince Maker美少年梦工厂3：重生

-- MAIN APPLICATION
addappid(1055760)
addappid(1059910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1055761, 1, "af85a49502dd6f972a6b979609a5e6e88543e09cb1a498a1f83566c952c3ed01")

