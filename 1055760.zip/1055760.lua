-- Lua provided by RyzenAPI
-- Game: Prince Maker美少年梦工厂3：重生

-- MAIN APPLICATION
addappid(1055760)
addappid(1059910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055761, 1, "af85a49502dd6f972a6b979609a5e6e88543e09cb1a498a1f83566c952c3ed01")

