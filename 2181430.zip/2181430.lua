-- Lua provided by RyzenAPI
-- Game: 三国群英志

-- MAIN APPLICATION
addappid(2181430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181431, 1, "eeb073c90cf5e5522e4544993c080417011689f8444a4d1fffb3b7bada38e221")

