-- Lua provided by RyzenAPI
-- Game: Game: Nothing

-- MAIN APPLICATION
addappid(2696480)
-- Game: addappid(2696480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696481, 1, "750deef447eacbd3a084fee30ee731d9209db446a495612845f8142707714111")
