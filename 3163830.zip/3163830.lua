-- Lua provided by RyzenAPI
-- Game: addappid(3163830)

-- MAIN APPLICATION
addappid(3163830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163831, 1, "9f14f7a8240c74ae1b4d8b4db805300d4309b20eeffbea15fc4be2d932b5201e")
