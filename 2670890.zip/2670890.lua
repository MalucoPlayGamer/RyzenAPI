-- Lua provided by RyzenAPI
-- Game: AppID 2670890

-- MAIN APPLICATION
addappid(2670890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670891, 1, "23d515ace47b385411bbea716a851c79f5820dfa34ed0a82eff6a9d31a859e8f")
