-- Lua provided by RyzenAPI 
-- Game: Around The World
addappid(2007130)
addappid(2007131, 1, "95af8e959404ca132c5b8b3a09c8c915074b18bee38a852d16d6acfd9062a806")
addappid(2007132, 1, "261ef46ca41cead92425d4741cd26e3bc79af9e28f9cee2391e9eb954d8872ab")
addappid(2007133, 1, "67c902414eb3f4d9fcfb4338e169f4dcb34cb4bb7a2b1fd7e61a8b36afcb8143")
