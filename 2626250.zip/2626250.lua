-- Lua provided by RyzenAPI
-- Game: Game: AppID 2626250

-- MAIN APPLICATION
addappid(2626250)
-- Game: addappid(2626250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626251, 1, "3f7c2d2bda65dc95a5e144f8b0bcd271601a7e8b35882f7530b4ce23f524b1ee")
