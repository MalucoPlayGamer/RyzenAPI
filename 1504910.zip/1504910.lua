-- Lua provided by RyzenAPI
-- Game: addappid(1504910)

-- MAIN APPLICATION
addappid(1504910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504911, 1, "5f73e2b8f1a04b15474dfdf0aedd2b6dce6e326be845941b5b0d35b32269dea8")
