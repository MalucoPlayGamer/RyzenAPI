-- Lua provided by SkyAPI 
-- Game: Sex Chess Soundtrack
addappid(2232700)
addappid(2232701, 1, "e3f76a59214aa0957156928fdea3d0cbb41f1547b4ffd80a998520f51eadb295")
