-- Lua provided by RyzenAPI
-- Game: Game: Sex Chess Soundtrack

-- MAIN APPLICATION
addappid(2232700)
-- Game: addappid(2232700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232701, 1, "e3f76a59214aa0957156928fdea3d0cbb41f1547b4ffd80a998520f51eadb295")
