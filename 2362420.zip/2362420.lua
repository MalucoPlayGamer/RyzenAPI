-- Lua provided by RyzenAPI
-- Game: Mass Effect 2 (2010) Edition

-- MAIN APPLICATION
addappid(2362420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362421, 1, "6acb38025a65260ecc29ee65d57edc160788f39ba85ae9dcd38f849f090a851d")
addappid(2362422, 1, "e559e7888896f1efd0d3d8443b6849826aa6ed15d55a269862df486de5de08b3")
addappid(2362423, 1, "bd9452d538ffd929f88f960d56b5ad445a87304b7cd76b5832367e7f69419972")
addappid(2362424, 1, "400372fb079f178b4993fc26789a961bed053c82b2e9394b68f0e47ad04d6d5f")
addappid(2362425, 1, "6df7a14d7d9d1b081d96b417c3a2ae272f8ca04d2d0e6ebbd5c84890fead0bb1")
addappid(2362426, 1, "1725a6bcd345e6fc6e7086704fc619beb50401c18756f02588389610acebfc3d")
addappid(2362427, 1, "8fe28013b5ce1ccd3d7b4035e879216ee3766c9c589766dc1fb0823e6eb6d8a9")
addappid(2362428, 1, "9d106f063bd34fd7e97894a49eb3bca0e6a73cfd3c61e772a4f2d91f0703538e")
addappid(2362429, 1, "72ff8581bb870af9130c09cc240b7d7f03ac8686f64d949990ad1b699a7713c5")
addappid(2362431, 1, "edcdc8f1d132cac005c581e298c97edb1a2d9e52e4231d50dfdd6447ea284075")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2362430)
addappid(2368020)
addappid(2368021)
addappid(2368022)
addappid(2368023)
addappid(2368024)
addappid(2368025)
addappid(2368026)
addappid(2368027)
addappid(2368028)
addappid(2368029)
addappid(2368040)
addappid(2368041)
addappid(2368042)
addappid(2368043)
addappid(2368044)
addappid(2368045)
addappid(2368046)
addappid(2368047)
addappid(2368048)
addappid(2368049)
addappid(2368050)
addappid(2368051)
addappid(2368052)
addappid(2368053)
addappid(2368054)
