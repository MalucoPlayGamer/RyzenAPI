-- Lua provided by RyzenAPI
-- Game: Succubus life

-- MAIN APPLICATION
addappid(1997430)
-- Game: addappid(1997430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997431, 1, "a49c676e6a39c849c3d5a8933672fa6d17cd9d7d1a2b3b8de587081a16d60086")
addappid(1997432, 1, "6d3ef8b8206321cbfa151f17d8b98afaba0c875f439bc2c01015ebd892d87a26")
addappid(1997433, 1, "1bfbda38a3cafdf953d8992803162fd2b3d592e06d9e59542142e5c5aee44b4d")
addappid(1997434, 1, "47ca9a54537c9e2ac8c949b194d78631c12dbbf803d7cdc89505c307af798738")
