-- Lua provided by RyzenAPI 
-- Game: Gravity Cat
addappid(491000)
addappid(491001, 1, "15c3b6ca69686a38caca0dd511f9597b74a0098969385a6a4132d84aed2e9f39")
