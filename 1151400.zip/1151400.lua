-- Lua provided by RyzenAPI
-- Game: Furious Goal

-- MAIN APPLICATION
addappid(1151400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151402,0,"f4b7a70608588ef714169933e7a9aa95fbc0b16713cc377eee8d26ff36595934")
