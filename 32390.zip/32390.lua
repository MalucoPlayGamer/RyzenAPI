-- Lua provided by RyzenAPI
-- Game: STAR WARS™ Jedi Knight - Mysteries of the Sith™

-- MAIN APPLICATION
addappid(32390)
-- Game: addappid(32390)

-- MAIN APP DEPOTS / PACKAGES
addappid(32391, 1, "ca6eb5443ece8b932958f20327519d12e310898ba8bb398ec4ace236994dbdf7")
addappid(32392, 1, "a5c4180d71e7604042e3b024dc8a0f31fa1b59a4ec44ff9beb9473b7db700812")
addappid(32393, 1, "530d2fd9ef99431b78b55d9a10776a71a2a1e368ea96913034105da0c9be940b")
addappid(32394, 1, "b2f4d6f13725e137d804d6124ed772a5a686ab2b246f3803c363405a44ea0bfc")
addappid(32395, 1, "b09da6b5a13d72ffb2a042a7dfcceef63444c6165bbb9984fc0e4ba1869d389f")
addappid(32396, 1, "4ce3ec20204c008fdd1d7310fe466db22fd96843499bd59d28c331861e635185")
