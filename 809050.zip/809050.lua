-- Lua provided by RyzenAPI
-- Game: Detective Holmes: Trap for the Hunter. Hidden objects. 探し物

-- MAIN APPLICATION
addappid(809050)

-- MAIN APP DEPOTS / PACKAGES
addappid(809051, 1, "3af0ef8931ad7d97a55eeee4316d65af617c0d77cff1407b2cf8277b06f6cd97")
