-- Lua provided by SkyAPI 
-- Game: Panzer Panic VR
addappid(589170)
addappid(589171, 1, "6ac6b02a7d12c9a0dea38f39f002cf56d13ab9c23714bcc3a7e308e6ea533c0f")
