-- Lua provided by RyzenAPI
-- Game: Panzer Panic VR

-- MAIN APPLICATION
addappid(589170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(589171, 1, "6ac6b02a7d12c9a0dea38f39f002cf56d13ab9c23714bcc3a7e308e6ea533c0f")

