-- Lua provided by RyzenAPI
-- Game: AppID 810680

-- MAIN APPLICATION
addappid(810680)

-- MAIN APP DEPOTS / PACKAGES
addappid(810681, 1, "820f6055dcde757f946b0a56ff30bbc5bd5b95d64b7b7fe890b2cfdd6a535665")

