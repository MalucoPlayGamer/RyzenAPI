-- Lua provided by RyzenAPI
-- Game: Flash Diving Demo

-- MAIN APPLICATION
addappid(3036070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036071, 1, "6486c4c1a7f82a389c09964779b55f767e4d61a35cb528c3581fa137729afa62")

