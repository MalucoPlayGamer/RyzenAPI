-- Lua provided by RyzenAPI
-- Game: AppID 233860

-- MAIN APPLICATION
addappid(233860)
addappid(233870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(233861, 1, "38568de2647a34cb59498e6eb270d8a8e4a9f6de3761eb6c087de081f8c47273")
addappid(468550, 0, "c908f9631d5bdcb41bb85c108c4e64f4cb3f51ff42c5555fe5471ec6ba9b43dd")

