-- Lua provided by RyzenAPI
-- Game: An Evening of Wonders

-- MAIN APPLICATION
addappid(2477590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477591, 1, "2da942b4ce2a92d0f749d243154d7409b1848cd5994f32a53548f259f6304622")
