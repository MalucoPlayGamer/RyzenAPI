-- Lua provided by RyzenAPI 
-- Game: Muffles' Life Sentence
addappid(3145370)
addappid(3145371, 1, "2d1352ec71646e73301ade51b2913b26b2496df3f43f7ed8ccb570b528c6d8d5")
