-- 1442820's Lua and Manifest Created by Hubcap Manifest
-- R-Type Final 2
-- Created: August 27, 2026 at 19:23:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 15
-- Total DLCs: 21
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1442820, 1, "b0e08ba389a7dafb7e1520ebd4c9f5a1c702cf4bb857519b939a74b97c4ff154") -- R-Type Final 2
-- MAIN APP DEPOTS
addappid(1442821, 1, "a8b6b3404251e2b428b43cf2afa2e0c44422a962f8140dfa60490d9e6fc51a38") -- R-Type Final 2 Content
setManifestid(1442821, "7126348927105864831", 18343037970)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- R-Type Final 2 - Complete Soundtrack (AppID: 1575080)
addappid(1575080)
addappid(1575080, 1, "af5c04be55f262a863c93f1aa7c352bf4f19a38fe75d563f95153a70b4deaf1b") -- R-Type Final 2 - Complete Soundtrack - R-Type Final 2 - Complete Soundtrack (1575080) Depot
setManifestid(1575080, "9067915236064013766", 972361925)
-- The Artwork of R-Type Final 2 - Art Book (AppID: 1575081)
addappid(1575081)
addappid(1575081, 1, "df039e23d623498e2b3fbc17fc8eacac05d23d8c9335be12bacc620a056e9b89") -- The Artwork of R-Type Final 2 - Art Book - The Artwork of R-Type Final 2 - Art Book (1575081) Depot
setManifestid(1575081, "2423855398054755056", 17634316)
-- R-Type Final 2 - DLC Set 1 (AppID: 1585380)
addappid(1585380)
addappid(1585380, 1, "b59653378e4462ddcf63f428ee77564a267fb729a8ee5a4e4cd1681fd3184803") -- R-Type Final 2 - DLC Set 1 - R-Type Final 2 - DLC Set 1 (1585380) デポ
setManifestid(1585380, "2657770548788754931", 18)
-- R-Type Final 2 - DLC Set 2 (AppID: 1585381)
addappid(1585381)
addappid(1585381, 1, "732e9d532c8fba52c9c38496fc513270d2814a24ed727bb1ef58ba70cc182a96") -- R-Type Final 2 - DLC Set 2 - R-Type Final 2 - DLC Set 2 (1585381) デポ
setManifestid(1585381, "6662076282831999373", 16)
-- R-Type Final 2 - DLC Set 3 (AppID: 1585382)
addappid(1585382)
addappid(1585382, 1, "49a5f61cf44703f220af6eaedab7e1036acc786469d3ac205dcd1147f3b14413") -- R-Type Final 2 - DLC Set 3 - R-Type Final 2 - DLC Set 3 (1585382) デポ
setManifestid(1585382, "5615940166254929847", 16)
-- R-Type Final 2 - DLC Set 4 (AppID: 1731960)
addappid(1731960)
addappid(1731960, 1, "c31367c0cbf0bce244c5f9b5f726feafa2781df38c92eaa9e509f3e0bbe05f9f") -- R-Type Final 2 - DLC Set 4 - R-Type Final 2 - DLC Set 4 (1731960) Depot
setManifestid(1731960, "2793064821411624969", 12)
-- R-Type Final 2 - DLC Set 5 (AppID: 1731961)
addappid(1731961)
addappid(1731961, 1, "f311f4f50c52d85fc1b2ccc8f9eb3c007c5ca685ef3b183fda5866520789362b") -- R-Type Final 2 - DLC Set 5 - R-Type Final 2 - DLC Set 5 (1731961) Depot
setManifestid(1731961, "852965508534153588", 12)
-- R-Type Final 2 - DLC Set 6 (AppID: 1731962)
addappid(1731962)
addappid(1731962, 1, "5987f884e8964fcc4ab39ea2bd2d4151f5988439ee3e23d7380d3fb7236701a1") -- R-Type Final 2 - DLC Set 6 - Depot 1731962
setManifestid(1731962, "2204325597925013946", 12)
-- R-Type Final 2 - OFX-X MARIKO R-Craft (AppID: 1898960)
addappid(1898960)
addappid(1898960, 1, "22b8e8015692c182d0651d18ee5398f190931b0008bc46d10c02543afe2fb5c1") -- R-Type Final 2 - OFX-X MARIKO R-Craft - Depot 1898960
setManifestid(1898960, "2623490603248313332", 16)
-- R-Type Final 2 - R-9uso799 APRIL FOOLS PROTOTYPE (AppID: 1913270)
addappid(1913270)
addappid(1913270, 1, "59108edc49f049352b0c6302281260f68685eae1cbb618ece664452a6b12f06b") -- R-Type Final 2 - R-9uso799 APRIL FOOLS PROTOTYPE - Depot 1913270
setManifestid(1913270, "7732255112709943324", 16)
-- R-Type Final 2 - DLC Set 7 (AppID: 2068670)
addappid(2068670)
addappid(2068670, 1, "254bb6b06e189dc2f338d668369ca8e7986a3820ef793ef99d0fd7f8f9c5e146") -- R-Type Final 2 - DLC Set 7 - Depot 2068670
setManifestid(2068670, "6081369100415955284", 12)
-- R-Type Final 2 - B-99 APOCALYPSE R-Craft (AppID: 2250360)
addappid(2250360)
addappid(2250360, 1, "268ecf03bed2011eb35f61057aea1256f26d72a1bf530f7806049f6522556054") -- R-Type Final 2 - B-99 APOCALYPSE R-Craft - Depot 2250360
setManifestid(2250360, "880983824388399652", 16)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1642020) -- R-Type Final 2 - Crowdfunding Original R-CRAFT
addappid(2068671) -- R-Type Final 2 - DLC Set 8
addappid(2068672) -- R-Type Final 2 - DLC Set 9
addappid(2176950) -- R-Type Final 2 - New Pilot Support Pack
addappid(2176951) -- R-Type Final 2 - Ace Pilot Special Training Pack I
addappid(2176952) -- R-Type Final 2 - Ace Pilot Special Training Pack II
addappid(2176953) -- R-Type Final 2 - Ace Pilot Special Training Pack III
addappid(3059590) -- R-Type Final 2 - Team COSMOS Backer-Exclusive R-Craft
addappid(4824620) -- R-Type Final 2 - Team COSMOS Backer-Exclusive Cosmetics
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1642020) -- Depot 1642020 (empty depot)
-- addappid(2068671) -- Depot 2068671 (empty depot)
-- addappid(2068672) -- Depot 2068672 (empty depot)
-- addappid(2176950) -- Depot 2176950 (empty depot)
-- addappid(2176951) -- Depot 2176951 (empty depot)
-- addappid(2176952) -- Depot 2176952 (empty depot)
-- addappid(2176953) -- Depot 2176953 (empty depot)
-- addappid(3059590) -- Depot 3059590 (empty depot)
-- addappid(4824620) -- Depot 4824620 (empty depot)
-- addappid(4824630) -- Depot 4824630 (empty depot)