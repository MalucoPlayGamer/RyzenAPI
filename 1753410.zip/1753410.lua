-- Lua provided by RyzenAPI
-- Game: King of Kinks

-- MAIN APPLICATION
addappid(1753410)
addappid(2458460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753411, 1, "d77c81ecd27e3aba43a1a630ad94e4d533bdbe3979e767707bed4febddc6dd20")
