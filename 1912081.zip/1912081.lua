-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Uchiban Outfit "Ichigo Hitofuri"

-- MAIN APPLICATION
addappid(1912081)
-- Game: addappid(1912081)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912081,0,"878572cf27f6af90259973a6ce93ab08ce2b5234da291ba0ac2257f8900a3560")
