-- Lua provided by SkyAPI 
-- Game: AppID 805360
addappid(805360)
addappid(805361, 1, "700388768298fedc50d00e0ce8f4ef2706c8f0ba8976103c6cd200e3e8b55aa7")
