-- Lua provided by RyzenAPI
-- Game: Wik™ & The Fable of Souls

-- MAIN APPLICATION
addappid(7420)

-- MAIN APP DEPOTS / PACKAGES
addappid(7421, 1, "4df5a6cb4c3a23e5ccb31d234dadab8e92b7032d7c226637c49305c0a51fec30")

