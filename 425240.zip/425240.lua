-- Lua provided by RyzenAPI
-- Game: AppID 425240

-- MAIN APPLICATION
addappid(425240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(425241, 1, "27ab454e66bd6e48381b291b93557bfa718ee8f1586e85fcdf9ff1ee5fe43653")
addappid(425242, 1, "1793a2031f986a636dc7f20c33ea678c2f3928fe7c37551332f08a3ca6e3cae1")
addappid(425243, 1, "ce2807910dfec912f7b69eff5d7ed0f79f93ee40124e3656760fe1f4ff2b9f54")
addappid(692140, 0, "4b7b37e933bb37c8cb0c71618b2dfdd6bc2fc6490b7312fb0695be942ce6bcb7")

