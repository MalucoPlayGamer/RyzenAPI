-- Lua provided by RyzenAPI
-- Game: 2847400

-- MAIN APPLICATION
addappid(2847400)
-- Game: addappid(2847400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2847407,0,"67883a80f97d9659d41441dffd1d73bdf9a6321b742d63e03d137c9abc251daa")
