-- Lua provided by RyzenAPI
-- Game: AppID 1053020

-- MAIN APPLICATION
addappid(1053020)
-- Game: addappid(1053020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053021, 1, "ec5ddaea99fad9675a5fdb3eed127976978ac44f3375811182cc6339a90ffc79")
