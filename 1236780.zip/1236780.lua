-- Lua provided by RyzenAPI
-- Game: AppID 1236780

-- MAIN APPLICATION
addappid(1236780)
-- Game: addappid(1236780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236781, 1, "c58644dc4a81ca9440da3ae0f460a5d01168e7f6f98c4241b5816ab3dc7a7f83")
