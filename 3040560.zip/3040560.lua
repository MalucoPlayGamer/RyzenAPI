-- Lua provided by RyzenAPI
-- Game: Elite Exorcist Miko

-- MAIN APPLICATION
addappid(3040560)
-- Game: addappid(3040560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040561, 1, "9c72d9ba7bb49316b56c5f8448248757c1cc213d57cc01bcc4c9c49935cdbdb5")
