-- Lua provided by SkyAPI 
-- Game: Terrorbytes
addappid(3172770)
addappid(3172771, 1, "f9d73ff2a218f27f1b6316d4de06be8d4ab5354d77e8026b5f05b350a0d25c5f")
