-- Lua provided by RyzenAPI
-- Game: Game: AppID 693670

-- MAIN APPLICATION
addappid(693670)
-- Game: addappid(693670)

-- MAIN APP DEPOTS / PACKAGES
addappid(693671, 1, "94188ab75132eea4b2fbc8ae32f4b4682cea025ac0b5c59a8b14880b18e1959d")
addappid(693672, 1, "ec34aa06a24ec3bf8263c006b4d4317c2612117abd44b06d53e9fb33898a8a01")
