-- Lua provided by RyzenAPI
-- Game: DFF NT: Kingly Raiment Appearance Set for Noctis Lucis Caelum

-- MAIN APPLICATION
addappid(1022508)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022508,0,"3e8aff1949eb046656707a9463e0fd6581732a4398c94202b315355aecc9a228")

