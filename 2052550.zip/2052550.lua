-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2052550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052552,0,"13238c21570fcedb24144d4c7b99c18fbfff6a32547095033cbec07f8086ae55")

