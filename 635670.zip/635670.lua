-- Lua provided by RyzenAPI
-- Game: 635670

-- MAIN APPLICATION
addappid(635670)
addappid(635671)
-- Game: addappid(635670)

-- MAIN APP DEPOTS / PACKAGES
addappid(635672,0,"0be4c11c63bacc652be29249187ade4349e7c3d0300412c6e093803950ae45e8")
