-- Lua provided by RyzenAPI
-- Game: PROPHUNT

-- MAIN APPLICATION
addappid(1600950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600951, 1, "0f3ccec2df340443a7334c45793f27ee0ca17f2cc7e822cb698a684d33e9f0bb")

