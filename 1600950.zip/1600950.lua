-- Lua provided by RyzenAPI
-- Game: PROPHUNT

-- MAIN APPLICATION
addappid(1600950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1600951, 1, "0f3ccec2df340443a7334c45793f27ee0ca17f2cc7e822cb698a684d33e9f0bb")

