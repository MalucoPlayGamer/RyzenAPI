-- Lua provided by RyzenAPI
-- Game: 485030

-- MAIN APPLICATION
addappid(485030)
-- Game: addappid(485030)

-- MAIN APP DEPOTS / PACKAGES
addappid(485031, 1, "cf3889b50d6a8670fa199c3db83ed672f9cfba13dc8ce239ad8151ee3a662b57")
addappid(918800, 0, "fc365dd3cb5e1fea96ee883e9e8f185fa6f6e740bec366723181d1740e2c11af")
addappid(918810, 0, "6e00db999e6b40578b77c79b1724a50c5e0d2f3791785c5e11b1a85869e7a664")
