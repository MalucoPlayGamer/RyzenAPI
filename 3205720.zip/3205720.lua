-- Lua provided by RyzenAPI
-- Game: Schedule I: Free Sample

-- MAIN APPLICATION
addappid(3205720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205721, 1, "aa9a905f9b8ecf4c29fa0e3c6f50d33e887ef1c83a523d9096ce889f6acc297b")
