-- Lua provided by RyzenAPI
-- Game: addappid(3215890)

-- MAIN APPLICATION
addappid(3215890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215891, 1, "51b39c6c427c20a14fa2bc9ad428f6dd63320e9ac114cb1c00d43b61231633dd")
