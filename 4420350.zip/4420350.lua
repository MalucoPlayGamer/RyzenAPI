-- Lua provided by RyzenAPI
-- Game: PPPoker

-- MAIN APPLICATION
addappid(4420350)

