-- Lua provided by RyzenAPI
-- Game: RunningDead

-- MAIN APPLICATION
addappid(584220)

-- MAIN APP DEPOTS / PACKAGES
addappid(584221, 1, "40db11411d910f5b3b3df94cbf6adf8bc3f8895a6b03fbbd5fd24bc31b4e01af")
