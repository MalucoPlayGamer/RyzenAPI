-- Lua provided by RyzenAPI
-- Game: Game: Endless Tentacle Cave

-- MAIN APPLICATION
addappid(2988290)
-- Game: addappid(2988290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2988291, 1, "c4051cecc4562a0c10f24104538c83a67710d5e74249edf016d700cdbe21c23d")
