-- Lua provided by RyzenAPI
-- Game: AppID 704380

-- MAIN APPLICATION
addappid(704380)
-- Game: addappid(704380)

-- MAIN APP DEPOTS / PACKAGES
addappid(704381, 1, "fc484f549822e0f3afcf220f171bffc8754d98f99a3ef9e7fbe82174784109ce")
