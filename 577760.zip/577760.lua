-- Lua provided by RyzenAPI
-- Game: Tears of a Dragon

-- MAIN APPLICATION
addappid(577760)

-- MAIN APP DEPOTS / PACKAGES
addappid(577761, 1, "39c12b97ecab4f201379cc4ddf3c20c3717a6c76c0797e6d7c501a3926044ba2")
