-- Lua provided by RyzenAPI
-- Game: addappid(1837580)

-- MAIN APPLICATION
addappid(1837580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837581, 1, "699ec561dddceea3ff20c1df94a97cf7dc37fd3d5b3b224af8c05bc20807e465")
addappid(1837583, 1, "de0727f8183733a7cb27bc3493e629132a0dd2f8d15535e18c22f2428d50209b")
