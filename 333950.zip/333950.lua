-- Lua provided by RyzenAPI
-- Game: Medieval Engineers

-- MAIN APPLICATION
addappid(333950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(333951, 1, "abeca689fb16e176d9c4e9e529d7d7e5bc66c5fe8c34b6b968bf2be179cf07bc")
addappid(346360, 0, "7a1fd70d71c6e93e16795fc14592706bc64e28c7cb673da14aef023b274ba08c")

