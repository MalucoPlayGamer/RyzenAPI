-- Lua provided by RyzenAPI
-- Game: Game: Medieval Engineers

-- MAIN APPLICATION
addappid(333950)
-- Game: addappid(333950)

-- MAIN APP DEPOTS / PACKAGES
addappid(333951, 1, "abeca689fb16e176d9c4e9e529d7d7e5bc66c5fe8c34b6b968bf2be179cf07bc")
addappid(346360, 0, "7a1fd70d71c6e93e16795fc14592706bc64e28c7cb673da14aef023b274ba08c")
