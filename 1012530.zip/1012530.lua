-- Lua provided by RyzenAPI
-- Game: AppID 1012530

-- MAIN APPLICATION
addappid(1012530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012531, 1, "dc92a7ce5720c284d665b91e22f5373b4d169692a9b6cb415bfa4ff03cdb45fa")
