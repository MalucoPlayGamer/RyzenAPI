-- Lua provided by RyzenAPI
-- Game: AppID 1012530

-- MAIN APPLICATION
addappid(1012530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012531, 1, "dc92a7ce5720c284d665b91e22f5373b4d169692a9b6cb415bfa4ff03cdb45fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
