-- Lua provided by RyzenAPI
-- Game: addappid(1701140)

-- MAIN APPLICATION
addappid(1701140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701141, 1, "801d4f3e36577affdcdc3d7d3066d320d4b621dd700e55f56217f0d3263fa640")
