-- Lua provided by RyzenAPI
-- Game: AppID 1701140

-- MAIN APPLICATION
addappid(1701140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1701141, 1, "801d4f3e36577affdcdc3d7d3066d320d4b621dd700e55f56217f0d3263fa640")

