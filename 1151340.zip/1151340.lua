-- Lua provided by RyzenAPI
-- Game: Fallout 76

-- MAIN APPLICATION
addappid(1158670) -- Fallout 76 - Atoms
addappid(1202520) -- Fallout 1st (Steam)
addappid(1224340) -- Fallout 76: Raiders Content Bundle
addappid(1224341) -- Fallout 76: Settlers Content Bundle
addappid(1224350) -- Fallout 76 Tricentennial Pack
addappid(1343770) -- Fallout 76: Appalachia Starter Bundle
addappid(1460140) -- DLC 1460140
addappid(1905070) -- DLC 1905070
addappid(1905071) -- DLC 1905071
addappid(1905072) -- DLC 1905072
addappid(1905073) -- DLC 1905073
addappid(2096110) -- DLC 2096110
addappid(2655310) -- Fallout 76: Atlantic City High Stakes Bundle
addappid(2975970) -- Fallout 76: Skyline Valley - Lost Treasures Bundle
addappid(3232920) -- Fallout 76: Enclave Armory Bundle
addappid(3699170) -- Fallout 76: Atomic Angler Bundle
addappid(4141110) -- Fallout 76: Burning Springs Starter Bundle
addappid(4250650) -- Fallout 76: Mojave Bundle
addappid(4712160) -- Fallout 76 - Deathclaw Pet Bundle

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1151340, 1, "0064295364d2bd8762d8e3e7a2dfb6720f9be3a9977ffb7821c393dc713093db")
addappid(1151341, 1, "9b8e3f1f2fa9b550117460bb2dbca6bfee667498c861e6876375b4d5ec918308")
addappid(1151342, 1, "c9bdd124ea5845113d7e4b8687219e437dce9c404d945e6c0c5c22dc21ed0f5c")
addappid(1151343, 1, "5be7b804108297cafff6ca063ae6009b754de5ce2342267b2a88deafe0519912")
addappid(1151344, 1, "2141a423a43cdcdc8b317d60cd34a2bec98b354963345ce6a5fa0800bd3b9bf9")
addappid(1151345, 1, "8357de1f7f255c1cab61800b9dadb760e064bc92cd7c0ec40a3df8807099b75a") -- English
addappid(1151346, 1, "e517e951cd40a75eb61414685600f93fd7008e1600b77f9ce1292aa007d14307") -- Schinese
addappid(1151347, 1, "13017d4b4e829c24cd8fe92a1ae931628e9ad518aa8fda1dfa8af9af902d9279") -- Tchinese
addappid(1151348, 1, "498e04dc7691d44b975505a1d73a12cc2f4e4166648c8af2088aed6a1d168818") -- French
addappid(1151349, 1, "d273e3372fd9054d568ff7e29f781c720585995edeff6448c388141dbd37088d") -- German
addappid(1158671, 1, "0fad41535abb51f925512abbba1e2386c7be759bc67ed2906f2c8674e81bd26f") -- Italian
addappid(1158672, 1, "efdd8c14fd13388af1083c0af43e558089d2cddae3f6337e04156885a24fe0e4") -- Japanese
addappid(1158673, 1, "d6cc4d1edec180a5d611c0bbbd1cb9a9c755cb4336e6142e474d6c73f50c64ae") -- Koreana
addappid(1158674, 1, "f623d1bd54715953e0e749cf1e788b88b97f1df17978c81b612349840e06f1a9") -- Polish
addappid(1158675, 1, "f1e3521393bed81272e5c2f2353377af109802f89fd76591ab9ffdc902746eb4") -- Brazilian
addappid(1158676, 1, "5649807ecc10b1a6c2e13df5f70dc08cbc2940284b40185dfe4ba928228e8af9") -- Russian
addappid(1158677, 1, "4fea494f71d6ea6197dfb26cee95bc129387c4c809ebe744beb499ba1d762a6f") -- Spanish
addappid(1158678, 1, "b61acc1af02249ef166e691640c143e48add6c63c1d48f4158308066f0baf452") -- Latam

