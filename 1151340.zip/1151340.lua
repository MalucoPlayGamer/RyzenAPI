-- Generated with Luie @ https://lua.tools/
-- 1151340 - Fallout 76
-- Generated 2026-08-10 19:05:31 UTC
-- # Depots (Total/DLC/Shared): 18/0/1

-- Main AppID
addappid(1151340, 1, "0064295364d2bd8762d8e3e7a2dfb6720f9be3a9977ffb7821c393dc713093db")

-- Main Depots
addappid(1151341, 1, "9b8e3f1f2fa9b550117460bb2dbca6bfee667498c861e6876375b4d5ec918308")
setManifestid(1151341, "5080726438685105788", 99230048)
addappid(1151342, 1, "c9bdd124ea5845113d7e4b8687219e437dce9c404d945e6c0c5c22dc21ed0f5c")
setManifestid(1151342, "884787029185706589", 107231716661)
addappid(1151343, 1, "5be7b804108297cafff6ca063ae6009b754de5ce2342267b2a88deafe0519912")
setManifestid(1151343, "5005002469046097868", 3608482426)
addappid(1151344, 1, "2141a423a43cdcdc8b317d60cd34a2bec98b354963345ce6a5fa0800bd3b9bf9")
setManifestid(1151344, "6969846946577275750", 13533071)
addappid(1151345, 1, "8357de1f7f255c1cab61800b9dadb760e064bc92cd7c0ec40a3df8807099b75a") -- English
setManifestid(1151345, "1570110867429329912", 5456)
addappid(1151346, 1, "e517e951cd40a75eb61414685600f93fd7008e1600b77f9ce1292aa007d14307") -- Schinese
setManifestid(1151346, "5257090921736523617", 233128446)
addappid(1151347, 1, "13017d4b4e829c24cd8fe92a1ae931628e9ad518aa8fda1dfa8af9af902d9279") -- Tchinese
setManifestid(1151347, "1707029590927747586", 233118550)
addappid(1151348, 1, "498e04dc7691d44b975505a1d73a12cc2f4e4166648c8af2088aed6a1d168818") -- French
setManifestid(1151348, "4662047450090935931", 3601309369)
addappid(1151349, 1, "d273e3372fd9054d568ff7e29f781c720585995edeff6448c388141dbd37088d") -- German
setManifestid(1151349, "3485073591319200872", 3931333407)
addappid(1158671, 1, "0fad41535abb51f925512abbba1e2386c7be759bc67ed2906f2c8674e81bd26f") -- Italian
setManifestid(1158671, "6575145919683317855", 3902587879)
addappid(1158672, 1, "efdd8c14fd13388af1083c0af43e558089d2cddae3f6337e04156885a24fe0e4") -- Japanese
setManifestid(1158672, "6122870478441443257", 3894497563)
addappid(1158673, 1, "d6cc4d1edec180a5d611c0bbbd1cb9a9c755cb4336e6142e474d6c73f50c64ae") -- Koreana
setManifestid(1158673, "2412956959791568569", 233120862)
addappid(1158674, 1, "f623d1bd54715953e0e749cf1e788b88b97f1df17978c81b612349840e06f1a9") -- Polish
setManifestid(1158674, "557781794227982016", 233129454)
addappid(1158675, 1, "f1e3521393bed81272e5c2f2353377af109802f89fd76591ab9ffdc902746eb4") -- Brazilian
setManifestid(1158675, "1990754200887071981", 233121892)
addappid(1158676, 1, "5649807ecc10b1a6c2e13df5f70dc08cbc2940284b40185dfe4ba928228e8af9") -- Russian
setManifestid(1158676, "9198597415454247277", 233126782)
addappid(1158677, 1, "4fea494f71d6ea6197dfb26cee95bc129387c4c809ebe744beb499ba1d762a6f") -- Spanish
setManifestid(1158677, "8757538983260426257", 3923360585)
addappid(1158678, 1, "b61acc1af02249ef166e691640c143e48add6c63c1d48f4158308066f0baf452") -- Latam
setManifestid(1158678, "4434207959330898769", 233128240)

-- DLC's (no depot keys required)
addappid(1158670) -- Fallout 76 - Atoms
addappid(1202520) -- Fallout 1st (Steam)
addappid(1224340) -- Fallout 76: Raiders Content Bundle
addappid(1224341) -- Fallout 76: Settlers Content Bundle
addappid(1224350) -- Fallout 76 Tricentennial Pack
addappid(1343770) -- Fallout 76: Appalachia Starter Bundle
addappid(1460140) -- DLC 1460140
addappid(1905070) -- DLC 1905070
addappid(1905071) -- DLC 1905071
addappid(1905072) -- DLC 1905072
addappid(1905073) -- DLC 1905073
addappid(2096110) -- DLC 2096110
addappid(2655310) -- Fallout 76: Atlantic City High Stakes Bundle
addappid(2975970) -- Fallout 76: Skyline Valley - Lost Treasures Bundle
addappid(3232920) -- Fallout 76: Enclave Armory Bundle
addappid(3699170) -- Fallout 76: Atomic Angler Bundle
addappid(4141110) -- Fallout 76: Burning Springs Starter Bundle
addappid(4250650) -- Fallout 76: Mojave Bundle
addappid(4712160) -- Fallout 76 - Deathclaw Pet Bundle

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
