-- Lua provided by RyzenAPI
-- Game: Spice&Wolf VR

-- MAIN APPLICATION
addappid(1065970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1065971, 1, "cc8c4f2ea1317324ece6d408894f3f18239681b1f13df4f4d415556097dcbd9f")

