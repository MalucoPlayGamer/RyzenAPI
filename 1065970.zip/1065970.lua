-- Lua provided by RyzenAPI
-- Game: 1065970

-- MAIN APPLICATION
addappid(1065970)
-- Game: addappid(1065970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065971, 1, "cc8c4f2ea1317324ece6d408894f3f18239681b1f13df4f4d415556097dcbd9f")
