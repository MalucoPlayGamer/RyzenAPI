-- Lua provided by RyzenAPI
-- Game: Nearly Dead - Live and Let Die

-- MAIN APPLICATION
addappid(1901810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901811, 1, "4da5ee17a2070c36c3aaa5e153c8622ebbe3f23f632b78bbf47ad972ac3d6027")

