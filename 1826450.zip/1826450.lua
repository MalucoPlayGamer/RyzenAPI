-- Lua provided by RyzenAPI
-- Game: Idling Idol

-- MAIN APPLICATION
addappid(1826450)
-- Game: addappid(1826450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826451, 1, "983086a1b73aafe5445a86da27d0e1599b83fabc5cb5fc4d79c0b26520249767")
