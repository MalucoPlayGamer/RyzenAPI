-- Lua provided by RyzenAPI
-- Game: addappid(2487660)

-- MAIN APPLICATION
addappid(2487660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487661, 1, "bffe93ac2776ecc9bb6f73fbff5663c4142c87640efeeacf3fe997339acf5138")
