-- 4515950's Lua and Manifest Created by Hubcap Manifest
-- Pulslink
-- Created: August 04, 2026 at 09:24:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4515950) -- Pulslink
-- MAIN APP DEPOTS
addappid(4515951, 1, "6e8100f17f1f86b09044c86bd109b171caff665a2fac56dc7eea2de0e5b697cc") -- Depot 4515951
setManifestid(4515951, "6799462317396662279", 169890484)