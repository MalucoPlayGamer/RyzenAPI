-- Lua provided by RyzenAPI
-- Game: Pulslink

-- MAIN APPLICATION
addappid(4515950) -- Pulslink

-- MAIN APP DEPOTS / PACKAGES
addappid(4515951, 1, "6e8100f17f1f86b09044c86bd109b171caff665a2fac56dc7eea2de0e5b697cc") -- Depot 4515951

