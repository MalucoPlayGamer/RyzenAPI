-- Lua provided by RyzenAPI
-- Game: Dancing Hime: Rhythm Matching

-- MAIN APPLICATION
addappid(2057490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057491, 1, "7709cf257374adbaa9fe328ff8f401cc2dda7feefac34bab57c2dbb82ab55017")

