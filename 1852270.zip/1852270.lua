-- Lua provided by RyzenAPI
-- Game: The Heroes around Me Demo

-- MAIN APPLICATION
addappid(1852270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852271, 1, "eb22662d5cf4fcf8462c7353c71275ba3564100011cba40edc1ad6e58c1d8d8a")

