-- Lua provided by RyzenAPI
-- Game: Pixel Traffic: Highway Racing

-- MAIN APPLICATION
addappid(867730)

-- MAIN APP DEPOTS / PACKAGES
addappid(867731, 1, "3b5b4ccbe8b87d1ac6f1c6914ae04f578dbb53203dc1edc7814eef43186e5d56")
addappid(867732, 1, "41ea8725d365fce70479983778ddff383d475835366dc112c3e3bf1827833bf9")
addappid(867733, 1, "e82b863e32ad141307119ad8ef71566916f3f8419ee7367fd1a4157c639ba21e")
