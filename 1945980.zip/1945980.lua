-- Lua provided by RyzenAPI 
-- Game: The Rusty Sword: Vanguard Island
addappid(1945980)
addappid(1945981, 1, "7eb5ae1a6e7d5f81797897fb14a8750513ad25af03ba14eb95219c1cb5f47184")
