-- Lua provided by RyzenAPI
-- Game: The Rusty Sword: Vanguard Island

-- MAIN APPLICATION
addappid(1945980)
-- Game: addappid(1945980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945981, 1, "7eb5ae1a6e7d5f81797897fb14a8750513ad25af03ba14eb95219c1cb5f47184")
