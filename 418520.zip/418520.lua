-- Lua provided by RyzenAPI
-- Game: 418520

-- MAIN APPLICATION
addappid(418520)
-- Game: addappid(418520)

-- MAIN APP DEPOTS / PACKAGES
addappid(418521, 1, "daaa02d6bcb1151deea0596124e5e5f982809bf3181904df53b15a035b8e2155")
