-- Lua provided by RyzenAPI
-- Game: setManifestid(2702973,"4098251481188723022")

-- MAIN APPLICATION
addappid(2702970)
-- Game: addappid(2702970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702973,0,"3b094e1567c36fb763feb184482f299a2511e9a8b5ab029c4066c6a30e297f6b")
addappid(2702979,0,"6ae14ca82c3d633ba6ad940fe49c4b080c9ca53eececdd6a6afd7befe7ce2fae")
