-- Lua provided by RyzenAPI
-- Game: Agatha Christie - Death on the Nile

-- MAIN APPLICATION
addappid(3150480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150481, 1, "9e961aeaf789de2af860bc2c0cd909bfe4e74777accc39cec2aee7449e0412cb")
addappid(3957320, 0, "2ca9d400c23276cc092fa4e0fcf3c6714051836e235c6ce9f0c72ea9aa0b6e48")

