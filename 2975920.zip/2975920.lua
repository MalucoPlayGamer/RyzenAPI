-- Lua provided by RyzenAPI
-- Game: Game: AppID 2975920

-- MAIN APPLICATION
addappid(2975920)
-- Game: addappid(2975920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975921, 1, "570e9d1c574580c173d2415ad7e40b9d97f94193bddfc93d8aa532bb5b8876b2")
