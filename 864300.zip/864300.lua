-- Lua provided by RyzenAPI
-- Game: addappid(864300)

-- MAIN APPLICATION
addappid(864300)

-- MAIN APP DEPOTS / PACKAGES
addappid(864301, 1, "b495ccc7a62d152bd40ce1877aa0949fb5a01caddecd5d99c531bc13e744f055")
