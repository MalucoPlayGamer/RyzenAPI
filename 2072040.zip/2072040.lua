-- Lua provided by RyzenAPI
-- Game: Azrael

-- MAIN APPLICATION
addappid(2072040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072041, 1, "bfa6f20e8b1c8d53bce10020838f81a8be7d366719c713d562373afc20ee7187")

