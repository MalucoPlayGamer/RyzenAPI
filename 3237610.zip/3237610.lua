-- Lua provided by RyzenAPI
-- Game: Shopenkraft's Magic Goods

-- MAIN APPLICATION
addappid(3237610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3237611,0,"085ccf396cfe19da69ab9ef0178418205172cc95710421f96dd32667839914a7")

