-- Lua provided by SkyAPI 
-- Game: Astron Jump Baby
addappid(692710)
addappid(692711, 1, "5df4aecfba687ee3f7c7aa3b0801e48990cbcced1aaca1f03cf49d5bf1cef5a0")
