-- Lua provided by RyzenAPI
-- Game: addappid(692710)

-- MAIN APPLICATION
addappid(692710)

-- MAIN APP DEPOTS / PACKAGES
addappid(692711, 1, "5df4aecfba687ee3f7c7aa3b0801e48990cbcced1aaca1f03cf49d5bf1cef5a0")
