-- Lua provided by SkyAPI 
-- Game: Opaline
addappid(370660)
addappid(370661, 1, "b55265e6577ea2450bc8fb4f252e6758bd7206539179fd3a5419d916080881ca")
addappid(1087870)
