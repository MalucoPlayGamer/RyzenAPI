-- Lua provided by RyzenAPI
-- Game: Game: AppID 1668200

-- MAIN APPLICATION
addappid(1668200)
-- Game: addappid(1668200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668201, 1, "794dc3e01c8f024589075ae0d3224633199e397c7c48235dbf932d429e2a5ed9")
