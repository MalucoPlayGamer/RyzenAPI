-- Lua provided by RyzenAPI
-- Game: Cemetery Warrior 4

-- MAIN APPLICATION
addappid(1150990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150991, 1, "b7b40d0cef5666e752870e61d674f51d88e178f06d243aa81a495698a816e6b2")
