-- Lua provided by RyzenAPI
-- Game: 1433330

-- MAIN APPLICATION
addappid(1433330)
-- Game: addappid(1433330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433331, 1, "abf9a15261cc77127d9266c45f75225d2c4cf01a6fd1e0ac4d6386f35f72c3b0")
