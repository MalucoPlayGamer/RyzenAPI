-- Lua provided by RyzenAPI
-- Game: The Lost Crown

-- MAIN APPLICATION
addappid(291710)

-- MAIN APP DEPOTS / PACKAGES
addappid(291711, 1, "e331c7401bb87c458cced65a98a823c434c739da43bbc3bdf3b57b8337d8fbdf")
addappid(291712, 1, "0abf6b08f48be30779ab8a8cb0e519bebea1d07de8b1acf43ff3e865a5454df2")
addappid(291713, 1, "a367206263e3f7c4aab37fe8380475352f6bb80b8ee3977eb33b46a7ef9316c5")
addappid(414010, 0, "5426e1f9c810198902b715386d3f8d3e273a7d65261fb986705845836f13031d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
