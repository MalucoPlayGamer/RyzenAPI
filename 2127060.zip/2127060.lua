-- Lua provided by RyzenAPI
-- Game: Afterdream Demo

-- MAIN APPLICATION
addappid(2127060)
-- Game: addappid(2127060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2127061, 1, "209f6490f55a4890e7661df67b89e50be8aba4c59bbc0094c24668ece690c03d")
