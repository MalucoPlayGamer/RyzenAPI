-- Lua provided by SkyAPI 
-- Game: Afterdream Demo
addappid(2127060)
addappid(2127061, 1, "209f6490f55a4890e7661df67b89e50be8aba4c59bbc0094c24668ece690c03d")
