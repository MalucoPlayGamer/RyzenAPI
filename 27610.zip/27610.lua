-- Lua provided by RyzenAPI
-- Game: Mevo and The Grooveriders Demo

-- MAIN APPLICATION
addappid(27610)

-- MAIN APP DEPOTS / PACKAGES
addappid(27612,0,"bd17363b204e99c394e2ecf44a20fde30cf1c59c541fdc46416d39c25739a095")

