-- Lua provided by RyzenAPI
-- Game: Street Fighter 6 Demo

-- MAIN APPLICATION
addappid(2154900)
-- Game: addappid(2154900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154901, 1, "41c9d514eee335e1fb816a35918250c72689dbc0361b151f8d5fb683c30460d2")
