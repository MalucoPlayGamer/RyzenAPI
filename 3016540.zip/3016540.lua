-- Lua provided by RyzenAPI
-- Game: Game: AppID 3016540

-- MAIN APPLICATION
addappid(3016540)
-- Game: addappid(3016540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016541, 1, "ac29b82d404481fbb6474d2d2d0085e206c74ee316ec8d7212d8ce532ec07eee")
