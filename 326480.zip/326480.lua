-- Lua provided by RyzenAPI
-- Game: If My Heart Had Wings

-- MAIN APPLICATION
addappid(326480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(326481, 1, "43d421a706f9c2d8ea84e4376897230e1ebc2f1655b0c78799e92265ac690d9e")
addappid(326483, 1, "dec9c701ef2d75660034a30a2212bda817ace7d1afd42f6d881b6faef0779202")
addappid(340080, 0, "05246b6edda14e2a59192c11d66457463e880dbd07a692eb8a9e0866486c5078")
addappid(734430, 0, "4f0067bf3bbcb9ab60f6d022b372f20288d877d342b9724014083aa340c66153")
