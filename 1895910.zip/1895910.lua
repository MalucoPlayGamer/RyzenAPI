-- Lua provided by RyzenAPI
-- Game: Game: Crossfire: Legion Demo

-- MAIN APPLICATION
addappid(1895910)
-- Game: addappid(1895910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895911, 1, "acfad3ff9d967dd6212fd80dc4189dc3d63384b8707e1132abb06cfad72edb70")
