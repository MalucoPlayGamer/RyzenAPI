-- Lua provided by RyzenAPI 
-- Game: Lost Ruins
addappid(1306630)
addappid(1306631, 1, "c4a67b4a6be84aca23afef67a3400117b2993b6f7082b570e8624a3cdcbe4495")
addappid(1306633, 1, "01f61eaee829367f1b6d3740191f9a73aac6ebe24b117ac2495c3d2045db3f90")
addappid(1306634, 1, "31c5211510a171b03c7c48df446a1d446e5857154de5251fcdfb412412bcfdb1")
