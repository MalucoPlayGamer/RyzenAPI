-- Lua provided by RyzenAPI
-- Game: POPULATION: ONE

-- MAIN APPLICATION
addappid(691260)

-- MAIN APP DEPOTS / PACKAGES
addappid(691261, 1, "2cbe66b4302cbdeadf7e89a0cefe0e9ef21e7093a74aef07ec38bae497865c9d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
