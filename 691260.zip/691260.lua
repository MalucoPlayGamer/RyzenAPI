-- Lua provided by RyzenAPI
-- Game: POPULATION: ONE

-- MAIN APPLICATION
addappid(691260)
-- Game: addappid(691260)

-- MAIN APP DEPOTS / PACKAGES
addappid(691261, 1, "2cbe66b4302cbdeadf7e89a0cefe0e9ef21e7093a74aef07ec38bae497865c9d")
