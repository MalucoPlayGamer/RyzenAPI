-- Lua provided by RyzenAPI
-- Game: Senza Peso

-- MAIN APPLICATION
addappid(496190)

-- MAIN APP DEPOTS / PACKAGES
addappid(496191, 1, "d9393fc2ff83c0368fd08dd37bfa01a31df28174b0de7026e93a2d15c0bd9cb2")
