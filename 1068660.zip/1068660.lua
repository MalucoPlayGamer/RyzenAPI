-- Lua provided by RyzenAPI
-- Game: Multiverse Designer Demo

-- MAIN APPLICATION
addappid(1068660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068661, 1, "db55d4e49bab9e80ab071ce444f5f0bed19b85a51e21978daca1c488aa974e11")

