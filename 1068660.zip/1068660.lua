-- Lua provided by RyzenAPI
-- Game: 1068660

-- MAIN APPLICATION
addappid(1068660)
-- Game: addappid(1068660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068661, 1, "db55d4e49bab9e80ab071ce444f5f0bed19b85a51e21978daca1c488aa974e11")
