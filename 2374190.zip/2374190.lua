-- Lua provided by RyzenAPI
-- Game: Nikoderiko: The Magical World — Director’s Cut

-- MAIN APPLICATION
addappid(2374190)
-- Game: addappid(2374190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374191, 1, "6824d28cc3d5b903cd58d0828d1d25ecf7062324b07b5aba906dbf36b9a7a1e7")
