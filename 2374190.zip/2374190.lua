-- Lua provided by RyzenAPI
-- Game: Nikoderiko: The Magical World — Director’s Cut

-- MAIN APPLICATION
addappid(2374190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374191, 1, "6824d28cc3d5b903cd58d0828d1d25ecf7062324b07b5aba906dbf36b9a7a1e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
