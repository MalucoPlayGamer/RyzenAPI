-- Lua provided by SkyAPI 
-- Game: Nikoderiko: The Magical World — Director’s Cut
addappid(2374190)
addappid(2374191, 1, "6824d28cc3d5b903cd58d0828d1d25ecf7062324b07b5aba906dbf36b9a7a1e7")
