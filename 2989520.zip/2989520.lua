-- Lua provided by RyzenAPI
-- Game: 2989520

-- MAIN APPLICATION
addappid(2989520)
-- Game: addappid(2989520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989521, 1, "c9e2014153b91656a8d213f20fb94bccdaab00bd6b8f91c5a8d31991aa3ec69c")
