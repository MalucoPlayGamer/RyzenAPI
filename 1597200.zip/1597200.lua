-- Lua provided by RyzenAPI
-- Game: addappid(1597200)

-- MAIN APPLICATION
addappid(1597200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597202,0,"1a5d17edf9b68e730d7d0b98660cc73e000d079d2c3a9f24d0058ab3966355ee")
