-- Lua provided by SkyAPI 
-- Game: Color Splash: Fairies
addappid(2990570)
addappid(2990571, 1, "c05ca8db6089c96455acdc1737dda53056b16b90f2f626f1f5d153dfd93a9597")
