-- Lua provided by RyzenAPI
-- Game: addappid(2990570)

-- MAIN APPLICATION
addappid(2990570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990571, 1, "c05ca8db6089c96455acdc1737dda53056b16b90f2f626f1f5d153dfd93a9597")
