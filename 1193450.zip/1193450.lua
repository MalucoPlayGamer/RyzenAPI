-- Lua provided by RyzenAPI
-- Game: 1193450

-- MAIN APPLICATION
addappid(1193450)
-- Game: addappid(1193450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193451, 1, "820aa82092e9580da99c7abe3c3ee3ae5e6e3e54983f77f9419dc6b3fb7ff058")
