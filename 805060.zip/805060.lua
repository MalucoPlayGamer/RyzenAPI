-- Lua provided by RyzenAPI
-- Game: DESOLATE - Original Soundtrack

-- MAIN APPLICATION
addappid(805060)

-- MAIN APP DEPOTS / PACKAGES
addappid(805060,0,"b41341c745b92a0661e161f12a068cc87743f99bdd1166a770dead66cf81fba2")
