-- Lua provided by RyzenAPI 
-- Game: Clash II
addappid(1347760)
addappid(1347761, 1, "df0fa2e7248ed06ea3d2cd861e7553c6742b3376db8f7c83d3133c33ada83d33")
