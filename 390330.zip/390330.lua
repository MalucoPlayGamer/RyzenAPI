-- Lua provided by RyzenAPI
-- Game: Mekazoo

-- MAIN APPLICATION
addappid(390330)

-- MAIN APP DEPOTS / PACKAGES
addappid(390331, 1, "622e922c085fa2910c6231ef4bafaf7a5d2ff5953bee616f7337e90c97fbb73a")
addappid(390332, 1, "b790a794ced54faea82078a98b3c7b12e83735d015c3b1b5b0fd1c19d0cac579")
addappid(390335, 1, "5a9a39f0a89ecd0b125818c3fd0c23bfe6635fdafbae800ce830605b0bd9debc")
addappid(552850, 0, "449eca1d363ef287107c43ce79afbb6981163b8cab52ce2c3efc5c97e4466c76")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
