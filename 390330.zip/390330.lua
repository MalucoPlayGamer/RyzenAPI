-- Lua provided by RyzenAPI
-- Game: addappid(390330)

-- MAIN APPLICATION
addappid(390330)

-- MAIN APP DEPOTS / PACKAGES
addappid(390331, 1, "622e922c085fa2910c6231ef4bafaf7a5d2ff5953bee616f7337e90c97fbb73a")
addappid(390332, 1, "b790a794ced54faea82078a98b3c7b12e83735d015c3b1b5b0fd1c19d0cac579")
addappid(390335, 1, "5a9a39f0a89ecd0b125818c3fd0c23bfe6635fdafbae800ce830605b0bd9debc")
addappid(552850, 0, "449eca1d363ef287107c43ce79afbb6981163b8cab52ce2c3efc5c97e4466c76")
