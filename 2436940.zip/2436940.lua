-- Lua provided by RyzenAPI
-- Game: Sephiria

-- MAIN APPLICATION
addappid(2436940)
-- Game: addappid(2436940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436941, 1, "65e59b412db2d2909f33ac5755b0d55df645935df94bfd26610fd4f3ee60bb21")
addappid(2436942, 1, "757a2d2178c53e79923cb2f6fd7694c3fcc6293414ff982ece838c607586ac53")
