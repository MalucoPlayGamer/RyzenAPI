-- Lua provided by RyzenAPI
-- Game: Gordian Rooms: A curious heritage Prologue

-- MAIN APPLICATION
addappid(1386790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1386791, 1, "449d324b0ec1aba42c9a6f7f0d65f17c748ffff7191eb57bb3207a016d8ff5ae")

