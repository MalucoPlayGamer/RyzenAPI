-- Lua provided by RyzenAPI
-- Game: Sex motel

-- MAIN APPLICATION
addappid(2773570)
addappid(2774810)
addappid(2774820)
addappid(2774840)
addappid(2774850)
addappid(2774860)
addappid(2774870)
addappid(2774880)
addappid(2774890)
addappid(2774900)
addappid(2774910)
addappid(2774920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773571, 1, "4be9515b862bcd6c968245537c8534d8647bd407cef1e87f0c22cd7725029c3d")

