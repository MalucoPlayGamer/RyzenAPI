-- Lua provided by RyzenAPI 
-- Game: Sex motel
addappid(2773570)
addappid(2773571, 1, "4be9515b862bcd6c968245537c8534d8647bd407cef1e87f0c22cd7725029c3d")
