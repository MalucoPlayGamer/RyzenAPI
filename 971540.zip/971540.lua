-- Lua provided by RyzenAPI
-- Game: SAMS

-- MAIN APPLICATION
addappid(971540)

-- MAIN APP DEPOTS / PACKAGES
addappid(971541, 1, "ddbe2a6d3e55fe11282fa9d8859bad6a7da93cab586cadbac078a529d993f23b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
