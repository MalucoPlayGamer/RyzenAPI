-- Lua provided by RyzenAPI
-- Game: SAMS

-- MAIN APPLICATION
addappid(971540)
-- Game: addappid(971540)

-- MAIN APP DEPOTS / PACKAGES
addappid(971541, 1, "ddbe2a6d3e55fe11282fa9d8859bad6a7da93cab586cadbac078a529d993f23b")
