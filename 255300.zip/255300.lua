-- Lua provided by RyzenAPI
-- Game: Journey of a Roach

-- MAIN APPLICATION
addappid(255300)

-- MAIN APP DEPOTS / PACKAGES
addappid(255301, 1, "ef356e1634ac2e4c30c5112b12f9150c4d5abf03756ea749ff4f13f4657343dd")
addappid(255302, 1, "3f33d09d2a6a9700550437a83907355d71c47b56ecf1890502ae38c051e202f0")
addappid(255303, 1, "ebd181e24c353dc855fdbdacf28ab3508de0b2c466cc7b3ed8de59ac1a8eb042")
