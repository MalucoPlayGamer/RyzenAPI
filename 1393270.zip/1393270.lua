-- Lua provided by RyzenAPI 
-- Game: 12 bananas
addappid(1393270)
addappid(1393271, 1, "ecb3314c138f3b11635222bff042bd237526e634926ae10af9c6a28e975eba78")
addappid(1393272, 1, "2330fd06a75a0afa208302630285d04bc9c14f9e079d675ab90099758dec214b")
