-- Lua provided by RyzenAPI
-- Game: addappid(897400)

-- MAIN APPLICATION
addappid(897400)

-- MAIN APP DEPOTS / PACKAGES
addappid(897401, 1, "91f332f83fe97c3c815869864d2cbadd99f989dfe2e9958748c36abe475f1b52")
