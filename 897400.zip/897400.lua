-- Lua provided by SkyAPI 
-- Game: AppID 897400
addappid(897400)
addappid(897401, 1, "91f332f83fe97c3c815869864d2cbadd99f989dfe2e9958748c36abe475f1b52")
