-- Lua provided by RyzenAPI
-- Game: NEOGEO POCKET COLOR SELECTION Vol. 1 Steam Edition

-- MAIN APPLICATION
addappid(1586350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1586351, 1, "342f8f67c2db17486a13076db592c22fcd3194927fd3a1d3650d11adec79bcf3")

