-- Lua provided by RyzenAPI
-- Game: Game: NEOGEO POCKET COLOR SELECTION Vol. 1 Steam Edition

-- MAIN APPLICATION
addappid(1586350)
-- Game: addappid(1586350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586351, 1, "342f8f67c2db17486a13076db592c22fcd3194927fd3a1d3650d11adec79bcf3")
