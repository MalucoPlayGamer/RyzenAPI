-- Lua provided by RyzenAPI 
-- Game: NEOGEO POCKET COLOR SELECTION Vol. 1 Steam Edition
addappid(1586350)
addappid(1586351, 1, "342f8f67c2db17486a13076db592c22fcd3194927fd3a1d3650d11adec79bcf3")
