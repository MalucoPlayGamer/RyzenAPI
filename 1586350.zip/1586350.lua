-- Lua provided by RyzenAPI
-- Game: addappid(1586350)

-- MAIN APPLICATION
addappid(1586350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586351, 1, "342f8f67c2db17486a13076db592c22fcd3194927fd3a1d3650d11adec79bcf3")
