-- Lua provided by RyzenAPI
-- Game: addappid(3073350)

-- MAIN APPLICATION
addappid(3073350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073351, 1, "74550d8dd474f1dbcb54856e9d28ae153953d04f03245e11bee7b258a31af80d")
