-- Lua provided by RyzenAPI
-- Game: 1667130

-- MAIN APPLICATION
addappid(1667130)
-- Game: addappid(1667130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667131, 1, "b69a55ad510828ef6ebac599d4f0b571632eb5835155a15eac2fbe7de13f7080")
