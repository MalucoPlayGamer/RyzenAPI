-- Lua provided by RyzenAPI
-- Game: Dino Zoo Transport Simulator

-- MAIN APPLICATION
addappid(1155420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155421, 1, "43ad066c7d80a21c06cf4443480fd0ca822c27071122d01e1f751ffc5a364aa4")
