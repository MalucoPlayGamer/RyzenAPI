-- Lua provided by RyzenAPI
-- Game: Battle Cube

-- MAIN APPLICATION
addappid(1506660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506661, 1, "89137605b486ca782a1c00fc1b7beca0293f1fe25da7a384f5cfe17150eb5a77")

