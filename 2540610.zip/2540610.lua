-- Lua provided by RyzenAPI 
-- Game: WARCANA Demo
addappid(2540610)
addappid(2540611, 1, "f462259f464d84422baa01e2674f9fee242dc6468f5b7cedc3e71d8b101ecfdc")
