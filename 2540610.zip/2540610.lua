-- Lua provided by RyzenAPI
-- Game: 2540610

-- MAIN APPLICATION
addappid(2540610)
-- Game: addappid(2540610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540611, 1, "f462259f464d84422baa01e2674f9fee242dc6468f5b7cedc3e71d8b101ecfdc")
