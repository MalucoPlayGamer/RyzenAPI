-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Fallen Brave Squad

-- MAIN APPLICATION
addappid(3705380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3705381, 1, "080cbd6952e9c81c88d5ece1575c643ce3165f1b3d329fa4f535e0c860b666e1")

