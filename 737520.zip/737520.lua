-- Lua provided by SkyAPI 
-- Game: AppID 737520
addappid(737520)
addappid(737521, 1, "f0547bcf8bc6f16645f6816e1dc861867d05b987621a7f9a2f5708cdea77b1a6")
