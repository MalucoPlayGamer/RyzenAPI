-- Lua provided by RyzenAPI
-- Game: 737520

-- MAIN APPLICATION
addappid(737520)
-- Game: addappid(737520)

-- MAIN APP DEPOTS / PACKAGES
addappid(737521, 1, "f0547bcf8bc6f16645f6816e1dc861867d05b987621a7f9a2f5708cdea77b1a6")
