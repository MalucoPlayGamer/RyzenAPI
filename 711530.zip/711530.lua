-- Lua provided by RyzenAPI
-- Game: Butterfly Moment

-- MAIN APPLICATION
addappid(711530)

-- MAIN APP DEPOTS / PACKAGES
addappid(711531, 1, "18c2931f7c17f261dc2ec47f12926c42843caeef04f6e1a09ef5372bfc06be93")

