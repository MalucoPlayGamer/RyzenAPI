-- Lua provided by RyzenAPI
-- Game: 357480

-- MAIN APPLICATION
addappid(357480)
-- Game: addappid(357480)

-- MAIN APP DEPOTS / PACKAGES
addappid(357482,0,"f0bb1d6d439d29b7f9cacd819e2bfea8479bbec0c88f0396006ecbd41319dcd1")
