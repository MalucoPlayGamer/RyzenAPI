-- Lua provided by RyzenAPI
-- Game: 2778740

-- MAIN APPLICATION
addappid(2778740)
-- Game: addappid(2778740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778744,0,"9c3bd59c36132aeb88ba09dca4cb0e93784d0945ffb135c4e5c7c7e5a08e827f")
