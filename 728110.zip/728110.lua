-- Lua provided by SkyAPI 
-- Game: AppID 728110
addappid(728110)
addappid(728111, 1, "7ad40c5d10581461a124598082168885a04590763ea3721366b4cd92a922aa9e")
addappid(973930)
addappid(1010960)
