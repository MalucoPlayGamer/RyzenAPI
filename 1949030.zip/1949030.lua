-- Lua provided by RyzenAPI
-- Game: Sherlock Holmes The Awakened

-- MAIN APPLICATION
addappid(1949030)
addappid(2208700)
addappid(2208701)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1949031, 1, "9d24669555d74ce46354104ac51cabb0d56b98f2be48de9c9eef2ff5b2a392cc")
addappid(1949032, 1, "f5ed67a9eed700ec2032583ddac5767254f593873bcc340b7b30141eac7d1dc7")
addappid(2330100, 0, "21dd9d672e685c3529683b7c95ec6e28aaae408ef532769282a39c17f9f0d43c")

