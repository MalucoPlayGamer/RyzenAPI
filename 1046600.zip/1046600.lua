-- Lua provided by RyzenAPI
-- Game: Game: 勇者有点太嚣张。™G(No Hero Allowed: No Puzzle Either!)

-- MAIN APPLICATION
addappid(1046600)
-- Game: addappid(1046600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046601, 1, "05b1e1320413ac27fd379d18c6674f2d7dfc0b42485a0e405894fcdb3978fb75")
