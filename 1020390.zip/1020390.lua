-- Lua provided by RyzenAPI
-- Game: 1020390

-- MAIN APPLICATION
addappid(1020390)
-- Game: addappid(1020390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020391, 1, "b99efc313f4f0d27faa56c4bb48ff55b563ed0bd0bbac966b440572b84952bcf")
