-- Lua provided by RyzenAPI
-- Game: Koi-Koi Japan [Hanafuda playing cards]

-- MAIN APPLICATION
addappid(364930)
addappid(372440)
addappid(510610)
addappid(520430)
addappid(557390)
addappid(1491860)

-- MAIN APP DEPOTS / PACKAGES
addappid(364931, 1, "c32204f8e753a97f6297e88cee3fdc456d20e48e74e84403c688252c362f876f")
addappid(364932, 1, "20a27099b209e09b94b448107609f23da8827a10cc053fa52c1da26a28a76c22")
