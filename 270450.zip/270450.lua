-- Lua provided by RyzenAPI
-- Game: Robot Roller-Derby Disco Dodgeball

-- MAIN APPLICATION
addappid(270450)
-- Game: addappid(270450)

-- MAIN APP DEPOTS / PACKAGES
addappid(270451, 1, "607a3a77aed19657402342101ff3bda74277557eddf2655ced6b55e6f1f4a32d")
addappid(270452, 1, "9ee8b30365b096092ada8f94e41bd5134af16327cd2e79dffdfb3db1e193366f")
addappid(270453, 1, "75bfa3f4ba3091472fc2dfad9c14c64fd058185265b74376cbfa88124ee3a982")
