-- Lua provided by RyzenAPI
-- Game: Blackthorn Arena: Reforged - Supporter Pack

-- MAIN APPLICATION
addappid(3363660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3363660,0,"55b793da8c0f3c1924b44589a6ba46aa73793e0de3a39afce32ea5fac4de9c4d")

