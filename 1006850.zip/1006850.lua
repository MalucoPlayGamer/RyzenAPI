-- Lua provided by RyzenAPI
-- Game: addappid(1006850)

-- MAIN APPLICATION
addappid(1006850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006851, 1, "1f4b029bf7937565f1a1856d8d336da2d68c9961d05cffe2ac22cb65879e93f0")
