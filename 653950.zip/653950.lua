-- Lua provided by RyzenAPI
-- Game: AppID 653950

-- MAIN APPLICATION
addappid(653950)

-- MAIN APP DEPOTS / PACKAGES
addappid(653951, 1, "3e697fe5d1e85a6f228c1f5cb09c3a3ac7063973bf20f29e7ecf3d200b44191b")
addappid(653952, 1, "718cb27440d75b8c407547522644488a208b80f665ddf73d44d5695162a51525")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(667250)
