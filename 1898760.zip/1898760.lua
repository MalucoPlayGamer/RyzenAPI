-- Lua provided by RyzenAPI
-- Game: 1898760

-- MAIN APPLICATION
addappid(1898760)
-- Game: addappid(1898760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1898761, 1, "4522e8574e38d82c69f709f3ee4801f9c2b8d94eaa94b4f886182f2973ccdd82")
