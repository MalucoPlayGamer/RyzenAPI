-- Lua provided by RyzenAPI 
-- Game: AppID 1898760
addappid(1898760)
addappid(1898761, 1, "4522e8574e38d82c69f709f3ee4801f9c2b8d94eaa94b4f886182f2973ccdd82")
