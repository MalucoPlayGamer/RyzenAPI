-- Lua provided by RyzenAPI
-- Game: Hero Tale Soundtrack

-- MAIN APPLICATION
addappid(2730740)
-- Game: addappid(2730740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730741, 1, "49c68c8553d9cee285fb171d97666a69fcedb7472f3d288d650e70369997bdcd")
addappid(2730742, 1, "a0537e1ceaf7675d5b2527c30ad253d0ba5046822229e915f8f9dc49d65504ab")
