-- Lua provided by RyzenAPI
-- Game: addappid(1222870)

-- MAIN APPLICATION
addappid(1222870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222871, 1, "95d44a3eec582113a5f9cbcb73fcee408738cfa0a9bc3e3ec55aaaec23123fd3")
