-- Lua provided by RyzenAPI
-- Game: Dransik

-- MAIN APPLICATION
addappid(1871470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1871471, 1, "47599d724210a01e2f3c991730d8ac2b24854c9c6971fbc6d260f2542318d48c")

