-- Lua provided by RyzenAPI
-- Game: AppID 880750

-- MAIN APPLICATION
addappid(880750)

-- MAIN APP DEPOTS / PACKAGES
addappid(880751, 1, "6b2caa760e95759834f2d1ac082061afe08847932d5cc8cb01bff539590f9a86")
addappid(880752, 1, "3c386e41015a67d3c98aa58c20faf22871fbf9f3dd9099beafc1ef5ab4132b59")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
