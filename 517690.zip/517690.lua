-- Lua provided by RyzenAPI
-- Game: AppID 517690

-- MAIN APPLICATION
addappid(517690)

-- MAIN APP DEPOTS / PACKAGES
addappid(517691, 1, "1c06cb6816a01d50b55cec497634eced28e1e76bcdf6212a73f8c0ceb1eea69e")
