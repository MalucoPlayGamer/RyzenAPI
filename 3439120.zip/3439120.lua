-- Lua provided by RyzenAPI
-- Game: addappid(3439120)

-- MAIN APPLICATION
addappid(3439120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3439121, 1, "6be56a838240678afc22dfae5940d544c8adcce91b0923f3f63c9d632585f8f4")
