-- Lua provided by RyzenAPI
-- Game: AppID 1853560

-- MAIN APPLICATION
addappid(1853560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853561, 1, "759b15874bd769a6a27fcdc7369593c4eeda353f5ebd1de3f43ddff8da8e8d43")
