-- Lua provided by RyzenAPI
-- Game: Cube - The Jumper

-- MAIN APPLICATION
addappid(856440)

-- MAIN APP DEPOTS / PACKAGES
addappid(856441, 1, "f538148aa6ab42352c8605f51a031305f5c05ada15a3e5a75e6748210e588430")
