-- Lua provided by RyzenAPI
-- Game: Mad Adventures

-- MAIN APPLICATION
addappid(1840660)

