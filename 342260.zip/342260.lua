-- Lua provided by RyzenAPI
-- Game: AppID 342260

-- MAIN APPLICATION
addappid(342260)

-- MAIN APP DEPOTS / PACKAGES
addappid(342261, 1, "e5fb3678e1de1de5c74c11aa0da3c720445f19f5dbd5f3446adbb3d51beca615")
addappid(342262, 1, "2ad62229e5efadf133a321d901ab37aa82dcc4a3a3191fccfafc93ef7459d299")
addappid(342263, 1, "48f42132d75a370d33e2982a692f3751097eeb6e85d408c78f81c242ec5b9ff6")
addappid(401860, 0, "d88d8cdcb6b2048372da875dcd7850feaf69c0360c61769f10b5715598408b7d")
addappid(572750, 0, "e0b39043532bbcbae8be778e01fb1fee05995206d8f6035be1d22871924a74d0")
addappid(738850, 0, "f5adbdb2c8639b514178337b36d48a3b0666e04edd69f6eeb09e20442d53559d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
