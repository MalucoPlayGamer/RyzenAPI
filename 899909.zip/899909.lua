-- Lua provided by RyzenAPI
-- Game: 899909

-- MAIN APPLICATION
addappid(899909)
-- Game: addappid(899909)

-- MAIN APP DEPOTS / PACKAGES
addappid(899909,0,"9cf1fa728b6bc320ac0ee8dceefec88da623a788fb89cc815bd361ca396d1ce9")
