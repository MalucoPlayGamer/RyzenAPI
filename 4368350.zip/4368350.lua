-- Lua provided by RyzenAPI
-- Game: Silly Linguine Cat Simulator Deluxe Online

-- MAIN APPLICATION
addappid(4368350)
