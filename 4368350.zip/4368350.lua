-- Lua provided by RyzenAPI
-- Game: Silly Linguine Cat Simulator Deluxe Online

-- MAIN APPLICATION
addappid(4368350)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4599230)
addappid(5073640)
