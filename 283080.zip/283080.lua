-- Lua provided by SkyAPI 
-- Game: Super Chibi Knight
addappid(283080)
addappid(283081, 1, "04a420f82b9fec1f92487f96d6ceb049e2a806cb565b91f34afa1194019f79b9")
addappid(283082, 1, "42b204cb7f89aee2ce07fa2c7211372a2131238f2f742588cd1f38d79841c4ab")
addappid(283083, 1, "9fc06edf41db4f2852c1506a29eedfb385e962177b798400c8df1904e53e286c")
addappid(373780, 0, "fc2fcdd87ec524a14f8c609be62965f180526fa7a6cdf7b90e8285b29a9ca7dd")
