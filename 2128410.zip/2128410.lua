-- Lua provided by RyzenAPI
-- Game: Game: World of Naples

-- MAIN APPLICATION
addappid(2128410)
-- Game: addappid(2128410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128411, 1, "c92f33d099dc902d272fbefa808522edb2189a32334b702b9dcf791e3224bace")
