-- Lua provided by RyzenAPI
-- Game: Gold Gold Adventure Gold

-- MAIN APPLICATION
addappid(3133650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133651,0,"7ea9fe11b244ae802bfb297c05a383923aa83b0169d908cc4eb1ba359ae1909c")

