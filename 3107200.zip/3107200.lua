-- Lua provided by RyzenAPI
-- Game: Anger Foot Soundtrack

-- MAIN APPLICATION
addappid(3107200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107201, 1, "2a4e4b8d5c3ac47c04df3dccca946102bc4bda27330249be70f9d1c360df4afb")
addappid(3107209, 1, "058a4a02dae8bfada903fe7e4e018a62810c6fc667af80a86748d1e52a797a4c")

