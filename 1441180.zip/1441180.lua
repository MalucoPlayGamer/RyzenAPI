-- Lua provided by SkyAPI 
-- Game: Dofamine
addappid(1441180)
addappid(1441181, 1, "595c4fee967aceddd7f2f30eddbd76aa97fd564839bfb38e36b23cacb920022e")
