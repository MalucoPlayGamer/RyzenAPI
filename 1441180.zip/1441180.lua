-- Lua provided by RyzenAPI
-- Game: addappid(1441180)

-- MAIN APPLICATION
addappid(1441180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441181, 1, "595c4fee967aceddd7f2f30eddbd76aa97fd564839bfb38e36b23cacb920022e")
