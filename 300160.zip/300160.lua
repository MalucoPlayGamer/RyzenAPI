-- Lua provided by RyzenAPI
-- Game: Bridge!

-- MAIN APPLICATION
addappid(300160)

-- MAIN APP DEPOTS / PACKAGES
addappid(300161, 1, "5eaeab322e6099df5746ed032825d2a26831b4b1a11933aa06bb507c97d3cf33")
