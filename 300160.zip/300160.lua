-- Lua provided by RyzenAPI
-- Game: Bridge!

-- MAIN APPLICATION
addappid(300160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(300161, 1, "5eaeab322e6099df5746ed032825d2a26831b4b1a11933aa06bb507c97d3cf33")

