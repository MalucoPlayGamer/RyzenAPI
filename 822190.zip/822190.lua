-- Lua provided by RyzenAPI
-- Game: Little Bug

-- MAIN APPLICATION
addappid(822190)

-- MAIN APP DEPOTS / PACKAGES
addappid(822191,0,"f887a320ea5d9ea534022230b3fec1375f2cbbb93a7997ed318617a7d0152b52")

