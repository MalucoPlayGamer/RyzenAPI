-- Lua provided by RyzenAPI
-- Game: addappid(607190)

-- MAIN APPLICATION
addappid(607190)

-- MAIN APP DEPOTS / PACKAGES
addappid(607191, 1, "585fbbbcd1f1101de642b22e410ea9ae757c843bc92b4cb91416edf020d3d834")
