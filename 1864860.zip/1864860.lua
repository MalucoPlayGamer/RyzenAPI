-- Lua provided by RyzenAPI 
-- Game: Hidden Islands
addappid(1864860)
addappid(1864861, 1, "21fbe1ab5e83747d529a3c4fe72dbf9559bf3e180dea69fd9543c99f33541e2a")
