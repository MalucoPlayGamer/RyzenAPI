-- Lua provided by RyzenAPI
-- Game: addappid(2564520)

-- MAIN APPLICATION
addappid(2564520)
addappid(3573930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564521, 1, "4b679f8c7ffc59c1398369a7bb72987e78717c22d81ec186eb11bb0cc0e5f6e8")
addappid(3478380, 0, "08b4f767f1591c4c96ec034dd7c78d0d442ac1d6c39586fff1ece5f94a7e4e6c")
