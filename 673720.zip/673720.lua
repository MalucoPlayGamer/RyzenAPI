-- Lua provided by RyzenAPI
-- Game: Police Adventure

-- MAIN APPLICATION
addappid(673720)

-- MAIN APP DEPOTS / PACKAGES
addappid(673721,0,"e13b1d80881771c997ea5711c822dde1a0f75690ab8eaa6cbf4667370cd52537")

