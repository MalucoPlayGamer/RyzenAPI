-- Lua provided by RyzenAPI
-- Game: 3075710

-- MAIN APPLICATION
addappid(3075710)
-- Game: addappid(3075710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075711, 1, "34fa9675438431e391ee2794ffb0d0817a5dbf216992d63048ccab8fe3c47856")
