-- Lua provided by RyzenAPI
-- Game: Castaway Paradise - live among the animals

-- MAIN APPLICATION
addappid(304950)
addappid(370880)
addappid(380760)
addappid(381630)
addappid(388780)
addappid(667650)

-- MAIN APP DEPOTS / PACKAGES
addappid(304951, 1, "bdb20a4ee27e0e65b61134f7030dd1011df2c96631106deaee707e3c08099df7")
addappid(304952, 1, "e7eaf2cb70cdb64d379815741666b758d63f0e0f872385d58d4cb5f0e6cef103")
addappid(410140, 0, "adff834a62ac1224436abf83f7913bd3e339ab1fc4a16053f268ea42c6ed04d3")
addappid(438830, 0, "946f60c83f2cd3e1e923fd2af31d344b3a84cabadb95e8d99ae12590a9b2f354")
addappid(438831, 0, "9cf748503bcfd10eef37459f32351715e9b3fe73960dcd5a77051da6fcd4a2ad")

