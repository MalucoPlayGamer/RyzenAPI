-- Lua provided by RyzenAPI
-- Game: Converter

-- MAIN APPLICATION
addappid(1574390)
-- Game: addappid(1574390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574391, 1, "70d4839582391e9a1100a752fc4bac020321ae9833c4127d020277215ca0a473")
