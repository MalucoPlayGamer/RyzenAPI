-- Lua provided by RyzenAPI
-- Game: Mutagenic

-- MAIN APPLICATION
addappid(2082560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082561, 1, "836d483d0a57d47e887ade9e357ae5ecbe08e8a1ff13c08098d7e821662807f3")
