-- Lua provided by RyzenAPI
-- Game: addappid(1483420)

-- MAIN APPLICATION
addappid(1483420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483421, 1, "8c0416d35cd9d8e5f2ce2042abd318db2441377643e5dfdee1682ea2ba938dd1")
