-- Lua provided by RyzenAPI
-- Game: addappid(2686690)

-- MAIN APPLICATION
addappid(2686690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686691, 1, "7c3e669dcfadc1d709fcabc24f15dbba902de24bde3fbe2253297acf0da84941")
