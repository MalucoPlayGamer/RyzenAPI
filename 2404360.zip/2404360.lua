-- Lua provided by RyzenAPI
-- Game: addappid(2404360)

-- MAIN APPLICATION
addappid(2404360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404361, 1, "9c81502c38d21e622cae80dfe7f1ef80d2118848dd26f0033e1ff8943bb3b90a")
