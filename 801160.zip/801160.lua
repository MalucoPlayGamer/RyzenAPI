-- Lua provided by RyzenAPI
-- Game: AppID 801160

-- MAIN APPLICATION
addappid(801160)

-- MAIN APP DEPOTS / PACKAGES
addappid(801161, 1, "33fbf2af3cde2bad07352f676e03e973b1fdedd467cf295c0ba63d2eccfd7069")
