-- Lua provided by RyzenAPI
-- Game: The Kingdom of the End＆The Witch of the Beginning

-- MAIN APPLICATION
addappid(1988100)
-- Game: addappid(1988100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988101, 1, "acd2c1a43b3bb62ce541b237d7c6b0d5f2f7cc0add722497c36e7f52c0cb09f6")
addappid(1988102, 1, "0a2a4615699451e0c2823aeaf61e9e113ce5ab8110f788c2f52a67934892133c")
addappid(1988103, 1, "d7a1fd6fe8cf3b587fb3ffefbc248f69420b8ecc92dcdeacc570016e57a2eed6")
addappid(1988104, 1, "c58c1cbf7d8153b6303efe88367cad4477b96476356e7f1bf90588043f6dc0eb")
addappid(1988105, 1, "301664e12d8fe0e28869688284713baea8847d06820a0c93a01a3a912f661984")
