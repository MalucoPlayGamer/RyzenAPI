-- Lua provided by SkyAPI 
-- Game: AppID 362870
addappid(362870)
addappid(362871, 1, "a1e4d8ec2af4f2aa3c010cbc833324f6bf8d2aa47fa03ab597fc28eeac041769")
addappid(367490)
