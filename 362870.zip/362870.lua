-- Lua provided by RyzenAPI
-- Game: 362870

-- MAIN APPLICATION
addappid(362870)
addappid(367490)
-- Game: addappid(362870)

-- MAIN APP DEPOTS / PACKAGES
addappid(362871, 1, "a1e4d8ec2af4f2aa3c010cbc833324f6bf8d2aa47fa03ab597fc28eeac041769")
