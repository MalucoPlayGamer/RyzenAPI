-- Lua provided by RyzenAPI 
-- Game: AppID 600210
addappid(600210)
addappid(600211, 1, "64c5c08fe719a2310852f6d1ab04d0f8e7013cb8f49f07ffae63972fa67b25ea")
