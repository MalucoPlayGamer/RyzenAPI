-- Lua provided by RyzenAPI
-- Game: RoboMatch

-- MAIN APPLICATION
addappid(600210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(600211, 1, "64c5c08fe719a2310852f6d1ab04d0f8e7013cb8f49f07ffae63972fa67b25ea")

