-- Lua provided by RyzenAPI
-- Game: AppID 1822990

-- MAIN APPLICATION
addappid(1822990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822991, 1, "a6ebc61b3944498b3635f9e04b745b55ccf51bae1bcb77b69daf1308ae3791fb")
