-- Lua provided by RyzenAPI
-- Game: addappid(1973370)

-- MAIN APPLICATION
addappid(1973370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973371, 1, "05e26d15bd61ea7f9c740165c52fd2ef844ece94fb265f3cddf260e1a77b1914")
