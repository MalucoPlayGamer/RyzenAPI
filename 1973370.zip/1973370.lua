-- Lua provided by RyzenAPI
-- Game: Tracing Decay

-- MAIN APPLICATION
addappid(1973370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1973371, 1, "05e26d15bd61ea7f9c740165c52fd2ef844ece94fb265f3cddf260e1a77b1914")

