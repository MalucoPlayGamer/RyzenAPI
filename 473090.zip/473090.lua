-- Lua provided by RyzenAPI
-- Game: Shoppe Keep - Original Soundtrack

-- MAIN APPLICATION
addappid(473090)
-- Game: addappid(473090)

-- MAIN APP DEPOTS / PACKAGES
addappid(473091, 1, "b80d4cd0f67f27ce6e09fc77641aa0f908a583c1078dd5b8929c5616dc1ad72c")
