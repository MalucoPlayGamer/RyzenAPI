-- Lua provided by RyzenAPI 
-- Game: Fireside
addappid(1722700)
addappid(1722701, 1, "5efae921b650e5db8643a8626e865cbdfa7b8730ebf88dac1f1028e3fa6d4419")
