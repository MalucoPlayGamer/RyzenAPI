-- Lua provided by RyzenAPI
-- Game: addappid(555880)

-- MAIN APPLICATION
addappid(555880)
addappid(861300)

-- MAIN APP DEPOTS / PACKAGES
addappid(555881, 1, "d1e67737cee67ad3f0cc35b498267c07fe2b3912d8e00355465f982d30e210d2")
