-- Lua provided by RyzenAPI 
-- Game: Life is Strange: True Colors Demo
addappid(2000100)
addappid(2000101, 1, "63671c7067770bfa2d50dcee37de323c483753185cae82b0aa16052b89a8fd39")
