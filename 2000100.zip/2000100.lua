-- Lua provided by RyzenAPI
-- Game: addappid(2000100)

-- MAIN APPLICATION
addappid(2000100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000101, 1, "63671c7067770bfa2d50dcee37de323c483753185cae82b0aa16052b89a8fd39")
