-- Lua provided by RyzenAPI
-- Game: addappid(1849440)

-- MAIN APPLICATION
addappid(1849440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849441, 1, "aacb01eb935ae46f7656388879bf99f562d63422534cbbcfefcac6aeed1c438e")
addappid(1849442, 1, "46fd9686c95c9afadedd334ad7a7443fdca110caad0486844554fc65f750d25a")
