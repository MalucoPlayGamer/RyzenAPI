-- Lua provided by RyzenAPI
-- Game: 3624390

-- MAIN APPLICATION
addappid(3624390)
-- Game: addappid(3624390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3624391, 1, "59beea265007f3bdb66861fd5e6675e371fc801e527c5c0804aeb66b62a43ad9")
