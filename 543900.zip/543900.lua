-- Lua provided by RyzenAPI
-- Game: addappid(543900)

-- MAIN APPLICATION
addappid(543900)

-- MAIN APP DEPOTS / PACKAGES
addappid(543901, 1, "6660062fa5608dd613cb712c1e4f4d930be90938794ff33a3963dab922c843bf")
