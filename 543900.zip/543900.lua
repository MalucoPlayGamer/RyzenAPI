-- Lua provided by RyzenAPI
-- Game: METAL GEAR SURVIVE

-- MAIN APPLICATION
addappid(543900)
addappid(631800)
addappid(631801)
addappid(631802)
addappid(631803)
addappid(802030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(543901, 1, "6660062fa5608dd613cb712c1e4f4d930be90938794ff33a3963dab922c843bf")
