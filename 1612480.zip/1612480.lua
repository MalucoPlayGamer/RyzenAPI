-- Lua provided by SkyAPI 
-- Game: Heal Hitler
addappid(1612480)
addappid(1612481, 1, "3a7ba0563a5e6ede37c14cff13589fa39f4a01a4509d6ead2586a119f3bbaf95")
addappid(1612482, 1, "c908d6f9c123d5b36e40f7273c053da232cc1d6d0d665d62e2339a424d8248e7")
