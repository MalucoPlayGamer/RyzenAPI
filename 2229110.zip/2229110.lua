-- Lua provided by RyzenAPI
-- Game: A Familiar World

-- MAIN APPLICATION
addappid(2229110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229111, 1, "545560c855b12640b4fa89e443938b6068089e3e5cec4e38e4b5c6c431218863")

