-- Lua provided by RyzenAPI
-- Game: Game: Angry Video Game Nerd II: ASSimilation

-- MAIN APPLICATION
addappid(409660)
-- Game: addappid(409660)

-- MAIN APP DEPOTS / PACKAGES
addappid(409661, 1, "f93ce53e3c40c24b16c4121801a70c0107347e39c3a89e0dbcc3788bee974890")
addappid(409662, 1, "a294f56027330b069cc0d0cfe061d5aadea3174c7514382584b7db9258d4a3b2")
addappid(409663, 1, "30064e56790a5a78073220fc2ed157f71e3e4963e9e4e20c3b47b84e33d71926")
