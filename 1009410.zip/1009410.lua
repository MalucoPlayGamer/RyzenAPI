-- 1009410's Lua and Manifest Created by Hubcap Manifest
-- Eternal Exodus
-- Created: June 16, 2026 at 04:24:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1009410) -- Eternal Exodus
-- MAIN APP DEPOTS
addappid(1009411, 1, "8157ecace345af7b1f4d55a61f608584b2a91502791c0ca25e4a86e831af87c8") -- Depot 1009411
-- setManifestid(1009411, "6410607211309424595", 2949305957)
addappid(1009412, 1, "3059f371c2ec0357c5e4c12755024cc787622bc84b72bdecac7cdd7f0c1b82ee") -- Depot 1009412
-- setManifestid(1009412, "1392462749016691337", 2955935449)
addappid(1009413, 1, "4c8ac2d2e92cbbe78b0f9c377adfb208ab9a58e5b945c04418f67f50b94ec532") -- Depot 1009413
-- setManifestid(1009413, "905027483689148304", 2995760174)