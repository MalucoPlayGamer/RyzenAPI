-- Lua provided by SkyAPI 
-- Game: STOP and MOVE
addappid(1519850)
addappid(1519851, 1, "11439db718a8774970e98936c1ca890b5eed04020f6b01d9acf38ee48c66d49f")
addappid(1519852, 1, "6cede7686205eb61ccf531444b803078b9802ce2c3d8c4e251ec537be067e5ee")
