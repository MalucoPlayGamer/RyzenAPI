-- Lua provided by RyzenAPI
-- Game: Otome Riron to Sono Shuuhen -École de Paris-

-- MAIN APPLICATION
addappid(2567190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567191, 1, "a71a45a360848e611f022091211a93de8eec0f97cbed756582db6aeca510cc3e")

