-- Lua provided by RyzenAPI
-- Game: Fate/Samurai Remnant - Additional Episode 2 "Record's Fragment: Yagyu Sword Chronicles"

-- MAIN APPLICATION
addappid(2494240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494240,0,"db064c19da0817e0898deb4cd5f4ddefc8ea01d695549eae9272582791f2b5e3")
