-- Lua provided by RyzenAPI
-- Game: Infinite Space III: Sea of Stars

-- MAIN APPLICATION
addappid(269990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(269991, 1, "25c9141c14675d3df3f91a890ab836c9d3ccb89c788aae8c1999fbbdf4124d6c")
addappid(269992, 1, "5be49542aa1d2bba45003c2a0519a3e8175ff9fa5166fbd876b11a86178220b7")
addappid(383600, 0, "78f8b8d3602357c41f5ab48e17868f12a68c294919804ee364f346caa593898d")

