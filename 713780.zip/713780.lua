-- Lua provided by RyzenAPI
-- Game: AppID 713780

-- MAIN APPLICATION
addappid(713780)
-- Game: addappid(713780)

-- MAIN APP DEPOTS / PACKAGES
addappid(713781, 1, "5ddc84a77d9e1dff6c942720badcc0f102be414ce768e55b73afc087d4ac2302")
