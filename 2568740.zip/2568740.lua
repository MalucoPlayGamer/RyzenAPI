-- Lua provided by SkyAPI 
-- Game: AppID 2568740
addappid(2568740)
addappid(2568741, 1, "6c4504edc7e3555309decba562d87ca10042b41cbf2754e277017d5242474b91")
