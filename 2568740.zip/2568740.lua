-- Lua provided by RyzenAPI
-- Game: Hell Throne Demo

-- MAIN APPLICATION
addappid(2568740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2568741, 1, "6c4504edc7e3555309decba562d87ca10042b41cbf2754e277017d5242474b91")

