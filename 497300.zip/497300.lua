-- Lua provided by RyzenAPI
-- Game: 497300

-- MAIN APPLICATION
addappid(497300)
-- Game: addappid(497300)

-- MAIN APP DEPOTS / PACKAGES
addappid(497301, 1, "f168d9238c1af88363a5ceda9f6f13785776ac369eb670e2d88096ae9c224cc6")
