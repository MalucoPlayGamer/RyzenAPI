-- Lua provided by RyzenAPI
-- Game: HENTAI EXOTICA vol.2

-- MAIN APPLICATION
addappid(1155960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155961, 1, "ded3ea21e426bf2e900b90bcdebf7f5181644eff347c924bd9decc5e240ed0e7")

