-- Lua provided by RyzenAPI
-- Game: Traders Life Together

-- MAIN APPLICATION
addappid(4669230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4669231,0,"e59844a809efd83bbb6dd1bcd6333d027f6b75517972495858e57b309fb65872")

