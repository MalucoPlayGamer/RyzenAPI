-- Lua provided by RyzenAPI
-- Game: Traders Life Together

-- MAIN APPLICATION
addappid(4669230)

-- MAIN APP DEPOTS / PACKAGES
addappid(4669231,0,"e59844a809efd83bbb6dd1bcd6333d027f6b75517972495858e57b309fb65872")

