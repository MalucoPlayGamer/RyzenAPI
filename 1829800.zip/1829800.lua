-- Lua provided by RyzenAPI
-- Game: Ultimate Super Powers Old Maid～3Days～

-- MAIN APPLICATION
addappid(1829800)
addappid(2296630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829801, 1, "9e9a07c232214b6a9d1e7baeddc5f4cbd1a57daf95f79ffb9cd8bcca7e0b5809")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
