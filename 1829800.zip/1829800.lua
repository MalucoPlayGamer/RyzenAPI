-- Lua provided by RyzenAPI
-- Game: Ultimate Super Powers Old Maid～3Days～

-- MAIN APPLICATION
addappid(1829800)
addappid(2296630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829801, 1, "9e9a07c232214b6a9d1e7baeddc5f4cbd1a57daf95f79ffb9cd8bcca7e0b5809")

