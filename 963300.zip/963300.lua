-- Lua provided by SkyAPI 
-- Game: AppID 963300
addappid(963300)
addappid(963301, 1, "ced0a1f1931bbd3a941b3884becd3b8fa745bf8e7f42fb325191cc420607a425")
