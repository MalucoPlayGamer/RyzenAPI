-- Lua provided by RyzenAPI
-- Game: Angel, Devil, Elf and Me!

-- MAIN APPLICATION
addappid(963300)

-- MAIN APP DEPOTS / PACKAGES
addappid(963301, 1, "ced0a1f1931bbd3a941b3884becd3b8fa745bf8e7f42fb325191cc420607a425")

