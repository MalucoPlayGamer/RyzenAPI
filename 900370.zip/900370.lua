-- Lua provided by RyzenAPI
-- Game: Stockpile

-- MAIN APPLICATION
addappid(900370)

-- MAIN APP DEPOTS / PACKAGES
addappid(900371, 1, "766cf7990f9e72e80dadb076a004535688de3ddc1d33e5c6c13ef09b442ff9c4")

