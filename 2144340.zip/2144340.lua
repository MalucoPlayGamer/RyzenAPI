-- Lua provided by RyzenAPI
-- Game: 女拳主義F-ist Demo

-- MAIN APPLICATION
addappid(2144340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144341, 1, "385c3dde7a83a0f220873416bbbb5c707888723013a88ab48ec04c1b01caf8b1")

