-- Lua provided by RyzenAPI
-- Game: Touhou Volleyball

-- MAIN APPLICATION
addappid(3813380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3813381, 1, "5d4a29b472049e7501098d44ce4543f7ef4fae02bfc4d0c0a18de78f474ae893")
