-- Lua provided by RyzenAPI
-- Game: Game: RaceTrap

-- MAIN APPLICATION
addappid(2668330)
-- Game: addappid(2668330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668331, 1, "f2c3612e15190797dfee89c1f0ee289b9d153e8534320475f948eade0b31a036")
addappid(2668332, 1, "dafd2e6a8ae936ac687367db024b997c2a809ebb31edf1779fadcdb369668c46")
