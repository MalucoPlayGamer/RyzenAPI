-- Lua provided by RyzenAPI
-- Game: 江湖侠客行

-- MAIN APPLICATION
addappid(842190)

-- MAIN APP DEPOTS / PACKAGES
addappid(842191,0,"833d2f176417c177a05f1ff3146524f76950322ac4b623c65a88c570fdc9c7ed")

