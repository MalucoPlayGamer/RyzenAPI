-- Lua provided by SkyAPI 
-- Game: Leaper
addappid(1495670)
addappid(1495671, 1, "5bf1e20ac51593c9f5a13f6f1dcac396f87fa60ac85dbf93430e5f88559c8549")
