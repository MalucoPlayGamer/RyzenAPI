-- Lua provided by RyzenAPI
-- Game: Leaper

-- MAIN APPLICATION
addappid(1495670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495671, 1, "5bf1e20ac51593c9f5a13f6f1dcac396f87fa60ac85dbf93430e5f88559c8549")
