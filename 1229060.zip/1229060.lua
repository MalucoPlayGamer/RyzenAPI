-- Lua provided by RyzenAPI
-- Game: Dungeon and Puzzles

-- MAIN APPLICATION
addappid(1229060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229061, 1, "999e316b6ef11e382d397832e9dc692895ef0c1c791e2d9583e11497c5736e62")
