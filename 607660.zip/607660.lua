-- Lua provided by RyzenAPI
-- Game: addappid(607660)

-- MAIN APPLICATION
addappid(607660)

-- MAIN APP DEPOTS / PACKAGES
addappid(607662,0,"0244be0f0d835409cb6aa2656d3700d97c8abf70f0a67b86c6c59d8864584eba")
