-- Lua provided by RyzenAPI
-- Game: Game: Timber Tennis: Versus

-- MAIN APPLICATION
addappid(321160)
-- Game: addappid(321160)

-- MAIN APP DEPOTS / PACKAGES
addappid(321161, 1, "772ce9b709588c7625149cac1f1ef909441e5e607ac2392dab332ede490b0983")
addappid(321162, 1, "fb72332574e7d4b05da50fd02f0f6fd9a7597a09a86377996f0147ef5342b601")
