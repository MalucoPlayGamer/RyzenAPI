-- Lua provided by RyzenAPI
-- Game: addappid(4240)

-- MAIN APPLICATION
addappid(4240)

-- MAIN APP DEPOTS / PACKAGES
addappid(4231,0,"feefe266d1c6254cbf5e3ead1b967932279ef80c5fb21b82fd2c0703c14a9b90")
addappid(4232,0,"63cc0f64dd4ccd79c4cb0495d057ba5dc36e95cadc3640d7758dff52051c1a7e")
