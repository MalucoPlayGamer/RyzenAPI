-- Lua provided by RyzenAPI
-- Game: RedEx

-- MAIN APPLICATION
addappid(1460250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460251, 1, "d5f314a694471c60bc110793e8e6dc3436fd80b5acad66c94fc27e07638c48f4")
