-- Lua provided by RyzenAPI
-- Game: Game: AppID 867530

-- MAIN APPLICATION
addappid(867530)
-- Game: addappid(867530)

-- MAIN APP DEPOTS / PACKAGES
addappid(867531, 1, "02ded51a99c38761e422d1093542563d4075a69665fc90fb663aca7b64e5e587")
