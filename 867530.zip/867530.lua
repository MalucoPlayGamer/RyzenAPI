-- Lua provided by RyzenAPI
-- Game: AppID 867530

-- MAIN APPLICATION
addappid(867530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(867531, 1, "02ded51a99c38761e422d1093542563d4075a69665fc90fb663aca7b64e5e587")

