-- Lua provided by RyzenAPI
-- Game: Game: The Settlers: New Allies

-- MAIN APPLICATION
addappid(2750080)
-- Game: addappid(2750080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2750081, 1, "33ee22467ac12ac1254685a95378f2f831405511a55fff1054a6b8e0bfb0165e")
