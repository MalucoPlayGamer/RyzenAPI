-- Lua provided by RyzenAPI
-- Game: The Settlers: New Allies

-- MAIN APPLICATION
addappid(2750080)
addappid(2880540)
addappid(2880550)
addappid(2880560)
addappid(2880570)
addappid(2880590)
addappid(2888500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
addappid(2750081,0,"33ee22467ac12ac1254685a95378f2f831405511a55fff1054a6b8e0bfb0165e")

