-- Lua provided by RyzenAPI
-- Game: addappid(1888430)

-- MAIN APPLICATION
addappid(1888430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888431, 1, "8d7609baf4c238852328ea092a5d7dec183c735f853c007ffe567b46ce45c7b8")
