-- Lua provided by SkyAPI 
-- Game: 10 Minutes Till Dawn
addappid(1888430)
addappid(1888431, 1, "8d7609baf4c238852328ea092a5d7dec183c735f853c007ffe567b46ce45c7b8")
