-- Lua provided by RyzenAPI
-- Game: Realpolitiks 3: Earth and Beyond

-- MAIN APPLICATION
addappid(2298690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298691, 1, "f0159ee367af9d4cb58b76b6ab2a9c0851f390e5808445054bdaaac507c7b13a")
addappid(2298692, 1, "e1e82ee5481299a0b1db7ad4c379798020669a521f5a1d2a3c288387eb031765")
