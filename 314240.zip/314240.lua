-- Lua provided by RyzenAPI
-- Game: RPG Tycoon

-- MAIN APPLICATION
addappid(314240)
addappid(551250)
addappid(570920)

-- MAIN APP DEPOTS / PACKAGES
addappid(314241, 1, "5e795f08b570543d81ab5c33b2cec53917ca853b281084808accc6c3db223cc2")

