-- Lua provided by SkyAPI 
-- Game: Fishing Together
addappid(1414280)
addappid(1414281, 1, "c17cf596f1c166165d62b8a41010dffef33fc241c928e6498b3cef7b9d3e36b9")
