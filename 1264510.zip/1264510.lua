-- Lua provided by RyzenAPI
-- Game: AppID 1264510

-- MAIN APPLICATION
addappid(1264510)
-- Game: addappid(1264510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264511, 1, "b7ee6df9190e3e28f358ad2b1d79ae39bb1a6fde3a479703e3cfea4a27db800f")
