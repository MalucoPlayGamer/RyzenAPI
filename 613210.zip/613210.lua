-- Lua provided by RyzenAPI
-- Game: Game: AppID 613210

-- MAIN APPLICATION
addappid(613210)
-- Game: addappid(613210)

-- MAIN APP DEPOTS / PACKAGES
addappid(613211, 1, "f01aa70ea3b005ed007cbff2080779cf0ed66cc0376f6b03f7354209697376ed")
