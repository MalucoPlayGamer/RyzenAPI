-- Lua provided by RyzenAPI
-- Game: addappid(1594400)

-- MAIN APPLICATION
addappid(1594400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594401, 1, "33f19bc4a58efe9c4b01fb6b517d985ec7a80b1a05df381618c7928f75ec1bb3")
