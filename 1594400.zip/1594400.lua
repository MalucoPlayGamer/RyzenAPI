-- Lua provided by RyzenAPI
-- Game: GAI Stops Auto: Right Version Simulator

-- MAIN APPLICATION
addappid(1594400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1594401, 1, "33f19bc4a58efe9c4b01fb6b517d985ec7a80b1a05df381618c7928f75ec1bb3")

