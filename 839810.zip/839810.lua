-- Lua provided by RyzenAPI 
-- Game: AppID 839810
addappid(839810)
addappid(839811, 1, "0cb4936f26898efe4926692bd3aaf79c90cdbfa8ff06ccf37d4984e8dadf5d36")
