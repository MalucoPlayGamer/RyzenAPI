-- Lua provided by RyzenAPI
-- Game: Pak Sung Bo Wing Chun

-- MAIN APPLICATION
addappid(1672420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1672421, 1, "d0b827b52a278744d5cc66f7c7176dfc858de4f24333daba37f54d49e6dbf12c")

