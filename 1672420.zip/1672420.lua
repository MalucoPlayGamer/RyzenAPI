-- Lua provided by RyzenAPI
-- Game: Pak Sung Bo Wing Chun

-- MAIN APPLICATION
addappid(1672420)
-- Game: addappid(1672420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672421, 1, "d0b827b52a278744d5cc66f7c7176dfc858de4f24333daba37f54d49e6dbf12c")
