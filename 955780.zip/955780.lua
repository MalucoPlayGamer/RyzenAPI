-- Lua provided by RyzenAPI
-- Game: Enderal: The Bard Songs

-- MAIN APPLICATION
addappid(955780)

-- MAIN APP DEPOTS / PACKAGES
addappid(955780,0,"913fe6992946a9bd4f32098ec71a30f01d4f6c5074b5c98cfc6d1ef6227d10ea")
