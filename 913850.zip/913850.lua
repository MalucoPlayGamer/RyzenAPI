-- Lua provided by RyzenAPI
-- Game: 103

-- MAIN APPLICATION
addappid(913850)

-- MAIN APP DEPOTS / PACKAGES
addappid(913852,0,"38ba80a94b9320f2553c056da479d7a19eb490c49945b031db5503744d071886")
addappid(1003570,0,"d2a024f3a6691f5e63d231b48c3eb9f5d8b6b4913a62daf290f66e75600c321c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
