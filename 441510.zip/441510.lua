-- Lua provided by RyzenAPI
-- Game: The Incredible Baron

-- MAIN APPLICATION
addappid(441510)
addappid(472750)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(441511, 1, "6a7fa88431f56d8ecd80365039d02af68187c005164479a9c2469c9a4ac88ab4")

