-- Lua provided by RyzenAPI
-- Game: 454130

-- MAIN APPLICATION
addappid(454130)
-- Game: addappid(454130)

-- MAIN APP DEPOTS / PACKAGES
addappid(454131, 1, "ed4bb6fa50a7c9a6d4a2503f4bdc86e5f8858a396b5ed9f363a21d5f079f722a")
