-- Lua provided by RyzenAPI
-- Game: Mangavania

-- MAIN APPLICATION
addappid(423910)
-- Game: addappid(423910)

-- MAIN APP DEPOTS / PACKAGES
addappid(423911, 1, "be49415995298419e859b7b4cb0ec46ecd05587424a76f9272ce390818ac8136")
