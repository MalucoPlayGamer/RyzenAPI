-- Lua provided by RyzenAPI
-- Game: addappid(1634910)

-- MAIN APPLICATION
addappid(1634910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634911, 1, "26136ec5ba5cb3c26716bbf25fbe617c8a4da66305ff80975a3cdbcc1eeb6fff")
