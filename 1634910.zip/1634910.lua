-- Lua provided by SkyAPI 
-- Game: Hundred Days (Original Game Soundtrack)
addappid(1634910)
addappid(1634911, 1, "26136ec5ba5cb3c26716bbf25fbe617c8a4da66305ff80975a3cdbcc1eeb6fff")
