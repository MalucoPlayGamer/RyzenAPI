-- Lua provided by RyzenAPI
-- Game: addappid(2586330)

-- MAIN APPLICATION
addappid(2586330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586331, 1, "521e9b9e0de92e78ae7391cb07dc5a08c56827380d7d271ba2b0fc6e4356209c")
