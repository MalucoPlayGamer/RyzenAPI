-- Lua provided by RyzenAPI
-- Game: Game: Horror Adventure Demo

-- MAIN APPLICATION
addappid(2292620)
-- Game: addappid(2292620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292621, 1, "62288478672ee0ebfa41809200d605e96b89409cdd872b58ffc02f8cda566596")
