-- Lua provided by RyzenAPI
-- Game: 3742560

-- MAIN APPLICATION
addappid(3742560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742560,0,"45c8a5bede1b8762b28cda906eceeee7af30a25c314af41e15aced3e2b845fb7")

