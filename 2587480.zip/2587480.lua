-- Lua provided by SkyAPI 
-- Game: Karting Superstars Demo
addappid(2587480)
addappid(2587481, 1, "28eea2be7e1c5aca4f959664cf6ac1ec26323e69f0054a0b0bf376eb57fd1924")
