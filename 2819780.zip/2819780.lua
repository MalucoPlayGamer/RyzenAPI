-- Lua provided by RyzenAPI
-- Game: 2819780

-- MAIN APPLICATION
addappid(2819780)
-- Game: addappid(2819780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819781, 1, "e00208e11045baba528fc89bd2117a9333375968ffaa6ecc9ec702720bfbbafb")
