-- Lua provided by RyzenAPI
-- Game: 镜花饴情 Mirage Sugar Acacia Demo

-- MAIN APPLICATION
addappid(2404120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404121, 1, "48fec905a977a7a6a356dd7431b97d1c1702b603f6c2a6fd76eb2f186b66ecd7")

