-- Lua provided by RyzenAPI
-- Game: Happy's Humble Burger Farm

-- MAIN APPLICATION
addappid(1433340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433341, 1, "cad7090cb7ab309ef67a6c60ff49477081f6358673c81715fd1d452507530672")
addappid(1816590, 0, "a3b62744ced0ff8597d66b701fca9ff7828601035e72c48a138c1d84097a90b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
