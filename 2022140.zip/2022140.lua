-- Lua provided by RyzenAPI
-- Game: 2022140

-- MAIN APPLICATION
addappid(2022140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022142,0,"5f40b4e453af7faf37590ffe5eff64328b3424ff7aecac2237a5e3acaff70d15")

