-- Lua provided by RyzenAPI
-- Game: AppID 622820

-- MAIN APPLICATION
addappid(622820)
-- Game: addappid(622820)

-- MAIN APP DEPOTS / PACKAGES
addappid(622821, 1, "5bc05d047103df1fcfe80d725f195af8aa741566bc431785a7b06fb744350d78")
