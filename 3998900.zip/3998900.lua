-- 3998900's Lua and Manifest Created by Hubcap Manifest
-- Claws Of Power
-- Created: August 21, 2026 at 22:55:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3998900) -- Claws Of Power
-- MAIN APP DEPOTS
addappid(3998901, 1, "df9a2c3d6593e32d64c9857c0e9d7ad3fd1a9f539a4bacdfbc70adb9db5bcb0f") -- Depot 3998901
setManifestid(3998901, "2894644242895869661", 527328511)