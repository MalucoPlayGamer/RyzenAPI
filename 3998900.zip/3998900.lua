-- Lua provided by RyzenAPI
-- Game: Claws Of Power

-- MAIN APPLICATION
addappid(3998900) -- Claws Of Power

-- MAIN APP DEPOTS / PACKAGES
addappid(3998901, 1, "df9a2c3d6593e32d64c9857c0e9d7ad3fd1a9f539a4bacdfbc70adb9db5bcb0f") -- Depot 3998901

