-- Lua provided by RyzenAPI
-- Game: Kawaii Girl2 AddPatch

-- MAIN APPLICATION
addappid(1366600)
-- Game: addappid(1366600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366600,0,"d5d11121360fb28614447649daf54d124239145ef6ea98b3e63e2e4aec688e4e")
