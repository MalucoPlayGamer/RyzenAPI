-- Lua provided by RyzenAPI
-- Game: addappid(2003310)

-- MAIN APPLICATION
addappid(2003310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003311, 1, "69e82e00ee23520adfa5d04ff1541ea60d9bcf22c86f7eab58ff8cfbb7233e4e")
