-- Lua provided by RyzenAPI
-- Game: Game: Unrailed!

-- MAIN APPLICATION
addappid(1016920)
-- Game: addappid(1016920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016921, 1, "b82ffaa19bdd8d11584b97453a59514dff8b19275df764530fe0b4ff903d307e")
addappid(1016922, 1, "177bb2c5aca577c8ed6613d81bd29757f03258799dd18fb4297fc00d49804d01")
addappid(1016923, 1, "4135b3d9d81843c6672277bd25d0e0a80d50f333f93ed5f508970ff02b9de4c7")
addappid(1150940, 0, "d7ead7d64b81dfa09d9e5dfab17ff7688f3cb0d9e5a2d0d7ec4ee733f44fd86b")
