-- Lua provided by RyzenAPI
-- Game: Unrailed!

-- MAIN APPLICATION
addappid(1016920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016921, 1, "b82ffaa19bdd8d11584b97453a59514dff8b19275df764530fe0b4ff903d307e")
addappid(1016922, 1, "177bb2c5aca577c8ed6613d81bd29757f03258799dd18fb4297fc00d49804d01")
addappid(1016923, 1, "4135b3d9d81843c6672277bd25d0e0a80d50f333f93ed5f508970ff02b9de4c7")
addappid(1150940, 0, "d7ead7d64b81dfa09d9e5dfab17ff7688f3cb0d9e5a2d0d7ec4ee733f44fd86b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
