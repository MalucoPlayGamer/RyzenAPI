-- Lua provided by RyzenAPI
-- Game: Dreamy Planet

-- MAIN APPLICATION
addappid(1792890)
addappid(2087870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792891, 1, "f137824f08158f6e0559d5cb0408cb16d61283c2cc211c49914bbcd5e2e60d7e")
