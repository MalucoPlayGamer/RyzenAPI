-- Lua provided by RyzenAPI
-- Game: AppID 1315020

-- MAIN APPLICATION
addappid(1315020)
-- Game: addappid(1315020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315021, 1, "54bcfca11d3a69b6025f807194172853b69b39683b3bad66e5eeb85a16093b09")
