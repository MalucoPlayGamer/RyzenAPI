-- Lua provided by SkyAPI 
-- Game: AppID 1315020
addappid(1315020)
addappid(1315021, 1, "54bcfca11d3a69b6025f807194172853b69b39683b3bad66e5eeb85a16093b09")
