-- Lua provided by RyzenAPI
-- Game: Game: BAWs Pharmacy

-- MAIN APPLICATION
addappid(1931960)
-- Game: addappid(1931960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931961, 1, "e4b5cddcffb2576d24daf9425f1b970f489ebf612450cd0a09d56b35b93a81e6")
