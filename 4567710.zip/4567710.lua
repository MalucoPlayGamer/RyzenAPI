-- Lua provided by RyzenAPI
-- Game: Template!! An Angel's Gift

-- MAIN APPLICATION
addappid(4567710)

-- MAIN APP DEPOTS / PACKAGES
addappid(4567711,0,"e18b0757a442891ddc0ac9d844625ffd048b2f484163cefdfbfc5db6559846a1")

