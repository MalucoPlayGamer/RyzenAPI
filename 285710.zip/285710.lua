-- Lua provided by RyzenAPI
-- Game: 285710

-- MAIN APPLICATION
addappid(285710)
-- Game: addappid(285710)

-- MAIN APP DEPOTS / PACKAGES
addappid(285711, 1, "21d5bae28cba50f32883ba38676e08920aed4bfd3e3bddb90053ad1f71e1a3d6")
