-- Lua provided by RyzenAPI
-- Game: Game: AppID 938340

-- MAIN APPLICATION
addappid(938340)
-- Game: addappid(938340)

-- MAIN APP DEPOTS / PACKAGES
addappid(938341, 1, "37689a38279d5c1b822d30e6803fdf6475d793d42ef1265b382487d7470aa072")
