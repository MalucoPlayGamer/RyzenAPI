-- Lua provided by RyzenAPI
-- Game: Detective Noir

-- MAIN APPLICATION
addappid(586480)

-- MAIN APP DEPOTS / PACKAGES
addappid(586481, 1, "129033f0012ef4a1e68d49dd637dfd558993571e14846326faf051fae87a4464")

