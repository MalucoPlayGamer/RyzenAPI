-- Lua provided by RyzenAPI 
-- Game: Drevepsina Demo
addappid(2496170)
addappid(2496171, 1, "b2318d7be2b51bde7c301026d7fddde3b2f88e8644cabdfacaf3d7a018a47e9f")
