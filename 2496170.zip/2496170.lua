-- Lua provided by RyzenAPI
-- Game: 2496170

-- MAIN APPLICATION
addappid(2496170)
-- Game: addappid(2496170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496171, 1, "b2318d7be2b51bde7c301026d7fddde3b2f88e8644cabdfacaf3d7a018a47e9f")
