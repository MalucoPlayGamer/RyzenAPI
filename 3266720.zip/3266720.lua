-- Lua provided by RyzenAPI 
-- Game: AppID 3266720
addappid(3266720)
addappid(3266721, 1, "18f156bc5136ae6b70e4b052c867cf7b258555e6773abae0c15de6d6c97c57c8")
