-- Lua provided by RyzenAPI
-- Game: SILENT SCREAM Demo

-- MAIN APPLICATION
addappid(2300010)
-- Game: addappid(2300010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300011, 1, "e58566d9fc3a8b8b075f32a077bf959ad12e46d7faf581534826c02eb91513e9")
