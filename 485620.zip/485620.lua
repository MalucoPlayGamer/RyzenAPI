-- Lua provided by RyzenAPI
-- Game: Pick a Hero

-- MAIN APPLICATION
addappid(485620)

-- MAIN APP DEPOTS / PACKAGES
addappid(485621, 1, "0587b06682893a10ed257bf4410c02c2923ed5ba1b024efdcb107330b919ac4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
