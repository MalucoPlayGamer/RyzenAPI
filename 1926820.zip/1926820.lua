-- Lua provided by RyzenAPI
-- Game: Game: BURNER

-- MAIN APPLICATION
addappid(1926820)
-- Game: addappid(1926820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926821, 1, "6962ce183bea930d636c02daf9ccd8bbb43e11c11a96c8d88adea23f6a87ff35")
