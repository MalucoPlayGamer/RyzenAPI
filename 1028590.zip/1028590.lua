-- Lua provided by RyzenAPI
-- Game: The WILDS

-- MAIN APPLICATION
addappid(1028590)
-- Game: addappid(1028590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028592,0,"179ac1f410c6aff6e738b4a57518f167a4e35e365161ca0f53d3f5e4fea579ac")
