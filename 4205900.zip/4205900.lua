-- 4205900's Lua and Manifest Created by Hubcap Manifest
-- Mining Wizards
-- Created: April 23, 2026 at 11:14:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4205900) -- Mining Wizards
-- MAIN APP DEPOTS
addappid(4205901, 1, "88338ad872a6e770c8b09e22330e4dc58fe9a7fa0cf93ff4a64354c8aade77e7") -- Depot 4205901
--setManifestid(4205901, "1074599283105218526", 514373919)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4481690) -- Mining Wizards - Supporter Pack