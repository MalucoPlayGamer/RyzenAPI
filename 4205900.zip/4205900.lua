-- Lua provided by RyzenAPI
-- Game: Mining Wizards

-- MAIN APPLICATION
addappid(4205900) -- Mining Wizards
addappid(4481690) -- Mining Wizards - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4205901, 1, "88338ad872a6e770c8b09e22330e4dc58fe9a7fa0cf93ff4a64354c8aade77e7") -- Depot 4205901

