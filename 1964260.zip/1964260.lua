-- Lua provided by RyzenAPI
-- Game: Void Prison

-- MAIN APPLICATION
addappid(1964260)
-- Game: addappid(1964260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964261, 1, "ae2c9a0fffd7cfd77ba161704268882e42cd9a3e29570c6b0db4d42177fe9edc")
