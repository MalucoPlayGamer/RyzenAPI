-- Lua provided by RyzenAPI
-- Game: 100 Waiting Cats

-- MAIN APPLICATION
addappid(3037060)

