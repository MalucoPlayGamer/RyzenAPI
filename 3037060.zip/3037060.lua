-- Lua provided by RyzenAPI
-- Game: 100 Waiting Cats

-- MAIN APPLICATION
addappid(3037060)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3247670)
addappid(3247680)
