-- Lua provided by RyzenAPI 
-- Game: It's On The Mouse
addappid(3075020)
addappid(3075021, 1, "d5ccfeadf2f47e081bdc4ec462628b05e905df00ec3ce4599d3f9cd92361b228")
