-- Lua provided by RyzenAPI
-- Game: AppID 535690

-- MAIN APPLICATION
addappid(535690)
-- Game: addappid(535690)

-- MAIN APP DEPOTS / PACKAGES
addappid(535691, 1, "8aba51d1155f1f4cdb6a0ae8355ad969eacf3a1fdcd420559491d4030a411cd8")
