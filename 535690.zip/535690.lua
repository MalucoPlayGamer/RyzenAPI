-- Lua provided by RyzenAPI
-- Game: AppID 535690

-- MAIN APPLICATION
addappid(535690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(535691, 1, "8aba51d1155f1f4cdb6a0ae8355ad969eacf3a1fdcd420559491d4030a411cd8")

