-- Lua provided by RyzenAPI
-- Game: Feudal Alloy

-- MAIN APPLICATION
addappid(699670)

-- MAIN APP DEPOTS / PACKAGES
addappid(699671, 1, "186b63dd9d4c98287ef8f979960e03a7d020d142b1d3c1f32fbcb806a3c65150")

