-- Lua provided by RyzenAPI
-- Game: 1504500

-- MAIN APPLICATION
addappid(1504500)
-- Game: addappid(1504500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504502,0,"0d0c0a89bb46ed460d2650f8f635aaf23fea36da557de02808be1fb29538ce30")
addappid(1504503,0,"effb492a43e6abf2b1fbde49540b75d21e0fce0b2a969d05f014b2894ce1f0a1")
addappid(1504504,0,"f8aa1081ea1f0ab09a6e37cded18a16a3421f58ba7e0857781ff200504a5bd8e")
