-- Lua provided by RyzenAPI
-- Game: Dead on Arrival: Remastered

-- MAIN APPLICATION
addappid(2180070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180071, 1, "167baace95d240bd5bc54231f538dba0efae380b95ee5b48a3b71f370084de26")

