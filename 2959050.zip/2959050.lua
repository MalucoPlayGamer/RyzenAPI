-- Lua provided by RyzenAPI
-- Game: addappid(2959050)

-- MAIN APPLICATION
addappid(2959050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959051, 1, "49befae0e3fef862033f14d374facf1d1a03c13ed9e78110edf62b01959e5f88")
