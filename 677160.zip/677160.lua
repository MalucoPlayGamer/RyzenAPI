-- Lua provided by RyzenAPI
-- Game: We Were Here Too

-- MAIN APPLICATION
addappid(677160)
-- Game: addappid(677160)

-- MAIN APP DEPOTS / PACKAGES
addappid(677162,0,"71b03145c5882cf28254bedd49a80ea8ac9688be3db9fe85eb29357636d3ed09")
addappid(677169,0,"515a3fefd8c4340919e33bf3f6faa71513c0a81d841a1212a650d5c578d4dcc9")
addappid(712130,0,"8a3953ad7804200df5c2a275f5d2732e182dc44c117b7a39661fc582cf5f3d79")
