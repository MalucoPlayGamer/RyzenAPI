-- Lua provided by RyzenAPI
-- Game: Sea of Craft

-- MAIN APPLICATION
addappid(990920)
-- Game: addappid(990920)

-- MAIN APP DEPOTS / PACKAGES
addappid(990921, 1, "01a96f6c25cb5e7efdc4f8c90f5599ca8a3bc37de213a04c58acb61d3a53b38d")
addappid(990922, 1, "b3f931b60193b11c9d1c21c6016fc249636f26a8fe45a63e6a91ef949411c20e")
addappid(990923, 1, "3a5cd0eadd08d8b901b499efc922c37086068fa9e0018895e47032342b9b49d2")
addappid(990924, 1, "cce23316a2289c724b662a3f6c0bb38ba693c3afd7c4567888bc768eaec09791")
