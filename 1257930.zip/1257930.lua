-- Lua provided by RyzenAPI
-- Game: Game: AppID 1257930

-- MAIN APPLICATION
addappid(1257930)
-- Game: addappid(1257930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257931, 1, "62b7732a51355ae5eae4e0678a281515e244d4a8105a4016baa5e8b8d891768e")
