-- Lua provided by RyzenAPI
-- Game: Leaflet Love Story

-- MAIN APPLICATION
addappid(895220)

-- MAIN APP DEPOTS / PACKAGES
addappid(895221, 1, "66506592571f0b75191438cb8371b7d87985d8799cbfb9e3fc26fbe8cc41b7b6")

