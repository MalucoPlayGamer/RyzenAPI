-- Lua provided by RyzenAPI
-- Game: 341680

-- MAIN APPLICATION
addappid(341680)
-- Game: addappid(341680)

-- MAIN APP DEPOTS / PACKAGES
addappid(341681, 1, "8fd2534e6b12d856f99f3d7546733a64ceee3bf43a4ad138a98cfd2f7ffbab1c")
addappid(341682, 1, "37067d675221e9ccf4f6e68d57a9f17585289113f7bf9a29f410edd09cc3e4d2")
