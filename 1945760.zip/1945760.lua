-- Lua provided by RyzenAPI
-- Game: Cyphers Game

-- MAIN APPLICATION
addappid(1945760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945761, 1, "b70e2d9e6e13b67be044622353caca364225513d32c68239f5541e3ccfb5a1f3")
