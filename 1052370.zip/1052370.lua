-- Lua provided by RyzenAPI 
-- Game: AppID 1052370
addappid(1052370)
addappid(1052371, 1, "13eab30f9d4ca24abd9d33999dbd60bffc2e2ffe35fbc30906106bf7a0ffe85d")
addappid(1052372, 1, "213f9c1ecc311beb2ea569f183c91689baa2132f407a8327a40f54d8738ad42a")
