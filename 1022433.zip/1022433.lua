-- Lua provided by RyzenAPI
-- Game: DFF NT: Magician's Deck, Ace's 4th Weapon

-- MAIN APPLICATION
addappid(1022433)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022433,0,"d983b4934b4a06925e700bc931c05f3f597a71c7318ac5ad6823ee158f1a6e8e")

