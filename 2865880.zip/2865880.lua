-- Lua provided by RyzenAPI
-- Game: Touhou: Fading Illusion - Destitute Chapter

-- MAIN APPLICATION
addappid(2865880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865880,0,"ee2ec003bc153e02ba82d2ab3f03e1699214f353588f526843428f755502ad1d")

