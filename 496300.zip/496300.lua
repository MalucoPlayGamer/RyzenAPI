-- Lua provided by RyzenAPI
-- Game: Kingdom: New Lands

-- MAIN APPLICATION
addappid(496300)
addappid(509430)
addappid(760200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(496301, 1, "572df00b3e10f4316ee29f1b11a3ac01192e3cd6a58b7332781d8b1101bf89e3")
addappid(496302, 1, "f2621e84c01368238de1e1102e9844200b83e05d339922a8faf0296f3eab78ed")
addappid(496303, 1, "12d1c69afb29f10f0cfaf288aff41316201ef70c49c7e12fee68bde51313bfc1")
addappid(496304, 1, "e94bcc30f1a422d071d1a459fdcd286a61bc675a2ddf23412ae7d6ad3b223d24")

