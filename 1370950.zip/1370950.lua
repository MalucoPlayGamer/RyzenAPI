-- Lua provided by RyzenAPI
-- Game: addappid(1370950)

-- MAIN APPLICATION
addappid(1370950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370951, 1, "adf434fcf4bd9b3103c914248d7dfad982fe123f05d600e2977bd4363bca39a1")
