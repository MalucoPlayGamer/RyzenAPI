-- Lua provided by SkyAPI 
-- Game: TactiCats Demo
addappid(2000080)
addappid(2000081, 1, "a7fdf5fd41cd5cd5b1b0ef5aeae51217c7f09313742bf8d458e0517697f750cb")
