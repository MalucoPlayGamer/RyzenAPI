-- Lua provided by RyzenAPI 
-- Game: Soul Axiom
addappid(279900)
addappid(279901, 1, "b61b850f61e94f69e6a1e11b60ff2522c20a210c3304ecbea3630aed66899724")
addappid(279902, 1, "05fdb876c2984bb24c4789bfc66404dfa605c00c40c3c976b478540d957a38cf")
addappid(279903, 1, "10d04a9ee8bf6c8246317981492a9dc02111778ee8bc170b37f1c73f5bf22904")
addappid(435820)
addappid(439860)
