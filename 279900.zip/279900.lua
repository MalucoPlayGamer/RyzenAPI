-- Lua provided by RyzenAPI
-- Game: Soul Axiom

-- MAIN APPLICATION
addappid(279900)
addappid(435820)
addappid(439860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(279901, 1, "b61b850f61e94f69e6a1e11b60ff2522c20a210c3304ecbea3630aed66899724")
addappid(279902, 1, "05fdb876c2984bb24c4789bfc66404dfa605c00c40c3c976b478540d957a38cf")
addappid(279903, 1, "10d04a9ee8bf6c8246317981492a9dc02111778ee8bc170b37f1c73f5bf22904")

