-- Lua provided by RyzenAPI
-- Game: ZM Desktop Elf

-- MAIN APPLICATION
addappid(3003300)
-- Game: addappid(3003300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3003301, 1, "325e733ae4a99b056ba9313f067dd0c882e5dbed87974e0367e6446c2f876f24")
