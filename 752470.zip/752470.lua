-- Lua provided by RyzenAPI
-- Game: addappid(752470)

-- MAIN APPLICATION
addappid(752470)

-- MAIN APP DEPOTS / PACKAGES
addappid(752473,0,"d82d8139d856e529e6a7d15d35941eecb6f95dac52fe1142680a019102c2fef9")
addappid(903610,0,"b8e8bfb3acdbeae530c346e8ef0289552c8b428b186cdd3d6e20df16d0770b9c")
