-- Lua provided by RyzenAPI
-- Game: Game: AppID 16830

-- MAIN APPLICATION
addappid(16830)
addappid(228983)
addappid(229000)
-- Game: addappid(16830)

-- MAIN APP DEPOTS / PACKAGES
addappid(16831, 1, "523c98385cff00b622194586039740dac4a2a0e5bf00d2def79da1e19a823f58")
