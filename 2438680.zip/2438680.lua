-- Lua provided by RyzenAPI
-- Game: Airborne Empire

-- MAIN APPLICATION
addappid(2438680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438681, 1, "b7a82611f534e7ff628612421bf94d88ea2921ab8ccc5a9f27943b17e85c3092")
