-- Lua provided by RyzenAPI
-- Game: Game: You Draw, I Guess Demo

-- MAIN APPLICATION
addappid(2732300)
-- Game: addappid(2732300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732301, 1, "437155d28c6435e041260c5f767a8de5b960d49f12a152e33d2194c065fbacfd")
