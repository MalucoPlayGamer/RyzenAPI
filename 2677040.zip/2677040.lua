-- Lua provided by RyzenAPI 
-- Game: AppID 2677040
addappid(2677040)
addappid(2677041, 1, "0a764d639a2cc63827d3e778928c0ebf6ebfb4280ac21e8ed27a4ab77b4758a2")
addappid(2677044, 1, "eb4a4f45344b6a87ae043928ee0a52fb49f01df2ebb8dc6ade9fa40baac2d988")
