-- Lua provided by RyzenAPI
-- Game: Game: Voxel Tank VR

-- MAIN APPLICATION
addappid(727800)
-- Game: addappid(727800)

-- MAIN APP DEPOTS / PACKAGES
addappid(727801, 1, "0a67b1956306dc855da8e253823ebf4fa8d6decaa6209a43c711349e48dc17c8")
addappid(727803, 1, "a4d3230b8f3b5dc790cea431d9a20715f6dc698296746286800b19f360b09bb8")
