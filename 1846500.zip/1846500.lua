-- Lua provided by RyzenAPI
-- Game: Game: AppID 1846500

-- MAIN APPLICATION
addappid(1846500)
-- Game: addappid(1846500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846501, 1, "cc0d59159a8e5de73039708500c20dab1eb5bcd4e2b92c335eb699c87a801f08")
