-- Lua provided by RyzenAPI
-- Game: 3028120

-- MAIN APPLICATION
addappid(3028120)
-- Game: addappid(3028120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028121, 1, "0e548b9af8c5162a7fd4bea863fdadce84cbf1ad9d1be18c73e83b9b6dc682f6")
