-- Lua provided by RyzenAPI
-- Game: Waifu Survivors

-- MAIN APPLICATION
addappid(3148510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148511, 1, "a2f8c70ab179e9061c05c4dcfdc8b28b67162838f78d27bc028e29df7c4721e9")

