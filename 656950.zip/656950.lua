-- Lua provided by RyzenAPI
-- Game: AppID 656950

-- MAIN APPLICATION
addappid(656950)

-- MAIN APP DEPOTS / PACKAGES
addappid(656951, 1, "e63ebf847c9b6bcbdf3973938a3e858c1f8b1a1a14dd77587e31af2c76bcb0bd")

