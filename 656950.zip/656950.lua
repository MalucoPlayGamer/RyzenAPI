-- Lua provided by SkyAPI 
-- Game: AppID 656950
addappid(656950)
addappid(656951, 1, "e63ebf847c9b6bcbdf3973938a3e858c1f8b1a1a14dd77587e31af2c76bcb0bd")
