-- Lua provided by RyzenAPI 
-- Game: The Space Bar
addappid(2253580)
addappid(2253581, 1, "1b40064a24b3525d825433321cc7ae4736213604595eb8386b95f2d19cd8c3d1")
addappid(2253582, 1, "8dd2bc7d668d11b5641e56cbda62f0e45bb61a685747529974ef5601f9346921")
