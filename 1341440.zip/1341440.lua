-- Lua provided by RyzenAPI
-- Game: World Process

-- MAIN APPLICATION
addappid(1341440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341441, 1, "fc5f5800132235f90acd377206d6e6385be3bfa772bbcad4b6caaad458f2504e")
