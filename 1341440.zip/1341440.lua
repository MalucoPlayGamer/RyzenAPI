-- Lua provided by SkyAPI 
-- Game: AppID 1341440
addappid(1341440)
addappid(1341441, 1, "fc5f5800132235f90acd377206d6e6385be3bfa772bbcad4b6caaad458f2504e")
