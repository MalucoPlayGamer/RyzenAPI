-- Lua provided by RyzenAPI
-- Game: 初恋日记

-- MAIN APPLICATION
addappid(1125480)
addappid(1288150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125480,0,"4e9d82c95fe9febf715435a4dc6918596a593f8406735cb5a4baa1cf02146cd9")
addappid(1125481,0,"2c7488ad1ba7f22850bbc0856295e838cdfe6a55718cdbe9257fd09bb9a96814")
addappid(1900771,0,"56ccd9bebe674e5cdd2e449a9a868d6509ae72eb1cb0a96bf057811fcaaf8ecd")

