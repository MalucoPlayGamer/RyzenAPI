-- Lua provided by RyzenAPI
-- Game: 1125480

-- MAIN APPLICATION
addappid(1125480)
-- Game: addappid(1125480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125481, 1, "2c7488ad1ba7f22850bbc0856295e838cdfe6a55718cdbe9257fd09bb9a96814")
