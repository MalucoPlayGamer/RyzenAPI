-- Lua provided by RyzenAPI
-- Game: 69 Iris Hot

-- MAIN APPLICATION
addappid(1844580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844581, 1, "d3880a2b03b58fdc3a7d44ef71b7ca8e6da0461beaa6c50665477ac2a009772a")
