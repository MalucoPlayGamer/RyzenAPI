-- Lua provided by RyzenAPI
-- Game: Game: Dr. Emmerson's Nocturnes Demo

-- MAIN APPLICATION
addappid(2643510)
-- Game: addappid(2643510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643511, 1, "00d39386960ffa7bbde00d26c772fa984a3dce967e6b1a8683c60110afe4cb2a")
