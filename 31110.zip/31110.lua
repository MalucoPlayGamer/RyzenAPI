-- Lua provided by RyzenAPI
-- Game: Wallace & Gromit’s Grand Adventures, Episode 2: The Last Resort

-- MAIN APPLICATION
addappid(31110)
-- Game: addappid(31110)

-- MAIN APP DEPOTS / PACKAGES
addappid(31112,0,"c74f2d99b3492c2fb96597889a7af91c08f0a95275297963a5050230ff7ecce4")
