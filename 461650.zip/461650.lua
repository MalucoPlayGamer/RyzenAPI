-- Lua provided by RyzenAPI
-- Game: It's Killing Time

-- MAIN APPLICATION
addappid(461650)

-- MAIN APP DEPOTS / PACKAGES
addappid(461651, 1, "8429fe3c9832f44e3d16c22a51eddf2b5d8362f17dfaf2b1e3806e01047129ab")

