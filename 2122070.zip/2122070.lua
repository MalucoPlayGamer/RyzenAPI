-- Lua provided by RyzenAPI
-- Game: 宝石少女/Girl & Gem Magic

-- MAIN APPLICATION
addappid(2122070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122071, 1, "9a6075550dc5cf06496548f825499764ddf6827b27f49c76a5666237fbf4e6c8")
addappid(2354950, 0, "0a700adbc47c98ec4e020d5dcf0559cbfe17ce20be0c88b701c366401f78168b")
