-- Lua provided by RyzenAPI
-- Game: AppID 527680

-- MAIN APPLICATION
addappid(527680)

-- MAIN APP DEPOTS / PACKAGES
addappid(527681, 1, "f612fecbe2f122fff2f6f29a1582df56ed3fbcacd6478f64f22b32b82a7c8cbc")
