-- Lua provided by RyzenAPI
-- Game: Game: AppID 367780

-- MAIN APPLICATION
addappid(367780)
-- Game: addappid(367780)

-- MAIN APP DEPOTS / PACKAGES
addappid(367781, 1, "0bb484efc1b6756fbbc991fecf2fe52025ccc9bb4fccd390648a43c05df17628")
