-- Lua provided by RyzenAPI
-- Game: 开局抽取超级天赋

-- MAIN APPLICATION
addappid(2687110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687111, 1, "420736d9c706e0045995ea8b3ee748ba0385a5ff8a3ccc505541968a5574a820")
