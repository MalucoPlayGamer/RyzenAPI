-- Lua provided by RyzenAPI
-- Game: Some Goodbyes We Made

-- MAIN APPLICATION
addappid(2705820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2705821, 1, "4cedb5ad34bb79e98de9f0c8193f5bcbd80e79b48ae923b615509e82fca48789")

