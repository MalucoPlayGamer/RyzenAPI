-- Lua provided by RyzenAPI
-- Game: addappid(3573780)

-- MAIN APPLICATION
addappid(3573780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3573781, 1, "213e812f64e6c7cffb62df6b4ceda5886aef3a8d3becee9be798a8009f4c6b94")
