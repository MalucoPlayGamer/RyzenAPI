-- Lua provided by RyzenAPI
-- Game: addappid(1420830)

-- MAIN APPLICATION
addappid(1420830)
addappid(1430490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420831, 1, "cecd0616a9c3965f32c369036ae5166e0364f711bafd53022a1f1ee91be5632e")
