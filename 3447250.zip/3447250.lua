-- Lua provided by RyzenAPI 
-- Game: AppID 3447250
addappid(3447250)
addappid(3447251, 1, "58538a1eca7669620022575d981357de467bdc55553168dc7541d0e48a9bb482")
