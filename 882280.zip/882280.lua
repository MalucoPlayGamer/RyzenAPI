-- Lua provided by RyzenAPI
-- Game: 882280

-- MAIN APPLICATION
addappid(882280)
-- Game: addappid(882280)

-- MAIN APP DEPOTS / PACKAGES
addappid(882281, 1, "04137c04738645e48316396cb723ce86bea76f3aa426ea33d3eac7bff43e97e9")
