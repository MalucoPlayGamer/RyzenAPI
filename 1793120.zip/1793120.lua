-- Lua provided by SkyAPI 
-- Game: Prototype Blocks
addappid(1793120)
addappid(1793121, 1, "02bb7feb692c9abfdf729181a28bdc52b82e5eba214c7c6c7553fd2897901219")
