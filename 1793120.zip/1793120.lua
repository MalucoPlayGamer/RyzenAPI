-- Lua provided by RyzenAPI
-- Game: 1793120

-- MAIN APPLICATION
addappid(1793120)
-- Game: addappid(1793120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793121, 1, "02bb7feb692c9abfdf729181a28bdc52b82e5eba214c7c6c7553fd2897901219")
