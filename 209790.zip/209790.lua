-- Lua provided by RyzenAPI
-- Game: 209790

-- MAIN APPLICATION
addappid(209790)
-- Game: addappid(209790)

-- MAIN APP DEPOTS / PACKAGES
addappid(209791, 1, "ac961f9a917e6c41915fb677634e2d1fd05d5070cb301a2a937a8b10e7754c6f")
addappid(209792, 1, "8590a12029e636828594742914e2ac45aa579ea3dab86561f0815844ffbdd4f5")
addappid(209793, 1, "845fb8cd20c2bdcb4c3281cd92a67fc5b7dfc3719ca781194d7fc58900f7fc9b")
addappid(209794, 1, "9a4bbf12f9c3e0ea8b2ae365edb6e5fc4d053f75afe85ebc432f9bb6615b72a3")
