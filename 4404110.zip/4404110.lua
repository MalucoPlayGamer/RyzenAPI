-- Lua provided by RyzenAPI
-- Game: Goblins Can Conquer

-- MAIN APPLICATION
addappid(4404110) -- Goblins Can Conquer

-- MAIN APP DEPOTS / PACKAGES
addappid(4404111, 1, "83870bf0da9658105c86f7b67e2356e3eeb11056f09515a0ad9aaeac00e8608a") -- Depot 4404111

