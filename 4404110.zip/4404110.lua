-- 4404110's Lua and Manifest Created by Hubcap Manifest
-- Goblins Can Conquer
-- Created: August 26, 2026 at 06:36:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4404110) -- Goblins Can Conquer
-- MAIN APP DEPOTS
addappid(4404111, 1, "83870bf0da9658105c86f7b67e2356e3eeb11056f09515a0ad9aaeac00e8608a") -- Depot 4404111
setManifestid(4404111, "653052453321560701", 126947632)