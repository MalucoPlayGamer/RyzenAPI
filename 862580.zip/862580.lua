-- Lua provided by RyzenAPI
-- Game: AppID 862580

-- MAIN APPLICATION
addappid(862580)
-- Game: addappid(862580)

-- MAIN APP DEPOTS / PACKAGES
addappid(862581, 1, "ac9e006cb1d826429eb24b652fd5c82bd0896b93a856e1fa849d77f9ede67f19")
