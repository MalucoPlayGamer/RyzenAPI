-- Lua provided by SkyAPI 
-- Game: AppID 862580
addappid(862580)
addappid(862581, 1, "ac9e006cb1d826429eb24b652fd5c82bd0896b93a856e1fa849d77f9ede67f19")
