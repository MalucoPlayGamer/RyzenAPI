-- Lua provided by RyzenAPI
-- Game: Rally Rock 'N Racing

-- MAIN APPLICATION
addappid(2492580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492581,0,"7747b2e39ce268020c9c755280972c47da505ccd5c69ee54c87e908f7bb7317e")

