-- Lua provided by RyzenAPI 
-- Game: AppID 2860120
addappid(2860120)
addappid(2860121, 1, "2afcb644d61c4786f4b52eb31c9048c872f214b4ffa58f4f55d939530798cd31")
