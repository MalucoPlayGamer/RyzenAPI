-- Lua provided by RyzenAPI
-- Game: 805590

-- MAIN APPLICATION
addappid(805590)

-- MAIN APP DEPOTS / PACKAGES
addappid(805592,0,"d0af4486f9d34107077006ceb7a6ed0958ccc0bf85f8a201f828ec2d8a1acfbe")
