-- Lua provided by RyzenAPI
-- Game: Agricola: All Creatures Big and Small

-- MAIN APPLICATION
addappid(528180)

-- MAIN APP DEPOTS / PACKAGES
addappid(528181, 1, "b912fbe1277ce96c9c599a477b67a7bf4c6b36ffc2110458177fae8d5066a52a")
