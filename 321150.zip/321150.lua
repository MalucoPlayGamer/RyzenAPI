-- Lua provided by RyzenAPI
-- Game: addappid(321150)

-- MAIN APPLICATION
addappid(321150)

-- MAIN APP DEPOTS / PACKAGES
addappid(321151, 1, "68d24729f247e1725c651e903372e5252efb1a09b93d3dde5f65587db2e3bf72")
addappid(321152, 1, "d79fd92a508634fb37652147ccac36e4df7ec981e8d8b9ac1ba6ec1ef4643e4d")
