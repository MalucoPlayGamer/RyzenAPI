-- Lua provided by RyzenAPI 
-- Game: AppID 656620
addappid(656620)
addappid(656621, 1, "c2843bad83b62134c1bcb1ddfda400a6a2b5b9fce16c22f303dad306524ce4a0")
