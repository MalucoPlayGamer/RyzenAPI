-- Lua provided by RyzenAPI
-- Game: Emberlight

-- MAIN APPLICATION
addappid(1434620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1434621, 1, "79013a9c562dd3ceefb88bf8e1d530a73b25c09b91a61e54108ba515c9e4bb93")
addappid(1434623, 1, "49d2d4fa536aef5bb1ee8b68ef6cb51fcf82433962a2f1be1b09cc7d9e93b5a1")

