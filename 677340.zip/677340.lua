-- Lua provided by RyzenAPI
-- Game: The Colonists

-- MAIN APPLICATION
addappid(677340)

-- MAIN APP DEPOTS / PACKAGES
addappid(677341, 1, "3d7728de928df3197a32149676017b26ef9e1222f52626fb2f19f3190a7e9433")
addappid(677342, 1, "022c14658f0ee9c4ecce20780d886a27b2089d9a2b79bcd859ab06e24d1c8f20")
addappid(677343, 1, "45aead0fab39f96815d947a73b585faf8a9b7f60f7cf3bfd9381eaf935c9ed0a")
