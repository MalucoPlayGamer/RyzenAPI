-- Lua provided by RyzenAPI
-- Game: Lovely Warriors

-- MAIN APPLICATION
addappid(1456020)
addappid(1495160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456021, 1, "fd7e69c50e7ba846200759fdcf7f8900e15425ed9169cf7c29eb751af2b4d855")

