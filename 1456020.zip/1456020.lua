-- Lua provided by SkyAPI 
-- Game: Lovely Warriors
addappid(1456020)
addappid(1456021, 1, "fd7e69c50e7ba846200759fdcf7f8900e15425ed9169cf7c29eb751af2b4d855")
