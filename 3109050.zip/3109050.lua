-- Lua provided by RyzenAPI
-- Game: Waifu

-- MAIN APPLICATION
addappid(3109050)
-- Game: addappid(3109050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3109051, 1, "ac8350cec66d95ce0f8925bc4eb8cc7d3a2921aac2a3d50edc87e1f40f11806d")
