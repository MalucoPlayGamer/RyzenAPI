-- Lua provided by RyzenAPI
-- Game: Game: OutRUN

-- MAIN APPLICATION
addappid(3187540)
-- Game: addappid(3187540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3187541, 1, "de8d57a084ff9dc9208bb2be11e1a2ec8e3c6f5b6e73e27b01bcab293c8ff485")
