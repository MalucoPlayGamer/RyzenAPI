-- Lua provided by RyzenAPI
-- Game: OutRUN

-- MAIN APPLICATION
addappid(3187540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3187541, 1, "de8d57a084ff9dc9208bb2be11e1a2ec8e3c6f5b6e73e27b01bcab293c8ff485")

