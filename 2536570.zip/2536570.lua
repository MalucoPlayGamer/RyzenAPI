-- Lua provided by RyzenAPI
-- Game: Mercenary Warriors

-- MAIN APPLICATION
addappid(2536570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2536571, 1, "d9de9ae39717c4007aacbb2dba63125c718ae42203e14945dda233cdd18ace13")

