-- Lua provided by RyzenAPI
-- Game: Game: Mercenary Warriors

-- MAIN APPLICATION
addappid(2536570)
-- Game: addappid(2536570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536571, 1, "d9de9ae39717c4007aacbb2dba63125c718ae42203e14945dda233cdd18ace13")
