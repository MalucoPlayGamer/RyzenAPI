-- Lua provided by RyzenAPI
-- Game: 3315830

-- MAIN APPLICATION
addappid(3315830)
-- Game: addappid(3315830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3315831, 1, "723aedcb0a4a5034e0eeea20027ffc3a139c653c7aa400944145786a9d1351eb")
