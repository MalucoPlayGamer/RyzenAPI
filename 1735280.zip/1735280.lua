-- Lua provided by RyzenAPI
-- Game: Game: AppID 1735280

-- MAIN APPLICATION
addappid(1735280)
-- Game: addappid(1735280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1735281, 1, "c071b6b5b9a0ce6108df718e611fb0b3af9e5d9947c64b1079b91efd74654e04")
