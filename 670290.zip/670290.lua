-- Lua provided by RyzenAPI
-- Game: 670290

-- MAIN APPLICATION
addappid(670290)
-- Game: addappid(670290)

-- MAIN APP DEPOTS / PACKAGES
addappid(670291, 1, "cea5f574f8a6ce997ff1867e597fd1100111f652244cbb77c8850e20decd9db6")
