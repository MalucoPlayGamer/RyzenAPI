-- Lua provided by RyzenAPI
-- Game: Tropical Fish Shop 2

-- MAIN APPLICATION
addappid(451350)

-- MAIN APP DEPOTS / PACKAGES
addappid(451351, 1, "eb541d118614fb65ae63e37dc35ca69659c87572f94f10a2cea13bf5b5c47f48")
