-- Lua provided by RyzenAPI
-- Game: The Pirate's Quest

-- MAIN APPLICATION
addappid(2946060)
-- Game: addappid(2946060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946061, 1, "b803bf8d1b31e12c8b6263ca8452595c9538c02146e020f074381481f1906c07")
