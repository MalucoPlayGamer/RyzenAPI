-- Lua provided by RyzenAPI
-- Game: Zero-G

-- MAIN APPLICATION
addappid(567890)

-- MAIN APP DEPOTS / PACKAGES
addappid(567891, 1, "19339b69fe2f93381ed54edd046dfd8ffc2cb3498de75440f173cc49136b4ea7")
addappid(567892, 1, "cb906e6c18e6efd7fbaae7774c705c60c407e973e841d2c7aa9a1a996b3a8245")

