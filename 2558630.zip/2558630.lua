-- Lua provided by RyzenAPI
-- Game: Resident Fear : Redistribution

-- MAIN APPLICATION
addappid(2558630)
-- Game: addappid(2558630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2558631, 1, "cbd46721e4e502561e895a3700058c6e66a9d0b5255774f648b58467991b7419")
