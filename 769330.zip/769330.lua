-- Lua provided by RyzenAPI
-- Game: AppID 769330

-- MAIN APPLICATION
addappid(769330)
-- Game: addappid(769330)

-- MAIN APP DEPOTS / PACKAGES
addappid(769331, 1, "8a13c90c05c5e6750f60274c518683b0d8d2d8c3b6eacb5352008cbfc73cf937")
