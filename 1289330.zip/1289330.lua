-- Lua provided by RyzenAPI
-- Game: Angry Bunny 3: Virus

-- MAIN APPLICATION
addappid(1289330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289331, 1, "ae4a3c69ce42f518bc7894a252006f371908eae2a76c2e468ecdfed96209c5ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
