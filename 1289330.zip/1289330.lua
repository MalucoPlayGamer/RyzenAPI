-- Lua provided by RyzenAPI
-- Game: Angry Bunny 3: Virus

-- MAIN APPLICATION
addappid(1289330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289331, 1, "ae4a3c69ce42f518bc7894a252006f371908eae2a76c2e468ecdfed96209c5ab")

