-- Lua provided by RyzenAPI
-- Game: Sword Art Online Re: Hollow Fragment

-- MAIN APPLICATION
addappid(638650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(638651, 1, "a9051a9a526c61c1d6d79a8672471b121f6e4e150be989de54ce15f285a84543")

