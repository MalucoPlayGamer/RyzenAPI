-- Lua provided by SkyAPI 
-- Game: AppID 638650
addappid(638650)
addappid(638651, 1, "a9051a9a526c61c1d6d79a8672471b121f6e4e150be989de54ce15f285a84543")
