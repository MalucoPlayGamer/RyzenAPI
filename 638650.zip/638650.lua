-- Lua provided by RyzenAPI
-- Game: addappid(638650)

-- MAIN APPLICATION
addappid(638650)

-- MAIN APP DEPOTS / PACKAGES
addappid(638651, 1, "a9051a9a526c61c1d6d79a8672471b121f6e4e150be989de54ce15f285a84543")
