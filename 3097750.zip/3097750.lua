-- Lua provided by RyzenAPI
-- Game: Game: My Lewd Adventure

-- MAIN APPLICATION
addappid(3097750)
-- Game: addappid(3097750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097751, 1, "b313bc6dd748a98b4f17e2608d847b65cf0b2e687f58ed9af70e5f3b6cd734f9")
