-- Lua provided by SkyAPI 
-- Game: My Lewd Adventure
addappid(3097750)
addappid(3097751, 1, "b313bc6dd748a98b4f17e2608d847b65cf0b2e687f58ed9af70e5f3b6cd734f9")
