-- Lua provided by RyzenAPI
-- Game: Abyss The Forgotten Past: Prologue

-- MAIN APPLICATION
addappid(1453140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453141, 1, "097da92c0a9e45476fc6dfb3c796a6f7a751ba2367c2e1154240cadb075ead72")
