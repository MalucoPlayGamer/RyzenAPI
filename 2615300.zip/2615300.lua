-- Lua provided by SkyAPI 
-- Game: Survival Guide 2
addappid(2615300)
addappid(2615301, 1, "72212c155a0c5551685a43937ed9cfb692e433fdf37c3b0f302a7d3dc876b507")
