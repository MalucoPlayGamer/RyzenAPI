-- Lua provided by RyzenAPI
-- Game: Survival Guide 2

-- MAIN APPLICATION
addappid(2615300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615301, 1, "72212c155a0c5551685a43937ed9cfb692e433fdf37c3b0f302a7d3dc876b507")

