-- Lua provided by RyzenAPI
-- Game: Cultist Simulator: The Lady Afterwards

-- MAIN APPLICATION
addappid(1813090)
-- Game: addappid(1813090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813090,0,"a9dade4a9e37f590a87383ecc3eaa6243fe7cb52b974f632c864bdac497fba7d")
