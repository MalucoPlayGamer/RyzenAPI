-- Lua provided by RyzenAPI
-- Game: The Unlikely Legend of Rusty Pup

-- MAIN APPLICATION
addappid(800690)

-- MAIN APP DEPOTS / PACKAGES
addappid(800692,0,"c82261458bae8d4c6392b64797b6fd5dd323b21e37c065f0bf8145aef09c8780")

