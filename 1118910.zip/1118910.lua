-- Lua provided by RyzenAPI
-- Game: Sunflower

-- MAIN APPLICATION
addappid(1118910)
addappid(1332480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118911, 1, "27b52f0a3bc021c64d47f95b5414b3d9fe03337d22827f6c887e52593c691b4b")
