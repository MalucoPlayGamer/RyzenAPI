-- Lua provided by RyzenAPI
-- Game: addappid(1939837)

-- MAIN APPLICATION
addappid(1939837)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939837,0,"5fa5560b1a97263c04ebd1030d5beddea578b89a0c05aaa0d4db09191287c448")
