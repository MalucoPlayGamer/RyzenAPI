-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1651180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651180,0,"f9e8c092c576efe4f932b5adf4c39d6bb0ac3266a53150126446241dced0cbef")
