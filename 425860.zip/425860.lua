-- Lua provided by RyzenAPI
-- Game: Game: AppID 425860

-- MAIN APPLICATION
addappid(425860)
-- Game: addappid(425860)

-- MAIN APP DEPOTS / PACKAGES
addappid(425861, 1, "eb52392827c99cec86a4e1809fec61d15f514899d812a349a2c29ab317129ed1")
