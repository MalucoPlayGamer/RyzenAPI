-- Lua provided by RyzenAPI
-- Game: Vector Assault

-- MAIN APPLICATION
addappid(425860)

-- MAIN APP DEPOTS / PACKAGES
addappid(425861, 1, "eb52392827c99cec86a4e1809fec61d15f514899d812a349a2c29ab317129ed1")
