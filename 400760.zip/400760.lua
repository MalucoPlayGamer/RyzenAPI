-- Lua provided by SkyAPI 
-- Game: AppID 400760
addappid(400760)
addappid(400761, 1, "67920fa280cac10bb301518db814a6bbffc327c5b726089d6a79bcea6412fa3d")
