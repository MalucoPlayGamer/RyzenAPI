-- Lua provided by RyzenAPI
-- Game: MetroLand

-- MAIN APPLICATION
addappid(3129590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3129591, 1, "b41fcd68a23699fecde2a4e77e07c15539a11a03e17a214eec818e501ed5a6b7")

