-- Lua provided by RyzenAPI
-- Game: 450360

-- MAIN APPLICATION
addappid(450360)
-- Game: addappid(450360)

-- MAIN APP DEPOTS / PACKAGES
addappid(450361, 1, "ebdb64ddf0db02191042963064cb93eb7744295cd7b8259e4e1fd3fcb76f918c")
