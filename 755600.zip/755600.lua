-- Lua provided by RyzenAPI
-- Game: Christmas Race

-- MAIN APPLICATION
addappid(755600)

-- MAIN APP DEPOTS / PACKAGES
addappid(755601, 1, "a633b4f3076204fd83c3ace0dae3c10cb77a5fd4da358380883c9a469b03857f")

