-- Lua provided by RyzenAPI
-- Game: A Kiss For The Petals - Remembering How We Met

-- MAIN APPLICATION
addappid(397270)

-- MAIN APP DEPOTS / PACKAGES
addappid(397271, 1, "5212cde5d0017ef26d0d2e9bec79efc6020232b1daedb2f1f3f84a9e9e335e1b")

