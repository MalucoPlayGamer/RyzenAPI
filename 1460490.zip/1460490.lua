-- Lua provided by RyzenAPI
-- Game: Majikoi! Love Me Seriously!

-- MAIN APPLICATION
addappid(1460490)
-- Game: addappid(1460490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460491, 1, "863a7edc7fee2b36a8d19ff42f6e464377d9c4f28c0bf9ccf8c8f8d7bfad58aa")
