-- Lua provided by RyzenAPI
-- Game: AppID 228880

-- MAIN APPLICATION
addappid(228880)
addappid(228984)
addappid(228990)
addappid(381650)
addappid(381651)
addappid(381652)
addappid(381653)
addappid(381654)
addappid(381655)
addappid(381656)
addappid(381657)
addappid(381658)
addappid(381659)
addappid(460461)
addappid(460462)
addappid(473390)
addappid(475450)
addappid(488010)
addappid(495360)
addappid(495361)
addappid(517730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228881, 1, "b9b0bf201628ddc31beec4252fd4b3780a24e5c5080350e26b46cca52acbf94f")
addappid(228884, 1, "91b8f66e90e499e2ab456ad793b7e8d57c5c123e2e710e0b5898446d3cc9cc02")
addappid(460460, 0, "8df051c6ae152cec77445a2572b4f1b9dd9c25c31d929d0bf8b54fcc4849d1d9")

