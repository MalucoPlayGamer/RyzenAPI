-- Lua provided by RyzenAPI
-- Game: addappid(1112670)

-- MAIN APPLICATION
addappid(1112670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112671, 1, "608db6e674ce3648bec79b83e3801ad99985c81db86567a3aa2777d992f6a701")
