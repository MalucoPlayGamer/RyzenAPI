-- Lua provided by RyzenAPI
-- Game: Game: AppID 1254870

-- MAIN APPLICATION
addappid(1254870)
-- Game: addappid(1254870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254871, 1, "801196818a8a927ca87d243cc88c0d8ef7133d5989f3bf11c5caee6541a02d1e")
