-- Lua provided by SkyAPI 
-- Game: AppID 1254870
addappid(1254870)
addappid(1254871, 1, "801196818a8a927ca87d243cc88c0d8ef7133d5989f3bf11c5caee6541a02d1e")
