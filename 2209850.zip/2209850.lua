-- Lua provided by SkyAPI 
-- Game: AppID 2209850
addappid(2209850)
addappid(2209851, 1, "f54cc9911f376027778da997cc5a55f88e69774908be323edded7bfe0e31eb48")
addappid(2209852, 1, "53e2f9648023eb1ec3613e7932fb2d4c1e25bee1eb604fe3277f96c08777a12d")
