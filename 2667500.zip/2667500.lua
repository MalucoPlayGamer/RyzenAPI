-- Lua provided by RyzenAPI
-- Game: World War Next

-- MAIN APPLICATION
addappid(2667500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667501, 1, "8f8a5d56f6e8d7a876f5ea56ef56c7947624bfeb450467d7b7ec665fcc67ef58")
