-- Lua provided by RyzenAPI
-- Game: AppID 663730

-- MAIN APPLICATION
addappid(663730)
-- Game: addappid(663730)

-- MAIN APP DEPOTS / PACKAGES
addappid(663731, 1, "611508e152bf71125fe74f2a655a7182e9d2b24ca9f3c319a2d89a99a0ea1b24")
