-- Lua provided by RyzenAPI
-- Game: Endless Knight

-- MAIN APPLICATION
addappid(1173870)
-- Game: addappid(1173870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173871, 1, "c99da69ed9ad51b0669fef4c6f080bc8a4710b06a4f3b17d2f5f64971fb1bddf")
