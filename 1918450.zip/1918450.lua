-- Lua provided by RyzenAPI
-- Game: HunterX

-- MAIN APPLICATION
addappid(1918450)
-- Game: addappid(1918450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918451, 1, "41811c0b06f134f240fc798eeaabba6391ee8ef9a3e5d0c221e4b2212ff1d84c")
