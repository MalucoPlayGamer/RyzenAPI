-- Lua provided by RyzenAPI
-- Game: addappid(2638800)

-- MAIN APPLICATION
addappid(2638800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638803,0,"a72eea4058159039975d59baf25f9aa762c497be2c9a99b82353ba14f0ed1572")
