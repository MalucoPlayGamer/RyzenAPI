-- Lua provided by RyzenAPI
-- Game: Achievement Hunter: Chef

-- MAIN APPLICATION
addappid(799740)

-- MAIN APP DEPOTS / PACKAGES
addappid(799741, 1, "88af9a7db7542a02153296bfe49e167517dca56fc210066f52e3a98c73ababb7")

