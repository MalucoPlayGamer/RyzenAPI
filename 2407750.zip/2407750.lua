-- Lua provided by RyzenAPI
-- Game: 2407750

-- MAIN APPLICATION
addappid(2407750)
-- Game: addappid(2407750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407751, 1, "a88c1edab0aa9bb4a8d36f5ca3da2e024346bec3fa8c346b20bdb6a28ac1eba6")
addappid(2407752, 1, "a75285453c6490b078fdc3b5ecaa0168940fe8a14a4391790ac7f0e4f04ec863")
