-- Lua provided by SkyAPI 
-- Game: AppID 514540
addappid(514540)
addappid(514541, 1, "ad4ce7527bd5f78ab92223ae6160220ff4f59bf1f46053e8adad56fd1dc26b14")
addappid(827320)
addappid(827340)
