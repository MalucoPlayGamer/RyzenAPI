-- Lua provided by RyzenAPI 
-- Game: Boxville Demo
addappid(1750730)
addappid(1750731, 1, "5048a4a2a60ea5ca79578c3490a59ec6146a7526221856067bf009bdb0d61194")
