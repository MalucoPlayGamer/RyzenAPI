-- Lua provided by RyzenAPI
-- Game: Gemini: Binary Conflict

-- MAIN APPLICATION
addappid(1293660)
addappid(2775360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1293661, 1, "5e56124065e030b3104e4b6b2173ff0b45a8dd47aecf46aab9b07bc269e86fdb")
addappid(1293662, 1, "0719d0adfe4e8c9c5208b57cb3bb31d97059dd99994ce38a4ccee77440771ccc")

