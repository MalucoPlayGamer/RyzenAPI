-- Lua provided by RyzenAPI
-- Game: The Black Within

-- MAIN APPLICATION
addappid(2372870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2372871, 1, "3ebf28c2c3ddc3a8f5ed278a7f29c392baed9762497e18ec2d8384d30c3a1ea3")

