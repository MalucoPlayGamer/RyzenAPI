-- Lua provided by RyzenAPI
-- Game: The Black Within

-- MAIN APPLICATION
addappid(2372870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372871, 1, "3ebf28c2c3ddc3a8f5ed278a7f29c392baed9762497e18ec2d8384d30c3a1ea3")

