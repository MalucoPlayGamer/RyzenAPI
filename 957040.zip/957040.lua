-- Lua provided by RyzenAPI
-- Game: HyperParasite Demo

-- MAIN APPLICATION
addappid(957040)

-- MAIN APP DEPOTS / PACKAGES
addappid(957042,0,"9cab61557d80e815ed296356c76a3f12db10013462ddc34320c98956f398e611")

