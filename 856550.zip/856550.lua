-- Lua provided by RyzenAPI 
-- Game: Stabby Machine
addappid(856550)
addappid(856551, 1, "beccbc527d8cb2ccb80b8a6f02b2863ceb61e6305f476eaabc0f9f6f5193c4ee")
