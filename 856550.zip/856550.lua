-- Lua provided by RyzenAPI
-- Game: Game: Stabby Machine

-- MAIN APPLICATION
addappid(856550)
-- Game: addappid(856550)

-- MAIN APP DEPOTS / PACKAGES
addappid(856551, 1, "beccbc527d8cb2ccb80b8a6f02b2863ceb61e6305f476eaabc0f9f6f5193c4ee")
