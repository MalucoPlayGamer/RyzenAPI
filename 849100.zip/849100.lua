-- Lua provided by RyzenAPI
-- Game: Alaskan Road Truckers

-- MAIN APPLICATION
addappid(849100)

-- MAIN APP DEPOTS / PACKAGES
addappid(849101, 1, "18d06e538da60410ecea175ee8198f8239f0de8d7fa253863ce308029d9135ae")
