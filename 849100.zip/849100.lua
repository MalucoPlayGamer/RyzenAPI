-- Generated with Luie @ https://lua.tools/
-- 849100 - Alaskan Road Truckers
-- Generated 2026-08-23 06:10:48 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(849100, 1, "5b2a19f8bb8ea524da44d6efbff4905948e26ee5338b86087ff4eeaeaa6281f5")

-- Main Depots
addappid(849101, 1, "18d06e538da60410ecea175ee8198f8239f0de8d7fa253863ce308029d9135ae")
setManifestid(849101, "6354848532672904016", 16241238313)

-- DLC's (no depot keys required)
addappid(2600800) -- Alaskan Road Truckers: Mother Truckers Edition
addappid(2704590) -- Alaskan Road Truckers: Ice Road Expansion
addappid(2709680) -- Alaskan Road Truckers: Trucking Hell Edition
addappid(2915720) -- Alaskan Road Truckers: Truck Skins Pack
addappid(3303500) -- Alaskan Road Truckers: Truck Skin Pack 2

-- Token-locked DLCs (couldn't read depots): 3303510
