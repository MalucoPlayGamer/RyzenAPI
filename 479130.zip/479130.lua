-- Lua provided by RyzenAPI
-- Game: ESEA

-- MAIN APPLICATION
addappid(479130)
addappid(497340)

-- MAIN APP DEPOTS / PACKAGES
addappid(479131, 1, "a8eee97a1d7676c8d01da7f00c50d1387bbb7e5cee0ee426a8a043de139f3b98")

