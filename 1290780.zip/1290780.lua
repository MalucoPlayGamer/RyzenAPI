-- Lua provided by RyzenAPI
-- Game: Residual

-- MAIN APPLICATION
addappid(1290780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290782,0,"5bb89c7918e5be976ada01033c27185468ea56908d22d6445d9d089c634f8fe5")

