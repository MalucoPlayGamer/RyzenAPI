-- Lua provided by RyzenAPI
-- Game: SEGA Bass Fishing

-- MAIN APPLICATION
addappid(71240)

-- MAIN APP DEPOTS / PACKAGES
addappid(71241, 1, "8c1a377e674ff017230bc0eb0c4d972e91c638b00a995c368a17f70d5a33f964")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
