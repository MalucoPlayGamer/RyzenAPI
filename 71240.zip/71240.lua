-- Lua provided by RyzenAPI
-- Game: SEGA Bass Fishing

-- MAIN APPLICATION
addappid(71240)
-- Game: addappid(71240)

-- MAIN APP DEPOTS / PACKAGES
addappid(71241, 1, "8c1a377e674ff017230bc0eb0c4d972e91c638b00a995c368a17f70d5a33f964")
