-- Lua provided by RyzenAPI
-- Game: 366230

-- MAIN APPLICATION
addappid(366230)
-- Game: addappid(366230)

-- MAIN APP DEPOTS / PACKAGES
addappid(366231, 1, "ba4c18b5d708b3f29e3d7f2dd0d06c7389c48d8f709be151525743b734233cfe")
