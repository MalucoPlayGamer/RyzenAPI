-- Lua provided by RyzenAPI
-- Game: addappid(1068700)

-- MAIN APPLICATION
addappid(1068700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068701, 1, "20c6bcddeb289e127131da8235c6ec86e7189a65526d0ae6e773bbb99a05e6c8")
