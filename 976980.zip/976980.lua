-- Lua provided by RyzenAPI
-- Game: 976980

-- MAIN APPLICATION
addappid(976980)
-- Game: addappid(976980)

-- MAIN APP DEPOTS / PACKAGES
addappid(976981, 1, "4f752e3c9668a5fd1d956dc7eed1e6a118fb97d0a940f5f402087443fa39f4e7")
