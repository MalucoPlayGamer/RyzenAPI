-- Lua provided by RyzenAPI
-- Game: The Great Emu War

-- MAIN APPLICATION
addappid(976980)

-- MAIN APP DEPOTS / PACKAGES
addappid(976981, 1, "4f752e3c9668a5fd1d956dc7eed1e6a118fb97d0a940f5f402087443fa39f4e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
