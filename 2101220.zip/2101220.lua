-- Lua provided by RyzenAPI
-- Game: 书之旅人 Story Walker

-- MAIN APPLICATION
addappid(2101220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101221, 1, "eb88dd6a71c15a7a735f899b399a6debe07d7e3e3667c1448ed52c0c64afd2f0")

