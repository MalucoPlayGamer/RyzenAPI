-- Lua provided by RyzenAPI
-- Game: 书之旅人 Story Walker

-- MAIN APPLICATION
addappid(2101220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101221, 1, "eb88dd6a71c15a7a735f899b399a6debe07d7e3e3667c1448ed52c0c64afd2f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
