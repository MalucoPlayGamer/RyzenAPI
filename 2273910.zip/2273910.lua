-- Lua provided by RyzenAPI
-- Game: 2273910

-- MAIN APPLICATION
addappid(2273910)
-- Game: addappid(2273910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273911, 1, "dc0d11bc92d6aaccbb8fb08c43ebacc202f153d2aea5666d80fa616eaf2b947e")
