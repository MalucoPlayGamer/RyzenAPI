-- Lua provided by RyzenAPI
-- Game: Project Vostok: Episode 1

-- MAIN APPLICATION
addappid(1783050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783051, 1, "91ff6243da9f535aaaaace1588a72ac3aeafc186291b799e3979e432e6a57d63")
