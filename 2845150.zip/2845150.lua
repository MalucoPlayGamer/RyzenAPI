-- Lua provided by RyzenAPI
-- Game: Seductress

-- MAIN APPLICATION
addappid(2845150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2845151, 1, "81caa5d3690ec58f975c7e299f1dd030ee4eb2c27792622df54c9e6bf147331a")

