-- Lua provided by RyzenAPI
-- Game: Game: Seductress

-- MAIN APPLICATION
addappid(2845150)
-- Game: addappid(2845150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845151, 1, "81caa5d3690ec58f975c7e299f1dd030ee4eb2c27792622df54c9e6bf147331a")
