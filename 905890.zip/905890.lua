-- Lua provided by RyzenAPI
-- Game: 905890

-- MAIN APPLICATION
addappid(905890)
-- Game: addappid(905890)

-- MAIN APP DEPOTS / PACKAGES
addappid(905891, 1, "6271494bf2aab84c6195fa9aa61b9f6eed63bd5c2f61077da6380911b907bbb8")
