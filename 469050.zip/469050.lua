-- Lua provided by RyzenAPI
-- Game: 469050

-- MAIN APPLICATION
addappid(469050)
-- Game: addappid(469050)

-- MAIN APP DEPOTS / PACKAGES
addappid(469050,0,"c5d0c741b29c7c4b7dc4f65625ed718f4ab736d72e22043c41eb42896e21ab93")
