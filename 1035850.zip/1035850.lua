-- Lua provided by RyzenAPI
-- Game: Balancelot

-- MAIN APPLICATION
addappid(1035850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035851, 1, "a5dfdd22bf024eddd3d6762210e4d54f64a358e688c11a74d9f8c185b5de288e")
