-- Lua provided by RyzenAPI
-- Game: Game: Rogue: Genesia

-- MAIN APPLICATION
addappid(2067920)
-- Game: addappid(2067920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067921, 1, "694c6e03c612ee141cf99d179407a9016054d522927e3a6643df1317e545f4c9")
addappid(2067922, 1, "30d15d97387ea8a35c73b655ea8101a694c293d83fc181da021eec8ab76d5666")
