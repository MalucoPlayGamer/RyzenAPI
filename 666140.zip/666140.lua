-- Lua provided by RyzenAPI
-- Game: My Time at Portia

-- MAIN APPLICATION
addappid(666140)
-- Game: addappid(666140)

-- MAIN APP DEPOTS / PACKAGES
addappid(666141, 1, "caba4d1fb75ba07e16c9cf25312648ff7d37f77df1b30238f5e069d54257b9d5")
addappid(666142, 1, "061eb1a76e81ff214a863af97636561615e4efa1d4f37bde4a4b155a2d19c9f9")
addappid(666143, 1, "2619a8a0873ecdbe14188c37a5bfb0541460c5c54a5c13872b44e756fbb7ac1c")
