-- Lua provided by RyzenAPI
-- Game: Drawn®: Dark Flight™ Collector's Edition

-- MAIN APPLICATION
addappid(451140)

-- MAIN APP DEPOTS / PACKAGES
addappid(451141, 1, "b98d4cf2c263c083f797f1c30446e74e179f430e6dd39b94415fd60a15b870d0")
