-- Lua provided by RyzenAPI
-- Game: AppID 1070190

-- MAIN APPLICATION
addappid(1070190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070191, 1, "ca3740b0065d014ddd22a75aaa92ef9b90d26f85ebee3ebafa8e02e971322d2b")

