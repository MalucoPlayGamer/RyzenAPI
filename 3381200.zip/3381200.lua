-- Lua provided by RyzenAPI
-- Game: Game: Lost in Random: The Eternal Die Demo

-- MAIN APPLICATION
addappid(3381200)
-- Game: addappid(3381200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381201, 1, "0bf744048f20700315c7bd846709212aba5c55b3127d953f350d05e1306013d8")
