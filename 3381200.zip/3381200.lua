-- Lua provided by SkyAPI 
-- Game: Lost in Random: The Eternal Die Demo
addappid(3381200)
addappid(3381201, 1, "0bf744048f20700315c7bd846709212aba5c55b3127d953f350d05e1306013d8")
