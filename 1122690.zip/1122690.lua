-- Lua provided by RyzenAPI
-- Game: Last Stop

-- MAIN APPLICATION
addappid(1122690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122691, 1, "6b48c1a96fbf4feac0f79dd004f3a088bf459bcb2580171c7740a7e0decb381a")

