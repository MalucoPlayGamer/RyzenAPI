-- Lua provided by RyzenAPI
-- Game: Last Stop

-- MAIN APPLICATION
addappid(1122690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1122691, 1, "6b48c1a96fbf4feac0f79dd004f3a088bf459bcb2580171c7740a7e0decb381a")

