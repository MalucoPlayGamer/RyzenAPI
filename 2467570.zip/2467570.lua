-- Lua provided by RyzenAPI
-- Game: 真探2 Playtest

-- MAIN APPLICATION
addappid(2467570)
-- Game: addappid(2467570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467571, 1, "1130f03010c1e803befbdeabeb0b1a2d3d9ae7cecfa4e18f258624a39ec06aa0")
