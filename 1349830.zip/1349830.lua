-- Lua provided by RyzenAPI
-- Game: Game: AppID 1349830

-- MAIN APPLICATION
addappid(1349830)
-- Game: addappid(1349830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349831, 1, "012be62c593569b20a806c4fe652fcb49d5b0d9bcd6747d57c9865ff5124d757")
