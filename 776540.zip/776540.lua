-- Lua provided by RyzenAPI
-- Game: 776540

-- MAIN APPLICATION
addappid(776540)
-- Game: addappid(776540)

-- MAIN APP DEPOTS / PACKAGES
addappid(776541, 1, "4d59932fcb22b5d370781cb102e23ffc4d0c96901eae25e79785b218adc539f3")
