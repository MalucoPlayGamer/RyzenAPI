-- Lua provided by RyzenAPI
-- Game: AppID 48180

-- MAIN APPLICATION
addappid(48180)

-- MAIN APP DEPOTS / PACKAGES
addappid(48181, 1, "15adebb56fd697a02d057066e91888d40e3b40a2055eca79886495da82078309")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(48185)
addappid(48186)
addappid(48187)
