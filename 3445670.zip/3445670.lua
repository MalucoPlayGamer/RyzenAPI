-- Lua provided by RyzenAPI
-- Game: Game: What The Chuck?

-- MAIN APPLICATION
addappid(3445670)
-- Game: addappid(3445670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445671, 1, "62a63cc570e442e1916fe6fc475037e5541c6fcf78c3ca46527a2c6571323fe2")
addappid(3445672, 1, "7085ebf5ed9460e976fe67a8b4d10230cfa6d925a2ecce189b67c67259d09e41")
