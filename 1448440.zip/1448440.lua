-- Lua provided by RyzenAPI
-- Game: Game: Wo Long: Fallen Dynasty

-- MAIN APPLICATION
addappid(1448440)
addappid(2205890)
addappid(2205891)
addappid(2205892)
addappid(2205893)
addappid(2205894)
addappid(2205895)
addappid(2205896)
addappid(2612470)
addappid(2612490)
addappid(2654720)
-- Game: addappid(1448440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448441, 1, "ef3b4eaabfb5d6bd17666007dda635b99375509180b267fbba485e2df18b4ed0")
addappid(1448442, 1, "4e508b0bc29665862ed41a6e37c28fe63fc758dca12297e0237f28b2df4b2fd7")
addappid(2232890, 0, "c9d303abb2711b7678880b74da95738ae983c74990967e0607993544a12c5087")
