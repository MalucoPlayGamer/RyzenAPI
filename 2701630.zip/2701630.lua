-- Lua provided by RyzenAPI
-- Game: 2701630

-- MAIN APPLICATION
addappid(2701630)
-- Game: addappid(2701630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701631, 1, "d629d56a26fe6cf4e27f101b307ade60b34bac8af282d63aad387b5912a2038c")
