-- Lua provided by RyzenAPI
-- Game: AppID 1058200

-- MAIN APPLICATION
addappid(1058200)
-- Game: addappid(1058200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058201, 1, "18230c32b07ed02e72d48a40f6e853eb14e94665368e9aa6a7b933784b847962")
addappid(1176206, 0, "7a5bebddc414c8ed4b9b39fecabd8f86c21f505a59bbcb3c1d85fd2c5804e445")
