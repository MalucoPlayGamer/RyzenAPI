-- Lua provided by RyzenAPI
-- Game: Stickman: Fidget Spinner Rush

-- MAIN APPLICATION
addappid(816760)
-- Game: addappid(816760)

-- MAIN APP DEPOTS / PACKAGES
addappid(816761, 1, "2ebf419f335328be1e92fdd25555cba81730bf05965f35af55ed9477f6ecbb0e")
