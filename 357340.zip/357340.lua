-- Lua provided by RyzenAPI 
-- Game: Cobalt
addappid(357340)
addappid(357341, 1, "ecb34960c8c5998a06d150986dc39d61eef34758ae3886917b7e72e64dc69712")
addappid(357342, 1, "e47c0a6e5e7071e010e9ba8dd71093850f80915cf6be9d6670f0c265713b6c87")
