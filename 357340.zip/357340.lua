-- Lua provided by RyzenAPI
-- Game: Cobalt

-- MAIN APPLICATION
addappid(357340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(357341, 1, "ecb34960c8c5998a06d150986dc39d61eef34758ae3886917b7e72e64dc69712")
addappid(357342, 1, "e47c0a6e5e7071e010e9ba8dd71093850f80915cf6be9d6670f0c265713b6c87")

