-- Lua provided by RyzenAPI
-- Game: addappid(1665200)

-- MAIN APPLICATION
addappid(1665200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665201, 1, "dccc6cf28dc470d6b219d7827d2963d4f341b89d37fa34ae0b3f72cd7de8c505")
