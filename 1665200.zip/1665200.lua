-- Lua provided by RyzenAPI 
-- Game: Printersim
addappid(1665200)
addappid(1665201, 1, "dccc6cf28dc470d6b219d7827d2963d4f341b89d37fa34ae0b3f72cd7de8c505")
