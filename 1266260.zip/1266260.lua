-- Lua provided by RyzenAPI
-- Game: Game: null

-- MAIN APPLICATION
addappid(1266260)
-- Game: addappid(1266260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266261, 1, "8b3b647ec35b807b7ad14106b8509880360b3a8c2c34d227a5928439878d7e6e")
