-- Lua provided by RyzenAPI
-- Game: 955500

-- MAIN APPLICATION
addappid(955500)
-- Game: addappid(955500)

-- MAIN APP DEPOTS / PACKAGES
addappid(955501, 1, "ff0f7fa792c6df49e93971de378ec4fcade8c32731460f99c29bc2e8b18ffcf7")
addappid(955502, 1, "a22d52d1ac3ac4f331b5710c518048ebdeeb8d0cec2ec94ffc93689803f1cb0c")
addappid(955503, 1, "bed2da4892c1eea05e69795a218aff4f2d5b90283a3d545119b1c86496c244b5")
