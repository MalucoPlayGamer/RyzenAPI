-- Lua provided by RyzenAPI
-- Game: AppID 934630

-- MAIN APPLICATION
addappid(934630)

-- MAIN APP DEPOTS / PACKAGES
addappid(934631, 1, "01ea9461dbd0dcfd2d6e877fa7337c722f24c0fadaa75e6206c6d3ae013db8df")

