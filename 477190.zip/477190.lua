-- Lua provided by RyzenAPI
-- Game: addappid(477190)

-- MAIN APPLICATION
addappid(477190)

-- MAIN APP DEPOTS / PACKAGES
addappid(477191, 1, "0c7f0f59ac4deead3ac2723496fa50cf9cb637be62de57b543c5408fab0d8cc9")
