-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS: ORIGINS - Official Book (Digital Edition, Japanese version)

-- MAIN APPLICATION
addappid(3319860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319860,0,"eb5c039bb499de6dea3bb580083c831393d697ff12404bae8b7ffcc0d8fe9f28")
addtoken(3319860,"525880456765100502")

