-- Lua provided by RyzenAPI
-- Game: addappid(41500)

-- MAIN APPLICATION
addappid(41500)

-- MAIN APP DEPOTS / PACKAGES
addappid(41501, 1, "6236391020c0136f5aa7550ae18794ff0dce37186d0c94240d2ff1bb6472f889")
addappid(41503, 1, "7c0d23ea8df78c942a0ed2ecbaa432a9eff811030a35e98ddf4c32200497b97d")
