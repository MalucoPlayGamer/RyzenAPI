-- Lua provided by RyzenAPI
-- Game: Kebab Chefs! - Restaurant Simulator

-- MAIN APPLICATION
addappid(1001270)
-- Game: addappid(1001270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001271, 1, "840a384558d951071f078063810429d5c2943f4389e02a2b992ad4e6cb001088")
