-- Lua provided by RyzenAPI
-- Game: NEW MONOPOLY®

-- MAIN APPLICATION
addappid(2929170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929171, 1, "9b638d9d641002703aee53b99579d38083b750a66ab978deff899c1a2739b312")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3062820)
