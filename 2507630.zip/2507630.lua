-- Lua provided by RyzenAPI
-- Game: Zombie Party 丧尸派对

-- MAIN APPLICATION
addappid(2507630)
-- Game: addappid(2507630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507631, 1, "c9e68f4286ef4435c790c178965fb8d865fc6c4ccb3ec3334183335cd1515549")
