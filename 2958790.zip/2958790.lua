-- Lua provided by RyzenAPI
-- Game: Game: Cyclopean: The Great Abyss

-- MAIN APPLICATION
addappid(2958790)
-- Game: addappid(2958790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958791, 1, "7ce07f270f809127b2101e82edf7ab70d9fab59339f3b72b08535e6e73ae2e5e")
