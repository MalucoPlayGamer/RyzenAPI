-- Lua provided by RyzenAPI 
-- Game: Cyclopean: The Great Abyss
addappid(2958790)
addappid(2958791, 1, "7ce07f270f809127b2101e82edf7ab70d9fab59339f3b72b08535e6e73ae2e5e")
