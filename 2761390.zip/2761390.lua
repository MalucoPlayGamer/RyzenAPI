-- Lua provided by RyzenAPI
-- Game: Tabletop Hero Demo

-- MAIN APPLICATION
addappid(2761390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761391, 1, "23f642ae5b5529c736a591a7c087fb3fc6b9234a670a568db42e1165696171b0")

