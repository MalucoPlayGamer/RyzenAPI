-- Lua provided by RyzenAPI
-- Game: 464670

-- MAIN APPLICATION
addappid(464670)
-- Game: addappid(464670)

-- MAIN APP DEPOTS / PACKAGES
addappid(464671, 1, "c0b5b2160013cd3b990cc5fd35e54d52de44296b0ff33be8b90397cc6d518b0a")
