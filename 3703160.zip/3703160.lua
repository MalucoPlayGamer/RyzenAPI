-- Lua provided by RyzenAPI
-- Game: Pocket Turtles

-- MAIN APPLICATION
addappid(3703160)
-- Game: addappid(3703160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3703161, 1, "b38f25476fa45cb23783c101d2ab62243f133d48de296190a6aedd8056ce6108")
