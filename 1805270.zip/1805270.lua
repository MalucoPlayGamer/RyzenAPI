-- Lua provided by RyzenAPI
-- Game: Game: TitTok Girls

-- MAIN APPLICATION
addappid(1805270)
addappid(1822830)
-- Game: addappid(1805270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805271, 1, "5798aad447d4003d6d20c45fecc0098123fe8176172b682eca935121e69cc2e6")
