-- Lua provided by RyzenAPI
-- Game: AppID 1904020

-- MAIN APPLICATION
addappid(1904020)
-- Game: addappid(1904020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904021, 1, "e555bf5de17b5d97fd73dd5925bf922c96b14f200e660deebe47a118e7ef588c")
