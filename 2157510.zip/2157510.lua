-- Lua provided by RyzenAPI
-- Game: Pool Game

-- MAIN APPLICATION
addappid(2157510)
-- Game: addappid(2157510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157511, 1, "3b1c31343bf4585c38db21c3786617c22efc3a953be47b34a4c15833265e98a6")
