-- Lua provided by RyzenAPI
-- Game: Pool Game

-- MAIN APPLICATION
addappid(2157510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2157511, 1, "3b1c31343bf4585c38db21c3786617c22efc3a953be47b34a4c15833265e98a6")

