-- Lua provided by RyzenAPI
-- Game: Game: King Erik

-- MAIN APPLICATION
addappid(656130)
-- Game: addappid(656130)

-- MAIN APP DEPOTS / PACKAGES
addappid(656131, 1, "1588745100f58c49aa825403bd886db367651e868d9c09d05b068846ceccc08b")
