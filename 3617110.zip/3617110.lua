-- Lua provided by RyzenAPI
-- Game: 3617110

-- MAIN APPLICATION
addappid(3617110)
addappid(3617115)
addappid(3617116)
-- Game: addappid(3617110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3617114,0,"6077ccf1e0ec0bb6c1aef1d3af682ae469991b6cb4761bd02e8e23f42980d719")
