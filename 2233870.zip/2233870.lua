-- Lua provided by RyzenAPI
-- Game: 2233870

-- MAIN APPLICATION
addappid(2233870)
-- Game: addappid(2233870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233871, 1, "2d603d80c6e6ebe6e9e55421b5ca6697714e43b03485dfc99d4b01ecf297e48d")
