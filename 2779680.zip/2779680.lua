-- Lua provided by RyzenAPI
-- Game: 2779680

-- MAIN APPLICATION
addappid(2779680)
-- Game: addappid(2779680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779681, 1, "5d8291707b2ecbd3007d0dbf976a44f21f46288f3f631546f90bad12e345f004")
