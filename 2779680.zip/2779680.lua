-- Lua provided by RyzenAPI
-- Game: Stories to Tell [Alpha 1] - Run Away

-- MAIN APPLICATION
addappid(2779680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779681, 1, "5d8291707b2ecbd3007d0dbf976a44f21f46288f3f631546f90bad12e345f004")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
