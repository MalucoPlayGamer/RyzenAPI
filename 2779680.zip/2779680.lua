-- Lua provided by SkyAPI 
-- Game: Stories to Tell [Alpha 1] - Run Away
addappid(2779680)
addappid(2779681, 1, "5d8291707b2ecbd3007d0dbf976a44f21f46288f3f631546f90bad12e345f004")
