-- Lua provided by RyzenAPI
-- Game: Evercore Heroes : Ascension

-- MAIN APPLICATION
addappid(2586780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2586781, 1, "aecfcf1cbc65fd9d45b3b2e1d6bdd0e56c5662933d4ed9f703c6b2c5cfab1588")

