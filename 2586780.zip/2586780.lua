-- Lua provided by RyzenAPI
-- Game: Evercore Heroes : Ascension

-- MAIN APPLICATION
addappid(2586780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586781, 1, "aecfcf1cbc65fd9d45b3b2e1d6bdd0e56c5662933d4ed9f703c6b2c5cfab1588")

