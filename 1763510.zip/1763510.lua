-- Lua provided by RyzenAPI
-- Game: X8

-- MAIN APPLICATION
addappid(1763510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763511, 1, "be8d25f344a50ee5aed64e14d427b15625172d72b6cecb994fbaf1c7a0d3f2d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2888270)
addappid(2888280)
addappid(3224190)
addappid(3224200)
addappid(3224210)
