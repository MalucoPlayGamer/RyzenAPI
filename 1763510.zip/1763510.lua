-- Lua provided by RyzenAPI
-- Game: addappid(1763510)

-- MAIN APPLICATION
addappid(1763510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763511, 1, "be8d25f344a50ee5aed64e14d427b15625172d72b6cecb994fbaf1c7a0d3f2d2")
