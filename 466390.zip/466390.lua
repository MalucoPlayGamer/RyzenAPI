-- Lua provided by RyzenAPI
-- Game: addappid(466390)

-- MAIN APPLICATION
addappid(466390)

-- MAIN APP DEPOTS / PACKAGES
addappid(466390,0,"cbc8339aee28cc9461aa44f0509230f175fbccef2ae0fc1eac84409a060e55e5")
