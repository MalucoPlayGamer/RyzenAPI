-- Lua provided by RyzenAPI
-- Game: Forest Survival

-- MAIN APPLICATION
addappid(934880)

-- MAIN APP DEPOTS / PACKAGES
addappid(934881, 1, "03837cc1359ebdfa4d9c5fd379a3393f55f9c1df0834e4213ae21bb6e45b9ec2")

