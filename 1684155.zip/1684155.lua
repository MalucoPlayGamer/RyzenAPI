-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1684155)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684155,0,"31b346ea8a3587edb6e690ca28efbf543d7f1514e1424c864572976a1df7a0c8")
