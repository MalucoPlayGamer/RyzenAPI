-- Lua provided by RyzenAPI
-- Game: addappid(1684155)

-- MAIN APPLICATION
addappid(1684155)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684155,0,"31b346ea8a3587edb6e690ca28efbf543d7f1514e1424c864572976a1df7a0c8")
