-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 Friendly and Slightly Naughty Woman GP-01Fb

-- MAIN APPLICATION
addappid(3652510)
-- Game: addappid(3652510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652511, 1, "54ae1e36c49072b88c38bc46b0716f295017b1842039f4b03c43dbcc48ef7fc0")
