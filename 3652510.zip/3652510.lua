-- Lua provided by RyzenAPI
-- Game: addappid(3652510)

-- MAIN APPLICATION
addappid(3652510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3652511, 1, "54ae1e36c49072b88c38bc46b0716f295017b1842039f4b03c43dbcc48ef7fc0")
