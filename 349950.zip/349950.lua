-- Lua provided by RyzenAPI
-- Game: 349950

-- MAIN APPLICATION
addappid(349950)
-- Game: addappid(349950)

-- MAIN APP DEPOTS / PACKAGES
addappid(349951, 1, "0334bce85049b61b3a8599e4ed218e78d2aae3f16f6648dc679d12513117a5e8")
