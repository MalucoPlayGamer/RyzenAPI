-- Lua provided by RyzenAPI
-- Game: SYNTHALGIA: Retro Arcade Racing Demo

-- MAIN APPLICATION
addappid(2797090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797091, 1, "7b1866082ab22324fb62dac9581693216d18db5e537868fbeaa406d833591d3d")
