-- Lua provided by SkyAPI 
-- Game: AppID 2797090
addappid(2797090)
addappid(2797091, 1, "7b1866082ab22324fb62dac9581693216d18db5e537868fbeaa406d833591d3d")
