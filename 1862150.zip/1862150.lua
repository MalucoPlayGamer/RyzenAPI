-- Lua provided by RyzenAPI
-- Game: My Furry Teacher - 18+ Adult Only Patch

-- MAIN APPLICATION
addappid(1862150)
-- Game: addappid(1862150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862150,0,"338124c601d7259d0099031003229e310b50c4501155b013e42bff003855806c")
