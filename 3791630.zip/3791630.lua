-- Lua provided by RyzenAPI
-- Game: Samurai beat demons

-- MAIN APPLICATION
addappid(3791630) -- Samurai beat demons

-- MAIN APP DEPOTS / PACKAGES
addappid(3791631, 1, "ed65a4bcd4ff88b5bc03c7f6e7c795ed973a9d1f79c555b2cd0e3ce7b53ecc49") -- Depot 3791631
addappid(3791632, 1, "dbabcc9e75b2d83c3367ac5781132b504a8fbb969636aa6e22ad8bd26f2f4956") -- Depot 3791632

