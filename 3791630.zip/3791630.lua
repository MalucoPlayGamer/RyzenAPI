-- 3791630's Lua and Manifest Created by Hubcap Manifest
-- Samurai beat demons
-- Created: August 11, 2026 at 00:20:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3791630) -- Samurai beat demons
-- MAIN APP DEPOTS
addappid(3791632, 1, "dbabcc9e75b2d83c3367ac5781132b504a8fbb969636aa6e22ad8bd26f2f4956") -- Depot 3791632
setManifestid(3791632, "3783227565976436776", 407432150)
addappid(3791631, 1, "ed65a4bcd4ff88b5bc03c7f6e7c795ed973a9d1f79c555b2cd0e3ce7b53ecc49") -- Depot 3791631
setManifestid(3791631, "4643854386784796330", 432286500)