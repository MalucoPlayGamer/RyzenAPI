-- Lua provided by RyzenAPI
-- Game: Final Cut: Encore Collector's Edition

-- MAIN APPLICATION
addappid(622550)

-- MAIN APP DEPOTS / PACKAGES
addappid(622551, 1, "fa8e0f03dfb23ea9ca15ed7198a6142d6f6c64c058dae6a4bf34e6296c762157")
