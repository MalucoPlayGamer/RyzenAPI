-- Lua provided by RyzenAPI
-- Game: 575880

-- MAIN APPLICATION
addappid(575880)
-- Game: addappid(575880)

-- MAIN APP DEPOTS / PACKAGES
addappid(575881, 1, "78b8894996e48b9dc927d06d616a871ef1982a0fced031e29823d4a37ae60f62")
