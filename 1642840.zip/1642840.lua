-- Lua provided by RyzenAPI
-- Game: 我16岁辍学做游戏！

-- MAIN APPLICATION
addappid(1642840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1642841, 1, "a253c60a3167f05240e6e4e85dc08e45f623c1c536f1b1ceb833e32eaaf287cd")
addappid(1642842, 1, "96b735e2978be678bc8663062d881bc7174c246e0b1e9502840b37bbc4b60006")

