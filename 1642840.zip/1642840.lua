-- Lua provided by RyzenAPI 
-- Game: 我16岁辍学做游戏！
addappid(1642840)
addappid(1642841, 1, "a253c60a3167f05240e6e4e85dc08e45f623c1c536f1b1ceb833e32eaaf287cd")
addappid(1642842, 1, "96b735e2978be678bc8663062d881bc7174c246e0b1e9502840b37bbc4b60006")
