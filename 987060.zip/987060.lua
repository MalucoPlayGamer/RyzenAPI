-- Lua provided by RyzenAPI
-- Game: Auri's Tales

-- MAIN APPLICATION
addappid(987060)

-- MAIN APP DEPOTS / PACKAGES
addappid(987061, 1, "0d1dca96b77f28c621d5c49cd31f30426c603d54d54439a0aab4629b99e1303b")

