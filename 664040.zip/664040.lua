-- Lua provided by RyzenAPI
-- Game: Staff Wars: Wizard Rumble

-- MAIN APPLICATION
addappid(664040)

-- MAIN APP DEPOTS / PACKAGES
addappid(664042,0,"65b67495d2e54779335c1a335a97602727c1b5ef9812a72ff169dbd8ab2799f9")

