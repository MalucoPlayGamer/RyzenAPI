-- Lua provided by RyzenAPI
-- Game: Staff Wars: Wizard Rumble

-- MAIN APPLICATION
addappid(664040)

-- MAIN APP DEPOTS / PACKAGES
addappid(664042,0,"65b67495d2e54779335c1a335a97602727c1b5ef9812a72ff169dbd8ab2799f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
