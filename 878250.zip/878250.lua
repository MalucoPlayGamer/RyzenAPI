-- Lua provided by RyzenAPI
-- Game: 878250

-- MAIN APPLICATION
addappid(878250)
-- Game: addappid(878250)

-- MAIN APP DEPOTS / PACKAGES
addappid(878251, 1, "43a99007b8708ded5b6037639b8b0df77d6dc4b93fab93d2338d963d071287b1")
addappid(1056621, 0, "94b26e46282cf029bf5b976bd4d3e6b4814d247af6d39fdc1e2301c722c2efad")
