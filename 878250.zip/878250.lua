-- Lua provided by SkyAPI 
-- Game: Super Jigsaw Puzzle: Monuments
addappid(878250)
addappid(878251, 1, "43a99007b8708ded5b6037639b8b0df77d6dc4b93fab93d2338d963d071287b1")
addappid(1056621, 0, "94b26e46282cf029bf5b976bd4d3e6b4814d247af6d39fdc1e2301c722c2efad")
