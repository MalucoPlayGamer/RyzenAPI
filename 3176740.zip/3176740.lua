-- Lua provided by RyzenAPI
-- Game: Multiplayer Bikini Brawlers

-- MAIN APPLICATION
addappid(3176740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176741, 1, "15956ba6d091cf367733d24bbbe56de40fd1fd1dd69ea9fa6566512d97b01a75")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
