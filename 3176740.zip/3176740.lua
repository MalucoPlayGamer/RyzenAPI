-- Lua provided by RyzenAPI
-- Game: 3176740

-- MAIN APPLICATION
addappid(3176740)
-- Game: addappid(3176740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176741, 1, "15956ba6d091cf367733d24bbbe56de40fd1fd1dd69ea9fa6566512d97b01a75")
