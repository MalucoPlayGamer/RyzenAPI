-- Lua provided by RyzenAPI
-- Game: Warudo

-- MAIN APPLICATION
addappid(2079120)
-- Game: addappid(2079120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079121, 1, "7d87560de09898a8ed75d0f43ee05a8b70dc3f2fb3a3c1dcef76e1cde89d9899")
