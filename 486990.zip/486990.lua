-- Lua provided by RyzenAPI
-- Game: AppID 486990

-- MAIN APPLICATION
addappid(486990)
-- Game: addappid(486990)

-- MAIN APP DEPOTS / PACKAGES
addappid(486991, 1, "ab17f8f3bbd5f04e41c794983599b7802dfe78c66ad590828c5306e619b29ec5")
