-- Lua provided by RyzenAPI
-- Game: Game: 63 Days Demo

-- MAIN APPLICATION
addappid(2867690)
-- Game: addappid(2867690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867691, 1, "4a00300f4c2d9667f853839a51328aa640e318a6e693ab38683743537b1de90c")
