-- Lua provided by RyzenAPI
-- Game: addappid(1427140)

-- MAIN APPLICATION
addappid(1427140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427141, 1, "ffb4b074e26666dbfe562e4b0086038fffd9ac675445050d3066c93909208f9a")
