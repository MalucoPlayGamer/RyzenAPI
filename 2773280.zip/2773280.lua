-- Lua provided by RyzenAPI
-- Game: ANEURISM IV

-- MAIN APPLICATION
addappid(2773280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2773281, 1, "0baa8f9cbe5a1fc3fbe71857aafe65b90379e67019d61fda1e44205ad376e2ec")

