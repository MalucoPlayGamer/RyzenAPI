-- Lua provided by RyzenAPI
-- Game: ANEURISM IV

-- MAIN APPLICATION
addappid(2773280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773281, 1, "0baa8f9cbe5a1fc3fbe71857aafe65b90379e67019d61fda1e44205ad376e2ec")
