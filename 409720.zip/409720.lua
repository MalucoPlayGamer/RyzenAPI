-- Lua provided by RyzenAPI
-- Game: BioShock 2 Remastered

-- MAIN APPLICATION
addappid(409720)
addappid(525720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(409721, 1, "56e58e17318457e873c36142f228883f76508c0ca1bc36270edf4405d546de48")
addappid(409722, 1, "a6ff58d9629130ba9d51f530f81baa688d8a315ec5a4c987340bd102a8873d66")
addappid(409723, 1, "a52ef043d894dafe4165d50e03b5294853ca2f5274fa12f27b4dc380f97ebf67")
addappid(1523211, 0, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
