-- Lua provided by RyzenAPI 
-- Game: AppID 622150
addappid(622150)
addappid(622151, 1, "7772c695e4e9fbb1ab4e131fe5cb9d2cd81ff35a7fd75a62a8422ba530dde0ab")
