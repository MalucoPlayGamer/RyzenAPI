-- Lua provided by RyzenAPI
-- Game: 761660

-- MAIN APPLICATION
addappid(761660)
-- Game: addappid(761660)

-- MAIN APP DEPOTS / PACKAGES
addappid(761661, 1, "4446d632d73e77a9fe9401f24d0ef1da1ccff7732edb1dc1e60ba8b328c7f330")
addappid(761662, 1, "c7ca01508cd2f6a019b2129bce93acf976c6c1a8af7d738e11ba611e6bd74fed")
addappid(761663, 1, "05d3170c90e8a99625c436dfef817c771e14b76b2e09c1db28ac2846aeca59e3")
