-- Lua provided by RyzenAPI
-- Game: MX vs ATV Legends

-- MAIN APPLICATION
addappid(1205970) -- MX vs ATV Legends
addappid(1949660) -- MX vs ATV Legends - Customization Pack
addappid(1979070) -- MX vs ATV Legends - 2022 AMA Pro Motocross Championship
addappid(1979071) -- MX vs ATV Legends - Track Pass
addappid(1979072) -- MX vs ATV Legends - Supercross World Tour
addappid(1979073) -- MX vs ATV Legends - Honda Pack 2022
addappid(1979074) -- MX vs ATV Legends - Husqvarna Pack 2022
addappid(1979075) -- MX vs ATV Legends - Kawasaki Pack 2022
addappid(1979090) -- MX vs ATV Legends - KTM Pack 2022
addappid(1979091) -- MX vs ATV Legends - Suzuki Pack 2022
addappid(1979092) -- MX vs ATV Legends - Polaris Pack
addappid(1979093) -- MX vs ATV Legends - Yamaha Pack 2022
addappid(2021800) -- MX vs ATV Legends - Slayground
addappid(2357890) -- MX vs ATV Legends - 2023 AMA Pro Motocross Championship
addappid(2438710) -- MX vs ATV Legends - Track Pass 2023
addappid(2487890) -- MX vs ATV Legends - GASGAS Pack 2023
addappid(2487891) -- MX vs ATV Legends - Honda Pack 20232024
addappid(2487892) -- MX vs ATV Legends - Husqvarna Pack 20232024
addappid(2487893) -- MX vs ATV Legends - Kawasaki Pack 20232024
addappid(2487894) -- MX vs ATV Legends - KTM Pack 20232024
addappid(2487895) -- MX vs ATV Legends - Suzuki Pack 20232024
addappid(2487896) -- MX vs ATV Legends - Yamaha Pack 20232024
addappid(2487900) -- MX vs ATV Legends - Compound Pack
addappid(2487901) -- MX vs ATV Legends - Throwback Tracks
addappid(2769900) -- MX vs ATV Legends - 2024 Monster Energy Supercross Championship
addappid(2928000) -- MX vs ATV Legends - 2024 AMA Pro Motocross Championship
addappid(2994710) -- MX vs ATV Legends - Triumph Pack 2024
addappid(2994720) -- MX vs ATV Legends - Track Pass 2024
addappid(3030670) -- MX vs ATV Legends - Element Bike Pack
addappid(3155040) -- MX vs ATV Legends - Reflex Pack
addappid(3336420) -- MX vs ATV Legends - Lawrence Dog Pound Pack
addappid(3465920) -- MX vs ATV Legends - Yamaha Pack 2025
addappid(3465930) -- MX vs ATV Legends - Kawasaki Pack 2025
addappid(3465940) -- MX vs ATV Legends - Honda Pack 2025
addappid(3465950) -- MX vs ATV Legends - Suzuki Pack 2025
addappid(3465960) -- MX vs ATV Legends - KTM Pack 2025
addappid(3466750) -- MX vs ATV Legends - Husqvarna Pack 2025
addappid(3466760) -- MX vs ATV Legends - GASGAS Pack 2025
addappid(3555990) -- MX vs ATV Legends - 2025 Monster Energy Supercross Championship
addappid(3556000) -- MX vs ATV Legends - 2025 AMA Pro Motocross Championship
addappid(3556010) -- MX vs ATV Legends - Redline Ridge Finals
addappid(3556020) -- MX vs ATV Legends - Pastranaland
addappid(3906670) -- MX vs ATV Legends - Track Pass 2025
addappid(4499340) -- MX vs ATV Legends - Track Pass 2026
addappid(4499350) -- MX vs ATV Legends - Daytona Supercross Pack 2026
addappid(4499360) -- MX vs ATV Legends - Motocross World Tour
addappid(4499390) -- MX vs ATV Legends - Honda Pack 2026
addappid(4499400) -- MX vs ATV Legends - Suzuki Pack 2026
addappid(4499410) -- MX vs ATV Legends - Kawasaki Pack 2026
addappid(4499420) -- MX vs ATV Legends - Yamaha Pack 2026
addappid(4499430) -- MX vs ATV Legends - KTM Pack 2026
addappid(4499440) -- MX vs ATV Legends - Husqvarna Pack 2026
addappid(4499450) -- MX vs ATV Legends - GASGAS Pack 2026
addappid(4499460) -- MX vs ATV Legends - Triumph Pack 2026
addappid(4499470) -- MX vs ATV Legends - Beta Pack 2026

-- MAIN APP DEPOTS / PACKAGES
addappid(1205971, 1, "bda7fa2a1e987629940c3faf629f17a0af5939f54cc244a56b1ac57e29739bbf") -- Depot 1205971

