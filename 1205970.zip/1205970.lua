-- Lua provided by RyzenAPI
-- Game: 1205970

-- MAIN APPLICATION
addappid(1205970)
-- Game: addappid(1205970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205971, 1, "bda7fa2a1e987629940c3faf629f17a0af5939f54cc244a56b1ac57e29739bbf")
