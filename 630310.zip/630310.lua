-- Lua provided by RyzenAPI
-- Game: The Mummy Demastered

-- MAIN APPLICATION
addappid(630310)

-- MAIN APP DEPOTS / PACKAGES
addappid(630311, 1, "8b8c3cc8e7e8eddb2178f670c8550f6d5d63772a6814b4c3cf0beb4a65581544")

