-- Lua provided by RyzenAPI
-- Game: 799640

-- MAIN APPLICATION
addappid(799640)
-- Game: addappid(799640)

-- MAIN APP DEPOTS / PACKAGES
addappid(799641, 1, "7170d2682fbc0a2a4ce11b8da18314e79358a14fce34a6e277060dfaf96595f2")
addappid(799642, 1, "e72f22ea8419781c9583b49be2fda6a72ef8356eee885ad7320b267b98d63bf5")
addappid(799643, 1, "d70f422e7fcba45f627d6fd8c5e71baa0234e23739e343a59b23fc3d8a6e12c6")
addappid(3185730, 0, "ebffda2eb35e60c49f5a8d42ca8519e6860fcf913ec3e4a8a7eb52df9b80c752")
