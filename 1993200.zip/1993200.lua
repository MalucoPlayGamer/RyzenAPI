-- Lua provided by RyzenAPI
-- Game: Witch 3 Return

-- MAIN APPLICATION
addappid(1993200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993201, 1, "f45aa0821afd0f4f8737d325133045d539628c7248cd23501cf86d587e343064")
addappid(2175920, 0, "34d37eb138d09434d2e234b5ccc80e06a7a861234fb43458428f40731cac6367")
addappid(2234180, 0, "8587d9704eb5d86ea792131499202e43fa1dee642757055f7d7b887b900de8e4")
addappid(2649950, 0, "42fea7405a0d8671cc7d2eb3262350a8bbe63aa29f43ac535e8cefcf1d6389af")
addappid(3046730, 0, "2a831e48e3360de0118da4da574271cfbd195cf66c3c8dc4d50767fa6dcf1a00")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
