-- Lua provided by RyzenAPI
-- Game: AppID 249190

-- MAIN APPLICATION
addappid(249190)

-- MAIN APP DEPOTS / PACKAGES
addappid(249191, 1, "21c8878c6754a4b96485c44076dae012ab8cebef5846444e279ac86f86a5af4e")
addappid(249192, 1, "018db9a56d89d121df0f389bf2ffb987fd6428d3b5e23fb1952fcba0a9485b0b")
addappid(316880, 0, "feb6cd12b369ec4d006157cf0dd9a358d786288804c57663d8a9373fe1c9411d")
addappid(317090, 0, "474e097a4ca3749f7a1395e0360911b4300e0098fffb4cac2a4094bfe98a5718")
addappid(317190, 0, "6a53532b7f9e0c1a5cb4bae18eadc14a91191f112f0180c32ddf3f343af48f72")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
