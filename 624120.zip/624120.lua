-- Lua provided by RyzenAPI
-- Game: Football Manager Touch 2018

-- MAIN APPLICATION
addappid(624120)
addappid(711731)
addappid(711732)
addappid(711733)
addappid(711734)
addappid(711735)
addappid(711736)
addappid(711737)
addappid(711738)
addappid(711739)
addappid(711740)
addappid(711741)
addappid(711742)
addappid(711743)
addappid(711744)
addappid(711745)
addappid(711746)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(624121,0,"4db8c78e1d16b50c222ed07425fa91b483877e9c0c834e4fe6158381b631d307")
addappid(624122,0,"5d49638ee7424a546031e5af819b0eb38a1e57151e1e4ed2d6898ff5108b6401")
addappid(624123,0,"9713e12fa27f9817ab4cfe2675b5247329335d0d2131ea6ffd5bb17a09ac0814")
addappid(624124,0,"29e64821248c1cf96214fbaa861441737b469faf5a3b697ebb0955e98f8863c9")
addappid(624125,0,"990a33571afd643d6bf6fe7dd671da55c82507e5fe5841a5a94082e51462ca82")

