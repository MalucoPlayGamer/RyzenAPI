-- Lua provided by RyzenAPI
-- Game: Revulsion

-- MAIN APPLICATION
addappid(719180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(719181, 1, "a0d3132129dc3f632bdcc54b73e6b13c8c753cf08bf959da72e82d9de83b045a")

