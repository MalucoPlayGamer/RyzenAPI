-- Lua provided by RyzenAPI
-- Game: AppID 880550

-- MAIN APPLICATION
addappid(880550)
-- Game: addappid(880550)

-- MAIN APP DEPOTS / PACKAGES
addappid(880551, 1, "94511b8b3d437267ff71e71cc52aa3578010cb43a6b283860589aafeb6409705")
addappid(887980, 0, "5997a6672d9eec0aff9dd0b56bdf4d5919df8392fb429f1e6e264fc9f9e5f531")
