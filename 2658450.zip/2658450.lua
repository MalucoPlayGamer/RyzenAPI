-- Lua provided by RyzenAPI
-- Game: Game: LOLLIPOP CHAINSAW RePOP

-- MAIN APPLICATION
addappid(2658450)
-- Game: addappid(2658450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658451, 1, "d3c09b507a343a7ba3c75abd0ce562ceb1c9f33c4a5c840a65bf5f245df9d891")
