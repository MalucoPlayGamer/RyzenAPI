-- Lua provided by RyzenAPI
-- Game: Game: Crossing Damaged Bridge

-- MAIN APPLICATION
addappid(2425890)
-- Game: addappid(2425890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425891, 1, "69503c3a11eb6a68267fb8ee8d5bf836e9669d2c18a4683b61fca543317a0cc6")
