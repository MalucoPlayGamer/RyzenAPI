-- Lua provided by RyzenAPI
-- Game: addappid(1461540)

-- MAIN APPLICATION
addappid(1461540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461541, 1, "03f1c85d85419d6d06391ced4e70fe79257954891c2c678dc16dc007a86dce27")
