-- Lua provided by RyzenAPI
-- Game: Rise of the Triad Ludicrous Development Kit

-- MAIN APPLICATION
addappid(255190)

-- MAIN APP DEPOTS / PACKAGES
addappid(255191, 1, "74cc76ed9b4ec7547627f74147e1f4a62e204016d8dae8a24ff8f346451df355")
