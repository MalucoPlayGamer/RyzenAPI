-- Lua provided by RyzenAPI
-- Game: addappid(691930)

-- MAIN APPLICATION
addappid(691930)

-- MAIN APP DEPOTS / PACKAGES
addappid(691931, 1, "caecc224a736170ec3dd08e0e464fcb07431d0060ea2fc46bca84d5a9d6c4c29")
