-- Lua provided by RyzenAPI
-- Game: MSI Electric City: Core Assault

-- MAIN APPLICATION
addappid(691930)

-- MAIN APP DEPOTS / PACKAGES
addappid(691931, 1, "caecc224a736170ec3dd08e0e464fcb07431d0060ea2fc46bca84d5a9d6c4c29")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
