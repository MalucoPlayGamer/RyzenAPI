-- Lua provided by RyzenAPI
-- Game: addappid(2777670)

-- MAIN APPLICATION
addappid(2777670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777671, 1, "a42f12729090f568d4ba8ea0bad82c8cf10d839ed13e6cae0d910deba3640ebb")
