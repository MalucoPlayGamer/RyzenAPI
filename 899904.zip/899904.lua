-- Lua provided by RyzenAPI
-- Game: 899904

-- MAIN APPLICATION
addappid(899904)

-- MAIN APP DEPOTS / PACKAGES
addappid(899904,0,"ac72ebe9ff44e6b9173f64f00cd5b62db5b181138716e7497b1dda7b4ffb962a")
