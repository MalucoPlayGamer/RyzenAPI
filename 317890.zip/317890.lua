-- Lua provided by RyzenAPI
-- Game: 317890

-- MAIN APPLICATION
addappid(317890)

-- MAIN APP DEPOTS / PACKAGES
addappid(317895,0,"1fc0a74210fff63f8a7c9c4c332aa1b19c43c360f0145a63dc7d3c7e958f156f")

