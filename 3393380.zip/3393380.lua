-- Lua provided by RyzenAPI
-- Game: The Sex Curse 💋

-- MAIN APPLICATION
addappid(3393380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393381, 1, "dbbbceaacfb69c9db65ca46e19cfec3e6f1e4e6e9b63328a5208a35b6ee90e5d")

