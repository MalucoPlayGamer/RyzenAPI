-- Lua provided by RyzenAPI
-- Game: setManifestid(1932472,"1397413422184412988")

-- MAIN APPLICATION
addappid(1932470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932472,0,"8a08e67d747aa64d312cc6822cc5caf2da8af947c28d72c7d14a405eeefbaddc")
