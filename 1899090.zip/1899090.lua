-- Lua provided by RyzenAPI
-- Game: addappid(1899090)

-- MAIN APPLICATION
addappid(1899090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899091, 1, "adcfe0b660710b37dad77d23f669e4f8229c3853005b6f8558449aafc0ea9389")
