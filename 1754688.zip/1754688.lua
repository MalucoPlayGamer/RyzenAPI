-- Lua provided by RyzenAPI
-- Game: addappid(1754688)

-- MAIN APPLICATION
addappid(1754688)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754688,0,"3e88a9d47ab78f7bcdbeccd14956e5d593fa48195b16cfeff5ab3dbfe31531a0")
