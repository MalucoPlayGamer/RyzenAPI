-- Lua provided by SkyAPI 
-- Game: AppID 1770090
addappid(1770090)
addappid(1770091, 1, "e2ff60da85ff484fae4d2995f7dd4e47b79e6f9e53a6d0e6eb89a095d4ee93f0")
addappid(1770092, 1, "f57dc42fa1bb9c6f97090f2ff8eb58475960f64de0f91b8e4c44f3edebccb9de")
