-- Lua provided by RyzenAPI
-- Game: Autumn and Girls

-- MAIN APPLICATION
addappid(1437700)
addappid(1447040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437701, 1, "d9140ad7afcb567dee5fcec419301516d97fb6e41bf92eca4a9bbc3814239050")
