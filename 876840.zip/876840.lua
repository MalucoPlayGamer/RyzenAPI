-- Lua provided by RyzenAPI
-- Game: 999

-- MAIN APPLICATION
addappid(876840)

-- MAIN APP DEPOTS / PACKAGES
addappid(876841,0,"f26b2971216f70d8fae4fcfc5dd34d74a3eaa68491d2ba22fb57a5255c93b5b0")