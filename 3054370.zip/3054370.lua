-- Lua provided by RyzenAPI
-- Game: addappid(3054370)

-- MAIN APPLICATION
addappid(3054370)
addappid(3054371)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054372,0,"7c01108b691d5d17e9fad58cf32a2bbe02e21e1f8d00642b5fedaf60dd3e95c4")
