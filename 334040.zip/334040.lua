-- Lua provided by RyzenAPI
-- Game: addappid(334040)

-- MAIN APPLICATION
addappid(334040)

-- MAIN APP DEPOTS / PACKAGES
addappid(334041, 1, "e96d0a2a1fd77f3b140e7b128779c8e31ca32463b590bd5cc6e1df00bf6c794c")
