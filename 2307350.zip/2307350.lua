-- Lua provided by SkyAPI 
-- Game: AppID 2307350
addappid(2307350)
addappid(2307351, 1, "20260ee59d150cc2511edf793073971d569a98d93db3564c77622ff953243a00")
