-- Lua provided by RyzenAPI
-- Game: AppID 2307350

-- MAIN APPLICATION
addappid(2307350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307351, 1, "20260ee59d150cc2511edf793073971d569a98d93db3564c77622ff953243a00")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4767560)
