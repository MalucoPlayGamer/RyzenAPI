-- Lua provided by RyzenAPI
-- Game: Into the Radius 2

-- MAIN APPLICATION
addappid(2307350)
addappid(4767560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307351, 1, "20260ee59d150cc2511edf793073971d569a98d93db3564c77622ff953243a00")

