-- Lua provided by RyzenAPI
-- Game: 648260

-- MAIN APPLICATION
addappid(648260)
-- Game: addappid(648260)

-- MAIN APP DEPOTS / PACKAGES
addappid(648261, 1, "c57dd4f68158b7df820d5d0266f59bb05aa732a5e80d498ea02d15d244eb8b16")
