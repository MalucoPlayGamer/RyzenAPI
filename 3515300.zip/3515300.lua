-- Lua provided by RyzenAPI
-- Game: Game: AppID 3515300

-- MAIN APPLICATION
addappid(3515300)
-- Game: addappid(3515300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515301, 1, "59071662a90b57130d239206bc924f6d8792cde7832be5bb103791c8abc761fb")
