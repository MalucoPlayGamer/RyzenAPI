-- Lua provided by SkyAPI 
-- Game: AppID 3177420
addappid(3177420)
addappid(3177421, 1, "f290551faf23e5f51e530acee2a945cc540df7d84dee4d0f380a51e7462b1a5a")
