-- Lua provided by RyzenAPI
-- Game: 3177420

-- MAIN APPLICATION
addappid(3177420)
-- Game: addappid(3177420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3177421, 1, "f290551faf23e5f51e530acee2a945cc540df7d84dee4d0f380a51e7462b1a5a")
