-- Lua provided by RyzenAPI
-- Game: 2193690

-- MAIN APPLICATION
addappid(2193690)
-- Game: addappid(2193690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193691, 1, "6ce5f1ea2b775482d1c4676b8b57e1c2e821395e9c24e7f662a25edf23b2482b")
