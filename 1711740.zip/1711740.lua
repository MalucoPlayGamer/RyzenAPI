-- Lua provided by RyzenAPI
-- Game: Cheftastic!: Buffet Blast

-- MAIN APPLICATION
addappid(1711740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1711741, 1, "dd697305ef29173627f6982ad8176a5be79ec8533f7ea5a27f2b1511370125c4")

