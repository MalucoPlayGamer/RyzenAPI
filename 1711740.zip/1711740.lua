-- Lua provided by RyzenAPI
-- Game: Cheftastic!: Buffet Blast

-- MAIN APPLICATION
addappid(1711740)
-- Game: addappid(1711740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711741, 1, "dd697305ef29173627f6982ad8176a5be79ec8533f7ea5a27f2b1511370125c4")
