-- Lua provided by RyzenAPI
-- Game: Game: The Red Beret 红色贝雷帽

-- MAIN APPLICATION
addappid(2532720)
-- Game: addappid(2532720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532721, 1, "46e75f2f2feb298081e2461d22e3fa854e8faa18ee0f45844255c3a3a300c823")
