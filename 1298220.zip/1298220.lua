-- Lua provided by RyzenAPI
-- Game: Hoop Gawds

-- MAIN APPLICATION
addappid(1298220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298221, 1, "c6e5056ac6b49e22d25e4f085640db69ee700668a5c30b99d10f468fd8ac4151")
