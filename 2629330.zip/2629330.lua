-- Lua provided by RyzenAPI
-- Game: addappid(2629330)

-- MAIN APPLICATION
addappid(2629330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629331, 1, "d2831c1e6fed8fe69c7e3096fb154ddff4f5cea5fb8280b112bc857a3ea2b125")
addappid(3120480, 0, "2f27d3343268518cfd4506262f34d4b0ff0f7377c6b1d82fc78db4c1c18c2a1d")
