-- Lua provided by RyzenAPI
-- Game: addappid(2746580)

-- MAIN APPLICATION
addappid(2746580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746581, 1, "6a0dd248f36c4bd5b767305bbd830d1b89e5c63213a37fe607a930695e0ab948")
