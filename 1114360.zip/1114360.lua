-- Lua provided by RyzenAPI 
-- Game: Hentai Inumimi
addappid(1114360)
addappid(1114361, 1, "c50dc719c72cfe68eb5c616ed8d0544085ad0c07515a2a1f260309c647247406")
