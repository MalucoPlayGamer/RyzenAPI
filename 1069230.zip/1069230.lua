-- Lua provided by RyzenAPI
-- Game: 月影魅像-解放之羽-

-- MAIN APPLICATION
addappid(1069230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1069231, 1, "9167766df0b94d42754502d5fa0d3c53e99aacbae1a09a0528a908235aea28de")
addappid(1069232, 1, "39082ac36c26edd80cb5c4ed75132cd5ce8fe2764398ea76f9c9e7b5da8cff9d")
addappid(1069233, 1, "fefd05371e9bf335bd72eca251f5cc6ea566929b7da94bac92dae47c18dca04c")

