-- Lua provided by RyzenAPI 
-- Game: AppID 454480
addappid(454480)
addappid(454481, 1, "229c57e2a71ec536003d3b2e598c07ec97fad7d3404c0c9acbbeff943d5ae163")
