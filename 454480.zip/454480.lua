-- Lua provided by RyzenAPI
-- Game: AppID 454480

-- MAIN APPLICATION
addappid(454480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(454481, 1, "229c57e2a71ec536003d3b2e598c07ec97fad7d3404c0c9acbbeff943d5ae163")

