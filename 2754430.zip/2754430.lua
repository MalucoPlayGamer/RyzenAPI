-- Lua provided by RyzenAPI
-- Game: Cardinal Chains Demo

-- MAIN APPLICATION
addappid(2754430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754432,0,"27a1046265cc57067b6f1109e7d891121ec82e7fa48f5cf836d9b201ef6c9875")

