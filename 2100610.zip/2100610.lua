-- Lua provided by RyzenAPI
-- Game: Southern Princesses - Artbook 18+

-- MAIN APPLICATION
addappid(2100610)
-- Game: addappid(2100610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100610,0,"74841151245a563b1dbfcab7b05903bf480b81ed186f4fd32f284c7c1f9d9e0f")
