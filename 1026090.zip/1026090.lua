-- Lua provided by RyzenAPI
-- Game: Invasher - Original Soundtrack

-- MAIN APPLICATION
addappid(1026090)
-- Game: addappid(1026090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026090,0,"d6edbc44d1ef2d272e520aa57adbc703e5ae8525e224fe96c2f636cd5c269d27")
