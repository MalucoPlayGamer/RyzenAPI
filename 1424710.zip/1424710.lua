-- Lua provided by RyzenAPI
-- Game: Geneforge 1 - Mutagen

-- MAIN APPLICATION
addappid(1424710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424711, 1, "1c1c87d069b2563db7a498f9928ce16e72f69a0a4a2698ad327824a379094b8e")
addappid(1530080, 0, "177156bb308177d4beb9d5fec58a938779950a4ada3907b312c15f2d717acc1d")

