-- Lua provided by RyzenAPI
-- Game: King's Bounty: Crossworlds

-- MAIN APPLICATION
addappid(63910)

-- MAIN APP DEPOTS / PACKAGES
addappid(63911, 1, "7fb6bc4358856113db53a14e0272c47787b925e106c8cd3db44ea2c98e2e4b21")
addappid(63912, 1, "92c67afcdca1ce026d46e83cb5f8d1cc52b1c16bba24d0b1f3073aa67aa7f1e3")
addappid(63913, 1, "b966bdc6b03ac5a261fd1a4a600d9c8c40b1325c7a5d65628482d01c03a933e0")
addappid(63914, 1, "3e794e046ba22c593afce23b535b23f3540d24871038ddfec3b32e8ebe8a80bc")
addappid(63915, 1, "a3fb4c7247f995025197139d2bf49e55cd55628d422dc72671709146494d0558")
addappid(63916, 1, "acb11265cdb4df36cf4e4e325ed6ef03bf1fa833b6c77625fecf0963f4f77e0c")
addappid(63917, 1, "0f91a3d3fdecf9d08cbf28b1ad74c676cc991290d64febdf31f7d40a39252cf7")
addappid(63918, 1, "e80c69de8603ce52b217d30b2a67a8525ae38aa4e6a1e575791fe59973b3c430")

