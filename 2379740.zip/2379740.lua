-- Lua provided by RyzenAPI
-- Game: Wizardry Variants Daphne

-- MAIN APPLICATION
addappid(2379740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379741, 1, "AE9A68BB7EEC87F9082C29AE4D1654FBDB4F6B8BB234AFD42A1D21191D813EA9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
