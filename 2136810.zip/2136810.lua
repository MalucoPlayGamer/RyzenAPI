-- Lua provided by RyzenAPI
-- Game: Jam Above Jam Below

-- MAIN APPLICATION
addappid(2136810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136811, 1, "d5f2a0eeb440a071e78579217401433a841e41d3c53e324a43ae298a9280296a")

