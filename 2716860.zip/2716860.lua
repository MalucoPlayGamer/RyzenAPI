-- Lua provided by RyzenAPI 
-- Game: Wings of Seduction Original Soundtrack
addappid(2716860)
addappid(2716861, 1, "9f0fde020bb92dbbbb0a97db1767a72338624843281fc8fce09dd3a11607d491")
addappid(2716862, 1, "1cd171f38a2a8da49e67789b16f97ef02b073f80e61e73ec02c091445d392c03")
