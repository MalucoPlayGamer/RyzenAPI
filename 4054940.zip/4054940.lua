-- 4054940's Lua and Manifest Created by Hubcap Manifest
-- Return to Dark Castle
-- Created: August 04, 2026 at 22:45:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4054940, 1, "948f3d1f2106b2ae6336c2540cf36faf839ffd62ed2451089b03226efeacfbef") -- Return to Dark Castle
-- MAIN APP DEPOTS
addappid(4054941, 1, "de24a6e224909ecdebb6af411ce27283dc512e0173227b46429693274aa1162d") -- Depot 4054941
setManifestid(4054941, "4917773112986284276", 247958096)
addappid(4054942, 1, "e6314fa1bd21d8d067a2238bddbde5bc52957f512aaf405a188c3ccf19c4012b") -- Depot 4054942
setManifestid(4054942, "4062635739906912696", 337751972)
addappid(4054943, 1, "61845d9b81cde83a8e2534dad1bf66f53e38e0fa56cf4d2b2f8c2a28b181a829") -- Depot 4054943
setManifestid(4054943, "3071474252006914666", 279130976)