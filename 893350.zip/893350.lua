-- Lua provided by RyzenAPI
-- Game: Malfortune

-- MAIN APPLICATION
addappid(893350)

-- MAIN APP DEPOTS / PACKAGES
addappid(893351, 1, "b90ab97685983fbd15d90b9776d3ac6b02f9e228596b82f863d148704906a01c")
