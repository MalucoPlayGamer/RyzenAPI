-- Lua provided by RyzenAPI
-- Game: Rag Doll Kung Fu

-- MAIN APPLICATION
addappid(1002)
-- Game: addappid(1002)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000,0,"2493380d1b7607e54439bfea560a5384b2f7e7a8b8cf9934fd1abd50286982c1")
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
