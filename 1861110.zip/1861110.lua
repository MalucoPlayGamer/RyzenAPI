-- Lua provided by RyzenAPI
-- Game: BLOCKY.GO!

-- MAIN APPLICATION
addappid(1861110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861111, 1, "e815da9b70164f1ce6bca448ff2de331bb0ef74348ee90193bfd3e3257926ebe")
