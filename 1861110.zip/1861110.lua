-- Lua provided by SkyAPI 
-- Game: BLOCKY.GO!
addappid(1861110)
addappid(1861111, 1, "e815da9b70164f1ce6bca448ff2de331bb0ef74348ee90193bfd3e3257926ebe")
