-- Lua provided by RyzenAPI
-- Game: BLOCKY.GO!

-- MAIN APPLICATION
addappid(1861110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861111, 1, "e815da9b70164f1ce6bca448ff2de331bb0ef74348ee90193bfd3e3257926ebe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
