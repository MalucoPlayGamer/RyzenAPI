-- Lua provided by RyzenAPI
-- Game: Santa Sling

-- MAIN APPLICATION
addappid(571050)

-- MAIN APP DEPOTS / PACKAGES
addappid(571051,0,"0ea8d941f70133b8d711929c1ee2edf50e4c30d78d7cb05b775e5627ec4287b2")

