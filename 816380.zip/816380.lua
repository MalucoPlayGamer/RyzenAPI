-- Lua provided by RyzenAPI
-- Game: addappid(816380)

-- MAIN APPLICATION
addappid(816380)
addappid(817240)

-- MAIN APP DEPOTS / PACKAGES
addappid(816381, 1, "e6d434afb0627011c05392dbde1916c66d1a21d72d0b807c33c26766dac3186c")
