-- Lua provided by SkyAPI 
-- Game: Military Tanks
addappid(2342030)
addappid(2342031, 1, "77827acb77330e8df7c918d66abe8f654daa9cdbb087d28055e118fe181ecd1d")
addappid(2342032, 1, "02dfcf6d842039d2a8ba2de9ab73e15a139233a305d00f3da91af3d594a47f8a")
