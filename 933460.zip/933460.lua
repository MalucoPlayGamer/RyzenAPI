-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Bonus Mount Pegasus

-- MAIN APPLICATION
addappid(933460)
-- Game: addappid(933460)

-- MAIN APP DEPOTS / PACKAGES
addappid(933460,0,"0735b7dea9b8a7ff6197e94c90d822d6cfd7a9ea2fc6700517747264b2b0daf1")
addtoken(933460,9279609088275084154)
