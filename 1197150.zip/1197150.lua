-- Lua provided by RyzenAPI
-- Game: Game: Em-A-Li

-- MAIN APPLICATION
addappid(1197150)
-- Game: addappid(1197150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197151, 1, "3ded8a88bb5d1e1766436787697b168059937f1b51e408f5b00a557673b2f371")
