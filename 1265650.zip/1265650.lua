-- Lua provided by RyzenAPI
-- Game: The Drained Goddess

-- MAIN APPLICATION
addappid(1265650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265651, 1, "079533b3e1f4514322b8b9ab643299317084ebe7fbd8179d291fcfd0be3939fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
