-- Lua provided by RyzenAPI
-- Game: Stonewall Penitentiary

-- MAIN APPLICATION
addappid(833990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(833991,0,"8f0e3aab693502f86363e739eb6fd24de6a9ae7084c4a33615289cfa4388028a")

