-- Lua provided by RyzenAPI
-- Game: Stonewall Penitentiary

-- MAIN APPLICATION
addappid(833990)

-- MAIN APP DEPOTS / PACKAGES
addappid(833991,0,"8f0e3aab693502f86363e739eb6fd24de6a9ae7084c4a33615289cfa4388028a")

