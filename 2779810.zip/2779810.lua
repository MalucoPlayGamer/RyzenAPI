-- Lua provided by RyzenAPI
-- Game: Supermarket Simulator Demo

-- MAIN APPLICATION
addappid(2779810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779811, 1, "ff585585f7d2fa6ffcfeb4250e5a5af6b35579b08fa0fa72ed240c685db4a324")
