-- Lua provided by RyzenAPI
-- Game: RC Simulation 2.0

-- MAIN APPLICATION
addappid(381750)

-- MAIN APP DEPOTS / PACKAGES
addappid(381751, 1, "c7853d2c600379fe02db8e1acafeb7201d6f8a19cc376f2cda2b5742914fc38e")
addappid(381752, 1, "d47579cef5afae3bb1bc0623dd275a72e770530ed1d846e7f6b238f69f22a433")
addappid(381753, 1, "d4156e132126c0f016be6194e150be2e419e89d360b8763f7e2c3dded40d4329")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
