-- Lua provided by RyzenAPI
-- Game: Game: RC Simulation 2.0

-- MAIN APPLICATION
addappid(381750)
-- Game: addappid(381750)

-- MAIN APP DEPOTS / PACKAGES
addappid(381751, 1, "c7853d2c600379fe02db8e1acafeb7201d6f8a19cc376f2cda2b5742914fc38e")
addappid(381752, 1, "d47579cef5afae3bb1bc0623dd275a72e770530ed1d846e7f6b238f69f22a433")
addappid(381753, 1, "d4156e132126c0f016be6194e150be2e419e89d360b8763f7e2c3dded40d4329")
