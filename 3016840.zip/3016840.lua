-- Lua provided by RyzenAPI
-- Game: I Am Cat

-- MAIN APPLICATION
addappid(3016840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016842,0,"3d7444d482bcbf25c3b9c9a5c2ffd579f296091057a48c85a9bf8e96d356be2a")
