-- Lua provided by RyzenAPI
-- Game: AppID 1131620

-- MAIN APPLICATION
addappid(1131620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131621, 1, "6025a3a3c1a8aacc781cdcbc1063945965429f1456d11c2c817449cf28ac1ea0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1581510)
addappid(1581511)
addappid(1581512)
addappid(1581513)
addappid(1581514)
addappid(1581515)
addappid(1581516)
addappid(1581517)
addappid(1581518)
addappid(1581519)
addappid(1581520)
addappid(1581521)
addappid(1581522)
addappid(1736990)
addappid(1736991)
addappid(1736992)
addappid(1736993)
addappid(1736994)
addappid(1830090)
addappid(1982390)
addappid(1983460)
addappid(2019910)
addappid(2019911)
addappid(2019912)
addappid(2019913)
addappid(2136670)
addappid(2845870)
addappid(2845880)
addappid(2845890)
addappid(2845900)
addappid(2987310)
addappid(4336870)
