-- Lua provided by RyzenAPI
-- Game: 1131620

-- MAIN APPLICATION
addappid(1131620)
-- Game: addappid(1131620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131621, 1, "6025a3a3c1a8aacc781cdcbc1063945965429f1456d11c2c817449cf28ac1ea0")
