-- Lua provided by RyzenAPI 
-- Game: Crazy Shipping
addappid(3254840)
addappid(3254841, 1, "2f5ab121427d80ab6052ba31fa9d0735e00a4c26ca0606d4bf10dc04574203aa")
