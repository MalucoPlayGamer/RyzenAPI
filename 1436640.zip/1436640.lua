-- Lua provided by RyzenAPI
-- Game: 6-7

-- MAIN APPLICATION
addappid(1436640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436642,0,"bbeda45638d039f59c03e04209e769f48e90a1b4fccd3feee641fe7d09f0af0f")
