-- Lua provided by RyzenAPI
-- Game: Pixelpart

-- MAIN APPLICATION
addappid(1734820)
-- Game: addappid(1734820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734821, 1, "4a2d61abdf4d41d5765d3ec5f6a48897bb289ba097593826e2c6d3e9bd970b7c")
