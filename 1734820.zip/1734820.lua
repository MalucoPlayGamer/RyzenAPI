-- Lua provided by SkyAPI 
-- Game: Pixelpart
addappid(1734820)
addappid(1734821, 1, "4a2d61abdf4d41d5765d3ec5f6a48897bb289ba097593826e2c6d3e9bd970b7c")
