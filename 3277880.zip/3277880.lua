-- Lua provided by RyzenAPI
-- Game: Warped Universe

-- MAIN APPLICATION
addappid(3277880)
