-- Lua provided by RyzenAPI
-- Game: Multi Turret Academy DEMO

-- MAIN APPLICATION
addappid(2609060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2609061, 1, "99b5a34c43bda14b2cb4cd8dad3e2a734ea1d9febb49a7c4ed106ed2e2997bfa")
