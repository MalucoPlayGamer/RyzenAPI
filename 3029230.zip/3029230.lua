-- Lua provided by RyzenAPI 
-- Game: Epstein 2
addappid(3029230)
addappid(3029231, 1, "1aeab16bf505bae414a2a7073b6ab774ee632fa8d982f7003b487ac886ec4729")
