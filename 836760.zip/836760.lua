-- Lua provided by RyzenAPI
-- Game: Sorcery Saga: Curse of the Great Curry God

-- MAIN APPLICATION
addappid(836760)
addappid(844240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(836761, 1, "16ca3328a48a2fe336f1055673999c5c1fee134be53aac91560e1983f4dd0d9b")

