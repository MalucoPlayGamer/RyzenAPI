-- Lua provided by RyzenAPI
-- Game: Sorcery Saga: Curse of the Great Curry God

-- MAIN APPLICATION
addappid(836760)
addappid(844240)
-- Game: addappid(836760)

-- MAIN APP DEPOTS / PACKAGES
addappid(836761, 1, "16ca3328a48a2fe336f1055673999c5c1fee134be53aac91560e1983f4dd0d9b")
