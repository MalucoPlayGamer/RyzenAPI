-- Lua provided by RyzenAPI
-- Game: addappid(1116280)

-- MAIN APPLICATION
addappid(1116280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116282,0,"cd2d65d5f62aa524af321cd51778e6546ea9a3c54ac5db50fd95a26bbf14097e")
addappid(1116283,0,"aac0ceb7c7ca65b6b0e2d1736edf95603d1850fe36dadee0bab682b1d9511bd2")
