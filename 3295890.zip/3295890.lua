-- Lua provided by SkyAPI 
-- Game: PARKOUR CIVILIZATION
addappid(3295890)
addappid(3295891, 1, "62892017873d807c57ee7ad087ad42da344d4f7eaa4c4dc99c1dc48fc42973b9")
