-- Lua provided by RyzenAPI
-- Game: Game: PARKOUR CIVILIZATION

-- MAIN APPLICATION
addappid(3295890)
-- Game: addappid(3295890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3295891, 1, "62892017873d807c57ee7ad087ad42da344d4f7eaa4c4dc99c1dc48fc42973b9")
