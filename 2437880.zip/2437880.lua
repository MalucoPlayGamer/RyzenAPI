-- Lua provided by RyzenAPI
-- Game: 2437880

-- MAIN APPLICATION
addappid(2437880)
-- Game: addappid(2437880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437881, 1, "a1219d6c8cdb271d0bcb07e992645f5c743f0d17e898f195c2394228ccaee92b")
