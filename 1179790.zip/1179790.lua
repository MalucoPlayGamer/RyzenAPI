-- Lua provided by RyzenAPI
-- Game: Game: AppID 1179790

-- MAIN APPLICATION
addappid(1179790)
-- Game: addappid(1179790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179791, 1, "ee914a91d28c504fde7ae9ae595de7c5742b1c222564ceae334a6db1a321da06")
