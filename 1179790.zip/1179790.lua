-- Lua provided by SkyAPI 
-- Game: AppID 1179790
addappid(1179790)
addappid(1179791, 1, "ee914a91d28c504fde7ae9ae595de7c5742b1c222564ceae334a6db1a321da06")
