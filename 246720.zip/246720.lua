-- Lua provided by RyzenAPI
-- Game: Wayward Manor

-- MAIN APPLICATION
addappid(246720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(246721, 1, "a481b053907e2586760ff2dec3358f3ec33c3e96dd15b844c2d558be359b9fb5")

