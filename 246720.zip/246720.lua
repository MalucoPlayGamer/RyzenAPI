-- Lua provided by RyzenAPI
-- Game: addappid(246720)

-- MAIN APPLICATION
addappid(246720)

-- MAIN APP DEPOTS / PACKAGES
addappid(246721, 1, "a481b053907e2586760ff2dec3358f3ec33c3e96dd15b844c2d558be359b9fb5")
