-- Lua provided by RyzenAPI
-- Game: 1575450

-- MAIN APPLICATION
addappid(1575450)
addappid(1836270)
-- Game: addappid(1575450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575451, 1, "4ce2ae447f20643e8dca1250805083098483e8d2b999c1da8922325e9ee3671d")
