-- Lua provided by RyzenAPI
-- Game: Game: AppID 237530

-- MAIN APPLICATION
addappid(237530)
-- Game: addappid(237530)

-- MAIN APP DEPOTS / PACKAGES
addappid(237531, 1, "082ca5a9ada801d1b9d4995253580c7c75ada4ad48aba060a49d01268b923c79")
addappid(237532, 1, "be26f91413a4429bfae86e610ab5f06dd70020fd49f767b2caac189207555515")
addappid(237533, 1, "3d275d8ae6f4c76b43eef855cca2a8f6b9abc7f2a8512b6975c77942526ce7d2")
