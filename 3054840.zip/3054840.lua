-- Lua provided by RyzenAPI
-- Game: Cities: Skylines II - Jade Road Radio

-- MAIN APPLICATION
addappid(3054840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054840,0,"02aead37a548fa148998bd2698389d9b497ba84680d8a1ca3116bb3c79208415")
