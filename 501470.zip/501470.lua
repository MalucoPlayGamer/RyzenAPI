-- Lua provided by RyzenAPI
-- Game: Game: Hold the door!

-- MAIN APPLICATION
addappid(501470)
-- Game: addappid(501470)

-- MAIN APP DEPOTS / PACKAGES
addappid(501471, 1, "743c1b938b5c99e65da7c35d8eedfe319e9823bd090bec520024505f738d8fe9")
