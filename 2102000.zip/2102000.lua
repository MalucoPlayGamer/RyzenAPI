-- Lua provided by RyzenAPI
-- Game: addappid(2102000)

-- MAIN APPLICATION
addappid(2102000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102002,0,"430abd9f46494515e93caedecff6f23cad85d1c9765dd52e855e9b8e72339802")
