-- Lua provided by RyzenAPI
-- Game: Another Crab's Treasure

-- MAIN APPLICATION
addappid(1887840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887841, 1, "19257cfc9a0b90cd9687a6893dbd234efcbb0cab05776a8180a2a49a271cccad")
