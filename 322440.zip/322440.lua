-- Lua provided by RyzenAPI
-- Game: Red Goddess: Inner World

-- MAIN APPLICATION
addappid(322440)

-- MAIN APP DEPOTS / PACKAGES
addappid(322441, 1, "4fe45bc5c950ee2c25e10e2a1ca4d4eb1b16540351734a43a8ccca9f83927309")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(390590)
