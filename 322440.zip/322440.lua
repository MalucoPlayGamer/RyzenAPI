-- Lua provided by RyzenAPI
-- Game: Game: Red Goddess: Inner World

-- MAIN APPLICATION
addappid(322440)
-- Game: addappid(322440)

-- MAIN APP DEPOTS / PACKAGES
addappid(322441, 1, "4fe45bc5c950ee2c25e10e2a1ca4d4eb1b16540351734a43a8ccca9f83927309")
