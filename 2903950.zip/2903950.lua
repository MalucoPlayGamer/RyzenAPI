-- Lua provided by RyzenAPI
-- Game: Master Detective Archives: RAIN CODE Plus

-- MAIN APPLICATION
addappid(2903950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903951, 1, "a12bd5bdeb914bcfc0be723089d2e8765ae48f4c1ebf378f37da0ba758b6c6c3")
