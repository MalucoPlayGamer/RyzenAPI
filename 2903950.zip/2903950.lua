-- Lua provided by RyzenAPI
-- Game: Master Detective Archives: RAIN CODE Plus

-- MAIN APPLICATION
addappid(2903950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903951, 1, "a12bd5bdeb914bcfc0be723089d2e8765ae48f4c1ebf378f37da0ba758b6c6c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2903990)
