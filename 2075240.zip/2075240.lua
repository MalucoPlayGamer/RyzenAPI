-- Lua provided by RyzenAPI
-- Game: addappid(2075240)

-- MAIN APPLICATION
addappid(2075240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075241, 1, "8dd46e217e85c7454d8b6be58d0805a55e36bcfc5d223e5625d9f997afdbff25")
