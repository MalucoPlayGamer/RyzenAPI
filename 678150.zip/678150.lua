-- Lua provided by RyzenAPI
-- Game: JMPR

-- MAIN APPLICATION
addappid(678150)

-- MAIN APP DEPOTS / PACKAGES
addappid(678151,0,"b3fb81294e5a2d50b2b9718ef92193d9f122a0416ab0a8d0b732fce9a1a9ca9f")

