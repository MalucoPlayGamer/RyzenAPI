-- Lua provided by RyzenAPI
-- Game: Operation Breakout

-- MAIN APPLICATION
addappid(546660)

-- MAIN APP DEPOTS / PACKAGES
addappid(546661, 1, "9568df5437026f988043644176a468f22605e0054313fd75ebe245603af27acb")

