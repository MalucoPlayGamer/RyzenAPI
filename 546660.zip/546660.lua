-- Lua provided by RyzenAPI
-- Game: Operation Breakout

-- MAIN APPLICATION
addappid(546660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(546661, 1, "9568df5437026f988043644176a468f22605e0054313fd75ebe245603af27acb")

