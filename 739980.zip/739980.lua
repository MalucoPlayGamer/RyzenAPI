-- Lua provided by RyzenAPI
-- Game: Let`s not stay friends

-- MAIN APPLICATION
addappid(739980)

-- MAIN APP DEPOTS / PACKAGES
addappid(739981, 1, "fd4b370fef9d4c4d506e400f14f374e9941c17ea92259b241574cf0d5fe91907")

