-- Lua provided by RyzenAPI 
-- Game: My Vow to My Liege
addappid(1146970)
addappid(1146971, 1, "9dfce3ea079be71a5cb4eb27b35ca5abe40d0d1100b4a456497b1dae4e012fd5")
addappid(1146972, 1, "0f767ea5222fbf7b432092c8021f386a7fbf38ac7c6033c0c199a9ff4b07dd08")
addappid(1146973, 1, "67ef239c07154b34d76cc6876f5a381828eb12bd52afc7e2770d6ff7d181e5ab")
addappid(1146974, 1, "6c03132c24d891f8372aa247d04ac82da68232618cd011750846c3ed0ba68e1d")
