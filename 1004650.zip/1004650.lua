-- Lua provided by RyzenAPI
-- Game: Game: AppID 1004650

-- MAIN APPLICATION
addappid(1004650)
addappid(1032780)
-- Game: addappid(1004650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004651, 1, "c10fb4172f18f0af5f1aab218f8b27184eccc221869e3b10aa85a590f806d807")
