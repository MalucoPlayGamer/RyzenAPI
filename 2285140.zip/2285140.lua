-- Lua provided by RyzenAPI
-- Game: 瞬忆

-- MAIN APPLICATION
addappid(2285140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285141, 1, "67be58e49dd72de4c6a0df6486bc435f3229fd3e56de0d6c9566b921b2df9f3d")

