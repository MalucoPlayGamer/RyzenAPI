-- Lua provided by RyzenAPI 
-- Game: 瞬忆
addappid(2285140)
addappid(2285141, 1, "67be58e49dd72de4c6a0df6486bc435f3229fd3e56de0d6c9566b921b2df9f3d")
