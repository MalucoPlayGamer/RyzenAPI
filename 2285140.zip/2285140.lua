-- Lua provided by RyzenAPI
-- Game: 瞬忆

-- MAIN APPLICATION
addappid(2285140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285141, 1, "67be58e49dd72de4c6a0df6486bc435f3229fd3e56de0d6c9566b921b2df9f3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
