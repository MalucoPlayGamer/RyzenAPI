-- Lua provided by RyzenAPI
-- Game: Hellbreaker

-- MAIN APPLICATION
addappid(793620)

-- MAIN APP DEPOTS / PACKAGES
addappid(793621, 1, "7c42806885348e8c8e9429cd54e4cdcbb89639ef56e13961ce6c3f67e7168d05")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
