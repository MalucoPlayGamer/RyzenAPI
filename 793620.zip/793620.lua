-- Lua provided by RyzenAPI
-- Game: Hellbreaker

-- MAIN APPLICATION
addappid(793620)

-- MAIN APP DEPOTS / PACKAGES
addappid(793621, 1, "7c42806885348e8c8e9429cd54e4cdcbb89639ef56e13961ce6c3f67e7168d05")
