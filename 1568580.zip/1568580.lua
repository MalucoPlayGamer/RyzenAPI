-- Lua provided by RyzenAPI
-- Game: 1568580

-- MAIN APPLICATION
addappid(1568580)
-- Game: addappid(1568580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568581, 1, "75145a60fb7e7ff66191eb04f375dd38d6958fa66311e8cb40fc531507648e1f")
