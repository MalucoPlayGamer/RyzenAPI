-- Lua provided by RyzenAPI
-- Game: addappid(2725090)

-- MAIN APPLICATION
addappid(2725090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725091, 1, "50bf85ebe948732ee306f5fc8169a642d8a2376b83f7dd869c44f8aae47e5968")
