-- Lua provided by RyzenAPI
-- Game: 253230

-- MAIN APPLICATION
addappid(253230)
addappid(356830)
-- Game: addappid(253230)

-- MAIN APP DEPOTS / PACKAGES
addappid(253231, 1, "bad6cfa1002a435782d44a7814659ee3c3621b2c2fafc625c5d17cd7e621f11b")
addappid(253232, 1, "f15a83ed51eec3d6335d9bea61d26d27c28baecc34c2f3c1f2815ec8382d53d3")
addappid(253233, 1, "93fb8cd74e500480e7c3633727875b4a205c1b5965be9c17056e7ad30d5a95d1")
addappid(1072430, 0, "d87ead7e6dacbeb528482d239ef60f3cc36e31ca816dc1bc64a7740be574b18f")
