-- Lua provided by RyzenAPI
-- Game: A Hat in Time

-- MAIN APPLICATION
addappid(253230)
addappid(356830)
addappid(787340)
addappid(924490)
addappid(940220)
addappid(1545960)
addappid(1550140)
addappid(1550141)
addappid(1550142)
addappid(1738980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(253231, 1, "bad6cfa1002a435782d44a7814659ee3c3621b2c2fafc625c5d17cd7e621f11b")
addappid(253232, 1, "f15a83ed51eec3d6335d9bea61d26d27c28baecc34c2f3c1f2815ec8382d53d3")
addappid(253233, 1, "93fb8cd74e500480e7c3633727875b4a205c1b5965be9c17056e7ad30d5a95d1")
addappid(1072430, 0, "d87ead7e6dacbeb528482d239ef60f3cc36e31ca816dc1bc64a7740be574b18f")
