-- Lua provided by RyzenAPI 
-- Game: AppID 1264280
addappid(1264280)
addappid(1264281, 1, "c6f30f391d892cff62283e848ea9368dad8ebb8658ffb599246c61311023df03")
addappid(1264282, 1, "b7fef56f1caa5a060d7a34ddeb10e5da9d151c7ed2244e1ef0c32224cbf9b240")
