-- Lua provided by RyzenAPI
-- Game: Slipways

-- MAIN APPLICATION
addappid(1264280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1264281, 1, "c6f30f391d892cff62283e848ea9368dad8ebb8658ffb599246c61311023df03")
addappid(1264282, 1, "b7fef56f1caa5a060d7a34ddeb10e5da9d151c7ed2244e1ef0c32224cbf9b240")
