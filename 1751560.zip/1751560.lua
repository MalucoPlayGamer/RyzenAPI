-- Lua provided by RyzenAPI
-- Game: Magurele Mystery

-- MAIN APPLICATION
addappid(1751560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751561, 1, "7e937fecc5612223716a940dc31cd6f16a287f3ab0b2329604a3fb52a99fc680")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
