-- Lua provided by RyzenAPI
-- Game: Art of Beauties

-- MAIN APPLICATION
addappid(1189360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189361, 1, "46b5c7091acfe904a50c51d60bcb724731069ea3f23e62057728c7d32f0bd81d")
