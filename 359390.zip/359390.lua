-- Lua provided by RyzenAPI
-- Game: Amnesia™: Memories

-- MAIN APPLICATION
addappid(359390)

-- MAIN APP DEPOTS / PACKAGES
addappid(359392,0,"45bb7b0593c6e18a971e511a2546db07f73657d1654f4cc68932bac172774640")
