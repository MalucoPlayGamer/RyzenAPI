-- Lua provided by RyzenAPI
-- Game: 3116830

-- MAIN APPLICATION
addappid(3116830)
-- Game: addappid(3116830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116831, 1, "218c9ddf0e775f6fbd51263cf0b391eecefb12316de4164723765dc2b5a8bdb3")
