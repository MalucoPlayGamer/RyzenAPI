-- Lua provided by RyzenAPI
-- Game: Cornflakestein

-- MAIN APPLICATION
addappid(728890)

-- MAIN APP DEPOTS / PACKAGES
addappid(728891, 1, "720416de981baf71288d46d6522ed72c5534e0512952a6981731a777b998f5fe")

