-- Lua provided by RyzenAPI
-- Game: Selection Bias

-- MAIN APPLICATION
addappid(4875600) -- Selection Bias

-- MAIN APP DEPOTS / PACKAGES
addappid(4875601, 1, "0c85a45f84879c08ce37e61e187fb57f6b9b88e3c9af4011589aaa6dc8f18c9a") -- Depot 4875601
addappid(4875602, 1, "3176486fd52d5f26ee2567b0d3cde193e06ed253fe3ddcc38e930f317b5e4e1e") -- Depot 4875602

