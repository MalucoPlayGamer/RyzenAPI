-- Lua provided by SkyAPI 
-- Game: Knights of the Deep Demo
addappid(2125020)
addappid(2125021, 1, "df0ff6ecfabca955d7b78ee3b3edef65b3eace3158b26582b18d5787f164a891")
