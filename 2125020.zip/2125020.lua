-- Lua provided by RyzenAPI
-- Game: 2125020

-- MAIN APPLICATION
addappid(2125020)
-- Game: addappid(2125020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125021, 1, "df0ff6ecfabca955d7b78ee3b3edef65b3eace3158b26582b18d5787f164a891")
