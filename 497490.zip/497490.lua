-- Lua provided by RyzenAPI
-- Game: 497490

-- MAIN APPLICATION
addappid(497490)
-- Game: addappid(497490)

-- MAIN APP DEPOTS / PACKAGES
addappid(497491, 1, "6f9dbf8a1c69eb8c3201df37dc7220fc8a9c76173adc67f91327f427d409a329")
