-- Lua provided by RyzenAPI
-- Game: addappid(690420)

-- MAIN APPLICATION
addappid(690420)

-- MAIN APP DEPOTS / PACKAGES
addappid(690421, 1, "827c58dd542fd377ac0cad6e07c068793fe7d9bfd9dc67a0a48f72a65ba92239")
