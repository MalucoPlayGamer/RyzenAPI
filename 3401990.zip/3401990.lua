-- Lua provided by RyzenAPI
-- Game: Sexy Furry - Bear Furry DLC

-- MAIN APPLICATION
addappid(3401990)
-- Game: addappid(3401990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3401990,0,"507df9620232ae597362dc0d80c645f137499041773ac13a8d251acce9656738")
