-- Lua provided by RyzenAPI
-- Game: 3198820

-- MAIN APPLICATION
addappid(3198820)
-- Game: addappid(3198820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198821, 1, "2a9afe74dc6104bb62baeca15f68ebcfc64a67c5b9bcdc48c9a851fa3e3f00fe")
