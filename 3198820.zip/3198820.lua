-- Lua provided by SkyAPI 
-- Game: Passer
addappid(3198820)
addappid(3198821, 1, "2a9afe74dc6104bb62baeca15f68ebcfc64a67c5b9bcdc48c9a851fa3e3f00fe")
