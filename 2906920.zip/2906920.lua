-- Lua provided by RyzenAPI
-- Game: Eternal Fate: A Journey Begins

-- MAIN APPLICATION
addappid(2906920)
-- Game: addappid(2906920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906921, 1, "bc41d8a61ef1dd40270d57447bc90660bf2b2eda179ed67becdffcea8e959f34")
