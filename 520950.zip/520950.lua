-- Lua provided by SkyAPI 
-- Game: DRIFT CE
addappid(520950)
addappid(520951, 1, "f765fb867cf4362a65125d74cb2bc8e14d5efca8888a2212aad2e4ff48a24c3f")
addappid(2738250)
