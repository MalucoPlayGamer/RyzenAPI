-- Lua provided by RyzenAPI
-- Game: DRIFT CE

-- MAIN APPLICATION
addappid(520950)
addappid(2738250)

-- MAIN APP DEPOTS / PACKAGES
addappid(520951, 1, "f765fb867cf4362a65125d74cb2bc8e14d5efca8888a2212aad2e4ff48a24c3f")
