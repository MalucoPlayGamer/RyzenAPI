-- Lua provided by RyzenAPI
-- Game: Backrooms  #999999999 Demo

-- MAIN APPLICATION
addappid(3067860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3067861, 1, "ada87ff2c02cac6d1f5e773ba61da7841b7f392b2e53fa094c52d5e5d1054e41")
