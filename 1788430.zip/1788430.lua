-- Lua provided by RyzenAPI
-- Game: BOT.vinnik Chess: Late USSR Championships

-- MAIN APPLICATION
addappid(1788430)
-- Game: addappid(1788430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788431, 1, "9c2e1300cc7c99ce5a03de6affbd9e586ab6ee0f0b41e34925cd0ad43f080de2")
