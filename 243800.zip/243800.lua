-- Lua provided by RyzenAPI
-- Game: Gas Guzzlers Extreme

-- MAIN APPLICATION
addappid(243800)

-- MAIN APP DEPOTS / PACKAGES
addappid(243801, 1, "cae65bfd3eb6c2c8cdaeb9746efedf2f915b951ac62d2e1f17053126225e6362")
addappid(277820, 0, "8f62d5c6ac18d71b98858d8a96eea0ad9f3d8e9c59d08157fcba2c1794e8b5e7")
addappid(277821, 0, "3a0e30e08d85189a92912c33944c1b8f1c96ebb36d324bfde38434c2787601cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
