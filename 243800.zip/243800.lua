-- Lua provided by RyzenAPI
-- Game: Gas Guzzlers Extreme

-- MAIN APPLICATION
addappid(243800)
-- Game: addappid(243800)

-- MAIN APP DEPOTS / PACKAGES
addappid(243801, 1, "cae65bfd3eb6c2c8cdaeb9746efedf2f915b951ac62d2e1f17053126225e6362")
addappid(277820, 0, "8f62d5c6ac18d71b98858d8a96eea0ad9f3d8e9c59d08157fcba2c1794e8b5e7")
addappid(277821, 0, "3a0e30e08d85189a92912c33944c1b8f1c96ebb36d324bfde38434c2787601cb")
