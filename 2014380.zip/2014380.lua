-- Lua provided by RyzenAPI
-- Game: 2014380

-- MAIN APPLICATION
addappid(2014380)
-- Game: addappid(2014380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014381, 1, "7fda95293f7806c84dd40f809c1ec537ad42ad31989ceb136bd9815b627341d7")
