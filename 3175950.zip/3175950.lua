-- Lua provided by RyzenAPI
-- Game: Ezrebeth

-- MAIN APPLICATION
addappid(3175950)
-- Game: addappid(3175950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3175951, 1, "114d4c69dff64cc2fa0ab1c6d49efb132b5e3f1164294e38afcb37675e32332b")
