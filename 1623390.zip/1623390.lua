-- Lua provided by RyzenAPI
-- Game: addappid(1623390)

-- MAIN APPLICATION
addappid(1623390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623391, 1, "0d12358630256495cce04e5cae60390aec07ad25943c90c7a58f3563ef57c09a")
