-- Lua provided by RyzenAPI
-- Game: Unplugged

-- MAIN APPLICATION
addappid(1623390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623391, 1, "0d12358630256495cce04e5cae60390aec07ad25943c90c7a58f3563ef57c09a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1882210)
addappid(1882211)
