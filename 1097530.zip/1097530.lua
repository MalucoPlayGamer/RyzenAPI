-- Lua provided by RyzenAPI 
-- Game: AppID 1097530
addappid(1097530)
addappid(1097531, 1, "72d8e2f4f5187b5ff6484d0496f08563d77d790bf1e82880c92aecda42bcd672")
addappid(1097532, 1, "c8c332c1d621f7531ee2960cace3e13bb1891c0199dd67817b83fc8be56f8ff2")
