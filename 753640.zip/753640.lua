-- Lua provided by RyzenAPI
-- Game: 753640

-- MAIN APPLICATION
addappid(753640)
-- Game: addappid(753640)

-- MAIN APP DEPOTS / PACKAGES
addappid(753641, 1, "57452658900ae11ac7c0e91c17d64353fa62936759ca202f4ecbbc9f29cf4b60")
