-- Lua provided by RyzenAPI
-- Game: AppID 753640

-- MAIN APPLICATION
addappid(753640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(753641, 1, "57452658900ae11ac7c0e91c17d64353fa62936759ca202f4ecbbc9f29cf4b60")

