-- Lua provided by RyzenAPI
-- Game: Coin Pusher

-- MAIN APPLICATION
addappid(827420)

-- MAIN APP DEPOTS / PACKAGES
addappid(827421, 1, "6734a9139c04b48e8bebe419878da85c2eacfd817adb18890326943ae62d14e0")

