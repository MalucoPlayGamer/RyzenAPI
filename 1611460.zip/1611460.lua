-- Lua provided by RyzenAPI
-- Game: Hide and Run

-- MAIN APPLICATION
addappid(1611460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611461, 1, "0aaf6805e2d6db220f78af9713ab723bb780469f4711ff8fc419657932132395")

