-- Lua provided by RyzenAPI
-- Game: Tailbound - Deluxe Extras

-- MAIN APPLICATION
addappid(2130150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130150,0,"bf1d56c45c250105278c9326ecfcd59de393f16128e586b90d1de3cbd9490b3a")

