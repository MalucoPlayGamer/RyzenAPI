-- Lua provided by RyzenAPI
-- Game: addappid(3021090)

-- MAIN APPLICATION
addappid(3021090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021091, 1, "81e5df65742dc8c831e0e459904b4b123a52b5eabaa1f8ef89abecb9086398b6")
