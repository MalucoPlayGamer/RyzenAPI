-- 4386980's Lua and Manifest Created by Hubcap Manifest
-- Pro Soccer Manager 27
-- Created: August 29, 2026 at 00:58:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4386980, 1, "8b6b8e7576128927d333997f16da9dc424a0fa738ad9f0ba567820854eeec2ac") -- Pro Soccer Manager 27
-- MAIN APP DEPOTS
addappid(4386981, 1, "9129056da4db6e5cf7e62c174b5e93cc4d7f68819e4bda047190104468916d17") -- Depot 4386981
setManifestid(4386981, "5095775032725942189", 436570672)