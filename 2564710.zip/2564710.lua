-- Lua provided by RyzenAPI
-- Game: Green Hell Official Soundtrack

-- MAIN APPLICATION
addappid(2564710)
-- Game: addappid(2564710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564711, 1, "8e8b4f7a71597ed2490fd32c490c7a8e79ed9835e66fef328bd70c243c8bbbd3")
addappid(2564712, 1, "29594e10b2246ce527414b2f9811969fa7fff90bc8a0f2c1b019c0292918b1cf")
