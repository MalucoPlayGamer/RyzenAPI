-- Lua provided by RyzenAPI
-- Game: Girlfriend Experience VR

-- MAIN APPLICATION
addappid(922800)

-- MAIN APP DEPOTS / PACKAGES
addappid(922801, 1, "b75697d4462759c3baca15d44ae89a9c9b2231455f2b28bbe2848b4232023c37")
