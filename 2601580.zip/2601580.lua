-- Lua provided by RyzenAPI
-- Game: Paradise's Secrets

-- MAIN APPLICATION
addappid(2601580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601581, 1, "9b91b394e873db057c71a0965ce0bfb8c9500366cc14a7d5083407d534e198e5")
