-- Lua provided by SkyAPI 
-- Game: Paradise's Secrets
addappid(2601580)
addappid(2601581, 1, "9b91b394e873db057c71a0965ce0bfb8c9500366cc14a7d5083407d534e198e5")
