-- Lua provided by RyzenAPI
-- Game: 1187330

-- MAIN APPLICATION
addappid(1187330)
-- Game: addappid(1187330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187331, 1, "50a2ae885bf5123dd08b5929a0e6b59eb51abbd14181ca77183c1621e55e68f5")
