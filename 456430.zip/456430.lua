-- Lua provided by RyzenAPI
-- Game: addappid(456430)

-- MAIN APPLICATION
addappid(456430)

-- MAIN APP DEPOTS / PACKAGES
addappid(456431, 1, "5c202aea8433b24a40441b54289fcdc16547ce7ef7076366c054b52eebb76b6c")
