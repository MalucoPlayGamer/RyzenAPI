-- Lua provided by SkyAPI 
-- Game: Christmas Adventure: Candy Storm
addappid(456430)
addappid(456431, 1, "5c202aea8433b24a40441b54289fcdc16547ce7ef7076366c054b52eebb76b6c")
