-- Lua provided by RyzenAPI
-- Game: Hang Up

-- MAIN APPLICATION
addappid(950380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(950381, 1, "98e60b92b8569f7f421d470da049592d119a054b2b3e8dab50dcce9ea9fde721")

