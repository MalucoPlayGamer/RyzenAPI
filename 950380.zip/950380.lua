-- Lua provided by RyzenAPI
-- Game: 950380

-- MAIN APPLICATION
addappid(950380)
-- Game: addappid(950380)

-- MAIN APP DEPOTS / PACKAGES
addappid(950381, 1, "98e60b92b8569f7f421d470da049592d119a054b2b3e8dab50dcce9ea9fde721")
