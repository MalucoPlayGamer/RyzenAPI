-- Lua provided by RyzenAPI
-- Game: AppID 1447090

-- MAIN APPLICATION
addappid(1447090)
-- Game: addappid(1447090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447091, 1, "68eb9839fcac43f7f493596aa2585a16e070b117a81fe86aab2f6b8d740aa5e4")
