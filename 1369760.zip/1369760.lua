-- Lua provided by RyzenAPI
-- Game: NINJA GAIDEN 3: Razor's Edge [NINJA GAIDEN: Master Collection]

-- MAIN APPLICATION
addappid(1369760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1369761, 1, "8e26b35454815bf7383133f0c5cc84daf001cd94fecca3bc67dc5d29ee98008e")

