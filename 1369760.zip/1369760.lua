-- Lua provided by RyzenAPI
-- Game: NINJA GAIDEN 3: Razor's Edge [NINJA GAIDEN: Master Collection]

-- MAIN APPLICATION
addappid(1369760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369761, 1, "8e26b35454815bf7383133f0c5cc84daf001cd94fecca3bc67dc5d29ee98008e")
