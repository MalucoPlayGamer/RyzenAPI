-- Lua provided by RyzenAPI
-- Game: AppID 1034160

-- MAIN APPLICATION
addappid(1034160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034161, 1, "abbe712a4c13dabf49c248ce1dda871326bb5d9b5f01267f3ea71fab3b1857e3")

