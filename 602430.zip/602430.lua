-- Lua provided by RyzenAPI
-- Game: Game: Yono and the Celestial Elephants

-- MAIN APPLICATION
addappid(602430)
-- Game: addappid(602430)

-- MAIN APP DEPOTS / PACKAGES
addappid(602431, 1, "0925c3daf274a7b7f4eace50f9ea1aa634975d4d970a6f22dc53d09da1a38c68")
addappid(602432, 1, "9e526950ee0586d1c355580eca484d9cf9984627981b93d3afde874ffd7d214e")
addappid(602433, 1, "b800ce8146d18cd334c67ad739ce85541b8df95a9b81b198c32ce1c4dbf84ae5")
addappid(602434, 1, "64c0db5c95819c83a1164f2d368c8ff885853c50e8c3f6c73a5e62d922a12474")
addappid(602435, 1, "a04ccc47207343463e836a0a0a3588c71ae4d5dd73c3dc3238ad8f1ddd265706")
addappid(602436, 1, "b301e93e955927936d35162f8183b1fd1c915c34cfb045b42365a58e7d8e4d8a")
addappid(602437, 1, "de2ce3f5408fa2182d61db79cd0ede108afc64ffaf462597b56a9da209d131a8")
addappid(602438, 1, "8952655ceafce24e0187cd1c54db2f40d82925e4d5378982df2316a7da2dbbf5")
