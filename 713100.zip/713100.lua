-- Lua provided by RyzenAPI
-- Game: StockUp

-- MAIN APPLICATION
addappid(713100)

-- MAIN APP DEPOTS / PACKAGES
addappid(713101,0,"ab1db9526d4a4a2c020d11d13c96564fd97147ca4e9212379aa7c7a0663833bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
