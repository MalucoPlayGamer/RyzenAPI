-- Lua provided by RyzenAPI
-- Game: Achievement Hunter: Zombie 2

-- MAIN APPLICATION
addappid(790400)

-- MAIN APP DEPOTS / PACKAGES
addappid(790401, 1, "123e85c27417488a06a583705e52378a9d6e312b259af207f58268c7659fc4ea")
