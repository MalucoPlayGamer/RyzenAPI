-- Lua provided by RyzenAPI
-- Game: Expansion Core

-- MAIN APPLICATION
addappid(1891010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891011, 1, "d3155a3dbff96176fef56bdc083487f81d86e661572fde822c1fd07c2ffacba5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
