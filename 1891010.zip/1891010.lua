-- Lua provided by RyzenAPI
-- Game: Expansion Core

-- MAIN APPLICATION
addappid(1891010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891011, 1, "d3155a3dbff96176fef56bdc083487f81d86e661572fde822c1fd07c2ffacba5")

