-- Lua provided by RyzenAPI 
-- Game: Buoyant
addappid(1085280)
addappid(1085281, 1, "fe06bcca0b7b03ff48ac5e4b92490175960d2e1a91ba9a17e8fb99e0dcc3b2e9")
addappid(1085282, 1, "149eee1fee6002130282cc3defd6d37ede2f0300baf3061a1e90d3f437c1a8d0")
