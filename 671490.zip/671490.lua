-- Lua provided by RyzenAPI
-- Game: addappid(671490)

-- MAIN APPLICATION
addappid(671490)

-- MAIN APP DEPOTS / PACKAGES
addappid(671491, 1, "4b73508a32eb7d591bc00977b826b2c35a1e2feec44b789ee6b9ff9e1e500207")
