-- Lua provided by RyzenAPI
-- Game: Game: Realm of the Undead Demo

-- MAIN APPLICATION
addappid(2768250)
-- Game: addappid(2768250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768251, 1, "8ea64c472e7d0b87299eb6caff5ac5510f0dd6aa643135d9cb93c82512967c91")
