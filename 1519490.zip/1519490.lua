-- Lua provided by RyzenAPI
-- Game: 1519490

-- MAIN APPLICATION
addappid(1519490)
-- Game: addappid(1519490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519491, 1, "b218786c6d2faeda40eb93f4d9c53eb4f136a1029bc283069f138a7a7f133292")
