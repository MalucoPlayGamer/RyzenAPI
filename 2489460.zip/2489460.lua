-- Lua provided by SkyAPI 
-- Game: Cropisle TD
addappid(2489460)
addappid(2489461, 1, "744c0a362a0b1f914d94b425aac150a011af0a677e36b3923fa768c55ade49f1")
