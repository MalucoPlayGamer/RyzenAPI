-- Lua provided by RyzenAPI
-- Game: addappid(856430)

-- MAIN APPLICATION
addappid(856430)

-- MAIN APP DEPOTS / PACKAGES
addappid(856431, 1, "a7d3bdecf7e7593d9f1b010fba3e3cb8112f76352630050426213d8dc6dc5e7d")
