-- Lua provided by RyzenAPI
-- Game: Game: Vesnith Tapes

-- MAIN APPLICATION
addappid(3284900)
-- Game: addappid(3284900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3284901, 1, "278f65757175aa556023784e2e098d50a3901cbf7148213ba5da4bead3fbbcbd")
