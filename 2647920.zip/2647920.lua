-- Lua provided by RyzenAPI
-- Game: Game: Isuem's Elixir

-- MAIN APPLICATION
addappid(2647920)
-- Game: addappid(2647920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2647921, 1, "3b7dd2496dbe51143d5b1af9a91592f8c1ce17ab14672d1c22868debdd291ae9")
addappid(2647922, 1, "0298ba0ed5d5ae3af4d61619be776f6736e736e0533a92931579f87c84b45552")
addappid(2647923, 1, "d2954c52803b71f16db3146066c9ac3c6914e56ef9a85d57e8d095880faa671d")
