-- Lua provided by SkyAPI 
-- Game: AppID 926610
addappid(926610)
addappid(926611, 1, "4140c175d512c422411a9cedb005ae471b8bb2758650dce02941ca73a9c440d5")
