-- Lua provided by RyzenAPI
-- Game: Game: AppID 926610

-- MAIN APPLICATION
addappid(926610)
-- Game: addappid(926610)

-- MAIN APP DEPOTS / PACKAGES
addappid(926611, 1, "4140c175d512c422411a9cedb005ae471b8bb2758650dce02941ca73a9c440d5")
