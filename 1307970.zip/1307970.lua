-- Lua provided by RyzenAPI
-- Game: Cyber Hook Demo

-- MAIN APPLICATION
addappid(1307970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307971, 1, "f8e34e617785f1ad473e6da933320ca49641970021f799346f389b01f4665cba")
