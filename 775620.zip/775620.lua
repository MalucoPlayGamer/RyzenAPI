-- Lua provided by RyzenAPI
-- Game: 775620

-- MAIN APPLICATION
addappid(775620)
-- Game: addappid(775620)

-- MAIN APP DEPOTS / PACKAGES
addappid(775621, 1, "381a0c36f83fe1b8a68ace00450c85b3c0ef61597b3676f9c6da6c9a6c239232")
