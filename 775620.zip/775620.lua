-- Lua provided by RyzenAPI
-- Game: Fight or Flight

-- MAIN APPLICATION
addappid(775620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(775621, 1, "381a0c36f83fe1b8a68ace00450c85b3c0ef61597b3676f9c6da6c9a6c239232")
