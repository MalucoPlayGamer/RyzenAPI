-- Lua provided by RyzenAPI
-- Game: Game: AppID 1257910

-- MAIN APPLICATION
addappid(1257910)
-- Game: addappid(1257910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257911, 1, "e6809e589084923bb893a523c95e3e788c5bfd872d3d954a9d5b259ab2134a58")
