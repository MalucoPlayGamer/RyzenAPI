-- Lua provided by RyzenAPI
-- Game: DethKarz

-- MAIN APPLICATION
addappid(1257910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1257911, 1, "e6809e589084923bb893a523c95e3e788c5bfd872d3d954a9d5b259ab2134a58")
