-- Lua provided by RyzenAPI
-- Game: Last Holiday

-- MAIN APPLICATION
addappid(2115850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115851, 1, "5be86e06fafb09ff2e259ce8357cdbbc84e92dfb1dcad24d51b6dbd332d16ffc")
