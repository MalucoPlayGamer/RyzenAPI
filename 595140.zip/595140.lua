-- Lua provided by RyzenAPI
-- Game: Immortal Redneck

-- MAIN APPLICATION
addappid(595140)

-- MAIN APP DEPOTS / PACKAGES
addappid(595142,0,"8670e81d1c9fe5864f26300f8ad0d949eddb3ee438443dfc4baf014915ef56f6")
addappid(595143,0,"40d64abcb31fb930073f74324f4ab5e0f60d5cb87f50bc004673392e23644544")
addappid(595144,0,"e53d1075cf510f0eeb5d225630f56308af32ad64d0c3f6e349a34c963d92de0a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(619711)
