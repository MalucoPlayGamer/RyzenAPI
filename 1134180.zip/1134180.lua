-- Lua provided by RyzenAPI
-- Game: Memory leak: Cyberpunk hentai

-- MAIN APPLICATION
addappid(1134180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134181, 1, "9f14d27054cfa43bb1314ce05077f0273523be16049ec40f5a5e14cf9596a93d")

