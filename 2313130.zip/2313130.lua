-- Lua provided by SkyAPI 
-- Game: Lord of the Other World
addappid(2313130)
addappid(2313131, 1, "78daa4458b59fa92914520c8112e75000d28991fdbd52bfb805079c38921e59c")
