-- Lua provided by RyzenAPI
-- Game: Lord of the Other World

-- MAIN APPLICATION
addappid(2313130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313131, 1, "78daa4458b59fa92914520c8112e75000d28991fdbd52bfb805079c38921e59c")
