-- Lua provided by RyzenAPI
-- Game: Huygens Principle

-- MAIN APPLICATION
addappid(1819620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1819621, 1, "8fed3298abcd4468fc952c07090cd096b18ef94a956876b553ea735329d9c1e7")

