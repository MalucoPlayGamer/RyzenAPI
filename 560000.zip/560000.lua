-- Lua provided by RyzenAPI
-- Game: Ladykiller in a Bind

-- MAIN APPLICATION
addappid(560000)

-- MAIN APP DEPOTS / PACKAGES
addappid(560001, 1, "73d20f496113556209dd203eea97e4b4a44aae2e4baa91cafee9d0933ea87726")
addappid(576920, 0, "207aaedbce39e8f15f5c1f2f2ed65cfb4ecb8a01e4dc851fea9a270072881a6d")
