-- 2342360's Lua and Manifest Created by Hubcap Manifest
-- Dead Hook
-- Created: August 17, 2026 at 13:48:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2342360) -- Dead Hook
-- MAIN APP DEPOTS
addappid(2342361, 1, "8a965a98cf00106bbb1618bdeabe2b38a5665c3d3529829fa0017b40d5426343") -- Depot 2342361
setManifestid(2342361, "7457080192544030168", 6510913742)