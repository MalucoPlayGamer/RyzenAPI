-- Lua provided by RyzenAPI
-- Game: Dead Hook

-- MAIN APPLICATION
addappid(2342360) -- Dead Hook

-- MAIN APP DEPOTS / PACKAGES
addappid(2342361, 1, "8a965a98cf00106bbb1618bdeabe2b38a5665c3d3529829fa0017b40d5426343") -- Depot 2342361

