-- Lua provided by RyzenAPI
-- Game: The Stalked

-- MAIN APPLICATION
addappid(2587770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587771, 1, "4b22bf6f3a26016e12ad539ab564080efb47c8b9f98d27af7cf6df6af389544e")

