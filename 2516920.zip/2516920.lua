-- Lua provided by RyzenAPI
-- Game: The Chef's Shift: First Course

-- MAIN APPLICATION
addappid(2516920)
