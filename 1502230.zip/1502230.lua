-- Lua provided by RyzenAPI
-- Game: Tower of Waifus

-- MAIN APPLICATION
addappid(1502230)
addappid(1536050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502231, 1, "d61b15ab225cc1fa8ada555dc3048f5446eb4ada26dfabbc01a04b19aafbaaf0")
