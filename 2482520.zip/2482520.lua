-- Lua provided by SkyAPI 
-- Game: Neva Soundtrack
addappid(2482520)
addappid(2482521, 1, "8542982bd924d425dff15e2c05c89d1287e5e11a412b18172d2509d99829fcb6")
addappid(2482522, 1, "4c531140fe9dbd8566907cfa136725e04ebbc7b9473d03601e0aabc1bda61dbf")
