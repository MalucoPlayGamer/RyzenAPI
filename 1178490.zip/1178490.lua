-- Lua provided by RyzenAPI
-- Game: 港詭實錄ParanormalHK

-- MAIN APPLICATION
addappid(1178490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178491, 1, "05de198526b71687f617c6a476b9829f9deaff99b590c33599e4cc1ba63ef987")
