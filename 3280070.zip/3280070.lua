-- Lua provided by RyzenAPI
-- Game: addappid(3280070)

-- MAIN APPLICATION
addappid(3280070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3280071, 1, "66ceeadbf737ba1cc6dee33d9437e7906e140376476591452f1beb144d90de53")
