-- Lua provided by RyzenAPI
-- Game: Game: FARLAND SAGA I Saturn Tribute

-- MAIN APPLICATION
addappid(3519180)
-- Game: addappid(3519180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3519181, 1, "ee670d1a03bbdb75ccf45370d36255b1f390f3baaa48eb0d6afe6760898c1487")
