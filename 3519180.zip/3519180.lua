-- Lua provided by RyzenAPI
-- Game: FARLAND SAGA I Saturn Tribute

-- MAIN APPLICATION
addappid(3519180)
addappid(3773560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3519181, 1, "ee670d1a03bbdb75ccf45370d36255b1f390f3baaa48eb0d6afe6760898c1487")

