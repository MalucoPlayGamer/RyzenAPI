-- Lua provided by RyzenAPI
-- Game: 1765540

-- MAIN APPLICATION
addappid(1765540)
-- Game: addappid(1765540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765541, 1, "1e2d4203fb3f3966befc4171ea93ce277f1e444b665fa7feedfb69966359ea88")
