-- Lua provided by RyzenAPI
-- Game: Skill Legends Royale

-- MAIN APPLICATION
addappid(3114410)

