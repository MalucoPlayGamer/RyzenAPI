-- Lua provided by RyzenAPI
-- Game: Skies above the Great War

-- MAIN APPLICATION
addappid(2320040)
-- Game: addappid(2320040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320041, 1, "423a823c4476dfb96f76a8b182466c301469d89b88b0ef3ab09c6fe276c920f4")
