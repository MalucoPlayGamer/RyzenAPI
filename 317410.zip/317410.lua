-- Lua provided by RyzenAPI
-- Game: Color Symphony

-- MAIN APPLICATION
addappid(317410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(317411, 1, "cf4aacef6d9f26af2ae1c97dab213303ed40491e6143980e9a5bba07eb9a7acc")

