-- Lua provided by RyzenAPI
-- Game: Color Symphony

-- MAIN APPLICATION
addappid(317410)

-- MAIN APP DEPOTS / PACKAGES
addappid(317411, 1, "cf4aacef6d9f26af2ae1c97dab213303ed40491e6143980e9a5bba07eb9a7acc")

