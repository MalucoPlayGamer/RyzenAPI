-- Lua provided by RyzenAPI 
-- Game: AppID 1384780
addappid(1384780)
addappid(1384781, 1, "84870694abd9bdf70a34250c81894d347da0cf5c661feb698f3c26770447aa25")
addappid(1384782, 1, "d090bc531e013b395ca5d33c1d656cfea4103127b13ce80ae6319264b88e6dfd")
