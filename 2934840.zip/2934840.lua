-- Lua provided by RyzenAPI
-- Game: addappid(2934840)

-- MAIN APPLICATION
addappid(2934840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934841, 1, "46d10b449dd86b4e31a935914793c376e87cb658cf4c59d625169ad637ea2c0f")
