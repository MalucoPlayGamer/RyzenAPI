-- Lua provided by RyzenAPI
-- Game: Tee Time Golf

-- MAIN APPLICATION
addappid(537630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(537631, 1, "71ca6b4cedddf3396d338591472c4079e436269b6f96e287d35a9c4919c45949")

