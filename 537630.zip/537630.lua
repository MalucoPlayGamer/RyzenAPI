-- Lua provided by RyzenAPI
-- Game: Tee Time Golf

-- MAIN APPLICATION
addappid(537630)

-- MAIN APP DEPOTS / PACKAGES
addappid(537631, 1, "71ca6b4cedddf3396d338591472c4079e436269b6f96e287d35a9c4919c45949")

