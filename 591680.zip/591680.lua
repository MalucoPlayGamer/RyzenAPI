-- Lua provided by SkyAPI 
-- Game: Taphouse VR
addappid(591680)
addappid(591681, 1, "dc92f27bcef9e232c7deddaa39c62f94de61b7d9c0b4a959b065cfb24b3bb8ee")
