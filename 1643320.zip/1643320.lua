-- Generated with Luie @ https://lua.tools/
-- 1643320 - S.T.A.L.K.E.R. 2: Heart of Chornobyl
-- Generated 2026-08-21 19:22:32 UTC
-- # Depots (Total/DLC/Shared): 6/2/3

-- Main AppID
addappid(1643320, 1, "b783726cbbe01aa0588ea0829164ac9b24665c7394b3d13497e62639b8c083ea")

-- Main Depots
addappid(1643321, 1, "71c29e58911c13991edea02ac06db5f5991e43e52cdcd76c19126d657c4a38e7")
setManifestid(1643321, "8121640911331993429", 187198087632)

-- DLC's (no depot keys required)
addappid(1661620) -- S.T.A.L.K.E.R. 2: Heart of Chornobyl - Deluxe Upgrade
addappid(1661621) -- S.T.A.L.K.E.R. 2: Heart of Chornobyl - Ultimate Content
addappid(1661622) -- S.T.A.L.K.E.R. 2: Heart of Chornobyl - Season Pass
addappid(1661623) -- S.T.A.L.K.E.R. 2: Heart of Chornobyl - Pre-order Bonus
addappid(3399310) -- DLC 3399310

-- DLC's (with depot keys)
-- S.T.A.L.K.E.R. 2: Cost of Hope (AppID: 3765020)
addappid(3765020)
addappid(3765020, 1, "b1b8603692741b1a378078069c67a9908bda61991fdec23100fef15970450358")
setManifestid(3765020, "4750257545716219112", 0)
addappid(3765021, 1, "e876a04dbb1e5e6acbfd5615bb7fef20660736442090c3eb1454398f00b7dd4f")
setManifestid(3765021, "2446997090978732446", 19951772721)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
