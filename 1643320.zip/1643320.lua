-- Lua provided by RyzenAPI
-- Game: Game: S.T.A.L.K.E.R. 2: Heart of Chornobyl

-- MAIN APPLICATION
addappid(1643320)
-- Game: addappid(1643320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643321, 1, "71c29e58911c13991edea02ac06db5f5991e43e52cdcd76c19126d657c4a38e7")
