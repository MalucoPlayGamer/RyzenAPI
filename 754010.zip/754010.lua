-- Lua provided by RyzenAPI
-- Game: addappid(754010)

-- MAIN APPLICATION
addappid(754010)

-- MAIN APP DEPOTS / PACKAGES
addappid(754011, 1, "abcfbb2aaf0ca554c7504dc6af71d2974d9cf3a6a1ed61f859749c5b1e491ddd")
