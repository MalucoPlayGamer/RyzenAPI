-- 3396630's Lua and Manifest Created by Hubcap Manifest
-- POUMOSA
-- Created: August 16, 2026 at 12:59:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3396630, 1, "0368282fb712bb03fc201123760066c837130b8d5232ba5bc37e6a1d0f05c32d") -- POUMOSA
-- MAIN APP DEPOTS
addappid(3396631, 1, "c0f83f731d306ada4d592400536d7aa39152e598f29f6de8f80be16d6e67c283") -- Depot 3396631
setManifestid(3396631, "4316190569899841477", 742968526)