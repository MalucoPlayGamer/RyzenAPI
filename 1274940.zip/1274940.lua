-- Lua provided by RyzenAPI
-- Game: Strip 'Em

-- MAIN APPLICATION
addappid(1274940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1274941, 1, "7dff4c8aa52773e0c953c153ee4446e84349224b47337208a1ac6b9795408eba")

