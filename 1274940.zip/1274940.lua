-- Lua provided by RyzenAPI
-- Game: Game: AppID 1274940

-- MAIN APPLICATION
addappid(1274940)
-- Game: addappid(1274940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274941, 1, "7dff4c8aa52773e0c953c153ee4446e84349224b47337208a1ac6b9795408eba")
