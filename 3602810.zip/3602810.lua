-- Lua provided by RyzenAPI
-- Game: Deep Cuts OST - Nuclear Wedding

-- MAIN APPLICATION
addappid(3602810)
-- Game: addappid(3602810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602811, 1, "e91335a8d45eaa958167ef4347f2cff718b91807a9c07546639577a682f95e2e")
addappid(3602812, 1, "6102d04c9cf143ddc0879fc2bce997225b6015e88555389d002c3ca69cbdb46e")
