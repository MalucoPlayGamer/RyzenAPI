-- Lua provided by SkyAPI 
-- Game: Private Property
addappid(1481700)
addappid(1481701, 1, "ea9ec34cea45a55eafcff4b14200ff1698c9945f9d6e468a2f27464e98950c11")
