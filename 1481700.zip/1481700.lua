-- Lua provided by RyzenAPI
-- Game: Private Property

-- MAIN APPLICATION
addappid(1481700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481701, 1, "ea9ec34cea45a55eafcff4b14200ff1698c9945f9d6e468a2f27464e98950c11")

