-- Lua provided by RyzenAPI
-- Game: StarsAway

-- MAIN APPLICATION
addappid(2780410)
-- Game: addappid(2780410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780413,0,"295ff0958abe1e7ef6662bcca03f8813f9411c96478a96735343e8fde25900e9")
