-- Lua provided by RyzenAPI
-- Game: Fork Knights

-- MAIN APPLICATION
addappid(1097330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1097331, 1, "249593a8823ab0d57074f98569bd656efe693330f82864a102294f9ea8bb1943")
