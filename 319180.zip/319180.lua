-- Lua provided by RyzenAPI
-- Game: Game: Platypus II

-- MAIN APPLICATION
addappid(319180)
-- Game: addappid(319180)

-- MAIN APP DEPOTS / PACKAGES
addappid(319181, 1, "f6a8104acd52ac4282eaf19af4556c8e6e05e2e450896216f9b24c6ae0f1ed3f")
