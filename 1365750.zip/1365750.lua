-- Lua provided by RyzenAPI
-- Game: 东方栖霞园 ~ Blue devil in the Belvedere.

-- MAIN APPLICATION
addappid(1365750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365751, 1, "e601e1beaa20b9baf636b8ecb5608e51fbf7bb9629cf2f278843d611cf5c15c5")

