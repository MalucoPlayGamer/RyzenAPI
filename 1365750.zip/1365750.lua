-- Lua provided by RyzenAPI
-- Game: 东方栖霞园 ~ Blue devil in the Belvedere.

-- MAIN APPLICATION
addappid(1365750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1365751, 1, "e601e1beaa20b9baf636b8ecb5608e51fbf7bb9629cf2f278843d611cf5c15c5")

