-- Lua provided by RyzenAPI
-- Game: addappid(2590)

-- MAIN APPLICATION
addappid(2590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591, 1, "3da4558fc210e878149d3134ace5308330ebe6a5f923facc7ca0b4de91a96fe0")
