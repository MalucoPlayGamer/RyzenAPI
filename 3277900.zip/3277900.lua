-- Lua provided by RyzenAPI
-- Game: The Seven Realms: High Lathión - Official Walkthrough

-- MAIN APPLICATION
addappid(3277900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277900,0,"96e1fda0dc61bb9d5cf45bcdaf9ed6324009eff18feaa520beb3f3873fa52310")
