-- Lua provided by RyzenAPI
-- Game: Homesick

-- MAIN APPLICATION
addappid(244910)

-- MAIN APP DEPOTS / PACKAGES
addappid(244911, 1, "eec32488082e117ad5e667d8d9de59bd6b77a5fadfb2799b26b2e34f597ba71f")

