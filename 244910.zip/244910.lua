-- Lua provided by RyzenAPI
-- Game: Homesick

-- MAIN APPLICATION
addappid(244910)

-- MAIN APP DEPOTS / PACKAGES
addappid(244911, 1, "eec32488082e117ad5e667d8d9de59bd6b77a5fadfb2799b26b2e34f597ba71f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
