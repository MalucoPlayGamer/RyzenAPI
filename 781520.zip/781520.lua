-- Lua provided by RyzenAPI 
-- Game: Lucid Dreams: Polyventure
addappid(781520)
addappid(781521, 1, "ed1f4c8392ae67b4e1a7de01dd026c241ca16a8af2bd48c488e418cbf77200c3")
addappid(781522, 1, "d7ca086d8eaff9c25bc1011811cd08eb97a0d590307ea4a6e410d5a469ed7466")
addappid(781523, 1, "c5c1691fda3c7682b849ffe163f55a6a9296ae3d50503909b9326f05d2d98b4f")
addappid(781524, 1, "183240b3a64a460ce67b457311b5ed5ada54b9a5c3d166eafb510b5235ecc90d")
addappid(783370)
