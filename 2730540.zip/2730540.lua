-- Lua provided by RyzenAPI
-- Game: Card-en-Ciel

-- MAIN APPLICATION
addappid(2730540)
addappid(4376020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2730541,0,"bb15eb56e2ff9e3d98cd71816938db84ca3be50a6482bbfdf6c0748d91d2c06e")
addappid(4164630,0,"dd247ccad3eb8baff680775a45d57ae08b0d7e44b40b1d00bc88e9345e2b1c76")
addappid(4314030,0,"9510bf217dd8787960cfb9b01af3f4f39a59814752be23dec078c5e6e6818e43")
addappid(4314040,0,"0c49060f2c3d79948ffeba9b286daea77cc535fc2c0b5cb5d22a88726a087d82")

