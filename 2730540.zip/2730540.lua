-- Lua provided by RyzenAPI
-- Game: addappid(2730540)

-- MAIN APPLICATION
addappid(2730540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730541, 1, "bb15eb56e2ff9e3d98cd71816938db84ca3be50a6482bbfdf6c0748d91d2c06e")
