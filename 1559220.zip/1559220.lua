-- Lua provided by RyzenAPI
-- Game: FUSER™ - Winnage - "The Night Porter"

-- MAIN APPLICATION
addappid(1559220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559220,0,"9a98e9d952d212a4a94134f235dff9b873ec082a771196b33c515bda73db1eff")
