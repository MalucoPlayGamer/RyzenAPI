-- Lua provided by RyzenAPI
-- Game: Game: Fap Goddess

-- MAIN APPLICATION
addappid(2060080)
-- Game: addappid(2060080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060081, 1, "17c6ea0ef07f7b2cb7bc6740dd32f3dcbd0c08bca6b5383a919dc00c5ff8d6b1")
