-- Lua provided by RyzenAPI
-- Game: Game: Indoor Kickball

-- MAIN APPLICATION
addappid(2102640)
-- Game: addappid(2102640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102641, 1, "61d35c82352c6990ba5be62bea690d70b188dc840df837174db47d35f2789238")
