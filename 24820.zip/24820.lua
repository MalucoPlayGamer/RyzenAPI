-- Lua provided by RyzenAPI
-- Game: addappid(24820)

-- MAIN APPLICATION
addappid(24820)

-- MAIN APP DEPOTS / PACKAGES
addappid(24821, 1, "f8f3488c8009877a9f45aa05b92c34cd41a1fbde33951f53887ffd76d5dcdc3c")
