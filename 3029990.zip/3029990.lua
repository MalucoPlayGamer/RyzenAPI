-- Lua provided by RyzenAPI
-- Game: Game: Girls on Campus, from Freshmen to Faculty, All Fall for Me!

-- MAIN APPLICATION
addappid(3029990)
-- Game: addappid(3029990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029991, 1, "67f56b5fbff43888a3b8333cbf8d02c30c55f3611de0e82fb9204f61d865ff08")
