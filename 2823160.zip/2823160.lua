-- Lua provided by RyzenAPI
-- Game: addappid(2823160)

-- MAIN APPLICATION
addappid(2823160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2823161, 1, "cadb468e2f214f4ee360c905d8ee0e282706b6be4e4a4da670d613a4bf8cd030")
