-- Lua provided by RyzenAPI
-- Game: Whispering Willows

-- MAIN APPLICATION
addappid(288060)
-- Game: addappid(288060)

-- MAIN APP DEPOTS / PACKAGES
addappid(288063,0,"1d3278feb4e848b635d3af6a092fd35f0f7cd59d6d2a63d1b58ac2118e2b1fdc")
addappid(288064,0,"1a49f6841eca00fb81a538c95b7bc649e5248290f89eacb0465298ac8ed0d648")
addappid(288065,0,"e7c0dca32930785c3289c4841843351b11459aa520bcfb62a4ce32600686198c")
