-- Lua provided by RyzenAPI
-- Game: Cyber Knights: Flashpoint

-- MAIN APPLICATION
addappid(1021210)
-- Game: addappid(1021210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021212,0,"ca8eecda387085ee0ddead4b8e6f11eb31acbf246bff8341d302488f02613fc4")
