-- Lua provided by RyzenAPI
-- Game: Odd Remedy

-- MAIN APPLICATION
addappid(1745680)
-- Game: addappid(1745680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745681, 1, "8551204b4ab186f5b9be22800f86ce7fbc3091614c31099c036a846636f2598d")
