-- Lua provided by RyzenAPI
-- Game: Odd Remedy

-- MAIN APPLICATION
addappid(1745680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745681, 1, "8551204b4ab186f5b9be22800f86ce7fbc3091614c31099c036a846636f2598d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
