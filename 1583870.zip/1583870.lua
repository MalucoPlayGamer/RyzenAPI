-- Lua provided by RyzenAPI
-- Game: Strip Black Jack - Sex Bunny

-- MAIN APPLICATION
addappid(1583870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583871, 1, "011fd90c36f1fd17391217c57888af17f51182374eb2c7e2b86ae3de7065d505")

