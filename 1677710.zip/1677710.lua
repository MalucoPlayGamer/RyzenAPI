-- Lua provided by SkyAPI 
-- Game: Pixel Game Maker MV - Falling Blocks Puzzle Sample
addappid(1677710)
addappid(1677711, 1, "9d854a7ba3290ea71ce4e828fa4cb2805895aaedcb1a29ee95e6b245d76ed8fd")
