-- Lua provided by RyzenAPI 
-- Game: Nurikabe World
addappid(2964540)
addappid(2964541, 1, "c4944028f05fe664b22b3eec695f95efe9e5b92a25f38d3ad5e5c87a040ea212")
