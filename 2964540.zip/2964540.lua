-- Lua provided by RyzenAPI
-- Game: Game: Nurikabe World

-- MAIN APPLICATION
addappid(2964540)
-- Game: addappid(2964540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964541, 1, "c4944028f05fe664b22b3eec695f95efe9e5b92a25f38d3ad5e5c87a040ea212")
