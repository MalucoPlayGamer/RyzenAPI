-- Lua provided by RyzenAPI
-- Game: addappid(494670)

-- MAIN APPLICATION
addappid(494670)

-- MAIN APP DEPOTS / PACKAGES
addappid(494671, 1, "d594ea0c5bd6760e74c128df952ceffddab7b79a6d9b85ce883b184dfe95ca27")
addappid(494675, 1, "d1ac1ccb4602dacd951891a7256189aaf3e779380615ede9e685da8286661750")
