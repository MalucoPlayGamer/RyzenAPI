-- Lua provided by RyzenAPI
-- Game: Against the Storm

-- MAIN APPLICATION
addappid(1336490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336491, 1, "c62157594f44e2a3087998f70ca9dfe4736a0a98d9d1eca658ecaaf102f17dec")
