-- Lua provided by SkyAPI 
-- Game: Against the Storm
addappid(1336490)
addappid(1336491, 1, "c62157594f44e2a3087998f70ca9dfe4736a0a98d9d1eca658ecaaf102f17dec")
