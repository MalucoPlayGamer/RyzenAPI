-- Lua provided by RyzenAPI
-- Game: addappid(2122800)

-- MAIN APPLICATION
addappid(2122800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122802,0,"8e6e21feeec8f6d57048c6ed88d4a6006c6d2075a9e91ff6a4616127d38d9c75")
