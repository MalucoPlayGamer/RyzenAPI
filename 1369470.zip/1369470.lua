-- Lua provided by RyzenAPI
-- Game: Game: Pincremental

-- MAIN APPLICATION
addappid(1369470)
-- Game: addappid(1369470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369471, 1, "72338de7076cd0d388764c1e54b59d9df2daceb176c735f4123448a67158bdc9")
addappid(1369472, 1, "556070916497add565ff619a3bc182db76d2f9dde82bcb719488f29f43bc14fe")
