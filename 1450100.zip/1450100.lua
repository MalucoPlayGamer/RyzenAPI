-- Lua provided by RyzenAPI 
-- Game: LUNA
addappid(1450100)
addappid(1450101, 1, "4b4ad0b2ad22f25a212a64b8519d28e39b39c44bcbc14483cdaecc9ca7b30928")
addappid(1450104, 1, "7dbce06b40e181033b6276516b9750953505463ddb07005492050603e57624ef")
