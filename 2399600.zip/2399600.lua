-- Lua provided by RyzenAPI
-- Game: 2399600

-- MAIN APPLICATION
addappid(2399600)
-- Game: addappid(2399600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399601, 1, "4bd7d4e05ae2d3d29d1bb69e50e71ab8aa2c30348d70607deb6efd8d080634d4")
