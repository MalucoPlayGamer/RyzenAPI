-- Lua provided by RyzenAPI
-- Game: Game: Nancy Drew®: The Haunted Carousel

-- MAIN APPLICATION
addappid(31820)
-- Game: addappid(31820)

-- MAIN APP DEPOTS / PACKAGES
addappid(31821, 1, "a34df3c5a31a090b4a97e604aa8ad028ea7c161309de70edfde98b83ccdcd164")
