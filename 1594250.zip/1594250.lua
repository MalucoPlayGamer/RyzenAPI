-- Lua provided by RyzenAPI
-- Game: Game: Trials of Fire Soundtrack

-- MAIN APPLICATION
addappid(1594250)
-- Game: addappid(1594250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594251, 1, "edc4489d45fe9f02828ac5a7c3d19509f4099ca48d17043499ce9e29228899e5")
