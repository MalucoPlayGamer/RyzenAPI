-- Lua provided by RyzenAPI
-- Game: AppID 774941

-- MAIN APPLICATION
addappid(774941)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(774942, 1, "7c69672d957f5dda9278c02191a08367c13783bb2951d4c10d74ead51b0271cb")
addappid(774943, 1, "fb7d8edd01837b5ceec5389d0d5a647bddc0318a05888b5760c70bed09194262")

