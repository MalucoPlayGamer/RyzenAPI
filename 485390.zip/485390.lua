-- Lua provided by RyzenAPI
-- Game: addappid(485390)

-- MAIN APPLICATION
addappid(485390)

-- MAIN APP DEPOTS / PACKAGES
addappid(485391, 1, "eb34e918031b1838b14af22ec7bbc709f5acbd3a5c2430a1a5ba2a11376faace")
