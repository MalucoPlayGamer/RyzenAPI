-- Lua provided by RyzenAPI
-- Game: addappid(3720920)

-- MAIN APPLICATION
addappid(3720920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720921, 1, "d7c68c7baad7f9c09cc8d290fb4254bf3ceeed6af6e14f1ef225e5a4204c66ad")
