-- Lua provided by RyzenAPI
-- Game: Acro FS

-- MAIN APPLICATION
addappid(834880)
-- Game: addappid(834880)

-- MAIN APP DEPOTS / PACKAGES
addappid(834881, 1, "e3a09b96e385115c3505ed9b57a2504b9d12899212d6d1a57caf083283098045")
