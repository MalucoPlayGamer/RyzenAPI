-- Lua provided by RyzenAPI
-- Game: Game: FIND ALL 6: Netherlands

-- MAIN APPLICATION
addappid(3444050)
-- Game: addappid(3444050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3444051, 1, "838a7d760107eaad2839c1590f9fcb6c69595879f26d9e5d19f6cc822208dd1f")
