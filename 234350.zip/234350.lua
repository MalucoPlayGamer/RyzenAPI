-- Lua provided by RyzenAPI
-- Game: 234350

-- MAIN APPLICATION
addappid(234350)
-- Game: addappid(234350)

-- MAIN APP DEPOTS / PACKAGES
addappid(234351, 1, "46192714bae526122d4d8dfb57792680b0676aea795a6e684818f2819eae5b44")
