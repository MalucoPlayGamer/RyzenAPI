-- Lua provided by RyzenAPI
-- Game: FallingStarTown: The Ghost From Past

-- MAIN APPLICATION
addappid(2069500)
addappid(2069501)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069502,0,"808d07b449d255b8947cb438638d90a3a0cc562193b2cd0a6285002f55b3474b")

