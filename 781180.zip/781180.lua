-- Lua provided by RyzenAPI
-- Game: Technicity

-- MAIN APPLICATION
addappid(781180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(781181, 1, "b0c880f01d4dda1d522028ce42ea7834124f6e31b6076c0cbdf32302d01154a8")

