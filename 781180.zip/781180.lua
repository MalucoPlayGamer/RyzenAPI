-- Lua provided by RyzenAPI
-- Game: addappid(781180)

-- MAIN APPLICATION
addappid(781180)

-- MAIN APP DEPOTS / PACKAGES
addappid(781181, 1, "b0c880f01d4dda1d522028ce42ea7834124f6e31b6076c0cbdf32302d01154a8")
