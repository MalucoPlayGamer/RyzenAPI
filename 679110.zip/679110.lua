-- Lua provided by RyzenAPI
-- Game: Werewolf: The Apocalypse - Earthblood

-- MAIN APPLICATION
addappid(679110)

-- MAIN APP DEPOTS / PACKAGES
addappid(679111, 1, "83f6cc474ce87d6af791241668c76607f5b8fcd392745da07c5436249b7ada16")

