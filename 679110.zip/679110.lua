-- Lua provided by RyzenAPI
-- Game: Werewolf: The Apocalypse - Earthblood

-- MAIN APPLICATION
addappid(679110)

-- MAIN APP DEPOTS / PACKAGES
addappid(679111, 1, "83f6cc474ce87d6af791241668c76607f5b8fcd392745da07c5436249b7ada16")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1330520)
addappid(1330540)
