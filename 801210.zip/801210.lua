-- Lua provided by RyzenAPI
-- Game: 801210

-- MAIN APPLICATION
addappid(801210)
-- Game: addappid(801210)

-- MAIN APP DEPOTS / PACKAGES
addappid(801211, 1, "d67e2c50a603f02ed508350fe66a6e22740173b32ee51668ca5d2f8a5e82ae07")
