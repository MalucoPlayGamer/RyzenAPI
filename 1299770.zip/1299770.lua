-- Lua provided by RyzenAPI
-- Game: If Found... - Original Soundtrack

-- MAIN APPLICATION
addappid(1299770)
-- Game: addappid(1299770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299771, 1, "43fbb5ed0924c2c6d1b44b10881c022d1fb1b21753c711e62437bf60db84cd18")
