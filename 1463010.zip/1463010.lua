-- Lua provided by RyzenAPI
-- Game: Tank Mechanic Simulator VR

-- MAIN APPLICATION
addappid(1463010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463012,0,"5bae4dc91a5cac094c10c655ab723840bed395866b0d10ff56cc236d24a5661d")
