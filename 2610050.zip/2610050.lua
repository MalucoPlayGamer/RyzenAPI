-- Lua provided by RyzenAPI
-- Game: Little Chefs: CO-OP

-- MAIN APPLICATION
addappid(2610050)
-- Game: addappid(2610050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610051, 1, "1663c6b6576086bf728a9329e54c2c932d692c0530ebb3edd02b72e20190c25b")
