-- Lua provided by RyzenAPI
-- Game: 3063960

-- MAIN APPLICATION
addappid(3063960)
-- Game: addappid(3063960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3063961, 1, "e2de61257c639330af1d87628dbf149e94a4cee99dfdfa2c0bc7e562325bb01e")
