-- Lua provided by RyzenAPI
-- Game: addappid(3408790)

-- MAIN APPLICATION
addappid(3408790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408791, 1, "7264eb885839de052a8cd5e1f40367119d01e7ec4723ac81ef3a64aec96f1476")
