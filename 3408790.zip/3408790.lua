-- Lua provided by RyzenAPI
-- Game: Rogue Rubber

-- MAIN APPLICATION
addappid(3408790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408791, 1, "7264eb885839de052a8cd5e1f40367119d01e7ec4723ac81ef3a64aec96f1476")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
