-- Lua provided by RyzenAPI
-- Game: AppID 447820

-- MAIN APPLICATION
addappid(447820)

-- MAIN APP DEPOTS / PACKAGES
addappid(447821, 1, "4f27a2d34b74d87201e79cbf567bc82b137b590a778dfaac4772ea241f7244e4")
addappid(447822, 1, "e63a5f9dac0f61471382af2055bdc83f334ccf813900413f00f614603760e6a1")
addappid(447823, 1, "06d5fc9943a0efaf3a07b24dfa8e2e3398d562f8e0befa1e1d55b993b9ab09e0")
addappid(447824, 1, "f1cf753e180034c5c4b8d24434e2eb6843790ba1524d0f864ca6cda3a08cd4bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(610400)
