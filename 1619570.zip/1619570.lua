-- Lua provided by RyzenAPI
-- Game: Death Roads: Tournament

-- MAIN APPLICATION
addappid(1619570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619571, 1, "0c92ff2aba108afd0cb5afd6a075be6e6c7e29949f1340baa98c5ac0ec5494b9")

