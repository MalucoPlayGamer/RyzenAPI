-- Lua provided by RyzenAPI
-- Game: AppID 698160

-- MAIN APPLICATION
addappid(698160)

-- MAIN APP DEPOTS / PACKAGES
addappid(698161, 1, "be0ff615156aab108ae30b95827f9eba445cdd87b5b6d23d4debf4f29fe5c6a1")

