-- Lua provided by RyzenAPI
-- Game: DinosaurIsland

-- MAIN APPLICATION
addappid(698160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(698161, 1, "be0ff615156aab108ae30b95827f9eba445cdd87b5b6d23d4debf4f29fe5c6a1")
