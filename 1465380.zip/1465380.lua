-- Lua provided by RyzenAPI
-- Game: Hello From Darkness

-- MAIN APPLICATION
addappid(1465380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1465381, 1, "d85dd624d71c4f2209f60ccff771292d8fd7fe35e76635a4ac08a007361ea528")
addappid(1465382, 1, "90d05c9c76e10495411202186fa23dc0b3a068a687f7a4b2ae7502f215a1b782")
addappid(1465383, 1, "6470219636dfbee8479143f43913214522a94c71671fce5218ae509c24728c2f")

