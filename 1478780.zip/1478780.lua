-- Lua provided by RyzenAPI
-- Game: Game: You Are Weak

-- MAIN APPLICATION
addappid(1478780)
-- Game: addappid(1478780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478781, 1, "ccb2a3310a260ba6168c01da8df1c6fc953aefac4d7bedb8ddaf1c4a9d7f7925")
