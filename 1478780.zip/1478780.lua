-- Lua provided by SkyAPI 
-- Game: You Are Weak
addappid(1478780)
addappid(1478781, 1, "ccb2a3310a260ba6168c01da8df1c6fc953aefac4d7bedb8ddaf1c4a9d7f7925")
