-- Lua provided by RyzenAPI
-- Game: Breaking Box: Rush!

-- MAIN APPLICATION
addappid(2628560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628561,0,"33d3ace39cbbbd9785510e143b34df524e0878269a3d6eb3ab2c61e3bb29d3c2")

