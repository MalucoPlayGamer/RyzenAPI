-- Lua provided by RyzenAPI 
-- Game: Bronana
addappid(2492330)
addappid(2492331, 1, "74a0b3f60816f0275810f1ddfcd7e0785ffff0355420876a43d30a64cd756a61")
