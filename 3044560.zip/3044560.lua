-- Lua provided by SkyAPI 
-- Game: Lust 'n Dead 🔞
addappid(3044560)
addappid(3044561, 1, "0948476b361b20cfcb6b91d7cec6b21147490946439851d7efd90e8245a9408f")
