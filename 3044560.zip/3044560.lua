-- Lua provided by RyzenAPI
-- Game: Lust 'n Dead 🔞

-- MAIN APPLICATION
addappid(3044560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044561, 1, "0948476b361b20cfcb6b91d7cec6b21147490946439851d7efd90e8245a9408f")

