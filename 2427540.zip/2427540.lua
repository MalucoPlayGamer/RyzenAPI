-- Lua provided by RyzenAPI
-- Game: addappid(2427540)

-- MAIN APPLICATION
addappid(2427540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427541, 1, "139ffd6562085f7ef7ef570a0a4d5deb7d1274a71fcfceb64d90979d2c0e8157")
