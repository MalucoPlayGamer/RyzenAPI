-- Lua provided by SkyAPI 
-- Game: Magnir Saga Part 1
addappid(2427540)
addappid(2427541, 1, "139ffd6562085f7ef7ef570a0a4d5deb7d1274a71fcfceb64d90979d2c0e8157")
