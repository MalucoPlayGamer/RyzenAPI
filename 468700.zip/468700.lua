-- Lua provided by RyzenAPI
-- Game: 468700

-- MAIN APPLICATION
addappid(468700)
-- Game: addappid(468700)

-- MAIN APP DEPOTS / PACKAGES
addappid(468701, 1, "cf5f81f359831cdf399db60df5190469af91183c2bfbeca6528a4b6352460284")
