-- Lua provided by SkyAPI 
-- Game: AppID 468700
addappid(468700)
addappid(468701, 1, "cf5f81f359831cdf399db60df5190469af91183c2bfbeca6528a4b6352460284")
