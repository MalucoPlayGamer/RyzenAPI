-- Lua provided by RyzenAPI
-- Game: AppID 1060360

-- MAIN APPLICATION
addappid(1060360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060361, 1, "1a7ba4c1ef24d8d962a3e03c9a116be06db1e06a4bea5fd49f3a828b48347108")
