-- Lua provided by RyzenAPI
-- Game: Full Court Heroes Demo

-- MAIN APPLICATION
addappid(2953680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2953681, 1, "f39e2eaf12eb485344f283ecf44b86cb5984ab0dad3187e7f0988ac53128b7f8")
