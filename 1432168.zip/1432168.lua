-- Lua provided by RyzenAPI
-- Game: FUSER™ - Tag Team - "Whoomp! There It Is"

-- MAIN APPLICATION
addappid(1432168)
-- Game: addappid(1432168)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432168,0,"4d0849f6046343d755f13b6e7359937ae7fa5a2c54a3b5f4d7d19631742fe605")
