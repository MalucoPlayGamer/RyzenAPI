-- Lua provided by RyzenAPI
-- Game: Champions of Breakfast

-- MAIN APPLICATION
addappid(454380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(454381, 1, "04a9f7159725368dc240d34ab0fe6d472c5cb7e93c80916b579c0333b6212320")
addappid(454383, 1, "648f4bc04ca826e7e277757cf69c90e2a3a1cafc20dd9297b11396dc4dd4d462")

