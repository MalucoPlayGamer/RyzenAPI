-- Lua provided by RyzenAPI
-- Game: addappid(642560)

-- MAIN APPLICATION
addappid(642560)

-- MAIN APP DEPOTS / PACKAGES
addappid(642561, 1, "1173e785858bbc30507dece443a9d96fd28436de01a05a303c619944e4527b0d")
