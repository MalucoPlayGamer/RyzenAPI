-- Lua provided by RyzenAPI
-- Game: Handyman Corporation: Prologue

-- MAIN APPLICATION
addappid(2159780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159781, 1, "d6c2d07ff7e746e2e4837d0a3192161b422530ad6b3853b028699652d499e9ab")
