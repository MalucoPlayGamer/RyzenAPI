-- Lua provided by RyzenAPI
-- Game: Rain Debt

-- MAIN APPLICATION
addappid(4385520)

-- MAIN APP DEPOTS / PACKAGES
addappid(4385521,0,"469b22b7b95fca3a58c4c5890bc9c5347f314d82bcfbbabf6ae9d7eb2b63047c")

