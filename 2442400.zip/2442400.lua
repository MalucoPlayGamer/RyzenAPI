-- Lua provided by RyzenAPI
-- Game: Sex doll came to Life

-- MAIN APPLICATION
addappid(2442400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442401, 1, "4664082aca219e79e72f5aad93157ca3c78321aa5fec4e8d9263a639b7232e7a")

