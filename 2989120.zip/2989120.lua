-- Lua provided by RyzenAPI
-- Game: Verve™ Demo

-- MAIN APPLICATION
addappid(2989120)
-- Game: addappid(2989120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989121, 1, "9fafa92f19aabda9eddd05c37f2b2488f9ff36f2f42bc26f5080c295582b623d")
