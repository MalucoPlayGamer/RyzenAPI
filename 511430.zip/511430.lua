-- Lua provided by RyzenAPI
-- Game: AppID 511430

-- MAIN APPLICATION
addappid(511430)
-- Game: addappid(511430)

-- MAIN APP DEPOTS / PACKAGES
addappid(511431, 1, "291c8032f12fc3dd9c1d98780a670311b0657791de2c04bdef85d57af834ae2e")
