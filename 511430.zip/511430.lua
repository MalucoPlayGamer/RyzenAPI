-- Lua provided by RyzenAPI 
-- Game: AppID 511430
addappid(511430)
addappid(511431, 1, "291c8032f12fc3dd9c1d98780a670311b0657791de2c04bdef85d57af834ae2e")
