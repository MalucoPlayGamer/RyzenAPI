-- Lua provided by RyzenAPI
-- Game: AppID 511430

-- MAIN APPLICATION
addappid(511430)

-- MAIN APP DEPOTS / PACKAGES
addappid(511431, 1, "291c8032f12fc3dd9c1d98780a670311b0657791de2c04bdef85d57af834ae2e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
