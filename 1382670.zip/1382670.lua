-- Lua provided by RyzenAPI
-- Game: 1382670

-- MAIN APPLICATION
addappid(1382670)
-- Game: addappid(1382670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382671, 1, "31bcc108a037831b51a32cb7001adde424738c86db6a67e08a115fce4b4c7c41")
addappid(1392440, 0, "fd00ad3e7cb197a6ad9dfc6049d4072dc18c38549a68ea705d22e17efd0a1c22")
