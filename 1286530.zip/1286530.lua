-- Lua provided by RyzenAPI
-- Game: Game: Black Skylands: Origins

-- MAIN APPLICATION
addappid(1286530)
-- Game: addappid(1286530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286531, 1, "07655f562e468f6fc8daaed3afd34c2a7850657a372c35cb9f7c46ab22ebd27c")
