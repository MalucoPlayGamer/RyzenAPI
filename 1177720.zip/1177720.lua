-- Lua provided by RyzenAPI
-- Game: AppID 1177720

-- MAIN APPLICATION
addappid(1177720)
addappid(1192561)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1177721, 1, "e36c2d595f48ca926faf1e0854dce7603ab4fa9bcdf0b7acfe3417a7b60635ca")

