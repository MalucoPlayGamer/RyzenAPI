-- Lua provided by RyzenAPI
-- Game: Game: Late Night Drift

-- MAIN APPLICATION
addappid(2681530)
-- Game: addappid(2681530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681531, 1, "a17e9a6d5f19cfb5d0e18b1524fef1ea903cffe18458f174ae684bbdc664d623")
