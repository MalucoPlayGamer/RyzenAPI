-- Lua provided by RyzenAPI 
-- Game: AppID 569650
addappid(569650)
addappid(569651, 1, "82647ac92f7243336c90daa7c01ec16eb8c6cb5ac2b784f5201f5778056bcafb")
