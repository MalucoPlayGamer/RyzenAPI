-- Lua provided by RyzenAPI
-- Game: AppID 569650

-- MAIN APPLICATION
addappid(569650)
-- Game: addappid(569650)

-- MAIN APP DEPOTS / PACKAGES
addappid(569651, 1, "82647ac92f7243336c90daa7c01ec16eb8c6cb5ac2b784f5201f5778056bcafb")
