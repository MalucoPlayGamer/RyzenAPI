-- Lua provided by RyzenAPI
-- Game: Chess Opening Repertoire Builder

-- MAIN APPLICATION
addappid(2755460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755461, 1, "d501ad2aa6edb1ae486263fc3aeeb7973ee4c37ce35857add0faefa2e69ab2a1")

