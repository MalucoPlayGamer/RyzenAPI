-- Lua provided by RyzenAPI 
-- Game: Kabaret
addappid(1525580)
addappid(1525581, 1, "93361a07aaec4196183af86d8d4199a3d3b582fc796f4a37c563fbc89e7c0ce4")
