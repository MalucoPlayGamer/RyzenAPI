-- Lua provided by RyzenAPI
-- Game: Kabaret

-- MAIN APPLICATION
addappid(1525580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525581, 1, "93361a07aaec4196183af86d8d4199a3d3b582fc796f4a37c563fbc89e7c0ce4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
