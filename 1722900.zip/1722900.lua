-- Lua provided by RyzenAPI
-- Game: I Expect You To Die 2 Official Soundtrack

-- MAIN APPLICATION
addappid(1722900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722901, 1, "c8e54a66f778a575746bad2aa0f4c023da875b1e393d1257d394f3065704cc9c")
addappid(1722902, 1, "b05b0539ed963c19040d356f709e095d415397f591623aecb11b5d62aa32cf88")

