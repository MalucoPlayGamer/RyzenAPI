-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors

-- MAIN APPLICATION
addappid(1191260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191261, 1, "c6f10197917469b20652ccb4c6b9596c676f898b9d084b738bf59a12751c470b")

