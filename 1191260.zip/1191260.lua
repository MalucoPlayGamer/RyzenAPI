-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors

-- MAIN APPLICATION
addappid(1191260) -- Touken Ranbu Warriors
addappid(1912030)
addappid(1912040)
addappid(1912041)
addappid(1912042)
addappid(1912043)
addappid(1912050)
addappid(1912051)
addappid(1912052)
addappid(1912053)
addappid(1912054)
addappid(1912070)
addappid(1912071)
addappid(1912072)
addappid(1912080)
addappid(1912081)
addappid(1912082)
addappid(1912083)
addappid(1912090)
addappid(1912091)
addappid(1912092)
addappid(1912100)
addappid(1912101)
addappid(1912102)
addappid(1912110)
addappid(1912111)
addappid(1912120)
addappid(1945210)
addappid(1945211)
addappid(1945212)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1191261, 1, "c6f10197917469b20652ccb4c6b9596c676f898b9d084b738bf59a12751c470b") -- Depot 1191261
addappid(1912030, 1, "5060aedbc1a51dc48a2327c7ff84b4793e8fe3f50e143b36c1a9415303854018") -- Touken Ranbu Warriors - Honmaru Backdrop Sakura Viewing - Depot 1912030
addappid(1912040, 1, "2806eee96999f5b2a96607bf661e39e88ec191bc5bf9f2a85bbaba3797fd0166") -- Touken Ranbu Warriors - Honmaru Backdrop Sakura Viewing - Nighttime - Depot 1912040
addappid(1912041, 1, "385a62f47de2b4e9e73225c9c33361e9d418ca47d37528a031ccedef0dc0de73") -- Touken Ranbu Warriors - Honmaru Backdrop Rainy Season - Depot 1912041
addappid(1912042, 1, "c00a85089e22c980b458b9fc17bedce136ad3c2c26b91360bf3972448a24f9fc") -- Touken Ranbu Warriors - Honmaru Backdrop Autumn Leaves - Depot 1912042
addappid(1912043, 1, "23a27dd51ecac0668c8fb2985a3f7cec99acca77e63aa2c2e9fce40983e6a329") -- Touken Ranbu Warriors - Honmaru Backdrop Snow Viewing - Depot 1912043
addappid(1912050, 1, "e8e6d20878cebb60761e312fbaef57fd4365cae1d4c3fefe00fd7094f2b00aed") -- Touken Ranbu Warriors - Additional Music Battle - Touken Ranbu Warriors - Depot 1912050
addappid(1912051, 1, "17cbe63bf1ab2f84c2d5de65541846cf7e569dfe68ea34ca7bebbc4542ed4ed1") -- Touken Ranbu Warriors - Additional Music Memories of Aonohara - Touken Ranbu Warriors - Depot 1912051
addappid(1912052, 1, "e647a6323c487958a9c7ea6048647fad2fb7a1658444623ca87cdb822cd69902") -- Touken Ranbu Warriors - Additional Music Osaka Winter Campaign - Touken Ranbu Warriors - Depot 1912052
addappid(1912053, 1, "05dc63cf78aa3e3e60f027ed83828b050a6e908df427039596c40faa77255fdb") -- Touken Ranbu Warriors - Additional Music Honmaru - Touken Ranbu Warriors - Depot 1912053
addappid(1912054, 1, "9285714b4140a0882d3185a6123737a7a814bd8d1dc47e6df6af6ae7512b7dea") -- Touken Ranbu Warriors - Additional Music Uchiban - Touken Ranbu Warriors - Depot 1912054
addappid(1912070, 1, "732a36ec12249e17533b0f293bf260ae2d2e1821cac7222cfb2a4dbed6e09af0") -- Touken Ranbu Warriors - Uchiban Outfit Mikazuki Munechika - Depot 1912070
addappid(1912071, 1, "52eeb94c8f62892f2f32ad2b5684ad928dd3527e04682317a95fc0db11c8510b") -- Touken Ranbu Warriors - Uchiban Outfit Sengo Muramasa - Depot 1912071
addappid(1912072, 1, "48a4fc26cf1e899e5817f72cb9df0b3199c93d6f9ce010aeb7f6c356934d8974") -- Touken Ranbu Warriors - Uchiban Outfit Tonbokiri - Depot 1912072
addappid(1912080, 1, "2455e072c56a51c2417166ecb1697d7d3a23cb8afb42605243888129b1fa8eca") -- Touken Ranbu Warriors - Uchiban Outfit Kasen Kanesada - Depot 1912080
addappid(1912081, 1, "878572cf27f6af90259973a6ce93ab08ce2b5234da291ba0ac2257f8900a3560") -- Touken Ranbu Warriors - Uchiban Outfit Ichigo Hitofuri - Depot 1912081
addappid(1912082, 1, "51f24163381c5fd7432c940ec6538931ca20fa38b8b80d57cd4640852b73339b") -- Touken Ranbu Warriors - Uchiban Outfit Namazuo Toushiro - Depot 1912082
addappid(1912083, 1, "aba65a1e5ea04abc5f420c9f13ac9e8afc44c922e9f34f8059874ca092740666") -- Touken Ranbu Warriors - Uchiban Outfit Hyuga Masamune - Depot 1912083
addappid(1912090, 1, "5d371db8d928687d1538c5d469ab1f177b8aa5a938732295d8f379f38d1455bc") -- Touken Ranbu Warriors - Uchiban Outfit Heshikiri Hasebe - Depot 1912090
addappid(1912091, 1, "b77da2817675e57418864ccebf40945d9a32f723b658e5879a69fdd5fa984bba") -- Touken Ranbu Warriors - Uchiban Outfit Yagen Toushiro - Depot 1912091
addappid(1912092, 1, "4f2a67dd4b5fdbb026e6dc246ddea9639499982010fc6959e50c84e6325a1fc4") -- Touken Ranbu Warriors - Uchiban Outfit Tomoegata Naginata - Depot 1912092
addappid(1912100, 1, "7a22c3917612ff0e89f379915e5a01dde57dd43adf9c37c98a69fc1cba4de145") -- Touken Ranbu Warriors - Uchiban Outfit Tsurumaru Kuninaga - Depot 1912100
addappid(1912101, 1, "79c779ff3d674eed9bffcebd09dcc9aad8f8a21111e58d14886c7ff31db21def") -- Touken Ranbu Warriors - Uchiban Outfit Shokudaikiri Mitsutada - Depot 1912101
addappid(1912102, 1, "8c6b1b1ec44287a450b09cc2194a3b963d19c2a3a56ab6de3979aa2b38e9e9b4") -- Touken Ranbu Warriors - Uchiban Outfit Okurikara - Depot 1912102
addappid(1912110, 1, "af10afd3fa7386bc3e6d97b6aeec25fc83f769ea4d4dbbe67dde9e17587e65ed") -- Touken Ranbu Warriors - Uchiban Outfit Yamanbagiri Kunihiro - Depot 1912110
addappid(1912111, 1, "3bd1a6d9aefcd4c3a308a425344e31e647c9d2651d4d1904231c7b5fd314a0ef") -- Touken Ranbu Warriors - Uchiban Outfit Yamanbagiri Chougi - Depot 1912111
addappid(1912120, 1, "761dc6841d8ed717b9d60cd81739950562e73d39c0555626d0d6787a6d0e004b") -- Touken Ranbu Warriors - Uchiban Outfit Omokage - Depot 1912120
addappid(1945210, 1, "e09aa97defb1e1266c3c7843f3321f5778bdd78dff8d727bba59618130f966a4") -- Touken Ranbu Warriors - Honmaru Backdrop 5-piece Set - Depot 1945210
addappid(1945211, 1, "ca378cd4ae0413dfe9f1a8b5da37b2d5198f611e7cf42885cac9c8fa52c2ca62") -- Touken Ranbu Warriors - Additional Music 5-piece Set - Depot 1945211
addappid(1945212, 1, "5d52c01281f25a7e44047d428a0eeb576d8f3a8cc6dd6565603163b71e5e2964") -- Touken Ranbu Warriors - Uchiban Outfit 16-piece Set - Depot 1945212

