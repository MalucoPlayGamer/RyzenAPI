-- Lua provided by RyzenAPI
-- Game: TEMPUS

-- MAIN APPLICATION
addappid(1742590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1742591, 1, "4f42d093a998b1b4022389b1f0a209d66cb79163dedf0f02f6c9fb5bdaa3873a")

