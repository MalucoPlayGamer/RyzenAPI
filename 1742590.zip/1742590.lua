-- Lua provided by RyzenAPI
-- Game: Game: TEMPUS

-- MAIN APPLICATION
addappid(1742590)
-- Game: addappid(1742590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742591, 1, "4f42d093a998b1b4022389b1f0a209d66cb79163dedf0f02f6c9fb5bdaa3873a")
