-- Lua provided by RyzenAPI
-- Game: Game: Starstruck Vagabond

-- MAIN APPLICATION
addappid(2448930)
-- Game: addappid(2448930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448931, 1, "3d870cdd002205d6605e4469544c4886f6e130b00d558e838b13e386a0005337")
