-- Lua provided by RyzenAPI
-- Game: Vanguard Princess Artwork and Soundtrack

-- MAIN APPLICATION
addappid(511170)
-- Game: addappid(511170)

-- MAIN APP DEPOTS / PACKAGES
addappid(511170,0,"35cd95b14d179d6bade496e968b6d5c93fec6911dcfb971dd19633cb36534cb8")
