-- Lua provided by RyzenAPI
-- Game: Airport Simulator 2015

-- MAIN APPLICATION
addappid(319780)

-- MAIN APP DEPOTS / PACKAGES
addappid(319781, 1, "5485d625272c48e4f68efa48cf0900f41c4f5a3472833f71737c997be1f130d3")

