-- Lua provided by RyzenAPI
-- Game: Airport Simulator 2015

-- MAIN APPLICATION
addappid(319780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(319781, 1, "5485d625272c48e4f68efa48cf0900f41c4f5a3472833f71737c997be1f130d3")

