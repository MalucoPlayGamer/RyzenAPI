-- Lua provided by RyzenAPI 
-- Game: Spermination
addappid(363460)
addappid(363461, 1, "0073d98a33b51f498c54fb531772daee2f21e24f4df7693495e075235109133e")
addappid(363462, 1, "2f5ab5d4a65d56618bf53e83fea3af3c2376016ebf0614ec0a83a6c7742b334b")
addappid(363463, 1, "8db36a9d61971f216acaba43d55acbfb58563a9858290de4103c89e80b74f00b")
