-- Lua provided by RyzenAPI
-- Game: Game: PixelJunk™ Monsters Ultimate

-- MAIN APPLICATION
addappid(243780)
-- Game: addappid(243780)

-- MAIN APP DEPOTS / PACKAGES
addappid(243781, 1, "b6dd4fe79f524b77456cb212f9b9ed5586f260f1d5eef5174b0cc182559456d3")
addappid(243782, 1, "d639698436db619a18ca3710b192079a733f5f635e40a28cd4d14ea3a7353b9a")
addappid(243783, 1, "4a2a93a00467b396612f19bf654d5ad7ff215b513b175c9eff748e8eaab51f01")
