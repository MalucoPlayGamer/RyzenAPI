-- Lua provided by RyzenAPI
-- Game: Arcane Eyes

-- MAIN APPLICATION
addappid(1500220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500221, 1, "edecc76182c86a694dea20676ca35b46a32122fbe1ae06c7388ebbc025fe8f1f")
