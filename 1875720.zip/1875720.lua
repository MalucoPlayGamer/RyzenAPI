-- Lua provided by RyzenAPI
-- Game: 1875720

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(229007)
addappid(229012)
addappid(229020)
addappid(229030)
addappid(1875720)
addappid(1875723)
-- Game: addappid(1875720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875722,0,"157dddf42a064e3c12f45b80953785894d902784a6c3bff3d9d9cee304d87ef5")
