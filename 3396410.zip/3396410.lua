-- Lua provided by RyzenAPI
-- Game: Multiverse Loot Hunter - Waifu-ized DLC

-- MAIN APPLICATION
addappid(3396410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3396410,0,"e9e432ec213897831b3a129e0921ca743bc67ae7432200c574ee4c88c5c0241b")

