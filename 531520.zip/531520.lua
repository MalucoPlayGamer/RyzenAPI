-- Lua provided by RyzenAPI
-- Game: TankCraft

-- MAIN APPLICATION
addappid(531520)

-- MAIN APP DEPOTS / PACKAGES
addappid(531521, 1, "99f2e077ee767b4043f7f4192dd2c73328bf1861a6908dd4e9755a21585a6e26")
