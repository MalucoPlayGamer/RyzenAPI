-- Lua provided by RyzenAPI
-- Game: Game: The Rest of Our Lives

-- MAIN APPLICATION
addappid(1169170)
-- Game: addappid(1169170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169171, 1, "170372856f482fc4a3586652676b7ce04944de74e42bfe938ecacdd80ebe59d2")
