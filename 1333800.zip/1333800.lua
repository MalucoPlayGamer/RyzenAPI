-- Lua provided by RyzenAPI
-- Game: 1333800

-- MAIN APPLICATION
addappid(1333800)
-- Game: addappid(1333800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333801, 1, "477ce66be2e8fd6395ec1db54aa57c39f51d3da56547ede118a9ff83bcd220c5")
