-- Lua provided by RyzenAPI
-- Game: Dragon Map Maker

-- MAIN APPLICATION
addappid(1906050)
-- Game: addappid(1906050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1906051, 1, "95b18658b84e099f2e0a0a7705605ce6caa402cc447efbb9b1742d0c69efcd04")
