-- Lua provided by RyzenAPI
-- Game: Karl BOOM

-- MAIN APPLICATION
addappid(1099470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1099471, 1, "a21ebbf7bc67ca210b25c65e387e82dc9a6106d888b9bb65236199bbbe7da799")
addappid(1099472, 1, "77d2a84ed46834458e65e2e2fd82798762644a91a591464ca904002660511ffa")
addappid(1099473, 1, "6d39a135376f798bada0f06352ddeb9321c10204180fec54580a684ac381ba1b")
