-- Lua provided by RyzenAPI
-- Game: Backrooms: Lost Tape

-- MAIN APPLICATION
addappid(1926620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926621, 1, "86c3570bbf4bb83b808820abbf83678055b74d43586bdde9bb8925d040af0991")
