-- Lua provided by RyzenAPI
-- Game: 1145570

-- MAIN APPLICATION
addappid(1145570)
-- Game: addappid(1145570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145571, 1, "e4f630846848cf268fec5fc80fd7ff523315385bda4b1eb5b6afcd350bf44864")
