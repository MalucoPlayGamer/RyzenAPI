-- Lua provided by RyzenAPI
-- Game: 2765760

-- MAIN APPLICATION
addappid(2765760)
addappid(2765763)
-- Game: addappid(2765760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765762,0,"c0aa500ace89acf71e28c3e7aa19a46ab28d3cb5de8cff5566062cd126d85674")
