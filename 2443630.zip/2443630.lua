-- Lua provided by RyzenAPI
-- Game: STAR WARS™: Episode I: Jedi Power Battles™

-- MAIN APPLICATION
addappid(2443630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443631, 1, "7c5a9468cd5d8d0dd3d3ca6e167b6e8c5cbd83fb298452b6975dfa1741ca7ebb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
