-- Lua provided by SkyAPI 
-- Game: STAR WARS™: Episode I: Jedi Power Battles™
addappid(2443630)
addappid(2443631, 1, "7c5a9468cd5d8d0dd3d3ca6e167b6e8c5cbd83fb298452b6975dfa1741ca7ebb")
