-- Lua provided by RyzenAPI
-- Game: Party Animals

-- MAIN APPLICATION
addappid(1260320)
addappid(2342040)
addappid(2545150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1260321, 1, "9623dafeee383701a837274d2547c7a5cbae7334393d64e82b4d2cdc01ef679e")
