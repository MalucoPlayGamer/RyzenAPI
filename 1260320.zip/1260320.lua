-- Lua provided by RyzenAPI
-- Game: Game: AppID 1260320

-- MAIN APPLICATION
addappid(1260320)
addappid(2342040)
addappid(2545150)
-- Game: addappid(1260320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260321, 1, "9623dafeee383701a837274d2547c7a5cbae7334393d64e82b4d2cdc01ef679e")
