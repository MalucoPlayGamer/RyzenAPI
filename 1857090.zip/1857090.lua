-- Lua provided by RyzenAPI
-- Game: Game: Norland

-- MAIN APPLICATION
addappid(1857090)
-- Game: addappid(1857090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857091, 1, "370d177702e1721868b4db49904b523b83825e329df24930490ba7b3a7da7131")
