-- Lua provided by RyzenAPI
-- Game: 3525580

-- MAIN APPLICATION
addappid(3525580)
-- Game: addappid(3525580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3525581, 1, "bc3d95dfee9505ceceb773ef61fefbfff2e042162d6f929de688b57b5a5cd9e1")
