-- Lua provided by SkyAPI 
-- Game: Castle Combat
addappid(3525580)
addappid(3525581, 1, "bc3d95dfee9505ceceb773ef61fefbfff2e042162d6f929de688b57b5a5cd9e1")
