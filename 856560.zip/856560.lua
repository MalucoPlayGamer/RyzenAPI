-- Lua provided by RyzenAPI
-- Game: Black Roses

-- MAIN APPLICATION
addappid(856560)

-- MAIN APP DEPOTS / PACKAGES
addappid(856561, 1, "31a078f0cdf5a19d07832961318f0edad4172ae45464faf28d267cd0b4ba84b1")
