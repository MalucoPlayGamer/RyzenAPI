-- Lua provided by RyzenAPI
-- Game: Path to Warband

-- MAIN APPLICATION
addappid(2116780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116782,0,"f3da5b340f9cf69be91d1c92485c36e11d69c270cd845bd9b383fc226c576976")
