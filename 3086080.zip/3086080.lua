-- Lua provided by RyzenAPI
-- Game: Sensei! I like you so much! - Fangirl Toolkit

-- MAIN APPLICATION
addappid(3086080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3086081, 1, "84f0679f5ba4d902f13b86c28bfa76553d4738d24b354599a41aac8e504fa101")
