-- Lua provided by RyzenAPI
-- Game: Battlemon

-- MAIN APPLICATION
addappid(2236220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236221, 1, "14d99a1ada07267ab4d46c15184ae44bee9caf112afd353e03098a24e3d0b337")

