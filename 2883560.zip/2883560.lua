-- Lua provided by RyzenAPI
-- Game: Observance of Homeland

-- MAIN APPLICATION
addappid(2883560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883561, 1, "80436d85a55c4de6ace08e5f2d9b2a153f806535c0a79bce4c3d501c51dc41b5")

