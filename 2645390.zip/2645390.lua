-- Lua provided by RyzenAPI
-- Game: Pelagos: A Marine Adventure

-- MAIN APPLICATION
addappid(2645390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645391, 1, "ab953b62802794af133de0d8cd5f4667ca9ac61584d8d3137e4bbdb5798a8fea")
