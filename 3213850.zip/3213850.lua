-- Lua provided by RyzenAPI
-- Game: gogh: Focus with Your Avatar

-- MAIN APPLICATION
addappid(3213850)
addappid(3559190)
addappid(4148270)
addappid(4148280)
addappid(4354530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213851, 1, "096cd494378b8ab62d21a7eadcf9a1736f7fe130b6f9bef9d2bb894074ab1bce")

