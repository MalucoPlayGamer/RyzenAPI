-- Lua provided by RyzenAPI
-- Game: 885180

-- MAIN APPLICATION
addappid(885180)
-- Game: addappid(885180)

-- MAIN APP DEPOTS / PACKAGES
addappid(885181, 1, "c7024b0034ac4ab2382dd4945f5947d8b39aebc4338e9a620c514767cc3bdb4d")
