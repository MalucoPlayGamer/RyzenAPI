-- Lua provided by RyzenAPI
-- Game: Nine Realms: Revolt Demo

-- MAIN APPLICATION
addappid(2487860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487861, 1, "b812118e77fe675949a439d20532b64f84fe02dd218eb7c1a4d0bcf8c401a2fd")
