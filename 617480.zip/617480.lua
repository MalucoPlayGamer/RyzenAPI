-- Lua provided by RyzenAPI
-- Game: Tower of Time

-- MAIN APPLICATION
addappid(617480)

-- MAIN APP DEPOTS / PACKAGES
addappid(617481, 1, "9679f72e357189f9e4df381c634dad5451f77202804263a2b10564605633502c")
addappid(617482, 1, "fb00644f79baf330476211f18987ada976f3714919f989943df4a85a40abdbf8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(713280)
addappid(3497290)
