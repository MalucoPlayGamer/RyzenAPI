-- Lua provided by RyzenAPI
-- Game: The Adventures of LinShanHai

-- MAIN APPLICATION
addappid(2283690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283691, 1, "fd85fa804491ed44b1436397fc721ed6683ad1569f427beb03e6a3c76491ad91")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
