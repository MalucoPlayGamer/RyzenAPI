-- Lua provided by RyzenAPI
-- Game: 2283690

-- MAIN APPLICATION
addappid(2283690)
-- Game: addappid(2283690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283691, 1, "fd85fa804491ed44b1436397fc721ed6683ad1569f427beb03e6a3c76491ad91")
