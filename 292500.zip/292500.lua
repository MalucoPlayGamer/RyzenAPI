-- Lua provided by RyzenAPI
-- Game: AppID 292500

-- MAIN APPLICATION
addappid(292500)
-- Game: addappid(292500)

-- MAIN APP DEPOTS / PACKAGES
addappid(292501, 1, "2dc74ac18bd794e8eeb5a2e2742adaa33361f57ebab6eb84dfaa8fb14a840909")
addappid(292502, 1, "573bb0abe187e7138c97d20b25064b21e11f1e4fb0ef469214070787e558602a")
