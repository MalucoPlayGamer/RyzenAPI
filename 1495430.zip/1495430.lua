-- Lua provided by RyzenAPI
-- Game: Game: AppID 1495430

-- MAIN APPLICATION
addappid(1495430)
-- Game: addappid(1495430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495431, 1, "e2863b3261090e5b234bd87fdb10eef5902ebafd80b1aff3909b76c46a8addc9")
