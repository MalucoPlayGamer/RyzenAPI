-- Lua provided by RyzenAPI
-- Game: Deck of Haunts

-- MAIN APPLICATION
addappid(3179730)
addappid(4229840)
-- Game: addappid(3179730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179731, 1, "91d2eed03b2cc6817cc2329b211f66b067b0bba3941763d1852e02eb8f56e970")
