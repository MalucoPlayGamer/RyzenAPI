-- Lua provided by RyzenAPI
-- Game: Game: AppID 546160

-- MAIN APPLICATION
addappid(546160)
-- Game: addappid(546160)

-- MAIN APP DEPOTS / PACKAGES
addappid(546161, 1, "45a9b1ffa2f1a100278c30d0742c118201fc0d9d86a526eb0fd895f1df60596e")
addappid(546162, 1, "4eae32ed7cde8e54e3db073befa0dd2ce4c211552c3f3e0415e534b38393a577")
addappid(768620, 0, "157f628d5221653416cea2f5ee868e90aa8f57e77af0a8ea23c43b2e877784b7")
