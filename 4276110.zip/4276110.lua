-- 4276110's Lua and Manifest Created by Hubcap Manifest
-- Rogue 21
-- Created: June 25, 2026 at 12:08:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4276110) -- Rogue 21
-- MAIN APP DEPOTS
addappid(4276111, 1, "798c0ac193fa01e37c10e6a1cefeaec08b48d99063fe9755b4b20d0b86b63913") -- Depot 4276111
setManifestid(4276111, "2371499093827793088", 440069820)
addappid(4276113, 1, "a77d421d1be50c47d5a8d25814da4c375946a1265a30f57315a3b9dabeb52e37") -- Depot 4276113
setManifestid(4276113, "3598191883018359277", 397495217)