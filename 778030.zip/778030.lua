-- Lua provided by RyzenAPI
-- Game: Block Heads: Instakill

-- MAIN APPLICATION
addappid(778030)
addappid(874150)
addappid(874151)
addappid(874152)
addappid(874153)
addappid(874160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(778031, 1, "32cf944f1ebb37898bd60e4343fc67ca38bacbd9d37eaac91decc80b2a427aad")
addappid(778032, 1, "2135a98cbcbf56f81f961ddb439fec24a5355dd534ea9ce83613bbfada0a4043")
addappid(778033, 1, "9e042f614c6098b4f1ebbcad924bf044612347d542f5394ff503ecf0ea1d55f2")

