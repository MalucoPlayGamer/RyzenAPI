-- Lua provided by RyzenAPI
-- Game: Hentai Cool Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1399450)
-- Game: addappid(1399450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399450,0,"8b1ac44c49675a07deb8964264d866b296026a22c9c883699f45bb5aa4743095")
