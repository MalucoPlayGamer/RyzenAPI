-- Lua provided by RyzenAPI
-- Game: AppID 527540

-- MAIN APPLICATION
addappid(527540)
-- Game: addappid(527540)

-- MAIN APP DEPOTS / PACKAGES
addappid(527541, 1, "bed3b86bb80c8df29b9d6ae8ee14e524b6014bdf246929b2d5bf8d6e4632df95")
