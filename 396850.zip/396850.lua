-- Lua provided by RyzenAPI
-- Game: Chronicles of the Witches and Warlocks

-- MAIN APPLICATION
addappid(396850)

-- MAIN APP DEPOTS / PACKAGES
addappid(396851, 1, "22d438841ab6cfc5b96f7be580c2d3926437c71b7a2db697b6781a2ac63d74f9")
