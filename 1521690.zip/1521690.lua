-- Lua provided by RyzenAPI
-- Game: Lost Robot

-- MAIN APPLICATION
addappid(1521690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521691, 1, "10f621f8168e2dc60421c86b75036a9ebcd5c1e26818156bef0068cd14f87945")
