-- Lua provided by RyzenAPI
-- Game: Lost Robot

-- MAIN APPLICATION
addappid(1521690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521691, 1, "10f621f8168e2dc60421c86b75036a9ebcd5c1e26818156bef0068cd14f87945")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
