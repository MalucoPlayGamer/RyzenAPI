-- Lua provided by RyzenAPI
-- Game: Game: BDSM Fuel Station - interactive physics simulation

-- MAIN APPLICATION
addappid(3339270)
-- Game: addappid(3339270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339271, 1, "55d83394a0d1f0b5f9999a0f27e68466d130f128018640dd66140b2c7554e2ca")
