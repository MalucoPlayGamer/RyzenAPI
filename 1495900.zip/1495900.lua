-- Lua provided by RyzenAPI
-- Game: AppID 1495900

-- MAIN APPLICATION
addappid(1495900)
-- Game: addappid(1495900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495901, 1, "c98d5fea70b98423320267c33b7225d089f20943dabb03c0ee9d0bc282559bc4")
