-- Lua provided by RyzenAPI
-- Game: Crownhold

-- MAIN APPLICATION
addappid(4579940)

-- MAIN APP DEPOTS / PACKAGES
addappid(4579941,0,"b5bb0fd625fa774196db3763b3d8bda17d214e6cf94afaa7fdaa6cbd27938e7d")

