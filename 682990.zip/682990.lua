-- Lua provided by RyzenAPI
-- Game: 682990

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(682990)
-- Game: addappid(682990)

-- MAIN APP DEPOTS / PACKAGES
addappid(682992,0,"52b59e88229b597e044a71ea1391a8bb52efc9f17b744820600007b650b2188c")
