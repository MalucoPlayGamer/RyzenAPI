-- Lua provided by RyzenAPI
-- Game: Sonic Frontiers: Monster Hunter Collaboration Pack

-- MAIN APPLICATION
addappid(2089730)
-- Game: addappid(2089730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089730,0,"dfb354863019c75a8143f9e7073ed589df096057283247fe5e16c1c6225667f2")
