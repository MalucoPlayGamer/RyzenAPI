-- Lua provided by RyzenAPI 
-- Game: Typing Land
addappid(1818940)
addappid(1818941, 1, "3d8a551b00a17b7473e288d7c40772a2e95340f5b91b232f4c572be7a8a02142")
