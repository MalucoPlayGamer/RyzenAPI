-- Lua provided by RyzenAPI
-- Game: 雨上がりのハナビィ Demo

-- MAIN APPLICATION
addappid(889010)
-- Game: addappid(889010)

-- MAIN APP DEPOTS / PACKAGES
addappid(889011, 1, "0e87881b7debacfbe7014375bd3403694c5061e8e9a28202d2bfd81947b514b4")
