-- Lua provided by RyzenAPI
-- Game: The Homestead

-- MAIN APPLICATION
addappid(228985)
addappid(228986)
addappid(228990)
addappid(731950)

-- MAIN APP DEPOTS / PACKAGES
addappid(731952,0,"87940ce440e73265aeeaf7897c091dbbea409a6e89a2457fcfe1b0cdfadd39ae")

