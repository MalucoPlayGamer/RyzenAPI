-- Lua provided by RyzenAPI
-- Game: addappid(3120300)

-- MAIN APPLICATION
addappid(3120300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3120301, 1, "987e481fafb2124813fd5311361c0eb12179da3ee5392ab84134a5e19bbc94a4")
