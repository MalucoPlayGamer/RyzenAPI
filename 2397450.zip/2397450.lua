-- Lua provided by RyzenAPI
-- Game: Dust Raiders

-- MAIN APPLICATION
addappid(2397450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397451, 1, "06e990280be737eee2f5c81fe934359751cf2d40a7d350a39aef945c5f597eec")

