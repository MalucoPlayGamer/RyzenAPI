-- Lua provided by RyzenAPI
-- Game: addappid(1021860)

-- MAIN APPLICATION
addappid(1021860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021861, 1, "9e9b14d981e22573b3a58eec4c96a0f27ec9301b833a6a53f0b4a8708032683f")
addappid(1021862, 1, "afb2f69adb1da65b35fe88f73cf8f6dee0fe67339a54b0f08c614575515a9c5f")
