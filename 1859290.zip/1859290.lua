-- Lua provided by RyzenAPI
-- Game: Crypto Miner Tycoon Simulator

-- MAIN APPLICATION
addappid(1859290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859291, 1, "b8b53a04611a2315b11f45a8fda9e61fce555eb8bcb110921f089258627f9bf4")

