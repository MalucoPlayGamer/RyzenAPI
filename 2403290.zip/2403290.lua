-- Lua provided by RyzenAPI
-- Game: 2403290

-- MAIN APPLICATION
addappid(2403290)
-- Game: addappid(2403290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403291, 1, "feaae982c0d913479fa740be39d5956d7e1efe8cb99b3a8e0b906382f7d40918")
