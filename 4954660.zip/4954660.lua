-- 4954660's Lua and Manifest Created by Hubcap Manifest
-- ALPARGUN
-- Created: August 06, 2026 at 10:55:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4954660) -- ALPARGUN
-- MAIN APP DEPOTS
addappid(4954661, 1, "36246999624a29bc26f913ecdf678f299bd652a23d8812abf92b99fd4bd7adcc") -- Depot 4954661
setManifestid(4954661, "489870586957924458", 7330363768)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)