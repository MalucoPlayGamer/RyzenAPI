-- Lua provided by RyzenAPI
-- Game: Game: Hurricane Abyss

-- MAIN APPLICATION
addappid(3043010)
-- Game: addappid(3043010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043011, 1, "476142a761247e1deb07e8f67378527048bfc39452152db9d873796355f787e5")
