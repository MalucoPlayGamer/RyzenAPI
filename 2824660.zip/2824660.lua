-- Lua provided by RyzenAPI
-- Game: 2824660

-- MAIN APPLICATION
addappid(2824660)
-- Game: addappid(2824660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824661, 1, "60f3ee3e365512571665fdfec50bd3b1c8f2d4e4fb747a610b4a9b6e83aea870")
