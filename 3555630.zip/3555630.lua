-- Lua provided by RyzenAPI
-- Game: Occupy

-- MAIN APPLICATION
addappid(3555630)
-- Game: addappid(3555630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3555631, 1, "c502ca8a426d725911be44b34736726d5657cd3bf451063954c0bdffd9987d96")
