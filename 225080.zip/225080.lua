-- Lua provided by RyzenAPI
-- Game: AppID 225080

-- MAIN APPLICATION
addappid(225080)
addappid(228983)
addappid(228990)
addappid(229003)
-- Game: addappid(225080)

-- MAIN APP DEPOTS / PACKAGES
addappid(225081, 1, "37eed7b9e8cef8298da022f816a11a8660f0f6094291370f5419f4708542baed")
