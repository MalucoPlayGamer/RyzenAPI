-- Lua provided by RyzenAPI
-- Game: AppID 1303760

-- MAIN APPLICATION
addappid(1303760)
-- Game: addappid(1303760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303761, 1, "ed605f7ef1a14a51fba3a39e92528197e8ed521a25e441ab0ba3f922c79e86f3")
