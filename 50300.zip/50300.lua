-- Lua provided by RyzenAPI
-- Game: Spec Ops: The Line

-- MAIN APPLICATION
addappid(50300)
addappid(203181)
addappid(203186)
addappid(203187)
addappid(203188)

-- MAIN APP DEPOTS / PACKAGES
addappid(50301, 1, "183bb5015eea47ed29938bfbbc83fe3697775fdc1529a7e8e1634c883960a7c8")
addappid(50302, 1, "86c7acfb6722cdec82871283c49a16a74b63cf1d6d1ab821557f4b2c6cf47941")
addappid(50303, 1, "787e8423199e3889c4fa6edfd848ea0a9fe138e0d5b73f971ba1b204e6c5d56f")
addappid(50304, 1, "0436e7aff84b7bb74b492123db22a0358de0e2b184ca0fe1c0c2bb838d3549ef")
addappid(50305, 1, "10931a8f64e4fa5afc9d2c496b30961dd73c93567bb7ed7a22a4cbe7af7492c5")
addappid(50306, 1, "96e139ddaac3c8aea5fc2dc7d75055926f6c222d5a5a753cb5e5655455d1b92c")
addappid(50307, 1, "28e4e0a171b728a6eb38f87b631be1702784b0479496acfc03bfc333525a4680")
addappid(50308, 1, "a9069aa0ea66fd5952d78661254de0591d1e947c98fb9bd9f20c5234ffd81158")
addappid(50309, 1, "8ef85a17066ec6e667cecc26c4f43cdef8b53546346378cb5187c11a682c36a4")
addappid(203180, 0, "3399e4fe5f7ce92a9a9fc69b121708268dce78c0f52b3b1a890f2c668a757fb7")
addappid(203185, 0, "ebd77b785fc186b312bedc5446eb955196b866e14a60c8a8c6ab723765232a7c")
addappid(203189, 0, "c38ce46581e6a705af9777c0138e51d51a153b18022d1d02bc1ba3a8718b45c0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(203182)
addappid(203183)
addappid(203184)
