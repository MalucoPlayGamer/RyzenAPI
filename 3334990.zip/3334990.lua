-- Lua provided by RyzenAPI
-- Game: Relicbound

-- MAIN APPLICATION
addappid(3334990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3334991,0,"3b23142222bbd5850c67ac9112e922195b0117217773cdab560650dfc8ae4505")

