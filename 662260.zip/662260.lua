-- Lua provided by RyzenAPI
-- Game: AppID 662260

-- MAIN APPLICATION
addappid(662260)
addappid(800260)
addappid(800261)

-- MAIN APP DEPOTS / PACKAGES
addappid(662261, 1, "1312a03b3e204b922932ffd9596a20f8106ff47c767ae0cd02f2526c9c7c9df8")

