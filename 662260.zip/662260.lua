-- Lua provided by RyzenAPI
-- Game: 662260

-- MAIN APPLICATION
addappid(662260)
-- Game: addappid(662260)

-- MAIN APP DEPOTS / PACKAGES
addappid(662261, 1, "1312a03b3e204b922932ffd9596a20f8106ff47c767ae0cd02f2526c9c7c9df8")
