-- Lua provided by RyzenAPI
-- Game: Secret of Mana

-- MAIN APPLICATION
addappid(637670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(637671, 1, "93cca6ab448250e7ee144fd47c729c8f4f14632b14ac4139d63d95f9d74978bf")
addappid(768210, 0, "3c28c40c4319834851ed703fa60aef6c520bda2bde6023da2a81f6c4beae8f65")
addappid(768220, 0, "0fd324aff9a0913a76482040fdc6a411147b23c0e330c1b7c572c8cbb0eff87b")
addappid(770420, 0, "454a6c1e7c052ffd8236f304c50e5819e5715bb618e6a0ca79b0cae3b9398740")

