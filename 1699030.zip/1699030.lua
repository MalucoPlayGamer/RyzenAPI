-- Lua provided by RyzenAPI
-- Game: addappid(1699030)

-- MAIN APPLICATION
addappid(1699030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699032,0,"7bf0686231995b98b5ecd0a658cb5b2b0736d3007032876365edfbd60d9bda61")
