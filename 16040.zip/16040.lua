-- Lua provided by RyzenAPI
-- Game: Luxor: Quest for the Afterlife

-- MAIN APPLICATION
addappid(16040)

-- MAIN APP DEPOTS / PACKAGES
addappid(16041, 1, "85b28c2237d11a137199ef7580034d36ae12be2f3036efefba41a835fe12aa14")

