-- Lua provided by RyzenAPI
-- Game: 捉妖物语2 - Full edition

-- MAIN APPLICATION
addappid(2267700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267701, 1, "56d2f2ef5fcaf13ebeb6775b46ae45a585308d14e832248254fd1009a29f8c1a")

