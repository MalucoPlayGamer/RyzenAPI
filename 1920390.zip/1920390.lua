-- Lua provided by RyzenAPI
-- Game: addappid(1920390)

-- MAIN APPLICATION
addappid(1920390)
addappid(1930690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920391, 1, "fc51b804cabb8b130b9ab480895001ed51c814324b9c45045c01694ad9159dc9")
