-- Lua provided by RyzenAPI
-- Game: Major Mayhem

-- MAIN APPLICATION
addappid(264340)
-- Game: addappid(264340)

-- MAIN APP DEPOTS / PACKAGES
addappid(264341, 1, "809378b2ee53c0120d8dd97d0c409ac8e8da776f8e06ff8e10d76f41885ab10a")
addappid(264342, 1, "80b83c93e587847c6b25a3662e2255dd64b36011508c79f0611d054bbb71c5c2")
addappid(264343, 1, "f1a3b873c3efd29230708ed28579fca30042034ea93bcb6e90423be536f6c0ef")
