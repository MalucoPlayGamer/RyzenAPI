-- Lua provided by RyzenAPI
-- Game: Draft Day Sports: Pro Football 2018

-- MAIN APPLICATION
addappid(782510)

-- MAIN APP DEPOTS / PACKAGES
addappid(782511,0,"a7cff7efc0e43e58c846a63c9c5427a844d058be024f6029f00353de6d819726")

