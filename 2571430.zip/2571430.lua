-- Lua provided by RyzenAPI
-- Game: addappid(2571430)

-- MAIN APPLICATION
addappid(2571430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571431, 1, "77a56f02d78607a79ed02bd63c09bdbacbacbf8a59df3b6836a57b0705c6c901")
