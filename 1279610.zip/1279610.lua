-- Lua provided by RyzenAPI
-- Game: PrprLive

-- MAIN APPLICATION
addappid(1279610)
addappid(1333210)
addappid(1336780)
addappid(1343320)
addappid(1361080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1279611, 1, "9725bbf9a24784484f79ec0d6444cb06c6340cf1550712c9972c6226d8ee87bf")
addappid(1279613, 1, "7f8880052ffc16e1f6dcc798e7477273b2316cff2323594254c9a9d6f94296d0")

