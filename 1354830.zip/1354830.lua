-- Lua provided by RyzenAPI
-- Game: Cat Cafe Manager

-- MAIN APPLICATION
addappid(1354830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1354831, 1, "f849a17da3ee9078feec79c8da9995bf38c42e64ef08f5aff87851c49b1ef801")

