-- Lua provided by RyzenAPI
-- Game: Uncover the Smoking Gun

-- MAIN APPLICATION
addappid(2492290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492291, 1, "316f908ad8f03620eb92fe2cc77bd7967ebe8a4ad094b2cbec81e13fd597857e")
