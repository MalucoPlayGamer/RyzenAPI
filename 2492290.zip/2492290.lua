-- Lua provided by RyzenAPI
-- Game: Uncover the Smoking Gun

-- MAIN APPLICATION
addappid(2492290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2492291, 1, "316f908ad8f03620eb92fe2cc77bd7967ebe8a4ad094b2cbec81e13fd597857e")

