-- Lua provided by SkyAPI 
-- Game: The Stones
addappid(3506030)
addappid(3506031, 1, "d9a5edcd6a7d9249539cf1cb968b2f7064278c17e332059dc2f3a89bc5d96a22")
