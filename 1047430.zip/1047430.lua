-- Lua provided by RyzenAPI
-- Game: Game: AppID 1047430

-- MAIN APPLICATION
addappid(1047430)
-- Game: addappid(1047430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047431, 1, "d6122fb06a0923939ad63ac552446a7e67d633b515a356bd5b58f3bb9b377dd8")
