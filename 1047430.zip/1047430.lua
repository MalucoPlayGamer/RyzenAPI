-- Lua provided by SkyAPI 
-- Game: AppID 1047430
addappid(1047430)
addappid(1047431, 1, "d6122fb06a0923939ad63ac552446a7e67d633b515a356bd5b58f3bb9b377dd8")
