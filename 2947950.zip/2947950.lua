-- Lua provided by RyzenAPI
-- Game: Game: AppID 2947950

-- MAIN APPLICATION
addappid(2947950)
-- Game: addappid(2947950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947951, 1, "83e1e0aedffc02089cd28db493ddace14db2f081c0a707a7b7642f5df5924668")
