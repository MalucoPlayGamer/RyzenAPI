-- Lua provided by RyzenAPI 
-- Game: AppID 2947950
addappid(2947950)
addappid(2947951, 1, "83e1e0aedffc02089cd28db493ddace14db2f081c0a707a7b7642f5df5924668")
