-- Lua provided by RyzenAPI
-- Game: Pape Rangers

-- MAIN APPLICATION
addappid(2812820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812821, 1, "40de8bd5ee68011deff53591dcf5a4da8b60465cb446b57346155393588887c0")

