-- Lua provided by RyzenAPI
-- Game: Zigglox

-- MAIN APPLICATION
addappid(1514880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1514881, 1, "3574627a366fe03ea965bd7af9232fefd590518a59c41a47946c34becb41acfb")
