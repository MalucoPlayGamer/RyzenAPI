-- Lua provided by RyzenAPI
-- Game: Game: Hide Alone

-- MAIN APPLICATION
addappid(2024300)
-- Game: addappid(2024300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024301, 1, "f6a5dddacb217e8e27825be30522992a3a2248e02b39c805c6ace4f4d997e941")
