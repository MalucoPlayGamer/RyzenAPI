-- Lua provided by RyzenAPI
-- Game: TAGLINE

-- MAIN APPLICATION
addappid(1921470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1921471, 1, "2dd63d54b8ae84673525dafee70010ca4f2aa9b8cc0df89f1149ec7d3cd2cd89")

