-- Lua provided by RyzenAPI
-- Game: TAGLINE

-- MAIN APPLICATION
addappid(1921470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921471, 1, "2dd63d54b8ae84673525dafee70010ca4f2aa9b8cc0df89f1149ec7d3cd2cd89")

