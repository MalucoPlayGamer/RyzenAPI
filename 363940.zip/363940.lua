-- Lua provided by RyzenAPI
-- Game: Game: Solar Shifter EX

-- MAIN APPLICATION
addappid(363940)
-- Game: addappid(363940)

-- MAIN APP DEPOTS / PACKAGES
addappid(363941, 1, "0bdf67fd605e2ec855b55ebf123b938175f28d0f1a63934970af021f4b424875")
addappid(363942, 1, "dbc416b115c4a93de9c29475dbee0289b6a5315fd2fa4c685be10ef49249951c")
addappid(363943, 1, "0417ba279acdde7aeb8b306e18d9c7e528a45843e7b8889cbb8fc2ce739ed6d0")
addappid(400770, 0, "c1d092cb12746b278b5a28c4094441e06db7f7826350a078ec618f751a9cd84c")
