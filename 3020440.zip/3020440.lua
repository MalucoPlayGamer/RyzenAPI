-- Lua provided by RyzenAPI 
-- Game: NETHER HEROES Soundtrack
addappid(3020440)
addappid(3020441, 1, "3689314ee3f05a1d51325a68d831bdefb0845cd6840b306790391f78d65aac48")
