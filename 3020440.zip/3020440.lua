-- Lua provided by RyzenAPI
-- Game: Game: NETHER HEROES Soundtrack

-- MAIN APPLICATION
addappid(3020440)
-- Game: addappid(3020440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020441, 1, "3689314ee3f05a1d51325a68d831bdefb0845cd6840b306790391f78d65aac48")
