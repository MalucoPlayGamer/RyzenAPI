-- Lua provided by RyzenAPI
-- Game: PROJECT MAZE

-- MAIN APPLICATION
addappid(659220)
addappid(1146200)
-- Game: addappid(659220)

-- MAIN APP DEPOTS / PACKAGES
addappid(659221, 1, "ce705a2970ab2b80ec4191ff33a03559a062a02047be9a559f09f32ebd40408c")
