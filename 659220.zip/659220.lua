-- Lua provided by RyzenAPI
-- Game: PROJECT MAZE

-- MAIN APPLICATION
addappid(659220)
addappid(690300)
addappid(1146200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(659221, 1, "ce705a2970ab2b80ec4191ff33a03559a062a02047be9a559f09f32ebd40408c")

