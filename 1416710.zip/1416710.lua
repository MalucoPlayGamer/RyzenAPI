-- Lua provided by RyzenAPI
-- Game: Game: Strip Black Jack - At The Pub

-- MAIN APPLICATION
addappid(1416710)
-- Game: addappid(1416710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416711, 1, "1f993ae4bbe4c4d1e149cbd2fe4dfbaa36c5b0bd47e9d3c07657394afb310168")
