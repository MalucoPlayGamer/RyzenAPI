-- Lua provided by SkyAPI 
-- Game: sword story
addappid(1194230)
addappid(1194231, 1, "e9d4ef53aadd4eb4255ab2d5490a01216395226a1ad26d0f211b2c2f7bbaa653")
