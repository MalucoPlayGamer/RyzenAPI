-- Lua provided by RyzenAPI
-- Game: 1194230

-- MAIN APPLICATION
addappid(1194230)
-- Game: addappid(1194230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194231, 1, "e9d4ef53aadd4eb4255ab2d5490a01216395226a1ad26d0f211b2c2f7bbaa653")
