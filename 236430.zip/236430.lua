-- Lua provided by RyzenAPI
-- Game: DARK SOULS™ II

-- MAIN APPLICATION
addappid(228982)
addappid(228983)
addappid(236430)

-- MAIN APP DEPOTS / PACKAGES
addappid(236432,0,"eda018a11af0a6a37b59a60dadcbfca12bd721227868fcff4053b8b85e67bd05")
addappid(271940,0,"591c3310fabae8ea378bcd7de0d2d6e51021ff65de92140c0869f2a90df0e3ce")
addappid(271941,0,"e6c617c30eb9d95791592e9fb5200627d32cb74264e74e58d55ffd04d01b0ff6")
addappid(271942,0,"a1965b62e56b19e4ff236ec31cef3b501ea253fd4d0f958b9f3db502e7e92e86")
addappid(271943,0,"03066e42170eb2798cc95b53972b74fc6ad4e994b1f0ad1c62720136abbd954a")
addappid(271944,0,"cce41eba79f1afc8fe13f0c97724e9bf9e1fbe22782a2eb17582fdc3a8b5780e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(284450)
addappid(287360)
addappid(287770)
addappid(287771)
addappid(289120)
addappid(289121)
addappid(289122)
addappid(355700)
