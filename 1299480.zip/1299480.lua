-- Lua provided by RyzenAPI
-- Game: The Fabled Woods

-- MAIN APPLICATION
addappid(1299480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299481, 1, "f08a09e48dea02295da64ab573a3aa7ae9a1f4b7c6e9c92ce48fc9d5a59f3c1e")
addappid(1573671, 0, "3b2e293b27cba3933afc5a57c85884ae771c799c521ba5098c3f0cc04a3386d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1573670)
