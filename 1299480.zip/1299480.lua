-- Lua provided by RyzenAPI
-- Game: addappid(1299480)

-- MAIN APPLICATION
addappid(1299480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299481, 1, "f08a09e48dea02295da64ab573a3aa7ae9a1f4b7c6e9c92ce48fc9d5a59f3c1e")
addappid(1573671, 0, "3b2e293b27cba3933afc5a57c85884ae771c799c521ba5098c3f0cc04a3386d7")
