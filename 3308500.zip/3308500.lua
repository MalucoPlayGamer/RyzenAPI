-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Another World Hero Generator 3 for MZ

-- MAIN APPLICATION
addappid(3308500)
-- Game: addappid(3308500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308500,0,"bd9363917915438326f93b319ebcaceeba4446c004989534424c361c1e9496f4")
