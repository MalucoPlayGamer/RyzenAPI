-- Lua provided by RyzenAPI
-- Game: 1371660

-- MAIN APPLICATION
addappid(1371660)
-- Game: addappid(1371660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371662,0,"e0656073bf78f838a59cb9d6082e55cee9e782da3c5aba852d11b62fb5872820")
