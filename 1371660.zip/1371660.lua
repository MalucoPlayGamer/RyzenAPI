-- Lua provided by RyzenAPI
-- Game: Time For You - Chapter 01

-- MAIN APPLICATION
addappid(1371660)
addappid(1574140)
addappid(1629090)
addappid(1630220)
addappid(1630230)
addappid(1630240)
addappid(1630260)
addappid(2187410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1371662,0,"e0656073bf78f838a59cb9d6082e55cee9e782da3c5aba852d11b62fb5872820")

