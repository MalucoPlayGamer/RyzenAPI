-- Lua provided by RyzenAPI
-- Game: G String

-- MAIN APPLICATION
addappid(1224600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224601, 1, "d2c2881173fc134920609edb36c4977009731be277efab497b197e39eb6dda51")
