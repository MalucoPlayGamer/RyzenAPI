-- Lua provided by RyzenAPI
-- Game: 創業王 CEO

-- MAIN APPLICATION
addappid(2269460)
-- Game: addappid(2269460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269461, 1, "7259b82704dab129d55a1f39360e7a3c8d2fc43d853d6bb521ce97d647910878")
