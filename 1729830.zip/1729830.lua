-- Lua provided by RyzenAPI
-- Game: Tactical Monsters - Strategy Edition

-- MAIN APPLICATION
addappid(1729830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729831, 1, "add54d30465e5831e517419ac9e4dfc5cca9d35aafe448d5223f105a7089e99f")
addappid(1729832, 1, "f323872a4bdd76730ad00b2bd1609381a2b1d8aab10b592cbcddd58188f9bafd")

