-- Lua provided by RyzenAPI
-- Game: addappid(3374720)

-- MAIN APPLICATION
addappid(3374720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3374721, 1, "28dd8bb14e71b58196601970f55da06dac5e13330dba028f93fcfddee54f4714")
