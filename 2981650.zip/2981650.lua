-- Lua provided by RyzenAPI
-- Game: AppID 2981650

-- MAIN APPLICATION
addappid(2981650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981651, 1, "a79e0aa888568ceb3efa745153fc75fcf795e9dd8fc774764c1f96b2cfc95ed1")
addappid(2981652, 1, "13ffa84bcefc222b01f4551d314c857d9a7c2bce969493e25365b9dc53d457f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
