-- Lua provided by RyzenAPI
-- Game: 2981650

-- MAIN APPLICATION
addappid(2981650)
-- Game: addappid(2981650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981651, 1, "a79e0aa888568ceb3efa745153fc75fcf795e9dd8fc774764c1f96b2cfc95ed1")
addappid(2981652, 1, "13ffa84bcefc222b01f4551d314c857d9a7c2bce969493e25365b9dc53d457f9")
