-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1635390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635390,0,"7d07c9f6135c7d54d23929932d16ecc91b9a998893ff4e785f21339c23c4ed21")
