-- Lua provided by RyzenAPI
-- Game: Cobalt Core

-- MAIN APPLICATION
addappid(2179850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179851, 1, "bc615c0333a243446cace8a2e902062b5450891478f8a8468c419bca793be235")
