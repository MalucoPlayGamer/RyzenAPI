-- Lua provided by RyzenAPI
-- Game: Furry Shades of Gay 2: A Shade Gayer

-- MAIN APPLICATION
addappid(1724050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724051, 1, "ae9d0aef9d7ab238bb06468f0803859cc281bc34cf64073bc0bc0f00c8479c30")
addappid(1834610, 0, "b726b69150549cc11cce2713cb235feb69a836e28755d7d44ac53b2ea91234fd")
addappid(2403220, 0, "94ab508cd353c96991e6b420ce2c206695fca4807c345c1408a2c45cb40e6f31")

