-- Lua provided by RyzenAPI
-- Game: 787250

-- MAIN APPLICATION
addappid(787250)
-- Game: addappid(787250)

-- MAIN APP DEPOTS / PACKAGES
addappid(787251, 1, "5579ccda97b0f649f403e47f050b2801f9ff0facff536a97f9882aede42fabf9")
