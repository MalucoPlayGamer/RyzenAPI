-- Lua provided by RyzenAPI
-- Game: 415350

-- MAIN APPLICATION
addappid(415350)
-- Game: addappid(415350)

-- MAIN APP DEPOTS / PACKAGES
addappid(415351, 1, "934c464fe29f4b4ab7ae22acef502a10c287513bd61aab5a5f3cbe9e43bd95ce")
addappid(415352, 1, "28fc8dddbf171d8cf784d37b46e597dbbd8b47d8362ee7f400c450fac8bfa116")
addappid(415353, 1, "5013a06d5fcb0eaa9dd1784543ab999cd041cf483bde75aac0d4d750c15420e0")
