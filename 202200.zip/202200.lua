-- Lua provided by RyzenAPI
-- Game: Galactic Civilizations® II: Ultimate Edition

-- MAIN APPLICATION
addappid(202200)
-- Game: addappid(202200)

-- MAIN APP DEPOTS / PACKAGES
addappid(202201, 1, "1f8e3e8e8563a2e639ad96a5be54ec39d2aa1f820296d8cb48b8b7ee78898c69")
