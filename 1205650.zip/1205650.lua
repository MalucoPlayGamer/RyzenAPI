-- Lua provided by RyzenAPI
-- Game: i Have Powers!

-- MAIN APPLICATION
addappid(1205650)
-- Game: addappid(1205650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205651, 1, "7e4f0f102d829873b3827e70d4f2f7531d147e6b61d53b129470f4e2d18814ba")
