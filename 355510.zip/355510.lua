-- Lua provided by RyzenAPI
-- Game: Crazy Belts

-- MAIN APPLICATION
addappid(355510)

-- MAIN APP DEPOTS / PACKAGES
addappid(355511, 1, "5cc9c3979f21a56c026f72691b6860c0d0f1b8bc095c7dbed563237a2489f910")
