-- Lua provided by RyzenAPI
-- Game: Sorcery and Survival

-- MAIN APPLICATION
addappid(3730670)
-- Game: addappid(3730670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3730671, 1, "36749f054ad77dda76c35ba353a806231f8e0e807cfe608fcb2a21916e35c973")
