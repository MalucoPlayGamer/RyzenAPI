-- Lua provided by RyzenAPI 
-- Game: MUMMMASTER!
addappid(1489480)
addappid(1489481, 1, "e095673e8dfc856653e3b081a7e983bf95106d690429b0ea119e4b2205647a01")
