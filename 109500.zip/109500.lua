-- Lua provided by RyzenAPI
-- Game: 109500

-- MAIN APPLICATION
addappid(109500)
-- Game: addappid(109500)

-- MAIN APP DEPOTS / PACKAGES
addappid(109503,0,"8a7a7da05fcfb54a1659d4b08ee0cb7788be513725dfe26eaf887b59a4de17f1")
