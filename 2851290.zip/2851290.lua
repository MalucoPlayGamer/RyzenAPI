-- Lua provided by SkyAPI 
-- Game: Pilapila
addappid(2851290)
addappid(2851291, 1, "629f754fff01aab1c646a09b28710cb67e63f35a1e510a4abed8a817c557d252")
