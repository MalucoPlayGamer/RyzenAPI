-- Lua provided by RyzenAPI
-- Game: Apollo 11 VR

-- MAIN APPLICATION
addappid(457860)

-- MAIN APP DEPOTS / PACKAGES
addappid(457861, 1, "79c28b3e81d1f8d8c8ce67a5f2e9f72ddadffa7f49f9d233a094dd2be5d3df28")
