-- Lua provided by RyzenAPI
-- Game: WTF Is Wrong With You?

-- MAIN APPLICATION
addappid(1640720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1640721, 1, "05ff0874e035a59d8503853362aa5d4d527db5fc81e33417808789bb4fb8d96c")

