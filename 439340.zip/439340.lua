-- Lua provided by RyzenAPI
-- Game: Tavern Tycoon - Dragon's Hangover

-- MAIN APPLICATION
addappid(439340)

-- MAIN APP DEPOTS / PACKAGES
addappid(439341, 1, "1f1fe808e56986118525e8995730db418c0a04e7a055e4aa30fe475369d727e5")
