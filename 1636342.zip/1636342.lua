-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1636342)
-- Game: addappid(1636342)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636342,0,"4dadf713009191cba9e0739cc89b813e89c215a92bdfffe3ad08cd3f6ac7fb9f")
