-- Lua provided by RyzenAPI
-- Game: Shattered Legacy

-- MAIN APPLICATION
addappid(2409790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409791, 1, "9f15a44a0433b35f76031e83bb6dbe4d3ad6753df87da68e04039d7815ab2058")

