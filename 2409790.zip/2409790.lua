-- Lua provided by RyzenAPI
-- Game: Shattered Legacy

-- MAIN APPLICATION
addappid(2409790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2409791, 1, "9f15a44a0433b35f76031e83bb6dbe4d3ad6753df87da68e04039d7815ab2058")

