-- Lua provided by RyzenAPI
-- Game: Nickelodeon Kart Racers 2: Grand Prix

-- MAIN APPLICATION
addappid(1383960)
-- Game: addappid(1383960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383961, 1, "3fee5819de14f7418fae7500e0cc8431c5ee377bf5ae7071ef1ff0e15ba0e786")
