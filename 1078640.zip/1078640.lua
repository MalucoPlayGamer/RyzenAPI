-- Lua provided by RyzenAPI
-- Game: Eggoria

-- MAIN APPLICATION
addappid(1078640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078641, 1, "a026d081ded4fc3830229391df436a0cb6fe93912922a5191b3f1e0a607b97ca")
