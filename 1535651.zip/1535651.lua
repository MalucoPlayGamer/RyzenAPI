-- Lua provided by RyzenAPI
-- Game: addappid(1535651)

-- MAIN APPLICATION
addappid(1535651)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535651,0,"1b7e33ab85d576d7375023f1c4daf3d3730fd9aea49d9292a8d440d146d9a42b")
