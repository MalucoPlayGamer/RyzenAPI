-- Lua provided by RyzenAPI 
-- Game: Endless Boss Fight
addappid(1676150)
addappid(1676151, 1, "1d5ee90d7cfa746979fd2004ffa1cb351bade830a99726452833731c6c55cccd")
