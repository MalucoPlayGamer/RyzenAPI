-- Lua provided by RyzenAPI
-- Game: Endless Boss Fight

-- MAIN APPLICATION
addappid(1676150)
-- Game: addappid(1676150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676151, 1, "1d5ee90d7cfa746979fd2004ffa1cb351bade830a99726452833731c6c55cccd")
