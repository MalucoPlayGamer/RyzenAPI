-- Lua provided by SkyAPI 
-- Game: Rogue Blight Demo
addappid(2336830)
addappid(2336831, 1, "32daa9ea254b6c2d68464d99888d25b67a4a9a4f073da0261889c18244f0e2e5")
