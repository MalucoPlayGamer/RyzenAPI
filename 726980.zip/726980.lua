-- Lua provided by RyzenAPI
-- Game: Cyber Warrior

-- MAIN APPLICATION
addappid(726980)

-- MAIN APP DEPOTS / PACKAGES
addappid(726981, 1, "72b7811c663738f65357f04ed2d89bd59b91ade9c13ebccb422052137f2c3170")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
