-- Lua provided by RyzenAPI
-- Game: Game: Cyber Warrior

-- MAIN APPLICATION
addappid(726980)
-- Game: addappid(726980)

-- MAIN APP DEPOTS / PACKAGES
addappid(726981, 1, "72b7811c663738f65357f04ed2d89bd59b91ade9c13ebccb422052137f2c3170")
