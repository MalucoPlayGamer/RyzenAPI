-- Lua provided by RyzenAPI
-- Game: Lovely Planet

-- MAIN APPLICATION
addappid(298600)

-- MAIN APP DEPOTS / PACKAGES
addappid(298601, 1, "7bfe86a851d0084b323659571f3c82521feb838d970776591943d537cb5b5ab5")
addappid(298602, 1, "c5f1608426d20c53ee89ac4db8cc5547ad7df81e17ea9d31a2c4289c82ebb01c")
addappid(298603, 1, "2a0b1b55752423239b99df25b7f9b3d48f4807f2ebff6107ae534ac868d1f7c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
