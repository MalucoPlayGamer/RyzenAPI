-- Lua provided by RyzenAPI
-- Game: Strategic War in Europe

-- MAIN APPLICATION
addappid(283000)

-- MAIN APP DEPOTS / PACKAGES
addappid(283001, 1, "6ddaafb0209a45b053364e036e6456e89725de20a885570b41f2897d1dffc695")
addappid(283002, 1, "c9f1a566e7f6f2c00d106664b19fb165d4abef425ff89b2fe7e3d4bf1b1d0b18")
addappid(283003, 1, "062f34ed5146f408310b1fd1e75e4640c03b70aa9843b3b8b0ad5eb8ce5cf97d")
addappid(283004, 1, "6ba5073f6968ddfd7c0339d18d6fb1816867b240da424d88c9ee939570e01460")
