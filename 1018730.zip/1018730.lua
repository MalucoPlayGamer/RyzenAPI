-- Lua provided by RyzenAPI
-- Game: AppID 1018730

-- MAIN APPLICATION
addappid(1018730)
-- Game: addappid(1018730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018731, 1, "557a497c4f46de1b6dac7a5d5e4981a7f0ee9f538697d62888be4eab876f74e3")
