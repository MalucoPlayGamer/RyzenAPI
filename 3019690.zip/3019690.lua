-- Lua provided by RyzenAPI
-- Game: Game: Rise of Kenshin Demo

-- MAIN APPLICATION
addappid(3019690)
-- Game: addappid(3019690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3019691, 1, "78b0b19fbf7f0ef6910567bc422dbade563e6ca9d34786602f34700b35a73189")
