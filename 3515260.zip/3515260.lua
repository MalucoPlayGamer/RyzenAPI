-- Lua provided by RyzenAPI
-- Game: 3515260

-- MAIN APPLICATION
addappid(3515260)
-- Game: addappid(3515260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515261, 1, "24dda728bb8073ed0560968ef82a61bda2c2b9f602d3f189dea2b3180647e4b1")
