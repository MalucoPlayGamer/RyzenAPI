-- Lua provided by RyzenAPI
-- Game: Game: Prison Run and Gun Demo

-- MAIN APPLICATION
addappid(1973180)
-- Game: addappid(1973180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973181, 1, "481a292fc47c131de99920cfe3d5d935e3d65cd845be48637ad68e19215638d0")
