-- Lua provided by RyzenAPI
-- Game: 933533

-- MAIN APPLICATION
addappid(933533)
-- Game: addappid(933533)

-- MAIN APP DEPOTS / PACKAGES
addappid(933533,0,"1142a199c20c6f738a9d574dfab29202507fdcad78a7e1cb5b46d61255394346")
