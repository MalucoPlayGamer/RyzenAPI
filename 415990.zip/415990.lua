-- Lua provided by SkyAPI 
-- Game: AppID 415990
addappid(415990)
addappid(415991, 1, "de0454c87c7887d2a0b2fbd6603a5d43d781441bfdcc7bddf84cd5b52bfc02f8")
addappid(415994, 1, "65e29bdbc479af1181d1d00872ca77008059836034fa6d7d4ce801c58a7e3d4b")
addappid(415995, 1, "0d1dad734b6a5cd35fe73bfa8861ac0c173a18766218eff852b7bf9228b203f5")
