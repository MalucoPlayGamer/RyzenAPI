-- Lua provided by RyzenAPI
-- Game: Withering Rooms

-- MAIN APPLICATION
addappid(2006140)
-- Game: addappid(2006140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2006141, 1, "86248995e5b0957c4bf242c3c8b675c4e5961445c38530eab5a49080dca9b282")
