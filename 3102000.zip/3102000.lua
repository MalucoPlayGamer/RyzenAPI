-- Lua provided by RyzenAPI
-- Game: Game: Madness inside

-- MAIN APPLICATION
addappid(3102000)
-- Game: addappid(3102000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3102001, 1, "79d5dd1dc27a4e8f7e0b1b85a349931f99ac0b937635a42d6dfc82926a4fecd3")
