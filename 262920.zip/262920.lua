-- Lua provided by RyzenAPI
-- Game: Super Chain Crusher Horizon

-- MAIN APPLICATION
addappid(262920)

-- MAIN APP DEPOTS / PACKAGES
addappid(262921, 1, "6eb97584feca89694da72255dd8553d330ef583cbf37cd02bc269db4f5405a28")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
