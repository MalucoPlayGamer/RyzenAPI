-- Lua provided by RyzenAPI
-- Game: Game: Super Chain Crusher Horizon

-- MAIN APPLICATION
addappid(262920)
-- Game: addappid(262920)

-- MAIN APP DEPOTS / PACKAGES
addappid(262921, 1, "6eb97584feca89694da72255dd8553d330ef583cbf37cd02bc269db4f5405a28")
