-- Lua provided by RyzenAPI
-- Game: AppID 55100

-- MAIN APPLICATION
addappid(55100)

-- MAIN APP DEPOTS / PACKAGES
addappid(55101, 1, "dfc944e966b55ec196f81516d517aef2eea598c50b0f53a749c8ad46e38e4d1d")
addappid(55102, 1, "5eedf45bc96fb030ed232bf919314259a98c5921e76c00be4a48f825b81f463d")
addappid(55103, 1, "02b74dfd091fb3250270bd03f8ab50756f02679bedef4fb9657b3523a7db223a")
addappid(55104, 1, "b5d7086499381c054653c3f2faab11cdf8877b7cabadc742bb4170224768b259")
addappid(55105, 1, "0f565f3bba8702f4e8da994d5b7d7aeeba28de85cce94abade3455c0e0f77264")
addappid(55106, 1, "67951f33c15fb7d97013c1ec537d46d64879eb0548eeb46cfebe2ec02516fba9")
addappid(55107, 1, "874ae5a64b5b328d9e3667946f32bd562d61e21a5eb9ac7f00aa0cd1ff8b96b9")
addappid(55108, 1, "04603bc07905ef8c5cd4b6a3362e2a08b0e054de6cd53b676a199c46af5a210a")
addappid(55109, 1, "b8efe3d51d8fde67d168eff0024ebfc367a342e0c34b0fe3dbf0e02b801f57fd")
addappid(55202, 0, "26ec7d11c69cad564f561ecc40b513e9a9a7a025686cf54122ef4ba56ceb478f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(55203)
addappid(55204)
addappid(55205)
addappid(55206)
addappid(55207)
addappid(55208)
