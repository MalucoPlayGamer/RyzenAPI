-- Lua provided by RyzenAPI 
-- Game: LIV
addappid(755540)
addappid(755541, 1, "aacf4771546ab0328517855394f2f2283e1463a5ec0eecfbbc0f5cd4908437e6")
