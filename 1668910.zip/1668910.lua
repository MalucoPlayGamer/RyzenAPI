-- Lua provided by SkyAPI 
-- Game: AppID 1668910
addappid(1668910)
addappid(1668911, 1, "94daa31b1ac3e812b52baa64ae3c8ae7a8d768c28a348858282ec8fd804cf9f6")
