-- Lua provided by RyzenAPI
-- Game: 1668910

-- MAIN APPLICATION
addappid(1668910)
-- Game: addappid(1668910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668911, 1, "94daa31b1ac3e812b52baa64ae3c8ae7a8d768c28a348858282ec8fd804cf9f6")
