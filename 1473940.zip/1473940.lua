-- Lua provided by RyzenAPI
-- Game: MultiVerse

-- MAIN APPLICATION
addappid(1473940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473941, 1, "839d40e885f2a8053e54d936206f0df68f69258665383f3127215e085182bb7f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
