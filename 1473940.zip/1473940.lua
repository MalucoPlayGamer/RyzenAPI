-- Lua provided by RyzenAPI
-- Game: MultiVerse

-- MAIN APPLICATION
addappid(1473940)
-- Game: addappid(1473940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473941, 1, "839d40e885f2a8053e54d936206f0df68f69258665383f3127215e085182bb7f")
