-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2617770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617770,0,"e69446c7b51abdb0dfece40ed6fa4bcbdb82a7e824906cbdff23f22fbb31dd81")
