-- Lua provided by RyzenAPI
-- Game: addappid(1857950)

-- MAIN APPLICATION
addappid(1857950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857952,0,"0f09efc4c8566ce587f3329874cc02f750a58ad24fa6d30c8154b1b95cf2f050")
