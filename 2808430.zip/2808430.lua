-- Lua provided by RyzenAPI
-- Game: addappid(2808430)

-- MAIN APPLICATION
addappid(2808430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808431, 1, "4589068334c41bee2fb673979dc9cded2e4ab61585bb2a009b268d921289fd01")
