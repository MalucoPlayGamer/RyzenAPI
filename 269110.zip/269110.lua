-- Lua provided by RyzenAPI
-- Game: Game: AppID 269110

-- MAIN APPLICATION
addappid(269110)
addappid(281780)
-- Game: addappid(269110)

-- MAIN APP DEPOTS / PACKAGES
addappid(269111, 1, "60b86540f794c8a52492ef377019dfdc196c1b3055d8077a5ba278f90a4f56cc")
