-- Lua provided by RyzenAPI
-- Game: AppID 269110

-- MAIN APPLICATION
addappid(269110)
addappid(281780)
addappid(295520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(269111, 1, "60b86540f794c8a52492ef377019dfdc196c1b3055d8077a5ba278f90a4f56cc")

