-- Lua provided by RyzenAPI
-- Game: AppID 1338250

-- MAIN APPLICATION
addappid(1338250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338251, 1, "7cb3c5b7b3ebba443c5d78de3b1a4d95116aa34ee6686538e80d96414000fcfe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
