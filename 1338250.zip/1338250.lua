-- Lua provided by RyzenAPI
-- Game: addappid(1338250)

-- MAIN APPLICATION
addappid(1338250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338251, 1, "7cb3c5b7b3ebba443c5d78de3b1a4d95116aa34ee6686538e80d96414000fcfe")
