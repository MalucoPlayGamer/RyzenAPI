-- Lua provided by RyzenAPI
-- Game: Magellania

-- MAIN APPLICATION
addappid(1511950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511951,0,"bbd4cab87580760ccf0484bf928ff7ee86ff91378570b81a98abb64cdf6e037f")

