-- Lua provided by RyzenAPI
-- Game: 397320

-- MAIN APPLICATION
addappid(397320)
-- Game: addappid(397320)

-- MAIN APP DEPOTS / PACKAGES
addappid(397321, 1, "752015b06beb79c9a6cd7ba719451063e071414a938e168f9fba59a917eef4ed")
