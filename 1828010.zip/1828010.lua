-- Lua provided by RyzenAPI
-- Game: Deadly Nightmare

-- MAIN APPLICATION
addappid(1828010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828011, 1, "0986136dc0e25d10363e0fa306982076cd5db96eb19612510e275b700202ae10")

