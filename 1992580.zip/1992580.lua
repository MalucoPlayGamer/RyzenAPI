-- Lua provided by RyzenAPI
-- Game: Game: Itchy Scratchy

-- MAIN APPLICATION
addappid(1992580)
-- Game: addappid(1992580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992581, 1, "f2037fedf4357e51087ab9492aadd23df8efbcb96de8baa8cb848af33bde799c")
