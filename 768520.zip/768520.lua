-- Lua provided by RyzenAPI
-- Game: Red Solstice 2: Survivors

-- MAIN APPLICATION
addappid(768520)
addappid(1588820)
addappid(1588821)
addappid(1604220)
addappid(1736390)
addappid(1751750)
addappid(1832100)
addappid(1931720)
addappid(2012090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(768521, 1, "6f73b9272499736de64e539fa4273b4f3068592d4e4cc2411d7c7faf71df7f8b")

