-- Lua provided by RyzenAPI
-- Game: Game: Red Solstice 2: Survivors

-- MAIN APPLICATION
addappid(768520)
-- Game: addappid(768520)

-- MAIN APP DEPOTS / PACKAGES
addappid(768521, 1, "6f73b9272499736de64e539fa4273b4f3068592d4e4cc2411d7c7faf71df7f8b")
