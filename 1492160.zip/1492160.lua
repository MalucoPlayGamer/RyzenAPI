-- Lua provided by RyzenAPI
-- Game: Doll Explorer Prologue

-- MAIN APPLICATION
addappid(1492160)
addappid(1498150)
-- Game: addappid(1492160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492161, 1, "950e5898917681b5c762453d68b98286839987c613cc54295818decc1942e586")
