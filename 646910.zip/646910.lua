-- Lua provided by RyzenAPI
-- Game: Game: AppID 646910

-- MAIN APPLICATION
addappid(646910)
addappid(702230)
addappid(702240)
addappid(702250)
addappid(889870)
addappid(889871)
addappid(889872)
addappid(889880)
addappid(889890)
addappid(999420)
addappid(999421)
addappid(1688450)
addappid(1688451)
addappid(2183880)
addappid(2183881)
addappid(2183882)
addappid(2183883)
addappid(4311250)
addappid(4311260)
addappid(4446240)
addappid(4446250)
addappid(4446260)
addappid(4446270)
-- Game: addappid(646910)

-- MAIN APP DEPOTS / PACKAGES
addappid(646911, 1, "cc9f8bf715fb14e78193c2cdc408aabe45916e645246197afcc4f361b19eeb99")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
