-- Lua provided by RyzenAPI
-- Game: Fish

-- MAIN APPLICATION
addappid(3073680)

