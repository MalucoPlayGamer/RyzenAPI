-- Lua provided by RyzenAPI
-- Game: Niskala Sacred Knowledge of Leyak Demo

-- MAIN APPLICATION
addappid(3443600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3443601, 1, "daa2becf561ff1c7d8e86e42058f106decedb18e23d8632590b50ac5efeba662")

