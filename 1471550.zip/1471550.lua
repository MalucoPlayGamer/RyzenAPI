-- Lua provided by RyzenAPI
-- Game: Variable

-- MAIN APPLICATION
addappid(1471550)
-- Game: addappid(1471550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471551, 1, "75ff7bc09a4cc26c28d0bfdd022157559ae1639c9d6a6b437a79f6b7891bd947")
