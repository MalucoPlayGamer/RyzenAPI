-- Lua provided by RyzenAPI
-- Game: Scream - Trial Ver -

-- MAIN APPLICATION
addappid(3218800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3218801, 1, "5c6f09087210552ba5399e6bee236d3cf961fb19e705ebf81130bb1cd41a21e3")
