-- Lua provided by RyzenAPI
-- Game: AppID 1370140

-- MAIN APPLICATION
addappid(1370140)
addappid(2052960)
addappid(2052961)
addappid(2052962)
addappid(2052963)
addappid(2155050)
addappid(2249670)
addappid(2389070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1370141, 1, "3f8629fbb74ca939c630c00762b9622a3a5e17611b0a9e65db4caebdb2dbec12")

