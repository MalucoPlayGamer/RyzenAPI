-- Lua provided by RyzenAPI
-- Game: addappid(1422420)

-- MAIN APPLICATION
addappid(1422420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422421, 1, "750e3dcf1d4b2766582056674a1abfe3d2a930ddc8aab898a4fb4a72d6d0782c")
