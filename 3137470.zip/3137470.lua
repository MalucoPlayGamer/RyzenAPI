-- Lua provided by RyzenAPI
-- Game: 3137470

-- MAIN APPLICATION
addappid(3137470)
-- Game: addappid(3137470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137471, 1, "330140077198efe633f91b4e2231fccd102daa2c6f69fec9afc0d4e08853729c")
