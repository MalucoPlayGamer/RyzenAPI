-- Lua provided by RyzenAPI
-- Game: Game: iso-Sphere

-- MAIN APPLICATION
addappid(414060)
-- Game: addappid(414060)

-- MAIN APP DEPOTS / PACKAGES
addappid(414061, 1, "c88a3cadb7f6e4eab4e7de197def733807b3dcc79ad4594e2bbf45d0dd404fef")
addappid(414062, 1, "ed2252f961cacc8e74c39b4d4f9a97f104015e5ca9ecc31927be2ce7635a962c")
