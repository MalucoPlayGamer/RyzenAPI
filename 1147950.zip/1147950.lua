-- Lua provided by RyzenAPI
-- Game: Shio And Mysterious Forest

-- MAIN APPLICATION
addappid(1147950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147951, 1, "8cf66e6f4309e7334de78b8a43e40dafc2972b53bd385a1352655549e42242b1")
addappid(1147952, 1, "5e2a11ff972b68b22f396e15c4378d2c0527c02242a0805ce98168192f3a5a11")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
