-- Lua provided by SkyAPI 
-- Game: Shio And Mysterious Forest
addappid(1147950)
addappid(1147951, 1, "8cf66e6f4309e7334de78b8a43e40dafc2972b53bd385a1352655549e42242b1")
addappid(1147952, 1, "5e2a11ff972b68b22f396e15c4378d2c0527c02242a0805ce98168192f3a5a11")
