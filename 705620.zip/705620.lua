-- Lua provided by SkyAPI 
-- Game: AppID 705620
addappid(705620)
addappid(705621, 1, "77c77edb11ef2a61f75fac1b0948b8401b26dcb9cadb03d23cdb8c76693a453b")
