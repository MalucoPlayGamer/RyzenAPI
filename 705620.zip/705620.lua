-- Lua provided by RyzenAPI
-- Game: Hellmut: The Badass from Hell

-- MAIN APPLICATION
addappid(705620)

-- MAIN APP DEPOTS / PACKAGES
addappid(705621, 1, "77c77edb11ef2a61f75fac1b0948b8401b26dcb9cadb03d23cdb8c76693a453b")
