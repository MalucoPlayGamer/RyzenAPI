-- Lua provided by RyzenAPI
-- Game: SUKEBE BLOCKS

-- MAIN APPLICATION
addappid(1860760)
-- Game: addappid(1860760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860761, 1, "2e505f831c02c10fd1589439d1ee151cae51c345742e0e9dadeb59865ae494a4")
