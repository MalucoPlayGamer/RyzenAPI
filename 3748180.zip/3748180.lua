-- Lua provided by RyzenAPI
-- Game: HardAF Soundtrack

-- MAIN APPLICATION
addappid(3748180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3748181, 1, "e7930fcfb668d8b416bcc94c4b3523aaedd50e83d16803e131cbbd0f98d1afa3")
