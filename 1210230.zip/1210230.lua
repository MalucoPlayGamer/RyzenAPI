-- Lua provided by RyzenAPI
-- Game: Suits: Absolute Power

-- MAIN APPLICATION
addappid(1210230)
-- Game: addappid(1210230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210231, 1, "97a7cf8114b33ce0ea492ba412e43c69dfc4ddbf5932fdaa33e44af63929df97")
