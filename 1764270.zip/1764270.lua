-- Lua provided by RyzenAPI
-- Game: Game: Garage Flipper

-- MAIN APPLICATION
addappid(1764270)
-- Game: addappid(1764270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764271, 1, "e398712a39618d8cf06309cd33b487683756c3d0d96160504c7720433a222f94")
