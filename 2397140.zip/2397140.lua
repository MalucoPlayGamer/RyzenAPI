-- Lua provided by RyzenAPI 
-- Game: TOKYO PSYCHODEMIC
addappid(2397140)
addappid(2397141, 1, "e069af8d7e6b317e43467e9e7872a39e88b04612aab3a4aaf782525daf3720ba")
