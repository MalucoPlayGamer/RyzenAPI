-- Lua provided by RyzenAPI
-- Game: 2397140

-- MAIN APPLICATION
addappid(2397140)
-- Game: addappid(2397140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397141, 1, "e069af8d7e6b317e43467e9e7872a39e88b04612aab3a4aaf782525daf3720ba")
