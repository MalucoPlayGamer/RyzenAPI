-- Lua provided by RyzenAPI
-- Game: addappid(485400)

-- MAIN APPLICATION
addappid(485400)

-- MAIN APP DEPOTS / PACKAGES
addappid(485403,0,"9c0430a611c263f2d80ddf9675573e6425ebf97e58358bfb35ba3973ca4cb3f8")
