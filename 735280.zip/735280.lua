-- Lua provided by RyzenAPI
-- Game: AppID 735280

-- MAIN APPLICATION
addappid(735280)

-- MAIN APP DEPOTS / PACKAGES
addappid(735281, 1, "386cd83c8d6045f046e262830c8cde7598c6e04a4fc0238bc6aa9dbe98a43154")
addappid(735282, 1, "16e91b9a819e230cb18ff997034e0deebef9ef35634fb22b6daff504f0449519")
addappid(735283, 1, "e10d5dfeb07d7a3fbc1fe8f0eea20958c38c0092d43e4913adc2097e369d721c")
addappid(735284, 1, "c924d6aa05215a4489ae17c7d9c9f5c9d56e7e475a41298674d0bca749a72c83")
addappid(735285, 1, "1940bc794f0b4aed94afabb5a446d9e79b2bb976c2dbf588121df97f153ed248")
addappid(735286, 1, "98edcbf3768e3d0bf12d86e2165eb2665c2e4858e0efb7aaf140733607f80639")
addappid(735287, 1, "87e1772e7b0c1422bf55eac9f5520a6e7114a85a24c81115ad12720c8a7573ff")
addappid(735288, 1, "fca964fc5014b6894b531bb0946fa9bac55c5b1b26115b2d81c7dc6f9e7236cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
