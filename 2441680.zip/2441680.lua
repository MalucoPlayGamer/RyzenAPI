-- Lua provided by RyzenAPI
-- Game: Game: AppID 2441680

-- MAIN APPLICATION
addappid(2441680)
-- Game: addappid(2441680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2441681, 1, "9f7365b06daae3945d319312e261e5ff90ba9d32a69eb084bb406af97361f6f3")
