-- Lua provided by RyzenAPI
-- Game: Career of the President

-- MAIN APPLICATION
addappid(1646480)
-- Game: addappid(1646480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646481, 1, "25215c79c49dfc3e360adead967af487bbe88b64b71dc4f751f50a4788c4f52f")
