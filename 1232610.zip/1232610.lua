-- Lua provided by RyzenAPI
-- Game: 1232610

-- MAIN APPLICATION
addappid(1232610)
-- Game: addappid(1232610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232611, 1, "c04864aea96b8f8e9904a1849542ce37891ecad1aeae4e52ce15b41250dbc59c")
