-- Lua provided by RyzenAPI
-- Game: 1106670

-- MAIN APPLICATION
addappid(1106670)
-- Game: addappid(1106670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106671, 1, "1d21567747a3abdee4e8802322e8aa49e3bd2fd49befd39d7f8469777282a4b0")
