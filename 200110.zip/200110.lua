-- Lua provided by RyzenAPI
-- Game: AppID 200110

-- MAIN APPLICATION
addappid(200110)
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228986)
addappid(228990)
addappid(229004)
addappid(229031)
-- Game: addappid(200110)

-- MAIN APP DEPOTS / PACKAGES
addappid(200111, 1, "8a7a14a98db6502dbff62134a04857295e9602feb910beadf37dcb989ad47c67")
