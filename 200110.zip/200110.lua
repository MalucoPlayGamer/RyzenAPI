-- Lua provided by RyzenAPI
-- Game: AppID 200110

-- MAIN APPLICATION
addappid(200110)
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228986)
addappid(228990)
addappid(229004)
addappid(229031)
addappid(281720)
addappid(281721)
addappid(281722)
addappid(281723)
addappid(281724)
addappid(281725)
addappid(306470)
addappid(314550)
addappid(314551)
addappid(314552)
addappid(314553)
addappid(333180)
addappid(333181)
addappid(333182)
addappid(333190)
addappid(333191)
addappid(333192)
addappid(333193)
addappid(358850)

-- MAIN APP DEPOTS / PACKAGES
addappid(200111, 1, "8a7a14a98db6502dbff62134a04857295e9602feb910beadf37dcb989ad47c67")

