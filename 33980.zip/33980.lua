-- Lua provided by RyzenAPI
-- Game: Pound of Ground

-- MAIN APPLICATION
addappid(33980)
-- Game: addappid(33980)

-- MAIN APP DEPOTS / PACKAGES
addappid(33981, 1, "d27d1bfdc376440da59b417869348b13256397444964e69bf98b402d431443fb")
