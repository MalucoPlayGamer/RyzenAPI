-- Lua provided by RyzenAPI
-- Game: AppID 1076920

-- MAIN APPLICATION
addappid(1076920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076921, 1, "c8904ddf90be67a9da8943a47514fcdcf97940a4a2c0dd02a9e0c6b3d707fd3e")

