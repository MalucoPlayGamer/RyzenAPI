-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Grim of Death

-- MAIN APPLICATION
addappid(1246030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246030,0,"0c36b94ba739b895df91998130d639f47732e460913f724c9a3c38895f121059")

