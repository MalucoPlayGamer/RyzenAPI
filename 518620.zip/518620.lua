-- Lua provided by RyzenAPI 
-- Game: Ballistick
addappid(518620)
addappid(518621, 1, "9e3568e0a879cf2d70522f317dda5d07aadff3d7f68bcf11ac0fe6d44f76d37a")
