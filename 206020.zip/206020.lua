-- Lua provided by RyzenAPI
-- Game: Game: Avernum 4

-- MAIN APPLICATION
addappid(206020)
-- Game: addappid(206020)

-- MAIN APP DEPOTS / PACKAGES
addappid(206021, 1, "0be338f288ee92839fc939e64c39ace10ba9caf78d1c00b41307c999973b4465")
