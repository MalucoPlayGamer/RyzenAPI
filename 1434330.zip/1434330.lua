-- Lua provided by RyzenAPI
-- Game: Game: Blaze and the Monster Machines: Axle City Racers

-- MAIN APPLICATION
addappid(1434330)
-- Game: addappid(1434330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434331, 1, "54b132e3f91e91a89e9c7aed944fe37eda5baea4cd65207496d1bc1f80b01108")
