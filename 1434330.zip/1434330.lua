-- Lua provided by RyzenAPI
-- Game: Blaze and the Monster Machines: Axle City Racers

-- MAIN APPLICATION
addappid(1434330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1434331, 1, "54b132e3f91e91a89e9c7aed944fe37eda5baea4cd65207496d1bc1f80b01108")

