-- Lua provided by RyzenAPI
-- Game: addappid(1837122)

-- MAIN APPLICATION
addappid(1837122)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837122,0,"1b991d6053185b14d980ca41ca7e083aa4c6078da6c567fce08e27bc7f5deb77")
