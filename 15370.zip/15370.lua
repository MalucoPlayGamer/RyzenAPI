-- Lua provided by RyzenAPI
-- Game: Heroes of Might & Magic V: Tribes of the East

-- MAIN APPLICATION
addappid(15370)

-- MAIN APP DEPOTS / PACKAGES
addappid(15371, 1, "e3718fbe2f8f98351eb260d4ea5d487e7f82ab1ec921d25ed9651c41d9991306")
addappid(15372, 1, "222a52489d9bd068bea12e1e737b9f118b0992c0d0e3b935796e3bac2bb09062")
addappid(15373, 1, "9f3e2054ab84775aa115213cb622fa37ce87a43b8920d334ce9a40b5331a9376")
addappid(15374, 1, "04dee008a9fa6ad531dca377c526947d3bba103cd3ea6d7d940a36ea27ac22a2")
addappid(15375, 1, "6327bfffbe1b62aa214bdc961baaef2dab35b45ff9c2bc2f78e306e3a5a106db")
addappid(15376, 1, "f21b96ff47e5ef90d6fc2a02030711ba6d30b19d2dce7a531f0a97eb12c0a33e")
addappid(15378, 1, "7d769e13ba4ae1654f4ab1f2828b934330a26043b44783db4da71ed1f3124b91")
addappid(3833491, 0, "663c7ff25649e9cb6bf7a64f0940b27c7367de86101058d56cb060eb68649328")

