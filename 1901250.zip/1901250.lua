-- Lua provided by RyzenAPI
-- Game: Mars Tactics Demo

-- MAIN APPLICATION
addappid(1901250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901251, 1, "6b241b518737867c853b84b8c632ff31be5819f54d0a8f5e2121726c222563d5")
