-- Lua provided by RyzenAPI 
-- Game: Peggle Extreme
addappid(3483)
addappid(3484, 1, "9139196ed941eada40864fa998092a88f23d27906865f8e7f7a7fd82150320d1")
