-- Lua provided by RyzenAPI
-- Game: Game: Peggle Extreme

-- MAIN APPLICATION
addappid(3483)
-- Game: addappid(3483)

-- MAIN APP DEPOTS / PACKAGES
addappid(3484, 1, "9139196ed941eada40864fa998092a88f23d27906865f8e7f7a7fd82150320d1")
