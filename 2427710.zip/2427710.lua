-- Lua provided by RyzenAPI 
-- Game: Cricket Captain 2023 Demo
addappid(2427710)
addappid(2427711, 1, "d20d6c7fac3af21ce13c769d5535b51e7a13999fe847c5618b9a7e77a85efa6d")
