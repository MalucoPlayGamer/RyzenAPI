-- Lua provided by RyzenAPI
-- Game: Monopoly Madness Demo

-- MAIN APPLICATION
addappid(2383800)
-- Game: addappid(2383800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383801, 1, "da3ad5219b383520a5064d2bc09cd91d052b166d7fcdcf1ac1f8c0052ee66a20")
