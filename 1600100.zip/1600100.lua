-- Lua provided by RyzenAPI
-- Game: Flexibility and Girls

-- MAIN APPLICATION
addappid(1600100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600101, 1, "265c40d23812ef820697d0264e7b54b7c25a6b88bb70c4a9c8695a4a2bbba0b8")

