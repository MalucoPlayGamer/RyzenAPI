-- Lua provided by RyzenAPI
-- Game: Recall

-- MAIN APPLICATION
addappid(3097200)
-- Game: addappid(3097200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097201, 1, "3669b7fed0d10ce079528a90791bb80b3d4c5bb552ce671797ba11631f056317")
