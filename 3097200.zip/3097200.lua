-- Lua provided by RyzenAPI 
-- Game: Recall
addappid(3097200)
addappid(3097201, 1, "3669b7fed0d10ce079528a90791bb80b3d4c5bb552ce671797ba11631f056317")
