-- Lua provided by RyzenAPI
-- Game: Game: Placid Plastic Duck VR

-- MAIN APPLICATION
addappid(3595010)
-- Game: addappid(3595010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3595011, 1, "9695b157ce3dde699f7ee24607d719ff089bb5a17ca3e057dc98c58d9595074d")
