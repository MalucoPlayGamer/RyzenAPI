-- Lua provided by RyzenAPI
-- Game: Game: Geneforge 1

-- MAIN APPLICATION
addappid(200960)
-- Game: addappid(200960)

-- MAIN APP DEPOTS / PACKAGES
addappid(200961, 1, "06e6571577987bb63a7742f2705086f74d573d1f28938f8e8d2b7d59e7736630")
