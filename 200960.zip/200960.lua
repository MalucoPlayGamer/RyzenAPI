-- Lua provided by SkyAPI 
-- Game: Geneforge 1
addappid(200960)
addappid(200961, 1, "06e6571577987bb63a7742f2705086f74d573d1f28938f8e8d2b7d59e7736630")
