-- Lua provided by RyzenAPI 
-- Game: TAISHO x ALICE epilogue
addappid(1596540)
addappid(1596541, 1, "829282dc81c188fb2c6fc0a19c92148ec5d75823a640338aa8629a2458fe48c5")
addappid(1600000, 0, "68c021f006c1536a41cc6025061f00af3444ba5bf89372649f4611741d76e31c")
