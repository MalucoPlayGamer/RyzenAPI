-- Lua provided by RyzenAPI 
-- Game: Trust No Bunny
addappid(2025660)
addappid(2025661, 1, "110a0d564b120a48bcd909495b4c32e0c0f0c8cc03df44c499f1c1eaf216208c")
