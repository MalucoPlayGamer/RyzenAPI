-- Lua provided by RyzenAPI
-- Game: Game: Trust No Bunny

-- MAIN APPLICATION
addappid(2025660)
-- Game: addappid(2025660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025661, 1, "110a0d564b120a48bcd909495b4c32e0c0f0c8cc03df44c499f1c1eaf216208c")
