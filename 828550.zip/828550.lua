-- Lua provided by RyzenAPI
-- Game: AppID 828550

-- MAIN APPLICATION
addappid(828550)
-- Game: addappid(828550)

-- MAIN APP DEPOTS / PACKAGES
addappid(828551, 1, "65e1bce299a2adc71f9716aabab70af70ccdb86859609c43a02aca4d36b48773")
