-- Lua provided by SkyAPI 
-- Game: Presence
addappid(1548050)
addappid(1548051, 1, "0c196710d4194c8eeb45fca0c8764ed4a8f9b039c9314570c79a70e14181e248")
