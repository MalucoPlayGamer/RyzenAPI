-- Lua provided by RyzenAPI
-- Game: Presence

-- MAIN APPLICATION
addappid(1548050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548051, 1, "0c196710d4194c8eeb45fca0c8764ed4a8f9b039c9314570c79a70e14181e248")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
