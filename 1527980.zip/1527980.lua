-- Lua provided by SkyAPI 
-- Game: AppID 1527980
addappid(1527980)
addappid(1527981, 1, "7597c80f21ffe54030675cdbc78adda6cd2a139759e67932490f46d5a04564da")
