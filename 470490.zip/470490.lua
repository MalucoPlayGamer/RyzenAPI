-- Lua provided by RyzenAPI
-- Game: 470490

-- MAIN APPLICATION
addappid(470490)
-- Game: addappid(470490)

-- MAIN APP DEPOTS / PACKAGES
addappid(470491, 1, "c014fe64b24566bc0502b712434245f9e3e1371d5e7fcdb1ec0c40f1a2bdd22c")
