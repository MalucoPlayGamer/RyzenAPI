-- Lua provided by RyzenAPI
-- Game: AppID 1280700

-- MAIN APPLICATION
addappid(1280700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280701, 1, "736d4a96cda5a24e57f9de4f503ab9a23039c1f4cb505e81ed2191763cfff57a")

