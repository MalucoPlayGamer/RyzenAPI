-- Lua provided by RyzenAPI
-- Game: Skies Above

-- MAIN APPLICATION
addappid(2604030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604032,0,"9be0a4f2812ec41d5aeca36cd28f93a95e0830b8ebd5e0ac8ae8dffd1231c044")

