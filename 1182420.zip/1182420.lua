-- Lua provided by RyzenAPI
-- Game: AppID 1182420

-- MAIN APPLICATION
addappid(1182420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182421, 1, "1ccd71ca485e1c46672f8315a3035cd347626125fcbcaa7abff2e2ee071ff0d3")
