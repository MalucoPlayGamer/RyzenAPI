-- Lua provided by RyzenAPI
-- Game: Home Sweet Home Survive

-- MAIN APPLICATION
addappid(1056600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1056601, 1, "db278cf9f6fe7bc9826baed3d1baaca38157a7ea3cf38abad959c01cd9b6419e")
