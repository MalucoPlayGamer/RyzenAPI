-- Lua provided by RyzenAPI
-- Game: 2235610

-- MAIN APPLICATION
addappid(2235610)
addappid(2240710)
-- Game: addappid(2235610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235611, 1, "d51bd697449cbfb094c247a1d7e2f4748447d1c3e2166f979b7b5b7f5ed6b5bb")
