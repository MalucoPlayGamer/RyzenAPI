-- Lua provided by RyzenAPI
-- Game: AppID 816710

-- MAIN APPLICATION
addappid(816710)
-- Game: addappid(816710)

-- MAIN APP DEPOTS / PACKAGES
addappid(816711, 1, "a998045fcc6cf1e186fa0df56a5f32997f92915a94fdded41fc855a60516563f")
