-- Lua provided by RyzenAPI 
-- Game: Roadside Research
addappid(3643170)
addappid(3643171, 1, "7d044644abebe1ae2cc08b7c0f2e4bb004c3616d81ffe2b4bf0e8ed2107fda67")
