-- Lua provided by RyzenAPI 
-- Game: Alone K.W.
addappid(442000)
addappid(442001, 1, "6b22967475777871b1fff2924bf5a1e6541138236c4f7aa435344714b4f2f832")
