-- Lua provided by RyzenAPI
-- Game: Game: Alone K.W.

-- MAIN APPLICATION
addappid(442000)
-- Game: addappid(442000)

-- MAIN APP DEPOTS / PACKAGES
addappid(442001, 1, "6b22967475777871b1fff2924bf5a1e6541138236c4f7aa435344714b4f2f832")
