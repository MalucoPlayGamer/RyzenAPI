-- Lua provided by RyzenAPI
-- Game: Game: AppID 494150

-- MAIN APPLICATION
addappid(494150)
-- Game: addappid(494150)

-- MAIN APP DEPOTS / PACKAGES
addappid(494151, 1, "937565aad52492498a0fb91cf9508ca5628c65c3198d0ba049ee8d3bab4b0489")
