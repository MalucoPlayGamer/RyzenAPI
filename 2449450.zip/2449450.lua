-- Lua provided by RyzenAPI
-- Game: Clonizer

-- MAIN APPLICATION
addappid(2449450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449451, 1, "e851bbdba1f73973a79770edf9d279583741bc2a4d5b6dae4ad4edeaf7f01b5b")

