-- Lua provided by RyzenAPI
-- Game: 3461610

-- MAIN APPLICATION
addappid(3461610)
-- Game: addappid(3461610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461611, 1, "08dc0582131c6fd7d20085a9cea6f65328c75dbf06fcae920d6084339cbdc1c0")
