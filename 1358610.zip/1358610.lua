-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1358610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358612,0,"d12f7f401fe7982640e58c65d3cb00763631a1fdea86595160165c90c593dafb")
