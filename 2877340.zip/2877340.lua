-- Lua provided by RyzenAPI
-- Game: Game: Star Leaping Story:prologue

-- MAIN APPLICATION
addappid(2877340)
-- Game: addappid(2877340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877341, 1, "a1904cfd1738cb299b70922b94d5b38bf9851fd243ca6e02a5ed3c0e0312e74c")
