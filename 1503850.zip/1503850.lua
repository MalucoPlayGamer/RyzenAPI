-- Lua provided by RyzenAPI
-- Game: 中年失业模拟器When a man lose his job

-- MAIN APPLICATION
addappid(1503850)
addappid(1732970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503851, 1, "8add59db7dec7d7b0540e4144be06ebd2c1a6b8a9e2e6bd392790d1ce7b8c6d0")

