-- Lua provided by RyzenAPI
-- Game: addappid(1503850)

-- MAIN APPLICATION
addappid(1503850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503851, 1, "8add59db7dec7d7b0540e4144be06ebd2c1a6b8a9e2e6bd392790d1ce7b8c6d0")
