-- Lua provided by RyzenAPI
-- Game: Miss Fisher and the Deathly Maze

-- MAIN APPLICATION
addappid(711430)

-- MAIN APP DEPOTS / PACKAGES
addappid(711431, 1, "f8d66cb33ed038ffe139f8e40e0a087fa7f454333970fc3516ba73ec2ccae586")

