-- Lua provided by RyzenAPI
-- Game: The Tall Man Tapes

-- MAIN APPLICATION
addappid(3369940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3369941,0,"88a77cf7fd0b719b82b6338efed22c087df70ff29f23b7618f549bfc86d526e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
