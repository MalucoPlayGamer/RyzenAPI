-- Lua provided by RyzenAPI
-- Game: The Tall Man Tapes

-- MAIN APPLICATION
addappid(3369940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3369941,0,"88a77cf7fd0b719b82b6338efed22c087df70ff29f23b7618f549bfc86d526e0")

