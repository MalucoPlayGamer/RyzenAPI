-- Lua provided by RyzenAPI
-- Game: The Chant

-- MAIN APPLICATION
addappid(1577250)
addappid(2144430)
addappid(2144440)
addappid(2190430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1577251, 1, "ac93a46bb6b0c489aecb92e2740184ebbbaf1f6ee2881bf52bd30f6134e51cbc")
addappid(1577252, 1, "b8d88cf83949f056ab3bdd5b0467009a67d02d11d93b7de4304a8a5325b0ff35")
addappid(2145780, 0, "5e359c5049831949a33dcdcbc1b8f0cffafcace09e99444de91a538752df46e9")

