-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Airi is streaming

-- MAIN APPLICATION
addappid(4312440) -- Hentai Clicker: Airi is streaming

-- MAIN APP DEPOTS / PACKAGES
addappid(4312441, 1, "e1dcc1eb727d749e5a184409aaf0f18a8ad99ac60cc9df39cedf7d45f6f4328e") -- Depot 4312441
addappid(4312442, 1, "4d4258778914e2527669548466867cbc18b80429f9a4f3193a42805b07b04993") -- Depot 4312442
addappid(4312443, 1, "b481efb50865d2e35f8632fd5a0e1abdf62b3c9959d887f24e988e46962fe8a6") -- Depot 4312443

