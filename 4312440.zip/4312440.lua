-- 4312440's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Airi is streaming
-- Created: July 10, 2026 at 16:06:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4312440) -- Hentai Clicker: Airi is streaming
-- MAIN APP DEPOTS
addappid(4312441, 1, "e1dcc1eb727d749e5a184409aaf0f18a8ad99ac60cc9df39cedf7d45f6f4328e") -- Depot 4312441
setManifestid(4312441, "5833322637184913133", 155577391)
addappid(4312442, 1, "4d4258778914e2527669548466867cbc18b80429f9a4f3193a42805b07b04993") -- Depot 4312442
setManifestid(4312442, "8096484342399518934", 190403678)
addappid(4312443, 1, "b481efb50865d2e35f8632fd5a0e1abdf62b3c9959d887f24e988e46962fe8a6") -- Depot 4312443
setManifestid(4312443, "1329231501480000372", 163335496)