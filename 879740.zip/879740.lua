-- Lua provided by SkyAPI 
-- Game: Epic Skater 2
addappid(879740)
addappid(879741, 1, "2b1619ed41b21702bc06f98f13f3fe55f2e45897b61c05abdd6dae53500b895f")
