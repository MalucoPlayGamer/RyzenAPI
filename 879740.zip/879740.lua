-- Lua provided by RyzenAPI
-- Game: 879740

-- MAIN APPLICATION
addappid(879740)
-- Game: addappid(879740)

-- MAIN APP DEPOTS / PACKAGES
addappid(879741, 1, "2b1619ed41b21702bc06f98f13f3fe55f2e45897b61c05abdd6dae53500b895f")
