-- Lua provided by RyzenAPI
-- Game: Game: AppID 1632270

-- MAIN APPLICATION
addappid(1632270)
-- Game: addappid(1632270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632271, 1, "48905026eeeb0028a80933309e952e9f2e4666081b5ee7629b4e75bc1c9f43ab")
