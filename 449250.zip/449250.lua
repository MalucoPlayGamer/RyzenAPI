-- Lua provided by RyzenAPI
-- Game: A Little Lily Princess

-- MAIN APPLICATION
addappid(449250)

-- MAIN APP DEPOTS / PACKAGES
addappid(449253,0,"aa1d8e717554a6d39dda1bf788078fd69fa30e468405f76ee6c01c190d6d1988")
addappid(449256,0,"84a16211d5f687a85b142eacc047c3296835b7d849d03ffd87b22a7e578ab34a")

