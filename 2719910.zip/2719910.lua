-- Lua provided by RyzenAPI
-- Game: 2719910

-- MAIN APPLICATION
addappid(2719910)
-- Game: addappid(2719910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719911, 1, "83f161709f32750700a4221ba782a2eff4be8abb3ffd3f6c6877e212e855acb7")
