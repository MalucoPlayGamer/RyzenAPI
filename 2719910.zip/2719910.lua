-- Lua provided by SkyAPI 
-- Game: AppID 2719910
addappid(2719910)
addappid(2719911, 1, "83f161709f32750700a4221ba782a2eff4be8abb3ffd3f6c6877e212e855acb7")
