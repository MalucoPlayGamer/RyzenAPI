-- Lua provided by RyzenAPI
-- Game: The New Beginning: A Surprise Visit

-- MAIN APPLICATION
addappid(4451200) -- The New Beginning: A Surprise Visit

-- MAIN APP DEPOTS / PACKAGES
addappid(4451201, 1, "f6b42e473fcdc4fcf91a6888a170cfd1efa0397cb3a1eef256ae058d34969e6f") -- Depot 4451201

