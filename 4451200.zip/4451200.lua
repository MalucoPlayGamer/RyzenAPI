-- 4451200's Lua and Manifest Created by Hubcap Manifest
-- The New Beginning: A Surprise Visit
-- Created: August 24, 2026 at 17:45:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4451200) -- The New Beginning: A Surprise Visit
-- MAIN APP DEPOTS
addappid(4451201, 1, "f6b42e473fcdc4fcf91a6888a170cfd1efa0397cb3a1eef256ae058d34969e6f") -- Depot 4451201
setManifestid(4451201, "3532804429745037110", 1010745287)