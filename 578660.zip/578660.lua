-- Lua provided by SkyAPI 
-- Game: Kindled Cavern
addappid(578660)
addappid(578661, 1, "04f9801c52f80fed958569a019111c7b1c91439fa87a01264fe53284f2f04d9c")
