-- Lua provided by RyzenAPI
-- Game: 578660

-- MAIN APPLICATION
addappid(578660)
-- Game: addappid(578660)

-- MAIN APP DEPOTS / PACKAGES
addappid(578661, 1, "04f9801c52f80fed958569a019111c7b1c91439fa87a01264fe53284f2f04d9c")
