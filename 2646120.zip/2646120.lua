-- Lua provided by RyzenAPI
-- Game: Boons & Burdens

-- MAIN APPLICATION
addappid(2646120)
-- Game: addappid(2646120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646121, 1, "25fc8499d2647cc8c7aa9a354402766696948e546a8be60049375c478a73af58")
