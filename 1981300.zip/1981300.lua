-- Lua provided by RyzenAPI
-- Game: Shadow Racer

-- MAIN APPLICATION
addappid(1981300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981301, 1, "733600483b464724858c1d84245e7b48ec54272d25d7ad3c2ad1a31acdebdfdf")

