-- Lua provided by RyzenAPI
-- Game: Game: Hinterland

-- MAIN APPLICATION
addappid(17140)
-- Game: addappid(17140)

-- MAIN APP DEPOTS / PACKAGES
addappid(17141, 1, "e4a496df720fb9a303877e1d5d25a05665d2c2ce7d57e1769dcd9fdae6736ca7")
