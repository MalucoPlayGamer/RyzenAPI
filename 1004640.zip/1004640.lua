-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY TACTICS - The Ivalice Chronicles

-- MAIN APPLICATION
addappid(1004640)
addappid(3589750)
addappid(3589760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004641, 1, "b9ffdc9182829343bcdf50e8c3fe66b2fc58fbbe11980078cfc04e6f8d91701d")
