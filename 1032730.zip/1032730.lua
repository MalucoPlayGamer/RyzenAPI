-- Lua provided by RyzenAPI
-- Game: Sticks And Bones

-- MAIN APPLICATION
addappid(1032730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032731, 1, "6b52cf6b83257c0853e8f5ee1762ad00cf35223d5e0077e753c8e014c494e5fc")
