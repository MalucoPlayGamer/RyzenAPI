-- Lua provided by RyzenAPI
-- Game: AppID 2075730

-- MAIN APPLICATION
addappid(2075730)
addappid(2104180)
addappid(2104183)
addappid(2104184)
addappid(2104185)
addappid(2104186)
addappid(2104187)
addappid(2104188)
-- Game: addappid(2075730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075731, 1, "a9ad65d1e9f43541f402222cdaa38b8de4ef9c556e4238ccb61fb88557d70e81")
addappid(2075732, 1, "f010253f0e434878e6fbe8a38ddc359f5f012f04aaec68e5a0533dea2167b0e2")
addappid(2075733, 1, "87e0de1a07e4ffa2297e76be3fa4acc6e9ede54ed44834993f546cccea03df35")
addappid(2104181, 0, "d6fad86adf3837597dfce3fff71f32f8363c2b69cb3e3a29ef1eb80f7ffa59e9")
addappid(2104182, 0, "80aa2738d3faedb9c3a93be71a6e56869cc712bdd1e72ec3ed729397aa5e78b8")
addappid(2104189, 0, "f5a8afb0bc9f223e9ec7816e32aeeecd6a6bd967c136702296ebe33ce846e1f6")
