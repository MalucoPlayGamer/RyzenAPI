-- Lua provided by RyzenAPI
-- Game: Tiger Heli

-- MAIN APPLICATION
addappid(2022970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022971, 1, "2fc72c07c19a731b6c5c345d74085ee213e3b4ea32e5ff5394a69b8023c49220")
