-- Lua provided by RyzenAPI
-- Game: AstronTycoon

-- MAIN APPLICATION
addappid(851790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(851791, 1, "ff47050fb81c6169b02bce3499e7167adf4d5526571dd9dfb642680275439647")

