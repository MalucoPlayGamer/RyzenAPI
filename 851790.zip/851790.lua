-- Lua provided by RyzenAPI
-- Game: Game: AstronTycoon

-- MAIN APPLICATION
addappid(851790)
-- Game: addappid(851790)

-- MAIN APP DEPOTS / PACKAGES
addappid(851791, 1, "ff47050fb81c6169b02bce3499e7167adf4d5526571dd9dfb642680275439647")
