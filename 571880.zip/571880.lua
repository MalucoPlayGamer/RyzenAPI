-- Lua provided by RyzenAPI
-- Game: Angels with Scaly Wings™ / 鱗羽の天使

-- MAIN APPLICATION
addappid(571880)

-- MAIN APP DEPOTS / PACKAGES
addappid(571881, 1, "3e8a00d8b2df1f39ad5fc00f8ac7b75997bdcbac0ab36d70f638fc69cdb515d8")
addappid(573290, 0, "fbc8b9a3183a22e254aa254fa35554d8f866c493c514a2451cd0b54da8fe3ea8")

