-- Lua provided by RyzenAPI
-- Game: 864700

-- MAIN APPLICATION
addappid(864700)
-- Game: addappid(864700)

-- MAIN APP DEPOTS / PACKAGES
addappid(864701, 1, "faedd46777d12749271e88108954cd2db14f7920472fe445a1b62c5867cff3fc")
