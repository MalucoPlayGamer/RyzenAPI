-- Generated with Luie @ https://lua.tools/
-- 864700 - Dinosaur Fossil Hunter
-- Generated 2026-08-23 05:40:15 UTC
-- # Depots (Total/DLC/Shared): 4/0/3

-- Main AppID
addappid(864700, 1, "0466b052d4cbd2c74ff4d7d254d96697c8b28b8fb6ce01bd8d56f49ba41bf391")

-- Main Depots
addappid(864701, 1, "faedd46777d12749271e88108954cd2db14f7920472fe445a1b62c5867cff3fc")
setManifestid(864701, "326556106419806971", 18011733706)

-- DLC's (no depot keys required)
addappid(2065550) -- Dinosaur Fossil Hunter - Designer DLC
addappid(2217690) -- Dinosaur Fossil Hunter - Raptor DLC

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
