-- Lua provided by RyzenAPI
-- Game: Cosmos: Stella Returns

-- MAIN APPLICATION
addappid(2570280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570281, 1, "0250a5086a26bdd26b7265d9827a300da1532aa5e0a4f6ea9d4632bbdcc6aa65")
