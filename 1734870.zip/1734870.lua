-- Lua provided by RyzenAPI
-- Game: Shiba Army

-- MAIN APPLICATION
addappid(1734870)
addappid(1772300)
-- Game: addappid(1734870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734871, 1, "10c92f359369127521fb60f13e0438707aca4127eb8e8b4d23f7f719494ec3d8")
