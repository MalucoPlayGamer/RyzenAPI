-- Lua provided by RyzenAPI
-- Game: addappid(1904310)

-- MAIN APPLICATION
addappid(1904310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904311, 1, "b509063eae19b9bc6d5efd49cf04a74947bda5a22c13d4dcec44bf14b66419a9")
