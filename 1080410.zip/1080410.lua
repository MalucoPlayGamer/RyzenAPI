-- Lua provided by RyzenAPI
-- Game: 1080410

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1080410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080414,0,"1719c4b75b779f013b29bfe6a577d9f65aad517196dfaefd20c53d1a3282a172")

