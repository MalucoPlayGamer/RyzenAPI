-- Lua provided by RyzenAPI
-- Game: AppID 791930

-- MAIN APPLICATION
addappid(791930)
addappid(792110)

-- MAIN APP DEPOTS / PACKAGES
addappid(791931, 1, "2b19031940641b1f61e6d338f4fc8d73c944da5b3e38ae72bb57c60bd9f40db9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
