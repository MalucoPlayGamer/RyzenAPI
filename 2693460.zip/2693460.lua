-- Lua provided by RyzenAPI
-- Game: 2693460

-- MAIN APPLICATION
addappid(2693460)
-- Game: addappid(2693460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693461, 1, "69a30e6d01fa8ad04ad883c2a4267346f7d1869b1b32b9dcb1b0a17d09108654")
