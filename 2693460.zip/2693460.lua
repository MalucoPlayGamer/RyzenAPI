-- Lua provided by SkyAPI 
-- Game: Christmas Nightmare
addappid(2693460)
addappid(2693461, 1, "69a30e6d01fa8ad04ad883c2a4267346f7d1869b1b32b9dcb1b0a17d09108654")
