-- Lua provided by RyzenAPI
-- Game: Christmas Nightmare

-- MAIN APPLICATION
addappid(2693460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693461, 1, "69a30e6d01fa8ad04ad883c2a4267346f7d1869b1b32b9dcb1b0a17d09108654")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
