-- Lua provided by SkyAPI 
-- Game: AppID 385860
addappid(385860)
addappid(385861, 1, "aab2b4734867a66a6c4ae14a2a3ed674f50dafd1385297c3d6bd4b8d41243864")
