-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4: The Ultimate Upgrade Pack

-- MAIN APPLICATION
addappid(1147480)
-- Game: addappid(1147480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147480,0,"c110a707ba474e78fec39dd54574f413101a8cd53ec7929d1c4caedbaae58342")
