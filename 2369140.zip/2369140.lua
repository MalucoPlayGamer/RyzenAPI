-- Lua provided by RyzenAPI
-- Game: 2369140

-- MAIN APPLICATION
addappid(2369140)
addappid(2519960)
-- Game: addappid(2369140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2369141, 1, "1a8614bc9a29b4117473a38f8f2fe75c2e81c53c09a4b2833e470a6964cf2528")
