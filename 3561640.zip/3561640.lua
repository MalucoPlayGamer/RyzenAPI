-- Lua provided by RyzenAPI 
-- Game: SHARP FISTS
addappid(3561640)
addappid(3561641, 1, "3d5c781c01ef5935baa587cb1b89c9c0dafee378a0fff3ff502a8e5ae561594a")
