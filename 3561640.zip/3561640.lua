-- Lua provided by RyzenAPI
-- Game: 3561640

-- MAIN APPLICATION
addappid(3561640)
-- Game: addappid(3561640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561641, 1, "3d5c781c01ef5935baa587cb1b89c9c0dafee378a0fff3ff502a8e5ae561594a")
