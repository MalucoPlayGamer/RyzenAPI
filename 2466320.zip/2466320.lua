-- Lua provided by RyzenAPI
-- Game: addappid(2466320)

-- MAIN APPLICATION
addappid(2466320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466321, 1, "25addd557e7eb9a6d2b70d1dc08dc9db662e137383eb4ac670fb60d59244d52b")
