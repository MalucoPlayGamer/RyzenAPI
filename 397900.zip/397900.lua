-- Lua provided by RyzenAPI
-- Game: Business Tour - Board Game with Online Multiplayer(大富翁)

-- MAIN APPLICATION
addappid(397900)

-- MAIN APP DEPOTS / PACKAGES
addappid(397901, 1, "004c56553d38452e960e65fa55a078ec817e63e8950dd328b3d97451153226fc")
addappid(397902, 1, "b86431dee863340e061be97814a86761c58cdc8a2994abde77c9b41490bca126")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(511840)
addappid(716790)
addappid(797240)
addappid(819240)
addappid(842000)
addappid(862610)
addappid(865210)
addappid(880350)
addappid(880351)
addappid(893700)
addappid(906060)
addappid(915590)
addappid(915591)
addappid(1024050)
addappid(2305850)
addappid(2305860)
