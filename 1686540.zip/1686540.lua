-- Lua provided by RyzenAPI
-- Game: my fluffy life

-- MAIN APPLICATION
addappid(1686540)
-- Game: addappid(1686540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686541, 1, "4b0dfe584f59d4c45efe6065f3718798e93ab6cb2deb01650bea1dfcbad70c71")
