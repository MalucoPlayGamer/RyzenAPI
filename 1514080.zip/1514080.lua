-- Lua provided by RyzenAPI 
-- Game: Escalation_Demo
addappid(1514080)
addappid(1514081, 1, "fcb57ffb70aedd591a34f0ec39bf297eefeee179b87de2e4cfe757d4400156b9")
