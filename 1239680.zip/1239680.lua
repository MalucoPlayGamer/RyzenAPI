-- Lua provided by RyzenAPI
-- Game: Day of Dragons Original Soundtrack

-- MAIN APPLICATION
addappid(1239680)
-- Game: addappid(1239680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239683,0,"75ac31a4cb64832907dddf257fbe181337f80b2fe6187370078053814f309052")
addappid(1239687,0,"c3bc09415d53c2a75de35333ca79e262dc5aa324623e76987dc7adb6eb772758")
