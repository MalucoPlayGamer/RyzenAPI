-- Lua provided by RyzenAPI
-- Game: Spheria's Familiar

-- MAIN APPLICATION
addappid(1500100)
addappid(2286350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500101, 1, "53aea630113feb3931ecb7a35438e9bcf72c80868e16cd8f5d1c82af4623bb6c")
