-- Lua provided by RyzenAPI
-- Game: 2086850

-- MAIN APPLICATION
addappid(2086850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086852,0,"4e6ef1421ba9a8edeca4071a9125aa2aa8fa8f786bcb911b18c41043e562a68d")
