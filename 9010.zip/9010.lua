-- Lua provided by RyzenAPI
-- Game: Return to Castle Wolfenstein

-- MAIN APPLICATION
addappid(9010)

-- MAIN APP DEPOTS / PACKAGES
addappid(9011, 1, "c0e9cd613c10302fbe131288c5b91f769fd29e7f2fd436bb6386ff8e114ade48")
