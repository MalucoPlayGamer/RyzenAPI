-- Lua provided by RyzenAPI
-- Game: 928610

-- MAIN APPLICATION
addappid(928610)
-- Game: addappid(928610)

-- MAIN APP DEPOTS / PACKAGES
addappid(928611, 1, "ca798cf8ebefbe6566f2d3919d45dd1de392894307a5f4202b03975cde59c046")
