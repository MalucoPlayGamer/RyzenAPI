-- Lua provided by RyzenAPI
-- Game: Endless Bounty

-- MAIN APPLICATION
addappid(1364730)
-- Game: addappid(1364730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364734,0,"764175e2a7635b9e541b3096c48e0f62f6842d61323dfdcd66fc2b2dfa1190c2")
