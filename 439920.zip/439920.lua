-- Lua provided by RyzenAPI
-- Game: AppID 439920

-- MAIN APPLICATION
addappid(439920)
-- Game: addappid(439920)

-- MAIN APP DEPOTS / PACKAGES
addappid(439921, 1, "6965aea36ddfcc8d645eaab3857a27edb7affba42a2385d20eb249c31256d875")
addappid(439922, 1, "1416906ae4f5811e77b31b4b45ba8ca6c7c6415d9f7d0d765555b5399d6352bb")
