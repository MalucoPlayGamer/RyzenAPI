-- Lua provided by RyzenAPI
-- Game: Game: Colorado Cocoa Club

-- MAIN APPLICATION
addappid(1592970)
-- Game: addappid(1592970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592971, 1, "2e948128a19c2850525d151fedb69a6d7fb5ce103b28b0e88dd40604aacf6349")
addappid(1592972, 1, "3f1b21a98ff2f9431e382d8fc06ffabe24ae0f0655c35bc69c557fb6c3b5e181")
addappid(1592973, 1, "bf0a6d74559854fbadbaf19eed4657996f13138d579b8b76289089ab10b6f8e5")
