-- Lua provided by RyzenAPI
-- Game: Capcom Arcade 2nd Stadium: Mini-Album Track 11 - Saturday Night Slam Masters - Tokyo (Stage 1)

-- MAIN APPLICATION
addappid(2093740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093741, 1, "e09a5d5b863ba6fd444e514d500012cf8b297cee42b2c25ad86822ca3c6010da")
addappid(2093742, 1, "14ec558c432cbd542a7277fc0c2af2aa7c6acfc233744c8561577d101369852a")
addappid(2093743, 1, "09054882b58432170d2bf3c3326e04b488ef984ffa3319bd0e86e1189be7892e")
addappid(2093744, 1, "c05a7eae5d992e8406b966164c7e591dea64123b023374a67697698dab7a4fad")
addappid(2093745, 1, "482f4c1863d9ef76c78628f8e63feb51bba5928102e6891207d6533aa3d1e6fe")
addappid(2093746, 1, "1bbe5c3f19a638c1e56d456a6a861767d202cbca5197623559bd85c65025a4f9")
