-- Lua provided by RyzenAPI
-- Game: InsanZ - Retro Survival Horror

-- MAIN APPLICATION
addappid(367040)

-- MAIN APP DEPOTS / PACKAGES
addappid(367041, 1, "8aefcbd1c8954d0561c44c32fb46b2a4a87ff812730c953f00825a389674c949")
addappid(370230, 0, "c737e82b101a1b8b557254b4129d186ec853cdf20bc0f712deb3ce5e825378a3")
addappid(372170, 0, "534441e4e3405796e3874090f782f35941522c028b31667be1e210f2659cbf25")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
