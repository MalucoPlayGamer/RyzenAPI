-- Lua provided by RyzenAPI
-- Game: Seafrog

-- MAIN APPLICATION
addappid(2107540)
-- Game: addappid(2107540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107541, 1, "364189e481f9d2e792d49c1a002f01fc72527066d1d74cfc5f505b9c6218d831")
