-- Lua provided by RyzenAPI
-- Game: Scene Investigators

-- MAIN APPLICATION
addappid(1159830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159831, 1, "9d4dc039801e80fe8650359da26279da29ce1e43ee5195c25844d49190c3deb3")
addappid(2743690, 0, "645740873c4328fe187ae90d539c9fea2e6808da8887c9c5da47edc04b52b32b")

