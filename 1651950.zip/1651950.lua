-- Lua provided by RyzenAPI
-- Game: addappid(1651950)

-- MAIN APPLICATION
addappid(1651950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651951, 1, "5c53f001c014df687bac4249553fc1822a7e2ff8f57c8e771ade8ede649408a6")
