-- Lua provided by RyzenAPI
-- Game: Game: Ghostrunner Demo

-- MAIN APPLICATION
addappid(1249200)
-- Game: addappid(1249200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249201, 1, "641f72211ef8a55b3bf49029c8eb69216657d271d0d43f1e64d7dc454f3367a1")
