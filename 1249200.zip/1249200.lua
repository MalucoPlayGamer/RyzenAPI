-- Lua provided by SkyAPI 
-- Game: Ghostrunner Demo
addappid(1249200)
addappid(1249201, 1, "641f72211ef8a55b3bf49029c8eb69216657d271d0d43f1e64d7dc454f3367a1")
