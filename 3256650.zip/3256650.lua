-- Lua provided by RyzenAPI
-- Game: Game: Foundation Demo

-- MAIN APPLICATION
addappid(3256650)
-- Game: addappid(3256650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3256651, 1, "9c0d0efd5d0f33cecd3a1564d2fd1c5d549e60e078e5d4b231cd6a5c8245e58e")
