-- Lua provided by RyzenAPI
-- Game: AppID 885590

-- MAIN APPLICATION
addappid(885590)
-- Game: addappid(885590)

-- MAIN APP DEPOTS / PACKAGES
addappid(885591, 1, "4426b5e0f0f965be0e9a02f3b2146596d824f92d74a949d247d6bd24585cd5b2")
