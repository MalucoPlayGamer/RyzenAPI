-- Lua provided by RyzenAPI
-- Game: Time

-- MAIN APPLICATION
addappid(885590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(885591, 1, "4426b5e0f0f965be0e9a02f3b2146596d824f92d74a949d247d6bd24585cd5b2")

