-- Lua provided by RyzenAPI 
-- Game: Love with Furry 🐺
addappid(1807450)
addappid(1807451, 1, "fe37135106d89a8d3897dc5db80b5bf44d4a714085f107015dff6524e93b2cea")
addappid(1820540, 0, "a425dc9ca736f0e9d08ad9b29f53a98e13fbe2f744d6cca0a341c3a115a70c21")
