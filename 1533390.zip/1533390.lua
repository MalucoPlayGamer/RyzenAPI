-- Lua provided by RyzenAPI
-- Game: Gorilla Tag

-- MAIN APPLICATION
addappid(1533390)
addappid(1564750)
-- Game: addappid(1533390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533391, 1, "76a9af57a776f43d1f3210b9c3beb33607799ae510b2c235ba2964972bc6a945")
