-- Lua provided by RyzenAPI
-- Game: 919400

-- MAIN APPLICATION
addappid(919400)
-- Game: addappid(919400)

-- MAIN APP DEPOTS / PACKAGES
addappid(919401, 1, "fb1f7f154b3565f15e1b0c4b9808b18d3d382d1101d707571d699061ae3fa1b0")
