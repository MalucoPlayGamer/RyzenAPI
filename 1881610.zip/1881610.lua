-- Lua provided by RyzenAPI
-- Game: Game: 江湖客栈-The Jianghu

-- MAIN APPLICATION
addappid(1881610)
-- Game: addappid(1881610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881611, 1, "71c6d10530299d341b172ab6c29122935953738ae418806ab848181d50c8d59a")
