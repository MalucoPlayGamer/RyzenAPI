-- Lua provided by RyzenAPI
-- Game: The Third Day

-- MAIN APPLICATION
addappid(1544460)
-- Game: addappid(1544460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544461, 1, "0c1266176648deeed100d58123b6d5cd7f598db4151f8b2e9f8fcce5bae20a8c")
