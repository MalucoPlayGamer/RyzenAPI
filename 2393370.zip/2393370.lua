-- Lua provided by RyzenAPI
-- Game: Dustgrave: A Sandbox RPG

-- MAIN APPLICATION
addappid(2393370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2393371, 1, "3a80ab218d76f36f4ea66464750af046872e58c208dba0aa0b61c6c49f77716b")

