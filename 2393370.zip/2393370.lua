-- Lua provided by SkyAPI 
-- Game: Dustgrave: A Sandbox RPG
addappid(2393370)
addappid(2393371, 1, "3a80ab218d76f36f4ea66464750af046872e58c208dba0aa0b61c6c49f77716b")
