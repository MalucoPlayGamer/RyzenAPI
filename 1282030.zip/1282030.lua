-- Lua provided by RyzenAPI
-- Game: 1282030

-- MAIN APPLICATION
addappid(1282030)
-- Game: addappid(1282030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282031, 1, "c51321d164d88285df57ecd725194a8eeccd41bdde5371144639449d911b2cc8")
