-- Lua provided by SkyAPI 
-- Game: AppID 1282030
addappid(1282030)
addappid(1282031, 1, "c51321d164d88285df57ecd725194a8eeccd41bdde5371144639449d911b2cc8")
