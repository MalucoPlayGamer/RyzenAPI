-- Lua provided by RyzenAPI
-- Game: addappid(200940)

-- MAIN APPLICATION
addappid(200940)

-- MAIN APP DEPOTS / PACKAGES
addappid(200941, 1, "ffaf0eda656cdfed561eea11d77130a60b5421fcaf13f888eb80d2b590639cff")
