-- Lua provided by RyzenAPI
-- Game: Das Boot: German U-Boat Simulation

-- MAIN APPLICATION
addappid(1782080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782081, 1, "b3a95a3c7ab7d3623a22a4f92aabdb38839d00b990240bb474f9873bf3ad36e5")

