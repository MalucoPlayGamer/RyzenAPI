-- Lua provided by RyzenAPI
-- Game: Unstoppable Hamster

-- MAIN APPLICATION
addappid(782300)

-- MAIN APP DEPOTS / PACKAGES
addappid(782301, 1, "a34e338f5531a466fc6fd96c4544f0730297d5cf3e355a8803eda74b7f360082")
