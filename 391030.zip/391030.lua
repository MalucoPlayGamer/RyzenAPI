-- Lua provided by RyzenAPI
-- Game: Hard to Be a God

-- MAIN APPLICATION
addappid(391030)

-- MAIN APP DEPOTS / PACKAGES
addappid(391031, 1, "abf55b7a0c3cf22000f78ced6f6b9eb33ec51a8344b3c0f3f8e87501c14a93bf")

