-- Lua provided by RyzenAPI
-- Game: Hydroponics Farm & Store Simulator

-- MAIN APPLICATION
addappid(3152540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152541, 1, "908fc9d312414097b4bc6a0636fd34b8c86607b121a294a1c0ce21c37c0ad1ea")
