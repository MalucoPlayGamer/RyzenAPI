-- Lua provided by SkyAPI 
-- Game: Hydroponics Farm & Store Simulator
addappid(3152540)
addappid(3152541, 1, "908fc9d312414097b4bc6a0636fd34b8c86607b121a294a1c0ce21c37c0ad1ea")
