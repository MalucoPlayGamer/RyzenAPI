-- Lua provided by RyzenAPI
-- Game: Darkness Road Demo

-- MAIN APPLICATION
addappid(2223830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223831, 1, "9195fa6fce41518689ff350059d3ec940f6344f97b0472e0d340d428a4772d87")
