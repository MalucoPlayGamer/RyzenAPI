-- Lua provided by RyzenAPI
-- Game: 2101670

-- MAIN APPLICATION
addappid(2101670)
-- Game: addappid(2101670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101674,0,"f2672959709f2a762c6a466c02dca66b0978be899a2c643f7a36963c95eaebed")
