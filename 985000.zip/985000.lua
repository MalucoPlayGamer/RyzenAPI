-- Lua provided by SkyAPI 
-- Game: Potion Paws
addappid(985000)
addappid(985001, 1, "7997a594a5d8178af1d5b34b070aa62cf302a78caf8b9748637a30ad5be1f9bc")
