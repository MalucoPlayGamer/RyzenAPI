-- Lua provided by RyzenAPI
-- Game: Potion Paws

-- MAIN APPLICATION
addappid(985000)
-- Game: addappid(985000)

-- MAIN APP DEPOTS / PACKAGES
addappid(985001, 1, "7997a594a5d8178af1d5b34b070aa62cf302a78caf8b9748637a30ad5be1f9bc")
