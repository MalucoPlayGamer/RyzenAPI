-- Lua provided by RyzenAPI
-- Game: Carnivores: Dinosaur Hunt

-- MAIN APPLICATION
addappid(1461030)
addappid(2059460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461031, 1, "6b6d8c8d1a28bc1f9538e1fca73ffaf914086abff2baf8a39c84f268c1361d8b")

