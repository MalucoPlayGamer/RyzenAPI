-- Lua provided by RyzenAPI
-- Game: Overload

-- MAIN APPLICATION
addappid(448850)

-- MAIN APP DEPOTS / PACKAGES
addappid(448851, 1, "459c4377ae4d35bc6b859ff31e963479efa312b0aef84d3e1e24846b25d87d24")
addappid(448852, 1, "212f5bd7bf986e262a21755ea39471445b4624ff89a0cda936bfd57c11133ad0")
addappid(448853, 1, "c7afbc423ba8c217d9fc47e3be9a1c7375f2c7cd51a8e318cb5d9557808146cb")
addappid(448854, 1, "23fa7dc7328c46c04bfba2d397da5c7b3a2ca4d0c8720a7f14d4f2c08edaac61")
addappid(448856, 1, "973afa6e85652f0145818dd45fbfc4f0aea7132425c95e3cd00218204cdc56b2")
addappid(448858, 1, "5211eeeddac9afb2eb405a73b0c6d0f0415081be437ba7085fb295e928d5000f")
addappid(448859, 1, "f6a2037398b17fba50a5becd2f90939c3e18b5f50623eae97d61f7c569797ee8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(884970)
addappid(954030)
addappid(1119750)
