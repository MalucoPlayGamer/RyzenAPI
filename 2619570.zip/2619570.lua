-- Lua provided by RyzenAPI
-- Game: Fallen Ninja

-- MAIN APPLICATION
addappid(2619570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619571, 1, "340eaf235767cb363715d38ad39e894f587d5dfc3092653bb159e62ac5513886")

