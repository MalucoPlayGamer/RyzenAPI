-- Lua provided by RyzenAPI
-- Game: Fae Farm

-- MAIN APPLICATION
addappid(2230110)
addappid(2480120)
addappid(2673180)
addappid(2678250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2230111, 1, "85f39a6c9f828f27279a4223cc232f8e3c01bce8a20eacfd284eedeac6b01f47")

