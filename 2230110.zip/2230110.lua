-- Lua provided by RyzenAPI
-- Game: Fae Farm

-- MAIN APPLICATION
addappid(2230110)
addappid(2480120)
addappid(2673180)
addappid(2678250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230111, 1, "85f39a6c9f828f27279a4223cc232f8e3c01bce8a20eacfd284eedeac6b01f47")
