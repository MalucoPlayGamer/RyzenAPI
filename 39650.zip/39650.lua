-- Lua provided by RyzenAPI
-- Game: Game: AppID 39650

-- MAIN APPLICATION
addappid(39650)
-- Game: addappid(39650)

-- MAIN APP DEPOTS / PACKAGES
addappid(39651, 1, "fdfb7b702cf4895d171d700ce5ab5356248708efe4fec586d68e9daaf48d12e1")
addappid(39652, 1, "680cfd77d62006e119adfe5c2e0c68a179b29f253be552656a310ba13718e60b")
addappid(39653, 1, "54c2e134a9dae47311674d9e05ab7adb769f26753efba24dd48444e539dbca6a")
addappid(39654, 1, "91425b55ada7c48b4a153eba9d92643d0b0c555d2eae248873c5078f7f958df3")
addappid(39655, 1, "f1f5dcdae19bc7c0bf19f618619389c054b233ff1a37e794b82449a100130eba")
