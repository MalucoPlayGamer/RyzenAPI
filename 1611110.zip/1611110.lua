-- Lua provided by RyzenAPI
-- Game: AMID THE LINES

-- MAIN APPLICATION
addappid(1611110)
-- Game: addappid(1611110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611111, 1, "3d736b6450fe07c2a98f498f1a26def6c5fdc2b273fabd40428b2a888c36d91a")
