-- Lua provided by RyzenAPI
-- Game: Game: Welcome Home

-- MAIN APPLICATION
addappid(3434440)
-- Game: addappid(3434440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3434441, 1, "35c97aab1ecc4a753f633d082d06efd41d2f66721599a251b038df8a690d850d")
