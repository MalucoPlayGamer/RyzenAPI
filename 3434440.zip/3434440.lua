-- Lua provided by RyzenAPI 
-- Game: Welcome Home
addappid(3434440)
addappid(3434441, 1, "35c97aab1ecc4a753f633d082d06efd41d2f66721599a251b038df8a690d850d")
