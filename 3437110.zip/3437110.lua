-- Lua provided by RyzenAPI
-- Game: Satan's Dungeon

-- MAIN APPLICATION
addappid(3437110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3437111, 1, "ab21a2dc60eb0eafbd167b4e90d742c3bf9a8ca58a1c846df5853e06c70dd49d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
