-- Lua provided by RyzenAPI
-- Game: Game: Satan's Dungeon

-- MAIN APPLICATION
addappid(3437110)
-- Game: addappid(3437110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3437111, 1, "ab21a2dc60eb0eafbd167b4e90d742c3bf9a8ca58a1c846df5853e06c70dd49d")
