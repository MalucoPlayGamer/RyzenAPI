-- Lua provided by RyzenAPI
-- Game: addappid(3216120)

-- MAIN APPLICATION
addappid(3216120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216121, 1, "9f92210cfbd0e9d3a44b4b3409c733cebca0d0cd86d49f22d650add617bf9aa7")
