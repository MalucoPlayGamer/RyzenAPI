-- Lua provided by RyzenAPI
-- Game: Luminary

-- MAIN APPLICATION
addappid(1648360) -- Luminary

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1648361, 1, "0f4aace15d1f5cf42a8b1a32086c9bb0abb4cd8246f9836727c0d01aac6f79a7") -- Depot 1648361

