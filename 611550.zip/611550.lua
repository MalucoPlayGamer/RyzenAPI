-- Lua provided by RyzenAPI
-- Game: Underground Keeper 2

-- MAIN APPLICATION
addappid(611550)

-- MAIN APP DEPOTS / PACKAGES
addappid(611551, 1, "9a2b0326902a02c2042c2c1c3ed98bed35262475e51594a066c887a503929349")

