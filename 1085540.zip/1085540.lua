-- Lua provided by RyzenAPI 
-- Game: AppID 1085540
addappid(1085540)
addappid(1085541, 1, "2d4834f580d753194683ba3f491c8d811ddcf431913fb91c940bd72c89322964")
