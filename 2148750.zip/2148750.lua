-- Lua provided by RyzenAPI
-- Game: 2148750

-- MAIN APPLICATION
addappid(2148750)
-- Game: addappid(2148750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148751, 1, "54ed0e104c32f6b8c4db4a3968bd4bb5651a3fc75f2cffce941dcdc4d33969d0")
