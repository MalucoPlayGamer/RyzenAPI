-- Lua provided by RyzenAPI
-- Game: Game: AppID 852080

-- MAIN APPLICATION
addappid(852080)
-- Game: addappid(852080)

-- MAIN APP DEPOTS / PACKAGES
addappid(852081, 1, "6d4fe79080981d0c2d02577c16a408b90755d49c669a0b0fa190c8eb9c5ce6f1")
