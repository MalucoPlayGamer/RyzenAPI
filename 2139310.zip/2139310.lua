-- Lua provided by RyzenAPI
-- Game: AppID 2139310

-- MAIN APPLICATION
addappid(2139310)
-- Game: addappid(2139310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139311, 1, "0fa972d801b4d3fbc1640e38f3410db0d861905e6c27a11ac0b08d314a22d012")
