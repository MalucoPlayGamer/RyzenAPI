-- Lua provided by RyzenAPI
-- Game: Dungeons of Hinterberg: Original Game Soundtrack

-- MAIN APPLICATION
addappid(3064440)
-- Game: addappid(3064440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064441, 1, "d775b2326aaf5441963499cbdc5657da1b024717bd0735631de3f2cdb7c15e5b")
addappid(3064442, 1, "a36b6c073d5190bc596ee8b4fd437493c5b3b1c836ee148f7534e51cbfce9bc0")
