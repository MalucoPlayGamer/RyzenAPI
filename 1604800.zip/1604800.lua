-- Lua provided by RyzenAPI
-- Game: Game: AppID 1604800

-- MAIN APPLICATION
addappid(1604800)
-- Game: addappid(1604800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604801, 1, "3b4f9a9a5ae95b7fcf1e088eea3b8837311a2589b87335c7ec14b9116ae7f7c2")
