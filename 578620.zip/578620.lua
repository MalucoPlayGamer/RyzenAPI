-- Lua provided by RyzenAPI
-- Game: Game: GORN

-- MAIN APPLICATION
addappid(578620)
-- Game: addappid(578620)

-- MAIN APP DEPOTS / PACKAGES
addappid(578621, 1, "e15b45d0f27d15fa846e4c7492e624f5abdb8df8587117a3da275e007dbfcfef")
