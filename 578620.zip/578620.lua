-- Lua provided by RyzenAPI 
-- Game: GORN
addappid(578620)
addappid(578621, 1, "e15b45d0f27d15fa846e4c7492e624f5abdb8df8587117a3da275e007dbfcfef")
