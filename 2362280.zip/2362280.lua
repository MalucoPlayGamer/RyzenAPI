-- Lua provided by RyzenAPI
-- Game: 2362280

-- MAIN APPLICATION
addappid(2362280)
-- Game: addappid(2362280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362281, 1, "b23c986a0066a856bdb8e8e8217a3f118d3d70c1d8f7fa9caff5835e0c486ac1")
