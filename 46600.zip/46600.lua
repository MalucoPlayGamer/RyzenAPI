-- Lua provided by RyzenAPI 
-- Game: Swarm Arena
addappid(46600)
addappid(46601, 1, "f66d39edd77514c0debc127659a19cbd1a21837a89592d8b51762dbe15bc1b3e")
