-- Lua provided by RyzenAPI
-- Game: addappid(631010)

-- MAIN APPLICATION
addappid(631010)

-- MAIN APP DEPOTS / PACKAGES
addappid(631011, 1, "301101c941b4d2fcd9bb1310bc46ded37e438b5eb9999bfdf42b6efa321934ff")
