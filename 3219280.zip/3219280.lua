-- Lua provided by RyzenAPI
-- Game: 3219280

-- MAIN APPLICATION
addappid(3219280)
-- Game: addappid(3219280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3219280,0,"15da4d4bbc7bee3c74409db6686c99d5d84f702435b9b8629eeab43ffe731289")
