-- Lua provided by RyzenAPI 
-- Game: Hentai Beach
addappid(2262190)
addappid(2262191, 1, "357a3f692d4209e9e9243ff7425db4f45cd63fad4eff5bb1d6256c8805795746")
