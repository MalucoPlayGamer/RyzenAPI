-- Lua provided by SkyAPI 
-- Game: AppID 1073410
addappid(1073410)
addappid(1073411, 1, "45f3a862d38ddd9eb75d6d8bf62c355e9e9dfde5fc456fa82a88cb68ca8dd6ae")
