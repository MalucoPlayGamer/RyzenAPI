-- Lua provided by RyzenAPI
-- Game: AppID 655020

-- MAIN APPLICATION
addappid(655020)
-- Game: addappid(655020)

-- MAIN APP DEPOTS / PACKAGES
addappid(655021, 1, "d144ad9651b515d430b104a6de90c6946bf0b206a3a1501ecda34b624e5da030")
