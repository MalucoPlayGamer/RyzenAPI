-- Lua provided by RyzenAPI
-- Game: Game: AppID 1303670

-- MAIN APPLICATION
addappid(1303670)
-- Game: addappid(1303670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303671, 1, "45714352c2e9f81eaa578b84056a3c1cd50418730254b654bd9ba26722aa7b0c")
