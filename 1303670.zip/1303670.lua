-- Lua provided by RyzenAPI
-- Game: AppID 1303670

-- MAIN APPLICATION
addappid(1303670)
addappid(1765650)
addappid(2282040)
addappid(2480140)
addappid(2520150)
addappid(3154060)
addappid(3154070)
addappid(3666560)
addappid(3666570)
addappid(3666580)
addappid(4338920)
addappid(4338930)
addappid(4974180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303671, 1, "45714352c2e9f81eaa578b84056a3c1cd50418730254b654bd9ba26722aa7b0c")

