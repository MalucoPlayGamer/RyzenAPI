-- Lua provided by RyzenAPI
-- Game: Moonbase 332

-- MAIN APPLICATION
addappid(397580)
addappid(611910)

-- MAIN APP DEPOTS / PACKAGES
addappid(397581, 1, "21763c3599eae050725bfff96b2cc52897e28f48a3b9599045f68e122454c470")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
