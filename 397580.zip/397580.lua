-- Lua provided by RyzenAPI
-- Game: Moonbase 332

-- MAIN APPLICATION
addappid(397580)
addappid(611910)

-- MAIN APP DEPOTS / PACKAGES
addappid(397581, 1, "21763c3599eae050725bfff96b2cc52897e28f48a3b9599045f68e122454c470")

