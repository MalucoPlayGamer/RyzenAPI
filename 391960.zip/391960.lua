-- Lua provided by RyzenAPI
-- Game: Super Mega Bob

-- MAIN APPLICATION
addappid(391960)

-- MAIN APP DEPOTS / PACKAGES
addappid(391961, 1, "85df275e217c89296c5f7fa77f355de750b92f2a1ffd5a3d39bb2248b9cc5e3b")
