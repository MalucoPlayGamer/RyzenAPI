-- Lua provided by RyzenAPI
-- Game: Super Mega Bob

-- MAIN APPLICATION
addappid(391960)

-- MAIN APP DEPOTS / PACKAGES
addappid(391961, 1, "85df275e217c89296c5f7fa77f355de750b92f2a1ffd5a3d39bb2248b9cc5e3b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
