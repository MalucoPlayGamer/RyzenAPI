-- Lua provided by RyzenAPI 
-- Game: Jurassic Park Classic Games Collection
addappid(2673080)
addappid(2673081, 1, "44b74c15af1eb6222ba220c7da6bdd9d9856c629fe07e0aa19dae4b863fe03d3")
