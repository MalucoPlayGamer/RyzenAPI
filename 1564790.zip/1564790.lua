-- Lua provided by RyzenAPI
-- Game: Game: Submachine: Legacy

-- MAIN APPLICATION
addappid(1564790)
-- Game: addappid(1564790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564791, 1, "0ebb96990d2afc45612b5a8f991dfb34da29feea45b165a9dd3713ac6a1bade7")
