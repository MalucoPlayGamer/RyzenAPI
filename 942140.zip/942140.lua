-- Lua provided by RyzenAPI
-- Game: Fap Queen

-- MAIN APPLICATION
addappid(942140)

-- MAIN APP DEPOTS / PACKAGES
addappid(942141, 1, "acff483afed7c3d754fd538bb5fefdec006e6057e2c324539301ec36419dd9ce")
