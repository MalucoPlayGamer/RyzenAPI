-- Lua provided by RyzenAPI
-- Game: 2010430

-- MAIN APPLICATION
addappid(2010430)
-- Game: addappid(2010430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010431, 1, "918867ed7a440cfe27b02b656eaa1483ab5ea9353d3ece1baf6c680664098164")
