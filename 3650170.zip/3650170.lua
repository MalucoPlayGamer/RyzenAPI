-- Lua provided by RyzenAPI
-- Game: Marsupilami 2 - Salsa Palombia

-- MAIN APP DEPOTS / PACKAGES
addappid(3650170, 1, "3164718b45521580ebb9f66952e0f62cf1ceb7317abb26387df0dafbbee71d39") -- Marsupilami 2 - Salsa Palombia
addappid(3650171, 1, "491d8bae6ac6e2a59caf140cea6e4a40ace00f92bd74946316ea5f3d2e580fd0") -- Depot 3650171
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
