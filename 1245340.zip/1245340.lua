-- Lua provided by RyzenAPI
-- Game: 1245340

-- MAIN APPLICATION
addappid(1245340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245340,0,"68d0be95cde26121c8dd4b52b5ffdac2a6a0d664d4e83961251ddf8b922646df")
