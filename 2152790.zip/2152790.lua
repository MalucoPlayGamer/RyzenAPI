-- Lua provided by RyzenAPI
-- Game: UNITED 1944

-- MAIN APPLICATION
addappid(2152790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152791, 1, "5f4774fdde25deea3ecf3171f98a93a856501693cd1b5ac463101fb499f3a2f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
