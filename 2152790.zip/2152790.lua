-- Lua provided by RyzenAPI
-- Game: Game: UNITED 1944

-- MAIN APPLICATION
addappid(2152790)
-- Game: addappid(2152790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152791, 1, "5f4774fdde25deea3ecf3171f98a93a856501693cd1b5ac463101fb499f3a2f9")
