-- Lua provided by RyzenAPI
-- Game: addappid(3703280)

-- MAIN APPLICATION
addappid(3703280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3703281, 1, "a2bff624f3656912154165cfecd1216e3fe4ab6d241505ff180cfe7be3e7c08e")
