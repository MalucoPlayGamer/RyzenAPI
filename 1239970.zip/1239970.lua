-- Lua provided by RyzenAPI
-- Game: addappid(1239970)

-- MAIN APPLICATION
addappid(1239970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239971, 1, "84ed95730d487ecf0fe8f309bd43c1ab4afe09c41799ec60a17e65044b4a7d57")
