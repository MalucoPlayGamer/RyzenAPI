-- Lua provided by RyzenAPI
-- Game: HexBat

-- MAIN APPLICATION
addappid(2375020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375021, 1, "d6364a021fee035e6dcbfdaf44f0bdc406508a37d038561089f0ac98985b701e")
