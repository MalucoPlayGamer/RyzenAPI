-- Lua provided by RyzenAPI
-- Game: Deadeye Deepfake Simulacrum

-- MAIN APPLICATION
addappid(1545990)
-- Game: addappid(1545990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545991, 1, "c1423b26c8f601a3b2d9d27b3dc2750d2104b9336dab2feb761582d257270f7a")
addappid(1545992, 1, "2638e45da965eb93dd46dc8493a12826f0c81c69d8e48eee9690409ad1f09ecc")
addappid(1545993, 1, "859c43bf083d4055c8a05feb66d3dd78222acd8565cd8fe534d299e8a64c9fde")
