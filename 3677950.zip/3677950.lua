-- Lua provided by RyzenAPI
-- Game: 3677950

-- MAIN APPLICATION
addappid(3677950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3677950,0,"e69349d5a4875e578facf2db40e1f3271e8de3eaa329dd9d05136ae4c2a7cbfb")

