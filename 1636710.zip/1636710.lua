-- Lua provided by RyzenAPI
-- Game: 1636710

-- MAIN APPLICATION
addappid(1636710)
-- Game: addappid(1636710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636711, 1, "4b89b9f61f17df4f8fc72e79e1ec6edb272ca29a9ed84979d5189c943c0b433a")
