-- Lua provided by RyzenAPI
-- Game: addappid(418310)

-- MAIN APPLICATION
addappid(418310)

-- MAIN APP DEPOTS / PACKAGES
addappid(418311, 1, "2091aa013359ebc395e826735424f71af96b8b197db55865659abfbe5fb9b816")
