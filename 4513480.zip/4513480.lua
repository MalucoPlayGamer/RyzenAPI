-- Lua provided by RyzenAPI
-- Game: Scarlet Skips

-- MAIN APPLICATION
addappid(4513480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4513481, 1, "727db0593b92ccccb4e7447fae0aa10f9cfb0f123994efaaa624b3c1abd0b7f9") -- (windows)

