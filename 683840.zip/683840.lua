-- Lua provided by RyzenAPI
-- Game: addappid(683840)

-- MAIN APPLICATION
addappid(683840)

-- MAIN APP DEPOTS / PACKAGES
addappid(683841, 1, "1e65defbd1cd2958b12137dec98ad96bad7310fccb42ed5406869db9fc4bf0e3")
