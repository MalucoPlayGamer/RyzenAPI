-- Lua provided by RyzenAPI
-- Game: AppID 930290

-- MAIN APPLICATION
addappid(930290)

-- MAIN APP DEPOTS / PACKAGES
addappid(930291, 1, "2a6cbbe71e00a58b031cff3c17681ac028dca469185ee6cc2adc636f568b2f31")
