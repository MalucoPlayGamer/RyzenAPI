-- Lua provided by RyzenAPI
-- Game: The Chaos Engine

-- MAIN APPLICATION
addappid(242530)

-- MAIN APP DEPOTS / PACKAGES
addappid(242531, 1, "3d579563b031a89f92d31d16780bd49d72605c064d585ed8366dc195181c6942")
addappid(242532, 1, "e46197303aaa6243a8bb786d2757bab1b20f6b9e543f210b18d7e4bdbc83990a")
addappid(242533, 1, "c7f8b791339565e154aea86ec4195c81643434f6b863465b67eda150147afc24")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
