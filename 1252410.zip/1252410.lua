-- Lua provided by RyzenAPI
-- Game: Alien Scumbags

-- MAIN APPLICATION
addappid(1252410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252412,0,"8810a716fea7b462f41f8b5366060481e4b5139ae8fa841f06a601fdf6a127f9")

