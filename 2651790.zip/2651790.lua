-- Lua provided by RyzenAPI
-- Game: Wonderland

-- MAIN APPLICATION
addappid(2651790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651791, 1, "2f5ebcdd5a1b92113fe40b131484f3337a9e1b7e71b98a66aa8b601bb0616a20")

