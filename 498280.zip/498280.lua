-- Lua provided by RyzenAPI
-- Game: Game: Jurassic Survival

-- MAIN APPLICATION
addappid(498280)
-- Game: addappid(498280)

-- MAIN APP DEPOTS / PACKAGES
addappid(498281, 1, "252977732454e462a6b1116cdb758c905bcfd617f9c0332aec5c678a3aa91c67")
