-- Lua provided by RyzenAPI
-- Game: Tyrant's Realm Demo

-- MAIN APPLICATION
addappid(2416810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416811, 1, "9f2fbd6506e7a7f2e50f71436270489245caae28c40054f0229407447d17a2b5")
