-- Lua provided by RyzenAPI
-- Game: 1967420

-- MAIN APPLICATION
addappid(1967420)
-- Game: addappid(1967420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967422,0,"8b838355ad7d7952d65da122d5d5c627af631f2b75bcfc7927d4b86b384565a8")
addappid(1967423,0,"9dfafdd8ea3a52fc0a5def28598abd413132d65ba62eb2ea6a62b1d3d1c6fa25")
