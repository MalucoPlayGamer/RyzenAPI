-- Lua provided by RyzenAPI
-- Game: Chicken Fight

-- MAIN APPLICATION
addappid(2159470)
-- Game: addappid(2159470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159471, 1, "8a9b360765a3544783aeae704d1cf9e012e03a414ad70791cad7b963fe36f661")
addappid(2159472, 1, "22e21d328825b8f316128384cae227be143346fd3d01fdf821ed30cad969c57d")
addappid(2159473, 1, "dc095883dd1049578182719b7e98dcac9e8e7b5aab5f7708d18a046d4f08ffe5")
