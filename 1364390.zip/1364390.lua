-- Lua provided by RyzenAPI
-- Game: Game: AppID 1364390

-- MAIN APPLICATION
addappid(1364390)
addappid(2103520)
addappid(2103521)
addappid(2383340)
addappid(2383341)
-- Game: addappid(1364390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364391, 1, "a99c58b77a65255cf19c64ca6f1459503c94e53f93331e552830e4b9bc0e11d6")
