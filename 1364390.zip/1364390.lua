-- Lua provided by RyzenAPI
-- Game: AppID 1364390

-- MAIN APPLICATION
addappid(1364390)
addappid(1430880)
addappid(1430881)
addappid(2103520)
addappid(2103521)
addappid(2383340)
addappid(2383341)
addappid(3325930)
addappid(3325940)
addappid(3959600)
addappid(3959610)
addappid(3959620)
addappid(3959630)
addappid(3959640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(1364391, 1, "a99c58b77a65255cf19c64ca6f1459503c94e53f93331e552830e4b9bc0e11d6")

