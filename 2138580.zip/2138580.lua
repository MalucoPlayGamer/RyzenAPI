-- Lua provided by RyzenAPI
-- Game: Exotica: Petshop Simulator

-- MAIN APPLICATION
addappid(2138580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138581, 1, "60f1fb7fc856ccea0ecfbf407e2abdbdef73510fa93717f9f93fc5ac94c18f59")

