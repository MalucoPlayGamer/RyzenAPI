-- Lua provided by RyzenAPI
-- Game: Exotica: Petshop Simulator

-- MAIN APPLICATION
addappid(2138580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138581, 1, "60f1fb7fc856ccea0ecfbf407e2abdbdef73510fa93717f9f93fc5ac94c18f59")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
