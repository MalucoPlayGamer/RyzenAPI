-- Lua provided by RyzenAPI
-- Game: Block Tower TD

-- MAIN APPLICATION
addappid(2427570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427571, 1, "76ca07b10084cc724a8dfcb97d2b0e2a8c16bdfd9f8c563780d072537775ea3d")
