-- Lua provided by RyzenAPI
-- Game: addappid(857450)

-- MAIN APPLICATION
addappid(857450)

-- MAIN APP DEPOTS / PACKAGES
addappid(857451, 1, "ebe91c0b2e2a74e9c0f7310fe1c2ed4cd4d73ff23423844f4124cab275deb25f")
addappid(857452, 1, "5fe515530a0a8c65b8232ebe5a4d86e63f945bae459161d4d510993194e1ccf9")
addappid(857454, 1, "fbb65d7c6d5e5b9b7d6690e9fe74b88b01910ec5fd7692e30f38767fd59a6af3")
