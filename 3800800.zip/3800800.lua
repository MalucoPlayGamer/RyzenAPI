-- Lua provided by RyzenAPI 
-- Game: The First Scene
addappid(3800800)
addappid(3800801, 1, "6bcdebc09629a1aca3dead3c920b94bd8f8acd8bf0c56120443f6ac85b7ebdb1")
