-- Lua provided by RyzenAPI
-- Game: Deadstep

-- MAIN APPLICATION
addappid(751470)

-- MAIN APP DEPOTS / PACKAGES
addappid(751471, 1, "f78fb47bfac8a401d77b6332a1dd7ac1b09176b3bcb5fcd65cf7d3ed64901c0f")

