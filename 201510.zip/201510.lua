-- Lua provided by RyzenAPI
-- Game: addappid(201510)

-- MAIN APPLICATION
addappid(201510)

-- MAIN APP DEPOTS / PACKAGES
addappid(201511, 1, "bab4b4c84e619a3f2fc6afd2739e422022f0ec8d449c3de6d7c16f5ba1105713")
