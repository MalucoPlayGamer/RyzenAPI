-- Lua provided by RyzenAPI
-- Game: addappid(2180700)

-- MAIN APPLICATION
addappid(2180700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180701, 1, "1a3afd2b5bca70b964b2d7ac5c0bccbf8053789ba9850a7296df35e61999b7ac")
