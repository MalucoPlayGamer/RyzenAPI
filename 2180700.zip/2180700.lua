-- Lua provided by RyzenAPI
-- Game: ABI-DOS

-- MAIN APPLICATION
addappid(2180700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180701, 1, "1a3afd2b5bca70b964b2d7ac5c0bccbf8053789ba9850a7296df35e61999b7ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
