-- Lua provided by RyzenAPI
-- Game: Riddles of Fate: Into Oblivion Collector's Edition

-- MAIN APPLICATION
addappid(647900)

-- MAIN APP DEPOTS / PACKAGES
addappid(647901,0,"5525f20e8233e9e404e8a988dbe3e49595320fc8448f985c676b86837f71f698")

