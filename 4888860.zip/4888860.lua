-- 4888860's Lua and Manifest Created by Hubcap Manifest
-- Loss Limit
-- Created: August 21, 2026 at 11:30:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4888860) -- Loss Limit
-- MAIN APP DEPOTS
addappid(4888861, 1, "c9e80ee15ea5c2a8e545f566f5a13b250ca78799a0eab020a56086b9842ba872") -- Depot 4888861
setManifestid(4888861, "449531219588045377", 1051844588)
addappid(4888862, 1, "fb3042e31ab4f9c566cf7a00486f70519319dd7b4c3965d22b169d9cb93829c9") -- Depot 4888862
setManifestid(4888862, "6470116649647748025", 901321475)