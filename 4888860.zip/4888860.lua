-- Lua provided by RyzenAPI
-- Game: Loss Limit

-- MAIN APPLICATION
addappid(4888860) -- Loss Limit

-- MAIN APP DEPOTS / PACKAGES
addappid(4888861, 1, "c9e80ee15ea5c2a8e545f566f5a13b250ca78799a0eab020a56086b9842ba872") -- Depot 4888861
addappid(4888862, 1, "fb3042e31ab4f9c566cf7a00486f70519319dd7b4c3965d22b169d9cb93829c9") -- Depot 4888862

