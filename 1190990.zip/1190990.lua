-- Lua provided by RyzenAPI
-- Game: Colormeleons

-- MAIN APPLICATION
addappid(1190990)
addappid(1309020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190991, 1, "48043af8d5c00bdad39cbf64def6170a88cd2f07bfcb3e2dd3177f429a9ec82e")
