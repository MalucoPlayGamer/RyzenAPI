-- Lua provided by RyzenAPI
-- Game: 782090

-- MAIN APPLICATION
addappid(782090)
-- Game: addappid(782090)

-- MAIN APP DEPOTS / PACKAGES
addappid(782091, 1, "ffcca4e6f11c5db3539200b28f79d1257f071e73424dae54d57d86b13dd5e2d8")
addappid(782092, 1, "976157d0f8f76f7468116577f2e7bc4ee9f827bc29365bb9fdfda839fd683851")
