-- Lua provided by RyzenAPI
-- Game: Cascadia

-- MAIN APPLICATION
addappid(2438970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438971, 1, "03616ac335908e0af8789dd512d572392b54872667ba0163e8246f0de1bddc42")

