-- Lua provided by RyzenAPI
-- Game: RGB RUN

-- MAIN APPLICATION
addappid(978340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(978341, 1, "1bd42d2b7e81bc4748402a133cd6f2c6c10b18e0950625957e00513e4428f993")
addappid(981230, 0, "aa54ffb3e5bdca3cb8ed5aed6ead15da087f7da6fb382875e93b8dc4f3aa41b1")

