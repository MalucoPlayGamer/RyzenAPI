-- Lua provided by RyzenAPI
-- Game: AppID 978340

-- MAIN APPLICATION
addappid(978340)

-- MAIN APP DEPOTS / PACKAGES
addappid(978341, 1, "1bd42d2b7e81bc4748402a133cd6f2c6c10b18e0950625957e00513e4428f993")
addappid(981230, 0, "aa54ffb3e5bdca3cb8ed5aed6ead15da087f7da6fb382875e93b8dc4f3aa41b1")
