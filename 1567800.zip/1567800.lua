-- Lua provided by RyzenAPI
-- Game: Game: 星空列车与白的旅行

-- MAIN APPLICATION
addappid(1567800)
-- Game: addappid(1567800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567801, 1, "7bbc4910773b61294434cfa7d2e40ac4caa8fd058486b5d45925e01f63d9417c")
