-- Lua provided by RyzenAPI
-- Game: Game: Rail Adventures

-- MAIN APPLICATION
addappid(272920)
-- Game: addappid(272920)

-- MAIN APP DEPOTS / PACKAGES
addappid(272921, 1, "6137bfd909da2242c9459236d10ed601fe5811655005617022d719100f0e8887")
