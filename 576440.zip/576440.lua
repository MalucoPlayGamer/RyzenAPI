-- Lua provided by RyzenAPI
-- Game: AppID 576440

-- MAIN APPLICATION
addappid(576440)

-- MAIN APP DEPOTS / PACKAGES
addappid(576441, 1, "bc5ee3dea71fd81ceb80ab2746d4da3f4f463ee03a9769f155b84baa4a3e7a33")
