-- Lua provided by RyzenAPI
-- Game: STAR OCEAN THE DIVINE FORCE

-- MAIN APPLICATION
addappid(1776380)
addappid(2022280)
addappid(2022281)
addappid(2022282)
addappid(2022283)
addappid(2022284)
addappid(2022285)
addappid(2022286)
addappid(2022287)
addappid(2022288)
addappid(2022289)
addappid(2022300)
addappid(2022303)
addappid(2022304)
addappid(2022305)
addappid(2051320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1776381, 1, "1f248b88e3052984008898821206c24c394919992efefa37dc2e317cf7e48486")

