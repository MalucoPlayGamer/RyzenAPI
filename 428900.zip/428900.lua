-- Lua provided by RyzenAPI
-- Game: Linea, the Game

-- MAIN APPLICATION
addappid(428900)
-- Game: addappid(428900)

-- MAIN APP DEPOTS / PACKAGES
addappid(428901, 1, "226364d383ec023443db1c8508aab04acc44d4d23f4cbc794a18ff389aa48e2b")
addappid(428902, 1, "57bda408f591c9ed7228b9bad8cb7a475b8783b53bb3a63972d75b40337192c9")
addappid(428903, 1, "4b67cfd8c7fd04ab3ed03bd4d0bd850c3432162f5060fd20b21d5e0e33adf641")
addappid(453330, 0, "9eae251e1603198dc815362841c312e09e7c92d743ede6017d2a3f09ca3d9e11")
