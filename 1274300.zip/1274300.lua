-- Lua provided by SkyAPI 
-- Game: AppID 1274300
addappid(1274300)
addappid(1274301, 1, "15ca4016e83f695eb2b729348bbabe7491f1e6e8e8297b607ecd4f5724f173fa")
addappid(1333370, 0, "0bfda0b1d5d9b05ae27494490d28a4418c746d09d1ebb1e4fd983e24c6d81985")
