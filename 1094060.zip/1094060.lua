-- Lua provided by RyzenAPI
-- Game: Escape First 2

-- MAIN APPLICATION
addappid(1094060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094061, 1, "facdeba6ac7d0aee09cbd93c3718a8a56f48ae82171c1b46b17bb261f423e766")

