-- Lua provided by SkyAPI 
-- Game: AppID 2172080
addappid(2172080)
addappid(2172081, 1, "d96168b96c85f7568069896aa4040f7a6bb0effd1f2fb64e3f4e2f6d695df7d0")
