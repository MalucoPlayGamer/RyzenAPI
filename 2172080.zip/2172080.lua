-- Lua provided by RyzenAPI
-- Game: 2172080

-- MAIN APPLICATION
addappid(2172080)
-- Game: addappid(2172080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172081, 1, "d96168b96c85f7568069896aa4040f7a6bb0effd1f2fb64e3f4e2f6d695df7d0")
