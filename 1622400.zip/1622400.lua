-- Lua provided by RyzenAPI
-- Game: Wyldernook

-- MAIN APPLICATION
addappid(1622400)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4811380)
