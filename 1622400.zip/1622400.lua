-- Lua provided by RyzenAPI
-- Game: Wyldernook

-- MAIN APPLICATION
addappid(1622400)

