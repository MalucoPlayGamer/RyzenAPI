-- Lua provided by RyzenAPI
-- Game: Worshippers of Cthulhu Demo

-- MAIN APPLICATION
addappid(2813170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2813171, 1, "4e563044ca6b119f7734f196a38bdf754511a7a5aeb475ace45ca4184821dfa8")
