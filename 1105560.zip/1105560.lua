-- Lua provided by RyzenAPI 
-- Game: Kra-Ken
addappid(1105560)
addappid(1105561, 1, "e25f5d1ae462d1837e5491e2a072324056bcfc6aed7a15f1b9a04828bea32959")
