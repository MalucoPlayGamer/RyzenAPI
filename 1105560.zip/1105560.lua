-- Lua provided by RyzenAPI
-- Game: Kra-Ken

-- MAIN APPLICATION
addappid(1105560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1105561, 1, "e25f5d1ae462d1837e5491e2a072324056bcfc6aed7a15f1b9a04828bea32959")

