-- Lua provided by SkyAPI 
-- Game: Rocket Squad: Infinity
addappid(3315230)
addappid(3315231, 1, "6844aec7149d9d1f3910405a9d6f6ad2eb78b1bba2cf892e26e7ea076d4042fc")
