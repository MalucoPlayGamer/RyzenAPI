-- Lua provided by RyzenAPI
-- Game: Rocket Squad: Infinity

-- MAIN APPLICATION
addappid(3315230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3315231, 1, "6844aec7149d9d1f3910405a9d6f6ad2eb78b1bba2cf892e26e7ea076d4042fc")

