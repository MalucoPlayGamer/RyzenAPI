-- Lua provided by RyzenAPI
-- Game: ZERO PARADES: For Dead Spies

-- MAIN APPLICATION
addappid(4719150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863680, 1, "b0deaab3529583327b89558f4eefca8cdaa31f2e94d8148eb1a7e4803b3af539")
addappid(2863681, 1, "6f8570b7626034b90d4244ec942a2e30b85f4a6c139c76622a364117e5e49be4") -- English (windows, 64-bit)
addappid(4719150, 1, "9ede90e3a696df35e824df54f8a882256941165d2b283859e3a422c7dccf75bb")

