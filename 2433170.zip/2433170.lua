-- Lua provided by RyzenAPI 
-- Game: Ciudad Alfombra
addappid(2433170)
addappid(2433171, 1, "2920f896fc235c99fb01bbe21247becec0934fac208d5bc3fc4326560bad933a")
