-- Lua provided by RyzenAPI
-- Game: Blast Zone! Tournament

-- MAIN APPLICATION
addappid(649190)
addappid(649191)

-- MAIN APP DEPOTS / PACKAGES
addappid(649192,0,"43db793b84e0a7a2c815821cc45b979a4a65b3b68fd972567921b8382400d973")
addappid(649193,0,"15408d1e7b7b8c91a470c5a558a124e7f298f9d1d38f93f713e64cab76c060aa")
