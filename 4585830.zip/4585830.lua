-- Lua provided by RyzenAPI
-- Game: Barbecue

-- MAIN APPLICATION
addappid(4585830)

-- MAIN APP DEPOTS / PACKAGES
addappid(4585831,0,"80c68f14bf852817ac0cfb5476799750ae77ee2e4256b5a2882d048ffa798689")

