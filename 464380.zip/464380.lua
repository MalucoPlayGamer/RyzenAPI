-- Lua provided by RyzenAPI
-- Game: Game: Best of Us

-- MAIN APPLICATION
addappid(464380)
-- Game: addappid(464380)

-- MAIN APP DEPOTS / PACKAGES
addappid(464381, 1, "67dc818fdcf352c459b056a237aad6456f3c4fbbc61af78542ae46aa4a353c01")
