-- Lua provided by SkyAPI 
-- Game: BOMBFEST
addappid(729640)
addappid(729641, 1, "be22d060abe34fc4c2a8c6e19a483c2e8bb5a1423982d837f5b26c581182f7ed")
