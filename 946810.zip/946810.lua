-- Lua provided by RyzenAPI
-- Game: addappid(946810)

-- MAIN APPLICATION
addappid(946810)

-- MAIN APP DEPOTS / PACKAGES
addappid(946811, 1, "e987760081b3ef75b1102c306b02816c5c1b573ee171b467e12efc609bb51a70")
