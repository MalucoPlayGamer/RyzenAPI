-- Lua provided by RyzenAPI
-- Game: AppID 1364590

-- MAIN APPLICATION
addappid(1364590)
-- Game: addappid(1364590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364591, 1, "39b705868ee194a9bf1dd29a828ac9892f77db5f680a10914566edba120a88b6")
