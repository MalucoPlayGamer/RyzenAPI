-- Lua provided by RyzenAPI
-- Game: Who Wants To Be A Millionaire? Special Editions

-- MAIN APPLICATION
addappid(206740)
addappid(206743)
addappid(206744)
addappid(206745)
addappid(206746)
addappid(206747)
addappid(206748)
addappid(206749)
addappid(206750)
addappid(206751)
addappid(206752)
addappid(206753)

-- MAIN APP DEPOTS / PACKAGES
addappid(206741, 1, "f4ea69f55f43e4af2dbb6eb77d17529c7cf3b15c8fecb6d77ca1a8bdc63a8daa")
addappid(206742, 1, "3abcf06c3b0112578ec75fcfe67aea78a1b7c4d66de95da2faf7f5ef2d836907")
