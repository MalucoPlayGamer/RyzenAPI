-- Lua provided by RyzenAPI
-- Game: Russian world cup battlegrounds

-- MAIN APPLICATION
addappid(897620)

-- MAIN APP DEPOTS / PACKAGES
addappid(897621, 1, "3428d89a96b490d8f4986f7ab4139675886bb2195d7222be682538a88f922af3")
