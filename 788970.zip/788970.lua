-- Lua provided by RyzenAPI
-- Game: AppID 788970

-- MAIN APPLICATION
addappid(788970)

-- MAIN APP DEPOTS / PACKAGES
addappid(788971, 1, "ea075da9f44a54ad14005143ded04e2c6da0026a1366ffa40a525949cbfc9a04")
