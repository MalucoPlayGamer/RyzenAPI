-- Lua provided by RyzenAPI
-- Game: AppID 1395830

-- MAIN APPLICATION
addappid(1395830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395831, 1, "6ca1cbffdc2d09b13a8a806315ca4bb6850845077ac7192a637a9b00ccabfb83")
