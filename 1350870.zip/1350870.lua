-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - MV Cover Art Characters Pack

-- MAIN APPLICATION
addappid(1350870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350870,0,"9488d93a927c678dad906744b21c0edb4ec6e54a397982511719ead946fd316b")

