-- Lua provided by RyzenAPI
-- Game: AppID 2378960

-- MAIN APPLICATION
addappid(2378960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378961, 1, "b2cf63dcd49b5b6916e0174ad2a8edbf26ca08dca77217eeaf0212b4a91e1d55")

