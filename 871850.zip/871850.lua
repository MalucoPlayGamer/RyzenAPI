-- Lua provided by RyzenAPI
-- Game: AppID 871850

-- MAIN APPLICATION
addappid(871850)
-- Game: addappid(871850)

-- MAIN APP DEPOTS / PACKAGES
addappid(871851, 1, "c1100c02a4ed343cc20d005721cbd1f7ff41cb9ad8597f9c38e2d4bd60f895f7")
