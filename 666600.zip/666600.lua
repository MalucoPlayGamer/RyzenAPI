-- Lua provided by RyzenAPI
-- Game: Zombie Town

-- MAIN APPLICATION
addappid(666600)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(666601, 1, "6b0e7772dbb64a86cd3d63e1a379b4848870f20fc9969c55e36f1294ee2e03e1")

