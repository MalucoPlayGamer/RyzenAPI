-- Lua provided by RyzenAPI
-- Game: Game: AppID 666600

-- MAIN APPLICATION
addappid(666600)
-- Game: addappid(666600)

-- MAIN APP DEPOTS / PACKAGES
addappid(666601, 1, "6b0e7772dbb64a86cd3d63e1a379b4848870f20fc9969c55e36f1294ee2e03e1")
