-- Lua provided by RyzenAPI
-- Game: Mossen Seikkailut

-- MAIN APPLICATION
addappid(1243260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243261, 1, "04db26cc879e01c727b2594ef17ff3ae67fdbf37ef1f4de7eff453eb4658fbb6")

