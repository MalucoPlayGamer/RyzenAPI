-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VIII Original Soundtrack

-- MAIN APPLICATION
addappid(3365700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365701, 1, "99f8544ea87302e3a1e6521d12669f8ca4659134ff480a1f7819d49daeb1fe38")

