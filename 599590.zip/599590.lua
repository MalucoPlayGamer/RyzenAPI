-- Lua provided by RyzenAPI
-- Game: Volleyball Fever

-- MAIN APPLICATION
addappid(599590)

-- MAIN APP DEPOTS / PACKAGES
addappid(599591, 1, "9729123edc24478d0bb8e257a230a55e97855a6beb2b60bd6893be3bcb562924")

