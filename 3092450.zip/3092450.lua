-- Lua provided by RyzenAPI
-- Game: inZOI: Creative Studio

-- MAIN APPLICATION
addappid(3092450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092451, 1, "40cc0f7748b0623c087162a85440efcc41e602b66f3542801c0911d21bca8e3b")

