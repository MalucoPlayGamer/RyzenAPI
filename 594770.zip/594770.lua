-- Lua provided by RyzenAPI
-- Game: AppID 594770

-- MAIN APPLICATION
addappid(594770)

-- MAIN APP DEPOTS / PACKAGES
addappid(594771, 1, "2976b506b59a8148818b962d590aaf330ff3507ea56faa7bd05983d012a52846")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1008810)
addappid(1124320)
addappid(1179930)
addappid(1208290)
addappid(1208291)
addappid(1208292)
