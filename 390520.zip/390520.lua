-- Lua provided by RyzenAPI
-- Game: PewDiePie: Legend of the Brofist

-- MAIN APPLICATION
addappid(390520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(390521, 1, "71f4c095788721696d0d1b0743eb410c4ce2817f5c5695546cbb5b4a79a39c1a")
addappid(390522, 1, "45a304be77c91502575d6f1b609deef81a914b67667067a4c4b324dc0d373b4d")
