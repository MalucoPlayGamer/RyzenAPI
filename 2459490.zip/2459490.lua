-- Lua provided by RyzenAPI
-- Game: This Grand Life 2

-- MAIN APPLICATION
addappid(2459490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2459491, 1, "faf54e9dca0c2db8a411e3c093b1996b91b3b52d534f40ceb705e1596765e3ab")

