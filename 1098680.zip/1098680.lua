-- Lua provided by RyzenAPI
-- Game: AppID 1098680

-- MAIN APPLICATION
addappid(1098680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098681, 1, "e2838ee1b4d649807672ffdd5e40ebe24a5f263b4a3eb90414f5dd904d9c6e9d")

