-- Lua provided by RyzenAPI
-- Game: Game: Digital Meow

-- MAIN APPLICATION
addappid(3015130)
-- Game: addappid(3015130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015131, 1, "6cb0f74eaefe7c343c10b63bbb56068405f0805ba8806882d57e9fd805c7b671")
