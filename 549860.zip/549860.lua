-- Lua provided by RyzenAPI
-- Game: Game: One Night Stand

-- MAIN APPLICATION
addappid(549860)
-- Game: addappid(549860)

-- MAIN APP DEPOTS / PACKAGES
addappid(549861, 1, "357daa8c9045394938efa8e8d8d055512e7b7c22e5c3fb47ab5563ac41bea877")
