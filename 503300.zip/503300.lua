-- Lua provided by SkyAPI 
-- Game: AppID 503300
addappid(503300)
addappid(503301, 1, "ef7d30c870be08164eb28fa249ff76eea100d2816b735840d6a256c0a63bda4c")
addappid(503302, 1, "53b51203f65836c94a53b20c214c6d14b42eb84145990f5cc0790e50f930fca7")
