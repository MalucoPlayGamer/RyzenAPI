-- Lua provided by SkyAPI 
-- Game: AppID 3341050
addappid(3341050)
addappid(3341051, 1, "672bb6b7894735055b7365337aa39d88bfa49ac99206d5fab00a30844ff0064d")
