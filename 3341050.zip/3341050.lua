-- Lua provided by RyzenAPI
-- Game: Game: AppID 3341050

-- MAIN APPLICATION
addappid(3341050)
-- Game: addappid(3341050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3341051, 1, "672bb6b7894735055b7365337aa39d88bfa49ac99206d5fab00a30844ff0064d")
