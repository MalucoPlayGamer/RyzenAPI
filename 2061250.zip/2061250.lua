-- Lua provided by RyzenAPI
-- Game: クレヨンしんちゃん「オラと博士の夏休み」～おわらない七日間の旅～

-- MAIN APPLICATION
addappid(2061250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061251, 1, "9ad04720ada19b496c5036cb51aa4a727363151e3bbc6a088dc225d8543561a0")

