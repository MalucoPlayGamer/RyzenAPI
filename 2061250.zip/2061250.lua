-- Lua provided by RyzenAPI 
-- Game: AppID 2061250
addappid(2061250)
addappid(2061251, 1, "9ad04720ada19b496c5036cb51aa4a727363151e3bbc6a088dc225d8543561a0")
