-- Lua provided by RyzenAPI
-- Game: Shin chan: Me and the Professor on Summer Vacation The Endless Seven-Day Journey

-- MAIN APPLICATION
addappid(2061250)
-- Game: addappid(2061250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061251, 1, "9ad04720ada19b496c5036cb51aa4a727363151e3bbc6a088dc225d8543561a0")
