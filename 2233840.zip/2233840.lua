-- Lua provided by RyzenAPI
-- Game: Lewd Delivery

-- MAIN APPLICATION
addappid(2233840)
addappid(2237600)
-- Game: addappid(2233840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233841, 1, "29608803363b47fc0b4f66bfc87eb9321fb2e513712168244b35276d4b191a96")
