-- Lua provided by RyzenAPI
-- Game: Toy Flying Car

-- MAIN APPLICATION
addappid(2291090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291091, 1, "46b4896d8e335e562b789a61acf805e93b4c927c510ff12db19db36a697ccdb5")
