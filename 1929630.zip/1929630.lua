-- Lua provided by RyzenAPI
-- Game: Game: Eragon's Tale

-- MAIN APPLICATION
addappid(1929630)
-- Game: addappid(1929630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929631, 1, "6afd64df48cd28a8b779c0bcca85b8075dc3fee203668efdedafb7cd07ef04e0")
