-- Lua provided by RyzenAPI 
-- Game: Jets'n'Guns 2
addappid(830820)
addappid(830821, 1, "f4c6ba87a23d47cddd094e16be14d6c4e395c79e9c6af7caf8408d3de165b3ad")
