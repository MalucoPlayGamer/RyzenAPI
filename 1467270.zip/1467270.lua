-- Lua provided by RyzenAPI
-- Game: Beyond Enemy Lines - Vietnam

-- MAIN APPLICATION
addappid(1467270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467271, 1, "f17926ea4da479d8f9237f821f97555fdb4a230ead5f2b37e1db2c5f761ca8d6")

