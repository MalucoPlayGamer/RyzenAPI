-- Lua provided by RyzenAPI 
-- Game: Ho-Ho-Maze!
addappid(3331260)
addappid(3331261, 1, "55dc50f85261e1c4e578fbb858d0da3d6bb3f2cf8be4c76dd17a8a486eb03bf7")
