-- Lua provided by RyzenAPI
-- Game: Ho-Ho-Maze!

-- MAIN APPLICATION
addappid(3331260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331261, 1, "55dc50f85261e1c4e578fbb858d0da3d6bb3f2cf8be4c76dd17a8a486eb03bf7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
