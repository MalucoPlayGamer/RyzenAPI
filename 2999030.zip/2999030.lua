-- Lua provided by RyzenAPI
-- Game: Exploding Kittens® 2

-- MAIN APPLICATION
addappid(2999030)
addappid(3140300)
addappid(3140310)
addappid(3140320)
addappid(3276090)
addappid(3377260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999031, 1, "8b8386310bdef28e1d892fac876e1fb231ab87901d9cc711eb0f5edcacacb836")

