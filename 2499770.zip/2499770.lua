-- Lua provided by RyzenAPI 
-- Game: Goblin Adventurer Hunting
addappid(2499770)
addappid(2499771, 1, "0856c6df68f6b99a501080901a393ccf4cac4e573ab7c84322359ed926b96e30")
addappid(2499772, 1, "44d86aff92097095f96c7f93c17f1c8a9988e1c0de7761367c51311d8dddb5ae")
addappid(2499773, 1, "e3721d974a7b1efb179cc0b5aebd787cb92f7e53003701055a9e446ba35a5e2c")
addappid(2499774, 1, "5caa7a3a9fd02e4b9651591dc7bf9e674c21dd9cdc69484b651916a50e42f6ac")
addappid(2640411)
addappid(2640412)
addappid(2640413)
addappid(2640414)
