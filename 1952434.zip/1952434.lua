-- Lua provided by RyzenAPI
-- Game: 1952434

-- MAIN APPLICATION
addappid(1952434)
-- Game: addappid(1952434)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952434,0,"eb4abebf632f295c5ccc8357ee369f631b4cf914f10da4b62554ae806bf91756")
