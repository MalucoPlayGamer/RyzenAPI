-- Lua provided by RyzenAPI
-- Game: The Pentest

-- MAIN APPLICATION
addappid(1638670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638671, 1, "c1d245e465ee4527833f41ccca4432d1ed4af418ff4bf0c2bffc3fbb9386e982")

