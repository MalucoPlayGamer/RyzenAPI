-- Lua provided by RyzenAPI
-- Game: AppID 569490

-- MAIN APPLICATION
addappid(569490)

-- MAIN APP DEPOTS / PACKAGES
addappid(569491, 1, "5905da8bf0d88b9fd8d7e8e6c2a9839fcaa810d80ed97a8b15bffc436c847278")
