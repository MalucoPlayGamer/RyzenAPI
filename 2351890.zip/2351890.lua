-- Lua provided by RyzenAPI
-- Game: addappid(2351890)

-- MAIN APPLICATION
addappid(2351890)
addappid(4157750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351891, 1, "02aa7526cabf6b7cfbbb386fac8a0876fe0d106f7f66d2212d2594fe423b4497")
addappid(2351892, 1, "fe17ab1b0c3d333dca664a1f5aa61a3b517c584d8bb946ba47557f2852c3e7b1")
