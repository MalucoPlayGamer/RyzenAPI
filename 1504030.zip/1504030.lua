-- Lua provided by RyzenAPI
-- Game: Game: Hover Ship

-- MAIN APPLICATION
addappid(1504030)
-- Game: addappid(1504030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504031, 1, "2e64115adca152a3408b7d51b0bf937fe58728197f7477ad1d0b9beeb0b30bd4")
