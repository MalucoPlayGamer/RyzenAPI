-- Lua provided by RyzenAPI
-- Game: Guns of Bullshit

-- MAIN APPLICATION
addappid(1241750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241751, 1, "6414e136287be7d497e21adacbe6f20ec867bce7b030f68c3b6127e4693ad320")

