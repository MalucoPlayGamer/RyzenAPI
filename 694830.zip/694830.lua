-- Lua provided by RyzenAPI
-- Game: addappid(694830)

-- MAIN APPLICATION
addappid(694830)

-- MAIN APP DEPOTS / PACKAGES
addappid(694831, 1, "dd1710faccefbd7b8a04462603e764639f596fb1a8b2a0fca81034f0ebc669d5")
