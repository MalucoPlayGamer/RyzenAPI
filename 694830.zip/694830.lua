-- Lua provided by RyzenAPI
-- Game: Give It Up! Plus / 永不言弃 PLUS

-- MAIN APPLICATION
addappid(694830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(694831, 1, "dd1710faccefbd7b8a04462603e764639f596fb1a8b2a0fca81034f0ebc669d5")

