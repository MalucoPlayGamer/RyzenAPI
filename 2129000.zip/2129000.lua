-- Lua provided by RyzenAPI
-- Game: 2129000

-- MAIN APPLICATION
addappid(2129000)
-- Game: addappid(2129000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129001, 1, "51a62fbe4d74561cd8091994cccf2226b9d7e26af189cd0b03dfce907f6ccdb1")
