-- Lua provided by RyzenAPI
-- Game: Game: AppID 691570

-- MAIN APPLICATION
addappid(691570)
-- Game: addappid(691570)

-- MAIN APP DEPOTS / PACKAGES
addappid(691571, 1, "26a0d8c3cba90e261d651b7944142d53025505fed839870b91f5b2fb38b08570")
