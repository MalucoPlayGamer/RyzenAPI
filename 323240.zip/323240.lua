-- Lua provided by RyzenAPI
-- Game: The World II: Hunting BOSS

-- MAIN APPLICATION
addappid(323240)

-- MAIN APP DEPOTS / PACKAGES
addappid(323241, 1, "2ddd66ba90f6a83d8afc84cd40c25f10dd104bd38c0050c2a5e4b8c59c933c92")
