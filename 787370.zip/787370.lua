-- Lua provided by RyzenAPI
-- Game: Fable of the Sword

-- MAIN APPLICATION
addappid(787370)

-- MAIN APP DEPOTS / PACKAGES
addappid(787371, 1, "d659a92eb5a7881fdd5f81367983560895a74651588129a907629d3cddec02c6")
addappid(787372, 1, "53302dbf06a72a093f3e571a9b8593bf31ab2d16a68a041cef7fbf3558d33e98")
addappid(787373, 1, "695dc34c6e056ba0378c6db72cf61b6e7a6a2c6c3cab6344f231aca2b3237ab7")
addappid(787374, 1, "0cc6fd57e43ce09ac59dbb11fdc64629f7895213c80ebb40d87b9dc7c5ee72c3")
