-- Lua provided by RyzenAPI
-- Game: 1785910

-- MAIN APPLICATION
addappid(1785910)
addappid(1904490)
-- Game: addappid(1785910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785911, 1, "3d6294ccb44280f00e0d21911cfc1d8623e7c90a02f3719513b693d9a63d5411")
