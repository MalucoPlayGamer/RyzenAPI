-- Lua provided by RyzenAPI
-- Game: Mobile Dungeon

-- MAIN APPLICATION
addappid(707710)
