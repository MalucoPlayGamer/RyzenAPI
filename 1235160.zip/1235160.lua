-- Lua provided by RyzenAPI 
-- Game: Boom Stick
addappid(1235160)
addappid(1235161, 1, "fdd7dcac93264aa2e34b8cd747f6c13cdfb02b4c39fa0cab3814c270f22776a5")
