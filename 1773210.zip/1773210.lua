-- Lua provided by RyzenAPI
-- Game: Game: HumanitZ Demo

-- MAIN APPLICATION
addappid(1773210)
-- Game: addappid(1773210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1773211, 1, "b136871f079c334c768288acfcd7cf03463fc39b4299e3400726675ad69bf1ce")
