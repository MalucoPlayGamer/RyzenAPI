-- Lua provided by SkyAPI 
-- Game: HumanitZ Demo
addappid(1773210)
addappid(1773211, 1, "b136871f079c334c768288acfcd7cf03463fc39b4299e3400726675ad69bf1ce")
