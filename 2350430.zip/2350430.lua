-- Lua provided by RyzenAPI
-- Game: Dirty Streamer Puzzle

-- MAIN APPLICATION
addappid(2350430)
-- Game: addappid(2350430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350431, 1, "ecc47666d943bbea06c17cad34b120f576db3c2b3d2ee2757999d1902a8be1a2")
