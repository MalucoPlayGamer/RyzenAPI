-- Lua provided by RyzenAPI
-- Game: 3468430

-- MAIN APPLICATION
addappid(3468430)
-- Game: addappid(3468430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3468431, 1, "213694d897534dffdeb6e5010c611e6e9c97c354c859f594c8e1ec86adb31b1b")
