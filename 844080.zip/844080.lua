-- Lua provided by RyzenAPI
-- Game: AppID 844080

-- MAIN APPLICATION
addappid(844080)

-- MAIN APP DEPOTS / PACKAGES
addappid(844081, 1, "788edc749fe816b2ff420eb3601312e8c5ae948f26618949723af8eb0cb4cddd")
