-- Lua provided by RyzenAPI
-- Game: Game: 女神氪金系统

-- MAIN APPLICATION
addappid(3332640)
-- Game: addappid(3332640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3332641, 1, "dc006eca05d8fe204ea017d8eb1aa782e7ba24c6493f2051557211458e82a016")
