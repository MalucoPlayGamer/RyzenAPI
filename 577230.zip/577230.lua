-- Lua provided by RyzenAPI
-- Game: Three Kingdoms The Last Warlord

-- MAIN APPLICATION
addappid(577230)

-- MAIN APP DEPOTS / PACKAGES
addappid(577231, 1, "9637d76aa413d336de9550b3932653ee37f71ac30d96721a9bcc5e14a87ec788")
addappid(577232, 1, "6bf9dba002c2cb8ed0fd82bc69393ca8464cffc170225416f7aee00fa0ad82a3")
addappid(577233, 1, "9bb32a976cd5c911f2cf02d5251dc28fbce00f9a991701c09532e03cd630637e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(692770)
addappid(1150750)
addappid(1520720)
addappid(1863450)
addappid(2022570)
addappid(2350150)
addappid(2350160)
addappid(2718740)
addappid(3171550)
addappid(3575830)
addappid(4330990)
addappid(4331000)
addappid(4539290)
addappid(4753560)
