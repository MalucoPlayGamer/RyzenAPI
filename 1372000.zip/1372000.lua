-- Lua provided by RyzenAPI
-- Game: Flowstone Saga

-- MAIN APPLICATION
addappid(1372000)
-- Game: addappid(1372000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372002,0,"c7be78b78dfa7242847d7c060637b5053783aca7758f5612fd50d15abfacbbb4")
addappid(1372003,0,"be37777dc1a77415fe974df0c810fc8b7dd116a7ae9478b52764c02b0d2324f4")
addappid(1372004,0,"a50aeea29a6bcfbe692fcbe89e6c00560fcd2cc64f017ebe7154aee1935e7e78")
