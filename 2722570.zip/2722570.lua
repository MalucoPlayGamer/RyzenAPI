-- Lua provided by SkyAPI 
-- Game: Christmas Girls
addappid(2722570)
addappid(2722571, 1, "f288f71ba2ca958194116dad17e3208cc797525bea94c3ea5136049da911963a")
addappid(2729980)
