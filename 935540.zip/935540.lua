-- Lua provided by SkyAPI 
-- Game: M-Plan
addappid(935540)
addappid(935541, 1, "60f749f6129f30a3e65f6b9b151f8e60c1097f8cb5b50693a3210c4af9665c65")
