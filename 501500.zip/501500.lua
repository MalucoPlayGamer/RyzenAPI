-- Lua provided by RyzenAPI
-- Game: addappid(501500)

-- MAIN APPLICATION
addappid(501500)

-- MAIN APP DEPOTS / PACKAGES
addappid(501501, 1, "7868b496b4fbc201d16e437ecbb37dade94111a3ce12b08c8a9e8f5fd06d9b4f")
