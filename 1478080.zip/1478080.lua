-- Lua provided by RyzenAPI 
-- Game: Omi Domini
addappid(1478080)
addappid(1478081, 1, "b09eacb131f5cbd4729316ded93d4b22ca8c355f4930d26cff2ff60967680bf3")
