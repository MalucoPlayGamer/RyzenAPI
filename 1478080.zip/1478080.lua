-- Lua provided by RyzenAPI
-- Game: 1478080

-- MAIN APPLICATION
addappid(1478080)
-- Game: addappid(1478080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478081, 1, "b09eacb131f5cbd4729316ded93d4b22ca8c355f4930d26cff2ff60967680bf3")
