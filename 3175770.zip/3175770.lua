-- Lua provided by RyzenAPI
-- Game: Game: AppID 3175770

-- MAIN APPLICATION
addappid(3175770)
-- Game: addappid(3175770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3175771, 1, "d1b5c1fb80b93ce9881712d213b68daa38742955dd6effb9b1325c6c7321e0a2")
