-- Lua provided by RyzenAPI
-- Game: 1178730

-- MAIN APPLICATION
addappid(1178730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178730,0,"2058e7adc34e3aceae1b7dea4c8e0a44dba3a4f2e6a00bb1ac210c0c10ce43a9")
