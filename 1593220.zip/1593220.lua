-- Lua provided by SkyAPI 
-- Game: Jessie 'Boom' James - a jigsaw chess tale
addappid(1593220)
addappid(1593221, 1, "16a02c3bb3e1090ae9c49f1655b7a96023c1d7b016d03093eaa7d7ee964cf6a7")
