-- Lua provided by RyzenAPI 
-- Game: AppID 1069050
addappid(1069050)
addappid(1069051, 1, "4b7f8aa3b37234cbacccae18608d5056f32fcdec048481deaa07a9a2c7b88679")
