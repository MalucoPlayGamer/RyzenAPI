-- Lua provided by RyzenAPI 
-- Game: UnBorn
addappid(886420)
addappid(886421, 1, "ca202e1c44f62533e985ba05d9f3695c48c1cb4c15d371aba3d178794dbbf315")
