-- Lua provided by RyzenAPI
-- Game: UnBorn

-- MAIN APPLICATION
addappid(886420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(886421, 1, "ca202e1c44f62533e985ba05d9f3695c48c1cb4c15d371aba3d178794dbbf315")

