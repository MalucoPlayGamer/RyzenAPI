-- Lua provided by SkyAPI 
-- Game: Artifact Run
addappid(3206600)
addappid(3206601, 1, "4935c4f15d26e27bf9c2e81f9e1a0072271ef114c4f68bd786c37d371cc460ee")
