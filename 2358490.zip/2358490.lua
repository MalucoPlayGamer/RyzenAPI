-- Lua provided by SkyAPI 
-- Game: Goblin Down
addappid(2358490)
addappid(2358491, 1, "a0218211199f0a473da42f64c70d294ebbd4ec310d7a9b77cf3c5c4204ddf34e")
