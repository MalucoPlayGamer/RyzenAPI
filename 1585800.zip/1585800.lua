-- Lua provided by RyzenAPI
-- Game: 1585800

-- MAIN APPLICATION
addappid(1585800)
-- Game: addappid(1585800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585801, 1, "3fa902bbfad1c24c1f09510ec803ab163287baf02ecf856866185dace304a7bc")
