-- Lua provided by RyzenAPI
-- Game: Aloft

-- MAIN APPLICATION
addappid(3352580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660080, 1, "0b289fef8a91dcf33a515bf73a0c1477918362c3bd9d57be186f6ccaa5c51c84") -- Aloft
addappid(1660082, 1, "b31ceba7551b938f6ee5ac53d92c6bba9c6620164b2dedf36cf80fae8825b17e") -- Depot 1660082
addappid(3352580, 1, "dad71f0783613579b08d5787dc32c61d420acb327988eb00bb6049ff1df2b630") -- Aloft - Supporter Pack - Depot 3352580
