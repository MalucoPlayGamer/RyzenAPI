-- Lua provided by RyzenAPI
-- Game: Absolute Tactics: Daughters of Mercy - Soundtrack

-- MAIN APPLICATION
addappid(2139360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139361, 1, "f6a33041bd375e0a46cdb5be07fab84c1f89291f11d4a57e7179aae467eb9e79")
