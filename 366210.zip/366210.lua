-- Lua provided by RyzenAPI
-- Game: Sleep Attack

-- MAIN APPLICATION
addappid(366210)

-- MAIN APP DEPOTS / PACKAGES
addappid(366211, 1, "6ec1a8d8f512d6f17234d9b439e329a36a3f6c1a2443b282c29807e08b243cdd")
addappid(366212, 1, "66280e40adceab9b61803e87f107f817baf886ac5702f05a749e0b87e10b8fb1")
addappid(366213, 1, "51227769a38efe9ec1c9eceece2bd6aca558a83af4a2b08d7038dedc928158f7")

