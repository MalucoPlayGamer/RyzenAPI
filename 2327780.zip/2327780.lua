-- Lua provided by RyzenAPI
-- Game: HAELE 3D - Feet Poses Pro - Drawing References

-- MAIN APPLICATION
addappid(2327780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327781, 1, "841b6519237ac1591a61af75110c776e3ee82c5f9cc38142e023f00308700272")
