-- Lua provided by RyzenAPI
-- Game: Buckler 2

-- MAIN APPLICATION
addappid(1039910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1039911, 1, "3f000f00c0ec66aa29749a5bc087a41a479a57820f147a4d058e70357853708b")

