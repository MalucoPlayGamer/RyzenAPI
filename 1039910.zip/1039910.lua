-- Lua provided by RyzenAPI
-- Game: Game: Buckler 2

-- MAIN APPLICATION
addappid(1039910)
-- Game: addappid(1039910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039911, 1, "3f000f00c0ec66aa29749a5bc087a41a479a57820f147a4d058e70357853708b")
