-- Lua provided by RyzenAPI
-- Game: addappid(1895350)

-- MAIN APPLICATION
addappid(1895350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895352,0,"6d7480b99a01adb8dda52877c1e1e6cdeb02298f7e0c57cfc892bfe8944f71c9")
