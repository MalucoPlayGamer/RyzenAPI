-- Lua provided by RyzenAPI
-- Game: Lichtreich: Willa

-- MAIN APPLICATION
addappid(2256760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256761, 1, "92bc5cdc3f11f9bebdbb8baa40e2f8eae59fa81cd8758d20280e1b0a873d9ba9")
