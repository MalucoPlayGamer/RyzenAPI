-- Lua provided by SkyAPI 
-- Game: Avernum 3: Ruined World
addappid(691830)
addappid(691831, 1, "fadcc63cabde38413b9eb3f1203b5c8479094ee63288572cbccde232128025ad")
addappid(691832, 1, "8debc771d14943b900bde629e86919c8899587968b21980bd8af4c111641ee4a")
addappid(776120, 0, "539cbcef12f58e23f10b432efd487f8b0d556fbe2c40b4408d4ec58922750469")
