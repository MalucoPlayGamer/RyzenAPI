-- Lua provided by RyzenAPI
-- Game: Barbarous: Tavern Of Emyr

-- MAIN APPLICATION
addappid(1202170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202171, 1, "d43c74c16478eb637620504d3b51c092793ceb06b983a05185af786db9051bf2")

