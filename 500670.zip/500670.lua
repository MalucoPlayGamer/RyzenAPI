-- Lua provided by RyzenAPI
-- Game: AppID 500670

-- MAIN APPLICATION
addappid(500670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(500671, 1, "ef138ba9830d8db90c66018e998a9d71e2d83b74ce657a4197e2f53906b4ab97")
addappid(500672, 1, "43000ac1c7f882bae9001f05f4254dfe7d41ae1aefc3b3703b43d1e862b29c66")

