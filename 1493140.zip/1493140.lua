-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Elemental Dungeon Tileset - Celestial Flora Ice Time

-- MAIN APPLICATION
addappid(1493140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493140,0,"42a3ec63185132f8d161952632237861b4a6ee0291ff7b1b26201608a9db004b")

