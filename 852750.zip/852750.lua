-- Lua provided by RyzenAPI
-- Game: Paper Shakespeare: Stick Merchant of Venice

-- MAIN APPLICATION
addappid(852750)
addappid(1510940)
addappid(1510941)
addappid(1510942)

-- MAIN APP DEPOTS / PACKAGES
addappid(852751, 1, "5889734a19def677f4e4ac407ddc65c50995aa37b89f6d3e38a65a23a6560474")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
