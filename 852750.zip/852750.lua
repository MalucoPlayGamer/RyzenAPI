-- Lua provided by RyzenAPI
-- Game: 852750

-- MAIN APPLICATION
addappid(852750)
addappid(1510940)
addappid(1510941)
addappid(1510942)
-- Game: addappid(852750)

-- MAIN APP DEPOTS / PACKAGES
addappid(852751, 1, "5889734a19def677f4e4ac407ddc65c50995aa37b89f6d3e38a65a23a6560474")
