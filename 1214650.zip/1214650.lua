-- Lua provided by RyzenAPI
-- Game: SOUTH PARK: SNOW DAY!

-- MAIN APPLICATION
addappid(1214650)
addappid(2534280)
addappid(2717700)
addappid(2777690)
addappid(2777700)
addappid(2856250)
addappid(2856260)
addappid(2895790)
addappid(2904870)
addappid(3000090)
addappid(3013230)
addappid(3053410)
addappid(3126390)
addappid(3126400)
addappid(3223240)
addappid(3312150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1214651,0,"ab40da96e959d0113c4a52d5736cce431bb07459a9a22b60d227598aa1420aa3")
addappid(2534280,0,"499001d339eb0c50bf4c3608fc07a306521cdd526a41a06a3cd53578e5cbcd0b")
addappid(2777700,0,"f43acf1097fae487007d0fdc5825a2c8fd61b9cb8bd6c407181a3a09a09913af")

