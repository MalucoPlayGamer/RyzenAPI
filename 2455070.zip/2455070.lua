-- Lua provided by RyzenAPI
-- Game: Long Way

-- MAIN APPLICATION
addappid(2455070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2455071, 1, "a4435b8e3e45ffb4d1b481e8d0954583ae4c1894b0d168fac7d13d0a9a95143d")

