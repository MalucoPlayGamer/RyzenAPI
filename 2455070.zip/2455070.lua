-- Lua provided by RyzenAPI 
-- Game: Long Way
addappid(2455070)
addappid(2455071, 1, "a4435b8e3e45ffb4d1b481e8d0954583ae4c1894b0d168fac7d13d0a9a95143d")
