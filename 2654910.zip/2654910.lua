-- Lua provided by RyzenAPI
-- Game: I'll Do It Tomorrow

-- MAIN APPLICATION
addappid(2654910)
-- Game: addappid(2654910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654911, 1, "fe1a94791a9db9bb7b428582e60076b856420416e2a7612d20e5d8812581e0ec")
