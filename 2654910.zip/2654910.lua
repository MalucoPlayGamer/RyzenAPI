-- Lua provided by SkyAPI 
-- Game: I'll Do It Tomorrow
addappid(2654910)
addappid(2654911, 1, "fe1a94791a9db9bb7b428582e60076b856420416e2a7612d20e5d8812581e0ec")
