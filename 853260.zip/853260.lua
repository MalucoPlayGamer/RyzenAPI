-- Lua provided by RyzenAPI
-- Game: Game: Ants! Mission of the salvation

-- MAIN APPLICATION
addappid(853260)
-- Game: addappid(853260)

-- MAIN APP DEPOTS / PACKAGES
addappid(853261, 1, "6a2c898a83243a1c1dcc170dbd1dcc3b35a3bbc005c6f8fefaa57e2fb1333f46")
