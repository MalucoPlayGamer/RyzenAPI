-- Lua provided by RyzenAPI
-- Game: Ants! Mission of the salvation

-- MAIN APPLICATION
addappid(853260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(853261, 1, "6a2c898a83243a1c1dcc170dbd1dcc3b35a3bbc005c6f8fefaa57e2fb1333f46")

