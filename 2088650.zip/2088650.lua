-- Lua provided by RyzenAPI
-- Game: Mist Slayer

-- MAIN APPLICATION
addappid(2088650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088651, 1, "844feca898f9d9185cad90f3f30f8ecd7c4c4b4a90fe2b424c27cd91f577b877")
