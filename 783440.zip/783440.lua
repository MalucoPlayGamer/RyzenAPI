-- Lua provided by RyzenAPI
-- Game: AppID 783440

-- MAIN APPLICATION
addappid(783440)
-- Game: addappid(783440)

-- MAIN APP DEPOTS / PACKAGES
addappid(783441, 1, "6b585714858c9dca9f0167958be5b77eeeeb312e6a37ae61cfac5118e290f2e2")
