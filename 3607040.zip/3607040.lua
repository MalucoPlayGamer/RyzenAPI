-- Lua provided by RyzenAPI
-- Game: Waifu Discovered 3: Cyberpunk Fantasy

-- MAIN APPLICATION
addappid(4057250) -- Waifu Discovered 3 - Exposed DLC

-- MAIN APP DEPOTS / PACKAGES
addappid(3607040, 1, "0087dd998e06f06c97cbed041fadbac25bbae826439224070aa96a0c090e979d") -- Waifu Discovered 3: Cyberpunk Fantasy
addappid(3607041, 1, "b855eedbf86210d7ed29695e3ccad11c5491110b5c75291e3b51288b3e83abf1") -- Depot 3607041

