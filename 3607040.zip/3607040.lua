-- 3607040's Lua and Manifest Created by Hubcap Manifest
-- Waifu Discovered 3: Cyberpunk Fantasy
-- Created: August 13, 2026 at 11:13:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3607040, 1, "0087dd998e06f06c97cbed041fadbac25bbae826439224070aa96a0c090e979d") -- Waifu Discovered 3: Cyberpunk Fantasy
-- MAIN APP DEPOTS
addappid(3607041, 1, "b855eedbf86210d7ed29695e3ccad11c5491110b5c75291e3b51288b3e83abf1") -- Depot 3607041
setManifestid(3607041, "2553652551414657230", 666750191)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4057250) -- Waifu Discovered 3 - Exposed DLC