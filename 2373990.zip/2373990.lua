-- Lua provided by RyzenAPI
-- Game: Solo Leveling: ARISE OVERDRIVE

-- MAIN APPLICATION
addappid(2373990)
addappid(3638570)
addappid(4240370)
addappid(4710940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2373991, 1, "5a97586d39bdb2a503376a75e3cae7d1f7e2de1bcb9ced523a73b21ca79de413")

