-- Lua provided by RyzenAPI
-- Game: addappid(2373990)

-- MAIN APPLICATION
addappid(2373990)
addappid(3638570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2373991, 1, "5a97586d39bdb2a503376a75e3cae7d1f7e2de1bcb9ced523a73b21ca79de413")
