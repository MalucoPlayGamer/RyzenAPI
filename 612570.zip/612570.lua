-- Lua provided by RyzenAPI
-- Game: Fort Triumph

-- MAIN APPLICATION
addappid(612570)

-- MAIN APP DEPOTS / PACKAGES
addappid(612572,0,"8ecc90aaa89c8bcd548f01752c0886c0dd59fab7f056d423e5b8c975855c6ad0")
addappid(612573,0,"918f9650741a0924ff48108921ed4104ded1d6df58882ded26519d4f214be8d8")
addappid(612574,0,"8e4719da8eb9ebc3b900e1188247210d6987345da447ed8dfbf5ff58360d510d")
addappid(612575,0,"498a6d3f7e2bce01c95e4e9283b0596de48e4cdea3da00d6cf6b0513cedad0b4")

