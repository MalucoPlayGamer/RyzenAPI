-- Lua provided by RyzenAPI
-- Game: GT Legends

-- MAIN APPLICATION
addappid(44690)

-- MAIN APP DEPOTS / PACKAGES
addappid(44691, 1, "1ecc9922a5a1b2a20fbda63dc875f0f69ddc0a826a269426dc6f3b460af9dd70")

