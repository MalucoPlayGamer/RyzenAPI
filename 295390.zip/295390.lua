-- Lua provided by RyzenAPI
-- Game: Football Manager 2015 Resource Archiver

-- MAIN APPLICATION
addappid(295390)

-- MAIN APP DEPOTS / PACKAGES
addappid(295391, 1, "00b849b2d1f28c4b8aa9ccbe828aa0372b7687bab49484d587b732d74ed30ce0")

