-- Lua provided by SkyAPI 
-- Game: AppID 295390
addappid(295390)
addappid(295391, 1, "00b849b2d1f28c4b8aa9ccbe828aa0372b7687bab49484d587b732d74ed30ce0")
