-- Lua provided by RyzenAPI
-- Game: Valfaris - Digital OST

-- MAIN APPLICATION
addappid(1166720)
-- Game: addappid(1166720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166720,0,"b26ef20df28196470848ee80097c0613601f4e64edd827c15eb5470df2f9879e")
