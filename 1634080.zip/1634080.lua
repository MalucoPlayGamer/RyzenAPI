-- Lua provided by RyzenAPI
-- Game: Game: Nocturnal

-- MAIN APPLICATION
addappid(1634080)
-- Game: addappid(1634080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634081, 1, "8405535fc21af6105c678a42b5ced6ab924cfa76e6b2f6347c52ffcef68b38a3")
