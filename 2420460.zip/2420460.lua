-- Lua provided by RyzenAPI
-- Game: 2420460

-- MAIN APPLICATION
addappid(2420460)
-- Game: addappid(2420460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420461, 1, "ad0e1bd33a4a927475147f2438b152337807810d2a3ed0c8f1586bd80cbfd310")
