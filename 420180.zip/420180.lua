-- Lua provided by RyzenAPI
-- Game: 420180

-- MAIN APPLICATION
addappid(420180)
-- Game: addappid(420180)

-- MAIN APP DEPOTS / PACKAGES
addappid(420181, 1, "1ff3a41aa92b4ef84418712aa7feb8004ca9170cb7b4be40647c5583fd3591be")
