-- Lua provided by RyzenAPI
-- Game: addappid(2791800)

-- MAIN APPLICATION
addappid(2791800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791802,0,"b17fb567dfd40e39a400f6524e46a21fc1558a093d0f5ffc9d0dbc30c15e47c5")
