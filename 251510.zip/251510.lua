-- Lua provided by RyzenAPI 
-- Game: AppID 251510
addappid(251510)
addappid(251511, 1, "f761327e667ce587e2c97551c72a7f389f3ab59fba798a541a7c03a97ea37462")
