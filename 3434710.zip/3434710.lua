-- Lua provided by RyzenAPI
-- Game: Black Pieces Move First

-- MAIN APPLICATION
addappid(3434710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3434711,0,"69b461ce4b101485f7b0a32f2553f15bb16bb35beae30e182388a0b7e044f531")

