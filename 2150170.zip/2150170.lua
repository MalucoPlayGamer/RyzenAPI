-- Lua provided by RyzenAPI
-- Game: Decent Checkers

-- MAIN APPLICATION
addappid(2150170)
-- Game: addappid(2150170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150171, 1, "8c4e126eaddf89439aa222ff3192250bd8d723c9cebcff05723406dd7ea915ca")
