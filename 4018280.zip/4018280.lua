-- 4018280's Lua and Manifest Created by Hubcap Manifest
-- Star Dice
-- Created: July 30, 2026 at 14:13:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4018280) -- Star Dice
-- MAIN APP DEPOTS
addappid(4018281, 1, "ec438d0aa1a2dd7da266d803308649369a44894adb464501536252b87788825b") -- Depot 4018281
setManifestid(4018281, "7204771017741084664", 499979794)
addappid(4018282, 1, "7efdc8fef6cde9e0a80095809aff8d8090c13dc38e0705d61cb08bd45871fd04") -- Depot 4018282
setManifestid(4018282, "2542906719525020338", 520461926)