-- Lua provided by RyzenAPI
-- Game: Game: Title_Pending Demo

-- MAIN APPLICATION
addappid(1293680)
-- Game: addappid(1293680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293681, 1, "802881875fa595cc860e4bc082936574b259560bb43219616c680169e3b55c36")
