-- Lua provided by RyzenAPI
-- Game: 1080330

-- MAIN APPLICATION
addappid(1080330)
addappid(1080331)
addappid(1080333)
addappid(1080334)
addappid(1080335)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080332,0,"aa7445a8dfe1d6fd0d0f3fc87acd15e3b06ec29a1b2a8ce8df34430dce540880")
addappid(1083020,0,"983c92a0459c079bc3b873ae531e1b8fd6d125d09da7fc93cf2155ff0e8bcb8d")
