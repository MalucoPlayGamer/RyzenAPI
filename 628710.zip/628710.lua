-- Lua provided by RyzenAPI
-- Game: Hell Warders

-- MAIN APPLICATION
addappid(628710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(628711, 1, "2749104abc3ba598ca476645e6ad877eb0e91aa3b138e966f13c22006d2eaa06")

