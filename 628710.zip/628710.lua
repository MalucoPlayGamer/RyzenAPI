-- Lua provided by SkyAPI 
-- Game: Hell Warders
addappid(628710)
addappid(628711, 1, "2749104abc3ba598ca476645e6ad877eb0e91aa3b138e966f13c22006d2eaa06")
