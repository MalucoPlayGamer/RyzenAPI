-- Lua provided by RyzenAPI
-- Game: Hentai Class

-- MAIN APPLICATION
addappid(2942190)
addappid(3446600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942191, 1, "2f8009853356a99f873daf3d47071326c0301e561184bb4e7a124f902f3b4c2d")

