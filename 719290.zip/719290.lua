-- Lua provided by RyzenAPI
-- Game: Game: Prophecy I - The Viking Child

-- MAIN APPLICATION
addappid(719290)
-- Game: addappid(719290)

-- MAIN APP DEPOTS / PACKAGES
addappid(719291, 1, "90024d9c64f37e015e770f6e41ef15a8ba4cb252a3735f7cebfa26271999b28b")
addappid(719292, 1, "5f32c97a913b8cfe968d87e379f5cf175c4689c58d155669d4680f78edc95cf6")
addappid(719293, 1, "e339f80fee000318545c2575fd464f8d5d725d7f1270b94d3d584e99cf7f2724")
addappid(719294, 1, "7e3260c906f7a4b9dfa363a5ad425866ecd1d4e47fddc566fa68b1eeb8ff7e5c")
addappid(719295, 1, "af3c1ef104ad98abe8892176d7a0887b9195971441cef44adddc226797073673")
