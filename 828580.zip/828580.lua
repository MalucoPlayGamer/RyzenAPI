-- Lua provided by RyzenAPI
-- Game: Game: AppID 828580

-- MAIN APPLICATION
addappid(828580)
-- Game: addappid(828580)

-- MAIN APP DEPOTS / PACKAGES
addappid(828581, 1, "79ffee89aedcf1f933c24203643cd1819bd310b6d75fc6857a0ef3e7166454d8")
addappid(947730, 0, "a388f08f2fa56fdc6e54022b734ab0e19cbb5d0af9064e4994cfcea6761d7f55")
