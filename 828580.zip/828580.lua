-- Lua provided by RyzenAPI
-- Game: NEKO-NIN exHeart 2

-- MAIN APPLICATION
addappid(828580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(828581, 1, "79ffee89aedcf1f933c24203643cd1819bd310b6d75fc6857a0ef3e7166454d8")
addappid(947730, 0, "a388f08f2fa56fdc6e54022b734ab0e19cbb5d0af9064e4994cfcea6761d7f55")
