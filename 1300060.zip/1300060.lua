-- Lua provided by RyzenAPI
-- Game: SMIB: Mission Cure

-- MAIN APPLICATION
addappid(1300060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300061, 1, "dcaba215f7f434c0691080100985624dc101b2a03a35f656da31d5925d25d913")

