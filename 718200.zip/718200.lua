-- Lua provided by RyzenAPI
-- Game: Game: AppID 718200

-- MAIN APPLICATION
addappid(718200)
-- Game: addappid(718200)

-- MAIN APP DEPOTS / PACKAGES
addappid(718201, 1, "386d3505eba3e68469322470fd2469f0e772f1d416173c7bc027f7f621d7d594")
