-- Lua provided by RyzenAPI
-- Game: Forever Home

-- MAIN APPLICATION
addappid(718200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(718201, 1, "386d3505eba3e68469322470fd2469f0e772f1d416173c7bc027f7f621d7d594")
