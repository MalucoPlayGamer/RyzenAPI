-- Lua provided by RyzenAPI
-- Game: Game: VoiceActress

-- MAIN APPLICATION
addappid(753360)
-- Game: addappid(753360)

-- MAIN APP DEPOTS / PACKAGES
addappid(753361, 1, "c03297382e4f158625aaf1e32a83b3f642b5cf43cc398cb690bc63a9c0e269a2")
