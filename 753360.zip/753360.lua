-- Lua provided by SkyAPI 
-- Game: VoiceActress
addappid(753360)
addappid(753361, 1, "c03297382e4f158625aaf1e32a83b3f642b5cf43cc398cb690bc63a9c0e269a2")
