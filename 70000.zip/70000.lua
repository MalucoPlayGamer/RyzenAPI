-- Lua provided by RyzenAPI 
-- Game: Dino D-Day
addappid(70000)
addappid(70001, 1, "e3b757daf5ba4b805c630ba5e40b33365bc0f744b887d76096a180fca0d5ae43")
addappid(70002, 1, "88c479c8c4d6b0010f813f72e64139e79ed4ae9820cdd51cb5f41873e5804009")
addappid(344290, 0, "15c191b6f25d1eeb6878f560f0c65a47ec69f9a3e2e1502981b8ae252cae38c8")
