-- Lua provided by RyzenAPI
-- Game: Oddinary Highway Demo

-- MAIN APPLICATION
addappid(1326460)
-- Game: addappid(1326460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326461, 1, "174fe2f8d9eda4db5602852c709bb604e594416e32972cf9809a618c4446550d")
