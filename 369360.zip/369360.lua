-- Lua provided by SkyAPI 
-- Game: AppID 369360
addappid(369360)
addappid(369361, 1, "4963bdb544bf3ac7169959d5f648987d4ee50fe54e2b37a9dc19a3917f688e34")
