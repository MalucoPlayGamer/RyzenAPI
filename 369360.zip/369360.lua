-- Lua provided by RyzenAPI
-- Game: 369360

-- MAIN APPLICATION
addappid(369360)
-- Game: addappid(369360)

-- MAIN APP DEPOTS / PACKAGES
addappid(369361, 1, "4963bdb544bf3ac7169959d5f648987d4ee50fe54e2b37a9dc19a3917f688e34")
