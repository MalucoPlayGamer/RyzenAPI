-- Lua provided by RyzenAPI
-- Game: Car Washer: Summer of the Ninja

-- MAIN APPLICATION
addappid(369360)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(369361, 1, "4963bdb544bf3ac7169959d5f648987d4ee50fe54e2b37a9dc19a3917f688e34")

