-- Lua provided by RyzenAPI
-- Game: addappid(892020)

-- MAIN APPLICATION
addappid(892020)

-- MAIN APP DEPOTS / PACKAGES
addappid(892021, 1, "daea57c414a5c819e711167d70b830d17eb0374b39f52970eff81db3c1b07461")
