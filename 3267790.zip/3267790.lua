-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3267790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267790,0,"ea30220dfd9741cd5afd06b7f571d80766051501d60d065e58143563a8057f4e")
