-- Lua provided by SkyAPI 
-- Game: MosGhost
addappid(3265370)
addappid(3265371, 1, "8b5615ef8d5cc0dc8ba2acaf76cdc93fed19d530816f541e7493412f8cb62b81")
