-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: Back to the Moon

-- MAIN APPLICATION
addappid(832080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(832081, 1, "391e3376d8e707f1938474d8ca9e2ada4b1a007101117c5cdb708183da44903c")
addappid(832082, 1, "ff81399c40d0e79500fe932bfe9b43aacbc84779e7cd5fe40d9154966c6307be")

