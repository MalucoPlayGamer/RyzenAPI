-- Lua provided by RyzenAPI 
-- Game: Poop Killer - Flush or Die
addappid(3553110)
addappid(3553111, 1, "c17d6c68a344c7e944957b2a50d26313086348e2c7ffcd087628e6eba056fbf8")
