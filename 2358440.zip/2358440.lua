-- Lua provided by RyzenAPI
-- Game: 2358440

-- MAIN APPLICATION
addappid(2358440)
-- Game: addappid(2358440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358441, 1, "243c35f511fbc93c71568f78dbe798714a49d7e911dfd37cf1616da2edb4237a")
