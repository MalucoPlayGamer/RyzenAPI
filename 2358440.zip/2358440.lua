-- Lua provided by RyzenAPI
-- Game: Monster Museum

-- MAIN APPLICATION
addappid(2358440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358441, 1, "243c35f511fbc93c71568f78dbe798714a49d7e911dfd37cf1616da2edb4237a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2390340)
addappid(2390341)
addappid(2397970)
addappid(2399510)
addappid(2399511)
addappid(2405040)
addappid(2405041)
addappid(2405042)
addappid(2413760)
addappid(2420650)
addappid(2428900)
addappid(2428901)
addappid(2435070)
addappid(2446240)
addappid(2446241)
addappid(2455470)
addappid(2463390)
