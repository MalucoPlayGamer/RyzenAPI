-- Lua provided by RyzenAPI 
-- Game: Monster Museum
addappid(2358440)
addappid(2358441, 1, "243c35f511fbc93c71568f78dbe798714a49d7e911dfd37cf1616da2edb4237a")
