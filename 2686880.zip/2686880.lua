-- Lua provided by RyzenAPI
-- Game: Game: Mob Factory Soundtrack

-- MAIN APPLICATION
addappid(2686880)
-- Game: addappid(2686880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686881, 1, "a3bd3c253b669caffcfffc3302dd885f83d4f8fa5fd41a31a162957ededae4bb")
