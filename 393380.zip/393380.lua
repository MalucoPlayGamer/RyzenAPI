-- Lua provided by RyzenAPI
-- Game: AppID 393380

-- MAIN APPLICATION
addappid(393380)
addappid(421270)
addappid(421271)
addappid(421272)
addappid(421273)
addappid(421274)
addappid(421275)
addappid(422950)
addappid(422960)
addappid(422961)
addappid(2222340)
addappid(2222341)
addappid(2222342)
addappid(2417350)
addappid(2417351)
addappid(2521990)
addappid(2522000)
addappid(2584870)
addappid(2598380)
addappid(2820320)
addappid(2826950)
addappid(2974490)
addappid(3165850)
addappid(3165860)
addappid(3486070)
addappid(3800510)
addappid(3925370)
addappid(3934740)
addappid(4012030)
addappid(4044570)
addappid(4062350)
addappid(4326750)

-- MAIN APP DEPOTS / PACKAGES
addappid(393381, 1, "d11ff0e6b7d56d9c48173256141f75daf1a14f85f6aac9e09d45d05ef7ef935d")
addappid(1123920, 0, "6e595b318ca37cc13710648c00e22386d7c5d385fadef84067f0e22b81b1d468")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4686020)
