-- Lua provided by RyzenAPI
-- Game: DUSK - Official Soundtrack

-- MAIN APPLICATION
addappid(994820)

-- MAIN APP DEPOTS / PACKAGES
addappid(994822,0,"550f98fad566089afa9f36979a9315f0e55e730c8c061442a74084b78684f94c")
addappid(994823,0,"ca6e0ba792a6fc03396472a3ddddabce5d06cd6af065af49500b08a5c1e19f54")
addtoken(994820,16417244447673309120)

