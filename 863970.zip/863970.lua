-- Lua provided by RyzenAPI
-- Game: Survive the Rift

-- MAIN APPLICATION
addappid(863970)

-- MAIN APP DEPOTS / PACKAGES
addappid(863971,0,"35779008cb24072054b6f4c4ef6109df1190f823337e1b5db21c60b7f1d2348d")

