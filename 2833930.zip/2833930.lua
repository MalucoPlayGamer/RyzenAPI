-- Lua provided by RyzenAPI
-- Game: addappid(2833930)

-- MAIN APPLICATION
addappid(2833930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2833931, 1, "d523aac5d02a217c89ca6d5b37473d6f564c152cba77cf8aae371da718503ba2")
