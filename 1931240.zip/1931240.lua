-- Lua provided by SkyAPI 
-- Game: MOTHERGUNSHIP: FORGE
addappid(1931240)
addappid(1931241, 1, "63cd8172458dd663f98d087d2cf6ac61d0940cb254086f32ed262f36a64df989")
