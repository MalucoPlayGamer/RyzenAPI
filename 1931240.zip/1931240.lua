-- Lua provided by RyzenAPI
-- Game: MOTHERGUNSHIP: FORGE

-- MAIN APPLICATION
addappid(1931240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931241, 1, "63cd8172458dd663f98d087d2cf6ac61d0940cb254086f32ed262f36a64df989")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
