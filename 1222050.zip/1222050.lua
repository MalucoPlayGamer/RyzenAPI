-- Lua provided by RyzenAPI
-- Game: Touhou Mechanical Scrollery | 幻想討幻経

-- MAIN APPLICATION
addappid(1222050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222051, 1, "603d89b56c0ddd9dde4f128111d0675064b05df390029865e61e468897f257da")

