-- 2622460's Lua and Manifest Created by Hubcap Manifest
-- The Skyland Chronicles
-- Created: August 27, 2026 at 05:42:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2622460) -- The Skyland Chronicles
addtoken(2622460, "7644346870986133077")
-- MAIN APP DEPOTS
addappid(2622461, 1, "237b4cad629acd6c9c9330a8a15067ad36296923a71bbc9c9b18d0550a5c4f7b") -- Depot 2622461
setManifestid(2622461, "4302537968258843560", 340592521)