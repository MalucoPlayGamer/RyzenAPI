-- Lua provided by RyzenAPI
-- Game: The Skyland Chronicles

-- MAIN APPLICATION
addappid(2622460) -- The Skyland Chronicles

-- MAIN APP DEPOTS / PACKAGES
addappid(2622461, 1, "237b4cad629acd6c9c9330a8a15067ad36296923a71bbc9c9b18d0550a5c4f7b") -- Depot 2622461
addtoken(2622460, "7644346870986133077")

