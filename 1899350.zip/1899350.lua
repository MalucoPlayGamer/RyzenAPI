-- Lua provided by RyzenAPI
-- Game: Trade Bots: A Technical Analysis Simulation

-- MAIN APPLICATION
addappid(1899350)
-- Game: addappid(1899350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899353,0,"bf47bd13892a35e193380e12f4b16a191a4eaf9d8d23423c279eb8ef69c29209")
