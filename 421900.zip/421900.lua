-- Lua provided by RyzenAPI
-- Game: Shadowrun Chronicles: INFECTED Director's Cut

-- MAIN APPLICATION
addappid(421900)
addappid(435200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(421901, 1, "e3f4f5fe7458ebff89844174558af5b5fee3a0b2c8437f8edac6041ef560f0dd")
addappid(421904, 1, "987d15c9c3a899a29d63586cd52e6334f77ae92fd2024310eb6c7e033ba16055")
addappid(421905, 1, "83b468340f75c029d3623bdf2620a756e2dd5e23123251a7af34558a4638481d")

