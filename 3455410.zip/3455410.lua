-- Lua provided by RyzenAPI
-- Game: 3455410

-- MAIN APPLICATION
addappid(3455410)
-- Game: addappid(3455410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3455411, 1, "7e87fc79ed27aac59a27741aef81c2f89ffddb5ea72f09dc1bba09cac51a26b6")
