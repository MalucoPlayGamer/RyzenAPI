-- Lua provided by RyzenAPI
-- Game: Dungeon Deck

-- MAIN APPLICATION
addappid(2895110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2895111,0,"e88eae751ddb43318026b0a6a2d46d670f68bfda2edb6b91089f5be28cca8f7f")

