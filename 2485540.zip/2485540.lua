-- Lua provided by SkyAPI 
-- Game: Never Ending Nightmare
addappid(2485540)
addappid(2485541, 1, "b6d32f267005b8ab02d986b2405074443999c670b888b6b63965a2a41d78f0e0")
