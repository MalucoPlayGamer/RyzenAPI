-- Lua provided by RyzenAPI
-- Game: Never Ending Nightmare

-- MAIN APPLICATION
addappid(2485540)
-- Game: addappid(2485540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485541, 1, "b6d32f267005b8ab02d986b2405074443999c670b888b6b63965a2a41d78f0e0")
