-- Lua provided by SkyAPI 
-- Game: 天台物语 Rooftop Story
addappid(2338800)
addappid(2338801, 1, "e5af54ae39e3a093cddb223a8e669acc43373cdd0e35cbf933846c6b7ce40a2c")
