-- Lua provided by RyzenAPI
-- Game: 1126100

-- MAIN APPLICATION
addappid(1126100)
-- Game: addappid(1126100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126101, 1, "6b32d9e81cf01816fb2b086cca0f72472454197797d5ef7d11bc244745e404af")
