-- Lua provided by RyzenAPI
-- Game: AppID 298480

-- MAIN APPLICATION
addappid(298480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(298481, 1, "773d39f214e010c24e809891d9dcb85a125ec906cbee382a23a6bf9b7daba6df")
addappid(298482, 1, "6026e6ee1a84e760b2f8faf13718e7bfe8ae59675e8b499ccf30f6c8b88dabbf")
addappid(298483, 1, "17b8a1927c52205d542b3aabfa099b97ff751b41c4f7c09cae681f86cf50db66")

