-- Lua provided by RyzenAPI
-- Game: AppID 1400100

-- MAIN APPLICATION
addappid(1400100)
-- Game: addappid(1400100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400101, 1, "ed76951325938c47b17e5dbce3311fa0b740320cbe4c00d2a74ad4370f032199")
