-- Lua provided by RyzenAPI
-- Game: Tower of Time Soundtrack

-- MAIN APPLICATION
addappid(713280)

-- MAIN APP DEPOTS / PACKAGES
addappid(713280,0,"52dd166e5385c5f6073b59e26302739f07875557e719aecce60c42e8e5951975")
