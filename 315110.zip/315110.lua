-- Lua provided by RyzenAPI
-- Game: Woah Dave!

-- MAIN APPLICATION
addappid(315110)

-- MAIN APP DEPOTS / PACKAGES
addappid(315111, 1, "1b31acbc5677d9ea4db287eed4260fe21f9a4dce422a3d78e98e8d5d650eeafa")
addappid(315112, 1, "d916a1450e344da31894f6488e4dc07219e3e13588336f9dabad174447a4fc39")
addappid(315113, 1, "cef815e2f85cf3f611f47a3dd0c571c71a49906b988fcf88bd27f5006acc134a")

