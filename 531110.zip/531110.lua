-- Lua provided by RyzenAPI
-- Game: Battles of Norghan

-- MAIN APPLICATION
addappid(531110)
-- Game: addappid(531110)

-- MAIN APP DEPOTS / PACKAGES
addappid(531111, 1, "4ad5e00f212cebd22306d152b1639682aa06c4b13fcd8f7f358c5b9f845b6224")
addappid(534830, 0, "253787c01afbb05242edf28bbdc9b4635c33fa544b3d06b72277919ad193b2df")
