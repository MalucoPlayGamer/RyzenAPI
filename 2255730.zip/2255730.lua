-- Lua provided by RyzenAPI
-- Game: 2255730

-- MAIN APPLICATION
addappid(2255730)
-- Game: addappid(2255730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255731, 1, "d14f20e565c1e43a10ab23d70e6e57475ae80314dc69ea85cf56228cba42aebe")
