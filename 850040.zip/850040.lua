-- Lua provided by RyzenAPI
-- Game: PuzzGun

-- MAIN APPLICATION
addappid(850040)

-- MAIN APP DEPOTS / PACKAGES
addappid(850041, 1, "a7f87659edf3f60f4e88d61029c1a339ddf9c2d10445040d09d4b8a49365b454")
