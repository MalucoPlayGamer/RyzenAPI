-- Lua provided by RyzenAPI
-- Game: Chaos Coming

-- MAIN APPLICATION
addappid(2356390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356391, 1, "03a5e2f08aafffa436b1292aec96f886e17470233bfaaa336ab2ec6bfdfb8551")
