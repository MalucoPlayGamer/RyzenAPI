-- Lua provided by RyzenAPI
-- Game: addappid(1556940)

-- MAIN APPLICATION
addappid(1556940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556941, 1, "e0bf2f670d9c9007109ec9b7938bb2bcd074b6fd88d00a6f75edc4f7b6bed70c")
