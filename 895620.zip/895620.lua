-- Lua provided by RyzenAPI
-- Game: AppID 895620

-- MAIN APPLICATION
addappid(895620)

-- MAIN APP DEPOTS / PACKAGES
addappid(895621, 1, "d43ff0db940ddcaaaf10a88d20286ea7f48a0eee9e62ba33b350860ccffc8e26")
addappid(895623, 1, "bc3a2d44c778fafa3501e61916403d9c952ea5d5d6d7517dba2434f178a0ed2b")
addappid(3394370, 0, "80aa14b15eaf1eaffce54fbaf112d0d0dd39f41bab9e166c56516cb8b0670f1d")
