-- 4516880's Lua and Manifest Created by Hubcap Manifest
-- Unusual Tales: After Bark
-- Created: August 17, 2026 at 03:53:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4516880) -- Unusual Tales: After Bark
-- MAIN APP DEPOTS
addappid(4516881, 1, "f1758d216ea782818398bb7253c70a23108b07fa65a8bf3b4d55974d9854a4a9") -- Depot 4516881
setManifestid(4516881, "3904786029374320984", 595206660)