-- Lua provided by RyzenAPI
-- Game: Unusual Tales: After Bark

-- MAIN APPLICATION
addappid(4516880) -- Unusual Tales: After Bark

-- MAIN APP DEPOTS / PACKAGES
addappid(4516881, 1, "f1758d216ea782818398bb7253c70a23108b07fa65a8bf3b4d55974d9854a4a9") -- Depot 4516881

