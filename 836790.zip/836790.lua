-- Lua provided by RyzenAPI 
-- Game: AppID 836790
addappid(836790)
addappid(836791, 1, "b9383f93bddc7850208fb86a2d1a7882406fb239249a80958fb65abc967b68e1")
addappid(836792, 1, "1fd1fb6893e58fbbaf20cc3fe0bffe0943b20bc5e18558bc60c16692beaa3dfc")
addappid(836793, 1, "1c8fd9617171f508e14b0be9f996087bc6829ff5a07175c96e48d6ddbaa1f3a1")
