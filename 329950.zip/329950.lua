-- Lua provided by RyzenAPI
-- Game: 329950

-- MAIN APPLICATION
addappid(329950)
-- Game: addappid(329950)

-- MAIN APP DEPOTS / PACKAGES
addappid(329951, 1, "41dae6e7138ffbbf347daf27e34f8999cea9a0542f3396f9749442f384204a4c")
