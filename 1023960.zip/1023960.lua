-- Lua provided by RyzenAPI
-- Game: Easter!

-- MAIN APPLICATION
addappid(1023960)
-- Game: addappid(1023960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023961, 1, "265142c202554342169f21522514ef6f9b2c1a3a2df9a76298a6b550c1c320f5")
