-- Lua provided by RyzenAPI
-- Game: Fatal Stormer

-- MAIN APPLICATION
addappid(818220)

-- MAIN APP DEPOTS / PACKAGES
addappid(818221, 1, "8a853d519a5bcafcb48653211680d171409b2dfa347f9f468065d9015c44f92e")
