-- Lua provided by RyzenAPI
-- Game: AppID 1088880

-- MAIN APPLICATION
addappid(1088880)
-- Game: addappid(1088880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088881, 1, "f6706dad739eb88d4bec460cb0f05ca7142b42e5501725ba67368ce62bf36ff4")
