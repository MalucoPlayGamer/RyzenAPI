-- Lua provided by SkyAPI 
-- Game: AppID 1088880
addappid(1088880)
addappid(1088881, 1, "f6706dad739eb88d4bec460cb0f05ca7142b42e5501725ba67368ce62bf36ff4")
