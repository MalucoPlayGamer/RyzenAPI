-- Lua provided by RyzenAPI
-- Game: Starboard

-- MAIN APPLICATION
addappid(3341750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3341753,0,"b5d78d223e8cca6dde4dd9f692915a6bbe5fabfa966be1065ca7791598af6847")

