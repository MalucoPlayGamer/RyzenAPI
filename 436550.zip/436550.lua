-- Lua provided by RyzenAPI
-- Game: addappid(436550)

-- MAIN APPLICATION
addappid(436550)

-- MAIN APP DEPOTS / PACKAGES
addappid(436551, 1, "f3c497d7a117f4d5809a587dc9558eca3efe214f1174525969b840fb3e249b34")
