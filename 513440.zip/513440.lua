-- Lua provided by RyzenAPI
-- Game: addappid(513440)

-- MAIN APPLICATION
addappid(513440)

-- MAIN APP DEPOTS / PACKAGES
addappid(513441, 1, "4a795944dca06d45ff19064ae829ca64144b868fb941b47e8ddc1b0b6d7c64f9")
