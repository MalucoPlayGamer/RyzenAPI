-- Lua provided by RyzenAPI
-- Game: SCALEPLANET

-- MAIN APPLICATION
addappid(1922360)
-- Game: addappid(1922360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922361, 1, "a95113818d1fa6d05ce75237b43e911c79a0d9f49b9d51ca3df3c5f24c8970e0")
