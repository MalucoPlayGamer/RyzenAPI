-- Lua provided by RyzenAPI 
-- Game: Silent Hope Demo
addappid(2275630)
addappid(2275631, 1, "e3ad5bb0fd18ba13a6a8abd59043e1b652b9c91fd0e602cfff68713a61333994")
