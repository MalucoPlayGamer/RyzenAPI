-- Lua provided by RyzenAPI
-- Game: Lines X

-- MAIN APPLICATION
addappid(724740)

-- MAIN APP DEPOTS / PACKAGES
addappid(724741, 1, "5f963c0cb216d7fa0a03a5891742c2ee8fef5d24ce8a704046ea2c0d7823aacf")
addappid(725000, 0, "bc7d1c440b93e33d27d7d6d947a003797e108890b7bb8a68f177890fcd9155f3")
