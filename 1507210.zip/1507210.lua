-- Lua provided by RyzenAPI
-- Game: Game: aerofly RC 8

-- MAIN APPLICATION
addappid(1507210)
-- Game: addappid(1507210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507211, 1, "59cd1b7291cc2a8e5fce77b288cecdcb2ceab16bb3040b1102d78ad639d341ad")
addappid(1507212, 1, "3c79712e8a6c6ddcaf750ce957f573bf072aa7500acfa5259ca0569772ead5b2")
addappid(1523450, 0, "aeac88980ed1e08d28308a3377a8263a35634f94483da99d69942072e8baf806")
addappid(1523451, 0, "c79e4375ccaa1af9149dfc30e28754fc8e644074ea685785b46363082b5fa120")
