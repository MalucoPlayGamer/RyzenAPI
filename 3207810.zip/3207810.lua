-- Lua provided by SkyAPI 
-- Game: In The Middle
addappid(3207810)
addappid(3207811, 1, "00544defb2792cfaa73272bbfb374baea18143e6e846d42bb7d62a0009d1dc5c")
