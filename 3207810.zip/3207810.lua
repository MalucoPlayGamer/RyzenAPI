-- Lua provided by RyzenAPI
-- Game: In The Middle

-- MAIN APPLICATION
addappid(3207810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207811, 1, "00544defb2792cfaa73272bbfb374baea18143e6e846d42bb7d62a0009d1dc5c")

