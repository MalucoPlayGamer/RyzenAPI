-- Lua provided by RyzenAPI
-- Game: addappid(733780)

-- MAIN APPLICATION
addappid(733780)

-- MAIN APP DEPOTS / PACKAGES
addappid(733781, 1, "d330e1ea2aa3e2dbe27a8bf54ea7dcc6a72a89402ff230838ed18a376f2d7098")
