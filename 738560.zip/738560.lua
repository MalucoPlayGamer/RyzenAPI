-- Lua provided by RyzenAPI
-- Game: Fariwalk: The Prelude

-- MAIN APPLICATION
addappid(738560)
-- Game: addappid(738560)

-- MAIN APP DEPOTS / PACKAGES
addappid(738562,0,"8175c61e91f817d8b2d682322319ea638873478267d5d488a76fbcc1711e0728")
