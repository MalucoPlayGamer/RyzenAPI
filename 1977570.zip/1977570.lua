-- Lua provided by SkyAPI 
-- Game: A Dance of Fire and Ice - Neo Cosmos
addappid(1977570)
addappid(1977571, 1, "a4ec8a574d6949e27a066e3ef02d87d50cc32e090944d977595132716b46ed40")
addappid(1977572, 1, "b0d89adeb9338cee8859eb5596cfad872bdf7a96c8e58f53cb8f214857e5c481")
addappid(1977573, 1, "51140ab9601562c890952d5b7022bc09726be1e7fc6d8dbbfc09f5318110f6f7")
addappid(1977574, 1, "b74fb5a309784a778cb5d14cd6b64ee94da0fd481eef93e9b50fc183ca8b3b1f")
