-- Lua provided by RyzenAPI
-- Game: Labyrinth of death

-- MAIN APPLICATION
addappid(1820910)
-- Game: addappid(1820910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820911, 1, "c27b244ffd1f07ada9e0ef356b3fdfc67eebdab0773e55de1686e3e193e3ad05")
