-- Lua provided by SkyAPI 
-- Game: AppID 2764360
addappid(2764360)
addappid(2764361, 1, "24356d08e1d88e59c0d8aaa73ea8d545dea8f96479b4a4925a37653ba661a728")
