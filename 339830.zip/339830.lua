-- Lua provided by RyzenAPI
-- Game: AppID 339830

-- MAIN APPLICATION
addappid(339830)
-- Game: addappid(339830)

-- MAIN APP DEPOTS / PACKAGES
addappid(339831, 1, "1bbcf737bbafd5a9a711a9693f54c6803fac1d7fb684507a500782cd2ba9f9d9")
addappid(339832, 1, "e854a8f9c763472afffbaf92886976367848595ae3266e017b9f2e45a9d4b5e9")
