-- Lua provided by RyzenAPI
-- Game: addappid(2821690)

-- MAIN APPLICATION
addappid(2821690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821691, 1, "2d824b155bc67bf45e01f3be84285aab1ecabc17dc864d8b751ea8aa15645cb5")
