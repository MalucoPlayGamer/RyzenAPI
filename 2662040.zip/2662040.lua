-- Lua provided by RyzenAPI
-- Game: 2662040

-- MAIN APPLICATION
addappid(2662040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2662040,0,"05bccd13c2e9ac418a3d2959dfba61c733103631f4feac706c3b1ece5bdebe5d")

