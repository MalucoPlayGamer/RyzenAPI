-- Lua provided by RyzenAPI
-- Game: Fan Speak

-- MAIN APPLICATION
addappid(3593990)
-- Game: addappid(3593990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3593991, 1, "023e135687a5584a6e004f69f2438a92cae7ca49f2d20281530cf7419b2a8a42")
