-- Lua provided by RyzenAPI 
-- Game: Fan Speak
addappid(3593990)
addappid(3593991, 1, "023e135687a5584a6e004f69f2438a92cae7ca49f2d20281530cf7419b2a8a42")
