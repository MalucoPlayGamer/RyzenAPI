-- Lua provided by RyzenAPI
-- Game: Fan Speak

-- MAIN APPLICATION
addappid(3593990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3593991, 1, "023e135687a5584a6e004f69f2438a92cae7ca49f2d20281530cf7419b2a8a42")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4921580)
