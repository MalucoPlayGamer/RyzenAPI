-- Lua provided by RyzenAPI
-- Game: Game: Hex Empire 3

-- MAIN APPLICATION
addappid(722920)
-- Game: addappid(722920)

-- MAIN APP DEPOTS / PACKAGES
addappid(722921, 1, "2e96ee4e8f7a85573920e00f6d6291906c9bd14b5f0dbbb34bf5341fc228d240")
