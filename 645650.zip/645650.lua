-- Lua provided by RyzenAPI
-- Game: AppID 645650

-- MAIN APPLICATION
addappid(645650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(645651, 1, "a9c050c533e9f333bd6c7063542d940f87a3cd75ba11fd4d7d67f4a99376b98a")

