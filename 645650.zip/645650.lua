-- Lua provided by RyzenAPI
-- Game: Chickens Madness

-- MAIN APPLICATION
addappid(645650)
-- Game: addappid(645650)

-- MAIN APP DEPOTS / PACKAGES
addappid(645651, 1, "a9c050c533e9f333bd6c7063542d940f87a3cd75ba11fd4d7d67f4a99376b98a")
