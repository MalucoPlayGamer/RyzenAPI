-- Lua provided by SkyAPI 
-- Game: AppID 645650
addappid(645650)
addappid(645651, 1, "a9c050c533e9f333bd6c7063542d940f87a3cd75ba11fd4d7d67f4a99376b98a")
