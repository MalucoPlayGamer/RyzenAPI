-- Lua provided by RyzenAPI
-- Game: Game: AppID 2589870

-- MAIN APPLICATION
addappid(2589870)
-- Game: addappid(2589870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589871, 1, "81307714f23165bd26dd15e520c85f236abe47141f7085b28e011f1d0f5c2e1d")
