-- Lua provided by SkyAPI 
-- Game: The Hotel
addappid(1831870)
addappid(1831871, 1, "92f856d6b7ef0ef0647059660bde25121fba4726ae1e763f4b8672d9a1b163e0")
