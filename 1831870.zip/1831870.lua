-- Lua provided by RyzenAPI
-- Game: The Hotel

-- MAIN APPLICATION
addappid(1831870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831871, 1, "92f856d6b7ef0ef0647059660bde25121fba4726ae1e763f4b8672d9a1b163e0")

