-- Lua provided by RyzenAPI
-- Game: 1954300

-- MAIN APPLICATION
addappid(1954300)
-- Game: addappid(1954300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954301, 1, "e64cc96ae762bb3afc72dbeb40b0d71f540f997043f1508a44d725a182597f54")
