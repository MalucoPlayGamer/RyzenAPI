-- Lua provided by SkyAPI 
-- Game: Avadon: The Black Fortress
addappid(112100)
addappid(112101, 1, "d965f376dba74640b6b2d3cf472161cc92532892f4dc860d134d97b233fee4f8")
addappid(112102, 1, "314c81ced8bdc6c13899051b8fb557d08b12900522b3837e92ab850cbe8e2eb0")
addappid(112103, 1, "f0baf5d089a4adea8b97c907102edeaa5a9c3761a28e4f808e3bc5c29d0d8bb5")
