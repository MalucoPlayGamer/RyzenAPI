-- Lua provided by SkyAPI 
-- Game: AppID 352620
addappid(352620)
addappid(352621, 1, "b24b679d42a786cdd7ea052bd57d3f33a26e69e1383b7927f86ce199f0008b25")
addappid(352622, 1, "55d2f35690ae508a3da26653d25be21e54fea60c30da6db6eae1f53562890bdf")
