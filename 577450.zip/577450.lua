-- Lua provided by RyzenAPI
-- Game: addappid(577450)

-- MAIN APPLICATION
addappid(577450)

-- MAIN APP DEPOTS / PACKAGES
addappid(577450,0,"efbe34ac7ecfa79956ca5d53f43011169bc1f827522f7862d0350ff52fda0685")
