-- Lua provided by RyzenAPI
-- Game: Game: Frontier Hunter: Erza’s Wheel of Fortune

-- MAIN APPLICATION
addappid(1429500)
-- Game: addappid(1429500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429501, 1, "4af31007a32b3a62aa74845448e0de78f69c44172d68b5292dc330e9b0be7ad8")
addappid(1429502, 1, "7a5cc48e0d18d23604a2b14deebc04c3d406551f22a4a43da1192b8845c1091d")
addappid(2177411, 0, "050a349e666466b9c5bc23b673aeadc4c84fa528b6cdae05c39f5129e4e67e3c")
addappid(2177420, 0, "8cb9bde0a297f48e38063f9cebb17b4239349a7f0f97ff36590605d86df3f0bc")
