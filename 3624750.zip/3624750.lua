-- Lua provided by RyzenAPI
-- Game: 天道轮回：我的修仙梦

-- MAIN APPLICATION
addappid(3624750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3624751, 1, "667e804e4e912a6f0798c8269c8c429965126619130b45d1b3fddcbb21a70af5")
