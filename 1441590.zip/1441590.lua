-- Lua provided by RyzenAPI
-- Game: Game: Hentai Maid Club

-- MAIN APPLICATION
addappid(1441590)
-- Game: addappid(1441590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441591, 1, "4e639131abe9ce8445ccbc1c1160877a608ced54087b9dd9c352ca46e11d24c7")
