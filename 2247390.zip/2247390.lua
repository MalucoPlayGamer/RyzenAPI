-- Lua provided by RyzenAPI
-- Game: No More Money - Season 2

-- MAIN APPLICATION
addappid(2247390)
-- Game: addappid(2247390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247390,0,"18a5246633dcc658e083a9fcbd56032aa8b4244939035d5a1af2e69d55f9d0e5")
