-- Lua provided by RyzenAPI
-- Game: Game: PlateUp!

-- MAIN APPLICATION
addappid(1599600)
-- Game: addappid(1599600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599601, 1, "f76247b76f5b0ded8151f64457185810cc0eebc920832653d7c5099888f26754")
