-- Lua provided by RyzenAPI
-- Game: 咸鱼的挂机游戏快餐版

-- MAIN APPLICATION
addappid(1854860)
-- Game: addappid(1854860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854861, 1, "f8f505513f793c8e708d39c9264fa391352660111c2c1c75ff14be2d4fe60ece")
