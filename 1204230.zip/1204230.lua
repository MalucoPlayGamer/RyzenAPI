-- Lua provided by RyzenAPI
-- Game: 4th Generation Warfare

-- MAIN APPLICATION
addappid(1204230)
addappid(1584710)
addappid(2104800)
addappid(2160770)
addappid(2199620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1204231,0,"4e2d662634bcaae8251c4b7c3b8538ebb8d715c9586fa2e1c44ae1216c0c440c")

