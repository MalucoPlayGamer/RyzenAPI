-- Lua provided by RyzenAPI
-- Game: Game: 4th Generation Warfare

-- MAIN APPLICATION
addappid(1204230)
-- Game: addappid(1204230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204231, 1, "4e2d662634bcaae8251c4b7c3b8538ebb8d715c9586fa2e1c44ae1216c0c440c")
