-- Lua provided by RyzenAPI
-- Game: 3317410

-- MAIN APPLICATION
addappid(3317410)
-- Game: addappid(3317410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317411, 1, "2551edc6da9a53f5a4e1810ae83470d95753caecd67c714d9e0b5453060981a9")
