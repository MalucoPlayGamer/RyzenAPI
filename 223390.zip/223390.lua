-- Lua provided by RyzenAPI
-- Game: AppID 223390

-- MAIN APPLICATION
addappid(223390)
addappid(228983)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(223391, 1, "d82d304df5297acdd65e5fbe716624b4228198967948094737ffcda5e58c6b45")
