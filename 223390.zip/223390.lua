-- Lua provided by RyzenAPI
-- Game: Forge

-- MAIN APPLICATION
addappid(223390)
addappid(228983)
addappid(228990)
addappid(236650)
addappid(249910)
addappid(249911)
addappid(249912)
addappid(249913)
addappid(266880)
addappid(313850)

-- MAIN APP DEPOTS / PACKAGES
addappid(223391, 1, "d82d304df5297acdd65e5fbe716624b4228198967948094737ffcda5e58c6b45")
