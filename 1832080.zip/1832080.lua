-- Lua provided by RyzenAPI
-- Game: addappid(1832080)

-- MAIN APPLICATION
addappid(1832080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832081, 1, "ff25fd0b97d851715a6caeb2a949447b764e0811c7abc551147c2e0851d48d03")
