-- Lua provided by RyzenAPI
-- Game: 问山海:暗黑修仙传奇

-- MAIN APPLICATION
addappid(3117040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3117041, 1, "be31c4a087a20ce92432da5b6e188d593ca70127f1fd89196a54ff6abd8c2b30")

