-- Lua provided by RyzenAPI
-- Game: Game: 问山海:暗黑修仙传奇

-- MAIN APPLICATION
addappid(3117040)
-- Game: addappid(3117040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3117041, 1, "be31c4a087a20ce92432da5b6e188d593ca70127f1fd89196a54ff6abd8c2b30")
