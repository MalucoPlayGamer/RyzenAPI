-- Lua provided by RyzenAPI
-- Game: Commander Bug Wars

-- MAIN APPLICATION
addappid(2881810) -- Commander Bug Wars

-- MAIN APP DEPOTS / PACKAGES
addappid(2881812, 1, "2d69dd13e4681155bb177b9300c175d9129787c2c1117712aa710971482f0b02") -- Depot 2881812

