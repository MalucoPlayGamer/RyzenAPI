-- Lua provided by RyzenAPI
-- Game: 916880

-- MAIN APPLICATION
addappid(916880)
-- Game: addappid(916880)

-- MAIN APP DEPOTS / PACKAGES
addappid(916881, 1, "7a4349c209929a1dcddf7594a3f0c06e07f351b4299da975de4aa3f6870df0a0")
