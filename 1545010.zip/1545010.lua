-- Lua provided by RyzenAPI
-- Game: Game: ExZeus™: The Complete Collection

-- MAIN APPLICATION
addappid(1545010)
-- Game: addappid(1545010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545011, 1, "bfbaeabc5383e2188cc8e21c6e99d4e1820dee3238237d1bcb73f647edeb74b3")
