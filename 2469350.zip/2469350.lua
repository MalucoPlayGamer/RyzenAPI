-- Lua provided by SkyAPI 
-- Game: Jagged Alliance 3 Soundtrack
addappid(2469350)
addappid(2469351, 1, "1a9a97d3a89e8c99dffc84f57b9cd7ab0cd01c557c3a51477ffd19d1a199d9e6")
addappid(2469352, 1, "276785045e18947700b587a2bd3f99a031c3402101db4f9e7f208270049af7dc")
