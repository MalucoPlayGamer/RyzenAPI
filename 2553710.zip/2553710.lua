-- Lua provided by RyzenAPI
-- Game: Birds Aren't Real: The Game

-- MAIN APPLICATION
addappid(2553710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553711, 1, "441221e3a90d7118fe47c03c462850b452950f04ad105bfd4e4707bb7d90ad55")
addappid(2553713, 1, "4400fe1650bdf00bcf7672f39a7b7a68e87c22af5b62f94f98c55cc0f4a5eeaf")

