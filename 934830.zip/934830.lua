-- Lua provided by SkyAPI 
-- Game: AppID 934830
addappid(934830)
addappid(934831, 1, "25c1b9a7024b594cef9958df5a54cf58e1f61f4149fae56f3befbe42b266786b")
