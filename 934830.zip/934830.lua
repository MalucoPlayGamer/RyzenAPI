-- Lua provided by RyzenAPI
-- Game: Circuit Slinger

-- MAIN APPLICATION
addappid(934830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(934831, 1, "25c1b9a7024b594cef9958df5a54cf58e1f61f4149fae56f3befbe42b266786b")
