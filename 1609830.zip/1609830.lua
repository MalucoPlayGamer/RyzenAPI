-- Lua provided by RyzenAPI 
-- Game: WillWalker
addappid(1609830)
addappid(1609831, 1, "1a917198bcc55a2803219095c8eb1fd57750495d9a6b17148e86c0a8a9672fe3")
