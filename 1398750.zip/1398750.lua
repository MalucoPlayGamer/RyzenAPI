-- Lua provided by RyzenAPI
-- Game: addappid(1398750)

-- MAIN APPLICATION
addappid(1398750)
addappid(1500430)
addappid(1500431)
addappid(1500440)
addappid(1500441)
addappid(1500442)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398751, 1, "e2d5438356e152e00a21401e34bef157296254f108dc3752e31f91b546676aad")
