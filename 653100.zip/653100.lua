-- Lua provided by RyzenAPI
-- Game: AppID 653100

-- MAIN APPLICATION
addappid(653100)

-- MAIN APP DEPOTS / PACKAGES
addappid(653101, 1, "e1fd27b3df5fcc3310aacf3763c2b49c80e1e5954ae8c827edd22b33d118d33f")
