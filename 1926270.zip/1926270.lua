-- Lua provided by RyzenAPI
-- Game: Bloodhound

-- MAIN APPLICATION
addappid(1926270)
addappid(2535550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926271, 1, "f30c52d976eef95ea8bcd16cfbe09029eea3c0dc669662b099f9d5efa073dd27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
