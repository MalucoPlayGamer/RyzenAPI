-- Lua provided by RyzenAPI
-- Game: 1926270

-- MAIN APPLICATION
addappid(1926270)
addappid(2535550)
-- Game: addappid(1926270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926271, 1, "f30c52d976eef95ea8bcd16cfbe09029eea3c0dc669662b099f9d5efa073dd27")
