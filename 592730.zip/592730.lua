-- Lua provided by RyzenAPI
-- Game: Aerial Destruction

-- MAIN APPLICATION
addappid(592730)

-- MAIN APP DEPOTS / PACKAGES
addappid(592731, 1, "c3a735120d051a25d9847eac1125e39868f8cc0fea641c9d83d85afec243331f")
addappid(592732, 1, "ee283a26ef79049aafdaaede29439e0dc5e0cbff98211bc0ac0fe1c967acbe24")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
