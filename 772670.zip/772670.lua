-- Lua provided by RyzenAPI
-- Game: Beyond the Invisible: Darkness Came

-- MAIN APPLICATION
addappid(772670)

-- MAIN APP DEPOTS / PACKAGES
addappid(772671, 1, "bac9c74af17f304b0ad6231aa0e948fd591c01999dac149b9bae6aeb1bc50c42")
