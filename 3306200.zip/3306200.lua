-- Lua provided by RyzenAPI
-- Game: Futanari★Coffee shop

-- MAIN APPLICATION
addappid(3306200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3306201, 1, "df0568186ef1858d1d4323e254ded42fb10a23af7da37d4b94f848fb79948da0")

