-- Lua provided by RyzenAPI
-- Game: AppID 1132080

-- MAIN APPLICATION
addappid(1132080)
-- Game: addappid(1132080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132081, 1, "f7e7ecb79cfdbe1d316a28aa22fb5241e973e154f27bb18ab1a3aaf90e02df75")
