-- Lua provided by RyzenAPI
-- Game: CrazyFlasher7 Mercenary Empire

-- MAIN APPLICATION
addappid(1484680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484681, 1, "9a7f39d55fe940c384c542ab18fed7a9df6ae9f4a97b26693d22624b5099ac27")

