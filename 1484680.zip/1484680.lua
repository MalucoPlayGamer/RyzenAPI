-- Lua provided by RyzenAPI
-- Game: CrazyFlasher7 Mercenary Empire

-- MAIN APPLICATION
addappid(1484680)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1484681, 1, "9a7f39d55fe940c384c542ab18fed7a9df6ae9f4a97b26693d22624b5099ac27")

