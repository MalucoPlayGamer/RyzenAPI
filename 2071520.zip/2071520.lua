-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2071520)
addappid(2250990)
addappid(2255400)
addappid(2397580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2071523,0,"8c218f93df63240d884934be8bb852a289c49aa6692d0b792c35458e5f8522de")
addappid(2212590,0,"3f0ed2ca96b454cfc3dfacbc9079f78a36890824cc162383eaaf7dc3b38ba5ae")
