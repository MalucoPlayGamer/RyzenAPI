-- Lua provided by RyzenAPI
-- Game: 2606920

-- MAIN APPLICATION
addappid(2606920)
-- Game: addappid(2606920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2606921, 1, "59f7a7fd9226e25de9633590b50f3d7b3c94144a5a4ff544e0ea0130cea634fc")
