-- Lua provided by SkyAPI 
-- Game: Field of Honor
addappid(2606920)
addappid(2606921, 1, "59f7a7fd9226e25de9633590b50f3d7b3c94144a5a4ff544e0ea0130cea634fc")
