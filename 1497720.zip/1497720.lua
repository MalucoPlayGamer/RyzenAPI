-- Lua provided by RyzenAPI 
-- Game: Crown Trick Soundtrack
addappid(1497720)
addappid(1497721, 1, "8a712d50159328a50b39d6f912da4ed52270dab04c19540400a393f660da2019")
