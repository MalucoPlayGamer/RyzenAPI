-- 2895360's Lua and Manifest Created by Hubcap Manifest
-- Moni Mons
-- Created: August 16, 2026 at 12:58:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2895360) -- Moni Mons
-- MAIN APP DEPOTS
addappid(2895361, 1, "42fd1005eace4309992b759dfbdd672dd329e6fd175362989177d227f401c374") -- Depot 2895361
setManifestid(2895361, "2012383859853526961", 738753800)