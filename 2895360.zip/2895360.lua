-- Lua provided by RyzenAPI
-- Game: Moni Mons

-- MAIN APPLICATION
addappid(2895360) -- Moni Mons

-- MAIN APP DEPOTS / PACKAGES
addappid(2895361, 1, "42fd1005eace4309992b759dfbdd672dd329e6fd175362989177d227f401c374") -- Depot 2895361

