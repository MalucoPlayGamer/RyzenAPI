-- Lua provided by RyzenAPI
-- Game: World of Tanks Blitz

-- MAIN APPLICATION
addappid(444200)

-- MAIN APP DEPOTS / PACKAGES
addappid(444202,0,"5b6adc08f9619d6e24a4f0ec439f0b0f64382713d2ba1c47dccff8688067c4f7")
addappid(444203,0,"76272afe9a85ab44d5eaff2c256dc29c81901920649c1424fbe1c114ee22721a")
