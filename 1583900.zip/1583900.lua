-- Lua provided by RyzenAPI
-- Game: 1583900

-- MAIN APPLICATION
addappid(1583900)
-- Game: addappid(1583900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583901, 1, "ad9ce9a26213f8135e9c1b70db321f22ca61ffaa235927304cabcde2e7d69e2c")
