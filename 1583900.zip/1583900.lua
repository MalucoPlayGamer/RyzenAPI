-- Lua provided by SkyAPI 
-- Game: M.A.R.S.S.
addappid(1583900)
addappid(1583901, 1, "ad9ce9a26213f8135e9c1b70db321f22ca61ffaa235927304cabcde2e7d69e2c")
