-- Lua provided by RyzenAPI
-- Game: Game: AppID 1180540

-- MAIN APPLICATION
addappid(1180540)
-- Game: addappid(1180540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180541, 1, "0b86bcba6cc383cf3b5e5b4f75247fe1bba83fd2a566c42f1899ebceeab04009")
