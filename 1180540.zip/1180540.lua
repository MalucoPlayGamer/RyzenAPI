-- Lua provided by SkyAPI 
-- Game: AppID 1180540
addappid(1180540)
addappid(1180541, 1, "0b86bcba6cc383cf3b5e5b4f75247fe1bba83fd2a566c42f1899ebceeab04009")
