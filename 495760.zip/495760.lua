-- Lua provided by RyzenAPI
-- Game: Deios II // DEIDIA

-- MAIN APPLICATION
addappid(495760)

-- MAIN APP DEPOTS / PACKAGES
addappid(495761, 1, "195e27b1cc936217256cbbd010f427fe426badd02b1c19dc689b97caef3c648a")
