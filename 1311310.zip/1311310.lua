-- Lua provided by RyzenAPI
-- Game: Escape from the hospital

-- MAIN APPLICATION
addappid(1311310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311311, 1, "008886ff0b53fd078136d0501a069c2667ad058587dc1615042147e42423c0c6")

