-- Lua provided by RyzenAPI
-- Game: Game: Moonlight Pulse Demo

-- MAIN APPLICATION
addappid(2291860)
-- Game: addappid(2291860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2291861, 1, "7981d392ae74911cac67aef9603eb1103aff6b4c71f15c7355959af7b9a0669f")
