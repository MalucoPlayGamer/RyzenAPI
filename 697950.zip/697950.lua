-- Lua provided by RyzenAPI
-- Game: Tank Wars: Anniversary Edition

-- MAIN APPLICATION
addappid(697950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(697951, 1, "535d1d20c094d4e2de512bed53425b5f785d097c8a0dffb257cfc501b0cb50b9")
