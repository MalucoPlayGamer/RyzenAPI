-- Lua provided by RyzenAPI
-- Game: addappid(697950)

-- MAIN APPLICATION
addappid(697950)

-- MAIN APP DEPOTS / PACKAGES
addappid(697951, 1, "535d1d20c094d4e2de512bed53425b5f785d097c8a0dffb257cfc501b0cb50b9")
