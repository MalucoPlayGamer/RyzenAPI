-- Lua provided by RyzenAPI 
-- Game: Song of the Myrne: What Lies Beneath
addappid(333330)
addappid(333331, 1, "0aa3ae7296fba20e0b3e49a5b441fa2d2c4d12903909b0b2ee1f87ebee567467")
addappid(333332, 1, "335bf687e52705b4e853292f366fa23159320493a3455b8fd247bfe7fe22a0c2")
addappid(333333, 1, "17744f77514be6e9a0fb337e8080dccf29b499a6e676ba5d2b65b32c789cb2a9")
