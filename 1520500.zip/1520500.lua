-- Lua provided by RyzenAPI
-- Game: 1520500

-- MAIN APPLICATION
addappid(1520500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520502,0,"1b369bdd7b5ad7930005e61fb9d2c80e232bd3edf76635da4b681eef7c7e7e7a")
