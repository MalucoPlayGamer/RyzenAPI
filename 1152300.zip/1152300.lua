-- Lua provided by RyzenAPI 
-- Game: AppID 1152300
addappid(1152300)
addappid(1152301, 1, "f9995d19407818fc7ebe49d2d895ecf05fd5b6205ce9c7f4f2fd091ec834c9bb")
