-- Lua provided by RyzenAPI
-- Game: AppID 1152300

-- MAIN APPLICATION
addappid(1152300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1152301, 1, "f9995d19407818fc7ebe49d2d895ecf05fd5b6205ce9c7f4f2fd091ec834c9bb")

