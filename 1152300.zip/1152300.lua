-- Lua provided by RyzenAPI
-- Game: Atelier Ayesha: The Alchemist of Dusk DX

-- MAIN APPLICATION
addappid(1152300)
-- Game: addappid(1152300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152301, 1, "f9995d19407818fc7ebe49d2d895ecf05fd5b6205ce9c7f4f2fd091ec834c9bb")
