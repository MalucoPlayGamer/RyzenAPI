-- Lua provided by SkyAPI 
-- Game: AppID 684820
addappid(684820)
addappid(684821, 1, "bd4a134678573c0ce8a9223b8d9d733f291cb103b1f8b82b04080926df5ad8a1")
