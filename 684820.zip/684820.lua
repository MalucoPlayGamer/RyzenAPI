-- Lua provided by RyzenAPI
-- Game: AppID 684820

-- MAIN APPLICATION
addappid(684820)
-- Game: addappid(684820)

-- MAIN APP DEPOTS / PACKAGES
addappid(684821, 1, "bd4a134678573c0ce8a9223b8d9d733f291cb103b1f8b82b04080926df5ad8a1")
