-- Lua provided by RyzenAPI
-- Game: Game: Captain Sabertooth and the Magic Diamond

-- MAIN APPLICATION
addappid(1383970)
-- Game: addappid(1383970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383971, 1, "c825b21ed7a24469dfd8d9f9f556f900fa07875e6545909e15a0293f43974b88")
