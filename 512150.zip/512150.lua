-- Lua provided by RyzenAPI
-- Game: Swordlord

-- MAIN APPLICATION
addappid(512150)

-- MAIN APP DEPOTS / PACKAGES
addappid(512151,0,"e8e83e3b872f101ebccd3b5092b2dbaf1f4636ca23c8a1fd410e74d2a6cf787a")

