-- Lua provided by RyzenAPI
-- Game: addappid(1781070)

-- MAIN APPLICATION
addappid(1781070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781070,0,"b5a46bc2207c721cf73bde0d6190254673d9ba060c2ecd5e9c27d65bf4c38411")
