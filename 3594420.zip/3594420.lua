-- Lua provided by RyzenAPI
-- Game: RebellionGODSOUL-OST-【VOL1:Resonance】

-- MAIN APPLICATION
addappid(3594420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3594421, 1, "2d4945cfc45e9a87f2b95b5415d0dbcafca57d7cfc96c83e9c22dedfc1159e44")
addappid(3594422, 1, "32babec84669f8415aef06baadfd7362bb58ad6f674588bd0a157f1f729e8775")

