-- Lua provided by RyzenAPI
-- Game: 2164670

-- MAIN APPLICATION
addappid(2164670)
-- Game: addappid(2164670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164670,0,"b215889ab3b5e31129008385eab85eea194926c369350c3fa4fb4d95ff6c58ff")
