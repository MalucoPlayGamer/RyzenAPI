-- Lua provided by RyzenAPI
-- Game: Kneedle Knight

-- MAIN APPLICATION
addappid(2491720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491721, 1, "ca7c68e05455202005e4433e5d43102b11980ef8a2bd034067bc9e6475b9d36c")

