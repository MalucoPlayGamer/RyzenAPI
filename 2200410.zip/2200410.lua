-- Lua provided by SkyAPI 
-- Game: AppID 2200410
addappid(2200410)
addappid(2200411, 1, "80624ee38ccb1c217e6e94d996a4f2862571fc533fe1a9f9bbbeb7bbd1323f9b")
