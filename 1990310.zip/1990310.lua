-- Lua provided by RyzenAPI
-- Game: addappid(1990310)

-- MAIN APPLICATION
addappid(1990310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990311, 1, "ef44e2f2b79051dc4fcd063dd1d9e450605122b407a8f0e8ab3c49336f260290")
