-- Lua provided by RyzenAPI
-- Game: 出張 Business trip

-- MAIN APPLICATION
addappid(3235650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3235651, 1, "f1894f67d013dc1838db468c1e985c3e0b0dcf01f52215cdd944a902083709ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
