-- Lua provided by SkyAPI 
-- Game: Monster Girl's Labyrinth
addappid(1789470)
addappid(1789471, 1, "4147e6435a64bef28d7bf86528f65617e7ba8f9f9666c77371f3d4ed9a3d6c09")
