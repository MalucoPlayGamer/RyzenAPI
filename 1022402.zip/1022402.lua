-- Lua provided by RyzenAPI
-- Game: addappid(1022402)

-- MAIN APPLICATION
addappid(1022402)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022402,0,"88b88a509035e9ab53d56cbd1293c17b6f0dfeea1ddeb3d6018ce373dfdb38d0")
