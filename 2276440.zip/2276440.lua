-- Lua provided by SkyAPI 
-- Game: AppID 2276440
addappid(2276440)
addappid(2276441, 1, "666f16ca1dd0c34bf6659cca548d2214ef2ecb8523ee2e2864446354363de3d5")
