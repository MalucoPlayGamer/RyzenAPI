-- Lua provided by RyzenAPI
-- Game: addappid(2276440)

-- MAIN APPLICATION
addappid(2276440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276441, 1, "666f16ca1dd0c34bf6659cca548d2214ef2ecb8523ee2e2864446354363de3d5")
