-- Lua provided by RyzenAPI
-- Game: Game: AppID 1895670

-- MAIN APPLICATION
addappid(1895670)
-- Game: addappid(1895670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895671, 1, "d47ebb1be55074196cda661ad02f304c45d7728ee8e81c1d0692e788173d0146")
