-- Lua provided by RyzenAPI
-- Game: Idle Build RPG

-- MAIN APPLICATION
addappid(2519990)
-- Game: addappid(2519990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2519991, 1, "4b7b3af61023e27ba890dc0abd0893757e248625e2fc42d22e75906330f339d6")
