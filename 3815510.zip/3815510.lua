-- Lua provided by RyzenAPI
-- Game: addappid(3815510)

-- MAIN APPLICATION
addappid(3815510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3815511, 1, "6d18fd7e2a8e87cd64786c3e41b9629ca009a1e01aa81bc6082230b9d66d7dca")
