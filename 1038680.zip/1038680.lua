-- Lua provided by SkyAPI 
-- Game: AppID 1038680
addappid(1038680)
addappid(1038681, 1, "a6a72b8907a74b45ff0d3a6e7482431a6a6e9d25c42f35783f004ab1d2f9cc09")
