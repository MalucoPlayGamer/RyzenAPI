-- Lua provided by SkyAPI 
-- Game: Age of Gladiators
addappid(442500)
addappid(442501, 1, "88d94e4d6fc0ea421a6b17028c75359da53b7e7ed7dce611df468248a04fb363")
