-- Lua provided by RyzenAPI
-- Game: Age of Gladiators

-- MAIN APPLICATION
addappid(442500)
-- Game: addappid(442500)

-- MAIN APP DEPOTS / PACKAGES
addappid(442501, 1, "88d94e4d6fc0ea421a6b17028c75359da53b7e7ed7dce611df468248a04fb363")
