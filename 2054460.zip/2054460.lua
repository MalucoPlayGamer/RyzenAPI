-- Lua provided by RyzenAPI
-- Game: Game: NEET Demo

-- MAIN APPLICATION
addappid(2054460)
-- Game: addappid(2054460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054461, 1, "fd6cc12077807c013713d8dfba7a33f2958f20d4271550d419ce40a28b497d41")
