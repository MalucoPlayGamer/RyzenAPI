-- Lua provided by RyzenAPI
-- Game: Pegfinity

-- MAIN APPLICATION
addappid(3947040) -- Pegfinity

-- MAIN APP DEPOTS / PACKAGES
addappid(3947041, 1, "9e5e971647727eb87913197a387aac9441aef730b937d9e102d4d746d3b96338") -- Depot 3947041

