-- 3947040's Lua and Manifest Created by Hubcap Manifest
-- Pegfinity
-- Created: August 14, 2026 at 18:37:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3947040) -- Pegfinity
-- MAIN APP DEPOTS
addappid(3947041, 1, "9e5e971647727eb87913197a387aac9441aef730b937d9e102d4d746d3b96338") -- Depot 3947041
setManifestid(3947041, "1672913054701394510", 112185036)