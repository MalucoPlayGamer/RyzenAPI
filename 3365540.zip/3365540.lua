-- Lua provided by RyzenAPI
-- Game: 3365540

-- MAIN APPLICATION
addappid(3365540)
-- Game: addappid(3365540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365540,0,"d097c4cad16b43fd708c515b702d20cc36699109c182e9544cabf3d83741d05c")
