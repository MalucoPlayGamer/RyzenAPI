-- Lua provided by RyzenAPI
-- Game: Kabukicho Story

-- MAIN APPLICATION
addappid(1339380)
-- Game: addappid(1339380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339381, 1, "c6374d97195478f71156749b374a9eabb44eee703b74111b96bda753a7500f56")
