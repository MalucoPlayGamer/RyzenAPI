-- Lua provided by RyzenAPI
-- Game: RELOADIAN

-- MAIN APPLICATION
addappid(3125690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125691,0,"90634ab9bcfdddd3b32099c1141054407581f9321e8f28d56766de142449e4ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
