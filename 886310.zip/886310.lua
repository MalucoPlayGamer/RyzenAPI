-- Lua provided by RyzenAPI
-- Game: The Island Combat

-- MAIN APPLICATION
addappid(886310)
addappid(891530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(886311, 1, "7ef3cba221008d0bd86394298fcd1095732167b7a7ee40c863064a983689dcfd")

