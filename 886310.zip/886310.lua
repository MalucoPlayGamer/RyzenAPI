-- Lua provided by RyzenAPI
-- Game: Game: The Island Combat

-- MAIN APPLICATION
addappid(886310)
addappid(891530)
-- Game: addappid(886310)

-- MAIN APP DEPOTS / PACKAGES
addappid(886311, 1, "7ef3cba221008d0bd86394298fcd1095732167b7a7ee40c863064a983689dcfd")
