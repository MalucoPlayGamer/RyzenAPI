-- Lua provided by RyzenAPI
-- Game: Beat Saber - Panic! at the Disco - "Victorious"

-- MAIN APPLICATION
addappid(1167661)
-- Game: addappid(1167661)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167661,0,"c7c59cb4e01df7008e2d584a4867796e5d41aa6df05f34a5a3e5d9c5dc2d5f7f")
