-- Lua provided by RyzenAPI
-- Game: AppID 958320

-- MAIN APPLICATION
addappid(958320)
-- Game: addappid(958320)

-- MAIN APP DEPOTS / PACKAGES
addappid(958321, 1, "3d151bc31b12ee0c5544cb9bc59d8de4e162e093beeceba520c80804dff36fea")
addappid(958322, 1, "53501b99e2a92a32f2b0e2221dad36a6645815ea999065b4bee3aab6a19f6613")
addappid(958323, 1, "fe8fb9c66b6aafeb40c4a184d2bbfc70e98361862d1306167f0f14b5a07cfcf9")
