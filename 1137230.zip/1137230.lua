-- Lua provided by SkyAPI 
-- Game: AppID 1137230
addappid(1137230)
addappid(1137231, 1, "9fd6ca30c5352b94e46d9141096808d3917cdf6e9419d3899f746e864d758690")
