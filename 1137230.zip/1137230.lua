-- Lua provided by RyzenAPI
-- Game: Derby Carmageddon

-- MAIN APPLICATION
addappid(1137230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137231, 1, "9fd6ca30c5352b94e46d9141096808d3917cdf6e9419d3899f746e864d758690")
