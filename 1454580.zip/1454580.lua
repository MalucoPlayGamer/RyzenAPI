-- Lua provided by RyzenAPI
-- Game: Trump VS Covid: Save The World Clicker

-- MAIN APPLICATION
addappid(1454580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454581, 1, "ebe1fc80008258bc3370b6e29f29837141aa71d5d5fe0dd5d1379d7970efd503")
