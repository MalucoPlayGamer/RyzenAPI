-- Lua provided by RyzenAPI
-- Game: addappid(369120)

-- MAIN APPLICATION
addappid(369120)

-- MAIN APP DEPOTS / PACKAGES
addappid(369121, 1, "ac95c8ed64754cb549da2c44df2fa03c49b881dada5c0f0ffe8a6b3fbedd7f57")
