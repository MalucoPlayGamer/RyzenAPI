-- 3839250's Lua and Manifest Created by Hubcap Manifest
-- Soulforge Lost Path
-- Created: July 13, 2026 at 05:49:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3839250) -- Soulforge Lost Path
-- MAIN APP DEPOTS
addappid(3839252, 1, "a59f7b2c4a59610f978e4c6ebe79dc570cc2684b4be11e71ed5320c6f31806d0") -- Depot 3839252
setManifestid(3839252, "1580520332627156033", 775258580)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3839253) -- Depot 3839253 (empty depot)