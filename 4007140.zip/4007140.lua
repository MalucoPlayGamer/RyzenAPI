-- Lua provided by RyzenAPI
-- Game: Ragnarok X: Next Generation

-- MAIN APPLICATION
addappid(4007140)

