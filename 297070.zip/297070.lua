-- Lua provided by SkyAPI 
-- Game: AppID 297070
addappid(297070)
addappid(297071, 1, "76d2ff9d4b7b38e7cfad2dbea21ff7b5ae200003bc291acef3512f8fa532fbad")
addappid(297072, 1, "99067508991296549ea6dc83ab21d46a4bb96515dcbae708baa6d5d097d8343f")
