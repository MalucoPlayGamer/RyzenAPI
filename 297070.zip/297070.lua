-- Lua provided by RyzenAPI
-- Game: Nicolas Eymerich The Inquisitor Book II : The Village

-- MAIN APPLICATION
addappid(297070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(297071, 1, "76d2ff9d4b7b38e7cfad2dbea21ff7b5ae200003bc291acef3512f8fa532fbad")
addappid(297072, 1, "99067508991296549ea6dc83ab21d46a4bb96515dcbae708baa6d5d097d8343f")

