-- Lua provided by RyzenAPI
-- Game: Folie Fatale

-- MAIN APPLICATION
addappid(2734450)
addappid(3035930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2734451, 1, "c28b9b1184f84f960c6dc8513b70af691d2a282a115684bdaafe6522c34c5605")
addappid(2734452, 1, "03cc689087ef2e00212aca38fd0ad443b2ea424c273acd7117490f6e4230bba0")
addappid(2734453, 1, "63c09724e17e7dfbf26c6bcbec0eaf5b33986b860f1128f7db13d25f94a10cf5")
addappid(2734456, 1, "2ef375fec800f27fbde5535ad843dd15d39b24e1b9e5c7af3987672bbaf1ac3e")
addappid(2734457, 1, "735a34adf886a3a09c8e098bfdb959b80d780179de6e483cecf280a44fcf3f07")
