-- Lua provided by RyzenAPI
-- Game: FeedBack

-- MAIN APPLICATION
addappid(3307560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3307561, 1, "c7dafdc3f57a15505b56a72046589ca1034126856a7e98c0a4dbdcb80d989068")

