-- Lua provided by RyzenAPI
-- Game: 594040

-- MAIN APPLICATION
addappid(594040)
-- Game: addappid(594040)

-- MAIN APP DEPOTS / PACKAGES
addappid(594041, 1, "464b7f803ff4e1535a597574552ce85c169bf944d373ba699be9081aa172d8ed")
