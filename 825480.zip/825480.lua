-- Lua provided by RyzenAPI
-- Game: ELDR  LEGACY

-- MAIN APPLICATION
addappid(825480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(825481, 1, "25e246ba354d529689ae26c1f23399c783a37a37366706ac2863a804314d0d07")

