-- Lua provided by RyzenAPI
-- Game: Sonic Generations Demo

-- MAIN APPLICATION
addappid(202290)

-- MAIN APP DEPOTS / PACKAGES
addappid(202291, 1, "736f00df771039fc93d7350480a7c3d70fdcb3d10345b97e0c48e9e742e3a26e")

