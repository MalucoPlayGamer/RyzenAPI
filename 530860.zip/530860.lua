-- Lua provided by RyzenAPI
-- Game: addappid(530860)

-- MAIN APPLICATION
addappid(530860)

-- MAIN APP DEPOTS / PACKAGES
addappid(530861, 1, "ed22a3cebcfee22fb4fc31423f2b24aa23336a7d39ef6b2d86a435127528b06f")
