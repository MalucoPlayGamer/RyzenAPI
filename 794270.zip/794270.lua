-- Lua provided by RyzenAPI
-- Game: Landinar: Into the Void

-- MAIN APPLICATION
addappid(794270)

-- MAIN APP DEPOTS / PACKAGES
addappid(794271, 1, "82bd1b7f96196a89123d831d55bd3721bd575ada4c08f307a865ab5b7e6509c8")
