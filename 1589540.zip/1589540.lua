-- Lua provided by RyzenAPI
-- Game: Game: Whispers in the Dark

-- MAIN APPLICATION
addappid(1589540)
-- Game: addappid(1589540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589541, 1, "20df1b851815ca2c8f86cf83a84cc48bbdc7fad5f769b29ee4a2e73c92af2c93")
