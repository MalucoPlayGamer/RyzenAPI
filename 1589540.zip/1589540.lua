-- Lua provided by RyzenAPI
-- Game: Whispers in the Dark

-- MAIN APPLICATION
addappid(1589540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1589541, 1, "20df1b851815ca2c8f86cf83a84cc48bbdc7fad5f769b29ee4a2e73c92af2c93")

