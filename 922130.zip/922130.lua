-- Lua provided by RyzenAPI
-- Game: Land of Puzzles: Knights

-- MAIN APPLICATION
addappid(922130)
-- Game: addappid(922130)

-- MAIN APP DEPOTS / PACKAGES
addappid(922131, 1, "fb232eef5b0cd282d28543dd164f234e5bc38fe50959a28b0b361d21c5877dbc")
