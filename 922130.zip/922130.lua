-- Lua provided by SkyAPI 
-- Game: Land of Puzzles: Knights
addappid(922130)
addappid(922131, 1, "fb232eef5b0cd282d28543dd164f234e5bc38fe50959a28b0b361d21c5877dbc")
