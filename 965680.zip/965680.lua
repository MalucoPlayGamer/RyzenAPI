-- Lua provided by RyzenAPI
-- Game: 965680

-- MAIN APPLICATION
addappid(965680)
-- Game: addappid(965680)

-- MAIN APP DEPOTS / PACKAGES
addappid(965681, 1, "05685e2eda75d5459cd0ec3a1735e0eed68414c8fb3a56585c6c0938b3102f57")
