-- Lua provided by RyzenAPI
-- Game: Boomerang Fu

-- MAIN APPLICATION
addappid(965680)
addappid(1685690)
addappid(2851830)

-- MAIN APP DEPOTS / PACKAGES
addappid(965681,0,"05685e2eda75d5459cd0ec3a1735e0eed68414c8fb3a56585c6c0938b3102f57")

