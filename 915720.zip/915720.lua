-- Lua provided by RyzenAPI
-- Game: Session Seven

-- MAIN APPLICATION
addappid(915720)

-- MAIN APP DEPOTS / PACKAGES
addappid(915721, 1, "4b2523efb86d886fbda6d963ecbe660c439159b7c8dd1d808450c450c5e9cbd8")
addappid(915722, 1, "e5ec4dc2b5a59d63bce4bc05c15bbe023ef0dcbab5eaa055e0f1b3d45cbdd07e")
addappid(915723, 1, "cc7364973486a8569b3e2516436505c8bba7cfacf537544fa3cf852507d7256c")
addappid(915724, 1, "e9aba412cb1b95eaff234e202a375f2c5e1e542d5ca6cd24f1c8eefc30221943")
addappid(915725, 1, "65ed67b125bbcab8d1f6dd21c190324cf9f85b4e5e92f6e39c8c6aa29c797148")
addappid(915726, 1, "ba95d09d0d1d80b41b92137a2e56562c7268265c343d85fa9ed348a0ca9e511a")
addappid(915727, 1, "44531cffdcc75f0d08cb2806a59e9fde6b94cbb1a27ef52235fcde044b00cd3f")
addappid(915728, 1, "0cb817828e5b721c1ca4cada9a60883c3a8458f3eaf9a3eb22d6e383e9778c3a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
