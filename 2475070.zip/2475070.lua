-- Lua provided by RyzenAPI
-- Game: 帶我去地下城吧！！ - Soundtrack

-- MAIN APPLICATION
addappid(2475070)
-- Game: addappid(2475070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475071, 1, "62047071d975962496816f3eb39c8924ce8439289ae2d4e5eb690d176759f544")
