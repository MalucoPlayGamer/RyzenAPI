-- Lua provided by RyzenAPI
-- Game: AppID 265950

-- MAIN APPLICATION
addappid(265950)

-- MAIN APP DEPOTS / PACKAGES
addappid(265951, 1, "b43c61a0edfc646ab262b5b5316839e00b3b7cb0d26c21a0179773e2193d6744")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(303360)
