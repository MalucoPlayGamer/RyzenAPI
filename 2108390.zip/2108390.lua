-- Lua provided by RyzenAPI
-- Game: AppID 2108390

-- MAIN APPLICATION
addappid(2108390)
-- Game: addappid(2108390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108391, 1, "3aac612122a3436c5f4f2d51aa7c52a203fa862d52a195e9b135665bcd9af564")
