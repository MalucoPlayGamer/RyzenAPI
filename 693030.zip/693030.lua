-- Lua provided by RyzenAPI
-- Game: Neo Angle

-- MAIN APPLICATION
addappid(693030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(693031, 1, "e62a03fbece78707234a50d1f199bc57ba0195bae6fe7759770cff2d20d0c3bb")
addappid(693032, 1, "108c90c07f1fd26148b2aaaf3f9bc48730416739d40fb55a5cf0feeddfe9f7fe")

