-- Lua provided by RyzenAPI
-- Game: Holdfast: Nations At War

-- MAIN APPLICATION
addappid(589290)

-- MAIN APP DEPOTS / PACKAGES
addappid(589291, 1, "a7c1417721600265bba5c83ede099119af0a65f1e2f3b341cc26c5cc7987b7b3")

