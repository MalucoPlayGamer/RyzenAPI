-- Lua provided by RyzenAPI
-- Game: Holdfast: Nations At War

-- MAIN APPLICATION
addappid(589290)
addappid(1243770)
addappid(1324000)
addappid(1415510)
addappid(1489800)
addappid(1906770)
addappid(1906771)
addappid(1960210)
addappid(1960220)
addappid(2107250)
addappid(2692480)
addappid(3320400)
addappid(4172870)
addappid(4172910)
addappid(4434720)
addappid(4678690)
addappid(4678700)
addappid(4678710)

-- MAIN APP DEPOTS / PACKAGES
addappid(589290,0,"58a30bb608730ed424304e2b8ded677da7ae400499e692e37118d61fadbd6e4a")
addappid(589291,0,"a7c1417721600265bba5c83ede099119af0a65f1e2f3b341cc26c5cc7987b7b3")
addappid(1243771,0,"889f1fb0c89f83e6b5940bd922810c574affb5f838d6cd81d85a1f3fcf6b25cb")

