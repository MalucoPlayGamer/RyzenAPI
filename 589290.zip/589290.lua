-- Lua provided by SkyAPI 
-- Game: Holdfast: Nations At War
addappid(589290)
addappid(589291, 1, "a7c1417721600265bba5c83ede099119af0a65f1e2f3b341cc26c5cc7987b7b3")
