-- Lua provided by RyzenAPI
-- Game: addappid(1221250)

-- MAIN APPLICATION
addappid(1221250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221251, 1, "0b426679c1a4645ceffb450c2cc7429f642700e86834de9d7bbfd6fe53f37a25")
addappid(1221252, 1, "4732571eb94fbee50ef9df204c750bbb946eeb5cb145eb5b321c41e1d5b688ee")
addappid(1919990, 0, "4ae1ea22e7ebee3bd17ad72308c12a3789f6baa2020086df032d912b2cf460b6")
