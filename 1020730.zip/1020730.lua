-- Lua provided by RyzenAPI
-- Game: 1020730

-- MAIN APPLICATION
addappid(1020730)
-- Game: addappid(1020730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020731, 1, "c092f29fc19ceb4c28e8c5bd3c4466dc1585ba246ba66c52805c89d4345523a1")
