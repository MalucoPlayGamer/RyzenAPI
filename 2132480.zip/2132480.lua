-- Lua provided by RyzenAPI 
-- Game: Touhou: Fading Illusion
addappid(2132480)
addappid(2132481, 1, "bbbc6e6d4e06bd01daf072c0bfd4da1cbdea370f4bc3901e0fc7e5ac704d3529")
addappid(2132482, 1, "a1f857f83fe76c91c8ca88639c747fa0b6fa31a90761815047df7bbfb14a0fdd")
addappid(2132483, 1, "3afe95412346af0675a4a31607f2a3979bdaf2ca249569973ccde6e1ca6a2182")
