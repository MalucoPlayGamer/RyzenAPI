-- Lua provided by RyzenAPI
-- Game: FATAL FURY: City of the Wolves

-- MAIN APPLICATION
addappid(2492040)
addappid(3141970)
addappid(3141980)
addappid(4070950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492041, 1, "22de4afa6bcad3761cbb58d3ba24b93045b264b33a9bf659ac64b3782375e691")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4071070)
addappid(4741280)
addappid(4741290)
addappid(4741300)
addappid(4741310)
addappid(4741320)
addappid(4741330)
addappid(4741340)
addappid(4741350)
addappid(4741360)
addappid(4741370)
