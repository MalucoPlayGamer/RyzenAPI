-- Lua provided by RyzenAPI
-- Game: Game: Backyard Boxing

-- MAIN APPLICATION
addappid(3422140)
-- Game: addappid(3422140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422141, 1, "41f29104d61026bd576be9863ef7673d0589353effe147caad02d203ecbb4a52")
