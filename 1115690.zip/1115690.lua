-- Lua provided by RyzenAPI 
-- Game: Yes, Your Grace
addappid(1115690)
addappid(1115691, 1, "6399829241662804fe4b082f084e7441c7c193dd49d4040cd665a05361a98304")
addappid(1115692, 1, "5a4dd2396487224d8d8beeee6444a641d65bf2c96994ee071d37f1710ca9c109")
