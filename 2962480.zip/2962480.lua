-- Lua provided by RyzenAPI
-- Game: Isekai Sex Boutique

-- MAIN APPLICATION
addappid(2962480)
-- Game: addappid(2962480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962481, 1, "d9345f83134c749ad77cdb18ce1544ee36df1df3b93db011fdd4e9fa5236874c")
