-- Lua provided by RyzenAPI
-- Game: AppID 2548950

-- MAIN APPLICATION
addappid(2548950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2548951, 1, "92054e544490fe1acd0116f75284f9437eb8096c26cb05d70211613509677c41")
addappid(2548952, 1, "6b1db98616c51b59dc4f4b30646dc69c3440145b400169b2b5b32a60679afd01")
addappid(2548953, 1, "f8f2ea0985848016322cd4eedc1aa27ce26d533f8975b597533bd77f77799ab8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2548980)
