-- Lua provided by RyzenAPI
-- Game: Game: The Witcher 3: Wild Hunt - Blood and Wine Soundtrack

-- MAIN APPLICATION
addappid(1233340)
-- Game: addappid(1233340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233341, 1, "a33c68d0a6b2a32c5ec9e5ed21783cd10e74fea9c71f94069fbee96e580dc9a3")
addappid(1233342, 1, "4a4d2b29d5ca7726300c3bf228bf951bb4d2da5bcde3b206c6417d1f4a5ce40c")
