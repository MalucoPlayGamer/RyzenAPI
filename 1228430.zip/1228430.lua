-- Lua provided by RyzenAPI
-- Game: Pair-a-Site

-- MAIN APPLICATION
addappid(1228430)
-- Game: addappid(1228430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228431, 1, "657c2b807b2efa45617b5918bf856177853be0fee4a44a0e8ed21904a7792457")
