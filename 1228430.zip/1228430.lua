-- Lua provided by RyzenAPI
-- Game: Pair-a-Site

-- MAIN APPLICATION
addappid(1228430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228431, 1, "657c2b807b2efa45617b5918bf856177853be0fee4a44a0e8ed21904a7792457")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
