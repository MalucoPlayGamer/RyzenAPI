-- Lua provided by RyzenAPI
-- Game: Eternal Lore

-- MAIN APPLICATION
addappid(601790)

-- MAIN APP DEPOTS / PACKAGES
addappid(601791, 1, "b0a95cc9b4c1f9738813a288be070a8d61cd7709c7c55be49b9d625925f628cf")
