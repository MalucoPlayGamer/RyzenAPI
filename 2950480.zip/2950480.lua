-- Lua provided by RyzenAPI
-- Game: 2950480

-- MAIN APPLICATION
addappid(2950480)
-- Game: addappid(2950480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2950481, 1, "dfe7c022f2d59f92baeb3f555e3a5e61e80cda4fe4212ea91aa3d8d95d685b01")
