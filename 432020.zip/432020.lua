-- Lua provided by RyzenAPI
-- Game: 432020

-- MAIN APPLICATION
addappid(432020)
-- Game: addappid(432020)

-- MAIN APP DEPOTS / PACKAGES
addappid(432021, 1, "ce85503cd342b000b46e2efe165fc9859c9a5e6bdd5d37f49b597956d287dafc")
