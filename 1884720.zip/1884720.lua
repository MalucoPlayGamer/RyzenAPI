-- Lua provided by RyzenAPI
-- Game: 1884720

-- MAIN APPLICATION
addappid(1884720)
-- Game: addappid(1884720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884721, 1, "262f587ef82891b78394ec273ef7f87c7167c63d148d901bfc055e446dd0c5e6")
