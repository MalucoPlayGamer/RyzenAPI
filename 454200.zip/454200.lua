-- Lua provided by RyzenAPI
-- Game: Neon Hardcorps

-- MAIN APPLICATION
addappid(454200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(454201, 1, "2a9d55cb1c766185b72e8da8c0f4d5fb9e010f0833f00c708b2aef4bba356c77")

