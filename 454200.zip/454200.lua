-- Lua provided by RyzenAPI
-- Game: Neon Hardcorps

-- MAIN APPLICATION
addappid(454200)

-- MAIN APP DEPOTS / PACKAGES
addappid(454201, 1, "2a9d55cb1c766185b72e8da8c0f4d5fb9e010f0833f00c708b2aef4bba356c77")

