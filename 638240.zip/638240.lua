-- Lua provided by RyzenAPI
-- Game: Game: AppID 638240

-- MAIN APPLICATION
addappid(638240)
-- Game: addappid(638240)

-- MAIN APP DEPOTS / PACKAGES
addappid(638241, 1, "47afef02ff07951f3538820783241592544d2f1a250e4cac5c09b64257f4a4eb")
