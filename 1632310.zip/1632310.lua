-- Lua provided by RyzenAPI
-- Game: 1632310

-- MAIN APPLICATION
addappid(1632310)
-- Game: addappid(1632310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632311, 1, "33813efde5174155ee8ed3cb9bbbbe9e8375df1d779a1099c40dcfeac3759c4c")
