-- Lua provided by RyzenAPI
-- Game: Game: Chef's Tail Demo

-- MAIN APPLICATION
addappid(1649140)
-- Game: addappid(1649140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649141, 1, "3bbd3c1d497511667cd9931e984366513a8ae5515f1f51cca662238907f76c2d")
