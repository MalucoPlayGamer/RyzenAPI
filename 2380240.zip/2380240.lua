-- Lua provided by RyzenAPI
-- Game: Sparky Marky: Episode 1

-- MAIN APPLICATION
addappid(2380240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380241, 1, "f514662694447e6fe31299f85ac2f9c83e64e81837de8464d1e05e83ee6c340b")
