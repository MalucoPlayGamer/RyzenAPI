-- Lua provided by RyzenAPI
-- Game: Sparky Marky: Episode 1

-- MAIN APPLICATION
addappid(2380240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2380241, 1, "f514662694447e6fe31299f85ac2f9c83e64e81837de8464d1e05e83ee6c340b")

