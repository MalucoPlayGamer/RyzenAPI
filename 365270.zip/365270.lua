-- Lua provided by RyzenAPI
-- Game: Shadow Hunter

-- MAIN APPLICATION
addappid(365270)
-- Game: addappid(365270)

-- MAIN APP DEPOTS / PACKAGES
addappid(365277,0,"22fe7ff09fc4d4a132fd199ce352a7e9242a3beabbbdf8370885c869906dece9")
