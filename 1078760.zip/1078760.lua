-- Lua provided by RyzenAPI
-- Game: Motorcycle Mechanic Simulator 2021

-- MAIN APPLICATION
addappid(1078760)
addappid(2139810)
addappid(2246270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078761, 1, "19540c6e349a1a7ada84247e525c19397874db503244bf7956e4167e1e9c0b74")

