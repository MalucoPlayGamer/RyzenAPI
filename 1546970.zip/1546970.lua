-- Lua provided by RyzenAPI
-- Game: Grand Theft Auto III – The Definitive Edition

-- MAIN APPLICATION
addappid(1546970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546971, 1, "d6dfa8078e89488b58be9d37f6b0e04acd6535686db4037c9036f3ef6b552b84")
addappid(1899671, 0, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
