-- Lua provided by RyzenAPI
-- Game: Elven Love

-- MAIN APPLICATION
addappid(798590)

-- MAIN APP DEPOTS / PACKAGES
addappid(798591, 1, "f0126a29562efe8189985abfc5be231aa37e5bcb4dc41b1fc3d15ab0386f6361")

