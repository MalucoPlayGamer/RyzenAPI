-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV

-- MAIN APPLICATION
addappid(837510)
-- Game: addappid(837510)

-- MAIN APP DEPOTS / PACKAGES
addappid(837512,0,"31b95e27dd7bd4bc564c67f9de8b278a309430afe7f353634d7911a19d2f69f0")
addappid(837513,0,"bb6f61aa7254b90e546e44285095ee66cb27fa5c6cf3445f41385a6ab34e8329")
