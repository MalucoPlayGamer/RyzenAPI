-- Lua provided by RyzenAPI
-- Game: Fetish Locator Week One

-- MAIN APPLICATION
addappid(1360980)
-- Game: addappid(1360980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360982,0,"460801e0eb4555d200b5e6cea7b9569995b5df4fc71923050f5c5ce90bc886f0")
addappid(1639460,0,"338d1b951d40117ada85b9e898949fc550e295220b109f8ae0897c723f902ff8")
