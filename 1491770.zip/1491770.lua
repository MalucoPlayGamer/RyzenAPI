-- Lua provided by RyzenAPI
-- Game: addappid(1491770)

-- MAIN APPLICATION
addappid(1491770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491771, 1, "9c7565df9c2c6363c7fd3236f1bdc43486cd24ee4298e212ee06f118c4691e70")
