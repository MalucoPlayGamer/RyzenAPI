-- Lua provided by RyzenAPI
-- Game: Village Bus Driver Simulator

-- MAIN APPLICATION
addappid(1159510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1159511, 1, "2229ac25c47ca8a6f124598035581947a76adba349cbc906624262eba8220668")

