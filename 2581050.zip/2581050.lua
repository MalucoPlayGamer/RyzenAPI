-- Lua provided by RyzenAPI
-- Game: KAMITSUBAKI CITY ENSEMBLE

-- MAIN APPLICATION
addappid(2581050)
addappid(3063310)
addappid(3063320)
addappid(3063330)
addappid(3063340)
addappid(3063350)
addappid(3063360)
addappid(3063560)
addappid(3063570)
addappid(3063580)
addappid(3063590)
addappid(3466910)
addappid(3466920)
addappid(3511140)
addappid(3511150)
addappid(3511160)
addappid(3511170)
addappid(3511180)
addappid(3511190)
addappid(3511200)
addappid(3809010)
addappid(3813170)
addappid(3813180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581051, 1, "72c4e9e40b3dd0b48fb2712bf570f6390358e03f8bd98d8e8bed1a5f7bec4f2c")

