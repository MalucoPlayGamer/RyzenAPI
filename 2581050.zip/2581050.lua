-- Lua provided by RyzenAPI
-- Game: addappid(2581050)

-- MAIN APPLICATION
addappid(2581050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581051, 1, "72c4e9e40b3dd0b48fb2712bf570f6390358e03f8bd98d8e8bed1a5f7bec4f2c")
