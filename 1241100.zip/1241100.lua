-- Lua provided by RyzenAPI 
-- Game: POLYGON
addappid(1241100)
addappid(1241101, 1, "28d47712c47d6099f9aad69786fd63a404e3acb14b71e25a143fd538020954e7")
