-- Lua provided by RyzenAPI
-- Game: MEMOLOGY: War of Memes

-- MAIN APPLICATION
addappid(3108010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3108011, 1, "0fe74e43a36d1112bce919b3f6886e73929c5ba1d3e0c1b71cdd818793059974")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
