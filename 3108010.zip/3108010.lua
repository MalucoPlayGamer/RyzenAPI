-- Lua provided by RyzenAPI
-- Game: 3108010

-- MAIN APPLICATION
addappid(3108010)
-- Game: addappid(3108010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3108011, 1, "0fe74e43a36d1112bce919b3f6886e73929c5ba1d3e0c1b71cdd818793059974")
