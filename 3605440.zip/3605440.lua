-- Lua provided by SkyAPI 
-- Game: FURRY TITS
addappid(3605440)
addappid(3605441, 1, "f3b6395a606d30a52ec9bba3db1ab1e6bde37f0a729e2b9e56b8cded64b1b59f")
