-- Lua provided by RyzenAPI
-- Game: FURRY TITS

-- MAIN APPLICATION
addappid(3605440)
-- Game: addappid(3605440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3605441, 1, "f3b6395a606d30a52ec9bba3db1ab1e6bde37f0a729e2b9e56b8cded64b1b59f")
