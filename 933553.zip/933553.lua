-- Lua provided by RyzenAPI
-- Game: addappid(933553)

-- MAIN APPLICATION
addappid(933553)

-- MAIN APP DEPOTS / PACKAGES
addappid(933553,0,"5b18218da49f2c504047d4aef0904c9bf3770e3fd901acb82dd145e542035187")
