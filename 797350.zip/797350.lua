-- Lua provided by RyzenAPI
-- Game: Fantasy Mosaics 25: Wedding Ceremony

-- MAIN APPLICATION
addappid(797350)

-- MAIN APP DEPOTS / PACKAGES
addappid(797351,0,"29e798362f509bb61015a4f22715c5882651d9abc7a401edd373f3ac2a7c72e2")

