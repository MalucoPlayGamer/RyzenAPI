-- Lua provided by RyzenAPI
-- Game: AppID 547310

-- MAIN APPLICATION
addappid(547310)

-- MAIN APP DEPOTS / PACKAGES
addappid(547311, 1, "1af7d99c2cca1dc8285256c4d896da31c6dd8fd9abb05f662b81e95aac0c802b")

