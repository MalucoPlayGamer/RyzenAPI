-- Lua provided by RyzenAPI
-- Game: That's Mahjong!

-- MAIN APPLICATION
addappid(547310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(547311, 1, "1af7d99c2cca1dc8285256c4d896da31c6dd8fd9abb05f662b81e95aac0c802b")

