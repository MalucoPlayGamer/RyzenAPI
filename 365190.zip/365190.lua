-- Lua provided by RyzenAPI
-- Game: 365190

-- MAIN APPLICATION
addappid(365190)
-- Game: addappid(365190)

-- MAIN APP DEPOTS / PACKAGES
addappid(365191, 1, "764b58fa76f4f094dd8332f0213d874b894a284ef610f4cff7fc77b316d18124")
