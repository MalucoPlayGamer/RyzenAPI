-- Lua provided by RyzenAPI
-- Game: 2754310

-- MAIN APPLICATION
addappid(2754310)
-- Game: addappid(2754310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754310,0,"154739a9e32f9ec03185c449ae473705d8eed4b0f0e21c45c15ce077a022d01c")
