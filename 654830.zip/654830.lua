-- Lua provided by RyzenAPI
-- Game: Athopiu - The Final Rebirth of Hopeless Incarnate

-- MAIN APPLICATION
addappid(654830)

-- MAIN APP DEPOTS / PACKAGES
addappid(654831, 1, "ba8bca75e362852520dbdd5dc0783089ca52c9dd0176dd5a8dd781c1726e4e27")
addappid(658370, 0, "24657457e36ac6a21a980ed6bfa2bab88387c573a19e8d2e201fc02847f9a9e8")
addappid(658380, 0, "f2abd2c4ae0b7d106b5c8e352e7c9e70be309cbebb12f6780cff542fe99fdc2e")
addappid(658381, 0, "15d4554ef872fe30448d4d1f07fd40dc7f0820c3ac472acb6a9586f519e4b0f8")
addappid(658382, 0, "0119ea7cfafaea6259fdf665a9d985ca4e10a7077bfff42d4e01dd2686225c2d")
addappid(658383, 0, "72c76e4d2e19ebd0cc33be35a3c4c094267b9d1dcfe59ea3b569e9dd7dadfb41")
addappid(658384, 0, "a7077cc45421ffd112ae586637244e5976f77b8e0e7a93856a26a2d9e4ff9fc3")
addappid(658385, 0, "b80a1946ea8af3e778102561f96924b9f886ccdc72325d861645430c9af19f77")
addappid(658386, 0, "4a4485cdd58a969bbca4e1f1094ac9a31569fcf3fb3183411590748d860d7ec7")
