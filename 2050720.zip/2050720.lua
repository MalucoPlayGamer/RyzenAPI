-- Lua provided by RyzenAPI
-- Game: addappid(2050720)

-- MAIN APPLICATION
addappid(2050720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050722,0,"99c94048ecd273ae621c4f3e1dd8b52610b528dd917dffdf4cabc821641b7308")
