-- Lua provided by RyzenAPI
-- Game: Game: AppID 732090

-- MAIN APPLICATION
addappid(732090)
-- Game: addappid(732090)

-- MAIN APP DEPOTS / PACKAGES
addappid(732091, 1, "bf7fb96d4f4617b92d814d144852aa25fb729014dc9843037f9605d007d5b7a6")
