-- Lua provided by RyzenAPI
-- Game: Oodlescape - The Apocalypse

-- MAIN APPLICATION
addappid(587560)

-- MAIN APP DEPOTS / PACKAGES
addappid(587561,0,"612bc2b0a03285adc4aad0411e39fe2dc7f486abe8beff8cb8202fb3f5c28dc2")

