-- Lua provided by SkyAPI 
-- Game: KAOS SurVival
addappid(1947280)
addappid(1947281, 1, "b9988ad01408b7e396e1e6d975a95b3b01f753a5e3c5c13a79f98d500918cb81")
