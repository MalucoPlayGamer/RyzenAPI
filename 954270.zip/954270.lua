-- Lua provided by RyzenAPI
-- Game: Game: AppID 954270

-- MAIN APPLICATION
addappid(954270)
-- Game: addappid(954270)

-- MAIN APP DEPOTS / PACKAGES
addappid(954271, 1, "452ef0ab53bffd10683370dd67bdc15910b8c6fc164580d6149a70ff412a3d0c")
