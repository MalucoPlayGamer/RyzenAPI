-- Lua provided by SkyAPI 
-- Game: AppID 954270
addappid(954270)
addappid(954271, 1, "452ef0ab53bffd10683370dd67bdc15910b8c6fc164580d6149a70ff412a3d0c")
