-- Lua provided by RyzenAPI
-- Game: AppID 954270

-- MAIN APPLICATION
addappid(954270)
addappid(985630)
addappid(1140550)
addappid(1140551)
addappid(1140552)
addappid(1140553)
addappid(1160760)
addappid(1181950)
addappid(1186140)
addappid(1201180)
addappid(1230040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(954271, 1, "452ef0ab53bffd10683370dd67bdc15910b8c6fc164580d6149a70ff412a3d0c")

