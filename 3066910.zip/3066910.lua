-- Lua provided by RyzenAPI
-- Game: SEX Massage 2 🔞

-- MAIN APPLICATION
addappid(3066910)
-- Game: addappid(3066910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3066911, 1, "3f143da11f9026c5e617a58bb378a9efc344d746f97d2470c199e4672ff759ae")
