-- Lua provided by RyzenAPI
-- Game: Shoujo City

-- MAIN APPLICATION
addappid(764230)

-- MAIN APP DEPOTS / PACKAGES
addappid(764231, 1, "f0c70efe9c46592f764f79ec27c81e4dfd1d9568831d504a5f9d8605794a8a12")
addappid(764232, 1, "ea331205dce6b20a3bdc1578e0ae7050c40fbec8584c22a3968489e780b7e18c")

