-- Lua provided by RyzenAPI 
-- Game: Planum
addappid(839730)
addappid(839731, 1, "21b354de51711e35987407db94a954ed24acf90f3eee498338b0ad76e25a3b62")
addappid(857260, 0, "404a1bfb627b533093792fc19b2f6b9d8b3d7fee2ad43bc33d22a7801234c382")
