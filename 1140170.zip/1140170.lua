-- Lua provided by RyzenAPI
-- Game: Arietta of Spirits

-- MAIN APPLICATION
addappid(1140170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140171, 1, "f5826c0755aa9634446731581b1aafea78c378d16ca248fbffe7e9718efe83c7")

