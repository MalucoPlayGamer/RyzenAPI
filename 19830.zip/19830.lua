-- Lua provided by RyzenAPI
-- Game: Tom Clancy's Rainbow Six 3: Gold Edition

-- MAIN APPLICATION
addappid(19830)

-- MAIN APP DEPOTS / PACKAGES
addappid(19831, 1, "db5e6f12fe170796a3a071c138e7b3de235d4b53e6858186d74b6d91d11f9699")

