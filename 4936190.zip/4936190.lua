-- Lua provided by RyzenAPI
-- Game: The Outskirts

-- MAIN APPLICATION
addappid(4936190) -- The Outskirts

-- MAIN APP DEPOTS / PACKAGES
addappid(4936191, 1, "52f3492c06eb6ae14eecabcafaa16379a5b51e3af63d4e1a3db4c00d699b341b") -- Depot 4936191

