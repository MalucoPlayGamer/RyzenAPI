-- 4936190's Lua and Manifest Created by Hubcap Manifest
-- The Outskirts
-- Created: August 04, 2026 at 09:25:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4936190) -- The Outskirts
-- MAIN APP DEPOTS
addappid(4936191, 1, "52f3492c06eb6ae14eecabcafaa16379a5b51e3af63d4e1a3db4c00d699b341b") -- Depot 4936191
setManifestid(4936191, "2900366577976986303", 161038848)