-- Lua provided by RyzenAPI
-- Game: After Life - Story of a Father

-- MAIN APPLICATION
addappid(550240)

-- MAIN APP DEPOTS / PACKAGES
addappid(550241, 1, "622a8fed5c5b234a841b72562488909c6e4bfc786105b9d3793665ce47840770")
addappid(561720, 0, "88a46f96495f527abe4154eb58ba035e4d0ebe8a9affa01d2b878e5d4edfa6a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
