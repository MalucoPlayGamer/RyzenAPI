-- Lua provided by RyzenAPI
-- Game: Game: Solitaire Royale

-- MAIN APPLICATION
addappid(530720)
-- Game: addappid(530720)

-- MAIN APP DEPOTS / PACKAGES
addappid(530721, 1, "ddaa512e3c3c5095adb0970124277c53d5ef67c21894d21984464b8460eb48a1")
