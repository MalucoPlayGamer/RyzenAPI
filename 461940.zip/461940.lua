-- Lua provided by RyzenAPI
-- Game: PlanCon: Space Conflict

-- MAIN APPLICATION
addappid(461940)

-- MAIN APP DEPOTS / PACKAGES
addappid(461941, 1, "1264b52dfea66c8813b4032f70e6315ee4fed5b12dba258f94a7bb2770aeab91")

