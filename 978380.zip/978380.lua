-- Lua provided by SkyAPI 
-- Game: Spinheads
addappid(978380)
addappid(978381, 1, "00b51d6d46032eec5e062a9afe287ce653229b67b6c8808c4268ceb82d194e4c")
addappid(978382, 1, "5890fe602b4474f8a909bbd74e2363ee84707e43e0cb921d7a9c90f5e2df9ac9")
