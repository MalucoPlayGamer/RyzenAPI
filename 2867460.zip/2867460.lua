-- Lua provided by SkyAPI 
-- Game: NTR Office
addappid(2867460)
addappid(2867461, 1, "3ba7fbd2034a8a11bc6e363a35b7170963943c3804bf743bf06eb5360d19c2ac")
