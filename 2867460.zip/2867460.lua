-- Lua provided by RyzenAPI
-- Game: NTR Office

-- MAIN APPLICATION
addappid(2867460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2867461, 1, "3ba7fbd2034a8a11bc6e363a35b7170963943c3804bf743bf06eb5360d19c2ac")

