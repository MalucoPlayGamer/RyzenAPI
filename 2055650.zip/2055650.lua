-- Lua provided by RyzenAPI
-- Game: Rolling Rush

-- MAIN APPLICATION
addappid(2055650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2055651, 1, "612b695ff8826ec3985b41d78c3f6bfb7fda76cd4b70ed113a27ee4180f6a82e")

