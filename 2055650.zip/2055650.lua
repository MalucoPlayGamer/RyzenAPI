-- Lua provided by RyzenAPI
-- Game: Rolling Rush

-- MAIN APPLICATION
addappid(2055650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055651, 1, "612b695ff8826ec3985b41d78c3f6bfb7fda76cd4b70ed113a27ee4180f6a82e")
