-- Lua provided by RyzenAPI
-- Game: Lucky Lord: The Coin Pusher of Fate

-- MAIN APPLICATION
addappid(3408410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408411, 1, "569df46648e5ccc8eaa835bcf56ef80b85f9ef662bd341f56b35354e6b977cec")
