-- Lua provided by RyzenAPI
-- Game: Asterigos: Curse of the Stars

-- MAIN APPLICATION
addappid(1731070)
addappid(1783160)
addappid(1969900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731071, 1, "b5f1f9079d56167c91da97c97d380f6f8db39878ff0552b1ef9be52510c7909b")
addappid(2119800, 0, "c933491b1295cab6052a9ba48b9b5b20562921f0b7701a8a028eddd7117e5007")
