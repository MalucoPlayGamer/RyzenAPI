-- Lua provided by RyzenAPI
-- Game: Asterigos: Curse of the Stars

-- MAIN APPLICATION
addappid(1731070)
addappid(1783160)
addappid(1969900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731071, 1, "b5f1f9079d56167c91da97c97d380f6f8db39878ff0552b1ef9be52510c7909b")
addappid(2119800, 0, "c933491b1295cab6052a9ba48b9b5b20562921f0b7701a8a028eddd7117e5007")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
