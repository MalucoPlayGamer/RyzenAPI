-- Lua provided by RyzenAPI
-- Game: Game: Zombie Arise

-- MAIN APPLICATION
addappid(3908660)
-- Game: addappid(3908660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3908661, 1, "2566ec5e0241b2a2e9da5d83932ea152648bbf692026f42cda23f521efb657f7")
