-- Lua provided by RyzenAPI
-- Game: Game: A Few Days With : Cassandra

-- MAIN APPLICATION
addappid(2932880)
-- Game: addappid(2932880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932881, 1, "9b829b73529bb9692db12c0f27d7e6ef4fcc0477152482dcb11edd3492512279")
