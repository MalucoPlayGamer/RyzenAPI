-- Lua provided by RyzenAPI
-- Game: Jonas Willy Online

-- MAIN APPLICATION
addappid(1350280)
-- Game: addappid(1350280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350281, 1, "152f110bd55644cb0c520a87ab57b4946308371e690b3ab4f648c43686597ed9")
