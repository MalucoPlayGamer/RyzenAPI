-- Lua provided by RyzenAPI
-- Game: Backrooms: What's Next

-- MAIN APPLICATION
addappid(3381170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381171, 1, "5fdc307e852ea2d176f88f0e597219ba1121205459be19d6bccc2b5615db4f11")
