-- Lua provided by RyzenAPI
-- Game: 897630

-- MAIN APPLICATION
addappid(897630)
-- Game: addappid(897630)

-- MAIN APP DEPOTS / PACKAGES
addappid(897631, 1, "c528bc56e3edf3f515d2db0e157c0464b9b1790321d6637d39234e2ed4e98d84")
