-- Lua provided by RyzenAPI
-- Game: Death Fungeon

-- MAIN APPLICATION
addappid(897630)

-- MAIN APP DEPOTS / PACKAGES
addappid(897631, 1, "c528bc56e3edf3f515d2db0e157c0464b9b1790321d6637d39234e2ed4e98d84")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
