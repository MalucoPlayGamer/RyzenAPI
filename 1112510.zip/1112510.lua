-- Lua provided by RyzenAPI
-- Game: addappid(1112510)

-- MAIN APPLICATION
addappid(1112510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112511, 1, "ed24dfc64a918873b5cfa850ac032535e643c3833116ef761f4fda4f26e7e1b1")
