-- Lua provided by RyzenAPI
-- Game: バグダス - デバッガー検定 -

-- MAIN APPLICATION
addappid(1002360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002361, 1, "b6f2264974d147260531a67b027340a0f9c24a097acda372e6d1b85de3a4c01d")

