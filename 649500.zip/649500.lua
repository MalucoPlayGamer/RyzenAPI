-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(649500)
-- Game: addappid(649500)

-- MAIN APP DEPOTS / PACKAGES
addappid(621301,0,"618d7c5275545e05c7ab7271ea2cff95a123a4694102fed060c5716b48c469fc")
addappid(621302,0,"61dad3074b32302bff26cb848fddf5e8f6552a03c122613260b717f5a5427aba")
addappid(621303,0,"bb290d752454c3f23c0edbcf82180f1b68255dc9b7bc1ee8f751af96f7779496")
addappid(621304,0,"8f0178e85075bd065cca458087214ae13d03ffac442843e31cea96b1ffcd738c")
