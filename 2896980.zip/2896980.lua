-- Lua provided by RyzenAPI
-- Game: 2896980

-- MAIN APPLICATION
addappid(2896980)
-- Game: addappid(2896980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2896981, 1, "a936ee28764b16caaba05cf9c578c9f55516f5731be25ec1f812e473b458cb29")
