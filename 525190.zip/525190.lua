-- Lua provided by RyzenAPI
-- Game: The Construct

-- MAIN APPLICATION
addappid(525190)
-- Game: addappid(525190)

-- MAIN APP DEPOTS / PACKAGES
addappid(525191, 1, "b1a08d62c5cbcea9d3c93ed657d7ecc9302a9be1bb962f440101a2658a2adf1b")
