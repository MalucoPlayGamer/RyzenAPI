-- Lua provided by RyzenAPI 
-- Game: Only Down: Gravitation Up
addappid(3343850)
addappid(3343851, 1, "7e1ca722cc26959ec70a69a90ede769646897a07234dde06a980c351994b28e2")
