-- Lua provided by RyzenAPI
-- Game: Only Down: Gravitation Up

-- MAIN APPLICATION
addappid(3343850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343851, 1, "7e1ca722cc26959ec70a69a90ede769646897a07234dde06a980c351994b28e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
