-- Lua provided by RyzenAPI
-- Game: 1568070

-- MAIN APPLICATION
addappid(1568070)
-- Game: addappid(1568070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568071, 1, "14b68e3fafb0aacc00d0d07eed9100aff2496dead30f735cee3a1ed25b37b2ab")
