-- Lua provided by RyzenAPI
-- Game: 1218320

-- MAIN APPLICATION
addappid(1218320)
-- Game: addappid(1218320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218321, 1, "a18fdb8069f67f13202c083bb1565baa8ce89c241e81f0fac0a4a19b92dc5815")
