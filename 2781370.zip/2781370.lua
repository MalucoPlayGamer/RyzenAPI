-- Lua provided by RyzenAPI
-- Game: EXIT KUN

-- MAIN APPLICATION
addappid(2781370)
addappid(2836780)
addappid(2858720)
addappid(2915580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(2781371, 1, "78b63094c32c4efd9282cf97ca349e6b9fd044ab2d765a2d397165caf73dd87c")
addappid(2781372, 1, "59d6481aa2cf6fc811911183cb5a214e0147ea9593c5bf77d1ab9b6fb09a13e2")

