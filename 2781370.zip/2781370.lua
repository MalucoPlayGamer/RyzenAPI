-- Lua provided by RyzenAPI 
-- Game: EXIT KUN
addappid(2781370)
addappid(2781371, 1, "78b63094c32c4efd9282cf97ca349e6b9fd044ab2d765a2d397165caf73dd87c")
addappid(2781372, 1, "59d6481aa2cf6fc811911183cb5a214e0147ea9593c5bf77d1ab9b6fb09a13e2")
