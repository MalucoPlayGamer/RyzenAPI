-- Lua provided by RyzenAPI 
-- Game: The MISSING Demo
addappid(956840)
addappid(956841, 1, "5d1c1764504200d573bd3ed06848d7b6edc636d021c9eecc784396ad08f87708")
