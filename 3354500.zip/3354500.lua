-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3354500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354500,0,"6f73df8bbc26936f5f9ee9d3bf031b9cb96617d8f8004038c2d04c9f8b01b808")

