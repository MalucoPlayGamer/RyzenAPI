-- Lua provided by RyzenAPI
-- Game: Deathtrap

-- MAIN APPLICATION
addappid(310510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(310511, 1, "3588965a77d5a97aec9e785ca8aae9c47d597c072b1c776b759867af2affcbef")
addappid(310512, 1, "049eef765b64011176c2f48407611f6088da4b632ba965135894966ea710f3e4")

