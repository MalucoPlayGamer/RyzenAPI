-- Lua provided by RyzenAPI
-- Game: Ball of Light

-- MAIN APPLICATION
addappid(539350)

-- MAIN APP DEPOTS / PACKAGES
addappid(539351, 1, "571e6b2f0f7bea100e794eb8abe1c856c6dc9795299e9dc63f85e9f6a6b63f58")
