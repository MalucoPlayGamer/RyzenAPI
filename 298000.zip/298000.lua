-- Lua provided by RyzenAPI
-- Game: MotoGP 14 Demo

-- MAIN APPLICATION
addappid(298000)

-- MAIN APP DEPOTS / PACKAGES
addappid(298001, 1, "63cf9d65ebb00630f32f23d611c8b8c2aa175586eed36fd0d640b8b3641e66b2")

