-- Lua provided by RyzenAPI
-- Game: Space Dragons

-- MAIN APPLICATION
addappid(1862530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862531, 1, "9a6f083a2c3dd00ae60c30427c51532c6be54e5ff875c5ad1b1acdbad1f6a070")

