-- Lua provided by RyzenAPI
-- Game: Game: AppID 605990

-- MAIN APPLICATION
addappid(605990)
-- Game: addappid(605990)

-- MAIN APP DEPOTS / PACKAGES
addappid(605991, 1, "bb553f05ac7ef865809d5aacacdbcd24b7df089dea8d73f12d6a3db79fe1fb7d")
addappid(605992, 1, "43cf94633bbecd20b186c0cd1fdae23e45568a3d49cdf73020df6e1924f85fda")
addappid(628240, 0, "d88a319000f4d20a30b5732bdd3d5bf0d6c0b6577b2b90908602de439a29ca21")
