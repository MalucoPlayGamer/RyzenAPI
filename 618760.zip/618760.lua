-- Lua provided by RyzenAPI
-- Game: IronBorn

-- MAIN APPLICATION
addappid(618760)

-- MAIN APP DEPOTS / PACKAGES
addappid(618761, 1, "cefd82de146d48464c42efd88ee93f3fec20de74f993238748de067d4eede499")
