-- Lua provided by RyzenAPI
-- Game: Atelier Marie Remake - Accessory "25 Glasses"

-- MAIN APPLICATION
addappid(2261011)
-- Game: addappid(2261011)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261011,0,"329240972cb6c6caaaf644bfc469081d82224728f74df7545915ff82f48d215b")
