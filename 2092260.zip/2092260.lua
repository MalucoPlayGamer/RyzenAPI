-- Lua provided by RyzenAPI
-- Game: Game: AppID 2092260

-- MAIN APPLICATION
addappid(2092260)
-- Game: addappid(2092260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092261, 1, "01bb80ac3d8cf6b6c7e6ffa614d88d75c9c49c376f467fdc6572b36e41ff0ca2")
addappid(2092263, 1, "af8b115fe3879c6ae1fff8b09a370b47a6093feffcc6a1aec51d2b7ae4cbce94")
