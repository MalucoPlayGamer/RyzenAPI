-- Lua provided by RyzenAPI
-- Game: Flynguin Station

-- MAIN APPLICATION
addappid(969250)

-- MAIN APP DEPOTS / PACKAGES
addappid(969251, 1, "b54ecd34dd57314d9833480d378cd128d51ae0538260d78a67ef0b9aa80516a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
