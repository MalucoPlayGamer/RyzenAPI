-- Lua provided by RyzenAPI
-- Game: 969250

-- MAIN APPLICATION
addappid(969250)
-- Game: addappid(969250)

-- MAIN APP DEPOTS / PACKAGES
addappid(969251, 1, "b54ecd34dd57314d9833480d378cd128d51ae0538260d78a67ef0b9aa80516a0")
