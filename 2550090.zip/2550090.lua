-- Lua provided by RyzenAPI
-- Game: RplGen Studio

-- MAIN APPLICATION
addappid(2550090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550091, 1, "6b7e76ae4d7c8bbbad968483ef1a5be22d4eca081e90c4479ce93886d713630d")
