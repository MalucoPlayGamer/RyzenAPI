-- Lua provided by RyzenAPI
-- Game: 2782400

-- MAIN APPLICATION
addappid(2782400)
-- Game: addappid(2782400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782401, 1, "56f86300566f6c48263aecd227efe6d840df45f3e7c867ec597bc2f4e73fa301")
