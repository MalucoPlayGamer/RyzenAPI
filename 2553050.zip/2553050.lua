-- Lua provided by RyzenAPI
-- Game: Estate Agent Simulator

-- MAIN APPLICATION
addappid(2553050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553051, 1, "ce0e5601e847f30d4c35bb1fd2b49ec2d044832e10a4fb0f363e2287be4df8e2")
