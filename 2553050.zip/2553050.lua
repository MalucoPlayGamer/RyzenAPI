-- Lua provided by SkyAPI 
-- Game: Estate Agent Simulator
addappid(2553050)
addappid(2553051, 1, "ce0e5601e847f30d4c35bb1fd2b49ec2d044832e10a4fb0f363e2287be4df8e2")
