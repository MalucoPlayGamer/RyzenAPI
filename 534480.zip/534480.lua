-- Lua provided by RyzenAPI 
-- Game: AppID 534480
addappid(534480)
addappid(534481, 1, "ef564bbacd2f1182007f06e7e2246879f1649e666c08ca077b33ee5a4aba64e9")
