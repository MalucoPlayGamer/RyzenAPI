-- Lua provided by RyzenAPI
-- Game: addappid(1222400)

-- MAIN APPLICATION
addappid(1222400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222401, 1, "1cdec400beb5cc02dce63939b5c5a55407af7df749d29a25ff614b9390d9b588")
