-- Lua provided by RyzenAPI
-- Game: Outbreak: Contagious Memories

-- MAIN APPLICATION
addappid(1772950)
-- Game: addappid(1772950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772951, 1, "86b993ff1d8c7764e8fa3d437babf6d4513b81806b50ff8905eb8ec57aa99f65")
