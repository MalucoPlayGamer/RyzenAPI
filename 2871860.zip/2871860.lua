-- Lua provided by RyzenAPI
-- Game: Watch Your Ass

-- MAIN APPLICATION
addappid(2871860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871861,0,"fcc9a0bcb35304e772814790d163789be5f9c3aa486511e47f95fec0e2ebeccd")

