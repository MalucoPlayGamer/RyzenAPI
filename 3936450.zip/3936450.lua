-- 3936450's Lua and Manifest Created by Hubcap Manifest
-- Cult of Shadows
-- Created: August 27, 2026 at 06:29:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3936450, 1, "65adf7fdfcd2575ceacd716ce255f06b1ea7e14d0b4b3d843b68542b77075a2e") -- Cult of Shadows
-- MAIN APP DEPOTS
addappid(3936451, 1, "c0572f89bddd00ee57fd1b49298c3ce4159b1d2cdad351bf2a8e1a7c95b153a3") -- Depot 3936451
setManifestid(3936451, "1631682180589150071", 6066163305)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)