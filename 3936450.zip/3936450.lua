-- Lua provided by RyzenAPI
-- Game: Cult of Shadows

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3936450, 1, "65adf7fdfcd2575ceacd716ce255f06b1ea7e14d0b4b3d843b68542b77075a2e") -- Cult of Shadows
addappid(3936451, 1, "c0572f89bddd00ee57fd1b49298c3ce4159b1d2cdad351bf2a8e1a7c95b153a3") -- Depot 3936451

