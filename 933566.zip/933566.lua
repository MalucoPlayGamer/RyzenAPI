-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Challenge Modes "Rampage" and "Bridge Melee"

-- MAIN APPLICATION
addappid(933566)
-- Game: addappid(933566)

-- MAIN APP DEPOTS / PACKAGES
addappid(933566,0,"4cdc3a5347ae49435e299e2bcd1cd349cfea31d15a5497f82b76ec845d7639cf")
