-- Lua provided by RyzenAPI
-- Game: Game: Tank Frenzy Survivor

-- MAIN APPLICATION
addappid(3331640)
-- Game: addappid(3331640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331641, 1, "d390e07c9a3d3ad5aaa7beeec19a61fdb24c6f6477207af046c193695d34869c")
