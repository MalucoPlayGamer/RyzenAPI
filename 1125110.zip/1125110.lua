-- Lua provided by RyzenAPI
-- Game: Game: AppID 1125110

-- MAIN APPLICATION
addappid(1125110)
-- Game: addappid(1125110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125111, 1, "6c28fd5ebca4cf98dab90fc493487acc446d159405c34ade8b47658444dad5cc")
