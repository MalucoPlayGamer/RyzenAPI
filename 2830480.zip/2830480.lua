-- Lua provided by RyzenAPI
-- Game: Gentoo Rescue

-- MAIN APPLICATION
addappid(2830480)
-- Game: addappid(2830480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830481, 1, "1d801f64ac7a36e4c48d28a3f2f2535b4638b9e454da650b81aa6c14ae7648a3")
