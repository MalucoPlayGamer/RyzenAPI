-- Lua provided by RyzenAPI
-- Game: addappid(314460)

-- MAIN APPLICATION
addappid(314460)

-- MAIN APP DEPOTS / PACKAGES
addappid(314461, 1, "0e90f0fac7e2c24e1c3dfbe5ea5a9926e7d24d295588261c5e6b458921053f96")
