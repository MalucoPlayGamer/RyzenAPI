-- Lua provided by RyzenAPI
-- Game: SPACE RABBIT

-- MAIN APPLICATION
addappid(3748400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3748401, 1, "c3dce0af2267cde190486f5ae97d69ccf1ec665f27dca956a02f51ebf03355a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
