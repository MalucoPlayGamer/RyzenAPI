-- Lua provided by SkyAPI 
-- Game: SPACE RABBIT
addappid(3748400)
addappid(3748401, 1, "c3dce0af2267cde190486f5ae97d69ccf1ec665f27dca956a02f51ebf03355a6")
