-- Lua provided by RyzenAPI
-- Game: Pretty Girls Mahjong Solitaire [GREEN]

-- MAIN APPLICATION
addappid(1432670)
-- Game: addappid(1432670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432671, 1, "31428e7b6eb7095886b926e0d3015f6f259a0fa19dc0292550defc6a93ba5630")
