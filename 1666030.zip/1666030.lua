-- Lua provided by RyzenAPI
-- Game: Azimech

-- MAIN APPLICATION
addappid(1666030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666031, 1, "ce1f2204f0652c9443297007bbc515573ecc05a7f22930548f72e48507d2d630")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
