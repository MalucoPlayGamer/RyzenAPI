-- Lua provided by RyzenAPI
-- Game: If Found

-- MAIN APPLICATION
addappid(1041920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041921, 1, "df4fdc3df889c327f5d7b4715a7cc79afaeae04f9396b81a0c9c0af492c2ef8e")
addappid(1041922, 1, "75d76b2e3a03c82c02f83dbc7f154cee6347c1df8d80a81510952d624ecaa1a6")

