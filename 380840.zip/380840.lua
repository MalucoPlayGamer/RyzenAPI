-- Lua provided by RyzenAPI
-- Game: AppID 380840

-- MAIN APPLICATION
addappid(380840)
-- Game: addappid(380840)

-- MAIN APP DEPOTS / PACKAGES
addappid(380841, 1, "d61e2b44be7e791647093e9081c22326bd9c3081ebea944c2a6d3a30ec53ba54")
addappid(380842, 1, "4b1c691af4d4166e9b9a878ce56493c9e38389ebfe3618282a5f0dabef3c84bd")
addappid(380843, 1, "e146dde0fe9e79b6b0ff5beeb31fdad9d9705ba6656a218b5207c717af2f31a6")
addappid(380844, 1, "ae3b2be4a17c4c89e05e92f807559a6e597eb8344aaca1e29def122380c333a8")
addappid(380845, 1, "1ff9e87813c916a9fb5a5426ead91e810bb8cd172bbd9058f4c0ec6a60313d63")
