-- Lua provided by RyzenAPI
-- Game: THE FAR EDGE OF FATE:FINAL FANTASY XIV Original Soundtrack

-- MAIN APPLICATION
addappid(3372270)
-- Game: addappid(3372270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372271, 1, "fe42766b6819fb450db2a2b579f62d1d1bbd1fe3c759951d4b9c15c191c7b95e")
