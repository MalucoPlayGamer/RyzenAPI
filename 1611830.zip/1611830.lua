-- Lua provided by RyzenAPI
-- Game: Game: TeamTower

-- MAIN APPLICATION
addappid(1611830)
-- Game: addappid(1611830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611831, 1, "c23282bfa7e55cc72c37f680513d7e573ba40641697a41dd2153c3b6b280c656")
