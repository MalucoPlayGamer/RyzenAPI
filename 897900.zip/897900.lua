-- Lua provided by RyzenAPI
-- Game: Typing Hero

-- MAIN APPLICATION
addappid(897900)

-- MAIN APP DEPOTS / PACKAGES
addappid(897901, 1, "10981dc1f94e831055c78f2990cd4966030ce0d78beab580ed2a6dc1d5c873fe")

