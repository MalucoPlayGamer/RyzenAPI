-- Lua provided by RyzenAPI
-- Game: NaGongGan Infinite

-- MAIN APPLICATION
addappid(1690990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690991, 1, "e15f12353301dace6776c59f8b62e2a1e4c2e3023cc65e41aacaec897a7c933f")

