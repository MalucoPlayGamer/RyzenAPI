-- Lua provided by RyzenAPI 
-- Game: AppID 652230
addappid(652230)
addappid(652231, 1, "26892a2f4d9e58b59a159155e3e96ce329a3bf0a0c84ff35d0b34042bf989086")
addappid(652232, 1, "3ba2fb3b279e80bba5eeeaf8381e8b82de92ad98b51983b7fdca76093dd1255c")
addappid(764950, 0, "eaa53bae7564ef6de13e3e67d23d5209bb7067271b720fbfb16c1f1773927b64")
