-- Lua provided by RyzenAPI
-- Game: Scania Truck Driving Simulator

-- MAIN APPLICATION
addappid(258760)

-- MAIN APP DEPOTS / PACKAGES
addappid(258761, 1, "aba943b02b2216d3ccd84b9c1e740e22fbcc32d4b5ff82c586b42dc088f9ec92")
addappid(258762, 1, "032c4d80be0c75650181c61247e42f2f3b35ebf1aaa838741eb84313fb45d9e8")
addappid(258763, 1, "2dbf9a2f3d052e1e4998b3481bab3669f88781f51c89743724e351e5ff8ef29b")

