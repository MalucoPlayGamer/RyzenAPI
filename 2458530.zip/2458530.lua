-- Lua provided by RyzenAPI
-- Game: 魔女的夜宴

-- MAIN APPLICATION
addappid(2458530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2458531, 1, "a112ff17726a4eadb397f7d89ea34e081ba3891aa001fe4de40b3b3f868bb1a7")

