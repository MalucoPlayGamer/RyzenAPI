-- Lua provided by SkyAPI 
-- Game: 魔女的夜宴
addappid(2458530)
addappid(2458531, 1, "a112ff17726a4eadb397f7d89ea34e081ba3891aa001fe4de40b3b3f868bb1a7")
