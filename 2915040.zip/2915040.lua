-- Lua provided by RyzenAPI
-- Game: Immortals Must Die Demo

-- MAIN APPLICATION
addappid(2915040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2915041, 1, "3899b1054d58019f23b7612684b643be356bc7c6de5d0d01f0b5086e3c5e4ccb")

