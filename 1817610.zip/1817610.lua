-- 1817610's Lua and Manifest Created by Hubcap Manifest
-- Battle Heroine Crisis
-- Created: August 15, 2026 at 14:15:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 13

-- MAIN APPLICATION
addappid(1817610, 1, "9361bab5389856e480d227dd9f1a89fd39c3c755e2f62f26b51d2c7ea7ad4458") -- Battle Heroine Crisis
-- MAIN APP DEPOTS
addappid(1817611, 1, "193fd29f6c2d2c5209895c2fdd5f65763b379083d986332a5deee3679c6bce2d") -- Battle Heroine Crysis Content
setManifestid(1817611, "2937967964940784119", 827495524)
-- DLCS WITH DEDICATED DEPOTS
-- Ganessas Challenge (AppID: 1880430)
addappid(1880430)
addappid(1880431, 1, "01387480f6ba639aebb18f8fd9929a6496d2cc1ae839c80969943505a924a7ee") -- Ganessas Challenge - Depot 1880431
setManifestid(1880431, "3774298136039262826", 29543055)
-- Heroine Pack  Satellizer Another  Cassie (AppID: 1998550)
addappid(1998550)
addappid(1998550, 1, "1adc1f5a4e23a7696ee1026219c129b8e6ad8521acd1502747ed91c871dc785b") -- Heroine Pack  Satellizer Another  Cassie - Depot 1998550
setManifestid(1998550, "7070976412729899702", 176527409)
-- COSTUME  Satellizer Summer (AppID: 2101230)
addappid(2101230)
addappid(2101230, 1, "07c8b3d35262d7262ed60fd8575ef8655f80f7d68f7b461d9db5ff9db14df2d4") -- COSTUME  Satellizer Summer - Depot 2101230
setManifestid(2101230, "6933659148269773941", 13374067)
-- COSTUME  Elizabeth Summer (AppID: 2101240)
addappid(2101240)
addappid(2101240, 1, "eaf6768906fd4ef07a29715114089c0d4b336276849684c17fb4cf953021fbd5") -- COSTUME  Elizabeth Summer - Depot 2101240
setManifestid(2101240, "3324981045466424115", 7756814)
-- Heroine Pack 2  Ticy  Elizabeth Another (AppID: 2200480)
addappid(2200480)
addappid(2200480, 1, "7fc4a027ffaab8ed3d5dcbb3bac22f275fa584ac8756503d88a1893be2ed5351") -- Heroine Pack 2  Ticy  Elizabeth Another - Depot 2200480
setManifestid(2200480, "8594065601126387079", 132318974)
-- COSTUME  Ticy Long Hair (AppID: 2200490)
addappid(2200490)
addappid(2200490, 1, "b08cdc5bbf78bdee33c6bd01190f5feea65ec011cab735f787d039874dde407f") -- COSTUME  Ticy Long Hair - Depot 2200490
setManifestid(2200490, "682411197474699706", 6408778)
-- COSTUME  Elizabeth Bunny Girl (AppID: 2200500)
addappid(2200500)
addappid(2200500, 1, "0707c740b20d365e4287373d665f5cdad379c6a4875950d32753b8938382d803") -- COSTUME  Elizabeth Bunny Girl - Depot 2200500
setManifestid(2200500, "55347790374756387", 9426893)
-- COSTUME  Satellizer Chinese dress (AppID: 2200510)
addappid(2200510)
addappid(2200510, 1, "11295b0c8d6633e93d5f74cfa066c172dfe18c2478fa4c36058c6ee388d90a72") -- COSTUME  Satellizer Chinese dress - Depot 2200510
setManifestid(2200510, "2660166708806581879", 12769307)
-- COSTUME  Chiffon Christmas (AppID: 2258690)
addappid(2258690)
addappid(2258690, 1, "1389b0f497dbe7d662846d3c06ca42086e63bee2d8cedef1689685713d6c5742") -- COSTUME  Chiffon Christmas - Depot 2258690
setManifestid(2258690, "6167346040460421867", 8199078)
-- COSTUME  Cassie Christmas (AppID: 2258700)
addappid(2258700)
addappid(2258700, 1, "49b2299192cb440580514fcf4da1920d5b196811eae4b5376dd5e6e2c84d4078") -- COSTUME  Cassie Christmas - Depot 2258700
setManifestid(2258700, "994563028000193391", 7126276)
-- COSTUME  Ticy Lovely Spring (AppID: 2340680)
addappid(2340680)
addappid(2340680, 1, "a00ae3ee10f0354b89d17a39224eecdde3009249f4490d7504a408304dd4f8c5") -- COSTUME  Ticy Lovely Spring - Depot 2340680
setManifestid(2340680, "5444949969820853194", 6491067)
-- COSTUME  Cassie Lovely Spring (AppID: 2340690)
addappid(2340690)
addappid(2340690, 1, "1b37d290fab3409e806e48f77ac414da4aee42a67b519e39bf9c244b899205f3") -- COSTUME  Cassie Lovely Spring - Depot 2340690
setManifestid(2340690, "6347508596564767109", 7020897)
-- COSTUME  Satellizer Lovely Spring (AppID: 2340710)
addappid(2340710)
addappid(2340710, 1, "6f96c50825cffc1466f5ab19ef108ba517e24321d06b81753e483a6727a464aa") -- COSTUME  Satellizer Lovely Spring - Depot 2340710
setManifestid(2340710, "4152882216804776238", 11455290)