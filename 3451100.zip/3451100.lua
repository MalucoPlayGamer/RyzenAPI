-- Lua provided by RyzenAPI 
-- Game: AppID 3451100
addappid(3451100)
addappid(3451101, 1, "f1fb7a83af500f4b37e49abab974a6c77db031e8d0eee2a288d1bea11aacd689")
addappid(3451102, 1, "6990834d031cf75fb872c26b3449027664654e2bf1fe786c790ef57e1acdf967")
addappid(3451103, 1, "64e0c2caee02183f5f83faa5ada8f355df5a4f88c7fb639a8a350961cc31c474")
