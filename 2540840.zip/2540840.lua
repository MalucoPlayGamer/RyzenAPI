-- Lua provided by SkyAPI 
-- Game: Mega Hero
addappid(2540840)
addappid(2540841, 1, "9ba0df4dbb55bb22d5ac08db7f24b814c90c35704474207ab5614fccefc2b91f")
