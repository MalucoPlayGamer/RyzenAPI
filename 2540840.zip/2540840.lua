-- Lua provided by RyzenAPI
-- Game: Game: Mega Hero

-- MAIN APPLICATION
addappid(2540840)
-- Game: addappid(2540840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540841, 1, "9ba0df4dbb55bb22d5ac08db7f24b814c90c35704474207ab5614fccefc2b91f")
