-- Lua provided by RyzenAPI
-- Game: Puzzle Spy International

-- MAIN APPLICATION
addappid(3406690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3406691,0,"17ed1db56a70acd9267e410cc410ee571feff394b2f4aefc8d3a28986fa4f479")

