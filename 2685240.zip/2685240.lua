-- Lua provided by RyzenAPI
-- Game: Where Cats 猫咪在哪里

-- MAIN APPLICATION
addappid(2685240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685241, 1, "18967c7328efaf4358621258ddfacf415849db4263da336607a9fe65951eb102")
