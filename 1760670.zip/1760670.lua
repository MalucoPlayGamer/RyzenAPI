-- Lua provided by RyzenAPI
-- Game: Mystery Swords

-- MAIN APPLICATION
addappid(1760670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760671, 1, "77e01696c5e8c07fa11c753e8da6c9f17890528d2db075eb486a31115b596239")

