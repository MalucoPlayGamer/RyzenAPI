-- Lua provided by RyzenAPI
-- Game: addappid(2318310)

-- MAIN APPLICATION
addappid(2318310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318311, 1, "e66e5394c607068e30ae879f37749246d2f8c1c56ef69abe96347284dbcdb519")
