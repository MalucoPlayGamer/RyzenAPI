-- Lua provided by RyzenAPI
-- Game: findgold

-- MAIN APPLICATION
addappid(2593380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593381, 1, "72a507713a40f4afcbe9a8873921e4699ba86cafce172255cfc7b91a60226a63")

