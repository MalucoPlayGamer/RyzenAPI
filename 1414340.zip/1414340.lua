-- Lua provided by RyzenAPI
-- Game: Smash Ball Demo

-- MAIN APPLICATION
addappid(1414340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414341, 1, "c28d4b1f2cabc34268190631a470264547898763f7e27f79ee1ed8a4b5948cb0")
