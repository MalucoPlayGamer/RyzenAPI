-- Lua provided by RyzenAPI
-- Game: Oik Reloaded

-- MAIN APPLICATION
addappid(1044220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044221, 1, "bca720a6ef70801b457192227daacbe057efcfead9eadc72e9096fd98843025b")
