-- Lua provided by RyzenAPI
-- Game: addappid(201420)

-- MAIN APPLICATION
addappid(201420)

-- MAIN APP DEPOTS / PACKAGES
addappid(201421, 1, "6c01ac49aa83ab040a5e16584a683792ddc45eb9b0b7cd8ec6bbb40f5698b604")
addappid(201422, 1, "a32df11acae46a083a3da987cdbdaa845014396841348d7c387d6a95adc8ce0b")
addappid(201423, 1, "5c738e9360adab338c439d1e8b8f40a5cfa41e811142752bd6be95ea53c34228")
