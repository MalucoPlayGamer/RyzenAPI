-- Lua provided by RyzenAPI
-- Game: Darksiders II - Death Rides

-- MAIN APPLICATION
addappid(215812)

-- MAIN APP DEPOTS / PACKAGES
addappid(215812,0,"f25238afd830fcd125dd39094efe429a8c50c432735c1afe56c4118814697a6e")

