-- Lua provided by SkyAPI 
-- Game: Oh...Sir!! The Insult Simulator
addappid(512250)
addappid(512251, 1, "304138d82f7cbe92850f0ec4d575e40a0f137ab9710730547de3e4cac21ca9aa")
addappid(512252, 1, "ced553b514d0a30fba0ee8fa44f722c2f8076a269ed27ee9934ffbed810eb941")
addappid(512253, 1, "ce9d49f18e7f6499987ea366297dddc46ec3e37cff6125c28f08264255389eba")
