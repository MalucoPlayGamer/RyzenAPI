-- Lua provided by RyzenAPI
-- Game: 512250

-- MAIN APPLICATION
addappid(512250)
-- Game: addappid(512250)

-- MAIN APP DEPOTS / PACKAGES
addappid(512251, 1, "304138d82f7cbe92850f0ec4d575e40a0f137ab9710730547de3e4cac21ca9aa")
addappid(512252, 1, "ced553b514d0a30fba0ee8fa44f722c2f8076a269ed27ee9934ffbed810eb941")
addappid(512253, 1, "ce9d49f18e7f6499987ea366297dddc46ec3e37cff6125c28f08264255389eba")
