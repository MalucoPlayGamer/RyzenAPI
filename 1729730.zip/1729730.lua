-- Lua provided by RyzenAPI
-- Game: MageRun

-- MAIN APPLICATION
addappid(1729730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729731, 1, "dd615db7630b9d3c488a0b24d9d148f4059781359b7a3daa2a73966b1cdd77f7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
