-- Lua provided by RyzenAPI
-- Game: MageRun

-- MAIN APPLICATION
addappid(1729730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729731, 1, "dd615db7630b9d3c488a0b24d9d148f4059781359b7a3daa2a73966b1cdd77f7")

