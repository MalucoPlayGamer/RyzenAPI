-- Lua provided by RyzenAPI
-- Game: Bullet Force

-- MAIN APPLICATION
addappid(3624370)
