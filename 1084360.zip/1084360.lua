-- Lua provided by SkyAPI 
-- Game: Mister Burnhouse
addappid(1084360)
addappid(1084361, 1, "4aaac9dfcf9aae7e598bef8d5e19799685c5de92af6f3ed233fe7852018e24dd")
