-- Lua provided by RyzenAPI
-- Game: Mister Burnhouse

-- MAIN APPLICATION
addappid(1084360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084361, 1, "4aaac9dfcf9aae7e598bef8d5e19799685c5de92af6f3ed233fe7852018e24dd")

