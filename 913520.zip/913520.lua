-- Lua provided by RyzenAPI
-- Game: 913520

-- MAIN APPLICATION
addappid(913520)
addappid(916460)
-- Game: addappid(913520)

-- MAIN APP DEPOTS / PACKAGES
addappid(913521, 1, "0112849bf34a5da74778b3143ede3c690bba3ae38ed3fbad4334d17b194dc580")
