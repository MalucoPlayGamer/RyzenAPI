-- Lua provided by SkyAPI 
-- Game: AppID 1056710
addappid(1056710)
addappid(1056711, 1, "bca09d96540ebed23eed257f490e9574eb98d9d3f1dee7092e035f9f4e071d0b")
