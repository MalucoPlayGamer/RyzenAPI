-- Lua provided by RyzenAPI 
-- Game: Bloody Trapland
addappid(257750)
addappid(257751, 1, "2c5e8e48e8e8091ae9498d34b580fd9aae140f059deb02232ff0b19bbcdfd014")
addappid(257753, 1, "98f30eb56bfe5c89e9b17bb69a1a2fbd1ea9e4e8a46bbe007610aad588e101c7")
addappid(257754, 1, "7bbf0078fbc3708d4b74274da03a32ae57e8d51463cc4a666264eca515ef00ce")
addappid(899330)
