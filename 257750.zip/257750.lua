-- Lua provided by RyzenAPI
-- Game: Bloody Trapland

-- MAIN APPLICATION
addappid(257750)
addappid(899330)

-- MAIN APP DEPOTS / PACKAGES
addappid(257751, 1, "2c5e8e48e8e8091ae9498d34b580fd9aae140f059deb02232ff0b19bbcdfd014")
addappid(257753, 1, "98f30eb56bfe5c89e9b17bb69a1a2fbd1ea9e4e8a46bbe007610aad588e101c7")
addappid(257754, 1, "7bbf0078fbc3708d4b74274da03a32ae57e8d51463cc4a666264eca515ef00ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
