-- Lua provided by RyzenAPI
-- Game: Dread X Collection 3

-- MAIN APPLICATION
addappid(1437500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437501, 1, "98ec5fe10371a1570f19f8366da151f7bce70e7902d83a83981dbe9f9907719c")

