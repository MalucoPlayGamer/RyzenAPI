-- Lua provided by RyzenAPI
-- Game: addappid(1279370)

-- MAIN APPLICATION
addappid(1279370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279371, 1, "da93b9630f98d6693cee376703d11884dc025fe520bb3fc37544c08965a13fdd")
