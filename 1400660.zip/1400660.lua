-- Lua provided by RyzenAPI
-- Game: Rise of Piracy

-- MAIN APPLICATION
addappid(1400660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400661, 1, "cfb855790f76c1a02694c2bd958cf5c366026b0c43f46b26de84286edbcaa8fd")

