-- Lua provided by RyzenAPI
-- Game: Stage Fright (by Broan Games)

-- MAIN APPLICATION
addappid(771470)
-- Game: addappid(771470)

-- MAIN APP DEPOTS / PACKAGES
addappid(771471, 1, "bba29129564071243904727034bb2bb1bd959a4b28d67bfde72c17e33c44d5a2")
