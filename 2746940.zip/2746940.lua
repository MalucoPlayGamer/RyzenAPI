-- Lua provided by RyzenAPI
-- Game: Clipbase Demo

-- MAIN APPLICATION
addappid(2746940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746941, 1, "30a854fbdd3028420445280d7aeb6a01f6e832b2c0d4a13b22bd4d70a0371d43")
