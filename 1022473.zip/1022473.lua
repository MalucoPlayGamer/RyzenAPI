-- Lua provided by RyzenAPI
-- Game: DFF NT: Fledgling Warrior Appearance Set for Warrior of Light

-- MAIN APPLICATION
addappid(1022473)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022473,0,"3d2e10f2a0ee398157fd88ddb0c29886943099d7113668a30d66a159d5e014ee")

