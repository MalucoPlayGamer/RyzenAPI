-- Lua provided by RyzenAPI
-- Game: Game: AppID 862040

-- MAIN APPLICATION
addappid(862040)
-- Game: addappid(862040)

-- MAIN APP DEPOTS / PACKAGES
addappid(862041, 1, "19bfff5df263a2d7d5c9f66928420a9bf91cf7a6411738ff34c449371a9d0d9d")
