-- Lua provided by RyzenAPI
-- Game: Dive

-- MAIN APPLICATION
addappid(798170)

-- MAIN APP DEPOTS / PACKAGES
addappid(798171,0,"27c1e9ec19d82f9de4796c732523cc3d988796476178cd0f1d66f026eacc5687")

