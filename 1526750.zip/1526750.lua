-- Lua provided by RyzenAPI 
-- Game: Remember When
addappid(1526750)
addappid(1526751, 1, "0561ef2f6fae2eef4e292bbee10b0b1c9c87631bcbb7ef55a8afafe307160632")
