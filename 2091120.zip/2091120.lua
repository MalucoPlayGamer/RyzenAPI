-- Lua provided by RyzenAPI
-- Game: 天天萌泡泡

-- MAIN APPLICATION
addappid(2091120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091121, 1, "4157ace153eefc7f03a034b71d756581fcdd3861e6c3d02378fdd9142ebeacc2")

