-- Lua provided by RyzenAPI
-- Game: AppID 1233260

-- MAIN APPLICATION
addappid(1233260)
-- Game: addappid(1233260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233261, 1, "b78e09baad5d30bf9c0678e42b20b8f8d41a75adae4d3766cdad156a6b383557")
