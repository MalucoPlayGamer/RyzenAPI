-- Lua provided by RyzenAPI
-- Game: addappid(3720970)

-- MAIN APPLICATION
addappid(3720970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720971, 1, "fc434bf2fc88c2064a9f9110edb3526ce846fcdbb09e629921f8c4ab5acb410c")
