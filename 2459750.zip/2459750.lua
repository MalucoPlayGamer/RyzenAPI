-- Lua provided by RyzenAPI 
-- Game: Yohane the Parhelion - NUMAZU in the MIRAGE -
addappid(2459750)
addappid(2459751, 1, "82dc4d1024f9965fd0116391d2d66a0d2cb57c9d92b32dc4f4e6e18a6cf39bc3")
