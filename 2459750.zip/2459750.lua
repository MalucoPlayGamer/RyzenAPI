-- Lua provided by RyzenAPI
-- Game: Yohane the Parhelion - NUMAZU in the MIRAGE -

-- MAIN APPLICATION
addappid(2459750)
addappid(2627830)
addappid(2627840)
addappid(2627860)
addappid(2627870)
addappid(2627880)
addappid(2627890)
addappid(2627900)
addappid(2627910)
addappid(2627920)
addappid(2627930)
addappid(2627940)
addappid(2627950)
addappid(2627960)
addappid(2627970)
addappid(2627980)
addappid(2627990)
addappid(2750830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459751, 1, "82dc4d1024f9965fd0116391d2d66a0d2cb57c9d92b32dc4f4e6e18a6cf39bc3")

