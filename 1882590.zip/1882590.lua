-- Lua provided by RyzenAPI
-- Game: Ella - a study in realism

-- MAIN APPLICATION
addappid(1882590)
-- Game: addappid(1882590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882591, 1, "ac833ba501e912e5b15481164554ca55082cc14dc4ebc5c0da73e22c5dc09d08")
addappid(1882592, 1, "98a3c9f4db3d724726d2f85edd65d3bcf59fdef5cb683b66e202e06321523623")
addappid(1882593, 1, "46621e0357d85d45d38280febb8951b28eb4d3ff6acfcd00225dfe93f4b04b79")
