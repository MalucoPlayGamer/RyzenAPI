-- 3972190's Lua and Manifest Created by Hubcap Manifest
-- Mineral Mining Simulator
-- Created: August 07, 2026 at 08:18:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3972190, 1, "6040ab22dc950ea892ee3d7cd1c852009a6d263be5f76772529731b91e093e78") -- Mineral Mining Simulator
-- MAIN APP DEPOTS
addappid(3972191, 1, "1d403677a9cec203d04c177ab7991fb39e9eb5851e38a35a3e11a015deb3fa6d") -- Depot 3972191
setManifestid(3972191, "1387834320882777347", 5077116423)