-- Lua provided by RyzenAPI
-- Game: Mineral Mining Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(3972190, 1, "6040ab22dc950ea892ee3d7cd1c852009a6d263be5f76772529731b91e093e78") -- Mineral Mining Simulator
addappid(3972191, 1, "1d403677a9cec203d04c177ab7991fb39e9eb5851e38a35a3e11a015deb3fa6d") -- Depot 3972191

