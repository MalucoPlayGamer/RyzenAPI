-- Lua provided by RyzenAPI
-- Game: Forever To You! - Animations Pack

-- MAIN APPLICATION
addappid(2654060)
-- Game: addappid(2654060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654060,0,"f84de94a74945a37bcd01cd723fed96cd88d9b42f75995922717478179a5e722")
