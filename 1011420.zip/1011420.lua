-- Lua provided by RyzenAPI
-- Game: addappid(1011420)

-- MAIN APPLICATION
addappid(1011420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011421, 1, "ff10b73cbc06a7339d5ca1d141f0a1f04c45aea81ff15c0afc783e8728fc2e08")
