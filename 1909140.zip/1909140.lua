-- Lua provided by RyzenAPI
-- Game: addappid(1909140)

-- MAIN APPLICATION
addappid(1909140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909141, 1, "4afb5c71053f6ca3f8da253ed66f1441bc734f45ad6fcc9e5abbff4e7de440c6")
