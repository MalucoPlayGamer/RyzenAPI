-- Lua provided by RyzenAPI
-- Game: 2336720

-- MAIN APPLICATION
addappid(2336720)
addappid(2589000)
-- Game: addappid(2336720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336721, 1, "96fa5213efc77cbb04de34ded3df5e99bee20c1d4acd47d90e04ca7265de8c9a")
