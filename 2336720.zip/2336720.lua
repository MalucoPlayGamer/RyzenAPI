-- Lua provided by RyzenAPI
-- Game: Greed of Man

-- MAIN APPLICATION
addappid(2336720)
addappid(2589000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336721, 1, "96fa5213efc77cbb04de34ded3df5e99bee20c1d4acd47d90e04ca7265de8c9a")
