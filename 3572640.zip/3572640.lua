-- Lua provided by RyzenAPI
-- Game: 3572640

-- MAIN APPLICATION
addappid(3572640)
-- Game: addappid(3572640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3572641, 1, "412208dde5ad6b7cb609621486faf0ca2dc124cc6478f438bf66157b15990d13")
