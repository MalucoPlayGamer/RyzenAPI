-- Lua provided by RyzenAPI
-- Game: 701930

-- MAIN APPLICATION
addappid(701930)
-- Game: addappid(701930)

-- MAIN APP DEPOTS / PACKAGES
addappid(701931, 1, "25cf17c9b62f2445f6f8f04181d4e74e1f9c15afa7f1188da08190745a75a8c6")
