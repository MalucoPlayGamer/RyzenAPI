-- Lua provided by RyzenAPI 
-- Game: AppID 657700
addappid(657700)
addappid(657701, 1, "457a05c8750a58991bf35279b7e5f536a9ddc280ac2a1dab04f2a8a340a76c83")
