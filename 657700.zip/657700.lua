-- Lua provided by RyzenAPI
-- Game: Game: AppID 657700

-- MAIN APPLICATION
addappid(657700)
-- Game: addappid(657700)

-- MAIN APP DEPOTS / PACKAGES
addappid(657701, 1, "457a05c8750a58991bf35279b7e5f536a9ddc280ac2a1dab04f2a8a340a76c83")
