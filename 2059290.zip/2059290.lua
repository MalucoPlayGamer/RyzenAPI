-- Lua provided by RyzenAPI
-- Game: Five nights at Stalin

-- MAIN APPLICATION
addappid(2059290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059291, 1, "7e723e6464ca3ad67446f668107fa22f2b86bb0164998afb9751d17f57b08cb5")

