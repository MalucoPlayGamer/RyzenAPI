-- Lua provided by RyzenAPI
-- Game: I Am Gangster

-- MAIN APPLICATION
addappid(1877830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877831, 1, "2d1937d1bc6eb2c9800476a895a3f13819068c52bba92712a43e56c5ba8cb383")

