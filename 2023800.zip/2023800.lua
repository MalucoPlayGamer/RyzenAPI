-- Lua provided by RyzenAPI
-- Game: addappid(2023800)

-- MAIN APPLICATION
addappid(2023800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023801, 1, "dfada597ce5d481509335f86926e9b988e372608bbf88481e19a8ac99b158f86")
