-- Lua provided by RyzenAPI
-- Game: 429940

-- MAIN APPLICATION
addappid(429940)
-- Game: addappid(429940)

-- MAIN APP DEPOTS / PACKAGES
addappid(429941, 1, "bcda09c1e0ddccc2dba315b09d26832355db119bc90b17108e9c6044cc757694")
