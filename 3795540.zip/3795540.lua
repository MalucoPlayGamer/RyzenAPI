-- Lua provided by RyzenAPI 
-- Game: DELETE
addappid(3795540)
addappid(3795541, 1, "8b4aaa65c04e23c30847079f74aeec0631a0ded044a948c1afb2de7b8b2f01fc")
