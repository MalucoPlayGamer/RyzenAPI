-- Lua provided by RyzenAPI
-- Game: DELETE

-- MAIN APPLICATION
addappid(3795540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3795541, 1, "8b4aaa65c04e23c30847079f74aeec0631a0ded044a948c1afb2de7b8b2f01fc")
