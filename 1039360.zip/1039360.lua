-- Lua provided by RyzenAPI
-- Game: Eyes in the Dark

-- MAIN APPLICATION
addappid(1039360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039361, 1, "c6032e9e4282bac3321696eaf463fc1d92a8d981af7d9dfa292e2b7a1da8face")
