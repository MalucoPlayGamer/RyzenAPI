-- Lua provided by RyzenAPI
-- Game: 404630

-- MAIN APPLICATION
addappid(404630)
-- Game: addappid(404630)

-- MAIN APP DEPOTS / PACKAGES
addappid(404631, 1, "834568ddf6d0986a09dce47898bfcfccab7b761dc4e9462c7fee999796d9aaca")
