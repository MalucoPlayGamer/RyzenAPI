-- Lua provided by RyzenAPI 
-- Game: AppID 555310
addappid(555310)
addappid(555311, 1, "115b096cae54a937063da232325c3ff227dadf758c6181fd2be1783c7bb193ff")
