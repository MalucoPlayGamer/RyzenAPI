-- Lua provided by RyzenAPI
-- Game: 555310

-- MAIN APPLICATION
addappid(555310)
-- Game: addappid(555310)

-- MAIN APP DEPOTS / PACKAGES
addappid(555311, 1, "115b096cae54a937063da232325c3ff227dadf758c6181fd2be1783c7bb193ff")
