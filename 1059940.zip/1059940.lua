-- Lua provided by RyzenAPI
-- Game: Game: Kill 'Em All Demo

-- MAIN APPLICATION
addappid(1059940)
-- Game: addappid(1059940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059941, 1, "623276023c7528e863e4a71be7e5ce12cc6359ee72ac00170a3f670d4c16a759")
