-- Lua provided by RyzenAPI
-- Game: AppID 712720

-- MAIN APPLICATION
addappid(712720)

-- MAIN APP DEPOTS / PACKAGES
addappid(712721, 1, "b5bb14366ede0e30877e94c6a4076da25466da4ab933ab2db37fbc90e8c11ac7")
