-- Lua provided by RyzenAPI
-- Game: Darkness Restricted

-- MAIN APPLICATION
addappid(781890)

-- MAIN APP DEPOTS / PACKAGES
addappid(781891,0,"9f8dd21093bc794c8607abf6a39a640d20f9e3e5769006169f81457997fee41a")

