-- Lua provided by RyzenAPI
-- Game: Puzzle Wizards

-- MAIN APPLICATION
addappid(2344820)
-- Game: addappid(2344820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2344822,0,"3e77ecdcf305158454c9a711519ca08c030f6edfb045d95940d0115ab6ac173c")
addappid(2344823,0,"da3f4a0db194ef757a4990e6996958a1a576e092d95c0d099081caf28e2a93b2")
addappid(2344824,0,"9dbbbc5e53e9a13f36f38c477ef49762b1ff702cce47a63a4b10e087e423d2af")
