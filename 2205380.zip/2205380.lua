-- Lua provided by RyzenAPI
-- Game: Ragnarök TD

-- MAIN APPLICATION
addappid(2205380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205381, 1, "f672b3e09188f70f397b66d5e34c87abf491355c763c85c7b37709f43a75af47")
addappid(2205382, 1, "d715ee39fcd32c0d38aa1ce8fd4dda363d5abf67c65ae9a384645d0a713ef9f0")
addappid(2205383, 1, "2c51f3bf1c0fd851279c9d98bb88c1c23d46c9019ba745558bff4c995254cade")

