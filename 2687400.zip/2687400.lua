-- Lua provided by RyzenAPI
-- Game: GODBREAKERS

-- MAIN APPLICATION
addappid(2687400)
addappid(3939160)
addappid(4005100)
addappid(4100670)
addappid(4184620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2687401,0,"d90f79ae21d7d9c853ea7896a317f64baec972599784c7fb89236a2a6164e79e")

