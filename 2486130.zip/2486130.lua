-- Lua provided by RyzenAPI
-- Game: Taboo University Book One Demo

-- MAIN APPLICATION
addappid(2486130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486131, 1, "4df997385d0fad27f8b47a39b352716363e30c000afb3cf090ecfbe03e63f857")
