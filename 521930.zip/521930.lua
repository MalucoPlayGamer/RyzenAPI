-- Lua provided by RyzenAPI
-- Game: Minimized

-- MAIN APPLICATION
addappid(521930)
addappid(528440)
addappid(590520)

-- MAIN APP DEPOTS / PACKAGES
addappid(521931, 1, "7bf694fd05c91e3c004319fa2bb5fa2ccf31e3a447f1c8de4b68feb3aa0bbaff")
