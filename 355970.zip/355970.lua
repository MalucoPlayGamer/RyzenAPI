-- Lua provided by RyzenAPI
-- Game: 355970

-- MAIN APPLICATION
addappid(355970)
-- Game: addappid(355970)

-- MAIN APP DEPOTS / PACKAGES
addappid(355971, 1, "e109f1b41a7e13ba120815bce4626ebfcc057b508427ff8171fb43d83d8cb6ad")
addappid(355972, 1, "1c92da056214f5677ca9c918954f32d04feb46d7ff1b4e51a0627c8d5359a6ce")
addappid(355973, 1, "a013e9004bc941f2f6a51e230bbf28d709a8ed573cdd0ade6c6f032b3ed23492")
