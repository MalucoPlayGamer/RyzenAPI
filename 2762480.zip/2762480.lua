-- Lua provided by RyzenAPI
-- Game: OuterRealm

-- MAIN APPLICATION
addappid(2762480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762481, 1, "27519eb34159babcb4d334ccb1b1ad8f241582492508051647be8fa1e85d3677")
