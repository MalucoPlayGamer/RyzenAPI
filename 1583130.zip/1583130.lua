-- Lua provided by RyzenAPI
-- Game: Replicators Defence

-- MAIN APPLICATION
addappid(1583130)
addappid(2076680)
-- Game: addappid(1583130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583131, 1, "08222d906bae60f4e5ee795d0bbf2b6d747288a41c17d872603d87ab8500af5c")
