-- Lua provided by RyzenAPI
-- Game: Shatterline

-- MAIN APPLICATION
addappid(2087030)
addappid(4035990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2087031, 1, "45c4a6a5a2a34c5d066bd2e654f351b74e75d97060ab471c2c04250670ed134f")

