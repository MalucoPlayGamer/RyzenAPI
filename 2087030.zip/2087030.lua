-- Lua provided by RyzenAPI
-- Game: Shatterline

-- MAIN APPLICATION
addappid(2087030)
addappid(4035990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087031, 1, "45c4a6a5a2a34c5d066bd2e654f351b74e75d97060ab471c2c04250670ed134f")

