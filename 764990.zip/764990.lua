-- Lua provided by RyzenAPI
-- Game: Game: Whack the Serial Killer 20 Ways plus Neighbour, Burglars...

-- MAIN APPLICATION
addappid(764990)
-- Game: addappid(764990)

-- MAIN APP DEPOTS / PACKAGES
addappid(764991, 1, "6fd98c8997c5ec25af6cc5462c6bb940461d3ce3c83b8e90bf0aab1507e6b81f")
