-- 4910220's Lua and Manifest Created by Hubcap Manifest
-- Incremental Vampire
-- Created: July 24, 2026 at 06:10:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4910220) -- Incremental Vampire
-- MAIN APP DEPOTS
addappid(4910221, 1, "2908ee4e2cdd82d9fff32bcc4b344637256724733eb006bea33a622338047537") -- Depot 4910221
setManifestid(4910221, "1154701273929691066", 191009992)
addappid(4910222, 1, "22f722c809d479eed8522a79a72288ced36a029b6dc10170e90690919e6ac9f8") -- Depot 4910222
setManifestid(4910222, "3300906835243900449", 158390888)