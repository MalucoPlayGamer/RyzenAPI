-- Lua provided by RyzenAPI
-- Game: AppID 441380

-- MAIN APPLICATION
addappid(441380)

-- MAIN APP DEPOTS / PACKAGES
addappid(441381, 1, "4eb6d361bf04ac18640968e1d37f5c69f13319167f9558942680c27fbfe7274f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
