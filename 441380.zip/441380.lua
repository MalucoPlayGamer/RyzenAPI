-- Lua provided by RyzenAPI 
-- Game: AppID 441380
addappid(441380)
addappid(441381, 1, "4eb6d361bf04ac18640968e1d37f5c69f13319167f9558942680c27fbfe7274f")
