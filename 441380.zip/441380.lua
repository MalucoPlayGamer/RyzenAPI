-- Lua provided by RyzenAPI
-- Game: 441380

-- MAIN APPLICATION
addappid(441380)
-- Game: addappid(441380)

-- MAIN APP DEPOTS / PACKAGES
addappid(441381, 1, "4eb6d361bf04ac18640968e1d37f5c69f13319167f9558942680c27fbfe7274f")
