-- Lua provided by RyzenAPI
-- Game: Top Trumps Turbo

-- MAIN APPLICATION
addappid(343180)

-- MAIN APP DEPOTS / PACKAGES
addappid(343181, 1, "13e1b6d2390df81d9372e5be8f5c83931eb494fa4894366c92ff801ef96b8634")
addappid(343182, 1, "1ae4596242d0c64c9f7ab098a2350909269b84f05ed1bc9529d0f7d84717f63b")
addappid(343183, 1, "1a08cf9cfec4ca3e2298fa3caec1a8e19ccff588280ec9d49ddc4fbb1f233745")

