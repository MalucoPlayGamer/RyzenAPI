-- Lua provided by RyzenAPI
-- Game: 1403020

-- MAIN APPLICATION
addappid(1403020)
-- Game: addappid(1403020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403021, 1, "4562da49a6821bcf96f8cc10172302105dadffd062fecc5203b6adfed1794ebd")
