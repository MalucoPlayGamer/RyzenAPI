-- Lua provided by RyzenAPI
-- Game: Game: AppID 1548860

-- MAIN APPLICATION
addappid(1548860)
-- Game: addappid(1548860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548861, 1, "505953b832ed9a11e07f65bb5378d955e72a078f4be00766587120ae995aad7f")
