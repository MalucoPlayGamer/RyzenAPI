-- Lua provided by RyzenAPI
-- Game: Farlight Commanders: Prologue

-- MAIN APPLICATION
addappid(1548860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1548861, 1, "505953b832ed9a11e07f65bb5378d955e72a078f4be00766587120ae995aad7f")

