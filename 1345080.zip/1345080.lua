-- Lua provided by RyzenAPI 
-- Game: 12 Hours to Die
addappid(1345080)
addappid(1345081, 1, "e904643522ed773f82ab279f85914b161913679ab6f62d53c830641b6f1733f8")
