-- Lua provided by RyzenAPI
-- Game: addappid(1939350)

-- MAIN APPLICATION
addappid(1939350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939351, 1, "b5dbdbcad469108cb7ece3a3949fcb8c9bda40d02990f6b2a1a0735a5d543965")
