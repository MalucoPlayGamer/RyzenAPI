-- Lua provided by RyzenAPI
-- Game: Distorted Illusions

-- MAIN APPLICATION
addappid(878280)

-- MAIN APP DEPOTS / PACKAGES
addappid(878282,0,"6a374e722fb10aacbb7d86c324e54000ebf76153aa1500b9fb71b85a8ded326a")
