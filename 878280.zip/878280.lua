-- Lua provided by RyzenAPI
-- Game: Distorted Illusions

-- MAIN APPLICATION
addappid(878280)

-- MAIN APP DEPOTS / PACKAGES
addappid(878282,0,"6a374e722fb10aacbb7d86c324e54000ebf76153aa1500b9fb71b85a8ded326a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
