-- Lua provided by RyzenAPI
-- Game: Game: Corpse of Discovery

-- MAIN APPLICATION
addappid(297720)
-- Game: addappid(297720)

-- MAIN APP DEPOTS / PACKAGES
addappid(297721, 1, "7973eebe6ea05a572790f948583fc91a22e20f2d0bac8010439243fe51452adc")
