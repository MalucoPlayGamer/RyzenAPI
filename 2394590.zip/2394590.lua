-- Lua provided by RyzenAPI
-- Game: addappid(2394590)

-- MAIN APPLICATION
addappid(2394590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394591, 1, "53c1f4c179ac21b646d926700f0b5e6582f94441a9523cede33d2baf36a1ddbc")
