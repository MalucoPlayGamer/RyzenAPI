-- Lua provided by RyzenAPI
-- Game: Trapped Dead: Lockdown

-- MAIN APPLICATION
addappid(305500)
-- Game: addappid(305500)

-- MAIN APP DEPOTS / PACKAGES
addappid(305501, 1, "f441bb7a612082d0df30ac29468befa0bf05c4c4dcb4b0d43f896d734d0eb4ad")
addappid(305502, 1, "7bd68b2f593e56f70ed61c18dc5cd49a75f738ea4169e234c8233b492679e4b8")
addappid(305503, 1, "b6b1d1e71f338692e589c90828a991f3fdcf31ea9a2787908999eecdfdd8d0a9")
