-- Lua provided by RyzenAPI
-- Game: 1749360

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(229033)
addappid(1749360)
addappid(1749364)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749363,0,"cce48a15dc80af5a052a6794ea816581f49b03b020dac7d75a1c1b0b38e0b617")

