-- Lua provided by RyzenAPI
-- Game: addappid(1524290)

-- MAIN APPLICATION
addappid(1524290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524291, 1, "952b3044bee28e843eb44363eae2f0b69daf1f4ac20afa70850bcb90fb349bae")
