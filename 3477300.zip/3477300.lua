-- Lua provided by RyzenAPI
-- Game: Scope X

-- MAIN APPLICATION
addappid(3477300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3477301, 1, "4d68ce9188c501ebc1df053a10c9bdf69f8912d30a218f65286981b081f80e58")

