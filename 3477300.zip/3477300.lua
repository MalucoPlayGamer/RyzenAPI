-- Lua provided by RyzenAPI
-- Game: Scope X

-- MAIN APPLICATION
addappid(3477300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3477301, 1, "4d68ce9188c501ebc1df053a10c9bdf69f8912d30a218f65286981b081f80e58")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
