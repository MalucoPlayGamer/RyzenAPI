-- Lua provided by RyzenAPI
-- Game: Noble Armada: Lost Worlds

-- MAIN APPLICATION
addappid(886230)

-- MAIN APP DEPOTS / PACKAGES
addappid(886231, 1, "e6bac8ec99dff1288ed4988213d6eb4d4c90128450be750563a89260a68d4017")
