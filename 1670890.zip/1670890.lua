-- Lua provided by RyzenAPI
-- Game: Lamia's Plan

-- MAIN APPLICATION
addappid(1670890)
addappid(1674480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670891, 1, "6e87826a4a21a9fb04ed9a37738fed7dcec651fdd042c98a9568a51dc3ddd88a")

