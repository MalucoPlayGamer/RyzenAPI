-- Lua provided by RyzenAPI
-- Game: Witchspire

-- MAIN APPLICATION
addappid(2679100)
addappid(4695140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2679101, 1, "fe034c141c4a7e40166c2a3c3e1113721f48dfdd6942e5767ad7532ade8d6982")

