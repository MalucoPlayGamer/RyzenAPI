-- 2679100's Lua and Manifest Created by Hubcap Manifest
-- Witchspire
-- Created: June 24, 2026 at 08:08:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2679100, 1, "24478c251e8ca94fd77f1a80c8aa3ec1cd31cc18a1c28efe82b51105b1583b5f") -- Witchspire
-- MAIN APP DEPOTS
addappid(2679101, 1, "fe034c141c4a7e40166c2a3c3e1113721f48dfdd6942e5767ad7532ade8d6982") -- Depot 2679101
setManifestid(2679101, "1735363744256216356", 6838685282)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Witchspire - Founders Edition (AppID: 4695140)
addappid(4695140)
addappid(4695140, 1, "532f18d1140801ec805d9ae829b920cae5c27a8c3080312c86e7d55ed695fd00") -- Witchspire - Founders Edition - Depot 4695140
setManifestid(4695140, "7850839620513313953", 1163098907)