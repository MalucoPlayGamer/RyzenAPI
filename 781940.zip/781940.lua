-- Lua provided by RyzenAPI
-- Game: AppID 781940

-- MAIN APPLICATION
addappid(781940)

-- MAIN APP DEPOTS / PACKAGES
addappid(781941, 1, "1eb7df0cf5d245f9aa81dfa3b9e19fc30eeb6170e8937cbee151c6a33734b620")
