-- Lua provided by RyzenAPI
-- Game: Winter Cats

-- MAIN APPLICATION
addappid(2762810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762812,0,"087400f0f6c766b45bbe811ac273dbe3dc2f67ad8af0c80f2e42fd7d461b4c3f")
addappid(2762813,0,"a49f0cd3d9e91382c5ff5301c340b5e04274bbc56aef0a22f1706f7f4594a70b")
addappid(2762814,0,"91c40823fe2bec4c502b08a137ae36549dc9fe3ba8a81f29126ede7be4dc3efb")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2789900)
addappid(2845670)
