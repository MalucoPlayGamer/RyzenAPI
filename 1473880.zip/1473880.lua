-- Lua provided by RyzenAPI
-- Game: The Humbling of a Holy Maiden

-- MAIN APPLICATION
addappid(1473880)
-- Game: addappid(1473880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473881, 1, "2d2965dc55412f5a04fb3e5994da177717b3144a9a8cf230f9727f8dc9815fda")
