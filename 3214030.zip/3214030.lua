-- Lua provided by RyzenAPI
-- Game: Crash Puzzle Hammer-San Demo

-- MAIN APPLICATION
addappid(3214030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214031, 1, "6d4c580123af09cc809e0ce6bffe4c1b3958c920cd0b86b6db142d8a9b8090db")

