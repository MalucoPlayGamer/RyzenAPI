-- Lua provided by RyzenAPI
-- Game: Bug & Seek

-- MAIN APPLICATION
addappid(2265310)
addappid(2753410)
addappid(2933230)
addappid(3847270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265312,0,"0ddaf5f767bfa6cba8a28e99650b9e2ed6a6421094d2e0d3d67d899f743905b8")

