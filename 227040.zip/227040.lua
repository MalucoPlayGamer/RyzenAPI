-- Lua provided by SkyAPI 
-- Game: AppID 227040
addappid(227040)
addappid(227041, 1, "4f51a51bc7e5af40145bab932e03ea1077eea5c0e08d3a2d72f4dca74d124073")
