-- Lua provided by RyzenAPI
-- Game: 227040

-- MAIN APPLICATION
addappid(227040)
-- Game: addappid(227040)

-- MAIN APP DEPOTS / PACKAGES
addappid(227041, 1, "4f51a51bc7e5af40145bab932e03ea1077eea5c0e08d3a2d72f4dca74d124073")
