-- Lua provided by RyzenAPI
-- Game: RIDE 6

-- MAIN APPLICATION
addappid(2815070)
addappid(3970220)
addappid(3970240)
addappid(3970250)
addappid(3970260)
addappid(3970270)
addappid(3970280)
addappid(3970290)
addappid(3970300)
addappid(3975550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2815071, 1, "daec92978f1e0a7c2eac9986cc7e2754d247b951584e6178d0e97cc4d29fa7bb")

