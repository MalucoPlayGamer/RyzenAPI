-- Lua provided by RyzenAPI
-- Game: RIDE 6

-- MAIN APPLICATION
addappid(2815070)
addappid(3970220)
addappid(3970240)
addappid(3970250)
addappid(3970260)
addappid(3970270)
addappid(3970280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815071, 1, "daec92978f1e0a7c2eac9986cc7e2754d247b951584e6178d0e97cc4d29fa7bb")
