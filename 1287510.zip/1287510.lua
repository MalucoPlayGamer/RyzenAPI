-- Lua provided by RyzenAPI
-- Game: Wizard Lady

-- MAIN APPLICATION
addappid(1287510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287511, 1, "e267d337ca83f94f9718b0155f22eaafcc0b4d9ec884e6c4452f2574f3228f33")
