-- Lua provided by RyzenAPI
-- Game: Game: AppID 1273530

-- MAIN APPLICATION
addappid(1273530)
-- Game: addappid(1273530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273531, 1, "afb11b0669298abc5f469171743c168f606f10754c2b11ae0d95175b9eec5142")
