-- Lua provided by RyzenAPI
-- Game: MXGP3 - The Official Motocross Videogame

-- MAIN APPLICATION
addappid(561600)

-- MAIN APP DEPOTS / PACKAGES
addappid(561601, 1, "ffa3d193e935a6f2bc3fc2bbbc5780bb3f16f71ebc82b5469731d0c80b0a6137")
addappid(561602, 1, "e0006db03d63c3c8d81a0c769626653f5391602acdb9ef450a8d3d388d89b4a0")
addappid(561603, 1, "52fc13b183256f9711a70228f52d82c3805d5ae15982e2fc3aaba105a6965267")
addappid(561604, 1, "8520e5e1f45232ea28749822c3845ebe1152bb2d5685121f4e8f5064e417251f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
