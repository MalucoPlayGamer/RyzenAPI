-- Lua provided by RyzenAPI
-- Game: Miryam: The Polluted Land

-- MAIN APPLICATION
addappid(3399770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3399771, 1, "15d03dd93048986c9fd0b5cbbc8d75842c2cc4299993045a93a064a357b07871")
