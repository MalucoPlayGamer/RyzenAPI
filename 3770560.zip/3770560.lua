-- Lua provided by RyzenAPI
-- Game: Game: Balloon Party

-- MAIN APPLICATION
addappid(3770560)
-- Game: addappid(3770560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3770561, 1, "0b36781a2d37f4b1bc848100e4106adc92487a8374033f6c0c1edd3d3efa9c62")
