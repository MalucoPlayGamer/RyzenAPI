-- Lua provided by RyzenAPI
-- Game: Backrooms Cleanup Crew Demo

-- MAIN APPLICATION
addappid(3295910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3295911, 1, "76081faaedc07bce69bccca099bc8d240221cd166adcc1184b6c59c9fea1f234")

