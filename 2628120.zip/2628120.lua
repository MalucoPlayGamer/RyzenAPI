-- Lua provided by SkyAPI 
-- Game: Pixel Cafe Demo
addappid(2628120)
addappid(2628121, 1, "62fb96654abc7ac60c2e0c2bf430162ea405533e6bdf0f8b1cddd62bc07de4cd")
