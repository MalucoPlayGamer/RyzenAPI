-- Lua provided by RyzenAPI
-- Game: 913220

-- MAIN APPLICATION
addappid(913220)
-- Game: addappid(913220)

-- MAIN APP DEPOTS / PACKAGES
addappid(913221, 1, "90a4d2d32942dbc9633c975ee0703e2c8c20a20b8a7b4d34c1a0503754cb9312")
