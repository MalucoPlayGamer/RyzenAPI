-- Lua provided by RyzenAPI
-- Game: FSX Active Sky Next Configuration Tool

-- MAIN APPLICATION
addappid(369140)

-- MAIN APP DEPOTS / PACKAGES
addappid(369141, 1, "a9a20735660ef002dc6188c9e24173a0691a09c2d3f0b24e2a967adafd7fd361")

