-- Lua provided by RyzenAPI
-- Game: Game: Fuga: Melodies of Steel 3

-- MAIN APPLICATION
addappid(3081320)
-- Game: addappid(3081320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081321, 1, "735a7c6b3f8d915e0c21319a079d89d673617cb135b626725ab4ea1740296891")
