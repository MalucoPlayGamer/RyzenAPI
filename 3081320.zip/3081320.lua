-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel 3

-- MAIN APPLICATION
addappid(3081320)
addappid(3173600)
addappid(3425730)
addappid(3425740)
addappid(3425750)
addappid(3425760)
addappid(3425770)
addappid(3872460)
addappid(3872470)
addappid(3872480)
addappid(3872490)
addappid(3872500)
addappid(3872510)
addappid(3872520)
addappid(3952760)
addappid(4070850)
addappid(4189450)
addappid(4283690)
addappid(4520470)
addappid(4520700)
addappid(4520710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3081321, 1, "735a7c6b3f8d915e0c21319a079d89d673617cb135b626725ab4ea1740296891")

