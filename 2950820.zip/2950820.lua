-- Lua provided by RyzenAPI
-- Game: impossible island

-- MAIN APPLICATION
addappid(2950820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2950821, 1, "beee9cfdc831cbfd1d92f05a5d5fb213b6752ded53c54f1106e045804e331769")

