-- Lua provided by RyzenAPI
-- Game: impossible island

-- MAIN APPLICATION
addappid(2950820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2950821, 1, "beee9cfdc831cbfd1d92f05a5d5fb213b6752ded53c54f1106e045804e331769")
