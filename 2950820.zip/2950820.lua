-- Lua provided by SkyAPI 
-- Game: impossible island
addappid(2950820)
addappid(2950821, 1, "beee9cfdc831cbfd1d92f05a5d5fb213b6752ded53c54f1106e045804e331769")
