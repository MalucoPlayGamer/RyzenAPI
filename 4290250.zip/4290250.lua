-- Lua provided by RyzenAPI
-- Game: Phantacall Realm

-- MAIN APPLICATION
addappid(4290250) -- Phantacall Realm

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4290251, 1, "406a08de359a966ce4a8cedfe273381a8fbd3875bbd670cc614ee13ee8ad1b95") -- Depot 4290251

