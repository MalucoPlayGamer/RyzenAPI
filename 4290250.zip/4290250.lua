-- 4290250's Lua and Manifest Created by Hubcap Manifest
-- Phantacall Realm
-- Created: August 04, 2026 at 14:15:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4290250) -- Phantacall Realm
-- MAIN APP DEPOTS
addappid(4290251, 1, "406a08de359a966ce4a8cedfe273381a8fbd3875bbd670cc614ee13ee8ad1b95") -- Depot 4290251
setManifestid(4290251, "2613800215297657884", 2433985951)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)