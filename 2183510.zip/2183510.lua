-- Lua provided by RyzenAPI
-- Game: Lunacy: Saint Rhodes Demo

-- MAIN APPLICATION
addappid(2183510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183511, 1, "48902811ec7aa6a7e95f3bc71c50f023559e0b9487fa22275b5a79db2c09dd85")
