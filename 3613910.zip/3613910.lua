-- Lua provided by RyzenAPI
-- Game: Game: Pipeline Crawl

-- MAIN APPLICATION
addappid(3613910)
-- Game: addappid(3613910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3613911, 1, "be8654b02a3d8ef6fb1dbba5be7c2034dea9fa9db03cbb7754875139898e529d")
