-- Lua provided by RyzenAPI
-- Game: Retro Rewind - Video Store Simulator

-- MAIN APPLICATION
addappid(3552140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3552141,0,"8527bf46fe5454e6c8956a042fb1aee9a9792d7f4c73ebe85ab6924dfcc1c0fe")

