-- Lua provided by RyzenAPI
-- Game: Parasite Black

-- MAIN APPLICATION
addappid(2174500)
-- Game: addappid(2174500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174503,0,"4f30c557ea6b487f1f13027e1651b44b80169d0540804cf3ba9a6b9dcf59ba0f")
