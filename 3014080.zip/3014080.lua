-- Lua provided by RyzenAPI
-- Game: AppID 3014080

-- MAIN APPLICATION
addappid(3014080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3014081, 1, "9c8b0e729ef1fce35224045a12393cf5a7069e60692bc9b3bf2d64b0bb37b6a3")
addappid(3319760, 0, "fe92de42a7232fcb703844d0f9644a24611561c408aa574d4dba47f3ee44b769")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3422790)
