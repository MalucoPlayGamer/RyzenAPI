-- Lua provided by SkyAPI 
-- Game: AppID 1819970
addappid(1819970)
addappid(1819971, 1, "0ace174bc99c04485b08adae370e705fafe6ac26f92d1a0759649abd38ed23b6")
