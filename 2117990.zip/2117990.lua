-- Lua provided by RyzenAPI
-- Game: AppID 2117990

-- MAIN APPLICATION
addappid(2117990)
-- Game: addappid(2117990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117991, 1, "0fd97e6b41b3351fd960f047dffbcfb41e3c57ff4ae40422b2ca0ac73f1e3801")
addappid(2117992, 1, "3d0bd1b7e668ddaf2a2c183e35e310dbeb0c3245353ad1b3335de4bafede30a3")
