-- Lua provided by RyzenAPI 
-- Game: Street Football
addappid(1502730)
addappid(1502731, 1, "c260a9a72e88b99da01233890100f8f5009328634ea5caf9b92c75c9ebc565af")
