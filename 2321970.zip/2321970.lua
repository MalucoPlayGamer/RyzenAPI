-- Lua provided by RyzenAPI
-- Game: Game: Not Anyone's Business But My Own

-- MAIN APPLICATION
addappid(2321970)
-- Game: addappid(2321970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321971, 1, "625a578a573cede178a77593445f9645628486bad21571ef7559031fa28bbef6")
addappid(2321972, 1, "41871e2053b698554deae2487b217ac6ae5cf278a95a85ef805e393d2fc3ff0a")
