-- Lua provided by RyzenAPI
-- Game: Nimbatus - Drone Creator

-- MAIN APPLICATION
addappid(228990)
addappid(1243130)
-- Game: addappid(1243130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243132,0,"b3e3cdbc712b808d45d8828bd5e3ef194191dabc4216e7fc3cbfb5cf3c360869")
addappid(1243133,0,"e3595295dcf22ba34115a75d85a832e8b6f06ce61d4882ce9a58d79e9fa60ddf")
addappid(1243134,0,"1caf713f6afe98cdeb719e45352ffb11a61e66dbbe55a1ea59bc0e6cc9d8b0b4")
addappid(1243135,0,"fa4b1b17ef42f60ca96a574d2052883c2d9f49974bc4d51766d5e6e5e16579ed")
