-- Lua provided by RyzenAPI
-- Game: Game: Operation: Tango - Soundtrack

-- MAIN APPLICATION
addappid(1657310)
-- Game: addappid(1657310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657311, 1, "065842dc54202ce0afa1a8f4d11d2d7d129b79b49acd246d6dc3b2c33b853b21")
addappid(1657312, 1, "4914532fd52edc4ec80eafc79326280f62b2c66b8ef672d7a62d765721643f01")
