-- Lua provided by RyzenAPI
-- Game: 英雄黄昏-文字三国志&曹贼模拟器

-- MAIN APPLICATION
addappid(1754720)
addappid(2135430)

