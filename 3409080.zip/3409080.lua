-- Lua provided by RyzenAPI
-- Game: addappid(3409080)

-- MAIN APPLICATION
addappid(3409080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3409080,0,"9c794df2f1d8c6185f39c4dd8046ec48a9304135bac7063e5d7b6190fe22ae7e")
