-- Lua provided by RyzenAPI
-- Game: Game: Mazemerizzz

-- MAIN APPLICATION
addappid(2733310)
-- Game: addappid(2733310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733311, 1, "ff0a889ca9a8371969f3f8d2711b4cc362a4d94c6d2ab28396f4ad8e22d05118")
