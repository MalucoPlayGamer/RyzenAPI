-- Lua provided by RyzenAPI
-- Game: Mazemerizzz

-- MAIN APPLICATION
addappid(2733310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2733311, 1, "ff0a889ca9a8371969f3f8d2711b4cc362a4d94c6d2ab28396f4ad8e22d05118")

