-- Lua provided by RyzenAPI
-- Game: Orgasm Simulator 2024 💦

-- MAIN APPLICATION
addappid(2560640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560641, 1, "5443567f6eb195a91e6dcbf5734c3becc20bfccea9db8eee23a7da7c4f6f422b")
