-- Lua provided by RyzenAPI
-- Game: 1354840

-- MAIN APPLICATION
addappid(1354840)
-- Game: addappid(1354840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1354841, 1, "c2ba42364005cf84fde0a8f87f6022cc99b54805f3a75b85de36c5e0dbfb9b73")
