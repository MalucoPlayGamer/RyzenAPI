-- Lua provided by RyzenAPI
-- Game: Game: Sparkle 2 Evo

-- MAIN APPLICATION
addappid(253650)
-- Game: addappid(253650)

-- MAIN APP DEPOTS / PACKAGES
addappid(253651, 1, "1277572c7898c7c61faf6f819e9bf4b4f8e3c376823d450ebc1671c4c898edf6")
addappid(253652, 1, "fe46998e8d8b73872cb4279a600f7a271e3eaaf57c3eab364626b1008c6f2f1b")
addappid(253653, 1, "4d36b81522079811111378daf08c152f6708da1aaeeddec57dedf8bf33cfb4bb")
addappid(253654, 1, "075d775106ebb1f01261a593776c72b095d9492c5c35016c907f720c55bc5da6")
