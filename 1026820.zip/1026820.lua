-- Lua provided by RyzenAPI
-- Game: Coloring Game

-- MAIN APPLICATION
addappid(1026820)
addappid(1066300)
addappid(1088120)
addappid(1090860)
addappid(1105010)
addappid(1153630)

