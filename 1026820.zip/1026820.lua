-- Lua provided by RyzenAPI
-- Game: Coloring Game

-- MAIN APPLICATION
addappid(1026820)

