-- Lua provided by RyzenAPI
-- Game: Game: IRENE.HOUSE

-- MAIN APPLICATION
addappid(1582310)
-- Game: addappid(1582310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582311, 1, "5cebcd86ed397bc7480611174028de450d73717739750d4045fa163054bcb0ff")
