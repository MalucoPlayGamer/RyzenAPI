-- Lua provided by RyzenAPI
-- Game: IRENE.HOUSE

-- MAIN APPLICATION
addappid(1582310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582311, 1, "5cebcd86ed397bc7480611174028de450d73717739750d4045fa163054bcb0ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
