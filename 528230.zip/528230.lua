-- Lua provided by RyzenAPI
-- Game: AppID 528230

-- MAIN APPLICATION
addappid(528230)
addappid(909610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(528231, 1, "7937ad6e2bdd3c8b315fb90a705835490dcea40b40f03c8f8ecfdd428cbb027e")

