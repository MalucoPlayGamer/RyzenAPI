-- Lua provided by RyzenAPI
-- Game: Game: AppID 528230

-- MAIN APPLICATION
addappid(528230)
addappid(909610)
-- Game: addappid(528230)

-- MAIN APP DEPOTS / PACKAGES
addappid(528231, 1, "7937ad6e2bdd3c8b315fb90a705835490dcea40b40f03c8f8ecfdd428cbb027e")
