-- Lua provided by RyzenAPI
-- Game: addappid(2398530)

-- MAIN APPLICATION
addappid(2398530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398531, 1, "eaa520290c798e625784553f9775625aecc474c7183b88abe9fc1886b95cdd5b")
