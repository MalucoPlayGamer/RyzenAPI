-- Lua provided by RyzenAPI 
-- Game: Top PUA
addappid(2398530)
addappid(2398531, 1, "eaa520290c798e625784553f9775625aecc474c7183b88abe9fc1886b95cdd5b")
