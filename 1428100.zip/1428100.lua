-- Lua provided by RyzenAPI
-- Game: addappid(1428100)

-- MAIN APPLICATION
addappid(1428100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428101, 1, "28bcde7abdd9c002e7aa944b4cb36d53e9e04a4358721d763f82ae6ef4be18bf")
