-- Lua provided by RyzenAPI
-- Game: El Taco Diablo

-- MAIN APPLICATION
addappid(843700)

-- MAIN APP DEPOTS / PACKAGES
addappid(843701,0,"11347b11550b29c89fdabe217033c7ced8bbbdb2b469e652c73b91653ee9217b")

