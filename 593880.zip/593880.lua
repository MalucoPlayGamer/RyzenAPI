-- Lua provided by SkyAPI 
-- Game: AppID 593880
addappid(593880)
addappid(593881, 1, "13f3d5fea40c289a649027d551d92f234cc029e256978b82ee10ed7de96b9982")
