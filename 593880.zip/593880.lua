-- Lua provided by RyzenAPI
-- Game: AppID 593880

-- MAIN APPLICATION
addappid(593880)
-- Game: addappid(593880)

-- MAIN APP DEPOTS / PACKAGES
addappid(593881, 1, "13f3d5fea40c289a649027d551d92f234cc029e256978b82ee10ed7de96b9982")
