-- Lua provided by RyzenAPI
-- Game: AppID 593880

-- MAIN APPLICATION
addappid(593880)

-- MAIN APP DEPOTS / PACKAGES
addappid(593881, 1, "13f3d5fea40c289a649027d551d92f234cc029e256978b82ee10ed7de96b9982")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
