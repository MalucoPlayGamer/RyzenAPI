-- Lua provided by RyzenAPI
-- Game: Sex Shop Simulator: X-RAY DESIRE

-- MAIN APPLICATION
addappid(4148670)

-- MAIN APP DEPOTS / PACKAGES
addappid(4148671,0,"465e3e5940df069d4b8508ab5b77e8ec7de3c50dc67d75c1cd3aa8e9fcc3b3d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
