-- Lua provided by RyzenAPI
-- Game: Cat & Farm Pals

-- MAIN APPLICATION
addappid(3181470)
addappid(3722840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181471, 1, "5066773f16781ea886f5c11a6b839fd41ed71983bb0a7efb147712f5a44e847b")
