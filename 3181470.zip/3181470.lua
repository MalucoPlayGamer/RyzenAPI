-- Lua provided by RyzenAPI
-- Game: addappid(3181470)

-- MAIN APPLICATION
addappid(3181470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181471, 1, "5066773f16781ea886f5c11a6b839fd41ed71983bb0a7efb147712f5a44e847b")
