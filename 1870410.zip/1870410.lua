-- Lua provided by RyzenAPI
-- Game: Gangsta: The Return

-- MAIN APPLICATION
addappid(1870410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870411, 1, "85dae690b58c3de04cde6cc8235c729c45cc6ecec4329f1bae73adc2fb656331")

