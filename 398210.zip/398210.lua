-- Lua provided by RyzenAPI
-- Game: 398210

-- MAIN APPLICATION
addappid(398210)
-- Game: addappid(398210)

-- MAIN APP DEPOTS / PACKAGES
addappid(398211, 1, "8dafbfd3f834be22d4f39f08c5f7bba82ddef4b880cb39593ecf51d4b6b50b89")
