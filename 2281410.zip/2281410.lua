-- Lua provided by RyzenAPI
-- Game: River Town Factory

-- MAIN APPLICATION
addappid(2281410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281411, 1, "1d52d0d15f2e216b6b6c3fc9da43106960eee9d6548facb4afe01d9565017508")
