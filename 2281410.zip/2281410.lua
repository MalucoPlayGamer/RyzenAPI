-- Lua provided by RyzenAPI
-- Game: River Town Factory

-- MAIN APPLICATION
addappid(2281410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2281411, 1, "1d52d0d15f2e216b6b6c3fc9da43106960eee9d6548facb4afe01d9565017508")

