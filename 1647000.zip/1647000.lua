-- Lua provided by RyzenAPI
-- Game: 1647000

-- MAIN APPLICATION
addappid(1647000)
-- Game: addappid(1647000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647002,0,"4f104ebbc39979ad1894eb3a1e9f5f8df5e71734d8851e086658931d407f3a1c")
addappid(1647003,0,"aac4b3d4ad131a3b78465fb3399a314e9c2ff4f10262aad81d9a3ef8407abd8f")
addappid(1647004,0,"3fa1d3ceac36b3deefe23bac4bfe172abffcecab6e1bb2f0bc567af87b85741a")
