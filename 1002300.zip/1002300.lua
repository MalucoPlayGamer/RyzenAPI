-- Lua provided by RyzenAPI
-- Game: Game: Fear & Hunger

-- MAIN APPLICATION
addappid(1002300)
-- Game: addappid(1002300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002301, 1, "5c15e7008bd31b169a8c7559c8346d74c46c8189a505ee65aea28d7d27ce22cc")
addappid(1002302, 1, "7a8f8c0b1734a22cfcd126d37fa5503fe919171c412df3bff9f61ee7d019e5fa")
addappid(1002306, 1, "031c859d72c1f341a09f6e39a87f9c241e1a3f639f39555ca7254c4bd11950c3")
addappid(1002307, 1, "14604d91bef7905e0cc56cdec1678ef0052f5875a382f7bd5f8e9030d74a09c6")
