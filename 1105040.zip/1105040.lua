-- Lua provided by RyzenAPI
-- Game: Alchemist Simulator

-- MAIN APPLICATION
addappid(1105040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105042,0,"9758438ebc026e00e2a0a2718519d5087276ccd67e68987582a8e1a7bedc66f1")

