-- Lua provided by RyzenAPI
-- Game: AppID 557040

-- MAIN APPLICATION
addappid(557040)

-- MAIN APP DEPOTS / PACKAGES
addappid(557041, 1, "f49e43f94812e1cdf9d107a60e620d7a4c47302bf66683e7fd67cf27ff572525")
addappid(557042, 1, "46c88e773bc54ddeaf269e6c1dcef6f9f1cc5680c3923242eb7e11d9182df151")
addappid(557043, 1, "b51a8554d8a4ed4b221715ec969692d801c767e77e273f120f3fed831b37b79b")
addappid(557044, 1, "ec9f08b1282ede1c90f33c76cc6d4f963044eab155246000d562be39674e57d6")
addappid(574020, 0, "e2767c1e2d47970910bfac4793d214a61c1a1efdd0dca6d36623c3e5bf5b0930")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
