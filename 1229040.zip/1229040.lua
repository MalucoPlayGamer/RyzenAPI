-- Lua provided by RyzenAPI
-- Game: Who's Your Daddy Classic Soundtrack (2015)

-- MAIN APPLICATION
addappid(1229040)
-- Game: addappid(1229040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229041, 1, "dc0a04388f651b5a2cd3f2886904dfa11e5412468b607c77d682a2d747724d54")
