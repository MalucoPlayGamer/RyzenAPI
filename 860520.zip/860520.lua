-- Lua provided by RyzenAPI
-- Game: AppID 860520

-- MAIN APPLICATION
addappid(860520)

-- MAIN APP DEPOTS / PACKAGES
addappid(860521, 1, "c20a66f8b17e137d302ef8e2a1cb90682de33f10e6c1c25cbec9746d25ee1602")

