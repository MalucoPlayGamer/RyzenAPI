-- Lua provided by RyzenAPI
-- Game: 1687020

-- MAIN APPLICATION
addappid(1687020)
-- Game: addappid(1687020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1687021, 1, "e4503a6e1e1ec0e2ae3be15b7addcd0c8ae32dbb0e7cfa5a332b02f97a5f1334")
