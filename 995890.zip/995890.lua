-- Lua provided by RyzenAPI
-- Game: AppID 995890

-- MAIN APPLICATION
addappid(995890)
-- Game: addappid(995890)

-- MAIN APP DEPOTS / PACKAGES
addappid(995891, 1, "3dd5dc62b2aa1f47a29afc5d4713123f13ab17a17a6e22fe11506ce3bc566dac")
