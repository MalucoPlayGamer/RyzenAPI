-- Lua provided by RyzenAPI
-- Game: AppID 1108320

-- MAIN APPLICATION
addappid(1108320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108321, 1, "f7e4a5a5bff6c84a73b75d8664b53a1f74bb77e1ce85eec06c4dfa04ff99a051")
addappid(1108322, 1, "ded489b573cd7d82c3d1e67cabd358b3be9369b0a7d539850589e996a5fc3423")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1284010)
