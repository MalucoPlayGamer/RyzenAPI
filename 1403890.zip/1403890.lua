-- Lua provided by RyzenAPI
-- Game: addappid(1403890)

-- MAIN APPLICATION
addappid(1403890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403891, 1, "49ef37afbc7ea10312a21d5d62d3b15fb9a433b128b7b166b0362d0a133de7dc")
