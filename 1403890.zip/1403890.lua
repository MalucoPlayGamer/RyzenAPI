-- Lua provided by RyzenAPI
-- Game: SmFly: Gravity Adventure

-- MAIN APPLICATION
addappid(1403890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403891, 1, "49ef37afbc7ea10312a21d5d62d3b15fb9a433b128b7b166b0362d0a133de7dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
