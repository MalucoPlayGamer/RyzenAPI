-- Lua provided by RyzenAPI 
-- Game: Card Survival: Tropical Island
addappid(1694420)
addappid(1694421, 1, "0ee0b42b1a7ee30211e35c2a4dbda4cfce3010d74b6706db2216e681d7ef942b")
addappid(1694422, 1, "1139d506c6b1951e36e015c52f956578d972181d441a941abbca743023957296")
