-- Lua provided by RyzenAPI
-- Game: TAL: Arctic 5

-- MAIN APPLICATION
addappid(2283310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283311, 1, "1965ee8973c1bbcb2e66efd3bfa3b08bc6e52f8943909fadb29783e4b391cf39")
