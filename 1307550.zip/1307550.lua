-- Lua provided by RyzenAPI
-- Game: addappid(1307550)

-- MAIN APPLICATION
addappid(1307550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307551, 1, "12f11842a788e0b656032cfbaf79b2ee2e74e3f7715e25ddd2efe5c0a33afc35")
