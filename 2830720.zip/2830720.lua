-- Lua provided by RyzenAPI
-- Game: FreeInfantry

-- MAIN APPLICATION
addappid(2830720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830721, 1, "28ac5ab944a46135989b095fdfd950cb9b159902d4f4c0de04b3e97f771eeb1d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
