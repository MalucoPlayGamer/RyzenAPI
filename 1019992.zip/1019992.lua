-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Additional Weapon "Iron Flute" / 追加武器「鉄笛」

-- MAIN APPLICATION
addappid(1019992)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019992,0,"ab543be4da40040c398b2870c79ba30a1a6c60c9fd30ce81895f8a86e1a66fdd")
