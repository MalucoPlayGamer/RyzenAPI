-- Lua provided by RyzenAPI
-- Game: addappid(1432760)

-- MAIN APPLICATION
addappid(1432760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432761, 1, "2cde38bf3598ec51b1d1a4d319de89f07aa11ca11d90cb413fdd2127ecf20fa1")
