-- Lua provided by RyzenAPI
-- Game: Hidden Town

-- MAIN APPLICATION
addappid(1778470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778471, 1, "c1a1a55c520b6ebbca18e196b9bf69c2798a66e4df7cfd7be3640827a801f0ac")

