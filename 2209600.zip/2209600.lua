-- Lua provided by RyzenAPI
-- Game: addappid(2209600)

-- MAIN APPLICATION
addappid(2209600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209601, 1, "8af0028ac086e53f843e779ef33474f0f35cc69a796abd306377e3aac55532f5")
