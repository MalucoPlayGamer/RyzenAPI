-- Lua provided by RyzenAPI
-- Game: Expendable

-- MAIN APPLICATION
addappid(804000)

-- MAIN APP DEPOTS / PACKAGES
addappid(804001, 1, "3912a5e6cdb73fc27a6c8c46b0a5372185ef48b4919e1ca4ad6d955b76906eaf")

