-- Lua provided by RyzenAPI
-- Game: Nihiland

-- MAIN APPLICATION
addappid(3011550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011551, 1, "1b764d0753d1e9cd3ac72e1d6f8d42def1731b35f01507ced96cf64a8310f890")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
