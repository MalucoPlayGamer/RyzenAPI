-- Lua provided by RyzenAPI
-- Game: addappid(3011550)

-- MAIN APPLICATION
addappid(3011550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011551, 1, "1b764d0753d1e9cd3ac72e1d6f8d42def1731b35f01507ced96cf64a8310f890")
