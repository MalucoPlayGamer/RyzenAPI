-- Lua provided by RyzenAPI
-- Game: 784100

-- MAIN APPLICATION
addappid(228990)
addappid(784100)
addappid(784103)
-- Game: addappid(784100)

-- MAIN APP DEPOTS / PACKAGES
addappid(784104,0,"55711949a1239ba901320de1b084161810187516b27c91a278d4fb8e92c99a23")
