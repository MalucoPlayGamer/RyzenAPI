-- Lua provided by RyzenAPI
-- Game: addappid(953490)

-- MAIN APPLICATION
addappid(953490)

-- MAIN APP DEPOTS / PACKAGES
addappid(953491, 1, "ba3221161cac581738cb2433d5658bd0258dea2cedd2bdcbe9dec3d8d5841183")
addappid(953492, 1, "09d7515c8233fe027d26fddb81052399bdfcfe5634ca6174a9b06f55d890e2f3")
addappid(953493, 1, "76be4b55c7e4efef7b2bda7cdc00df1ecaf235c2e6badebad025e7e63cc2346a")
addappid(953494, 1, "06c1cacc01a95017aaf62947d83d93d43db7a11412efea87b5718a307cdb0e16")
addappid(953495, 1, "86622a0179e594dd3943fe09b241193b4dc37b5d7861e61abf7b18aaff7cdd71")
