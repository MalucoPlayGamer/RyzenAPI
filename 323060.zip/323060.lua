-- Lua provided by RyzenAPI
-- Game: AppID 323060

-- MAIN APPLICATION
addappid(323060)
-- Game: addappid(323060)

-- MAIN APP DEPOTS / PACKAGES
addappid(323061, 1, "c512aa03721dea88cabc9b3cdc003ea06a7125e7f26ecb919e3cfe741b42d1d9")
addappid(323062, 1, "f3a4b9cb8aadc2c18d5140d08e5972c7044bebeb3348a4ef1bd0c12c73162d9b")
