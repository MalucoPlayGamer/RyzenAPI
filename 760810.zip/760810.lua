-- Lua provided by RyzenAPI
-- Game: setManifestid(760812,"4161060321310933187")

-- MAIN APPLICATION
addappid(760810)
-- Game: addappid(760810)

-- MAIN APP DEPOTS / PACKAGES
addappid(760812,0,"38e0bd296896e09e5b2dd6dc206695992ea2cda762863b60db81da6aeea46f9f")
