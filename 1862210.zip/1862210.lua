-- Lua provided by RyzenAPI
-- Game: 1862210

-- MAIN APPLICATION
addappid(1862210)
-- Game: addappid(1862210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862211, 1, "526634ce603fed6951b69f89becbcb9c12de6c455298fa1974dbbc017e701542")
