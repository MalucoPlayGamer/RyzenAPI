-- Lua provided by RyzenAPI
-- Game: addappid(412250)

-- MAIN APPLICATION
addappid(412250)

-- MAIN APP DEPOTS / PACKAGES
addappid(412251, 1, "0b02d8e60eb62f79b6cc19b068a6859129c4bc613fb01773c702dbc6119606bf")
