-- Lua provided by RyzenAPI
-- Game: Game: AppID 861460

-- MAIN APPLICATION
addappid(861460)
-- Game: addappid(861460)

-- MAIN APP DEPOTS / PACKAGES
addappid(861461, 1, "8841f9238d7d83262d2846cabeb2a0c6d18350e37c509ed5cf6ec45d63484318")
