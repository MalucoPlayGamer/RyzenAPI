-- Lua provided by RyzenAPI
-- Game: Ascendrix

-- MAIN APPLICATION
addappid(3207360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3207361, 1, "a3cfd72b01c25d8c05b8b9c48506c990df93c7f096d5595deacbfe06137ca050")

