-- Lua provided by RyzenAPI
-- Game: 3207360

-- MAIN APPLICATION
addappid(3207360)
-- Game: addappid(3207360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207361, 1, "a3cfd72b01c25d8c05b8b9c48506c990df93c7f096d5595deacbfe06137ca050")
