-- Lua provided by RyzenAPI
-- Game: DayZ Tools

-- MAIN APPLICATION
addappid(830640)
-- Game: addappid(830640)

-- MAIN APP DEPOTS / PACKAGES
addappid(830641, 1, "3e61bff301ba32c46755dfa2807e6b54e9482e44f9732d0a166ff258cc0a20c3")
