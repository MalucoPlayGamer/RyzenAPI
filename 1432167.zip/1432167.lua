-- Lua provided by RyzenAPI
-- Game: FUSER™ - Maroon 5 - "Maps"

-- MAIN APPLICATION
addappid(1432167)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432167,0,"5feb02c67bd6560dfb599b84302d61c10677748ee3f1efd054bfb6fa0c266af4")

