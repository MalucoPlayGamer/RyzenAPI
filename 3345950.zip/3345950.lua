-- Lua provided by RyzenAPI
-- Game: Capote

-- MAIN APPLICATION
addappid(3345950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3345951,0,"59212d7bdda81bd66f1d168eccc6c7857df7d922101e3b25190d44418966ef7b")

