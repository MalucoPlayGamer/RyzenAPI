-- Lua provided by RyzenAPI
-- Game: Capote

-- MAIN APPLICATION
addappid(3345950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345951,0,"59212d7bdda81bd66f1d168eccc6c7857df7d922101e3b25190d44418966ef7b")

