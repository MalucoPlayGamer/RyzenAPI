-- Lua provided by RyzenAPI
-- Game: Pixel Piracy

-- MAIN APPLICATION
addappid(264140)
addappid(2314920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(264141, 1, "58a18168231b4cde2a56a5264db6cf2d4abfe30b33d46e845a9b3649cb926041")
addappid(264142, 1, "d73ff3adcf8eb108b37be6f6f92bb6991f20dc15fa29a0c383f8ba26ab577859")
addappid(264143, 1, "38baaf38cff6582daac14b9ac615186f3ec704c7edb3adc2945ba613c84b2977")
addappid(365970, 0, "635ab13dedd745136361f48389694cc84e48131dda6716bcf9a40b44f07897f9")
