-- Lua provided by RyzenAPI
-- Game: SUMETRICK

-- MAIN APPLICATION
addappid(771950)

-- MAIN APP DEPOTS / PACKAGES
addappid(771951, 1, "6a7e66435492716761bf74788f276c6e2fa7f0059dd02e445e897b82487fd966")
addappid(776800, 0, "973440b104ba8292605ff7ea4e7a5c6431e3ab9ced2d36ae0211bb2edcfe1c98")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
