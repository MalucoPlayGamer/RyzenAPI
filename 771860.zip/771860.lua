-- Lua provided by RyzenAPI
-- Game: addappid(771860)

-- MAIN APPLICATION
addappid(771860)

-- MAIN APP DEPOTS / PACKAGES
addappid(771861, 1, "27fae1d1e7b6a1a2a8bf274b6f73dc81e552da4d6e6c5a986afee930c8613819")
