-- Lua provided by RyzenAPI
-- Game: HARVEST

-- MAIN APPLICATION
addappid(3614960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614961, 1, "7edee2226dd9cf35bd41d443f9e80a90f90dda6290017fbb4f909b82cce7851c")

