-- Lua provided by RyzenAPI
-- Game: Game: THE WALLWAY

-- MAIN APPLICATION
addappid(3253990)
-- Game: addappid(3253990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253991, 1, "43974538cc51a20b9fbe9a9dda6c06485e5814a390f8e8b26a696234397fe322")
