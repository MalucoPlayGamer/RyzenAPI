-- Lua provided by RyzenAPI
-- Game: AppID 344960

-- MAIN APPLICATION
addappid(344960)
-- Game: addappid(344960)

-- MAIN APP DEPOTS / PACKAGES
addappid(344961, 1, "4434da19b4d161f09f7f972067d888627d63fa2fcdfa807197e2d924e7041c46")
