-- Lua provided by RyzenAPI
-- Game: addappid(2492420)

-- MAIN APPLICATION
addappid(2492420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492421, 1, "cd07aec68be4c9197ff4aff84dea75f3fed83da64a20d9025bdcf83534db6124")
