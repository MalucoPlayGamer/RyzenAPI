-- Lua provided by RyzenAPI
-- Game: Game: Apocalypse Love Shelter

-- MAIN APPLICATION
addappid(2782280)
-- Game: addappid(2782280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782281, 1, "09c172d0b606c32701c27e5404f5a36c679fccf2b3eea8569b4580b717a3c300")
