-- Lua provided by RyzenAPI
-- Game: Shred Off

-- MAIN APPLICATION
addappid(2707400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2707401, 1, "06f2eacfbe5a8ca38f14d2b3251ae990255386a40099c0250fe399ec9ba4d413")

