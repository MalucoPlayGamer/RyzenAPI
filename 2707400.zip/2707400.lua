-- Lua provided by RyzenAPI 
-- Game: Shred Off
addappid(2707400)
addappid(2707401, 1, "06f2eacfbe5a8ca38f14d2b3251ae990255386a40099c0250fe399ec9ba4d413")
