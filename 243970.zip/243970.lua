-- Lua provided by RyzenAPI
-- Game: AppID 243970

-- MAIN APPLICATION
addappid(243970)

-- MAIN APP DEPOTS / PACKAGES
addappid(243971, 1, "aec8bcec0402c611d88d018636894d0d43516913fce2298380491ba1c5cf1918")
addappid(243972, 1, "576d4580a34d6252288fe77326b0b35c11549523ee979510a27424d9bcd6a50c")
addappid(243973, 1, "dce1f2beedc8484f242d82eceb494bda967507eecb0648d8d71aee2ebf16455f")
addappid(243974, 1, "b05ee6a959c914c012ab37f80aa8a16bb67a58637a1effaa9b5ba4fe504430b9")
addappid(370650, 0, "b6da2caade99cf3f5b70f7edc67c0355360e2199ee0bf9d7d43751afcfd2d76f")
addappid(376981, 0, "798cd7bce3ea7bb8e544a7db882d34713e272507503fa668257884581fa52eea")
addappid(376982, 0, "2551c63783cb4d374d6a071a048ddaac34910e169ed88f076f92e1e442ee3362")
addappid(376983, 0, "8abf0093f48b90348385068696a1b62a2f09dd117b293da49f44222403647d52")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(376980)
