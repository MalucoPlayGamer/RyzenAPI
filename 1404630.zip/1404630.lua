-- Lua provided by RyzenAPI
-- Game: All Hit All Her

-- MAIN APPLICATION
addappid(1404630)
addappid(1814680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404631, 1, "4b78c0859fab7f37dc0e5fcb12586be485e7f2dd97b1aa4c29c90dbc489f924c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
