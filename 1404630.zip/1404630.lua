-- Lua provided by RyzenAPI
-- Game: All Hit All Her

-- MAIN APPLICATION
addappid(1404630)
addappid(1814680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404631, 1, "4b78c0859fab7f37dc0e5fcb12586be485e7f2dd97b1aa4c29c90dbc489f924c")

