-- Lua provided by RyzenAPI
-- Game: Loretta Digital ArtBook

-- MAIN APPLICATION
addappid(2346520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346520,0,"79409b12f4660a84f24cd05b702f6bc78703590501c11ec0fbb7be4a2de5df2b")

