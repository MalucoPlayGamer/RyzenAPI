-- Lua provided by RyzenAPI
-- Game: Game: Super Slam Dunk Touchdown

-- MAIN APPLICATION
addappid(388260)
-- Game: addappid(388260)

-- MAIN APP DEPOTS / PACKAGES
addappid(388261, 1, "1ca4943345802bff4b475ebb9dc185a1efc3600aad160adfa4856e08a11c40a1")
