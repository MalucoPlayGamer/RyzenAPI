-- Lua provided by RyzenAPI
-- Game: Urban Strife

-- MAIN APPLICATION
addappid(710230)

-- MAIN APP DEPOTS / PACKAGES
addappid(710232,0,"29cc40f22a6ee8ac5b670831c28e2b65b6a26460fcd3b53a7adafbd50f15adea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
