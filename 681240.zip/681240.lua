-- Lua provided by RyzenAPI
-- Game: Dujanah

-- MAIN APPLICATION
addappid(681240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(681241, 1, "8db9d882268d5fbfd35850fe4bffa8c335da7293ded923810ee8317c4d1da839")

