-- Lua provided by RyzenAPI
-- Game: 681240

-- MAIN APPLICATION
addappid(681240)
-- Game: addappid(681240)

-- MAIN APP DEPOTS / PACKAGES
addappid(681241, 1, "8db9d882268d5fbfd35850fe4bffa8c335da7293ded923810ee8317c4d1da839")
