-- Lua provided by RyzenAPI
-- Game: Close to Flight Demo

-- MAIN APPLICATION
addappid(3041870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041871, 1, "37063f96835922757f86e4ada5181f93bbb1142d968fa7fc2d0c741dc66985a0")

