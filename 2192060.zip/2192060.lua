-- Lua provided by SkyAPI 
-- Game: NASCAR Arcade Rush
addappid(2192060)
addappid(2192061, 1, "50a610e64f6827929f2a07fa83789155a752a2e8ded62f37b54574d2a2ef65bb")
addappid(2418390)
