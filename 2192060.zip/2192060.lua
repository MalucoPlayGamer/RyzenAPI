-- Lua provided by RyzenAPI
-- Game: NASCAR Arcade Rush

-- MAIN APPLICATION
addappid(2192060)
addappid(2418390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2192061, 1, "50a610e64f6827929f2a07fa83789155a752a2e8ded62f37b54574d2a2ef65bb")

