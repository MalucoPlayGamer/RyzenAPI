-- Lua provided by SkyAPI 
-- Game: Shelldom
addappid(3477800)
addappid(3477801, 1, "7830dcca7a25b1ad0913f91b22e97412c3c2a86dc1a24a9e01e103d7fe180988")
