-- Lua provided by RyzenAPI
-- Game: Shelldom

-- MAIN APPLICATION
addappid(3477800)
-- Game: addappid(3477800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3477801, 1, "7830dcca7a25b1ad0913f91b22e97412c3c2a86dc1a24a9e01e103d7fe180988")
