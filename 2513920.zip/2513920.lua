-- Lua provided by RyzenAPI
-- Game: addappid(2513920)

-- MAIN APPLICATION
addappid(2513920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2513921, 1, "0e021ee3787b77d7859350c20dfdd85353bfa76f1c186ecaa195a7ac15c8d846")
