-- Lua provided by RyzenAPI
-- Game: DOOM 64

-- MAIN APPLICATION
addappid(1148590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1148591, 1, "81e323e091fc79632b94020332d7f5f4c5767b99fbf257ed30d61716370b01bc")
addappid(1148592, 1, "bc4c97f55279905b9b59959067e5103d47a0efd4464607c1b659fe7ed2790d24")
