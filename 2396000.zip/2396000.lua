-- Lua provided by RyzenAPI
-- Game: Poly Jigsaw: Dinosaurs

-- MAIN APPLICATION
addappid(2396000)
-- Game: addappid(2396000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396001, 1, "e38b1de502edd23907b389128e3c591fe227270d6088a3825318c98a038b49c6")
