-- Lua provided by RyzenAPI
-- Game: 404100

-- MAIN APPLICATION
addappid(404100)
-- Game: addappid(404100)

-- MAIN APP DEPOTS / PACKAGES
addappid(404101, 1, "a8720c3275fe87e1f936866d2d61de2ec34f05f455b5837e36e78f57f3489668")
