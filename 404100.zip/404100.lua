-- Lua provided by RyzenAPI
-- Game: STEEL STRIDER

-- MAIN APPLICATION
addappid(404100)

-- MAIN APP DEPOTS / PACKAGES
addappid(404101, 1, "a8720c3275fe87e1f936866d2d61de2ec34f05f455b5837e36e78f57f3489668")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
