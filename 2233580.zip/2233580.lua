-- Lua provided by RyzenAPI
-- Game: Monkey See Monkey Doo Doo

-- MAIN APPLICATION
addappid(2233580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233581, 1, "3b598cacbc064524d61e3bc81d1fa8e495aba37c9930b23b8d6228530b4516ed")
