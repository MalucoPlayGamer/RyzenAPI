-- Lua provided by RyzenAPI 
-- Game: 像素男友 语音完整版
addappid(1478410)
addappid(1478411, 1, "381da03a72b6b27a66f0cb30b21e7132c4bfd11e82c886b64b81863f76643da2")
