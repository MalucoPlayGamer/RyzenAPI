-- Lua provided by RyzenAPI
-- Game: addappid(1478410)

-- MAIN APPLICATION
addappid(1478410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478411, 1, "381da03a72b6b27a66f0cb30b21e7132c4bfd11e82c886b64b81863f76643da2")
