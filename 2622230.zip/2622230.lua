-- Lua provided by RyzenAPI 
-- Game: Kungfu
addappid(2622230)
addappid(2622231, 1, "8cc538ddf15b12839c4fc349de470032cd56158e2e371f4617a830cb59b42d29")
