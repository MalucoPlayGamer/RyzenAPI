-- Lua provided by SkyAPI 
-- Game: 逐鹿
addappid(1984720)
addappid(1984721, 1, "ab4edfd9e483e8ec0298e01cd8fd21bfbfae98d9f60fae744c4fa7648a15ff11")
