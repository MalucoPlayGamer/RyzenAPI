-- Lua provided by RyzenAPI
-- Game: Rich Lady's Slave Role Play

-- MAIN APPLICATION
addappid(1925010)
-- Game: addappid(1925010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925011, 1, "5bf7f4b1cd0074d1a29eb4db0a15be6e08402d7f8c6197cddf4dc01be9e64099")
