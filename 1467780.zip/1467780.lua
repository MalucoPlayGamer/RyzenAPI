-- Lua provided by RyzenAPI
-- Game: Geminism

-- MAIN APPLICATION
addappid(1467780)
-- Game: addappid(1467780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467781, 1, "99bdd46d11583e94604e031969f1b5d20d4484dfa4a9c2fd571453749f48d2b6")
