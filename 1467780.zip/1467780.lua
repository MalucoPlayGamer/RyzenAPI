-- Lua provided by SkyAPI 
-- Game: Geminism
addappid(1467780)
addappid(1467781, 1, "99bdd46d11583e94604e031969f1b5d20d4484dfa4a9c2fd571453749f48d2b6")
