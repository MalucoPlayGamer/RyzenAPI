-- Lua provided by RyzenAPI
-- Game: Game: AppID 636070

-- MAIN APPLICATION
addappid(636070)
-- Game: addappid(636070)

-- MAIN APP DEPOTS / PACKAGES
addappid(636071, 1, "f36ed0f8218fc3dc58a89d9201890b50bb82ee3dd73ad7609ff95e0a81d8ad12")
addappid(636072, 1, "046645d453bde05a4937397d76bb87f972bba5259182680727f6cc47a9ed7ef9")
addappid(636073, 1, "454b6fd704b24abdbf314826f88bfc6f051378986f3aabdeb4aa7d14b6770fa6")
addappid(636074, 1, "ac0e51658a4cd8ba61f296dc9cee1312e1d9ef47f3cb950049d122edeb1cf767")
