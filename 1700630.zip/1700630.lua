-- Lua provided by RyzenAPI
-- Game: 天下镖局

-- MAIN APPLICATION
addappid(1700630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700632,0,"1eefedd98e95700feeb6c19582d63f717542605e52c7f9cca4841356636cfd19")

