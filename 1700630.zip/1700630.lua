-- Lua provided by RyzenAPI
-- Game: setManifestid(1700632,"7970925182017413844")

-- MAIN APPLICATION
addappid(1700630)
-- Game: addappid(1700630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700632,0,"1eefedd98e95700feeb6c19582d63f717542605e52c7f9cca4841356636cfd19")
