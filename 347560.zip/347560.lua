-- Lua provided by RyzenAPI
-- Game: Terra Incognita Chapter One: The Descendant

-- MAIN APPLICATION
addappid(347560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(347561, 1, "cec2163648e5764993cc34554281852029ae1ee835329c3d70d640ea410affcb")

