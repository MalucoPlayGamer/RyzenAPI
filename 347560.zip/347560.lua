-- Lua provided by RyzenAPI
-- Game: addappid(347560)

-- MAIN APPLICATION
addappid(347560)

-- MAIN APP DEPOTS / PACKAGES
addappid(347561, 1, "cec2163648e5764993cc34554281852029ae1ee835329c3d70d640ea410affcb")
