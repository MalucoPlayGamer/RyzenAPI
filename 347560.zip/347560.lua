-- Lua provided by SkyAPI 
-- Game: Terra Incognita Chapter One: The Descendant
addappid(347560)
addappid(347561, 1, "cec2163648e5764993cc34554281852029ae1ee835329c3d70d640ea410affcb")
