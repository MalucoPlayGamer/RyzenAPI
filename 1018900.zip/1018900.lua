-- Lua provided by RyzenAPI 
-- Game: AppID 1018900
addappid(1018900)
addappid(1018901, 1, "fc49df7e2348407b1c35cfc7346bab7f3951fc40decda2c2d1dc7d449f608c83")
