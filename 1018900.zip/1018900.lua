-- Lua provided by RyzenAPI
-- Game: Let's Learn Japanese! Katakana

-- MAIN APPLICATION
addappid(1018900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1018901, 1, "fc49df7e2348407b1c35cfc7346bab7f3951fc40decda2c2d1dc7d449f608c83")
