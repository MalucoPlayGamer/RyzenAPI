-- Lua provided by RyzenAPI
-- Game: Dune Rancher

-- MAIN APP DEPOTS / PACKAGES
addappid(4319210, 1, "569f96dee08c763ce7897b6782f5cf9dfc9ee28fafb5b4aad2106af0025b3b34") -- Dune Rancher
addappid(4319211, 1, "de3b2e13a1f2760836916dfb4c7ac247cd16a5e3dc4aff5502a15df5e0ddc7ae") -- Depot 4319211
addappid(4319212, 1, "fa0dcefb6139066e11f2d25297a100416ac3ef56e5d96cbee17a58e2f9a93c16") -- Depot 4319212

