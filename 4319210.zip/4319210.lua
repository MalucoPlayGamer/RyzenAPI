-- 4319210's Lua and Manifest Created by Hubcap Manifest
-- Dune Rancher
-- Created: August 05, 2026 at 22:44:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4319210, 1, "569f96dee08c763ce7897b6782f5cf9dfc9ee28fafb5b4aad2106af0025b3b34") -- Dune Rancher
-- MAIN APP DEPOTS
addappid(4319211, 1, "de3b2e13a1f2760836916dfb4c7ac247cd16a5e3dc4aff5502a15df5e0ddc7ae") -- Depot 4319211
setManifestid(4319211, "6109605125084598901", 49182638)
addappid(4319212, 1, "fa0dcefb6139066e11f2d25297a100416ac3ef56e5d96cbee17a58e2f9a93c16") -- Depot 4319212
setManifestid(4319212, "1861578097766771438", 331682464)