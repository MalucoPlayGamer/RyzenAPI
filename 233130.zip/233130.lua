-- Lua provided by RyzenAPI
-- Game: addappid(233130)

-- MAIN APPLICATION
addappid(233130)
addappid(254670)
addappid(254671)
addappid(254672)
addappid(255580)
addappid(2550000)

-- MAIN APP DEPOTS / PACKAGES
addappid(233131, 1, "e49efbcac7fadc110b71ffb3bd9beda4c26e9fad773b1908421308fcb6acd436")
addappid(233132, 1, "4097c14b856d417fb04cabb6d3ebc7d150030b99e7e14cd5022c24d9b58d56e9")
addappid(254673, 0, "a6d47bd12f8f037384afc892b5610560c78a6ae4c1853cd5b31fab4be4b32a3a")
addappid(254674, 0, "2f891797235cdd181db04cebe903a75ec5eb840af3f27a01d06107347bd974c0")
addappid(254675, 0, "9ba715d0a7ad237032ebfb8c8d22c82d40e42552d664d8e381dd69fc2dae8067")
addappid(254676, 0, "205d45573cef11347f8acb7411d9ed9e568cf41184e8724cfef2743353d36460")
