-- Lua provided by RyzenAPI
-- Game: Russian Village Simulator on Mars

-- MAIN APPLICATION
addappid(2800460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(2800461, 1, "184766163b4f65bd8b93be7220edd5f9c4bdcf6a9163ce975ae2130044fb5971")
addappid(2800465, 1, "1ac74dc9445e1fdcfc206bd22cfe0e86082641508797a7d37a2e74183c633899")

