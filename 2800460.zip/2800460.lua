-- Lua provided by RyzenAPI
-- Game: Russian Village Simulator on Mars

-- MAIN APPLICATION
addappid(2800460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800461, 1, "184766163b4f65bd8b93be7220edd5f9c4bdcf6a9163ce975ae2130044fb5971")
addappid(2800465, 1, "1ac74dc9445e1fdcfc206bd22cfe0e86082641508797a7d37a2e74183c633899")

