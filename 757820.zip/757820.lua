-- Lua provided by RyzenAPI
-- Game: Flowing Lights

-- MAIN APPLICATION
addappid(757820)

-- MAIN APP DEPOTS / PACKAGES
addappid(757821,0,"5a2319fd558128a1a8d01407af0e688b1824ad809daaac91a5c857d65d3725f5")

