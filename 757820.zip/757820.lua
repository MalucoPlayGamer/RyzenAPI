-- Lua provided by RyzenAPI
-- Game: Flowing Lights

-- MAIN APPLICATION
addappid(757820)

-- MAIN APP DEPOTS / PACKAGES
addappid(757821,0,"5a2319fd558128a1a8d01407af0e688b1824ad809daaac91a5c857d65d3725f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
