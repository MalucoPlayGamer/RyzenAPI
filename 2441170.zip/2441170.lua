-- Lua provided by RyzenAPI 
-- Game: MagicShop2
addappid(2441170)
addappid(2441171, 1, "c51f8c407a5471645fbe34dd790416f2e82522f60f19a089aa8198ebcf9b297c")
