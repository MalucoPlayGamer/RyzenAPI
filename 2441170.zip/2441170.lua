-- Lua provided by RyzenAPI
-- Game: MagicShop2

-- MAIN APPLICATION
addappid(2441170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2441171, 1, "c51f8c407a5471645fbe34dd790416f2e82522f60f19a089aa8198ebcf9b297c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
