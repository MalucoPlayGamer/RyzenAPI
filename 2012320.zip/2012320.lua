-- Lua provided by RyzenAPI
-- Game: 2012320

-- MAIN APPLICATION
addappid(2012320)
-- Game: addappid(2012320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012321, 1, "bcdcac45ea040db57ec42574707273f04ec7f21be80e16b4b0ad0e920c34a3b2")
