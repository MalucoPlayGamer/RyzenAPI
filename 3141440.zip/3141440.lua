-- Lua provided by RyzenAPI
-- Game: Game: Get Tilted :) Demo

-- MAIN APPLICATION
addappid(3141440)
-- Game: addappid(3141440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141441, 1, "f603a5a560df7af915bcbc892a39d3d4e4b7e0c6fab7e66d71ae58ac47beff90")
