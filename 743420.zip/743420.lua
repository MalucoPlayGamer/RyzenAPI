-- Lua provided by RyzenAPI
-- Game: addappid(743420)

-- MAIN APPLICATION
addappid(743420)
addappid(802590)

-- MAIN APP DEPOTS / PACKAGES
addappid(743421, 1, "99e860a3c1bc5a0ebf21ce7608b48cd3d027b20906f0bba9db789b7f754b0ef6")
