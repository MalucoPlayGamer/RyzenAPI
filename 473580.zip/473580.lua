-- Lua provided by RyzenAPI
-- Game: Wyatt Derp 2: Peacekeeper

-- MAIN APPLICATION
addappid(473580)
addappid(492040)

-- MAIN APP DEPOTS / PACKAGES
addappid(473581, 1, "b60827b74552b6610432850c520df31e9ed15d23e563b8f48facb51545ed5577")
