-- Lua provided by RyzenAPI
-- Game: The Seven Realms: High Lathión

-- MAIN APPLICATION
addappid(2580130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2580132,0,"5a73798d8903015918ca9170611938e57b16e955176c82c1abc7706d58496890")

