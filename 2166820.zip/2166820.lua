-- Lua provided by RyzenAPI
-- Game: 史莱姆冒险战SlimeWarfare

-- MAIN APPLICATION
addappid(2166820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166821, 1, "abb7c3371736185169fb81861e75402c0a998dcf55640263794055e42228cf3f")
