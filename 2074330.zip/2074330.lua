-- Lua provided by RyzenAPI 
-- Game: Femboys & Fries
addappid(2074330)
addappid(2074331, 1, "8013d2e6a6a809a02095766e1abd612ba73c43de45796cbc3a17b35723fdc2c7")
