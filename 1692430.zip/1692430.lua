-- Lua provided by RyzenAPI
-- Game: Game: Larry The Unlucky Part 1

-- MAIN APPLICATION
addappid(1692430)
-- Game: addappid(1692430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692431, 1, "bb1c46331773302e5d35073dfc90aa673718764370f9fc4731e12807882e0310")
