-- Lua provided by RyzenAPI
-- Game: Game: MOBIUS BAND*

-- MAIN APPLICATION
addappid(2123380)
-- Game: addappid(2123380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123381, 1, "82ffb4dea8b556a006a69c44572f1212775a69112dc141b0b52ff3774adf3849")
