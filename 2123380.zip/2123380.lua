-- Lua provided by RyzenAPI
-- Game: MOBIUS BAND*

-- MAIN APPLICATION
addappid(2123380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123381, 1, "82ffb4dea8b556a006a69c44572f1212775a69112dc141b0b52ff3774adf3849")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
