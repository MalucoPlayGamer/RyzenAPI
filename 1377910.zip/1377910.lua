-- Lua provided by RyzenAPI
-- Game: Zodiac Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1377910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377910,0,"3d058f6398a38fc7268fe291fed234439e93f759342ed7372dbd30194b659f77")

