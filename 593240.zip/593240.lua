-- Lua provided by RyzenAPI
-- Game: VR SUPER SPORTS

-- MAIN APPLICATION
addappid(593240)

-- MAIN APP DEPOTS / PACKAGES
addappid(593241, 1, "bccf5c2a3c9d2f5c8d487586d2ecb2fc2ce09aab743776d719742f8ab0553267")
addappid(593243, 1, "4faa1335e1ed0b7f3712080ba8b4a77cecbc5d92bd042f5ffac5030dc40addb5")
addappid(593244, 1, "381182757bb24b2cd23ef46ab759a3e731723ef45ec4cb5eaa2ffc48f4613e85")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(647370)
addappid(647371)
addappid(789640)
