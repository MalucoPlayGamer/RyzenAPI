-- Lua provided by RyzenAPI
-- Game: Summer With You

-- MAIN APPLICATION
addappid(1916450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916451, 1, "14a13214f42e0ecf738672a94b4b2cbf0a4334e7283bf2a7fd44cca51955b735")

