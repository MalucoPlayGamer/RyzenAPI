-- Lua provided by RyzenAPI 
-- Game: Make me float Demo
addappid(2407150)
addappid(2407151, 1, "5d6830a466f26a1cd95d42fec9a29c3d9db54a967b0a5f561ad11d95ae3badbd")
