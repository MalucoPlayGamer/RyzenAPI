-- Lua provided by SkyAPI 
-- Game: AppID 2090760
addappid(2090760)
addappid(2090761, 1, "73e7fc65c36104fb4d30f8db9afea2882a3942a6b68d06d17357d73605dc0031")
