-- Lua provided by RyzenAPI
-- Game: Elements: Soul of Fire

-- MAIN APPLICATION
addappid(340650)

-- MAIN APP DEPOTS / PACKAGES
addappid(340651, 1, "fca8fb43549243f9865d13fbbc4ff392662bb107454401abb0e6487d1f07170b")
addappid(468580, 0, "f6bb88ac1e4a12291c7f9f09d47c7fbe796ccb33e0833e7426b283fa42d3fd2f")
