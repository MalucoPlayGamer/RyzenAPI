-- Lua provided by RyzenAPI
-- Game: A Shadow Cast on Water

-- MAIN APPLICATION
addappid(2452370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452371, 1, "9ccfaacc3afa79923824cc8ae4a5d673f6b8f7d35f7c3857665123eee9af709f")
