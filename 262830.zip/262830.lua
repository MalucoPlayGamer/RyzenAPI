-- Lua provided by RyzenAPI
-- Game: Crimsonland

-- MAIN APPLICATION
addappid(262830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(262831, 1, "2ee7fcbd0166fc095ee1e68caa1c0681b4ccd9fd21471c2af424209ae8a03e85")
addappid(262832, 1, "e287e0e84de7f8ae2989c3e2f5a2d6a320934a51d61d0653fb19d6d9da02efd5")
addappid(262833, 1, "f1afaa12367e2c5cc1d97cc7bf5ca8fb95f36f5c5cb77f3a59df3f326a169769")

