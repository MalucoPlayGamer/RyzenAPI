-- Lua provided by RyzenAPI 
-- Game: Crimsonland
addappid(262830)
addappid(262831, 1, "2ee7fcbd0166fc095ee1e68caa1c0681b4ccd9fd21471c2af424209ae8a03e85")
addappid(262832, 1, "e287e0e84de7f8ae2989c3e2f5a2d6a320934a51d61d0653fb19d6d9da02efd5")
addappid(262833, 1, "f1afaa12367e2c5cc1d97cc7bf5ca8fb95f36f5c5cb77f3a59df3f326a169769")
