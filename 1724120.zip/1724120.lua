-- Lua provided by RyzenAPI 
-- Game: ASTRONAUTILUS
addappid(1724120)
addappid(1724121, 1, "715605e7b5fa17396ebb93455d1d78d377e567e1b9deaa56a7d6f97b4d42af79")
