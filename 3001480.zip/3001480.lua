-- Lua provided by SkyAPI 
-- Game: AppID 3001480
addappid(3001480)
addappid(3001481, 1, "98a8d8f3a784b2a1a57d1255f6080134ec4a9ca07805d9937bf9684baafd3773")
