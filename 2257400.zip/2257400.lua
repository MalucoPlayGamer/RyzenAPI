-- Lua provided by RyzenAPI
-- Game: Game: GirlFriend VR

-- MAIN APPLICATION
addappid(2257400)
-- Game: addappid(2257400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257401, 1, "fe91728f0c74eb00924ab31f34c25e50f1ba3073084fa8dac14bc90e01a8b45a")
