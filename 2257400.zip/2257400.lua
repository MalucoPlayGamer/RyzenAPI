-- Lua provided by RyzenAPI 
-- Game: GirlFriend VR
addappid(2257400)
addappid(2257401, 1, "fe91728f0c74eb00924ab31f34c25e50f1ba3073084fa8dac14bc90e01a8b45a")
