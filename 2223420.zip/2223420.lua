-- Lua provided by RyzenAPI
-- Game: 紡織者之詠Voice of Belldona

-- MAIN APPLICATION
addappid(2223420)
addappid(3399800)
addappid(4746750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223421,0,"a5bb6f6d51212c9e49725443b65d908237b14371852b9080f4f576d7aa03f9b6")

