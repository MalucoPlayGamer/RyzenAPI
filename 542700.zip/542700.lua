-- Lua provided by RyzenAPI
-- Game: 力量的代價 Power Overwhelming

-- MAIN APPLICATION
addappid(542700)

-- MAIN APP DEPOTS / PACKAGES
addappid(542701, 1, "d01de445767136425aa17a818398f711dcc102824cc3c205326b7325b1aa543b")

