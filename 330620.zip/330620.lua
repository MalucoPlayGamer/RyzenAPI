-- Lua provided by RyzenAPI
-- Game: It's A Wipe!

-- MAIN APPLICATION
addappid(330620)

-- MAIN APP DEPOTS / PACKAGES
addappid(330622,0,"2a969e3c79afbf91cce421e7659cc283bcec6aa7760bd147cfae78d565f4f2d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
