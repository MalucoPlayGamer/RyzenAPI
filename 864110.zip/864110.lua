-- Lua provided by RyzenAPI
-- Game: Trap Defense

-- MAIN APPLICATION
addappid(864110)

-- MAIN APP DEPOTS / PACKAGES
addappid(864111, 1, "0efb14b2007c7762f16b68e68344259f3392d3295b774e4e2dd046a5cbda32ce")
