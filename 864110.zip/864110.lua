-- Lua provided by SkyAPI 
-- Game: Trap Defense
addappid(864110)
addappid(864111, 1, "0efb14b2007c7762f16b68e68344259f3392d3295b774e4e2dd046a5cbda32ce")
