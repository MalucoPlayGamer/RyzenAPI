-- Lua provided by RyzenAPI
-- Game: ヘブンバーンズレッド

-- MAIN APPLICATION
addappid(1973710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973711, 1, "f9b7c13407da5cff58d249c1b167561ef3b4388bf83109210655528563827af4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
