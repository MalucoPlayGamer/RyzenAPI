-- Lua provided by RyzenAPI
-- Game: ヘブンバーンズレッド

-- MAIN APPLICATION
addappid(1973710)
-- Game: addappid(1973710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973711, 1, "f9b7c13407da5cff58d249c1b167561ef3b4388bf83109210655528563827af4")
