-- Lua provided by RyzenAPI
-- Game: 2635120

-- MAIN APPLICATION
addappid(2635120)
-- Game: addappid(2635120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635121, 1, "c4a31fe9273eb2961a91298029dfe929d870e49f1cb40012bf201664f93eadf5")
