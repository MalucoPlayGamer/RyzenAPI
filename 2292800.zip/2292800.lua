-- Lua provided by RyzenAPI
-- Game: addappid(2292800)

-- MAIN APPLICATION
addappid(2292800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292801, 1, "eabaeaf0e86b550dc3dfb73dbfc87bf0ef141f3279e04f2e41ed631dc95c8f08")
