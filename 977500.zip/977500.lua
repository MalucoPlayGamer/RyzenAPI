-- Lua provided by RyzenAPI
-- Game: 克苏鲁异闻录

-- MAIN APPLICATION
addappid(977500)
-- Game: addappid(977500)

-- MAIN APP DEPOTS / PACKAGES
addappid(977501, 1, "dbe01fb00c7f6e559d0d0185c439e2abc43dfa3c44a9419e3b82fd875fae25e4")
