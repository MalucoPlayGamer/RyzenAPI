-- Lua provided by RyzenAPI
-- Game: 404820

-- MAIN APPLICATION
addappid(404820)
-- Game: addappid(404820)

-- MAIN APP DEPOTS / PACKAGES
addappid(404821, 1, "ced907a73500663c9b6c5f3793055bf790a807439f8cb59ef0f7961494f233e0")
