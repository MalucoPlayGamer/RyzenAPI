-- Lua provided by RyzenAPI
-- Game: 1678790

-- MAIN APPLICATION
addappid(1678790)
addappid(1683260)
-- Game: addappid(1678790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678791, 1, "6833bef4f801bd3d90ec000e3a47834643d8ac7d8d0f699e759e666992c799e8")
