-- Lua provided by RyzenAPI
-- Game: Gothic 1 Remake - Demo (Nyras Prologue)

-- MAIN APPLICATION
addappid(3448280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3448281, 1, "613993f0b8166b3e2aa1306217ad55fac964a30e0f505be7239d11829a3390a6")

