-- Lua provided by RyzenAPI
-- Game: Beyond Hanwell Demo

-- MAIN APPLICATION
addappid(2814030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814031, 1, "f3596c851b0bce0f6d068d67ecd17cdb01fb70633b538eaa29dea40533a77440")

