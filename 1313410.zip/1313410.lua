-- Lua provided by RyzenAPI
-- Game: The Last Cube Demo

-- MAIN APPLICATION
addappid(1313410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313411, 1, "972a3a97970686afec23a116422004b1399dc3b5ccf8eb7e6d20ca4f9747be29")

