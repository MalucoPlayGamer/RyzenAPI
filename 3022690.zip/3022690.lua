-- Lua provided by RyzenAPI
-- Game: Night Driver

-- MAIN APPLICATION
addappid(3022690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022691, 1, "e2fb3ef49669b39db63ad980cc341aaaf4f48ee5b2a743fbaa062ce1ec581ea5")

