-- Lua provided by RyzenAPI
-- Game: Human Factory

-- MAIN APPLICATION
addappid(1160040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160041, 1, "e206ea06a42b9e3109282792993a09215bcff68d52739201f2d990a04f2fe8ea")

