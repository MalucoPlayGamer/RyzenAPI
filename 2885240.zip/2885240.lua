-- Lua provided by RyzenAPI 
-- Game: Last Moon - Demo
addappid(2885240)
addappid(2885241, 1, "57c9a7d4c4281ce7763404369005a6b9bbfee403d21ec46bb4fba479a2d8b565")
