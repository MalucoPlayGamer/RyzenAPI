-- Lua provided by RyzenAPI
-- Game: addappid(2885240)

-- MAIN APPLICATION
addappid(2885240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2885241, 1, "57c9a7d4c4281ce7763404369005a6b9bbfee403d21ec46bb4fba479a2d8b565")
