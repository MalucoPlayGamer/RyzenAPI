-- Lua provided by RyzenAPI
-- Game: Game: Meaty McSkinBones

-- MAIN APPLICATION
addappid(1046370)
-- Game: addappid(1046370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046371, 1, "136ea63d7a8fa0b4bd03900acc00fe5f8a8fa7830c24ef605b963301f6a051dd")
