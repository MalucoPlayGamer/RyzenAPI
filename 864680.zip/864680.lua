-- Lua provided by RyzenAPI
-- Game: Rover Mechanic Simulator

-- MAIN APPLICATION
addappid(864680)

-- MAIN APP DEPOTS / PACKAGES
addappid(864681, 1, "7f88dad911cc8dead1023ee9d0cca7e98909066badd9bafa00912b2e94501010")
addappid(1512110, 0, "026caa43e94321779ff820fc8fce6807e2a9409f486b5febcdf9a429c3622301")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
