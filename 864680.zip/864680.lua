-- Lua provided by RyzenAPI
-- Game: addappid(864680)

-- MAIN APPLICATION
addappid(864680)

-- MAIN APP DEPOTS / PACKAGES
addappid(864681, 1, "7f88dad911cc8dead1023ee9d0cca7e98909066badd9bafa00912b2e94501010")
addappid(1512110, 0, "026caa43e94321779ff820fc8fce6807e2a9409f486b5febcdf9a429c3622301")
