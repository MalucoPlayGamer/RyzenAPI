-- Lua provided by RyzenAPI
-- Game: 1238680

-- MAIN APPLICATION
addappid(1238680)
-- Game: addappid(1238680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238681, 1, "53a6382b28e82c7797d9dbc6b9e74fc71c7956bb5cfb4e1dc2bdb4d5cf86bdc6")
