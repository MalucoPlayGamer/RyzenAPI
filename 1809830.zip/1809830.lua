-- Lua provided by RyzenAPI
-- Game: AppID 1809830

-- MAIN APPLICATION
addappid(1809830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809831, 1, "a8efbeeb6cd1d8dec1e6b929f2ec057541a343ae7f5741f0baf0b710010b4eaa")
addappid(1809832, 1, "5b1fdaa14eb7962e4a50da04f0b7c846d3d72aa5922e37ce7cdd3e4e93f1a73c")

