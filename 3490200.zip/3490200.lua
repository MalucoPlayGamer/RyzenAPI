-- Lua provided by RyzenAPI
-- Game: Game: LOVE Hotel Simulator 🏩 Demo

-- MAIN APPLICATION
addappid(3490200)
-- Game: addappid(3490200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3490201, 1, "3a3217b2e040e4e7a2eefce16f3966350f74064536080e7b9aa4ea382755109e")
