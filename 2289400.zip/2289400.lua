-- Lua provided by RyzenAPI
-- Game: AppID 2289400

-- MAIN APPLICATION
addappid(2289400)
-- Game: addappid(2289400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289401, 1, "7bd477a5c3f949607752448621f89ca44133ebc654d51d09f8f68dbdef73a91a")
