-- Lua provided by RyzenAPI
-- Game: 江华号 Demo

-- MAIN APPLICATION
addappid(2592640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2592641, 1, "a021b70e74c30bd5ebb7a213004014cfba73d57016bad0aa2c094174fadbbb48")

