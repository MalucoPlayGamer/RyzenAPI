-- Lua provided by RyzenAPI
-- Game: Scratchies

-- MAIN APPLICATION
addappid(4001240)

-- MAIN APP DEPOTS / PACKAGES
addappid(4001242,0,"cd3b69a10c8ede27791af56e3d73bb5037751dcdf23fe805bea86a82fc19645d")

