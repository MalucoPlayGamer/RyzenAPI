-- Lua provided by RyzenAPI
-- Game: Mystery Chamber: Forever - Sneak Peek

-- MAIN APPLICATION
addappid(2401880)
-- Game: addappid(2401880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401881, 1, "adf12b66d095322cf16a698355ad1c107fea2766d2e7d86539f5e599c5016c57")
