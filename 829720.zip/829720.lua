-- Lua provided by RyzenAPI
-- Game: The Nature

-- MAIN APPLICATION
addappid(829720)

-- MAIN APP DEPOTS / PACKAGES
addappid(829721,0,"233a3f9f5604d5df8899ad190ab281d9b78f67656f429c5a0696d69957f23f4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
