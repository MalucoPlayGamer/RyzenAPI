-- Lua provided by RyzenAPI
-- Game: Game: AppID 2458520

-- MAIN APPLICATION
addappid(2458520)
-- Game: addappid(2458520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458521, 1, "f9f3ba5ca3bd1919ecfe5ff6a9379a213ecfe9e92c017138c1dbaeddb5e48b38")
