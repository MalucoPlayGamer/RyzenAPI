-- Lua provided by RyzenAPI
-- Game: JUNK! A Demo About Robots Playtest

-- MAIN APPLICATION
addappid(2210610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210611, 1, "ce80c7ed8478a51e22971c04e15ff9d90c4a7758e4b6446a595be414029229ab")

