-- Lua provided by RyzenAPI
-- Game: 727670

-- MAIN APPLICATION
addappid(727670)
-- Game: addappid(727670)

-- MAIN APP DEPOTS / PACKAGES
addappid(727671, 1, "d88ce7dd7c6664625c4545c0e764dde65fce6acda6cf969ee384528fe0fc70b0")
addappid(727672, 1, "fb29d8839ff60217d911d62a20c6377b1cdea37084c72bb30efc0ff2dd3c313f")
