-- Lua provided by RyzenAPI 
-- Game: OPPAI RENDER: FIRST LOVE
addappid(3612080)
addappid(3612081, 1, "2022aee0353e06d5a14d8917fb042a841b2e0f62a936d02256de401448d77794")
