-- Lua provided by RyzenAPI
-- Game: addappid(992310)

-- MAIN APPLICATION
addappid(992310)

-- MAIN APP DEPOTS / PACKAGES
addappid(992311, 1, "84e74097c4bbbdc76ee5fbb692d2e5ed1e7597884f7f299c52e89c5e4d6e6c96")
