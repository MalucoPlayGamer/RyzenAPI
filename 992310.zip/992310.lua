-- Lua provided by RyzenAPI
-- Game: AppID 992310

-- MAIN APPLICATION
addappid(992310)

-- MAIN APP DEPOTS / PACKAGES
addappid(992311, 1, "84e74097c4bbbdc76ee5fbb692d2e5ed1e7597884f7f299c52e89c5e4d6e6c96")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
