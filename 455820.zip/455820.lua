-- Lua provided by RyzenAPI
-- Game: Omensight: Definitive Edition

-- MAIN APPLICATION
addappid(455820)
addappid(943560)
addappid(943650)

-- MAIN APP DEPOTS / PACKAGES
addappid(455821, 1, "cf5afb5b6b151b891c46f0d2d066aefaa2380227ba7b913a32f7f66a03f7a0e6")
addappid(858980, 0, "e5760b90059fcda3ce9930dce8d85716ac16c0588bdb102e7a1fa1048bd200ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
