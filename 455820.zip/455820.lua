-- Lua provided by RyzenAPI
-- Game: addappid(455820)

-- MAIN APPLICATION
addappid(455820)
addappid(943560)
addappid(943650)

-- MAIN APP DEPOTS / PACKAGES
addappid(455821, 1, "cf5afb5b6b151b891c46f0d2d066aefaa2380227ba7b913a32f7f66a03f7a0e6")
addappid(858980, 0, "e5760b90059fcda3ce9930dce8d85716ac16c0588bdb102e7a1fa1048bd200ae")
