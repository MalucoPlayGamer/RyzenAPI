-- Lua provided by RyzenAPI
-- Game: Game: Unearthing Mars VR

-- MAIN APPLICATION
addappid(605310)
-- Game: addappid(605310)

-- MAIN APP DEPOTS / PACKAGES
addappid(605311, 1, "67885acef033e92c2656ce67aaf24401b5ec1b01db80d4e19f94c4c6619b9980")
