-- Lua provided by RyzenAPI
-- Game: Unearthing Mars VR

-- MAIN APPLICATION
addappid(605310)

-- MAIN APP DEPOTS / PACKAGES
addappid(605311, 1, "67885acef033e92c2656ce67aaf24401b5ec1b01db80d4e19f94c4c6619b9980")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
