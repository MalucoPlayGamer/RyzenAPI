-- Lua provided by RyzenAPI
-- Game: Game: Plush

-- MAIN APPLICATION
addappid(341820)
-- Game: addappid(341820)

-- MAIN APP DEPOTS / PACKAGES
addappid(341821, 1, "e8df18262e7a907feb88aeb8b300cbe1f77e487a96a965b6791bb1905e587eaf")
addappid(341822, 1, "457150dbc86a90881e868bb3a6c25d8b9d23eac5de73c6c3df586afd3d0fb609")
addappid(341823, 1, "10233eb379ac056c420dc377c07b0f5cd8c068277b21ac3afa9cfbeca38fbde3")
