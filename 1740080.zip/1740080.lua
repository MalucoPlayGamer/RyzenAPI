-- Lua provided by RyzenAPI
-- Game: Game: Level Up Simulator

-- MAIN APPLICATION
addappid(1740080)
-- Game: addappid(1740080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740081, 1, "898fc5187380ca1fa56938e5312a46d27b12c490900bb40d5facbdfc84165bd0")
