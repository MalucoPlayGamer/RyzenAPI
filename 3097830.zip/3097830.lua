-- Lua provided by RyzenAPI
-- Game: Ultraleap Gemini - Blocks

-- MAIN APPLICATION
addappid(3097830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097830,0,"2393b66b452294852ae36d18d4ba232bf17b54004506c0b026486df897b04e08")

