-- Lua provided by SkyAPI 
-- Game: Praise Dead
addappid(2459180)
addappid(2459181, 1, "bb47005981c4680b9cf68fff32827f3a5ae129b283a8d78b686f2754b3d14b5d")
