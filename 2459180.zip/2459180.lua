-- Lua provided by RyzenAPI
-- Game: Game: Praise Dead

-- MAIN APPLICATION
addappid(2459180)
-- Game: addappid(2459180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459181, 1, "bb47005981c4680b9cf68fff32827f3a5ae129b283a8d78b686f2754b3d14b5d")
