-- Lua provided by RyzenAPI 
-- Game: Angry Angry Shark
addappid(1546930)
addappid(1546931, 1, "75bbeeccea8d5e70940b6bda3de0f46a1d724096950bcfef20394cc41e0474b0")
