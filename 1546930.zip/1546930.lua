-- Lua provided by RyzenAPI
-- Game: Angry Angry Shark

-- MAIN APPLICATION
addappid(1546930)
-- Game: addappid(1546930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546931, 1, "75bbeeccea8d5e70940b6bda3de0f46a1d724096950bcfef20394cc41e0474b0")
