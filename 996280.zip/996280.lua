-- Lua provided by RyzenAPI
-- Game: Buttle Tank

-- MAIN APPLICATION
addappid(996280)

-- MAIN APP DEPOTS / PACKAGES
addappid(996281, 1, "6b3e461ed1ea342a2a81a77f2f651c70050490f1d3628b009ed76d2b512d9bc5")
