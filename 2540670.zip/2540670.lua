-- Lua provided by RyzenAPI
-- Game: Terralysia

-- MAIN APPLICATION
addappid(2540670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2540671, 1, "031e60823ba4813030e082fc4ddcfbf56d0d9854e8b8276740a5b2f00988bff2")

