-- Lua provided by RyzenAPI
-- Game: Great Hopes City I Demo

-- MAIN APPLICATION
addappid(2466180)
-- Game: addappid(2466180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466181, 1, "0a993a735613f3f0db20249373650b4c120599416aa664f607ae1e9226c25430")
