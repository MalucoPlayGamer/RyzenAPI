-- Lua provided by SkyAPI 
-- Game: Great Hopes City I Demo
addappid(2466180)
addappid(2466181, 1, "0a993a735613f3f0db20249373650b4c120599416aa664f607ae1e9226c25430")
