-- Lua provided by RyzenAPI
-- Game: Game: Cats in Time

-- MAIN APPLICATION
addappid(1599880)
-- Game: addappid(1599880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599881, 1, "23c3eb7c8b5f977989898fb2558fba6a2be2bb1d62b1eb5a3b633ddb0d999e8a")
