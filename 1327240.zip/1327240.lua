-- Lua provided by RyzenAPI
-- Game: 1327240

-- MAIN APPLICATION
addappid(1327240)
-- Game: addappid(1327240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327241, 1, "b4ee460f4b0b447379320659b2ce24ac84ebf3ee0d66dec5b1c01b4c6071e2fe")
