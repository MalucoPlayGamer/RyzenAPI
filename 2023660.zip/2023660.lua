-- Lua provided by RyzenAPI
-- Game: Toy Tactics Demo

-- MAIN APPLICATION
addappid(2023660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023661, 1, "e698232814c0eacaff06c24260efe9f9b906f8ee5e7062b20c6d4c905a61f760")
