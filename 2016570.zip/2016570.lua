-- Lua provided by RyzenAPI
-- Game: Game: AppID 2016570

-- MAIN APPLICATION
addappid(2016570)
-- Game: addappid(2016570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016571, 1, "564158bf6aff56424ae1b21c3b0e13215c658f590845c646176e065367cae05e")
