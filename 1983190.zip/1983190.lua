-- Lua provided by RyzenAPI
-- Game: Game: AppID 1983190

-- MAIN APPLICATION
addappid(1983190)
-- Game: addappid(1983190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983191, 1, "1ecd982dc0a80f6419832837feb36ca83f1089c747a6231009e44a01caab9318")
