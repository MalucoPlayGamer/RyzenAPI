-- Lua provided by RyzenAPI
-- Game: DynBrushes

-- MAIN APPLICATION
addappid(2853320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853321, 1, "78bd039d8017c157b07666dd6b0c88e1118306364373f8c9ec3092261050cc27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
