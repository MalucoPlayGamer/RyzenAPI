-- Lua provided by RyzenAPI
-- Game: DynBrushes

-- MAIN APPLICATION
addappid(2853320)
-- Game: addappid(2853320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853321, 1, "78bd039d8017c157b07666dd6b0c88e1118306364373f8c9ec3092261050cc27")
