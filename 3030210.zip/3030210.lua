-- Lua provided by RyzenAPI
-- Game: Slash/Jump

-- MAIN APPLICATION
addappid(3030210)

