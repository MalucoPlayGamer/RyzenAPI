-- Lua provided by RyzenAPI
-- Game: Terrors to Unveil - Intrusion

-- MAIN APPLICATION
addappid(3716700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3716701, 1, "3b87a69d59f2f7cbd33fe3bccda10b551242b33f6ba46f41e6a55023c6ba59ee")
