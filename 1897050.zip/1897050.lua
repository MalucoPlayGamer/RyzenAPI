-- Lua provided by RyzenAPI
-- Game: VARIOUS DAYLIFE

-- MAIN APPLICATION
addappid(1897050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1897051, 1, "dc337d52af4c196f05e27b36e354287796f43dde225ae15bdc54ec237df62e52")
addappid(2081320, 0, "d72e14646a42ffdb26d8ab7da4afa1f602f5f59f2468882a1e11cebf32ab4c10")

