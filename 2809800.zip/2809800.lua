-- Lua provided by RyzenAPI
-- Game: addappid(2809800)

-- MAIN APPLICATION
addappid(2809800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809801, 1, "90d66e3aa98e5d62d4bc1a84e9d84f29d6aa2eaef025d0c7644e89e751e6553f")
