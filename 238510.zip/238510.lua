-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228990)
addappid(238510)
addappid(238511)

-- MAIN APP DEPOTS / PACKAGES
addappid(234083,0,"b87b6f66b1adb93c834b430768ddf9b1cf1457edf63f2a6235366c28cbcc711f")

