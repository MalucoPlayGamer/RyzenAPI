-- Lua provided by RyzenAPI
-- Game: Wizardry: Proving Grounds of the Mad Overlord

-- MAIN APPLICATION
addappid(2518960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518961, 1, "f96b51c37ef3628dae284bfc72451f9ddf40815efeecea2da0f4fbfd63e6eab4")
