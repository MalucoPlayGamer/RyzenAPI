-- Lua provided by SkyAPI 
-- Game: Wizardry: Proving Grounds of the Mad Overlord
addappid(2518960)
addappid(2518961, 1, "f96b51c37ef3628dae284bfc72451f9ddf40815efeecea2da0f4fbfd63e6eab4")
