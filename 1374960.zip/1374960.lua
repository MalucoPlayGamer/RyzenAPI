-- Lua provided by RyzenAPI
-- Game: SpaceVenture

-- MAIN APPLICATION
addappid(1374960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374961,0,"c4b09177da67e7a1584047160dbef9c70c3a3cf9ee18f6c2cfcd487f5917a857")

