-- Lua provided by RyzenAPI
-- Game: addappid(1479460)

-- MAIN APPLICATION
addappid(1479460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479461, 1, "33a4abc2eebf6ecb0f98c946be6d68fc29c10c25e070f860fc26dd79bc142265")
