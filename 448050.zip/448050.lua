-- Lua provided by RyzenAPI
-- Game: Mr Nibbles Forever

-- MAIN APPLICATION
addappid(448050)

-- MAIN APP DEPOTS / PACKAGES
addappid(448052,0,"30e824064e2df4166323e4828c0aff2c034f33b054953049a669e48218829dcd")
