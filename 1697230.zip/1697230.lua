-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Useful Decorative Plant Tiles

-- MAIN APPLICATION
addappid(1697230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697230,0,"6f00852ebecbb34bd14f614419d62149940ed68be7a00c9047cf9cb46daa2df1")

