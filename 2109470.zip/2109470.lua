-- Lua provided by RyzenAPI
-- Game: Game: Wild West Legacy: The New Hope Gazette

-- MAIN APPLICATION
addappid(2109470)
addappid(2109480)
-- Game: addappid(2109470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109471, 1, "eb5394a8e70118f342f35439a41b876c73d73f8767e8b807d58faa670bc5c563")
addappid(2109472, 1, "717a34e4bab037f30fa22925480c7aa3117ef8490213268862941fb2bcf1b81b")
addappid(2109473, 1, "b625deb998f346e204bf69fd23023debe94f82e3fd1f3e9c823bd75214ed9091")
addappid(2109474, 1, "06afddee8a1d72cfe2a97f5dd3a3a35e19ffff4cc33f50ca32772d530f12a699")
