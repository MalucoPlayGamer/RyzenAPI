-- Lua provided by RyzenAPI
-- Game: AppID 2991470

-- MAIN APPLICATION
addappid(2991470)
-- Game: addappid(2991470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2991471, 1, "d1066c78a2ffe5319e5b6d47cce4c8c27a2bbe72abbdc88e390ac0ae8617ab21")
