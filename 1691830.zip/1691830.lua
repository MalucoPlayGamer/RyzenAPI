-- Lua provided by RyzenAPI
-- Game: Temple with traps

-- MAIN APPLICATION
addappid(1691830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691831, 1, "a8746f22186c2db9e7a9c91705b2bb0c5a2f411b8a74187b3f550db7f16c33db")

