-- Lua provided by RyzenAPI
-- Game: 482920

-- MAIN APPLICATION
addappid(482920)
-- Game: addappid(482920)

-- MAIN APP DEPOTS / PACKAGES
addappid(482921, 1, "90a97f494368c6a622fffd78ced9c5872d61167e9447f975c365be59bac722d2")
