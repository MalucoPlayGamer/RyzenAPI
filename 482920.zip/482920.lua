-- Lua provided by RyzenAPI 
-- Game: Hero Zero - Multiplayer RPG
addappid(482920)
addappid(482921, 1, "90a97f494368c6a622fffd78ced9c5872d61167e9447f975c365be59bac722d2")
