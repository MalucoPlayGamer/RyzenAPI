-- Lua provided by RyzenAPI
-- Game: addappid(2664860)

-- MAIN APPLICATION
addappid(2664860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2664861, 1, "5928ca7d4c76dc87889fe5432a12aeec7c53e8b52e3a89a8c0d3e01306985120")
