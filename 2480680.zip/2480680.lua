-- Lua provided by RyzenAPI
-- Game: 2480680

-- MAIN APPLICATION
addappid(2480680)
-- Game: addappid(2480680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2480681, 1, "9fe1db2849a49c736506dcb6bf5cb73a6436df871870faeac1d66a9975191670")
