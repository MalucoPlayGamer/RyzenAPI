-- Lua provided by RyzenAPI
-- Game: Zombies Don't Drive

-- MAIN APPLICATION
addappid(1297370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297371, 1, "b4cae560a2859b1cf01722b43f918b7686d71e34296f43e4dbdd9fd2528ad91e")
