-- Lua provided by RyzenAPI
-- Game: Three kingdoms story: Conussia - Complete rework

-- MAIN APPLICATION
addappid(1998090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998091, 1, "49a7d242cf4d7871e7565d36dc5c5526ab7d9ab5a9f4a4b9d104d330727cd5eb")

