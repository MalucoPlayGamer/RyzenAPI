-- Lua provided by RyzenAPI
-- Game: AppID 2546770

-- MAIN APPLICATION
addappid(2546770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546771, 1, "2c7edd41ebae25d07ee970e99f1a01312f3cb4bba832e9629ebee3c617b3f764")
