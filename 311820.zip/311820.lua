-- Lua provided by RyzenAPI
-- Game: Game: RC Mini Racers

-- MAIN APPLICATION
addappid(311820)
-- Game: addappid(311820)

-- MAIN APP DEPOTS / PACKAGES
addappid(311821, 1, "74b86678e41e7a5c04e4ecd639a08d7a1581764cf1b5c3a376b21372c9e8b7b3")
addappid(311822, 1, "aed50c1152fb7185537376b8263d8640c056fe25fdc84aa2b33b55eb6d3bc2c6")
addappid(311823, 1, "4e043a0c4afd299c7ef322bf2544f5e82bdd24868e2d8dcb2166b026b4499378")
