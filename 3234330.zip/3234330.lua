-- Lua provided by SkyAPI 
-- Game: Ninja Ming
addappid(3234330)
addappid(3234331, 1, "2ee543f15981748ad16c8f2cb3e289a09fc50fe32250d28e751a7478115146a8")
