-- Lua provided by RyzenAPI
-- Game: Ninja Ming

-- MAIN APPLICATION
addappid(3234330)
-- Game: addappid(3234330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3234331, 1, "2ee543f15981748ad16c8f2cb3e289a09fc50fe32250d28e751a7478115146a8")
