-- Lua provided by RyzenAPI
-- Game: Samurai pussy

-- MAIN APPLICATION
addappid(2146230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146231, 1, "19fc2eff03ea784a8eafd03e32f5b7e3dec70226c35032feb2d542958d600750")
