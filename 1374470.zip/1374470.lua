-- Lua provided by RyzenAPI
-- Game: Game: Hentai Cool Girls

-- MAIN APPLICATION
addappid(1374470)
-- Game: addappid(1374470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374471, 1, "63dd0012c7463c33ee25d03223feeadcb39bc94a4de8790a24c291c67aa2a759")
