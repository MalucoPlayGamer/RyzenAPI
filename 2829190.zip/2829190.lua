-- Lua provided by RyzenAPI 
-- Game: All-In-One Summer Sports VR Demo
addappid(2829190)
addappid(2829191, 1, "3af2786da3718c7cd361b3583edec6b14efcb6290771270a3ec3019287521e2c")
