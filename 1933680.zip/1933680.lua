-- Lua provided by RyzenAPI
-- Game: Spiral Dystopia

-- MAIN APPLICATION
addappid(1933680)
-- Game: addappid(1933680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933681, 1, "ea87b9d2c2001bc146ebc771c37e99cc5e7e92482fdd91bc6b8ea9d745d8e866")
addappid(1933682, 1, "b08034f43eb92782e907561d4c5accb562b9613446b68437819eb7bc52f664b1")
addappid(1933683, 1, "22e0a4f958aabdf073b12614ea98fe76b06e6676a0bd4910a5ab4aba049b7d7e")
