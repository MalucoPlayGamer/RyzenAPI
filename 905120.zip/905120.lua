-- Lua provided by RyzenAPI
-- Game: Game: Son.Light.Sleepwalker

-- MAIN APPLICATION
addappid(905120)
-- Game: addappid(905120)

-- MAIN APP DEPOTS / PACKAGES
addappid(905121, 1, "882032b4bdf1f187f00f6e25a85b986768a066ec67d3c85a2159e09c47f4db1b")
