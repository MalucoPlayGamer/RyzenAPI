-- Lua provided by RyzenAPI
-- Game: Hardcore ZBoy

-- MAIN APPLICATION
addappid(709800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(709801, 1, "9e07cde01c907c97e127f9330532f523125c8ed9dd96d7b1362ecd2f1081ca90")
addappid(709802, 1, "4f6447bf732082f8538cff52a3bce90fed514fe67fc47484934321d63a77c681")

