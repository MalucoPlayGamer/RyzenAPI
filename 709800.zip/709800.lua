-- Lua provided by SkyAPI 
-- Game: Hardcore ZBoy
addappid(709800)
addappid(709801, 1, "9e07cde01c907c97e127f9330532f523125c8ed9dd96d7b1362ecd2f1081ca90")
addappid(709802, 1, "4f6447bf732082f8538cff52a3bce90fed514fe67fc47484934321d63a77c681")
