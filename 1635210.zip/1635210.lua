-- Lua provided by RyzenAPI
-- Game: Game: Broken Blades

-- MAIN APPLICATION
addappid(1635210)
-- Game: addappid(1635210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635211, 1, "b7032796dd5854d510b3e931803ef2313caea5836529e5f22fd4f44b87a1b1eb")
