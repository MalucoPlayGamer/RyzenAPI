-- Lua provided by RyzenAPI
-- Game: 龙傲天的多元宇宙 开发者支持包

-- MAIN APPLICATION
addappid(2418190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2418190,0,"4ec5bb2047813105ea7a046354be5088f5044a29a830ad79fe29597a2e07b164")
