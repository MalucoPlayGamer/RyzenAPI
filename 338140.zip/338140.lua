-- Lua provided by RyzenAPI
-- Game: Venetica - Gold Edition

-- MAIN APPLICATION
addappid(338140)

-- MAIN APP DEPOTS / PACKAGES
addappid(338141, 1, "eec03c097dbe8ffecbb543f517b174759b2011882badd705dadb212f11888194")
addappid(338142, 1, "471a6d2180974d5a090b147276cb9f6d445c0b899d8e5e7e511359a1adafd357")
addappid(338143, 1, "3fb844f7b70e79a2f7749ee22b08ec89b38227ed5170c716f20a5bdedc3205c5")
addappid(338144, 1, "15e5a80ae384fa89b68b0ade2aa764008890c51452f1be8ce9a0bd33f96735d5")
addappid(338145, 1, "93c590b54cd1ad9d6b7a96eb27fc2c958b6e67aae2b87e6949df99fb5ac46f0a")
addappid(338146, 1, "23d3cdd3bcd73507bc012c2b62ca4aa34ca7868039ff02adf9f4c5349bcc0670")
addappid(338147, 1, "4a03710540a1f61b8c77ed38048f74da13c96f36feeb8495606db3d93712d3fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
