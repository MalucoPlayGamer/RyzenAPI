-- Lua provided by RyzenAPI
-- Game: Game: AppID 1052090

-- MAIN APPLICATION
addappid(1052090)
-- Game: addappid(1052090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052091, 1, "20735da24ed7b2310891864444487ff4bfe8e86d2e9b892e216c99932ca16e14")
