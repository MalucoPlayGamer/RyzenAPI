-- Lua provided by RyzenAPI
-- Game: addappid(2440290)

-- MAIN APPLICATION
addappid(2440290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440291, 1, "8b07d6a3c0bed3da2bbe46640897f541c2111b27d516eee5f6511b14174826cc")
