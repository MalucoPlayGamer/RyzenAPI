-- Lua provided by SkyAPI 
-- Game: AppID 2440290
addappid(2440290)
addappid(2440291, 1, "8b07d6a3c0bed3da2bbe46640897f541c2111b27d516eee5f6511b14174826cc")
