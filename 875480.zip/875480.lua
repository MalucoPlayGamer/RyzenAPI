-- Lua provided by RyzenAPI
-- Game: Game: Somnium Space VR

-- MAIN APPLICATION
addappid(875480)
-- Game: addappid(875480)

-- MAIN APP DEPOTS / PACKAGES
addappid(875481, 1, "46da21073560a468e70266bf4671a132bc516c07534799bf4e66bdb3d3f516c9")
