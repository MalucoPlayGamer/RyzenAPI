-- Lua provided by RyzenAPI
-- Game: Evopollution

-- MAIN APPLICATION
addappid(295990)

-- MAIN APP DEPOTS / PACKAGES
addappid(295991, 1, "f842a7cad3a3e6f14a94c60095ba42d6e13592cf0c23f00e3a157dafad88d8ca")
