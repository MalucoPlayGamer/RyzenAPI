-- Lua provided by RyzenAPI
-- Game: addappid(1010210)

-- MAIN APPLICATION
addappid(1010210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010210,0,"d81dd8db60a9230cba5d7ae0b67bd5bf6b9e43b835a40c2fab7c56e413894ef2")
