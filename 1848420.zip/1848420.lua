-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1848420)
-- Game: addappid(1848420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848420,0,"2f366ace6c34db54f812b799f7eea8dc034fa0706e5f91772b73ae4b113829ed")
