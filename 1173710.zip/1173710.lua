-- Lua provided by RyzenAPI
-- Game: Game: AppID 1173710

-- MAIN APPLICATION
addappid(1173710)
-- Game: addappid(1173710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173711, 1, "eb709211ee0b3eb02c90c7d114f3db30701dc4e8e8f12b4b6d8cf76b5961dd68")
