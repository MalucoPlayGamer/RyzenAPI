-- Lua provided by RyzenAPI
-- Game: addappid(2125540)

-- MAIN APPLICATION
addappid(2125540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125542,0,"03a982baa6facb2d155f1c861f5e2155178d77af05bd836c26d8898cfcd8f910")
