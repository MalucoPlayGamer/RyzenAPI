-- Lua provided by RyzenAPI
-- Game: Kādomon: Hyper Auto Battlers

-- MAIN APPLICATION
addappid(2125540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2125542,0,"03a982baa6facb2d155f1c861f5e2155178d77af05bd836c26d8898cfcd8f910")

