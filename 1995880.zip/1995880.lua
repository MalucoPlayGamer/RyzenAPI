-- Lua provided by RyzenAPI
-- Game: Game: Afterdream

-- MAIN APPLICATION
addappid(1995880)
-- Game: addappid(1995880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995881, 1, "f75b6a72ee73e34e1b3ff15e72e81517785513162b3544c3f5261751550a1006")
