-- Lua provided by RyzenAPI
-- Game: Game: GentleMoon 2

-- MAIN APPLICATION
addappid(488890)
-- Game: addappid(488890)

-- MAIN APP DEPOTS / PACKAGES
addappid(488891, 1, "b607dd107b25071da344c1e2098b75c5a18eef96a11670681754e85755842c7c")
