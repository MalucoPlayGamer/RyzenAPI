-- 1148130's Lua and Manifest Created by Hubcap Manifest
-- Divinum
-- Created: August 29, 2026 at 00:58:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1148130, 1, "d667b5371575f1f1aa943bcdcd27e9d967c797f91f1a28d7517cbb8150b8e238") -- Divinum
-- MAIN APP DEPOTS
addappid(1148131, 1, "d51f35c9961ee97bfc99d4119281c8e0584cdb1616848d9702b73fe486bc975b") -- Depot 1148131
setManifestid(1148131, "7249194946373401431", 594232464)
addappid(1148132, 1, "9ce728f8e09394670d73111ec2ae5ae1d3f2569695d0eb31f03d83f73d538296") -- Depot 1148132
setManifestid(1148132, "741199014797409044", 619063905)