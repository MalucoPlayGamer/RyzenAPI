-- Lua provided by RyzenAPI
-- Game: Fatty Bear's Birthday Surprise

-- MAIN APPLICATION
addappid(317030)

-- MAIN APP DEPOTS / PACKAGES
addappid(317031, 1, "d1e3a2467ac76bd9db35b40ee8c8cb807cd883adcd030a94f62fbc5902fe8b2c")
addappid(317032, 1, "4d0c63c3b4ba4b6738a3a7bf5589eb069d8eea97aefad7bd96931b1e5446e20c")
addappid(317033, 1, "fb74a1f728d17e23589016a0b21512e398c45536a63f40d48af14e29a7dfa5c7")
addappid(317034, 1, "e9ae114fa02a65e5fdf7255b34d134a2fa12f8188028b1c7ff17eb9834440eef")
addappid(317035, 1, "4064471b53cab205e2f657f301fa9a13060ed7879d5c397b930a08c60e8f6584")
addappid(317036, 1, "569391b0e4e43482c4fb3543b69cdb48218294bb41eccda69badb77524261df4")
addappid(317037, 1, "8d89f70768dbe50e8dbb073327663164d8f4d9cb38eaab119ceac5e5fbd0bec6")

