-- Lua provided by SkyAPI 
-- Game: AppID 2073850
addappid(2073850)
addappid(2073851, 1, "0ac69706a0ad749c7111eeb755df5595603cd8ba035b220276b7f32bca7a9e99")
