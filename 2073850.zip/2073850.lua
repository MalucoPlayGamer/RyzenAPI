-- Lua provided by RyzenAPI
-- Game: AppID 2073850

-- MAIN APPLICATION
addappid(2073850)
-- Game: addappid(2073850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073851, 1, "0ac69706a0ad749c7111eeb755df5595603cd8ba035b220276b7f32bca7a9e99")
