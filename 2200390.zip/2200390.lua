-- Lua provided by RyzenAPI
-- Game: 2200390

-- MAIN APPLICATION
addappid(2200390)
addappid(2229090)
-- Game: addappid(2200390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200391, 1, "2d347fa080682855a3b25fc989dfddfcd5e4202e3da84467340a3202bc6cac9c")
