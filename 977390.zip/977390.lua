-- Lua provided by RyzenAPI
-- Game: Tokyo Warfare Turbo

-- MAIN APPLICATION
addappid(977390)

-- MAIN APP DEPOTS / PACKAGES
addappid(977391, 1, "49217e561130672434ae3594fee8024630ce0e4630b69307c7c55f9fa0db3607")
addappid(1028970, 0, "74b5d42fff169e96f3e2f5e3a5114f92e463c7fd40d143f2fd41108c851e5eea")
addappid(1032330, 0, "10ad56d7d103882b3c04ae961f90a75fa2efb80a724c13c5dff3520c9d094a17")
addappid(1055220, 0, "911b1f52ac3f8548bcc9a11f5622c557f3d438c2465caf7f7f681bc5f14a9f96")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
