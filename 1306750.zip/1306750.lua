-- Lua provided by RyzenAPI
-- Game: 黑色花与红山羊 / Black Datura & Red Goat

-- MAIN APPLICATION
addappid(1306750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306751, 1, "2e9021ae1c27bb8103dab2083d00812ba99bf7a46308a967caf5913f9616ae01")
