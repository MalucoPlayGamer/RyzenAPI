-- Lua provided by RyzenAPI
-- Game: addappid(1430680)

-- MAIN APPLICATION
addappid(1430680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430681, 1, "e23a9dbf2197c848f26cf4e1f05c56d83100c975ba5e206ba01f2ea122aa03b7")
