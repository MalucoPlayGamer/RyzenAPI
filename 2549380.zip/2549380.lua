-- Lua provided by RyzenAPI 
-- Game: Cryptical Path
addappid(2549380)
addappid(2549381, 1, "ae7fd2afa74cb09b355f5650ebb8bae35fe85dd07866591a1f77dd1908358ca5")
