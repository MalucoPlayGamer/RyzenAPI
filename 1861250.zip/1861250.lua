-- Lua provided by RyzenAPI
-- Game: Antro

-- MAIN APPLICATION
addappid(1861250)
addappid(3346290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861251, 1, "955411502bc9f8ee8efbaee25320bb0fdc420d9dc7d7d13394f4c0a96c5a2a49")

