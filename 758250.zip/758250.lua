-- Lua provided by RyzenAPI 
-- Game: Taste of Power
addappid(758250)
addappid(758251, 1, "3dc4fe903e8bb0fe0428657745ff227bbc1d4141db1775f9e4fb12e8559cf7be")
