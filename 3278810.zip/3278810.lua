-- Lua provided by SkyAPI 
-- Game: Backrooms: Last Room Playtest
addappid(3278810)
addappid(3278811, 1, "d123d15ac79c0749861ba7ed50d59e4ca6a4e426aec59dffbbf8a55334a52ead")
