-- Lua provided by SkyAPI 
-- Game: Christmas Tina Trial version
addappid(1087930)
addappid(1087931, 1, "cd11b3deb484649591557ac4d0ce0b5a628cd3ab868bf0ecf7d80054dc4faf9d")
addappid(1087932, 1, "574644b02250e4aa7150e25c1f9b0f0392b962b2861499a7cfc02f77fce5a25c")
