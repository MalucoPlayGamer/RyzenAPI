-- Lua provided by RyzenAPI
-- Game: AppID 1013140

-- MAIN APPLICATION
addappid(1013140)
-- Game: addappid(1013140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013141, 1, "627819d4dc52699ed1d0deb733ccad9efdc0173dd35f432457d04f10a065b48f")
