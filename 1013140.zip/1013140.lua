-- Lua provided by RyzenAPI
-- Game: Outcast - A New Beginning

-- MAIN APPLICATION
addappid(1013140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1013141, 1, "627819d4dc52699ed1d0deb733ccad9efdc0173dd35f432457d04f10a065b48f")

