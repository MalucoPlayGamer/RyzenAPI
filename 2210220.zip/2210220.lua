-- Lua provided by RyzenAPI
-- Game: Outfield

-- MAIN APPLICATION
addappid(2210220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2210222,0,"83a6c71d478aa6f95ae452ae3edcd900d65aebfb45fdccd56e06b1b038bc4092")

