-- Lua provided by RyzenAPI
-- Game: Outfield

-- MAIN APPLICATION
addappid(2210220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210222,0,"83a6c71d478aa6f95ae452ae3edcd900d65aebfb45fdccd56e06b1b038bc4092")

