-- Lua provided by RyzenAPI
-- Game: Twilight City: Love as a Cure

-- MAIN APPLICATION
addappid(428270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(428271, 1, "670ac36029b866e723b109dc9349e73054f37205c7878a73d2d71773436ad92d")
addappid(428272, 1, "3c90dcd4199aec26d0d551a2c591d8797466f59f209bf132a7ab63737e1262f5")
addappid(428274, 1, "83af61d5cfea3afd787029cb57350e7b7e6acb16de8ae621500948103d2933e9")
addappid(428275, 1, "7acba729f6366957bc984fe8cda4bc349930daad2c83b4fd5aea3b312c444bff")
addappid(428276, 1, "f62955c04e9fe61098d4cf856db5dffb4dd21caa56aa4a3b31c73a161c75d8ea")
addappid(428277, 1, "e07f68244950acb8170e00471ac8c9dd5d3d536c6e95653416d516bc0bac5263")

