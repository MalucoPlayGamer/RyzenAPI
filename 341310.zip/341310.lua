-- Lua provided by RyzenAPI
-- Game: addappid(341310)

-- MAIN APPLICATION
addappid(341310)

-- MAIN APP DEPOTS / PACKAGES
addappid(341311, 1, "39e5a8ea56ded4537fabc6d219d9e78d29f458572edede5109bc218f517b3dec")
