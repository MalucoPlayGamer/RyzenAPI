-- Lua provided by RyzenAPI
-- Game: Greyfox RPG

-- MAIN APPLICATION
addappid(341310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(341311, 1, "39e5a8ea56ded4537fabc6d219d9e78d29f458572edede5109bc218f517b3dec")

