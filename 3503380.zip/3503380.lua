-- Lua provided by SkyAPI 
-- Game: AppID 3503380
addappid(3503380)
addappid(3503381, 1, "3193e06a91023d69dfb096801832ce3e58cd87ad5b10c56747a9099662a119a6")
