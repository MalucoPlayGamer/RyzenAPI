-- Lua provided by RyzenAPI
-- Game: 寻龙分金模拟器

-- MAIN APPLICATION
addappid(3503380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3503381, 1, "3193e06a91023d69dfb096801832ce3e58cd87ad5b10c56747a9099662a119a6")
