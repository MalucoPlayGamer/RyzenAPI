-- Lua provided by RyzenAPI 
-- Game: Saints Row IV: Inauguration Station
addappid(242590)
addappid(242591, 1, "2ba61bea9de2a8e359243bf73cc57ce282caa13d87d2564e82ba8d358fd789c8")
addappid(242592, 1, "3b67173c806112ee884e713c13ccbea9324d9cc8553f298be8766259079c36a6")
addappid(242593, 1, "29b9a836aca98baa81ba4cfd31b30f70895831c60002cf3fa39f721259d19c98")
