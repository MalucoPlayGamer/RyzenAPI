-- Lua provided by RyzenAPI
-- Game: Valnir Rok Survival RPG

-- MAIN APPLICATION
addappid(658980)

-- MAIN APP DEPOTS / PACKAGES
addappid(658981, 1, "db203cbc20ea4822a59bbd8e944ce18f4be92524ab1daa986d5d4cbce5cd45fa")
