-- Lua provided by RyzenAPI
-- Game: 1505680

-- MAIN APPLICATION
addappid(1505680)
-- Game: addappid(1505680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505681, 1, "f52b4318e97fb8141f820ac9385c5b252e84c5aa367b9c5bdf78a9e4f8e85901")
