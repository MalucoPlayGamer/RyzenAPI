-- Lua provided by RyzenAPI
-- Game: Whitewater VR: Extreme Kayaking Adventure

-- MAIN APPLICATION
addappid(2360340)
-- Game: addappid(2360340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360341, 1, "0fedd17ae7fda6201a8040baa266afa7688737bdf68049f96a5594c635fdce2a")
