-- Lua provided by RyzenAPI
-- Game: Whitewater VR: Extreme Kayaking Adventure

-- MAIN APPLICATION
addappid(2360340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360341, 1, "0fedd17ae7fda6201a8040baa266afa7688737bdf68049f96a5594c635fdce2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
