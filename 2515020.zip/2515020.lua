-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY XVI

-- MAIN APPLICATION
addappid(2515020)
addappid(2886900)
addappid(3142080)
addappid(3142090)
addappid(3142100)
addappid(3372350)
addappid(3372360)
-- Game: addappid(2515020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515021, 1, "a1bc4011c581932ab613727be50494068bd3d57d59fa0f60bef081401902a046")
addappid(2515022, 1, "3bf28fa5738f1732e7e31ca3de269b6690be6a325d2ce76da6f924ddf812b90b")
addappid(2744050, 0, "bc72920eacff6d82dae14ecb5d72a42f4ecbba95f5aab7db874e4cea87e8801e")
addappid(2744060, 0, "e57aab17d957ce339fc8bfa53c929fdaa17fa91f3355b40c9bd25e8ba1f1ff83")
addappid(3372351, 1, "08563a78682af9b68bfba279c1bbaac0547124141da786614bcbf79d4721dd91")
addappid(3372361, 1, "925873942a1404520bdac75d984b41af4be65f647df751cd6c9381c032f347d4")
