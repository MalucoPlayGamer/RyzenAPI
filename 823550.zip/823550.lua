-- Generated with Luie @ https://lua.tools/
-- 823550 - Booty Calls
-- Generated 2026-08-23 06:43:21 UTC
-- # Depots (Total/DLC/Shared): 5/0/2

-- Main AppID
addappid(823550)

-- Main Depots
addappid(823551, 1, "f417a1e53ee609179fd266d27c20cd4c644f771a8dba8045fd34001eaa651f59") -- (macos)
setManifestid(823551, "5588459607009983508", 231153623)
addappid(823552, 1, "dfccf1c12f5e123330fd2d23bd7447dea9967d82a4d60b83d6215f48bdeb7a55") -- (windows, 32-bit)
setManifestid(823552, "4099489611665299852", 195006018)
addappid(823553, 1, "0012b61c51fa0623857ea0b01a31b2c87a78054c3c6382ceca15959d861c5616") -- (windows, 64-bit)
setManifestid(823553, "2414247519056328607", 203688666)

-- DLC's (no depot keys required)
addappid(1676041) -- Booty Calls - Lulu Furry Pack
addappid(1676042) -- Booty Calls - Eva Elfie Pack
addappid(1676043) -- Booty Calls - Miyu Pack
addappid(1676044) -- Booty Calls - Eve Pack
addappid(3498420) -- Booty Calls - Sweetie Fox Pack

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
