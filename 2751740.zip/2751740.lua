-- Lua provided by RyzenAPI
-- Game: Collapsed Galaxy 2 Playtest

-- MAIN APPLICATION
addappid(2751740)
-- Game: addappid(2751740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751741, 1, "edb825a27e8bab5cab335f9dfef12a866072c879a0ebcb7b0d80551eae7ab391")
