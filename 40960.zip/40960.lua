-- Lua provided by RyzenAPI
-- Game: Stronghold 2: Steam Edition

-- MAIN APPLICATION
addappid(40960)
addappid(1802290)
-- Game: addappid(40960)

-- MAIN APP DEPOTS / PACKAGES
addappid(40961, 1, "d56d3ce32ce00d1da5135840cdb59ce3f6bb83ccb8a71423c94e44355d902873")
addappid(40962, 1, "54b1ddeb552841b1010b6f1b6e057467348f7683b240261792488c1e93309f3e")
addappid(40963, 1, "763f1c85d0fee5e824d7363bcf96831cd355deb14e85120fcf944109eab9990a")
addappid(40964, 1, "dbb511c9687f34f73c6b4a4bcabc2210c5ef324ef849711ba04ee4bde11b36c0")
addappid(40965, 1, "fb1c1a9ca6fdd3c3218101d329fa5e7b570af0ff7c2c4a1b8af6c77ed3108724")
addappid(40966, 1, "a0da99723d07bc9598bccf0a435807bc3555d4051ef5e6b16b2238dc73828dce")
addappid(40967, 1, "b93e118b56e28256fa4c5b62813eeecd24da2440454f1fd95742ebc7bef67563")
addappid(40968, 1, "d23a6751c11ed6a1eccb2bbb3b8a22364e8bd3ac97517332633d9a2d4fe6e623")
