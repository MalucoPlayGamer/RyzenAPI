-- Lua provided by RyzenAPI 
-- Game: AppID 1479140
addappid(1479140)
addappid(1479141, 1, "a9fb539d8f51721164cf77f8eae5920f78569a47156b69a61f7aa1435f1f2343")
addappid(1479142, 1, "5aa484edabfed4cb8071959c5d5b56a1d3d3bb2e0b0560329518e9e4a895e1bb")
