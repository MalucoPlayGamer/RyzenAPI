-- Lua provided by RyzenAPI 
-- Game: Nova Strike
addappid(2320280)
addappid(2320281, 1, "1ca4e76714e38769f0fc24879b5434c524c329e238007a7b066b26f7ce85b9da")
