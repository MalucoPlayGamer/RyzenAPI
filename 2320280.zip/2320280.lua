-- Lua provided by RyzenAPI
-- Game: Nova Strike

-- MAIN APPLICATION
addappid(2320280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320281, 1, "1ca4e76714e38769f0fc24879b5434c524c329e238007a7b066b26f7ce85b9da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
