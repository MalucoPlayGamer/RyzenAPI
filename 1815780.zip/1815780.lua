-- Lua provided by RyzenAPI
-- Game: Asphalt Legends

-- MAIN APPLICATION
addappid(1815780)
addappid(4241640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1815781, 1, "5bcde2a5b270cc5f3a1a571b16fba5c90347280e05940c8ac301a5a38df2a451")

