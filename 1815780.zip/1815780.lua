-- Lua provided by RyzenAPI
-- Game: Asphalt Legends

-- MAIN APPLICATION
addappid(1815780)
addappid(4241640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815781, 1, "5bcde2a5b270cc5f3a1a571b16fba5c90347280e05940c8ac301a5a38df2a451")
