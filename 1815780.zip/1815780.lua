-- Lua provided by SkyAPI 
-- Game: Asphalt Legends
addappid(1815780)
addappid(1815781, 1, "5bcde2a5b270cc5f3a1a571b16fba5c90347280e05940c8ac301a5a38df2a451")
addappid(4241640)
