-- Lua provided by RyzenAPI
-- Game: Game: Aplestia

-- MAIN APPLICATION
addappid(791600)
-- Game: addappid(791600)

-- MAIN APP DEPOTS / PACKAGES
addappid(791601, 1, "a41c475de0e65d0ee2d3aa481177fdc13b8d0c7f7eaa178a4bf411214689def9")
