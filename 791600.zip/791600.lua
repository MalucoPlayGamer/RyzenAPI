-- Lua provided by RyzenAPI
-- Game: Aplestia

-- MAIN APPLICATION
addappid(791600)

-- MAIN APP DEPOTS / PACKAGES
addappid(791601, 1, "a41c475de0e65d0ee2d3aa481177fdc13b8d0c7f7eaa178a4bf411214689def9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
