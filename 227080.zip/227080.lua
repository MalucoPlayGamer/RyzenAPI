-- Lua provided by RyzenAPI
-- Game: AppID 227080

-- MAIN APPLICATION
addappid(227080)
-- Game: addappid(227080)

-- MAIN APP DEPOTS / PACKAGES
addappid(227081, 1, "ced0677b1c84f086354aebf2f8497e407af79f3fbe5d1a4476dea594d1139123")
addappid(227082, 1, "b0fc69533cc3128fb816a2c16401e16a21f9e97ce29b9420ecf0753c03f965cc")
addappid(227083, 1, "070409aecccb116da5c843acd926ab4e62e57d626298cda4a4a3543bd27b5450")
addappid(227090, 1, "fd2a1daa0bbbe41a3cfc3f1a20fda388520ce47f68b16d941021c98d9b68258c")
