-- Lua provided by SkyAPI 
-- Game: AppID 396220
addappid(396220)
addappid(396221, 1, "86b8fed2869dbe5624ca1b5e52f86dbd3754c56e268e904faf055771ae23529a")
addappid(396222, 1, "6b60dda3cd40990dbe29826788a5dffbb1f37d149a579462f99ab8a7cd9ce6e9")
addappid(396223, 1, "df023cad6f14e48e2dba154622f02b68ae97c5057f3687e85f5fb3de38696543")
