-- Lua provided by RyzenAPI
-- Game: 2206590

-- MAIN APPLICATION
addappid(2206590)
-- Game: addappid(2206590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206591, 1, "ba6e209dc1965b1297949ce3e2ecf3baa61088e16ae0ba80eb4fa318693b1c92")
