-- Lua provided by RyzenAPI
-- Game: 1368330

-- MAIN APPLICATION
addappid(1368330)
-- Game: addappid(1368330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368331, 1, "156d283a2efbace54d83e3ecc205e3e051030db5b4519db4cc5ea723cfd4cc6a")
