-- Lua provided by RyzenAPI
-- Game: Game: VR Marco Polo's Travelling in Medieval Asia (The Far East, Chinese, Japanese, Shogun, Khitan...revisit A.D. 1290)

-- MAIN APPLICATION
addappid(1368330)
-- Game: addappid(1368330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368331, 1, "156d283a2efbace54d83e3ecc205e3e051030db5b4519db4cc5ea723cfd4cc6a")
