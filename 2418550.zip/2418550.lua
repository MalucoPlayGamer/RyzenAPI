-- Lua provided by RyzenAPI 
-- Game: AppID 2418550
addappid(2418550)
addappid(2418551, 1, "d92498feed2b367570b4244314504f09881c4388728f17b6ce5cb66e075d94a6")
