-- Lua provided by RyzenAPI
-- Game: Project Planet - Earth vs Humanity Demo

-- MAIN APPLICATION
addappid(2409310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2409311, 1, "4ace4fdd68361574ec92c28b77887a28183f495cf12ea9978bc1aff40e70c479")

