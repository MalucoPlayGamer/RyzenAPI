-- Lua provided by RyzenAPI
-- Game: The Nameless Braves: Heaven

-- MAIN APPLICATION
addappid(1941750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1941751, 1, "9060ed6b2c14455f8487a8f7b80140200e45eaa4ad4d35fea661cff8c1956a80")

