-- Lua provided by RyzenAPI
-- Game: Game: AppID 1941750

-- MAIN APPLICATION
addappid(1941750)
-- Game: addappid(1941750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941751, 1, "9060ed6b2c14455f8487a8f7b80140200e45eaa4ad4d35fea661cff8c1956a80")
