-- Lua provided by RyzenAPI
-- Game: 3011440

-- MAIN APPLICATION
addappid(3011440)
-- Game: addappid(3011440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011441, 1, "5894cdfd02ee8ca54b8128ba76da4a550083907320ded4331482d29f23a2e9ac")
