-- Lua provided by RyzenAPI
-- Game: One Life Playtest

-- MAIN APPLICATION
addappid(3761850)
-- Game: addappid(3761850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3761851, 1, "52efab68dddbb629f6ac76e527d1b1920bfe8ae5af88428d65ddcbc051c46203")
