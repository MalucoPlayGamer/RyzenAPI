-- Lua provided by RyzenAPI 
-- Game: Little Spaceman
addappid(3560680)
addappid(3560681, 1, "a9d177e30bd6014b1e4812c66c23f40bb435f4297be8a65fdd9435cd0d0b1653")
