-- Lua provided by RyzenAPI
-- Game: Chaos Village

-- MAIN APPLICATION
addappid(1024690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1024691, 1, "10cd13da37bd9a9b32ec3e30b7fb6d90fbb19b5454c102f0b0524a07cde5a5ed")

