-- Lua provided by SkyAPI 
-- Game: Chaos Village
addappid(1024690)
addappid(1024691, 1, "10cd13da37bd9a9b32ec3e30b7fb6d90fbb19b5454c102f0b0524a07cde5a5ed")
