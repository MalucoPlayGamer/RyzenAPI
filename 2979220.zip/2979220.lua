-- Lua provided by SkyAPI 
-- Game: DEVIL'S WAY
addappid(2979220)
addappid(2979221, 1, "d620d1133789e09a4a11e37e4c24d3a8daa2b2fc978b8909615bdd2e7ac12124")
