-- Lua provided by RyzenAPI
-- Game: Game: AppID 929270

-- MAIN APPLICATION
addappid(929270)
-- Game: addappid(929270)

-- MAIN APP DEPOTS / PACKAGES
addappid(929271, 1, "10047866d38dec7c0f0fef3cfa406c522fae6db1ebda7e00709d2779732f2ecf")
addappid(929272, 1, "d785d660a2397b8c27b68220950c773081672e45c19608e9093a536b1d89baae")
