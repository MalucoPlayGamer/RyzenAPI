-- Lua provided by RyzenAPI
-- Game: SUDOKU IT

-- MAIN APPLICATION
addappid(5006820) -- SUDOKU IT

-- MAIN APP DEPOTS / PACKAGES
addappid(5006821, 1, "00c77a88f8644eae2ac9e175b064c78147617cd5ecca884c9cd2a2d4f9b5c8fc") -- Depot 5006821

