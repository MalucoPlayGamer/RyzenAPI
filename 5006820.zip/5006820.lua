-- 5006820's Lua and Manifest Created by Hubcap Manifest
-- SUDOKU IT
-- Created: August 12, 2026 at 15:00:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5006820) -- SUDOKU IT
-- MAIN APP DEPOTS
addappid(5006821, 1, "00c77a88f8644eae2ac9e175b064c78147617cd5ecca884c9cd2a2d4f9b5c8fc") -- Depot 5006821
setManifestid(5006821, "5581212749183331397", 217915964)