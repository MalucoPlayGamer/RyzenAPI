-- Lua provided by RyzenAPI
-- Game: 1538680

-- MAIN APPLICATION
addappid(1538680)
-- Game: addappid(1538680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538681, 1, "30d555fe683ce2d6a03da825d828ec7dd2df1d0afbc7050257d5316d39d0c75a")
addappid(1538682, 1, "b9ef57deda07d585a438cd82d009d42f527a9184af2e3650a95872fba4c051b1")
