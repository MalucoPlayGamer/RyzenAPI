-- Lua provided by RyzenAPI
-- Game: 1306240

-- MAIN APPLICATION
addappid(1306240)
-- Game: addappid(1306240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306241, 1, "da6240322cc2e0c0f6dc7b2256a7eed1714cd6f3bf7a99276b47f98498370562")
