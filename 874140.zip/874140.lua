-- Lua provided by RyzenAPI
-- Game: Othello 2018

-- MAIN APPLICATION
addappid(874140)

-- MAIN APP DEPOTS / PACKAGES
addappid(874141, 1, "48a4d7835194a9f22b3355fed660feaeb5a99596e1c72e1acd3dabfd3541d3ca")
