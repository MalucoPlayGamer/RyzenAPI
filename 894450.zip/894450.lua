-- Lua provided by RyzenAPI
-- Game: Game: AppID 894450

-- MAIN APPLICATION
addappid(894450)
-- Game: addappid(894450)

-- MAIN APP DEPOTS / PACKAGES
addappid(894451, 1, "0a1608746251ea865be6d8a958bed554884a33e272885c9c13a17711d288f4f4")
