-- Lua provided by RyzenAPI 
-- Game: AppID 3214400
addappid(3214400)
addappid(3214401, 1, "10251a6e179ae51a532296eec766e5c61b4802fb2b7fd92a60a84504d42d5a8d")
