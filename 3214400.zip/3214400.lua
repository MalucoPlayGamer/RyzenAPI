-- Lua provided by RyzenAPI
-- Game: addappid(3214400)

-- MAIN APPLICATION
addappid(3214400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214401, 1, "10251a6e179ae51a532296eec766e5c61b4802fb2b7fd92a60a84504d42d5a8d")
