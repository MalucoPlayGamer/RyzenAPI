-- Lua provided by RyzenAPI
-- Game: HAELE 3D - Feet Poses Lite - Drawing References

-- MAIN APPLICATION
addappid(2378840)
-- Game: addappid(2378840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378841, 1, "f676d6b54134f89ea06a7e18010faec74aed9e17236ae3b645993680be48ddfd")
