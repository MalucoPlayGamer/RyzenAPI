-- Lua provided by RyzenAPI
-- Game: HAELE 3D - Feet Poses Lite - Drawing References

-- MAIN APPLICATION
addappid(2378840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2378841, 1, "f676d6b54134f89ea06a7e18010faec74aed9e17236ae3b645993680be48ddfd")

