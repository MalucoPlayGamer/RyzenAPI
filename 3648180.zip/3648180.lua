-- Lua provided by RyzenAPI
-- Game: 3648180

-- MAIN APPLICATION
addappid(3648180)
-- Game: addappid(3648180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3648181, 1, "85229dd1612ae2d093e85acd853f418d4600114238d42fbc5189c3b6e5b03ef3")
