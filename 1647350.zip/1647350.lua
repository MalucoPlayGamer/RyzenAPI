-- Lua provided by RyzenAPI
-- Game: Anthology of Fear Demo

-- MAIN APPLICATION
addappid(1647350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647351, 1, "53b2aa549d3881995f945a8e73f77f8a351a55e817f0857329717b7525d13c84")

