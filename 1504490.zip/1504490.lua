-- Lua provided by RyzenAPI
-- Game: Game: bridg

-- MAIN APPLICATION
addappid(1504490)
-- Game: addappid(1504490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504491, 1, "4198fd98bd83aa665bd371f867579bb8c28bfdf0109e06d9a574064500f2887e")
