-- Lua provided by RyzenAPI
-- Game: Game: Alchemist of War

-- MAIN APPLICATION
addappid(1849430)
-- Game: addappid(1849430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849431, 1, "8572826dc39285ad81411c97da19277066227d4df03189925477a74f2d7e01f9")
