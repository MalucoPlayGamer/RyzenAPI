-- Lua provided by RyzenAPI
-- Game: addappid(2641940)

-- MAIN APPLICATION
addappid(2641940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641940,0,"144251bdcf0ea5ad21af924e1f6673e80d652161a9f4bf301aceef9c752f9aee")
