-- Lua provided by RyzenAPI
-- Game: Tower Island: Explore, Discover and Disassemble

-- MAIN APPLICATION
addappid(487740)
addappid(505470)

-- MAIN APP DEPOTS / PACKAGES
addappid(487741, 1, "c0794a394f697c0a671e501b61d32ccf6992327e5ebd11d3707c47652fe32f18")
