-- Lua provided by RyzenAPI 
-- Game: AppID 2478080
addappid(2478080)
addappid(2478081, 1, "584b0a8df737013882350f692d2454917ced33779ee1da972366f5f5df87d5bf")
