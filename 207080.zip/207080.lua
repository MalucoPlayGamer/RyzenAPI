-- Lua provided by RyzenAPI
-- Game: AppID 207080

-- MAIN APPLICATION
addappid(207080)
-- Game: addappid(207080)

-- MAIN APP DEPOTS / PACKAGES
addappid(207081, 1, "df53f0a83501b578c330fea60eb72a65df93f067f838a88476d2b0637db178a4")
addappid(207082, 1, "c3a4b57284c7f74d2d9839bd3f78c6e6878e4abaa9a10b19669262b9e1aeacff")
addappid(207083, 1, "dd7e5b28297cedfb402c40ab4d8dc278667797d42730b3d12bb1703cd5256b0d")
addappid(207090, 1, "74634f15860d5abca87fe40ace0d3eea12d9f05719f790aeef20b3b3a70f0c4e")
