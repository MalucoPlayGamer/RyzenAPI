-- Lua provided by RyzenAPI
-- Game: FUSER™ - Beast Business - "Royce Please"

-- MAIN APPLICATION
addappid(1652860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652860,0,"7165d9b8cb372e5d278dbea6415c9373243cc98ba0eade26fca710caa4626e22")

