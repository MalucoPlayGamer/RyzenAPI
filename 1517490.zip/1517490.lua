-- Lua provided by SkyAPI 
-- Game: Peaceful Gunner
addappid(1517490)
addappid(1517491, 1, "e2ed7f9b2f73480ec33009b366a1138bff8cdce50106202a75654c044f7e183d")
