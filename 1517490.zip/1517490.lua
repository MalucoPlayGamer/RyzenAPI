-- Lua provided by RyzenAPI
-- Game: Peaceful Gunner

-- MAIN APPLICATION
addappid(1517490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517491, 1, "e2ed7f9b2f73480ec33009b366a1138bff8cdce50106202a75654c044f7e183d")
