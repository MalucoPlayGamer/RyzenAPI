-- Lua provided by RyzenAPI
-- Game: Four Last Things

-- MAIN APPLICATION
addappid(503400)
addappid(4562470)
-- Game: addappid(503400)

-- MAIN APP DEPOTS / PACKAGES
addappid(503401, 1, "cf7df1122ce42820efd08ac9a54c459a097f1a3b5de847969e283723ce185f49")
