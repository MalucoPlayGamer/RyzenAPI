-- Lua provided by RyzenAPI
-- Game: Four Last Things

-- MAIN APPLICATION
addappid(503400)
addappid(4562470)

-- MAIN APP DEPOTS / PACKAGES
addappid(503401, 1, "cf7df1122ce42820efd08ac9a54c459a097f1a3b5de847969e283723ce185f49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
