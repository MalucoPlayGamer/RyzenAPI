-- Lua provided by RyzenAPI
-- Game: 581350

-- MAIN APPLICATION
addappid(581350)
-- Game: addappid(581350)

-- MAIN APP DEPOTS / PACKAGES
addappid(581351, 1, "1ecc915fe140fdbe7c750f9a0ec8f6e7af26cab00f0978190119e4f4b22f74d5")
