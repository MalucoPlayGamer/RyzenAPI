-- Lua provided by RyzenAPI
-- Game: addappid(853050)

-- MAIN APPLICATION
addappid(853050)

-- MAIN APP DEPOTS / PACKAGES
addappid(853051, 1, "005dc089615a9a8709300cb77f2bd77ed5ea72163c804cb57f5992df769bbc19")
