-- Lua provided by RyzenAPI
-- Game: SEX Tentacles [18+]

-- MAIN APPLICATION
addappid(2380410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380411, 1, "3ede6f8229cd02c5a5aec8fda7e6d6d290335c4beaea23aca867ed1af40c2246")
