-- Lua provided by RyzenAPI
-- Game: 1974210

-- MAIN APPLICATION
addappid(1974210)
-- Game: addappid(1974210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1974211, 1, "42f5ea3316b6db3d9f67082bc7ecb77daff806c1beceeb8b6479c9f468ab88ea")
