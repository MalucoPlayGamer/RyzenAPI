-- Lua provided by RyzenAPI
-- Game: Aerial Guardian

-- MAIN APPLICATION
addappid(885730)

-- MAIN APP DEPOTS / PACKAGES
addappid(885731, 1, "6b5c38e6ea0a2cf41001791ad52de9149e5b20837c0880ae864953dd0254f385")

