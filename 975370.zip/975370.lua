-- Lua provided by RyzenAPI
-- Game: AppID 975370

-- MAIN APPLICATION
addappid(975370)

-- MAIN APP DEPOTS / PACKAGES
addappid(975371, 1, "aa6347285a9e6c185411c629fb9b716ec5cb596c82f4c92b6ff4f975ecceca02")
addappid(975372, 1, "c614f2b35af4127b3055bd00e17855ab075066c9499166058d58f8ab634e7308")
addappid(975373, 1, "81d7b4688c2843358ad10f198f6f0a00a27d41800f4ad4109b933e6ac11ad955")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
