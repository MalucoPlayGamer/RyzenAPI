-- Lua provided by RyzenAPI
-- Game: Poltergeist Watcher

-- MAIN APPLICATION
addappid(2926550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926551, 1, "5726828e3966bc61bc9b1ea81c8f13ebb17c6f59f69ad396e202f9c5475d4745")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
