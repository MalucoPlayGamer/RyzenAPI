-- Lua provided by RyzenAPI
-- Game: Poltergeist Watcher

-- MAIN APPLICATION
addappid(2926550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926551, 1, "5726828e3966bc61bc9b1ea81c8f13ebb17c6f59f69ad396e202f9c5475d4745")

