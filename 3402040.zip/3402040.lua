-- Lua provided by RyzenAPI
-- Game: Sexy Furry - Fox Furry DLC

-- MAIN APPLICATION
addappid(3402040)
-- Game: addappid(3402040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402040,0,"638ef70f34ed9bb282f69d859243483d7b370d0996e2dcf47b9c8c125ad77180")
