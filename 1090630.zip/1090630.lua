-- Lua provided by RyzenAPI 
-- Game: Granblue Fantasy: Versus
addappid(1090630)
addappid(1090631, 1, "b5f78f47f569c27ce004a9fbfdded96e4aa71e27aaa6004283b2fcc5ecdaa615")
