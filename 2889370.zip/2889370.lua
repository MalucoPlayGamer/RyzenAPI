-- Lua provided by RyzenAPI
-- Game: 13层：公寓异常管理员 13 Floors: Anomalies

-- MAIN APPLICATION
addappid(2889370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2889371, 1, "c1b169100b91784265f35ad990994b07897bb78637142996fe1e84182dddb6f1")