-- Lua provided by RyzenAPI
-- Game: 13层：公寓异常管理员 13 Floors: Anomalies

-- MAIN APPLICATION
addappid(2889370)
-- Game: addappid(2889370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889371, 1, "c1b169100b91784265f35ad990994b07897bb78637142996fe1e84182dddb6f1")
