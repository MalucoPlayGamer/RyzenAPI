-- Lua provided by RyzenAPI
-- Game: Destruction 48

-- MAIN APPLICATION
addappid(619520)

-- MAIN APP DEPOTS / PACKAGES
addappid(619521, 1, "6ab9ba26b5a07fda0a605891bee1a12d9aafdcc3f29ed48c15f5efdbb7b563dd")

