-- Lua provided by RyzenAPI
-- Game: Game: Vidar

-- MAIN APPLICATION
addappid(355370)
addappid(630590)
-- Game: addappid(355370)

-- MAIN APP DEPOTS / PACKAGES
addappid(355371, 1, "e37b835126f8221232fddd0536f678ce0cc2db10d25468482071dad7024fd9bb")
