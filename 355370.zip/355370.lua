-- Lua provided by RyzenAPI
-- Game: Vidar

-- MAIN APPLICATION
addappid(355370)
addappid(630590)

-- MAIN APP DEPOTS / PACKAGES
addappid(355371, 1, "e37b835126f8221232fddd0536f678ce0cc2db10d25468482071dad7024fd9bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
