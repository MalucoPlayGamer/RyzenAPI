-- Lua provided by RyzenAPI
-- Game: Hot and Lovely : Seduction waifu

-- MAIN APPLICATION
addappid(3557760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3557761, 1, "8073d9b25785203feb08e8dc97357dd4850ff1b629f9d664d2c8296d653178ae")

