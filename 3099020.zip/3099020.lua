-- Lua provided by RyzenAPI
-- Game: Fast Food Simulator: Prologue

-- MAIN APPLICATION
addappid(3099020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3099021, 1, "18f197134f8fa1342ca56a97a94564e74f946653245c78724257a49c370a1b40")

