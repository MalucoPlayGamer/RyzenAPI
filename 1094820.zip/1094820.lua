-- Lua provided by RyzenAPI
-- Game: 徒花異譚 / Adabana Odd Tales

-- MAIN APPLICATION
addappid(1094820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094821, 1, "25352b3b06e18591994d59e7761c5b983fc285afbb525ea566c101850512c166")

