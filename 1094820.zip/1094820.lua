-- Lua provided by SkyAPI 
-- Game: AppID 1094820
addappid(1094820)
addappid(1094821, 1, "25352b3b06e18591994d59e7761c5b983fc285afbb525ea566c101850512c166")
