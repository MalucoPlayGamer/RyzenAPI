-- Lua provided by RyzenAPI
-- Game: addappid(1518190)

-- MAIN APPLICATION
addappid(1518190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518191, 1, "dbf8be83b6c4c0402ce69a0725ec530dbc5c6cd89c3c35603d5cd6abbbeaba62")
