-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3216920)
-- Game: addappid(3216920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216920,0,"131bb568d2ac6ea3be6f1e2582df787b3f05f1a23b6461559434587b056d7aef")
