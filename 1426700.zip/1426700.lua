-- Lua provided by RyzenAPI
-- Game: Devil May Cry 5 Vergil's Rebirth Sound Selection

-- MAIN APPLICATION
addappid(1426700)
-- Game: addappid(1426700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426701, 1, "dd1c38e85a8cf875e5b61e397ec6df2990cc68dbdd7faf923053e40a3530768d")
addappid(1426702, 1, "7317abf67f555128a335ba70495b864195bb2f81bcfbe9a69601d79d24a7888e")
addappid(1426703, 1, "8021b4edc4037bf105667279bea9e5651645602dbad122d44c0d0c4353d56d21")
