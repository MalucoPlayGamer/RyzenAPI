-- Lua provided by RyzenAPI
-- Game: Dead Island Definitive Edition

-- MAIN APPLICATION
addappid(383150)

-- MAIN APP DEPOTS / PACKAGES
addappid(383151, 1, "848765cbc4ad068b9676d33d38c720ad28c690b3aceceb467947e4564b95e9e4")
addappid(383152, 1, "2bbe10937bfd3798ca64c41702a970237c6316d80544d2f8636f344bd9f0f1f5")
addappid(383153, 1, "00b123ed897e65d3ed13036cbc16e867bfb0e31c14af87a2b3b35b425cef47d2")
addappid(383154, 1, "cfc88d94c4e825a0367280ca7395214ab6e6e73987ea66368b275b80a727b170")
addappid(383155, 1, "545717ce30503c9738098d4e5450da026acc272a575fe815d87d0cbcc600f1d9")
addappid(383156, 1, "1ef83354cda51c9e87f7901171d8ab5224fabf69e2605f550d47ed3ad1620bfd")
addappid(383157, 1, "eed0d30f6698a7562af48e6b88cd246befc2e76aa6fba153b63b952af19f41fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
