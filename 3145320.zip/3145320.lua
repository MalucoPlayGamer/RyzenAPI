-- Lua provided by RyzenAPI
-- Game: Elements and build

-- MAIN APPLICATION
addappid(3145320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3145321, 1, "62d81b3af6a664b111d82164de5063075fdd70c0c8c045eeb69b75b419c327f6")
