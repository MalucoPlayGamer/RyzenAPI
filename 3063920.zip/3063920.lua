-- Lua provided by RyzenAPI
-- Game: Game: Football Squad

-- MAIN APPLICATION
addappid(3063920)
-- Game: addappid(3063920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3063921, 1, "e871a0e8c69666a312783b31c1ab6df5e8312e417c641830a09f2caa900310fd")
