-- Lua provided by RyzenAPI
-- Game: AppID 1440080

-- MAIN APPLICATION
addappid(1440080)
-- Game: addappid(1440080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440081, 1, "a0caa08a36acfcd9c6d9db66bc13797ed8a7e3065bc924a7dc264d2dbfc1834b")
