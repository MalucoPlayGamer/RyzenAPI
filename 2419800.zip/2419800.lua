-- Lua provided by RyzenAPI
-- Game: Harem in Another World

-- MAIN APPLICATION
addappid(2419800)
addappid(4370250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419801, 1, "4a7bef718df8d31586cde9b359bb6f5357b205878529fe6025f4272be36bdd6f")
addappid(2850880, 0, "c3d2153b7af4d5803f71afcaf938f9d5c121ac3fff1cf8ffa6784f5c6edf0f57")

