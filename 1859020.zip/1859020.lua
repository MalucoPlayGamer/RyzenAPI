-- Lua provided by RyzenAPI
-- Game: Porcelain Tales

-- MAIN APPLICATION
addappid(1859020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859021, 1, "e80b1a0f961e1edc1742749c2de4a90052079b432ace860f79902e043e23e042")
