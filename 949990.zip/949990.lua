-- Lua provided by RyzenAPI
-- Game: addappid(949990)

-- MAIN APPLICATION
addappid(949990)

-- MAIN APP DEPOTS / PACKAGES
addappid(949991, 1, "49ad7a297f7b70388340cb88374270fe5e3d06b6df2d867e1208e66a6eafdda4")
