-- Lua provided by RyzenAPI
-- Game: AppID 2376110

-- MAIN APPLICATION
addappid(2376110)
-- Game: addappid(2376110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376111, 1, "65ddc97b2a0577859a7cb8489b271eb447d4c53143e82169bf13af6f72720ab4")
