-- Lua provided by SkyAPI 
-- Game: AppID 1083920
addappid(1083920)
addappid(1083921, 1, "db5d9071a47a00613cbf7e1eb557f6bd17c65e7dc92f4ef8113674b0b63c7907")
