-- Lua provided by RyzenAPI
-- Game: 3665970

-- MAIN APPLICATION
addappid(3665970)
-- Game: addappid(3665970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3665971, 1, "533a1e6b7f9c44cdaaacd98fa4826525117ede00d23fd0414b0c5bc8c51fd978")
