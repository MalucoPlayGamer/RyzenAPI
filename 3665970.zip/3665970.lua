-- Lua provided by RyzenAPI
-- Game: Drop Adventure - مغامرة قطرة

-- MAIN APPLICATION
addappid(3665970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3665971, 1, "533a1e6b7f9c44cdaaacd98fa4826525117ede00d23fd0414b0c5bc8c51fd978")

