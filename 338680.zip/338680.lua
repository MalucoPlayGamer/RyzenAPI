-- Lua provided by RyzenAPI
-- Game: addappid(338680)

-- MAIN APPLICATION
addappid(338680)

-- MAIN APP DEPOTS / PACKAGES
addappid(338681, 1, "ab87aa339d5f4a466812200060e14dab21859b0c757bfbbc40728c05be84b5e8")
