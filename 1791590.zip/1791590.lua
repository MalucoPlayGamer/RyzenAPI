-- Lua provided by RyzenAPI
-- Game: Sunset Hills

-- MAIN APPLICATION
addappid(1791590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791591, 1, "e02d286317336282bcd3d5c676620b5e49946ccc92fb4c7c4fbbab27f494bc17")
addappid(1791592, 1, "eddb467068198c7c2b8fc41c94df028118d3b82926de97e8e280135b15364d5a")
addappid(1791593, 1, "344f19bc8a7999c418b744571efcded013b13997eaa0f725090bb5c7a6a06a78")
addappid(1791594, 1, "1c634c0168c763c06499b52c75f2acc5b314fcfd739af52a5f2728539a4fb31b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4296440)
