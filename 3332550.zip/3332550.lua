-- Lua provided by RyzenAPI
-- Game: 3332550

-- MAIN APPLICATION
addappid(3332550)
-- Game: addappid(3332550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3332551, 1, "f0919dba04b97b8783ee28c5dac42003177ef763a2d7562860a02edef714b412")
