-- Lua provided by RyzenAPI
-- Game: Light in the woods

-- MAIN APPLICATION
addappid(3332550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3332551, 1, "f0919dba04b97b8783ee28c5dac42003177ef763a2d7562860a02edef714b412")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
