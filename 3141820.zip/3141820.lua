-- Lua provided by RyzenAPI
-- Game: addappid(3141820)

-- MAIN APPLICATION
addappid(3141820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141821, 1, "8b1b0af23ec0e5b65ba49528c059844b72deea41f13738873e0e59b0e4a0155f")
addappid(3141822, 1, "4182412daadc13c29d539f1eedc6f1c0b59aeb3fbb4a88d798377cfc96c807e4")
