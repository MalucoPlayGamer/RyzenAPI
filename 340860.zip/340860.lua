-- Lua provided by RyzenAPI
-- Game: 340860

-- MAIN APPLICATION
addappid(340860)
-- Game: addappid(340860)

-- MAIN APP DEPOTS / PACKAGES
addappid(340861, 1, "6db212b72d6e568b0aa7443eef48f6cff433fda8f6149d968397219fed78861f")
addappid(340862, 1, "4cbb81cf98b2c7283c9868be27aca1a87cbad4a1be0f37f72d7345c63e86b362")
