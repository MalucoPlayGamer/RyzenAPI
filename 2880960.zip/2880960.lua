-- Lua provided by RyzenAPI
-- Game: The Zombie Wave

-- MAIN APPLICATION
addappid(2880960)
-- Game: addappid(2880960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2880961, 1, "aaedf4e2fafa67b6596ad2eb27e5072b3503ded4691ef70a115d3db3da59895e")
addappid(2935970, 0, "8672d14359ddb0d510628f135a2f7eac25adf3580f3c5da06c9f91dbdd480c06")
