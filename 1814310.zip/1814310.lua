-- Lua provided by RyzenAPI
-- Game: Wicked Paradise

-- MAIN APPLICATION
addappid(1814310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814311, 1, "e33ceeaf8a7f318c2ca101c571cb21a1a625512ac3c01bbadd760463069d9a51")
