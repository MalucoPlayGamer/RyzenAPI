-- Lua provided by RyzenAPI
-- Game: Love Sucks Art Book

-- MAIN APPLICATION
addappid(2920350)
-- Game: addappid(2920350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920350,0,"3668e0f47962999c499d976b7dbc7bc43ca192ad461c94375e45bb9a7924e4f5")
