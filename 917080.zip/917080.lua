-- Lua provided by RyzenAPI
-- Game: This Is the Police 2 - Soundtrack

-- MAIN APPLICATION
addappid(917080)
-- Game: addappid(917080)

-- MAIN APP DEPOTS / PACKAGES
addappid(917080,0,"e1f9ca500ee2d80c6a2a9851cea129c327149076a5ab6cdf478211cd0fdac03c")
