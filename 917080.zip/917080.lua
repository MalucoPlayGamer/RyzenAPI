-- Lua provided by RyzenAPI
-- Game: 917080

-- MAIN APPLICATION
addappid(917080)

-- MAIN APP DEPOTS / PACKAGES
addappid(917080,0,"e1f9ca500ee2d80c6a2a9851cea129c327149076a5ab6cdf478211cd0fdac03c")

