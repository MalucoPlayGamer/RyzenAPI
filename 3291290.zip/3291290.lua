-- Lua provided by RyzenAPI
-- Game: Game: E-Commerce Simulator 2025

-- MAIN APPLICATION
addappid(3291290)
-- Game: addappid(3291290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291291, 1, "bff1faa09fb3461053e6792f0f645d98940e5147509a929b4009d287ebf6df37")
