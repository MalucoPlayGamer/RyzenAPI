-- Lua provided by SkyAPI 
-- Game: E-Commerce Simulator 2025
addappid(3291290)
addappid(3291291, 1, "bff1faa09fb3461053e6792f0f645d98940e5147509a929b4009d287ebf6df37")
