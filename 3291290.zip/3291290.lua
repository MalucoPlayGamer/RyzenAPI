-- Lua provided by RyzenAPI
-- Game: E-Commerce Simulator 2025

-- MAIN APPLICATION
addappid(3291290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291291, 1, "bff1faa09fb3461053e6792f0f645d98940e5147509a929b4009d287ebf6df37")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
