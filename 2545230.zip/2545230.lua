-- Lua provided by RyzenAPI
-- Game: Game: Raining City: Millions Recollections Demo

-- MAIN APPLICATION
addappid(2545230)
-- Game: addappid(2545230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545231, 1, "9b4990ff31985d4eec1ef999e0bf262875f0bd4c8775f4028ac6fc1266d5768c")
