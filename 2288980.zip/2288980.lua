-- Lua provided by SkyAPI 
-- Game: X4: Kingdom End Soundtrack
addappid(2288980)
addappid(2288981, 1, "b097cd8dc20634053bffed9ff710fce1d4bd8dc92c5c6e16a107272a5e5d0aa2")
addappid(2288982, 1, "3131100704077f834eaf705de6234f2ac293933834c053ea88085747dd0e0dd8")
