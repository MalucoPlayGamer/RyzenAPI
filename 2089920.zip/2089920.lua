-- Lua provided by RyzenAPI
-- Game: Shadow Heroes

-- MAIN APPLICATION
addappid(2089920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089921, 1, "4a12e816a251037245f4a8fe665a579d2a39de22db792829a9d1b79c0c43747b")
addappid(2161270, 0, "204ccab6a5cedd4d069c74d38a6503bdc9f72f61eb8416d7662b6634f4c0fecf")
