-- Lua provided by SkyAPI 
-- Game: Tinykin Demo
addappid(1884590)
addappid(1884591, 1, "8a7e9cdf248cdc504a93cdd4e0481fb00f0ddcc0888ab0eb737efd7b7e0b8b0a")
