-- Lua provided by RyzenAPI
-- Game: 1884590

-- MAIN APPLICATION
addappid(1884590)
-- Game: addappid(1884590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884591, 1, "8a7e9cdf248cdc504a93cdd4e0481fb00f0ddcc0888ab0eb737efd7b7e0b8b0a")
