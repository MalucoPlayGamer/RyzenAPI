-- Lua provided by RyzenAPI
-- Game: Game: Courtin' Cowboys

-- MAIN APPLICATION
addappid(2648870)
-- Game: addappid(2648870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2648871, 1, "0611cce317e51fa7efd8bf63ce0109e0b1ed00905a2272dd3bed80ae60e12852")
