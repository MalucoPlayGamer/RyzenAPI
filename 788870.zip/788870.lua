-- Lua provided by RyzenAPI
-- Game: In The Long Run The Game

-- MAIN APPLICATION
addappid(788870)

-- MAIN APP DEPOTS / PACKAGES
addappid(788871,0,"e8aed39f9225e376dcd7487e4a1e5906c0f8d1cd5c50840075c492b6fa429995")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
