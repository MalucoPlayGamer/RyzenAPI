-- Lua provided by RyzenAPI
-- Game: In The Long Run The Game

-- MAIN APPLICATION
addappid(788870)

-- MAIN APP DEPOTS / PACKAGES
addappid(788871,0,"e8aed39f9225e376dcd7487e4a1e5906c0f8d1cd5c50840075c492b6fa429995")

