-- Lua provided by RyzenAPI
-- Game: addappid(679900)

-- MAIN APPLICATION
addappid(679900)
addappid(1150360)

-- MAIN APP DEPOTS / PACKAGES
addappid(679901, 1, "fbea0591e68d74106d2081d100a9de4f487793098f754a2dd39425d1fc65d109")
addappid(679902, 1, "985c89217e0616a657cbc802b8af6c93df71ad8b7b0edacd792704b667f09ec9")
