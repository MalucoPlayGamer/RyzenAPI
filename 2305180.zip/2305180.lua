-- Lua provided by RyzenAPI
-- Game: Game: You are the Judge!

-- MAIN APPLICATION
addappid(2305180)
-- Game: addappid(2305180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305181, 1, "c3f22f368f49ae6bb156dcdd4ce88de2f126405fb3a05d45ba02afc5a6d7df54")
