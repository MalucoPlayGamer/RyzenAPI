-- Lua provided by RyzenAPI
-- Game: I drink Sorrel Coffee to reboot reality, but I'm being hunted by Monster Girls and armed agents

-- MAIN APPLICATION
addappid(3511020)
addappid(3703770)
addappid(3703780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3511021, 1, "c6aa942335bb0445fa85a1be3ab15ae6d6718e6793094d6f7d0836e4a5a9fea5")
addappid(3649220, 0, "13b49031393840261c7664bfca8e1c6c6266bf2bef8caafeec7c6d5ffcb7e502")

