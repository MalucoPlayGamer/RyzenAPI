-- Lua provided by RyzenAPI
-- Game: Ninja Midori

-- MAIN APPLICATION
addappid(858440)

-- MAIN APP DEPOTS / PACKAGES
addappid(858441, 1, "2ebc3a68025fe44f74f19deb63b7de1d6d23cdb2a8af392fb2466aa1d7d3c2da")
addappid(858442, 1, "e7120735e290213490fa19e522c9a2235e122455ab5569c5e66d786145996f72")
addappid(858443, 1, "dd81becbacc3908940d9cb7e5638ce22b9eaae6b47002a2e665e2e14625bb73e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
