-- Lua provided by RyzenAPI
-- Game: MicroProse™ Soccer

-- MAIN APPLICATION
addappid(1544740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544741, 1, "9a2600b98998248341b7b1b89ccd0b0754f3a6305135abd1d665d75f4baa4c2f")

