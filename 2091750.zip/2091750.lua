-- Lua provided by RyzenAPI
-- Game: Game: Cold Way

-- MAIN APPLICATION
addappid(2091750)
-- Game: addappid(2091750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091751, 1, "131abcbf0b278f18afb641693836da25e36e19dafa2436779b5dc2059e160f3e")
