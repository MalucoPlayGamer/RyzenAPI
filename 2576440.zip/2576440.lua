-- Lua provided by RyzenAPI 
-- Game: AppID 2576440
addappid(2576440)
addappid(2576441, 1, "b978ba1f5de305b0e4af3e55a2f2c1dbf8bbd91c0f995c89acee8e8389b57f56")
