-- Lua provided by RyzenAPI
-- Game: Game: XenoWorld ~The Rondeau of Astra~

-- MAIN APPLICATION
addappid(2227860)
-- Game: addappid(2227860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2227861, 1, "112dc66a40a643e1eae784e8342a1e2df03544a09be30113e8bfb8f9d67de274")
