-- Lua provided by RyzenAPI
-- Game: The Best Duck Clicker

-- MAIN APPLICATION
addappid(3110500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3110501, 1, "3d5b41da728fb0e18d0d6397c326704a513f619bc63fc3351c8d870cb2aa79e8")

