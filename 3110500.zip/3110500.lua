-- Lua provided by RyzenAPI
-- Game: The Best Duck Clicker

-- MAIN APPLICATION
addappid(3110500)
-- Game: addappid(3110500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3110501, 1, "3d5b41da728fb0e18d0d6397c326704a513f619bc63fc3351c8d870cb2aa79e8")
