-- Lua provided by RyzenAPI
-- Game: Game: VIRUS 91

-- MAIN APPLICATION
addappid(2598620)
-- Game: addappid(2598620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598621, 1, "554129a6fcb950981cf6d0fd3f3f5610dec9c9dfa47bdcf3ddff6a7b88636c61")
