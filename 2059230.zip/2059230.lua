-- Lua provided by RyzenAPI
-- Game: Game: AppID 2059230

-- MAIN APPLICATION
addappid(2059230)
-- Game: addappid(2059230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059231, 1, "58dab030a9e92317bb0f7888d046c4ef0c54925f2f31ae9325a04b1391475689")
