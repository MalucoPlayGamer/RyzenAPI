-- Lua provided by RyzenAPI
-- Game: Game: NIGHTSTAR: Alliance

-- MAIN APPLICATION
addappid(864970)
addappid(1039760)
-- Game: addappid(864970)

-- MAIN APP DEPOTS / PACKAGES
addappid(864971, 1, "b8e9339facd453981fbed41a0d41d5b6afdd24d380f6ca9f1c72b2e4b1942cbf")
