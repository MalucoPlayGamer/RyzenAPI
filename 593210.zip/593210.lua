-- Lua provided by RyzenAPI
-- Game: Game: Counter Fight: Samurai Edition

-- MAIN APPLICATION
addappid(593210)
-- Game: addappid(593210)

-- MAIN APP DEPOTS / PACKAGES
addappid(593211, 1, "567e89f256020964bcb4707d44588a8615ef463f2f9c72d39d354a7fc6c1c35f")
