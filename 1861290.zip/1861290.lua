-- Lua provided by RyzenAPI
-- Game: AppID 1861290

-- MAIN APPLICATION
addappid(1861290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861291, 1, "85e1d9cdacdedddfc86d58c3783b0e37734a5685bd9aef931911f8fdd0712554")

