-- Lua provided by RyzenAPI
-- Game: Water Drift

-- MAIN APPLICATION
addappid(1607860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607861, 1, "815dc9411716156dcdbb95ede702e8f72c49e314526fceb8f82b8a570bfcdc10")

