-- Lua provided by SkyAPI 
-- Game: Water Drift
addappid(1607860)
addappid(1607861, 1, "815dc9411716156dcdbb95ede702e8f72c49e314526fceb8f82b8a570bfcdc10")
