-- Lua provided by RyzenAPI
-- Game: Lost Chronicles of Zerzura

-- MAIN APPLICATION
addappid(308330)

-- MAIN APP DEPOTS / PACKAGES
addappid(308331, 1, "b3829138d590568c98e13f7623821a7309ea9b90a169922e0b8508251ebe3bf4")

