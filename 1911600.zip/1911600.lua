-- Lua provided by RyzenAPI
-- Game: Game: Lost Alone Ep.3 - Nonnina

-- MAIN APPLICATION
addappid(1911600)
-- Game: addappid(1911600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911601, 1, "6947949a225d57b6a8a4f22b6806ef072e65e0198f31789c34fac0d9084ad63c")
