-- Lua provided by RyzenAPI
-- Game: Sakura Succubus 6

-- MAIN APPLICATION
addappid(1961390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961391, 1, "2becab7ab959fbaa7adf57380ee64d20c4ebab33820c235bd47f932bf6ead22b")
