-- Lua provided by RyzenAPI
-- Game: addappid(796620)

-- MAIN APPLICATION
addappid(796620)

-- MAIN APP DEPOTS / PACKAGES
addappid(796621, 1, "66403ca45a92862b6e42b1f490f0add345ce3469801b00ee24b5cee7dfc90924")
addappid(1272430, 0, "0bddddb5040dce56ce7ededa5b76125b104d46e5ccbf832e285be0a5cce0bd4f")
