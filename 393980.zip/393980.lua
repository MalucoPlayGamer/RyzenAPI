-- Lua provided by RyzenAPI
-- Game: Game: AppID 393980

-- MAIN APPLICATION
addappid(393980)
-- Game: addappid(393980)

-- MAIN APP DEPOTS / PACKAGES
addappid(393981, 1, "d98c713232e11e5f8ca76916ca82f4b803c687f44fc6d23d121608ba51ca7565")
addappid(393982, 1, "c95e1febef325bbf8a3df273315a68068e9dd7d0764af81b83e6d11ff3fdc285")
