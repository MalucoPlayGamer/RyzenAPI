-- Lua provided by RyzenAPI
-- Game: Yet Another Zombie Survivors Demo

-- MAIN APPLICATION
addappid(2265230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265231, 1, "4b17bf875e268d55fdc948be5ba859b98bf27c6621111b16765f9f96d2685e6c")

