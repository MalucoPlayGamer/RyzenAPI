-- Lua provided by SkyAPI 
-- Game: HyperPortals
addappid(1917370)
addappid(1917371, 1, "a23910d450826062b90a456e8d4fda8b9bec2c0acdf8f092faf45bfcf68f2acb")
