-- Lua provided by RyzenAPI
-- Game: Game: AppID 1665800

-- MAIN APPLICATION
addappid(1665800)
-- Game: addappid(1665800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665801, 1, "36a5515383ca9663158ebecb9b613f59401e0a851459d2e452ab531ee1c8f472")
