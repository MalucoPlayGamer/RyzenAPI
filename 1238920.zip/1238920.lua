-- Lua provided by SkyAPI 
-- Game: Future Fragments
addappid(1238920)
addappid(1238921, 1, "695c29433df4e38e9ffd9f3ba326af791b0d0b77da7d7ae1eb69e0696e622b63")
