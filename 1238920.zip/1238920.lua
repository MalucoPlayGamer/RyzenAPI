-- Lua provided by RyzenAPI
-- Game: 1238920

-- MAIN APPLICATION
addappid(1238920)
-- Game: addappid(1238920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1238921, 1, "695c29433df4e38e9ffd9f3ba326af791b0d0b77da7d7ae1eb69e0696e622b63")
