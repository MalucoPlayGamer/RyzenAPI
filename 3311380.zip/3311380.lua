-- Lua provided by RyzenAPI
-- Game: addappid(3311380)

-- MAIN APPLICATION
addappid(3311380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311381, 1, "24a54ccc7ba322168388e5ecbc728788f90604fb6a94be17acd5c1639933962d")
