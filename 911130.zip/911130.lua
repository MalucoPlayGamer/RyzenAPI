-- Lua provided by RyzenAPI
-- Game: Puzzle Monarch: Vampires

-- MAIN APPLICATION
addappid(911130)

-- MAIN APP DEPOTS / PACKAGES
addappid(911131, 1, "8e98dfb8c43fb3122cab5eeb51d686ea5f5c10d44473dd7e6f34b32ef34b4d76")
