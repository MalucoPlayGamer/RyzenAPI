-- Lua provided by RyzenAPI
-- Game: Enoch Demo

-- MAIN APPLICATION
addappid(2146350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146351, 1, "8cd54154d8927868846e4b9af19510805cc361005ba35f45a1e00885cb5b8da4")

