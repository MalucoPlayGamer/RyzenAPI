-- Lua provided by SkyAPI 
-- Game: Enoch Demo
addappid(2146350)
addappid(2146351, 1, "8cd54154d8927868846e4b9af19510805cc361005ba35f45a1e00885cb5b8da4")
