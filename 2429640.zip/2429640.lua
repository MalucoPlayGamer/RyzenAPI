-- Lua provided by RyzenAPI
-- Game: Throne and Liberty

-- MAIN APPLICATION
addappid(2429640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429641, 1, "6051e96a5f7110e0d5d05b21a62e68943aa2048e0e243705f53272127fc25314")
