-- Lua provided by RyzenAPI
-- Game: Throne and Liberty

-- MAIN APPLICATION
addappid(2429640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429641, 1, "6051e96a5f7110e0d5d05b21a62e68943aa2048e0e243705f53272127fc25314")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3040080)
addappid(3040090)
addappid(3040100)
addappid(3138320)
addappid(3138330)
addappid(3138340)
addappid(3487970)
addappid(3487980)
addappid(3487990)
addappid(3717450)
addappid(3717460)
addappid(3717470)
addappid(3732870)
addappid(3820100)
addappid(3820110)
addappid(3820120)
addappid(3974160)
addappid(3974170)
addappid(3974180)
addappid(3974190)
addappid(4120020)
addappid(4120030)
addappid(4120040)
addappid(4333250)
addappid(4333270)
addappid(4333280)
addappid(4375020)
addappid(4444460)
addappid(4444470)
addappid(4444480)
addappid(4444490)
addappid(4538530)
addappid(4538540)
addappid(4538560)
addappid(4538570)
addappid(4806540)
addappid(4927180)
addappid(4947160)
addappid(4947170)
addappid(4947180)
