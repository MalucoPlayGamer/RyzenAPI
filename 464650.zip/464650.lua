-- Lua provided by RyzenAPI
-- Game: addappid(464650)

-- MAIN APPLICATION
addappid(464650)
addappid(505480)

-- MAIN APP DEPOTS / PACKAGES
addappid(464651, 1, "50eda759adc54de3108c3d2caaef040bf377c7ad87b3a4ce87801546b5095f95")
