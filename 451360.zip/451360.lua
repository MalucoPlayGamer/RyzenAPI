-- Lua provided by RyzenAPI
-- Game: Fenrisulfr Puzzle

-- MAIN APPLICATION
addappid(451360)

-- MAIN APP DEPOTS / PACKAGES
addappid(451361, 1, "33ab488618763c135d8192513a5ee5d96aff3d9d8cd8f7600768723b931c4044")
