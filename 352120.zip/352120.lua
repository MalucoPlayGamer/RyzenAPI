-- Lua provided by RyzenAPI
-- Game: Game: Fair Strike

-- MAIN APPLICATION
addappid(352120)
-- Game: addappid(352120)

-- MAIN APP DEPOTS / PACKAGES
addappid(352121, 1, "b36fc46968ca4c43a9a778fddae00a456ae3627c370b82d75c0b34dc6c77c15c")
addappid(352122, 1, "61b9e4f2c2303c68e453305e5404d008be2300fc6960be8f2bb6dcfe9d8bb541")
addappid(352123, 1, "3d9541baca91465ba6b9c3c7f81901a106af5b6ebfacbbfb80edcfbd09a10ecb")
addappid(352124, 1, "0485c5671fc010a0f80d7489963d6cd0496a42d2d86f836c84ccc51f7ca2a775")
addappid(352125, 1, "ad28ae307825f8256063488f1fd9504dbaf40d0355e84a8d492e2f11ffcf4d7d")
addappid(352126, 1, "661b1cc6bf24097516400cffcc47cd54f795d44e7c32d1d332a37676c644d3ac")
addappid(352127, 1, "bc495a095897378b5624988b64fccbb1fa285f96a51aa288fe17ef1d362cc085")
addappid(352128, 1, "e99d2994e7f45984a738a371e3f9c6e05ab3e8ed4b51f2e814235d1b5ef64e7e")
