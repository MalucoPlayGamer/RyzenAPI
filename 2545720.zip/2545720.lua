-- Lua provided by RyzenAPI
-- Game: 2545720

-- MAIN APPLICATION
addappid(2545720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545722,0,"9827e3920cfd7f553811cc3f9b52e5f8035dd05aa76bbe2fe1bffe370aeae164")
