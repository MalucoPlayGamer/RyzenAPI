-- Lua provided by RyzenAPI
-- Game: Game: AppID 644310

-- MAIN APPLICATION
addappid(644310)
-- Game: addappid(644310)

-- MAIN APP DEPOTS / PACKAGES
addappid(644311, 1, "75ca8e24ec9624d10469ff1888fc9912a2f38532df28b2436ac95b28b45df509")
