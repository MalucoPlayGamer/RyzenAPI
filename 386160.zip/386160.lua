-- Lua provided by RyzenAPI
-- Game: 386160

-- MAIN APPLICATION
addappid(386160)
-- Game: addappid(386160)

-- MAIN APP DEPOTS / PACKAGES
addappid(386161, 1, "89387595652c8116dbee9f935190c71df558a04ffbe3e5b9a9fbe463e9eddd80")
addappid(386162, 1, "ecf3228eb7e35be291e0ada5ab928eb6e4a77c7dbd760a343861d5ece37cddd3")
