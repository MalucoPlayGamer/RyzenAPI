-- Lua provided by RyzenAPI
-- Game: Game: Rabbit Hole 3D: Steam Edition

-- MAIN APPLICATION
addappid(283660)
-- Game: addappid(283660)

-- MAIN APP DEPOTS / PACKAGES
addappid(283661, 1, "e68ea3d839f99bf0b298ce3d8c2c7c1c0c5a65041bd912b2cb925878e10e37ae")
addappid(283662, 1, "dbccfcc2bb67509e833e5db57ce788d89286dc05349667a41917b242b4e4ef99")
addappid(283663, 1, "e3890e3fd33ba8a3592d483d49f6dfae4e9644dcd52bf4b6a0e633e62b4f7e63")
