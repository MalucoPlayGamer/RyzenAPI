-- Lua provided by RyzenAPI
-- Game: Amarillo's Butt Slapper

-- MAIN APPLICATION
addappid(3231090)
addappid(4622870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231091,0,"d1ad5cf0111a45abfbe5d87463f55175c6c6914dc78fe4388d5ec9580c3b03d3")

