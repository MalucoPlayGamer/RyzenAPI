-- Lua provided by RyzenAPI
-- Game: Lost Grimoires 2: Shard of Mystery

-- MAIN APPLICATION
addappid(574270)

-- MAIN APP DEPOTS / PACKAGES
addappid(574271, 1, "a0a8c6b652f3497a011297c8036e90bcee48c8d3be68b51ebd6b7c0aa8b0eca3")

