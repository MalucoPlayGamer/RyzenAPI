-- Lua provided by SkyAPI 
-- Game: AppID 574270
addappid(574270)
addappid(574271, 1, "a0a8c6b652f3497a011297c8036e90bcee48c8d3be68b51ebd6b7c0aa8b0eca3")
