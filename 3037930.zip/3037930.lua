-- Lua provided by RyzenAPI
-- Game: [Bober Bros] The Hole

-- MAIN APPLICATION
addappid(3037930)
-- Game: addappid(3037930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037931, 1, "f365b814864e076222c7c5747f3b29af7fa838de5283ae3d3b9abe252cba76e0")
