-- Lua provided by RyzenAPI
-- Game: addappid(305800)

-- MAIN APPLICATION
addappid(305800)
addappid(316070)
addappid(336320)

-- MAIN APP DEPOTS / PACKAGES
addappid(305801, 1, "2f92205b0c5cdc4e4ca9e9c325439ff7cdb70514cbd6937c0a6cc4a372220937")
addappid(305802, 1, "aca36fc9d4c2655c426897cf6b798f5a03d86955e8e580da4a4e9a24d9bcc042")
