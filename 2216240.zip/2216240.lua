-- Lua provided by SkyAPI 
-- Game: Business War: ERP Sandbox Simulation
addappid(2216240)
addappid(2216241, 1, "d38153722ce18168195312eb0e7eaf5a3f8bfe9ea77b83099655a0d94ed7882f")
