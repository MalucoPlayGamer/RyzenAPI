-- Lua provided by RyzenAPI
-- Game: Business War: ERP Sandbox Simulation

-- MAIN APPLICATION
addappid(2216240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216241, 1, "d38153722ce18168195312eb0e7eaf5a3f8bfe9ea77b83099655a0d94ed7882f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
