-- Generated with Luie @ https://lua.tools/
-- 1478050 - Tomb Rumble
-- Generated 2026-08-11 16:23:21 UTC
-- # Depots (Total/DLC/Shared): 5/0/0

-- Main AppID
addappid(1478050)

-- Main Depots
addappid(1478051, 1, "190398053adc598953427fd11ae75d1dd8f7f4875e46ac1c5e04d7fe80135ef7") -- (windows, 32-bit)
setManifestid(1478051, "495311176788370857", 110232128)
addappid(1478052, 1, "414976b73e0a9665e68f56d3508a296e5fef38610c99061e79e30e9cf5156b6a") -- (macos)
setManifestid(1478052, "4306451274193246840", 382525509)
addappid(1478053, 1, "77f26a4d4e7f05838717fc70ecebf2b0221ec8662f780aa2c2e63d4afccbdd6b") -- (linux, 64-bit)
setManifestid(1478053, "5334088474973609748", 138795147)
addappid(1478054, 1, "34a605c9a8e7044e2efdd1b41f375ab90bb9ada5a0cdc363373da75f7f94f685") -- (windows, 64-bit)
setManifestid(1478054, "4448398451644760825", 134615840)
addappid(1478055, 1, "344ec25e313cc3269b61ba6716328b2f6e4cf433cdbceef02e6fbab1135940a2") -- (linux, 32-bit)
setManifestid(1478055, "1961543194936324358", 140851511)

-- DLC's (no depot keys required)
addappid(1663700) -- Tomb Rumble - Cursed sorcerer
addappid(1738690) -- Tomb Rumble - Cursed vampire
addappid(1738700) -- Tomb Rumble - Home
