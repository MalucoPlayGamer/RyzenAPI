-- Lua provided by RyzenAPI
-- Game: Game: Tomb Rumble

-- MAIN APPLICATION
addappid(1478050)
-- Game: addappid(1478050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1478051, 1, "190398053adc598953427fd11ae75d1dd8f7f4875e46ac1c5e04d7fe80135ef7")
addappid(1478052, 1, "414976b73e0a9665e68f56d3508a296e5fef38610c99061e79e30e9cf5156b6a")
addappid(1478053, 1, "77f26a4d4e7f05838717fc70ecebf2b0221ec8662f780aa2c2e63d4afccbdd6b")
addappid(1478054, 1, "34a605c9a8e7044e2efdd1b41f375ab90bb9ada5a0cdc363373da75f7f94f685")
addappid(1478055, 1, "344ec25e313cc3269b61ba6716328b2f6e4cf433cdbceef02e6fbab1135940a2")
