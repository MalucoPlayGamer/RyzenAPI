-- Lua provided by RyzenAPI
-- Game: AppID 1209410

-- MAIN APPLICATION
addappid(1209410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209411, 1, "7af6081af1c233f9443cdbfdeefe9aae2f393706abe584b8366adad3834ac05f")

