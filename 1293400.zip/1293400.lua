-- Lua provided by RyzenAPI
-- Game: 1293400

-- MAIN APPLICATION
addappid(1293400)
-- Game: addappid(1293400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293401, 1, "637e6e10f067c1fc5e275f3d2716c8af98f3b216d59231e640764bf8e7e5de70")
