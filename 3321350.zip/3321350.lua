-- Lua provided by RyzenAPI
-- Game: Human Fast Food Demo

-- MAIN APPLICATION
addappid(3321350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3321351, 1, "045aaf899b1401665a74a30bede19dcb85f7cf26be0fd57fdf993978dace1433")
