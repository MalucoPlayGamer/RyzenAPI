-- Lua provided by RyzenAPI
-- Game: 燕赤霞

-- MAIN APPLICATION
addappid(1738570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1738571, 1, "664bf221cb1f420ec9b1b040b20b8974af6ea6ada9d70796e88974a57c14f530")
