-- Lua provided by RyzenAPI
-- Game: 1738570

-- MAIN APPLICATION
addappid(1738570)
-- Game: addappid(1738570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738571, 1, "664bf221cb1f420ec9b1b040b20b8974af6ea6ada9d70796e88974a57c14f530")
