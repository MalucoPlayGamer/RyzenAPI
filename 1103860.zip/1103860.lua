-- Lua provided by RyzenAPI
-- Game: Game: AppID 1103860

-- MAIN APPLICATION
addappid(1103860)
-- Game: addappid(1103860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103861, 1, "8cfec9cb1a721afa63655b301fd5b872632b30c028cf2a22fdba1d8202b895e5")
