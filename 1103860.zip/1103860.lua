-- Lua provided by RyzenAPI
-- Game: The Wizards - Dark Times

-- MAIN APPLICATION
addappid(1103860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1103861, 1, "8cfec9cb1a721afa63655b301fd5b872632b30c028cf2a22fdba1d8202b895e5")

