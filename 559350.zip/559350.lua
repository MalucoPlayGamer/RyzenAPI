-- Lua provided by RyzenAPI
-- Game: EURGAVA™: Fight for Haaria

-- MAIN APPLICATION
addappid(559350)

-- MAIN APP DEPOTS / PACKAGES
addappid(559351, 1, "3bde5b73ba98dc4923970bc96cfe774a5e045f15e85cd8af81d0dd950a2c12bd")

