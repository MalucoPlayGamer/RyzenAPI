-- Lua provided by RyzenAPI
-- Game: 小兵习武 Demo

-- MAIN APPLICATION
addappid(3050820)
-- Game: addappid(3050820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3050821, 1, "d3adf3ffa858f87daacb8f0c3acfc663092c8ab514f5660b365241c5a870abeb")
