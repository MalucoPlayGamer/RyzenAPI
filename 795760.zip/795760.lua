-- Lua provided by RyzenAPI 
-- Game: AppID 795760
addappid(795760)
addappid(795761, 1, "14bf47834557d54fa30c0534b2fcf5171cd81877085541bfcab5ab06741bcf67")
