-- Lua provided by RyzenAPI
-- Game: COTTOn 2 - Saturn Tribute

-- MAIN APPLICATION
addappid(1708800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708801, 1, "1b8982dbc71a50e486c98b3dc707f766d73f86c0042049d29121673e1c7f7b87")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
