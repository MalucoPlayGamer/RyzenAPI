-- Lua provided by RyzenAPI
-- Game: AppID 1167170

-- MAIN APPLICATION
addappid(1167170)
addappid(1806781)
addappid(1957261)
addappid(2309321)
addappid(2462671)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167171, 1, "8470063fbd0a81fe63078fd81dbc2abb14934c41c8bd7a08963af91c4617bf57")
addappid(1785111, 0, "0329cb7391ebb90024f1ea0eab534d24dd78681aa94f084c2baa08d094808ee4")
addappid(2290391, 0, "6b6ceafd249d75f7157443f415b75ea7458c1ba50dac9ff8685b1900f3ac66e5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1785110)
addappid(2290390)
