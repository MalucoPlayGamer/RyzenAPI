-- Lua provided by RyzenAPI
-- Game: Game: 三国大领主

-- MAIN APPLICATION
addappid(2242510)
-- Game: addappid(2242510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242511, 1, "17fa02d275fb4ffbfe8a9f2812c579cb37dfd367fbd047d8f274db32b9d14dc3")
