-- Lua provided by RyzenAPI
-- Game: Typing Fingers

-- MAIN APPLICATION
addappid(1450860)
addappid(1450863)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450862,0,"33622f2eb73fcd9f9962791417e4cd4e85dfe3758c9308a758235ac982d4a49c")

