-- Lua provided by RyzenAPI
-- Game: 2541360

-- MAIN APPLICATION
addappid(2541360)
-- Game: addappid(2541360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541361, 1, "572dad92db31c4e94894d9856656b801a0988fff70aebbbec64bf7a7cdd4be8b")
