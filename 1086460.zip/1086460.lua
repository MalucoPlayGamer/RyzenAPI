-- Lua provided by RyzenAPI
-- Game: Supermarket Shriek

-- MAIN APPLICATION
addappid(1086460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086461, 1, "d5175f1f66fa162a9671c706a31c01ad7eb0b40fc984dd14702c55cda7df20de")

