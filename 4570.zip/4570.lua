-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Dawn of War - Anniversary Edition (Classic)

-- MAIN APPLICATION
addappid(4570)

-- MAIN APP DEPOTS / PACKAGES
addappid(4571, 1, "cd29e710bc768c891460d4b29858905d8a9c25eb3c11c16912d7296fe9ac2270")
addappid(4572, 1, "7f5ef5d88b2ca50cf1279f3185ac95b1255c09a29b3c2a4af7325deecee926f1")
addappid(4573, 1, "ef7b8a5b2b3732cd1284ef1004272a2c6d1c6ae60160860b09f50004cb43e141")
addappid(4574, 1, "b6363d215e674b4b4f1f51023e2aa223deff4471eb4662464c2bc8a74a826f3c")
addappid(4575, 1, "d53eef39d2d9daf87e8c0442388792ccc181d627d73284afcad7b68151c8fd49")
addappid(4576, 1, "ef666ae4e383c0f0ca02b56189bab8e6120cd6bd905c0d3fb172a479db11517c")
addappid(4577, 1, "6a170b9c3f47d515d32af19775049e22c4bf0f9e67edd3a8fa0de67162ae7178")
addappid(4578, 1, "eacc86720ac93f9ef053b5a24a91fc6c5d469ea19b96a4d1b6330bb81a2bbb05")

