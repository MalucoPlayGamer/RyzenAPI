-- Lua provided by RyzenAPI
-- Game: World War 2: Strategy Simulator

-- MAIN APPLICATION
addappid(1401170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401172,0,"e9ceaae9ceaa57bc6f0821b9cf8b43e189eb2d0e83e8bce0f4d346ece863e34f")
