-- Lua provided by RyzenAPI
-- Game: Game: Minimalist Sudoku

-- MAIN APPLICATION
addappid(3397830)
-- Game: addappid(3397830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3397831, 1, "4f927e0683d81d529517283369466747450e3231816bf1eca712e15f4b51fbfe")
