-- Lua provided by RyzenAPI
-- Game: 655790

-- MAIN APPLICATION
addappid(655790)
-- Game: addappid(655790)

-- MAIN APP DEPOTS / PACKAGES
addappid(655791, 1, "cacef8fe3eee773cc08a38d2a7812250e8245fccb058b809072fd1b210a31fb0")
