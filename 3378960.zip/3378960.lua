-- Lua provided by RyzenAPI
-- Game: Lost Soul Aside™

-- MAIN APPLICATION
addappid(3378960)
addappid(3484230)
addappid(3484240)
addappid(3596880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3378961, 1, "02157efe6285cacaa20730d8f0bd83c4b020ec25cd0c75e88ad7ac83465a570a")
addappid(3484241, 0, "850583f98b56a2b21b65c877cf536c83830fa54c21f30ce3c6397935f065b2bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
