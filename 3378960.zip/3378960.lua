-- Lua provided by RyzenAPI
-- Game: Lost Soul Aside™

-- MAIN APPLICATION
addappid(3378960)
addappid(3484230)
addappid(3484240)
addappid(3596880)
-- Game: addappid(3378960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3378961, 1, "02157efe6285cacaa20730d8f0bd83c4b020ec25cd0c75e88ad7ac83465a570a")
addappid(3484241, 0, "850583f98b56a2b21b65c877cf536c83830fa54c21f30ce3c6397935f065b2bc")
