-- Lua provided by RyzenAPI
-- Game: Optika

-- MAIN APPLICATION
addappid(504400)
addappid(516910)
addappid(516919)

-- MAIN APP DEPOTS / PACKAGES
addappid(504401, 1, "b15dd7a451b1b149e37953f6d921311c2e703619ec20883fc12f5d5bfeb5b133")
addappid(504402, 1, "70f87b412ed95caf605545f5ca1ce66e02f7d0dda5b6214961c1d866568e357e")

