-- Lua provided by RyzenAPI
-- Game: GALAK-Z

-- MAIN APPLICATION
addappid(300580)

-- MAIN APP DEPOTS / PACKAGES
addappid(300581, 1, "c53e4f3651249f963df313fb958c891082492a3b5584533532c1a5a488cd04e5")
addappid(300583, 1, "66dbd21a4eb3d0f525e8e122eda54b45999da1fe2747c476486e60ce5542b400")
addappid(300584, 1, "a8edde558863c7c2ec35f85073d793b80fa00b5c1b5834961835a49e5f8f3447")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
