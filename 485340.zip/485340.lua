-- Lua provided by RyzenAPI
-- Game: The Orchard of Stray Sheep

-- MAIN APPLICATION
addappid(485340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(485341, 1, "0a476797990067ec82fc6d6baa75e6a19fb8f182ee5414776165364240d196b6")
addappid(485342, 1, "75f392e34fa0a8026156b2053a4aa6c29a691734149379edadd8bf00b31d206e")
addappid(485343, 1, "f853eb3d738deea5974261a570f75fb89dcbd25421e7e14fd5819e35ed90c5e8")

