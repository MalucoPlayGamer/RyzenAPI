-- Lua provided by RyzenAPI
-- Game: ASTRAL

-- MAIN APPLICATION
addappid(703600)
-- Game: addappid(703600)

-- MAIN APP DEPOTS / PACKAGES
addappid(703601, 1, "85dae224188eb68654ce3f636239a746c41329824b6e859c27efe6aead6c8bd8")
