-- Lua provided by RyzenAPI
-- Game: Tentacles Party With Nuns Demo

-- MAIN APPLICATION
addappid(2799250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799251, 1, "e615774b572e413433acbed9966e958a924d9de0264eae2be1a42bb4d73f9469")

