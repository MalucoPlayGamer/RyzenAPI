-- Lua provided by RyzenAPI
-- Game: Mathigo

-- MAIN APPLICATION
addappid(3531680)
-- Game: addappid(3531680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3531681, 1, "45000f2843a71324bb76140dbbf2a3c6c55d450f40e0f5dc42c01296fa387be9")
