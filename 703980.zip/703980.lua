-- Lua provided by RyzenAPI
-- Game: Game: Star Wars: Imperial Assault - Legends of the Alliance

-- MAIN APPLICATION
addappid(703980)
-- Game: addappid(703980)

-- MAIN APP DEPOTS / PACKAGES
addappid(703981, 1, "902aabb146f738dfeb01cf99d6f80c3554abe5f194507549b0f488b07bd1f6dc")
addappid(703982, 1, "ef9c913aadf40062080bb5f98494a36e2ae36049072611e78ac4f0253bc01a71")
