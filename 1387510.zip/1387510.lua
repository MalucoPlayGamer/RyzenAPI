-- Lua provided by RyzenAPI
-- Game: 1387510

-- MAIN APPLICATION
addappid(1387510)
-- Game: addappid(1387510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387511, 1, "e608bf59f7cc2dc52833ed48833bc2eec9f77848d5aad715f324ee610692ae25")
