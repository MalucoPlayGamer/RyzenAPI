-- Lua provided by RyzenAPI 
-- Game: Last Mortem
addappid(1387510)
addappid(1387511, 1, "e608bf59f7cc2dc52833ed48833bc2eec9f77848d5aad715f324ee610692ae25")
