-- Lua provided by RyzenAPI
-- Game: addappid(1555570)

-- MAIN APPLICATION
addappid(1555570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1555571, 1, "6bc46a09eb07e71d85b7fa5c4b9ed04bfbc1397d7b45ca01d9ae6e867dfc9d48")
