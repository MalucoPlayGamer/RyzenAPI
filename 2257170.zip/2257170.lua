-- Lua provided by SkyAPI 
-- Game: Disaster Area
addappid(2257170)
addappid(2257171, 1, "967b2ee21547ae9ac414b1cb2ab4e241a9ba3de74b6108ab15168bc9679f8512")
