-- Lua provided by RyzenAPI
-- Game: Game: AppID 1264770

-- MAIN APPLICATION
addappid(1264770)
-- Game: addappid(1264770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264771, 1, "47254e49ed7aa6d688810a1843490d13872ffbab617b9a4fe7cf0545d0b53be8")
