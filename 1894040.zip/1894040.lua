-- Lua provided by RyzenAPI
-- Game: 白昼夢の青写真 Soundtrack CASE-3

-- MAIN APPLICATION
addappid(1894040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894041, 1, "2d3b5c0e8421a7e137eddd1436c38f3f09f76ad0771c92d13c0333805d35b011")
addappid(1894042, 1, "d4e24867eac4a9f40f130a9f6703db976598b510e855ca0fc5dabc923c9e73c0")
