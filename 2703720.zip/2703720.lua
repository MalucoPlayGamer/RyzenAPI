-- Lua provided by RyzenAPI
-- Game: Bobos FunZone

-- MAIN APPLICATION
addappid(2703720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703721, 1, "1bb7cdfc4a5cc604dcd3eaa474fa5a2abe26f99f4334684730b982f11f38033f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
