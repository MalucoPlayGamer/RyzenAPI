-- Lua provided by RyzenAPI
-- Game: Bobos FunZone

-- MAIN APPLICATION
addappid(2703720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703721, 1, "1bb7cdfc4a5cc604dcd3eaa474fa5a2abe26f99f4334684730b982f11f38033f")
