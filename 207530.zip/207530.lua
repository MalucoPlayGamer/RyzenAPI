-- Lua provided by RyzenAPI
-- Game: Game: Noitu Love 2: Devolution

-- MAIN APPLICATION
addappid(207530)
-- Game: addappid(207530)

-- MAIN APP DEPOTS / PACKAGES
addappid(207531, 1, "65a8f56a93429d13f0cd8a33a531f7f1b521833f8e43438a9ce687e422513335")
