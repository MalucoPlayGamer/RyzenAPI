-- Lua provided by RyzenAPI
-- Game: Erotic Justice

-- MAIN APPLICATION
addappid(2539120)
-- Game: addappid(2539120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2539123,0,"d121d20b71d0b63d630e39e683506c9960375dd9a0841006be54a53c5c4cee58")
addappid(2539124,0,"24e0ccae63316f045d39a14dd457c947ab1ba110447d50ad316fe27bc12d6ca5")
