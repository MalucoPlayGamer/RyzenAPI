-- Lua provided by RyzenAPI
-- Game: Game: AppID 504210

-- MAIN APPLICATION
addappid(504210)
-- Game: addappid(504210)

-- MAIN APP DEPOTS / PACKAGES
addappid(504211, 1, "9ab4015eaef5cfa7d0dd10c2f4f8c309ff79bed610f6830ee81adfa902cfefd6")
addappid(504212, 1, "a134fe5b8a15752af53905dabca21d681193c60f6d1cb7b8f4d756d37205e672")
addappid(504213, 1, "66ac5e2056f57402a9e54dd63877603305302e78c9e4154c4425aa8c9378fc86")
