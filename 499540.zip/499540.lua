-- Lua provided by RyzenAPI
-- Game: 499540

-- MAIN APPLICATION
addappid(499540)
-- Game: addappid(499540)

-- MAIN APP DEPOTS / PACKAGES
addappid(499541, 1, "b3c3182c6954fb95c4185317d84adad96f6659a2e36f89c3a81f2e6e8ef95cda")
