-- Lua provided by RyzenAPI
-- Game: addappid(1400290)

-- MAIN APPLICATION
addappid(1400290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400291, 1, "87b1d0bcdabbdbfea7f6a931dcf993a2efb8f23424c241d307d5e165d0a68fee")
