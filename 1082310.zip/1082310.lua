-- Lua provided by RyzenAPI
-- Game: addappid(1082310)

-- MAIN APPLICATION
addappid(1082310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082310,0,"f62088d8ce00be79a289fae2c5c326a650c5dd4a62ebca81e1b42b4a3481de6e")
