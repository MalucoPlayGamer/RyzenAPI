-- Lua provided by SkyAPI 
-- Game: Raceborn
addappid(3032600)
addappid(3032601, 1, "9f937f0fe94e335994b670758abecfa2c8ac4806775bf1c1f350656338643733")
