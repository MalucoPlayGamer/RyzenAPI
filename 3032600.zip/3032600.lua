-- Lua provided by RyzenAPI
-- Game: Raceborn

-- MAIN APPLICATION
addappid(3032600)
-- Game: addappid(3032600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032601, 1, "9f937f0fe94e335994b670758abecfa2c8ac4806775bf1c1f350656338643733")
