-- Lua provided by RyzenAPI
-- Game: Game: Grotto Demo

-- MAIN APPLICATION
addappid(1538880)
-- Game: addappid(1538880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538881, 1, "c07ecc7057163f186ac402161377a7f03017b227a75dead41caec62b3c69e267")
