-- Lua provided by RyzenAPI
-- Game: Panzer Elite Action Gold Edition

-- MAIN APPLICATION
addappid(292420)

-- MAIN APP DEPOTS / PACKAGES
addappid(292421, 1, "c7b83aeb04b8432df92c4f2188d9af1446b8cbcb8ef7860a253fd1add70c1ac5")
addappid(292422, 1, "ec6b0f66c66ee1fca4173fb06958326b1e9c82081f2a4ba5df4d0d5e40d2bd86")
addappid(292423, 1, "a69b29b59b2cde7afc4f8a8c58c0cc4e8274f7a81e6e71ed76644604eb5989cf")
addappid(292424, 1, "d7aa61a16683d73b33f7b466b61e4181daa55adba81a61b54868fe935276e110")
addappid(292425, 1, "6cb041605cbac9d9609b649baa5ebcc9abf1c7c6372dfb382817305e39beaf30")
addappid(292426, 1, "1466f7030dea75bfd12aa162ea82d7267e33a2e9ae9df7f13f4dc4689c9bc042")
addappid(292427, 1, "cfa0ef4ec873db8cd9b0ce9f852b042a44c8bcfd54e25566b3957f44fbd1699a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
