-- Lua provided by RyzenAPI
-- Game: Sea under the sea under the sea

-- MAIN APPLICATION
addappid(2718030)
-- Game: addappid(2718030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718031, 1, "1582f2f993b8eb933943dfcbec842f0ddcf403f652ab73f131f58323fce739a4")
