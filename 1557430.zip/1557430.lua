-- Lua provided by RyzenAPI
-- Game: Midnight is Lost

-- MAIN APPLICATION
addappid(1557430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557431, 1, "8bf68b2a253d8bb807076eb5ef409d201dc1ce3d84fa4ed193aabb90757e7cc0")

