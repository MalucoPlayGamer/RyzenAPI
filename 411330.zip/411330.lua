-- Lua provided by RyzenAPI
-- Game: Men of Valor

-- MAIN APPLICATION
addappid(411330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(411331, 1, "84f55b4d413d32361f4528c38e62cad3ae94b9ca592173e1f763972c79bb4f84")
addappid(411332, 1, "4398f9888d553e4af3b5232d41a05eb2fca04e425563a00d8d9deadab827ab7c")
addappid(411333, 1, "d14472efd68c5aad989b3261d2cb51e775bd402d228d332ffe5c43d90ef863e5")
addappid(411334, 1, "6527ae40464d0170decbdb8695cd616fa88185f46dac8db52c2e47a3f6e4ed39")

