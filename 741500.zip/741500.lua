-- Lua provided by RyzenAPI
-- Game: John, The Zombie

-- MAIN APPLICATION
addappid(741500)

-- MAIN APP DEPOTS / PACKAGES
addappid(741501, 1, "498bc9aef49022edf28109062043d6190a2d0530caba6702ce35d2ef914825d1")

