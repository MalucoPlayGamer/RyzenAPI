-- Lua provided by SkyAPI 
-- Game: Monster Prom Demo
addappid(1276400)
addappid(1276401, 1, "8c7e1432a319d0cc40fecbbf81027b59846f7e4a28d7999fc5fd8fb06b9f859b")
