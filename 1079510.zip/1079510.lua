-- Lua provided by SkyAPI 
-- Game: Sumerians
addappid(1079510)
addappid(1079511, 1, "632c99699436aaab7074ef521f6e58d929a0dd883b7c478fda0c3d07b15e555b")
addappid(2918320)
