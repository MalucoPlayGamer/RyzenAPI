-- Lua provided by RyzenAPI
-- Game: 1079510

-- MAIN APPLICATION
addappid(1079510)
addappid(2918320)
-- Game: addappid(1079510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079511, 1, "632c99699436aaab7074ef521f6e58d929a0dd883b7c478fda0c3d07b15e555b")
