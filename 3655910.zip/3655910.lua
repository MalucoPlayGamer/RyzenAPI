-- Lua provided by RyzenAPI
-- Game: addappid(3655910)

-- MAIN APPLICATION
addappid(3655910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655911, 1, "4c79712e9fa9da6d742c8ef991595bc468c2c3fab98e0989f1251f2c5e1ed4d7")
