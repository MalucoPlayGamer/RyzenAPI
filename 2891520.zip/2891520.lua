-- Lua provided by RyzenAPI
-- Game: addappid(2891520)

-- MAIN APPLICATION
addappid(2891520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891521, 1, "e03eb070392cfa4191dec3dd0d2beef11a8e9cfe9c1de5e57118002cf927491f")
