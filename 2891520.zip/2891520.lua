-- Lua provided by RyzenAPI 
-- Game: Deep Dark Wrath
addappid(2891520)
addappid(2891521, 1, "e03eb070392cfa4191dec3dd0d2beef11a8e9cfe9c1de5e57118002cf927491f")
