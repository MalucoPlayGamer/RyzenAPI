-- Lua provided by RyzenAPI
-- Game: Enishia and the Binding Brand

-- MAIN APPLICATION
addappid(2582650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582651, 1, "8ea2fbad7aa8878bd7e674aa550b35e8d4b750a2bce64c0ffeed92a421157200")
addappid(2582652, 1, "f505ee536ae4c88d3f84bfd824d866a2d385b3cb48580c5ecff9ba06d0ba1de4")
addappid(2582653, 1, "8b1ee3f6676e1efa49bb41c979e61634454ca32fe393f8564c2e71d809422460")
addappid(3047540, 0, "a15775e485b7b50aeb3a6ee4b02313660239f1bb19e27e29ffb3867b20600b65")
