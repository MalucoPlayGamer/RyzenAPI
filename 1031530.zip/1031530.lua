-- Lua provided by RyzenAPI
-- Game: 奇迹纪念册 The last 47 hours Commemorative Book

-- MAIN APPLICATION
addappid(1031530)
-- Game: addappid(1031530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031530,0,"9a8d125365e96548e5fe1a53eddac456e2ca9c0823cc9ac40acc539dd95f8749")
