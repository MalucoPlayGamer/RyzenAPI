-- Lua provided by RyzenAPI
-- Game: Blessed Burden

-- MAIN APPLICATION
addappid(2379230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379231, 1, "f32c14f9af362cac409a1040340e229a78a9bbf514e61347ac859c937f5545a5")

