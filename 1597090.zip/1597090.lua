-- Lua provided by RyzenAPI
-- Game: 1597090

-- MAIN APPLICATION
addappid(1597090)
-- Game: addappid(1597090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597091, 1, "494dcac459dad589835c3ae7870bd90649a415831cd22b7c2025e596b4c25ab3")
