-- Lua provided by RyzenAPI
-- Game: Game: Rogue Fable IV

-- MAIN APPLICATION
addappid(2720010)
-- Game: addappid(2720010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720011, 1, "9234f5e3d1f13b518710676fbc03654b164ea4891abd11dee8bcd2b40dbec2ac")
