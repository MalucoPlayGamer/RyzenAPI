-- Lua provided by RyzenAPI
-- Game: Naughty Doughy

-- MAIN APPLICATION
addappid(3535000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3535001, 1, "a91301be373e781c7959fee55013385498f71d08f9d259bd7c759d1d320dcf49")

