-- Lua provided by SkyAPI 
-- Game: AppID 282350
addappid(282350)
addappid(282351, 1, "51165e44f2e4406d9d66f29d832300025d6c817d9232d70355344170ef133ceb")
