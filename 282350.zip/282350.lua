-- Lua provided by RyzenAPI
-- Game: NBA 2K15

-- MAIN APPLICATION
addappid(282350)
addappid(323360)
addappid(386730)
addappid(400480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(282351, 1, "51165e44f2e4406d9d66f29d832300025d6c817d9232d70355344170ef133ceb")
