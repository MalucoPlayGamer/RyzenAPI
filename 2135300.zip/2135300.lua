-- Lua provided by RyzenAPI
-- Game: AppID 2135300

-- MAIN APPLICATION
addappid(2135300)
-- Game: addappid(2135300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135301, 1, "9b5fe45be9fc0d63c64d54f11c02345e140a0a7425b1f266fcf472d892448685")
