-- Lua provided by RyzenAPI
-- Game: Double Cubes

-- MAIN APPLICATION
addappid(391300)

-- MAIN APP DEPOTS / PACKAGES
addappid(391301, 1, "c0902b777a4a0a56e0f2e35f2de7b15505ca19271d194257c6cc8904ee288d30")
