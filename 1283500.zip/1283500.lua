-- Lua provided by RyzenAPI
-- Game: Euphoria: Supreme Mechanics

-- MAIN APPLICATION
addappid(1283500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283501, 1, "78c860fcc920b2ec4ab7bdb7178c0ae19cd2e9211d2b951aaeb71459308baafd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
