-- Lua provided by RyzenAPI
-- Game: Euphoria: Supreme Mechanics

-- MAIN APPLICATION
addappid(1283500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283501, 1, "78c860fcc920b2ec4ab7bdb7178c0ae19cd2e9211d2b951aaeb71459308baafd")

