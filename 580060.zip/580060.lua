-- Lua provided by RyzenAPI
-- Game: addappid(580060)

-- MAIN APPLICATION
addappid(580060)

-- MAIN APP DEPOTS / PACKAGES
addappid(580061, 1, "ebeba0a7d6d6d07da2db8fab3ba48705225cea6ff63e54700ffc6592e60aba8f")
