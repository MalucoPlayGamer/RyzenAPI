-- Lua provided by RyzenAPI
-- Game: Game: AppID 1140030

-- MAIN APPLICATION
addappid(1140030)
-- Game: addappid(1140030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140031, 1, "c24cd09983d66d4733e663497b5fb20ec08f4ce219043d2071fad3dbd40395f8")
