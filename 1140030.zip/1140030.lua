-- Lua provided by SkyAPI 
-- Game: AppID 1140030
addappid(1140030)
addappid(1140031, 1, "c24cd09983d66d4733e663497b5fb20ec08f4ce219043d2071fad3dbd40395f8")
