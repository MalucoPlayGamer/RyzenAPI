-- Lua provided by RyzenAPI
-- Game: AppID 1140030

-- MAIN APPLICATION
addappid(1140030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1140031, 1, "c24cd09983d66d4733e663497b5fb20ec08f4ce219043d2071fad3dbd40395f8")

