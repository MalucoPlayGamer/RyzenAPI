-- Lua provided by RyzenAPI 
-- Game: Professional Farmer 2017
addappid(433670)
addappid(433671, 1, "08a0c152077778f71ede7e98bd88489f8bdb50780d1cf11d0b5099d424d0fede")
addappid(576930, 0, "2b0037f30f2cc59bbc889219e6cbdae9c5ee163517b85e788e973d4975cdf844")
