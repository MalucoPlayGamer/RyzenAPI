-- Lua provided by RyzenAPI
-- Game: CHORDIOID: First Breath Demo

-- MAIN APPLICATION
addappid(2924780)
-- Game: addappid(2924780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2924781, 1, "18203323f623a61743c13e67b8ba53067807970143a09610a4374ffcd128e6d9")
