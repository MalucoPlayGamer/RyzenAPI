-- Lua provided by RyzenAPI
-- Game: 2313720

-- MAIN APPLICATION
addappid(2313720)
-- Game: addappid(2313720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313721, 1, "28deea2a3c397cb3cb4bab57efcd08e787e65a139b8c96bb5c725f39ee4088cd")
