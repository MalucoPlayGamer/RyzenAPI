-- Lua provided by RyzenAPI
-- Game: addappid(2242820)

-- MAIN APPLICATION
addappid(2242820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242821, 1, "9cd37d1cd09e88b7cc14413e5cebecbe499cde04f2d87971e181f7c502623b03")
