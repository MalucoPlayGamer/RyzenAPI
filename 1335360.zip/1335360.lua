-- Lua provided by SkyAPI 
-- Game: Chef Chen
addappid(1335360)
addappid(1335361, 1, "a5955b55045ac8b4e73e9063064958f9f95e73c98802850a2a634dec64fb11cb")
