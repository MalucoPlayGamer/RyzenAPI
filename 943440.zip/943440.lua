-- Lua provided by RyzenAPI
-- Game: addappid(943440)

-- MAIN APPLICATION
addappid(943440)

-- MAIN APP DEPOTS / PACKAGES
addappid(943441, 1, "62ba586e94a5c0b1e10e6b11f5ad643381c22e5527ad0f61bf02dbbdcf528b61")
