-- Lua provided by SkyAPI 
-- Game: AppID 943440
addappid(943440)
addappid(943441, 1, "62ba586e94a5c0b1e10e6b11f5ad643381c22e5527ad0f61bf02dbbdcf528b61")
