-- Lua provided by RyzenAPI
-- Game: 2692950

-- MAIN APPLICATION
addappid(2692950)
-- Game: addappid(2692950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692951, 1, "5e7853a68363abcd64b46d610ff86a0e75d221bd1178701204e4c90dbceae034")
