-- Lua provided by RyzenAPI
-- Game: Might & Magic: Clash of Heroes

-- MAIN APPLICATION
addappid(61700)

-- MAIN APP DEPOTS / PACKAGES
addappid(61701, 1, "286f9e94b88562bb9116a4c1bd8c7ddb330ed1d96cd4bde0662247f3635f995a")
addappid(61702, 1, "4c306bd9c79caf5ea1fdee8bb91b8bc6cb7fbd469e3fec5d9d91560ead7adb46")
addappid(61703, 1, "ac3b0620a2686ca4132f1a48d0cb73e68737e8d7a75f88c6995972e640fc761b")
addappid(61704, 1, "02ccbfd63394d6dfd327c2207e201df965ce994eef8beefa6f314e56ce5976ef")
addappid(61705, 1, "d40a40ca793583aa123df4e809248d41e3dfb6e24baaa735f6b21765f22cfd4e")
addappid(61706, 1, "e52eb260cc533ce33ab49d9a40dc635ee02fb07a42895a183cd63f87cc5797cd")
addappid(61707, 1, "17acd4ddb841fc8a5325c8444c163691d4240e308ce1ee7c2b3540ccb5ceded6")
addappid(61708, 1, "4b92ef1dd3994104e7449825ceb0cbf8c175e296c9dc7a408ac5860b1cc095ca")
addappid(61709, 1, "57994a6267ab798b02a8ab516378143a67812d0df729adc0fe8039d79d7b1d5d")
