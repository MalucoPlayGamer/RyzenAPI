-- Lua provided by RyzenAPI
-- Game: Marginal act

-- MAIN APPLICATION
addappid(823330)

-- MAIN APP DEPOTS / PACKAGES
addappid(823331,0,"3bcdbac355738b139c1701bb2be2ef72c5b8b4f593da1eddd87e330fead25256")

