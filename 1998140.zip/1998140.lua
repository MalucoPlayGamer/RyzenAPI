-- Lua provided by RyzenAPI 
-- Game: Bud Farm Idle Tycoon
addappid(1998140)
addappid(1998141, 1, "3e11b3c180e7b9013564e63985ff74890d6907e191eea9b61a8d2ec097ea6f57")
addappid(1998142, 1, "e8833b6dc64bf06c6d584a2adf91f286f7e50d420338a10984f68567abb32de4")
