-- Lua provided by RyzenAPI
-- Game: addappid(2467050)

-- MAIN APPLICATION
addappid(2467050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467051, 1, "4e963135111442130002ae8e0af10042743abc185bc6311538cecb00afac5a6e")
