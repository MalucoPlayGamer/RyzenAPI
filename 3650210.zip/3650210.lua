-- 3650210's Lua and Manifest Created by Hubcap Manifest
-- Thumps & Blows
-- Created: August 27, 2026 at 13:29:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3650210) -- Thumps & Blows
-- MAIN APP DEPOTS
addappid(3650211, 1, "f8f165779d0d51a7a93946c18d3494df9433fe2de724881e66a459f3933678a6") -- Depot 3650211
setManifestid(3650211, "181018488672943908", 382718231)
addappid(3650212, 1, "3dd95bc0f1c1dc812d1175064ce40010be395e21709792f13db636d75fae386d") -- Depot 3650212
setManifestid(3650212, "2217731013957459386", 368050120)