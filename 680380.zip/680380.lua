-- Lua provided by RyzenAPI
-- Game: Night Call

-- MAIN APPLICATION
addappid(680380)

-- MAIN APP DEPOTS / PACKAGES
addappid(680383,0,"0905c719a2f5adda8a8f1d6c2148335084ef48f33a05270d0d44424cf6c47256")
addappid(680384,0,"675ab1efacfff3ff3461259f4517514e76978638bf226aea9031d5abf5bf59d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
