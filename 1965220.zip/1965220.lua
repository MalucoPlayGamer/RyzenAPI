-- Lua provided by RyzenAPI
-- Game: Maid Knight Alicia - DLC

-- MAIN APPLICATION
addappid(1965220)
-- Game: addappid(1965220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965221, 1, "cee0c9356ae0b11dc119a265fe5613bddfae5f36661a4adfd8d3e0caf1b4989e")
