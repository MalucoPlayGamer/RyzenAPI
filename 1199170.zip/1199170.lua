-- Lua provided by RyzenAPI
-- Game: 1199170

-- MAIN APPLICATION
addappid(1199170)
-- Game: addappid(1199170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199171, 1, "59ec8ad6b6c681eb30bbf290787da024487befdf81c17fffce602037caf68946")
