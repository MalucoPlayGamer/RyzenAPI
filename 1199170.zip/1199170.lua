-- Lua provided by SkyAPI 
-- Game: Gravity Escape From The Maze
addappid(1199170)
addappid(1199171, 1, "59ec8ad6b6c681eb30bbf290787da024487befdf81c17fffce602037caf68946")
