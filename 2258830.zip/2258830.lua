-- Lua provided by RyzenAPI
-- Game: NOTHING TO LOSE

-- MAIN APPLICATION
addappid(2258830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2258831, 1, "ae96b482ab43ba0f6f3edc58659e5ebdd989fd093bd1875bfeb7b083d6603ebf")

