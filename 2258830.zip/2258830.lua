-- Lua provided by SkyAPI 
-- Game: NOTHING TO LOSE
addappid(2258830)
addappid(2258831, 1, "ae96b482ab43ba0f6f3edc58659e5ebdd989fd093bd1875bfeb7b083d6603ebf")
