-- Lua provided by RyzenAPI
-- Game: NOTHING TO LOSE

-- MAIN APPLICATION
addappid(2258830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258831, 1, "ae96b482ab43ba0f6f3edc58659e5ebdd989fd093bd1875bfeb7b083d6603ebf")

