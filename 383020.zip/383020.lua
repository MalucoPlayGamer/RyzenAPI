-- Lua provided by RyzenAPI
-- Game: 383020

-- MAIN APPLICATION
addappid(383020)
-- Game: addappid(383020)

-- MAIN APP DEPOTS / PACKAGES
addappid(383021, 1, "e63e92ea7a826eb39c0cad1d2452ec2bfb70457cd9e961aa439ef2702876b7b5")
