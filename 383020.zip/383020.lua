-- Lua provided by RyzenAPI
-- Game: AppID 383020

-- MAIN APPLICATION
addappid(383020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(383021, 1, "e63e92ea7a826eb39c0cad1d2452ec2bfb70457cd9e961aa439ef2702876b7b5")

