-- Lua provided by RyzenAPI
-- Game: 933554

-- MAIN APPLICATION
addappid(933554)

-- MAIN APP DEPOTS / PACKAGES
addappid(933554,0,"cccff9f75c71235e1dc9938dd377dc003190ceaa9bf5ad0ed778caf56d2c3f6e")
