-- Lua provided by RyzenAPI
-- Game: Castle Daybreak

-- MAIN APPLICATION
addappid(1714100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714101, 1, "92b67f6ba26518edd72bedd073adc5d22cf9ff1286ee2f5000807554295df3de")
