-- Lua provided by RyzenAPI
-- Game: Game: AppID 1620430

-- MAIN APPLICATION
addappid(1620430)
-- Game: addappid(1620430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620431, 1, "3d41f858f64fd43f89725cb47528a0b2d81673b163d3b8c63f3836c02d6e3151")
