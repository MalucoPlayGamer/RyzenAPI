-- Lua provided by RyzenAPI
-- Game: Larkin building by Frank Lloyd Wright

-- MAIN APPLICATION
addappid(814700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(814701, 1, "135a23b096c1108f7c31501e14a9cd4f93ebfb3fee24bdeb9b93defee9a6564f")
