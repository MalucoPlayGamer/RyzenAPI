-- Lua provided by RyzenAPI
-- Game: 814700

-- MAIN APPLICATION
addappid(814700)
-- Game: addappid(814700)

-- MAIN APP DEPOTS / PACKAGES
addappid(814701, 1, "135a23b096c1108f7c31501e14a9cd4f93ebfb3fee24bdeb9b93defee9a6564f")
