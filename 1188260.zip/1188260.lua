-- Lua provided by RyzenAPI
-- Game: 1188260

-- MAIN APPLICATION
addappid(1188260)
-- Game: addappid(1188260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1188261, 1, "76fff44fc2d3c1315d10c913e229b8816c1e18a3cb63974c7b4c3b05f7f6d88d")
addappid(1188262, 1, "1deef89ba3e679be9b09386d1f79d46d4cb8a3dfcb1b1a04d735d42e489dadbe")
addappid(1188263, 1, "1c9c85c0bfc7bed0f0c470c4947a725d7017f137f0db29215b5e4eb64394c431")
