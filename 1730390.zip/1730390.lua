-- Lua provided by RyzenAPI
-- Game: Your Show Has Been Cancelled

-- MAIN APPLICATION
addappid(1730390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730392,0,"4d101383119a31eafa132af5b5f9c05a3517665a1844347b583ef10549a4c573")

