-- Lua provided by RyzenAPI
-- Game: Game: Crisol: Theater of Idols

-- MAIN APPLICATION
addappid(1790930)
-- Game: addappid(1790930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1790931, 1, "1004ecdf80e18a409de92e25b9422c289ffae11c70dc4480fcb2ac76f4f77f39")
