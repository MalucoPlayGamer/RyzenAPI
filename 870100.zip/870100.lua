-- Lua provided by RyzenAPI 
-- Game: AppID 870100
addappid(870100)
addappid(870101, 1, "1b4c8ff354771e65f5f2a40b79db3a6981fb276b3bca0a1b23c371f6bae0bb0b")
