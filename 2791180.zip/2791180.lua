-- Lua provided by RyzenAPI
-- Game: Seraphim Slum

-- MAIN APPLICATION
addappid(2791180)
addappid(3018350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791183,0,"7a9e6612587c8d44aebe5c9b13597992b6aba9f03c8efa5729564345f13d55d3")

