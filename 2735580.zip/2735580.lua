-- Lua provided by RyzenAPI
-- Game: Netherworld Covenant

-- MAIN APPLICATION
addappid(2735580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735583,0,"c55904da7d44d2a56d195136d0a47a4c722bd166cd278e69055417c1972b39be")
