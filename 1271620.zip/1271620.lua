-- Lua provided by RyzenAPI
-- Game: Game: Umihara Kawase BaZooKa!

-- MAIN APPLICATION
addappid(1271620)
-- Game: addappid(1271620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1271621, 1, "8200230bc940e3e31e427e1fb45bed501dd9e308d7fe6ad084ce738291048a40")
