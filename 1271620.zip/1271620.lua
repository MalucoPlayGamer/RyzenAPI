-- Lua provided by RyzenAPI 
-- Game: Umihara Kawase BaZooKa!
addappid(1271620)
addappid(1271621, 1, "8200230bc940e3e31e427e1fb45bed501dd9e308d7fe6ad084ce738291048a40")
