-- Lua provided by RyzenAPI
-- Game: Discharge

-- MAIN APPLICATION
addappid(975660)
-- Game: addappid(975660)

-- MAIN APP DEPOTS / PACKAGES
addappid(975661, 1, "6fae5234779aedc339a6930902cf4be1da26011207a821863a1637d34a6140bf")
