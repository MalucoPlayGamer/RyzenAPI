-- Lua provided by RyzenAPI 
-- Game: AppID 1529710
addappid(1529710)
addappid(1529711, 1, "ff8f351b1b2e8ba4b8efb7504550fb73537958abe8608c1f5a6c5a94e18ac095")
