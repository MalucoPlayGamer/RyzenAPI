-- Lua provided by RyzenAPI 
-- Game: AppID 2057710
addappid(2057710)
addappid(2057711, 1, "377709e768c1e9aa34423083d4e51dd664aed8cfaf0083bdead93645feb172c7")
addappid(2088310, 0, "bfda9d8416edef65195297932101315d6619e1c9a642da7c73799f0cd2381566")
