-- Lua provided by RyzenAPI
-- Game: Intelligence: Anime girls

-- MAIN APPLICATION
addappid(862880)
addappid(869330)

-- MAIN APP DEPOTS / PACKAGES
addappid(862881,0,"a17993203e6521e2e6e560ca36c77589c22907013a85d9cbf5ac3e3fa4ce2724")

