-- Lua provided by RyzenAPI
-- Game: addappid(862880)

-- MAIN APPLICATION
addappid(862880)

-- MAIN APP DEPOTS / PACKAGES
addappid(862881, 1, "a17993203e6521e2e6e560ca36c77589c22907013a85d9cbf5ac3e3fa4ce2724")
