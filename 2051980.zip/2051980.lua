-- Lua provided by RyzenAPI
-- Game: Aloft Demo

-- MAIN APPLICATION
addappid(2051980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051981, 1, "9e7b6435d40bb3d858a79db0e0223a7dab01d8939d768a0cea562a74733e8237")
