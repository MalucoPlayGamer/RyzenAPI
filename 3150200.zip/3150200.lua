-- Lua provided by RyzenAPI
-- Game: 3150200

-- MAIN APPLICATION
addappid(3150200)
-- Game: addappid(3150200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150201, 1, "25eb6bc97cb0c0e73d9881825bf8251ed01438a3ea41735857febeec09d3d8ca")
