-- Lua provided by RyzenAPI
-- Game: Chess Survivors

-- MAIN APPLICATION
addappid(2065000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2065003,0,"32e2d8dc11ac072e75d48844eb36806110908f4a9d8c9ed1077fd15d436cd535")

