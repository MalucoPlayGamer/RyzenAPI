-- Lua provided by RyzenAPI
-- Game: Deadly Flare

-- MAIN APPLICATION
addappid(844390)

-- MAIN APP DEPOTS / PACKAGES
addappid(844391, 1, "f645ac785e60fccb1b6ea7a309096c9b95b7c330b362ea39480a72c933e8a386")
