-- Lua provided by RyzenAPI
-- Game: Ghostlords

-- MAIN APPLICATION
addappid(522340)
-- Game: addappid(522340)

-- MAIN APP DEPOTS / PACKAGES
addappid(522341, 1, "2c7ba588f139e6ae6a2b319fa38080cc13854313bc7343ce02c76a999c12758a")
addappid(522342, 1, "cbd2600b0b6f44d2fd3ae08403aa9f640869e528584e1d79008f81714eba5e11")
addappid(522343, 1, "8a713cdb27a96079b40e05cac3c8958d1b19deed698a813c634f654e6dc27d99")
