-- Lua provided by RyzenAPI
-- Game: Puppet Master: The Game

-- MAIN APPLICATION
addappid(1757610)
-- Game: addappid(1757610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757611, 1, "eda6381b0117627fa62e08e01daab29d5da3aed794b4e07310b575de542b976d")
