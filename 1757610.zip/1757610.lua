-- Lua provided by RyzenAPI
-- Game: Puppet Master: The Game

-- MAIN APPLICATION
addappid(1757610)
addappid(2324640)
addappid(2324641)
addappid(2324642)
addappid(2324643)
addappid(2324644)
addappid(2324645)
addappid(2324646)
addappid(2752410)
addappid(3266570)
addappid(3927470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757611, 1, "eda6381b0117627fa62e08e01daab29d5da3aed794b4e07310b575de542b976d")

