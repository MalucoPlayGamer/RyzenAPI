-- Lua provided by RyzenAPI
-- Game: Vanity

-- MAIN APPLICATION
addappid(2600670)
addappid(2659130)
addappid(2663900)
addappid(2718630)
addappid(2718640)
addappid(2999140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600671, 1, "30574fcac232fa312e1a55508a7a9f9d9628d8fadd37a077ca246cadd981a392")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
