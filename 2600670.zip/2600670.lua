-- Lua provided by RyzenAPI
-- Game: Game: Vanity

-- MAIN APPLICATION
addappid(2600670)
addappid(2659130)
addappid(2663900)
addappid(2718630)
addappid(2718640)
addappid(2999140)
-- Game: addappid(2600670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600671, 1, "30574fcac232fa312e1a55508a7a9f9d9628d8fadd37a077ca246cadd981a392")
