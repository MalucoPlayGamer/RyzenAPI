-- Lua provided by RyzenAPI
-- Game: Crazy Veggies

-- MAIN APPLICATION
addappid(621050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(621051, 1, "614c6026f9f8474f110648c2775a78f8479d661fdc81ef852f49949da4fd7ad7")
addappid(621052, 1, "64f91be41e8b2f60fec5313509b7db8aa80f92b18a9b9fdc24de0889077d833b")
addappid(621053, 1, "d6a363787feae87703e7881ec8736289679112a19cd60bbf98e1171e0be85f44")
