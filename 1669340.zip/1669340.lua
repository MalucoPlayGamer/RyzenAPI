-- Lua provided by RyzenAPI
-- Game: 尘埃见闻录

-- MAIN APPLICATION
addappid(1669340)
-- Game: addappid(1669340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669341, 1, "a76eebb60243c94b949360d83c8f229008d4f5e660fae6780ff714780e7cd586")
