-- Lua provided by RyzenAPI
-- Game: Abyssus

-- MAIN APPLICATION
addappid(1721110)
addappid(3853680)
addappid(3853790)
addappid(3853800)
addappid(4168330)
addappid(4508360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1721111, 1, "fd31fe45269b1676240f9cabc945952eddc0eca492eed6d02938264d045af58b")

