-- Lua provided by RyzenAPI
-- Game: addappid(2413780)

-- MAIN APPLICATION
addappid(2413780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413781, 1, "22748b13caa9c148f9ef5d0110ff31d3e1e12ee8add72753205ee521a87f028c")
