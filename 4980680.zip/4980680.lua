-- 4980680's Lua and Manifest Created by Hubcap Manifest
-- BLUE SHIP
-- Created: August 08, 2026 at 22:55:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4980680) -- BLUE SHIP
-- MAIN APP DEPOTS
addappid(4980681, 1, "292b79ef5ee8b397f752c756b43ff360c8a7ec1e796846d852768d85e71dd889") -- Depot 4980681
setManifestid(4980681, "5329738523168834494", 169721372)