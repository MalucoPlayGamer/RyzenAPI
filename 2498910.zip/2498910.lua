-- Lua provided by RyzenAPI
-- Game: 2498910

-- MAIN APPLICATION
addappid(2498910)
-- Game: addappid(2498910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498911, 1, "d40b33beed184c007c5fe768bf0e9a69cf592c14ad48dc485a1ed34c988782d6")
addappid(2498912, 1, "1b9553d87cf0d8de371047815fbba32cdea5f2ff1468df299e727c7c87c2adb9")
