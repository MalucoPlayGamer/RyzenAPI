-- Lua provided by RyzenAPI
-- Game: BloodSpire

-- MAIN APPLICATION
addappid(4918790) -- BloodSpire

-- MAIN APP DEPOTS / PACKAGES
addappid(4918791, 1, "b09f5f84e8cb1e6a11b43ecaf1fa8d713be741984c198ec9fafec6368b66b8f3") -- Depot 4918791

