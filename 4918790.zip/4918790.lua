-- 4918790's Lua and Manifest Created by Hubcap Manifest
-- BloodSpire
-- Created: August 07, 2026 at 07:24:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4918790) -- BloodSpire
-- MAIN APP DEPOTS
addappid(4918791, 1, "b09f5f84e8cb1e6a11b43ecaf1fa8d713be741984c198ec9fafec6368b66b8f3") -- Depot 4918791
setManifestid(4918791, "8203931203050262744", 53417670)