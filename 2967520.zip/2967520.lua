-- Lua provided by RyzenAPI 
-- Game: Corner Abyss
addappid(2967520)
addappid(2967521, 1, "a615f8558f4cdd551cc27665762591ebc9ce9452add9067137377a49ad51e1ca")
