-- Lua provided by RyzenAPI
-- Game: 2967520

-- MAIN APPLICATION
addappid(2967520)
-- Game: addappid(2967520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967521, 1, "a615f8558f4cdd551cc27665762591ebc9ce9452add9067137377a49ad51e1ca")
