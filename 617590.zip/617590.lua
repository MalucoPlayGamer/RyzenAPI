-- Lua provided by RyzenAPI 
-- Game: Affliction
addappid(617590)
addappid(617591, 1, "2c9e5b13395e883d70cee87298f95bf68096c3c5b4deb4a21e2908edf945f8d4")
