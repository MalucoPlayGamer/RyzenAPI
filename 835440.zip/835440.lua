-- Lua provided by RyzenAPI
-- Game: Naturallandscape - Grand Canyon (自然景观系列-美国大峡谷)

-- MAIN APPLICATION
addappid(835440)

-- MAIN APP DEPOTS / PACKAGES
addappid(835441, 1, "faa8258c60ff2c60aaefb061c6ee5064abdf279f54726a0d04808b7fd9f9f8d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
