-- Lua provided by SkyAPI 
-- Game: Tank On Tank Digital  - West Front
addappid(613860)
addappid(613861, 1, "529797d562ec8742fdc32e66ee510d41e3a31ac51a05f270f518a74138c97315")
addappid(613870)
