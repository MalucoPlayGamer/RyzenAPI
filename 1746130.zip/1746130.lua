-- Lua provided by RyzenAPI
-- Game: Onmyoji in the Otherworld: Sayaka's Story

-- MAIN APPLICATION
addappid(1746130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746133,0,"df8793540b2978c2e09814c0c62dd173101735311821f84f7eac56f9ee3f08d8")
