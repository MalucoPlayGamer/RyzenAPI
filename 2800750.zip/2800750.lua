-- Lua provided by RyzenAPI
-- Game: Game: Cursed Crew Demo

-- MAIN APPLICATION
addappid(2800750)
-- Game: addappid(2800750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800751, 1, "3fd7b0504332d6ea5e16fdff90513872005f1ea3f02e4945af2c126d6dc6f37f")
