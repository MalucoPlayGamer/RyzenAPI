-- Lua provided by SkyAPI 
-- Game: Cannon Royale Demo
addappid(2564980)
addappid(2564981, 1, "6c7798c858a977e1008178367239995421609fabef004f6456a33b2d8ca4fc6a")
