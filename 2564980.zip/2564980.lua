-- Lua provided by RyzenAPI
-- Game: Cannon Royale Demo

-- MAIN APPLICATION
addappid(2564980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564981, 1, "6c7798c858a977e1008178367239995421609fabef004f6456a33b2d8ca4fc6a")

