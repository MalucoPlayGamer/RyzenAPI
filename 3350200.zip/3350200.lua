-- Lua provided by RyzenAPI
-- Game: Revenge on gold diggers

-- MAIN APPLICATION
addappid(3350200)
addappid(4267430)
-- Game: addappid(3350200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3350201, 1, "974375ed45d0dfd5d3224cfbd5397125e752a9a2d4c309473f9b613abdefb3f8")
addappid(3350202, 1, "80afb11fa9e728e5367517c4c4987b73fb3ea468f97b3ffaaff8801399c2cbbd")
