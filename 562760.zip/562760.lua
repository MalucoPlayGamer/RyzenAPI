-- Lua provided by RyzenAPI
-- Game: AppID 562760

-- MAIN APPLICATION
addappid(562760)
-- Game: addappid(562760)

-- MAIN APP DEPOTS / PACKAGES
addappid(562761, 1, "30c2532cbcde81f39dd14806ddf8261526a326e550331a66861ac01b021e0a0e")
