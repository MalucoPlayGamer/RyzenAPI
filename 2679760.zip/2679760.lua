-- Lua provided by RyzenAPI
-- Game: The Ampoule

-- MAIN APPLICATION
addappid(2679760)
-- Game: addappid(2679760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679761, 1, "36d465313506bb9bffd2cbcd9ddad680af45a09bdef9b42d97cb57ee6c14db81")
