-- Lua provided by RyzenAPI
-- Game: ShipShaper: Falconeer Chronicles

-- MAIN APP DEPOTS / PACKAGES
addappid(4339280, 1, "bd8a649395d09e719b76c8a299e5d67ab3d1f58f3c133998199d2976bc8e3e2c") -- ShipShaper: Falconeer Chronicles
addappid(4339281, 1, "11da066eec2561b1c9f265b85822d9978a169517cfdfb2d79779d778318d20bc") -- Depot 4339281
