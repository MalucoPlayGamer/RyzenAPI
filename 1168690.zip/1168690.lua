-- Lua provided by RyzenAPI
-- Game: HELLSEED: All Chapters

-- MAIN APPLICATION
addappid(1168690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168691, 1, "ae02ac7d68b3fb1f132d7f17e77d565ce3534d11d122311fb2920290fd100a14")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
