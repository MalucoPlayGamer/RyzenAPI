-- Lua provided by SkyAPI 
-- Game: HELLSEED: All Chapters
addappid(1168690)
addappid(1168691, 1, "ae02ac7d68b3fb1f132d7f17e77d565ce3534d11d122311fb2920290fd100a14")
