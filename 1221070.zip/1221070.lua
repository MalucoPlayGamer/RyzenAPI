-- Lua provided by RyzenAPI
-- Game: Game: Alien street battle

-- MAIN APPLICATION
addappid(1221070)
-- Game: addappid(1221070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221071, 1, "47bb5921ff9c3fbb3ebadbb97801a685b1a0e50c1ac0de70cf0f3a99df1635c5")
