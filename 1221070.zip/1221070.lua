-- Lua provided by RyzenAPI
-- Game: Alien street battle

-- MAIN APPLICATION
addappid(1221070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221071, 1, "47bb5921ff9c3fbb3ebadbb97801a685b1a0e50c1ac0de70cf0f3a99df1635c5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
