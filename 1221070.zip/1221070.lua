-- Lua provided by RyzenAPI 
-- Game: Alien street battle
addappid(1221070)
addappid(1221071, 1, "47bb5921ff9c3fbb3ebadbb97801a685b1a0e50c1ac0de70cf0f3a99df1635c5")
