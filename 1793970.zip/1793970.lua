-- Lua provided by RyzenAPI
-- Game: Village defense

-- MAIN APPLICATION
addappid(1793970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793971, 1, "3b50f5ad273693567706db6a451005b37dd0714342b9e9c776ed43d9247a23e9")
