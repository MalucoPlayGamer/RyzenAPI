-- Lua provided by RyzenAPI 
-- Game: AppID 3257610
addappid(3257610)
addappid(3257611, 1, "7e6f36b3f70ecff70b613f94bd2a82ba7042865bf7d6246a27953e045394d947")
