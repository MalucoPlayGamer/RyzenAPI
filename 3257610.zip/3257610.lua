-- Lua provided by RyzenAPI
-- Game: ToriDori 2 Demo

-- MAIN APPLICATION
addappid(3257610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3257611, 1, "7e6f36b3f70ecff70b613f94bd2a82ba7042865bf7d6246a27953e045394d947")
