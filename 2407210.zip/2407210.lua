-- Lua provided by RyzenAPI
-- Game: Fate/Samurai Remnant - Bonus Equipment: Hallowed Relic Sword Mountings

-- MAIN APPLICATION
addappid(2407210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407210,0,"7ef987ddbc066ec90fc0ce6780ecfe9b3e572d75f23fbd4111188736220c3b9a")

