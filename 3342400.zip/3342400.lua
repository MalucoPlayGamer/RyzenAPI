-- Lua provided by RyzenAPI
-- Game: addappid(3342400)

-- MAIN APPLICATION
addappid(3342400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3342401, 1, "898eae225d9cb9effcaeb6458cddd1ee866cd16369e9b28d0bab8dd3fda6b07a")
