-- Lua provided by RyzenAPI
-- Game: 属性与生活

-- MAIN APPLICATION
addappid(822470)

-- MAIN APP DEPOTS / PACKAGES
addappid(822472,0,"88bc2f11bf06f874ca415627b7c7bddaf9e5ad4f1b031c8ec014ab7b8b5d3a4e")

