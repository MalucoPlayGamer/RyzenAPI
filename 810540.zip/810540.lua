-- Lua provided by RyzenAPI
-- Game: Game: AppID 810540

-- MAIN APPLICATION
addappid(810540)
-- Game: addappid(810540)

-- MAIN APP DEPOTS / PACKAGES
addappid(810541, 1, "8f6e94e9b64448a7902e0d1e32563e39cf48d9150a798ce764666943d21d1d13")
