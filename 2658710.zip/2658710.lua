-- Lua provided by SkyAPI 
-- Game: Tinkerlands: A Shipwrecked Adventure
addappid(2658710)
addappid(2658711, 1, "442b02484ee74753315b5dc2200a871df8361af4f2d1cc069d0b29d4aef99a75")
