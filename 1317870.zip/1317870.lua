-- Lua provided by RyzenAPI
-- Game: 1317870

-- MAIN APPLICATION
addappid(1317870)
-- Game: addappid(1317870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132971,0,"955ee1882db11a0b355ed7f82f7a24fcea6ffde1afd24398039058501d6fe154")
