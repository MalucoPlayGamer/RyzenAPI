-- Lua provided by RyzenAPI
-- Game: Game: 100 Dino Cats

-- MAIN APPLICATION
addappid(2803000)
-- Game: addappid(2803000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803001, 1, "46b8228b85caa6f1ea9f3f9405e46ec477e26aca7ec289db4101051e8222588c")
