-- Lua provided by RyzenAPI
-- Game: SOH One Shot Challenge

-- MAIN APPLICATION
addappid(1166630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166631, 1, "ba27cec9ecf0789f1e2fd965c63338d82c5a765e1eafa7294fbfedf41072ae65")

