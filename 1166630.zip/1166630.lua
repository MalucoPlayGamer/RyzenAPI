-- Lua provided by RyzenAPI
-- Game: SOH One Shot Challenge

-- MAIN APPLICATION
addappid(1166630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166631, 1, "ba27cec9ecf0789f1e2fd965c63338d82c5a765e1eafa7294fbfedf41072ae65")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
