-- Lua provided by RyzenAPI
-- Game: 292090

-- MAIN APPLICATION
addappid(292090)
-- Game: addappid(292090)

-- MAIN APP DEPOTS / PACKAGES
addappid(292091, 1, "3de423582544f854acf5efddcb64a6172053aac4aae0fd725a21c7247d8d3aec")
