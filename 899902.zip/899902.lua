-- Lua provided by RyzenAPI
-- Game: 899902

-- MAIN APPLICATION
addappid(899902)
-- Game: addappid(899902)

-- MAIN APP DEPOTS / PACKAGES
addappid(899902,0,"dd91d199d75a65da0eaaf0fdb51b96c373c6d202762a380414b2cf10e629582c")
