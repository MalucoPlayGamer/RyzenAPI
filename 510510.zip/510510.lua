-- Lua provided by RyzenAPI
-- Game: WWE 2K17

-- MAIN APPLICATION
addappid(510510)
addappid(570160)
addappid(570170)
addappid(570180)
addappid(570181)
addappid(570190)
addappid(570200)
addappid(579410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(510511, 1, "d90019ece60b2601281b5b058c540e27af5b92c42861f03bfa3bc8e878a0ea4e")
addappid(570210, 0, "348bbc0086d1dc58de547e30622eb7b90a9a4edfa9fd1cb2344144e83a219246")

