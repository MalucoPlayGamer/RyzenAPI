-- Lua provided by SkyAPI 
-- Game: AppID 1085750
addappid(1085750)
addappid(1085751, 1, "accc6ade0d89c0229c7c9b2d5887fd67bdd4879979fdd516ae9535e3849d8c47")
