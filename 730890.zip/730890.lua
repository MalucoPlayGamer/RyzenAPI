-- Lua provided by RyzenAPI
-- Game: Salvation in Corruption

-- MAIN APPLICATION
addappid(730890)

-- MAIN APP DEPOTS / PACKAGES
addappid(730891,0,"bd49d0152c8a4f97aa99924b62cf3a4560fb54fa7c2ddb73136a91187c4d97b6")

