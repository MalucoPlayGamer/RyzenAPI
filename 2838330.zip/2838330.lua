-- Lua provided by RyzenAPI
-- Game: 2838330

-- MAIN APPLICATION
addappid(2838330)
-- Game: addappid(2838330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838330,0,"28f0331e08241db0ad74fbd9e2f3dd018888ae2f8a23224082b838586ee30df7")
