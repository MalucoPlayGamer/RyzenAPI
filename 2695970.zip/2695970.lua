-- Lua provided by RyzenAPI
-- Game: 2695970

-- MAIN APPLICATION
addappid(2695970)
-- Game: addappid(2695970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695971, 1, "13233f0220d0d644607ff8410ab3f39cc58bd6e7a7f96d38408b02cfe5685e23")
