-- Lua provided by RyzenAPI 
-- Game: AppID 2695970
addappid(2695970)
addappid(2695971, 1, "13233f0220d0d644607ff8410ab3f39cc58bd6e7a7f96d38408b02cfe5685e23")
