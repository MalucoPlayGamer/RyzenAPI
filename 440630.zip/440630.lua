-- Lua provided by RyzenAPI
-- Game: The Brookhaven Experiment

-- MAIN APPLICATION
addappid(440630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(440631, 1, "f715151a8a4f31ad396ec5853e1dea733f5d4b68fbaafa081cf4cac4aed4191f")

