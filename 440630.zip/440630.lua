-- Lua provided by RyzenAPI
-- Game: The Brookhaven Experiment

-- MAIN APPLICATION
addappid(440630)

-- MAIN APP DEPOTS / PACKAGES
addappid(440631, 1, "f715151a8a4f31ad396ec5853e1dea733f5d4b68fbaafa081cf4cac4aed4191f")
