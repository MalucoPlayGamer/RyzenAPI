-- Lua provided by RyzenAPI
-- Game: addappid(2072110)

-- MAIN APPLICATION
addappid(2072110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072111, 1, "d658354068aee0dcfac1b5c0bd40ed9b8434d73ebabcddddedfa5aa209295e59")
