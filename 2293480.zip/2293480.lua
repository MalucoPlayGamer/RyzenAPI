-- Lua provided by RyzenAPI
-- Game: addappid(2293480)

-- MAIN APPLICATION
addappid(2293480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293481, 1, "60f599c12159093c534e9ecc2b53fd6dac230b0553ae2d6e3a7318fc14e3ba3e")
