-- Lua provided by RyzenAPI
-- Game: NaziShootout

-- MAIN APPLICATION
addappid(802850)

-- MAIN APP DEPOTS / PACKAGES
addappid(802851, 1, "cb084e76ed1be614b3892b0694b911a6f2cea7d801d1e1c8589f0ccbcf9ee5ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
