-- Lua provided by RyzenAPI
-- Game: 802850

-- MAIN APPLICATION
addappid(802850)
-- Game: addappid(802850)

-- MAIN APP DEPOTS / PACKAGES
addappid(802851, 1, "cb084e76ed1be614b3892b0694b911a6f2cea7d801d1e1c8589f0ccbcf9ee5ce")
