-- Lua provided by RyzenAPI
-- Game: 1684157

-- MAIN APPLICATION
addappid(1684157)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684157,0,"bd3c6ea9a13d4949afba2a00fabd26d22478d4a09c1230f001be3cc2df7c71d4")
