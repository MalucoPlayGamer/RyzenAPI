-- Lua provided by SkyAPI 
-- Game: Mountain Bicycle Rider Simulator
addappid(2565210)
addappid(2565211, 1, "9c25ab2fb8eb6acf7319e09ce2ef98160ad85b26eca6da6250a75bbca1704218")
