-- Lua provided by RyzenAPI
-- Game: Mountain Bicycle Rider Simulator

-- MAIN APPLICATION
addappid(2565210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565211, 1, "9c25ab2fb8eb6acf7319e09ce2ef98160ad85b26eca6da6250a75bbca1704218")

