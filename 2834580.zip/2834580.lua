-- Lua provided by RyzenAPI
-- Game: Cursed Despair

-- MAIN APPLICATION
addappid(2834580)
-- Game: addappid(2834580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834581, 1, "c172d9c98a76aa68b66f3ecf35893c1028a53d156c24333c710a4b0d0faef2cb")
