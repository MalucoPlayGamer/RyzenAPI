-- Lua provided by RyzenAPI
-- Game: Cursed Despair

-- MAIN APPLICATION
addappid(2834580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834581, 1, "c172d9c98a76aa68b66f3ecf35893c1028a53d156c24333c710a4b0d0faef2cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
