-- Lua provided by RyzenAPI
-- Game: 964938

-- MAIN APPLICATION
addappid(964938)

-- MAIN APP DEPOTS / PACKAGES
addappid(964938,0,"40d1b6fd1d52d7af6be994d9bf3e84847558b2ad47b88b09a63785fff4645bf2")

