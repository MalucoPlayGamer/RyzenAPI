-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Xiahouji (New wife Costume) / 夏侯姫 「新妻風コスチューム」

-- MAIN APPLICATION
addappid(964938)
-- Game: addappid(964938)

-- MAIN APP DEPOTS / PACKAGES
addappid(964938,0,"40d1b6fd1d52d7af6be994d9bf3e84847558b2ad47b88b09a63785fff4645bf2")
