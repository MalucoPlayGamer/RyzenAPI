-- Lua provided by RyzenAPI
-- Game: 495540

-- MAIN APPLICATION
addappid(495540)
-- Game: addappid(495540)

-- MAIN APP DEPOTS / PACKAGES
addappid(495541, 1, "c8d32d2474be95180cfd2145d7ff366dd217489b8e418e77dfdf886e78a0268d")
