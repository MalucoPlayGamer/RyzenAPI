-- Lua provided by RyzenAPI
-- Game: 3155810

-- MAIN APPLICATION
addappid(3155810)
-- Game: addappid(3155810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155811, 1, "68ae12f81673db29b6e5fb12f34b61d99b28f100b8caac46f0d5b2fd62ba627c")
