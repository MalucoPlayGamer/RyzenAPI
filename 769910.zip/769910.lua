-- Lua provided by RyzenAPI
-- Game: Flipped On

-- MAIN APPLICATION
addappid(769910)

-- MAIN APP DEPOTS / PACKAGES
addappid(769912,0,"5e4c705bd86ede2361750b731b82e34f6a74d264ce42dcdff89e8a9a9b3195c4")

