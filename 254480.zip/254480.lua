-- Lua provided by RyzenAPI
-- Game: AppID 254480

-- MAIN APPLICATION
addappid(254480)
-- Game: addappid(254480)

-- MAIN APP DEPOTS / PACKAGES
addappid(254481, 1, "ed1b1644b01ffdf727acac40f8f018151fe5c56e3b7c5b1e333ef365706d4942")
addappid(283260, 0, "62d878261826e0e7d6e9b01d30c6a8c7d4763a1f1b7933320e1afe5380de992b")
