-- Lua provided by RyzenAPI
-- Game: Obscure 2

-- MAIN APPLICATION
addappid(254480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(254481, 1, "ed1b1644b01ffdf727acac40f8f018151fe5c56e3b7c5b1e333ef365706d4942")
addappid(283260, 0, "62d878261826e0e7d6e9b01d30c6a8c7d4763a1f1b7933320e1afe5380de992b")
