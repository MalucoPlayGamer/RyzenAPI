-- Lua provided by RyzenAPI
-- Game: Memories Off Sousou ~Not always true~

-- MAIN APPLICATION
addappid(2604320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604321, 1, "35762e4f71eab48eb04bb2460a09ffb5dfd74946fcae38dfa797429549ce5f89")
addappid(3426820, 0, "bea5fa10a4361d7c6b37c506aeceee91b37921785f1adb969c9e9da7220bdab5")

