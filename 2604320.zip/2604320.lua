-- Lua provided by RyzenAPI
-- Game: Memories Off Sousou ~Not always true~

-- MAIN APPLICATION
addappid(2604320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2604321, 1, "35762e4f71eab48eb04bb2460a09ffb5dfd74946fcae38dfa797429549ce5f89")
addappid(3426820, 0, "bea5fa10a4361d7c6b37c506aeceee91b37921785f1adb969c9e9da7220bdab5")

