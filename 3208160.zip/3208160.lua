-- Lua provided by RyzenAPI
-- Game: Coffee Extra: Ukuzala

-- MAIN APPLICATION
addappid(3208160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3208161, 1, "96a144c366ef2718517b56126253bfab7e8638e0cf207dca6c8e5d66b16e2f64")
