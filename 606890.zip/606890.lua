-- Lua provided by SkyAPI 
-- Game: Masters of Anima
addappid(606890)
addappid(606891, 1, "99229af5fe6fba7344b94cfed9eb91773ba807a3297f38ce8674e3c0f2e1c7e1")
