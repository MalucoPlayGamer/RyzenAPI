-- Lua provided by RyzenAPI
-- Game: Masters of Anima

-- MAIN APPLICATION
addappid(606890)
-- Game: addappid(606890)

-- MAIN APP DEPOTS / PACKAGES
addappid(606891, 1, "99229af5fe6fba7344b94cfed9eb91773ba807a3297f38ce8674e3c0f2e1c7e1")
