-- Lua provided by RyzenAPI
-- Game: Game: Blackwell Unbound

-- MAIN APPLICATION
addappid(80340)
-- Game: addappid(80340)

-- MAIN APP DEPOTS / PACKAGES
addappid(80341, 1, "64f171f47951a667883d1ae0b739e2db4ad25dd666e093e168fa6097cb5be900")
addappid(80342, 1, "2dd6b51fb66cf40bd082dc7a96afadb10ae9e12e3d311bea26d2914dac4fa3dc")
addappid(80343, 1, "818ae4ca72819dac693d131b882cdeefabf4a193df34f9422d00af010e1f377e")
addappid(2022100, 0, "88d83e3020e7ab8a5dd623944f03018760e996734c243e59b4127b5a862c7bdb")
