-- 4901910's Lua and Manifest Created by Hubcap Manifest
-- Moon Miner
-- Created: July 28, 2026 at 04:08:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4901910) -- Moon Miner
-- MAIN APP DEPOTS
addappid(4901911, 1, "b8fd37ced7bba9d6773d007483b7e3769df13906feb295d3302b61c378f07f83") -- Depot 4901911
setManifestid(4901911, "2241773848527590310", 344907033)