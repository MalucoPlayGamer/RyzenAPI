-- Lua provided by RyzenAPI
-- Game: 864260

-- MAIN APPLICATION
addappid(864260)
-- Game: addappid(864260)

-- MAIN APP DEPOTS / PACKAGES
addappid(864261, 1, "9fe1e330ff2846b59955dbdd916adda015c002d45da21f2e082a3844e05062a8")
