-- Lua provided by RyzenAPI
-- Game: Occulto

-- MAIN APPLICATION
addappid(1892630) -- Occulto

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1892631, 1, "248170479b19f4470a87bee2ae5dac3b6f24ab56e81f1dbe67f83b7adca9e92d") -- Depot 1892631
addappid(1892632, 1, "474ee0b5259769a47b753c6458c3966eae7782ff8b7790e1accbfc22af553eb2") -- Depot 1892632

