-- Lua provided by RyzenAPI 
-- Game: Crazy Archery
addappid(1008680)
addappid(1008681, 1, "262d10f736b57896417e6c3ef7955ee21893758b77699fe02fff5f17989b34ff")
