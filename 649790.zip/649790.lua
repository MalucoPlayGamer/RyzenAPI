-- Lua provided by RyzenAPI
-- Game: Harvest Life

-- MAIN APPLICATION
addappid(649790)

-- MAIN APP DEPOTS / PACKAGES
addappid(649791, 1, "4774ac545650e50677b0baa0a1d0da32752c1bd4efb35d22d64a38bd53c8af4f")
