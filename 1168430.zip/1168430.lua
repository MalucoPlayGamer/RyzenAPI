-- Lua provided by RyzenAPI
-- Game: Dairy Princess

-- MAIN APPLICATION
addappid(1168430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1168431, 1, "6d260e25d770373d4ea28049f2e73728c9d5a25742ccc23a4228203d62ca2526")
addappid(1168432, 1, "158be5f607904d1c97046fb884a323dc7d1be24f4b5767a02df15809156c11a3")

