-- Lua provided by RyzenAPI
-- Game: Trash Bomber

-- MAIN APPLICATION
addappid(2067760)
addappid(2326680)
-- Game: addappid(2067760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067761, 1, "793231750358da26ce5b9d025dc1d17556fda74b74e369bbd725008a03437ffb")
