-- Lua provided by RyzenAPI
-- Game: Pizza House Simulator🍕

-- MAIN APPLICATION
addappid(4132330) -- Pizza House Simulator🍕

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4132331, 1, "51035a357a681b45f9b70402c409d25181faea5a48999aaf9eb13536d0a203e9") -- Depot 4132331

