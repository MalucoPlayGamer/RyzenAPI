-- Lua provided by RyzenAPI
-- Game: Car For Sale Simulator 2023

-- MAIN APPLICATION
addappid(2248760)
addappid(2679810)
addappid(3400430)
addappid(3400450)
addappid(3400460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248761, 1, "7e322b4c38775f33754204b8cb08844982412cd9d4b140906cfff0047a9b2843")

