-- Lua provided by RyzenAPI
-- Game: addappid(2385030)

-- MAIN APPLICATION
addappid(2385030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385031, 1, "1f7aaca58b1f9e3484e43d9d75def0753e5dcba0ff5dc260ff3a69574a93c65b")
