-- Lua provided by SkyAPI 
-- Game: Insane Demo
addappid(2385030)
addappid(2385031, 1, "1f7aaca58b1f9e3484e43d9d75def0753e5dcba0ff5dc260ff3a69574a93c65b")
