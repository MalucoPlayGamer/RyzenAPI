-- Lua provided by SkyAPI 
-- Game: AppID 3201880
addappid(3201880)
addappid(3201881, 1, "03f51492241c99a7638aebddcfbc0c87940c9cc9e52a20a4d6dc1ae74387b3b5")
