-- Lua provided by RyzenAPI
-- Game: PEPPERED: an existential platformer

-- MAIN APPLICATION
addappid(1883370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883371, 1, "93e18aed49925c7edf2d81e74ab25313320b3af7c9956d516afd62f5245792cd")

