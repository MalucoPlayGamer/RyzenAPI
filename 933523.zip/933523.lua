-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Others Pack

-- MAIN APPLICATION
addappid(933523)
-- Game: addappid(933523)

-- MAIN APP DEPOTS / PACKAGES
addappid(933523,0,"6d953620066db0ebc611baf2f6ce7757c1c78561f0a3f183093967961269563e")
