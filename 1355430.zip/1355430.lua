-- Lua provided by RyzenAPI 
-- Game: The Outcast Lovers
addappid(1355430)
addappid(1355431, 1, "8b1af9fffc443abc0f7e40d704b76b5354e0b0bb625f94569699a5bbbd549bd8")
addappid(1355432, 1, "d6788aaf7e3749928e7ef51dca17a3c3137a2779ec89ee26bce1e709de302557")
