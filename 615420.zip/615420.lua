-- Lua provided by RyzenAPI
-- Game: San Diego International [KSAN] airport for Tower!3D Pro

-- MAIN APPLICATION
addappid(615420)

-- MAIN APP DEPOTS / PACKAGES
addappid(615420,0,"f81d7e1dfac2b1f4582eff0f475e860016e6089fb0eafa7372490c140a780cab")

