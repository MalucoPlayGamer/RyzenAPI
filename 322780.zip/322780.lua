-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228986)
addappid(322780)

-- MAIN APP DEPOTS / PACKAGES
addappid(322783,0,"80099bf395c027131eb47816d4c8e0790519676e6b4355eeb24f010bfc49ec6f")
addappid(322785,0,"177e855820ed9ff8205fc9aee79fc1c00cc998d0c8b2e6fd73a1e4b99356825e")
addappid(322786,0,"c460ce613dd2eacefb74ac1a90f7c8bbbe087b108d1f937daff8dc94028c0bcb")
addappid(322787,0,"aa540b74048e2719ce7c555711017b371775eb9f34160f70a9ee903f833720fd")

