-- Lua provided by RyzenAPI
-- Game: Game: Hotel 188

-- MAIN APPLICATION
addappid(3322980)
-- Game: addappid(3322980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3322981, 1, "de61081b3ed11030a94714acdb03de3dfd835ff2d88022249d15cf47e16e1c61")
