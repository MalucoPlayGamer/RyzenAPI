-- Lua provided by SkyAPI 
-- Game: Hotel 188
addappid(3322980)
addappid(3322981, 1, "de61081b3ed11030a94714acdb03de3dfd835ff2d88022249d15cf47e16e1c61")
