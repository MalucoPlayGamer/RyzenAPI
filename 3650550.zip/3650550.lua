-- Lua provided by RyzenAPI
-- Game: PhaRaBis

-- MAIN APPLICATION
addappid(3650550)
-- Game: addappid(3650550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3650551, 1, "6fa4db918f92c2bc80bec590a1a7c1e9f871f40a7a13950f67a6d486a9bd193d")
