-- Lua provided by RyzenAPI 
-- Game: Pyrene Demo
addappid(2777050)
addappid(2777051, 1, "9c3da071c06fa79d50d7ec2fcc54bee5f1a93d4fa4e979a48da96296275a98c3")
