-- Lua provided by RyzenAPI
-- Game: Game: Pyrene Demo

-- MAIN APPLICATION
addappid(2777050)
-- Game: addappid(2777050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777051, 1, "9c3da071c06fa79d50d7ec2fcc54bee5f1a93d4fa4e979a48da96296275a98c3")
