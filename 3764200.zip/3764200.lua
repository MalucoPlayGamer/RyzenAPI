-- Lua provided by SkyAPI 
-- Game: Resident Evil Requiem
addappid(3764200)
addappid(3764201, 1, "bdf443ffde6449192b9863c0fa5e3cda31fdaa5e4d33e5bcded62dc2085b7cb8")
addappid(3764203, 1, "b2e820287e6e3f32d1ccb3f2f8c95ec3783e8c0a75abab5d311a0a648626fd92")
addappid(3990800, 0, "f5bf116706491176c9eee46a96fe1faa70b3f771d75ccb34f0c8962097a907e5")
addappid(3990820, 0, "9ae4713cb4114effdd34d1cd54dbda8a560f27a05aef06fbaa0370748f69d15c")
