-- Lua provided by RyzenAPI
-- Game: BlockDude

-- MAIN APPLICATION
addappid(669490)

-- MAIN APP DEPOTS / PACKAGES
addappid(669491,0,"3092acc5d43b1b516f9fe5a12359056451beb532ae28563d3aadd897ace13bd2")

