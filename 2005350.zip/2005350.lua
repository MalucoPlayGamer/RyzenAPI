-- Lua provided by RyzenAPI
-- Game: Elohim Eternal - Prologue

-- MAIN APPLICATION
addappid(2005350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005351, 1, "34331a89fb133649256aecb42e4ed6ae59f092594a0011f81c96844c2bda83e7")

