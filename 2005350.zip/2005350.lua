-- Lua provided by SkyAPI 
-- Game: Elohim Eternal - Prologue
addappid(2005350)
addappid(2005351, 1, "34331a89fb133649256aecb42e4ed6ae59f092594a0011f81c96844c2bda83e7")
