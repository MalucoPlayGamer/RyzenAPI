-- Lua provided by RyzenAPI
-- Game: addappid(1437760)

-- MAIN APPLICATION
addappid(1437760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437761, 1, "173a0f2cdea45cabbbb1228e99635022b7c099bbb6d5106ff41aebbd9b8bd586")
