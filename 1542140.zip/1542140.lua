-- Lua provided by RyzenAPI
-- Game: 1542140

-- MAIN APPLICATION
addappid(1542140)
-- Game: addappid(1542140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542141, 1, "8e84b60fb3ee1a64e5a93e49e50cfc8664e659cbce9f6bd5c878863f16692f43")
