-- Lua provided by RyzenAPI
-- Game: AppID 1289960

-- MAIN APPLICATION
addappid(1289960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289961, 1, "d5916d46c29f34649d74ac07f2ce74bc0ced3b45f20571dd3aa34e5f1b5d4d4b")

