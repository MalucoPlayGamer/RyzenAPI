-- Lua provided by RyzenAPI
-- Game: addappid(1457740)

-- MAIN APPLICATION
addappid(1457740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457741, 1, "20e5715de252a6d47ab17fc6a189fe54f7c1fa42b3e6e5fd7bec2b1ad77cdc88")
