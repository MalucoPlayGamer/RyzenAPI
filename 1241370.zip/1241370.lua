-- Lua provided by SkyAPI 
-- Game: FierceWind Decay
addappid(1241370)
addappid(1241371, 1, "5fa02324282e6de484969568b168ba9b3178195eb71a3689d6efb02d1e9fd18f")
