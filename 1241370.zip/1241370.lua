-- Lua provided by RyzenAPI
-- Game: FierceWind Decay

-- MAIN APPLICATION
addappid(1241370)
-- Game: addappid(1241370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241371, 1, "5fa02324282e6de484969568b168ba9b3178195eb71a3689d6efb02d1e9fd18f")
