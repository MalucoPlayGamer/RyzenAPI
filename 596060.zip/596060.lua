-- Lua provided by RyzenAPI
-- Game: AppID 596060

-- MAIN APPLICATION
addappid(596060)
-- Game: addappid(596060)

-- MAIN APP DEPOTS / PACKAGES
addappid(596061, 1, "30e59d1eee3ba128a30b21589bfaa3cebdddb0f9fe4ae2eb6daf8d058b86bea6")
addappid(596062, 1, "2dfee3a44e7e0e0b571400df42b6a91b094b06ebb32ac00642252b611e3048fc")
addappid(596064, 1, "2f08e47673e9c5425905be499032f5daddc17e01ab1a8048bc6558aaece41479")
addappid(597623, 0, "84bdb5e2272b83e399fee033a12b2d5c1d7c2406009bb0cf605dae1cb69c6e31")
