-- Lua provided by RyzenAPI
-- Game: 3126830

-- MAIN APPLICATION
addappid(3126830)
-- Game: addappid(3126830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126830,0,"2fbc72271a2d3dd17d70b1d956e5e947e84eda431bc4b8cdf67768636b414880")
