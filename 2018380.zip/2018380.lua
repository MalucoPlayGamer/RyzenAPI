-- Lua provided by RyzenAPI
-- Game: Neon Invaders

-- MAIN APPLICATION
addappid(2018380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018381, 1, "946be8ffb70cc1ba9977f9b3de5d94308e4e9f30d9ec2825cc8b7a58e33c20f8")

