-- Lua provided by RyzenAPI
-- Game: Alvora Tactics

-- MAIN APPLICATION
addappid(643900)

-- MAIN APP DEPOTS / PACKAGES
addappid(643901,0,"b83c625e3c389f46bcc129af1c92950cc50833b92a3ede02dced2c117f66205b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
