-- Lua provided by RyzenAPI
-- Game: Alvora Tactics

-- MAIN APPLICATION
addappid(643900)

-- MAIN APP DEPOTS / PACKAGES
addappid(643901,0,"b83c625e3c389f46bcc129af1c92950cc50833b92a3ede02dced2c117f66205b")

