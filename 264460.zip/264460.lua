-- Lua provided by RyzenAPI 
-- Game: AppID 264460
addappid(264460)
addappid(264461, 1, "011194b4221370721196256168c93d97d021bbe9ba49636a6372296b8a675353")
