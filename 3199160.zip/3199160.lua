-- Lua provided by RyzenAPI
-- Game: 3199160

-- MAIN APPLICATION
addappid(3199160)
-- Game: addappid(3199160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3199161, 1, "cb200c9ba4554aab90f1ff79ca6c09cb55671625aa4b8ec86ae39ebd5f73e11a")
