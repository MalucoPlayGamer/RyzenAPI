-- Lua provided by RyzenAPI
-- Game: Canyon of Outlaws

-- MAIN APPLICATION
addappid(3688480)
-- Game: addappid(3688480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3688481, 1, "a8cc226bf952564d66ff33fa9facafd762e8e649abe71a1f0931627782bc582f")
