-- Lua provided by RyzenAPI
-- Game: Olympics VR

-- MAIN APPLICATION
addappid(737070)

-- MAIN APP DEPOTS / PACKAGES
addappid(737074,0,"0c576049f2f6665eca547c533b2498c17029b028b83ee2b6ba86b745e7d6b724")

