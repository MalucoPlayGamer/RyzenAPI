-- Lua provided by RyzenAPI
-- Game: 515470

-- MAIN APPLICATION
addappid(515470)
-- Game: addappid(515470)

-- MAIN APP DEPOTS / PACKAGES
addappid(515471, 1, "c5f44eceb99e963b0dd918ca1a7eb124f89b0f55bb1984107a90f0a52cd4f52d")
