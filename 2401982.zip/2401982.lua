-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Wooden Platform Pack

-- MAIN APPLICATION
addappid(2401982)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401982,0,"d177fa888f8727da0014b9175396b9fd55fd81582e0459e66cedf2e3ea390f80")
