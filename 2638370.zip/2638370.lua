-- Lua provided by RyzenAPI
-- Game: Five Nights at Freddy's: Into the Pit

-- MAIN APPLICATION
addappid(2638370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638371, 1, "8852cf8d7bc2edf25ef5fa623e3a6811b710f8c4e6ed3d59de3db7f7a9776210")

