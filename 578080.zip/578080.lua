-- Lua provided by RyzenAPI
-- Game: PUBG: BATTLEGROUNDS

-- MAIN APPLICATION
addappid(578080)
addappid(888770)
addappid(990650)
addappid(1046180)
addappid(1113910)
addappid(1145250)
addappid(1222520)
addappid(1273370)
addappid(1349770)
addappid(1414050)
addappid(1477540)
addappid(1737770)
addappid(1776090)
addappid(3639460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(578081, 1, "74eea6f9f5b0c0deea249bea435370fe734f552a55e1aca5b09ff4f3990ad53e")
addappid(578082, 1, "6cbd9e8da0339346aeaafb966fd6a173ee898929b9ba4349550c5489234dbac7")

