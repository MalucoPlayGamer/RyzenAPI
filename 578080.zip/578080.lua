-- Lua provided by RyzenAPI
-- Game: PUBG: BATTLEGROUNDS

-- MAIN APPLICATION
addappid(578080)
-- Game: addappid(578080)

-- MAIN APP DEPOTS / PACKAGES
addappid(578081, 1, "74eea6f9f5b0c0deea249bea435370fe734f552a55e1aca5b09ff4f3990ad53e")
addappid(578082, 1, "6cbd9e8da0339346aeaafb966fd6a173ee898929b9ba4349550c5489234dbac7")
