-- Lua provided by SkyAPI 
-- Game: Ratatan
addappid(2949320)
addappid(2949321, 1, "3b33d27a923706d4e15053028684f05880816915c68004b0e4c9f341b711e664")
