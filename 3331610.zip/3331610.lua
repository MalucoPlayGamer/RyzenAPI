-- Lua provided by SkyAPI 
-- Game: Dark Honor™
addappid(3331610)
addappid(3331611, 1, "140d799ddcb565e9853a7853db590a2fb6ebce184a9d1368b6a1d49da9401b6a")
