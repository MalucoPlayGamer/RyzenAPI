-- Lua provided by RyzenAPI
-- Game: Dark Honor™

-- MAIN APPLICATION
addappid(3331610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331611, 1, "140d799ddcb565e9853a7853db590a2fb6ebce184a9d1368b6a1d49da9401b6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
