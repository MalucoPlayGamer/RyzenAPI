-- Lua provided by RyzenAPI
-- Game: Cold Waters

-- MAIN APPLICATION
addappid(541210)

-- MAIN APP DEPOTS / PACKAGES
addappid(541211, 1, "6c288dd0856b544a4c0b832563772f0f8bbc7c3df76a16aea3ef9476010f0688")
addappid(541212, 1, "28601bf414e9fd53f90189824ef4070698eb4360a5bfbf7cb2c52b00a3dd68a2")
addappid(642510, 0, "27ab4ce764b0365a1ba5237540d5e00fb8bfc2f71f02cee04bcb70bc8e89f7dd")
