-- Lua provided by RyzenAPI
-- Game: 2092461

-- MAIN APPLICATION
addappid(2092461)
-- Game: addappid(2092461)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092461,0,"a342886c21ef3a2942d6d8f9a70f8827a0694e22fb9d73d77d1b5babc59f0076")
