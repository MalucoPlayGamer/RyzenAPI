-- Lua provided by RyzenAPI
-- Game: Hentai Christmas

-- MAIN APPLICATION
addappid(2245270)
-- Game: addappid(2245270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245271, 1, "b79accc970b03f1486dc70d722fd68b2e56b6e8e5f5d4e4fd5cbfb4e7c35f1b7")
