-- Lua provided by RyzenAPI
-- Game: Game: Turbo Carnage

-- MAIN APPLICATION
addappid(3932930)
-- Game: addappid(3932930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3932931, 1, "6765a8273385d129b244a032a65a6426ef5f2ab2060150dcfdbb283224be0607")
