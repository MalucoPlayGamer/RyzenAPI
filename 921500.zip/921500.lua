-- Lua provided by RyzenAPI 
-- Game: Jack Is Missing
addappid(921500)
addappid(921501, 1, "ee5548f41edd87177c05ea5bba1572ee376d36f33a83c43c4a759bd386853cac")
addappid(921502, 1, "93bf1b8c1a86a5e2d68b5515e16a86fef5053fa0dc650c4312a08bbcdf84462a")
addappid(921503, 1, "728cb62fb9b67177b4fd9d9a770b8b4796402e1c656edfdaef174fdb5430eaa0")
