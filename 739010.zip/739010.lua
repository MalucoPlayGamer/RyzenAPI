-- Lua provided by RyzenAPI
-- Game: The Blue Box

-- MAIN APPLICATION
addappid(739010)

-- MAIN APP DEPOTS / PACKAGES
addappid(739011, 1, "21fc8c09d8ec2267500ea80a6c52c31a6afdb853fe9b5e09dd2b178210d4cc99")
addappid(739013, 1, "52e4a0b7fced7c83c1d1e48944d5b9b63f59febbfce608f9a9078ef8eda2fcb2")
addappid(739014, 1, "6be5e45ec6635633b3bd62c11bdb8fcdfd582b88d3a163366fd58ffbc8de4388")
addappid(1214896, 0, "b2fba8f7a8c2cdf6b3a8eec8db20a2bdebc1eaf9bbc4e40b78e544dfe14e69f9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1214890)
addappid(1214891)
addappid(1214892)
addappid(1214893)
addappid(1214894)
addappid(1214895)
addappid(1214897)
