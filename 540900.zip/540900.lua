-- Lua provided by RyzenAPI
-- Game: 540900

-- MAIN APPLICATION
addappid(540900)
-- Game: addappid(540900)

-- MAIN APP DEPOTS / PACKAGES
addappid(540901, 1, "b41cb10679fdd76acebd930d520cbad5635a7b08042ea35d4e375e6efba24161")
