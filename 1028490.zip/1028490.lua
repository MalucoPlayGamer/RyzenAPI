-- Lua provided by SkyAPI 
-- Game: AppID 1028490
addappid(1028490)
addappid(1028491, 1, "c4ae2f3f94d9e5425c1117d6fc1155397b79366849ad010d099af66bd5f434ac")
