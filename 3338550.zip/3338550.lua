-- Lua provided by RyzenAPI
-- Game: Alma and the Fragments of Cursed Memories

-- MAIN APPLICATION
addappid(3338550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3338553,0,"92280d729a5477b0de3656081d0fb9190c0b66c8fde52d5bc7b99cc8f3e52e68")

