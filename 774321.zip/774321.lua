-- Lua provided by RyzenAPI
-- Game: STARBO - The Story of Leo Cornell

-- MAIN APPLICATION
addappid(774321)
-- Game: addappid(774321)

-- MAIN APP DEPOTS / PACKAGES
addappid(774322, 1, "b1b39a392d348f3cd68c6a879151e959ef016e111ffba8cf057538a5cdeded7b")
