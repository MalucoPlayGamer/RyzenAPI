-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Mature, Level-Headed, and Dependable Secretary Maid GP-01

-- MAIN APPLICATION
addappid(2926570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2926571, 1, "5156ea935caf3ceaad858fe408399a30dcb046c7f15cdc6d9f1ed5378dcda1c0")
