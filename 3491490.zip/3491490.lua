-- 3491490's Lua and Manifest Created by Hubcap Manifest
-- Will The King Escape?
-- Created: July 25, 2026 at 11:56:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3491490) -- Will The King Escape?
-- MAIN APP DEPOTS
addappid(3491491, 1, "816fff552fb53143ebc2a45fd832580231d89498f56f9a861e2a41b60a9c8aff") -- Depot 3491491
setManifestid(3491491, "3973323122292863161", 616355336)