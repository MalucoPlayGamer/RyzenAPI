-- Lua provided by RyzenAPI
-- Game: Leviathan Starblade

-- MAIN APPLICATION
addappid(549900)

-- MAIN APP DEPOTS / PACKAGES
addappid(549901,0,"0eef85a04132135e2e6ecd86a09abbd03aaf5369cc77cc6a0ad0d5a0e537ce6d")

