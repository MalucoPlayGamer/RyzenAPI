-- Lua provided by RyzenAPI
-- Game: BOT.vinnik Chess: Mid-Century USSR Championships

-- MAIN APPLICATION
addappid(1788410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788411, 1, "a292c31db85c676c45165f3db8852832b405ae53a92fc783c7351a175e24d63c")
