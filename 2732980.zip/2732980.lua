-- Lua provided by RyzenAPI
-- Game: Capybara: The story of Sisyphus

-- MAIN APPLICATION
addappid(2732980)
addappid(2914340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732981, 1, "97e3421e83b6419f1dd181922b5396c4e8890af266c2a8984e62967ed2245f3a")
