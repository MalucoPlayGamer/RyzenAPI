-- Lua provided by RyzenAPI
-- Game: Game: AppID 1739600

-- MAIN APPLICATION
addappid(1739600)
-- Game: addappid(1739600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739601, 1, "23dbd11cfe3b3c6cc88cc5f48052a3935e1d9da9a582f32f5660b292177b1bce")
