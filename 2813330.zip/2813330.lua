-- Lua provided by RyzenAPI
-- Game: Game: Rush Heroes

-- MAIN APPLICATION
addappid(2813330)
-- Game: addappid(2813330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2813331, 1, "d217a2d5da0cdd66115d700905058ccc50cfcbd36041c1e2527715dfabdb8035")
