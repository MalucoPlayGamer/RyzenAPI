-- Lua provided by RyzenAPI
-- Game: The Mooseman

-- MAIN APPLICATION
addappid(574310)
addappid(579890)

-- MAIN APP DEPOTS / PACKAGES
addappid(574311, 1, "df2c2736411af383fe379ce23690fe504d888e6e7ffac3a06ee679f294f97f70")

