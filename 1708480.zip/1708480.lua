-- Lua provided by RyzenAPI
-- Game: 暖雪 Warm Snow Demo

-- MAIN APPLICATION
addappid(1708480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708481, 1, "93e4e790c86637363e28768559192507a97533a34d3b4cbbc987d41d482d4da6")
