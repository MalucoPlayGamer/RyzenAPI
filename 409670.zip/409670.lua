-- Lua provided by RyzenAPI
-- Game: Game: AppID 409670

-- MAIN APPLICATION
addappid(409670)
-- Game: addappid(409670)

-- MAIN APP DEPOTS / PACKAGES
addappid(409671, 1, "b9577ff19393d6480f489d269516e8434cf0ba89edc6c6d9f8d01f53cfce2595")
addappid(409672, 1, "04b0a4bb4cbfa2767eae03744a68dcbcd2eb3c7f65273796c6f43d82e208eb31")
