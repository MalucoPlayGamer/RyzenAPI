-- Lua provided by RyzenAPI
-- Game: AppID 409670

-- MAIN APPLICATION
addappid(409670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(409671, 1, "b9577ff19393d6480f489d269516e8434cf0ba89edc6c6d9f8d01f53cfce2595")
addappid(409672, 1, "04b0a4bb4cbfa2767eae03744a68dcbcd2eb3c7f65273796c6f43d82e208eb31")

