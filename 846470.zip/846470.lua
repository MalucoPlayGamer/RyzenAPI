-- Lua provided by RyzenAPI 
-- Game: Moss VR
addappid(846470)
addappid(846471, 1, "2ea1d6b4f099a8c56b387dbab12334b24d276cff55504946af8fb4d8c88f8b0a")
addappid(925970, 0, "aed4861d7f7874d1496f03847c131ccef4cf8154022b37d14355e541fb68831e")
