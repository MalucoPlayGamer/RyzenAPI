-- Lua provided by RyzenAPI
-- Game: Moss VR

-- MAIN APPLICATION
addappid(846470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(846471, 1, "2ea1d6b4f099a8c56b387dbab12334b24d276cff55504946af8fb4d8c88f8b0a")
addappid(925970, 0, "aed4861d7f7874d1496f03847c131ccef4cf8154022b37d14355e541fb68831e")

