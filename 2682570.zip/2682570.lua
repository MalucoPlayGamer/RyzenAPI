-- Lua provided by SkyAPI 
-- Game: 魔方谏言
addappid(2682570)
addappid(2682571, 1, "085d46d5bdfc9299c2a1cd6bd4651ba1a40de6dea93392de4c11e4c1402dd888")
addappid(2682573, 1, "2026a5a9010277824a2794bda440ba0bf9f0c5527618cb32d7c374890308d9fc")
