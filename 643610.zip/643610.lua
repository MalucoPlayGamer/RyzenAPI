-- Lua provided by RyzenAPI
-- Game: Mortal Blitz

-- MAIN APPLICATION
addappid(643610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(643611,0,"7aeb49a1e0556c09c60bb873839fe246522c4b5215331d8111b47bd307f1c326")

