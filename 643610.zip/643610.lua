-- Lua provided by RyzenAPI
-- Game: Mortal Blitz

-- MAIN APPLICATION
addappid(643610)

-- MAIN APP DEPOTS / PACKAGES
addappid(643611,0,"7aeb49a1e0556c09c60bb873839fe246522c4b5215331d8111b47bd307f1c326")

