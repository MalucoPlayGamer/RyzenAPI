-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2307170)
addappid(2307171)
addappid(2307173)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307172,0,"595b95c6367ad08263a3cbd1cbe186de67639897fef301f39880378abc3d706b")

