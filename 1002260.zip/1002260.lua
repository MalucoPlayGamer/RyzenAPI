-- Lua provided by RyzenAPI 
-- Game: AppID 1002260
addappid(1002260)
addappid(1002261, 1, "6aea6ffacd2487544606fb4cea235949543ed57dbc547f181b7a8c4d0dca4c00")
addappid(1002262, 1, "9904b9743e2d74768ac31b7b3c9de96015278aa8034220af3f252d4ec7d95e81")
