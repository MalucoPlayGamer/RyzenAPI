-- Lua provided by RyzenAPI 
-- Game: AppID 1666350
addappid(1666350)
addappid(1666351, 1, "8514bfe857886c26073a4444f70607e0de505cc88626a6b9837110e5248b07df")
