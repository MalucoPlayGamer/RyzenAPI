-- Lua provided by RyzenAPI
-- Game: addappid(2795090)

-- MAIN APPLICATION
addappid(2795090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795092,0,"ccad51d4f51b5bdf2a6644a3084bed469c5d048ffffcbe45bcbc87d57a465ae4")
