-- Lua provided by RyzenAPI
-- Game: Line War

-- MAIN APPLICATION
addappid(1309610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309611, 1, "3dfaf6fe9e949792916333af7a2fb75f03850e8c6b7d5eb63e2ec6e58171fb1d")

