-- Lua provided by RyzenAPI
-- Game: 410430

-- MAIN APPLICATION
addappid(410430)
-- Game: addappid(410430)

-- MAIN APP DEPOTS / PACKAGES
addappid(410431, 1, "08aa84da6a2ccf83e4bff9959af8b773ec2649393a31bdf4a05e88d398238bdf")
