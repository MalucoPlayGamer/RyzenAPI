-- Lua provided by RyzenAPI
-- Game: A Castle Full of Cats

-- MAIN APPLICATION
addappid(2070550)
-- Game: addappid(2070550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070552,0,"52b6116cd80054759b2d869d012cf17869611830547284f56116f093e1eb9c7c")
addappid(2070553,0,"ffea7fbdd4c1f5d55f525073d2f40fa8ef677705f688c74c898daabfcd6d9861")
