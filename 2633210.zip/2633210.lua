-- Lua provided by RyzenAPI
-- Game: Catch Them Sweetie

-- MAIN APPLICATION
addappid(2633210)
addappid(2947370)
addappid(2947371)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2633211, 1, "ec140601183fa33fac7f5265a39fe76d69d27c8cb20a522be335e6e95f113b6e")

