-- Lua provided by RyzenAPI
-- Game: Catch Them Sweetie

-- MAIN APPLICATION
addappid(2633210)
addappid(2947370)
addappid(2947371)
-- Game: addappid(2633210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633211, 1, "ec140601183fa33fac7f5265a39fe76d69d27c8cb20a522be335e6e95f113b6e")
