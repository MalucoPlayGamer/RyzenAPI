-- Lua provided by RyzenAPI
-- Game: Choppy Cuts

-- MAIN APPLICATION
addappid(2947650)

