-- Lua provided by RyzenAPI
-- Game: addappid(1764790)

-- MAIN APPLICATION
addappid(1764790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764791, 1, "ba0ad1e58a95a00e6a6aadc3cda625af82335efe44ed2a3d6228a47605812eaf")
