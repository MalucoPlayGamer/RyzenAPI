-- Lua provided by RyzenAPI
-- Game: 1501720

-- MAIN APPLICATION
addappid(1501720)
-- Game: addappid(1501720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501721, 1, "42bd0e2c2685bb74569aedbec2fd67725d68195e86d6dd658f4b83961cb8452a")
