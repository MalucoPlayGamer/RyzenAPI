-- Lua provided by RyzenAPI
-- Game: BobsleighX

-- MAIN APPLICATION
addappid(1501720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501721, 1, "42bd0e2c2685bb74569aedbec2fd67725d68195e86d6dd658f4b83961cb8452a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
