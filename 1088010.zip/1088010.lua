-- Lua provided by RyzenAPI
-- Game: addappid(1088010)

-- MAIN APPLICATION
addappid(1088010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088011, 1, "ea9edd5ecf494f96c36c4b29f3b43e620fc429c00e6a297ddaa5d2fd094fc0b5")
