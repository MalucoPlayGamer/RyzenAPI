-- Lua provided by RyzenAPI
-- Game: Morphopolis

-- MAIN APPLICATION
addappid(314020)
-- Game: addappid(314020)

-- MAIN APP DEPOTS / PACKAGES
addappid(314021, 1, "39fb68dfa75113a0c6cc65a48008ea0c8ad4f5fc51ae17b26e2f7c2144f6b5a3")
