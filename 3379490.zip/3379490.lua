-- Lua provided by RyzenAPI
-- Game: Hostyle Playtest

-- MAIN APPLICATION
addappid(3379490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3379491, 1, "f83b0645c1f5b1198a325f64147eadd298f15bfe1e6d7a3947932d586910f1f8")

