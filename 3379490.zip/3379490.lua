-- Lua provided by SkyAPI 
-- Game: Hostyle Playtest
addappid(3379490)
addappid(3379491, 1, "f83b0645c1f5b1198a325f64147eadd298f15bfe1e6d7a3947932d586910f1f8")
