-- Lua provided by RyzenAPI
-- Game: 2701530

-- MAIN APPLICATION
addappid(2701530)
-- Game: addappid(2701530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701530,0,"c3d2a5740230d825ff72c6883c9660dc67125edbb703c8b31303d9c41ba83ce3")
