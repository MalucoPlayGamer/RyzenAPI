-- Lua provided by RyzenAPI
-- Game: Game: Everglow

-- MAIN APPLICATION
addappid(1763150)
-- Game: addappid(1763150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1763151, 1, "2713610fb8a9321772b44273289e5f7274f90fee319e93536d8eb940c3ece8c4")
