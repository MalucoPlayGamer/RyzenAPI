-- Lua provided by RyzenAPI
-- Game: 2496000

-- MAIN APPLICATION
addappid(2496000)
-- Game: addappid(2496000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496001, 1, "2f8790d1e41f925a3e63d7ed4184149302ee44de3074c402c4d7b284de7ffb5f")
