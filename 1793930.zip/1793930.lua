-- Lua provided by RyzenAPI
-- Game: Game: COVEN Demo

-- MAIN APPLICATION
addappid(1793930)
-- Game: addappid(1793930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793931, 1, "53210ae3085602f72906d1ab93cdf499c9cdccbacdfeaa1ee2f8b9958cf34516")
