-- Lua provided by RyzenAPI
-- Game: Dr. Chatelet: Faith 神医

-- MAIN APPLICATION
addappid(1924910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924911, 1, "77ba9130b6e5e2c77dd56a81fe9332fcfd5756b37613abc28077ad3ff900764a")
