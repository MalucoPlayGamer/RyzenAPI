-- Lua provided by RyzenAPI 
-- Game: Dwarven Realm
addappid(2891200)
addappid(2891201, 1, "9782ef4f4a8efacf375dd21834169d7b337b7ece1169a386dc3dac7d2346aade")
