-- Lua provided by RyzenAPI
-- Game: Alchemic Cutie

-- MAIN APPLICATION
addappid(913720)

-- MAIN APP DEPOTS / PACKAGES
addappid(913722,0,"691deee3918a5ac922e6ce599434d71a7cfb9db4903d0d4bad2dd654b19793cf")
addappid(913723,0,"9d69f0e4d2d72568c821ec05658d0f016a0f9b8dec5bfa1fbaa4f2d2eedcb926")
addappid(913724,0,"c8eb2be566f4977e1ac509fa1fe677e6465776bcc68432e0ff0122d61a90afad")

