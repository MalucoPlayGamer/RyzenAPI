-- Lua provided by RyzenAPI
-- Game: 2773840

-- MAIN APPLICATION
addappid(2773840)
-- Game: addappid(2773840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773841, 1, "38e87b510f80eca48807d512c963de9bba38cec8d8d745312f629cc52063a5b2")
