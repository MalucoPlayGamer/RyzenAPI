-- Lua provided by RyzenAPI
-- Game: Rise for the Fight - Early Access

-- MAIN APPLICATION
addappid(1871970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1871971, 1, "761a56d31eb4e74220ef167e1f9a123343736632c096c4f214b1a8fcf85e06be")
addappid(1871972, 1, "16e199b25fbe16c4f43df5a362f145e13557210fd76a0fe652e1fce01533d260")

