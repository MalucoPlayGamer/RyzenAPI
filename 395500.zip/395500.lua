-- Lua provided by RyzenAPI
-- Game: Rot Gut

-- MAIN APPLICATION
addappid(395500)
addappid(465691)
-- Game: addappid(395500)

-- MAIN APP DEPOTS / PACKAGES
addappid(395501, 1, "ac8278ae4ea07be9c3c268cf0e1d96a27a8262ea4b7ea8ea7e492bef75d2752b")
