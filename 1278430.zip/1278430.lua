-- Lua provided by RyzenAPI
-- Game: Game: Warehouse attack

-- MAIN APPLICATION
addappid(1278430)
-- Game: addappid(1278430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278431, 1, "bd2dbea8c889af69ccf77e8aa537b2d3c02ac7d5ad22e7252c5a4d7c2def52c1")
