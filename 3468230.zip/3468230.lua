-- Lua provided by RyzenAPI
-- Game: Mop Skater

-- MAIN APPLICATION
addappid(3468230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3468231, 1, "6ce2e0c4e7ee8b1e6d5381b920e38c23ce166ff672ff15fecbf76049c3850578")

