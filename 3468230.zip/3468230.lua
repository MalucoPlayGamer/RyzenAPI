-- Lua provided by RyzenAPI
-- Game: 3468230

-- MAIN APPLICATION
addappid(3468230)
-- Game: addappid(3468230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3468231, 1, "6ce2e0c4e7ee8b1e6d5381b920e38c23ce166ff672ff15fecbf76049c3850578")
