-- Lua provided by RyzenAPI
-- Game: 1848910

-- MAIN APPLICATION
addappid(1848910)
-- Game: addappid(1848910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848911, 1, "90b487af072e906cc5b0c11b81b4a616397b809dc23cf1fc7b53fadbc7f7a201")
