-- Lua provided by RyzenAPI
-- Game: Game: 人气动漫大乱斗

-- MAIN APPLICATION
addappid(1000310)
-- Game: addappid(1000310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000311, 1, "852760afc099c680dd944fbbdcb467ebe2c3f68e4399091d2ade46f306dfd402")
