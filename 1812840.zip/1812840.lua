-- Lua provided by RyzenAPI
-- Game: The Labyrinth of Greed

-- MAIN APPLICATION
addappid(1812840)
-- Game: addappid(1812840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812841, 1, "ce2dcb5203d4b80b0c6ed4cb1ed6a08f611a6119ff5de379405fba9e217ce434")
