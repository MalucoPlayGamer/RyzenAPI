-- Lua provided by RyzenAPI
-- Game: 单词训练营 | Word Training Camp

-- MAIN APPLICATION
addappid(1175100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175101, 1, "3c4a3fdf2fa7c1d406ff0b53f9b332a9ed357277a470af5b85bb27b8a0ee2129")

