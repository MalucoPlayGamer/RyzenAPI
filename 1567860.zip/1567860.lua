-- Lua provided by RyzenAPI
-- Game: Femboy Bangers - Pub & Grill

-- MAIN APPLICATION
addappid(1567860)
-- Game: addappid(1567860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567861, 1, "41c806bfedce84902a06013fb21f1358779b44698731d588d4f82ed16179b22b")
