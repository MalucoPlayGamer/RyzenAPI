-- Lua provided by RyzenAPI
-- Game: addappid(2390070)

-- MAIN APPLICATION
addappid(2390070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2390071, 1, "d95b888284c11d5d2227caba230ffb33573bffa0b725a2e6aa6a505e0f926482")
