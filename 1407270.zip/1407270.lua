-- Lua provided by RyzenAPI
-- Game: 1407270

-- MAIN APPLICATION
addappid(1407270)
-- Game: addappid(1407270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407271, 1, "22855fd904acc2c96548f624e06270580a39e0c594ee4d3a2f55b77e1af1241e")
