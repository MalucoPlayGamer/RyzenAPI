-- Lua provided by RyzenAPI
-- Game: Keng's Little Universe

-- MAIN APPLICATION
addappid(1725860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725861, 1, "bf39fba06434b862cb651702ca72b145424f4680411f2655712781639e64987c")

