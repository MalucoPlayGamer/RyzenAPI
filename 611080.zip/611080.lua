-- Lua provided by RyzenAPI
-- Game: 611080

-- MAIN APPLICATION
addappid(611080)
-- Game: addappid(611080)

-- MAIN APP DEPOTS / PACKAGES
addappid(611081, 1, "ada5f260b222046a2403b945164a93464baec0a75a171c32e6f46ac74707c44b")
