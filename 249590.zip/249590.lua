-- Lua provided by RyzenAPI
-- Game: AppID 249590

-- MAIN APPLICATION
addappid(249590)

-- MAIN APP DEPOTS / PACKAGES
addappid(249591, 1, "320c81076615725407aa0e3a0ceaaf17303ff3681c123f0e2023347e9f3b879f")
addappid(249592, 1, "a168ded2a585b01f7a17de7489ca7457508d4dd5fbcade4afc29ac3a53debcfd")
addappid(249593, 1, "24bb4ce9427af256fd8d1ef4ee7b5a723712f62b0ff19dbd5724882869e13331")
addappid(249595, 1, "b83c6ac1af184318945e52e977f3e381b970dc08c0bb6db55f60a04b00c97703")
addappid(650900, 0, "bc5cae3ce36c2ad6e30b57740c39222a0b2866498eeeee56baa7e25e6fe37c66")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
