-- Lua provided by RyzenAPI 
-- Game: The Children of The Woods - Lost Tape
addappid(2752660)
addappid(2752661, 1, "cedafae892dcd84c1fe4b1c33d88631c9ab4d47a0068da3c7013d9b68f9d8cbf")
