-- Lua provided by RyzenAPI
-- Game: fiction.colors

-- MAIN APPLICATION
addappid(228990)
addappid(1480540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480542,0,"85752c196f7ffd7d35e6bf774889a1393386cf4ed1a65179b6350b2fa38b2a8c")

