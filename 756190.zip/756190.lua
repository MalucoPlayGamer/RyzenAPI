-- Lua provided by RyzenAPI
-- Game: Game: Sky Road

-- MAIN APPLICATION
addappid(756190)
-- Game: addappid(756190)

-- MAIN APP DEPOTS / PACKAGES
addappid(756191, 1, "48a8decd028aa6f39cee32e060c5154ab6b152e225d3a09fe3e57be0a4a66886")
