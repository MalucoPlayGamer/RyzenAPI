-- Lua provided by RyzenAPI
-- Game: AppID 366160

-- MAIN APPLICATION
addappid(366160)

-- MAIN APP DEPOTS / PACKAGES
addappid(366161, 1, "aa71dcd63352cdeca74c40870edfca15b1b9efa0694f9400c5cf6d99f0e3dbc1")
addappid(366162, 1, "9c14e05ad8a01f3edd1e992aa8d45deba15fd18fa696b5a60b939a056a4bb547")
