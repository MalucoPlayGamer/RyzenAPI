-- Lua provided by RyzenAPI
-- Game: Familiar Findings

-- MAIN APPLICATION
addappid(3914780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3914781,0,"0c1cd7734e761fada0eae872d54ff728e4890d021827e15ca90b28b0476518a3")

