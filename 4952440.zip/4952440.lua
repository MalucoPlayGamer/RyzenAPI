-- Lua provided by RyzenAPI
-- Game: Slotlocked

-- MAIN APPLICATION
addappid(4952440) -- Slotlocked

-- MAIN APP DEPOTS / PACKAGES
addappid(4952441, 1, "1cf140924c6a28cd4398b4b6b3d58be7d377cbf79697ebe738c9c390fae62d6b") -- Depot 4952441

