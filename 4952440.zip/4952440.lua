-- 4952440's Lua and Manifest Created by Hubcap Manifest
-- Slotlocked
-- Created: August 05, 2026 at 22:35:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4952440) -- Slotlocked
-- MAIN APP DEPOTS
addappid(4952441, 1, "1cf140924c6a28cd4398b4b6b3d58be7d377cbf79697ebe738c9c390fae62d6b") -- Depot 4952441
setManifestid(4952441, "8427054292359846773", 163366731)