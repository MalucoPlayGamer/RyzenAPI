-- Lua provided by RyzenAPI
-- Game: Mini Metal

-- MAIN APPLICATION
addappid(454420)

-- MAIN APP DEPOTS / PACKAGES
addappid(454421, 1, "3c68b4dc8129891f7bf5fdfe741746bb6841f4b2ae9dbca03d172218124bc1b1")
addappid(454422, 1, "99565a73156e4c094a12462ffd3e620945f939fdd7b546ded40890ac8a10b372")
addappid(454423, 1, "39a19fb5b3cfdeba6a07803f3a2ac3aae6efd5c2932429caf8e51a7fa42f060b")
addappid(454424, 1, "1823de92ea81ec8625f37f0df617248e337067243b23f9aaab99a6fdcca00081")

