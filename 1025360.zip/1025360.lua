-- Lua provided by RyzenAPI
-- Game: addappid(1025360)

-- MAIN APPLICATION
addappid(1025360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025361, 1, "91973156408d687af2ad75f7cd60fd517aabb855ecca46e66073eb22820206ba")
