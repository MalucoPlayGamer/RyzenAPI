-- Lua provided by SkyAPI 
-- Game: AppID 1025360
addappid(1025360)
addappid(1025361, 1, "91973156408d687af2ad75f7cd60fd517aabb855ecca46e66073eb22820206ba")
