-- Lua provided by RyzenAPI
-- Game: Is This Game Trying To Kill Me? Demo

-- MAIN APPLICATION
addappid(3166880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3166881, 1, "ac660846934d9becd058fa1625e121d0cd41637ca879ffcb64fbfe49ef7c0a7d")

