-- Lua provided by RyzenAPI
-- Game: AppID 3051560

-- MAIN APPLICATION
addappid(3051560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3051561, 1, "aa2a7671e50d842e946b7c01bbbdfb9193cefb50df68bbe288b19330c6aee177")

