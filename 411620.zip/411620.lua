-- Lua provided by RyzenAPI 
-- Game: Pane In The Glass
addappid(411620)
addappid(411621, 1, "d24c405cc653717e29bb9232196370a47df6d799b9a5ba733ce5200802f520a0")
