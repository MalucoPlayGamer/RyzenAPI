-- Lua provided by RyzenAPI
-- Game: Idle ShowOff

-- MAIN APPLICATION
addappid(2392060)
-- Game: addappid(2392060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392061, 1, "d2870d41e70189f1df80f6ab9c7abfaabee6d0fbf36582d11794a6888eba2ed1")
