-- Lua provided by RyzenAPI
-- Game: REYNATIS - Mini Art Book

-- MAIN APPLICATION
addappid(3129530)
-- Game: addappid(3129530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3129530,0,"a247adcad5817ec3f49d84bfefa505bcc2d6a3750e6bce2670f939e752c811bc")
addtoken(3129530,3983366802017702124)
