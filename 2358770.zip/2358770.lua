-- Lua provided by RyzenAPI
-- Game: Million Monster Militia

-- MAIN APPLICATION
addappid(2358770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358771, 1, "789975ab84e1fab11884079a09d12cceadcafc3c0b7ed8aa6411e3bae89ba4cc")
addappid(2358772, 1, "c423c2a61ff75c3a3fa8277a840f1065851034c6b5deb8313f763a89a726df41")
