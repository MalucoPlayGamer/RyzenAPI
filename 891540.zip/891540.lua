-- Lua provided by RyzenAPI
-- Game: The Warrior War: Soundtrack

-- MAIN APPLICATION
addappid(891540)

-- MAIN APP DEPOTS / PACKAGES
addappid(891541, 1, "2d91647ec8bb8da1cfad35365636e5761939ee6c597854e821ccf6b714c23fa9")

