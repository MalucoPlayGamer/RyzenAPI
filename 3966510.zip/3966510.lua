-- Lua provided by RyzenAPI
-- Game: Feed the Scorchpot

-- MAIN APP DEPOTS / PACKAGES
addappid(3966510, 1, "c06fe1040eaab60b1f1812d63ac314425009988444f45da27ac29941c0697c24") -- Feed the Scorchpot
addappid(3966511, 1, "89fc42b587382ef78ba6fa9a31764750f58d0427ec35748d231eddfec1105c56") -- Depot 3966511

