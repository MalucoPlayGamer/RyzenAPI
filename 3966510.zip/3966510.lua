-- 3966510's Lua and Manifest Created by Hubcap Manifest
-- Feed the Scorchpot
-- Created: August 21, 2026 at 09:27:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3966510, 1, "c06fe1040eaab60b1f1812d63ac314425009988444f45da27ac29941c0697c24") -- Feed the Scorchpot
-- MAIN APP DEPOTS
addappid(3966511, 1, "89fc42b587382ef78ba6fa9a31764750f58d0427ec35748d231eddfec1105c56") -- Depot 3966511
setManifestid(3966511, "6781627749764096187", 724696155)