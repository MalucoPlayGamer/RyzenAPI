-- Lua provided by RyzenAPI
-- Game: 522570

-- MAIN APPLICATION
addappid(522570)
-- Game: addappid(522570)

-- MAIN APP DEPOTS / PACKAGES
addappid(522571, 1, "814edf8750365aca9a4e15b944ee1022183f56ccccae8461812fc322c22d8aaa")
