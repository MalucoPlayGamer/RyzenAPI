-- Lua provided by SkyAPI 
-- Game: The Last Hope
addappid(522570)
addappid(522571, 1, "814edf8750365aca9a4e15b944ee1022183f56ccccae8461812fc322c22d8aaa")
