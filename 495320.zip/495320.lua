-- Lua provided by RyzenAPI
-- Game: Ancient VR coaster

-- MAIN APPLICATION
addappid(495320)

-- MAIN APP DEPOTS / PACKAGES
addappid(495321, 1, "7efd5b343daa23bbf0af122975ce43bc49f0f3a0c04a25f992fa3d609fa3535d")

