-- Lua provided by RyzenAPI
-- Game: Letter Lancers: Prologue

-- MAIN APPLICATION
addappid(2925450)
-- Game: addappid(2925450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925451, 1, "fbe9593b031bf6fc828a483a13a7ce8f3ea6bf034b640e5e7d9575601bde320a")
