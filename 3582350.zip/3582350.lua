-- Lua provided by RyzenAPI
-- Game: 3582350

-- MAIN APPLICATION
addappid(3582350)
-- Game: addappid(3582350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582351, 1, "cb93805de9e971adbdf4dcdc44fbbc2ac2ac8ce17fb61dd16896ce4177df3c4e")
