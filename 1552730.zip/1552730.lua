-- Lua provided by SkyAPI 
-- Game: Fireworks Simulator: Realistic
addappid(1552730)
addappid(1552731, 1, "3049f2518709d3499d9d781bf529ff88b61a8367ea251c0c1f449d186c159a89")
