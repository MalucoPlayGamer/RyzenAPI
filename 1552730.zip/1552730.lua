-- Lua provided by RyzenAPI
-- Game: Fireworks Simulator: Realistic

-- MAIN APPLICATION
addappid(1552730)
-- Game: addappid(1552730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552731, 1, "3049f2518709d3499d9d781bf529ff88b61a8367ea251c0c1f449d186c159a89")
