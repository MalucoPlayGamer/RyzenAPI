-- Lua provided by RyzenAPI
-- Game: The Mysterious Cities of Gold

-- MAIN APPLICATION
addappid(261940)

-- MAIN APP DEPOTS / PACKAGES
addappid(261941, 1, "1923d50c329083e144b21044995b11cd484c10028ad2d8d5abb25d22826833a7")
