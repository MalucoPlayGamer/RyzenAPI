-- Lua provided by RyzenAPI
-- Game: Game: AppID 699460

-- MAIN APPLICATION
addappid(699460)
-- Game: addappid(699460)

-- MAIN APP DEPOTS / PACKAGES
addappid(699461, 1, "f97f3b3c9a530e4079df9a9eda373e0921080824cb5792da894320c641307aaf")
