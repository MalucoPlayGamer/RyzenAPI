-- Lua provided by RyzenAPI
-- Game: Inexistence

-- MAIN APPLICATION
addappid(444720)

-- MAIN APP DEPOTS / PACKAGES
addappid(444721, 1, "09d5e1e52aeaa7507efc071830c422b979fd7767f53589c2858a1623deacbf91")
addappid(463600, 0, "be1af9cdd4bf87a648f713b4e54f22f7f43c5be088843d2df5cabe92fdf034ef")

