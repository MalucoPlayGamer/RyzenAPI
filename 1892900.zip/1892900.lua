-- Lua provided by RyzenAPI
-- Game: WarBots

-- MAIN APPLICATION
addappid(1892900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1892901, 1, "fa00d93b8506178e75009aacceb1d044d141f9cac20832da254b6fdc655a9a8c")

