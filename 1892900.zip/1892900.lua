-- Lua provided by RyzenAPI 
-- Game: WarBots
addappid(1892900)
addappid(1892901, 1, "fa00d93b8506178e75009aacceb1d044d141f9cac20832da254b6fdc655a9a8c")
