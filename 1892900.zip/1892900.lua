-- Lua provided by RyzenAPI
-- Game: 1892900

-- MAIN APPLICATION
addappid(1892900)
-- Game: addappid(1892900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892901, 1, "fa00d93b8506178e75009aacceb1d044d141f9cac20832da254b6fdc655a9a8c")
