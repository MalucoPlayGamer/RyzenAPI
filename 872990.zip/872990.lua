-- Lua provided by RyzenAPI
-- Game: Game: AppID 872990

-- MAIN APPLICATION
addappid(872990)
-- Game: addappid(872990)

-- MAIN APP DEPOTS / PACKAGES
addappid(872991, 1, "1726f82ccf119168e7f850d6ba7be64b5e7199f6963552ae183923d263b9b080")
