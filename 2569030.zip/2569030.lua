-- Lua provided by RyzenAPI
-- Game: Depthdrops

-- MAIN APPLICATION
addappid(2569030)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(2569031, 1, "9eeed65f0d268a924b2b717bec6e194b0d940ce2ad661189017e23e7c29638c3")

