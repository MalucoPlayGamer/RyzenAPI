-- Lua provided by RyzenAPI
-- Game: Depthdrops

-- MAIN APPLICATION
addappid(2569030)
-- Game: addappid(2569030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569031, 1, "9eeed65f0d268a924b2b717bec6e194b0d940ce2ad661189017e23e7c29638c3")
