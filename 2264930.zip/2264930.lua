-- Lua provided by SkyAPI 
-- Game: 『LACKGIRL I - "Astra inclinant, sed non obligant."』
addappid(2264930)
addappid(2264931, 1, "bec92f43d9e5a2fd88553c7f5542b863beb66a4e6292ff1ba7027f6b6c8f0224")
