-- Lua provided by RyzenAPI
-- Game: Warface: Clutch

-- MAIN APPLICATION
addappid(291480)

-- MAIN APP DEPOTS / PACKAGES
addappid(291481, 1, "a7acb47ed390e070a19f509637e3ad1ca0364526bb5612999d0690ece3ef2355")
