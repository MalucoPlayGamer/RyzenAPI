-- Lua provided by RyzenAPI 
-- Game: Summer~Life in the Countryside~
addappid(1508570)
addappid(1508571, 1, "0fc8bbfd68f345b69c6afb453fb86b722789fb96fa1e3656964dac2a63f61e4d")
addappid(2107850, 0, "19d4a80e52b5f6ab4bcbec10fc570b877a01decc50fba435f37fdc47f5afe98a")
