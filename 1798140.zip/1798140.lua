-- Lua provided by RyzenAPI
-- Game: addappid(1798140)

-- MAIN APPLICATION
addappid(1798140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798141, 1, "17d53e75fca048a9812fee10fd55bb2c87028456eee3c5cb70584a332a37c7a3")
