-- Lua provided by RyzenAPI
-- Game: Monster Girls and the Mysterious Adventure 2

-- MAIN APPLICATION
addappid(1895860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895861, 1, "e21e581807cec458eaaf4e07aa8e71675ff5cb87b949bd7935eb9ea9ad88df51")

