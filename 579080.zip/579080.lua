-- Lua provided by SkyAPI 
-- Game: Snow Games VR
addappid(579080)
addappid(579081, 1, "0dc9b22f1c92f3e9787823402d4a4d215410f5bb44c62009b03da42946a7ab68")
