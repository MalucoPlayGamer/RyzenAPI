-- Lua provided by RyzenAPI
-- Game: Snow Games VR

-- MAIN APPLICATION
addappid(579080)

-- MAIN APP DEPOTS / PACKAGES
addappid(579081, 1, "0dc9b22f1c92f3e9787823402d4a4d215410f5bb44c62009b03da42946a7ab68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
