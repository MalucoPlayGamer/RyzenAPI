-- Lua provided by RyzenAPI
-- Game: Panelka

-- MAIN APPLICATION
addappid(3376760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376761, 1, "6312e77faa59685d239a3811eff6c2732f6996bf83dd4bc26f9aa057884d3cff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
