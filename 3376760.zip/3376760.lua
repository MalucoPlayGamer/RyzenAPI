-- Lua provided by RyzenAPI
-- Game: Panelka

-- MAIN APPLICATION
addappid(3376760)
-- Game: addappid(3376760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376761, 1, "6312e77faa59685d239a3811eff6c2732f6996bf83dd4bc26f9aa057884d3cff")
