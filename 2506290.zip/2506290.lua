-- Lua provided by RyzenAPI
-- Game: Nova Hearts

-- MAIN APPLICATION
addappid(2506290)
-- Game: addappid(2506290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506292,0,"0ceb83b19e1499aca0fca6f42e8238e2641a967256fdf83ae8f3aafc54ea8331")
