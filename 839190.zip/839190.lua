-- Lua provided by RyzenAPI
-- Game: 看见我~See Me Demo

-- MAIN APPLICATION
addappid(839190)
-- Game: addappid(839190)

-- MAIN APP DEPOTS / PACKAGES
addappid(839191, 1, "b00e26e7e03383e01436ac523787ff241b92cc08fe145557bfa820fb719a2543")
