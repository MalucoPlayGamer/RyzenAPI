-- Lua provided by RyzenAPI
-- Game: FUSER™ - The White Stripes - "Seven Nation Army"

-- MAIN APPLICATION
addappid(1535650)
-- Game: addappid(1535650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535650,0,"81d5d35c17a48a96cf29db86d60aa99a613a04f5c7d20ddacbc4c34f46f32081")
