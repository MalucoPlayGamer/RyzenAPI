-- Lua provided by RyzenAPI
-- Game: Heaven Snakes [Beta]

-- MAIN APPLICATION
addappid(1982230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982231, 1, "cc926d73ce6cddb0b81afd74edbacf685355c5336559b1531777add8239ddb66")

