-- Lua provided by SkyAPI 
-- Game: Dungeoneer
addappid(1951840)
addappid(1951841, 1, "f3a880a6406443d8e0ec93de97c95678aa9e464d6fb89696287eba1d458d8009")
