-- Lua provided by RyzenAPI
-- Game: Dungeoneer

-- MAIN APPLICATION
addappid(1951840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1951841, 1, "f3a880a6406443d8e0ec93de97c95678aa9e464d6fb89696287eba1d458d8009")

