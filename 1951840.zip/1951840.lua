-- Lua provided by RyzenAPI
-- Game: Dungeoneer

-- MAIN APPLICATION
addappid(1951840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951841, 1, "f3a880a6406443d8e0ec93de97c95678aa9e464d6fb89696287eba1d458d8009")

