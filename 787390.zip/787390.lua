-- Lua provided by RyzenAPI
-- Game: 787390

-- MAIN APPLICATION
addappid(787390)
-- Game: addappid(787390)

-- MAIN APP DEPOTS / PACKAGES
addappid(787391, 1, "f3c64bd1d46433efb5ec20957f47d10843fea9e4922faf7bfaa800e7975e9023")
