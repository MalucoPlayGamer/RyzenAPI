-- Lua provided by RyzenAPI
-- Game: Dudes on a Map: Virtual Grid Paper

-- MAIN APPLICATION
addappid(1470020)
addappid(1531100)
-- Game: addappid(1470020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470021, 1, "c13ce23c2b4fc5b4e7633d1c54822462846a11f6f7dfc02340b8f2e4398f1fc5")
addappid(1470022, 1, "950cdc459f2ec72083790b7426ba69882c746f5ad2522410334d8d3656f4d3cb")
