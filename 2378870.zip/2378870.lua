-- Lua provided by RyzenAPI
-- Game: CLOSED BETA TEST LWO

-- MAIN APPLICATION
addappid(2378870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378871, 1, "2689fa70ad854f34082635f5d54b6b1d2b3a818e9bffe251c9fc25f9079445b6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
