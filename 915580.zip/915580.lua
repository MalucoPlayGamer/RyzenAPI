-- Lua provided by RyzenAPI
-- Game: Dungeon Hunter Champions

-- MAIN APPLICATION
addappid(915580)

-- MAIN APP DEPOTS / PACKAGES
addappid(915581, 1, "64114cb5d904adfa7269ec100a803d9091cde2a99af96db889d2c18a5411ca96")
