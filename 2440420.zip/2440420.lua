-- Lua provided by RyzenAPI
-- Game: addappid(2440420)

-- MAIN APPLICATION
addappid(2440420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440421, 1, "1d6b4816f6145e5b86a006bf6c2bec85f82983d89ba29327fdfd59b77013fa37")
