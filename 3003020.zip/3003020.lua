-- Lua provided by RyzenAPI
-- Game: Steam Prison -Beyond the Steam-

-- MAIN APPLICATION
addappid(3003020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3003021, 1, "d446dcad0c6b3cc319234b30df70111be95caa7c6485e57054aa5364e0b16539")
