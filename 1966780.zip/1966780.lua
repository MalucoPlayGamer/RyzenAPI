-- Lua provided by RyzenAPI
-- Game: My Ass Pass to Succubus Sexland!

-- MAIN APPLICATION
addappid(1966780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966781, 1, "4454042304ade506788cbff08231a4c390c2cc2e49d50e0c1be144f5b278b6c9")

