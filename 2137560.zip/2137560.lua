-- Lua provided by RyzenAPI
-- Game: Touhou - Reimus Awesome Holiday

-- MAIN APPLICATION
addappid(2137560)
-- Game: addappid(2137560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137561, 1, "27b044d10906f78401de0a776e135c97f67f08b8f2acd768c6b400c62410d039")
