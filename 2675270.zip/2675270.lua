-- Lua provided by RyzenAPI
-- Game: Game: Blood Lily Loop

-- MAIN APPLICATION
addappid(2675270)
-- Game: addappid(2675270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675271, 1, "0d9f7e3b7f39f8cc2e5ed62fa3026cd5883d11b92af6f60cbae5aff8a43e12cf")
