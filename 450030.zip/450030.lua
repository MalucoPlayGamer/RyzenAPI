-- Lua provided by RyzenAPI
-- Game: Worst Case Z

-- MAIN APPLICATION
addappid(450030)

-- MAIN APP DEPOTS / PACKAGES
addappid(450031, 1, "9c4446e3d28d7581ad3e66ca57c875e3011c1a8dc11c4f8c0dfd65ad22dd67ec")
