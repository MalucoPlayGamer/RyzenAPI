-- Lua provided by RyzenAPI
-- Game: addappid(1904190)

-- MAIN APPLICATION
addappid(1904190)
addappid(2057630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904191, 1, "3ac6d4e70cb0655cce8763182bbcce676706369c0278379d04135fee355706e7")
