-- Lua provided by RyzenAPI
-- Game: AppID 1904190

-- MAIN APPLICATION
addappid(1904190)
addappid(2057630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904191, 1, "3ac6d4e70cb0655cce8763182bbcce676706369c0278379d04135fee355706e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
