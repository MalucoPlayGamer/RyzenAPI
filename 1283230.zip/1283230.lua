-- Lua provided by RyzenAPI
-- Game: Game: Autopsy Simulator

-- MAIN APPLICATION
addappid(1283230)
-- Game: addappid(1283230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283231, 1, "578da163a6889657d25ae77647b853543c386f98b887c29aec3845255d378ea3")
addappid(3017520, 0, "bf5308dd1c5f9bec7c93a631d0ff95730de681d7a940f9433cc48903db285647")
