-- Lua provided by RyzenAPI
-- Game: Escape the Game

-- MAIN APPLICATION
addappid(542310)
addappid(543560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(542311, 1, "8ed6d29ae9907058c47dac2ee26e815c4cff7850a43fad2b4aa3d9fe7359e821")

