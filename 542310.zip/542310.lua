-- Lua provided by RyzenAPI
-- Game: 542310

-- MAIN APPLICATION
addappid(542310)
-- Game: addappid(542310)

-- MAIN APP DEPOTS / PACKAGES
addappid(542311, 1, "8ed6d29ae9907058c47dac2ee26e815c4cff7850a43fad2b4aa3d9fe7359e821")
