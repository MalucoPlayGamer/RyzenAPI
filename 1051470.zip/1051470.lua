-- Lua provided by RyzenAPI
-- Game: addappid(1051470)

-- MAIN APPLICATION
addappid(1051470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051471, 1, "140cb84d28b5becf65cfb8067d9eea9b6fe3e29655f439ff7309801ea16c260c")
