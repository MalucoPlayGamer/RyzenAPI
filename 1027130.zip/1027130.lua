-- Lua provided by RyzenAPI
-- Game: Game: AppID 1027130

-- MAIN APPLICATION
addappid(1027130)
-- Game: addappid(1027130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027131, 1, "52a8844f8547f0a2e906826d264a565b84f823c1e2c7558afc784c5dfc80e392")
