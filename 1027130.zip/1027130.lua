-- Lua provided by RyzenAPI 
-- Game: AppID 1027130
addappid(1027130)
addappid(1027131, 1, "52a8844f8547f0a2e906826d264a565b84f823c1e2c7558afc784c5dfc80e392")
