-- Lua provided by RyzenAPI
-- Game: NEKO-NIN exHeart 2 Love+PLUS

-- MAIN APPLICATION
addappid(1027130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1027131, 1, "52a8844f8547f0a2e906826d264a565b84f823c1e2c7558afc784c5dfc80e392")
