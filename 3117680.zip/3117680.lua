-- Lua provided by RyzenAPI
-- Game: Hentai Girls Gallery

-- MAIN APPLICATION
addappid(3117680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3117681, 1, "55238a4f694d29e0a91d505d05fc4b0eefae7e5a8e0aa4c41a071105508aa83d")
