-- Lua provided by SkyAPI 
-- Game: Hentai Girls Gallery
addappid(3117680)
addappid(3117681, 1, "55238a4f694d29e0a91d505d05fc4b0eefae7e5a8e0aa4c41a071105508aa83d")
