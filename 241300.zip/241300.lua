-- Lua provided by RyzenAPI 
-- Game: Card City Nights 2
addappid(241300)
addappid(241301, 1, "cdf0f8a68e87cb6943703ebc8b4e7f9f54a7b24ce5922dae0955d755e0f3dbdb")
addappid(241302, 1, "c84efc6affa5cac16ed9a9cfbedce58a08ecc79a2accfddb0e478e6a6aa0a0d0")
addappid(241303, 1, "456c61231e9a6774e3e7695578cb651f3dda4f4a5f317d0ebda088d0fc85fd0f")
