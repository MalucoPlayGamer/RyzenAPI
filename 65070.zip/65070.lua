-- Lua provided by SkyAPI 
-- Game: AppID 65070
addappid(65070)
addappid(65071, 1, "1664da845c53a8a603149721db89460642a89abc282783ee07b12a53e499c1da")
addappid(65072, 1, "bd4e528ff7b529972d16bedcba66c20781b211679b963fcead4dbabff691138b")
addappid(65073, 1, "6aa3786ea15dd5b4cce13de53558b13f77647bbe370659967f86334eb86bc436")
addappid(228990)
