-- Lua provided by RyzenAPI
-- Game: Game: The Hundred Year Kingdom

-- MAIN APPLICATION
addappid(1581170)
-- Game: addappid(1581170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581171, 1, "522b1b00ab038f20987840102f316278f497df3dda966cdfca3ce3af63fe6916")
