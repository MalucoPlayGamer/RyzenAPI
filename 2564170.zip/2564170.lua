-- Lua provided by RyzenAPI 
-- Game: AppID 2564170
addappid(2564170)
addappid(2564171, 1, "5de744c30a12bb41fa809f25f83ce75181160b09df20cba7b9c0fefa99e99953")
addappid(2564172, 1, "a0797f07d450dc4d1c85a9474befd48943696533b5c0196135d25fcf4107534a")
