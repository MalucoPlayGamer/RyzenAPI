-- Lua provided by RyzenAPI
-- Game: Fire On Fight : Online Multiplayer Shooter

-- MAIN APPLICATION
addappid(1092050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092053,0,"76ff5453943b2b602f6504100b5597a3d3ed7dc84024b77c258cccce9a84be4b")

