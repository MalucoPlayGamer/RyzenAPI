-- Lua provided by RyzenAPI
-- Game: setManifestid(1092053,"7143364027852693569")

-- MAIN APPLICATION
addappid(1092050)
-- Game: addappid(1092050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092053,0,"76ff5453943b2b602f6504100b5597a3d3ed7dc84024b77c258cccce9a84be4b")
