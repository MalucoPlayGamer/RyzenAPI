-- Lua provided by RyzenAPI
-- Game: addappid(2233200)

-- MAIN APPLICATION
addappid(2233200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233201, 1, "a88531574e23f4e8a680699f1c8111cbbbe033797dde9ddd541ee75f95fed7a9")
