-- Lua provided by RyzenAPI
-- Game: Stunts above Clouds 2

-- MAIN APPLICATION
addappid(2840010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840011, 1, "ea6e6bcde311deb71c8fb50681812075400b340c411e96c3860ae9bb078fa65a")
