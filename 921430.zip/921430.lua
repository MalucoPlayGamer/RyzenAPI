-- Lua provided by RyzenAPI
-- Game: Genius! NAZI-GIRL GoePPels-Chan ep1

-- MAIN APPLICATION
addappid(921430)
-- Game: addappid(921430)

-- MAIN APP DEPOTS / PACKAGES
addappid(921431, 1, "19c1ac0f752a6d6f3a04b2788b13c524dd6b917a6ca4d6387d110bf7784dc914")
