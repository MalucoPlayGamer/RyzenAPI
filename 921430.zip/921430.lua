-- Lua provided by RyzenAPI
-- Game: Genius! NAZI-GIRL GoePPels-Chan ep1

-- MAIN APPLICATION
addappid(921430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(921431, 1, "19c1ac0f752a6d6f3a04b2788b13c524dd6b917a6ca4d6387d110bf7784dc914")

