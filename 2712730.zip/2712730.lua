-- Lua provided by RyzenAPI
-- Game: AppID 2712730

-- MAIN APPLICATION
addappid(2712730)
-- Game: addappid(2712730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712731, 1, "90a87a76cf631ccd2af998b432780e6e698966194c602d5424a34cbca9cb7517")
