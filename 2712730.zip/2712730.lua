-- Lua provided by RyzenAPI
-- Game: 杉木花与风信子

-- MAIN APPLICATION
addappid(2712730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712731, 1, "90a87a76cf631ccd2af998b432780e6e698966194c602d5424a34cbca9cb7517")

