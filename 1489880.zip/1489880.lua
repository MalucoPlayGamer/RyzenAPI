-- Lua provided by RyzenAPI
-- Game: addappid(1489880)

-- MAIN APPLICATION
addappid(1489880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489881, 1, "42a68c3a99bba2d05bb160e468c3e0096dda3a8bb5e786ce5f51091541e7b599")
