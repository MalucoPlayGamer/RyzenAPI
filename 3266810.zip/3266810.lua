-- Lua provided by RyzenAPI
-- Game: Jetpack Birdie Playtest

-- MAIN APPLICATION
addappid(3266810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3266811, 1, "0dc0ce04d653a02a0c211740b662b1978c66dd4b1d9017746305778ccbdba6ed")

