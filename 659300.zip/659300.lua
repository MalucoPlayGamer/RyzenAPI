-- Lua provided by RyzenAPI
-- Game: Super Farming Boy

-- MAIN APPLICATION
addappid(659300)
