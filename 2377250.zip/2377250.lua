-- Lua provided by RyzenAPI
-- Game: Whimel Academy

-- MAIN APPLICATION
addappid(2377250)
-- Game: addappid(2377250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377251, 1, "db59201fba7cfbfc6f6f90f0bac0233b2a414afc92fa181037314aceccee999b")
