-- Lua provided by RyzenAPI
-- Game: NecroCity: Prologue

-- MAIN APPLICATION
addappid(2012820)
-- Game: addappid(2012820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012821, 1, "c658014111aa8d75c990a04db6d4a8a9a841a96991439d3bfd3a85525485b2c9")
