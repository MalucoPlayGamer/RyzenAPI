-- Lua provided by SkyAPI 
-- Game: NecroCity: Prologue
addappid(2012820)
addappid(2012821, 1, "c658014111aa8d75c990a04db6d4a8a9a841a96991439d3bfd3a85525485b2c9")
