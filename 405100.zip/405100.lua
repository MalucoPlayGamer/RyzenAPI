-- Lua provided by RyzenAPI
-- Game: Hurtworld Dedicated Server

-- MAIN APPLICATION
addappid(405100)

-- MAIN APP DEPOTS / PACKAGES
addappid(405101, 1, "f30a8ab6ae9d36c1cc8241af349aef1d2522b1b09d05d798715de75e81d00854")
addappid(405102, 1, "31789f249191203314558e38f2f76d3c114224ea6c5915fd2e45c09aa72cfb3b")
addappid(405103, 1, "752c0b1ff5d43089a36dc06ded98cccb6ef4d058f5c02d25f6119a6c19916423")
