-- Lua provided by RyzenAPI 
-- Game: NKODICE
addappid(1510950)
addappid(1510951, 1, "8f217e0a8b50bd265e6f9025d45a44d35fa3992519692976c65d517a4f53884f")
