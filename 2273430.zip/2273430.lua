-- Lua provided by RyzenAPI
-- Game: BlazBlue Entropy Effect

-- MAIN APPLICATION
addappid(2273430)
addappid(3085820)
addappid(3422870)
addappid(3681910)
addappid(4212180)
addappid(4372140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2273431,0,"8208c2f3da1d2334a1bdfdce064948df43608a9dce229fd006defc11ec0bb5ff")
addappid(2273432,0,"61cf08549f627caaf2793f6324710aa2bc1e9ce5b15ddd5f91a07fe323c89cef")
addappid(2771130,0,"9252ee34ddef99b9842cf9b953a265b23f119aac46977475999deac055a2aa24")

