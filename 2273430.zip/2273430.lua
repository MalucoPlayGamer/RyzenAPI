-- Lua provided by SkyAPI 
-- Game: BlazBlue Entropy Effect
addappid(2273430)
addappid(2273431, 1, "8208c2f3da1d2334a1bdfdce064948df43608a9dce229fd006defc11ec0bb5ff")
addappid(2273432, 1, "61cf08549f627caaf2793f6324710aa2bc1e9ce5b15ddd5f91a07fe323c89cef")
addappid(2771130, 0, "9252ee34ddef99b9842cf9b953a265b23f119aac46977475999deac055a2aa24")
