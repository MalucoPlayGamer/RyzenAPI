-- Lua provided by RyzenAPI
-- Game: 880414

-- MAIN APPLICATION
addappid(880414)
-- Game: addappid(880414)

-- MAIN APP DEPOTS / PACKAGES
addappid(880414,0,"a9e5564471a3a6b09aed183aa3dbf77c699d72c98b65ba2dac92e114a36740b6")
addtoken(880414,"9057945740060895040")
