-- Lua provided by RyzenAPI
-- Game: addappid(3334710)

-- MAIN APPLICATION
addappid(3334710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3334711, 1, "7b99b332fd3b4d33b5294ba535ea4e1a37f88024fb7b8472d857eb771e0715a0")
