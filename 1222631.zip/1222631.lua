-- Lua provided by RyzenAPI
-- Game: RetroArch - bsnes

-- MAIN APPLICATION
addappid(1222631)
-- Game: addappid(1222631)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222631,0,"ec08b5ddd7e973a1b39a72651f0e23f9fddd19ee8e95c26d57fe8226254d01c7")
addappid(1790160,0,"fdc51a1ef12ea6e36f5cdce55d1d7480e48f2b2615855646d4f84b92b591b4b2")
addappid(1790161,0,"80e05db04d9695834ba0c0d96c51a1677011c8cf851633f4f4ac14d6f8b5d2c4")
