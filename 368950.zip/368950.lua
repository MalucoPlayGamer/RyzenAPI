-- Lua provided by RyzenAPI
-- Game: AppID 368950

-- MAIN APPLICATION
addappid(368950)
-- Game: addappid(368950)

-- MAIN APP DEPOTS / PACKAGES
addappid(368951, 1, "db7875edf24e4bf0ad2df4f18f96a517995f58109972785ad635e37c170d8d27")
