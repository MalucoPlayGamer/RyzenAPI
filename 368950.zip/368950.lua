-- Lua provided by RyzenAPI
-- Game: Jigoku Kisetsukan: Sense of the Seasons

-- MAIN APPLICATION
addappid(368950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(368951, 1, "db7875edf24e4bf0ad2df4f18f96a517995f58109972785ad635e37c170d8d27")
