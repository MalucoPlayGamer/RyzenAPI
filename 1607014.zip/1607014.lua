-- Lua provided by RyzenAPI
-- Game: addappid(1607014)

-- MAIN APPLICATION
addappid(1607014)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607014,0,"e8730ab2ae2dbb9236976b1a0c274b9f000d1203fbfd735c22692967a0e00b72")
