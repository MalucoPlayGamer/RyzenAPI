-- Lua provided by RyzenAPI 
-- Game: Sex Simulator - Bar Staff
addappid(2729990)
addappid(2729991, 1, "e779e1ff057a747bd2ffa1d94d9ca2e1941681d783540adcfca00191e7e10068")
