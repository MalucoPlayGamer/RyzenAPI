-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Extra Area "Heartscape"

-- MAIN APPLICATION
addappid(1754696)
-- Game: addappid(1754696)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754696,0,"5358e8fac5274f01364d3bc414c5953d3fe293f777ce09aeb074d0ad271a1d67")
