-- Lua provided by RyzenAPI
-- Game: DFF NT: Y'shtola Starter Pack

-- MAIN APPLICATION
addappid(1022469)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022469,0,"dc423d96702c1164fffdbb8dcf0d8ce2e7e2e513f02a7198bb9cefc059ab271f")
