-- Lua provided by RyzenAPI
-- Game: 3677290

-- MAIN APPLICATION
addappid(3677290)
-- Game: addappid(3677290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3677291, 1, "f2f97b338b55414ba05d1dca997e044ce02f281c5f52e9f44ab4dee7c4f7b0e3")
