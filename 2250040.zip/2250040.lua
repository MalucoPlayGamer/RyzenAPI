-- Lua provided by RyzenAPI
-- Game: Crosshair V2

-- MAIN APPLICATION
addappid(2250040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250041, 1, "3d8a488b7c7334a3b7a5cba340c8d97ef71ab99fa660a62cdf624c46c7ea0cf4")

