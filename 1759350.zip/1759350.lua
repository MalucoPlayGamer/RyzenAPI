-- Lua provided by RyzenAPI 
-- Game: Space Trash Scavenger
addappid(1759350)
addappid(1759351, 1, "d2245152748f3f80ac259bcd63c20a9979422468d2783be4e552dd0b9b191861")
