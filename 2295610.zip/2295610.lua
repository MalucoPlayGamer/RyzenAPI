-- Lua provided by RyzenAPI
-- Game: 2295610

-- MAIN APPLICATION
addappid(2295610)
-- Game: addappid(2295610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2295611, 1, "8f2eddb84ea6342d6f394369a9e4efb2acc8686d096e3a57199d8f63bdb7f788")
