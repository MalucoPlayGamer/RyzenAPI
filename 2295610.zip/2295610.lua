-- Lua provided by SkyAPI 
-- Game: Abathor
addappid(2295610)
addappid(2295611, 1, "8f2eddb84ea6342d6f394369a9e4efb2acc8686d096e3a57199d8f63bdb7f788")
