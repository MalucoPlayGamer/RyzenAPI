-- Lua provided by RyzenAPI
-- Game: addappid(40920)

-- MAIN APPLICATION
addappid(40920)

-- MAIN APP DEPOTS / PACKAGES
addappid(40921, 1, "0435c1819b7cd6f060439de2762ae312a4abee2c74cf9b828057f84cc48be8e2")
