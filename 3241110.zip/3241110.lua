-- Lua provided by RyzenAPI
-- Game: 封神

-- MAIN APPLICATION
addappid(3241110)
-- Game: addappid(3241110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241111, 1, "87e5538fb4a5c525dacaa834224f334cc7c9106b1f4c15950a5909f01ca03f42")
