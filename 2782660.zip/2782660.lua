-- Lua provided by RyzenAPI
-- Game: 1001 Nights Demo

-- MAIN APPLICATION
addappid(2782660)
-- Game: addappid(2782660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782661, 1, "db85c22a68585e3dd5f56cb92a994e1d48b1adc47ce647de787df9615443f9c2")
