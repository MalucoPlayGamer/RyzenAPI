-- Lua provided by RyzenAPI
-- Game: Sword and Shadow

-- MAIN APPLICATION
addappid(1994480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994481, 1, "177fae9aa4294d212974cf6535dec038a9cb11d9a6822e089982592e2566187d")
