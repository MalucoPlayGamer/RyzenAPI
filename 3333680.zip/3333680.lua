-- Lua provided by SkyAPI 
-- Game: 100 Find Kitties: Thief
addappid(3333680)
addappid(3333681, 1, "a47e05c3dcb181d8c6b8bcc4726b93383c3d1eb2fd519bf7b588562ed6d99138")
