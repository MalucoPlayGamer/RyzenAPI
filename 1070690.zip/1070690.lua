-- Lua provided by RyzenAPI
-- Game: RollerCoaster VR Universe

-- MAIN APPLICATION
addappid(1070690)
-- Game: addappid(1070690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070691, 1, "99dc5768c326beb70b9a6bddc607b349b5310b97aeb22f15bb6e3309c59e484d")
