-- Lua provided by RyzenAPI
-- Game: ZERO GUNNER 2-

-- MAIN APPLICATION
addappid(1342250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342251, 1, "dbb6cbdd7ed82639ac27032f5c9d979a5eebc2f4b103230e94dc1b484d66cb17")
