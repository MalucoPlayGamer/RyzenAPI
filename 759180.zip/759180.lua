-- Lua provided by RyzenAPI
-- Game: Bizarre Tale

-- MAIN APPLICATION
addappid(759180)

-- MAIN APP DEPOTS / PACKAGES
addappid(759181,0,"ec607a8cc8526d36031538344ba9dd5e122b9c2876ea986379f6a0c8138fe508")

