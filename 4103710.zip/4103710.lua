-- Lua provided by RyzenAPI
-- Game: Amazons vs Zombies 🔞

-- MAIN APPLICATION
addappid(4103710)

-- MAIN APP DEPOTS / PACKAGES
addappid(4103711,0,"c055a1274df62da1ea6f8203cf62bafbbb0725c8e2935d47d3b5039c6b2a9483")

