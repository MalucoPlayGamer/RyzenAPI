-- Lua provided by RyzenAPI
-- Game: addappid(610400)

-- MAIN APPLICATION
addappid(610400)

-- MAIN APP DEPOTS / PACKAGES
addappid(610400,0,"5d15eb12ab933f4f81ef2c8101a4f1a764dc0411a74b67b2123b2a1bdea778e9")
