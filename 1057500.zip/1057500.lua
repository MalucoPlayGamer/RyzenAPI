-- Lua provided by SkyAPI 
-- Game: Sim 4K VR MediaPlayer
addappid(1057500)
addappid(1057501, 1, "9306b17a0a7825502b943ef22f6d03f314bb67bdda3ecd74688855ab60c238c1")
