-- Lua provided by RyzenAPI
-- Game: Sim 4K VR MediaPlayer

-- MAIN APPLICATION
addappid(1057500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1057501, 1, "9306b17a0a7825502b943ef22f6d03f314bb67bdda3ecd74688855ab60c238c1")

