-- Lua provided by RyzenAPI
-- Game: addappid(1057500)

-- MAIN APPLICATION
addappid(1057500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057501, 1, "9306b17a0a7825502b943ef22f6d03f314bb67bdda3ecd74688855ab60c238c1")
