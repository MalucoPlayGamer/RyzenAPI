-- Lua provided by RyzenAPI
-- Game: Invector: Rhythm Galaxy

-- MAIN APPLICATION
addappid(2009450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009451, 1, "ca1c7feb6bf278dda6fcd952032f4bdbdcc79757b9399868e1c34f56c920c5c4")
addappid(2552980, 0, "abaffadb56619843e298e71ea39422bd20466d3adea446637f9d9e47bfe73d72")
addappid(2617860, 0, "7f6d81f1bf2cceaf5f306321a687d99421552082b36b19b3057b6538c1b6f8df")
