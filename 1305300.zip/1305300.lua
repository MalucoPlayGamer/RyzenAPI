-- Lua provided by RyzenAPI
-- Game: Love Love School Days

-- MAIN APPLICATION
addappid(1305300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305301, 1, "f8b020856f2e87bb765193e2820af0d07dd73045d91a5a38863471ae0b54694c")
