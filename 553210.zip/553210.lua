-- Lua provided by RyzenAPI
-- Game: AppID 553210

-- MAIN APPLICATION
addappid(553210)

-- MAIN APP DEPOTS / PACKAGES
addappid(553211, 1, "3ef5d20aa89cc5b57abf03006ae029ac81e35892b25820c4bceffae024ae2176")

