-- Lua provided by RyzenAPI
-- Game: AppID 553210

-- MAIN APPLICATION
addappid(553210)

-- MAIN APP DEPOTS / PACKAGES
addappid(553211, 1, "3ef5d20aa89cc5b57abf03006ae029ac81e35892b25820c4bceffae024ae2176")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(710300)
addappid(760720)
addappid(795720)
addappid(887030)
addappid(942180)
addappid(965430)
addappid(1073650)
addappid(1073660)
