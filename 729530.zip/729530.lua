-- Lua provided by RyzenAPI
-- Game: addappid(729530)

-- MAIN APPLICATION
addappid(729530)

-- MAIN APP DEPOTS / PACKAGES
addappid(729531, 1, "c4a44d4ac3c7996991892a07d0c8c8b41f4c584705c9cb0ae66e2242d1240f90")
