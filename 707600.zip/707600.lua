-- Lua provided by RyzenAPI
-- Game: Achievement Hunter: Dogger

-- MAIN APPLICATION
addappid(707600)

-- MAIN APP DEPOTS / PACKAGES
addappid(707601, 1, "652f63bfc288823f1fd86cd075c6e1cefe76ce21c523b3cce4c16f9deca4add4")
