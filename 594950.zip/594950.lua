-- Lua provided by RyzenAPI
-- Game: The Witches' Tea Party

-- MAIN APPLICATION
addappid(594950)

-- MAIN APP DEPOTS / PACKAGES
addappid(594952,0,"e61dcad199cd273e2c3d09ac9c5780c4d7c5409698104e43690257a97f2e64d5")
addappid(594956,0,"59974f1503ae65fb0569d7bc8fde627e69fd37a377264e9ea85dca144dde5e36")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(678270)
addappid(678280)
addappid(890350)
