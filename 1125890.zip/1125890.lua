-- Lua provided by RyzenAPI
-- Game: Party Maker

-- MAIN APPLICATION
addappid(1125890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125891, 1, "51865a52a9b6db33fe2f2ac29616de63c95d10314eaf383eb93be2399244e1b7")
