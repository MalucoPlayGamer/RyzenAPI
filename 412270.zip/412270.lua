-- Lua provided by RyzenAPI
-- Game: Game: Stories of Bethem: Full Moon

-- MAIN APPLICATION
addappid(412270)
-- Game: addappid(412270)

-- MAIN APP DEPOTS / PACKAGES
addappid(412271, 1, "bc650f1ce7191133af3f191954a433c585a56e20588acfdc4e7afa883e95231b")
addappid(412272, 1, "1259b766252a7179b70733ef19b60047dc7b5704183162991002377c502cdebc")
addappid(412273, 1, "0633438f76b0135fe8138a1bf7d676e0e20a606153b1f780ade18e345d5da18f")
