-- Lua provided by RyzenAPI
-- Game: Summon of Asmodeus

-- MAIN APPLICATION
addappid(1042170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042171, 1, "6305f7bf2fd471858f9dcddf603a8ba87164b40e51b094a70046f50f2a2b38e4")
