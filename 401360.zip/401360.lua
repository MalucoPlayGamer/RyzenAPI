-- Lua provided by RyzenAPI
-- Game: The Aquatic Adventure of the Last Human

-- MAIN APPLICATION
addappid(401360)
-- Game: addappid(401360)

-- MAIN APP DEPOTS / PACKAGES
addappid(401361, 1, "f5a4a6a6e555c5c379edb60c3ee18336449222fd74aef1559e59521fd8347f7e")
addappid(401364, 1, "8e5cd5dfc8a24a7bf2d68ece686e3b21b3f4629286b82c7810e8d2f4a7ffb96b")
addappid(401365, 1, "c0362e068bf8b8eb3a881a8c62165b87ed846fdb4346191b9d3605dc3d12261d")
addappid(441710, 0, "740e0b67a25d0f86fb74c5d4c180a6884b5df74ec39373a0cad0ea3db74a7170")
