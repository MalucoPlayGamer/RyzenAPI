-- Lua provided by RyzenAPI
-- Game: 7 Soccer: a sci-fi soccer tale

-- MAIN APPLICATION
addappid(788500)

-- MAIN APP DEPOTS / PACKAGES
addappid(788501, 1, "170762014e37fc627769e42d618b4195a1db46bc517102607d71a75e0698c240")
