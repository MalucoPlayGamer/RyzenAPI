-- Lua provided by SkyAPI 
-- Game: AppID 788500
addappid(788500)
addappid(788501, 1, "170762014e37fc627769e42d618b4195a1db46bc517102607d71a75e0698c240")
