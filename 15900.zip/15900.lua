-- Lua provided by RyzenAPI
-- Game: 7 Wonders II

-- MAIN APPLICATION
addappid(15900)

-- MAIN APP DEPOTS / PACKAGES
addappid(15901, 1, "e129c6b84b3465277339dce0264457968a33fc84ab80369f66ac40a8f2be2b38")