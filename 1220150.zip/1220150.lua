-- Lua provided by RyzenAPI
-- Game: AppID 1220150

-- MAIN APPLICATION
addappid(1220150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1220151, 1, "a2192e5a6b5ef59eccd27dbc9d92eb107fc920b831b4eb377b7c458d3523063e")

