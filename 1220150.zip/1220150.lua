-- Lua provided by RyzenAPI
-- Game: Game: AppID 1220150

-- MAIN APPLICATION
addappid(1220150)
-- Game: addappid(1220150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220151, 1, "a2192e5a6b5ef59eccd27dbc9d92eb107fc920b831b4eb377b7c458d3523063e")
