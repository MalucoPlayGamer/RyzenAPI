-- Lua provided by RyzenAPI
-- Game: BandRoll

-- MAIN APPLICATION
addappid(2206390)
-- Game: addappid(2206390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206391, 1, "7b4cb99528183a3ffe6da78f9b7a7955f8999bde5055c062f2e707ec62a82d1d")
