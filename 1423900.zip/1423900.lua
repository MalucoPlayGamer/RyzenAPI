-- Lua provided by RyzenAPI 
-- Game: Project Hospital - Traumatology Department
addappid(1423900)
addappid(1423901, 1, "e769b7cf6049294e299b483c76c9526892d71e9ac191975d7d4abf680aa4bdc1")
addappid(1423902, 1, "8c80b060cfcfd64baa71e2ca772c88730a554cf024959c037176498ca49b7acc")
addappid(1423903, 1, "03273afc355f0e967cd1d9048f2e8a54ebfb8be1a0f1f68da036b575a2100852")
