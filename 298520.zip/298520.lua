-- Lua provided by RyzenAPI
-- Game: Game: Orbital Gear

-- MAIN APPLICATION
addappid(298520)
-- Game: addappid(298520)

-- MAIN APP DEPOTS / PACKAGES
addappid(298521, 1, "0a9765bcec3160326ef8bce20a06ee879f47cdc044cf02772501b6dcea32ca53")
addappid(298522, 1, "27ea07eb11c50daa5bd73eee75d9206df9a83ebc6952ec3414d514574b09876b")
addappid(298523, 1, "fc93f2ac54af9a608264b10c91bb40bd20d01aea95ca3b1357615920649f0442")
addappid(358880, 0, "01e1c12b593a9101ba1229b2bb1ff8f7a6d1ecdfac528d16c52c9144733747cf")
