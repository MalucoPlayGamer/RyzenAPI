-- Lua provided by RyzenAPI
-- Game: Sunny Memories

-- MAIN APPLICATION
addappid(2204720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204721, 1, "29162c977c82e000212801ac601f6f77fcece1a0a85e1335d899fe9b49fc8d5f")
