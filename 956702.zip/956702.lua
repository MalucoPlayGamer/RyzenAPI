-- Lua provided by RyzenAPI
-- Game: Sima Yi - Officer Ticket / 司馬懿使用券

-- MAIN APPLICATION
addappid(956702)

-- MAIN APP DEPOTS / PACKAGES
addappid(956702,0,"d3150aea50eb8da6ad4f2609eea552521dc4b4d052f731660b2e5dc918df1cf1")

