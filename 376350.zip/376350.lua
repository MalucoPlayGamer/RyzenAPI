-- Lua provided by RyzenAPI
-- Game: 376350

-- MAIN APPLICATION
addappid(376350)
-- Game: addappid(376350)

-- MAIN APP DEPOTS / PACKAGES
addappid(376351, 1, "78763edd8c7b09c0aa82bff7e59835023e13cd4e1465b0871d949f367bb0b083")
