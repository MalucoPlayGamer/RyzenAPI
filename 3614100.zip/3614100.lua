-- Lua provided by RyzenAPI
-- Game: Accretion

-- MAIN APPLICATION
addappid(3614100)
-- Game: addappid(3614100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3614101, 1, "70100a46d9a08e4d2002f97a7074ad7bbba5186883a1ad3efe43a44f664c949f")
