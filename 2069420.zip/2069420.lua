-- Lua provided by RyzenAPI
-- Game: addappid(2069420)

-- MAIN APPLICATION
addappid(2069420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069421, 1, "7a1fbd53cbd877f77d81155c3b038382f81e5fb3e7fc0902277f5f371309b7b0")
