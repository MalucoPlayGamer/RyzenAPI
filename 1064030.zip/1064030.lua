-- Lua provided by RyzenAPI
-- Game: King of the Cul-De-Sac

-- MAIN APPLICATION
addappid(1064030)
-- Game: addappid(1064030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064031, 1, "145d3d4b453165330adfb14122eaf59ef580c6084dc55b6ca96c685c1f8de0bb")
