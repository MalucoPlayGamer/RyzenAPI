-- Lua provided by RyzenAPI
-- Game: Awakening: The Redleaf Forest Collector's Edition

-- MAIN APPLICATION
addappid(455080)

-- MAIN APP DEPOTS / PACKAGES
addappid(455081, 1, "1dfa622de9694fb9acbdf96c21d2755be6b2b9533c6f2b64c929aea07c1913da")
