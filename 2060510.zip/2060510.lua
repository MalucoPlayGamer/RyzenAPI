-- Lua provided by RyzenAPI
-- Game: Lustful Professor

-- MAIN APPLICATION
addappid(2060510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060511, 1, "545d171e79d88898414cd3c3f226d7379cb527f1fea0b370aa91a807336f5d0f")
