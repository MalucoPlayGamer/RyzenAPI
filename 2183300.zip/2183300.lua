-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2183300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183300,0,"6784bb672c730e98c30658f77d2b5500d4ffbc183052262b34d7f445ff650a1a")
