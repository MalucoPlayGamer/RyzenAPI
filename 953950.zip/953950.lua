-- Lua provided by RyzenAPI 
-- Game: AppID 953950
addappid(953950)
addappid(953951, 1, "baf86f7250844db14b96914dda726ee58a2f236d26c8955099f556d92e98f314")
