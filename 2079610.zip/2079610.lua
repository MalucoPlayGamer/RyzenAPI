-- Lua provided by RyzenAPI
-- Game: Game: Wand Out - A 3D Magical Gay Novel

-- MAIN APPLICATION
addappid(2079610)
addappid(2241470)
-- Game: addappid(2079610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079611, 1, "e3be329fa5276d0bc69b126ace038f0fdf3f86ee93e0728cacf178566aae7d12")
