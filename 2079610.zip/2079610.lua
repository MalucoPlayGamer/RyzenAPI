-- Lua provided by RyzenAPI
-- Game: addappid(2079610)

-- MAIN APPLICATION
addappid(2079610)
addappid(2241470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079611, 1, "e3be329fa5276d0bc69b126ace038f0fdf3f86ee93e0728cacf178566aae7d12")
