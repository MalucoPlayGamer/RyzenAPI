-- Lua provided by RyzenAPI
-- Game: Game: Sword and Shield Idle

-- MAIN APPLICATION
addappid(2882710)
-- Game: addappid(2882710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2882711, 1, "b723be8a80c85650fc4e2ad26e08a24cb64210f5db3fe7bbca8ad5fefab51888")
