-- Lua provided by RyzenAPI
-- Game: Screaming Chicken: Ultimate Showdown Demo

-- MAIN APPLICATION
addappid(1431580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431581, 1, "9f276fe30d9957944ed829f634b57d3025aa43bf57e770df991311aebdc60243")
