-- Lua provided by RyzenAPI
-- Game: Witch of the Space Station

-- MAIN APPLICATION
addappid(2820960)
-- Game: addappid(2820960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820961, 1, "a7c35abd4e3cb9de830b2c9ad692872b1fe885eea151e2f16eb51e31172d5bed")
