-- Lua provided by RyzenAPI
-- Game: 1738170

-- MAIN APPLICATION
addappid(1738170)
-- Game: addappid(1738170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738171, 1, "ddad6178e57ea7fdfbca84be36c972d1e57437de23b3930df2337e9df852e317")
