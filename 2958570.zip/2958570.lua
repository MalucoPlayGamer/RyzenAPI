-- Lua provided by RyzenAPI
-- Game: Guards II: Chaos in Hell

-- MAIN APPLICATION
addappid(2958570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958571, 1, "65379066171458c52c0f59ea9efe5f339865ed43bdc87f587fa8220ab6228f0d")

