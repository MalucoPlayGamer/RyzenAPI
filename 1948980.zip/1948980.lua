-- Lua provided by RyzenAPI
-- Game: Hero's Adventure: Road to Passion

-- MAIN APPLICATION
addappid(1948980)
addappid(2924120)
addappid(3128600)
addappid(3332620)
addappid(3393130)
addappid(3731090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948980,0,"6d0e4344aa93ffe73f7fe7bb24d37aed4024fb6abc21e376e1e551157551e56c")
addappid(1948981,0,"e24e21853fcf27393c4424978740b631785a618ee8356eb9fa135070ade87f1b")
addappid(2924120,0,"1ee9dbc5a2205fa53b8290d7b9444ba5bcbee983bf5c04a92851b83c8edca2ce")
addappid(3332620,0,"ad493ff72c24f4f74d94a5255ec284fcf42f1717927f548cd65dc879a0c97855")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
