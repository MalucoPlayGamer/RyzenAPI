-- Lua provided by RyzenAPI
-- Game: addappid(840260)

-- MAIN APPLICATION
addappid(840260)
addappid(1104720)

-- MAIN APP DEPOTS / PACKAGES
addappid(840261, 1, "68393bb84ae42b9e51f7e6c298ffa0dc73e2d1f16edbd9708c054034cb9ecb3d")
addappid(840262, 1, "6f34cf56cf2307ec7ae28ddb3457b0f16a020f785a3e9705dca7bc6b69c2e4f8")
