-- Lua provided by RyzenAPI
-- Game: Endless World Idle RPG

-- MAIN APPLICATION
addappid(840260)
addappid(1190570)
addappid(1190580)
addappid(1262550)
addappid(1299190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(840261,0,"68393bb84ae42b9e51f7e6c298ffa0dc73e2d1f16edbd9708c054034cb9ecb3d")
addappid(840262,0,"6f34cf56cf2307ec7ae28ddb3457b0f16a020f785a3e9705dca7bc6b69c2e4f8")

