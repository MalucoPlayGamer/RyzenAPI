-- Lua provided by RyzenAPI
-- Game: Game: Wargroove 2

-- MAIN APPLICATION
addappid(1346020)
-- Game: addappid(1346020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346021, 1, "5f6ec8a48cf98fc4daec0cde1de1bebb1a50d9e7e95df64e4b9f2c097f92dd91")
addappid(1346022, 1, "1570e2dba0d57c2752c49ac6f12de3b61e776b03803fcd26ecad3d7659228841")
addappid(1346024, 1, "6525cfae852b7960c27d3e4f2b899855db68707e569fcb1a7e09bd18aef15e9a")
