-- Lua provided by RyzenAPI
-- Game: Yomawari: Lost in the Dark - Mini Art Book

-- MAIN APPLICATION
addappid(2134170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134170,0,"f5570b24be58795f5d2654c98673444df50c0f352ae1fbae8aa41714fb57c7bb")
