-- Lua provided by RyzenAPI 
-- Game: Cosmic Awakening VR
addappid(591990)
addappid(591991, 1, "a752adb7b17195ac8a8cc1541cec3c3cebd649ca7ef9d626fabc132a2a72a61f")
