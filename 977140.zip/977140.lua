-- Lua provided by RyzenAPI
-- Game: 剪刀石头布

-- MAIN APPLICATION
addappid(977140)

-- MAIN APP DEPOTS / PACKAGES
addappid(977141, 1, "e2ea82971b37f5e5111792da3327391d48e431e34ceb43334abc5136d375f5d2")

