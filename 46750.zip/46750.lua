-- Lua provided by RyzenAPI
-- Game: Dark Fall: Lost Souls

-- MAIN APPLICATION
addappid(46750)
addappid(228990)
-- Game: addappid(46750)

-- MAIN APP DEPOTS / PACKAGES
addappid(46751, 1, "e8cc508db87c28f1bc6474319f83d28d38f1ab4f10e7b045e67c9bbef6ed72d2")
