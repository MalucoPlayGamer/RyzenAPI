-- Lua provided by RyzenAPI
-- Game: Polarity

-- MAIN APPLICATION
addappid(315430)

-- MAIN APP DEPOTS / PACKAGES
addappid(315431, 1, "8fe2e26fd6f0d70f2967f07765ebcd7006e1289fd47fc065244d7d0fee29398f")
addappid(456480, 0, "1af23c985df64d43bfa1b52699bd448ebb8bb206c76404da485dad5f1933ec0e")

