-- Lua provided by RyzenAPI
-- Game: Knightica

-- MAIN APPLICATION
addappid(3093400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3093401,0,"fba8be508356b56d8c8a45b64116e7e109f4faea526311d2ea0beed8ea40c52f")

