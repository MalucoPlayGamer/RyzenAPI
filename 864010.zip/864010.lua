-- Lua provided by RyzenAPI
-- Game: Game: Space Force

-- MAIN APPLICATION
addappid(864010)
-- Game: addappid(864010)

-- MAIN APP DEPOTS / PACKAGES
addappid(864011, 1, "111a981f738150fab67f1c21ee3caa80d69d0c67cf302eaebbfac48f03e0a61a")
