-- Lua provided by RyzenAPI
-- Game: Game: AppID 2747780

-- MAIN APPLICATION
addappid(2747780)
-- Game: addappid(2747780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747781, 1, "ac1b8302eac31e44339feed6db4d30900b551714465d0e1cd56146cfb55d3506")
