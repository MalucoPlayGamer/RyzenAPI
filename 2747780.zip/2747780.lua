-- Lua provided by RyzenAPI
-- Game: AppID 2747780

-- MAIN APPLICATION
addappid(2747780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747781, 1, "ac1b8302eac31e44339feed6db4d30900b551714465d0e1cd56146cfb55d3506")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
