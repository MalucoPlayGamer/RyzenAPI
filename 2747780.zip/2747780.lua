-- Lua provided by SkyAPI 
-- Game: AppID 2747780
addappid(2747780)
addappid(2747781, 1, "ac1b8302eac31e44339feed6db4d30900b551714465d0e1cd56146cfb55d3506")
