-- Lua provided by RyzenAPI
-- Game: Lucky Night: Texas Hold'em VR

-- MAIN APPLICATION
addappid(657010)
-- Game: addappid(657010)

-- MAIN APP DEPOTS / PACKAGES
addappid(657011, 1, "684d921e836b9c6e4bbc9065eee5b03abc3a68541ace980bb0c6f7004964b41f")
