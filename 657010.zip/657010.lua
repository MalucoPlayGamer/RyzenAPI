-- Lua provided by RyzenAPI
-- Game: Lucky Night: Texas Hold'em VR

-- MAIN APPLICATION
addappid(657010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(657011, 1, "684d921e836b9c6e4bbc9065eee5b03abc3a68541ace980bb0c6f7004964b41f")

