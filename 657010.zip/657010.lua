-- Lua provided by SkyAPI 
-- Game: Lucky Night: Texas Hold'em VR
addappid(657010)
addappid(657011, 1, "684d921e836b9c6e4bbc9065eee5b03abc3a68541ace980bb0c6f7004964b41f")
