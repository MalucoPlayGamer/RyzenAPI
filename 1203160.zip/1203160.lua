-- Lua provided by RyzenAPI
-- Game: 1203160

-- MAIN APPLICATION
addappid(1203160)
-- Game: addappid(1203160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203161, 1, "db1e18e684139aa2ab3971cf85bd7526dd91614eb4d737d124d75161b9f32a14")
