-- Lua provided by RyzenAPI 
-- Game: The Zebra-Man!
addappid(2055360)
addappid(2055361, 1, "19f342a8497bf28de6b8fbc0326f90065ed36bfc379926bc1978f2dfc673857c")
