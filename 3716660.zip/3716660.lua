-- Lua provided by RyzenAPI
-- Game: addappid(3716660)

-- MAIN APPLICATION
addappid(3716660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3716661, 1, "1a99c2bc0fe4bab3a66adfd3c52ec7fc4da2bfe6e55d2c6911ec17c71508c233")
