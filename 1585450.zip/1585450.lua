-- Lua provided by RyzenAPI
-- Game: Furry Shakespeare: To Date Or Not To Date Spooky Cat Girls?

-- MAIN APPLICATION
addappid(1585450)
addappid(2480520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1585451, 1, "cfc6b7d91d24a836c60dc442f2066efa966b7efd3104211acfaaaffb7acfbba5")
addappid(1585452, 1, "2fbcb4cdb75bff977cac9ca02008177d9099a6382f237112c57181a35e7e1307")

