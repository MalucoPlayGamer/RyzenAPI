-- Lua provided by RyzenAPI
-- Game: Game: SPACE MOUSE 35th Anniversary edition

-- MAIN APPLICATION
addappid(546330)
-- Game: addappid(546330)

-- MAIN APP DEPOTS / PACKAGES
addappid(546331, 1, "25867eb0059cc8fc71d45023524b78f4db776ecc62e8cba404145fb6cd0e794d")
