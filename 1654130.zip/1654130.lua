-- Lua provided by RyzenAPI
-- Game: 孙美琪疑案:雨儿胡同

-- MAIN APPLICATION
addappid(1654130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654131, 1, "d8209e45e9aae395d72ffc3f326e06890aabd043d6973c409d4678faac546233")
