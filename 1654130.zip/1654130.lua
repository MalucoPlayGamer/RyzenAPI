-- Lua provided by RyzenAPI
-- Game: 孙美琪疑案:雨儿胡同

-- MAIN APPLICATION
addappid(1654130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654131, 1, "d8209e45e9aae395d72ffc3f326e06890aabd043d6973c409d4678faac546233")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
