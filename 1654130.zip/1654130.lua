-- Lua provided by RyzenAPI
-- Game: 1654130

-- MAIN APPLICATION
addappid(1654130)
-- Game: addappid(1654130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654131, 1, "d8209e45e9aae395d72ffc3f326e06890aabd043d6973c409d4678faac546233")
