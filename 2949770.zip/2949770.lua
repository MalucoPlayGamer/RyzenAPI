-- Lua provided by RyzenAPI
-- Game: 琉隐九绝 Demo

-- MAIN APPLICATION
addappid(2949770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949771, 1, "fa59813b4eb1f8c0c87dc670968abe8993b3efcb9b70b4323c6fe0b47c46212d")

