-- Lua provided by RyzenAPI 
-- Game: Few Nights More
addappid(1491200)
addappid(1491201, 1, "a1e52640be111ff3d970af5b8fd52de01a66eb27f1ac31f4f0daca13453cd24b")
