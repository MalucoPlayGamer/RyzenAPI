-- Lua provided by SkyAPI 
-- Game: Vaporwave World
addappid(1243560)
addappid(1243561, 1, "d46ddab8daf4b2a659d6291691fe2d5f506b294b0df395965600b2af8614393c")
