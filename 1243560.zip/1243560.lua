-- Lua provided by RyzenAPI
-- Game: Vaporwave World

-- MAIN APPLICATION
addappid(1243560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243561, 1, "d46ddab8daf4b2a659d6291691fe2d5f506b294b0df395965600b2af8614393c")

