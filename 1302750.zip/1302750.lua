-- Lua provided by RyzenAPI
-- Game: 大明王朝1789 | Ming dynasty 1789

-- MAIN APPLICATION
addappid(1302750)
-- Game: addappid(1302750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302751, 1, "c7f0b484c4e7832f89a174a5180641dd573b4f4c05561b6fe0e686b59d15d944")
