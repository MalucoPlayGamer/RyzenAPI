-- Lua provided by RyzenAPI
-- Game: Idle Trillionaire

-- MAIN APPLICATION
addappid(2753100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753101, 1, "894e229332c2f2ef62705259877f837eb9d847091b13eedea0734cb144eb164b")
