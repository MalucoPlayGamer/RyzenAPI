-- Lua provided by RyzenAPI
-- Game: Game: Dead-End City Blues OD Edition

-- MAIN APPLICATION
addappid(2756380)
-- Game: addappid(2756380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756381, 1, "f556477d2d52f0967d05b9a9bc8fe4f10ed29415b745c4642ae7000778d07a19")
