-- Lua provided by RyzenAPI
-- Game: addappid(1397470)

-- MAIN APPLICATION
addappid(1397470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397471, 1, "deb7a26b08d4c3901a0ce6f5d8e5be415bdcabfa972d6c1bc9c32b1bfb393f56")
