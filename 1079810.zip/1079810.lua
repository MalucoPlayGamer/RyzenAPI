-- Lua provided by RyzenAPI 
-- Game: KreisReise
addappid(1079810)
addappid(1079811, 1, "b7040b5e196c2c966af7c4d69ed6ea74a8b8ea307a0b0e234152108b0ebdb3bc")
