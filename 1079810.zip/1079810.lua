-- Lua provided by RyzenAPI
-- Game: KreisReise

-- MAIN APPLICATION
addappid(1079810)
-- Game: addappid(1079810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079811, 1, "b7040b5e196c2c966af7c4d69ed6ea74a8b8ea307a0b0e234152108b0ebdb3bc")
