-- Lua provided by RyzenAPI
-- Game: AppID 1519620

-- MAIN APPLICATION
addappid(1519620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519621, 1, "81c789b91a63397debf2e8e587d8deb82b1c6c60ee9a5f9e2e9b1a4d7b80c5a7")

