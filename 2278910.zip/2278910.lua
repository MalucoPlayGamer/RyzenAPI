-- Lua provided by RyzenAPI
-- Game: addappid(2278910)

-- MAIN APPLICATION
addappid(2278910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278911, 1, "4aaaf0c8f4b824be539ccf633694f5fd9bc1e9c2dc1278c11d95b9c5e60351d2")
