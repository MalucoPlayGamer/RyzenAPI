-- Lua provided by RyzenAPI
-- Game: OneShot

-- MAIN APPLICATION
addappid(420530)
-- Game: addappid(420530)

-- MAIN APP DEPOTS / PACKAGES
addappid(420531, 1, "e48d0eabf484554b966a4670897091a406599c2a619282a741e68a6c38706463")
addappid(420532, 1, "7fcf74dcd883c19603f1c565c0a46ea557247cac434fde7b35bdba37f9d4aae2")
addappid(420533, 1, "051438a98e0c4f8b67ec46b131e7cbce3ecc5ee50a58f1ede27a35f0c83e0ef2")
addappid(420534, 1, "96865a4ce094f33ce72551bace14ada0bf7a233a461fa43633f697c49eac7ed5")
addappid(420535, 1, "5779eef45c8dcdcb63801f8cdb992c4cbe83620196e43b626f7b3b94b4282aaa")
