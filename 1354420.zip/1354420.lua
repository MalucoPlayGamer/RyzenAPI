-- Lua provided by RyzenAPI
-- Game: The protectors of Deya

-- MAIN APPLICATION
addappid(1354420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1354421, 1, "231edc47193415bd4d0485bc5f70844e5d0f3376570315a0a5bb2b22ffa0de95")
