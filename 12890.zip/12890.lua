-- Lua provided by RyzenAPI
-- Game: Game: Operation Flashpoint: Dragon Rising Demo

-- MAIN APPLICATION
addappid(12890)
-- Game: addappid(12890)

-- MAIN APP DEPOTS / PACKAGES
addappid(12891, 1, "ac7021c88b482a930290dc856bac479b5aef37f8719c20d1b398457e072a639a")
