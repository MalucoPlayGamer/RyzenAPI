-- Lua provided by RyzenAPI
-- Game: 678450

-- MAIN APPLICATION
addappid(678450)
-- Game: addappid(678450)

-- MAIN APP DEPOTS / PACKAGES
addappid(678451, 1, "ae72c5a0f7b16808a4330cf234e82246f53e7077f1ce065ca2cde3c7f5a7e191")
