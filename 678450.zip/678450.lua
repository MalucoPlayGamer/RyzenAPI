-- Lua provided by RyzenAPI
-- Game: Full-On Paintball

-- MAIN APPLICATION
addappid(678450)

-- MAIN APP DEPOTS / PACKAGES
addappid(678451, 1, "ae72c5a0f7b16808a4330cf234e82246f53e7077f1ce065ca2cde3c7f5a7e191")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(862400)
addappid(862401)
addappid(1024870)
addappid(1034640)
