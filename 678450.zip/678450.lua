-- Lua provided by SkyAPI 
-- Game: Full-On Paintball
addappid(678450)
addappid(678451, 1, "ae72c5a0f7b16808a4330cf234e82246f53e7077f1ce065ca2cde3c7f5a7e191")
