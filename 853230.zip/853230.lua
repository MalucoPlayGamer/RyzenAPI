-- Lua provided by RyzenAPI
-- Game: 853230

-- MAIN APPLICATION
addappid(853230)
addappid(853231)
-- Game: addappid(853230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983,0,"77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b")
