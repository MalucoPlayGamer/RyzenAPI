-- Lua provided by RyzenAPI
-- Game: AppID 312800

-- MAIN APPLICATION
addappid(312800)
-- Game: addappid(312800)

-- MAIN APP DEPOTS / PACKAGES
addappid(312801, 1, "cf7f59f8b43f5000e4ddb907e2b0d79cf60b19fcc2dea5f7bd2546d2b94abcb6")
