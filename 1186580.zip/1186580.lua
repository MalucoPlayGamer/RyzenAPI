-- Lua provided by RyzenAPI 
-- Game: AppID 1186580
addappid(1186580)
addappid(1186581, 1, "33a107ed2894acbe1cc19a3cb0040b565c837020266582f30fe3129ece7556e6")
