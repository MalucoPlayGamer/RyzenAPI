-- Lua provided by RyzenAPI
-- Game: New York Mysteries: The Outbreak

-- MAIN APPLICATION
addappid(1186580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186581, 1, "33a107ed2894acbe1cc19a3cb0040b565c837020266582f30fe3129ece7556e6")
