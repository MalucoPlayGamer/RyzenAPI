-- Lua provided by RyzenAPI
-- Game: AppID 713380

-- MAIN APPLICATION
addappid(713380)

-- MAIN APP DEPOTS / PACKAGES
addappid(713381, 1, "4d1f13bb8bf662b6871a6adfcf6c9bcda34e4a599c673f79aa5257779a6c2a7a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(815020)
addappid(1122530)
