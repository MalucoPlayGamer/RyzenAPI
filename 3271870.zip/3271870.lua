-- Lua provided by RyzenAPI
-- Game: Biohazard: Siberia

-- MAIN APPLICATION
addappid(3271870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271873,0,"17595c42fcda49f9a7746735939862d21573bcd6a140d78284fdbf8b71003bb6")

