-- Lua provided by RyzenAPI
-- Game: Ultimate Arena

-- MAIN APPLICATION
addappid(385240)

-- MAIN APP DEPOTS / PACKAGES
addappid(385241, 1, "114b725c8aa63ea4edc378790c5fe19b3364eaea4babc6f0c91ff68caae26ff1")

