-- Lua provided by RyzenAPI
-- Game: Ultimate Arena

-- MAIN APPLICATION
addappid(385240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(385241, 1, "114b725c8aa63ea4edc378790c5fe19b3364eaea4babc6f0c91ff68caae26ff1")

