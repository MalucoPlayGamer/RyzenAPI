-- Lua provided by RyzenAPI
-- Game: Mazey Village

-- MAIN APPLICATION
addappid(1766240) -- Mazey Village

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1766241, 1, "71d91f8c39df475fc489c1d281fafa35ffb1292a6cec532093f9c5c35cef9c9e") -- Depot 1766241

