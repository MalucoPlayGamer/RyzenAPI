-- Lua provided by RyzenAPI
-- Game: addappid(2118810)

-- MAIN APPLICATION
addappid(2118810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118811, 1, "fe842fa8b3b9df7aad5d259d932cdaa24ecc7b4336b1e4370d1de3ba806c7b85")
