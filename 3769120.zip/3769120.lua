-- Lua provided by RyzenAPI
-- Game: Game: Final Stand

-- MAIN APPLICATION
addappid(3769120)
-- Game: addappid(3769120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3769121, 1, "0d84d01134c49607664f642a54a342c3acc5b921f14316324a67d100c8cd8955")
