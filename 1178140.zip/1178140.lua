-- Lua provided by RyzenAPI
-- Game: AppID 1178140

-- MAIN APPLICATION
addappid(1178140)
-- Game: addappid(1178140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178141, 1, "516c851f081e8c83e99be719e84c1e000eb2fdbc7aff126b985e92b4889f8825")
