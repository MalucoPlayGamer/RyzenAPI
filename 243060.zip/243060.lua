-- Lua provided by RyzenAPI
-- Game: Game: Urban Chaos

-- MAIN APPLICATION
addappid(243060)
-- Game: addappid(243060)

-- MAIN APP DEPOTS / PACKAGES
addappid(243061, 1, "b0bde965d6a14e84fc6b2cdb3ef3b95b2101d5878b2cec83285580e045904460")
