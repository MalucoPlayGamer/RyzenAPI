-- Lua provided by RyzenAPI
-- Game: addappid(235720)

-- MAIN APPLICATION
addappid(235720)

-- MAIN APP DEPOTS / PACKAGES
addappid(235721, 1, "8f0fdff7a373d0f2bca2b60aa369671c1c184ca744893ac2015a7dbde4caf1ba")
addappid(235722, 1, "a6e3bbc52476d1411d6a2acbeef84ca4f3d8036f5ae206912fb2aae4dc1ac5e9")
