-- Lua provided by RyzenAPI
-- Game: Game: AppID 2475190

-- MAIN APPLICATION
addappid(2475190)
-- Game: addappid(2475190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475191, 1, "8b707da0ce4233b185503004814a761416bafe93c3e133594e9e9e51c9b648cd")
