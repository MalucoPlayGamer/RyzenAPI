-- Lua provided by SkyAPI 
-- Game: AppID 2475190
addappid(2475190)
addappid(2475191, 1, "8b707da0ce4233b185503004814a761416bafe93c3e133594e9e9e51c9b648cd")
