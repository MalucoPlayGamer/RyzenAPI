-- Lua provided by RyzenAPI
-- Game: Save Twiks

-- MAIN APPLICATION
addappid(2811080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811081, 1, "22c29be6a5c868efa9322c890362df4b560db31adec2393ee83c2e26fd58923a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
