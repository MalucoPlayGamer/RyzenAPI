-- Lua provided by RyzenAPI
-- Game: Game: Save Twiks

-- MAIN APPLICATION
addappid(2811080)
-- Game: addappid(2811080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811081, 1, "22c29be6a5c868efa9322c890362df4b560db31adec2393ee83c2e26fd58923a")
