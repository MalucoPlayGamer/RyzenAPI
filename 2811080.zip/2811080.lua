-- Lua provided by SkyAPI 
-- Game: Save Twiks
addappid(2811080)
addappid(2811081, 1, "22c29be6a5c868efa9322c890362df4b560db31adec2393ee83c2e26fd58923a")
