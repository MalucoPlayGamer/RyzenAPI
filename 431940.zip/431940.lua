-- Lua provided by RyzenAPI
-- Game: Wildfire

-- MAIN APPLICATION
addappid(431940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(431941, 1, "09fb248748a867ba443f2cb385ab73eda2b28c0db118ccdadf414582881f41a4")
