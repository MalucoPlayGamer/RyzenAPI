-- Lua provided by RyzenAPI
-- Game: Steam and Metal

-- MAIN APPLICATION
addappid(335010)

-- MAIN APP DEPOTS / PACKAGES
addappid(335011, 1, "c022ad05d0b1c6342a031a4a1c4fa7d130cad7bdaf861ccd66e279c8c5926336")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
