-- Lua provided by RyzenAPI
-- Game: Game: Steam and Metal

-- MAIN APPLICATION
addappid(335010)
-- Game: addappid(335010)

-- MAIN APP DEPOTS / PACKAGES
addappid(335011, 1, "c022ad05d0b1c6342a031a4a1c4fa7d130cad7bdaf861ccd66e279c8c5926336")
