-- Lua provided by RyzenAPI
-- Game: Game: Trash TV

-- MAIN APPLICATION
addappid(343840)
-- Game: addappid(343840)

-- MAIN APP DEPOTS / PACKAGES
addappid(343841, 1, "f38fa2eea98c3be0fa9d0c84f9796d200e6de437f2ddc2afeaba8f370e45a700")
