-- Lua provided by RyzenAPI
-- Game: Trash TV

-- MAIN APPLICATION
addappid(343840)

-- MAIN APP DEPOTS / PACKAGES
addappid(343841, 1, "f38fa2eea98c3be0fa9d0c84f9796d200e6de437f2ddc2afeaba8f370e45a700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
