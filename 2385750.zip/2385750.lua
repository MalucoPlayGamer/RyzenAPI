-- Lua provided by RyzenAPI
-- Game: Mega Man Battle Network Legacy Collection Original Soundtrack

-- MAIN APPLICATION
addappid(2385750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385751, 1, "fb589e1ea2ebc9ed6c36d1e002fd85c7aa0bc9cf7dd1781974006c737963b6ca")
addappid(2385752, 1, "62a3ac77ef20e4f220ae5ce0c7309d483d08a02fd8516085115658b58b045d73")
addappid(2385753, 1, "efb6d48b33cef3305a338df678424f64856ddd31e50531325efb125ecba3e76c")
addappid(2392110, 0, "094f72851571d1fb008b0a862aedf99d4df072adc6eb8d97a43c4f98ee222b6b")
addappid(2392111, 0, "39ef58e0f9d3e5504cfac592326f97efc57e96eaba5b5ed826c746eef95636d7")
addappid(2392112, 0, "a6d54f192a49310a95f0d50eb8b36eb7a9f315b6234fd79417ee7ae225bc9d03")

