-- Lua provided by RyzenAPI
-- Game: Puppet Master Playtest

-- MAIN APPLICATION
addappid(2019940)
-- Game: addappid(2019940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019941, 1, "963e6ef2e02246cf68968eb0f9c7ce2f1108195dada21930613b35893957a25a")
