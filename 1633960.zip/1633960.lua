-- Lua provided by RyzenAPI
-- Game: addappid(1633960)

-- MAIN APPLICATION
addappid(1633960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633960,0,"f92a7a008369b116abe0acdfdabe1c03c4b538af01366090d3adf40b5d64c615")
