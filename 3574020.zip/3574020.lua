-- Lua provided by RyzenAPI
-- Game: Ramen Simulator

-- MAIN APPLICATION
addappid(3574020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3574021,0,"fefe39565161808f51b29ed9ecbada14e0af86a6b1ac9e3b34a2d2e0462ad058")

