-- Lua provided by RyzenAPI
-- Game: AppID 477730

-- MAIN APPLICATION
addappid(477730)

-- MAIN APP DEPOTS / PACKAGES
addappid(477731, 1, "925d83ddad5ca30e461567cb1cff2eafe81182e68053508ca17c3c5e06d59edc")
