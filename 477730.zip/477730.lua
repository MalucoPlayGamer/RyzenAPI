-- Lua provided by RyzenAPI
-- Game: AppID 477730

-- MAIN APPLICATION
addappid(477730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(477731, 1, "925d83ddad5ca30e461567cb1cff2eafe81182e68053508ca17c3c5e06d59edc")

