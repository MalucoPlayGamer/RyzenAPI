-- Lua provided by RyzenAPI 
-- Game: Morningstar: Descent to Deadrock
addappid(339130)
addappid(339131, 1, "439477026dfad0142d01846bc5470cf541ee7ec8791027fe5d96a54f69936ae6")
addappid(339132, 1, "f09407bbdc5865ad6988706537e2275d227ffb8018e98d030954df805d874d91")
addappid(339133, 1, "9b2bd1cf82e8b725508aa477b877bd1a1a901e3c263d8270c1a34ac35755aad6")
