-- Lua provided by RyzenAPI
-- Game: 2171550

-- MAIN APPLICATION
addappid(2171550)
-- Game: addappid(2171550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171551, 1, "3e033228545e2a01581bf2533e64b768f33cd24416e4aab8f3d6c3a69bfb1f27")
