-- Lua provided by RyzenAPI
-- Game: Crown Gambit - Digital Artbook

-- MAIN APPLICATION
addappid(3795890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3795890,0,"a5cf72b9230970735ce09f74d72650ca4f408b26dd5c83af6b0fbf723ffbc303")
