-- Lua provided by RyzenAPI
-- Game: Cricket: Jae's Really Peculiar Game

-- MAIN APPLICATION
addappid(1381520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381521, 1, "b6f3379afc94e4d142123a0e25fd076dd675762ca0bd34299f96cf74204820b1")

