-- Lua provided by RyzenAPI
-- Game: Cricket: Jae's Really Peculiar Game

-- MAIN APPLICATION
addappid(1381520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1381521, 1, "b6f3379afc94e4d142123a0e25fd076dd675762ca0bd34299f96cf74204820b1")

