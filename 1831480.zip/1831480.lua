-- Lua provided by RyzenAPI
-- Game: Sandbox World

-- MAIN APPLICATION
addappid(1831480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1831481, 1, "9b8d50d661b01fc940fe30df39ca6e2c929797453b55d07f574efff3570c8817")

