-- Lua provided by RyzenAPI
-- Game: Sandbox World

-- MAIN APPLICATION
addappid(1831480)
-- Game: addappid(1831480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831481, 1, "9b8d50d661b01fc940fe30df39ca6e2c929797453b55d07f574efff3570c8817")
