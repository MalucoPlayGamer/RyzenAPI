-- Lua provided by RyzenAPI
-- Game: Flat Worlds

-- MAIN APPLICATION
addappid(703490)

-- MAIN APP DEPOTS / PACKAGES
addappid(703491,0,"6370565d4c45ecdf3da75dd958f28e2594172867001d4e0933e8a1087ec2f283")

