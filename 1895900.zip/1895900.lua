-- Lua provided by RyzenAPI
-- Game: 1348 Ex Voto

-- MAIN APPLICATION
addappid(1895900)
addappid(4008520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1895901, 1, "bb52ef46cac6e7a399bcd20c95934f9d94a7039b8a1c03fe3c21ebe2eb5c5c1e")