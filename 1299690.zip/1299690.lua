-- Lua provided by SkyAPI 
-- Game: Gori: Cuddly Carnage
addappid(1299690)
addappid(1299691, 1, "e98ac5c23950700f14844776585c217a0931a6f1c7b9a60f2b931129107d80ff")
