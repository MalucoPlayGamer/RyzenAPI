-- Lua provided by RyzenAPI
-- Game: Gori: Cuddly Carnage

-- MAIN APPLICATION
addappid(1299690)
addappid(2658940)
addappid(3035200)
addappid(3035210)
addappid(3035220)
addappid(3035230)
addappid(3035240)
addappid(3035260)
addappid(3075820)
addappid(3142680)
addappid(3142690)
addappid(3142700)
addappid(3145920)
addappid(3228010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1299691, 1, "e98ac5c23950700f14844776585c217a0931a6f1c7b9a60f2b931129107d80ff")

