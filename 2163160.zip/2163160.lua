-- Lua provided by RyzenAPI
-- Game: addappid(2163160)

-- MAIN APPLICATION
addappid(2163160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163161, 1, "edecdcddaaec4d0901db9c1eac3078a5c004e0a0b561547441ff542a1109d861")
