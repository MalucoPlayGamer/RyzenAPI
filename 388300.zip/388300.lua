-- Lua provided by RyzenAPI
-- Game: Just Alone

-- MAIN APPLICATION
addappid(388300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(388301, 1, "1fc49b9af5ea5f99888718fe6e362af0c32a1092d0858fa1747aa1f971e59484")
