-- Lua provided by RyzenAPI
-- Game: Claws of Soria

-- MAIN APP DEPOTS / PACKAGES
addappid(4054650, 1, "8cea8678181169ba910092a3ffe0305daecbfbe16c07c208346dec9ebc613cc3") -- Claws of Soria
addappid(4054651, 1, "25e873528a9abfc9eea415d4a9d9ae0f3f43c3d84d9c136880c1976d506c4f44") -- Depot 4054651
addappid(4054652, 1, "f683b529a5f89c693863409c752b100198757e7f6a90800d7c09533f7fc84b0d") -- Depot 4054652
