-- Lua provided by RyzenAPI
-- Game: Game: ENDLOOP

-- MAIN APPLICATION
addappid(2862350)
-- Game: addappid(2862350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862351, 1, "ba89fd030b311fb91c091495afd75b4008654cd4ff413abaa8acbacfb2162dc4")
