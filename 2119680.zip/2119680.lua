-- Lua provided by RyzenAPI
-- Game: Game: Tropical Resort Story

-- MAIN APPLICATION
addappid(2119680)
-- Game: addappid(2119680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119681, 1, "13acc917a0dd5ceb58194c3d3e182d3af3a41c57f23cdb444a76a2ecf3ef15c6")
