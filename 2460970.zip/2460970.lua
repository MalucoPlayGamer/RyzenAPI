-- Lua provided by RyzenAPI
-- Game: Pathogen Purge - Tower Defense

-- MAIN APPLICATION
addappid(2460970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2460971, 1, "faf64fef12e1c122a75401d29b5729022ac8594d5cda06d0691d0b31b66a4b2d")
