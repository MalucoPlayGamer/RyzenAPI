-- 4582080's Lua and Manifest Created by Hubcap Manifest
-- Goal Idle
-- Created: July 15, 2026 at 16:27:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4582080, 1, "5486ddaf1aa52626875d74b972a84d4c76582d508d47e969bf4437f5adf92f73") -- Goal Idle
-- MAIN APP DEPOTS
addappid(4582081, 1, "b90366de80fc203b8401fd31bd9b0d813de47e84ac0e80f781e5bd6474dd357c") -- Depot 4582081
setManifestid(4582081, "8063952305692728662", 447157872)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4876220) -- Goal Idle - Supporter Pack