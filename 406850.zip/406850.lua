-- Lua provided by RyzenAPI
-- Game: Game: AppID 406850

-- MAIN APPLICATION
addappid(406850)
addappid(501510)
-- Game: addappid(406850)

-- MAIN APP DEPOTS / PACKAGES
addappid(406851, 1, "c0667bc91ce570fff4e02a81826a8f1e931b97cf5ea5234270aa0c68fa3c5af2")
addappid(406852, 1, "1940222afc4a8f4df25d333cc71ae0033cde16536adefe3329962afa41087597")
addappid(406853, 1, "33e933ebfa44d962c5e8b40a68091e438a71448b6511e2f29b3072e577e0da2e")
