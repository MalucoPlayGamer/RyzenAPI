-- Lua provided by RyzenAPI
-- Game: 1491510

-- MAIN APPLICATION
addappid(1491510)
addappid(1881220)
-- Game: addappid(1491510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491511, 1, "07ff1bb5eb385c757d0f05fedf3e6ad4208948fa42d188da9fa41278c2ca17eb")
