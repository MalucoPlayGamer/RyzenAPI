-- Lua provided by RyzenAPI 
-- Game: Bleed 2
addappid(396350)
addappid(396351, 1, "5d20e71a420fe46e0a179b2c729718eaba9c58d44b0fae6fc1a26de085a349af")
addappid(396352, 1, "9793e552470c38bb6a861c5d15635563b247abb7cdab14371908b2c610b47dcf")
addappid(396353, 1, "1bc98e71f1fe994ef312ff63d19d9481c8d744e3e3a557095b36f8e624edd0c6")
