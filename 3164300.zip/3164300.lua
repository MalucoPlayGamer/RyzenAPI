-- Lua provided by RyzenAPI
-- Game: AppID 3164300

-- MAIN APPLICATION
addappid(3164300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164301, 1, "fcd3a0eebf0dfa5c4f7d904df450ed9ba336f4a6bcf7546754eb5cafdca326de")

