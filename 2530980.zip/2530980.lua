-- Lua provided by RyzenAPI
-- Game: Tales of Graces f Remastered

-- MAIN APPLICATION
addappid(2530980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530981, 1, "a93f851271a22d8fd77c25f7ab3f895e3a9d638ead344dce1379db3b9c287f31")
addappid(2867770, 0, "8494db845bd40739acc2ef44d165a27f6e6b7c3704d7c76c393ac4cc5a2e14e9")
addappid(3030040, 0, "567db2ea52f3117ea696a99d34885266103b1e6c94a2386b44b395fea1362e5b")
addappid(3030050, 0, "56d222937ef2f954ac3756fa8cbb68722c2a570ded1fb9c8e0702ac1bc27cda9")
addappid(3030060, 0, "b6ddc550c380151b3660fa370b4827eabce743c68e17ea386bcf71d307a21c3a")
addappid(3030070, 0, "08de21488414c17cab1796a951079e09111a80e4204fecc8b711e34739dcf3b2")
addappid(3030080, 0, "84956132289ea4731f59ad71d63c28e47cb673e51b005121d36490c9ad59c6fc")
addappid(3030090, 0, "ac138dee693e850bc7f30c5040275fe6407252458519fca689dbfd71d627aa0b")
addappid(3030100, 0, "d7c288a9392822bc42ff451f5ec9373e868c925907501fde446b75ea3795af75")
addappid(3030110, 0, "9733847a96f124ec76f92ba93964435f83786d5f35d93829c5abcd1088ba560a")
addappid(3030120, 0, "511e7e46ad335906712799cdc6d166533623b2fcb692239e73e74a29024fe31f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3036400)
