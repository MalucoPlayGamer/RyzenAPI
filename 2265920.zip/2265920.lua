-- Lua provided by RyzenAPI
-- Game: Castle of Blackwater

-- MAIN APPLICATION
addappid(2265920)
-- Game: addappid(2265920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265921, 1, "86f7844137c9ae7536ba0515df6abfa1dba39c25f5786e4e24bcfb79349b2e44")
