-- Lua provided by RyzenAPI
-- Game: addappid(3472850)

-- MAIN APPLICATION
addappid(3472850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3472851, 1, "72188682cb021cae1728d33a2615ffc905c5e2a3c354e39363ecbefa85b105f4")
