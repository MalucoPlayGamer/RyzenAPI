-- Lua provided by RyzenAPI
-- Game: Game: Random Blacksmith Game

-- MAIN APPLICATION
addappid(1604710)
-- Game: addappid(1604710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604711, 1, "21addbe86c1c71fd3bd6a01eb0fd94e73bc07211c361c052e6d001a7dd3edac7")
