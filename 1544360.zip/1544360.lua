-- Lua provided by RyzenAPI
-- Game: LEGO® Builder's Journey

-- MAIN APPLICATION
addappid(1544360)
-- Game: addappid(1544360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544361, 1, "f68c8ea838a50a342ba77fc9816a952a46f6a54a86d821c3adb661e4b9455868")
