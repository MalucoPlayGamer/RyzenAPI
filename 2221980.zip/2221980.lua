-- Lua provided by RyzenAPI
-- Game: addappid(2221980)

-- MAIN APPLICATION
addappid(2221980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221981, 1, "1992fefc2f1e55936500b4ab43319ca9c808c9293587bfada9971cf2a25f068f")
