-- Lua provided by RyzenAPI
-- Game: Game: VANQUISH

-- MAIN APPLICATION
addappid(2076820)
-- Game: addappid(2076820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076821, 1, "9d783c55f3a538d50d64e23293aa91f7f9f4364bf417b2546103d85019dd39b9")
