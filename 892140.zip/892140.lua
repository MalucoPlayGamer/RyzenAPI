-- Lua provided by RyzenAPI
-- Game: 892140

-- MAIN APPLICATION
addappid(892140)
-- Game: addappid(892140)

-- MAIN APP DEPOTS / PACKAGES
addappid(892141, 1, "f7bf9da811830c4ca0f3d2e98cd7c696a71863631a8cd6b3ec4ca4b5890756f5")
