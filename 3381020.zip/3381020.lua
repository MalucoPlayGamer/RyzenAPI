-- Lua provided by RyzenAPI
-- Game: Shapelab 2025 Upgrade

-- MAIN APPLICATION
addappid(3381020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381021, 1, "1fb8580c8fbcbc1343c0537f217290f278963c70fe5d15a23c4b683aeacd1d74")

