-- Lua provided by RyzenAPI
-- Game: Game: Turbo Pug DX

-- MAIN APPLICATION
addappid(513780)
addappid(533810)
-- Game: addappid(513780)

-- MAIN APP DEPOTS / PACKAGES
addappid(513781, 1, "1b0c5136bc6c205b4b80ab9609b6d9a639fb0c496c48def05935290e3cb574dc")
