-- Lua provided by RyzenAPI
-- Game: The Quintessential Quintuplets - Five Memories Spent With You

-- MAIN APPLICATION
addappid(2507620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507621, 1, "d6364de979b39ce493b884cc5f3d1b330ed52df9c8189b3a4c79fc20da39180e")
