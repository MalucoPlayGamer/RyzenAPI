-- Lua provided by RyzenAPI
-- Game: Game: Project 1337: The Well

-- MAIN APPLICATION
addappid(3375970)
-- Game: addappid(3375970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3375971, 1, "c593c7fd5da24923ff8255e1e7f54d46a15bcd76935c59e4d36d32bb28a9c03e")
