-- Lua provided by RyzenAPI
-- Game: Nash Racing: 70 seconds left

-- MAIN APPLICATION
addappid(2257450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257451, 1, "fa5dbbf2fe15b5b4a6da543788e85eb730c91306582196218372cdfa7b860228")

