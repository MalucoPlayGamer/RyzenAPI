-- Lua provided by RyzenAPI
-- Game: addappid(2928560)

-- MAIN APPLICATION
addappid(2928560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928560,0,"bbf115b23fcadf411100fd4eaaa9a3a0a4d56c7a8f68a207d36330120954e0a3")
