-- Lua provided by RyzenAPI
-- Game: Counter-Strike Nexon

-- MAIN APPLICATION
addappid(273110)
addappid(381150)
addappid(381151)
addappid(381152)
addappid(404240)
addappid(429450)
addappid(451430)
addappid(453590)
addappid(3324660)
addappid(3324670)
addappid(3324680)
addappid(3324690)

-- MAIN APP DEPOTS / PACKAGES
addappid(273111,0,"1a055548bc66ae731b5770c9ebc03f8d8cf9476db8677070cec5b1f1ead9cd3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
