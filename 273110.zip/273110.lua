-- Lua provided by RyzenAPI
-- Game: addappid(273110)

-- MAIN APPLICATION
addappid(273110)

-- MAIN APP DEPOTS / PACKAGES
addappid(273111, 1, "1a055548bc66ae731b5770c9ebc03f8d8cf9476db8677070cec5b1f1ead9cd3d")
