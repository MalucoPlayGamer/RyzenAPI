-- Lua provided by RyzenAPI
-- Game: Furquest

-- MAIN APPLICATION
addappid(1740230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1740232,0,"58d9ddff6efc5ad59c87db708849e42eb6a90c55090cb2f4410709739bbdda17")

