-- Lua provided by RyzenAPI
-- Game: addappid(1740230)

-- MAIN APPLICATION
addappid(1740230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740232,0,"58d9ddff6efc5ad59c87db708849e42eb6a90c55090cb2f4410709739bbdda17")
