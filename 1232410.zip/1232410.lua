-- Lua provided by RyzenAPI
-- Game: 孙美琪疑案 第二季

-- MAIN APPLICATION
addappid(1232410)
-- Game: addappid(1232410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232411, 1, "5fe9a83e701af274c85ee3c2a51d9b5f85477bb3c4a01bab8a8497daae56fb6c")
