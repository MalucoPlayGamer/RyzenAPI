-- Lua provided by RyzenAPI
-- Game: Big Rumble Boxing: Creed Champions

-- MAIN APPLICATION
addappid(1278170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278171, 1, "4d3958d027a0ef43a140d426a473c1e64d9a2b9b46ad66dc36d1e2b650c3061f")
