-- Lua provided by RyzenAPI
-- Game: Big Rumble Boxing: Creed Champions

-- MAIN APPLICATION
addappid(1278170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1278171, 1, "4d3958d027a0ef43a140d426a473c1e64d9a2b9b46ad66dc36d1e2b650c3061f")

