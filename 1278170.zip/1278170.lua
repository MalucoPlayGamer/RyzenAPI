-- Lua provided by SkyAPI 
-- Game: Big Rumble Boxing: Creed Champions
addappid(1278170)
addappid(1278171, 1, "4d3958d027a0ef43a140d426a473c1e64d9a2b9b46ad66dc36d1e2b650c3061f")
