-- Lua provided by RyzenAPI
-- Game: Dreamin' Her - 僕は、彼女の夢を見る。-

-- MAIN APPLICATION
addappid(1920540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920541, 1, "6255c82a4b0c67b25252049999fedd3262c6cb76273f0cc23dfa5e9dfe37866c")
