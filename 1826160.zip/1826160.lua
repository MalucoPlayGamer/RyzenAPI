-- Lua provided by RyzenAPI
-- Game: 1826160

-- MAIN APPLICATION
addappid(1826160)
-- Game: addappid(1826160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826162,0,"151d4b8e250d96a3fe3b40f8ae315405c0831c7613f32ee7f3e6b91ff2b12469")
