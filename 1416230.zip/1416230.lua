-- Lua provided by RyzenAPI
-- Game: Panzer Knights

-- MAIN APPLICATION
addappid(1416230)
addappid(1820200)
addappid(2054090)
addappid(2264940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416231, 1, "fdfd395e8802add2302241a08e4044158aeee82c18468667d93f5dfc58b5c268")
