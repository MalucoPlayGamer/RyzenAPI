-- Lua provided by RyzenAPI
-- Game: 1416230

-- MAIN APPLICATION
addappid(1416230)
-- Game: addappid(1416230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1416231, 1, "fdfd395e8802add2302241a08e4044158aeee82c18468667d93f5dfc58b5c268")
