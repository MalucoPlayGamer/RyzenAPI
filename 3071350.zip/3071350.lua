-- Lua provided by RyzenAPI
-- Game: AppID 3071350

-- MAIN APPLICATION
addappid(3071350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071351, 1, "b16569d99019bacc1058ebc2b0aec043d7c428ceeea9660489f2608bcbbcb89d")
