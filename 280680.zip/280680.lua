-- Lua provided by RyzenAPI
-- Game: Krita

-- MAIN APPLICATION
addappid(280680)
addappid(315160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(280681, 1, "baddb076af5bd847f9b4a70a0cdb83740b1a0724a1b4cedf1a3e3a223a745b4b")
addappid(280682, 1, "86c126ddb42071c4ce7cd430018739e0b35e228dd59d35ce160360eabed73f72")
addappid(280683, 1, "9c024c741808fd1d0203e1e31b77ad9a3e0e29b7b3c06dc5228e258bfafb92aa")
addappid(280684, 1, "e57e0186d6d1f641e1a40408a81f126382a46ce850b451064ba027fbaf0dbecd")

