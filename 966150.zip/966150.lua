-- Lua provided by RyzenAPI
-- Game: 966150

-- MAIN APPLICATION
addappid(966150)
-- Game: addappid(966150)

-- MAIN APP DEPOTS / PACKAGES
addappid(966150,0,"9ff5e3072b4ec4b28d76a59dd50fd2b1df3db621c7cfd18b5e72be2d44f411de")
