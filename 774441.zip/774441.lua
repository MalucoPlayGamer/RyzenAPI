-- Lua provided by RyzenAPI
-- Game: AppID 774441

-- MAIN APPLICATION
addappid(774441)
-- Game: addappid(774441)

-- MAIN APP DEPOTS / PACKAGES
addappid(774442, 1, "2579fef3df9285a7d8160539ad23291088f97aedcd2bd7422a11626c9536b3a1")
