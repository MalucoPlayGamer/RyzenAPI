-- Lua provided by RyzenAPI
-- Game: Countryballs: Rise of Europe

-- MAIN APPLICATION
addappid(3428840)
-- Game: addappid(3428840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428841, 1, "c103c09cc03b99b19e54d876d93ec0ad262c733a29fbd2679d699197181ec4a6")
