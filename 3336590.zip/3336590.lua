-- Lua provided by RyzenAPI
-- Game: Puyo! Push Brain

-- MAIN APPLICATION
addappid(3336590)
-- Game: addappid(3336590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3336591, 1, "a19f63c49397e94241cc396956dc99b5ebc494d91643715764ab5f9cce17a928")
