-- Lua provided by RyzenAPI
-- Game: 215824

-- MAIN APPLICATION
addappid(215824)
-- Game: addappid(215824)

-- MAIN APP DEPOTS / PACKAGES
addappid(215824,0,"7133602ccd31648099c9aad1e5fc6b163fdd373d8aceb3bd9689b240893c7048")
