-- Lua provided by RyzenAPI
-- Game: Myths and Legends - Card Game

-- MAIN APPLICATION
addappid(1005340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1005341, 1, "12edebaeab10ba6b0028cb95b5fee2ef8b8517ce8c722fcfc646f872a7727514")
addappid(1005342, 1, "f7b645a0c4a2ac6259b4677812bae31cc4975730442410ba4522b29365c491ff")

