-- Lua provided by RyzenAPI
-- Game: Game: Yomawari: Lost in the Dark

-- MAIN APPLICATION
addappid(1998330)
-- Game: addappid(1998330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998331, 1, "6480c2d900946b05852a49688cfd14d0b44b50b8d2fd7aa6c1d1f091dd5ede6e")
