-- Lua provided by RyzenAPI
-- Game: Yomawari: Lost in the Dark

-- MAIN APPLICATION
addappid(1998330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998331, 1, "6480c2d900946b05852a49688cfd14d0b44b50b8d2fd7aa6c1d1f091dd5ede6e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2134170)
