-- Lua provided by RyzenAPI
-- Game: Happy Endings

-- MAIN APP DEPOTS / PACKAGES
addappid(4689440, 1, "bdcff8704cb53dc1676cb863b27f2df164a65c405bfbdb0d7311fc98bbb81227") -- Happy Endings
addappid(4689441, 1, "05f732751da07c3758b14fc605072eb1609581fed6e9f85c12aeb39413cbe7de") -- Depot 4689441
addappid(4689442, 1, "db63f518e63bf08273a9f67dac0de7b27ce3c0a4a8d7813b6f2f8975676bb16c") -- Depot 4689442
addappid(4689443, 1, "b1fa43b8fae3dbf1030b59954c89e828e0660dd40c2df985dcede1865656ec8b") -- Depot 4689443

