-- 4689440's Lua and Manifest Created by Hubcap Manifest
-- Happy Endings
-- Created: August 26, 2026 at 19:54:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4689440, 1, "bdcff8704cb53dc1676cb863b27f2df164a65c405bfbdb0d7311fc98bbb81227") -- Happy Endings
-- MAIN APP DEPOTS
addappid(4689441, 1, "05f732751da07c3758b14fc605072eb1609581fed6e9f85c12aeb39413cbe7de") -- Depot 4689441
setManifestid(4689441, "3244500802344646816", 450290409)
addappid(4689442, 1, "db63f518e63bf08273a9f67dac0de7b27ce3c0a4a8d7813b6f2f8975676bb16c") -- Depot 4689442
setManifestid(4689442, "6951563405271592904", 611655778)
addappid(4689443, 1, "b1fa43b8fae3dbf1030b59954c89e828e0660dd40c2df985dcede1865656ec8b") -- Depot 4689443
setManifestid(4689443, "7253072690482429773", 449825159)