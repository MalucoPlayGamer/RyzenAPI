-- Lua provided by RyzenAPI
-- Game: Game: Angry stone

-- MAIN APPLICATION
addappid(2824470)
-- Game: addappid(2824470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824471, 1, "9ee350099312d53d5c9cc966502019995f7f33c57df42d7a8b0cdaf9a2076c81")
