-- Lua provided by RyzenAPI
-- Game: 3219810

-- MAIN APPLICATION
addappid(3219810)
-- Game: addappid(3219810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3219811, 1, "ea31fd79b61389136d03c7bb36888602bab00f9f5f986291404a550a48cdaa7b")
