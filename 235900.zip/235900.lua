-- Lua provided by RyzenAPI
-- Game: RPG Maker XP

-- MAIN APPLICATION
addappid(235900)
addappid(235901)
-- Game: addappid(235900)

-- MAIN APP DEPOTS / PACKAGES
addappid(235902,0,"a6b237ec57c4c9b605c8e29cba2d703c36921aa09b9ede610c370d30eb4150e0")
addappid(235903,0,"73b5696663ea58499a0466eef79435ab77c46523760ae08c8408feec62b7c555")
