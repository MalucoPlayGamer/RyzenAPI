-- Lua provided by RyzenAPI
-- Game: Game: 北荒纪

-- MAIN APPLICATION
addappid(2321610)
-- Game: addappid(2321610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321611, 1, "7459b236fd7ac0a4371f50944a11801d629cbef22aba3d77f1180235f9b22858")
