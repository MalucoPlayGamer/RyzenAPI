-- Lua provided by RyzenAPI
-- Game: Inhibit

-- MAIN APPLICATION
addappid(2578950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578951, 1, "35781a899d4d50b44058d324b3a9abd57c496c5f53582a3252ea73ac8c1a548a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
