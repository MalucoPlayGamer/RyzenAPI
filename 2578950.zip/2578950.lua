-- Lua provided by RyzenAPI
-- Game: Game: Inhibit

-- MAIN APPLICATION
addappid(2578950)
-- Game: addappid(2578950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578951, 1, "35781a899d4d50b44058d324b3a9abd57c496c5f53582a3252ea73ac8c1a548a")
