-- Lua provided by SkyAPI 
-- Game: Rebirth evolution
addappid(1816390)
addappid(1816391, 1, "7785ab53a1384170b61d63a9317e77cc2e901944489c4bc644d3f96d95b32fad")
addappid(2514610)
addappid(2545070, 0, "33835de570762a01dced2c3c4a401614621d862247f06af982177da90625c4b8")
addappid(2545080)
addappid(2572800)
addappid(2575280)
addappid(2583110)
addappid(2583180)
addappid(2583200)
