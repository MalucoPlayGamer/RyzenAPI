-- Lua provided by RyzenAPI
-- Game: Left By Angels

-- MAIN APPLICATION
addappid(3720950)
-- Game: addappid(3720950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720951, 1, "0f856733248b8569b9065465796d1348f98cb5ec4882b20a78f6ec453cc83b49")
