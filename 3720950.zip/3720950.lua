-- Lua provided by RyzenAPI
-- Game: Left By Angels

-- MAIN APPLICATION
addappid(3720950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720951, 1, "0f856733248b8569b9065465796d1348f98cb5ec4882b20a78f6ec453cc83b49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
