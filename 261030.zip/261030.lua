-- Lua provided by RyzenAPI
-- Game: The Walking Dead: Season Two

-- MAIN APPLICATION
addappid(261030)

-- MAIN APP DEPOTS / PACKAGES
addappid(261031, 1, "e03a138d5ac9b1ad2d1bbb1ae54be86e694138d9382275a9c2d896bb1d76a404")
addappid(261032, 1, "c4a0e873b59fbbe4b7c6c0e02a389fdcdfecfd4c1cfdcfdc4bfc5ce1cd55997d")
addappid(261033, 1, "7ea163cc093db296a087c8323468fdafccdfcb21f888df9d2bf9e11cd30f6872")
addappid(261034, 1, "c05dc4e04b443e208ae65f05da101fd2a1bdc5b100537562834fe7dccefccd3e")
addappid(261035, 1, "cb0b576f5af77832a53bfb0512a9f8530940d4b7786c6b31fa9e6b71c8bdf768")
addappid(261036, 1, "8762913ce59723d759d38c2f7fd40db25352cc0590cf9aa4f235d84d5e14e047")
addappid(261037, 1, "0b33dbd6ef88df055e33beed2df48f9789368b99b5966f97c398b8390100d7dc")
addappid(261038, 1, "4a5186767626dafe854e8dbb6e0a46fc0210705e63d0b33deaa7fa2716a6a964")
addappid(261039, 1, "0efa0f8012a53b090e23721be61de9bc33378cd61ca24d6af2ea0d4163328602")
addappid(261040, 1, "fd44be055a0a0fb3bd6a8ddb3c48a69eda7246a16698863710a9f02441529125")
addappid(261041, 1, "9a7e087ab3d5172ff3b74d9693e626ae4e96222cf3b3b0e6b5b345d528a3ed5d")
addappid(261042, 1, "1adc767bde75d4c63f55debb0b96eaca10e444e7e8b24dbfbfcc75d676f4d505")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
