-- Lua provided by RyzenAPI
-- Game: 1000xRESIST

-- MAIN APPLICATION
addappid(1675830)
addappid(3279710)
addappid(3697900)
addappid(4002240)
addappid(4336110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675831, 1, "251d5215fe6174f423769d01cc9a6235309a8a94c9b5ec78b6a3c22ac5925de2")
