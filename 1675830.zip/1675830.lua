-- Lua provided by RyzenAPI
-- Game: addappid(1675830)

-- MAIN APPLICATION
addappid(1675830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675831, 1, "251d5215fe6174f423769d01cc9a6235309a8a94c9b5ec78b6a3c22ac5925de2")
