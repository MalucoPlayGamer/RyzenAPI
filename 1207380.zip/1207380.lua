-- Lua provided by RyzenAPI
-- Game: 1207380

-- MAIN APPLICATION
addappid(1207380)
-- Game: addappid(1207380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207381, 1, "9314f712bda1ca15540dadcc97ee5ae608c58e38a5201148c97c7089d5de469b")
