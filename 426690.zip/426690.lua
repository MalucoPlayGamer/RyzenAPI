-- Lua provided by RyzenAPI
-- Game: Narcissu 10th Anniversary Anthology Project

-- MAIN APPLICATION
addappid(426690)

-- MAIN APP DEPOTS / PACKAGES
addappid(426693,0,"91875c70c32ecdd64f4b5f7e5ab74ae6c30768875fbe2d74a329e339c00dc7a0")
addappid(426694,0,"da4d68619e18780e4f549360a34dfd00986204aff12bb150942e757050f95c1e")
addappid(426695,0,"91b05309b071adf107e9e6d88260b87843a2a645bccdd099b72c85b22ffe0fd7")
addappid(426696,0,"562e1823a6697bcdaf4c682df2ad260e9ddd82d2a1591a4f4efef956bf0cc897")
addappid(426697,0,"0e726ed4ee717de75ff7e270c9aca1a011f627e9c27b8ee297dde29430ecf3c3")
addappid(461250,0,"a3b8b0d143cffed30031de73a8ab475a37086a6e2aa8be21e5e196ee220c0482")
addappid(461251,0,"ce07b39c0ca58ce1948fc971003605b7ecbe67da6e56efb75c9357b590699177")
addappid(461252,0,"0da848c94371486939edc6896c438189c276940d0a293b2b7d4e0e22caf16f02")
addappid(461253,0,"5d03dbf523bfae588e8530890bacc6af29ac87a44db6fac13bfe0a47ee5fa26d")
addappid(504640,0,"af2f82c1c49d6cbedab7cd80048bd71f3ad6380d50c732d68aebf13925a8953b")
addappid(504641,0,"a9b781501402808bbf09a18b516a27c1c782ab51a21ca04e0055dd89f0453307")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(439510)
addappid(608420)
