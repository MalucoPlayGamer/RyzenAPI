-- Lua provided by RyzenAPI
-- Game: KINGDOM HEARTS HD 2.8 Final Chapter Prologue

-- MAIN APPLICATION
addappid(229002)
addappid(2552440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2552442,0,"aa2a72186b9d5b0e6051ef85923163544ddfd147950510bae59aaafa9ba00118")
addappid(2552443,0,"e5176bdda321bbcc30b63de2f1bd4c65627192ac6ab3873322f163f258574cf5")
addappid(2552444,0,"bfce5797607ede0bf1d4da6979773463c31c6040d20c5f90f563ecd1c2ed6b76")
addappid(2552445,0,"cbb8de50bd24129bbb6907a8db75af671ea013054811ccdd1cfa44fd094f2ecf")
addappid(2552446,0,"ec25765b66a429dc12261f550d4cdf2a9bb143a632c580a5dc76c5e6b5729696")
addappid(2552447,0,"3a3cd77bcccfef0c5c5e8ce6b389516901f10bf009ed1ee31c6cac12b88d16d4")

