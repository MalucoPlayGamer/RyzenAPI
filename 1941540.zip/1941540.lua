-- Lua provided by RyzenAPI
-- Game: Game: Mafia: The Old Country

-- MAIN APPLICATION
addappid(1941540)
addappid(3262000)
addappid(3269260)
addappid(3269270)
addappid(3269280)
-- Game: addappid(1941540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1941541, 1, "47c1ea957b9ecc8662a117fa6b19eea01ed30ef06478a364110fe40afa4e9f0e")
