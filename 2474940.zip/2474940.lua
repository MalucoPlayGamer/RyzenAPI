-- Lua provided by RyzenAPI
-- Game: Nope Nope Nope Nope Nurses

-- MAIN APPLICATION
addappid(2474940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474941, 1, "21ee99ef5fc00ffd56eebe7540b9ce39bf861e3bba1e23605cdb87f74ea4f5b1")
