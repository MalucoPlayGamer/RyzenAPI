-- Lua provided by RyzenAPI
-- Game: Nope Nope Nope Nope Nurses

-- MAIN APPLICATION
addappid(2474940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474941, 1, "21ee99ef5fc00ffd56eebe7540b9ce39bf861e3bba1e23605cdb87f74ea4f5b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
