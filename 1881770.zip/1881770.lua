-- Lua provided by RyzenAPI
-- Game: Game: Doors: Paradox Demo

-- MAIN APPLICATION
addappid(1881770)
-- Game: addappid(1881770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881771, 1, "124ce3b015912456f706da2d50deacacd743ec4e9e97e2c67857e0e9cb5b034f")
