-- Lua provided by SkyAPI 
-- Game: Chroma Deluxe : Sexy Hentai Girls
addappid(998010)
addappid(998011, 1, "dc47b61f9b542f3069d6c2551c48e03fa11b57f511ccb90f316df27877aa0bf6")
addappid(998012, 1, "48752f55d631a3fbd335407a0f84cde0e0fae75904fa9420f0d8d2ecba9a9cfc")
