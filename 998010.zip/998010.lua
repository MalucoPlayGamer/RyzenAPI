-- Lua provided by RyzenAPI
-- Game: 998010

-- MAIN APPLICATION
addappid(998010)
-- Game: addappid(998010)

-- MAIN APP DEPOTS / PACKAGES
addappid(998011, 1, "dc47b61f9b542f3069d6c2551c48e03fa11b57f511ccb90f316df27877aa0bf6")
addappid(998012, 1, "48752f55d631a3fbd335407a0f84cde0e0fae75904fa9420f0d8d2ecba9a9cfc")
