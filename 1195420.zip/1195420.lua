-- Lua provided by RyzenAPI
-- Game: 1195420

-- MAIN APPLICATION
addappid(1195420)
-- Game: addappid(1195420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195421, 1, "986fbd3ee13199848d927aa99d007d5336651f9adcdb0981ac24458b7b527e9d")
