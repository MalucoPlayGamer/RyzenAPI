-- Lua provided by RyzenAPI
-- Game: AppID 277870

-- MAIN APPLICATION
addappid(277870)

-- MAIN APP DEPOTS / PACKAGES
addappid(277871, 1, "c0627cbf4ca6edb3f9496ad3f239e9a951f6901c52e52b4af25eb5158ace3e81")
