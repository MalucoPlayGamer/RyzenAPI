-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2300790)
addappid(2300792,0,"f2b451e0a5b539b466c5a9de0ba6bc500783eeb225155fcecd07b408810fde60")
-- setManifestid(2300792,"8308574323193995576")
addappid(2300793,0,"61e162aa16c9b4997fb4b5ed43b207fca9596493b34ef8e9a9e5fe6de4c9c99b")
-- setManifestid(2300793,"8125356531657419744")