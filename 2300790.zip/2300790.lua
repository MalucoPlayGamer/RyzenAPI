-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2300790)
-- Game: addappid(2300790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300792,0,"f2b451e0a5b539b466c5a9de0ba6bc500783eeb225155fcecd07b408810fde60")
addappid(2300793,0,"61e162aa16c9b4997fb4b5ed43b207fca9596493b34ef8e9a9e5fe6de4c9c99b")
