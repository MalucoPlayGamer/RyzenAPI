-- Lua provided by RyzenAPI 
-- Game: 闲置神话
addappid(2563550)
addappid(2563551, 1, "fdc417fe56b80c43bf8ae5afbf0598574734ec39bd0ddd687943ee3ad494469a")
