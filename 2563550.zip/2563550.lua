-- Lua provided by RyzenAPI
-- Game: 闲置神话

-- MAIN APPLICATION
addappid(2563550)
-- Game: addappid(2563550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563551, 1, "fdc417fe56b80c43bf8ae5afbf0598574734ec39bd0ddd687943ee3ad494469a")
