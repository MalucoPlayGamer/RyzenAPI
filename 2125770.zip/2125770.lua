-- Lua provided by RyzenAPI
-- Game: addappid(2125770)

-- MAIN APPLICATION
addappid(2125770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125771, 1, "d02c5573e5a86d0dff86310db5470598e29242583d0b4a1b80f81fa869efb06a")
