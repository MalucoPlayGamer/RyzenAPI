-- Lua provided by RyzenAPI
-- Game: FPS - Fun Puzzle Shooter

-- MAIN APPLICATION
addappid(697850)
-- Game: addappid(697850)

-- MAIN APP DEPOTS / PACKAGES
addappid(697851, 1, "b68195fc69df6ac2006ecf8bb8160a2f28ab3fb463343e97fc8f292dc6b8f6fa")
