-- Lua provided by RyzenAPI
-- Game: Game: Iridion II

-- MAIN APPLICATION
addappid(1132230)
-- Game: addappid(1132230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132231, 1, "3f75c9ac3404a54d7e242683f18ad1cc0e71f998304d7e48918367e0976c1465")
