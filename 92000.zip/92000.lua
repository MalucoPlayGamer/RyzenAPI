-- Lua provided by RyzenAPI
-- Game: Hydrophobia: Prophecy

-- MAIN APPLICATION
addappid(92000)

-- MAIN APP DEPOTS / PACKAGES
addappid(92001, 1, "82ca22b1a60a3e090da8011774290c45096b974b3055e70b99ddc3943925affc")

