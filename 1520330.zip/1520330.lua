-- Lua provided by RyzenAPI
-- Game: TechBeat Heart

-- MAIN APPLICATION
addappid(1520330)
-- Game: addappid(1520330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520331, 1, "1480ff53939112393f8d774b0adeded215ceea9b2d0edb547608cd9545079763")
addappid(1520332, 1, "c094605f37c2412d787a0b2869f1e8ac78960a70dc038f04bd2c5b1a223b42b3")
