-- Lua provided by RyzenAPI
-- Game: Forgotten Villa

-- MAIN APPLICATION
addappid(4154970)

-- MAIN APP DEPOTS / PACKAGES
addappid(4154971,0,"6ca19e585c21657725de160335e91ffa4ea7cf3ddbae6a1479c05289d682031e")

