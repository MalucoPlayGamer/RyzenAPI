-- Lua provided by RyzenAPI
-- Game: Sullen: Light is Your Friend

-- MAIN APPLICATION
addappid(525460)

-- MAIN APP DEPOTS / PACKAGES
addappid(525461, 1, "ef45be98f97b4bf753900f34dd1359766231e6c0c925d2b29fcd27e887d2abac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
