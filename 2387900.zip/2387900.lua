-- Lua provided by RyzenAPI
-- Game: 2387900

-- MAIN APPLICATION
addappid(2387900)
-- Game: addappid(2387900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387901, 1, "9a79c2078ff5064037c41b0419564ac935b2663d66f4d514cbd888da2b5b0423")
addappid(2387902, 1, "b474e2ce65ab747cd551dfd37bb9be13f764bb8deb27ab3c24e219375eb6df2e")
