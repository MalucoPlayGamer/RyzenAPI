-- Lua provided by RyzenAPI
-- Game: addappid(1669980)

-- MAIN APPLICATION
addappid(1669980)
addappid(2582920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669981, 1, "3a047ea5cbf7ba1277d2f1f7ed2016381bf2791e4678e42a7548f09fa03284e6")
