-- Lua provided by RyzenAPI
-- Game: Data Hacker: Reboot

-- MAIN APPLICATION
addappid(331790)
-- Game: addappid(331790)

-- MAIN APP DEPOTS / PACKAGES
addappid(331791, 1, "b5bbd83176ea6a0a6adc50d812ec132de54a43c339e2ea386b1a5bd61213a0ce")
addappid(367250, 0, "22fd0771634dd63cd5e3e413962ddc129e814f2911240661e1a89337e68b9f92")
addappid(376530, 0, "c439e292cae4a0800d935ae5580c054056ac4af044d6b730860256ed467e0d44")
