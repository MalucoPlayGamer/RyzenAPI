-- Lua provided by RyzenAPI
-- Game: Nancy Drew: Trail of the Twister

-- MAIN APPLICATION
addappid(42230)

-- MAIN APP DEPOTS / PACKAGES
addappid(42231, 1, "234e9b5ead31c65b5c4176e1d29e49f84337d5b4201102868d279ee4fa06e2fd")
