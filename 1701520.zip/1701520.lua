-- Lua provided by RyzenAPI 
-- Game: Afterimage
addappid(1701520)
addappid(1701521, 1, "db0d8a5eed6f71381499903f6250df33d49f9a7f998dc6be20c1ebe04cbf1eee")
addappid(1701522, 1, "6315657c5dad11d05c9d412b95960bcf0527d2a273a47a8ab4b5b1bce7ee628a")
