-- Lua provided by RyzenAPI
-- Game: Afterimage

-- MAIN APPLICATION
addappid(1701520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701521, 1, "db0d8a5eed6f71381499903f6250df33d49f9a7f998dc6be20c1ebe04cbf1eee")
addappid(1701522, 1, "6315657c5dad11d05c9d412b95960bcf0527d2a273a47a8ab4b5b1bce7ee628a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2389760)
