-- Lua provided by SkyAPI 
-- Game: AppID 1322600
addappid(1322600)
addappid(1322601, 1, "b1609477541c5135b49b3236a947c3efd6968f9f12423981dc4440f4a81c5b39")
