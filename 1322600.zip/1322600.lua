-- Lua provided by RyzenAPI
-- Game: Pizza Bike Rider

-- MAIN APPLICATION
addappid(1322600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322601, 1, "b1609477541c5135b49b3236a947c3efd6968f9f12423981dc4440f4a81c5b39")

