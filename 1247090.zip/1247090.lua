-- Lua provided by RyzenAPI
-- Game: Stormworks Dedicated Server

-- MAIN APPLICATION
addappid(1247090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247091, 1, "9d73913e72d1ee60a92c06f1ac9bb0d66ad09908d7e9eb2595cc9bee4a6e5821")
