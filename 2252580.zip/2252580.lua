-- Lua provided by RyzenAPI
-- Game: AppID 2252580

-- MAIN APPLICATION
addappid(2252580)
-- Game: addappid(2252580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252581, 1, "1c726f18aaf500e7a0d7f101ab43f280bd04a6acc9ae80329be3461fe7f2663e")
addappid(2252582, 1, "83d3d04fb3050b58e907c96988573625b94ec5a5d8ddb9b3031e0a0b5ec414d5")
