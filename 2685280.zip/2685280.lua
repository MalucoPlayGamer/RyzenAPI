-- Lua provided by SkyAPI 
-- Game: AppID 2685280
addappid(2685280)
addappid(2685281, 1, "874218558f9d57c5bc983b88cf1518ced2eb78ce6c220cfe1c164ed85cdaa494")
