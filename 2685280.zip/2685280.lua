-- Lua provided by RyzenAPI
-- Game: AppID 2685280

-- MAIN APPLICATION
addappid(2685280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685281, 1, "874218558f9d57c5bc983b88cf1518ced2eb78ce6c220cfe1c164ed85cdaa494")
