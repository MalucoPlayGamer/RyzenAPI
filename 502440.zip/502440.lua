-- Lua provided by RyzenAPI
-- Game: addappid(502440)

-- MAIN APPLICATION
addappid(502440)

-- MAIN APP DEPOTS / PACKAGES
addappid(502441, 1, "2b2f9ffc0f713a42ccbfdfcbc6c03f8c15fc860798791ca54cc04e5fad87c564")
