-- Lua provided by SkyAPI 
-- Game: The Witness
addappid(210970)
addappid(210971, 1, "2e55c8ba9200080a092bb03dc13648364723b13f154c00a569624e4df1717964")
addappid(210972, 1, "129582a1d0d8904c8f2c4164360eb6de7d619cd4ab6a9dcc972c6dc18dd2472b")
addappid(228985)
