-- Lua provided by RyzenAPI
-- Game: The Sea Eternal

-- MAIN APPLICATION
addappid(463320)

-- MAIN APP DEPOTS / PACKAGES
addappid(463321, 1, "690732c051163df23be6f0bc025047134158f54574e27cb10d72ad51d4ec06d6")
