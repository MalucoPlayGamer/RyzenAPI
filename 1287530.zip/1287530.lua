-- Lua provided by RyzenAPI
-- Game: Lords and Villeins

-- MAIN APPLICATION
addappid(1287530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287531, 1, "310a6803521875703829fc63be1dc42ade96e9cdd8b8fe347f5d3ff95a739bc2")
addappid(2943600, 0, "9bb8301013c5fbd7a8dc77e75b0f9a726f306e35d010c338e165bef63dfe5250")
