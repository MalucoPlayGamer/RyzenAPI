-- Lua provided by RyzenAPI
-- Game: Strategos

-- MAIN APPLICATION
addappid(3064810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064811,0,"335a9881c4d400a487006eb53ab7aa0c16a05ddc569d2dd63bb16dc19db20008")

