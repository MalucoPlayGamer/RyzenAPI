-- Lua provided by RyzenAPI
-- Game: Tiny Bridge: Ratventure

-- MAIN APPLICATION
addappid(360380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(360381, 1, "230690caa51b2eee237dfea0d127db51a24264c8e2822ec527f342ad43ce01a5")
addappid(360382, 1, "82f677639273c60fc1684d1ef8399928472ff481b63462c269c5f4766caf3ee0")

