-- Lua provided by RyzenAPI
-- Game: addappid(1181772)

-- MAIN APPLICATION
addappid(1181772)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181772,0,"042f1baeeda071002406c8cc24575f3bbd3d8c2afff17d6cf8734188673e5a8b")
