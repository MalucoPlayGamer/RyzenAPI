-- Lua provided by RyzenAPI
-- Game: Elevator Zero

-- MAIN APPLICATION
addappid(2840990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840991, 1, "1601736fb1bc0620d0dd4df1a2b5983928979d7fe13f8b23df230619cfad820d")
