-- Lua provided by RyzenAPI
-- Game: Super Sus

-- MAIN APPLICATION
addappid(2920270)
