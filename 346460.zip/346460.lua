-- Lua provided by RyzenAPI
-- Game: Vector 36

-- MAIN APPLICATION
addappid(346460)
addappid(421860)
addappid(578770)
addappid(1095621)
addappid(1095622)
addappid(1095624)
addappid(1095626)

-- MAIN APP DEPOTS / PACKAGES
addappid(346461, 1, "cb5299e85f59741737d9001ff128bace5d1468a24610086c7f047c00db5d03ea")
addappid(346464, 1, "a30c18347f4d2dd5295ab84d26d0090b2f5a9cf19e450366a12e51af709bbec7")

