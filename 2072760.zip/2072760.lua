-- Lua provided by RyzenAPI
-- Game: AppID 2072760

-- MAIN APPLICATION
addappid(2072760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072761, 1, "fd7bc6e26d81b8e400de7692f223a8de3456934a4ebb9c9dabc11a63b544fb4e")

