-- Lua provided by RyzenAPI
-- Game: addappid(2729360)

-- MAIN APPLICATION
addappid(2729360)
addappid(2734630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729361, 1, "aaa862f5ce36683c926a72c125916cdfd4a46fdc02aadda4e2b35d1fd59ed414")
addappid(2729362, 1, "0dd85dcd44b879a7d3100368332ab9237ce8a26711349349be8d90109d6c36eb")
