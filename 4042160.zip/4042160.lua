-- Lua provided by RyzenAPI
-- Game: Static Dread: The Submarine

-- MAIN APPLICATION
addappid(4042160) -- Static Dread: The Submarine
addappid(4860820) -- Supporter Pack
-- addappid(5003390)

-- MAIN APP DEPOTS / PACKAGES
addappid(4042161, 1, "e33985a09675437534a8edffd1459a5b30842285b3b8226723dd9c30887881ff") -- Depot 4042161

