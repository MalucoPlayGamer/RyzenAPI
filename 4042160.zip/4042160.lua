-- 4042160's Lua and Manifest Created by Hubcap Manifest
-- Static Dread: The Submarine
-- Created: August 15, 2026 at 03:35:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1 (1 excluded)

-- MAIN APPLICATION
addappid(4042160) -- Static Dread: The Submarine
-- MAIN APP DEPOTS
addappid(4042161, 1, "e33985a09675437534a8edffd1459a5b30842285b3b8226723dd9c30887881ff") -- Depot 4042161
setManifestid(4042161, "4616250151702678354", 1755556096)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4860820) -- Supporter Pack
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Digital Art Collection (AppID: 5003390) - missing depot keys
-- addappid(5003390)