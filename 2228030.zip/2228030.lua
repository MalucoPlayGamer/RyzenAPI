-- Lua provided by RyzenAPI
-- Game: Game: Dr. Fetus' Mean Meat Machine

-- MAIN APPLICATION
addappid(2228030)
-- Game: addappid(2228030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2228031, 1, "e98afe15b52fb6306c76e0730b0d6758f88f95a54027fc410fd533abe6786583")
