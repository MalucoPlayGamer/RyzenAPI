-- Lua provided by RyzenAPI
-- Game: addappid(567030)

-- MAIN APPLICATION
addappid(567030)

-- MAIN APP DEPOTS / PACKAGES
addappid(567031, 1, "e117def2f15e011af114fc6f874da7239f050aa2af301c75c07d871b167fd564")
