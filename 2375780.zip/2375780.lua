-- Lua provided by RyzenAPI
-- Game: Beam Eye Tracker

-- MAIN APPLICATION
addappid(2375780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375781, 1, "36327ca060d94c61bde1b0518cc17b2c9e035f7829155f0b90a846d24a27766c")
