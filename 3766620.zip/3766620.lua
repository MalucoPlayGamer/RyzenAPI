-- 3766620's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Midori is streaming
-- Created: July 11, 2026 at 02:41:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3766620) -- Hentai Clicker: Midori is streaming
-- MAIN APP DEPOTS
addappid(3766621, 1, "92341e38f81c4e51e8afc3544e17f73d09dae7cc8dc1e503ef7e65ee8b0ff70f") -- Depot 3766621
setManifestid(3766621, "8339664307124362420", 161822666)
addappid(3766622, 1, "b2c22f785639b63d52e82c9ae5e2037c1bd13cc2f0d1ccb783b31c0c58fc2598") -- Depot 3766622
setManifestid(3766622, "4422670755457562118", 196975792)
addappid(3766623, 1, "e384ea3bbcf8a71a8236147d4f1ccbd8686486ba8bdd85a68318ad64f239972f") -- Depot 3766623
setManifestid(3766623, "5041607552530935067", 210624901)