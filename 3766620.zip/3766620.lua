-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Midori is streaming

-- MAIN APPLICATION
addappid(3766620) -- Hentai Clicker: Midori is streaming

-- MAIN APP DEPOTS / PACKAGES
addappid(3766621, 1, "92341e38f81c4e51e8afc3544e17f73d09dae7cc8dc1e503ef7e65ee8b0ff70f") -- Depot 3766621
addappid(3766622, 1, "b2c22f785639b63d52e82c9ae5e2037c1bd13cc2f0d1ccb783b31c0c58fc2598") -- Depot 3766622
addappid(3766623, 1, "e384ea3bbcf8a71a8236147d4f1ccbd8686486ba8bdd85a68318ad64f239972f") -- Depot 3766623

