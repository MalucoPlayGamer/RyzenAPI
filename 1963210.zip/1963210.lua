-- Lua provided by RyzenAPI
-- Game: VALKYRIE ELYSIUM

-- MAIN APPLICATION
addappid(1963210)
addappid(2055030)
-- Game: addappid(1963210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963211, 1, "bec635b62e3e6444839005dad7627c6bda98ef0250e9c7fdc9293fdf944b1643")
