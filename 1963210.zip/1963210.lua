-- Lua provided by RyzenAPI
-- Game: VALKYRIE ELYSIUM

-- MAIN APPLICATION
addappid(1963210)
addappid(2055030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963211, 1, "bec635b62e3e6444839005dad7627c6bda98ef0250e9c7fdc9293fdf944b1643")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2054990)
