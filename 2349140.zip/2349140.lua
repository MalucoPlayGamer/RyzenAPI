-- Lua provided by RyzenAPI
-- Game: KONOSUBA - God's Blessing on this Wonderful World! Love For These Clothes Of Desire!

-- MAIN APPLICATION
addappid(2349140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349141, 1, "9eaa0ae414f8b52960c20ea2c2ff0a0a8aa7ade563b3de3ffccd4e8a0612a53b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2590880)
addappid(2590890)
addappid(2590900)
