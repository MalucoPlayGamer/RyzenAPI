-- Lua provided by RyzenAPI
-- Game: 2349140

-- MAIN APPLICATION
addappid(2349140)
-- Game: addappid(2349140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349141, 1, "9eaa0ae414f8b52960c20ea2c2ff0a0a8aa7ade563b3de3ffccd4e8a0612a53b")
