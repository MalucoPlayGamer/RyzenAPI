-- Lua provided by RyzenAPI
-- Game: Spirits of Baciu - Prologue

-- MAIN APPLICATION
addappid(2143930)
-- Game: addappid(2143930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143931, 1, "e66043a65a601fec062ed3a25466dcaf55e591ee5a63f73e207f17b11c8a5ada")
