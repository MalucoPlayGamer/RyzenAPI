-- Lua provided by RyzenAPI
-- Game: Horny Sekai - DLC 18+ Adult Only

-- MAIN APPLICATION
addappid(1729680)
-- Game: addappid(1729680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729682,0,"713b10d29ceea708531081da4802c2c3e20c6925e160b2b5c4ab3c55f47065d6")
