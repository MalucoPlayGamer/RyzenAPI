-- Lua provided by RyzenAPI
-- Game: addappid(893982)

-- MAIN APPLICATION
addappid(893982)

-- MAIN APP DEPOTS / PACKAGES
addappid(893982,0,"861aea4c1cc63cbbfa20b54be39f052d83e3a5e3fb71441c698da27d02a11cb7")
