-- Lua provided by RyzenAPI
-- Game: Roots of Insanity - Original Soundtrack

-- MAIN APPLICATION
addappid(1550930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550931, 1, "f984026c599201db904c44908937c6591adf2a103a73cc1f427b398953eea4d0")
