-- Lua provided by RyzenAPI
-- Game: Kohan: Ahriman's Gift

-- MAIN APPLICATION
addappid(97120)

-- MAIN APP DEPOTS / PACKAGES
addappid(97121, 1, "ad212fc06e80558425558da9966fad611e985ce63375ea7816605aeb57a037b5")

