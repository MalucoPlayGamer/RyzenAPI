-- Lua provided by RyzenAPI
-- Game: Paragnosia

-- MAIN APPLICATION
addappid(3017580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017581,0,"1f1d66cb0085c70de0f55e6b05d25a209611694c51be55b49a91810a55343903")
addappid(3017582,0,"2e31d152a8275694675dfe467e5dd6d8e14bd4c1ef658694bddfae0f94c3b91f")
addappid(3017583,0,"f1ed74b665eebdc8c14d3144c0a42a9696a180f26dc56fb1fbeff326cab1f35d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4841850)
