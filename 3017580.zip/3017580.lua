-- Lua provided by RyzenAPI
-- Game: Paragnosia

-- MAIN APPLICATION
addappid(3017580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017581, 1, "1f1d66cb0085c70de0f55e6b05d25a209611694c51be55b49a91810a55343903")

