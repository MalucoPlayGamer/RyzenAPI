-- Lua provided by SkyAPI 
-- Game: Paragnosia
addappid(3017580)
addappid(3017581, 1, "1f1d66cb0085c70de0f55e6b05d25a209611694c51be55b49a91810a55343903")
