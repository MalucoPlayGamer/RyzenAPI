-- Lua provided by RyzenAPI
-- Game: 802620

-- MAIN APPLICATION
addappid(802620)
-- Game: addappid(802620)

-- MAIN APP DEPOTS / PACKAGES
addappid(802621, 1, "6431a76aba423bed20531848d764e670084ff3150fa31c0e2a3776cebe1ef90e")
