-- Lua provided by RyzenAPI
-- Game: Wordatro! Soundtrack

-- MAIN APPLICATION
addappid(3819390)
-- Game: addappid(3819390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3819391, 1, "6d2716f291d57b8700dc28284e05a2f5674a58641b79740c17ee23f2c22b2ec8")
addappid(3819392, 1, "fd970818ee4184eea02d1f8a2a2d4438e09c47bcc20a1c71f7e966525470ca1a")
