-- Lua provided by SkyAPI 
-- Game: Soda Story - Brewing Tycoon
addappid(1088750)
addappid(1088751, 1, "826763209ddceaedda71e7e5e7f3c4c56e821942ee5d4bbbf3d9709f505414c2")
