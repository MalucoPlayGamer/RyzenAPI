-- Lua provided by RyzenAPI
-- Game: Soda Story - Brewing Tycoon

-- MAIN APPLICATION
addappid(1088750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088751, 1, "826763209ddceaedda71e7e5e7f3c4c56e821942ee5d4bbbf3d9709f505414c2")

