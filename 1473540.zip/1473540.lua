-- Lua provided by RyzenAPI
-- Game: Gondola's Adventure

-- MAIN APPLICATION
addappid(1473540)
addappid(2436320)
-- Game: addappid(1473540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473541, 1, "d89dc0ac6b49ae3cf38c5c2d8ab0763227829c3df119a0483a3e4305f7f1e153")
