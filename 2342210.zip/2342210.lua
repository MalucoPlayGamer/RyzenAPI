-- Lua provided by RyzenAPI
-- Game: GENIE

-- MAIN APPLICATION
addappid(2342210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342211, 1, "a768a64339beb2159bc2b2562d34519c4ce5c76ee064a4ca7e25af3e5ebc82fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
