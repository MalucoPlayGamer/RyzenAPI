-- Lua provided by RyzenAPI
-- Game: GENIE

-- MAIN APPLICATION
addappid(2342210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342211, 1, "a768a64339beb2159bc2b2562d34519c4ce5c76ee064a4ca7e25af3e5ebc82fa")

