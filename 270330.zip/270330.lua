-- Lua provided by RyzenAPI
-- Game: Ku: Shroud of the Morrigan

-- MAIN APPLICATION
addappid(270330)
-- Game: addappid(270330)

-- MAIN APP DEPOTS / PACKAGES
addappid(270331, 1, "2bf86148a9ba11f43958c2e975e9f739ec8758d3611845ea840ffacb1a0ff352")
