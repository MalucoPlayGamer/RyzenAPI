-- Lua provided by RyzenAPI
-- Game: addappid(3088410)

-- MAIN APPLICATION
addappid(3088410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088411, 1, "2d535f711e664042597e20630e89eaac1bf116c7f1aa74098c9bb939f366ee6c")
