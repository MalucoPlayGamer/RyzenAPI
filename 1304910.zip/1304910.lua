-- Lua provided by RyzenAPI
-- Game: Game: My Hidden Things

-- MAIN APPLICATION
addappid(1304910)
-- Game: addappid(1304910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304911, 1, "e5b1538268d37aaf66d0ac5a4b933e465d64551ca8f1fd3c1a92aabb1b644c73")
