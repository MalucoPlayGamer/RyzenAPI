-- Lua provided by RyzenAPI
-- Game: Game: Dark Hours

-- MAIN APPLICATION
addappid(2208570)
-- Game: addappid(2208570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208571, 1, "0712fda8075e570ec33f25a8e1d2f12b0027b76e2d415ee0433e2099eafe4c03")
