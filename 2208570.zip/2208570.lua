-- Lua provided by RyzenAPI
-- Game: Dark Hours

-- MAIN APPLICATION
addappid(2208570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2208571, 1, "0712fda8075e570ec33f25a8e1d2f12b0027b76e2d415ee0433e2099eafe4c03")

