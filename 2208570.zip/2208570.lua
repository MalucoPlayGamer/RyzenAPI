-- Lua provided by SkyAPI 
-- Game: Dark Hours
addappid(2208570)
addappid(2208571, 1, "0712fda8075e570ec33f25a8e1d2f12b0027b76e2d415ee0433e2099eafe4c03")
