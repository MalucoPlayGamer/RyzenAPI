-- Lua provided by RyzenAPI
-- Game: projectM Music Visualizer

-- MAIN APPLICATION
addappid(1358800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1358801, 1, "485a1afe9fc7115b19ba87905fdd96d1b47e89db5bce912f5637218868795a08")
addappid(1358802, 1, "4c98263d8664388af9cbcd98720388fb930ceb64bd525b087773a67379d729b6")
addappid(1358803, 1, "2ca1c2113645ba78595d1e27571a9c016f9cb9bc95f98005714c08c9fb616070")
addappid(1358804, 1, "cad571454c2811c8a14aa36a0badcf5298706eee14aa0f3baf7fadd1e5799319")

