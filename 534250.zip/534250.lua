-- Lua provided by RyzenAPI
-- Game: Getting Freaky With Fujiki

-- MAIN APPLICATION
addappid(534250)
addappid(2393450)

-- MAIN APP DEPOTS / PACKAGES
addappid(534251, 1, "2c61a47665980f38257a0444147546d8c8fc2b0b4de9b3adfc7ee6367616e7ad")
addappid(534252, 1, "5cb603f75137734a4c11d6c4901960f3071e518e9c04d33c8ae276b255c7c7c2")
addappid(534253, 1, "b973120dc42f3e08df5e674a7e3f59082859241d8e59997bc87be06a7fe7da1b")

