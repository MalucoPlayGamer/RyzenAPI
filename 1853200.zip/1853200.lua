-- Lua provided by RyzenAPI
-- Game: addappid(1853200)

-- MAIN APPLICATION
addappid(1853200)
addappid(1874460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853201, 1, "39a775fb16aa1add61ddb97c4fa9c07398c229b8758ddb8bc1dddef5940157ba")
addappid(1853202, 1, "2ac62fcace20bceeaac76b117518f206f57d91160812e48443ca48aaba20df75")
