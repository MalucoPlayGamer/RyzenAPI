-- Lua provided by RyzenAPI
-- Game: Animal Planner

-- MAIN APPLICATION
addappid(2479960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479961, 1, "3e13d9180267e4c030723263ef63d885889e0740e4126cf0b2dc97540fd7b17d")
