-- Lua provided by SkyAPI 
-- Game: Animal Planner
addappid(2479960)
addappid(2479961, 1, "3e13d9180267e4c030723263ef63d885889e0740e4126cf0b2dc97540fd7b17d")
