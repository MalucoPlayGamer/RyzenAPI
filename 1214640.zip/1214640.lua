-- Lua provided by SkyAPI 
-- Game: StellarX
addappid(1214640)
addappid(1214641, 1, "940ab3f8f8980a127378ab78d6aa01dbaff1cd4fb20e0750601ef359da1ea93a")
