-- Lua provided by RyzenAPI
-- Game: StellarX

-- MAIN APPLICATION
addappid(1214640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214641, 1, "940ab3f8f8980a127378ab78d6aa01dbaff1cd4fb20e0750601ef359da1ea93a")

