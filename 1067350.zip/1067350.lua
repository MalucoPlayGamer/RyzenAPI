-- Lua provided by RyzenAPI
-- Game: Sophie's Dice

-- MAIN APPLICATION
addappid(1067350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067351, 1, "c464b06ceb5340093bc655ed1cedcf66584776dcbbab7bb1ca2c96cb6aa603ea")

