-- Lua provided by RyzenAPI 
-- Game: AppID 1067350
addappid(1067350)
addappid(1067351, 1, "c464b06ceb5340093bc655ed1cedcf66584776dcbbab7bb1ca2c96cb6aa603ea")
