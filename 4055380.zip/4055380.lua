-- Lua provided by RyzenAPI
-- Game: SpaceSim - Astrophysical Simulation Software

-- MAIN APPLICATION
addappid(4055380)

-- MAIN APP DEPOTS / PACKAGES
addappid(4055380,0,"1413874e8afb00c37463990868f9cfb47ea876020a63d11fd02de3f8d941e939")
addappid(4055381,0,"c9d66eb676ab6239bc5e1dd5c5f5d57ecd66c7f72930b3958dffde1e9a6abc4a")
addappid(4055382,0,"ce71523e1994ec2cc7471adab6bcf85fde819fa99c76736288bb72aa3a586e7d")

