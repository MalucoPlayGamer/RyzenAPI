-- Lua provided by RyzenAPI
-- Game: 1982530

-- MAIN APPLICATION
addappid(1982530)
-- Game: addappid(1982530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982531, 1, "a22d40dfa895def1c6c712eb1550f8fcb7c1783bbef1ff5c710ce2e0d7e2010e")
