-- Lua provided by RyzenAPI
-- Game: Touhou ~Red Empress Devil. DEMO

-- MAIN APPLICATION
addappid(2204690)
-- Game: addappid(2204690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204691, 1, "a0da95f029fff4591d567593b7990b7b33a75e27ea909bed9c06542b368200a5")
