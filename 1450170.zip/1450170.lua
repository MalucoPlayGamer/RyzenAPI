-- Lua provided by SkyAPI 
-- Game: My Ten-day Girlfriend
addappid(1450170)
addappid(1450171, 1, "f9ecb9a2c4eb1219b975b42431f4f83a65f442268e9c7f5f59a347c59874233a")
addappid(1469010, 0, "31b874f3a8f2e9189da5aba0bcdc13d419a1841fdda1c588597a407a61a81830")
