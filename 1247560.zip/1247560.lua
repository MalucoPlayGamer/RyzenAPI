-- Lua provided by RyzenAPI
-- Game: Game: AppID 1247560

-- MAIN APPLICATION
addappid(1247560)
-- Game: addappid(1247560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247561, 1, "5eba5dcba579021e3b21137bcc0bdd031ec91b6b5b129155137b9c197affe8f7")
