-- Lua provided by RyzenAPI 
-- Game: Cyborg Arena
addappid(706440)
addappid(706441, 1, "91af963fb0050ac2769a7039920f38c119016ece4dfd2d20243b2af52a83afe4")
