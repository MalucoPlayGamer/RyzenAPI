-- Lua provided by RyzenAPI
-- Game: Game: Cyborg Arena

-- MAIN APPLICATION
addappid(706440)
-- Game: addappid(706440)

-- MAIN APP DEPOTS / PACKAGES
addappid(706441, 1, "91af963fb0050ac2769a7039920f38c119016ece4dfd2d20243b2af52a83afe4")
