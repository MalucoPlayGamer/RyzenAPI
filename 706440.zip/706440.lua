-- Lua provided by RyzenAPI
-- Game: Cyborg Arena

-- MAIN APPLICATION
addappid(706440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(706441, 1, "91af963fb0050ac2769a7039920f38c119016ece4dfd2d20243b2af52a83afe4")

