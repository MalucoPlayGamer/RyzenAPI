-- Lua provided by SkyAPI 
-- Game: Fausts Alptraum
addappid(574740)
addappid(574741, 1, "5ad223a0fc45ab5f22d6063df09777c9248aaa4acd44ed63e6763ce1ea264e5c")
addappid(574742, 1, "f3f82856b7d2731ca7c45c54c0cec2db9d5e043a3537d0f14810b9e1b1b8e20d")
addappid(574743, 1, "795e6982cc38e30788f261cd6ceb6bfb2b61d942fea43d54fab720858fb56101")
addappid(777700)
