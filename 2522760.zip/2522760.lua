-- Lua provided by RyzenAPI
-- Game: Game: Music Man 2: New land

-- MAIN APPLICATION
addappid(2522760)
-- Game: addappid(2522760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522761, 1, "179bbabfd30572c70ffaf53b01ee858308c597905e0d738f52a8e8a58f1ec095")
