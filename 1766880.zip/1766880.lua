-- Lua provided by RyzenAPI
-- Game: Tetris® Effect: Connected Original Soundtrack

-- MAIN APPLICATION
addappid(1766880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766881, 1, "0b78322cdb8fc38e53b4c44b48d13409820ef432ddd756550550e7502bfb348b")
addappid(1766882, 1, "cdb7a7a08c728f4b9aabe99ecad20e63995aa7f94c0074bc22184b88c84cb074")

