-- Lua provided by RyzenAPI
-- Game: Game: Wood and Flesh: A Candleforth Short Story

-- MAIN APPLICATION
addappid(3411660)
-- Game: addappid(3411660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3411661, 1, "74dbae447e80c4856414e52ad5efe122104bf49ea6a8268e0da82bb5582ce836")
