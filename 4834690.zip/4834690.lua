-- 4834690's Lua and Manifest Created by Hubcap Manifest
-- Airplane Flight Simulator : Combat Zone
-- Created: August 06, 2026 at 13:50:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4834690, 1, "d965a573a7589819aa3147877fbb7db1cd39d7c660554743ed97e6c6f741aab6") -- Airplane Flight Simulator : Combat Zone
-- MAIN APP DEPOTS
addappid(4834691, 1, "af05db6ea1c52a18f48e1459df6b8447a370d0c437d921e2533c7d1887faf6ee") -- Depot 4834691
setManifestid(4834691, "575715295475296754", 7724656435)