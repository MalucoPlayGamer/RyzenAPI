-- Lua provided by RyzenAPI
-- Game: Airplane Flight Simulator : Combat Zone

-- MAIN APP DEPOTS / PACKAGES
addappid(4834690, 1, "d965a573a7589819aa3147877fbb7db1cd39d7c660554743ed97e6c6f741aab6") -- Airplane Flight Simulator : Combat Zone
addappid(4834691, 1, "af05db6ea1c52a18f48e1459df6b8447a370d0c437d921e2533c7d1887faf6ee") -- Depot 4834691

