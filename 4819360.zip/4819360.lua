-- 4819360's Lua and Manifest Created by Hubcap Manifest
-- Marie's Adventure
-- Created: August 12, 2026 at 23:20:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4819360) -- Marie's Adventure
-- MAIN APP DEPOTS
addappid(4819361, 1, "8ac8ff215e47867897cfaa587950bd9164a58eaf2ab8e019c693ab1ac2543514") -- Depot 4819361
setManifestid(4819361, "1925643631382654291", 2308754588)