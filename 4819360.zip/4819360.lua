-- Lua provided by RyzenAPI
-- Game: Marie's Adventure

-- MAIN APPLICATION
addappid(4819360) -- Marie's Adventure

-- MAIN APP DEPOTS / PACKAGES
addappid(4819361, 1, "8ac8ff215e47867897cfaa587950bd9164a58eaf2ab8e019c693ab1ac2543514") -- Depot 4819361

