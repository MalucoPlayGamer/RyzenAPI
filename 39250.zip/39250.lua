-- Lua provided by RyzenAPI
-- Game: addappid(39250)

-- MAIN APPLICATION
addappid(39250)

-- MAIN APP DEPOTS / PACKAGES
addappid(23391,0,"69bf246191f67e5c2cf6c0b525f2c537b56dcb6860af118eaf00b2bc12fc6f5d")
