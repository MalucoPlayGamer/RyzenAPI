-- Lua provided by RyzenAPI
-- Game: addappid(3760560)

-- MAIN APPLICATION
addappid(3760560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3760560,0,"ef93848c7ac7c39965bed85d4945d4a585bdd5b90781413dae2b2f5dff32b94c")
