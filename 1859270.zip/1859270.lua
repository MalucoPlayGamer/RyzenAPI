-- Lua provided by RyzenAPI
-- Game: Perfect Partner

-- MAIN APPLICATION
addappid(1859270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859271, 1, "f1269ec2b149f4f01f52ddf68248a1c6f92eceac6d777d3e17929fcc795e31d4")
