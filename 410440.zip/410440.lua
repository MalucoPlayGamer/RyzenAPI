-- Lua provided by RyzenAPI
-- Game: Vertigo Void

-- MAIN APPLICATION
addappid(410440)
-- Game: addappid(410440)

-- MAIN APP DEPOTS / PACKAGES
addappid(410441, 1, "6a5ca9da9e596999ede4f21f84f652a84ba695b50e8e4133fb650095aef59a2d")
addappid(410442, 1, "bfb91279730fc0b072f184cbe65466b174337deb04cf4f768b82f45b7f6e3ac0")
addappid(410443, 1, "7fe68fdfece0f7b0d0d0bfdb3771c343f217f041b7ef8860f9c3fff631bbebe0")
addappid(410444, 1, "4d1ca2e907b91286613a44232beb83ba10c2bed47ab9203c1b1005f56ce009fd")
addappid(410445, 1, "c2933c9958de611eb14e2483810adf69e80090fd4cd03a802076928bde67e916")
