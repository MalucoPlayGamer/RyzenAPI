-- Lua provided by RyzenAPI
-- Game: Flesh Made Fear

-- MAIN APPLICATION
addappid(3316350)
addappid(4013570)
addappid(4013580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3316351,0,"9438fb5ebe984f693124171759ed5db8330811269311a5534e2aaa50787fe675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4108320)
