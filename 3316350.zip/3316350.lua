-- Lua provided by RyzenAPI
-- Game: Flesh Made Fear

-- MAIN APPLICATION
addappid(3316350)
addappid(4013570)
addappid(4013580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3316351,0,"9438fb5ebe984f693124171759ed5db8330811269311a5534e2aaa50787fe675")

