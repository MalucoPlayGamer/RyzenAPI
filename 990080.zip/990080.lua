-- Lua provided by RyzenAPI
-- Game: Hogwarts Legacy

-- MAIN APPLICATION
addappid(990080)
addappid(1880830)
addappid(1880832)
addappid(1880833)
addappid(1880837)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(990081, 1, "99edd7f3221635d93481770b28ebac240488e1f42cf16f01e5a4e744b0944da6")
addappid(990082, 1, "ac55581fbdef1f6687f91654d435e2d4c395d2fa56eb5aba4fa52d708118157e")
addappid(990083, 1, "2326f907ccd6ebfc8235495fbb2abd7b12d814a3228cd3b0bf480f7c602c87f5")
addappid(990084, 1, "f043f2ca0cfbbaf5fcb6e30d4beb1a20ba5ef293db11dc4e5521bdfa8a7fdfe0")
addappid(990085, 1, "b7d07ff314786df30f9d32266a2e88cd026fabaffbd2567dbc1637cd319ef996")
addappid(990086, 1, "d9814846faaa5f83e45151bec5190062e320c6b9a6842e7722ed51293a29a667")
addappid(990087, 1, "42c46e0e1520cefc9f4120f00fca640bc83f48b322e7b19ad9530538d9cbee75")
addappid(990088, 1, "81c364d84279c2fafb7960d0aabd75e7e371ad27f275484d99ef5734e4c00d95")
addappid(990089, 1, "21886ab063a78ccf9b676f311597b895c73a1410cd9f7e0e3e7b4e99b82f1e6b")

