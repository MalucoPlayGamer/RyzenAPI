-- Lua provided by RyzenAPI
-- Game: New Year Girls

-- MAIN APPLICATION
addappid(1845610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845611, 1, "273ed5af0d4c37eec4222cc07edfdfdc07658ba88c978e9aeeb97d499ac0690b")

