-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Underground

-- MAIN APPLICATION
addappid(3009780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009781, 1, "b93f10acfb200f0e42273b7043ed1fedcfd16e3fa0c00082c713b86b288c2089")
