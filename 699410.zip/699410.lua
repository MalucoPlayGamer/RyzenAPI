-- Lua provided by RyzenAPI
-- Game: addappid(699410)

-- MAIN APPLICATION
addappid(699410)

-- MAIN APP DEPOTS / PACKAGES
addappid(699411, 1, "fbd58e9d59d3c33dcf98de27e57be40ad7a10daeabad335486a1fa12a8311576")
