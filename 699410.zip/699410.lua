-- Lua provided by RyzenAPI 
-- Game: Labyrinthian
addappid(699410)
addappid(699411, 1, "fbd58e9d59d3c33dcf98de27e57be40ad7a10daeabad335486a1fa12a8311576")
