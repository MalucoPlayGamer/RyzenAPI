-- Lua provided by RyzenAPI
-- Game: addappid(2407310)

-- MAIN APPLICATION
addappid(2407310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407311, 1, "6706426eedf40bdb900b75732c2fcd3bf90a6dd5d93c8cf2c28e7f8aa5d32f21")
