-- Lua provided by RyzenAPI
-- Game: Atomic Heart - Original Soundtrack

-- MAIN APPLICATION
addappid(2303120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303121, 1, "6fd3db1eba411d9ecc68741d7ebf12f38bfb738c8578dd71419af57f7b2f73c4")
addappid(2303122, 1, "49808584cc51f185a98e76678db9045fcfccc7474b9bccb847a92aa223ed8aff")
