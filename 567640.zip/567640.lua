-- Lua provided by RyzenAPI
-- Game: Danganronpa V3: Killing Harmony

-- MAIN APPLICATION
addappid(567640)

-- MAIN APP DEPOTS / PACKAGES
addappid(567641, 1, "9970cbb9f5643bcca6f9a4a79fd477c623bd86b920e15e1b5d305928b99b6940")
addappid(567642, 1, "12906a228da73773ee68b88cb8dda37c3a385f65cab8e7ef355e53bbb648ff20")
addappid(567643, 1, "523db6fe1fbeca55f4d7c4b053f5ccb95fbb155a23d6b1d67fac210b04fcc102")
addappid(567644, 1, "c61bb68902b01ef6e3d5d1ccf5514fdbb153ddb9df5e2ea6abf67939d6162723")
addappid(567645, 1, "69c35716aa9c4bd28a5f5dcec3fffa15922690b8b1b612e81992871b50c1d937")
addappid(567646, 1, "996f6d53be10b91a1e3c54a9ffc6688732de2da64f7701b242cfc0865d6ae178")
addappid(567649, 1, "ce16809a2ece4721017e47e7835a0158561444aab4053f41d1ea7bb904a673dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
