-- Lua provided by SkyAPI 
-- Game: CurseBreaker Demo
addappid(3007010)
addappid(3007011, 1, "a8302fe4bf99025f2ba7655d04d843e9aeb8c31dfcf8b7afbbc940360e79d0fc")
