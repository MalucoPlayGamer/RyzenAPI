-- Lua provided by RyzenAPI
-- Game: Game: CurseBreaker Demo

-- MAIN APPLICATION
addappid(3007010)
-- Game: addappid(3007010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007011, 1, "a8302fe4bf99025f2ba7655d04d843e9aeb8c31dfcf8b7afbbc940360e79d0fc")
