-- Lua provided by RyzenAPI
-- Game: addappid(3037940)

-- MAIN APPLICATION
addappid(3037940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037941, 1, "6fa8cc649de9e13409589b1d131a2eab285f6e7d24d15c08c1d4ee2268a876fd")
