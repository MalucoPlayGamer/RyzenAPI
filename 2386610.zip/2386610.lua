-- Lua provided by RyzenAPI
-- Game: Wandering Skies

-- MAIN APPLICATION
addappid(2386610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386611, 1, "4f4207d875512078b8a7d8bbac8e5434b5037de07c52faedb9a268a8590255da")
