-- Lua provided by RyzenAPI 
-- Game: Kimi ga Nozomu Eien: Enhanced Edition
addappid(1777440)
addappid(1777441, 1, "42af52393d0d56b75c7b2f6f94407fccd75084dfa7870ae3bc145806a84f2731")
addappid(3112140)
