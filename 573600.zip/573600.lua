-- Lua provided by RyzenAPI
-- Game: Think of the Children

-- MAIN APPLICATION
addappid(573600)

-- MAIN APP DEPOTS / PACKAGES
addappid(573603,0,"f5c3ed10a74949d732037403a6d6dae47e48b72977720bd4c129d4f3b030a1be")
addappid(573604,0,"1bc4ea787d582dfe1e183df09dd56218f97ef43f04c4eefb47d35d0f29951921")

