-- Lua provided by RyzenAPI
-- Game: Carth

-- MAIN APPLICATION
addappid(1526430)
-- Game: addappid(1526430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526431, 1, "2027467a005eda7b103568fb7148322f016af2bd6f40711d90bd00801ea198ea")
