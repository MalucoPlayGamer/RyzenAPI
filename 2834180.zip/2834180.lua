-- Lua provided by RyzenAPI
-- Game: AppID 2834180

-- MAIN APPLICATION
addappid(2834180)
-- Game: addappid(2834180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834181, 1, "d8f16b915707d869d82b07e8dbfde6d516a39c61d60be54db0a9b04195e62186")
