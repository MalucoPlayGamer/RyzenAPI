-- Lua provided by RyzenAPI
-- Game: Game: 夢現しろっぷ - Dreamy Syrup -

-- MAIN APPLICATION
addappid(3586280)
-- Game: addappid(3586280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586281, 1, "2f30c97a6783ac00d24c769d398aced9c2e6c8e0aa5c94bda09c55ff476452c5")
