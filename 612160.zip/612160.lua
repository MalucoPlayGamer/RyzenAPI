-- Lua provided by SkyAPI 
-- Game: Splinter Zone
addappid(612160)
addappid(612161, 1, "54ac9dd42b32e5ed3ea249477becef58e692ea6c6377fd2159002e17bc2f08c0")
