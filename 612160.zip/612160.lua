-- Lua provided by RyzenAPI
-- Game: Splinter Zone

-- MAIN APPLICATION
addappid(612160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(612161, 1, "54ac9dd42b32e5ed3ea249477becef58e692ea6c6377fd2159002e17bc2f08c0")

