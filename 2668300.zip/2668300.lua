-- Lua provided by RyzenAPI
-- Game: 2668300

-- MAIN APPLICATION
addappid(2668300)
-- Game: addappid(2668300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668301, 1, "5631200e24b6ddad73cdbcce58d3356c56181caf1f931a3b815c5f376afb8853")
