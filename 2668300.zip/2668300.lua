-- Lua provided by RyzenAPI
-- Game: Game: Sakura Segment 1.0

-- MAIN APPLICATION
addappid(2668300)
-- Game: addappid(2668300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668301, 1, "5631200e24b6ddad73cdbcce58d3356c56181caf1f931a3b815c5f376afb8853")
