-- Lua provided by RyzenAPI
-- Game: addappid(2615620)

-- MAIN APPLICATION
addappid(2615620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615621, 1, "765fcfcf65d42b96132e3f8228baa35a5b22915067b21fe51113fe947acd0549")
