-- Lua provided by RyzenAPI
-- Game: addappid(1506260)

-- MAIN APPLICATION
addappid(1506260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506261, 1, "0b1031e55a3d7d51b3f3307e8e6ed5f63ec02f42d31fdd323547491bdbcad26f")
