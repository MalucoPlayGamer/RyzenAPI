-- Lua provided by RyzenAPI
-- Game: Eternium

-- MAIN APPLICATION
addappid(981600)
-- Game: addappid(981600)

-- MAIN APP DEPOTS / PACKAGES
addappid(981601, 1, "40c94380d0799588ee391ece523dc9d596e043b428a73e7f106c586f70b83489")
