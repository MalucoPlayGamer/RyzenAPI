-- Lua provided by RyzenAPI
-- Game: The Girlfriend From My Novel Demo

-- MAIN APPLICATION
addappid(2791200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791201, 1, "43c1e7e650d458d6cdf6a28470e716e564a649985941a60a350ba00a94aa883c")

