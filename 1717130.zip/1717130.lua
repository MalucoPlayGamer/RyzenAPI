-- Lua provided by RyzenAPI
-- Game: 1717130

-- MAIN APPLICATION
addappid(1717130)
-- Game: addappid(1717130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717131, 1, "eed138e3997cb451fd25c54092795325eb8a5bf62061d7bcd23f9340fae39bae")
