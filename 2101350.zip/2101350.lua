-- Lua provided by RyzenAPI 
-- Game: AppID 2101350
addappid(2101350)
addappid(2101351, 1, "2c411cf5d815637e369cb0cf95efd22146b57499e8eb0a54322bc813505f0b61")
