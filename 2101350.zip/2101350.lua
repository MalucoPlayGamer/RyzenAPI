-- Lua provided by RyzenAPI
-- Game: addappid(2101350)

-- MAIN APPLICATION
addappid(2101350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101351, 1, "2c411cf5d815637e369cb0cf95efd22146b57499e8eb0a54322bc813505f0b61")
