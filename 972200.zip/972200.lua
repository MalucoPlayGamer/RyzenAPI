-- Lua provided by RyzenAPI
-- Game: 祛魅·入灭（祛魅2） - Disenchantment Nirvana

-- MAIN APPLICATION
addappid(972200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(972201, 1, "b50855a3300c81b002726e36415c3d37168e9f289913d332422830f34599a063")
addappid(987430, 0, "1a174fb6e56e36c852f1957e296869c066554f6b199a0377bd86a9e21cc08c81")
addappid(1496830, 0, "3e16edb4b3a32e977acc49b75b77828c9b906a740af82cac785918aac5570fcf")

