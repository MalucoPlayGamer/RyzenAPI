-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: The Deadly Device

-- MAIN APPLICATION
addappid(220420)
addappid(954020)

-- MAIN APP DEPOTS / PACKAGES
addappid(220421, 1, "f1eff53ba7b22b2228f37e74c78457a9d29e92a5a46b20b6d8c83897b603ebcc")
addappid(220422, 1, "a250f897c300eb40b4c0dc6c3728038accb1120afb1e20c4c298aa5dece978ac")
