-- Lua provided by RyzenAPI
-- Game: Cave Digger 2

-- MAIN APPLICATION
addappid(2392740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392741, 1, "cebfd4d54665fecf45e611769fdc18100237712937f646b2dc76e9af630ed169")

