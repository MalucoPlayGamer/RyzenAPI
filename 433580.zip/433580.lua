-- Lua provided by RyzenAPI
-- Game: Timelapse

-- MAIN APPLICATION
addappid(433580)

-- MAIN APP DEPOTS / PACKAGES
addappid(433581, 1, "07aade67eafc7c451575722c1e8d0277feb4d63fd122bfffd264ce1b17f45632")
addappid(433582, 1, "852a60d635a2a8058d6bffc46e0b19f456691ed60a991fe86fdff8d9615107f1")
