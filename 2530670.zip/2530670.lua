-- Lua provided by RyzenAPI
-- Game: addappid(2530670)

-- MAIN APPLICATION
addappid(2530670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530671, 1, "ceb56ede6819e18a30d6e2528a31225574f7a0a9d695e06302229ae27c0cc630")
