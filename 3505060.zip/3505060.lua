-- Lua provided by RyzenAPI
-- Game: addappid(3505060)

-- MAIN APPLICATION
addappid(3505060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3505061, 1, "6a077f1ce966cae3c985181bf333b929e04ddec8bcf2956e4cb722046b78d625")
