-- Lua provided by RyzenAPI
-- Game: Static

-- MAIN APPLICATION
addappid(1043560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043561, 1, "290c730b76c318e1a491d5cc4aec58c216b489d351317b918a0960941648b1ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
