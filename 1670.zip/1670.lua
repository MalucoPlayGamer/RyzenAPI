-- Lua provided by RyzenAPI
-- Game: 1670

-- MAIN APPLICATION
addappid(1670)
-- Game: addappid(1670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671, 1, "a0c665f43004cc32be5473baeb449e19fe8eec29d21a4db40c5807c198a60555")
addappid(1672, 1, "2a23ac8cdc159522272306f0216442f82c4b40b01b0c6acdc7bf9e1d436aedcc")
