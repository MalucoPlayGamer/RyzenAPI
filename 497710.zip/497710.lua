-- Lua provided by RyzenAPI
-- Game: AppID 497710

-- MAIN APPLICATION
addappid(497710)
addappid(595020)

-- MAIN APP DEPOTS / PACKAGES
addappid(497711, 1, "c8e6a6ecd2fdb260e388ef4bd06474a64bdab31092fc2cf2b8b7bf56d0e3240d")

