-- Lua provided by RyzenAPI
-- Game: 2274590

-- MAIN APPLICATION
addappid(2274590)
-- Game: addappid(2274590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274591, 1, "e9565ad2b939c9c6664a90a0148b2003e61acd02fdc2c08446d7a720028a9c6f")
