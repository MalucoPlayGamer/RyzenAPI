-- Lua provided by RyzenAPI
-- Game: AppID 463170

-- MAIN APPLICATION
addappid(463170)

-- MAIN APP DEPOTS / PACKAGES
addappid(463171, 1, "9de2d49c17c98da83777f567f7abe2138a17ba9bae6b24e41d73a59158bd7d5f")
addappid(463172, 1, "bf85920d811775a6a590d6a34cb60d5c6a1fbc4dce46d8c997278b9e8b431d95")
addappid(463175, 1, "9d9575e3fc6f1919d61f9c97f7fee63284798e212a979c82ff97f1e4ebbcee16")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
