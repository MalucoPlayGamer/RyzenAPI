-- Lua provided by RyzenAPI
-- Game: AppID 463170

-- MAIN APPLICATION
addappid(463170)
-- Game: addappid(463170)

-- MAIN APP DEPOTS / PACKAGES
addappid(463171, 1, "9de2d49c17c98da83777f567f7abe2138a17ba9bae6b24e41d73a59158bd7d5f")
addappid(463172, 1, "bf85920d811775a6a590d6a34cb60d5c6a1fbc4dce46d8c997278b9e8b431d95")
addappid(463175, 1, "9d9575e3fc6f1919d61f9c97f7fee63284798e212a979c82ff97f1e4ebbcee16")
