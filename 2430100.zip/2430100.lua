-- Lua provided by RyzenAPI
-- Game: 2430100

-- MAIN APPLICATION
addappid(2430100)
-- Game: addappid(2430100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430101, 1, "ced865659cc2d6e0e7a3c88fc72958f16ed7e896895c025c5960c43d345101be")
