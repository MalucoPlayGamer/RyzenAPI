-- Lua provided by RyzenAPI
-- Game: Game: Peculiar Tales of Mid-Lake Pavilion

-- MAIN APPLICATION
addappid(1796180)
-- Game: addappid(1796180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796181, 1, "9594a9a000b1d93911605477f4fd77af64bf7866a802be11903100b22073832a")
