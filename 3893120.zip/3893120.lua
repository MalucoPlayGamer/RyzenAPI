-- Lua provided by RyzenAPI
-- Game: Hell Clock Original Soundtrack

-- MAIN APPLICATION
addappid(3893120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3893122,0,"92fa4198711af9cbff1be1f3f7a6b4e9a60f9988b3df20f104e8a693444288e4")
