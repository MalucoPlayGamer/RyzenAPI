-- Lua provided by RyzenAPI
-- Game: Mimic Hunter

-- MAIN APPLICATION
addappid(657400)

-- MAIN APP DEPOTS / PACKAGES
addappid(657401,0,"b9f7f2fa1679075851068eb43bf05571161079a08421aa4f93313039465c2a56")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
