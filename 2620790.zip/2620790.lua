-- Lua provided by RyzenAPI
-- Game: Star Trek: Infinite - Galactic Tracks

-- MAIN APPLICATION
addappid(2620790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620790,0,"a6d85796b48a5282b2bad610645e30724aa5982220551887f67de294f5c7dd8e")
