-- Lua provided by RyzenAPI
-- Game: Beat Saber: Lady Gaga, Ariana Grande - 'Rain On Me (with Ariana Grande)'

-- MAIN APPLICATION
addappid(1812886)
-- Game: addappid(1812886)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812886,0,"ed9c9683c871144bf233e7940c68c0750bf95e2aa39cf40c35f29d02b20ce710")
