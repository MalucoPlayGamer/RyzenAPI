-- Lua provided by RyzenAPI
-- Game: City of Stories: Stephan's Journey Collector's Edition

-- MAIN APPLICATION
addappid(3803080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3803081, 1, "e543fc8deb30b3ab831cde126b778f309d035f054653a3b6452ee63923ae86dd")
