-- Lua provided by RyzenAPI
-- Game: MAMIYA

-- MAIN APPLICATION
addappid(1394930)
addappid(2591300)
addappid(3216010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1394931, 1, "0f2e1e2fbf8401fc39f26cd61b2e2757e30bdb14610d101f47b035df8fc60f36")

