-- Lua provided by RyzenAPI
-- Game: MAMIYA

-- MAIN APPLICATION
addappid(1394930)
-- Game: addappid(1394930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394931, 1, "0f2e1e2fbf8401fc39f26cd61b2e2757e30bdb14610d101f47b035df8fc60f36")
