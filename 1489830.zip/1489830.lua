-- Lua provided by SkyAPI 
-- Game: Bouboum
addappid(1489830)
addappid(1489831, 1, "0f21fb9864704c62ec94393e980135314909046e625ed7ec0611a981aa99b544")
