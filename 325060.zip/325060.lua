-- Lua provided by RyzenAPI 
-- Game: AppID 325060
addappid(325060)
addappid(325061, 1, "493d744c8d6559f627e9b2cfe779cc6399b3042d60f6ff9dd7740da23ce0e90d")
