-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228983)
addappid(228985)
addappid(229003)
addappid(545270)
-- Game: addappid(545270)

-- MAIN APP DEPOTS / PACKAGES
addappid(545273,0,"580efdcefb9b6c21db6a844eab2ce2d2dd3daccf6a9a939e4d7c636b16e1c694")
