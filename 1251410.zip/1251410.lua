-- Lua provided by RyzenAPI 
-- Game: Golf Ace
addappid(1251410)
addappid(1251411, 1, "ea0c4c3ec46f5fe5b4cf46695877f67a33930569a3aa926702f1a6148d921f52")
