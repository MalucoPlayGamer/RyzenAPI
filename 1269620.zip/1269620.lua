-- Lua provided by RyzenAPI
-- Game: Puzzle - STONE BLOCKS

-- MAIN APPLICATION
addappid(1269620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269621, 1, "f07a2d76193c0b50b44e12148273cbeee8c13b3d15d1dd7e4903f9093d1f66ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1464310)
addappid(1464311)
addappid(1464312)
addappid(1485790)
addappid(1506120)
