-- Lua provided by RyzenAPI
-- Game: Puzzle - STONE BLOCKS

-- MAIN APPLICATION
addappid(1269620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269621, 1, "f07a2d76193c0b50b44e12148273cbeee8c13b3d15d1dd7e4903f9093d1f66ea")

