-- Lua provided by SkyAPI 
-- Game: Horus IDLE
addappid(1507510)
addappid(1507511, 1, "1e1505eb4215c1df61db8d96aad77603f120281c5caf010ab883b25d33dc6a80")
