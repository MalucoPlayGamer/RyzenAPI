-- Lua provided by RyzenAPI
-- Game: Horus IDLE

-- MAIN APPLICATION
addappid(1507510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507511, 1, "1e1505eb4215c1df61db8d96aad77603f120281c5caf010ab883b25d33dc6a80")
