-- Lua provided by RyzenAPI
-- Game: Game: Tower of God

-- MAIN APPLICATION
addappid(1279770)
-- Game: addappid(1279770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279771, 1, "7e32e61fa945dede3b047717f53856ce39086aeeae4b3ed10ddf18b0318250e2")
