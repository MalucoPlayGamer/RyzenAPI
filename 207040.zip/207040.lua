-- Lua provided by RyzenAPI
-- Game: Game: AppID 207040

-- MAIN APPLICATION
addappid(207040)
-- Game: addappid(207040)

-- MAIN APP DEPOTS / PACKAGES
addappid(207041, 1, "03b6eadcd060f5d214d8d9a6659abad10a44d8bc3131a5363ba14d7c3e33d06b")
