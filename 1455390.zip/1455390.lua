-- Lua provided by RyzenAPI 
-- Game: UBOAT: The Silent Wolf VR
addappid(1455390)
addappid(1455391, 1, "a9853de9b4fe2d6c25aea749a586a9c7bb5c07265653755b6e06d16918dcada1")
