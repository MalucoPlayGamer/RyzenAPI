-- Lua provided by RyzenAPI
-- Game: Grimlord

-- MAIN APPLICATION
addappid(1910860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1910861, 1, "188097d1cc92bb96dee16ea6fa1f400e075d0c99de8cf1d49307cc25c6215a15")

