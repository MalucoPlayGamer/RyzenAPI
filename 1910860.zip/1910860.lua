-- Lua provided by RyzenAPI
-- Game: 1910860

-- MAIN APPLICATION
addappid(1910860)
-- Game: addappid(1910860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1910861, 1, "188097d1cc92bb96dee16ea6fa1f400e075d0c99de8cf1d49307cc25c6215a15")
