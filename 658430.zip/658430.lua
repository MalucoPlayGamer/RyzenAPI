-- Lua provided by RyzenAPI
-- Game: Game: AppID 658430

-- MAIN APPLICATION
addappid(658430)
-- Game: addappid(658430)

-- MAIN APP DEPOTS / PACKAGES
addappid(658431, 1, "09a15824976edc0938a8f2b9d03315e5d643c3ad0da2fae4cd2d4abd7992d36d")
