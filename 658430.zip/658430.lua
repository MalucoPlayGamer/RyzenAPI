-- Lua provided by SkyAPI 
-- Game: AppID 658430
addappid(658430)
addappid(658431, 1, "09a15824976edc0938a8f2b9d03315e5d643c3ad0da2fae4cd2d4abd7992d36d")
