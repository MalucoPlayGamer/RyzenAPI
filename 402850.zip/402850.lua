-- Lua provided by SkyAPI 
-- Game: Miner Mayhem
addappid(402850)
addappid(402851, 1, "c96b275449b5c335d3f67c61782286c8c44306b1d45508b1f4f72761ff97796f")
addappid(402852, 1, "86ab206c3bc23f9cdd8b831b467fa16689038d13d6b0201081311a24e61e7a07")
addappid(402853, 1, "c3e37cb0a8aed0a1c29e3c9b46b0306f2bf5a2566d91afec9e0eadeb4a2e0464")
