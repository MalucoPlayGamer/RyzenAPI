-- Lua provided by RyzenAPI
-- Game: Comixxx Jixxaw

-- MAIN APPLICATION
addappid(1805980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805981, 1, "3cfb933d410c1ae254a88d78bc3a5db5f098470d4d9897de004170a04ba55808")

