-- Lua provided by SkyAPI 
-- Game: Comixxx Jixxaw
addappid(1805980)
addappid(1805981, 1, "3cfb933d410c1ae254a88d78bc3a5db5f098470d4d9897de004170a04ba55808")
