-- Lua provided by RyzenAPI
-- Game: Comixxx Jixxaw

-- MAIN APPLICATION
addappid(1805980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1805981, 1, "3cfb933d410c1ae254a88d78bc3a5db5f098470d4d9897de004170a04ba55808")

