-- Lua provided by RyzenAPI
-- Game: Starship Troopers: Extermination

-- MAIN APPLICATION
addappid(1268750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268751, 1, "4c9adfd6fcc55cac391befdc3c63c0bd233339efd4b1d755bbf24f3170ed86e8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3205210)
addappid(3205220)
addappid(3205230)
addappid(3205240)
addappid(3353190)
addappid(3353210)
addappid(3353220)
addappid(3714670)
addappid(3842930)
addappid(4319560)
addappid(4319570)
addappid(4735900)
addappid(4735910)
