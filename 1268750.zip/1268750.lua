-- Lua provided by RyzenAPI
-- Game: Starship Troopers: Extermination

-- MAIN APPLICATION
addappid(1268750)
-- Game: addappid(1268750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268751, 1, "4c9adfd6fcc55cac391befdc3c63c0bd233339efd4b1d755bbf24f3170ed86e8")
