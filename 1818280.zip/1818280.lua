-- Lua provided by SkyAPI 
-- Game: AppID 1818280
addappid(1818280)
addappid(1818281, 1, "59cfffe4a6487559725f0603d9bb80d8fd3479a6471eba3dcedbbe917c66a449")
addappid(1818282, 1, "a66ccf572dd2dfd5ee6e2953a31c6870769f41ccc7f12f9b05ad7eee95aee921")
addappid(1818283, 1, "8285208e13c3c14ad0fa25f3d4269cec97bf840a59a6da103a7ed3746cc41fc2")
