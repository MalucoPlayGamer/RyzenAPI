-- Lua provided by RyzenAPI
-- Game: addappid(978863)

-- MAIN APPLICATION
addappid(978863)

-- MAIN APP DEPOTS / PACKAGES
addappid(978863,0,"b315ec666186e8b6d801c5e664bd999d987ac634a51fd9133e65f752df1c8bad")
