-- Lua provided by RyzenAPI
-- Game: Extreme Exorcism

-- MAIN APPLICATION
addappid(334100)
addappid(334101)

-- MAIN APP DEPOTS / PACKAGES
addappid(334102,0,"b9228ce4c2d9233305326881d584850f9419d364244b4d494f3b0b4750c4ccdd")

