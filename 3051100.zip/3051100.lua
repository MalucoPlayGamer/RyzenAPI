-- Lua provided by RyzenAPI
-- Game: addappid(3051100)

-- MAIN APPLICATION
addappid(3051100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3051101, 1, "3d4d57f52538d366c574390a5c504f7a6f8ee72a559e39999e967ff41121fabb")
