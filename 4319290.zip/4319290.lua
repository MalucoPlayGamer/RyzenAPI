-- Lua provided by RyzenAPI
-- Game: Void Cargo: Equilibrium

-- MAIN APP DEPOTS / PACKAGES
addappid(4319290, 1, "05a157f85eb372f5b7415a717ef7434bdb9863c452d0cc4b9ed037966241819c") -- Void Cargo: Equilibrium
addappid(4319292, 1, "837145ef1b014543c9eef82b2c324273e11b9a1ba76b14a4fa66f36202251ffe") -- Depot 4319292
addappid(4319293, 1, "3528f9a1d5c8030f527d39d141ec80cd38ffc1e405a744c50a7ecfbf9eff5dbb") -- Depot 4319293
addappid(4319294, 1, "9d728f006b2c5f466bbd88de1b6c60a836ddad0fdbba645897bdeb17deda532c") -- Depot 4319294
addappid(4319295, 1, "9bab39e0dfbb50ab52fa31ae002357a27cabb9095880953568a04aa84ad82050") -- Depot 4319295
