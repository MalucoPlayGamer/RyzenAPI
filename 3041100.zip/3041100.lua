-- Lua provided by RyzenAPI
-- Game: Shogi

-- MAIN APPLICATION
addappid(3041100)
addappid(3041101)
addappid(3041103)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041102,0,"73e063868e55cd3be626c3ffe3bf16036c1c6d44ec62354650a87c421a2c0fff")

