-- Lua provided by RyzenAPI
-- Game: Game: AppID 967460

-- MAIN APPLICATION
addappid(967460)
-- Game: addappid(967460)

-- MAIN APP DEPOTS / PACKAGES
addappid(967461, 1, "a05ff720b91ffe665d83909a624536d483c71634850e2fa6acd6914abfee383c")
