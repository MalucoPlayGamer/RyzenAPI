-- Lua provided by RyzenAPI
-- Game: 2377700

-- MAIN APPLICATION
addappid(2377700)
-- Game: addappid(2377700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377701, 1, "8102a09b0391b6ec1476ae545673d8ddc634ebc116be919088f400f74fc074c7")
