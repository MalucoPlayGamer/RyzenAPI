-- Lua provided by RyzenAPI
-- Game: Grind Zones

-- MAIN APPLICATION
addappid(327680)

-- MAIN APP DEPOTS / PACKAGES
addappid(327681, 1, "5189c9bbcc6ac294a82217c399d59d1313858a185cc5f842f8492af1573e5419")

