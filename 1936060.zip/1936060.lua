-- Lua provided by RyzenAPI
-- Game: 1936060

-- MAIN APPLICATION
addappid(1936060)
-- Game: addappid(1936060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1936060,0,"f9afdc45cbb56aab93ff1a84717c1c1d6ecb0a3050eb279247437bd903b15a65")
