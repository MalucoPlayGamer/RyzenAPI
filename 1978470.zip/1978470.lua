-- Lua provided by SkyAPI 
-- Game: AppID 1978470
addappid(1978470)
addappid(1978471, 1, "2e6b5b5ee6d1cd9460559d0057d5a6f041ea1e1ae287ae8b37d018487b810a10")
