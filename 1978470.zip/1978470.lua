-- Lua provided by RyzenAPI
-- Game: addappid(1978470)

-- MAIN APPLICATION
addappid(1978470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978471, 1, "2e6b5b5ee6d1cd9460559d0057d5a6f041ea1e1ae287ae8b37d018487b810a10")
