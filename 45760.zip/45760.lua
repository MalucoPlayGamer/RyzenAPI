-- Lua provided by RyzenAPI
-- Game: Ultra Street Fighter® IV

-- MAIN APPLICATION
addappid(45760)
addappid(228983)

-- MAIN APP DEPOTS / PACKAGES
addappid(45761, 1, "57e09e51340949bac89d9a3b1be1274426a0a8c44c04288e78aeee7cebd1afdc")
addappid(45762, 1, "0f3e423d8ebb2d9c2d875bb9d44f676e13cee2feea0f61448af5778f3f27bf90")
addappid(45763, 1, "021020f02f3e53dfb27c215dd29ba45e93912dd1a18c10352f10fbe7c11cbeb4")
addappid(45764, 1, "ea6267f4b30c43759f65516977082415e1ad11bf6c0eaa71b513070efc06bbb9")
addappid(45765, 1, "ac6275726b29b5307f9c08e9e09aadeab062553c74ecd91405f6fd4f881b34e7")
addappid(301660, 0, "6bf7af0f3e6c1d6f19ce09adc0fcae00b25d17bc42ad7d30cb0ae095a6e5a89f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(45790)
addappid(45791)
addappid(45792)
addappid(45793)
addappid(45794)
addappid(45795)
addappid(45796)
addappid(45797)
addappid(45798)
addappid(306610)
addappid(308261)
addappid(308262)
addappid(308263)
addappid(308264)
addappid(308265)
addappid(308266)
addappid(308267)
addappid(308268)
addappid(308269)
addappid(331350)
addappid(331351)
addappid(331352)
addappid(331353)
addappid(331354)
addappid(331355)
addappid(331356)
addappid(331357)
addappid(331358)
addappid(344170)
addappid(344171)
addappid(344172)
addappid(344173)
addappid(344174)
addappid(344175)
addappid(344176)
addappid(344177)
addappid(344178)
