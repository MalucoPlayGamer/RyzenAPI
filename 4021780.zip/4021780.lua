-- 4021780's Lua and Manifest Created by Hubcap Manifest
-- Geo-Political Simulator 2026 Edition
-- Created: May 29, 2026 at 14:43:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(4021780, 1, "ddf12dd1d13a353e31d93c11599c6eb72fc7aa418d378c9c376c8f65d68e1da9") -- Geo-Political Simulator 2026 Edition
-- MAIN APP DEPOTS
addappid(4021781, 1, "438160fadb31dce47aa4f362366f24c7c0457384d6078b216aee9eef19e35e98") -- Depot 4021781
setManifestid(4021781, "5092673682514276067", 10142035237)
addappid(4021782, 1, "c7dd235961562b90c5e823a659cea586df115ac625177a3729b9d9664b7c62a1") -- Depot 4021782
setManifestid(4021782, "8907285335784437028", 516750521)
addappid(4021783, 1, "741b179f662e7e8e0e53058cfb2237365121e323cad1e03e18b9247b389a8a72") -- Depot 4021783
setManifestid(4021783, "4048564619417607940", 32263792)
addappid(4021784, 1, "0e6ad31d07572f3037b3cb31a86cdbdbf5ea574ecfa3028191e9ce012e3f131e") -- Depot 4021784
setManifestid(4021784, "7288186209094298243", 506206763)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4025710) -- Godn Spy Add-on for Geo-Political Simulator 2026 Edition
addappid(4025720) -- Modding Tool Add-on for Geo-Political Simulator 2026 Edition