-- Lua provided by RyzenAPI 
-- Game: Hentai Babe Buffy
addappid(1390040)
addappid(1390041, 1, "47a8cfe56e769c2a09f29189ad9892066725a6008025c978b040fd2e3595b90e")
addappid(1399920, 0, "39d27899281f826fb06240f8d2b675d9afbf30a3166464e19fbee1cc3c7495aa")
addappid(1401960, 0, "3c73cff1de50c3866c7b007c2fff67737eae00238bc19daef53f8da488d74492")
