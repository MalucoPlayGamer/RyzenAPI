-- Lua provided by SkyAPI 
-- Game: AppID 546390
addappid(546390)
addappid(546391, 1, "38721d3844c596007035de652520d971edb2ca409cb45d8bbbcfcc4fa6c862ad")
addappid(546392, 1, "a08e0f203c9e439865c799264e85f01f5e6d6b014637c3360197b61be3a1e057")
