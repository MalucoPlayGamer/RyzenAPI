-- Lua provided by RyzenAPI
-- Game: addappid(868080)

-- MAIN APPLICATION
addappid(868080)
addappid(1035420)

-- MAIN APP DEPOTS / PACKAGES
addappid(868081, 1, "22c66258014dfa1d0ad94e1ccb9fe62173d8ab0a183b73a30c299e349cbdc737")
addappid(868082, 1, "d8a701f757f31f6de993fa087fbcb12e457fde1fb948512973280f9f695c025e")
