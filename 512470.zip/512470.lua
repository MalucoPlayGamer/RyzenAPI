-- Lua provided by RyzenAPI
-- Game: The Pirate: Caribbean Hunt

-- MAIN APPLICATION
addappid(512470)

-- MAIN APP DEPOTS / PACKAGES
addappid(512471, 1, "80bf6914a3a54e1e2a6f9c57d6085d5c16b8ab9e266d98b5e9530a72e139599e")
addappid(512472, 1, "a09da5e86af70dd0c9f19bd38ef56640365afaaeaef788f994cfb50a190d1912")
addappid(512473, 1, "1f76be1d61ff4850fb870176ddea1b9ac5af2756617c59d053ae868b91ba6c80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
