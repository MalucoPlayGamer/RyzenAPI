-- Lua provided by SkyAPI 
-- Game: Yolo Space Hacker
addappid(1341450)
addappid(1341451, 1, "9a3debff3040f324c04b26840c2a6e186d8843b3bea937743705f2364fa5cfc2")
addappid(1341452, 1, "05627c9cf59e07f4b72f4d1138bfe517332c9e449ac2466ecc51b48552a2294c")
addappid(1543680)
