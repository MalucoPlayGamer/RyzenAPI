-- Lua provided by RyzenAPI
-- Game: Yolo Space Hacker

-- MAIN APPLICATION
addappid(1341450)
addappid(1543680)
addappid(1572490)
addappid(1572491)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1341451, 1, "9a3debff3040f324c04b26840c2a6e186d8843b3bea937743705f2364fa5cfc2")
addappid(1341452, 1, "05627c9cf59e07f4b72f4d1138bfe517332c9e449ac2466ecc51b48552a2294c")

