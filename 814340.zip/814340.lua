-- Lua provided by SkyAPI 
-- Game: AppID 814340
addappid(814340)
addappid(814341, 1, "f14d67b2767e4c91c78f089d6272c04bfd312f2aba59aa1b7fdc44246fccca16")
