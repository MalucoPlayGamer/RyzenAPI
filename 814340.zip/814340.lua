-- Lua provided by RyzenAPI
-- Game: Ghoststory

-- MAIN APPLICATION
addappid(814340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(814341, 1, "f14d67b2767e4c91c78f089d6272c04bfd312f2aba59aa1b7fdc44246fccca16")

