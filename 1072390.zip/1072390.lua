-- Lua provided by RyzenAPI
-- Game: BirdGut

-- MAIN APPLICATION
addappid(1072390)

