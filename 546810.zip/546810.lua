-- Lua provided by RyzenAPI
-- Game: 546810

-- MAIN APPLICATION
addappid(546810)
-- Game: addappid(546810)

-- MAIN APP DEPOTS / PACKAGES
addappid(546811, 1, "fa6150f5325fbb69b1b214cde29e0441e92034d68a4b66d1d430cae3c249a55c")
