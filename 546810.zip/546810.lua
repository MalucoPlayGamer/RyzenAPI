-- Lua provided by RyzenAPI 
-- Game: AppID 546810
addappid(546810)
addappid(546811, 1, "fa6150f5325fbb69b1b214cde29e0441e92034d68a4b66d1d430cae3c249a55c")
