-- Lua provided by RyzenAPI
-- Game: Chernobyl: Terrorist Attack

-- MAIN APPLICATION
addappid(546810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(546811, 1, "fa6150f5325fbb69b1b214cde29e0441e92034d68a4b66d1d430cae3c249a55c")

