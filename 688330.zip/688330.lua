-- Lua provided by RyzenAPI
-- Game: Zombie Commando 3D

-- MAIN APPLICATION
addappid(688330)

-- MAIN APP DEPOTS / PACKAGES
addappid(688331, 1, "e913f6a3d43ebeb86c5906b7617cb0cbc32c0b1595e34bd0ce8aa9a53f3cc8e0")

