-- Lua provided by RyzenAPI
-- Game: AppID 609940

-- MAIN APPLICATION
addappid(609940)

-- MAIN APP DEPOTS / PACKAGES
addappid(609941, 1, "7583df2bde9bbe1d53cf4eb6d717cf30a0c941c6330b775716f317ee0514e073")
addappid(609942, 1, "e1be7afd7ed97a03a001d19a2b0994841f9e1e557769a8e2130c2ccb8a5afc9b")
addappid(609943, 1, "806fd136b9d4acc61f327b2369737fe4bc4b8639ba90789316f56031dd153260")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
