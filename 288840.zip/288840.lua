-- Lua provided by RyzenAPI
-- Game: AppID 288840

-- MAIN APPLICATION
addappid(288840)
-- Game: addappid(288840)

-- MAIN APP DEPOTS / PACKAGES
addappid(288841, 1, "2be8bc0a9749f35dc2dbc021216cb990b4bd62ac797804e55033efbaf482843f")
