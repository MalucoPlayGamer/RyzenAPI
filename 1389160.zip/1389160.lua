-- Lua provided by RyzenAPI
-- Game: Dark Fracture: Prologue

-- MAIN APPLICATION
addappid(1389160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389161, 1, "0de2238fa778251aa0ff453f730c48e369372ee80f1151c7f437e2884d34f261")
