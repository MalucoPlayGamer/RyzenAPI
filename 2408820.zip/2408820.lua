-- Lua provided by RyzenAPI
-- Game: addappid(2408820)

-- MAIN APPLICATION
addappid(2408820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408821, 1, "49df48241b28b06fdb2844200bd8a711c1e734ae6fa87a67e97a55a3a22e686c")
