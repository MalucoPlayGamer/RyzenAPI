-- Lua provided by RyzenAPI 
-- Game: Ocean Keeper: Dome Survival
addappid(2845630)
addappid(2845631, 1, "4bcf999a98e53405183975f2f098156b1f7e52f228fb9690e7a6695217b5bac4")
addappid(2845634, 1, "5c6c912d0378b730b1da1906079f6d53a499311404321789bf96e802c4c4f3d7")
