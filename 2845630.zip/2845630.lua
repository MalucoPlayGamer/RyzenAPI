-- Lua provided by RyzenAPI
-- Game: Ocean Keeper: Dome Survival

-- MAIN APPLICATION
addappid(2845630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845631, 1, "4bcf999a98e53405183975f2f098156b1f7e52f228fb9690e7a6695217b5bac4")
addappid(2845634, 1, "5c6c912d0378b730b1da1906079f6d53a499311404321789bf96e802c4c4f3d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
