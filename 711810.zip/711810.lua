-- Lua provided by RyzenAPI
-- Game: Never Split the Party

-- MAIN APPLICATION
addappid(711810)
addappid(801440)
addappid(1307470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(711811, 1, "630727bbc622961df8a5fcdf11d2612865b232bc50aae2e9276ff005eeddbdef")
addappid(711812, 1, "d4eb0477e67ac64e9c3c630a3ad7fa8b903f0ecbfc5585594f8a36336f0c115d")
addappid(711813, 1, "d7b8b5ad0595e3a6e281b164785663072801dd623025e7ac27a3758dcdbb9152")

