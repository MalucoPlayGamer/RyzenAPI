-- Lua provided by RyzenAPI
-- Game: addappid(353550)

-- MAIN APPLICATION
addappid(353550)

-- MAIN APP DEPOTS / PACKAGES
addappid(353551, 1, "2277c1b04f8eede90237372065b47d16a1e6b8cee4c7394a77cbbe83eec47d96")
addappid(353552, 1, "414dcc84b74eca998fb921a671ec52f6727837f13f1a092e69ebe276d8e2b5a4")
