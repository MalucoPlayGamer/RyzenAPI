-- Lua provided by RyzenAPI
-- Game: Game of Drones

-- MAIN APPLICATION
addappid(811940)

-- MAIN APP DEPOTS / PACKAGES
addappid(811942,0,"cfd832c4b7155abb2d37a2598c7b50ad0f9b0e309ead46134759a11a61f2173c")

