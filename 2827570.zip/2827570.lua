-- Lua provided by RyzenAPI
-- Game: addappid(2827570)

-- MAIN APPLICATION
addappid(2827570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827571, 1, "f3567d2663acbfab8ceb3b975c2197c847fdaf0b367e0f5e0dc648625fd08546")
