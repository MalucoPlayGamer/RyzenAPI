-- Lua provided by RyzenAPI
-- Game: My Wifey

-- MAIN APPLICATION
addappid(4240280)

-- MAIN APP DEPOTS / PACKAGES
addappid(4240281,0,"604a0a2839c332c4ea92577b9bf9075dbd619fa9e69f53d59447e27ebea564de")
addappid(4267930,0,"3dcbd3eb073928ce2a44f9c007a822a5a43f1745bd4b0eedb196887ece4db438")
addappid(4267940,0,"21d27bd6d7bad6ccdc97daf7ab456a0559e0cec91950a8ed366963b4ccd708dc")
addappid(4267950,0,"e2829d48b8f2fbd95f175ce1e52bec012cd8608621c41634ff8217cd4d6a5480")
addappid(4267960,0,"12b83a95ac536b5ae4ecc46a336ae9df3131ba38d7f3088c9186c6d5b5a64317")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4248010)
addappid(4267910)
addappid(4267920)
