-- Lua provided by RyzenAPI
-- Game: Ancient Enemy

-- MAIN APPLICATION
addappid(993790)

-- MAIN APP DEPOTS / PACKAGES
addappid(993791, 1, "e1b115c59ce147d3bbebf31b93867a07c32a9c74065d77d8b648b7767c892319")
addappid(993792, 1, "e00efa74b4d5eeb2761e6ed63ef0654b62346f03f4f55bc62883f60df82b1876")

