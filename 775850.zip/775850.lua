-- Lua provided by RyzenAPI
-- Game: Game: AppID 775850

-- MAIN APPLICATION
addappid(775850)
-- Game: addappid(775850)

-- MAIN APP DEPOTS / PACKAGES
addappid(775851, 1, "2f15d70bc339c0444573b73cd97a523e687a7092c38992b422a6e61bf50ec565")
