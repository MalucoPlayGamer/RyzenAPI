-- Lua provided by RyzenAPI
-- Game: 878330

-- MAIN APPLICATION
addappid(878330)
-- Game: addappid(878330)

-- MAIN APP DEPOTS / PACKAGES
addappid(878331, 1, "ca7eda5da965cd2d4c221d1e1a1c822dfce9f730ca8a35a93b71bc82be021595")
