-- Lua provided by RyzenAPI
-- Game: AppID 878330

-- MAIN APPLICATION
addappid(878330)

-- MAIN APP DEPOTS / PACKAGES
addappid(878331, 1, "ca7eda5da965cd2d4c221d1e1a1c822dfce9f730ca8a35a93b71bc82be021595")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
