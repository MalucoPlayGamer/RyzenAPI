-- Lua provided by RyzenAPI
-- Game: 522040

-- MAIN APPLICATION
addappid(522040)
-- Game: addappid(522040)

-- MAIN APP DEPOTS / PACKAGES
addappid(522041, 1, "b48d2d8c7945c414c1924bd69ba9b10362462d7d76b8d014d6b57935eeb8906d")
