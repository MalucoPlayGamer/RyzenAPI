-- Lua provided by RyzenAPI
-- Game: AdVenture Communist

-- MAIN APPLICATION
addappid(462930)

-- MAIN APP DEPOTS / PACKAGES
addappid(462931, 1, "28f19374cc46631c4d9cfac1efbcd8f0aecdbba2386ac2d5755a068620fbfa36")
addappid(462932, 1, "b48426de2d8d15e7fef5d8639a1741fa3cacf8a66e147fa61c6f0ee4e90f7e2c")
