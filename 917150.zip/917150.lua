-- Lua provided by RyzenAPI
-- Game: Game: Godhood

-- MAIN APPLICATION
addappid(917150)
addappid(1117010)
addappid(1117011)
addappid(1117190)
addappid(1117191)
addappid(1117192)
addappid(1117193)
addappid(1117195)
addappid(1117196)
addappid(1117197)
addappid(1117198)
addappid(1117199)
addappid(1117722)
addappid(1117723)
addappid(1117724)
addappid(1118460)
addappid(1118461)
-- Game: addappid(917150)

-- MAIN APP DEPOTS / PACKAGES
addappid(917151, 1, "276d320b66866252819b27c979a1d2416de386672e04edbd2b186ce2a79df1dc")
addappid(917152, 1, "0dfb5ce78bbce3d150a39a828bc65a1484b788614b1726ae2f64abf2ac83dd3f")
addappid(917153, 1, "59e7c3e6f92b229d730cc0a3d31fb7d55c2d8fccc8521c99c3332afab23ac4e4")
addappid(1117012, 0, "de38ca09cf3ccdeb1148c1693159d762b1704a5c5ebc08f249afd362c762557c")
