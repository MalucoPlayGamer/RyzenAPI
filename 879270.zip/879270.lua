-- Lua provided by RyzenAPI
-- Game: 879270

-- MAIN APPLICATION
addappid(879270)
-- Game: addappid(879270)

-- MAIN APP DEPOTS / PACKAGES
addappid(879271, 1, "a276fc90ec727d38602a3d3794958a315aad643a1f2cd0be4ce82238295300d6")
