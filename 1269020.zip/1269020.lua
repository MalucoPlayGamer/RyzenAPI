-- Lua provided by RyzenAPI
-- Game: AppID 1269020

-- MAIN APPLICATION
addappid(1269020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269021, 1, "fd90cbce2f41dd81c0b6fae2cd5f390c768f98801261d448896e0a09a08c88e0")
addappid(1269022, 1, "c7aa98302d60da91f22fe00072501937db4143cd042641a2cdb3ff4600788745")
addappid(1269023, 1, "0b5567466c71f4f3bbedd362e1a0424fb77db5c80e31b5692b63b2b50239d382")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2324620)
addappid(2660340)
