-- Lua provided by SkyAPI 
-- Game: Magnus Imago
addappid(1856550)
addappid(1856551, 1, "5384c1797868833c73e48268e163a5be678b0292d5db0c396b568b606d361bd8")
addappid(1868700)
