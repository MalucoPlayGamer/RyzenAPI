-- Lua provided by RyzenAPI
-- Game: Spikit

-- MAIN APPLICATION
addappid(509110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(509111, 1, "0c832303d824cb5cbbf7db40009112762fa7df8f76ecb7e4748833a7d888d88b")

