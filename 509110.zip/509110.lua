-- Lua provided by RyzenAPI
-- Game: Spikit

-- MAIN APPLICATION
addappid(509110)

-- MAIN APP DEPOTS / PACKAGES
addappid(509111, 1, "0c832303d824cb5cbbf7db40009112762fa7df8f76ecb7e4748833a7d888d88b")
