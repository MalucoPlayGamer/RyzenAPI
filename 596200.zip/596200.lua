-- Lua provided by RyzenAPI 
-- Game: AppID 596200
addappid(596200)
addappid(596201, 1, "4d7de6ea1457ec343958469482d3bcb3981591c68fc39372fa81d8fa27a9cfae")
addappid(958600, 0, "a4270711951b2d646b527b3528e6810d8ca73b62fb1af76f5c11465acfa501c6")
