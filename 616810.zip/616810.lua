-- Lua provided by RyzenAPI
-- Game: 616810

-- MAIN APPLICATION
addappid(616810)
-- Game: addappid(616810)

-- MAIN APP DEPOTS / PACKAGES
addappid(616811, 1, "86feb243df4a4399a9f63852429872393db0b32f370def4028b7f77619879fb7")
