-- Lua provided by RyzenAPI 
-- Game: Kairo
addappid(233230)
addappid(233231, 1, "16fa7b6d3d49c6d18a9718fb2cfe36eb04a57a9d9b8d3a6694cc2384b7605c41")
addappid(233232, 1, "5bba7decfdc89b255e5084eaf571c1f8bc008d54a9fa8080619b27dfe9f4ee5d")
addappid(233233, 1, "880fee1fffe5f49ae26706852329c86d309198ed693c16daccb493d95ae90751")
