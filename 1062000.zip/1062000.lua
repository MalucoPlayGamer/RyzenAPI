-- Lua provided by RyzenAPI
-- Game: Game: Starmancer

-- MAIN APPLICATION
addappid(1062000)
-- Game: addappid(1062000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062001, 1, "51c1064a9409f09d6516549a4fa6eb669331439f9c6fd6d7291ad990eabb3d17")
addappid(1062002, 1, "734f98a59b44da492cf2dcb7ffb43078e6825577ae4451faf39d87f246aa05dd")
addappid(1062003, 1, "ad7f867c2d4c47cdc695cd891a849fbd8eac66b07b0e6248c1a1fd18c6320768")
