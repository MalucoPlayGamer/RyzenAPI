-- Lua provided by RyzenAPI 
-- Game: Child of Lothian
addappid(1761260)
addappid(1761261, 1, "024a188cd9f1a567031cd69bcf02e62abc69d1acecbd90c1a4e1d07db26548f6")
