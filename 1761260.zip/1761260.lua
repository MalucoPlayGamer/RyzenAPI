-- Lua provided by RyzenAPI
-- Game: Child of Lothian

-- MAIN APPLICATION
addappid(1761260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761261, 1, "024a188cd9f1a567031cd69bcf02e62abc69d1acecbd90c1a4e1d07db26548f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
