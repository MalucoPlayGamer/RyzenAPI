-- Lua provided by RyzenAPI 
-- Game: Touhou Shoujo Tale of Beautiful Memories / 東方少女綺想譚
addappid(1124060)
addappid(1124061, 1, "0ca2ee0ebf137a0b273462db062b5095c71045a1673000f656111e695e401aa4")
addappid(1124062, 1, "951ad03f01d3d859c10b6644367749baa0492cfeba6b61ce0c1877192d57058a")
addappid(1124063, 1, "2aa8027c5110f81202e26703b278a4bbacf05a6520f06a10c4b38c3997892caf")
addappid(1124064, 1, "630804c27e8ee793dd9d7f840b5dcf002981339083be387be67a2db7937f9fca")
