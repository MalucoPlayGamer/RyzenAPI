-- Lua provided by RyzenAPI 
-- Game: AppID 3292350
addappid(3292350)
addappid(3292351, 1, "09d32b7f95416cc187044753ef7ab205a39c7b0f2ae5d164f0451cfa693445a3")
