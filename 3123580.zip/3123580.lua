-- Lua provided by RyzenAPI
-- Game: Madness Arena

-- MAIN APPLICATION
addappid(3123580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123581, 1, "214a5604c77f60bead0d98bec2201cb5e92e8cf1bef7df5de85b88436de1012a")
