-- Lua provided by RyzenAPI
-- Game: Champions Tactics Reforged

-- MAIN APPLICATION
addappid(3546740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
