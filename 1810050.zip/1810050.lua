-- Lua provided by RyzenAPI
-- Game: Fortune Avenue

-- MAIN APPLICATION
addappid(1810050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1810052,0,"6575f7dbbb7608bbe7d71afe5321f34372457adf87460acb86992c8001e24249")
