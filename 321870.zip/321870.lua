-- Lua provided by RyzenAPI
-- Game: Silence of the Sleep

-- MAIN APPLICATION
addappid(321870)
addappid(329210)

-- MAIN APP DEPOTS / PACKAGES
addappid(321871, 1, "3b1067459f3f9aa4fc6cfe17b793a3dbc1d43c6a607527d29a478d74a21a9fe2")

