-- Lua provided by RyzenAPI 
-- Game: Silence of the Sleep
addappid(321870)
addappid(321871, 1, "3b1067459f3f9aa4fc6cfe17b793a3dbc1d43c6a607527d29a478d74a21a9fe2")
addappid(329210)
