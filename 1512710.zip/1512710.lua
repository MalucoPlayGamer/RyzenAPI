-- Lua provided by RyzenAPI
-- Game: TunTown

-- MAIN APPLICATION
addappid(1512710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512711, 1, "83e9fbe548e04279ad610b10a432dcfd0d662c17c77ee327dc1ff67aedf87911")
