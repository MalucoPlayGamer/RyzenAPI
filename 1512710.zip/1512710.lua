-- Lua provided by RyzenAPI
-- Game: TunTown

-- MAIN APPLICATION
addappid(1512710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512711, 1, "83e9fbe548e04279ad610b10a432dcfd0d662c17c77ee327dc1ff67aedf87911")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
