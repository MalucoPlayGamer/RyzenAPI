-- Lua provided by RyzenAPI
-- Game: addappid(2359950)

-- MAIN APPLICATION
addappid(2359950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359951, 1, "bfee9275d7db8f1d381c555402df4e516a20f9f862c3a5389a5651c195ba770e")
