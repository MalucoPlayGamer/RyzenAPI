-- Lua provided by RyzenAPI
-- Game: 还有一个小愿望 One More Wish

-- MAIN APPLICATION
addappid(2359950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359951, 1, "bfee9275d7db8f1d381c555402df4e516a20f9f862c3a5389a5651c195ba770e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
