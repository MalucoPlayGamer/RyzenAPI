-- Lua provided by RyzenAPI
-- Game: addappid(3716780)

-- MAIN APPLICATION
addappid(3716780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3716780,0,"9b423a1def74f317340bb9f1bdcd1d9f5dc7097a27c8069bbf8391ba27115c5c")
