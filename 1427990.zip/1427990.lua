-- Lua provided by RyzenAPI
-- Game: Game: Jigsaw Tour

-- MAIN APPLICATION
addappid(1427990)
-- Game: addappid(1427990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427991, 1, "2d0129ea7159813df5080f3ba7bc4ea149ca056f5e37fff0d4fae23e487cea54")
addappid(1427992, 1, "066dbd77bdc90716065b558f36f12ae18a5dd7fde003f596b5d95e5392b538bc")
addappid(1427993, 1, "025ace45fdcf7c3106f0e9d48f3f5f687ef3b5c9750dfda87bcea286e3f08795")
