-- Lua provided by RyzenAPI
-- Game: Game: Happy's Humble Burger Farm: Mutual Decline (OST)

-- MAIN APPLICATION
addappid(1832460)
-- Game: addappid(1832460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832461, 1, "9a9c240e426c07da000c8e8645e25957c1d1f3ee055d2d2b582cf0b65c2340bc")
