-- Lua provided by RyzenAPI
-- Game: Game: SATAN

-- MAIN APPLICATION
addappid(2997260)
-- Game: addappid(2997260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2997261, 1, "a453dc19e3545e56e703eb4b71022b03a831d1e4edc993910dc4cf024e19ec87")
