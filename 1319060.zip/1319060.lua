-- Lua provided by RyzenAPI 
-- Game: Deadly Maze
addappid(1319060)
addappid(1319061, 1, "355d0175b948035a4d0695e732e6e51571283b6b2da689f31951321baa3c07c7")
