-- Lua provided by RyzenAPI
-- Game: Deadly Maze

-- MAIN APPLICATION
addappid(1319060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1319061, 1, "355d0175b948035a4d0695e732e6e51571283b6b2da689f31951321baa3c07c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
