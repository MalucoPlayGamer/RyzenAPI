-- Lua provided by RyzenAPI
-- Game: Game: Deadly Maze

-- MAIN APPLICATION
addappid(1319060)
-- Game: addappid(1319060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1319061, 1, "355d0175b948035a4d0695e732e6e51571283b6b2da689f31951321baa3c07c7")
