-- Lua provided by RyzenAPI
-- Game: Lonely tiny spaceship

-- MAIN APPLICATION
addappid(2899930)
-- Game: addappid(2899930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899932,0,"3165ef76b8a58fcb8204811268d4af81de4e03133f190e70564eb562b0993a59")
