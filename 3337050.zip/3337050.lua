-- Lua provided by RyzenAPI
-- Game: The Night Games Collection

-- MAIN APPLICATION
addappid(3337050)
-- Game: addappid(3337050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337051, 1, "5544ca47f9dd3bd939ff478078ef97b4f47a98d6172a320273ed74a7a659d6d1")
