-- Lua provided by RyzenAPI
-- Game: Pirate Jigsaw

-- MAIN APPLICATION
addappid(1427940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427941, 1, "8bca65a782d9e999cae09fc5a1204c83a9f9f6e4a841459a0fe34e4396d297e4")
addappid(1427942, 1, "e85d3afd7117544f2d0bf494604e067a25abda4c4b514726bdc2367c96033881")
addappid(1427943, 1, "72f5a9f42c69dce959fdb5f985ed6e97c142c72d4b155b524e509282a9f03bcc")
addappid(1427944, 1, "a12aa0d3959eddcf85256e5cf2c3d98feceeed30388964bbe0dd02d0b509d29f")

