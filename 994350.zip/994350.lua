-- Lua provided by RyzenAPI
-- Game: Game: The Seduction of Shaqeera VR

-- MAIN APPLICATION
addappid(994350)
-- Game: addappid(994350)

-- MAIN APP DEPOTS / PACKAGES
addappid(994351, 1, "1af4b4a87e90b63a7e34a7024c4e1b55c024ece55194152626f356fe17e64fab")
