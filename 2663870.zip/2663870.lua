-- Lua provided by RyzenAPI
-- Game: Game: AppID 2663870

-- MAIN APPLICATION
addappid(2663870)
-- Game: addappid(2663870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663871, 1, "47b24519bd22cf2aaaee33b53084b5ebcb9d54efab859516579d8b32a493312e")
