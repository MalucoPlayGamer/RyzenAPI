-- Lua provided by RyzenAPI 
-- Game: Mundaun
addappid(720350)
addappid(720351, 1, "4b8219cacf08860190369060f9437b7e4d8c034a90f4fc0886d6656e0b7e9ecf")
addappid(720352, 1, "a3d58de0df0230af2c4d49285bfa1a4ce835c681a14738b8f3892ebb6c67c549")
