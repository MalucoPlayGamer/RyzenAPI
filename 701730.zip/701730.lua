-- Lua provided by RyzenAPI
-- Game: Yi and the Thousand Moons

-- MAIN APPLICATION
addappid(701730)

-- MAIN APP DEPOTS / PACKAGES
addappid(701732,0,"0b2faa1d48bd695f49e69a263c5c555f358ce98b79ab6ea19abed8e05b83f907")
addappid(701733,0,"7311b6d940ef74efbd323da7f0e5110709d967ba0bdab24d00df66299fc663bf")
addappid(742280,0,"383cb9c5fa44bc2ee61b4398508a6de6d82768e1a41d7e1c6c63b287cedbe251")
