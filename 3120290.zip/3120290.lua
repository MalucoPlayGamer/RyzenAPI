-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Courtyard

-- MAIN APPLICATION
addappid(3120290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3120291, 1, "8b55a967ae441f4f568d411f70daefd513d111bd8efde5d620e21b5ea5f7acd8")
