-- Lua provided by RyzenAPI 
-- Game: 3D PUZZLE - Courtyard
addappid(3120290)
addappid(3120291, 1, "8b55a967ae441f4f568d411f70daefd513d111bd8efde5d620e21b5ea5f7acd8")
