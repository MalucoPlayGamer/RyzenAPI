-- Lua provided by RyzenAPI
-- Game: Why Is There A Girl In My House?!

-- MAIN APPLICATION
addappid(1155720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155721, 1, "23a652e6722660fc38add86d1eaa3515ca17165f9c79c0f3527a19aef0fbb3e4")

