-- Lua provided by RyzenAPI
-- Game: 3267630

-- MAIN APPLICATION
addappid(3267630)
-- Game: addappid(3267630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267631, 1, "1a5126d03a7cc4e6fdb2b5debccc782478c4ff5b0bd9c4062fede2a43c0d2f16")
