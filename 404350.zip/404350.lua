-- Lua provided by RyzenAPI
-- Game: Sid Meier's Civilization VI Development Tools

-- MAIN APPLICATION
addappid(404350)

-- MAIN APP DEPOTS / PACKAGES
addappid(404351, 1, "889de13fc17719706791e4c6926692361afa949b5f15b09f7b385077bf3c3606")
