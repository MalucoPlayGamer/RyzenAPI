-- Lua provided by SkyAPI 
-- Game: AppID 404350
addappid(404350)
addappid(404351, 1, "889de13fc17719706791e4c6926692361afa949b5f15b09f7b385077bf3c3606")
