-- Lua provided by RyzenAPI
-- Game: addappid(2455551)

-- MAIN APPLICATION
addappid(2455551)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455551,0,"164f8aa6f956264970e464ec26a660b81dec5adb757ed032969d06d5f10a1d36")
