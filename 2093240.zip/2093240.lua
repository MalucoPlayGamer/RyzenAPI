-- Lua provided by SkyAPI 
-- Game: AppID 2093240
addappid(2093240)
addappid(2093241, 1, "9eac17d35c7a4d92c2bc39bbfcd5a64c61df1d4aed6c5dc7bad49f962d4780bf")
