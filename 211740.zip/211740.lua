-- Lua provided by RyzenAPI
-- Game: addappid(211740)

-- MAIN APPLICATION
addappid(211740)

-- MAIN APP DEPOTS / PACKAGES
addappid(211741, 1, "2859ca8ae3cf480ee14a5fe8ab59b756a7d0f3ec9f87ae8be06845150a461296")
