-- Lua provided by RyzenAPI
-- Game: Tangram Collection

-- MAIN APPLICATION
addappid(3182240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3182241, 1, "4b58bfbced43aa67a4f5047d879a64fc74fb2d94324fbd39e16c33d387cdd8c6")

