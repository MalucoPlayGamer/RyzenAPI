-- Lua provided by RyzenAPI
-- Game: Game: Drug Dealer Simulator 2

-- MAIN APPLICATION
addappid(1708850)
addappid(3064210)
addappid(3169480)
addappid(3385220)
-- Game: addappid(1708850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708851, 1, "9da58ce930b5409698dfdd9945f19efdbe1e0b7acead98d61080b5b7058f9890")
