-- Lua provided by RyzenAPI
-- Game: Game: Road Stones

-- MAIN APPLICATION
addappid(2069580)
-- Game: addappid(2069580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2069581, 1, "0d0df32068a3e62fe63980c4134a4039f03b1351c18c92894f3194c5732578fe")
