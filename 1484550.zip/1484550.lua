-- Lua provided by RyzenAPI
-- Game: addappid(1484550)

-- MAIN APPLICATION
addappid(1484550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484551, 1, "ddb3a09722daaadfa0af7a0c6a89679849e2c8b072a2dd3beb80184d9b65fc0c")
