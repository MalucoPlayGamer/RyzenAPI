-- Lua provided by RyzenAPI
-- Game: addappid(3720810)

-- MAIN APPLICATION
addappid(3720810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720811, 1, "f02df0b10f38e342e32bef105f44f23cdaaf25c5a3aa4d3eb51d5b8d26fbb1d5")
