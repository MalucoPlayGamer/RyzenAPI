-- Lua provided by RyzenAPI
-- Game: addappid(2273880)

-- MAIN APPLICATION
addappid(2273880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273881, 1, "4f3dbe7c7e2ef0babaa92fc552c8c0e2d15ccb983af63f2fe707e1dbfcfc123c")
