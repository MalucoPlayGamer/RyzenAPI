-- Lua provided by RyzenAPI
-- Game: Наружу

-- MAIN APPLICATION
addappid(2461800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461801, 1, "c6459ef29981ab855c36781ccb773cea292a1329a732e20638487de7755bbe85")

