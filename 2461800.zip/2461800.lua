-- Lua provided by SkyAPI 
-- Game: Наружу
addappid(2461800)
addappid(2461801, 1, "c6459ef29981ab855c36781ccb773cea292a1329a732e20638487de7755bbe85")
