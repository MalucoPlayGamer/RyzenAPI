-- Lua provided by RyzenAPI
-- Game: AppID 342500

-- MAIN APPLICATION
addappid(342500)
-- Game: addappid(342500)

-- MAIN APP DEPOTS / PACKAGES
addappid(342501, 1, "c5646a6c75e92830ba35405da4d0cc5f0ecd7d66cac16e1fb5077fe700f6f544")
