-- Lua provided by RyzenAPI
-- Game: Game: Diorama Builder

-- MAIN APPLICATION
addappid(1370170)
-- Game: addappid(1370170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370171, 1, "a14625a6bf9e76e962e0880e0d80d4fa112e845bc521ac6e879b767186242a01")
addappid(1370172, 1, "38302b808b8d3ecde45a236f94c9f533740f1e4b9a74e8df091f5e21388c5412")
addappid(1370173, 1, "8307c168951b32b789870f5bc41bdbcb2307332c1e2b8ebb3d9eed4fbd7ca7d6")
addappid(1370174, 1, "0d8bab13a2f17b12ccdd49aaf9d0e02a788043026fa0b0c29055ca1657a83dbe")
addappid(1370175, 1, "73b14fcb48930e05c8c05df253de3f5d341bcfaabb4f1aa7f89fd682c3261288")
addappid(1370176, 1, "e1336647be9cefad0a8ef2dde79c0327d6ecbcecc1d862c75bff956679cdeb78")
addappid(1370177, 1, "8416c570bdec7add57de48889b301bb2c8d5bd56988b3067b59ff7994400ae6c")
