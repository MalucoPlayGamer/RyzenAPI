-- Lua provided by SkyAPI 
-- Game: Horizon Chase Turbo Demo
addappid(891900)
addappid(891901, 1, "988feba495cad3db3a56d48df03305e8910e4b7e68de64b3443a850f54bbd44b")
