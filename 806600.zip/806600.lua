-- Lua provided by RyzenAPI
-- Game: Escape!

-- MAIN APPLICATION
addappid(806600)
addappid(823520)
-- Game: addappid(806600)

-- MAIN APP DEPOTS / PACKAGES
addappid(806601, 1, "0d0823f4d15af033fdb8afb867797ffa15b914945d5527ffc887775f67ce451a")
