-- Lua provided by RyzenAPI
-- Game: Escape!

-- MAIN APPLICATION
addappid(806600)
addappid(823520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(806601, 1, "0d0823f4d15af033fdb8afb867797ffa15b914945d5527ffc887775f67ce451a")

