-- Lua provided by RyzenAPI
-- Game: Game: AppID 1235130

-- MAIN APPLICATION
addappid(1235130)
-- Game: addappid(1235130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235131, 1, "6174b7382ec69bb98f887a0e884ccdb953b25f7c4bb083152a0500b55cf79ce8")
