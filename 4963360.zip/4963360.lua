-- 4963360's Lua and Manifest Created by Hubcap Manifest
-- THE REF - Football Referee Simulator
-- Created: August 06, 2026 at 23:52:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4963360) -- THE REF - Football Referee Simulator
-- MAIN APP DEPOTS
addappid(4963361, 1, "aed7734d9b258915af8eeb4fc59b8ccdf19cc3e2376b58e7a0865a857b5d0874") -- Depot 4963361
setManifestid(4963361, "7953597595514219133", 299915596)