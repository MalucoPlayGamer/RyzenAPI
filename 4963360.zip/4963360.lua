-- Lua provided by RyzenAPI
-- Game: THE REF - Football Referee Simulator

-- MAIN APPLICATION
addappid(4963360) -- THE REF - Football Referee Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4963361, 1, "aed7734d9b258915af8eeb4fc59b8ccdf19cc3e2376b58e7a0865a857b5d0874") -- Depot 4963361

