-- Lua provided by RyzenAPI
-- Game: Chimeras: Wailing Waters Collector's Edition

-- MAIN APPLICATION
addappid(1097280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097281, 1, "f01df0cd65501b18728d3a03552a1852d48b240abb99dae373e7890021005f74")

