-- Lua provided by RyzenAPI
-- Game: addappid(779800)

-- MAIN APPLICATION
addappid(779800)

-- MAIN APP DEPOTS / PACKAGES
addappid(779801, 1, "be3fc64333c5447cf8b6c65c7e96a7f25ad6e1c8fd78ad46f824def23c4f81da")
