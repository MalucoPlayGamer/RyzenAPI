-- Lua provided by RyzenAPI
-- Game: Happy’s Humble Burger Farm: Fountain of Guts (OST)

-- MAIN APPLICATION
addappid(1832400)
-- Game: addappid(1832400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832401, 1, "439a8f1278aeca990b37a3f3971893da0e35354976b1f17b0249230df67eb761")
