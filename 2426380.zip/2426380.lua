-- Lua provided by RyzenAPI
-- Game: Pact of Joy: Prologue

-- MAIN APPLICATION
addappid(2426380)
-- Game: addappid(2426380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426381, 1, "a2563b250fd0ef844c3eae6ef557740bc34215338de9645cf99b2da5171f5e17")
