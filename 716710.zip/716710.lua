-- Lua provided by RyzenAPI
-- Game: AppID 716710

-- MAIN APPLICATION
addappid(716710)

-- MAIN APP DEPOTS / PACKAGES
addappid(716711, 1, "43775a5b0f74c6c8d6694388a64a73113ae7a443ecc579b983159729ce509110")
addappid(716712, 1, "a97ea7ce13af612de7ac94b64e1f5dd734199989c3e0f42ab50b3a6ac4eee65f")
addappid(716717, 1, "d5a43ef63493fdddcedbb67aa1ff539158bf7849008d0638169807d331c5e4a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
