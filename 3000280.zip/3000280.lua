-- Lua provided by RyzenAPI
-- Game: Sexcalibur: Knights of the Pound Table

-- MAIN APPLICATION
addappid(3000280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3000281, 1, "bba113a74795b652ee0f2167ea4e9e929a8b8e51345b5e44bae31ecc64ef92be")
addappid(3000282, 1, "cdedb84303ffa9713b365f17e03e81bb312974c53b29f3ed8b3cd5ed6a2066a2")

