-- Lua provided by SkyAPI 
-- Game: Werewolf: The Apocalypse - Heart of the Forest Demo
addappid(1384410)
addappid(1384411, 1, "4b76487c897d2057e0505f0008a3319f14084285e56abd8878129ffc6697834f")
