-- Lua provided by RyzenAPI
-- Game: AppID 795220

-- MAIN APPLICATION
addappid(795220)

-- MAIN APP DEPOTS / PACKAGES
addappid(795221, 1, "915bd38d9207dbf82a18925ea9003df22eb4cd4661f779d5caf1807f8ecdb7ad")

