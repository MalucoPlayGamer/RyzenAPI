-- Lua provided by RyzenAPI
-- Game: Game: Beeswing

-- MAIN APPLICATION
addappid(365580)
-- Game: addappid(365580)

-- MAIN APP DEPOTS / PACKAGES
addappid(365581, 1, "f7fc6b91c726df22d2bcab06cec02c1214ab8d2972eff158952c62585ecd82f6")
addappid(365582, 1, "5d5344d50bcecec6071a43163d2f135fdd4b8028c85a4ae6a040343da2dbbbc6")
addappid(365583, 1, "f4fcf1ee90bf362da5fc0a5b4d5154e593dc42aa7d50d65c73a16c717975bed0")
