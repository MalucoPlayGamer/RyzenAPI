-- Lua provided by RyzenAPI
-- Game: addappid(2848360)

-- MAIN APPLICATION
addappid(2848360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848361, 1, "8d828d87f109dc28acc3a5f02de1c95216ff76d797bc0d4bd8d37843dc20efdf")
