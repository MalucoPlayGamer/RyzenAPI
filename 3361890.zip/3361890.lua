-- Lua provided by RyzenAPI
-- Game: addappid(3361890)

-- MAIN APPLICATION
addappid(3361890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361891, 1, "7c98b70ab00fe8156b1042e9108c3ea0666474855e0f313fd608bebd941dbac8")
