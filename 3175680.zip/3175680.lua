-- Lua provided by RyzenAPI 
-- Game: Lofi Haven Demo
addappid(3175680)
addappid(3175681, 1, "ec15b6e0dce2c9848e2a9414956963496802f0c180a467ac2891b1c3cdf69d24")
