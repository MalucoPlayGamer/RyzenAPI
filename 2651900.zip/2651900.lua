-- Lua provided by RyzenAPI
-- Game: addappid(2651900)

-- MAIN APPLICATION
addappid(2651900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651901, 1, "5bb2a197e8828df72d9e5d538ba0c90da194f50a8bf61e38972dc83bcd0c888e")
