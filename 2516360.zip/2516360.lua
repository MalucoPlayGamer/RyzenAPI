-- Lua provided by RyzenAPI
-- Game: addappid(2516360)

-- MAIN APPLICATION
addappid(2516360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516361, 1, "779f27dc4de99eec1b8ed7a9ac3a70bc85c571ac15f944b3c8da2f9441cfca2a")
