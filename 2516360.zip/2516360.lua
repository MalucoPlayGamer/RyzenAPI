-- Lua provided by RyzenAPI
-- Game: AppID 2516360

-- MAIN APPLICATION
addappid(2516360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2516361, 1, "779f27dc4de99eec1b8ed7a9ac3a70bc85c571ac15f944b3c8da2f9441cfca2a")

