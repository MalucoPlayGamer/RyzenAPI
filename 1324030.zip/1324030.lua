-- Lua provided by RyzenAPI
-- Game: Game: Alien Cat 2

-- MAIN APPLICATION
addappid(1324030)
-- Game: addappid(1324030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324031, 1, "bd693240bb667286fcc428929bf67a0482b012dc6b15d0071344c2394c56abbe")
