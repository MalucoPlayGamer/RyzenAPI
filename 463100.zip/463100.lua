-- Lua provided by RyzenAPI
-- Game: Game: Liveza: Death of the Earth

-- MAIN APPLICATION
addappid(463100)
-- Game: addappid(463100)

-- MAIN APP DEPOTS / PACKAGES
addappid(463101, 1, "a046ec89a38987ec2d34f9342b08dd33c96c2f0aa2ba10060bf736e55aad8f53")
addappid(463102, 1, "6c4a3ceb0e56ac2ecbceb8fa312761a8e811008df57665ed40c7898179861066")
addappid(463103, 1, "5464e2489f2d59d6917baadee1baad1251c8bda251a5022a2c3668d641f4dcd1")
addappid(463104, 1, "2b5fd082580095c71d7245782583f62456590b18fd5bb42b100ffb92a86e4c28")
