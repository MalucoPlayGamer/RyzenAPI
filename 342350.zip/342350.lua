-- Lua provided by RyzenAPI
-- Game: 342350

-- MAIN APPLICATION
addappid(342350)
-- Game: addappid(342350)

-- MAIN APP DEPOTS / PACKAGES
addappid(342351, 1, "c5990d4af6ccf7e2fb95805fdcbf18dec9c4dad1365d4c699e6f6708611ca5e1")
