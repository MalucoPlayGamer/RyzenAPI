-- Lua provided by RyzenAPI
-- Game: 1518200

-- MAIN APPLICATION
addappid(1518200)
-- Game: addappid(1518200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1518201, 1, "d63a9becb1a2614adaa0e7eba6105493a969d0325b64d9e661da04a6558ec6e3")
