-- Lua provided by SkyAPI 
-- Game: Agent Murphy
addappid(1518200)
addappid(1518201, 1, "d63a9becb1a2614adaa0e7eba6105493a969d0325b64d9e661da04a6558ec6e3")
