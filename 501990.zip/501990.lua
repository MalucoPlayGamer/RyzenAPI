-- Lua provided by RyzenAPI
-- Game: AppID 501990

-- MAIN APPLICATION
addappid(501990)

-- MAIN APP DEPOTS / PACKAGES
addappid(501991, 1, "4beeec07590c8c2893254fa0eb58a8df4db6847e40c9eec93c440eab033986b5")
