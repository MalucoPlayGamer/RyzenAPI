-- Lua provided by RyzenAPI
-- Game: Dickdown Duel

-- MAIN APPLICATION
addappid(1868850)
-- Game: addappid(1868850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1868851, 1, "9a5c10f7b9f736f98face30eba8547920e74908a8e087bd5fb57cb80b4ce52e8")
