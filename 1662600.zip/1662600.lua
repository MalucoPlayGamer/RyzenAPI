-- Lua provided by RyzenAPI
-- Game: 1662600

-- MAIN APPLICATION
addappid(1662600)
-- Game: addappid(1662600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662600,0,"519274afa5b8c1a3d3944008c1524ce3bb7f172c8b52264bca49f15cb007117e")
