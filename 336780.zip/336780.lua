-- Lua provided by RyzenAPI
-- Game: Pilot Brothers 3: Back Side of the Earth

-- MAIN APPLICATION
addappid(336780)

-- MAIN APP DEPOTS / PACKAGES
addappid(336781, 1, "223fec4e3e33c70cc3806eefbc655079047cc35f6c4528bc94668d4bc0880b90")
