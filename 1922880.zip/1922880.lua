-- Lua provided by RyzenAPI
-- Game: Fun Quest

-- MAIN APPLICATION
addappid(1922880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922881, 1, "59f74233ac8a0110ac37de15224acdf2a3bd7da1683eb1aa552b43d045787e21")
