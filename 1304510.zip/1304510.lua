-- Lua provided by RyzenAPI
-- Game: SCP: Nine-Tailed Fox

-- MAIN APPLICATION
addappid(1304510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304511, 1, "20ae4a0173188bf67b23aedc925661e665cd791185dabab809c25b440aba087b")
