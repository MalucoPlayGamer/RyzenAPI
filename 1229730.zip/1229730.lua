-- Lua provided by RyzenAPI
-- Game: 1229730

-- MAIN APPLICATION
addappid(1229730)
-- Game: addappid(1229730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229731, 1, "532b3c83c9b60820b78d3f09da31dac2e72135055020dd35dd50fc7e4eddefab")
