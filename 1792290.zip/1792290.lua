-- Lua provided by RyzenAPI
-- Game: Back Alley Inn

-- MAIN APPLICATION
addappid(1792290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792291, 1, "17dee2782967a0918c53d650d28d7a3fe35bfb26edb7c9b073c984745b303f2e")
addappid(1818170, 0, "5c5e05911b7f4e089d7589cb69dd5e3c57de5a2881508da90a9f6edf53800f24")
