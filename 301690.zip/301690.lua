-- Lua provided by RyzenAPI
-- Game: Game: Cobi Treasure Deluxe

-- MAIN APPLICATION
addappid(301690)
-- Game: addappid(301690)

-- MAIN APP DEPOTS / PACKAGES
addappid(301691, 1, "ba1ddc0bd41dc15cf047795078467bb8dd27c87ac7df7b3646e74e3d03bbfa66")
