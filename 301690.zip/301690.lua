-- Lua provided by SkyAPI 
-- Game: Cobi Treasure Deluxe
addappid(301690)
addappid(301691, 1, "ba1ddc0bd41dc15cf047795078467bb8dd27c87ac7df7b3646e74e3d03bbfa66")
