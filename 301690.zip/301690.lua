-- Lua provided by RyzenAPI
-- Game: Cobi Treasure Deluxe

-- MAIN APPLICATION
addappid(301690)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(301691, 1, "ba1ddc0bd41dc15cf047795078467bb8dd27c87ac7df7b3646e74e3d03bbfa66")

