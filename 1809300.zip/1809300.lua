-- Lua provided by RyzenAPI
-- Game: addappid(1809300)

-- MAIN APPLICATION
addappid(1809300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809301, 1, "18184b82c30a35b018380d0379c3d02ae80ae042bfa9a6067dd9bf1dd2e97087")
