-- Lua provided by RyzenAPI
-- Game: Fight Ascending

-- MAIN APPLICATION
addappid(1809300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809301, 1, "18184b82c30a35b018380d0379c3d02ae80ae042bfa9a6067dd9bf1dd2e97087")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
