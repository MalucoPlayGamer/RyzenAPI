-- Lua provided by RyzenAPI
-- Game: Touhou Mystia's Izakaya DLC1 Pack - Forest of Magic & Youkai Mountain

-- MAIN APPLICATION
addappid(1838750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838751, 1, "802c21518c05f219fe8cce3eff43d09ad71dc681f1e6941ae81ef4124682db07")
addappid(1838752, 1, "723a2afe9f3d1c328df82a5ecc6d93a197a149f9063a425f718b9b0d5c9f8007")
