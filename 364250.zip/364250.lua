-- Lua provided by RyzenAPI
-- Game: AppID 364250

-- MAIN APPLICATION
addappid(364250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(364251, 1, "c3a6887d62a212388171c1e014cda99eca76d70af536228b8482ab007b3966de")

