-- Lua provided by RyzenAPI
-- Game: 364250

-- MAIN APPLICATION
addappid(364250)
-- Game: addappid(364250)

-- MAIN APP DEPOTS / PACKAGES
addappid(364251, 1, "c3a6887d62a212388171c1e014cda99eca76d70af536228b8482ab007b3966de")
