-- Lua provided by RyzenAPI
-- Game: Mask of the Plague Doctor

-- MAIN APPLICATION
addappid(1244930)
-- Game: addappid(1244930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244931, 1, "3299f553032fad7d89dc668d6e7c574d6a8207c5497ebd4b9c663b447ca3d12b")
