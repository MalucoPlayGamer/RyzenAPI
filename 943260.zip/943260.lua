-- Lua provided by RyzenAPI
-- Game: Stranded Sails - Explorers of the Cursed Islands

-- MAIN APPLICATION
addappid(943260)
-- Game: addappid(943260)

-- MAIN APP DEPOTS / PACKAGES
addappid(943261, 1, "10ec0ac1d7cf0da6e4e6afd3e753a6112f2894e55e30bcb9010d3f8b415afef1")
