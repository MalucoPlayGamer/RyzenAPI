-- Lua provided by RyzenAPI
-- Game: Super Stone Legacy

-- MAIN APPLICATION
addappid(580300)

-- MAIN APP DEPOTS / PACKAGES
addappid(580301,0,"4c1f0f00759ac09cf5a4f1ba3ce6468f26623a006590ad3316c6baadabf66fb5")

