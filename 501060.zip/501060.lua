-- Lua provided by RyzenAPI
-- Game: C.S.S. CITADEL VR

-- MAIN APPLICATION
addappid(501060)
-- Game: addappid(501060)

-- MAIN APP DEPOTS / PACKAGES
addappid(501061, 1, "4a09c63af9fbf79d3c640f32fdac411c49f11497c41da166b08ee0668dea0acc")
