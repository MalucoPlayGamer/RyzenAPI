-- Lua provided by RyzenAPI
-- Game: Rebirth:Which is my toilet

-- MAIN APPLICATION
addappid(3622490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3622491, 1, "d29d326ddf1633b17d836a2b21aa1595c495e6ce3c4fb681a7774ca55858c5dd")

