-- Lua provided by RyzenAPI
-- Game: Rebirth:Which is my toilet

-- MAIN APPLICATION
addappid(3622490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3622491, 1, "d29d326ddf1633b17d836a2b21aa1595c495e6ce3c4fb681a7774ca55858c5dd")
