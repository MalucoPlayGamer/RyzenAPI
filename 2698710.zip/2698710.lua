-- Lua provided by RyzenAPI
-- Game: 2698710

-- MAIN APPLICATION
addappid(2698710)
-- Game: addappid(2698710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698711, 1, "b638b8a987d328ca2f7cce0f70a2549c352b0c69588b9cac87a0eef1818875d8")
