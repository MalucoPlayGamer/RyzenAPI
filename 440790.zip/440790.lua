-- Lua provided by RyzenAPI
-- Game: Game: AppID 440790

-- MAIN APPLICATION
addappid(440790)
-- Game: addappid(440790)

-- MAIN APP DEPOTS / PACKAGES
addappid(440791, 1, "f3ac1956ab9af7a2ea4b86e8324184d9a14c7a97d341beb20b8dd5f1da94b93b")
addappid(440792, 1, "cb4b5b0dc44ded1d9f0f17eb34de7aa8742ec0b0b8a3829eed94a5aabf02b604")
