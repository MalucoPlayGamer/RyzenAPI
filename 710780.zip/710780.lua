-- Lua provided by RyzenAPI 
-- Game: Sky Jump
addappid(710780)
addappid(710781, 1, "1946ca484570526af7d6e7575bbefdd7181ee338501b30a3f00cbe307157b0ba")
