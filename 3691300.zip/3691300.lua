-- Lua provided by SkyAPI 
-- Game: 三国混战
addappid(3691300)
addappid(3691301, 1, "6fa8b78b4017a69d3ef62e02fee61e0a55a2ae7ff40330882abdc8d8a2c12d16")
