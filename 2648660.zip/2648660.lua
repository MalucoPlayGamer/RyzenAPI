-- Lua provided by RyzenAPI 
-- Game: Mortisomem
addappid(2648660)
addappid(2648661, 1, "b1c5d65dfa29d8dee183d4b6a3515739e56959ea7d1afb4eb3eb41899424f7ec")
