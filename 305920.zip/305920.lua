-- Lua provided by RyzenAPI
-- Game: Another Perspective

-- MAIN APPLICATION
addappid(305920)

-- MAIN APP DEPOTS / PACKAGES
addappid(305921, 1, "09a9e0466c4ed190e06b129ad892ba5bf3174d508b81de3ca17af7bdaac68a22")

