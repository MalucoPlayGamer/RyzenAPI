-- Lua provided by RyzenAPI
-- Game: 2399130

-- MAIN APPLICATION
addappid(2399130)
-- Game: addappid(2399130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399131, 1, "a411606c6eb928a1c6a3c2ec7d2b062607315d3ffd04a231bcd6f6e496629726")
