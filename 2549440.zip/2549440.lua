-- Lua provided by RyzenAPI
-- Game: Game: Rings of Harmony

-- MAIN APPLICATION
addappid(2549440)
-- Game: addappid(2549440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549441, 1, "48f73580fc0e78739cc564e7d54517cdd057adea485ea078d612619dbfb29d96")
