-- Lua provided by RyzenAPI 
-- Game: TYRONE vs COPS VR
addappid(2085920)
addappid(2085921, 1, "8114e7908f665fdc8b2a5246cf5fdfe04ce5d813858b9117614e64d036393a94")
addappid(2085922, 1, "78b1e3278c09fbcc61754a59034aaa07a9e18970a64dbb04b4348d1f23c32865")
