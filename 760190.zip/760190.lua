-- Lua provided by RyzenAPI
-- Game: 760190

-- MAIN APPLICATION
addappid(760190)
-- Game: addappid(760190)

-- MAIN APP DEPOTS / PACKAGES
addappid(760191, 1, "672c3bb8ceee5c19b6da2f304f83047eb3a0cf759140a07a2424c9c089412bd2")
addappid(760192, 1, "ecb195b5710626bbc80e6e037328b6b5b781334c324d2b60232b84ee0cc23da7")
