-- Lua provided by SkyAPI 
-- Game: AppID 554530
addappid(554530)
addappid(554531, 1, "27ea13386d53e9eb1fc57457f1ec308bc4a3cc88424f421904259416a4ff7293")
addappid(554532, 1, "b22a5e92e658d4c9ec828c98f40f2fb4ce8541a78a568cd835a2afb7a97b2954")
