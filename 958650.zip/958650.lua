-- Lua provided by RyzenAPI
-- Game: addappid(958650)

-- MAIN APPLICATION
addappid(958650)

-- MAIN APP DEPOTS / PACKAGES
addappid(958651, 1, "ee650b9586e661b852767c92df83f1b5bae83c4c8f7d2e42d7648d0fddd27385")
