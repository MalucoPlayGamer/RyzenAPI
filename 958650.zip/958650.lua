-- Lua provided by SkyAPI 
-- Game: Strange Encounter
addappid(958650)
addappid(958651, 1, "ee650b9586e661b852767c92df83f1b5bae83c4c8f7d2e42d7648d0fddd27385")
