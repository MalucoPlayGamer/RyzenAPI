-- Lua provided by RyzenAPI
-- Game: Startup Company

-- MAIN APPLICATION
addappid(606800)

-- MAIN APP DEPOTS / PACKAGES
addappid(606801, 1, "ed9983aa107af72693cf9d476cf2f9689d0f9a337a7a7b914ace6e181612e15f")
addappid(606802, 1, "efb9aa64d29c6bdece6532a1d4c05cec8d6d2c36185610d6db93d82f9fc5bb9d")
addappid(606803, 1, "5bff66c11dc82339323f665dda5cacb1a5b6fd89068f7218de08e158f1c99bed")
