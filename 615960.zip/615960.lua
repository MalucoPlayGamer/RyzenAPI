-- Lua provided by RyzenAPI
-- Game: COMPOUND Demo

-- MAIN APPLICATION
addappid(615960)

-- MAIN APP DEPOTS / PACKAGES
addappid(615961, 1, "6b196910fc5d8f7d8edac96b39ffd84cf9d4257a90a0e816114f4f4b2cdbce6f")
