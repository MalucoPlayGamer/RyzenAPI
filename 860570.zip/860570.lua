-- Lua provided by RyzenAPI
-- Game: 860570

-- MAIN APPLICATION
addappid(860570)
addappid(860571)
addappid(860572)

-- MAIN APP DEPOTS / PACKAGES
addappid(860573,0,"a7eb5389c529ef76e1c29154325c98dbfc8be70441d9982fa64315831df3bc2a")

