-- Lua provided by RyzenAPI
-- Game: There's a Gun in the Office

-- MAIN APPLICATION
addappid(3291220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291221, 1, "f55d3ddd403d0d72baa283046b3574e2862253f10e4def08514bc6034df61cb3")
