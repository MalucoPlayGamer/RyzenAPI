-- Lua provided by RyzenAPI
-- Game: Hidden Caves

-- MAIN APPLICATION
addappid(1765800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765801, 1, "c7ec38b8e63cc3b1744d18736b4dd2c564b167c655162930e536531df4f53d8e")
