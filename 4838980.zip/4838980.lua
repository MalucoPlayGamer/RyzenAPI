-- 4838980's Lua and Manifest Created by Hubcap Manifest
-- Hentai Academy: The Professor's Secret
-- Created: August 15, 2026 at 03:16:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4838980) -- Hentai Academy: The Professor's Secret
-- MAIN APP DEPOTS
addappid(4838981, 1, "2364bc38ab912c58a2bd11492191cc061bf772a988652b905d715a3788e3effa") -- Depot 4838981
setManifestid(4838981, "5751361771979994639", 1246081140)