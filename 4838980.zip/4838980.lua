-- Lua provided by RyzenAPI
-- Game: Hentai Academy: The Professor's Secret

-- MAIN APPLICATION
addappid(4838980) -- Hentai Academy: The Professor's Secret

-- MAIN APP DEPOTS / PACKAGES
addappid(4838981, 1, "2364bc38ab912c58a2bd11492191cc061bf772a988652b905d715a3788e3effa") -- Depot 4838981

