-- Lua provided by RyzenAPI
-- Game: ArcRunner Demo

-- MAIN APPLICATION
addappid(2230580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230581, 1, "362e834bd59acf48390affa89b352334bb9750dbfeb58242294e71e7a8ab940a")
