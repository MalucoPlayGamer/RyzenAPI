-- Lua provided by RyzenAPI
-- Game: Deskmate Girl

-- MAIN APPLICATION
addappid(1268870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268871, 1, "d2478e151f5b413407ad2b894c85bfc186eee14252ebfca63b70f1f3072483d9")
