-- Lua provided by RyzenAPI
-- Game: My Furry Detective - 18+ Adult Only Patch 🐾

-- MAIN APPLICATION
addappid(1788530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788530,0,"24683cf6002bbb0aeb6ea7c8a3cf8349554911e8e51dc8333f35cbbb1c5ec6c8")
