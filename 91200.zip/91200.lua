-- Lua provided by RyzenAPI 
-- Game: Anomaly: Warzone Earth
addappid(91200)
addappid(91201, 1, "b68325f494f9605da20966449aee46fe9d11bb4a296213d18061468f70a3737a")
addappid(91202, 1, "fce5bc4286e517d969d3c4331314798bad4a7cb610384f3ad6e488fc5d377ae1")
addappid(91203, 1, "49623c5f91b7fb116ed44d69a9afa2b03851e07e96093f1dd9c3c37ffb727bb3")
