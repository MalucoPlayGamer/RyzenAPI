-- Lua provided by RyzenAPI
-- Game: SONIC X SHADOW GENERATIONS

-- MAIN APPLICATION
addappid(2513280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2513281, 1, "e5b9cddfe91ed04af8c6d17537301797ab16a5041a7edca1d45ae281208a740f")
addappid(2909770, 0, "45c41ebbd5561b69146ab5f7ecc497f31ee3e82db476188d8af2ae31537ae58a")
addappid(2909780, 0, "d4bca264bdbcdde86f3167d63185b55ea30748dc1670b75bd2c48fe00b16ec08")
addappid(2909790, 0, "bf6e60e47f8307ecf6fa9f9d935d223475b099b56d9da116e8e52377b5b971b4")
addappid(2983600, 0, "bc2088d641e09b580bd27cc38e66095166613065bbe61e6bd0af493143ed106c")
addappid(2999160, 0, "5333f0019f11df5032e635e73031fddfb9d2b9a631779e9d4cf309b15397cf7a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
