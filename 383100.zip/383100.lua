-- Lua provided by RyzenAPI
-- Game: Fragile Allegiance

-- MAIN APPLICATION
addappid(383100)

-- MAIN APP DEPOTS / PACKAGES
addappid(383101, 1, "81a60276b1feaf92fda1b68262c8bb174634b0ac0bf2096e7d1ed5396c1905b6")
