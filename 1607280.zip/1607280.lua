-- Lua provided by RyzenAPI
-- Game: AppID 1607280

-- MAIN APPLICATION
addappid(1607280)
-- Game: addappid(1607280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607281, 1, "ac0c4b0f53f4e8a20bb7b7afd566ef51154ffc8f4f021d7a515f0fb3996639d3")
addappid(1608240, 0, "560e522a14f091602f54119318805dd1fe0ea3a8aec22de6435263a907aa60b5")
addappid(1724690, 0, "d17ad544e407ac2ce5ff42cdcaae5a49d0311eb20fa54bef7c48c401388d560f")
