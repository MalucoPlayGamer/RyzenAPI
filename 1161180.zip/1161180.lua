-- Lua provided by RyzenAPI
-- Game: Funbag Fantasy: Sideboob Story 2

-- MAIN APPLICATION
addappid(1161180)
-- Game: addappid(1161180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161181, 1, "e1c94b2eaaec5ac08608c5e29ef4642fedf4483c967652e9013ee302df7fcd70")
