-- Lua provided by RyzenAPI
-- Game: AppID 657180

-- MAIN APPLICATION
addappid(657180)
-- Game: addappid(657180)

-- MAIN APP DEPOTS / PACKAGES
addappid(657181, 1, "9e579a8e833bfa6a0eebd925ca9031f00017b27d3c61b8fe09d799e07c2db037")
