-- Lua provided by SkyAPI 
-- Game: AppID 657180
addappid(657180)
addappid(657181, 1, "9e579a8e833bfa6a0eebd925ca9031f00017b27d3c61b8fe09d799e07c2db037")
