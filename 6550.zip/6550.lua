-- Lua provided by RyzenAPI
-- Game: Devil May Cry® 3 Special Edition

-- MAIN APPLICATION
addappid(6550)

-- MAIN APP DEPOTS / PACKAGES
addappid(6551, 1, "9fc2e9035811d502e0caefc88bfcdcce0ee92d1cc90bd6f21a4b1795905a50f0")
addappid(6552, 1, "2ebef56094868d075732c86d2bddda632e2fdcb766da9064983ceb0c6ff19bce")
addappid(6553, 1, "07609b801c9cf5e0b633535b972a64d4a9c8760b5a18775c23ff509bdc67e357")

