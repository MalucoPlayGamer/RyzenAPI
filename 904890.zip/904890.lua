-- Lua provided by RyzenAPI
-- Game: addappid(904890)

-- MAIN APPLICATION
addappid(904890)

-- MAIN APP DEPOTS / PACKAGES
addappid(904891, 1, "f1fab8f0f1c05bd9768057b5e91afb213ee85eb7f877dce93128eb2fbb32f350")
