-- Lua provided by RyzenAPI
-- Game: 1756610

-- MAIN APPLICATION
addappid(1756610)
-- Game: addappid(1756610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756610,0,"668d146abbeecf79896917f4ab1d1294eae0c2ec6befb12e5f29c3f7164aa93b")
