-- Lua provided by RyzenAPI
-- Game: The Keep

-- MAIN APPLICATION
addappid(317370)
-- Game: addappid(317370)

-- MAIN APP DEPOTS / PACKAGES
addappid(317371, 1, "060d24b8cfb0c1652eb72a5da74d67a6422e149872ff51956f7a86cb1d16405c")
addappid(317373, 1, "c937289ce8628f68f2b579dd7eb49a47737865ade12292e0708a5c7ae0f93523")
