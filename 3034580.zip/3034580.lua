-- Lua provided by RyzenAPI 
-- Game: AppID 3034580
addappid(3034580)
addappid(3034581, 1, "64866aaa8f9f73e8817b192ecb6439641c7438e0fa67eeab2f2db490b5b840a4")
