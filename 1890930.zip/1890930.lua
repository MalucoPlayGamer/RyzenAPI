-- Lua provided by RyzenAPI
-- Game: 1890930

-- MAIN APPLICATION
addappid(1890930)
-- Game: addappid(1890930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890931, 1, "ea8ca0ccd1502e8041b5e5b18629aa3c49b2c5bdaa7a958c528fdfc85a0ad13a")
