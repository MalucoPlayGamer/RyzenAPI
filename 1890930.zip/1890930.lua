-- Lua provided by RyzenAPI 
-- Game: AppID 1890930
addappid(1890930)
addappid(1890931, 1, "ea8ca0ccd1502e8041b5e5b18629aa3c49b2c5bdaa7a958c528fdfc85a0ad13a")
