-- Lua provided by RyzenAPI
-- Game: Game: Rapid Soccer Demo

-- MAIN APPLICATION
addappid(2810710)
-- Game: addappid(2810710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810711, 1, "71e07d632501dfd73c5e31f195722945878224be985989e3696becb50bb9372b")
