-- Lua provided by RyzenAPI 
-- Game: Cossacks: Art of War
addappid(4870)
addappid(4871, 1, "5181f63e66f5815c1d6b1a6291e2a6c92eb9dda4523b5969bcba75147ffe159e")
