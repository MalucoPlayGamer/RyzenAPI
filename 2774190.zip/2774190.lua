-- Lua provided by RyzenAPI
-- Game: addappid(2774190)

-- MAIN APPLICATION
addappid(2774190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2774191, 1, "aa993bcab7a738a99b6b6678af3dd3b310aebc1b2dec4d25176506b121d7d288")
