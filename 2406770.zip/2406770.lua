-- Lua provided by RyzenAPI
-- Game: Bodycam

-- MAIN APPLICATION
addappid(2406770)
-- Game: addappid(2406770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406771, 1, "0456324ba6c023dafc26bedc6005e6145a7b03bfe59a6d2806bf7e07ef54e6c2")
