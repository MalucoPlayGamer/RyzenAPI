-- Lua provided by SkyAPI 
-- Game: Bodycam
addappid(2406770)
addappid(2406771, 1, "0456324ba6c023dafc26bedc6005e6145a7b03bfe59a6d2806bf7e07ef54e6c2")
