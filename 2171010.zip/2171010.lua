-- Lua provided by RyzenAPI
-- Game: Game: The secret pyramid VR

-- MAIN APPLICATION
addappid(2171010)
-- Game: addappid(2171010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171011, 1, "0b21d0803b256c86c4944e8141953cee90f08d9ab1c3e50094f03925e4a4a4af")
