-- Lua provided by RyzenAPI
-- Game: addappid(1351380)

-- MAIN APPLICATION
addappid(1351380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351382,0,"d168f8b0b68b42a5dc4f5edaf127f29f16800dbbfa0dc8f1f10b39047137a0ad")
