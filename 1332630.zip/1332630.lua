-- Lua provided by RyzenAPI
-- Game: 1332630

-- MAIN APPLICATION
addappid(1332630)
-- Game: addappid(1332630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332631, 1, "1735db0223970c36f257e1d0445552be6fc9e8d427a2ebbfece83649695c8dbd")
