-- Lua provided by RyzenAPI
-- Game: addappid(1094320)

-- MAIN APPLICATION
addappid(1094320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094321, 1, "5a90843fc4004d71ff3f8407d6cebbe7832c0389558c5c15d5b94a44b8a4c199")
