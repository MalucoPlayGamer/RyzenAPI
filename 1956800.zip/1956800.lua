-- Lua provided by RyzenAPI
-- Game: Game: Thriving City: Song

-- MAIN APPLICATION
addappid(1956800)
-- Game: addappid(1956800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956801, 1, "f254dc89cb04fbc2228cbf01e4d818f698f4d45ebfa5761feb4d1c0b59ad6618")
addappid(1956802, 1, "d40c20925ad438fcb5041add7fa831e21103a1224637d2861a5c2721dff014fb")
