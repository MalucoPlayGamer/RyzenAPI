-- Lua provided by RyzenAPI
-- Game: God Of Arrows VR

-- MAIN APPLICATION
addappid(522730)

-- MAIN APP DEPOTS / PACKAGES
addappid(522731,0,"8e9b7927fb73da176b6db4c776f209d510510a2ed7794e4dba93af71c86b6943")

