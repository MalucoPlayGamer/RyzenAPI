-- Lua provided by RyzenAPI
-- Game: Big Rigs: Over the Road Racing-YOU’RE WINNER

-- MAIN APPLICATION
addappid(3610200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3610200,0,"f5129d179b9ab41544b088852d71c6e69de1e08f50ef1468b0bd3581179d9785")

