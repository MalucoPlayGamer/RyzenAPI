-- Lua provided by RyzenAPI
-- Game: 321830

-- MAIN APPLICATION
addappid(321830)
-- Game: addappid(321830)

-- MAIN APP DEPOTS / PACKAGES
addappid(321831, 1, "5d7a32a29955cd0922e77de2921d614d35335235dec947c41def449d2826b8ca")
