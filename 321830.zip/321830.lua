-- Lua provided by RyzenAPI
-- Game: AppID 321830

-- MAIN APPLICATION
addappid(321830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(321831, 1, "5d7a32a29955cd0922e77de2921d614d35335235dec947c41def449d2826b8ca")

