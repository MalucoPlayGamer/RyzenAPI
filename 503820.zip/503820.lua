-- Lua provided by SkyAPI 
-- Game: AppID 503820
addappid(503820)
addappid(503821, 1, "af1877d369e238bca49f0f8f90c3b8732d16d9decf8abfc2656df44f73e06f21")
