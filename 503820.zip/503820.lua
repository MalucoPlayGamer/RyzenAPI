-- Lua provided by RyzenAPI
-- Game: AppID 503820

-- MAIN APPLICATION
addappid(503820)
-- Game: addappid(503820)

-- MAIN APP DEPOTS / PACKAGES
addappid(503821, 1, "af1877d369e238bca49f0f8f90c3b8732d16d9decf8abfc2656df44f73e06f21")
