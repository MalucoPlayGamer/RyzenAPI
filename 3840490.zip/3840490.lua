-- Lua provided by RyzenAPI
-- Game: 3840490

-- MAIN APPLICATION
addappid(3840490)
-- Game: addappid(3840490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3840491, 1, "6ff5bc2ad4b4fd31535e554d423d3507fba7fc769b6d2ea0355e764e2c0d51eb")
