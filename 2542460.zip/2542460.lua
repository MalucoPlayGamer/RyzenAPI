-- Lua provided by RyzenAPI
-- Game: Monstronomy

-- MAIN APPLICATION
addappid(2542460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542461, 1, "8e60361d66c3dbe796178494619ddce2043365878b95d3afbcd7e6afb4a02852")

