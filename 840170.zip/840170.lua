-- Lua provided by RyzenAPI
-- Game: Delivery man simulator

-- MAIN APPLICATION
addappid(840170)

-- MAIN APP DEPOTS / PACKAGES
addappid(840171,0,"d31164f49f579814e7e31b12068155a3e90e78e31db48a31d31572764e5121e2")

