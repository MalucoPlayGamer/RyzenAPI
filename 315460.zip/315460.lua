-- Lua provided by RyzenAPI
-- Game: Dig or Die

-- MAIN APPLICATION
addappid(315460)

-- MAIN APP DEPOTS / PACKAGES
addappid(315461, 1, "03421b5268783284f68613a290c705dae24568d0b07bf6d2dfbb068328c2fbeb")

