-- Lua provided by RyzenAPI
-- Game: AppID 762950

-- MAIN APPLICATION
addappid(762950)
-- Game: addappid(762950)

-- MAIN APP DEPOTS / PACKAGES
addappid(762951, 1, "b6c7b9600b541888538bddf123695200917548f8ef98bd54cda73ab5e0442f12")
