-- Lua provided by RyzenAPI
-- Game: Crazy Alchemist

-- MAIN APPLICATION
addappid(914680)

-- MAIN APP DEPOTS / PACKAGES
addappid(914681, 1, "8f42efe555cff6be285a72ce68175f6b35059402d26dc997a6298900926e7314")
