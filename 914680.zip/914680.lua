-- Lua provided by SkyAPI 
-- Game: Crazy Alchemist
addappid(914680)
addappid(914681, 1, "8f42efe555cff6be285a72ce68175f6b35059402d26dc997a6298900926e7314")
