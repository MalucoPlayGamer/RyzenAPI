-- Lua provided by RyzenAPI
-- Game: Moon Runner

-- MAIN APPLICATION
addappid(1755240)
-- Game: addappid(1755240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755241, 1, "4c24ea660bc3c05b4165410ec1e85544b1305b6dfbc31ada0664378c0a5527d0")
