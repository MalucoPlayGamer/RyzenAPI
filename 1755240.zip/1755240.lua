-- Lua provided by RyzenAPI
-- Game: Moon Runner

-- MAIN APPLICATION
addappid(1755240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1755241, 1, "4c24ea660bc3c05b4165410ec1e85544b1305b6dfbc31ada0664378c0a5527d0")

