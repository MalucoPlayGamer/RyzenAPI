-- Lua provided by RyzenAPI
-- Game: Game: Hollow Cocoon

-- MAIN APPLICATION
addappid(2414630)
-- Game: addappid(2414630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2414631, 1, "3b4fa040c640e20822385134cdc30aa5414539210af253423b2c5550911e041a")
