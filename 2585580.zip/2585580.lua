-- Lua provided by RyzenAPI
-- Game: Legacy of Sin: Ill-Boding

-- MAIN APPLICATION
addappid(2585580)
addappid(3485490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585581, 1, "ebf0182bb881ffb042075d779cfffe6b41bf77d9f8a0d00df2dbbab57f8377b1")

