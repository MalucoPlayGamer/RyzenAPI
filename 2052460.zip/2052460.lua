-- Lua provided by RyzenAPI
-- Game: ENF Novels: Cold Night

-- MAIN APPLICATION
addappid(2052460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052461, 1, "18a6e4cc7a60feb3aeffe7daddd5c50291b116b0ea737c65d270260e56bd5f49")
