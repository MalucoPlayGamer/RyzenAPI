-- Lua provided by RyzenAPI
-- Game: 3271250

-- MAIN APPLICATION
addappid(3271250)
-- Game: addappid(3271250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271251, 1, "c86f29f35cbc4360e0573f9a73a86fa39be3d6b6f46f52a51ec50a8b5459e128")
