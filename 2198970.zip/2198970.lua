-- Lua provided by RyzenAPI
-- Game: Land of Towers

-- MAIN APPLICATION
addappid(2198970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198971, 1, "d300b501c9e295ef7a86d49aac3d75a22dc3af3f41c71f52a02ae0c3802142cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
