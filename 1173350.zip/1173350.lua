-- Lua provided by SkyAPI 
-- Game: HENTAI CLIMBER
addappid(1173350)
addappid(1173351, 1, "b4ebc175fa4d0bc0163914a33fb80f70f93d3a20f0dd41b83928671499a56525")
