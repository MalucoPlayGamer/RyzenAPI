-- Lua provided by SkyAPI 
-- Game: Armechgeddon
addappid(1929250)
addappid(1929251, 1, "44b5de22b19b68f722017b88ca384289c1a1ad53ad37969ab605d9862561dd57")
