-- Lua provided by RyzenAPI
-- Game: Game: The Neverwhere Tales - Book 1

-- MAIN APPLICATION
addappid(2639380)
-- Game: addappid(2639380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639381, 1, "e4715cee704fcdd9d3bad0a99cf879f59915d1765bdab3f0f749e5768e3351a0")
