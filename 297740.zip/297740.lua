-- Lua provided by RyzenAPI 
-- Game: Overruled!
addappid(297740)
addappid(297741, 1, "a043cf102928a327062df280b72f7871a74aeb02d07ab15a059425ecd8d6022d")
addappid(297742, 1, "d0d9d7a0c894a59f34a582e76aeaab91e85eb297f1adc2773fd893fe58e61f41")
addappid(297743, 1, "a900be8e4eaaaf64ee64118403fcadfcece647546153aad7f3920dd2fee9124b")
addappid(297744, 1, "50a40241c9cd25ead5efe5fda0a33259c1a57f6e8137ba6fbab09d94810ec5c4")
