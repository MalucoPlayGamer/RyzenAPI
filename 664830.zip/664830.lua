-- Lua provided by RyzenAPI
-- Game: Game: Zombotron

-- MAIN APPLICATION
addappid(664830)
-- Game: addappid(664830)

-- MAIN APP DEPOTS / PACKAGES
addappid(664831, 1, "a26b914ec23052a98e131cd0aaa2e6953df49d178da88cd3c0ba523b0dc865fe")
addappid(664832, 1, "b1649f6d111d676ff84d19c583e456770ecf6b75f605514e547306aa7386bcbb")
addappid(664833, 1, "d8797196818c99cb5491e64726c80bb1e2089dfcf5966fc61d536e94e94b3605")
addappid(664834, 1, "ea544780c5d3c9ad4523e8e64ba7f0082c866cfe51f8af8f0d267386455d7da6")
