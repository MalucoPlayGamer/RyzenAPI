-- Lua provided by RyzenAPI
-- Game: Switch - Or Die Trying

-- MAIN APPLICATION
addappid(506090)

-- MAIN APP DEPOTS / PACKAGES
addappid(506091, 1, "f7f96225a6d1dcd3e81e20271933fcc84ce0fb577a7024774796107da52f62ed")
addappid(604930, 0, "84576f1cf5eb40c28a05bb703d06f5957fc60f740e008535666ec52f705505f5")

