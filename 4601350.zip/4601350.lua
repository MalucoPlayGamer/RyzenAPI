-- 4601350's Lua and Manifest Created by Hubcap Manifest
-- GammaBoost+
-- Created: August 12, 2026 at 01:03:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4601350) -- GammaBoost+
-- MAIN APP DEPOTS
addappid(4601351, 1, "d66f4aafdee7f6cc722948f68daeb19550c323a9d8f0665a4c396e29dc3d9f33") -- Depot 4601351
setManifestid(4601351, "6937985909765815953", 247581160)