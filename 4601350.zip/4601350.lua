-- Lua provided by RyzenAPI
-- Game: GammaBoost+

-- MAIN APPLICATION
addappid(4601350) -- GammaBoost+

-- MAIN APP DEPOTS / PACKAGES
addappid(4601351, 1, "d66f4aafdee7f6cc722948f68daeb19550c323a9d8f0665a4c396e29dc3d9f33") -- Depot 4601351

