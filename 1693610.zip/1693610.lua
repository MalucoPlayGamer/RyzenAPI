-- Lua provided by RyzenAPI
-- Game: Game: Sudokolorful

-- MAIN APPLICATION
addappid(1693610)
-- Game: addappid(1693610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693611, 1, "ce8a493e27bedbd5660f7b2b3a0cf67bef80fe2319e1ac5c9388dee9a64b577a")
