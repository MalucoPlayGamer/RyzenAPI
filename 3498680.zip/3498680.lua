-- Lua provided by RyzenAPI 
-- Game: The Mindvasion
addappid(3498680)
addappid(3498681, 1, "768bb9f07ba36f109bd971094cd0f6d8dfecd632fa1584a9e2f4776e108ab187")
