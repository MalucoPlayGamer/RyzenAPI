-- Lua provided by RyzenAPI
-- Game: 3498680

-- MAIN APPLICATION
addappid(3498680)
-- Game: addappid(3498680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3498681, 1, "768bb9f07ba36f109bd971094cd0f6d8dfecd632fa1584a9e2f4776e108ab187")
