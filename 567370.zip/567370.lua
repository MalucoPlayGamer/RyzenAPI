-- Lua provided by RyzenAPI
-- Game: Atomic 79

-- MAIN APPLICATION
addappid(567370)
-- Game: addappid(567370)

-- MAIN APP DEPOTS / PACKAGES
addappid(567371, 1, "3bc1e6cdeec13f5e5291fcc78c095e8f34311eceb26a7d19b110aebe8cca76bd")
