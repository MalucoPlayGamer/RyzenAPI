-- Lua provided by RyzenAPI
-- Game: Game: Ambushed

-- MAIN APPLICATION
addappid(1856080)
-- Game: addappid(1856080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856081, 1, "09815192335573a8e8ffe14938f95252835d69271b814d7d2404770c23066f72")
