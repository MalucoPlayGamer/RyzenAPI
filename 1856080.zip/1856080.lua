-- Lua provided by SkyAPI 
-- Game: Ambushed
addappid(1856080)
addappid(1856081, 1, "09815192335573a8e8ffe14938f95252835d69271b814d7d2404770c23066f72")
