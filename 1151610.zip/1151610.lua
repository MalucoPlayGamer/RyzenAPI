-- Lua provided by RyzenAPI
-- Game: Game: 活下去

-- MAIN APPLICATION
addappid(1151610)
-- Game: addappid(1151610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151611, 1, "f142b8dc83b8159da224a941789c2b8130183c2cd3eeb882325e34f7eae217a0")
