-- 2435630's Lua and Manifest Created by Hubcap Manifest
-- Cell Machine Indev
-- Created: August 16, 2026 at 16:58:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2435630) -- Cell Machine Indev
-- MAIN APP DEPOTS
addappid(2435632, 1, "86b176fe8399ba187b5f29f72194d838d5756f6a4d45ef19617b8880e39fc54b") -- Depot 2435632
setManifestid(2435632, "9147226673444053655", 217524327)
addappid(2435633, 1, "a66951517aa394806071ecffb65d28768eb028dc416aaf98d43cfae59f551e9d") -- Depot 2435633
setManifestid(2435633, "6117495701510107843", 232679912)
addappid(2435634, 1, "b67be4c67ace57216bff15fcc33bef1bd186dc2470814b521c21d91dc6461323") -- Depot 2435634
setManifestid(2435634, "2837343459975402434", 237084692)