-- Lua provided by RyzenAPI
-- Game: Cell Machine Indev

-- MAIN APPLICATION
addappid(2435630) -- Cell Machine Indev

-- MAIN APP DEPOTS / PACKAGES
addappid(2435632, 1, "86b176fe8399ba187b5f29f72194d838d5756f6a4d45ef19617b8880e39fc54b") -- Depot 2435632
addappid(2435633, 1, "a66951517aa394806071ecffb65d28768eb028dc416aaf98d43cfae59f551e9d") -- Depot 2435633
addappid(2435634, 1, "b67be4c67ace57216bff15fcc33bef1bd186dc2470814b521c21d91dc6461323") -- Depot 2435634

