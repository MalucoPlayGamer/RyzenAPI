-- Lua provided by RyzenAPI 
-- Game: KAWAII SLIME ARENA
addappid(1837510)
addappid(1837511, 1, "56a0243196208e6666ca30e1b7ea6538b1511224bf41c0f36672c2c8b4e6c40c")
