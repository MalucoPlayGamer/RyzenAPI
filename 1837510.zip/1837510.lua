-- Lua provided by RyzenAPI
-- Game: KAWAII SLIME ARENA

-- MAIN APPLICATION
addappid(1837510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837511, 1, "56a0243196208e6666ca30e1b7ea6538b1511224bf41c0f36672c2c8b4e6c40c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
