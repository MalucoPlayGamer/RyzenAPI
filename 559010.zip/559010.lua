-- Lua provided by RyzenAPI
-- Game: Cosmic Sugar VR

-- MAIN APPLICATION
addappid(559010)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(560410)
