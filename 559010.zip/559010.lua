-- Lua provided by RyzenAPI
-- Game: Cosmic Sugar VR

-- MAIN APPLICATION
addappid(559010)
