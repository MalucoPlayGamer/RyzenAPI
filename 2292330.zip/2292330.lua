-- Lua provided by RyzenAPI
-- Game: addappid(2292330)

-- MAIN APPLICATION
addappid(2292330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292331, 1, "d64cf6b7d0dde704f0e7482b5e808c7c92e4bfd640ca2abae72998e94cb89ec9")
