-- Lua provided by SkyAPI 
-- Game: The Chronicles of Lancelot 2 - The Adventure to Avalon
addappid(3331580)
addappid(3331581, 1, "cbce4d82ef9e1c1086c93cc9f2df6832dc6986d29db7db7a2209081dd380d558")
