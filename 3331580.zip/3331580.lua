-- Lua provided by RyzenAPI
-- Game: The Chronicles of Lancelot 2 - The Adventure to Avalon

-- MAIN APPLICATION
addappid(3331580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331581, 1, "cbce4d82ef9e1c1086c93cc9f2df6832dc6986d29db7db7a2209081dd380d558")

