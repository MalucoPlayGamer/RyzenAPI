-- Lua provided by RyzenAPI
-- Game: Corrupted Paradise

-- MAIN APPLICATION
addappid(2701750)
-- Game: addappid(2701750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701751, 1, "0b49d809733f3c29c345861dd3655bc56b5e680b74285b1e596506dfb1f50b5f")
addappid(3327130, 0, "a6e2835c19958f4d1990533627b9dedbd85433dc8f0ffbc7b722f29c9a294cf1")
