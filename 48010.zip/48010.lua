-- Lua provided by RyzenAPI
-- Game: LIMBO Demo

-- MAIN APPLICATION
addappid(48010)
-- Game: addappid(48010)

-- MAIN APP DEPOTS / PACKAGES
addappid(48012,0,"0d7037ccb458ec90fee0a299326270e427366f5bd9de18c250da1ffe55561be4")
addappid(48014,0,"401e05a0806590864465b0c52327cd4134aa4902f52aac8e1945eb3d0bb611a2")
addappid(48015,0,"882dc1e7bed1f9a1ffd19008213af7f2f14cd42e62c29c906b1aaac7d1edca3e")
