-- Lua provided by RyzenAPI
-- Game: addappid(1211120)

-- MAIN APPLICATION
addappid(1211120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211121, 1, "9c38a1d2724231ac6d0eb06a9c17cf475e1a1aa07828e07b1c0014a966912e54")
