-- Lua provided by RyzenAPI
-- Game: AQUA KITTY UDX

-- MAIN APPLICATION
addappid(2217420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217421, 1, "573eb7941e9b1b6908e365ce38d24c25c194bef4d3bc93ee037646f0ded2d093")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
