-- Lua provided by SkyAPI 
-- Game: Farmer's Shop Simulator
addappid(2975460)
addappid(2975461, 1, "99aff9d633c7019337275977beacbd9a6e78f3f02e8b34d664b36142a606c9d2")
