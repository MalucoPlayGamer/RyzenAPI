-- Lua provided by RyzenAPI
-- Game: Farmer's Shop Simulator

-- MAIN APPLICATION
addappid(2975460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975461, 1, "99aff9d633c7019337275977beacbd9a6e78f3f02e8b34d664b36142a606c9d2")

