-- Lua provided by RyzenAPI
-- Game: Farmer's Shop Simulator

-- MAIN APPLICATION
addappid(2975460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2975461, 1, "99aff9d633c7019337275977beacbd9a6e78f3f02e8b34d664b36142a606c9d2")

