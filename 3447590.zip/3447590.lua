-- Lua provided by RyzenAPI
-- Game: Game: AppID 3447590

-- MAIN APPLICATION
addappid(3447590)
-- Game: addappid(3447590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3447591, 1, "ee32f648efea6c39c0b7bf2b464b066f47e12cd04ecff83403c4a3bd76a56797")
