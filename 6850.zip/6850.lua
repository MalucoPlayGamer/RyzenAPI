-- Lua provided by SkyAPI 
-- Game: Hitman 2: Silent Assassin
addappid(6850)
addappid(6851, 1, "f208fc795032e395aa6126f8b1a18ed8b33cbc5b6a78ef1469b0e3c957993169")
