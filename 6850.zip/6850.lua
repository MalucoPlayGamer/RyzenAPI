-- Lua provided by RyzenAPI
-- Game: Hitman 2: Silent Assassin

-- MAIN APPLICATION
addappid(6850)

-- MAIN APP DEPOTS / PACKAGES
addappid(6851, 1, "f208fc795032e395aa6126f8b1a18ed8b33cbc5b6a78ef1469b0e3c957993169")

