-- Lua provided by RyzenAPI
-- Game: Cookie Clicker Soundtrack

-- MAIN APPLICATION
addappid(1738020)
-- Game: addappid(1738020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738021, 1, "2ce0503c73a5d7d5e684ef6cca5a7e125b56eff799567a59cf4a247455bd7e13")
addappid(1738022, 1, "49267d0594a11ffd07cc226d84890c7826b85fa55622b99f20fa40f4d09ba94a")
