-- 4986740's Lua and Manifest Created by Hubcap Manifest
-- AFTERLIGHT: The Apartment
-- Created: August 25, 2026 at 11:14:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4986740) -- AFTERLIGHT: The Apartment
-- MAIN APP DEPOTS
addappid(4986741, 1, "309789bfe1b0bd61f5aad3f17b568d8febbf83b54f560bfadd85599f6c1eab0d") -- Depot 4986741
setManifestid(4986741, "956358313673963688", 690118540)