-- Lua provided by RyzenAPI
-- Game: AFTERLIGHT: The Apartment

-- MAIN APPLICATION
addappid(4986740) -- AFTERLIGHT: The Apartment

-- MAIN APP DEPOTS / PACKAGES
addappid(4986741, 1, "309789bfe1b0bd61f5aad3f17b568d8febbf83b54f560bfadd85599f6c1eab0d") -- Depot 4986741

