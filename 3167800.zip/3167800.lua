-- Lua provided by RyzenAPI
-- Game: Game: Therapy

-- MAIN APPLICATION
addappid(3167800)
-- Game: addappid(3167800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167801, 1, "cef4cf911e605c5e0320a5e960797773e975d654945b6b63f494f307aa055484")
