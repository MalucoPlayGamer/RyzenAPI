-- Lua provided by RyzenAPI
-- Game: 1889980

-- MAIN APPLICATION
addappid(1889980)
-- Game: addappid(1889980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889982,0,"4546c780b37b5baaccc6ae647caddd0286cbdf31b7bedcdf0cf61f140109d312")
addappid(1889983,0,"5e63a3360c1f7ceb257a0d2ec48b2cd6a74395f45989cee75a0fec9205765d52")
