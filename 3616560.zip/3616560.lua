-- Lua provided by RyzenAPI
-- Game: addappid(3616560)

-- MAIN APPLICATION
addappid(3616560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3616561, 1, "72989bce05366a5ef7a5d6b939da0e1aa3844b244ff217edbdcab21c6e728cda")
