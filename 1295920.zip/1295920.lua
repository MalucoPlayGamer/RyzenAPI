-- Lua provided by SkyAPI 
-- Game: The Mortuary Assistant
addappid(1295920)
addappid(1295921, 1, "6b61d645efde65dcb14c38641fec46ad7296e8fc2ae9343a376f37c5031850b0")
