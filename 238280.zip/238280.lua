-- Lua provided by RyzenAPI
-- Game: Legend of Dungeon

-- MAIN APPLICATION
addappid(238280)

-- MAIN APP DEPOTS / PACKAGES
addappid(238281, 1, "4653e69f87ea275f7d4b5babe260f4ddaf9eb948d249939ca861677d9d53018b")
addappid(238282, 1, "ee0cf7dd137a94f79234509e3f4ca53b0a9a2e31fc9000207606937b4239ccf7")
addappid(238283, 1, "f2a8626b57d044c8ecd2ab300d567d2081e200524221aa222ea159d0d59a6782")
addappid(255240, 0, "fff03c0eced1954cc5a86a829af7b2e145f4928678fe927726bfc6d03c10e385")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
