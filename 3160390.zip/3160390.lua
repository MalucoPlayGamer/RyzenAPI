-- Lua provided by RyzenAPI
-- Game: Fort Solis - 1 Year Anniversary Digital Goodies

-- MAIN APPLICATION
addappid(3160390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3160390,0,"1085cf46d657900b21a57d1eaed394acf64024a046f970529106d4c98b2da385")
