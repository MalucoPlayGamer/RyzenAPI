-- Lua provided by RyzenAPI
-- Game: Spellcats: Auto Card Tactics

-- MAIN APPLICATION
addappid(2150910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150911, 1, "130f9e8bfc2d67620a059a4a014bc0a716b5c742237f3cae2cfe32190d705506")
