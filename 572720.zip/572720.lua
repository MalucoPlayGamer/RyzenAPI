-- Lua provided by RyzenAPI
-- Game: Nancy Drew: The Shattered Medallion

-- MAIN APPLICATION
addappid(572720)
addappid(954120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(572721, 1, "1174885dd1093b82ba240359534a94341eb4e11ce3ad653e39d2ebacb897c60a")
