-- Lua provided by RyzenAPI
-- Game: Game: AppID 572720

-- MAIN APPLICATION
addappid(572720)
-- Game: addappid(572720)

-- MAIN APP DEPOTS / PACKAGES
addappid(572721, 1, "1174885dd1093b82ba240359534a94341eb4e11ce3ad653e39d2ebacb897c60a")
