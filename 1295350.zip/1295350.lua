-- Lua provided by RyzenAPI
-- Game: Resident Evil Resistance - Female Survivor Costume: Claire Redfield

-- MAIN APPLICATION
addappid(1295350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295350,0,"dbe021a1825f0f53da71272f5fd0f4e37669b27d0e00393fcc472b70f515dce7")
