-- Lua provided by RyzenAPI
-- Game: Song of Farca Demo

-- MAIN APPLICATION
addappid(1534990)
addappid(1534991)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435671,0,"4cda7f56fd6573e281189ae57d4368d8cb02255857fb90c8cbd3318697389809")

