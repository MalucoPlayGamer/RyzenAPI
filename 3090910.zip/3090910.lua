-- Lua provided by RyzenAPI
-- Game: 她杀 - The Suspected Murder

-- MAIN APPLICATION
addappid(3090910)
-- Game: addappid(3090910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3090911, 1, "c22a8cac9b7cb5cb9d17022ee77891cc84e8f77166aacfc08312faf79b8dd91b")
