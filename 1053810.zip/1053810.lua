-- Lua provided by RyzenAPI
-- Game: The World Next Door (Original Soundtrack)

-- MAIN APPLICATION
addappid(1053810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053810,0,"421d3f6014674a08786e50b0bf02230f90eb713866f6a74b328bbbd82f1e1af4")

