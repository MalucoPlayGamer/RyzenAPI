-- Lua provided by RyzenAPI
-- Game: Chaos Galaxy

-- MAIN APPLICATION
addappid(1184840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184841, 1, "59b82f4331a3be9dcacb8d732c20630da5d12f68e277c187f2f55260d58595da")
