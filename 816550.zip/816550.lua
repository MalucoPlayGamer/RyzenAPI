-- Lua provided by RyzenAPI
-- Game: Gallows

-- MAIN APPLICATION
addappid(816550)

-- MAIN APP DEPOTS / PACKAGES
addappid(816551,0,"a98df11e5ecfd839e647f127a8174e658aafd17f047469ce70e2567b751965e7")

