-- Lua provided by RyzenAPI
-- Game: 丧尸世界-经典策略卡牌养成

-- MAIN APPLICATION
addappid(2264970)
-- Game: addappid(2264970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264971, 1, "0ea046d5da7c4fa24c53530a3d8149115c9b19841a7b6aa4781e83885533ff56")
