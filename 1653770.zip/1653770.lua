-- Lua provided by RyzenAPI
-- Game: 1653770

-- MAIN APPLICATION
addappid(1653770)
-- Game: addappid(1653770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653771, 1, "cad547f4e4ff858d63017075599dd97545ef100a74fb8daf72e128a8f5dabce2")
