-- Lua provided by RyzenAPI
-- Game: Quantum Protocol Soundtrack

-- MAIN APPLICATION
addappid(1456450)
-- Game: addappid(1456450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456451, 1, "1597fcede42fcc8397a808c22adf950d1a2afe186488c7e0c0d560b6e2965db3")
addappid(1456452, 1, "a899525daac6f4038ee70113d21a4e128ca802e239211e4d144585037d99fe35")
