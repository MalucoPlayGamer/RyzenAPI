-- Lua provided by RyzenAPI
-- Game: Witches' Hallow

-- MAIN APPLICATION
addappid(2545340)
-- Game: addappid(2545340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545341, 1, "f943c88aa16c774fafe6bd301f4751c3bb0077a53f282a830d8a61fa49692bb4")
