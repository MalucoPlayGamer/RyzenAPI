-- Lua provided by RyzenAPI
-- Game: 3515310

-- MAIN APPLICATION
addappid(3515310)
-- Game: addappid(3515310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515311, 1, "67bff3d8329629cd99fb5e532be0b8e0077e0b0ccd617415557389bc92d53b5c")
