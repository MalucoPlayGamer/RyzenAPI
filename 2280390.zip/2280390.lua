-- Lua provided by RyzenAPI
-- Game: 2280390

-- MAIN APPLICATION
addappid(2280390)
-- Game: addappid(2280390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280391, 1, "003b98af1b727e93d43be53e54d1895151e16d713f845a8ba5293e0848ad11ee")
