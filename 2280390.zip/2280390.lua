-- Lua provided by RyzenAPI
-- Game: Tennis Manager 2023

-- MAIN APPLICATION
addappid(2280390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2280391, 1, "003b98af1b727e93d43be53e54d1895151e16d713f845a8ba5293e0848ad11ee")

