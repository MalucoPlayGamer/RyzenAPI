-- Lua provided by RyzenAPI
-- Game: Game: POLYZONE DEMO

-- MAIN APPLICATION
addappid(2824900)
-- Game: addappid(2824900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824901, 1, "44d54348a8a83097329bef8454ca872f0fec20a3deb3bf1b89ca42fad7eb2622")
