-- Lua provided by RyzenAPI
-- Game: Game: AppID 2529850

-- MAIN APPLICATION
addappid(2529850)
-- Game: addappid(2529850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529851, 1, "75bb8d22a5039228ae55166aa114b73190898d0e5b3d7a921f91586ad4ed3f55")
