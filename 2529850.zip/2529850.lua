-- Lua provided by RyzenAPI 
-- Game: AppID 2529850
addappid(2529850)
addappid(2529851, 1, "75bb8d22a5039228ae55166aa114b73190898d0e5b3d7a921f91586ad4ed3f55")
