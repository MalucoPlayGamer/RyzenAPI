-- Lua provided by RyzenAPI
-- Game: Blood High!

-- MAIN APPLICATION
addappid(4077400)

-- MAIN APP DEPOTS / PACKAGES
addappid(4077401,0,"6eb5d82fdaa20c8e41bda33f77f0660c162c218dcbffbcf4c3f4d2b9a5c3e241")

