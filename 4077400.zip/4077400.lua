-- Lua provided by RyzenAPI
-- Game: Blood High!

-- MAIN APPLICATION
addappid(4077400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4077401,0,"6eb5d82fdaa20c8e41bda33f77f0660c162c218dcbffbcf4c3f4d2b9a5c3e241")

