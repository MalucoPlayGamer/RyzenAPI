-- Lua provided by RyzenAPI
-- Game: Grim Legends 3: The Dark City

-- MAIN APPLICATION
addappid(458470)
addappid(715150)

-- MAIN APP DEPOTS / PACKAGES
addappid(458471, 1, "9e84b5c959f9482c64d9c1ac59f7213ab424c4f171479d60796101de9fcba9ce")

