-- Lua provided by RyzenAPI
-- Game: Game: Ghost Sync

-- MAIN APPLICATION
addappid(1711540)
addappid(1770940)
addappid(1770941)
addappid(1770942)
-- Game: addappid(1711540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711541, 1, "dd38601665ec0e3167329449b9d573d46595166ab15bfe728040858707a43230")
