-- Lua provided by SkyAPI 
-- Game: Climb Challenge - Find Items Cyberpunk
addappid(2703280)
addappid(2703281, 1, "cf216a1a33f16a0aa04df8c902d3ecc57982df512b5b616491591a3f33c8f3ee")
