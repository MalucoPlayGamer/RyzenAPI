-- Lua provided by RyzenAPI
-- Game: 2703280

-- MAIN APPLICATION
addappid(2703280)
-- Game: addappid(2703280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703281, 1, "cf216a1a33f16a0aa04df8c902d3ecc57982df512b5b616491591a3f33c8f3ee")
