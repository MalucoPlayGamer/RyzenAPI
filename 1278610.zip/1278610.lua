-- Lua provided by RyzenAPI
-- Game: Game: Last Oasis Soundtrack

-- MAIN APPLICATION
addappid(1278610)
-- Game: addappid(1278610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278611, 1, "65fc39c8618023e93becef829629bfb3153c8f10cc7dfec66b508c1c717d8179")
addappid(1278612, 1, "2c813d0555198339395655b9a7e5d6d159d47bdee7ba9571d16bac3388e9796f")
