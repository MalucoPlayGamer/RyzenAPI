-- Lua provided by RyzenAPI
-- Game: 1257250

-- MAIN APPLICATION
addappid(1257250)
-- Game: addappid(1257250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257251, 1, "52bdfe58feb29cb86bd0071c797ef1f7277973fa8fbaa89108a31a05be74f19c")
