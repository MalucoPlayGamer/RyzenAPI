-- Lua provided by RyzenAPI
-- Game: Avocado Love

-- MAIN APPLICATION
addappid(1846290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846291, 1, "cf541e50e56fa8292f2e279b3cbc155548b81042601d977dceb1c7380ca48d24")

