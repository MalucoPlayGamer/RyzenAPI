-- Lua provided by RyzenAPI
-- Game: 2378900

-- MAIN APPLICATION
addappid(2378900)
-- Game: addappid(2378900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378901, 1, "7e8df27c22fc52c5f740357a93710dcdb613817ef5c9e61763f20eb28b73d525")
