-- Lua provided by RyzenAPI
-- Game: 9-nine-:Episode 4

-- MAIN APPLICATION
addappid(1424660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424661, 1, "21abaa86202f86a718339e76e61da55fb30b386327c353a8360d8ebe7a22b9b7")
