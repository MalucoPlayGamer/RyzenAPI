-- Lua provided by RyzenAPI 
-- Game: Drone VR
addappid(1383650)
addappid(1383651, 1, "a442d49d54628df5941c2804c7abae94508ce53ccf82c281c437f05b39b1c76c")
