-- Lua provided by RyzenAPI
-- Game: AppID 339350

-- MAIN APPLICATION
addappid(339350)

-- MAIN APP DEPOTS / PACKAGES
addappid(339351, 1, "98ac6c970e450fab015f0a3f1809c32c84c94e2ded6d6c2eb19686fe0ac3c9b5")

