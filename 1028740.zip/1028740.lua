-- Lua provided by RyzenAPI
-- Game: AppID 1028740

-- MAIN APPLICATION
addappid(1028740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028741, 1, "2cedf2c52bd9d83cc2e004edde763953ec2f54f47c6caaa5eafb13a9c8e95c60")
