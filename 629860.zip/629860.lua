-- Lua provided by RyzenAPI
-- Game: AppID 629860

-- MAIN APPLICATION
addappid(629860)
-- Game: addappid(629860)

-- MAIN APP DEPOTS / PACKAGES
addappid(629861, 1, "1ac9916ead1d57392f4b6665d5e2b2f45c70920405cfa8261f08cf72b758b086")
