-- Lua provided by RyzenAPI
-- Game: Isekai Slave

-- MAIN APPLICATION
addappid(2366700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366701, 1, "4cb9b433183609632c044d978e12ebeb0bd87bb1b9516e78c1848e045b9751d5")

