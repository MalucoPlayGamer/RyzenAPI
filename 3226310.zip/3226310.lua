-- Lua provided by RyzenAPI 
-- Game: FURRY WHORES
addappid(3226310)
addappid(3226311, 1, "fb163b6369807dd7aee0f4f1a60f8a562103e34dd79e76d1a7a41442a23fec76")
