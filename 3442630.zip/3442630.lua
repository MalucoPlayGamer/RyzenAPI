-- Lua provided by RyzenAPI
-- Game: Game: BOKURA: planet  Special Demo

-- MAIN APPLICATION
addappid(3442630)
-- Game: addappid(3442630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3442631, 1, "154eb3ccbdb645f9c83b5431d7665157fcdbdf31d378c25c38ef11d24d30427c")
