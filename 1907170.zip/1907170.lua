-- Lua provided by RyzenAPI
-- Game: Adventure in My Head

-- MAIN APPLICATION
addappid(1907170)
addappid(2056260)
-- Game: addappid(1907170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907171, 1, "07f9852491a8ec2e578dc294ff492bce5ede2946149cb84f1bc59871e87ec965")
