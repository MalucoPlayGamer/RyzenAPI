-- Lua provided by RyzenAPI
-- Game: Bonesaw

-- MAIN APPLICATION
addappid(1586860)
-- Game: addappid(1586860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586863,0,"62046e9541f922e78b4990844a7167ba7ab8471e1af792f502c78bdafb747f24")
