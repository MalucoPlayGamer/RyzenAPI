-- Lua provided by RyzenAPI
-- Game: Bonesaw

-- MAIN APPLICATION
addappid(1586860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1586863,0,"62046e9541f922e78b4990844a7167ba7ab8471e1af792f502c78bdafb747f24")

