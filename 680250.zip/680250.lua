-- Lua provided by RyzenAPI
-- Game: The Mirage : Illusion of wish

-- MAIN APPLICATION
addappid(680250)

-- MAIN APP DEPOTS / PACKAGES
addappid(680251,0,"281a73e84bb32371245c3bfa653fb0c70333467256c376cd0a9dafca6fa64608")

