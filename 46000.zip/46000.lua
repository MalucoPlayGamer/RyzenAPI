-- Lua provided by RyzenAPI
-- Game: Bob Came in Pieces

-- MAIN APPLICATION
addappid(46000)

-- MAIN APP DEPOTS / PACKAGES
addappid(46001, 1, "a14a3ef044d5c9f1e8ac81354a7c70a29f6d43c61ea8564d1de495e9b68180db")
addappid(46002, 1, "01d8bc99318b6258068b5e5273ed203eea2c7f71dc731d9bc1134ac5b7171b54")
addappid(46003, 1, "55c0e030392a03674c667aeadbbd9f6294416588fe93341fee9f1de8764f1614")

