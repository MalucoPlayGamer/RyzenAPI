-- Lua provided by RyzenAPI
-- Game: MazeQuest 2

-- MAIN APPLICATION
addappid(738440)

-- MAIN APP DEPOTS / PACKAGES
addappid(738441,0,"e23d9a5aab91c8f042b8f434622a17c3189951e6126bc7b884ce035c4f503a04")

