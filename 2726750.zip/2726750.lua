-- Lua provided by RyzenAPI
-- Game: 病娇X契约

-- MAIN APPLICATION
addappid(2726750)
-- Game: addappid(2726750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726751, 1, "0db366c292f90f93896a4dd50a9bb5d938bc3e0ceee6201f24e20f7d04d9a53c")
