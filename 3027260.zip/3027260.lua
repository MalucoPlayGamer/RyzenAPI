-- Lua provided by SkyAPI 
-- Game: BEHEMOTH
addappid(3027260)
addappid(3027261, 1, "a7d69e809019979aaa0d8553c8a77f57435e7c515d606e299ff36e744a2337f8")
