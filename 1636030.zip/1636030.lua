-- Lua provided by RyzenAPI
-- Game: Crossfire: Sierra Squad

-- MAIN APPLICATION
addappid(1636030)
-- Game: addappid(1636030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636031, 1, "2d8720190d02579a8522454d9c5bc6e274fa1ac825921df614a1903e8cb580ae")
