-- Lua provided by RyzenAPI
-- Game: 105700

-- MAIN APPLICATION
addappid(105700)
-- Game: addappid(105700)

-- MAIN APP DEPOTS / PACKAGES
addappid(105701, 1, "32383a6cf1936873ede78a4a8512eb72e22260f1a520f56d335304e4dc3e535d")
