-- Lua provided by RyzenAPI
-- Game: Mazes and Labyrinths

-- MAIN APPLICATION
addappid(2641230)
-- Game: addappid(2641230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641231, 1, "602812a82cb416e4b699dc1900732af45e0743c813ec6865842656cb74ba6bef")
