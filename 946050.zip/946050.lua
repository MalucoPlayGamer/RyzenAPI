-- Lua provided by RyzenAPI
-- Game: Soda Dungeon 2

-- MAIN APPLICATION
addappid(946050)

