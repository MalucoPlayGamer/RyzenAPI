-- Lua provided by RyzenAPI
-- Game: AppID 1749750

-- MAIN APPLICATION
addappid(1749750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749751, 1, "df1a43a719b08e88f04345fffa4c8675b5fd85304af261ada11233f805811173")
addappid(2051970, 0, "21e0f12d187860fe3b67d369bd2180cad8669d2726c4b1eee68d2e3d0eb3b74d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1749780)
