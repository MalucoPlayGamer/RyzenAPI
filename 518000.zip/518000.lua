-- Lua provided by RyzenAPI
-- Game: Edge Guardian

-- MAIN APPLICATION
addappid(518000)

-- MAIN APP DEPOTS / PACKAGES
addappid(518001,0,"bd1dbc6b8b93d3c544b7500d9bfba1fe2db4a0c20dba1f77165d717c2089797e")

