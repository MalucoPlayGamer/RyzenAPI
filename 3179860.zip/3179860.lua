-- Lua provided by RyzenAPI
-- Game: Game: Pairs & Perils

-- MAIN APPLICATION
addappid(3179860)
-- Game: addappid(3179860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179861, 1, "f1183ae961a62306a7c258b9fc023998b3de1b037f35e3b02ecb9546a423c6f7")
addappid(3179862, 1, "340ba25f5317c663139a3aea7a610768f2727773f4cf038ce050aa4069db11d9")
addappid(3179863, 1, "a95d6592b1f81939c11dfd2b33c7b1360e039b2c94aca593fe0d37b7a3a93fe9")
