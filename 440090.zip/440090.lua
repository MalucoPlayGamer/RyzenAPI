-- Lua provided by RyzenAPI
-- Game: Game: AppID 440090

-- MAIN APPLICATION
addappid(440090)
-- Game: addappid(440090)

-- MAIN APP DEPOTS / PACKAGES
addappid(440091, 1, "9db70b5814258e0496890910fe143203cebca60210203f812ae78273a4984fd1")
addappid(440092, 1, "a54e6c5dbebe61531527bc838a5300f711882afe6279c94dd7aa3c9bf59add1a")
