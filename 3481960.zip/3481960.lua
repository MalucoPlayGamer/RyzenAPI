-- Lua provided by RyzenAPI
-- Game: Game: No Alibi Demo

-- MAIN APPLICATION
addappid(3481960)
-- Game: addappid(3481960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3481961, 1, "3884cd1b92d2526c536db2595f82b4301e3b1431d2b7216afaa452ea46306758")
