-- Lua provided by RyzenAPI 
-- Game: Heart attack
addappid(1903530)
addappid(1903531, 1, "be51f19483ac06b2e8388ce7d8863e0c777ede254dd6d651359bd8f08af96805")
