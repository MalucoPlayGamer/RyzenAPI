-- Lua provided by RyzenAPI
-- Game: Heart attack

-- MAIN APPLICATION
addappid(1903530)
-- Game: addappid(1903530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903531, 1, "be51f19483ac06b2e8388ce7d8863e0c777ede254dd6d651359bd8f08af96805")
