-- Lua provided by RyzenAPI
-- Game: The Chad

-- MAIN APPLICATION
addappid(2605260)
-- Game: addappid(2605260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605261, 1, "f6684851dead6b0be4c44bdb0eaf3cd215efbd00f02d6853033968308973180e")
