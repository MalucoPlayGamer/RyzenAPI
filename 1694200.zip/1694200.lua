-- Lua provided by RyzenAPI
-- Game: Dragon And Home

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1694200)
addappid(1694201)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694202,0,"7f0bf21138e6d59b2daa4d3b610317068e76391069d217895e8e47e69e3e0030")

