-- Lua provided by RyzenAPI
-- Game: Zula Global

-- MAIN APPLICATION
addappid(747610)
addappid(1823680)

-- MAIN APP DEPOTS / PACKAGES
addappid(747611, 1, "e37f18f50ae544a1995484305b7cb7b819e209723f0d3e5ddc58daacedfb3e17")

