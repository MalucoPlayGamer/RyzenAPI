-- Lua provided by RyzenAPI
-- Game: WhiTaers

-- MAIN APPLICATION
addappid(714130)

-- MAIN APP DEPOTS / PACKAGES
addappid(714131, 1, "20373b1a91e896c100217bacbc04b78bb36c861011d9538411a24b9fc357f6d3")
