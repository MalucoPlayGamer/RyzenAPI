-- Lua provided by RyzenAPI
-- Game: AppID 1296510

-- MAIN APPLICATION
addappid(1296510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296511, 1, "7bc0d08264747e1e8f75d4c2b4d5f627dcbf956fb9a12367807b49de1c35bb03")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
