-- Lua provided by SkyAPI 
-- Game: AppID 1953560
addappid(1953560)
addappid(1953561, 1, "fdebeac3698abd06ce3bcd3f6f53e582e018806d80e29c7ac2f2b7073344a397")
addappid(1953562, 1, "d29589fe0019d623c838f433d87292bc7e56b5d7bd1db05800b7f59edcc97f1b")
