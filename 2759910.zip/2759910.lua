-- Lua provided by RyzenAPI
-- Game: addappid(2759910)

-- MAIN APPLICATION
addappid(2759910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2759911, 1, "671c858417b27c8da8db7480e93257064cefc3051be3de9aec9687a125432d6f")
