-- Lua provided by RyzenAPI
-- Game: Mighty Gemstones

-- MAIN APPLICATION
addappid(778230)
addappid(883250)

-- MAIN APP DEPOTS / PACKAGES
addappid(778231, 1, "b8067e06c63c6407714add6105e0531f290f43081ebf54dde3ffc28168a51e5e")
