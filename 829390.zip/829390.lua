-- Lua provided by RyzenAPI 
-- Game: AppID 829390
addappid(829390)
addappid(829391, 1, "c98478f00b3cadf29e7b665e4b4126bcbf12509f916a09312f8514680eb5ef09")
addappid(829392, 1, "2dd8a2315ff828052333dcb5c2779e4f09dbbd371b87b53b7a0a38181c77ceaf")
