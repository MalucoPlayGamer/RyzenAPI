-- Lua provided by RyzenAPI
-- Game: Hospital Aliens 2

-- MAIN APPLICATION
addappid(2653210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653211, 1, "6b28dabc131177a454d234eaa9d50d3408cbc8af52710d3417e30de5bd17bafc")
