-- Lua provided by RyzenAPI
-- Game: Hospital Aliens 2

-- MAIN APPLICATION
addappid(2653210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653211, 1, "6b28dabc131177a454d234eaa9d50d3408cbc8af52710d3417e30de5bd17bafc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
