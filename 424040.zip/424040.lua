-- Lua provided by RyzenAPI
-- Game: Fragmental

-- MAIN APPLICATION
addappid(424040)

-- MAIN APP DEPOTS / PACKAGES
addappid(424041, 1, "736c789c4186b81ecac7f5433cfe4ad2ce18c35c6638d2cdb042e6eedadf0477")
