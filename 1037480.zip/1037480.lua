-- Lua provided by RyzenAPI
-- Game: Classic Racers

-- MAIN APPLICATION
addappid(1037480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037481, 1, "54ba3fb391969286b751b7be9ea74aba32711f8202c08eef81870b851089ca28")

