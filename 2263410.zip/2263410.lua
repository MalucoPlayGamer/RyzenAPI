-- Lua provided by RyzenAPI
-- Game: Napoleon Maiden ~A maiden without the word impossible~ Theme Song Collection

-- MAIN APPLICATION
addappid(2263410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263411, 1, "c186599970df47d24b131185301d7ded9282db8deb0a96110a271e5e4c771972")
addappid(2263412, 1, "4955ceb3215548b84549f131e621324c078ebbb24d285731a7480908beca3eb6")
