-- Lua provided by RyzenAPI
-- Game: Ark Mobius

-- MAIN APPLICATION
addappid(1594090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594091, 1, "99724be5b6dbe7164a70b1f32299054c0930635e4b2f63e2afd4fe62c7165d18")

