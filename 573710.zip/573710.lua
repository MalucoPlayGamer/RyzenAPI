-- Lua provided by RyzenAPI
-- Game: addappid(573710)

-- MAIN APPLICATION
addappid(573710)

-- MAIN APP DEPOTS / PACKAGES
addappid(573711, 1, "2d68b7a7d9c9371bcd3fc5c8002e36e7ee8826e74bc5c5e3c9576c377bc0d71d")
