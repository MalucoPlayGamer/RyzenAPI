-- Lua provided by SkyAPI 
-- Game: Still Light
addappid(1452180)
addappid(1452181, 1, "606aa169a45092eba28c2010d093e3ab264292110dc2dc58beec222be94c659f")
