-- Lua provided by RyzenAPI
-- Game: Plattis

-- MAIN APPLICATION
addappid(3244200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3244201, 1, "098432a8da2e72b5001ebe50af3ca13b180e9c3b6aaa7d988f5cc91fad19b202")

