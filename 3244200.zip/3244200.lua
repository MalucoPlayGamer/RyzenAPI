-- Lua provided by RyzenAPI
-- Game: Game: Plattis

-- MAIN APPLICATION
addappid(3244200)
-- Game: addappid(3244200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244201, 1, "098432a8da2e72b5001ebe50af3ca13b180e9c3b6aaa7d988f5cc91fad19b202")
