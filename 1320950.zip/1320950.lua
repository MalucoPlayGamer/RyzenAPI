-- Lua provided by RyzenAPI
-- Game: The Swine

-- MAIN APPLICATION
addappid(1320950)
-- Game: addappid(1320950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320951, 1, "a91f483e8aeecce6377253b19d1c990d47881e4f8e82b9fae25a965b84302b0c")
