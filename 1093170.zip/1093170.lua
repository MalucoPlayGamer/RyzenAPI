-- Lua provided by RyzenAPI
-- Game: AppID 1093170

-- MAIN APPLICATION
addappid(1093170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093171, 1, "8dcebe553bfaaba26db2989b3e748548e18cc3411169b2a796ac3cc8cde68e64")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1524500)
