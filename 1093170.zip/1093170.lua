-- Lua provided by RyzenAPI 
-- Game: AppID 1093170
addappid(1093170)
addappid(1093171, 1, "8dcebe553bfaaba26db2989b3e748548e18cc3411169b2a796ac3cc8cde68e64")
