-- Lua provided by RyzenAPI
-- Game: LIP! Lewd Idol Project Vol. 3 - Hot Springs and Beach Episodes

-- MAIN APPLICATION
addappid(3171240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171241, 1, "b15c15b58587a0b6fafe7fd51e765b0f67ee27a1e059994c3c8a38734c5a090d")

