-- Lua provided by RyzenAPI
-- Game: addappid(1525050)

-- MAIN APPLICATION
addappid(1525050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525051, 1, "d5d151c97fa1c979dc6effe5c355a6ea78fc1f08af0dc0daf1e29dae01fac767")
addappid(1525052, 1, "7a92943cea2a4e6855d19b51db195c43cfbcef8f4c109b2b93c6c3933afe505a")
addappid(1525053, 1, "c34988b48761958aac7ef2dc876375d3a1242d29dddbcc8d46aadf394d53a451")
addappid(2595520, 0, "1136e954f9119f99f4b7b89c7a254babdb2698a904367c213ad050957171e45a")
