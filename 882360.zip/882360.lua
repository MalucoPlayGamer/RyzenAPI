-- Lua provided by RyzenAPI
-- Game: 882360

-- MAIN APPLICATION
addappid(882360)
-- Game: addappid(882360)

-- MAIN APP DEPOTS / PACKAGES
addappid(882361, 1, "9e887a4eb09a65c324cea4b857a7794c90fcdf9ad4efda1c39185a37a4b742b5")
