-- Lua provided by RyzenAPI
-- Game: 3491700

-- MAIN APPLICATION
addappid(3491700)
-- Game: addappid(3491700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3491701, 1, "e3cbc99b2acebe0789484bc82a9b44fdb5c050d4e4e9cf6b47a4dc61a0c9b249")
