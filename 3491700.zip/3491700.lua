-- Lua provided by SkyAPI 
-- Game: The Music at the end of the World
addappid(3491700)
addappid(3491701, 1, "e3cbc99b2acebe0789484bc82a9b44fdb5c050d4e4e9cf6b47a4dc61a0c9b249")
