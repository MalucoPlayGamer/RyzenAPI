-- Lua provided by RyzenAPI
-- Game: Heliotropism

-- MAIN APPLICATION
addappid(1653100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653101, 1, "1c15654a55577f83143aaca29bacb5b8cd5c9e182d6fbf162c73365186dfc888")

