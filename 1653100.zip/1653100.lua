-- Lua provided by RyzenAPI 
-- Game: Heliotropism
addappid(1653100)
addappid(1653101, 1, "1c15654a55577f83143aaca29bacb5b8cd5c9e182d6fbf162c73365186dfc888")
