-- Lua provided by RyzenAPI
-- Game: addappid(2658510)

-- MAIN APPLICATION
addappid(2658510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658511, 1, "a48c2e31217f8135a3c94b510a5fcc9053ec566353f54bc6a17f9e42c2e36481")
