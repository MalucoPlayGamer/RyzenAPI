-- Lua provided by RyzenAPI
-- Game: Animal Shelter 2

-- MAIN APPLICATION
addappid(2658510) -- Animal Shelter 2
addappid(4119650) -- Animal Shelter 2 - Little Friends DLC
addappid(4247800) -- Animal Shelter 2 - Vet Clinic DLC
addappid(4613570) -- Animal Shelter 2 - Hunting Dogs Pack
addappid(4831010) -- Animal Shelter 2 - Bull-Type Terriers Dogs Pack
addappid(4831020) -- Animal Shelter 2 - Fluffy Cats Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(2658511, 1, "a48c2e31217f8135a3c94b510a5fcc9053ec566353f54bc6a17f9e42c2e36481") -- Depot 2658511

