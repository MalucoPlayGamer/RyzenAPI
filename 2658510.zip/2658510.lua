-- 2658510's Lua and Manifest Created by Hubcap Manifest
-- Animal Shelter 2
-- Created: July 28, 2026 at 21:35:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(2658510) -- Animal Shelter 2
-- MAIN APP DEPOTS
addappid(2658511, 1, "a48c2e31217f8135a3c94b510a5fcc9053ec566353f54bc6a17f9e42c2e36481") -- Depot 2658511
setManifestid(2658511, "7760319976994993730", 17419767132)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4119650) -- Animal Shelter 2 - Little Friends DLC
addappid(4247800) -- Animal Shelter 2 - Vet Clinic DLC
addappid(4613570) -- Animal Shelter 2 - Hunting Dogs Pack
addappid(4831010) -- Animal Shelter 2 - Bull-Type Terriers Dogs Pack
addappid(4831020) -- Animal Shelter 2 - Fluffy Cats Pack