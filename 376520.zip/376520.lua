-- Lua provided by RyzenAPI
-- Game: Kelvin and the Infamous Machine

-- MAIN APPLICATION
addappid(376520)

-- MAIN APP DEPOTS / PACKAGES
addappid(376521, 1, "3799b29ec790f116d3e0573daccdb439aa33c16cc451e15ef13fdfbf30cbf918")
addappid(376522, 1, "159f211b02648f42fcaaf350748b32bfd58bbdd77ae9202355bfe7bcd2c1a597")
addappid(376523, 1, "e51fb7a227e142d7f26d1b98a25e36365aa5e35a866a60838a9858f7056c210c")
addappid(506620, 0, "42abbba7a7dfe3c4cdef75a582758a886eb653dbe1fb9c61bd33bbf149946ece")
