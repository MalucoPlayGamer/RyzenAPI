-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker Series MagicalShot The AttackBump☆

-- MAIN APPLICATION
addappid(4300420) -- Pixel Game Maker Series MagicalShot The AttackBump☆

-- MAIN APP DEPOTS / PACKAGES
addappid(4300421, 1, "34d2c5573c287d8b34b8430be72e109ab77ca70f09f6bbd475d30f3475b7edf0") -- Depot 4300421

