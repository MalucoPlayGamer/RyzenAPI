-- 4300420's Lua and Manifest Created by Hubcap Manifest
-- Pixel Game Maker Series MagicalShot The AttackBump☆
-- Created: August 23, 2026 at 00:25:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4300420) -- Pixel Game Maker Series MagicalShot The AttackBump☆
-- MAIN APP DEPOTS
addappid(4300421, 1, "34d2c5573c287d8b34b8430be72e109ab77ca70f09f6bbd475d30f3475b7edf0") -- Depot 4300421
setManifestid(4300421, "696862696755763638", 622880747)