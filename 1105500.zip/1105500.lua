-- Lua provided by RyzenAPI 
-- Game: Yakuza 4 Remastered
addappid(1105500)
addappid(1105501, 1, "cffc68d6e7a4f09d3a9c8f4749651f94d5f148f5b9adc30190b522a8954ad140")
addappid(1105502, 1, "237653df87e9e42840a9f5111f0aabcd598c530a044ed29d27104d4a05cb7d57")
