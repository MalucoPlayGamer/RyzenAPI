-- Lua provided by RyzenAPI
-- Game: Escape Memoirs: Mini Stories

-- MAIN APPLICATION
addappid(2098350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098351, 1, "34202c22271c288aa527cea772c8beb990ccf489d2a6d124aac1c5858def4bac")
