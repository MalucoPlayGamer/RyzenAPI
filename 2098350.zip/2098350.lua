-- Lua provided by RyzenAPI
-- Game: Escape Memoirs: Mini Stories

-- MAIN APPLICATION
addappid(2098350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098351, 1, "34202c22271c288aa527cea772c8beb990ccf489d2a6d124aac1c5858def4bac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2190440)
addappid(2222460)
