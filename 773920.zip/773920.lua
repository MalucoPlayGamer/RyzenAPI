-- Lua provided by RyzenAPI
-- Game: AppID 773920

-- MAIN APPLICATION
addappid(773920)
-- Game: addappid(773920)

-- MAIN APP DEPOTS / PACKAGES
addappid(773921, 1, "b0fc760b485e20ba1a53ad651c5f253d9badddc5fff9f728dbaa0069332d1ec3")
addappid(773922, 1, "2f19b8e42a4d4c08ca13e67600756ddbb91f488323befdb186e90e17520284ee")
addappid(773923, 1, "ed02dc6846c8abd092fba5ac119825a49f7e63b45f33106e166bc313e8cda19e")
addappid(773924, 1, "b332722cb6afddbba95c2e5161bbd974b36d127a42f2103fa460f105c51a6d1b")
addappid(773925, 1, "bc811bbb5bab36594ebd800ab78fc8cba6783063c1b2232669dea58daf1b7d12")
addappid(773926, 1, "3178d14ad528cc1c91593620a9ca23f81651117023d2cd68baedc875275f75dd")
