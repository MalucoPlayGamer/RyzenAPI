-- Lua provided by RyzenAPI
-- Game: Game: Cosmic Coliseum

-- MAIN APPLICATION
addappid(2158810)
-- Game: addappid(2158810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158811, 1, "92841fb59aa8b7c0c44f750aa8c7d052bc11d76a32467c44a716efc4b774458b")
