-- Lua provided by RyzenAPI
-- Game: EXS2～EthnologySister2：Structuralism of kinship system

-- MAIN APPLICATION
addappid(2091630)
