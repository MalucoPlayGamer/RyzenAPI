-- Lua provided by RyzenAPI
-- Game: AppID 3203750

-- MAIN APPLICATION
addappid(3203750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3203751, 1, "bce773534a7e3c7b0a40bcfd5c4c70c70def0315902ffc76df2b6c2a873078d4")
