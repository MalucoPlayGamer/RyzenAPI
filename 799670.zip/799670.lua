-- Lua provided by RyzenAPI 
-- Game: AppID 799670
addappid(799670)
addappid(799671, 1, "c20e34d4afa0e5800623013b12e3f94f44373a0c5b534feb26c1832a4ae6b797")
addappid(799672, 1, "196f518f43cc6024b306ddb2d749c3e4ce34f1fc5627df3f7184b31529c57cca")
