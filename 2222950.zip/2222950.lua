-- Lua provided by RyzenAPI
-- Game: Captain Velvet Meteor: The Jump+ Dimensions

-- MAIN APPLICATION
addappid(2222950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222952,0,"6e085e0017ef90c0ee02041bf8ec57fbd2e3ef95af404a8e19f02a6c71992e6a")
