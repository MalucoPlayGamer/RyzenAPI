-- Lua provided by RyzenAPI
-- Game: 1029150

-- MAIN APPLICATION
addappid(1029150)
-- Game: addappid(1029150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029151, 1, "45e01203c7ac67c3946e265cc6135129155d6d8fb172da708c210e3959fb6abc")
