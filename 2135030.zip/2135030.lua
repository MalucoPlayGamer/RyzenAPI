-- Lua provided by RyzenAPI
-- Game: addappid(2135030)

-- MAIN APPLICATION
addappid(2135030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135031, 1, "e62ec4ced2586d96ac07f63c97f304a2fda81999fb7a6c3ef233b3c8eb78447d")
