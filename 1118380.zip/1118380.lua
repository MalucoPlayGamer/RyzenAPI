-- Lua provided by RyzenAPI
-- Game: Bot Studio for Discord

-- MAIN APPLICATION
addappid(1118380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118382,0,"dd7240f8207937ac0803e4c8c6040e7f20892b03f5d71a1465b325be98f77413")

