-- Lua provided by RyzenAPI
-- Game: Game: Detective - The Test

-- MAIN APPLICATION
addappid(3473570)
-- Game: addappid(3473570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473571, 1, "8b0bdea1176b461f71653e71b1d9061a0bd957ed2023af5db3f99eef5dbb0b10")
