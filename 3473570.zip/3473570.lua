-- Lua provided by RyzenAPI
-- Game: Detective - The Test

-- MAIN APPLICATION
addappid(3473570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473571, 1, "8b0bdea1176b461f71653e71b1d9061a0bd957ed2023af5db3f99eef5dbb0b10")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
