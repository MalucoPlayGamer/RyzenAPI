-- Lua provided by RyzenAPI
-- Game: addappid(1191170)

-- MAIN APPLICATION
addappid(1191170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191171, 1, "48ebfffa0115a0d5d439de98c20bd9deb0f3b6760d14936c75e614ffbb4c082c")
