-- Lua provided by RyzenAPI
-- Game: Eminus Demo

-- MAIN APPLICATION
addappid(1543840)
-- Game: addappid(1543840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543841, 1, "04680a16b508fe335db8ffb12287f838bb251239f92622467096cda91b9e3f9a")
