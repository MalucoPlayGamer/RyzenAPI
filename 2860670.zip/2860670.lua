-- Lua provided by RyzenAPI
-- Game: Souls of Shadow

-- MAIN APPLICATION
addappid(2860670) -- Souls of Shadow

-- MAIN APP DEPOTS / PACKAGES
addappid(2860671, 1, "d1868be0db045773819446c99e8776c11135624216822f9fb4e10acdc3c2653b") -- Depot 2860671

