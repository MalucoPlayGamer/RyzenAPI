-- Lua provided by RyzenAPI
-- Game: Basics In Intermediate Filmmaking

-- MAIN APPLICATION
addappid(2477740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477743,0,"f68337b17e9e8e3aef61d17c8ba48707c68721bf5c1e8e3b73ef51295bc0ff2d")
