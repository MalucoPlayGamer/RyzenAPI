-- Lua provided by RyzenAPI
-- Game: Basics In Intermediate Filmmaking

-- MAIN APPLICATION
addappid(2477740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2477743,0,"f68337b17e9e8e3aef61d17c8ba48707c68721bf5c1e8e3b73ef51295bc0ff2d")

