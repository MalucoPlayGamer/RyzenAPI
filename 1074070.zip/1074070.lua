-- Lua provided by SkyAPI 
-- Game: Dust to the End
addappid(1074070)
addappid(1074071, 1, "1d22622abe12096b66b56585d8a7f9bc3fb58695ff0ce01da7467266f07a2272")
