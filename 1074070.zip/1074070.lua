-- Lua provided by RyzenAPI
-- Game: Dust to the End

-- MAIN APPLICATION
addappid(1074070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074071, 1, "1d22622abe12096b66b56585d8a7f9bc3fb58695ff0ce01da7467266f07a2272")

