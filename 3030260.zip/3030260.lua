-- Lua provided by RyzenAPI
-- Game: Familiar Friends: What's Your Familiar?

-- MAIN APPLICATION
addappid(3030260)

