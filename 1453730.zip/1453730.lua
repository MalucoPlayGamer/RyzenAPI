-- Lua provided by RyzenAPI
-- Game: Liminal

-- MAIN APPLICATION
addappid(1453730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453731, 1, "ff2dd4745bfe21277e7623794703ccd0a83f142286cf4cd067c7fb0353416ef8")

