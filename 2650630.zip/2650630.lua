-- Lua provided by RyzenAPI
-- Game: Last Hope

-- MAIN APPLICATION
addappid(2650630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650631, 1, "03334fffeb88386e9b3d33688832c236c1ce54d4d782a0a43d057d831a04acb7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
