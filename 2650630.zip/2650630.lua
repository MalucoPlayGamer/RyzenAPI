-- Lua provided by RyzenAPI
-- Game: Game: Last Hope

-- MAIN APPLICATION
addappid(2650630)
-- Game: addappid(2650630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650631, 1, "03334fffeb88386e9b3d33688832c236c1ce54d4d782a0a43d057d831a04acb7")
