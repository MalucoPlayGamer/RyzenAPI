-- Lua provided by RyzenAPI
-- Game: 1491550

-- MAIN APPLICATION
addappid(1491550)
-- Game: addappid(1491550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491555,0,"10a0b454da101a3d21d48fad8ae7660dffc39d25a9cc007132804cb64c076261")
