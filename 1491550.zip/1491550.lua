-- Lua provided by RyzenAPI
-- Game: Accident On the Simple Rd

-- MAIN APPLICATION
addappid(1491550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491555,0,"10a0b454da101a3d21d48fad8ae7660dffc39d25a9cc007132804cb64c076261")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
