-- Lua provided by RyzenAPI
-- Game: 千面 Melancholy Love Soundtrack

-- MAIN APPLICATION
addappid(1296640)
-- Game: addappid(1296640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296641, 1, "6eb90bb4672af6ecf10b98d3b3d32da1577c4e9f11ea059f7044d612c3222c94")
addappid(1296642, 1, "bd8c80501852e53ee15b0ef4d6562a1f82afdb2197633c008efc6ad85dd77e48")
