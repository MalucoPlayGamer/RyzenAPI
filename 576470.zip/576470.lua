-- Lua provided by RyzenAPI
-- Game: AppID 576470

-- MAIN APPLICATION
addappid(576470)
-- Game: addappid(576470)

-- MAIN APP DEPOTS / PACKAGES
addappid(576471, 1, "a6065dc63a657f49e2bbbb2db02efc66c15d37a6cb107f6b1b043cc1825618a3")
