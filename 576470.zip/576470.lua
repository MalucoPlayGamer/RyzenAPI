-- Lua provided by RyzenAPI
-- Game: AppID 576470

-- MAIN APPLICATION
addappid(576470)

-- MAIN APP DEPOTS / PACKAGES
addappid(576471, 1, "a6065dc63a657f49e2bbbb2db02efc66c15d37a6cb107f6b1b043cc1825618a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(576520)
addappid(576530)
addappid(1307290)
addappid(1309150)
addappid(1309151)
addappid(1309152)
addappid(1309153)
addappid(1309154)
addappid(1309155)
addappid(1309156)
addappid(1309159)
addappid(1310730)
addappid(1310731)
addappid(1337180)
addappid(1337181)
addappid(1337182)
addappid(1355870)
addappid(1355871)
addappid(1355872)
addappid(1451340)
