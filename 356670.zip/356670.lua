-- Lua provided by RyzenAPI
-- Game: Spooky's Jump Scare Mansion

-- MAIN APPLICATION
addappid(356670)

