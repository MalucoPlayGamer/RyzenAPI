-- Lua provided by RyzenAPI
-- Game: 1896920

-- MAIN APPLICATION
addappid(1896920)
-- Game: addappid(1896920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896921, 1, "8e75c0333396d639f736d8ea25931919c900ae6dd9c8b9b5645dfb713e5cb1e4")
