-- Lua provided by RyzenAPI
-- Game: Lamia Must Die

-- MAIN APPLICATION
addappid(385260)
-- Game: addappid(385260)

-- MAIN APP DEPOTS / PACKAGES
addappid(385261, 1, "111bd984993ad9010d16c1ed7a9ec71e179c3e4036e504c0a0d26de4e8b050d5")
