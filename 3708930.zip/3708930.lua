-- Lua provided by RyzenAPI
-- Game: addappid(3708930)

-- MAIN APPLICATION
addappid(3708930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3708931, 1, "695d366228fb7273411c78ea58cecb80d3782aadc435e95fbbfe0f7f006f00d8")
