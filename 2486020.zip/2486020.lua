-- Lua provided by RyzenAPI
-- Game: 2486020

-- MAIN APPLICATION
addappid(2486020)
addappid(2486023)
addappid(2486024)

-- MAIN APP DEPOTS / PACKAGES
addappid(2486022,0,"bbb36c302bc4a915618c3d33985f497f60bcd49a3dbc4a4fca96d3989096a5ec")
