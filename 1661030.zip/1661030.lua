-- Lua provided by RyzenAPI
-- Game: 恋爱关系 Demo

-- MAIN APPLICATION
addappid(1661030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661031, 1, "e0880a397a8fbb3de5719bcc8b9e421a877a00b1ccb3d57a175f17782a526d0f")
