-- Lua provided by RyzenAPI
-- Game: AppID 1434720

-- MAIN APPLICATION
addappid(1434720)
-- Game: addappid(1434720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434721, 1, "ae5700ec52d5a4784ba94f2a40dad6394ee03282b1e44b7043239ea112ab05b9")
