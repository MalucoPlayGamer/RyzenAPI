-- Lua provided by RyzenAPI 
-- Game: No Way Out Demo
addappid(2128510)
addappid(2128511, 1, "8094d0c9dcc97fc609f9acfcf8f5999ab5eac9b581939055beee6636777dda87")
