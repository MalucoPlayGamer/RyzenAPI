-- Lua provided by RyzenAPI
-- Game: Game: Blood: One Unit Whole Blood

-- MAIN APPLICATION
addappid(299030)
-- Game: addappid(299030)

-- MAIN APP DEPOTS / PACKAGES
addappid(299031, 1, "c90bb79be73ff0999319d94d01d5d970ad938d35aa274ef9429742aae8ead09d")
