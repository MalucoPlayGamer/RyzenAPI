-- Lua provided by RyzenAPI
-- Game: SCP: Fragmented Minds Demo

-- MAIN APPLICATION
addappid(228988)
addappid(1216170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216172,0,"e24d19392584c20685fc5c93ed555d5b7bd0cffdec799f75525c6cc169a499a2")

