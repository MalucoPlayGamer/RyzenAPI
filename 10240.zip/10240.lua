-- Lua provided by SkyAPI 
-- Game: A Stroke of Fate: Operation Valkyrie
addappid(10240)
addappid(10241, 1, "51783e4142883d0d2b3c1b0f7c5e6c67f214411547a3026f22aa95e95de6e2a7")
