-- Lua provided by RyzenAPI
-- Game: addappid(10240)

-- MAIN APPLICATION
addappid(10240)

-- MAIN APP DEPOTS / PACKAGES
addappid(10241, 1, "51783e4142883d0d2b3c1b0f7c5e6c67f214411547a3026f22aa95e95de6e2a7")
