-- Lua provided by RyzenAPI
-- Game: Game: AppID 568450

-- MAIN APPLICATION
addappid(568450)
-- Game: addappid(568450)

-- MAIN APP DEPOTS / PACKAGES
addappid(568451, 1, "0df37c2f03c2483942d502ca05fb881656e94f0d0cd895c2c6b7cffb6f50740c")
