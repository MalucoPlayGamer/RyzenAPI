-- Lua provided by RyzenAPI
-- Game: NITRO GEN OMEGA - Original Soundtrack

-- MAIN APPLICATION
addappid(3783740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3783741, 1, "ae3ac3dd4af1b8e2e626f6b375b08ce62f6ff477567d6636b34124561d5032fb")
