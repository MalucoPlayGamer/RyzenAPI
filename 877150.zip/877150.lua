-- Lua provided by RyzenAPI
-- Game: Gravity Wars

-- MAIN APPLICATION
addappid(877150)
addappid(1013230)

-- MAIN APP DEPOTS / PACKAGES
addappid(877151, 1, "af604224e880ee52d3bb9c32ffb26d972fad8f99a81974aefc296478146d4393")
addappid(877152, 1, "fce918dd1470ac5126889f34dc0bd444c2921ad3bda9438b6c7ac56c39a88ec9")
addappid(877153, 1, "9ea9a7bf3baacf1735b9736a1878c8f65a85a563692162e3e4b70851ac3d9b85")

