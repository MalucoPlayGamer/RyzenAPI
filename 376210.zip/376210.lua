-- Lua provided by RyzenAPI
-- Game: addappid(376210)

-- MAIN APPLICATION
addappid(376210)

-- MAIN APP DEPOTS / PACKAGES
addappid(376212,0,"ec98ff5da26fe8ed2ed0776bff3cf9b786d8942eafcf581c04401c7cf8621b54")
