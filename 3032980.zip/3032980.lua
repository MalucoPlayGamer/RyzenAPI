-- Lua provided by RyzenAPI
-- Game: Anomalous Crossing ~Shibuya~

-- MAIN APPLICATION
addappid(3032980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032981, 1, "e835a5e368880a49d11a93d27619e3153029d9c7872f2a0c6792a4c4314a664c")

