-- Lua provided by RyzenAPI
-- Game: Don't Mess With Bober

-- MAIN APPLICATION
addappid(3177010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3177011, 1, "03cd8e4232184b34a0ca791cc89efe43c7ddd2109f0f71941cc76433b507a6b1")

