-- Lua provided by RyzenAPI
-- Game: Don't Mess With Bober

-- MAIN APPLICATION
addappid(3177010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3177011, 1, "03cd8e4232184b34a0ca791cc89efe43c7ddd2109f0f71941cc76433b507a6b1")

