-- Lua provided by RyzenAPI
-- Game: Scorn

-- MAIN APPLICATION
addappid(698670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(698671, 1, "4e1f1b866d2734e7bebea00a9226a1d1406620391d593824cde754a461253b17")
addappid(2023230, 0, "fa6115ec633bab9fcbd3d36a02f38cae3dc7d062710fa19626553964243f9bd9")

