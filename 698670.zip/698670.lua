-- Lua provided by RyzenAPI
-- Game: Scorn

-- MAIN APPLICATION
addappid(698670)
-- Game: addappid(698670)

-- MAIN APP DEPOTS / PACKAGES
addappid(698671, 1, "4e1f1b866d2734e7bebea00a9226a1d1406620391d593824cde754a461253b17")
addappid(2023230, 0, "fa6115ec633bab9fcbd3d36a02f38cae3dc7d062710fa19626553964243f9bd9")
