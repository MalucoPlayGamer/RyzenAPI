-- Lua provided by RyzenAPI
-- Game: AppID 977840

-- MAIN APPLICATION
addappid(977840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(977841, 1, "ecdb04f56ab02e2b69e41339c6a7f30417037a16c7958dbb452f5f3ca6cc3991")
addappid(977843, 1, "c23b6f0da346083dcff36dfb1af0e998cbe7b4506481a762e067f38095d498b6")

