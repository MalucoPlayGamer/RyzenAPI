-- Lua provided by RyzenAPI
-- Game: 977840

-- MAIN APPLICATION
addappid(977840)
-- Game: addappid(977840)

-- MAIN APP DEPOTS / PACKAGES
addappid(977841, 1, "ecdb04f56ab02e2b69e41339c6a7f30417037a16c7958dbb452f5f3ca6cc3991")
addappid(977843, 1, "c23b6f0da346083dcff36dfb1af0e998cbe7b4506481a762e067f38095d498b6")
