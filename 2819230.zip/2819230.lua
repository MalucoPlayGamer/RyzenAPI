-- Lua provided by RyzenAPI
-- Game: addappid(2819230)

-- MAIN APPLICATION
addappid(2819230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819231, 1, "58fe659403c2f09aff30d7ccf754a8a744ce8f542205be669f9ee4ed0d4da082")
