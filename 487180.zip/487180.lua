-- Lua provided by RyzenAPI
-- Game: AppID 487180

-- MAIN APPLICATION
addappid(487180)
addappid(508830)

-- MAIN APP DEPOTS / PACKAGES
addappid(487181, 1, "bdd0c07126ee5414be1bae4e6dd3820b9d59ca6e59181ebbb1904d40e9e29df6")
addappid(487182, 1, "599b845a960719c23d1840a00a1c98fba1b27f9ef1d4c97ba2f9f3ed8eb6c621")
