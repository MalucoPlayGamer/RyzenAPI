-- Lua provided by RyzenAPI
-- Game: Metal Garden

-- MAIN APPLICATION
addappid(3539440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3539441, 1, "44318a0fda95b82dadc858f0e0715e846e942852570d017260df14708f0d5104")

