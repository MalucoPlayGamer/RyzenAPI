-- Lua provided by RyzenAPI
-- Game: SCUM

-- MAIN APPLICATION
addappid(513710)

-- MAIN APP DEPOTS / PACKAGES
addappid(513711, 1, "a4217026617fd23bbc1b544c3160c7c7e5157bc3cfcd825b8dbd1c6d0513c3b4")
addappid(919680, 0, "903d006bb149ccbe1ab4f9dbbad34150079380811c9c78b3cfa5c1505ad889ae")
addappid(1643210, 0, "9e747e8f5cf60151ff0c48ce9eb2bb1977b88052fbb610f1a0ae88d28d001194")
addappid(3596770, 0, "ca8672e87bb66a5095fa0d3bd263d23d78ee88ee808938b6b0df4c0abbbb0cd2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1990860)
addappid(2321800)
addappid(2371620)
addappid(2517160)
addappid(2517170)
addappid(2651720)
addappid(2651740)
addappid(2651750)
addappid(2841840)
addappid(4062860)
addappid(4139450)
addappid(4369750)
addappid(4529160)
addappid(4635190)
addappid(4635200)
addappid(4635240)
addappid(4635250)
addappid(5006300)
