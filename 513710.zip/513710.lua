-- Lua provided by SkyAPI 
-- Game: SCUM
addappid(513710)
addappid(513711, 1, "a4217026617fd23bbc1b544c3160c7c7e5157bc3cfcd825b8dbd1c6d0513c3b4")
addappid(919680, 0, "903d006bb149ccbe1ab4f9dbbad34150079380811c9c78b3cfa5c1505ad889ae")
addappid(1643210, 0, "9e747e8f5cf60151ff0c48ce9eb2bb1977b88052fbb610f1a0ae88d28d001194")
addappid(3596770, 0, "ca8672e87bb66a5095fa0d3bd263d23d78ee88ee808938b6b0df4c0abbbb0cd2")
