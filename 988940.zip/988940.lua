-- Lua provided by RyzenAPI
-- Game: Dark Alley Elf

-- MAIN APPLICATION
addappid(988940)
-- Game: addappid(988940)

-- MAIN APP DEPOTS / PACKAGES
addappid(988941, 1, "747c4c8e95fcc89228473b6070dfd752b83bd6ef981897d1f316e759f47f7d64")
