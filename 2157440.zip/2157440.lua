-- Lua provided by RyzenAPI 
-- Game: Run Run Boy
addappid(2157440)
addappid(2157441, 1, "18a9dd0d1226610214eda9ade2c37761dc2142412cf148f42e41b332ce5c7c72")
