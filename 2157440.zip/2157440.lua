-- Lua provided by RyzenAPI
-- Game: addappid(2157440)

-- MAIN APPLICATION
addappid(2157440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157441, 1, "18a9dd0d1226610214eda9ade2c37761dc2142412cf148f42e41b332ce5c7c72")
