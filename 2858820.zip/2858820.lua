-- Lua provided by RyzenAPI
-- Game: Clean City Project

-- MAIN APPLICATION
addappid(2858820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858821,0,"b1627dfcbaeea777353a6c02f586f972e214cad4a886c719f58209c648584649")

