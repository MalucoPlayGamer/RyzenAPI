-- Lua provided by RyzenAPI
-- Game: Humpi and Hemicube

-- MAIN APPLICATION
addappid(2631380)
addappid(2768650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631381, 1, "dbdb77590cba3d17348742d3ceac4fd111ea73d9a576ccc21b208ce14f1b28b7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
