-- Lua provided by RyzenAPI
-- Game: 2631380

-- MAIN APPLICATION
addappid(2631380)
addappid(2768650)
-- Game: addappid(2631380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631381, 1, "dbdb77590cba3d17348742d3ceac4fd111ea73d9a576ccc21b208ce14f1b28b7")
