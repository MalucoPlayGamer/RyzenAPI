-- Lua provided by RyzenAPI
-- Game: Humpi and Hemicube

-- MAIN APPLICATION
addappid(2631380)
addappid(2768650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631381, 1, "dbdb77590cba3d17348742d3ceac4fd111ea73d9a576ccc21b208ce14f1b28b7")
