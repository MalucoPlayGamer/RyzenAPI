-- Lua provided by RyzenAPI
-- Game: Moo Moo Move

-- MAIN APPLICATION
addappid(987880)

-- MAIN APP DEPOTS / PACKAGES
addappid(987881, 1, "c2166588d606f02970b2e00c5861e9f6c1c9c6107bcf5b8ad8fb7930bc4c69e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
