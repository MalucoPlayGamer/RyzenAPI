-- Lua provided by RyzenAPI
-- Game: Moo Moo Move

-- MAIN APPLICATION
addappid(987880)

-- MAIN APP DEPOTS / PACKAGES
addappid(987881, 1, "c2166588d606f02970b2e00c5861e9f6c1c9c6107bcf5b8ad8fb7930bc4c69e5")

