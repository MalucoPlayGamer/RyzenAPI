-- Lua provided by RyzenAPI
-- Game: English - CrocApoca!! Crocodile maiden at the End of the World Demo

-- MAIN APPLICATION
addappid(1306170)
-- Game: addappid(1306170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306171, 1, "9bf24072c6b7d3b04b5cbcad7806d32d343f7d67a0c3e4574289b6825765d477")
