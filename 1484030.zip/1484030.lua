-- Lua provided by RyzenAPI 
-- Game: Raw Element
addappid(1484030)
addappid(1484031, 1, "f5c5a38d04746eef749c8da43411e0e9bdc384ca914c54ecc4cf224cd5d4ddaa")
