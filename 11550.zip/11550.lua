-- Lua provided by RyzenAPI
-- Game: 11550

-- MAIN APPLICATION
addappid(11550)
-- Game: addappid(11550)

-- MAIN APP DEPOTS / PACKAGES
addappid(11551, 1, "cfd4dfdb9aa688f87fc4c92629d381cf0fa5362fa36c0bc5c6fec05ebf9f698f")
