-- Lua provided by RyzenAPI
-- Game: Devil's Toy

-- MAIN APPLICATION
addappid(959540)

-- MAIN APP DEPOTS / PACKAGES
addappid(959541, 1, "0dcb15c8a3542312b7e78a46a74d2a4ab9aec63bf48a85888c0430f84882d4d3")
