-- Lua provided by RyzenAPI
-- Game: The Purge Man

-- MAIN APPLICATION
addappid(1063930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063931, 1, "df339f7c27240d27b85bc359db45835cfd9a9fdce91351219eb9a4a26a4a1324")
