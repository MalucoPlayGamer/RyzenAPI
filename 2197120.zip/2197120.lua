-- Lua provided by RyzenAPI
-- Game: Game: Withering Rooms Demo

-- MAIN APPLICATION
addappid(2197120)
-- Game: addappid(2197120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197121, 1, "3c418d274bb25185f4c677d45c6b5d00cb6cecb9fbd75bcc75f475278b83276d")
