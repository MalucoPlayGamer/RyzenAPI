-- Lua provided by RyzenAPI
-- Game: Idle Atomic

-- MAIN APPLICATION
addappid(1658620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658621, 1, "be3dee980ca3e6a8203a8ff22e5c78d7ecb55ecfde066a3a811c89df80a62569")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1659570)
addappid(1670140)
addappid(1670141)
addappid(1670142)
addappid(1684590)
addappid(1684591)
addappid(1684592)
addappid(1684960)
addappid(1684961)
