-- Lua provided by RyzenAPI
-- Game: Idle Atomic

-- MAIN APPLICATION
addappid(1658620)
-- Game: addappid(1658620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658621, 1, "be3dee980ca3e6a8203a8ff22e5c78d7ecb55ecfde066a3a811c89df80a62569")
