-- Lua provided by RyzenAPI
-- Game: Blast the Past

-- MAIN APPLICATION
addappid(943170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(943171, 1, "fed9ce1964f8d55fafa3a6cabdc0588cefe9c0fbfb787dfa16ca96130fa2b7ff")
