-- Lua provided by RyzenAPI
-- Game: AppID 943170

-- MAIN APPLICATION
addappid(943170)
-- Game: addappid(943170)

-- MAIN APP DEPOTS / PACKAGES
addappid(943171, 1, "fed9ce1964f8d55fafa3a6cabdc0588cefe9c0fbfb787dfa16ca96130fa2b7ff")
