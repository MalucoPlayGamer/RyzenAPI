-- Lua provided by RyzenAPI
-- Game: Lara Croft GO

-- MAIN APPLICATION
addappid(540840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(540841, 1, "4a195a2527afd1e8fd4486c21867ba9d9796bda372bc3aca5f0d7055ac7d6b66")
addappid(540842, 1, "89f3e7b920e89204093b6cc21169ad2a46d93b58c1f852fb6db3f44de82d60ff")
addappid(540843, 1, "b09c27773d90e037636e5e17310316d7f465fe7316d6aab3c05aee0d9de6d008")
addappid(540845, 1, "877151bd59de7ce401fa464f5f2677183532da4c9203a0735b088ed1040da5a6")

