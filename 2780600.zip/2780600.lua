-- Lua provided by RyzenAPI
-- Game: Game: Dark Investigation : Experiment

-- MAIN APPLICATION
addappid(2780600)
-- Game: addappid(2780600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780601, 1, "1a3bb45e38c9a2471473af91ed3dc6498885405c36dcbade4ba6b775bad7f42a")
