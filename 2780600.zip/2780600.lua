-- Lua provided by SkyAPI 
-- Game: Dark Investigation : Experiment
addappid(2780600)
addappid(2780601, 1, "1a3bb45e38c9a2471473af91ed3dc6498885405c36dcbade4ba6b775bad7f42a")
