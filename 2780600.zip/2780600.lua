-- Lua provided by RyzenAPI
-- Game: Dark Investigation : Experiment

-- MAIN APPLICATION
addappid(2780600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780601, 1, "1a3bb45e38c9a2471473af91ed3dc6498885405c36dcbade4ba6b775bad7f42a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
