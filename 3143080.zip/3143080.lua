-- Lua provided by RyzenAPI
-- Game: Mr. Hopp's Playhouse 2 HD

-- MAIN APPLICATION
addappid(3143080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143081,0,"23499aa85fb211af66948532a8207e153c367fccb6a5f886e2b076ad380d2ab8")

