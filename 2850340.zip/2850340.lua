-- Lua provided by RyzenAPI
-- Game: 2850340

-- MAIN APPLICATION
addappid(2850340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850340,0,"423f4ec9aa4edff9616f9a065bf6d4a7b3a50e7a5989eca2eba1fe2e8c232af2")

