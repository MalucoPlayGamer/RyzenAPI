-- Lua provided by RyzenAPI
-- Game: Necro Rumble

-- MAIN APPLICATION
addappid(2735950)
-- Game: addappid(2735950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735951, 1, "b26b3feac5136674294bbd7e499fc18278d5a3198cdbd6c960b8f83751331f01")
