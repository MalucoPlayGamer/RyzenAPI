-- Lua provided by RyzenAPI
-- Game: 幻恋夜宴: 恋恋的幻觉夜宴 ~ Halluci-Sabbat of Koishi Demo

-- MAIN APPLICATION
addappid(1722990)
-- Game: addappid(1722990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722991, 1, "90e806a06a49033fcd1d24c7fc725d44c3a52d1b568153122b643f8ad3921869")
