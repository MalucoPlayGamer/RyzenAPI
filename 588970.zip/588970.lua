-- Lua provided by RyzenAPI
-- Game: Oik

-- MAIN APPLICATION
addappid(588970)

-- MAIN APP DEPOTS / PACKAGES
addappid(588971, 1, "77262a5d550c1ab5903310b7b84408c589bfeba8b54ca31073981ffd01e1ba04")

