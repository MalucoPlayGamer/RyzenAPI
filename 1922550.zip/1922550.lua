-- Lua provided by RyzenAPI
-- Game: Psychosis

-- MAIN APPLICATION
addappid(1922550)
-- Game: addappid(1922550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922551, 1, "b3d56f70afa9512097c567e3159661c8034a19c316f672c3dda313acdc64ef28")
addappid(1922552, 1, "087118a1d8f23e366e3b942bd64bf0b5898114e5df3061be1e639973737b4c77")
