-- Lua provided by RyzenAPI
-- Game: Psychosis

-- MAIN APPLICATION
addappid(1922550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1922551, 1, "b3d56f70afa9512097c567e3159661c8034a19c316f672c3dda313acdc64ef28")
addappid(1922552, 1, "087118a1d8f23e366e3b942bd64bf0b5898114e5df3061be1e639973737b4c77")

