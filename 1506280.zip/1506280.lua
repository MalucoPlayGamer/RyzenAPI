-- Lua provided by SkyAPI 
-- Game: Erophone
addappid(1506280)
addappid(1506281, 1, "68ea5ca95dee740307df15b7f1848adb3be96d4391021e9e30d094ad53b4ca9b")
addappid(1594550, 0, "8fa3a6fcbca0601d848bdb5e859fd10b8795d6bdb87dff46bd8e18fa7b78e071")
