-- Lua provided by RyzenAPI
-- Game: addappid(2266190)

-- MAIN APPLICATION
addappid(2266190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266191, 1, "46ba7f5076739c2a02e8edce039fd9749ebcebd5ae63f5e8ed52aafd970dadec")
