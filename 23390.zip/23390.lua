-- Lua provided by RyzenAPI
-- Game: 23390

-- MAIN APPLICATION
addappid(23390)
-- Game: addappid(23390)

-- MAIN APP DEPOTS / PACKAGES
addappid(23391, 1, "69bf246191f67e5c2cf6c0b525f2c537b56dcb6860af118eaf00b2bc12fc6f5d")
