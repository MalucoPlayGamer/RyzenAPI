-- Lua provided by SkyAPI 
-- Game: AppID 23390
addappid(23390)
addappid(23391, 1, "69bf246191f67e5c2cf6c0b525f2c537b56dcb6860af118eaf00b2bc12fc6f5d")
