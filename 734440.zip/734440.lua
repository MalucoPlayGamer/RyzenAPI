-- Lua provided by RyzenAPI
-- Game: 734440

-- MAIN APPLICATION
addappid(734440)
-- Game: addappid(734440)

-- MAIN APP DEPOTS / PACKAGES
addappid(734441, 1, "ee38dcd02a4a25294c9ea66408832d858dc2bb77210b981f05be8c82e6b9fca8")
