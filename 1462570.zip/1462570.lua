-- Lua provided by RyzenAPI
-- Game: Game: Lost in Random™

-- MAIN APPLICATION
addappid(1462570)
-- Game: addappid(1462570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462571, 1, "d42eb343714c848a585b32e1d16f1fec8406b8596a0d50c66bd49bbcc7089c35")
addappid(1462572, 1, "e94a618db2c3fc1ac5278e81ebaba1620fb59f1e6ebaea3ca7c49267894de48c")
addappid(1462573, 1, "0b7eb88b534fbf9b44b05194a14925460c1fd51d96a59f55efe21404c362cc65")
addappid(1462574, 1, "04e21c8539faf5a8fda6f9c6c8bf270100ed2bdda1f86c89347426363ebed32d")
addappid(1462575, 1, "f01edcc130d4598a8777447ff940edaf1dc0500eb9953796b763cb945c4202c9")
addappid(1462576, 1, "21f5d99b180542e3ff06f618de2bf9b2870322c183049fd406cf0a333a5db164")
addappid(1462577, 1, "4daf71b2bc3a0520e515deb9acfc9933a6c5ddbe9f7a808a362b2eadb57653ac")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")
