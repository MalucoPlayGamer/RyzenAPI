-- Lua provided by RyzenAPI
-- Game: Game: AppID 1272080

-- MAIN APPLICATION
addappid(1272080)
-- Game: addappid(1272080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272081, 1, "3e032aede34266458c52fd8d6bd33c4505bc1742e2cdbba706fe9746a83059fa")
