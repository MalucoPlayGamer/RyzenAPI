-- Lua provided by RyzenAPI
-- Game: AppID 1272080

-- MAIN APPLICATION
addappid(1272080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272081, 1, "3e032aede34266458c52fd8d6bd33c4505bc1742e2cdbba706fe9746a83059fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2438800)
addappid(2442890)
addappid(2449350)
addappid(2449351)
addappid(2450690)
addappid(2450691)
addappid(2450692)
addappid(2450693)
addappid(2450694)
addappid(2450695)
addappid(2450696)
addappid(2450697)
addappid(2450711)
addappid(2713010)
addappid(3055010)
addappid(3110530)
addappid(3111880)
addappid(3128380)
addappid(3128390)
addappid(3128400)
addappid(3128410)
addappid(3128420)
addappid(3171970)
addappid(3171980)
addappid(3171990)
addappid(3172010)
addappid(3214920)
addappid(3450550)
addappid(3679630)
addappid(3858460)
addappid(4129170)
addappid(4533420)
addappid(4640190)
