-- 4529660's Lua and Manifest Created by Hubcap Manifest
-- Greedy Spin: Reel Roguelike
-- Created: July 30, 2026 at 14:10:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4529660) -- Greedy Spin: Reel Roguelike
-- MAIN APP DEPOTS
addappid(4529661, 1, "3466550b1014a81e39016136689d8a57a40b708719d38d5328eb6974d96c7684") -- Depot 4529661
setManifestid(4529661, "7221669815615919490", 222427448)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4529662) -- Depot 4529662 (empty depot)