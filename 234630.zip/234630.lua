-- Lua provided by RyzenAPI
-- Game: Game: Project CARS

-- MAIN APPLICATION
addappid(234630)
-- Game: addappid(234630)

-- MAIN APP DEPOTS / PACKAGES
addappid(234631, 1, "ce6e2b12011b5741335811ed81d7e3b02a8e9518073cc3645373e63a26cf4971")
