-- Lua provided by RyzenAPI
-- Game: Project CARS

-- MAIN APPLICATION
addappid(234630)
addappid(334770)
addappid(334771)
addappid(334772)
addappid(334773)
addappid(334774)
addappid(334780)
addappid(334781)
addappid(334782)
addappid(334790)
addappid(334791)
addappid(334792)
addappid(334793)
addappid(372900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(234631, 1, "ce6e2b12011b5741335811ed81d7e3b02a8e9518073cc3645373e63a26cf4971")

