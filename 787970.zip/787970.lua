-- Lua provided by RyzenAPI
-- Game: 787970

-- MAIN APPLICATION
addappid(787970)
-- Game: addappid(787970)

-- MAIN APP DEPOTS / PACKAGES
addappid(787977,0,"724932ee03acd283cdb0914df322ffdceb3f426a18c2a32fe71469cb3fd3ff13")
