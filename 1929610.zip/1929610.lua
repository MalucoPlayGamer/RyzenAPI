-- Lua provided by RyzenAPI
-- Game: 1929610

-- MAIN APPLICATION
addappid(1929610)
-- Game: addappid(1929610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929611, 1, "17c7cca3b4b0c06f525fe2745e8d2ff64f80b66ca39321e251d0a89c66dd6164")
