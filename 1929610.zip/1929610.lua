-- Lua provided by RyzenAPI
-- Game: Demonologist

-- MAIN APPLICATION
addappid(1929610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1929611, 1, "17c7cca3b4b0c06f525fe2745e8d2ff64f80b66ca39321e251d0a89c66dd6164")

