-- Lua provided by RyzenAPI
-- Game: Old World Demo

-- MAIN APPLICATION
addappid(2117470)
-- Game: addappid(2117470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117471, 1, "17dfb861a901398d0e45d4166b47de1b8b167145b4d3ac1a4d46fc464b01ce1c")
