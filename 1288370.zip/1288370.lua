-- Lua provided by RyzenAPI
-- Game: Game: Desert attack

-- MAIN APPLICATION
addappid(1288370)
-- Game: addappid(1288370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288371, 1, "13ef1357b611be08d9e1f055b0561a6d21bd36f153a01a5d5c04d1dba6f8d1ee")
