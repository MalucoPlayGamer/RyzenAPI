-- Lua provided by RyzenAPI
-- Game: Wand Wars

-- MAIN APPLICATION
addappid(422110)

-- MAIN APP DEPOTS / PACKAGES
addappid(422111, 1, "b60ffee1ea55f6c6bbf15d9025bac581b0a48ed8e4f77fdefa187d16a3671984")
addappid(574400, 0, "97bb63343332f06ebc59d139df48d2acb2bf5509a54f55e3354268fe36740730")
