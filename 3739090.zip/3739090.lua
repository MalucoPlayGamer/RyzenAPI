-- Lua provided by RyzenAPI
-- Game: Reversi

-- MAIN APPLICATION
addappid(3739090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3739093,0,"e6049694f5714efca6f771c38c8e074da283eaea358e3a3d04f077ec7e813627")
