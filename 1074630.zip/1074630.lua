-- Lua provided by RyzenAPI
-- Game: addappid(1074630)

-- MAIN APPLICATION
addappid(1074630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074631, 1, "a7c690551bebb6d3e5837ea479e3baca647dd23bc04eb068eb2d6e48b43442a1")
