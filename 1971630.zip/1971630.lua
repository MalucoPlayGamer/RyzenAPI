-- Lua provided by RyzenAPI
-- Game: addappid(1971630)

-- MAIN APPLICATION
addappid(1971630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971632,0,"ead6efd9c39a22724b78b9dcfda5d468319a387a1c09ee7110223d9b2387c1d4")
