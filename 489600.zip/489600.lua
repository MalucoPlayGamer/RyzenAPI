-- Lua provided by RyzenAPI
-- Game: Game: AppID 489600

-- MAIN APPLICATION
addappid(489600)
-- Game: addappid(489600)

-- MAIN APP DEPOTS / PACKAGES
addappid(489601, 1, "aa5c80736409abe09bd942f8648a969222567804ff1631f2937189daf783c020")
