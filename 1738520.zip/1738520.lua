-- Lua provided by RyzenAPI
-- Game: Game: Bikini Armour Explorers

-- MAIN APPLICATION
addappid(1738520)
-- Game: addappid(1738520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738521, 1, "44cd14cd20a6b69408965f70e5a214ebdd8708e8c2d13409bcb572ae54443609")
addappid(1738522, 1, "24da35e14065c0fbd2071ac16600f005f7dd610709162c2b0acabe87e48c0f81")
addappid(1738523, 1, "be287bd56761670227e6d671550d9679297c282528d0771b2948beebba2e19fc")
