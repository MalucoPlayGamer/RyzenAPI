-- Lua provided by RyzenAPI
-- Game: AppID 451020

-- MAIN APPLICATION
addappid(451020)

-- MAIN APP DEPOTS / PACKAGES
addappid(451021, 1, "711266748319bcc04361997b2fce047f6476e75e9016452ef08604b818b9d94e")
addappid(451022, 1, "dd40503960997bcd261f48990d1b946bf6d91fecf526dac44120c6e6d0eed712")
addappid(451023, 1, "ac2a6d33baaf55766a3f02e879b1f249d3d0c3d3044dc6c1b89d3a0ce0cc0292")
addappid(712630, 0, "8b882a343771d06b0fad6ac33ecc498d2bf8146109f7f102c7c394a16e8f9a38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
