-- Lua provided by RyzenAPI
-- Game: Game: Tales of Seikyu Soundtrack

-- MAIN APPLICATION
addappid(3718710)
-- Game: addappid(3718710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3718711, 1, "643d4fa6138100176d7d2f04838986948ed1431a0f41de554c167616c0662b39")
addappid(3718712, 1, "67b0e842999edab58ef701b1775fef9a133f0b15329aa417b50a7f6c8cc90770")
