-- Lua provided by RyzenAPI
-- Game: 2906450

-- MAIN APPLICATION
addappid(2906450)
-- Game: addappid(2906450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906451, 1, "c14e2c839721fce1f9b858885c9a64f7af95d67a7704e0dff43f5294a2e10607")
