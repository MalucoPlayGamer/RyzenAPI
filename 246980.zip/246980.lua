-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228990)
addappid(229000)
addappid(246980)
addappid(246981)
addappid(278720)
-- Game: addappid(246980)

-- MAIN APP DEPOTS / PACKAGES
addappid(246982,0,"5b295610f8b682ce5c0c52b5662caea5e93fb43a065d7f28a4b9e43a03131303")
