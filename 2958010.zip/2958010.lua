-- Lua provided by RyzenAPI
-- Game: Game: Sex Change Contract and Molester Girl Demo

-- MAIN APPLICATION
addappid(2958010)
-- Game: addappid(2958010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958011, 1, "3939d2ead56aea1e17f54f5cd01d0fc5ee99ad25baa35b24a68886a41152890a")
