-- Lua provided by RyzenAPI
-- Game: Eat'n Eaten Demo

-- MAIN APPLICATION
addappid(1537840)
-- Game: addappid(1537840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537841, 1, "1eeaded93864329559b31b452c2d9f3296c7797b7e8289aa2b5b05c046e77636")
