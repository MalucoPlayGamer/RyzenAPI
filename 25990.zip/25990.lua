-- Lua provided by RyzenAPI
-- Game: Majesty: Gold Edition

-- MAIN APPLICATION
addappid(25990)

-- MAIN APP DEPOTS / PACKAGES
addappid(25991, 1, "6cce4003e8dd51faaeaf5a8a5f78e4b4ae7c6806128292afac9c4ad29e98ecc6")

