-- Lua provided by RyzenAPI
-- Game: Tide Girl: Phenomena

-- MAIN APPLICATION
addappid(2287790)
-- Game: addappid(2287790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287791, 1, "1114894d09ea35017d060cb0829b8a7891e2b94499e351edc30d4f07d84b1ed2")
