-- Lua provided by RyzenAPI
-- Game: AppID 1325510

-- MAIN APPLICATION
addappid(1325510)
-- Game: addappid(1325510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325511, 1, "75fc186e6941dac7e799a8cb680fe266fdcf34057768eb7141c88cd6410e721e")
