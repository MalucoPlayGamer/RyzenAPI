-- Lua provided by RyzenAPI
-- Game: Game: Insecticide Part 1

-- MAIN APPLICATION
addappid(16710)
-- Game: addappid(16710)

-- MAIN APP DEPOTS / PACKAGES
addappid(16711, 1, "b314754eefb675e535ba41b448d67cba30eb63a4865a969020e17ce0235b2786")
