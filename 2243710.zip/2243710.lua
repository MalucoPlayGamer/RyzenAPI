-- Lua provided by RyzenAPI
-- Game: Rune Factory 3 Special

-- MAIN APPLICATION
addappid(2243710)
addappid(2244790)
addappid(2244791)
addappid(2244792)
addappid(2244793)
addappid(2244794)
addappid(2244795)
addappid(2244796)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(2243711, 1, "48f545cab498f15092d267bd07ac909c46982c2730c2e878123db87dacbcd69c")
addappid(2243712, 1, "898a15a42166018df5759186a084b737c6ec379b994cd3a454f9cbc0cae6ac5c")

