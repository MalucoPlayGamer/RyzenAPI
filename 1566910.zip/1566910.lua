-- Lua provided by RyzenAPI 
-- Game: Riddle Girl
addappid(1566910)
addappid(1566911, 1, "b476ebf28b25fa461b3235f6e53aa263e82e705b7a25d9c4fb15386d980b2800")
addappid(1664500, 0, "806791dafec54a16fcd2559d9f1f339306430ea527a4964fb99e2600b90bf8b7")
