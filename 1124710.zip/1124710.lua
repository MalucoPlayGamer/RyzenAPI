-- Lua provided by RyzenAPI
-- Game: IS -Infinite Stratos- Versus Colors

-- MAIN APPLICATION
addappid(1124710)
addappid(1124711)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124712,0,"025b32483d0001dc236e2ce7addf455210112cfd2d971124d01f1c1078f8b3a4")

