-- Lua provided by SkyAPI 
-- Game: AppID 653060
addappid(653060)
addappid(653061, 1, "8e54ddf08593903724a043d6ee647ce0ca2a908f1fdfc969aa943260dcae0e66")
