-- Lua provided by RyzenAPI
-- Game: The Siege and the Sandfox

-- MAIN APPLICATION
addappid(653060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(653061, 1, "8e54ddf08593903724a043d6ee647ce0ca2a908f1fdfc969aa943260dcae0e66")
