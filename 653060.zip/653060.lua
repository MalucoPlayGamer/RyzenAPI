-- Lua provided by RyzenAPI
-- Game: Game: AppID 653060

-- MAIN APPLICATION
addappid(653060)
-- Game: addappid(653060)

-- MAIN APP DEPOTS / PACKAGES
addappid(653061, 1, "8e54ddf08593903724a043d6ee647ce0ca2a908f1fdfc969aa943260dcae0e66")
