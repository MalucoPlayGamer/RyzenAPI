-- Lua provided by RyzenAPI
-- Game: AppID 1015130

-- MAIN APPLICATION
addappid(1015130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015131, 1, "bbba32a0b178ad266b9159b08b5b5aab107e9b813baaf1eeeb3c1dcd7d3310cf")

