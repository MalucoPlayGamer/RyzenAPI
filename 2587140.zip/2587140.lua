-- Lua provided by RyzenAPI
-- Game: Empires Shall Fall Soundtrack

-- MAIN APPLICATION
addappid(2587140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587141, 1, "a237722c2585c7afe1798edcfb4e6e80ce71eab47d92501bd473a849a9fee841")
