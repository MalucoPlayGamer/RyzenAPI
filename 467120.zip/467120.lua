-- Lua provided by RyzenAPI
-- Game: Game: Rising Runner

-- MAIN APPLICATION
addappid(467120)
-- Game: addappid(467120)

-- MAIN APP DEPOTS / PACKAGES
addappid(467121, 1, "bdbed2b0a2226f18cf2b2f2b24ca22b3b98460f44d681495196596f2fc4d47ee")
