-- Lua provided by RyzenAPI
-- Game: addappid(2261490)

-- MAIN APPLICATION
addappid(2261490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261491, 1, "11d792a53caa7a0c0d4693c19dfbf85fda401624cb285c5c292538e0e2d4c0e8")
