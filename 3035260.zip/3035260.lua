-- Lua provided by RyzenAPI
-- Game: Gori: Cuddly Carnage - Artbook

-- MAIN APPLICATION
addappid(3035260)
-- Game: addappid(3035260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035260,0,"e5f1f497ca718762593ec5092ac3a3dcc8ac122642c12d9a10dd7c0809f1b553")
