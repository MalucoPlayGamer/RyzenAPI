-- Lua provided by RyzenAPI
-- Game: Stream Toys by Zokya

-- MAIN APPLICATION
addappid(1535420)
-- Game: addappid(1535420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535421, 1, "46e3eca00a4ede5a8a6d73d0c155772da04d720ea47b3724b7257a3827cc8be5")
addappid(1535422, 1, "28c0cec3514454c822ed3cb099fd58dd4e159cdaedf93638093be9ca3f8d313f")
addappid(1535423, 1, "4ec4856ef0162f4710369231a93d564ed5a65c70061acbb6d0b885ae158c5871")
