-- Lua provided by RyzenAPI
-- Game: Arcana Heart 3 LOVEMAX SIXSTARS!!!!!! XTEND

-- MAIN APPLICATION
addappid(661990)
addappid(1209800)
addappid(1209801)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(661991, 1, "2fa8d9e49a989e184582c9b52cce5c76d14e229a23cc28c4187a434a51a6e6bf")
