-- Lua provided by RyzenAPI
-- Game: Game: AppID 661990

-- MAIN APPLICATION
addappid(661990)
-- Game: addappid(661990)

-- MAIN APP DEPOTS / PACKAGES
addappid(661991, 1, "2fa8d9e49a989e184582c9b52cce5c76d14e229a23cc28c4187a434a51a6e6bf")
