-- 3453070's Lua and Manifest Created by Hubcap Manifest
-- COTTOn RockWithYou -ORIENTAL NIGHT DREAMS-
-- Created: August 06, 2026 at 04:40:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3453070) -- COTTOn RockWithYou -ORIENTAL NIGHT DREAMS-
-- MAIN APP DEPOTS
addappid(3453071, 1, "7b7f0a68c1fc977bf0c4cf3846cf07af0b7ed0ce95e457b3e85553f9e6fc68d6") -- Depot 3453071
setManifestid(3453071, "4813241456506735839", 5689053339)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)