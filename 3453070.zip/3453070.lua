-- Lua provided by RyzenAPI
-- Game: COTTOn RockWithYou -ORIENTAL NIGHT DREAMS-

-- MAIN APPLICATION
addappid(3453070) -- COTTOn RockWithYou -ORIENTAL NIGHT DREAMS-

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(3453071, 1, "7b7f0a68c1fc977bf0c4cf3846cf07af0b7ed0ce95e457b3e85553f9e6fc68d6") -- Depot 3453071

