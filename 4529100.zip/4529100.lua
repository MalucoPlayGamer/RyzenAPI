-- 4529100's Lua and Manifest Created by Hubcap Manifest
-- Idle DeepMiner
-- Created: July 06, 2026 at 11:44:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4529100) -- Idle DeepMiner
-- MAIN APP DEPOTS
addappid(4529101, 1, "fecdb2f0f45a9260c0c31ec0cc3522186c684665c03a58982cda489ecbd74ef6") -- Depot 4529101
-- setManifestid(4529101, "192942867495109594", 406425862)