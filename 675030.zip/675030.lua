-- Lua provided by RyzenAPI
-- Game: addappid(675030)

-- MAIN APPLICATION
addappid(675030)

-- MAIN APP DEPOTS / PACKAGES
addappid(675031, 1, "5089dbf6789527e3a7a59b665af4169451d98302a2b4aba31b07c477eb3dda79")
