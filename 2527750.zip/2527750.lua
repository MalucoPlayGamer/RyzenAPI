-- Lua provided by RyzenAPI
-- Game: Game: Lost Oath

-- MAIN APPLICATION
addappid(2527750)
-- Game: addappid(2527750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527751, 1, "d38911f632dc4b45a4126fb59be4582831d358638bc90f78743b65122f3a871a")
