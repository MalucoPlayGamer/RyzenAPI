-- Lua provided by RyzenAPI 
-- Game: Drone Crash Course
addappid(1793910)
addappid(1793911, 1, "f206b7e93abcbc035026c428c7720e29aa7d54423dcf5194059f4efb68752b24")
