-- Lua provided by RyzenAPI
-- Game: Space Guardian

-- MAIN APPLICATION
addappid(2382210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382211, 1, "7b7cc329b5ad311eccde4ebc967f95fbbb32c02ab12879fb3919a029a2ec4767")

