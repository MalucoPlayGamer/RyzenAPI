-- Lua provided by RyzenAPI
-- Game: Once Alive

-- MAIN APPLICATION
addappid(2336440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336441, 1, "3d9946d5c299e0c30d0c34faa3514620d80a1688ae74e2f0618700e2aa9fa5df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
