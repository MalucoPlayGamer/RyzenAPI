-- Lua provided by RyzenAPI
-- Game: Once Alive

-- MAIN APPLICATION
addappid(2336440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336441, 1, "3d9946d5c299e0c30d0c34faa3514620d80a1688ae74e2f0618700e2aa9fa5df")
