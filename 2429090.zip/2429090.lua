-- Lua provided by RyzenAPI
-- Game: Garden Buddies

-- MAIN APPLICATION
addappid(2429090)
-- Game: addappid(2429090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429091, 1, "8b7df642bcd3fd54e96a583749bf69a6992eb46e089c9e92c1085a8e072fd2b6")
