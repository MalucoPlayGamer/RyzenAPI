-- Lua provided by RyzenAPI
-- Game: 27920

-- MAIN APPLICATION
addappid(27920)
-- Game: addappid(27920)

-- MAIN APP DEPOTS / PACKAGES
addappid(27921, 1, "6adaac978f87b820e749fa9c14cf9df794fac83b20d22c08eae220369a8f0d7e")
