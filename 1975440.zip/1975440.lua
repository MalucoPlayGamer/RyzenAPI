-- Lua provided by RyzenAPI
-- Game: 1975440

-- MAIN APPLICATION
addappid(1975440)
-- Game: addappid(1975440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975441, 1, "a5841fd8a2ef1290667c7e49fec8d2d795f65642368ad9a52e5836ed13c2bd28")
