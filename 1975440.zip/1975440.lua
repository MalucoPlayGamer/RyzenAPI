-- Lua provided by RyzenAPI
-- Game: AppID 1975440

-- MAIN APPLICATION
addappid(1975440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975441, 1, "a5841fd8a2ef1290667c7e49fec8d2d795f65642368ad9a52e5836ed13c2bd28")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
