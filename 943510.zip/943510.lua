-- Lua provided by RyzenAPI 
-- Game: AppID 943510
addappid(943510)
addappid(943511, 1, "82e4c9296cf5fc4e85fd4b7d3e0116a5cfc9f58e663cdc9e608c67d1aa9ef263")
