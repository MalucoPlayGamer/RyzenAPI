-- Lua provided by RyzenAPI
-- Game: 1833040

-- MAIN APPLICATION
addappid(1833040)
-- Game: addappid(1833040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833041, 1, "27d3df5f02f3abf43d4510bd9996aa658ea459d8eb02d0eadae9fe9f470419ff")
