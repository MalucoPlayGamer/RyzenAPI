-- Lua provided by RyzenAPI
-- Game: ISO

-- MAIN APPLICATION
addappid(2202510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202511, 1, "17820ac8acafeb4903058cffacba2a9530efafa09c79cfa27674e16f61d8f3ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
