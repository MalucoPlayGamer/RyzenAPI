-- Lua provided by RyzenAPI
-- Game: ISO

-- MAIN APPLICATION
addappid(2202510)
-- Game: addappid(2202510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202511, 1, "17820ac8acafeb4903058cffacba2a9530efafa09c79cfa27674e16f61d8f3ac")
