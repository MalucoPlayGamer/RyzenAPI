-- Lua provided by RyzenAPI
-- Game: Reignman

-- MAIN APPLICATION
addappid(832380)

-- MAIN APP DEPOTS / PACKAGES
addappid(832381,0,"2ab86aab3369f085f6796527629c6b9d5fd573cdb3700d851fa418d8da8159d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
