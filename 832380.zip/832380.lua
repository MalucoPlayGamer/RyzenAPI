-- Lua provided by RyzenAPI
-- Game: Reignman

-- MAIN APPLICATION
addappid(832380)

-- MAIN APP DEPOTS / PACKAGES
addappid(832381,0,"2ab86aab3369f085f6796527629c6b9d5fd573cdb3700d851fa418d8da8159d5")

