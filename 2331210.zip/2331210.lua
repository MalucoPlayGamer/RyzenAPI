-- Lua provided by RyzenAPI
-- Game: Quit Smoking VR Therapist

-- MAIN APPLICATION
addappid(2331210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331211, 1, "72b1b347aa1e51ed84f5fc572bb32566297d085e0d6e18cd7c11acd9f8c32e5b")
