-- Lua provided by RyzenAPI
-- Game: Quit Smoking VR Therapist

-- MAIN APPLICATION
addappid(2331210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2331211, 1, "72b1b347aa1e51ed84f5fc572bb32566297d085e0d6e18cd7c11acd9f8c32e5b")

