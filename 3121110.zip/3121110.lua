-- Lua provided by RyzenAPI
-- Game: Game: Zort

-- MAIN APPLICATION
addappid(3121110)
-- Game: addappid(3121110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3121111, 1, "806aeaed5d4ad4428cd6c1eba28ff88c387605abe45508700508db278de71391")
