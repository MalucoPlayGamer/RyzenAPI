-- Lua provided by RyzenAPI
-- Game: 1824440

-- MAIN APPLICATION
addappid(1824440)
-- Game: addappid(1824440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824441, 1, "2f9002358d2d389ccb1ec1ce507d4e96972f70746659534a8b1399aaaa294af6")
