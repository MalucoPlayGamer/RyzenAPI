-- Lua provided by RyzenAPI
-- Game: Through Abandoned: The Forest

-- MAIN APPLICATION
addappid(513340)
addappid(518080)
addappid(518081)

-- MAIN APP DEPOTS / PACKAGES
addappid(513344,0,"89a2a7e18f1cfc42d49dabfddb71a25ccf756b68f75185353885a095c3f339aa")
