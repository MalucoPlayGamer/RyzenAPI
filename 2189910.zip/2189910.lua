-- Lua provided by RyzenAPI
-- Game: Mystic Forest

-- MAIN APPLICATION
addappid(2189910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2189911, 1, "bdffc82c59767283f8c7342f641313cee7384cf69f3c9a608fc4c7fc55531984")

