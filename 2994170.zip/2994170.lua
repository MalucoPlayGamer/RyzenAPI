-- Lua provided by RyzenAPI
-- Game: Undusted: Letters from the Past Demo

-- MAIN APPLICATION
addappid(2994170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994171, 1, "87fd96ddc75298549ae69c5e0c16e71c958a3f6fd09696b5887e6d8e64c65606")
