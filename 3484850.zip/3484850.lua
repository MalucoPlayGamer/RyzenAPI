-- 3484850's Lua and Manifest Created by Hubcap Manifest
-- Scam Center Simulator: UnderKingdom
-- Created: August 02, 2026 at 15:38:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3484850, 1, "f74b0087c302de52d0633b201e82664acc68565bb45a7e2d5ace6fc53a5c5d43") -- Scam Center Simulator: UnderKingdom
-- MAIN APP DEPOTS
addappid(3484851, 1, "d3f006a17610929854d256761a03e2ed2f17d6b0cd5f555cc91d7c8e0a07d095") -- Depot 3484851
setManifestid(3484851, "218955040846859412", 7002201810)