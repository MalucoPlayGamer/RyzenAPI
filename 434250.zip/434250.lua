-- Lua provided by RyzenAPI
-- Game: Masked Shooters 2

-- MAIN APPLICATION
addappid(434250)
addappid(909050)

-- MAIN APP DEPOTS / PACKAGES
addappid(434251, 1, "56a81d95bbde0edab27f1cb833876eb72fd833886da3521b13fe8b3086509abf")
