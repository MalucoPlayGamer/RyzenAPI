-- Lua provided by RyzenAPI
-- Game: Loco Dojo

-- MAIN APPLICATION
addappid(667800)
-- Game: addappid(667800)

-- MAIN APP DEPOTS / PACKAGES
addappid(667801, 1, "6e9102b976c9bc689155f12a6c8fec4d0e39b8828b8f501eb7dd03c8510bb75d")
