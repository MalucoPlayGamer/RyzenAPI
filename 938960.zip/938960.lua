-- Lua provided by RyzenAPI
-- Game: Soul-Ivy: C0

-- MAIN APPLICATION
addappid(938960)

-- MAIN APP DEPOTS / PACKAGES
addappid(938961, 1, "f9576eebd199d816e23fe43894ed65a283b8090d7d669e3053d6d9cf0477ca5e")
