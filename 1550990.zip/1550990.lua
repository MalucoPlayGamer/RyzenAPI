-- Lua provided by SkyAPI 
-- Game: Jurassic Attack
addappid(1550990)
addappid(1550991, 1, "ae2d6d004f3337dde06dc477627140775ac2230ed4403201354f71aa622a2011")
