-- Lua provided by RyzenAPI
-- Game: Jurassic Attack

-- MAIN APPLICATION
addappid(1550990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550991, 1, "ae2d6d004f3337dde06dc477627140775ac2230ed4403201354f71aa622a2011")

