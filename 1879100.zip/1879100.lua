-- Lua provided by RyzenAPI
-- Game: 1879100

-- MAIN APPLICATION
addappid(1879100)
-- Game: addappid(1879100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879101, 1, "3eaff452c16f3b9fa2fe4eafa62d1a62f4f59fd858508fbb1ce15f96d4044cb4")
