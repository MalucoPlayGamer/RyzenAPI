-- Lua provided by RyzenAPI
-- Game: Project Skylab

-- MAIN APPLICATION
addappid(907160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(907161, 1, "da9de771229739621462499d16d2254976644fd4aaf74cda12c81bb452faf5ca")
addappid(907162, 1, "e8c4bbf87177d81a87fbf506afab9b996f430986dbe770f400a79da7b500c447")
addappid(907163, 1, "8f54dd8768c6ff7b0bbe8b5ea30b114df2ef86dafa63d34b9831f7452abb492d")

