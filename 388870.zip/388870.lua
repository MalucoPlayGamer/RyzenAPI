-- Lua provided by RyzenAPI
-- Game: 388870

-- MAIN APPLICATION
addappid(388870)
addappid(491980)
-- Game: addappid(388870)

-- MAIN APP DEPOTS / PACKAGES
addappid(388871, 1, "58b1c1ac9176d5fcd655a3b9c9023501e4c1cda22a95348d5435de30c9d9d073")
