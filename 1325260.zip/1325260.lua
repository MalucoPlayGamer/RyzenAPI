-- Lua provided by RyzenAPI
-- Game: Kitsune Tails

-- MAIN APPLICATION
addappid(1325260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1325261, 1, "021be79561b9d0e1a45d3435aef31268abf0d0199446f1e86f13f292dbaca4a7")

