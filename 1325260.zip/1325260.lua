-- Lua provided by RyzenAPI
-- Game: Kitsune Tails

-- MAIN APPLICATION
addappid(1325260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325261, 1, "021be79561b9d0e1a45d3435aef31268abf0d0199446f1e86f13f292dbaca4a7")

