-- Lua provided by RyzenAPI
-- Game: The LEGO® Movie 2 - Videogame

-- MAIN APPLICATION
addappid(881320)

-- MAIN APP DEPOTS / PACKAGES
addappid(881321,0,"37b9556ad369ea4f08041b38b39d121d0aca1c3b80ebe517c07416cd87e1fffa")
addappid(881322,0,"790f5eaaf4304bc91e228b19ea8387989a6073238db59f7c1917f49da40a8201")
addappid(881323,0,"f78f0d46269a368b90f3090d4631387a79d14e0f9f13027314c23a490ff8dd22")
addappid(881325,0,"db5fa7a3289fd9e1e1b634c3a943c7c8ca3d9e34925de93773925ea385bf83cd")
addappid(976220,0,"c7cd2a41a7438a00ce0bea7f28d864cb94dce8a9879d0d544ad8ac6d74f2585b")
addappid(1045890,0,"0fe04dc63187d349b4f69714dcc5bdd302c01cccd62443b4539c8a2c05e4a77e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
