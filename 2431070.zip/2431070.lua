-- Lua provided by RyzenAPI
-- Game: 98xx

-- MAIN APPLICATION
addappid(2431070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431079,0,"69ba8101f335d0701853aa92764777d356bc9678fecf4c63fa07ced75800f571")

