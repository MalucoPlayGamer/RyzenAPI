-- Lua provided by RyzenAPI
-- Game: Game: 没有被美女包围的三角恋

-- MAIN APPLICATION
addappid(2744040)
-- Game: addappid(2744040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744041, 1, "21e41066e7a4db70931c34b3a82b32a947957c471166a52a0f7b8026a31a60f9")
