-- Lua provided by RyzenAPI
-- Game: PAC-MAN™ Championship Edition DX+

-- MAIN APPLICATION
addappid(236450)
-- Game: addappid(236450)

-- MAIN APP DEPOTS / PACKAGES
addappid(236451, 1, "2c25893e5492216e484ceb5f514f471a5521438c5ebc2d1b7c428604897c2530")
