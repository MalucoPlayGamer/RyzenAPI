-- Lua provided by RyzenAPI
-- Game: PAC-MAN™ Championship Edition DX+

-- MAIN APPLICATION
addappid(236450)

-- MAIN APP DEPOTS / PACKAGES
addappid(236451, 1, "2c25893e5492216e484ceb5f514f471a5521438c5ebc2d1b7c428604897c2530")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(246250)
addappid(246251)
addappid(246252)
addappid(246253)
addappid(246254)
addappid(246255)
addappid(246256)
addappid(246257)
