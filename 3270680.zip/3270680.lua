-- Lua provided by SkyAPI 
-- Game: AppID 3270680
addappid(3270680)
addappid(3270681, 1, "c99a11119e6a3f2444e574b59bde526dbed1314f7d4490066ea52e68af2de78b")
