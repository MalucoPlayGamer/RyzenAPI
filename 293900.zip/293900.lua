-- Lua provided by RyzenAPI
-- Game: Pivvot

-- MAIN APPLICATION
addappid(293900)

-- MAIN APP DEPOTS / PACKAGES
addappid(293902,0,"3e17bb681fa2e47eb9b33756d53f00eaaf3c7429bb506c3261e525493d236115")
addappid(293903,0,"b84f271249e77984a1bc41030e0bca107eb7330fe4b605e617a484b41eac1fe0")
addappid(293904,0,"dce53a4caaf13d0a42e195ba7b31432cc0471701c31296f2b32250c766ec2c0e")
addappid(311440,0,"4a2a5792213146d307fcb75f96334b54eebf4b38edb81c5b4b0711199554f7c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
