-- Lua provided by RyzenAPI
-- Game: OASE - Other Age Second Encounter

-- MAIN APPLICATION
addappid(400410)
-- Game: addappid(400410)

-- MAIN APP DEPOTS / PACKAGES
addappid(400411, 1, "d5b86f4ded11a0aa5e8cc5e0a0d5874f82040a9b5a9c71485286039235feb037")
