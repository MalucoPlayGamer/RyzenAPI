-- Lua provided by RyzenAPI
-- Game: PGA TOUR 2K25

-- MAIN APPLICATION
addappid(2385530)
-- Game: addappid(2385530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385531, 1, "891c9c194df2d680a3dbe94e736933f9252184a9680761d1cd6cef9fd178a77a")
