-- Lua provided by RyzenAPI
-- Game: PGA TOUR 2K25

-- MAIN APPLICATION
addappid(2385530) -- PGA TOUR 2K25
addappid(2385540) -- PGA TOUR 2K25 Extra Butter x adidas Pack
addappid(2385541) -- PGA TOUR 2K25 Starter Pack
addappid(2385570) -- PGA TOUR 2K25 - Malbon Bucket Ball Pack
addappid(2385571) -- PGA TOUR 2K25 Members Pass
addappid(2385580) -- PGA TOUR 2K25 Clubhouse Pass Premium Season 1
addappid(3226840) -- PGA TOUR 2K25 - Birdie Pack
addappid(3226860) -- PGA TOUR 2K25 Sun Day Red Pack
addappid(3326590) -- PGA TOUR 2K25 - Clubhouse Gear Pack
addappid(3337880) -- PGA TOUR 2K25 Clubhouse Pass Premium Season 2
addappid(3337890) -- PGA TOUR 2K25 - Clubhouse Pass Premium Season 3
addappid(3337900) -- PGA TOUR 2K25 Clubhouse Pass Premium Season 4
addappid(3337910) -- PGA TOUR 2K25 Clubhouse Pass Premium Season 5
addappid(4085380) -- PGA TOUR 2K25 Clubhouse Pass Premium Season 6
addappid(4085390) -- PGA TOUR 2K25 - Clubhouse Pass Premium Season 7
addappid(4085410) -- PGA TOUR 2K25 Clubhouse Gear Pack Year 2
addappid(4085420) -- PGA TOUR 2K25 Year 2 Members Pass
addappid(4092500) -- PGA TOUR 2K25 Pro Accelerator Bonus Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(2385531, 1, "891c9c194df2d680a3dbe94e736933f9252184a9680761d1cd6cef9fd178a77a") -- Depot 2385531

