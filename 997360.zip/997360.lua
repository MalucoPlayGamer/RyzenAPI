-- Lua provided by RyzenAPI
-- Game: 997360

-- MAIN APPLICATION
addappid(997360)
-- Game: addappid(997360)

-- MAIN APP DEPOTS / PACKAGES
addappid(997361, 1, "a1561cdef84e62b0edac30422b2a2b1367e31a95bd47dceaa6a9e9d325dbadca")
