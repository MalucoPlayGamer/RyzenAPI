-- Lua provided by RyzenAPI
-- Game: Vaulted Valor

-- MAIN APPLICATION
addappid(3417600) -- Vaulted Valor

-- MAIN APP DEPOTS / PACKAGES
addappid(3417601, 1, "803a116262bacf20da897b87d6217b82304cb1b0d43df84398774ed4fca277c8") -- Depot 3417601
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
