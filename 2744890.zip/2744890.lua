-- Lua provided by RyzenAPI
-- Game: Crystal Guardians Prologue

-- MAIN APPLICATION
addappid(2744890)
-- Game: addappid(2744890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744891, 1, "088dc6446fe78cc6e2e2ee288beeda35f58dfa5257548fbe56c271476591a6c5")
