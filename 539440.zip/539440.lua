-- Lua provided by RyzenAPI
-- Game: Game: AppID 539440

-- MAIN APPLICATION
addappid(539440)
-- Game: addappid(539440)

-- MAIN APP DEPOTS / PACKAGES
addappid(539441, 1, "699a5a3e3353de6a5a3934930b294cd89aab8a2212e2adae0120470dd5e6d942")
addappid(539442, 1, "b9da4aaf26a0a1b9d0aaab67ce2b661d22d6214861536f302d155ae6e62cdec5")
