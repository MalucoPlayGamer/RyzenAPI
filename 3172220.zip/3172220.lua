-- Lua provided by RyzenAPI
-- Game: YUME 5 : Spring Festival of Lust

-- MAIN APPLICATION
addappid(3172220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172221, 1, "420c56109db1519fc24b75968bfeb19a77a69e7391b47125420aeae63bc2c6b3")

