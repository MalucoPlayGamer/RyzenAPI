-- Lua provided by RyzenAPI
-- Game: 3172220

-- MAIN APPLICATION
addappid(3172220)
-- Game: addappid(3172220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172221, 1, "420c56109db1519fc24b75968bfeb19a77a69e7391b47125420aeae63bc2c6b3")
