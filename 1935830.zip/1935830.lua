-- Lua provided by RyzenAPI
-- Game: Stoney's Adventure

-- MAIN APPLICATION
addappid(1935830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935831, 1, "442d50e1e72cc06e3885fdcfe423de703661401ad1fa5402aa878e74bf6d995c")
