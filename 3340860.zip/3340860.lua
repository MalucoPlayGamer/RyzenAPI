-- Lua provided by RyzenAPI
-- Game: addappid(3340860)

-- MAIN APPLICATION
addappid(3340860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3340862,0,"acbd242abfa0889a3ce0e7a0c0e42c89d3062ea0326cb0ceae700526466a59a9")
