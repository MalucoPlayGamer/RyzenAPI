-- Lua provided by RyzenAPI
-- Game: Organizer

-- MAIN APPLICATION
addappid(3340860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3340862,0,"acbd242abfa0889a3ce0e7a0c0e42c89d3062ea0326cb0ceae700526466a59a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
