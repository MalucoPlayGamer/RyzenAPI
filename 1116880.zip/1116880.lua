-- Lua provided by RyzenAPI
-- Game: addappid(1116880)

-- MAIN APPLICATION
addappid(1116880)
addappid(1883380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116881, 1, "831df00d649d6e5cfd28e9c556e54e336bb813da3e71fdfc8f4fdec7eeb5ccff")
addappid(1880400, 0, "ebfdb67369f68440d9434eeafc1e606fefdf8125f5d1fe053fcaecbe93789626")
