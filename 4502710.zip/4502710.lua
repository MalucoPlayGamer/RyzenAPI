-- 4502710's Lua and Manifest Created by Hubcap Manifest
-- Stonewards
-- Created: August 11, 2026 at 23:25:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4502710) -- Stonewards
-- MAIN APP DEPOTS
addappid(4502711, 1, "6bdd3c6710622e5f03c268df0de252546165acb87ab19e8ec6bd60b941958aa5") -- Depot 4502711
setManifestid(4502711, "3759952621705494836", 2001722333)