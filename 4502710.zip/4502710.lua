-- Lua provided by RyzenAPI
-- Game: Stonewards

-- MAIN APPLICATION
addappid(4502710) -- Stonewards

-- MAIN APP DEPOTS / PACKAGES
addappid(4502711, 1, "6bdd3c6710622e5f03c268df0de252546165acb87ab19e8ec6bd60b941958aa5") -- Depot 4502711

