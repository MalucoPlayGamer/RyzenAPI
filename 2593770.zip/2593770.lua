-- Lua provided by RyzenAPI
-- Game: Project Chimeira

-- MAIN APPLICATION
addappid(2593770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593771, 1, "d7b28dbc7c0bfb30e51fc0c691c4d4a6c857d492f8b5a7c9394bdf132cc07672")
