-- Lua provided by RyzenAPI
-- Game: Fantasy Heroes

-- MAIN APPLICATION
addappid(1031210)
addappid(1218390)
-- Game: addappid(1031210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031211, 1, "bcbf52e1bd5a780d0a7a0d092e6db6aa8bee269f7435913aeab80a9d821ed93d")
