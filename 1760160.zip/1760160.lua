-- Lua provided by RyzenAPI
-- Game: 1760160

-- MAIN APPLICATION
addappid(1760160)
-- Game: addappid(1760160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760161, 1, "81c9c42db6cccd4ae0b343f506bf4753058ebe322828394567a14ab6ac9dc0b6")
