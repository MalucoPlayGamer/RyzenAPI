-- Lua provided by RyzenAPI
-- Game: Hidden Battle Top-Down 3D

-- MAIN APPLICATION
addappid(2023630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023631, 1, "869d07939b3c4b83ffc7351c398bf9db5d07f83790583a75c7d11b35ece5ff0e")
