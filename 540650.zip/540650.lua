-- Lua provided by RyzenAPI
-- Game: AppID 540650

-- MAIN APPLICATION
addappid(540650)
-- Game: addappid(540650)

-- MAIN APP DEPOTS / PACKAGES
addappid(540651, 1, "a825fa1b23dbefb027c269a09f99a47eec8cd0424506b1b56140851120e9c1fd")
