-- Lua provided by RyzenAPI
-- Game: AppID 540650

-- MAIN APPLICATION
addappid(540650)

-- MAIN APP DEPOTS / PACKAGES
addappid(540651, 1, "a825fa1b23dbefb027c269a09f99a47eec8cd0424506b1b56140851120e9c1fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
