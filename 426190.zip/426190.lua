-- Lua provided by RyzenAPI
-- Game: Miner Meltdown

-- MAIN APPLICATION
addappid(426190)
addappid(426191)
addappid(426193)
addappid(780830)

-- MAIN APP DEPOTS / PACKAGES
addappid(426192,0,"78505011cdd354235f675d203170f8520903022e7bb767414e7806814963b0fb")
