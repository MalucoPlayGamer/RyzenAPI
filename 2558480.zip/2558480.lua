-- Lua provided by RyzenAPI
-- Game: 碧海潮生怀旧版

-- MAIN APPLICATION
addappid(2558480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2558481, 1, "ba72705c5b0563760036d8e29fd4ad6bb40c1aaf9ffb280430dfdc554b96b7df")
