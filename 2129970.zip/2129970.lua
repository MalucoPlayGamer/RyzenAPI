-- Lua provided by RyzenAPI
-- Game: My Loving Wife

-- MAIN APPLICATION
addappid(2129970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129971, 1, "05d09f662a10284b691f1be966906c32c8731046bb815ee0dcaa353542f26162")

