-- Lua provided by RyzenAPI
-- Game: addappid(1012490)

-- MAIN APPLICATION
addappid(1012490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012491, 1, "6cef2ce49a99cbc708b752133d3b8eff25e06334ecf44597ecb68ec8908523dd")
addappid(1012492, 1, "28f7673b2050fe193b3cccdf0678c53ba70c3212bde8bb3993672b6bbd9d068f")
