-- Lua provided by RyzenAPI
-- Game: Horny Suika: Wet Watermelon

-- MAIN APPLICATION
addappid(2739980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739981, 1, "cf0ab872a17e935fb0bfc6f3069a078416eb7bbd3d16514066b9a94f99d56127")

