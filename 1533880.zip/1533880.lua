-- Lua provided by RyzenAPI
-- Game: Game: Hunter Girl

-- MAIN APPLICATION
addappid(1533880)
-- Game: addappid(1533880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533881, 1, "d09f1b4822fd8131509e8c5be770032f7a7c28fef9e48f3374ba5604a72544fc")
