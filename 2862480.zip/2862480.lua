-- Lua provided by RyzenAPI
-- Game: Game: Windowkill Soundtrack

-- MAIN APPLICATION
addappid(2862480)
-- Game: addappid(2862480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862481, 1, "9670abe4bd33c543c43300bd8a2c5229887d5bb37eea171b0c7704752d5b1fb5")
addappid(2862482, 1, "ee1d57ba8bdaba4c909afa03cadce05337d1b3cabccf2a1adaf70924dc78c02f")
