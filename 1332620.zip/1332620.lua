-- Lua provided by RyzenAPI 
-- Game: Ashmedai: Queen of Lust
addappid(1332620)
addappid(1332621, 1, "bf3d99bcbb2483ce23d84a79c67fac14d9169fe547b06135108cdd5a8dd7f3cc")
addappid(1571710, 0, "41898f65117b260dd4567df4926cd96a0cca46f5713eec49e77eafeab5226f9c")
