-- Lua provided by RyzenAPI
-- Game: The Thing at the Window

-- MAIN APPLICATION
addappid(1135560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1135561, 1, "24061375b4518fb9814fe154bcd30c73f8412867e4eab3d687bd5ff536ba292a")

