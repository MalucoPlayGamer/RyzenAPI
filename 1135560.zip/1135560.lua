-- Lua provided by RyzenAPI
-- Game: addappid(1135560)

-- MAIN APPLICATION
addappid(1135560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135561, 1, "24061375b4518fb9814fe154bcd30c73f8412867e4eab3d687bd5ff536ba292a")
