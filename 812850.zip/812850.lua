-- Lua provided by RyzenAPI
-- Game: Outline

-- MAIN APPLICATION
addappid(812850)
-- Game: addappid(812850)

-- MAIN APP DEPOTS / PACKAGES
addappid(812851, 1, "2862efff4d82a1cce7e939b75f0caa59021734e087412516c35038072f6a88bd")
