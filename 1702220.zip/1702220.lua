-- Lua provided by RyzenAPI
-- Game: addappid(1702220)

-- MAIN APPLICATION
addappid(1702220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702229,0,"dc9d7de1f2aaaac375d7d0d1d204e112aa8170a241d7caaea5e290293afbb747")
