-- Lua provided by RyzenAPI
-- Game: setManifestid(1702229,"5749142917628267783")

-- MAIN APPLICATION
addappid(1702220)
-- Game: addappid(1702220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702229,0,"dc9d7de1f2aaaac375d7d0d1d204e112aa8170a241d7caaea5e290293afbb747")
