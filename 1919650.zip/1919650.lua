-- Lua provided by RyzenAPI
-- Game: Game: AppID 1919650

-- MAIN APPLICATION
addappid(1919650)
-- Game: addappid(1919650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919651, 1, "23497c775ab0729a14c21a7c227195c6c183723310fc371ffd7877eedfeb2ea5")
