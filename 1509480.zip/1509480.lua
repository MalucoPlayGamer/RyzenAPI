-- Lua provided by RyzenAPI
-- Game: Elysium Above 履云录 Demo

-- MAIN APPLICATION
addappid(1509480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509481, 1, "1f2861b1e575aada905e0a5416b1141e38bae61f2f76d2ef411a656b3aaab9c2")
