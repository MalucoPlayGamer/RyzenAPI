-- Lua provided by RyzenAPI
-- Game: Pixelgroove

-- MAIN APPLICATION
addappid(2871570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871571, 1, "0073036a90cc160ff5f128e5c68ae50f6a188addd1311e3e061efa4394a8158d")

