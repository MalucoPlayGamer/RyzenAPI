-- Lua provided by RyzenAPI
-- Game: 762940

-- MAIN APPLICATION
addappid(762940)
-- Game: addappid(762940)

-- MAIN APP DEPOTS / PACKAGES
addappid(762941, 1, "faa039677305dd7f0d1bf3f26cb9c170a85e7e224016d10d7c5eb395acb1ca83")
