-- Lua provided by RyzenAPI
-- Game: Critters for Sale: SNAKE

-- MAIN APPLICATION
addappid(1350240)
addappid(1350243)
addappid(1350244)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350242,0,"d3b7486a90f83988ccd1f67a349923f59b68ce9fa3e9ef371a2a267a172e5687")

