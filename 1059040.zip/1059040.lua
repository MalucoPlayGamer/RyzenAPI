-- Lua provided by RyzenAPI
-- Game: 1059040

-- MAIN APPLICATION
addappid(1059040)
-- Game: addappid(1059040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059041, 1, "62258d5d9aa07e2888425d083f3eaea37a6e056a05ac3a08f13339b744d20eab")
