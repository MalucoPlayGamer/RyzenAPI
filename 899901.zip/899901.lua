-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Easy Linear Playing Exercise 1

-- MAIN APPLICATION
addappid(899901)

-- MAIN APP DEPOTS / PACKAGES
addappid(899901,0,"44e4e763f09a02f21e19317c4800647926201aea375b2eb2c3d45a367ee25446")

