-- Lua provided by RyzenAPI
-- Game: addappid(2560100)

-- MAIN APPLICATION
addappid(2560100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560101, 1, "add18006dc15b2920eff7541b312c553c75a1c728546c857829e1a172d9e6f3f")
