-- Lua provided by RyzenAPI
-- Game: Midnight Special

-- MAIN APPLICATION
addappid(2560100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2560101, 1, "add18006dc15b2920eff7541b312c553c75a1c728546c857829e1a172d9e6f3f")

