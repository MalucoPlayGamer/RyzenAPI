-- Lua provided by RyzenAPI
-- Game: addappid(1587780)

-- MAIN APPLICATION
addappid(1587780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587781, 1, "d6f8f15f5df082f6edc55bd1133a3d85feba4072465992770ba0398b2745c656")
