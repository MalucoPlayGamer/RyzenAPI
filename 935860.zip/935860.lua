-- Lua provided by RyzenAPI
-- Game: The young mathematician: Easy difficulty

-- MAIN APPLICATION
addappid(935860)

-- MAIN APP DEPOTS / PACKAGES
addappid(935861, 1, "4a170d6cbb69c08a6f09bd45b0bf7d89777ff6a7ba9ffa9bf1e101ffbe35f511")
