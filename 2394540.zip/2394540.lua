-- Lua provided by SkyAPI 
-- Game: AppID 2394540
addappid(2394540)
addappid(2394541, 1, "fd815dd54b7c356d634d425c19bf63c5af194df971354be7b714e7da2611d1cc")
addappid(2394542, 1, "f01f0c846beaa4f826dbfabb743c8998697353521d01ef4eb02e5ee5b018b5f6")
