-- Lua provided by RyzenAPI
-- Game: 816950

-- MAIN APPLICATION
addappid(816950)
-- Game: addappid(816950)

-- MAIN APP DEPOTS / PACKAGES
addappid(816951, 1, "2fc57f33bd3709a3c7326adc2232dce1efd6c1eb89b46878b516fa6a5e26f27d")
