-- Lua provided by SkyAPI 
-- Game: AppID 3491220
addappid(3491220)
addappid(3491221, 1, "6bc67dcf206b2f69a02b1efa784a330164a12a9bb810ce4c449fae6230358695")
