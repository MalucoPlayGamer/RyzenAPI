-- Lua provided by RyzenAPI
-- Game: 3491220

-- MAIN APPLICATION
addappid(3491220)
-- Game: addappid(3491220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3491221, 1, "6bc67dcf206b2f69a02b1efa784a330164a12a9bb810ce4c449fae6230358695")
