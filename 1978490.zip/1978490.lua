-- Lua provided by RyzenAPI
-- Game: Pixel drawing block

-- MAIN APPLICATION
addappid(1978490)
-- Game: addappid(1978490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978491, 1, "481a62a734c579287aba00968c7fecb7d167feb42ab9953faee4e551411ad727")
