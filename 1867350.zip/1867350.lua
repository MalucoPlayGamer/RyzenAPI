-- Lua provided by RyzenAPI
-- Game: Slime Village VR

-- MAIN APPLICATION
addappid(1867350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867351, 1, "7fa4b9054060fb5c7fe98b0d4203021aa6e7fe2a8fe02b9524cc864b92c07459")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
