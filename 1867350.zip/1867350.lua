-- Lua provided by RyzenAPI
-- Game: 1867350

-- MAIN APPLICATION
addappid(1867350)
-- Game: addappid(1867350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867351, 1, "7fa4b9054060fb5c7fe98b0d4203021aa6e7fe2a8fe02b9524cc864b92c07459")
