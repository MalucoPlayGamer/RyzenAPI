-- Lua provided by RyzenAPI
-- Game: addappid(2832560)

-- MAIN APPLICATION
addappid(2832560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832561, 1, "ee78db39cb7c3f5ecbc362a0c9f203e9ff2a94480fbf5bc925d1238a23ad171e")
