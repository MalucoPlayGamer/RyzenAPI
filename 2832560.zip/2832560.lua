-- Lua provided by RyzenAPI
-- Game: Silent

-- MAIN APPLICATION
addappid(2832560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2832561, 1, "ee78db39cb7c3f5ecbc362a0c9f203e9ff2a94480fbf5bc925d1238a23ad171e")

