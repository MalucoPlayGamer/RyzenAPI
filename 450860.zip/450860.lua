-- Lua provided by RyzenAPI
-- Game: AppID 450860

-- MAIN APPLICATION
addappid(450860)

-- MAIN APP DEPOTS / PACKAGES
addappid(450861, 1, "dad4d9240e547fd411df6cf33733381534546968b44879c18bac3a679afbb9d0")
addappid(450862, 1, "119c6b3ddda1c87c85822a56bd01034da24b7c6d6dcc1137a591883e284d2b74")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(730040)
addappid(731750)
addappid(749170)
addappid(819360)
addappid(823660)
addappid(1085400)
