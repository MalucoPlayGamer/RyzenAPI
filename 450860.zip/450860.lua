-- Lua provided by SkyAPI 
-- Game: AppID 450860
addappid(450860)
addappid(450861, 1, "dad4d9240e547fd411df6cf33733381534546968b44879c18bac3a679afbb9d0")
addappid(450862, 1, "119c6b3ddda1c87c85822a56bd01034da24b7c6d6dcc1137a591883e284d2b74")
