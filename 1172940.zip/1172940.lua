-- Lua provided by RyzenAPI
-- Game: Cockwork Industries Complete

-- MAIN APPLICATION
addappid(1172940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172941, 1, "25a2dc491586f75f0abc70b9b16c93e9b2d76c7103becef52ba41fcebad1884f")

