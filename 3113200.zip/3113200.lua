-- Lua provided by SkyAPI 
-- Game: Edge of Sanity - Soundtrack
addappid(3113200)
addappid(3113201, 1, "197950e3876a63b0ec5c6806dcd77e229eae813b2784363042172130e0751955")
addappid(3113202, 1, "0a424148a4e85d71a0d4ea2fad6a664cee090e1524327bc9d60fd07cb51c6676")
