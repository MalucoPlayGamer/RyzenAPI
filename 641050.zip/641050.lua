-- Lua provided by RyzenAPI
-- Game: StroodleDoodle

-- MAIN APPLICATION
addappid(641050)

-- MAIN APP DEPOTS / PACKAGES
addappid(641051,0,"1e59b6cb329f0ba5477821a5f553791a654c947c39f858fb5cc2a515230246ec")

