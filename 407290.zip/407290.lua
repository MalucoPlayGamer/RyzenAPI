-- Lua provided by RyzenAPI
-- Game: There Was A Caveman

-- MAIN APPLICATION
addappid(407290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(407291, 1, "77ebff4658cf8bcba6a35f6d2fe8159f89791b43f0a2a055e3c6e72fea67357c")

