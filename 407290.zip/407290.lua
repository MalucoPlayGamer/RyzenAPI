-- Lua provided by RyzenAPI 
-- Game: There Was A Caveman
addappid(407290)
addappid(407291, 1, "77ebff4658cf8bcba6a35f6d2fe8159f89791b43f0a2a055e3c6e72fea67357c")
