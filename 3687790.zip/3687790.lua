-- Lua provided by RyzenAPI
-- Game: Deadliest Pigeon

-- MAIN APPLICATION
addappid(3687790) -- Deadliest Pigeon
addappid(5031640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3687791, 1, "fcaf346fd5ed144336541d7ba2fb8200ad9b56294e1bc66d769af20d382b7774") -- Depot 3687791

