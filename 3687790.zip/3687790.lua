-- 3687790's Lua and Manifest Created by Hubcap Manifest
-- Deadliest Pigeon
-- Created: August 06, 2026 at 14:59:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3687790) -- Deadliest Pigeon
-- MAIN APP DEPOTS
addappid(3687791, 1, "fcaf346fd5ed144336541d7ba2fb8200ad9b56294e1bc66d769af20d382b7774") -- Depot 3687791
setManifestid(3687791, "1695699280546585555", 5214311409)