-- Lua provided by RyzenAPI
-- Game: Borealis

-- MAIN APPLICATION
addappid(307170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(307171, 1, "547eef52ef7dd49c96f3ee10173633a62225dc57ab75cd7da8a58aa7c96dbd86")
