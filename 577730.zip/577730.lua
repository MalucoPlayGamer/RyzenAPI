-- Lua provided by RyzenAPI
-- Game: Game: Idle Evolution

-- MAIN APPLICATION
addappid(577730)
-- Game: addappid(577730)

-- MAIN APP DEPOTS / PACKAGES
addappid(577731, 1, "5edba18ef0e582fc725c34c1a28c8825fd6378deef664a0f0d4f6d7733a88b51")
