-- Lua provided by RyzenAPI
-- Game: Game: SHOOPER NOVA

-- MAIN APPLICATION
addappid(2853160)
-- Game: addappid(2853160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853161, 1, "8847ddb773742ba493c003dd4aa1c2e51b561cc2dfe206eda8cd1fff17132b4f")
