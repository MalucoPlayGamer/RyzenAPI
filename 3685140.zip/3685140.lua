-- Lua provided by RyzenAPI
-- Game: 3685140

-- MAIN APPLICATION
addappid(3685140)
-- Game: addappid(3685140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3685141, 1, "4358e1588b8ec150cb4e508f769af45f1c08ae16bddbfc90901baa7de291da6b")
