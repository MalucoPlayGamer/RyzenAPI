-- Lua provided by RyzenAPI
-- Game: DFF NT: Vaan Starter Pack

-- MAIN APPLICATION
addappid(1022467)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022467,0,"7663408cb28c4df4248d39c4597ac00e3288c93a3d1b6a878162486fa0548fc4")
