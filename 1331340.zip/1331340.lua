-- Lua provided by RyzenAPI
-- Game: Break the Loop

-- MAIN APPLICATION
addappid(1331340)
-- Game: addappid(1331340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331341, 1, "0e97944479b2a17b5ea623d73bc601800bea306ae87a3ec42886d9eb17897561")
