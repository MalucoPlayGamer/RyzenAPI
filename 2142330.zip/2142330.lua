-- Lua provided by RyzenAPI
-- Game: Bud Spencer & Terence Hill - Slaps And Beans 2

-- MAIN APPLICATION
addappid(2142330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142331, 1, "726589e2196fb1860447c16330501e8adfb574ab1af8e2e8f9484142041e30da")

