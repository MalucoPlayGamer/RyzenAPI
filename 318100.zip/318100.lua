-- Lua provided by RyzenAPI
-- Game: 318100

-- MAIN APPLICATION
addappid(318100)
-- Game: addappid(318100)

-- MAIN APP DEPOTS / PACKAGES
addappid(318101, 1, "372d1396227c7e54a3480b9707179c0b5dfa3eadf258a1166512ac16d11beef8")
