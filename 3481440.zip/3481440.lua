-- Lua provided by RyzenAPI
-- Game: addappid(3481440)

-- MAIN APPLICATION
addappid(3481440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3481441, 1, "f99343d8063a037a269fcb7e5b6cde034ceea70f83e3452ece1fec5e6505b1bb")
addappid(3481442, 1, "4421071bdfc2e6636c15ba97f4043f91140946d166e92edd10b7a4f64e2bbde5")
