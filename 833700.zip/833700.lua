-- Lua provided by RyzenAPI
-- Game: City Bus Simulator 2018

-- MAIN APPLICATION
addappid(833700)
-- Game: addappid(833700)

-- MAIN APP DEPOTS / PACKAGES
addappid(833701, 1, "55aa1342afa0b4f0a24a15df53f70d56a622e007d2bc4665453b5185d7d14f20")
