-- Lua provided by RyzenAPI
-- Game: 2095140

-- MAIN APPLICATION
addappid(2095140)
-- Game: addappid(2095140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095142,0,"9d8a4915a3345847449700ca9b7bceedfdcb45179b51cf24476757d66caf0775")
