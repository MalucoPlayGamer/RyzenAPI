-- Lua provided by RyzenAPI
-- Game: 1385500

-- MAIN APPLICATION
addappid(1385500)
-- Game: addappid(1385500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385501, 1, "b7808b4b047af9e9f2f3a241992c4616d02a7e2412362bbf8cd191a13c17a1cb")
