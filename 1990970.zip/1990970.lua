-- Lua provided by SkyAPI 
-- Game: AppID 1990970
addappid(1990970)
addappid(1990971, 1, "cb149e0dd76869ce16001ff9efeae49df52fd472d56a42f8c9f4964e8fa35808")
