-- Lua provided by RyzenAPI
-- Game: The Morgue Fissure Between Worlds

-- MAIN APPLICATION
addappid(547150)

-- MAIN APP DEPOTS / PACKAGES
addappid(547151,0,"2275082fbb77d4d22899f59d8959bf262221d2bbe28ba8a54ba280893ae9b4d9")

