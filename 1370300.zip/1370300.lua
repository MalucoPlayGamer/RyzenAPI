-- Lua provided by RyzenAPI
-- Game: 1370300

-- MAIN APPLICATION
addappid(1370300)
-- Game: addappid(1370300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370301, 1, "9b51c6fd21d121cbc3f9fd7266fbf2d52b428f7fc5034b13573ee6f07b10acf2")
