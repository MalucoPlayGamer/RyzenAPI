-- Lua provided by RyzenAPI
-- Game: Freakshow soundtrack

-- MAIN APPLICATION
addappid(898420)
-- Game: addappid(898420)

-- MAIN APP DEPOTS / PACKAGES
addappid(898420,0,"42c484a0ad4caf590b6dc7397bfa1e4b8294f0615f3a32942239754ca5754f15")
