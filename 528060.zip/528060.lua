-- Lua provided by RyzenAPI
-- Game: 東周列萌志 Philosophic Love

-- MAIN APPLICATION
addappid(528060)
addappid(894500)
addappid(895130)
addappid(1249920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(528061, 1, "c7ff98bb4a5f53401b2b5d7fc386271ca6e0d009cee92c9481664f73fff38c0f")
addappid(528062, 1, "0bf68fcc926b076c82f73962b472d80374ffe3093e0bf8316e2c93313b3106b7")
addappid(528063, 1, "d975a05426aa0516435651cde8fbd7469b441e83b9c8f71202cda3d7b7a3d7f0")
addappid(528064, 1, "b1cabc8adc5d2bdb198c33d7749d97bbe1364923d37fe2e2c1938f97cec77081")
addappid(528065, 1, "5857fd2ea6152624f5959a977ae92b42b70a5e65886beb3870b02577c96c4018")
addappid(528066, 1, "eea6bcbea0fb388e2ae4ae2efff1f4d6af0564c5276bb1c834dc53eaa8688467")
addappid(528067, 1, "e9f57e63cf1c7ccc7c962301665ed3d9f61ef2805b7d857c507f946bdd428a43")
addappid(528068, 1, "fcdb4d99c319154c687d18c13347ff2f50dd369c7d2bf3196d270157a812675c")

