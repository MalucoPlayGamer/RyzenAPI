-- Lua provided by RyzenAPI
-- Game: addappid(713080)

-- MAIN APPLICATION
addappid(713080)

-- MAIN APP DEPOTS / PACKAGES
addappid(713081, 1, "2fdd224573f1c9e32cdf0bd014f845c6d115686eeeff4aa75c11bb82acbda963")
