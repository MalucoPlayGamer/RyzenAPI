-- Lua provided by RyzenAPI
-- Game: addappid(3660090)

-- MAIN APPLICATION
addappid(3660090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3660091, 1, "70c01f7e7692a13b70a8d4ab77a229eee91df6a149a27fb11b0bce73d7ac008a")
