-- Lua provided by RyzenAPI
-- Game: Total Chaos

-- MAIN APPLICATION
addappid(2208350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2208351, 1, "f89145057d0fc47ccfafc6f127d9a151704248d818381e1fd71c03e5124b81fb")
