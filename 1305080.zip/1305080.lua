-- Lua provided by RyzenAPI
-- Game: GearBlocks

-- MAIN APPLICATION
addappid(1305080)
-- Game: addappid(1305080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305081, 1, "5137f201daad2a7ee699149c46ff8b27786d400d8ffc959a0fb1c7cf53beb4b2")
addappid(1305082, 1, "9d05c1a650b5139aeaaaef711f52f7d8cc3123e7b0e1b94c46010e922b44a8b9")
addappid(1305086, 1, "a2466c2f181265df030537a6e8efc797454761d097d9c32fa2813d4a9185a876")
