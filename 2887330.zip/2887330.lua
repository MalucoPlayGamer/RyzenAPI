-- Lua provided by RyzenAPI
-- Game: Shadow Album Demo

-- MAIN APPLICATION
addappid(2887330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2887331, 1, "5ec7d2a9747984ce5999cddc4d8225b7a4b4a198ceb1e74adf31857632c18a98")
