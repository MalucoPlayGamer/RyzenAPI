-- Lua provided by RyzenAPI
-- Game: 1422410

-- MAIN APPLICATION
addappid(1422410)
-- Game: addappid(1422410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422411, 1, "3bcc2e597bfa84420d9743ec005dcd47113006b8095768cc40fed6de0bc6b539")
