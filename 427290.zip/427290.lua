-- Lua provided by RyzenAPI
-- Game: addappid(427290)

-- MAIN APPLICATION
addappid(427290)
addappid(728850)

-- MAIN APP DEPOTS / PACKAGES
addappid(427291, 1, "cdc71f514e81cdcdf2205f20a95908bd1e90d12bad79d5089096ba9966113524")
