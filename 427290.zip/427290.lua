-- Lua provided by RyzenAPI
-- Game: Vampyr

-- MAIN APPLICATION
addappid(427290)
addappid(728850)

-- MAIN APP DEPOTS / PACKAGES
addappid(427291, 1, "cdc71f514e81cdcdf2205f20a95908bd1e90d12bad79d5089096ba9966113524")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
