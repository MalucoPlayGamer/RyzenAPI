-- Lua provided by RyzenAPI
-- Game: Hentai Stories - Digital Artbook

-- MAIN APPLICATION
addappid(3430240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3430240,0,"c6d69b049966318dc7b68caa479ca8ff02f232686659642670fc72e148bfed95")

