-- Lua provided by SkyAPI 
-- Game: AppID 765530
addappid(765530)
addappid(765531, 1, "e07217503864bed818d403e7e87191a1bff2c1f9441365cb82d3717bbb276a1d")
