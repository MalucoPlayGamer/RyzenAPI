-- Lua provided by RyzenAPI
-- Game: AppID 765530

-- MAIN APPLICATION
addappid(765530)
-- Game: addappid(765530)

-- MAIN APP DEPOTS / PACKAGES
addappid(765531, 1, "e07217503864bed818d403e7e87191a1bff2c1f9441365cb82d3717bbb276a1d")
