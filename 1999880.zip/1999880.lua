-- Lua provided by SkyAPI 
-- Game: Life is Paradise
addappid(1999880)
addappid(1999881, 1, "269de22c86538acac553e8a021bcf59e7f9df81599d79c77dc850a7b68b027f0")
