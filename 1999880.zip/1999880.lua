-- Lua provided by RyzenAPI
-- Game: Life is Paradise

-- MAIN APPLICATION
addappid(1999880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999881, 1, "269de22c86538acac553e8a021bcf59e7f9df81599d79c77dc850a7b68b027f0")
