-- Lua provided by RyzenAPI
-- Game: Game: SEXY LADIES

-- MAIN APPLICATION
addappid(2567710)
-- Game: addappid(2567710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567711, 1, "0119167cd08cd0262abea5e687f962954f53253040d63bb516afe99f6a1f5660")
