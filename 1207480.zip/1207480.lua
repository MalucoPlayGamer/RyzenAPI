-- Lua provided by RyzenAPI
-- Game: Pupper park

-- MAIN APPLICATION
addappid(1207480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1207481, 1, "e21e1dc22e417812e20ac8455277ace427b7f489f6373715f460d2b48fed7cce")
addappid(1207482, 1, "7c60b536d95648df3272c9e5e114b5ccef93915f736021457f2552c4da9a330a")

