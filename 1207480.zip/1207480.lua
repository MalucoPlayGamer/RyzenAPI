-- Lua provided by RyzenAPI
-- Game: Pupper park

-- MAIN APPLICATION
addappid(1207480)
-- Game: addappid(1207480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207481, 1, "e21e1dc22e417812e20ac8455277ace427b7f489f6373715f460d2b48fed7cce")
addappid(1207482, 1, "7c60b536d95648df3272c9e5e114b5ccef93915f736021457f2552c4da9a330a")
