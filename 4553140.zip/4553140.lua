-- 4553140's Lua and Manifest Created by Hubcap Manifest
-- Scratch Off!
-- Created: June 24, 2026 at 06:16:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4553140) -- Scratch Off!
-- MAIN APP DEPOTS
addappid(4553141, 1, "41152c074ed3c62952fc98feae7f54a97c55659e04ca3a831f93dbb06b333dad") -- Depot 4553141
setManifestid(4553141, "5360571165995181520", 173012440)