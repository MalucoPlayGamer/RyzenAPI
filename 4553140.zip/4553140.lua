-- Lua provided by RyzenAPI
-- Game: Scratch Off!

-- MAIN APPLICATION
addappid(4553140) -- Scratch Off!

-- MAIN APP DEPOTS / PACKAGES
addappid(4553141, 1, "41152c074ed3c62952fc98feae7f54a97c55659e04ca3a831f93dbb06b333dad") -- Depot 4553141

