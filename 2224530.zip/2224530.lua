-- Lua provided by RyzenAPI 
-- Game: Gas Station Tycoon
addappid(2224530)
addappid(2224531, 1, "812d411f44f2b732fbca9b63f4aa502899f8479edcc1679308c795bde0388e8b")
