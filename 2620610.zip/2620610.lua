-- Lua provided by SkyAPI 
-- Game: Dungeons of Mysteria
addappid(2620610)
addappid(2620611, 1, "8d34942680e90d006ca3b352a0f23c83a3de95a2267998930594529d611b9273")
