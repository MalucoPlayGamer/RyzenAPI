-- Lua provided by RyzenAPI
-- Game: Game: AppID 387400

-- MAIN APPLICATION
addappid(387400)
-- Game: addappid(387400)

-- MAIN APP DEPOTS / PACKAGES
addappid(387401, 1, "c952b9a59eb7f54acce0a51c1c9b1cebc86a04f42fd9bf2a66ac7bcc543baa28")
