-- Lua provided by SkyAPI 
-- Game: AppID 341760
addappid(341760)
addappid(341761, 1, "df951d5da18169e1a6180abe53617e9eccdfa25b10ea235543c11d37297c3e93")
addappid(341762, 1, "e80d56f2f12f21ce309567af73b89f105a829b2da2b656c8e12dfd9879032891")
