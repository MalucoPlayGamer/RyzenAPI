-- Lua provided by RyzenAPI
-- Game: addappid(422140)

-- MAIN APPLICATION
addappid(422140)

-- MAIN APP DEPOTS / PACKAGES
addappid(422141, 1, "329d247bcd2fba043964e8ed89d8320430bf365a8fe46be28ecfb0470235b70f")
