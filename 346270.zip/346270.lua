-- Lua provided by RyzenAPI
-- Game: Fortune's Tavern - The Fantasy Tavern Simulator!

-- MAIN APPLICATION
addappid(346270)
addappid(367280)
addappid(369450)
addappid(401740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(346271, 1, "f7b2a329752cde618f2bc14c5734f501cb716176f9a7e217c5f06f0ef50581e4")
addappid(362420, 0, "e230604faa9d2c8ab1cd1b5156474ff331bfbfd711da7f069edb2bb0bc76c114")
addappid(364410, 0, "0b7e4bddc8d16d310e7671b71819126fbf84052b2bcaa553e328e85b6c2f0158")
addappid(366140, 0, "523fd91f3848b6ff0005419c3c13de7af74189f9fdb5f65c07d3f46d29b14c6b")
