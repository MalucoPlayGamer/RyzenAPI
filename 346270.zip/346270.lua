-- Lua provided by RyzenAPI
-- Game: AppID 346270

-- MAIN APPLICATION
addappid(346270)
addappid(367280)
addappid(369450)
addappid(401740)
-- Game: addappid(346270)

-- MAIN APP DEPOTS / PACKAGES
addappid(346271, 1, "f7b2a329752cde618f2bc14c5734f501cb716176f9a7e217c5f06f0ef50581e4")
addappid(362420, 0, "e230604faa9d2c8ab1cd1b5156474ff331bfbfd711da7f069edb2bb0bc76c114")
addappid(364410, 0, "0b7e4bddc8d16d310e7671b71819126fbf84052b2bcaa553e328e85b6c2f0158")
addappid(366140, 0, "523fd91f3848b6ff0005419c3c13de7af74189f9fdb5f65c07d3f46d29b14c6b")
