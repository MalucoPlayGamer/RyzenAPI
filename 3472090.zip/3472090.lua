-- Lua provided by RyzenAPI
-- Game: 3472090

-- MAIN APPLICATION
addappid(3472090)
-- Game: addappid(3472090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3472091, 1, "0da54237bf3a96e6d18202fa5fe1288d06a439e85f9400701de3ecd7c6a783a9")
