-- Lua provided by RyzenAPI
-- Game: addappid(956721)

-- MAIN APPLICATION
addappid(956721)

-- MAIN APP DEPOTS / PACKAGES
addappid(956721,0,"2471ac3b89b7a73517971c658d0c5e3a38ec7375cc7391c5be34561cc6a31e8e")
