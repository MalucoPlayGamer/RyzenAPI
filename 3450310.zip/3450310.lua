-- 3450310's Lua and Manifest Created by Hubcap Manifest
-- Europa Universalis V
-- Created: July 16, 2026 at 06:06:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 4
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(3450310, 1, "abdc499f4638e2d977e16203b7173a9af729319f625704e136ec1b194032572a") -- Europa Universalis V
-- MAIN APP DEPOTS
addappid(3450311, 1, "8e55f9c055e30102dd092568a62262d3e5c812fc6708b9ed1ba03bdbe15dc456") -- Depot 3450311
setManifestid(3450311, "1843869554669924199", 14801998020)
addappid(3450312, 1, "8e3d3c7051dc0ba1a4320aa4fb02d83724de0150342f7c05e4b1b126f611dfd5") -- Depot 3450312
setManifestid(3450312, "3625260415707585388", 452357559)
addappid(3450313, 1, "559435c494fa76bc572eb78918ebd2a4046f80a9de65280538e793d66f5d34b0") -- Depot 3450313
setManifestid(3450313, "148061723707740060", 667016410)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3698980) -- Europa Universalis V Premium Upgrade
addappid(3699010) -- Europa Universalis V Fate of the Phoenix
addtoken(3699010, "6729835124443927372")
addappid(3865300) -- Europa Universalis V Sacred Sites
addappid(4091650) -- Europa Universalis V Ancient Monuments