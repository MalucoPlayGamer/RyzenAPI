-- Lua provided by RyzenAPI
-- Game: addappid(3226820)

-- MAIN APPLICATION
addappid(3226820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226821, 1, "69202f16ca1b815569f6aa7d216d6106dec3f9849d10ae86a76db230904d2d6b")
