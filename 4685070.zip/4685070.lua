-- 4685070's Lua and Manifest Created by Hubcap Manifest
-- Far Mining
-- Created: June 05, 2026 at 06:19:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4685070) -- Far Mining
-- MAIN APP DEPOTS
addappid(4685071, 1, "5fed10548c72111f68aba1cd9a23da67f9c732a03816ce34b6759261a4dfd351") -- Depot 4685071
setManifestid(4685071, "8860339319961201136", 164899580)