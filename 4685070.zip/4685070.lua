-- Lua provided by RyzenAPI
-- Game: Far Mining

-- MAIN APPLICATION
addappid(4685070) -- Far Mining

-- MAIN APP DEPOTS / PACKAGES
addappid(4685071, 1, "5fed10548c72111f68aba1cd9a23da67f9c732a03816ce34b6759261a4dfd351") -- Depot 4685071

