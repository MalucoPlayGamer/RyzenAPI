-- Lua provided by RyzenAPI
-- Game: Boat, Snake & Salvage

-- MAIN APPLICATION
addappid(3748440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3748441, 1, "30e8dbbff6c805d9aca855f99fd9c19615602ade180aaf5d0d1da4f720d1fabc")

