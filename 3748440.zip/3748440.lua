-- Lua provided by RyzenAPI
-- Game: addappid(3748440)

-- MAIN APPLICATION
addappid(3748440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3748441, 1, "30e8dbbff6c805d9aca855f99fd9c19615602ade180aaf5d0d1da4f720d1fabc")
