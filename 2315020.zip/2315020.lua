-- Lua provided by RyzenAPI 
-- Game: Froguelike
addappid(2315020)
addappid(2315021, 1, "c9f945eae1da39ab722e87bf589587286035a9b3634a63a20b15fe9c0669d763")
