-- Lua provided by RyzenAPI
-- Game: Froguelike

-- MAIN APPLICATION
addappid(2315020)
-- Game: addappid(2315020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315021, 1, "c9f945eae1da39ab722e87bf589587286035a9b3634a63a20b15fe9c0669d763")
