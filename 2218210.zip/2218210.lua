-- Lua provided by RyzenAPI
-- Game: 2218210

-- MAIN APPLICATION
addappid(2218210)
-- Game: addappid(2218210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218213,0,"449bd52562baf4f747e368bbee1c16c0d87b347c122d994aa5fe6acd20465a46")
addappid(2218216,0,"bfdd66566dbecdc96d0cff1aec51f263abad32ff081310bd4589d8cb0f66ec4c")
