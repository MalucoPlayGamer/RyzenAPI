-- Lua provided by RyzenAPI
-- Game: Farmington Tales

-- MAIN APPLICATION
addappid(667820)

-- MAIN APP DEPOTS / PACKAGES
addappid(667821,0,"d59b5dac876c9c6209b450daf2740f199c01d50622e17055d6fa711cbad1b9ab")

