-- Lua provided by RyzenAPI
-- Game: addappid(1022497)

-- MAIN APPLICATION
addappid(1022497)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022497,0,"5b660130e6b657973561471d1d5cd7cb7e1db2cc23300db87e33f44f1fbfe9cc")
