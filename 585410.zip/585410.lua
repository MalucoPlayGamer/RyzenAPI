-- Lua provided by RyzenAPI 
-- Game: AppID 585410
addappid(585410)
addappid(585411, 1, "429af3d5fad8639444edf48d7e5d01fccd1b5e9e096fbd4c28f318b28067f48a")
