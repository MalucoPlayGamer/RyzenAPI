-- Lua provided by RyzenAPI
-- Game: Sun Quan - Officer Ticket / 孫権使用券

-- MAIN APPLICATION
addappid(956739)

-- MAIN APP DEPOTS / PACKAGES
addappid(956739,0,"afc6557b77caa43ec4d7fb1bdc1dd603dbfca20556458edd04e169ad1bf99aa1")
