-- Lua provided by RyzenAPI
-- Game: 2407360

-- MAIN APPLICATION
addappid(2407360)
-- Game: addappid(2407360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407361, 1, "8d0df49ace6eaecf31506f9b8121f04fecf57948c917af8c4f58dcda3b90ea50")
