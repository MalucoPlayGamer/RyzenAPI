-- Lua provided by RyzenAPI
-- Game: Impaler Gold

-- MAIN APPLICATION
addappid(1573090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573091, 1, "568a1d289f13ad3ec20e1d23e80b55b6bfd0dff001c86d29697ab5aaa84ce1c5")

