-- Lua provided by RyzenAPI
-- Game: Impaler Gold

-- MAIN APPLICATION
addappid(1573090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573091, 1, "568a1d289f13ad3ec20e1d23e80b55b6bfd0dff001c86d29697ab5aaa84ce1c5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
