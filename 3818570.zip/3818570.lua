-- Lua provided by RyzenAPI
-- Game: Game: ANOVILL

-- MAIN APPLICATION
addappid(3818570)
-- Game: addappid(3818570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3818571, 1, "6d35cac187ca5650b54b904b684f77d36dbb83e05f5a17f240a7cd95f09de489")
