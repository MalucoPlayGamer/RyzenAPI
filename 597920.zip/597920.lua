-- Lua provided by RyzenAPI
-- Game: 597920

-- MAIN APPLICATION
addappid(597920)
-- Game: addappid(597920)

-- MAIN APP DEPOTS / PACKAGES
addappid(597922,0,"6ac672612975ffcffec76917b12b4c98c9dabfd304b6ce98c9c153fb4158d1b3")
