-- Lua provided by RyzenAPI
-- Game: 1631470

-- MAIN APPLICATION
addappid(1631470)
-- Game: addappid(1631470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631471, 1, "8b00ecf62bfe27a6bcabe7faf4de530264e9a53e43636774ef84f6d091c750d9")
