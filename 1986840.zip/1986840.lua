-- Lua provided by RyzenAPI
-- Game: POPGOES Arcade

-- MAIN APPLICATION
addappid(1986840)
-- Game: addappid(1986840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986841, 1, "557f28af3c981358be0844c5fcd743a3dd0979871a79e65e8be1e63f9c6cc3c8")
