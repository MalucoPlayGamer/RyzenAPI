-- Lua provided by RyzenAPI
-- Game: Syren and Friends Roast the Dev

-- MAIN APPLICATION
addappid(2229710)
addappid(2244870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229711, 1, "1fa126d8ee3c29684c6db9d615b314877a23378258fba334d750ac02d9ed2099")

