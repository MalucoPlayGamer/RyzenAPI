-- Lua provided by RyzenAPI
-- Game: Outbreak: Endless Nightmares

-- MAIN APPLICATION
addappid(1419350)
-- Game: addappid(1419350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419351, 1, "096a87a9df1e9f5c975953230b12a30770e32c6fbd3d10727a3b06270b9ff281")
