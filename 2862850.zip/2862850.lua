-- Lua provided by RyzenAPI 
-- Game: The Vault
addappid(2862850)
addappid(2862851, 1, "bf4e4d63dd02224c4ee478faa594581837f2ccb7d9b06be050f3da3d0b2a518c")
