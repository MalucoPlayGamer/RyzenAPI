-- Lua provided by RyzenAPI
-- Game: 978700

-- MAIN APPLICATION
addappid(978700)
-- Game: addappid(978700)

-- MAIN APP DEPOTS / PACKAGES
addappid(978701, 1, "4290fb7a1b8052d72144301aaa7b54e568479c8e8a4834ca4cbbc87a673e3607")
