-- Lua provided by RyzenAPI
-- Game: 860320

-- MAIN APPLICATION
addappid(860320)
addappid(860321)
addappid(860322)
addappid(860323)
addappid(860324)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987,0,"cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229006,0,"9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416")

