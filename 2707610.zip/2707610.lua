-- Lua provided by RyzenAPI
-- Game: 2707610

-- MAIN APPLICATION
addappid(2707610)
-- Game: addappid(2707610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707611, 1, "8570b35a943ec27cf2de23ae8c7ea5dd3876e93a36b2f956d50472fa8b51d494")
