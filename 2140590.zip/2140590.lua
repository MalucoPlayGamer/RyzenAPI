-- Lua provided by RyzenAPI
-- Game: Cat and Watermouse

-- MAIN APPLICATION
addappid(2140590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140591, 1, "f0e962c51ab2f5b22d6a209fb9f8f87fec83ac58c660dcc5ee9916bf597eefe4")

