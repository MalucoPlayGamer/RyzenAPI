-- Lua provided by RyzenAPI
-- Game: 1689270

-- MAIN APPLICATION
addappid(1689270)
-- Game: addappid(1689270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689271, 1, "c9d68d8715040e022a47f9c44ac56caf5df7da9fb478b68415872b0a42d6772e")
