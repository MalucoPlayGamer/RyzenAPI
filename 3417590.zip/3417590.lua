-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Space Marine 2 - Public Test Server

-- MAIN APPLICATION
addappid(3417590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3417591, 1, "42a49390692e48d8a48bcab455299be83c420d3a83361842202b92430aac3fae")

