-- Lua provided by RyzenAPI
-- Game: Game: AppID 3417590

-- MAIN APPLICATION
addappid(3417590)
-- Game: addappid(3417590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3417591, 1, "42a49390692e48d8a48bcab455299be83c420d3a83361842202b92430aac3fae")
