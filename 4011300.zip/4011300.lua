-- Lua provided by RyzenAPI
-- Game: Super Shout Showdown

-- MAIN APPLICATION
addappid(4011300)

-- MAIN APP DEPOTS / PACKAGES
addappid(4011301,0,"1f0704a67edc01355a39a2ca648c6643dd8cbe73fc0eb718c496db5aa8d9686a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
