-- Lua provided by RyzenAPI 
-- Game: AppID 1051840
addappid(1051840)
addappid(1051841, 1, "b1d2b53817e9ac6c1cc10936eb1df62d2b942c9bbd8988f478ef779a98d89877")
