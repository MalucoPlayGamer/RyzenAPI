-- Lua provided by RyzenAPI
-- Game: 69 Ways to Kill a Zombie

-- MAIN APPLICATION
addappid(512410)

-- MAIN APP DEPOTS / PACKAGES
addappid(512411, 1, "edd4c7a4b356b3f0aca717dc8326db13143d9ac185ffd47ac949bf567f080a08")

