-- Lua provided by RyzenAPI
-- Game: AppID 512410

-- MAIN APPLICATION
addappid(512410)
-- Game: addappid(512410)

-- MAIN APP DEPOTS / PACKAGES
addappid(512411, 1, "edd4c7a4b356b3f0aca717dc8326db13143d9ac185ffd47ac949bf567f080a08")
