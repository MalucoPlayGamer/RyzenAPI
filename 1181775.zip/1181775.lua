-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1181775)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181775,0,"d8765c7f5608cdd4ec398d1325efa4d3bbf2c6406e6a12054ace256bf65d6d85")

