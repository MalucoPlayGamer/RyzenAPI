-- Lua provided by RyzenAPI
-- Game: Siege of Avalon: Anthology

-- MAIN APPLICATION
addappid(1558990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558991, 1, "d8704ed32353e348366d1e6b3f5f58b2225ef330977b4ee7fc69041af273720e")
