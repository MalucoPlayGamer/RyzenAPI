-- Lua provided by RyzenAPI
-- Game: addappid(2266930)

-- MAIN APPLICATION
addappid(2266930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266931, 1, "b5dbd6a3aec432f7b0fad20c481860a8fb173bd496251d12164fc24b1d92d591")
