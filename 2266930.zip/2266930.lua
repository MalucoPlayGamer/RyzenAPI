-- Lua provided by RyzenAPI
-- Game: RUSLICSTAN INVADES

-- MAIN APPLICATION
addappid(2266930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266931, 1, "b5dbd6a3aec432f7b0fad20c481860a8fb173bd496251d12164fc24b1d92d591")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2286130)
addappid(2286140)
addappid(2286150)
addappid(2286160)
