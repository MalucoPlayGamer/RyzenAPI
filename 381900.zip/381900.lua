-- Lua provided by RyzenAPI
-- Game: Bard's Gold

-- MAIN APPLICATION
addappid(381900)

-- MAIN APP DEPOTS / PACKAGES
addappid(381901, 1, "18ef1653be6d8a021633001947a52c1de46c798610fd1152e1e18e57d68adb9a")
addappid(395060, 0, "b5c85746f674a715e2d12b1bc77b30f9f7e379c2fe75dd2caabc68f67b2ae786")
