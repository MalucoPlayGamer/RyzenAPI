-- Lua provided by SkyAPI 
-- Game: Molecular Warfare
addappid(2345410)
addappid(2345411, 1, "ab3c316e3877e4cbcf739b830289d20e4dc22429d1c5f22f285c3d30550dd797")
