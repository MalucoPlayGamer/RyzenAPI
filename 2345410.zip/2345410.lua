-- Lua provided by RyzenAPI
-- Game: Molecular Warfare

-- MAIN APPLICATION
addappid(2345410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2345411, 1, "ab3c316e3877e4cbcf739b830289d20e4dc22429d1c5f22f285c3d30550dd797")

