-- Lua provided by RyzenAPI
-- Game: 1142250

-- MAIN APPLICATION
addappid(1142250)
-- Game: addappid(1142250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142250,0,"e42e3d6fff86f95346c6909bae32982b0dba75da205a8d45f8e29e24169a708d")
