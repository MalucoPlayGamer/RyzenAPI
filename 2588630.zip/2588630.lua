-- Lua provided by RyzenAPI
-- Game: 2588630

-- MAIN APPLICATION
addappid(2588630)
-- Game: addappid(2588630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588631, 1, "35f6140e87c1ab91f764c4e48ecaaaacf49eb1dc26a315d8863036f26a44e18b")
