-- Lua provided by RyzenAPI
-- Game: Virtual Touch Screen 2

-- MAIN APPLICATION
addappid(2588630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2588631, 1, "35f6140e87c1ab91f764c4e48ecaaaacf49eb1dc26a315d8863036f26a44e18b")

