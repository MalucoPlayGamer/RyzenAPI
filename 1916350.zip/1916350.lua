-- Lua provided by RyzenAPI
-- Game: Lord of the Click 3

-- MAIN APPLICATION
addappid(1916350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916351, 1, "d6a3cbe0cdbe0117a4080a44899d870cccf71aa94e5fb81d73cbbaefcd1752dd")
