-- Lua provided by RyzenAPI
-- Game: 2541780

-- MAIN APPLICATION
addappid(2541780)
-- Game: addappid(2541780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541781, 1, "4cbf0f299add2bda4fa9d245a949dbeca87ee67081f1a11fbce9b436602608c9")
