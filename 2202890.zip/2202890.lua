-- Lua provided by RyzenAPI
-- Game: addappid(2202890)

-- MAIN APPLICATION
addappid(2202890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202891, 1, "32a398b9b7d89fa7fdac3a315aabde974f26edbbfd893629fe1ca3cb0f2cfe31")
