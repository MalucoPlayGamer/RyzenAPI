-- Lua provided by RyzenAPI
-- Game: addappid(236690)

-- MAIN APPLICATION
addappid(236690)
addappid(382210)
addappid(382910)
addappid(401590)
addappid(497170)
addappid(523980)
addappid(547570)
addappid(571760)
addappid(571761)
addappid(672830)
addappid(686390)
addappid(686400)
addappid(686401)
addappid(686402)
addappid(686403)
addappid(686404)
addappid(686405)
addappid(686410)
addappid(1300450)

-- MAIN APP DEPOTS / PACKAGES
addappid(236691, 1, "61c2f0d53906659f0c4ee6278cef5c599082f1550bf768f52fb2b861fc13dcd8")
addappid(236694, 1, "bef4ba4a84dcaa070b1134eb1e9f1076c413c79634ac8dcc377ff4a516abb3bf")
addappid(236699, 1, "8dd56102eaae803ff7beae526ee0218ae895439fb658b5862a389fe0a8293738")
