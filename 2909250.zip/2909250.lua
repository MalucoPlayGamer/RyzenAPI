-- Lua provided by RyzenAPI
-- Game: addappid(2909250)

-- MAIN APPLICATION
addappid(2909250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909251, 1, "f883f5f06088a50f05f065d462cce2d5242df1136bb5fe63cc597cbd9541f2a7")
