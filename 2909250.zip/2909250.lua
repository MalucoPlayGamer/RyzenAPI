-- Lua provided by RyzenAPI 
-- Game: Extreme Climbing
addappid(2909250)
addappid(2909251, 1, "f883f5f06088a50f05f065d462cce2d5242df1136bb5fe63cc597cbd9541f2a7")
