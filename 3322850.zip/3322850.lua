-- Lua provided by RyzenAPI
-- Game: The Maze Survivor : First Entrants（Demo）

-- MAIN APPLICATION
addappid(3322850)
-- Game: addappid(3322850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3322851, 1, "b792a12fd8f5dd2dbf4869fc35f5f197c762727bd24979eac50ecf50209c9120")
