-- Lua provided by RyzenAPI
-- Game: Thief Simulator 2 Playtest

-- MAIN APPLICATION
addappid(1838590)
-- Game: addappid(1838590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838591, 1, "d2f9745bb73243fae29eafabc56bd89597a17e929ac5b1b65ab126277ee3cfa9")
