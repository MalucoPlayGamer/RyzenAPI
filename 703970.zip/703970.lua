-- Lua provided by RyzenAPI
-- Game: Protoball

-- MAIN APPLICATION
addappid(703970)

-- MAIN APP DEPOTS / PACKAGES
addappid(703971, 1, "8c5b75567a9ad439c5cb301f9fd22ca7f1eb67a18dcfed9bf5533937bed9d4d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
