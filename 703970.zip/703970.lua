-- Lua provided by SkyAPI 
-- Game: Protoball
addappid(703970)
addappid(703971, 1, "8c5b75567a9ad439c5cb301f9fd22ca7f1eb67a18dcfed9bf5533937bed9d4d6")
