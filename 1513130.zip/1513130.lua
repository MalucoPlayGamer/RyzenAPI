-- Lua provided by RyzenAPI
-- Game: No Lights

-- MAIN APPLICATION
addappid(1513130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513132,0,"bf2eac73dc626d1b437c510f187e79bf645e75b5e7240101bb985e5f2502a4da")

