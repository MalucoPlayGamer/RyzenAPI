-- Lua provided by RyzenAPI
-- Game: 3414900

-- MAIN APPLICATION
addappid(3414900)
-- Game: addappid(3414900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3414901, 1, "5382aa99fbfbdbd57ba0f6f4e2712b758e105d3d4027cbbf11849f5e51d32c3c")
