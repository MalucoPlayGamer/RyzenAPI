-- Lua provided by RyzenAPI
-- Game: AppID 2160360

-- MAIN APPLICATION
addappid(2160360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2160361, 1, "f1029594a120fb8078939333144ab729beb373172aea281161fadd67cd468948")
addappid(2160362, 1, "2ae0974121e9a1fb78e430522013c6232ce83130170c721e556e923be969a1f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
