-- Lua provided by RyzenAPI
-- Game: MyDestinyGirls Demo

-- MAIN APPLICATION
addappid(2821170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2821171, 1, "81b016150cab71ce60e693dd64c6564106d550faeeb17aa520a99f8ae3e82335")
