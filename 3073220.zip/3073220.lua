-- Lua provided by RyzenAPI
-- Game: Deliberate

-- MAIN APPLICATION
addappid(3073220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073221, 1, "cc68bb7fa471bb7413feec540c9b1edae87cf9785289f1315d5cba61abbee688")

