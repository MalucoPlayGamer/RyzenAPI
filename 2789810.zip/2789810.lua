-- Lua provided by RyzenAPI
-- Game: Bingle Bingle

-- MAIN APPLICATION
addappid(2789810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2789811, 1, "002724066244a2381b8b12443996109cedc61069d1d31d8af57e1bf3edd10139")
