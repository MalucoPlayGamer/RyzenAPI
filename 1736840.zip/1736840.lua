-- Lua provided by RyzenAPI
-- Game: 1736840

-- MAIN APPLICATION
addappid(1736840)
-- Game: addappid(1736840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736841, 1, "1f2c2fc296278d787ededa83168dda86b6d6edf755a71c63b47a2dbd395dfa9b")
