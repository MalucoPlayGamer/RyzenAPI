-- Lua provided by RyzenAPI
-- Game: Juice Galaxy Soundtrack Volume 1

-- MAIN APPLICATION
addappid(2590590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2590593,0,"78418653908b05363772967cb31c2b1e7b108fb341187ac22ebdb6d85a8de983")
