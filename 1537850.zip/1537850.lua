-- Lua provided by RyzenAPI
-- Game: Smart Moves 2

-- MAIN APPLICATION
addappid(1537850)
-- Game: addappid(1537850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537851, 1, "d068be811322b711cf5a5458b19b9736b8aaa5f94d6e641e2276ef6fa7f26976")
