-- Lua provided by RyzenAPI
-- Game: Summon

-- MAIN APPLICATION
addappid(2555320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555321, 1, "87ac54e6035b1667b18054e619f46f1fce93611de2b69c7fe452a02afc314674")
