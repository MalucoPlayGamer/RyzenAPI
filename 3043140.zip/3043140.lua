-- Lua provided by RyzenAPI
-- Game: 3043140

-- MAIN APPLICATION
addappid(3043140)
-- Game: addappid(3043140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043141, 1, "44b1253cee876189cdeae31ee5e73da701d45f83dd34e04859733b9f3701366f")
