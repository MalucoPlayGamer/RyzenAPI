-- Lua provided by SkyAPI 
-- Game: Ghost
addappid(3043140)
addappid(3043141, 1, "44b1253cee876189cdeae31ee5e73da701d45f83dd34e04859733b9f3701366f")
