-- Lua provided by RyzenAPI
-- Game: Game: ARCADE GAME SERIES: GALAGA

-- MAIN APPLICATION
addappid(403430)
-- Game: addappid(403430)

-- MAIN APP DEPOTS / PACKAGES
addappid(403431, 1, "d4a00bd1e971c824d7ca2980fe03baf3a2b3f82e3fb83a1fad4afea08993a2ce")
