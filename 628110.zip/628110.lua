-- Lua provided by RyzenAPI
-- Game: AppID 628110

-- MAIN APPLICATION
addappid(628110)

-- MAIN APP DEPOTS / PACKAGES
addappid(628111, 1, "8e3547b81bb75a6cc63337f818422a22dca0b6cb09afecfc81c7fc721fdcedf0")

