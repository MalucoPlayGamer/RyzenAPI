-- Lua provided by RyzenAPI
-- Game: addappid(1107060)

-- MAIN APPLICATION
addappid(1107060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107065,0,"244914a073790822df8c61d52daaf2da5e233288aac4cce6d8433f1bb42063ab")
