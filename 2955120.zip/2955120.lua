-- Lua provided by RyzenAPI
-- Game: 2955120

-- MAIN APPLICATION
addappid(2955120)
-- Game: addappid(2955120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955122,0,"759e9cd04c71e2c1c567c3d3c4a4ef01e06a51a1e93dd341eca23606d0a9f821")
