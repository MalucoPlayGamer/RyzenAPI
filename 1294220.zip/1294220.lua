-- Lua provided by RyzenAPI
-- Game: 1294220

-- MAIN APPLICATION
addappid(1294220)
-- Game: addappid(1294220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1294221, 1, "9ba375f3deaad5a423976b921557ad7209d8c9fcb7618b1525a0cf41cf2f8093")
