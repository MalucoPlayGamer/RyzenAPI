-- Lua provided by RyzenAPI
-- Game: Quest Hunter

-- MAIN APPLICATION
addappid(487000)

-- MAIN APP DEPOTS / PACKAGES
addappid(487001, 1, "0eee28a68c6c5f37cb8218918c26c2c9b1ee45d7f7cccb0ece2ad58ff0def28b")
addappid(487002, 1, "5f769e7594723b0a94f9e7d0c141cc1a01d978e81cb21dd34191245a2d6c9a1b")
addappid(487003, 1, "5d05dddbfa8504e7e8e98f8b0e6106b3661206c9f23975ed18c77e5be700bd23")
addappid(487004, 1, "fa46c2be4bce6763f4f57605440f9e085eee24fb24246a62b1651d838a8d89f5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(793340)
addappid(1851540)
