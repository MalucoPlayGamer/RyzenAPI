-- Lua provided by RyzenAPI
-- Game: Ze VR

-- MAIN APPLICATION
addappid(574220)

-- MAIN APP DEPOTS / PACKAGES
addappid(574221, 1, "f4a3aa98f3a44cd2420529f45daa9dcf56f015e89ac04a45779963be3ecc19d2")
