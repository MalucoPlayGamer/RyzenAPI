-- Lua provided by RyzenAPI
-- Game: Elves vs Goblins Defender

-- MAIN APPLICATION
addappid(516740)

-- MAIN APP DEPOTS / PACKAGES
addappid(516741,0,"405f2077e0bc0f0d5a2d5f54e6664c2c428a4a1e50f4c0280a67ea0dbc6ce794")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
