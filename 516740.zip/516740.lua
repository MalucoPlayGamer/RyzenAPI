-- Lua provided by RyzenAPI
-- Game: Elves vs Goblins Defender

-- MAIN APPLICATION
addappid(516740)

-- MAIN APP DEPOTS / PACKAGES
addappid(516741,0,"405f2077e0bc0f0d5a2d5f54e6664c2c428a4a1e50f4c0280a67ea0dbc6ce794")

