-- Lua provided by RyzenAPI
-- Game: Happy World

-- MAIN APPLICATION
addappid(1079890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1079891, 1, "17751f28fd2b1933b5223dd08d888f741cf68cc617c15060273e947c4257297f")
