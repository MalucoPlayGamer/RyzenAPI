-- Lua provided by RyzenAPI 
-- Game: AppID 1079890
addappid(1079890)
addappid(1079891, 1, "17751f28fd2b1933b5223dd08d888f741cf68cc617c15060273e947c4257297f")
