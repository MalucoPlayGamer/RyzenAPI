-- Lua provided by RyzenAPI
-- Game: Game: AppID 749830

-- MAIN APPLICATION
addappid(749830)
-- Game: addappid(749830)

-- MAIN APP DEPOTS / PACKAGES
addappid(749831, 1, "34bdc2b3fd67e798d3cb06695d849b55e3cdae96d713a1397db31e6c37073849")
addappid(749832, 1, "703ba909651c44d3613f852b0caa18fcb0ee1ed7d05718a183815b276b6d15b2")
