-- Lua provided by RyzenAPI
-- Game: RETRO – Expansion Pack for RACE 07

-- MAIN APPLICATION
addappid(44660)

-- MAIN APP DEPOTS / PACKAGES
addappid(44661, 1, "e553ded92e64d120156acfde41a3d7dd06ccf59bd679ad28c1c82ce814155683")
