-- Lua provided by SkyAPI 
-- Game: The Forgotten Ones
addappid(314280)
addappid(314281, 1, "582bd05865347ecf7fe5cb6ae8299680bd07c5d58cbacbe1f5b1aea626fbd783")
addappid(314282, 1, "354f90434a352392eab2db9b8f884cdb16afbd588a63abd3ca0e35b28e44ae40")
addappid(314283, 1, "b41acdc710d93a163734d569a2c3aff8c784a2a30673488841f2493402e8c0b1")
addappid(314284, 1, "e3f67e5816368559d89be3ce37fd0d67ba7020dc81ddc3e754d1d35160013a92")
