-- Lua provided by RyzenAPI
-- Game: A Trip to Yugoslavia: Director's Cut

-- MAIN APPLICATION
addappid(545410)

-- MAIN APP DEPOTS / PACKAGES
addappid(545411, 1, "783495255cd76f85a24d8fab5948adeb76e75de4f58ffe3c8286197c6c8b9c42")
addappid(545412, 1, "ddf3dd838a23567a06ec704cb135f8b23d8e90e7e89479dd320b446f009938e5")
addappid(545413, 1, "19a2c415ab6f5ff4bedd9742e661c8bf8176693850ee1dd1135ff28670b1b310")
