-- Lua provided by RyzenAPI
-- Game: Athletics Games VR

-- MAIN APPLICATION
addappid(1029660)
addappid(1029661)
addappid(1029662)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029663,0,"876c47eb0730d976fef64274ab1356bcea8f617111be6397c0b00fab738c9440")

