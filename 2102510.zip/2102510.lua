-- Lua provided by RyzenAPI 
-- Game: Pagui soundtrack album#4-The Beginning of The Ending
addappid(2102510)
addappid(2102511, 1, "94594a1532427a662064aa818eeb135bda59b74b3bf67458b3833b2f8d0dbe66")
addappid(2102512, 1, "d68e8d8180d6c423cf2c1381a8dd0c610328b42bba35d19c0b2fb670d31f9e3e")
