-- Lua provided by SkyAPI 
-- Game: Bright Lord
addappid(2906370)
addappid(2906371, 1, "aefc381b5f8e1d6ef23422f8681f983febac8819a4956ae1855ea457d479a416")
addappid(3316070, 0, "c0b8b21be38e98c6b9e12aceb56e5726b5ab65c936856e1984197770ab299986")
