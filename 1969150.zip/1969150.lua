-- Lua provided by RyzenAPI
-- Game: Game: Formula Bwoah: Online Multiplayer Racing

-- MAIN APPLICATION
addappid(1969150)
-- Game: addappid(1969150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969151, 1, "61e1e341fd79f84ead802451c2b3d29fc0d922f93036a1bef52fa1868544209f")
