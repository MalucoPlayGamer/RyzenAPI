-- Lua provided by SkyAPI 
-- Game: AppID 1685030
addappid(1685030)
addappid(1685031, 1, "e0bae8e2d64140bba5ba82d058bb5ff584e57d200d6645c600c7bc319e0c1a3e")
