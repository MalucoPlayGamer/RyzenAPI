-- Lua provided by RyzenAPI
-- Game: Game: AppID 2389310

-- MAIN APPLICATION
addappid(2389310)
-- Game: addappid(2389310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389311, 1, "c4eb8d37bada04f97694177cb57bb7854319e8316e9bcc34510801799fd25bf9")
