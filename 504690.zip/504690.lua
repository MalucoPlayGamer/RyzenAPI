-- Lua provided by RyzenAPI
-- Game: 504690

-- MAIN APPLICATION
addappid(504690)
-- Game: addappid(504690)

-- MAIN APP DEPOTS / PACKAGES
addappid(504691, 1, "3012e6cba57d80afc46ba1ad7d9bdf61e4c29b3afa314b12506ff7c51049e4d5")
