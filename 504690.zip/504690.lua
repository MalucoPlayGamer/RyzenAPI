-- Lua provided by RyzenAPI
-- Game: Woven

-- MAIN APPLICATION
addappid(504690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(504691, 1, "3012e6cba57d80afc46ba1ad7d9bdf61e4c29b3afa314b12506ff7c51049e4d5")

