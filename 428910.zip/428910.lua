-- Lua provided by SkyAPI 
-- Game: Red Fox and the Four Seasons
addappid(428910)
addappid(428911, 1, "1efc8454c08654abc2fc16a8d2e0b8a248fc14fb4ad298a088fe20e7c6168fed")
addappid(2110260)
addappid(2136040)
addappid(2171620)
