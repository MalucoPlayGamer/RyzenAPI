-- Lua provided by RyzenAPI
-- Game: AppID 1913390

-- MAIN APPLICATION
addappid(1913390)
-- Game: addappid(1913390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1913391, 1, "6e70276aff7f63f4f647a9675147ccf19be144ee9a80f3e7509844c469ce2fcd")
