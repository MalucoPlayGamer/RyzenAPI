-- Lua provided by RyzenAPI
-- Game: Myst

-- MAIN APPLICATION
addappid(1255560)
-- Game: addappid(1255560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255561, 1, "2ffd95ae0859793b901df49c62c092ff41a34ae082001d4239098045ef12109d")
