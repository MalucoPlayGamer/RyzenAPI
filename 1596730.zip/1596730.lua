-- Lua provided by RyzenAPI
-- Game: Game: Dynopunk

-- MAIN APPLICATION
addappid(1596730)
-- Game: addappid(1596730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1596731, 1, "40579ea57de4779b19618183d4c4a24c88852205fc42e44604d2df0aab3793f0")
