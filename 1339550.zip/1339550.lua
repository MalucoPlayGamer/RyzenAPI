-- Lua provided by RyzenAPI
-- Game: Game: Alien Cat 3

-- MAIN APPLICATION
addappid(1339550)
-- Game: addappid(1339550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339551, 1, "4c1ef36d877eae0eca0e5978c1fda8ecb33abcebefb5e372654c44a85bb0543d")
