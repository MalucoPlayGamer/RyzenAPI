-- Lua provided by RyzenAPI
-- Game: Bigfoot Forest

-- MAIN APPLICATION
addappid(1506230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506231, 1, "2f672697c8cef9ffb65446a9909ba3906038a9cd84a808d53347594b12e9f35f")

