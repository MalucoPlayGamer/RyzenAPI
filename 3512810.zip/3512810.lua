-- Lua provided by RyzenAPI
-- Game: 3512810

-- MAIN APPLICATION
addappid(3512810)
-- Game: addappid(3512810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3512811, 1, "9d7af50fde77db64cd23a551865fe92d24737986850d8b48277aeea9b77577c6")
