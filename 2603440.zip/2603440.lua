-- Lua provided by RyzenAPI
-- Game: addappid(2603440)

-- MAIN APPLICATION
addappid(2603440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2603441, 1, "bf8628f46ec16d51f600399fa38540de4001fc32dfec27d2caa5e5f285608391")
