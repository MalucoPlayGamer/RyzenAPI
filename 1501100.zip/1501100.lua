-- Lua provided by RyzenAPI
-- Game: 1501100

-- MAIN APPLICATION
addappid(1501100)
-- Game: addappid(1501100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501101, 1, "0fb867aaac7aad5a65124a184448bda0f5eff01395d4f8931722d5a83a0ea3e8")
