-- Lua provided by SkyAPI 
-- Game: Samurai Aces III: Sengoku Cannon
addappid(1279390)
addappid(1279391, 1, "067391e768c85ee8c6801065cd2faa4620bc7869324e6163fc58beff6afbe64f")
