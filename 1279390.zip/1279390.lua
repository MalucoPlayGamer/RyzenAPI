-- Lua provided by RyzenAPI
-- Game: addappid(1279390)

-- MAIN APPLICATION
addappid(1279390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279391, 1, "067391e768c85ee8c6801065cd2faa4620bc7869324e6163fc58beff6afbe64f")
