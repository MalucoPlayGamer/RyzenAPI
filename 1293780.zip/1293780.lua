-- Lua provided by SkyAPI 
-- Game: AppID 1293780
addappid(1293780)
addappid(1293781, 1, "4df8c2035c40c188c827eb88074958ae36cec662c27684988b88b759b2d5e6f7")
