-- Lua provided by RyzenAPI
-- Game: Game: Love Too Easily

-- MAIN APPLICATION
addappid(2274500)
-- Game: addappid(2274500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274501, 1, "b986dc20992f9850433597ff9a2f0999bfa8fa141f946625d7d63f31c7fff801")
