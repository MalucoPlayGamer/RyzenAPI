-- Lua provided by RyzenAPI
-- Game: My Big Sister: Remastered

-- MAIN APPLICATION
addappid(2118540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118541, 1, "baa6c26c3a875d8b8cc4ce5950fc574f4c2a8d2a8b168971dadac0e14f5a8957")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
