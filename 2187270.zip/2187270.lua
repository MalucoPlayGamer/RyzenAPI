-- Lua provided by RyzenAPI
-- Game: addappid(2187270)

-- MAIN APPLICATION
addappid(2187270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187271, 1, "bea957071631eaa0c2b7b68b4518ac4a8978d69508916450fad93c6dc93181c2")
