-- Lua provided by RyzenAPI
-- Game: Cum & Climb

-- MAIN APPLICATION
addappid(2598300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598301, 1, "8fa317dbd308c9a82b5bda0837b83d9aa209e1d55ce6eb921629410f233cd05f")
