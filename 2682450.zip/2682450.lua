-- Lua provided by RyzenAPI
-- Game: Do Not Press The Button (Or You'll Delete The Multiverse): Prologue

-- MAIN APPLICATION
addappid(2682450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2682451, 1, "86348cd9ae041e72f762ab9f48d6cd27b8176babbe198221911a023ed9414ab7")

