-- Lua provided by RyzenAPI
-- Game: 100 hidden cats 2

-- MAIN APPLICATION
addappid(1679320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679321, 1, "92beb557d10e31cd696c42d66befed438b663af848dba5bb56f3870f697bbd59")

