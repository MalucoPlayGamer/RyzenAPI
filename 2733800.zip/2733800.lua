-- Lua provided by RyzenAPI
-- Game: Game: Bloodhounds

-- MAIN APPLICATION
addappid(2733800)
-- Game: addappid(2733800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733801, 1, "68b84c8bd9f62cb06b3cfb80d6af1b2ed4888901c560876dbde83a6b30212332")
