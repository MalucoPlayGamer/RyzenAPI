-- Lua provided by SkyAPI 
-- Game: Exposed Livestream
addappid(3304770)
addappid(3304771, 1, "eeaca3018316d609d12d4bd90a7de215db16583f924117066441be6c8426f3f5")
addappid(3304773, 1, "92569f4b87fb47f4e004be1245a6619babc7da89b9de531a1ef5e0e9241d80eb")
addappid(3304774, 1, "88d9421f9e08267459aa648ff8747d95980bfd2ef0abfd01dce9b66a72012175")
