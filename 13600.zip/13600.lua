-- Lua provided by RyzenAPI
-- Game: Prince of Persia®: The Sands of Time

-- MAIN APPLICATION
addappid(13600)
-- Game: addappid(13600)

-- MAIN APP DEPOTS / PACKAGES
addappid(13601, 1, "c1219f4917c48071fbec7da890c82e2b07dc3152b52549c69d7a78cf43a456b7")
addappid(13602, 1, "ce4378f684d987d25d05a1388849c71b166e4c23f27b0fea92aac65d2581f5a2")
addappid(13603, 1, "6da03859cded054b5bec5c76bbf25c79cb4edc5d8472200baaeac724878e9daf")
addappid(13604, 1, "b6ce7d8a754852560e3fe4eecef775b4ae55525e0906c0f1365c5f2b3e01a9d0")
addappid(13605, 1, "1bd0bfb456798480557a2ee2a2726150fab0920679cd05f9e8ee9df3cada7b62")
addappid(13606, 1, "5239d2b0fa93c9c55a17498d2264500e7cfdbbd420d184c89535a166a77fc8a6")
