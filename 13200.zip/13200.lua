-- Lua provided by RyzenAPI
-- Game: addappid(13200)

-- MAIN APPLICATION
addappid(13200)

-- MAIN APP DEPOTS / PACKAGES
addappid(13201, 1, "ba23c52b0addb34cc3ab4b57364035061d610dd7375bbaab8a3bdbade397fe50")
addappid(13202, 1, "2ea1ae840072ae7fa487f1540380e701a77e1a853530bc338260836222037846")
