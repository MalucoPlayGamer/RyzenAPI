-- 4558690's Lua and Manifest Created by Hubcap Manifest
-- SkyChart: Airline Executive
-- Created: July 23, 2026 at 12:21:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4558690, 1, "017d1b108c52ade96dcbd77c5efb57c003accbe7bf70b3bb4245c2f52ab225f6") -- SkyChart: Airline Executive
-- MAIN APP DEPOTS
addappid(4558691, 1, "5a5c7bf39dc63d018c30354541e846624f6b25053ea4933880343c482b6d3b41") -- Depot 4558691
setManifestid(4558691, "4961390799115695250", 1244798039)
addappid(4558692, 1, "cb4f16f5a7e4d281f65388bc7fd9801124391c93af4ab35cfb7145a5aeaa042d") -- Depot 4558692
setManifestid(4558692, "4147325565199633286", 913055211)
addappid(4558693, 1, "abbcc350a53ad49601623d27618d3de893e50ada11aee6a7fbf99aab55719a5a") -- Depot 4558693
setManifestid(4558693, "4165431477089326279", 1201316687)