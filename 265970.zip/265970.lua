-- Lua provided by RyzenAPI
-- Game: Game: AppID 265970

-- MAIN APPLICATION
addappid(265970)
addappid(369130)
addappid(369131)
-- Game: addappid(265970)

-- MAIN APP DEPOTS / PACKAGES
addappid(265971, 1, "7ba28768f8ad18ddb92326afe05acf80949375daed5d3fa0c0726db21aef8619")
addappid(265972, 1, "0068fedde25cf339c3d5f3eea13db5a7a4c07338e5f9a108444c5b820094eb7f")
addappid(265973, 1, "361c970a6e98cbce66e5bf7015f21934a8b1ec6179b68bcbb05913ca6d5388b6")
addappid(265975, 1, "12e1278acb358aaa22a30802ac7b6aa7a8153583c6fbb56777f9ceec541c6f3f")
addappid(265976, 1, "eedc423f1e728814ce40af7d4bfa8ca97a27c0d3b344e64f2a3a83889a5f9b66")
