-- Lua provided by RyzenAPI
-- Game: Worlds of Magic

-- MAIN APPLICATION
addappid(265970)
addappid(369130)
addappid(369131)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(265971, 1, "7ba28768f8ad18ddb92326afe05acf80949375daed5d3fa0c0726db21aef8619")
addappid(265972, 1, "0068fedde25cf339c3d5f3eea13db5a7a4c07338e5f9a108444c5b820094eb7f")
addappid(265973, 1, "361c970a6e98cbce66e5bf7015f21934a8b1ec6179b68bcbb05913ca6d5388b6")
addappid(265975, 1, "12e1278acb358aaa22a30802ac7b6aa7a8153583c6fbb56777f9ceec541c6f3f")
addappid(265976, 1, "eedc423f1e728814ce40af7d4bfa8ca97a27c0d3b344e64f2a3a83889a5f9b66")

