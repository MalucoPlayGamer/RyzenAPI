-- Lua provided by RyzenAPI
-- Game: 1368870

-- MAIN APPLICATION
addappid(1368870)
-- Game: addappid(1368870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368871, 1, "a050e43f478502fecce7c44ee48c4c8dd3b48d4a370e64df81ec922e8fa6ff82")
addappid(1368872, 1, "311b34ec5eac1c26afc4d93dacaa5961a4d7c53626c5ba03295cda7c941a9bb5")
