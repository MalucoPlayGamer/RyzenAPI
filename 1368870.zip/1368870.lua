-- Lua provided by RyzenAPI
-- Game: Field of Glory II: Medieval

-- MAIN APPLICATION
addappid(1368870)
addappid(1548770)
addappid(1651570)
addappid(1736340)
addappid(1882110)
addappid(2009600)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1368871, 1, "a050e43f478502fecce7c44ee48c4c8dd3b48d4a370e64df81ec922e8fa6ff82")
addappid(1368872, 1, "311b34ec5eac1c26afc4d93dacaa5961a4d7c53626c5ba03295cda7c941a9bb5")

