-- Lua provided by RyzenAPI
-- Game: AppID 2871810

-- MAIN APPLICATION
addappid(2871810)
-- Game: addappid(2871810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871811, 1, "d4503779e071c9b7dc7369f5ad48106dba10e48defda2f2ad1fcd2c63aa885ae")
