-- Lua provided by RyzenAPI
-- Game: 3075380

-- MAIN APPLICATION
addappid(3075380)
-- Game: addappid(3075380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075383,0,"b3963bf0008b99a5941bce9d2a2e923e455abd6b98c3707f5f55d18024800dec")
