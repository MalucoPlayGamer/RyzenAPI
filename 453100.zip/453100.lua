-- Lua provided by RyzenAPI
-- Game: AppID 453100

-- MAIN APPLICATION
addappid(453100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(453101, 1, "b5251cb4efe93bef038a56bf62916dae1344fc7e38726d6b0c4d04bf018dc8bc")
addappid(453102, 1, "3d4d3d1495727b9b3145ace5be7e2ddbfdbf507ff7a7d93a3f50dc6b57dd2777")
addappid(453103, 1, "b8efb9f3de90719a88c5945626c44544108b1ea5a2aba11e21e392dc3ca9ca84")
addappid(469050, 0, "c5d0c741b29c7c4b7dc4f65625ed718f4ab736d72e22043c41eb42896e21ab93")

