-- Lua provided by RyzenAPI
-- Game: Elimination Games

-- MAIN APPLICATION
addappid(1796440)
-- Game: addappid(1796440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796441, 1, "77abe0696a96236f28b135462c01a2655cacb46631ffe5106dccdc9ec899f60e")
