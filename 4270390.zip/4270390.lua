-- Lua provided by RyzenAPI
-- Game: D1AL-ogue

-- MAIN APPLICATION
addappid(4270390)
