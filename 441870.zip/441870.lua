-- Lua provided by SkyAPI 
-- Game: OutDrive
addappid(441870)
addappid(441871, 1, "7f701f8d17d9b85cdd72940238a7dd11a327ecd59d801295b4e09d83c2c837c0")
addappid(1014290)
addappid(1014300, 0, "62b89b710539230496a056b84d43d95a8dbaac6d20196ad89b48fb336bbf76d7")
