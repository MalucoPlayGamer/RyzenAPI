-- Lua provided by RyzenAPI
-- Game: addappid(569810)

-- MAIN APPLICATION
addappid(569810)

-- MAIN APP DEPOTS / PACKAGES
addappid(569811, 1, "f4cd20cc0e5df4b4dbd58cd91d2650ac49b65dfe72be00bcc06cb7bd0e5356d5")
addappid(569812, 1, "79dc163b9ced5b7afe6dbfcc5cc4c5ebe1d539ab78e6cab9c820734d1c091f02")
addappid(1912370, 0, "e6443dfd18f2f5eac7d54276e4a190d66d80d1844a2b4d55a93d9baaf5f3abb4")
