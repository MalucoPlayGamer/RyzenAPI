-- Lua provided by RyzenAPI
-- Game: Big Bang West

-- MAIN APPLICATION
addappid(1641080)
-- Game: addappid(1641080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641081, 1, "af01586ea55fb2f9dfbd556322adbce3a0d41b9dc3d394d3a7abf35ebd5779e8")
