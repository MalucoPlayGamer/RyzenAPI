-- Lua provided by RyzenAPI
-- Game: Greed 2: Forbidden Experiments

-- MAIN APPLICATION
addappid(1007730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007731, 1, "9d2a5821b6c05caf81978d589306cbad8c7658b28cb64c51d1389cfc3b4805b8")
addappid(1007732, 1, "c742c78b81f862476f6b4e473ce5e1e7fd7d1b2c7fefeb1e5de2e246c8a62da9")
addappid(1007733, 1, "72fa336d220a20b61b0dca5bd1bc39f1f2e73f8af59be15fa10889ea25f1de67")
addappid(1007734, 1, "a7c142d9bddf8a998793bbc2e43773a998283f3d8af4d4710c32ebe5c37faaf5")
addappid(1007735, 1, "449d6685bc6a23fd38f922026629e3c1fb072f296ce11d6bf511c42b4a37cb36")
addappid(1007736, 1, "db11b2b7912c89159f973d468db93c40302eea23987a13ee7a7cd1fcd3ce44a5")
addappid(1007737, 1, "89dfb97b3cc0ce78a91985bd44980ba83c12b3c66f7e971bec787969028b874c")
