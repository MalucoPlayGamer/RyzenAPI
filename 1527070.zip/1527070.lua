-- Lua provided by RyzenAPI
-- Game: Commanding Nations

-- MAIN APPLICATION
addappid(1527070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1527071, 1, "3694e7162e4af44a403cba50f2cbcb54c08a7e477e824e2a5f6799be7e73ed09")

