-- Lua provided by SkyAPI 
-- Game: Smackball
addappid(1554520)
addappid(1554521, 1, "485aaafa641a4ed180554e5bb67708e181c75ea8d69981e14c0f95a14ba39188")
addappid(1554522, 1, "763abaa466fc69bc87f76f483f27c1a497bf92b975bbbb83c7402b2f6522e3d5")
