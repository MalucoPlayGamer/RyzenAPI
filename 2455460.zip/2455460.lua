-- Lua provided by RyzenAPI
-- Game: Milord

-- MAIN APPLICATION
addappid(2455460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455461, 1, "d5502d535c2fcbf54d6e1bdf427c9806526115632afedbbd46bd2674247a5bee")
addappid(2455462, 1, "9c123ded8a0ac75860346e9689d13f3fcc228db729eccd6aa101e944040cf190")

