-- Lua provided by RyzenAPI
-- Game: Ms. Han's After-School Tutoring

-- MAIN APPLICATION
addappid(1520840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520841, 1, "bb1952a207bea2eb208fa1d431bee262d5ab7908ee3e30cff7195d4919da7a70")
