-- Lua provided by RyzenAPI
-- Game: Game: AppID 427880

-- MAIN APPLICATION
addappid(427880)
-- Game: addappid(427880)

-- MAIN APP DEPOTS / PACKAGES
addappid(427881, 1, "a5516332afd73bf6bd0ca198a3f537459879d28832004370d2b740fa942ed7f8")
