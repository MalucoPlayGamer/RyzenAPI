-- Lua provided by RyzenAPI
-- Game: AppID 427880

-- MAIN APPLICATION
addappid(427880)

-- MAIN APP DEPOTS / PACKAGES
addappid(427881, 1, "a5516332afd73bf6bd0ca198a3f537459879d28832004370d2b740fa942ed7f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
