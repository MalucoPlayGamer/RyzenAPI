-- Lua provided by SkyAPI 
-- Game: AppID 427880
addappid(427880)
addappid(427881, 1, "a5516332afd73bf6bd0ca198a3f537459879d28832004370d2b740fa942ed7f8")
