-- Lua provided by RyzenAPI 
-- Game: Beyond the Red Door
addappid(3540100)
addappid(3540101, 1, "65f75c240ec4b34965f2bc19520eb4487f390424851b7ce5af0b6235ea3b0423")
