-- Lua provided by RyzenAPI
-- Game: OMICRON: Coronavirus Battlegrounds

-- MAIN APPLICATION
addappid(1310210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310211, 1, "63179c63438c36b89a2ea037d0c4c430b0148abe3e095a2011c2557b667bb95e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
