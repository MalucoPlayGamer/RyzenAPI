-- Lua provided by SkyAPI 
-- Game: OMICRON: Coronavirus Battlegrounds
addappid(1310210)
addappid(1310211, 1, "63179c63438c36b89a2ea037d0c4c430b0148abe3e095a2011c2557b667bb95e")
