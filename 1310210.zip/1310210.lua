-- Lua provided by RyzenAPI
-- Game: OMICRON: Coronavirus Battlegrounds

-- MAIN APPLICATION
addappid(1310210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310211, 1, "63179c63438c36b89a2ea037d0c4c430b0148abe3e095a2011c2557b667bb95e")

