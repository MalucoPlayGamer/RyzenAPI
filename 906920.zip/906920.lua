-- Lua provided by RyzenAPI
-- Game: Game: Political Puzzle

-- MAIN APPLICATION
addappid(906920)
-- Game: addappid(906920)

-- MAIN APP DEPOTS / PACKAGES
addappid(906921, 1, "c57942ba9bdbbe0ad4775e64cfabe3cc67c43680bf4f01b50b645f0a83ce133d")
