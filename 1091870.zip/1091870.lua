-- Lua provided by RyzenAPI
-- Game: Theropods

-- MAIN APPLICATION
addappid(1091870) -- Theropods

-- MAIN APP DEPOTS / PACKAGES
addappid(1091871, 1, "c09cb94a1e922f4bc2f3a043bad287195f92059332ef70f868b034a62eccc48d") -- Depot 1091871
addappid(1091872, 1, "60eac5ec9e958120b6dd59f0dda25a6415e973077741a3847406454b6ca4b919") -- Depot 1091872
addappid(1091873, 1, "d0faf0a94740c640b5a057fef160dea1491e5da3b9d6256ee8940d9b55666415") -- Depot 1091873

