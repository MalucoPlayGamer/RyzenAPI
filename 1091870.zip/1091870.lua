-- 1091870's Lua and Manifest Created by Hubcap Manifest
-- Theropods
-- Created: August 21, 2026 at 14:09:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1091870) -- Theropods
-- MAIN APP DEPOTS
addappid(1091871, 1, "c09cb94a1e922f4bc2f3a043bad287195f92059332ef70f868b034a62eccc48d") -- Depot 1091871
setManifestid(1091871, "5945104151433814346", 808075574)
addappid(1091872, 1, "60eac5ec9e958120b6dd59f0dda25a6415e973077741a3847406454b6ca4b919") -- Depot 1091872
setManifestid(1091872, "6185194972473182764", 831271339)
addappid(1091873, 1, "d0faf0a94740c640b5a057fef160dea1491e5da3b9d6256ee8940d9b55666415") -- Depot 1091873
setManifestid(1091873, "2729993441264324550", 850186938)