-- Lua provided by RyzenAPI
-- Game: Bushside Rangers

-- MAIN APPLICATION
addappid(3054410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054411, 1, "f3d4245e90daabdf8d1139fd3fc806309720faaf24a60902e2331d579126f314")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
