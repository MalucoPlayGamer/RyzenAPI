-- Lua provided by RyzenAPI
-- Game: Bushside Rangers

-- MAIN APPLICATION
addappid(3054410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3054411, 1, "f3d4245e90daabdf8d1139fd3fc806309720faaf24a60902e2331d579126f314")

