-- Lua provided by RyzenAPI
-- Game: Tiny Pixels Vol. 2 - Stormy Knights

-- MAIN APPLICATION
addappid(3078670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078671, 1, "0d3f8676931eeec95db4d61564768da496e6bc8eb473a35538566c6264cc7b96")

