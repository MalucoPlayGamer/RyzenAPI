-- Lua provided by RyzenAPI
-- Game: Brave Princess Milia

-- MAIN APPLICATION
addappid(1828950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828951, 1, "dc4bdc73e25940a4fd79cbdf36e223e2960099d13c0c37a12de4f6d2f9158bb4")
addappid(1828952, 1, "1ff75c12f51c25f92f24d87cc2a627714d9bf14081854827bfd440ed1943ea54")

