-- Lua provided by RyzenAPI
-- Game: 408520

-- MAIN APPLICATION
addappid(228986)
addappid(408520)
-- Game: addappid(408520)

-- MAIN APP DEPOTS / PACKAGES
addappid(408522,0,"6fe5ba4b86f98ea1b0f125271cc5ecb7585a1ec5f8fa4d8be4f909f9c72d6a7c")
addappid(682980,0,"035752b099d7e082913dcded7e56cde9dd2739a51d706326d5a5ff83b79cf56b")
