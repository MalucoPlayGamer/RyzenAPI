-- Lua provided by SkyAPI 
-- Game: Wild Woods
addappid(1975580)
addappid(1975581, 1, "fec9e2c7c0e862b3d9ba1e206ec959822e7b9df92d97baa5661f3ea091a61b4f")
addappid(3311820, 0, "be93993211fe89782eb1ad7a4d746318d3477690d6c903de8d5c8a6b75cf1725")
