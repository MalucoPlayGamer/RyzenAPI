-- Lua provided by RyzenAPI
-- Game: Contradiction: Spot The Liar

-- MAIN APPLICATION
addappid(373390)
-- Game: addappid(373390)

-- MAIN APP DEPOTS / PACKAGES
addappid(373392,0,"47ad9eb0c1b672cbd6282c3b79eb9c84fd85d770ee1a07f63c2048f62e01e343")
addappid(373393,0,"658711e375a311fb077bed869b964cfbf5bf88f1ab124f972f13f971e7cd6a5a")
