-- Lua provided by RyzenAPI
-- Game: AppID 542430

-- MAIN APPLICATION
addappid(542430)

-- MAIN APP DEPOTS / PACKAGES
addappid(542431, 1, "5eff571e4bd35408015ebe7ce39b8ba8031eb6cf69f106892598a31a4ec8a87e")
