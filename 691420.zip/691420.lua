-- Lua provided by RyzenAPI
-- Game: addappid(691420)

-- MAIN APPLICATION
addappid(691420)

-- MAIN APP DEPOTS / PACKAGES
addappid(691421, 1, "268d7e1de4ad3c67562b761a7ab07242b6f6e1971942235376d731bbed2f0860")
