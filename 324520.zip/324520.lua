-- Lua provided by RyzenAPI
-- Game: Defense Zone 3 Ultra HD

-- MAIN APPLICATION
addappid(324520)
-- Game: addappid(324520)

-- MAIN APP DEPOTS / PACKAGES
addappid(324521, 1, "bc3fbec30a03a8f8e9fc0a991cc9279a0e4c4c2fc9e39e36bbf69440ea6ec0eb")
