-- Lua provided by RyzenAPI
-- Game: Oknytt

-- MAIN APPLICATION
addappid(286320)
-- Game: addappid(286320)

-- MAIN APP DEPOTS / PACKAGES
addappid(286321, 1, "7fc36aa9772bdf71b9fb199477b4ca39cd3cef0949f846ae653fa6d00d599b90")
