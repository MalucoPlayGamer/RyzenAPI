-- Lua provided by RyzenAPI
-- Game: Revenge of the Boxer: Moscow Criminality

-- MAIN APPLICATION
addappid(3061900)
addappid(3553530)
-- Game: addappid(3061900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3061901, 1, "2338de4ed6027980e862a4e69012a7ef24ac85d13b3bd6aa3c527079a85f3de3")
addappid(3061902, 1, "e67dbc1e30a4a3da23a02564946b11f728525643cec385e04e6eb09d6f41eeb1")
