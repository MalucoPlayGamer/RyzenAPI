-- Lua provided by RyzenAPI
-- Game: After The War

-- MAIN APPLICATION
addappid(1385190)
-- Game: addappid(1385190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385191, 1, "2e53fc8a1476f332abbe59b0b860f3751134a6ea207184914174d6ffd0b6c194")
