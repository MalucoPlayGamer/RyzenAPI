-- Lua provided by RyzenAPI
-- Game: Phoenix Force

-- MAIN APPLICATION
addappid(332480)
-- Game: addappid(332480)

-- MAIN APP DEPOTS / PACKAGES
addappid(332481, 1, "20ee43010fc522de4701674f8a9f4915544d65feecb75a577f0bc39d2c19ce4b")
