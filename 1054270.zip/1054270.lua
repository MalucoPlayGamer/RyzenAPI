-- Lua provided by RyzenAPI
-- Game: RASHLANDER

-- MAIN APPLICATION
addappid(1054270)
-- Game: addappid(1054270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054271, 1, "df3454f4d009c905fb085e23546c8af2f3a9efe3ebcbea6d0a4b85450243a7f8")
