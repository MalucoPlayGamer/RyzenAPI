-- Lua provided by SkyAPI 
-- Game: RASHLANDER
addappid(1054270)
addappid(1054271, 1, "df3454f4d009c905fb085e23546c8af2f3a9efe3ebcbea6d0a4b85450243a7f8")
