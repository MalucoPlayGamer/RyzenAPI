-- Lua provided by RyzenAPI
-- Game: 765430

-- MAIN APPLICATION
addappid(765430)
-- Game: addappid(765430)

-- MAIN APP DEPOTS / PACKAGES
addappid(765430,0,"a0b8a9f69f8afee39e98a83fceab992a048e4ab23b641507761ad912f2fc5df6")
