-- Lua provided by RyzenAPI
-- Game: The First Descendant

-- MAIN APPLICATION
addappid(2074920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2074921, 1, "7b71a400e55a9f6781b1a47daa3ea3754b321c2fee535fbe882be8233fe557b3")

