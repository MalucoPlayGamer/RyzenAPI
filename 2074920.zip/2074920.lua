-- Lua provided by RyzenAPI
-- Game: The First Descendant

-- MAIN APPLICATION
addappid(2074920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074921, 1, "7b71a400e55a9f6781b1a47daa3ea3754b321c2fee535fbe882be8233fe557b3")

