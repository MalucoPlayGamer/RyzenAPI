-- Lua provided by RyzenAPI
-- Game: Leaf Blower Man: This Game Blows!

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(229004)
addappid(229005)
addappid(229006)
addappid(2212110)
addappid(2212111)
addappid(2498050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2212112,0,"c4525a06498401ac8321983c08749a48b05501e66f368b6d1ee67166a9282af4")
addappid(2212113,0,"c292563bfe504f8daac6639a7b98c2d56490b5287631f1af59c1eb4e7eaa336d")
addappid(2212114,0,"68e517a5a39e1bb26f7dd894e4ddff8807abd6ee84e5214fcde605cc9c33debd")
