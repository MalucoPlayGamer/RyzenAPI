-- Lua provided by RyzenAPI
-- Game: Surmount Demo

-- MAIN APPLICATION
addappid(2424590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424591, 1, "ca49594e8fbd15c2c99ec2621d7e1fea6035e19e334193bf8e4973999cdef532")

