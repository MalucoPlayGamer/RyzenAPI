-- Lua provided by RyzenAPI
-- Game: 99 Waves to Die

-- MAIN APPLICATION
addappid(360600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(360601, 1, "f7bc73df15f2977674129706f329fd4d64fe05a80e6c684be795567c661ec246")
addappid(360602, 1, "ce3fea5e4717ec58f0be042803dc9c21ef113167d7ee91429f8bcf58c8825955")
addappid(360603, 1, "e13ad5eb588426df0446e930eaf152a3b7be259fd7d24043df6f19f648ff9dec")