-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1376370)
addappid(1376371)
addappid(1379390)
addappid(1381170)
addappid(1384100)
-- Game: addappid(1376370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377220,0,"cdf26df3b37fa4b35689dfb57e3de37b7c8d854a7ef8b5515f1fbac8e4ff6991")
addappid(1380140,0,"0fbe32df20b9a4b63cb78a8315ad147824ac10fca35da30a5679e9104b6fc3c3")
