-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV - The Demon's Dark Castle: Explorative-Platformer Resource Pack

-- MAIN APPLICATION
addappid(2052421)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052421,0,"25c0a19203d8f83559a577ac7047afed86bec51aa6601fd25671321622202d68")

