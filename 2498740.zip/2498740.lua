-- Lua provided by RyzenAPI
-- Game: 2498740

-- MAIN APPLICATION
addappid(2498740)
-- Game: addappid(2498740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498741, 1, "1577b40b63b9218dc387f8d83263503082a35ee67dce91a29d370e28f2da7ef2")
