-- Lua provided by RyzenAPI
-- Game: Game: 玉言·离光

-- MAIN APPLICATION
addappid(1537480)
-- Game: addappid(1537480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537481, 1, "26844c291d66b5e59a164b02f84cb5b3e188545b7c1c5e7c3f75b002969d8411")
