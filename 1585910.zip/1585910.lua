-- Lua provided by RyzenAPI
-- Game: Game: Roll

-- MAIN APPLICATION
addappid(1585910)
-- Game: addappid(1585910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585911, 1, "a1607e661dfd48f06ea11c17573e67452c6f2efd277926e042dd1656047f61c4")
