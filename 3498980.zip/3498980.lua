-- Lua provided by RyzenAPI
-- Game: M.I.A.: Mission in Asia

-- MAIN APPLICATION
addappid(3498980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3498981, 1, "d95956b744a59f7d29bce2271703468388ca2bc780e7d08e4fdf7642096399ff")
addappid(3498982, 1, "298e9dc7f27b34943cd526563cbc9e0e67e323823ee0a29c46bc00ba932b83c9")

