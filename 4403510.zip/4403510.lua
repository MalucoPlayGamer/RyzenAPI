-- Lua provided by RyzenAPI
-- Game: Sensory Overload

-- MAIN APP DEPOTS / PACKAGES
addappid(4403510, 1, "80ae03364d57853ee84f881ee5d003e733ac41f030b61895acc36b771c156bbd") -- Sensory Overload
addappid(4403511, 1, "83f10cc5e0abcdfd8179c211cc7dd5b82443b051ec367b6df477aa15493ed456") -- Depot 4403511
addappid(4403513, 1, "81362aab3a181f002cec7bc9a130f73d89fa3791a7e84d9ff40cd56f9340b721") -- Depot 4403513

