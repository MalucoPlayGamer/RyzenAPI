-- 4403510's Lua and Manifest Created by Hubcap Manifest
-- Sensory Overload
-- Created: August 20, 2026 at 13:23:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4403510, 1, "80ae03364d57853ee84f881ee5d003e733ac41f030b61895acc36b771c156bbd") -- Sensory Overload
-- MAIN APP DEPOTS
addappid(4403511, 1, "83f10cc5e0abcdfd8179c211cc7dd5b82443b051ec367b6df477aa15493ed456") -- Depot 4403511
setManifestid(4403511, "8361791779963619730", 177444421)
addappid(4403513, 1, "81362aab3a181f002cec7bc9a130f73d89fa3791a7e84d9ff40cd56f9340b721") -- Depot 4403513
setManifestid(4403513, "7283885206155523543", 184048885)