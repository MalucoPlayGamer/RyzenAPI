-- Lua provided by RyzenAPI
-- Game: MEANDERS - Original Soundtrack

-- MAIN APPLICATION
addappid(777110)

-- MAIN APP DEPOTS / PACKAGES
addappid(777110,0,"47f3964297628403236557a0b5d3d6fcfe99c039fbdef714769e064359de3dd1")
