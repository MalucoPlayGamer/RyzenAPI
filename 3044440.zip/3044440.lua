-- Lua provided by RyzenAPI
-- Game: Gas Station Manager

-- MAIN APPLICATION
addappid(3044440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044441, 1, "2840c93bb75474604b492bb085b1d5b13f1f40822edd816661204eff2d54ea05")
