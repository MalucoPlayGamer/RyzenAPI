-- Lua provided by RyzenAPI 
-- Game: Mob Control
addappid(2736490)
addappid(2736491, 1, "30a4d19cc3183ed51e5ff97631295c53d8a9eeb2182783de84a524452c6f08fd")
addappid(2749200, 0, "ccd397efb50dca9d2ff453bc1e70bded2452c80d68d2b401f7db289dc30dfb97")
addappid(2749210, 0, "23ef1d80879386b4a9063d2d9773aac5476efa5a7507fd27456032de03fa4fee")
