-- Lua provided by SkyAPI 
-- Game: Coin Dash
addappid(1606730)
addappid(1606731, 1, "ed8140ed906bdbaf13b366dfaf4c5c31b7cb28a73fdf00654d059061452c7483")
