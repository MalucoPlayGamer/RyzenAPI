-- Lua provided by RyzenAPI
-- Game: Coin Dash

-- MAIN APPLICATION
addappid(1606730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606731, 1, "ed8140ed906bdbaf13b366dfaf4c5c31b7cb28a73fdf00654d059061452c7483")
