-- Lua provided by RyzenAPI
-- Game: LockYourDoor

-- MAIN APPLICATION
addappid(3004140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004141, 1, "c5482a764f6c408ac116fa2d938d157c8fe9e44b6d605dbff37e9d42c42edf2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
