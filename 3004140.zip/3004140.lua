-- Lua provided by SkyAPI 
-- Game: LockYourDoor
addappid(3004140)
addappid(3004141, 1, "c5482a764f6c408ac116fa2d938d157c8fe9e44b6d605dbff37e9d42c42edf2c")
