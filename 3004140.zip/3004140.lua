-- Lua provided by RyzenAPI
-- Game: 3004140

-- MAIN APPLICATION
addappid(3004140)
-- Game: addappid(3004140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3004141, 1, "c5482a764f6c408ac116fa2d938d157c8fe9e44b6d605dbff37e9d42c42edf2c")
