-- Lua provided by RyzenAPI
-- Game: 小三角大英雄

-- MAIN APPLICATION
addappid(575050)

-- MAIN APP DEPOTS / PACKAGES
addappid(575051, 1, "66a2eb3888c56ada0f810957eeaa46f39275fabcbad69cfff2574cbed93b9d35")

