-- Lua provided by RyzenAPI
-- Game: AppID 2264310

-- MAIN APPLICATION
addappid(2264310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264311, 1, "b330908cbac06532fdd39f6e3bd1fd7c4b0d477865c7bcc447a4cc54c3bf2179")
