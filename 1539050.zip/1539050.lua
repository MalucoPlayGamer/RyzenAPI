-- Lua provided by RyzenAPI
-- Game: Fire Boy

-- MAIN APPLICATION
addappid(1539050) -- Fire Boy

-- MAIN APP DEPOTS / PACKAGES
addappid(1539051, 1, "54bf69ee366f0605c893a09f055fce80e0a02fe007c27e8b3f65d8ed7ce03ec3") -- Depot 1539051
