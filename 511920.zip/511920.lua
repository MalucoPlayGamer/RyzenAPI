-- Lua provided by RyzenAPI
-- Game: Reproduction Man

-- MAIN APPLICATION
addappid(511920)

-- MAIN APP DEPOTS / PACKAGES
addappid(511922,0,"9054f201386bb11fed91cbc170dd2278bbf2a851734e0fb71c9505ce17fdf0fd")

