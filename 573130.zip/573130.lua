-- Lua provided by RyzenAPI
-- Game: Aporia: Beyond The Valley

-- MAIN APPLICATION
addappid(573130)

-- MAIN APP DEPOTS / PACKAGES
addappid(573131, 1, "b5d7d4c5cbb6c4b7ab587522f215616087ade0f5463aab7b24ebd96682d41f33")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(669590)
