-- Lua provided by RyzenAPI
-- Game: Aporia: Beyond The Valley

-- MAIN APPLICATION
addappid(573130)
-- Game: addappid(573130)

-- MAIN APP DEPOTS / PACKAGES
addappid(573131, 1, "b5d7d4c5cbb6c4b7ab587522f215616087ade0f5463aab7b24ebd96682d41f33")
