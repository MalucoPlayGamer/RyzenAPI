-- Lua provided by SkyAPI 
-- Game: Tyrant's Blessing Soundtrack
addappid(2108850)
addappid(2108851, 1, "572cac2f251ac64521e7b23013c4d11ea8ff26a16f17194e540f8a2326d351fb")
