-- Lua provided by RyzenAPI
-- Game: Game: Factory Town Idle Demo

-- MAIN APPLICATION
addappid(2270260)
-- Game: addappid(2270260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270261, 1, "6ccb9924b38939558011ee9a5fae496d4e4a0141a4b18c06c5b4643a819c4658")
