-- Lua provided by RyzenAPI
-- Game: Game: Baby Bee

-- MAIN APPLICATION
addappid(1014660)
-- Game: addappid(1014660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014661, 1, "ff2b6413a5b4715f37cb0edff0630a6dfadaae65285b32f121e7d8bb3a6b6d5c")
