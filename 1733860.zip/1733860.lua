-- Lua provided by SkyAPI 
-- Game: Slime Factory
addappid(1733860)
addappid(1733861, 1, "b0b803464b5501e35d39929b50b3c2cbf1ea8f1b8560820762d88850800d5a34")
