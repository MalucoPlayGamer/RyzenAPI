-- Lua provided by RyzenAPI
-- Game: Slime Factory

-- MAIN APPLICATION
addappid(1733860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733861, 1, "b0b803464b5501e35d39929b50b3c2cbf1ea8f1b8560820762d88850800d5a34")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
