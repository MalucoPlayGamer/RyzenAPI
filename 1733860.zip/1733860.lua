-- Lua provided by RyzenAPI
-- Game: Slime Factory

-- MAIN APPLICATION
addappid(1733860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733861, 1, "b0b803464b5501e35d39929b50b3c2cbf1ea8f1b8560820762d88850800d5a34")

