-- Lua provided by RyzenAPI
-- Game: AppID 503240

-- MAIN APPLICATION
addappid(503240)

-- MAIN APP DEPOTS / PACKAGES
addappid(503241, 1, "4273145ce6a22a4832bfa364132c7cf9a9151474a4e8d4a4213ba558e82f836b")
addappid(503242, 1, "cf4464075ae776a309ad212f7ee20c186be7a7168bfe323c0ea7efff6d1ff882")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
