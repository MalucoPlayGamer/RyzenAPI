-- Lua provided by RyzenAPI
-- Game: addappid(503240)

-- MAIN APPLICATION
addappid(503240)

-- MAIN APP DEPOTS / PACKAGES
addappid(503241, 1, "4273145ce6a22a4832bfa364132c7cf9a9151474a4e8d4a4213ba558e82f836b")
addappid(503242, 1, "cf4464075ae776a309ad212f7ee20c186be7a7168bfe323c0ea7efff6d1ff882")
