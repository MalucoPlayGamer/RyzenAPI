-- Lua provided by RyzenAPI
-- Game: PixBit

-- MAIN APPLICATION
addappid(466790)

-- MAIN APP DEPOTS / PACKAGES
addappid(466791, 1, "bcdae4395a8ef60055891e4b4e5a4b4a23ff7d9d970eb3f37e6a140311037f54")

