-- Lua provided by RyzenAPI 
-- Game: Super Mombo Quest
addappid(1262040)
addappid(1262041, 1, "a27289a32c2d50c436cd4341a5eb4e4dbd7f6d640262f834ed798e4a146d56f7")
