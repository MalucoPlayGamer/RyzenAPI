-- Lua provided by RyzenAPI
-- Game: KUUKIYOMI 4: Consider It

-- MAIN APPLICATION
addappid(3140130)
addappid(3141760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140131, 1, "af8c7798674efd80a5461c67945451687013be8310daa3b0e9d1fceb0b960d1d")
