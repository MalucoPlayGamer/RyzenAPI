-- Lua provided by RyzenAPI
-- Game: AppID 1174900

-- MAIN APPLICATION
addappid(1174900)
addappid(1184690)
addappid(1185710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174901, 1, "0a429074b069c429dad57f424a39ada523b0e4c57648badcd3e2a46697ed6cc4")

