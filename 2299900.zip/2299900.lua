-- Lua provided by RyzenAPI
-- Game: addappid(2299900)

-- MAIN APPLICATION
addappid(2299900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299901, 1, "69c657bebecb896de388aeb9fda4da91d90605afe228f98f3e049b863a4b01dd")
