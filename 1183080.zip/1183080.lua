-- Lua provided by RyzenAPI
-- Game: addappid(1183080)

-- MAIN APPLICATION
addappid(1183080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183081, 1, "f11d5b2e8fe9b83de6c41b664a6024bf1a8b216c09d4b3f6acfefd74b700799e")
