-- Lua provided by RyzenAPI
-- Game: 511830

-- MAIN APPLICATION
addappid(511830)
-- Game: addappid(511830)

-- MAIN APP DEPOTS / PACKAGES
addappid(511831, 1, "0bbe9956e136c04cb28f1ecba3c7069c3e367c886ae8ed57aa4259c5ea702cac")
