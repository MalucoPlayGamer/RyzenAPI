-- Lua provided by RyzenAPI
-- Game: Queen's Quest 3: The End of Dawn

-- MAIN APPLICATION
addappid(589690)

-- MAIN APP DEPOTS / PACKAGES
addappid(589691, 1, "ae26ce33f9c434512376f66da05056896881f86c8ecd52825d63bd45cd430310")
