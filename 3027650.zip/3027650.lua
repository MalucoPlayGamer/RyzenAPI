-- Lua provided by RyzenAPI 
-- Game: AppID 3027650
addappid(3027650)
addappid(3027651, 1, "51441fdd758b74522065fe0e4ae1a82c0d10ecca37ccee2c9598e7e2b2ce7ea7")
