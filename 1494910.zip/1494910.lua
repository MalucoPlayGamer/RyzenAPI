-- Lua provided by RyzenAPI
-- Game: 1494910

-- MAIN APPLICATION
addappid(1494910)
-- Game: addappid(1494910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494911, 1, "235433eb8621fdba80c63e134aa74f3a4b3a3aa7c234c047d555586d1bb81c9e")
addappid(1494912, 1, "68fc8a9bfd6b9a28a7bbecf08451b7faa6c9fb3233417ab1fd7d4bf92bc78fbf")
