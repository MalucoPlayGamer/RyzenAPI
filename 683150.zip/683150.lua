-- Lua provided by RyzenAPI
-- Game: INFERNO: Deathfield

-- MAIN APPLICATION
addappid(683150)

-- MAIN APP DEPOTS / PACKAGES
addappid(683151,0,"735a4b6524bc36365eb2b16c761e523a3abc47ca42cd7b3ca8dff3be2d775d38")

