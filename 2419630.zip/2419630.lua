-- Lua provided by RyzenAPI
-- Game: Worlds of Aria Friends Pass

-- MAIN APPLICATION
addappid(2419630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419631, 1, "d88a8dca01d32e2cfbb87660442f4ae986017923da6814f7d0891219b8d43a68")
