-- Lua provided by RyzenAPI
-- Game: The Sword of Rhivenia

-- MAIN APPLICATION
addappid(1897250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897251,0,"52f4688660a557baea538f390de282cb398d94bcde016db150d4faff9adac635")

