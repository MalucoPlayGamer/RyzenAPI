-- Lua provided by RyzenAPI
-- Game: Deathly Dominion

-- MAIN APPLICATION
addappid(3200580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3200581, 1, "43700c00515c1037d973830e14045f6ea18fc33c6bfb955a133d26641b37c7c1")

