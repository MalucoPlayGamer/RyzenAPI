-- Lua provided by RyzenAPI 
-- Game: Deathly Dominion
addappid(3200580)
addappid(3200581, 1, "43700c00515c1037d973830e14045f6ea18fc33c6bfb955a133d26641b37c7c1")
