-- Lua provided by RyzenAPI
-- Game: 1220600

-- MAIN APPLICATION
addappid(1220600)
-- Game: addappid(1220600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220601, 1, "b9d1b893deb43b0fcc6b2399d002965ce4870d9749a8dddcb46b61427bda9a00")
