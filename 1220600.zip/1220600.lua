-- Lua provided by RyzenAPI 
-- Game: Edengrall
addappid(1220600)
addappid(1220601, 1, "b9d1b893deb43b0fcc6b2399d002965ce4870d9749a8dddcb46b61427bda9a00")
