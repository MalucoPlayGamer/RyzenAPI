-- Lua provided by RyzenAPI
-- Game: 926580

-- MAIN APPLICATION
addappid(228990)
addappid(926580)
addappid(926581)
addappid(926582)
addappid(926583)
addappid(926585)
addappid(926586)
-- Game: addappid(926580)

-- MAIN APP DEPOTS / PACKAGES
addappid(926584,0,"e825cf7593a1260f5c5575d3ffdf9b7379ef220691b557e71d8b83032dcf4c5a")
