-- Lua provided by RyzenAPI
-- Game: addappid(1853530)

-- MAIN APPLICATION
addappid(1853530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853530,0,"4d3cea952a1dfd9b059bc2af685bfc7e28b21b05316f5be8576703e5042afc2a")
