-- Lua provided by RyzenAPI 
-- Game: 墙之恐惧: The Walls Still Stand
addappid(3114650)
addappid(3114651, 1, "9101406f10ee55d5571496df799b19dafcc4188c9f277f09d0e33f4ca6e83c01")
