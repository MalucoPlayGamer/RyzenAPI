-- Lua provided by RyzenAPI
-- Game: 3114650

-- MAIN APPLICATION
addappid(3114650)
-- Game: addappid(3114650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114651, 1, "9101406f10ee55d5571496df799b19dafcc4188c9f277f09d0e33f4ca6e83c01")
