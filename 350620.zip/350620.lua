-- Lua provided by RyzenAPI
-- Game: Sandmason

-- MAIN APPLICATION
addappid(350620)

-- MAIN APP DEPOTS / PACKAGES
addappid(350621, 1, "302a3334a187ec0154ae4da0a94763ebf54d4c3af29e8cf76aa72127ded07d2f")
addappid(350622, 1, "1dd33a7b67739b0c223d905929e111b280df829accc8ba4a1e7f8b19e3f3f71f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
