-- Lua provided by RyzenAPI
-- Game: Game: Charlie the Duck

-- MAIN APPLICATION
addappid(691250)
-- Game: addappid(691250)

-- MAIN APP DEPOTS / PACKAGES
addappid(691251, 1, "92282c71a45df5a41323aa37700a8e19a474386699716ede5eac44f709f9f375")
addappid(993710, 0, "98fdc6f865fd197fae8f354b561583a4ceca5ef49c049964e5ee7b7f9dc5fb41")
