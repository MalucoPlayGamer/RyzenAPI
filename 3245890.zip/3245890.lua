-- Generated with Luie @ https://lua.tools/
-- 3245890 - Upstream
-- Generated 2026-08-22 05:24:06 UTC
-- # Depots (Total/DLC/Shared): 2/1/0

-- Main AppID
addappid(3245890)

-- Main Depots
addappid(3245891, 1, "b9eb710b428cbc3bdedeaa712d70a00458a7d9f6275886998e1cab74c66e4692")
setManifestid(3245891, "7683800604144356230", 152494264)

-- Missing Depots (We don't have the keys yet lol): 3582841
