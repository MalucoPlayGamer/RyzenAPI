-- Lua provided by RyzenAPI
-- Game: Upstream

-- MAIN APPLICATION
addappid(3245890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245891, 1, "b9eb710b428cbc3bdedeaa712d70a00458a7d9f6275886998e1cab74c66e4692")

