-- Lua provided by RyzenAPI
-- Game: Grow Up

-- MAIN APPLICATION
addappid(426790)
-- Game: addappid(426790)

-- MAIN APP DEPOTS / PACKAGES
addappid(426791, 1, "72c36d76a90c094a495e0825516f58cccc19aa94b5c3e757718d4acb1a679cab")
