-- Lua provided by RyzenAPI
-- Game: DYSMANTLE

-- MAIN APPLICATION
addappid(846770)
addappid(2004110)
addappid(2147250)
addappid(2439690)

-- MAIN APP DEPOTS / PACKAGES
addappid(846770,0,"e62c47c969d5072004230043978c146f4b1ccfec300b7d1f73a86ab637d560d5")
addappid(846771,0,"c345ec3e46cd18e15a4f18b0c8e1c099ab995829330b6a66d5a8f47894be732f")
addappid(846772,0,"a0fcc1b3487aacf7ed5abbd1859ee12a145b61fb902bb71961426d4921e9a0ae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
