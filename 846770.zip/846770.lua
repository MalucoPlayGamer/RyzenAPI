-- Lua provided by RyzenAPI
-- Game: addappid(846770)

-- MAIN APPLICATION
addappid(846770)

-- MAIN APP DEPOTS / PACKAGES
addappid(846771, 1, "c345ec3e46cd18e15a4f18b0c8e1c099ab995829330b6a66d5a8f47894be732f")
addappid(846772, 1, "a0fcc1b3487aacf7ed5abbd1859ee12a145b61fb902bb71961426d4921e9a0ae")
