-- Lua provided by RyzenAPI
-- Game: addappid(1380570)

-- MAIN APPLICATION
addappid(1380570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380571, 1, "f57456cc5b116fdd6964cf8c96c34ad091abad051e7329936db8f0dba5915696")
