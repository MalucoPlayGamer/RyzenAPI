-- Lua provided by SkyAPI 
-- Game: AppID 1380570
addappid(1380570)
addappid(1380571, 1, "f57456cc5b116fdd6964cf8c96c34ad091abad051e7329936db8f0dba5915696")
