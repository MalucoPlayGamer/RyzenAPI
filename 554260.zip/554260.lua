-- Lua provided by RyzenAPI
-- Game: Songs for a Hero Skin Pack

-- MAIN APPLICATION
addappid(554260)
addappid(554261)

-- MAIN APP DEPOTS / PACKAGES
addappid(554260,0,"0c8db76b67cbeed797eb69ec864bb6336f59ab06d1bb0a8ff5f1dff4f45acb40")

