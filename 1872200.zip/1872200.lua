-- Lua provided by RyzenAPI
-- Game: 1872200

-- MAIN APPLICATION
addappid(1872200)
-- Game: addappid(1872200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872201, 1, "d8d1dc06d6efd1799cb80af43928618d3b5dd2e52df0defe664727c687367688")
