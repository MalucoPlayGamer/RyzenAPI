-- Lua provided by RyzenAPI
-- Game: AppID 1878450

-- MAIN APPLICATION
addappid(1878450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878451, 1, "4b272af9e7197ff7ff20da0a14b4fc3a813fdfc8d49efecb1666c7b5e6afd995")
addappid(1878452, 1, "a5753803e6996e051a8db6e0e36ffcfaaf7cb29104ef993e29e362f0098e99b2")
addappid(1878453, 1, "f892afa0e753312fea556815ebf83197121142419ed4651c51228dc6d6842e9a")
addappid(1878454, 1, "c07aaeada57758553252ebcfda5eabbb0f2c240f6addb5d907448cfeba31ac40")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
