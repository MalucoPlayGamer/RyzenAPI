-- Lua provided by RyzenAPI
-- Game: 1878450

-- MAIN APPLICATION
addappid(1878450)
-- Game: addappid(1878450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878451, 1, "4b272af9e7197ff7ff20da0a14b4fc3a813fdfc8d49efecb1666c7b5e6afd995")
addappid(1878452, 1, "a5753803e6996e051a8db6e0e36ffcfaaf7cb29104ef993e29e362f0098e99b2")
addappid(1878453, 1, "f892afa0e753312fea556815ebf83197121142419ed4651c51228dc6d6842e9a")
addappid(1878454, 1, "c07aaeada57758553252ebcfda5eabbb0f2c240f6addb5d907448cfeba31ac40")
