-- Lua provided by RyzenAPI
-- Game: Lakeview Valley

-- MAIN APPLICATION
addappid(783840)

-- MAIN APP DEPOTS / PACKAGES
addappid(783842,0,"8114b8c7d53de747b5687354d23c17149975c8ac15c62187f02cf64a6388e9d9")

