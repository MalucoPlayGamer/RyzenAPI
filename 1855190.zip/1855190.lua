-- Lua provided by RyzenAPI
-- Game: Game: Vektor Z

-- MAIN APPLICATION
addappid(1855190)
-- Game: addappid(1855190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855191, 1, "61f05688269e1ee123961c99701258420e254c8a294d281f7474b2f52ae123b7")
