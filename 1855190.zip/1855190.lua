-- Lua provided by SkyAPI 
-- Game: Vektor Z
addappid(1855190)
addappid(1855191, 1, "61f05688269e1ee123961c99701258420e254c8a294d281f7474b2f52ae123b7")
