-- Lua provided by RyzenAPI
-- Game: addappid(508410)

-- MAIN APPLICATION
addappid(508410)

-- MAIN APP DEPOTS / PACKAGES
addappid(508411, 1, "66f8f7e8686f1eb8e99d355cb74d778b6e444696d1ee580d9d99d3a8645e573e")
