-- Lua provided by RyzenAPI
-- Game: addappid(370440)

-- MAIN APPLICATION
addappid(370440)

-- MAIN APP DEPOTS / PACKAGES
addappid(370441, 1, "75b85986f902dbcd418c4de07ecad63d040e024b8f968b7f854aa8ed2620f49e")
