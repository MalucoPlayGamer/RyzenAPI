-- Lua provided by RyzenAPI
-- Game: AppID 443080

-- MAIN APPLICATION
addappid(443080)
-- Game: addappid(443080)

-- MAIN APP DEPOTS / PACKAGES
addappid(443081, 1, "21def7d5441e74a52de6cbb5967ce5b619315da87ab597471d262e25da353f23")
addappid(443082, 1, "8c95a8419fddb587502de970706ff74233fcbda7371da73e75606b1ef6861e6f")
