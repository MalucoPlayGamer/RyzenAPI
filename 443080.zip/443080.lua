-- Lua provided by RyzenAPI
-- Game: AppID 443080

-- MAIN APPLICATION
addappid(443080)
addappid(1067910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(443081, 1, "21def7d5441e74a52de6cbb5967ce5b619315da87ab597471d262e25da353f23")
addappid(443082, 1, "8c95a8419fddb587502de970706ff74233fcbda7371da73e75606b1ef6861e6f")

