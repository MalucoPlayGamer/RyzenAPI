-- Lua provided by RyzenAPI
-- Game: AquaDesk

-- MAIN APPLICATION
addappid(4943290) -- AquaDesk

-- MAIN APP DEPOTS / PACKAGES
addappid(4943291, 1, "5c3a8823be77bd808b6f43028836e723f1893f22bceac04d0548a60478cade40") -- Depot 4943291

