-- 4943290's Lua and Manifest Created by Hubcap Manifest
-- AquaDesk
-- Created: August 16, 2026 at 12:07:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4943290) -- AquaDesk
-- MAIN APP DEPOTS
addappid(4943291, 1, "5c3a8823be77bd808b6f43028836e723f1893f22bceac04d0548a60478cade40") -- Depot 4943291
setManifestid(4943291, "2107442806186318247", 104683880)