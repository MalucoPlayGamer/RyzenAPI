-- Lua provided by RyzenAPI
-- Game: Gary Grigsby's War in the East 2

-- MAIN APPLICATION
addappid(1775550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775551, 1, "5dca212ba73b5ab6560a7d29ab07675840aa54b7a45c4279442a07f80e6af358")
addappid(1775552, 1, "2c021b7f66f2af238fc9f2e632555fe77fb057662f5fb463423e6b68791f1072")
addappid(1975590, 0, "2963d8f3bdd942f4f89feaed945932876f3ae0a41812dfd0d398a1291de43a0f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
