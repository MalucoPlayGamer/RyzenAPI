-- Lua provided by RyzenAPI
-- Game: AppID 435400

-- MAIN APPLICATION
addappid(435400)
-- Game: addappid(435400)

-- MAIN APP DEPOTS / PACKAGES
addappid(435401, 1, "a7ccbe00ddde51f9a2dc9774ecd5a52ad5eaa51eec7080a2a828ada4069b36c3")
addappid(435402, 1, "fed12eb73cc580086d1a70c6408b0e174084178584e9c751adead9abc5a49f14")
addappid(435403, 1, "e06d345a10ff3ab4531cfba49a8e10881ef1e4922c1489e405297739201ca5d2")
