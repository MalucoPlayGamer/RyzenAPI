-- Lua provided by RyzenAPI
-- Game: addappid(485160)

-- MAIN APPLICATION
addappid(485160)

-- MAIN APP DEPOTS / PACKAGES
addappid(485161, 1, "0a32ddd9a28ad7b2cddcab347a94c480768bd35080da36a5c047fa5ad0ed3639")
addappid(485162, 1, "5dd19e6d39993e50c9b8902ecd55a96e1f35177c8daa2ac42bb906d455f23a37")
addappid(522830, 0, "513c7169bd3334ff92bbf284d602e3f786280b6fccba50a6c6076b34b57de21c")
