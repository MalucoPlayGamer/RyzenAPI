-- Lua provided by RyzenAPI
-- Game: Game: AppID 1896680

-- MAIN APPLICATION
addappid(1896680)
-- Game: addappid(1896680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896681, 1, "0486e08114c0ebb0a71fb171f074668111cd333845b2b86b6df662f0b8ace76c")
