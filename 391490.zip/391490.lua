-- Lua provided by RyzenAPI
-- Game: Braveland Pirate

-- MAIN APPLICATION
addappid(391490)
-- Game: addappid(391490)

-- MAIN APP DEPOTS / PACKAGES
addappid(391491, 1, "ee3aa40111fbb0d4044f29ed38f818e3b2e6de2d4f94b38b6e2fa6938bc7c74c")
addappid(391492, 1, "06ffa23a3e52455fbbd6c09f69200bfa06fc42155398fdfc1a64c94fdbae3ffe")
addappid(391493, 1, "717a3b6311d8052471914e115a55575f7e15ebebd4adcbe0bd77888c6a804b9a")
