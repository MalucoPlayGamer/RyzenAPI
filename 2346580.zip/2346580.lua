-- Lua provided by RyzenAPI
-- Game: Game: Sentimental Death Loop

-- MAIN APPLICATION
addappid(2346580)
-- Game: addappid(2346580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346581, 1, "91a834a1bee8ab58752bf5ae20a433df48024d1eae96f3b746cd40e2d34a168d")
