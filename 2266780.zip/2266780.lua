-- Lua provided by RyzenAPI
-- Game: Ascendant

-- MAIN APPLICATION
addappid(2266780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2266781, 1, "952402f691b8dd457cba1c8c4d03f79dec2cc53e47cc3bb2da3a55e2c491057a")
addappid(2266782, 1, "ac946f5171d601e2129f3607eb5ccad88a7c574f6f579a32ba1ede6ef3fa11fe")
