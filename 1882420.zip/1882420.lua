-- Lua provided by RyzenAPI
-- Game: Learn Programming: Python - Remake

-- MAIN APPLICATION
addappid(1882420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882421, 1, "7983a87acc0dfe74b066567c8886a3a51fc7bd501c3b073d8694026ba2d5e364")

