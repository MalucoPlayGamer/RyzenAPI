-- Lua provided by RyzenAPI
-- Game: Warp Factory

-- MAIN APPLICATION
addappid(1601860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601861, 1, "9ec9b961fa3ac2616d4aa5042b89ffa25bb6ec49f5a7fe6a6abdd64a69ecd8e0")
