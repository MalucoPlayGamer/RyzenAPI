-- Lua provided by RyzenAPI
-- Game: Game: AppID 1069430

-- MAIN APPLICATION
addappid(1069430)
-- Game: addappid(1069430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069431, 1, "65747fde24349df86bc74852c892eec5eed760c7e8e2a635f13120576d407780")
