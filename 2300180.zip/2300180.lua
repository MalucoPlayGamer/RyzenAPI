-- Lua provided by RyzenAPI
-- Game: Patchouli's Adventure In Doll's House (Demo)

-- MAIN APPLICATION
addappid(2300180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300182,0,"179e1dca6fe009937acf9c269b534c32cdb2915a1b80fdcb9474a9d7f1031ae2")
addappid(2300184,0,"fc95dc412ec3dd32b3541ed671e480091d501625a1d8a2b85703b543739cc80a")

