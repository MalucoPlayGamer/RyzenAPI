-- Lua provided by RyzenAPI
-- Game: Under The Hood

-- MAIN APPLICATION
addappid(1428700)
-- Game: addappid(1428700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428702,0,"87b492cc86a26648090cce79145dfc50bb286242602e3c5196497817caf2a962")
