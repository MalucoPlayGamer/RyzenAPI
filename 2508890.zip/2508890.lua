-- Lua provided by RyzenAPI
-- Game: Etaine: Magic Survivor / 伊泰恩：魔法幸存者

-- MAIN APPLICATION
addappid(2508890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508891, 1, "69680195b1a313d236b1ca64e87df11a04b9dd55a5e01fe6a75391a3d3e7101d")

