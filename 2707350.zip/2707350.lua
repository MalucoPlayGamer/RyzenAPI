-- Lua provided by RyzenAPI
-- Game: On the Bubble

-- MAIN APPLICATION
addappid(2707350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707351, 1, "138a8963a6ee4e7ae06348da4b79e1ff5558f9bd3ff8276e18ec1151237487cc")
