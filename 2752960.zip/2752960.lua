-- Lua provided by RyzenAPI
-- Game: Guardians of Eden Demo

-- MAIN APPLICATION
addappid(2752960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752961, 1, "ac93362896b43d2610cf264bf38e798af94b887ae17c9541159f52daa312a48f")
