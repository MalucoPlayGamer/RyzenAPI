-- Lua provided by RyzenAPI
-- Game: Game: AppID 599390

-- MAIN APPLICATION
addappid(599390)
-- Game: addappid(599390)

-- MAIN APP DEPOTS / PACKAGES
addappid(599391, 1, "453a189f401660e3b4c3b3174b8c10c4aed809aebc76dc434a39d994bff63722")
addappid(599392, 1, "9a15757143d0d3edd42a4b686ac7252d8416dec2b88cdfe0820fa57bc9de685d")
addappid(599393, 1, "33c5ef8f64bef9299cc1222e55860d99a99f4a15e166c328984318def3be4c55")
addappid(599394, 1, "ef1a3db3cdfa815d048da1edebeb778be0f9134f6a255234e183a340fe0e8177")
