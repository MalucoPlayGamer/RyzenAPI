-- Lua provided by RyzenAPI
-- Game: Bank Simulator

-- MAIN APPLICATION
addappid(3355800)
-- Game: addappid(3355800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3355801, 1, "fabe54fdaf7a5a04910f223f36584ebb24fee7c50fa79167e55c6c5fcb1ecfa2")
