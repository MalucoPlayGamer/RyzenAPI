-- Lua provided by RyzenAPI
-- Game: Game: Solo Flight

-- MAIN APPLICATION
addappid(1703090)
-- Game: addappid(1703090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703091, 1, "d8ea5b39c194695c7c0883474b50181e1e704fa241963db3b81ac927471310dc")
addappid(1703092, 1, "0990d3a9db30363ad221d11bb0a1b145a8938065c69eb0ebb9a07821555373aa")
