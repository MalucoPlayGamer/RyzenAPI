-- Lua provided by RyzenAPI 
-- Game: TriangleWingXXXX
addappid(1205010)
addappid(1205011, 1, "ffbd300f3cc6f34aab24e9c88b9c91cc5a9243fce6c53f98bff711188a06c8d4")
