-- Lua provided by RyzenAPI
-- Game: 1205010

-- MAIN APPLICATION
addappid(1205010)
-- Game: addappid(1205010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205011, 1, "ffbd300f3cc6f34aab24e9c88b9c91cc5a9243fce6c53f98bff711188a06c8d4")
