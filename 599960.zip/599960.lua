-- Lua provided by RyzenAPI
-- Game: 599960

-- MAIN APPLICATION
addappid(599960)
-- Game: addappid(599960)

-- MAIN APP DEPOTS / PACKAGES
addappid(599961, 1, "98e8d7c118d096fa652220324adc9a1dd43e9495c74ab6621affe2fcf9b42c58")
