-- Lua provided by RyzenAPI
-- Game: Necro Blade

-- MAIN APPLICATION
addappid(3315670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3315671, 1, "465676c307f3876116c5d2529acfa069a95c7050f659fff138273aa42da5c1ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
