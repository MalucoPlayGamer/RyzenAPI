-- Lua provided by SkyAPI 
-- Game: Necro Blade
addappid(3315670)
addappid(3315671, 1, "465676c307f3876116c5d2529acfa069a95c7050f659fff138273aa42da5c1ab")
