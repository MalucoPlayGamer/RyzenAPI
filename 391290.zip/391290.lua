-- Lua provided by RyzenAPI
-- Game: DeathCrank

-- MAIN APPLICATION
addappid(391290)

-- MAIN APP DEPOTS / PACKAGES
addappid(391291, 1, "f25759f84ab1ba5cd08112f76d9f372c2beb8674b5652f087f45c7ffff17177a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
