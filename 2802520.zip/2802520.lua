-- Lua provided by RyzenAPI
-- Game: Game: AppID 2802520

-- MAIN APPLICATION
addappid(2802520)
-- Game: addappid(2802520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802521, 1, "567580132c94ede7e107598ffe80ce7e5706029afd53f21fd6f2ad8171550855")
