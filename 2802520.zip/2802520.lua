-- Lua provided by RyzenAPI
-- Game: Gracia

-- MAIN APPLICATION
addappid(2802520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2802521, 1, "567580132c94ede7e107598ffe80ce7e5706029afd53f21fd6f2ad8171550855")

