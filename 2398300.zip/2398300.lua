-- Lua provided by RyzenAPI
-- Game: Chris - The Element Runner

-- MAIN APPLICATION
addappid(2398300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398301, 1, "652df8499c2e2f1878d2815bd4845a0ef3b8428724fc4e50b618334d7e233d23")

