-- Lua provided by RyzenAPI
-- Game: Drift Into Eternity

-- MAIN APPLICATION
addappid(431830)
addappid(602060)

-- MAIN APP DEPOTS / PACKAGES
addappid(431831, 1, "2d1cf9b27e6ebd66d1d9f6c646260640fcb98099c7e4311572a60bd24930c12a")
addappid(431832, 1, "56dd9d80ffac1b786827bcc2423ee12790d5ec7d6ce106a3a0683b28c4347688")
addappid(431833, 1, "19a21cbfdf66e04aaf6d75255d8ac38df753ea9408235db6976bbb3ffd951ff0")
addappid(431834, 1, "9fc270a3838aa8c43ac2e62687ac9655cb9f5715c93fe84e87f650b91d18590c")

