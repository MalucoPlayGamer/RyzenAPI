-- 3978240's Lua and Manifest Created by Hubcap Manifest
-- Wordless Forest
-- Created: August 24, 2026 at 15:17:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3978240) -- Wordless Forest
-- MAIN APP DEPOTS
addappid(3978241, 1, "d08228067f346a6ff98e6e6efa9d2cbf3fa230b7c35190aeccc2d3f73eecacdc") -- Depot 3978241
setManifestid(3978241, "5743617528955630098", 8402356924)