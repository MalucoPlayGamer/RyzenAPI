-- Lua provided by RyzenAPI
-- Game: Wordless Forest

-- MAIN APPLICATION
addappid(3978240) -- Wordless Forest

-- MAIN APP DEPOTS / PACKAGES
addappid(3978241, 1, "d08228067f346a6ff98e6e6efa9d2cbf3fa230b7c35190aeccc2d3f73eecacdc") -- Depot 3978241

