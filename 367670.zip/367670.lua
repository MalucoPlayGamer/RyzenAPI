-- Lua provided by RyzenAPI
-- Game: 367670

-- MAIN APPLICATION
addappid(367670)
-- Game: addappid(367670)

-- MAIN APP DEPOTS / PACKAGES
addappid(367671, 1, "3bc0ccfdf6aa8ad040b70e6aa2b778caa5d18060e0e407efdf18db55f44a1739")
