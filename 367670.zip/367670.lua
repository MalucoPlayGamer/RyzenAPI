-- Lua provided by RyzenAPI
-- Game: AppID 367670

-- MAIN APPLICATION
addappid(367670)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(367671, 1, "3bc0ccfdf6aa8ad040b70e6aa2b778caa5d18060e0e407efdf18db55f44a1739")

