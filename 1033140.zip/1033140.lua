-- Lua provided by RyzenAPI
-- Game: Church Era

-- MAIN APPLICATION
addappid(1033140)
-- Game: addappid(1033140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033141, 1, "552838829b5090465f510e77eb2edf878cf80bcd75fc9419aca2b03544b6844b")
