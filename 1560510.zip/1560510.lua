-- Lua provided by RyzenAPI
-- Game: 1560510

-- MAIN APPLICATION
addappid(1560510)
-- Game: addappid(1560510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560511, 1, "37933038dc4481d26ecdb080a576cf1e8aeea5e9ed366c60568c6ccc124f9f8e")
