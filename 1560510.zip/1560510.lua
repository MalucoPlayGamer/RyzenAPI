-- Lua provided by SkyAPI 
-- Game: HardCop 2
addappid(1560510)
addappid(1560511, 1, "37933038dc4481d26ecdb080a576cf1e8aeea5e9ed366c60568c6ccc124f9f8e")
