-- Lua provided by RyzenAPI
-- Game: addappid(1123050)

-- MAIN APPLICATION
addappid(1123050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123051, 1, "230adf4f9c1f00f60fe23bbe3309ce106c450fa5f0c9e7c1cf9023b0ecb176db")
addappid(1123052, 1, "03601a72763163ec9fdbf880ee86eda3533ca9487d4eab6fa406a7051ee24838")
