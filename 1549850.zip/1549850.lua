-- Lua provided by RyzenAPI
-- Game: 1549850

-- MAIN APPLICATION
addappid(1549850)
-- Game: addappid(1549850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549851, 1, "62adaa150b211f96b7398f77aecc4ad436ec96334edacccfe9d4096a50934a42")
