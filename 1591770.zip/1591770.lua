-- Lua provided by RyzenAPI
-- Game: Agent 64: Spies Never Die Demo

-- MAIN APPLICATION
addappid(1591770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591771, 1, "cbbc55a84af9c6b1d556970485b93fbbdc05d4c0b27d3d3de58d2ac9e00429cf")
