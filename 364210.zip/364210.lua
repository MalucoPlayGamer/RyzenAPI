-- Lua provided by RyzenAPI
-- Game: Sierra Ops - Space Strategy Visual Novel

-- MAIN APPLICATION
addappid(364210)

-- MAIN APP DEPOTS / PACKAGES
addappid(364211, 1, "9946d3b466b3d04f3d6db148d33f95815e1ca205838dc3afd89ab38a67f01d00")
addappid(1217400, 0, "3b6ca79a225685b8907fef52b1e5a7a6e33277d7a6ba458031841711ceda0572")

