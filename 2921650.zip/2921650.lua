-- Lua provided by RyzenAPI
-- Game: Jesus Christ Simulator

-- MAIN APPLICATION
addappid(2921650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2921651, 1, "91c2e510d95a1aa21cce3a1fe23a84f28245898341a2b24e5405f0878f74d0bc")

