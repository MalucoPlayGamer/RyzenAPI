-- Lua provided by SkyAPI 
-- Game: Jesus Christ Simulator
addappid(2921650)
addappid(2921651, 1, "91c2e510d95a1aa21cce3a1fe23a84f28245898341a2b24e5405f0878f74d0bc")
