-- Lua provided by RyzenAPI
-- Game: AppID 3247210

-- MAIN APPLICATION
addappid(3247210)
-- Game: addappid(3247210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3247211, 1, "09f5f3be3dc32fef78bf7b4e6010647cafe680d9cb0e5255313ec5e20a38d799")
