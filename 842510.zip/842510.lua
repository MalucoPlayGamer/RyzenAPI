-- Lua provided by RyzenAPI
-- Game: Survival Maze

-- MAIN APPLICATION
addappid(842510)

-- MAIN APP DEPOTS / PACKAGES
addappid(842511,0,"0b1bde3587ddc898059fc23074549e151eab9bf83401cf38c3e2549d62b997b0")

