-- Lua provided by RyzenAPI
-- Game: addappid(283410)

-- MAIN APPLICATION
addappid(283410)

-- MAIN APP DEPOTS / PACKAGES
addappid(283411, 1, "a7b3a3608d2fd40cd4220434a572d383034daeb1b3e7aeff6dbc76145f32d605")
