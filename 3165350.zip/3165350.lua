-- Lua provided by SkyAPI 
-- Game: BECOME THE DEVIL
addappid(3165350)
addappid(3165351, 1, "e14154530888d548bd281f32e553d45a9bd39bce2e2d7d876fa1f1e81815f3fd")
