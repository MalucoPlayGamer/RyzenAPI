-- Lua provided by RyzenAPI
-- Game: Game: BECOME THE DEVIL

-- MAIN APPLICATION
addappid(3165350)
-- Game: addappid(3165350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165351, 1, "e14154530888d548bd281f32e553d45a9bd39bce2e2d7d876fa1f1e81815f3fd")
