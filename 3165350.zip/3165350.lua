-- Lua provided by RyzenAPI
-- Game: BECOME THE DEVIL

-- MAIN APPLICATION
addappid(3165350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3165351, 1, "e14154530888d548bd281f32e553d45a9bd39bce2e2d7d876fa1f1e81815f3fd")

