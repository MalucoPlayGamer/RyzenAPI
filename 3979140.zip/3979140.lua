-- Lua provided by RyzenAPI
-- Game: Karma Keepers

-- MAIN APPLICATION
addappid(3979140) -- Karma Keepers

-- MAIN APP DEPOTS / PACKAGES
addappid(3979141, 1, "6d482689378b8a8e7f7e28bda7cfe3e60c42d0459ca0bc5a3bbf414b02df93b3") -- Depot 3979141
addappid(3979142, 1, "a8e44ddaed0038a4f277ab18fa89e5138f8b8d7898bf5f35c3a1f27515f30768") -- Depot 3979142

