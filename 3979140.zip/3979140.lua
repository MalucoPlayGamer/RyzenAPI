-- 3979140's Lua and Manifest Created by Hubcap Manifest
-- Karma Keepers
-- Created: August 14, 2026 at 00:45:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3979140) -- Karma Keepers
-- MAIN APP DEPOTS
addappid(3979141, 1, "6d482689378b8a8e7f7e28bda7cfe3e60c42d0459ca0bc5a3bbf414b02df93b3") -- Depot 3979141
setManifestid(3979141, "6630527111172755628", 85040451)
addappid(3979142, 1, "a8e44ddaed0038a4f277ab18fa89e5138f8b8d7898bf5f35c3a1f27515f30768") -- Depot 3979142
setManifestid(3979142, "1924112235437867283", 79034865)