-- Lua provided by RyzenAPI
-- Game: Zup! XS

-- MAIN APPLICATION
addappid(673800)

-- MAIN APP DEPOTS / PACKAGES
addappid(673801, 1, "2ec06614ff1bbedb1e5f1082d8d926e4ec14e6de791eddf1c9f610d0897b9568")
