-- Lua provided by RyzenAPI
-- Game: addappid(979310)

-- MAIN APPLICATION
addappid(979310)

-- MAIN APP DEPOTS / PACKAGES
addappid(979311, 1, "68296528c1762ea2680af0f7c9d143012978cf1662e5df0790e0ca76d5b755dd")
