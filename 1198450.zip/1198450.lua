-- Lua provided by SkyAPI 
-- Game: The Secret Order 8: Return to the Buried Kingdom
addappid(1198450)
addappid(1198451, 1, "e3c26b20c9ef1a1959b3b72bd9cd0c6d090f16c321a4f1e89c1de715bb2a44ac")
