-- Lua provided by RyzenAPI
-- Game: Paladin's Passage

-- MAIN APPLICATION
addappid(1908480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908481, 1, "661dd19ee64d762d02025229db31dcb4c366edff92670a13b50984d0df0c1982")
