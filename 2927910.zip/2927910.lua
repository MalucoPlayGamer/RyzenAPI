-- Lua provided by RyzenAPI
-- Game: addappid(2927910)

-- MAIN APPLICATION
addappid(2927910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927911, 1, "bf86ffd9575bf4244b990af6eb12704014d0ae2c755fd7b36f383cde4a8f8d19")
