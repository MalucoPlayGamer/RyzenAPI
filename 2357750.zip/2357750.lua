-- Lua provided by SkyAPI 
-- Game: StackHoops
addappid(2357750)
addappid(2357751, 1, "260b0cd4e42cc5aa064783beb7285852ba3636a53cb39acc5d66bc6f7aa4f3da")
