-- Lua provided by RyzenAPI
-- Game: StackHoops

-- MAIN APPLICATION
addappid(2357750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357751, 1, "260b0cd4e42cc5aa064783beb7285852ba3636a53cb39acc5d66bc6f7aa4f3da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
