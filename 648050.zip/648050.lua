-- Lua provided by RyzenAPI
-- Game: Super Pilot

-- MAIN APPLICATION
addappid(648050)

-- MAIN APP DEPOTS / PACKAGES
addappid(648052,0,"d344f8264c66ca58e29de523f2201343e290b8f7b2de79a7caeacfecae670a20")
