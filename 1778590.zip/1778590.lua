-- Lua provided by RyzenAPI
-- Game: Game: Equinox

-- MAIN APPLICATION
addappid(1778590)
-- Game: addappid(1778590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778591, 1, "0f134f5664dcbf2da04e8efb8dd56a1530b529b3b41dfd4f7f70333fffd303fd")
addappid(1778592, 1, "b748a7f38c7bfc6bea4a93c1d9debe9cfddffd9f6185938d89befd6286794abc")
