-- Lua provided by RyzenAPI
-- Game: 1229390

-- MAIN APPLICATION
addappid(1229390)
-- Game: addappid(1229390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229391, 1, "3cc01cf40a9a740a249faae0397f5dd6250fc95d666931323ec285025c87a78c")
