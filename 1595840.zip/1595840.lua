-- Lua provided by RyzenAPI
-- Game: Phoenotopia Awakening Soundtrack

-- MAIN APPLICATION
addappid(1595840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595841, 1, "38111977402a6d1d8c77ce8f5ba03b068002158af7dc5854a015933c6d584231")
