-- Lua provided by SkyAPI 
-- Game: Space Turbo 2
addappid(1995470)
addappid(1995471, 1, "f9e51cdf8da2e5e2f709b04b848d77a0ad8ee1eed6bdea8c3aa60f9b469bfd37")
