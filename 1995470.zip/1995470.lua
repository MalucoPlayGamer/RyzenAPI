-- Lua provided by RyzenAPI
-- Game: Game: Space Turbo 2

-- MAIN APPLICATION
addappid(1995470)
-- Game: addappid(1995470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995471, 1, "f9e51cdf8da2e5e2f709b04b848d77a0ad8ee1eed6bdea8c3aa60f9b469bfd37")
