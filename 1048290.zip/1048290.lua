-- Lua provided by RyzenAPI
-- Game: Game: AppID 1048290

-- MAIN APPLICATION
addappid(1048290)
-- Game: addappid(1048290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048291, 1, "82e5d76db5c10004c583ea5ec911269db2938f5794a5444f64e1a514e902775b")
addappid(1048292, 1, "339cac5db6a35ee8ba3f959a10070d0ba3def45202ce78b42a64857bfcd6893c")
