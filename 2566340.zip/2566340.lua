-- Lua provided by RyzenAPI
-- Game: addappid(2566340)

-- MAIN APPLICATION
addappid(2566340)
addappid(4207070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566341, 1, "a343c371cf6d12acb940c9b7287ff6b8362edaf688af430a7ed08a80cfef055a")
