-- Lua provided by RyzenAPI
-- Game: Warhammer: Vermintide 2 Closed Test

-- MAIN APPLICATION
addappid(737010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(737011, 1, "f3e04ff4ac1996e52429b616920ef552fafacb70a6ea3744cae5ee289d5a2a8a")
addappid(737012, 1, "277e04fa12cff133cd83006d8ba595dbe2d165a88a68438bd293d1dbeeee5a64")
addappid(737013, 1, "cf82762f84dc52cb524d2fd2c1ef9816a14c30a2315b69aafb10df430b47d3e6")

