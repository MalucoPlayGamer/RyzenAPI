-- Lua provided by RyzenAPI 
-- Game: Akai Onna
addappid(2674190)
addappid(2674191, 1, "20d36906c451208250f517428d480419fee31839bb8319d13d08f229530d35cc")
