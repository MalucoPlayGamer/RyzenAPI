-- Lua provided by RyzenAPI
-- Game: Game: Akai Onna

-- MAIN APPLICATION
addappid(2674190)
-- Game: addappid(2674190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674191, 1, "20d36906c451208250f517428d480419fee31839bb8319d13d08f229530d35cc")
