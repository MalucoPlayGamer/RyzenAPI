-- Lua provided by SkyAPI 
-- Game: AppID 1286120
addappid(1286120)
addappid(1286121, 1, "8795f71b5016d3c071652271a0b42f4854e6cf176df3e6f804a6c69538684f18")
