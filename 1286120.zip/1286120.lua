-- Lua provided by RyzenAPI
-- Game: Marble It Up! Classic

-- MAIN APPLICATION
addappid(1286120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286121, 1, "8795f71b5016d3c071652271a0b42f4854e6cf176df3e6f804a6c69538684f18")
