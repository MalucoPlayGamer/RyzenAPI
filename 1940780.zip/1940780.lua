-- Lua provided by RyzenAPI
-- Game: 1940780

-- MAIN APPLICATION
addappid(1940780)
-- Game: addappid(1940780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940781, 1, "dcbfda640595b73bcdcc11169bb5fc17bf32056f5dd5ca52f38ef534b7f4dc22")
