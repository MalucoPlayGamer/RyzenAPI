-- Lua provided by RyzenAPI 
-- Game: AppID 1940780
addappid(1940780)
addappid(1940781, 1, "dcbfda640595b73bcdcc11169bb5fc17bf32056f5dd5ca52f38ef534b7f4dc22")
