-- Lua provided by RyzenAPI
-- Game: Talisman: Origins

-- MAIN APPLICATION
addappid(1033170)
addappid(1093430)
addappid(1093431)
addappid(1189990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033171,0,"18fe606d7c4cf45293bb6bde7d963138e92a1f22e8956b6bc0c50950351dff74")
addappid(1033172,0,"1669dce89d49744e60434392b5d279a45838bdb03a5c8c1c11441f58f0e1a5d3")

