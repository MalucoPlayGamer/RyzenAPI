-- Lua provided by RyzenAPI
-- Game: Sky in your eyes

-- MAIN APPLICATION
addappid(1980890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980891, 1, "5dbc653f850686c70d4700bda98d9a21181e5d6f95803842485f438aacffd2b5")

