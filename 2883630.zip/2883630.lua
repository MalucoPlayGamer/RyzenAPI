-- Lua provided by RyzenAPI 
-- Game: glitter
addappid(2883630)
addappid(2883631, 1, "e82a7c5559c1f7ae25032b36ae521ef4b6d67f9a0314408a51bed6c0c701c19e")
