-- Lua provided by RyzenAPI
-- Game: 2883630

-- MAIN APPLICATION
addappid(2883630)
-- Game: addappid(2883630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883631, 1, "e82a7c5559c1f7ae25032b36ae521ef4b6d67f9a0314408a51bed6c0c701c19e")
