-- Lua provided by RyzenAPI
-- Game: 1094185

-- MAIN APPLICATION
addappid(1094185)
-- Game: addappid(1094185)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094185,0,"0e067aae1a00e01eb78ae847a2ae446f8559287859e0a90a1a1fcf33a21b7c13")
