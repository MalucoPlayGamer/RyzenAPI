-- Lua provided by RyzenAPI 
-- Game: Obscurant
addappid(1465440)
addappid(1465441, 1, "d01e5fef8999452b97666f5711653ef3d0a80d08c1fcfc70d9ec99ce1aea3369")
