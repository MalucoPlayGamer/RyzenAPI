-- Lua provided by RyzenAPI 
-- Game: Typing Tempo
addappid(2332930)
addappid(2332931, 1, "2ad801d73f39ad447ecc17aa109027a2f99e5eef7f0936706c852c59d682d0e7")
