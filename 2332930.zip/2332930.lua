-- Lua provided by RyzenAPI
-- Game: Typing Tempo

-- MAIN APPLICATION
addappid(2332930)
-- Game: addappid(2332930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2332931, 1, "2ad801d73f39ad447ecc17aa109027a2f99e5eef7f0936706c852c59d682d0e7")
