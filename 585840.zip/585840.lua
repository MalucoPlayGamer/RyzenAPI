-- Lua provided by RyzenAPI 
-- Game: Leaving Lyndow
addappid(585840)
addappid(585841, 1, "080841850349b0f4219075c33f0d2889bbc8b10484fc72f92d20aefcb27ac423")
addappid(587660, 0, "b58ba3e7cf8b279ec474e46e74c82ce7b24e74b889819218e921c0489fc84c74")
