-- Lua provided by RyzenAPI
-- Game: The Liminal Space

-- MAIN APPLICATION
addappid(2077770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077771, 1, "860485d0eca335ef2bf97fe83f812aca773128a00d9929df5cfd3cd77de59bb5")

