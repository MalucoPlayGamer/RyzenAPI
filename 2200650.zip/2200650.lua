-- Lua provided by RyzenAPI
-- Game: Game: Bits & Bops Demo

-- MAIN APPLICATION
addappid(2200650)
-- Game: addappid(2200650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200651, 1, "87a6124cb90cf82464fa059a2396e9ad27f9941f25e54cb86381eed8889e8ee6")
