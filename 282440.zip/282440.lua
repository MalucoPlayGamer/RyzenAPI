-- Lua provided by RyzenAPI
-- Game: AppID 282440

-- MAIN APPLICATION
addappid(282440)

-- MAIN APP DEPOTS / PACKAGES
addappid(282441, 1, "759d76a5e90c2a665c031af72f07c32a76c020ed868e6d305d740a36d2f93365")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
