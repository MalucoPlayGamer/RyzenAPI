-- Lua provided by RyzenAPI
-- Game: Heart and Seoul

-- MAIN APPLICATION
addappid(546490)
addappid(553010)
-- Game: addappid(546490)

-- MAIN APP DEPOTS / PACKAGES
addappid(546491, 1, "05077fdf882e9a7ff95a367ad6fddbdcce8db4a5bdd1efd0bdc04f86e550ac38")
addappid(546492, 1, "4c6681e36f276958d5826ba262ceeeea4334286ace0f2283021d5b819b228bdb")
addappid(546493, 1, "fc8841794fad0e2121b52c42d719a429101011e8cdb1f2e792c146b1fcf12c56")
addappid(546494, 1, "d4c4ea640ca3883ecad84986ad57c0d3301e92eaf91343f90e85ff81c55b0f9b")
addappid(546495, 1, "52a6b9995f5505e8eb30f220df51fc4ac9c5d148c28162853f661924c891e917")
addappid(552820, 0, "73a793fd5da22d7a4b346e584b604b6eefb79fab1ae0226c73b42e0832c221df")
