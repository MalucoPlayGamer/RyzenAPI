-- Lua provided by RyzenAPI
-- Game: AppID 882900

-- MAIN APPLICATION
addappid(882900)

-- MAIN APP DEPOTS / PACKAGES
addappid(882901, 1, "08f266a10648742d2b8e832e96126a896e85f1d923a5928b5935f5785402e345")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(963600)
