-- Lua provided by RyzenAPI
-- Game: 1584300

-- MAIN APPLICATION
addappid(1584300)
-- Game: addappid(1584300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584302,0,"4c912fcd7a1fe3760dacadbdf4f4c2ce210b3ae35162d10ea3c6452257903513")
