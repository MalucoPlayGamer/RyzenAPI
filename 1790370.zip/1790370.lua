-- Lua provided by SkyAPI 
-- Game: Rogue AI Simulator
addappid(1790370)
addappid(1790371, 1, "9eb7b9411256e935e765df0a87b75cca6d6094a8a9b5e5d6ffe185b7f9233b55")
