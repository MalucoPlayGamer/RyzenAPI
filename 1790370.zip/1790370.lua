-- Lua provided by RyzenAPI
-- Game: Game: Rogue AI Simulator

-- MAIN APPLICATION
addappid(1790370)
-- Game: addappid(1790370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1790371, 1, "9eb7b9411256e935e765df0a87b75cca6d6094a8a9b5e5d6ffe185b7f9233b55")
