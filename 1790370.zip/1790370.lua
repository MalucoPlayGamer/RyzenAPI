-- Lua provided by RyzenAPI
-- Game: Rogue AI Simulator

-- MAIN APPLICATION
addappid(1790370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1790371, 1, "9eb7b9411256e935e765df0a87b75cca6d6094a8a9b5e5d6ffe185b7f9233b55")

