-- Lua provided by RyzenAPI
-- Game: addappid(3279160)

-- MAIN APPLICATION
addappid(3279160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279161, 1, "3443a7884ebbf202c83e8c5a96086500513b05c04a502bdb3f1d091cbfeed513")
