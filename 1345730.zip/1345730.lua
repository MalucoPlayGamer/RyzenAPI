-- Lua provided by RyzenAPI 
-- Game: AppID 1345730
addappid(1345730)
addappid(1345731, 1, "cb2615968126ed26ddc0a6ed8005d4ebdd6a065b8a07c01906d45220eb3e9ac4")
