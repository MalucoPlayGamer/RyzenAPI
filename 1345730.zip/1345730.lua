-- Lua provided by RyzenAPI
-- Game: 江湖侠客令

-- MAIN APPLICATION
addappid(1345730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345731, 1, "cb2615968126ed26ddc0a6ed8005d4ebdd6a065b8a07c01906d45220eb3e9ac4")
