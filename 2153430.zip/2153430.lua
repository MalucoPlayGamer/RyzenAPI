-- Lua provided by RyzenAPI
-- Game: 2153430

-- MAIN APPLICATION
addappid(2153430)
-- Game: addappid(2153430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153433,0,"a4a99e3c8e5ba8878790d4f8065073e1ad95f41c240140b36385f2edcb9cb565")
