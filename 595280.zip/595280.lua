-- Lua provided by RyzenAPI
-- Game: Throne of Lies®: Medieval Politics

-- MAIN APPLICATION
addappid(595280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(595281, 1, "a0b1003edfcb0a9e3ab253ac3281cc5eafa7bd4a1a9674135ba261f78455ad87")

