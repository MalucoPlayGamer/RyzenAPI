-- Lua provided by RyzenAPI
-- Game: addappid(595280)

-- MAIN APPLICATION
addappid(595280)

-- MAIN APP DEPOTS / PACKAGES
addappid(595281, 1, "a0b1003edfcb0a9e3ab253ac3281cc5eafa7bd4a1a9674135ba261f78455ad87")
