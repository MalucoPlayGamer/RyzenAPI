-- Lua provided by RyzenAPI
-- Game: Castle of Shikigami 3

-- MAIN APPLICATION
addappid(3253690)
addappid(4715020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3253691, 1, "6b47a121b2e47b13fec204501a1cdabac1c6d3e03fac38ce702dfdac868e6a56")

