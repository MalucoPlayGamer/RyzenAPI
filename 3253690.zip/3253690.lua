-- Lua provided by RyzenAPI
-- Game: Castle of Shikigami 3

-- MAIN APPLICATION
addappid(3253690)
-- Game: addappid(3253690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253691, 1, "6b47a121b2e47b13fec204501a1cdabac1c6d3e03fac38ce702dfdac868e6a56")
