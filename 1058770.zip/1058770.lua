-- Lua provided by RyzenAPI
-- Game: 我来自江湖 From Jianghu

-- MAIN APPLICATION
addappid(1058770)
-- Game: addappid(1058770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058771, 1, "91b84c89799bb48299af01a22869aa305f118e31f8c3560d6e10011b8cdea2cd")
