-- Lua provided by RyzenAPI
-- Game: addappid(2912700)

-- MAIN APPLICATION
addappid(2912700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2912701, 1, "2ef7ee7faacea67c669bbfa38f018a2da8ab44ee98c810641b471e70e2d6348f")
