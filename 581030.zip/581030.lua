-- Lua provided by SkyAPI 
-- Game: The Last Hope: Trump vs Mafia - North Korea
addappid(581030)
addappid(581031, 1, "f44194cf209a23b3a78025cac8d8edd9ea0b3b29166cdf0f0e2d729b298ff48a")
