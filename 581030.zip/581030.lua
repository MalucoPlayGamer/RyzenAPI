-- Lua provided by RyzenAPI
-- Game: The Last Hope: Trump vs Mafia - North Korea

-- MAIN APPLICATION
addappid(581030)

-- MAIN APP DEPOTS / PACKAGES
addappid(581031, 1, "f44194cf209a23b3a78025cac8d8edd9ea0b3b29166cdf0f0e2d729b298ff48a")

