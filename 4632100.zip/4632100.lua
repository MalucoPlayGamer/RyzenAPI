-- Lua provided by RyzenAPI
-- Game: PLACE TO FIT

-- MAIN APPLICATION
addappid(4632100) -- PLACE TO FIT

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4632101, 1, "5960d822ba66f373bcda4eb8ef9ae723210fe9d559e4b39d2fb288f670f882d6") -- Depot 4632101
