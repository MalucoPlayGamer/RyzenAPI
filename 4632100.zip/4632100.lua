-- 4632100's Lua and Manifest Created by Hubcap Manifest
-- PLACE TO FIT
-- Created: August 29, 2026 at 01:10:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4632100) -- PLACE TO FIT
-- MAIN APP DEPOTS
addappid(4632101, 1, "5960d822ba66f373bcda4eb8ef9ae723210fe9d559e4b39d2fb288f670f882d6") -- Depot 4632101
setManifestid(4632101, "6650198295007993068", 6315910805)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)