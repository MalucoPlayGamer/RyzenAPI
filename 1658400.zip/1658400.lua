-- Lua provided by RyzenAPI
-- Game: The Mountain Hunting

-- MAIN APPLICATION
addappid(1658400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658401, 1, "97810508214ea03e598d0406054b2873e8fb0893613ae67af86532488aff3b33")

