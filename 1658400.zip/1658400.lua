-- Lua provided by RyzenAPI 
-- Game: AppID 1658400
addappid(1658400)
addappid(1658401, 1, "97810508214ea03e598d0406054b2873e8fb0893613ae67af86532488aff3b33")
