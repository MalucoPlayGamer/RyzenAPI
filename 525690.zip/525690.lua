-- Lua provided by SkyAPI 
-- Game: AppID 525690
addappid(525690)
addappid(525691, 1, "10ca9d679ecbc98123829e7dd45ecc4cf56c64f45d4952f65cc3c9ce6ce88908")
addappid(525692, 1, "43abe79db6fc2fa6cefd5482369b5a353d21b276529b312c8b3a4048f5110479")
addappid(525693, 1, "f3b0c3c6d7c4090d59fd4ef9fa68b160fea54afa0a631bc300b451d1d4f6674b")
