-- Lua provided by SkyAPI 
-- Game: Nick
addappid(572660)
addappid(572661, 1, "c7d0770952c8692c5553d266a831f9773ac4a7584851361eeba1b19a6af0007e")
