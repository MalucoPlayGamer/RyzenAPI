-- Lua provided by RyzenAPI
-- Game: Nick

-- MAIN APPLICATION
addappid(572660)

-- MAIN APP DEPOTS / PACKAGES
addappid(572661, 1, "c7d0770952c8692c5553d266a831f9773ac4a7584851361eeba1b19a6af0007e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
