-- Lua provided by RyzenAPI
-- Game: Lightfield HYPER Edition

-- MAIN APPLICATION
addappid(790020)

-- MAIN APP DEPOTS / PACKAGES
addappid(790021,0,"4fc8bf8be02f5e549cefb8da8a1ddaa02e37f75eef5a535d4d336161112e56bc")

