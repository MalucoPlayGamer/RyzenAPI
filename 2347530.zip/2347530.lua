-- Lua provided by RyzenAPI
-- Game: addappid(2347530)

-- MAIN APPLICATION
addappid(2347530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347531, 1, "8566c5f469b624a94426c5a1a8dbe6ac137ea0f95f1686f262eb1561ef56c857")
