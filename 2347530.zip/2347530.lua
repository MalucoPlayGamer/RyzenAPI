-- Lua provided by RyzenAPI
-- Game: IndependANT

-- MAIN APPLICATION
addappid(2347530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2347531, 1, "8566c5f469b624a94426c5a1a8dbe6ac137ea0f95f1686f262eb1561ef56c857")

