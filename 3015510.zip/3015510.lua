-- Lua provided by RyzenAPI
-- Game: Decision Legacy Collection

-- MAIN APPLICATION
addappid(3015510)
-- Game: addappid(3015510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015511, 1, "6bf050709231ec10f1ee2d0aac97ba9ba27ae519b6cc729def6df0f27b3ff85c")
