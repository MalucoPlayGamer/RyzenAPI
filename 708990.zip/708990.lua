-- Lua provided by RyzenAPI 
-- Game: Turtle's Quest
addappid(708990)
addappid(708991, 1, "2ca2cee3fb53f2fa43f4c72d5b485b501d880911944a58617b00a464dc9e6157")
