-- Lua provided by RyzenAPI
-- Game: Game: Turtle's Quest

-- MAIN APPLICATION
addappid(708990)
-- Game: addappid(708990)

-- MAIN APP DEPOTS / PACKAGES
addappid(708991, 1, "2ca2cee3fb53f2fa43f4c72d5b485b501d880911944a58617b00a464dc9e6157")
