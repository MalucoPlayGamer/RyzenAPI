-- Lua provided by RyzenAPI
-- Game: Game: The Entropy Centre

-- MAIN APPLICATION
addappid(1730590)
-- Game: addappid(1730590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730591, 1, "21e1a67a1a7b116ff9e2d5027f3fdc0418b923e58eb5aa2ec632e057d363b415")
