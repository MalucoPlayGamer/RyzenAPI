-- Lua provided by RyzenAPI
-- Game: The Entropy Centre

-- MAIN APPLICATION
addappid(1730590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1730591, 1, "21e1a67a1a7b116ff9e2d5027f3fdc0418b923e58eb5aa2ec632e057d363b415")

