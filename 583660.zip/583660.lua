-- Lua provided by RyzenAPI
-- Game: 583660

-- MAIN APPLICATION
addappid(583660)
-- Game: addappid(583660)

-- MAIN APP DEPOTS / PACKAGES
addappid(583661, 1, "9161c2edc861ad7e74181a13a8beff3b6be930c2d6256932f60fd4631c9c418d")
