-- Lua provided by RyzenAPI
-- Game: Game: AppID 818290

-- MAIN APPLICATION
addappid(818290)
-- Game: addappid(818290)

-- MAIN APP DEPOTS / PACKAGES
addappid(818291, 1, "813c3c3712bb4888ae27012b806373612a3abca6f7ca7db089eee27087bbc74f")
