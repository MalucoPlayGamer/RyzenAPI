-- Lua provided by RyzenAPI 
-- Game: Crashed Lander
addappid(340450)
addappid(340451, 1, "1f9255341b6f706f19863409fbdb452ef9a978c05d3ecba94b5ecc9071308d06")
addappid(340454, 1, "6f58455e97109a7c502a1e58699dbf365278dd3f2c1d890cdb8e64472165fc67")
