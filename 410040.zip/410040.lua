-- Lua provided by RyzenAPI
-- Game: Hope in Hell

-- MAIN APPLICATION
addappid(410040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(410041, 1, "4b25ec71a3fa304459e4215aa5c1765ec9e26ed0f9343e19832bcbeb25f89000")
