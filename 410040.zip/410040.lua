-- Lua provided by RyzenAPI
-- Game: 410040

-- MAIN APPLICATION
addappid(410040)
-- Game: addappid(410040)

-- MAIN APP DEPOTS / PACKAGES
addappid(410041, 1, "4b25ec71a3fa304459e4215aa5c1765ec9e26ed0f9343e19832bcbeb25f89000")
