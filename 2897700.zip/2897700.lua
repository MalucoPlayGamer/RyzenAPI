-- Lua provided by RyzenAPI
-- Game: Game: AppID 2897700

-- MAIN APPLICATION
addappid(2897700)
-- Game: addappid(2897700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897701, 1, "9e4f150ac9c2b03885a785aa128754100e92bbe743db1ca2d69a5aa9991251c7")
