-- Lua provided by RyzenAPI
-- Game: Obsolete

-- MAIN APPLICATION
addappid(1369560)
-- Game: addappid(1369560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369561, 1, "b531e1fc26b6dd6aeac5c7bf4c8f0519905d644ee161ff41d3f941e74d44b34c")
