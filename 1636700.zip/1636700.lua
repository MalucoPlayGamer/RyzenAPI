-- Lua provided by RyzenAPI 
-- Game: Wirewalk()↳
addappid(1636700)
addappid(1636701, 1, "bc5158c5e6c041850d5f721109cdcfd5dd9ea5021d033a598ba1024dd3a8f5de")
