-- Lua provided by RyzenAPI
-- Game: addappid(1061300)

-- MAIN APPLICATION
addappid(1061300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061301, 1, "0da87d191b40b6df983d3b9717cb04514dabf2d5b92f7983f765b6ced4e5f4c1")
