-- Lua provided by RyzenAPI
-- Game: Oboi

-- MAIN APPLICATION
addappid(3571700)
-- Game: addappid(3571700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3571701, 1, "1f5b0a96116b5c7bc3423606ef0836ef628b65039241223dc3d43ee0188aee1b")
