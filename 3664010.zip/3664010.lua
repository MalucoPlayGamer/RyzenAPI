-- Lua provided by RyzenAPI
-- Game: Drift Legends 2

-- MAIN APPLICATION
addappid(3664010)
addappid(3707410)
addappid(3707420)
addappid(3707430)
addappid(3707440)
addappid(3707450)
addappid(3707460)
addappid(4254810)
addappid(4915400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3664011,0,"ef87640da3a5d0168b16df271d9546ce064f52dce5c2fbc9aaa5f4e39073d76d")
addappid(3664012,0,"bc2208b6760edd5a07856b17c58810c09c26a7dbb10b61c9cf6c5db523680194")
addappid(3681930,0,"79c5bcaf0ff69532b9797d92ed672609592a1f53e35a1740c35a510f1f5589ad")

