-- Lua provided by RyzenAPI
-- Game: 3420790

-- MAIN APPLICATION
addappid(3420790)
-- Game: addappid(3420790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3420791, 1, "ed5771c1be8102700eeda14d421e73b0a370b9d995ea4609a3d9795201fc2c16")
