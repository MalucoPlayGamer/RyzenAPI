-- Lua provided by RyzenAPI
-- Game: Game: Concursion

-- MAIN APPLICATION
addappid(303340)
-- Game: addappid(303340)

-- MAIN APP DEPOTS / PACKAGES
addappid(303341, 1, "43542c4bb70bf3bf6b9c4487bbb4fe7887f1616526e8f8b8bc05825a268d6ecb")
addappid(303342, 1, "56343940b38623697347c308627510263b5a25c117da076e09fe80bf49d1b0a8")
