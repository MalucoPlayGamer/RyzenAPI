-- Lua provided by RyzenAPI
-- Game: 2690580

-- MAIN APPLICATION
addappid(2690580)
-- Game: addappid(2690580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690581, 1, "7ccd5ed7bf4b9208cc698b73f7ef04ea71c1cfe0aa5e741cbfe9da3d5b738fcd")
