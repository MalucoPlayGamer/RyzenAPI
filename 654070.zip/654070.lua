-- Lua provided by RyzenAPI
-- Game: 654070

-- MAIN APPLICATION
addappid(654070)
-- Game: addappid(654070)

-- MAIN APP DEPOTS / PACKAGES
addappid(654071, 1, "5342cb94443cd41e8edae655dea8c8932b5afff16b58f2da810fb5a7b106f22c")
