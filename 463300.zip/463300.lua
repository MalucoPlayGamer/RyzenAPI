-- Lua provided by SkyAPI 
-- Game: AppID 463300
addappid(463300)
addappid(463301, 1, "976c898fffe18cf4f683553a8c4521dc3fc06584959cbbc05c37346779c2d1f1")
