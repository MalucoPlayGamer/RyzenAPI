-- Lua provided by RyzenAPI
-- Game: AppID 1467950

-- MAIN APPLICATION
addappid(1467950)
-- Game: addappid(1467950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467951, 1, "26ce1c294127573fc605580146c2adbe05c8758b3bc961eeb6c2d9453d90916f")
