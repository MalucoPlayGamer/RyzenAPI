-- Lua provided by RyzenAPI
-- Game: AppID 1229030

-- MAIN APPLICATION
addappid(1229030)
-- Game: addappid(1229030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229031, 1, "e04b949a96371aaf694d530f174e482a8b9d9792092abb6a605ecaf2a59561d5")
