-- Lua provided by SkyAPI 
-- Game: AppID 1229030
addappid(1229030)
addappid(1229031, 1, "e04b949a96371aaf694d530f174e482a8b9d9792092abb6a605ecaf2a59561d5")
