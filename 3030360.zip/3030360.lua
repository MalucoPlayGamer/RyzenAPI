-- Lua provided by RyzenAPI
-- Game: addappid(3030360)

-- MAIN APPLICATION
addappid(3030360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3030362,0,"7030120465b819a52103de650970f5cc2e1da5bc3bc4ceb9246eba6b5e63f5a7")
