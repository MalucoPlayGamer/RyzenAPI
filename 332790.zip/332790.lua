-- Lua provided by RyzenAPI
-- Game: Darkness Assault

-- MAIN APPLICATION
addappid(332790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(332791, 1, "8043888041d5efed1e19f8320093143f9c9a3201c55f3c9d9d3e63c35f144440")
addappid(339430, 0, "e346bca7d15ee50495a5e86a015646b720167b4661a28a850cd83cebe0cd192b")
addappid(369470, 0, "2da211708e808feceef8ea2307858c21b922dc9ba305e4acbccdc4eb46a7e0ab")
addappid(369610, 0, "df80089ef39dbc99017f491b9f2e75c8773bb50bd88c3419d4c800a67bc23a91")

