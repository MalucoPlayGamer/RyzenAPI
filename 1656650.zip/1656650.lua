-- Lua provided by SkyAPI 
-- Game: Express Simulator
addappid(1656650)
addappid(1656651, 1, "138e869aa4900032132fc168161d94c6c00fe19381cf460f65e28030c339e477")
