-- Lua provided by RyzenAPI
-- Game: Express Simulator

-- MAIN APPLICATION
addappid(1656650)
-- Game: addappid(1656650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656651, 1, "138e869aa4900032132fc168161d94c6c00fe19381cf460f65e28030c339e477")
