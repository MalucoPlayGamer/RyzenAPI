-- Lua provided by RyzenAPI
-- Game: addappid(1410110)

-- MAIN APPLICATION
addappid(1410110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410111, 1, "2cda8ce250670e38c9b04d5f2ce48b6f228a89c96c5f7047d105ab620ab8dacd")
