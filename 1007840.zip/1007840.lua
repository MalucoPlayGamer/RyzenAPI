-- Lua provided by RyzenAPI
-- Game: Wanking Simulator

-- MAIN APPLICATION
addappid(1007840)
addappid(1261340)
-- Game: addappid(1007840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007841, 1, "e4d276532947458dbc875d7c6d9f13e6a911eb5d318eb9a50e0352705b1a3265")
