-- Lua provided by SkyAPI 
-- Game: Fragile Reflection Demo
addappid(3111440)
addappid(3111441, 1, "8bd23cde59ee4f96eb3cdbbac604b2a2128441f896d5973763c8a3502718a838")
