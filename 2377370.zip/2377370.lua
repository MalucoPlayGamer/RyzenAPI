-- Lua provided by RyzenAPI
-- Game: Wrapturous Adventure (A Yuri BDSM-Theme Game) Demo

-- MAIN APPLICATION
addappid(2377370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377371, 1, "12dc2dd176694dd482069fd858d07ed822a857dd6bf52f01cf03b808fc7a7a69")

