-- Lua provided by RyzenAPI
-- Game: New Frontier Days ~Founding Pioneers~

-- MAIN APPLICATION
addappid(570790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(570791,0,"e2867c30804911885a416f5b926e8745ec584e28ad79d5b978718d9af0e9d692")

