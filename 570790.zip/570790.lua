-- Lua provided by RyzenAPI
-- Game: New Frontier Days ~Founding Pioneers~

-- MAIN APPLICATION
addappid(570790)

-- MAIN APP DEPOTS / PACKAGES
addappid(570791,0,"e2867c30804911885a416f5b926e8745ec584e28ad79d5b978718d9af0e9d692")

