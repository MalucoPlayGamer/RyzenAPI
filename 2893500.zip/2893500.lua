-- Lua provided by RyzenAPI
-- Game: Beat Saber - Grandmaster Flash & The Furious Five - "The Message"

-- MAIN APPLICATION
addappid(2893500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893500,0,"f0cb06548c5ce142ae628348990da820f5234b7ee891897991648dca24d5e84a")

