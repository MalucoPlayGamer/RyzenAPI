-- Lua provided by RyzenAPI
-- Game: 2886090

-- MAIN APPLICATION
addappid(2886090)
-- Game: addappid(2886090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2886091, 1, "748c3cf843ff66cdf4f1b2fcb2f16166fbed77f506e0dbac85d33a24fb9c5db9")
