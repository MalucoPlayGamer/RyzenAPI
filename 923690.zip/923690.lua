-- Lua provided by RyzenAPI
-- Game: Game: Hacker.exe

-- MAIN APPLICATION
addappid(923690)
-- Game: addappid(923690)

-- MAIN APP DEPOTS / PACKAGES
addappid(923691, 1, "0be3881c82756017a35265655f15a8c0d8840a4c73d00b7644a3327994db6e82")
