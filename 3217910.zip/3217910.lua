-- Lua provided by RyzenAPI
-- Game: Dirty Fantasy

-- MAIN APPLICATION
addappid(3217910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3217911, 1, "6c90f54398b959656334b80ab8cc5b7cf05e8b336373d2ec1d222a1b482d435f")

