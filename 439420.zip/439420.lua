-- Lua provided by RyzenAPI
-- Game: addappid(439420)

-- MAIN APPLICATION
addappid(439420)
addappid(581940)

-- MAIN APP DEPOTS / PACKAGES
addappid(439421, 1, "4075c3fd30c91f8ee7d1b49e2d8ca15fca57505d21214d62da1313c535134de2")
