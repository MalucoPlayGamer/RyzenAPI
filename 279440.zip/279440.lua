-- Lua provided by RyzenAPI
-- Game: Game: Joe Dever's Lone Wolf HD Remastered

-- MAIN APPLICATION
addappid(279440)
-- Game: addappid(279440)

-- MAIN APP DEPOTS / PACKAGES
addappid(279441, 1, "a6b44e8d726d3ce335badf397336d8996593b0bb069e06c5a38559670ce9a537")
addappid(279443, 1, "a820ac17afeb17871eca7ae69892630cb06d5d61d1babc28a57c3f0e9cbcd96a")
