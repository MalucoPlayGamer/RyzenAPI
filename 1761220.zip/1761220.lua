-- Lua provided by RyzenAPI
-- Game: Game: Prosperous Universe

-- MAIN APPLICATION
addappid(1761220)
-- Game: addappid(1761220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761221, 1, "353e7317d8dd483118f053ec502590f521a90a027695770e06689dc59ef55a04")
addappid(1761222, 1, "7cce663ca13db267a21644ff9aecfa5b25475c7d451c679a40bd381ac565d0f2")
