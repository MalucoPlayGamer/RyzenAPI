-- Lua provided by RyzenAPI
-- Game: DFF NT: Ardyn Izunia Starter Pack

-- MAIN APPLICATION
addappid(1213330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213330,0,"c98868a1a7e6957aa0c70259cf3dfeb15ab7a8d196c24a3b8bd750dbe54e5ff0")

