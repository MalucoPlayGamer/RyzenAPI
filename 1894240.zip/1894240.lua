-- Lua provided by RyzenAPI
-- Game: AppID 1894240

-- MAIN APPLICATION
addappid(1894240)
-- Game: addappid(1894240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894241, 1, "c57ca8b38df4c0553a7c81ab271e390d1fad316d8bcd6481ec346b5346c14e32")
