-- Lua provided by RyzenAPI
-- Game: Hector: Episode 2

-- MAIN APPLICATION
addappid(94610)

-- MAIN APP DEPOTS / PACKAGES
addappid(94611, 1, "ec152a106a6578bc750e8d66c20dd4c373fdffe0690c036e6a40251a8561aaa6")
addappid(94612, 1, "a003572b83e1b2c6632e4a18cd11be686b4987509863af20977ecd3b8db6a2aa")

