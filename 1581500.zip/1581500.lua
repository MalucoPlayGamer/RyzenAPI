-- Lua provided by RyzenAPI
-- Game: Game: Dragon Drop

-- MAIN APPLICATION
addappid(1581500)
-- Game: addappid(1581500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581501, 1, "1655545b24a2c2104e58381bd5439c670cf196f84673f8ac224b3635f7670f21")
