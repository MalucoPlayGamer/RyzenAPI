-- Lua provided by RyzenAPI 
-- Game: Trap Legend
addappid(1226530)
addappid(1226531, 1, "70850b01cec43e33ec6a1f3b875809dda3d1dd240a76bfd9a873de43f7612a67")
