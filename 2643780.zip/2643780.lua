-- Lua provided by RyzenAPI
-- Game: ◒ Achievement Shades

-- MAIN APPLICATION
addappid(2643780)
-- Game: addappid(2643780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643781, 1, "826720001871ff2f91cb925478df8bc393ecf708a0299be98c9916a8ae1d610b")
