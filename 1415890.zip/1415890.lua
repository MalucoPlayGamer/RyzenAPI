-- Lua provided by RyzenAPI 
-- Game: Hot Robot
addappid(1415890)
addappid(1415891, 1, "ffe424c8af30fe1e3e8e9561e9b02d5c9fd4bfd066f31b378ec4105a482291cc")
