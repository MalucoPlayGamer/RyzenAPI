-- Lua provided by RyzenAPI
-- Game: Darkness Within 2: The Dark Lineage

-- MAIN APPLICATION
addappid(298950)
addappid(414640)

-- MAIN APP DEPOTS / PACKAGES
addappid(298951, 1, "922ae44b61f249537d1869d180edbb91e460e41cac58dff32b6f337dca9e3b4a")
addappid(298952, 1, "fc03d600a366df6638f81af0cf86c4b6f62afe4e9ca772be9545b0bdc3dee86e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
