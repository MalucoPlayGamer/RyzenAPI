-- Lua provided by RyzenAPI
-- Game: Darkness Within 2: The Dark Lineage

-- MAIN APPLICATION
addappid(298950)
addappid(414640)

-- MAIN APP DEPOTS / PACKAGES
addappid(298951, 1, "922ae44b61f249537d1869d180edbb91e460e41cac58dff32b6f337dca9e3b4a")
addappid(298952, 1, "fc03d600a366df6638f81af0cf86c4b6f62afe4e9ca772be9545b0bdc3dee86e")
