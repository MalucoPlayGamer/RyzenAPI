-- Lua provided by RyzenAPI
-- Game: AppID 454540

-- MAIN APPLICATION
addappid(454540)
-- Game: addappid(454540)

-- MAIN APP DEPOTS / PACKAGES
addappid(454541, 1, "3496057393c6259b65bcbc2eda8671ce93c0246c200fe6854d89e117a4d303d0")
