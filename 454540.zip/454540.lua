-- Lua provided by RyzenAPI
-- Game: AppID 454540

-- MAIN APPLICATION
addappid(454540)

-- MAIN APP DEPOTS / PACKAGES
addappid(454541, 1, "3496057393c6259b65bcbc2eda8671ce93c0246c200fe6854d89e117a4d303d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
