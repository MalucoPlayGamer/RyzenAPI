-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2399330)
-- Game: addappid(2399330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399333,0,"a922cd7cd42f5a333ad760b2029b8894ea28a3077dd6e41df15ca6cc3f93b8ae")
addappid(2399334,0,"57aabca3caf1c34a00d7ecde1d68b27ea157662ba10990fd14d6b095269977c5")
