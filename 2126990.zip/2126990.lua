-- Lua provided by RyzenAPI
-- Game: Lost World

-- MAIN APPLICATION
addappid(2126990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126991, 1, "0207b0a764013f4debaece4a03c8250fe82ce1d9b35dc501ace0c6f0a093cb28")

