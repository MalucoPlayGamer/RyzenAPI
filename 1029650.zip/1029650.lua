-- Lua provided by RyzenAPI
-- Game: AppID 1029650

-- MAIN APPLICATION
addappid(1029650)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1029651, 1, "d0725dfed815a5c30a7af994922903e073c6519d18ec25b4ed14f0445eaa3626")

