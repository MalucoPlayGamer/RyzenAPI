-- Lua provided by RyzenAPI
-- Game: addappid(1029650)

-- MAIN APPLICATION
addappid(1029650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029651, 1, "d0725dfed815a5c30a7af994922903e073c6519d18ec25b4ed14f0445eaa3626")
