-- Lua provided by RyzenAPI
-- Game: Kemopop!

-- MAIN APPLICATION
addappid(3093590)
-- Game: addappid(3093590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3093591, 1, "bb1643f6f7a3b4bd4f286d307082298064737c237f7cd8a8546dc399590f82d7")
