-- Lua provided by RyzenAPI
-- Game: Warborne Above Ashes

-- MAIN APPLICATION
addappid(3142050)

