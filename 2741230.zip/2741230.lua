-- Lua provided by RyzenAPI
-- Game: Game: Forest Of Perdition

-- MAIN APPLICATION
addappid(2741230)
-- Game: addappid(2741230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741231, 1, "94b73a1071722ff1cfa1f07842b1de88466730c4d0cc725272b3103dbf9ff284")
