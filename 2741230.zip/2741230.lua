-- Lua provided by RyzenAPI
-- Game: Forest Of Perdition

-- MAIN APPLICATION
addappid(2741230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741231, 1, "94b73a1071722ff1cfa1f07842b1de88466730c4d0cc725272b3103dbf9ff284")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
