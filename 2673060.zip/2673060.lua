-- Lua provided by RyzenAPI
-- Game: Moi Moi Heroes

-- MAIN APPLICATION
addappid(2673060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2673061, 1, "9b2106b7c309539170fce0a97c0cdef7305e8f82974eb4e38494b10d679a2af4")
