-- Lua provided by RyzenAPI
-- Game: Game: AppID 2673060

-- MAIN APPLICATION
addappid(2673060)
-- Game: addappid(2673060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673061, 1, "9b2106b7c309539170fce0a97c0cdef7305e8f82974eb4e38494b10d679a2af4")
