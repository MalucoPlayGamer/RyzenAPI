-- Lua provided by RyzenAPI
-- Game: 2022090

-- MAIN APPLICATION
addappid(2022090)
-- Game: addappid(2022090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022091, 1, "487640ebaba04f23c74e978a841d3b9c0ecc36d7d8c1916bfd68961e99408c85")
