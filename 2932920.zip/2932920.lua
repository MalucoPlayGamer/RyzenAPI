-- Lua provided by RyzenAPI
-- Game: addappid(2932920)

-- MAIN APPLICATION
addappid(2932920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932921, 1, "561e72cda6835a9a6a92d30d8a2aab5422236c2cfc5291745d209ba899631c01")
