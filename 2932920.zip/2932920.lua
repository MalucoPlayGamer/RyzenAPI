-- Lua provided by RyzenAPI
-- Game: AppID 2932920

-- MAIN APPLICATION
addappid(2932920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2932921, 1, "561e72cda6835a9a6a92d30d8a2aab5422236c2cfc5291745d209ba899631c01")

