-- Lua provided by RyzenAPI
-- Game: Weed Shop 3

-- MAIN APPLICATION
addappid(1182110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182111, 1, "38f0e134e58c497af8b56f60d883e2eb42e086707e881070e966ed413d718fe4")

