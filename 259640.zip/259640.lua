-- Lua provided by RyzenAPI
-- Game: Game: Guise Of The Wolf

-- MAIN APPLICATION
addappid(259640)
-- Game: addappid(259640)

-- MAIN APP DEPOTS / PACKAGES
addappid(259641, 1, "585308efc6126a326ec09d1f42d84d243a790d731fa07f50b8a0f2e0e465c546")
addappid(259642, 1, "3ec63970f15465a7ca29f2548f894f9af4e054e79b0f052aaa947250146c11a6")
addappid(259643, 1, "ef55643f948c79a8765a93c331b5bf20ce912cff2a29f38811f8d6857f954f3d")
