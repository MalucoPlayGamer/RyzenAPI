-- Lua provided by RyzenAPI
-- Game: AppID 514360

-- MAIN APPLICATION
addappid(514360)

-- MAIN APP DEPOTS / PACKAGES
addappid(514361, 1, "01064d2dec6dbd20694274f8d0c98fe66eef7d8e2cbb5d852e60360f69c37d51")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
