-- Lua provided by RyzenAPI
-- Game: AppID 514360

-- MAIN APPLICATION
addappid(514360)

-- MAIN APP DEPOTS / PACKAGES
addappid(514361, 1, "01064d2dec6dbd20694274f8d0c98fe66eef7d8e2cbb5d852e60360f69c37d51")
