-- Lua provided by RyzenAPI
-- Game: 1243960

-- MAIN APPLICATION
addappid(1243960)
-- Game: addappid(1243960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243961, 1, "7aebeffe9f73689183b6674be54492a1f835e508f144bd65d8d558928e23b606")
