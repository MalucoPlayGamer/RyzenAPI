-- Lua provided by RyzenAPI
-- Game: addappid(2505790)

-- MAIN APPLICATION
addappid(2505790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505791, 1, "34577a6ff0d0bd21ca6e22c81801f3ac67addc4febca7685f588bc8f80f9b8b7")
