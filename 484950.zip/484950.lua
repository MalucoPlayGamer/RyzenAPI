-- Lua provided by RyzenAPI
-- Game: Game: 恶魔迷宫 | Evil Maze

-- MAIN APPLICATION
addappid(484950)
-- Game: addappid(484950)

-- MAIN APP DEPOTS / PACKAGES
addappid(484951, 1, "2bf103a4a04f3fcbe3c491a0c7fa63aeff6553d0218018530da353713fab95a5")
addappid(498520, 0, "601ced4055a125fc2f66b5123366d0dc5761180c744a96fb0d912a913b430923")
addappid(498540, 0, "a8de0b4707a14cefa7febfcd9023f2ae7dd731b70129350553aa7850ee8745d7")
addappid(996300, 0, "4352dd6faced81c4a4bf7dd5f54aeb1ace4c706e294f18eb71604292ba6a8156")
addappid(1323720, 0, "6a4bcc6b7cbc5e32831746d94419f0dcf07719fbf7302b67dcd7f7e41f4c286f")
