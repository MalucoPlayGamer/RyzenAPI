-- Lua provided by RyzenAPI
-- Game: Marvel's Midnight Suns

-- MAIN APPLICATION
addappid(368260)
addappid(1712442)
addappid(1922631)
addappid(1922632)
addappid(1922633)
addappid(1922634)
addappid(2074340)
addappid(2100870)
addappid(2100871)

-- MAIN APP DEPOTS / PACKAGES
addappid(368261, 1, "70e0c68fc7e9ff3b4054bcfda8648cae98efa3b3905a29d91c2eaeee83dd9b21")
addappid(1523211, 0, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
