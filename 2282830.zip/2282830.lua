-- Lua provided by RyzenAPI
-- Game: addappid(2282830)

-- MAIN APPLICATION
addappid(2282830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282831, 1, "aba9c5378b9b289ca44020823bc91a01ec95eb56a3d9e2c3ffc5b4dc2ebbe417")
