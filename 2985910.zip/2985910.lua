-- Lua provided by RyzenAPI
-- Game: Game: Survivors Of The Zombie World

-- MAIN APPLICATION
addappid(2985910)
-- Game: addappid(2985910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985911, 1, "4f27208bbde696c31fc2bca0b936fd0ad9f7d672c935707e19733b0bb05b07c0")
