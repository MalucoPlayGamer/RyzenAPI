-- Lua provided by RyzenAPI
-- Game: Yokai Taiji

-- MAIN APPLICATION
addappid(1614020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614022,0,"d2ecb63152f7eb95e687ec3473b9528d3e3c24296315791f5868d8dfe8612d6c")

