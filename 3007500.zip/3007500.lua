-- Lua provided by SkyAPI 
-- Game: Dark Hunting Ground Demo
addappid(3007500)
addappid(3007501, 1, "83ba0ae52365aa9e1a1395ad55f1353a153d6dd85960d24c2b59d78a7fde6080")
