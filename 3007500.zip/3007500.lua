-- Lua provided by RyzenAPI
-- Game: Game: Dark Hunting Ground Demo

-- MAIN APPLICATION
addappid(3007500)
-- Game: addappid(3007500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007501, 1, "83ba0ae52365aa9e1a1395ad55f1353a153d6dd85960d24c2b59d78a7fde6080")
