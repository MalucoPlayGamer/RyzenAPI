-- Lua provided by RyzenAPI
-- Game: Game: AppID 1268090

-- MAIN APPLICATION
addappid(1268090)
-- Game: addappid(1268090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268091, 1, "219841723bb3d51b62c218fe836dff3b35fc7f56d9d97bf332c4ff3273d227f7")
