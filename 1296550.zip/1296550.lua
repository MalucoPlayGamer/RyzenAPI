-- Lua provided by RyzenAPI
-- Game: Altidudes®

-- MAIN APPLICATION
addappid(1296550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296551, 1, "bd13f72a88e95f466861e3e9b9207cbfe4c743a00505edc3025baf50f45fc86b")

