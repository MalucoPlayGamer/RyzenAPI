-- Lua provided by RyzenAPI
-- Game: 662330

-- MAIN APPLICATION
addappid(662330)
-- Game: addappid(662330)

-- MAIN APP DEPOTS / PACKAGES
addappid(662331, 1, "cb8a5c9151111da5d9e22c8a14dc1cacc4d51f2072668518ab3eea9fc9e0690f")
