-- Lua provided by RyzenAPI
-- Game: We Become What We Behold

-- MAIN APPLICATION
addappid(1103210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103211, 1, "880156295a8f6a1e1bcd9bc0ecc97ff10310964358f6d13f26f3ffe17f2bd865")
addappid(1103212, 1, "f65b584a508a25de41672668d9e919f273c8d99c49c2b4a074f3226534296fec")

