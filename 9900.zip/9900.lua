-- Lua provided by SkyAPI 
-- Game: Star Trek Online
addappid(9900)
addappid(9901, 1, "2d4cd228cc33a7b0c0b8783c3d35a36039f34ba4f25c954ef7316582ad741f1f")
addappid(228990, 0, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
