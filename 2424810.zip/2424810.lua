-- Lua provided by RyzenAPI
-- Game: Lost at Birth

-- MAIN APPLICATION
addappid(2424810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424811, 1, "8b49861258d40f24022bbb72ffdaca4e75acb52974e4a695ea0227a4b8050cf1")
