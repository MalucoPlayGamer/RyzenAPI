-- Lua provided by RyzenAPI
-- Game: Game: Touhou: New World - Original Soundtrack

-- MAIN APPLICATION
addappid(2487820)
-- Game: addappid(2487820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487821, 1, "4190570d6881aaa6f59fb580ca2c8950e7484f399c80e3b647cdcb6652e4b748")
addappid(2487822, 1, "3a8465cc63a452d9fa8fee22faed0c11a7ffaec389331511b0f818a40c3d5b58")
