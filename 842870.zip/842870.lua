-- Lua provided by RyzenAPI
-- Game: Lords of Strife

-- MAIN APPLICATION
addappid(842870)

-- MAIN APP DEPOTS / PACKAGES
addappid(842871,0,"ffaee59e6044273733e1a15508415c7ab2537d1ed04a1178c2e37ec7d9ead90b")
addappid(842872,0,"34b63943556cb032eb34435db712cf6b933cbfe961732fcf49fc6a20753a6d08")

