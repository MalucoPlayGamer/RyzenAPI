-- Lua provided by RyzenAPI
-- Game: Super Gear Quest

-- MAIN APPLICATION
addappid(545880)

-- MAIN APP DEPOTS / PACKAGES
addappid(545881, 1, "4ea74506e9d4afb1b33105acc35cc6c60b48e19d3f47477995a8f442415453ba")
