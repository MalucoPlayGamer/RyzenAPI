-- Lua provided by RyzenAPI
-- Game: KovaaK's

-- MAIN APPLICATION
addappid(824270)
addappid(1438210)
addappid(2633870)

-- MAIN APP DEPOTS / PACKAGES
addappid(824271, 1, "eb3bfa996ec2fa95ac46deb12cac451a680c017946edfb52209740273157dd1c")
