-- Lua provided by RyzenAPI
-- Game: KovaaK's

-- MAIN APPLICATION
addappid(824270)
addappid(1438210)
addappid(2633870)

-- MAIN APP DEPOTS / PACKAGES
addappid(824271, 1, "eb3bfa996ec2fa95ac46deb12cac451a680c017946edfb52209740273157dd1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
