-- Lua provided by RyzenAPI
-- Game: addappid(2435570)

-- MAIN APPLICATION
addappid(2435570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435571, 1, "de8142212ad526e506e3b968b1bc8d9ac1d9c25d662872fdacf9e57ee2e25524")
