-- Lua provided by RyzenAPI
-- Game: Resident Evil: Operation Raccoon City

-- MAIN APPLICATION
addappid(209100)
addappid(210010)
-- Game: addappid(209100)

-- MAIN APP DEPOTS / PACKAGES
addappid(209101, 1, "0cb75133d130a7f7e5291ee1f5324f3eb890004c910cec3777467cbeb4d95840")
addappid(210011, 0, "1dbe894edc1b1c111f6f7156c42b1ff91a94ef953210399bbc345a9b76d287cf")
addappid(210012, 0, "b66f99c08b15b07edaab9c45a6bddcecbda138e31c6136c9d9543278ff7cab7a")
addappid(210013, 0, "11a1d2d64ee443e4ac618d9c0d424ee6d68bb830034f70c6b33e455d5c7b4d28")
addappid(210014, 0, "ae16d95c7e1b1cb592a2256129cb9c3ab82d9c1c0e6b490cf6c1c5b9a741b9c0")
addappid(210015, 0, "5d91d23e61ddb257ac0fd2902243f3c45d2d52104361cb9492487ceb235ea014")
addappid(210016, 0, "f26ba9e157c543c4b85a9fc7752522028eb99b1ab154f8c7cd573a10d420a8eb")
addappid(210017, 0, "7cc5209e5fa52feca4047b105ad0a3d9762e8a104ef91f64469c6ab8cdd2233c")
addappid(210018, 0, "38daf59157cd92a5da021ac4bdfead8f1e6221cdd7d8626589ff842a05e74b9a")
addappid(210019, 0, "be0a09b9ce70a9f38db057df6085b3d644d941a9c31595ca64bebd86ac0a1671")
