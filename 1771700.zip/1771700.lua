-- Lua provided by RyzenAPI
-- Game: Vaygren - Lustful Temptation

-- MAIN APPLICATION
addappid(1771700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771701, 1, "59a1fc62e34fe007d5c485f46989980cb731d3f87219d035efe5db869bff31bc")
