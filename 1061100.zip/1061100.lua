-- Lua provided by RyzenAPI
-- Game: Game: AppID 1061100

-- MAIN APPLICATION
addappid(1061100)
-- Game: addappid(1061100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061101, 1, "539a08464cd3b951d8c97a487c19fa279639b092439fbcec91dac473bbc0210d")
