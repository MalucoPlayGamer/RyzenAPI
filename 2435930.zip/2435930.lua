-- Lua provided by SkyAPI 
-- Game: .
addappid(2435930)
addappid(2435931, 1, "bf749dcb476defef1a6423314469208b9d3aedb45eb8993e8d835266fd0d3331")
