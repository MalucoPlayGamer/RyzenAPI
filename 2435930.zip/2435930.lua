-- Lua provided by RyzenAPI
-- Game: .

-- MAIN APPLICATION
addappid(2435930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435931, 1, "bf749dcb476defef1a6423314469208b9d3aedb45eb8993e8d835266fd0d3331")

