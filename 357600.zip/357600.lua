-- Lua provided by RyzenAPI
-- Game: Game: Unium

-- MAIN APPLICATION
addappid(357600)
-- Game: addappid(357600)

-- MAIN APP DEPOTS / PACKAGES
addappid(357601, 1, "389e9deddd8ecb76459af79bdd8319c896467d7c53fb42ffb7998306d2c8e68c")
addappid(357602, 1, "ea9ce627ac8a488e838e43cb24064ee76012e61bf5c2ff45f87187c327bc6db4")
addappid(357603, 1, "c5903f56343138ed4760f2d3ef5e0e1ed379bb30ec879c9a7a1a0ea39f6a4c2f")
