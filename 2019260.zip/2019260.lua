-- Lua provided by RyzenAPI
-- Game: PARADISE CLEANING -Me and my Doctor's life in the hospital-

-- MAIN APPLICATION
addappid(2019260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019261, 1, "e38362dcf1a4f43807f0fe92837d56561f109ea8cbd2a112cdeeee2669cec7f3")

