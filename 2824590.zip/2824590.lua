-- Lua provided by RyzenAPI
-- Game: Burning Sword Death Sun Demo

-- MAIN APPLICATION
addappid(2824590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824591, 1, "431f643492d995f38a0e7c40654618c6c158cc16a965f2d74a702202e97dd5ea")

