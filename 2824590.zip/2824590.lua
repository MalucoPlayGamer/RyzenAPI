-- Lua provided by SkyAPI 
-- Game: AppID 2824590
addappid(2824590)
addappid(2824591, 1, "431f643492d995f38a0e7c40654618c6c158cc16a965f2d74a702202e97dd5ea")
