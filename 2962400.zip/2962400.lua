-- Lua provided by RyzenAPI
-- Game: Operation Darkside DX

-- MAIN APPLICATION
addappid(2962400)
addappid(4878230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962401,0,"87f9772ed9ec17f8d2574bdfbfc6338d3750ed933b2d3bfc167a171b173bafcb")
addappid(4878231,0,"d11d6d28db110d8760830f81aa790ad6ef577752c7239b59b5b91f328650b06e")

