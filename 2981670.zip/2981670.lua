-- Lua provided by RyzenAPI
-- Game: Game: The King is Watching Demo

-- MAIN APPLICATION
addappid(2981670)
-- Game: addappid(2981670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981671, 1, "1b58e14d917a10caa557452bb38b652fa76224989c771f61c5356eb1227ba1f5")
