-- Lua provided by SkyAPI 
-- Game: Pestilence
addappid(2639350)
addappid(2639351, 1, "01a761cb231da5310322c20db34dc2a305409fc33cdb02133ef6ec61214b6402")
