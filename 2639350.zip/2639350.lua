-- Lua provided by RyzenAPI
-- Game: Pestilence

-- MAIN APPLICATION
addappid(2639350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2639351, 1, "01a761cb231da5310322c20db34dc2a305409fc33cdb02133ef6ec61214b6402")

