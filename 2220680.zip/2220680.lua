-- Lua provided by RyzenAPI
-- Game: 丸转三国

-- MAIN APPLICATION
addappid(2220680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220681, 1, "1494df5e22e1e5c5204d0d74c45fc0bc76a4e3828124fe362f6c998376d539a8")
