-- Lua provided by RyzenAPI
-- Game: Zombie Scrapper

-- MAIN APPLICATION
addappid(997170)
addappid(997171)

-- MAIN APP DEPOTS / PACKAGES
addappid(997172,0,"c89e9584443ce779e930ef9f650ee6b840dbecae1e4b34608ff682945a795d2d")
addappid(997173,0,"2593487df27eac21e7dc028a7959dd50ae037aa5d3b3fd3dbe5738e278b7fd4f")
addappid(997174,0,"77b06fa6f495dbad41c4cbecaa4d7a413d62014e8ba53f5093e35a89a596a489")
addappid(997175,0,"d54f09d76b56d1542a8716dd51d011b018e4fa1b7e35c55f45a6e1401bae6cfb")
addappid(997176,0,"9e6566a0990604324e519b04ea01d67090a7a182b70e83f5c78c257d66d269c3")

