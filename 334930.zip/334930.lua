-- Lua provided by RyzenAPI
-- Game: The Ingenious Machine: New and Improved Edition

-- MAIN APPLICATION
addappid(334930)

-- MAIN APP DEPOTS / PACKAGES
addappid(334932,0,"55cc6ac4dd878c1951d466c4d07182627468a8c22e8a4c5a104640009340998f")
addappid(334933,0,"a6787116b7654a063d4e1de470ed2eb261bf9dc0de465860d0975c298b10b885")

