-- Lua provided by RyzenAPI 
-- Game: Mayjasmine Episode01 - What is God?
addappid(417110)
addappid(417111, 1, "46641f809a766ef5fd6c037f2fef2f7d484cf9b28cf8c7540af565199c83cf18")
addappid(417112, 1, "0869f35510968814944e8de40e67a3a63727d45eaa5c6a8db22e629e28e52761")
