-- Lua provided by RyzenAPI
-- Game: Alone

-- MAIN APPLICATION
addappid(871870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(871871, 1, "103d37157307e50ca5d8c629ea2eb47cd46322343d81e544ff7cff7faf1e7804")

