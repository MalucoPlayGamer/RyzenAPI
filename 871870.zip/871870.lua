-- Lua provided by RyzenAPI
-- Game: Alone

-- MAIN APPLICATION
addappid(871870)
-- Game: addappid(871870)

-- MAIN APP DEPOTS / PACKAGES
addappid(871871, 1, "103d37157307e50ca5d8c629ea2eb47cd46322343d81e544ff7cff7faf1e7804")
