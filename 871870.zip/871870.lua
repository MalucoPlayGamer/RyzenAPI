-- Lua provided by SkyAPI 
-- Game: Alone
addappid(871870)
addappid(871871, 1, "103d37157307e50ca5d8c629ea2eb47cd46322343d81e544ff7cff7faf1e7804")
