-- Lua provided by RyzenAPI
-- Game: 2991720

-- MAIN APPLICATION
addappid(2991720)
-- Game: addappid(2991720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2991721, 1, "326458961626ecb4ab0d0b14ebeb80a4fb6915334ebc6f272a6e5a74ec30e881")
