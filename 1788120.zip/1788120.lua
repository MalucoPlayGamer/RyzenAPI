-- Lua provided by RyzenAPI
-- Game: French Crime Detective Game

-- MAIN APPLICATION
addappid(1788120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788121, 1, "864c6b46a46ab99117334a7b93ea238592e12e7f020e11d146e1cd0bfaf9466e")

