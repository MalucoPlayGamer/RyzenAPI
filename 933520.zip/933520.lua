-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Wu Pack 1

-- MAIN APPLICATION
addappid(933520)

-- MAIN APP DEPOTS / PACKAGES
addappid(933520,0,"b139279cbaf261841f15fad53e564315f4d91d550483e16c1585c326f976bf30")

