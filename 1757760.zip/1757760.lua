-- Lua provided by RyzenAPI
-- Game: My Stepsis is a Futanari

-- MAIN APPLICATION
addappid(1757760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757761, 1, "348c6380529f98559ad226f214886274884bb148159f202470ec5b2c3fd67ae5")

