-- Lua provided by RyzenAPI
-- Game: Godumas

-- MAIN APPLICATION
addappid(2006730)
-- Game: addappid(2006730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2006731, 1, "6747248689197db34e959bb8715c409e6db08ef58fb269aef1cbcfa776ea09b2")
