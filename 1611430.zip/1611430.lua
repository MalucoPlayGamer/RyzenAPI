-- Lua provided by RyzenAPI
-- Game: The Bridge Curse Road to Salvation

-- MAIN APPLICATION
addappid(1611430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611431, 1, "8fdf1fee2f7e0022f277fb2cb92c46cc68dc86bdbf8f0c0921ecfc81f29a4fa4")
addappid(2022750, 0, "e086b181400e8c49125bea5d968beb91b97cb2e54cef534a0282f15c533f1b66")
