-- Lua provided by RyzenAPI
-- Game: The Bridge Curse Road to Salvation

-- MAIN APPLICATION
addappid(1611430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611431, 1, "8fdf1fee2f7e0022f277fb2cb92c46cc68dc86bdbf8f0c0921ecfc81f29a4fa4")
addappid(2022750, 0, "e086b181400e8c49125bea5d968beb91b97cb2e54cef534a0282f15c533f1b66")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
