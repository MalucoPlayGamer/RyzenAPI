-- Lua provided by RyzenAPI
-- Game: addappid(517790)

-- MAIN APPLICATION
addappid(517790)

-- MAIN APP DEPOTS / PACKAGES
addappid(517791, 1, "c9aab3317d0bfd856c63b770a78890744d1fe10e169f001992974eb277ac3744")
