-- Lua provided by RyzenAPI
-- Game: EXCHANGE

-- MAIN APPLICATION
addappid(854400)

-- MAIN APP DEPOTS / PACKAGES
addappid(854401,0,"e5ea213ec70da381a41e0c1144bff0837affba48f7ea47ecfa126bd2512daffc")

