-- Lua provided by RyzenAPI
-- Game: Lovecraft's Untold Stories 2

-- MAIN APPLICATION
addappid(1401400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1401401, 1, "053cc9fb6e5d7339eb0dcd160d2d2da7b762b373d3dd574956f70cd5ee3b9ac3")

