-- Lua provided by RyzenAPI 
-- Game: Lovecraft's Untold Stories 2
addappid(1401400)
addappid(1401401, 1, "053cc9fb6e5d7339eb0dcd160d2d2da7b762b373d3dd574956f70cd5ee3b9ac3")
