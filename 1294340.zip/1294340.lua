-- Lua provided by RyzenAPI
-- Game: addappid(1294340)

-- MAIN APPLICATION
addappid(1294340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1294341, 1, "3255f515b4ab238e134bc8c3e708a51bbd8f6341849824565a80de0353bd4b7b")
