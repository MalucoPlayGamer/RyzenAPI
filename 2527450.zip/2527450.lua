-- Lua provided by RyzenAPI
-- Game: Nie No Hakoniwa - Dollhouse of Offerings

-- MAIN APPLICATION
addappid(2527450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527451, 1, "43e96f76bd734e16d6c43092803dd9b599cea35ba7673e60c67240cad2b44b36")
