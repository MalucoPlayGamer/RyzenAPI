-- Lua provided by RyzenAPI
-- Game: Game: AppID 341120

-- MAIN APPLICATION
addappid(341120)
-- Game: addappid(341120)

-- MAIN APP DEPOTS / PACKAGES
addappid(341121, 1, "ccf00073cc812cdaa54163a12c0ea75a55f3ba06958e42b27fa0ac89cb7ff254")
addappid(341122, 1, "db0f4b0d4fae698871b444e4f377ce465027d09117bccc4ee2e142b32ea8316f")
