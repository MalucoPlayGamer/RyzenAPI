-- Lua provided by RyzenAPI
-- Game: addappid(1149290)

-- MAIN APPLICATION
addappid(1149290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149291, 1, "f67c0d416711eaa3968159e800503bcde6f592c6d11f81cc0837c145440f7d2f")
