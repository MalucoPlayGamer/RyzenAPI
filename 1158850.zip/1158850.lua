-- Lua provided by RyzenAPI
-- Game: The Great Ace Attorney Chronicles

-- MAIN APPLICATION
addappid(1158850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158851, 1, "8d69eee633a664e6efb3977ee6638aa5ca8227819a5cce5d34955a236ff7ac3e")
addappid(1158852, 1, "1c388fc7e55be5e7da2ca1c7d054359f1caf394ef07e48d548e38225eaeb2ec0")
addappid(1158853, 1, "72d532e8aff80288545d0797a73ebe55ada2d3524b970c239ccc56a68e92c035")
addappid(1158854, 1, "edf1ce4b26060c7e6ff543c032b9048f76dc72037725e1b5049af439a87dac8f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1487540)
