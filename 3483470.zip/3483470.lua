-- Lua provided by RyzenAPI 
-- Game: AppID 3483470
addappid(3483470)
addappid(3483471, 1, "a2e9f168e447df8def456b5debe048426b6dd4df21db1c0e001a96ffed72a552")
