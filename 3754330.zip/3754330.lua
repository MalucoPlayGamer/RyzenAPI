-- Lua provided by RyzenAPI
-- Game: Apocalypse Tale

-- MAIN APPLICATION
addappid(3754330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3754331, 1, "5de4bd57c39999a37cee51bb44c731016f86d84a062a48c674c0b482ea006a49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
