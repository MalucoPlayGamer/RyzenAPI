-- Lua provided by RyzenAPI
-- Game: addappid(3754330)

-- MAIN APPLICATION
addappid(3754330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3754331, 1, "5de4bd57c39999a37cee51bb44c731016f86d84a062a48c674c0b482ea006a49")
