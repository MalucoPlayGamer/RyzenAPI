-- Lua provided by RyzenAPI
-- Game: Seeds of Chaos

-- MAIN APPLICATION
addappid(1205950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205951, 1, "d467dba1c824e39195d0ab355168ae4fcfc4d90909a6e30ce8a376832f0b2a38")

