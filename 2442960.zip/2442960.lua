-- Lua provided by RyzenAPI 
-- Game: 三界
addappid(2442960)
addappid(2442961, 1, "7f14c378331b67a07bea5b006ab2cfd3db512e657acd97f8158fde99d61d5109")
