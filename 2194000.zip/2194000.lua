-- Lua provided by RyzenAPI
-- Game: addappid(2194000)

-- MAIN APPLICATION
addappid(2194000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194003,0,"cb1709057a53f9c00857db53bfa2b5f59de77601b19101a90fed29bc25e19cb4")
