-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Samurai Warriors Pack 3

-- MAIN APPLICATION
addappid(933527)
-- Game: addappid(933527)

-- MAIN APP DEPOTS / PACKAGES
addappid(933527,0,"7e4e9a01036b1d11035771d270945dbae1f6a0d2066d89522ba761f0514cdf8b")
