-- Lua provided by RyzenAPI
-- Game: Dragon Ace Casino

-- MAIN APPLICATION
addappid(3801380)

