-- Lua provided by RyzenAPI
-- Game: 346490

-- MAIN APPLICATION
addappid(346490)
-- Game: addappid(346490)

-- MAIN APP DEPOTS / PACKAGES
addappid(346491, 1, "f6a6112ee2a0ffc65ea4eaabbe7de40d6e4fd503e48e1b8f599ea067292dee90")
