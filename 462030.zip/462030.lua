-- Lua provided by RyzenAPI
-- Game: Game: AppID 462030

-- MAIN APPLICATION
addappid(462030)
-- Game: addappid(462030)

-- MAIN APP DEPOTS / PACKAGES
addappid(462031, 1, "5e48320ae53af76cc69f2da0151f5a3a7bed66676c259127bc4a8c7161889fee")
