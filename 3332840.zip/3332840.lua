-- Lua provided by RyzenAPI 
-- Game: AppID 3332840
addappid(3332840)
addappid(3332841, 1, "ffc3bd681f76274984aaabed562db6cd84bb142d0648bd177206ffb1ed101757")
