-- Lua provided by RyzenAPI
-- Game: Palmyra Orphanage

-- MAIN APPLICATION
addappid(1085160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1085161, 1, "6c215c709f79c21bcc76cf25e227eecd7aa5571d1545873dce607419126587f2")

