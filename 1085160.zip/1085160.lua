-- Lua provided by RyzenAPI
-- Game: addappid(1085160)

-- MAIN APPLICATION
addappid(1085160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085161, 1, "6c215c709f79c21bcc76cf25e227eecd7aa5571d1545873dce607419126587f2")
