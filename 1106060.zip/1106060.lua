-- Lua provided by SkyAPI 
-- Game: AppID 1106060
addappid(1106060)
addappid(1106061, 1, "b3b4aafe513dbcf68675a375c73a071d2c6042a43c4becd89d22ac1eca37ee79")
