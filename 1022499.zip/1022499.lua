-- Lua provided by RyzenAPI
-- Game: 1022499

-- MAIN APPLICATION
addappid(1022499)
-- Game: addappid(1022499)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022499,0,"37ae3c6f7c7eaf6e3212cbc8911b754c9b80b93e81522f9d6b1c17aacf70afcc")
