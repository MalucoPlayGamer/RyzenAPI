-- Lua provided by SkyAPI 
-- Game: Core Keeper
addappid(1621690)
addappid(1621691, 1, "a2bb442f3eecb2b4c84232418b1d1b417a033b4c3ec1dca7caa4943d477026af")
addappid(1621692, 1, "70e686d10c357b0098e61a583d60a7ea311e5776fbc4729261c0a86a2e83bd1f")
