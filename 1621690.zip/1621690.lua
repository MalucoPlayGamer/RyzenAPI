-- Lua provided by RyzenAPI
-- Game: Core Keeper

-- MAIN APPLICATION
addappid(1621690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621690,0,"09b5706b917a21896f1086b393736c962f358d311c69ae96afed48cdb55a9acb")
addappid(1621691,0,"a2bb442f3eecb2b4c84232418b1d1b417a033b4c3ec1dca7caa4943d477026af")
addappid(1621692,0,"70e686d10c357b0098e61a583d60a7ea311e5776fbc4729261c0a86a2e83bd1f")
addappid(4160230,0,"516f85c58861a93a57a2dcfb53ab6f0f334bf4473d852ff0c8047f4b84c4c9c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
