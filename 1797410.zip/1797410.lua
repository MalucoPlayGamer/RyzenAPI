-- Lua provided by RyzenAPI
-- Game: Game: Doge Dimensions

-- MAIN APPLICATION
addappid(1797410)
-- Game: addappid(1797410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797411, 1, "32a0881f9f14406ef21530fd02b13f7c867348169db89f5aad0fdf7fcbb59797")
