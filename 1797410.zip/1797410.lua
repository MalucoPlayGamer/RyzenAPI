-- Lua provided by RyzenAPI
-- Game: Doge Dimensions

-- MAIN APPLICATION
addappid(1797410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797411, 1, "32a0881f9f14406ef21530fd02b13f7c867348169db89f5aad0fdf7fcbb59797")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
