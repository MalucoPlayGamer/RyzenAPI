-- Lua provided by SkyAPI 
-- Game: Doge Dimensions
addappid(1797410)
addappid(1797411, 1, "32a0881f9f14406ef21530fd02b13f7c867348169db89f5aad0fdf7fcbb59797")
