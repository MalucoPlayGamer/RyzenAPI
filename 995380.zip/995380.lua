-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(995380)
-- Game: addappid(995380)

-- MAIN APP DEPOTS / PACKAGES
addappid(995380,0,"b9830a7b18f8c32381b49ff4bd295b73ebeb38c39d83cfdfc4f4040224e4c996")
