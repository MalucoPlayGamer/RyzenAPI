-- Lua provided by RyzenAPI
-- Game: Story Of Eve 2 Demo

-- MAIN APPLICATION
addappid(1978250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978251, 1, "60783f3c2693ca809f9ae59ed318fbfc2c7b4017127b10be904e157f17080ab6")
