-- Lua provided by SkyAPI 
-- Game: AppID 1477940
addappid(1477940)
addappid(1477941, 1, "8fd39cf92b63df3c082bd1e095a57e146573fef8e116019c91e47869d9b63690")
