-- Lua provided by RyzenAPI
-- Game: Unknown 9: Awakening

-- MAIN APPLICATION
addappid(1477940)
addappid(2280170)
addappid(2385220)
addappid(2385221)
addappid(2385222)
addappid(2385223)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477941,0,"8fd39cf92b63df3c082bd1e095a57e146573fef8e116019c91e47869d9b63690")
addappid(1477942,0,"09edcf416ad8e00c4a0fe7efd24f7e66ca990a941fe3e65e8e98b4dc8a9bf464")

