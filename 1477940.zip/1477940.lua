-- Lua provided by RyzenAPI
-- Game: 1477940

-- MAIN APPLICATION
addappid(1477940)
-- Game: addappid(1477940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477941, 1, "8fd39cf92b63df3c082bd1e095a57e146573fef8e116019c91e47869d9b63690")
