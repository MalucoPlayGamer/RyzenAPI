-- Lua provided by RyzenAPI
-- Game: 2300410

-- MAIN APPLICATION
addappid(2300410)
-- Game: addappid(2300410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300411, 1, "42c7afbdb920fd57db4c89630c47dc5ab8195bd35b7797152f59d7ea43a695c1")
