-- Lua provided by RyzenAPI
-- Game: addappid(2959800)

-- MAIN APPLICATION
addappid(2959800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959800,0,"9017ffefba75da1ca060d2b4e49a299801a2663467be1974d600ad01934e1a19")
