-- Lua provided by RyzenAPI
-- Game: addappid(2612780)

-- MAIN APPLICATION
addappid(2612780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612781, 1, "b56f5a859cf0d5815aaf47e22b3bf5ef958d645fdc4f7a7046da932a7e47c8ce")
