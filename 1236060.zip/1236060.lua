-- Lua provided by RyzenAPI
-- Game: Don Juan Of The Galaxy

-- MAIN APPLICATION
addappid(1236060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236061, 1, "253ad5bfd9a01d2dc85ce7dd7eed1315b956c698c3b677a1d70b49dd313079bc")

