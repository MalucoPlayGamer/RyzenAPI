-- Lua provided by RyzenAPI
-- Game: AI公寓：虚拟证言

-- MAIN APPLICATION
addappid(2911060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2911061, 1, "e0763b40a30ea94ad68a42a09bd6a8effb60d535755f25383bf221416e5ae9db")

