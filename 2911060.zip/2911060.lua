-- Lua provided by RyzenAPI
-- Game: addappid(2911060)

-- MAIN APPLICATION
addappid(2911060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911061, 1, "e0763b40a30ea94ad68a42a09bd6a8effb60d535755f25383bf221416e5ae9db")
