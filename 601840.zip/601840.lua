-- Lua provided by RyzenAPI
-- Game: Griftlands

-- MAIN APPLICATION
addappid(601840)
-- Game: addappid(601840)

-- MAIN APP DEPOTS / PACKAGES
addappid(601841, 1, "faab12a8a91e3359c0d31da63864dbaaf5ec4690d70e615e8d925add8072bb9e")
addappid(601842, 1, "392fa8cd2f75786233de540a828fc6337e320979aad3b2392a3be8f150b8905f")
addappid(601843, 1, "4124e865d4dfbc67985260d0b33e247c623e71ce9a148622a258e7ef1025fbbe")
