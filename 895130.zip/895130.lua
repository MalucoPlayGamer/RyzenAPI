-- Lua provided by RyzenAPI
-- Game: Game: AppID 895130

-- MAIN APPLICATION
addappid(895130)
-- Game: addappid(895130)

-- MAIN APP DEPOTS / PACKAGES
addappid(895131, 1, "5c028d995766f3cfb2f2408c590352130b6f533f752f6f557e62881609de56f5")
