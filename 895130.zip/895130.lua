-- Lua provided by SkyAPI 
-- Game: AppID 895130
addappid(895130)
addappid(895131, 1, "5c028d995766f3cfb2f2408c590352130b6f533f752f6f557e62881609de56f5")
