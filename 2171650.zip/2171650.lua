-- Lua provided by RyzenAPI
-- Game: addappid(2171650)

-- MAIN APPLICATION
addappid(2171650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171651, 1, "7f0c7ff12fe9b5e40963cffc58187bc3cf2f6836fc546e5ff4aff000a9e11e30")
