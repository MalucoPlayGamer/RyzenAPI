-- Lua provided by RyzenAPI
-- Game: Cook For Love

-- MAIN APPLICATION
addappid(3009920)
addappid(3273500)
addappid(3273510)
addappid(3273520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3009921, 1, "746c1141f985fc8fd5bf02f3900118f584aba1e9c1bfec4047c52da7a799b821")

