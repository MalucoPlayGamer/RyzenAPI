-- Lua provided by SkyAPI 
-- Game: Cook For Love
addappid(3009920)
addappid(3009921, 1, "746c1141f985fc8fd5bf02f3900118f584aba1e9c1bfec4047c52da7a799b821")
