-- Lua provided by RyzenAPI
-- Game: Tiltility™ 1 

-- MAIN APPLICATION
addappid(4058970)
addappid(4120630)
addappid(4120700)

-- MAIN APP DEPOTS / PACKAGES
addappid(4058971,0,"49a8f321140e9208451868aa002e1b58f1a40910954970f0962ca5bf571be808")

