-- Lua provided by SkyAPI 
-- Game: Anchor Up
addappid(1384000)
addappid(1384001, 1, "51381ed9f206f3691a6eb8b0f560287158929bcb1b98668dea1c6d1b8357ebef")
