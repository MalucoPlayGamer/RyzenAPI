-- Lua provided by RyzenAPI
-- Game: 1384000

-- MAIN APPLICATION
addappid(1384000)
-- Game: addappid(1384000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384001, 1, "51381ed9f206f3691a6eb8b0f560287158929bcb1b98668dea1c6d1b8357ebef")
