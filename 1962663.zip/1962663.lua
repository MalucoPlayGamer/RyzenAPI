-- Lua provided by RyzenAPI
-- Game: Call of Duty®: Warzone™

-- MAIN APPLICATION
addappid(1962663)

