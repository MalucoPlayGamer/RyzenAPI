-- Lua provided by RyzenAPI
-- Game: ENCODYA

-- MAIN APPLICATION
addappid(1137450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137451, 1, "501e2311428175637a7d16acfdb67b0b7aeb6345e8307796b646822a89825c04")
addappid(1137452, 1, "df3a0c587954950f7948a6ae106748d69646805d758d4d73e3911e7f2bb9e424")
addappid(1137453, 1, "f31ef2534ff80b0c666eb6ade8171d7df3e7d6b9dd57cb1b0caaafce359a5498")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1520860)
