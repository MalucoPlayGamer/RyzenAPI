-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(907470)
addappid(907471)
addappid(907473)

-- MAIN APP DEPOTS / PACKAGES
addappid(907472,0,"095876dbe0ac9eec87ae1128f2b438804db50d2761f67a7d30adad1171969b36")
addappid(1025040,0,"5337ad193c841d82159c829f5d8d1e2a01d8918e991bff97e03d191af04325ed")

