-- Lua provided by RyzenAPI
-- Game: 3158530

-- MAIN APPLICATION
addappid(3158530)
-- Game: addappid(3158530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3158531, 1, "768b334d55f7e8c5a68e9a5fa01317f5ef887082f3d7d490011a44f6756de6d9")
