-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2893510)
-- Game: addappid(2893510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893510,0,"b2115366009e3e8ec360cd2827f5af458ed9c53cf856c8d8c71943c59df490e4")
