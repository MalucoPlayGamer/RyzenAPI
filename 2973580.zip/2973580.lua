-- Lua provided by RyzenAPI
-- Game: 2973580

-- MAIN APPLICATION
addappid(2973580)
-- Game: addappid(2973580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973581, 1, "146700b038bce2927e469c8cbb3c1bd2d20a6352dbbb9b5738bcc0de6a2256d0")
