-- Lua provided by RyzenAPI
-- Game: 3378260

-- MAIN APPLICATION
addappid(3378260)
-- Game: addappid(3378260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3378261, 1, "d94b8cd204d1fd3273d50180d432419f2c026e8acbd5d71d8e6f6db0c589722b")
