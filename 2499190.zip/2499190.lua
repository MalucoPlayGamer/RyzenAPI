-- Lua provided by RyzenAPI
-- Game: Desktop Beach Girls Demo

-- MAIN APPLICATION
addappid(2499190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499191, 1, "f2c999d9fd78fb9c8c30f6959196a56109f93398a2cb4a06242742198403fe9d")

