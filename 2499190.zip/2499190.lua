-- Lua provided by RyzenAPI 
-- Game: AppID 2499190
addappid(2499190)
addappid(2499191, 1, "f2c999d9fd78fb9c8c30f6959196a56109f93398a2cb4a06242742198403fe9d")
