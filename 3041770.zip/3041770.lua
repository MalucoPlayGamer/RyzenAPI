-- Lua provided by RyzenAPI
-- Game: addappid(3041770)

-- MAIN APPLICATION
addappid(3041770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041771, 1, "b39b23f1b5b7105f9f5614188d9ee8be6bd7c15dea9f11d0f56f34d79dd23d76")
