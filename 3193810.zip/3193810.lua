-- Lua provided by SkyAPI 
-- Game: Commandos: Origins - Original Soundtrack
addappid(3193810)
addappid(3193811, 1, "13bb24aec83dd1d97fb89aa9cde9ec167fe8b5725e5fa5cfd190dbfaf483f85d")
addappid(3193812, 1, "1da5b04d5bf13510469f27a0d3e622897963d54b82e34d39a2330fc0153b6f49")
