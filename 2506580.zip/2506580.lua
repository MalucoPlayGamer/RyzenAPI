-- Lua provided by SkyAPI 
-- Game: Gearbits
addappid(2506580)
addappid(2506581, 1, "06ad8fd6b7308881521e58549fa53078ae1c9e9faa6aa0406d689c19fb1f63bf")
addappid(2506582, 1, "0f1d3ce1094c9bafa9d339b55007148b4cde049abf71531b29c82641f165ca66")
addappid(2506583, 1, "078a1bb8d5197568efda13fd1365e988dae55a6c6c8e583ff60da28b7b4fd59a")
addappid(2989880)
