-- Lua provided by RyzenAPI
-- Game: Lake Haven - Chrysalis

-- MAIN APPLICATION
addappid(1696960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696961, 1, "37ce068732be8faa970ef566d7fd7fe61f217b9943d9004bad0858c0ec30ca6a")
