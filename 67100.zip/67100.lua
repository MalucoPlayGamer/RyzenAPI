-- Lua provided by RyzenAPI
-- Game: 67100

-- MAIN APPLICATION
addappid(46774)
addappid(67100)
-- Game: addappid(67100)

-- MAIN APP DEPOTS / PACKAGES
addappid(46772,0,"1bcd34f2acbda59310b3dbf6e53dd2a8b66f2e08649de0e0270a3dca96c973cd")
