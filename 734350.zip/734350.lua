-- Lua provided by RyzenAPI
-- Game: AppID 734350

-- MAIN APPLICATION
addappid(734350)

-- MAIN APP DEPOTS / PACKAGES
addappid(734351, 1, "83df962ae46db793fa5ef8dc1a20af6e5e2cad3423f166e5549c24ac8ca3e067")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
