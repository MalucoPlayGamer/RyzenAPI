-- Lua provided by RyzenAPI
-- Game: addappid(734350)

-- MAIN APPLICATION
addappid(734350)

-- MAIN APP DEPOTS / PACKAGES
addappid(734351, 1, "83df962ae46db793fa5ef8dc1a20af6e5e2cad3423f166e5549c24ac8ca3e067")
