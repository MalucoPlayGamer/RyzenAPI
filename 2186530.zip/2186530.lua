-- Lua provided by RyzenAPI
-- Game: My Desktop Girlfriend

-- MAIN APPLICATION
addappid(2186530)
-- Game: addappid(2186530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186531, 1, "e24b2aa477b7801d0021a7c1784aae5f11103360ccb3991c0cc997b725bbe213")
