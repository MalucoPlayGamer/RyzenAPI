-- Lua provided by RyzenAPI
-- Game: AppID 393500

-- MAIN APPLICATION
addappid(393500)

-- MAIN APP DEPOTS / PACKAGES
addappid(393501, 1, "59d6360bf1b32af0ec96a9b575aaf1d027490bfa59c651d517b5deece01bf5b1")
