-- Lua provided by RyzenAPI
-- Game: Mirror Of Life

-- MAIN APPLICATION
addappid(1624470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1624471, 1, "6da43d953d80304cc051ec7c19228dcad8fc9a838e4947b09fd1e77abe08b1e8")
