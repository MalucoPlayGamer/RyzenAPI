-- Lua provided by RyzenAPI
-- Game: Ubinota

-- MAIN APPLICATION
addappid(323630)
-- Game: addappid(323630)

-- MAIN APP DEPOTS / PACKAGES
addappid(323631, 1, "b741e0a051c46141aaad3ec4900d2b8d4eb67244dcad814801f9988f7eb96f85")
addappid(323632, 1, "335c599df24e740b17f1359bec5be62a5006987ed01967c60734547ba3409374")
