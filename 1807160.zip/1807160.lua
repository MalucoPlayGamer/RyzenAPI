-- Lua provided by RyzenAPI
-- Game: 1807160

-- MAIN APPLICATION
addappid(1807160)
-- Game: addappid(1807160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807161, 1, "025606ec88a93fc37ef91bc84baa84f8912e8039fad0085156998da217df85e9")
