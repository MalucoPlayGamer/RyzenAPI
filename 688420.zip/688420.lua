-- Lua provided by RyzenAPI
-- Game: Bad North: Jotunn Edition

-- MAIN APPLICATION
addappid(688420)

-- MAIN APP DEPOTS / PACKAGES
addappid(688421, 1, "525079f6b1d23bbcaace38e134d75021bc71b75853a8e538a802326ce95897cc")
addappid(688423, 1, "216ca3b6d87e9cc1152b065fa3f7178f0f68a2710e55a026f12a235a04e8d7b2")
addappid(970060, 0, "d34dd4efea15ff2655d034a2d54792fe2daa21459e7e709102fc3f0a08003d58")
