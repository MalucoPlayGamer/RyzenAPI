-- Lua provided by RyzenAPI 
-- Game: Polylylyrhythm
addappid(3006240)
addappid(3006241, 1, "92899804638121e9e3db7dafbaafd7a8055e8a12cdee4fc10fbe54b603c79db3")
