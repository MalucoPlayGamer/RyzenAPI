-- Lua provided by RyzenAPI
-- Game: VR Parallel World

-- MAIN APPLICATION
addappid(1523360)
-- Game: addappid(1523360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1523361, 1, "8a9fb5fc1a32be481aeb135c4961701cd46395a41f19da3616477ea2ce7a0ab6")
