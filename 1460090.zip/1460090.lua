-- Lua provided by RyzenAPI
-- Game: The Life and Suffering of Sir Brante — Chapter 1&2

-- MAIN APPLICATION
addappid(1460090)
