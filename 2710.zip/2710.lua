-- Lua provided by RyzenAPI
-- Game: 2710

-- MAIN APPLICATION
addappid(2710)
-- Game: addappid(2710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711, 1, "78494b9f19f405e445c6ef28e2ad188fb0b3bc454fafe6022ae55948102c94e0")
addappid(2712, 1, "e99156f4e78fc094f29bbce0fab3dbf6a2974bb8aaa1f1cfb8163103f473b249")
addappid(2713, 1, "9b85de3de76e8fe9c0cd5b182c038f09da55d580af4e79b78c20d7f752b60e4d")
addappid(2714, 1, "c12feb27d279ad74be4e45b9c670bf8b93964887d7287010b5bffbc86e43c9fc")
