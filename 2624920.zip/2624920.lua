-- Lua provided by RyzenAPI
-- Game: addappid(2624920)

-- MAIN APPLICATION
addappid(2624920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624921, 1, "7c067eb22e983a5226945cf8f30f43a6bce1dbc9608e7392f1c90874946ea0a8")
