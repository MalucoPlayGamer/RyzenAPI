-- Lua provided by RyzenAPI
-- Game: No Place Like Home

-- MAIN APPLICATION
addappid(1472660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1472661, 1, "88f2dc889c6de42d83bceb0133a4c7dd3d669ef3b523af1275b4ce1f0872fbca")

