-- Lua provided by RyzenAPI
-- Game: No Place Like Home

-- MAIN APPLICATION
addappid(1472660)
-- Game: addappid(1472660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472661, 1, "88f2dc889c6de42d83bceb0133a4c7dd3d669ef3b523af1275b4ce1f0872fbca")
