-- Lua provided by RyzenAPI
-- Game: Deep GachiGASM

-- MAIN APPLICATION
addappid(744430)
addappid(761900)
-- Game: addappid(744430)

-- MAIN APP DEPOTS / PACKAGES
addappid(744431, 1, "87bb9065e5af728bfafefe337988333d298ead3f0878f617d3d4eb22384c0585")
