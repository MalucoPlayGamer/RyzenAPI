-- Lua provided by RyzenAPI
-- Game: Game: Undead & Beyond

-- MAIN APPLICATION
addappid(839410)
-- Game: addappid(839410)

-- MAIN APP DEPOTS / PACKAGES
addappid(839411, 1, "829d7123d9245c5199b1fae0cacb053fbaa01574dc8dc9e0ab2f79d41d6e3b7e")
