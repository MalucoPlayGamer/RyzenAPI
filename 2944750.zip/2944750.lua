-- Lua provided by RyzenAPI
-- Game: The Strange City

-- MAIN APPLICATION
addappid(2944750)
-- Game: addappid(2944750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2944751, 1, "ff470bc0151da281aad99df41df54e28a6601bafccf8a57172700660785a5530")
