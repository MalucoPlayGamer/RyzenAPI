-- Lua provided by RyzenAPI
-- Game: Mahjong Realms

-- MAIN APPLICATION
addappid(3284780)

