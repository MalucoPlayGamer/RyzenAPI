-- Lua provided by RyzenAPI
-- Game: Mahjong Realms

-- MAIN APPLICATION
addappid(3284780)
addappid(4257760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

