-- Lua provided by RyzenAPI
-- Game: Gothic II: Gold Edition

-- MAIN APPLICATION
addappid(39510)
addappid(228988)

-- MAIN APP DEPOTS / PACKAGES
addappid(39511, 1, "19594bd89b6aef0b481013cafd3da433d86d6046c221734a339a895d70286f08")
addappid(39512, 1, "9305a7849a67bad28a78d6c52240aef13542029e71a9a72cc8e36dfd6cfbf3d8")
addappid(39513, 1, "78de7e36728842efaded5b3700037f454a6e0d8127f647e9f6050e612e5c485e")
addappid(39514, 1, "6e88a54ba2ebdc265380de4bee82fcc4dad80118b4d5c13b86b3461b3f657941")
addappid(39515, 1, "59413aea084189c35b42a206dda3ce5752f33c019c08657999d414000af037f1")
addappid(39516, 1, "137df0fc92a311cb1be4f23cde600524f9cde6748a95a922e011c95de3addf85")
addappid(39517, 1, "9b734085006ae36183582809eb469d112c6446525f0048b31eaebef7620c0116")
addappid(39518, 1, "12aa691dae028f958fcefde6cc354d555de75c734c4890fb4258d2733f0d3615")
addappid(39519, 1, "ac5a87e84a1524360fda7b2dbcb0cd5b44b4a0d006dcd979c7171f7f474850e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
