-- Lua provided by RyzenAPI
-- Game: Game: Lethal Honor - Order of the Apocalypse Demo

-- MAIN APPLICATION
addappid(2922460)
-- Game: addappid(2922460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2922461, 1, "464519902b42e02dd6e725744c00395822743003aff54fead95c40f6d6cfbfb7")
