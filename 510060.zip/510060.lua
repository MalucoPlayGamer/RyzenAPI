-- Lua provided by RyzenAPI
-- Game: AppID 510060

-- MAIN APPLICATION
addappid(510060)
-- Game: addappid(510060)

-- MAIN APP DEPOTS / PACKAGES
addappid(510061, 1, "b50db91a0a8795845a21bab0069da3974c35558bccb26918beb5881fed3e8f40")
