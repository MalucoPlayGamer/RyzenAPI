-- Lua provided by RyzenAPI
-- Game: Just King

-- MAIN APPLICATION
addappid(1059980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059981, 1, "34533a736ad588eadf3d54a4d396138ffd82c4c67a791cc8b5f6583289168abd")
