-- Lua provided by RyzenAPI
-- Game: 850930

-- MAIN APPLICATION
addappid(850930)
-- Game: addappid(850930)

-- MAIN APP DEPOTS / PACKAGES
addappid(850931, 1, "f9453f9cafa477306bcd01cb84924f7ffa9ee93a3fb7a0f0ecf8cf42a5de479f")
