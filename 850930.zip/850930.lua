-- Lua provided by SkyAPI 
-- Game: MODERN ROAD-LIKE
addappid(850930)
addappid(850931, 1, "f9453f9cafa477306bcd01cb84924f7ffa9ee93a3fb7a0f0ecf8cf42a5de479f")
