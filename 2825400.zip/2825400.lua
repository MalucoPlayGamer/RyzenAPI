-- Lua provided by RyzenAPI
-- Game: Pogo Pogo

-- MAIN APPLICATION
addappid(2825400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825401, 1, "b9285f0bd3a50c73e80052191e790cfe8d59cc4f6f90bc71aa6a1d16f671cda9")

