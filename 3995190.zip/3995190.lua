-- Lua provided by RyzenAPI
-- Game: Obsessed Lucy

-- MAIN APPLICATION
addappid(3995190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3995191,0,"d51221beb57afe8c73d2f7550b4da163a690e5b288bbed0f8f826b94eceb2f0c")

