-- Lua provided by RyzenAPI
-- Game: Game: SEARCH ALL - BITCOIN

-- MAIN APPLICATION
addappid(2010540)
-- Game: addappid(2010540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010541, 1, "4cbb7b43c0757ab4c5000cfe91e0b918df965273ff3a4355e9e814fa6f703885")
