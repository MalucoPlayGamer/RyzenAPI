-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1945211)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945211,0,"ca378cd4ae0413dfe9f1a8b5da37b2d5198f611e7cf42885cac9c8fa52c2ca62")

