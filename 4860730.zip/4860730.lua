-- 4860730's Lua and Manifest Created by Hubcap Manifest
-- Race Town: Kids and Toddlers Car Racing Game
-- Created: July 22, 2026 at 21:14:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4860730) -- Race Town: Kids and Toddlers Car Racing Game
-- MAIN APP DEPOTS
addappid(4860731, 1, "22f89090cd566c3ebcf250d38fbb39e0e59051549c9576fbf34725fd7f5762a9") -- Depot 4860731
setManifestid(4860731, "668676831618732381", 1373373412)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)