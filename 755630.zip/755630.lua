-- Lua provided by RyzenAPI
-- Game: Drake of the 99 Dragons

-- MAIN APPLICATION
addappid(755630)
-- Game: addappid(755630)

-- MAIN APP DEPOTS / PACKAGES
addappid(755631, 1, "de5fbd42d176d846757f89c1cf4792f3ca4952c3d33a818b50b67994ef3da116")
