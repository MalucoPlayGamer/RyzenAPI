-- Lua provided by RyzenAPI 
-- Game: AppID 3145840
addappid(3145840)
addappid(3145841, 1, "1c8dbb23f05bb6c3c1426c76cb3d4e60e002f156082d7dcbc31f1b0861a64eb3")
