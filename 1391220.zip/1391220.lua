-- Lua provided by RyzenAPI
-- Game: Scrapnaut: Prologue

-- MAIN APPLICATION
addappid(1391220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391221, 1, "31b47fa18d0afcab96d5d3e80020d17945dbb48cd434bf96772318dc19873991")

