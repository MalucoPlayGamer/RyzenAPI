-- Lua provided by RyzenAPI
-- Game: 七月-July

-- MAIN APPLICATION
addappid(1959780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959781, 1, "31ee399d85574b4a75f501f72beecdcae0d6e190f94121fb360ff7113cacdf1e")

