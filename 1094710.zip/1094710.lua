-- Lua provided by RyzenAPI
-- Game: 1094710

-- MAIN APPLICATION
addappid(1094710)
-- Game: addappid(1094710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094711, 1, "619c2237a9237d306c6aaac5b832957dd250bcd0d189621333d95b69da641e9f")
