-- Lua provided by RyzenAPI
-- Game: The Expression Amrilato

-- MAIN APPLICATION
addappid(1044490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044491, 1, "7a640a21f102a79941c71e94290722d2e0d44392e534241868546e5b3b39619f")

