-- Lua provided by RyzenAPI
-- Game: addappid(798870)

-- MAIN APPLICATION
addappid(798870)

-- MAIN APP DEPOTS / PACKAGES
addappid(798870,0,"680393c44baee691054a6e27404226e9504ae85eb46fcab200b5ddc6a2288d43")
