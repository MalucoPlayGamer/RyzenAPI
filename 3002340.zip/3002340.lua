-- Lua provided by RyzenAPI
-- Game: Sunset Solitaire

-- MAIN APPLICATION
addappid(3002340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002342,0,"b43e26116e1f85b43168be469f618420b2d1c1a09ebdce9987473d57a3041591")
