-- Lua provided by RyzenAPI
-- Game: Kingdom Draw

-- MAIN APPLICATION
addappid(1986040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986041, 1, "6233675e4a8afeb90cea6daee0bbbc5fcdf60a354ee8ff312f895f217eaa310e")
addappid(1986043, 1, "2d848297ef1e8656cba6058a9d0cbbdcfc40de15788ca28a5763ad667af29b22")
addappid(1986045, 1, "85b1e69809546041210a4ab5b573c7bc2f24cf8fa39e0ae33fde2184ea7a1ecf")
