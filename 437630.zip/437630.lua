-- Lua provided by RyzenAPI
-- Game: AppID 437630

-- MAIN APPLICATION
addappid(437630)

-- MAIN APP DEPOTS / PACKAGES
addappid(437631, 1, "8b3d123d4510e4ab04fe986a2009263fcb9f0ddf6e920475778d281d3e56f79b")
addappid(437632, 1, "d2b2b1a881f42b643e659fc17c538fd6d50f34f00ea3e4014b9bc444bbd4acbd")
addappid(437633, 1, "54008b6c4459fde8869f557c438845432edc64eb67fe02b20bf9cad6468eaf19")
addappid(437634, 1, "2b82a083a39c7ca1885b9e18d106fad753bee00526c1d4ec8bafa9358e49fa48")
addappid(437635, 1, "7aee38dfe2fbb81c78921501bdf7286ad312b6afcc0acb11a302ff9ba268dc51")
addappid(437636, 1, "ed1ce14e2b5ef04401c244f232deef65f13e6460a747c1df8d1300a1578d97d9")
addappid(884031, 0, "47dcabcc4f0ca27c19d740202c7e5c97f88086836f852c6e3ac7d12848c9fa60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
