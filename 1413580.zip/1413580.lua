-- Lua provided by RyzenAPI
-- Game: The Dragoness: Command of the Flame

-- MAIN APPLICATION
addappid(1413580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413581, 1, "de7a4df3b6293909ff32bec044f23df6b72be11a7a08b580ac928a588f50676c")

