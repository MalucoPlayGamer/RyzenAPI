-- Lua provided by RyzenAPI
-- Game: Hentai Sexy

-- MAIN APPLICATION
addappid(1679990)
-- Game: addappid(1679990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679991, 1, "3b517e69aede8e76a45142c7ca1297d4b2fc68d0b1da93831bae1a5bef634063")
