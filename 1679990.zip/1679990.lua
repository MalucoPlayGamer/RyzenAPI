-- Lua provided by SkyAPI 
-- Game: Hentai Sexy
addappid(1679990)
addappid(1679991, 1, "3b517e69aede8e76a45142c7ca1297d4b2fc68d0b1da93831bae1a5bef634063")
