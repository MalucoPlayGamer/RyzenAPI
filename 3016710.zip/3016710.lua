-- Lua provided by RyzenAPI 
-- Game: AppID 3016710
addappid(3016710)
addappid(3016711, 1, "b73b0eee34023d44f62f7766b42ecd27490327e41467960afac4a8e11add147b")
