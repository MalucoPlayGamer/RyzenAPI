-- Lua provided by RyzenAPI
-- Game: 603250

-- MAIN APPLICATION
addappid(603250)
-- Game: addappid(603250)

-- MAIN APP DEPOTS / PACKAGES
addappid(603251, 1, "461601b49582833cd795f52918146ae6fae81f16cc4cccc26c3abebf89467e1d")
