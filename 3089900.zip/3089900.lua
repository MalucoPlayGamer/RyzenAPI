-- Lua provided by RyzenAPI 
-- Game: AppID 3089900
addappid(3089900)
addappid(3089901, 1, "8e73f9b5e5f74b1ce952a2bd62f81ecf67a3bfec22ad0851a40999402e0033fe")
addappid(3089902, 1, "e2492b2c266aec1c88d06b2c1cb7539b585e50767d2ab7e970f5749ab8a2b2ee")
