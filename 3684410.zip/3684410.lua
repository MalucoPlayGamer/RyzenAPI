-- Lua provided by RyzenAPI
-- Game: Goat Stand and Turtle Guy

-- MAIN APPLICATION
addappid(3684410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3684411, 1, "edcd8bf625a5d8f764feb19090110ae329a6c768183e0c3a5e5938bab0f2f256")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
