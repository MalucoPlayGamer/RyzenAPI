-- Lua provided by RyzenAPI
-- Game: Maza

-- MAIN APPLICATION
addappid(2672760)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(2672761, 1, "cd9c80c180f1286b8a467d2e2532f36a3a9661ac277bf5e73acd3446d7a6036e")
addappid(2672762, 1, "5cde1fd8dccf0c765d8d50fc0ed801dd606bf7618bc28abce03cc5a01c1e6f89")

