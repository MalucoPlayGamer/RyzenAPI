-- Lua provided by RyzenAPI
-- Game: MarginCall

-- MAIN APPLICATION
addappid(4961460) -- MarginCall

-- MAIN APP DEPOTS / PACKAGES
addappid(4961461, 1, "438de88fd1189cf8417133265a0668b397316dd75beaa625ea524f4f8e9bd0c1") -- Depot 4961461
addtoken(4961460, "3842927537449807955")

