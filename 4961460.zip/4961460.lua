-- 4961460's Lua and Manifest Created by Hubcap Manifest
-- MarginCall
-- Created: August 19, 2026 at 18:57:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4961460) -- MarginCall
addtoken(4961460, "3842927537449807955")
-- MAIN APP DEPOTS
addappid(4961461, 1, "438de88fd1189cf8417133265a0668b397316dd75beaa625ea524f4f8e9bd0c1") -- Depot 4961461
setManifestid(4961461, "8162299186173741448", 680854139)