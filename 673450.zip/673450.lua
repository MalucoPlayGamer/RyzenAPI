-- Lua provided by RyzenAPI
-- Game: addappid(673450)

-- MAIN APPLICATION
addappid(673450)

-- MAIN APP DEPOTS / PACKAGES
addappid(673451, 1, "c8ad3dbf40ff38fb49a6f441673fb83398174b087fa9c2aff6e9e7a97ec835c4")
