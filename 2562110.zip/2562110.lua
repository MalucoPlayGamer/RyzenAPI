-- Lua provided by RyzenAPI
-- Game: G.I. Joe: Wrath of Cobra Demo

-- MAIN APPLICATION
addappid(2562110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562111, 1, "7096c4ae206a54e80acbabf97e7551b5c7e0f8a51b1cebca000008515c84ba20")
