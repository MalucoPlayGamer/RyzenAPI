-- Lua provided by RyzenAPI
-- Game: StarSavior

-- MAIN APPLICATION
addappid(3609080)
