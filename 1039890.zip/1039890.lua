-- Lua provided by RyzenAPI
-- Game: 1039890

-- MAIN APPLICATION
addappid(1039890)
-- Game: addappid(1039890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039891, 1, "7a2f5ea4eb13458c963a09fc2ca6754df6d1690dda4bd7e0f99bc629001af509")
