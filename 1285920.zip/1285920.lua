-- Lua provided by RyzenAPI 
-- Game: AppID 1285920
addappid(1285920)
addappid(1285921, 1, "1edc21c1af736f80e622a480541e8bf82e4fc709e6ea139d5b31ce35ae3ca1ea")
