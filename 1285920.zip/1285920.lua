-- Lua provided by RyzenAPI
-- Game: AppID 1285920

-- MAIN APPLICATION
addappid(1285920)
addappid(2812790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1285921, 1, "1edc21c1af736f80e622a480541e8bf82e4fc709e6ea139d5b31ce35ae3ca1ea")

