-- Lua provided by RyzenAPI
-- Game: Game: KAIKAN

-- MAIN APPLICATION
addappid(2558570)
-- Game: addappid(2558570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2558571, 1, "b4796a3c3d329c9b2115fd1f1815dd7e00b00d7669329a7267e6868a3ce91702")
