-- Lua provided by RyzenAPI
-- Game: Power Fantasy

-- MAIN APPLICATION
addappid(2482190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482191, 1, "886f9214c868838f5862799a8fb8fd93c9f0251881e8d0355ad6946aa124f2f2")

