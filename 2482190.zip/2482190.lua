-- Lua provided by RyzenAPI
-- Game: Power Fantasy

-- MAIN APPLICATION
addappid(2482190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482191, 1, "886f9214c868838f5862799a8fb8fd93c9f0251881e8d0355ad6946aa124f2f2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2725210)
addappid(2856540)
addappid(3368730)
addappid(4220750)
addappid(4511590)
