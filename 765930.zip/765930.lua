-- Lua provided by RyzenAPI
-- Game: 765930

-- MAIN APPLICATION
addappid(765930)
-- Game: addappid(765930)

-- MAIN APP DEPOTS / PACKAGES
addappid(765931, 1, "272ef068c8c1e1c71ccf0bf08fb93c21f7ca01feafb951548e85cec72078c9ec")
