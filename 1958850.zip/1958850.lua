-- Lua provided by RyzenAPI
-- Game: REDACTED

-- MAIN APPLICATION
addappid(1958850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958851, 1, "e4b6de86dd823405511aa49cd318ff6d2c22931b1640427b3602043827723a39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
