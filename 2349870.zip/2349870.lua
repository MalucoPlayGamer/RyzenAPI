-- Lua provided by RyzenAPI
-- Game: Game: AppID 2349870

-- MAIN APPLICATION
addappid(2349870)
-- Game: addappid(2349870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2349871, 1, "45d38ae1c7ba0356cb0f5bfed8a8b68bb155e3658e37f4fbb0d88f4a5e3427a5")
