-- Lua provided by RyzenAPI
-- Game: AppID 2349870

-- MAIN APPLICATION
addappid(2349870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2349871, 1, "45d38ae1c7ba0356cb0f5bfed8a8b68bb155e3658e37f4fbb0d88f4a5e3427a5")

