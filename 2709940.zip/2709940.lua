-- Lua provided by RyzenAPI
-- Game: 2709940

-- MAIN APPLICATION
addappid(2709940)
-- Game: addappid(2709940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709941, 1, "237cee666db2f5c6ba94f702a2117bb5e7149c96cabbd4fa9a298055f6ed04d9")
