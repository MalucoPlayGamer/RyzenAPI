-- Lua provided by SkyAPI 
-- Game: Block Fortress 2
addappid(2107030)
addappid(2107031, 1, "593cc95131d689b2ed17d5b3668a601f39eb05136f1d29c5f8b736fa30e73cb3")
addappid(2107032, 1, "29865c8f33ea6c7156432375949c2d3131bbe05f70cde9ca17258462c9ebfbc6")
