-- Lua provided by RyzenAPI
-- Game: 1923950

-- MAIN APPLICATION
addappid(1923950)
-- Game: addappid(1923950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923950,0,"ea2a86120284e9a9c557f05158595dcda95fd7659bac67b49952d36e19ed3cfb")
