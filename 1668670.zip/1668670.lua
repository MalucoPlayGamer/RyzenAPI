-- Lua provided by RyzenAPI
-- Game: Game: snowboarding

-- MAIN APPLICATION
addappid(1668670)
-- Game: addappid(1668670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668671, 1, "398965a4b5edaf297df54498fd7a5ada16ff90cfefdc93822953faa87846dbbc")
