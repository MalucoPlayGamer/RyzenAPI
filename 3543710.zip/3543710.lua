-- Lua provided by RyzenAPI
-- Game: A Few Days With : Hazel

-- MAIN APPLICATION
addappid(3543710)
-- Game: addappid(3543710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3543711, 1, "37a5922c20bf81507069c1fc595b896cdee211144b4732a901867d329201419e")
