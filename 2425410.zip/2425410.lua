-- Lua provided by RyzenAPI
-- Game: Alia's Carnival! Flowering Sky

-- MAIN APPLICATION
addappid(2425410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425411, 1, "5fe46983582159f687c4bf0698ff79ec166923ce97ae1d391ea94255c74a90e6")
