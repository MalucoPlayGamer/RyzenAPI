-- Lua provided by RyzenAPI
-- Game: Game: AppID 1879580

-- MAIN APPLICATION
addappid(1879580)
-- Game: addappid(1879580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879581, 1, "f5873054bdec082ade7014d0473011cd614d024a793a1ff044b0dda76a2d58b9")
