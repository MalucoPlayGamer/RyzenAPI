-- Lua provided by RyzenAPI
-- Game: Game: DEEP SPACE WAIFU: WORLD

-- MAIN APPLICATION
addappid(872130)
-- Game: addappid(872130)

-- MAIN APP DEPOTS / PACKAGES
addappid(872131, 1, "80871037ff1272b069d6d6c923877f7d71b5c4712f56ddf3104addc8b80dea82")
