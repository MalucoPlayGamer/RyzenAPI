-- Lua provided by RyzenAPI
-- Game: addappid(1645940)

-- MAIN APPLICATION
addappid(1645940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645941, 1, "4cadcf648cc3e2fe926f62a867d2e2a8247079fa86199753697a6c68f8b44250")
