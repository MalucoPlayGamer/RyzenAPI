-- Lua provided by RyzenAPI
-- Game: Rolling Valley

-- MAIN APPLICATION
addappid(1864180)
-- Game: addappid(1864180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864181, 1, "faba08a320a73923771df502cc70f42bcede8b5e37dd0e5f5d756d6eb4247fb2")
