-- Lua provided by RyzenAPI
-- Game: addappid(2914420)

-- MAIN APPLICATION
addappid(2914420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914421, 1, "f5aa4bc12166e8e3c136aaa533b42f9a0caa15d10e1c3c5c4d507b7a932185f4")
