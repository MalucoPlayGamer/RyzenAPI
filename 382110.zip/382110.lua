-- Lua provided by RyzenAPI
-- Game: Virtual Desktop Classic

-- MAIN APPLICATION
addappid(382110)
-- Game: addappid(382110)

-- MAIN APP DEPOTS / PACKAGES
addappid(382111, 1, "1632201f7c9e9870e37676db64ba31aacf8d92098420074795c08cb2b77ce385")
