-- Lua provided by RyzenAPI
-- Game: Danse Macabre: The Last Adagio Collector's Edition

-- MAIN APPLICATION
addappid(551380)

-- MAIN APP DEPOTS / PACKAGES
addappid(551381,0,"28e5c786a4f3c948222eb686e5b6a38c676fed786b2390c06fae23218322e14d")

