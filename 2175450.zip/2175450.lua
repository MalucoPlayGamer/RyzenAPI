-- Lua provided by RyzenAPI
-- Game: Rhythm Stones

-- MAIN APPLICATION
addappid(2175450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175451, 1, "4a861cdff924ff113c683dcb25788848251c72494392a8394edb0fff8ea96e7b")
addappid(2175452, 1, "d33e78590e7df0eb7b860fc600288313f62aecfd131a206a7097c027fcec92f5")
