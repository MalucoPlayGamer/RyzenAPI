-- Lua provided by RyzenAPI
-- Game: 1065800

-- MAIN APPLICATION
addappid(1065800)
-- Game: addappid(1065800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065801, 1, "541a3a06f955cecc524335bc4d4a6a832b13cde180e2f604c832df4eab324869")
