-- Lua provided by RyzenAPI
-- Game: Gulman 5

-- MAIN APPLICATION
addappid(805610)

-- MAIN APP DEPOTS / PACKAGES
addappid(805611,0,"5c40be573c9489b075a46b55f74acb6b793a4cea04aa03ef2a508fc328f6249c")
addappid(805612,0,"4a2cfb633bb85324f32ebc635f4c5049e7bf867e45208fb08902a84731e13997")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
