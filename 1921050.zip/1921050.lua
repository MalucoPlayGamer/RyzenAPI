-- Lua provided by RyzenAPI
-- Game: Agony - Unrated

-- MAIN APPLICATION
addappid(1921050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921050,0,"ecca89d732aa3fd2dc495849b2364d9418127772758e36b12fda0996482a670e")
