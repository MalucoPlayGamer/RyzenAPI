-- Lua provided by RyzenAPI
-- Game: Game: Final Vendetta

-- MAIN APPLICATION
addappid(1891090)
-- Game: addappid(1891090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891091, 1, "5178aee11dbdbd40e8e0b1143cb0843e7d79afb75b02f2a5a57d5544ff8a22a1")
addappid(1891094, 1, "39230010e0014f3856a550d88a3a9f1b5dff906b7cc60091a53604b0af33078f")
