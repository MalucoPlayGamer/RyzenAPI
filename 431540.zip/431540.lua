-- Lua provided by RyzenAPI
-- Game: Frosty Kiss

-- MAIN APPLICATION
addappid(431540)
addappid(632210)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(431541, 1, "9ecb4d500ecf1b9dc65e819b8b7589e3bb9dc060d114d76a30b7c1550574bc8a")

