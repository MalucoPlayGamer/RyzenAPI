-- Lua provided by RyzenAPI
-- Game: Game: Frosty Kiss

-- MAIN APPLICATION
addappid(431540)
-- Game: addappid(431540)

-- MAIN APP DEPOTS / PACKAGES
addappid(431541, 1, "9ecb4d500ecf1b9dc65e819b8b7589e3bb9dc060d114d76a30b7c1550574bc8a")
