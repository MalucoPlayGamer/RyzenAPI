-- Lua provided by RyzenAPI 
-- Game: Exit: A Biodelic Adventure
addappid(620410)
addappid(620411, 1, "884deeeedcb942ec76f27a7c806ca5138eba3388bf4da68ea203706dc8586e4a")
