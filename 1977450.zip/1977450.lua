-- Lua provided by RyzenAPI 
-- Game: Escape From Zombie U:reloaded
addappid(1977450)
addappid(1977451, 1, "5e280692d96985f833abfa8fea32ec1e61b5282fe44bf47f5375e2c2311ed730")
