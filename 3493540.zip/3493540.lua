-- Lua provided by RyzenAPI
-- Game: Transport Fever 3

-- MAIN APPLICATION
addappid(3493540)
