-- Lua provided by RyzenAPI
-- Game: Sampling

-- MAIN APPLICATION
addappid(869090)
-- Game: addappid(869090)

-- MAIN APP DEPOTS / PACKAGES
addappid(869091, 1, "a11f1c6aab2e2a08d3bae4f9f82449c746609c666955d71c8b91e3a863a5429d")
