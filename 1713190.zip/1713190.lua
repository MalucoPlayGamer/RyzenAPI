-- Lua provided by RyzenAPI 
-- Game: AppID 1713190
addappid(1713190)
addappid(1713191, 1, "2a65919da34b962497483cded84352e13f2712777b7651ec2854a04dbb6b0a22")
