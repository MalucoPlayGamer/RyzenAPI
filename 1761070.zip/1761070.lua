-- Lua provided by SkyAPI 
-- Game: ASTLIBRA ～生きた証～ Revision Demo
addappid(1761070)
addappid(1761071, 1, "eee82cc6dd505e53dd2bf044a38c6d0f6d214d1c0329ea8b636e4d0dacc959d0")
