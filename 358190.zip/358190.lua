-- Lua provided by RyzenAPI
-- Game: Blake Stone: Aliens of Gold

-- MAIN APPLICATION
addappid(358190)

-- MAIN APP DEPOTS / PACKAGES
addappid(358191, 1, "de306830b390112dedbb11f7ad25cd5e3206541b4a7bd0047bd4675235c7ab8b")
addappid(358192, 1, "550d2fa8364f59dfa9f5b1e99e49c4063487124f082f9ca263da29213575df1d")
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070") -- (windows)

