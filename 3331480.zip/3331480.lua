-- Lua provided by RyzenAPI
-- Game: AppID 3331480

-- MAIN APPLICATION
addappid(3331480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3331481, 1, "4645bdde41aca3d181b1c41abe7bc8fe7eec43cb2a640b13110ed1494cd29f7a")
