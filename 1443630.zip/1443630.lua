-- Lua provided by RyzenAPI
-- Game: Turbo Sloths

-- MAIN APPLICATION
addappid(1443630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443631, 1, "3305c81aaeebd553ad174dfca6bf437f469f9f746ee152d76411aca088f9dace")
addappid(2226040, 0, "71f9d38ee015996ffc25b98ea772d45b605b37cfb851dc470dd785fa0082c397")
addappid(2226050, 0, "a06f984029834aa3b38b1af0f9f44c4f1a159ed570215227514570e988b3ecb3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
