-- 4110480's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Cassandra is streaming
-- Created: July 09, 2026 at 02:54:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4110480) -- Hentai Clicker: Cassandra is streaming
-- MAIN APP DEPOTS
addappid(4110481, 1, "767a79888e5b620bb184c8486855492e9c05ebd73423e6903bd9f7188ad63f91") -- Depot 4110481
setManifestid(4110481, "4621264050554477086", 172700147)