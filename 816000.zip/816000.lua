-- Lua provided by RyzenAPI
-- Game: Face au train

-- MAIN APPLICATION
addappid(816000)

-- MAIN APP DEPOTS / PACKAGES
addappid(816001, 1, "9df7714ddf70e848789f6e1512c45d0e435da625d8cceafcb7b66b2357053e92")

