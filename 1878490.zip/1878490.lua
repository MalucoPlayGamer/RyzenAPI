-- Lua provided by RyzenAPI
-- Game: addappid(1878490)

-- MAIN APPLICATION
addappid(1878490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878494,0,"9663fd6df002fa97f1bbfc1c75e123021d54a132bd430e3dbf6084d8559ac975")
