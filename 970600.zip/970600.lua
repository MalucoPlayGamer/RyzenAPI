-- Lua provided by RyzenAPI
-- Game: AppID 970600

-- MAIN APPLICATION
addappid(970600)

-- MAIN APP DEPOTS / PACKAGES
addappid(970601, 1, "22e0ce6554f373972c48c9ebbf531dc83649e208d94e67ee17b063bb7a769b17")
addappid(970602, 1, "0687b49b7316eab9e155fdef3dfccea29c53535e6c70d6e0c3104440a53cbc29")
addappid(970603, 1, "21531ffaef9ef95a5ca7574960c7f0b5cf986a922961f08d15752298c38f3b42")
addappid(970604, 1, "0e7f69b6c67a260f809e995d20f44b568841fa5344ed4b5084fe4cb124c0e8e7")
addappid(970605, 1, "857b4f392f80e753e72435c4d299a1900335359f2e60addc4bf881aaeb3cf3a8")
addappid(970606, 1, "8751c3dc94f9a12d5fe01320023bc88100db6d51a33d15b9a8464e4c154f38d6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(990170)
