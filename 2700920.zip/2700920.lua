-- Lua provided by SkyAPI 
-- Game: AppID 2700920
addappid(2700920)
addappid(2700921, 1, "b11b3b0e202153884e017b272cc272864f1cf8de719b803ac23c4c7a7533ca48")
