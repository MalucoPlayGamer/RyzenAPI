-- Lua provided by RyzenAPI 
-- Game: Delta Force Demo
addappid(2951290)
addappid(2951291, 1, "aa4f04142e2bfbb93471aa2dfde711dcfaf3c8e031b2a695beb2b46b6c0daf24")
addappid(2951292, 1, "b18213a32a06c699e18719f92a7dbad4bcb30b2173bcf9ac669683fedef30b9d")
