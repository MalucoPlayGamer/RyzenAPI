-- Lua provided by RyzenAPI
-- Game: Modern Combat 5

-- MAIN APPLICATION
addappid(921060)

-- MAIN APP DEPOTS / PACKAGES
addappid(921061, 1, "50c4b9d8f511940c1b82f93378818b6dfe93c78f1bcedc50dcae01d7676bdaa9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
