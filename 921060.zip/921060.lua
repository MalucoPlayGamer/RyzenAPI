-- Lua provided by RyzenAPI
-- Game: Modern Combat 5

-- MAIN APPLICATION
addappid(921060)

-- MAIN APP DEPOTS / PACKAGES
addappid(921061, 1, "50c4b9d8f511940c1b82f93378818b6dfe93c78f1bcedc50dcae01d7676bdaa9")
