-- Lua provided by RyzenAPI 
-- Game: Hentai Splash
addappid(1257840)
addappid(1257841, 1, "0f1634a37289d85184aca11fdef756e15dd4bb1838ad2482ea6ae81089e22379")
