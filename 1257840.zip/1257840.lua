-- Lua provided by RyzenAPI
-- Game: Hentai Splash

-- MAIN APPLICATION
addappid(1257840)
addappid(1269440)
addappid(1302810)
addappid(1315460)
addappid(1328880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257841, 1, "0f1634a37289d85184aca11fdef756e15dd4bb1838ad2482ea6ae81089e22379")

