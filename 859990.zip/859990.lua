-- Lua provided by RyzenAPI
-- Game: Eggs 1942

-- MAIN APPLICATION
addappid(859990)

-- MAIN APP DEPOTS / PACKAGES
addappid(859991,0,"821c44aa673fbd7087c71ba04541ba8720ddb5c35884abca122aa03d16f79899")

