-- Lua provided by RyzenAPI 
-- Game: 幻想异乡曲 Butterfly~Rin
addappid(1094290)
addappid(1094291, 1, "7b04dd7e1c8c4f1a04cfeff7115a5814c58afbfa6ea0cb2fde6d1c0b66d0d09e")
