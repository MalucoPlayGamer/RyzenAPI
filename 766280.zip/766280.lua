-- Lua provided by RyzenAPI
-- Game: A Light in the Dark

-- MAIN APPLICATION
addappid(766280)
-- Game: addappid(766280)

-- MAIN APP DEPOTS / PACKAGES
addappid(766281, 1, "a01a6c463d14dc40f80b28ce2fcece963abe69f1e015079c60c872e5d497454a")
addappid(766282, 1, "7ed22fd6444c981403af9238b7814bfe3553cfcc52ce3864ff4da6b017bd13eb")
addappid(889630, 0, "af16718f7ac7d21591a6d695544ed74f8e774e7fddaf57b9307443a6c608947a")
addappid(889640, 0, "b2112f9869eeffcefdab80fb2c3a6d01e584363a942194b26ae5891a1a044737")
