-- Lua provided by RyzenAPI
-- Game: Monobeno-HAPPY END- Deluxe

-- MAIN APPLICATION
addappid(831660)

-- MAIN APP DEPOTS / PACKAGES
addappid(831661, 1, "92e8629478d922fc003ccae53e556653f67ffa932d410aa7c44d826799bd23e2")
addappid(831662, 1, "d6fbbe087294cf9d1069d09882d1434475c9b1619e95dd09b7d1b73c755ee3a5")
addappid(831663, 1, "c465d420a567f9d44f0708492cd2ed78b38ccf556d6614edfa54627ae3728d11")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
