-- Lua provided by RyzenAPI
-- Game: Game: AppID 1035010

-- MAIN APPLICATION
addappid(1035010)
-- Game: addappid(1035010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035011, 1, "3962e8021b65c0e4c13fde449512d4cc1f820f6bb6caccf809ed320292d099c6")
