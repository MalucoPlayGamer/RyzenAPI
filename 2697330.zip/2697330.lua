-- Lua provided by RyzenAPI
-- Game: 2697330

-- MAIN APPLICATION
addappid(2697330)
-- Game: addappid(2697330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697331, 1, "0595977ef0c9aedb7baa11a93dc963e783964660aa38101fc159cc2170d5db67")
