-- Lua provided by RyzenAPI
-- Game: Rush Rally Origins

-- MAIN APPLICATION
addappid(1728660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728661, 1, "7a8eaff124856cadfac04971c00d363e3b0071e9a1662106db7a95963093a7b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
