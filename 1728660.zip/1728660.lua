-- Lua provided by RyzenAPI
-- Game: Rush Rally Origins

-- MAIN APPLICATION
addappid(1728660)
-- Game: addappid(1728660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728661, 1, "7a8eaff124856cadfac04971c00d363e3b0071e9a1662106db7a95963093a7b2")
