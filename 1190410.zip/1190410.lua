-- Lua provided by RyzenAPI
-- Game: Crazy city

-- MAIN APPLICATION
addappid(1190410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190411, 1, "36a8c409805e424994dec49874bbfc24592e8dfb75c751022bd1b0a38e47948c")

