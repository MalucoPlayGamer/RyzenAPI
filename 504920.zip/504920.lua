-- Lua provided by RyzenAPI
-- Game: 39 Days to Mars

-- MAIN APPLICATION
addappid(504920)

-- MAIN APP DEPOTS / PACKAGES
addappid(504921, 1, "744b5e8f8fb2b4b3c67c4f4dd5fe6d0399f1039abfc30370b6229407be6ee97b")
addappid(504924, 1, "09e91e39256a73e8eb8871c5cfb8aac7b5c3efab87fbea2ecdb73a7b8f40ca70")

