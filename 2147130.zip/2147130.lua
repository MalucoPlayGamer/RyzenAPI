-- Lua provided by RyzenAPI
-- Game: Crazy Edition of Stunts

-- MAIN APPLICATION
addappid(2147130)
-- Game: addappid(2147130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147131, 1, "2b5ff3732bd9e1ad9c409e7dbf753a42f0d99bf33ce45b738b6ab3b7896ac8e1")
