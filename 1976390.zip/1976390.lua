-- Lua provided by RyzenAPI
-- Game: Game: Prepare Uranus: Exploring Black Holes for Adults

-- MAIN APPLICATION
addappid(1976390)
-- Game: addappid(1976390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976391, 1, "7c52be3bbae1190f882e7c355079cb77880b802e0e21c1313338ba96e2089df6")
