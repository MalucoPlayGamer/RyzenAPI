-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Season Pass Bonus

-- MAIN APPLICATION
addappid(1634696)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634696,0,"be25947a35ab4ce739e788e94580dfcacdf316d811c302eaa3c4c3cb1d21d10d")

