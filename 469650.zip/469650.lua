-- Lua provided by RyzenAPI
-- Game: Disney Movies VR

-- MAIN APPLICATION
addappid(469650)

-- MAIN APP DEPOTS / PACKAGES
addappid(469651, 1, "3a9551505b6329c9224d062b7bf11feb99ad38bfc669a827bba393ac729250a0")
