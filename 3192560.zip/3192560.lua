-- Lua provided by RyzenAPI
-- Game: Phantom Thief Angels: Twin Angel - Labyrinth of Time and World - Re:light

-- MAIN APPLICATION
addappid(3192560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192562,0,"076998ba0a73ebc324c7dd5a8ad479f150a38d6e511cc24210b43aad11232b91")
addappid(3192563,0,"449e3d539a3143f6bd0cdd3aeeee12d0c88194c17d93b99b807581c3c87020b8")
addappid(3524192,0,"cdefe32840ea38337a347e2794d6e26714269aac0b102c68597207f3e27b1009")

