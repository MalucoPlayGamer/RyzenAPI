-- Lua provided by SkyAPI 
-- Game: Zombies and Orcs
addappid(3387740)
addappid(3387741, 1, "36c0d2efc2fb006625522d278a5bc173887997115e295a33382b81e163d0722d")
