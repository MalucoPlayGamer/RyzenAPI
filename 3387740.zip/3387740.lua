-- Lua provided by RyzenAPI
-- Game: Zombies and Orcs

-- MAIN APPLICATION
addappid(3387740)
-- Game: addappid(3387740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3387741, 1, "36c0d2efc2fb006625522d278a5bc173887997115e295a33382b81e163d0722d")
