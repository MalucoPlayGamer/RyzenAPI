-- Lua provided by RyzenAPI
-- Game: Game: Gundemonium Recollection

-- MAIN APPLICATION
addappid(92200)
-- Game: addappid(92200)

-- MAIN APP DEPOTS / PACKAGES
addappid(92201, 1, "668c16aade6903d1425f8939ddada11db8a50abdabadab10ff6efdd950258012")
addappid(92202, 1, "7afd9e31ff1bda8de92632a0705fe9f7daf138f0f904503428cb531def06f042")
addappid(92203, 1, "a742428fb824a518767cfe4929d95f40ebc8219a4699e53a56e0549b84fe4644")
addappid(92204, 1, "e40debe2fafac78099d2bbf2c99a29a5668aa86167f27863512c5f8f4092d15c")
addappid(92205, 1, "4d523d685cc377a63eac50f56517f738ef1834ed88e45bc5f8189442deb624ee")
addappid(92206, 1, "741f971c34eb111a4b6afe2d7f4716f14c1ecb811397b54470246a3093a2cbf0")
