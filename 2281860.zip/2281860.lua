-- Lua provided by RyzenAPI
-- Game: Duelyst GG

-- MAIN APPLICATION
addappid(2281860)
-- Game: addappid(2281860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281861, 1, "154c71d9f2d60103e1accbaa01eef04b786510eca75deccdf59bced144fbae7b")
