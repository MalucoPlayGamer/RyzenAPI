-- Lua provided by RyzenAPI
-- Game: HIT

-- MAIN APPLICATION
addappid(336670)
addappid(346870)

-- MAIN APP DEPOTS / PACKAGES
addappid(336671, 1, "8d9c30dba5ce01dca48dd7c896d161260f028833abb42fba96009dcbc667fbbf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
