-- Lua provided by RyzenAPI
-- Game: Game: HIT

-- MAIN APPLICATION
addappid(336670)
addappid(346870)
-- Game: addappid(336670)

-- MAIN APP DEPOTS / PACKAGES
addappid(336671, 1, "8d9c30dba5ce01dca48dd7c896d161260f028833abb42fba96009dcbc667fbbf")
