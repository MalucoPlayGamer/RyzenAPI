-- Lua provided by RyzenAPI
-- Game: HIT

-- MAIN APPLICATION
addappid(336670)
addappid(346870)

-- MAIN APP DEPOTS / PACKAGES
addappid(336671, 1, "8d9c30dba5ce01dca48dd7c896d161260f028833abb42fba96009dcbc667fbbf")

