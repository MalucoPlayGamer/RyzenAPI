-- Lua provided by RyzenAPI
-- Game: Swing & Miss

-- MAIN APPLICATION
addappid(1204750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204751, 1, "6e2ebab83e448de6384816033b4909296e2ed3914870c3e57d51dc7bbe4b9874")

