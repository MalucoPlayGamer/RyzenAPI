-- Lua provided by RyzenAPI
-- Game: 1116590

-- MAIN APPLICATION
addappid(1116590)
-- Game: addappid(1116590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116591, 1, "dcc174df5a0f39b396c3a1781746fd4c61b62798bc9aa88833b040b16344c933")
