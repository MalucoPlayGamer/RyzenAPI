-- Lua provided by RyzenAPI
-- Game: Full Animal Party

-- MAIN APPLICATION
addappid(1116590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116591, 1, "dcc174df5a0f39b396c3a1781746fd4c61b62798bc9aa88833b040b16344c933")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
