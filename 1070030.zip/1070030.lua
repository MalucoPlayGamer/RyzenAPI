-- Lua provided by RyzenAPI
-- Game: Under Stranger Stars

-- MAIN APPLICATION
addappid(1070030)
-- Game: addappid(1070030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070031, 1, "807c171f542210435f242f7014e857661f29faa041adfaf321a3b7eb2cbf7709")
