-- Lua provided by RyzenAPI
-- Game: addappid(1632560)

-- MAIN APPLICATION
addappid(1632560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632560,0,"dfa84065cc9af7ccf5eb28de437a579ea2c8ea0cd35c6ec8a47afc8bef339875")
