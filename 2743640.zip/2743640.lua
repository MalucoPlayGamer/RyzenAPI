-- Lua provided by RyzenAPI
-- Game: 2743640

-- MAIN APPLICATION
addappid(2743640)
-- Game: addappid(2743640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743640,0,"5dd8c61606a902cc3bb8b04df445888a5cf991b7e136f8b107d0eb710ce4819d")
