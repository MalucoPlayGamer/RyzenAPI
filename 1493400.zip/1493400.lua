-- Lua provided by RyzenAPI
-- Game: Game: Jack's Labyrinth

-- MAIN APPLICATION
addappid(1493400)
-- Game: addappid(1493400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493401, 1, "4bf632968310046ca360aadd666dea3510dda4d9965da42ff6065fb2ca874dcd")
