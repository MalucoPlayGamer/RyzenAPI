-- Lua provided by RyzenAPI
-- Game: Orc's Bride

-- MAIN APPLICATION
addappid(2727020)
-- Game: addappid(2727020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727021, 1, "2886a98eb4a19d158e6a14fc5c98d2604af8ab9a1bcb87b28d4f93c02e8eb0c0")
