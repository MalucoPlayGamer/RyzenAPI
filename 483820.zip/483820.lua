-- Lua provided by RyzenAPI
-- Game: addappid(483820)

-- MAIN APPLICATION
addappid(483820)

-- MAIN APP DEPOTS / PACKAGES
addappid(483821, 1, "a0058766b6b019a093ef84a977d9b23048a5905f798b17d57f7d5a715cbdee2d")
