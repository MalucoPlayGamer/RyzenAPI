-- Lua provided by RyzenAPI
-- Game: Four Realms

-- MAIN APPLICATION
addappid(483820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(483821, 1, "a0058766b6b019a093ef84a977d9b23048a5905f798b17d57f7d5a715cbdee2d")
