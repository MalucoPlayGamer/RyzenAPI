-- Lua provided by RyzenAPI
-- Game: addappid(1057740)

-- MAIN APPLICATION
addappid(1057740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057741, 1, "3365640602fc0ca719cc104e9177f00e32b2f0784c5a0e03f8a5351cff5e06e7")
