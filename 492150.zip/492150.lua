-- Lua provided by RyzenAPI
-- Game: RPG World - Action RPG Maker

-- MAIN APPLICATION
addappid(492150)
-- Game: addappid(492150)

-- MAIN APP DEPOTS / PACKAGES
addappid(492151, 1, "07624be5689efdac0d7c683084b70ac47bf95c5fcadfa55defaa15d4888591f0")
