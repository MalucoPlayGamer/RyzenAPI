-- Lua provided by RyzenAPI
-- Game: Western 1849 Reloaded

-- MAIN APPLICATION
addappid(576980)

-- MAIN APP DEPOTS / PACKAGES
addappid(576981, 1, "16ea40fb651dfedbcad0f72ef3ae5600cb14910c61acbeb51946ce2a8f07a581")
