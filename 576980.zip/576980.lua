-- Lua provided by RyzenAPI
-- Game: Game: AppID 576980

-- MAIN APPLICATION
addappid(576980)
-- Game: addappid(576980)

-- MAIN APP DEPOTS / PACKAGES
addappid(576981, 1, "16ea40fb651dfedbcad0f72ef3ae5600cb14910c61acbeb51946ce2a8f07a581")
