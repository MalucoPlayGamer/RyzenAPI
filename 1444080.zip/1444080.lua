-- Lua provided by RyzenAPI
-- Game: Dewdrop Dynasty

-- MAIN APPLICATION
addappid(1444080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444083,0,"a161f99f4105fcbc319509ca560f55a807c5c0b817df0e7cb80ea8f2e3050b66")

