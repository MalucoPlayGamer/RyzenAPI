-- Lua provided by RyzenAPI
-- Game: wasteland of east

-- MAIN APPLICATION
addappid(2431600)
-- Game: addappid(2431600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431601, 1, "42b0ac358f93cd474ce48175128da725404f69ee397a9d3e4e4011f8cdfba74c")
addappid(2431602, 1, "09248a0922a3c37d600b113476f347be4261c9f7b7aa7ab476273b27abda3488")
