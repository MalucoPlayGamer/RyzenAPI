-- Lua provided by RyzenAPI
-- Game: AppID 493280

-- MAIN APPLICATION
addappid(493280)
-- Game: addappid(493280)

-- MAIN APP DEPOTS / PACKAGES
addappid(493281, 1, "a52c3d75e15c97d7ff48db74b3708499de1b7f4d1ec21b4df5735952a3d32fc7")
addappid(493282, 1, "9e56aff1acaeb91bbb238a82679a326745fff4422abb0b0257b0f478d71655e0")
