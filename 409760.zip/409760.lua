-- Lua provided by RyzenAPI
-- Game: Angry Video Game Nerd II: ASSimilation Original Soundtrack

-- MAIN APPLICATION
addappid(409760)

-- MAIN APP DEPOTS / PACKAGES
addappid(409760,0,"eb080bcf081f227632ba6be7483e343894258b03c7076e1661f9b2575fa38eeb")
