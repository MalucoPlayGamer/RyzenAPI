-- Lua provided by RyzenAPI
-- Game: Towards Future - CG Gallery & Character Emoji Pack

-- MAIN APPLICATION
addappid(1888090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888090,0,"0ed54a1407e3abe2bb6088f8244ef03190ef8cf51b5e8e5a951c097fffa84355")

