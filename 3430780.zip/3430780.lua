-- Lua provided by RyzenAPI
-- Game: Game: Escape the Tower

-- MAIN APPLICATION
addappid(3430780)
-- Game: addappid(3430780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3430781, 1, "22441c5c8aadc60440d261370f79ab3b216b1970a0081531b8892dacafd38cf6")
