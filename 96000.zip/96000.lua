-- Lua provided by RyzenAPI
-- Game: AppID 96000

-- MAIN APPLICATION
addappid(96000)
addappid(228985)
-- Game: addappid(96000)

-- MAIN APP DEPOTS / PACKAGES
addappid(96001, 1, "12ff30d4ced068794e18db280935da5b23295dc0a4222d4ce50b0f92d9bddc46")
addappid(96002, 1, "980b350998d8e8ba4a515349801c927e1eaf3219f8bfeb97b879f3c0dd3ce8cd")
addappid(96003, 1, "5b7a47800c9ed2cf0777af17b5eaa328126fbd20e1197535cf667c6fda0e664f")
addappid(96005, 1, "731982d3ce8fbd5eefe98e3c2e8a639c3692507f3674be19ec8533be927952a7")
