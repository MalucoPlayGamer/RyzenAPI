-- Lua provided by RyzenAPI
-- Game: addappid(600260)

-- MAIN APPLICATION
addappid(600260)

-- MAIN APP DEPOTS / PACKAGES
addappid(600261, 1, "7683c72db381ae82f56c3397e5977457d264ec4b513e044800a7d7dba9ae6a03")
