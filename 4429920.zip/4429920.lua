-- 4429920's Lua and Manifest Created by Hubcap Manifest
-- Sex Shop Simulator: Sinful Girls
-- Created: July 10, 2026 at 16:31:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4429920) -- Sex Shop Simulator: Sinful Girls
-- MAIN APP DEPOTS
addappid(4429922, 1, "9cdf4c07eb3edb208d52366937f72ac34e75fedda02344bf0348d01e5cac0f75") -- Depot 4429922
setManifestid(4429922, "585928889604675313", 3946270483)