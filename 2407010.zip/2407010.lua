-- Lua provided by RyzenAPI
-- Game: 木夕镇的午夜轮回 Midnight cycle in Muxi Town

-- MAIN APPLICATION
addappid(2407010)
-- Game: addappid(2407010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407011, 1, "a9b61b5a6f8e5c016c250c15f194da4b8fee546a8cc938e1cae30e9b67c22153")
