-- Lua provided by RyzenAPI
-- Game: AppID 562260

-- MAIN APPLICATION
addappid(562260)

-- MAIN APP DEPOTS / PACKAGES
addappid(562261, 1, "f2039daed60323b80d2815cd02fdca9722f87c69aaf1930e14721d36ebbc02f9")
addappid(562262, 1, "6463c05beba0af0f868130daa2e5d3fc9fc9e34ccb30248923745d6208a4cb4c")

