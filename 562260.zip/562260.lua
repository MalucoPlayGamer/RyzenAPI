-- Lua provided by RyzenAPI
-- Game: WAVESHAPER

-- MAIN APPLICATION
addappid(562260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(562261, 1, "f2039daed60323b80d2815cd02fdca9722f87c69aaf1930e14721d36ebbc02f9")
addappid(562262, 1, "6463c05beba0af0f868130daa2e5d3fc9fc9e34ccb30248923745d6208a4cb4c")
