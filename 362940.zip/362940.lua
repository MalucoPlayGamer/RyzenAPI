-- Lua provided by RyzenAPI
-- Game: addappid(362940)

-- MAIN APPLICATION
addappid(362940)

-- MAIN APP DEPOTS / PACKAGES
addappid(362941, 1, "f1d431dcc7d45ef22630ee55a7f60c4fd51248f2c0dd9aed12e24d53f34b1d9b")
