-- Lua provided by RyzenAPI
-- Game: Courier of the Crypts

-- MAIN APPLICATION
addappid(362940)

-- MAIN APP DEPOTS / PACKAGES
addappid(362941, 1, "f1d431dcc7d45ef22630ee55a7f60c4fd51248f2c0dd9aed12e24d53f34b1d9b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
