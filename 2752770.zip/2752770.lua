-- Lua provided by RyzenAPI
-- Game: JongRo 3_Street

-- MAIN APPLICATION
addappid(2752770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752771, 1, "19a4fc312f4a0809386e7aaece6d2f62de78a2c8c824b557b7ec1861ed109e3c")

