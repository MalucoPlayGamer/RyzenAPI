-- Lua provided by RyzenAPI 
-- Game: Minigame Madness
addappid(1408080)
addappid(1408081, 1, "a9d5e9858c3ac9c1af67c66759fa3d885cdcf991de3ae4acbcd7637c3aa5dbba")
