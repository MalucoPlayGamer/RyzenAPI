-- Lua provided by RyzenAPI
-- Game: Beat Saber - Monstercat Mixtape 2 - Öwnboss & Selva - "RIOT"

-- MAIN APPLICATION
addappid(3274260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274260,0,"004693a3ab320208bd06f572285501b1e3b4f934d9773b25db6b738d8ed1cc2b")
