-- Lua provided by RyzenAPI
-- Game: addappid(2155090)

-- MAIN APPLICATION
addappid(2155090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155091, 1, "5f25462dcee44ca76fca51f4d87c5dc74e8d982d6acda58a4b1d8e515ba219a1")
