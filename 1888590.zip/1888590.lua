-- Lua provided by RyzenAPI
-- Game: Rotund Zero

-- MAIN APPLICATION
addappid(1888590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888591, 1, "1cf94b651738de4c0632c12842ca7087ab1b6814790e252c6f5dbb185d432d08")

