-- Lua provided by SkyAPI 
-- Game: Cube Defense
addappid(999640)
addappid(999641, 1, "cc1487f39e7d1073b93f1250e18cb3f9efc751047b8e2c080494b88a72770cb8")
