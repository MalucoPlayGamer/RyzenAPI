-- Lua provided by RyzenAPI
-- Game: 1378310

-- MAIN APPLICATION
addappid(1378310)
-- Game: addappid(1378310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378311, 1, "e3048761b8bb18a4cc8f05fc954a2f373859d34f7ed1f469f6ee26b24fd56097")
