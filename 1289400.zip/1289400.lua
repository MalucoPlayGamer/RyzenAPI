-- Lua provided by RyzenAPI
-- Game: Moving Out - Original Soundtrack

-- MAIN APPLICATION
addappid(1289400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289401, 1, "9a4ce4e3a865cbe0338d71eef0e50cb41eab3c5a5a6a4606a360038544512ef8")
addappid(1289402, 1, "e24a3b6422ecd41a59350d186875d3ab1b7b8b2cb81d1ad60863c74135412bd9")

