-- Lua provided by SkyAPI 
-- Game: AppID 602700
addappid(602700)
addappid(602701, 1, "8e9da79462da88439f077656b90c11bc078de5ef9437be8cdc1f77090c2428c6")
