-- Lua provided by RyzenAPI
-- Game: AppID 602700

-- MAIN APPLICATION
addappid(602700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(602701, 1, "8e9da79462da88439f077656b90c11bc078de5ef9437be8cdc1f77090c2428c6")

