-- Lua provided by RyzenAPI
-- Game: addappid(1111620)

-- MAIN APPLICATION
addappid(1111620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111621, 1, "77b9f5969ea53d6d3780812b3faa132b91e4f193c2db485578e41d8bf40ccd65")
