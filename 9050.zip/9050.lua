-- Lua provided by RyzenAPI
-- Game: 9050

-- MAIN APPLICATION
addappid(9050)
-- Game: addappid(9050)

-- MAIN APP DEPOTS / PACKAGES
addappid(9051, 1, "a6b3510995bf7cc4e56b42c020d52546ab9ecc6ff1bf04bc28e05ab28af78ff5")
addappid(9052, 1, "0bddb46cb1153bbb6b7d38c18eb032f8866566caf51b17b1a5230b9f273f3993")
addappid(9053, 1, "94a8f12d066cde33d47a0ad640e4478a59e367a08a21bb6061c5d5ee24a46697")
addappid(9054, 1, "c6119bfdb230bbaf193f988ed17bd1a6c77956369e05b0d55c7e68e91d488463")
addappid(9055, 1, "9c0cdfa9d2cd8d82f641efe69dd99fba4562dbf2c98b47585e928b6fbcbd2c15")
addappid(9057, 1, "ef243538908734ad17979cd9d77f9b615a535bdb7b37313f49b7a7b35bc830aa")
