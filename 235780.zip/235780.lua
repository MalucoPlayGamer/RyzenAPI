-- Lua provided by RyzenAPI
-- Game: MINERVA: Metastasis

-- MAIN APPLICATION
addappid(235780)

-- MAIN APP DEPOTS / PACKAGES
addappid(235781, 1, "b26e57edc06c7708c0d85d849e0e90faa8bc48f8f5653c5310c758c5bdaab973")

