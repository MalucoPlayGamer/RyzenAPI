-- Lua provided by RyzenAPI
-- Game: Game: Due Process - Original Soundtrack

-- MAIN APPLICATION
addappid(1486040)
-- Game: addappid(1486040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486041, 1, "3798caf676df0d23de0fb7d9d0aa50629651fe85d2e8c2156fe551f50b118de8")
