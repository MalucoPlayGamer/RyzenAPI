-- Lua provided by RyzenAPI
-- Game: Game: AppID 2823750

-- MAIN APPLICATION
addappid(2823750)
-- Game: addappid(2823750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2823751, 1, "a05fe6ef045947fc5f84d052a2b3109cb5265d060bd392dad8a47d80b2be3650")
