-- Lua provided by RyzenAPI
-- Game: addappid(1042080)

-- MAIN APPLICATION
addappid(1042080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042081, 1, "a920a586f1b8ca0e3950d531284acf6afa6debea520bb1b6f4b8a970d5c1c4fb")
