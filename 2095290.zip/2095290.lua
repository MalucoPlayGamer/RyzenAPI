-- Lua provided by RyzenAPI
-- Game: Theseus Protocol

-- MAIN APPLICATION
addappid(2095290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2095291, 1, "943b1dae8fc62582d97297dd318a6bc8cf45a8892fb344706f08ef112629392a")

