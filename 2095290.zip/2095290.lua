-- Lua provided by RyzenAPI
-- Game: Game: Theseus Protocol

-- MAIN APPLICATION
addappid(2095290)
-- Game: addappid(2095290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095291, 1, "943b1dae8fc62582d97297dd318a6bc8cf45a8892fb344706f08ef112629392a")
