-- Lua provided by SkyAPI 
-- Game: AppID 562160
addappid(562160)
addappid(562161, 1, "9a02e0384af0fef80962481cb41a097440e1d296a207c210608750ffe29239d7")
