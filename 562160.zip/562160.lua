-- Lua provided by RyzenAPI
-- Game: The Inner Darkness

-- MAIN APPLICATION
addappid(562160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(562161, 1, "9a02e0384af0fef80962481cb41a097440e1d296a207c210608750ffe29239d7")

