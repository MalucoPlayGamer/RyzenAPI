-- Lua provided by RyzenAPI
-- Game: addappid(1605890)

-- MAIN APPLICATION
addappid(1605890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605891, 1, "db549120e71e239860f13d4cbe22524e8ac5b79ae8e7b344af61d1d4b63cce42")
