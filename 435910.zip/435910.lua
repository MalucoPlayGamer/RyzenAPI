-- Lua provided by RyzenAPI
-- Game: Firewatch Original Soundtrack

-- MAIN APPLICATION
addappid(435910)
-- Game: addappid(435910)

-- MAIN APP DEPOTS / PACKAGES
addappid(435911, 1, "75179127a8019f86ecd887ddadaa3869255787804a40056da40c0823e358ba20")
