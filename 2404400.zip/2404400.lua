-- Lua provided by RyzenAPI
-- Game: 2404400

-- MAIN APPLICATION
addappid(2404400)
-- Game: addappid(2404400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404401, 1, "7a40fd35d68a825c922c4c6a9871e02633e4534b43ce469ddcb0d8e5e1579f75")
