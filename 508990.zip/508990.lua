-- Lua provided by RyzenAPI
-- Game: AppID 508990

-- MAIN APPLICATION
addappid(508990)
-- Game: addappid(508990)

-- MAIN APP DEPOTS / PACKAGES
addappid(508991, 1, "2f84b7302ab767c4787dcdc6413e4bff23e015f4a4d59db6c681e314fa5889fe")
