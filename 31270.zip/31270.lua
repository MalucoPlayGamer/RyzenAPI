-- Lua provided by RyzenAPI 
-- Game: Puzzle Agent
addappid(31270)
addappid(31271, 1, "c891f0862fed598551270bcbf505e2c77e825fe9b70296c437e296b773d40ada")
addappid(31272, 1, "7f2d7f6cc19e38833fc635b006b90b795eef97558efd02c54d226d4a810442bc")
