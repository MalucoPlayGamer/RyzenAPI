-- Lua provided by RyzenAPI 
-- Game: Cookie Clicker
addappid(1454400)
addappid(1454401, 1, "dc8be6e8bb8cf9a7d3f548fe759eb532def1c3d380deece391d81dafa6c96e67")
addappid(1454402, 1, "39c00dfd8ff729f8012400b55fc6d55b1c21b5ee2b012fe72a6c33b5b5ec176b")
