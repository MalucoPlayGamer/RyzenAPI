-- Lua provided by RyzenAPI
-- Game: Naheulbeuk's Dungeon Master

-- MAIN APPLICATION
addappid(2005160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005161, 1, "8d1fded44b72fbcda3669981504d33af9d5c1af585517cc4f594714eea783ee6")

