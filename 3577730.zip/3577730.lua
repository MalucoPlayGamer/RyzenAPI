-- Lua provided by RyzenAPI
-- Game: Wallpaper Pack - Aquilon's Sex Quest

-- MAIN APPLICATION
addappid(3577730)
-- Game: addappid(3577730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3577730,0,"ed22e32251f2722950428edc73435cd397da28fa3573de1ccfed89b9fff4d0e3")
