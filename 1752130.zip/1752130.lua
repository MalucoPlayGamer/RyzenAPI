-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Pivot Point

-- MAIN APPLICATION
addappid(1752130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752130,0,"063c3a53393b57dff30aa799ca76ba76d8f5982228142038793839a6b14a5474")

