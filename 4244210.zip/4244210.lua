-- Lua provided by RyzenAPI
-- Game: Open The Gate Just A Little

-- MAIN APPLICATION
addappid(4244210) -- Open The Gate Just A Little

-- MAIN APP DEPOTS / PACKAGES
addappid(4244211, 1, "5f63ad118c56a3fcae73e5f6fefc139314eb2fd04837c4b319d648ae97dc1753") -- Depot 4244211
addappid(4244212, 1, "e7f343956b6e33a5ad5d9438615ae3e7963e0cf16de52879481d3c5849f86126") -- Depot 4244212

