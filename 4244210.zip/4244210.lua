-- 4244210's Lua and Manifest Created by Hubcap Manifest
-- Open The Gate Just A Little
-- Created: August 14, 2026 at 00:45:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4244210) -- Open The Gate Just A Little
-- MAIN APP DEPOTS
addappid(4244211, 1, "5f63ad118c56a3fcae73e5f6fefc139314eb2fd04837c4b319d648ae97dc1753") -- Depot 4244211
setManifestid(4244211, "6507135222451033246", 181315508)
addappid(4244212, 1, "e7f343956b6e33a5ad5d9438615ae3e7963e0cf16de52879481d3c5849f86126") -- Depot 4244212
setManifestid(4244212, "3200109279953348630", 244888691)