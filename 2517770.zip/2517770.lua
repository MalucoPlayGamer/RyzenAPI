-- Lua provided by RyzenAPI
-- Game: SWORDCAR

-- MAIN APPLICATION
addappid(2517770)
-- Game: addappid(2517770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517771, 1, "5ceea076063863fea3dd88e2e5610e729ee6ceb7971b513c5f85204a114d9c6c")
