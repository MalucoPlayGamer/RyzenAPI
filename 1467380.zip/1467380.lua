-- Lua provided by RyzenAPI
-- Game: Ancient Warriors Casino Jackpot

-- MAIN APPLICATION
addappid(1467380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467381, 1, "51437ec695ec36cc934822d7c766b61543ed3fd3fa66fc477df5155d5cffcce6")

