-- Lua provided by RyzenAPI
-- Game: Milthm

-- MAIN APPLICATION
addappid(2498480)
-- Game: addappid(2498480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498481, 1, "e941ab7b943f44c72ae37d322df1e950b8e08d1bca991be7391788d89ac1ea60")
addappid(2498482, 1, "fde356a3ed060c6a2dc704f50b51391fa32d5cce468ce4da471c957508027936")
addappid(2498483, 1, "94e1fd0dcfb7213fa8cd7c0bc85d7ca89d23a5a937f0f2cb1585a11f4ec53f3d")
