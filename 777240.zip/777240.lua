-- Lua provided by SkyAPI 
-- Game: AppID 777240
addappid(777240)
addappid(777241, 1, "579613dadf8956ae4493d145a1c0b7ed7257555cd509a14fdfc9f2c70371e663")
addappid(810240, 0, "2d94e722ca012af3b71692288e797f8a945ee555940affcb2ec6645f438d1faa")
