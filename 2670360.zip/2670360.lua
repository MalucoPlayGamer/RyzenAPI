-- Lua provided by RyzenAPI
-- Game: The Smell of Death - A Tsugunohi Tale - STEAM EDITION

-- MAIN APPLICATION
addappid(2670360)
-- Game: addappid(2670360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670362,0,"def23d582efb0773a573020dba244a766a9871265b74dc5e7e76137e0bdab466")
addappid(2670363,0,"4d0177a7bcd62dccd52dabfe64061a0aa1444b0ce5f1d6f1f82411bb9b88cae6")
addappid(2670364,0,"0bacb3c834d1f0b9aee29c3b0de794127f7c1a7573f3167bc78ed4f8c8b9ae27")
addappid(2670365,0,"0308dc680f4b4272cd9c071f2c4028044f5a5b8007e5f86643eda6729f912b81")
