-- Lua provided by RyzenAPI
-- Game: My Cute Girls

-- MAIN APPLICATION
addappid(1844260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844261, 1, "b408a1d36ea2bc95b7f999fb22efbc51f120ab5341db01e60e0c2dc7c50b3d76")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1858610)
