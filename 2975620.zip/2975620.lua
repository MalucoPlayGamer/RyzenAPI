-- Lua provided by RyzenAPI
-- Game: MILF's Plaza - Bonus Content

-- MAIN APPLICATION
addappid(2975620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2975620,0,"25eaae474555219c50666945f1ab5be6859a71892f78fa62770634e28b3bc8c2")

