-- Lua provided by RyzenAPI
-- Game: 966400

-- MAIN APPLICATION
addappid(966400)
-- Game: addappid(966400)

-- MAIN APP DEPOTS / PACKAGES
addappid(966401, 1, "d57f842ab9921f01dc0f976c9cb1bca09d8b2ba74f6c2362ebbf188879d03394")
