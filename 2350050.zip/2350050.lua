-- Lua provided by RyzenAPI
-- Game: 2350050

-- MAIN APPLICATION
addappid(2350050)
-- Game: addappid(2350050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350051, 1, "d37a0eeb052ba21bce21ce2201a8f18b67f1009f69ed80a8c00c3608087309b9")
