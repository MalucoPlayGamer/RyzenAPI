-- Lua provided by RyzenAPI
-- Game: Game: Lusitania: The Experience

-- MAIN APPLICATION
addappid(1260710)
-- Game: addappid(1260710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260711, 1, "dff664313812bcbadd69f10ef983bb150613a01c01cf179fba0d2df205e79732")
