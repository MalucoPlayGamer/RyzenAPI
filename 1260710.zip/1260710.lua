-- Lua provided by RyzenAPI 
-- Game: Lusitania: The Experience
addappid(1260710)
addappid(1260711, 1, "dff664313812bcbadd69f10ef983bb150613a01c01cf179fba0d2df205e79732")
