-- Lua provided by RyzenAPI
-- Game: AppID 315860

-- MAIN APPLICATION
addappid(315860)
addappid(413330)
addappid(413331)
addappid(413333)
addappid(413334)
addappid(413335)
addappid(413337)
addappid(413338)
addappid(462610)
addappid(462611)
-- Game: addappid(315860)

-- MAIN APP DEPOTS / PACKAGES
addappid(315861, 1, "95a68541ee1107faaaa34ec562ff5ae2086533b587dae6c63427d77fdcd997c0")
addappid(315863, 1, "f1eb54009f11193e7dee0c588136b087ce00c4d806453784206c37af98b8d10f")
addappid(315864, 1, "d989b99b2e07bcc7b3326288702e3f7c15ff48b5f01f341c9c3b48ece37a4af0")
