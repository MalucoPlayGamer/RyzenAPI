-- Lua provided by RyzenAPI
-- Game: DRAGON NINJA BYOKA

-- MAIN APPLICATION
addappid(1858920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858921, 1, "d9881f5551ad81087640394dd906442236f34eb99005d92b523045d03e01d2f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
