-- Lua provided by SkyAPI 
-- Game: OVR Toolkit - Desktop Overlay
addappid(1068820)
addappid(1068821, 1, "b1ac70eb9afc949e0644b8f68791b30974d10d6976185dc44402eef72124e49b")
