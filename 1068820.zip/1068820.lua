-- Lua provided by RyzenAPI
-- Game: OVR Toolkit - Desktop Overlay

-- MAIN APPLICATION
addappid(1068820)
-- Game: addappid(1068820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068821, 1, "b1ac70eb9afc949e0644b8f68791b30974d10d6976185dc44402eef72124e49b")
