-- Lua provided by RyzenAPI
-- Game: 3339470

-- MAIN APPLICATION
addappid(3339470)
-- Game: addappid(3339470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339471, 1, "ca690bbbd0f880336ca78ac6e5fdefbfa8c4d3c06a2de0bc9159f9b4841606ba")
