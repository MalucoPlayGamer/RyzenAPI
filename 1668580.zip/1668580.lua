-- Lua provided by RyzenAPI
-- Game: Valor

-- MAIN APPLICATION
addappid(1668580)
-- Game: addappid(1668580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668581, 1, "72a962381338f8c4bb709bbda31c3e17fd12f941b898ae4f8e5e902ba324ecc8")
