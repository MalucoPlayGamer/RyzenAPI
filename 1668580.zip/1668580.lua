-- Lua provided by RyzenAPI
-- Game: Valor

-- MAIN APPLICATION
addappid(1668580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1668581, 1, "72a962381338f8c4bb709bbda31c3e17fd12f941b898ae4f8e5e902ba324ecc8")

