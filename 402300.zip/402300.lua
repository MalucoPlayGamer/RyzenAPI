-- Lua provided by RyzenAPI
-- Game: Dungeon Manager ZV

-- MAIN APPLICATION
addappid(402300)

-- MAIN APP DEPOTS / PACKAGES
addappid(402301, 1, "3a09cf47fed87b47bb9aed71b054cf61c87307c28136fc14417f49ee32353e06")
