-- Lua provided by RyzenAPI
-- Game: 1500110

-- MAIN APPLICATION
addappid(1500110)
addappid(2374050)
-- Game: addappid(1500110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500111, 1, "3554219f1be3f853dfb8dd35abb3bdccada5c1f1e9e198fd25c5aa51b4eb6e96")
