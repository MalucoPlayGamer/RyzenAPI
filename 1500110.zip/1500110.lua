-- Lua provided by RyzenAPI
-- Game: KNIGHT SLAVE -The Dark Valkyrie of Depravity-

-- MAIN APPLICATION
addappid(1500110)
addappid(2374050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500111, 1, "3554219f1be3f853dfb8dd35abb3bdccada5c1f1e9e198fd25c5aa51b4eb6e96")

