-- Lua provided by RyzenAPI
-- Game: 2394650

-- MAIN APPLICATION
addappid(2394650)
-- Game: addappid(2394650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394651, 1, "025ab4303ab5f8d193676b20d64663eaf6418bfd1ab8be75d3c404cb67c597f1")
