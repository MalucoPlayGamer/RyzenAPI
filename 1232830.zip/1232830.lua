-- Lua provided by SkyAPI 
-- Game: AppID 1232830
addappid(1232830)
addappid(1232831, 1, "c6e4a34970e2cd5da0744b428c611a693cbcbbc099db464f89afb4f1f7d97861")
addappid(1232832, 1, "303a13a8ef86d15c1f530119a8f88d32583e0f335fed88bc20baaa5708791e2c")
