-- Lua provided by RyzenAPI 
-- Game: HUMANITY (Original Soundtrack)
addappid(2383720)
addappid(2383721, 1, "afb407f5e5642870468c28604e129af6bf117913592d353f9441e8725e8ef68c")
addappid(2383722, 1, "71c98b81260ed7ae81cc8a8c6d24c4ba03db5439911ebb9f3aecdf444edcd2bd")
