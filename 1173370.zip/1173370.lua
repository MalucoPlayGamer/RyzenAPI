-- Lua provided by RyzenAPI
-- Game: AppID 1173370

-- MAIN APPLICATION
addappid(1173370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173371, 1, "ba84354ff92499c5f4ff5b9edbe1f5fd7d33885b65ef4efdd728312c83275e61")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1485570)
addappid(3636430)
