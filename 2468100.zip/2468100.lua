-- Lua provided by RyzenAPI
-- Game: Pyrene

-- MAIN APPLICATION
addappid(2468100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2468101, 1, "a21cf0e528c3491a8bd1137b7677c952289e6bae9151840615a2d53e4db3295b")
addappid(2468102, 1, "c9e6d120be1b5a60a440b58d7772a62b89fb0d41ba20cd0eb936e3f24ff03933")

