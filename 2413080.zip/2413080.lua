-- Lua provided by RyzenAPI
-- Game: Project CarnEvil

-- MAIN APPLICATION
addappid(2413080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413081, 1, "3e3375ac0a6162077cbfee79e797e877e87c7a569b424278c70a48ba5bfc0394")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
