-- Lua provided by RyzenAPI
-- Game: addappid(2413080)

-- MAIN APPLICATION
addappid(2413080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413081, 1, "3e3375ac0a6162077cbfee79e797e877e87c7a569b424278c70a48ba5bfc0394")
