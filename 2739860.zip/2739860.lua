-- Lua provided by RyzenAPI
-- Game: addappid(2739860)

-- MAIN APPLICATION
addappid(2739860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739861, 1, "3e93c7ca1ac28594e941c45c2e45c3b95244797ab93f9dd5929e9cc8e399358d")
