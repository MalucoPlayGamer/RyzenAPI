-- Lua provided by RyzenAPI
-- Game: addappid(1511670)

-- MAIN APPLICATION
addappid(1511670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511671, 1, "ac6fc590215db054553829844ddf827be270be4d3c87eb3ded0eb2d8b1078dfe")
