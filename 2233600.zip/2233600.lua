-- Lua provided by RyzenAPI 
-- Game: Brothel Simulator 🍓
addappid(2233600)
addappid(2233601, 1, "868c31d17bb07f0a744e5e2314fcd9bb990f468addab10670e3b649c50776d19")
