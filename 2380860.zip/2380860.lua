-- Lua provided by RyzenAPI
-- Game: Game: AppID 2380860

-- MAIN APPLICATION
addappid(2380860)
-- Game: addappid(2380860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380861, 1, "dc70923d68a568a40e4eb9323a65f5462e5e709c4c8e86ba9f922983b605ae8c")
