-- Lua provided by RyzenAPI
-- Game: Game: Mad Restaurant People

-- MAIN APPLICATION
addappid(871920)
-- Game: addappid(871920)

-- MAIN APP DEPOTS / PACKAGES
addappid(871921, 1, "4ed12f08f0c57ff4912596f94b2f968e9056483fdecb30beaf1b4f3b78617319")
