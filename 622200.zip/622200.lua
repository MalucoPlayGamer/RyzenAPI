-- Lua provided by RyzenAPI
-- Game: Cursery: The Crooked Man and the Crooked Cat Collector's Edition

-- MAIN APPLICATION
addappid(622200)

-- MAIN APP DEPOTS / PACKAGES
addappid(622201,0,"8d34ecf9e390f9f004275c4e027af222f5480ab819efe8be20dd95989dfd6dbc")

