-- Lua provided by RyzenAPI 
-- Game: Last Group Out
addappid(1843730)
addappid(1843731, 1, "edace4e80a96403ed87e2391a6f48c9e68b908913aa40a820be8cdda93d0c3ba")
