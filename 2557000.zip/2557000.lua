-- Lua provided by RyzenAPI
-- Game: Game: Prominence Poker - Original Soundtrack

-- MAIN APPLICATION
addappid(2557000)
-- Game: addappid(2557000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2557001, 1, "8b0cc68944510731d5fe59ee3430d9ac4a1e21968c010571589b9e84fb055d20")
addappid(2557002, 1, "2c46fb72c46f1ad479768f8f10c7a28ae6a6779afde62ba51262bf0b045c1533")
