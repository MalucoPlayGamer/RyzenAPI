-- Lua provided by RyzenAPI
-- Game: Damned Cold

-- MAIN APPLICATION
addappid(543720)

-- MAIN APP DEPOTS / PACKAGES
addappid(543721,0,"396d1cd37051e6abfbcc04e36e7b46cf636db294750bf363e0896ad693a6cb2b")

