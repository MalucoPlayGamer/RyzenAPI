-- Lua provided by RyzenAPI
-- Game: 3D Gravity Rocket

-- MAIN APPLICATION
addappid(870020)
addappid(870630)

-- MAIN APP DEPOTS / PACKAGES
addappid(870021, 1, "bc5f28c0996f49d7673047565dc8ffc90f9a5f678e7f93aff24fecf0d3c10641")