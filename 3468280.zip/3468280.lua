-- Lua provided by RyzenAPI
-- Game: Deathblight Jormungandr

-- MAIN APPLICATION
addappid(3468280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3468281,0,"4d31834e559a488c4e2722efc45520ff719ee9154cb2be6d79ce271657d3d2d6")

