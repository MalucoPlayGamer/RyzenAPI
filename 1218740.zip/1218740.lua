-- Lua provided by RyzenAPI
-- Game: Rakion Chaos Force

-- MAIN APPLICATION
addappid(1218740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218741, 1, "bd1ee7704b8d66be23b6d23ac35eb07a46b5f01de67e0a289d82d0bf053a57ce")
addappid(1218742, 1, "f26ba8f5e7b2c8a21c886146a343542d80fb0036dc2f9faa4e03961aa5ae2100")
