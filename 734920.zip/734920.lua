-- Lua provided by RyzenAPI
-- Game: 734920

-- MAIN APPLICATION
addappid(734920)
-- Game: addappid(734920)

-- MAIN APP DEPOTS / PACKAGES
addappid(734921, 1, "df3d778a1d86c7d6e58177dab5b66afe3a7b1906707ac5a18b80516b79f482c2")
