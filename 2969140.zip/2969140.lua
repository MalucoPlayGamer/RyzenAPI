-- Lua provided by RyzenAPI
-- Game: Checkout: Cashier Simulator

-- MAIN APPLICATION
addappid(2969140)
-- Game: addappid(2969140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969141, 1, "8c82e0c98a812dd8283a451bb086b5f155e44637c10996e7ecdd40c67d0861a2")
