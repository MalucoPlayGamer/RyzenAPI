-- Lua provided by RyzenAPI
-- Game: Fap & Cum 💦

-- MAIN APPLICATION
addappid(2229680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229681, 1, "b323d7056e57d8121cf740ad81155edee669b93e5f1e40b031d5ba8dafeab76f")

