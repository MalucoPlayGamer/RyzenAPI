-- Lua provided by RyzenAPI
-- Game: Jim Power -The Lost Dimension

-- MAIN APPLICATION
addappid(370270)

-- MAIN APP DEPOTS / PACKAGES
addappid(370271, 1, "e94d3d2dab774eb3762de0e5e9d1cd9d2c96e2244803c256b162b07dba63ad49")
addappid(370272, 1, "16e2bbc2b46cd5454ad03080f9df6950a1a8f42a85fd61f466cf42ee7f92445c")
addappid(370273, 1, "ab273bd9271b4876ed44f498238d20820c51bd3eb79249d88d40041d045a550b")
addappid(370274, 1, "0e787deee29bdf97a0d7743d357a97348b4b11768e61f2cb5376052ae4112ef7")
addappid(370275, 1, "74dc078ba09ddd6068819dcf4a3df50cdd28dbd1792a668a16cbf80b49bfd79d")
