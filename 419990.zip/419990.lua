-- Lua provided by RyzenAPI
-- Game: 419990

-- MAIN APPLICATION
addappid(419990)
-- Game: addappid(419990)

-- MAIN APP DEPOTS / PACKAGES
addappid(419991, 1, "1afd13af5b9effc908261d193ebccd54170f350089fdad04295851b8b86a68f3")
