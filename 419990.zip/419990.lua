-- Lua provided by RyzenAPI
-- Game: Ganbare! Super Strikers

-- MAIN APPLICATION
addappid(419990)

-- MAIN APP DEPOTS / PACKAGES
addappid(419991, 1, "1afd13af5b9effc908261d193ebccd54170f350089fdad04295851b8b86a68f3")
