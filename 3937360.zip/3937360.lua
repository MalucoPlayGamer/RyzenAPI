-- Lua provided by RyzenAPI
-- Game: Ocean Keeper Co-op

-- MAIN APPLICATION
addappid(3937360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3937361,0,"2b015480ca1650854e92848ddaa25fe7497dfad7d48b73e77f8df720f5f47ea5")

