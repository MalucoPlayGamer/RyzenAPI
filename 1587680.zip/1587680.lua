-- Lua provided by RyzenAPI
-- Game: Marionette lab

-- MAIN APPLICATION
addappid(1587680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587681, 1, "31315f9f9ac52c3311c56a9fa671868c79cb2debc072234e23d3d998107dab71")

