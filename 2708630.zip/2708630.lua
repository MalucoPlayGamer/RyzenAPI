-- Lua provided by RyzenAPI
-- Game: AppID 2708630

-- MAIN APPLICATION
addappid(2708630)
-- Game: addappid(2708630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708631, 1, "c940b7d8349b3da0fdbe7d3d8fd34b7743ded63b5342978adf0c9d4c35a5ad72")
