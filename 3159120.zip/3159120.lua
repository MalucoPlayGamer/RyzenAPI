-- Lua provided by RyzenAPI
-- Game: Game: Hidden Realm of the Enchantress

-- MAIN APPLICATION
addappid(3159120)
-- Game: addappid(3159120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3159121, 1, "1581732e538977d320e79f328d65922494cb640edfa22161ef3c3e8502d50083")
