-- Lua provided by RyzenAPI
-- Game: Last Resort

-- MAIN APPLICATION
addappid(1491650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491651, 1, "3d05784752707a507eb69c94af98374e72d273bbabec08174f4797294ac813c4")

