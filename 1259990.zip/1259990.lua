-- Lua provided by RyzenAPI
-- Game: addappid(1259990)

-- MAIN APPLICATION
addappid(1259990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259991, 1, "4823422a3cf64bb95d64a350f345657e98f318fcd0aefbde23e29a2f71a555b9")
