-- Lua provided by RyzenAPI
-- Game: 你好！我们还有场恋爱没谈-番外篇

-- MAIN APPLICATION
addappid(4161480)
-- Game: addappid(4161480)

-- MAIN APP DEPOTS / PACKAGES
addappid(4161481, 1, "fba6dbf32706fc4083f18981be1156941884005baae73db59900d20c4510c551")
