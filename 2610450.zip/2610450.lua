-- Lua provided by SkyAPI 
-- Game: AppID 2610450
addappid(2610450)
addappid(2610451, 1, "e20d48c12dd2465386410d67d7f775c6c5fe50cb5c4fef19d133f5f84f404645")
