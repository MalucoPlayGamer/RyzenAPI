-- 1052250's Lua and Manifest Created by Hubcap Manifest
-- Tiger Tank 59 Ⅰ Black Hill Fortress
-- Created: October 01, 2025 at 01:44:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 100

-- MAIN APPLICATION
addappid(1052250) -- Tiger Tank 59 Ⅰ Black Hill Fortress
-- MAIN APP DEPOTS
addappid(1052251, 1, "ffc49de8e53eafa6b22768228dd95bf3b8108a85960bc5884743a21b2782afaa") -- Tiger Tank 59 Ⅰ Black Hill Fortress Content
setManifestid(1052251, "7738733773640955294", 11497365)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1685350) -- Tiger Tank 59  Black Hill Fortress MP001
addappid(1685351) -- Tiger Tank 59  Black Hill Fortress MP002
addappid(1685352) -- Tiger Tank 59  Black Hill Fortress MP003
addappid(1685353) -- Tiger Tank 59  Black Hill Fortress MP004
addappid(1685354) -- Tiger Tank 59  Black Hill Fortress MP005
addappid(1685355) -- Tiger Tank 59  Black Hill Fortress MP006
addappid(1685356) -- Tiger Tank 59  Black Hill Fortress MP007
addappid(1685357) -- Tiger Tank 59  Black Hill Fortress MP008
addappid(1685358) -- Tiger Tank 59  Black Hill Fortress MP009
addappid(1685359) -- Tiger Tank 59  Black Hill Fortress MP010
addappid(1685360) -- Tiger Tank 59  Black Hill Fortress MP011
addappid(1685361) -- Tiger Tank 59  Black Hill Fortress MP012
addappid(1685362) -- Tiger Tank 59  Black Hill Fortress MP013
addappid(1685363) -- Tiger Tank 59  Black Hill Fortress MP014
addappid(1685364) -- Tiger Tank 59  Black Hill Fortress MP015
addappid(1685365) -- Tiger Tank 59  Black Hill Fortress MP016
addappid(1685366) -- Tiger Tank 59  Black Hill Fortress MP017
addappid(1685367) -- Tiger Tank 59  Black Hill Fortress MP018
addappid(1685368) -- Tiger Tank 59  Black Hill Fortress MP019
addappid(1685369) -- Tiger Tank 59  Black Hill Fortress MP020
addappid(1685370) -- Tiger Tank 59  Black Hill Fortress MP021
addappid(1685371) -- Tiger Tank 59  Black Hill Fortress MP022
addappid(1685372) -- Tiger Tank 59  Black Hill Fortress MP023
addappid(1685373) -- Tiger Tank 59  Black Hill Fortress MP024
addappid(1685374) -- Tiger Tank 59  Black Hill Fortress MP025
addappid(1685375) -- Tiger Tank 59  Black Hill Fortress MP026
addappid(1685376) -- Tiger Tank 59  Black Hill Fortress MP027
addappid(1685377) -- Tiger Tank 59  Black Hill Fortress MP028
addappid(1685378) -- Tiger Tank 59  Black Hill Fortress MP029
addappid(1685379) -- Tiger Tank 59  Black Hill Fortress MP030
addappid(1685380) -- Tiger Tank 59  Black Hill Fortress MP031
addappid(1685381) -- Tiger Tank 59  Black Hill Fortress MP032
addappid(1685382) -- Tiger Tank 59  Black Hill Fortress MP033
addappid(1685383) -- Tiger Tank 59  Black Hill Fortress MP034
addappid(1685384) -- Tiger Tank 59  Black Hill Fortress MP035
addappid(1685385) -- Tiger Tank 59  Black Hill Fortress MP036
addappid(1685386) -- Tiger Tank 59  Black Hill Fortress MP037
addappid(1685387) -- Tiger Tank 59  Black Hill Fortress MP038
addappid(1685388) -- Tiger Tank 59  Black Hill Fortress MP039
addappid(1685389) -- Tiger Tank 59  Black Hill Fortress MP040
addappid(1685390) -- Tiger Tank 59  Black Hill Fortress MP041
addappid(1685391) -- Tiger Tank 59  Black Hill Fortress MP042
addappid(1685392) -- Tiger Tank 59  Black Hill Fortress MP043
addappid(1685393) -- Tiger Tank 59  Black Hill Fortress MP044
addappid(1685394) -- Tiger Tank 59  Black Hill Fortress MP045
addappid(1685395) -- Tiger Tank 59  Black Hill Fortress MP046
addappid(1685396) -- Tiger Tank 59  Black Hill Fortress MP047
addappid(1685397) -- Tiger Tank 59  Black Hill Fortress MP048
addappid(1685398) -- Tiger Tank 59  Black Hill Fortress MP049
addappid(1685399) -- Tiger Tank 59  Black Hill Fortress MP050
addappid(1685400) -- Tiger Tank 59  Black Hill Fortress MP051
addappid(1685401) -- Tiger Tank 59  Black Hill Fortress MP052
addappid(1685402) -- Tiger Tank 59  Black Hill Fortress MP053
addappid(1685403) -- Tiger Tank 59  Black Hill Fortress MP054
addappid(1685404) -- Tiger Tank 59  Black Hill Fortress MP055
addappid(1685405) -- Tiger Tank 59  Black Hill Fortress MP056
addappid(1685406) -- Tiger Tank 59  Black Hill Fortress MP057
addappid(1685407) -- Tiger Tank 59  Black Hill Fortress MP058
addappid(1685408) -- Tiger Tank 59  Black Hill Fortress MP059
addappid(1685409) -- Tiger Tank 59  Black Hill Fortress MP060
addappid(1685410) -- Tiger Tank 59  Black Hill Fortress MP061
addappid(1685411) -- Tiger Tank 59  Black Hill Fortress MP062
addappid(1685412) -- Tiger Tank 59  Black Hill Fortress MP063
addappid(1685413) -- Tiger Tank 59  Black Hill Fortress MP064
addappid(1685414) -- Tiger Tank 59  Black Hill Fortress MP065
addappid(1685415) -- Tiger Tank 59  Black Hill Fortress MP066
addappid(1685416) -- Tiger Tank 59  Black Hill Fortress MP067
addappid(1685417) -- Tiger Tank 59  Black Hill Fortress MP068
addappid(1685418) -- Tiger Tank 59  Black Hill Fortress MP069
addappid(1685419) -- Tiger Tank 59  Black Hill Fortress MP070
addappid(1685420) -- Tiger Tank 59  Black Hill Fortress MP071
addappid(1685421) -- Tiger Tank 59  Black Hill Fortress MP072
addappid(1685422) -- Tiger Tank 59  Black Hill Fortress MP073
addappid(1685423) -- Tiger Tank 59  Black Hill Fortress MP074
addappid(1685424) -- Tiger Tank 59  Black Hill Fortress MP075
addappid(1685425) -- Tiger Tank 59  Black Hill Fortress MP076
addappid(1685426) -- Tiger Tank 59  Black Hill Fortress MP077
addappid(1685427) -- Tiger Tank 59  Black Hill Fortress MP078
addappid(1685428) -- Tiger Tank 59  Black Hill Fortress MP079
addappid(1685429) -- Tiger Tank 59  Black Hill Fortress MP080
addappid(1685430) -- Tiger Tank 59  Black Hill Fortress MP081
addappid(1685431) -- Tiger Tank 59  Black Hill Fortress MP082
addappid(1685432) -- Tiger Tank 59  Black Hill Fortress MP083
addappid(1685433) -- Tiger Tank 59  Black Hill Fortress MP084
addappid(1685434) -- Tiger Tank 59  Black Hill Fortress MP085
addappid(1685435) -- Tiger Tank 59  Black Hill Fortress MP086
addappid(1685436) -- Tiger Tank 59  Black Hill Fortress MP087
addappid(1685437) -- Tiger Tank 59  Black Hill Fortress MP088
addappid(1685438) -- Tiger Tank 59  Black Hill Fortress MP089
addappid(1685439) -- Tiger Tank 59  Black Hill Fortress MP090
addappid(1685440) -- Tiger Tank 59  Black Hill Fortress MP091
addappid(1685441) -- Tiger Tank 59  Black Hill Fortress MP092
addappid(1685442) -- Tiger Tank 59  Black Hill Fortress MP093
addappid(1685443) -- Tiger Tank 59  Black Hill Fortress MP094
addappid(1685444) -- Tiger Tank 59  Black Hill Fortress MP095
addappid(1685445) -- Tiger Tank 59  Black Hill Fortress MP096
addappid(1685446) -- Tiger Tank 59  Black Hill Fortress MP097
addappid(1685447) -- Tiger Tank 59  Black Hill Fortress MP098
addappid(1685448) -- Tiger Tank 59  Black Hill Fortress MP099
addappid(1685449) -- Tiger Tank 59  Black Hill Fortress MP100