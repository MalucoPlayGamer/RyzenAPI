-- Lua provided by RyzenAPI
-- Game: Game: Tiger Tank 59 Ⅰ Black Hill Fortress

-- MAIN APPLICATION
addappid(1052250)
-- Game: addappid(1052250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052251, 1, "ffc49de8e53eafa6b22768228dd95bf3b8108a85960bc5884743a21b2782afaa")
