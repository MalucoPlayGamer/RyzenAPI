-- Lua provided by RyzenAPI
-- Game: Game: AppID 2338510

-- MAIN APPLICATION
addappid(2338510)
-- Game: addappid(2338510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338511, 1, "836b610c7c48e2864f6b250c86d82e081e4896cf4c01508252c9ea65e5f6139f")
