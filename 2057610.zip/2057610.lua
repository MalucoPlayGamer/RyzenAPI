-- Lua provided by RyzenAPI
-- Game: Game: Soul Link

-- MAIN APPLICATION
addappid(2057610)
-- Game: addappid(2057610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057611, 1, "47b32181757940a15835021be5ace10c115384af35253da662d95b1db3e9ad33")
