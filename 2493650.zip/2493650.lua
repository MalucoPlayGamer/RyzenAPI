-- Lua provided by RyzenAPI
-- Game: Game: AppID 2493650

-- MAIN APPLICATION
addappid(2493650)
-- Game: addappid(2493650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493651, 1, "e5d384dc41563b99e67b989952275d0bd5e0a41a8eb51670e39625d44a390eb4")
