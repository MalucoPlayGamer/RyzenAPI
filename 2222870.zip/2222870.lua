-- Lua provided by RyzenAPI
-- Game: 2222870

-- MAIN APPLICATION
addappid(2222870)
-- Game: addappid(2222870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222871, 1, "e179edecaf6131e23ad0ef21f07d72a63bbd573cda6c25c64de45a278e5b7490")
