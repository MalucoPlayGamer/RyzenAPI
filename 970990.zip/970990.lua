-- Lua provided by RyzenAPI
-- Game: Theatre of Doom Soundtrack

-- MAIN APPLICATION
addappid(970990)

-- MAIN APP DEPOTS / PACKAGES
addappid(970990,0,"c92d910ce7ff470babfb9177513600045fe86aec157932cfc59e5127c6d18190")

