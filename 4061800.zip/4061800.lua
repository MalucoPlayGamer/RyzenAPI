-- Lua provided by RyzenAPI
-- Game: A Game About Penguins

-- MAIN APPLICATION
addappid(4061800) -- A Game About Penguins

-- MAIN APP DEPOTS / PACKAGES
addappid(4061801, 1, "34023c588fddc04a0ceb9d77e133f549d93ac60ced89f277b6413e354eff80e4") -- Depot 4061801

