-- 4061800's Lua and Manifest Created by Hubcap Manifest
-- A Game About Penguins
-- Created: August 10, 2026 at 14:57:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4061800) -- A Game About Penguins
-- MAIN APP DEPOTS
addappid(4061801, 1, "34023c588fddc04a0ceb9d77e133f549d93ac60ced89f277b6413e354eff80e4") -- Depot 4061801
setManifestid(4061801, "8166904040237243606", 1935584002)