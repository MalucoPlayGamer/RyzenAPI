-- Lua provided by RyzenAPI
-- Game: Sim Companies

-- MAIN APPLICATION
addappid(2253720)
-- Game: addappid(2253720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253721, 1, "e051b304c353c75067178cf35a49b6fcbedbecebb9cb751b29b61eaa0e8e705b")
addappid(2253722, 1, "21aab32cf94eade02997673cb9a0d8ad2df6ec661dd775061976aa1630abd4af")
addappid(2253723, 1, "40e565499c2c50b615eb1894c0200d4361a6b24c9c8e1bfb1dd01bd7cf4222b7")
