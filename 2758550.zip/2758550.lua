-- Lua provided by RyzenAPI
-- Game: Training Elves

-- MAIN APPLICATION
addappid(2758550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758551, 1, "ac068ef5061e111cb2a759abe1cbc7cfe3ea6e13bab689bd9c2fa4600730e444")
