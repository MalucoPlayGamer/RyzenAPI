-- Lua provided by RyzenAPI
-- Game: Magi's Dream

-- MAIN APPLICATION
addappid(2462610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462611, 1, "f6ddef7e8b62416bbbc33ec49c497a2ff9a03b97099f9ffbffecfa19cd9daab6")

