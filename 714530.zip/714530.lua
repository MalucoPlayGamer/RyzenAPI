-- Lua provided by RyzenAPI
-- Game: GRIM - Mystery of Wasules

-- MAIN APPLICATION
addappid(714530)

-- MAIN APP DEPOTS / PACKAGES
addappid(714531,0,"ec995c2d4e4cfff7359cf122ab5ea6c2387a2b8afd590d21a441d2006f583a29")

