-- Lua provided by RyzenAPI
-- Game: addappid(1940180)

-- MAIN APPLICATION
addappid(1940180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940181, 1, "e9da501ecfe0eb3e4f9ddb88665ec802d6a251b9a9e21198814e20c8dc8f7ba6")
