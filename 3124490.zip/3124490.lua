-- Lua provided by RyzenAPI
-- Game: Operation: Polygon Storm - Deliberate Force Pack DLC

-- MAIN APPLICATION
addappid(3124490)
addappid(3124491)
-- Game: addappid(3124490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124490,0,"fadf8d40948c5e83ed757ed693f98ae4904f501495cbd7ca6caa558837cc2b4e")
