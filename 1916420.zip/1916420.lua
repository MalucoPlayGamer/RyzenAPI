-- Lua provided by RyzenAPI
-- Game: Game: Secrets of the Temple

-- MAIN APPLICATION
addappid(1916420)
-- Game: addappid(1916420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916421, 1, "6e4ca2ad1d6413ab71d2f8acb0d6f8c02f0199036a18c74e3a91d6d727e8ebbb")
