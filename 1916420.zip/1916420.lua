-- Lua provided by RyzenAPI
-- Game: Secrets of the Temple

-- MAIN APPLICATION
addappid(1916420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1916421, 1, "6e4ca2ad1d6413ab71d2f8acb0d6f8c02f0199036a18c74e3a91d6d727e8ebbb")

