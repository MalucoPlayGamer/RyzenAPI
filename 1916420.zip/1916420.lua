-- Lua provided by RyzenAPI 
-- Game: Secrets of the Temple
addappid(1916420)
addappid(1916421, 1, "6e4ca2ad1d6413ab71d2f8acb0d6f8c02f0199036a18c74e3a91d6d727e8ebbb")
