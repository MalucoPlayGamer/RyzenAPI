-- Lua provided by RyzenAPI
-- Game: Summer Days

-- MAIN APPLICATION
addappid(1160620)
addappid(1160650)
addappid(1160651)
addappid(1160653)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160621, 1, "2a1b60a8ddf3337000286a40a889937839645886f4823adde77465b79dd05257")

