-- Lua provided by RyzenAPI
-- Game: 2394140

-- MAIN APPLICATION
addappid(2394140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394142,0,"43dfaa90442f63f12bbed5f5226d2f8b988b89be91bdcee54da45f34564eeba0")

