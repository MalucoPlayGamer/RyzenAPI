-- Lua provided by RyzenAPI
-- Game: 4115180

-- MAIN APPLICATION
addappid(4115180)
-- Game: addappid(4115180)

-- MAIN APP DEPOTS / PACKAGES
addappid(4115181, 1, "0ed021d5740889497a6c34f603ffbbb663ab786ca26cee2df4a0cfb23ba90a15")
