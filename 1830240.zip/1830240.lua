-- Lua provided by RyzenAPI
-- Game: 1830240

-- MAIN APPLICATION
addappid(1830240)
-- Game: addappid(1830240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830241, 1, "a5bec913f294748915e43b5a497c758a5754a106f788de57762d9c6af6a3e0d9")
