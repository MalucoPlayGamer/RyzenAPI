-- Lua provided by RyzenAPI
-- Game: Looterkings

-- MAIN APPLICATION
addappid(397310)
addappid(512480)
addappid(512510)

-- MAIN APP DEPOTS / PACKAGES
addappid(397311, 1, "3aca5c23c3f4114c050e1441abd7d971b3039d080fa6b77ec999ae4e010a9163")

