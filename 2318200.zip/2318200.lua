-- Lua provided by RyzenAPI
-- Game: The Safe Place Demo

-- MAIN APPLICATION
addappid(2318200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318201, 1, "e0e3315191d62b94cbbc2c096885b67759b1b99e0bd7071a6766915d4b5e13b0")
