-- Lua provided by RyzenAPI
-- Game: addappid(2354520)

-- MAIN APPLICATION
addappid(2354520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354521, 1, "da817691c74cb24c366ce1e0073daf8fa7956f3011437aeb544beef8b4d12a5f")
