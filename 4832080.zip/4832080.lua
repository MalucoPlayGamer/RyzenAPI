-- 4832080's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Sigrid is streaming
-- Created: July 19, 2026 at 14:02:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4832080) -- Hentai Clicker: Sigrid is streaming
-- MAIN APP DEPOTS
addappid(4832081, 1, "0aa88b5b907079801ecfc667b5f23874ce73dd02c57b9475046e3caeceb5043f") -- Depot 4832081
setManifestid(4832081, "8410441735387990508", 156367679)