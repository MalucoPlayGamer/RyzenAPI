-- Lua provided by SkyAPI 
-- Game: AppID 429380
addappid(429380)
addappid(429381, 1, "f6a40034b9b203ef99ddbb5613917456d7bda6ab7e79e90460b92fc09e19369b")
