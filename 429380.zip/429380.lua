-- Lua provided by RyzenAPI
-- Game: Space Mechanic Simulator

-- MAIN APPLICATION
addappid(429380)

-- MAIN APP DEPOTS / PACKAGES
addappid(429381, 1, "f6a40034b9b203ef99ddbb5613917456d7bda6ab7e79e90460b92fc09e19369b")

