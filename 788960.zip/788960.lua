-- Lua provided by RyzenAPI
-- Game: addappid(788960)

-- MAIN APPLICATION
addappid(788960)

-- MAIN APP DEPOTS / PACKAGES
addappid(788961, 1, "2dfa97a1478794b0ef44209bd4b27c61aad351c2bd33ae48309a9160277d7102")
