-- Lua provided by RyzenAPI
-- Game: 561260

-- MAIN APPLICATION
addappid(561260)
addappid(912780)
-- Game: addappid(561260)

-- MAIN APP DEPOTS / PACKAGES
addappid(561261, 1, "a1239a6deedfd3f1b50fe7a0155a10b2374251312c5fc8b4db0ac9dd37af2068")
