-- Lua provided by RyzenAPI
-- Game: Game: AppID 887170

-- MAIN APPLICATION
addappid(887170)
-- Game: addappid(887170)

-- MAIN APP DEPOTS / PACKAGES
addappid(887171, 1, "114613e3f4ae04a4bf2a31a6c10636261752f6f833a5fd87fa9db466e7243fce")
