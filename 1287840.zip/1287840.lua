-- Lua provided by RyzenAPI
-- Game: Disciples: Liberation

-- MAIN APPLICATION
addappid(1287840)
-- Game: addappid(1287840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1287841, 1, "47e108643d118f40545405806cea60cb9f70469ed7eaae637cd42dd5bc5dc38b")
addappid(1287842, 1, "2136a9efd8bd367758a7fc571975cf588bac72be5bcb6b2e9f37af93f573819a")
addappid(1287843, 1, "0035d9c5e2649ad2243cfe3187ac2e372bad78a555e84dca7b609430eb428c51")
addappid(1287844, 1, "84c3488c09330dca574f88a944db95a5d2087b552fed5bfb01a110a2f2e5ccec")
addappid(1287848, 1, "2f27e12b98db2eb6e5c7f6bed586d8f839e91992837eb0cdd18814bcb31e651e")
addappid(1652430, 0, "aea2082bba24762caa9091319b6b49fbe9e9befd38c41ff8385aaf7e4f8e1f34")
