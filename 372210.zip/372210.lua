-- Lua provided by RyzenAPI
-- Game: Spooky Cats

-- MAIN APPLICATION
addappid(372210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(372211, 1, "fb41e356ba292b54ac054fc25afe75eeb166bbd53262d08b84eddbf97b6ed9ab")
addappid(372212, 1, "8016a0acb66fc965daeb37688a6f3ce5ecd7e506192cbbd85f6d761473cef620")

