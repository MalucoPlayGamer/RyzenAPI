-- Lua provided by RyzenAPI 
-- Game: Spooky Cats
addappid(372210)
addappid(372211, 1, "fb41e356ba292b54ac054fc25afe75eeb166bbd53262d08b84eddbf97b6ed9ab")
addappid(372212, 1, "8016a0acb66fc965daeb37688a6f3ce5ecd7e506192cbbd85f6d761473cef620")
