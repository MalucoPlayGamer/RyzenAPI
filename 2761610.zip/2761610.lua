-- Lua provided by RyzenAPI
-- Game: Game: Creator of Another World

-- MAIN APPLICATION
addappid(2761610)
-- Game: addappid(2761610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761611, 1, "fa02e7f48e17c0c7ac9349565d901e9cb9ce46db13c7d004f378e6f86552497d")
