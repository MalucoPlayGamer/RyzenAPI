-- 896250's Lua and Manifest Created by Hubcap Manifest
-- Liquidation
-- Created: August 04, 2026 at 16:54:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(896250) -- Liquidation
-- MAIN APP DEPOTS
addappid(896251, 1, "8c9b0b453f8389cf7d9dfd44b47a72fa2e77230c4cd094019c359fe12c826b02") -- Depot 896251
setManifestid(896251, "8751367168682861701", 7266197490)