-- Lua provided by RyzenAPI
-- Game: Liquidation

-- MAIN APPLICATION
addappid(896250) -- Liquidation

-- MAIN APP DEPOTS / PACKAGES
addappid(896251, 1, "8c9b0b453f8389cf7d9dfd44b47a72fa2e77230c4cd094019c359fe12c826b02") -- Depot 896251

