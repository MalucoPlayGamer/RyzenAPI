-- Lua provided by RyzenAPI
-- Game: Lucid

-- MAIN APPLICATION
addappid(61100)
-- Game: addappid(61100)

-- MAIN APP DEPOTS / PACKAGES
addappid(61101, 1, "e5c0b12005c40d03d45f4d7bd35c5b5c420b8423885d18b356379cf75fd20797")
