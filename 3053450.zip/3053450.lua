-- Lua provided by RyzenAPI
-- Game: BUSTAFELLOWS Demo

-- MAIN APPLICATION
addappid(3053450)
-- Game: addappid(3053450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3053451, 1, "f24c0ad53f7d052bf4540aebdc6f89c6d9f6ad5804987acf4bd78b328eae6b12")
