-- Lua provided by RyzenAPI
-- Game: 1418790

-- MAIN APPLICATION
addappid(1418790)
-- Game: addappid(1418790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418791, 1, "21941a1a88e6021943cec163fbabaaf0d87efcfb80fb79cd7d8dffe9a8cc3231")
