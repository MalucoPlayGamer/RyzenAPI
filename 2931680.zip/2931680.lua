-- Lua provided by RyzenAPI
-- Game: addappid(2931680)

-- MAIN APPLICATION
addappid(2931680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2931681, 1, "e8a45f9f44ff07644980c1eb3c8c6f5fd82e8e53a2baa0063d476cf9e0170921")
