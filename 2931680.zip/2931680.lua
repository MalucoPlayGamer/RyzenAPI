-- Lua provided by RyzenAPI
-- Game: Venatrix

-- MAIN APPLICATION
addappid(2931680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2931681, 1, "e8a45f9f44ff07644980c1eb3c8c6f5fd82e8e53a2baa0063d476cf9e0170921")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
