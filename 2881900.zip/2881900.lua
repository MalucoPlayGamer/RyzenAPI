-- Lua provided by RyzenAPI
-- Game: Cosmo Cats

-- MAIN APPLICATION
addappid(2881900)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2882010)
addappid(2882020)
