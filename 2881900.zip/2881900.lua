-- Lua provided by RyzenAPI
-- Game: Cosmo Cats

-- MAIN APPLICATION
addappid(2881900)
addappid(2882010)
addappid(2882020)

