-- Lua provided by RyzenAPI
-- Game: Cosmo Cats

-- MAIN APPLICATION
addappid(2881900)

