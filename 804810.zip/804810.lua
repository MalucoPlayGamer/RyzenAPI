-- Lua provided by RyzenAPI
-- Game: Robocraft Royale

-- MAIN APPLICATION
addappid(804810)

-- MAIN APP DEPOTS / PACKAGES
addappid(804811, 1, "9476f2612188749f9c3fe3d5055c597e000ec200652fe9912df0cfdad8d15cc2")

