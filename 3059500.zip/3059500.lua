-- Lua provided by RyzenAPI
-- Game: Portrait of a Torn

-- MAIN APPLICATION
addappid(3059500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3059501, 1, "f659102ff0a611d90dbf8a9e4b5137f42e5e9e5ef225ff01b779917632853033")

