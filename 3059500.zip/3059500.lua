-- Lua provided by RyzenAPI 
-- Game: Portrait of a Torn
addappid(3059500)
addappid(3059501, 1, "f659102ff0a611d90dbf8a9e4b5137f42e5e9e5ef225ff01b779917632853033")
