-- Lua provided by RyzenAPI
-- Game: 长征1934-1936

-- MAIN APPLICATION
addappid(2550330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550331, 1, "1b3599fa3dd8b90cf00a37daced1385555b744fde2b82b1cb5accd090931a131")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
