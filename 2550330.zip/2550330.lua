-- Lua provided by RyzenAPI
-- Game: addappid(2550330)

-- MAIN APPLICATION
addappid(2550330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2550331, 1, "1b3599fa3dd8b90cf00a37daced1385555b744fde2b82b1cb5accd090931a131")
