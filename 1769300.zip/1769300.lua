-- Lua provided by RyzenAPI
-- Game: Countess in Crimson Demo

-- MAIN APPLICATION
addappid(1769300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769301, 1, "14ff090014ea515b307c2ce75cafd0305b91015a80bfa3750c6e8c22ed3b2f5c")

