-- Lua provided by SkyAPI 
-- Game: Stardust Vanguards
addappid(341530)
addappid(341531, 1, "fef5e9aa481c8c066b1c2eeada9f31168b5a6b3e2d4a805b9c0d04779c403662")
addappid(341532, 1, "38f30f36c6c5d87ef28f433ff6e28373ee152f55c975269f0d78370a2ad04f60")
