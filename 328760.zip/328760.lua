-- Lua provided by RyzenAPI
-- Game: SanctuaryRPG: Black Edition

-- MAIN APPLICATION
addappid(328760)
addappid(683610)

-- MAIN APP DEPOTS / PACKAGES
addappid(328764,0,"654e8a884653fdf86b51832b4598f0cb167c4e967fe9c2e4f3d113c2331eff2f")
addappid(328767,0,"1ae0feb29d28cc277d9fef9d7fe586ec1ee71413504b71277388564becc556a5")
addappid(383130,0,"7ff45941b657c50565b8428b797910999ec3cf03e68c5b4b18cc366a3a5945cd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(338770)
