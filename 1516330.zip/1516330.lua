-- Lua provided by RyzenAPI
-- Game: Acolyte

-- MAIN APPLICATION
addappid(1516330)
-- Game: addappid(1516330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516331, 1, "9fcc96985a88cd444511c67a254eb93caf2d5180347037ab15e322e257404159")
