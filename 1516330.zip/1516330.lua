-- Lua provided by RyzenAPI 
-- Game: Acolyte
addappid(1516330)
addappid(1516331, 1, "9fcc96985a88cd444511c67a254eb93caf2d5180347037ab15e322e257404159")
