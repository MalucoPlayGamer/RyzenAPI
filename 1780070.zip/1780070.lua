-- Lua provided by RyzenAPI
-- Game: Seeds of Calamity

-- MAIN APPLICATION
addappid(1780070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780072,0,"9979a9bd7ff7246f4e189b93072b201d9d04338d7549066071073edbb2dc44c3")
