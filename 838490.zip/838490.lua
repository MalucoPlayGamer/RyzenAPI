-- Lua provided by SkyAPI 
-- Game: Theorem
addappid(838490)
addappid(838491, 1, "99d5a8aa344db5729b600e12b2c9068b5898a307b81884a8c02916c6ff976e41")
