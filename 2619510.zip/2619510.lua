-- Lua provided by RyzenAPI
-- Game: Fantasy Amusement Park II

-- MAIN APPLICATION
addappid(2619510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619511, 1, "6475c7736ef57987e791be66b8bd9b4f0fbe5e5a2d4eea12785d1fc683903784")
addappid(2619512, 1, "a3e93dc656c92abbf139d8d677465692c1a539bf1ae44bca593515284bdd137c")
