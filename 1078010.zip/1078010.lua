-- Lua provided by SkyAPI 
-- Game: AppID 1078010
addappid(1078010)
addappid(1078011, 1, "fd054107bbce8cf975f9c2389162a4f640156890161cf01e6e7d978e041a413d")
