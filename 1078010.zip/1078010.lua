-- Lua provided by RyzenAPI
-- Game: Game: AppID 1078010

-- MAIN APPLICATION
addappid(1078010)
-- Game: addappid(1078010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078011, 1, "fd054107bbce8cf975f9c2389162a4f640156890161cf01e6e7d978e041a413d")
