-- Lua provided by RyzenAPI 
-- Game: Contractors
addappid(963930)
addappid(963931, 1, "56ed9d9993a9933e6d73d826229cedacfec70f8d02ae1989205a2781b710d774")
