-- Lua provided by RyzenAPI
-- Game: Last Days Of Tascaria

-- MAIN APPLICATION
addappid(577470)

-- MAIN APP DEPOTS / PACKAGES
addappid(577471,0,"ef577f46c9869bd375aa7a2d45084efb1b7bfa50ca2a70a3aaa2f05d308efcb0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
