-- Lua provided by RyzenAPI
-- Game: Last Days Of Tascaria

-- MAIN APPLICATION
addappid(577470)

-- MAIN APP DEPOTS / PACKAGES
addappid(577471,0,"ef577f46c9869bd375aa7a2d45084efb1b7bfa50ca2a70a3aaa2f05d308efcb0")

