-- Lua provided by RyzenAPI
-- Game: Tales of Terrarum

-- MAIN APPLICATION
addappid(3864100)
