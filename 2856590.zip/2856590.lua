-- Lua provided by RyzenAPI 
-- Game: AppID 2856590
addappid(2856590)
addappid(2856591, 1, "70234292dcb4da1e823d52e0ac750e7524a024bda6f6d0979340b7f4b3b4a6cd")
addappid(2856592, 1, "88d4629e93ca9af5be957f57ef1613a816e14957b8bac067073351735f7d4b5c")
