-- 2825860's Lua and Manifest Created by Hubcap Manifest
-- The Sinking City 2
-- Created: August 16, 2026 at 12:09:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2825860) -- The Sinking City 2
-- MAIN APP DEPOTS
addappid(2825861, 1, "f02c681f5c694511752aaec61e14bd203f901b3f2d7b30ac2bda2318d9d2b699") -- Depot 2825861
setManifestid(2825861, "6795930677185897916", 52040903624)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)