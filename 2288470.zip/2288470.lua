-- Lua provided by RyzenAPI
-- Game: Aethermancer

-- MAIN APPLICATION
addappid(2288470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288471, 1, "a6f02b8c9aec331ef154cbc269be48029dc44f5682779fbf4e176152d73ac1e2")

