-- Lua provided by RyzenAPI 
-- Game: The Initial
addappid(665090)
addappid(665091, 1, "199b59f0cda2a178bbb7ddf4374c42a62a0278f3a6e4d711208c34aadca70ad1")
addappid(665092, 1, "40db356f356d5daea3821e5537997e7de0addd11cb203b05f1266219e59e472a")
addappid(671950)
