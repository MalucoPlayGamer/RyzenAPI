-- Lua provided by RyzenAPI
-- Game: Game: FPV Air Tracks

-- MAIN APPLICATION
addappid(461680)
-- Game: addappid(461680)

-- MAIN APP DEPOTS / PACKAGES
addappid(461681, 1, "552215d9193ce6201df5c70dd07f10943d54a86df39781b8c4463a747b7027d3")
