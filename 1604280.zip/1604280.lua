-- Lua provided by RyzenAPI
-- Game: STHELL

-- MAIN APPLICATION
addappid(1604280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1604281, 1, "8d6956d46d0da9138ffcdd65bae685548fd07818f1167e43d661e17a4aeea9d0")

