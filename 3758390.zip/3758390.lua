-- Lua provided by RyzenAPI
-- Game: addappid(3758390)

-- MAIN APPLICATION
addappid(3758390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3758390,0,"27fb24560abcdbfc1a4796dc2e373a0c1e5e391202b8c0722a4cd62ddc8ec61a")
addappid(3758393,0,"23b1f28f0fe080f4b2e9f0b309fa69acb194e234db9e31609e4bc80b5bcb14ab")
