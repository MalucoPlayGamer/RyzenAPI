-- Lua provided by RyzenAPI
-- Game: Minimalism

-- MAIN APPLICATION
addappid(585690)

-- MAIN APP DEPOTS / PACKAGES
addappid(585691, 1, "3ce41a02b048c40521bbac8e5dbb8adfa08989fa108240512204a3f5d1748d56")
