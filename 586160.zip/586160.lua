-- Lua provided by SkyAPI 
-- Game: Dash Fleet
addappid(586160)
addappid(586161, 1, "feb08c8de6247e4dd2d4dc82830c2d32075cfc238237b6735313dde3c667b893")
addappid(586162, 1, "0c5ccef47492e68d3d5db6cd7469832ac2dda78724265fa178b3a54bed060f66")
addappid(586163, 1, "30fed9a4ff839f3a974a01f38fb3d2c13d8b5d4a9d0ea9e2fbe7a41796b867ef")
