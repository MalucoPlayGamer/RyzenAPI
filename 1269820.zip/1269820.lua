-- Lua provided by RyzenAPI
-- Game: Kozue's Strange Journey

-- MAIN APPLICATION
addappid(1269820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269821, 1, "1c517d244ae45f3cd35b6548006e6412bc38c04f898d48fc6d1752f3cffb5fa0")
addappid(1269822, 1, "2a46d6fd38db1524ab90cf8f355ed1aeef6026fb9a18187a505021ad01f48913")
addappid(1269823, 1, "80eed594ff5afe17b6e42848e26737bd80c7699fb5aeb81fc61cc6cb10c07c6b")