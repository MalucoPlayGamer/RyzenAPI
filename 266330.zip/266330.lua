-- Lua provided by RyzenAPI
-- Game: Ethan: Meteor Hunter

-- MAIN APPLICATION
addappid(266330)
addappid(273370)

-- MAIN APP DEPOTS / PACKAGES
addappid(266331, 1, "62ea97377f00544ac575a358d54cfaae93ca979555b1b0332d7f0c59bc367107")
