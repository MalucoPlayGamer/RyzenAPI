-- Lua provided by RyzenAPI
-- Game: Ethan: Meteor Hunter

-- MAIN APPLICATION
addappid(266330)
addappid(273370)

-- MAIN APP DEPOTS / PACKAGES
addappid(266331, 1, "62ea97377f00544ac575a358d54cfaae93ca979555b1b0332d7f0c59bc367107")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
