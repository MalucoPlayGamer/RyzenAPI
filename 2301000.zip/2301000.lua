-- Lua provided by RyzenAPI
-- Game: Where Is Sarah?

-- MAIN APPLICATION
addappid(2301000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301001, 1, "65182d4510bf090360574ce723e9dd29e3a6d99c4963b589b06db15a366119cd")
