-- Lua provided by RyzenAPI
-- Game: addappid(1976790)

-- MAIN APPLICATION
addappid(1976790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976791, 1, "0b88c0658d25138a56bb42a6ff24966b9cec8d3375a812685b7aabc136aa9659")
