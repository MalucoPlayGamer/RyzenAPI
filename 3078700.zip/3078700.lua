-- Lua provided by SkyAPI 
-- Game: AppID 3078700
addappid(3078700)
addappid(3078701, 1, "5e3fde0a234cb0db1634394e0c5f667321304e2f1c5739bf49f43c60101812d7")
