-- Lua provided by RyzenAPI
-- Game: Game: AppID 3078700

-- MAIN APPLICATION
addappid(3078700)
-- Game: addappid(3078700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078701, 1, "5e3fde0a234cb0db1634394e0c5f667321304e2f1c5739bf49f43c60101812d7")
