-- Lua provided by RyzenAPI
-- Game: Rising World

-- MAIN APPLICATION
addappid(324080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(324081, 1, "15ddb75872372f5f287317d991d16f6c3287a378ab860c177b5c8c9d1b242207")
addappid(324086, 1, "e304084c0fe5b6a2da873f35b5d4eda8c27fd67906ac94cb78ae1dfc5ec1a8b6")
addappid(324087, 1, "f2a385e511df8d915cfca6d0d2af4ac20b21404a087bb4efc91ad5679afead78")

