-- Lua provided by RyzenAPI
-- Game: addappid(19500)

-- MAIN APPLICATION
addappid(19500)

-- MAIN APP DEPOTS / PACKAGES
addappid(19502,0,"239b4fa2e6ce27a2ee8e9b6a336a5bd1801cb45e45aff6e6f618f3bab9e87fd4")
