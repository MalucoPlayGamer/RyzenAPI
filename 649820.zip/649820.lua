-- Lua provided by RyzenAPI
-- Game: setManifestid(649822,"2738280511305867356")

-- MAIN APPLICATION
addappid(649820)
-- Game: addappid(649820)

-- MAIN APP DEPOTS / PACKAGES
addappid(649822,0,"dfe20c06e37aedbf6317e765009d99d8d2adf145b03a50157758391f8e1b3f7a")
