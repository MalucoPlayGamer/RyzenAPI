-- Lua provided by RyzenAPI
-- Game: The friends of Ringo Ishikawa – Manga

-- MAIN APPLICATION
addappid(1428220)
-- Game: addappid(1428220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428220,0,"9dbc7d45020d2b82792477ef4357b1c85bea4edbba12841d15f076d9afba0308")
