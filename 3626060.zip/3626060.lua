-- Lua provided by RyzenAPI
-- Game: Lust Academy Final - Beyond the Veil

-- MAIN APPLICATION
addappid(3626060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3626060,0,"234075db63c4153b7ae55622e9867591c85dae14d341f2fb5e50d6011d469727")

