-- Lua provided by RyzenAPI
-- Game: Ereban: Shadow Legacy

-- MAIN APPLICATION
addappid(1671360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671362,0,"6ad79ede93def0530e1ad8a406c61fe54a5af84bc94d3afc98fc64b75542ec6c")

