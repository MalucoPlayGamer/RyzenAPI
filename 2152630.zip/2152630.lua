-- Lua provided by SkyAPI 
-- Game: Dream Team Basketball
addappid(2152630)
addappid(2152631, 1, "ba59fd04b88420682a83b1b0fd76452846a5be1fa324603dbd77ca095c35ad48")
