-- Lua provided by RyzenAPI
-- Game: 1635750

-- MAIN APPLICATION
addappid(1635750)
-- Game: addappid(1635750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635751, 1, "6278d1078be567296c655afba127cc09ed5eeb9fd8ba534d465747f3a64ff8a8")
