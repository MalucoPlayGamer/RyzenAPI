-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VI

-- MAIN APPLICATION
addappid(1173820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1173821, 1, "f14232f6b12f98270c9af46260c0e9ed60c5c3b2e7ea5aa7d7a4a3aad47b27b6")
addappid(1638420, 0, "044ac29b160a56f2451fe51f246515764b172431ebf2871f35f8afad63db50fa")

