-- Lua provided by RyzenAPI 
-- Game: FINAL FANTASY VI
addappid(1173820)
addappid(1173821, 1, "f14232f6b12f98270c9af46260c0e9ed60c5c3b2e7ea5aa7d7a4a3aad47b27b6")
addappid(1638420, 0, "044ac29b160a56f2451fe51f246515764b172431ebf2871f35f8afad63db50fa")
