-- Lua provided by RyzenAPI
-- Game: 1710530

-- MAIN APPLICATION
addappid(1710530)
-- Game: addappid(1710530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710531, 1, "ae5a6ce8fce2d8ed3dbb89152f9aa621fa816490a9583079a498850351231ec3")
