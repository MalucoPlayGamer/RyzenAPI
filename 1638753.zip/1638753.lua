-- Lua provided by RyzenAPI
-- Game: 1638753

-- MAIN APPLICATION
addappid(1638753)
-- Game: addappid(1638753)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638753,0,"e30e8dbac0cc975daf6ae45f3c7d505ad8fbb1e1fd40373ec2c85dc123db8dfb")
