-- Lua provided by RyzenAPI
-- Game: Super Soccer Blast

-- MAIN APPLICATION
addappid(1253680)
-- Game: addappid(1253680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253681, 1, "2cdaa49c907ac24ad8c2d0ad9dcd6b59956a808aec3b9955e1c8bc3b0d8cdcd9")
