-- Lua provided by RyzenAPI
-- Game: Game: AppID 227260

-- MAIN APPLICATION
addappid(227260)
-- Game: addappid(227260)

-- MAIN APP DEPOTS / PACKAGES
addappid(227261, 1, "6026f54075a119ee0f391621f65b1c1a91d3eb751f7971e68f5338d692ac08d4")
