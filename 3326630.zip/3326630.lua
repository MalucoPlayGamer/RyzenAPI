-- Lua provided by RyzenAPI
-- Game: 3326630

-- MAIN APPLICATION
addappid(3326630)
-- Game: addappid(3326630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3326631, 1, "c82d45a423c91f44b5acc72b82729736434233afef52aeb0a1de5cd7fecbece7")
