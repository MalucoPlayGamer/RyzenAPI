-- Lua provided by RyzenAPI
-- Game: The Black Labyrinth

-- MAIN APPLICATION
addappid(3119480)
-- Game: addappid(3119480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3119481, 1, "28cf32997d72efbc6d8abeb4e824f7209e67f2b12025693f93544da82511aef8")
addappid(3119482, 1, "b248d12638030315f289faf81b0c75c24a8cdc61f855aa2c973a5856962c2250")
