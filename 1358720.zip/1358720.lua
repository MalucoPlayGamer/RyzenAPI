-- Lua provided by RyzenAPI
-- Game: Nightmare Puppeteer Demo

-- MAIN APPLICATION
addappid(1358720)
-- Game: addappid(1358720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358721, 1, "5a24cda897e4b3325b437e001033c7ce602f406de4186304002d08f09b475d9a")
