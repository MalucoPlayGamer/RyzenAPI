-- 4269100's Lua and Manifest Created by Hubcap Manifest
-- What'Sub
-- Created: August 23, 2026 at 03:17:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4269100, 1, "141404dd38f45c47b947f2f85c7f5a92df4a00b59066a0705ac22d343b65b103") -- What'Sub
-- MAIN APP DEPOTS
addappid(4269101, 1, "cc1bde48817b86555cd6e6a37f0ae8b90cc16b2677f23b09a39a5fd468ae4c7e") -- Depot 4269101
setManifestid(4269101, "9165757323942846829", 1839071083)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)