-- Lua provided by RyzenAPI
-- Game: Selfie Worm

-- MAIN APP DEPOTS / PACKAGES
addappid(4333980, 1, "2d57b2bf1e08095f3537d11ce654de5dc5273770477090e11e7cb051f5888870") -- Selfie Worm
addappid(4333981, 1, "4ea2a3d6e9dfeb66d0d3b0a1273c63352bd4ebf73f27f3615dd373386de76cd8") -- Depot 4333981
addappid(4333982, 1, "b5fbc55964e4c94a55401cdc70778c3f1cd9d9e8c7980e3706c371966750f61a") -- Depot 4333982
