-- Lua provided by RyzenAPI
-- Game: Meta-Ghost: Prologue

-- MAIN APPLICATION
addappid(2811970)
-- Game: addappid(2811970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811971, 1, "6aaa1278400cb11f8b4778010af36e39361651e0e914b148ebf43989d637131d")
