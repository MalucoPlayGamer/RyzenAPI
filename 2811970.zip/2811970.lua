-- Lua provided by SkyAPI 
-- Game: Meta-Ghost: Prologue
addappid(2811970)
addappid(2811971, 1, "6aaa1278400cb11f8b4778010af36e39361651e0e914b148ebf43989d637131d")
