-- Lua provided by RyzenAPI
-- Game: 929690

-- MAIN APPLICATION
addappid(929690)
-- Game: addappid(929690)

-- MAIN APP DEPOTS / PACKAGES
addappid(929691, 1, "1d43c79461d28fb4a0a20875f62c15510b2e8c8f843431985af836a789aff88c")
