-- Lua provided by RyzenAPI
-- Game: 1791790

-- MAIN APPLICATION
addappid(1791790)
-- Game: addappid(1791790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791791, 1, "630a4d6dbe3c389b58045030e605a0075c45891dcad20eccfb7ccde51dba5b88")
