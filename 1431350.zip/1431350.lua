-- Lua provided by RyzenAPI
-- Game: Santa Claus in Trouble (HD)

-- MAIN APPLICATION
addappid(1431350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431351, 1, "fdaef0b7653dd9a3a1f6002db21827de526c6128066f7a9585f29168e65623e6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
