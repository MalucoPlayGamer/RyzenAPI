-- Lua provided by SkyAPI 
-- Game: Santa Claus in Trouble (HD)
addappid(1431350)
addappid(1431351, 1, "fdaef0b7653dd9a3a1f6002db21827de526c6128066f7a9585f29168e65623e6")
