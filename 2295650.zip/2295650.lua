-- Lua provided by RyzenAPI 
-- Game: Citadale Resurrection
addappid(2295650)
addappid(2295651, 1, "2bd263fe7460469c306f18e794d3f79762522532ed9c605bf2fcea5379b14c65")
