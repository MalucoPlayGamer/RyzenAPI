-- Lua provided by RyzenAPI
-- Game: Game: Citadale Resurrection

-- MAIN APPLICATION
addappid(2295650)
-- Game: addappid(2295650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2295651, 1, "2bd263fe7460469c306f18e794d3f79762522532ed9c605bf2fcea5379b14c65")
