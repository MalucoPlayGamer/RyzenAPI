-- Lua provided by RyzenAPI
-- Game: Rad Rodgers: World One

-- MAIN APPLICATION
addappid(353580)

-- MAIN APP DEPOTS / PACKAGES
addappid(353581, 1, "e4c4b34a754ccfdbaa42ead5195c333dde260959eb733cb880ea9e59bdefc4bc")
