-- Lua provided by RyzenAPI 
-- Game: Doom Rails
addappid(41400)
addappid(41401, 1, "51d000785ab09770e631e2a0c32e9c443f9df980acd95d7ba31c7c0938396dcb")
