-- Lua provided by RyzenAPI
-- Game: Doom Rails

-- MAIN APPLICATION
addappid(41400)
-- Game: addappid(41400)

-- MAIN APP DEPOTS / PACKAGES
addappid(41401, 1, "51d000785ab09770e631e2a0c32e9c443f9df980acd95d7ba31c7c0938396dcb")
