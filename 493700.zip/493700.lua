-- Lua provided by SkyAPI 
-- Game: Monster Puzzle
addappid(493700)
addappid(493701, 1, "f52ef729c1f1ec9abe1476edb91aaab4dd16aea6a8a4942b0f2a8ba0696eca5a")
addappid(493702, 1, "2af4dfec3cd555c25126fab6883f5f427689b79787a04755a89fff78f0e7929a")
addappid(493703, 1, "4cf1a1ec74f1700160ddef81ada56f3e9e984c03bf5e2ffac76690d898e92109")
