-- Lua provided by RyzenAPI
-- Game: Game: AppID 2254910

-- MAIN APPLICATION
addappid(2254910)
-- Game: addappid(2254910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254911, 1, "acd19bcf08661b32c87ff2914cbab18c56a3523f934094ad3864d57017aca152")
