-- Lua provided by RyzenAPI
-- Game: addappid(349181)

-- MAIN APPLICATION
addappid(349181)

-- MAIN APP DEPOTS / PACKAGES
addappid(291661,0,"335d253b68f0dbf0dcd0641b1a351ff0597ad24baddabf51dda7e7c31d58262a")
addtoken(349181,10635756701369841052)
