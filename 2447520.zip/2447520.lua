-- Lua provided by RyzenAPI
-- Game: Hero Siege Playtest

-- MAIN APPLICATION
addappid(2447520)
-- Game: addappid(2447520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447521, 1, "72fe3cbb4fa4829bedc51169f0369b48ff6cfa1070a3e133534de470bb0a0d1b")
