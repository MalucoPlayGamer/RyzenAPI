-- Lua provided by RyzenAPI
-- Game: Game: Insanity Ice

-- MAIN APPLICATION
addappid(1960010)
-- Game: addappid(1960010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960011, 1, "926d81edaa7d7cfc038e55515c01529809a8adbe923ac8f186432e0f599555e6")
