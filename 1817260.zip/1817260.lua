-- Lua provided by RyzenAPI
-- Game: XO Evolved

-- MAIN APPLICATION
addappid(1817260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817261, 1, "1330ab5488fdd7102dd2b789c5c5bb879d75b672d07bd7a192ebcf80d74768bc")

