-- Lua provided by RyzenAPI 
-- Game: Rex Nebular and the Cosmic Gender Bender
addappid(328430)
addappid(328431, 1, "b087f17e1c4d759e070aa5437a08fbf307f49792f46e7bee6ca25f8387cd32a9")
addappid(328432, 1, "91e32ac15b1f875c065f66a0dad4c77aee782ded789e9eb7e64ca489db73d064")
addappid(328433, 1, "b5b77a1d3b77f9e2814abab3dd54a14bc05997874263f190f1c6c232d8708dca")
addappid(328434, 1, "ec4b10fcd3e9afcaac9789a03f5ce007e77f0d1b6d3da59c75303631fc6eeb71")
addappid(328435, 1, "312e973b04646698f2a81ea2fb7da6686432d13e173bdb0042125fdc20809f97")
addappid(328436, 1, "305e8364f897d4a5e774ae49f6658be7567cea4ec398f07e466ff542fabb8583")
