-- Lua provided by SkyAPI 
-- Game: AppID 680680
addappid(680680)
addappid(680681, 1, "f739194cfa209dd18128bc28cd260916249487e93677c7ad0ce816d8f9d0659f")
addappid(680682, 1, "af2aaeadde796b6924e43844fcfff22968006ae56334bd7e3469154d41a55787")
