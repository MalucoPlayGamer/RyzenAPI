-- Lua provided by RyzenAPI
-- Game: Shadow of Fear

-- MAIN APPLICATION
addappid(2644260)
-- Game: addappid(2644260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644261, 1, "d1e7856b96b6963dca7a42328c056d632fa504324234e6d6d7b856005423a10a")
