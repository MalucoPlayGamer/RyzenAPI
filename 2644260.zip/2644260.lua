-- Lua provided by RyzenAPI
-- Game: Shadow of Fear

-- MAIN APPLICATION
addappid(2644260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2644261, 1, "d1e7856b96b6963dca7a42328c056d632fa504324234e6d6d7b856005423a10a")

