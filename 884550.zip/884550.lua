-- Lua provided by RyzenAPI
-- Game: Mist of the Dark

-- MAIN APPLICATION
addappid(884550)

-- MAIN APP DEPOTS / PACKAGES
addappid(884551, 1, "07aeba55461c0cde133040e602182b88b7bb4ead6033e041af93f1dc8abffd9b")

