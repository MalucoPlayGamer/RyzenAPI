-- Lua provided by RyzenAPI
-- Game: Mist of the Dark

-- MAIN APPLICATION
addappid(884550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(884551, 1, "07aeba55461c0cde133040e602182b88b7bb4ead6033e041af93f1dc8abffd9b")

