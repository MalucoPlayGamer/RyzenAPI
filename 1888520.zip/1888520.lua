-- Lua provided by RyzenAPI 
-- Game: AI Stories
addappid(1888520)
addappid(1888521, 1, "abf81fe3edc2be96055d8f1b42a0b15d901fd0df80556f683a100aa72b80aa25")
addappid(1888522, 1, "b9cda45849026b60298ef9f2002789f0c33e4690bb5fc0f65c20873be2f87a0d")
