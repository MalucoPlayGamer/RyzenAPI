-- Lua provided by SkyAPI 
-- Game: Warudo Playtest
addappid(2079740)
addappid(2079741, 1, "cf66e8b6d0e23b3a7cacfaec8e7908149e47f80cb9e40548cc0e060698f61e3f")
