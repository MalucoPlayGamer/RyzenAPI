-- Lua provided by RyzenAPI
-- Game: addappid(1318560)

-- MAIN APPLICATION
addappid(1318560)
addappid(1318562)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318563,0,"80da39a5062452946e0da02e2ffcfeca336ab2befcedf69bfacb41170c9b4d63")
