-- Lua provided by RyzenAPI
-- Game: Glam's Incredible Run: Escape from Dukha

-- MAIN APPLICATION
addappid(1503930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503931, 1, "963fbe8eab51c8bcf8be70c75eb6d514ffc8172faee1e4ce3a96fc2b1ab3109a")
