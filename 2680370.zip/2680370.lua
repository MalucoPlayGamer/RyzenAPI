-- Lua provided by RyzenAPI
-- Game: 2680370

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2680370)
-- Game: addappid(2680370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680372,0,"e44ad6565fd8a916c06e83a2632fd4159b35a6fe2f4a1953671db754b0e0ba85")
