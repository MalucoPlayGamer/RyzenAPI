-- Lua provided by RyzenAPI
-- Game: addappid(494810)

-- MAIN APPLICATION
addappid(494810)

-- MAIN APP DEPOTS / PACKAGES
addappid(494811, 1, "de63e381eb1ba44eff18b5b96c7278dd5d87f66d33cdfe9979940c08eb457236")
