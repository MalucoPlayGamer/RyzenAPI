-- Lua provided by RyzenAPI
-- Game: Radical Spectrum: Volume 1

-- MAIN APPLICATION
addappid(486150)

-- MAIN APP DEPOTS / PACKAGES
addappid(486151, 1, "b6d2ed5c62e02903d645e842f38944a12deb037d50f6c9b4d2ac9026c5701bf3")
addappid(486152, 1, "b816d6b1730ca07c3eb189d0303944a6260f98830082c500a03f57761e37eaf1")
