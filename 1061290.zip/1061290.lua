-- Lua provided by RyzenAPI
-- Game: Game: AppID 1061290

-- MAIN APPLICATION
addappid(1061290)
-- Game: addappid(1061290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061291, 1, "4c5c3b033c878330ba1394d0bd705959e7125e1deb12fd1333a35b105658f620")
