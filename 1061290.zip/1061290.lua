-- Lua provided by SkyAPI 
-- Game: AppID 1061290
addappid(1061290)
addappid(1061291, 1, "4c5c3b033c878330ba1394d0bd705959e7125e1deb12fd1333a35b105658f620")
