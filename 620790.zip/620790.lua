-- Lua provided by RyzenAPI
-- Game: addappid(620790)

-- MAIN APPLICATION
addappid(620790)

-- MAIN APP DEPOTS / PACKAGES
addappid(620791, 1, "7a51c192e2ac4d57a06f52e67bfbc16018af89a648f45fe15743cda5d089e097")
