-- Lua provided by RyzenAPI
-- Game: 1334110

-- MAIN APPLICATION
addappid(1334110)
-- Game: addappid(1334110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334111, 1, "f037c5917c05bd1798914c7cf48c7378c9d92d4605b0b729fafc9227f268cc8f")
