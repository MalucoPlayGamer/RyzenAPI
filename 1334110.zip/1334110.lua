-- Lua provided by RyzenAPI
-- Game: FREAKOUT

-- MAIN APPLICATION
addappid(1334110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1334111, 1, "f037c5917c05bd1798914c7cf48c7378c9d92d4605b0b729fafc9227f268cc8f")

