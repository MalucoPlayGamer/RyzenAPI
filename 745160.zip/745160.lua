-- Lua provided by RyzenAPI
-- Game: AppID 745160

-- MAIN APPLICATION
addappid(745160)
-- Game: addappid(745160)

-- MAIN APP DEPOTS / PACKAGES
addappid(745161, 1, "b583a130208120bac6cccdf113989dc01b83ff812d77bf04bfaa4f2f8a07c02f")
