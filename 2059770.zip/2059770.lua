-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV - Magical Sound Adventure -Light

-- MAIN APPLICATION
addappid(2059770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059770,0,"367c41ec2c32637e608ff51defc7a67b9e7a09277228b6b36d9343291a78a37c")

