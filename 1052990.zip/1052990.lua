-- Lua provided by RyzenAPI
-- Game: A Monster's Expedition

-- MAIN APPLICATION
addappid(1052990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052991, 1, "65d060621a768ab3aaecd365ab466beeaa59e2a1a67028af575c58948786c183")
addappid(1052992, 1, "6c9657af49bab04a8cbb2399d78a8e2fc4f0b5200a27470038ccef95b48a984f")
addappid(1052993, 1, "76b8ed666fce4b5ef78afec3fde5a622b59ff33191f5fa06d2d9593a83ad63cf")

