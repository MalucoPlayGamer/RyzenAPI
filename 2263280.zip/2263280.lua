-- Lua provided by RyzenAPI
-- Game: Dinogen Online Multiplayer Server

-- MAIN APPLICATION
addappid(2263280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263281, 1, "276a41475950c5a4d7510a3e253074b68ad113c83ee7c3dd5dc797d40b5aaa2d")

