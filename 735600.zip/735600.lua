-- Lua provided by RyzenAPI
-- Game: Game: BANZAI ROYALE

-- MAIN APPLICATION
addappid(735600)
-- Game: addappid(735600)

-- MAIN APP DEPOTS / PACKAGES
addappid(735601, 1, "ac70d18dcbb41a049caa04b17634f48d9923ecd590869613b63be979c453318a")
