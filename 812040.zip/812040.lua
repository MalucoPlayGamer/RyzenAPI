-- Lua provided by RyzenAPI
-- Game: AppID 812040

-- MAIN APPLICATION
addappid(812040)

-- MAIN APP DEPOTS / PACKAGES
addappid(812041, 1, "5aec578332ce2c5e59308a1f81c799386ef89d64ebdcc173cc258c73285a7177")
addappid(812042, 1, "d934eadcb1bc75fae24919dee9092126bd39f8e5504ccd83c33148093c4fb2b6")
addappid(1172130, 0, "b0287ad3635235620584a026b313d9673571beec826e75693fa4de6381026a48")
addappid(1392710, 0, "17c82329e6c10d0b8ea2b1aeeeb6f1ae991450223a208daee585b5119eedd139")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3757030)
