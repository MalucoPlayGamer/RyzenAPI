-- Lua provided by RyzenAPI
-- Game: addappid(866520)

-- MAIN APPLICATION
addappid(866520)

-- MAIN APP DEPOTS / PACKAGES
addappid(866521, 1, "ec8bfd130ec022e9125d824be48d36bc2db621551757493458de3248d74957bf")
