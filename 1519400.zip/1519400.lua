-- Lua provided by RyzenAPI
-- Game: Game: AppID 1519400

-- MAIN APPLICATION
addappid(1519400)
-- Game: addappid(1519400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519401, 1, "5601169f78faaf789961f9dfaf397f1457cb5849d5a9559f6928ea8e271e6822")
