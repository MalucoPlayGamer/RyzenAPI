-- Lua provided by RyzenAPI
-- Game: addappid(2838930)

-- MAIN APPLICATION
addappid(2838930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838931, 1, "675b35a410f49c94da8ec2dec7c3dca96f1a86cb2d6d5d31cbab382ab864775a")
