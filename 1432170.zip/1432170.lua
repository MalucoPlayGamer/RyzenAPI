-- Lua provided by RyzenAPI
-- Game: FUSER™ - OneRepublic - "Counting Stars"

-- MAIN APPLICATION
addappid(1432170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432170,0,"813e0a36c16cf51f8a8936d8b11619f3e5be239af2fe034add9b40ef9fa6051a")
