-- Lua provided by RyzenAPI
-- Game: addappid(585420)

-- MAIN APPLICATION
addappid(585420)
addappid(1171470)
addappid(1183540)
addappid(1333570)
addappid(1607390)
addappid(2054110)
addappid(2054120)
addappid(2285970)
addappid(2579530)
addappid(2863610)
addappid(3009870)
addappid(3323320)
addappid(3708690)
addappid(3729370)
addappid(3915680)

-- MAIN APP DEPOTS / PACKAGES
addappid(585421, 1, "131cfc758986f58922fa998a0f28bda5abe20df30a8d51f9f1ff21a91e69d07e")
addappid(3275860, 0, "92541d123b724326f3491f00d06a06ad9cc4c16d90bb42156c8140c43b238d6c")
