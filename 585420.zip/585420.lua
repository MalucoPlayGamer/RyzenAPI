-- Lua provided by RyzenAPI
-- Game: Trailmakers

-- MAIN APPLICATION
addappid(585420)
addappid(1171470)
addappid(1183540)
addappid(1333570)
addappid(1607390)
addappid(2054110)
addappid(2054120)
addappid(2285970)
addappid(2579530)
addappid(2863610)
addappid(3009870)
addappid(3323320)
addappid(3708690)
addappid(3729370)
addappid(3915680)
addappid(4380410)
addappid(5087960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(585421, 1, "131cfc758986f58922fa998a0f28bda5abe20df30a8d51f9f1ff21a91e69d07e")
addappid(3275860, 0, "92541d123b724326f3491f00d06a06ad9cc4c16d90bb42156c8140c43b238d6c")

