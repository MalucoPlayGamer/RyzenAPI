-- Lua provided by RyzenAPI
-- Game: 2244110

-- MAIN APPLICATION
addappid(2244110)
-- Game: addappid(2244110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244111, 1, "243a31b0ffdf3ee501a54d897a51554e7a8a3929d56422bb9ebe2dcdf23272cb")
