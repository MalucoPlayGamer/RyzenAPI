-- Lua provided by RyzenAPI
-- Game: 12530

-- MAIN APPLICATION
addappid(12530)
-- Game: addappid(12530)

-- MAIN APP DEPOTS / PACKAGES
addappid(12531, 1, "b16b4c1f2a46a251063d9104ddb10f3b83b0ae7a067dd87f4e49f579d071e5b0")
