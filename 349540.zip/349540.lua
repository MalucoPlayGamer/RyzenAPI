-- Lua provided by RyzenAPI 
-- Game: PeriAreion
addappid(349540)
addappid(349541, 1, "0f03367af40e17d4f7e1e1ec3187b7d4e86b3ea2761a86ddeda92e51bf98dfc8")
addappid(349542, 1, "782ba06b60fe2b2e2d0105a42bb826d2f359ae22fa9655ab73389d0ceaa3aae4")
