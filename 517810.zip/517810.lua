-- Lua provided by RyzenAPI
-- Game: AppID 517810

-- MAIN APPLICATION
addappid(517810)

-- MAIN APP DEPOTS / PACKAGES
addappid(517811, 1, "a380db153191e6bb6ccc8481abae35acc0da82fca1640a46224d26e3a533f796")
