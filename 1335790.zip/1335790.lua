-- Lua provided by RyzenAPI
-- Game: 1335790

-- MAIN APPLICATION
addappid(1335790)
-- Game: addappid(1335790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335791, 1, "754dc13328edd44c8b6f8618bbd72a482059001a695a5fd8dd98ab5e0938cafb")
