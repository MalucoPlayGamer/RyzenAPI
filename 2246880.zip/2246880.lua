-- Lua provided by SkyAPI 
-- Game: STANDBOX
addappid(2246880)
addappid(2246881, 1, "ee1956c1c6bf8b3aae40730034b6558b10ea4a2c1d7f28a29c23e959921c35cb")
