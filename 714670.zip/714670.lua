-- Lua provided by RyzenAPI
-- Game: Iron Knight

-- MAIN APPLICATION
addappid(714670)

-- MAIN APP DEPOTS / PACKAGES
addappid(714671, 1, "37fcf240335ddd542b348a299ace19a96fe42bb1d7e635d8f7569fb38bb88447")

