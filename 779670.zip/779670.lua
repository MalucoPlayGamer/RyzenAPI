-- Lua provided by RyzenAPI
-- Game: addappid(779670)

-- MAIN APPLICATION
addappid(779670)

-- MAIN APP DEPOTS / PACKAGES
addappid(779671, 1, "c5e20d7cb1abe325f71ef478150b8d19f4caec6d0ae309f7880e8aaa152f7767")
