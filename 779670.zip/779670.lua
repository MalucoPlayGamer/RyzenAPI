-- Lua provided by SkyAPI 
-- Game: AppID 779670
addappid(779670)
addappid(779671, 1, "c5e20d7cb1abe325f71ef478150b8d19f4caec6d0ae309f7880e8aaa152f7767")
