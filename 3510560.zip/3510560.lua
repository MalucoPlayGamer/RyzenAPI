-- Lua provided by RyzenAPI
-- Game: 電視夢工場

-- MAIN APPLICATION
addappid(3510560)
-- Game: addappid(3510560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3510561, 1, "01862684f97ded1f2d276f55aa79d4f2890f61efe510632ac04664556b0e1c23")
addappid(3510562, 1, "952389502fb608f4f7409d53d13646b17a732c0c82ccecd6e9baaacc309f75f8")
addappid(3510563, 1, "bd4ee70dd5c936c70135b68ce68759376e0990d9e239c0a8b3d861ef8d1bdfac")
