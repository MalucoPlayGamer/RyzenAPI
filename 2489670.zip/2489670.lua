-- Lua provided by RyzenAPI
-- Game: addappid(2489670)

-- MAIN APPLICATION
addappid(2489670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2489671, 1, "6eccc70068f1a8b09f61c650b1a389e9ee9bc7b52fb9b4d447035c349213ee6e")
