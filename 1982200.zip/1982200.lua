-- Lua provided by RyzenAPI
-- Game: Neko Night

-- MAIN APPLICATION
addappid(1982200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982202,0,"8e3e312ac17395855a6f4f0426359b03340473763b6ae5a6effd0e42d04d9fce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
