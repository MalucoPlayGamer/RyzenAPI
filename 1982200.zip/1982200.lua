-- Lua provided by RyzenAPI
-- Game: Neko Night

-- MAIN APPLICATION
addappid(1982200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982202,0,"8e3e312ac17395855a6f4f0426359b03340473763b6ae5a6effd0e42d04d9fce")
