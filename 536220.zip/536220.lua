-- Lua provided by RyzenAPI
-- Game: The Walking Dead: A New Frontier

-- MAIN APPLICATION
addappid(536220)
addappid(613181)
addappid(613183)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(536221, 1, "703133d97e2d25ab0d5d341c50e130133748fe005a9ccf401fe75cebea72ad26")
addappid(536223, 1, "50d545b3781ea090d40aea81120a5880fbbbdfd57103289e240b37cf6a6c9580")
addappid(536225, 1, "72809e0de9156b976b4f5294125d6b8431de0e32c7f433e53da06b8e918e200c")
addappid(536228, 1, "efe50117f88613e69521db988b6d0fb302269f3dc3e82dd6b8106a33bef89188")
addappid(613180, 0, "5bd36cfa47b5df7f48f9b4d38c750f7e0e76f4dfe125b642f329d44c2f08f3f6")
addappid(613182, 0, "286edf917478a4ef5f7c108de4afa94b9b0631fb2b39506a0e1623c2c4593c31")
