-- Lua provided by RyzenAPI
-- Game: AppID 1089100

-- MAIN APPLICATION
addappid(1089100)
-- Game: addappid(1089100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089101, 1, "becf22b0beed97f048c3fc0700f6e716747439bde235847a6bea14e1077afa82")
