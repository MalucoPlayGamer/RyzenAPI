-- Lua provided by RyzenAPI
-- Game: Project Search

-- MAIN APPLICATION
addappid(3317890)
-- Game: addappid(3317890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3317891, 1, "94cf1f2a5ffcbeeca7987d53672ba0d250711d1b7938dc4de5df9b4294bc26ec")
