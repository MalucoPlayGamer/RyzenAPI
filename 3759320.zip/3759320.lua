-- Lua provided by RyzenAPI
-- Game: 3759320

-- MAIN APPLICATION
addappid(3759320)
-- Game: addappid(3759320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3759321, 1, "2ff05371058449f51a4222c87617fb695f49f57c08f3ac160cd842fdc1cca060")
