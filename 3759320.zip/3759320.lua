-- Lua provided by RyzenAPI
-- Game: Game: Drugged-up Sex with a Self Destructive Girl! ~Fucking her sugar daddy to support the guys she worships! Overdosing on pills during sex~

-- MAIN APPLICATION
addappid(3759320)
-- Game: addappid(3759320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3759321, 1, "2ff05371058449f51a4222c87617fb695f49f57c08f3ac160cd842fdc1cca060")
