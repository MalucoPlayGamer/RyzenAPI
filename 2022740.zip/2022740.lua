-- Lua provided by RyzenAPI
-- Game: My Landlord is a Futanari

-- MAIN APPLICATION
addappid(2022740)
-- Game: addappid(2022740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022741, 1, "5ff061d282690d9ce96d6820b099f5641994d6a745b4988c2020b07f314f004e")
