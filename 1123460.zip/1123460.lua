-- Lua provided by RyzenAPI
-- Game: addappid(1123460)

-- MAIN APPLICATION
addappid(1123460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1123461, 1, "c0720fb2b9dfccd5cf151c8dce999e9b7790fc96bd266ff96a18b63a2dec8a9f")
