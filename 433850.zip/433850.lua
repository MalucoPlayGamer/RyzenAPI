-- Lua provided by RyzenAPI
-- Game: AppID 433850

-- MAIN APPLICATION
addappid(433850)
-- Game: addappid(433850)

-- MAIN APP DEPOTS / PACKAGES
addappid(433851, 1, "328ed7f5d231ca0cfc1c9994b2ab907a6815029ce6e7dbb701ffff987f2eb751")
