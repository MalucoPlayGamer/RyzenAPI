-- Lua provided by RyzenAPI
-- Game: ProjectM : Daydream

-- MAIN APPLICATION
addappid(646310)

-- MAIN APP DEPOTS / PACKAGES
addappid(646311, 1, "6a0ecd0cf063aa6e28a8eb78adce379d54ecf372f15560be08a97f49dc01d786")

