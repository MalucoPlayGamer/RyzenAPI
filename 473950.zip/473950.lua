-- Lua provided by RyzenAPI
-- Game: Manifold Garden

-- MAIN APPLICATION
addappid(473950)

-- MAIN APP DEPOTS / PACKAGES
addappid(473951, 1, "564eae6d41e9de28a20f0798b204a1b5c6675ccc49c0ce241715feafe9cd1cfd")

