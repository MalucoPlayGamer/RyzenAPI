-- Lua provided by RyzenAPI 
-- Game: Escape From Mystwood Mansion
addappid(2292650)
addappid(2292651, 1, "77c7cb56aaf344a3d73663c11b551d5129f06ad0832ef6fd2686f1eaa856ed76")
