-- Lua provided by RyzenAPI
-- Game: Escape From Mystwood Mansion

-- MAIN APPLICATION
addappid(2292650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2292651, 1, "77c7cb56aaf344a3d73663c11b551d5129f06ad0832ef6fd2686f1eaa856ed76")

