-- Lua provided by RyzenAPI
-- Game: Mega City Void

-- MAIN APPLICATION
addappid(1820930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820931, 1, "1a7ed45033e7992729823941dd47f23cc5079bdb61ab54bb9a80f29eeff2e068")

