-- Lua provided by RyzenAPI
-- Game: AppID 1113850

-- MAIN APPLICATION
addappid(1113850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113851, 1, "974dbea0ea11f79ef8d6a78afcbe374549d5fd88aee5aecb45539d3ce84752e7")

