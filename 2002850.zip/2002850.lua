-- Lua provided by RyzenAPI
-- Game: Raiden IV x MIKADO remix

-- MAIN APPLICATION
addappid(2002850)
-- Game: addappid(2002850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002851, 1, "9beffe53843a9ba784a2d105983e501128a34ceaf3fdc00d70e55b7c88b89d94")
