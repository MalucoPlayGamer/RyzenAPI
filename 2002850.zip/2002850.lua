-- Lua provided by RyzenAPI
-- Game: Raiden IV x MIKADO remix

-- MAIN APPLICATION
addappid(2002850)
addappid(2185350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(2002851, 1, "9beffe53843a9ba784a2d105983e501128a34ceaf3fdc00d70e55b7c88b89d94")

