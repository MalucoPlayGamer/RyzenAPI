-- Lua provided by RyzenAPI 
-- Game: Avernum 6
addappid(206060)
addappid(206061, 1, "801c172d9e30a28306cfbfe64b77d61286c3ba0576662e4143cfac9ebd4ebc99")
