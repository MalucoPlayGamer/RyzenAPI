-- Lua provided by RyzenAPI
-- Game: Game: Avernum 6

-- MAIN APPLICATION
addappid(206060)
-- Game: addappid(206060)

-- MAIN APP DEPOTS / PACKAGES
addappid(206061, 1, "801c172d9e30a28306cfbfe64b77d61286c3ba0576662e4143cfac9ebd4ebc99")
