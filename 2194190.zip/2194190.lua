-- Lua provided by RyzenAPI
-- Game: Ocelot Sunrise

-- MAIN APPLICATION
addappid(2194190)
-- Game: addappid(2194190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194191, 1, "aec78768293c99b31fb2533893737d432b3a6d541c1957b3952c59347ea82167")
