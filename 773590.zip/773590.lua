-- Lua provided by RyzenAPI
-- Game: Azusa RP Online

-- MAIN APPLICATION
addappid(773590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(773591, 1, "53e5e0ca445221d82b32135b2978d9043e3d49bada2fb018b97bb5533652c7d2")

