-- Lua provided by RyzenAPI 
-- Game: Azusa RP Online
addappid(773590)
addappid(773591, 1, "53e5e0ca445221d82b32135b2978d9043e3d49bada2fb018b97bb5533652c7d2")
