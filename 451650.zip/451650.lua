-- Lua provided by RyzenAPI
-- Game: 451650

-- MAIN APPLICATION
addappid(451650)
addappid(4712550)
-- Game: addappid(451650)

-- MAIN APP DEPOTS / PACKAGES
addappid(451651, 1, "d4004d944433e442ddc31f82d48f81dcd729b18d5212ce394f2d3cf3e53eb623")
