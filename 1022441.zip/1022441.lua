-- Lua provided by RyzenAPI
-- Game: DFF NT: Cecil Harvey Starter Pack

-- MAIN APPLICATION
addappid(1022441)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022441,0,"a4ac604b2f02ed355a1c50dc164ac34c86402c411f8ed4684ca8f2e985174947")

