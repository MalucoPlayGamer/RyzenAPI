-- Lua provided by RyzenAPI
-- Game: The Carnival Killer

-- MAIN APPLICATION
addappid(3261510)
-- Game: addappid(3261510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261511, 1, "d461be61ebe3c161123af5b815ce10ed69f895fb194447de21a891b03c562f45")
