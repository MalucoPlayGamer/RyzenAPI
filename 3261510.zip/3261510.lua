-- Lua provided by SkyAPI 
-- Game: The Carnival Killer
addappid(3261510)
addappid(3261511, 1, "d461be61ebe3c161123af5b815ce10ed69f895fb194447de21a891b03c562f45")
