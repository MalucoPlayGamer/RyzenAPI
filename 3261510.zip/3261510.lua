-- Lua provided by RyzenAPI
-- Game: The Carnival Killer

-- MAIN APPLICATION
addappid(3261510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3261511, 1, "d461be61ebe3c161123af5b815ce10ed69f895fb194447de21a891b03c562f45")

