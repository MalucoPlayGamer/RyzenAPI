-- Lua provided by RyzenAPI 
-- Game: AppID 1227420
addappid(1227420)
addappid(1227421, 1, "b6b2d8d127e3866f43f46ad9cebc1b7f42c0a19958c6035e5cea0b4891d04148")
addappid(1227422, 1, "8f3505bddff46cd9dca054264053200be94641b112199923282a924da118fbc7")
