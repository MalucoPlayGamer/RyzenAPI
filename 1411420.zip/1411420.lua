-- Lua provided by RyzenAPI
-- Game: Ordeal

-- MAIN APPLICATION
addappid(1411420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1411421, 1, "e1e35791d7d07698ed5a016253a8ad167f25cf8bcb8b344e5c7e7b725b2223c4")

