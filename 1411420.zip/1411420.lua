-- Lua provided by RyzenAPI
-- Game: 1411420

-- MAIN APPLICATION
addappid(1411420)
-- Game: addappid(1411420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411421, 1, "e1e35791d7d07698ed5a016253a8ad167f25cf8bcb8b344e5c7e7b725b2223c4")
