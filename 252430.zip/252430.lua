-- Lua provided by RyzenAPI
-- Game: addappid(252430)

-- MAIN APPLICATION
addappid(252430)
addappid(297050)
addappid(297870)

-- MAIN APP DEPOTS / PACKAGES
addappid(252431, 1, "1f61ad4a924f4a055f6f367545ccb8b17c50f560084126d1ecfa2351513b8dce")
addappid(252432, 1, "af3049c5ec40f0ce6556df5e18af330ca81960140162c526acbb2219f41eb08f")
