-- Lua provided by RyzenAPI
-- Game: Dusty Revenge:Co-Op Edition

-- MAIN APPLICATION
addappid(252430)
addappid(297050)
addappid(297870)

-- MAIN APP DEPOTS / PACKAGES
addappid(252431, 1, "1f61ad4a924f4a055f6f367545ccb8b17c50f560084126d1ecfa2351513b8dce")
addappid(252432, 1, "af3049c5ec40f0ce6556df5e18af330ca81960140162c526acbb2219f41eb08f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
