-- Lua provided by SkyAPI 
-- Game: Ark Mobius: Censored Edition
addappid(1731520)
addappid(1731521, 1, "0c2c9221d2a8e58e8b2ae8079623f5c69d688da1a2ca58aed99858e6515a8379")
addappid(1773960, 0, "955479afe31def0baa71e23895bd5353dfc59f3483e9cbceab006bce19a578d9")
