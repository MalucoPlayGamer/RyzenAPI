-- Lua provided by RyzenAPI
-- Game: Dauntless

-- MAIN APPLICATION
addappid(331370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(331371, 1, "3de6cef7ed0bcc0f1647a3b1be84627ed7d57fde0ab848dbf1025e35fdc6355b")

