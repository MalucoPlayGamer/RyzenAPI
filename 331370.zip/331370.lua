-- Lua provided by RyzenAPI 
-- Game: AppID 331370
addappid(331370)
addappid(331371, 1, "3de6cef7ed0bcc0f1647a3b1be84627ed7d57fde0ab848dbf1025e35fdc6355b")
