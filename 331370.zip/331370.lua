-- Lua provided by RyzenAPI
-- Game: 331370

-- MAIN APPLICATION
addappid(331370)
-- Game: addappid(331370)

-- MAIN APP DEPOTS / PACKAGES
addappid(331371, 1, "3de6cef7ed0bcc0f1647a3b1be84627ed7d57fde0ab848dbf1025e35fdc6355b")
