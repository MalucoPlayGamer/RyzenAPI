-- Lua provided by RyzenAPI
-- Game: Trizon

-- MAIN APPLICATION
addappid(3064290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064291, 1, "44726536451c08d05f6f607caaabb1f1da65fab81da68b36824792727e8f759d")

