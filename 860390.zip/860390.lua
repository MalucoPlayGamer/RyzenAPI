-- Lua provided by RyzenAPI
-- Game: Math Speed Challenge

-- MAIN APPLICATION
addappid(860390)

-- MAIN APP DEPOTS / PACKAGES
addappid(860391, 1, "3021085ee4bfeeebfb1dde408707fb3694be2cdf35dcc899af742df94eb99139")
