-- Lua provided by SkyAPI 
-- Game: AppID 860390
addappid(860390)
addappid(860391, 1, "3021085ee4bfeeebfb1dde408707fb3694be2cdf35dcc899af742df94eb99139")
