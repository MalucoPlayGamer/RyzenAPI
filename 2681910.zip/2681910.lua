-- Lua provided by RyzenAPI
-- Game: Blacksmith. Song of two Kings. Demo

-- MAIN APPLICATION
addappid(2681910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2681911, 1, "a492016a0fb640cb8aa7d03e1311abe75a25bd05158376b749b3d19e813a3032")

