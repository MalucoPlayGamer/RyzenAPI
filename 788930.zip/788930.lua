-- Lua provided by RyzenAPI 
-- Game: AppID 788930
addappid(788930)
addappid(788931, 1, "75043f9ec868fcf2f96939b3dc5fdace3493e80ed94ffd715569fee26152b157")
addappid(788932, 1, "f7c4854f701a2c724dff774f07c10987c7cf6b8095ff04e1e23cfbf2e1055866")
