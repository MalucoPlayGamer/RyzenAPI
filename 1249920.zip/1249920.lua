-- Lua provided by RyzenAPI
-- Game: addappid(1249920)

-- MAIN APPLICATION
addappid(1249920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249920,0,"73223b1a3e8f782c48719de8f66eb5179a09fd567f3b02cf03d6b198deccf1ad")
