-- Lua provided by RyzenAPI
-- Game: AppID 1090060

-- MAIN APPLICATION
addappid(1090060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090061, 1, "24c082baf0e0bdca075251825861d6d3018be36468a613c832f1e4084971591d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
