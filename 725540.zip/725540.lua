-- Lua provided by RyzenAPI
-- Game: addappid(725540)

-- MAIN APPLICATION
addappid(725540)

-- MAIN APP DEPOTS / PACKAGES
addappid(725541, 1, "fdf1cfe348485d333a4b06c2c0939d3c01c62934f52bb1d0660e39074f178ccb")
