-- Lua provided by RyzenAPI
-- Game: 2514680

-- MAIN APPLICATION
addappid(2514680)
-- Game: addappid(2514680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514681, 1, "ca2843f26042c53e81555a6c5db2138b8becfff6ff1f060c0cc91ebe5225c1ad")
