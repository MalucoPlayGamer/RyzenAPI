-- Lua provided by RyzenAPI 
-- Game: AppID 63600
addappid(63600)
addappid(63601, 1, "c7c98c533426b5f2644105217f3dcfd576f1692e41dbcc791232ec362381a715")
