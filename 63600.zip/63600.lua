-- Lua provided by RyzenAPI
-- Game: 63600

-- MAIN APPLICATION
addappid(63600)
-- Game: addappid(63600)

-- MAIN APP DEPOTS / PACKAGES
addappid(63601, 1, "c7c98c533426b5f2644105217f3dcfd576f1692e41dbcc791232ec362381a715")
