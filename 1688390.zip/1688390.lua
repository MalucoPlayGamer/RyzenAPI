-- Lua provided by RyzenAPI
-- Game: Nightron Wars

-- MAIN APPLICATION
addappid(1688390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688391, 1, "e27bd2f353abc34ac0e8d53f6b02f1b5462f26f2b18c890597dd1ce5152bc567")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
