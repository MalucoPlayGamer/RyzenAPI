-- Lua provided by RyzenAPI
-- Game: Nightron Wars

-- MAIN APPLICATION
addappid(1688390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688391, 1, "e27bd2f353abc34ac0e8d53f6b02f1b5462f26f2b18c890597dd1ce5152bc567")

