-- Lua provided by RyzenAPI
-- Game: Hell is Others

-- MAIN APPLICATION
addappid(964440)

-- MAIN APP DEPOTS / PACKAGES
addappid(964441,0,"203b89acdccfef4597d6693196f8bf70f383f015a7f545da663e4a229775a3bb")
addappid(2170430,0,"e587cce17a5a7772c8befc21f75fb0fc00005d0ef09f5ac45eae946e0b11519b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
