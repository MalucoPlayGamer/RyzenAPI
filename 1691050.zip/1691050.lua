-- Lua provided by RyzenAPI 
-- Game: AppID 1691050
addappid(1691050)
addappid(1691051, 1, "e7cf0f2cfe7afe5ff45447c449e82ef522a8753838a03f82c7e2a6f6a340f158")
