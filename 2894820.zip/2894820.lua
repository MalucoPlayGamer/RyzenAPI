-- Lua provided by RyzenAPI
-- Game: addappid(2894820)

-- MAIN APPLICATION
addappid(2894820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2894821, 1, "91029697a955f5e752be855b7ab5f5ea23cabdea925ed879a5bf9fb784fecff8")
