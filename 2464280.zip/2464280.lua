-- Lua provided by RyzenAPI
-- Game: Tormented Souls 2

-- MAIN APPLICATION
addappid(2464280)
addappid(3908350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2464281, 1, "35ad79ec9649e9b4e9adf4595a0cf6a5f154af8dba7cd93afef6a346dea7002d")

