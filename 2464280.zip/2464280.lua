-- Lua provided by RyzenAPI
-- Game: Tormented Souls 2

-- MAIN APPLICATION
addappid(2464280)
addappid(3908350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464281, 1, "35ad79ec9649e9b4e9adf4595a0cf6a5f154af8dba7cd93afef6a346dea7002d")

