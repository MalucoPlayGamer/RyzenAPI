-- Lua provided by RyzenAPI 
-- Game: AppID 709430
addappid(709430)
addappid(709431, 1, "e283da73ef07acc5ec6f7e9c0a9cf192e5e0c3434383bf803ef23f1a041e699d")
