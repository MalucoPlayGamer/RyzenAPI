-- Lua provided by RyzenAPI
-- Game: Trials of the Illuminati: Animated Sea Creatures Jigsaws

-- MAIN APPLICATION
addappid(709430)

-- MAIN APP DEPOTS / PACKAGES
addappid(709431, 1, "e283da73ef07acc5ec6f7e9c0a9cf192e5e0c3434383bf803ef23f1a041e699d")
