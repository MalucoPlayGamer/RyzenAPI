-- Lua provided by RyzenAPI
-- Game: Wattam

-- MAIN APPLICATION
addappid(702680)

-- MAIN APP DEPOTS / PACKAGES
addappid(702681, 1, "967acd271a5d728d1d8acfa61ae17cd333e2051f8b14abc3faa27e4ac0b6b088")
