-- Lua provided by RyzenAPI
-- Game: Game: Friends of little Yus

-- MAIN APPLICATION
addappid(1752430)
-- Game: addappid(1752430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752431, 1, "e51c0ccb6fd6e00bb2ebcb13cf11c713b9b2192cee46593876869a2e7348fadd")
addappid(1752432, 1, "97e5d787c29d8566a50f8ac11ece1ac55bbb9f6b3687d39fea6088efb7cb1b69")
