-- Lua provided by RyzenAPI
-- Game: Echoes of The Backrooms: Remastered

-- MAIN APPLICATION
addappid(2777630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777634,0,"cb23dfa826a38ce7bf8d2ee532daea50aa196d8d864a35e574e6c694a6acfe81")
