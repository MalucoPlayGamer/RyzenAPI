-- Lua provided by RyzenAPI
-- Game: NARUTO X BORUTO Ultimate Ninja STORM CONNECTIONS

-- MAIN APPLICATION
addappid(1020790)
addappid(2171320)
addappid(2171321)
addappid(2171324)
addappid(2171325)
addappid(2171326)
addappid(2171327)
addappid(2171328)
addappid(2171329)
addappid(2171330)
addappid(2171332)
addappid(2594760)
addappid(2674900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020791, 1, "20b22cbbc47231bd29023b51d8a6fa2c019ad774840d245064799912ea48b105")
addappid(2542820, 0, "290c05f9538952fbafab1381ad8516cb900a835310db3701bd21461afa343090")

