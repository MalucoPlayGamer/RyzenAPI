-- Lua provided by RyzenAPI
-- Game: NARUTO X BORUTO Ultimate Ninja STORM CONNECTIONS

-- MAIN APPLICATION
addappid(1020790)
addappid(2171320)
addappid(2171321)
addappid(2171324)
addappid(2171325)
addappid(2171326)
addappid(2171327)
addappid(2171328)
addappid(2171329)
addappid(2171330)
addappid(2171332)
addappid(2594760)
addappid(2674900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020791, 1, "20b22cbbc47231bd29023b51d8a6fa2c019ad774840d245064799912ea48b105")
addappid(2542820, 0, "290c05f9538952fbafab1381ad8516cb900a835310db3701bd21461afa343090")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
