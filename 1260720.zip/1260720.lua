-- Lua provided by RyzenAPI
-- Game: 1260720

-- MAIN APPLICATION
addappid(1260720)
-- Game: addappid(1260720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260721, 1, "ec1f57df94c55a1f1d1fa2aa73d2932fb05ee01f878af8263252c5618e380de4")
