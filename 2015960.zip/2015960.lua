-- Lua provided by RyzenAPI
-- Game: Parcel Corps

-- MAIN APPLICATION
addappid(2015960)
-- Game: addappid(2015960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015961, 1, "49e28894827dbb154e036251a43241f0b5c9aa01cf1f3d09db9ddcaed8e526fb")
