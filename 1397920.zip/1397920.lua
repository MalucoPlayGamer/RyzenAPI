-- Lua provided by RyzenAPI
-- Game: Mr.Mine

-- MAIN APPLICATION
addappid(1397920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1397921, 1, "78c6a3f86d7796b308d3f8ef75e47b94958c63056202393a3045690de2f8eedb")
addappid(1397922, 1, "dde01bab3c05ff2432837390c049ec4ec5d0f8ce22720d8d95c24dd43ee578e9")

