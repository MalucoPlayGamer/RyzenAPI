-- Lua provided by RyzenAPI
-- Game: Life source

-- MAIN APPLICATION
addappid(1050180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050181, 1, "450d7aa629aaeac404acd45ef3c2adf34fb278458855b7d3766e559f6a9aa90f")
