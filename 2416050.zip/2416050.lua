-- Lua provided by RyzenAPI
-- Game: 2416050

-- MAIN APPLICATION
addappid(2416050)
-- Game: addappid(2416050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416051, 1, "db9f67f3e1af4f8549a6f559de7d6de7818e453a17e44731d0c2f5148499a2f4")
