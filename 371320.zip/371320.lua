-- Lua provided by RyzenAPI
-- Game: AppID 371320

-- MAIN APPLICATION
addappid(371320)

-- MAIN APP DEPOTS / PACKAGES
addappid(371321, 1, "039333b393f567f2c4b215a5c54af2850d8c2a8da5ce807cb0a06120461f8307")
addappid(371322, 1, "a67bfb846ed4e3f1aedb4e1799e0e7faca4aca2a0ffb1202e637727abbb4f545")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
