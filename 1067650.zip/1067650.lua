-- Lua provided by RyzenAPI
-- Game: 1067650

-- MAIN APPLICATION
addappid(1067650)
-- Game: addappid(1067650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067651, 1, "948ccacb97d4943a749d754b5b183a98e59bffece4cab3aeb9b682c1493d5d17")
