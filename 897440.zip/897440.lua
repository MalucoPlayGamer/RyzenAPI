-- Lua provided by RyzenAPI
-- Game: 897440

-- MAIN APPLICATION
addappid(897440)
-- Game: addappid(897440)

-- MAIN APP DEPOTS / PACKAGES
addappid(897441, 1, "183512ea1bec44f4a0663ab5b29236a642b5c268f50793406becbd7bc7dc6514")
addappid(897442, 1, "fbf2053a26e8933c7ed75ca00c229a3dabc26faac3e73617971e0b1f2218f2cd")
addappid(897443, 1, "305b86734c21ddc69019bae449811d9c5a1da846c5bc49f09e2e5bce1005a805")
