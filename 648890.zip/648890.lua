-- Lua provided by RyzenAPI
-- Game: DMT: Dynamic Music Tesseract

-- MAIN APPLICATION
addappid(648890)
-- Game: addappid(648890)

-- MAIN APP DEPOTS / PACKAGES
addappid(648891, 1, "604392b1dd5d06b8c5e59144dd606be7b3da5ccfd03f2f0760254d3ad6537897")
addappid(648892, 1, "f4f13b4694114bf8531f54406f8ca9dbc847a65e10512a2abfa60ef945679824")
