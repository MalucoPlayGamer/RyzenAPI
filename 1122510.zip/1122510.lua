-- Lua provided by RyzenAPI
-- Game: 1122510

-- MAIN APPLICATION
addappid(1122510)
-- Game: addappid(1122510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122511, 1, "7c07165e502fdd8ae3a1680756c8af8db22f96b3438ee938acf1c8e848507236")
