-- Lua provided by RyzenAPI
-- Game: Breachers

-- MAIN APPLICATION
addappid(3246660) -- Breachers - Aquatic Fun Bundle
addappid(3246720) -- Breachers - Adrenaline Bundle
addappid(3246730) -- Breachers - Horror Bundle
addappid(3562130) -- Breachers - Gilded Bundle
addappid(3656450) -- Breachers - Sakura Bundle
addappid(3707360) -- Breachers - Wildstyle Bundle
addappid(3731960) -- Breachers - Chivalry Bundle
addappid(3842440) -- Breachers - Quantum Bundle
addappid(3908000) -- Breachers - Banana Bundle
addappid(3992060) -- Breachers - Moonforged Bundle
addappid(4053830) -- Breachers - Hellfire Bundle
addappid(4148420) -- Breachers - Cashflow Bundle
addappid(4201850) -- Breachers - Glacier Bundle
addappid(4347670) -- Breachers - Nova Bundle
addappid(4572920) -- Breachers - Bubblegum Bundle
addappid(4573030) -- Breachers - Anime Stickerbomb Bundle
addappid(4896090) -- Breachers - Vantos Standouts Bundle

-- MAIN APP DEPOTS / PACKAGES
addappid(1922010, 1, "9196584675d4acd3292c271fcd7726aa0a8b77f658a74673788bda195bcf197e") -- Breachers
addappid(1922011, 1, "515868fe0b42e739aec093cc314cd9ecd5aa9ca87e7e94e58211c8104a73dd36") -- Depot 1922011

