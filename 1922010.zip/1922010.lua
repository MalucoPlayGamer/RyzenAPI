-- Lua provided by RyzenAPI
-- Game: Breachers™

-- MAIN APPLICATION
addappid(1922010)
addappid(3562130)
addappid(3656450)
addappid(3707360)
addappid(3731960)
addappid(3842440)
addappid(3908000)
addappid(3992060)
addappid(4053830)
addappid(4148420)
addappid(4201850)
addappid(4347670)
addappid(4572920)
addappid(4573030)
addappid(4896090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922011, 1, "515868fe0b42e739aec093cc314cd9ecd5aa9ca87e7e94e58211c8104a73dd36")

