-- Lua provided by RyzenAPI
-- Game: Breachers™

-- MAIN APPLICATION
addappid(1922010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922011, 1, "515868fe0b42e739aec093cc314cd9ecd5aa9ca87e7e94e58211c8104a73dd36")

