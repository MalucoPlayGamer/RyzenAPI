-- 3649860's Lua and Manifest Created by Hubcap Manifest
-- A Good Day Fishing
-- Created: August 05, 2026 at 13:25:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3649860) -- A Good Day Fishing
-- MAIN APP DEPOTS
addappid(3649861, 1, "c6873e1e4344e95224f5969e8b563f896db7519e53516e8ba6a8bda217c9c34f") -- Depot 3649861
setManifestid(3649861, "8353094939110500127", 233508940)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3649862) -- Depot 3649862 (empty depot)