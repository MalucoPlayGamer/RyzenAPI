-- Lua provided by RyzenAPI
-- Game: A Good Day Fishing

-- MAIN APPLICATION
addappid(3649860) -- A Good Day Fishing
-- addappid(3649862) -- Depot 3649862 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(3649861, 1, "c6873e1e4344e95224f5969e8b563f896db7519e53516e8ba6a8bda217c9c34f") -- Depot 3649861

