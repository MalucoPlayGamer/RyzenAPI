-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1802830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802830,0,"e1d515a3bc8b0c2ad8708e223a54447ae0affbec4fbe264c4b9861996a709593")

