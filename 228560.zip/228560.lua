-- Lua provided by RyzenAPI
-- Game: Game: Teenage Mutant Ninja Turtles™: Out of the Shadows

-- MAIN APPLICATION
addappid(228560)
addappid(228983)
addappid(228990)
addappid(229002)
-- Game: addappid(228560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228561, 1, "76d6ceda8e2d1e2b3fe7da057adac68db648cac5131c72d28f263afd3b3fc1d4")
addappid(228562, 1, "dcb62a2f620401ddf46347b6b5a83482171e3d767f93e2a6bd3ccae6be477a1d")
addappid(228563, 1, "4a6892329f0201a517c69bb4d437a9f2add141b0d192f85b9fadcd43748792da")
addappid(228564, 1, "f6872e062de97407f89279e2a16b4b3e5f65e0430cacc0ed61bf388521d11bbe")
addappid(228565, 1, "e931c4e09db4d2a76351fa1a3d28064e760a323b3a518fcf78013ca7ab3cb280")
addappid(228566, 1, "295fec8a3496e11c293b45e15d567c0376d552444408b06c51a343a5dcc5c09c")
addappid(228567, 1, "8298cba9898ecd7b2ff80cbf4cad87377b821a8795dbdc4d03b176d23cc5b720")
