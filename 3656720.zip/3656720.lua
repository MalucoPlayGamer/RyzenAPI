-- Lua provided by RyzenAPI
-- Game: Dungeon Raid

-- MAIN APPLICATION
addappid(3656720) -- Dungeon Raid

-- MAIN APP DEPOTS / PACKAGES
addappid(3656721, 1, "ae5d4f4d1119d79d9564049ee8998f71cc065c159a5d54208501fcc54bc496db") -- Depot 3656721

