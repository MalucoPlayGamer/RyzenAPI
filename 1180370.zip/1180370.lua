-- Lua provided by RyzenAPI
-- Game: Game: AppID 1180370

-- MAIN APPLICATION
addappid(1180370)
-- Game: addappid(1180370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180371, 1, "1c3ffca657151e72ba839c07629cd6b9f987c091fec41a12176c82739a9238a1")
