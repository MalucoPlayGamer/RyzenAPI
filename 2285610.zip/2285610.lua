-- Lua provided by RyzenAPI
-- Game: Scar of the Doll: A Psycho-Horror Story about the Mystery of an Older Sister

-- MAIN APPLICATION
addappid(2285610)
-- Game: addappid(2285610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285611, 1, "bd09023c4e203867c465bfd0551b95e3de7521c374f3457051217097a0e0ae87")
