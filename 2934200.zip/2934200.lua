-- Lua provided by RyzenAPI
-- Game: Game: Move The Chains - Episode 1 Demo

-- MAIN APPLICATION
addappid(2934200)
-- Game: addappid(2934200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934201, 1, "e53f9d1e17cb2c3b0f2b706d14be3307afef444003c6c481d27fd543f0b40434")
