-- Lua provided by RyzenAPI
-- Game: Karakulo 21

-- MAIN APPLICATION
addappid(4805750) -- Karakulo 21

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4805751, 1, "67f02fbce9454b39b86e62964ee505a31d91c90cbfeb41c6b21768f31adb787d") -- Depot 4805751

