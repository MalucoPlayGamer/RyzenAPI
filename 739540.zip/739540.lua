-- Lua provided by RyzenAPI
-- Game: AppID 739540

-- MAIN APPLICATION
addappid(739540)

-- MAIN APP DEPOTS / PACKAGES
addappid(739541, 1, "3a8057c34ab81eb1a56e871f05dd1e13dda09b7ed8959ac4d6e9e94227e7d860")

