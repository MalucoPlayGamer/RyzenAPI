-- Lua provided by RyzenAPI 
-- Game: Rocks and Rockets
addappid(715470)
addappid(715471, 1, "593666d0889851ed64c770329be29fb9f80b4b4b4ce220fcd3b3b71771b187af")
addappid(730340, 0, "e214e3fe247df06bbda7af1d45260a685b2678a8302cb65ba13adc71bdd10c94")
