-- Lua provided by RyzenAPI
-- Game: AppID 374410

-- MAIN APPLICATION
addappid(374410)

-- MAIN APP DEPOTS / PACKAGES
addappid(374411, 1, "ae851038a78cb1b6de82accb7c9b384b351ff158a61fd9685e2f625f46ae22da")
addappid(374412, 1, "b3e5acc88783d01439f5d9e8a69ab5b795ee7a1bbd3bde1b2311ad927da850a6")
addappid(374413, 1, "acc44c6a9b5d6fd4307a3de6e1bf81454cb6995e67188f8ed96a979740b166be")

