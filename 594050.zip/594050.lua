-- Lua provided by RyzenAPI
-- Game: Game: Red Alliance

-- MAIN APPLICATION
addappid(594050)
-- Game: addappid(594050)

-- MAIN APP DEPOTS / PACKAGES
addappid(594051, 1, "a6f094cb116808137699d4ec9cf640c6128fa27cb93f3fa0f29a32fd041f6bb6")
