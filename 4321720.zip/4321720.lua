-- Lua provided by RyzenAPI
-- Game: Speedway Challenge 2026

-- MAIN APPLICATION
addappid(4321720)

