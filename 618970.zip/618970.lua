-- Lua provided by RyzenAPI
-- Game: Game: Outcast - Second Contact

-- MAIN APPLICATION
addappid(618970)
-- Game: addappid(618970)

-- MAIN APP DEPOTS / PACKAGES
addappid(618971, 1, "ae1197453919016f51eb55f6dc219511a53433d0ed95404799896bc1e1815f93")
addappid(685840, 0, "d5da3e6c7edfd6ad5e5854abbca5c7776a9b6cc1fac4fba9efda3fb278e6c723")
addappid(685850, 0, "8cf2423af155fa45b690d64e825951dab4815c8610b73b72122929bb22cb1aec")
