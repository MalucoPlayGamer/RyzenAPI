-- Lua provided by RyzenAPI
-- Game: Idle Pins

-- MAIN APPLICATION
addappid(1709920)

