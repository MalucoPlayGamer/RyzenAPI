-- Lua provided by RyzenAPI
-- Game: Adult Toy Store

-- MAIN APPLICATION
addappid(848610)

-- MAIN APP DEPOTS / PACKAGES
addappid(848611,0,"ab704d115d96526e4f2eb2649d625c2b8e5a16bb5c6fb0e5fe45a0c840bdcbab")

