-- Lua provided by RyzenAPI
-- Game: Adult Toy Store

-- MAIN APPLICATION
addappid(848610)

-- MAIN APP DEPOTS / PACKAGES
addappid(848611,0,"ab704d115d96526e4f2eb2649d625c2b8e5a16bb5c6fb0e5fe45a0c840bdcbab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
