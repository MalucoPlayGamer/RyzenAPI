-- Lua provided by RyzenAPI
-- Game: Breeze

-- MAIN APPLICATION
addappid(2081460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081461,0,"d50ffb175cac23c924c606d39badaabcd30bdfe27c5ab0342af7c0b8c892473a")
addappid(2081462,0,"45e93333cc78543775af3d7a8610b61ad7f2fb1cb2e383fdbf79db5473d89780")

