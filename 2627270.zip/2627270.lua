-- Lua provided by RyzenAPI
-- Game: The Method of Hiding a Body

-- MAIN APPLICATION
addappid(2627270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2627272,0,"2cf44fd45c71630ef296d8842eaaf153859ea9400c496388c3d412e0d5e0d07d")

