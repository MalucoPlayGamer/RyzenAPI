-- Lua provided by RyzenAPI
-- Game: 2627270

-- MAIN APPLICATION
addappid(2627270)
-- Game: addappid(2627270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2627272,0,"2cf44fd45c71630ef296d8842eaaf153859ea9400c496388c3d412e0d5e0d07d")
