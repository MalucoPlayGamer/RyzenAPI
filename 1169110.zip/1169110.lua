-- Lua provided by RyzenAPI
-- Game: Super Bout: Champion's Tour

-- MAIN APPLICATION
addappid(1169110)
-- Game: addappid(1169110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169112,0,"3b60c6b0ba243870f29b9ea9be8b9d8c1628f53fe8e4cb1bb775cababae8e1a9")
