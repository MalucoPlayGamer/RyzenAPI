-- Lua provided by RyzenAPI
-- Game: Super Bout: Champion's Tour

-- MAIN APPLICATION
addappid(1169110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1169112,0,"3b60c6b0ba243870f29b9ea9be8b9d8c1628f53fe8e4cb1bb775cababae8e1a9")

