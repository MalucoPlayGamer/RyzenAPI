-- Lua provided by RyzenAPI
-- Game: LSD

-- MAIN APPLICATION
addappid(718370)

-- MAIN APP DEPOTS / PACKAGES
addappid(718371, 1, "fb4048732e3fea9bb486d492fd2a8e4578ee250b15ee780b9986ce90cef187f1")

