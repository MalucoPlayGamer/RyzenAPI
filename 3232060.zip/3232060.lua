-- Lua provided by RyzenAPI
-- Game: 3232060

-- MAIN APPLICATION
addappid(3232060)
-- Game: addappid(3232060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3232061, 1, "cc6c969fdf592d36aae729994a24fb4a1a909604a1ba7510de20bbaa3ea92361")
