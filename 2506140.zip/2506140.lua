-- Lua provided by RyzenAPI
-- Game: addappid(2506140)

-- MAIN APPLICATION
addappid(2506140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506141, 1, "36035c039a3ec996cbc235aea110bc123c2366c2ca0bbbef29a3e304392e8669")
