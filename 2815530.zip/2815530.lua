-- Lua provided by RyzenAPI
-- Game: Game: The Last Drop

-- MAIN APPLICATION
addappid(2815530)
-- Game: addappid(2815530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815531, 1, "88009497b28da1421026f0489896e0369b963547e8324a8d9a9cd6efe53cd130")
