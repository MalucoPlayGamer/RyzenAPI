-- Lua provided by RyzenAPI
-- Game: Dear His Majesty

-- MAIN APPLICATION
addappid(3052480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052482,0,"db54d9938e27822f5ee8855e8cd72e5cca759dbed7e3f0f9862e90f57b9a38d9")

