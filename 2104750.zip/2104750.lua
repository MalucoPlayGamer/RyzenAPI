-- Lua provided by RyzenAPI
-- Game: 2104750

-- MAIN APPLICATION
addappid(2104750)
-- Game: addappid(2104750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2104751, 1, "7bba1a357b7f6b017ee822daede77671eef760720829214920d423ba16a134d8")
