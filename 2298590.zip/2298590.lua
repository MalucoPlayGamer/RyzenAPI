-- Lua provided by RyzenAPI
-- Game: addappid(2298590)

-- MAIN APPLICATION
addappid(2298590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298591, 1, "e044b81a681cef3450961c1e7f3f715b7634b33b75b0894b08db6f8bd2976a61")
