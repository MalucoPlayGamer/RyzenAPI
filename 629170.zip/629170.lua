-- Lua provided by RyzenAPI
-- Game: Amnesia Fortnight

-- MAIN APPLICATION
addappid(629170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(629171, 1, "4f8ad1f36a8ebc31fee24b72fed68d0150ebc57865ffa1551cea4230b9f8ccfd")

