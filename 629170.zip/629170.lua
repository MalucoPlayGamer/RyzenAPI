-- Lua provided by RyzenAPI
-- Game: Amnesia Fortnight

-- MAIN APPLICATION
addappid(629170)
-- Game: addappid(629170)

-- MAIN APP DEPOTS / PACKAGES
addappid(629171, 1, "4f8ad1f36a8ebc31fee24b72fed68d0150ebc57865ffa1551cea4230b9f8ccfd")
