-- Lua provided by RyzenAPI
-- Game: Game: Who Is Zombie

-- MAIN APPLICATION
addappid(1853140)
-- Game: addappid(1853140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853141, 1, "f273936c5d778a19d8167916d2674c4e5545289e13cfdd03bdcafe8abc05e4d9")
