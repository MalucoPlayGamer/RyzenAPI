-- Lua provided by RyzenAPI
-- Game: Kunoichi Keiko: Boobs DLC

-- MAIN APPLICATION
addappid(3165930)
-- Game: addappid(3165930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165931, 1, "89b0381cf5b4de91ac946b56118645f0cd827f1701a032afe34fc109d03f732e")
