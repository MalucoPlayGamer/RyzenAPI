-- Lua provided by RyzenAPI
-- Game: Coding Learn

-- MAIN APPLICATION
addappid(1982900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982901, 1, "64f585b794fce0407acc850e06d14087f8b16955bc6de3c6890ceaed6595432b")
