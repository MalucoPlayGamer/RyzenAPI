-- Lua provided by RyzenAPI
-- Game: Game: AppID 1151840

-- MAIN APPLICATION
addappid(1151840)
-- Game: addappid(1151840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151841, 1, "4be47dad9ae6e282316146fa150230d0ac8f252e68942e93e0ae6eae1ba16684")
addappid(1165980, 0, "b8a719493a6cbc4978959b6df1c953e392ad347d6cbcf930ed10ab9107e4c788")
