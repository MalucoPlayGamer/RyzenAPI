-- Lua provided by RyzenAPI
-- Game: AppID 477180

-- MAIN APPLICATION
addappid(477180)

-- MAIN APP DEPOTS / PACKAGES
addappid(477181, 1, "920dd78eaec493a35f0dac648cbcb499f016cab7d025d17040ecf22e74d07a60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
