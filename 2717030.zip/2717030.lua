-- Lua provided by RyzenAPI
-- Game: Game: AppID 2717030

-- MAIN APPLICATION
addappid(2717030)
-- Game: addappid(2717030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717031, 1, "626a4af9ec60e5bbddfb49ee927686df0249b4f3886a07c130fcbb2f5d61b07f")
