-- Lua provided by RyzenAPI
-- Game: Movavi Video Suite 2025 Steam Edition

-- MAIN APPLICATION
addappid(3276070)
addappid(3345990)
addappid(3346000)
addappid(3346010)
addappid(3346020)
addappid(3346030)
addappid(3346040)
addappid(3346050)
addappid(3346060)
addappid(3346070)
addappid(3346080)
addappid(3346100)
addappid(3346110)
addappid(3346120)
addappid(3346130)
addappid(3346140)
addappid(3346150)
addappid(3346160)
addappid(3346180)
addappid(3346200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3276071, 1, "731a27d534b6321cf84d3f18a76217adc82dd434cc11da850d726f7b62b75cec")
