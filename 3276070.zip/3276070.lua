-- Lua provided by RyzenAPI 
-- Game: AppID 3276070
addappid(3276070)
addappid(3276071, 1, "731a27d534b6321cf84d3f18a76217adc82dd434cc11da850d726f7b62b75cec")
