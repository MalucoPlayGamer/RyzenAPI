-- Lua provided by RyzenAPI
-- Game: 3276070

-- MAIN APPLICATION
addappid(3276070)
-- Game: addappid(3276070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3276071, 1, "731a27d534b6321cf84d3f18a76217adc82dd434cc11da850d726f7b62b75cec")
