-- Lua provided by RyzenAPI
-- Game: 《古龙风云录》游戏原声带

-- MAIN APPLICATION
addappid(2786340)
-- Game: addappid(2786340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786341, 1, "e637f8fcf3ab064aee1b0195cf342324c8f3de7fb46a23ac1f3080efe00589c9")
addappid(2786343, 1, "1c6223e2178ee39633ed828c0f236a7427fa95f7031585c69574498572de3b14")
