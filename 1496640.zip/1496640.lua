-- Lua provided by RyzenAPI
-- Game: 1496640

-- MAIN APPLICATION
addappid(1496640)
-- Game: addappid(1496640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496641, 1, "fd70df7440f2d8449df486b1648c5f7becf3bbadc5de426cfdfbd2ba6296a852")
