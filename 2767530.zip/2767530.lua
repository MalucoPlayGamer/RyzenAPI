-- Lua provided by RyzenAPI 
-- Game: Wicked Seed
addappid(2767530)
addappid(2767531, 1, "5e98faea04897f670898e4eac039ecfe4eff5770d0fe517f44a3731de86f130c")
