-- Lua provided by RyzenAPI
-- Game: Wicked Seed

-- MAIN APPLICATION
addappid(2767530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767531, 1, "5e98faea04897f670898e4eac039ecfe4eff5770d0fe517f44a3731de86f130c")

