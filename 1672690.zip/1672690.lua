-- Lua provided by RyzenAPI
-- Game: Game: Across the Galaxy: Stellar Dominator

-- MAIN APPLICATION
addappid(1672690)
-- Game: addappid(1672690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672691, 1, "42d5f8ff1f4cfb7f982e2fe6f030bc95ed5e591cc20979bbbb03ddc8eb212278")
