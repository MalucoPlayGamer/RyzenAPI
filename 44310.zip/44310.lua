-- Lua provided by RyzenAPI
-- Game: 44310

-- MAIN APPLICATION
addappid(44310)
-- Game: addappid(44310)

-- MAIN APP DEPOTS / PACKAGES
addappid(44311, 1, "f0c70b06b6a7f2d1678fd6f790781957901dd57dfce352837562cd02afe12925")
