-- Lua provided by RyzenAPI
-- Game: Street Warriors Online

-- MAIN APPLICATION
addappid(417910)
addappid(559860)
addappid(572310)
addappid(572311)

-- MAIN APP DEPOTS / PACKAGES
addappid(417911, 1, "0f4ff81f9357052af87b0b9aff5838e00e46eef2839ea4b907652e89f8ebdae9")

