-- Lua provided by RyzenAPI
-- Game: Fitzzle Wise Owls

-- MAIN APPLICATION
addappid(884250)

-- MAIN APP DEPOTS / PACKAGES
addappid(884251, 1, "eaf073ecb01f993a47fea126466485384408ef918b41f440d8f95e7b10f4ceb7")
