-- Lua provided by RyzenAPI
-- Game: Backyard Soccer '98

-- MAIN APPLICATION
addappid(3170410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170411, 1, "d1adbdad152f2967887ccf21e95fba41bed705afc107f47c40dc86b843db52ac")
