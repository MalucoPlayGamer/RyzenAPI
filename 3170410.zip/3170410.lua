-- Lua provided by RyzenAPI
-- Game: Backyard Soccer '98

-- MAIN APPLICATION
addappid(3170410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3170411, 1, "d1adbdad152f2967887ccf21e95fba41bed705afc107f47c40dc86b843db52ac")

