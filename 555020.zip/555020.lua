-- Lua provided by RyzenAPI
-- Game: AppID 555020

-- MAIN APPLICATION
addappid(555020)

-- MAIN APP DEPOTS / PACKAGES
addappid(555021, 1, "52a9309d3b1a1982fb1c68086feed932014db26abc53bfd08c6de67fcef68ee5")

