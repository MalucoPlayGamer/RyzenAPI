-- Lua provided by SkyAPI 
-- Game: RUINER
addappid(464060)
addappid(464061, 1, "caf56d9514fc22cab6d846defe4d6f3edf908db25ff6f7742b7d2339d8eaf71e")
addappid(464062, 1, "0799e14bb212309573ede5e16823800c7ce6049901908ef08d131f32d2c328c9")
