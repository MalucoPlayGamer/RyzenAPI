-- Lua provided by RyzenAPI
-- Game: Research And Development 1 - Extra Research

-- MAIN APPLICATION
addappid(3109020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3109020,0,"9ed516a5eb3a37959034bb7711a0ff3844572a549393a3ac100ff784f7819154")

