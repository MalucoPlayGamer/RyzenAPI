-- Lua provided by RyzenAPI
-- Game: Snake Pit

-- MAIN APPLICATION
addappid(1787470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787472,0,"a2afa3a848dff27ed0a26d46b8e3b7e877b85d24101848d9d8c554ae0660aea5")

