-- Lua provided by RyzenAPI 
-- Game: AppID 2244630
addappid(2244630)
addappid(2244631, 1, "035d91f624b6be141d1e97fada71638c977880200146b91197b60c532d340658")
