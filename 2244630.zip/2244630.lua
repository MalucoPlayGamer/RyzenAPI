-- Lua provided by RyzenAPI
-- Game: AppID 2244630

-- MAIN APPLICATION
addappid(2244630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244631, 1, "035d91f624b6be141d1e97fada71638c977880200146b91197b60c532d340658")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3895810)
