-- Lua provided by RyzenAPI
-- Game: PULSAR: Lost Colony

-- MAIN APPLICATION
addappid(252870)

-- MAIN APP DEPOTS / PACKAGES
addappid(252871, 1, "6c05ecaa0bbb97919e27b86f0207cd578f42f66a6f47f97008f8829ac35fac3a")
addappid(252872, 1, "ee6b79aeb3b76327059453e7517f5781ebe28667c657c05c321c8e828d4e861d")
addappid(252873, 1, "d6520440f6cad6737a2a1f7464f9bf7e8fe68e892349d025ce3aa26665ff732d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
