-- Lua provided by RyzenAPI
-- Game: Game: AppID 2794110

-- MAIN APPLICATION
addappid(2794110)
-- Game: addappid(2794110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2794111, 1, "3a49564d52dedb8be7cb426d746da1baae65fd8c06cecff68095c62444bb4bcc")
