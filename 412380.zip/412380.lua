-- Lua provided by RyzenAPI
-- Game: Legend (1994)

-- MAIN APPLICATION
addappid(412380)
-- Game: addappid(412380)

-- MAIN APP DEPOTS / PACKAGES
addappid(412381, 1, "85a276c783c68e0814a9a36593eb156c11cfa1b15c5404339de0f35e94911d64")
