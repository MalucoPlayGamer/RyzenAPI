-- Lua provided by SkyAPI 
-- Game: CCO Car Crash Online Simulator
addappid(2897500)
addappid(2897501, 1, "2bdc5fb96972534bd569e26e0204afe47cdc582ab9791a641ceaf80e2bda8da6")
