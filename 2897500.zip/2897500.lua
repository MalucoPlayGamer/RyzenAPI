-- Lua provided by RyzenAPI
-- Game: CCO Car Crash Online Simulator

-- MAIN APPLICATION
addappid(2897500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2897501, 1, "2bdc5fb96972534bd569e26e0204afe47cdc582ab9791a641ceaf80e2bda8da6")
