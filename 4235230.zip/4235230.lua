addappid(4235230, 1, "063a56d3e945923e9b4384d73105636e6e9c6405169d1a63f845c51d1a1925a9") -- Werewolf: The Inner Beast
addappid(4235231, 1, "31ef69542587c9fb8b15d4810b23816e77dd7595178bf40bfbd771552b27aa03") -- Depot 4235231
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4560040)
addappid(4560040, 1, "719cce34a60fb713b7b6c02c4d069efd4c3c05f6d50188891e02d0384dd66deb") -- Werewolf The Inner Beast - Unrated - Depot 4560040