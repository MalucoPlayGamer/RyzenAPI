-- Lua provided by RyzenAPI
-- Game: Wild Fire

-- MAIN APPLICATION
addappid(2143870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143872,0,"a71fcaf53c48544d7ba0794288cc50576f2b8fab67d31b8481b67ea814dd7ba8")
