-- Lua provided by RyzenAPI 
-- Game: Cardcaster
addappid(3276950)
addappid(3276951, 1, "48ec9f9863ef5f9bebf1adf76f7488528ef01159c9afbe7ed79e2c92ec2db23b")
