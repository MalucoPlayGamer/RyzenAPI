-- Lua provided by RyzenAPI
-- Game: AppID 434380

-- MAIN APPLICATION
addappid(434380)

-- MAIN APP DEPOTS / PACKAGES
addappid(434381, 1, "f554a2fbda386dbcdfc90ba7dda876a4e0bd6d0a88045c80168a60d06a4278e6")
