-- Lua provided by RyzenAPI
-- Game: Game: AppID 1999320

-- MAIN APPLICATION
addappid(1999320)
-- Game: addappid(1999320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999321, 1, "8cee331d3ccd3c9a4c72b4a8e38188a434d96c6edc80300e96b788578f964dc6")
