-- Lua provided by RyzenAPI
-- Game: 2718740

-- MAIN APPLICATION
addappid(2718740)
-- Game: addappid(2718740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718741, 1, "b1a2c27ca53df6f77e224bfdfcf211fd874afea094b01555a6b369ee10c7913d")
