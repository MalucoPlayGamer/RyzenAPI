-- Lua provided by RyzenAPI
-- Game: WHAT THE PAK?!

-- MAIN APPLICATION
addappid(2752710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752711, 1, "8e55a3db740197131363d1a16aed388a6ef4265ad4282b3f6a88576666d40b73")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
