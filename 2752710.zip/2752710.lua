-- Lua provided by RyzenAPI 
-- Game: WHAT THE PAK?!
addappid(2752710)
addappid(2752711, 1, "8e55a3db740197131363d1a16aed388a6ef4265ad4282b3f6a88576666d40b73")
