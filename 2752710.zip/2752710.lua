-- Lua provided by RyzenAPI
-- Game: Game: WHAT THE PAK?!

-- MAIN APPLICATION
addappid(2752710)
-- Game: addappid(2752710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752711, 1, "8e55a3db740197131363d1a16aed388a6ef4265ad4282b3f6a88576666d40b73")
