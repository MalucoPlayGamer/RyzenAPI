-- Lua provided by RyzenAPI
-- Game: addappid(987190)

-- MAIN APPLICATION
addappid(987190)

-- MAIN APP DEPOTS / PACKAGES
addappid(987191, 1, "d600bd53d49db062e743997f9e0ad93ca27c098c118bf4e7ad15cbcff71cf8df")
