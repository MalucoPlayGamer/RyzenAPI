-- Lua provided by RyzenAPI
-- Game: Black Widow: Recharged

-- MAIN APPLICATION
addappid(1714180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714181, 1, "3681a78b874b527ee8cf712bcb7f34780cb65f223c232189317e6bfc53544149")

