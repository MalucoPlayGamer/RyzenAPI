-- Lua provided by RyzenAPI
-- Game: Game: Mucorales

-- MAIN APPLICATION
addappid(2746420)
-- Game: addappid(2746420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746421, 1, "bb046c9e239951ec653c89709b68eea2af6a22cf7d24e6d8b38998dd49bc947e")
