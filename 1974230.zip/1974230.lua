-- Lua provided by RyzenAPI 
-- Game: Locks
addappid(1974230)
addappid(1974231, 1, "3e0142dc6f96f3ba4b9a913d0d57a1e1d6bb5867a16b02fb22f5219021994ded")
