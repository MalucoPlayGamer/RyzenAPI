-- Lua provided by RyzenAPI
-- Game: Locks

-- MAIN APPLICATION
addappid(1974230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1974231, 1, "3e0142dc6f96f3ba4b9a913d0d57a1e1d6bb5867a16b02fb22f5219021994ded")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
