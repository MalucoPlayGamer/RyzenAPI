-- Lua provided by RyzenAPI
-- Game: Game: Rage Runner

-- MAIN APPLICATION
addappid(279520)
-- Game: addappid(279520)

-- MAIN APP DEPOTS / PACKAGES
addappid(279521, 1, "061b79d20450fc7bf19567c8a97668a3500107a8357f05fa9ad5a9390b40a759")
addappid(279522, 1, "e9f643db7b01fc6995f74721367df535e64a25a910cebd1f488d1f719267009e")
addappid(279523, 1, "f16afb3ca4a866207e3e2b92b6f560da82d1ec7ba79b9445ae267dd957c177df")
