-- Lua provided by RyzenAPI 
-- Game: EBOLA
addappid(1094660)
addappid(1094661, 1, "a31bcc70e3b5cb8135a4d95e12e390fba37d511acfb3bcc4a7f9d973501f8537")
