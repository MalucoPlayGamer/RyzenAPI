-- Lua provided by RyzenAPI
-- Game: EBOLA

-- MAIN APPLICATION
addappid(1094660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1094661, 1, "a31bcc70e3b5cb8135a4d95e12e390fba37d511acfb3bcc4a7f9d973501f8537")

