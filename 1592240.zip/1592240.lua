-- Lua provided by RyzenAPI
-- Game: Zoelie - SCAD Games Studio

-- MAIN APPLICATION
addappid(1592240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592241, 1, "a301738c65aea05aed06a2477cf68910d81728217c15f2bd8aaa8fbef5da136d")
