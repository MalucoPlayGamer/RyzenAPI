-- Lua provided by RyzenAPI
-- Game: addappid(2529540)

-- MAIN APPLICATION
addappid(2529540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529541, 1, "27f3544567f36861841387fbc22c2e44cda19aa753f7c0e69fca9b3fdd3e7ab6")
