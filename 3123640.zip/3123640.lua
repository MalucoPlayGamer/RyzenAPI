-- Lua provided by RyzenAPI
-- Game: 3123640

-- MAIN APPLICATION
addappid(3123640)
-- Game: addappid(3123640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123641, 1, "0ab0356a375f4e4bb78ef65c8b52d13cee54acc68812ab168f13088f2777d6aa")
