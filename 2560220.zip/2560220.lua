-- Lua provided by RyzenAPI
-- Game: Getting Out Alive

-- MAIN APPLICATION
addappid(2560220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560221, 1, "709e8567979557c36c561e2999dadab5543d21d59eae4190143923eb7891907b")

