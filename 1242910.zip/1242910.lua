-- Lua provided by RyzenAPI
-- Game: 1242910

-- MAIN APPLICATION
addappid(1242910)
-- Game: addappid(1242910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1242911, 1, "fa9a4acb25dc330dba54658b30cae8debdb192f2e9963d77163a333c933527ab")
