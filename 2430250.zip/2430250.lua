-- Lua provided by RyzenAPI
-- Game: VerdantOfWorld:LostWay

-- MAIN APPLICATION
addappid(2430250)
-- Game: addappid(2430250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430251, 1, "00cdc2843a4697772e372f871256898f643f6edd201d49d948a49ac8e2619245")
