-- Lua provided by RyzenAPI
-- Game: 2402990

-- MAIN APPLICATION
addappid(2402990)
-- Game: addappid(2402990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402991, 1, "bbe84f79cd405844d7d375f7373a7267b4fdf646dc563b0be4234798b75870d2")
