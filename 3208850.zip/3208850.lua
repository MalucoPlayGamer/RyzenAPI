-- Lua provided by RyzenAPI 
-- Game: AppID 3208850
addappid(3208850)
addappid(3208851, 1, "b2780e3acd15cb70077b19f67ec484b55b12413e25353d9de0c4b763fdb764e8")
