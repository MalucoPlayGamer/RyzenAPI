-- Lua provided by RyzenAPI
-- Game: Game: Bits n Bullets

-- MAIN APPLICATION
addappid(730180)
-- Game: addappid(730180)

-- MAIN APP DEPOTS / PACKAGES
addappid(730181, 1, "1e0600d5760fc421dd9f6c755aa4f6e71054ea4df72b425efea0d5115f871892")
