-- Lua provided by RyzenAPI
-- Game: Neofeud

-- MAIN APPLICATION
addappid(673850)

-- MAIN APP DEPOTS / PACKAGES
addappid(673851, 1, "baf1a0f15635d10928b523edb19fec38424676ae63fdde9002b40d5df33c5fdc")
addappid(704730, 0, "03c4fa8c3143c42a83e7edcc4e93e19d753d2844d668b72d29221c0d463039dd")
