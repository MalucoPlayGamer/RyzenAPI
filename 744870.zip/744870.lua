-- Lua provided by RyzenAPI
-- Game: Seven: Enhanced Edition - Original Soundtrack

-- MAIN APPLICATION
addappid(744870)

-- MAIN APP DEPOTS / PACKAGES
addappid(471013,0,"7a6ccc6ff4b96ef460dd2b44d21765726be11479b6c58cf059771adff4b594c0")
addappid(744873,0,"26e7e42b6bbe8cd7017cfb833ea0b49ff40179765010771774989811c8a94f72")

