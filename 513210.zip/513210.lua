-- Lua provided by RyzenAPI
-- Game: Rescue Bear Operation

-- MAIN APPLICATION
addappid(513210)

-- MAIN APP DEPOTS / PACKAGES
addappid(513211, 1, "c433d1226f6091499fa16e0de791e335ba050b43de436ca11dbbb3cdccee8583")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(522930)
addappid(523580)
addappid(523581)
addappid(523582)
addappid(523583)
addappid(531720)
