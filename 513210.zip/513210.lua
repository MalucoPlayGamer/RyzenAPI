-- Lua provided by RyzenAPI
-- Game: addappid(513210)

-- MAIN APPLICATION
addappid(513210)

-- MAIN APP DEPOTS / PACKAGES
addappid(513211, 1, "c433d1226f6091499fa16e0de791e335ba050b43de436ca11dbbb3cdccee8583")
