-- Lua provided by RyzenAPI
-- Game: THE QUIET MAN™

-- MAIN APPLICATION
addappid(790540)

-- MAIN APP DEPOTS / PACKAGES
addappid(790541, 1, "8a6fd00a5933e79e29a37910c213f741ab9fee49f9841ca8f091162a0a6cb986")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(919310)
