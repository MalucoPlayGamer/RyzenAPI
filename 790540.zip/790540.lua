-- Lua provided by RyzenAPI
-- Game: addappid(790540)

-- MAIN APPLICATION
addappid(790540)

-- MAIN APP DEPOTS / PACKAGES
addappid(790541, 1, "8a6fd00a5933e79e29a37910c213f741ab9fee49f9841ca8f091162a0a6cb986")
