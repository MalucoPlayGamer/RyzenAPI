-- Lua provided by RyzenAPI
-- Game: Let Bions Be Bygones Demo

-- MAIN APPLICATION
addappid(2629460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629461, 1, "559fc3e51c02c5ffc667d7499731b014097e91f01875c009357b22bf8e00bcc1")

