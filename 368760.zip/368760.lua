-- Lua provided by RyzenAPI
-- Game: 368760

-- MAIN APPLICATION
addappid(368760)
-- Game: addappid(368760)

-- MAIN APP DEPOTS / PACKAGES
addappid(368761, 1, "c42c272c6f3a9494cc4b486c9270145028ad196a4cd847db6ede1578eb80eb3e")
addappid(368762, 1, "77665b0f898b8f648209e9f0cfadc14f0dfa704f218a3a90aa1d129a66b3c67a")
