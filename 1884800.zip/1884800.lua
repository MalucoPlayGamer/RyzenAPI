-- Lua provided by RyzenAPI
-- Game: Omitted

-- MAIN APPLICATION
addappid(1884800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884801, 1, "d47b1b873a6c9f68b8c743733767a01b87ae13b9b9ca6f88142178ca234f84f8")
