-- Lua provided by SkyAPI 
-- Game: Omitted
addappid(1884800)
addappid(1884801, 1, "d47b1b873a6c9f68b8c743733767a01b87ae13b9b9ca6f88142178ca234f84f8")
