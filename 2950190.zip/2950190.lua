-- Lua provided by RyzenAPI
-- Game: BloodLight

-- MAIN APPLICATION
addappid(2950190)
-- Game: addappid(2950190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2950191, 1, "d61a74ecbb571974a0f77a459f6b7aefdb228d98f21bc8e0480e646a0b2213d5")
