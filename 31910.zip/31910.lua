-- Lua provided by RyzenAPI
-- Game: Nancy Drew®: The Haunting of Castle Malloy

-- MAIN APPLICATION
addappid(31910)

-- MAIN APP DEPOTS / PACKAGES
addappid(31911, 1, "8c699c86bc540561fd53078e7cb3f40baf066621d9271082a91bf08c94124755")
