-- Lua provided by RyzenAPI
-- Game: LEAP

-- MAIN APPLICATION
addappid(906930)
-- Game: addappid(906930)

-- MAIN APP DEPOTS / PACKAGES
addappid(906931, 1, "ab09238b5729845db0eb4a090d50090b4f65e9d735be54b5ad0dc9e997fbf886")
