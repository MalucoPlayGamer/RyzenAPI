-- Lua provided by RyzenAPI
-- Game: LEAP

-- MAIN APPLICATION
addappid(906930)
addappid(1771270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(906931,0,"ab09238b5729845db0eb4a090d50090b4f65e9d735be54b5ad0dc9e997fbf886")

