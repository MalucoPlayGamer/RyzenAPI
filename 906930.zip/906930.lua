-- Lua provided by RyzenAPI
-- Game: LEAP

-- MAIN APPLICATION
addappid(906930)
addappid(1771270)

-- MAIN APP DEPOTS / PACKAGES
addappid(906931,0,"ab09238b5729845db0eb4a090d50090b4f65e9d735be54b5ad0dc9e997fbf886")

