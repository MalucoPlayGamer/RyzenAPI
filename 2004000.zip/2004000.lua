-- Lua provided by RyzenAPI
-- Game: The Cub Demo

-- MAIN APPLICATION
addappid(2004000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004001, 1, "952e60ffc5bbde7778a86f7add3ebbf27e8822d49fdd56489917266330c05126")

