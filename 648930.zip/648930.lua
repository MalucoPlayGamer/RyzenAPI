-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(648930)

-- MAIN APP DEPOTS / PACKAGES
addappid(648930,0,"ec0f49e81bd0dac85e45def5cefba761780826aaf97f43676651f6c78f5987bf")
