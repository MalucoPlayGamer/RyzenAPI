-- Lua provided by RyzenAPI
-- Game: Game: AppID 348950

-- MAIN APPLICATION
addappid(348950)
-- Game: addappid(348950)

-- MAIN APP DEPOTS / PACKAGES
addappid(348951, 1, "754aa7df230bacce52ac61b197555a120e8880e630d7508f89999c6df38c7353")
addappid(348952, 1, "d2c6f3fe5f9568927193f7456d02ef682e451e36d50711bb31de0aa7cc6d34a5")
