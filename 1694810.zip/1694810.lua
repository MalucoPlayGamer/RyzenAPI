-- Lua provided by RyzenAPI
-- Game: Nightmares to be

-- MAIN APPLICATION
addappid(1694810)
-- Game: addappid(1694810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1694811, 1, "a435a2fe3c0a739e15c69c42a2273f2b579767a972c7803eea445e91a66e8b80")
