-- Lua provided by RyzenAPI
-- Game: addappid(871651)

-- MAIN APPLICATION
addappid(871651)

-- MAIN APP DEPOTS / PACKAGES
addappid(871651,0,"599c341d17f74a0320f42a57c93207b05be9d547a1e3de5cc8d55719ad0563c1")
addappid(1083440,0,"2accfdbbe5f172aa4344a05afc2c1022cb647d1c36f9277cb0fc91c40f79ef5e")
addappid(1083441,0,"c658ce292f63cfbe12a720e2f9c01fa30489bba6efb2a1bcd6f0da4208aaa77f")
