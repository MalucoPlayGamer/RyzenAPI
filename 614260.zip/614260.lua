-- Lua provided by RyzenAPI
-- Game: Gates Of Nowhere

-- MAIN APPLICATION
addappid(614260)

-- MAIN APP DEPOTS / PACKAGES
addappid(614261,0,"ff8c28afc24630bed96df960bac4ee74201bfa0cb57d55e6962aa2c8269d3a66")

