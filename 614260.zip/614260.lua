-- Lua provided by RyzenAPI
-- Game: Gates Of Nowhere

-- MAIN APPLICATION
addappid(614260)

-- MAIN APP DEPOTS / PACKAGES
addappid(614261,0,"ff8c28afc24630bed96df960bac4ee74201bfa0cb57d55e6962aa2c8269d3a66")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
