-- Lua provided by RyzenAPI
-- Game: AppID 3035190

-- MAIN APPLICATION
addappid(3035190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035191, 1, "9ef73fee98cff62f8cb99bfc3d28d4d185191c49db561cf950df29b76be610c7")
