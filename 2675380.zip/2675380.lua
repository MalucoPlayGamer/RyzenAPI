-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - KFLL Airport

-- MAIN APPLICATION
addappid(2675380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675380,0,"9df4c808e4273b0eb25f4f735b4bc1a3df9da02b8b6056b3eb0302693085b74b")

