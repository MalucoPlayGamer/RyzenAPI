-- Lua provided by RyzenAPI
-- Game: Magic War

-- MAIN APPLICATION
addappid(1970740)
-- Game: addappid(1970740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970741, 1, "2bb913ff45a821007922bc061879f34b0bff8a64b040df8642e2fb829e33095e")
