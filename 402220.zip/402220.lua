-- Lua provided by RyzenAPI
-- Game: Lift It

-- MAIN APPLICATION
addappid(402220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(402221, 1, "af7feecf3e85e2779e58b9b7c6ecc8fe7dd513b70b75cbd1a01286ffd4ecc1ec")

