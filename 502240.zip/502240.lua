-- Lua provided by RyzenAPI
-- Game: AppID 502240

-- MAIN APPLICATION
addappid(502240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(502241, 1, "4f043f81cbe5c2517650440fcd87c25fa77c984cebadf7e307d9f58ced29d44e")

