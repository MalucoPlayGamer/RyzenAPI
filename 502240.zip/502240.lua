-- Lua provided by RyzenAPI
-- Game: 502240

-- MAIN APPLICATION
addappid(502240)
-- Game: addappid(502240)

-- MAIN APP DEPOTS / PACKAGES
addappid(502241, 1, "4f043f81cbe5c2517650440fcd87c25fa77c984cebadf7e307d9f58ced29d44e")
