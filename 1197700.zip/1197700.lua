-- Lua provided by RyzenAPI
-- Game: Hermes: War of the Gods

-- MAIN APPLICATION
addappid(1197700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197701, 1, "37e62343946ca659619e79dc282ab17e36fb01f4558cb1ebc4dee101f7b812bb")
addappid(1197704, 1, "4e43b9418c486bae60f992afda0c1f3da1c95dcf9d47544083f56223f47c997d")
