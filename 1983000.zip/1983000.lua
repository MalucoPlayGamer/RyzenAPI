-- Lua provided by RyzenAPI
-- Game: 1983000

-- MAIN APPLICATION
addappid(1983000)
-- Game: addappid(1983000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983001, 1, "ea52fb153f8d7ba5f87e86a1c82fb3e1ee389922de7cd05605b158fa0ebac035")
