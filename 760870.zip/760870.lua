-- Lua provided by RyzenAPI
-- Game: AppID 760870

-- MAIN APPLICATION
addappid(760870)

-- MAIN APP DEPOTS / PACKAGES
addappid(760871, 1, "78e6dba49ff956706ddaa9dca7e361fb9b9c1456c5d7dad69535692bbca6df61")
