-- Lua provided by RyzenAPI
-- Game: The Nom

-- MAIN APPLICATION
addappid(2771320)
addappid(2820860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771321, 1, "26ecd8537ca914dad2dfb4b186b04fe79739022b529c0429587512f2c2d64bf3")
