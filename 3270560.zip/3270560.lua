-- Lua provided by RyzenAPI 
-- Game: Boo Boo Booster
addappid(3270560)
addappid(3270561, 1, "f8633e70d36ca32eba4c93f069278dc430921e0b7e9b1d2992d493ec36f0dbfe")
