-- Lua provided by RyzenAPI
-- Game: Nova Nukers!

-- MAIN APPLICATION
addappid(445000)
-- Game: addappid(445000)

-- MAIN APP DEPOTS / PACKAGES
addappid(445001, 1, "d20f88e8f00f139e10d12d66168150cd3cadd50cece30f4a71af1d3c03b5ad64")
