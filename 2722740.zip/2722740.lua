-- Lua provided by SkyAPI 
-- Game: Watermelon Suika Game
addappid(2722740)
addappid(2722741, 1, "e4c0cf61f2291b6eadc2c55b20a57aab00720cf9e363ff144823513d91ca848d")
