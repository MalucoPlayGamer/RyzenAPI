-- Lua provided by RyzenAPI
-- Game: Game: AppID 749650

-- MAIN APPLICATION
addappid(749650)
addappid(757750)
-- Game: addappid(749650)

-- MAIN APP DEPOTS / PACKAGES
addappid(749651, 1, "eddb0d887e6669c597a8df0435f9a3fd62fc20497759a14866662f05043a428e")
