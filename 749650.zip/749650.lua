-- Lua provided by RyzenAPI
-- Game: Barrimean Jungle

-- MAIN APPLICATION
addappid(749650)
addappid(757750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(749651, 1, "eddb0d887e6669c597a8df0435f9a3fd62fc20497759a14866662f05043a428e")
