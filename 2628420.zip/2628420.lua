-- Lua provided by RyzenAPI
-- Game: Croakoloco

-- MAIN APPLICATION
addappid(2628420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628421, 1, "ad64b7093f376760287474559db2347f089ab5c23f0407aef16d7d744e96b6f8")
