-- Lua provided by SkyAPI 
-- Game: Croakoloco
addappid(2628420)
addappid(2628421, 1, "ad64b7093f376760287474559db2347f089ab5c23f0407aef16d7d744e96b6f8")
