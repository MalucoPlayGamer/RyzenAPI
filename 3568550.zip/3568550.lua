-- Lua provided by RyzenAPI
-- Game: Tainted Pools

-- MAIN APPLICATION
addappid(3568550)
-- Game: addappid(3568550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3568551, 1, "61937951ac6a7acf20beced2ad21109b0c66738667a779f97029abf86d5143aa")
