-- Lua provided by RyzenAPI
-- Game: addappid(3181580)

-- MAIN APPLICATION
addappid(3181580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181580,0,"ed2148cdee8ff3d9bebb95c357adff9c6445874519334eabecc76cafaea03523")
