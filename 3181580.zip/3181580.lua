-- Lua provided by RyzenAPI
-- Game: Beat Saber - Britney Spears - Till the World Ends - Till the World Ends

-- MAIN APPLICATION
addappid(3181580)
-- Game: addappid(3181580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181580,0,"ed2148cdee8ff3d9bebb95c357adff9c6445874519334eabecc76cafaea03523")
