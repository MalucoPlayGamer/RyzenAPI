-- Lua provided by RyzenAPI
-- Game: addappid(2635050)

-- MAIN APPLICATION
addappid(2635050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635051, 1, "9d55bb1512a1aac31ebbecfc6c48b45e6e5f3f9a5436792544dd9ab17631cf68")
