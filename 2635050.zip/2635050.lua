-- Lua provided by RyzenAPI
-- Game: Sancticide

-- MAIN APPLICATION
addappid(2635050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635051, 1, "9d55bb1512a1aac31ebbecfc6c48b45e6e5f3f9a5436792544dd9ab17631cf68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
