-- Lua provided by RyzenAPI
-- Game: BlazBlue Entropy Effect - Soundtrack B

-- MAIN APPLICATION
addappid(2872920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2872921, 1, "1d9b78c5d9de65e82553135803e1141a63c04e20028de8376ec9398ef67ae727")
addappid(2872922, 1, "46574a10735fbe8a7d678a380cdab1dd5618849d50fc82f3273df2cc86e9f88c")

