-- Lua provided by RyzenAPI
-- Game: 少女战场

-- MAIN APPLICATION
addappid(2353450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353451, 1, "7d50f49e0add77de4e51bfc9427aa4ba80ddac4fb0715c66ebd326645cc6c46c")

