-- Lua provided by RyzenAPI 
-- Game: AppID 1844200
addappid(1844200)
addappid(1844201, 1, "ff6d5a0490b156b862fd96eb9f82bb9e994c174095b5e1937a7332b8a1f9ce59")
