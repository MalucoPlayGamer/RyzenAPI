-- Lua provided by RyzenAPI
-- Game: My Furry Maid 🐾

-- MAIN APPLICATION
addappid(1977050)
addappid(1984750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977051, 1, "3d6f92730da9aa7e419cd7bef2ec84397d740dbd87cc6340afe53699508913c4")
addappid(1977052, 1, "4f5ae89adbba930be1f5e7e8cb6ef1abfd7aac5aee43d88e61a7e2f3d08521a4")
