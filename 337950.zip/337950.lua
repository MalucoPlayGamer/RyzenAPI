-- Lua provided by SkyAPI 
-- Game: AppID 337950
addappid(337950)
addappid(337951, 1, "2668ad09857868d8bef17e6742253cb62582a90f0536cd56079435c4ff8b88e4")
