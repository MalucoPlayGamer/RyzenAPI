-- Lua provided by RyzenAPI
-- Game: Game: AppID 337950

-- MAIN APPLICATION
addappid(337950)
-- Game: addappid(337950)

-- MAIN APP DEPOTS / PACKAGES
addappid(337951, 1, "2668ad09857868d8bef17e6742253cb62582a90f0536cd56079435c4ff8b88e4")
