-- Lua provided by RyzenAPI
-- Game: 280200

-- MAIN APPLICATION
addappid(280200)
addappid(287250)
-- Game: addappid(280200)

-- MAIN APP DEPOTS / PACKAGES
addappid(280201, 1, "5e7cb559b1980e0cc87b663a398d0bfe91ba37b8fe4afa6dd1e1307d574b7e48")
