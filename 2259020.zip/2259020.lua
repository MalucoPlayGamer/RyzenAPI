-- Lua provided by RyzenAPI
-- Game: Game: Cassette Beasts: Original Soundtrack

-- MAIN APPLICATION
addappid(2259020)
-- Game: addappid(2259020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259021, 1, "c4f28afc4b73c13cb73d022dd044a95882b0c8b6f49ddc1b533e2c754de0ced7")
addappid(2259022, 1, "684580547dec5ebb2cdf33923e11385f1917db6b005244f8361da54be46aa8ec")
