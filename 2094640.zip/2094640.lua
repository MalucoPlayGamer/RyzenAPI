-- Lua provided by RyzenAPI
-- Game: Save Daddy Trump 3: Rise Of Evil

-- MAIN APPLICATION
addappid(2094640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094641, 1, "5f4839c68ce395ba88153fbfe09eef558b1e9c098c0405f7e8c6ccbf315a3291")
