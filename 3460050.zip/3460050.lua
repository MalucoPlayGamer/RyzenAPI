-- Lua provided by RyzenAPI
-- Game: Game: A Sexy Tour With : Tanvi

-- MAIN APPLICATION
addappid(3460050)
-- Game: addappid(3460050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460051, 1, "1fdcb6c2c4175a531f1cb0cfbfd3098b3a878ba067f70318ad9f59ff75b43fea")
