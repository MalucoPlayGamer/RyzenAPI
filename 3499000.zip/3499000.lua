-- Lua provided by RyzenAPI
-- Game: Partisan

-- MAIN APPLICATION
addappid(3499000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499002,0,"5690a9f623e5d312663c862776968b64f6be3413dfc1849081ec50385f633eca")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
