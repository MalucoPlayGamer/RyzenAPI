-- Lua provided by RyzenAPI
-- Game: Partisan

-- MAIN APPLICATION
addappid(3499000)
-- Game: addappid(3499000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3499002,0,"5690a9f623e5d312663c862776968b64f6be3413dfc1849081ec50385f633eca")
