-- Lua provided by SkyAPI 
-- Game: Double Dragon Gaiden: Rise Of The Dragons
addappid(1967260)
addappid(1967261, 1, "f72501396cb0ffeadaddc1c636085b6d618b31ef376acd0afd663cb13ea83d80")
addappid(1967262, 1, "b441dc4e9638bd4630f8f06d2a2d660cc2e0663b61e99793a4b3e7631ecc8b9d")
addappid(1967263, 1, "2676fe5f1108633d33e11f3fca8e4637990795e339a7702bff50d72f85fa339f")
