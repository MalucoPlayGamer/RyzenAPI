-- Lua provided by RyzenAPI
-- Game: addappid(2216120)

-- MAIN APPLICATION
addappid(2216120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216121, 1, "ff51a31583104f487ab0edc9a153551076aa6fc4d43858d8027c80c16e0a9b8e")
