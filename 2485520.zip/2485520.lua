-- Lua provided by RyzenAPI
-- Game: Hammer of Pain Playtest

-- MAIN APPLICATION
addappid(2485520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485523,0,"a2473898b45142d31618263b1b313cdda0b993d3a2170a292e30d1c6133ff8e9")
