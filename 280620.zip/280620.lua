-- Lua provided by RyzenAPI
-- Game: Fiesta Online

-- MAIN APPLICATION
addappid(280620)

-- MAIN APP DEPOTS / PACKAGES
addappid(280622,0,"8d006f1ff4d95b98049b4c421fa59e275061ec2a632017960918521eddd7fbbe")
addappid(280623,0,"d25666cb07d86749dd8adb00d329db2548597a393b053d4eaeb582f34609c0e2")
addappid(280624,0,"c80b2599bc88c212b5f08ec160226640fe12bc8df55a79403b5abb7b036762c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
