-- Lua provided by RyzenAPI
-- Game: 1684159

-- MAIN APPLICATION
addappid(1684159)
-- Game: addappid(1684159)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684159,0,"cb08a05bad2d7e52d1db7ccb8213879a03352e34a7aaa2e750b664ce64dc955e")
