-- Lua provided by RyzenAPI
-- Game: Wide Cross

-- MAIN APPLICATION
addappid(803800)

-- MAIN APP DEPOTS / PACKAGES
addappid(803801, 1, "42907f8b72c68057cbaef7491746c49216b015609c9c01c43701c5d3d156d8b9")

