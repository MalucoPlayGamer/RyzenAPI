-- Lua provided by RyzenAPI
-- Game: Shoes Store Simulator

-- MAIN APPLICATION
addappid(3319250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3319251, 1, "660476d6ad2dd9bec32a18fc1ec53e3d840531771763645d0dce37eeec1ac14c")

