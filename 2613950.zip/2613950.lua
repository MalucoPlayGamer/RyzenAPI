-- Lua provided by RyzenAPI
-- Game: addappid(2613950)

-- MAIN APPLICATION
addappid(2613950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613951, 1, "298b10be2cce7ae9ad5e5acb64e48c100ab6be5af21ed54ffbd5210212f9c4da")
