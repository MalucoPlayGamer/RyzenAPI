-- Lua provided by RyzenAPI
-- Game: KYOTO TANOJI QUEST

-- MAIN APPLICATION
addappid(558680)
-- Game: addappid(558680)

-- MAIN APP DEPOTS / PACKAGES
addappid(558681, 1, "599863b03fd4e3436d91fc06ab6f0b9d78ccdc94a6f21cb8f5c5eb4a77a76ade")
