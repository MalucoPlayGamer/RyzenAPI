-- Lua provided by RyzenAPI
-- Game: Doka 2 Trade

-- MAIN APPLICATION
addappid(966770)

-- MAIN APP DEPOTS / PACKAGES
addappid(966771, 1, "4e5287e188b1db160d663bb86f68dfb5418faaf3f311b5f4760c5e344e3b8252")

