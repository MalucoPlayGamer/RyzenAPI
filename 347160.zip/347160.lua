-- Lua provided by RyzenAPI
-- Game: Steredenn: Binary Stars

-- MAIN APPLICATION
addappid(347160)

-- MAIN APP DEPOTS / PACKAGES
addappid(835730,0,"279949f4fe4206e13cfff20ddd5a5f14dd2651782d5c739794b42ebaa571bd6a")
addappid(835731,0,"65a0992e5e1f74b95e32cd992d8316a9a6a3d6f67c4fb9bbc59acecb84d3cfd3")
addappid(835732,0,"0c0f40da1154dd9893156fe0398eb839a8063190d611832e85e4fce9126da424")
addappid(835733,0,"2d9222878227a72fb3ffa2c533b6f828c723702920e096d96859ee915568efb7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
