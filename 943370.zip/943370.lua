-- Lua provided by RyzenAPI
-- Game: Bravery and Greed

-- MAIN APPLICATION
addappid(943370)
-- Game: addappid(943370)

-- MAIN APP DEPOTS / PACKAGES
addappid(943371, 1, "96a567d77dd49570c16752f5cb3c5fc47d2680dfe0a19fdc3682503a0d887318")
