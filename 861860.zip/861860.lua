-- Lua provided by RyzenAPI
-- Game: Doctor Tsunami

-- MAIN APPLICATION
addappid(861860)
-- Game: addappid(861860)

-- MAIN APP DEPOTS / PACKAGES
addappid(861861, 1, "cb99901d686421763eb9fd1b7e3903543ca6f0c503edea50205a10bd40009aba")
