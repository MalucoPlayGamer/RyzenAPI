-- Lua provided by RyzenAPI
-- Game: Automation* of Sorts

-- MAIN APPLICATION
addappid(1574020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574021, 1, "28d2d4f1712c37f1e3133f37dc7dfbd0306f82bee9cf821bdddce9dce4f75931")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
