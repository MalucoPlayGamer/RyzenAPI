-- Lua provided by RyzenAPI
-- Game: Automation* of Sorts

-- MAIN APPLICATION
addappid(1574020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574021, 1, "28d2d4f1712c37f1e3133f37dc7dfbd0306f82bee9cf821bdddce9dce4f75931")

