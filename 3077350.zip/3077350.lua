-- Lua provided by RyzenAPI
-- Game: 上古河图测试版

-- MAIN APPLICATION
addappid(3077350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077351, 1, "af68556c5102288c9e5da962138ef65ce8d629f9a4c744bfc8c3dd989360e413")
