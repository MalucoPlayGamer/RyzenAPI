-- Lua provided by RyzenAPI
-- Game: Game: Zeliria Sanctuary - Isle's Memories

-- MAIN APPLICATION
addappid(1181230)
-- Game: addappid(1181230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181231, 1, "fe5f6d9a67cbc8328ec6d2ad7ae1c6346c5490a46c68ff4457be1b03a9f26702")
