-- Lua provided by RyzenAPI
-- Game: NOLO HOME

-- MAIN APPLICATION
addappid(954350)
-- Game: addappid(954350)

-- MAIN APP DEPOTS / PACKAGES
addappid(954351, 1, "853d1786fe723c6222969adc5c0e27edae676db7a66270b3e3008575f6dc1b5b")
