-- Lua provided by RyzenAPI
-- Game: Lord Winklebottom Investigates

-- MAIN APPLICATION
addappid(1024160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024161, 1, "bbdf1aa7e82e0e1d7bececff72a809c8f512f97d9845c9bed4f3864ccd11a200")
