-- Lua provided by RyzenAPI
-- Game: Game: AppID 840850

-- MAIN APPLICATION
addappid(840850)
-- Game: addappid(840850)

-- MAIN APP DEPOTS / PACKAGES
addappid(840851, 1, "58f7b2f668397639350b90c708d3f196d78c737352b132f5145d67bb8b65f4da")
