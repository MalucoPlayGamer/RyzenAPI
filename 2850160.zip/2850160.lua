-- Lua provided by RyzenAPI
-- Game: Sophia the Traveler: Storybook

-- MAIN APPLICATION
addappid(2850160)
-- Game: addappid(2850160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850160,0,"c77f59c935620534e9e25307d7ab6a7d9e9349660f6bbaf4c8edce42fc419007")
