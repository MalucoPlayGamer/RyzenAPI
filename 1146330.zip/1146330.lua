-- Lua provided by RyzenAPI
-- Game: Virulent Addiction

-- MAIN APPLICATION
addappid(1146330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146331, 1, "3963cafe83d42612ab85ff7329b62be94f126bd69dbce94037a75bb75e42e507")
