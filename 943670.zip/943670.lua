-- Lua provided by RyzenAPI
-- Game: Contraverse

-- MAIN APPLICATION
addappid(943670)
-- Game: addappid(943670)

-- MAIN APP DEPOTS / PACKAGES
addappid(943671, 1, "a4077080e8fe5f923a899533beaa54e949f15890956fa17a3b3c3aa534d6d5b4")
