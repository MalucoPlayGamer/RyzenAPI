-- Lua provided by RyzenAPI
-- Game: Mega Knockdown

-- MAIN APPLICATION
addappid(1492750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492751, 1, "bec9d83ee7ca87f8a0d47e15c7fc384a1a80435462e1bef7480e88a158460372")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1932410)
addappid(3067270)
