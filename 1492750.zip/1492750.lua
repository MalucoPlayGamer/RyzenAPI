-- Lua provided by RyzenAPI
-- Game: addappid(1492750)

-- MAIN APPLICATION
addappid(1492750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492751, 1, "bec9d83ee7ca87f8a0d47e15c7fc384a1a80435462e1bef7480e88a158460372")
