-- Lua provided by RyzenAPI
-- Game: Mouse Pointer Engine

-- MAIN APPLICATION
addappid(2949260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949261, 1, "e2bc63e38eb39decbbdc4998eb7d5ff28022e0fb41eb6a24c24c43d5317a8f3c")
