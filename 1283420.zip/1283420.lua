-- Lua provided by RyzenAPI
-- Game: AppID 1283420

-- MAIN APPLICATION
addappid(1283420)
-- Game: addappid(1283420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283421, 1, "84556a853691c1720ddf0b0dd36cf732a834cecf99e6cdf2be5ac2daaf0e37bd")
