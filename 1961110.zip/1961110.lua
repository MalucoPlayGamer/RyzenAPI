-- Lua provided by RyzenAPI
-- Game: 依依 Soundtrack

-- MAIN APPLICATION
addappid(1961110)
-- Game: addappid(1961110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961111, 1, "41bd75039efdedf4fe00fec40d68548627a004b6b30c27c2c86006bd695a1670")
addappid(1961112, 1, "3314a11e528166efd1126705014c949abc96a3c5bed69db2c1e961e3e3225885")
