-- Lua provided by RyzenAPI
-- Game: Game: Sable Maze: Twelve Fears Collector's Edition

-- MAIN APPLICATION
addappid(941050)
-- Game: addappid(941050)

-- MAIN APP DEPOTS / PACKAGES
addappid(941051, 1, "fc9432b8693d7261c04bd8f16a5c27063d8a1d44905d0dd55e45c10dcd0b73c4")
