-- Lua provided by RyzenAPI
-- Game: Game: The DioField Chronicle Digital Artbook

-- MAIN APPLICATION
addappid(1982540)
-- Game: addappid(1982540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982541, 1, "4b038b4b7396d05662b8d07c6d2327802f0bc26119e1fbf8c48a98dff5eac8b1")
