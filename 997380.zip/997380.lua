-- Lua provided by RyzenAPI
-- Game: 997380

-- MAIN APPLICATION
addappid(997380)
addappid(997381)
addappid(997382)
-- Game: addappid(997380)

-- MAIN APP DEPOTS / PACKAGES
addappid(997384,0,"08020fdbd6e67b6f58ccc58018af69c777cd52b200b585828d9e9eadc164d595")
