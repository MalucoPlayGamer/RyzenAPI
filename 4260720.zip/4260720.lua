-- Lua provided by RyzenAPI
-- Game: EmuDevz

-- MAIN APPLICATION
addappid(4260720)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4283970)
