-- Lua provided by RyzenAPI
-- Game: EmuDevz

-- MAIN APPLICATION
addappid(4260720)
