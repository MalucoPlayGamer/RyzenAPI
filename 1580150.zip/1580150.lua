-- Lua provided by RyzenAPI
-- Game: Between Time: Escape Room

-- MAIN APPLICATION
addappid(1580150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1580151, 1, "9c35b60ba3d968ad7c470ca39c7b8eef9b4a5c395ffcb1da5c0f08e163cb1dc6")
