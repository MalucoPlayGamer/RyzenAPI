-- Lua provided by RyzenAPI
-- Game: MY DIRECT DAMAG 7 TRILLION

-- MAIN APPLICATION
addappid(3073470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3073471, 1, "c719f32fef339539e4051c2f79bfd6e4c527e12da904f0f2b162f47bd97bc776")

