-- Lua provided by RyzenAPI
-- Game: addappid(3073470)

-- MAIN APPLICATION
addappid(3073470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073471, 1, "c719f32fef339539e4051c2f79bfd6e4c527e12da904f0f2b162f47bd97bc776")
