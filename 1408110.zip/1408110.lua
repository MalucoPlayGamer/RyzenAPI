-- Lua provided by RyzenAPI 
-- Game: The Grounding
addappid(1408110)
addappid(1408111, 1, "585cda5eb3721fb13f8cf9b2c61169ddf1dc37873d4cb5dd95aff90efa0d9206")
