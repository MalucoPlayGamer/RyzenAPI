-- Lua provided by RyzenAPI
-- Game: 3179110

-- MAIN APPLICATION
addappid(3179110)
-- Game: addappid(3179110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179111, 1, "453dcd998e9b3a23203649c71b7ebc230b299afb3d7d235ad152302d512c6a47")
