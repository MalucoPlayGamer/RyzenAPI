-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(956762)

-- MAIN APP DEPOTS / PACKAGES
addappid(956762,0,"7453ac3827589a51c8550fdb4ead2ac1fb46473d729510fc3edb131d9dacf059")
