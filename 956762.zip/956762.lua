-- Lua provided by RyzenAPI
-- Game: addappid(956762)

-- MAIN APPLICATION
addappid(956762)

-- MAIN APP DEPOTS / PACKAGES
addappid(956762,0,"7453ac3827589a51c8550fdb4ead2ac1fb46473d729510fc3edb131d9dacf059")
