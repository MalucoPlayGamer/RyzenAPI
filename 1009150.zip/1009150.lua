-- Lua provided by RyzenAPI
-- Game: Choconoa

-- MAIN APPLICATION
addappid(1009150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1009151, 1, "27962d89c27dba0b4eee6e4aa01c3027a1fcd9e40181727e85244fbdd6347a90")
