-- Lua provided by RyzenAPI
-- Game: AppID 1009150

-- MAIN APPLICATION
addappid(1009150)
-- Game: addappid(1009150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009151, 1, "27962d89c27dba0b4eee6e4aa01c3027a1fcd9e40181727e85244fbdd6347a90")
