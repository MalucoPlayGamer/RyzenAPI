-- Lua provided by RyzenAPI
-- Game: addappid(421960)

-- MAIN APPLICATION
addappid(421960)

-- MAIN APP DEPOTS / PACKAGES
addappid(421961, 1, "cecce0ad383c44c8463cf93c8693d579219c8e32bfed62424dd26a157518d125")
