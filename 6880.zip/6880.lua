-- Lua provided by RyzenAPI
-- Game: Just Cause

-- MAIN APPLICATION
addappid(6880)

-- MAIN APP DEPOTS / PACKAGES
addappid(6881, 1, "5854f390d81e64dc72091523232293ffb12c407c5eb2f0df69ab84365e228bed")
addappid(6882, 1, "2858a892836ccf45daae357327e1929281dd29fab8e5c703f600eb0688a995ce")
addappid(6883, 1, "704d286e39fdcb270349e458bfe8eaab4eb0ab17bf687a712c8fc5e6789e5183")
addappid(6884, 1, "460b5da345151d48b476733b8e2fc045287d85cc5c36277ea7fddfb52688cacc")
addappid(6885, 1, "2d23a59611ccbd91d8c86d82c591ec4080f01235ea42023f22f6e94f47886ecc")
addappid(6886, 1, "7e9920847b07a10a686aaec3522bbb4c34822edc3068be79d2c3c5f2ea1da190")
addappid(6887, 1, "cf92a31f74cfdfb172df990a4b8e59c1024449e9229e9f7ce7b9c6b371fc8adf")
addappid(6888, 1, "1075edc75ea1aac5e20b6fe0dfefa1848ba943b1c8ca7a6c3b3c27019e59b51f")
addappid(6889, 1, "346df249f423b2d2ca05ab46aebd6609ff0a240a9f4e474ff65d11c713b49da3")
addappid(6890, 1, "a1636158c174a3b1efc8ebc74869b8e05388712895d8a1edbd7611d44e0118e8")
addappid(6891, 1, "ed9f31e9515ff0cdfba17a2afe3813426686d599426a9f4a9187ebb70471f5e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
