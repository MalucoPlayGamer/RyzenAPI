-- Lua provided by RyzenAPI
-- Game: 466940

-- MAIN APPLICATION
addappid(466940)
addappid(555770)
-- Game: addappid(466940)

-- MAIN APP DEPOTS / PACKAGES
addappid(466941, 1, "0727b2cc54ca553591c27db99b2ea977e3b9d8ad9dd428f2b9535fd8a0594276")
