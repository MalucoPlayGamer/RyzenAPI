-- Lua provided by RyzenAPI
-- Game: AppID 520080

-- MAIN APPLICATION
addappid(520080)
-- Game: addappid(520080)

-- MAIN APP DEPOTS / PACKAGES
addappid(520081, 1, "0a7d01ef844e90eb76ae7aea4e25bdbfd7fac9f69236b71b88aa5ea5b8368d03")
