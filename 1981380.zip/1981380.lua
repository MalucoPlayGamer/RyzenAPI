-- Lua provided by RyzenAPI
-- Game: Static of Eve –凝滯聖夜–

-- MAIN APPLICATION
addappid(1981380)
-- Game: addappid(1981380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981381, 1, "9c2251c8a732b17e5fa57ca058dc880023a06210cd369d5afb86846076c71dd1")
