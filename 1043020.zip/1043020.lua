-- Lua provided by RyzenAPI
-- Game: Dust On Wheels

-- MAIN APPLICATION
addappid(1043020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043021, 1, "9f0fc8fadb95903da4f75dbc3b3a074223cf7939cbae55accb4fc7e7959e918b")
