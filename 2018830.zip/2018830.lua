-- Lua provided by RyzenAPI
-- Game: addappid(2018830)

-- MAIN APPLICATION
addappid(2018830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018831, 1, "ecf3751fe80fc1053e3fe2ad7010809297f03a3d7e34fba3803edfd21f2821b1")
