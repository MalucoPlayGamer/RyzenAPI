-- Lua provided by RyzenAPI
-- Game: Twin Cores

-- MAIN APPLICATION
addappid(2018830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2018831, 1, "ecf3751fe80fc1053e3fe2ad7010809297f03a3d7e34fba3803edfd21f2821b1")

