-- Lua provided by RyzenAPI
-- Game: 928940

-- MAIN APPLICATION
addappid(928940)
-- Game: addappid(928940)

-- MAIN APP DEPOTS / PACKAGES
addappid(928941, 1, "edaa9099cdd21a75a5c6f09965b7ca065515da6fecf15fe4979898d121955095")
