-- Lua provided by RyzenAPI
-- Game: Code Name: Operation Dawn

-- MAIN APPLICATION
addappid(2549270)
addappid(2609970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549271, 1, "f642841a6d4b6172ebe64413349894eaa123607849e19258c5f40e2ec926acb0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2549460)
addappid(2663980)
