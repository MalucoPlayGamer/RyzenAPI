-- Lua provided by RyzenAPI
-- Game: Code Name: Operation Dawn

-- MAIN APPLICATION
addappid(2549270)
addappid(2609970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549271, 1, "f642841a6d4b6172ebe64413349894eaa123607849e19258c5f40e2ec926acb0")
