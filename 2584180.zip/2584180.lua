-- Lua provided by RyzenAPI
-- Game: My Friend Aki

-- MAIN APPLICATION
addappid(2584180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584181, 1, "b222a4c1895b843314a63a0ad2b2504eb10241583d0ccd410bf19dc59630bd10")
