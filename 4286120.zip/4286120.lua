-- Lua provided by RyzenAPI
-- Game: Photomaly

-- MAIN APPLICATION
addappid(4286120)

-- MAIN APP DEPOTS / PACKAGES
addappid(4286121,0,"8ba184028e7c93e71bf1be655408324148b30e3f1201b728dc7dbac93a581fe1")

