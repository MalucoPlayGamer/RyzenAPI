-- Lua provided by RyzenAPI
-- Game: 2761570

-- MAIN APPLICATION
addappid(2761570)
-- Game: addappid(2761570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761571, 1, "2ba0fc9f31d6320e7a7dc80ea7c85fdc92fa3f8d2bec09a2fb9b1a3ddc56086b")
