-- Lua provided by RyzenAPI
-- Game: Lust in Space 🔞🪐

-- MAIN APPLICATION
addappid(3094840)
-- Game: addappid(3094840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3094841, 1, "138476d78444dc6764a51c71f3f93f260218587f7c9e3c63465cfb71bb36e852")
