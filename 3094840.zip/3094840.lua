-- Lua provided by SkyAPI 
-- Game: Lust in Space 🔞🪐
addappid(3094840)
addappid(3094841, 1, "138476d78444dc6764a51c71f3f93f260218587f7c9e3c63465cfb71bb36e852")
