-- Lua provided by RyzenAPI
-- Game: Game: Medieval Blacksmith

-- MAIN APPLICATION
addappid(2732100)
-- Game: addappid(2732100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732101, 1, "38704e2fd44e659e159e1ade284b1533dc0d2323e3392f8fbfc38b8d01ad83a8")
