-- Lua provided by RyzenAPI
-- Game: 1229090

-- MAIN APPLICATION
addappid(1229090)
-- Game: addappid(1229090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229091, 1, "82460fc916131f754c7b4ac822708b35a46dc7ae6be2af84b25310a38d9e955e")
