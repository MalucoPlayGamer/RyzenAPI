-- Lua provided by RyzenAPI
-- Game: Game: Undertale

-- MAIN APPLICATION
addappid(391540)
addappid(391570)
-- Game: addappid(391540)

-- MAIN APP DEPOTS / PACKAGES
addappid(391541, 1, "b416ce2b64256c530f83775eef790b171047ce48c3795077ebcfd83f9c627cab")
addappid(391542, 1, "6b3c4e270f515da237a568230e441e3a28a5984fa2a9224c31b6c3c825ca44fd")
addappid(391544, 1, "ba1155a879c71e2f624fe2fe74a0ac1baf68e199cc84e32e507c4c737299d92b")
