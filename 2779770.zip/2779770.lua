-- Lua provided by RyzenAPI
-- Game: 2779770

-- MAIN APPLICATION
addappid(2779770)
-- Game: addappid(2779770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779771, 1, "fa7c35cd84567aedfd653d1f2f7eb57c707e388d8f312a0228f9d165df5f8905")
