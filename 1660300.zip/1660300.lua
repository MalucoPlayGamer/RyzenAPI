-- Lua provided by RyzenAPI
-- Game: Ultimate Physical Wrestling

-- MAIN APPLICATION
addappid(1660300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660301, 1, "d15ff00acfb716b3b5bcf0c7e44b2b5bd0d220c3c33e848cf2bb12a289641fa4")
