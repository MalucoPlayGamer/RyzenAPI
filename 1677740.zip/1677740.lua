-- Lua provided by RyzenAPI
-- Game: 1677740

-- MAIN APPLICATION
addappid(1677740)
-- Game: addappid(1677740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1677741, 1, "3152088e05159ee3cea8d9df19cc0916ddbcbf1d572bfce0cf5936c658bbc2e2")
