-- Lua provided by RyzenAPI
-- Game: Game: Warlord

-- MAIN APPLICATION
addappid(2219410)
-- Game: addappid(2219410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219411, 1, "2d7792e7c32a9a439f43042b8cfed8d383f025f74ac7ca2b806197499870ac8e")
