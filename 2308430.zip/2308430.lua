-- Lua provided by RyzenAPI
-- Game: Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.10「永劫会事件」

-- MAIN APPLICATION
addappid(2308430)
-- Game: addappid(2308430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308431, 1, "651db18623298926f2195829096db889809d1d66f5b15de19414f59a77414b49")
