-- Lua provided by RyzenAPI
-- Game: addappid(518920)

-- MAIN APPLICATION
addappid(518920)

-- MAIN APP DEPOTS / PACKAGES
addappid(518921, 1, "e7a6b03ece938c3fdca226ba4d7182f859e16ac17d0fd3a2dcecdae1d344accd")
