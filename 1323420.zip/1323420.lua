-- Lua provided by RyzenAPI 
-- Game: H-SNIPER: World War II
addappid(1323420)
addappid(1323421, 1, "10520fed14ca3ea3920346ca2bd1f6f40004a988b4e478fe3efce7c19b657809")
addappid(1346910)
