-- Lua provided by RyzenAPI
-- Game: Game: Escape Toon Kingdom

-- MAIN APPLICATION
addappid(3198360)
-- Game: addappid(3198360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198361, 1, "a67e283210b3288e744e1efcdd7978703c13e751fc2cea3e99cef188f9092b80")
