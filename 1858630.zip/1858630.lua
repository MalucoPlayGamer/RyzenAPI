-- Lua provided by RyzenAPI
-- Game: SWORD ART ONLINE Fractured Daydream

-- MAIN APPLICATION
addappid(1858630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858631, 1, "21adba4e332aa48b0f8834b0896bc582f7132947f62dd148cd8d5a3f1df6cfee")
addappid(2387391, 0, "0b159382f281cad0e7b1c810c1dce8d0c7265e096706792f5e90920a8c92bfe1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2877820)
addappid(2877830)
addappid(2877840)
addappid(2939660)
addappid(2985460)
addappid(3037270)
addappid(3037280)
addappid(3047110)
addappid(3047120)
addappid(3300980)
addappid(3428460)
addappid(3428470)
