-- Lua provided by SkyAPI 
-- Game: SWORD ART ONLINE Fractured Daydream
addappid(1858630)
addappid(1858631, 1, "21adba4e332aa48b0f8834b0896bc582f7132947f62dd148cd8d5a3f1df6cfee")
addappid(2387391, 0, "0b159382f281cad0e7b1c810c1dce8d0c7265e096706792f5e90920a8c92bfe1")
