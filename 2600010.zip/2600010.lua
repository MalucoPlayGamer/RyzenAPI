-- Lua provided by RyzenAPI
-- Game: Earthless Demo

-- MAIN APPLICATION
addappid(2600010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600011, 1, "5380f23f8a71ee62599441e0f1e686e95224baf535d54c9cec5a3f6c699c2e27")
