-- Lua provided by SkyAPI 
-- Game: AppID 1651350
addappid(1651350)
addappid(1651351, 1, "a66459daaa9d4d62e847e272782a1c16171a17848f67862098353a2e55aadc54")
