-- Lua provided by RyzenAPI
-- Game: Game: AppID 1651350

-- MAIN APPLICATION
addappid(1651350)
-- Game: addappid(1651350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651351, 1, "a66459daaa9d4d62e847e272782a1c16171a17848f67862098353a2e55aadc54")
