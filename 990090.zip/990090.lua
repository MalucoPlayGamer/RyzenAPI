-- Lua provided by RyzenAPI
-- Game: The Dandelion Girl: Don't You Remember Me?

-- MAIN APPLICATION
addappid(990090)

-- MAIN APP DEPOTS / PACKAGES
addappid(990091, 1, "992c63a3b0a97b7770db643d02b691349326dddd94bf06089694485a22fe0af4")

