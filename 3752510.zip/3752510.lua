-- Lua provided by RyzenAPI
-- Game: 3752510

-- MAIN APPLICATION
addappid(3752510)
-- Game: addappid(3752510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3752511, 1, "6b8cb4dee36e1ffd781fb216b74e7fb5b947319421acc0dcf7d74dc43072fdcf")
