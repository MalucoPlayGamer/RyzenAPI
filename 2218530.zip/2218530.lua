-- Lua provided by RyzenAPI
-- Game: 2218530

-- MAIN APPLICATION
addappid(2218530)
-- Game: addappid(2218530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218530,0,"6ff451301fdc04016a02e4beb1b7ef8b956f17d00e1c80d9fc40546d7c3c3e49")
