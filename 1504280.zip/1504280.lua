-- Lua provided by RyzenAPI
-- Game: CyberHook Level Editor

-- MAIN APPLICATION
addappid(1504280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504281, 1, "d8f81095d15fee7516fa52a5ceffbd028fa16b3fc7cc29907871345cdaa00082")
