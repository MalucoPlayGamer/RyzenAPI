-- Lua provided by RyzenAPI
-- Game: Game: AppID 1183940

-- MAIN APPLICATION
addappid(1183940)
-- Game: addappid(1183940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183941, 1, "37727a6167f8734084f825ab095851f05369b8a3f42d3aa8bdb4f94c5ab25375")
