-- Lua provided by RyzenAPI
-- Game: My Dear Frankenstein

-- MAIN APPLICATION
addappid(1550460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550461, 1, "4aa5564fc6766463f1f95d922223cb21f49a92b47e87e9f9dbf8df3b3fa4cfab")
