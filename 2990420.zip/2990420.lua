-- Lua provided by RyzenAPI
-- Game: Game: The Void Project: Demo

-- MAIN APPLICATION
addappid(2990420)
-- Game: addappid(2990420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990421, 1, "b72ff5bce4c47c11f91e0e7be4cc131fda4c0af19d2b68942417e7cbc46cf816")
