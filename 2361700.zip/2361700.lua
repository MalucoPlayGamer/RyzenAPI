-- Lua provided by RyzenAPI
-- Game: Game: Destiny Star Girlfriend

-- MAIN APPLICATION
addappid(2361700)
-- Game: addappid(2361700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361701, 1, "509a000db18a96cee8bc893aa1de7432e25c0e8c16761ee86bcedccd26a66124")
