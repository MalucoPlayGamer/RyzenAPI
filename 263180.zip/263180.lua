-- Lua provided by RyzenAPI
-- Game: Squirt's Adventure

-- MAIN APPLICATION
addappid(263180)

-- MAIN APP DEPOTS / PACKAGES
addappid(263181, 1, "064ad12757614322ce1dbb48c80cada0425c56aa01a319ac26ad77a85a1fe408")
addappid(263182, 1, "ab726350d70b5178e021ae773bc3109754585d05756f420bd7185f737beee014")
