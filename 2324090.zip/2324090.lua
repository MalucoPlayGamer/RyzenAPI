-- Lua provided by RyzenAPI
-- Game: VRHandsFrame

-- MAIN APPLICATION
addappid(2324090)
-- Game: addappid(2324090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324091, 1, "9a7809ed206c1931f812d5c41a3e5159493b17a284755f2f95d17564667cae4a")
