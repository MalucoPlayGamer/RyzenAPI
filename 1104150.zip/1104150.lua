-- Lua provided by SkyAPI 
-- Game: Ashi
addappid(1104150)
addappid(1104151, 1, "a114eb47cd23fe52016ed3d62a1fc09c778f4be4c4c25fb75b89172bd7e9ee67")
