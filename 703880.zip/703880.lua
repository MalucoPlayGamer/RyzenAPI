-- Lua provided by RyzenAPI
-- Game: Game: AppID 703880

-- MAIN APPLICATION
addappid(703880)
-- Game: addappid(703880)

-- MAIN APP DEPOTS / PACKAGES
addappid(703881, 1, "f52ae4286eb9391105a2fa721e502e44a14f6ac221d506f9da516177549a9b32")
addappid(969090, 0, "f576f7491e5d6db7a82a6d6d1c833d408b9732c83d4b931d37fda5999f2351de")
addappid(973870, 0, "0cd46c35ea59f6c5c14de6ca66fec2556f6a96bbccc93586167cc3dddf92c280")
