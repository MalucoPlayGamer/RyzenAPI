-- Lua provided by RyzenAPI
-- Game: Swords and Soldiers 2 Shawarmageddon

-- MAIN APPLICATION
addappid(703880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(703881, 1, "f52ae4286eb9391105a2fa721e502e44a14f6ac221d506f9da516177549a9b32")
addappid(969090, 0, "f576f7491e5d6db7a82a6d6d1c833d408b9732c83d4b931d37fda5999f2351de")
addappid(973870, 0, "0cd46c35ea59f6c5c14de6ca66fec2556f6a96bbccc93586167cc3dddf92c280")

