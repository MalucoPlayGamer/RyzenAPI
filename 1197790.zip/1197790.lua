-- Lua provided by RyzenAPI
-- Game: Arcade Attack Anthology

-- MAIN APPLICATION
addappid(1197790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197791, 1, "a7a56531dc9bdc6b44122e4378416f5ad44019a7ff440d1c395ebc9c1d9e98cf")
