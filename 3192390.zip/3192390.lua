-- Lua provided by RyzenAPI
-- Game: 3192390

-- MAIN APPLICATION
addappid(3192390)
-- Game: addappid(3192390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192391, 1, "2be5305cd2d8c98a8a153c60e9309732db3a87a58fd0d035a4653c8a5e631c7d")
