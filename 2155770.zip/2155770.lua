-- Lua provided by RyzenAPI
-- Game: addappid(2155770)

-- MAIN APPLICATION
addappid(2155770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155771, 1, "c58585cf9577d1828528fb4d9d059dda12cf559ed3e1250672c004ab92aa5319")
