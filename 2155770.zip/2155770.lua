-- Lua provided by RyzenAPI
-- Game: THE MULLER-POWELL PRINCIPLE

-- MAIN APPLICATION
addappid(2155770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155771, 1, "c58585cf9577d1828528fb4d9d059dda12cf559ed3e1250672c004ab92aa5319")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
