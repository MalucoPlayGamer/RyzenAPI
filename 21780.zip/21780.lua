-- Lua provided by SkyAPI 
-- Game: Driver® Parallel Lines
addappid(21780)
addappid(21781, 1, "5c5cc177ff9116fb0a8434303ac373526eade3d36a21eb52c7c16b774f551c43")
addappid(21782, 1, "2e492096da1aaedaea2c53f37f9837e209c2f0aafbb4bf384901da3e6f938dad")
addappid(21783, 1, "2ee7aa77a84673cf50feddeb447358e34d5d939f66ff5f67b17014e1d3ff5664")
addappid(21784, 1, "a6198370fc97d5bfa826217d866eb37d580facafbb934eb9ac93bc3d35591b4b")
addappid(21785, 1, "c56c979b4fe9e6665733b3edc1b4c68a129309f2c985708a559b1752ade54ad3")
