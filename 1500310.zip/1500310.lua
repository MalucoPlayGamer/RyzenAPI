-- Lua provided by RyzenAPI
-- Game: Choco Pixel D

-- MAIN APPLICATION
addappid(1500310)
-- Game: addappid(1500310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500311, 1, "9c707fcfdb851c0b840b98a7d6e12be81b3565ce1ce0a09bcd3ef69130a3b2fa")
