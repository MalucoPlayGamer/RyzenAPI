-- Lua provided by RyzenAPI
-- Game: 1441950

-- MAIN APPLICATION
addappid(1441950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441950,0,"613287896ffd9ec780baf8ac50769c3f41fa1157bf1662b9ddbda1c9efe9e9a2")

