-- Lua provided by SkyAPI 
-- Game: Football Coach: College Dynasty
addappid(2151290)
addappid(2151291, 1, "4510fce6947cb8c25d77ebf3aa7a8883594265d1f4ed82ba98b2e062caa1687c")
