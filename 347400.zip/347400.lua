-- Lua provided by RyzenAPI
-- Game: 001 Game Creator: 2025 Edition

-- MAIN APPLICATION
addappid(347400)

-- MAIN APP DEPOTS / PACKAGES
addappid(347401, 1, "3b7940247a68bcd03fe6fea16b52132e6250e07b85edfef9405a0c795602e92b")
addappid(564680, 0, "c66ce3b05b7aa7153bc95ae07ddf476de5e5e26e54ce290f19a11c615523f9c3")
addappid(736530, 0, "3e9fb9fe6a41dae472667a1bb0afdde455985b41dd274ae75077599c7273ab12")
