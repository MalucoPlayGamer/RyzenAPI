-- Lua provided by RyzenAPI
-- Game: Simu V3

-- MAIN APPLICATION
addappid(4300530)

-- MAIN APP DEPOTS / PACKAGES
addappid(4300530,0,"9c6df7783969ce4d0166789e1e68ea552e7b60971952415cae1c85c1be85c074")
addappid(4300531,0,"a1ed21159442674a3644db5a5d3cb6c8dd270071f313996ad2aa56f0687cfd90")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
