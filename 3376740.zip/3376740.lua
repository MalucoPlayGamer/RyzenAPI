-- Lua provided by RyzenAPI
-- Game: Game: Myrmidon Demo

-- MAIN APPLICATION
addappid(3376740)
-- Game: addappid(3376740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376741, 1, "ad8ae34e7e76205b403905fddc83515defae12a7e8c1ebdd7d52faf5ebc1b126")
