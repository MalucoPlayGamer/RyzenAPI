-- Lua provided by RyzenAPI 
-- Game: Hacker Simulator: Free Trial
addappid(1828100)
addappid(1828101, 1, "abd734f2b0f63cca78c34c32f93713a49bd6f8fc44865a84f5b8bba4c8f1cb30")
