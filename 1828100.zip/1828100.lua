-- Lua provided by RyzenAPI
-- Game: 1828100

-- MAIN APPLICATION
addappid(1828100)
-- Game: addappid(1828100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828101, 1, "abd734f2b0f63cca78c34c32f93713a49bd6f8fc44865a84f5b8bba4c8f1cb30")
