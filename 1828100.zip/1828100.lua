-- Lua provided by RyzenAPI
-- Game: Hacker Simulator: Free Trial

-- MAIN APPLICATION
addappid(1828100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1828101, 1, "abd734f2b0f63cca78c34c32f93713a49bd6f8fc44865a84f5b8bba4c8f1cb30")

