-- Lua provided by RyzenAPI
-- Game: Rainbow Cattle

-- MAIN APPLICATION
addappid(3666080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3666081, 1, "2003165a1a7c57a2d995eff24b0032614a897e72dc97b96b169aa3edd60b5792")

