-- Lua provided by RyzenAPI
-- Game: Kingdom Of Peace Soundtrack

-- MAIN APPLICATION
addappid(3131920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3131921, 1, "45f3b09065da01d46f9135a566c9f610539587e06e6566756eb927c18b9c225c")
