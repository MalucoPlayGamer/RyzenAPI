-- Lua provided by RyzenAPI
-- Game: The Housewife

-- MAIN APPLICATION
addappid(496750)
-- Game: addappid(496750)

-- MAIN APP DEPOTS / PACKAGES
addappid(496751, 1, "590e0d69a78594c087321022c0ee9768aaed3b447822bb63d906c04f3a401fc7")
