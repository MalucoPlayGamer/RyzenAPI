-- Lua provided by RyzenAPI 
-- Game: Slay The Bigies
addappid(1203810)
addappid(1203811, 1, "a76bd3a6e22deeb1c80866582d9c70f090db3e308e5043cb9d15ab9bd5109620")
addappid(1271231, 0, "95a232e0b8b68d6f14fead2eb264ed97252e6e89798b71dcb90b72e6abbf396e")
addappid(1271240, 0, "f8a955980cdd982fcc7f769e558d246990368bdc2900cdb6629c5c90036f1ca2")
