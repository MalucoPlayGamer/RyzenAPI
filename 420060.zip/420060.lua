-- Lua provided by RyzenAPI
-- Game: Candle

-- MAIN APPLICATION
addappid(420060)
addappid(537210)

-- MAIN APP DEPOTS / PACKAGES
addappid(420061, 1, "a1c4563aabe941f1faa4099011b5e7c616f2f6447a8a9fdd38130e9c3590327a")
addappid(420062, 1, "78bf38fbe7884e5d1df509b29ac3a5847e2db7396f871d8c65b695adae572445")
addappid(420063, 1, "b75d0decbafbafb6c674727f1934bbaf8b64b9d2522025fbf0eadbaadba40c64")
