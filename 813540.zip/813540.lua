-- Lua provided by RyzenAPI
-- Game: Game: AppID 813540

-- MAIN APPLICATION
addappid(813540)
-- Game: addappid(813540)

-- MAIN APP DEPOTS / PACKAGES
addappid(813541, 1, "5454c6bd101d0eb4a25fd41058579e33c48939ea0e2936d0ed38c0ca8679108f")
addappid(813542, 1, "6dfbcd2a59ec3177a6adbfe069fae9f5562981e314135c3957e2e21bb5f7b7d0")
