-- Lua provided by RyzenAPI
-- Game: We Were Here: Original Soundtrack

-- MAIN APPLICATION
addappid(721410)
addappid(721411)

-- MAIN APP DEPOTS / PACKAGES
addappid(721410,0,"f3963ba19878ba9049a919f10aab856954ee4e9735167299e1fc567eeedd077b")

