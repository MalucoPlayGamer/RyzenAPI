-- Lua provided by RyzenAPI
-- Game: AppID 1977920

-- MAIN APPLICATION
addappid(1977920)
-- Game: addappid(1977920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977921, 1, "976bd6cf0e23f20be70a5630893b93d15ec10a63776f7c956e656df7c931adf4")
