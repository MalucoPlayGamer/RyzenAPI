-- 4383880's Lua and Manifest Created by Hubcap Manifest
-- HuntinBuddies
-- Created: July 25, 2026 at 14:19:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4383880) -- HuntinBuddies
-- MAIN APP DEPOTS
addappid(4383881, 1, "d2dd90f7bebe74d7ef50f64af9dc585da72ad3a9c451fc96cb5979d4040fc118") -- Depot 4383881
setManifestid(4383881, "441317011689853851", 5486084946)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)