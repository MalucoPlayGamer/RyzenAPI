-- Lua provided by RyzenAPI
-- Game: Game: The Cooking Game VR

-- MAIN APPLICATION
addappid(857180)
-- Game: addappid(857180)

-- MAIN APP DEPOTS / PACKAGES
addappid(857181, 1, "58bec056c91b22e1b29d1b79f5a7c4ab24c7999e3f3ce00edcb42f67c394f15a")
