-- Lua provided by SkyAPI 
-- Game: AppID 3091440
addappid(3091440)
addappid(3091441, 1, "fabe9331c0dfd543a9b4d8bc4103f9096c28f8cdd0f8e2d1eb369c823a0811fb")
