-- Lua provided by RyzenAPI
-- Game: addappid(3091440)

-- MAIN APPLICATION
addappid(3091440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3091441, 1, "fabe9331c0dfd543a9b4d8bc4103f9096c28f8cdd0f8e2d1eb369c823a0811fb")
