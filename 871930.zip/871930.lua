-- Lua provided by RyzenAPI
-- Game: Gladiabots

-- MAIN APPLICATION
addappid(871930)
addappid(914280)
addappid(1287320)
addappid(1287321)
addappid(1287322)
addappid(1287323)
addappid(1287324)

-- MAIN APP DEPOTS / PACKAGES
addappid(871931,0,"61aee1c1f9e751d0f5719602b31ca9e4efab975e54f182c108a9f6b14e9f664a")
addappid(871932,0,"ca817de7fd55b521b0a38ad08fa12970c7a0e3f9af4acb88d187da7b00b1285a")
addappid(871933,0,"88f09e2c754c5621d9adf3b543756dd09c9ac619dffab09326997da5c9b68a56")
addappid(871934,0,"18f433c9f97241b6b5ee2e14bd404174e130a36d5b0cb70b1feb447999512212")
addappid(914280,0,"525aa6866fbe6d669096331649faf184ea68a10bf57d19e9c1bb89f274b8b71c")

