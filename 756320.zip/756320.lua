-- Lua provided by RyzenAPI
-- Game: 756320

-- MAIN APPLICATION
addappid(756320)
addappid(852200)
-- Game: addappid(756320)

-- MAIN APP DEPOTS / PACKAGES
addappid(756321, 1, "b1479fd780c1c96b5df60c32021da1b721b75209839b0273c466d9cf58a074a6")
