-- Lua provided by RyzenAPI
-- Game: Crazy Buggy Racing

-- MAIN APPLICATION
addappid(610780)

-- MAIN APP DEPOTS / PACKAGES
addappid(610781, 1, "46abf5cebbda74a9afaba38e8aaf55b255f3681557435c658a6e24e7985c1663")
addappid(622390, 0, "a4d3fdeaee79285c724c05a71e4245643f9e2cda100332040331de280c5436b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
