-- Lua provided by RyzenAPI
-- Game: Game: Crazy Buggy Racing

-- MAIN APPLICATION
addappid(610780)
-- Game: addappid(610780)

-- MAIN APP DEPOTS / PACKAGES
addappid(610781, 1, "46abf5cebbda74a9afaba38e8aaf55b255f3681557435c658a6e24e7985c1663")
addappid(622390, 0, "a4d3fdeaee79285c724c05a71e4245643f9e2cda100332040331de280c5436b3")
