-- Lua provided by SkyAPI 
-- Game: Escape Dinosaur Island
addappid(1417400)
addappid(1417401, 1, "86c6213a2ebb55ac01ed08a9128120959fb0195c03d24595846e52c47c67e1ac")
