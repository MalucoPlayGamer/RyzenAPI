-- Lua provided by RyzenAPI
-- Game: Escape Dinosaur Island

-- MAIN APPLICATION
addappid(1417400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417401, 1, "86c6213a2ebb55ac01ed08a9128120959fb0195c03d24595846e52c47c67e1ac")
