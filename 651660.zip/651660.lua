-- Lua provided by RyzenAPI
-- Game: Halcyon 6: Lightspeed Edition

-- MAIN APPLICATION
addappid(651660)
addappid(782270)

-- MAIN APP DEPOTS / PACKAGES
addappid(651661, 1, "5668704a2f2261f398c58535c12b5deea94a4334514f00ea4d01862e62b46c9a")
addappid(651662, 1, "defb58d61670deb7c57973a58d5f9d2edbfad70ca912b27d5ea3377cdfdc5150")
addappid(651663, 1, "dcd7ef5957b71dd3d44bb3de5493e12256315c404440053f0c385318cd3263ab")
addappid(651664, 1, "d45c6e42228f6b83fc5904c8d1dbb1db66174139687982496f2957e1c7e1184f")
addappid(677640, 0, "804c25fd5dfa6bd65bb4c2ad1f0d3475eab4da20ba448786e2c58cb32e6a02f2")
addappid(706910, 0, "d4a7f0cca7c4a9d75d5b31db4a79250ac6df3d510146b1dbe5c098c98102dfbf")
addappid(782271, 0, "a29eee3d16e7d48253c532f57c353baf7644e5c9f42fd282b670dd8bf2e43428")
addappid(782272, 0, "93e25eeaaa7d77ac2d346197bec5a22ccb5a17f44a8a1a4bbe39bb297fe3b8d4")
addappid(782273, 0, "a2bd4c835b8995f2bfe2687a5a57c00b4be92a3d58099e42620104f70ec4cfbb")
