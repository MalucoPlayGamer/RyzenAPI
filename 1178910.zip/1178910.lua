-- Lua provided by RyzenAPI
-- Game: addappid(1178910)

-- MAIN APPLICATION
addappid(1178910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178910,0,"144c5c75f5c63a27b1ef26a4be9914d45738feba60c0cae3732c78c67aeefd23")
