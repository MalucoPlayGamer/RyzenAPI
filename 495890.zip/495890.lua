-- Lua provided by RyzenAPI
-- Game: Game: AppID 495890

-- MAIN APPLICATION
addappid(495890)
-- Game: addappid(495890)

-- MAIN APP DEPOTS / PACKAGES
addappid(495891, 1, "012fbb5f5e2a1bc6836c6a3b64a251c26963735ac0fe0d370f4efac0be7e0c0d")
addappid(495894, 1, "af5f21e3a7939a5016e820d9135a1c97e6314b68ab6dbed200591fd148d2131b")
addappid(495895, 1, "791f954be6c0bd7e1018cb3223dfb6206a4ac55cc2b815940e525705466177de")
