-- Lua provided by RyzenAPI
-- Game: 655460

-- MAIN APPLICATION
addappid(655460)
-- Game: addappid(655460)

-- MAIN APP DEPOTS / PACKAGES
addappid(655461, 1, "f1164109ce93a8dcacf73a93f6d65b4cf43466b8cf786054213d1e76aef1d345")
