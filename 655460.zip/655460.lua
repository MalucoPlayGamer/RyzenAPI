-- Lua provided by RyzenAPI
-- Game: Hooligan Vasja: Halloween

-- MAIN APPLICATION
addappid(655460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(655461, 1, "f1164109ce93a8dcacf73a93f6d65b4cf43466b8cf786054213d1e76aef1d345")

