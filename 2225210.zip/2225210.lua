-- Lua provided by SkyAPI 
-- Game: Grape Juice City
addappid(2225210)
addappid(2225211, 1, "39efbb04c21a4b596303bc284612a1a3bad864a83392ae7277ded998d090719e")
