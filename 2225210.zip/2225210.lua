-- Lua provided by RyzenAPI
-- Game: Grape Juice City

-- MAIN APPLICATION
addappid(2225210)
-- Game: addappid(2225210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225211, 1, "39efbb04c21a4b596303bc284612a1a3bad864a83392ae7277ded998d090719e")
