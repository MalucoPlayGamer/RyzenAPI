-- Lua provided by RyzenAPI
-- Game: Pogostuck: Rage With Your Friends

-- MAIN APPLICATION
addappid(688130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(688131, 1, "870512c8b60e6496adc4f40e8a26b2957807e910fd806a5b671e8297ffe2e67c")

