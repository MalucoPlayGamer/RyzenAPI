-- Lua provided by RyzenAPI
-- Game: Game: Pogostuck: Rage With Your Friends

-- MAIN APPLICATION
addappid(688130)
-- Game: addappid(688130)

-- MAIN APP DEPOTS / PACKAGES
addappid(688131, 1, "870512c8b60e6496adc4f40e8a26b2957807e910fd806a5b671e8297ffe2e67c")
