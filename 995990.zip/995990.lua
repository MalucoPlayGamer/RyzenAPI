-- Lua provided by RyzenAPI
-- Game: Death Leak

-- MAIN APPLICATION
addappid(995990)
-- Game: addappid(995990)

-- MAIN APP DEPOTS / PACKAGES
addappid(995991, 1, "e058513c377d6502434fc106e5258308652b61b7d0413ccf20311d865496d265")
