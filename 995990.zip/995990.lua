-- Lua provided by RyzenAPI
-- Game: Death Leak

-- MAIN APPLICATION
addappid(995990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(995991, 1, "e058513c377d6502434fc106e5258308652b61b7d0413ccf20311d865496d265")

