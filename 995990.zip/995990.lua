-- Lua provided by SkyAPI 
-- Game: Death Leak
addappid(995990)
addappid(995991, 1, "e058513c377d6502434fc106e5258308652b61b7d0413ccf20311d865496d265")
