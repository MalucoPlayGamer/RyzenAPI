-- Lua provided by RyzenAPI
-- Game: Loop Queen-Escape Dungeon 3 Demo

-- MAIN APPLICATION
addappid(2119780)
-- Game: addappid(2119780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119781, 1, "9533f5200df3d42fbc42a6757f3fcdb05b09b9eac9086ce8851e327f492ca1ea")
