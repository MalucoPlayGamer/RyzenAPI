-- Lua provided by RyzenAPI
-- Game: Salt Thrust

-- MAIN APPLICATION
addappid(736230)

-- MAIN APP DEPOTS / PACKAGES
addappid(736231, 1, "edd501a209a313041b457d4e475fdccf8c0301c985749716ea93ee75a843c695")

