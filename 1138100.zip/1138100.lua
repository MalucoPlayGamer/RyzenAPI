-- Lua provided by RyzenAPI
-- Game: Touhou Ibunseki - Ayaria Dawn: ReCreation

-- MAIN APPLICATION
addappid(1138100)
-- Game: addappid(1138100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138101, 1, "0a8143bfc5aba3e56e69f920f36540e3dfebed1a33340e47f2dc7472ed906f69")
