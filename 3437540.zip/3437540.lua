-- Lua provided by RyzenAPI
-- Game: Game: Mysteries Of FangClaw

-- MAIN APPLICATION
addappid(3437540)
-- Game: addappid(3437540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3437541, 1, "523383890e14d2b23d3b89d1bf103a8a4903c7c1bfe95efaf1cdf5feb0bce178")
