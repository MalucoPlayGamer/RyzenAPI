-- Lua provided by RyzenAPI
-- Game: Game: Friday Fever

-- MAIN APPLICATION
addappid(3204510)
-- Game: addappid(3204510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204511, 1, "b1fce811d2e0517226d2fba0027c1022f66707b0a792817bc30966c63783d6a7")
addappid(3204512, 1, "37e8327fc8af630fb13c95001a1b1c5e9fa8db1ce01c46f4d529a2b3d884ea15")
