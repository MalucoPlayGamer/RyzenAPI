-- Lua provided by RyzenAPI
-- Game: 1125700

-- MAIN APPLICATION
addappid(1125700)
-- Game: addappid(1125700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125701, 1, "a8216ffd058acfaffe93be143cff8a978995aca2da7ca2fb484cb1dddab63fe9")
