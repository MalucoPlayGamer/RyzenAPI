-- Lua provided by SkyAPI 
-- Game: Endless Void
addappid(1125700)
addappid(1125701, 1, "a8216ffd058acfaffe93be143cff8a978995aca2da7ca2fb484cb1dddab63fe9")
