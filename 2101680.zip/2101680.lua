-- Lua provided by RyzenAPI
-- Game: good game

-- MAIN APPLICATION
addappid(2101680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101681, 1, "a47942aa8b74094f25d776c4223e03ae42c4cf8bdd2b1a1fcb3100e50d5e6a11")
