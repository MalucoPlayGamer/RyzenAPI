-- Lua provided by RyzenAPI
-- Game: Niplheim's Hunter - Branded Azel

-- MAIN APPLICATION
addappid(965670)

-- MAIN APP DEPOTS / PACKAGES
addappid(965671, 1, "c9664ede194aa939ac282969c827d88ada039d858abb4852741402bb9eb0cb7c")
addappid(965672, 1, "8c8961fe8a5a007c5d07473803e8f1e0a4c490649d1ce3e0a00a791089ca999e")
addappid(965673, 1, "edec97c831deebfc9795c045a7f20df543c79540143b292f847c9fc9844ea14c")
addappid(965720, 0, "46d33b524414b9188f5af83a07d8874230bd223257e2c32f9dfddf2c955ea45f")
