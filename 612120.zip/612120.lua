-- Lua provided by RyzenAPI 
-- Game: Darwin's bots: Episode 1
addappid(612120)
addappid(612121, 1, "5213ac549a0912c2b27c3ecc69eb046c421c30e1af54266d3a977ff7112d7d5e")
