-- Lua provided by RyzenAPI
-- Game: 612120

-- MAIN APPLICATION
addappid(612120)
-- Game: addappid(612120)

-- MAIN APP DEPOTS / PACKAGES
addappid(612121, 1, "5213ac549a0912c2b27c3ecc69eb046c421c30e1af54266d3a977ff7112d7d5e")
