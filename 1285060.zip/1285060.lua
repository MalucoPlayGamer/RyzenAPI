-- Lua provided by RyzenAPI
-- Game: Winter Falling: Battle Tactics

-- MAIN APPLICATION
addappid(1285060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285061, 1, "7f826998ff403c45b281a641907131c94562e1198f8f9e6426952f35ee5d1589")

