-- Lua provided by RyzenAPI
-- Game: Half-Life: Restored

-- MAIN APPLICATION
addappid(1283930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283939,0,"fc16a2eb8a0b2a7838948810600de387c81f2dece683b9cfde0e88f9432ccd92")

