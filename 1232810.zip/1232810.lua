-- Lua provided by RyzenAPI
-- Game: Game: Savage Halloween

-- MAIN APPLICATION
addappid(1232810)
-- Game: addappid(1232810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232811, 1, "887981595b260d285f6ef3268a082063651cac8577234a998fc79cc349c05b70")
addappid(1232812, 1, "ee43ed379c769fbbbbe1b83b993c7a4607f112b77033ed0d1548a2836e3bea4f")
addappid(1232813, 1, "6171348fcd2b07f64e4ed213269dddeac566198b75d4b2821cfc3e65061ca1b6")
