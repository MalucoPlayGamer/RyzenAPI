-- Lua provided by RyzenAPI
-- Game: addappid(2691220)

-- MAIN APPLICATION
addappid(2691220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691221, 1, "a90d847f7254d169fc017b335bd606437a4c1c0756f406cb9355e260b1ba1ebf")
