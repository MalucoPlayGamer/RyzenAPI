-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST III HD-2D Remake

-- MAIN APPLICATION
addappid(2701660)
addappid(2875360)
addappid(2915510)
addappid(2915520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2701661, 1, "8c4c389019c5d2e6c25110711a77cb18558175e329aab3f13151b5ba67f25a79")

