-- Lua provided by RyzenAPI
-- Game: addappid(2057460)

-- MAIN APPLICATION
addappid(2057460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057461, 1, "3aa11e478c1f9a2a44cf83471fb1184f3ae818ea73e0c55088700f9208d37dde")
