-- Lua provided by RyzenAPI
-- Game: Awesome Pea 2

-- MAIN APPLICATION
addappid(1200420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200421, 1, "9d4143c77fc37c3f411f06ae52e909c76131fec53b69a9dffbc8f1bbc109c2c8")
