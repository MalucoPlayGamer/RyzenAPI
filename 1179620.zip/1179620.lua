-- Lua provided by RyzenAPI
-- Game: AppID 1179620

-- MAIN APPLICATION
addappid(1179620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179621, 1, "2b1ffaa0b3203343f24ca94303a02a997320de1c2dc9ad8919f9483aaad9fcab")
