-- Lua provided by RyzenAPI
-- Game: Golden Mine Pickaxe

-- MAIN APPLICATION
addappid(1857070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857071, 1, "90dbcb8beb21b6d125e838cf0a0851c89aa2bb8c46b155c2b7037da1f57e0702")
