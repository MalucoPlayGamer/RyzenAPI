-- Lua provided by SkyAPI 
-- Game: Golden Mine Pickaxe
addappid(1857070)
addappid(1857071, 1, "90dbcb8beb21b6d125e838cf0a0851c89aa2bb8c46b155c2b7037da1f57e0702")
