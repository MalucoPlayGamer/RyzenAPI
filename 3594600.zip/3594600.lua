-- Lua provided by RyzenAPI
-- Game: Katana Dragon - Supporter Pack 1

-- MAIN APPLICATION
addappid(3594600)
addappid(3594601)
-- Game: addappid(3594600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3594600,0,"804a2c1cb9350a402a8f945f214e2e17623ed21da06a731444f5892fe53f8495")
