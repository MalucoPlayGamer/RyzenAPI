-- Lua provided by RyzenAPI
-- Game: Escort Simulator 2

-- MAIN APPLICATION
addappid(1857020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857021, 1, "035ea08513b4311b066b0f281c53b6fa764ea8bfac86bc56e897369bc507d1ca")

