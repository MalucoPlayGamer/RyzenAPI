-- Lua provided by RyzenAPI
-- Game: 1054300

-- MAIN APPLICATION
addappid(1054300)
-- Game: addappid(1054300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054301, 1, "f7feb7d04b4fa6ea9fa1303b1711373fc4d32b02af74ad7ff844e3f0f793e2d6")
addappid(1054304, 1, "367a78358e2f3afc7823f8100db523efb3c173a9de9bb272fcdc7a7a72572fdb")
