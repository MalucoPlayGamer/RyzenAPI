-- Lua provided by RyzenAPI
-- Game: the fairytale of DEATH

-- MAIN APPLICATION
addappid(1054300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054301, 1, "f7feb7d04b4fa6ea9fa1303b1711373fc4d32b02af74ad7ff844e3f0f793e2d6")
addappid(1054304, 1, "367a78358e2f3afc7823f8100db523efb3c173a9de9bb272fcdc7a7a72572fdb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
