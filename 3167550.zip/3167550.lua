-- Lua provided by RyzenAPI
-- Game: Game: Tiny Pasture

-- MAIN APPLICATION
addappid(3167550)
-- Game: addappid(3167550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167551, 1, "2eb36141e330220bd89c47de8cca1c780182686771b6f5e9251eeef811774d14")
addappid(3167552, 1, "33361caf10efc9ff15081a065b3a6de507c769dc7f1d976a67177ca845c5093c")
