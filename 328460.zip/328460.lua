-- Lua provided by RyzenAPI
-- Game: Game: Redline

-- MAIN APPLICATION
addappid(328460)
-- Game: addappid(328460)

-- MAIN APP DEPOTS / PACKAGES
addappid(328461, 1, "82f446b879940fc0c95efcbc5bf3cc13512a099b3083d85d07284bdb90e7c6fc")
addappid(328462, 1, "52712d05d63c2a7855720438330a4e9dc5f7f5dea41d9e0fce26c975250589ba")
