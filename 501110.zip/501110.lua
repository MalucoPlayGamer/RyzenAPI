-- Lua provided by RyzenAPI
-- Game: Game: Mount Wingsuit

-- MAIN APPLICATION
addappid(501110)
-- Game: addappid(501110)

-- MAIN APP DEPOTS / PACKAGES
addappid(501111, 1, "cd3b2e6a9d94a14e3a8bee14a4e53f68b0b06ceb7ffdee0012bee4ec44a02e65")
