-- Lua provided by RyzenAPI
-- Game: Raiden Legacy

-- MAIN APPLICATION
addappid(407600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(407601, 1, "37c6e48f44c13665554724bf466852c3f78c5842de2083884ff9d2b669102a45")
