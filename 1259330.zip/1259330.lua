-- Lua provided by RyzenAPI 
-- Game: Stolen Rage
addappid(1259330)
addappid(1259331, 1, "1488b7098c638d2c911d27049cd7a6803c9edf3c6bdb6f8e0790703c6e466732")
