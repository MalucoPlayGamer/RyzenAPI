-- Lua provided by RyzenAPI
-- Game: AppID 1066220

-- MAIN APPLICATION
addappid(1066220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066221, 1, "1f3a75397a12012ed355ea2bd311011aa65900906037f1140a4f1241d796b2de")
addappid(1066222, 1, "ea8d41c278b1f6bb61d114ad81a261b115a6039a8f3d30a572c6d3681438028f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1110750)
