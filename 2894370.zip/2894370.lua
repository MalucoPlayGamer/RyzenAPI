-- Lua provided by RyzenAPI 
-- Game: Grab n' Throw Demo
addappid(2894370)
addappid(2894371, 1, "3cdb726490c0cd9eefbd5c293d7eb5fc4f38fcd60573923821e75b9dbd727c80")
