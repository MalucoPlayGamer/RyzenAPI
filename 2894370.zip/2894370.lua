-- Lua provided by RyzenAPI
-- Game: Grab n' Throw Demo

-- MAIN APPLICATION
addappid(2894370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2894371, 1, "3cdb726490c0cd9eefbd5c293d7eb5fc4f38fcd60573923821e75b9dbd727c80")

