-- Lua provided by RyzenAPI
-- Game: Ashes of Arcanum

-- MAIN APPLICATION
addappid(2576960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576961, 1, "a8641c9696e1b9320c4f0772410ea6226c60ac35317fa4162cecebaa3cc4d7f2")
addappid(2576962, 1, "c1c760159b57f0310debe669a4a17a1c77d7c250f7d657d19761d1cec4fdbf3a")
