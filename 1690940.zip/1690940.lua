-- Lua provided by RyzenAPI
-- Game: DELTARUNE Demo

-- MAIN APPLICATION
addappid(1690940)
-- Game: addappid(1690940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690941, 1, "0eef13bb5d3681842f152ced9b6110099ffcaba0fe9e84a448f25d4da3a364cb")
