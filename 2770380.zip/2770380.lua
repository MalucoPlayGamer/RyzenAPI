-- Lua provided by RyzenAPI
-- Game: AppID 2770380

-- MAIN APPLICATION
addappid(2770380)
-- Game: addappid(2770380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2770381, 1, "3b651919468452bf3c4bfe0e45bf74c4ad119f958f3191ee71190e9d5f707e94")
