-- Lua provided by RyzenAPI
-- Game: Scribble Fight

-- MAIN APPLICATION
addappid(1506300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506301, 1, "4b1658a74beb7e98304cc0c4a13c6b799634bb10d2a4fdc7608d3a5f436f1174")

