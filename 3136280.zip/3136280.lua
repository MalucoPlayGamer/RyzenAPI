-- Lua provided by RyzenAPI
-- Game: Forgotten Fears Demo

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(3136280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3136282,0,"b69b4f95350aeb1b1d2e010da14e625876baa8de68a8b351c0a24079943d2d1d")

