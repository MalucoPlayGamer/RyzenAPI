-- Lua provided by RyzenAPI
-- Game: Pipo Park

-- MAIN APPLICATION
addappid(1485600)
-- Game: addappid(1485600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485601, 1, "dee18eb2291e84c6610de664d69b77b4b7bcf0d31f6bd482560487efad83219a")
