-- Lua provided by RyzenAPI
-- Game: Firefly Studio

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2086520)
-- Game: addappid(2086520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086522,0,"83b529a0e1c4ff23205cc5ca07a5e45062101d9dab54ae43d4420d6545386409")
