-- Lua provided by RyzenAPI
-- Game: Game: Smokyflex

-- MAIN APPLICATION
addappid(2003270)
-- Game: addappid(2003270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003271, 1, "f97354bf3e26dd782f023e47c1da46d3d0258907347d787098d7eb86e2597786")
