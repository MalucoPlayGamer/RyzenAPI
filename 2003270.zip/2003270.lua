-- Lua provided by RyzenAPI 
-- Game: Smokyflex
addappid(2003270)
addappid(2003271, 1, "f97354bf3e26dd782f023e47c1da46d3d0258907347d787098d7eb86e2597786")
