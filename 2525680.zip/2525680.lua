-- Lua provided by RyzenAPI
-- Game: Game: PP

-- MAIN APPLICATION
addappid(2525680)
-- Game: addappid(2525680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2525681, 1, "33a42a770cbb4d725ddab4b71541ff99caf10e28c4a5d256c437ad09c24a9745")
