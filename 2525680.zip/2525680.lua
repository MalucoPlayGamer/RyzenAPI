-- Lua provided by SkyAPI 
-- Game: PP
addappid(2525680)
addappid(2525681, 1, "33a42a770cbb4d725ddab4b71541ff99caf10e28c4a5d256c437ad09c24a9745")
