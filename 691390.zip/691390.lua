-- Lua provided by RyzenAPI
-- Game: Alchemage

-- MAIN APPLICATION
addappid(691390)

-- MAIN APP DEPOTS / PACKAGES
addappid(691391, 1, "2db282ec029b26d2f436121e160853f25053b50efb26c1a6b63d14b2ea665258")
