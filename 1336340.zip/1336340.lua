-- Lua provided by RyzenAPI
-- Game: setManifestid(1336345,"155562683661777169")

-- MAIN APPLICATION
addappid(1336340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336345,0,"80449163eeff9570fb869cdbd0f291f2ad2eab8de6863fda636ba4667c4cbf0d")

