-- Lua provided by RyzenAPI
-- Game: Back to the Dawn - Original Soundtrack

-- MAIN APPLICATION
addappid(2646420)
-- Game: addappid(2646420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646421, 1, "10604d3dec843e1666b3fee920169e1c9758852911109b08f24d9783d8e07398")
addappid(2646422, 1, "126aa0345576d873662ac1e268c5ad98f102a41a45561155e8a4ef640e976277")
