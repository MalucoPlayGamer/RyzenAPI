-- Lua provided by RyzenAPI
-- Game: Immortals of Aveum™

-- MAIN APPLICATION
addappid(2009100)
addappid(2165170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009101, 1, "d86e611fab03143f2175ef5eca7adf37fec7226a43e3ea9fbe29331cd062917c")
