-- Lua provided by RyzenAPI
-- Game: Immortals of Aveum™

-- MAIN APPLICATION
addappid(2009100)
addappid(2165170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009101, 1, "d86e611fab03143f2175ef5eca7adf37fec7226a43e3ea9fbe29331cd062917c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2179880)
addappid(2395350)
addappid(2395351)
addappid(2424221)
