-- Lua provided by RyzenAPI
-- Game: Wrap House Simulator🌯 Demo

-- MAIN APPLICATION
addappid(3533260)
-- Game: addappid(3533260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3533262,0,"6be6ff797a60c114949f03b6cb655dc82b483d784fdb478cd731a4d904198736")
