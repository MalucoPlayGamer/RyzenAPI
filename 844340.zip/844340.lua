-- Lua provided by RyzenAPI
-- Game: 844340

-- MAIN APPLICATION
addappid(844340)
-- Game: addappid(844340)

-- MAIN APP DEPOTS / PACKAGES
addappid(844342,0,"8a9f2a2431ff7894aabb700e9d64aed3690a96fb20b4d98a6423737493e8c6b5")
