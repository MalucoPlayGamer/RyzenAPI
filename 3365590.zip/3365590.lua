-- Lua provided by RyzenAPI 
-- Game: FINAL FANTASY III PIXEL REMASTER Original Soundtrack
addappid(3365590)
addappid(3365591, 1, "d45419f46a87058322aa5945d8e0e6374d910165699f117357583e864b6051eb")
