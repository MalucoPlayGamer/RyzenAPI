-- Lua provided by RyzenAPI
-- Game: A Story Beside

-- MAIN APPLICATION
addappid(634410)

-- MAIN APP DEPOTS / PACKAGES
addappid(634411, 1, "71015992f6616486c9730681514ec22c45ed8d950f98755ab49f891fa1a5c3eb")

