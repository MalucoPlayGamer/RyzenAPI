-- Lua provided by RyzenAPI
-- Game: Kismet Tapestry

-- MAIN APPLICATION
addappid(1787730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787731, 1, "afbffe7237f0c035e8d0ee4b27070d391d183d2d120d1ad36ef414a7672b4a81")
addappid(1787732, 1, "0197cf7477491b40e35e92ce01c4766c9b0b74476a7ac0ce2e27e75875c72940")

