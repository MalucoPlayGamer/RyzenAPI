-- Lua provided by RyzenAPI
-- Game: 1815330

-- MAIN APPLICATION
addappid(1815330)
-- Game: addappid(1815330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815331, 1, "67e07a2a7a16cc7b67052d351524268c49305e6b5fe19beeb79d3dbfe51f04dd")
