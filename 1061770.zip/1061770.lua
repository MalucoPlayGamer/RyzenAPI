-- Lua provided by RyzenAPI
-- Game: 1061770

-- MAIN APPLICATION
addappid(1061770)
-- Game: addappid(1061770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061771, 1, "5f9ec141de8e1b8222709333b732ff9d3e4488f30b3b7cdaaef77a0b374695c7")
