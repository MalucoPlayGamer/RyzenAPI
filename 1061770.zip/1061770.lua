-- Lua provided by SkyAPI 
-- Game: AppID 1061770
addappid(1061770)
addappid(1061771, 1, "5f9ec141de8e1b8222709333b732ff9d3e4488f30b3b7cdaaef77a0b374695c7")
