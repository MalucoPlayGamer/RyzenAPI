-- Lua provided by RyzenAPI
-- Game: Game: Bakeborough

-- MAIN APPLICATION
addappid(2093050)
-- Game: addappid(2093050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093051, 1, "0db1cf687439e2715191139f097d511d29414adbe8a635387e29587eb5a85a42")
