-- Lua provided by RyzenAPI
-- Game: Chronicles: Immortal Sect

-- MAIN APPLICATION
addappid(4314430)
