-- Lua provided by RyzenAPI
-- Game: Hotel Hideaway: Avatar & Chat

-- MAIN APPLICATION
addappid(3829340)
