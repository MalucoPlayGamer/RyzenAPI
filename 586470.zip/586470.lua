-- Lua provided by RyzenAPI
-- Game: Game: AppID 586470

-- MAIN APPLICATION
addappid(586470)
-- Game: addappid(586470)

-- MAIN APP DEPOTS / PACKAGES
addappid(586471, 1, "b4f9a467d8934dd292518822da865a4c98c1d8854152d919d8df852ceecb5888")
addappid(586472, 1, "3853ffb5b63c939bd717cc7dd6618a7bc865fd66e797df9e2c4f58a79c0a9d67")
