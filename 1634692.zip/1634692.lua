-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1634692)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634692,0,"5d3cc3de43279e5dc488f4f75393aadb32f0b2fa9b4f058bec158e35d51899c4")

