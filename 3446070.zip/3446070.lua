-- Lua provided by RyzenAPI
-- Game: Zombies Overloaded

-- MAIN APPLICATION
addappid(3446070)
-- Game: addappid(3446070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3446071, 1, "ca5eea34ef645f9274eed1a8d46755fd75c48518fb5d059ce42647c7ff117a38")
