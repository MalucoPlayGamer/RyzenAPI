-- Lua provided by RyzenAPI
-- Game: 3089040

-- MAIN APPLICATION
addappid(3089040)
-- Game: addappid(3089040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3089041, 1, "c54caf9790efda2628041670f1070e1bb7498de219b5360742a0cea263b3ad46")
