-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Deathwatch - Enhanced Edition

-- MAIN APPLICATION
addappid(394450)

-- MAIN APP DEPOTS / PACKAGES
addappid(394451,0,"aee34168a2e827c0f0ad4ce56c0b5f7354bf418a49f8f5491863e990e7504463")

