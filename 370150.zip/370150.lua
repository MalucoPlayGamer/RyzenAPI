-- Lua provided by SkyAPI 
-- Game: LOOP: A Tranquil Puzzle Game
addappid(370150)
addappid(370151, 1, "7690da3d1212053b5b693a2cd5b48ea9106e52ec500f9794848412d6fa91c247")
addappid(370152, 1, "d2e6374ae76814ff957ba264aa56931a9b91e1c9dd9d0f2609c87723e64c2719")
addappid(370153, 1, "06cd6652c2067ba02899c5bac1d5469fe141433bfbe3511534f50535d0999bbd")
