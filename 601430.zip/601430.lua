-- Lua provided by RyzenAPI
-- Game: The Evil Within 2

-- MAIN APPLICATION
addappid(601430)
addappid(679710)

-- MAIN APP DEPOTS / PACKAGES
addappid(601431, 1, "11ab2f6c4c169c9c448bdf0a31fcd33b6ca4f1d029ac4cc4c2f1c744aaafb3ef")
addappid(601432, 1, "0509a3fe26f284297c9723525f8afb61daee6e620f7ae3cea05fd8065a0a279c")
addappid(601433, 1, "9f0bebc08c2393ed83f25f935fea2fd9203258e466cdefe758037c32c0b59038")
addappid(601434, 1, "47e9bba75d7dc876877610ca2a1dbc2b2d17516d9624a63562766e379dfe358e")
addappid(601435, 1, "74375919bb0af12c20c40995ac7208808e9a11db3712db8199ebe47b1cce1514")
addappid(601436, 1, "a1ac4e01217fe84194abb9da3c0de37806d5a69ab40ac61405aa3604f9c07c4d")
addappid(601437, 1, "70d4f399162d1ed8885189aeac944f4b45a95ffe2618c4ba07cb89aa8222e9e8")
addappid(601438, 1, "07bbfb78175dc3409c0e4c4c6da0d274f2edf5c47d25b5aa5a3511bae5a25276")
addappid(601439, 1, "97549c2fdeff3e4287b76045297c026e5e2e26e52fb2d4385c473656a3badc89")
addappid(679711, 0, "b2e75333e96da8dafbd0a483c0dd7541747c81b181604b3e791b5558fe5ada21")
addappid(679712, 0, "36ae93ecd511e227f5c1b772de8eb7fd86bc182d2395c00943b06e98c516a8f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
