-- Lua provided by RyzenAPI
-- Game: Internet Generation

-- MAIN APPLICATION
addappid(1556980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556981, 1, "6ff522822db902ed6d931d4e8ce6052bdc5e782be61b6b97dba38a6b485d909d")
