-- 3688650's Lua and Manifest Created by Hubcap Manifest
-- False Alarm
-- Created: August 21, 2026 at 01:46:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3688650) -- False Alarm
-- MAIN APP DEPOTS
addappid(3688651, 1, "f75bd9586812dacfcaf9f345b4754cad66965a818dc18c1a88f05ce568243351") -- Depot 3688651
setManifestid(3688651, "5285803433170799191", 193420664)
addappid(3688652, 1, "beb613033856bca8f06395fffebba0b8e9abaad274798482a7c8efe5e78dc5b7") -- Depot 3688652
setManifestid(3688652, "4662916622099918415", 161336648)