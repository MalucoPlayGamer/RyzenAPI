-- Lua provided by RyzenAPI
-- Game: False Alarm

-- MAIN APPLICATION
addappid(3688650) -- False Alarm

-- MAIN APP DEPOTS / PACKAGES
addappid(3688651, 1, "f75bd9586812dacfcaf9f345b4754cad66965a818dc18c1a88f05ce568243351") -- Depot 3688651
addappid(3688652, 1, "beb613033856bca8f06395fffebba0b8e9abaad274798482a7c8efe5e78dc5b7") -- Depot 3688652

