-- Lua provided by RyzenAPI
-- Game: Bionic Bay: Official Game Soundtrack

-- MAIN APPLICATION
addappid(3590220)
-- Game: addappid(3590220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3590221, 1, "3557a09b3a30c7f78e73cd177ee0a939acf05cf0732a1f1c07edb37616497dc7")
