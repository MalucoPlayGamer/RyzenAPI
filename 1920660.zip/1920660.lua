-- Lua provided by RyzenAPI
-- Game: Game: YiYi

-- MAIN APPLICATION
addappid(1920660)
-- Game: addappid(1920660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920661, 1, "d82b7b7767f2f2bff1030e6eaa9622da600997495ce5f2c66d999dd090044a56")
