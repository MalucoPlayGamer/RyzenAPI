-- Lua provided by RyzenAPI
-- Game: Five Nights at Backrooms: Waifu Edition

-- MAIN APPLICATION
addappid(2692010)
-- Game: addappid(2692010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692011, 1, "99eabcf8a7ee5c8ce4d727809bd63e3695de9f9be808345037ed38a0cd932837")
