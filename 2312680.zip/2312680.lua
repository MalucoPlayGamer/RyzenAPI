-- Lua provided by RyzenAPI
-- Game: KarmaZoo Demo

-- MAIN APPLICATION
addappid(2312680)
-- Game: addappid(2312680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312681, 1, "6633d9204d26ff8aa510a87685b921389afed002ba5833ba773b29b987957ab2")
