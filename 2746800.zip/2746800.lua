-- Lua provided by RyzenAPI
-- Game: 轉生打怪學英文(五)(Adventure and study English in a fantasy world)

-- MAIN APPLICATION
addappid(2746800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746801, 1, "b392ebcd0623968c80be05356e8333afc868de8b9a48cc173bc5e95ac7ae6511")

