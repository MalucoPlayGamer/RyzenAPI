-- Lua provided by SkyAPI 
-- Game: AppID 2746800
addappid(2746800)
addappid(2746801, 1, "b392ebcd0623968c80be05356e8333afc868de8b9a48cc173bc5e95ac7ae6511")
