-- Lua provided by RyzenAPI
-- Game: C.U.B.E

-- MAIN APPLICATION
addappid(4523340) -- C.U.B.E

-- MAIN APP DEPOTS / PACKAGES
addappid(4523341, 1, "b7021505ebf96ff2109c67aa74e6f87d3816e27699f61b5f53bf2ce63d8dc4f7") -- Depot 4523341

