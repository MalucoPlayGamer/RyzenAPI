-- 4523340's Lua and Manifest Created by Hubcap Manifest
-- C.U.B.E
-- Created: August 21, 2026 at 22:56:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4523340) -- C.U.B.E
-- MAIN APP DEPOTS
addappid(4523341, 1, "b7021505ebf96ff2109c67aa74e6f87d3816e27699f61b5f53bf2ce63d8dc4f7") -- Depot 4523341
setManifestid(4523341, "6655194396879101953", 12526820738)