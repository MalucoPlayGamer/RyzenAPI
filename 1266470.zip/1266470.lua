-- Lua provided by RyzenAPI
-- Game: Real VR Fishing

-- MAIN APPLICATION
addappid(1266470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266471, 1, "0cf32a0440490f0a6f9afbaae490c4a43cbd66ab23333cf0835d0ec93e220a66")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3158890)
addappid(3158900)
addappid(3158910)
addappid(3158920)
addappid(3524450)
addappid(3524460)
addappid(3524470)
addappid(4035670)
addappid(4035680)
addappid(4035690)
addappid(4035700)
addappid(4164750)
addappid(4486630)
addappid(4771320)
addappid(5105730)
