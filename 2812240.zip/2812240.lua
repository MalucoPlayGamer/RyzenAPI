-- Lua provided by RyzenAPI
-- Game: Whispers in the Void

-- MAIN APPLICATION
addappid(2812240)
-- Game: addappid(2812240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2812241, 1, "a953d96fa20400c3e54cece3f699194e3ee4f2db3665a7f9258fa6f397bf5443")
