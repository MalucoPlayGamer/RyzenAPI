-- Lua provided by RyzenAPI
-- Game: Broken Thorns: West Gate

-- MAIN APPLICATION
addappid(1508220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508221, 1, "109c471454f4cb6ab38d9bcc07a8dbbaa9a2f33c828149b5ebd8d6a63be8d0fe")
