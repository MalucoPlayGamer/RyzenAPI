-- Lua provided by RyzenAPI
-- Game: Game: Life Goes On: Done to Death

-- MAIN APPLICATION
addappid(250050)
-- Game: addappid(250050)

-- MAIN APP DEPOTS / PACKAGES
addappid(250051, 1, "3d6ebd9af0e8bbd3dc06253dfb4deef826f1998cc6937a16e9e1e086184e4cd2")
addappid(250052, 1, "7c53c2591c358f27146ce48ee2b2941ba2efa04e81d1d2add16be0ef60ddc5cf")
addappid(250053, 1, "62be5064a1c635e9e7e26338435f04a5f1e8039020d613662d776242f4c0651a")
