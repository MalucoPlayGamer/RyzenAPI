-- Lua provided by SkyAPI 
-- Game: Satellite Repairman
addappid(567780)
addappid(567781, 1, "25a8b3d9c9dbd0d0876695e1a543eb5d5eb2dc75bb7de348a368bb015c4c0d9b")
addappid(567782, 1, "094accfc773f9b3d150add55399f87afbb27ddedb4e6199ca24b8c4d0e9a4188")
addappid(567783, 1, "bbe98be1a33acb6303fb0669d09ce72350f939e0a6e63e3e38f760e417edba10")
