-- Lua provided by SkyAPI 
-- Game: AppID 2612820
addappid(2612820)
addappid(2612821, 1, "ba99aa7da82f96cf25f36411dfa90bbf2645508976d3b5514c442ea3e9451c72")
