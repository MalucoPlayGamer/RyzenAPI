-- Lua provided by RyzenAPI
-- Game: addappid(2612820)

-- MAIN APPLICATION
addappid(2612820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612821, 1, "ba99aa7da82f96cf25f36411dfa90bbf2645508976d3b5514c442ea3e9451c72")
