-- Lua provided by RyzenAPI
-- Game: 673660

-- MAIN APPLICATION
addappid(673660)
-- Game: addappid(673660)

-- MAIN APP DEPOTS / PACKAGES
addappid(673661, 1, "75ed3f162301affacb7692f8f3061f139f8aae902947eee63d9c98c8c2325c50")
