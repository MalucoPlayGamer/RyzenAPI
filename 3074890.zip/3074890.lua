-- Lua provided by RyzenAPI 
-- Game: Theo Demo
addappid(3074890)
addappid(3074891, 1, "d31666cff9d7822870f3080a6512d52b905a0d6148a22d653750f2e29b4237f7")
