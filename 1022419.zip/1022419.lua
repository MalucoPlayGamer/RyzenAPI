-- Lua provided by RyzenAPI
-- Game: DFF NT: Thinking Cap, Kefka Palazzo's 4th Weapon

-- MAIN APPLICATION
addappid(1022419)
-- Game: addappid(1022419)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022419,0,"fc06b385a3b6ced236375810ec9c34448b14a59c3c95fd206b8ad3f396026045")
