-- Lua provided by RyzenAPI
-- Game: Space Shapes

-- MAIN APPLICATION
addappid(1174430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1174431, 1, "8cecb6998e8911391aab633862fe98f3926cf0cadfa83cd3c76f26fa85872bbe")
