-- Lua provided by SkyAPI 
-- Game: AppID 1174430
addappid(1174430)
addappid(1174431, 1, "8cecb6998e8911391aab633862fe98f3926cf0cadfa83cd3c76f26fa85872bbe")
