-- Lua provided by RyzenAPI
-- Game: SOULCALIBUR VI

-- MAIN APPLICATION
addappid(544750)
addappid(874340)
addappid(874341)
addappid(874342)
addappid(874343)
addappid(874344)
addappid(874345)
addappid(874360)
addappid(1162200)
addappid(1162201)
addappid(1162202)
addappid(1162203)
addappid(1162204)
addappid(1162205)
addappid(1162206)
addappid(1162207)
addappid(1162208)
addappid(1163030)
-- Game: addappid(544750)

-- MAIN APP DEPOTS / PACKAGES
addappid(544751, 1, "af49b86e4edb4905c96329dbb5a0c17cf0a4eeb4c4d9b658bd7753146cacc309")
