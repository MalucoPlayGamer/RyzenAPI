-- Lua provided by RyzenAPI
-- Game: AppID 1957590

-- MAIN APPLICATION
addappid(1957590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957591, 1, "99bb1b38f23afd2aac54bbc24f45f09b968fda5fa92cfcb4df9a1cd6f45d28cc")

