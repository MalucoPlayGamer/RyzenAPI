-- Lua provided by SkyAPI 
-- Game: The HeartBeat
addappid(1386710)
addappid(1386711, 1, "a422097e1a52e9f0a77a40ad975b7deae9ce65532029f1abd54ca22053e94fda")
