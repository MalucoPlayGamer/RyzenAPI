-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1760490)
-- Game: addappid(1760490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760490,0,"c5e244432a04f26054022a4f38c1419c2c743df9b79d9a706bdf38cf2fb41856")
