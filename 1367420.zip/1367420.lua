-- Lua provided by RyzenAPI
-- Game: One Line Coloring

-- MAIN APPLICATION
addappid(1367420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1367421, 1, "4dfe21ae2957dc7f41565835c8eab1402857a0ca99ff512ec77b172f6b0499fb")
