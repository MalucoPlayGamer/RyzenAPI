-- Lua provided by RyzenAPI
-- Game: 1367420

-- MAIN APPLICATION
addappid(1367420)
-- Game: addappid(1367420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367421, 1, "4dfe21ae2957dc7f41565835c8eab1402857a0ca99ff512ec77b172f6b0499fb")
