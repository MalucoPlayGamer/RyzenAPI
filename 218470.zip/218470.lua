-- Lua provided by RyzenAPI
-- Game: RaiderZ

-- MAIN APPLICATION
addappid(218470)
addappid(229031)

-- MAIN APP DEPOTS / PACKAGES
addappid(218471, 1, "df44a50306f72f29fb6de9d25d995b757ae258f98f8f1371e1005109e15fc6ed")

