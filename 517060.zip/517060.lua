-- Lua provided by RyzenAPI
-- Game: Day of the Trumplings

-- MAIN APPLICATION
addappid(517060)
-- Game: addappid(517060)

-- MAIN APP DEPOTS / PACKAGES
addappid(517061, 1, "42c8a95c5fa649e35a67f10776a555b032cf6e45405ee09569cbaabdb9cc8e31")
addappid(517063, 1, "1eb948a1e501fdc2e0319d1d38fe4153dfc50eae8359ba99420cd7312fe96bb0")
