-- Lua provided by RyzenAPI 
-- Game: Pictopix
addappid(568320)
addappid(568321, 1, "def07808651c8d520957b995dd54f013720f1c4b419ea621a5bff57d8a6d0ee7")
addappid(568322, 1, "4d3bf8f4d66d755e39880ffb87c034376f3e7d49da496d649ad3f4a3fd511b8f")
addappid(568323, 1, "1f676f6f61b2a081bcf3ffa8cf79a0ce59812f29b6b4ad3a3846a8faa990b5c2")
addappid(568324, 1, "2c22963ab0e2db739dfbcbaf67867274bc47a4ad613862e0d352f70320aee427")
