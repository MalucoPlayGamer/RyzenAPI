-- Lua provided by RyzenAPI
-- Game: Bartender VR Simulator

-- MAIN APPLICATION
addappid(704300)

-- MAIN APP DEPOTS / PACKAGES
addappid(704301, 1, "8e4f3e847ee835c3831df9ac62e59a9ff98d42b31200aaf722701f335fff8553")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
