-- Lua provided by RyzenAPI
-- Game: AppID 623090

-- MAIN APPLICATION
addappid(623090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(623091, 1, "080be6240c5acefa6d4ec019861c5899112f53fd2c05c103b556cf4d1c713cde")
addappid(623092, 1, "4bc0dcfc07156ea6314f0888d3f349c926292e792c733faf7cbe924ad4ea76c1")

