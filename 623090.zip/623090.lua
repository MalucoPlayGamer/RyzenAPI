-- Lua provided by RyzenAPI 
-- Game: AppID 623090
addappid(623090)
addappid(623091, 1, "080be6240c5acefa6d4ec019861c5899112f53fd2c05c103b556cf4d1c713cde")
addappid(623092, 1, "4bc0dcfc07156ea6314f0888d3f349c926292e792c733faf7cbe924ad4ea76c1")
