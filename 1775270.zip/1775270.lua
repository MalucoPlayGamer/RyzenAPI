-- Lua provided by RyzenAPI
-- Game: AppID 1775270

-- MAIN APPLICATION
addappid(1775270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775271, 1, "d4ebda642b68b1df066d0065a98637626071894c9aaac80c360bd8a4a9ac39e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
