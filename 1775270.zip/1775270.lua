-- Lua provided by RyzenAPI
-- Game: Game: AppID 1775270

-- MAIN APPLICATION
addappid(1775270)
-- Game: addappid(1775270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775271, 1, "d4ebda642b68b1df066d0065a98637626071894c9aaac80c360bd8a4a9ac39e3")
