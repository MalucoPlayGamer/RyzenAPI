-- Lua provided by RyzenAPI
-- Game: TowerFall Ascension

-- MAIN APPLICATION
addappid(251470)
-- Game: addappid(251470)

-- MAIN APP DEPOTS / PACKAGES
addappid(251471, 1, "d0f40bbe2a311a5daf79c576307113a685b556e563ee89409ccdb0be66feac55")
addappid(251472, 1, "06703ec3b608e7539dc0e47d8be88dc5eb5424006da34605a5e2a615d22e70ba")
addappid(251473, 1, "abb6bdbccfb1d19f1b191f0109b27a4c144ccc48b9779e9a16979fe5111d4e05")
addappid(337840, 0, "19c292db638ea335b03ec9fca1e7e69140e28b76c4e960976840e744fc6d3953")
