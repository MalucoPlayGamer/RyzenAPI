-- Lua provided by RyzenAPI
-- Game: 25920

-- MAIN APPLICATION
addappid(25920)
-- Game: addappid(25920)

-- MAIN APP DEPOTS / PACKAGES
addappid(25921, 1, "26cb02dd4190ad54bd79a1c98a9bb857544aa8a257032988add50037db9afb71")
addappid(25922, 1, "06f46395cb334fad5cfe4e32a0835d3dd1a15f2b2b060180034165a0d7208cc9")
