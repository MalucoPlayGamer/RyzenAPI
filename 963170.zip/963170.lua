-- Lua provided by RyzenAPI 
-- Game: Citadale - The Ancestral Strain
addappid(963170)
addappid(963171, 1, "e097d2e1723c419f9e42c21c5fa1804acf901f2f15461fb3f0b88dc4cdcba056")
