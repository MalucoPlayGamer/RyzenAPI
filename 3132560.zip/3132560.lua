-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel (Manga) Vol. 2

-- MAIN APPLICATION
addappid(3132560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132561, 1, "284676b2dd9ab63efdafa1acacdd98fb454ecddd308c5398a00751952ecbc188")

