-- Lua provided by RyzenAPI
-- Game: Airplane Racing Championship

-- MAIN APPLICATION
addappid(3595280)
-- Game: addappid(3595280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3595281, 1, "8c96ef82f1943c69002a4babb8138768a3a56356bfd56cf178d158f70ab05943")
