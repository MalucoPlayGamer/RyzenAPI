-- Lua provided by RyzenAPI
-- Game: AppID 860510

-- MAIN APPLICATION
addappid(860510)
addappid(1282530)
addappid(1282532)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(860511, 1, "b4785c13c7b51e8a08e3f16332ef4839c28d6e7544230b06535bd5ee180cbfea")
addappid(1282531, 0, "1bf86c1151867753629f54ffb559c02482ff71f34f59476a0a058093e0635ddd")
addappid(1413420, 0, "8c10dd752f9e566421902b5f300bfc5098b40beaf62ba20c7ab8d223c1423dbf")

