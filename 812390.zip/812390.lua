-- Lua provided by RyzenAPI
-- Game: addappid(812390)

-- MAIN APPLICATION
addappid(812390)

-- MAIN APP DEPOTS / PACKAGES
addappid(812391, 1, "5aa1b868fbdc8152427b13fc1c3baa1cb41c89f3c64c93721f97f335c442d7a2")
