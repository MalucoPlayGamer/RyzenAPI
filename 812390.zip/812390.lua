-- Lua provided by RyzenAPI
-- Game: Torimodosu

-- MAIN APPLICATION
addappid(812390)

-- MAIN APP DEPOTS / PACKAGES
addappid(812391, 1, "5aa1b868fbdc8152427b13fc1c3baa1cb41c89f3c64c93721f97f335c442d7a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
