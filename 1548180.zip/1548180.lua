-- Lua provided by RyzenAPI
-- Game: addappid(1548180)

-- MAIN APPLICATION
addappid(1548180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548181, 1, "56b4ac160aaaff762a5109ab9d414da4d5f219f52d58e43807452028c7918adb")
