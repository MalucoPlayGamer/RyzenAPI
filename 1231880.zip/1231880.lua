-- Lua provided by RyzenAPI
-- Game: Haiku, the Robot

-- MAIN APPLICATION
addappid(1231880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231881, 1, "901ba963ce62d5e82f4e565c2e15aa05de9ba0ffbff4b97f99ea41cfaa70a7c1")
addappid(1231882, 1, "b8b30912ffea1edc3be0941f251c8e9b1b87a8803c0f2faf4bde169524dc8392")
