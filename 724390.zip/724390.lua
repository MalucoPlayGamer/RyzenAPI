-- Lua provided by RyzenAPI
-- Game: Rigid Force Alpha

-- MAIN APPLICATION
addappid(724390)
addappid(931740)

-- MAIN APP DEPOTS / PACKAGES
addappid(724391, 1, "ff2c1591af8993fab61fa4c9d23f463a5f3c7e11136d73d5591a81354d595240")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
