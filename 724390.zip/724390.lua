-- Lua provided by SkyAPI 
-- Game: Rigid Force Alpha
addappid(724390)
addappid(724391, 1, "ff2c1591af8993fab61fa4c9d23f463a5f3c7e11136d73d5591a81354d595240")
addappid(931740)
