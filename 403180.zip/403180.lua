-- Lua provided by RyzenAPI 
-- Game: Draw a Stickman: EPIC 2
addappid(403180)
addappid(403181, 1, "b1b0922e588e7a40298617326e08d86855c3002b992ca29c6e045e607c182fcf")
addappid(487320, 0, "6098c476e7646c83f4d77712eed8dcb5c8c6e6fa8f26f3bfb1d094b00a68b6d6")
