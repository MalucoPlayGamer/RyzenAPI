-- Lua provided by RyzenAPI 
-- Game: Wizened Dream
addappid(2640600)
addappid(2640601, 1, "4718038428cb9cc4c661867959e0357185ed3d16f12eba547383b50237e79bb0")
addappid(2640602, 1, "b7571601c4649f1a1c8f2c60178a3a0c77e788bfbcfc1393be0e21d8ed67be5b")
addappid(2640603, 1, "ac0a041204502189b23180904aab0d0c6dda22296cef56dd8de31740ca5fb4ca")
addappid(2763350)
