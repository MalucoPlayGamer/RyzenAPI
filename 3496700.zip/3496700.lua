-- Lua provided by RyzenAPI
-- Game: Hentai Girls: Lust [18+]

-- MAIN APPLICATION
addappid(3496700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3496701, 1, "f7dae505548b523d0a85fb0186ca09b83a50a901493c54c58d4fed66ebd1300a")

