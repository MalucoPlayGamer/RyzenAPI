-- Lua provided by SkyAPI 
-- Game: Hentai Girls: Lust [18+]
addappid(3496700)
addappid(3496701, 1, "f7dae505548b523d0a85fb0186ca09b83a50a901493c54c58d4fed66ebd1300a")
