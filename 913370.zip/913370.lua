-- Lua provided by RyzenAPI 
-- Game: The Colony
addappid(913370)
addappid(913371, 1, "f94e4da52bdbfc82cd9280bffafc65ff16022c4fa2148908ddf9804e770928b4")
