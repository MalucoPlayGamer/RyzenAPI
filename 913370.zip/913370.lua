-- Lua provided by RyzenAPI
-- Game: The Colony

-- MAIN APPLICATION
addappid(913370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(913371, 1, "f94e4da52bdbfc82cd9280bffafc65ff16022c4fa2148908ddf9804e770928b4")

