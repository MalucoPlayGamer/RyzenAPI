-- Lua provided by RyzenAPI
-- Game: The Colony

-- MAIN APPLICATION
addappid(913370)
-- Game: addappid(913370)

-- MAIN APP DEPOTS / PACKAGES
addappid(913371, 1, "f94e4da52bdbfc82cd9280bffafc65ff16022c4fa2148908ddf9804e770928b4")
