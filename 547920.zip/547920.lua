-- Lua provided by RyzenAPI
-- Game: Our Darkest Night

-- MAIN APPLICATION
addappid(547920)

-- MAIN APP DEPOTS / PACKAGES
addappid(547921,0,"4ab6e2be892789c9bead05652aa0fa80725d075255900a6bd7ac1502b8416749")

