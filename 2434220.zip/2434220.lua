-- Lua provided by RyzenAPI
-- Game: Game: AppID 2434220

-- MAIN APPLICATION
addappid(2434220)
-- Game: addappid(2434220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434221, 1, "61eec2d23cafe4ac2e1fa633dab4a0434a093b8239fb7353169a4d7250ddad78")
