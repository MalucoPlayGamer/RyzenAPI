-- Lua provided by SkyAPI 
-- Game: Mystery Island:Missing Amy
addappid(3439040)
addappid(3439041, 1, "2a62281d7cfb8741ddcdf1e3be15d3361ac283b8b428ecb92d04afe60d0f8642")
