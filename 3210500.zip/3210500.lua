-- Lua provided by RyzenAPI
-- Game: Pixel Beat Playtest

-- MAIN APPLICATION
addappid(3210500)
-- Game: addappid(3210500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3210501, 1, "945edd1f6754c52fde0aa5141623bea122c9e81ebb0491b684513236a9d941c3")
