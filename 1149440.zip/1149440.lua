-- Lua provided by RyzenAPI
-- Game: Game: Dragon Marked For Death

-- MAIN APPLICATION
addappid(1149440)
addappid(1168380)
-- Game: addappid(1149440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149441, 1, "09f81b4dd171620f919cc227322b3f504d0d09fec97de16fe805028491864ed6")
