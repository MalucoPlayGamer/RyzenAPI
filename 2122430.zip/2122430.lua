-- Lua provided by RyzenAPI
-- Game: Renai X Royale - Love's a Battle

-- MAIN APPLICATION
addappid(2122430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122431, 1, "8e09d7b2a3a34d6bc091143978da5e24f8b7212f2149048593822624dcc78593")

