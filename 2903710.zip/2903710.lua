-- Lua provided by RyzenAPI
-- Game: Lost Lullabies: The Orphanage Chronicles

-- MAIN APPLICATION
addappid(2903710)
-- Game: addappid(2903710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903711, 1, "e3773d8270a3efd10ccd9fb57b05cd8aa2567cd607cb59fba893dcbe43366cfd")
