-- Lua provided by RyzenAPI
-- Game: Inertia ball

-- MAIN APPLICATION
addappid(2563930)
-- Game: addappid(2563930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563931, 1, "b18125ecee1f48ad3ecc2e5248b09dec5b4692f60e771e67c410d913d313a3fb")
