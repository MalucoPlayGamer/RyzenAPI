-- Lua provided by RyzenAPI
-- Game: Game: The Mystery of the Druids

-- MAIN APPLICATION
addappid(343000)
-- Game: addappid(343000)

-- MAIN APP DEPOTS / PACKAGES
addappid(343001, 1, "96af80161a429861a7e25053c9e37f3c34b113650b84d503b2014a62ead1cba5")
addappid(343002, 1, "d7a28a977fe806ee6f6e43f26793676384e94a05329fe2b03c62344e534ebe90")
addappid(343003, 1, "0c3ebfe35683f6619ce108f352de62141b4742fb190b439421693e4ef4f86105")
addappid(343005, 1, "f0520fcea0b57339b73f6b0262c9cd6c6aa6e3af401afd564acb6b74a1a4f200")
