-- Lua provided by RyzenAPI
-- Game: Midnight Cruise

-- MAIN APPLICATION
addappid(2842120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842121, 1, "36846271851a536b6d46fa392db4c656bd0eb3ae609f265ea9a0460803cd92b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
