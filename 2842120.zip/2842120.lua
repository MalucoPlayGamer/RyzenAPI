-- Lua provided by RyzenAPI
-- Game: Midnight Cruise

-- MAIN APPLICATION
addappid(2842120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842121, 1, "36846271851a536b6d46fa392db4c656bd0eb3ae609f265ea9a0460803cd92b5")

