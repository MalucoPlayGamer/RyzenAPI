-- Lua provided by RyzenAPI
-- Game: AppID 778450

-- MAIN APPLICATION
addappid(778450)

-- MAIN APP DEPOTS / PACKAGES
addappid(778451, 1, "cec1734fe21d12d8c0604b5dc6d4d1b1358b461e3bea12e1b35ed07e8da3438f")

