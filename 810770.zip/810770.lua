-- Lua provided by RyzenAPI
-- Game: addappid(810770)

-- MAIN APPLICATION
addappid(810770)

-- MAIN APP DEPOTS / PACKAGES
addappid(810771, 1, "c42ec29f808ea3940a69ea7afab48fbb71b8d0867ef6603f28573d26c4dd38e4")
