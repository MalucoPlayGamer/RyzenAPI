-- Lua provided by RyzenAPI
-- Game: Game: AppID 275470

-- MAIN APPLICATION
addappid(275470)
-- Game: addappid(275470)

-- MAIN APP DEPOTS / PACKAGES
addappid(275471, 1, "d408f325652594eb4cd0ab6e3085b250601e0397335f3d07309db58ee8cd3a7d")
