-- Lua provided by RyzenAPI
-- Game: AppID 275470

-- MAIN APPLICATION
addappid(275470)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(275471, 1, "d408f325652594eb4cd0ab6e3085b250601e0397335f3d07309db58ee8cd3a7d")

