-- Lua provided by RyzenAPI
-- Game: Crawl OST

-- MAIN APPLICATION
addappid(619690)

-- MAIN APP DEPOTS / PACKAGES
addappid(619690,0,"7bb890ce49db81098cd1bef83b901cb0589a3c682f3ee02fdd3813273e3236fe")

