-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2694550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2694552,0,"dbae8d36e1de33217921fdaa29a251b2e5a46588224e18f587e1fcf27c9ac8ed")
