-- Lua provided by RyzenAPI
-- Game: Game: god of Y

-- MAIN APPLICATION
addappid(3517110)
-- Game: addappid(3517110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3517111, 1, "bfee52fc328cf94e67acde8dbfb932f6b84d8c2ab4628e5767073acf9d74acfc")
