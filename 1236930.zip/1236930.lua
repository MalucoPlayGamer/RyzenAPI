-- Lua provided by RyzenAPI
-- Game: Outliver: Tribulation

-- MAIN APPLICATION
addappid(1236930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1236931, 1, "377f569da323c2461966bbb9390babdd6eaea3bc4fd7fcd9387014e6fa72a95b")
