-- Lua provided by RyzenAPI
-- Game: Game: AppID 1236930

-- MAIN APPLICATION
addappid(1236930)
-- Game: addappid(1236930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236931, 1, "377f569da323c2461966bbb9390babdd6eaea3bc4fd7fcd9387014e6fa72a95b")
