-- Lua provided by RyzenAPI
-- Game: 727930

-- MAIN APPLICATION
addappid(727930)
addappid(1096020)
-- Game: addappid(727930)

-- MAIN APP DEPOTS / PACKAGES
addappid(727931, 1, "bf7ce71ce4824153b0e9fe49cef360a37c1a174d79c3eb5b40792b594187046e")
