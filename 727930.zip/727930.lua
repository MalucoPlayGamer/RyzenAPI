-- Lua provided by RyzenAPI
-- Game: Robo Revenge Squad

-- MAIN APPLICATION
addappid(727930)
addappid(1096020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(727931, 1, "bf7ce71ce4824153b0e9fe49cef360a37c1a174d79c3eb5b40792b594187046e")

