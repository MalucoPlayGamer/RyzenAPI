-- Lua provided by RyzenAPI
-- Game: 3508870

-- MAIN APPLICATION
addappid(3508870)
-- Game: addappid(3508870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3508871, 1, "4440735ae1c65d74a1ad35736be98a8cf00100d836c78dc1e63e607586ec80c0")
