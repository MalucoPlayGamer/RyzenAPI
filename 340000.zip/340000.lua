-- Lua provided by RyzenAPI
-- Game: Headlander

-- MAIN APPLICATION
addappid(340000)
addappid(501260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(340001, 1, "2133fbec1526b19d8371840e55a6f28f3718a020d361a3f78d141dfdac7394cb")
addappid(340002, 1, "5c0a3371f161fa9a87c588a9df3f366db9f9787d8805e1e2ba6462ddbe442e5a")

