-- Lua provided by RyzenAPI 
-- Game: The Cub
addappid(1941410)
addappid(1941411, 1, "996ff2807bf2b6aac889e26279c750e71cbd5ed63ec5d6cf5b54642641b228ec")
