-- Lua provided by RyzenAPI
-- Game: Frederic: Evil Strikes Back

-- MAIN APPLICATION
addappid(301200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(301201, 1, "e67d24a926f179365dce10cf21f13ac22523590c363deaa546d2b87ab2f8004e")
addappid(301202, 1, "448ec6bfdea5ff6382b4a0e32a303de7f1e52c0d332ee130cf64b816958b64ea")
addappid(301203, 1, "4f10b3b07bd6f766164ec49f9766f169ce499eb7422299ab3b29bf45afe56068")
addappid(301204, 1, "5f3a9659f386bbb3df4c6d13e73a4aa05454995aa8ec3107f96e47f4beeffb35")

