-- Lua provided by RyzenAPI
-- Game: 3349050

-- MAIN APPLICATION
addappid(3349050)
-- Game: addappid(3349050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3349051, 1, "72ed7e6bb887890e08a34fcd42afa85377aa3fb74a78abf24fd51a01d49927b6")
