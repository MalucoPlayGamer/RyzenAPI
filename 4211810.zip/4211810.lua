-- 4211810's Lua and Manifest Created by Hubcap Manifest
-- ヴァルキリーチューン：機械仕掛けのアイ
-- Created: July 23, 2026 at 02:36:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4211810) -- ヴァルキリーチューン：機械仕掛けのアイ
-- MAIN APP DEPOTS
addappid(4211811, 1, "5c7bba85a1a7153fc7a63bfc3a2106b06d03062b154133739cb3f71d552f0aaa") -- Depot 4211811
setManifestid(4211811, "6879915356322086010", 5028643855)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)