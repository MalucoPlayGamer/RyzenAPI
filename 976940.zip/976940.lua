-- Lua provided by RyzenAPI
-- Game: addappid(976940)

-- MAIN APPLICATION
addappid(976940)

-- MAIN APP DEPOTS / PACKAGES
addappid(976941, 1, "065c54b08e72d38d3eff311031141b62936fd717e03721f0596bd0d84a6dd4ab")
