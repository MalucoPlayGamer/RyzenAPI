-- Lua provided by RyzenAPI
-- Game: Trip to Vinelands

-- MAIN APPLICATION
addappid(546090)
-- Game: addappid(546090)

-- MAIN APP DEPOTS / PACKAGES
addappid(546091, 1, "92437f9917a305c6541f6bc159e1736d859941c0ce036a44295c7ffc55c79832")
addappid(546092, 1, "87bafa25951f3370cfc3db8d909591bf43a3089d8ebab39f5b33a15b19940c52")
