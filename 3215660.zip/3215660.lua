-- Lua provided by RyzenAPI
-- Game: Game: Late Homework | 遅れた宿題

-- MAIN APPLICATION
addappid(3215660)
-- Game: addappid(3215660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215661, 1, "5b85cd0b656dd466c580e023eda544feb64e092d0f521122f84a039198cbd0c0")
