-- Lua provided by RyzenAPI
-- Game: addappid(1766280)

-- MAIN APPLICATION
addappid(1766280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766280,0,"198640f883c08003e1827f8874b2fd3b66578a99f43a0e86aea3da2318d7bfaa")
