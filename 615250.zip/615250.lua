-- Lua provided by RyzenAPI
-- Game: M.A.X.: Mechanized Assault & Exploration

-- MAIN APPLICATION
addappid(615250)

-- MAIN APP DEPOTS / PACKAGES
addappid(615251, 1, "4591c2ac854ff8b62d531115e24d71b64a582e264881075b0513126bc86e6181")
