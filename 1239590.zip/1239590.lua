-- Lua provided by SkyAPI 
-- Game: AppID 1239590
addappid(1239590)
addappid(1239591, 1, "196b7e3465c76153c9206326f4500f4a38b65dd708bc4227d36b0e455ec29c03")
