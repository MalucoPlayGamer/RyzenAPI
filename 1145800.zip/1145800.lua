-- Lua provided by RyzenAPI
-- Game: Game: Marisa's Inconceivable Journey

-- MAIN APPLICATION
addappid(1145800)
-- Game: addappid(1145800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1145801, 1, "5a02f6977fd0a5679276d0f75d3d48df6edcb981b2f3449f887497cb6df31aee")
