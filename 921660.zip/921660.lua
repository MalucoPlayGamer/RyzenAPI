-- Lua provided by RyzenAPI
-- Game: Quirky Crystal RPG

-- MAIN APPLICATION
addappid(921660)

-- MAIN APP DEPOTS / PACKAGES
addappid(921661, 1, "eaed7c110cb5a8333518cb1bbf52fcfacbb9d9ef16aac8b68c2f1b60cc89b2d7")

