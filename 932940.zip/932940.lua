-- Lua provided by RyzenAPI
-- Game: AppID 932940

-- MAIN APPLICATION
addappid(932940)

-- MAIN APP DEPOTS / PACKAGES
addappid(932941, 1, "96070a156bdf6725009b3ca085e947bbe6b892d3aee66b297bf87a90d62cc9e8")

