-- Lua provided by SkyAPI 
-- Game: Astrodle
addappid(2853130)
addappid(2853131, 1, "3af4f54167500135a79431006a0bc2f85f926101d208e188085c8b4c180f9daf")
