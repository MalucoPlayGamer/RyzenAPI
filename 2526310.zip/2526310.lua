-- Lua provided by RyzenAPI
-- Game: Out of Sight

-- MAIN APPLICATION
addappid(2526310)
addappid(4054300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526311, 1, "4d96d2024ac336424c26d995e45c7d983e97f71552e8d67e3d794e182b21fc57")

