-- Lua provided by RyzenAPI
-- Game: Out of Sight

-- MAIN APPLICATION
addappid(2526310)
addappid(4054300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2526311, 1, "4d96d2024ac336424c26d995e45c7d983e97f71552e8d67e3d794e182b21fc57")

