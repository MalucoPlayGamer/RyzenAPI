-- Lua provided by RyzenAPI
-- Game: Ikonei Island: Friends' Pass

-- MAIN APPLICATION
addappid(2576450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576451, 1, "3d8980f41feb3a266c440d8cedc5fff0859bc3d5e82ccd0923f8ef8332bcc1e7")
