-- Lua provided by RyzenAPI
-- Game: Hundred Doors

-- MAIN APPLICATION
addappid(3892240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3892241,0,"0e953541533e341818c7594e2708bf8477fc5d28cc8cd17d3a5c549ff1cd928b")

