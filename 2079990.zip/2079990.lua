-- Lua provided by RyzenAPI
-- Game: Monch!

-- MAIN APPLICATION
addappid(2079990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079991, 1, "b2edd37d64b19aeb080a4d048fd4e259fd052f73118913e8ae07df75fb421393")
