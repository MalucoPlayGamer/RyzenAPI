-- Lua provided by RyzenAPI 
-- Game: AppID 774421
addappid(774421)
addappid(774422, 1, "d1bb907e0fa10e58da1bbac491538994ba881c3b246f184a315aa4048e164409")
