-- Lua provided by RyzenAPI
-- Game: girl agent - new clothes

-- MAIN APPLICATION
addappid(1788000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788000,0,"155b25a16ba1b49eb66790c4c9550a4afda63ca15f56be6fe4ac79a0dfc788db")
