-- Lua provided by RyzenAPI
-- Game: Kawaii Neko Girls 2

-- MAIN APPLICATION
addappid(1794330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794331, 1, "2c30fad16db07ac5648dc4c37d62c75f21eed4ef5125523f2a4c09282567214e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2313460)
addappid(2317530)
addappid(2317531)
addappid(2317532)
addappid(2317533)
addappid(2319450)
addappid(2611150)
