-- Lua provided by RyzenAPI
-- Game: addappid(1794330)

-- MAIN APPLICATION
addappid(1794330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794331, 1, "2c30fad16db07ac5648dc4c37d62c75f21eed4ef5125523f2a4c09282567214e")
