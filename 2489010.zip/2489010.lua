-- Lua provided by RyzenAPI
-- Game: Game: Geometry Survivor

-- MAIN APPLICATION
addappid(2489010)
-- Game: addappid(2489010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2489011, 1, "ed40469477a840b6008e2eb78b43f05b71a158521ead4236d33befb956b05185")
