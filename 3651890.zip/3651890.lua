-- Generated with Luie @ https://lua.tools/
-- 3651890 - Buried Below
-- Generated 2026-08-21 21:21:01 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(3651890)

-- Main Depots
addappid(3651891, 1, "359e160d8968850ae968f7195fa094e7d2efe33bf3c8789b0edfaa6afc5f038e") -- (windows)
setManifestid(3651891, "5528301607187138154", 768884993)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
