-- Lua provided by RyzenAPI
-- Game: Buried Below

-- MAIN APPLICATION
addappid(3651890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3651891, 1, "359e160d8968850ae968f7195fa094e7d2efe33bf3c8789b0edfaa6afc5f038e") -- (windows)

