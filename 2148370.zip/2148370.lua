-- Lua provided by RyzenAPI
-- Game: 2148370

-- MAIN APPLICATION
addappid(2148370)
-- Game: addappid(2148370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148371, 1, "331fa1a569d3a60f224fee5a8ce060d3c19986cef131b2bca1bb073f2b786dfb")
