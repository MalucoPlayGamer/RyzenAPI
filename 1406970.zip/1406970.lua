-- Lua provided by RyzenAPI
-- Game: addappid(1406970)

-- MAIN APPLICATION
addappid(1406970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406971, 1, "d880928f6b9f4fdd32c1337ed33a5439af2e87916c835c733fa2c25f5c0c7c3a")
