-- Lua provided by RyzenAPI
-- Game: Light of Alariya OST

-- MAIN APPLICATION
addappid(2385430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385431, 1, "93f4651b4b6cae57ea282d4e561ba608882e2322b941b2b503300821a11040c9")

