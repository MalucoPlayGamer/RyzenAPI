-- Lua provided by RyzenAPI
-- Game: Rhino Puzzle

-- MAIN APPLICATION
addappid(2556090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556091, 1, "287f5223acc482c1ec19d2f295c0a0732aadba0aacc1d6646a5ce89f0ab0cfdf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
