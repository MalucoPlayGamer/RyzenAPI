-- Lua provided by RyzenAPI
-- Game: Game: Rhino Puzzle

-- MAIN APPLICATION
addappid(2556090)
-- Game: addappid(2556090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556091, 1, "287f5223acc482c1ec19d2f295c0a0732aadba0aacc1d6646a5ce89f0ab0cfdf")
