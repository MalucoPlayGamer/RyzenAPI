-- Lua provided by RyzenAPI
-- Game: 2455190

-- MAIN APPLICATION
addappid(2455190)
-- Game: addappid(2455190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455191, 1, "4d367a56222ec3f5b1019a82fb459ea4cffaa488c44e67d498bd37551e35f289")
