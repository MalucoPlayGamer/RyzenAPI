-- Lua provided by SkyAPI 
-- Game: AppID 1035610
addappid(1035610)
addappid(1035611, 1, "df553d55a0171bac0edde05e7c446f24fc8998825626eb5eb8cd6c6a8178059c")
addappid(1035612, 1, "fbb5c347f7d47df5daf70825e91dcdcfec998bf5d45b0aa238982e2c6f3b1066")
