-- Lua provided by SkyAPI 
-- Game: Armajet
addappid(895670)
addappid(895671, 1, "0b5d91abd7ad1c897e5a68bc5aa9216f47e73fa8542bdbcd5e51cd6bbcc7424c")
addappid(895672, 1, "2aa8a8f70d798b3ec6e5c4fdddb31f6cef13ab41b4eddd3c358ac57d98bbf66f")
