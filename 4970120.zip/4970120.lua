-- Lua provided by RyzenAPI
-- Game: Museum of Lost Dinosaurs

-- MAIN APPLICATION
addappid(4970120) -- Museum of Lost Dinosaurs
-- addappid(4970129) -- Depot 4970129 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4970121, 1, "dac7a58916a5354162b0dca8d5262087f318eb8aafc7ab85db6418e5949ba5df") -- Depot 4970121

