-- Lua provided by RyzenAPI
-- Game: Areia

-- MAIN APPLICATION
addappid(768460)

-- MAIN APP DEPOTS / PACKAGES
addappid(768461,0,"6795b2862926acd56a16fce8c475eb40064822fd19f671f8415d3cb4def1ca58")

