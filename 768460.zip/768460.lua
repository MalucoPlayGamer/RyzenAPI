-- Lua provided by RyzenAPI
-- Game: Areia

-- MAIN APPLICATION
addappid(768460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(768461,0,"6795b2862926acd56a16fce8c475eb40064822fd19f671f8415d3cb4def1ca58")

