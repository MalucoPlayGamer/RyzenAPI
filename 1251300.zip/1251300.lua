-- Lua provided by RyzenAPI
-- Game: AppID 1251300

-- MAIN APPLICATION
addappid(1251300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251301, 1, "ac4ab38960a59ffa12d78eaba6aa1151aee2aa355cdbc8d50a3c0f836665a831")
