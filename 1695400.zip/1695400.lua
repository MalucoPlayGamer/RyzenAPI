-- Lua provided by RyzenAPI
-- Game: Lucky Fish Bread

-- MAIN APPLICATION
addappid(1695400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695401, 1, "4cad561b0bf42dded15892a0d724fcf7b15493a8867cf278257c7325d2524d95")

