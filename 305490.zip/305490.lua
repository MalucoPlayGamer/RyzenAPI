-- Lua provided by RyzenAPI
-- Game: 305490

-- MAIN APPLICATION
addappid(305490)
-- Game: addappid(305490)

-- MAIN APP DEPOTS / PACKAGES
addappid(305491, 1, "29feb0352500e8b6e9805f41f4c300594bcef1f41dc8cd272b70113da18fa42b")
addappid(307500, 0, "6653b6ecd658f8628c7987c0b7f8a9733cc060eedc3bd569c33b87b928ea579b")
