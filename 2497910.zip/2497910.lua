-- Lua provided by RyzenAPI
-- Game: Into the Dungeon

-- MAIN APPLICATION
addappid(2497910)
-- Game: addappid(2497910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497911, 1, "aa08cfa41dd72cc4b34a5af2f1551d8d950be670347f24ff9db4e8ed38f193d4")
