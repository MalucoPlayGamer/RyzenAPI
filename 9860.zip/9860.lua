-- Lua provided by RyzenAPI
-- Game: The Chronicles of Riddick™ Assault on Dark Athena

-- MAIN APPLICATION
addappid(9860)

-- MAIN APP DEPOTS / PACKAGES
addappid(9861, 1, "470ef566525a3a4d29d7711ab2632f5722fc9f42d3f3ba8cfe0eaef143ba5e32")
