-- Lua provided by RyzenAPI
-- Game: Game: Our Life: Beginnings & Always

-- MAIN APPLICATION
addappid(1129190)
-- Game: addappid(1129190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129191, 1, "34492bd890a7f9e38be22cfc9f4ca9c486567d9a604f50635c73d42e7aa2a946")
addappid(1464060, 0, "a118df11c3a17977dd268f8f78815983ac7657268992362e7ecfda5f2be169a8")
addappid(1464061, 0, "049b855c359159feb1e7b026acd3bd7142aca0da5c0440f4d4d732ca81e0418d")
addappid(1464062, 0, "306d00fb8cb054b2dfd034a8d0dcd6ef9b3fd7e33fc2000bd06a6b404cc4c8d5")
addappid(1464063, 0, "972b91307bfab3540c0a5aeee8350283babe1564ba0976a08b9991607c2872bf")
addappid(1854710, 0, "0414404dbda502ecdf4818abf3785ea9fb05d17acdeefeea7cf69d4da282a0e8")
addappid(2015100, 0, "e876dd5547e3c2c383205502f716821186a38c55ff41f8fa69cf36553f6fcefd")
addappid(2365280, 0, "6218826dc998cbc1048ef5e9ab1b120b2c76fdeb5b24706a3d6eaa920c66d40b")
