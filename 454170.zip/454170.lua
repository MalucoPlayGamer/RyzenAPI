-- Lua provided by RyzenAPI
-- Game: Game: XorceD - Sashiro's Laedrum

-- MAIN APPLICATION
addappid(454170)
-- Game: addappid(454170)

-- MAIN APP DEPOTS / PACKAGES
addappid(454171, 1, "bcb81ab9286fdce1f59d8ab2c6a0d7c4a786ece2c8b2c259c34830139944a00f")
