-- Lua provided by SkyAPI 
-- Game: Sightbringer
addappid(1400110)
addappid(1400111, 1, "805d2ad80568fa7c132cb58f52f144ac06764514083af0c86078ae94af2fde38")
