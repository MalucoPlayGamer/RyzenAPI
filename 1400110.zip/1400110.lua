-- Lua provided by RyzenAPI
-- Game: Sightbringer

-- MAIN APPLICATION
addappid(1400110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400111, 1, "805d2ad80568fa7c132cb58f52f144ac06764514083af0c86078ae94af2fde38")

