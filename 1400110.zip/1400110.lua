-- Lua provided by RyzenAPI
-- Game: Sightbringer

-- MAIN APPLICATION
addappid(1400110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400111, 1, "805d2ad80568fa7c132cb58f52f144ac06764514083af0c86078ae94af2fde38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
