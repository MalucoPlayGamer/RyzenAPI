-- Lua provided by RyzenAPI
-- Game: My Furry Neighbour - 18+ Adult Only Patch 🐾

-- MAIN APPLICATION
addappid(1705910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705910,0,"890fd9531575a1ec6879febc262edd2e4d6142876718a8b6ec5d104a081f7569")

