-- Lua provided by RyzenAPI
-- Game: 2183170

-- MAIN APPLICATION
addappid(2183170)
addappid(2263100)
-- Game: addappid(2183170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183171, 1, "e375ae454a453b5607439461fa16bb4908c492946cbd561acee4db3a3f85b1c2")
