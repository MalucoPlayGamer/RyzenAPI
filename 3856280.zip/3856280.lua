-- Lua provided by RyzenAPI
-- Game: holoVillage: Our Cozy Days

-- MAIN APPLICATION
addappid(3856280)
addappid(4582350)
addappid(5059200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3856281,0,"dd5dafbfa6d1302c7f7028e7aa17faba71d57b0b38aecaeaf14a23553904ad77")
