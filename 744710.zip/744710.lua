-- Lua provided by RyzenAPI
-- Game: Kungfu Beggar

-- MAIN APPLICATION
addappid(744710)

-- MAIN APP DEPOTS / PACKAGES
addappid(744711,0,"d933f87b746f8d9823556cfcfede77115cec797dffe300188c0b121609f45b7b")

