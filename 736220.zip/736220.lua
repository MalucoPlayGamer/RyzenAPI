-- Lua provided by RyzenAPI
-- Game: AppID 736220

-- MAIN APPLICATION
addappid(736220)
-- Game: addappid(736220)

-- MAIN APP DEPOTS / PACKAGES
addappid(736221, 1, "672051e5cb7894f0c6168ddb34c61671100323d964ab8d5dba04eda83db1a5d2")
