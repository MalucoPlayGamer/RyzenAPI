-- Lua provided by RyzenAPI
-- Game: addappid(1818590)

-- MAIN APPLICATION
addappid(1818590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818591, 1, "e27feed702bdd5348d3a9683e3c9131a90b780d3c072db75602addb8bada284c")
