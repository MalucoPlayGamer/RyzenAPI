-- Lua provided by RyzenAPI
-- Game: 214640

-- MAIN APPLICATION
addappid(214631)
addappid(214633)
addappid(214635)
addappid(214636)
addappid(214637)
addappid(214638)
addappid(214640)
addappid(214643)

-- MAIN APP DEPOTS / PACKAGES
addappid(214634,0,"06082554b254b4f2109aa1af5abe42d001cb05f5fff01ffc38d20339ad9cd0d3")
addappid(214645,0,"6b22dcf0120eec6c5325356e6f881820c99d077ce7a358b2bf7023447f51f672")
addappid(214647,0,"6cb4d4a4e558b3d83d5f40d0493e8cb1ede9c0b83ea32dab40c3751916aee923")
