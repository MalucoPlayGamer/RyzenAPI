-- Lua provided by RyzenAPI
-- Game: Sexual Void

-- MAIN APPLICATION
addappid(1310910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1310911, 1, "b635f30be36839cc68eb397846d63f82beb744fadef5fac374d87df6b309b5cb")

