-- Lua provided by RyzenAPI
-- Game: Sexual Void

-- MAIN APPLICATION
addappid(1310910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310911, 1, "b635f30be36839cc68eb397846d63f82beb744fadef5fac374d87df6b309b5cb")
