-- Lua provided by RyzenAPI
-- Game: Game: Max Payne

-- MAIN APPLICATION
addappid(12140)
-- Game: addappid(12140)

-- MAIN APP DEPOTS / PACKAGES
addappid(12141, 1, "852706f81744732c81de6bb29ee0c7bde48941cbdde1b270c0def608d8414827")
