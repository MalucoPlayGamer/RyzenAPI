-- Lua provided by RyzenAPI
-- Game: Ants Took My Eyeball

-- MAIN APPLICATION
addappid(1627890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627891, 1, "b861249ab7ffd634b52c15ed3a318456e388e4c4f1a666163f43c96121315139")
