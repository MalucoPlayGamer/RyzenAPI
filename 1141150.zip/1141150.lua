-- Lua provided by RyzenAPI
-- Game: The Defender: Farm and Castle 2

-- MAIN APPLICATION
addappid(1141150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141151, 1, "964625d477a86a0fecb4e58c08e5154a33afffd0b4d5e47d9cb9ad7742531bbc")

