-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG Character Pack 10

-- MAIN APPLICATION
addappid(2531620)
-- Game: addappid(2531620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531620,0,"11494433f817983cb2dc8af626b1627564de7498046a4f506c64ed580a53ec05")
