-- Lua provided by RyzenAPI
-- Game: Terracards Demo

-- MAIN APPLICATION
addappid(2601560)
-- Game: addappid(2601560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601561, 1, "35aefdb53813d681f45a2743574717e2a686470a82cf3fa3198a6c3507a263a7")
