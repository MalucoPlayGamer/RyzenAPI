-- Lua provided by RyzenAPI
-- Game: Germ Wars

-- MAIN APPLICATION
addappid(557680)
addappid(561800)

-- MAIN APP DEPOTS / PACKAGES
addappid(557681, 1, "0c73adf044879c486af9af9e21ff2c0673a6bdc41b32913f403c2442e77ff838")
