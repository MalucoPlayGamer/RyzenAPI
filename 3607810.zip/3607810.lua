-- Lua provided by RyzenAPI
-- Game: Created: August 07, 2026 at 07:22:41 EDT

-- MAIN APPLICATION
addappid(3607810) -- 灵魂•绝境防线

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3607811, 1, "72892fe1c6e189de6821b6553c2bb5ff9439d6adedd46253cc9c27035c194bd5") -- Depot 3607811

