-- Lua provided by RyzenAPI
-- Game: My Protogen Engineer ⚙️

-- MAIN APPLICATION
addappid(2844500)
-- Game: addappid(2844500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844501, 1, "52c480bb50eb704c996b3d0f311c5f6c8474768dfc8f863d3919d4d4f0f82521")
addappid(2877970, 0, "8aa121adb77af7a3b243747702002e66031133877c67255ec37700bc3c8e80e3")
