-- Lua provided by RyzenAPI
-- Game: Game: IKAROS

-- MAIN APPLICATION
addappid(669440)
-- Game: addappid(669440)

-- MAIN APP DEPOTS / PACKAGES
addappid(669441, 1, "4bcca51e3b291e930302a320d16849294ac7c58230f9473c2e18f84180ab2780")
