-- Lua provided by RyzenAPI
-- Game: Escape Bloody Mary

-- MAIN APPLICATION
addappid(544530)

-- MAIN APP DEPOTS / PACKAGES
addappid(544531, 1, "fc268b08aa96e6b28bb78370a0e3b7ab64e8829bedf5e1462afef1fa0a4610d6")

