-- Lua provided by RyzenAPI 
-- Game: Escape Bloody Mary
addappid(544530)
addappid(544531, 1, "fc268b08aa96e6b28bb78370a0e3b7ab64e8829bedf5e1462afef1fa0a4610d6")
