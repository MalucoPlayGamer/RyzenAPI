-- Lua provided by RyzenAPI
-- Game: AppID 2800150

-- MAIN APPLICATION
addappid(2800150)
-- Game: addappid(2800150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800151, 1, "baf6c96f78b00ec6ca32c0ca01587940819f92cbd1de4f0deff3d26d13f6b3ce")
