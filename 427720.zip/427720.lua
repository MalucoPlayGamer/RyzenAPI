-- Lua provided by RyzenAPI
-- Game: 427720

-- MAIN APPLICATION
addappid(427720)
-- Game: addappid(427720)

-- MAIN APP DEPOTS / PACKAGES
addappid(427721, 1, "91ee42a5dc8087fcc9657a243a66602a3c6ac368526f28e612f76c1850cb461a")
addappid(427722, 1, "6b2eec1d261d5c51c2d8118c51329852cdd97ac60a9ebd148fef0963a7b0b402")
