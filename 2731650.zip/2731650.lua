-- Lua provided by RyzenAPI
-- Game: Desperate ESCAPE

-- MAIN APPLICATION
addappid(2731650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731651, 1, "311ed92caca72dfe61e3775719fcfbdf824bd1bfc106b2a11dfb03b4f4bc7523")
