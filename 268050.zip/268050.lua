-- Lua provided by RyzenAPI
-- Game: AppID 268050

-- MAIN APPLICATION
addappid(268050)
addappid(318750)
addappid(345980)
addappid(354710)
-- Game: addappid(268050)

-- MAIN APP DEPOTS / PACKAGES
addappid(268051, 1, "93ee80eca527bcfb7d775351a682fee43cb7e507105958ade0b022e19a59f4d0")
addappid(268052, 1, "2f35291eae1dedeb25ab35a40987c05dee10afd39883acdd1eb86f411ffbdc01")
addappid(268053, 1, "84748307b8aaef4518f3657e9d2250072898e781824478f78f33197b5c157d10")
addappid(359930, 0, "bad4fe532d4b0af4716ada1632250ca9a4993e693615aee74b8a5cd50872b8e2")
addappid(446950, 0, "bf30aa6a29252e5fedf5bb424228fa5549eb907f08ffebe3769e98c9d32e36cd")
