-- Lua provided by RyzenAPI
-- Game: 2793140

-- MAIN APPLICATION
addappid(2793140)
-- Game: addappid(2793140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793141, 1, "d5a05eb313cfff210b21c96834ef71fbf5733275bf5d68d119f3f93f4b9ed560")
