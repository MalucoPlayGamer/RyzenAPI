-- Lua provided by RyzenAPI
-- Game: Ginseng Hero

-- MAIN APPLICATION
addappid(1290110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290111, 1, "0ee8e186512846190744787c9669c8ce7deb690b30197c3cc49e9604bcb1f245")

