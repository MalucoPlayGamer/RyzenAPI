-- Lua provided by RyzenAPI
-- Game: YOHANE THE PARHELION -BLAZE in the DEEPBLUE-

-- MAIN APPLICATION
addappid(2404370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2404371, 1, "83ef7aab1e3125613b1ef53da60e1b3bc1b1291a3ae03387b8807a4fe49b1378")

