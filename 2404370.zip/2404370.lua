-- Lua provided by RyzenAPI
-- Game: addappid(2404370)

-- MAIN APPLICATION
addappid(2404370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404371, 1, "83ef7aab1e3125613b1ef53da60e1b3bc1b1291a3ae03387b8807a4fe49b1378")
