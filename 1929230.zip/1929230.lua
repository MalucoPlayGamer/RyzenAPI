-- Lua provided by RyzenAPI
-- Game: Lost Lives

-- MAIN APPLICATION
addappid(1929230)
addappid(4827780)

