-- Lua provided by RyzenAPI
-- Game: Lost Lives

-- MAIN APPLICATION
addappid(1929230)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4827780)
