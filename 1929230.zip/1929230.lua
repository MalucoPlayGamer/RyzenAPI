-- Lua provided by RyzenAPI
-- Game: Lost Lives

-- MAIN APPLICATION
addappid(1929230)

