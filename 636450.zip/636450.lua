-- Lua provided by RyzenAPI
-- Game: Rez Infinite

-- MAIN APPLICATION
addappid(636450)

-- MAIN APP DEPOTS / PACKAGES
addappid(636451, 1, "5384f89f3e08dce9012fba611907bccb57b9868ae06aa32a08c9cd1db0190284")
addappid(689950, 0, "174fc08cf5479cae59e5b78702ae24b0dcf9d314ff8612bdac4b2d02df3bb751")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
