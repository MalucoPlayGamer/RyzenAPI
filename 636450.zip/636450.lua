-- Lua provided by RyzenAPI
-- Game: 636450

-- MAIN APPLICATION
addappid(636450)
-- Game: addappid(636450)

-- MAIN APP DEPOTS / PACKAGES
addappid(636451, 1, "5384f89f3e08dce9012fba611907bccb57b9868ae06aa32a08c9cd1db0190284")
addappid(689950, 0, "174fc08cf5479cae59e5b78702ae24b0dcf9d314ff8612bdac4b2d02df3bb751")
