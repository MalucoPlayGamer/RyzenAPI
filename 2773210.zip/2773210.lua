-- Lua provided by RyzenAPI
-- Game: Guild Saga: Vanished Worlds Demo

-- MAIN APPLICATION
addappid(2773210)
-- Game: addappid(2773210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773211, 1, "91fab18fa41c2d63b3252db8a2403febd691d396afaf636f0859253339195f11")
