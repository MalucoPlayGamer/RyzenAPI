-- Lua provided by RyzenAPI
-- Game: Game: AppID 1019630

-- MAIN APPLICATION
addappid(1019630)
-- Game: addappid(1019630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019631, 1, "3781dd109f8cf977fe96a8136bde6a7d5d09426ba22044c5b7033b0febc470ed")
