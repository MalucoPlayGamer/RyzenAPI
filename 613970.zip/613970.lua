-- Lua provided by RyzenAPI
-- Game: Bravery: Rise of The Last Hero

-- MAIN APPLICATION
addappid(613970)

-- MAIN APP DEPOTS / PACKAGES
addappid(613971,0,"85f7ef9b79d1625383e5ff2d918941429bf3dfa0e24e07760daeb9363329bdd9")

