-- Lua provided by RyzenAPI
-- Game: Bravery: Rise of The Last Hero

-- MAIN APPLICATION
addappid(613970)

-- MAIN APP DEPOTS / PACKAGES
addappid(613971,0,"85f7ef9b79d1625383e5ff2d918941429bf3dfa0e24e07760daeb9363329bdd9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
