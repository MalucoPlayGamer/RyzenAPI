-- Lua provided by SkyAPI 
-- Game: Meme Mayhem
addappid(2719030)
addappid(2719031, 1, "1f950d77bd89fc305dd52b04e86601519a05bc655a1f5015277443b3c7e52636")
