-- Lua provided by RyzenAPI
-- Game: Packmates

-- MAIN APPLICATION
addappid(3171540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171541,0,"e3a7d23611ea543338a537cd23b843767ca7d75ee533376604150a94eddf725e")

