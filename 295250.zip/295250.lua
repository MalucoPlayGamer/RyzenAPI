-- Lua provided by RyzenAPI
-- Game: Stranded

-- MAIN APPLICATION
addappid(295250)
-- Game: addappid(295250)

-- MAIN APP DEPOTS / PACKAGES
addappid(295251, 1, "8d679fcef449a7663e6d1fd3984359250acaa4fd09f3cbbdc392de117c34dce6")
addappid(295252, 1, "9e043aba27131ee7c8c0f874481931c82af2cf473192898768951ef86790715f")
addappid(295253, 1, "294a663c4e05bf015ae4fba1c3e3657293c60d5693a2db3d3c3e36048b2f9f9d")
