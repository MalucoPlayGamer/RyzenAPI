-- Lua provided by RyzenAPI
-- Game: addappid(2786490)

-- MAIN APPLICATION
addappid(2786490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786491, 1, "c5343ffb97ba09aca1aa3ad974ae1d16753c2beaa90e7b9c30e030fc1fd30550")
