-- Lua provided by RyzenAPI
-- Game: LowPoly Towerdefense

-- MAIN APPLICATION
addappid(2786490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786491, 1, "c5343ffb97ba09aca1aa3ad974ae1d16753c2beaa90e7b9c30e030fc1fd30550")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
