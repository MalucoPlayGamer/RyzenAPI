-- Lua provided by RyzenAPI 
-- Game: Poly Plaza
addappid(2716030)
addappid(2716031, 1, "f1b1366838fb417254bd6cb4db091871ae4c07661af92bc40295cfe3f7c0ff11")
