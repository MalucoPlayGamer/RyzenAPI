-- Lua provided by RyzenAPI
-- Game: Poly Plaza

-- MAIN APPLICATION
addappid(2716030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716031, 1, "f1b1366838fb417254bd6cb4db091871ae4c07661af92bc40295cfe3f7c0ff11")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3235010)
addappid(3248660)
addappid(3248680)
addappid(3667250)
