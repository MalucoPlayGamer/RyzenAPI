-- Lua provided by RyzenAPI
-- Game: 元卡牌2 - MetaCard2

-- MAIN APPLICATION
addappid(2669440)
-- Game: addappid(2669440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669441, 1, "c4125b3ef8521ae6cf11084f70ed64e938b317e6f1e3234e16611882c7cd02f7")
