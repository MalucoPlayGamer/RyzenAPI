-- 3968160's Lua and Manifest Created by Hubcap Manifest
-- Island Beekeeper
-- Created: July 29, 2026 at 04:44:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3968160) -- Island Beekeeper
-- MAIN APP DEPOTS
addappid(3968161, 1, "af816085a8fd45a18630f365ad54237285bcc8de9aa0f91fa9609c918fe59b79") -- Depot 3968161
setManifestid(3968161, "688867181287844539", 1542014186)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)