-- Lua provided by RyzenAPI
-- Game: 1323890

-- MAIN APPLICATION
addappid(1323890)
-- Game: addappid(1323890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323891, 1, "333eba719a0a357ede32d47f2293b5c063ca30bb0045d25a0d6e1d2d2adbcada")
