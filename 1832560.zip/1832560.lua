-- Lua provided by RyzenAPI
-- Game: 1832560

-- MAIN APPLICATION
addappid(1832560)
-- Game: addappid(1832560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832561, 1, "5c1f10dcc0fb6792c2ec86615fd506730c225267ed1f8521f76df649fd94f911")
