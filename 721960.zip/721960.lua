-- Lua provided by RyzenAPI
-- Game: AppID 721960

-- MAIN APPLICATION
addappid(721960)

-- MAIN APP DEPOTS / PACKAGES
addappid(721961, 1, "20993c8d2f47b568cebfa440bbcdd51b405ac1f53a48177234767fcbfb0f0280")
