-- Lua provided by RyzenAPI
-- Game: 心の闇の先に Trial VersionⅡ

-- MAIN APPLICATION
addappid(661700)
-- Game: addappid(661700)

-- MAIN APP DEPOTS / PACKAGES
addappid(661701, 1, "adedb13823047e7e5ce8e4f38b781946df0e3d48a3d72bc987f8b74f0d8aab2c")
