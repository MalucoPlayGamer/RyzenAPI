-- Lua provided by RyzenAPI
-- Game: Nope Nope Nurses

-- MAIN APPLICATION
addappid(1846330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846331, 1, "c469d24d80b5f030ec12ae02b3267645a7d2d2643ce9c7e253f985d91ffbbd4d")

