-- Lua provided by RyzenAPI
-- Game: AppID 314560

-- MAIN APPLICATION
addappid(314560)
addappid(378650)
addappid(389960)

-- MAIN APP DEPOTS / PACKAGES
addappid(314561, 1, "1f6bc42e925663cd834be5447e3c6dfc2d8bb0ffba1ac575fed30c6e91bc7209")

