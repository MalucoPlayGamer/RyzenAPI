-- Lua provided by RyzenAPI
-- Game: Hoodie Survivor and Super Hoodie Bros

-- MAIN APPLICATION
addappid(2883700)
-- Game: addappid(2883700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883701, 1, "4ae4fb8e13e9d087fd82b4ab79625903822be5fcc682ef01a58e3c18d16d36d7")
