-- Lua provided by RyzenAPI
-- Game: Game: Eleanor 3

-- MAIN APPLICATION
addappid(1116340)
-- Game: addappid(1116340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116341, 1, "f250e5ca7fa4ceb971dc7ba8644996a3ce5ebe82d27bfcf33069837efd434b95")
addappid(1426770, 0, "fa065c321d64f8c457414f8228d7a307b70cb16ea9396ff4906a8f203d39d9c2")
