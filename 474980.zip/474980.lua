-- Lua provided by RyzenAPI
-- Game: Cat President ~A More Purrfect Union~

-- MAIN APPLICATION
addappid(474980)

-- MAIN APP DEPOTS / PACKAGES
addappid(474981, 1, "243ac9912d333c4f2d5a542a55106f6401f2a8946664d08ada783a6bca7abb03")
