-- Lua provided by RyzenAPI
-- Game: Game: Puppycraft: Maze

-- MAIN APPLICATION
addappid(3458850)
-- Game: addappid(3458850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3458851, 1, "da2a94394d603697383486df7e6258e5c141165b5e4bca78b17acda2807bc7d7")
