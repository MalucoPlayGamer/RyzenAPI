-- Lua provided by RyzenAPI
-- Game: Soccer in a Box

-- MAIN APPLICATION
addappid(3231990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3231991, 1, "80afbdb4a975734a5e1585013b89e1e421f7429e63b9b103fb5c0a93e7bdd217")

