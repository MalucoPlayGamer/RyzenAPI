-- Lua provided by RyzenAPI
-- Game: PEG

-- MAIN APPLICATION
addappid(699600)
-- Game: addappid(699600)

-- MAIN APP DEPOTS / PACKAGES
addappid(699602,0,"941999aa7caf34de0b55a9f7dcfc8af7104100e6274472b851fbed9f04a09bc7")
addappid(699603,0,"1bed9e101671a90a77dc12496c8d0caa7c8657f47f22d14ec3503d20dff744f6")
