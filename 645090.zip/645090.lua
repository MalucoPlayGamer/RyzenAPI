-- Lua provided by RyzenAPI
-- Game: Zup! 5

-- MAIN APPLICATION
addappid(645090)
-- Game: addappid(645090)

-- MAIN APP DEPOTS / PACKAGES
addappid(645091, 1, "308e972820c9107d4cdf885ea44d863d7f105bea081d0df1e3f04166f3470e7f")
addappid(683060, 0, "161023177f8ef909dfef1e8c8447c9cb5e8de4627cd75e43311808db75c2a800")
