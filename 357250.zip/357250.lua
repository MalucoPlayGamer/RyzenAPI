-- Lua provided by RyzenAPI
-- Game: Sproggiwood Original Soundtrack

-- MAIN APPLICATION
addappid(357250)

-- MAIN APP DEPOTS / PACKAGES
addappid(357250,0,"94505937297e9d82402c24eb5d08d77dcc1b8996a76c4018e511e2db056accd2")

