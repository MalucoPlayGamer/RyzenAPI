-- Lua provided by RyzenAPI
-- Game: Fruit Stand Fortune

-- MAIN APPLICATION
addappid(3306030)
