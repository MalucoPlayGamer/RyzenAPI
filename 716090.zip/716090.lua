-- Lua provided by RyzenAPI
-- Game: Cottage Garden

-- MAIN APPLICATION
addappid(716090)

-- MAIN APP DEPOTS / PACKAGES
addappid(716091, 1, "0ef18bfa460c20a516f30bc465ee4ea0a3f57a90e83c5115c2b066e9cb317c08")

