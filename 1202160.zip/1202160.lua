-- Lua provided by SkyAPI 
-- Game: Choco Pixel
addappid(1202160)
addappid(1202161, 1, "6b421b19cb408765786f0fd42e5b204fbc90ab3c19bb0fad786f9e5b5fd89985")
