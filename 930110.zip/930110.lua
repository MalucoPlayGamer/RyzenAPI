-- Lua provided by RyzenAPI
-- Game: Game: Sufoco

-- MAIN APPLICATION
addappid(930110)
-- Game: addappid(930110)

-- MAIN APP DEPOTS / PACKAGES
addappid(930111, 1, "f022148a1f6c75e8f1bc46a4e87ac0081b8fa01ed139aa7dfc5b39d1c28743b7")
addappid(930112, 1, "8823556885fc81b03f41197398ad225e00e488d95209f90196ebddd7487b2e1a")
addappid(930113, 1, "123514b1d73ab82a4636ac685c1218ccdaf763138fff91bf508fe72ba17f5b0c")
addappid(930114, 1, "407dcb2a5d90ad46ca2a7a0cd52892db45ceb8b972e9711dc2a1bd17878aebde")
