-- Lua provided by RyzenAPI
-- Game: Cyberhunt

-- MAIN APPLICATION
addappid(636150)

-- MAIN APP DEPOTS / PACKAGES
addappid(636151, 1, "f064c91420e6b3a6e69499f96ffcacbfd14cc05232e9347da77272c8190105a1")
addappid(636152, 1, "503266d3bc47e5634908cc0ad739ccd66128626b82eab4f51109f36f6040e790")
addappid(636880, 0, "37219206f919b2ff0a12e9431049667438b03b7c4c66c3160ff753685ee27b58")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
