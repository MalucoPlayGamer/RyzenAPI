-- Lua provided by RyzenAPI
-- Game: VR垃圾分类_Refuse classification

-- MAIN APPLICATION
addappid(1139920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139921, 1, "2dd3035829a41f52e52e05a478b1657348ac710e08c2dc2d9f4f9e260048ef89")

