-- Lua provided by RyzenAPI
-- Game: Undying Flower

-- MAIN APPLICATION
addappid(3180670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180671, 1, "2f6d88840c619e27f567a8658375fa758593f041f8c7d8abcdb1f9f6f0d52f1c")

