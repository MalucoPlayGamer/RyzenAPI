-- Lua provided by RyzenAPI
-- Game: AppID 784080

-- MAIN APPLICATION
addappid(784080)
addappid(1456211)
-- Game: addappid(784080)

-- MAIN APP DEPOTS / PACKAGES
addappid(784081, 1, "b8b97d071286439862b9f60a8898a85f6e6c648afd1e3064b37f125523f14a46")
