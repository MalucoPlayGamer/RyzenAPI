-- Lua provided by RyzenAPI
-- Game: MechWarrior 5: Mercenaries

-- MAIN APPLICATION
addappid(784080)
addappid(1456180)
addappid(1456211)
addappid(1705820)
addappid(1969380)
addappid(2179800)
addappid(2489020)
addappid(2782050)
addappid(3799610)
addappid(4371500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(784081, 1, "b8b97d071286439862b9f60a8898a85f6e6c648afd1e3064b37f125523f14a46")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4849350)
