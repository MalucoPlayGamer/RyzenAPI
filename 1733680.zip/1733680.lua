-- Lua provided by RyzenAPI
-- Game: addappid(1733680)

-- MAIN APPLICATION
addappid(1733680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733681, 1, "24efaa341ef3d1d3721b35b4bd1b940c38b44db340057a79d7b8f8f83c1a6516")
