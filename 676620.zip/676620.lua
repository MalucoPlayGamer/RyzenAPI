-- Lua provided by RyzenAPI
-- Game: Robots: create AI

-- MAIN APPLICATION
addappid(676620)

-- MAIN APP DEPOTS / PACKAGES
addappid(676621, 1, "4b88a537a658d72f24bd44881e6de5e8b09df60acc39bd2f497dc3cb1c74ed9d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
