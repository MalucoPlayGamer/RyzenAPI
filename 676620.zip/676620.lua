-- Lua provided by RyzenAPI
-- Game: addappid(676620)

-- MAIN APPLICATION
addappid(676620)

-- MAIN APP DEPOTS / PACKAGES
addappid(676621, 1, "4b88a537a658d72f24bd44881e6de5e8b09df60acc39bd2f497dc3cb1c74ed9d")
