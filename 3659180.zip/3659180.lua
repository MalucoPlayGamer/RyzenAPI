-- Lua provided by RyzenAPI 
-- Game: ?? Movie Theater
addappid(3659180)
addappid(3659181, 1, "f2bd12ca475c39a70c61e39b606ddf5f9901171a6aa4092fa860e5b8916e7431")
