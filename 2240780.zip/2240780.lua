-- Lua provided by RyzenAPI
-- Game: 307 Racing

-- MAIN APPLICATION
addappid(2240780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240781, 1, "7ac4d8423bae7ccbf78449dc2055b39c859e8aeb2e790fa14c0ed609e67a2f14")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
