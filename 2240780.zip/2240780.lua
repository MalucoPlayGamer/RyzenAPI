-- Lua provided by RyzenAPI
-- Game: 307 Racing

-- MAIN APPLICATION
addappid(2240780)
-- Game: addappid(2240780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240781, 1, "7ac4d8423bae7ccbf78449dc2055b39c859e8aeb2e790fa14c0ed609e67a2f14")
