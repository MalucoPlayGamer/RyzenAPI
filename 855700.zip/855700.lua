-- Lua provided by RyzenAPI
-- Game: Trippy Jump

-- MAIN APPLICATION
addappid(855700)
-- Game: addappid(855700)

-- MAIN APP DEPOTS / PACKAGES
addappid(855701, 1, "043b934f306ed963b7ea7dcb0a12d219856ae65461562afc1cc08cfaf85acfb3")
