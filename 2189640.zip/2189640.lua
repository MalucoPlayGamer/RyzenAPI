-- Lua provided by RyzenAPI
-- Game: addappid(2189640)

-- MAIN APPLICATION
addappid(2189640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2189641, 1, "427c3215e5b4e78ac34cbaf932db1628a8c51b6ce6583ae6eb3ba97a7fcf8909")
