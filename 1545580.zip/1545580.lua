-- Lua provided by RyzenAPI
-- Game: Game: BattleJuice Alchemist Playtest

-- MAIN APPLICATION
addappid(1545580)
-- Game: addappid(1545580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545581, 1, "4ad9d65f52c759130eca35e628be0596b2f37935f5d7f2414e4ef1bb33924df5")
