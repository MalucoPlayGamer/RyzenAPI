-- Lua provided by RyzenAPI
-- Game: Melancholy Love

-- MAIN APPLICATION
addappid(1387460)
-- Game: addappid(1387460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387461, 1, "ff95a740fec2165d3b8842c8bb73e1137f4e4c04d760a9e2372c46bbf66de792")
