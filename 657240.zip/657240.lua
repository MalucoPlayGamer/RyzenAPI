-- Lua provided by RyzenAPI
-- Game: Tracks - The Train Set Game

-- MAIN APPLICATION
addappid(657240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(657241, 1, "96cac63efb7c80475bf18dbc8ef8aaca812bbc246d99a59fbc919f4c7493c0d1")
addappid(657242, 1, "61b88f22c008f7862db3a8e00ecb94ee3e96d07a597dd6d96623055a78d9fbe7")
addappid(1278630, 0, "bc7476b9f9885bc3deb85579dc00c11645b4901fe5282dd0cde79e46de1930ba")
addappid(1296900, 0, "9e981dc28c7c62e2b7e192a5074a5f981d9b7afcd3845af3769abea84e29998c")

