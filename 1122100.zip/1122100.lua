-- 1122100's Lua and Manifest Created by Hubcap Manifest
-- Giraffe and Annika
-- Created: March 16, 2026 at 16:50:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1122100, 1, "1477969e652d920a0a65c96795e1ed66f0c8bdf3ceee07b9f21ce20ccf2542a1") -- Giraffe and Annika
-- MAIN APP DEPOTS
addappid(1122101, 1, "1b0af53cc13f4dc38b37092d2b27d911fa3fcefaf8bd6b9d8992968a2080a854") -- Giraffe and Annika（ジラフとアンニカ） Content
setManifestid(1122101, "6683191667599911004", 3232730076)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Giraffe and Annika Art Book (AppID: 1868190)
addappid(1868190)
addappid(1868190, 1, "82b374108b1a0a1746898452bbdc6665c284a3362367c344babea6f09c344d5d") -- Giraffe and Annika Art Book - Depot 1868190
setManifestid(1868190, "4519497558983722080", 423535665)
-- Giraffe and Annika Comic Book (AppID: 1868200)
addappid(1868200)
addappid(1868200, 1, "8a165d99383f6f629cf49d6b7ec8d189097d098323412649e367af13f7db2cdc") -- Giraffe and Annika Comic Book - Depot 1868200
setManifestid(1868200, "1441814659624550963", 841243569)