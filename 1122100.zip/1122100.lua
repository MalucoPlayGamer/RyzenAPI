-- Lua provided by RyzenAPI
-- Game: Giraffe and Annika

-- MAIN APPLICATION
addappid(1868190)
addappid(1868200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1122100, 1, "1477969e652d920a0a65c96795e1ed66f0c8bdf3ceee07b9f21ce20ccf2542a1") -- Giraffe and Annika
addappid(1122101, 1, "1b0af53cc13f4dc38b37092d2b27d911fa3fcefaf8bd6b9d8992968a2080a854") -- Giraffe and Annika（ジラフとアンニカ） Content
addappid(1868190, 1, "82b374108b1a0a1746898452bbdc6665c284a3362367c344babea6f09c344d5d") -- Giraffe and Annika Art Book - Depot 1868190
addappid(1868200, 1, "8a165d99383f6f629cf49d6b7ec8d189097d098323412649e367af13f7db2cdc") -- Giraffe and Annika Comic Book - Depot 1868200

