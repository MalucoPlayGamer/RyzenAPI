-- Lua provided by RyzenAPI
-- Game: addappid(1122100)

-- MAIN APPLICATION
addappid(1122100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122101, 1, "1b0af53cc13f4dc38b37092d2b27d911fa3fcefaf8bd6b9d8992968a2080a854")
