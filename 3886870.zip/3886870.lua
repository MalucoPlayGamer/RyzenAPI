-- Lua provided by RyzenAPI
-- Game: Harem Fantasy

-- MAIN APPLICATION
addappid(4100560)
addappid(4100570)
addappid(4100580)
addappid(4449130) -- Harem Fantasy - Kinky Ninja Scroll DLC
addappid(4651540) -- Harem Fantasy - Femboy Futa Tales DLC
addappid(4651550) -- Harem Fantasy - The Concubine War DLC
addappid(4953720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3886870, 1, "9b47f3e8f4ab51b89c6efc0a400c614a0413b2ff34725ac18b5e323d7beeda44")
addappid(3886871, 1, "c6b3980edea75863215d46482708da35cf935d055507441fbe951db4df4dfafb")
addappid(3886872, 1, "20d6d0cf8c46555eccb346ca9383107526e7ccdfe00edeb6088b0c6df1e97d0f") -- (macos)
addappid(4100560, 1, "8390409fc3b76bd8571f0b21c6b0a78c721bea200fada524563272771c170a66")
addappid(4100570, 1, "f9e6cf7998f8450d65e201accab587edac609044f62bffa5637689eb976d092d")
addappid(4100580, 1, "78e8d761aef4788f92a7da24af70967cf92d6191052e75d4abe161721086dc27")

