-- Lua provided by RyzenAPI
-- Game: Game: Serin Fate

-- MAIN APPLICATION
addappid(1070860)
-- Game: addappid(1070860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070861, 1, "17aa61995c517a706995d71f2c80a661915c8721bbc99946e4af714e825c009e")
