-- Lua provided by RyzenAPI
-- Game: 776520

-- MAIN APPLICATION
addappid(776520)

-- MAIN APP DEPOTS / PACKAGES
addappid(776520,0,"565afb0c5345487abf68ab7ab5aa38d940abc8ad49a655085e70fccba083c503")
