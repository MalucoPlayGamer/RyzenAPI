-- Lua provided by RyzenAPI 
-- Game: AppID 2553370
addappid(2553370)
addappid(2553371, 1, "e574d01434ddeaed023ece1509884e9ea6eb6e7e835f5f94704ff143f49e77c8")
