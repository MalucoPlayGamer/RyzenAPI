-- Lua provided by RyzenAPI
-- Game: Swarm the City: Prologue

-- MAIN APPLICATION
addappid(1714740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714741, 1, "d7eeba345fd861fc74e54dea73f244a67fd45a94ae2bb6f783e54de384adecb5")
