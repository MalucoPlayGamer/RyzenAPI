-- Lua provided by RyzenAPI
-- Game: Game: Russian Prison Sport: OCHKO

-- MAIN APPLICATION
addappid(845730)
-- Game: addappid(845730)

-- MAIN APP DEPOTS / PACKAGES
addappid(845731, 1, "7ae872daecf150ff365f49bb2eae5c01373b58a46bcbe735a44b1fc9d7ab36a9")
addappid(845732, 1, "dc0d84cfb93ddf913a7f2c8cc9ab2c9bfccf3445ec3c455170f0814fd0ac77ad")
