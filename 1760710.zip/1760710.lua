-- Lua provided by RyzenAPI
-- Game: Infected Dawn

-- MAIN APPLICATION
addappid(1760710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1760712,0,"b998e543518250f6f737c0b75a9e738a3222a3926f5b12e05dcdd53002b07798")

