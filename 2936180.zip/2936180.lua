-- Lua provided by RyzenAPI
-- Game: 茜色

-- MAIN APPLICATION
addappid(2936180)
addappid(3345010)
-- Game: addappid(2936180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936181, 1, "32a43b73456ed97a64299a064753f9ca9818293b7a392b56577da28ab57c54df")
