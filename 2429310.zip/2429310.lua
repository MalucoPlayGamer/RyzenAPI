-- Lua provided by RyzenAPI
-- Game: Game: Noxious Weeds

-- MAIN APPLICATION
addappid(2429310)
-- Game: addappid(2429310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429311, 1, "bf35fdd65a21812ab84e387cc811a57d0fad9ba243601934d826aaf2fc5f6162")
addappid(2429312, 1, "488cf474998d7616da615d8d5c6dc022c27a5c7a6444d829f2405db4492e7e21")
