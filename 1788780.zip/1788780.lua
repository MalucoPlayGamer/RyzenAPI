-- Lua provided by RyzenAPI
-- Game: VenusBlood HOLLOW International

-- MAIN APPLICATION
addappid(1788780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(1788781, 1, "a4fef81ebca7ef2750259701ea2af6a4e8d4f8c90685f0307bc607192321d228")
addappid(1788782, 1, "ac244bffa9f83fc801d992f0fdbb2199b48291453b8d0be861b68bdc60c942fd")

