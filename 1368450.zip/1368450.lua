-- Lua provided by RyzenAPI
-- Game: ENDLESS Zone™

-- MAIN APPLICATION
addappid(1368450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368451, 1, "1dcf4dd2c76c53ed8514422afaa89a21bad1fbe31f053b3896b961f9d690935d")

