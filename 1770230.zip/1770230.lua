-- Lua provided by RyzenAPI
-- Game: Game: SudoKube

-- MAIN APPLICATION
addappid(1770230)
-- Game: addappid(1770230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770231, 1, "7239d87ce14e11307ff6bd505f65a37732f1ba5b9e02e6eb2783b5508372de76")
