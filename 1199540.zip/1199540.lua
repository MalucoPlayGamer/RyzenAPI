-- Lua provided by RyzenAPI
-- Game: Spartan Commander Realtime

-- MAIN APPLICATION
addappid(1199540)
-- Game: addappid(1199540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199541, 1, "313db57f5a16b44547dfd07cae7ff1c4dc9fc82e53c4af40b839aaac499c0ca9")
