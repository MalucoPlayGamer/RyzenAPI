-- Lua provided by RyzenAPI
-- Game: addappid(1506510)

-- MAIN APPLICATION
addappid(1506510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506511, 1, "dbbc2e988bb44dc68bab3e401f7b9ba7d1933a8196961987ff36c46e189297a1")
