-- Lua provided by RyzenAPI
-- Game: Tower!3D Pro - ZBAD airport

-- MAIN APPLICATION
addappid(1562950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562950,0,"b6400e1780404be2c0694003200c8e322346e3cf73a401bfcf0ef8f4db1571d6")
