-- Lua provided by RyzenAPI
-- Game: AppID 2009510

-- MAIN APPLICATION
addappid(2009510)
-- Game: addappid(2009510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009511, 1, "09b567343d2c2d98c4a830f7cf51d04b970599d51bf49f3520110dcc5774df5f")
