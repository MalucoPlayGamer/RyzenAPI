-- Lua provided by RyzenAPI
-- Game: Game: Below the Stone Demo

-- MAIN APPLICATION
addappid(2504970)
-- Game: addappid(2504970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504971, 1, "d840f576ccaa79a08f286de20b057846f15e8a14d1d481e4101cdab486e5af88")
