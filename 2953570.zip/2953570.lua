-- Lua provided by RyzenAPI 
-- Game: Slime Survivors
addappid(2953570)
addappid(2953571, 1, "1dd72a86f6cea38a8a77cb8a9b3d4c1446c79f08d6b9f9fe03abd3783bdd4199")
