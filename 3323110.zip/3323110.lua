-- Lua provided by RyzenAPI
-- Game: 大鹏 - The Roc 设定集

-- MAIN APPLICATION
addappid(3323110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3323110,0,"995a119be7e4d8378b1c176b931058b0032d3c135ddd427adfc58566f53a9ba2")

