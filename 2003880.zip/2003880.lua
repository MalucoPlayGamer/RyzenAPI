-- Lua provided by RyzenAPI
-- Game: 2003880

-- MAIN APPLICATION
addappid(2003880)
-- Game: addappid(2003880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003881, 1, "664bbab0af43c345085c136d373ebb0a1033c40429fa39e378b7fdaca1fd80e3")
