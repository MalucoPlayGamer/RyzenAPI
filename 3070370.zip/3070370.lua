-- Lua provided by RyzenAPI 
-- Game: Invasion of The Halloween Fiends
addappid(3070370)
addappid(3070371, 1, "632611f90b772984cb9cb3b2a4aef87363d0188693707ef6e96de0762c3917d2")
