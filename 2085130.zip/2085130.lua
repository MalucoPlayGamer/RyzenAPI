-- Lua provided by RyzenAPI
-- Game: Monster Girl Dormitory

-- MAIN APPLICATION
addappid(2085130)
-- Game: addappid(2085130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085131, 1, "c67a82f8f03c3a16959f55c798dc140173b83855208103f905dbba017db85e82")
addappid(2092780, 0, "e06bea39adcb233ada672c12ff7208e46c71cab9724b7e53bc9d97b362008f3a")
