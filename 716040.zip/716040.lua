-- Lua provided by RyzenAPI
-- Game: Hide and go boom

-- MAIN APPLICATION
addappid(716040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(716041, 1, "3f280e7daf598545ff77a0245bfb1882cdbfa49abfcc23f48e1068eeb75f670e")
addappid(716042, 1, "0be34b807993d7cf1b0ceb2e0cacf7f0926fa602225629a568e4e32a01187d5d")
addappid(716043, 1, "2a9e2dc3f1958858f53835799facec568eedf6010c4903302679c4f30ef6ea1b")
