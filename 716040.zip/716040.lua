-- Lua provided by RyzenAPI 
-- Game: AppID 716040
addappid(716040)
addappid(716041, 1, "3f280e7daf598545ff77a0245bfb1882cdbfa49abfcc23f48e1068eeb75f670e")
addappid(716042, 1, "0be34b807993d7cf1b0ceb2e0cacf7f0926fa602225629a568e4e32a01187d5d")
addappid(716043, 1, "2a9e2dc3f1958858f53835799facec568eedf6010c4903302679c4f30ef6ea1b")
