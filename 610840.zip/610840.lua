-- Lua provided by RyzenAPI
-- Game: Game: AppID 610840

-- MAIN APPLICATION
addappid(610840)
-- Game: addappid(610840)

-- MAIN APP DEPOTS / PACKAGES
addappid(610841, 1, "7e994dd8b013bc7ed69ac8464ef067614bc587efce8edc9d2527f64e40989854")
addappid(610842, 1, "6b65c92bb445937607d3f1e6ee36062eea68cb4e49edd7d0e13d6cbc3fbebded")
addappid(610843, 1, "8a07fd16ee360e8b3ce1dee5d5f10651dbe5eb6a5fba7bdbc7e49de42d9c57f0")
addappid(727630, 0, "5611ffa09657b34a045cf921c75ed124f08839cb00da2f082edf8d02baee7442")
