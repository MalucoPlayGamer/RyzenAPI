-- Lua provided by SkyAPI 
-- Game: TDP4: Team Battle
addappid(340540)
addappid(340541, 1, "f2e574cedb982d57bc70c6a338ef2b288a662aa1b9a85d2f2ea059753c21f7a4")
