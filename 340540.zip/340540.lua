-- Lua provided by RyzenAPI
-- Game: TDP4: Team Battle

-- MAIN APPLICATION
addappid(340540)

-- MAIN APP DEPOTS / PACKAGES
addappid(340541, 1, "f2e574cedb982d57bc70c6a338ef2b288a662aa1b9a85d2f2ea059753c21f7a4")
