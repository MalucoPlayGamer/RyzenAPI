-- 2678820's Lua and Manifest Created by Hubcap Manifest
-- Vector Strike
-- Created: August 13, 2026 at 11:07:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2678820, 1, "034047de3bd9d11b951ca54dd33c99c2e9d29e8cbbc268b88df15e2d5412c7a9") -- Vector Strike
-- MAIN APP DEPOTS
addappid(2678821, 1, "29b3b8ed7f7b8241baabe84ea2922a7e0f02a1312fb14ced6f1f43af043cf241") -- Depot 2678821
setManifestid(2678821, "2321155806253763769", 4579947011)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)