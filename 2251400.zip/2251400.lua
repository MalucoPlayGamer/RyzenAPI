-- Lua provided by RyzenAPI
-- Game: 2251400

-- MAIN APPLICATION
addappid(2251400)
-- Game: addappid(2251400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251401, 1, "764d3b25a6137d9b57a29b8b0c012befe232474a74ad6789a8dba423bed4b5a5")
