-- Lua provided by RyzenAPI
-- Game: Startide

-- MAIN APPLICATION
addappid(598500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(598501, 1, "f200e356c727439cb9668a0d157176c950c14e0b60c0171d22214233bf2f2ac0")
