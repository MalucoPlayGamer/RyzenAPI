-- Lua provided by RyzenAPI
-- Game: Game: AppID 598500

-- MAIN APPLICATION
addappid(598500)
-- Game: addappid(598500)

-- MAIN APP DEPOTS / PACKAGES
addappid(598501, 1, "f200e356c727439cb9668a0d157176c950c14e0b60c0171d22214233bf2f2ac0")
