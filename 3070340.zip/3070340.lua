-- Lua provided by RyzenAPI
-- Game: Escape From Clive

-- MAIN APPLICATION
addappid(3070340)
-- Game: addappid(3070340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070341, 1, "d83aeb12a136b90744f0e9f9e18425dda2a5c8501f32899f74daf5dc3d4ee5eb")
