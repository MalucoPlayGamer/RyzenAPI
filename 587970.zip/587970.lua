-- Lua provided by RyzenAPI
-- Game: addappid(587970)

-- MAIN APPLICATION
addappid(587970)

-- MAIN APP DEPOTS / PACKAGES
addappid(587972,0,"3a9e36f72162fcda62a23c8a6391eb73b4a6dd6e0ce9132609a86d95e377cbc2")
