-- Lua provided by RyzenAPI
-- Game: No Haste

-- MAIN APPLICATION
addappid(1826540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826541, 1, "34da739bbfaf26c6652d3804e12d1e5b9b7f5672a226f9ea3e3ad13ea777797e")

