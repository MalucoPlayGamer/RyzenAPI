-- Lua provided by RyzenAPI
-- Game: No Haste

-- MAIN APPLICATION
addappid(1826540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1826541, 1, "34da739bbfaf26c6652d3804e12d1e5b9b7f5672a226f9ea3e3ad13ea777797e")

