-- Lua provided by RyzenAPI
-- Game: HENTAI ARENA HOLY PUSSY

-- MAIN APPLICATION
addappid(1136440)
-- Game: addappid(1136440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136441, 1, "3bfa44ff268ddf53208d8938f8bddfcc9ce5c61752912e91926fe98c39ef066c")
