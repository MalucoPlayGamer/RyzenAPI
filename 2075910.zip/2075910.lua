-- Lua provided by RyzenAPI
-- Game: Affogato Demo

-- MAIN APPLICATION
addappid(2075910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075911, 1, "2ae5fe210d28234ae3d7d978bb2a2c3ac9568cd1878a3dd5407163e4d0c382b7")

