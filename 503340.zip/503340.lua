-- Lua provided by RyzenAPI
-- Game: Dig 4 Destruction

-- MAIN APPLICATION
addappid(503340)
addappid(524870)
addappid(525220)
addappid(525221)
addappid(525230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(503341, 1, "98a2b75e1b6f93f17ec70fdef09053d54b7a7b5adf761fe67ca2b00ac3996319")

