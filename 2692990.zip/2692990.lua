-- Lua provided by RyzenAPI
-- Game: DON'T SCREAM TOGETHER

-- MAIN APPLICATION
addappid(2692990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692991, 1, "9b971dfb6dc8c67c3cd15d90b0daf3432bca02a2816476c9d877630216b0ec9a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
