-- Lua provided by RyzenAPI
-- Game: 2692990

-- MAIN APPLICATION
addappid(2692990)
-- Game: addappid(2692990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692991, 1, "9b971dfb6dc8c67c3cd15d90b0daf3432bca02a2816476c9d877630216b0ec9a")
