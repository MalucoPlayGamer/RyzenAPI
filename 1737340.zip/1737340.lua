-- Lua provided by RyzenAPI
-- Game: Noobs Want to Live

-- MAIN APPLICATION
addappid(1737340)
-- Game: addappid(1737340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737341, 1, "f9085c091809af07337e7c98154e79778bf4c5999d3bd501393b9a3e37d13211")
addappid(1737342, 1, "d2178c9981f81b6e0463acd308f5b79df764da9b692738028c119c3d0a8cba71")
