-- Lua provided by RyzenAPI
-- Game: Game: UnEpic

-- MAIN APPLICATION
addappid(233980)
-- Game: addappid(233980)

-- MAIN APP DEPOTS / PACKAGES
addappid(233981, 1, "2254694605175e08a680c2c4ebd007b41a0fa882ea6cc44feaaa6b2184b5e927")
addappid(233982, 1, "cf0d234162e8eb6ffd6d2cb22a09573c77dd83af4e91049823777453af459cd1")
addappid(233983, 1, "5ce0d611b31e4acdefc10a69532b9f11993a7483839ed8d32ad25f9e85bd358d")
addappid(233984, 1, "b9ca0564d037e975894884a20c219eb92a6e741888f60bade8232ce712252b96")
addappid(233985, 1, "f41e0bdb9af6a87bbaf1b338e9e7235f8f45721effcd7e57556b3fbfe84f0942")
addappid(233986, 1, "ccb69e7aba1568372b5cbc1ddcc76681e00fecc8fc7031c04261ce888fba65fa")
addappid(542040, 0, "5a2771f255a827fe5a0556c37ec5c3dd7a1bb8d38f27e4ddaeabe165b6ea59e1")
