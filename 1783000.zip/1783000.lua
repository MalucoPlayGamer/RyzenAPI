-- Lua provided by RyzenAPI
-- Game: Diner Runners

-- MAIN APPLICATION
addappid(1783000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783001, 1, "c572481a31b63fa21badc070eb2e1ce59c5ea07b85b14bf07ca6686bd7f76d7f")

