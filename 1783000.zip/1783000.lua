-- Lua provided by RyzenAPI
-- Game: Diner Runners

-- MAIN APPLICATION
addappid(1783000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783001, 1, "c572481a31b63fa21badc070eb2e1ce59c5ea07b85b14bf07ca6686bd7f76d7f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
