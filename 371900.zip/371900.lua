-- Lua provided by RyzenAPI
-- Game: Pillar

-- MAIN APPLICATION
addappid(371900)
addappid(371930)

-- MAIN APP DEPOTS / PACKAGES
addappid(371901, 1, "e53d7672109ebe465ee40319bf14c9d13ab17911ca7343f7f5140511446b8ce4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
