-- Lua provided by RyzenAPI
-- Game: Pillar

-- MAIN APPLICATION
addappid(371900)
addappid(371930)

-- MAIN APP DEPOTS / PACKAGES
addappid(371901, 1, "e53d7672109ebe465ee40319bf14c9d13ab17911ca7343f7f5140511446b8ce4")

