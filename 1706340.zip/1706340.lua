-- Lua provided by RyzenAPI
-- Game: Big Klondike - Classic Solitaire

-- MAIN APPLICATION
addappid(1706340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706341, 1, "892f1c4723c73af74c1d01eef764dc101312cefdaead81db9e3dd91facf8a04a")
addappid(1706342, 1, "14c1c6c3e8e004454f32cb759529accd6c8956d6677389f8d053e7d4a5dd51aa")
addappid(1706343, 1, "bc38f30c678fe660718dd3c5b98580b8772a784edc007c1ea94d43f3acd87e7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1712190)
addappid(2634670)
addappid(2667390)
addappid(2684870)
addappid(2871770)
