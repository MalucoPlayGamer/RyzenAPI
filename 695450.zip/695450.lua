-- Lua provided by RyzenAPI
-- Game: Kingdom of the Dragon

-- MAIN APPLICATION
addappid(695450)

-- MAIN APP DEPOTS / PACKAGES
addappid(695451,0,"eb74c96df60ae7fac9df2fa6f7de5a614f05efc4348eb4c47169021a209a28c1")
addappid(695452,0,"fdd83db2fd49dd4d49b0730c8c9ad8573b4b1d41adaa0971d1c04e3976b0242f")

