-- Lua provided by RyzenAPI
-- Game: Midnight: Submersion Nightmare Horror Story Prologue

-- MAIN APPLICATION
addappid(1833050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833051, 1, "1e1ee16e71b9ff7d04bfb07738f652778f8674eacfe616f4cc34ec19491865d1")
