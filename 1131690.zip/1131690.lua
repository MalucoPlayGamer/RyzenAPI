-- Lua provided by RyzenAPI
-- Game: Xentripetal Force

-- MAIN APPLICATION
addappid(1131690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1131691, 1, "58e5c6637875d0a9073a407655f5e1ba2fb1ebd0edd3e6f3457ac93c7f7771eb")

