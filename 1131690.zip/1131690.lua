-- Lua provided by SkyAPI 
-- Game: AppID 1131690
addappid(1131690)
addappid(1131691, 1, "58e5c6637875d0a9073a407655f5e1ba2fb1ebd0edd3e6f3457ac93c7f7771eb")
