-- Lua provided by RyzenAPI
-- Game: Game: Fragile Feelings

-- MAIN APPLICATION
addappid(2025700)
-- Game: addappid(2025700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025701, 1, "480a9f11d3a51dc127deadfc2863f175189e65fdc1e5ed39f1372140c2dd8217")
