-- Lua provided by RyzenAPI 
-- Game: Echoes Of Spellcraft
addappid(3152290)
addappid(3152291, 1, "75a5bb76632b8f8baca37a208f4ff87c71ab9f20bfe380fbcff1d68d200d6a2f")
