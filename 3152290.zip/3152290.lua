-- Lua provided by RyzenAPI
-- Game: Echoes Of Spellcraft

-- MAIN APPLICATION
addappid(3152290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152291, 1, "75a5bb76632b8f8baca37a208f4ff87c71ab9f20bfe380fbcff1d68d200d6a2f")
