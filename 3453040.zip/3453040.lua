-- 3453040's Lua and Manifest Created by Hubcap Manifest
-- INFLATION Inc.
-- Created: July 20, 2026 at 22:37:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3453040) -- INFLATION Inc.
-- MAIN APP DEPOTS
addappid(3453041, 1, "e93875c644cc3d6bc5a03616d5f9620392048e8b33fe0fe0950c7ba0a5540a57") -- Depot 3453041
setManifestid(3453041, "6057264219518106527", 216654120)