-- Lua provided by RyzenAPI 
-- Game: AppID 1440530
addappid(1440530)
addappid(1440531, 1, "462a498997c70ea24bce59df3677bea5c158f61d07ab7a7717b8873b8c4a713c")
