-- Lua provided by RyzenAPI
-- Game: Calm Waters: A Point and Click Adventure

-- MAIN APPLICATION
addappid(541350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(541351, 1, "c4d505f20a89d2e8727aeca95ac5d5b2049490aaf3eaebdd55eb300de1fc3b22")
addappid(541352, 1, "f75aaf624085cf23351ba101d78942d2ec06d95c3311f5c0dc5c00bf66dd64dc")

