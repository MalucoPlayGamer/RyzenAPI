-- Lua provided by RyzenAPI
-- Game: addappid(541350)

-- MAIN APPLICATION
addappid(541350)

-- MAIN APP DEPOTS / PACKAGES
addappid(541351, 1, "c4d505f20a89d2e8727aeca95ac5d5b2049490aaf3eaebdd55eb300de1fc3b22")
addappid(541352, 1, "f75aaf624085cf23351ba101d78942d2ec06d95c3311f5c0dc5c00bf66dd64dc")
