-- Lua provided by RyzenAPI
-- Game: Game: AppID 895200

-- MAIN APPLICATION
addappid(895200)
-- Game: addappid(895200)

-- MAIN APP DEPOTS / PACKAGES
addappid(895201, 1, "8e4eff902a2fa6490c6cb9321caeb7e9f4815c963f7f0b60a5f197c372ae7047")
