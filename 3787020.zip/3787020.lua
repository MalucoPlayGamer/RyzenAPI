-- Lua provided by RyzenAPI
-- Game: addappid(3787020)

-- MAIN APPLICATION
addappid(3787020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3787021, 1, "9d3d90bed359759337a011e625c08a0cf35b3a3f7cfee8d07d2e44c318a24292")
