-- Lua provided by RyzenAPI
-- Game: AppID 1034370

-- MAIN APPLICATION
addappid(1034370)
-- Game: addappid(1034370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034371, 1, "e518cfceaacd574c98fd7706eb0879c8639756f18fe6cfa152adbf579d360a40")
addappid(1034374, 1, "b4c7dd2b492808021969403e6ffba71834f589fa2dae79f221ef2a802ef5fcb1")
