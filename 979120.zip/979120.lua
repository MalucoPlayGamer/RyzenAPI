-- Lua provided by RyzenAPI
-- Game: addappid(979120)

-- MAIN APPLICATION
addappid(979120)

-- MAIN APP DEPOTS / PACKAGES
addappid(979121, 1, "e02ef730cc4d71c2f8b8b035f733fa7d3b3ba3a4eb20205c474185c107dd3d55")
