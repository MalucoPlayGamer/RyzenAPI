-- Lua provided by RyzenAPI
-- Game: Game: 少侠传说 Playtest

-- MAIN APPLICATION
addappid(2135550)
-- Game: addappid(2135550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135551, 1, "1f3cf26e835dcbd20cb4bd80fd2dba9b1fd52a67b160a29531623dc875ad6e7c")
