-- Lua provided by RyzenAPI
-- Game: 2420540

-- MAIN APPLICATION
addappid(2420540)
-- Game: addappid(2420540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420541, 1, "3d4e899ecc761048fe275cb6ed6864ad8a88d31206b370344eb52e0b3d2effe5")
