-- Lua provided by RyzenAPI 
-- Game: Manivore
addappid(3601980)
addappid(3601981, 1, "3333ec8a55d5acab0b8821debe46173b6259b44522d3a00f3d111fe290f5176b")
