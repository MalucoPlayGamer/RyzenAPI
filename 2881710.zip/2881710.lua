-- Lua provided by RyzenAPI
-- Game: Lightyear Frontier Soundtrack

-- MAIN APPLICATION
addappid(2881710)
-- Game: addappid(2881710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881711, 1, "e691c5cd89bbc93b66ea915a5540c26bfe7ec7da70cbd09de6458eee374dcfd7")
addappid(2881712, 1, "79bfcbaa62bbb5870d3e1e2d09bcbaef392ae1a13611bcaa0ede56f2e3c58e56")
