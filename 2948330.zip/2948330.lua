-- Lua provided by RyzenAPI
-- Game: Bauhaus Bonk

-- MAIN APPLICATION
addappid(2948330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2948331, 1, "d34e94eecb8d922bc69cd88a56c8c0040a683b9e10aa97d81ec7f255ebff360c")
