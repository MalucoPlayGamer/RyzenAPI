-- Lua provided by RyzenAPI
-- Game: Land of War - The Beginning

-- MAIN APPLICATION
addappid(228990)
addappid(1146300)
addappid(1146301)
-- Game: addappid(1146300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146302,0,"44475b55d86f9ca6c724ad0c8875d654835abe5ecf35822c8cd2bc89a0653b9c")
