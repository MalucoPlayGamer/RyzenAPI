-- Lua provided by RyzenAPI
-- Game: Land of War - The Beginning

-- MAIN APPLICATION
addappid(1146300)
addappid(1593122)
addappid(1593123)
addappid(1593124)
addappid(1609280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146302,0,"44475b55d86f9ca6c724ad0c8875d654835abe5ecf35822c8cd2bc89a0653b9c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
