-- Lua provided by RyzenAPI
-- Game: Caveblazers Soundtrack

-- MAIN APPLICATION
addappid(641430)
-- Game: addappid(641430)

-- MAIN APP DEPOTS / PACKAGES
addappid(641431, 1, "772d340f45cc131ec9a3b2f797d4b1ac309e62caad44b166851df96d82d71272")
