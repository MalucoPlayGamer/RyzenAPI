-- Lua provided by RyzenAPI
-- Game: Game: Gems of the Aztecs

-- MAIN APPLICATION
addappid(429280)
-- Game: addappid(429280)

-- MAIN APP DEPOTS / PACKAGES
addappid(429281, 1, "f65a903e0d4073eb6c1b0e14fb6711daf8e8e24e69f223a1f72323bac1d667b8")
addappid(429282, 1, "b1a3d4e2c71af1c8246c89a415988a7e869d487ece8a28dc172233efd181e4ce")
addappid(429283, 1, "b735360e7d0d508748f54985fa2c21ac0269e925a559e4641c8baa140b82d3e2")
addappid(429284, 1, "c8f1782ac4ae7445ee7520d2cf0ef1444f6f33cb231a2b02d15c77a270cc1a50")
addappid(429285, 1, "df8b9f6d450b3b39c21deb626321e17847ecfb2e7ceec67e4607900f1525ba13")
