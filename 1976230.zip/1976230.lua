-- Lua provided by RyzenAPI
-- Game: Game: Outnumbered

-- MAIN APPLICATION
addappid(1976230)
addappid(2140420)
-- Game: addappid(1976230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976231, 1, "92caf096eb637f9fe2b389ef98822c0a9a55de85ba2f017a61d3bbaaa6b40c4c")
