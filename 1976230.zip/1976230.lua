-- Lua provided by RyzenAPI 
-- Game: Outnumbered
addappid(1976230)
addappid(1976231, 1, "92caf096eb637f9fe2b389ef98822c0a9a55de85ba2f017a61d3bbaaa6b40c4c")
addappid(2140420)
