-- Lua provided by RyzenAPI
-- Game: Containment: The Zombie Puzzler

-- MAIN APPLICATION
addappid(203560)

-- MAIN APP DEPOTS / PACKAGES
addappid(203561, 1, "12425099ca9225227e294f8b4137af3a4e0b36826212bc1f2c3a4d5821ef78a4")
addappid(203563, 1, "f809a679da550e0f3a10a9e58bbc721ff3fd181b630349e32b5ed4f3ed069891")
addappid(203564, 1, "7c1036d48cc375d234fd66dd9b880b1d9d104c32d97380cf948cb7234f2ca4aa")

