-- Lua provided by RyzenAPI
-- Game: Templar 2

-- MAIN APPLICATION
addappid(2751580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751582,0,"03435cc464e2e08a2a465bef846461285242f555ca5e3efef5ddf24e5229d5a1")

