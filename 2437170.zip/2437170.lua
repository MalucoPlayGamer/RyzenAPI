-- Lua provided by RyzenAPI
-- Game: SMITE 2

-- MAIN APPLICATION
addappid(2437170)
addappid(2855200)
addappid(2855210)
addappid(2855220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2437171,0,"b812d1b17a2a57774d8eaf7f83f550ef62d7233a26b05d5133ad110d489f5600")

