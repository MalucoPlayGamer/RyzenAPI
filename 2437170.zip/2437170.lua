-- Lua provided by RyzenAPI
-- Game: SMITE 2

-- MAIN APPLICATION
addappid(2437170)
-- Game: addappid(2437170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437171, 1, "b812d1b17a2a57774d8eaf7f83f550ef62d7233a26b05d5133ad110d489f5600")
