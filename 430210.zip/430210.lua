-- Lua provided by SkyAPI 
-- Game: Megaton Rainfall
addappid(430210)
addappid(430211, 1, "3d473c67c4219a3740902def77ac1d1577a0a2340f4dbfee811f8751a9936910")
