-- Lua provided by RyzenAPI
-- Game: Megaton Rainfall

-- MAIN APPLICATION
addappid(430210)

-- MAIN APP DEPOTS / PACKAGES
addappid(430211, 1, "3d473c67c4219a3740902def77ac1d1577a0a2340f4dbfee811f8751a9936910")

