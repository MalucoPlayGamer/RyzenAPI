-- Lua provided by RyzenAPI
-- Game: Casual Mahjong

-- MAIN APPLICATION
addappid(2829320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2829321, 1, "c397bce6f3025b5ccbfa9ecbdc35717714e55112bc9779bcb805963a3a81dc8b")
