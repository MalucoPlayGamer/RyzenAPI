-- Lua provided by RyzenAPI
-- Game: Disney Winnie the Pooh

-- MAIN APPLICATION
addappid(319400)

-- MAIN APP DEPOTS / PACKAGES
addappid(319401, 1, "551b7b99b66500c02f21e4b95da73c2ab42055db2ffa74e6bedfc9ab228bd098")
addappid(319402, 1, "4028101e9ad6849d3cd0ad7779a8a7902930dce23990cf2e7843cfaad4252196")
addappid(319407, 1, "57b56a3324705e0bd4344a16a6a120fd00f886fd543a52991de9def9da0bba5d")
addappid(319408, 1, "94e7ef84ea16a863ba565c5c70d3d5436b442ad23558361191ed29a3dcb125aa")
addappid(319409, 1, "14a2eca3721b78ae009f12a626ad106366797e76db4172ab78efd93c7a4604a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
