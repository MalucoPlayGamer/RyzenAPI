-- Lua provided by RyzenAPI
-- Game: Rise of a Porn Star

-- MAIN APPLICATION
addappid(3174920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3174921, 1, "a4faf2ddfdb789c2c80dfa0fb7fa699a0cc898054250ae31a6ebbcf44de6b364")
