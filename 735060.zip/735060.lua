-- Lua provided by RyzenAPI
-- Game: The Forbidden Arts

-- MAIN APPLICATION
addappid(735060)

-- MAIN APP DEPOTS / PACKAGES
addappid(735061,0,"92dc135303786539f9521a46b8404eb2ccbc6d81b3dd9ec56150fd9b119ad545")
addappid(735062,0,"2bb9de701d385cd30cb62565972ebf72adc974362a785be57d9c0adcf757acf8")

