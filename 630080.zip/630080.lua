-- Lua provided by RyzenAPI
-- Game: EggTime 2

-- MAIN APPLICATION
addappid(630080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(630081, 1, "26367a736099871b54ad667611c679e8ae571e430297d725e15bf530f233cfb8")
