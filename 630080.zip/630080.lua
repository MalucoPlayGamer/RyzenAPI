-- Lua provided by RyzenAPI
-- Game: Game: AppID 630080

-- MAIN APPLICATION
addappid(630080)
-- Game: addappid(630080)

-- MAIN APP DEPOTS / PACKAGES
addappid(630081, 1, "26367a736099871b54ad667611c679e8ae571e430297d725e15bf530f233cfb8")
