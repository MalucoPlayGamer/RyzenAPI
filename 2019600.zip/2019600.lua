-- Lua provided by RyzenAPI
-- Game: 2019600

-- MAIN APPLICATION
addappid(2019600)
-- Game: addappid(2019600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019601, 1, "a1804922430b9745ac52368155a72c49dc3ed074e28b370b229ee0eee2e8dbcd")
