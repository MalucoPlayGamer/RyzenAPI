-- Lua provided by SkyAPI 
-- Game: Restaurant Renovator Demo
addappid(2019600)
addappid(2019601, 1, "a1804922430b9745ac52368155a72c49dc3ed074e28b370b229ee0eee2e8dbcd")
