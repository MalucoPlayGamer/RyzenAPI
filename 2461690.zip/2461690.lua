-- Lua provided by RyzenAPI
-- Game: Game: AppID 2461690

-- MAIN APPLICATION
addappid(2461690)
-- Game: addappid(2461690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461691, 1, "0d5c90dcfcd8056fd8eaca27d1916d2741ce846c4604824c97ffbcb514ef20f5")
