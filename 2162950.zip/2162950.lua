-- Lua provided by RyzenAPI
-- Game: A Maiden Astrologer Divines the Future

-- MAIN APPLICATION
addappid(2162950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2162951, 1, "01bfd8ea9dcbb9ca2b2ee39ee5e433749f00bcce91457ea597bac8b4c7107336")

