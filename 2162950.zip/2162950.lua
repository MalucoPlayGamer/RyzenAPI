-- Lua provided by RyzenAPI
-- Game: addappid(2162950)

-- MAIN APPLICATION
addappid(2162950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162951, 1, "01bfd8ea9dcbb9ca2b2ee39ee5e433749f00bcce91457ea597bac8b4c7107336")
