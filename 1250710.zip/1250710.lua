-- Lua provided by RyzenAPI
-- Game: 1250710

-- MAIN APPLICATION
addappid(1250710)
-- Game: addappid(1250710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250711, 1, "ab231b588f8f2216b5480e3db137cc8068732575f16c25bfe85d9a1cfdf8cc73")
