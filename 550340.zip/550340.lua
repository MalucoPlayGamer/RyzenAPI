-- Lua provided by RyzenAPI
-- Game: Umineko: Golden Fantasia

-- MAIN APPLICATION
addappid(550340)

-- MAIN APP DEPOTS / PACKAGES
addappid(550341, 1, "58454efda034f20404cbe031d52f3d53115b30c5abeafc087c614ccecee90e4b")
