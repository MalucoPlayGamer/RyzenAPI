-- Lua provided by RyzenAPI
-- Game: Zen of Sudoku

-- MAIN APPLICATION
addappid(4900)

-- MAIN APP DEPOTS / PACKAGES
addappid(4901, 1, "f0b9189a2e431982972fa454984db5454040a095760f472059c08ee079704f5c")

