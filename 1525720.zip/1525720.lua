-- Lua provided by RyzenAPI
-- Game: addappid(1525720)

-- MAIN APPLICATION
addappid(1525720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525721, 1, "b34b9e0534446e917b200c91ad83d4a33298b14b768dec625e2595a7b6fb17c6")
