-- Lua provided by SkyAPI 
-- Game: AppID 1143860
addappid(1143860)
addappid(1143861, 1, "51845a3cdec36475e220d8817072a3d8d42ea87d868c4812683e483ade4d1b55")
