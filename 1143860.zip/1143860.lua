-- Lua provided by RyzenAPI
-- Game: Zombie Admin

-- MAIN APPLICATION
addappid(1143860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1143861, 1, "51845a3cdec36475e220d8817072a3d8d42ea87d868c4812683e483ade4d1b55")
