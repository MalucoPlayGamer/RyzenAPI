-- Lua provided by RyzenAPI
-- Game: 1807140

-- MAIN APPLICATION
addappid(1807140)
-- Game: addappid(1807140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1807141, 1, "dadbca81f69bcff14c05b4737f8a1fba848cec502e880c2fcf62c2a0f4794ace")
