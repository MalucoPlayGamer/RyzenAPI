-- Lua provided by RyzenAPI
-- Game: Dangerous Plane

-- MAIN APPLICATION
addappid(1284140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284141, 1, "5425517ef420903a8d1eb6009d42b862be4a20c217e91c61329adc6811cb7f22")

