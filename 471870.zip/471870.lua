-- Lua provided by RyzenAPI
-- Game: addappid(471870)

-- MAIN APPLICATION
addappid(471870)

-- MAIN APP DEPOTS / PACKAGES
addappid(471871, 1, "97e66a7d5d1f2e340879d4554751b30ffbef75b2acda7fd7ac7980a8b9471d63")
