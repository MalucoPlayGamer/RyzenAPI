-- Lua provided by RyzenAPI
-- Game: Game: With My Past Demo

-- MAIN APPLICATION
addappid(2737790)
-- Game: addappid(2737790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737791, 1, "2f53bf7f5e9c8946eb120a1adfa3696ea78e91408be1a6ef8127d57f164252f5")
