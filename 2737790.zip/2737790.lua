-- Lua provided by RyzenAPI 
-- Game: With My Past Demo
addappid(2737790)
addappid(2737791, 1, "2f53bf7f5e9c8946eb120a1adfa3696ea78e91408be1a6ef8127d57f164252f5")
