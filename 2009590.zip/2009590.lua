-- Lua provided by RyzenAPI
-- Game: Passpartout 2: The Lost Artist Demo

-- MAIN APPLICATION
addappid(2009590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009591, 1, "07d0eea8afc44878aeff1fb63c4ea67de78f77cff38bb44fbf60848c8fdb5fec")

