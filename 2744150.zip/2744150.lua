-- Lua provided by RyzenAPI
-- Game: Proud To Love

-- MAIN APPLICATION
addappid(2744150)
-- Game: addappid(2744150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2744153,0,"e9495094314e25f67c926e391ea8eb82928011f97ec1cb5427047f30b6486ed6")
