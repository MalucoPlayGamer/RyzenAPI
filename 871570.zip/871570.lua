-- Lua provided by RyzenAPI 
-- Game: Summer Memory of Bell
addappid(871570)
addappid(871571, 1, "3c5f3c1fcdd1e4f1ea537cac44979e4b93ad4fce55deef5702db948a53e37e8b")
