-- Lua provided by RyzenAPI
-- Game: Talented Exorcist won't submit to Tentacle Demon

-- MAIN APPLICATION
addappid(2799920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799922,0,"6183fe3ba46d90609961b5c2e7c0021d3a60c7bd515323ba2d468d457871bb00")
addappid(2799923,0,"3c9dddf7e9a7ef7745dbc52209e3ca6925d7e0b701bcdf70bc45fc7bc42bc54c")
addappid(2799924,0,"1d2fc0a49f4c6ab43dc687a4e341f59ed12b271589a7ec5c3982e16bbb7f5c77")

