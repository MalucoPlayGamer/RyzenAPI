-- Lua provided by RyzenAPI
-- Game: addappid(3274170)

-- MAIN APPLICATION
addappid(3274170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274170,0,"848cd5582486e1ccb355b3e585ca90c23093c06409e2df865a5d92c28a7e1ca3")
