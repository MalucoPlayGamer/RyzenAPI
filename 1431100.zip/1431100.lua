-- Lua provided by RyzenAPI
-- Game: 1431100

-- MAIN APPLICATION
addappid(1431100)
-- Game: addappid(1431100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431101, 1, "0762b52c97022869d0394dc6e1c802d855105569fcd00e4ac4e00c952ebc5f2b")
