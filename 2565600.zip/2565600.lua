-- Lua provided by RyzenAPI
-- Game: Seybul Tech

-- MAIN APPLICATION
addappid(2565600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565601, 1, "1ca4af735086a7e4d14b59f60daace58eeaf0ea7b22a8b6e7b81c1177cd83099")
