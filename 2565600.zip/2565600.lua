-- Lua provided by SkyAPI 
-- Game: Seybul Tech
addappid(2565600)
addappid(2565601, 1, "1ca4af735086a7e4d14b59f60daace58eeaf0ea7b22a8b6e7b81c1177cd83099")
