-- Lua provided by RyzenAPI
-- Game: Prison Fights Simulator

-- MAIN APPLICATION
addappid(2962390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962391, 1, "5ee6ed8c2a20ab88f29e31e03f12db4709658e0a1bcc989a84741cfb64f18a2d")

