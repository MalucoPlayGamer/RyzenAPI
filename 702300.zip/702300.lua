-- Lua provided by RyzenAPI
-- Game: Number World Adventure

-- MAIN APPLICATION
addappid(702300)

-- MAIN APP DEPOTS / PACKAGES
addappid(702301,0,"2f17e2740ff8b22e989275c4c94e042822e6e7a33f0eff741c2246d8812c8ec5")

