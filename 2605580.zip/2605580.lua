-- Lua provided by RyzenAPI
-- Game: addappid(2605580)

-- MAIN APPLICATION
addappid(2605580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605581, 1, "8d3ba4c0a36702b11dd05e2ad6703921630a6b82091d10daef6620155bf49a82")
