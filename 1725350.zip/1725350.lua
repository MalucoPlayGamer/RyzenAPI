-- Lua provided by RyzenAPI
-- Game: Game: Mari and Bayu - The Road Home

-- MAIN APPLICATION
addappid(1725350)
-- Game: addappid(1725350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725351, 1, "0a68c9554cd30d4ee2a4729674d7b6164cf7f481a4cf3fa045a6e5ff429e22b9")
