-- Lua provided by RyzenAPI
-- Game: Game: 皇帝游戏：天下-皇游天下

-- MAIN APPLICATION
addappid(3067950)
-- Game: addappid(3067950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3067951, 1, "a010f40fb7ca2da5dcd250b854776a9611de8cd499466ae772a13c748c23137b")
