-- Lua provided by SkyAPI 
-- Game: Metal World: Street Scraps
addappid(1987050)
addappid(1987051, 1, "78334be45ea626bca9cb2ed8f6279858d729d7e5e333a97bcc42f934fd36eebf")
