-- Lua provided by RyzenAPI
-- Game: Metal World: Street Scraps

-- MAIN APPLICATION
addappid(1987050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987051, 1, "78334be45ea626bca9cb2ed8f6279858d729d7e5e333a97bcc42f934fd36eebf")

