-- Lua provided by RyzenAPI
-- Game: The Land of Glass

-- MAIN APPLICATION
addappid(802190)

-- MAIN APP DEPOTS / PACKAGES
addappid(802191,0,"b272f6461914e07007d6b203a35b2417a33e7f242f8340f5aaa8a61183bd1ae8")

