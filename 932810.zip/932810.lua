-- Lua provided by RyzenAPI
-- Game: BattleCry: World At War

-- MAIN APPLICATION
addappid(932810)

-- MAIN APP DEPOTS / PACKAGES
addappid(932811, 1, "7344f31e3673d0d24f6490cb6fdb11885bbacaf7850822f079aff62215c05537")
addappid(932812, 1, "a22afd06a8d9a8d6d1170c79ffacf391034a1d03d7017a60225fbc28b01b1a8b")
addappid(932813, 1, "5203b77c975ca6de1f7e8d5fd244e172d93d61045a7dcd0f6627b1fab572e21d")
addappid(932814, 1, "228325414f3ceadcf9cb580dd3e798b4ea62e55c1645f5b40928beac8fc1ff41")

