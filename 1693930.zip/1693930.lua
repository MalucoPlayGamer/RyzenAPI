-- Lua provided by RyzenAPI
-- Game: Game: 浮世万千三天地情殇

-- MAIN APPLICATION
addappid(1693930)
-- Game: addappid(1693930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693931, 1, "7a60ce11d3e07e695a6b4afeee75f8db6386b597ac0f99abeccfa2a32bea0906")
