-- Lua provided by RyzenAPI
-- Game: Stolen Realm Soundtrack

-- MAIN APPLICATION
addappid(2864540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2864542,0,"1167a8f658a2aaa4e7adb200e4e9739a6db2898e48f427a1a7fe84a7c6214d3f")
