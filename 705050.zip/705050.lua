-- Lua provided by RyzenAPI
-- Game: Game: Apocalypse: Legacy Edition

-- MAIN APPLICATION
addappid(705050)
addappid(720460)
-- Game: addappid(705050)

-- MAIN APP DEPOTS / PACKAGES
addappid(705051, 1, "4a267676eed68ac292478581b0b3c31cb0d55e21fd0cc5c60f0320a0d47f304a")
