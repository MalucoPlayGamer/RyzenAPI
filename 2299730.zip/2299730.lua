-- Lua provided by RyzenAPI 
-- Game: Dual Chroma: Academy Carols
addappid(2299730)
addappid(2299731, 1, "c0926aa5d5182e77d60f3ad40b8d1c27fdfbcc7490e36260332e1c40310f53a4")
