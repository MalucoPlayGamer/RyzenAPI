-- Lua provided by RyzenAPI
-- Game: addappid(1391000)

-- MAIN APPLICATION
addappid(1391000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391001, 1, "aa1029320e3c577ccb7b205af12a1c817bd2542ad282be7f9f38e13fd8dc61a3")
