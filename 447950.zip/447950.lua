-- Lua provided by RyzenAPI
-- Game: Bad Caterpillar

-- MAIN APPLICATION
addappid(447950)

-- MAIN APP DEPOTS / PACKAGES
addappid(447951, 1, "c262b781af41df2e2aaeea58a2c88cdb9a53007dcaf916acfd13ff86f5b98f6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
