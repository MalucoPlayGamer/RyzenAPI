-- Lua provided by RyzenAPI
-- Game: Bad Caterpillar

-- MAIN APPLICATION
addappid(447950)

-- MAIN APP DEPOTS / PACKAGES
addappid(447951, 1, "c262b781af41df2e2aaeea58a2c88cdb9a53007dcaf916acfd13ff86f5b98f6a")
