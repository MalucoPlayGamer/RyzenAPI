-- Lua provided by RyzenAPI
-- Game: Double Shoulders

-- MAIN APPLICATION
addappid(3393620)
-- Game: addappid(3393620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393621, 1, "6809e99e0283f27818166edd93f410803310539c5d94e093c6f1bf312e91df87")
