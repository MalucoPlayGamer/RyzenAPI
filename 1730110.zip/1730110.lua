-- Lua provided by RyzenAPI
-- Game: Dinogotchi

-- MAIN APPLICATION
addappid(1730110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730111, 1, "aee7f1b91df2b55b9b7b65827e4ce0144945d5ce0ecb8f9ba6475340f2796a45")

