-- Lua provided by RyzenAPI
-- Game: AppID 368420

-- MAIN APPLICATION
addappid(368420)
addappid(536820)
-- Game: addappid(368420)

-- MAIN APP DEPOTS / PACKAGES
addappid(368421, 1, "3dfee627b2eab92c6f885340f6982f8df2392526e0f66614399351fc240f248c")
addappid(548660, 0, "989a5b819f55f4efeabf379cca72e1f6e084a2cd79f0d30b3fa387fbf07c99ad")
