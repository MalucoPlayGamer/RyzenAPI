-- Lua provided by RyzenAPI
-- Game: AppID 368420

-- MAIN APPLICATION
addappid(368420)
addappid(536820)
addappid(614740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(368421, 1, "3dfee627b2eab92c6f885340f6982f8df2392526e0f66614399351fc240f248c")
addappid(548660, 0, "989a5b819f55f4efeabf379cca72e1f6e084a2cd79f0d30b3fa387fbf07c99ad")

