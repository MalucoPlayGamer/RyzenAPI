-- Lua provided by RyzenAPI
-- Game: Ah, Love!

-- MAIN APPLICATION
addappid(937390)
-- Game: addappid(937390)

-- MAIN APP DEPOTS / PACKAGES
addappid(937391, 1, "be3879e389356cc998406b4c25f44a26a1f8f2456ab54016053a8594e6d15f53")
