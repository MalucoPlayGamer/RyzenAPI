-- Lua provided by SkyAPI 
-- Game: Ah, Love!
addappid(937390)
addappid(937391, 1, "be3879e389356cc998406b4c25f44a26a1f8f2456ab54016053a8594e6d15f53")
