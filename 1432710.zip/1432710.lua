-- Lua provided by RyzenAPI
-- Game: 新魔剑（New Magic Sword）

-- MAIN APPLICATION
addappid(1432710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432711, 1, "4ce616821af6d0b56e69e552ebe408311e64de8cf8c5a06f529b581c2d767b28")
