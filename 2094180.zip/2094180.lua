-- Lua provided by RyzenAPI
-- Game: addappid(2094180)

-- MAIN APPLICATION
addappid(2094180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094181, 1, "87069e1edb5c3048d2c211d5872eef06b2068ecfe7c0f1633cf89b66432144d0")
