-- Lua provided by RyzenAPI
-- Game: AppID 441680

-- MAIN APPLICATION
addappid(441680)
-- Game: addappid(441680)

-- MAIN APP DEPOTS / PACKAGES
addappid(441681, 1, "94537eeaa07416928076e8ec0ebb3c9938a0d02d8baaea4f383ae2d2d42106a1")
addappid(441682, 1, "108b3bd3329bcd4e9894f2470d4ea2ec790a18092629b3a552528d21ebe8fdff")
