-- Lua provided by RyzenAPI
-- Game: Drown in Yesterday's Sea

-- MAIN APPLICATION
addappid(4849190) -- Drown in Yesterday's Sea

-- MAIN APP DEPOTS / PACKAGES
addappid(4849192, 1, "18ecf4fa2fefd5b7e2a225300bdf8d29568e68e45b66227ee99cc9d03916aefb") -- Depot 4849192
addtoken(4849190, "5242551770246762513")

