-- 4849190's Lua and Manifest Created by Hubcap Manifest
-- Drown in Yesterday's Sea
-- Created: August 07, 2026 at 11:10:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4849190) -- Drown in Yesterday's Sea
addtoken(4849190, "5242551770246762513")
-- MAIN APP DEPOTS
addappid(4849192, 1, "18ecf4fa2fefd5b7e2a225300bdf8d29568e68e45b66227ee99cc9d03916aefb") -- Depot 4849192
setManifestid(4849192, "7623422690856792707", 181727331)