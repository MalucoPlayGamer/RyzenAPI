-- Lua provided by RyzenAPI
-- Game: 3227190

-- MAIN APPLICATION
addappid(3227190)
-- Game: addappid(3227190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227192,0,"6fc6c03f75dd6446e88407a12968fa118eb31ea5b12ff64647357f9503fcb38a")
