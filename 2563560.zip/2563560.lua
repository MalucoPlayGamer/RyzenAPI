-- Lua provided by RyzenAPI 
-- Game: AppID 2563560
addappid(2563560)
addappid(2563561, 1, "7509ef3d7c47be9daee20a5c637f9cc75f42a7e408a46b01cb4c285529c73049")
