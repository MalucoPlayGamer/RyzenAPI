-- Lua provided by RyzenAPI
-- Game: Game: AppID 3540210

-- MAIN APPLICATION
addappid(3540210)
-- Game: addappid(3540210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3540211, 1, "3752968ae1f7fa057d6ab55aa490f894afc683f2a10ad0e68b64deb354888da7")
