-- Lua provided by SkyAPI 
-- Game: AppID 3540210
addappid(3540210)
addappid(3540211, 1, "3752968ae1f7fa057d6ab55aa490f894afc683f2a10ad0e68b64deb354888da7")
