-- Lua provided by RyzenAPI
-- Game: Canvas The Gallery

-- MAIN APPLICATION
addappid(590280)

