-- Lua provided by RyzenAPI
-- Game: Canvas The Gallery

-- MAIN APPLICATION
addappid(590280)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(590290)
