-- Lua provided by RyzenAPI
-- Game: Game: Live by the Sword: Tactics

-- MAIN APPLICATION
addappid(1363210)
-- Game: addappid(1363210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363211, 1, "3bde907d66dfb422ac75cfc659275a9cf749ef6a1c714e4f754c424c41ef8c86")
