-- Lua provided by RyzenAPI
-- Game: The Coma 2: Vicious Sisters

-- MAIN APPLICATION
addappid(1183520)
addappid(1222920)
addappid(1226460)
addappid(1240930)
addappid(1240950)
addappid(1240960)
addappid(1240970)
addappid(1240980)
addappid(1240990)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
addappid(1045720, 1, "c37d524c477d647c37cde175e548b33653ea919622d4da7d02bb7ca5c75f5b96") -- The Coma 2: Vicious Sisters
addappid(1045721, 1, "acab6f72f76788b069b0480637d5640c81b7a59821104105a5afba557f10697c") -- The Coma 2: Vicious Sisters (WIN)
addappid(1045722, 1, "2a66e873c1f7504af029ebcddcaa7c8928857f8b5b76d2e540e68b250ee4877a") -- The Coma 2: Vicious Sisters (OSX)
addappid(1045723, 1, "8f3c843ed3a064ad7a6172f2da123d83102baa04d862aa3d653136cdcbac3478") -- The Coma 2: Vicious Sisters (LINUX)
addappid(1183521, 1, "b35e7cba80fa7a89c1be62ebf064858a0f68c1e616ef41d761e39d0bacfa9b8c") -- The Coma 2 Vicious Sisters DLC - Mina - Locks of Love Skin - Mina - Locks of Love Skin Depot (WIN)
addappid(1183522, 1, "d34216524b1d8b8b0a6d3d40a7b79a14d3d430728b017a6ede481499d88868a8") -- The Coma 2 Vicious Sisters DLC - Mina - Locks of Love Skin - Mina - Locks of Love Skin Depot (LINUX)
addappid(1183523, 1, "04f618060eeebf3e3d05bd7c5135a7453bb756f437038cc253e55d02744e1b89") -- The Coma 2 Vicious Sisters DLC - Mina - Locks of Love Skin - Mina - Locks of Love Skin Depot (OSX)
addappid(1222921, 1, "1408c9ed84ddce8a6fcc9e4bd3317f0ea102e0c68d333cf2aae65c4f81ca90c1") -- The Coma 2 Vicious Sisters DLC - Artbook - The Coma 2: Vicious Sisters DLC - Artbook Depot
addappid(1226461, 1, "8fb7329e1ea0a2821766ffd639a40142ef41eaea429820da664f9797953f9616") -- The Coma 2 Vicious Sisters DLC - Mina - Winter Princess Skin - Mina - Winter Princess Skin Depot (WIN)
addappid(1226462, 1, "dc23611207bbca243b0685cd2253856febfb74a71c979395a4f10dadf772ed1a") -- The Coma 2 Vicious Sisters DLC - Mina - Winter Princess Skin - Mina - Winter Princess Skin Depot (Linux)
addappid(1226463, 1, "3d019fe8798d83c12988e0b452bdf5f3c35410c9517de0b081dbe0f3d1b06ef5") -- The Coma 2 Vicious Sisters DLC - Mina - Winter Princess Skin - Mina - Winter Princess Skin Depot (OSX)
addappid(1240936, 1, "4345f26748e9dbf34d76911db8bf9f2a4b381d717f796724142e9c8ad69376b2") -- The Coma 2 Vicious Sisters DLC - Mina - School Bully Skin - Mina - School Bully Skin Depot (WIN)
addappid(1240937, 1, "051b43cfb09c7b431f1dfd1d9ab04c7a4f9697094a42d8b40a84cb3eb822f256") -- The Coma 2 Vicious Sisters DLC - Mina - School Bully Skin - Mina - School Bully Skin Depot (LINUX)
addappid(1240938, 1, "1ca05e251eba3f2759d5d233b043feacb6f0dbe42c0522ff3320314d221d9215") -- The Coma 2 Vicious Sisters DLC - Mina - School Bully Skin - Mina - School Bully Skin Depot (OSX)
addappid(1240951, 1, "aad665aebb968b76350732c5da5bfdbd100c2e70e91bdbcdca9c28f2fba0dff3") -- The Coma 2 Vicious Sisters DLC - Mina - Summer Child Skin - Mina - Summer Child Skin Depot (WIN)
addappid(1240952, 1, "b4386741058e48b502a375f01ca396bba4f14ea25e206bf4d85f0e22b6bfd08f") -- The Coma 2 Vicious Sisters DLC - Mina - Summer Child Skin - Mina - Summer Child Skin Depot (LINUX)
addappid(1240953, 1, "d61ed6bff858cd8485779a9505b3837c3560e55a400ad6a5c17161f536894bec") -- The Coma 2 Vicious Sisters DLC - Mina - Summer Child Skin - Mina - Summer Child Skin Depot (OSX)
addappid(1240961, 1, "06d457193c2e57f193df2aa3c395a393345869f2720d14a0f80168263c7a09f7") -- The Coma 2 Vicious Sisters DLC - Mina - Model Student Skin - Mina - Model Student Skin Depot (WIN)
addappid(1240962, 1, "14c9eaefcedebbd28b0972af487af2a5b0ac3975196e4313a805ecf7a9e4c341") -- The Coma 2 Vicious Sisters DLC - Mina - Model Student Skin - Mina - Model Student Skin Depot (LINUX)
addappid(1240963, 1, "3878fc5acfa175cd1cba245ec4fdbf4c7d846aa5ca495e0672517018e2cec619") -- The Coma 2 Vicious Sisters DLC - Mina - Model Student Skin - Mina - Model Student Skin Depot (OSX)
addappid(1240971, 1, "21c31cbb2bd34c31a9091c393dc7b67925fbf835c1224953d41ab17980ab0f19") -- The Coma 2 Vicious Sisters DLC - Mina - Local Celeb Skin - Mina - Local Celeb Skin Depot (Win)
addappid(1240972, 1, "d1e05ef3e0a5b46c1e52abae391934bff7a03ae457a33df3819a3038555bbae7") -- The Coma 2 Vicious Sisters DLC - Mina - Local Celeb Skin - Mina - Local Celeb Skin Depot (LINUX)
addappid(1240973, 1, "e311cf91cd18d7a86b7eda4d8d2d115a87b68ad6e8b3555c3bef815aba2a67c4") -- The Coma 2 Vicious Sisters DLC - Mina - Local Celeb Skin - Mina - Local Celeb Skin Depot (Osx)
addappid(1240981, 1, "a337d8f4ecca1f0b7c77d281106bdb8d73adf7122b1b65bab6aec9aece53dfd1") -- The Coma 2 Vicious Sisters DLC - Mina - Beach Bum Skin - Mina - Beach Bum Skin Depot (Win)
addappid(1240982, 1, "e965d20bf2437a6900431823975de9b2d9fc946b2203ada51a26efe99ffc5c5f") -- The Coma 2 Vicious Sisters DLC - Mina - Beach Bum Skin - Mina - Beach Bum Skin Depot (Linux)
addappid(1240983, 1, "3e2a14821b74fad334a63d8d31023adf528059115dc688ec550799cdedcfa33c") -- The Coma 2 Vicious Sisters DLC - Mina - Beach Bum Skin - Mina - Beach Bum Skin Depot (Osx)
addappid(1240991, 1, "a27a566f3424c7bb478657cef4afdd506a81aae3a03a7db80bba1dfd608ecd29") -- The Coma 2 Vicious Sisters DLC - Mina - Gamer Girl Skin - Mina - Gamer Girl Skin Depot (Win)
addappid(1240992, 1, "a4738d53484ceb9f36119728b16158b0da837e1eebf4a8fd62176307dab0cea3") -- The Coma 2 Vicious Sisters DLC - Mina - Gamer Girl Skin - Mina - Gamer Girl Skin Depot (Linux)
addappid(1240993, 1, "ae7012a4b110e0131cea202d8854b5b8138fc81d79760e1dc58ca9f7383209a8") -- The Coma 2 Vicious Sisters DLC - Mina - Gamer Girl Skin - Mina - Gamer Girl Skin Depot (Osx)

