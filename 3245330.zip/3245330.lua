-- Lua provided by RyzenAPI
-- Game: AppID 3245330

-- MAIN APPLICATION
addappid(3245330)
-- Game: addappid(3245330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245331, 1, "8b32c8a6145fed73ba747f03a9eebb26e437f0bcb8b1688a3b67784f74a98ddd")
