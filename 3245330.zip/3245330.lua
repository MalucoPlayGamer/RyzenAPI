-- Lua provided by RyzenAPI
-- Game: AppID 3245330

-- MAIN APPLICATION
addappid(3245330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245331, 1, "8b32c8a6145fed73ba747f03a9eebb26e437f0bcb8b1688a3b67784f74a98ddd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
