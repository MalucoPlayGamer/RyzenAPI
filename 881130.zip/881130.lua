-- Lua provided by RyzenAPI
-- Game: addappid(881130)

-- MAIN APPLICATION
addappid(881130)

-- MAIN APP DEPOTS / PACKAGES
addappid(881131, 1, "c23c913c94b7360f3d38b591e1520b75c8cb23f426e51cd9f9c85d3c12254a93")
