-- Lua provided by RyzenAPI
-- Game: My Racing Career

-- MAIN APPLICATION
addappid(805770)

-- MAIN APP DEPOTS / PACKAGES
addappid(805771,0,"a2d807f00487f51d23a43a56aaae08a91a3afc4b24f9b22e57f00d18f40e6b9b")

