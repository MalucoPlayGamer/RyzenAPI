-- Lua provided by RyzenAPI
-- Game: 3260890

-- MAIN APPLICATION
addappid(3260890)
-- Game: addappid(3260890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3260891, 1, "037629a2f44a4420d209aa927eea9b9108f40afc02190b31e062beb2961a53fd")
