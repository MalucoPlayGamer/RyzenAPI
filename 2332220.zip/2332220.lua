-- Lua provided by RyzenAPI
-- Game: Marionette Mates

-- MAIN APPLICATION
addappid(2332220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2332221, 1, "9e0fa7f79c50d0f1146978d7ed4d9143e6a20070fd467e6bcb3fb72d2f307c44")

