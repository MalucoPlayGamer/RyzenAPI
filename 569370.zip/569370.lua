-- Lua provided by RyzenAPI
-- Game: Game: Bitdude

-- MAIN APPLICATION
addappid(569370)
-- Game: addappid(569370)

-- MAIN APP DEPOTS / PACKAGES
addappid(569371, 1, "a17e2500971876ae7f66419c3c30dc6c843eb56cc8505c3da9edec5af1181f6b")
