-- Lua provided by RyzenAPI
-- Game: Don’t Tell Anyone, Okay? - NSFW Stream

-- MAIN APPLICATION
addappid(4785670)

-- MAIN APP DEPOTS / PACKAGES
addappid(4785671,0,"47b3fc8280c3be4d1efc3fe822779062c8daa4bc72c5e0ab3b405ed917129bfb")

