-- Lua provided by RyzenAPI 
-- Game: AppID 965230
addappid(965230)
addappid(965231, 1, "7991997f37bd388822b50e2b9e2984c14593fd80b32bfbc60baa0e795b037c04")
