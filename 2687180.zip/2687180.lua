-- Lua provided by SkyAPI 
-- Game: The Scholars: Fan Jin's Chapter Soundtrack
addappid(2687180)
addappid(2687181, 1, "b792a3df8f4903e9af9d9e0b9727df5f9c910a7ccbb2b87bfd7a02767e735883")
addappid(2687182, 1, "43500da9e6723dda679c0749437c88d06e8e18563b6db8f32174ecf4013fb262")
