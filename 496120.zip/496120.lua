-- Lua provided by RyzenAPI
-- Game: LaserCat

-- MAIN APPLICATION
addappid(496120)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(496121, 1, "6ca2dce4df14a80a1ae298ee08078e21bac54542daea442a015bf1ee87bcfdfe")

