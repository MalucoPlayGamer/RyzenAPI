-- Lua provided by RyzenAPI
-- Game: LaserCat

-- MAIN APPLICATION
addappid(496120)

-- MAIN APP DEPOTS / PACKAGES
addappid(496121, 1, "6ca2dce4df14a80a1ae298ee08078e21bac54542daea442a015bf1ee87bcfdfe")

