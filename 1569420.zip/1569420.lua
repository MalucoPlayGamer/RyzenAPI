-- Lua provided by RyzenAPI
-- Game: Spellfarers

-- MAIN APPLICATION
addappid(1569420)
