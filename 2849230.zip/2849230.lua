-- Lua provided by RyzenAPI 
-- Game: AppID 2849230
addappid(2849230)
addappid(2849231, 1, "3fc911b56038d8ddcfc0c63e3b16b9dd3eb9671f76957e2dacfeec14e7e0f069")
