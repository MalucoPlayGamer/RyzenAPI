-- Lua provided by RyzenAPI
-- Game: Realms of Magic

-- MAIN APPLICATION
addappid(490280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(490282,0,"ed0e9e4c7912af267a863219cc0a85142960121334554c5440d8190d56794356")
addappid(490283,0,"87da8ea5863b7ab1be86f2347be173a7a8c512bc0d072e678ccd012690a14d04")

