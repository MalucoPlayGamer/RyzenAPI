-- Lua provided by RyzenAPI
-- Game: addappid(2327660)

-- MAIN APPLICATION
addappid(2327660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2327661, 1, "de15fbf8bac092ce37fea0251afb19185e33893563ac0841c56afdf10a76b925")
