-- Lua provided by RyzenAPI
-- Game: Everafter Falls - Artbook

-- MAIN APPLICATION
addappid(3024910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3024910,0,"05aa9c5a57a13895ecc6ecdabb1854879c7a1c9de9089ed3247f37683c38e9be")
