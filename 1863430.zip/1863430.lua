-- Lua provided by RyzenAPI
-- Game: Dragonkin: The Banished

-- MAIN APPLICATION
addappid(1863430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863431, 1, "328f355333eea5102d7e3e43ead832f03f1005e6b29a00b563799c6db5148602")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3462450)
addappid(3594840)
addappid(3594850)
addappid(3594860)
addappid(4130000)
addappid(4508200)
addappid(4844640)
