-- Lua provided by RyzenAPI
-- Game: Dragonkin: The Banished

-- MAIN APPLICATION
addappid(1863430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863431, 1, "328f355333eea5102d7e3e43ead832f03f1005e6b29a00b563799c6db5148602")
