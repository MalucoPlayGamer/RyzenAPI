-- Lua provided by RyzenAPI
-- Game: Recovery Search & Rescue Simulation

-- MAIN APPLICATION
addappid(262870)
-- Game: addappid(262870)

-- MAIN APP DEPOTS / PACKAGES
addappid(262871, 1, "9d0d3590ab0ca4ed1da08c945cb72725fbee7e2f3d55f01cccbd3f32e73d9be5")
