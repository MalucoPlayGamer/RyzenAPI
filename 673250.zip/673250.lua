-- Lua provided by RyzenAPI
-- Game: Exterminator: Escape!

-- MAIN APPLICATION
addappid(673250)

-- MAIN APP DEPOTS / PACKAGES
addappid(673251,0,"eb8f076b746dd07234204aee39f6601d5bdf86fa4619a7257e4ad46195e92ba2")

