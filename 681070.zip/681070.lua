-- Lua provided by RyzenAPI
-- Game: The Slug

-- MAIN APPLICATION
addappid(681070)

-- MAIN APP DEPOTS / PACKAGES
addappid(681071, 1, "ec44e0f2466af30096c8b6c1e89a3827d58f5e4fe362150acaaa1206466c6b6f")

