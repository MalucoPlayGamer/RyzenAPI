-- Lua provided by RyzenAPI
-- Game: Another Bar Game Demo

-- MAIN APPLICATION
addappid(2216820)
-- Game: addappid(2216820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216821, 1, "6ee93d9c5c23cc0b7526647804cab73be7177f27c4e76f74e46056cd8a89aaa5")
