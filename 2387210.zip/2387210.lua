-- Lua provided by SkyAPI 
-- Game: Mirage
addappid(2387210)
addappid(2387211, 1, "160b8c2a5de7a68ec1303a5fe2d25924b703b4b572a498517473175e3e1c5b3a")
