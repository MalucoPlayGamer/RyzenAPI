-- Lua provided by RyzenAPI
-- Game: AppID 3437820

-- MAIN APPLICATION
addappid(3437820)
-- Game: addappid(3437820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3437821, 1, "3b0ff8abdfbee78841571fc092cc59b865ca4f285fc26b38c59afe6d724deac9")
