-- Lua provided by SkyAPI 
-- Game: AppID 540150
addappid(540150)
addappid(540151, 1, "61db0839cb0f54c2802e037641ade617a780a86f7d85736c0d172e42d46477f6")
addappid(540152, 1, "c55b1f7ad17e7df66a72f69793e43c98beb2fdb7451a7fb27fa65e42c1d52f16")
