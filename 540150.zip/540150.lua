-- Lua provided by RyzenAPI
-- Game: Tank Battle: Blitzkrieg

-- MAIN APPLICATION
addappid(540150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(540151, 1, "61db0839cb0f54c2802e037641ade617a780a86f7d85736c0d172e42d46477f6")
addappid(540152, 1, "c55b1f7ad17e7df66a72f69793e43c98beb2fdb7451a7fb27fa65e42c1d52f16")

