-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Time Fantasy Add-on: Animals

-- MAIN APPLICATION
addappid(1441940)
-- Game: addappid(1441940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441940,0,"c4b6740b7b0425f1892611815d140259e9ba52747cc623cc3e65068117899385")
