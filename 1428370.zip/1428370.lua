-- Lua provided by RyzenAPI
-- Game: times infinity

-- MAIN APPLICATION
addappid(1428370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428371, 1, "cfac4ef98ae382ea800a637ccd5408f9cd92d1ccaa3985b4ff7163dc60c2a6d0")
addappid(1428372, 1, "4cfca03e8bdce9a342b523ff1073a3796575482c81274267562f9c997daab3bb")

