-- Lua provided by RyzenAPI
-- Game: New Heights: Realistic Climbing and Bouldering

-- MAIN APPLICATION
addappid(2179440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179441, 1, "ea3a1aa499469ab077f82c7bc881585f1e622c96d871cf937cadd8e4c7a24dce")

