-- Lua provided by RyzenAPI
-- Game: AppID 1084420

-- MAIN APPLICATION
addappid(1084420)
-- Game: addappid(1084420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084421, 1, "c66b6fe8de16b97869e2b663a24c3d43884431fe492e24d1fb6b5e5ca161b69f")
