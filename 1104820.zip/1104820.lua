-- Lua provided by RyzenAPI
-- Game: Steel Division 2 Modding Assets

-- MAIN APPLICATION
addappid(1104820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104821, 1, "43c56cd3d10b75b62cf6335135ca2fbb7d4150bdafcc43251aac7be71848bc2e")
