-- Lua provided by SkyAPI 
-- Game: AppID 1104820
addappid(1104820)
addappid(1104821, 1, "43c56cd3d10b75b62cf6335135ca2fbb7d4150bdafcc43251aac7be71848bc2e")
