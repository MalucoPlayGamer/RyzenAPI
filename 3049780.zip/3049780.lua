-- Lua provided by RyzenAPI
-- Game: 3049780

-- MAIN APPLICATION
addappid(3049780)
-- Game: addappid(3049780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3049781, 1, "d7de7061fcb41a6115ab0a85a47d654c52d62629c27ceda5a5cbc34d7d43b07a")
