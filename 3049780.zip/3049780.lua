-- Lua provided by SkyAPI 
-- Game: Death row inmates on the run
addappid(3049780)
addappid(3049781, 1, "d7de7061fcb41a6115ab0a85a47d654c52d62629c27ceda5a5cbc34d7d43b07a")
