-- Lua provided by RyzenAPI
-- Game: KISEKI of the Gun-Dog – Digital Artbook

-- MAIN APPLICATION
addappid(3471190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471190,0,"4e0187a899fb71f3e5b1003f256da63a0d06728791ea93d08d41a88a70c009d4")
