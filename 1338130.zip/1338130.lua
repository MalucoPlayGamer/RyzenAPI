-- Lua provided by RyzenAPI
-- Game: Popo's Tower

-- MAIN APPLICATION
addappid(1338130)
-- Game: addappid(1338130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338131, 1, "276ed20a956a18c2a3af72e56e260e9870431808902378fa040a5eef7908c416")
