-- Lua provided by RyzenAPI
-- Game: Popo's Tower

-- MAIN APPLICATION
addappid(1338130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1338131, 1, "276ed20a956a18c2a3af72e56e260e9870431808902378fa040a5eef7908c416")

