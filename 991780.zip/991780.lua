-- Lua provided by RyzenAPI
-- Game: Notes of Soul

-- MAIN APPLICATION
addappid(991780)
-- Game: addappid(991780)

-- MAIN APP DEPOTS / PACKAGES
addappid(991781, 1, "96d486bdee232132c4f0f1c79089e5f04b6e822ef9a3bd14f4e652c4bdba75e9")
