-- Lua provided by RyzenAPI
-- Game: 1799110

-- MAIN APPLICATION
addappid(1799110)
-- Game: addappid(1799110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799111, 1, "033289fcf3e9e67040a88b25d5f4055e53db6185f96f8b8ba11d55ff466b0792")
