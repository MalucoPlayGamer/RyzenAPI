-- Lua provided by SkyAPI 
-- Game: Regency Solitaire
addappid(351090)
addappid(351091, 1, "93357ac1240e75cc643b8eb11f22d07c1f75ee124850c7e53f5ceb0e8b095dd0")
addappid(351092, 1, "7ec14e1709d8847e2395351c427c3c24aaced802d107d9a0bbf85347ad5a4a15")
addappid(351093, 1, "2516ebd28e5e796ba3d7c1fe3e47f31a22415679f9efc4ae168b04f87a12518e")
