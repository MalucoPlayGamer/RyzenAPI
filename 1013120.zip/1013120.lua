-- Lua provided by RyzenAPI
-- Game: 1013120

-- MAIN APPLICATION
addappid(1013120)
-- Game: addappid(1013120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013121, 1, "009cc5e2dbc449d468325603c1633b43a7cb1e436b3807fee13176bedbd47b43")
