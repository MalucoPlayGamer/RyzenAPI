-- Lua provided by RyzenAPI
-- Game: Game: AppID 562810

-- MAIN APPLICATION
addappid(562810)
-- Game: addappid(562810)

-- MAIN APP DEPOTS / PACKAGES
addappid(562811, 1, "2167d0c08caf4089421eb05ba77a5ec0c869f51a58cc0090827aed949dafb59c")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
