-- Lua provided by RyzenAPI
-- Game: Fisherman's Palace

-- MAIN APPLICATION
addappid(2749370)
-- Game: addappid(2749370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2749371, 1, "0b434e2da1bc4c87a53066cab73159007453fce9c3eaca679754dd656ee64010")
