-- Lua provided by RyzenAPI
-- Game: Why don't they laugh?

-- MAIN APPLICATION
addappid(3031940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3031941, 1, "50289c4a5dcc5d7d157cfb424dbdaf644d99dfcd7d78cb7c47291cc570fc8727")
