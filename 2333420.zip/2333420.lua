-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Mage

-- MAIN APPLICATION
addappid(2333420)
-- Game: addappid(2333420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333421, 1, "638319575cb6370af7affc28f5e1764043c74d8f13a2287a06f446da52775284")
