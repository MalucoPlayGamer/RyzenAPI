-- Lua provided by RyzenAPI
-- Game: Peggy's Farm Demo

-- MAIN APPLICATION
addappid(2803620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803621, 1, "fa5f6143adee6b7ee2f704a9445d3657eb9d3164da8f076e1d565bb0adcd77e2")

