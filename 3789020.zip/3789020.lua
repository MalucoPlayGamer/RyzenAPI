-- Lua provided by RyzenAPI
-- Game: Game: Banana Ninja VS 100 Mann

-- MAIN APPLICATION
addappid(3789020)
-- Game: addappid(3789020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3789021, 1, "c590685a14eea3fad9a878c481467fa963ac771ef778ccb52a7aaa03175cf0c1")
