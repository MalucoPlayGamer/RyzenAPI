-- Lua provided by RyzenAPI
-- Game: 374510

-- MAIN APPLICATION
addappid(374510)
-- Game: addappid(374510)

-- MAIN APP DEPOTS / PACKAGES
addappid(374511, 1, "18e61222fbdbba3c29fe109b399ba3a4a961c108da6823678f54f6658b6c8f05")
addappid(374512, 1, "ba5fa3fe8098241245215eb4b61a4b2c69f8bb217c23eba306000749f968fdcf")
addappid(374840, 0, "e16aa8c077e65acd6e0cdb8f4445a95165a4beabcd9eb17c80622d2eddc1f44c")
addappid(386310, 0, "6dcd7b512dfc1f87961716c9bd3d38655db645b46cd068088ce69c85b3c70da2")
