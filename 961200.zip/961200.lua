-- Lua provided by RyzenAPI
-- Game: Game: Predecessor

-- MAIN APPLICATION
addappid(961200)
-- Game: addappid(961200)

-- MAIN APP DEPOTS / PACKAGES
addappid(961201, 1, "6741cadcf781daa8e89c92951a76d44c4aa8955ba7ae8657a5857ce8d22a56bf")
