-- Lua provided by RyzenAPI
-- Game: BHB: BioHazard Bot

-- MAIN APPLICATION
addappid(711260)

-- MAIN APP DEPOTS / PACKAGES
addappid(711261,0,"7c251ceb550c489d6c82a9559224a6a78ed009cdd13774bb0e423c0d374af7ec")

