-- Lua provided by RyzenAPI
-- Game: Utawarerumono: Mask of Truth

-- MAIN APPLICATION
addappid(1151440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1151441, 1, "256e9965f5c720a0c49fb5513e1a970a030f6273d495e0c5b38551b25b42d7c3")
addappid(1151442, 1, "076820c4f6feeee50b1c82a74b31f649d43c04a18f9a3aba2155cbd1f3212115")
addappid(1151443, 1, "46a3ba555bbb2bf61ace9d4ee9b09df0469955e5205361c913efbd07fbb3c41f")
addappid(1151444, 1, "2af52f414ad584d51cbec170ab5cc86be8035e2dfc3e2dff6d61707aab637966")
