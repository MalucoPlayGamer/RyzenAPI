-- Lua provided by SkyAPI 
-- Game: Bad boy simulator
addappid(1489380)
addappid(1489381, 1, "86fe8ba1fac0c3d222bc96ca0233a8e3f525c9ca9690780feb7fdceed69922b9")
