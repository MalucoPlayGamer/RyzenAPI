-- Lua provided by RyzenAPI
-- Game: 1489380

-- MAIN APPLICATION
addappid(1489380)
-- Game: addappid(1489380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489381, 1, "86fe8ba1fac0c3d222bc96ca0233a8e3f525c9ca9690780feb7fdceed69922b9")
