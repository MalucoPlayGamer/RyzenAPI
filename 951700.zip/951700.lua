-- Lua provided by RyzenAPI
-- Game: Game: Super Jigsaw Puzzle: Space

-- MAIN APPLICATION
addappid(951700)
-- Game: addappid(951700)

-- MAIN APP DEPOTS / PACKAGES
addappid(951701, 1, "c98082fcd4e75968d87f3004fd61a60c453ed6d5a65b81829bbfaa11fa8346e5")
addappid(1056622, 0, "9ddb2c04f1f7da8b648f5701fde202ed2e1bd04ca5405010a7d8180be60a1ced")
