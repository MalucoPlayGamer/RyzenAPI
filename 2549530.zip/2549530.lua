-- Lua provided by RyzenAPI
-- Game: SONIC SUPERSTARS - Extra Content Pack

-- MAIN APPLICATION
addappid(2549530)
-- Game: addappid(2549530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549530,0,"1df5d5fc27599c6099bf21263adf57547fa1e3bd827da9094e8d40210599d386")
