-- Lua provided by RyzenAPI
-- Game: 牧剑(Tale Of Swords)

-- MAIN APPLICATION
addappid(992260)

-- MAIN APP DEPOTS / PACKAGES
addappid(992261, 1, "26c12058fedc34e8ffb2e9d03decf3322d5fbc205b8553980190b93b2f1869d9")
