-- Lua provided by RyzenAPI
-- Game: The Adventures of Herbie & Katt LeChatt

-- MAIN APPLICATION
addappid(1656210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656211, 1, "2fcbac207b96ae03b4ccfadefca81b13f650f31f941cbc61f9eae452aec246be")
