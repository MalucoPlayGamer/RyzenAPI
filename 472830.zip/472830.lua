-- Lua provided by RyzenAPI
-- Game: 472830

-- MAIN APPLICATION
addappid(472830)
-- Game: addappid(472830)

-- MAIN APP DEPOTS / PACKAGES
addappid(472831, 1, "0f1452072dde04c38461d13d3e3a0a9c2f236c3f3092d8f6f81518aa3bb00f3d")
