-- Lua provided by RyzenAPI
-- Game: 3030810

-- MAIN APPLICATION
addappid(3030810)
-- Game: addappid(3030810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3030811, 1, "21f3fdbee7f2e4f6f391e919d650dbc25c32c92728a817f17c09996855d627f2")
