-- Lua provided by RyzenAPI
-- Game: 巫女契约 Demo

-- MAIN APPLICATION
addappid(1680040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1680041, 1, "f98a1ed9304f18de2dbe596f9f0cc2d9dffcf7989e4dc683dbdbba441eb90bad")

