-- Lua provided by RyzenAPI
-- Game: 1550870

-- MAIN APPLICATION
addappid(1550870)
-- Game: addappid(1550870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550871, 1, "cb594119b55c946a3dec419f5a51dfafb23e73039000268ba0d138d76e7aae06")
