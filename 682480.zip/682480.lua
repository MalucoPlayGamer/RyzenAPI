-- Lua provided by RyzenAPI
-- Game: 682480

-- MAIN APPLICATION
addappid(682480)
-- Game: addappid(682480)

-- MAIN APP DEPOTS / PACKAGES
addappid(682481, 1, "7a7c4eae628eef45a2fb553d95a16d30f732264fc4ff1c9364014633e7f4b1c7")
