-- Lua provided by RyzenAPI
-- Game: Splitter Critters

-- MAIN APPLICATION
addappid(473780)

-- MAIN APP DEPOTS / PACKAGES
addappid(473781, 1, "b0a06acd5179ca64472d6cc0e456d8a08498f343db8fee5042f46c52c55ce9af")

