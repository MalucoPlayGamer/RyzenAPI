-- Lua provided by RyzenAPI
-- Game: The DioField Chronicle

-- MAIN APPLICATION
addappid(1399080)
addappid(1948770)
addappid(1953450)
addappid(1953451)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1399081, 1, "34ffebca3f2cf35760d220c807c1cc9adf69788c4b80413b640df8f08db09aba")

