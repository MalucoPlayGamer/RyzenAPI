-- Lua provided by RyzenAPI
-- Game: The DioField Chronicle

-- MAIN APPLICATION
addappid(1399080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399081, 1, "34ffebca3f2cf35760d220c807c1cc9adf69788c4b80413b640df8f08db09aba")

