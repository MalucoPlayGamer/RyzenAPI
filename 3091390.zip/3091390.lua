-- Lua provided by RyzenAPI
-- Game: addappid(3091390)

-- MAIN APPLICATION
addappid(3091390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3091391, 1, "aa9c7863762a69fac30d807eb22ab375bbfd9fafa520a7375dd6de4032537b9b")
