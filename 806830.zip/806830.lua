-- Lua provided by RyzenAPI
-- Game: 806830

-- MAIN APPLICATION
addappid(806830)
-- Game: addappid(806830)

-- MAIN APP DEPOTS / PACKAGES
addappid(806831, 1, "96be472f9867c91bd1d9bc6bc2a1bf71300b7c7fcca760b41ffc464e25167161")
