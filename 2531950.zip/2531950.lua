-- Lua provided by RyzenAPI
-- Game: Scourge of the village

-- MAIN APPLICATION
addappid(2531950)
-- Game: addappid(2531950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2531951, 1, "ff3cf7c221d820a11b1cb8f73ac081b50c3857739ccf43aa857a793eda1bc730")
