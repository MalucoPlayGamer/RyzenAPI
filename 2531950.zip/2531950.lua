-- Lua provided by RyzenAPI 
-- Game: Scourge of the village
addappid(2531950)
addappid(2531951, 1, "ff3cf7c221d820a11b1cb8f73ac081b50c3857739ccf43aa857a793eda1bc730")
