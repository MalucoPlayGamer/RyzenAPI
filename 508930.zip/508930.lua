-- Lua provided by RyzenAPI
-- Game: 508930

-- MAIN APPLICATION
addappid(508930)
-- Game: addappid(508930)

-- MAIN APP DEPOTS / PACKAGES
addappid(508931, 1, "f9c9fec9bc066206076b43198deb60c1fc5124cb1bb0604752c17fae1e879bf5")
