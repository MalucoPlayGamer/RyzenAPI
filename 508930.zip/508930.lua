-- Lua provided by RyzenAPI 
-- Game: Mini Z Racers Turbo
addappid(508930)
addappid(508931, 1, "f9c9fec9bc066206076b43198deb60c1fc5124cb1bb0604752c17fae1e879bf5")
