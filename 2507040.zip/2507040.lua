-- Lua provided by RyzenAPI
-- Game: addappid(2507040)

-- MAIN APPLICATION
addappid(2507040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507041, 1, "2ef3f94c80d619864e1d2accf51ed8f928bb6e4777c581f3f1384da592e4ec70")
