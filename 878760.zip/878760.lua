-- Lua provided by RyzenAPI
-- Game: AppID 878760

-- MAIN APPLICATION
addappid(878760)
-- Game: addappid(878760)

-- MAIN APP DEPOTS / PACKAGES
addappid(878761, 1, "b557278ba0d1f283add459b03281b10db0d2d9d424e05b521113cb38cfd3ebc6")
