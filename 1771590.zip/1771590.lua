-- Lua provided by RyzenAPI
-- Game: FUSER™ - Rick James - "Super Freak"

-- MAIN APPLICATION
addappid(1771590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771590,0,"382fe9591e0257cbdf9d2b202713f82b7ed6e92ed87a8a86b53b09766e1c484c")
