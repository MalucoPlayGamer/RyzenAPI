-- Lua provided by RyzenAPI
-- Game: Nathan Morgan: Dilemma

-- MAIN APPLICATION
addappid(2680520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680522,0,"f57cdf5644fd4db0e6d3fca86ef9d70d565c51d8b798faf1039a5d4751dfd5a3")

