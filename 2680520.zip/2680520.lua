-- Lua provided by RyzenAPI
-- Game: Nathan Morgan: Dilemma

-- MAIN APPLICATION
addappid(2680520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2680522,0,"f57cdf5644fd4db0e6d3fca86ef9d70d565c51d8b798faf1039a5d4751dfd5a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
