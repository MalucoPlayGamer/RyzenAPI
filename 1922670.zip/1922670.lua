-- Lua provided by RyzenAPI
-- Game: Game: Banner of Blood

-- MAIN APPLICATION
addappid(1922670)
-- Game: addappid(1922670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922671, 1, "8898710c7ad350724268ca49b02409edfc0c7311c51802f2e948351fe7350cea")
