-- Lua provided by SkyAPI 
-- Game: Dungeons of Hinterberg Demo
addappid(2887710)
addappid(2887711, 1, "599ee3377a96933656c34cb49c86f79ef9947b81fc2f6f0217ec06dcab1e62c7")
