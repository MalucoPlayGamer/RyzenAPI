-- Lua provided by RyzenAPI
-- Game: Dungeons of Hinterberg Demo

-- MAIN APPLICATION
addappid(2887710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2887711, 1, "599ee3377a96933656c34cb49c86f79ef9947b81fc2f6f0217ec06dcab1e62c7")
