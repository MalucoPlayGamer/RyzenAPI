-- Lua provided by RyzenAPI
-- Game: If you touch me, I will marry you. Pt.1

-- MAIN APPLICATION
addappid(3044070)
-- Game: addappid(3044070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044071, 1, "e101d384d2f386c91a207af0681c07a4ef44ef5f3ea62febfc143d963098b803")
