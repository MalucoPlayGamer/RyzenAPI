-- Lua provided by RyzenAPI
-- Game: Laptop Tycoon

-- MAIN APPLICATION
addappid(1780270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780271, 1, "822c8b3e340ec700ba50fc790c9c54896197e796fa2f745cbd991cd82a9e960c")

