-- Lua provided by RyzenAPI
-- Game: 1873140

-- MAIN APPLICATION
addappid(1873140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873142,0,"fcc98ca4cfc6382be5cc70f579ea7fe43d0dde29e5a9306fb44c8f1763852a7d")
