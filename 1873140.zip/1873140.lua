-- Lua provided by RyzenAPI
-- Game: Horror Cartridge Collection

-- MAIN APPLICATION
addappid(1873140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873142,0,"fcc98ca4cfc6382be5cc70f579ea7fe43d0dde29e5a9306fb44c8f1763852a7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
