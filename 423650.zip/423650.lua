-- Lua provided by RyzenAPI
-- Game: 423650

-- MAIN APPLICATION
addappid(423650)
-- Game: addappid(423650)

-- MAIN APP DEPOTS / PACKAGES
addappid(423651, 1, "06563aa26e05177318f2aef7c919e6c9a12346f84e3312d4bd87c987f7e4ecff")
addappid(464160, 0, "ad6d1b25531ef1a7a934833ebe2e59bd9f800cf08a6a4e0dfa300f41a44f58e2")
