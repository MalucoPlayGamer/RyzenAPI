-- Lua provided by RyzenAPI
-- Game: Microgravity

-- MAIN APPLICATION
addappid(1559770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559771, 1, "2d2bc9a7566ffc9da2befc63614f16afa1e0ebd51708177c2b9dbe69179f2a45")
