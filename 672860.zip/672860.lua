-- Lua provided by RyzenAPI
-- Game: addappid(672860)

-- MAIN APPLICATION
addappid(672860)

-- MAIN APP DEPOTS / PACKAGES
addappid(672861, 1, "c09d8a8b180dc4f9f681b5d6a98f36ac4d7ae0a14e7c2b47487c764da2097dd3")
