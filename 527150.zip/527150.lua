-- Lua provided by RyzenAPI
-- Game: Dead

-- MAIN APPLICATION
addappid(527150)
addappid(538500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(527151, 1, "9a9792d4dd91c7778e7be0a47e74a229a73ae7efacd6d564071515edb148a9dc")

