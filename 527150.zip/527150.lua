-- Lua provided by RyzenAPI
-- Game: Dead

-- MAIN APPLICATION
addappid(527150)
-- Game: addappid(527150)

-- MAIN APP DEPOTS / PACKAGES
addappid(527151, 1, "9a9792d4dd91c7778e7be0a47e74a229a73ae7efacd6d564071515edb148a9dc")
