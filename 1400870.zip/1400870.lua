-- Lua provided by RyzenAPI
-- Game: When The Night Comes

-- MAIN APPLICATION
addappid(1400870)
addappid(2173950)
addappid(2173952)
-- Game: addappid(1400870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400871, 1, "393d9be2ef2b87dbc51010a22c5bd995adc2eafbbd77b6e6b6af5cc351619e92")
addappid(2173951, 1, "856bfd24bc20e52be1943915e815b123e0a935aab6739c3897f31955411ec562")
