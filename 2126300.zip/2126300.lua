-- Lua provided by RyzenAPI
-- Game: Fix My Legs Doc

-- MAIN APPLICATION
addappid(2126300)
-- Game: addappid(2126300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126301, 1, "61996e4006d2cda8a8161d6799e7ca5c02760d07f78210e1f5afeae3effd9b1e")
