-- Lua provided by RyzenAPI
-- Game: addappid(2308630)

-- MAIN APPLICATION
addappid(2308630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308631, 1, "4a0002995ee4b17bdf1fbcdf1b20a2ff66ecebbf0f7290dbe8d67d178e4c1983")
