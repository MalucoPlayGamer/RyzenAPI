-- Lua provided by RyzenAPI
-- Game: Game: War Beasts

-- MAIN APPLICATION
addappid(1706670)
-- Game: addappid(1706670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706671, 1, "ce460779ade7b1c085d811c55773ce1f2848281f378d1e2a0f07b79fe44da2f6")
