-- Lua provided by RyzenAPI
-- Game: NOVEMS

-- MAIN APPLICATION
addappid(3549210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3549211, 1, "6b1b3573aee48f5d42ef86f9e409c8fabaf31e69f8eff5cd7a5d2e3a62e72862")

