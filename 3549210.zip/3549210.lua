-- Lua provided by RyzenAPI
-- Game: NOVEMS

-- MAIN APPLICATION
addappid(3549210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3549211, 1, "6b1b3573aee48f5d42ef86f9e409c8fabaf31e69f8eff5cd7a5d2e3a62e72862")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
