-- Lua provided by RyzenAPI
-- Game: addappid(3198990)

-- MAIN APPLICATION
addappid(3198990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3198991, 1, "599930e9a323e48b4edb7921050bb4c42e4ca8b1075860fac90327c7ef91219c")
