-- Lua provided by RyzenAPI
-- Game: Game: 猎魔战纪

-- MAIN APPLICATION
addappid(1986310)
addappid(1997140)
-- Game: addappid(1986310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986311, 1, "925ddbd05d43c633bdc9200d2d2bee4c0ee9222734c510d7c7c45fac5baf8a3e")
addappid(1986312, 1, "ec6882c3708401b008596700f7990d38f7d5908546896b5b4b07807596010721")
