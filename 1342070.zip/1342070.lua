-- Lua provided by RyzenAPI
-- Game: Game: The Triumphant Return of Diabolos

-- MAIN APPLICATION
addappid(1342070)
-- Game: addappid(1342070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342071, 1, "7b7870795ae61b43a09e3488cb5e8b1bc4e9e61bd069d7cb05ea68fcd72b6457")
addappid(1342072, 1, "dbd21bed52b8910d5ebd43a7f94ab289fb46494117482c2c1c33a93483356376")
addappid(1342073, 1, "7c4135384b641eae24101d02e321bba8533075d97499534accae5eb3617fa307")
