-- Lua provided by RyzenAPI 
-- Game: Creepy Forest
addappid(2193900)
addappid(2193901, 1, "9f5113678f83ee004e5d67233ea1b9cf835e36f7b477e8a0a44ae8026eefa86f")
