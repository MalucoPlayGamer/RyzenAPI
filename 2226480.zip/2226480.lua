-- Lua provided by RyzenAPI
-- Game: Yummy Girls 3

-- MAIN APPLICATION
addappid(2226480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226481, 1, "d7081b6a0b2e7e64806c9df6ae2d3060ac85d0b6598fe6f2a1e388a31d116d64")
