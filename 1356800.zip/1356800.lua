-- Lua provided by RyzenAPI
-- Game: 1356800

-- MAIN APPLICATION
addappid(1356800)
-- Game: addappid(1356800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988,0,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
