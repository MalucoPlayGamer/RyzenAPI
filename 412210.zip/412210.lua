-- Lua provided by RyzenAPI 
-- Game: Warfront Defenders
addappid(412210)
addappid(412211, 1, "5ee391ca28476f6fbfc5f9b83e3277ce7d03b940a557fdf4f851a18269876f4f")
