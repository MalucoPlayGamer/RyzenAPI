-- Lua provided by RyzenAPI
-- Game: Warfront Defenders

-- MAIN APPLICATION
addappid(412210)

-- MAIN APP DEPOTS / PACKAGES
addappid(412211, 1, "5ee391ca28476f6fbfc5f9b83e3277ce7d03b940a557fdf4f851a18269876f4f")
