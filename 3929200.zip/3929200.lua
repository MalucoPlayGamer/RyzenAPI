-- Lua provided by RyzenAPI
-- Game: BULT: Hunting simulator

-- MAIN APPLICATION
addappid(3929200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3929201, 1, "01f24d375d502d408f3522e6b492417d29dd2d89be3dbd927711c8e3f2c84ccb")
