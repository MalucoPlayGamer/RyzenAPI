-- Lua provided by RyzenAPI
-- Game: BULT: Hunting simulator

-- MAIN APPLICATION
addappid(3929200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3929201, 1, "01f24d375d502d408f3522e6b492417d29dd2d89be3dbd927711c8e3f2c84ccb")

