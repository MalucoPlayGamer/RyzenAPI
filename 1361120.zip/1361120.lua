-- Lua provided by RyzenAPI
-- Game: 1361120

-- MAIN APPLICATION
addappid(1361120)
addappid(1432540)
addappid(1450140)
-- Game: addappid(1361120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361121, 1, "072021d7b0c3aac286c2ad435075c5ffa63e21481de62941d84d7ccef953fda4")
