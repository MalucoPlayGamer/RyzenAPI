-- Lua provided by RyzenAPI
-- Game: 1254930

-- MAIN APPLICATION
addappid(1254930)
-- Game: addappid(1254930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254931, 1, "e7bc0d9e91e787a749544fafabcecbb4bf28a929ef7e0a854ebb63bc52419839")
