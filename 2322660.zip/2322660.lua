-- Lua provided by RyzenAPI
-- Game: Global Strike

-- MAIN APPLICATION
addappid(2322660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322661, 1, "2a0b19bb5dabab4396a0a12cb808dd36591c4a083599d201ea2f40a54c569a96")

