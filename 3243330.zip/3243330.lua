-- Lua provided by RyzenAPI
-- Game: Youniverse

-- MAIN APPLICATION
addappid(3243330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243331, 1, "03d7a3ec8c9fefcb13a56520fd2da665e2c22a1680050a1fff466763bf1e6fb9")
