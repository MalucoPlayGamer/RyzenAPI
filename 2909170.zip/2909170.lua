-- Lua provided by RyzenAPI
-- Game: addappid(2909170)

-- MAIN APPLICATION
addappid(2909170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2909171, 1, "7cbbaf548fcb7e13b3f988bc1ddf128dc062f4751b682542c931e7780643fe58")
