-- Lua provided by RyzenAPI
-- Game: Phantom Breaker: Battle Grounds Ultimate Soundtrack

-- MAIN APPLICATION
addappid(3677300)
-- Game: addappid(3677300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3677301, 1, "c993ab2ff493d58e021c288f31db8e9642384bd6c6dc24d9c495d5fb02ab7bb2")
