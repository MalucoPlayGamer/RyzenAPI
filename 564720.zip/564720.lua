-- Lua provided by RyzenAPI
-- Game: setManifestid(564722,"3494633494734767585")

-- MAIN APPLICATION
addappid(564720)
-- Game: addappid(564720)

-- MAIN APP DEPOTS / PACKAGES
addappid(564722,0,"c7827e51dbb20590702bdbbe44b0e1db51e38cfee8d9be72bdf31d1f1c5e0107")
