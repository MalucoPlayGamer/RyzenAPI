-- Lua provided by RyzenAPI
-- Game: Snake 3D Adventures

-- MAIN APPLICATION
addappid(572240)

-- MAIN APP DEPOTS / PACKAGES
addappid(572241, 1, "6d60455f50a41ee5570d1a23c4be31b07e3b4b6c2a87dc975514970c519ef696")
