-- Lua provided by RyzenAPI
-- Game: Mineirinho Director's Cut

-- MAIN APPLICATION
addappid(1201630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201631, 1, "c7f0efb35ccf55702c1c209fd2800a3b86ea34e2c216098270f61e4aaf0ea876")
