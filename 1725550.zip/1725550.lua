-- Lua provided by RyzenAPI
-- Game: Game: Skiing VR Demo

-- MAIN APPLICATION
addappid(1725550)
-- Game: addappid(1725550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725551, 1, "81832db07fa921d8805638403a9480211864c57fd7161a30a53e3c42e3e95eec")
