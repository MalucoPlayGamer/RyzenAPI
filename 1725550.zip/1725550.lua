-- Lua provided by SkyAPI 
-- Game: Skiing VR Demo
addappid(1725550)
addappid(1725551, 1, "81832db07fa921d8805638403a9480211864c57fd7161a30a53e3c42e3e95eec")
