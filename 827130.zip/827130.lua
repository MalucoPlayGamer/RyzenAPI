-- Lua provided by RyzenAPI
-- Game: AppID 827130

-- MAIN APPLICATION
addappid(827130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(827131, 1, "7c66916286e3433f9bcbcf62fd475ffd6d1ad7977eff93978db1c11db774d749")

