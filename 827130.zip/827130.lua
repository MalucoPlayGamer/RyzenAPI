-- Lua provided by RyzenAPI
-- Game: AppID 827130

-- MAIN APPLICATION
addappid(827130)

-- MAIN APP DEPOTS / PACKAGES
addappid(827131, 1, "7c66916286e3433f9bcbcf62fd475ffd6d1ad7977eff93978db1c11db774d749")
