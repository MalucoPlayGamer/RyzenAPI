-- Lua provided by RyzenAPI
-- Game: 490500

-- MAIN APPLICATION
addappid(490500)
-- Game: addappid(490500)

-- MAIN APP DEPOTS / PACKAGES
addappid(490501, 1, "d685cb4e8c0f3fe12824b3e8beda3b45299679dd0d0ff49361ebc46a3cc25ec9")
addappid(490502, 1, "4a3ff69e7b53a0ab17d8ed42f0ebebe13ac6ebbc755b2c231636b49f5c7aa9ba")
