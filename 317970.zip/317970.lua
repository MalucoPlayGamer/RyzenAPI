-- Lua provided by RyzenAPI
-- Game: Dusk 12

-- MAIN APPLICATION
addappid(317970)

-- MAIN APP DEPOTS / PACKAGES
addappid(317971, 1, "47e1371bc115bcc8b74ca1131a5dba214daae7ea2da8c66478ac42aa7f1f860a")
addappid(317972, 1, "beafe76d5f874d398a30605c5b2442dd1eb221bcce053344e0bf6db9556a729c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
