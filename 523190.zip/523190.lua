-- Lua provided by RyzenAPI
-- Game: addappid(523190)

-- MAIN APPLICATION
addappid(523190)

-- MAIN APP DEPOTS / PACKAGES
addappid(523191, 1, "01af4a7c80d3fd2d6ac2ca62c4d037f4e0881e5afbc86e0cacedd10535921c42")
