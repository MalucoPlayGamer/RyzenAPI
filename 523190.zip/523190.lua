-- Lua provided by RyzenAPI
-- Game: Weapons of Mythology - New Age -

-- MAIN APPLICATION
addappid(523190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(523191, 1, "01af4a7c80d3fd2d6ac2ca62c4d037f4e0881e5afbc86e0cacedd10535921c42")

