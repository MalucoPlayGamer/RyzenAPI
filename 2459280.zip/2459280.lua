-- Lua provided by RyzenAPI
-- Game: Ecstasy / Light / Inertia

-- MAIN APPLICATION
addappid(2459280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459281, 1, "d050b463416187505e80f90f9a20fd831274ff3fd9aeb2142a66a5c1cd33c340")
