-- Lua provided by SkyAPI 
-- Game: Ecstasy / Light / Inertia
addappid(2459280)
addappid(2459281, 1, "d050b463416187505e80f90f9a20fd831274ff3fd9aeb2142a66a5c1cd33c340")
