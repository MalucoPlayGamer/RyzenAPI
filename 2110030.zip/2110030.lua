-- Lua provided by RyzenAPI
-- Game: Magenta Horizon Demo

-- MAIN APPLICATION
addappid(2110030)
-- Game: addappid(2110030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2110031, 1, "1ea33cc9b6ea5208303e35a827b327590db51669f0ef0086a71c8996fb4572e8")
