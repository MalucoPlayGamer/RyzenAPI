-- Lua provided by SkyAPI 
-- Game: Not Dying Today
addappid(568440)
addappid(568441, 1, "444946a10c38df99cdb850f06f6aea8000999d3fe5d882b1a4bd693b10706005")
addappid(568442, 1, "d34dfe3b9f55b0da016d331a93f8a9ebe79b113cd94539df22d0bcbc15d28e9c")
