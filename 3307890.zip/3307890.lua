-- Lua provided by RyzenAPI
-- Game: AppID 3307890

-- MAIN APPLICATION
addappid(3307890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3307891, 1, "14d8c9fa2669c16e10df407c0ab912aeeea81d792b81a029c0b81ac7350dbd2f")
