-- Lua provided by RyzenAPI
-- Game: Dead6hot

-- MAIN APPLICATION
addappid(438030)

-- MAIN APP DEPOTS / PACKAGES
addappid(438031, 1, "782fda16a1b25a59af2ccacdf7054825b7db51431ec9f247096bbade217bc53d")
addappid(438032, 1, "4d574eb6e56ffabadc4184d9d88a2ff7d60ba2ebbeeebe0dd55cbbf3537ae4f3")

