-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin House Pack Vol.1

-- MAIN APPLICATION
addappid(1952421)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952421,0,"f694302c6176811522b1520c24f13cc349e32a6f40800530542cda9d6b743874")

