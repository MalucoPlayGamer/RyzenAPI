-- Lua provided by RyzenAPI
-- Game: addappid(3085720)

-- MAIN APPLICATION
addappid(3085720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085721, 1, "25e280bc4425ea33509fb782ad88bcba9fbebcb252060f958e4d3ce61babde5d")
