-- Lua provided by RyzenAPI
-- Game: addappid(2810240)

-- MAIN APPLICATION
addappid(2810240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810240,0,"c788aa3dda279fb5f1d3095048425715ec4bb10627fae9ba53b10f37316fc588")
