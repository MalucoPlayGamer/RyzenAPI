-- Lua provided by RyzenAPI
-- Game: NAMCO MUSEUM ARCHIVES Vol 1

-- MAIN APPLICATION
addappid(1250250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250251, 1, "364ce0ba658c13f766ee361d0118fb4bd0b42129eaf9d758f01b7549336bdfbe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
