-- Lua provided by RyzenAPI
-- Game: 1250250

-- MAIN APPLICATION
addappid(1250250)
-- Game: addappid(1250250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250251, 1, "364ce0ba658c13f766ee361d0118fb4bd0b42129eaf9d758f01b7549336bdfbe")
