-- Lua provided by RyzenAPI
-- Game: 942900

-- MAIN APPLICATION
addappid(942900)
-- Game: addappid(942900)

-- MAIN APP DEPOTS / PACKAGES
addappid(942901, 1, "fbe7d2f31f57608f06962cfc096c0ce539b09a464a3f807edcb4542b46062010")
