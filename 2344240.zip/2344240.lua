-- Lua provided by RyzenAPI
-- Game: StreetStep: 21st Century Basketball

-- MAIN APPLICATION
addappid(2344240)
-- Game: addappid(2344240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2344241, 1, "5a5e487df27bd27c9d1ae0623def2637db58d77acb517bd9e4109dbb48058c58")
