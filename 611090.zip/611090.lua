-- Lua provided by RyzenAPI
-- Game: 611090

-- MAIN APPLICATION
addappid(611090)
-- Game: addappid(611090)

-- MAIN APP DEPOTS / PACKAGES
addappid(611091, 1, "4e798fd1cb0b5b1a81bd185b264b8da610adfcf3b1fc38050047c551e7b0d620")
