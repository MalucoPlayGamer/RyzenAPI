-- Lua provided by RyzenAPI
-- Game: AppID 809320

-- MAIN APPLICATION
addappid(809320)

-- MAIN APP DEPOTS / PACKAGES
addappid(809321, 1, "1202ee18f3bd1a501dc3551d9b0ffb173eb4aa435edd613d06f1cb6bad9cd929")
