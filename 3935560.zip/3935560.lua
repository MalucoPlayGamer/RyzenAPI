-- 3935560's Lua and Manifest Created by Hubcap Manifest
-- Slither Link Plus
-- Created: August 03, 2026 at 02:50:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3935560, 1, "507d2309de00fc7342c60b03c35b29833d47b94dfc4d663b12df5e41f929ff78") -- Slither Link Plus
-- MAIN APP DEPOTS
addappid(3935561, 1, "624004840b2e98e73a46a6e119a2656f8ab4597cd4d0fd3c9093d1236cc590d5") -- Depot 3935561
setManifestid(3935561, "5504119694397490123", 46639739)