-- Lua provided by RyzenAPI
-- Game: B. Braun Future Operating Room

-- MAIN APPLICATION
addappid(550520)
-- Game: addappid(550520)

-- MAIN APP DEPOTS / PACKAGES
addappid(550524,0,"749590ba0b12ff3c17d001b576d98411378d68204e17d38c07784a75d8a784d1")
