-- Lua provided by RyzenAPI
-- Game: 1902300

-- MAIN APPLICATION
addappid(1902300)
-- Game: addappid(1902300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902301, 1, "2ca584e6346dc1d646ec6d52437392edc6c3cb828fa4a8bf13693b902d2ac693")
