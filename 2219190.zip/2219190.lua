-- Lua provided by RyzenAPI
-- Game: addappid(2219190)

-- MAIN APPLICATION
addappid(2219190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219191, 1, "7039177bd523fadb374d9c4b5f6d33b41d00b8535c0c0d597926dbe9cc1c5b68")
