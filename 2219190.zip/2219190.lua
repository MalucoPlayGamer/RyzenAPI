-- Lua provided by SkyAPI 
-- Game: Balance 100
addappid(2219190)
addappid(2219191, 1, "7039177bd523fadb374d9c4b5f6d33b41d00b8535c0c0d597926dbe9cc1c5b68")
