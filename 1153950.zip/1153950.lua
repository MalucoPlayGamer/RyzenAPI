-- Lua provided by RyzenAPI
-- Game: USAGIRI

-- MAIN APPLICATION
addappid(1153950)
-- Game: addappid(1153950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153951, 1, "b4b012c4740e29c26b2615986bc90f6573a4e9ea82db3683427b301be8aa68ab")
