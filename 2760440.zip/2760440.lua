-- Lua provided by RyzenAPI 
-- Game: AppID 2760440
addappid(2760440)
addappid(2760441, 1, "3074d998f2169c90f6ed383dac52011b0a226f7c2b4402f181e64115c0c7a6ea")
