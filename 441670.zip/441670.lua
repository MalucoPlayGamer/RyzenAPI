-- Lua provided by SkyAPI 
-- Game: Jelly Killer
addappid(441670)
addappid(441671, 1, "98156769bb7b34cb596a7eaf46f3265159d76a454b3582f742fb0c518588c129")
