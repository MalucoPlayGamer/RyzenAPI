-- Lua provided by RyzenAPI
-- Game: Jelly Killer

-- MAIN APPLICATION
addappid(441670)

-- MAIN APP DEPOTS / PACKAGES
addappid(441671, 1, "98156769bb7b34cb596a7eaf46f3265159d76a454b3582f742fb0c518588c129")
