-- Lua provided by RyzenAPI
-- Game: addappid(1503920)

-- MAIN APPLICATION
addappid(1503920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503921, 1, "c7ad914fd63a67636fbb306f7d6fb41777a34b366c19922ca386e84798b8368f")
