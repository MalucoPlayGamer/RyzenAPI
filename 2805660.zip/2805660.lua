-- Lua provided by RyzenAPI
-- Game: addappid(2805660)

-- MAIN APPLICATION
addappid(2805660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805661, 1, "8694d7bfdc9ca4881fd519da2f37699fbcf352341caea2f51fcb273a5f834544")
