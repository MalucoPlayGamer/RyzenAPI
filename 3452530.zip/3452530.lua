-- Lua provided by RyzenAPI
-- Game: Game: Run-Sprint-Parkour!

-- MAIN APPLICATION
addappid(3452530)
-- Game: addappid(3452530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3452531, 1, "43f2c92eca8e99aab0f2af65884a66b021d9efd35b4e484f1ca48b48379000c1")
