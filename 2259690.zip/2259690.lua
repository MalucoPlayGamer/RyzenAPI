-- Lua provided by SkyAPI 
-- Game: AIKAGI After Days
addappid(2259690)
addappid(2259691, 1, "64ee1c3d10cc21b8a969b126539541308668b8e21d1c9325c0d82b424a099074")
