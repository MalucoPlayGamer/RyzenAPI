-- Lua provided by RyzenAPI
-- Game: AIKAGI After Days

-- MAIN APPLICATION
addappid(2259690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259691, 1, "64ee1c3d10cc21b8a969b126539541308668b8e21d1c9325c0d82b424a099074")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
