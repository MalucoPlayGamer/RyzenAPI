-- Lua provided by RyzenAPI
-- Game: AIKAGI After Days

-- MAIN APPLICATION
addappid(2259690)
-- Game: addappid(2259690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259691, 1, "64ee1c3d10cc21b8a969b126539541308668b8e21d1c9325c0d82b424a099074")
