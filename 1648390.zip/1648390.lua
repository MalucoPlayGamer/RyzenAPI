-- Lua provided by RyzenAPI
-- Game: ScooterFlow

-- MAIN APPLICATION
addappid(1648390)
addappid(4390020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648391, 1, "7ed985af42eead2970bf0b43eb8ab5487b31564347f6811cacdf3c73e355edc4")

