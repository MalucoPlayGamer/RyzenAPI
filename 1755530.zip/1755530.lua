-- Lua provided by RyzenAPI
-- Game: Days with Ophelia: The Girl From Wind City

-- MAIN APPLICATION
addappid(1755530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755531, 1, "fb1d5f67f30515b9d6452073b1b91424b3af9ff60642577d9fad3e45a3c49c9b")
addappid(1755532, 1, "1dac05b61b1ae5e4ddca3772b0e0d4846807464a2aa8f0b9479a986853d21642")
addappid(1755533, 1, "eb57f93f471a3fa895f0f19d05aa75294311fdc8e028d20d1965928f6ba9e72c")
