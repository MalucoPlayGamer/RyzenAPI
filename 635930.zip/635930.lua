-- Lua provided by RyzenAPI
-- Game: DOGO

-- MAIN APPLICATION
addappid(635930)

-- MAIN APP DEPOTS / PACKAGES
addappid(635931,0,"888c6de5edb23094e5a3cb481c6f706547b3c29e4e81a4b416191bb33ede3e4d")

