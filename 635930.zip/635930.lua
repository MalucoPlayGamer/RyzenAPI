-- Lua provided by RyzenAPI
-- Game: DOGO

-- MAIN APPLICATION
addappid(635930)

-- MAIN APP DEPOTS / PACKAGES
addappid(635931,0,"888c6de5edb23094e5a3cb481c6f706547b3c29e4e81a4b416191bb33ede3e4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
