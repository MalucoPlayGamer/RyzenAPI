-- Lua provided by RyzenAPI
-- Game: 704370

-- MAIN APPLICATION
addappid(704370)
-- Game: addappid(704370)

-- MAIN APP DEPOTS / PACKAGES
addappid(704371, 1, "cf7c0ba6bce82f2be87af9849cf6841a94f8bf77688c6f5ad93749dddf5baae7")
