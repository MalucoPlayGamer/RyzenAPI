-- Lua provided by RyzenAPI
-- Game: Game: Space Channel 5: Part 2

-- MAIN APPLICATION
addappid(71260)
addappid(228983)
addappid(228990)
-- Game: addappid(71260)

-- MAIN APP DEPOTS / PACKAGES
addappid(71261, 1, "3131b446868262dd501665db7dc73f65035a7ea72e3cef00b55124c175b49873")
