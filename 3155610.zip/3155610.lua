-- Lua provided by RyzenAPI
-- Game: XEYYEX 2: Colour Wars

-- MAIN APPLICATION
addappid(3155610)
-- Game: addappid(3155610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155611, 1, "497ed35c360d42c04b0e3f13024a3aa7356041adc257b3a0a22d12883f3fa341")
