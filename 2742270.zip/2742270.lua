-- Lua provided by RyzenAPI
-- Game: Apex Heroines - Sun Punch 日字冲拳

-- MAIN APPLICATION
addappid(2742270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742270,0,"8e23dee49404f2ebc8393fd557838025bb783f068faff589452a4d354e9083ef")

