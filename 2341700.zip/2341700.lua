-- Lua provided by SkyAPI 
-- Game: Akpala
addappid(2341700)
addappid(2341701, 1, "bb922e32e482fa52670ffe39e1ac680902f1b988616fac5fac0abb1a0cc133cb")
addappid(3166600)
