-- Lua provided by RyzenAPI
-- Game: 2907270

-- MAIN APPLICATION
addappid(2907270)
-- Game: addappid(2907270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2907271, 1, "ad4113c901faec1bf47a304872db386ce5942658fab012b49ae3269be084b5d5")
