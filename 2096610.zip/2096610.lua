-- Lua provided by RyzenAPI
-- Game: Crysis 3 Remastered

-- MAIN APPLICATION
addappid(2096610)
-- Game: addappid(2096610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096611, 1, "7520613d714314319c640eaa259e33f95eea91f174c51525abd3ebd5c0698456")
