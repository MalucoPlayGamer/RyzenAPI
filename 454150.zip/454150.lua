-- Lua provided by RyzenAPI
-- Game: Voxel Warfare Online

-- MAIN APPLICATION
addappid(454150)

-- MAIN APP DEPOTS / PACKAGES
addappid(454155,0,"cc53f2dac6c6d4f5f8407c81642f6b08947a8f435a8496c62a47354500603233")
addtoken(454150,16469728316205589705)

