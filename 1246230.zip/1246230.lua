-- Lua provided by SkyAPI 
-- Game: Boom Blaster
addappid(1246230)
addappid(1246231, 1, "a6a44fb08373bb93cb7d341052e64006e4f9be1339bdf4744c7e2719a8da889d")
