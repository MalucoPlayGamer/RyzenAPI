-- Lua provided by SkyAPI 
-- Game: AppID 2774270
addappid(2774270)
addappid(2774271, 1, "2ba1a868daea765f5a08af452a50eb052eda052896eb01b79f7454f5e719b9a6")
