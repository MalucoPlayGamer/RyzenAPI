-- Lua provided by RyzenAPI 
-- Game: AppID 298340
addappid(298340)
addappid(298341, 1, "36c2d34cecb72865c2915cff939c28f738855d2a4cc1af96c1634bb749da5709")
addappid(298343, 1, "2988fcac32b97849edd70f541344d36ed9691006b0e4d8322f186e346fd36ae9")
