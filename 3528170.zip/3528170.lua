-- 3528170's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Hanma is streaming
-- Created: December 05, 2025 at 01:44:51 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3528170) -- Hentai Clicker: Hanma is streaming
-- MAIN APP DEPOTS
addappid(3528171, 1, "f6379f311283e54681071bb5e82a71e028f8f626631f1d6583eb91f105c54e45") -- Depot 3528171
setManifestid(3528171, "5188895393122222550", 150870641)