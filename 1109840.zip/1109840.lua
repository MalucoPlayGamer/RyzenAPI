-- Lua provided by RyzenAPI
-- Game: AppID 1109840

-- MAIN APPLICATION
addappid(1109840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1109841, 1, "75ab219fdd320707cbd4dab3a900e8eaa62a95b70ec4b3e58aa34770895afd1f")
addappid(1109842, 1, "2e66fe093de2165bd35ecd6dae6845a2a6ec02ee31a8825c8b7415df736b717d")
addappid(1109843, 1, "c78695520bb2d378e0fcf1808a60e09700b2bdf5ee6f161b0638c9308d3ac72e")
addappid(1109844, 1, "973173b98757600039505d36427644647882e49df6b29271e6e3a275f6127f7c")
addappid(1479800, 0, "bb641c03a130d1277ddc2caf41ad4520109bf5267afffbba599f09f5efb0d0fd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2331430)
