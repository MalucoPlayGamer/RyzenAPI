-- Lua provided by RyzenAPI
-- Game: URUBU

-- MAIN APPLICATION
addappid(1939290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939291, 1, "17d2cff5dabb990a3f78ff6951145c93783c3c0d72babdb1f9df679847bc9732")

