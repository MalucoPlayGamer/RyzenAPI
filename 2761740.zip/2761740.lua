-- Lua provided by RyzenAPI 
-- Game: 弈剑江湖 Demo
addappid(2761740)
addappid(2761741, 1, "8955716420af7fa55bf02f835a41f80ef8944e78e85764b65f29b207bb339b25")
