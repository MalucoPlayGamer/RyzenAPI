-- Lua provided by RyzenAPI
-- Game: Farm Manager

-- MAIN APPLICATION
addappid(3759820)

