-- Lua provided by RyzenAPI
-- Game: Game: Quasimorph: End of Dream

-- MAIN APPLICATION
addappid(2347110)
-- Game: addappid(2347110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347111, 1, "d1d983284a0aa11c189d9c15e47124fd5b5d21b884e08c8a544b1c8b17fbdadf")
