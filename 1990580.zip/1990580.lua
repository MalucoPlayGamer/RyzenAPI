-- Lua provided by RyzenAPI
-- Game: addappid(1990580)

-- MAIN APPLICATION
addappid(1990580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990581, 1, "207e3f83185bf61bd76cc99b0b69f55326967ed22a651857da7a35dcc643ceff")
