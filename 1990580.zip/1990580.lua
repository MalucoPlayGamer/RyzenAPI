-- Lua provided by RyzenAPI
-- Game: 异界生存

-- MAIN APPLICATION
addappid(1990580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1990581, 1, "207e3f83185bf61bd76cc99b0b69f55326967ed22a651857da7a35dcc643ceff")

