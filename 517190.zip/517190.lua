-- Lua provided by RyzenAPI
-- Game: Rebound

-- MAIN APPLICATION
addappid(517190)
addappid(517191)

-- MAIN APP DEPOTS / PACKAGES
addappid(517192,0,"e04d204d0d58a800daa693a3b8b81dd3e5f8401b520c2adaccbbeb110f0fc9ac")
addappid(517193,0,"b2c1bfc951fe7d2c41b1a83dbb42909c1aca8bf5be250fe6fa126c97428078f9")
addappid(517194,0,"8c0761d172acce11ad60e3bf7ee3d93f5424de4ce1c8564730f332a9ddf3134c")
addappid(517195,0,"79c2f77b26b3e2055bc55681ed86923bd805ba4031407feeab82c1a17be544d1")
addappid(517196,0,"7d339634b6ff1e1b9d0e0d966f5012b5a2e21eed1efe2f9a1cc333779725f4ff")
addappid(517197,0,"9b96a99766de002b48c92a8761d403f59f0ba3fcdeb82f12bc285866d9c0c35b")

