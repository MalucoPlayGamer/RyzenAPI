-- 3634020's Lua and Manifest Created by Hubcap Manifest
-- Dante's RUMBA
-- Created: July 30, 2026 at 00:12:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3634020) -- Dante's RUMBA
-- MAIN APP DEPOTS
addappid(3634021, 1, "5c5d2b58cf520c4353e10206cf49a6688129ca53ce5f5f1bcce134b2b9773484") -- Depot 3634021
setManifestid(3634021, "6463642672809900972", 1169458089)