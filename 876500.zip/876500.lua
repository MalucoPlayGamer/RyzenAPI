-- Lua provided by RyzenAPI
-- Game: HyperDot

-- MAIN APPLICATION
addappid(876500)

-- MAIN APP DEPOTS / PACKAGES
addappid(876501, 1, "40a6e8c07fdca78c01852364a5f579d0424e0bb14d8a23a1b0b30b0c5c161cbb")

