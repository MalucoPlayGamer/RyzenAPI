-- Lua provided by RyzenAPI 
-- Game: Delirium
addappid(3293250)
addappid(3293251, 1, "46544bd0c06c823cbaf2b80e9fdace7f17a07b8636abf7db0e23080c84ffc824")
