-- Lua provided by RyzenAPI
-- Game: 3293250

-- MAIN APPLICATION
addappid(3293250)
-- Game: addappid(3293250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3293251, 1, "46544bd0c06c823cbaf2b80e9fdace7f17a07b8636abf7db0e23080c84ffc824")
