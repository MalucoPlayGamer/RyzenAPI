-- Lua provided by RyzenAPI
-- Game: Millie's Adventure

-- MAIN APPLICATION
addappid(2074580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074581, 1, "2dbe52ccc69f2256126848615b502fd4e2e7bfcf5c9e0e494a83aeb63c3ad2a1")

