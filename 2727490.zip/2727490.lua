-- Lua provided by SkyAPI 
-- Game: BLITZ ARENA
addappid(2727490)
addappid(2727491, 1, "519fc140541704919be35c63c7236388d7c6324945e995a22ec528cc4dcdff48")
