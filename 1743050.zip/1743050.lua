-- Lua provided by RyzenAPI
-- Game: Robo pocket: 3d fighter with rollback

-- MAIN APPLICATION
addappid(1743050)
-- Game: addappid(1743050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743051, 1, "f7cb2f787c0cf560e06f428c8ad4f7e288e4958aafa2a0f88cfb8a93e511e4a9")
