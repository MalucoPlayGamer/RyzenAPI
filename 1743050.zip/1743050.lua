-- Lua provided by RyzenAPI
-- Game: Robo pocket: 3d fighter with rollback

-- MAIN APPLICATION
addappid(1743050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1743051, 1, "f7cb2f787c0cf560e06f428c8ad4f7e288e4958aafa2a0f88cfb8a93e511e4a9")

