-- Lua provided by RyzenAPI
-- Game: Orbit

-- MAIN APPLICATION
addappid(2196210)
addappid(2239630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196211, 1, "da9546d4de0317eee5966cf96ad6ff0a4191af732b347d2a83930772b688ca74")

