-- Lua provided by RyzenAPI
-- Game: ReX

-- MAIN APPLICATION
addappid(727540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(727541, 1, "7bc05645b258a0d57638152a33af0861c9d2591adda17ee5ad31faa297c45f56")
addappid(727542, 1, "584df2101f157ae41a59904d103be879854fc76d64b7922c2dd0f6566fab4b7c")
