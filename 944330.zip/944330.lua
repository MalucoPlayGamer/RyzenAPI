-- Lua provided by RyzenAPI
-- Game: 944330

-- MAIN APPLICATION
addappid(944330)
-- Game: addappid(944330)

-- MAIN APP DEPOTS / PACKAGES
addappid(944332,0,"9bf1b42d5ebde3d592f09fec7b6a0770021ae9b0baf414d724a5a9d548741a2e")
