-- Lua provided by RyzenAPI
-- Game: Hunt and Snare

-- MAIN APPLICATION
addappid(944330)

-- MAIN APP DEPOTS / PACKAGES
addappid(944332,0,"9bf1b42d5ebde3d592f09fec7b6a0770021ae9b0baf414d724a5a9d548741a2e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
