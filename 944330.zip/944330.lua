-- Lua provided by RyzenAPI
-- Game: Hunt and Snare

-- MAIN APPLICATION
addappid(944330)

-- MAIN APP DEPOTS / PACKAGES
addappid(944332,0,"9bf1b42d5ebde3d592f09fec7b6a0770021ae9b0baf414d724a5a9d548741a2e")
