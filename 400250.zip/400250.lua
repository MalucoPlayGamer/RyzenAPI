-- Lua provided by RyzenAPI
-- Game: AppID 400250

-- MAIN APPLICATION
addappid(400250)

-- MAIN APP DEPOTS / PACKAGES
addappid(400251, 1, "34ee9d6655c6505a5db0902f20a0852224d291396b20a361a85501a49b9561a7")
addappid(400252, 1, "52a1e6024571f45845f3d31fb073f7b3dc6b90cff2686631b614c80c724f226c")
addappid(400253, 1, "c526fb5642e2dcd5d5c480446dfaf52c7dc63ac7e9fb44d0bef9ad515e6529b9")
addappid(455470, 0, "101ddee2d5da8c241c4886c68ba1962fbf339ce47e58df2e5b99e7c24c617f73")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(573920)
