-- Lua provided by RyzenAPI
-- Game: Game: AppID 1233280

-- MAIN APPLICATION
addappid(1233280)
-- Game: addappid(1233280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233281, 1, "4a5e8e0f4729f38afb17748f565f7a342968b6345f622d9031d51370acd5175a")
addappid(1233282, 1, "c496f66738b7af1b4fd7c233acf5b28d8b408aa255df02cf8d811b179bcf63dd")
