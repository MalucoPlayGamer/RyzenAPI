-- Lua provided by RyzenAPI
-- Game: MadOut Ice Storm

-- MAIN APPLICATION
addappid(400500)

-- MAIN APP DEPOTS / PACKAGES
addappid(400501, 1, "80ab91eafbb04fe8404fa958b26209b176874e00cab1f0d3ed22c1e6c221afa0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
