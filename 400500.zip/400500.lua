-- Lua provided by RyzenAPI
-- Game: Game: MadOut Ice Storm

-- MAIN APPLICATION
addappid(400500)
-- Game: addappid(400500)

-- MAIN APP DEPOTS / PACKAGES
addappid(400501, 1, "80ab91eafbb04fe8404fa958b26209b176874e00cab1f0d3ed22c1e6c221afa0")
