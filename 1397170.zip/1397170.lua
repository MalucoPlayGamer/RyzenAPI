-- Lua provided by SkyAPI 
-- Game: Anime Wave Simulator
addappid(1397170)
addappid(1397171, 1, "73cc2ca26e98d4df8269156946e1147aaf9bf791444b4f7388de93105ac1dcc3")
