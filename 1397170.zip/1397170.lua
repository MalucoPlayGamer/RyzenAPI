-- Lua provided by RyzenAPI
-- Game: Game: Anime Wave Simulator

-- MAIN APPLICATION
addappid(1397170)
-- Game: addappid(1397170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397171, 1, "73cc2ca26e98d4df8269156946e1147aaf9bf791444b4f7388de93105ac1dcc3")
