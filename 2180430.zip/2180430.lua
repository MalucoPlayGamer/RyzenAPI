-- Lua provided by RyzenAPI
-- Game: MeiQi 2023

-- MAIN APPLICATION
addappid(2180430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2180431, 1, "94ab8fd69a0267675c3d5df4003e54dc33e3bd3035e18097e7c64d39bb0134e7")

