-- Lua provided by RyzenAPI
-- Game: Game: MeiQi 2023

-- MAIN APPLICATION
addappid(2180430)
-- Game: addappid(2180430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180431, 1, "94ab8fd69a0267675c3d5df4003e54dc33e3bd3035e18097e7c64d39bb0134e7")
