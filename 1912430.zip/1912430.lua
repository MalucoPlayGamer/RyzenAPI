-- Lua provided by RyzenAPI
-- Game: Game: AppID 1912430

-- MAIN APPLICATION
addappid(1912430)
-- Game: addappid(1912430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912431, 1, "ac2b1868aae600d296ec16f899129823050cea775d14b14ee90414752e40c77a")
