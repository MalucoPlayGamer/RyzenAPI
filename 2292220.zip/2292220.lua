-- Lua provided by RyzenAPI
-- Game: Dungeons of the Obelisk

-- MAIN APPLICATION
addappid(2292220)
-- Game: addappid(2292220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292221, 1, "e344244bceb8e12801de19a47eef0853eb8a380110d2f4faf4ff93dbb899690e")
