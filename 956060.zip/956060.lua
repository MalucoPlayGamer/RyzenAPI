-- Lua provided by RyzenAPI
-- Game: Mittelborg: City of Mages

-- MAIN APPLICATION
addappid(956060)
addappid(956061)
addappid(956063)
addappid(956064)
-- Game: addappid(956060)

-- MAIN APP DEPOTS / PACKAGES
addappid(956062,0,"99545a3de4ecc2830457482fd538b97d1095f92ab016892bd16c8feb4bad592b")
