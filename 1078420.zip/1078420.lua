-- Lua provided by RyzenAPI
-- Game: addappid(1078420)

-- MAIN APPLICATION
addappid(1078420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078421, 1, "5ced3d1b6b07ca4f0b8763c92f6ba3b1f2aeed7bbce48895ed242e5dfaca22eb")
addappid(1078422, 1, "d6a61b30148d61ce04d4feb25f3eb280b732e9ecdeabe9d97f77da1aeda69cf1")
addappid(1078423, 1, "82729901608663dc572562628a458ae20e625fe950ad70bad6fb132e4ee6fe04")
