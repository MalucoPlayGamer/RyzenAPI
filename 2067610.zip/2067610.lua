-- Lua provided by RyzenAPI
-- Game: KoreanPoliticalFighters : 2ND

-- MAIN APPLICATION
addappid(2067610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067611, 1, "e5a4aadf25204f446629336f33cb841f9d2e59ea0168baed97a4fe5b3f8ab301")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
