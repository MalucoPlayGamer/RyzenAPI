-- Lua provided by RyzenAPI 
-- Game: KoreanPoliticalFighters : 2ND
addappid(2067610)
addappid(2067611, 1, "e5a4aadf25204f446629336f33cb841f9d2e59ea0168baed97a4fe5b3f8ab301")
