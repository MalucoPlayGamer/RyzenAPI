-- Lua provided by RyzenAPI
-- Game: Aero GPX Demo

-- MAIN APPLICATION
addappid(2161320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161321, 1, "7d37a097c2bcfb20463ad9c1bfe9aa0329f6e4458ba9c3178416f7d64cb049e4")
