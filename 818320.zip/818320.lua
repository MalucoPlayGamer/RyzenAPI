-- Lua provided by RyzenAPI
-- Game: LEGO® The Incredibles

-- MAIN APPLICATION
addappid(818320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(818321, 1, "6ce5dfe98f68fe49ee0ca8464231b09d5d34c71227f41b4a98d2e77fea8a87da")
addappid(818322, 1, "bf53a94edb83cc75dc2db28f848f970ca181b78da71b13728f7a1541b9c62a42")
addappid(818323, 1, "f79b5fc4dd1d7295bce13c630425cf08596173103cbba38750a5d6f7dc6850b2")
addappid(818330, 0, "d3782143e833f0a2ee1f432490d82e17dedc4b8ec937d351418e7285f5a7fa6e")

