-- Lua provided by RyzenAPI
-- Game: Game: AppID 2802160

-- MAIN APPLICATION
addappid(2802160)
-- Game: addappid(2802160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802161, 1, "1c93f8f8b416c14df038bc9d41de9085b4bc4e5e67e29fe831e4ceb1ae68c655")
