-- Lua provided by RyzenAPI
-- Game: Grimgrad

-- MAIN APPLICATION
addappid(1837340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1837341, 1, "24ba207f9fb9574d2121090df3a114cc545532a4e21e8271a9a7d85632388ffc")
addappid(1837342, 1, "ccab1f21885b1fee2bd7ac3cc0b75f453ce30b637dced1cef7e6d74482abe8c2")

