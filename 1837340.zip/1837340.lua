-- Lua provided by RyzenAPI
-- Game: 1837340

-- MAIN APPLICATION
addappid(1837340)
-- Game: addappid(1837340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837341, 1, "24ba207f9fb9574d2121090df3a114cc545532a4e21e8271a9a7d85632388ffc")
addappid(1837342, 1, "ccab1f21885b1fee2bd7ac3cc0b75f453ce30b637dced1cef7e6d74482abe8c2")
