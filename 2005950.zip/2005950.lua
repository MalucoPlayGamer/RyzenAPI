-- Lua provided by RyzenAPI
-- Game: The Rabbit's Scroll

-- MAIN APPLICATION
addappid(2005950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2005951, 1, "ecb00354b7de26c57d26b0d127170d07a7b5558aa5d16a42de25586e8a5490ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
