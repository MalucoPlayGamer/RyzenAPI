-- Lua provided by RyzenAPI 
-- Game: The Rabbit's Scroll
addappid(2005950)
addappid(2005951, 1, "ecb00354b7de26c57d26b0d127170d07a7b5558aa5d16a42de25586e8a5490ba")
