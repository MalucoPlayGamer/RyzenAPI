-- Lua provided by RyzenAPI
-- Game: Game: Nekomata Kitan

-- MAIN APPLICATION
addappid(1894370)
addappid(2308450)
-- Game: addappid(1894370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894371, 1, "158691d884bfec4b5dda88765c8919e343f312e22fd0b3aa073805fb303cc639")
