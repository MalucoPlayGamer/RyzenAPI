-- Lua provided by RyzenAPI
-- Game: The Gauntlet

-- MAIN APPLICATION
addappid(2701020)
-- Game: addappid(2701020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701021, 1, "c938e541cc99e28fb6ccc6a7b3318cc27444af243f1d1e26d5cd73df135c90e0")
