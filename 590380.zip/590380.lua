-- Lua provided by RyzenAPI
-- Game: Into the Breach

-- MAIN APPLICATION
addappid(590380)

-- MAIN APP DEPOTS / PACKAGES
addappid(590381, 1, "0f473a094a1ad7c93b49ad57618ea958e903510c26e39db8fd1bdfb0b29a9061")
addappid(590382, 1, "d7fbb3e761e4323321c053d368f5c1b99722fcb1f608182fdc9a0a962bccae39")
addappid(590383, 1, "d5a2478194548ef6050a0df0ebcdda38e0ec71f36498f865075f50e1694fe011")

