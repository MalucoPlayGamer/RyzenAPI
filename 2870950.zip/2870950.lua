-- Lua provided by RyzenAPI 
-- Game: Splash Carnival
addappid(2870950)
addappid(2870951, 1, "cc2917b58d53070adb779cd8e5a3f2a588096718605eba73743527a6548283fb")
