-- Lua provided by RyzenAPI
-- Game: Chrono Recorder

-- MAIN APPLICATION
addappid(2843090)
-- Game: addappid(2843090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843091, 1, "0a2672716fbf2f1737f143e1b767c029fe581c5486a601bf9945536b8825a1c9")
