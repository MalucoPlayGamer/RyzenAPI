-- Lua provided by RyzenAPI
-- Game: Charrua Soccer - Pro Edition

-- MAIN APPLICATION
addappid(2283380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283381, 1, "2b048aea8a8eedf5651571119c86f2538e357bc31439b1933092b3fd49bb2056")
