-- Lua provided by RyzenAPI
-- Game: Raiders Of The Lost Island

-- MAIN APPLICATION
addappid(867980)

-- MAIN APP DEPOTS / PACKAGES
addappid(867981,0,"11e4ccabddf798195e5dd1ed6b473a690f0bb876d0ca126e007d4d91b483a1f0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
