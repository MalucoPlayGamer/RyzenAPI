-- Lua provided by RyzenAPI
-- Game: Raiders Of The Lost Island

-- MAIN APPLICATION
addappid(867980)

-- MAIN APP DEPOTS / PACKAGES
addappid(867981,0,"11e4ccabddf798195e5dd1ed6b473a690f0bb876d0ca126e007d4d91b483a1f0")

