-- Lua provided by RyzenAPI
-- Game: Primordia

-- MAIN APPLICATION
addappid(227000)
-- Game: addappid(227000)

-- MAIN APP DEPOTS / PACKAGES
addappid(227001, 1, "8c3cc95fb36ea0a5f84bbb69910be9ae6dfc2102ebf8437d1e97d618b2a3152e")
addappid(227002, 1, "7d3c59eee3a7dd3f977ab23b7a7a911775c16b2ce1f3430f9230f3d3aad2d72d")
addappid(227003, 1, "d0ed11ebfd9609638411b402a7ffc11b51e6d93b675645666304cbf64b15a9fc")
addappid(227007, 1, "05f67000511ef97213c6853fce8426848e039b82288ab66b037e875ffbedc8de")
