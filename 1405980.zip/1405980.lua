-- Lua provided by RyzenAPI
-- Game: 1405980

-- MAIN APPLICATION
addappid(1405980)
-- Game: addappid(1405980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405981, 1, "0f5904a7284cf92ead43a62cce11bb6717205c3e5e8108b81803279a9cda844b")
