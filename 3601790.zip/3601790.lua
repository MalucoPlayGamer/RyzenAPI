-- Lua provided by RyzenAPI
-- Game: Game: your girl

-- MAIN APPLICATION
addappid(3601790)
-- Game: addappid(3601790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3601791, 1, "3b4488c19f2414b1dc87dfc545ba3835746cbc3b585434d1d3057d961771a163")
