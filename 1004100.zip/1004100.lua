-- Lua provided by RyzenAPI
-- Game: Game: Chaos Caves

-- MAIN APPLICATION
addappid(1004100)
-- Game: addappid(1004100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004101, 1, "dffaf289f16c99e06a18e874208776ded38e3032361581cd5b5f060b5fbdf5c5")
