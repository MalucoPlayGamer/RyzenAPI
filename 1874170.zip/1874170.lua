-- Lua provided by RyzenAPI
-- Game: Shredders

-- MAIN APPLICATION
addappid(1874170)
addappid(2320520)
addappid(2320521)
addappid(2320522)
addappid(2320523)
addappid(2320524)
addappid(2320525)
addappid(2320526)
addappid(2320527)
addappid(2320528)
addappid(2320529)
addappid(2320540)
addappid(2320541)
addappid(2399620)
addappid(3907700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1874171, 1, "50b1b11197001951c2a7644def7c3024b28d0d99d7acc30f0cf20a64af6c0733")

