-- Lua provided by RyzenAPI 
-- Game: Shredders
addappid(1874170)
addappid(1874171, 1, "50b1b11197001951c2a7644def7c3024b28d0d99d7acc30f0cf20a64af6c0733")
