-- Lua provided by RyzenAPI 
-- Game: EZ-Crosshair
addappid(2434730)
addappid(2434731, 1, "bd3da6521f6d06467aaf9a06cd67482719cd2d9b55d786bab061744a3354d7a8")
