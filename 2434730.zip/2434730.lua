-- Lua provided by RyzenAPI
-- Game: EZ-Crosshair

-- MAIN APPLICATION
addappid(2434730)
-- Game: addappid(2434730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434731, 1, "bd3da6521f6d06467aaf9a06cd67482719cd2d9b55d786bab061744a3354d7a8")
