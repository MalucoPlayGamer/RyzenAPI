-- Lua provided by RyzenAPI
-- Game: Simulator of Countries

-- MAIN APPLICATION
addappid(3153890)
addappid(3168430)
addappid(3218920)
addappid(3339020)
addappid(3496800)
addappid(3633620)
addappid(3826150)
addappid(4527210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3153891, 1, "9c87950ff867d0c333ed25546ad38bfd4adba0e28d6b5e95c1d005e99699677f")

