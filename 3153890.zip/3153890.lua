-- Lua provided by SkyAPI 
-- Game: Simulator of Countries
addappid(3153890)
addappid(3153891, 1, "9c87950ff867d0c333ed25546ad38bfd4adba0e28d6b5e95c1d005e99699677f")
