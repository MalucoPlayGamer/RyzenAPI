-- Lua provided by RyzenAPI
-- Game: 332880

-- MAIN APPLICATION
addappid(332880)

-- MAIN APP DEPOTS / PACKAGES
addappid(332882,0,"925cf0c510beb9a9c7781efbdc7b9e5f09ece451d2fe86cbf245e402b531fc07")

