-- Lua provided by RyzenAPI
-- Game: Kandidatos Kart

-- MAIN APPLICATION
addappid(1415140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415141, 1, "2a90e8b2d6db25ce6c383eaed806148fe431f3b8ee6f71de6ee982fb1b05bfdf")
