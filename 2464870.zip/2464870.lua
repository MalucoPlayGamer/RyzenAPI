-- Lua provided by RyzenAPI
-- Game: Power Drill Massacre Demo

-- MAIN APPLICATION
addappid(2464870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464871, 1, "61c33bc1e03ac64d8cf377d671c811fba938190d01429f2365ef568a70d55f2c")

