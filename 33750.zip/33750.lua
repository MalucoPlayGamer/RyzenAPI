-- Lua provided by RyzenAPI
-- Game: 33750

-- MAIN APPLICATION
addappid(33750)
-- Game: addappid(33750)

-- MAIN APP DEPOTS / PACKAGES
addappid(33751, 1, "b9cca92a0a0a3c4360d30cb79440bc99650f05c0ab25138e7e5d267b0541ff8e")
