-- Lua provided by RyzenAPI
-- Game: KiKiMiMi / 听能力搜查官

-- MAIN APPLICATION
addappid(1072490)
addappid(1072491)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072492,0,"7b4c7427bdce01eea1663bd7d513b4a08312ba9605d8e82492d1512324342e4a")

