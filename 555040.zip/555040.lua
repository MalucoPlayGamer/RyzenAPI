-- Lua provided by RyzenAPI
-- Game: Fan Fun

-- MAIN APPLICATION
addappid(555040)

-- MAIN APP DEPOTS / PACKAGES
addappid(555041,0,"3c79274e4d1d793337267d92aeecc762a8f8c4860c08acd23eb21ff19c640e76")

