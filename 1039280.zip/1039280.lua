-- Lua provided by RyzenAPI
-- Game: ProtoCorgi

-- MAIN APPLICATION
addappid(1039280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039281, 1, "53d40f91a21bcc391b242f6a7344b24320eee30ed5238330139f6229d9ba47dd")
addappid(1039282, 1, "e5310f33e84522c19456fa34ac9563ee33e2d0d014cad5e1b01a425d4abe4497")
addappid(1039283, 1, "e84d57666437e4481757f0b5d9b9cfdf4d28266838d03830fbe7ae3768bcef13")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
