-- Lua provided by RyzenAPI
-- Game: encrypted_nightmares

-- MAIN APPLICATION
addappid(3576980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3576981, 1, "2849b9e1910703cbcbb88dcb397973a987542a559e6261757b01d155b35e13ec")

