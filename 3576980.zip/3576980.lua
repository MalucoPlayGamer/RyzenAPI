-- Lua provided by SkyAPI 
-- Game: encrypted_nightmares
addappid(3576980)
addappid(3576981, 1, "2849b9e1910703cbcbb88dcb397973a987542a559e6261757b01d155b35e13ec")
