-- Lua provided by RyzenAPI
-- Game: Target speed

-- MAIN APPLICATION
addappid(755230)

-- MAIN APP DEPOTS / PACKAGES
addappid(755231, 1, "7b529225c6cc664d014059fcb6f01277b907bcffafb7b3b72ddec1825e2e43c9")

