-- Lua provided by RyzenAPI
-- Game: The Bridge Curse 2: The Extrication

-- MAIN APPLICATION
addappid(2331330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2331331, 1, "eb2fadb9b6ec0e6369a6cdc4d441e912bc8b31a0477d2bc3395efcaf83bb9b0a")
addappid(2915350, 0, "3fd91fa1147d67e1d3d767cafccd9f3dcc1f36b1501629175a64b022cf5509c5")

