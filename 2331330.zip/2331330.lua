-- Lua provided by RyzenAPI
-- Game: 2331330

-- MAIN APPLICATION
addappid(2331330)
-- Game: addappid(2331330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331331, 1, "eb2fadb9b6ec0e6369a6cdc4d441e912bc8b31a0477d2bc3395efcaf83bb9b0a")
addappid(2915350, 0, "3fd91fa1147d67e1d3d767cafccd9f3dcc1f36b1501629175a64b022cf5509c5")
