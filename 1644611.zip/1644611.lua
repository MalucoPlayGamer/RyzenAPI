-- Lua provided by RyzenAPI
-- Game: FUSER™ - Tiësto - "The Business"

-- MAIN APPLICATION
addappid(1644611)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644611,0,"0e0e75d46d2e5f6cbf405e8f11222c6d73ef6242ed80bba631da8fc5bf8310f5")

