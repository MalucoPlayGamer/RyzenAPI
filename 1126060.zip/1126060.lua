-- Lua provided by SkyAPI 
-- Game: AppID 1126060
addappid(1126060)
addappid(1126061, 1, "27c100c31297dad951afc8886249a93dd629193a430cd9606d14ab3ff0779755")
