-- Lua provided by RyzenAPI
-- Game: Game: AppID 1126060

-- MAIN APPLICATION
addappid(1126060)
-- Game: addappid(1126060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126061, 1, "27c100c31297dad951afc8886249a93dd629193a430cd9606d14ab3ff0779755")
