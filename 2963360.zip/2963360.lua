-- Lua provided by RyzenAPI
-- Game: Chicken Game

-- MAIN APPLICATION
addappid(2963360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963361, 1, "0ad13300f9d07787db0ef31e5c675830bc930f7036da8f94c412efa793b7e865")
