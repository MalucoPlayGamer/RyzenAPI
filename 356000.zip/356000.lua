-- Lua provided by RyzenAPI
-- Game: 356000

-- MAIN APPLICATION
addappid(356000)
-- Game: addappid(356000)

-- MAIN APP DEPOTS / PACKAGES
addappid(356001, 1, "538273de5ea9bd4ef6a028df6282652c0e99d174bfc29805695ed4f64cc61be8")
