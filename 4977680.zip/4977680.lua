-- Lua provided by RyzenAPI
-- Game: 末日战姬：废土觉醒

-- MAIN APPLICATION
addappid(4977680)
