-- Lua provided by RyzenAPI
-- Game: Game: Ace Campus Club

-- MAIN APPLICATION
addappid(1261200)
addappid(1679810)
-- Game: addappid(1261200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261201, 1, "0c5639ce26e0e2fcb223cc4ac58a0c34227f370cb1b3458c5648a2395bdbaa5a")
