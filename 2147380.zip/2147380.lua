-- Lua provided by RyzenAPI
-- Game: Heroes of Science and Fiction

-- MAIN APPLICATION
addappid(2147380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147382,0,"176adf9439ff6a2910198d8c854431276a869cb36bbc35a8d318df9186d07f20")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4844630)
