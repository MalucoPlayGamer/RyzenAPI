-- Lua provided by RyzenAPI
-- Game: Ramen

-- MAIN APPLICATION
addappid(801870)

-- MAIN APP DEPOTS / PACKAGES
addappid(801871, 1, "404dd551d40fd362e8d31f8b2860431758c5ab7eed941350d21bd14a22acaf42")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
