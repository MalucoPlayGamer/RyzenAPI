-- Lua provided by RyzenAPI
-- Game: Ramen

-- MAIN APPLICATION
addappid(801870)

-- MAIN APP DEPOTS / PACKAGES
addappid(801871, 1, "404dd551d40fd362e8d31f8b2860431758c5ab7eed941350d21bd14a22acaf42")
