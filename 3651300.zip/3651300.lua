-- Lua provided by RyzenAPI
-- Game: Game: Mist

-- MAIN APPLICATION
addappid(3651300)
-- Game: addappid(3651300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3651301, 1, "acb30d1e86b89b942739bc15e7202f8183a20b69bae60309c16ec0fac379e3a3")
