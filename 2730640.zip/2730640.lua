-- Lua provided by SkyAPI 
-- Game: Prospector: The First Contract
addappid(2730640)
addappid(2730641, 1, "fde861ea1a816fe0145d7e37446646318236189d95a28d3f07e43d11129927d0")
