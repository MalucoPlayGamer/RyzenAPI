-- Lua provided by RyzenAPI 
-- Game: AppID 596950
addappid(596950)
addappid(596951, 1, "fc68554bd5b50ce9a26ad3e3e84e50745af5d5a51984208e3797c10349941c14")
