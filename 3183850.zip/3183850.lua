-- Lua provided by RyzenAPI
-- Game: Overlord

-- MAIN APPLICATION
addappid(3183850)
-- Game: addappid(3183850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3183851, 1, "0777dc30f2ed575d1f35a4ddc5150ff5654091c2e73afb08c1a1db33580af543")
