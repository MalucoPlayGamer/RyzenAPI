-- Lua provided by RyzenAPI
-- Game: Escape from the Office

-- MAIN APPLICATION
addappid(1688240)
-- Game: addappid(1688240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688241, 1, "0bfceff82eb0708aa9a4b4cc9bb06eb139cab9bec787a30045758e6610dcc53b")
