-- Lua provided by RyzenAPI
-- Game: 3591680

-- MAIN APPLICATION
addappid(3591680)
-- Game: addappid(3591680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3591681, 1, "83e1939e3f49a1fd14c10bef0e91cb309caf8517204a825e3d2d197ad60bf3d3")
