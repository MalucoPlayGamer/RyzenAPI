-- Lua provided by RyzenAPI
-- Game: addappid(719270)

-- MAIN APPLICATION
addappid(719270)

-- MAIN APP DEPOTS / PACKAGES
addappid(719271, 1, "4b9f5a63ce9cd79e124df5771ea4b56530f9f896e2b83af8244d6d7dd880412d")
