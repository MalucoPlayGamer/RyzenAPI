-- Lua provided by RyzenAPI
-- Game: Blasterbug: Last Bug Standing!

-- MAIN APPLICATION
addappid(3069340)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4584880)
