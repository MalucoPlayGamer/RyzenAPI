-- Lua provided by RyzenAPI
-- Game: Blasterbug: Last Bug Standing!

-- MAIN APPLICATION
addappid(3069340)

