-- Lua provided by RyzenAPI
-- Game: Gearhead Karting Simulator - Mechanic & Racing

-- MAIN APPLICATION
addappid(2325800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325801, 1, "3743f78e62347197f3df1dc59625a6f2af57df01cb3f865f98a41a0c790f6dde")

