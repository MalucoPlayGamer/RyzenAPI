-- Lua provided by RyzenAPI 
-- Game: Mahou Arms
addappid(1165870)
addappid(1165871, 1, "d9f54b16c1da7cd86fb9df6038fea5304ff0ab65adbf2e0508cab3112ada43a4")
