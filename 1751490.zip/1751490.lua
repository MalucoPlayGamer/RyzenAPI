-- Lua provided by RyzenAPI 
-- Game: Wing Breakers Playtest
addappid(1751490)
addappid(1751491, 1, "92046da378c363a5d47f8ce6f4b3a4efd8a3da3f29cb34faf6757f31715a88b3")
