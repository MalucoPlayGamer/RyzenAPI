-- Lua provided by RyzenAPI
-- Game: Game: Wing Breakers Playtest

-- MAIN APPLICATION
addappid(1751490)
-- Game: addappid(1751490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751491, 1, "92046da378c363a5d47f8ce6f4b3a4efd8a3da3f29cb34faf6757f31715a88b3")
