-- Lua provided by RyzenAPI
-- Game: Tentacle Tango Demo

-- MAIN APPLICATION
addappid(3278600)
-- Game: addappid(3278600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3278601, 1, "6a65541c05443f42907992a6e596f1410fefa4478d8aedc629b6c7eca937d30c")
