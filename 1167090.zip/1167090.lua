-- Lua provided by RyzenAPI
-- Game: Desert coachman

-- MAIN APPLICATION
addappid(1167090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167091, 1, "5086b2305a3390add6f5428164bb14a0097cc2223a9a39d8a677a9b87f5d1b10")

