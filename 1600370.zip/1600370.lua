-- Lua provided by RyzenAPI
-- Game: Game: Not Tonight 2

-- MAIN APPLICATION
addappid(1600370)
-- Game: addappid(1600370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600371, 1, "359910901e1b0838168c2107bda3af42bb7f04cbe004332e9083dd8a2a279427")
