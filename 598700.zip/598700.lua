-- Lua provided by RyzenAPI
-- Game: The Vagrant

-- MAIN APPLICATION
addappid(228987)
addappid(598700)

-- MAIN APP DEPOTS / PACKAGES
addappid(598703,0,"eb31e40d798c5f0e1d1ff1387780e2ca04689c0bfefa0286d61f902ff1bd088f")
addappid(888360,0,"02e222a385e0e10ec60651f0d5f0b40afc0c20224c3f4e2b51908089665aa9b2")
addappid(930200,0,"d83f4a2a6247c078ef95f3f1f20463c6341d6e627f7a82e3e0f0fd1b00867766")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
