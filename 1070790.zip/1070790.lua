-- Lua provided by RyzenAPI
-- Game: Freshly Frosted

-- MAIN APPLICATION
addappid(1070790)
-- Game: addappid(1070790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070791, 1, "3d7415eeaf4d8eac61ac695e13c0ea62c7aa6da43fc24ae48c9e1d91ba937ca6")
