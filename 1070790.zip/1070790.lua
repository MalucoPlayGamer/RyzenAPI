-- Lua provided by RyzenAPI
-- Game: Freshly Frosted

-- MAIN APPLICATION
addappid(1070790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(1070791, 1, "3d7415eeaf4d8eac61ac695e13c0ea62c7aa6da43fc24ae48c9e1d91ba937ca6")

