-- Lua provided by RyzenAPI 
-- Game: Be Frugal
addappid(2288280)
addappid(2288281, 1, "5e8d427e34e6bb326063b8258d149b25ea5ed86aaf93b16b1d93ea64b1ed6a61")
