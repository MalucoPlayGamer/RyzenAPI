-- Lua provided by RyzenAPI
-- Game: Game: Be Frugal

-- MAIN APPLICATION
addappid(2288280)
-- Game: addappid(2288280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288281, 1, "5e8d427e34e6bb326063b8258d149b25ea5ed86aaf93b16b1d93ea64b1ed6a61")
