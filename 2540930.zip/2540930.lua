-- Lua provided by SkyAPI 
-- Game: Puppetmaster Demo
addappid(2540930)
addappid(2540931, 1, "fbd60b10befbeda3a50121282f2d5a47b6af7b113e095494d50ddf9386f93c94")
