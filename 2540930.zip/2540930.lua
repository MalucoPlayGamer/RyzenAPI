-- Lua provided by RyzenAPI
-- Game: Game: Puppetmaster Demo

-- MAIN APPLICATION
addappid(2540930)
-- Game: addappid(2540930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540931, 1, "fbd60b10befbeda3a50121282f2d5a47b6af7b113e095494d50ddf9386f93c94")
