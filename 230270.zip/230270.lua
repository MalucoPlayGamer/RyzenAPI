-- Lua provided by RyzenAPI
-- Game: N++ (NPLUSPLUS)

-- MAIN APPLICATION
addappid(230270)

-- MAIN APP DEPOTS / PACKAGES
addappid(230271, 1, "012ae7bf93394d9c13a6fe0b6a19bb864b9c9a12987f502e3701037af032e5d9")
addappid(230272, 1, "e85c3de7820321443622a22835dcc9979d4f773dfa8dd2e1e8a6fbdb330e5534")
addappid(230273, 1, "b77ff2a02f39145844f959ef3717452a87054211288ed96dcdf0575749b20d37")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
