-- Lua provided by RyzenAPI
-- Game: Game: The Mildew Children: Chapter 1

-- MAIN APPLICATION
addappid(2420330)
-- Game: addappid(2420330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420331, 1, "f9b6d72347b40989ea73ae90f29f947a00a486b678dd2f526668fff7b10ad7b0")
