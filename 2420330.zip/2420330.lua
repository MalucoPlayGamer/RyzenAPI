-- Lua provided by RyzenAPI
-- Game: The Mildew Children: Chapter 1

-- MAIN APPLICATION
addappid(2420330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420331, 1, "f9b6d72347b40989ea73ae90f29f947a00a486b678dd2f526668fff7b10ad7b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
