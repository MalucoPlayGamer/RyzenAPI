-- Lua provided by RyzenAPI
-- Game: 3569680

-- MAIN APPLICATION
addappid(3569680)
-- Game: addappid(3569680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3569680,0,"55ce8c9a94c2ee0711125b50bc78f8cddd61e9445737985eec0a48b43c72b40c")
