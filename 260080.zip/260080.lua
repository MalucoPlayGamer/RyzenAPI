-- Lua provided by RyzenAPI
-- Game: AppID 260080

-- MAIN APPLICATION
addappid(260080)
-- Game: addappid(260080)

-- MAIN APP DEPOTS / PACKAGES
addappid(260081, 1, "eb5ddcb473aa91b5bc352afaedba9cfa553006be1145ee9988abb731e6887668")
