-- Lua provided by RyzenAPI
-- Game: YOU DON'T KNOW JACK Vol. 6 The Lost Gold

-- MAIN APPLICATION
addappid(260080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(260081, 1, "eb5ddcb473aa91b5bc352afaedba9cfa553006be1145ee9988abb731e6887668")

