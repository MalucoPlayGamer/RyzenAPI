-- Lua provided by RyzenAPI
-- Game: Game: Occupy Mars: Prologue (2020)

-- MAIN APPLICATION
addappid(1310520)
-- Game: addappid(1310520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310521, 1, "f65d63d3eb26300e36cd678449e68153a2d8e10ccc67587985f5740a4a02de56")
