-- Lua provided by RyzenAPI
-- Game: 2505930

-- MAIN APPLICATION
addappid(2505930)
-- Game: addappid(2505930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505931, 1, "f12cf64ee28c15e877dd2a025a8d6db7c7a4168d11b240e603253b852716d836")
