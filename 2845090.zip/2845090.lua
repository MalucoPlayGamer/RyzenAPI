-- Lua provided by RyzenAPI 
-- Game: The Last FARMER
addappid(2845090)
addappid(2845091, 1, "83327f2c62b7dce3f9a8faa35c571d3d3284b08e34f6399f087b5a8c89169fc8")
