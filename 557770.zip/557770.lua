-- Lua provided by RyzenAPI
-- Game: AppID 557770

-- MAIN APPLICATION
addappid(557770)
-- Game: addappid(557770)

-- MAIN APP DEPOTS / PACKAGES
addappid(557771, 1, "a3d76aaf902834cce0f6af17a410e7b4704cd399433b872c0878cd2dfe1dff83")
