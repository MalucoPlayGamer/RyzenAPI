-- Lua provided by RyzenAPI
-- Game: AppID 1422260

-- MAIN APPLICATION
addappid(1422260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422261, 1, "96ce7237e672bd7a7b152febd19b5b9c3069b364af6fbef5feb73a7040cc5608")
