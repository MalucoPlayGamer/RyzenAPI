-- Lua provided by RyzenAPI
-- Game: Yore VR

-- MAIN APPLICATION
addappid(524380)

-- MAIN APP DEPOTS / PACKAGES
addappid(524381, 1, "08a6e5205f3400141074ff6fc02e0d1f35667613c1fcae3bc30d2836e2c3ceca")

