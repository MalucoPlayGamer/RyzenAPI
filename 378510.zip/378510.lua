-- Lua provided by RyzenAPI 
-- Game: AppID 378510
addappid(378510)
addappid(378511, 1, "cd1768ee10a8a6fee95ef196335d35ca698e9c0f58d66f8caf13869c74aa9bf8")
addappid(378512, 1, "3e154c4cbf1eaa60e9cc8fabf2857c0d66ed1755a241f926a3240029c25d0df2")
