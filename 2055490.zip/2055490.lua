-- Lua provided by RyzenAPI
-- Game: A Game with a Kitty 1 & Darkside Adventures

-- MAIN APPLICATION
addappid(2055490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2055491, 1, "0d75c111505a5b46e22019683cd176ac6f1e44f9b88d8ec36c40886f5cd6bbae")

