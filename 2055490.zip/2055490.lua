-- Lua provided by RyzenAPI
-- Game: A Game with a Kitty 1 & Darkside Adventures

-- MAIN APPLICATION
addappid(2055490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055491, 1, "0d75c111505a5b46e22019683cd176ac6f1e44f9b88d8ec36c40886f5cd6bbae")

