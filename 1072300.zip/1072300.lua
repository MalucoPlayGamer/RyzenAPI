-- Lua provided by RyzenAPI
-- Game: 1072300

-- MAIN APPLICATION
addappid(1072300)
-- Game: addappid(1072300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072301, 1, "aa28cb9533c649de113b564bad4f90e0bb3a397f67ddf4885e42c9b13b5286f3")
