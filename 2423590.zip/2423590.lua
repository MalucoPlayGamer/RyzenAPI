-- Lua provided by RyzenAPI
-- Game: Dr. Carlos' Personality Exam

-- MAIN APPLICATION
addappid(2423590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423591, 1, "dda0bc33a100a2357af853ddfa4312183c0495a205102b994ba6927c0c261392")

