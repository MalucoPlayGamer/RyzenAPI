-- Lua provided by RyzenAPI
-- Game: Game: Ymir

-- MAIN APPLICATION
addappid(378360)
-- Game: addappid(378360)

-- MAIN APP DEPOTS / PACKAGES
addappid(378361, 1, "713385bd229af8b8996b9c2dafada1225a6c67c2ee9b0aa5ca6fcaa19ba8bf36")
