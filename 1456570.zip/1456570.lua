-- Lua provided by RyzenAPI
-- Game: PixelJunk™ Eden 2

-- MAIN APPLICATION
addappid(1456570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456571,0,"0ccd86b4724a9fd7fd8d2b063411e66a4c997b7ec38babac72b0bf1d6b29aecd")

