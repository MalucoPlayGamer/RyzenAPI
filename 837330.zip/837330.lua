-- Lua provided by RyzenAPI 
-- Game: AppID 837330
addappid(837330)
addappid(837331, 1, "88283822f6b67a1a2357ce8ed10bbd7d1cb411551ba3abd9b9b1f76680377da3")
