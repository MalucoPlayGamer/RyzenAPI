-- Lua provided by SkyAPI 
-- Game: Aurora
addappid(1382380)
addappid(1382381, 1, "39fc13765b368cff59bd1f7487ab8f8d48cf821eea86dec444af6eb2ce73824c")
