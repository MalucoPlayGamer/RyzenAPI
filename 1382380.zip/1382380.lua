-- Lua provided by RyzenAPI
-- Game: 1382380

-- MAIN APPLICATION
addappid(1382380)
-- Game: addappid(1382380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1382381, 1, "39fc13765b368cff59bd1f7487ab8f8d48cf821eea86dec444af6eb2ce73824c")
