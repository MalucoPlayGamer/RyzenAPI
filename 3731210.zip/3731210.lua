-- Lua provided by RyzenAPI
-- Game: Game: Villages & Dungeons Soundtrack

-- MAIN APPLICATION
addappid(3731210)
-- Game: addappid(3731210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3731211, 1, "01c99b0b52a51388fe38e782f7026bf05e76e5cecb3e85f4df9bfe1239b51c6a")
