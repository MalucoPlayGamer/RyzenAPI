-- Lua provided by RyzenAPI
-- Game: Hide and Shriek

-- MAIN APPLICATION
addappid(480430)
addappid(729850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(480431, 1, "99b1201e7473625cc2b570bf7937d6f58350179d9f3feb9033e08488baba5242")
