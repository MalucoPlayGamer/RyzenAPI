-- Lua provided by RyzenAPI
-- Game: Game: AppID 480430

-- MAIN APPLICATION
addappid(480430)
-- Game: addappid(480430)

-- MAIN APP DEPOTS / PACKAGES
addappid(480431, 1, "99b1201e7473625cc2b570bf7937d6f58350179d9f3feb9033e08488baba5242")
