-- Lua provided by SkyAPI 
-- Game: Out Of Hands Playtest
addappid(1854350)
addappid(1854351, 1, "e0f1c4c045ac4c78febcae055e15f4193382103f840e14f47a03a6b2e6ee4bb3")
