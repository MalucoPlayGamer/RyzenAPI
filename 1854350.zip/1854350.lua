-- Lua provided by RyzenAPI
-- Game: Out Of Hands Playtest

-- MAIN APPLICATION
addappid(1854350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854351, 1, "e0f1c4c045ac4c78febcae055e15f4193382103f840e14f47a03a6b2e6ee4bb3")
