-- Lua provided by RyzenAPI
-- Game: Game: Enchanted - A Magic Shop

-- MAIN APPLICATION
addappid(3300060)
-- Game: addappid(3300060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3300061, 1, "4303155447542cf6bccf15826356d80d5d0e12a5c838699bf8a2ceadf1bebc08")
