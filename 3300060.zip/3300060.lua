-- Lua provided by RyzenAPI
-- Game: Enchanted - A Magic Shop

-- MAIN APPLICATION
addappid(3300060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3300061, 1, "4303155447542cf6bccf15826356d80d5d0e12a5c838699bf8a2ceadf1bebc08")

