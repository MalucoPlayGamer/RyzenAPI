-- Lua provided by SkyAPI 
-- Game: First Dwarf
addappid(1714900)
addappid(1714901, 1, "4a350b16170b0b8dedd4a037757b361c684d522266a79073451d057a9bb0a361")
