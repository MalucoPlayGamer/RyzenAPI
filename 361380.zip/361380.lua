-- Lua provided by RyzenAPI
-- Game: World War I

-- MAIN APPLICATION
addappid(361380)

-- MAIN APP DEPOTS / PACKAGES
addappid(361381, 1, "d9b9b14f9f1555b9bb29ac2720690f05b7f44c5b5ce812cf8653d06a65410bb2")
addappid(361382, 1, "8017a7e2e742717a7501697322d7b9517cb0011e8b1ab8f5cc61d1f2883519b5")
addappid(361383, 1, "9e473623a4af9de3e280dd7b36d1ec02e6e669a7ea252b94d359695ca25a547b")
addappid(361384, 1, "f09471e53c65a2782da6fec5540dcc7c03beae3d6ff404b5f388691e7798db32")
addappid(361385, 1, "846aa170eeda882d719850ae6d6e95c698cbc9a9b1141f3ee4496c223f033b9a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
