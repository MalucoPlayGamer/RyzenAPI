-- Lua provided by RyzenAPI
-- Game: Atelier Ryza 3 - Gust Extra BGM Pack

-- MAIN APPLICATION
addappid(2156253)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156253,0,"4d11750381e7041d36e373ed16308b525180f234f1f3199c35c1486821a563e2")

