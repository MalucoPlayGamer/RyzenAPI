-- Lua provided by RyzenAPI 
-- Game: AppID 877850
addappid(877850)
addappid(877851, 1, "ccad8c1141394688ea99a109d23f0e15b356be8db2c5319766e2fb79eb50bc35")
