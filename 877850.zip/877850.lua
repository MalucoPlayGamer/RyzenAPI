-- Lua provided by RyzenAPI
-- Game: Game: AppID 877850

-- MAIN APPLICATION
addappid(877850)
-- Game: addappid(877850)

-- MAIN APP DEPOTS / PACKAGES
addappid(877851, 1, "ccad8c1141394688ea99a109d23f0e15b356be8db2c5319766e2fb79eb50bc35")
