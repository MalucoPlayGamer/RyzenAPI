-- Lua provided by RyzenAPI
-- Game: AppID 877850

-- MAIN APPLICATION
addappid(877850)
addappid(1077060)
addappid(1093940)
addappid(1093941)
addappid(1194360)
addappid(1194361)
addappid(1214620)
addappid(1464880)
addappid(1502870)
addappid(1628460)
addappid(2411700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(877851, 1, "ccad8c1141394688ea99a109d23f0e15b356be8db2c5319766e2fb79eb50bc35")

