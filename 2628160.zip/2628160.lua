-- Lua provided by RyzenAPI
-- Game: Game: Captain Pawsome Demo

-- MAIN APPLICATION
addappid(2628160)
-- Game: addappid(2628160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628161, 1, "be6f7714291fde9a41e75cebe96e6988bef71f1956a0f42e4d08e923fc745bd8")
