-- Lua provided by RyzenAPI
-- Game: Deadwalker Chronicles

-- MAIN APPLICATION
addappid(3357680)
-- Game: addappid(3357680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3357681, 1, "f7c3004994a4963bccc9d3d95b5353aa60859665471c5db56b6336c85b94b30e")
