-- Lua provided by RyzenAPI
-- Game: Game: The Last Worker

-- MAIN APPLICATION
addappid(1579280)
-- Game: addappid(1579280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1579281, 1, "1e1a629bbfdbedd1c00323d80ca93043e86b901e1e3af8b961163abc4dfa8175")
