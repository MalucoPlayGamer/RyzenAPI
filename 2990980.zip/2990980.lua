-- Lua provided by RyzenAPI
-- Game: Ultra Strikers Demo

-- MAIN APPLICATION
addappid(2990980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990981, 1, "ec228f00f679a2c3da4d5e678285e817a65bd56266dd9b8fdf438096bc0e6b27")

