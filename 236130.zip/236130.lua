-- Lua provided by RyzenAPI
-- Game: Game: Horizon

-- MAIN APPLICATION
addappid(236130)
addappid(2586390)
-- Game: addappid(236130)

-- MAIN APP DEPOTS / PACKAGES
addappid(236131, 1, "5f435ce3871c1f4c7d3f929a47b9a1ab81bdee77fbe1d81cf36722d8caba6523")
addappid(236132, 1, "1da011bb2f315a8d51b37cdd6c380708643d7dad3a6db3906de6e4a5077cc8bf")
addappid(236133, 1, "210bc017376d532d426733ab6001214682866cb31ff4dd592171b0b5118aea7c")
addappid(236134, 1, "2821c5bcdd044da85bff6de306f6db70c869927aad86196aaaebb15e441e3084")
addappid(236135, 1, "e2202998c262f7220848473861f6df98d20cd10db246989d92fd46a919bfea82")
addappid(236136, 1, "b4038ea2a11aea677a3400fbd15644fa909f5ba64a9ad2f9bb251c2788b7a0d6")
