-- Lua provided by RyzenAPI
-- Game: Horizon

-- MAIN APPLICATION
addappid(236130)
addappid(2586390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(236131, 1, "5f435ce3871c1f4c7d3f929a47b9a1ab81bdee77fbe1d81cf36722d8caba6523")
addappid(236132, 1, "1da011bb2f315a8d51b37cdd6c380708643d7dad3a6db3906de6e4a5077cc8bf")
addappid(236133, 1, "210bc017376d532d426733ab6001214682866cb31ff4dd592171b0b5118aea7c")
addappid(236134, 1, "2821c5bcdd044da85bff6de306f6db70c869927aad86196aaaebb15e441e3084")
addappid(236135, 1, "e2202998c262f7220848473861f6df98d20cd10db246989d92fd46a919bfea82")
addappid(236136, 1, "b4038ea2a11aea677a3400fbd15644fa909f5ba64a9ad2f9bb251c2788b7a0d6")

