-- Lua provided by RyzenAPI
-- Game: Memories: Millennium Girl

-- MAIN APPLICATION
addappid(2263980)
-- Game: addappid(2263980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263981, 1, "c4d29ea809993ba78f3e106af8bda5e11427133b1b5e47fd192610495e640808")
