-- Lua provided by RyzenAPI
-- Game: addappid(2163590)

-- MAIN APPLICATION
addappid(2163590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163591, 1, "7d9684eb46c8fa40062d8c484fc8b5e749bd541cf147e77d670a33e5ff38c4f3")
