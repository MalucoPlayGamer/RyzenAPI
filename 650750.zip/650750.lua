-- Lua provided by RyzenAPI
-- Game: HYPERNOVA: Escape from Hadea

-- MAIN APPLICATION
addappid(650750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(650751, 1, "e68abd80e64b7934b742633cfb44751f0cdccfc1d31ead2ecf435f2ee737b500")
