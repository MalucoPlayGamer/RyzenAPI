-- Lua provided by RyzenAPI
-- Game: HYPERNOVA: Escape from Hadea

-- MAIN APPLICATION
addappid(650750)
-- Game: addappid(650750)

-- MAIN APP DEPOTS / PACKAGES
addappid(650751, 1, "e68abd80e64b7934b742633cfb44751f0cdccfc1d31ead2ecf435f2ee737b500")
