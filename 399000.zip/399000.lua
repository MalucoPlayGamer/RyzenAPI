-- Lua provided by RyzenAPI
-- Game: Porradaria Upgrade

-- MAIN APPLICATION
addappid(399000)
-- Game: addappid(399000)

-- MAIN APP DEPOTS / PACKAGES
addappid(399001, 1, "4474c077ff51cf98cdcb24f01f20a20ff2951a9a5bdf964d3caf6532d58d6572")
addappid(399002, 1, "aa773ea96ef47ac7a64f84292d31993180d7dbe55145560e86554411ec924adf")
