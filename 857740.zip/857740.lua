-- Lua provided by RyzenAPI
-- Game: Ludicrous Speed

-- MAIN APPLICATION
addappid(857740)
-- Game: addappid(857740)

-- MAIN APP DEPOTS / PACKAGES
addappid(857741, 1, "f8cda1b017b8d33988e59fcc0b6593587383dc16c8a1787899119cc727ca1c11")
