-- Lua provided by RyzenAPI
-- Game: addappid(2290320)

-- MAIN APPLICATION
addappid(2290320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290321, 1, "9a562b4d4dcbd0945befb0453638ede9038ec36eb0dea1e413aa9bdaeb2f1134")
