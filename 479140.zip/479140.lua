-- Lua provided by RyzenAPI
-- Game: Framed Wings

-- MAIN APPLICATION
addappid(479140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(479141, 1, "009dd398f27f4bbaa2ffcc9b989bac1a44b0b85d6f19aa60a10e54301092b09a")

