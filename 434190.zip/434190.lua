-- Lua provided by RyzenAPI 
-- Game: AppID 434190
addappid(434190)
addappid(434191, 1, "232f77c3581b357426750c7964a0390eadf4b8b57a9af33784da788674fa2ce1")
addappid(765930, 0, "dbe9c0fe673236663e08c18017b81d8bb26d0ba4b78f736759be642a00e7d8e1")
