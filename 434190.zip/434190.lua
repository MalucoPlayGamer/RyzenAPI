-- Lua provided by RyzenAPI
-- Game: AppID 434190

-- MAIN APPLICATION
addappid(434190)

-- MAIN APP DEPOTS / PACKAGES
addappid(434191, 1, "232f77c3581b357426750c7964a0390eadf4b8b57a9af33784da788674fa2ce1")
addappid(765930, 0, "dbe9c0fe673236663e08c18017b81d8bb26d0ba4b78f736759be642a00e7d8e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
