-- Lua provided by RyzenAPI
-- Game: addappid(2754230)

-- MAIN APPLICATION
addappid(2754230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2754231, 1, "9e8d898ba39ef51ae604497b2a432d2b58220fecbe78cafe0f35118d0441c6e6")
