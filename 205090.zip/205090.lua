-- Lua provided by RyzenAPI
-- Game: BIT.TRIP FLUX

-- MAIN APPLICATION
addappid(205090)

-- MAIN APP DEPOTS / PACKAGES
addappid(205091, 1, "d5bcb5813d634c27b218d65e24e93e38106d1e02730b82f962bbcefb8c7dd3ef")
addappid(205092, 1, "198f5e5e895d31bb2b563fcbffced8d298662a9368a1c4206d995a626908c663")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(205093)
