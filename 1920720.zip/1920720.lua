-- Lua provided by RyzenAPI
-- Game: mtion worlds

-- MAIN APPLICATION
addappid(1920720)
-- Game: addappid(1920720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920721, 1, "805ed12587ae4ffe535e1d22d4937bd92a265fc27910cf1ed5f3cba04d33f66b")
