-- Lua provided by RyzenAPI
-- Game: Pro Eleven

-- MAIN APPLICATION
addappid(3818350)

