-- Lua provided by RyzenAPI
-- Game: 848160

-- MAIN APPLICATION
addappid(848160)
-- Game: addappid(848160)

-- MAIN APP DEPOTS / PACKAGES
addappid(848161, 1, "7748ee032b7a055d6bfc205c91975eb7a00dc3976cda072dcc400335a74d1c4f")
