-- Lua provided by RyzenAPI
-- Game: 973040

-- MAIN APPLICATION
addappid(973040)
-- Game: addappid(973040)

-- MAIN APP DEPOTS / PACKAGES
addappid(973041, 1, "f79b48e63d90f7ee46a36060a0d00e26e4e3a6e43709b35c233a14f7998ae902")
