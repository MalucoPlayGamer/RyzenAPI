-- Lua provided by RyzenAPI 
-- Game: AppID 973040
addappid(973040)
addappid(973041, 1, "f79b48e63d90f7ee46a36060a0d00e26e4e3a6e43709b35c233a14f7998ae902")
