-- Lua provided by RyzenAPI
-- Game: Myths of the World: Black Rose Collector's Edition

-- MAIN APPLICATION
addappid(995920)

-- MAIN APP DEPOTS / PACKAGES
addappid(995921, 1, "a5de28186d2c6b713afe7f6eaae7a1cb4a8adf8b9fc461f17da0071159a68870")

