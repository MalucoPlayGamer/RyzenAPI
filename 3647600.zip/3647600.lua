-- Lua provided by RyzenAPI
-- Game: Midnight Riff

-- MAIN APPLICATION
addappid(3647600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3647601, 1, "2150da94449b3cbed3e44b506fc91bd0ad818b1c243640c7f1e1e78b1d28106f")
