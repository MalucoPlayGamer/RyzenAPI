-- Lua provided by SkyAPI 
-- Game: Shift'n Slay
addappid(2698460)
addappid(2698461, 1, "d9a459198aff46157b674749a94c4dfaa97b0974058a6d9b6111847a7aab93ab")
