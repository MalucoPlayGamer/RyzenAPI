-- Lua provided by RyzenAPI
-- Game: Shift'n Slay

-- MAIN APPLICATION
addappid(2698460)
-- Game: addappid(2698460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698461, 1, "d9a459198aff46157b674749a94c4dfaa97b0974058a6d9b6111847a7aab93ab")
