-- Lua provided by RyzenAPI
-- Game: 1934570

-- MAIN APPLICATION
addappid(1934570)
-- Game: addappid(1934570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934571, 1, "8339de2d0121af2b4b3a7ec0b461091ae5a3dcfb4f531c1d45aa3640a8715d17")
