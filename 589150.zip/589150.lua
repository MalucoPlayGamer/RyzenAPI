-- Lua provided by RyzenAPI
-- Game: Viking Rage

-- MAIN APPLICATION
addappid(589150)

-- MAIN APP DEPOTS / PACKAGES
addappid(589151, 1, "5ef30364e563dc5f58927ee690b42231aa19a1313e6ae40fabd6ea4f2729b1ea")

