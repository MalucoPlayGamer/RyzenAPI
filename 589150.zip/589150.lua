-- Lua provided by SkyAPI 
-- Game: Viking Rage
addappid(589150)
addappid(589151, 1, "5ef30364e563dc5f58927ee690b42231aa19a1313e6ae40fabd6ea4f2729b1ea")
