-- Lua provided by RyzenAPI
-- Game: Breeding City Welcomes you

-- MAIN APPLICATION
addappid(3609640)
-- Game: addappid(3609640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3609641, 1, "1b848cd1267d598f9dd98f5fc664fe99b21210c50b5e42906d435a08c0c4ce5a")
addappid(3609642, 1, "9d8afb2d4400ca0e3f69fc3147d678edad2e18454508f5df7bd0554382e8df42")
addappid(3609643, 1, "ec10a1c56b3a6d76a27d48bef615ab4afb88781aa2d4dc513c542b94d73637e7")
addappid(3609644, 1, "d967c27566147342f179d037cf0064d45e7c61eb170b97507500b46fb27ec22b")
