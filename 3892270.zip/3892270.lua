-- Lua provided by RyzenAPI
-- Game: Gamble With Your Friends

-- MAIN APPLICATION
addappid(3892270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3892271, 1, "90695be6010d5ec2e8890f1d742357316f4d5f74a8a9d22b2ae076b184797167")

