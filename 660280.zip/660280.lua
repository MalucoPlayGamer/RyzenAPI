-- Lua provided by RyzenAPI
-- Game: 660280

-- MAIN APPLICATION
addappid(660280)
-- Game: addappid(660280)

-- MAIN APP DEPOTS / PACKAGES
addappid(660281, 1, "cb6dbcd1bc8bec301fb552ac1b82db9137d35dba2144e9b1c7935d9626613e73")
