-- Lua provided by RyzenAPI
-- Game: Lust Epidemic 18+

-- MAIN APPLICATION
addappid(3172860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172861, 1, "623f99b45d8afab9c117ac6ec68ad5adafe7e1199fbc8da49c0ef666b474ce5a")
addappid(3172862, 1, "cda3bc086bb5fcf7beb1d8aa717400f5350024369dc3f61cf8d6e762aa42168e")
addappid(3172863, 1, "859b68896c9302d305e0687373e31d62600ab0fe8ad5bbd5ddad08168033472e")
