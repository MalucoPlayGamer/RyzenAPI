-- Lua provided by RyzenAPI
-- Game: AppID 854300

-- MAIN APPLICATION
addappid(854300)
-- Game: addappid(854300)

-- MAIN APP DEPOTS / PACKAGES
addappid(854301, 1, "b4293ecfea086fffefb91f24a2b14af24933aeb0b9519f79e09cb0aabfcf46d3")
