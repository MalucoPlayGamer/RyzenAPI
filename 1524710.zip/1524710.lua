-- Lua provided by RyzenAPI 
-- Game: Dark Flowers
addappid(1524710)
addappid(1524711, 1, "450f349744ab699882b1aa8bee791b95ee9f35a2e409ec8d8422d3be1a680002")
