-- Lua provided by RyzenAPI
-- Game: Crazy Hill Racing

-- MAIN APPLICATION
addappid(2272280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272281, 1, "a27c47abb8613959087f71715584715ddf58d75cb0a0e902b79eda7b83d44368")

