-- Lua provided by RyzenAPI
-- Game: Fiends of Imprisonment

-- MAIN APPLICATION
addappid(410590)

-- MAIN APP DEPOTS / PACKAGES
addappid(410591, 1, "a03f5de927547d4af8d04fc4c14f1115a88378d5b26d8b3185c165632eeeb50d")
