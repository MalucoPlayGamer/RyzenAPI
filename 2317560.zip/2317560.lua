-- Lua provided by RyzenAPI
-- Game: The War

-- MAIN APPLICATION
addappid(2317560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2317561, 1, "cfd14412d8f11449c131a4bee61bc3998a23d017ae29962f51dc7d0f4f72c619")

