-- Lua provided by SkyAPI 
-- Game: 3 Days War
addappid(2317560)
addappid(2317561, 1, "cfd14412d8f11449c131a4bee61bc3998a23d017ae29962f51dc7d0f4f72c619")
