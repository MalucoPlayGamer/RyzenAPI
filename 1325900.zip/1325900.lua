-- Lua provided by RyzenAPI
-- Game: Demon Turf

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1325900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325902,0,"eaef2a2a39f892218cb4076b4b1b5a56f75aba53e7f678fa4a8c691e7668da49")

