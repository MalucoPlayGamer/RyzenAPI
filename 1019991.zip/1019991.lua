-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Ling Tong "Samurai Costume" / 凌統「武者風コスチューム」

-- MAIN APPLICATION
addappid(1019991)
-- Game: addappid(1019991)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019991,0,"20fa9d8f177f83d027719b6dd208490b36ec4c64ee8704981a3fa4b04022a438")
