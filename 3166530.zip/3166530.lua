-- Lua provided by RyzenAPI 
-- Game: Five Hearts Under One Roof Demo
addappid(3166530)
addappid(3166531, 1, "0de4ec1079245ed65e870b177ac596f63573424e24f7b060a7e985b837f2adaa")
