-- Lua provided by SkyAPI 
-- Game: A traveler's photo album
addappid(1480340)
addappid(1480341, 1, "030bd6e5851a0781fa4d2368732ddfb69b91c24e7f9489211b23b38061050487")
addappid(1494130, 0, "55ff62cadd22a212c2bc24fcb0e9c00b1867721a6242f01d696500ffcc0a8bd5")
