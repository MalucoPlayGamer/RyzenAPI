-- Lua provided by RyzenAPI 
-- Game: 迷失岛2：时间的灰烬 电子书
addappid(909390)
addappid(909391, 1, "6aa484e56df0ac4b1f0558566c51dc0a5ccad3a6b79107d608ec6f752d5d7dc0")
