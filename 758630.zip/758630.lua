-- Lua provided by RyzenAPI
-- Game: Cadenza: The Kiss of Death Collector's Edition

-- MAIN APPLICATION
addappid(758630)

-- MAIN APP DEPOTS / PACKAGES
addappid(758631,0,"e44846b7a25885fb0f2a01d09b89878cd9aadbee840e10f745b88f2b328dc796")

