-- Lua provided by RyzenAPI
-- Game: Chernobylite - The Art of Chernobylite

-- MAIN APPLICATION
addappid(1701200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701200,0,"fa86adca169023889b58ef61c505090a61a8da3443ddf019b9f69ef260f8164a")

