-- Lua provided by RyzenAPI
-- Game: Island Tribe

-- MAIN APPLICATION
addappid(411550)

-- MAIN APP DEPOTS / PACKAGES
addappid(411551, 1, "f346d17381029b4a47e19f31da96b032971f46a66647fab1986de49f1f60bd6a")

