-- Lua provided by RyzenAPI
-- Game: Jungle Chains

-- MAIN APPLICATION
addappid(3097570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097571, 1, "900852e193c445cd5c008eec7041abac89773dca0be86b746b83cdc1c2b5b98e")
