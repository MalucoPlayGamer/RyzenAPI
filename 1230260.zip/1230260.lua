-- Lua provided by RyzenAPI
-- Game: ULTRAKILL Demo

-- MAIN APPLICATION
addappid(1230260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230261, 1, "d4c026d9c7ebbadcb45162beed0504ff6eb2ab8f8fbe372fd93bc1f8c76d0b14")
