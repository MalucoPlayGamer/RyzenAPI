-- Lua provided by RyzenAPI
-- Game: FLASHOUT 3

-- MAIN APPLICATION
addappid(1761870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761871, 1, "7196de9858bfacb607eae48929af8f60921f7327d4039b64d48d870d929767b5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2175730)
