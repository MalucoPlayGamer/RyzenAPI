-- Lua provided by RyzenAPI
-- Game: Cronie the Assassin's Mission ~ The Teddy Bear Payment

-- MAIN APPLICATION
addappid(2574800)
-- Game: addappid(2574800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574803,0,"ad25137f2ea0832458ea8306d89693cd1f9539f8a5ef8b4a9b3658f462b7d780")
addappid(2574804,0,"ca388afaefe73368afcd0e30ac0bd6522179e7df9d2732180ff197a16a98638a")
