-- Lua provided by RyzenAPI
-- Game: AppID 1065550

-- MAIN APPLICATION
addappid(1065550)
addappid(1183610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1065551, 1, "23042872dfc2bbf105cf82d5f1db8b4e57bd840afdee91f254a96bf62100e4e9")

