-- Lua provided by RyzenAPI 
-- Game: AppID 1065550
addappid(1065550)
addappid(1065551, 1, "23042872dfc2bbf105cf82d5f1db8b4e57bd840afdee91f254a96bf62100e4e9")
