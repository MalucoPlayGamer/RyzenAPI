-- Lua provided by RyzenAPI
-- Game: Hubris

-- MAIN APPLICATION
addappid(1265800)
-- Game: addappid(1265800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265801, 1, "8d47f600639a6863c70cdcf9460c71a40fe07fa56837c886f6d7ccba18520a3b")
