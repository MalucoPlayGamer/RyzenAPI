-- Lua provided by SkyAPI 
-- Game: Hubris
addappid(1265800)
addappid(1265801, 1, "8d47f600639a6863c70cdcf9460c71a40fe07fa56837c886f6d7ccba18520a3b")
