-- Lua provided by RyzenAPI
-- Game: Glasses and Girls

-- MAIN APPLICATION
addappid(1437940)
addappid(1455600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437941, 1, "133cfdb91026089f591bf805a1629981f86b0a10cff985e98f39e6daa198bdab")

