-- Lua provided by RyzenAPI
-- Game: addappid(992050)

-- MAIN APPLICATION
addappid(992050)

-- MAIN APP DEPOTS / PACKAGES
addappid(992051, 1, "4a25d1d176144be895bac16cc04b5d33cea92c2e0cdee0704a8575fafc709a47")
addappid(1037300, 0, "7eb0fed0e493ab9c8b02e7d82129807acc301058517dd82bf310fb69390bd958")
