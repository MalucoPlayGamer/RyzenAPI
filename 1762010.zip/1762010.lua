-- Lua provided by RyzenAPI
-- Game: Wrought Flesh

-- MAIN APPLICATION
addappid(1762010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762015,0,"40216f1d08f8dcd9d8e87c43a2c3c6a95fae2b57127c9e70ca4a3ef33b647c7a")

