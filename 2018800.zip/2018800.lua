-- Lua provided by RyzenAPI
-- Game: Kamifuda Demo

-- MAIN APPLICATION
addappid(2018800)
-- Game: addappid(2018800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018801, 1, "0385a975692ccc1208ca93b07d83964faee73fc3a80a59157a84637f345581b9")
