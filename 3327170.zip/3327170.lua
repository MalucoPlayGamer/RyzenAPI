-- Lua provided by RyzenAPI
-- Game: Minutescape

-- MAIN APPLICATION
addappid(3327170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3327171, 1, "37f2bc208430b8b412c6c06fa954bb5f891fa0ac9922cd5072d5ae091d478490")
