-- Lua provided by RyzenAPI
-- Game: addappid(2492360)

-- MAIN APPLICATION
addappid(2492360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2492361, 1, "31dca5119d0e290e74d78ca7fa5fae8540d3ba34cdc8979c9ddb4c8ccc5cf795")
