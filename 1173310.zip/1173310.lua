-- Lua provided by SkyAPI 
-- Game: AppID 1173310
addappid(1173310)
addappid(1173311, 1, "e05233914eef8549d99241ae768b07fa8117720164e6ae10e6fd5a014b197346")
