-- Lua provided by RyzenAPI
-- Game: Lab 7: Cold Nights

-- MAIN APPLICATION
addappid(1173310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173311, 1, "e05233914eef8549d99241ae768b07fa8117720164e6ae10e6fd5a014b197346")
