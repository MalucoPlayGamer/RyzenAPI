-- Lua provided by SkyAPI 
-- Game: Internet Cafe Simulator 2
addappid(1563180)
addappid(1563181, 1, "deb015c5f355a865f557ef2511c27ed07fed2214540bad2c41e5567e65cd2c62")
