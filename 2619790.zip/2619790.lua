-- Lua provided by RyzenAPI
-- Game: DUNGEON: Cradle of hell

-- MAIN APPLICATION
addappid(2619790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619791, 1, "7149a309addda2ab7733e8bf46f976ebf6dadfc6114edb3e7e5ce05c96555891")
