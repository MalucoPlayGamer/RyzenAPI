-- Lua provided by RyzenAPI
-- Game: AppID 2204350

-- MAIN APPLICATION
addappid(2204350)
-- Game: addappid(2204350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204351, 1, "1d29ac89d3e1d6782bf35c3f1cdaebf821754f40065449f7c11eb86b1b5c7fe9")
