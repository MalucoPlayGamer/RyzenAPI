-- Lua provided by RyzenAPI
-- Game: AppID 2204350

-- MAIN APPLICATION
addappid(2204350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204351, 1, "1d29ac89d3e1d6782bf35c3f1cdaebf821754f40065449f7c11eb86b1b5c7fe9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
