-- Lua provided by SkyAPI 
-- Game: AppID 2204350
addappid(2204350)
addappid(2204351, 1, "1d29ac89d3e1d6782bf35c3f1cdaebf821754f40065449f7c11eb86b1b5c7fe9")
