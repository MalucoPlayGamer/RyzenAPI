-- Lua provided by RyzenAPI
-- Game: 610360

-- MAIN APPLICATION
addappid(610360)
-- Game: addappid(610360)

-- MAIN APP DEPOTS / PACKAGES
addappid(610361, 1, "14f0bf0a833e6734ed5df264d88869986ecb520ec2b1b5024b473b6ce0f98c9e")
addappid(631320, 0, "4d7830b3fb5ed40db35b300fab6e6db3e63437ba7f690018994eb0aade450e81")
