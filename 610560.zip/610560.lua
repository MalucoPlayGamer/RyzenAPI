-- Lua provided by RyzenAPI
-- Game: Tales of the Lumminai

-- MAIN APPLICATION
addappid(610560)

-- MAIN APP DEPOTS / PACKAGES
addappid(610561, 1, "57172788d56c3b0faf7764526ef6aee94f735edea295c69562b91d1af54b6c83")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
