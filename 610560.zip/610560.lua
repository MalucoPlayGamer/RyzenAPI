-- Lua provided by RyzenAPI
-- Game: Tales of the Lumminai

-- MAIN APPLICATION
addappid(610560)
-- Game: addappid(610560)

-- MAIN APP DEPOTS / PACKAGES
addappid(610561, 1, "57172788d56c3b0faf7764526ef6aee94f735edea295c69562b91d1af54b6c83")
