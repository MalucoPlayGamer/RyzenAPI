-- Lua provided by RyzenAPI
-- Game: Game: AppID 2474040

-- MAIN APPLICATION
addappid(2474040)
-- Game: addappid(2474040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474041, 1, "9c7b544cf8b877a0c51a9832edea8fb6dc0e8ccd1f1631eaa44bd9e8de02b41b")
