-- Lua provided by RyzenAPI
-- Game: Protect the campus

-- MAIN APPLICATION
addappid(1148890)
-- Game: addappid(1148890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148891, 1, "b3e191c4bd512a65784585edafb19422c134f0175e2425259acf4fcc97028221")
