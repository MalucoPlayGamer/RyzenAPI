-- Lua provided by RyzenAPI
-- Game: Cold Iron

-- MAIN APPLICATION
addappid(543440)

-- MAIN APP DEPOTS / PACKAGES
addappid(543441,0,"3e9489af2e4d477046388b50f850bb83a453e25ff952bbb3f744b74f52c79a14")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(772630)
