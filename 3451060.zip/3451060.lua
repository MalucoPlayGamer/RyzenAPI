-- Lua provided by RyzenAPI
-- Game: Game: Health Insurance Claim Denier

-- MAIN APPLICATION
addappid(3451060)
-- Game: addappid(3451060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3451061, 1, "0609a62e8a8c3591d3e877c7069c60da5db90dc72b2b804c36807502b7c19865")
