-- Lua provided by RyzenAPI
-- Game: Game: AppID 603030

-- MAIN APPLICATION
addappid(603030)
-- Game: addappid(603030)

-- MAIN APP DEPOTS / PACKAGES
addappid(603031, 1, "548f4cc3c21bb150f8a75d5c7553cfe48130b683153539e1acb27f428f562566")
