-- Lua provided by RyzenAPI
-- Game: AppID 329110

-- MAIN APPLICATION
addappid(329110)

-- MAIN APP DEPOTS / PACKAGES
addappid(329111, 1, "00ad10835c36c87d116ee78834db505059dd67dd9b463bead9e6694f1158d950")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(526300)
addappid(526301)
addappid(1067150)
addappid(1409800)
addappid(1409802)
addappid(1412350)
