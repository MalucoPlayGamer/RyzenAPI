-- Lua provided by RyzenAPI
-- Game: 329110

-- MAIN APPLICATION
addappid(329110)
-- Game: addappid(329110)

-- MAIN APP DEPOTS / PACKAGES
addappid(329111, 1, "00ad10835c36c87d116ee78834db505059dd67dd9b463bead9e6694f1158d950")
