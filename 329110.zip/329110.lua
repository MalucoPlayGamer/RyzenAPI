-- Lua provided by RyzenAPI 
-- Game: AppID 329110
addappid(329110)
addappid(329111, 1, "00ad10835c36c87d116ee78834db505059dd67dd9b463bead9e6694f1158d950")
