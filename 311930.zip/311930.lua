-- Lua provided by RyzenAPI
-- Game: addappid(311930)

-- MAIN APPLICATION
addappid(311930)

-- MAIN APP DEPOTS / PACKAGES
addappid(311931, 1, "c00636365d44a76c5eb6d5ce1301bd07546d88cf127c7f3b29821a967173b50e")
