-- Lua provided by RyzenAPI
-- Game: Vlad Voievod Dracula: Dungeons of Egrigoz

-- MAIN APPLICATION
addappid(2984080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984082,0,"a31fbf2c26b8062174648decff098e5865d613d9848071eb0ffe66151905115d")
addappid(2984083,0,"59b566de2de4148f0e6da5c8db9608af50575b597bcd224016bebfa0bd86ff6c")

