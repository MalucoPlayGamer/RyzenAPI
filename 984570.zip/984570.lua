-- Lua provided by RyzenAPI
-- Game: Game: AppID 984570

-- MAIN APPLICATION
addappid(984570)
-- Game: addappid(984570)

-- MAIN APP DEPOTS / PACKAGES
addappid(984571, 1, "d11be81311295467992d4dd044ec25d2fa3b37c3c5aac3bdef9d4ef610438468")
addappid(984572, 1, "1c18f72f17cc24fb429165cfdab0a95c321bb4f010e3baec6dd74012061992f3")
