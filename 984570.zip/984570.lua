-- Lua provided by RyzenAPI
-- Game: Chess Sphere

-- MAIN APPLICATION
addappid(984570)
addappid(1240900)

-- MAIN APP DEPOTS / PACKAGES
addappid(984571,0,"d11be81311295467992d4dd044ec25d2fa3b37c3c5aac3bdef9d4ef610438468")
addappid(984572,0,"1c18f72f17cc24fb429165cfdab0a95c321bb4f010e3baec6dd74012061992f3")

