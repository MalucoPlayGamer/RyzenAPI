-- Lua provided by RyzenAPI
-- Game: 2129720

-- MAIN APPLICATION
addappid(2129720)
-- Game: addappid(2129720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129722,0,"b633eab1b9f5bba7725a202c3a484aa9922c2053ddcbb40f344c515b8032d1e2")
