-- Lua provided by RyzenAPI
-- Game: AppID 300080

-- MAIN APPLICATION
addappid(300080)

-- MAIN APP DEPOTS / PACKAGES
addappid(300081, 1, "8325b40d0df5efd8068a051011aaa9b23873e56279af4599c138f4f785f126b7")
addappid(372531, 0, "85fd9e7e0a0f07b17dcb14263b94e436306270f02200d7a6669de0ba70602504")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(480720)
addappid(480721)
addappid(480722)
