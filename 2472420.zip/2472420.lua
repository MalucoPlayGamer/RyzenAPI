-- Lua provided by RyzenAPI
-- Game: 天台物语 Demo

-- MAIN APPLICATION
addappid(2472420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472421, 1, "4cf97451e5240eceadf97842f4ae9fed9ab3438a975a0a17950b2ae2a42006c7")
