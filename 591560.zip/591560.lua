-- Lua provided by SkyAPI 
-- Game: AppID 591560
addappid(591560)
addappid(591561, 1, "2a401efa34543f4bbd3bd17129452eb5895438da68ab588f53e0a94fd80e4738")
