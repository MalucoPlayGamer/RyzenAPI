-- Lua provided by SkyAPI 
-- Game: Drone Zone Playtest
addappid(2518050)
addappid(2518051, 1, "8a6f80f918702177d56caa2af29b3872c58bb4738495a13fe83a4ee760da2ab0")
