-- Lua provided by RyzenAPI
-- Game: Game: Drone Zone Playtest

-- MAIN APPLICATION
addappid(2518050)
-- Game: addappid(2518050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518051, 1, "8a6f80f918702177d56caa2af29b3872c58bb4738495a13fe83a4ee760da2ab0")
