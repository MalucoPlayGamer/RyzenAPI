-- Lua provided by RyzenAPI
-- Game: Wild Warfare

-- MAIN APPLICATION
addappid(312150)
addappid(315120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(312151, 1, "22b9c874ef54a8839ffa8fb1a8f921673781c44a1b64eb855ddb6a0a3c1a0024")
addappid(312152, 1, "0a266b44c6db83b8718a640b8e6d029e1baedf89fbfa4467c3f731f1caa63330")

