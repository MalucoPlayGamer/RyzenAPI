-- Lua provided by RyzenAPI
-- Game: 1859990

-- MAIN APPLICATION
addappid(1859990)
-- Game: addappid(1859990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859991, 1, "60f6e608ad26e3f768d0fa60f9f9848938af9e2bc4937e3081a55118cad39961")
