-- Lua provided by RyzenAPI
-- Game: Out of Orbit

-- MAIN APPLICATION
addappid(1859990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1859991, 1, "60f6e608ad26e3f768d0fa60f9f9848938af9e2bc4937e3081a55118cad39961")

