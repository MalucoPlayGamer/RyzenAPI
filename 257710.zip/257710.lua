-- Lua provided by RyzenAPI
-- Game: Max Gentlemen

-- MAIN APPLICATION
addappid(257710)
addappid(261220)
addappid(300150)

-- MAIN APP DEPOTS / PACKAGES
addappid(257711, 1, "6ff03e863127c962edb78efd03080b5d5bd1a90ee674417c5c12eb423f62be6c")
addappid(257712, 1, "2e5584354d3162e4756fa455154a2ccde65792aa13a4d910bb022c11f28ad4a6")
addappid(257713, 1, "8485678fc67bf27141ccbad7855d7ef8e78336a63dcdf0a23c9fa31ee00f64cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(376550)
