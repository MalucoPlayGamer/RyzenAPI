-- Lua provided by RyzenAPI
-- Game: Monster Portal

-- MAIN APPLICATION
addappid(1419140)
-- Game: addappid(1419140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419143,0,"03e694397242fc65d700c76607b344e34e18c41095c4c7372fb921ee2069a277")
