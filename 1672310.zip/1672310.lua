-- Lua provided by RyzenAPI
-- Game: Decarnation

-- MAIN APPLICATION
addappid(1672310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672311, 1, "49275f0712ae729f454c40272bc98f1be17183b013cd1f996d292c4c9027e4cb")
