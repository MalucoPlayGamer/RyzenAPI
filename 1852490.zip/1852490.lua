-- Lua provided by RyzenAPI
-- Game: The Vortex

-- MAIN APPLICATION
addappid(1852490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1852491, 1, "02291f11a38b64d8aea56167eb44cb91fa53653ce5ad0bc83a737c87e7bd4474")

