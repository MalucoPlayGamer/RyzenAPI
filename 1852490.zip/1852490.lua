-- Lua provided by RyzenAPI 
-- Game: The Vortex
addappid(1852490)
addappid(1852491, 1, "02291f11a38b64d8aea56167eb44cb91fa53653ce5ad0bc83a737c87e7bd4474")
