-- Lua provided by RyzenAPI 
-- Game: AppID 402530
addappid(402530)
addappid(402531, 1, "edc5c43309e039866fd81a685ecf237c0457139333e2867b54a0031d90e57b6e")
addappid(455740, 0, "86b3651cb1693b32a45f0baf7eabbf2bb2d9751c3818bc0a86c0c0f848369f08")
