-- Lua provided by RyzenAPI
-- Game: UNRESTRAINED

-- MAIN APPLICATION
addappid(2248340)
-- Game: addappid(2248340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248341, 1, "3339233aa6a2a4eef1edf0fca74b77795387e3e54e98e1485c2ee55cae7a7a25")
