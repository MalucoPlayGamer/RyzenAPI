-- Lua provided by RyzenAPI
-- Game: Game: AppID 1861620

-- MAIN APPLICATION
addappid(1861620)
-- Game: addappid(1861620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861621, 1, "7c0fffd9af815ae85ff917f1351732f0510afb120db16fc9e7f21b564fa4b91c")
