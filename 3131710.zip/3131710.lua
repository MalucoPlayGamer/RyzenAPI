-- Lua provided by RyzenAPI
-- Game: addappid(3131710)

-- MAIN APPLICATION
addappid(3131710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3131711, 1, "7d1f64fdf8e65b6c4c39292cbfbd589e886d6f7df57ea03db364ec1500bc8811")
