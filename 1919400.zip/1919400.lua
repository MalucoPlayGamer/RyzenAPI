-- Lua provided by RyzenAPI
-- Game: addappid(1919400)

-- MAIN APPLICATION
addappid(1919400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919401, 1, "ebab48fc53bbf371f92960fb31b32f6de75b134ba1b4b6bf88eeb7d5a58d63f2")
