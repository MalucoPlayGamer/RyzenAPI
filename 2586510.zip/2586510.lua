-- Lua provided by RyzenAPI
-- Game: Bang Average Football Demo

-- MAIN APPLICATION
addappid(2586510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586513,0,"9f992b7718a22f37cda589f3b15264a6ddad0cebfc0917433440f04b9cb115cb")

