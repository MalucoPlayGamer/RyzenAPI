-- Lua provided by RyzenAPI
-- Game: Tales of Farhollow

-- MAIN APPLICATION
addappid(1524150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524151, 1, "21aacd5a7ed9d3a3cc77e13e63a2c555d5c2cec33a99604068f62be5b20365a6")

