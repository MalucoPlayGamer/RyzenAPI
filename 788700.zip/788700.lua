-- Lua provided by RyzenAPI
-- Game: ValeGuard

-- MAIN APPLICATION
addappid(788700)
addappid(860720)

-- MAIN APP DEPOTS / PACKAGES
addappid(788701, 1, "34a25c612d40e97b9c117274f77f4791ddce2ea2a13626defc3c006f3d1b09f3")

