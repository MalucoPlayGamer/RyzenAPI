-- Lua provided by RyzenAPI
-- Game: addappid(2121210)

-- MAIN APPLICATION
addappid(2121210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2121211, 1, "42d1a1cc2b5474745f7d14c6710762a65b6fe3ef1d17a9d0a54dd12bc2e42e90")
