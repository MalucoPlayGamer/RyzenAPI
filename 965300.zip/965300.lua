-- Lua provided by RyzenAPI
-- Game: addappid(965300)

-- MAIN APPLICATION
addappid(965300)

-- MAIN APP DEPOTS / PACKAGES
addappid(965301, 1, "9dbdf6f72aab69f95f3020da9cba6740f872f82f89452228233618940a0956e7")
