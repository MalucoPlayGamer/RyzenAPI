-- Lua provided by RyzenAPI
-- Game: The Settlers : Heritage of Kings - History Edition

-- MAIN APPLICATION
addappid(965300)
addappid(1001410)

-- MAIN APP DEPOTS / PACKAGES
addappid(965301,0,"9dbdf6f72aab69f95f3020da9cba6740f872f82f89452228233618940a0956e7")

