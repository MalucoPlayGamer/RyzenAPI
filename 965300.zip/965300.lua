-- Lua provided by RyzenAPI
-- Game: The Settlers : Heritage of Kings - History Edition

-- MAIN APPLICATION
addappid(965300)
addappid(1001410)

-- MAIN APP DEPOTS / PACKAGES
addappid(965301,0,"9dbdf6f72aab69f95f3020da9cba6740f872f82f89452228233618940a0956e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
