-- Lua provided by RyzenAPI
-- Game: addappid(1070058)

-- MAIN APPLICATION
addappid(1070058)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070058,0,"22ea684c252eeb036ac0d7244a8541ad2b67c9e6b09a98715e0b61ab1bad714c")
