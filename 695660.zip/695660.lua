-- Lua provided by RyzenAPI
-- Game: Saloon Showdown VR

-- MAIN APPLICATION
addappid(695660)

-- MAIN APP DEPOTS / PACKAGES
addappid(695661, 1, "b1fa35605b872f20a9794f2d3a66993f506cc2fe68f610efa91b0252be14696a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
