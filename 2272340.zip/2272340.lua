-- Lua provided by RyzenAPI
-- Game: Horticular Demo

-- MAIN APPLICATION
addappid(2272340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272341, 1, "3f79a553debd9333ea1a8a2c39452adead570f3693f6ec6c176885ea6daaadca")
