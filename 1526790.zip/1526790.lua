-- Lua provided by RyzenAPI
-- Game: Soldier in the darkness

-- MAIN APPLICATION
addappid(1526790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1526791, 1, "070b01170964350e5744b356f67dbc1de7de62a8f36836aae5c4acd8f4aadd81")

