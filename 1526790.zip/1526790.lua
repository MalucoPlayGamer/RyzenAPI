-- Lua provided by RyzenAPI
-- Game: Game: Soldier in the darkness

-- MAIN APPLICATION
addappid(1526790)
-- Game: addappid(1526790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526791, 1, "070b01170964350e5744b356f67dbc1de7de62a8f36836aae5c4acd8f4aadd81")
