-- Lua provided by RyzenAPI
-- Game: Bone Dust

-- MAIN APPLICATION
addappid(2247640)
-- Game: addappid(2247640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247642,0,"0594fc99ad96a303d319f05803a6ac7f3914a70029c7720864673cdc0b988aa1")
