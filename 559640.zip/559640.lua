-- Lua provided by RyzenAPI
-- Game: Betrayal Collection

-- MAIN APPLICATION
addappid(559640)

-- MAIN APP DEPOTS / PACKAGES
addappid(559641,0,"8243a07f8165646a179b14116db7948fb16c00fbe5d1d5947e4254f6a6f55542")

