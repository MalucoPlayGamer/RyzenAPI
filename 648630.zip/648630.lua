-- Lua provided by RyzenAPI
-- Game: Damascus Gear Operation Tokyo HD

-- MAIN APPLICATION
addappid(648630)

-- MAIN APP DEPOTS / PACKAGES
addappid(648631, 1, "b6a558d640b935072cc20594c1fbe471ea36f589a3d1fdbfd2e31b3569b6b891")

