-- Lua provided by RyzenAPI
-- Game: addappid(696360)

-- MAIN APPLICATION
addappid(696360)

-- MAIN APP DEPOTS / PACKAGES
addappid(696361, 1, "a42cd1b7a78090437eac86d15679a54552b1e94ce1d63c37ea8b7cd26abbbb4e")
