-- Lua provided by RyzenAPI
-- Game: Chinese Paladin：Sword and Fairy 6

-- MAIN APPLICATION
addappid(696360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(696361, 1, "a42cd1b7a78090437eac86d15679a54552b1e94ce1d63c37ea8b7cd26abbbb4e")

