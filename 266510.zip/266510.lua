-- Lua provided by RyzenAPI
-- Game: AppID 266510

-- MAIN APPLICATION
addappid(266510)

-- MAIN APP DEPOTS / PACKAGES
addappid(266511, 1, "d96fddad3a96581f9565048fffa4c9c736808b3ff3eaf138442010656716fa71")
addappid(266512, 1, "f069d71777e1c3d4e1e405029c8c59abd278ee8fcd1a11892ea2677d85b2ee73")
addappid(266513, 1, "5b0d5965087479fd1bd6e1a56a6edfd2631b9df5c20bf33385f43a8d8638f385")
addappid(351430, 0, "14c5d50c4d139bc65a7314115ca98e7f5bdf8367dbf01632519c36e662e58d51")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(350460)
