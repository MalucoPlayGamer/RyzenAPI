-- Lua provided by RyzenAPI
-- Game: addappid(2953480)

-- MAIN APPLICATION
addappid(2953480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2953481, 1, "2a966395acc7d2cc1c60362d668bae6e0b283d86ba2251ae54a6ca3151d39c09")
