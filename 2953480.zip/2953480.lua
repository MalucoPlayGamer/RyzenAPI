-- Lua provided by RyzenAPI
-- Game: Lunar Eclipse

-- MAIN APPLICATION
addappid(2953480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2953481, 1, "2a966395acc7d2cc1c60362d668bae6e0b283d86ba2251ae54a6ca3151d39c09")

