-- Lua provided by RyzenAPI
-- Game: Three Pigeons in a Trench Coat

-- MAIN APPLICATION
addappid(1740710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740711, 1, "512c41e3ae21755c7ca29eb62fd9d65824e019f8f11e25200207b97f4f8fc64b")
addappid(1740712, 1, "b5f37acceb6db53cb7d9e435b350b695058348521bc74da421c3d1f8dd3bbc7b")

