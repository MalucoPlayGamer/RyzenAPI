-- Lua provided by RyzenAPI 
-- Game: AppID 1193340
addappid(1193340)
addappid(1193341, 1, "102721171675aa074391f11007ab59dea0ab596ade6d7bf17bf8c6f7a416d712")
addappid(1193343, 1, "ddc2567feed8c2cde14fd8c1b24bf65d8224b269ab5b5574a3b516312b270892")
