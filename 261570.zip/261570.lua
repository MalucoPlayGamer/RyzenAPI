-- Lua provided by RyzenAPI 
-- Game: AppID 261570
addappid(261570)
addappid(261571, 1, "7eeb593b78d5eb4db1691cef6355d28cbf59ad13ca630577f75e87a2ce4c3ed3")
addappid(378950, 0, "0a39588e113af0b41a17420aefcf4739a63350c1b3fc58609b3879f1caec4ce7")
