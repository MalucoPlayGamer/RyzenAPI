-- Lua provided by RyzenAPI
-- Game: Poly Runner VR

-- MAIN APPLICATION
addappid(462910)

-- MAIN APP DEPOTS / PACKAGES
addappid(462911, 1, "85ef6bdc45587d4e5d6322334c59065cd376c5b4d55bc90209c8b56d740b6f87")

