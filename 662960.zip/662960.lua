-- Lua provided by RyzenAPI
-- Game: Mysteria ~Occult Shadows~

-- MAIN APPLICATION
addappid(662960)
addappid(1009670)
addappid(1143500)
addappid(1143530)
addappid(1364660)
addappid(1364661)
addappid(1364662)
addappid(1364663)
addappid(1364664)

-- MAIN APP DEPOTS / PACKAGES
addappid(662961, 1, "ef6df66e3d471c36efb71e8474a3f7c2e13a3f45ed86d04499bcd86c12c2058d")
addappid(1143510, 0, "4bdb3b244b0b1f369c966de792d59f07a5f9e5fdc2c4036cec9dbdaa9ef9ba4d")
addappid(1143520, 0, "94fc922c23ef2fbef751004804211598e384cc2a4c2c16a47952d4c949a76292")
addappid(1143660, 0, "2b5c2553043779ae5d95bef524e62a00299ce43d885bd14452a4e1f203b716cd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
