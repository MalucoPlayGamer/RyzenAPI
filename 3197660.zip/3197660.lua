-- Lua provided by RyzenAPI
-- Game: 3197660

-- MAIN APPLICATION
addappid(3197660)
-- Game: addappid(3197660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197661, 1, "c54b111d151efe8bff2143a8d54cdf8c36f8dc3a33bafab167d242bd14d0936e")
