-- Lua provided by RyzenAPI
-- Game: AppID 830380

-- MAIN APPLICATION
addappid(830380)
-- Game: addappid(830380)

-- MAIN APP DEPOTS / PACKAGES
addappid(830381, 1, "0ce7cdfdfee7716bd71131a62140a7d8a4135a30aa92516b53f6301430ce99c6")
