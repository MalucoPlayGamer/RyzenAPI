-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3670090)
-- Game: addappid(3670090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3670092,0,"b6f2a3af30655cada76cf1ef59356b8b0afb365fa08b464e75f2536652c09598")
