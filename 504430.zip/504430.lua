-- Lua provided by RyzenAPI
-- Game: addappid(504430)

-- MAIN APPLICATION
addappid(504430)

-- MAIN APP DEPOTS / PACKAGES
addappid(504431, 1, "17064d22aeecec1dd392732ccace3672b2cf90b3139f29d7a09ba154eb7e3e9d")
