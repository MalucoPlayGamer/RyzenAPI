-- Lua provided by RyzenAPI
-- Game: The Watchmaker

-- MAIN APPLICATION
addappid(504430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(504431, 1, "17064d22aeecec1dd392732ccace3672b2cf90b3139f29d7a09ba154eb7e3e9d")

