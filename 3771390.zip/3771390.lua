-- 3771390's Lua and Manifest Created by Hubcap Manifest
-- Carefully Stamped
-- Created: February 28, 2026 at 23:04:19 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3771390) -- Carefully Stamped
-- MAIN APP DEPOTS
addappid(3771391, 1, "539256fb23cb0adf340328c317939b22efeaf6180d13beb90a171e1ab176a108") -- Depot 3771391
setManifestid(3771391, "5058859173529932823", 1600366271)
addappid(3771392, 1, "5cd06a2d2afb9e2db651a8fdac50da3193135d67330e777675562a1846e24584") -- Depot 3771392
setManifestid(3771392, "8087292400907266551", 1616726175)
addappid(3771393, 1, "e1fb41f834b13cfc463bdf3b69fd02f04fc9973e5e210ce2858fe008997d7688") -- Depot 3771393
setManifestid(3771393, "362994000189720702", 1596371407)