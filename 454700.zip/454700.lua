-- Lua provided by RyzenAPI
-- Game: Shiny Gauntlet

-- MAIN APPLICATION
addappid(454700)

-- MAIN APP DEPOTS / PACKAGES
addappid(454701, 1, "c5fe0145a600a918ef62fc93c4b571de6f2fec979c4c75db9cb51132b42865af")
