-- Lua provided by RyzenAPI
-- Game: Warriors Of Titus - F2P

-- MAIN APPLICATION
addappid(1513740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513741, 1, "95066f62434335e852ed8dfdf7474ea75afb410244160507ce7ec45aaa0539a8")

