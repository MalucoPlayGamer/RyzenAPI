-- Lua provided by RyzenAPI
-- Game: Game: 100 Asian Cats

-- MAIN APPLICATION
addappid(2667970)
-- Game: addappid(2667970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667971, 1, "276ab4d34075feaf3a3b0b4dfaf09d515becf9c41dc03b38e52177bbd7d9f459")
