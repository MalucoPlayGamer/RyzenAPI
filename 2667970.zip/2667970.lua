-- Lua provided by RyzenAPI
-- Game: 100 Asian Cats

-- MAIN APPLICATION
addappid(2667970)
addappid(2733930)
addappid(2733940)
addappid(2733950)
addappid(2733960)
addappid(2733970)
addappid(2733980)
addappid(2733990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667971, 1, "276ab4d34075feaf3a3b0b4dfaf09d515becf9c41dc03b38e52177bbd7d9f459")
