-- Lua provided by SkyAPI 
-- Game: Forgotten Realms: The Archives - Collection One
addappid(1882240)
addappid(1882241, 1, "50f963b85201ca78c5fa18e005ccc19666e85a5c2cf9e062e13c43bb724081b7")
addappid(1882260, 1, "bab39ea9f11532680f42bcceb28cc5d81a5840ccd714b3147f3bbf444c99074e")
addappid(1882261, 0, "54f84392be696c0c2ebe9e6b2b769be6790d4b50610cf71259a421422cf6ce62")
addappid(1882262, 0, "b791fd71d18d6e661c317d9aeebf15ce3f684411725499d069b3f55b0142b8a9")
