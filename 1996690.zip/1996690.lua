-- Lua provided by RyzenAPI
-- Game: Fowl Scourge Demo

-- MAIN APPLICATION
addappid(1996690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996691, 1, "95fb53442f30f96636a47be5b0ab199545833211d89c495d4f22b37804e47a50")

