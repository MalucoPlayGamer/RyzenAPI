-- Lua provided by RyzenAPI
-- Game: Euro Fishing

-- MAIN APPLICATION
addappid(314520)
-- Game: addappid(314520)

-- MAIN APP DEPOTS / PACKAGES
addappid(314521, 1, "3aee6a262a549ab49cff30c8c81e636a0666befca5d06a506e50d8c2a15ad9eb")
addappid(321460, 0, "00a37250fa7ac2c36a1e39318866b6147c19197704f56fb30d9383aef508feef")
addappid(321470, 0, "58eaf140ba7675bf13369494a2690c944a54a610aa14cf20b37b58bbeecb989b")
addappid(321472, 0, "4290b0af3262fafd749b0566f693fcc1488748874875aea0e9dbc005dd8267e1")
addappid(321473, 0, "9d2b842d53bfe4a593301d2aa69654aed71a4f5d8b9c9692482eedb8bb62cf14")
addappid(321474, 0, "978661d6c0f24bea5ee88e7dbb7a9d1ad74c6bcd4d3259eebd58e1fc7d715249")
addappid(321475, 0, "4c5df420470e6bece3cbdc860db9e551114a36a806e1d1174468c65f0eb89fa1")
addappid(321476, 0, "0aa1427141bd9b88ea28fc80d5e6c66eb0e00facba9e7952d0e31f68e88ff5b2")
addappid(321478, 0, "d04679469b40ea6af586771a0a8d570f968fdfefbeaadbc34d460aed8321c2c3")
