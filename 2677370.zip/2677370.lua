-- Lua provided by RyzenAPI
-- Game: College Sex - Episode 4

-- MAIN APPLICATION
addappid(2677370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677371, 1, "9983301e4e50761f690915c3eddba485d38ea52bdca0dc1378724983f3d04ad9")
