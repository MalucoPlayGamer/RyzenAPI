-- Lua provided by RyzenAPI
-- Game: 错误之事

-- MAIN APPLICATION
addappid(2220980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2220981, 1, "14ec8070d93bf566b48ad1116db108f823b027de652b22a4c3dba9c8b23de687")

