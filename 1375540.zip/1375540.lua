-- Lua provided by RyzenAPI
-- Game: 1375540

-- MAIN APPLICATION
addappid(1375540)
-- Game: addappid(1375540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375541, 1, "ab361489851c6c0dfea85f19474abb81746f044a3c73951b1348e619beeea838")
