-- Lua provided by RyzenAPI
-- Game: AppID 3148910

-- MAIN APPLICATION
addappid(3148910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148911, 1, "63cf0669f6ccab373de74cd99cc69dae59aa64f7531d3e496afae30cf5edddb5")
