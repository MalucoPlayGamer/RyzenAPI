-- Lua provided by SkyAPI 
-- Game: THE LAST BLADE Soundtrack
addappid(1940720)
addappid(1940721, 1, "fb06d5985a126603f09c3c609d92836e6a57538c9db21c8e4cad84aae7baaea1")
addappid(1940722, 1, "2485948fc920e88a1783f8d39b67829b7509129f8b77356086c6458113d7fa91")
