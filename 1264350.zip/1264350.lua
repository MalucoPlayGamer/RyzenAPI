-- Lua provided by RyzenAPI
-- Game: 夜弦之音 - Echoes of Nocturnal Chords

-- MAIN APPLICATION
addappid(1264350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264351, 1, "30591755995da81765808d58b281b3c16b2634f1010fcd7e5353911f5fe272e9")
