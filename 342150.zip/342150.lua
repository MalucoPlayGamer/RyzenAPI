-- Lua provided by RyzenAPI
-- Game: AppID 342150

-- MAIN APPLICATION
addappid(342150)

-- MAIN APP DEPOTS / PACKAGES
addappid(342151, 1, "b8a916e5425369460d377359efdd9a5ad4c4cba0b5a9b02da6c659a31a27b2d5")
