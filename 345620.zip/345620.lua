-- Lua provided by RyzenAPI
-- Game: The Labyrinth of Grisaia

-- MAIN APPLICATION
addappid(345620)
-- Game: addappid(345620)

-- MAIN APP DEPOTS / PACKAGES
addappid(345621, 1, "35cf22f314e06b6b8dfdd35590f27420cfcd18800c4cfc2ca7c219f5bc5ca1fe")
