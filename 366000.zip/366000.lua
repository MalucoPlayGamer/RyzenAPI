-- Lua provided by RyzenAPI
-- Game: addappid(366000)

-- MAIN APPLICATION
addappid(366000)
addappid(417780)
addappid(417781)
addappid(417782)

-- MAIN APP DEPOTS / PACKAGES
addappid(366001, 1, "7974b3bd612aa078702c3636489f7c218419d1d25a866cae4ac5150d27cdf3b0")
