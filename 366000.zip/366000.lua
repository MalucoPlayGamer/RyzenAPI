-- Lua provided by RyzenAPI
-- Game: Rogue System

-- MAIN APPLICATION
addappid(366000)
addappid(417780)
addappid(417781)
addappid(417782)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(366001, 1, "7974b3bd612aa078702c3636489f7c218419d1d25a866cae4ac5150d27cdf3b0")

