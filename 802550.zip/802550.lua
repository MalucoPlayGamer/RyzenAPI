-- Lua provided by RyzenAPI
-- Game: various fighters

-- MAIN APPLICATION
addappid(802550)

-- MAIN APP DEPOTS / PACKAGES
addappid(802551,0,"14372fc03e47d69269331223cc3c987858f745df1cf28792f60f58043601e70d")

