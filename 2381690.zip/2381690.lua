-- Lua provided by RyzenAPI
-- Game: Game: Monkey Business

-- MAIN APPLICATION
addappid(2381690)
addappid(2746660)
-- Game: addappid(2381690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381691, 1, "93f447fc79f2f06e62c4be56c9c2b448361d6acabe200d2346a88efc3d7eb3bb")
