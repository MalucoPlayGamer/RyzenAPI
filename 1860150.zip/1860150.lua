-- Lua provided by RyzenAPI
-- Game: Operation8 Project

-- MAIN APPLICATION
addappid(1860150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860151, 1, "16f3de7cae6ec973156cffc5c4c8c1da6b65ae42ab44159545d3225892d3f152")
