-- Lua provided by RyzenAPI
-- Game: The Blackout Club

-- MAIN APPLICATION
addappid(599080)
addappid(996060)
addappid(1186870)
addappid(1186871)
addappid(1186872)
addappid(1186873)
addappid(1186874)
addappid(1186875)
addappid(1186876)
addappid(1186877)

-- MAIN APP DEPOTS / PACKAGES
addappid(599085,0,"c4699be11410affcb6cdf67dbeebe63ca30133c0c6a9526be18e4a892cad04ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
