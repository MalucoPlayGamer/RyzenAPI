-- Lua provided by RyzenAPI
-- Game: addappid(599080)

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(599080)

-- MAIN APP DEPOTS / PACKAGES
addappid(599085,0,"c4699be11410affcb6cdf67dbeebe63ca30133c0c6a9526be18e4a892cad04ef")
