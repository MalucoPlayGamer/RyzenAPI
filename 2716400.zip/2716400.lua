-- Lua provided by RyzenAPI
-- Game: The Rise of the Golden Idol

-- MAIN APPLICATION
addappid(2716400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716401, 1, "369c88aa7a34e596ee6cf0e3eb93af0259fe3ef7de70e1e285e73557f365188f")
addappid(3333860, 0, "2adfc1b7518f90239656a9f29587c851f9b8f206381b83d6f0efef44af1bb663")
addappid(3333870, 0, "27c915af9c80ea8746d49e5832f54c3637bd9a20db457028196b94222b47142d")
addappid(3333880, 0, "1a7ba8ee1daadc056b3316e58463f01679a4266c1cdc4f6d6598072e65ce0443")
addappid(3335341, 0, "2000a328e7913b585f04f3db4284593d30a52908720f87c3db07ccbaa9aa596c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3335340)
addappid(3335350)
