-- Lua provided by SkyAPI 
-- Game: Dungeons of Aether
addappid(1668290)
addappid(1668291, 1, "d0f5559bd225642657f8cfc39b1698c8f6f78e955bb419ef4532382834159a0d")
addappid(1668293, 1, "ee95713ee3db2a8c184dabc65ee95626ba0d8a8d6497ac7c035973132ce1c8a9")
