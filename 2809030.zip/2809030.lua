-- Lua provided by RyzenAPI
-- Game: Game: dreamboat

-- MAIN APPLICATION
addappid(2809030)
-- Game: addappid(2809030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809031, 1, "a6bcc554bff6bca034decffc34a32407e5797184d118f8c452b4ac607fe502b6")
