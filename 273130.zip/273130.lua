-- Lua provided by RyzenAPI
-- Game: Castlevania: Lords of Shadow 2 Demo

-- MAIN APPLICATION
addappid(273130)
-- Game: addappid(273130)

-- MAIN APP DEPOTS / PACKAGES
addappid(273131, 1, "f5f09a7203415827c37cae17e54a3932717985aebf9b47f95de140cbdba064e1")
