-- Lua provided by RyzenAPI
-- Game: Operation Wolf Returns: First Mission

-- MAIN APPLICATION
addappid(1852650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852651, 1, "b79fdcf382ecdd8898d6e83c77bc649629e51ee775b223279788809512da1367")
