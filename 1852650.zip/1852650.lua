-- Lua provided by SkyAPI 
-- Game: Operation Wolf Returns: First Mission
addappid(1852650)
addappid(1852651, 1, "b79fdcf382ecdd8898d6e83c77bc649629e51ee775b223279788809512da1367")
