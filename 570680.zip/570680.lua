-- Lua provided by RyzenAPI
-- Game: AppID 570680

-- MAIN APPLICATION
addappid(570680)

-- MAIN APP DEPOTS / PACKAGES
addappid(570681, 1, "134f0d58123b8cb855ee9fd497cb8bd212a254511a7c1ba28f43fe81b1a8a946")

