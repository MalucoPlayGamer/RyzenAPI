-- Lua provided by RyzenAPI
-- Game: Travellin Cats Around the World

-- MAIN APPLICATION
addappid(2377970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2377971, 1, "93bf08a663ee1168c054f966a1c253a9c31f0c3d1bc97af0fda40fe58c674235")

