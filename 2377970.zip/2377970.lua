-- Lua provided by RyzenAPI
-- Game: Travellin Cats Around the World

-- MAIN APPLICATION
addappid(2377970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2377971, 1, "93bf08a663ee1168c054f966a1c253a9c31f0c3d1bc97af0fda40fe58c674235")

