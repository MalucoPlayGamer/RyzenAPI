-- Lua provided by RyzenAPI
-- Game: Project Myriad

-- MAIN APPLICATION
addappid(829410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(829411, 1, "0403176db2fb618ec5ed84b927c028f3a42c83c47834156642a786de52ee3438")

