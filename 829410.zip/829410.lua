-- Lua provided by RyzenAPI 
-- Game: Project Myriad
addappid(829410)
addappid(829411, 1, "0403176db2fb618ec5ed84b927c028f3a42c83c47834156642a786de52ee3438")
