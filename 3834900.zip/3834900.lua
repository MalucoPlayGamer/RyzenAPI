-- Lua provided by RyzenAPI
-- Game: Ark of Trisolar (三体方舟)

-- MAIN APPLICATION
addappid(3834900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3834901, 1, "7fc36d4927b98f63d6e6445f15b626d2e19b20841ad760fa1a18a53d5eedc196")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
