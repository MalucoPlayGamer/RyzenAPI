-- Lua provided by RyzenAPI
-- Game: One More Gate: A Wakfu Legend Demo

-- MAIN APPLICATION
addappid(2013410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013411, 1, "4013f33834b325381cc62a183da1c3e4aa5cc6810424baacbf1c8fe77b6ab0fd")
