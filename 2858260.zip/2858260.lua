-- Lua provided by RyzenAPI
-- Game: 2858260

-- MAIN APPLICATION
addappid(2858260)
-- Game: addappid(2858260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858260,0,"cec8236cf3f9a7590602623e0c2ddc484a08c387b6e70e9448ea24ab45bb4995")
