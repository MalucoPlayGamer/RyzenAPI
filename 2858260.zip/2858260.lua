-- Lua provided by RyzenAPI
-- Game: 小夜怪奇物语追加章节：魔女狂疫

-- MAIN APPLICATION
addappid(2858260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858260,0,"cec8236cf3f9a7590602623e0c2ddc484a08c387b6e70e9448ea24ab45bb4995")
