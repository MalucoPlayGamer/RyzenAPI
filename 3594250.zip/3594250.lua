-- Lua provided by RyzenAPI 
-- Game: Street Fighter 6 Original Soundtrack [Year 1]
addappid(3594250)
addappid(3594251, 1, "e73ba7077c6d42f417db793fa6933742619b3f83eca3b5855f2fac7fcac46ad6")
