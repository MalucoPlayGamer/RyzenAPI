-- Lua provided by RyzenAPI
-- Game: 3594250

-- MAIN APPLICATION
addappid(3594250)
-- Game: addappid(3594250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3594251, 1, "e73ba7077c6d42f417db793fa6933742619b3f83eca3b5855f2fac7fcac46ad6")
