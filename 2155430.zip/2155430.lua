-- Lua provided by RyzenAPI
-- Game: addappid(2155430)

-- MAIN APPLICATION
addappid(2155430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155432,0,"3c9389bc2de927a24def19f42797642c6924e1b3d92b82aacad8413dac374e97")
