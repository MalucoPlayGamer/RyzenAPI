-- Lua provided by RyzenAPI
-- Game: Audition Online

-- MAIN APPLICATION
addappid(349720)

-- MAIN APP DEPOTS / PACKAGES
addappid(349721, 1, "281a9deb9f34b06be47e07f764abe51ac9ea03e840e9bb1af62df0c898d988a0")

