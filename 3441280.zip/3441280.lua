-- Lua provided by RyzenAPI
-- Game: The Greenening

-- MAIN APPLICATION
addappid(3441280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441281,0,"26373e389247fb1413650a0cd67a85e404c654c371244f1ce08dad378fa4a77f")

