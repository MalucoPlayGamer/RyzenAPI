-- Lua provided by RyzenAPI 
-- Game: Freddi Fish and Luther's Maze Madness
addappid(284020)
addappid(284021, 1, "95c92a0c2b949ac36e09d175bbcd9300e82e2bed59b0d01e8e1fa601b8524077")
addappid(284024, 1, "b2ce18d891fae6a6e5598530ece9be602d7b6212938d380fbee9da297aaeb908")
addappid(284025, 1, "37e5612ac9551563fc7fcae6eb41ba47d2b5ce414c8f9645f554a341e61726ba")
