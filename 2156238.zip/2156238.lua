-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2156238)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156238,0,"4c970b818628480ea9b0f1301092983995916387c6c77d4ad74fec6c19d203c5")

