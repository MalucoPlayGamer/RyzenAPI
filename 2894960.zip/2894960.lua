-- Lua provided by RyzenAPI
-- Game: 2894960

-- MAIN APPLICATION
addappid(2894960)
-- Game: addappid(2894960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2894961, 1, "b102bec1790f1821141221dddc50d0347a0c04f7ac396b96efa349f64c4826b1")
