-- Lua provided by RyzenAPI
-- Game: Inverted Angel

-- MAIN APPLICATION
addappid(2894960)
addappid(4612670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2894961, 1, "b102bec1790f1821141221dddc50d0347a0c04f7ac396b96efa349f64c4826b1")

