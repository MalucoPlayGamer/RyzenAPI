-- Lua provided by RyzenAPI 
-- Game: BioMech
addappid(1139130)
addappid(1139131, 1, "f4f5e7326babd027c8c6cb1811bd51f142dc4505e6788b3c779773407ac06e35")
