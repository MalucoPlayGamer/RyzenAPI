-- Lua provided by RyzenAPI
-- Game: 2612460

-- MAIN APPLICATION
addappid(2612460)
-- Game: addappid(2612460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2612460,0,"1e2416b3f616248e7702dc140cc9f7160562ef2d5e6dbbcf97526cce4bff11d9")
