-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: FSDG - Dakar

-- MAIN APPLICATION
addappid(991066)

-- MAIN APP DEPOTS / PACKAGES
addappid(991066,0,"da6032240579b00231409c7918e2514e366d478c99325d40f53b532a7b34a629")

