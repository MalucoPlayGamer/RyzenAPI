-- Lua provided by RyzenAPI
-- Game: 草食系男子の言いなり入院生活- A passive boy at the Huntress clinic -

-- MAIN APPLICATION
addappid(2265010)
-- Game: addappid(2265010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265011, 1, "8cf1f3a32ab5b50a340c902a44e22b592e8b061b0cde5cf7c198a0ff7392e8f5")
