-- Lua provided by RyzenAPI 
-- Game: Hungry Adventurer
addappid(2081830)
addappid(2081831, 1, "c5bc065ce9e08593c306744ceb22084e47529375de5c266901252cd19af58a71")
