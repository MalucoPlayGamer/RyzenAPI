-- Lua provided by RyzenAPI
-- Game: Rest Area Simulator

-- MAIN APPLICATION
addappid(3732960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3732961,0,"b1e5581b68c73fb56e6aa183c0dbc3e6b7f062d7438023f2336e6672e4111d89")

