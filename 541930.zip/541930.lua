-- Lua provided by RyzenAPI
-- Game: Panoptic

-- MAIN APPLICATION
addappid(541930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(541931, 1, "a101bd1f1d8e160d247dfef4d6aa7a41e21be068b5124b3ec942f06a71cf2cb2")

