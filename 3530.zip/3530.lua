-- Lua provided by RyzenAPI
-- Game: addappid(3530)

-- MAIN APPLICATION
addappid(3530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3531, 1, "3defd816ebdc7409b4f70a674238b62530adc0afc03bdbee6e4197b6191045e5")
