-- Lua provided by RyzenAPI
-- Game: Worm Runner

-- MAIN APPLICATION
addappid(2058120)
-- Game: addappid(2058120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058121, 1, "67cb7a038bff779d6ac894e5050c913bafb21e7096af86e859217af0dedcf530")
