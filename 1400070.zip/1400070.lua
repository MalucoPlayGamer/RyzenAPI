-- Lua provided by RyzenAPI
-- Game: Don't Cheat On Me

-- MAIN APPLICATION
addappid(1400070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400071, 1, "5023b942e0cd21b15f630dc3549a0a34cb57b2219a44af2f960bb005215f9c5d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
