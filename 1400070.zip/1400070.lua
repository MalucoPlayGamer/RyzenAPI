-- Lua provided by RyzenAPI 
-- Game: Don't Cheat On Me
addappid(1400070)
addappid(1400071, 1, "5023b942e0cd21b15f630dc3549a0a34cb57b2219a44af2f960bb005215f9c5d")
