-- Lua provided by RyzenAPI
-- Game: Don't Cheat On Me

-- MAIN APPLICATION
addappid(1400070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400071, 1, "5023b942e0cd21b15f630dc3549a0a34cb57b2219a44af2f960bb005215f9c5d")
