-- Lua provided by RyzenAPI 
-- Game: Dungeonoid
addappid(2153000)
addappid(2153001, 1, "2bfb442e38417e4b1d1348b17dae6f419b28abacadf4defa549b0e25e32266a3")
