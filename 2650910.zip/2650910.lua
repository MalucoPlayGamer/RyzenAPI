-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Rolling Stones - "Can’t You Hear Me Knocking"

-- MAIN APPLICATION
addappid(2650910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650910,0,"80ab700e862d4dee8506d6b420a0076c57e7330f0c9210cc7d1bbcf0f86d481c")

