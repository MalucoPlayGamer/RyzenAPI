-- Lua provided by RyzenAPI
-- Game: addappid(2650910)

-- MAIN APPLICATION
addappid(2650910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650910,0,"80ab700e862d4dee8506d6b420a0076c57e7330f0c9210cc7d1bbcf0f86d481c")
