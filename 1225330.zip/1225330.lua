-- Lua provided by RyzenAPI
-- Game: NBA 2K21

-- MAIN APPLICATION
addappid(1225330)
addappid(1357310)
addappid(1357311)
addappid(1357312)
addappid(1357313)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1225331, 1, "bf4623b9dc059a63ddc9c7c1a4d830617cd9e31375ffe3e2af78aff8515b048b")

