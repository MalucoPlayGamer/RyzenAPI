-- Lua provided by RyzenAPI 
-- Game: NBA 2K21
addappid(1225330)
addappid(1225331, 1, "bf4623b9dc059a63ddc9c7c1a4d830617cd9e31375ffe3e2af78aff8515b048b")
