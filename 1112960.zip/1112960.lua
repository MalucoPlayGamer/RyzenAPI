-- Lua provided by RyzenAPI
-- Game: Wildland

-- MAIN APPLICATION
addappid(1112960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112961, 1, "074e29cd6780fd6facfb3d4095185987a01647325990e8feb8996e3150dc67e1")

