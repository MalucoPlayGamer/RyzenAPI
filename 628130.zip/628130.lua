-- Lua provided by RyzenAPI
-- Game: NOBUNAGA'S AMBITION: Soutenroku with Power Up Kit

-- MAIN APPLICATION
addappid(628130)

-- MAIN APP DEPOTS / PACKAGES
addappid(628131, 1, "d8b8c6fdf72fa4cb1b063e0ced2c556e6b9d3557c830299d0b3fba4ef9683a1c")

