-- Lua provided by RyzenAPI
-- Game: Arcadegeddon Art Book

-- MAIN APPLICATION
addappid(2477580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477580,0,"35a8878b6a6a7ac2110eab7e42c574404b340c085eff5d2c04d9804819c84400")

