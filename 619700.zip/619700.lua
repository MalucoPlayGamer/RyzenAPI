-- Lua provided by RyzenAPI
-- Game: AppID 619700

-- MAIN APPLICATION
addappid(619700)
addappid(969110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(619701, 1, "6a6f743e4d7aecf910a83c2979caf9e94fb381585d93375985fb72dd6aeac190")
addappid(619702, 1, "780325af5dde5fc00d8a22edf10a29a04cc3c85665c506548844bda2ae708015")
addappid(619703, 1, "933ecd886f49d4c18ab46ead5e79b02b2f3c61e4a1cf203d7dec41f6fc712b07")

