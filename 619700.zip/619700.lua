-- Lua provided by RyzenAPI
-- Game: AppID 619700

-- MAIN APPLICATION
addappid(619700)
-- Game: addappid(619700)

-- MAIN APP DEPOTS / PACKAGES
addappid(619701, 1, "6a6f743e4d7aecf910a83c2979caf9e94fb381585d93375985fb72dd6aeac190")
addappid(619702, 1, "780325af5dde5fc00d8a22edf10a29a04cc3c85665c506548844bda2ae708015")
addappid(619703, 1, "933ecd886f49d4c18ab46ead5e79b02b2f3c61e4a1cf203d7dec41f6fc712b07")
