-- Lua provided by RyzenAPI
-- Game: AppID 1110870

-- MAIN APPLICATION
addappid(1110870)
-- Game: addappid(1110870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110871, 1, "9e36438a823256f1d2ea0d4b7ea4547c9c1d093e0408963fd4ecb11c7a0ca604")
