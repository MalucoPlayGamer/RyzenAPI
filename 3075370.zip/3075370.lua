-- Lua provided by RyzenAPI
-- Game: Crazy Islands

-- MAIN APPLICATION
addappid(3075370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3075379,0,"5137d54b97faece43a2397dbe2bc0332b3a3a4bbd413b5641b19f4ee9d6f0832")
