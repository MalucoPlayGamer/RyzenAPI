-- Lua provided by RyzenAPI
-- Game: DEAD LAMB WALKING

-- MAIN APPLICATION
addappid(3272960)
