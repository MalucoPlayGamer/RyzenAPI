-- Lua provided by RyzenAPI
-- Game: Some Synergy

-- MAIN APPLICATION
addappid(1969910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969912,0,"23560d18540a402c3630a21b5cbda09f9fbc4e2873c8a62016461456b2e6e8bb")
