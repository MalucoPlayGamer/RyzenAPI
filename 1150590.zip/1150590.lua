-- Lua provided by SkyAPI 
-- Game: AppID 1150590
addappid(1150590)
addappid(1150591, 1, "7e64949511fb7797e94c062b1483e46e4b941ad39acb357e5896759494d81b52")
