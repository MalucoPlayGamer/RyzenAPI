-- Lua provided by RyzenAPI
-- Game: Samurai Jack: Battle Through Time

-- MAIN APPLICATION
addappid(1150590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1150591, 1, "7e64949511fb7797e94c062b1483e46e4b941ad39acb357e5896759494d81b52")
