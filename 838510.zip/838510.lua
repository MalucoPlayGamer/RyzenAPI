-- Lua provided by RyzenAPI
-- Game: Find & Destroy: Tank Strategy

-- MAIN APPLICATION
addappid(838510)

-- MAIN APP DEPOTS / PACKAGES
addappid(838511, 1, "b0dd11b70a2cbe3b4b3cba51ba56abe79ed07c49de962c0f0343a72b6a08ca62")
addappid(838512, 1, "3ae3771e1c9009ad4fcdba4155c2a33014920d1f5da947bc070f310d7bb0971e")
addappid(838513, 1, "600a6cc62970fa46497f4901e5511b6eedfd91e94a53f3eb179fc20de15c72ed")

