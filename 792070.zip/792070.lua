-- Lua provided by RyzenAPI
-- Game: Asteion Nights

-- MAIN APPLICATION
addappid(792070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(792071,0,"7ee4dab83d5c65c944a5eb732c372b2388574d355dea48e12fb9f31f1435b053")

