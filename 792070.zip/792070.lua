-- Lua provided by RyzenAPI
-- Game: Asteion Nights

-- MAIN APPLICATION
addappid(792070)

-- MAIN APP DEPOTS / PACKAGES
addappid(792071,0,"7ee4dab83d5c65c944a5eb732c372b2388574d355dea48e12fb9f31f1435b053")

