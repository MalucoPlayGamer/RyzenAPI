-- Lua provided by RyzenAPI
-- Game: Emiko's Pledge

-- MAIN APPLICATION
addappid(1870170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870171, 1, "d51f24b2d482297808d39a810ce2300e58c95b7100f12b74b1b3304b62f04c3d")

