-- Lua provided by RyzenAPI
-- Game: addappid(3078020)

-- MAIN APPLICATION
addappid(3078020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078021, 1, "b9008cb9a4ebbee92b4f2c0c981f28d997127a0b23cca44cdab5f43b3cf5f4d0")
