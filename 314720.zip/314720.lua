-- Lua provided by RyzenAPI
-- Game: Game: ShaderTool

-- MAIN APPLICATION
addappid(314720)
-- Game: addappid(314720)

-- MAIN APP DEPOTS / PACKAGES
addappid(314721, 1, "29d0469d0ea2aad5cbf4f81625ae482ea18271f32ccd96e8c76a558850620126")
