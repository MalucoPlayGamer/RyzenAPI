-- Lua provided by RyzenAPI
-- Game: AppID 603530

-- MAIN APPLICATION
addappid(603530)

-- MAIN APP DEPOTS / PACKAGES
addappid(603531, 1, "c3af1fa9dc89941c92596e71efbfa1ab06f8c6a197020f912e84be852f75ce68")

