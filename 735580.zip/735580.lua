-- Lua provided by RyzenAPI
-- Game: 11-11 Memories Retold

-- MAIN APPLICATION
addappid(735580)
addappid(923380)

-- MAIN APP DEPOTS / PACKAGES
addappid(735581, 1, "9aefe2be7406173d6d55545e609fd475bf8fa23cb31724d8a0d829f08e4abc33")

