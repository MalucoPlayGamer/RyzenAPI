-- Lua provided by RyzenAPI
-- Game: 11-11 Memories Retold

-- MAIN APPLICATION
addappid(735580)
addappid(923380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(735581, 1, "9aefe2be7406173d6d55545e609fd475bf8fa23cb31724d8a0d829f08e4abc33")