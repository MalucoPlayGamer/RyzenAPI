-- Lua provided by RyzenAPI
-- Game: 3016980

-- MAIN APPLICATION
addappid(3016980)
-- Game: addappid(3016980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016981, 1, "0d1fedf232c9c531a4682d3e86550ef805ccd6779c03233894001a9fb329fe9e")
