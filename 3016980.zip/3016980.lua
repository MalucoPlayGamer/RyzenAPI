-- Lua provided by RyzenAPI 
-- Game: Love Quiz Battle: LoveLove Quiz
addappid(3016980)
addappid(3016981, 1, "0d1fedf232c9c531a4682d3e86550ef805ccd6779c03233894001a9fb329fe9e")
