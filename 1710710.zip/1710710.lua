-- Lua provided by SkyAPI 
-- Game: AppID 1710710
addappid(1710710)
addappid(1710711, 1, "0594eb5fc0254987ca94be9901e956e5949e4556ecefcb8ac62e56a88a2178e7")
