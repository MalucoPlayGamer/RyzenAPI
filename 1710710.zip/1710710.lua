-- Lua provided by RyzenAPI
-- Game: AppID 1710710

-- MAIN APPLICATION
addappid(1710710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710711, 1, "0594eb5fc0254987ca94be9901e956e5949e4556ecefcb8ac62e56a88a2178e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
