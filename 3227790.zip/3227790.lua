-- Lua provided by RyzenAPI
-- Game: Game: The Uncultured

-- MAIN APPLICATION
addappid(3227790)
-- Game: addappid(3227790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227791, 1, "5d1bfd7a5e4818a9db464b5ff33f680721597310f5ddbcca56499c3d5041938a")
