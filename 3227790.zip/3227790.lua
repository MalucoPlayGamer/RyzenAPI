-- Lua provided by SkyAPI 
-- Game: The Uncultured
addappid(3227790)
addappid(3227791, 1, "5d1bfd7a5e4818a9db464b5ff33f680721597310f5ddbcca56499c3d5041938a")
