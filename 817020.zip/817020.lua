-- Lua provided by RyzenAPI
-- Game: Game: AppID 817020

-- MAIN APPLICATION
addappid(817020)
-- Game: addappid(817020)

-- MAIN APP DEPOTS / PACKAGES
addappid(817021, 1, "0a93126377aad37f012e676550507031d59ed06e48f5a481eeec2898f60421d7")
