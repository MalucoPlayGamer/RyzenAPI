-- Lua provided by RyzenAPI
-- Game: V.L.A.D.i.K

-- MAIN APPLICATION
addappid(1023980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023981, 1, "aa6b71fc5824f192ecd792ca941622453d7ea4efb36c819c571b415d0d7cdec9")
