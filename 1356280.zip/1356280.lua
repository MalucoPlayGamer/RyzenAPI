-- Lua provided by RyzenAPI
-- Game: Kitaria Fables

-- MAIN APPLICATION
addappid(1356280)
-- Game: addappid(1356280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356282,0,"48760c1b1699ac09822f3c157d5fdc53c79366dca2ce09d236ce81bc07a76d02")
addappid(1582422,0,"9c43b6367f7e52f361336b11fb434d3f0f37e0f083c915d1feb6417de2c3bf77")
