-- Lua provided by RyzenAPI
-- Game: Kitaria Fables

-- MAIN APPLICATION
addappid(1356280)
addappid(1650160)
addappid(1650170)
addappid(1650171)
addappid(1650172)
addappid(1650173)
addappid(1650174)
addappid(1650175)
addappid(1650176)
addappid(1650177)
addappid(1650178)
addappid(1650179)
addappid(1650230)
addappid(1650231)
addappid(1650232)
addappid(1650233)
addappid(1650260)
addappid(1785040)
addappid(1785041)
addappid(1785042)
addappid(1793720)
addappid(1793721)
addappid(1793722)
addappid(1793723)
addappid(1793724)
addappid(1793725)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356282,0,"48760c1b1699ac09822f3c157d5fdc53c79366dca2ce09d236ce81bc07a76d02")
addappid(1582422,0,"9c43b6367f7e52f361336b11fb434d3f0f37e0f083c915d1feb6417de2c3bf77")

