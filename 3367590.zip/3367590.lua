-- Lua provided by RyzenAPI 
-- Game: AppID 3367590
addappid(3367590)
addappid(3367591, 1, "3abf0d8a5798ca0647190c26ed62243ff470bb2f50d07f450ad2d89337fd1e5b")
