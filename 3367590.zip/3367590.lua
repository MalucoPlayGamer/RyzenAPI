-- Lua provided by RyzenAPI
-- Game: 3367590

-- MAIN APPLICATION
addappid(3367590)
-- Game: addappid(3367590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3367591, 1, "3abf0d8a5798ca0647190c26ed62243ff470bb2f50d07f450ad2d89337fd1e5b")
