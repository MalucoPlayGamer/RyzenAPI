-- Lua provided by RyzenAPI 
-- Game: NINJA GIRL
addappid(1417050)
addappid(1417051, 1, "65460fa750529f42e622599363cc6f5d8e28385a1517f213119de8328a2b7a7f")
