-- Lua provided by RyzenAPI
-- Game: Not For Broadcast

-- MAIN APPLICATION
addappid(1147550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147551, 1, "e77c3c3ca48df0a2a140f22a16494bd674a3f90e02d7cd6aaa06a069f7da2306")
addappid(1147552, 1, "5db5a1906dc83552bc93a7fbc8e198fd94f5158e7d05b9eefed30bb8c49d4ae8")
addappid(1147553, 1, "7184221fe0a0d5caef7cf93b1bc24aed87cfa5a046f5634de14636ae4fc52434")
addappid(1147554, 1, "ea562c0ad50c7bd0fa0cb2a6684ff6cb71d5654f676828c005d337b07a40f085")
addappid(2199310, 0, "84b163bc9e08de48a1e587247896559e7da504735d4277dc6674e364fb8b0af1")
addappid(2303600, 0, "3e435af6db627c5fdf10e365b1e319b49b1aac6190e5bef985aab211221849a3")
addappid(2303601, 0, "af3f3248a85fa608d6be03357aa4790209ad4d008567a76d40726cf9124924e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2303602)
