-- Lua provided by RyzenAPI
-- Game: WANDERER: Broken Bed - Big Wallpapers Pack

-- MAIN APPLICATION
addappid(2814140)
-- Game: addappid(2814140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814140,0,"10a8c852ce82e20f36ffe185561c317941bc811e769aeff7af531eafc999aa23")
