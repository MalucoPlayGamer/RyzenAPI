-- Lua provided by RyzenAPI
-- Game: Game: Vyanka's Memories Demo

-- MAIN APPLICATION
addappid(3236210)
-- Game: addappid(3236210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3236211, 1, "fafe25c224a511dbeb91611c9717250ddd9eeb3f0e26c5b1537a8e2ba1e29227")
