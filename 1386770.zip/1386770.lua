-- Lua provided by RyzenAPI
-- Game: Blip (Open Alpha)

-- MAIN APPLICATION
addappid(1386770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386771, 1, "7c7886d120b89a528437a7f675e0cd3c4b08f43dc031497c56805660954a941d")
addappid(1386772, 1, "d57d8383c91d3b2ca0a11547f0171b8ec3918b2afdd56ca47d6ae399e0266c0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
