-- Lua provided by RyzenAPI
-- Game: AppID 1548510

-- MAIN APPLICATION
addappid(1548510)
addappid(1600940)
-- Game: addappid(1548510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548511, 1, "7eedfe6b2cd8bd0c7b5a71eeda69ba3fe391c68acc8a11c38e7fa98c1c290d75")
