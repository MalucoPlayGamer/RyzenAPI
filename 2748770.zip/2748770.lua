-- 2748770's Lua and Manifest Created by Hubcap Manifest
-- Dala and the Cursed Forest
-- Created: June 27, 2026 at 05:42:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2748770) -- Dala and the Cursed Forest
-- MAIN APP DEPOTS
addappid(2748771, 1, "c53e96059ca5e402e21192d99af701adaeaea26952aa97d5a46bfa209d9050df") -- Depot 2748771
-- setManifestid(2748771, "4928091631347295047", 1186950467)