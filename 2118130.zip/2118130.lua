-- Lua provided by RyzenAPI
-- Game: addappid(2118130)

-- MAIN APPLICATION
addappid(2118130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118131, 1, "b0fa75bac5473f37989d2f383f332d31d5f16ce7a9e2eb482d55babaa5868401")
