-- Lua provided by RyzenAPI
-- Game: Chicken Feet

-- MAIN APPLICATION
addappid(2118130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2118131, 1, "b0fa75bac5473f37989d2f383f332d31d5f16ce7a9e2eb482d55babaa5868401")

