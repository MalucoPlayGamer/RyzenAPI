-- Lua provided by RyzenAPI
-- Game: addappid(654430)

-- MAIN APPLICATION
addappid(654430)

-- MAIN APP DEPOTS / PACKAGES
addappid(654431, 1, "a403cda77a7b79ce53225af892df8aefeb58d53bb9f29a781f07f97d9db0cad5")
