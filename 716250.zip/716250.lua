-- Lua provided by RyzenAPI
-- Game: Game: Eight Dragons

-- MAIN APPLICATION
addappid(716250)
-- Game: addappid(716250)

-- MAIN APP DEPOTS / PACKAGES
addappid(716251, 1, "2c0de77aa2c62aaeda9471d685c55a392e20c57ab937e29f8ae94d5af1654eda")
addappid(716252, 1, "5504025bdf10da6e3dc17059163a43f84e6ae1d3ad3ccd7470d5ff4048da7608")
addappid(716253, 1, "7d924c21c0b8091df4848ac22e1dfa896534c7200b7c48b83463d80686186e9f")
addappid(716254, 1, "baa418e388eba8daae34fd80baa29fbdffb7b3260520bcb93ea217a86815c6c6")
