-- Lua provided by RyzenAPI
-- Game: Eight Dragons

-- MAIN APPLICATION
addappid(716250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(716251, 1, "2c0de77aa2c62aaeda9471d685c55a392e20c57ab937e29f8ae94d5af1654eda")
addappid(716252, 1, "5504025bdf10da6e3dc17059163a43f84e6ae1d3ad3ccd7470d5ff4048da7608")
addappid(716253, 1, "7d924c21c0b8091df4848ac22e1dfa896534c7200b7c48b83463d80686186e9f")
addappid(716254, 1, "baa418e388eba8daae34fd80baa29fbdffb7b3260520bcb93ea217a86815c6c6")

