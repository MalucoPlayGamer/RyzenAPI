-- Lua provided by RyzenAPI
-- Game: Ghost Case

-- MAIN APPLICATION
addappid(4883150) -- Ghost Case

-- MAIN APP DEPOTS / PACKAGES
addappid(4883151, 1, "81a790bf72fa7d060f76a381abcfe5393acd476cb034988195cd42969fc152c0") -- Depot 4883151

