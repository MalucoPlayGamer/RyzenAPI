-- Lua provided by RyzenAPI
-- Game: Mirror's Edge™ Catalyst

-- MAIN APPLICATION
addappid(1233570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233571, 1, "4a7739c3f8685c5004646c84c6a1e1e012f888b12a033bffbb7174d6dc71fe23")
addappid(1233572, 1, "3bb71854973567ca44bed6ac1627ce0af43164752bb94f1e0ffa2a3e4262685b")
addappid(1233573, 1, "05e7f3b53812763a8afaa3e4cce4eda454dc764f68a83e9409d1e0fbfa46c1ce")
addappid(1233574, 1, "486e564945a9d732639bd5f5339df13a41bf8300d345ac02ff7e168db7741f0d")
addappid(1233575, 1, "69e2755b5f71b726d4f3cf6a34a844502b62da1ee8e4a243567af5e7e14b4826")
addappid(1233576, 1, "bd8902a4963d5cbd15bbabcebc352c327bf674209588dff6e0e445ae359a7a41")
addappid(1233577, 1, "7498325c3586ec7c0c0f327ddab3b8aa45fd0ab30660a57c3e3c31bffb92373f")
addappid(1233578, 1, "8b8292b730c644c2be533caec47b66371fca6ced3d04f7b4ee3731fe59f58598")
addappid(1233579, 1, "50619a2dcc2fd76e192034e34496a9238d66eb23bc2b254649c1f06e16821bbf")
addappid(1238091, 0, "7e605fbeb142e54bc02d3abce04a2ca946aa363e26800a542ad663e76d721a11")
addappid(1238092, 0, "ceefca4eb050e65558ce6123b162b90ce47e852604aded4ed021eb6f82aa1df1")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1238090)
addappid(1238380)
addappid(1238381)
addappid(1290410)
