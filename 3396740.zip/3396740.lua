-- Lua provided by RyzenAPI
-- Game: Backrooms: Hide Together

-- MAIN APPLICATION
addappid(3396740)
-- Game: addappid(3396740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3396741, 1, "c04920cada0992c8fb458ba44ed22d938487329ba7248d4224818078205ec0f2")
