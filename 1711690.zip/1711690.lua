-- Lua provided by RyzenAPI
-- Game: Aran's Bike Trip

-- MAIN APPLICATION
addappid(1711690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711691, 1, "8f33d3079abdbce4838dd1bc908ee523dee00dd85dc23cf1cb641ab0cbcd7f27")

