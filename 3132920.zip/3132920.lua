-- Lua provided by RyzenAPI
-- Game: addappid(3132920)

-- MAIN APPLICATION
addappid(3132920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132921, 1, "bf34f2a9f925544c68c3824ab4777888610057becec26077ac6f7ccf09e22d12")
