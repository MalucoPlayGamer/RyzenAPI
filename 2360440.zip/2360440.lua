-- Lua provided by RyzenAPI
-- Game: Dreamians: Card Battle

-- MAIN APPLICATION
addappid(2360440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360441, 1, "d882b0b0412eecc3c0df2d513a82e60a2f577095429e533f2052784b38d6d688")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
