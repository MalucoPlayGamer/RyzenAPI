-- Lua provided by RyzenAPI
-- Game: AppID 1174050

-- MAIN APPLICATION
addappid(1174050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1174051, 1, "2e1c11a4e889a88ea65d6c8c7f08b8d93ebf6ddae88a76a9eeaf1b3563909e34")
