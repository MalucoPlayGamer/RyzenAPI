-- Lua provided by SkyAPI 
-- Game: AppID 2655190
addappid(2655190)
addappid(2655191, 1, "e25d43fb7797944fecdab1fb0facae713711590e6f94f8baf658b2851a26fdd5")
