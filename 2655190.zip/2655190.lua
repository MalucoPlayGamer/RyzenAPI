-- Lua provided by RyzenAPI
-- Game: Game: AppID 2655190

-- MAIN APPLICATION
addappid(2655190)
-- Game: addappid(2655190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655191, 1, "e25d43fb7797944fecdab1fb0facae713711590e6f94f8baf658b2851a26fdd5")
