-- Lua provided by RyzenAPI
-- Game: Abrix 2 - Diamond version

-- MAIN APPLICATION
addappid(461850)
addappid(465340)

-- MAIN APP DEPOTS / PACKAGES
addappid(461851, 1, "8ca2c0a220bc056a94e2a918a78cd8dfd4a6a15e5100d830db83319de73c70c0")
addappid(461853, 1, "92e89975f25a6f08bdc18b3fcfc6a84c85770dd20e0f3e45732c6bf3d61376b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(489200)
addappid(526830)
