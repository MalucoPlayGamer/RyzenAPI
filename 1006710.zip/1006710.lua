-- Lua provided by RyzenAPI
-- Game: Decent Icons 2

-- MAIN APPLICATION
addappid(1006710)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1006712,0,"8050c84973de0f7b121bf3d907491ea89fcef5cf85f96f03accafe74c49f8b94")

