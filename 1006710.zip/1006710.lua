-- Lua provided by RyzenAPI
-- Game: Decent Icons 2

-- MAIN APPLICATION
addappid(1006710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006712,0,"8050c84973de0f7b121bf3d907491ea89fcef5cf85f96f03accafe74c49f8b94")
