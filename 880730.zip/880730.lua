-- Lua provided by RyzenAPI
-- Game: Rocket Assault

-- MAIN APPLICATION
addappid(880730)

-- MAIN APP DEPOTS / PACKAGES
addappid(880731,0,"cc9c72c31939ae279f8c84aed323832e369736db6e9608dff47273a027033e1d")

