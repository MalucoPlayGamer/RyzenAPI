-- Lua provided by RyzenAPI
-- Game: Rocket Assault

-- MAIN APPLICATION
addappid(880730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(880731,0,"cc9c72c31939ae279f8c84aed323832e369736db6e9608dff47273a027033e1d")

