-- Lua provided by RyzenAPI
-- Game: addappid(2162710)

-- MAIN APPLICATION
addappid(2162710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162710,0,"4a9caf7a11002e52b89fe8bcbf94e73505cff5496c58de06480e6eff9287c11e")
