-- Lua provided by RyzenAPI
-- Game: Croc's World Construction Kit

-- MAIN APPLICATION
addappid(831910)

-- MAIN APP DEPOTS / PACKAGES
addappid(831911,0,"3c844a8888ca960ca35618fb8f4651478cbdbf4b140f3f6965621c4115637c1b")

