-- Lua provided by RyzenAPI 
-- Game: 黑石
addappid(2774150)
addappid(2774151, 1, "23c25cfd4b22d38f85eb8943b926bad2b331a8a989367fc9382026f5d5ea4000")
