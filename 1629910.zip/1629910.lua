-- Lua provided by RyzenAPI
-- Game: AppID 1629910

-- MAIN APPLICATION
addappid(1629910)
-- Game: addappid(1629910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1629911, 1, "a520d95aac236f70a68664a8b2ea06dda12bd444d216492108c646946738b3ff")
