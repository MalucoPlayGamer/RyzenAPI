-- Lua provided by RyzenAPI
-- Game: King of Retail 2

-- MAIN APPLICATION
addappid(2425150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2425151, 1, "786a49a2dd06813007c5e4577ef05a2b3fb1f6065a198f8f53a0bc4ac7bf55b6")

