-- Lua provided by RyzenAPI 
-- Game: King of Retail 2
addappid(2425150)
addappid(2425151, 1, "786a49a2dd06813007c5e4577ef05a2b3fb1f6065a198f8f53a0bc4ac7bf55b6")
