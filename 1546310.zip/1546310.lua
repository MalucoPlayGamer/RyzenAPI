-- Lua provided by RyzenAPI
-- Game: addappid(1546310)

-- MAIN APPLICATION
addappid(1546310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546311, 1, "79be084b976dd6b187c62daaaa02ddded150136dcc4a154813732a078ed77c4c")
