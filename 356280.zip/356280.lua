-- Lua provided by RyzenAPI
-- Game: Desert Law

-- MAIN APPLICATION
addappid(356280)
-- Game: addappid(356280)

-- MAIN APP DEPOTS / PACKAGES
addappid(356281, 1, "d1b0633dc1be7db09b7b7e6eba856648b8c4081c5d35ca7ce796fce70cfbd5ce")
addappid(356282, 1, "69c703e323ef0b8ac28e5a8b8655a6ae47b992353699be7b9a7ce4d43ab28f95")
addappid(356283, 1, "5535cd67d409c9a6ca4127c16b8c27f8b71cfeabc3921de8083c9debeb7672af")
addappid(356284, 1, "c55c447d53fc1181984dbc9db80ef4b1b0de18ce19adf34fa58703f6d82b41de")
