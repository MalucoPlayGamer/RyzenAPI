-- 4886760's Lua and Manifest Created by Hubcap Manifest
-- Bull&Bear Crypto Trading Simulator
-- Created: August 01, 2026 at 00:35:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4886760) -- Bull&Bear Crypto Trading Simulator
-- MAIN APP DEPOTS
addappid(4886762, 1, "295cfcb0b49579c396640a37d7607d69507d0ac765b6989c65ec1444ad050005") -- Depot 4886762
setManifestid(4886762, "8742668152527959268", 103321123)