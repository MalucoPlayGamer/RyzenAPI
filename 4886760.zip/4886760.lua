-- Lua provided by RyzenAPI
-- Game: Bull&Bear Crypto Trading Simulator

-- MAIN APPLICATION
addappid(4886760) -- Bull&Bear Crypto Trading Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4886762, 1, "295cfcb0b49579c396640a37d7607d69507d0ac765b6989c65ec1444ad050005") -- Depot 4886762

