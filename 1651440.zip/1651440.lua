-- Lua provided by SkyAPI 
-- Game: AppID 1651440
addappid(1651440)
addappid(1651441, 1, "5b7c6215db0b16cc5b80fb8d0e6888f091d810499c7e2b077b8d1094af09476e")
