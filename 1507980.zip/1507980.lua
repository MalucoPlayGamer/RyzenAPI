-- Lua provided by RyzenAPI
-- Game: Game: Leap of Love - Safe Edition

-- MAIN APPLICATION
addappid(1507980)
-- Game: addappid(1507980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507981, 1, "f95de23d4895e345b16a458dbcb2344b03c24a5755d229196fe231dbe819b419")
