-- Lua provided by RyzenAPI
-- Game: AppID 1114380

-- MAIN APPLICATION
addappid(1114380)
addappid(2916140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1114381, 1, "90eeac32af2b7ae17121fc960d0d98659832a46cc6ed53b079897bb0829039ba")

