-- Lua provided by RyzenAPI
-- Game: 521720

-- MAIN APPLICATION
addappid(521720)
-- Game: addappid(521720)

-- MAIN APP DEPOTS / PACKAGES
addappid(521721, 1, "5682f7fbb16aa4a7072516b75502a5b026fd12f225c6c5cc83028eb05a5a694b")
