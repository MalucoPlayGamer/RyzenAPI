-- Lua provided by RyzenAPI
-- Game: GameDev Life Simulator 🎮🕹

-- MAIN APPLICATION
addappid(2256790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256791, 1, "25df0f950fbc7ca28990ba0405f4bdd9d828dae85f7c777ccf2ccc47362f6311")
