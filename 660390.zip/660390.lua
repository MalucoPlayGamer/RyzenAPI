-- Lua provided by RyzenAPI
-- Game: Game: RageBall

-- MAIN APPLICATION
addappid(660390)
-- Game: addappid(660390)

-- MAIN APP DEPOTS / PACKAGES
addappid(660391, 1, "7a8c18c7692b4863b9962b8e8ba9ec25a56a3d1881688beb60113d35b02640eb")
