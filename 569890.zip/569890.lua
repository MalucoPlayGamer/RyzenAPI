-- Lua provided by RyzenAPI
-- Game: me Igigu

-- MAIN APPLICATION
addappid(569890)

-- MAIN APP DEPOTS / PACKAGES
addappid(569891,0,"217841d793bffa411f14c9fd9efeca3e35665eb773c8df1e9fc33dcc8664b6f4")

