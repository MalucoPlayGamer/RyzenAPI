-- Lua provided by RyzenAPI
-- Game: me Igigu

-- MAIN APPLICATION
addappid(569890)

-- MAIN APP DEPOTS / PACKAGES
addappid(569891,0,"217841d793bffa411f14c9fd9efeca3e35665eb773c8df1e9fc33dcc8664b6f4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
