-- Lua provided by RyzenAPI
-- Game: addappid(1721950)

-- MAIN APPLICATION
addappid(1721950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721951, 1, "a74064f5f01c5f730ca49150b7fb1f595cd02142ce5791356369ded55108fe8b")
