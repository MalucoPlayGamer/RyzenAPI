-- Lua provided by RyzenAPI
-- Game: addappid(1018420)

-- MAIN APPLICATION
addappid(1018420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018421, 1, "45e9dc20a5b98f333f1400a56e5ea0bb87c26e1bc70a43aa9906eacb220f4bb1")
