-- Lua provided by RyzenAPI
-- Game: Battlegun

-- MAIN APPLICATION
addappid(684720)

-- MAIN APP DEPOTS / PACKAGES
addappid(684721, 1, "547a80da3a76df0734502b67f8d957c0e8c99695fac18a6900b1646dbc247bc3")
