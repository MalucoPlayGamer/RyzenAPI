-- Lua provided by RyzenAPI 
-- Game: TEXNOPLAZM Demo
addappid(2757700)
addappid(2757701, 1, "76849060c1d391ee3ba0159b180b7dbdf674e0a3f95898a25dd5699a1d5ff444")
