-- Lua provided by SkyAPI 
-- Game: Cultivation Fantasy
addappid(2610720)
addappid(2610721, 1, "08793c10e87f4815243491db5001bd993a290c49756ffd032173e4ad00273317")
