-- Lua provided by RyzenAPI
-- Game: 451130

-- MAIN APPLICATION
addappid(451130)
-- Game: addappid(451130)

-- MAIN APP DEPOTS / PACKAGES
addappid(451131, 1, "176bfd8d7237daef5b9ebe9d9232ce27248568e95fef0bdde2fcbde98a0aafb9")
