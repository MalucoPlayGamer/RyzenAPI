-- Lua provided by RyzenAPI
-- Game: Loop:ClassRoom

-- MAIN APPLICATION
addappid(2980940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2980941, 1, "67348c0b941951d0ad44f420f11c08d56d3a60eeb6dd772dfd10d0672a4d6b7e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
