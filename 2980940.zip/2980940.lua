-- Lua provided by RyzenAPI
-- Game: Loop:ClassRoom

-- MAIN APPLICATION
addappid(2980940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2980941, 1, "67348c0b941951d0ad44f420f11c08d56d3a60eeb6dd772dfd10d0672a4d6b7e")
