-- Lua provided by RyzenAPI
-- Game: Game: Cats on Duty: Prologue

-- MAIN APPLICATION
addappid(2668350)
-- Game: addappid(2668350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668351, 1, "314dcf8981881784fb3ac24f76ba7326960901c1327fd4260c69bdce6fd801b4")
