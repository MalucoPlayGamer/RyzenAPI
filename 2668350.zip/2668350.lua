-- Lua provided by RyzenAPI
-- Game: Cats on Duty: Prologue

-- MAIN APPLICATION
addappid(2668350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2668351, 1, "314dcf8981881784fb3ac24f76ba7326960901c1327fd4260c69bdce6fd801b4")

