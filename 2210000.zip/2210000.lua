-- Lua provided by RyzenAPI
-- Game: Game: Unnatural: Benighted

-- MAIN APPLICATION
addappid(2210000)
-- Game: addappid(2210000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210001, 1, "b3ebd6db827551e464a55b1536741a46dd0925fadba8ea4b2353ced7e04caae0")
