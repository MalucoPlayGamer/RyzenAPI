-- Lua provided by RyzenAPI
-- Game: Dark Mechanism

-- MAIN APPLICATION
addappid(600580)

-- MAIN APP DEPOTS / PACKAGES
addappid(600581,0,"0c7422b6fe1a2f2331414cbadb60e0d80b8dd9f268a5d2cdba2ac1332278c4e1")

