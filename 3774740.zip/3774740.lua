-- Lua provided by RyzenAPI
-- Game: Game: Rooftops & Alleys - Soundtrack

-- MAIN APPLICATION
addappid(3774740)
-- Game: addappid(3774740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3774741, 1, "cce2250f8f9305417c348297a76926af196ae6e34ab2e19f3476cd1b92415c1e")
