-- Lua provided by RyzenAPI
-- Game: Game: AppID 2434970

-- MAIN APPLICATION
addappid(2434970)
-- Game: addappid(2434970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434971, 1, "e8600623b09e03687fab6e757bf00333204cb712dc1caa70ec1c9ca080288f6f")
