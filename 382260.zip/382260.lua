-- Lua provided by RyzenAPI
-- Game: 8Bit Fiesta

-- MAIN APPLICATION
addappid(382260)
addappid(845580)
addappid(845581)
addappid(845582)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(382261, 1, "465368b2133aac37e918b0d0234d40faeb95c2d831eefaac7b7e3e37496775d9")
addappid(382263, 1, "348522dfa5423a8fcaea6653286b14c49d5f11be6d3510694c58da1c69ce0931")