-- Lua provided by RyzenAPI
-- Game: DFF NT: Shire Crook, Y'shtola's 4th Weapon

-- MAIN APPLICATION
addappid(1022430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022430,0,"2ff8bf0e570f1c404c8fae4717ef04c87004c4f22d9d8c238d6054b9bb012872")
