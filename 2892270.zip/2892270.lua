-- Lua provided by RyzenAPI
-- Game: 2892270

-- MAIN APPLICATION
addappid(2892270)
-- Game: addappid(2892270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892271, 1, "34bed4536756e996445e9287ec4069a6fff951998fd465fa4e9ae8731a5a3da6")
