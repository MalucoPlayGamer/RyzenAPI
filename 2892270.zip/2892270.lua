-- Lua provided by RyzenAPI
-- Game: AppID 2892270

-- MAIN APPLICATION
addappid(2892270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892271, 1, "34bed4536756e996445e9287ec4069a6fff951998fd465fa4e9ae8731a5a3da6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
