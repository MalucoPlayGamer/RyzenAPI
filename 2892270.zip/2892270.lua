-- Lua provided by SkyAPI 
-- Game: AppID 2892270
addappid(2892270)
addappid(2892271, 1, "34bed4536756e996445e9287ec4069a6fff951998fd465fa4e9ae8731a5a3da6")
