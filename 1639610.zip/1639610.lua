-- Lua provided by RyzenAPI
-- Game: Game: Save Me, Sakuya-san!

-- MAIN APPLICATION
addappid(1639610)
-- Game: addappid(1639610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639611, 1, "eb1fc5d4dae7170bb7834eaa4901e431831a962ecd5b84c252e4ec4ab0ec4301")
addappid(1639612, 1, "8631b76511103d887ed012ab751dfd5107ae1bcdf21e2079f046ed8e5bfd1d25")
addappid(1639613, 1, "9adf79d4191b3d3c59cf3e23c9b432545ace12c0bf7cfdf9380977ce970559cf")
addappid(1639614, 1, "57a0286cb5278d43ff8a9c4ad3514a49989715a282d4ab710d00f9cc1a700485")
addappid(1639615, 1, "e39a3dc4a4995586152dbc58bb7cfbe3eed905204b158e6890c7e5fbcecb8a0c")
addappid(1695230, 0, "d4d19e1538adf553c63d14298276ab5ecb50ed3a5fcd835a7db7317097a0a274")
