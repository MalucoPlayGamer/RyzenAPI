-- Lua provided by RyzenAPI
-- Game: 1816130

-- MAIN APPLICATION
addappid(1816130)
-- Game: addappid(1816130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816131, 1, "5f700e6a4d70be2ee729da643b94999b904e6c7c081f616c8bbe0f7dee37a9f6")
