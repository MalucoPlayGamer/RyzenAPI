-- Lua provided by RyzenAPI
-- Game: Chop Chop Inc.

-- MAIN APPLICATION
addappid(5052310)
-- addappid(4369132) -- Depot 4369132 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4369130, 1, "f214b7e94601bf26e0bcce43600eb019d95941bea8dec04843112ed76aac84d0") -- Chop Chop Inc.
addappid(4369131, 1, "3e363585ccb4ee65a0c41048ffca621b28fa4b00e41e044dcc34e117cf8367e4") -- Depot 4369131
addappid(5052311, 1, "7a3a8c8840e7ef7dcbae43e47af1f55d210f5734add52380de923e54d64b8edf") -- Chop Chop Inc. - Ducks, Dollars and Dark Beginnings (Short Story) - Depot 5052311

