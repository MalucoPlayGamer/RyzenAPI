-- 4369130's Lua and Manifest Created by Hubcap Manifest
-- Chop Chop Inc.
-- Created: August 07, 2026 at 11:39:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4369130, 1, "f214b7e94601bf26e0bcce43600eb019d95941bea8dec04843112ed76aac84d0") -- Chop Chop Inc.
-- MAIN APP DEPOTS
addappid(4369131, 1, "3e363585ccb4ee65a0c41048ffca621b28fa4b00e41e044dcc34e117cf8367e4") -- Depot 4369131
setManifestid(4369131, "5170176920105918272", 2711657541)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4369132) -- Depot 4369132 (empty depot)