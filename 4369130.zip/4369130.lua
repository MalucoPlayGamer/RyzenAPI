-- 4369130's Lua and Manifest Created by Hubcap Manifest
-- Chop Chop Inc.
-- Created: August 13, 2026 at 07:39:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4369130, 1, "f214b7e94601bf26e0bcce43600eb019d95941bea8dec04843112ed76aac84d0") -- Chop Chop Inc.
-- MAIN APP DEPOTS
addappid(4369131, 1, "3e363585ccb4ee65a0c41048ffca621b28fa4b00e41e044dcc34e117cf8367e4") -- Depot 4369131
setManifestid(4369131, "3513581809315454574", 2711739534)
-- DLCS WITH DEDICATED DEPOTS
-- Chop Chop Inc. - Ducks, Dollars and Dark Beginnings (Short Story) (AppID: 5052310)
addappid(5052310)
addappid(5052311, 1, "7a3a8c8840e7ef7dcbae43e47af1f55d210f5734add52380de923e54d64b8edf") -- Chop Chop Inc. - Ducks, Dollars and Dark Beginnings (Short Story) - Depot 5052311
setManifestid(5052311, "7850932473246094644", 7309970)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4369132) -- Depot 4369132 (empty depot)