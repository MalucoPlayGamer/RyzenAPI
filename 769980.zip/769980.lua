-- Lua provided by RyzenAPI
-- Game: AppID 769980

-- MAIN APPLICATION
addappid(769980)

-- MAIN APP DEPOTS / PACKAGES
addappid(769981, 1, "22addf527040761e0edae106d3d131431309dae6e3e5140d9efde24a3ce95084")

