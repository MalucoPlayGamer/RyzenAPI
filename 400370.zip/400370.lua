-- Lua provided by RyzenAPI
-- Game: Normality

-- MAIN APPLICATION
addappid(400370)
-- Game: addappid(400370)

-- MAIN APP DEPOTS / PACKAGES
addappid(400371, 1, "ad2219feb913b903c2fc6c87eedd5abf2ba551139bf4b618e7d8c620a535d573")
