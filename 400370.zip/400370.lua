-- Lua provided by SkyAPI 
-- Game: Normality
addappid(400370)
addappid(400371, 1, "ad2219feb913b903c2fc6c87eedd5abf2ba551139bf4b618e7d8c620a535d573")
