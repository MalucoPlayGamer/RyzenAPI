-- Lua provided by RyzenAPI
-- Game: Game: Rhythm Brawl

-- MAIN APPLICATION
addappid(1729900)
addappid(1734690)
-- Game: addappid(1729900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729901, 1, "cb5ac3880232b885f766450b0cc65d0a4d743f89dc9bc2db46b4728c79c67e96")
