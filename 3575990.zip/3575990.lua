-- Lua provided by RyzenAPI
-- Game: 3575990

-- MAIN APPLICATION
addappid(3575990)
-- Game: addappid(3575990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575991, 1, "4ee5a84796eba27ff74e5d1037d6d81da81b887ab7fe284ff80a27a398610568")
