-- Lua provided by RyzenAPI
-- Game: addappid(1625070)

-- MAIN APPLICATION
addappid(1625070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625071, 1, "c11128764dc30ec97e76d7c3414f27f63fbee712cf43aa445a61b07133a791b9")
