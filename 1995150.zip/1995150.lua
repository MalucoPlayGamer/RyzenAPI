-- Lua provided by RyzenAPI
-- Game: Jerry Wanker and the Quest to get Laid Demo

-- MAIN APPLICATION
addappid(1995150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995151, 1, "f6bea58845bbd47058ef01bf3f57ab66ba39b0f24f18a9ec23627b70c474f60a")

