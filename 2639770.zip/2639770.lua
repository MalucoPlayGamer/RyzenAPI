-- Lua provided by RyzenAPI
-- Game: Bad Guys Good Boys

-- MAIN APPLICATION
addappid(2639770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639771,0,"8b0f3f880b11bccde9f5c3bc48910edd87c4030f27c5625eb4bd2786f976197e")

