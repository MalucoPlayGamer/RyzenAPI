-- Lua provided by RyzenAPI
-- Game: Game: Hentai Tales: Sex Apartment

-- MAIN APPLICATION
addappid(2674930)
-- Game: addappid(2674930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674931, 1, "4cad1ea2105c9a1188c1410c49ef06473c1c3dbcdc118fef825a5000f504548c")
