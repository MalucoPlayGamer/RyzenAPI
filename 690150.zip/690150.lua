-- Lua provided by RyzenAPI
-- Game: Fossil Hunters

-- MAIN APPLICATION
addappid(690150)

-- MAIN APP DEPOTS / PACKAGES
addappid(690151,0,"ab234c09e1ae48415bb85fef58a8719cd6ca4270692362face5f623ce782f945")

