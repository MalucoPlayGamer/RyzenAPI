-- Lua provided by RyzenAPI 
-- Game: AppID 3133750
addappid(3133750)
addappid(3133751, 1, "905fa8f5d8cd963f8eabaec9efccc4feaa6417e49621b1bf3563028935edf670")
