-- Lua provided by RyzenAPI
-- Game: Amaranthine Voyage: The Shadow of Torment Collector's Edition

-- MAIN APPLICATION
addappid(796080)

-- MAIN APP DEPOTS / PACKAGES
addappid(796081,0,"307003fc479435b0c670f270f05103b67ac93eee168bc5d5f96f7cddde616b0b")

