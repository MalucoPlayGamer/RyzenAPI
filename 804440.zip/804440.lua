-- Lua provided by RyzenAPI
-- Game: 804440

-- MAIN APPLICATION
addappid(804440)
addappid(806420)
-- Game: addappid(804440)

-- MAIN APP DEPOTS / PACKAGES
addappid(804441, 1, "f60caf902fc6dccc512083ea8de986c9fc3b3c63de32fd02ce83eb8d5f88afb4")
