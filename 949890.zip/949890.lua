-- Lua provided by RyzenAPI
-- Game: Game: Physical Exorcism: Case 01

-- MAIN APPLICATION
addappid(949890)
-- Game: addappid(949890)

-- MAIN APP DEPOTS / PACKAGES
addappid(949891, 1, "41e6a7ac4b484b782a1cef463570139f31d32e51424941b813bafc3085a05ed2")
addappid(949892, 1, "0e26ae98a3d70f78d5665018572c3e8fff4c3c3a330a4145e31c7764e2105a21")
