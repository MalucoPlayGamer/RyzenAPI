-- Lua provided by RyzenAPI 
-- Game: 问道仙途2
addappid(1805490)
addappid(1805491, 1, "6c708ec01c15c07d1269a375c8f6cc9b435054fa1c6b00bb2b6f738571442625")
