-- Lua provided by RyzenAPI
-- Game: Steel Rain

-- MAIN APPLICATION
addappid(387240)
addappid(672800)
addappid(672810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(387241, 1, "ec400b4070505fc34f44b539d11bc3a834e1d78d074eb00b984e7cca97ef6cdb")
addappid(387242, 1, "876ea6514fd4d5dda84f6acc90c40cc980965d44f5e4ef3dbb9086266d24d83e")

