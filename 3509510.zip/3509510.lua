-- Lua provided by RyzenAPI
-- Game: 3509510

-- MAIN APPLICATION
addappid(3509510)
-- Game: addappid(3509510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3509511, 1, "cfb18fe9128aad2d9bde18892739c533fef396cc618fb272b98bffe16b92dbd9")
