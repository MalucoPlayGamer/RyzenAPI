-- Lua provided by RyzenAPI
-- Game: Survivor of Eschewal

-- MAIN APPLICATION
addappid(738260)
-- Game: addappid(738260)

-- MAIN APP DEPOTS / PACKAGES
addappid(738261, 1, "17cfb1027fdcd9ca39b75436529c29c6fe28dca800be7e120fc0d1dec8938893")
