-- Lua provided by RyzenAPI
-- Game: X4: Cradle of Humanity Soundtrack

-- MAIN APPLICATION
addappid(1288490)
-- Game: addappid(1288490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288491, 1, "70bffd1e69bc22fa2799082f19aa9842897134e77cb4c638a7d58f9c85d229f5")
addappid(1288492, 1, "d954c2f54eecf2b70510a591ff7febf5624d187a16175f7b62ba67a92c2a3996")
