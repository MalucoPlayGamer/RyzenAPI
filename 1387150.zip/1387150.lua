-- Lua provided by RyzenAPI
-- Game: A Case of the Crabs: Rehash

-- MAIN APPLICATION
addappid(1387150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387151, 1, "f712767b834ba38cfb65f400d8ee741ca0155584f86d368c31b4f5c9b157c4a5")
