-- Lua provided by SkyAPI 
-- Game: Model Eight
addappid(2362480)
addappid(2362481, 1, "38e0850c966f053452e7cf94e4916ef3e68858071c6307dda54fc84bd9acc29e")
