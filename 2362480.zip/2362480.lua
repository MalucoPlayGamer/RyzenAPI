-- Lua provided by RyzenAPI
-- Game: 2362480

-- MAIN APPLICATION
addappid(2362480)
-- Game: addappid(2362480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362481, 1, "38e0850c966f053452e7cf94e4916ef3e68858071c6307dda54fc84bd9acc29e")
