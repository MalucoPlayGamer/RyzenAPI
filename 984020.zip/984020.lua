-- Lua provided by RyzenAPI
-- Game: Super Ninja Meow Cat

-- MAIN APPLICATION
addappid(984020)

-- MAIN APP DEPOTS / PACKAGES
addappid(984023,0,"d3333bebde991545d37f76a8190c321e71dafbcc6116771aa268d990c80ab8d7")

