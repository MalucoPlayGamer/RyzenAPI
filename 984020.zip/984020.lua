-- Lua provided by RyzenAPI
-- Game: setManifestid(984023,"5707906692229474734")

-- MAIN APPLICATION
addappid(984020)
-- Game: addappid(984020)

-- MAIN APP DEPOTS / PACKAGES
addappid(984023,0,"d3333bebde991545d37f76a8190c321e71dafbcc6116771aa268d990c80ab8d7")
