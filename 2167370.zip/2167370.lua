-- Lua provided by RyzenAPI
-- Game: 克瑞因的纷争艺术设定集 - Criminal Dissidia Art Book

-- MAIN APPLICATION
addappid(2167370)
-- Game: addappid(2167370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167370,0,"b3221c429aa257d73a6ad7a623546d272820e277516476d8bf9b51e5c72d47de")
