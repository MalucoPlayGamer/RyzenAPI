-- Lua provided by RyzenAPI
-- Game: Epic Battle Simulator 2

-- MAIN APPLICATION
addappid(711570)

-- MAIN APP DEPOTS / PACKAGES
addappid(711571, 1, "a251c0ecf4282bfa6d8e829b7fddb34c18e7e9adfb859881331c7a382516256b")
addappid(711572, 1, "f55917c55c7fb8de95d1523ebd63505b5a1f18a7576440eeb160077c3b7ccea1")
addappid(711573, 1, "64fdeff0686bb08a1a26a8f2d16e899c1f1dcb028253e1a8ed1655645943ecee")
