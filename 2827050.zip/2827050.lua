-- Lua provided by RyzenAPI
-- Game: Project Frontier Playtest

-- MAIN APPLICATION
addappid(2827050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827051, 1, "187d8741b471ce9fc295ff75d63d22c77258e4199ad29fce384098c94e3f97cd")

