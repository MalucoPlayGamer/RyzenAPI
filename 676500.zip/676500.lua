-- Lua provided by RyzenAPI
-- Game: 676500

-- MAIN APPLICATION
addappid(676500)
-- Game: addappid(676500)

-- MAIN APP DEPOTS / PACKAGES
addappid(676501, 1, "2f77cf7fb18cf6e1b5bc82722d679cac862f94708de3dde300c7e29bcaf05309")
