-- Lua provided by SkyAPI 
-- Game: Steep Slopes
addappid(1543760)
addappid(1543761, 1, "04b0419ef9884642eed05940d7db76898ca4f8b6c083a0d625e8a2ead335ff56")
