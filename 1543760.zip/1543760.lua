-- Lua provided by RyzenAPI
-- Game: addappid(1543760)

-- MAIN APPLICATION
addappid(1543760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543761, 1, "04b0419ef9884642eed05940d7db76898ca4f8b6c083a0d625e8a2ead335ff56")
