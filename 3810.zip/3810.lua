-- Lua provided by RyzenAPI
-- Game: Game: BloodRayne (Legacy)

-- MAIN APPLICATION
addappid(3810)
-- Game: addappid(3810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3811, 1, "3a818a8e22dbde320d2036c9b2155767929f631cf05719a02a449dc677445e3f")
