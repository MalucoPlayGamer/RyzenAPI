-- Lua provided by RyzenAPI
-- Game: Beat Saber - Daft Punk - "Harder, Better, Faster, Stronger"

-- MAIN APPLICATION
addappid(2838270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838270,0,"9ad8257af0ff2ff95186115329a8a9a2cff2aed2e0fc96e823c203a464a39909")

