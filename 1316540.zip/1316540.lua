-- Lua provided by RyzenAPI
-- Game: Neglected OST

-- MAIN APPLICATION
addappid(1316540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316541, 1, "5f9866fea8b08cb17ce4a8a37e2cdab332130c68522e3fdb402e3c15daab12df")

