-- Lua provided by SkyAPI 
-- Game: KILLA Demo
addappid(2601570)
addappid(2601571, 1, "5705bece8d4c18f8f4ec12ab4382ebe8f4ad056e84f735cd2814f23d9fed07fa")
