-- Lua provided by RyzenAPI
-- Game: Vyanka's Memories

-- MAIN APPLICATION
addappid(3115150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115151,0,"e3b7ad0cf42f101175b396a3e9c03119df0341b35dd7e7dbf35603ad273efe1a")

