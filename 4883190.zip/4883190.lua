-- Lua provided by RyzenAPI
-- Game: Escape from the Shadows

-- MAIN APPLICATION
addappid(4883190) -- Escape from the Shadows

-- MAIN APP DEPOTS / PACKAGES
addappid(4883191, 1, "373289c6004ade20adb4f5aab03fa73edeef8bbd683ba2ad5473ab5eaa32831e") -- Depot 4883191

