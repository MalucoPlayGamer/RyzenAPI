-- Lua provided by RyzenAPI
-- Game: addappid(2359520)

-- MAIN APPLICATION
addappid(228989)
addappid(2359520)
addappid(2359523)
addappid(2359524)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359522,0,"5c48859acff7daa4ca012c75b9be7767f643c50af2bdfd1b366d209258febaba")
