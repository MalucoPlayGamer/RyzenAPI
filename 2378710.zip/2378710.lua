-- Lua provided by RyzenAPI
-- Game: 2378710

-- MAIN APPLICATION
addappid(2378710)
-- Game: addappid(2378710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2378711, 1, "c2099dde0da5c23b06faaeb07de947d5271572b2d33fb4f5d1abc9adbc37db23")
