-- Lua provided by RyzenAPI
-- Game: Summoners War

-- MAIN APPLICATION
addappid(2426960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2426961, 1, "36212b96b54cb5c2e81406a73668db6b59d7252c187030dc1ed00e8205856721")

