-- Lua provided by RyzenAPI
-- Game: Summoners War

-- MAIN APPLICATION
addappid(2426960)
-- Game: addappid(2426960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426961, 1, "36212b96b54cb5c2e81406a73668db6b59d7252c187030dc1ed00e8205856721")
