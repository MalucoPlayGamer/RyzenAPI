-- Lua provided by RyzenAPI
-- Game: On The Verge II

-- MAIN APPLICATION
addappid(1106710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1106711, 1, "f643b5efc81b8b4ccc5cd19a3a4349b43d55661e7a36d92ddb20831c63054fd4")

