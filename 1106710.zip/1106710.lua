-- Lua provided by RyzenAPI
-- Game: 1106710

-- MAIN APPLICATION
addappid(1106710)
-- Game: addappid(1106710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106711, 1, "f643b5efc81b8b4ccc5cd19a3a4349b43d55661e7a36d92ddb20831c63054fd4")
