-- Lua provided by RyzenAPI
-- Game: 1630760

-- MAIN APPLICATION
addappid(1630760)
-- Game: addappid(1630760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630761, 1, "e4e9f8f93fa0b22424fbe32026bff20607053da240d7e5eef1aa1549c69a0ecd")
