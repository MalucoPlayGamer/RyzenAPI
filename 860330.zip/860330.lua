-- Lua provided by RyzenAPI
-- Game: Game: AppID 860330

-- MAIN APPLICATION
addappid(860330)
-- Game: addappid(860330)

-- MAIN APP DEPOTS / PACKAGES
addappid(860331, 1, "39fa7bb4333da3cfc0db85daa60e134c7c23d7b8173b867c877882a79b210d52")
