-- Lua provided by RyzenAPI
-- Game: AppID 860330

-- MAIN APPLICATION
addappid(860330)

-- MAIN APP DEPOTS / PACKAGES
addappid(860331, 1, "39fa7bb4333da3cfc0db85daa60e134c7c23d7b8173b867c877882a79b210d52")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
