-- Lua provided by RyzenAPI
-- Game: Game: AppID 497850

-- MAIN APPLICATION
addappid(497850)
-- Game: addappid(497850)

-- MAIN APP DEPOTS / PACKAGES
addappid(497851, 1, "3c6cb428251cd70c92e33432842e119ba160c246f3030cce6107d46a15ee8411")
