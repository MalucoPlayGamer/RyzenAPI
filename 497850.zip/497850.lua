-- Lua provided by RyzenAPI
-- Game: 8-Bit Hordes

-- MAIN APPLICATION
addappid(497850)
addappid(549620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(497851, 1, "3c6cb428251cd70c92e33432842e119ba160c246f3030cce6107d46a15ee8411")

