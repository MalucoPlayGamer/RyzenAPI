-- Lua provided by RyzenAPI
-- Game: Hellgineers

-- MAIN APPLICATION
addappid(2587030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587032,0,"0b08b41f0c6b0ec1169c0010fd807064dd8cbae4c24c778b7a88452b3d9e95c9")
addappid(2587033,0,"5840e3561689f9e53b5c374a553eee91ac46d6992dd05090de6fc60e2e70dbd7")

