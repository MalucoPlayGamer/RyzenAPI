-- Lua provided by RyzenAPI
-- Game: Dagon: by H. P. Lovecraft

-- MAIN APPLICATION
addappid(1481400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481401, 1, "5057fafc7747f766784e0ff378f7409b42369b3040a77e305927c845d26ea098")
