-- Lua provided by RyzenAPI
-- Game: Dagon: by H. P. Lovecraft

-- MAIN APPLICATION
addappid(1481400)
addappid(1722010)
addappid(1751590)
addappid(2291520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1481401, 1, "5057fafc7747f766784e0ff378f7409b42369b3040a77e305927c845d26ea098")

