-- Lua provided by RyzenAPI
-- Game: Backrooms Bodycam

-- MAIN APPLICATION
addappid(3746210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3746211, 1, "46483c64cc4d0e855a8a095b0d32da986a8403f833020b0fb8cb47e7b6e0e535")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
