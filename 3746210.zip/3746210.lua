-- Lua provided by RyzenAPI
-- Game: 3746210

-- MAIN APPLICATION
addappid(3746210)
-- Game: addappid(3746210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3746211, 1, "46483c64cc4d0e855a8a095b0d32da986a8403f833020b0fb8cb47e7b6e0e535")
