-- Lua provided by RyzenAPI
-- Game: Game: Outta This Kingdom

-- MAIN APPLICATION
addappid(1462780)
-- Game: addappid(1462780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462781, 1, "d16546a745ba972286fb651d2683000aabcf205240a6549276bdcc1747cc21a3")
addappid(1462782, 1, "41a051683fe759da3536b8a06811869625ffd556c8a52d30d4096df1af18fe4e")
