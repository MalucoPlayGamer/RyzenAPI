-- Lua provided by SkyAPI 
-- Game: AppID 791410
addappid(791410)
addappid(791411, 1, "b4ee2785a5358d421c085a36423c225d0ba73b58997bd6b331dc6986d5713aa4")
