-- Lua provided by RyzenAPI
-- Game: Game: Elite School Roof Club

-- MAIN APPLICATION
addappid(1929930)
-- Game: addappid(1929930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929931, 1, "03e465868e29aed798566600581eb532d86dfb574240305bdfa69e8dd8dc68af")
