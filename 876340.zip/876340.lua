-- Lua provided by RyzenAPI
-- Game: 876340

-- MAIN APPLICATION
addappid(876340)
-- Game: addappid(876340)

-- MAIN APP DEPOTS / PACKAGES
addappid(876341, 1, "0cdc5275ed314fa22254bd22d3b98a1e4b98629735ec0f1f7f593ea362146fc9")
