-- Lua provided by SkyAPI 
-- Game: AppID 2604970
addappid(2604970)
addappid(2604971, 1, "b0b4414d8ddaf1b86a43d252c94c44e30025ec431b91245fb731dc1423737a84")
