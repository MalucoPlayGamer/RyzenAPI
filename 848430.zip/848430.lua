-- Lua provided by RyzenAPI
-- Game: AppID 848430

-- MAIN APPLICATION
addappid(848430)

-- MAIN APP DEPOTS / PACKAGES
addappid(848431, 1, "9a45ab4c0ce6a07cc65cc487901171336f156b4f66bd41afcb2bc713c782693e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
