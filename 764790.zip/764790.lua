-- Lua provided by RyzenAPI
-- Game: AppID 764790

-- MAIN APPLICATION
addappid(764790)
-- Game: addappid(764790)

-- MAIN APP DEPOTS / PACKAGES
addappid(764791, 1, "480da7dfe193152a3538806b86d478f050cbfb16615492990c043b1926e5cd4d")
