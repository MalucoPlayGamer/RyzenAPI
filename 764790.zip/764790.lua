-- Lua provided by SkyAPI 
-- Game: AppID 764790
addappid(764790)
addappid(764791, 1, "480da7dfe193152a3538806b86d478f050cbfb16615492990c043b1926e5cd4d")
