-- Lua provided by RyzenAPI
-- Game: 3DMark 11

-- MAIN APPLICATION
addappid(205270)
addappid(228990)
addappid(229003)
-- Game: addappid(205270)

-- MAIN APP DEPOTS / PACKAGES
addappid(205271, 1, "ba70ce8d3d2ad57b7a5ef0fdf9fec360dc1b5a473bb8b2de5f57dd8e1edc1ab2")
