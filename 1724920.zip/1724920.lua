-- Lua provided by RyzenAPI
-- Game: Syberia: The World Before - Deluxe Edition Upgrade

-- MAIN APPLICATION
addappid(1724920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724921, 1, "9b9fa3dea670079c9417f1882f0f8602521438796f08a794073427b89968c149")

