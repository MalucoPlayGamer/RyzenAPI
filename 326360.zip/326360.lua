-- Lua provided by RyzenAPI
-- Game: Game: AppID 326360

-- MAIN APPLICATION
addappid(326360)
-- Game: addappid(326360)

-- MAIN APP DEPOTS / PACKAGES
addappid(326361, 1, "4204e81c2793587d05d6ab393864bc46474fc20e73146caa17f9762ad5e1199a")
addappid(326362, 1, "3c7e41daace6b77efdcc351050da12ea75081a496f6952730f5fc21b8a4362af")
addappid(326363, 1, "8874ba6e3f3ce68dc52b49396ff195f1d58bc8d274c2ee3e4f1bba21f1646c74")
