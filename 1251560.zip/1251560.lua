-- Lua provided by RyzenAPI
-- Game: Buck Bradley: Comic Adventure

-- MAIN APPLICATION
addappid(1251560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251561, 1, "026a7b14bf38c74d41932c57a37477595cbbd01be83fedf78cce5aee69ecc6d1")

