-- Lua provided by RyzenAPI
-- Game: Game: BAA! Never Stop Bleating Demo

-- MAIN APPLICATION
addappid(2977600)
-- Game: addappid(2977600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2977601, 1, "d744346f55cb244aade0b9a49580fef563283c4d4b75f4335b8e89a1f735b1b2")
