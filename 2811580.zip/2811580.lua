-- Lua provided by RyzenAPI
-- Game: 文若九洲记：艳欲之乡

-- MAIN APPLICATION
addappid(2811580)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(2811581, 1, "9eb075dadb3931a36bc95f35da6174ecc7c775c270a25d5dde817a026511afa1")

