-- Lua provided by RyzenAPI
-- Game: 天行镖客 (Sky Escort)

-- MAIN APPLICATION
addappid(2428310)
-- Game: addappid(2428310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428311, 1, "24c4d67202389f2f6c2269a384ac0684c742879760f83dfcf132347ab3ac5e29")
