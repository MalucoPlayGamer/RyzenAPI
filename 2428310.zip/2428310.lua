-- Lua provided by RyzenAPI
-- Game: 天行镖客 (Sky Escort)

-- MAIN APPLICATION
addappid(2428310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(2428311, 1, "24c4d67202389f2f6c2269a384ac0684c742879760f83dfcf132347ab3ac5e29")

