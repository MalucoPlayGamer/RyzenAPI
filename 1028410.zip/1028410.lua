-- Lua provided by RyzenAPI
-- Game: AppID 1028410

-- MAIN APPLICATION
addappid(1028410)
-- Game: addappid(1028410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028411, 1, "d693408d35dd54f1911770ea2e885a76a7bc92dd704d4b4d7e80c953be911f11")
