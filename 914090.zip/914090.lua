-- Lua provided by RyzenAPI
-- Game: GIRAL

-- MAIN APPLICATION
addappid(914090)
-- Game: addappid(914090)

-- MAIN APP DEPOTS / PACKAGES
addappid(914091, 1, "e0298ca7921c42b887f0e9107d99267a1e09d73501cc1aaa52777fa395c453be")
