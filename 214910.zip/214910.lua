-- Lua provided by RyzenAPI
-- Game: addappid(214910)

-- MAIN APPLICATION
addappid(214910)

-- MAIN APP DEPOTS / PACKAGES
addappid(214911, 1, "a12b28bddda98ce27427254ce05f5dbcbda1c55223c40850feb3b3a42e831c89")
addappid(214912, 1, "1b5870ea230f95ee08d63da086c30881cb51d53720e3411a0b8c57bc3ed5cc70")
