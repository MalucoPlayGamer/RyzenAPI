-- Lua provided by RyzenAPI
-- Game: Yakuza Rogue EX: Officer Ayukawa Hikaru

-- MAIN APP DEPOTS / PACKAGES
addappid(4706950, 1, "d8d793233453a7e6b34cd6fe1c051198fbe782a527a0a3e401e8d662cbb7b2d1") -- Yakuza Rogue EX: Officer Ayukawa Hikaru
addappid(4706951, 1, "69cfff20d9d2aa1070d4e29215cb5bac9aa78227f23d64b7e766040af2734521") -- Depot 4706951

