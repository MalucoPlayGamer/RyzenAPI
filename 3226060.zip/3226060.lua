-- 3226060's Lua and Manifest Created by Hubcap Manifest
-- 梦境回响 DreamEcho
-- Created: August 11, 2026 at 13:07:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3226060) -- 梦境回响 DreamEcho
-- MAIN APP DEPOTS
addappid(3226061, 1, "db5d9e4559b50550e5d57576dd2e8bf48abdbc02456a3185ee74e9dc51207087") -- Depot 3226061
setManifestid(3226061, "8390088679001771460", 1921963203)