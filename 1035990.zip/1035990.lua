-- Lua provided by RyzenAPI 
-- Game: Dialtown: Phone Dating Sim
addappid(1035990)
addappid(1035991, 1, "78cffaa9205ac86a7f2dfb94727f96e3f2814a8aeb2c9831c185420774e64960")
