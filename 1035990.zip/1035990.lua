-- Lua provided by RyzenAPI
-- Game: Dialtown: Phone Dating Sim

-- MAIN APPLICATION
addappid(1035990)
addappid(3170530)
addappid(3598710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1035991, 1, "78cffaa9205ac86a7f2dfb94727f96e3f2814a8aeb2c9831c185420774e64960")

