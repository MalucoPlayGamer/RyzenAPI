-- Lua provided by RyzenAPI
-- Game: AppID 1796880

-- MAIN APPLICATION
addappid(1796880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796881, 1, "ed1fb360eed7a92ce6f3bb3a4e140b57e5f868ebb54c3a16fed66dc970c76020")

