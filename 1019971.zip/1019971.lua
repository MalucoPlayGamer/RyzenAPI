-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Li Dian "Knight Costume" / 李典「騎士風コスチューム」

-- MAIN APPLICATION
addappid(1019971)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019971,0,"0d4eebd735332052095d6f4781cbe24bc2b2a5831c0bc13d9a1aa7bdbd8817e3")
