-- Lua provided by RyzenAPI
-- Game: 1019971

-- MAIN APPLICATION
addappid(1019971)
-- Game: addappid(1019971)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019971,0,"0d4eebd735332052095d6f4781cbe24bc2b2a5831c0bc13d9a1aa7bdbd8817e3")
