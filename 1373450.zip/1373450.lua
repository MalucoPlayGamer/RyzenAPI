-- Lua provided by RyzenAPI
-- Game: Misplaced

-- MAIN APPLICATION
addappid(1373450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373451, 1, "7aa399bf89255b644947e4af84e416d03d1bc68b1fde8866ce8dd77026fef351")

