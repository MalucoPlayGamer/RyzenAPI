-- Lua provided by RyzenAPI
-- Game: Hot Hentai

-- MAIN APPLICATION
addappid(2012530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012531, 1, "aab3357573f48ee333daf50bc1f6b6b98092dd95735fac2a7ea9b11a2074a085")

