-- Lua provided by RyzenAPI
-- Game: Game: AppID 1161870

-- MAIN APPLICATION
addappid(1161870)
-- Game: addappid(1161870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161871, 1, "3b5bb1ccaa5784b49ae8a3e99ffb595f086d6cd431463998cda90f5e826d7c4c")
addappid(1227170, 0, "78eb1e62e670960676b840f2898f5f3901de14ee0537e4d1e41fb2eec3e1cf17")
