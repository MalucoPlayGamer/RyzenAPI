-- Lua provided by RyzenAPI
-- Game: addappid(2191490)

-- MAIN APPLICATION
addappid(2191490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191491, 1, "ad32657382022f4a70c660ea22d86f32e228ad429fa72fb8f14eacd2130169e4")
