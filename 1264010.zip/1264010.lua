-- Lua provided by RyzenAPI
-- Game: 9 Till Void

-- MAIN APPLICATION
addappid(1264010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264011, 1, "0b8aed9ceb29cd1c1e4652b64853089c0c8a13bb1088b420fbb4488c0a4fb4d8")

