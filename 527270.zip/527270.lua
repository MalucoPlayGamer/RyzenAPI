-- Lua provided by RyzenAPI
-- Game: Atelier Sophie: The Alchemist of the Mysterious Book

-- MAIN APPLICATION
addappid(527270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(527271, 1, "0b5da2cfbeae1d80d580f66b2d50625231e42d45589aa7e21a56fc2c86a3c74a")
