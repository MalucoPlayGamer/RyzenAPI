-- Lua provided by RyzenAPI
-- Game: TILT Demo

-- MAIN APPLICATION
addappid(3035050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3035051, 1, "d815c21a76541054a84ddf2e54996f9ccb07d8d8a44aa7ec0c9bbb2d01f13b34")

