-- Lua provided by RyzenAPI
-- Game: George VS Bonny PP Wars

-- MAIN APPLICATION
addappid(663830)

-- MAIN APP DEPOTS / PACKAGES
addappid(663831,0,"0cabe83e24eb1fa91f57d455214a0c69b2e484204a3d5bdb59e55d803140758e")

