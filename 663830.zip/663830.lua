-- Lua provided by RyzenAPI
-- Game: George VS Bonny PP Wars

-- MAIN APPLICATION
addappid(663830)

-- MAIN APP DEPOTS / PACKAGES
addappid(663831,0,"0cabe83e24eb1fa91f57d455214a0c69b2e484204a3d5bdb59e55d803140758e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
