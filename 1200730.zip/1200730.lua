-- Lua provided by RyzenAPI
-- Game: Shady Lewd Kart

-- MAIN APPLICATION
addappid(2900500) -- Wild Woody Character Pack
addappid(3579600) -- Pyramid Tits Character Pack
addappid(4105870) -- Butt Plug Blaster Character Pack
addappid(4191320) -- Shady Lewd Kart - Office Party GP Pack
addappid(4521350) -- Shady Lewd Kart - Track Cleaning Simulator 2026

-- MAIN APP DEPOTS / PACKAGES
addappid(1200730, 1, "99e072b6e74e544f6cc8455bdf69282bcd2e0215ee8de37d3d849f2481c06241") -- Shady Lewd Kart
addappid(1200731, 1, "c6eeaf71460de6f32a5461c7a38c28f7b66b196c5801007ea62c8141378d4c41") -- Shady Lewd Kart

