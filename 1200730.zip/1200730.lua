-- Lua provided by RyzenAPI
-- Game: AppID 1200730

-- MAIN APPLICATION
addappid(1200730)
-- Game: addappid(1200730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200731, 1, "c6eeaf71460de6f32a5461c7a38c28f7b66b196c5801007ea62c8141378d4c41")
