-- Lua provided by RyzenAPI
-- Game: addappid(1233900)

-- MAIN APPLICATION
addappid(1233900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233901, 1, "16e3c3dad430675ce96f2f59322ab963c0d562e1bb62d505c56b482dc895a386")
