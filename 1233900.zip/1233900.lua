-- Lua provided by RyzenAPI
-- Game: AppID 1233900

-- MAIN APPLICATION
addappid(1233900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1233901, 1, "16e3c3dad430675ce96f2f59322ab963c0d562e1bb62d505c56b482dc895a386")

