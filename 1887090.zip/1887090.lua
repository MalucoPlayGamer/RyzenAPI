-- Lua provided by RyzenAPI
-- Game: Athanasy Soundtrack

-- MAIN APPLICATION
addappid(1887090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887091, 1, "084d64b720d17724ad783511798598edc51d963c4d255b93a72c8eb7a0905a13")

