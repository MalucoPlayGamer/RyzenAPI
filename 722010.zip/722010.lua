-- Lua provided by RyzenAPI
-- Game: B A S E M E N T

-- MAIN APPLICATION
addappid(722010)

-- MAIN APP DEPOTS / PACKAGES
addappid(722011, 1, "2814417c50417d5fd174da63e741d2882d96da473b0060eec757234ffee51647")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
