-- Lua provided by RyzenAPI
-- Game: 722010

-- MAIN APPLICATION
addappid(722010)
-- Game: addappid(722010)

-- MAIN APP DEPOTS / PACKAGES
addappid(722011, 1, "2814417c50417d5fd174da63e741d2882d96da473b0060eec757234ffee51647")
