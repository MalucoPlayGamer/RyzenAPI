-- Lua provided by SkyAPI 
-- Game: Old Coin Pusher Friends
addappid(1722020)
addappid(1722021, 1, "4db8d2afcadc875ec7d8904b4c688b76a6a7b39dd2d157a1124bb662fa88268d")
