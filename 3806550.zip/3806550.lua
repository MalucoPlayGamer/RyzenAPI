-- Lua provided by RyzenAPI
-- Game: 101 Cats in Prague

-- MAIN APPLICATION
addappid(3806550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3806551, 1, "611dd4ede68a998b6e911da5ca7c5c04c68353031886c0027d685d7691da1cd1")
