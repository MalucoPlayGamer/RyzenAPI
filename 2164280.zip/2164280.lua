-- Lua provided by SkyAPI 
-- Game: Sorcerer Standoff
addappid(2164280)
addappid(2164281, 1, "d15b97e5ed5c1c8f249536130b9febb282be716f3934fd42ade15ab98f256b2a")
