-- Lua provided by RyzenAPI
-- Game: Sorcerer Standoff

-- MAIN APPLICATION
addappid(2164280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164281, 1, "d15b97e5ed5c1c8f249536130b9febb282be716f3934fd42ade15ab98f256b2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
