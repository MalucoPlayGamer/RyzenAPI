-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - FSM: Woods and Cave

-- MAIN APPLICATION
addappid(1441920)
-- Game: addappid(1441920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441920,0,"dd57a3864a5d6443ffbe0886105e3593939850556f69243b10f3048db663b955")
