-- Lua provided by RyzenAPI
-- Game: Big Bad Pharma

-- MAIN APPLICATION
addappid(4953610) -- Big Bad Pharma

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4953611, 1, "f19a0d1b56531b9b4a762a3fa58eb0ece4bc5a4afabd5573a8df96fca0dd76c2") -- Depot 4953611

