-- Lua provided by RyzenAPI
-- Game: TEVI Demo

-- MAIN APPLICATION
addappid(2320160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320161, 1, "5f1cc62b1b55482b6eb731da74806da86cc71bd05885fbc86931d809b9cb1064")

