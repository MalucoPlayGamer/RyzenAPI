-- Lua provided by RyzenAPI 
-- Game: The Apocalypse Sacrifice
addappid(2776600)
addappid(2776601, 1, "60b0a71361e15e7ac43088a140d19150d74bb50751830b3cc66694f5890179b5")
