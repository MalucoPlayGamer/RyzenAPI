-- Lua provided by RyzenAPI
-- Game: The Apocalypse Sacrifice

-- MAIN APPLICATION
addappid(2776600)
-- Game: addappid(2776600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776601, 1, "60b0a71361e15e7ac43088a140d19150d74bb50751830b3cc66694f5890179b5")
