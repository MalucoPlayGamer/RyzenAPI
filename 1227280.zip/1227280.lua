-- Lua provided by RyzenAPI
-- Game: Game: Despot's Game: Dystopian Battle Simulator

-- MAIN APPLICATION
addappid(1227280)
-- Game: addappid(1227280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227281, 1, "f6b8483daa9da8b2fca74a261f724862b1e09a920d884ef03160ffc9e1c8f47e")
addappid(1227282, 1, "7610180bde14d5f4665caa9491bf55f14799b599bfe8cf27f405d8ae4da477c0")
addappid(1227283, 1, "3b85d0e0a8ae0bbe91bd7dfa72f3eee65537ebe31f57b4ebd4412ee23f62dc0f")
addappid(2089800, 0, "9b6b37ef9629904d6ce5e579749a7ad0c95429eeee0368f8e4bce050f66338fb")
addappid(2089801, 0, "443a642e3574f91b8b8b8cbb0dc7f274430fbc1fc2439af753000720992d8fbd")
addappid(2089802, 0, "55a6ad9e5383911b47e3e2f53034a7428979a406c6e32911c3e008cd5391539c")
