-- Lua provided by RyzenAPI
-- Game: Constructor Plus

-- MAIN APPLICATION
addappid(898800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(898801, 1, "cb8092b4bcbe28d67182c662a64567065b79419ce15b7ed406e0e19871660d81")
addappid(898802, 1, "387cd5112fadf4208e5da4a7b253cbe1529c21dd8b912f8b34521fb4ff7a8ae1")

