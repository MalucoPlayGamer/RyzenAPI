-- Lua provided by RyzenAPI
-- Game: Game: Constructor Plus

-- MAIN APPLICATION
addappid(898800)
-- Game: addappid(898800)

-- MAIN APP DEPOTS / PACKAGES
addappid(898801, 1, "cb8092b4bcbe28d67182c662a64567065b79419ce15b7ed406e0e19871660d81")
addappid(898802, 1, "387cd5112fadf4208e5da4a7b253cbe1529c21dd8b912f8b34521fb4ff7a8ae1")
