-- Lua provided by RyzenAPI
-- Game: Die Young

-- MAIN APPLICATION
addappid(433170)
addappid(1171460)

-- MAIN APP DEPOTS / PACKAGES
addappid(433171, 1, "242f6d2a05bff4026030506b880de2971dbe2a02f4c9b1bec924a2f7f114706a")
addappid(973001, 1, "f5495b32b8499214fa455fe081b48d0e19cde21b44c1e0eece88969af2df675c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
