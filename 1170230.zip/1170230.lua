-- Lua provided by RyzenAPI
-- Game: 1170230

-- MAIN APPLICATION
addappid(1170230)
-- Game: addappid(1170230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170231, 1, "38a44e147b8b2a282ae00d6ee50e9456d63b5982eb6cf17710d7fc1f53bf4535")
