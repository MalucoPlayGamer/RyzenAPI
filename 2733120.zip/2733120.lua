-- Lua provided by RyzenAPI
-- Game: Game: A Wolf in Autumn Soundtrack

-- MAIN APPLICATION
addappid(2733120)
-- Game: addappid(2733120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733121, 1, "2bbeec1b504aa9f8817acf2c3211c700ad0c449bb52b0589071298d3ecd53c02")
