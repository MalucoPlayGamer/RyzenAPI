-- Lua provided by RyzenAPI
-- Game: Commie Killer 2069

-- MAIN APPLICATION
addappid(1508490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508491, 1, "b85a5737d8a0bac49f74a47c3fcd79eae3fc72a3761eb84160f02272428ff4f0")
