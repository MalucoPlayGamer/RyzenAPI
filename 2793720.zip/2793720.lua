-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2793720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793722,0,"6cebd3b3eadf536ce29020ed229d09d1a4161e00845ebce7b04953e7bc2036f8")

