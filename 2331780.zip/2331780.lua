-- Lua provided by RyzenAPI
-- Game: Push battle Royale

-- MAIN APPLICATION
addappid(2331780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331781, 1, "1e85ef059292c763481f08505ab7d5a446f9be04084eae76ce87da3e78e0734d")
