-- Lua provided by RyzenAPI
-- Game: Push battle Royale

-- MAIN APPLICATION
addappid(2331780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2331781, 1, "1e85ef059292c763481f08505ab7d5a446f9be04084eae76ce87da3e78e0734d")

