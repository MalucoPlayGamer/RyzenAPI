-- Lua provided by RyzenAPI
-- Game: addappid(2686720)

-- MAIN APPLICATION
addappid(2686720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686721, 1, "7b2855f9dbb413aad466bf70bbda5ba837317cbd64fc8f5916a5f24f5bcc7cd6")
