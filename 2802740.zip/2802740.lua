-- 2802740's Lua and Manifest Created by Hubcap Manifest
-- Heave Ho 2
-- Created: July 17, 2026 at 13:24:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2802740, 1, "882aeadbe5eb3b06647eaa8f9be92841df62a7a4cb815f9ff2f572d569b74ccc") -- Heave Ho 2
-- MAIN APP DEPOTS
addappid(2802741, 1, "1d791ebf9bb239893588e966e88b93d3f08eac26f5dbb2a315804fc66c9775fd") -- Depot 2802741
setManifestid(2802741, "1794586521527165935", 3883930234)