-- Lua provided by RyzenAPI
-- Game: Ricochet Abyss

-- MAIN APPLICATION
addappid(3084370) -- Ricochet Abyss

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3084371, 1, "0ad9879edf57c595d46116fb6f53140642b76bf381053bc22f734b738110d765") -- Depot 3084371

