-- Lua provided by RyzenAPI
-- Game: PlayForm: Human Dynamics

-- MAIN APPLICATION
addappid(1729300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729300,0,"32d3bdfde72197f5f30a5968866f11bfea003657648f8c146dbb1fd45cad2801")
addappid(1729301,0,"9910834e9b5f1d3bac390d7781903791165596aa7e0b0d20136afc95b4d2b862")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
