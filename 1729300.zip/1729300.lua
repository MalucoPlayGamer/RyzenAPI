-- Lua provided by RyzenAPI 
-- Game: PlayForm: Human Dynamics
addappid(1729300)
addappid(1729301, 1, "9910834e9b5f1d3bac390d7781903791165596aa7e0b0d20136afc95b4d2b862")
