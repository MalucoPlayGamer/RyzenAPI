-- Lua provided by RyzenAPI
-- Game: The InVincible Iron Ivy: Enter the Pretty, Pretty Princess

-- MAIN APPLICATION
addappid(2578220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578221, 1, "fec3a4577ee63586e629a74586efc9be4e6a262285a28974f64d0d9ba48bea36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
