-- Lua provided by RyzenAPI 
-- Game: Slikoban
addappid(1636910)
addappid(1636911, 1, "7faa3050a19acadb9eb89f2ce02c211344026a2038410734ae5607a8fe35e0d3")
