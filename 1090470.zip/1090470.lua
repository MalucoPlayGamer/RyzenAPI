-- Lua provided by RyzenAPI
-- Game: AppID 1090470

-- MAIN APPLICATION
addappid(1090470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090471, 1, "1b3dabdc0a268b05b17d46f9a233c335c78582775019f319188b06223faf4e29")
addappid(1090472, 1, "9c9144807fb3ea2f71d83f47232352753f2621c71b60040cf68dfb94e1cfd651")
addappid(1090474, 1, "71a4a8f3dcae121dbb805ee14991bf4d8a775cce3199788064ff2be29ea8f49c")
addappid(1090476, 1, "e003f7f1c831de5f90e14d069fb18e2fe76b1c4ad9919472be66bb4f1990028f")
addappid(1358500, 0, "1e41cf170b7e981658c0896ca950fc199a60bb4e54a6d9dfea975081d2412cbc")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1099380)
