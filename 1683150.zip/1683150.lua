-- Lua provided by RyzenAPI
-- Game: 1683150

-- MAIN APPLICATION
addappid(1683150)
-- Game: addappid(1683150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683151, 1, "a6213f68b5dd47f4f8e9e0252dfc6ff390dea9931c891b01fca20408efae3bb9")
