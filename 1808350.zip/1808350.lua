-- Lua provided by RyzenAPI
-- Game: addappid(1808350)

-- MAIN APPLICATION
addappid(1808350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808351, 1, "93cc34da2c8fba559bb73097633328dffe4c9dd2c6c727ff370c6eb069341588")
