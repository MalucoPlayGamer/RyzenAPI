-- Lua provided by RyzenAPI
-- Game: Slymes

-- MAIN APPLICATION
addappid(530300)

-- MAIN APP DEPOTS / PACKAGES
addappid(530301,0,"8a744fd62704db20800aefcc4192cc6b19ed82a09a5088b6f181cc09f7e8f523")

