-- Lua provided by RyzenAPI
-- Game: addappid(388990)

-- MAIN APPLICATION
addappid(388990)

-- MAIN APP DEPOTS / PACKAGES
addappid(388991, 1, "a29eba731dd4c2037cfe2054cc7b446581f9df28c0d007155b1e7171780263ec")
