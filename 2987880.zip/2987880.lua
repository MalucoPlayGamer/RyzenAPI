-- Lua provided by RyzenAPI
-- Game: addappid(2987880)

-- MAIN APPLICATION
addappid(2987880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987881, 1, "57332003daaf39d2416d48609ad052130d021dcedff96d9f52c3abaafb8f67d1")
