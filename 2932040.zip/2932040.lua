-- Lua provided by RyzenAPI
-- Game: 2.5 DIMENSIONAL SEDUCTION: Angels on Stage!

-- MAIN APPLICATION
addappid(2932040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2932041, 1, "d1fb5792d6a77535521cd036ebdae1d949404fd65771ccad0a220a5abcd5296d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
