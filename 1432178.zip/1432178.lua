-- Lua provided by RyzenAPI
-- Game: FUSER™ - Wu-Tang Clan - "Gravel Pit"

-- MAIN APPLICATION
addappid(1432178)
-- Game: addappid(1432178)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432178,0,"99c22a6945fbb6b4b5ef008139af652e9f7499daf47727e3878092751daece40")
