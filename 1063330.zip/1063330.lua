-- Lua provided by RyzenAPI
-- Game: addappid(1063330)

-- MAIN APPLICATION
addappid(1063330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063331, 1, "5f0e2189528ad74d3419c3cd457d8c96779a07b34cc8e54edbe1b6e697256aa7")
