-- Lua provided by RyzenAPI
-- Game: 麻神消消乐

-- MAIN APPLICATION
addappid(1063330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063331, 1, "5f0e2189528ad74d3419c3cd457d8c96779a07b34cc8e54edbe1b6e697256aa7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
