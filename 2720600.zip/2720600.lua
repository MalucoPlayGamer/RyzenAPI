-- Lua provided by RyzenAPI
-- Game: Game: Alpha League Playtest

-- MAIN APPLICATION
addappid(2720600)
-- Game: addappid(2720600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720601, 1, "36ff4eeed2aa7b36d4e07ee0b16ea977b8153ccfe1d5ccaf889dcadbdf3370d8")
