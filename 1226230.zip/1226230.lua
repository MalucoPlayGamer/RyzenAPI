-- Lua provided by RyzenAPI
-- Game: Game: Escape From The Grim

-- MAIN APPLICATION
addappid(1226230)
-- Game: addappid(1226230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226231, 1, "0c39d83f9435a9e3506eed883883ef4621c177c3c0b43c71312f11bbff4dddbc")
