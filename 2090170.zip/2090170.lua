-- Lua provided by RyzenAPI
-- Game: Abigor

-- MAIN APPLICATION
addappid(2090170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090171, 1, "0b7fc2a5d40fe638c2f2d1132f4319ca12fd079116c93eac0a758d8ac36cee81")
