-- Lua provided by SkyAPI 
-- Game: Alchemia: Creatio Ex Nihilo
addappid(1960330)
addappid(1960331, 1, "a8345c66244514c6a08f35eab4e30b728ab258c914887e1dc8c9e1d256c2978b")
