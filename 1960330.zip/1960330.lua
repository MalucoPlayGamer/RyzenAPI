-- Lua provided by RyzenAPI
-- Game: addappid(1960330)

-- MAIN APPLICATION
addappid(1960330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960331, 1, "a8345c66244514c6a08f35eab4e30b728ab258c914887e1dc8c9e1d256c2978b")
