-- Lua provided by RyzenAPI
-- Game: Chess Knights: Viking Lands

-- MAIN APPLICATION
addappid(1338980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338981, 1, "4f0df58243e41debd19c03de48396ad7e551264f96097dc4a5d5c68dbdde7f14")

