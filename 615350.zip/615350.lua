-- Lua provided by RyzenAPI
-- Game: Scarlett Mysteries: Cursed Child

-- MAIN APPLICATION
addappid(615350)

-- MAIN APP DEPOTS / PACKAGES
addappid(615351,0,"98b03caff949edc6cdc6d04e4b2ba6fc9a6d3c325e21a8f5e40eb7d417df47f7")
addappid(615352,0,"e77f799646e4796de996cbce0f6813d7cb7af1b1859769c2e7cba84f8dd66d43")
addappid(615353,0,"5bfd47ed26ed59d017bf304261e1d2711ba383b8dad86532d08f93df9829e1ef")

