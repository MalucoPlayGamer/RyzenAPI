-- Lua provided by RyzenAPI
-- Game: Farever

-- MAIN APPLICATION
addappid(3672400)
-- Game: addappid(3672400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3672401, 1, "73831a16cbfc579d84a852e8cbaf9f5a9d3a6b6060370bbd8763e9b0d2dea36a")
