-- Lua provided by RyzenAPI
-- Game: Anomaly Report

-- MAIN APPLICATION
addappid(3535830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3535831, 1, "edbb266f742bca095ee767520472a4c3ced0fd6e135bc6d6c943c2fa5ac82cc8")

