-- Lua provided by RyzenAPI 
-- Game: Anomaly Report
addappid(3535830)
addappid(3535831, 1, "edbb266f742bca095ee767520472a4c3ced0fd6e135bc6d6c943c2fa5ac82cc8")
