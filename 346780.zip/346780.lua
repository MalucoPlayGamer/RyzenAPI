-- Lua provided by RyzenAPI
-- Game: Luminosity

-- MAIN APPLICATION
addappid(346780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(346781, 1, "b287989a3898a77c936595d0fb4e37cf71dfdafeb891e1233cd120d74e09e7e8")

