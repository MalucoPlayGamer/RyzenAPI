-- Lua provided by RyzenAPI
-- Game: Luminosity

-- MAIN APPLICATION
addappid(346780)

-- MAIN APP DEPOTS / PACKAGES
addappid(346781, 1, "b287989a3898a77c936595d0fb4e37cf71dfdafeb891e1233cd120d74e09e7e8")
