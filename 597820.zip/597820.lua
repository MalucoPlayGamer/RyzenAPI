-- Lua provided by RyzenAPI
-- Game: AppID 597820

-- MAIN APPLICATION
addappid(597820)

-- MAIN APP DEPOTS / PACKAGES
addappid(597821, 1, "7717c3f61ba02868ba10112406e09176ec739560f33b596b23ddfb0ffd8f4077")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1549560)
