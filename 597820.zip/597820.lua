-- Lua provided by RyzenAPI
-- Game: 597820

-- MAIN APPLICATION
addappid(597820)
-- Game: addappid(597820)

-- MAIN APP DEPOTS / PACKAGES
addappid(597821, 1, "7717c3f61ba02868ba10112406e09176ec739560f33b596b23ddfb0ffd8f4077")
