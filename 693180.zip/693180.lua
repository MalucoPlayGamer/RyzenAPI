-- Lua provided by RyzenAPI 
-- Game: Slice of Life
addappid(693180)
addappid(693181, 1, "035e9eb0bbcb1447e2ec490f42e263fd4cfc2052e2250d5dde4d9d7b00dadb57")
