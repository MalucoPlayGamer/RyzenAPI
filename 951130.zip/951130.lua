-- Lua provided by RyzenAPI
-- Game: 心之檻

-- MAIN APPLICATION
addappid(951130)
-- Game: addappid(951130)

-- MAIN APP DEPOTS / PACKAGES
addappid(951131, 1, "3555e8b40173cec7d3f3c5997bbc15bae3979658352704c4b6880cb4c039dd2d")
