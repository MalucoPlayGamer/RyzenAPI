-- Lua provided by RyzenAPI
-- Game: Midnight Monitor: Aldercourt

-- MAIN APPLICATION
addappid(2843540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2843541, 1, "8e09a68a5862bb23db7b4bebe40f5ab7bfbdfb62f8c50401afce45603df9ccaa")

