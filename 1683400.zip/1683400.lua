-- Lua provided by RyzenAPI
-- Game: The Chronicles: Wasteland Assault

-- MAIN APPLICATION
addappid(1683400)
-- Game: addappid(1683400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683401, 1, "abbbd35ef49d68bafe3d7b0a3558f1148b6a59ab2a88a8a8b8065c6ca132502a")
