-- Lua provided by RyzenAPI
-- Game: 1861070

-- MAIN APPLICATION
addappid(1861070)
-- Game: addappid(1861070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861071, 1, "7af49817d347d1eceaa01fd2ab406e97ab81cc5ca7591566583953e3d58174ce")
