-- Lua provided by RyzenAPI 
-- Game: My Lovely Wife Original Soundtrack
addappid(1861070)
addappid(1861071, 1, "7af49817d347d1eceaa01fd2ab406e97ab81cc5ca7591566583953e3d58174ce")
