-- Lua provided by RyzenAPI
-- Game: Time Knight Adventures

-- MAIN APPLICATION
addappid(1651410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651411, 1, "5dd854213955dc34fe50d918df49d143dc65354503b0d5428c03af611f8629d3")

