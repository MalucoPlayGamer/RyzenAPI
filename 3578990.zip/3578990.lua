-- Lua provided by RyzenAPI
-- Game: Space Engineers 2 - Mod SDK

-- MAIN APPLICATION
addappid(3578990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3578991, 1, "36fa606c6e7fa3b73defdcde33c10a60fdbcb8dce6dab8195bf769c8345122bf")

