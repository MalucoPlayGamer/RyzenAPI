-- Lua provided by RyzenAPI
-- Game: Football Manager 2021 Touch

-- MAIN APPLICATION
addappid(1263860)
addappid(1436160)
addappid(1436161)
addappid(1436162)
addappid(1436163)
addappid(1436164)
addappid(1436165)
addappid(1436166)
addappid(1436167)
addappid(1436168)
addappid(1436169)
addappid(1436170)
addappid(1436171)
addappid(1436172)
addappid(1436173)
addappid(1436174)
addappid(1436175)
addappid(1436176)

-- MAIN APP DEPOTS / PACKAGES
addappid(1263861, 1, "7fe0f4da287a3ba203bf905844048e39723955a81a96c00113b0b2ed4fb79ab1")
addappid(1263862, 1, "719216290575048566057b9dbd71c0a12f8cac5491d12f83cf29bc3c3905a394")
addappid(1263863, 1, "46c48f4cea6b8334aa5504ba5ee39c8616e2cfbff70c0ce07922cb91b74ad19e")

