-- Lua provided by RyzenAPI
-- Game: Umichan Sorani

-- MAIN APPLICATION
addappid(1012330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012331, 1, "05b99ac1feceba563d00f994acec8b0060c3858382ce1f051da5fd66778ebae0")

