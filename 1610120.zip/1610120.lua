-- Lua provided by RyzenAPI
-- Game: 1610120

-- MAIN APPLICATION
addappid(1610120)
-- Game: addappid(1610120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610121, 1, "71ca223dec87837f6b60056aab238a1581498efd2079e77d9798bf9321f4ca5d")
