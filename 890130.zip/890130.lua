-- Lua provided by RyzenAPI
-- Game: Pawn of the Dead

-- MAIN APPLICATION
addappid(890130)

-- MAIN APP DEPOTS / PACKAGES
addappid(890131, 1, "19bb692fb88d20ff3ede84afea9726c4db673b71d68fa8b541378bfa170877d1")

