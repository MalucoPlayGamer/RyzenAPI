-- Lua provided by RyzenAPI
-- Game: addappid(649640)

-- MAIN APPLICATION
addappid(649640)

-- MAIN APP DEPOTS / PACKAGES
addappid(649641, 1, "9dbe47cc84b53d98672c7984cac899f0727e94f27ab0bc2da62d8fbfbcd88c65")
