-- Lua provided by RyzenAPI
-- Game: Ashes Cricket

-- MAIN APPLICATION
addappid(649640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(649641, 1, "9dbe47cc84b53d98672c7984cac899f0727e94f27ab0bc2da62d8fbfbcd88c65")
