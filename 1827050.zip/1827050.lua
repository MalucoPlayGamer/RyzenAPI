-- Lua provided by RyzenAPI
-- Game: Afterimage Kickstarter Backer Exclusive Demo

-- MAIN APPLICATION
addappid(1827050)
-- Game: addappid(1827050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827051, 1, "a01f676b56cbc1cb7623f91ce7010bd8ea1fec2c3fcc4bf997a3652be1d67365")
