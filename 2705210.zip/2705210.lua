-- Lua provided by RyzenAPI
-- Game: Good Kill!

-- MAIN APPLICATION
addappid(2705210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2705211, 1, "cd5dff7b8ed88730a8513ec1b773d101ea477e6c637b0d5644ca19afa32f3c45")

