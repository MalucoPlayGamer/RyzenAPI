-- Lua provided by RyzenAPI
-- Game: Good Kill!

-- MAIN APPLICATION
addappid(2705210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2705211, 1, "cd5dff7b8ed88730a8513ec1b773d101ea477e6c637b0d5644ca19afa32f3c45")
