-- Lua provided by RyzenAPI
-- Game: Pocky & Rocky Reshrined

-- MAIN APPLICATION
addappid(2200580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200581, 1, "096fd3a16673179fea6ccb3bb08a6ba3d3b4e1e681e1129ef6ec2c6bda37da7e")
