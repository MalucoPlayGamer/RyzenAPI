-- Lua provided by RyzenAPI
-- Game: addappid(3494930)

-- MAIN APPLICATION
addappid(3494930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3494931, 1, "c51f60ce6176394f93112f300ebad8e99f10b298dae202f8e398231f5040f77b")
