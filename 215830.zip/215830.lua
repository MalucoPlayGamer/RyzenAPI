-- Lua provided by RyzenAPI
-- Game: Closers

-- MAIN APPLICATION
addappid(215830)
addappid(747860)
addappid(747861)
addappid(747862)
addappid(747863)
addappid(789390)
addappid(789391)
addappid(789392)
addappid(789393)
addappid(820470)
addappid(969470)
addappid(969471)
addappid(1032460)
addappid(1032490)
addappid(1088210)
addappid(1088220)
addappid(1088230)
addappid(1093000)
addappid(1467050)
addappid(1467051)
addappid(1467052)
addappid(2430040)
addappid(2430041)
addappid(2430042)

-- MAIN APP DEPOTS / PACKAGES
addappid(215831, 1, "c1727334030146c751f5f0f8ba8179278993041d5e6e14b6a2158f558585520d")
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

