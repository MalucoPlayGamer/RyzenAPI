-- Lua provided by RyzenAPI
-- Game: Closers

-- MAIN APPLICATION
addappid(215830)
-- Game: addappid(215830)

-- MAIN APP DEPOTS / PACKAGES
addappid(215831, 1, "c1727334030146c751f5f0f8ba8179278993041d5e6e14b6a2158f558585520d")
