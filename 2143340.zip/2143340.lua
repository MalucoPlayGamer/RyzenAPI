-- Lua provided by RyzenAPI
-- Game: Dark Nights

-- MAIN APPLICATION
addappid(2143340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143341, 1, "e5135766af8c4702e82a6e6f4e13c2d4bfb5eddeec93f53287a4dcdab67ec368")
addappid(2143342, 1, "0c0b06829041e7529088774beaa6b550c928c6ed0e2b36591e6e56d7d59dcc7d")
