-- Lua provided by RyzenAPI
-- Game: Sam & Max 304: Beyond the Alley of the Dolls

-- MAIN APPLICATION
addappid(31250)

-- MAIN APP DEPOTS / PACKAGES
addappid(31251, 1, "afaa49087148361b114e41474691c4f89825b3da9c46dc29977fd3b778ed8b23")
addappid(31252, 1, "e45541f7d96cfb67373299cc72db848e402b97186c1e10df9dcd66e5d5723cf7")
