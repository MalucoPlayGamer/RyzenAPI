-- Lua provided by RyzenAPI
-- Game: Circle pong

-- MAIN APPLICATION
addappid(780440)

-- MAIN APP DEPOTS / PACKAGES
addappid(780441, 1, "e145956f811f5e16b3223ae6b91db04320c142076f427aeab5f06b1356a19f08")
