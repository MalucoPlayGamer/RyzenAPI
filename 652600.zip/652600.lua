-- Lua provided by RyzenAPI
-- Game: Descent - Silence of Mind

-- MAIN APPLICATION
addappid(652600)

-- MAIN APP DEPOTS / PACKAGES
addappid(652601, 1, "76c4aa7f4f6ef390e9b9cef30c8d5232a7ce17af26648f91d625d39f0aaafac3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
