-- Lua provided by RyzenAPI
-- Game: 2009390

-- MAIN APPLICATION
addappid(2009390)
-- Game: addappid(2009390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009391, 1, "cc5188a03e638478fa69de4582c51e620c50c5425ab5dccf1e15680a0b908a62")
