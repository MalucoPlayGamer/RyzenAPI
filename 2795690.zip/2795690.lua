-- Lua provided by RyzenAPI
-- Game: addappid(2795690)

-- MAIN APPLICATION
addappid(2795690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795690,0,"39aa2edad12db82b7e7fb9aebaa7bf3ee3a358339c76e332ee16eb5ad3ad5530")
