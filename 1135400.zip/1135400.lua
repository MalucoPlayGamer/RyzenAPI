-- Lua provided by RyzenAPI
-- Game: Captain fly and sexy students

-- MAIN APPLICATION
addappid(1135400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135401, 1, "5d8e12d2b722808288849128e801dfc6c8c6ff0431071395ef628a8c0554d0f6")

