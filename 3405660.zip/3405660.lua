-- Lua provided by RyzenAPI
-- Game: 3405660

-- MAIN APPLICATION
addappid(3405660)
-- Game: addappid(3405660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3405661, 1, "666e184dfc67bff8110a8a0cf15b264fafe3d8e43f6311549de75ca84fb246a4")
