-- Lua provided by RyzenAPI 
-- Game: AppID 3405660
addappid(3405660)
addappid(3405661, 1, "666e184dfc67bff8110a8a0cf15b264fafe3d8e43f6311549de75ca84fb246a4")
