-- Lua provided by RyzenAPI
-- Game: AppID 508200

-- MAIN APPLICATION
addappid(508200)
addappid(877110)
addappid(877120)

-- MAIN APP DEPOTS / PACKAGES
addappid(508201, 1, "7cbf36f8028ed68fb917aafbd6e6ada4b8ac7c73111a1ef13f4ee727bbe56c35")

