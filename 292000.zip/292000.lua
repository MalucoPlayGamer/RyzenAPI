-- Lua provided by RyzenAPI
-- Game: 292000

-- MAIN APPLICATION
addappid(292000)
-- Game: addappid(292000)

-- MAIN APP DEPOTS / PACKAGES
addappid(292001, 1, "2bb3dfcc7245e9a85e6adcb82c91257dfd6e3ca66bdc188476820020395cc812")
