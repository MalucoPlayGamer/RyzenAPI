-- Lua provided by RyzenAPI
-- Game: No More Room in Hell 2

-- MAIN APPLICATION
addappid(292000)
addappid(2089150)
addappid(4250540)
addappid(4250550)
addappid(4250630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(292001,0,"2bb3dfcc7245e9a85e6adcb82c91257dfd6e3ca66bdc188476820020395cc812")

