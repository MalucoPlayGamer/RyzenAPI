-- Lua provided by RyzenAPI
-- Game: No More Room in Hell 2

-- MAIN APPLICATION
addappid(292000)
addappid(4250540)
addappid(4250550)
addappid(4250630)

-- MAIN APP DEPOTS / PACKAGES
addappid(292001,0,"2bb3dfcc7245e9a85e6adcb82c91257dfd6e3ca66bdc188476820020395cc812")

