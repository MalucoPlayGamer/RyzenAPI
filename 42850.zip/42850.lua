-- Lua provided by RyzenAPI
-- Game: Arsenal of Democracy: A Hearts of Iron Game

-- MAIN APPLICATION
addappid(42850)
addappid(228986)
addappid(228987)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(42851, 1, "4b8a526f628b0fab63c94ef0999b33d54134bf1b0d3d16c1b253b1992dc300a4")
addappid(42852, 1, "5da3569a0145b901de9e277c16342d2f1eb0d7ce5a8bb9398a5be6b2ae78f89b")
addappid(42853, 1, "2356363440bf1d965a5882ae18ccd59db79126b4fc190a1a579edae5a7e7999c")
addappid(42854, 1, "d044e4409374241cc77ab3d7625a349461aa2554dff295286443c74fa4ebc955")
addappid(42855, 1, "993dc88ff2af0eeaf2dd75b574ff7d4791e390f2be54a8a7fdb3403ebab3fd40")
addappid(42856, 1, "07345aa33d2cdccb89ff3b0004652ed35fa15332bdfc33e61464e20e6f40ba2d")
addappid(42857, 1, "3df8a7c8c1f636adae592bbc4d5f2ccbf5d22138084bee8abf77023231a779b6")
