-- Lua provided by RyzenAPI
-- Game: Game: Dolphins-cyborgs and open space

-- MAIN APPLICATION
addappid(767170)
-- Game: addappid(767170)

-- MAIN APP DEPOTS / PACKAGES
addappid(767171, 1, "a1c1162e192327deccc453743beb7d5534d537ebd6c19daba2f0b5d0acaaf196")
