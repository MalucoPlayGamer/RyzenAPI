-- Lua provided by RyzenAPI
-- Game: Game: Corsairs Legacy - Pirate Action RPG & Sea Battles

-- MAIN APPLICATION
addappid(1594880)
addappid(2461620)
-- Game: addappid(1594880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594881, 1, "ebfe05cf0ade7af896bef16008d81c8c4a69ed3d2c66f0e18830d18ec6575053")
