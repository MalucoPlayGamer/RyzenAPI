-- Lua provided by RyzenAPI
-- Game: Before the Fall: FINAL FANTASY XIV Original Soundtrack

-- MAIN APPLICATION
addappid(3372250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372251, 1, "32b6fe84c9cc1b0f68156bd4c955afc916ff3a5eaef623fa80c70a5ae8808b84")

