-- Lua provided by RyzenAPI
-- Game: Game: Strange Investigations: Becoming Collector's Edition

-- MAIN APPLICATION
addappid(1709240)
-- Game: addappid(1709240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709241, 1, "c80a4a4754617e3be59e42bd18b55ad8b5305e86cf6475e4db476386ad5c865c")
