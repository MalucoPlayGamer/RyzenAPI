-- Lua provided by RyzenAPI
-- Game: Automobilista 2 Demo

-- MAIN APPLICATION
addappid(1786210)
-- Game: addappid(1786210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786211, 1, "910dbb5a03cbb696a22e640a498e5476c81167229e7e60862e73d17a96d50d17")
