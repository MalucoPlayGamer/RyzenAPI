-- Lua provided by RyzenAPI 
-- Game: Automobilista 2 Demo
addappid(1786210)
addappid(1786211, 1, "910dbb5a03cbb696a22e640a498e5476c81167229e7e60862e73d17a96d50d17")
