-- Lua provided by RyzenAPI
-- Game: Wordatro!

-- MAIN APPLICATION
addappid(3140120)
-- Game: addappid(3140120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140121, 1, "df6e1fda11bd93e0a2de262cfeab38173a1ad5da15bc9ee8f238550b63e5b91b")
