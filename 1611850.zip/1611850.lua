-- Lua provided by RyzenAPI
-- Game: Game: 提线木偶 The Marionette

-- MAIN APPLICATION
addappid(1611850)
-- Game: addappid(1611850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611851, 1, "37ed8065253601ed872b145795e4cb1128ed02404b90f91758375f9a110c1a4b")
