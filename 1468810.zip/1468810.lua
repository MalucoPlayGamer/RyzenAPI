-- Lua provided by RyzenAPI
-- Game: Game: 鬼谷八荒 Tale of Immortal

-- MAIN APPLICATION
addappid(1468810)
addappid(2408730)
-- Game: addappid(1468810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468811, 1, "57880f9288973b73552c08af505e7d3e21db84ff579c2b5d08a34f092f652349")
