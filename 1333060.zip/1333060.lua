-- Lua provided by RyzenAPI
-- Game: Game: AppID 1333060

-- MAIN APPLICATION
addappid(1333060)
-- Game: addappid(1333060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333061, 1, "e5dd3eed83714830c9ccb5edb86bb18558940732aa47c53ac85d853a45598252")
