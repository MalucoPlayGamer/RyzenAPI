-- Lua provided by RyzenAPI
-- Game: AppID 412730

-- MAIN APPLICATION
addappid(412730)

-- MAIN APP DEPOTS / PACKAGES
addappid(412731, 1, "2bb138fd1d734e4e4f8ab3d1663e4ce89c20fc5bd68e4b633b00af1530d7f6ea")
addappid(412732, 1, "d02af006c3a0aa2db84a11093f7fbb826ec6eff78c70fbb97e8aad4162184f0b")
addappid(412733, 1, "f2790ff05d74ad1af1de92a95294d50c8e3a63c4e0e9a3e9627189edd1c5ae4c")
addappid(412734, 1, "9c6563b3b8aa3e4c80da2e9adb6c21b1e8f69097667ba2f1e4e9f0769fe5eb62")
addappid(412735, 1, "5b66ce3c20e5297b6ca5a6c8f2543123165d985f9aebb1044417532ded81f33d")
addappid(412736, 1, "fb932f01423a36416e7c34d29c72d64e8752afbf264808ccfab4dd8036606cce")
addappid(412737, 1, "f5547dc4326456c1214db2e267eee067360418938d87059259f04bf8d6d1dc07")
addappid(412738, 1, "9509a479e192a10a289327be2e6b69ade5da60dc5f40a0d542b356fb36cb07ed")
addappid(412739, 1, "3c3948944af85da3050b958702c5fc092c3a881bd5dff99491a33f3e25fa6cc6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
