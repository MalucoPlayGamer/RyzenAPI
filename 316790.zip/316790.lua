-- Lua provided by RyzenAPI
-- Game: Grim Fandango Remastered

-- MAIN APPLICATION
addappid(316790)

-- MAIN APP DEPOTS / PACKAGES
addappid(316791, 1, "e86e0d6626592d0d4f03ae76a54ed90fb6dc2707e50425003e0ee67752920a26")
addappid(316792, 1, "e852795f2b05f6dfa952ab1a6a411a2dbff19f7c258ce198a8719355389b07c0")
addappid(316793, 1, "8af7a76bd341364ed0c9c7f4774d183e37159637acfc12bbe762b3ac276012bf")
addappid(316794, 1, "14d6c7dd468f6f6e5ae060f8d59e9e02d252e415652b3967ae56360fcbb77c24")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
