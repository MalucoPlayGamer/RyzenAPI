-- Lua provided by RyzenAPI
-- Game: Game: Pool 2D - Poolians

-- MAIN APPLICATION
addappid(891040)
-- Game: addappid(891040)

-- MAIN APP DEPOTS / PACKAGES
addappid(891041, 1, "70b157145d61363cbc19e66f527d242153ee065161e375de6b6e2ed7f4bb0cdf")
