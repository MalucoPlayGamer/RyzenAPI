-- Lua provided by RyzenAPI
-- Game: Workplace Fantasy - New Girl Chapter 2

-- MAIN APPLICATION
addappid(3606670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3606670,0,"a2182366192e13278c19aede58968a3cc78d42adb068881e240ee1996fd40274")
