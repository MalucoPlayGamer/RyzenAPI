-- Lua provided by RyzenAPI
-- Game: addappid(2836380)

-- MAIN APPLICATION
addappid(2836380)
addappid(2836381)

-- MAIN APP DEPOTS / PACKAGES
addappid(2836380,0,"afcef8c4f6c6668a3c749ac90fb0f169d79896bb44e69f06229cd93282385c3e")
