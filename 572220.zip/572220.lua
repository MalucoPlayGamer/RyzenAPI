-- Lua provided by SkyAPI 
-- Game: MageQuit
addappid(572220)
addappid(572221, 1, "d666b123427ef0dfbacdf6b3715a6bdc0cf4845b558f21b6d072ee6cc906ff0c")
addappid(572222, 1, "bf6abc2169f3910a776874fe55385fd3145c4e8513094efdc99d3b388a9a668f")
addappid(572223, 1, "2bcd1a93cb35d9622960ef9998ebb8a1592003f45de196aa925a0cbcf253057d")
