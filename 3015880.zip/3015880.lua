-- Lua provided by RyzenAPI
-- Game: AppID 3015880

-- MAIN APPLICATION
addappid(3015880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015881, 1, "b3670506c748b72a4e7f5c9948b8c5bcf0dec82d2ad48439035cbc02f9daa22c")
