-- Lua provided by RyzenAPI
-- Game: 1650200

-- MAIN APPLICATION
addappid(1650200)
-- Game: addappid(1650200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650201, 1, "b9a41f430b5d986dd4a616d03b923d4068c8d1abceed22426e864da87c16b42a")
