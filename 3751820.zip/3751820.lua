-- Lua provided by RyzenAPI
-- Game: RutMaker

-- MAIN APPLICATION
addappid(3751820) -- RutMaker

-- MAIN APP DEPOTS / PACKAGES
addappid(3751821, 1, "9e8e9091182992924fd5a25ace78a32b61b0c06ed52c6217ab9767ecdd85a415") -- Depot 3751821

