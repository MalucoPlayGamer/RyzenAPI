-- 3751820's Lua and Manifest Created by Hubcap Manifest
-- RutMaker
-- Created: August 01, 2026 at 00:01:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3751820) -- RutMaker
-- MAIN APP DEPOTS
addappid(3751821, 1, "9e8e9091182992924fd5a25ace78a32b61b0c06ed52c6217ab9767ecdd85a415") -- Depot 3751821
setManifestid(3751821, "5097050182499111668", 11706022334)