-- Lua provided by RyzenAPI
-- Game: Game: AppID 1991830

-- MAIN APPLICATION
addappid(1991830)
-- Game: addappid(1991830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991831, 1, "738327506385bcb2e14f9f666fccb6a53d45c0a7cd00d59bd5cc303ba8a2fed3")
