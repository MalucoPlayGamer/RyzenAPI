-- Lua provided by RyzenAPI
-- Game: 2007470

-- MAIN APPLICATION
addappid(2007470)
-- Game: addappid(2007470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2007471, 1, "4deda4a0f4cf718c25ff4c9ea4b72cf9e0136035bf3ee3f85c1b63ee2afbd671")
