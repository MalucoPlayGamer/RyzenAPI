-- Lua provided by RyzenAPI
-- Game: Dimension of Monster Girls

-- MAIN APPLICATION
addappid(812410)

-- MAIN APP DEPOTS / PACKAGES
addappid(812411,0,"24eabb74dabc12203793d9d311a64c1576cc017aad3378cb0be0672c51247d92")

