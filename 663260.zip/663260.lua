-- Lua provided by RyzenAPI
-- Game: Game: AppID 663260

-- MAIN APPLICATION
addappid(663260)
-- Game: addappid(663260)

-- MAIN APP DEPOTS / PACKAGES
addappid(663261, 1, "517e8bb7bb7db8d761119c4ff1edc6ec236f527789bcfeae0666ba640674924f")
