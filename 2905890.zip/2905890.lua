-- Lua provided by RyzenAPI
-- Game: Hidden Corgi Mansion

-- MAIN APPLICATION
addappid(2905890)
