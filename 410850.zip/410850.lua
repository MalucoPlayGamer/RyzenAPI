-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST HEROES™ Slime Edition

-- MAIN APPLICATION
addappid(410850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(410851, 1, "b4406d34ae2f77a89f0af9aea3b37670fe92166ad6abd0ff2cb194f175fbbeac")
addappid(419540, 0, "16d9268ad858dd2357beeb7a56742c767977ba2be79b3a225c77d10845d04b73")

