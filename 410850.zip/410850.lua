-- Lua provided by RyzenAPI
-- Game: addappid(410850)

-- MAIN APPLICATION
addappid(410850)

-- MAIN APP DEPOTS / PACKAGES
addappid(410851, 1, "b4406d34ae2f77a89f0af9aea3b37670fe92166ad6abd0ff2cb194f175fbbeac")
addappid(419540, 0, "16d9268ad858dd2357beeb7a56742c767977ba2be79b3a225c77d10845d04b73")
