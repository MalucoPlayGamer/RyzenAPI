-- Lua provided by RyzenAPI
-- Game: Trials of Innocence DEMO

-- MAIN APPLICATION
addappid(3162210)
-- Game: addappid(3162210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3162211, 1, "5dd8302a2c041a909b73a43abc2101f3f7721907f9a2b48c318d28d576395984")
