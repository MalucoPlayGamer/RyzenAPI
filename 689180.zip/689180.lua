-- Lua provided by RyzenAPI
-- Game: 689180

-- MAIN APPLICATION
addappid(689180)
-- Game: addappid(689180)

-- MAIN APP DEPOTS / PACKAGES
addappid(689181, 1, "2cf9d51df2e15791bf68fd7fb64c6c9cdaedddbbb766dcc01676a44a53c35776")
