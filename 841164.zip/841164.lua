-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Dortmund XP

-- MAIN APPLICATION
addappid(841164)
-- Game: addappid(841164)

-- MAIN APP DEPOTS / PACKAGES
addappid(841164,0,"901b093122eb73383f248c737515f7df10d016b011738d873b812a0c67268ff9")
