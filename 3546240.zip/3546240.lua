-- Lua provided by RyzenAPI
-- Game: Cirno's Card Class

-- MAIN APPLICATION
addappid(3546240)
-- Game: addappid(3546240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3546241, 1, "3be53f71993b362dfb07f9a24a1a2392ac26b4c17d28b8ff81a041eee63aba83")
