-- Lua provided by SkyAPI 
-- Game: Abstract
addappid(946070)
addappid(946071, 1, "2145a6c5e5c9dbc8482d3acd2014ac82dad4c71dc5775094b1914463cfd98be6")
