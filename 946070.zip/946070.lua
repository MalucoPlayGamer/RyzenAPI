-- Lua provided by RyzenAPI
-- Game: 946070

-- MAIN APPLICATION
addappid(946070)
-- Game: addappid(946070)

-- MAIN APP DEPOTS / PACKAGES
addappid(946071, 1, "2145a6c5e5c9dbc8482d3acd2014ac82dad4c71dc5775094b1914463cfd98be6")
