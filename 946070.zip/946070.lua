-- Lua provided by RyzenAPI
-- Game: Abstract

-- MAIN APPLICATION
addappid(946070)

-- MAIN APP DEPOTS / PACKAGES
addappid(946071, 1, "2145a6c5e5c9dbc8482d3acd2014ac82dad4c71dc5775094b1914463cfd98be6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
