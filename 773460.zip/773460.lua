-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(773460)

-- MAIN APP DEPOTS / PACKAGES
addappid(773462,0,"767ede30e0e56178091b7409a9a691b450ba8958cf18da543f52eec9a6c76946")
