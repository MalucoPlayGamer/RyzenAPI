-- Lua provided by RyzenAPI
-- Game: 25840

-- MAIN APPLICATION
addappid(25840)
-- Game: addappid(25840)

-- MAIN APP DEPOTS / PACKAGES
addappid(25841, 1, "145f9ef699b681410e1fea7390db251e9b61215934440ceba49d1286a940a3f5")
