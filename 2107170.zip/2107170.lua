-- Lua provided by RyzenAPI
-- Game: 2107170

-- MAIN APPLICATION
addappid(2107170)
-- Game: addappid(2107170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107171, 1, "6f3e72f8440a38934a6ad244792225f61acf72e83e8ae921089cc0d2761dccc1")
