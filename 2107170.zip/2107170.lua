-- Lua provided by RyzenAPI
-- Game: Beyond the Mountains

-- MAIN APPLICATION
addappid(2107170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107171, 1, "6f3e72f8440a38934a6ad244792225f61acf72e83e8ae921089cc0d2761dccc1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
