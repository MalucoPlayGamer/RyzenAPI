-- Lua provided by RyzenAPI
-- Game: addappid(3709910)

-- MAIN APPLICATION
addappid(3709910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3709910,0,"5b90b81daf1117be3b01456d01480bf4ef087bbf33dbee3db51b6771a1fad838")
