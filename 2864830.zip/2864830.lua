-- Lua provided by RyzenAPI 
-- Game: Legend of the Master Baiter
addappid(2864830)
addappid(2864831, 1, "6730b05338776ace8d3a6500f8a4aa6449dba074448aa85e1959b6c1114e0807")
addappid(2864832, 1, "73ae2150352279166e698dddb5057df3141ca744398f861f9d5902f466c2a07f")
addappid(2864833, 1, "ac8bd3c82f69966d04be0cfa8bb9df33d0d941d95533571e3a009bf405f0d244")
