-- Lua provided by RyzenAPI
-- Game: Game: AppID 1098870

-- MAIN APPLICATION
addappid(1098870)
-- Game: addappid(1098870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098871, 1, "eef8c2706a79e6aa353e67c5b16ff348da52d5f517a56dcb1ee62b8ccd9f7acb")
