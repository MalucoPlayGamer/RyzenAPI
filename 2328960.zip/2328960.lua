-- Lua provided by RyzenAPI
-- Game: Flappy Souls

-- MAIN APPLICATION
addappid(2328960)
addappid(3228410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328961, 1, "3008f63ffdefceddab1b7c9038e1a5c550e4558037ee1ebcb64c5de826648d7b")

