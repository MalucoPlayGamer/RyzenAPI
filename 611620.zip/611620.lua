-- Lua provided by RyzenAPI
-- Game: 611620

-- MAIN APPLICATION
addappid(611620)
addappid(797460)
-- Game: addappid(611620)

-- MAIN APP DEPOTS / PACKAGES
addappid(611621, 1, "de844e1a387d3fb7b8ecc4a281c9c9f9dad7f1bcea9deaa21ee098f5e6f2967a")
