-- Lua provided by RyzenAPI
-- Game: AppID 1568970

-- MAIN APPLICATION
addappid(1568970)
-- Game: addappid(1568970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568971, 1, "6e9ba79c7de2cb6b469ad51905fb2c4bd572efb3787f15e7ec90da8801296456")
