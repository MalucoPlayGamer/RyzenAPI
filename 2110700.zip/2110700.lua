-- Lua provided by RyzenAPI 
-- Game: Japanese goblins
addappid(2110700)
addappid(2110701, 1, "0242f4760657ad18205d4e0eca66efb551d344c1b4a0c45740a1ab870d230fe5")
