-- Lua provided by RyzenAPI
-- Game: Game: Tornado: Research and Rescue

-- MAIN APPLICATION
addappid(2250550)
-- Game: addappid(2250550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250551, 1, "1bdbb302876e30404ebac5adb97058551ae3fbb68decae32782f63eed738576b")
