-- Lua provided by RyzenAPI
-- Game: AppID 318300

-- MAIN APPLICATION
addappid(318300)

-- MAIN APP DEPOTS / PACKAGES
addappid(318301, 1, "67c36faa61b2c8776de38aaf7ee8f40ca793083c3a1a142af8c1f1d25058436d")

