-- Lua provided by RyzenAPI
-- Game: Deluded Mind

-- MAIN APPLICATION
addappid(786910)

-- MAIN APP DEPOTS / PACKAGES
addappid(786911, 1, "b82b2adb78d42856176c3743315947b21393f950abab88d71e253b5e707fa079")

