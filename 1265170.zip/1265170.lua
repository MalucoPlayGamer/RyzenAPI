-- Lua provided by RyzenAPI
-- Game: addappid(1265170)

-- MAIN APPLICATION
addappid(1265170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265171, 1, "56a90282dae646fcad4e8262ebbd42cdcd19fd0fc9eba260e02e8a93076040ef")
addappid(1265174, 1, "133e8a56cd1b32c1a6a7388600846f182adba460a5e42401aa4b085023e13d42")
