-- Lua provided by RyzenAPI
-- Game: addappid(16160)

-- MAIN APPLICATION
addappid(16160)

-- MAIN APP DEPOTS / PACKAGES
addappid(16161, 1, "20411f942d81024dc08af6ac10c15a9c481a7f5dae70dbbf98213b006f98f154")
