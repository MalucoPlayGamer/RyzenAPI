-- Lua provided by RyzenAPI
-- Game: Choices That Matter: And The Sun Went Out

-- MAIN APPLICATION
addappid(1343140)
-- Game: addappid(1343140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343141, 1, "ff0357c2fc2b9edc2a6f6da15ff54fd793580995a031adbb7bbc3e71aeb8de7d")
