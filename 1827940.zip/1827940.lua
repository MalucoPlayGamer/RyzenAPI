-- Lua provided by RyzenAPI
-- Game: Game: Last Lovers 绿洲之爱

-- MAIN APPLICATION
addappid(1827940)
-- Game: addappid(1827940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827941, 1, "3ba861ab7ed07b0f90daf7324729b861929435453e9de0e6cf54538736110df9")
