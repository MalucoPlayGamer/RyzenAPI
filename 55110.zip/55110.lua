-- Lua provided by RyzenAPI
-- Game: Red Faction®: Armageddon™

-- MAIN APPLICATION
addappid(55110)
addappid(55112)
addappid(55113)
addappid(55114)

-- MAIN APP DEPOTS / PACKAGES
addappid(55111, 1, "7e64d762ec828d0594d823fae1029b886e94e3aef7c50674e204ccd24d783acf")
addappid(55115, 1, "0d0080b3540d13f3068e09d21f3285690dea56c248b2424edfe6a0865a5046ac")
addappid(55116, 1, "3d907015f5f9b7e44d5ef93b5e4f4e704d27e8a0edb30a17f31e5e25fcca866e")

