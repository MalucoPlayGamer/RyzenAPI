-- Lua provided by RyzenAPI
-- Game: 1205280

-- MAIN APPLICATION
addappid(1205280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205284,0,"e032fe9e2476f4160c9bce3b72aa91c92a7afd72c2b87f45bcd617974e3ec78b")
