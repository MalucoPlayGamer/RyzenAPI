-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel

-- MAIN APPLICATION
addappid(1357860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357861, 1, "2e7a2be2be9a73d35661e3e791a48275d8a4435bf0cbf7b84eac87ca46a5ec5c")

