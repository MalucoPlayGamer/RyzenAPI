-- Lua provided by RyzenAPI
-- Game: Game: AppID 994890

-- MAIN APPLICATION
addappid(994890)
-- Game: addappid(994890)

-- MAIN APP DEPOTS / PACKAGES
addappid(994891, 1, "1eae813fce1fa8fde4840d8e8ddba76a65f3c8fd14450aeffee5d63d8fff6f29")
