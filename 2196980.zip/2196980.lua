-- Lua provided by RyzenAPI
-- Game: 2196980

-- MAIN APPLICATION
addappid(2196980)
-- Game: addappid(2196980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196985,0,"cfb9dc5de7d8c658a4f3badfa2066960d4be8cf0a7e3203cba276fb41bed567f")
addappid(2196988,0,"954bd6c26eb8c8ae8e14fa093e55d4578de0634379300280d8bad0eb593a64ca")
