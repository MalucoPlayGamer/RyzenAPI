-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(232330)
addappid(232336)
-- Game: addappid(232330)

-- MAIN APP DEPOTS / PACKAGES
addappid(232330,0,"1d68269caba773f1c7e195e1735615a4b3cc9d76aa61e53f2530e0dba282cdd2")
addappid(232335,0,"0ca67a38d65bdaa658464ac47284dcf3f1add9a618b8548edb1dbb5a346eb8fd")
