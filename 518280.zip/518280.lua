-- Lua provided by RyzenAPI
-- Game: Dead End Junction

-- MAIN APPLICATION
addappid(518280)

-- MAIN APP DEPOTS / PACKAGES
addappid(518281, 1, "9121e87c57baa1cde758533d6ed1fdc0cb0f1efff807f61c4b081302efb2d937")
