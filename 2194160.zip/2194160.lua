-- Lua provided by RyzenAPI
-- Game: Hentai CatMaid

-- MAIN APPLICATION
addappid(2194160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194161, 1, "0b57d98f0b0f441d7ab6f94c9fdfcce9d2e0ef4f6d89054d8a712d4bba0e4d71")

