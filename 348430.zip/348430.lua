-- Lua provided by RyzenAPI
-- Game: Quell Reflect

-- MAIN APPLICATION
addappid(348430)
-- Game: addappid(348430)

-- MAIN APP DEPOTS / PACKAGES
addappid(348431, 1, "366cb1deae7361743d893bcc9301769e37df25acc42a6914cff3205a3a047ee0")
