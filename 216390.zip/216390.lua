-- Lua provided by RyzenAPI
-- Game: 216390

-- MAIN APPLICATION
addappid(216390)
-- Game: addappid(216390)

-- MAIN APP DEPOTS / PACKAGES
addappid(216391, 1, "a3758d3d369248a98905deb2095070baeb737b2665870ee398c77e7da65033f8")
addappid(225700, 0, "c01df5ac7cfeae363f44b0d5060f2d8b2379dcc676b6b28c67bfb4b7abf11abb")
