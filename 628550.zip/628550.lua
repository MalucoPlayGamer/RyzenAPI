-- Lua provided by RyzenAPI
-- Game: Crypt Stalker

-- MAIN APPLICATION
addappid(628550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(628551, 1, "dc6a8140e229c5353db92f60728935dc3ad1e2536a6d50f4033bf933b65d4989")
