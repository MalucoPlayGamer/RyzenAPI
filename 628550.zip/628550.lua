-- Lua provided by SkyAPI 
-- Game: AppID 628550
addappid(628550)
addappid(628551, 1, "dc6a8140e229c5353db92f60728935dc3ad1e2536a6d50f4033bf933b65d4989")
