-- Lua provided by RyzenAPI
-- Game: Voice of Cards: The Beasts of Burden

-- MAIN APPLICATION
addappid(1890740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890741, 1, "7a28b456e7fd42bf011e44832326e307645bb667f96285eb45110f891fedcf11")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1924830)
addappid(1924831)
addappid(1924832)
addappid(1924833)
addappid(1924834)
addappid(1924835)
addappid(1924836)
addappid(1924837)
addappid(1924838)
addappid(1924839)
