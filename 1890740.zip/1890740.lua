-- Lua provided by RyzenAPI
-- Game: Voice of Cards: The Beasts of Burden

-- MAIN APPLICATION
addappid(1890740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890741, 1, "7a28b456e7fd42bf011e44832326e307645bb667f96285eb45110f891fedcf11")
