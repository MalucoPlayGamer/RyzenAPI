-- Lua provided by RyzenAPI
-- Game: Fat Prisoner Simulator 2

-- MAIN APPLICATION
addappid(1085270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085271, 1, "8446a3fbc8f6e8e05db641a9094e4088b129947a6f88964846fc2f807b5139f2")

