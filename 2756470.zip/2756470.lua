-- Lua provided by RyzenAPI
-- Game: 2756470

-- MAIN APPLICATION
addappid(2756470)
-- Game: addappid(2756470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756471, 1, "5ba2bf00c1275bc74220c82caf964146dbe6a97258a8ca6abe209da8fa626122")
