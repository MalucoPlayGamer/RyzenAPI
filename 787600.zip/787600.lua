-- Lua provided by RyzenAPI
-- Game: 787600

-- MAIN APPLICATION
addappid(787600)
-- Game: addappid(787600)

-- MAIN APP DEPOTS / PACKAGES
addappid(787601, 1, "ff76f9f0a4ff7922c4c28b8d6726cf67791c1558e5c7aafd390eaf8f0051fbf9")
