-- Lua provided by RyzenAPI
-- Game: 525450

-- MAIN APPLICATION
addappid(525450)
-- Game: addappid(525450)

-- MAIN APP DEPOTS / PACKAGES
addappid(525451, 1, "14743e798affe72cb18797bd5f4b9e0a9578637402a9db2ba8ee9b7e3b9eff2e")
