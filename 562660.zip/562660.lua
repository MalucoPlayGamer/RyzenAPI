-- Lua provided by RyzenAPI
-- Game: Pandarama: The Lost Toys

-- MAIN APPLICATION
addappid(562660)

-- MAIN APP DEPOTS / PACKAGES
addappid(562661, 1, "27ee7a73cc95bb910cc0abce92eb0b1986e1daa01ecea9f587132c21a52082c1")
