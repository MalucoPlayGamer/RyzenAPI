-- Lua provided by RyzenAPI
-- Game: Game: AppID 428930

-- MAIN APPLICATION
addappid(428930)
-- Game: addappid(428930)

-- MAIN APP DEPOTS / PACKAGES
addappid(428931, 1, "a569b27f2d44a4b839e0b813e594a2dcf59bc266128b97c6c3c70c31d284205b")
