-- Lua provided by RyzenAPI
-- Game: Into the Belly of the Beast

-- MAIN APPLICATION
addappid(428930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(428931, 1, "a569b27f2d44a4b839e0b813e594a2dcf59bc266128b97c6c3c70c31d284205b")

