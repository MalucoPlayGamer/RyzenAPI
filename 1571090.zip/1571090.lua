-- Lua provided by RyzenAPI
-- Game: BEAST CRIMES

-- MAIN APPLICATION
addappid(1571090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571091, 1, "a0bfc8950c12ba90a395bac811806504065f2ee26b69c8e37effd01049199f0a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2065850)
addappid(2192740)
