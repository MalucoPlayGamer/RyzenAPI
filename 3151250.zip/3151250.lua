-- Lua provided by RyzenAPI
-- Game: The Losers Team

-- MAIN APPLICATION
addappid(3151250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3151251, 1, "b32433b286f00b516ae6f4962052db8cd6e5b2708e1adc88e9aeabd6351c3763")

