-- Lua provided by SkyAPI 
-- Game: The Losers Team
addappid(3151250)
addappid(3151251, 1, "b32433b286f00b516ae6f4962052db8cd6e5b2708e1adc88e9aeabd6351c3763")
