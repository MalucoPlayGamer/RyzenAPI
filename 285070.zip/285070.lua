-- Lua provided by RyzenAPI
-- Game: Between Me and The Night

-- MAIN APPLICATION
addappid(285070)

-- MAIN APP DEPOTS / PACKAGES
addappid(285071, 1, "51c7c2137ec4a3869c1b34edadbae4c0525bfccee1399de7695ffca4bc8e7e61")
addappid(285072, 1, "84cf66e609f1d3237e3250b00dd2e79b31a7694e7eb7118f5cc4c92ae12663b1")
addappid(285073, 1, "c35812a314a00f8bc28edc875eb326c42dd2d7355dbf4b641a0bb0213ebfc7e7")
addappid(285074, 1, "4ca2c9d1dcca8cf833e4d3fefbb9b666b8d1123cab91317c31bd5b7afe31a712")
