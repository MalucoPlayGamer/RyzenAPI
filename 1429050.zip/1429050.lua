-- Lua provided by RyzenAPI
-- Game: 1429050

-- MAIN APPLICATION
addappid(1429050)
-- Game: addappid(1429050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429051, 1, "acd19a61da5761becd96c39b1ecef1c299d0fbbc59dd907a01e1cd56ab17aff9")
