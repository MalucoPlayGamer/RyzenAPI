-- Lua provided by RyzenAPI
-- Game: Game: Streets of Rogue Soundtrack

-- MAIN APPLICATION
addappid(594700)
-- Game: addappid(594700)

-- MAIN APP DEPOTS / PACKAGES
addappid(594701, 1, "ab5dc87872646aff5c4042ac6f0b95044e98a6850e58f2778fd9fa7a6b000255")
