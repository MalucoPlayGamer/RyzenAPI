-- Lua provided by SkyAPI 
-- Game: AppID 397690
addappid(397690)
addappid(397691, 1, "fbf1d84e125bb8719f3ea44152f61257bd3d060955c168ecad49f25ebd98296f")
