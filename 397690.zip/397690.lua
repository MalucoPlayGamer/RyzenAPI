-- Lua provided by RyzenAPI
-- Game: AppID 397690

-- MAIN APPLICATION
addappid(397690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(397691, 1, "fbf1d84e125bb8719f3ea44152f61257bd3d060955c168ecad49f25ebd98296f")

