-- Lua provided by RyzenAPI 
-- Game: 256vs256
addappid(2704120)
addappid(2704121, 1, "57aea684de5ffb3ae516b820dbc1fd3cd243396921c51e69dcde70fff7bada4c")
