-- Lua provided by SkyAPI 
-- Game: AppID 589450
addappid(589450)
addappid(589451, 1, "bb63f58611fbafa3b55618d3de9fc6b8d15baf6bf0ba8b752d0432941394c0a3")
