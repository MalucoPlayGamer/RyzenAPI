-- Lua provided by RyzenAPI
-- Game: Super Archer

-- MAIN APPLICATION
addappid(2439870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439871, 1, "2af15aa7644f679bb8ecf87eac8baf082d1f89c9b6a247044fd7f88e5b97f7ea")
