-- Lua provided by SkyAPI 
-- Game: Super Archer
addappid(2439870)
addappid(2439871, 1, "2af15aa7644f679bb8ecf87eac8baf082d1f89c9b6a247044fd7f88e5b97f7ea")
