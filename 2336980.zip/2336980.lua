-- Lua provided by RyzenAPI
-- Game: Enjoy the Diner

-- MAIN APPLICATION
addappid(2336980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336981, 1, "ec0d8dfce3e6ae48a1f04e6a09791bef453601f477d29e668435730efd8992b9")
