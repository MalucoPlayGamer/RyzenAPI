-- Lua provided by RyzenAPI
-- Game: AppID 2196700

-- MAIN APPLICATION
addappid(2196700)
-- Game: addappid(2196700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196701, 1, "dffecca66b9bc4efba890e2c8dbf4cef9e483686069805cda34f6fc80c254c8e")
