-- Lua provided by RyzenAPI
-- Game: 964580

-- MAIN APPLICATION
addappid(964580)
-- Game: addappid(964580)

-- MAIN APP DEPOTS / PACKAGES
addappid(964581, 1, "bfe5f4f1cd1fb40cf7be6a20aab6f64b8140dca762f75e1086a025b7c8e9225a")
