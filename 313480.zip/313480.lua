-- Lua provided by RyzenAPI
-- Game: Blitzkrieg Anthology

-- MAIN APPLICATION
addappid(313480)
-- Game: addappid(313480)

-- MAIN APP DEPOTS / PACKAGES
addappid(313481, 1, "fa22448830197efb76e505a074a62d398bfbe99413da8acb2a393f8370f0b83c")
addappid(313482, 1, "6c288ecb90c5a0c8c2201640924899aaa233368254d867312b018cec302d5918")
addappid(313483, 1, "85693680a39ffa11c5aa88e6073504617ab57c96258ebfdf68cae953ef2096d0")
