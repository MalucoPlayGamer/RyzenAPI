-- Lua provided by RyzenAPI
-- Game: Nice City

-- MAIN APPLICATION
addappid(4028160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4028161, 1, "e61b0dd2806b6396e2861bdabb5d269ba90cecc1a412ad36574a146d653c04b6")

