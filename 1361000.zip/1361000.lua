-- Lua provided by RyzenAPI 
-- Game: In Silence
addappid(1361000)
addappid(1361001, 1, "1a9fddf06e3691e9ffa213327290292e3d83919fbca1bdda8d7c6ae70e0792e1")
addappid(1361002, 1, "2f16f9b9c066aec5ee6895b836787cea628a73a0ea32857238b04b0afde9f0a0")
