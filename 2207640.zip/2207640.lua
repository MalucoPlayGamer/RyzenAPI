-- Lua provided by RyzenAPI
-- Game: Little Circuit

-- MAIN APP DEPOTS / PACKAGES
addappid(2207640, 1, "dae72582fe48a14185c8fe36d1b15821f276451e863633b07a5c4511b1206e5c") -- Little Circuit
addappid(2207641, 1, "98aa7bff5de2c4267ac676e66cd5cb9d86f44f5322bbd7f6bf1165f5a8480967") -- Depot 2207641

