-- 2207640's Lua and Manifest Created by Hubcap Manifest
-- Little Circuit
-- Created: August 01, 2026 at 05:07:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2207640, 1, "dae72582fe48a14185c8fe36d1b15821f276451e863633b07a5c4511b1206e5c") -- Little Circuit
-- MAIN APP DEPOTS
addappid(2207641, 1, "98aa7bff5de2c4267ac676e66cd5cb9d86f44f5322bbd7f6bf1165f5a8480967") -- Depot 2207641
setManifestid(2207641, "8625294858814395861", 133534173)