-- Lua provided by RyzenAPI
-- Game: Game: Mystery Trackers: Black Isle Collector's Edition

-- MAIN APPLICATION
addappid(926120)
-- Game: addappid(926120)

-- MAIN APP DEPOTS / PACKAGES
addappid(926121, 1, "2746f86db1531a39825fbf5d6d636ffcf3eeeb52d69cece48f194e157a04f7c8")
