-- Lua provided by SkyAPI 
-- Game: ClickCells: Summer
addappid(1495990)
addappid(1495991, 1, "7412952b37e3f35c7f603bbfeb507b3503db1fd11dae21baa6ef89dc9b93dcc0")
