-- Lua provided by RyzenAPI
-- Game: Beat Saber - Dr Dre - "Nuthin’ But A “G” Thang"

-- MAIN APPLICATION
addappid(2893490)
-- Game: addappid(2893490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893490,0,"cd74752e9ddeff1ec25e137ab72305528f4d03e6cfd617e8cd9b0e95f6365ccd")
