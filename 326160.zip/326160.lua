-- Lua provided by RyzenAPI
-- Game: Shroud of the Avatar: Forsaken Virtues

-- MAIN APPLICATION
addappid(326160)

-- MAIN APP DEPOTS / PACKAGES
addappid(326161, 1, "38c70d38dff5376f62b24ad496895cf59f5d6712bb72780e5359fa16fc011efa")
addappid(326162, 1, "cce071863edc4bfec125442bac66ee96a0345232a09cb4709665016947776ffe")
addappid(326163, 1, "f4915d4fd093a1da532855e54087f918b1e6bf0ed2514b72766a587976a612d4")
