-- Lua provided by RyzenAPI
-- Game: 3057500

-- MAIN APPLICATION
addappid(3057500)
-- Game: addappid(3057500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057500,0,"4343c0d630c8eded1acaa32860e412905537e3c0ce314ecc22b2bbc6f578e32d")
