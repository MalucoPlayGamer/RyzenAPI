-- Lua provided by RyzenAPI
-- Game: Game: 你农哦农-Need Know What Know

-- MAIN APPLICATION
addappid(2150870)
-- Game: addappid(2150870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150871, 1, "aeceb4aabe0196348f68bd26b1d354dcfd3166b2ec59940055d04300e2df7564")
