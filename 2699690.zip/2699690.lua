-- Lua provided by RyzenAPI
-- Game: Game: Harmonia Full HD Edition

-- MAIN APPLICATION
addappid(2699690)
-- Game: addappid(2699690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699691, 1, "f66409750f6efd60466bafa0334f4f52df9b18590d73d8ddfcca004403153091")
