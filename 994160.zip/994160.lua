-- Lua provided by RyzenAPI
-- Game: The Seduction of Shaqeera

-- MAIN APPLICATION
addappid(994160)

-- MAIN APP DEPOTS / PACKAGES
addappid(994161, 1, "1330d421936145599a728040b7bc985f9c3fe5d3380d0e219e3189c2f6794bea")
