-- Lua provided by RyzenAPI 
-- Game: Pinball Breeze
addappid(3412400)
addappid(3412401, 1, "1980a6cbd12b4c1cf1b0549b36549d2242106bb92ee7a03fabdc2ce6acfd422a")
