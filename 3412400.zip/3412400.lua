-- Lua provided by RyzenAPI
-- Game: Pinball Breeze

-- MAIN APPLICATION
addappid(3412400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3412401, 1, "1980a6cbd12b4c1cf1b0549b36549d2242106bb92ee7a03fabdc2ce6acfd422a")

