-- Lua provided by RyzenAPI
-- Game: 933500

-- MAIN APPLICATION
addappid(933500)
-- Game: addappid(933500)

-- MAIN APP DEPOTS / PACKAGES
addappid(933500,0,"bbce039e87fef7c37aba7a4435dad5f5bf7f05971edcd50eea310bc0259a42ce")
addtoken(933500,225271796409487172)
