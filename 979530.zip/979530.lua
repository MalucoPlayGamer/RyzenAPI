-- Lua provided by RyzenAPI
-- Game: Endless Maneuver

-- MAIN APPLICATION
addappid(979530)
-- Game: addappid(979530)

-- MAIN APP DEPOTS / PACKAGES
addappid(979531, 1, "33adb494ec32f83417a756a6597bcb990efe08946aa80c758a17de2d043d65dc")
