-- Lua provided by RyzenAPI
-- Game: Occult Crime Police

-- MAIN APPLICATION
addappid(1745750)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1773920)
