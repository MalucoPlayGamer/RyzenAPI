-- Lua provided by RyzenAPI
-- Game: Occult Crime Police

-- MAIN APPLICATION
addappid(1745750)
addappid(1773920)

