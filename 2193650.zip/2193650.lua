-- Lua provided by RyzenAPI
-- Game: 2193650

-- MAIN APPLICATION
addappid(2193650)
-- Game: addappid(2193650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193651, 1, "c95545f8720bb8fcf0fcd40a109b9bd27d04d6eec29640aaefca38d4c290ac3b")
