-- Lua provided by RyzenAPI
-- Game: Boxville

-- MAIN APPLICATION
addappid(1750710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750711, 1, "cc64a2ac0efcd7f886f455c5e17de0719aee6341897a040e9b18f86c282790ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2147300)
