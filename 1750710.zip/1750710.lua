-- Lua provided by RyzenAPI
-- Game: Boxville

-- MAIN APPLICATION
addappid(1750710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750711, 1, "cc64a2ac0efcd7f886f455c5e17de0719aee6341897a040e9b18f86c282790ee")

