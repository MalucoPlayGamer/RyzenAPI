-- Lua provided by SkyAPI 
-- Game: IMUGI
addappid(1492930)
addappid(1492931, 1, "6bed2c930739cfae196d5eb32712c9c68c967528e465a8639ec07067e42224ce")
