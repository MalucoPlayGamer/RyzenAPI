-- Lua provided by RyzenAPI
-- Game: IMUGI

-- MAIN APPLICATION
addappid(1492930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1492931, 1, "6bed2c930739cfae196d5eb32712c9c68c967528e465a8639ec07067e42224ce")

