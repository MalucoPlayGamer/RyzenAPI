-- Lua provided by RyzenAPI
-- Game: IMUGI

-- MAIN APPLICATION
addappid(1492930)
-- Game: addappid(1492930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492931, 1, "6bed2c930739cfae196d5eb32712c9c68c967528e465a8639ec07067e42224ce")
