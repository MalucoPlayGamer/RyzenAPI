-- Lua provided by RyzenAPI
-- Game: addappid(2162720)

-- MAIN APPLICATION
addappid(2162720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162721, 1, "7fdce479d951a276731a973c46bf9d213435dd52fbd988a37fc266cf0b674b54")
