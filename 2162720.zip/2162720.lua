-- Lua provided by RyzenAPI 
-- Game: Shepherd's Crossing
addappid(2162720)
addappid(2162721, 1, "7fdce479d951a276731a973c46bf9d213435dd52fbd988a37fc266cf0b674b54")
