-- Lua provided by RyzenAPI
-- Game: Game: Base One

-- MAIN APPLICATION
addappid(1471040)
-- Game: addappid(1471040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471041, 1, "41e6df05a47381df664c160c5c39e06bf61ebefb11c3e29c9134683a6834b632")
