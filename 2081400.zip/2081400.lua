-- Lua provided by RyzenAPI
-- Game: 2081400

-- MAIN APPLICATION
addappid(2081400)
-- Game: addappid(2081400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081401, 1, "79b35e615d959aae37d92d346543d8f5f5a0a50168b912d0b4ebbf06f5826c4c")
