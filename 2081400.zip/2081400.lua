-- Lua provided by RyzenAPI
-- Game: Gal Guardians: Demon Purge

-- MAIN APPLICATION
addappid(2081400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2081401, 1, "79b35e615d959aae37d92d346543d8f5f5a0a50168b912d0b4ebbf06f5826c4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
