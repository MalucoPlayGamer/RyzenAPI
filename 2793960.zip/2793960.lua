-- Lua provided by RyzenAPI
-- Game: addappid(2793960)

-- MAIN APPLICATION
addappid(2793960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793961, 1, "c203ada08e2614f720c1b3f749c1938e55ce8bc55e3fc81eafccae304364d634")
