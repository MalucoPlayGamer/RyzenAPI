-- Lua provided by RyzenAPI
-- Game: Depixtion: Halloween

-- MAIN APPLICATION
addappid(1132510)
addappid(1132511)
addappid(1132512)
addappid(1132513)
-- Game: addappid(1132510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092781,0,"b35d93d01f16aaec3e600d4edfa172c5683e534ec4ba2fa1163b2e0815a24cc6")
