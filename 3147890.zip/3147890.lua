-- Lua provided by RyzenAPI
-- Game: addappid(3147890)

-- MAIN APPLICATION
addappid(3147890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3147891, 1, "cbcacfab3b799818864829f8c2a5acf1e6ce1972834bd7c8829859dfd1dd4c67")
