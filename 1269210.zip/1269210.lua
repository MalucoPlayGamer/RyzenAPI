-- Lua provided by RyzenAPI
-- Game: Liberated Demo

-- MAIN APPLICATION
addappid(1269210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269211, 1, "979c5cd8b941ac29de759ac8ddbc5503d430b4bb3303025fb0db1f814a3c7c6d")

