-- Lua provided by RyzenAPI 
-- Game: Caveman Warriors
addappid(603420)
addappid(603421, 1, "4c869fac70ea175c6cba3941d99bec45ab83b0d05001df0cecb45aacc99fab76")
addappid(603422, 1, "deb7b70db0cdf64e61ed8bb2b1eb82d5620107f26151840ebe30d20ffb35cb2e")
addappid(603423, 1, "dde86ef4c6142f57ccb99eae3046d31213dbf55ef83bfd57d1e09ec35e385538")
