-- Lua provided by RyzenAPI
-- Game: AppID 606870

-- MAIN APPLICATION
addappid(606870)

-- MAIN APP DEPOTS / PACKAGES
addappid(606871, 1, "c4bbf786497d5273f6009987c2cddf3312790ca3fb7469f0ba6edfb6926a4dd5")

