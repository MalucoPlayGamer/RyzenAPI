-- Lua provided by RyzenAPI
-- Game: Techwars Deathmatch

-- MAIN APPLICATION
addappid(835600)

-- MAIN APP DEPOTS / PACKAGES
addappid(835601,0,"942affee3d81a8e4ee36aa3761136af698d5c6de01ebc78e6fb4515e360fd2a2")

