-- Lua provided by RyzenAPI
-- Game: The Wild Eight - Supporter Pack

-- MAIN APPLICATION
addappid(590361)

-- MAIN APP DEPOTS / PACKAGES
addappid(590361,0,"bc6ce300bbaaaafec95586fa21557687d25a0b9f6af6284874c69f0678e9e287")

