-- Lua provided by RyzenAPI
-- Game: Game: AppID 1170970

-- MAIN APPLICATION
addappid(1170970)
-- Game: addappid(1170970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170971, 1, "5194ce69247d44b923796c2d91cc3d76524afca53f9c7e70ca98c4b4b8131ab5")
