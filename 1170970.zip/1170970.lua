-- Lua provided by RyzenAPI
-- Game: AppID 1170970

-- MAIN APPLICATION
addappid(1170970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170971, 1, "5194ce69247d44b923796c2d91cc3d76524afca53f9c7e70ca98c4b4b8131ab5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
