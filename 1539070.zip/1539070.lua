-- Lua provided by RyzenAPI
-- Game: AppID 1539070

-- MAIN APPLICATION
addappid(1539070)
-- Game: addappid(1539070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1539071, 1, "4e0cdc3f641c8e59be74e8abbac27581a5d491c1d76bef1c752941364500c085")
