-- Lua provided by RyzenAPI
-- Game: Game: AppID 2658700

-- MAIN APPLICATION
addappid(2658700)
-- Game: addappid(2658700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658701, 1, "bea9d02d3d1f319baf39e5ef82f2e8acbf0e7203ad53f222821a6f0d88e01418")
