-- Lua provided by RyzenAPI
-- Game: Game: Botworld Odyssey Demo

-- MAIN APPLICATION
addappid(3012160)
-- Game: addappid(3012160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012161, 1, "b7285a2ec85b5118416ca127ebb7981fd8baedee5e73dd7da89c963ccf58974f")
