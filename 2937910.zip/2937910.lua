-- Lua provided by RyzenAPI
-- Game: addappid(2937910)

-- MAIN APPLICATION
addappid(2937910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937911, 1, "7f1c7ada777551a1a6b52b48d1def3e574cdc1aae86d2e5575821f5002fe0733")
