-- Lua provided by RyzenAPI
-- Game: True Spring Love

-- MAIN APPLICATION
addappid(1568960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568961, 1, "2e440eb3f47d9413d150bc0cf2eed03765484348f7e68b039cf50d7594780a3e")

