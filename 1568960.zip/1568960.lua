-- Lua provided by SkyAPI 
-- Game: AppID 1568960
addappid(1568960)
addappid(1568961, 1, "2e440eb3f47d9413d150bc0cf2eed03765484348f7e68b039cf50d7594780a3e")
