-- Lua provided by RyzenAPI
-- Game: 1010750

-- MAIN APPLICATION
addappid(1010750)
-- Game: addappid(1010750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010751, 1, "f40e4e6ac54d41b64049c785f549b115b63fc51615d31e7ef6c3c54afa2dec5a")
addappid(1010752, 1, "9131cb84c94a01cdbddc2184c9844967734fe1c4a3ab2d922cd0cefe97889f6b")
addappid(1010753, 1, "c8dd7940db206b08afc788cd9c8cb2cfaf3adaa2913e865a5ea19c13507e20f4")
