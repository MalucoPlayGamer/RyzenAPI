-- Lua provided by RyzenAPI
-- Game: 声锁 Sound Lock

-- MAIN APPLICATION
addappid(2506510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506511, 1, "a2697660550e43ed1f3c531e7f8ad671eae11df85850a051dd006873aa884607")

