-- Lua provided by RyzenAPI 
-- Game: AppID 2271980
addappid(2271980)
addappid(2271981, 1, "8692333f5771350972c8e620786ac563ec87778dcbbfc4713208da455a609a4f")
addappid(2277580, 0, "bcb5d2ce8545849f62f502601fae2ef6306debca7c66e09ab68a1f09ec1b0a7c")
