-- Lua provided by RyzenAPI
-- Game: 3695990

-- MAIN APPLICATION
addappid(3695990)
-- Game: addappid(3695990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3695991, 1, "f6aa32b13fccde3caa6b84a12ffd584c57ef67c49957bb0c5f49227f54fd9c80")
