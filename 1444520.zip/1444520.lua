-- Lua provided by RyzenAPI
-- Game: Tribal Hunter Demo

-- MAIN APPLICATION
addappid(1444520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1444521, 1, "4d0520aeed8aa5d80a7972321d03772df9efb2aaaa46e14305d7f36b77b284fd")
