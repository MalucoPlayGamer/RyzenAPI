-- Lua provided by RyzenAPI
-- Game: 861250

-- MAIN APPLICATION
addappid(861250)
-- Game: addappid(861250)

-- MAIN APP DEPOTS / PACKAGES
addappid(861253,0,"a05ef11dbc06ab37ac237124b3b6f0884e1e2d6e7a4e7494b44503f4b6e773db")
