-- Lua provided by RyzenAPI
-- Game: ROSE

-- MAIN APPLICATION
addappid(2262170)
addappid(3234470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262171, 1, "04e0a8d960d2429022ab3a9ccc4375976c53a1d8782e2527df1ffe6cb4c54418")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
