-- Lua provided by RyzenAPI
-- Game: Game: ROSE

-- MAIN APPLICATION
addappid(2262170)
addappid(3234470)
-- Game: addappid(2262170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262171, 1, "04e0a8d960d2429022ab3a9ccc4375976c53a1d8782e2527df1ffe6cb4c54418")
