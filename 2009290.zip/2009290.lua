-- Lua provided by SkyAPI 
-- Game: AppID 2009290
addappid(2009290)
addappid(2009291, 1, "751db1713937e9242ee52c324c446d1692f342638e7654fa461a43c1bde1f362")
