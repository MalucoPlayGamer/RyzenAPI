-- Lua provided by RyzenAPI
-- Game: Dubio (Demo)

-- MAIN APPLICATION
addappid(2780792)
addappid(2993610)
addappid(2993611)
addappid(2993612)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780791,0,"cb6a23fb1af09ca12915faa4db6a89bb34cc88cfb711dec760297763edf06ffd")
