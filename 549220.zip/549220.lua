-- Lua provided by RyzenAPI
-- Game: Game: Dark Canvas: A Brush With Death Collector's Edition

-- MAIN APPLICATION
addappid(549220)
-- Game: addappid(549220)

-- MAIN APP DEPOTS / PACKAGES
addappid(549221, 1, "55170bb8f2b7751b6a88c7ca7ccddae4a7f9600c0e37fb8e62a3323b760128d7")
