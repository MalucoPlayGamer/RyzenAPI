-- Lua provided by RyzenAPI
-- Game: Halluci-Sabbat of Koishi - Koishi's Supporter Pack

-- MAIN APPLICATION
addappid(2937320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2937321, 1, "07e3f6b774b5ce78db545e594f9091878173f1f5d53ac754e8212ffd2033b264")

