-- Lua provided by RyzenAPI
-- Game: Glyde The Dragon™ Demo

-- MAIN APPLICATION
addappid(1821610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821611, 1, "15521455e4990d9ad3d4143494304ed8006fd959e715787c1c555c7ed04a4a97")

