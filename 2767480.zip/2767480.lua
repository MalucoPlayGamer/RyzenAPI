-- Lua provided by RyzenAPI
-- Game: Alien Horizon (Preview Alpha)

-- MAIN APPLICATION
addappid(2767480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767481, 1, "81c96b1f57785fb16dbbdcae248e5a8172822190ae30be2178a0da6638fe1c82")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2771610)
addappid(2771620)
