-- Lua provided by RyzenAPI 
-- Game: AppID 2528380
addappid(2528380)
addappid(2528381, 1, "260ed018d382d70026381514d0d0962fc926fe647ac6e30000aa697085542386")
