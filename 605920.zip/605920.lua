-- Lua provided by RyzenAPI
-- Game: addappid(605920)

-- MAIN APPLICATION
addappid(605920)

-- MAIN APP DEPOTS / PACKAGES
addappid(605921, 1, "e17038c554487c8292063b0ecc6b5fe2c07b28366f9a5c742afca7989f1c25af")
