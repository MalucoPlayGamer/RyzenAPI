-- Lua provided by RyzenAPI
-- Game: Game: Diffraction Demo

-- MAIN APPLICATION
addappid(2242350)
-- Game: addappid(2242350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242351, 1, "66897aaf8265c52e11337044e4f3c901eadac3062dbd1ce07fb7228e5f4fc406")
