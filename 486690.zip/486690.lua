-- Lua provided by RyzenAPI
-- Game: Pastelia Stories

-- MAIN APPLICATION
addappid(486690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(486691, 1, "2e0620ad7cb4091cd18ced230bd4469f2568ce51859383c2a59b5f94906d07ac")
addappid(486692, 1, "e54b7dc69b13b1bf076d340848e61071a648ffd1a2a847aec6304e7f913e2418")
addappid(486693, 1, "5fba000009e90a14dd03015bd23c873eb219d455517a94e15b223b3d0ec324b2")
addappid(486694, 1, "85651ad0c5df5285615a52946efb8e7775a6f861c1ad02e6ec5991cadf3e60f5")

