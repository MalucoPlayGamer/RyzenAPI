-- Lua provided by RyzenAPI
-- Game: Age of Water

-- MAIN APPLICATION
addappid(2695490)
addappid(2720750)
addappid(2720760)
-- Game: addappid(2695490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2695491, 1, "fb4635bc4301ae8756fe365886c6c09b599761bb5113365389e116aec878d2f2")
