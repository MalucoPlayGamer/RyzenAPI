-- Lua provided by RyzenAPI
-- Game: 2015160

-- MAIN APPLICATION
addappid(2015160)
-- Game: addappid(2015160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015160,0,"393d8ee3bef375c514a33f58f6125a93480faa0b5932d4a0d2120ae1b1f0db3d")
