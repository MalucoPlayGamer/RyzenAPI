-- Lua provided by RyzenAPI
-- Game: SmartBoy

-- MAIN APPLICATION
addappid(800130)

-- MAIN APP DEPOTS / PACKAGES
addappid(800131,0,"c17c4dcc8d9f05b8c32c203fdab37cdef05b13299ed6c13d99d13031a7db5f46")

