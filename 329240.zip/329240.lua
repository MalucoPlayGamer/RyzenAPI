-- Lua provided by RyzenAPI
-- Game: addappid(329240)

-- MAIN APPLICATION
addappid(329240)

-- MAIN APP DEPOTS / PACKAGES
addappid(329241, 1, "b23d7986447b7c91999bec220105d8f2b0f2cb6e56cca829058a5fe663ff765d")
