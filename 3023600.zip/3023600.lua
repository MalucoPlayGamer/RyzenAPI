-- Lua provided by RyzenAPI
-- Game: Game: Horse Farm Simulator

-- MAIN APPLICATION
addappid(3023600)
-- Game: addappid(3023600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023601, 1, "94f559459b987a7e297c1bfc6292c0af60d7a2b91b3c0876b37e7f6a0a5a9aac")
