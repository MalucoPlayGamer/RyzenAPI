-- Lua provided by RyzenAPI
-- Game: COLD VR

-- MAIN APPLICATION
addappid(2636890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2636891, 1, "9638c7af330bd285d5b22cb64f441e2b3d6d91b2918cb1e7a970c67e01c707c3")

