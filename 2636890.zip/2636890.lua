-- Lua provided by RyzenAPI
-- Game: 2636890

-- MAIN APPLICATION
addappid(2636890)
-- Game: addappid(2636890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636891, 1, "9638c7af330bd285d5b22cb64f441e2b3d6d91b2918cb1e7a970c67e01c707c3")
