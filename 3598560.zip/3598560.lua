-- Lua provided by RyzenAPI
-- Game: Hentai Lucia

-- MAIN APPLICATION
addappid(3598560)
-- Game: addappid(3598560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3598561, 1, "b2f52e3031677243024bc6d7ba0f7966d4767f663b9a4542a42f10b07fa9396f")
