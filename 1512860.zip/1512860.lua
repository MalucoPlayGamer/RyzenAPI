-- Lua provided by RyzenAPI
-- Game: Pixelot

-- MAIN APPLICATION
addappid(1512860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512861, 1, "5a2f9af4498a9fecf422fbcac2d996f7ad26957d4357d7d2605fd541e17f384a")
