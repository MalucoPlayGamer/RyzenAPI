-- Lua provided by RyzenAPI
-- Game: Dice Assassin

-- MAIN APPLICATION
addappid(2573470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573471, 1, "3fbb3e9384fc79669ade05ebf6d42d97726b85411bc9cff7870fe25a8a95e549")
