-- Lua provided by SkyAPI 
-- Game: AppID 608980
addappid(608980)
addappid(608981, 1, "45271c4d5c8cf95ecdcedf55afd4da5b522c986155676374893318f768f8db79")
