-- Lua provided by RyzenAPI
-- Game: Arch Virtual HQ

-- MAIN APPLICATION
addappid(608980)

-- MAIN APP DEPOTS / PACKAGES
addappid(608981, 1, "45271c4d5c8cf95ecdcedf55afd4da5b522c986155676374893318f768f8db79")
