-- Lua provided by RyzenAPI
-- Game: Grandpa's Cheese

-- MAIN APPLICATION
addappid(1843030)
-- Game: addappid(1843030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843032,0,"66998e4f817beb923c585aba8b925527b6b0e0a8e380e67813cdc57b02b830b2")
