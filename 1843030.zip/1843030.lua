-- Lua provided by RyzenAPI
-- Game: Grandpa's Cheese

-- MAIN APPLICATION
addappid(1843030)
addappid(2755140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1843032,0,"66998e4f817beb923c585aba8b925527b6b0e0a8e380e67813cdc57b02b830b2")

