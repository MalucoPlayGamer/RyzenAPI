-- Lua provided by RyzenAPI
-- Game: Hyper Hentai Bikini Party

-- MAIN APPLICATION
addappid(2365670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365671, 1, "03bb7e1adb5181cfb75ab8a469350f8a3eebfcb66c73a11a13d1d94ac679eb00")
