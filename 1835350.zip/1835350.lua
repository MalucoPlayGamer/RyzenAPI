-- Lua provided by RyzenAPI
-- Game: 道不可道

-- MAIN APPLICATION
addappid(1835350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835351, 1, "2dae9e154cde0eb776862462c87cbe6aad35f7cb85cb9978f89db3e6e9eefec9")

