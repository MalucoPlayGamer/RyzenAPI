-- Lua provided by SkyAPI 
-- Game: 道不可道
addappid(1835350)
addappid(1835351, 1, "2dae9e154cde0eb776862462c87cbe6aad35f7cb85cb9978f89db3e6e9eefec9")
