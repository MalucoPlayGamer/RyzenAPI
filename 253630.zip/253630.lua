-- Lua provided by RyzenAPI
-- Game: AppID 253630

-- MAIN APPLICATION
addappid(253630)

-- MAIN APP DEPOTS / PACKAGES
addappid(253631, 1, "9a661de8c47671b7acf37583342d51e1564b374c53f48e7e9b466be189b8c4fb")
addappid(253632, 1, "b116a83f0c69fc3a104b34d6c64e181fec1e5dced5fd3ca25ca31f7ea6a4aa6e")
addappid(253633, 1, "6852e78868f7e1e2b61e399fb1c4a6db49a6fe93f7e7c2204e4e31e6510ba0fd")

