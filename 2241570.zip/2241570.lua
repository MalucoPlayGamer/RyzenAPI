-- Lua provided by RyzenAPI 
-- Game: Legend of Edda: Pegasus
addappid(2241570)
addappid(2241571, 1, "104af9e76577e0ecc6341e527a5023943255ac0403399fb874f2d7a076e2e7f4")
