-- Lua provided by RyzenAPI
-- Game: Toki Tori

-- MAIN APPLICATION
addappid(38700)
addappid(98015)
addappid(228983)
addappid(228990)
-- Game: addappid(38700)

-- MAIN APP DEPOTS / PACKAGES
addappid(38702,0,"81e3d823460c357ca47d7fc971c5c41f740d8be6ec85b1223daa69e57d01f759")
addappid(38703,0,"397a4325c685453912947fe7809c5200d479825cc0c30b71debcae04185838f7")
addappid(387001,0,"4a5feffeb22bc8e65f70982a12bae8b17528e7210922b87c300078fdcf474647")
