-- Lua provided by RyzenAPI
-- Game: Thunder Spheres

-- MAIN APPLICATION
addappid(559300)

-- MAIN APP DEPOTS / PACKAGES
addappid(559301,0,"5e9230f540e1b3c38b5ae69543c8ab797c32b3bee48915c570dcbf3a8dee21da")

