-- Lua provided by RyzenAPI
-- Game: Game: Near Death

-- MAIN APPLICATION
addappid(327560)
-- Game: addappid(327560)

-- MAIN APP DEPOTS / PACKAGES
addappid(327561, 1, "935c01af8375dfbf7bcf4fbd1ac81c21b856f51e4567beb87f550c25bd881a83")
addappid(327562, 1, "f843c6df4b87aeb99a0ef2a872b523bb55081198c5d9a88e714403f668900f34")
addappid(327563, 1, "08fdaccdd231c00be470e7e31fc876af551e37de1f827a1d6e4ba62bdec6214f")
addappid(443550, 0, "83b4d8eed9eee582fe6f92887896f184653d693c4c93a0b4058ad5200be2f200")
