-- Lua provided by RyzenAPI
-- Game: Wolfenstein II: The Freedom Chronicles - Episode 2

-- MAIN APPLICATION
addappid(624621)
addappid(762741)
-- Game: addappid(624621)

-- MAIN APP DEPOTS / PACKAGES
addappid(762740,0,"518461383a927fa6f8b01c3ce717561a8061ec27057f00af03be400e4c4ac77e")
