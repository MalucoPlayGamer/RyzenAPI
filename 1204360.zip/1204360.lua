-- Lua provided by RyzenAPI 
-- Game: AppID 1204360
addappid(1204360)
addappid(1204361, 1, "26428b4f5b9b4f65d0dcb8b6fddf6347553eb8ecac08976e51a5cbe063f82ba2")
