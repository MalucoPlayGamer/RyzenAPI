-- Lua provided by RyzenAPI
-- Game: AirMech

-- MAIN APPLICATION
addappid(206500)
-- Game: addappid(206500)

-- MAIN APP DEPOTS / PACKAGES
addappid(206503,0,"c1f4008780c08ced071797be6a11ef77e8908fb26e045ca9692019add23db146")
addappid(216173,0,"bd82c8ad83822799bbb5ac0ec26078c0e1786e35f9296fc42cb5dee1f334c83a")
