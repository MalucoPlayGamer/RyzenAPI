-- Lua provided by RyzenAPI 
-- Game: Team Indie
addappid(302850)
addappid(302851, 1, "e71fc8657c37ac172a4378d0ff4a858499737862b5c55bcad5531d0c494575ac")
addappid(302852, 1, "5e8a5339bf6756c0e8f2921d8036ee107870f9226875f987a05886a406c6827d")
