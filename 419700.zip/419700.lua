-- Lua provided by RyzenAPI
-- Game: 419700

-- MAIN APPLICATION
addappid(419700)

-- MAIN APP DEPOTS / PACKAGES
addappid(419702,0,"9cc623ced3ce8bf92329388ce92fe93654c52f7e4dff518ca1ccd09309f3cba4")
