-- Lua provided by RyzenAPI
-- Game: AT SUNDOWN: Shots in the Dark

-- MAIN APPLICATION
addappid(419700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(419702,0,"9cc623ced3ce8bf92329388ce92fe93654c52f7e4dff518ca1ccd09309f3cba4")

