-- Lua provided by RyzenAPI
-- Game: Patch Quest

-- MAIN APPLICATION
addappid(1347970)
addappid(2300060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1347971, 1, "16b30d6e1a5efac95b1bbef8ba62ccb8d5adb88708f3b78d767186bfe526b462")
addappid(2333170, 0, "93d21540aa70eeaf25a19ca9acac7f6bde6888732a502b77728039fd042c6571")

