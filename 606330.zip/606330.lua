-- Lua provided by RyzenAPI
-- Game: 606330

-- MAIN APPLICATION
addappid(606330)
-- Game: addappid(606330)

-- MAIN APP DEPOTS / PACKAGES
addappid(606331, 1, "39cbc8d71a2702b15b5e5d449c1a162756f67a0a5885330cbfff8c2b409533fc")
