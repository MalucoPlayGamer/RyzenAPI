-- Lua provided by RyzenAPI
-- Game: addappid(2921660)

-- MAIN APPLICATION
addappid(2921660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921661, 1, "e0a11574d4ef417eeac1ab9389bf22b33ea7d71066aeb2ec32bf3f882dd77b59")
