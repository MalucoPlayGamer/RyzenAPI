-- Lua provided by RyzenAPI
-- Game: Game: Vessel

-- MAIN APPLICATION
addappid(108500)
-- Game: addappid(108500)

-- MAIN APP DEPOTS / PACKAGES
addappid(108501, 1, "773e09ac861e96d4b08c0551f444dcf8dced9a62f59c7794fe699c835548de5e")
addappid(108502, 1, "15aef5c156845467ba1595abb0ff062223195e13fcfdb94294def0fef801c1ab")
addappid(108503, 1, "d43f780d44b9708d596ae0f58eee5b547c257b079cfa63a2e2e83b80645cb097")
addappid(108504, 1, "a4bbe0e9348660a1baf5f8ca7a86d4f406a1ced837688dffd9d9b407d70a5d67")
addappid(108505, 1, "6e6394c8cd7d3c00228783e0cc952db52f9f79688def11861ed468da8d22524a")
addappid(202392, 0, "acf1fc021a4e7d7f4f4003b04cf63b4e3eacfd4cf12ac9b07d7eac2d588f4746")
addappid(202393, 0, "51b407bf5eccb7296905073492bf3c0fff98372bdb73f6ecec44c75e6101ddc4")
