-- Lua provided by RyzenAPI
-- Game: Game: Dawn Of Hell

-- MAIN APPLICATION
addappid(2255820)
-- Game: addappid(2255820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255821, 1, "fcabc32e0c4f8d079db59f5c7d296e784176d2aa24190af8a225a3310bca72a6")
