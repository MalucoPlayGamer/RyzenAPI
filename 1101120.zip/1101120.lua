-- Lua provided by RyzenAPI
-- Game: 1101120

-- MAIN APPLICATION
addappid(1101120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101122,0,"b82f041de94c4180a238a248cb18c8fdbc3d3f0ac8dda0152b6c70e6e2e9a28a")

