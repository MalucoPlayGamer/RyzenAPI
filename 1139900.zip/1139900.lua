-- Lua provided by RyzenAPI
-- Game: Ghostrunner

-- MAIN APPLICATION
addappid(1480500) -- Ghostrunner - Winter Pack
addappid(1542040) -- Ghostrunner - Metal OX Pack
addappid(1647450) -- Ghostrunner - Neon Pack
addappid(1741380)
addappid(1760130) -- Ghostrunner - Halloween Pack
addappid(1760190) -- Ghostrunner - Project_Hel

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
addappid(1139900, 1, "b5628f62a987d51d0b00fa2e44ee9b7350875840b8eca368f0f3483ab0382520") -- Ghostrunner
addappid(1139901, 1, "b1a4614bd74ba48ab2546570b5d66bc0d1380a4b1dce45acc370be5fc5fb9c1f") -- Ghostrunner Content
addappid(1741380, 1, "f8bc115f6677008301df4a15b02a362d568e2b6e5e6b1443de1d146cb01892ba") -- Ghostrunner Digital Artbook - Ghostrunner Digital Artbook (1741380) Depot

