-- Lua provided by RyzenAPI
-- Game: addappid(1139900)

-- MAIN APPLICATION
addappid(1139900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139901, 1, "b1a4614bd74ba48ab2546570b5d66bc0d1380a4b1dce45acc370be5fc5fb9c1f")
addappid(1741380, 0, "f8bc115f6677008301df4a15b02a362d568e2b6e5e6b1443de1d146cb01892ba")
