-- Lua provided by RyzenAPI
-- Game: Game: AppID 1200650

-- MAIN APPLICATION
addappid(1200650)
-- Game: addappid(1200650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1200651, 1, "57f3daaf0dc189cb84ffe68e6f66e3dff960329f649b2593c8f264d8e4641b16")
