-- Lua provided by RyzenAPI
-- Game: 3440110

-- MAIN APPLICATION
addappid(3440110)
-- Game: addappid(3440110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440111, 1, "36a6822da1973cae2af31e4d6e4a87a79c8c35d47b7601e3421fe10332235a61")
