-- Lua provided by RyzenAPI
-- Game: 米可可大冒險 Demo

-- MAIN APPLICATION
addappid(2153580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2153584,0,"d068a9cdacba09f720afef48b1fa778b53b88e5218ccefacc24d69ce1160cc72")
addappid(2153585,0,"833fbeb2fbea901076cae41ebee74a53f99a05fabcbefa3d5a51bbaed474e3d5")

