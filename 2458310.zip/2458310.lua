-- Lua provided by RyzenAPI
-- Game: 2458310

-- MAIN APPLICATION
addappid(2458310)
-- Game: addappid(2458310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458311, 1, "740287d3e7e0577a8b76b098bece3977a4074bffde7a2e61fed1c5c561602f55")
