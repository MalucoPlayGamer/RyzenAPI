-- Lua provided by RyzenAPI
-- Game: DeathComing

-- MAIN APPLICATION
addappid(705120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(705121, 1, "f3aa5d5fe76260d17644a872021bcd3fefe371c5799d91bc69a5477f7fff623c")
