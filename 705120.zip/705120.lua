-- Lua provided by RyzenAPI
-- Game: AppID 705120

-- MAIN APPLICATION
addappid(705120)

-- MAIN APP DEPOTS / PACKAGES
addappid(705121, 1, "f3aa5d5fe76260d17644a872021bcd3fefe371c5799d91bc69a5477f7fff623c")

