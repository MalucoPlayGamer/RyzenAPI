-- Lua provided by RyzenAPI
-- Game: 235360

-- MAIN APPLICATION
addappid(228983)
addappid(235360)
addappid(235362)
addappid(235363)
-- Game: addappid(235360)

-- MAIN APP DEPOTS / PACKAGES
addappid(235364,0,"607155aca3a7e3670771fc3b5589419793921374b3a5d43e1b8bb6fef50ed999")
addappid(235365,0,"99af3ffc18b89adf12be37c44483cb56233aac56f23927854fbfa248cec6560d")
