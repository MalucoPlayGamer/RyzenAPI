-- Lua provided by RyzenAPI
-- Game: Dog Clicker

-- MAIN APPLICATION
addappid(1142530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1142531, 1, "201bb97933100cc25972ef589cf38088e27ffc367cf31ad2bc3603786a7265f3")
addappid(1142534, 1, "6176faa4415378c63561e5ddaf248fcd6bd16502dd296768ad92e77bb784f06c")
