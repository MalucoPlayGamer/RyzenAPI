-- Lua provided by RyzenAPI
-- Game: Darwin's Test

-- MAIN APPLICATION
addappid(958960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(958961, 1, "0c27ca5eb3b23e0f2ce6b55d792b3f3f951ea5400fcee428769015202214d295")

