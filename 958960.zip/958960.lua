-- Lua provided by RyzenAPI
-- Game: Game: Darwin's Test

-- MAIN APPLICATION
addappid(958960)
-- Game: addappid(958960)

-- MAIN APP DEPOTS / PACKAGES
addappid(958961, 1, "0c27ca5eb3b23e0f2ce6b55d792b3f3f951ea5400fcee428769015202214d295")
