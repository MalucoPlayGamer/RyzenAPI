-- Lua provided by RyzenAPI
-- Game: addappid(1456590)

-- MAIN APPLICATION
addappid(1456590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456591, 1, "1a0d009276884e19d0a9d4d576536fa6ad1d5442becae6a876b92805077f748d")
