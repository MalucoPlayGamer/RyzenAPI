-- Lua provided by RyzenAPI 
-- Game: Twizzle Puzzle: Dragons
addappid(3138800)
addappid(3138801, 1, "4829d4623c5598b996b7a9dcfd7c0d7de80b40c87903e6d88590f9f44eba6fb7")
