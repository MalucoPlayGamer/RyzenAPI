-- Lua provided by RyzenAPI
-- Game: addappid(1767170)

-- MAIN APPLICATION
addappid(1767170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767171, 1, "5ad0dd59bcb98ba4824f36b9835b964dd4527518df57da2869a3461d14c0f9f4")
