-- Lua provided by RyzenAPI 
-- Game: Super Bullet Break
addappid(1767170)
addappid(1767171, 1, "5ad0dd59bcb98ba4824f36b9835b964dd4527518df57da2869a3461d14c0f9f4")
