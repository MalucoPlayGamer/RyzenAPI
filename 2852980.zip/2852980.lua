-- Lua provided by RyzenAPI
-- Game: Necroking

-- MAIN APPLICATION
addappid(2852980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852981, 1, "d3108f617df874b9b0a82188da9484b91ae49e090aaee10fdf5db65e509d4a1c")

