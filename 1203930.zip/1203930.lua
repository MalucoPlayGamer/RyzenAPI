-- Lua provided by RyzenAPI
-- Game: The Last Haven

-- MAIN APPLICATION
addappid(1203930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203931, 1, "e0a01f21c48afd956615f13e005945f6021691aa3bfa9718813e3ea5f904716f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
