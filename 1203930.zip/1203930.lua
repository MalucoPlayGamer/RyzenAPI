-- Lua provided by RyzenAPI 
-- Game: The Last Haven
addappid(1203930)
addappid(1203931, 1, "e0a01f21c48afd956615f13e005945f6021691aa3bfa9718813e3ea5f904716f")
