-- Lua provided by RyzenAPI
-- Game: AppID 2642520

-- MAIN APPLICATION
addappid(2642520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642521, 1, "df95fa79b93d741a3009a16cc0c80fa17e36717a116ea5606142210741cf3a63")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
