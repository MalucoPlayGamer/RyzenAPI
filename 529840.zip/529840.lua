-- Lua provided by RyzenAPI
-- Game: Brawl of Ages

-- MAIN APPLICATION
addappid(529840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(529841, 1, "319a254d45ffcc7c88e1b1bcea4ad7db80790a849cebd78e4c0231b358080ecf")
addappid(529842, 1, "be21821a56e1de5b06e569b5e7ab5d3a4f3f170dba1674c4d8f4e70f1bf158c1")
addappid(529845, 1, "e3313785faf36c638fa4835633aaef2ac6302862284641910cd115ce97660e00")
addappid(529846, 1, "7ffe8957b9c65dd76d3e116287a36091326b1e259a31bdc8825e98f62dae701f")

