-- Lua provided by RyzenAPI
-- Game: Brawl of Ages

-- MAIN APPLICATION
addappid(529840)
-- Game: addappid(529840)

-- MAIN APP DEPOTS / PACKAGES
addappid(529841, 1, "319a254d45ffcc7c88e1b1bcea4ad7db80790a849cebd78e4c0231b358080ecf")
addappid(529842, 1, "be21821a56e1de5b06e569b5e7ab5d3a4f3f170dba1674c4d8f4e70f1bf158c1")
addappid(529845, 1, "e3313785faf36c638fa4835633aaef2ac6302862284641910cd115ce97660e00")
addappid(529846, 1, "7ffe8957b9c65dd76d3e116287a36091326b1e259a31bdc8825e98f62dae701f")
