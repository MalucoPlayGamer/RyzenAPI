-- Lua provided by RyzenAPI
-- Game: 498020

-- MAIN APPLICATION
addappid(498020)
-- Game: addappid(498020)

-- MAIN APP DEPOTS / PACKAGES
addappid(498021, 1, "ea1bc5e3a0c6807d91bf61a8b3adadabe8d4a2905030835f18f5cb72de176a69")
