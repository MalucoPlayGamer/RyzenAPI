-- Lua provided by RyzenAPI
-- Game: 1802190

-- MAIN APPLICATION
addappid(1802190)
-- Game: addappid(1802190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802191, 1, "0fef00e36da154118200f3be053a2a3518c74b362a49bce9cbbad85b8756b3cf")
