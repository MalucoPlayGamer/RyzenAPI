-- Lua provided by RyzenAPI
-- Game: Puzzles For Clef

-- MAIN APPLICATION
addappid(1802190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1802191, 1, "0fef00e36da154118200f3be053a2a3518c74b362a49bce9cbbad85b8756b3cf")
