-- Lua provided by RyzenAPI
-- Game: Game: Amazing Frog?

-- MAIN APPLICATION
addappid(332570)
-- Game: addappid(332570)

-- MAIN APP DEPOTS / PACKAGES
addappid(332571, 1, "914497bf7253dae27e380c140c5f34a17a7b0be144e186b299df16cd38673402")
addappid(332572, 1, "ef05975e6a5e7e1b2319bc118cb199d4a6beb3c20979157e6eb3cc65c8ff93a0")
addappid(332573, 1, "46e402f3b495e25ea0e9f1be5ee4689c0f97c9d3536cc697784118cb89109a6a")
addappid(332574, 1, "8e6d00dbdfa286c81765c135bb5da8054e182ad8f5e56f2d8765ad785bc0cfa3")
addappid(332575, 1, "3b209ff0cb6e0bf31debc839a99e15c5e101f97f398c9076f0445202db777b01")
