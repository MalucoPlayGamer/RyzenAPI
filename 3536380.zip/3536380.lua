-- Lua provided by RyzenAPI
-- Game: Gridkeeper

-- MAIN APPLICATION
addappid(3536380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3536381, 1, "4abed8ef92db346f7549866723716f6600e573b577c572a06acffe4d0e443755")
