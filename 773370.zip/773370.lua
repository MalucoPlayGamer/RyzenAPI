-- Lua provided by RyzenAPI 
-- Game: AppID 773370
addappid(773370)
addappid(773371, 1, "90152f0b2bbf4ae0dd7ce4eb27e421a46fbcee16b45461453a6b5ed838f8ee7a")
