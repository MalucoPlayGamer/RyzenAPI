-- Lua provided by RyzenAPI
-- Game: Game: AppID 869740

-- MAIN APPLICATION
addappid(869740)
-- Game: addappid(869740)

-- MAIN APP DEPOTS / PACKAGES
addappid(869741, 1, "401d921a5019dab83fbd59c79236d1df35c52184b330cbf10717f00b4a4b795a")
