-- 4665550's Lua and Manifest Created by Hubcap Manifest
-- Dev Life: Tap & Code
-- Created: July 26, 2026 at 06:01:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4665550) -- Dev Life: Tap & Code
-- MAIN APP DEPOTS
addappid(4665551, 1, "ffb76b0e61b8c5ff1fb7422ab95c5eabe04ac894aebf33fb5dc6f8a38d9ef370") -- Depot 4665551
setManifestid(4665551, "2556513033488223817", 380806071)