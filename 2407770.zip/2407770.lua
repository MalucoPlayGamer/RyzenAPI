-- Lua provided by RyzenAPI
-- Game: Beat Saber - Queen - We Will Rock You

-- MAIN APPLICATION
addappid(2407770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407770,0,"d8f67e8234e74b58483ec23b48b7267a435b8265320aef220815ad20dab1641e")

