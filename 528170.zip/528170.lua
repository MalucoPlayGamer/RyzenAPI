-- Lua provided by RyzenAPI
-- Game: AppID 528170

-- MAIN APPLICATION
addappid(528170)
-- Game: addappid(528170)

-- MAIN APP DEPOTS / PACKAGES
addappid(528171, 1, "a9a36f6e40d30d90a7e5513becba31a001b04660cb4f4e53ee8fa21ae8e726b5")
