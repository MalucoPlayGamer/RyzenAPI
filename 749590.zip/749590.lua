-- Lua provided by RyzenAPI
-- Game: 749590

-- MAIN APPLICATION
addappid(749590)
-- Game: addappid(749590)

-- MAIN APP DEPOTS / PACKAGES
addappid(749590,0,"8f22cab78170f8fdac333fa25eebf1864a86b755af7895d791ff5d08fd547a0b")
