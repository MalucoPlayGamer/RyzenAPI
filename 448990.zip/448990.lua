-- Lua provided by RyzenAPI
-- Game: Phlyndir

-- MAIN APPLICATION
addappid(448990)

-- MAIN APP DEPOTS / PACKAGES
addappid(448991, 1, "a1583d8c4462d6cbe366fb206b212f07b583a25538909bceba209314952626ff")
