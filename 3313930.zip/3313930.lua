-- 3313930's Lua and Manifest Created by Hubcap Manifest
-- Galactic Simulator
-- Created: August 07, 2026 at 23:03:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3313930, 1, "cf3aec8a25fd98ffeb8ab6e6f1a2efb37be56e16725709c122894f7fc12566c1") -- Galactic Simulator
-- MAIN APP DEPOTS
addappid(3313931, 1, "077a42431cae38d8a3183231cc33b6a95e9705edaae950d11928baabb6beb0cd") -- Depot 3313931
setManifestid(3313931, "2904129561827940782", 8960736832)
addappid(3313932, 1, "93eb6d23466eac2326b1b8810c9155d6c5076e3e2813267980ad49c0c8c1e79d") -- Depot 3313932
setManifestid(3313932, "6247717636167714353", 9105204609)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3453300) -- Galactic Simulator Supporter Pack