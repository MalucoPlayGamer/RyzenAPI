-- Lua provided by RyzenAPI 
-- Game: Spirits of the Hellements - TD
addappid(1742610)
addappid(1742611, 1, "a6a8d76f89f0b81ef29f265eed826061fe5191b07814f35b4572255289a7702b")
