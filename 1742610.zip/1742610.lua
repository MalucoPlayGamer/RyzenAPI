-- Lua provided by RyzenAPI
-- Game: Spirits of the Hellements - TD

-- MAIN APPLICATION
addappid(1742610)
-- Game: addappid(1742610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742611, 1, "a6a8d76f89f0b81ef29f265eed826061fe5191b07814f35b4572255289a7702b")
