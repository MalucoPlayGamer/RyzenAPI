-- Lua provided by RyzenAPI 
-- Game: Toolnich Village
addappid(1769150)
addappid(1769151, 1, "11866fafb027d81d370d0b32f8f9f7e037398be1b494e89f185f1136f399d3c7")
