-- Lua provided by RyzenAPI
-- Game: 1769150

-- MAIN APPLICATION
addappid(1769150)
-- Game: addappid(1769150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769151, 1, "11866fafb027d81d370d0b32f8f9f7e037398be1b494e89f185f1136f399d3c7")
