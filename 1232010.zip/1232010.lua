-- Lua provided by RyzenAPI
-- Game: addappid(1232010)

-- MAIN APPLICATION
addappid(1232010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232011, 1, "801fe8d9c842156f96a81816f89cac5bf3769386b57e4b18b36cf04cab2eabfd")
