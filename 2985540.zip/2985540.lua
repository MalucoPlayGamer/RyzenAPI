-- Lua provided by RyzenAPI
-- Game: Game: POGOPPL Demo

-- MAIN APPLICATION
addappid(2985540)
-- Game: addappid(2985540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2985541, 1, "9f93656e6a31346dea19f52e22fbfa90bf67d4734d704cc19a869205e3062137")
