-- Lua provided by RyzenAPI 
-- Game: POGOPPL Demo
addappid(2985540)
addappid(2985541, 1, "9f93656e6a31346dea19f52e22fbfa90bf67d4734d704cc19a869205e3062137")
