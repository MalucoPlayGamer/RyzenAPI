-- Lua provided by RyzenAPI
-- Game: Crazy Truck

-- MAIN APPLICATION
addappid(1776260)
-- Game: addappid(1776260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776261, 1, "72a32fdfd27422d56340a825811dd6ff25336fea2f7deeb69cd1617b84f3ba6e")
