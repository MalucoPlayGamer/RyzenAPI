-- Lua provided by RyzenAPI
-- Game: Game: AppID 652810

-- MAIN APPLICATION
addappid(652810)
-- Game: addappid(652810)

-- MAIN APP DEPOTS / PACKAGES
addappid(652811, 1, "5c7a53cff371b1043e454952aa428e768879fe59635c2d51f300c37575f4241e")
