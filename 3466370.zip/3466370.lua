-- Lua provided by RyzenAPI
-- Game: Mystic Tesserae

-- MAIN APPLICATION
addappid(3466370)
-- Game: addappid(3466370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3466371, 1, "1160f1d371652c6fcf618835b196b109b2d68f89894e32d07dc5d3fa53c0653c")
