-- Lua provided by SkyAPI 
-- Game: Mystic Tesserae
addappid(3466370)
addappid(3466371, 1, "1160f1d371652c6fcf618835b196b109b2d68f89894e32d07dc5d3fa53c0653c")
