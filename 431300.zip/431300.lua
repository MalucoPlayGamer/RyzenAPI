-- Lua provided by RyzenAPI
-- Game: 431300

-- MAIN APPLICATION
addappid(431300)
-- Game: addappid(431300)

-- MAIN APP DEPOTS / PACKAGES
addappid(431301, 1, "3d44832c7d08a48d7b0ee23e0209ccacbd344af31bd5a91838c9c37a7e783acb")
addappid(431302, 1, "b36711309f84bd9ac3768244ff78df9b1fdd6a2bfd453292bfd5d23e05e23f26")
