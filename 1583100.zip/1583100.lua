-- Lua provided by RyzenAPI
-- Game: addappid(1583100)

-- MAIN APPLICATION
addappid(1583100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583100,0,"7f30cb5f714c5c8588805a09c3132eac7568ab54c2ef3f66b1b7c700fb29b394")
