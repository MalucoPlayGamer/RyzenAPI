-- Lua provided by RyzenAPI
-- Game: addappid(1587810)

-- MAIN APPLICATION
addappid(1587810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587811, 1, "793c8549c096d9cec7ab0dacb09e2cd799e62ff46ff0a48811c3e626e94152b4")
