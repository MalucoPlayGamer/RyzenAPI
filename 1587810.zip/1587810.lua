-- Lua provided by SkyAPI 
-- Game: Spell Swap
addappid(1587810)
addappid(1587811, 1, "793c8549c096d9cec7ab0dacb09e2cd799e62ff46ff0a48811c3e626e94152b4")
