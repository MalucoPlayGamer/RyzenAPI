-- Lua provided by RyzenAPI
-- Game: Spiritlands

-- MAIN APPLICATION
addappid(618270)

-- MAIN APP DEPOTS / PACKAGES
addappid(618271, 1, "a0153ed3a0996049611fe7104ebb6755485e7b981b5f5e46c7c4c52e58cab4e0")

