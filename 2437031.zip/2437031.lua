-- Lua provided by RyzenAPI
-- Game: 2437031

-- MAIN APPLICATION
addappid(2437031)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437031,0,"c3043863ca880062b3d9e2c81bf7bcea3587892e69eabd907a15a1afae0baf7f")

