-- Lua provided by RyzenAPI
-- Game: Beyond the Room

-- MAIN APPLICATION
addappid(4883200) -- Beyond the Room

-- MAIN APP DEPOTS / PACKAGES
addappid(4883201, 1, "20510b13d0bc2903d8c754cca660b0d080ca670332da94db3f94893b93da9e68") -- Depot 4883201

