-- Lua provided by RyzenAPI
-- Game: Hitler On The Moon

-- MAIN APPLICATION
addappid(1603200)
-- Game: addappid(1603200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603201, 1, "e6e8efa6a0e0d4c2b50955e318117ddf66bd36bc5be7fdf3fab24caffe2b7e82")
