-- Lua provided by RyzenAPI
-- Game: AppID 2603360

-- MAIN APPLICATION
addappid(2603360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2603361, 1, "fed3cb2285dd194ea3a34ecb78e37b4f2e21f8bc3a28234cce3bb8553d2ba09a")
