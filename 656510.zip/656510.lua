-- Lua provided by RyzenAPI
-- Game: Game: Epic Car Factory

-- MAIN APPLICATION
addappid(656510)
-- Game: addappid(656510)

-- MAIN APP DEPOTS / PACKAGES
addappid(656511, 1, "8b6a8246ba41748b5be3912fda4d65b8fc5c93ff0db1ddfa750fefa32da803b6")
addappid(656512, 1, "0fcbfd4605b81098350647e331365b34acc3871a9f4628e2722de55034c3215f")
addappid(656513, 1, "54093c0abd88b44103758ca0c64b543191c7f15e1fa6256acaed923675383f0f")
addappid(656514, 1, "cafc69455bc3aec4604da58b070ebdbd3e9ed5375b4c3b83d08c6a863f8b3a1a")
addappid(656515, 1, "a0e9905a0aaaba6928ab59433371910191b63389915f12e888624cf70776dcad")
