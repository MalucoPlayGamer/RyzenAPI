-- Lua provided by RyzenAPI
-- Game: Fated Kingdom

-- MAIN APPLICATION
addappid(837400)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(837401, 1, "951f87c2e607da74dfb90e79279a3a1cc0048246b7eb745e8525a6c7b74e0e0a")

