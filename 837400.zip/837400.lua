-- Lua provided by RyzenAPI
-- Game: Game: AppID 837400

-- MAIN APPLICATION
addappid(837400)
-- Game: addappid(837400)

-- MAIN APP DEPOTS / PACKAGES
addappid(837401, 1, "951f87c2e607da74dfb90e79279a3a1cc0048246b7eb745e8525a6c7b74e0e0a")
