-- Lua provided by RyzenAPI
-- Game: 725140

-- MAIN APPLICATION
addappid(725140)
-- Game: addappid(725140)

-- MAIN APP DEPOTS / PACKAGES
addappid(725141, 1, "aaeba794f64e56e0a2c7394d6c97facd80e5cbab0beda33425313aece2117169")
