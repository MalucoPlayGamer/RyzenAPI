-- Lua provided by RyzenAPI
-- Game: Nogard

-- MAIN APPLICATION
addappid(725140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(725141, 1, "aaeba794f64e56e0a2c7394d6c97facd80e5cbab0beda33425313aece2117169")

