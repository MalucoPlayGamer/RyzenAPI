-- Lua provided by RyzenAPI
-- Game: Tropico 6

-- MAIN APPLICATION
addappid(492720)

-- MAIN APP DEPOTS / PACKAGES
addappid(492721, 1, "dd1294f56dcac65ce85f51bb16a22e48be2ae8a6ad5d4ca90c6dab91f11d11e0")
addappid(492722, 1, "3f6d0842f19aa9a1e925efa65af938a7c0787a40772209f04f85b642390a7e7d")
addappid(492723, 1, "a7acf29ed791bbbbeab7db9de495da7a7a8de56210c1ecbfc1a136fd5164bafc")
addappid(492724, 1, "ab2df80459c17b89abb8dc0b273fc0428a0032b6ebc2c5027c98588279068a37")
addappid(492725, 1, "8efc4cf21f7207cea9c32f259680080dac5f5f942aaec8868cfbee4e8de36029")
addappid(492726, 1, "9020266ef836d81e3607a7ef8c032c5d154101593ca7819008fe12e390b2b738")
addappid(492727, 1, "553570b3d73881c17534d6e148cf70cae386b3329d85e5b102865c6abe9b5780")
addappid(492728, 1, "b45380cb07f37f378d256c7db47227896c9fdac77516b840e8290a25d8b59a2f")
addappid(492729, 1, "4188d6855228eedcaf3acee2a1177b56d9cadde1f6564d1fcc8b2d5e8fd07dd4")
addappid(881960, 0, "9a205eb5d636da4082eef0bd4c83938e1eaf7f313cc8f19e3daaae78989b2b24")
addappid(881961, 0, "4acb95226bd1bae883783022f7021263752f0ad2c41657310320ef2252167fb8")
addappid(881962, 0, "17f8cb3323a7e98acdaf4db2607701917ed439757bc8adb8e81f69272de34077")
addappid(881963, 0, "fa30a245f1c36ba45e97fe5366ffcc2d17c2b22f510ddc1c788b4260099e5af6")
addappid(881964, 0, "cdcb5067d4bd9abc27cdf0c5bc5e389b5c04cd3d9b864539e4e5ef12c45b6e25")
addappid(881965, 0, "e8c37b294ead4c0599777edbd97dd724ceb7c1140fb8a6cf165a0ac83cd140a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1100250)
addappid(1259750)
addappid(1282350)
addappid(1449310)
addappid(1631380)
addappid(2186250)
addappid(2594010)
addappid(2938080)
addappid(3391380)
