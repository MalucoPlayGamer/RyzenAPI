-- Lua provided by RyzenAPI
-- Game: Cyber Ops

-- MAIN APPLICATION
addappid(863460)

-- MAIN APP DEPOTS / PACKAGES
addappid(863461, 1, "90f78114a9a9ea4d97e5a38fe3ac5331a3e257c89a106df84020609400d40cd5")
