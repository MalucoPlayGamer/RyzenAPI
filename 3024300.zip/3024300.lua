-- Lua provided by RyzenAPI
-- Game: Game: Who is Abby Demo

-- MAIN APPLICATION
addappid(3024300)
-- Game: addappid(3024300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3024301, 1, "12e1ac0a34ca5fb74f985abf77c990e155fa27051a4341dcc6d2d6b61eb4fad5")
