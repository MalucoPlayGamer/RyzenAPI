-- Lua provided by RyzenAPI
-- Game: ASSASSINATION BOX

-- MAIN APPLICATION
addappid(551550)
addappid(552680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(551551, 1, "dea6c863a9cc0b355a8e10daf3998feb86c8dbda231c9d1b9eb28e5821d969ea")

