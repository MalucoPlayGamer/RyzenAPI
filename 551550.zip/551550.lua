-- Lua provided by RyzenAPI
-- Game: addappid(551550)

-- MAIN APPLICATION
addappid(551550)

-- MAIN APP DEPOTS / PACKAGES
addappid(551551, 1, "dea6c863a9cc0b355a8e10daf3998feb86c8dbda231c9d1b9eb28e5821d969ea")
