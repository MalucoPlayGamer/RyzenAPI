-- Lua provided by RyzenAPI
-- Game: AppID 1027220

-- MAIN APPLICATION
addappid(1027220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027221, 1, "cc5f959d4cb89d14a6aefe281136de24a183b0282687f1bbe126762eb6eda33d")
