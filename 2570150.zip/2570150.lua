-- Lua provided by RyzenAPI
-- Game: 2570150

-- MAIN APPLICATION
addappid(2570150)
-- Game: addappid(2570150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570151, 1, "7b34a5645977f5f13872df08bc01e3df28abe577f10c52d87c1292bf8eebf8ba")
