-- Lua provided by RyzenAPI
-- Game: addappid(1288420)

-- MAIN APPLICATION
addappid(1288420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288421, 1, "af95aa0c04e33160e4a27c32596963eb1e52b4fc81e8bb9c40397e34ea8f2621")
