-- Lua provided by RyzenAPI
-- Game: DreamLand

-- MAIN APPLICATION
addappid(498510)

-- MAIN APP DEPOTS / PACKAGES
addappid(498511, 1, "52cfe2d73ed278a8d4a7a0a5c0bdfb022cac5aa52e0b24f00ef0daef6cbfc1bf")

