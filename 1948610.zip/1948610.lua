-- Lua provided by RyzenAPI
-- Game: AppID 1948610

-- MAIN APPLICATION
addappid(1948610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948611, 1, "7240baf51af2f1ff163e5baa4ad655d899493e1cf6241fca9b5fad087dfedb1d")

