-- Lua provided by RyzenAPI
-- Game: 3099000

-- MAIN APPLICATION
addappid(3099000)
-- Game: addappid(3099000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099001, 1, "b796e08fa994d42f500dfea5db6515409779cc50c6e94a719f862ed2d2c0af43")
