-- Lua provided by RyzenAPI
-- Game: Marble Age: Remastered

-- MAIN APPLICATION
addappid(383740)

-- MAIN APP DEPOTS / PACKAGES
addappid(383742,0,"9316bc633b222276456b7fdbbf300dc90785e30933c547fa613dd0cb3acfbf9c")
addappid(383743,0,"747e88474115bae47b95eabd4d62dfb25150341db9cc8eea67ad931317ef81d0")
addappid(383744,0,"0a34c6348bc6dcad290a8b942483aa9935d31c80645e196af08eeb0cc3224739")
