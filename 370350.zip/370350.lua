-- Lua provided by RyzenAPI
-- Game: LOTUS-Simulator

-- MAIN APPLICATION
addappid(370350)
addappid(374760)
addappid(374770)
addappid(374871)
addappid(378460)
addappid(378461)
addappid(2691300)

-- MAIN APP DEPOTS / PACKAGES
addappid(370358,0,"e9e09ca0f93c24f635b292e6437a50f8f9f86a16b0dcee8cf4a64e0e5e2c14ff")
addappid(370359,0,"dea1d19136250bca194d02a1cf8a1232f7526825866575b29cf667cbca84083b")
addappid(374861,0,"1ff0f31e1ff70e6a5e834a27aaf46f5f4a907e1b9922865d7ce2dd98da78c5d6")

