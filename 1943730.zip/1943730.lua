-- Lua provided by RyzenAPI
-- Game: Wicked Island

-- MAIN APPLICATION
addappid(1943730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943731, 1, "81c0549cd66717388a81657fc3ddbc0fbd441454791cd86b4772a77adb01fc89")
