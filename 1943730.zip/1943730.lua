-- Lua provided by RyzenAPI
-- Game: Wicked Island

-- MAIN APPLICATION
addappid(1943730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943731, 1, "81c0549cd66717388a81657fc3ddbc0fbd441454791cd86b4772a77adb01fc89")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
