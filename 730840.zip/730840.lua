-- Lua provided by RyzenAPI 
-- Game: AppID 730840
addappid(730840)
addappid(730841, 1, "0a706cc85da5039a99a5dd59ff49e59f7719ad95e15cda36c046de61351152c7")
addappid(730842, 1, "3a4ab2807b553362a622f2ccc3e24cbda646b81131713a693c62f11d942d5622")
