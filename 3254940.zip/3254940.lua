-- Lua provided by RyzenAPI
-- Game: My Putrid Ponies

-- MAIN APPLICATION
addappid(3254940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3254941, 1, "e66c54de5422bc8d96fcba1397a1bc4081a9d21a83af4897392b9dd5dcfbcb0c")

