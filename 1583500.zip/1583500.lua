-- Lua provided by SkyAPI 
-- Game: AppID 1583500
addappid(1583500)
addappid(1583501, 1, "b9100a16b63006ed8f608b1d4baebc8f650c916e661663f2a0743c63f4db6774")
