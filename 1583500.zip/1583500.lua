-- Lua provided by RyzenAPI
-- Game: Eternal Dread 3

-- MAIN APPLICATION
addappid(1583500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583501, 1, "b9100a16b63006ed8f608b1d4baebc8f650c916e661663f2a0743c63f4db6774")
