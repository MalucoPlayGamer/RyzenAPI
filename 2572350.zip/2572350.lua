-- Lua provided by RyzenAPI
-- Game: Game: AppID 2572350

-- MAIN APPLICATION
addappid(2572350)
-- Game: addappid(2572350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2572351, 1, "2cf6a4167717454c4b90429da2143a83602d5f1af83be85ea1abb3b17ed5a2c6")
