-- Lua provided by RyzenAPI 
-- Game: AppID 2572350
addappid(2572350)
addappid(2572351, 1, "2cf6a4167717454c4b90429da2143a83602d5f1af83be85ea1abb3b17ed5a2c6")
