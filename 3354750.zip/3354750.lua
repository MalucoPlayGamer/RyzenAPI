-- Lua provided by RyzenAPI
-- Game: skate.

-- MAIN APPLICATION
addappid(3354750)
addappid(3354800)
addappid(3354810)
addappid(3354820)
addappid(3494010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354751, 1, "12f0eab99e98b8912cb7e80d06eb068409135cc2968fc071880ac3f5850e1722")

