-- 3354750's Lua and Manifest Created by Hubcap Manifest
-- skate.
-- Created: August 07, 2026 at 08:46:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 9
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3354750, 1, "8da710686b19b8e033c9162f2007f5fd51bbe31f8985ebcb59094f7f636ad4f3") -- skate.
-- MAIN APP DEPOTS
addappid(3354751, 1, "12f0eab99e98b8912cb7e80d06eb068409135cc2968fc071880ac3f5850e1722") -- Depot 3354751
setManifestid(3354751, "7298251582320541887", 13092544319)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(3893181, 1, "7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6") -- Depot 3893181 (Shared from App 3893180)
setManifestid(3893181, "1558442456104985494", 333590753)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3354800) -- skate. Meatman Cosmetics and 3,100 San Van Bucks
addappid(3354810) -- skate. - skate Tees and Vans Founders Shoes
addappid(3354820) -- skate. - Mocap Cosmetics and 2,800 San Van Bucks
addappid(3494010) -- skate. - Founding Founders Cosmetics and S1 skate.Pass
addappid(4103880) -- skate. - Season 2 Starter Pack
addappid(4115210) -- skate. - Season 3 Starter Pack
addappid(4115220) -- skate. - Thrasher Season 4 Starter Pack
addappid(4573910) -- skate. - Dem Bones Pack
addappid(4573920) -- skate. - Dem Bones Deluxe Pack