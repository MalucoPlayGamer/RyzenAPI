-- Lua provided by RyzenAPI
-- Game: EMPTY SHELL

-- MAIN APPLICATION
addappid(2243110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243111, 1, "aad786dc745df38b6d2bacc92cb92b1cecf32be45eaffe3682bc8c786041aa7d")
