-- Lua provided by RyzenAPI
-- Game: Space Empires II

-- MAIN APPLICATION
addappid(1430140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430141, 1, "061c6e281467893481b4c9e5c8ab5b7d939a6a6b887afeb1fcf4396fecd2182a")
