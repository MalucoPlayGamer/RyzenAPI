-- Lua provided by RyzenAPI
-- Game: AppID 342310

-- MAIN APPLICATION
addappid(342310)
addappid(377580)
-- Game: addappid(342310)

-- MAIN APP DEPOTS / PACKAGES
addappid(342311, 1, "d26f9ad2119e59bd4cf2023b9ea0b1ed2fd7511f83006ff36b1a13bbc5d59c42")
addappid(342312, 1, "52c364754f10812ceea13615fe5d597a96d7b8a6162f30487a07ef970e5e1eff")
addappid(342313, 1, "587b397fa8a3da82bfab8c2d582f3b55300a6c9bb4c115d11d5bd32fd5fee6a3")
addappid(1034550, 0, "4a728e40acde5ce5d22e463cd690f7ecf8dd59babaefd1c634a730e822fb18f9")
