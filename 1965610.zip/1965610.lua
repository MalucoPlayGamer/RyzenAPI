-- Lua provided by SkyAPI 
-- Game: Froggie
addappid(1965610)
addappid(1965611, 1, "d43aeaae241a2aa9d59b5b0f166f31de03b88f0d4a4a64229bf687e2ad5b373b")
