-- Lua provided by RyzenAPI
-- Game: The Wonderful 101: Remastered

-- MAIN APPLICATION
addappid(1190400)
-- Game: addappid(1190400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190401, 1, "fd8eb6da527d7a70dad9f7c660d44bd6d6a1881e393f650a5909268bc952c665")
addappid(1521860, 0, "43093b8975b69a10ba9fcb5cc30b8857b7978c813fb64178cb52afb15cdea52d")
addappid(1658810, 0, "05a40defafedab8bd1246fe49aebb2c32ac78bcf19ee71973b378f54deb6061b")
addappid(2353290, 0, "3ee3d6b432501bb2e3754f6e134701d2a097f19d6b37ad45a6d4faf8c46cecaf")
addappid(2353300, 0, "57e0d9395dc375791d2144b527f9340843547ce32dbc5fbdfd3fc02d4edc32d1")
