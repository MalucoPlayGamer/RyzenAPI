-- Lua provided by SkyAPI 
-- Game: Weable 2
addappid(765160)
addappid(765161, 1, "9db299b3b613d12865ec2ab6608e6272ace985ae9fffc48fca27e1ee87e27ad0")
