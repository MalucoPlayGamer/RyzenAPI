-- Lua provided by RyzenAPI
-- Game: Midnight Ghost Hunt Dedicated Server

-- MAIN APPLICATION
addappid(1118810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118811, 1, "71634d9e66b26d622181be81b6590a57ca1bdee6a116150748a418b7b7e50bf1")
