-- Lua provided by RyzenAPI
-- Game: 438260

-- MAIN APPLICATION
addappid(438260)
-- Game: addappid(438260)

-- MAIN APP DEPOTS / PACKAGES
addappid(438261, 1, "31fe4d45d2a0e113beae86aa9a722afeb66ea0060dd059adb67112ee9359110b")
