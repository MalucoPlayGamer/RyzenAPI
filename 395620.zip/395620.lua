-- Lua provided by RyzenAPI
-- Game: Ittle Dew 2+

-- MAIN APPLICATION
addappid(395620)

-- MAIN APP DEPOTS / PACKAGES
addappid(395621, 1, "b6b2f7f40aeb8e30707b48d7906a628690c2a495e8bd7cee4167fa2a1a55d98a")
addappid(395622, 1, "48cac3e731ae432f6368e26868ab21fa6ddba9acdbe311a0454dd9889a73dd3f")
addappid(395623, 1, "84a9f2b979408646227996521d322b1c833c508c9f41c2fe0b84bf7b3e234b65")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
