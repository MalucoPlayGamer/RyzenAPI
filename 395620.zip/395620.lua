-- Lua provided by RyzenAPI
-- Game: Ittle Dew 2+

-- MAIN APPLICATION
addappid(395620)
-- Game: addappid(395620)

-- MAIN APP DEPOTS / PACKAGES
addappid(395621, 1, "b6b2f7f40aeb8e30707b48d7906a628690c2a495e8bd7cee4167fa2a1a55d98a")
addappid(395622, 1, "48cac3e731ae432f6368e26868ab21fa6ddba9acdbe311a0454dd9889a73dd3f")
addappid(395623, 1, "84a9f2b979408646227996521d322b1c833c508c9f41c2fe0b84bf7b3e234b65")
