-- Lua provided by RyzenAPI
-- Game: 546790

-- MAIN APPLICATION
addappid(546790)
-- Game: addappid(546790)

-- MAIN APP DEPOTS / PACKAGES
addappid(546791, 1, "1f3fed69a5b9d9c4b6392b5fc3cff424e341e72f9b6c8e091823a643466942d6")
