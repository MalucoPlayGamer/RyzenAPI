-- Lua provided by RyzenAPI
-- Game: AppID 546790

-- MAIN APPLICATION
addappid(546790)

-- MAIN APP DEPOTS / PACKAGES
addappid(546791, 1, "1f3fed69a5b9d9c4b6392b5fc3cff424e341e72f9b6c8e091823a643466942d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
