-- Lua provided by RyzenAPI
-- Game: GameAssistant: The Tool For Every Gamer

-- MAIN APPLICATION
addappid(1190750)
addappid(1220130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190751, 1, "24d71c2c25a63fb29b22fec5d0ae658124fe891356a490c87c9d2d45a2ba1a1e")
