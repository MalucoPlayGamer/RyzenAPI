-- Lua provided by RyzenAPI
-- Game: Cat Isle

-- MAIN APPLICATION
addappid(4018550)

-- MAIN APP DEPOTS / PACKAGES
addappid(4018551,0,"fdd99a76ae0c605a08b9e78b09b69596dff0dabf19041f50de387b8deee8d05e")
addappid(4018552,0,"4a6751d2e0f24a4d793773a9f2a5101f215157549dd3d5d4f1c8f65cac5afce9")

