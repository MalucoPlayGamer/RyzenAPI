-- Lua provided by RyzenAPI
-- Game: Call of Senpai: Waifu Warfare 2

-- MAIN APPLICATION
addappid(1893530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893531, 1, "114512d40bdec76bc8273373e8954f9a257721947c8398e0e4baaeead54db842")
