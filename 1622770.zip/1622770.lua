-- Lua provided by RyzenAPI
-- Game: Doors: Paradox

-- MAIN APPLICATION
addappid(1622770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622771, 1, "63aba965828b702fb14d37314011ac649acf4f09e1e55a9a25a3c43b7ab402cd")

