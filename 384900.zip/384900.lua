-- Lua provided by RyzenAPI
-- Game: Temporal Shift

-- MAIN APPLICATION
addappid(384900)

-- MAIN APP DEPOTS / PACKAGES
addappid(384901, 1, "4e8f368880409b50e824cbe5ae91c1b52e8bc995b508d2bd5f0a30be96d07795")

