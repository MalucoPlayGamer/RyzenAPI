-- Lua provided by RyzenAPI
-- Game: Game: AppID 2868040

-- MAIN APPLICATION
addappid(2868040)
-- Game: addappid(2868040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868041, 1, "8a825f639961d16ae016c1694976eba6745c3b1266e047a47e5fe2c2c06e4860")
