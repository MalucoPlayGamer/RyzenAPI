-- Lua provided by RyzenAPI
-- Game: 2383070

-- MAIN APPLICATION
addappid(2383070)
-- Game: addappid(2383070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383070,0,"2ad3b0c8e7b7712b12e74a4c9d00ec5bafed84214cce6df42da32f042c83478a")
