-- Lua provided by RyzenAPI
-- Game: AppID 418250

-- MAIN APPLICATION
addappid(418250)

-- MAIN APP DEPOTS / PACKAGES
addappid(418251, 1, "93b4fe63c75a877c2d453bb45f5769db921299fceff7fb160ba641dec17cf977")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(620680)
