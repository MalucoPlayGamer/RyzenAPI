-- Lua provided by RyzenAPI
-- Game: 443380

-- MAIN APPLICATION
addappid(443380)
-- Game: addappid(443380)

-- MAIN APP DEPOTS / PACKAGES
addappid(443381, 1, "abfd13634366e4eb9cb44752ea7f3d0c694fbf3e1b6703512ce43dbc82536ec5")
