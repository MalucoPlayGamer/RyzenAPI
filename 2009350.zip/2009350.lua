-- Lua provided by SkyAPI 
-- Game: Out of Ore
addappid(2009350)
addappid(2009351, 1, "41a1bb5707b6d179fc15f341ee3f4481b7d28f3a571eec865f526783430a26a8")
