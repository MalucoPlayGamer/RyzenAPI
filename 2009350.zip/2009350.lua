-- Lua provided by RyzenAPI
-- Game: addappid(2009350)

-- MAIN APPLICATION
addappid(2009350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009351, 1, "41a1bb5707b6d179fc15f341ee3f4481b7d28f3a571eec865f526783430a26a8")
