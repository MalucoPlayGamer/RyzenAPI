-- Lua provided by RyzenAPI
-- Game: Disc Golf Online

-- MAIN APPLICATION
addappid(2083540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083541, 1, "3f215ac3642699ebde4d352d79dc02f4fe9ab7a5d8f22700160d9024b14ca630")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
