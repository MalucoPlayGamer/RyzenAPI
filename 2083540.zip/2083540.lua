-- Lua provided by RyzenAPI
-- Game: 2083540

-- MAIN APPLICATION
addappid(2083540)
-- Game: addappid(2083540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083541, 1, "3f215ac3642699ebde4d352d79dc02f4fe9ab7a5d8f22700160d9024b14ca630")
