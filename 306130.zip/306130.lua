-- Lua provided by RyzenAPI
-- Game: Game: AppID 306130

-- MAIN APPLICATION
addappid(306130)
-- Game: addappid(306130)

-- MAIN APP DEPOTS / PACKAGES
addappid(306131, 1, "efe4e3dbd8640a7ad50003146af400ca0cfba95e16374e834ae08010ff8ec048")
