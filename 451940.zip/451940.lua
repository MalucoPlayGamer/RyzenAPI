-- Lua provided by RyzenAPI
-- Game: addappid(451940)

-- MAIN APPLICATION
addappid(451940)

-- MAIN APP DEPOTS / PACKAGES
addappid(451941, 1, "025f8c274d2bb02fc76ddf9fc7698098a967d04730b00f7367f988e854d0e5c3")
