-- Lua provided by RyzenAPI
-- Game: Snake vs Snake

-- MAIN APPLICATION
addappid(1005310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1005311, 1, "685a7f19fe56045196e5733c20ccfcaf644e9ba7a1e31afbaee696169609ffd8")

