-- Lua provided by RyzenAPI 
-- Game: Snake vs Snake
addappid(1005310)
addappid(1005311, 1, "685a7f19fe56045196e5733c20ccfcaf644e9ba7a1e31afbaee696169609ffd8")
