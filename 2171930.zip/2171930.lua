-- Lua provided by RyzenAPI 
-- Game: DEATHWATCH - PRELUDE
addappid(2171930)
addappid(2171931, 1, "f857a09c69d2520a40cd25f43d7210a41b47a212503585df1f6d3465e994a57e")
