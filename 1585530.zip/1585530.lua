-- Lua provided by RyzenAPI
-- Game: GW: Legacy

-- MAIN APPLICATION
addappid(1585530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585531, 1, "22abbff8dc91a72a180edc54ebe5ee6dbb2f7acebe1b3e1631db5be6c5ee0181")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
