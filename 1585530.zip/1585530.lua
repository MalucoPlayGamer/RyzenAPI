-- Lua provided by RyzenAPI 
-- Game: GW: Legacy
addappid(1585530)
addappid(1585531, 1, "22abbff8dc91a72a180edc54ebe5ee6dbb2f7acebe1b3e1631db5be6c5ee0181")
