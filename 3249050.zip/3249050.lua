-- Lua provided by RyzenAPI
-- Game: Tap 4 Sex

-- MAIN APPLICATION
addappid(3249050)
addappid(3783140)
-- Game: addappid(3249050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249051, 1, "fd15f7e4566aef8ab5ac7b08f42cd6e357cffe18d894de30cdcc800cca25de94")
