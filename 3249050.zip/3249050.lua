-- Lua provided by RyzenAPI
-- Game: Tap 4 Sex

-- MAIN APPLICATION
addappid(3249050)
addappid(3783140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249051, 1, "fd15f7e4566aef8ab5ac7b08f42cd6e357cffe18d894de30cdcc800cca25de94")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
