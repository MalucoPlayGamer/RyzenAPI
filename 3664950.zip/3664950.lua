-- Lua provided by RyzenAPI 
-- Game: My Bimbo Dream - Art Hunt Minigame
addappid(3664950)
addappid(3664951, 1, "08c174eeed51f79032d5d231ad970b8d117a8df542e4d1f577abfe4ed58b0cc3")
