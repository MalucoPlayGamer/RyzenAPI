-- Lua provided by RyzenAPI
-- Game: First Sexy Night

-- MAIN APPLICATION
addappid(2060760)
addappid(2090850)
-- Game: addappid(2060760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060761, 1, "b3c538482d82e6037a05c543920b28b3e756744d89e62074a88673f3824cae8a")
