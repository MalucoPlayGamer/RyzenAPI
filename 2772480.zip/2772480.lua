-- Lua provided by RyzenAPI
-- Game: My COUSIN is a FEMBOY

-- MAIN APPLICATION
addappid(2772480)
-- Game: addappid(2772480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772481, 1, "536abe051a6d1f3a75e9aa29d8a9c25005d0c671e309eea708b2e3e87f9cc944")
