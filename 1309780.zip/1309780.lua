-- Lua provided by RyzenAPI
-- Game: addappid(1309780)

-- MAIN APPLICATION
addappid(1309780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309781, 1, "16bc3081bd778d84a7de79fdd11259c6d0e7a17805fddb5807c15114c0561d66")
