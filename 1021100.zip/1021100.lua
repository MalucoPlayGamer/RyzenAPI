-- Lua provided by RyzenAPI
-- Game: Aircraft Carrier Survival

-- MAIN APPLICATION
addappid(1021100)
addappid(2288452)
addappid(2288453)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021102,0,"08879a03b02c6b6da4a608b5082c8de9a0d31e45188f521d910a44ecd7ab53ee")
addappid(2288450,0,"983957eb5fe4cd164a816d5b2402321fdea581d75ae0415dacec26eda891d905")
addappid(2288451,0,"24cc3c1ca555514f54c957c1098d656669029b8bea087b3670b881d0adc242e8")
