-- Lua provided by RyzenAPI
-- Game: AppID 493730

-- MAIN APPLICATION
addappid(493730)
addappid(500780)
addappid(574680)

-- MAIN APP DEPOTS / PACKAGES
addappid(493731, 1, "776d5b0afbbb07aee19ef7578506ae95a45f464accf2da20e95dc64cd03061fa")
addappid(493732, 1, "6c2e4b84e8a895edf987495503502ed6c7d0e44bf5748ad380616c25b64f6c81")
addappid(493733, 1, "25f0da6ec29ccd29dcf43b6b59d58dada110aeb9fc5997598cf35c8db31bd21a")
