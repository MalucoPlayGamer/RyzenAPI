-- Lua provided by RyzenAPI
-- Game: Game: Drox Operative 2

-- MAIN APPLICATION
addappid(1305310)
-- Game: addappid(1305310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305311, 1, "cd31a449b9596d90d5a1721520e81d2b69dcd949afe0fcb22cf36f10d6915702")
addappid(1305312, 1, "4ed9dc8a65d57358bad9a8203f45898de97077529a039bd8818613992155da36")
