-- Lua provided by RyzenAPI
-- Game: My First Femboy Date

-- MAIN APPLICATION
addappid(2097540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2097541, 1, "bd2662a15eb7f47bc05c6afb73b4f1ca114cea224597f881b4f946686f5685a9")

