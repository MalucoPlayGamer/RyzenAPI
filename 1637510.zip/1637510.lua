-- Lua provided by RyzenAPI
-- Game: Whitehaven

-- MAIN APPLICATION
addappid(1637510)
-- Game: addappid(1637510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637511, 1, "8cf33246f882e105d8bc601909718a5e4c4ef7aef54de2ca6fb1d1b6f6f66be0")
