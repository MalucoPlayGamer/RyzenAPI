-- Lua provided by RyzenAPI
-- Game: addappid(2796090)

-- MAIN APPLICATION
addappid(2796090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2796091, 1, "919650dab1bac1d95bebb05bd97de719d0e06297056995616696c9d1da4919f5")
