-- Lua provided by RyzenAPI
-- Game: addappid(2529180)

-- MAIN APPLICATION
addappid(2529180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529181, 1, "466d4060d979556f5e3f4c5eda9377581195ec769b6ee52674c16f8ba60d6a7d")
