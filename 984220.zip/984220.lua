-- Lua provided by RyzenAPI
-- Game: Alien 911

-- MAIN APPLICATION
addappid(984220)
-- Game: addappid(984220)

-- MAIN APP DEPOTS / PACKAGES
addappid(984221, 1, "12c37aa49979b8308de0e519a08d4167e0757d782b6dbbaa78f45c02cc186b1c")
