-- Lua provided by RyzenAPI
-- Game: Railroad Tycoon 3

-- MAIN APPLICATION
addappid(7610)

-- MAIN APP DEPOTS / PACKAGES
addappid(7611, 1, "eae8f03ea5a8e30606359ecff5ef1c5ff03f7780356878374142aa3dda69bf98")
addappid(7612, 1, "d56ac8937fec55d92555531b68368a5819aece97e002eb8a992a2ef00247d171")
addappid(7613, 1, "a1d0a8215d552a99e940dcc4ea825127447b2e1bbc918f850b3d2f5a16dfb8a4")
addappid(7614, 1, "28d37c2d1cec31570dc5334819e7f1d15deb713f4ad0c314ccc656f9d2d2e318")
addappid(7615, 1, "726d190cd06c974c3f7fb4f4065c44bedb09a176d9a0484428fed3479160e72c")

