-- Lua provided by RyzenAPI
-- Game: Let Them Come

-- MAIN APPLICATION
addappid(505630)

-- MAIN APP DEPOTS / PACKAGES
addappid(505631, 1, "55ec10d75f8b42f110a8eabcc098eebeb4069e03657d7d789232ba7dbe05c22b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
