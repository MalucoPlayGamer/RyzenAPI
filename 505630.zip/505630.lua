-- Lua provided by RyzenAPI
-- Game: Let Them Come

-- MAIN APPLICATION
addappid(505630)
-- Game: addappid(505630)

-- MAIN APP DEPOTS / PACKAGES
addappid(505631, 1, "55ec10d75f8b42f110a8eabcc098eebeb4069e03657d7d789232ba7dbe05c22b")
