-- Lua provided by SkyAPI 
-- Game: AppID 1082110
addappid(1082110)
addappid(1082111, 1, "383578d8687cc7e1d5e604a9c60686a980e2ae3c1ddcbb04adc0a30a9ccdc7ba")
