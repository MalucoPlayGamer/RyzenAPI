-- Lua provided by RyzenAPI
-- Game: Spherecraft

-- MAIN APPLICATION
addappid(1074370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074371, 1, "b98b144590485fa4c0a9e9c9a93ea87883758aa1fda3f7ea9cb7b709ee58197b")

