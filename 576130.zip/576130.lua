-- Lua provided by RyzenAPI
-- Game: 576130

-- MAIN APPLICATION
addappid(576130)
-- Game: addappid(576130)

-- MAIN APP DEPOTS / PACKAGES
addappid(576131, 1, "b0a691ae228e5d0c1e28b9f12553ac4a1e2f0157c23b78d242f9285194f0aea4")
addappid(576132, 1, "f466bb0fb019c837fc2fc0619ef24ac24cc0cc88c7fc0e6dd4b7ed619c2755cc")
addappid(576133, 1, "acf725f7bd8cbfe08d65d797aa8e11555a7b94e9bd0fef23135f8821c2a9b3d4")
