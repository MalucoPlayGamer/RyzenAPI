-- Lua provided by RyzenAPI
-- Game: Breakthru

-- MAIN APPLICATION
addappid(2836340)
-- Game: addappid(2836340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2836343,0,"39ecc26e8dd188c20377073b6909b34a755f0787ccdced960d9356a96bd9449a")
