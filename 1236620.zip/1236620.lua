-- Lua provided by RyzenAPI
-- Game: Endurium

-- MAIN APPLICATION
addappid(1236620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1236621, 1, "ad3b3054537fda35b2d38b5bf016cce96889a8d195da46ca6ded979ca0d2b2d2")

