-- Lua provided by RyzenAPI
-- Game: Drift Legends

-- MAIN APPLICATION
addappid(794050)

-- MAIN APP DEPOTS / PACKAGES
addappid(794051,0,"6cd62a56c24069dce69e2cf25b2c3d5e1983fc12cef828d994e4999c55de45e4")

