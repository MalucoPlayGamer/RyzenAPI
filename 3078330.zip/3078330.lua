-- Lua provided by SkyAPI 
-- Game: Xeno Rangers
addappid(3078330)
addappid(3078331, 1, "f59d45e2a73a64228f82a607c57ab8e0a48e6db3015f8cedd2fc8cac3b2a4a80")
