-- Lua provided by RyzenAPI
-- Game: The Peresmeshnik

-- MAIN APPLICATION
addappid(1353370)
-- Game: addappid(1353370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353371, 1, "cff7b4b96d09e4c99b71fe39f69044d3aa0857ed9051db452b1cbcdee6a27232")
