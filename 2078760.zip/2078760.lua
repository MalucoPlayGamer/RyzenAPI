-- Lua provided by RyzenAPI
-- Game: addappid(2078760)

-- MAIN APPLICATION
addappid(2078760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078761, 1, "9774e65be6f70268e28ea62c126afa726e1a67bd68aa7d252d133dee12d93ec8")
