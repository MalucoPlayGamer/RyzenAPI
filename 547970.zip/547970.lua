-- Lua provided by RyzenAPI
-- Game: Celestial Breach

-- MAIN APPLICATION
addappid(547970)

-- MAIN APP DEPOTS / PACKAGES
addappid(547971,0,"917bf9c00b76069abaf517d17d5e861a5a0f26197dfc18d0b856e189393c97d1")
addappid(595901,0,"cbb828d613cb79bc395726985c202b5228903aceda4ab1c7c7bf408716ad7ccf")

