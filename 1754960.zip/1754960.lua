-- Lua provided by RyzenAPI
-- Game: Astride

-- MAIN APPLICATION
addappid(1754960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754963,0,"713d92e5c6212a0b8c9205206204f8b7ff500c6f2ef62fcc0cd54283d1d723d0")
