-- Lua provided by RyzenAPI
-- Game: addappid(1717570)

-- MAIN APPLICATION
addappid(1717570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717571, 1, "3bd16976a1ada8f2d20970a5ee1556aa0eeae354dd23fb81e393182befa6d713")
