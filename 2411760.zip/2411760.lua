-- Lua provided by RyzenAPI
-- Game: A Collection of Mini-Games

-- MAIN APPLICATION
addappid(2411760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411761, 1, "9e64f346bd45a90b3f0e0ff0f2f686489f36bb8224d31db48c680bb43a2cf049")
