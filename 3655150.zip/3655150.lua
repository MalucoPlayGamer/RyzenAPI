-- Lua provided by RyzenAPI
-- Game: addappid(3655150)

-- MAIN APPLICATION
addappid(3655150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655151, 1, "206e7abde00a238e00fe011204e6ad561dec4699aa698664ec8b87e80b33182b")
