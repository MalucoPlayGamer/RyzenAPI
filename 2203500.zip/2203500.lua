-- Lua provided by RyzenAPI
-- Game: addappid(2203500)

-- MAIN APPLICATION
addappid(2203500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203501, 1, "a4213893611c3ecb0bb6ab832c50dd1286e279e36d297bfb89ccfca09fdd12c8")
