-- Lua provided by RyzenAPI
-- Game: 灭顶之灾（crowning calamity)

-- MAIN APPLICATION
addappid(1884410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1884411, 1, "14ef17bb39d9e21acdfeaf580b96fdde147072f1d51d712f91940c5313281e24")

