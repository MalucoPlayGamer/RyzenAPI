-- Lua provided by RyzenAPI
-- Game: 灭顶之灾（crowning calamity)

-- MAIN APPLICATION
addappid(1884410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884411, 1, "14ef17bb39d9e21acdfeaf580b96fdde147072f1d51d712f91940c5313281e24")

