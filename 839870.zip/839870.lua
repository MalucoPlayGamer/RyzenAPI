-- Lua provided by RyzenAPI
-- Game: 839870

-- MAIN APPLICATION
addappid(839870)
-- Game: addappid(839870)

-- MAIN APP DEPOTS / PACKAGES
addappid(839871, 1, "a009282167f5c36851a9c723a45f4094dfe0a9ddf66aac7b826cc2f4f3ff8a00")
addappid(839872, 1, "38b5a59195befbbace3d0dd741a58d0559fc311c7724a7c6e9713c8f9d1654fb")
