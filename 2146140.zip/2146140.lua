-- Lua provided by RyzenAPI
-- Game: 2146140

-- MAIN APPLICATION
addappid(2146140)
-- Game: addappid(2146140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146141, 1, "c747cfb10c3175fc0d2400592be76f7e75c7a3a701d410b2dcd72e300b0d9540")
