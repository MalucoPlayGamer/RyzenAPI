-- Lua provided by RyzenAPI
-- Game: Overgrowth

-- MAIN APPLICATION
addappid(25000)
addappid(271810)

-- MAIN APP DEPOTS / PACKAGES
addappid(25001, 1, "be3e6307428128521e6482890477186e21b585673dd6ae8a3bc7b259bf178b17")
addappid(25002, 1, "257d7d96a0d09402ce7d74eeb57bee5eae885cb29874989b87eb1759bf664b58")
addappid(25003, 1, "90252db22434476beb3ec3e8c122a39c7b1eb8125fedfa7891e18e5f26357279")
addappid(25004, 1, "75d522644fabb73355aa7687fb5ee22a7bba4783157c2a58e2f54f75eb23c49f")
addappid(25005, 1, "22e8ba83cd687fb2f62bc2420880e547e804042d80248ff0fff902fbee536dd4")
addappid(25006, 1, "0c6341a3b074a2fbb0a091de51910d9177da7c5bae880eb7a0f7211618849830")
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

