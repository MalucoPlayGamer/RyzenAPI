-- Lua provided by RyzenAPI
-- Game: MacGuffin's Curse

-- MAIN APPLICATION
addappid(58230)

-- MAIN APP DEPOTS / PACKAGES
addappid(58231, 1, "3746dc834c2e9203878cfc1ccfb57f994d79a5288e1aac499bbdba38808444c2")
