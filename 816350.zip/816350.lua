-- Lua provided by RyzenAPI
-- Game: The Flood

-- MAIN APPLICATION
addappid(816350)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(816390)
