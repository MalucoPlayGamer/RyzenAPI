-- Lua provided by RyzenAPI
-- Game: The Flood

-- MAIN APPLICATION
addappid(816350)
addappid(816390)

