-- Lua provided by RyzenAPI
-- Game: Futariuum's Gate

-- MAIN APPLICATION
addappid(3084620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3084621, 1, "a467958c737b11f3315fc5c64080088e2f636849f56fde74fd2d83af86f0a640")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3106940)
addappid(3106950)
addappid(3106960)
