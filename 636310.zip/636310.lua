-- Lua provided by RyzenAPI
-- Game: Concurrency

-- MAIN APPLICATION
addappid(636310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(636311, 1, "9fd6881966582c7dc433a6a38f9d1895f22e0703525f2be00f86a0def07dc8c9")

