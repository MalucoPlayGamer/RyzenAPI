-- Lua provided by RyzenAPI
-- Game: addappid(636310)

-- MAIN APPLICATION
addappid(636310)

-- MAIN APP DEPOTS / PACKAGES
addappid(636311, 1, "9fd6881966582c7dc433a6a38f9d1895f22e0703525f2be00f86a0def07dc8c9")
