-- Lua provided by RyzenAPI
-- Game: Code:RI Demo

-- MAIN APPLICATION
addappid(1701500)
-- Game: addappid(1701500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701501, 1, "2da0113a7c7651484ee8780a53913082b067de8c45aa22455034491e7111f422")
