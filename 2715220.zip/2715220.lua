-- Lua provided by RyzenAPI
-- Game: Doudou Companion

-- MAIN APPLICATION
addappid(2715220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715222,0,"ce2f39fbe0136174651488a4f7451eed56e88cb1bec39bbc1a4c1939d872ef46")
