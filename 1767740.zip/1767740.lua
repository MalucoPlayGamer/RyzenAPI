-- Lua provided by RyzenAPI
-- Game: Lust&Magic -Chisalla in a Flower Basket-

-- MAIN APPLICATION
addappid(1767740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767742,0,"3bc4681cd64167232e102cfeea4231728600bca712cc51dbaeb187f17e10e574")
addappid(1767743,0,"b14c2d6c9107bca0c2da2bed34265448330d67172ea28ca46375042b9b4cd9c4")
