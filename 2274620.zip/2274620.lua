-- Lua provided by RyzenAPI
-- Game: Game: AppID 2274620

-- MAIN APPLICATION
addappid(2274620)
-- Game: addappid(2274620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274621, 1, "d80dd2f7740fe455053082e62f1e36d65a4106f01468400177459d688063b8bc")
addappid(3903750, 0, "eec2964a88dcbbdbbdee1d7f4be6c44ffe7fcbd3f316daf3b0854378b30e989a")
