-- Lua provided by RyzenAPI
-- Game: Tower of Scherbenmark

-- MAIN APPLICATION
addappid(4972610) -- Tower of Scherbenmark
-- addappid(4972611) -- Depot 4972611 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4972612, 1, "6110e8ef42987848857e27593afcf1bedbf2fb18b017a7f37d966b2ef71e7391") -- Depot 4972612
addappid(4972613, 1, "6ba740a70062821ca46214d03980b0612a8679aa606f4c02baf3a2e2011c20f5") -- Depot 4972613

