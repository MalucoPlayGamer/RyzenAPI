-- 4972610's Lua and Manifest Created by Hubcap Manifest
-- Tower of Scherbenmark
-- Created: August 23, 2026 at 16:32:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4972610) -- Tower of Scherbenmark
-- MAIN APP DEPOTS
addappid(4972612, 1, "6110e8ef42987848857e27593afcf1bedbf2fb18b017a7f37d966b2ef71e7391") -- Depot 4972612
setManifestid(4972612, "3528969195247399065", 133770249)
addappid(4972613, 1, "6ba740a70062821ca46214d03980b0612a8679aa606f4c02baf3a2e2011c20f5") -- Depot 4972613
setManifestid(4972613, "3334320976646558534", 98462761)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4972611) -- Depot 4972611 (empty depot)