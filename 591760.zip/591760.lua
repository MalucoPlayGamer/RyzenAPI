-- Lua provided by RyzenAPI
-- Game: AppID 591760

-- MAIN APPLICATION
addappid(591760)
addappid(1338960)
addappid(1338961)
addappid(1338962)
addappid(1338963)
addappid(1338964)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(591761, 1, "e2d0dbdca132300657cc025ac026fc88c543b9aa6c20876166cc450fcb8e6ee0")

