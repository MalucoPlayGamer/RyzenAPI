-- Lua provided by RyzenAPI 
-- Game: AppID 591760
addappid(591760)
addappid(591761, 1, "e2d0dbdca132300657cc025ac026fc88c543b9aa6c20876166cc450fcb8e6ee0")
