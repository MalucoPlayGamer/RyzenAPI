-- Lua provided by RyzenAPI
-- Game: AppID 1502110

-- MAIN APPLICATION
addappid(1502110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502111, 1, "5715e3cf7f13a6eb2aaeb381676e976ec6e4d48c93e0b8abcc386148b7f70a9c")
