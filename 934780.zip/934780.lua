-- Lua provided by RyzenAPI
-- Game: 934780

-- MAIN APPLICATION
addappid(934780)
-- Game: addappid(934780)

-- MAIN APP DEPOTS / PACKAGES
addappid(934781, 1, "b8978f2b890ff3d5e5b32157c88aa9522390e7ea787e9850aba1439d030e82c8")
