-- Lua provided by RyzenAPI
-- Game: addappid(718730)

-- MAIN APPLICATION
addappid(718730)
addappid(1193370)

-- MAIN APP DEPOTS / PACKAGES
addappid(718731, 1, "620e6adce028328a02189facbfd187cf77f1c751b72a1821f4986f6875363580")
