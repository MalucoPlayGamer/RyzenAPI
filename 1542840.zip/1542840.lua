-- Lua provided by SkyAPI 
-- Game: PuzzlePet - Feed your cat
addappid(1542840)
addappid(1542841, 1, "5ae097e55cc0be0a0309ba836c3f561632019d41f28957c3bc57f01a6ea54190")
