-- Lua provided by RyzenAPI
-- Game: addappid(1542840)

-- MAIN APPLICATION
addappid(1542840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542841, 1, "5ae097e55cc0be0a0309ba836c3f561632019d41f28957c3bc57f01a6ea54190")
