-- Lua provided by RyzenAPI
-- Game: 2095551

-- MAIN APPLICATION
addappid(2095551)
-- Game: addappid(2095551)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095551,0,"706d68cecad1b7a5b97f0481dccc447ee62b637f3ff43e91e925120309634c42")
