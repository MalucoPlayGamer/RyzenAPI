-- Lua provided by RyzenAPI 
-- Game: Case 32 Demo
addappid(3008980)
addappid(3008981, 1, "a06e825f9c6638b7ec02f985c556af87dab958d65809bf483c705916c9d21c58")
