-- Lua provided by RyzenAPI
-- Game: The Concentration of Lust

-- MAIN APPLICATION
addappid(1798870)
-- Game: addappid(1798870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1798872,0,"1084072fa874154c14c9a94d813f825b1a4e11cd059c7328b66400bcc1530187")
