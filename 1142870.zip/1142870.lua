-- Lua provided by RyzenAPI
-- Game: addappid(1142870)

-- MAIN APPLICATION
addappid(1142870)
addappid(1142871)
addappid(1142872)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153290,0,"d0bbdb88b2c858ecc9c8aebaba489ff54ce35fc42542aa38921e7f6b48ae32cc")
