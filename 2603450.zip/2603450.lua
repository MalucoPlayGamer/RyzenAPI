-- Lua provided by RyzenAPI
-- Game: Tank War Shooting Simulator

-- MAIN APPLICATION
addappid(2603450)
-- Game: addappid(2603450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2603451, 1, "4ea363dcadc50d362871c33607e149cb6d9df74ae8b1edb075a419a20a2f433e")
