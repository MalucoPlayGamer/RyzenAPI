-- Lua provided by RyzenAPI
-- Game: AppID 891860

-- MAIN APPLICATION
addappid(891860)
addappid(965291)
addappid(965292)
addappid(965293)
addappid(965294)
addappid(965295)
addappid(965296)
addappid(965297)

-- MAIN APP DEPOTS / PACKAGES
addappid(891861, 1, "3d737ccde674c5f9b0b94f1641221a2f4c3fd6af5753b0fd2a2d6b395e1944c9")
addappid(891862, 1, "130570a18993da117599ecc0e19657d7aef96109511a4268396ec3fb0f1c53f0")
addappid(891863, 1, "acf46ce0d4c0704fc5b2b826478e346acd08bf95ba79847468e1e30de620aabc")
addappid(891864, 1, "8a46d862eda506fc2c528315388e5eb1c77aa10d81a9b2e190165297ac5e4da2")
addappid(891865, 1, "02f671adabe3e2ff98e9df1f0c15655f43378ed5c92900dcae2dcf14ca16e933")
addappid(891866, 1, "7dd2b8ae6557fc0e934b70d76557ee67d722750f72f6501dca76b183855b9a6e")

