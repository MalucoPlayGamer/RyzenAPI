-- Lua provided by RyzenAPI
-- Game: Say Goodbye

-- MAIN APPLICATION
addappid(557880)
addappid(567960)
-- Game: addappid(557880)

-- MAIN APP DEPOTS / PACKAGES
addappid(557881, 1, "8a0e30428fa1c9c4c02ce9a3b344df72807f36d8216a135d380e46a41d192628")
addappid(557882, 1, "d4537604db11d010c0eaf1b24d5bff287e8ad3cd0aff4f14fdb4665cd59f6182")
