-- Lua provided by SkyAPI 
-- Game: Say Goodbye
addappid(557880)
addappid(557881, 1, "8a0e30428fa1c9c4c02ce9a3b344df72807f36d8216a135d380e46a41d192628")
addappid(557882, 1, "d4537604db11d010c0eaf1b24d5bff287e8ad3cd0aff4f14fdb4665cd59f6182")
addappid(567960)
