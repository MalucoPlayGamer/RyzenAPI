-- Lua provided by SkyAPI 
-- Game: AppID 2739840
addappid(2739840)
addappid(2739841, 1, "0d6fbc86d12cdf0fbcccbcaa2c2b7f402d85acb83b176293d9cd396952974110")
