-- Lua provided by RyzenAPI
-- Game: addappid(2739840)

-- MAIN APPLICATION
addappid(2739840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739841, 1, "0d6fbc86d12cdf0fbcccbcaa2c2b7f402d85acb83b176293d9cd396952974110")
