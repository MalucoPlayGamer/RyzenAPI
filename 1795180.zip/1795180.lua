-- Lua provided by RyzenAPI
-- Game: Ice Station Z

-- MAIN APPLICATION
addappid(1795180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795181, 1, "67ca3570e4cc9e9744a64d31eeebd974ee13adfda506bf127b308dd65a15afa8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1803180)
addappid(1803240)
addappid(1803250)
addappid(1803260)
addappid(1803270)
addappid(1803280)
