-- Lua provided by RyzenAPI
-- Game: Ice Station Z

-- MAIN APPLICATION
addappid(1795180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795181, 1, "67ca3570e4cc9e9744a64d31eeebd974ee13adfda506bf127b308dd65a15afa8")

