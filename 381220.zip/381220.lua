-- Lua provided by RyzenAPI
-- Game: Hydraulic Empire

-- MAIN APPLICATION
addappid(381220)

-- MAIN APP DEPOTS / PACKAGES
addappid(381221, 1, "3bfa051198702ff411a6794477575a0f474909de5156ba17456f874f4c5a2011")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
