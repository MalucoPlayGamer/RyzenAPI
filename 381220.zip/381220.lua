-- Lua provided by RyzenAPI
-- Game: Hydraulic Empire

-- MAIN APPLICATION
addappid(381220)

-- MAIN APP DEPOTS / PACKAGES
addappid(381221, 1, "3bfa051198702ff411a6794477575a0f474909de5156ba17456f874f4c5a2011")

