-- Lua provided by SkyAPI 
-- Game: Astonishing Baseball Manager
addappid(1680650)
addappid(1680651, 1, "4a45dc291f1e7665d9f07d1dda823f4636204c507ef201a8ac8fee6f220dc2b0")
addappid(1680652, 1, "90bf28803bf2e871e37642f96cc0433da8bf09c44e214561b601f62b39baa78c")
addappid(2082240)
