-- Lua provided by RyzenAPI
-- Game: Game: iDigging

-- MAIN APPLICATION
addappid(3447690)
-- Game: addappid(3447690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3447691, 1, "1f84872c8b0009e840668c4bbb969a273f70e17064a6743b2370be6988d5520d")
