-- Lua provided by RyzenAPI
-- Game: iDigging

-- MAIN APPLICATION
addappid(3447690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3447691, 1, "1f84872c8b0009e840668c4bbb969a273f70e17064a6743b2370be6988d5520d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
