-- Lua provided by RyzenAPI 
-- Game: AppID 322410
addappid(322410)
addappid(322411, 1, "9bf9bb75f9ceb604b73e3a64cdf8c7f170261a9e50478631d67d85a1c90a554b")
addappid(322412, 1, "d20826e0b55ecc41efa7f1465f897d54c2cdd67a3bc9add7946a94c032a7779c")
