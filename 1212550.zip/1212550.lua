-- Lua provided by RyzenAPI
-- Game: EVECTOR, Acid Thirst

-- MAIN APPLICATION
addappid(1212550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212551, 1, "8f72769276368b53c4dcda2318e0c46bdd0ddcd60b1694af56f9bea62f6330b8")

