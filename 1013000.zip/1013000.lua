-- Lua provided by RyzenAPI
-- Game: AppID 1013000

-- MAIN APPLICATION
addappid(1013000)
-- Game: addappid(1013000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013001, 1, "e253e7784a0e895e91eb9402cb85abc4a2c0558182d82ff08f20c0d1dcba14aa")
