-- Lua provided by RyzenAPI
-- Game: Bloomtown: A Different Story Demo

-- MAIN APPLICATION
addappid(2725930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725931, 1, "adb0571318ad7523f6c7fe6b78954cf9c1b7f3e2b45492fdbafdec48bbc9f0dd")

