-- Lua provided by RyzenAPI 
-- Game: Kwaidan ～Azuma manor story～
addappid(1066430)
addappid(1066431, 1, "39ae15a5bb0ec41056d55f6357446fbfcd3b1b5c413fb2d8b0798662b4b08bd8")
