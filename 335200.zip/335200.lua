-- Lua provided by RyzenAPI
-- Game: ManaCollect

-- MAIN APPLICATION
addappid(335200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(335201, 1, "37c150dcc2754cf74dc1893d65aa0d961361a132ec02e22a82ed882f7ab4c925")

