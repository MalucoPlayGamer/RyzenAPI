-- Lua provided by RyzenAPI
-- Game: Game: ManaCollect

-- MAIN APPLICATION
addappid(335200)
-- Game: addappid(335200)

-- MAIN APP DEPOTS / PACKAGES
addappid(335201, 1, "37c150dcc2754cf74dc1893d65aa0d961361a132ec02e22a82ed882f7ab4c925")
