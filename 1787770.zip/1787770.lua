-- Lua provided by RyzenAPI
-- Game: Game: Spirits of Carter Mansion

-- MAIN APPLICATION
addappid(1787770)
-- Game: addappid(1787770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787771, 1, "563066c90e5f9469ff9460ddf6baa4aecc9b396baa20051131c6864c61a10d09")
