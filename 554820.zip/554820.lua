-- Lua provided by RyzenAPI
-- Game: 554820

-- MAIN APPLICATION
addappid(554820)
-- Game: addappid(554820)

-- MAIN APP DEPOTS / PACKAGES
addappid(554821, 1, "62eac58a076f282e3f672f01f5253046be12a05c01107b9bcee28b6f74adc799")
addappid(554828, 1, "bb5a8e85d4434e8a22e5bf00745688f8906ca586fcd3eb90c5f187aa5ec92f30")
