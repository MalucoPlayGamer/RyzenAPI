-- Lua provided by RyzenAPI
-- Game: Game: EYE TO ME

-- MAIN APPLICATION
addappid(2966110)
-- Game: addappid(2966110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2966111, 1, "c55d22c99fb631f74ac9a5546e90f0a9bf3f7bbd99aeafc0cb7708ad0b7fbca3")
addappid(2966112, 1, "3a6038c37fc7d6ea540cc48292e706e14b4da7bdd1727fecaf3417228a4f8367")
addappid(2966114, 1, "3d8de3d18c6dce0677cfb10e1e77566f4c441a6e0732c75c14db927430b13023")
