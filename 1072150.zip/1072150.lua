-- Lua provided by SkyAPI 
-- Game: AppID 1072150
addappid(1072150)
addappid(1072151, 1, "66fb11cbfabf8eb775c7fd12e67bb77e5b05ac08ac6a122b5c1ac13632717cd5")
addappid(1072153, 1, "185849ce665f1fe5d1a5903e87d9a2e6dbc07f6631fde905213c3bdbc1a93c70")
addappid(1903580)
