-- Lua provided by RyzenAPI
-- Game: AppID 545060

-- MAIN APPLICATION
addappid(545060)

-- MAIN APP DEPOTS / PACKAGES
addappid(545061, 1, "e6d7884a5ab41bc69493daff1f7d3c942085b30a26fe7ab42265c5b4270fd503")
addappid(545062, 1, "ea729ff0a476517fb048b96a26ce73482d73a6ca95e5273922dc57a344829621")
addappid(545063, 1, "db8e58506a618fbdc2df7f1e58c752c4394fd806330c2c513afb3550a8620259")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(665170)
