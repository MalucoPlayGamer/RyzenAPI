-- Lua provided by RyzenAPI
-- Game: DFF NT: Yuna Starter Pack

-- MAIN APPLICATION
addappid(1022392)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022392,0,"1acba40e07edff86b6e0fbdcc765892aafa73f33a8c8b9483cb97c55434422a9")
