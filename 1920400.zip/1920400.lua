-- Lua provided by RyzenAPI
-- Game: Game: Bunny Girl Story

-- MAIN APPLICATION
addappid(1920400)
addappid(1934070)
-- Game: addappid(1920400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920401, 1, "acf1945445db5d40f0619f058350d6c67eb8e774ddf8040705f182cc5c893207")
