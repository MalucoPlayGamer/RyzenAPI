-- Lua provided by RyzenAPI
-- Game: 晨海星澜 - 追忆篇

-- MAIN APPLICATION
addappid(2138180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138181, 1, "fd3b17a2a7fe57dcd38526610c16a5398e2847fcbd17e0969326398561f31e6a")
