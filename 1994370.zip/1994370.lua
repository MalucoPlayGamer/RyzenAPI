-- Lua provided by RyzenAPI
-- Game: 1994370

-- MAIN APPLICATION
addappid(1994370)
-- Game: addappid(1994370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994371, 1, "ea57c571798cc225f7e38d67df90a1714944c9d42ebf2debc61a5c5bb2de429d")
addappid(2804350, 0, "a2611c3cc1d08afadc041c3be28ca1d67eda97473d4c71297edfb8adc7c8f738")
addappid(2849920, 0, "29c850f014f9c4193bb340b0cc2205d88ad7e83b86d4e866c3ac5063794aeaa3")
