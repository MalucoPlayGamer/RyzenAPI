-- Lua provided by RyzenAPI 
-- Game: AppID 1658290
addappid(1658290)
addappid(1658291, 1, "9301b85350d59288ba69b81a00242b1720a59eb2ad1a95461480df0f21470fd3")
