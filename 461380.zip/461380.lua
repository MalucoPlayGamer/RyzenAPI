-- Lua provided by RyzenAPI
-- Game: A Princess' Tale

-- MAIN APPLICATION
addappid(461380)

-- MAIN APP DEPOTS / PACKAGES
addappid(461381, 1, "e25a273939b39860cdcefbeb0a18c4b1846090733e37ef791cad3ec398c75871")

