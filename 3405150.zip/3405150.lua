-- Lua provided by RyzenAPI
-- Game: Incursion Red River - Supporter Edition

-- MAIN APPLICATION
addappid(3405150)
-- Game: addappid(3405150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3405150,0,"66466595306f5647e00fca5435234afc25e2a2f757c1ab2d550917767e80b71e")
