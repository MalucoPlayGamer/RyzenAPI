-- Lua provided by RyzenAPI
-- Game: AppID 252630

-- MAIN APPLICATION
addappid(252630)

-- MAIN APP DEPOTS / PACKAGES
addappid(252631, 1, "656d183e33bd865f35d4b83285c4477a5dc8c9594b6a9f88ae038b691bf574f6")
addappid(252632, 1, "d6850ebdacfeddee2430f8ff2e2d0071c40a6fc8639a8694202d6d15719db212")
addappid(252633, 1, "e88eacaed4e24c47543062b43c7fd883643850cc88f565ed7f75f38aafe01229")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
