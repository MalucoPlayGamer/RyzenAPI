-- Lua provided by RyzenAPI
-- Game: Journey of Greed

-- MAIN APPLICATION
addappid(1032790)
addappid(1261840)
addappid(1262660)
addappid(1973650)
addappid(1973651)
addappid(1973652)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032791,0,"6c774cb758eeaf8ad8ec14c0fccd12da866c78940c46329c77993187fa58e244")
addappid(1032792,0,"60f41ea28fd7625e854dd3251dcfd8f5a5a2813af58be6cd4af4352bda490c13")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
