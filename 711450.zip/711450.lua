-- Lua provided by RyzenAPI
-- Game: addappid(711450)

-- MAIN APPLICATION
addappid(711450)

-- MAIN APP DEPOTS / PACKAGES
addappid(711451, 1, "e18015fb71b851abb645add7656d4b1718d5b9fdec19f4af45f958fa177eca11")
addappid(711452, 1, "f19728d78e094ce3590ec4ca42e9e1f0389e6856f66aa7e8c2a4c466c0e961ad")
