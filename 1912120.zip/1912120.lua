-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Uchiban Outfit "Omokage"

-- MAIN APPLICATION
addappid(1912120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912120,0,"761dc6841d8ed717b9d60cd81739950562e73d39c0555626d0d6787a6d0e004b")

