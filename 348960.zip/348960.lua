-- Lua provided by RyzenAPI 
-- Game: Odysseus: Long Way Home
addappid(348960)
addappid(348961, 1, "244c5ba9cac5c33e1652761891cd251966637bab4d14747037558ed735b75fab")
addappid(348962, 1, "d847dc4f0221328d80292f3ef62c059e99e80f8d027869170e4531ddb5439839")
