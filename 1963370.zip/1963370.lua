-- Lua provided by RyzenAPI
-- Game: No One Survived

-- MAIN APPLICATION
addappid(1963370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963371, 1, "3074ce009a3d9fbc8a0cd5d12b08145f1e07640ef7cde557cbe043bc06d1e45f")

