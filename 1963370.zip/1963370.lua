-- Lua provided by RyzenAPI
-- Game: No One Survived

-- MAIN APPLICATION
addappid(1963370)
addappid(3338710)
addappid(3516790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1963371, 1, "3074ce009a3d9fbc8a0cd5d12b08145f1e07640ef7cde557cbe043bc06d1e45f")

