-- Lua provided by RyzenAPI
-- Game: Unending Dusk

-- MAIN APPLICATION
addappid(806530)
addappid(1053180)

-- MAIN APP DEPOTS / PACKAGES
addappid(806531, 1, "6ebc61a4b6652c7730f3b6f30ceadf28db0d88009a3ed9c8ac938b94af5095bc")

