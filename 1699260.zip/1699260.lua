-- Lua provided by RyzenAPI
-- Game: 1699260

-- MAIN APPLICATION
addappid(1699260)
-- Game: addappid(1699260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699261, 1, "40a43fa0d2079d8712dcdb9ee318d29fe4b71a65331a7695153a341407fdfdc4")
