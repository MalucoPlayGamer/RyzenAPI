-- Lua provided by RyzenAPI
-- Game: Game: AppID 1211830

-- MAIN APPLICATION
addappid(1211830)
-- Game: addappid(1211830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211831, 1, "c4e03566bc167e93a6b2ce07e6e96f4bad3d7d100b13dd445cfae8f48bf0ca3b")
addappid(1211832, 1, "42d9d07b13d897f1cd25ef8e774a1d9f14a8c84242d98e3e1a938a2c0ae3c441")
addappid(1211833, 1, "716d17e61429b86f8135e7adfbf03d7571ba35e2dbf5ff90e83b53ac21c59a13")
