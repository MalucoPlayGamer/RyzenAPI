-- Lua provided by RyzenAPI
-- Game: addappid(1611130)

-- MAIN APPLICATION
addappid(1611130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611133,0,"0dbc5c99f18de5bfbebfe43bf489af1949b9a63f1d3f2b9c30ebbdc973d08019")
