-- Lua provided by RyzenAPI
-- Game: Game: AppID 884160

-- MAIN APPLICATION
addappid(884160)
-- Game: addappid(884160)

-- MAIN APP DEPOTS / PACKAGES
addappid(884161, 1, "e0c699d82d90c7477940491f42aa1f5f4af9e352966a7db982cc502e1cc2b1df")
addappid(884162, 1, "45acff9868f18dc897c62ad8c7c57e0eee35ee9e1dc45c206f9b8087454989f7")
addappid(884163, 1, "21565f8a12e447a22ee5053a8d4350af58c327224ae36c045f4da9ab84978e95")
addappid(884164, 1, "6021404765e66605c467b82ab63eb5cec33d6abcf3e8cc95176b7aba9ee01b0c")
addappid(884165, 1, "b757a3ffcfcd2a7fed8e102e3a5cfb63e1e5a1adaf6c5278baefb009a8fd5faa")
