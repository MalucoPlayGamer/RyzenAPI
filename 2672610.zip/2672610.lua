-- Lua provided by RyzenAPI
-- Game: 2672610

-- MAIN APPLICATION
addappid(2672610)
-- Game: addappid(2672610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2672611, 1, "9f7513ce3953f71d2f994a9a331b862c8a41aeae89b0ff0933336aeef1796220")
