-- Lua provided by SkyAPI 
-- Game: Black Myth: Wukong Deluxe Edition Upgrade
addappid(2672610)
addappid(2672611, 1, "9f7513ce3953f71d2f994a9a331b862c8a41aeae89b0ff0933336aeef1796220")
