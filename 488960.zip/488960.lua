-- Lua provided by RyzenAPI
-- Game: Game: Star Vikings Forever

-- MAIN APPLICATION
addappid(488960)
-- Game: addappid(488960)

-- MAIN APP DEPOTS / PACKAGES
addappid(488961, 1, "fe982824d2e1e0d008e5c1c32305b591bec66e894e9e03a114e47622aeb691e2")
addappid(488962, 1, "23f99fc359a99362ac829b33975bb76d50e9ea08237d63243b2b2711af5ea6b2")
addappid(488963, 1, "039b6e184fa70fd4e75886c7ccb69beae76016bb24ef05097142e7f96708df3e")
