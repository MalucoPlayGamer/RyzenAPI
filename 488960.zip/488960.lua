-- Lua provided by RyzenAPI
-- Game: Star Vikings Forever

-- MAIN APPLICATION
addappid(488960)

-- MAIN APP DEPOTS / PACKAGES
addappid(488961, 1, "fe982824d2e1e0d008e5c1c32305b591bec66e894e9e03a114e47622aeb691e2")
addappid(488962, 1, "23f99fc359a99362ac829b33975bb76d50e9ea08237d63243b2b2711af5ea6b2")
addappid(488963, 1, "039b6e184fa70fd4e75886c7ccb69beae76016bb24ef05097142e7f96708df3e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
