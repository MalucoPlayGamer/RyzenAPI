-- Lua provided by RyzenAPI
-- Game: Game: Fueled Up Demo

-- MAIN APPLICATION
addappid(1985480)
-- Game: addappid(1985480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985481, 1, "872c3c830afb87f77a615ddd0c119967be7686245f2dd3b529611fe15a1c092f")
