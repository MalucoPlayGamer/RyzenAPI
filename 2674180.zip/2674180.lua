-- Lua provided by RyzenAPI
-- Game: addappid(2674180)

-- MAIN APPLICATION
addappid(2674180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2674181, 1, "30f5ff8136ec31727534d2c33eae669d38fcd4c0b83f5231ce5499ee7eb61f9a")
