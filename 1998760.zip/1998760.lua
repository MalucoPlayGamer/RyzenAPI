-- Lua provided by SkyAPI 
-- Game: AppID 1998760
addappid(1998760)
addappid(1998761, 1, "4ad9d27da971cd0ee7b5d8fd460bf05b926b5ef3feebbd036b86469fba307880")
