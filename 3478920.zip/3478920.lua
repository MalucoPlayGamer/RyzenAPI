-- Lua provided by RyzenAPI
-- Game: 3478920

-- MAIN APPLICATION
addappid(3478920)
addappid(3823390)
addappid(3823400)
addappid(3823410)
-- Game: addappid(3478920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478921, 1, "d1bd2d72bc41298aea4d612ff01e64d20bb9a7cf4ac4b9134d0c6ce2fad638bf")
