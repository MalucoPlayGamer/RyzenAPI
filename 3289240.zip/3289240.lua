-- Lua provided by RyzenAPI
-- Game: 拜托！请你先告白

-- MAIN APPLICATION
addappid(3289240)
-- Game: addappid(3289240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3289241, 1, "064408a77e11f2ff2e978a595722f05ed1c8591372c7a5d864647fc3004ec4fb")
