-- Lua provided by RyzenAPI
-- Game: Tokyo Cop

-- MAIN APPLICATION
addappid(1921090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921091, 1, "7bfcd4530eb863c494556cfc7a37624bb0ec3d8a777f6ecc6e21beb62a737f7e")
