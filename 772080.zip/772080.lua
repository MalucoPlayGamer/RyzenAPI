-- Lua provided by RyzenAPI
-- Game: addappid(772080)

-- MAIN APPLICATION
addappid(772080)

-- MAIN APP DEPOTS / PACKAGES
addappid(772081, 1, "3b0bde83162774f62ebb0be74e4442847a10c9c39ce88f373b325805e55a2085")
