-- Lua provided by RyzenAPI 
-- Game: Stellar Poetry Demo
addappid(2993710)
addappid(2993711, 1, "44cad76902f3818dfdbd7351561aa83eae329976a48344bcb8703c94fd631208")
