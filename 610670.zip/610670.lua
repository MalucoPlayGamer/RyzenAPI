-- Lua provided by RyzenAPI 
-- Game: AppID 610670
addappid(610670)
addappid(610671, 1, "f93647d2933d6776ddc4a7bd1eae1146c378e600691dce74c397e9427cf8cbae")
addappid(610672, 1, "a3fe5b96aaeaa1719296977a0caf129ce332064f887fc4826054bfcb38c9c082")
