-- Lua provided by RyzenAPI
-- Game: FolkOrigin

-- MAIN APPLICATION
addappid(2863790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863791, 1, "6d000bedd4f206edb293ff57784aa2f5980ed0849d49520fd3c5ca6b1b9935b2")

