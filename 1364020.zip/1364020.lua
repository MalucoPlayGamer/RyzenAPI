-- Lua provided by RyzenAPI
-- Game: addappid(1364020)

-- MAIN APPLICATION
addappid(228983)
addappid(228985)
addappid(228989)
addappid(228990)
addappid(1364020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364023,0,"d11348db49f59c7fd026463c0c69ddd3e9071abb22b624a9441b8ddb75e53656")
