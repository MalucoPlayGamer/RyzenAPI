-- Lua provided by RyzenAPI
-- Game: 3164320

-- MAIN APPLICATION
addappid(3164320)
-- Game: addappid(3164320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164321, 1, "6f314308ee857df6203b7e5570e722088516cba58e8483f09f6cbbef9e4c8dd2")
