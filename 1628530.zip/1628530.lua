-- Lua provided by RyzenAPI
-- Game: 1628530

-- MAIN APPLICATION
addappid(1628530)
-- Game: addappid(1628530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628531, 1, "28ec4660a361f8272d9b4452b0ac1540b2bcf0b7a050beb8d5c6d6cd1db226ba")
