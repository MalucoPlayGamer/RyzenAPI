-- Lua provided by RyzenAPI 
-- Game: AppID 2372360
addappid(2372360)
addappid(2372361, 1, "bf924372f5d78426bf60897c2db2a32c576e19db1a10c600633c56de926dec32")
