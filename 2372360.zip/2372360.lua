-- Lua provided by RyzenAPI
-- Game: Lovely Nurse

-- MAIN APPLICATION
addappid(2372360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372361, 1, "bf924372f5d78426bf60897c2db2a32c576e19db1a10c600633c56de926dec32")

