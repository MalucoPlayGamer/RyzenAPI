-- Lua provided by RyzenAPI
-- Game: Zombie's Cool

-- MAIN APPLICATION
addappid(1419760)
-- Game: addappid(1419760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419761, 1, "2c0875f2aa80a1d0e110bff3ac557fcfc97eba17dd30b5149a77e86b8725dfe6")
