-- Lua provided by RyzenAPI
-- Game: Cricket Through the Ages

-- MAIN APPLICATION
addappid(2657480)
-- Game: addappid(2657480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2657481, 1, "07cde4858a6d3c1b4c5d8102a48b89a229126c28ab74fd1663ee369fa48dea1a")
