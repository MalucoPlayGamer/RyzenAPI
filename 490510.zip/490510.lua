-- Lua provided by RyzenAPI
-- Game: 490510

-- MAIN APPLICATION
addappid(490510)
-- Game: addappid(490510)

-- MAIN APP DEPOTS / PACKAGES
addappid(490511, 1, "d795a7a47aff7209f3ea0ae0e69704f4f8119b62a50750ee12c151d86edb52a4")
