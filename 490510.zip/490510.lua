-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles 2: Christmas

-- MAIN APPLICATION
addappid(490510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(490511, 1, "d795a7a47aff7209f3ea0ae0e69704f4f8119b62a50750ee12c151d86edb52a4")
