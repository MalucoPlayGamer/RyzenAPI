-- Lua provided by RyzenAPI
-- Game: AppID 589060

-- MAIN APPLICATION
addappid(589060)

-- MAIN APP DEPOTS / PACKAGES
addappid(589061, 1, "d4e22983d17bd63ce0f405a77da856e2ae107b96cd05b1ffe75bac56096b924a")
addappid(589062, 1, "25a3111eb933360bf144852227bea89eb748d5ef10b430c6326efec12a435c27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
