-- Lua provided by RyzenAPI
-- Game: addappid(997740)

-- MAIN APPLICATION
addappid(997740)

-- MAIN APP DEPOTS / PACKAGES
addappid(997740,0,"f0b1b757d2704b6b82557c4bedfaa3fb0fbb9de17ff18f82667c30fe028d0d10")
