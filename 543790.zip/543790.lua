-- Lua provided by RyzenAPI
-- Game: addappid(543790)

-- MAIN APPLICATION
addappid(543790)

-- MAIN APP DEPOTS / PACKAGES
addappid(543791, 1, "32689adbae81e177d3fb2a4b3b237a5a728884ab851377f91c8ae8b382a8d0a8")
