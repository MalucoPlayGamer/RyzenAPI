-- Lua provided by RyzenAPI
-- Game: 1714330

-- MAIN APPLICATION
addappid(1714330)
-- Game: addappid(1714330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714330,0,"ddd162f0b5aff18bd29f54fa3350c8246a1b2817552057307d6b4e57e76db4e9")
