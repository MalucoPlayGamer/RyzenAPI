-- Lua provided by RyzenAPI 
-- Game: Left to Survive: Zombie Shooter
addappid(1702140)
addappid(1702141, 1, "36e12286db137bd6c068a6593cbf7a059e0bd1d2c3498d2a0ae45619aefdcc36")
