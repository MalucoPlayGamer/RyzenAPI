-- Lua provided by SkyAPI 
-- Game: AppID 2638130
addappid(2638130)
addappid(2638131, 1, "e94a5f7db7483dc9789387547687e812bcc6e71cde13761ea84e5c870d910630")
