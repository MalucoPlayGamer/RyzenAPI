-- Lua provided by RyzenAPI
-- Game: Game: AppID 2638130

-- MAIN APPLICATION
addappid(2638130)
-- Game: addappid(2638130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638131, 1, "e94a5f7db7483dc9789387547687e812bcc6e71cde13761ea84e5c870d910630")
