-- Lua provided by RyzenAPI
-- Game: addappid(2328670)

-- MAIN APPLICATION
addappid(2328670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328671, 1, "40ae75b4031f4f251a3f3060957c5b1dc2fa445d8e655c87b2b5d55c112302c5")
