-- Lua provided by RyzenAPI
-- Game: Hentai Simulator

-- MAIN APPLICATION
addappid(1284760)
-- Game: addappid(1284760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284761, 1, "2a98e9ab7962f3e6dc9170a86ad53f550f8422264d1dc7a6943daa4f54283090")
