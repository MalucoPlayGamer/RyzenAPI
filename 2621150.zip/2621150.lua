-- Lua provided by RyzenAPI
-- Game: Lizard Survivors: Battle for Hyperborea

-- MAIN APPLICATION
addappid(2621150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2621151, 1, "270d9b646ce82d6be514ef4025d7bffd4114d822bfc96be33671f170f69b891d")

