-- Lua provided by SkyAPI 
-- Game: Godsbane
addappid(1480960)
addappid(1480961, 1, "5f27d2908afe6b1031b21bd9189a916a4319877fa5e493c9a3092f9d23b52419")
