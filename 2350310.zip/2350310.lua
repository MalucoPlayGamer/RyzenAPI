-- Lua provided by RyzenAPI
-- Game: Monica's Newlywed Life

-- MAIN APPLICATION
addappid(2350310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350311, 1, "b3ce6b28735f732862e1ff3123aeb380456a071f8ba0dba398c23ffcd1f0c133")
addappid(2350312, 1, "cc523530fadc9d6751b518b2ee960bb3dca437fb175bccbaaa95ef95149b4d9e")
addappid(2350313, 1, "e1bd71480324b1180a06c32e1bb9ddfd7e68ef0a9ce785f79fccae8b4c3589e1")

