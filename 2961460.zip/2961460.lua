-- Lua provided by RyzenAPI
-- Game: 神树残响（Echoes of the Divine Tree）

-- MAIN APPLICATION
addappid(2961460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2961461, 1, "f212983d1e3601104cc7f5b5a4aa8955ad1572209b9afe60a34e610948ec8b65")

