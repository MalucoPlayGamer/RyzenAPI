-- Lua provided by RyzenAPI
-- Game: Game: Paradigm City

-- MAIN APPLICATION
addappid(1124390)
-- Game: addappid(1124390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124391, 1, "6b252cffbbd26633786942859ee2ca314fc4086fcc4dae8c090d90299a427d15")
