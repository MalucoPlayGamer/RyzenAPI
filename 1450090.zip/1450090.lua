-- Lua provided by RyzenAPI
-- Game: 1450090

-- MAIN APPLICATION
addappid(1450090)
-- Game: addappid(1450090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450091, 1, "808d09608e292503dafb98b90cc38c5432cce7e6dbbd68b274014864b182900e")
