-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Sen no Kiseki II KAI -The Erebonian Civil War-

-- MAIN APPLICATION
addappid(1450090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(1450091, 1, "808d09608e292503dafb98b90cc38c5432cce7e6dbbd68b274014864b182900e")

