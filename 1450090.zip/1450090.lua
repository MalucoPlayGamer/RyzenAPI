-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Sen no Kiseki II KAI -The Erebonian Civil War-

-- MAIN APPLICATION
addappid(1450090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450091, 1, "808d09608e292503dafb98b90cc38c5432cce7e6dbbd68b274014864b182900e")

