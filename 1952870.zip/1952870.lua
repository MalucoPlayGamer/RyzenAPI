-- Lua provided by RyzenAPI
-- Game: Shale Hill Secrets Demo

-- MAIN APPLICATION
addappid(1952870)
-- Game: addappid(1952870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952871, 1, "dae3487862154e43d90a1180e1e3e34a9a3b24a7d9225220cb281874d1a52260")
