-- Lua provided by RyzenAPI
-- Game: 3110750

-- MAIN APPLICATION
addappid(3110750)
-- Game: addappid(3110750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3110751, 1, "556231235c939e128a66d5ca49dc29d644f87e813fd16de3d671ff74cb9b708e")
