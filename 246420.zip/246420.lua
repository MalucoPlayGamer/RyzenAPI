-- Lua provided by RyzenAPI
-- Game: 246420

-- MAIN APPLICATION
addappid(246420)
-- Game: addappid(246420)

-- MAIN APP DEPOTS / PACKAGES
addappid(246421, 1, "5435d120412fea104e604ea151e16e439b95df2a769cbf660c51b53a0130d563")
addappid(246422, 1, "8eb92c910e8a3a140c96b16ac23fb2e370eccec64dbaf508bb3fe626273919db")
addappid(246423, 1, "5b7cccc9354c9e19700c2bad6a5ee8015edd1696af9da2fb737ad2ed72f12928")
