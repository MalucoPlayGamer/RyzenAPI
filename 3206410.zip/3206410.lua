-- Lua provided by RyzenAPI
-- Game: addappid(3206410)

-- MAIN APPLICATION
addappid(3206410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206411, 1, "3a9924d6d8d6d649fbd8c797280f72ba62db9d495e30f3dc6654d72a60320aa9")
