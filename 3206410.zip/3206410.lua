-- Lua provided by SkyAPI 
-- Game: The Sinking Forest - 沈んだ森 -
addappid(3206410)
addappid(3206411, 1, "3a9924d6d8d6d649fbd8c797280f72ba62db9d495e30f3dc6654d72a60320aa9")
