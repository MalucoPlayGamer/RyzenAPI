-- Lua provided by RyzenAPI
-- Game: Tutor X Hypnosis 2 - Trial ver -

-- MAIN APPLICATION
addappid(2928210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928211, 1, "6fffb7ff2b336f0da72b2f49be11576ba413eb52e54198fc3c1ec3ca3f84f4da")

