-- Lua provided by SkyAPI 
-- Game: Valakas Story
addappid(1171310)
addappid(1171311, 1, "af7f699a74809eda3a4f56c7223a630a7ba21fc8639d54ee6bcc7c5f84a488fd")
