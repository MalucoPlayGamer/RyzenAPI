-- Lua provided by RyzenAPI
-- Game: Game: Feudal Fantasy Incremental

-- MAIN APPLICATION
addappid(2298500)
-- Game: addappid(2298500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298501, 1, "52ae874e85369230a67e4ef533079b65486e3088eb2b2e6bad9a9b46e257c39e")
