-- Lua provided by RyzenAPI
-- Game: 1727620

-- MAIN APPLICATION
addappid(1727620)
-- Game: addappid(1727620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727621, 1, "b9516f75aab1b409248a8c1e9a375989f876586cf2b3e0c43ef7d7d929c26f8b")
