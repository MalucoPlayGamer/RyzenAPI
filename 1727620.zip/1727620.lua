-- Lua provided by SkyAPI 
-- Game: Neighbor Diana
addappid(1727620)
addappid(1727621, 1, "b9516f75aab1b409248a8c1e9a375989f876586cf2b3e0c43ef7d7d929c26f8b")
