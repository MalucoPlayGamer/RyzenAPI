-- Lua provided by RyzenAPI
-- Game: Game: DRAW CHILLY

-- MAIN APPLICATION
addappid(839080)
-- Game: addappid(839080)

-- MAIN APP DEPOTS / PACKAGES
addappid(839081, 1, "66cc2da6a55615512023c4611242292baea0aa4c07c7e8e38091f6f429fd05c5")
