-- Lua provided by RyzenAPI
-- Game: DRAW CHILLY

-- MAIN APPLICATION
addappid(839080)
addappid(1166390)

-- MAIN APP DEPOTS / PACKAGES
addappid(839081,0,"66cc2da6a55615512023c4611242292baea0aa4c07c7e8e38091f6f429fd05c5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
