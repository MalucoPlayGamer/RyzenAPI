-- Lua provided by RyzenAPI
-- Game: addappid(2942170)

-- MAIN APPLICATION
addappid(2942170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942171, 1, "9af1c47d3968d7230d25d0fc4d3be5f1cdc5f7e5c922e1f1d0d66cf85f3d3f15")
