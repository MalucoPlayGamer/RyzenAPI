-- Lua provided by RyzenAPI 
-- Game: Jogward
addappid(1586230)
addappid(1586231, 1, "500a24914b1ea68a5111930f11aa8df5666d7fb4dd5f726ea64ff10514e5678a")
