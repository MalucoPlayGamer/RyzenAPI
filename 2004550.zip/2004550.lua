-- Lua provided by RyzenAPI
-- Game: addappid(2004550)

-- MAIN APPLICATION
addappid(2004550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004551, 1, "78ea0681d2c3148f440d095d2dd3da8ac8484ca3c1b7220be8fbb768c735ce93")
addappid(2004552, 1, "041311923cf5ef239c22e54bf2af6486d4884c646d376de76cf97b69daa6cce6")
