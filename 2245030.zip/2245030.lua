-- Lua provided by RyzenAPI
-- Game: addappid(2245030)

-- MAIN APPLICATION
addappid(2245030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245031, 1, "63dc222a28a951fec68d0297ffbc1ad89274e0abf7f99434e8d5cd37e0c65820")
