-- Lua provided by RyzenAPI
-- Game: Combat Troops VR

-- MAIN APPLICATION
addappid(1817120)
-- Game: addappid(1817120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817121, 1, "14175d23fb5038c691e05ced71725059587243125c2acf353728a9f0a2ac8463")
