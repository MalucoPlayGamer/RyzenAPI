-- Lua provided by RyzenAPI
-- Game: Game: Color Clash

-- MAIN APPLICATION
addappid(3739230)
-- Game: addappid(3739230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3739231, 1, "32be960d9924725ad05a2bb3b36b86743411a43bf786d14133bbb678a7befd64")
