-- Lua provided by RyzenAPI
-- Game: addappid(2300070)

-- MAIN APPLICATION
addappid(2300070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300071, 1, "09e2da33907a6fea67beeacdcec4f5dd8d77d463912c3f9fa713b08079661a37")
