-- Lua provided by RyzenAPI
-- Game: AppID 975950

-- MAIN APPLICATION
addappid(975950)
-- Game: addappid(975950)

-- MAIN APP DEPOTS / PACKAGES
addappid(975951, 1, "dedc3d4096cea8d602eda38484852775529d87c79bfeb6b4de8f75e286a6de27")
