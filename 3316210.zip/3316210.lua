-- Lua provided by RyzenAPI
-- Game: 梧州CityWalk

-- MAIN APPLICATION
addappid(3316210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3316211, 1, "73697eda0a9fae8f3542dd4a2615d5f274848da8627e06697a3bd86c67f1ba75")

