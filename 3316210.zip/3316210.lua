-- Lua provided by RyzenAPI
-- Game: 梧州CityWalk

-- MAIN APPLICATION
addappid(3316210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3316211, 1, "73697eda0a9fae8f3542dd4a2615d5f274848da8627e06697a3bd86c67f1ba75")
