-- Lua provided by RyzenAPI
-- Game: Hidden Futa

-- MAIN APPLICATION
addappid(2267370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267371, 1, "841f8e9fea047a75a2e7ee71935211ea4dc114aaf4ed869b0ca68efeabc04c1b")

