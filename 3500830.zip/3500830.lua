-- Lua provided by RyzenAPI
-- Game: Store Keeper

-- MAIN APPLICATION
addappid(3500830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3500831, 1, "da76c6cb0b01c4e9e592349600475a304e9fc1cb9e33afa1f6cf501feb046057")
