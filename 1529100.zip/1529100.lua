-- Lua provided by RyzenAPI
-- Game: 1529100

-- MAIN APPLICATION
addappid(1529100)
-- Game: addappid(1529100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529101, 1, "a2eda344d6c568f15cc357d37b997246b4eeb7014a1a58c4a8e6c06b243dfb1b")
