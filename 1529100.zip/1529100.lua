-- Lua provided by RyzenAPI
-- Game: What The Maze

-- MAIN APPLICATION
addappid(1529100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1529101, 1, "a2eda344d6c568f15cc357d37b997246b4eeb7014a1a58c4a8e6c06b243dfb1b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
