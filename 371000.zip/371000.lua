-- Lua provided by RyzenAPI
-- Game: Cave Coaster

-- MAIN APPLICATION
addappid(371000)

-- MAIN APP DEPOTS / PACKAGES
addappid(371001, 1, "15d9fc0e5ef567cd48394ef62338dd9b60f0904650e1324aa696625af95977f3")

