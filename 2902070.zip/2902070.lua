-- Lua provided by RyzenAPI
-- Game: Gym Manager: Prologue

-- MAIN APPLICATION
addappid(2902070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2902071, 1, "ebf6597e4de245c9093347665e7f2aa5f30241c1e37ecd425574cdf60697db99")

