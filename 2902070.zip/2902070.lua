-- Lua provided by RyzenAPI
-- Game: 2902070

-- MAIN APPLICATION
addappid(2902070)
-- Game: addappid(2902070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902071, 1, "ebf6597e4de245c9093347665e7f2aa5f30241c1e37ecd425574cdf60697db99")
