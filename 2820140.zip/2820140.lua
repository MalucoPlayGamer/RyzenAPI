-- Lua provided by RyzenAPI
-- Game: AppID 2820140

-- MAIN APPLICATION
addappid(2820140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820141, 1, "4202340fc8dc8a98784c84ca79fc7a299a3033ccc7fb0a329a0075426a9fbfe8")
addappid(2820142, 1, "bb9960731db224bdd09803b5c684180dd8880019fb5a23bd7cd448c3f83d62b5")
addappid(2820143, 1, "ca42c6e0cca971a1d9100da7d4c000de0db10ac87eb14b357e48b81cd2ea2c67")
addappid(2820144, 1, "e1087b41d01c7922171d804b224b324aae5f1e0baea5e0d1522c1aa04fd5c7ba")
addappid(2820145, 1, "91a942c2c9cee73c42b868f13f58ae1e38b3c7910f8f7bc32c69f59bc29d57d1")
addappid(2820146, 1, "4ecca2e06b53e3c589f70379b9f827927c2ee7ebdc041ad23972082cacfd95f8")
addappid(2820147, 1, "800aa90f59499f7cd633e8772674a3ad8cb2efa449abb7fa3eb766bad3a88314")
addappid(2820148, 1, "c3d8d86aef160c5d80430f748117fae50b5112b1ae790a6170c877caf1dd2b87")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2914950)
