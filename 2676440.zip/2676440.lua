-- Lua provided by RyzenAPI
-- Game: Game: GLITCH DADDY

-- MAIN APPLICATION
addappid(2676440)
-- Game: addappid(2676440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676441, 1, "2eb9c0547a431e452452669f2403bc0f7aee96e28acfc3c1a283047410144a16")
