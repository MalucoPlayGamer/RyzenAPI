-- Lua provided by RyzenAPI
-- Game: AppID 213350

-- MAIN APPLICATION
addappid(213350)

-- MAIN APP DEPOTS / PACKAGES
addappid(213351, 1, "dc26b0ec45257809fb774d7c4f1380e26a6bce3d38ce04658aac5c52e7b2dcc9")
