-- Lua provided by RyzenAPI
-- Game: 1554570

-- MAIN APPLICATION
addappid(1554570)
-- Game: addappid(1554570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554572,0,"59bf878757dd4fb78d4d1b0c2bbfccaf3a77da000a94c8a3674d224b6ff8e26c")
