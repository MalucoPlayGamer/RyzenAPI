-- Lua provided by RyzenAPI
-- Game: Game: AppID 951750

-- MAIN APPLICATION
addappid(951750)
-- Game: addappid(951750)

-- MAIN APP DEPOTS / PACKAGES
addappid(951751, 1, "fa99e26ab8e19a698aa737a993e4c776f5545762eff15a83cd2728ef5fb63f16")
