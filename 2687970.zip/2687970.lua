-- Lua provided by RyzenAPI
-- Game: TRIBES 3: Rivals

-- MAIN APPLICATION
addappid(2687970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687971, 1, "b503b889ffffd0a9c7b359b754db8098c7f13b10548472db0311f575168ad58e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2864280)
addappid(2864430)
