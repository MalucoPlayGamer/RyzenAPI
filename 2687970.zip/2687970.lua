-- Lua provided by RyzenAPI
-- Game: addappid(2687970)

-- MAIN APPLICATION
addappid(2687970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687971, 1, "b503b889ffffd0a9c7b359b754db8098c7f13b10548472db0311f575168ad58e")
