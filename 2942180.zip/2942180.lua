-- Lua provided by RyzenAPI
-- Game: Hentai Tales: Seed Prison

-- MAIN APPLICATION
addappid(2942180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942181, 1, "c2ef5a058a0298d27005171a3e2c0a56683e32b733cc069e2b85bd3b177614d0")

