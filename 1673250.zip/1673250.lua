-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Tuscan Seaside Tiles

-- MAIN APPLICATION
addappid(1673250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673250,0,"81fce6847680af3c4be47c44d70831abfdd7ef9cbf9c5536acb6b0cabc079fd8")

