-- Lua provided by RyzenAPI
-- Game: 2673820

-- MAIN APPLICATION
addappid(2673820)
-- Game: addappid(2673820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673821, 1, "e202b5ad9646d33829d8b69d4c54fa2c3d96783077108fd1609872a5deab92df")
