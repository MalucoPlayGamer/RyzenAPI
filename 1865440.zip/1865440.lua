-- Lua provided by RyzenAPI
-- Game: Cave Crawler

-- MAIN APPLICATION
addappid(1865440)

