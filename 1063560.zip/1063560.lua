-- Lua provided by RyzenAPI 
-- Game: 12 HOURS
addappid(1063560)
addappid(1063561, 1, "52ec012ec941d30c0598abca4629dc199df341cda3db68007400e8fbd65fc2a8")
addappid(1099330, 0, "f88272396d84b1ad8e3dbd651911aef7d4d2bf7435eac36550847d89a08d3c9f")
