-- Lua provided by RyzenAPI 
-- Game: The Operator - Original Soundtrack
addappid(3110180)
addappid(3110181, 1, "e518b045374bc922fe1fa82e429a4761cb17ac790190bd3f24645657ad51b0f5")
addappid(3110182, 1, "3d8422bdea6ca063285f6a69edd4607d868a52c6b432bb8c35a28c81bc11f8c9")
