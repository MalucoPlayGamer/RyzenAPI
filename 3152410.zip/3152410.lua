-- Lua provided by RyzenAPI
-- Game: 3152410

-- MAIN APPLICATION
addappid(3152410)
-- Game: addappid(3152410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152411, 1, "12c8b1e081617ef524c8698865ccd0ebe6710d1f6ebe71ea8eafbbdfe17bbdb5")
