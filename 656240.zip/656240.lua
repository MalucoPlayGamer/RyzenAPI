-- Lua provided by RyzenAPI
-- Game: 656240

-- MAIN APPLICATION
addappid(656240)
-- Game: addappid(656240)

-- MAIN APP DEPOTS / PACKAGES
addappid(656241, 1, "4b23d627ab1743716d87fe6a43683a9b935b8e736f1c06112f0a0dbc34084024")
