-- Lua provided by SkyAPI 
-- Game: AppID 656240
addappid(656240)
addappid(656241, 1, "4b23d627ab1743716d87fe6a43683a9b935b8e736f1c06112f0a0dbc34084024")
