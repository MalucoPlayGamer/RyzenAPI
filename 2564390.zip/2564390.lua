-- Lua provided by RyzenAPI
-- Game: Game: AppID 2564390

-- MAIN APPLICATION
addappid(2564390)
-- Game: addappid(2564390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564391, 1, "928bd0f69beae55c211720aff4d808e544fc4b2817bd134f10e5578c4767fd8a")
