-- Lua provided by RyzenAPI
-- Game: Spacebase DF-9

-- MAIN APPLICATION
addappid(246090)
addappid(259260)

-- MAIN APP DEPOTS / PACKAGES
addappid(246091, 1, "fa7475dbc7efeb1fd163212171d3abae1e16912dba28c15d96a293754cf95f55")
addappid(246092, 1, "3bcc9d5960bf5ff15cf051e7e52db4d125f1fe6281b2722c357942b7de6ad751")
addappid(246093, 1, "2f3a6a4be8b0f2840784adac46bb04dbb3df857bf938cd4e578ab373cca8f1a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
