-- Lua provided by RyzenAPI
-- Game: setManifestid(808363,"3222425643897474064")

-- MAIN APPLICATION
addappid(808360)
-- Game: addappid(808360)

-- MAIN APP DEPOTS / PACKAGES
addappid(808363,0,"a490571a12ffe710b867f60bbbba1db16d3494bd641f0c73a7a77a3fd148a088")
