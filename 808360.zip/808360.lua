-- Lua provided by RyzenAPI
-- Game: Graveyard Birds

-- MAIN APPLICATION
addappid(808360)

-- MAIN APP DEPOTS / PACKAGES
addappid(808363,0,"a490571a12ffe710b867f60bbbba1db16d3494bd641f0c73a7a77a3fd148a088")

