-- Lua provided by RyzenAPI
-- Game: EXZEAL Original Soundtrack

-- MAIN APPLICATION
addappid(473110)

-- MAIN APP DEPOTS / PACKAGES
addappid(473111, 1, "1760491fef957439c100249788883a67fc3ad2169520ac8854a25d4fc03d3e0f")

