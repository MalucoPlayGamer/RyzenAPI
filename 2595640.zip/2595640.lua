-- Lua provided by RyzenAPI
-- Game: Move The Chains - Season 1

-- MAIN APPLICATION
addappid(2595640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595642,0,"7c0f70d282a58bb2a0743a2352abe791d583df281cab4d7026f67cd82e382688")
addappid(3182970,0,"2da36604f158dbd21647938c82388f4cf75b6ae857b2db52755dc33bced11ded")

