-- Lua provided by RyzenAPI
-- Game: Fancy Skiing VR

-- MAIN APPLICATION
addappid(512080)
-- Game: addappid(512080)

-- MAIN APP DEPOTS / PACKAGES
addappid(512081, 1, "50663fca29af0dc74331985a8dd0851d1019e147b414eeb253b231bc883ae826")
addappid(512082, 1, "d5fb4a6c2e8f1b7f8802e826893a8d5610a37c2c1c50039fb0af991940b0b0bf")
