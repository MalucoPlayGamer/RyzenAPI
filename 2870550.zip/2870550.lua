-- Generated with Luie @ https://lua.tools/
-- 2870550 - Galactic Love Utopia
-- Generated 2026-08-29 07:13:19 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(2870550, 1, "46028ca5d566f5299be161e20fc0a53674b14a9af019475e9fc6f4220bd0a324")

-- Main Depots
addappid(2870551, 1, "0520f2a97b55a5d2788f36d9ea9f9be8cf5e648b382904efc0af5cf41cea88f7")
setManifestid(2870551, "376233997554644981", 3311119958)
