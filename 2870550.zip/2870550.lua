-- Lua provided by RyzenAPI
-- Game: Galactic Love Utopia

-- MAIN APP DEPOTS / PACKAGES
addappid(2870550, 1, "46028ca5d566f5299be161e20fc0a53674b14a9af019475e9fc6f4220bd0a324")
addappid(2870551, 1, "0520f2a97b55a5d2788f36d9ea9f9be8cf5e648b382904efc0af5cf41cea88f7")