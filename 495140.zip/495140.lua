-- Lua provided by RyzenAPI
-- Game: 495140

-- MAIN APPLICATION
addappid(495140)
-- Game: addappid(495140)

-- MAIN APP DEPOTS / PACKAGES
addappid(495141, 1, "78542431af43146b9f53910d3bf2450a1cebf5ce5166f7d05cf474135be186ea")
