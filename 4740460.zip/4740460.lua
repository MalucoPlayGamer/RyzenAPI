-- Lua provided by RyzenAPI
-- Game: 十米爆爽超变

-- MAIN APPLICATION
addappid(4740460)

