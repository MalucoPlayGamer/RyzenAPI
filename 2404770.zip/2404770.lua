-- Lua provided by SkyAPI 
-- Game: Chicken Tricks
addappid(2404770)
addappid(2404771, 1, "0236836cb3065f4d6a12818d7888a3ec78905278a5bbbe64baba048a4ba2cf90")
