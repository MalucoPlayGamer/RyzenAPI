-- Lua provided by RyzenAPI
-- Game: Game: Chicken Tricks

-- MAIN APPLICATION
addappid(2404770)
-- Game: addappid(2404770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404771, 1, "0236836cb3065f4d6a12818d7888a3ec78905278a5bbbe64baba048a4ba2cf90")
