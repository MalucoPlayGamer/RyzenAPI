-- Lua provided by RyzenAPI
-- Game: Chicken Tricks

-- MAIN APPLICATION
addappid(2404770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404771, 1, "0236836cb3065f4d6a12818d7888a3ec78905278a5bbbe64baba048a4ba2cf90")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
