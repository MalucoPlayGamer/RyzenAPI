-- Lua provided by RyzenAPI
-- Game: Game: Community College Hero: Fun and Games

-- MAIN APPLICATION
addappid(1782860)
-- Game: addappid(1782860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782861, 1, "eba53e1047eecf91b258e3164465f1481887fad776f8d62cc013bfb80f2bd9c3")
