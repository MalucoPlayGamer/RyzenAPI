-- Lua provided by RyzenAPI
-- Game: addappid(454550)

-- MAIN APPLICATION
addappid(454550)

-- MAIN APP DEPOTS / PACKAGES
addappid(454551, 1, "0a717f18d31fc1eaa620b2385ac69a927ed919b407ed4aace493b6fb86761abe")
