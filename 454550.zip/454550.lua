-- Lua provided by RyzenAPI
-- Game: Qubicle Voxel Editor

-- MAIN APPLICATION
addappid(454550)
addappid(456110)
addappid(456230)
addappid(456231)
addappid(464560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(454551, 1, "0a717f18d31fc1eaa620b2385ac69a927ed919b407ed4aace493b6fb86761abe")

