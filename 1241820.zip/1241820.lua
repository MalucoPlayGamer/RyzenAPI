-- Lua provided by SkyAPI 
-- Game: AppID 1241820
addappid(1241820)
addappid(1241821, 1, "2df0bf0b3dc1f2a0be0e08a2d9ac2a4250649fee751fc861f26762d0e5bc8919")
