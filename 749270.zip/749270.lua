-- Lua provided by RyzenAPI
-- Game: Game: Magic Siege - Defender

-- MAIN APPLICATION
addappid(749270)
-- Game: addappid(749270)

-- MAIN APP DEPOTS / PACKAGES
addappid(749271, 1, "6ecf521351f1a04cdb87e7139c882a44aec6fac93ed18d97eede654404fe0cb8")
