-- Lua provided by RyzenAPI
-- Game: Not Involved Demo

-- MAIN APPLICATION
addappid(2429560)
-- Game: addappid(2429560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429561, 1, "de7efad8edd35862acc46e651ffd6d123a61cb4aba7c83870bd01a8ffaf0f141")
