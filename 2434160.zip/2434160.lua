-- Lua provided by RyzenAPI
-- Game: Office Is My Harem🔞

-- MAIN APPLICATION
addappid(2434160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434161, 1, "9f15a7ee019e495b267436320f3b6d7a5fac4f4def65b153f11d75f05786266c")
