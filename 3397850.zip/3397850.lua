-- Lua provided by RyzenAPI
-- Game: addappid(3397850)

-- MAIN APPLICATION
addappid(3397850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3397851, 1, "34de6dcd720bd26404bdcb94c3a2d14c3614d20d92d9c099db0ef507c6245032")
