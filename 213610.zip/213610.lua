-- Lua provided by RyzenAPI
-- Game: addappid(213610)

-- MAIN APPLICATION
addappid(213610)
addappid(217900)

-- MAIN APP DEPOTS / PACKAGES
addappid(213611, 1, "62f1345bc9ba1ad0629de28584b42ae616b50160113d7735b6eda7f0e9434117")
