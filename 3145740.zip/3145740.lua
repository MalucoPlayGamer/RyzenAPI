-- Lua provided by RyzenAPI
-- Game: VRider SBK™

-- MAIN APPLICATION
addappid(3145740)
-- Game: addappid(3145740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3145741, 1, "caaa99ce0f1d4691305b06eb85ca9494609f01f63528f4802680e3aad6dea6d7")
