-- Lua provided by RyzenAPI
-- Game: Librarian: Tidy Up the Arcane Library!

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4197610, 1, "3395ec08d845610070523bc65b3c1b3a42351c90b220ea5061a5ea3d511a5a27")
addappid(4197611, 1, "7e993b4b5641cd2b8a90a465d2ee2448a2443a34f97c6d20ea87b3ed0b4625fc") -- Depot 4197611

