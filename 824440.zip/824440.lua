-- Lua provided by RyzenAPI
-- Game: Abandoned Snowy Castle

-- MAIN APPLICATION
addappid(824440)

-- MAIN APP DEPOTS / PACKAGES
addappid(824441, 1, "2a742c7f193c3bae81e129b19e3efb2e70c1504d58f348c9eba91930f19d9226")

