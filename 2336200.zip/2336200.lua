-- Lua provided by RyzenAPI
-- Game: 2336200

-- MAIN APPLICATION
addappid(2336200)
-- Game: addappid(2336200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336201, 1, "4fee206ce00d50938a4012d5f065dbfff6c0c908c0e37c24f0658327a0bbdae9")
