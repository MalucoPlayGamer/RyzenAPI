-- Lua provided by RyzenAPI
-- Game: DIMENSIONS

-- MAIN APPLICATION
addappid(2559050)
addappid(2823180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2559051, 1, "102231cde0a3a13f1f81f308e97e6113b7bbb1d48f5de529b38ef3a03781e2c2")

