-- Lua provided by RyzenAPI
-- Game: 2559050

-- MAIN APPLICATION
addappid(2559050)
-- Game: addappid(2559050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2559051, 1, "102231cde0a3a13f1f81f308e97e6113b7bbb1d48f5de529b38ef3a03781e2c2")
