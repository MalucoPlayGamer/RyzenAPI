-- Lua provided by RyzenAPI
-- Game: Kaptain Brawe: A Brawe New World

-- MAIN APPLICATION
addappid(65080)

-- MAIN APP DEPOTS / PACKAGES
addappid(65081, 1, "41b72d1619af80e7af7646af2e13f9cbeee2b0954e4fe0842c93e4d5d24979ce")
addappid(65082, 1, "763ea7abe3810e91fc57405bf56d3304008330357aa065b94b891ee26ccb0a2e")
addappid(65083, 1, "157917bd1c5ef3fb6e7ca680d1ccca7ee68197a6b29c770d2bbb01ec909376ab")
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

