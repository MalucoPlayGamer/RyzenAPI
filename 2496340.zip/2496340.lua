-- Lua provided by RyzenAPI
-- Game: Night Run Playtest

-- MAIN APPLICATION
addappid(2496340)
-- Game: addappid(2496340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496341, 1, "9bd33be386c335f38e4b301513918f94558f2aad6f814ce3b384671f563b9106")
