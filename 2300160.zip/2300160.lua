-- Lua provided by RyzenAPI
-- Game: addappid(2300160)

-- MAIN APPLICATION
addappid(2300160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300161, 1, "c6682388389db35a2d939cdfafe685e4e36692732af45490f61c11d9c4ef7309")
