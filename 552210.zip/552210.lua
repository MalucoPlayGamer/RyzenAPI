-- Lua provided by RyzenAPI
-- Game: Game: peakvox Route Candle for Steam

-- MAIN APPLICATION
addappid(552210)
-- Game: addappid(552210)

-- MAIN APP DEPOTS / PACKAGES
addappid(552211, 1, "1aad1a4e3230c3f56727a9d7451d5afd00b5ad76425d9252ec92d39175d7a6fb")
