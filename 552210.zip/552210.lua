-- Lua provided by RyzenAPI
-- Game: peakvox Route Candle for Steam

-- MAIN APPLICATION
addappid(552210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(552211, 1, "1aad1a4e3230c3f56727a9d7451d5afd00b5ad76425d9252ec92d39175d7a6fb")

