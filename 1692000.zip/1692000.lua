-- Lua provided by RyzenAPI
-- Game: 雨音スイッチ - Amane Switch -

-- MAIN APPLICATION
addappid(1692000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692001, 1, "86714b01b626cbaac47488a2a7ffe20223195f9e8d36486ee37922c5567ec4cd")

