-- Lua provided by RyzenAPI
-- Game: addappid(676030)

-- MAIN APPLICATION
addappid(676030)

-- MAIN APP DEPOTS / PACKAGES
addappid(676032,0,"7efb8ce34700d6d4fabd56817481057ff5ce582049c8c7b975da7a40c2dccd1e")
