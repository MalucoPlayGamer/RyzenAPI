-- Lua provided by RyzenAPI
-- Game: 2420

-- MAIN APPLICATION
addappid(2420)
-- Game: addappid(2420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
addappid(2402,0,"fa1c2ff566f4ea5244afe781ad841f82a8ce01915dd9eb789d72ecde9ef0efc4")
addappid(2405,0,"d2258c2e3f2c13f7317b1b3db0de5aa9d837580b99dded40d194ae22ead53380")
addappid(2407,0,"2d2c166b0ac3c9be109f706026f494c0d4301638ff36be72b118a0e5d8b3ebff")
addappid(2408,0,"0e19d5c76db122d41396bcb872d09a93979398bb6785f9b240aae0a2f10efb62")
addappid(2433,0,"8ded62b8a7abac130a1c01663ba4b4e756855f8e89a1a7d25c1c4083b6d4f67f")
