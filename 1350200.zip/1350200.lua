-- Lua provided by RyzenAPI
-- Game: 1350200

-- MAIN APPLICATION
addappid(1350200)
-- Game: addappid(1350200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350202,0,"6263aac3e09dae5c533b029b581ff0684c0f3bb2a76d1d40e9dc33e3616b687e")
addappid(1350203,0,"994f65229d2ddd65368e99c1e01683de1c0a8a178d05388cbca476c1fa9f1adc")
