-- Lua provided by RyzenAPI
-- Game: addappid(2455630)

-- MAIN APPLICATION
addappid(2455630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455631, 1, "49964f9adc46beaf3f2e8e0a97b3fca7591b5c9894d36bd1da29719ac7213d2b")
