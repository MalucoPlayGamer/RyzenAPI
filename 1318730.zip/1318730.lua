-- Lua provided by RyzenAPI
-- Game: addappid(1318730)

-- MAIN APPLICATION
addappid(1318730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318731, 1, "d16f91743ec2b4eac44b89aa9a41639ea22eac0b0e57b84bb34a2c1497bcefdf")
