-- Lua provided by RyzenAPI
-- Game: WitchSpring3 Re:Fine - The Story of Eirudy -

-- MAIN APPLICATION
addappid(1592520)
addappid(1611450)
addappid(1612670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592521, 1, "fc0ffe7dae93ed9a8c14a36d67a915b01ff4279f25bb874e351981804fdd8f42")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1753550)
