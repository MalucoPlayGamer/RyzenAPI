-- Lua provided by RyzenAPI
-- Game: Medieval Dynasty - Original Soundtrack Vol. 2

-- MAIN APPLICATION
addappid(3214760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214761, 1, "eca4676503d291016a05d1eba062320bcb338ccf294d0b8ea55d2fb69c344b10")
addappid(3214762, 1, "bb842d206582aea08c09e1e6288567829067db21c049c89f23959a731a9dfa9b")

