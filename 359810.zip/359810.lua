-- Lua provided by RyzenAPI
-- Game: Game: AppID 359810

-- MAIN APPLICATION
addappid(359810)
-- Game: addappid(359810)

-- MAIN APP DEPOTS / PACKAGES
addappid(359811, 1, "794ebefd5375162751b75da0bfc2a1be3e9b0f440e85ed93fff738522cf6b3c7")
addappid(359812, 1, "b3c2a21d5620ce426d373fad903421e2a2224eb3d91ef6ba7adf6fae30064bf7")
addappid(359813, 1, "cb8be4e60743d97be73a4891ddb082e99280d3146ecc82073c29046809ed0013")
addappid(460890, 0, "c0358c8ac7ae9a51937c9bcc42674ad066ea731708ef853d0d7bd07ac33e06da")
