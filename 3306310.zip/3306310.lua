-- Lua provided by RyzenAPI
-- Game: Welcome to a Sexy, Open World!

-- MAIN APPLICATION
addappid(3306310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3306311, 1, "59b7e130c2d189eed83fe82d7f1ef0ba45642052e24356f67b7e0847e6702242")

