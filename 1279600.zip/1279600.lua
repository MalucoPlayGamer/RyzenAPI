-- Lua provided by RyzenAPI
-- Game: addappid(1279600)

-- MAIN APPLICATION
addappid(1279600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279601, 1, "c51ae236bcadb903d8be59c3be5fe2b44c6a9d017785a8787f18663c017e1f29")
