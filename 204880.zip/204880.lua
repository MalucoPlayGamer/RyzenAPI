-- Lua provided by RyzenAPI
-- Game: Sins of a Solar Empire®: Rebellion

-- MAIN APPLICATION
addappid(204880)
addappid(228983)
addappid(228984)
addappid(228987)
addappid(228990)
addappid(229003)
-- Game: addappid(204880)

-- MAIN APP DEPOTS / PACKAGES
addappid(204881, 1, "625ff525b2a56ec1aa37c3baaada74f4d9a5d17b646f7ee69df7b42355e068df")
addappid(204882, 1, "9b4fd4ef076a1e6d6ffcc9f43fbe6966d365aa3aa12d35598978a1fdc482629d")
addappid(204883, 1, "b536802805d6d0875bea553258c4eea542cabf31606f4f683302199715680a59")
addappid(204884, 1, "4023e5670bf7eb3acd9e13adb1c05f9e525df51e58698793c4eea36a1024ca7e")
addappid(204885, 1, "0bcc039fc949a097ff131d2bd759729286b9e5d87c204085801c2e851d7c1a4c")
addappid(204886, 1, "ba49ade2d8190372afbe1e90ad35ea338d483d13fa17a51aa5de256c89194336")
addappid(204887, 1, "f8a998ca0fe9afecc8b93a24318a89244cf3ada2897193d4f65d22eb0fa6fb86")
addappid(204888, 1, "1ce2bd3c09f521d416621e94eaa632a95286f00f0d5cf2ce6a62a3b28f0c6330")
addappid(204889, 1, "006fc20a42de99c68e12364343b601942713935e489d4e238b36052792d9cca5")
