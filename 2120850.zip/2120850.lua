-- Lua provided by RyzenAPI
-- Game: The Elder Goddess

-- MAIN APPLICATION
addappid(2120850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120851, 1, "0ab529516172a1c96230d0c18f1389a11294a8997de1206bd0ce5e172f757abb")

