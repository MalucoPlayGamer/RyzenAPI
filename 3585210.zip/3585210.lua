-- Lua provided by SkyAPI 
-- Game: Your Granny
addappid(3585210)
addappid(3585211, 1, "d06c8a512aa857710484e5b952e85b3b0885ec68009e4037c53a471eee2ea901")
