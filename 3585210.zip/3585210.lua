-- Lua provided by RyzenAPI
-- Game: Your Granny

-- MAIN APPLICATION
addappid(3585210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3585211, 1, "d06c8a512aa857710484e5b952e85b3b0885ec68009e4037c53a471eee2ea901")

