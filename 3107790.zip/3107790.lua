-- Lua provided by RyzenAPI
-- Game: ReBullet

-- MAIN APPLICATION
addappid(3107790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107791, 1, "a7f16e91a11b9fcd0be81e5df4d9a2e8d530489c6beecf224018d4e5b19fb6c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
