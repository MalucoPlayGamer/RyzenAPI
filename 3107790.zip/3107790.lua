-- Lua provided by RyzenAPI 
-- Game: ReBullet
addappid(3107790)
addappid(3107791, 1, "a7f16e91a11b9fcd0be81e5df4d9a2e8d530489c6beecf224018d4e5b19fb6c8")
