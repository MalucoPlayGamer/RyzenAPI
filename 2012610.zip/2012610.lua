-- Lua provided by RyzenAPI
-- Game: Age of Undead

-- MAIN APPLICATION
addappid(2012610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012611, 1, "e13d6b59cbcfe8b7365293e1b382d8fc5437b8e96c8da7a1ffd6edd694a68792")
