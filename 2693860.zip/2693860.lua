-- Lua provided by RyzenAPI
-- Game: NARIBIKIMURA

-- MAIN APPLICATION
addappid(2693860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693861, 1, "c305357e95bd5832634536902ab6a2ec887771372ce07321a86c486e6fc0031b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
