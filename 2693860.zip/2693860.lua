-- Lua provided by RyzenAPI 
-- Game: NARIBIKIMURA
addappid(2693860)
addappid(2693861, 1, "c305357e95bd5832634536902ab6a2ec887771372ce07321a86c486e6fc0031b")
