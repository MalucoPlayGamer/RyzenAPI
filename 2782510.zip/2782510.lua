-- Lua provided by SkyAPI 
-- Game: ARATAMAKAMI
addappid(2782510)
addappid(2782511, 1, "68ee63d1f44dd68452fc4b72550144ec4d95c50ade17a9a3ed8b976a4d05a61f")
