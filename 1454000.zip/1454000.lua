-- Lua provided by RyzenAPI
-- Game: 1454000

-- MAIN APPLICATION
addappid(1454000)
addappid(2411030)
addappid(2411031)
addappid(2452530)
-- Game: addappid(1454000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454001, 1, "b04a8baf5e029d46b9d278e2fd5766202035a87416329dacd2becf0e49bb74bc")
