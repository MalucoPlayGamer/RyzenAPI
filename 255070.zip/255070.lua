-- Lua provided by RyzenAPI
-- Game: 255070

-- MAIN APPLICATION
addappid(255070)
addappid(311590)
-- Game: addappid(255070)

-- MAIN APP DEPOTS / PACKAGES
addappid(255071, 1, "e98ae1ff35af615cd7f953505442fbc58072aac748145754cd3de90f984c84bc")
addappid(255073, 1, "7ecfc81fe1158b6bb1886217a7ffe2e7517b499eea3613358d67b4fd111e7ab9")
