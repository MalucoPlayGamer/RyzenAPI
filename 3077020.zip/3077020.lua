-- Lua provided by RyzenAPI
-- Game: DOKAPON! Sword of Fury

-- MAIN APPLICATION
addappid(3077020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3077021, 1, "f1fe5b4ac18c2e50df6c380046f21935408a3373d68373a0409d9eed6dd71336")

