-- Lua provided by RyzenAPI
-- Game: AppID 1493270

-- MAIN APPLICATION
addappid(1493270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493271, 1, "55d71acdfa995ec7abea04bfa8822cfebf3375aa3f53af3adf66b4a2f5036b14")

