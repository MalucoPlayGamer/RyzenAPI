-- Lua provided by RyzenAPI
-- Game: AppID 876460

-- MAIN APPLICATION
addappid(876460)

-- MAIN APP DEPOTS / PACKAGES
addappid(876461, 1, "15be018268e7945672a86c613d7fdde9e357ef3c07de4991102d4fd36b701436")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
