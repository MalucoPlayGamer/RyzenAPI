-- Lua provided by RyzenAPI
-- Game: Game: AppID 876460

-- MAIN APPLICATION
addappid(876460)
-- Game: addappid(876460)

-- MAIN APP DEPOTS / PACKAGES
addappid(876461, 1, "15be018268e7945672a86c613d7fdde9e357ef3c07de4991102d4fd36b701436")
