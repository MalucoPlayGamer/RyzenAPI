-- Lua provided by RyzenAPI
-- Game: SGS Imjin War

-- MAIN APPLICATION
addappid(2948480)
-- Game: addappid(2948480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2948481, 1, "0a631af0fd0786f237619a8f3ff515d5833e2c8eae18ee639886d76623e870ae")
addappid(2948483, 1, "894c02e74831b49c62ac0905fe277d4d5ab69bfe29790094ef3d6fcee30fe995")
