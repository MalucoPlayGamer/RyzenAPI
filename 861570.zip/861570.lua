-- Lua provided by RyzenAPI
-- Game: 861570

-- MAIN APPLICATION
addappid(861570)
-- Game: addappid(861570)

-- MAIN APP DEPOTS / PACKAGES
addappid(861571, 1, "3a1c2b4d63cb86b3fd6959a40b9b9a5930ffd8f8403a3e5bb6b73db482410050")
