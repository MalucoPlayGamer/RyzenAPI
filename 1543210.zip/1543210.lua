-- Lua provided by RyzenAPI
-- Game: 1543210

-- MAIN APPLICATION
addappid(1543210)
-- Game: addappid(1543210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543211, 1, "1876646f1b9dc2f080549556b18bd0a0a23fc4b048833d82d836daa71a77ba2b")
