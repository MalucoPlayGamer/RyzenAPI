-- Lua provided by RyzenAPI
-- Game: addappid(582210)

-- MAIN APPLICATION
addappid(582210)

-- MAIN APP DEPOTS / PACKAGES
addappid(582211, 1, "8e966b8cb9445343b0a58b051a1729d5c4db49f9d5919ca7be386a18f950715e")
