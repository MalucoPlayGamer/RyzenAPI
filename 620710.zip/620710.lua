-- Lua provided by RyzenAPI
-- Game: Game: TankBlitz

-- MAIN APPLICATION
addappid(620710)
-- Game: addappid(620710)

-- MAIN APP DEPOTS / PACKAGES
addappid(620711, 1, "a0c6eb21d65929c00adf6d5c50ac3e7196ebc97c1607378143b90af06760c004")
