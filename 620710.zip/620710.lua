-- Lua provided by SkyAPI 
-- Game: TankBlitz
addappid(620710)
addappid(620711, 1, "a0c6eb21d65929c00adf6d5c50ac3e7196ebc97c1607378143b90af06760c004")
