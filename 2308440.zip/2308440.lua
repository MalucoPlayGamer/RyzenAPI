-- Lua provided by RyzenAPI
-- Game: 2308440

-- MAIN APPLICATION
addappid(2308440)
-- Game: addappid(2308440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308441, 1, "f9eebb7fde2cd3344eeb3a5584113145b336c5feff755addfeaf688676c9bde9")
