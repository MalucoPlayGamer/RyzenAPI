-- Lua provided by RyzenAPI
-- Game: Goliath

-- MAIN APPLICATION
addappid(363520)

-- MAIN APP DEPOTS / PACKAGES
addappid(363521, 1, "b160b3cbca1814c55376413aba0e1614002f4200e6b3553aecd8ac4fc7e10c63")
addappid(363522, 1, "b8fda535b0fff28f220da4f1e7e33e1ae5a3be187f24fad81cac6a7a6dfc8902")
addappid(363523, 1, "970e881bc496062f8e9b764b29a5b52ca29ccd0604b5753c36bd4781e0e1b8bc")
addappid(363524, 1, "56cd0f807c8f34d261fecb6cc43bc8751376c670fc553f74fde4f35ce7e90fe6")
addappid(433200, 0, "8f4ec37a27b32b7f975e07ddf61470ba55afcf7ba3f330a6ba8e4652adf56c3f")
addappid(493240, 0, "4f9d4bc752a4d670fc24ae9a3a4deeecccdb4369c93f3c858302c0ee96c747de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
