-- Lua provided by RyzenAPI
-- Game: R.B.I. Baseball 21

-- MAIN APPLICATION
addappid(1462150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1462151, 1, "52e24dfc16de37c330f88d5687b006b355f6c3e92b07b8a237631a8e8f8e985c")

