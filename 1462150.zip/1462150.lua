-- Lua provided by RyzenAPI
-- Game: R.B.I. Baseball 21

-- MAIN APPLICATION
addappid(1462150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462151, 1, "52e24dfc16de37c330f88d5687b006b355f6c3e92b07b8a237631a8e8f8e985c")
