-- Lua provided by SkyAPI 
-- Game: Trident's Wake
addappid(704880)
addappid(704881, 1, "6e7e8051bdb870f8b38fd0587fed034b43c8cf5b0412f0f1c51e7845ce0d44fe")
