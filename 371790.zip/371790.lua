-- Lua provided by RyzenAPI
-- Game: Ramayana

-- MAIN APPLICATION
addappid(371790)

-- MAIN APP DEPOTS / PACKAGES
addappid(371791, 1, "a86b213b5d14e0570d9fc4d6936b61494079c64e79bcbf96c198cf92efd110c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
