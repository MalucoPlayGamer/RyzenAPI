-- Lua provided by RyzenAPI 
-- Game: Ramayana
addappid(371790)
addappid(371791, 1, "a86b213b5d14e0570d9fc4d6936b61494079c64e79bcbf96c198cf92efd110c3")
