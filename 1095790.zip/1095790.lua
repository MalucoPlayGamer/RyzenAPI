-- Lua provided by RyzenAPI
-- Game: 1095790

-- MAIN APPLICATION
addappid(1095790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095793,0,"fb07bccdaf750ddf7e8ce6d3b35bc0d6d92db637510b512b02856dd63eafa9a7")
