-- Lua provided by RyzenAPI
-- Game: SPAGHET

-- MAIN APPLICATION
addappid(821320)

-- MAIN APP DEPOTS / PACKAGES
addappid(821321, 1, "914633fa2e5d731b8819e717d0b56eede0e994a025144b9af12b2cab8c8109dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
