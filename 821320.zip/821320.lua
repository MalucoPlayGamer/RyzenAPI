-- Lua provided by RyzenAPI 
-- Game: SPAGHET
addappid(821320)
addappid(821321, 1, "914633fa2e5d731b8819e717d0b56eede0e994a025144b9af12b2cab8c8109dc")
