-- Lua provided by RyzenAPI
-- Game: Metamorphosis

-- MAIN APPLICATION
addappid(1025410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1025411, 1, "96be9594b2e645111a45b6833fb72d2a48c96245c112554a378a5a3b8f9eb075")

