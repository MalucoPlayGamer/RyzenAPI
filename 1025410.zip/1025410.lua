-- Lua provided by RyzenAPI
-- Game: Game: Metamorphosis

-- MAIN APPLICATION
addappid(1025410)
-- Game: addappid(1025410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025411, 1, "96be9594b2e645111a45b6833fb72d2a48c96245c112554a378a5a3b8f9eb075")
