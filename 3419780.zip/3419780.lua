-- Lua provided by SkyAPI 
-- Game: Tick Hop
addappid(3419780)
addappid(3419781, 1, "627dafe6a24a91ee10d2afbd8e0cf73f87a3e222b7a374475287016d6365538d")
