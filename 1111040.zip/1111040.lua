-- Lua provided by RyzenAPI
-- Game: addappid(1111040)

-- MAIN APPLICATION
addappid(1111040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111041, 1, "8374c7fa2443c30aa8c26c5efbf4692fda3d7a86cb37b4700bf47318829614f9")
