-- Lua provided by RyzenAPI
-- Game: AppID 1111040

-- MAIN APPLICATION
addappid(1111040)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1111041, 1, "8374c7fa2443c30aa8c26c5efbf4692fda3d7a86cb37b4700bf47318829614f9")

