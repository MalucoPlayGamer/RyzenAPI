-- Lua provided by RyzenAPI
-- Game: Game: Bite Night

-- MAIN APPLICATION
addappid(2951520)
-- Game: addappid(2951520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951521, 1, "42f07f25c9bef0c5e920cfc601f57645b49a7a8db47e80dbf03b6c8e11aab4a5")
