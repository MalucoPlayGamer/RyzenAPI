-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1375366)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375366,0,"dcd69b42c3b608202180c5b7139ff90b6757a18cc42a34c0efe92bdec3d2549e")
