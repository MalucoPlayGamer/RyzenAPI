-- Lua provided by RyzenAPI
-- Game: AppID 2453160

-- MAIN APPLICATION
addappid(2453160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2453161, 1, "768d23554ddb00ac303ad9de2ebf64108fd846d8dfbc0a7b24cc911bf91914ab")

