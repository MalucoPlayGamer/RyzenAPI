-- Lua provided by SkyAPI 
-- Game: AppID 2453160
addappid(2453160)
addappid(2453161, 1, "768d23554ddb00ac303ad9de2ebf64108fd846d8dfbc0a7b24cc911bf91914ab")
