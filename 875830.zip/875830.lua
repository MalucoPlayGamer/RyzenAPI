-- Lua provided by RyzenAPI 
-- Game: Moral King
addappid(875830)
addappid(875831, 1, "920a07859c2275d5abe111bee339b3bd942e8f1daa2d9228d15ba444c4196093")
