-- Lua provided by RyzenAPI
-- Game: 2352120

-- MAIN APPLICATION
addappid(2352120)
-- Game: addappid(2352120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352121, 1, "4f5eca795ccbb7696cfec483a0921e0220bb150b296809e46361fef7ad123a58")
