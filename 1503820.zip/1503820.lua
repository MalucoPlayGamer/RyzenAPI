-- Lua provided by RyzenAPI
-- Game: Ballfrog

-- MAIN APPLICATION
addappid(1503820)
-- Game: addappid(1503820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503821, 1, "8ffddcdc6acaa8e81fd38dcbcedfa9484830dbc509e26259d31d24a27d6ed57f")
