-- Lua provided by RyzenAPI 
-- Game: Ballfrog
addappid(1503820)
addappid(1503821, 1, "8ffddcdc6acaa8e81fd38dcbcedfa9484830dbc509e26259d31d24a27d6ed57f")
