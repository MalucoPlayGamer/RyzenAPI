-- Lua provided by RyzenAPI
-- Game: Backroom Company

-- MAIN APPLICATION
addappid(3010460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3010461, 1, "e62116c41a5959c1ff5040fdd41271c8b2629fc47b804069ea2d897ee48d2f2d")
