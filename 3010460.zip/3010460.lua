-- Lua provided by RyzenAPI
-- Game: Backroom Company

-- MAIN APPLICATION
addappid(3010460)
addappid(4778210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3010461, 1, "e62116c41a5959c1ff5040fdd41271c8b2629fc47b804069ea2d897ee48d2f2d")

