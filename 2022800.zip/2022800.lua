-- Lua provided by RyzenAPI
-- Game: Game: Aokana - Four Rhythms Across the Blue Piano Album #1

-- MAIN APPLICATION
addappid(2022800)
-- Game: addappid(2022800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022801, 1, "d6ce053fcf077b0d563bfbfb0097cf11a0381bb280d0a5af8bdb16ebb27ed9d1")
addappid(2022802, 1, "83d392ef0b19831bdf81e01e5503a71eb897d2be8d3b698a89dc43cc39fd0506")
