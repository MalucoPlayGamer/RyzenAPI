-- Lua provided by RyzenAPI
-- Game: Hidden Forest

-- MAIN APPLICATION
addappid(1689020)
-- Game: addappid(1689020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689021, 1, "4b1ae667289dbc5db633ef48030c3e34319ca9f6dd683445b23f51eb7c13442f")
