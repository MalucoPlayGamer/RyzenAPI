-- Lua provided by SkyAPI 
-- Game: Hidden Forest
addappid(1689020)
addappid(1689021, 1, "4b1ae667289dbc5db633ef48030c3e34319ca9f6dd683445b23f51eb7c13442f")
