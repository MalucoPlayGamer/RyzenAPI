-- Lua provided by RyzenAPI
-- Game: addappid(593670)

-- MAIN APPLICATION
addappid(593670)

-- MAIN APP DEPOTS / PACKAGES
addappid(593672,0,"1fffffe0057156a179148813cebe7d6fdbb16f7f4952623fed6816f86c0700dd")
