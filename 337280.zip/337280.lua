-- Lua provided by RyzenAPI
-- Game: Planetship

-- MAIN APPLICATION
addappid(337280)

-- MAIN APP DEPOTS / PACKAGES
addappid(337281, 1, "f9c95de4c422cd24cad4ae1477490e1b8cea9c6f6f0ba5c36221758d33d7c2e2")
