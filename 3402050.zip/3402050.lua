-- Lua provided by RyzenAPI
-- Game: 3402050

-- MAIN APPLICATION
addappid(3402050)
-- Game: addappid(3402050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402050,0,"ec6fcdb9edb29bb90b568c581929f8945b434d50651b85706cd6e816d59788f1")
