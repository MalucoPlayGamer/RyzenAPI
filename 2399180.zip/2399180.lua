-- Lua provided by RyzenAPI
-- Game: Oh Satan, I gotta hide

-- MAIN APPLICATION
addappid(2399180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399181, 1, "4e8cb62a0a26ecbefed737ef5ed81dbbde22c4cba5361485992d0da6d7228aa9")
