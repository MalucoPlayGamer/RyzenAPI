-- Lua provided by RyzenAPI
-- Game: Skull and Bones

-- MAIN APPLICATION
addappid(2853730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2853731, 1, "714fcb880dabe47d44a94ed0315e88d867583916d2e1c24d26b648f73870ee9f")
