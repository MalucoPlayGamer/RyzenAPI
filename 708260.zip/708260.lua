-- Lua provided by RyzenAPI
-- Game: addappid(708260)

-- MAIN APPLICATION
addappid(708260)

-- MAIN APP DEPOTS / PACKAGES
addappid(708268,0,"624a3046c20ae20fb062af0faf3f264e90dbc17a011bc523ab38a2e011c307bc")
