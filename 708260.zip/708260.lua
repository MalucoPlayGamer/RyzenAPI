-- Lua provided by RyzenAPI
-- Game: setManifestid(708268,"9063717950139041594")

-- MAIN APPLICATION
addappid(708260)
-- Game: addappid(708260)

-- MAIN APP DEPOTS / PACKAGES
addappid(708268,0,"624a3046c20ae20fb062af0faf3f264e90dbc17a011bc523ab38a2e011c307bc")
