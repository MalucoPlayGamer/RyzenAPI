-- Lua provided by RyzenAPI
-- Game: Game: 欧酱的迷宫大冒险

-- MAIN APPLICATION
addappid(3244490)
-- Game: addappid(3244490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244491, 1, "a4e5970638b7856668aa7690d4020b7c7edf3994f48885a09173a0cc62827b67")
