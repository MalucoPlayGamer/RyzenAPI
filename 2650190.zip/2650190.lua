-- Lua provided by SkyAPI 
-- Game: Christmas Adventure
addappid(2650190)
addappid(2650191, 1, "c7a48796f13e130c1e4f652514707585b62f413fa288b535b9f96d23819fd717")
