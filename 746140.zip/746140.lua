-- Lua provided by RyzenAPI
-- Game: Walking zombie: Shooter

-- MAIN APPLICATION
addappid(746140)

-- MAIN APP DEPOTS / PACKAGES
addappid(746141, 1, "c33a076a30b75d495a7997be8bfdff43c0e575f531a3f573b858873fe2ca1235")
