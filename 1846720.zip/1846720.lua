-- Lua provided by SkyAPI 
-- Game: AppID 1846720
addappid(1846720)
addappid(1846721, 1, "0fa8a7d5fd3f702285647d12af11c7d8889ff5098f2524df9f7948402be863b3")
