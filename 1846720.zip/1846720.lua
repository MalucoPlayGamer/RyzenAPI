-- Lua provided by RyzenAPI
-- Game: AppID 1846720

-- MAIN APPLICATION
addappid(1846720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1846721, 1, "0fa8a7d5fd3f702285647d12af11c7d8889ff5098f2524df9f7948402be863b3")

