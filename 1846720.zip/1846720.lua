-- Lua provided by RyzenAPI
-- Game: 1846720

-- MAIN APPLICATION
addappid(1846720)
-- Game: addappid(1846720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1846721, 1, "0fa8a7d5fd3f702285647d12af11c7d8889ff5098f2524df9f7948402be863b3")
