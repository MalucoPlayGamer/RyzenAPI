-- Lua provided by RyzenAPI
-- Game: Game: SHOFER Race Driver

-- MAIN APPLICATION
addappid(367700)
-- Game: addappid(367700)

-- MAIN APP DEPOTS / PACKAGES
addappid(367701, 1, "9f268fd844319960b995cd902e03ee81e6785e1985bb1c958ab38bc43d79513a")
