-- Lua provided by RyzenAPI
-- Game: Child of Light

-- MAIN APPLICATION
addappid(256290)

-- MAIN APP DEPOTS / PACKAGES
addappid(256291, 1, "34e614ced9041d655084cd5b9ab37c65441f4ea42c7b34c37f7fcddef410fd04")
addappid(290400, 0, "448311aed69b8a3c3de26f4fb0df0116e58ab0b16c1994fc615d0c49e6365516")
addappid(290401, 0, "99eaab179428a45d4dfc276d5ad4166e7666d30ec8a7b5a65ee8331c6f4c6226")
addappid(290402, 0, "6a404920b54f6fdd9c830a4a145fc23cb09a8fb091ed679615779fb13644c34a")
addappid(290403, 0, "fc2635bee39726d03feef1335a0a03884d1adf43c889fdb89bdce03ae072b8ce")
addappid(290404, 0, "c25311f1971a0f619fecba28e833d99c2df508977dbe1d0008cae9d422602def")
addappid(290405, 0, "d7563cad9f317a2d1ec7e547f6b623f01be698908b8192e77d4e8d59d05dddb4")
addappid(290406, 0, "3d0fec5dcfc9bf0c092a0af209b77ede7ad44e4646433fda91a21a06c2f94415")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
