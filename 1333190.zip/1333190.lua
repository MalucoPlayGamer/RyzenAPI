-- Lua provided by RyzenAPI
-- Game: Rescue Team: Danger from Outer Space!

-- MAIN APPLICATION
addappid(1333190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333191, 1, "8215aad360b69acfa950e7112fcf411959ccafa1d36978b93853c244563da790")
addappid(1333192, 1, "0b13a042f480bb64377e74b4383571462f1c31f530a8ab1d022150e4e5dc1ebd")
addappid(1333193, 1, "ee0beb47735268238d1faa0432d204ee07946705d3defffc2ddef8c2f00c3423")
