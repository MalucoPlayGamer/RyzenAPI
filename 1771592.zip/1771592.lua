-- Lua provided by RyzenAPI
-- Game: 1771592

-- MAIN APPLICATION
addappid(1771592)
-- Game: addappid(1771592)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771592,0,"07c56babd5c9c872311b81631c49b759e33a7bce501cc77c1717c4c3b28e65a3")
