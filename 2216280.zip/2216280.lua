-- Lua provided by RyzenAPI
-- Game: 2216280

-- MAIN APPLICATION
addappid(2216280)
-- Game: addappid(2216280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216281, 1, "dc0cdfafecdb6420765d80cf9d6870ac406c1a0babe2949358af0291bb2eaa7e")
