-- Lua provided by RyzenAPI
-- Game: Slip 'n Dip

-- MAIN APPLICATION
addappid(1360790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360791, 1, "0026cfd833ab8761aa9983f117f3faea224e5887059055e5699df89772478da2")

