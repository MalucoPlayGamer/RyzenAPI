-- Lua provided by RyzenAPI
-- Game: 920460

-- MAIN APPLICATION
addappid(920460)
-- Game: addappid(920460)

-- MAIN APP DEPOTS / PACKAGES
addappid(920461, 1, "ee61ce1a7037840479b73f436df5add258f9956eaa53a7d53952018193edc539")
