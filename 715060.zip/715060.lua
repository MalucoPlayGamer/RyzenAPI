-- Lua provided by RyzenAPI
-- Game: Lost in the Forest

-- MAIN APPLICATION
addappid(715060)

-- MAIN APP DEPOTS / PACKAGES
addappid(715061, 1, "5976610fd27895fe2d6ce81c198fddf6ffc8f3cddbcb7b00f13f37dee2644f12")
addappid(715062, 1, "96ede7dc0b69b8179a3677b71eb6332af13a3edef7da26cd5659ac5db8020439")
addappid(715063, 1, "b627ef0ac27bd782a9bae958d52c88d8714516841e33f6b06e36b8711874df03")
addappid(715064, 1, "1d4942e9017c7f9cbb17fe6288c4c0e391f96d077421f21301e1495bc989b8ae")

