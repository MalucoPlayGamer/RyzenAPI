-- Lua provided by RyzenAPI
-- Game: Alchemist's Awakening

-- MAIN APPLICATION
addappid(431450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(431451, 1, "2f7a1574f5c0c4821aaec04731927983aee4857777d15184899053f869e99c13")

