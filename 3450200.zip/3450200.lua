-- Lua provided by RyzenAPI
-- Game: addappid(3450200)

-- MAIN APPLICATION
addappid(3450200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3450201, 1, "e1a769fe8e361f71f84bac4ccad6fe7fae5d8e9b887780e56919c004b2711437")
