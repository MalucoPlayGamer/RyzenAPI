-- Lua provided by RyzenAPI 
-- Game: AppID 3450200
addappid(3450200)
addappid(3450201, 1, "e1a769fe8e361f71f84bac4ccad6fe7fae5d8e9b887780e56919c004b2711437")
