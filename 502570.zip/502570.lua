-- Lua provided by RyzenAPI
-- Game: Houdini Indie

-- MAIN APPLICATION
addappid(502570)

-- MAIN APP DEPOTS / PACKAGES
addappid(502571, 1, "45059bb8eb99ebc52bc35445ee7afb5beb7ae9ecdb14cd772bcb16c934250517")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
