-- Lua provided by RyzenAPI
-- Game: Game: Houdini Indie

-- MAIN APPLICATION
addappid(502570)
-- Game: addappid(502570)

-- MAIN APP DEPOTS / PACKAGES
addappid(502571, 1, "45059bb8eb99ebc52bc35445ee7afb5beb7ae9ecdb14cd772bcb16c934250517")
