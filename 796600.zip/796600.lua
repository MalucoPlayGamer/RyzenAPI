-- Lua provided by RyzenAPI
-- Game: AppID 796600

-- MAIN APPLICATION
addappid(796600)

-- MAIN APP DEPOTS / PACKAGES
addappid(796601, 1, "b75f8b290a1afbe5dcb93bf98ad9d68a4dc6b40cbcce95d9af809896c795c4fe")

