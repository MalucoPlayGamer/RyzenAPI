-- Lua provided by RyzenAPI
-- Game: addappid(956930)

-- MAIN APPLICATION
addappid(956930)

-- MAIN APP DEPOTS / PACKAGES
addappid(956930,0,"d9f17ec71f6046f8e21719497c3ee2826151d03e0e5d29cdcb3248c70e2e7565")
