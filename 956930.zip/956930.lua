-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(956930)

-- MAIN APP DEPOTS / PACKAGES
addappid(956930,0,"d9f17ec71f6046f8e21719497c3ee2826151d03e0e5d29cdcb3248c70e2e7565")

