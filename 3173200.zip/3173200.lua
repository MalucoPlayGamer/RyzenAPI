-- Lua provided by RyzenAPI
-- Game: Game: Kuri Kuri Click! ~My Sweet Model!~

-- MAIN APPLICATION
addappid(3173200)
-- Game: addappid(3173200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173201, 1, "a2a1dbf489ca127e0a6e5f35205295db77ab51bc8bbef8619eecbae00d3e1f31")
addappid(3412810, 0, "fdcf062c3f2df69a79f79d9c9ff379580d672bd11463348dac13f6b454ddee72")
