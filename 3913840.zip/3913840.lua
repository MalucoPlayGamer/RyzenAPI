-- Lua provided by RyzenAPI
-- Game: Drink Factory Simulator

-- MAIN APPLICATION
addappid(3913840) -- Drink Factory Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3913841, 1, "604a40ba5922b08107c8779b3f029ac3592e7e090b455f7e225999ea05746687") -- Depot 3913841

