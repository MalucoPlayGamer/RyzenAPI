-- Lua provided by RyzenAPI
-- Game: The Mean Greens - Plastic Warfare

-- MAIN APPLICATION
addappid(228985)
addappid(360940)

-- MAIN APP DEPOTS / PACKAGES
addappid(360942,0,"7821a8577b025e172b8eddf8a76409947dd1d1db776988e73419e6624df201c0")
addappid(360943,0,"84170fb2290b11ff2c17bfce0be98d2ea3426a6a2ea065689d25b4ec533b7ad3")
addappid(360944,0,"1c5ad7f5d525092f88eb5a3e4a3997ecf7dcea10a775104a74940a3f6e1bbc13")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1567390)
addappid(1942750)
addappid(2081950)
