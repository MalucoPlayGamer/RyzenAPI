-- Lua provided by RyzenAPI
-- Game: The Mean Greens - Plastic Warfare

-- MAIN APPLICATION
addappid(228985)
addappid(360940)

-- MAIN APP DEPOTS / PACKAGES
addappid(360942,0,"7821a8577b025e172b8eddf8a76409947dd1d1db776988e73419e6624df201c0")
addappid(360943,0,"84170fb2290b11ff2c17bfce0be98d2ea3426a6a2ea065689d25b4ec533b7ad3")
addappid(360944,0,"1c5ad7f5d525092f88eb5a3e4a3997ecf7dcea10a775104a74940a3f6e1bbc13")

