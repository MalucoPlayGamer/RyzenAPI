-- Lua provided by RyzenAPI
-- Game: Game: Cumrooms

-- MAIN APPLICATION
addappid(3114500)
-- Game: addappid(3114500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114501, 1, "7c07957deba5e459d1483926da8b89f7db41672373179e1a94e245496b3b72ea")
