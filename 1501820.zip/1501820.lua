-- Lua provided by RyzenAPI
-- Game: Ziggy's Cosmic Adventures

-- MAIN APPLICATION
addappid(1501820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501821, 1, "54c123ea406aa47d67e0697ead4bc5351c751724675460fc48edea1fe3fce127")
