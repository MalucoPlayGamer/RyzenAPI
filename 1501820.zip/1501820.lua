-- Lua provided by SkyAPI 
-- Game: Ziggy's Cosmic Adventures
addappid(1501820)
addappid(1501821, 1, "54c123ea406aa47d67e0697ead4bc5351c751724675460fc48edea1fe3fce127")
