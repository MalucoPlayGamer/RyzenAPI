-- Lua provided by RyzenAPI
-- Game: Ziggy's Cosmic Adventures

-- MAIN APPLICATION
addappid(1501820)
addappid(2820720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1501821, 1, "54c123ea406aa47d67e0697ead4bc5351c751724675460fc48edea1fe3fce127")

