-- Lua provided by RyzenAPI
-- Game: 2793810

-- MAIN APPLICATION
addappid(2793810)
-- Game: addappid(2793810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793811, 1, "7c1f7d2449dd95e371c6a4437b868897ce898e982ee171a690f2c4de4e6f04dd")
