-- Lua provided by RyzenAPI
-- Game: BEACHED

-- MAIN APPLICATION
addappid(1412190)
-- Game: addappid(1412190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1412191, 1, "da0b4719a1aa78f03cb7398087b28a4698ded296de9e89f4f38149aceed5b4de")
