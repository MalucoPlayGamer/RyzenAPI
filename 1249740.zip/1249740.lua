-- Lua provided by RyzenAPI 
-- Game: Carnival Games
addappid(1249740)
addappid(1249741, 1, "bb18be0f24f8f869dcf1bedbfa53399effa088c3149c28cb8f6cf65cc3e0006d")
