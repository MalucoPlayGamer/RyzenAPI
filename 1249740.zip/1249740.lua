-- Lua provided by RyzenAPI
-- Game: Carnival Games

-- MAIN APPLICATION
addappid(1249740)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1249741, 1, "bb18be0f24f8f869dcf1bedbfa53399effa088c3149c28cb8f6cf65cc3e0006d")

