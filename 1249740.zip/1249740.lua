-- Lua provided by RyzenAPI
-- Game: Game: Carnival Games

-- MAIN APPLICATION
addappid(1249740)
-- Game: addappid(1249740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249741, 1, "bb18be0f24f8f869dcf1bedbfa53399effa088c3149c28cb8f6cf65cc3e0006d")
