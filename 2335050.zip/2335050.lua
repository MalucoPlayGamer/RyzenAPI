-- Lua provided by RyzenAPI
-- Game: addappid(2335050)

-- MAIN APPLICATION
addappid(2335050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335051, 1, "32a19a27dfd4898e9e05430b190e6e296b23b31b246729d5854acc87eb6caa6d")
