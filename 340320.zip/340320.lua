-- Lua provided by RyzenAPI
-- Game: Sinless

-- MAIN APPLICATION
addappid(340320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(340321, 1, "ea53ab3648f6ab90cfffc2786f86e6a8dde5f0fc8c3ead36c41e0cc288e30ec4")
addappid(340322, 1, "f8f4d6623fd5fb880752f329d60ec83c2f29e03f6c63f3ee0d431fbe7ad9061e")
addappid(340323, 1, "9f6c1584ac16f4f613ca2d416089c819343eedb4679ade6115557f2a0399d098")
addappid(340324, 1, "cf0f12767398b1fe98c5d3588146e7817db2674a848564dd93597b081ee951ab")

