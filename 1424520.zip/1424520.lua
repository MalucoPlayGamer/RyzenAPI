-- Lua provided by RyzenAPI 
-- Game: Astria
addappid(1424520)
addappid(1424521, 1, "60501a90cd850c12f4d0cda98f7d1f244dc9e9d5107d164d65e7d9eca6a0e240")
