-- Lua provided by RyzenAPI
-- Game: Astria

-- MAIN APPLICATION
addappid(1424520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424521, 1, "60501a90cd850c12f4d0cda98f7d1f244dc9e9d5107d164d65e7d9eca6a0e240")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
