-- Lua provided by RyzenAPI
-- Game: Game: #KILLALLZOMBIES

-- MAIN APPLICATION
addappid(303720)
-- Game: addappid(303720)

-- MAIN APP DEPOTS / PACKAGES
addappid(303721, 1, "73aa45fe2861b307cba287efe759e40485f57086e4c0574fdaf3031e41970611")
