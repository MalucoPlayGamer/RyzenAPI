-- Lua provided by RyzenAPI
-- Game: The Weird Dream

-- MAIN APPLICATION
addappid(2532300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532301, 1, "d1352a1ccd94e9420dddad608e03170fbbb8026dbc446a822dbd21f2a44db306")
