-- Lua provided by RyzenAPI 
-- Game: AppID 2532300
addappid(2532300)
addappid(2532301, 1, "d1352a1ccd94e9420dddad608e03170fbbb8026dbc446a822dbd21f2a44db306")
