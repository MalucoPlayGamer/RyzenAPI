-- Lua provided by RyzenAPI 
-- Game: AppID 949200
addappid(949200)
addappid(949201, 1, "d130e9b56c61b97a72d0478013c53156d896589f21f61c592403de273fe6bdac")
