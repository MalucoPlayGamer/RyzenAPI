-- Lua provided by RyzenAPI
-- Game: Game: Umihara Kawase Shun

-- MAIN APPLICATION
addappid(384700)
-- Game: addappid(384700)

-- MAIN APP DEPOTS / PACKAGES
addappid(384701, 1, "18d7d2b8f2d596d27f3052c92489b78de94482a41ce5b4be2bbc969608a78e0b")
