-- Lua provided by RyzenAPI
-- Game: Game: Still Life 2

-- MAIN APPLICATION
addappid(46490)
-- Game: addappid(46490)

-- MAIN APP DEPOTS / PACKAGES
addappid(46491, 1, "4f7cbd856bbb642dff4d9e0710f50de08b26e5921ea76eee0ecafa56361c6ba3")
addappid(46493, 1, "db412306fe740c132a7e023df29c2d054fe4977dd26bfbb3bde989c00b8e75c6")
addappid(46494, 1, "1692717a923b49c07514301194ef9bdb31c044301b4059b3b2d1b048961cf742")
addappid(46495, 1, "8bdec7e9d29bb0fc36a4a1108c70f2dcafe8f72fea369e46585e794cc0093f85")
addappid(46496, 1, "6f3f7b0f6c763cb37682f41efa779ed7f73282590666e6f30553619486c8902d")
