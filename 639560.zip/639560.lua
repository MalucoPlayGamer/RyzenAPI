-- Lua provided by RyzenAPI
-- Game: Spacescape

-- MAIN APPLICATION
addappid(639560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(639561, 1, "ffc2e06448f6a96688c9f3e52888e67d26285feeb24b2047b72a2f47060383f8")

