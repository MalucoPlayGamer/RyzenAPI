-- Lua provided by RyzenAPI 
-- Game: Spacescape
addappid(639560)
addappid(639561, 1, "ffc2e06448f6a96688c9f3e52888e67d26285feeb24b2047b72a2f47060383f8")
