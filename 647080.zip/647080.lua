-- Lua provided by RyzenAPI
-- Game: Haunted Halls: Green Hills Sanitarium Collector's Edition

-- MAIN APPLICATION
addappid(647080)

-- MAIN APP DEPOTS / PACKAGES
addappid(647081,0,"25337d699adf9d4fd4158e33371c29bf62589604dfdf40329b0189b653a34301")

