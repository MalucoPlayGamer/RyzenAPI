-- Lua provided by RyzenAPI
-- Game: Za češtiny ve hrách!

-- MAIN APPLICATION
addappid(2737160)
-- Game: addappid(2737160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737161, 1, "a1b035dec4c6b56e3ac32c1fb967e71afe6331ab38a3472376275b8efc400995")
