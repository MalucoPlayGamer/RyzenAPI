-- Lua provided by RyzenAPI
-- Game: Za češtiny ve hrách!

-- MAIN APPLICATION
addappid(2737160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737161, 1, "a1b035dec4c6b56e3ac32c1fb967e71afe6331ab38a3472376275b8efc400995")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
