-- Lua provided by RyzenAPI
-- Game: AppID 596710

-- MAIN APPLICATION
addappid(596710)

-- MAIN APP DEPOTS / PACKAGES
addappid(596711, 1, "84d7aee6ec3cf442c99ca6065cc877d64d195043836ecf37589281606e75e281")
addappid(596712, 1, "81c5c3714a56769c7e49051865d289f8c84c04bf05d86b995e6a68c5398f53f0")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(607100)
