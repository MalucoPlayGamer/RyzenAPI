-- Lua provided by RyzenAPI
-- Game: AppID 3552630

-- MAIN APPLICATION
addappid(3552630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3552631, 1, "ee5fbbec2a1a1c3dd8ffd877ce1d3ea24c3d2688ec8d53a3ae63d0ed8efdbe20")

