-- Lua provided by RyzenAPI
-- Game: Virtua Unlimited Project 虚拟无限计划 Demo

-- MAIN APPLICATION
addappid(2786110)
-- Game: addappid(2786110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2786111, 1, "b1f66384ced36f955216991036e82bf29f9dea735c7efaceb7f1364c3dbf9395")
