-- Lua provided by RyzenAPI
-- Game: KAWAII GIRLS PUZZLE

-- MAIN APPLICATION
addappid(1192310)
-- Game: addappid(1192310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192311, 1, "903ea869c506098033d445cfaaf5fda158abd16a8de6c100c7b167af19ed3af3")
