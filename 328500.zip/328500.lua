-- Lua provided by RyzenAPI
-- Game: Potatoman Seeks the Troof

-- MAIN APPLICATION
addappid(328500)

-- MAIN APP DEPOTS / PACKAGES
addappid(328502,0,"cf9fc6eb4a135f320c5c80b03d97ec99d2e8a5399292f3a9c3216e89db31b57b")
addappid(328503,0,"93fdb989677d11275a2e6a31746b10038f808128ec52aefede9a79ba12f16839")
