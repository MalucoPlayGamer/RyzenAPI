-- Lua provided by RyzenAPI
-- Game: 456100

-- MAIN APPLICATION
addappid(456100)
-- Game: addappid(456100)

-- MAIN APP DEPOTS / PACKAGES
addappid(456101, 1, "7082339cf5da296a7b34afcc3c7523471f526b8990ad3df7f3acf3be20b98c84")
