-- Lua provided by RyzenAPI 
-- Game: Qubicle Demo
addappid(456100)
addappid(456101, 1, "7082339cf5da296a7b34afcc3c7523471f526b8990ad3df7f3acf3be20b98c84")
