-- Lua provided by RyzenAPI
-- Game: Game: AppID 1498180

-- MAIN APPLICATION
addappid(1498180)
-- Game: addappid(1498180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498181, 1, "e90e0fa2752680eec0790808add68fb9f5dfc34d80b987402f6af828490ad17b")
