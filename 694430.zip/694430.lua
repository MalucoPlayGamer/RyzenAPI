-- Lua provided by RyzenAPI
-- Game: Alimardan Meets Merlin

-- MAIN APPLICATION
addappid(694430)

-- MAIN APP DEPOTS / PACKAGES
addappid(694431,0,"d6830c93d8495c040fbb43f36ce6767139674bd6e0a900f0d97cb62c0e62ee35")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
