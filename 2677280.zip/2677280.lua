-- Lua provided by RyzenAPI
-- Game: 梦境世界

-- MAIN APPLICATION
addappid(2677280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677281, 1, "6fdcbdf6c1c695f04c35a60e1b9ac267e3b946dddd81c0a621db329f80881070")
