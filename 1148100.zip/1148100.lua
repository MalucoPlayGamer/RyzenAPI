-- Lua provided by RyzenAPI
-- Game: Life on the Hook

-- MAIN APPLICATION
addappid(1148100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1148101, 1, "b3e71321ff6aa4c026131f06b4dc795760ee5485ec5fbb1987afb8bb8e31430b")
