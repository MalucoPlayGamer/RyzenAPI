-- 3767740's Lua and Manifest Created by Hubcap Manifest
-- Outhold
-- Created: April 18, 2026 at 04:34:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3767740, 1, "0a7fc916f3b34078c17cbdff6101fb9f59fbf33a9a984e8b07a469a0aa9e9e36") -- Outhold
-- MAIN APP DEPOTS
addappid(3767741, 1, "97fbb25eacb8358b777d45b36c5a08a6cadb9260f44a15944a73764e84c01278") -- Depot 3767741
-- setManifestid(3767741, "1068501148644185741", 155028152)