-- Lua provided by RyzenAPI
-- Game: Grand Theft Auto: Episodes from Liberty City

-- MAIN APPLICATION
addappid(12220)

-- MAIN APP DEPOTS / PACKAGES
addappid(12221, 1, "81ddb2112e643bbd3b6ba2afb6cb5befc29e6af279417b1fe869a913e6fb2131")
addappid(12222, 1, "b5b5eda30f092696af90c38dececf04ce645b6c719190650068bddce5c49de1e")
addappid(12223, 1, "982592ab99db3254cf53eba6b7cc8fb969d6bb444701a5b69d9c4013980153e6")
addappid(12224, 1, "eafa2330ab55d5ac009bc764b5a743ca0f8b066908589f75687b2f72ba2d5466")

