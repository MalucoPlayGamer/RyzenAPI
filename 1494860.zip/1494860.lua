-- Lua provided by SkyAPI 
-- Game: AppID 1494860
addappid(1494860)
addappid(1494861, 1, "53f3c7b9f4f30d1d0a7584f91ed0b7da325b02dce64a2650fd75b26655bb6c4d")
