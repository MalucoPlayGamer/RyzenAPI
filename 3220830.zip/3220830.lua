-- Lua provided by RyzenAPI
-- Game: Game: Dusk Pub

-- MAIN APPLICATION
addappid(3220830)
-- Game: addappid(3220830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3220831, 1, "4ae6d5e9242175e1947542de81937b397e135f6feb6badc47785822b5a10cdf7")
