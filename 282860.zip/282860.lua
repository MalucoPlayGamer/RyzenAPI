-- Lua provided by RyzenAPI
-- Game: 282860

-- MAIN APPLICATION
addappid(282860)
-- Game: addappid(282860)

-- MAIN APP DEPOTS / PACKAGES
addappid(282861, 1, "f93ffcde2f0aeebc82cb2b2bfe12cb696f01654edf10cb04fabf9e2d5b0e9c15")
