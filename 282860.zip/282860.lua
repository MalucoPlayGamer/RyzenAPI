-- Lua provided by RyzenAPI
-- Game: AppID 282860

-- MAIN APPLICATION
addappid(282860)

-- MAIN APP DEPOTS / PACKAGES
addappid(282861, 1, "f93ffcde2f0aeebc82cb2b2bfe12cb696f01654edf10cb04fabf9e2d5b0e9c15")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
