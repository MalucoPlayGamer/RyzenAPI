-- Lua provided by RyzenAPI
-- Game: Game: Never Return

-- MAIN APPLICATION
addappid(1612620)
-- Game: addappid(1612620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1612621, 1, "f88bc2ad258b96b22010a76f48eea83573dae354875354083112a0c99cfb823a")
