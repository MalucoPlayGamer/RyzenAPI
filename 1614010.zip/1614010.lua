-- Lua provided by RyzenAPI
-- Game: FreeRunners

-- MAIN APPLICATION
addappid(1614010)
-- Game: addappid(1614010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614011, 1, "457164c296a8647c388301f060390f123ecb33df5a0908a9725d2ffb972b08d5")
