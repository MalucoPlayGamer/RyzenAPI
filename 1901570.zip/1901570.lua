-- Lua provided by RyzenAPI 
-- Game: AppID 1901570
addappid(1901570)
addappid(1901571, 1, "dc11c23686c8f80f2f14b4b7b53b66e9c6b6a56649c1daa25b68f12263cab9e3")
