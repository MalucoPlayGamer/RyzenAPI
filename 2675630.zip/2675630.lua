-- Lua provided by RyzenAPI
-- Game: 2675630

-- MAIN APPLICATION
addappid(2675630)
-- Game: addappid(2675630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675631, 1, "9e725d408133ce58e14d1dbe7d6dcb3d9e1e1402bebe54034cc419e0d288ffef")
