-- Lua provided by RyzenAPI
-- Game: addappid(1117900)

-- MAIN APPLICATION
addappid(1117900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117901, 1, "cd86205345148797df46cb0d47dbfa23182256e36a827b55f0605fec9262ded6")
