-- Lua provided by SkyAPI 
-- Game: Only Society: Arena
addappid(1831770)
addappid(1831771, 1, "2eeb0747f5da676571f3dd6a8793e8f1a8fabfca6ee9802c7aa7b475dbe11e2a")
