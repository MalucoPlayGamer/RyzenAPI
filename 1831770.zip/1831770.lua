-- Lua provided by RyzenAPI
-- Game: Only Society: Arena

-- MAIN APPLICATION
addappid(1831770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1831771, 1, "2eeb0747f5da676571f3dd6a8793e8f1a8fabfca6ee9802c7aa7b475dbe11e2a")

