-- Lua provided by RyzenAPI
-- Game: Mayan Prophecies: Ship of Spirits Collector's Edition

-- MAIN APPLICATION
addappid(568160)

-- MAIN APP DEPOTS / PACKAGES
addappid(568161,0,"b245df9cbe6662c636c09db9007e6cc40ef4d5433e44fedaf2a357f7af90484c")

