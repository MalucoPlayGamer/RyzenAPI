-- Lua provided by RyzenAPI
-- Game: 467930

-- MAIN APPLICATION
addappid(467930)
-- Game: addappid(467930)

-- MAIN APP DEPOTS / PACKAGES
addappid(467931, 1, "f8125d01a2ecd31461e72b0448b661c5da0f8c16fa97057eeba9966ca478d687")
