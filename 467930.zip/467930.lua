-- Lua provided by RyzenAPI
-- Game: SMASHING THE BATTLE

-- MAIN APPLICATION
addappid(467930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(467931, 1, "f8125d01a2ecd31461e72b0448b661c5da0f8c16fa97057eeba9966ca478d687")
