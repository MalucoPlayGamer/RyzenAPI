-- Lua provided by SkyAPI 
-- Game: AppID 467930
addappid(467930)
addappid(467931, 1, "f8125d01a2ecd31461e72b0448b661c5da0f8c16fa97057eeba9966ca478d687")
