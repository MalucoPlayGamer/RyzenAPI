-- Lua provided by RyzenAPI
-- Game: Game: Music Man

-- MAIN APPLICATION
addappid(2009560)
-- Game: addappid(2009560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009561, 1, "f0aa03fe951fd76eb99aae999d4be748a0c9ef2636f63ea1fa3d77fbe08c184c")
