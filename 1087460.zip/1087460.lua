-- Lua provided by RyzenAPI
-- Game: Super Life (RPG)

-- MAIN APPLICATION
addappid(1087460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1087462,0,"cb4f210c0d51944b1584d743fb8da350f0c27153c801351d54536473612b0c2c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
