-- Lua provided by RyzenAPI
-- Game: 2889780

-- MAIN APPLICATION
addappid(2889780)
-- Game: addappid(2889780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2889781, 1, "a63fd84b569451abb48a08cfdf860b2202c2191d61a8c99f34a2f9003189161d")
