-- Lua provided by RyzenAPI 
-- Game: SPELLHACK!!
addappid(2889780)
addappid(2889781, 1, "a63fd84b569451abb48a08cfdf860b2202c2191d61a8c99f34a2f9003189161d")
