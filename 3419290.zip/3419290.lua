-- Lua provided by RyzenAPI 
-- Game: GOD FORSAKEN
addappid(3419290)
addappid(3419291, 1, "51ce371d193ffdb376f1e8e2d6be2db852cc96609ff438ab8179316be25b9927")
addappid(3985080)
addappid(4340460)
