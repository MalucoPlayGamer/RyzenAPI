-- Lua provided by RyzenAPI
-- Game: Game: AppID 438820

-- MAIN APPLICATION
addappid(438820)
-- Game: addappid(438820)

-- MAIN APP DEPOTS / PACKAGES
addappid(438821, 1, "bef4bab852719dc5800f04e950f52dee94f72814e106756fdffc437f1894a7d5")
