-- Lua provided by RyzenAPI
-- Game: Super Rhythm Fit

-- MAIN APPLICATION
addappid(4279200) -- Super Rhythm Fit
-- addappid(4279202) -- Depot 4279202 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4279201, 1, "2f941d727beb4d4371ff7ff2a7153f099a485cea1ad6638297a4b829ab81cc4d") -- Depot 4279201

