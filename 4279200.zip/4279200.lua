-- 4279200's Lua and Manifest Created by Hubcap Manifest
-- Super Rhythm Fit
-- Created: August 15, 2026 at 03:08:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4279200) -- Super Rhythm Fit
-- MAIN APP DEPOTS
addappid(4279201, 1, "2f941d727beb4d4371ff7ff2a7153f099a485cea1ad6638297a4b829ab81cc4d") -- Depot 4279201
setManifestid(4279201, "4710276479522053701", 3577376607)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4279202) -- Depot 4279202 (empty depot)