-- Lua provided by SkyAPI 
-- Game: Nerd Survivors
addappid(2648990)
addappid(2648991, 1, "f7f2d9e981e6b2a55dcbd4dad2de4e6544fc3dbd915cda08123660847ebde572")
