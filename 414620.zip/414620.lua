-- Lua provided by RyzenAPI
-- Game: addappid(414620)

-- MAIN APPLICATION
addappid(414620)

-- MAIN APP DEPOTS / PACKAGES
addappid(414620,0,"58110be6090ff99de30a77c239377e57cddd84d99045227280c06e27bc3bd03e")
