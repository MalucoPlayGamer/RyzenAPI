-- Lua provided by RyzenAPI
-- Game: AppID 467300

-- MAIN APPLICATION
addappid(467300)
-- Game: addappid(467300)

-- MAIN APP DEPOTS / PACKAGES
addappid(467301, 1, "a5362ebb010126d49d81d4d7d381f31555103f3aaccdc29b3212fc8900f548c2")
addappid(467302, 1, "ffe5f6d0653e0acd3ca28bac409b039b674df88593a93a1a0e824357ef66021d")
