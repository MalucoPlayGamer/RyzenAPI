-- Lua provided by SkyAPI 
-- Game: AppID 1492380
addappid(1492380)
addappid(1492381, 1, "252d9194b36e898b97115962c932681072ea32cd182ec7c73cee2b35ff16b0a7")
