-- Lua provided by RyzenAPI
-- Game: Jumping Over It With Neko Girl

-- MAIN APPLICATION
addappid(1492380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492381, 1, "252d9194b36e898b97115962c932681072ea32cd182ec7c73cee2b35ff16b0a7")

