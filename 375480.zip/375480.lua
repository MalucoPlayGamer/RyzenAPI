-- Lua provided by RyzenAPI
-- Game: Chronicon

-- MAIN APPLICATION
addappid(375480)

-- MAIN APP DEPOTS / PACKAGES
addappid(375481, 1, "9b3ec65b4136ebdb9d7fcd81ac8f1df6bf938c65e42d704b0971d9ec93baf58a")
addappid(375482, 1, "6836e7d940b17e4d85ad32b6cb7ca44feaa969843e7565c6f6fc409a7422b352")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1599010)
addappid(2206120)
