-- Lua provided by RyzenAPI
-- Game: Game: Chronicon

-- MAIN APPLICATION
addappid(375480)
-- Game: addappid(375480)

-- MAIN APP DEPOTS / PACKAGES
addappid(375481, 1, "9b3ec65b4136ebdb9d7fcd81ac8f1df6bf938c65e42d704b0971d9ec93baf58a")
addappid(375482, 1, "6836e7d940b17e4d85ad32b6cb7ca44feaa969843e7565c6f6fc409a7422b352")
