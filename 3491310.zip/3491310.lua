-- Lua provided by SkyAPI 
-- Game: Chicken Invaders 1
addappid(3491310)
addappid(3491311, 1, "10bd84849db0843255d5133dc2960d66dbc2def87a15d3b5dd04516bde88ae1b")
addappid(3491312, 1, "8c33a1ae3ffe11e5d2a7ddeae82b9e14793ce1f4a72517cfcbcce38570ce2f8e")
addappid(3491313, 1, "bcb91aa03c08f367c1ae669ff7e1293bcb3809f424ad37143c2988ddf80eedd2")
addappid(3491314, 1, "04c685fcd7a8d5144cdfec482093d0c8262fa6d863bf232d9917b61a27d06542")
