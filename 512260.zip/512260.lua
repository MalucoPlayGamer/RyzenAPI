-- Lua provided by RyzenAPI 
-- Game: Avalon Legends Solitaire 2
addappid(512260)
addappid(512261, 1, "f2858ede4a16e13aa08c784a94b52b4cd99e04ba8c0481800c719aa9d6ba1f0b")
