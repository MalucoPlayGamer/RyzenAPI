-- Lua provided by RyzenAPI
-- Game: Furry Company

-- MAIN APPLICATION
addappid(3557690)
-- Game: addappid(3557690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3557691, 1, "111bb73de3097948966a9b321a87f45a985dadae0b232ba4b10daf62ac9d5e65")
