-- Lua provided by RyzenAPI
-- Game: RoboSkate

-- MAIN APPLICATION
addappid(1404530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404531, 1, "f2dd4d160c1fc9b3ec2fedd0cf428f47592809fe6eb046d39fb6f7537e4feb91")

