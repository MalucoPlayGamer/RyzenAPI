-- Lua provided by RyzenAPI
-- Game: Figurine Scene Simulator Demo

-- MAIN APPLICATION
addappid(1690910)
-- Game: addappid(1690910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690919,0,"7e666cdf3c70a14379ce74a25f296be28b103009ae4902af4caf00e63aa3df6d")
