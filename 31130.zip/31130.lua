-- Lua provided by RyzenAPI
-- Game: Game: AppID 31130

-- MAIN APPLICATION
addappid(31130)
-- Game: addappid(31130)

-- MAIN APP DEPOTS / PACKAGES
addappid(31131, 1, "44dc6bc2d4027adaf628df37c8a0403bad6b2ca0c2ac5c26526f1e7fe5155d98")
