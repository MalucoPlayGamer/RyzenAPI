-- Lua provided by SkyAPI 
-- Game: Hordes of Hunger Demo
addappid(3241800)
addappid(3241801, 1, "f67f16d23f6c92722bab2d57ba42b5d503f83219daeecc7d682e834d03196847")
