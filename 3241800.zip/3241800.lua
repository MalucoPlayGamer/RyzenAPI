-- Lua provided by RyzenAPI
-- Game: Hordes of Hunger Demo

-- MAIN APPLICATION
addappid(3241800)
-- Game: addappid(3241800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241801, 1, "f67f16d23f6c92722bab2d57ba42b5d503f83219daeecc7d682e834d03196847")
