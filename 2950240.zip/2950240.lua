-- Lua provided by RyzenAPI
-- Game: ネジ込みシミュレーター: あまねのドラマ01 -魔法少女は敗北しました-

-- MAIN APPLICATION
addappid(2950240)
-- Game: addappid(2950240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2950241, 1, "752dd30f53e39e02b177b333bb8ad4790023cd507315a5cb391a61d7b66ed0b8")
addappid(2950242, 1, "7f05a14371d2d82f9670eaa8fba2557b54c4ee36d1cda80a13e971f70a739150")
