-- Lua provided by RyzenAPI
-- Game: Ukrainian Soccer  ( any two points directed towards the net can score )

-- MAIN APPLICATION
addappid(1653510)
-- Game: addappid(1653510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653511, 1, "758f0b415a2ece5a92aecc99d68a3471f6fd4b820ff9e7849f720939f134dbbf")
