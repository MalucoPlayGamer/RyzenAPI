-- Lua provided by RyzenAPI
-- Game: Self Reliance 自我性赖

-- MAIN APPLICATION
addappid(229006)
addappid(1016110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016112,0,"ab03e5a01a1c3e956d2c11dfdf1218cfdc4a4738d954d664871af5ae7258439b")
addappid(1016113,0,"b84bd02db422e135fd3980da9b10e46e629795e17beb0f107313e71af433e440")
