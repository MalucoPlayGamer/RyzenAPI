-- Lua provided by RyzenAPI
-- Game: 3193940

-- MAIN APPLICATION
addappid(3193940)
-- Game: addappid(3193940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193941, 1, "a19a915327788c3b9e89a3ba0520eb5a75105e7975bada13aa024cb49918b382")
