-- Lua provided by RyzenAPI
-- Game: addappid(395470)

-- MAIN APPLICATION
addappid(395470)
addappid(395471)
addappid(395472)

-- MAIN APP DEPOTS / PACKAGES
addappid(631610,0,"870e281d2123030be597f28420091ad9f881cef9ec5cb7082bd5f01261c19327")
