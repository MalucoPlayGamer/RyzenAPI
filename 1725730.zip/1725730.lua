-- Lua provided by RyzenAPI
-- Game: addappid(1725730)

-- MAIN APPLICATION
addappid(1725730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725731, 1, "f902038a4ce238eaf1607cdc79a7490d7dc85a42208a6a1d1f764f0379cd78b7")
