-- Lua provided by RyzenAPI
-- Game: Game: Lust from Beyond

-- MAIN APPLICATION
addappid(1035120)
-- Game: addappid(1035120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035121, 1, "901b9b3b84b9b94a01a3007392b1835eb936320cd50f9dbac00cafac67be38ab")
addappid(1573380, 0, "56a3bf81c8eb9a016c3bad96529f67e18185725fe28a3a5bd2d34ef4b444888a")
