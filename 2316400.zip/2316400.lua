-- Lua provided by RyzenAPI
-- Game: Game: Hot Pussy College 2 🍓🔞

-- MAIN APPLICATION
addappid(2316400)
-- Game: addappid(2316400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316401, 1, "d1af630dcedcd9dae03531953e494009624158772382e8b49958ed8c95b917c6")
