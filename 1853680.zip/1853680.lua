-- Lua provided by RyzenAPI
-- Game: Forbidden Fruit

-- MAIN APPLICATION
addappid(1853680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853681, 1, "995897ac7280c78177dfc1eb1f4fd32efc036986c1a725d2c3bb3951e336b83c")

