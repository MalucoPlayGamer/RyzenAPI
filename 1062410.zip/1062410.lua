-- Lua provided by RyzenAPI
-- Game: AppID 1062410

-- MAIN APPLICATION
addappid(1062410)
-- Game: addappid(1062410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062411, 1, "8242bbc2b4375eeaeda0e97276f145c6520b750f6523a721b46a4ee8e571e068")
