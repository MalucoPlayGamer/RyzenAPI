-- Lua provided by RyzenAPI
-- Game: addappid(3569500)

-- MAIN APPLICATION
addappid(3569500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3569501, 1, "a4b2f02fea15a8275b5d46d70727d80a505dca76ebbda765687007c9be7065f3")
