-- Lua provided by RyzenAPI
-- Game: Game: Dale & Dawson Stationery Supplies

-- MAIN APPLICATION
addappid(2920570)
-- Game: addappid(2920570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920571, 1, "2936fe6bebf97616a1cbb0e4aa41393c5483773bec5053130418999c4126485e")
