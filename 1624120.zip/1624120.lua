-- Lua provided by RyzenAPI
-- Game: Football Manager 2022 Resource Archiver

-- MAIN APPLICATION
addappid(1624120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624121, 1, "0f7c6c7fb62d4f4e4e5b94861988464dc633bcb25b1e4484784c66bf71f41849")
addappid(1624122, 1, "37d40a20f20751d959901211b381c98e1cb46e18a157150612717a32c68bf8fd")

