-- Lua provided by RyzenAPI
-- Game: addappid(1633370)

-- MAIN APPLICATION
addappid(1633370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633371, 1, "a1cb9a467238e14f3daa8d67086275cdd70ba6c65edee62f78a5d18e29220dd5")
