-- Lua provided by RyzenAPI
-- Game: 758920

-- MAIN APPLICATION
addappid(758920)
-- Game: addappid(758920)

-- MAIN APP DEPOTS / PACKAGES
addappid(758921, 1, "798fb4d005d82f0042ed92218fb7ab8bfd67361972e39d257e00a64421d5a9bb")
