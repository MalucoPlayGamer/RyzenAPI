-- Lua provided by RyzenAPI
-- Game: Nexus Rumble: The Ultimate Showdown

-- MAIN APPLICATION
addappid(3027820)
