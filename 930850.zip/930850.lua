-- Lua provided by RyzenAPI
-- Game: addappid(930850)

-- MAIN APPLICATION
addappid(930850)

-- MAIN APP DEPOTS / PACKAGES
addappid(930851, 1, "fccce5b83ccf394b8ea44b3804e666cf76fc1efdd6e4b8ae2bb0b917710eebad")
