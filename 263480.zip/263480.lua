-- Lua provided by RyzenAPI
-- Game: AppID 263480

-- MAIN APPLICATION
addappid(263480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(263481, 1, "01849694dbb07e066bd43c0d6b4e2268a5518e50565139854f419b1503d5e9a9")
addappid(263498, 1, "6f977caa2ed4b39b7b38f4860dae884a1a58aa6ff80ffab7a309d78dd3b245ca")
addappid(313750, 0, "5cc21f677843e6f18a48ebd47c96af57d095b953c8f66e9d6de944c1063cb131")

