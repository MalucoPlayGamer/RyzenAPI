-- Lua provided by RyzenAPI
-- Game: addappid(1457150)

-- MAIN APPLICATION
addappid(1457150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457151, 1, "069cac4e3eac9dd65d498744ea7cf80f1c04357e4fbf05f3ac4ba3eb1bdb0cc0")
