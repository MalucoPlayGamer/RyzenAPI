-- Lua provided by RyzenAPI
-- Game: Leafling

-- MAIN APPLICATION
addappid(1457150)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1457151, 1, "069cac4e3eac9dd65d498744ea7cf80f1c04357e4fbf05f3ac4ba3eb1bdb0cc0")

