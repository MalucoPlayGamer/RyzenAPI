-- Lua provided by RyzenAPI
-- Game: addappid(413680)

-- MAIN APPLICATION
addappid(413680)

-- MAIN APP DEPOTS / PACKAGES
addappid(413681, 1, "e59eda648e32b3eb5ed31652c4fac34117c8916a4a19540440c78494cae7ea54")
