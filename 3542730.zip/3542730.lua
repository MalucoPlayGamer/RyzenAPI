-- Lua provided by RyzenAPI
-- Game: addappid(3542730)

-- MAIN APPLICATION
addappid(3542730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3542730,0,"2ec9177285c7ce702785ac004ecb38825a5bd33ffadc0f4da621aecf06cc362f")
