-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1485010)
-- Game: addappid(1485010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485012,0,"9dc3b7547e762aadbbbca2d1be37329a1ed2fb0de29fa8227f2684fd8466486e")
