-- Lua provided by RyzenAPI
-- Game: addappid(1485010)

-- MAIN APPLICATION
addappid(1485010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485012,0,"9dc3b7547e762aadbbbca2d1be37329a1ed2fb0de29fa8227f2684fd8466486e")
