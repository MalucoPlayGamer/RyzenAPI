-- Lua provided by RyzenAPI
-- Game: AppID 908790

-- MAIN APPLICATION
addappid(908790)

-- MAIN APP DEPOTS / PACKAGES
addappid(908791, 1, "8bd7090ce66c6ca883d54dc88abce0b1d4b636513d3c17b7ca76e94740bf9e6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
