-- Lua provided by RyzenAPI
-- Game: AppID 908790

-- MAIN APPLICATION
addappid(908790)

-- MAIN APP DEPOTS / PACKAGES
addappid(908791, 1, "8bd7090ce66c6ca883d54dc88abce0b1d4b636513d3c17b7ca76e94740bf9e6d")

