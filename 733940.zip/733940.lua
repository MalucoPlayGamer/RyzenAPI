-- Lua provided by RyzenAPI
-- Game: AppID 733940

-- MAIN APPLICATION
addappid(733940)

-- MAIN APP DEPOTS / PACKAGES
addappid(733941, 1, "c5cd25ca23e433cb8397166c46f5ff66a31c99c892fe4bbc10ab0e908d0a515c")

