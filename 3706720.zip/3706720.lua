-- Lua provided by RyzenAPI
-- Game: 建国同志爱加税TaxKing

-- MAIN APPLICATION
addappid(3706720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3706721, 1, "cc5b7bf1c81bd80701a2c9649e2b5a3a9485eb6945af4891f933b828cd7dbcba")

