-- Lua provided by RyzenAPI
-- Game: 建国同志爱加税TaxKing

-- MAIN APPLICATION
addappid(3706720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3706721, 1, "cc5b7bf1c81bd80701a2c9649e2b5a3a9485eb6945af4891f933b828cd7dbcba")

