-- Lua provided by RyzenAPI
-- Game: Little Farm

-- MAIN APPLICATION
addappid(15960)

-- MAIN APP DEPOTS / PACKAGES
addappid(15961, 1, "44e710ee66274558e38f9e3be26f0ea8317e26711ff52d5c58e5d8d837a016ee")

