-- Lua provided by RyzenAPI
-- Game: AppID 1222470

-- MAIN APPLICATION
addappid(1222470)
-- Game: addappid(1222470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222471, 1, "ce8498464949f59c44bb0ab2b07f9420448cc06b89802bcbe5309fa50f7b5ade")
