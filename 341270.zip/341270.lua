-- Lua provided by RyzenAPI
-- Game: Samphi

-- MAIN APPLICATION
addappid(341270)
addappid(341272)
addappid(341273)
-- Game: addappid(341270)

-- MAIN APP DEPOTS / PACKAGES
addappid(341274,0,"6e8751d02f9d90adf8c64b86113c53312123b140bed0ad82ede0a34648f70223")
