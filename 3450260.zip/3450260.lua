-- Lua provided by RyzenAPI
-- Game: 3450260

-- MAIN APPLICATION
addappid(3450260)
-- Game: addappid(3450260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3450261, 1, "1f0b93a94eefe04c54def3582b9aad3e8a3f5ad94ff59a8a23a58d9056bb07d9")
