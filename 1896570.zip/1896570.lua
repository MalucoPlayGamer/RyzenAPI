-- Lua provided by RyzenAPI
-- Game: Final Stardust: Cosmic Nexus

-- MAIN APPLICATION
addappid(1896570)
addappid(1896571)
-- Game: addappid(1896570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896572,0,"2bebb6ffffefd0971e3084de5c089656de3f63ac2f221a4aec927ddb55b0fb44")
