-- Lua provided by RyzenAPI
-- Game: The Four Kings Casino and Slots

-- MAIN APPLICATION
addappid(260430)

-- MAIN APP DEPOTS / PACKAGES
addappid(260431, 1, "b708a09ff33f2072e96e77b794150db30ae40fa4ccaf063c554ded9e189b08dd")
addappid(260432, 1, "df632e2bdacc3abf8cb3f42c87c865654c0ea46a9de1b9d195926f935a7606b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(324350)
addappid(324351)
addappid(324352)
