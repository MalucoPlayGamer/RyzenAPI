-- Lua provided by RyzenAPI
-- Game: Frontier Hunter: Soundtrack

-- MAIN APPLICATION
addappid(2175990)
-- Game: addappid(2175990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175991, 1, "52902fa28299b860f65faaee871878d3fd20b7b9eb088e67b4519592e59e0d04")
addappid(2175992, 1, "b4b2357b0c729980e28730a03f0ef73d51fb5d58383a4c22794e7b79d4ba8f83")
