-- Lua provided by RyzenAPI
-- Game: Game: FLIGHTMARE

-- MAIN APPLICATION
addappid(2569570)
-- Game: addappid(2569570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569571, 1, "227555cbc39a0887d466852e2d844ff426f364c9a11cb36e08da7a7addc3cc3a")
