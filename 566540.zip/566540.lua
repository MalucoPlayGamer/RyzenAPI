-- Lua provided by RyzenAPI
-- Game: Labyrinth of Refrain: Coven of Dusk

-- MAIN APPLICATION
addappid(566540) -- Labyrinth of Refrain: Coven of Dusk
addappid(889610) -- Labyrinth of Refrain Coven of Dusk - Meels Best Bell
addappid(889611) -- Labyrinth of Refrain Coven of Dusk - Meels Best Shield
addappid(889612) -- Labyrinth of Refrain Coven of Dusk - Meels Manania Pact
addappid(889613) -- Labyrinth of Refrain Coven of Dusk - Meels Best Earring
addappid(889614) -- Labyrinth of Refrain Coven of Dusk - Meels Strategy Guide Pact
addappid(889620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(566541, 1, "be741c70c261c5fb804d69d043686bd8cd033e868d664b86d93c04e9e97e8414") -- Labyrinth of Refrain: Coven of Dusk Content
addappid(889620, 1, "63272b8a344145e2b5fd73b44a68bac0ff845e6f1dfe3a5297f87f93c666f05d") -- Labyrinth of Refrain Coven of Dusk - Digital Art Book - Labyrinth of Refrain: Coven of Dusk - Digital Art Book (889620) デポ

