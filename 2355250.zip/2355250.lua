-- Lua provided by RyzenAPI
-- Game: Idle Biceps

-- MAIN APPLICATION
addappid(2355250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355251, 1, "3954b53a664d4ea3122fa384dcd6fe58e80a6e4f001612f35047778d170b29b1")

