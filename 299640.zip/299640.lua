-- Lua provided by RyzenAPI
-- Game: AppID 299640

-- MAIN APPLICATION
addappid(299640)

-- MAIN APP DEPOTS / PACKAGES
addappid(299641, 1, "51090ba43031fad8f8b9fef061aad6ba7d9d349415f262575c01e0572983dd07")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
