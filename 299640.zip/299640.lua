-- Lua provided by RyzenAPI
-- Game: 299640

-- MAIN APPLICATION
addappid(299640)
-- Game: addappid(299640)

-- MAIN APP DEPOTS / PACKAGES
addappid(299641, 1, "51090ba43031fad8f8b9fef061aad6ba7d9d349415f262575c01e0572983dd07")
