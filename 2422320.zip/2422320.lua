-- Lua provided by RyzenAPI
-- Game: 2422320

-- MAIN APPLICATION
addappid(2422320)
-- Game: addappid(2422320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422321, 1, "c417de98bbd06774f2d342f3a6a12d44c034a29dd60ee7772052ec6532091d46")
