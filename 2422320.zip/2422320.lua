-- Lua provided by SkyAPI 
-- Game: AppID 2422320
addappid(2422320)
addappid(2422321, 1, "c417de98bbd06774f2d342f3a6a12d44c034a29dd60ee7772052ec6532091d46")
