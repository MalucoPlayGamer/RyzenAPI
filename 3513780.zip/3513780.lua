-- Lua provided by RyzenAPI
-- Game: Game: ADVANCED V.G. Saturn Tribute Yumeiro Tsushin Extra issue ver.VG

-- MAIN APPLICATION
addappid(3513780)
-- Game: addappid(3513780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3513781, 1, "3aa595feac15ab9e7b4b09a69f4eeb426298f50e3c31365c8ef9fab9e12ed0a3")
