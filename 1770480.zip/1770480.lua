-- Lua provided by RyzenAPI
-- Game: VTOL VR: AH-94 Attack Helicopter

-- MAIN APPLICATION
addappid(1770480)
-- Game: addappid(1770480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770481, 1, "da89b7918a466dc116fa3dc2ec780134e8829781ae3a8282aa0532994d34a068")
