-- Lua provided by RyzenAPI
-- Game: 622320

-- MAIN APPLICATION
addappid(622320)
-- Game: addappid(622320)

-- MAIN APP DEPOTS / PACKAGES
addappid(622321, 1, "127b24e410cd99bb9fa91a1202ccf1e89e339b16b92d0c234ae87fd265fcbb43")
