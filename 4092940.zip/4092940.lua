-- 4092940's Lua and Manifest Created by Hubcap Manifest
-- Lucky Shot
-- Created: August 09, 2026 at 14:54:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4092940) -- Lucky Shot
addtoken(4092940, "383805694026437809")
-- MAIN APP DEPOTS
addappid(4092941, 1, "a770f2a968b986800900f52a072015601cd0e47c7f83cd1f096a9e0d71df5d88") -- Depot 4092941
setManifestid(4092941, "1454758959799965574", 1807263836)
addappid(4092942, 1, "c13db13247d576e63976823dddc79c030cf826f1fa02dc84bc4d5040ea500fcd") -- Depot 4092942
setManifestid(4092942, "5625764862381053011", 1824054449)