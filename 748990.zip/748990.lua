-- Lua provided by RyzenAPI 
-- Game: The Z Axis: Continuum
addappid(748990)
addappid(748991, 1, "0ebb926a800fb7f957c2585cf43eff4c8eeb9de6cb3d064dcd6c77dd8a0c583a")
