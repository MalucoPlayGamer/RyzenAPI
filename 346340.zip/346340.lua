-- Lua provided by RyzenAPI
-- Game: Gran Vitreous

-- MAIN APPLICATION
addappid(346340)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(346341, 1, "ea6c51ab452e962704fa5d113e99432674298470c1ca1ae12a7531b5084218a4")

