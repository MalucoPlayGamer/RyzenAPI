-- Lua provided by RyzenAPI
-- Game: Gran Vitreous

-- MAIN APPLICATION
addappid(346340)
-- Game: addappid(346340)

-- MAIN APP DEPOTS / PACKAGES
addappid(346341, 1, "ea6c51ab452e962704fa5d113e99432674298470c1ca1ae12a7531b5084218a4")
