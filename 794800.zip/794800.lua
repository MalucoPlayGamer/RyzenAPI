-- Lua provided by SkyAPI 
-- Game: Clue/Cluedo: Classic Edition
addappid(794800)
addappid(794801, 1, "7bbde98210e28ce6c0bfe67ee880ffb07b7e1c687b2d379ab52d88b21430912d")
addappid(850260)
