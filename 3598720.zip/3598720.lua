-- Lua provided by RyzenAPI
-- Game: Bling Bling Bankruptcy

-- MAIN APPLICATION
addappid(3598720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3598721, 1, "de683b8d91dfda0b3ad5d1fbae54271d7b24f8f417777f8f374108cc5b6767ad")
