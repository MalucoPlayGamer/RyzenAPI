-- Lua provided by RyzenAPI
-- Game: 974840

-- MAIN APPLICATION
addappid(974840)
-- Game: addappid(974840)

-- MAIN APP DEPOTS / PACKAGES
addappid(974841, 1, "17efee4101a520d92c2ce14202b68fec9dc6dd994d5c01afb4bf50a6b1adedf3")
