-- Lua provided by RyzenAPI 
-- Game: AppID 974840
addappid(974840)
addappid(974841, 1, "17efee4101a520d92c2ce14202b68fec9dc6dd994d5c01afb4bf50a6b1adedf3")
