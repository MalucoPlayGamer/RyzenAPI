-- Lua provided by RyzenAPI
-- Game: Game: ASSASSINATION STATION

-- MAIN APPLICATION
addappid(683430)
-- Game: addappid(683430)

-- MAIN APP DEPOTS / PACKAGES
addappid(683431, 1, "2a81bcf3d9d25ea62171f8852b29ced61a26cbc4c8827a49ffd655f8926806e8")
