-- Lua provided by RyzenAPI 
-- Game: 全球戒备
addappid(2361390)
addappid(2361391, 1, "5d98ed78c0df5b8d396c513d90039cdcc4ce120a1509353f1b84c2446c2f27b0")
