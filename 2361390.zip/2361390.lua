-- Lua provided by RyzenAPI
-- Game: 全球戒备

-- MAIN APPLICATION
addappid(2361390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361391, 1, "5d98ed78c0df5b8d396c513d90039cdcc4ce120a1509353f1b84c2446c2f27b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
