-- Lua provided by RyzenAPI
-- Game: addappid(202130)

-- MAIN APPLICATION
addappid(202130)

-- MAIN APP DEPOTS / PACKAGES
addappid(202131, 1, "98a1b0399bcd8e95c3cfabcc3d31673bfa9a54fd32971d4e2bc095e5c1232a60")
