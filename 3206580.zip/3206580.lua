-- Lua provided by RyzenAPI
-- Game: Remorse

-- MAIN APPLICATION
addappid(3206580)
-- Game: addappid(3206580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206581, 1, "908af857835e320228054a11b2517f23c3a56406243c9f78fd0b212e11fe7804")
