-- 4601160's Lua and Manifest Created by Hubcap Manifest
-- Just Keep Fishing
-- Created: August 27, 2026 at 13:04:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4601160) -- Just Keep Fishing
-- MAIN APP DEPOTS
addappid(4601161, 1, "44f198bceb4ecca2bfbefd98d3fb8363c7c32025f15dfa888b3ec64a5f4763c4") -- Depot 4601161
setManifestid(4601161, "4857062438947243822", 354851478)
addappid(4601162, 1, "bf2bc420a51bb47edcdec15522d07b31d08ccb50e7deffaecb834c9d59fb7620") -- Depot 4601162
setManifestid(4601162, "7939719777323305049", 382012910)
addappid(4601163, 1, "9e7cd19b558f48b13a85e93b0ad081843c0de012de4879c2671fa35fc9c59e01") -- Depot 4601163
setManifestid(4601163, "5944062694538517089", 433676866)