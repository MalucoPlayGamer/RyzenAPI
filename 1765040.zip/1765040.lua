-- Lua provided by RyzenAPI
-- Game: Seditionis Crutarch Royale

-- MAIN APPLICATION
addappid(1765040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1765041, 1, "8ab30150f263c8798dcdfd33be37f0de6ead4051f58f5f94dd3154e3e77cfa22")

