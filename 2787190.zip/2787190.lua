-- Lua provided by RyzenAPI
-- Game: Morbid: The Lords of Ire Soundtrack

-- MAIN APPLICATION
addappid(2787190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2787191, 1, "e5f34580744fda5d16fc997b7e95178d4617886c332537155d3b2c6a6c86d702")
addappid(2787192, 1, "6fbbb1961f6b2a403fe3495ce0d13dcc33cb8d5ddfae9d9c1b2be785dd980618")
