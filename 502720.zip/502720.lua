-- Lua provided by RyzenAPI
-- Game: Star Explorers

-- MAIN APPLICATION
addappid(502720)

-- MAIN APP DEPOTS / PACKAGES
addappid(502721, 1, "a3ac8237438159bbc91b1e8e0a82bf9105b57fbeabc6dd32d260b4a2058e5efa")
