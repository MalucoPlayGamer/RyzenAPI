-- Lua provided by RyzenAPI 
-- Game: AppID 502720
addappid(502720)
addappid(502721, 1, "a3ac8237438159bbc91b1e8e0a82bf9105b57fbeabc6dd32d260b4a2058e5efa")
