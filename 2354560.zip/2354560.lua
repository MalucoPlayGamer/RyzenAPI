-- Lua provided by SkyAPI 
-- Game: ClickeRogue
addappid(2354560)
addappid(2354561, 1, "e1b4a28e7620d13170678652b4e61a52af28f2e758b663e47d0f712e14c14ddb")
