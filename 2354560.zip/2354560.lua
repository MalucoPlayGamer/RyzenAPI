-- Lua provided by RyzenAPI
-- Game: Game: ClickeRogue

-- MAIN APPLICATION
addappid(2354560)
-- Game: addappid(2354560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354561, 1, "e1b4a28e7620d13170678652b4e61a52af28f2e758b663e47d0f712e14c14ddb")
