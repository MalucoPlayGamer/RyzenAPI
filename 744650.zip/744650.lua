-- Lua provided by RyzenAPI
-- Game: Order Of The Gatekeepers

-- MAIN APPLICATION
addappid(744650)

-- MAIN APP DEPOTS / PACKAGES
addappid(744651,0,"c4903df854caa49ef92951ad9b375f096acccaaf5106f77978f5ff74359d16bf")

