-- Lua provided by RyzenAPI
-- Game: addappid(1223020)

-- MAIN APPLICATION
addappid(1223020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223021, 1, "7f3c3ce7002c1a17c533b22c9ccf488a4d04725ad9d310b780792ff38c10edb6")
