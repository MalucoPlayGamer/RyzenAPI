-- Lua provided by RyzenAPI
-- Game: Cute Waifu

-- MAIN APPLICATION
addappid(1808260)
addappid(4863190)
addappid(4863200)
addappid(4863210)
addappid(4863220)
addappid(4863240)
addappid(4863250)
addappid(4863260)
addappid(4863270)
addappid(4863280)
addappid(4863290)
addappid(4863320)
addappid(4863330)
addappid(4863350)
addappid(4863360)
addappid(4863370)
addappid(4863380)
addappid(4863390)
addappid(4863400)
addappid(4863410)
addappid(4863420)
addappid(4863440)
addappid(4863450)
addappid(4863460)
addappid(4863470)
addappid(4863480)
addappid(4863490)
addappid(4863500)
addappid(4863510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808261, 1, "907ad25b0b9160b0db45e1a4f8d51e273a99bc6b186de0f97405f0b7a491933c")

