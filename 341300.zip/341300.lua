-- Lua provided by RyzenAPI
-- Game: Game: Modern Combat

-- MAIN APPLICATION
addappid(341300)
-- Game: addappid(341300)

-- MAIN APP DEPOTS / PACKAGES
addappid(341301, 1, "0d471503e6d3249ea1923640e7ed527210a53327e31e7fb6bbd538efaa0ae2d9")
