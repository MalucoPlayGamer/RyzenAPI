-- Lua provided by RyzenAPI
-- Game: Game: AppID 971400

-- MAIN APPLICATION
addappid(971400)
-- Game: addappid(971400)

-- MAIN APP DEPOTS / PACKAGES
addappid(971401, 1, "b7ea36c2f2866b1190b42b0d9757cbb59dc1c876cb344d0e7f3b92922be4ba01")
