-- Lua provided by RyzenAPI 
-- Game: Club Soccer Director 2022
addappid(1698080)
addappid(1698081, 1, "55ac2cd19be5e72ab99342fa0f9fb6eabaea87815eb28726577569819ace412e")
