-- Lua provided by RyzenAPI
-- Game: Game: Club Soccer Director 2022

-- MAIN APPLICATION
addappid(1698080)
-- Game: addappid(1698080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1698081, 1, "55ac2cd19be5e72ab99342fa0f9fb6eabaea87815eb28726577569819ace412e")
