-- Lua provided by SkyAPI 
-- Game: Per Aspera
addappid(803050)
addappid(803051, 1, "9cc56df6c0ed8ed20759eae18a6a268eeb4fb20cfd38b309b45db6855f92dc5b")
