-- Lua provided by RyzenAPI
-- Game: Per Aspera

-- MAIN APPLICATION
addappid(803050)
addappid(1479440)
addappid(1688480)
addappid(1726200)
addappid(1966430)
addappid(2287380)

-- MAIN APP DEPOTS / PACKAGES
addappid(803050,0,"0687939283d2742b67154007345d616351db3a7019ca6d17ac3e9e6f312bccd9")
addappid(803051,0,"9cc56df6c0ed8ed20759eae18a6a268eeb4fb20cfd38b309b45db6855f92dc5b")
addappid(1479441,0,"ced94ce2d9f4756d805f95f0795dd4f8e490eab626f6ea16a56624ca52b6075b")

