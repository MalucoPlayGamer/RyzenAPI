-- Lua provided by RyzenAPI
-- Game: addappid(803050)

-- MAIN APPLICATION
addappid(803050)

-- MAIN APP DEPOTS / PACKAGES
addappid(803051, 1, "9cc56df6c0ed8ed20759eae18a6a268eeb4fb20cfd38b309b45db6855f92dc5b")
