-- Lua provided by RyzenAPI
-- Game: ADVANCED V.G. Saturn Tribute Sound Tracks

-- MAIN APPLICATION
addappid(3513770)
-- Game: addappid(3513770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3513771, 1, "30fb0a731a0a516e0cfd5e6521af517eee26689ce7201f3da3f7017513e18e0f")
addappid(3513772, 1, "0033fa24a32b834fec7175be302ed79cc3d49a8704aac0f007b5a4b66b9849b4")
