-- Lua provided by RyzenAPI
-- Game: addappid(1230230)

-- MAIN APPLICATION
addappid(1230230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230230,0,"d293a4ee3b76eecea9a324b1ab6b7e723bbc116560c7d885832db912177b6d09")
