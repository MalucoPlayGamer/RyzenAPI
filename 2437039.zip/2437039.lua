-- Lua provided by RyzenAPI
-- Game: 2437039

-- MAIN APPLICATION
addappid(2437039)
-- Game: addappid(2437039)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437039,0,"92804ec8c718b649d9036f2bd6e9584cd20daebda824682df920c21b9230c189")
