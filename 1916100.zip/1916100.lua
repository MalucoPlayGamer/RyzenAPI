-- Lua provided by RyzenAPI 
-- Game: Day of the Dino
addappid(1916100)
addappid(1916101, 1, "ef81a4e0df8a79e7160913aedf4f7b46524648a5e60796a9f29ebe7d5827dfde")
