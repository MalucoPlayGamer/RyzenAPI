-- Lua provided by SkyAPI 
-- Game: AppID 791500
addappid(791500)
addappid(791501, 1, "70a8d2d872433fc5f7a6600b14b65a05fa885f73eae3d09eb6f142f814c9e573")
