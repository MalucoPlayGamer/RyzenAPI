-- Lua provided by RyzenAPI
-- Game: 791500

-- MAIN APPLICATION
addappid(791500)
-- Game: addappid(791500)

-- MAIN APP DEPOTS / PACKAGES
addappid(791501, 1, "70a8d2d872433fc5f7a6600b14b65a05fa885f73eae3d09eb6f142f814c9e573")
