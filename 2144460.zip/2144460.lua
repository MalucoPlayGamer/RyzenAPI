-- Lua provided by RyzenAPI
-- Game: Game: Path to purge

-- MAIN APPLICATION
addappid(2144460)
-- Game: addappid(2144460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144461, 1, "b76b3af256063129fb75f81b091292f04eff369ef88db1c9871d3f283bb49e7f")
