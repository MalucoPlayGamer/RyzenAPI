-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2122141)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122141,0,"0b4fe1b4cc92dd720a2bf2f38a1570be40dbcde8c3b233fc26db19dfd021e7dc")
