-- Lua provided by RyzenAPI
-- Game: Game: AppID 1882000

-- MAIN APPLICATION
addappid(1882000)
-- Game: addappid(1882000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882001, 1, "61ad6589a499cc8013052ec4fc23640825cdd293986be6601f85d840290acc94")
