-- Lua provided by RyzenAPI
-- Game: addappid(1409690)

-- MAIN APPLICATION
addappid(1409690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1409691, 1, "2dc3f3d2878d43ed96f7b596e7bb50e28188a58eaac842867fff000cc2ea2182")
