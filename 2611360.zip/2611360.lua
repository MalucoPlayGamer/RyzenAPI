-- Lua provided by RyzenAPI
-- Game: 2611360

-- MAIN APPLICATION
addappid(2611360)
-- Game: addappid(2611360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2611361, 1, "2fea51a216ed9b6e3ee6c25527da1336c2604a9f6caa2ec5dc8db9d17ac9d177")
