-- Lua provided by RyzenAPI
-- Game: My Ex-Boyfriend the Space Tyrant

-- MAIN APPLICATION
addappid(312970)

-- MAIN APP DEPOTS / PACKAGES
addappid(312971, 1, "2698ba0958297cc903f4f341b29af67b907810576011f052bb76cd9551bfd0f5")
addappid(312972, 1, "44c7139293903e930cd934e3e0894aa73795f119ad3ed4ad22b7f3d97f37045a")
