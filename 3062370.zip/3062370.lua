-- Lua provided by RyzenAPI
-- Game: 3062370

-- MAIN APPLICATION
addappid(3062370)
-- Game: addappid(3062370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3062371, 1, "29e3f3e7f71e9a86951bb29b547f955df37c6e88370119ae94780b466bcb867f")
