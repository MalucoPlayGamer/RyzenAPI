-- Lua provided by RyzenAPI
-- Game: Frincess&amp;Cnight Demo

-- MAIN APPLICATION
addappid(1686360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686361, 1, "7898d33d6a28516a61e581761eaaee185368436603ef321da7101db3f3e077d0")

