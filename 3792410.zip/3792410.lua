-- Lua provided by RyzenAPI
-- Game: Game: Legend of Mana Remastered: The Soundtrack

-- MAIN APPLICATION
addappid(3792410)
-- Game: addappid(3792410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3792411, 1, "4c9f83d54fd646d39677b08978030301f7bc5dd4df9402b63d2944509a733a42")
