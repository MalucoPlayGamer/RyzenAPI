-- Lua provided by RyzenAPI
-- Game: Operation Covid-19

-- MAIN APPLICATION
addappid(1316570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316571, 1, "bb18d8f1e32752f400129ee839cf9f9f29d86b467f774087888db414036442ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
