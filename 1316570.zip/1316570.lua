-- Lua provided by SkyAPI 
-- Game: Operation Covid-19
addappid(1316570)
addappid(1316571, 1, "bb18d8f1e32752f400129ee839cf9f9f29d86b467f774087888db414036442ec")
