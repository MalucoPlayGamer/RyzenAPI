-- Lua provided by RyzenAPI 
-- Game: AppID 3444800
addappid(3444800)
addappid(3444801, 1, "86f3c1a5ee32c5e9255fe23fe767ba19429842c856b75a41504e422d87f85e03")
