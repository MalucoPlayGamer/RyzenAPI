-- Lua provided by RyzenAPI
-- Game: Fish Game

-- MAIN APPLICATION
addappid(1372150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372151, 1, "efb8b3757e6c420a126256c4a626da290ffc10e1e96099b695be927020130fb6")
