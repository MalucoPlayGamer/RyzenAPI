-- Lua provided by RyzenAPI
-- Game: Fish Game

-- MAIN APPLICATION
addappid(1372150)
addappid(3213040)
addappid(3459300)
addappid(3537170)
addappid(3537180)
addappid(3794510)
addappid(3925080)
addappid(4941890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1372151, 1, "efb8b3757e6c420a126256c4a626da290ffc10e1e96099b695be927020130fb6")

