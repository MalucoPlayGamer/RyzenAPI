-- Lua provided by RyzenAPI
-- Game: Puzzle Pelago - A Drag & Drop Economy

-- MAIN APPLICATION
addappid(1064540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064542,0,"0cfdd7d5ccd3ed349eb1e85368cacf3d900e0fc733a3ab2fbf0760f3605d5f51")

