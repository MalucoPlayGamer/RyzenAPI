-- Lua provided by RyzenAPI
-- Game: Game: Magic Archery

-- MAIN APPLICATION
addappid(2905170)
-- Game: addappid(2905170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2905171, 1, "6d2543dca3b35760b3b08470f560ca57f9d7dd03c552ef2b6651ab4abd9c3d96")
