-- Lua provided by RyzenAPI
-- Game: Infinity Kingdom

-- MAIN APPLICATION
addappid(1573360)

