-- 3065180's Lua and Manifest Created by Hubcap Manifest
-- Dolls: The Hunt
-- Created: July 27, 2026 at 16:40:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3065180, 1, "887ee6deb098eb24e23032b4f4009eae21a573e3a5a190bb41c2282e27001ad8") -- Dolls: The Hunt
-- MAIN APP DEPOTS
addappid(3065181, 1, "d33e7c488705598ea3f69e93d1586cf681a8636544dd2890804fcc73fcb2952f") -- Depot 3065181
setManifestid(3065181, "5425316680397871146", 4177882560)