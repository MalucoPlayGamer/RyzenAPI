-- Lua provided by RyzenAPI
-- Game: Take Me To The Dungeon!! - Family Friendly Demo

-- MAIN APPLICATION
addappid(2571090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571091, 1, "2e5c44e7cca0ecbea66ad6d708ec4424e2552b47c2d2596620291fa867ba3aa8")
