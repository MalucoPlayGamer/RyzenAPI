-- Lua provided by RyzenAPI
-- Game: Super Hydorah

-- MAIN APPLICATION
addappid(628800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(628801, 1, "a6efddcbc18ae462fa543e95d0b3683d3100728a610612ac4555dbcf61311f7f")

