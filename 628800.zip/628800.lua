-- Lua provided by RyzenAPI
-- Game: Super Hydorah

-- MAIN APPLICATION
addappid(628800)

-- MAIN APP DEPOTS / PACKAGES
addappid(628801, 1, "a6efddcbc18ae462fa543e95d0b3683d3100728a610612ac4555dbcf61311f7f")

