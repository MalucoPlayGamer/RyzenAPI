-- 4855560's Lua and Manifest Created by Hubcap Manifest
-- Kingdom Chronicle
-- Created: July 22, 2026 at 23:42:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4855560) -- Kingdom Chronicle
-- MAIN APP DEPOTS
addappid(4855561, 1, "a7f3cbe187d4f8c3311e0a1cd4cd44e2050783ebdca54d57559d799b8bb908a2") -- Depot 4855561
setManifestid(4855561, "4711849575830677447", 889752617)