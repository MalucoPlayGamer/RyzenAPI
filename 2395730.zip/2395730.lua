-- Lua provided by RyzenAPI
-- Game: Spiral Up

-- MAIN APPLICATION
addappid(2395730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395731, 1, "71baca7cf1f086031a4a1ce49ac785f2d8bd51391d265e6f202b6da9e8c2032b")

