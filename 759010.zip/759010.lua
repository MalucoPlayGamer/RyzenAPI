-- Lua provided by RyzenAPI
-- Game: AppID 759010

-- MAIN APPLICATION
addappid(759010)
-- Game: addappid(759010)

-- MAIN APP DEPOTS / PACKAGES
addappid(759011, 1, "8e0f267c1051ffc695f15acd8af05a2c02b769908cd33bac078f8d553e6747c2")
addappid(759012, 1, "e8d218b1a587c384f0d11e537b62dd07b3a19eecc9ca0535e24cffe792aacaf5")
