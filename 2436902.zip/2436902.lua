-- Lua provided by RyzenAPI
-- Game: 2436902

-- MAIN APPLICATION
addappid(2436902)
-- Game: addappid(2436902)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436902,0,"3a31bdaeaf3255a5586311dbf1bf694ed2757f556192fdd33d697bafdf495411")
