-- Lua provided by RyzenAPI
-- Game: it's always monday

-- MAIN APPLICATION
addappid(558660)

-- MAIN APP DEPOTS / PACKAGES
addappid(558661, 1, "7945f43bd4c959d22f98ad8192150910f71faf7886e3e12cac5a347da0fe52d2")

