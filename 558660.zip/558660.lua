-- Lua provided by SkyAPI 
-- Game: AppID 558660
addappid(558660)
addappid(558661, 1, "7945f43bd4c959d22f98ad8192150910f71faf7886e3e12cac5a347da0fe52d2")
