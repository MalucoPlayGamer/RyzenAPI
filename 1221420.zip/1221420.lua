-- Lua provided by RyzenAPI
-- Game: 零怨 The curse of the dead

-- MAIN APPLICATION
addappid(1221420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221421, 1, "84970c6ed42465d0c363e1b798d80102cd0ccb61d7ca7ea647716a9e92937bdf")

