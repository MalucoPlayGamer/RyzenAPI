-- Lua provided by RyzenAPI
-- Game: Game: Hunter Survivors

-- MAIN APPLICATION
addappid(2010700)
-- Game: addappid(2010700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010701, 1, "ebb2c097c00e3c3d7262279b319aeadddff71140e8a0829a28d3dff079bff32f")
