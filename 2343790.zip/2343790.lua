-- Lua provided by RyzenAPI
-- Game: A Little to the Left: Cupboards & Drawers

-- MAIN APPLICATION
addappid(2343790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343791, 1, "bca36b3144693458d85d458757a3b8ca728a9424fe307fd360cd81fa98efa882")
addappid(2343792, 1, "25252034054079c81f78613eb721fe19652a6a90e7dbccc71b6f155fdc717355")

