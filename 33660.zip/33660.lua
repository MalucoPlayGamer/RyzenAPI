-- Lua provided by RyzenAPI
-- Game: Ziro

-- MAIN APPLICATION
addappid(33660)

-- MAIN APP DEPOTS / PACKAGES
addappid(33661, 1, "f8b538ab6203cdaaf2920210219f9d75e0db166930a22757bd749ab7dde8a35f")

