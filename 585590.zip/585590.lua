-- Lua provided by RyzenAPI
-- Game: Emperor Kingdom

-- MAIN APPLICATION
addappid(585590)

-- MAIN APP DEPOTS / PACKAGES
addappid(585591, 1, "cb88d6cff269e329934940f329853e77d139b6b2cc7190d9a6417003d99962a2")
