-- Lua provided by RyzenAPI 
-- Game: AppID 1895730
addappid(1895730)
addappid(1895731, 1, "54ea93b6ef99a42f985ee14a5e6541462066cb0f7c077c1a12a8048a00d953b9")
