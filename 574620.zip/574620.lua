-- Lua provided by RyzenAPI
-- Game: Game: AppID 574620

-- MAIN APPLICATION
addappid(574620)
-- Game: addappid(574620)

-- MAIN APP DEPOTS / PACKAGES
addappid(574621, 1, "1de46565a0e7d220be53dd04ba39e038f4aef8315535f537c97bf61f090af4f2")
