-- Lua provided by RyzenAPI 
-- Game: AppID 2230610
addappid(2230610)
addappid(2230611, 1, "65dd583dd491446b4d9785313be37130850097723836f29cb019a0213b660e39")
