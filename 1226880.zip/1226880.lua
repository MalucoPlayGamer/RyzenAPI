-- Lua provided by RyzenAPI
-- Game: AppID 1226880

-- MAIN APPLICATION
addappid(1226880)
-- Game: addappid(1226880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226881, 1, "9a9c0ee11b9fef072204377afb0f97e8b18be78d35b5c4aa1f7f4b8f4b583148")
