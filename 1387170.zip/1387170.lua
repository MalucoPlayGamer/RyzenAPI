-- Lua provided by RyzenAPI
-- Game: Similo: The Card Game

-- MAIN APPLICATION
addappid(1387170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387171, 1, "d696c07d7ccb386913456415276e448dc1327349229714560ceb56c47bcd41b3")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1394230)
addappid(1394231)
addappid(1394232)
addappid(1400550)
addappid(1400551)
