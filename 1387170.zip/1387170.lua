-- Lua provided by RyzenAPI
-- Game: Similo: The Card Game

-- MAIN APPLICATION
addappid(1387170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387171, 1, "d696c07d7ccb386913456415276e448dc1327349229714560ceb56c47bcd41b3")
