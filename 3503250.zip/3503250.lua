-- Lua provided by RyzenAPI
-- Game: 信标2010

-- MAIN APPLICATION
addappid(3503250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3503251, 1, "3b3c740e7bff0c7f9f2794cd52e63deec60421e04cee60636b94f30f601a811b")

