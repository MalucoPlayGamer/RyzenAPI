-- Lua provided by RyzenAPI
-- Game: addappid(1417020)

-- MAIN APPLICATION
addappid(1417020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417022,0,"85aacc49ce3f9c9b1c1090c729b7a150fe79c2fe928aa14e0c3b7048c754477c")
