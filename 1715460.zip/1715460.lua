-- Lua provided by RyzenAPI
-- Game: Touhou Hero of Ice Fairy: Prologue

-- MAIN APPLICATION
addappid(1715460)

