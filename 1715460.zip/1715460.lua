-- Lua provided by RyzenAPI
-- Game: Touhou Hero of Ice Fairy: Prologue

-- MAIN APPLICATION
addappid(1715460)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1852710)
