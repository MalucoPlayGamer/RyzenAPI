-- Lua provided by RyzenAPI
-- Game: Heroes Of The Dark

-- MAIN APPLICATION
addappid(1851330)
-- Game: addappid(1851330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851331, 1, "4113a795bcf30daf3267131fbeebc8e2ee44ada87525af1f2f90ae04c9ccb89b")
