-- Lua provided by RyzenAPI
-- Game: Treasures of the Ancients: Egypt

-- MAIN APPLICATION
addappid(866150)

-- MAIN APP DEPOTS / PACKAGES
addappid(866151, 1, "5641642b7936828de3a98b0d7ac1d09f1a1ef7d5304de1d06b2ce31e3d1f0b25")
