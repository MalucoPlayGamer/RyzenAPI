-- Lua provided by RyzenAPI
-- Game: addappid(2443020)

-- MAIN APPLICATION
addappid(2443020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443021, 1, "d65d77b47c92cc2bc2c069a9dc32bd5fbc76e3eaabecf1742786a72aeacb69db")
