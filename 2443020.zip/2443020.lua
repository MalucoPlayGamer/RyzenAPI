-- Lua provided by RyzenAPI 
-- Game: Holstin Demo
addappid(2443020)
addappid(2443021, 1, "d65d77b47c92cc2bc2c069a9dc32bd5fbc76e3eaabecf1742786a72aeacb69db")
