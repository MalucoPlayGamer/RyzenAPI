-- Lua provided by RyzenAPI
-- Game: 100 hidden Cthulhu fish

-- MAIN APPLICATION
addappid(2998850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998851, 1, "68168ae407076b2f407bc067cda63da6c6c5cef5448f0de47da71897562376d6")
