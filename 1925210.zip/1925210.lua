-- Lua provided by RyzenAPI
-- Game: 1925210

-- MAIN APPLICATION
addappid(1925210)
-- Game: addappid(1925210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925211, 1, "49c5cb0e9dfa972091133552ae4ae894bc03f69a3674ff434642efb2f6f69e1d")
