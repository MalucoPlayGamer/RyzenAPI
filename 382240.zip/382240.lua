-- Lua provided by RyzenAPI
-- Game: 382240

-- MAIN APPLICATION
addappid(382240)
-- Game: addappid(382240)

-- MAIN APP DEPOTS / PACKAGES
addappid(382241, 1, "be8e046b690afc06c4571f3349bd7768f1c4ca7ea725b90e54e6f81032ef9b9b")
