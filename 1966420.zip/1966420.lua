-- Lua provided by RyzenAPI
-- Game: Harmony: The Fall of Reverie

-- MAIN APPLICATION
addappid(1966420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966421, 1, "69c6eaa9483c47aa39d38d98bd14fb2e6dae61215f489bc8f603fb52029c148b")

