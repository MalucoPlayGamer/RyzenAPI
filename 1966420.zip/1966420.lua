-- Lua provided by RyzenAPI
-- Game: Harmony: The Fall of Reverie

-- MAIN APPLICATION
addappid(1966420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1966421, 1, "69c6eaa9483c47aa39d38d98bd14fb2e6dae61215f489bc8f603fb52029c148b")

