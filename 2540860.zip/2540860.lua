-- Lua provided by RyzenAPI
-- Game: AppID 2540860

-- MAIN APPLICATION
addappid(2540860)
-- Game: addappid(2540860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540861, 1, "3733a0b960ecf6f5441a2f0f7882f85df9fc06e0a50b7629b5e522e1140aa56a")
