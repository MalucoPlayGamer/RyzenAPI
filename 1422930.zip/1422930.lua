-- Lua provided by RyzenAPI
-- Game: Aripi

-- MAIN APPLICATION
addappid(1422930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1422931,0,"da3784e619b06e522b8bb98b2701ba73b5469e091b51b69699c9a3671cc9e247")

