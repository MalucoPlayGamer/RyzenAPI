-- Lua provided by RyzenAPI
-- Game: Game: AppID 2962420

-- MAIN APPLICATION
addappid(2962420)
-- Game: addappid(2962420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2962421, 1, "421aa1690ba87992f1663d256ac8fa79e1580b392bef84cf1873315ddd3d6cef")
