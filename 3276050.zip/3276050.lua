-- Lua provided by RyzenAPI
-- Game: SpaceCraft

-- MAIN APPLICATION
addappid(3276050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3276051, 1, "16f4c3c685babde916480904915bceab31c662c08053e6776b5a875e9fefd614")

