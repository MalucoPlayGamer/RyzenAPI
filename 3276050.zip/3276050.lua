-- Lua provided by RyzenAPI
-- Game: Game: SpaceCraft

-- MAIN APPLICATION
addappid(3276050)
-- Game: addappid(3276050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3276051, 1, "16f4c3c685babde916480904915bceab31c662c08053e6776b5a875e9fefd614")
