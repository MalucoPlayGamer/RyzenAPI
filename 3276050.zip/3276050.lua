-- Lua provided by SkyAPI 
-- Game: SpaceCraft
addappid(3276050)
addappid(3276051, 1, "16f4c3c685babde916480904915bceab31c662c08053e6776b5a875e9fefd614")
