-- Lua provided by SkyAPI 
-- Game: Burst Fighter
addappid(642600)
addappid(642601, 1, "01aea7312769b421e71114935eb2e58b8ec4973ad8f8fca134ee8ccab3d418a6")
