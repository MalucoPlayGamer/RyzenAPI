-- Lua provided by RyzenAPI
-- Game: Burst Fighter

-- MAIN APPLICATION
addappid(642600)

-- MAIN APP DEPOTS / PACKAGES
addappid(642601, 1, "01aea7312769b421e71114935eb2e58b8ec4973ad8f8fca134ee8ccab3d418a6")

