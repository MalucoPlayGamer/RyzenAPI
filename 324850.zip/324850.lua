-- Lua provided by RyzenAPI
-- Game: Red Orchestra 2/Rising Storm Beta Community Maps

-- MAIN APPLICATION
addappid(324850)

-- MAIN APP DEPOTS / PACKAGES
addappid(324851, 1, "d1d1118ea4e05f94b8aacc846e4f8912415fb5bd8cfa5f5d21262dd46cfa8a3b")
