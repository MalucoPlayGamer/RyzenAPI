-- Lua provided by RyzenAPI
-- Game: Game: Eden Island

-- MAIN APPLICATION
addappid(1974220)
-- Game: addappid(1974220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1974221, 1, "d04501cf6168b2a41828b4c38e4ed25fe56e64d561e099b2d9f216d5430612b0")
