-- Lua provided by SkyAPI 
-- Game: Speed Stars
addappid(1482700)
addappid(1482701, 1, "58464e5ae1fd1ba7524343dff0e363f9c27f0abde7b8ed76dc314152bd943bc7")
