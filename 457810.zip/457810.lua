-- Lua provided by RyzenAPI
-- Game: Game: Sky to Fly: Soulless Leviathan

-- MAIN APPLICATION
addappid(457810)
-- Game: addappid(457810)

-- MAIN APP DEPOTS / PACKAGES
addappid(457811, 1, "91421a009bc7b63d7e980687e181217935c5dba96df075c8b93208090118954a")
