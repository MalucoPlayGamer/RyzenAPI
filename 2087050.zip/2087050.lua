-- Lua provided by RyzenAPI
-- Game: 2087050

-- MAIN APPLICATION
addappid(2087050)
-- Game: addappid(2087050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087050,0,"d93fafda8d97e7e1ac209676dbfdf0f1eca7f4ff5615d70e0a39edfcba518c08")
