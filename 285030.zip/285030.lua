-- Lua provided by RyzenAPI
-- Game: Game: AppID 285030

-- MAIN APPLICATION
addappid(285030)
-- Game: addappid(285030)

-- MAIN APP DEPOTS / PACKAGES
addappid(285031, 1, "07c3e8f5183699d8709a62902d1d9a314fe727b20992d37ba7d9ec079ff5163e")
