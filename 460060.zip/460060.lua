-- Lua provided by RyzenAPI
-- Game: Varenje

-- MAIN APPLICATION
addappid(460060)
addappid(888700)
addappid(888701)
addappid(938450)
addappid(948250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(460061, 1, "a85d8c49a6dd9274ccc7170e3ca7230893ae2cc73abfd7a0c1e9854343fd1b30")
addappid(460062, 1, "385e847c0328a27b047829c29ed6fa9984fbadd8fde94dbb03ebc364ea3ca816")
addappid(460064, 1, "2195475528497ca0cce1b713d63e5549db4522a5c4773af45a80d25e64e1920b")
addappid(460066, 1, "e432f0959afb5dd0c9777203ab5127ca5a16a8e385a6ac46a7d028844f078aa5")

