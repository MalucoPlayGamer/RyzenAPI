-- Lua provided by RyzenAPI
-- Game: Pink Girls

-- MAIN APPLICATION
addappid(2357080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357081, 1, "f75da42e238a8e4688091c39cc3924fefda885227c4beca70329c5cf0b4cfc11")
