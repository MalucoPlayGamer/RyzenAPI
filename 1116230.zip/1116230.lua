-- Lua provided by RyzenAPI
-- Game: Game: The Story of Henry Bishop

-- MAIN APPLICATION
addappid(1116230)
-- Game: addappid(1116230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116231, 1, "f16b1ae81d92ae9f6bdb03911363044d0c249bad397de19827eb058af896697a")
