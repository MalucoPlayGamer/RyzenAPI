-- Lua provided by RyzenAPI
-- Game: Raining Blobs

-- MAIN APPLICATION
addappid(414370)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(414371, 1, "6971dd4969cd0a87b3385bec9f21708da85f720922256c65e0e8d0c845fc5103")
addappid(414372, 1, "d8590778a92ab6e77f25691482e1711515d61b09a914cd34b9e0dffc69aa7f9b")
addappid(414373, 1, "3ba597323ccb013018ba515ef4887fc266a39c406697713f69695a34c2d891e5")
addappid(593040, 0, "892516a491a8acf4c084cb00370f35772e2cc19ea0a1ba55de17172ba1b963a2")

