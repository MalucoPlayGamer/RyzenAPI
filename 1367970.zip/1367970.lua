-- Lua provided by RyzenAPI
-- Game: Motionless

-- MAIN APPLICATION
addappid(1367970)
-- Game: addappid(1367970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367971, 1, "213f6c6040bc1e9443e39b9d3529408c46339316cac4f8b4210f43dd11e9eaf5")
