-- Lua provided by RyzenAPI
-- Game: Between the Stars

-- MAIN APPLICATION
addappid(727130)

-- MAIN APP DEPOTS / PACKAGES
addappid(727131, 1, "cce5f3f16fb6131076693c80acf3791d8b7cb2202c555d8a994a74a1fc207625")
addappid(1092490, 0, "3f394b7b7aa7b6ee0d5633b5d465353be012d35eff6a9dff2be938122b55d8e5")
