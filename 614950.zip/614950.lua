-- Lua provided by RyzenAPI
-- Game: Game: Shootout on Cash Island

-- MAIN APPLICATION
addappid(614950)
-- Game: addappid(614950)

-- MAIN APP DEPOTS / PACKAGES
addappid(614951, 1, "5d9e4a324bd315fc5948ce2952a13e4a7db5e5c915bb8b6af0a315c1f1764712")
addappid(614952, 1, "31327486da47432cb929692673e6136076ef8c6324d8be4643116e9825ed73ae")
addappid(614953, 1, "5e7ae3820f683be48f9147ce697639fa44adf66a6596d13bb2d97f2c4c2631ae")
