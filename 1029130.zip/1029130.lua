-- Lua provided by RyzenAPI
-- Game: AppID 1029130

-- MAIN APPLICATION
addappid(1029130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029131, 1, "5e1352202f4413a42182a39ffba2b67b16d23f0d50dca6a8d7c5f49aad1ec3e4")

