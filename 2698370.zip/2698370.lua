-- Lua provided by RyzenAPI
-- Game: Lone Fungus: Melody of Spores Demo

-- MAIN APPLICATION
addappid(2698370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2698371, 1, "59f2729987976b79487164aa9bdb7fa1e2b2a63c56a2398f333de1648912d336")
