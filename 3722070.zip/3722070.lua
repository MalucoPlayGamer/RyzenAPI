-- Lua provided by RyzenAPI
-- Game: Night Patrol

-- MAIN APPLICATION
addappid(3722070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3722071, 1, "c2f40fafb4c09881c05bf1211b96213a6a98ee9c8b5189cf85e59affd4bb0b7a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3793340)
