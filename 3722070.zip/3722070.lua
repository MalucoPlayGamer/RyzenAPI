-- Lua provided by RyzenAPI 
-- Game: Night Patrol
addappid(3722070)
addappid(3722071, 1, "c2f40fafb4c09881c05bf1211b96213a6a98ee9c8b5189cf85e59affd4bb0b7a")
