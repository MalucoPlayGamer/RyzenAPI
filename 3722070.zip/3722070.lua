-- Lua provided by RyzenAPI
-- Game: 3722070

-- MAIN APPLICATION
addappid(3722070)
-- Game: addappid(3722070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3722071, 1, "c2f40fafb4c09881c05bf1211b96213a6a98ee9c8b5189cf85e59affd4bb0b7a")
