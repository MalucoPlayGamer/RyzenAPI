-- Lua provided by RyzenAPI
-- Game: Artemis: Book One

-- MAIN APPLICATION
addappid(1775530)
addappid(3738540)
-- Game: addappid(1775530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775531, 1, "125bedceb5d1e9652c75cd766d6825d18330ead60c7fa40f420f7110b19e81fd")
