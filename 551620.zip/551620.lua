-- Lua provided by RyzenAPI
-- Game: Approaching Infinity

-- MAIN APPLICATION
addappid(551620)
addappid(1691390)
addappid(3723910)
addappid(4151410)
addappid(4153590)

-- MAIN APP DEPOTS / PACKAGES
addappid(551621, 1, "d087c1a1ebfe30a40406d23db94562927895c1f28e1d244bbe0c195c4e855eb6")

