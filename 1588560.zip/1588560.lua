-- Lua provided by RyzenAPI
-- Game: The Swordsmen X: Survival

-- MAIN APPLICATION
addappid(1588560)
addappid(2282870)
addappid(2282980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1588561, 1, "6acf4728133381c900268f90c87c5cbb3f9ec3599aed4a4819fc260fff54bc0d")

