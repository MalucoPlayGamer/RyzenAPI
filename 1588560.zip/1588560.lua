-- Lua provided by RyzenAPI
-- Game: 1588560

-- MAIN APPLICATION
addappid(1588560)
-- Game: addappid(1588560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588561, 1, "6acf4728133381c900268f90c87c5cbb3f9ec3599aed4a4819fc260fff54bc0d")
