-- Lua provided by SkyAPI 
-- Game: South of the Circle Soundtrack
addappid(2019870)
addappid(2019871, 1, "3cce425aeb82d87fcd21cf076f156b8ca7a79111cbe52fd24b22d74414c58dcf")
addappid(2019872, 1, "2e2f58cc431c827bf2aeb95b24338eec7fb145b640e531cd032eceb3d4adfb2d")
