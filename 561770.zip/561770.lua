-- Lua provided by RyzenAPI
-- Game: AppID 561770

-- MAIN APPLICATION
addappid(561770)
-- Game: addappid(561770)

-- MAIN APP DEPOTS / PACKAGES
addappid(561771, 1, "3808dce8384de63f25b4706d2d7cf87b27284b2d7936f29ff0e48cb5ac9c96df")
