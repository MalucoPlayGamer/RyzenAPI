-- Lua provided by RyzenAPI
-- Game: Just Ignore Them

-- MAIN APPLICATION
addappid(561770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(561771, 1, "3808dce8384de63f25b4706d2d7cf87b27284b2d7936f29ff0e48cb5ac9c96df")
