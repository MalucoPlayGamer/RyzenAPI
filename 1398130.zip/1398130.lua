-- Lua provided by RyzenAPI
-- Game: addappid(1398130)

-- MAIN APPLICATION
addappid(1398130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398131, 1, "7b35632add6340b0e3e3a4b514b5a6425e2ca143b49f326346a0a4e3eac9a392")
