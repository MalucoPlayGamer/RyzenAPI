-- Lua provided by RyzenAPI
-- Game: Duplicate Dissolution

-- MAIN APPLICATION
addappid(2825310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825311, 1, "9745628c65580d2818cc16bd335a3f5006e73a51e15772c8b43626afb4538444")

