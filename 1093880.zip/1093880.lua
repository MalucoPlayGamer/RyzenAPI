-- Lua provided by RyzenAPI
-- Game: XWallpaper

-- MAIN APPLICATION
addappid(1093880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093881, 1, "a1be3040319891b65e6a11b84c9fd1fc46c2229d965c57d5f28113fc81b79b72")

