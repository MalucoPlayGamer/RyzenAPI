-- Lua provided by RyzenAPI 
-- Game: AppID 12520
addappid(12520)
addappid(12521, 1, "cbde8c768ce2b037a8391bcd810a2cca60402c2b08e618a9b7c78264eb815ec1")
