-- Lua provided by RyzenAPI
-- Game: Symbiotic Overload

-- MAIN APPLICATION
addappid(659820)

-- MAIN APP DEPOTS / PACKAGES
addappid(659821, 1, "a59412748e33e336811ba1dd6af39917b8a9b0b541862467026d1776ea9cf137")

