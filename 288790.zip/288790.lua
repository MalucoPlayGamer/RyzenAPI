-- Lua provided by RyzenAPI
-- Game: 288790

-- MAIN APPLICATION
addappid(288790)
-- Game: addappid(288790)

-- MAIN APP DEPOTS / PACKAGES
addappid(288791, 1, "dc1f49e7487a7b0f0def01563c2db0d465a8f227cf904d28db1bf8a3bc959e1c")
