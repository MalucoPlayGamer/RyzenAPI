-- Lua provided by RyzenAPI
-- Game: Let's Cook It!

-- MAIN APPLICATION
addappid(4480370) -- Let's Cook It!

-- MAIN APP DEPOTS / PACKAGES
addappid(4480371, 1, "03819f232d999d2d5725b662ad9a600d103c4cf9d9adbdd6c9f975bf1dc8ac5a") -- Depot 4480371

