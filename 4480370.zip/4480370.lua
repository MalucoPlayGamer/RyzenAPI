-- 4480370's Lua and Manifest Created by Hubcap Manifest
-- Let's Cook It!
-- Created: August 15, 2026 at 00:09:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4480370) -- Let's Cook It!
-- MAIN APP DEPOTS
addappid(4480371, 1, "03819f232d999d2d5725b662ad9a600d103c4cf9d9adbdd6c9f975bf1dc8ac5a") -- Depot 4480371
setManifestid(4480371, "1116362399855591675", 267405017)