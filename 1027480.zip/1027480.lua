-- Lua provided by RyzenAPI 
-- Game: AppID 1027480
addappid(1027480)
addappid(1027481, 1, "3d339e0151c04b9365f82d4e6b10c4c4e2e4d96049fd8b3cee18cd736622a632")
