-- Lua provided by RyzenAPI
-- Game: AppID 1027480

-- MAIN APPLICATION
addappid(1027480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1027481, 1, "3d339e0151c04b9365f82d4e6b10c4c4e2e4d96049fd8b3cee18cd736622a632")

