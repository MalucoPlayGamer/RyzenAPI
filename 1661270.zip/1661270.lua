-- Lua provided by RyzenAPI
-- Game: 1661270

-- MAIN APPLICATION
addappid(1661270)
-- Game: addappid(1661270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661273,0,"d9e74c8a7ba11bfd9ab1fdbaed5742f0dc916ac23cd1a278c9c603f1c0bc2b82")
