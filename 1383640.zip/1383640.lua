-- Lua provided by RyzenAPI
-- Game: Attack at Dawn: North Africa

-- MAIN APPLICATION
addappid(1383640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383641, 1, "51aedabd55ce89f8f3e48cba58b64edc7b7722baf382d9329770d0bd6efbff27")

