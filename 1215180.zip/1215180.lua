-- Lua provided by RyzenAPI
-- Game: 1215180

-- MAIN APPLICATION
addappid(1215180)
-- Game: addappid(1215180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215181, 1, "7b7ce709a8e515aaf907b1101761d7283c7901d2ef6a6a02b5a9acf5c82d3888")
