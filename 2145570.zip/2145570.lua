-- Lua provided by RyzenAPI
-- Game: AppID 2145570

-- MAIN APPLICATION
addappid(2145570)
-- Game: addappid(2145570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2145571, 1, "512186c89ce5280b92ea6a03472e6d72aef32448665cc1f8511efc9a09d1b2f7")
