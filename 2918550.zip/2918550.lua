-- Lua provided by RyzenAPI
-- Game: Drive Me Crazy

-- MAIN APPLICATION
addappid(2918550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2918551, 1, "72626cdd4f1c805b8747da6c2e8470d20dced3af4db719757fbfe97de9129aec")
addappid(3137250, 0, "b4d82a878ef74d5f8431b8782f10f19e71b5204008b9688a10a6989917de89ce")

