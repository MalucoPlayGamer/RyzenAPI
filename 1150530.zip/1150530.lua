-- Lua provided by RyzenAPI
-- Game: AppID 1150530

-- MAIN APPLICATION
addappid(1150530)
addappid(2493640)
addappid(2493641)
addappid(2563910)
addappid(2632270)
addappid(2632280)
addappid(2632290)
addappid(2632300)
addappid(2632310)
addappid(2853350)
addappid(2853360)
addappid(2853370)
addappid(2853380)
addappid(2853390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150531, 1, "be7f839c9405122842ab1a51bb4f328f4d7a3e716a4dd212656b6d59625f6175")
addappid(2506660, 0, "b3c05adc7eae1503dba628d881de063ea95f4d8226ab2d84f28461a401e66a08")
