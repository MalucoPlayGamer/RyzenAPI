-- Lua provided by RyzenAPI 
-- Game: AppID 904800
addappid(904800)
addappid(904801, 1, "ed9694925db9c2ddefeb050a0a58c76649fa12c162e2bfcb211fe5d764ab8ca7")
