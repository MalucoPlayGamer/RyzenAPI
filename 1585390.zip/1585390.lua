-- Lua provided by RyzenAPI
-- Game: 1585390

-- MAIN APPLICATION
addappid(1585390)
-- Game: addappid(1585390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585391, 1, "e060df2be0000f885ac18b2180efba1741399e3ea1da70a0ca38167c1e127ba1")
