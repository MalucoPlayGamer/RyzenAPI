-- Lua provided by RyzenAPI
-- Game: Code Zero

-- MAIN APPLICATION
addappid(1585390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1585391, 1, "e060df2be0000f885ac18b2180efba1741399e3ea1da70a0ca38167c1e127ba1")

