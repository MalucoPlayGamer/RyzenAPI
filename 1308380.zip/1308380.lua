-- Lua provided by RyzenAPI
-- Game: 1308380

-- MAIN APPLICATION
addappid(1308380)
addappid(1462660)
-- Game: addappid(1308380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308381, 1, "65995160f08bf18570e286e97af51a585f24cb48ec50c47962e50e0ca4551d12")
