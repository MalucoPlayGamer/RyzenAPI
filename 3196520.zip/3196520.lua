-- Lua provided by RyzenAPI
-- Game: Island Robot Farm

-- MAIN APPLICATION
addappid(3196520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196521, 1, "48d0a879c5bc741049880aec83b3892317cdcca7cf508ac157ce08778cc2bbb1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4155980)
addappid(4164040)
