-- Lua provided by RyzenAPI
-- Game: The Braves Demo

-- MAIN APPLICATION
addappid(2569690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569691, 1, "0a24680921eef78323396960f855a88f99d9466302b11ddf44cf11bc833e27fa")
