-- Lua provided by RyzenAPI
-- Game: Dead Island Retro Revenge

-- MAIN APPLICATION
addappid(337360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(337361, 1, "a029e93002937cf23f80a1c7dbc0e6f7ca2c435dd11cd40ba9ae86c470d5fc4d")
addappid(337362, 1, "de0d9d99fc331d5f41ffca0c6adac48d56d64985fe8341ed144e128a078ed256")

