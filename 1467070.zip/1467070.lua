-- Lua provided by RyzenAPI
-- Game: Game: Time Trap 2 - Search and Find Objects Game - Hidden Pictures

-- MAIN APPLICATION
addappid(1467070)
-- Game: addappid(1467070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467071, 1, "c6d2003d664de144b247af18d21a786056f6c7dc2a66d7028654e434c2d1a149")
