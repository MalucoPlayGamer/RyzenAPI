-- Lua provided by SkyAPI 
-- Game: Vending Machine Business Simulator
addappid(2998750)
addappid(2998751, 1, "da8ce2c4542a33eb0d7c8cf3efeabe0cd2434e951d4b5932ffe4a7fca347bfab")
