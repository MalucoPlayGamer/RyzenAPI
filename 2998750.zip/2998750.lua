-- Lua provided by RyzenAPI
-- Game: 2998750

-- MAIN APPLICATION
addappid(2998750)
-- Game: addappid(2998750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998751, 1, "da8ce2c4542a33eb0d7c8cf3efeabe0cd2434e951d4b5932ffe4a7fca347bfab")
