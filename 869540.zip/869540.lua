-- Lua provided by RyzenAPI
-- Game: Game: Hero Hunters - 杀手 3D 2K19

-- MAIN APPLICATION
addappid(869540)
-- Game: addappid(869540)

-- MAIN APP DEPOTS / PACKAGES
addappid(869541, 1, "8fcf99849e19db13b830e9060040d3ba56e05d25a9e76a0f93c2386938b48651")
