-- Lua provided by RyzenAPI
-- Game: Worms World Party Remastered

-- MAIN APPLICATION
addappid(270910)
addappid(358901)
-- Game: addappid(270910)

-- MAIN APP DEPOTS / PACKAGES
addappid(270911, 1, "3a6633a50c27189b4f67c403ff3cb40282e0b9a68a1e0fe1c3fccc20825c1794")
