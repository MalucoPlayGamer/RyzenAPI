-- Lua provided by RyzenAPI
-- Game: Worms World Party Remastered

-- MAIN APPLICATION
addappid(270910)
addappid(358901)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(270911, 1, "3a6633a50c27189b4f67c403ff3cb40282e0b9a68a1e0fe1c3fccc20825c1794")

