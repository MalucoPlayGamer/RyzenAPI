-- Lua provided by RyzenAPI
-- Game: Waifus Smash

-- MAIN APPLICATION
addappid(1602490)
addappid(1705990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602491, 1, "16c45c4cf25c55c63628491e2e63b6b8e5c6049d236a90b3ffee0f0946fe378a")

