-- Lua provided by RyzenAPI
-- Game: Lonely Mountains: Snow Riders

-- MAIN APPLICATION
addappid(2545360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545361, 1, "097b0ce09326208a8d662ac6de3f39f1cc1f8bad9caaecd6ffb87937706620d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3976250)
addappid(4602210)
addappid(4602220)
