-- Lua provided by RyzenAPI
-- Game: 2545360

-- MAIN APPLICATION
addappid(2545360)
-- Game: addappid(2545360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545361, 1, "097b0ce09326208a8d662ac6de3f39f1cc1f8bad9caaecd6ffb87937706620d8")
