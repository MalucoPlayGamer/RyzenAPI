-- Lua provided by RyzenAPI
-- Game: Hidden World Top-Down 3D

-- MAIN APPLICATION
addappid(1915940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915941, 1, "f4ec8167c31434fc50b40f06b0b6586c10dd9655b30d892a679e41f2dc32ad41")

