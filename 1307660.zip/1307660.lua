-- Lua provided by RyzenAPI 
-- Game: Ravenbound
addappid(1307660)
addappid(1307661, 1, "80a2d108c008202648fe42f3e33563339592701b34d78fb420e17bb2dfb42f2a")
