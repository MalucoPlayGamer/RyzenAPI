-- Lua provided by RyzenAPI
-- Game: Ravenbound

-- MAIN APPLICATION
addappid(1307660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307661, 1, "80a2d108c008202648fe42f3e33563339592701b34d78fb420e17bb2dfb42f2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2356650)
addappid(2447860)
