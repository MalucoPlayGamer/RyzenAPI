-- Lua provided by RyzenAPI
-- Game: Nif Nif

-- MAIN APPLICATION
addappid(2631650)
-- Game: addappid(2631650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631651, 1, "40ba0a1e8bf6d10983b2688f6dc34ed6b3238f1e9c542ceeed3ac78b481b9d5c")
