-- Lua provided by RyzenAPI
-- Game: addappid(1597500)

-- MAIN APPLICATION
addappid(1597500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597501, 1, "2dcda3886c0bcf63ec3322dbb837541c1560d7b0a266489c13f7dc1524ff32ff")
