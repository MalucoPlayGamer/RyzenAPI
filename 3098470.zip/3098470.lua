-- Lua provided by RyzenAPI
-- Game: Arctic Motel Simulator

-- MAIN APPLICATION
addappid(3098470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3098471, 1, "beb4924fff3aeddd33728e557b5cd2069aff5277b25b967cb0f80443de42ba67")

