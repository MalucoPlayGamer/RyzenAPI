-- Lua provided by RyzenAPI
-- Game: Life is Hard

-- MAIN APPLICATION
addappid(414080)

-- MAIN APP DEPOTS / PACKAGES
addappid(414081, 1, "c299f871770e0d9a436e6b9a5b567bbf92d50c12dcbcc524302aa5e7a608595e")
addappid(414082, 1, "5d93e6dc271a77e09f79f1d1b4302d7b9fbbcef928c376eb6042f2a30ddc490a")
addappid(414083, 1, "37468cb4135c71c781b59d9cfd542a4b3b3ee8e1ca367d508997741ce0733289")
addappid(414084, 1, "5dd2a9c162853c62719eb5bd345d22dde0f2e21975e579a8edaf005317ff6940")
addappid(414085, 1, "1443eaf861dc6c5abc5dc3311094a1ca67183861c86501e33ff58e84c3b25151")
addappid(414086, 1, "c8f79cfc6881c173154fc39a17788ddde00bec116ce5effdc40570ad77377e37")
addappid(414087, 1, "c403d09022af0ac80f27d2ba0e088eba3fb41319d68dadad65d2352e1a251aa6")
addappid(417230, 0, "30e66aa83a355e68812123dbaa2f308f9b25dac6621459e2d5eb74dc2ec27924")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
