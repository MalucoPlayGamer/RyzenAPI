-- Lua provided by RyzenAPI
-- Game: You are Peter Shorts

-- MAIN APPLICATION
addappid(2352640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352641, 1, "9c122e303321fa53a6ff3ef3d8278d84b15654aeb128fb409e7c4e000a2cfbb1")
