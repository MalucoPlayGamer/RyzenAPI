-- Lua provided by RyzenAPI
-- Game: ATONE: Heart of the Elder Tree

-- MAIN APPLICATION
addappid(894620)

-- MAIN APP DEPOTS / PACKAGES
addappid(894621, 1, "3e93b0c93c855f931dd181fb75d3c66d5b50f79da7d881de0cf6cc4e7787c9ad")

