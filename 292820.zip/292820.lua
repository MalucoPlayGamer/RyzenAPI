-- Lua provided by RyzenAPI
-- Game: AppID 292820

-- MAIN APPLICATION
addappid(292820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(292821, 1, "5cbe96a08f4048e2e157c4c8a799fe6a06c777ca70d3a74dc0403508c84ef5b2")
addappid(292822, 1, "2d2812dc231e25ccf50e0a6fb75b9b1ed6a15da1aff78a530e2836e0b0d68f05")

