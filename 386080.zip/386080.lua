-- Lua provided by RyzenAPI
-- Game: Pharaonic

-- MAIN APPLICATION
addappid(386080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(386081, 1, "af845492d1439e9676862a1fd02ce218992df31c0318b917a49fb567c970f7e4")
addappid(386082, 1, "ed3861b0f11acce11b6cf44189dd5d453d59a9af3f7fadd19af48d26bc7ac1af")
addappid(386083, 1, "769ee789d18aa547c7ede117d6d69ab519057b5cc6e1b3caecd8c1d93fbeee92")

