-- Lua provided by RyzenAPI
-- Game: 386080

-- MAIN APPLICATION
addappid(386080)
-- Game: addappid(386080)

-- MAIN APP DEPOTS / PACKAGES
addappid(386081, 1, "af845492d1439e9676862a1fd02ce218992df31c0318b917a49fb567c970f7e4")
addappid(386082, 1, "ed3861b0f11acce11b6cf44189dd5d453d59a9af3f7fadd19af48d26bc7ac1af")
addappid(386083, 1, "769ee789d18aa547c7ede117d6d69ab519057b5cc6e1b3caecd8c1d93fbeee92")
