-- Lua provided by RyzenAPI
-- Game: Virtual Boxing League

-- MAIN APPLICATION
addappid(777430)

-- MAIN APP DEPOTS / PACKAGES
addappid(777431, 1, "ba398fcd8ae4e2cb00c39a63daaa79011a555647f91cb98b9f73ccb32cda8fc3")

