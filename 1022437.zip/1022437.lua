-- Lua provided by RyzenAPI
-- Game: DFF NT: Firion Starter Pack

-- MAIN APPLICATION
addappid(1022437)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022437,0,"9d49566135be2254e648766a3b615201c505b77de427b824e93fc99d9a84b02d")

