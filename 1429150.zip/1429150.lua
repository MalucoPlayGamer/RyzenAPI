-- Lua provided by RyzenAPI
-- Game: 1429150

-- MAIN APPLICATION
addappid(1429150)
-- Game: addappid(1429150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429151, 1, "3bafd302794f50e2031adb6ea5dad62c3478d1eda232044deaf520f93b4ecd4e")
