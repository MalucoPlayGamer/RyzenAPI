-- Lua provided by SkyAPI 
-- Game: AppID 1910600
addappid(1910600)
addappid(1910601, 1, "665209bc6439a7dfae5a79ab6fe6ca8ec9e50d273f51dcd8e7c6ec7e7f1162f1")
