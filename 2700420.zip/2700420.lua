-- Lua provided by RyzenAPI
-- Game: addappid(2700420)

-- MAIN APPLICATION
addappid(2700420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700421, 1, "29eee0eea6e01352c5ebf3e75ee5cc771496f6b727093a67c79489cd89bb248d")
