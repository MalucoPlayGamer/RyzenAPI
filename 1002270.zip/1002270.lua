-- Lua provided by RyzenAPI
-- Game: PiiSim

-- MAIN APPLICATION
addappid(1002270)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1002271, 1, "e2639beffae42bc28e25b54bac1b2cffb6026ecdc6ed663bd137e1f0256b2de4")

