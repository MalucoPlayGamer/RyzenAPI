-- Lua provided by RyzenAPI
-- Game: AppID 1002270

-- MAIN APPLICATION
addappid(1002270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002271, 1, "e2639beffae42bc28e25b54bac1b2cffb6026ecdc6ed663bd137e1f0256b2de4")
