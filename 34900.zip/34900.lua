-- Lua provided by RyzenAPI
-- Game: addappid(34900)

-- MAIN APPLICATION
addappid(34900)

-- MAIN APP DEPOTS / PACKAGES
addappid(34903,0,"1ba1e353deb4be34906e707591bb7a725873c1e1e04aae75fbeb18496c199269")
