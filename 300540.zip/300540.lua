-- Lua provided by RyzenAPI
-- Game: Sweet Lily Dreams

-- MAIN APPLICATION
addappid(300540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(300541, 1, "f379ecef4902e6f51857e5e587accf003684b5ac2d1728e955aa46b53d346044")

