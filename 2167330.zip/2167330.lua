-- Lua provided by RyzenAPI
-- Game: The Sims™ 4 Greenhouse Haven Kit

-- MAIN APPLICATION
addappid(2167330)
-- Game: addappid(2167330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167330,0,"f9b163fbdb557e7821047ab65304ba97d3c36a70e14f66a41a20e9599c7ed9f3")
addappid(2167332,0,"bd60c06ea88d4ebb6237eda6dd4bca1c014ba5f7018c94f8a6c917d3f46a188d")
addappid(2167334,0,"0de0c224e368bb6bcde027e5ade31458443cb685f06e6cb045d06153b1d82b2a")
addappid(2167337,0,"3ae37693d7ebb9d40561422e94a08fe88512c3edef84ecc34d175a30d8f789f6")
addappid(2167338,0,"7fa1002a6a4fd2efdc58caf00b9abb903826d555aac1817f3a82619ebde857ec")
addappid(2167339,0,"ab0f829f818e0a3cdd040a9f5e6fdaebaee185ca26618c3cf19d51c09d477f2c")
addappid(2243772,0,"76061561e4126b37cb97ec1a32745d23acc88a252ff8f6b8b81800e67f3db41f")
addappid(2243779,0,"8dfd5673a1d75477a520d6b289fbd6a9d2557772f4dbbdfdc6fcc47bad0871ab")
