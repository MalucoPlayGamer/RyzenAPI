-- Lua provided by RyzenAPI
-- Game: 1691420

-- MAIN APPLICATION
addappid(1691420)
addappid(1697580)
-- Game: addappid(1691420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691421, 1, "e981a8f752642b6ae69e75b3530b96dbda10dc6ca6f0be042d2c08d494daf551")
