-- Lua provided by RyzenAPI
-- Game: Grand Tanks: WW2 Tank Games

-- MAIN APPLICATION
addappid(2391400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391401, 1, "aa13730c050d572d57a668bb5d2dc5944b1cad4ca8ff24dbef1f6f8d0aca890c")
addappid(2391402, 1, "fae792bbacc40259ac73aa890dd272eed930cfa0b5dc82d2894870b459320ddb")
addappid(2391403, 1, "5d8db58b39666ccf209e49ce96d513814f617db091830b54161cb3069bbd47f4")
