-- Lua provided by RyzenAPI
-- Game: Monster Girl Incursion

-- MAIN APPLICATION
addappid(1434650)
addappid(1440930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434651, 1, "8316d99fbf589466844de2df44d94ccef937ceec95ccb8e5d524831f6fdc85fd")

