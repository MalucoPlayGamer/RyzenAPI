-- Lua provided by RyzenAPI 
-- Game: AppID 396790
addappid(396790)
addappid(396791, 1, "30d1ca46103f44a8807594973e1ebb2c562449a1c661775022f6f95940c19158")
