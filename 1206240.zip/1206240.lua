-- Lua provided by RyzenAPI
-- Game: Talvisota - Winter War

-- MAIN APPLICATION
addappid(1206240)
-- Game: addappid(1206240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206241, 1, "05c7a4f4d4212b5ad26b965173a96d4dadb210ff7bb06c9b441cc0b26bb81b90")
