-- Lua provided by RyzenAPI
-- Game: Merek's Market

-- MAIN APPLICATION
addappid(1610860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610861, 1, "f5f52b94a72bc8c74b196d82577e1d6ab9442dcfda9d3c43151c1a7011a01a43")
