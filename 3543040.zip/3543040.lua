-- Lua provided by RyzenAPI
-- Game: 3543040

-- MAIN APPLICATION
addappid(3543040)
-- Game: addappid(3543040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3543041, 1, "976cf31d04a1c05b8e113f94713dc136c8a7f6ab629a07faa0235236417b5cb3")
