-- Lua provided by RyzenAPI 
-- Game: Conquer the world
addappid(3543040)
addappid(3543041, 1, "976cf31d04a1c05b8e113f94713dc136c8a7f6ab629a07faa0235236417b5cb3")
