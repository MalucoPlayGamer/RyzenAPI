-- Lua provided by RyzenAPI
-- Game: 3032580

-- MAIN APPLICATION
addappid(3032580)
-- Game: addappid(3032580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032581, 1, "4c28fabe6c658ae9bcaec12530c210df0db036af33b8cd40234de432a4825925")
