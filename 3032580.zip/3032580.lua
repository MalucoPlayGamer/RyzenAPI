-- Lua provided by SkyAPI 
-- Game: LEVEL UP 80
addappid(3032580)
addappid(3032581, 1, "4c28fabe6c658ae9bcaec12530c210df0db036af33b8cd40234de432a4825925")
