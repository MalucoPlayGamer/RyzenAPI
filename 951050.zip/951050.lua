-- Lua provided by RyzenAPI
-- Game: Another Hardcore Game

-- MAIN APPLICATION
addappid(951050)
-- Game: addappid(951050)

-- MAIN APP DEPOTS / PACKAGES
addappid(951051, 1, "6fcba04a6ef536636eafc82430b72f4728c40acaa30b79bf06ce95f5ae705988")
