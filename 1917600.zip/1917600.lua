-- Lua provided by RyzenAPI
-- Game: Game: 牝喰いダンジョン - MeguiDungeon -

-- MAIN APPLICATION
addappid(1917600)
-- Game: addappid(1917600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917601, 1, "3e3e240e1dd44dca40638f2fc3c81218a463570fe4bbcf1a6107b2951789cbd0")
