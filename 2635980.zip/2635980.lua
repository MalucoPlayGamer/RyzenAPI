-- Lua provided by RyzenAPI
-- Game: Bring Me that Shawarma

-- MAIN APPLICATION
addappid(2635980)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3013030)
