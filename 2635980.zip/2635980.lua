-- Lua provided by RyzenAPI
-- Game: Bring Me that Shawarma

-- MAIN APPLICATION
addappid(2635980)
addappid(3013030)

