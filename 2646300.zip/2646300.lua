-- Lua provided by RyzenAPI
-- Game: Game: AppID 2646300

-- MAIN APPLICATION
addappid(2646300)
-- Game: addappid(2646300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646301, 1, "a7402c32159aa7631278bedea3ad78ffa3bad937d4d45ccf0b384b4469f52b97")
addappid(2646302, 1, "fd341bdb96bee1eba356ac6b77745f0995ae3e0f8290b475aef0d79abca4ec3b")
