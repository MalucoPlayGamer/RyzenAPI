-- Lua provided by RyzenAPI
-- Game: Bounty Trail

-- MAIN APP DEPOTS / PACKAGES
addappid(4126530, 1, "2b5b591c2a8fc29ade1baaaca264a55fd9b0007553314e53873af7b5df284b58") -- Bounty Trail
addappid(4126531, 1, "fbf9f0d9fbabcf8e9c4fbe168adeb6fec9b70e3a6cebc10cf6a572412c789007") -- Depot 4126531

