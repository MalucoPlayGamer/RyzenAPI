-- Lua provided by RyzenAPI
-- Game: City Bus Manager - North America

-- MAIN APPLICATION
addappid(1903920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903921, 1, "e093b998ba2d6e782584d9711f4ca3721107926c74571dfd752c86eb7307559a")
