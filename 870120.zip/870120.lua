-- Lua provided by RyzenAPI
-- Game: AppID 870120

-- MAIN APPLICATION
addappid(870120)

-- MAIN APP DEPOTS / PACKAGES
addappid(870121, 1, "f68f7b50b3d78df0c02200d586c1bb56154544deac5844927bac87fcb5396626")
addappid(983930, 0, "e4fc1c2378da787e7d59cfb72f4efaca2dfeb6f8deaa4867042e2d61fca6a318")
