-- Lua provided by RyzenAPI
-- Game: AppID 870120

-- MAIN APPLICATION
addappid(870120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(870121, 1, "f68f7b50b3d78df0c02200d586c1bb56154544deac5844927bac87fcb5396626")
addappid(983930, 0, "e4fc1c2378da787e7d59cfb72f4efaca2dfeb6f8deaa4867042e2d61fca6a318")

