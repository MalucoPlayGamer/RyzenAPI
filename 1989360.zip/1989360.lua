-- Lua provided by RyzenAPI
-- Game: Game: Sargasso on Steam

-- MAIN APPLICATION
addappid(1989360)
-- Game: addappid(1989360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989361, 1, "a87429befb60ea483d7c1d4c4c68e5df5fa8a4480ee9882138e83def7a670d03")
