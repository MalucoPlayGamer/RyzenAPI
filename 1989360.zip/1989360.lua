-- Lua provided by RyzenAPI 
-- Game: Sargasso on Steam
addappid(1989360)
addappid(1989361, 1, "a87429befb60ea483d7c1d4c4c68e5df5fa8a4480ee9882138e83def7a670d03")
