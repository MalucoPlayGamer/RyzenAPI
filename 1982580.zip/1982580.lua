-- Lua provided by RyzenAPI 
-- Game: Last Command Demo
addappid(1982580)
addappid(1982581, 1, "557db8d3c8c5c3bdfeff324a8a9086f9f1afa532ef5d17570cb2a2f4993816bc")
