-- Lua provided by RyzenAPI
-- Game: 1128480

-- MAIN APPLICATION
addappid(1128480)
-- Game: addappid(1128480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128482,0,"470668f9cf0422688f81dcd53dc00cee1fca1ab56bb1fc4c2d45a128a3535fc5")
addappid(1128483,0,"6ca2905609dfcfe76a8d90b845eac2085d050bc0f9814c733d3a0fafba4e8263")
addappid(1128484,0,"0f0b3474b65d7b5aabe5821dca3d4ac62de71d7c693c33d4acaaf59be8ea23b9")
