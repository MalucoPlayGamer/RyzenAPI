-- Lua provided by RyzenAPI
-- Game: Game: Magical Girl Clicker

-- MAIN APPLICATION
addappid(2142540)
-- Game: addappid(2142540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142541, 1, "b7d204c004a99df32da2c3b321aba441ac3441bdbd2e72406374174c42b6efeb")
