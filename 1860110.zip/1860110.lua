-- Lua provided by RyzenAPI
-- Game: 1860110

-- MAIN APPLICATION
addappid(1860110)
-- Game: addappid(1860110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860111, 1, "b42afd4e8ff8196d040fce1471380e5be46f76891d4b06c3d1ad272dbc58f759")
