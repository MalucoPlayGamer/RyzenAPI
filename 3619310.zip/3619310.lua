-- Lua provided by RyzenAPI
-- Game: Game: Bingo Pet

-- MAIN APPLICATION
addappid(3619310)
-- Game: addappid(3619310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3619311, 1, "0647355863a7f88ab502db6673953771ff248f84df4981f3af656a8168029f59")
