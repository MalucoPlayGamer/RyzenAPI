-- Lua provided by RyzenAPI
-- Game: Invisible Apartment

-- MAIN APPLICATION
addappid(351790)
-- Game: addappid(351790)

-- MAIN APP DEPOTS / PACKAGES
addappid(351791, 1, "d3c5844f64fa6ac97dd716b3c2f6fdb49808112a3b8abfdc48a13c12325d63a3")
addappid(351792, 1, "893d7122138770bebbb58b33d656ffe1cb65c6b086b77b209489282ca4480077")
addappid(351793, 1, "ce7232c40cd7bd27f440019cae0b6976e1a3e1a775c708953fe8daba2449d38b")
addappid(351794, 1, "1b5d6bcf6a4415e7a76ac89bb951fa6e2c44862b25c8ff377c5d4003d4cc289c")
