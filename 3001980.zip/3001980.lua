-- Lua provided by RyzenAPI
-- Game: Doki Doki AI Interrogation Soundtrack

-- MAIN APPLICATION
addappid(3001980)
-- Game: addappid(3001980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001981, 1, "9e0754dff5e0ba9eb2b275059bec6d754644c6d217aaf4b1e920ddea9b418c80")
addappid(3001982, 1, "4e9aa44ee7e07c8967813ab72aa3351d60fb4993b136d221c92b3da542630fed")
