-- Lua provided by RyzenAPI
-- Game: AppID 1951070

-- MAIN APPLICATION
addappid(1951070)
addappid(1951110)
addappid(1951111)
-- Game: addappid(1951070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951071, 1, "ba63cebda06ee1854e2098358a01f423d999d231da936879a8775cd1150be842")
