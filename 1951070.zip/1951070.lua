-- Lua provided by RyzenAPI
-- Game: Wind Angel Challenge

-- MAIN APPLICATION
addappid(1951070)
addappid(1951110)
addappid(1951111)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951071, 1, "ba63cebda06ee1854e2098358a01f423d999d231da936879a8775cd1150be842")
