-- Lua provided by RyzenAPI
-- Game: 2191710

-- MAIN APPLICATION
addappid(2191710)
-- Game: addappid(2191710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191711, 1, "24c9d586a3a2f9c0c3decd0d691ae8b4ebd257c6cf32c15e401e5cf5e9b86a1e")
