-- Lua provided by RyzenAPI
-- Game: Game: Last Vanguard

-- MAIN APPLICATION
addappid(1729180)
-- Game: addappid(1729180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729181, 1, "784d51b5ccd0cc968dcde09b31486c10ca786afc85cf0669305f4ebaf1360abe")
