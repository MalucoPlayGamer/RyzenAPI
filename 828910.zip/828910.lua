-- Lua provided by RyzenAPI
-- Game: Game: AppID 828910

-- MAIN APPLICATION
addappid(828910)
-- Game: addappid(828910)

-- MAIN APP DEPOTS / PACKAGES
addappid(828911, 1, "19e460848a3e9d67145c73f6309979af79eb4ef1e87220bf33a468cc48d0d0d8")
