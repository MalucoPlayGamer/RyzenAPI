-- Lua provided by RyzenAPI
-- Game: CODE VEIN Demo

-- MAIN APPLICATION
addappid(1192670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192671, 1, "07c24d2cc4af6aa988aca0ba66860f8a7993d48e37aef6417c43c54d4767357f")

