-- Lua provided by RyzenAPI
-- Game: Game: 东巴

-- MAIN APPLICATION
addappid(2708490)
-- Game: addappid(2708490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708491, 1, "051b3577877a5780380d1b9058a2bd71838001d03e86592d4decbaf74665c37c")
