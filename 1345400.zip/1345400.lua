-- Lua provided by RyzenAPI
-- Game: addappid(1345400)

-- MAIN APPLICATION
addappid(1345400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345401, 1, "8c863cf40fb978b7eb517f58725506b14ca27a9ebcde46749a3de2c87ca10068")
