-- Lua provided by RyzenAPI
-- Game: 群鹰之岛

-- MAIN APPLICATION
addappid(1345400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345401, 1, "8c863cf40fb978b7eb517f58725506b14ca27a9ebcde46749a3de2c87ca10068")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
