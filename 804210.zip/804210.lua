-- Lua provided by RyzenAPI
-- Game: AppID 804210

-- MAIN APPLICATION
addappid(804210)

-- MAIN APP DEPOTS / PACKAGES
addappid(804211, 1, "8f51ea72e0c7cc9496c1214f9fcdf0afd3d8f0f2e9ff709a8dcebba1840cc6a5")
addappid(940570, 0, "05377210f4e4f0d499cebe204bcfb03eebaeddfec1b93c909e3445420ca6ef76")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
