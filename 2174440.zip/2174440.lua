-- Lua provided by RyzenAPI
-- Game: Jump'n'Brawl

-- MAIN APPLICATION
addappid(2174440)
-- Game: addappid(2174440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174441, 1, "20255d51ec3458f538ede968abf6ab66344a69e8bd642a2280168d73ce03d79d")
