-- Lua provided by RyzenAPI
-- Game: Illusion Box

-- MAIN APPLICATION
addappid(3109800)
-- Game: addappid(3109800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3109801, 1, "a06b35f7970dd39948c2856e5093d17b0f07c70c6d52d85e222dffd0b17bc688")
