-- Lua provided by RyzenAPI
-- Game: 3026780

-- MAIN APPLICATION
addappid(3026780)
-- Game: addappid(3026780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026781, 1, "0a801504e583b5f682b08adafbdbdf1efc520741353ad0966420ab858808bd26")
