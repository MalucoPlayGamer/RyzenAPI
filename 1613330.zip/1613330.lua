-- Lua provided by RyzenAPI
-- Game: 1613330

-- MAIN APPLICATION
addappid(1613330)
addappid(1613331)
addappid(1674040)
-- Game: addappid(1613330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639280,0,"c9a6d3ae59174766e414a6c47c024d6f4da9798a040f91c112cdab2b000bbe57")
