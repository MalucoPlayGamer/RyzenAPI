-- Lua provided by RyzenAPI
-- Game: Game: Rioters 2025

-- MAIN APPLICATION
addappid(1613100)
-- Game: addappid(1613100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1613101, 1, "38c677b559d22373c84886c1438cd17c4349278771551875fb9c1f29c8d90f36")
