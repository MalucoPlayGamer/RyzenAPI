-- Lua provided by RyzenAPI 
-- Game: The Uninvited: MacVenture Series
addappid(343810)
addappid(343811, 1, "4d19e5924f8b352f8e8e7574e871a09c786b84bd8831fd527ac9664c03f45da5")
addappid(343812, 1, "35881b1858a23dbaa1b06a8e24827242a52e506d2ee446931939d60cfb6faa30")
