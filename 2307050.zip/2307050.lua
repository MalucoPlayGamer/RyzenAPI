-- Lua provided by RyzenAPI
-- Game: addappid(2307050)

-- MAIN APPLICATION
addappid(2307050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307051, 1, "66fa84fcae22ab1699417d5dabb5e52abc80d4040d8e597fcb61fb8ccaaa17f8")
