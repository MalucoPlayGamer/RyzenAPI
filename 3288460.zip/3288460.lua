-- Lua provided by RyzenAPI
-- Game: ROLLING STAR

-- MAIN APPLICATION
addappid(3288460)
-- Game: addappid(3288460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288461, 1, "3d9f7674539c00e8712a9816b5ab990466dbd2526becbfe582e2380da779e9e5")
