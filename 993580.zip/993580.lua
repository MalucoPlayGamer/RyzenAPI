-- Lua provided by RyzenAPI
-- Game: Enchanted Path

-- MAIN APPLICATION
addappid(993580)
-- Game: addappid(993580)

-- MAIN APP DEPOTS / PACKAGES
addappid(993581, 1, "a4f7ea83192846f5f832795baa4bdde3e5807813ded1d06cfba7b9b7ed0db501")
addappid(1039730, 0, "8069ad5291acc0f571549c39f60fae4ead2da4f421f2e517236fda3ca8d8e2a4")
