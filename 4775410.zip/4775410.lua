-- 4775410's Lua and Manifest Created by Hubcap Manifest
-- Jeffrey Eggstein
-- Created: July 23, 2026 at 19:14:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4775410) -- Jeffrey Eggstein
-- MAIN APP DEPOTS
addappid(4775411, 1, "db28464c3659c3a17143de62391df08ac612d0b507b4158e5fe05eda82fe4ad3") -- Depot 4775411
setManifestid(4775411, "2449134438190061514", 621781891)