-- Lua provided by RyzenAPI
-- Game: Gazillionaire

-- MAIN APPLICATION
addappid(1169100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1169101, 1, "7b8b4856c6a268210df45b49d6ca7f17e4085a389b346d07c70f6647d12465e9")

