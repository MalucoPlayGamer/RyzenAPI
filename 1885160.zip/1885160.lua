-- Lua provided by RyzenAPI
-- Game: addappid(1885160)

-- MAIN APPLICATION
addappid(1885160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885161, 1, "dd5bbbd95392b3de842221659eea1f55554220a726dbbae62397c037c69eacdc")
