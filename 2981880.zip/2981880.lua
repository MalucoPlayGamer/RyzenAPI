-- Lua provided by RyzenAPI
-- Game: KADO HUNTER

-- MAIN APPLICATION
addappid(2981880)
