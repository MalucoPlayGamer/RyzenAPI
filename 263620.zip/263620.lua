-- Lua provided by RyzenAPI
-- Game: AppID 263620

-- MAIN APPLICATION
addappid(263620)

-- MAIN APP DEPOTS / PACKAGES
addappid(263621, 1, "71ad833c1c42481c6af22effdeb8426fceb601471d8922b31bd02b05718729da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
