-- Lua provided by RyzenAPI
-- Game: 263620

-- MAIN APPLICATION
addappid(263620)
-- Game: addappid(263620)

-- MAIN APP DEPOTS / PACKAGES
addappid(263621, 1, "71ad833c1c42481c6af22effdeb8426fceb601471d8922b31bd02b05718729da")
