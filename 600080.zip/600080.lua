-- Lua provided by SkyAPI 
-- Game: Unto The End
addappid(600080)
addappid(600081, 1, "33ade65a1fb367fbb37a6fd060109f04e755abdb8e1e4c7c2c4fce96a6835f5b")
addappid(1492690, 0, "7c3426a492eb71f08b612c28b8129f6d2e1b1c48acdc6fbdf924eda9824c9bf3")
