-- Lua provided by RyzenAPI
-- Game: Game: Unto The End

-- MAIN APPLICATION
addappid(600080)
-- Game: addappid(600080)

-- MAIN APP DEPOTS / PACKAGES
addappid(600081, 1, "33ade65a1fb367fbb37a6fd060109f04e755abdb8e1e4c7c2c4fce96a6835f5b")
addappid(1492690, 0, "7c3426a492eb71f08b612c28b8129f6d2e1b1c48acdc6fbdf924eda9824c9bf3")
