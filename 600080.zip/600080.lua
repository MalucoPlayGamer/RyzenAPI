-- Lua provided by RyzenAPI
-- Game: Unto The End

-- MAIN APPLICATION
addappid(600080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(600081, 1, "33ade65a1fb367fbb37a6fd060109f04e755abdb8e1e4c7c2c4fce96a6835f5b")
addappid(1492690, 0, "7c3426a492eb71f08b612c28b8129f6d2e1b1c48acdc6fbdf924eda9824c9bf3")

