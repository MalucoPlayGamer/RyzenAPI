-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(931800)

-- MAIN APP DEPOTS / PACKAGES
addappid(931800,0,"96a03619fdd4f985eab464cc115d84984a542f7592b46e269ad1cdbc7b3dc284")

