-- Lua provided by RyzenAPI
-- Game: addappid(931800)

-- MAIN APPLICATION
addappid(931800)

-- MAIN APP DEPOTS / PACKAGES
addappid(931800,0,"96a03619fdd4f985eab464cc115d84984a542f7592b46e269ad1cdbc7b3dc284")
