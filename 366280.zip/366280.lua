-- Lua provided by RyzenAPI
-- Game: addappid(366280)

-- MAIN APPLICATION
addappid(366280)

-- MAIN APP DEPOTS / PACKAGES
addappid(366281, 1, "cc4d6ca8abd1f342aeeb4ceb18e9c9a3969ce1d9adf5f0fd24d7ea269aa6dac0")
