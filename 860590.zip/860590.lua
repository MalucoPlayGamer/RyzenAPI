-- Lua provided by RyzenAPI
-- Game: MissileDancer

-- MAIN APPLICATION
addappid(860590)

-- MAIN APP DEPOTS / PACKAGES
addappid(860591,0,"6085a4271e84e322e50624213b6f3a7b225754c26886cc621be0c4b4d1a144af")

