-- Lua provided by RyzenAPI
-- Game: Game: Dragon Eclipse

-- MAIN APPLICATION
addappid(2626860)
-- Game: addappid(2626860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626861, 1, "0cb8194db7a361dfcb4539b209ac65cce9e5cfa284fb38483afeac98763419bd")
