-- Lua provided by RyzenAPI 
-- Game: Dragon Eclipse
addappid(2626860)
addappid(2626861, 1, "0cb8194db7a361dfcb4539b209ac65cce9e5cfa284fb38483afeac98763419bd")
