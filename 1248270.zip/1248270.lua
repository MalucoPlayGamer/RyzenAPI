-- Lua provided by RyzenAPI
-- Game: Game: Spellbound Spire

-- MAIN APPLICATION
addappid(1248270)
-- Game: addappid(1248270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248271, 1, "8a7f7970ac757b26b277041112191bae52ad87f58238923925b00b4ec1806861")
