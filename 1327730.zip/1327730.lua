-- Lua provided by RyzenAPI
-- Game: Game: AppID 1327730

-- MAIN APPLICATION
addappid(1327730)
-- Game: addappid(1327730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327731, 1, "cbe63cc60465322d5825e1aa0a3aa76d7a11f44a90747991c6e0723456a76142")
addappid(1327732, 1, "95870fddb3a0f16ca2da3fe3d7873835534570796d68445aeadeaab9f2edc6f5")
