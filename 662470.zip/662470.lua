-- Lua provided by RyzenAPI
-- Game: SoundLites

-- MAIN APPLICATION
addappid(662470)
addappid(813100)

-- MAIN APP DEPOTS / PACKAGES
addappid(662471, 1, "eb8370a9197412b0784b8995d26e61bed5fd13274dc95d22ceb0d80dc1eccb8a")
