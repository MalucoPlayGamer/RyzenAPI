-- Lua provided by RyzenAPI
-- Game: addappid(1684163)

-- MAIN APPLICATION
addappid(1684163)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684163,0,"9c66bca814e39417c5000bfe2a639e3fc8b6ec302a67894bce6f395cf93269d4")
