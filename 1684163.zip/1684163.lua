-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1684163)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684163,0,"9c66bca814e39417c5000bfe2a639e3fc8b6ec302a67894bce6f395cf93269d4")
