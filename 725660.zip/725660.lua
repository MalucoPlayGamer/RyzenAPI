-- Lua provided by RyzenAPI
-- Game: 725660

-- MAIN APPLICATION
addappid(725660)
-- Game: addappid(725660)

-- MAIN APP DEPOTS / PACKAGES
addappid(725661, 1, "7ff447d6279906ad218b01df06a8a53cd4d5064914760342f88b5473ecde2b07")
