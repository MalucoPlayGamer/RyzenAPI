-- Lua provided by RyzenAPI
-- Game: 祝福：第一幕 Blessing Part I

-- MAIN APPLICATION
addappid(3703870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3703871, 1, "8e403b195a70693c452f1ce1c38977eee089760199e1107586134615c008c962")

