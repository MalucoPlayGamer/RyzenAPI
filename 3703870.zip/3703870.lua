-- Lua provided by RyzenAPI 
-- Game: AppID 3703870
addappid(3703870)
addappid(3703871, 1, "8e403b195a70693c452f1ce1c38977eee089760199e1107586134615c008c962")
