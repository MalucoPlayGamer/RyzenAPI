-- Lua provided by SkyAPI 
-- Game: Mechaneer Resta's Grand Adventure
addappid(2219800)
addappid(2219801, 1, "39cee5e0ea8d55672ac1b187d1ff9516300fb6243bd4122e6ef4161a73be4a17")
addappid(2219802, 1, "a478a56dcf792a7033e09a0e6ade5b4f2cac788219664d24e82c655b4f1370e4")
addappid(2219803, 1, "9de7ff3eae808c0d32d6594d8246f86090eef5aa860c1e01590784e6806289bc")
