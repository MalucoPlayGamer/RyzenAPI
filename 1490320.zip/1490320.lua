-- Lua provided by RyzenAPI
-- Game: Game: 魂之归宿 Demo

-- MAIN APPLICATION
addappid(1490320)
-- Game: addappid(1490320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490321, 1, "7db40a647f22b47fc771a0ef733416b7dd3602e853a916d44b4205e5b7fa4478")
