-- Lua provided by RyzenAPI
-- Game: addappid(1958890)

-- MAIN APPLICATION
addappid(1958890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958891, 1, "d1113ae81ed97b4f2efade04ad3023914b391717c2ed5b965752cd59332f63d2")
