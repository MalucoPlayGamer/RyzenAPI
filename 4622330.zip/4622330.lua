-- 4622330's Lua and Manifest Created by Hubcap Manifest
-- CD Market - Music Label Sim
-- Created: July 18, 2026 at 08:03:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4622330) -- CD Market - Music Label Sim
-- MAIN APP DEPOTS
addappid(4622332, 1, "8b3e097e190804bc065a6942db34de9555197467adc7ec9f28e32c6540952a5e") -- Depot 4622332
setManifestid(4622332, "8620716116052967377", 561821193)
addappid(4622333, 1, "dcd50f90ad42fc3ad46802a2f209abf1d88464c839d18fe1ab3d2d347d3ed7dd") -- Depot 4622333
setManifestid(4622333, "8031096546224754462", 425735314)
addappid(4622336, 1, "2cd8bc382c7c5776e9ef4d59a2103115dc9e5bdf2e6e3d751452a4c119c0552f") -- Depot 4622336
setManifestid(4622336, "6822050928336982191", 388930674)