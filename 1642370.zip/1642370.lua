-- Lua provided by RyzenAPI
-- Game: AppID 1642370

-- MAIN APPLICATION
addappid(1642370)
-- Game: addappid(1642370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642371, 1, "bc6f84f3598b9a32d820493c1f95ac78178daa8d61d16b032cc778465007fc5b")
