-- Lua provided by RyzenAPI
-- Game: Chamberbound Demo

-- MAIN APPLICATION
addappid(2407380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407381, 1, "a8e9556d560d765cb2f2f7f5a859d071475a294cd59cc65667515f824cd30d47")

