-- Lua provided by RyzenAPI
-- Game: Game: SEX HELP

-- MAIN APPLICATION
addappid(2906220)
-- Game: addappid(2906220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2906221, 1, "8d94d56f8d88f436469f71ced076b243ea638838d4304efef80c5ab83d682ae1")
