-- Lua provided by RyzenAPI
-- Game: addappid(370800)

-- MAIN APPLICATION
addappid(370800)

-- MAIN APP DEPOTS / PACKAGES
addappid(370801, 1, "a84932c53f975e411202a94c52127eaebc2c696085a091efc90c751f3e0180a3")
