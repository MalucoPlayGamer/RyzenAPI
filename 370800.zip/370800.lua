-- Lua provided by RyzenAPI
-- Game: Fields of Battle

-- MAIN APPLICATION
addappid(370800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(370801, 1, "a84932c53f975e411202a94c52127eaebc2c696085a091efc90c751f3e0180a3")

