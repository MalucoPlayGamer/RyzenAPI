-- Lua provided by RyzenAPI
-- Game: Game: BrVR Backrooms Virtual Reality

-- MAIN APPLICATION
addappid(1922060)
-- Game: addappid(1922060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922061, 1, "c2178484cc234e2a5d06369a3b59ccbc23eb78ffb79ed31c4808e3931cb7f37e")
