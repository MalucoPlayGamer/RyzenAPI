-- Lua provided by RyzenAPI
-- Game: addappid(612640)

-- MAIN APPLICATION
addappid(612640)

-- MAIN APP DEPOTS / PACKAGES
addappid(612641, 1, "1bbb7961aeaf174d3efdda276ab7800140902b3bd292afa3df13e93f4feff09e")
