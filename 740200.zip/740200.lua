-- Lua provided by RyzenAPI
-- Game: The Mercury Man

-- MAIN APPLICATION
addappid(740200)

-- MAIN APP DEPOTS / PACKAGES
addappid(740201, 1, "1fd0e2d48f8ee8dd2d6548cab5e70aef91f7d166b79e1a674e5f4fa13267c0b4")

