-- Lua provided by RyzenAPI
-- Game: Game: Sephonie

-- MAIN APPLICATION
addappid(1248840)
-- Game: addappid(1248840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248841, 1, "4402afbaa121c07612f3bd356a2b22ed617c6ee4921123a7e8296008b5f533bc")
addappid(1248842, 1, "8e245a42dd83dc8bda544c7c6d575847a09ecbcffd04f475e3e62e7c79966cc6")
addappid(1248843, 1, "85070b7ad9d59478af5c59c81ba16e79499a70ea4a10bb261ec61e9caa922173")
