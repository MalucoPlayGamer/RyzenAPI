-- Lua provided by RyzenAPI 
-- Game: Fluid Engine PC Live Wallpaper
addappid(1268040)
addappid(1268041, 1, "88b4dc5bc0f0a6694662762ee160621b28dfc48a21fe2f6d18b5076026f03388")
