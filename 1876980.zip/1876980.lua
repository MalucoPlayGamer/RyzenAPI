-- Lua provided by RyzenAPI
-- Game: Game: 戛然而止的音符

-- MAIN APPLICATION
addappid(1876980)
-- Game: addappid(1876980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876981, 1, "381768bf3a691a48491cb5bbe8cef9757bb3b5543f7709b4264a18b4a60c79fa")
addappid(1876982, 1, "b2e26dea4bdbeb13ef8ccf32dc1efc1337db95ceb76a73b6788f1df1d4770c26")
