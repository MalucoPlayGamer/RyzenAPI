-- Lua provided by SkyAPI 
-- Game: Magic Time
addappid(1754380)
addappid(1754381, 1, "ca44987dc2009e5778869656755b49ac512dd44615593bfb5a0f078aaa48744e")
