-- Lua provided by RyzenAPI
-- Game: 2890910

-- MAIN APPLICATION
addappid(2890910)
-- Game: addappid(2890910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890911, 1, "81c632f75fc1e975154245eef33289c686a8d290e35765ca9eb0ea1d130449bc")
