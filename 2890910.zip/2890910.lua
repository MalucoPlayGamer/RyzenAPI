-- Lua provided by SkyAPI 
-- Game: MATRESHKA
addappid(2890910)
addappid(2890911, 1, "81c632f75fc1e975154245eef33289c686a8d290e35765ca9eb0ea1d130449bc")
