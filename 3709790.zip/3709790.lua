-- Lua provided by RyzenAPI
-- Game: Zerowake GATES

-- MAIN APPLICATION
addappid(3709790)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4261200)
