-- Lua provided by RyzenAPI
-- Game: Zerowake GATES

-- MAIN APPLICATION
addappid(3709790)
