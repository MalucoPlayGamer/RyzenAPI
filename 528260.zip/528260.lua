-- Lua provided by RyzenAPI
-- Game: 528260

-- MAIN APPLICATION
addappid(528260)
-- Game: addappid(528260)

-- MAIN APP DEPOTS / PACKAGES
addappid(528261, 1, "dac2d95f55dd6aa19bd8cf147a674e54e618de4a22996d134940124798ee3c9d")
