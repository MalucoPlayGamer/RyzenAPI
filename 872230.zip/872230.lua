-- Lua provided by RyzenAPI
-- Game: Destiny of Altrais

-- MAIN APPLICATION
addappid(872230)
addappid(872231)
addappid(872233)
addappid(872234)

-- MAIN APP DEPOTS / PACKAGES
addappid(872232,0,"1fbb1a16bb2ce0381c30cecdbd789441ee902822532aa6c339e430a0b5352aa8")
