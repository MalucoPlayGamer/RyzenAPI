-- Lua provided by RyzenAPI
-- Game: Screaming Eagles

-- MAIN APPLICATION
addappid(655660)
-- Game: addappid(655660)

-- MAIN APP DEPOTS / PACKAGES
addappid(655661, 1, "0319624a7b05f2c088ed5aeaf7b6c2c52a871d590b7bd83e26db096d6c190798")
