-- Lua provided by RyzenAPI
-- Game: Game: Lorn's Lure Demo

-- MAIN APPLICATION
addappid(1514800)
-- Game: addappid(1514800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1514801, 1, "488cdda6a11e894c68d39666957478e7409e4b0bb8c1d1c92b13ee48c5c1f58e")
