-- Lua provided by RyzenAPI
-- Game: Guano

-- MAIN APPLICATION
addappid(2779220)
-- Game: addappid(2779220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779221, 1, "2abb4386d2995ebae9aa5eb374ceddd089974c71e7fbbcc1d16f95c24666cf8b")
