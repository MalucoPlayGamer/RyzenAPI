-- Lua provided by RyzenAPI 
-- Game: Guano
addappid(2779220)
addappid(2779221, 1, "2abb4386d2995ebae9aa5eb374ceddd089974c71e7fbbcc1d16f95c24666cf8b")
