-- Lua provided by RyzenAPI
-- Game: addappid(1203570)

-- MAIN APPLICATION
addappid(1203570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203571, 1, "e4ad48823bf42fa3c3033ddb9577b01223f9b5fde125f4ff73215e5b46573c6d")
