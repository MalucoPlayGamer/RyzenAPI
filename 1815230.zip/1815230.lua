-- Lua provided by RyzenAPI
-- Game: Summum Aeterna

-- MAIN APPLICATION
addappid(1815230)
addappid(2562920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815231, 1, "755ca7a9adff76b7b15f42029d5cf61e6ae8b54dcb0e331a2094fee67b6adce8")

