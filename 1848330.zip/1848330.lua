-- Lua provided by SkyAPI 
-- Game: Clarent Saga: Chronicles
addappid(1848330)
addappid(1848331, 1, "46b19e31066ee3d0848b40e42cbe4832a52a7d2511cd14ccad9748b9a365c84b")
