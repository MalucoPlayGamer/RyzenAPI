-- Lua provided by RyzenAPI
-- Game: Game: Clarent Saga: Chronicles

-- MAIN APPLICATION
addappid(1848330)
-- Game: addappid(1848330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848331, 1, "46b19e31066ee3d0848b40e42cbe4832a52a7d2511cd14ccad9748b9a365c84b")
