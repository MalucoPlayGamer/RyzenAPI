-- Lua provided by RyzenAPI
-- Game: Finding summer

-- MAIN APPLICATION
addappid(993400)

-- MAIN APP DEPOTS / PACKAGES
addappid(993401, 1, "aed160d65759aa59caec7164a385bcf77deb4b734db2088216f6b5da4934b6a6")
