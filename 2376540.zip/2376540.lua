-- Lua provided by RyzenAPI
-- Game: The Haunted Building

-- MAIN APPLICATION
addappid(2376540)
-- Game: addappid(2376540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376541, 1, "bd190add54663cdac0163f7fa05b9d54f1ca0f87aefdf35e8f3446f19003450f")
