-- Lua provided by RyzenAPI
-- Game: addappid(2085440)

-- MAIN APPLICATION
addappid(2085440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085441, 1, "7225179c654a053bbb560a698901fd9567dc22cf51ad626efeb1e7ca01c71812")
