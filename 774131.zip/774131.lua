-- Lua provided by RyzenAPI
-- Game: Nostradamus - The Four Horsemen of the Apocalypse

-- MAIN APPLICATION
addappid(774131)
-- Game: addappid(774131)

-- MAIN APP DEPOTS / PACKAGES
addappid(774132, 1, "a85ee311f7564e14de9d0fe0fb1d11e20bb9b5f63b3023d422ca27a83c71b0c1")
