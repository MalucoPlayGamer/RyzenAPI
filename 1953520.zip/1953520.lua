-- Lua provided by RyzenAPI
-- Game: WRC Generations – The FIA WRC Official Game

-- MAIN APPLICATION
addappid(1953520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953521, 1, "22a77bd226c9a356f60e7c333c8eba478eab6a48a4f312794e5d5a3ee118651a")

