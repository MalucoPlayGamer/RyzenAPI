-- Lua provided by RyzenAPI
-- Game: WRC Generations – The FIA WRC Official Game

-- MAIN APPLICATION
addappid(1953520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1953521, 1, "22a77bd226c9a356f60e7c333c8eba478eab6a48a4f312794e5d5a3ee118651a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2074060)
addappid(2074070)
addappid(2074080)
addappid(2074090)
addappid(2074100)
