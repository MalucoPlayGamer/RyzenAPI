-- Lua provided by RyzenAPI
-- Game: İBLİS2:sorcery

-- MAIN APPLICATION
addappid(2205460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2205461, 1, "d606fef60b7b12898355e502490afa09026dc10169bbd99491a35901157bb943")

