-- Lua provided by RyzenAPI
-- Game: Game: İBLİS2:sorcery

-- MAIN APPLICATION
addappid(2205460)
-- Game: addappid(2205460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205461, 1, "d606fef60b7b12898355e502490afa09026dc10169bbd99491a35901157bb943")
