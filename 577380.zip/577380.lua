-- Lua provided by RyzenAPI
-- Game: Game: AppID 577380

-- MAIN APPLICATION
addappid(577380)
-- Game: addappid(577380)

-- MAIN APP DEPOTS / PACKAGES
addappid(577381, 1, "9b4d27c5c820e2b6c2bd9c12a72437c176050e9120d211d7b9db38bf86b5b6bd")
