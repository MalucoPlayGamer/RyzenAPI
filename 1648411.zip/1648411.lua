-- Lua provided by RyzenAPI
-- Game: addappid(1648411)

-- MAIN APPLICATION
addappid(1648411)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648411,0,"a4418efee6e51965c2a9ac92f86aba17ed3f5d73690a904188dbbb0696325420")
