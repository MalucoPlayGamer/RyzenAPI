-- Lua provided by RyzenAPI
-- Game: Game: AppID 712050

-- MAIN APPLICATION
addappid(712050)
-- Game: addappid(712050)

-- MAIN APP DEPOTS / PACKAGES
addappid(712051, 1, "512bdfc043cd7cf897f4eaa46cc2bc67bc4ca7fe65d9250363cd4c86ff0df572")
