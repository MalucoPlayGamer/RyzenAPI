-- Lua provided by RyzenAPI
-- Game: addappid(681030)

-- MAIN APPLICATION
addappid(681030)

-- MAIN APP DEPOTS / PACKAGES
addappid(681031, 1, "ecf9aacce90f67ffdcedfc9a6e58754e4e32fbaced174c2f721ed64c5eff4943")
