-- Lua provided by RyzenAPI 
-- Game: AppID 777000
addappid(777000)
addappid(777001, 1, "30b809162125014859cde87dfdb79e7e8b30a12a35a834a0acb4a31827dc3869")
