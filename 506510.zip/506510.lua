-- Lua provided by RyzenAPI
-- Game: AppID 506510

-- MAIN APPLICATION
addappid(506510)
addappid(663821)
addappid(1037860)
addappid(1037861)
-- Game: addappid(506510)

-- MAIN APP DEPOTS / PACKAGES
addappid(506511, 1, "e2a88d2934aa80973fbef42f0cd03ea47808cad7aa80b5cdc9548fc5cd45e095")
addappid(604430, 0, "1d8447fbd7ec67fc121d9056e73f86a1110d7acc8309e5ce39eaf2081c2006ea")
addappid(663820, 0, "f2232978573422db7aee8d52c7078ecf84a82cac79d95a27aedb244720e7983d")
