-- Lua provided by RyzenAPI
-- Game: AppID 2620480

-- MAIN APPLICATION
addappid(2620480)
-- Game: addappid(2620480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620481, 1, "bbe1fa794de8c8aba895dacb206249982e1d2c43626646ccff7d0a65a4d8913c")
