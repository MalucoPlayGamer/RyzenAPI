-- Lua provided by RyzenAPI
-- Game: Fast Rolling

-- MAIN APPLICATION
addappid(651050)

-- MAIN APP DEPOTS / PACKAGES
addappid(651051, 1, "df5a45e88ccb7dd49c4b544601327920587cb3002d3cd45771b50607f681c1c5")

