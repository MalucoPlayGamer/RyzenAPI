-- Lua provided by RyzenAPI
-- Game: Expeditions: Rome

-- MAIN APPLICATION
addappid(987840)
addappid(1805540)

-- MAIN APP DEPOTS / PACKAGES
addappid(987841,0,"14094ec59b39c55320b51fb59cea528683b720fd8402f74240da964dd3270f2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
