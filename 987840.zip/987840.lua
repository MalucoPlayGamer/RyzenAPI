-- Lua provided by RyzenAPI
-- Game: addappid(987840)

-- MAIN APPLICATION
addappid(987840)

-- MAIN APP DEPOTS / PACKAGES
addappid(987841, 1, "14094ec59b39c55320b51fb59cea528683b720fd8402f74240da964dd3270f2d")
