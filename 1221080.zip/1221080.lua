-- Lua provided by RyzenAPI
-- Game: Strip 4: Classmate Study

-- MAIN APPLICATION
addappid(1221080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221081, 1, "aa4eb5d30ed2e62083c8d732a8dfa4a488d232ecb5886435bfbfdb648b22dff7")
addappid(1221082, 1, "96094f62168b42b47a173a3ac979f39ed423fdbc3c4ee3052a470fe7787dd8cc")
addappid(1221083, 1, "86e876892c911d40c9e51f3e7870994071d5ae912f718debb8426af2a5559df4")

