-- Lua provided by RyzenAPI
-- Game: Ghost Marriage Matchmaking

-- MAIN APPLICATION
addappid(1683430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683431, 1, "511db6311273fd3605655da5a5c79ab89744866c0773405adaa7da5f71a97c8f")
addappid(1683432, 1, "6b6352e8ba7fd502030b643ca09bac2fac1367ff713ed6d22ee83ea07770e8f9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1915620)
