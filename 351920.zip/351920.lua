-- Lua provided by RyzenAPI
-- Game: addappid(351920)

-- MAIN APPLICATION
addappid(351920)

-- MAIN APP DEPOTS / PACKAGES
addappid(351921, 1, "c8385b229fbba084191fbd77a633411271b57ea566762c8232ce9949decab6f5")
