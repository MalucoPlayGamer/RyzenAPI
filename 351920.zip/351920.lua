-- Lua provided by RyzenAPI
-- Game: Crazy Machines 3

-- MAIN APPLICATION
addappid(351920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(351921, 1, "c8385b229fbba084191fbd77a633411271b57ea566762c8232ce9949decab6f5")

