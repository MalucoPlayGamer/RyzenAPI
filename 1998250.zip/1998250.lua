-- Lua provided by RyzenAPI
-- Game: Liminus: The Silent Guard

-- MAIN APPLICATION
addappid(1998250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998251, 1, "06bc3d264cc75c9f22586356d7ddd6660dd11a57d58932f4ed32bc2dae61edd4")
