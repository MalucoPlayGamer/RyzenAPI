-- Lua provided by RyzenAPI
-- Game: Game: Before Sunset 台山

-- MAIN APPLICATION
addappid(1980820)
-- Game: addappid(1980820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980821, 1, "897ff93d2d8f514da165e605840057af01d9fa152ad28705ac95434081765e4e")
