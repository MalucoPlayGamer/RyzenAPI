-- Lua provided by SkyAPI 
-- Game: Hunted: One Step Too Far - Reborn Edition Remastered
addappid(521450)
addappid(521451, 1, "d19530c60e4d2ab5d24c9c9aa0079de0d79b891674f398f184e10a6bc5517a74")
