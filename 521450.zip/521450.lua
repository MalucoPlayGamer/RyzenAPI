-- Lua provided by RyzenAPI
-- Game: addappid(521450)

-- MAIN APPLICATION
addappid(521450)

-- MAIN APP DEPOTS / PACKAGES
addappid(521451, 1, "d19530c60e4d2ab5d24c9c9aa0079de0d79b891674f398f184e10a6bc5517a74")
