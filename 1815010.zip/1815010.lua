-- Lua provided by RyzenAPI
-- Game: addappid(1815010)

-- MAIN APPLICATION
addappid(1815010)
addappid(1965220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815011, 1, "24854a1318f2a74b4d76f4bcdadc3c8c5e386fb19515bc115215a0e6a5e62349")
