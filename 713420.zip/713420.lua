-- Lua provided by RyzenAPI
-- Game: Crisis on the Planet of the Apes

-- MAIN APPLICATION
addappid(713420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(713421,0,"c0007eef40f2c988c9b9c89a89b8a682732944c4c5e5005b34421a945dd492a5")

