-- Lua provided by RyzenAPI
-- Game: Crisis on the Planet of the Apes

-- MAIN APPLICATION
addappid(713420)

-- MAIN APP DEPOTS / PACKAGES
addappid(713421,0,"c0007eef40f2c988c9b9c89a89b8a682732944c4c5e5005b34421a945dd492a5")

