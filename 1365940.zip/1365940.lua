-- Lua provided by RyzenAPI
-- Game: addappid(1365940)

-- MAIN APPLICATION
addappid(1365940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1365941, 1, "4700b29ab125c9ea292c785e32028863e027eb08feedd5e4c831f14c11e4d019")
