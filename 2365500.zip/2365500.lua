-- Lua provided by RyzenAPI
-- Game: 不被忘记的你

-- MAIN APPLICATION
addappid(2365500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365501, 1, "90f6c51bb8da51a60f12179b7d44d015b50a40a3a333f2d22c67bac451f23600")
