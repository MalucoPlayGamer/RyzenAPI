-- Lua provided by RyzenAPI
-- Game: Martian Law

-- MAIN APPLICATION
addappid(1135570)
-- Game: addappid(1135570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135571, 1, "617cb51bdf9edbf156925e6971a81bb63f403d0570bb0e758cf16d2784a4d0a8")
