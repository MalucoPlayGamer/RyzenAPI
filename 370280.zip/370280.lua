-- Lua provided by RyzenAPI
-- Game: Season of 12 Colors

-- MAIN APPLICATION
addappid(370280)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(370281, 1, "27089ed26388824334ff3fe631fa6fead2e68f1adb006fcb9db794091b6a6643")
addappid(370282, 1, "230ba23f95f17be56c7a6d9f3797693f9b4ddf8eab9707f79f8cb81ab188b168")
addappid(370283, 1, "d66fbcfd1378c97264ef0634226b1e9d5b9cb8c177703f17cfe54f51a4aec231")
addappid(370284, 1, "01d5371361ec66dd560e236e28b0e067b51b0dec5f4da2628c993f716f74dd81")
