-- Lua provided by RyzenAPI
-- Game: Beat Saber - Linkin Park - "One Step Closer"

-- MAIN APPLICATION
addappid(1375367)
-- Game: addappid(1375367)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375367,0,"b02846120ed0685b8c92d203a686fd49699747de3a6ddfc7975f6a9ee4d9f214")
