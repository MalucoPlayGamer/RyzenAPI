-- Lua provided by RyzenAPI
-- Game: AppID 435440

-- MAIN APPLICATION
addappid(435440)
-- Game: addappid(435440)

-- MAIN APP DEPOTS / PACKAGES
addappid(435441, 1, "468d570ad78d8e9fc0852c86ee5b48fe25d8f5d5e26a2facb5dff2c313adc6b3")
addappid(435442, 1, "7df44bb52798438e91e0b691b8acf5683ca72a93744cd1b7197311cdf851d033")
