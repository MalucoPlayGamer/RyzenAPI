-- Lua provided by RyzenAPI
-- Game: Game: Arma 3 Tools

-- MAIN APPLICATION
addappid(233800)
-- Game: addappid(233800)

-- MAIN APP DEPOTS / PACKAGES
addappid(233801, 1, "1224182c96a3b25c64e25143a403eca1f641e7853ea4383fd91bd700ea18e928")
