-- Lua provided by RyzenAPI
-- Game: To Be Headed Or Not To Be

-- MAIN APPLICATION
addappid(1165380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1165381, 1, "bfb4100a24ff441387ca6059bc9c6e2a90fe2707d885a1606880c2898031e0d7")
addappid(1165382, 1, "b80ed46dcf0ca9bb596b571d5ff0c0e4cdb7b2abc3413170971bd095fb58bd05")

