-- Lua provided by RyzenAPI
-- Game: Robot Exploration Squad

-- MAIN APPLICATION
addappid(393600)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(393601, 1, "a7d66e55be4d4dbbec5cc4e6b7d058dae6c09577f797b25eea11a0ef65fe359c")
