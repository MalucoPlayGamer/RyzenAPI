-- Lua provided by RyzenAPI
-- Game: 393600

-- MAIN APPLICATION
addappid(393600)
-- Game: addappid(393600)

-- MAIN APP DEPOTS / PACKAGES
addappid(393601, 1, "a7d66e55be4d4dbbec5cc4e6b7d058dae6c09577f797b25eea11a0ef65fe359c")
