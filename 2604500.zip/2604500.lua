-- Lua provided by RyzenAPI
-- Game: Fantastic Haven Demo

-- MAIN APPLICATION
addappid(2604500)
-- Game: addappid(2604500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604501, 1, "e674303179aa66e3d8a107057a719b8c564f515de4097a00ab730b989c862ed6")
