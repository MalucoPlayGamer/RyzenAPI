-- Lua provided by RyzenAPI
-- Game: Rescue Team: Heist of the Century

-- MAIN APPLICATION
addappid(1901560)
-- Game: addappid(1901560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901561, 1, "2610617725b78a60512b2484070ab05ac7973a827628d35f242144be46eb0486")
