-- Lua provided by RyzenAPI
-- Game: Wicked Engine

-- MAIN APPLICATION
addappid(1967460)
-- Game: addappid(1967460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967461, 1, "a1b974d9c70ab1d2ddfdf1234f74031d565b503673deaf9ba850084bbb1a37db")
