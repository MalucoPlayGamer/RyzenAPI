-- Lua provided by RyzenAPI 
-- Game: Unnamed Space Idle
addappid(2471100)
addappid(2471101, 1, "ad8817c6048c128cd5befb0138d267907a461ab173c1e2016519b5662dc57578")
addappid(2471102, 1, "51e4f8608020417c2bfa678529cd02d486138c69016f95124eb755e2350bf102")
