-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1784538)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784538,0,"782b90ed5c59bd4379857de3b10c3b429a61a04ca22253695b1c2e9273a19c73")
