-- Lua provided by RyzenAPI
-- Game: addappid(2959610)

-- MAIN APPLICATION
addappid(2959610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959611, 1, "a8a8ab2bb84a026b16b49e2cd4b28c2a6c2b59fa7840ad3e88fc04cc5f6e9c0f")
