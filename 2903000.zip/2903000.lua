-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR The Motherlode Cave and Mine Tileset

-- MAIN APPLICATION
addappid(2903000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2903000,0,"bee2af5df5f735334e7778dad62727cca79a90610182299860a53ad1a2344c37")

