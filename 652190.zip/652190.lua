-- Lua provided by RyzenAPI
-- Game: Emily Wants to Play Too

-- MAIN APPLICATION
addappid(652190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(652191, 1, "ca19d30923f020ff61c7d8df05c7badc463b63a3577aaf57206855a8eeb2d730")
addappid(652192, 1, "288fd6e93cb4e0240069e86434cd7f2c1214397e84b0f9d04dabbd2e262c4ba0")
addappid(652193, 1, "daad764185c9f713a0aead306c899a48ae50358c1111366d9dee32b9e6738649")
addappid(652194, 1, "bf2d1f530dc1c1e698a91e9df635b9e449beef89400f1bfe9e0f06df300402e7")

