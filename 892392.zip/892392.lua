-- Lua provided by RyzenAPI
-- Game: addappid(892392)

-- MAIN APPLICATION
addappid(892392)

-- MAIN APP DEPOTS / PACKAGES
addappid(892392,0,"13c3fc1f15dec088f5391a254ff6d943c7524c995c439e64a4f2ddc4026be8ab")
