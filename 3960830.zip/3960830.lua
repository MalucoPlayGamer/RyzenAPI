-- 3960830's Lua and Manifest Created by Hubcap Manifest
-- 沙威猫传奇：黑帮预制菜
-- Created: August 13, 2026 at 10:28:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3960830) -- 沙威猫传奇：黑帮预制菜
-- MAIN APP DEPOTS
addappid(3960831, 1, "3edf55032898e8e4b9355b3e50838a82454fd6d911f92af58099a05da88f8ebf") -- Depot 3960831
setManifestid(3960831, "8497625006920408334", 444462612)