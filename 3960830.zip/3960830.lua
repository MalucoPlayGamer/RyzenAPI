-- Lua provided by RyzenAPI
-- Game: Created: August 13, 2026 at 10:28:36 EDT

-- MAIN APPLICATION
addappid(3960830) -- 沙威猫传奇：黑帮预制菜

-- MAIN APP DEPOTS / PACKAGES
addappid(3960831, 1, "3edf55032898e8e4b9355b3e50838a82454fd6d911f92af58099a05da88f8ebf") -- Depot 3960831

