-- Lua provided by RyzenAPI
-- Game: 548090

-- MAIN APPLICATION
addappid(548090)
-- Game: addappid(548090)

-- MAIN APP DEPOTS / PACKAGES
addappid(548091, 1, "b5fc0aaae206fb171ea9a3db549a038ca5a69c2e3ad2cc36c923a45b8a5b605e")
