-- Lua provided by RyzenAPI
-- Game: Game: RuneScape: Dragonwilds

-- MAIN APPLICATION
addappid(1374490)
addappid(3501790)
-- Game: addappid(1374490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374491, 1, "e1a3b5ad6a0fbda32b1fceadce8be5fe365e6c98dcc654bfdef62b6aa01f48d5")
