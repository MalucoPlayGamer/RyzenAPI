-- Lua provided by RyzenAPI
-- Game: Tobari 2: Dream Ocean

-- MAIN APPLICATION
addappid(1243530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1243531, 1, "5953c142dbfbb7f2f2a923fda94bdaf3cf654077d7dbff105397f9ee55c89059")
