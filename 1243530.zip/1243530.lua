-- Lua provided by RyzenAPI 
-- Game: AppID 1243530
addappid(1243530)
addappid(1243531, 1, "5953c142dbfbb7f2f2a923fda94bdaf3cf654077d7dbff105397f9ee55c89059")
