-- Lua provided by RyzenAPI
-- Game: addappid(3345410)

-- MAIN APPLICATION
addappid(3345410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345410,0,"e74ecedeeefda54b1cd44c68e17598c1f7a182acfab6e56c6443d902c600a44b")
