-- Lua provided by RyzenAPI
-- Game: Gladiator Trainer

-- MAIN APPLICATION
addappid(527990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(527991, 1, "0dfabf1fdb4a0c72077c57da7e2c99ca1c2f3cbf1514a52b3152d4215d61dce8")
