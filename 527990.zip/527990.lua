-- Lua provided by RyzenAPI
-- Game: 527990

-- MAIN APPLICATION
addappid(527990)
-- Game: addappid(527990)

-- MAIN APP DEPOTS / PACKAGES
addappid(527991, 1, "0dfabf1fdb4a0c72077c57da7e2c99ca1c2f3cbf1514a52b3152d4215d61dce8")
