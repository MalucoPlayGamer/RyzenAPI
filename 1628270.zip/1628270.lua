-- Lua provided by RyzenAPI
-- Game: Recursive Hate - Spider Hell

-- MAIN APPLICATION
addappid(1628270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628271, 1, "21c0c89fea2784cd7311e8356a93aef6b67a5aafc38f087369419f0b826625df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
