-- Lua provided by RyzenAPI
-- Game: Game: Recursive Hate - Spider Hell

-- MAIN APPLICATION
addappid(1628270)
-- Game: addappid(1628270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628271, 1, "21c0c89fea2784cd7311e8356a93aef6b67a5aafc38f087369419f0b826625df")
