-- Lua provided by RyzenAPI 
-- Game: Heads Will Roll
addappid(1525420)
addappid(1525421, 1, "c31ce7c95937508d13a66df854d6d22d9427f51dfd25c5dd198c70096bec97b4")
