-- Lua provided by RyzenAPI
-- Game: Pesticide Not Required

-- MAIN APPLICATION
addappid(2479320)
-- Game: addappid(2479320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479321, 1, "8cb7f16f2207f1607055e20d8163a3a0810c7801b912b91dd37694cadfeba8d8")
addappid(2479323, 1, "380b6dcddb8810b5cbfff68f1f2b60954d3b5a0f966cae6f48ec441261db7d51")
