-- Lua provided by RyzenAPI
-- Game: Samurai: Ronin's Path

-- MAIN APPLICATION
addappid(1208170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208171,0,"63945313ee364c0ed6c36cfaa7710e0326d5f8cb0057f212804f03b50adb9f3f")

