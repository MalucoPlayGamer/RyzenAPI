-- Lua provided by RyzenAPI
-- Game: Handstand Hank

-- MAIN APPLICATION
addappid(3308150)
-- Game: addappid(3308150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308151, 1, "fc2c5560b2affe13535e4601451e7edad7125d12bc0be93456702ee30119b5de")
