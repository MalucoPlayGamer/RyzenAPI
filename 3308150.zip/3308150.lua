-- Lua provided by RyzenAPI
-- Game: Handstand Hank

-- MAIN APPLICATION
addappid(3308150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3308151, 1, "fc2c5560b2affe13535e4601451e7edad7125d12bc0be93456702ee30119b5de")

