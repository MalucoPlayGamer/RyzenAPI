-- Lua provided by RyzenAPI
-- Game: Solar System

-- MAIN APPLICATION
addappid(741120)

-- MAIN APP DEPOTS / PACKAGES
addappid(741121,0,"e46e71188dfee72f1df365e9adc3121d469c8f3a9b0c5d7961be596012c6c45f")

