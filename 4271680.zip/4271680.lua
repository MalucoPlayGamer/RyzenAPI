-- 4271680's Lua and Manifest Created by Hubcap Manifest
-- outpost4
-- Created: August 15, 2026 at 00:10:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4271680) -- outpost4
addtoken(4271680, "18270652608302902804")
-- MAIN APP DEPOTS
addappid(4271681, 1, "6bb2fc83d77d7c3821e8a74787475b9a1c3b69ce30b842d035dfbfebf36c36a4") -- Depot 4271681
setManifestid(4271681, "6168811468090746905", 429407437)