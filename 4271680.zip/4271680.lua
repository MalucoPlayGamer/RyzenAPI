-- Lua provided by RyzenAPI
-- Game: outpost4

-- MAIN APPLICATION
addappid(4271680) -- outpost4

-- MAIN APP DEPOTS / PACKAGES
addappid(4271681, 1, "6bb2fc83d77d7c3821e8a74787475b9a1c3b69ce30b842d035dfbfebf36c36a4") -- Depot 4271681
addtoken(4271680, "18270652608302902804")

