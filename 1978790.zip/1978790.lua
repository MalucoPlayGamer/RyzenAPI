-- Lua provided by RyzenAPI
-- Game: addappid(1978790)

-- MAIN APPLICATION
addappid(1978790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978791, 1, "10f912f0a69421040ef3d99fc42c49dea0aea8672cfc8cea38de8f3bf9ad9e96")
