-- Lua provided by RyzenAPI
-- Game: AppID 1806020

-- MAIN APPLICATION
addappid(1806020)
-- Game: addappid(1806020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806021, 1, "3646e82c01fdec9b670676bdba72c2369bd5141a8104d0424b7c9d8e4ec590f6")
