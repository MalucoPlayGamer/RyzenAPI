-- Lua provided by RyzenAPI
-- Game: HOT MILF VR

-- MAIN APPLICATION
addappid(2677720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2677721, 1, "f4751e13a871ad9e825ec018e5b56752fcbda478f5a7d1f4f9d9955dbbbb475f")

