-- Lua provided by RyzenAPI
-- Game: STSP: Super Titty Space Prison

-- MAIN APPLICATION
addappid(2408600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408601, 1, "3731cd50cd2cd8c6727c1edd29e485d04285aa23aa9d3c64dab33a63247aec87")
