-- Lua provided by RyzenAPI
-- Game: Game: Shadowlings

-- MAIN APPLICATION
addappid(883020)
-- Game: addappid(883020)

-- MAIN APP DEPOTS / PACKAGES
addappid(883021, 1, "721d2aa0a544901db6c6be471888354340e6357f23a1c4fc4632d8574adfb0fe")
addappid(898710, 0, "0e3b877e86c7d67188559d52c5096c21ef70ebac5203d133c6e067df9c25277d")
