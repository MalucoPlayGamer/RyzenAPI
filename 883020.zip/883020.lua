-- Lua provided by RyzenAPI
-- Game: Shadowlings

-- MAIN APPLICATION
addappid(883020)

-- MAIN APP DEPOTS / PACKAGES
addappid(883021, 1, "721d2aa0a544901db6c6be471888354340e6357f23a1c4fc4632d8574adfb0fe")
addappid(898710, 0, "0e3b877e86c7d67188559d52c5096c21ef70ebac5203d133c6e067df9c25277d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
