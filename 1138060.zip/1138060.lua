-- Lua provided by RyzenAPI
-- Game: Diablo_IslanD 暗黑破坏岛

-- MAIN APPLICATION
addappid(1138060)
-- Game: addappid(1138060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138061, 1, "36974292fa230a10c22aa1bd035c3d13ac0a8649266cd6d3c3b6058bd06d05ff")
