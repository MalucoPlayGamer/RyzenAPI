-- Lua provided by RyzenAPI
-- Game: Pandora: Chains of Chaos

-- MAIN APPLICATION
addappid(791260)
addappid(1373660)

-- MAIN APP DEPOTS / PACKAGES
addappid(791261,0,"4de9e971a64630dfe29a8c5d3282f6a4e8c49989206036be768f25d69f53208d")

