-- Lua provided by RyzenAPI
-- Game: Pandora: Chains of Chaos

-- MAIN APPLICATION
addappid(791260)
addappid(1373660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(791261,0,"4de9e971a64630dfe29a8c5d3282f6a4e8c49989206036be768f25d69f53208d")

