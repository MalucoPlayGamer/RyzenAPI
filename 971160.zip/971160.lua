-- Lua provided by RyzenAPI
-- Game: Möbius Front '83

-- MAIN APPLICATION
addappid(971160)

-- MAIN APP DEPOTS / PACKAGES
addappid(971161, 1, "76a063ba21a233fb75071ff4da4a20246d0af028c27baad94d0d13cc6b1041c8")
addappid(971162, 1, "d5ed2f95e3bb0f6acc0563f47481694973911e433d840f321a77e07f34626782")
addappid(971163, 1, "30525138974368c109040f5a5edfb7c71691c9fd12da3d0b6d1ea0769d27b575")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
