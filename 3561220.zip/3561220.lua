-- 3561220's Lua and Manifest Created by Hubcap Manifest
-- Pass the Fear
-- Created: July 27, 2026 at 07:27:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3561220) -- Pass the Fear
-- MAIN APP DEPOTS
addappid(3561221, 1, "4f52357a78cf16a8e4fadac5cc8e76f5738421d302882c03123057cf8f286cc3") -- Depot 3561221
setManifestid(3561221, "7778710828258947998", 3503642990)