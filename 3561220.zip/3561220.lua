-- 3561220's Lua and Manifest Created by Hubcap Manifest
-- Pass the Fear
-- Created: July 23, 2026 at 02:12:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3561220) -- Pass the Fear
-- MAIN APP DEPOTS
addappid(3561221, 1, "4f52357a78cf16a8e4fadac5cc8e76f5738421d302882c03123057cf8f286cc3") -- Depot 3561221
setManifestid(3561221, "8131525274224226668", 3496407030)