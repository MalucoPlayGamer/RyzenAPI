-- Lua provided by RyzenAPI
-- Game: Pass the Fear

-- MAIN APPLICATION
addappid(3561220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561221,0,"4f52357a78cf16a8e4fadac5cc8e76f5738421d302882c03123057cf8f286cc3")

