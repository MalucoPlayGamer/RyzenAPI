-- Lua provided by RyzenAPI
-- Game: Butterflies

-- MAIN APPLICATION
addappid(2420050)
addappid(2420060)
addappid(2420061)
addappid(2420062)

-- MAIN APP DEPOTS / PACKAGES
addappid(2420051, 1, "59cf64a4f3a1432e3ad0f596583812db94f1f4f5a1f7e881b046a9871ad35623")
addappid(2420052, 1, "45cba6f777e5ba5032a6dcb1518fb25344513d675e79caf2918067adbedf50ef")
addappid(2420053, 1, "5c917021eebbeab971bbf05a5166916626e64a2d553a7439e06dae624661756f")

