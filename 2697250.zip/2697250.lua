-- Lua provided by RyzenAPI
-- Game: Gran Carismo

-- MAIN APPLICATION
addappid(2697250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697251, 1, "fbe4c7081c16ed20711e8ef013c31f220a49f690b006844c25dc500d9ff74acc")
