-- Lua provided by RyzenAPI
-- Game: Game: DLC Scenario Pack: Hana and Itsuki's Epilogue 1

-- MAIN APPLICATION
addappid(2697130)
-- Game: addappid(2697130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697131, 1, "3041cf28211bb3e2a3325db5de211135bb96046a4926efb8474ac239e11877c6")
