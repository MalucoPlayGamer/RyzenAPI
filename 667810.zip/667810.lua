-- Lua provided by RyzenAPI
-- Game: AppID 667810

-- MAIN APPLICATION
addappid(667810)

-- MAIN APP DEPOTS / PACKAGES
addappid(667811, 1, "d2aff157379e71817763f92fcbc6f8e0748bc874347b97db4c8ceb9b0ad70c81")
addappid(667812, 1, "342c6ba96f236e94a84c8a2234c7584ba30406929fc1f87b0a143881187986ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(717650)
