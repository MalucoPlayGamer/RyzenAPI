-- Lua provided by RyzenAPI
-- Game: 696840

-- MAIN APPLICATION
addappid(696840)
-- Game: addappid(696840)

-- MAIN APP DEPOTS / PACKAGES
addappid(696841, 1, "c553399004149b220ce7a05cc6bb9397f10f52ce9db61a5bf284874314f4274c")
