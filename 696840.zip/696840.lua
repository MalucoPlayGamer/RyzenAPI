-- Lua provided by RyzenAPI
-- Game: AppID 696840

-- MAIN APPLICATION
addappid(696840)

-- MAIN APP DEPOTS / PACKAGES
addappid(696841, 1, "c553399004149b220ce7a05cc6bb9397f10f52ce9db61a5bf284874314f4274c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
