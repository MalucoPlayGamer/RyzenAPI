-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - 90s Retro Sounds 2 - Battle

-- MAIN APPLICATION
addappid(2447271)
-- Game: addappid(2447271)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447271,0,"4f89751bfa8f906f5e82c74db0b297fb03aef44e7817df1f1cd02b882c0692e3")
