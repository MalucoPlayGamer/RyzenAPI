-- Lua provided by RyzenAPI
-- Game: addappid(2447271)

-- MAIN APPLICATION
addappid(2447271)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447271,0,"4f89751bfa8f906f5e82c74db0b297fb03aef44e7817df1f1cd02b882c0692e3")
