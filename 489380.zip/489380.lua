-- Lua provided by RyzenAPI
-- Game: QuiVr

-- MAIN APPLICATION
addappid(489380)

-- MAIN APP DEPOTS / PACKAGES
addappid(489381, 1, "921012bfe7d67b63ea1a8c4b4773efab9a0b0fcb023ae1762220d75e38c265ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
