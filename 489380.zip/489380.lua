-- Lua provided by SkyAPI 
-- Game: QuiVr
addappid(489380)
addappid(489381, 1, "921012bfe7d67b63ea1a8c4b4773efab9a0b0fcb023ae1762220d75e38c265ee")
