-- Lua provided by RyzenAPI
-- Game: Game: QuiVr

-- MAIN APPLICATION
addappid(489380)
-- Game: addappid(489380)

-- MAIN APP DEPOTS / PACKAGES
addappid(489381, 1, "921012bfe7d67b63ea1a8c4b4773efab9a0b0fcb023ae1762220d75e38c265ee")
