-- Lua provided by RyzenAPI
-- Game: Game: Cappasity Demo

-- MAIN APPLICATION
addappid(982830)
-- Game: addappid(982830)

-- MAIN APP DEPOTS / PACKAGES
addappid(982831, 1, "ce3d99e556f3be39e9b53daabe147d481f1186d64c951c530b121dd2891cd788")
