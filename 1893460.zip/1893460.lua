-- Lua provided by RyzenAPI
-- Game: Pick The Lock

-- MAIN APPLICATION
addappid(1893460)
-- Game: addappid(1893460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893461, 1, "7484f74201d829376eb3f582105de275cded5740f2ce49857289d56a85370d60")
