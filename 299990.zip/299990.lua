-- Lua provided by RyzenAPI
-- Game: 299990

-- MAIN APPLICATION
addappid(299990)
-- Game: addappid(299990)

-- MAIN APP DEPOTS / PACKAGES
addappid(299991, 1, "ba239dbe4a1ec3437fccc321db6881dc9b4ca8b12ecd39342b127927c69700ad")
