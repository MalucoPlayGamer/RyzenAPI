-- Lua provided by RyzenAPI
-- Game: AppID 230030

-- MAIN APPLICATION
addappid(230030)
-- Game: addappid(230030)

-- MAIN APP DEPOTS / PACKAGES
addappid(230031, 1, "1b55afbbf9b500ac83d6475a936b628d5dba1272776c6578d1857a9c1e9f7810")
