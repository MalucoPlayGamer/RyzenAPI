-- Lua provided by RyzenAPI
-- Game: SONG OF HORROR - Episode 4

-- MAIN APPLICATION
addappid(1158110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158110,0,"10e306a0051ec5d25d4cad10a9d396949dacd2350b2f1a338cf82ba5ff55f8fa")

