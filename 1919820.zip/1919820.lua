-- Lua provided by RyzenAPI
-- Game: addappid(1919820)

-- MAIN APPLICATION
addappid(1919820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919820,0,"d89f22e15db50b1d725dcd6b06cb3d90ab0e11bcd446bb0d3a83184f8806dfd9")
