-- Lua provided by RyzenAPI
-- Game: 1001 TVs: Screen Mirroring

-- MAIN APPLICATION
addappid(2874180)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(2874181, 1, "d2d0b62e2c1831ef06eb53f7560242215b0944f373a5fd45ce18d9346961a5a1")

