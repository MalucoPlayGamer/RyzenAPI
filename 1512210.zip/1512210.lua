-- Lua provided by RyzenAPI
-- Game: Ultra App Kit

-- MAIN APPLICATION
addappid(1512210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512211, 1, "9a5f2e217cca4d0607f2e4e2b1197eb0b69ecb78d17232d79f71be5c6db8dd54")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
