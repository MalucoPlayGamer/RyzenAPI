-- Lua provided by RyzenAPI
-- Game: Ultra App Kit

-- MAIN APPLICATION
addappid(1512210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512211, 1, "9a5f2e217cca4d0607f2e4e2b1197eb0b69ecb78d17232d79f71be5c6db8dd54")
