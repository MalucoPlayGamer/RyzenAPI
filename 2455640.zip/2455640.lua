-- Lua provided by RyzenAPI
-- Game: Romancing SaGa 2: Revenge of the Seven

-- MAIN APPLICATION
addappid(2455640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2455641, 1, "e203486d7b9a34f0df0728458d20a368e5abc9a4a9bcfcf7d3987af942a8be9c")
