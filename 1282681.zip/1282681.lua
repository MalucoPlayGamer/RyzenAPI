-- Lua provided by RyzenAPI
-- Game: To the Edge of the Sky: Through His Eyes - Four

-- MAIN APPLICATION
addappid(1282681)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282681,0,"f2aa43ebcb4fb20f547725c3172bf4e00ac4a2483f3aa63d2fda2763854523e9")

