-- Lua provided by RyzenAPI 
-- Game: Full Void Soundtrack
addappid(2682290)
addappid(2682291, 1, "3c42c82c307e5c7642b198f1c2ae1720c5cc9761370263c8bd73681dbee08a3b")
addappid(2682292, 1, "b7661b66a693d086d6c838373cfd2cc88bac9d8124206f268885786e9c34d99b")
