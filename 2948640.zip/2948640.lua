-- Lua provided by RyzenAPI
-- Game: Game: The Jackbox Survey Scramble

-- MAIN APPLICATION
addappid(2948640)
-- Game: addappid(2948640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2948641, 1, "495e7db8dde45454e229ba6eeece64a25a245319f778e013ce32538c1ff19eb9")
addappid(2948642, 1, "2404b95d2f09944aa45977a18fb2d88897aab19dfb63bcde394cd59861efae9a")
