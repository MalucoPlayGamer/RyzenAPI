-- Lua provided by RyzenAPI
-- Game: The Jackbox Survey Scramble

-- MAIN APPLICATION
addappid(2948640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2948641, 1, "495e7db8dde45454e229ba6eeece64a25a245319f778e013ce32538c1ff19eb9")
addappid(2948642, 1, "2404b95d2f09944aa45977a18fb2d88897aab19dfb63bcde394cd59861efae9a")

