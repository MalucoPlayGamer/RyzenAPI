-- Lua provided by SkyAPI 
-- Game: AppID 981260
addappid(981260)
addappid(981261, 1, "391e17c05251750fae2be1bfb9ef9d1dc530b8d90fe482bf7d80d645bdf4818d")
