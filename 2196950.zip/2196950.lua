-- Lua provided by RyzenAPI
-- Game: Load Slinging VR Training

-- MAIN APPLICATION
addappid(2196950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196951, 1, "e8002ca0ef94d90a2825399f2a956e9919e5a65310665c26c2ee7c1d554b5e94")

