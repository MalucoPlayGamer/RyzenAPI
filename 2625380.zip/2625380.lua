-- Lua provided by RyzenAPI
-- Game: Draft Day Sports: Pro Basketball 2024

-- MAIN APPLICATION
addappid(2625380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625381, 1, "ada79505e16fbfa4c2e43e3d5f7a7a750c350485210a1e325110e85037ccc97b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
