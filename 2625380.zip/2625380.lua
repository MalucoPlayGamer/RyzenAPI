-- Lua provided by RyzenAPI
-- Game: addappid(2625380)

-- MAIN APPLICATION
addappid(2625380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2625381, 1, "ada79505e16fbfa4c2e43e3d5f7a7a750c350485210a1e325110e85037ccc97b")
