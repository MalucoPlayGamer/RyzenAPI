-- Lua provided by RyzenAPI
-- Game: Howl

-- MAIN APPLICATION
addappid(2172180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172181, 1, "c07787cf38d303ca6103f21138423db950f7c88dc2977c2faa2db12d303db853")
