-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Sen no Kiseki IV -THE END OF SAGA-

-- MAIN APPLICATION
addappid(1457510)
addappid(1828860)
addappid(1828861)
addappid(1828862)
addappid(1828863)
addappid(1828864)
addappid(3464270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457511,0,"7db3a601981abe153c26288dd1f7c3417c542e506086b2041e85f9d6ec6f5bfd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
