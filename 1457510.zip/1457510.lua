-- Lua provided by RyzenAPI
-- Game: 1457510

-- MAIN APPLICATION
addappid(1457510)
-- Game: addappid(1457510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457511, 1, "7db3a601981abe153c26288dd1f7c3417c542e506086b2041e85f9d6ec6f5bfd")
