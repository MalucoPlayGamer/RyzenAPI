-- Lua provided by RyzenAPI
-- Game: addappid(388500)

-- MAIN APPLICATION
addappid(388500)

-- MAIN APP DEPOTS / PACKAGES
addappid(388502,0,"aa8847912829f7b7e8db69ba70ad9ae4b23fa6690020f33a09531f06294e91c8")
