-- Lua provided by RyzenAPI
-- Game: Worms W.M.D

-- MAIN APPLICATION
addappid(327030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(327031, 1, "70ead596b9b883ebaf42e583c136985d850063cd7f80ecc678dc2d0224424fdb")
addappid(327032, 1, "197164a6fc82190290ac30e69e741bf14d54b398e853544e0559977c03abbbd4")
addappid(327033, 1, "25ad6e69b23d4d5690f92f6884485c81a860446e5ebb9ac548a88f7ad5f04c3b")
addappid(327035, 1, "72fb636fa7486b169e2dce975f6df08daa56b6756d5e6b34dc2f74e42c5a4418")
addappid(497140, 0, "d9c270cb923a5322538fb2d58e249db801d32f988940d82e665a1fcfb5516b8f")

