-- Lua provided by RyzenAPI
-- Game: AppID 543850

-- MAIN APPLICATION
addappid(543850)

-- MAIN APP DEPOTS / PACKAGES
addappid(543851, 1, "9b98bda5ecb4f8fd4623130c1ccf1a9683b054d82fe97b63849adec544570ffd")
