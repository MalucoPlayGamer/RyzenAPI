-- Lua provided by RyzenAPI
-- Game: Fears to Fathom - Ironbark Lookout

-- MAIN APPLICATION
addappid(2506160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506161, 1, "21ca9f80277ec51e1e063ad48d39eb22f37081c9034ab900704dde1986b4806e")
