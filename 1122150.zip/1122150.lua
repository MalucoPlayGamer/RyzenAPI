-- Lua provided by RyzenAPI
-- Game: AppID 1122150

-- MAIN APPLICATION
addappid(1122150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122151, 1, "61f9ac8e1d31679aedbef4793e06d2d809ecd2f95f2fe147ff0dfc96fbc95a72")

