-- Lua provided by RyzenAPI
-- Game: Winds Of Trade

-- MAIN APPLICATION
addappid(576260)

-- MAIN APP DEPOTS / PACKAGES
addappid(576261, 1, "e2883eaadd5676c6b31b253151a55bc399a1d84e62f7a0fafffe760a42270149")
addappid(576262, 1, "e0aae2327067f94c3735ee245175a1e12505a2e2ac3f54eaec1449a131862904")

