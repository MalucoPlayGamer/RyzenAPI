-- Lua provided by RyzenAPI
-- Game: AppID 563130

-- MAIN APPLICATION
addappid(563130)
-- Game: addappid(563130)

-- MAIN APP DEPOTS / PACKAGES
addappid(563131, 1, "f7e1cbf1acb6e424ea6fab0f0750311794a87e83f4d252e30fce3e95ef2d971f")
