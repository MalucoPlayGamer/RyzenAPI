-- Lua provided by RyzenAPI
-- Game: addappid(1755650)

-- MAIN APPLICATION
addappid(1755650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755651, 1, "6801686d3450d7d90c71d4f2d5ccb650c8f11c34ce0f2569f94bba7a9ffd9209")
