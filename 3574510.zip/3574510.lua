-- Lua provided by RyzenAPI
-- Game: Serre

-- MAIN APPLICATION
addappid(3574510)
addappid(3585980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3574511,0,"b4b619770a4d900df4a7b27fb586df40d8b6c5a8eac800ab804e5b8c133668d9")

