-- Lua provided by RyzenAPI
-- Game: addappid(3111080)

-- MAIN APPLICATION
addappid(3111080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3111081, 1, "8411918c449ce8996aae76cde60594f80c341a830643f4318d416cc19cec09dc")
