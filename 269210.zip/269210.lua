-- Lua provided by RyzenAPI
-- Game: Game: Hero Siege

-- MAIN APPLICATION
addappid(269210)
-- Game: addappid(269210)

-- MAIN APP DEPOTS / PACKAGES
addappid(269211, 1, "17c86e12a62175327e05b395fc5fb45ea6447ac445c5bea0b99e733b48520551")
addappid(269213, 1, "650c7455955440db5870deb3bbd0f004860db55b91d08669722add8b9bd1cdcc")
