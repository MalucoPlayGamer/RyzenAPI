-- Lua provided by SkyAPI 
-- Game: Who dies first
addappid(1702740)
addappid(1702741, 1, "dc97c010e75f9453f056751318b6ed52ee3b49c40b7af25b929075f8655de4d3")
