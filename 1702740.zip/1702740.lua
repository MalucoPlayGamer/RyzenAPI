-- Lua provided by RyzenAPI
-- Game: addappid(1702740)

-- MAIN APPLICATION
addappid(1702740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702741, 1, "dc97c010e75f9453f056751318b6ed52ee3b49c40b7af25b929075f8655de4d3")
