-- Lua provided by RyzenAPI
-- Game: addappid(380580)

-- MAIN APPLICATION
addappid(380580)

-- MAIN APP DEPOTS / PACKAGES
addappid(380581, 1, "6f205f9fd9c89edf8c0c0ed7b64a66a06f80575474646e9b68a37af038371cf3")
