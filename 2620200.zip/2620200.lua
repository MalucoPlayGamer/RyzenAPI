-- Lua provided by RyzenAPI
-- Game: addappid(2620200)

-- MAIN APPLICATION
addappid(2620200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620201, 1, "b627ca567cd9ced48ae51047e7be6de10ff7aa240df2cbc10b9eedcb32642fad")
