-- Lua provided by RyzenAPI
-- Game: addappid(3179550)

-- MAIN APPLICATION
addappid(3179550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179551, 1, "68bb375bbe5020b5b7146980513f4d480a53adfa50b41854f26b71d615bc65cd")
addappid(3179552, 1, "2cf474db7839d6becd15c0360cdee10d5b9fd73ebd6809d0293b29abec062860")
