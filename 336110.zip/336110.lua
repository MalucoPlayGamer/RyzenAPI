-- Lua provided by RyzenAPI 
-- Game: Bloody Streets
addappid(336110)
addappid(336111, 1, "8d69888bb921871656f053c6790c7f2149fb5b23ded88ecc585e251f238631b2")
addappid(354300, 0, "6e8d94944d7c075aeb15bb4c34976f0f5451f638730b58c7785f0efc489c7e88")
