-- Lua provided by RyzenAPI
-- Game: Bloody Streets

-- MAIN APPLICATION
addappid(336110)

-- MAIN APP DEPOTS / PACKAGES
addappid(336111, 1, "8d69888bb921871656f053c6790c7f2149fb5b23ded88ecc585e251f238631b2")
addappid(354300, 0, "6e8d94944d7c075aeb15bb4c34976f0f5451f638730b58c7785f0efc489c7e88")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
