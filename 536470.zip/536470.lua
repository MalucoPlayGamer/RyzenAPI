-- Lua provided by RyzenAPI
-- Game: Magnetized

-- MAIN APPLICATION
addappid(536470)

-- MAIN APP DEPOTS / PACKAGES
addappid(536471, 1, "d1f0892606c24cccc0e7358b2147c8dfc98763fcc0145acd09361aed6e4c0d50")

