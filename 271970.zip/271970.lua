-- Lua provided by RyzenAPI
-- Game: Game: AppID 271970

-- MAIN APPLICATION
addappid(271970)
-- Game: addappid(271970)

-- MAIN APP DEPOTS / PACKAGES
addappid(271971, 1, "694ac2e9441be60389d55a7dd92fcdc8e23f5fc35efe29478e284915c96c2bea")
