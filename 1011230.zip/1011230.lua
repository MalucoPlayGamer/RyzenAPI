-- Lua provided by RyzenAPI
-- Game: AppID 1011230

-- MAIN APPLICATION
addappid(1011230)
-- Game: addappid(1011230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011231, 1, "4c777f2478b8d82a4d327d6e44b088c9129d61e5620762ea75afbc4b1d979a86")
