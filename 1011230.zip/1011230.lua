-- Lua provided by SkyAPI 
-- Game: AppID 1011230
addappid(1011230)
addappid(1011231, 1, "4c777f2478b8d82a4d327d6e44b088c9129d61e5620762ea75afbc4b1d979a86")
