-- Lua provided by RyzenAPI
-- Game: Salthe

-- MAIN APPLICATION
addappid(1357840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357841, 1, "10a94d6b312d17d5d7dfb6f7e6ee35f77b4d4e2543407b8d97035a0d31186c74")
addappid(1357842, 1, "e2aed88e7411507c8cf394c3cac48d1bbc5a7d8aee452206f3402481b10f517e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
