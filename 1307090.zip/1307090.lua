-- Lua provided by RyzenAPI
-- Game: Game: Barro Racing

-- MAIN APPLICATION
addappid(1307090)
-- Game: addappid(1307090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307091, 1, "e876f1f5364dc2d61be952f24894f5722fd87e50b08a9dc22202299f0bdd0aeb")
addappid(1307092, 1, "1dd97b9e8840ef005d93ae70b0d9483d674c1c33718c5e954587df6c7a2fb4f8")
