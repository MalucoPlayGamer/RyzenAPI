-- Lua provided by RyzenAPI
-- Game: Game: Ember Strike

-- MAIN APPLICATION
addappid(374670)
-- Game: addappid(374670)

-- MAIN APP DEPOTS / PACKAGES
addappid(374671, 1, "b3f9b058dd735aec5931e69c18db6337c9724a7a32dd1253b20c34eb722de2a9")
