-- Lua provided by SkyAPI 
-- Game: Ember Strike
addappid(374670)
addappid(374671, 1, "b3f9b058dd735aec5931e69c18db6337c9724a7a32dd1253b20c34eb722de2a9")
