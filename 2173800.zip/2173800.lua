-- Lua provided by SkyAPI 
-- Game: Projekt: Passion - Season 1
addappid(2173800)
addappid(2173801, 1, "5e2bd10d255b09afeab30becbaa1ae93d8f3eb5b2f6696de8e91356c029fc65f")
addappid(2447610, 0, "e48ffd8e3cc28345310847e93e7749d97b5eda4838608ed7a2d7904c382021c4")
