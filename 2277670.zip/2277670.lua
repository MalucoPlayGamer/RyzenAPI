-- Lua provided by RyzenAPI
-- Game: Hank: Straightjacket

-- MAIN APPLICATION
addappid(2277670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277671, 1, "6257ac81201952a0772ef8f8421a7ba89ff392f8da933959c9d47823352fc99d")

