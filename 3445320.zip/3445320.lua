-- Lua provided by RyzenAPI
-- Game: AppID 3445320

-- MAIN APPLICATION
addappid(3445320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445321, 1, "51cf33f2344f7b2756b9cab33bd55e7e45dc7a16c3dd84beca7997c66e5c0f7e")

