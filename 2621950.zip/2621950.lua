-- Lua provided by RyzenAPI
-- Game: Reaplaced

-- MAIN APPLICATION
addappid(2621950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2621951, 1, "02f5a242405d80d8aad16ba34d55bd1d75bd3f813174622b334ac11d1289e8da")

