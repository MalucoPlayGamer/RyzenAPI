-- Lua provided by RyzenAPI
-- Game: Anodyne 2: Return to Dust

-- MAIN APPLICATION
addappid(877810)

-- MAIN APP DEPOTS / PACKAGES
addappid(877811, 1, "ad1cc51a1dab7b37c9289993819098567d9154ab66b731c474f284d16f346beb")
addappid(877812, 1, "e73afa1f991fab5281bcccf45c72b086d418d4dde3e80ff38deeefb21824d54a")
addappid(877813, 1, "5b8cf6ef94dbddd10d75a0404d1c22064a5e4175d31708114f752fe1840007b8")

