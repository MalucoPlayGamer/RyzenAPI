-- Lua provided by RyzenAPI
-- Game: Neon Fantasy: Dogs

-- MAIN APPLICATION
addappid(2637100)
-- Game: addappid(2637100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2637101, 1, "4d766c1a88c6ee22366b3a1860189badc94b1f990039a54b1562c275e2589c44")
