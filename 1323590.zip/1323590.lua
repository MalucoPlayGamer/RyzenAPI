-- Lua provided by SkyAPI 
-- Game: AppID 1323590
addappid(1323590)
addappid(1323591, 1, "04b34baa55aed8f6056f41df943423120160150ee81303a21a9f5d591fb6aa65")
