-- Lua provided by RyzenAPI
-- Game: Game: AppID 1323590

-- MAIN APPLICATION
addappid(1323590)
-- Game: addappid(1323590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323591, 1, "04b34baa55aed8f6056f41df943423120160150ee81303a21a9f5d591fb6aa65")
