-- Lua provided by RyzenAPI
-- Game: 365960

-- MAIN APPLICATION
addappid(365960)
-- Game: addappid(365960)

-- MAIN APP DEPOTS / PACKAGES
addappid(365961, 1, "e1341e8323a5e1b100e4ab63a6b513d40d8e1bb511bae72cf3297dcf63fed844")
