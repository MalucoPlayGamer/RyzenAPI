-- Lua provided by RyzenAPI
-- Game: rFactor 2

-- MAIN APPLICATION
addappid(365960)

-- MAIN APP DEPOTS / PACKAGES
addappid(365961, 1, "e1341e8323a5e1b100e4ab63a6b513d40d8e1bb511bae72cf3297dcf63fed844")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(377640)
addappid(377641)
