-- Lua provided by RyzenAPI
-- Game: 534300

-- MAIN APPLICATION
addappid(534300)
-- Game: addappid(534300)

-- MAIN APP DEPOTS / PACKAGES
addappid(534301, 1, "bfb68a4ff3428dd5b2ace1ae922ce3ecad5bf90f538029076e4338ef9f403117")
