-- Lua provided by RyzenAPI
-- Game: AppID 534300

-- MAIN APPLICATION
addappid(534300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(534301, 1, "bfb68a4ff3428dd5b2ace1ae922ce3ecad5bf90f538029076e4338ef9f403117")

