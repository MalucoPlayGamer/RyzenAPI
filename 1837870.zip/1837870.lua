-- Lua provided by RyzenAPI
-- Game: Downroll

-- MAIN APPLICATION
addappid(1837870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1837871, 1, "1c84d72d51f5c5e77ea013a85ad77a9389f50deb5cb396fc574a9c1e9db3f1c5")

