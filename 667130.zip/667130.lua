-- Lua provided by RyzenAPI
-- Game: Clumsy Fred

-- MAIN APPLICATION
addappid(667130)

-- MAIN APP DEPOTS / PACKAGES
addappid(667131, 1, "68eb3ab43ea4e1feda695a4b1166823d4019b64a2d9aca60ca7fdb749e880569")

