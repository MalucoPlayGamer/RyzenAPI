-- Lua provided by RyzenAPI 
-- Game: AppID 621080
addappid(621080)
addappid(621081, 1, "eeb59c892d7e3515af5cad15890d47fea4b20a76283c118fa4f1792433e70fbb")
