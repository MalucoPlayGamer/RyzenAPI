-- Lua provided by RyzenAPI
-- Game: Persian Nights: Sands of Wonders

-- MAIN APPLICATION
addappid(621080)

-- MAIN APP DEPOTS / PACKAGES
addappid(621081, 1, "eeb59c892d7e3515af5cad15890d47fea4b20a76283c118fa4f1792433e70fbb")

