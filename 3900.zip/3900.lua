-- Lua provided by RyzenAPI
-- Game: Sid Meier's Civilization® IV

-- MAIN APPLICATION
addappid(3900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3901, 1, "b04d6ae9bab33ef0fe6da033f818cabf770888946798a688643e628eded8c316")
