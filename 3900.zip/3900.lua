-- Lua provided by RyzenAPI
-- Game: 3900

-- MAIN APPLICATION
addappid(3900)
-- Game: addappid(3900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3901, 1, "b04d6ae9bab33ef0fe6da033f818cabf770888946798a688643e628eded8c316")
