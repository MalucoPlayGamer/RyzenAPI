-- Lua provided by RyzenAPI
-- Game: NBA 2K19

-- MAIN APPLICATION
addappid(841370)
addappid(863680)
addappid(863681)
addappid(927700)

-- MAIN APP DEPOTS / PACKAGES
addappid(841371,0,"16fb529c90bf0ee75500debcf16fb1b67eb02500cc0261675c5e3ecadc1bc5d8")

