-- Lua provided by RyzenAPI
-- Game: NBA 2K19

-- MAIN APPLICATION
addappid(841370)
addappid(863680)
addappid(863681)
addappid(927700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(841371,0,"16fb529c90bf0ee75500debcf16fb1b67eb02500cc0261675c5e3ecadc1bc5d8")

