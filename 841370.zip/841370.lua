-- Lua provided by RyzenAPI
-- Game: AppID 841370

-- MAIN APPLICATION
addappid(841370)
-- Game: addappid(841370)

-- MAIN APP DEPOTS / PACKAGES
addappid(841371, 1, "16fb529c90bf0ee75500debcf16fb1b67eb02500cc0261675c5e3ecadc1bc5d8")
