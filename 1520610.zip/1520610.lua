-- Lua provided by RyzenAPI
-- Game: BlackJack Math Cross Numbers

-- MAIN APPLICATION
addappid(1520610)
-- Game: addappid(1520610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520611, 1, "7481bd393d65e5fedff61ac9c34eb180772e8b551c086cc581672878b8dcee25")
