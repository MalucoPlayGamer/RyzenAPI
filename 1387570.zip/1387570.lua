-- Lua provided by SkyAPI 
-- Game: Orbitect
addappid(1387570)
addappid(1387571, 1, "4893fa2eb84cddf735794d7b2cc31d69af57631f3fbca7cca81898c57d1e6311")
