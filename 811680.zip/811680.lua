-- Lua provided by RyzenAPI
-- Game: The Old Kazulka

-- MAIN APPLICATION
addappid(811680)

-- MAIN APP DEPOTS / PACKAGES
addappid(811681, 1, "a1ae57234d796784472f7938a9c00cf04721da437f22f889675d060f7c8fa760")
