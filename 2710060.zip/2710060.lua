-- Lua provided by RyzenAPI 
-- Game: 西门立志传
addappid(2710060)
addappid(2710061, 1, "b986017bd174ed2da3a8d412cbfee411ea62d52b9ac5daf1522b00f371e2cfaf")
