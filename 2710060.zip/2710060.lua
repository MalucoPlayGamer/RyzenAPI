-- Lua provided by RyzenAPI
-- Game: 2710060

-- MAIN APPLICATION
addappid(2710060)
-- Game: addappid(2710060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710061, 1, "b986017bd174ed2da3a8d412cbfee411ea62d52b9ac5daf1522b00f371e2cfaf")
