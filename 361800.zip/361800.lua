-- Lua provided by SkyAPI 
-- Game: AppID 361800
addappid(361800)
addappid(361801, 1, "f2f416813ff3ff5808d8bbcf56d018e52628de0d9f1162e8c57b8bbd2a266a63")
addappid(361802, 1, "55a45897e8ffba930802f83d92dd4c8462677b30c429df4e1098bc2152913d09")
