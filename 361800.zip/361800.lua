-- Lua provided by RyzenAPI
-- Game: Tree of Life

-- MAIN APPLICATION
addappid(361800)
addappid(368960)
addappid(368961)
addappid(677930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(361801, 1, "f2f416813ff3ff5808d8bbcf56d018e52628de0d9f1162e8c57b8bbd2a266a63")
addappid(361802, 1, "55a45897e8ffba930802f83d92dd4c8462677b30c429df4e1098bc2152913d09")

