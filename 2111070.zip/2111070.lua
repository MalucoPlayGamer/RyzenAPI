-- Lua provided by RyzenAPI
-- Game: 荒土之上 On Wasteland

-- MAIN APPLICATION
addappid(2111070)
-- Game: addappid(2111070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111071, 1, "7c74189e0a6de59e7ec95b070597c3d0e580f298d40b4c9fb319dcef4cfcbda6")
