-- Lua provided by RyzenAPI
-- Game: Love wish

-- MAIN APPLICATION
addappid(1153430)
addappid(1209400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153431, 1, "03be09a785084b42b5cb1cb53dcc99a03232d56ef0fd588f5fd0240c29a847af")
addappid(1153433, 1, "97dc7fd43710e661fd3a21d191c7a6373fa0af4bc07e27f2535c1090f143b740")
