-- Lua provided by RyzenAPI
-- Game: Maverta Island

-- MAIN APPLICATION
addappid(1848290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848291, 1, "d8af72832f34c2b4fadbcd8d89b7d675ef6d8ce29ad21e5ee2fb532cbab3c65c")
addappid(1848292, 1, "a14a3415d5427da03872d0d216400c0081f9193c3eaa87a77484251fdb92fc02")

