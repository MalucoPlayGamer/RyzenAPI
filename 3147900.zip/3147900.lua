-- Lua provided by RyzenAPI
-- Game: Game: Meddl Dash

-- MAIN APPLICATION
addappid(3147900)
-- Game: addappid(3147900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3147901, 1, "4239bcafe120b2c90d22a7f2e3aad46e95781ceda9c3bd5d4f4b9b50c418812a")
