-- Lua provided by RyzenAPI
-- Game: addappid(2361140)

-- MAIN APPLICATION
addappid(2361140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361141, 1, "540a05cac131117b3e1858d57aecb6272480c195cbd48d9fd16b27e50061e2eb")
