-- Lua provided by RyzenAPI
-- Game: Game: COASTLINE Demo

-- MAIN APPLICATION
addappid(2072180)
-- Game: addappid(2072180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072181, 1, "d480052899dfe5eb75a427b7a100204984289333f226f247ee3078745dbd67ee")
