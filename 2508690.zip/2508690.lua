-- Lua provided by RyzenAPI
-- Game: Sugar Girls

-- MAIN APPLICATION
addappid(2508690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508691, 1, "3804ce3fcd049222724f187f8bfed05c9f49be38081ac5eb35fbc084422f891a")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2616640)
