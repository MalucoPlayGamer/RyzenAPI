-- Lua provided by SkyAPI 
-- Game: Central Bank
addappid(3316880)
addappid(3316881, 1, "0874000e22995f40be7336af77f163b6ad6ab85cf2ea5905f22e20158b3c7898")
