-- Lua provided by RyzenAPI
-- Game: Pipe connect

-- MAIN APPLICATION
addappid(1908430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908431, 1, "9b39b9126835d452afc5b1d768c7d7148a344e178f9f77f1646ec7c461712a8d")
