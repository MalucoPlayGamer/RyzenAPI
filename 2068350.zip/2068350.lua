-- Lua provided by RyzenAPI
-- Game: 2068350

-- MAIN APPLICATION
addappid(2068350)
-- Game: addappid(2068350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068351, 1, "ce807be1eff5ffbdd74e959cee451136dc87149e0f1785328870a7f77a987be0")
