-- Lua provided by RyzenAPI
-- Game: addappid(1230340)

-- MAIN APPLICATION
addappid(1230340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230341, 1, "08845f39f209e06dfa49c415fbbf08f11d343e0a0a08cd7b940d988540e5d3fd")
