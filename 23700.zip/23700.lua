-- Lua provided by RyzenAPI
-- Game: Puzzle Kingdoms

-- MAIN APPLICATION
addappid(23700)

-- MAIN APP DEPOTS / PACKAGES
addappid(23701, 1, "bedcc9576883f64351df00eef4a75ca4048b50184a2ec950d7d21e882bc6ed03")
