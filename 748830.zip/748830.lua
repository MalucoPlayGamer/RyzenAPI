-- Lua provided by RyzenAPI
-- Game: AppID 748830

-- MAIN APPLICATION
addappid(748830)

-- MAIN APP DEPOTS / PACKAGES
addappid(748831, 1, "6fd919ce1119251b8ab951893a2deaa0772bf2ceba31177cfc82bed5c2b0ce12")
