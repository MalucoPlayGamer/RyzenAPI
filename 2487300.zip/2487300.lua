-- Lua provided by RyzenAPI
-- Game: 2487300

-- MAIN APPLICATION
addappid(2487300)
addappid(4227140)
addappid(4227150)
addappid(4227160)
-- Game: addappid(2487300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487301, 1, "38cfd22b926d3b26003c9fdbb4b31de63fdcfd1e7a507955cf73c1854176315e")
