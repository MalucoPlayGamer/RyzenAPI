-- Lua provided by RyzenAPI
-- Game: Docked

-- MAIN APPLICATION
addappid(2487300)
addappid(4227140)
addappid(4227150)
addappid(4227160)
addappid(4227170)
addappid(4911490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487301,0,"38cfd22b926d3b26003c9fdbb4b31de63fdcfd1e7a507955cf73c1854176315e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
