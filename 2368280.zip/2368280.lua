-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2368280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368280,0,"970b4281b82ddecad62c584ee0d84146328e062863bd084d9f8770e71ab520e1")

