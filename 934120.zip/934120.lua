-- Lua provided by RyzenAPI
-- Game: 934120

-- MAIN APPLICATION
addappid(934120)
-- Game: addappid(934120)

-- MAIN APP DEPOTS / PACKAGES
addappid(934121, 1, "0e4dab283ee011220e01d5c89fc71b415554fff411b8ef4c894f45f71edf1834")
