-- Lua provided by SkyAPI 
-- Game: Amenti
addappid(3292260)
addappid(3292261, 1, "74eef4bc050faacbb032fd8e150628a23fc93aec229876a4f5e04427fb623b33")
