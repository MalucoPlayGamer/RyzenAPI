-- Lua provided by RyzenAPI
-- Game: Amenti

-- MAIN APPLICATION
addappid(3292260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3292261, 1, "74eef4bc050faacbb032fd8e150628a23fc93aec229876a4f5e04427fb623b33")

