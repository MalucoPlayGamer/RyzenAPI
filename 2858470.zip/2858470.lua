-- Lua provided by RyzenAPI
-- Game: AppID 2858470

-- MAIN APPLICATION
addappid(2858470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858471, 1, "49e41c755940ac4bdcfbf7dae924bf45788e9dd90a3b54daeff68e3007587836")

