-- Lua provided by RyzenAPI 
-- Game: AppID 817460
addappid(817460)
addappid(817461, 1, "5a6807054ff29003e6ccd0a8e152fe54e1e507c62b91cd5c48783065d32d3158")
addappid(817462, 1, "51434b16d0709aef02bf4a4f47a13dc1f6e4227018ab16f4a826a2724c01e33c")
