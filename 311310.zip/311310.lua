-- Lua provided by RyzenAPI 
-- Game: Naval Action
addappid(311310)
addappid(311311, 1, "f6cef5d884c5388e8ef8d7d216236d741b9f5797b7c84fcd2b1450e5b350a498")
