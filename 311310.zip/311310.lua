-- Lua provided by RyzenAPI
-- Game: Naval Action

-- MAIN APPLICATION
addappid(311310)

-- MAIN APP DEPOTS / PACKAGES
addappid(311311, 1, "f6cef5d884c5388e8ef8d7d216236d741b9f5797b7c84fcd2b1450e5b350a498")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(785910)
addappid(814110)
addappid(867240)
addappid(885270)
addappid(904370)
addappid(1045170)
addappid(1045190)
addappid(1054070)
addappid(1054071)
addappid(1143890)
addappid(1214480)
addappid(1307430)
addappid(1307440)
addappid(1412530)
addappid(1588640)
addappid(1588830)
addappid(1869320)
addappid(2322810)
addappid(2402190)
addappid(3010160)
addappid(4521440)
