-- Lua provided by RyzenAPI
-- Game: Game: Naval Action

-- MAIN APPLICATION
addappid(311310)
-- Game: addappid(311310)

-- MAIN APP DEPOTS / PACKAGES
addappid(311311, 1, "f6cef5d884c5388e8ef8d7d216236d741b9f5797b7c84fcd2b1450e5b350a498")
