-- Lua provided by RyzenAPI
-- Game: 3460970

-- MAIN APPLICATION
addappid(3460970)
-- Game: addappid(3460970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460971, 1, "69b04f20c3fbf92bc8e525ef1cd406d53903f3efd630666c3dded28d852a8f23")
