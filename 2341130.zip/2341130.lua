-- Lua provided by RyzenAPI
-- Game: The Turgenev Study

-- MAIN APPLICATION
addappid(2341130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341131,0,"e636800662feb92045124fe8f5fc6dd75eca0b7a0ac0b09d30420977faa517bd")

