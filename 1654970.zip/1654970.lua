-- Lua provided by RyzenAPI
-- Game: addappid(1654970)

-- MAIN APPLICATION
addappid(1654970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654971, 1, "4103c0fed13dc66d769f86c2df148c1b1ebfc88ac0cfe7d717df1bb3221f7d33")
