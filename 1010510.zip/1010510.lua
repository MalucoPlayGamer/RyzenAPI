-- Lua provided by RyzenAPI
-- Game: DCB Server

-- MAIN APPLICATION
addappid(1010510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
addappid(1005,0,"ffa980484d510ce8d7bfcdfde8545a438acc894accb6750711fdb75c0ee92ad9")
addappid(1006,0,"0a6d85ecbae0b6b89cf23244f6b4a69fe14e3e64b128473e93f9a2ed3d835b1c")
addappid(1010512,0,"a1cfc89b66db52827f696f68ca8a1d3b852e16fa9655b888aab6f5b635db4538")
addappid(1010513,0,"1addaf974aa79ceec736fe10557e260018699839b0992dfa7f22fe55424faebb")

