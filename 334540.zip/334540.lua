-- Lua provided by RyzenAPI 
-- Game: AppID 334540
addappid(334540)
addappid(334541, 1, "4156b85706d51f1edeb170d54c7a8cc36ecb5d9e8327397bb53b0e3caeed9816")
addappid(334542, 1, "ac9356e92e273eab26722076ec3bace81b8eace007e390629f13556aa3f1214c")
