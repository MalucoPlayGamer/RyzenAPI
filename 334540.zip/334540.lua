-- Lua provided by RyzenAPI
-- Game: AppID 334540

-- MAIN APPLICATION
addappid(334540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(334541, 1, "4156b85706d51f1edeb170d54c7a8cc36ecb5d9e8327397bb53b0e3caeed9816")
addappid(334542, 1, "ac9356e92e273eab26722076ec3bace81b8eace007e390629f13556aa3f1214c")

