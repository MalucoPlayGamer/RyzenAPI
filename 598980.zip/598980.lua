-- Lua provided by RyzenAPI
-- Game: The Coin Game

-- MAIN APPLICATION
addappid(598980)
addappid(1267250)

-- MAIN APP DEPOTS / PACKAGES
addappid(598981, 1, "5eef890e869bba07fb135158a507ede6b276453d706d5c4e36f2ac5a66e43963")
addappid(598984, 1, "8cd74454dd76b1413f9e9edce77dc07524709e46e9cca1523699953c636ad7dd")
