-- Lua provided by RyzenAPI
-- Game: Idol Project : NTR

-- MAIN APPLICATION
addappid(1742180)
addappid(1742181)
addappid(1742182)
addappid(1742184)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742183,0,"c52559d8505520917285ceba3663ee02ffced5cecf112d390dd03b179c4f3be6")
addtoken(1742180,10936266255042766215)

