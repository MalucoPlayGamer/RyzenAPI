-- Lua provided by RyzenAPI
-- Game: addappid(2509120)

-- MAIN APPLICATION
addappid(2509120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509121, 1, "9f131b1dbfeaa72e13348dfe0df6023eaf38721fc7e8323d92858dba5e1e13c8")
