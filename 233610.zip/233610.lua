-- Lua provided by RyzenAPI
-- Game: Distance

-- MAIN APPLICATION
addappid(233610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(233611, 1, "6b19ad1365e822aa56423ef49c06dcec500cee65065052d5714e7f14ec7e2fa4")
addappid(233612, 1, "6a05e3b879c50cdd7cbc8a9b1f129d951604599b26e73672b44f1da1a11ce8ec")
addappid(233613, 1, "6892c471018336e9f2dfbdee33d30eb6fec7a9e0cb06f2edabe66b1582898bfa")
addappid(233614, 1, "e5a0c197ecafbb6f346cbd811f304ccc2312e3ad29dd4f9019ea411f746efad6")

