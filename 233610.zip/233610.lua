-- Lua provided by RyzenAPI
-- Game: Distance

-- MAIN APPLICATION
addappid(233610)

-- MAIN APP DEPOTS / PACKAGES
addappid(233611, 1, "6b19ad1365e822aa56423ef49c06dcec500cee65065052d5714e7f14ec7e2fa4")
addappid(233612, 1, "6a05e3b879c50cdd7cbc8a9b1f129d951604599b26e73672b44f1da1a11ce8ec")
addappid(233613, 1, "6892c471018336e9f2dfbdee33d30eb6fec7a9e0cb06f2edabe66b1582898bfa")
addappid(233614, 1, "e5a0c197ecafbb6f346cbd811f304ccc2312e3ad29dd4f9019ea411f746efad6")

