-- Lua provided by RyzenAPI
-- Game: Game: Mineirinho Wildtides DC

-- MAIN APPLICATION
addappid(1222240)
-- Game: addappid(1222240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222241, 1, "4eeb8ba5dd8123ec979fb2ce554b1a286f23cc5b77fd34386c0b3bc032f048b0")
