-- Lua provided by RyzenAPI
-- Game: addappid(2631000)

-- MAIN APPLICATION
addappid(2631000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631001, 1, "3b23dc62bb1133c9c1a24fb6cfdc453995a69f2238fb45eb1c3c888a9084d427")
