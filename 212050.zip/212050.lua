-- Lua provided by RyzenAPI 
-- Game: Resonance
addappid(212050)
addappid(212051, 1, "3251e039a503c68fa53c7b1c2fba1e69d9f42b4629db0bbd7005f898ac5c1d66")
addappid(212052, 1, "da048debfa06127fd89418b5208098fdd1b772eed704f31270ac7dacfe366ddb")
addappid(212053, 1, "a348c6803b96a87f15bf1048726928db8c63dfb12525d00664c7aa1fbb65138c")
addappid(212054, 1, "647939be0923f81cb229df40d9849d8ceac26dac74c5e34a7e31e96ec4e0fc22")
