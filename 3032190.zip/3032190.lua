-- Lua provided by RyzenAPI
-- Game: Just Date Vegan

-- MAIN APPLICATION
addappid(3032190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032191, 1, "4d9a65f594a9a059e9c183a946d7a5ac772c0b3b78a71ab3192e789694aa4a22")

