-- Lua provided by SkyAPI 
-- Game: Just Date Vegan
addappid(3032190)
addappid(3032191, 1, "4d9a65f594a9a059e9c183a946d7a5ac772c0b3b78a71ab3192e789694aa4a22")
