-- Lua provided by RyzenAPI
-- Game: Hatred

-- MAIN APPLICATION
addappid(341940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(341941, 1, "9a058f86501451492d08c6eb37d6bd51e6937951ac04de40caa6c7feea376fc9")
addappid(341942, 1, "eae9b9d8694786069538cc89beb7f2f1f9e20694c06907ac78db2aa68a230a74")
addappid(1171890, 0, "0fdd1c65078267470f71130fd77b21931942ec50c65a511653822a02dcd9cf3e")
addappid(1580880, 0, "480533da6d6b9e61972ad4b0c2a1e6e011e7d2d9bece0468274cfdaeeb9d8be0")

