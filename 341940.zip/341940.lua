-- Lua provided by RyzenAPI
-- Game: Game: Hatred

-- MAIN APPLICATION
addappid(341940)
-- Game: addappid(341940)

-- MAIN APP DEPOTS / PACKAGES
addappid(341941, 1, "9a058f86501451492d08c6eb37d6bd51e6937951ac04de40caa6c7feea376fc9")
addappid(341942, 1, "eae9b9d8694786069538cc89beb7f2f1f9e20694c06907ac78db2aa68a230a74")
addappid(1171890, 0, "0fdd1c65078267470f71130fd77b21931942ec50c65a511653822a02dcd9cf3e")
addappid(1580880, 0, "480533da6d6b9e61972ad4b0c2a1e6e011e7d2d9bece0468274cfdaeeb9d8be0")
