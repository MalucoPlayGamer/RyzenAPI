-- Lua provided by RyzenAPI
-- Game: Gobbo goes adventures

-- MAIN APPLICATION
addappid(2440320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440321, 1, "0d7309e9c629b5336c978d9ebf5bbe8ea1e13ff8bde4aa9bc527656e8aeec25f")

