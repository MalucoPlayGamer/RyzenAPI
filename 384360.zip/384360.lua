-- Lua provided by RyzenAPI
-- Game: Fingered

-- MAIN APPLICATION
addappid(384360)

-- MAIN APP DEPOTS / PACKAGES
addappid(384361, 1, "e7670e8cef5aa3b327c5600d68416565b51bdceae7fedabed074096ad548c369")

