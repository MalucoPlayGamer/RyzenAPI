-- Lua provided by RyzenAPI
-- Game: 1363980

-- MAIN APPLICATION
addappid(1363980)
-- Game: addappid(1363980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363981, 1, "8faf0eb2f5c2ffc67ef5ebb70178331bc74ed03c75d14b0256f5f4b534b2d2d9")
