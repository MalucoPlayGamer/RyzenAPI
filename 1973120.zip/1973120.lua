-- Lua provided by RyzenAPI
-- Game: AppID 1973120

-- MAIN APPLICATION
addappid(1973120)
-- Game: addappid(1973120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973121, 1, "f30909341ffca9bc6a5912aff9a0c319a44e21b43966b01f1bd301e588bce088")
