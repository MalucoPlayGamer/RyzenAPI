-- Lua provided by RyzenAPI
-- Game: addappid(2257470)

-- MAIN APPLICATION
addappid(2257470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257471, 1, "1495f6fcba3bf8a98436c33052bdafba56af0b83b6b34de82e1dc7bad8bebe6f")
