-- Lua provided by RyzenAPI
-- Game: Game: Last Night Shift

-- MAIN APPLICATION
addappid(2628070)
-- Game: addappid(2628070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628071, 1, "4cd32b3051af4e1ba39a4e61f2b1876dcf4e029aee448c98082a4605413000d2")
