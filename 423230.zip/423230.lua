-- Lua provided by RyzenAPI 
-- Game: Furi
addappid(423230)
addappid(423231, 1, "156dd9e4eb8c7891a53e579ff33bf7aac55c26b1d5de6153aa1fe3688d04fffd")
