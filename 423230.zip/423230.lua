-- Lua provided by RyzenAPI
-- Game: Furi

-- MAIN APPLICATION
addappid(423230)

-- MAIN APP DEPOTS / PACKAGES
addappid(423231, 1, "156dd9e4eb8c7891a53e579ff33bf7aac55c26b1d5de6153aa1fe3688d04fffd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(567810)
addappid(1802170)
addappid(3612090)
