-- Lua provided by RyzenAPI
-- Game: 523680

-- MAIN APPLICATION
addappid(523680)
-- Game: addappid(523680)

-- MAIN APP DEPOTS / PACKAGES
addappid(523681, 1, "7085629fdb032256d574679a34c4fc55258fc5bc9d1ce2268cd4812f5761d3c3")
