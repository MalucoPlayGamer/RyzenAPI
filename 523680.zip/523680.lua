-- Lua provided by RyzenAPI
-- Game: Honey Rose: Underdog Fighter Extraordinaire

-- MAIN APPLICATION
addappid(523680)
addappid(527400)
addappid(527401)
addappid(527402)
addappid(527403)
addappid(527404)
addappid(527405)
addappid(527406)
addappid(527407)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(523681, 1, "7085629fdb032256d574679a34c4fc55258fc5bc9d1ce2268cd4812f5761d3c3")

