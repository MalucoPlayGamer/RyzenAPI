-- Lua provided by RyzenAPI
-- Game: HAWKEN REBORN

-- MAIN APPLICATION
addappid(705040)
-- Game: addappid(705040)

-- MAIN APP DEPOTS / PACKAGES
addappid(705041, 1, "41272d8974381b25e507bcd74fc2cd013a070ce100cd7fe898bbf0bfc929b4c7")
