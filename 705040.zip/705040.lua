-- Lua provided by RyzenAPI
-- Game: HAWKEN REBORN

-- MAIN APPLICATION
addappid(705040)

-- MAIN APP DEPOTS / PACKAGES
addappid(705041, 1, "41272d8974381b25e507bcd74fc2cd013a070ce100cd7fe898bbf0bfc929b4c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
