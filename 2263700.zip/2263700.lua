-- Lua provided by RyzenAPI
-- Game: Manabaz

-- MAIN APPLICATION
addappid(2263700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263701, 1, "1a4abfd78ad9ce5d39125481e430e7b7dc85784531259a552be8719f70e81cf8")
