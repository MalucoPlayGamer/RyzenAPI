-- Lua provided by SkyAPI 
-- Game: Impulse
addappid(1753760)
addappid(1753761, 1, "2b7314028352ebe5d04286d4494cdfbd45ac00b1ab096848aebb7d4b624e2e53")
