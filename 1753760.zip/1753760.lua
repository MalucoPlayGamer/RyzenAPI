-- Lua provided by RyzenAPI
-- Game: Impulse

-- MAIN APPLICATION
addappid(1753760)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(1753761, 1, "2b7314028352ebe5d04286d4494cdfbd45ac00b1ab096848aebb7d4b624e2e53")

