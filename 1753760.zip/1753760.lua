-- Lua provided by RyzenAPI
-- Game: Impulse

-- MAIN APPLICATION
addappid(1753760)
-- Game: addappid(1753760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753761, 1, "2b7314028352ebe5d04286d4494cdfbd45ac00b1ab096848aebb7d4b624e2e53")
