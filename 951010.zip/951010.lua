-- Lua provided by RyzenAPI
-- Game: Zero spring episode 1 English translation version

-- MAIN APPLICATION
addappid(951010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(951011, 1, "4c627dd0179e08a34d3bf0ea7dc1d26ec13f851f84f7db199736378b920f8d62")

