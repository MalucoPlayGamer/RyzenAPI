-- Lua provided by RyzenAPI 
-- Game: Save Room - Organization Puzzle
addappid(1955330)
addappid(1955331, 1, "4b135a86649f7acbf3dc4cb0ecae8acd4816f05cb4d934d6f654afae4b3c79b3")
addappid(1955332, 1, "65064902081d955bc43bc5fd339aaeb219362477e5b88976a5673975bb521a8b")
