-- Lua provided by SkyAPI 
-- Game: Granny: Chapter Two
addappid(1205040)
addappid(1205041, 1, "4c4bbe19ea7a183ac419f32c6c140bd98938407f07a00718eddeee9d493b24da")
