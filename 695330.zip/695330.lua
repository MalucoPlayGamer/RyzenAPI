-- Lua provided by RyzenAPI
-- Game: SEASON: A letter to the future

-- MAIN APPLICATION
addappid(695330)

-- MAIN APP DEPOTS / PACKAGES
addappid(695331, 1, "3253b2367bd8fddfab812397b2cff6a950e641aafc374f39c1c0bc4131d91445")
