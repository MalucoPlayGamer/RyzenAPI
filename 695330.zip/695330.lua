-- Lua provided by RyzenAPI
-- Game: SEASON: A letter to the future

-- MAIN APPLICATION
addappid(695330)

-- MAIN APP DEPOTS / PACKAGES
addappid(695331, 1, "3253b2367bd8fddfab812397b2cff6a950e641aafc374f39c1c0bc4131d91445")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
