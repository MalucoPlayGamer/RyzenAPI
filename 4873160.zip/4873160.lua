-- Lua provided by RyzenAPI
-- Game: 3D Print Designer

-- MAIN APPLICATION
addappid(4873160) -- 3D Print Designer

-- MAIN APP DEPOTS / PACKAGES
addappid(4873161, 1, "e271ee9ad60eff3e2119f4b9e9a6cf13818b94b67b1ee5c83c6a5b5033907462") -- Depot 4873161
addappid(4873162, 1, "ae427b0a40508db6149f3be6d99c908c75fcd03829286af5f92d3e6c21c948eb") -- Depot 4873162

