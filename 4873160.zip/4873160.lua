-- 4873160's Lua and Manifest Created by Hubcap Manifest
-- 3D Print Designer
-- Created: August 11, 2026 at 12:26:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4873160) -- 3D Print Designer
-- MAIN APP DEPOTS
addappid(4873161, 1, "e271ee9ad60eff3e2119f4b9e9a6cf13818b94b67b1ee5c83c6a5b5033907462") -- Depot 4873161
setManifestid(4873161, "6520416673769953478", 592028753)
addappid(4873162, 1, "ae427b0a40508db6149f3be6d99c908c75fcd03829286af5f92d3e6c21c948eb") -- Depot 4873162
setManifestid(4873162, "5392283325118761089", 711343701)