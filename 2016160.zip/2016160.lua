-- Lua provided by RyzenAPI
-- Game: addappid(2016160)

-- MAIN APPLICATION
addappid(2016160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016161, 1, "686a2308acf42e01c1b6dc008ca3a09b9b65302702d1bc6f31ca196840e74749")
