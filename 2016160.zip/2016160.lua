-- Lua provided by RyzenAPI 
-- Game: POSTAL 4: No Regerts - KDTF Soundtrack
addappid(2016160)
addappid(2016161, 1, "686a2308acf42e01c1b6dc008ca3a09b9b65302702d1bc6f31ca196840e74749")
