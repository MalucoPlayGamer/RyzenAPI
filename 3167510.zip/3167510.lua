-- Lua provided by RyzenAPI
-- Game: Ghost Clicker

-- MAIN APPLICATION
addappid(3167510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167511, 1, "444205acaebf8b5b2b5c4e0275e171e548dddfd43969d244735f0a80c86b0ff9")
