-- Lua provided by RyzenAPI
-- Game: AppID 2483800

-- MAIN APPLICATION
addappid(2483800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483801, 1, "fbbc91b6ad1c1a9caaa366912e40f00696d7c9ec25b1ce01024586a6277b7a8f")

