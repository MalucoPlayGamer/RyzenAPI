-- Lua provided by RyzenAPI
-- Game: AppID 2060640

-- MAIN APPLICATION
addappid(2060640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060641, 1, "73f8f8f53ef90e25cdf2e4a40485ba515943a19f5e637bae6e273ce1ef36d0e0")
