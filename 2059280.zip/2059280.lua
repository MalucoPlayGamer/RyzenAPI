-- Lua provided by RyzenAPI
-- Game: addappid(2059280)

-- MAIN APPLICATION
addappid(2059280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059282,0,"36c4ea8984fe478b9dc5431d632bb1004c62dc975516e8fef9ef15669ccfaf82")
