-- Lua provided by RyzenAPI
-- Game: addappid(2545570)

-- MAIN APPLICATION
addappid(2545570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2545571, 1, "49944b186b85af44ccf18f97d6bd039e5ac9e4744f02ef2581e340781d5ad689")
