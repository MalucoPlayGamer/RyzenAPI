-- Lua provided by RyzenAPI
-- Game: Toon War

-- MAIN APPLICATION
addappid(803780)

-- MAIN APP DEPOTS / PACKAGES
addappid(803781,0,"084c3b90ceadd84b7c3490c924afa4ea06fadf18dd3c9661d889f9d222bb4b36")
addappid(803782,0,"75ca6cc7b9112429e469bb7be86840d511983592f2d81a02be092ecb153ac84b")

