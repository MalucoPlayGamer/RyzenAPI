-- Lua provided by RyzenAPI
-- Game: Lost King's Lullaby

-- MAIN APPLICATION
addappid(737670)

-- MAIN APP DEPOTS / PACKAGES
addappid(737671,0,"95640a503f7a4a59af364bf5575a1b5fbc8ca519f0d0b93beee52d757631e665")

