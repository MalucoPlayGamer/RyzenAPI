-- Lua provided by SkyAPI 
-- Game: Re.Surs
addappid(1603260)
addappid(1603261, 1, "bc24604813d8fb2c7447c0ace3b31529ecebbc9da75414a95eec8320d064bafe")
