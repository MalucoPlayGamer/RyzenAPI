-- Lua provided by RyzenAPI
-- Game: Game: Re.Surs

-- MAIN APPLICATION
addappid(1603260)
-- Game: addappid(1603260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603261, 1, "bc24604813d8fb2c7447c0ace3b31529ecebbc9da75414a95eec8320d064bafe")
