-- Lua provided by RyzenAPI
-- Game: Re.Surs

-- MAIN APPLICATION
addappid(1603260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1603261, 1, "bc24604813d8fb2c7447c0ace3b31529ecebbc9da75414a95eec8320d064bafe")

