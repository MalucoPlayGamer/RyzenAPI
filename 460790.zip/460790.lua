-- Lua provided by RyzenAPI
-- Game: Bayonetta

-- MAIN APPLICATION
addappid(460790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(460792,0,"e80066b74e53039c621ea6adf902751eb8f1dac4ca0d402199191086cf6302b7")
addappid(460793,0,"cdea589ed071f14e0e3888afa183b8571b885073ac2994fad89e6830f5371cc8")

