-- Lua provided by RyzenAPI
-- Game: Bayonetta

-- MAIN APPLICATION
addappid(460790)
-- Game: addappid(460790)

-- MAIN APP DEPOTS / PACKAGES
addappid(460792,0,"e80066b74e53039c621ea6adf902751eb8f1dac4ca0d402199191086cf6302b7")
addappid(460793,0,"cdea589ed071f14e0e3888afa183b8571b885073ac2994fad89e6830f5371cc8")
