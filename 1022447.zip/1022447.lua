-- Lua provided by RyzenAPI
-- Game: DFF NT: Kefka Palazzo Starter Pack

-- MAIN APPLICATION
addappid(1022447)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022447,0,"b36879658111ccd42e7aa8b5ea3371f1d5f965cb6a8dcff03863d1926375a351")
