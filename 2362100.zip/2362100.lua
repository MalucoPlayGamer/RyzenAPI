-- Lua provided by RyzenAPI
-- Game: Game: Punch Club 2 Demo

-- MAIN APPLICATION
addappid(2362100)
-- Game: addappid(2362100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362101, 1, "74684d7b6a8344eac28f490330106a0f59fa187a3937c545101281898561dd0f")
