-- Lua provided by RyzenAPI
-- Game: Game: Wild Wet West

-- MAIN APPLICATION
addappid(1581700)
-- Game: addappid(1581700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581701, 1, "33111895b9e582c2462890a3ea9608ed012c6186d8a7067e30c8e6b60e0b2582")
