-- Lua provided by SkyAPI 
-- Game: Friki
addappid(1502010)
addappid(1502011, 1, "c90cd4405df758cc994d7812d66ba70ef6ffb72e0e25c24b2ecd49623015abf2")
