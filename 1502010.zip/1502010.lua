-- Lua provided by RyzenAPI
-- Game: Friki

-- MAIN APPLICATION
addappid(1502010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1502011, 1, "c90cd4405df758cc994d7812d66ba70ef6ffb72e0e25c24b2ecd49623015abf2")

