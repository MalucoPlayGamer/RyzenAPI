-- Lua provided by RyzenAPI
-- Game: Game: Friki

-- MAIN APPLICATION
addappid(1502010)
-- Game: addappid(1502010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502011, 1, "c90cd4405df758cc994d7812d66ba70ef6ffb72e0e25c24b2ecd49623015abf2")
