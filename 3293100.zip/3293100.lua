-- Lua provided by RyzenAPI
-- Game: Scientist Creature

-- MAIN APPLICATION
addappid(3293100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3293101, 1, "36803a08d970cfb6e44ddce36624cffc3a41a2b22db3827f7677018d1452a66f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
