-- Lua provided by RyzenAPI
-- Game: Scientist Creature

-- MAIN APPLICATION
addappid(3293100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3293101, 1, "36803a08d970cfb6e44ddce36624cffc3a41a2b22db3827f7677018d1452a66f")
