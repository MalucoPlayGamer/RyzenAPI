-- Lua provided by RyzenAPI
-- Game: Click on their Heads

-- MAIN APPLICATION
addappid(1498630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498631, 1, "ad47bb83d4f870a781e38ddbd5a5de6e98db50517eafcda833dff47bff0e6240")

