-- Lua provided by RyzenAPI 
-- Game: AppID 2606280
addappid(2606280)
addappid(2606281, 1, "3df27e31503550c0f2a9ab02a1131151a48fae8d579144f0cca0ca3f62ed7faa")
