-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles World War II Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1005220)
