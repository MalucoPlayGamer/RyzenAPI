-- Lua provided by RyzenAPI
-- Game: Pixel Puzzles World War II Jigsaw Puzzles

-- MAIN APPLICATION
addappid(1005220)
addappid(1760834)
addappid(1760839)
addappid(1760852)
addappid(1760855)
addappid(1760856)
addappid(1760858)
addappid(1760859)
addappid(1760866)
addappid(1760929)
addappid(1760935)
addappid(1760940)
addappid(1760949)
addappid(1760950)
addappid(1760951)

