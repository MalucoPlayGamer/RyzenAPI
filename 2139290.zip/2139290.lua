-- Lua provided by RyzenAPI
-- Game: Game: One Tank Army

-- MAIN APPLICATION
addappid(2139290)
-- Game: addappid(2139290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139291, 1, "ec2c88771fc564579f331e0f1960517850e1626bc69d9b796de427224d22dce7")
