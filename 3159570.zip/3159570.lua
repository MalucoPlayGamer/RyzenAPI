-- Lua provided by RyzenAPI
-- Game: Game: Lynked: Banner of the Spark

-- MAIN APPLICATION
addappid(3159570)
addappid(3269880)
-- Game: addappid(3159570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3159571, 1, "8b67b11313f1da51f2ba40bab7831b79558154057a6270e935dfed05d85b9fef")
