-- Lua provided by RyzenAPI
-- Game: Lynked: Banner of the Spark

-- MAIN APPLICATION
addappid(3159570)
addappid(3269880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3159571, 1, "8b67b11313f1da51f2ba40bab7831b79558154057a6270e935dfed05d85b9fef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
