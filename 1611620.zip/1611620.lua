-- Lua provided by RyzenAPI 
-- Game: Nude for Clip maker
addappid(1611620)
addappid(1611621, 1, "4e12d0c5929ba4eea9e2414d05782b30df057b14e1edd739edf85afe2b115232")
