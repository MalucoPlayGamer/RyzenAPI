-- Lua provided by RyzenAPI
-- Game: 1611620

-- MAIN APPLICATION
addappid(1611620)
-- Game: addappid(1611620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611621, 1, "4e12d0c5929ba4eea9e2414d05782b30df057b14e1edd739edf85afe2b115232")
