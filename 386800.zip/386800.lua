-- Lua provided by RyzenAPI
-- Game: AppID 386800

-- MAIN APPLICATION
addappid(386800)

-- MAIN APP DEPOTS / PACKAGES
addappid(386801, 1, "14add6c8bb4bd5c3789fbdda71103176a039ffabcbc0e4cd885eaca2fdb45044")
