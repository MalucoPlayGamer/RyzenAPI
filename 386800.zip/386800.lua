-- Lua provided by SkyAPI 
-- Game: AppID 386800
addappid(386800)
addappid(386801, 1, "14add6c8bb4bd5c3789fbdda71103176a039ffabcbc0e4cd885eaca2fdb45044")
