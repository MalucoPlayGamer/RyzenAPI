-- Lua provided by RyzenAPI
-- Game: AppID 386800

-- MAIN APPLICATION
addappid(386800)

-- MAIN APP DEPOTS / PACKAGES
addappid(386801, 1, "14add6c8bb4bd5c3789fbdda71103176a039ffabcbc0e4cd885eaca2fdb45044")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
