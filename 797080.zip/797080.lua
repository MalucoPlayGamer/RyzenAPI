-- Lua provided by RyzenAPI
-- Game: addappid(797080)

-- MAIN APPLICATION
addappid(797080)

-- MAIN APP DEPOTS / PACKAGES
addappid(797081, 1, "953563e984d308f9a305ad656b6679d6423ada6b6c8bfe987001680cfd49eecf")
