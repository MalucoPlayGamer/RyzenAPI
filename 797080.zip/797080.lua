-- Lua provided by RyzenAPI 
-- Game: AppID 797080
addappid(797080)
addappid(797081, 1, "953563e984d308f9a305ad656b6679d6423ada6b6c8bfe987001680cfd49eecf")
