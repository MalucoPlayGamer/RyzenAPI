-- Lua provided by RyzenAPI
-- Game: RetroArch - Theodore

-- MAIN APPLICATION
addappid(1227442)
-- Game: addappid(1227442)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227442,0,"06dfd959b95e0cd7106214ce83293fbbc89ef0db3b2f35f7bfa6c3a581370e65")
addappid(1790090,0,"a624d3fe87e047463b84d0d4288c5355d0e2a8a63d84a4eed519e75b43398424")
addappid(1790091,0,"94aa13da9d4ff42d40791bd4b3cb4ff59112e22ede5aa734f8aa247fdcb3344a")
