-- Lua provided by RyzenAPI
-- Game: addappid(340200)

-- MAIN APPLICATION
addappid(340200)

-- MAIN APP DEPOTS / PACKAGES
addappid(340201, 1, "6ae47b0e0952b8f365716fea710890d03b33c24d9cb65d822b4886900eb3d661")
