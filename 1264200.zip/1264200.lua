-- Lua provided by RyzenAPI
-- Game: 1264200

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(229006)
addappid(1264200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264202,0,"f739ef9a75420dde8e8cc2e20482f4efeb98054e3ae516c49fefcb467f514aeb")

