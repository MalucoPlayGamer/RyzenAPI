-- Lua provided by SkyAPI 
-- Game: Cafeteria Nipponica
addappid(1952170)
addappid(1952171, 1, "46db69c59ba068661a3d3c90cf81190c8fabb14610937605a4eaeb6c1c918627")
