-- Lua provided by RyzenAPI
-- Game: Cafeteria Nipponica

-- MAIN APPLICATION
addappid(1952170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952171, 1, "46db69c59ba068661a3d3c90cf81190c8fabb14610937605a4eaeb6c1c918627")
