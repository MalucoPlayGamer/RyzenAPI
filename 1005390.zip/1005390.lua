-- Lua provided by RyzenAPI
-- Game: Anti-Grav Bamboo-copter

-- MAIN APPLICATION
addappid(1005390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005391, 1, "ebdf217187fcf6b41638f5a14c440fe192d344908c6020c71b2efb805e055487")

