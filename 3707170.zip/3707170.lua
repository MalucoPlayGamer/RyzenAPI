-- Lua provided by RyzenAPI
-- Game: 3707170

-- MAIN APPLICATION
addappid(3707170)
-- Game: addappid(3707170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3707171, 1, "0a50353e5cbda12cadf78e1e4c12a6e55ce65140b5c111fb73fa2d268a2df096")
