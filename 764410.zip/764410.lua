-- Lua provided by RyzenAPI
-- Game: Trials of the Gauntlet

-- MAIN APPLICATION
addappid(764410)
addappid(810390)

-- MAIN APP DEPOTS / PACKAGES
addappid(764411, 1, "46d7a3fb78c4b7ed5095e94038400015f7520031a9064efadbbbc357dd8f815a")

