-- Lua provided by RyzenAPI
-- Game: Gorgon Shield

-- MAIN APPLICATION
addappid(2446920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2446922,0,"b3f749306e6c0d03524a9da269f1e633ec43e1131089307a80e2a484503bef0f")

