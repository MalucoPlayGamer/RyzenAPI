-- Lua provided by RyzenAPI
-- Game: AppID 852140

-- MAIN APPLICATION
addappid(852140)

-- MAIN APP DEPOTS / PACKAGES
addappid(852141, 1, "dcb847de6937703b4ffbb53f9c2c1cf3bb1cf2555a080cb9328795792f58729a")

