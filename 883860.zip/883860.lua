-- Lua provided by RyzenAPI
-- Game: Cadria Item Shop

-- MAIN APPLICATION
addappid(883860)

-- MAIN APP DEPOTS / PACKAGES
addappid(883861,0,"9e539453e0af280d79227a89cec60ee1f45190d8b93e9e12ae0a62cc27805a83")
addappid(914560,0,"ed1df0090ed40aac2f868b800db93c93faf51507b8a668d59ece12916a7e1cee")
addappid(914570,0,"84f02d33406073c89c5ff37a9ac3fbbe8db68985db3e1816f572c34f6308bce5")

