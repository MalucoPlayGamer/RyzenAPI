-- Lua provided by RyzenAPI
-- Game: 883860

-- MAIN APPLICATION
addappid(883860)
-- Game: addappid(883860)

-- MAIN APP DEPOTS / PACKAGES
addappid(883861, 1, "9e539453e0af280d79227a89cec60ee1f45190d8b93e9e12ae0a62cc27805a83")
