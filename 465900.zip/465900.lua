-- Lua provided by RyzenAPI
-- Game: addappid(465900)

-- MAIN APPLICATION
addappid(465900)

-- MAIN APP DEPOTS / PACKAGES
addappid(465901, 1, "e3dcc7c2296c40272ac0684d5fe180ce5baf1b938fd6001e30c08abe0fa14fb5")
