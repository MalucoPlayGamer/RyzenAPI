-- Lua provided by RyzenAPI
-- Game: 2517870

-- MAIN APPLICATION
addappid(2517870)
-- Game: addappid(2517870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517871, 1, "f6569ae7eb58c6ef242f486f2821fffd90e40b5efe8f54aa2a1fc0935891d5db")
