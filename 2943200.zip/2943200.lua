-- Lua provided by RyzenAPI
-- Game: Dr. Murph

-- MAIN APPLICATION
addappid(2943200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943201, 1, "450e8c80cfa66811618dbce42284999478bf9b03ab8e9f7246a56b32562c8e18")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
