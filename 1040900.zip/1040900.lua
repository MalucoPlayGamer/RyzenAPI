-- Lua provided by RyzenAPI
-- Game: Massive Air Combat

-- MAIN APPLICATION
addappid(1040900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040901,0,"c827008ed5ad93b0cd37eca13bcdcfa6eba30fd6f9d40157a1b47c83f8461f2d")
addappid(1040902,0,"758966833388bc9bb31b5b0c039910d01c322d58eef017f64ab116a9edffa676")
addappid(1103261,0,"f64808a89b3813451ccc6451096c85da8a9c98ad2b875160029d83fb44f24f18")
addappid(1149111,0,"c07a6d562128e57c2afad078daa43ed685c8685ef1c27bad1a35b213a9fe27d9")
addappid(1221871,0,"ba9ef24b72e671155396480dfa3cd993be7c41458e808c9c22ca9292be892d9b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1103260)
addappid(1149110)
addappid(1221870)
