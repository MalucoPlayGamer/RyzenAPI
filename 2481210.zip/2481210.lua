-- Lua provided by RyzenAPI
-- Game: Neve Demo

-- MAIN APPLICATION
addappid(2481210)
-- Game: addappid(2481210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2481211, 1, "0ef4fdebeffcb23a385fb45e3456ce79260984ce79b438ac42d9477bf21d36ed")
