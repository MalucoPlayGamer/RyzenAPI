-- Lua provided by RyzenAPI
-- Game: Heaven's Dream

-- MAIN APPLICATION
addappid(2502830)
addappid(2524240)
addappid(2551100)
addappid(2624220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2502831, 1, "492144af97383a07f2b2b4a137c74312b6e8f62c448865d5228d309ad53f4617")

