-- Lua provided by RyzenAPI
-- Game: Heaven's Dream

-- MAIN APPLICATION
addappid(2502830)
addappid(2524240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2502831, 1, "492144af97383a07f2b2b4a137c74312b6e8f62c448865d5228d309ad53f4617")

