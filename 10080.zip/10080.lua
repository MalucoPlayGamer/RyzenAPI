-- Lua provided by RyzenAPI
-- Game: Game: Quantum of Solace

-- MAIN APPLICATION
addappid(10080)
-- Game: addappid(10080)

-- MAIN APP DEPOTS / PACKAGES
addappid(10081, 1, "8a2adff5b7766af46f70ea475267c14ad1c9fcc7048054a959b602a090146017")
addappid(10082, 1, "07f629ada26e75a1de444692c6b7640050b4ae24b6b67fb106d7e7a4c96dcde5")
