-- Lua provided by RyzenAPI
-- Game: Game: Project Malice

-- MAIN APPLICATION
addappid(2157060)
addappid(2211740)
-- Game: addappid(2157060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157061, 1, "6144d270d4f60f1dc5290ca02417dc39c97ce05535c99b31964172a6323b3348")
