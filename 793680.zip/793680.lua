-- Lua provided by RyzenAPI
-- Game: Game: Fission Superstar X

-- MAIN APPLICATION
addappid(793680)
-- Game: addappid(793680)

-- MAIN APP DEPOTS / PACKAGES
addappid(793681, 1, "27022fa8e2729787c8ed62584404f68ebce9f3339b0b39d7c96818821f787815")
