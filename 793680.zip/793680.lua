-- Lua provided by SkyAPI 
-- Game: Fission Superstar X
addappid(793680)
addappid(793681, 1, "27022fa8e2729787c8ed62584404f68ebce9f3339b0b39d7c96818821f787815")
