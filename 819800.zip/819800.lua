-- Lua provided by SkyAPI 
-- Game: Untouchable
addappid(819800)
addappid(819801, 1, "31464071538e040f475bab7257e994b67dd754cc1c7b3007f921049b8872e7d9")
