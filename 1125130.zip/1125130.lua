-- Lua provided by RyzenAPI 
-- Game: AppID 1125130
addappid(1125130)
addappid(1125131, 1, "f9152cd426e96271d9d4afbc1fe667d7631c3b64c36bd939662ae7255b37e825")
