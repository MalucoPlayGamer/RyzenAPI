-- Lua provided by RyzenAPI 
-- Game: Toy Trains
addappid(2494440)
addappid(2494441, 1, "13cd46f71dc5e3cecdb134983b4f68815cae55fbced6b50a1e887674cb4458c3")
