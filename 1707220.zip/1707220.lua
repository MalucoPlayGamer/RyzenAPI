-- Lua provided by SkyAPI 
-- Game: AppID 1707220
addappid(1707220)
addappid(1707221, 1, "67dda0e470eac30328b2ef170579a4a180223edd1a30d4e9419e64007513697a")
