-- Lua provided by RyzenAPI
-- Game: Game: AppID 1707220

-- MAIN APPLICATION
addappid(1707220)
-- Game: addappid(1707220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707221, 1, "67dda0e470eac30328b2ef170579a4a180223edd1a30d4e9419e64007513697a")
