-- Lua provided by RyzenAPI
-- Game: Game: Bird Assassin

-- MAIN APPLICATION
addappid(312010)
-- Game: addappid(312010)

-- MAIN APP DEPOTS / PACKAGES
addappid(312011, 1, "d7636f7bc6d59fc1a51f94e07e1cc95f2137f0dd157c463e81db079a5cf49a73")
