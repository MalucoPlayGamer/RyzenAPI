-- Lua provided by RyzenAPI
-- Game: 353320

-- MAIN APPLICATION
addappid(353320)
-- Game: addappid(353320)

-- MAIN APP DEPOTS / PACKAGES
addappid(353321, 1, "fa8452a08431c25180f8b66e6f14a007867cf81eaf17a53d26b46d42f2c53699")
