-- Lua provided by RyzenAPI
-- Game: Vibrant Venture

-- MAIN APPLICATION
addappid(1264520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264521, 1, "4f9b2d72b3960114e65695c456931b99a33a4a634bc6a61b8c54818838bd5013")

