-- Lua provided by RyzenAPI
-- Game: Eight Mini Racers

-- MAIN APPLICATION
addappid(434890)
-- Game: addappid(434890)

-- MAIN APP DEPOTS / PACKAGES
addappid(434891, 1, "6517cacb3d6516bb4b425733068c27658305da3dcf2c2984e24016a2e45732c2")
