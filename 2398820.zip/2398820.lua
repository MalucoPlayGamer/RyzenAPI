-- Lua provided by RyzenAPI
-- Game: Polygeddon: Survive Demo

-- MAIN APPLICATION
addappid(2398820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2398821, 1, "4b9f761334d5aa5863eb81e3481081805480bcea713530104da93b835d88e8d2")
