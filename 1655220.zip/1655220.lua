-- Lua provided by RyzenAPI
-- Game: Game: Star Trek Prodigy: Supernova

-- MAIN APPLICATION
addappid(1655220)
-- Game: addappid(1655220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655221, 1, "933a22da992a733756724095d4d8e8bc0eab9c3a4f3c30faf17e7012a14b5d30")
