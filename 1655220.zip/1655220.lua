-- Lua provided by RyzenAPI
-- Game: Star Trek Prodigy: Supernova

-- MAIN APPLICATION
addappid(1655220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655221, 1, "933a22da992a733756724095d4d8e8bc0eab9c3a4f3c30faf17e7012a14b5d30")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
