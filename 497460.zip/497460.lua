-- Lua provided by RyzenAPI
-- Game: Mervils: A VR Adventure

-- MAIN APPLICATION
addappid(497460)

-- MAIN APP DEPOTS / PACKAGES
addappid(497461, 1, "c9299f256fbd9e4dea7c8b00e00065ff3329ab617ed28d7c213b864a4f4c6496")

