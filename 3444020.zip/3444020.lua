-- Lua provided by RyzenAPI
-- Game: Game: Demonic Mahjong

-- MAIN APPLICATION
addappid(3444020)
-- Game: addappid(3444020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3444021, 1, "390479eb93dcb5aa47faa126ba19b7b0db80bb304eeaedc192215c05deb69b8e")
