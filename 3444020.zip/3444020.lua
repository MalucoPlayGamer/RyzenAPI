-- Lua provided by RyzenAPI
-- Game: Created: August 07, 2026 at 12:36:59 EDT

-- MAIN APPLICATION
addappid(4817180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3444020, 1, "4bf7c24f3401a258a3191843cd2890ce58ac47bc5f3dc1b388be9645e2e31a77") -- 我在地府打麻将
addappid(3444021, 1, "390479eb93dcb5aa47faa126ba19b7b0db80bb304eeaedc192215c05deb69b8e") -- Depot 3444021
addappid(3444022, 1, "c7d881f2483c870330dfc2b85e02394b14b6257070a99cbe010f2ad1db2b98ba") -- Depot 3444022
addappid(4817182, 1, "a8e6dad6ba27a1b4dc901d4f2cc617f04e0ad9dcc0583d83dbba4572f5dae940") -- Depot 4817182
addappid(4817183, 1, "c3493b8e76e3facec9a63c57a2f972be6326e0f269e18360f96230b6d83beef5") -- Depot 4817183

