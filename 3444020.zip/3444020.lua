-- 3444020's Lua and Manifest Created by Hubcap Manifest
-- 我在地府打麻将
-- Created: August 07, 2026 at 12:36:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3444020, 1, "4bf7c24f3401a258a3191843cd2890ce58ac47bc5f3dc1b388be9645e2e31a77") -- 我在地府打麻将
-- MAIN APP DEPOTS
addappid(3444021, 1, "390479eb93dcb5aa47faa126ba19b7b0db80bb304eeaedc192215c05deb69b8e") -- Depot 3444021
setManifestid(3444021, "8203801859273469667", 6429545030)
addappid(3444022, 1, "c7d881f2483c870330dfc2b85e02394b14b6257070a99cbe010f2ad1db2b98ba") -- Depot 3444022
setManifestid(3444022, "7525551261295980339", 6786939032)
-- DLCS WITH DEDICATED DEPOTS
--  (AppID: 4817180)
addappid(4817180)
addappid(4817182, 1, "a8e6dad6ba27a1b4dc901d4f2cc617f04e0ad9dcc0583d83dbba4572f5dae940") -- Depot 4817182
setManifestid(4817182, "4432311096106271299", 0)
addappid(4817183, 1, "c3493b8e76e3facec9a63c57a2f972be6326e0f269e18360f96230b6d83beef5") -- Depot 4817183
setManifestid(4817183, "6825836540166172945", 0)