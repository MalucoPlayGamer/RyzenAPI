-- Lua provided by RyzenAPI
-- Game: AppID 1993130

-- MAIN APPLICATION
addappid(1993130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993131, 1, "1f56d5afff000a7302007cebb8f888ec1f596c82313cdece82495eebf556e7f7")

