-- Lua provided by RyzenAPI
-- Game: The Sheltered

-- MAIN APPLICATION
addappid(364370)

-- MAIN APP DEPOTS / PACKAGES
addappid(364371, 1, "af7f01fc356648906b9f7891cea80d0793b79501dd63c5b8713e16b84aafb1bd")
