-- Lua provided by SkyAPI 
-- Game: The Sheltered
addappid(364370)
addappid(364371, 1, "af7f01fc356648906b9f7891cea80d0793b79501dd63c5b8713e16b84aafb1bd")
