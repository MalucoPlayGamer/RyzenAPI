-- Lua provided by RyzenAPI
-- Game: Persian Nights 2: The Moonlight Veil

-- MAIN APPLICATION
addappid(1276540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276541, 1, "159d7d25dd70b8f9aa44f693388598dc9b9e4656fa6d39633a929be9bace8644")

