-- Lua provided by RyzenAPI 
-- Game: Evolution of Ages: Settlements
addappid(704640)
addappid(704641, 1, "33ee4a81147879fdac8d0276aba6ee5a81449d6cb551fa4a3230b8fdc7020b0d")
