-- Lua provided by RyzenAPI
-- Game: Game: Evolution of Ages: Settlements

-- MAIN APPLICATION
addappid(704640)
-- Game: addappid(704640)

-- MAIN APP DEPOTS / PACKAGES
addappid(704641, 1, "33ee4a81147879fdac8d0276aba6ee5a81449d6cb551fa4a3230b8fdc7020b0d")
