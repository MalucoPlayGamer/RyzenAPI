-- Lua provided by RyzenAPI
-- Game: AppID 1053250

-- MAIN APPLICATION
addappid(1053250)
-- Game: addappid(1053250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053251, 1, "60a4d0368e6f3ccbaba1205ff5f0620d542071ca56f25ea89bc080c0a254294d")
