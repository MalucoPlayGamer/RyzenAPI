-- Lua provided by RyzenAPI
-- Game: Treehouse Riddle

-- MAIN APPLICATION
addappid(1155900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155901, 1, "1b75d07dc96e3c0850a171367b56dee6624923c7c9bb107daa26d3ba10c9c1f8")
