-- Lua provided by RyzenAPI
-- Game: Treehouse Riddle

-- MAIN APPLICATION
addappid(1155900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155901, 1, "1b75d07dc96e3c0850a171367b56dee6624923c7c9bb107daa26d3ba10c9c1f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
