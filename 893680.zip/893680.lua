-- Lua provided by RyzenAPI
-- Game: Project Warlock

-- MAIN APPLICATION
addappid(893680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(893681, 1, "f243fe9206b50dc0cfc4f160cb9775e514938279d5015367c4b37a38fa5cd49e")
addappid(989960, 0, "d987f5343a4e971257d7bf2153706bd449de31abb4a127c4c12f7bfb62cf861c")
