-- Lua provided by RyzenAPI
-- Game: 680340

-- MAIN APPLICATION
addappid(680340)
-- Game: addappid(680340)

-- MAIN APP DEPOTS / PACKAGES
addappid(680341, 1, "8a2b6c29e5a21ee69c6536db9d55b3d83f1caa0a3a8ce6c88413334377173920")
