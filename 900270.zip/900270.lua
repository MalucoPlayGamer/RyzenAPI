-- Lua provided by RyzenAPI
-- Game: 900270

-- MAIN APPLICATION
addappid(900270)
-- Game: addappid(900270)

-- MAIN APP DEPOTS / PACKAGES
addappid(900271, 1, "b3a07f5334cf36332eab9aa6d8147c4d509e7f5f15ccceb638a830a5d8597a23")
