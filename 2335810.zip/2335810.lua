-- Lua provided by RyzenAPI
-- Game: Beach Club Simulator

-- MAIN APPLICATION
addappid(2335810)
-- Game: addappid(2335810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335811, 1, "640f142c5225e7e8fd4ee473f408f47b6e6b934e1d059802d42f95ffaaba0fec")
