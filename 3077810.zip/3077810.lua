-- Lua provided by RyzenAPI
-- Game: Dear Flower Demo

-- MAIN APPLICATION
addappid(3077810)
-- Game: addappid(3077810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077811, 1, "16d6a1463f138d75cdecfbf21f5a42eb58cee9654e63146826d18a7513bb0888")
