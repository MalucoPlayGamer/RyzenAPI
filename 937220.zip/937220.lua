-- Lua provided by RyzenAPI
-- Game: Escape parking lot

-- MAIN APPLICATION
addappid(937220)

-- MAIN APP DEPOTS / PACKAGES
addappid(937221, 1, "f8632c882c810a580aad45b45f9e07b207fe0d1c10dfd595893702e1011a6a95")

