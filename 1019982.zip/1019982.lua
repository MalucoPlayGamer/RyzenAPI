-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Fa Zheng Special Scenario / 法正「追加ＩＦシナリオセット」

-- MAIN APPLICATION
addappid(1019982)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019982,0,"4e7873685bc38986589e041284bcbf96ca424975227652c05e1d5c41a5dc2d07")
