-- Lua provided by RyzenAPI
-- Game: Muck

-- MAIN APPLICATION
addappid(1625450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1625451, 1, "37cedf0a2e524d663807b46c0c03f367932edd3a3f8900eb514410b9412a396c")
addappid(1625452, 1, "70087d06cccd09cddacf78bb63342a2f4ae4b524e18cb0475ce86c9bca0844f4")
addappid(1625453, 1, "3ac10fa4af0ac12d41e87d9376792faca9de54f1d78dfda05944b400b02d0cde")
