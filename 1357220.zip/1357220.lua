-- Lua provided by RyzenAPI
-- Game: PogoChamp

-- MAIN APPLICATION
addappid(1357220)
-- Game: addappid(1357220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357221, 1, "47eb579d279ae3a2a93674e81b3efc0acbe8c67aaba2234300dd41c06aacb9e9")
