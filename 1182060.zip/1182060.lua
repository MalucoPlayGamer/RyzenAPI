-- Lua provided by RyzenAPI
-- Game: Heavens Tournament

-- MAIN APPLICATION
addappid(1182060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182061, 1, "560e549b82332257e1445b37d8db5629b77425adeecbbcaac48fbbdc0d4f3f5d")
