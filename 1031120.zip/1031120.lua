-- Lua provided by RyzenAPI
-- Game: Bakery Simulator

-- MAIN APPLICATION
addappid(1031120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031121, 1, "57e801f7c005d043431cad876ad2f1ba922599948edc89b0719419db4d6b0537")
