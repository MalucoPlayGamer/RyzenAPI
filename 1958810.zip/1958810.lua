-- Lua provided by RyzenAPI
-- Game: My Bunny Girl

-- MAIN APPLICATION
addappid(1958810)
addappid(2105720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1958811, 1, "44c06ae5c18b3c34384e45cf2fecfc73cd5347f0c7355bb960ee122e4fa29d71")

