-- Lua provided by RyzenAPI
-- Game: 1032120

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(1032120)
addappid(1032121)
addappid(1032122)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032123,0,"0890a33e2782001727b3c332d3e2902627f070b2bbbcfa6f6489242f4bf4f1f8")
