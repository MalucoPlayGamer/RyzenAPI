-- Lua provided by RyzenAPI
-- Game: Bloodstained: Curse of the Moon 2

-- MAIN APPLICATION
addappid(1257360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1257361, 1, "6fb123b654ad793d825819c53cd2937c2a1921fc1761afb911616ad5b45d8359")

