-- Lua provided by RyzenAPI
-- Game: Bloodstained: Curse of the Moon 2

-- MAIN APPLICATION
addappid(1257360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257361, 1, "6fb123b654ad793d825819c53cd2937c2a1921fc1761afb911616ad5b45d8359")
