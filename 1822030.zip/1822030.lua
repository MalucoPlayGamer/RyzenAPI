-- Lua provided by RyzenAPI 
-- Game: The Library of Babel
addappid(1822030)
addappid(1822031, 1, "0a7630d93218eb433a6c0736613fedc721703adb2a7c139f448ec342253b247e")
