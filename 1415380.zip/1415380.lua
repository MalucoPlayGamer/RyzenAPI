-- Lua provided by RyzenAPI
-- Game: Overlay Studio

-- MAIN APPLICATION
addappid(1415380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415381, 1, "b2d9799f1630643335c18e7f631c361313a5ca82653d92ca431041c5cb6b2169")

