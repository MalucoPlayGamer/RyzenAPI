-- Lua provided by RyzenAPI
-- Game: Mosaique Neko Waifus 3

-- MAIN APPLICATION
addappid(1385730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385731, 1, "99dbffb143d18187dfdc5a4ea1c5f54ec37c3427011c13dd341be6289ac8dc79")
addappid(1385732, 1, "4832229f934867519f3ed58992f359ae673f68dc708a45e2be6aff794e402069")
addappid(1389910, 0, "07adac6cc5d0aac874d02c24edc4fb481eb2c6e8568ba56067a6aa9d0d749ca3")
addappid(1389911, 0, "e9623cb9009c8ea8aa41348fe60556ad19a2cb66bd5755f5e6e8684314f4ecd1")
addappid(1448980, 0, "82e432f1a97ca9ddbd892a3b30ce0088ca5170fbebfda1877fb53c6cbfd5e1f4")

