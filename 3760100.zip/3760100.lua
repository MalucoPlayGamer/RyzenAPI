-- Lua provided by RyzenAPI
-- Game: 8 Ball by Pokerist™

-- MAIN APPLICATION
addappid(3760100)

