-- Lua provided by RyzenAPI
-- Game: AppID 371100

-- MAIN APPLICATION
addappid(371100)

-- MAIN APP DEPOTS / PACKAGES
addappid(371101, 1, "1270b8700bfe2da0072f90828b88d20ec8207d3734d726c10deebc479bef87a1")
addappid(439900, 0, "5bd7c74fe6ca4650935d4d5c7c3eadd9d9020b5b0972ecae53a10ba7f52da70e")
addappid(443750, 0, "deb2192ab842f942a44a35856db0e3d14dd097af4bfb57ec354090a4a24f0ca7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(371350)
addappid(374660)
addappid(395690)
addappid(581080)
addappid(742310)
addappid(829360)
addappid(1468710)
addappid(1610050)
addappid(1630620)
addappid(1695720)
addappid(1794090)
addappid(4909560)
