-- Lua provided by RyzenAPI
-- Game: addappid(371100)

-- MAIN APPLICATION
addappid(371100)

-- MAIN APP DEPOTS / PACKAGES
addappid(371101, 1, "1270b8700bfe2da0072f90828b88d20ec8207d3734d726c10deebc479bef87a1")
addappid(439900, 0, "5bd7c74fe6ca4650935d4d5c7c3eadd9d9020b5b0972ecae53a10ba7f52da70e")
addappid(443750, 0, "deb2192ab842f942a44a35856db0e3d14dd097af4bfb57ec354090a4a24f0ca7")
