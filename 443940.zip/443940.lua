-- Lua provided by RyzenAPI
-- Game: 443940

-- MAIN APPLICATION
addappid(443940)
-- Game: addappid(443940)

-- MAIN APP DEPOTS / PACKAGES
addappid(443941, 1, "fbec11864ac91f5a8ed4e899780eb479f06240770afac4aa653ea743d0e783ad")
