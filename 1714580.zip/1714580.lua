-- Lua provided by RyzenAPI
-- Game: moon: Remix RPG Adventure

-- MAIN APPLICATION
addappid(1714580)
-- Game: addappid(1714580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714581, 1, "da20e98796446f3813cbb4a2d102ee79e6ecf10fc1caa1be6730b54cd2d0cf84")
