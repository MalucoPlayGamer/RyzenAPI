-- Lua provided by RyzenAPI
-- Game: addappid(1568330)

-- MAIN APPLICATION
addappid(1568330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568331, 1, "963a25cdee0d6cd4f909877b5c7608fb3d229e932220a758b74ed329e3503ecd")
