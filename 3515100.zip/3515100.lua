-- Lua provided by RyzenAPI
-- Game: 3515100

-- MAIN APPLICATION
addappid(3515100)
-- Game: addappid(3515100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515102,0,"8e42f89add75524c3403f231b74c3bd0bec10c7ded64c7ef7f288352c1dc828d")
addappid(3515103,0,"c32c0c4d30d4b4e2e2ce96ff082e745c0bd9082f84e43ef3afd23e2ef3a02a11")
