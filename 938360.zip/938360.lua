-- Lua provided by RyzenAPI
-- Game: The last soldier

-- MAIN APPLICATION
addappid(938360)

-- MAIN APP DEPOTS / PACKAGES
addappid(938361, 1, "72fa4aed719a6a1ae1de87065485f0854129455cd85cbb10b5c19b506d451865")
