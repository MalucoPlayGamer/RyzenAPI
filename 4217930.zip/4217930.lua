-- Lua provided by RyzenAPI
-- Game: Briar Flame

-- MAIN APPLICATION
addappid(4217930)

-- MAIN APP DEPOTS / PACKAGES
addappid(4217932,0,"0eaa8e9e3a4109cab316198cc1691998b8453bb0b36765bca8efcc1fcff16b2e")

