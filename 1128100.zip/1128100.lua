-- Lua provided by RyzenAPI
-- Game: addappid(1128100)

-- MAIN APPLICATION
addappid(1128100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128101, 1, "a4f4fffe7a5a98b642b65a0027c6052354eeaa74ed9eecdac0bc6d9c57cb1a26")
