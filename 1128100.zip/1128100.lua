-- Lua provided by RyzenAPI
-- Game: ZeroZone2020

-- MAIN APPLICATION
addappid(1128100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128101, 1, "a4f4fffe7a5a98b642b65a0027c6052354eeaa74ed9eecdac0bc6d9c57cb1a26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
