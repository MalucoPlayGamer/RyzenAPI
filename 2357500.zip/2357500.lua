-- Lua provided by RyzenAPI 
-- Game: URBANO - Legends' Debut Demo
addappid(2357500)
addappid(2357501, 1, "e3374c93e71e578153b9a5c4dd46016d201953c88da66702e94c38dea396f8c0")
