-- Lua provided by RyzenAPI
-- Game: Game: Starcom: Nexus

-- MAIN APPLICATION
addappid(863590)
-- Game: addappid(863590)

-- MAIN APP DEPOTS / PACKAGES
addappid(863591, 1, "db7a2cd3ad55071a76ecec3c88f1a77d05d1269d77104a82e17713dc717d79c9")
