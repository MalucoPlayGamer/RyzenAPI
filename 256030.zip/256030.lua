-- Lua provided by RyzenAPI
-- Game: AppID 256030

-- MAIN APPLICATION
addappid(256030)
addappid(327191)
addappid(334090)

-- MAIN APP DEPOTS / PACKAGES
addappid(256031, 1, "80e47623309ec24b86e96145c26cb5893689f6406cceef0c1f2c7c1291a878fe")
