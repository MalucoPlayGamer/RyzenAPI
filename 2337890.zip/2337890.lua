-- Lua provided by RyzenAPI
-- Game: addappid(2337890)

-- MAIN APPLICATION
addappid(2337890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337891, 1, "9ba517803ffaff460844a88c69a7772eaeec378ca0e21f306f6da45c27eb0dc8")
