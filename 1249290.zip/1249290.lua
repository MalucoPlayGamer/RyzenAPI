-- Lua provided by RyzenAPI
-- Game: The Curse of Zigoris

-- MAIN APPLICATION
addappid(1249290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1249291, 1, "4f98d9082bdbccda8513dba36bc5f07374073448f031b437d3821f9faae77a39")

