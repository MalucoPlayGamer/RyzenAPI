-- Lua provided by RyzenAPI
-- Game: addappid(1249290)

-- MAIN APPLICATION
addappid(1249290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249291, 1, "4f98d9082bdbccda8513dba36bc5f07374073448f031b437d3821f9faae77a39")
