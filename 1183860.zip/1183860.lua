-- Lua provided by RyzenAPI
-- Game: 1183860

-- MAIN APPLICATION
addappid(1183860)
-- Game: addappid(1183860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183861, 1, "783e2bcf9d724722f44b71f6a3c7f6ca638b8e1fb97741a6f14f2c315aa6d1f3")
