-- Lua provided by RyzenAPI
-- Game: addappid(2516550)

-- MAIN APPLICATION
addappid(2516550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516551, 1, "425f9ab654ebbf7924ac82dd4a1290a0a864480c5fccdc800a1cd4d02db71eda")
