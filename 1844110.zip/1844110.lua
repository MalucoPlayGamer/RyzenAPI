-- Lua provided by RyzenAPI
-- Game: The Legend of the War Axe

-- MAIN APPLICATION
addappid(1844110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1844111, 1, "5cfe33829701e3edd243303fc881d47e148a344bee8e486e9c820d992207a577")

