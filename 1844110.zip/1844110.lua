-- Lua provided by RyzenAPI
-- Game: Game: AppID 1844110

-- MAIN APPLICATION
addappid(1844110)
-- Game: addappid(1844110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844111, 1, "5cfe33829701e3edd243303fc881d47e148a344bee8e486e9c820d992207a577")
