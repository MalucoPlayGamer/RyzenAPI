-- Lua provided by RyzenAPI
-- Game: Defeated Girl

-- MAIN APPLICATION
addappid(1205260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205261, 1, "273be4305abaa152fedde0b8c1b7c33a431055ebfc7ea338e371263a771757ad")
addappid(1436060, 0, "a6ff8bba105cdceb0a3de91fa302b8588b8d3c90245b8a32743132302d99d8ee")
