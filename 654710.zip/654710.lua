-- Lua provided by RyzenAPI
-- Game: 654710

-- MAIN APPLICATION
addappid(654710)
-- Game: addappid(654710)

-- MAIN APP DEPOTS / PACKAGES
addappid(654711, 1, "97af88454b4937440bdb6392a4623e0697d1aa04ac171b1527203e9cc1727ebb")
