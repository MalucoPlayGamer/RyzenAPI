-- Lua provided by RyzenAPI
-- Game: Game: Horror Tale 2: Samantha

-- MAIN APPLICATION
addappid(2258910)
-- Game: addappid(2258910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258911, 1, "389e151fbf80818e02506697377087967789fc3de85d73a60e7db7ffceb244ff")
