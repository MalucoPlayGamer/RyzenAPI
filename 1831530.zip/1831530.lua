-- Lua provided by RyzenAPI
-- Game: 1831530

-- MAIN APPLICATION
addappid(1831530)
-- Game: addappid(1831530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831531, 1, "e677d1d05b128d4407c2fa0cf2728bac13c1b3325a7098a54c0ee438ef457de4")
