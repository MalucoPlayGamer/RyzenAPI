-- Lua provided by RyzenAPI 
-- Game: PC Creator - PC Building Simulator
addappid(1831530)
addappid(1831531, 1, "e677d1d05b128d4407c2fa0cf2728bac13c1b3325a7098a54c0ee438ef457de4")
