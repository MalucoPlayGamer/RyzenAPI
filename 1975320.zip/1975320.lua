-- Lua provided by RyzenAPI
-- Game: Kronos: Titan of Time

-- MAIN APPLICATION
addappid(1975320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975321, 1, "39dd8b9fdf11044d2a2434ae623f1b0aa3c2a13940b0e1aed1a42b81a77ff681")

