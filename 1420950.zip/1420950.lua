-- Lua provided by RyzenAPI
-- Game: addappid(1420950)

-- MAIN APPLICATION
addappid(1420950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420951, 1, "04e12769315ac7b8e4a5e4ab787a4315fb919545d79d9f46d928f2aab0532fdd")
