-- Lua provided by RyzenAPI
-- Game: Game Tycoon 1.5

-- MAIN APPLICATION
addappid(273770)
-- Game: addappid(273770)

-- MAIN APP DEPOTS / PACKAGES
addappid(273771, 1, "820bbdc6d60215d28a608c0513071df56c39727376aa47ea8be303a0c64d8ec2")
addappid(273772, 1, "698474ba667b986e311ff7c56c39dbc55f8923ee7edb002396b8806d040e26ae")
addappid(273773, 1, "d1e240027b7c8d61cc42e481b550599ecdf0d6fd95a5e198bd7142603c7a1e28")
