-- Lua provided by RyzenAPI
-- Game: Minigunner®

-- MAIN APPLICATION
addappid(1778200)
-- Game: addappid(1778200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778201, 1, "bba6df15eef10f28f6d5340f9c79b222c7153831ff789a701fe65ba4dfeeb07c")
