-- Lua provided by RyzenAPI
-- Game: DEFENDit

-- MAIN APPLICATION
addappid(2859300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859301, 1, "bf3f44b8e38781383db7cc70882f4822e8147e9f7c4f0bd14dd43f700db95a97")
addappid(2859302, 1, "64bf3a4ff575bb16e4117562a06c996496e856911d9c236f50a1856ceda0d294")
addappid(2859303, 1, "945fe05d0b8b80213dcb8a9b83c33ddbd055113e2306a327b699b1d714b28e65")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2934720)
addappid(2934730)
