-- Lua provided by RyzenAPI
-- Game: 751500

-- MAIN APPLICATION
addappid(751500)

-- MAIN APP DEPOTS / PACKAGES
addappid(751502,0,"d13a068fc95943b022fd6fc951dbb4d3e44a3fc0afb6b896ca36e88c49205bcd")

