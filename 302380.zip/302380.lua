-- Lua provided by RyzenAPI
-- Game: Game: Floating Point

-- MAIN APPLICATION
addappid(302380)
-- Game: addappid(302380)

-- MAIN APP DEPOTS / PACKAGES
addappid(302381, 1, "8e5119e90726fc95842985c103b7abee4e4089ffc1cbe38025468ad457ae814d")
addappid(302382, 1, "e00b4976fdc1a922bb623513950bf00415f21e3acd5e76e21bff2fb07334ccef")
addappid(302383, 1, "781e961b2e35c6eb76d18bed6d583163817a5193d1397c45e0e1a5b657f0736f")
