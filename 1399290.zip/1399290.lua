-- Lua provided by RyzenAPI
-- Game: addappid(1399290)

-- MAIN APPLICATION
addappid(1399290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399291, 1, "a69293cb49494c2de8dc6453a226b70aef1d7e771caf626523c26f43c99fd4c9")
