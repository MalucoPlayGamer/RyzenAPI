-- Lua provided by RyzenAPI 
-- Game: Dead Realm
addappid(352460)
addappid(352461, 1, "4368d382f519064123feb9eabb59b48b9884fcfcc2456c8b5ddc6673718e0412")
addappid(352462, 1, "0fed7d60d98e69ef176459d50b7bb3a00e49f48d2ba47a27ccfc755da6fc9780")
addappid(352463, 1, "d98945329fbca284f3264cd3fe646a69165264e6712c99daed0e0506d59eebbe")
addappid(414520)
