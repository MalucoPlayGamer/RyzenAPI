-- Lua provided by RyzenAPI
-- Game: Soul's Chronicle: Immortal Slayer

-- MAIN APPLICATION
addappid(2731940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2731941, 1, "02b73832079fe99ed02d94d960a0984f0d0c0effc7cb6c9715e3dd604298ef69")
