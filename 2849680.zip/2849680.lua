-- Lua provided by RyzenAPI
-- Game: Utopia Must Fall

-- MAIN APPLICATION
addappid(2849680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2849682,0,"04eb002fd372794240aea910d074b4fa5053ffa017edc9d8d8bc5b5237e32434")

