-- Lua provided by RyzenAPI
-- Game: Utopia Must Fall

-- MAIN APPLICATION
addappid(2849680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2849682,0,"04eb002fd372794240aea910d074b4fa5053ffa017edc9d8d8bc5b5237e32434")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
