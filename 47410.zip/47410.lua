-- Lua provided by RyzenAPI
-- Game: Game: Stronghold Kingdoms

-- MAIN APPLICATION
addappid(47410)
addappid(248160)
-- Game: addappid(47410)

-- MAIN APP DEPOTS / PACKAGES
addappid(47411, 1, "0836de33ebc86cd7ffc32203bfb0bc1a42be066a67441a1d18dd61150f2be03d")
addappid(47412, 1, "c593b90a6f24104570d03c100c56c75f5f37d0c0a63954e9360377971f28a3fd")
addappid(47413, 1, "86f83f0a94835e67ace24b2e4dded051ec0acb0af40f432b32bcaa161f58fc2c")
addappid(47414, 1, "fedf1951cf6bfb4b7962388e4fe6d2f81ad7cb6eea66d1fe417010ed9f4d21d4")
addappid(47415, 1, "02e70bb761d555e58ae7394268846623e30136e4a1da2d5444957d5bd73d8f1f")
addappid(47416, 1, "61db28233a9ccf2078d133ef25b78f235d5bbb0928ad36d8fa52ecc7c9fa1f20")
addappid(47417, 1, "b4ef077546abef3cd03b65501c388c09ab30e2a9925c26f0e2d52d5f4ffa875e")
addappid(47418, 1, "3e766c18f984b3dd399427349cbfad23bdedc29b679cf9c4973078fd1a892cc7")
addappid(47419, 1, "8e2f8a525b5a1feac35be72ecb9397ee02f471863e637bb88affc4b7c370039c")
addappid(248161, 1, "eccb6ee6074dd3af69aade4a4ff2746ab248af8adcba915216a475d14936b906")
addappid(248162, 1, "da28990964382ee5d0e9cca134c696cbceddf5d8d977ed188186184bf7c702fd")
addappid(248163, 1, "c3bdc5aedf9b55fbffb6ac0395d3608cc9c49bd1ea24ddea5507be8f62ae7b08")
