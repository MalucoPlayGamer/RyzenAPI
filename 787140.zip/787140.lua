-- Lua provided by RyzenAPI
-- Game: The Adventures of Kusoge

-- MAIN APPLICATION
addappid(787140)

-- MAIN APP DEPOTS / PACKAGES
addappid(787141, 1, "c6f8b3a0b74a506703696dc9a3627b63f719415ec2108772df3e45b9fb073b18")
