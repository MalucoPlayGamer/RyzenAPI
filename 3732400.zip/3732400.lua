-- Lua provided by RyzenAPI
-- Game: 3732400

-- MAIN APPLICATION
addappid(3732400)
-- Game: addappid(3732400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3732401, 1, "fb1dbde2a73819f0f585a35d3ce345f8d366f4dd7ba1f1210e99af737e02e48d")
