-- Lua provided by RyzenAPI
-- Game: addappid(762900)

-- MAIN APPLICATION
addappid(762900)

-- MAIN APP DEPOTS / PACKAGES
addappid(762901, 1, "74005a4e6c65755fa313b67be727faf9c65a6d1caf67d459e143f4364c329a8a")
