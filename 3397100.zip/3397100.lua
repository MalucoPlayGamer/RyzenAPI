-- Lua provided by RyzenAPI
-- Game: Eye of the Incubus

-- MAIN APPLICATION
addappid(3397100) -- Eye of the Incubus

-- MAIN APP DEPOTS / PACKAGES
addappid(3397101, 1, "06bb5f6152fb9b698177672be584f46b06ab0f473276fbb4f53dab83facf2829") -- Depot 3397101
addtoken(3397100, "9638877320527686269")

