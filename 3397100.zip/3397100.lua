-- 3397100's Lua and Manifest Created by Hubcap Manifest
-- Eye of the Incubus
-- Created: August 13, 2026 at 04:06:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3397100) -- Eye of the Incubus
addtoken(3397100, "9638877320527686269")
-- MAIN APP DEPOTS
addappid(3397101, 1, "06bb5f6152fb9b698177672be584f46b06ab0f473276fbb4f53dab83facf2829") -- Depot 3397101
setManifestid(3397101, "4947601607254722173", 435332365)