-- Lua provided by RyzenAPI
-- Game: Counter Terrorist Agency

-- MAIN APPLICATION
addappid(936490)

-- MAIN APP DEPOTS / PACKAGES
addappid(936492,0,"c4e91508aa5946d16ed15760ea1cb3f56416a8c6d2fa24c2d919d9fe95d014e3")
addappid(936494,0,"d62361cfb38842dce830377bcc9ef6e6aef367f99b91821906c2ba95a53a6411")
