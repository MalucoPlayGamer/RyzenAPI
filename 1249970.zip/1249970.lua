-- Lua provided by RyzenAPI
-- Game: Test Drive Unlimited Solar Crown

-- MAIN APPLICATION
addappid(1249970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249971, 1, "ef894cda9509eea638e332e510f8d089c04994ef8ffafdfd3cc721414b0b4176")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2515670)
addappid(2515680)
addappid(2515690)
addappid(2515700)
