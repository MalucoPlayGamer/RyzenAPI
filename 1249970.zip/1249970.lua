-- Lua provided by RyzenAPI
-- Game: Test Drive Unlimited Solar Crown

-- MAIN APPLICATION
addappid(1249970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249971, 1, "ef894cda9509eea638e332e510f8d089c04994ef8ffafdfd3cc721414b0b4176")
