-- Lua provided by RyzenAPI
-- Game: Grim Tales: The Heir Collector's Edition

-- MAIN APPLICATION
addappid(1709450)
-- Game: addappid(1709450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709451, 1, "25197b687b5ea877f4c62af49bd36b20864bbecee24719a5b8074082e77c4fb6")
