-- Lua provided by RyzenAPI
-- Game: NO-GO

-- MAIN APPLICATION
addappid(941710)
addappid(941711)
-- Game: addappid(941710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986,0,"51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
