-- Lua provided by RyzenAPI 
-- Game: 小明明的世界 Playtest
addappid(3442200)
addappid(3442201, 1, "f96197f5754033405c29d89a67a46ff6266177f284044c29dd1b6d9a29623559")
