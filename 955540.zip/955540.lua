-- Lua provided by RyzenAPI
-- Game: Telecube Nightmare

-- MAIN APPLICATION
addappid(955540)

-- MAIN APP DEPOTS / PACKAGES
addappid(955541, 1, "083d9061d546cabc841939c686c49e2b29b7d22b5c3cc4e69cc1040b4902288e")
addappid(955542, 1, "edd499b40558959f45bd3235d36d2ccb0706f7b3f6196fb0a61e9d0fc1d3aa99")

