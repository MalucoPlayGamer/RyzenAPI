-- Lua provided by RyzenAPI
-- Game: Physics Lab VR

-- MAIN APPLICATION
addappid(2660960)
-- Game: addappid(2660960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660960,0,"cd5bd7e435da7b913c742abab051321c57ac76f363dd98a80461cbe95a5a9993")
