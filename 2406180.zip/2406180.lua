-- Lua provided by RyzenAPI
-- Game: Game: Knights Within

-- MAIN APPLICATION
addappid(2406180)
-- Game: addappid(2406180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406181, 1, "cbf06c72ee8bc46136ab7a5c23e3d46af32cbfe555d47996a9cd2c89eb57057e")
