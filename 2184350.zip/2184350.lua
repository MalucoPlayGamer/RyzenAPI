-- Lua provided by RyzenAPI
-- Game: Guild Saga: Vanished Worlds

-- MAIN APPLICATION
addappid(2184350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184351, 1, "2a999e283fd4e1e911dbf0b0af2cb0c12ad487fe85f8d9718b6ecf52971962ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
