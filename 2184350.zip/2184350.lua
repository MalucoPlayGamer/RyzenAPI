-- Lua provided by RyzenAPI
-- Game: 2184350

-- MAIN APPLICATION
addappid(2184350)
-- Game: addappid(2184350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184351, 1, "2a999e283fd4e1e911dbf0b0af2cb0c12ad487fe85f8d9718b6ecf52971962ba")
