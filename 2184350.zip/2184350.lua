-- Lua provided by SkyAPI 
-- Game: Guild Saga: Vanished Worlds
addappid(2184350)
addappid(2184351, 1, "2a999e283fd4e1e911dbf0b0af2cb0c12ad487fe85f8d9718b6ecf52971962ba")
