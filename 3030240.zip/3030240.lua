-- Lua provided by RyzenAPI
-- Game: Game: CuckTales 🐓

-- MAIN APPLICATION
addappid(3030240)
-- Game: addappid(3030240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3030241, 1, "d196a0a60d91dc67d747ca27048261548a1c480581b653e09127dec4d395d38b")
