-- Lua provided by RyzenAPI
-- Game: Liquor Store Simulator

-- MAIN APPLICATION
addappid(3124550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124551, 1, "bf645b5292497a17f5384bceec7196595e86a537fe89e23229bf6c759c32c75b")
