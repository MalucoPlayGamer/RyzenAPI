-- Lua provided by RyzenAPI
-- Game: Magic Technology

-- MAIN APPLICATION
addappid(614660)

-- MAIN APP DEPOTS / PACKAGES
addappid(614662,0,"3df6e48b1ac0028f31cf2d2e311bb5ca407d2e5c23a0907fa5f376e8e141ceb0")

