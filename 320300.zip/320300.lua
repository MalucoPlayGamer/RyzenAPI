-- Lua provided by SkyAPI 
-- Game: AppID 320300
addappid(320300)
addappid(320301, 1, "98fdac23d05484143a04a5f07b7e527a2fc6bdb3a67fdad7bb3618c258881097")
addappid(320302, 1, "f060b1696adfdb346ba2560f90ba8edbd44d77a97966ba45cefde74e428c8b48")
addappid(320303, 1, "050b356a267ad27d3165e65a202ebd97aab78dc3c671e1ffd3a93d6c2e9c85cc")
