-- Lua provided by RyzenAPI
-- Game: AppID 781040

-- MAIN APPLICATION
addappid(781040)

-- MAIN APP DEPOTS / PACKAGES
addappid(781041, 1, "d7a2d487300b623361413260e3243d3a4f2bf966cb62d4da048e1911d4160c39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
