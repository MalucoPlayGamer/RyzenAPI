-- Lua provided by RyzenAPI
-- Game: Game: AppID 781040

-- MAIN APPLICATION
addappid(781040)
-- Game: addappid(781040)

-- MAIN APP DEPOTS / PACKAGES
addappid(781041, 1, "d7a2d487300b623361413260e3243d3a4f2bf966cb62d4da048e1911d4160c39")
