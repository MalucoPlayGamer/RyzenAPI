-- Lua provided by RyzenAPI
-- Game: Game: AppID 890750

-- MAIN APPLICATION
addappid(890750)
-- Game: addappid(890750)

-- MAIN APP DEPOTS / PACKAGES
addappid(890751, 1, "c120388ae832eb14b8560566ad810c44c010199e945d9a76cc2f70736e4bdb29")
