-- Lua provided by RyzenAPI
-- Game: 3441190

-- MAIN APPLICATION
addappid(3441190)
-- Game: addappid(3441190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441191, 1, "497f9dc3fcd31ee69ac383a7171ea1216cb405afdfb1b0f43331c69b82b0663b")
