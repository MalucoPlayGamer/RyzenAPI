-- Lua provided by RyzenAPI
-- Game: Dead of Night: Supermarket

-- MAIN APPLICATION
addappid(3441190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3441191, 1, "497f9dc3fcd31ee69ac383a7171ea1216cb405afdfb1b0f43331c69b82b0663b")

