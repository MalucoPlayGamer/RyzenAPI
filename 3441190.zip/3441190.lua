-- Lua provided by SkyAPI 
-- Game: Dead of Night: Supermarket
addappid(3441190)
addappid(3441191, 1, "497f9dc3fcd31ee69ac383a7171ea1216cb405afdfb1b0f43331c69b82b0663b")
