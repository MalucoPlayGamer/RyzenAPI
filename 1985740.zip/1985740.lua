-- Lua provided by SkyAPI 
-- Game: Bugaboo Pocket
addappid(1985740)
addappid(1985741, 1, "a3252f3aa3682f681667989ab6df551e3683e9cc90488b7083056835f2694317")
