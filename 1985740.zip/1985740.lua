-- Lua provided by RyzenAPI
-- Game: Game: Bugaboo Pocket

-- MAIN APPLICATION
addappid(1985740)
-- Game: addappid(1985740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985741, 1, "a3252f3aa3682f681667989ab6df551e3683e9cc90488b7083056835f2694317")
