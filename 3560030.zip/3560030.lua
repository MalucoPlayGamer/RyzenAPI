-- Lua provided by RyzenAPI
-- Game: Cataclysm: The Last Generation

-- MAIN APPLICATION
addappid(3560030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3560032,0,"df8b392c9de333ef7bfee59fb54422ea32e3937a66623060c2d1de790d649e28")

