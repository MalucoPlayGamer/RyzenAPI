-- Lua provided by RyzenAPI
-- Game: Chill X

-- MAIN APPLICATION
addappid(1482580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482581, 1, "7723fc34db33e3b804fdbf34d02754d8b1e398385c32b75baf2477fddda01557")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
