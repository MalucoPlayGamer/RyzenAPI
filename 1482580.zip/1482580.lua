-- Lua provided by RyzenAPI
-- Game: Game: Chill X

-- MAIN APPLICATION
addappid(1482580)
-- Game: addappid(1482580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1482581, 1, "7723fc34db33e3b804fdbf34d02754d8b1e398385c32b75baf2477fddda01557")
