-- Lua provided by RyzenAPI
-- Game: Game: Azazel Gamble 阿撒兹勒赌局

-- MAIN APPLICATION
addappid(3438900)
-- Game: addappid(3438900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3438901, 1, "3c580d1ba9e9aeb45e2036fa247dbac3b1543bb2424428d986658b7ded82e0ec")
