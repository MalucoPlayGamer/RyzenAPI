-- Lua provided by RyzenAPI
-- Game: Sokpop S09: pyramida

-- MAIN APPLICATION
addappid(1390010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1390011, 1, "ebee0c8619d82eba352b57b389c7c382ba4460ee45b6bea98ed7644eaa3918a7")
