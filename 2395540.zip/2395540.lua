-- Lua provided by RyzenAPI
-- Game: MINDHACK Soundtrack

-- MAIN APPLICATION
addappid(2395540)
-- Game: addappid(2395540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395541, 1, "00e68ee22aee0cf8e9a6aeb798789059c4a30a982dea9d23b1b7d7dfd1f41951")
addappid(2395542, 1, "a52aa2297e16e2c73793bea6c9d0c6e1e1fb38790595ce5cb3b80ec8c127316f")
