-- Lua provided by RyzenAPI
-- Game: Ethereal Legends

-- MAIN APPLICATION
addappid(428980)

-- MAIN APP DEPOTS / PACKAGES
addappid(428981, 1, "7c71032068ed56ee4a6569eb7da12a1d0a17bb5c1cdcf06dc05a8afd3790f7f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
