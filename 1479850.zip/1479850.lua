-- Lua provided by RyzenAPI
-- Game: Game: Chompy Chomp Chomp Party

-- MAIN APPLICATION
addappid(1479850)
addappid(2109490)
-- Game: addappid(1479850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479851, 1, "90c5671dc3089bab20cf660e3a0a4853767d736253c0240fb960c12b3bac4318")
