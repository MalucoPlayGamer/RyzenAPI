-- Lua provided by RyzenAPI
-- Game: Generic RPG Idle

-- MAIN APPLICATION
addappid(1858120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858121, 1, "b4e637ce5190784d1c1c9823b5281f573b49803db0e1e4b1080a5d4253e152ef")

