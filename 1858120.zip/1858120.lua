-- Lua provided by SkyAPI 
-- Game: Generic RPG Idle
addappid(1858120)
addappid(1858121, 1, "b4e637ce5190784d1c1c9823b5281f573b49803db0e1e4b1080a5d4253e152ef")
