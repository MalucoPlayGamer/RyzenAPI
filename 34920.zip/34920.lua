-- Lua provided by RyzenAPI
-- Game: Razor2: Hidden Skies

-- MAIN APPLICATION
addappid(34920)
-- Game: addappid(34920)

-- MAIN APP DEPOTS / PACKAGES
addappid(34921, 1, "2cbe72261407a037572b86c30b7e41fbfe9ac66fa32e965df064ccee83e1c23f")
