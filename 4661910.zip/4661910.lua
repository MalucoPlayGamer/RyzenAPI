-- Lua provided by RyzenAPI
-- Game: Nexus Legacy

-- MAIN APPLICATION
addappid(4661910)

