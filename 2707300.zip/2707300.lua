-- Lua provided by RyzenAPI
-- Game: Cosmic Collapse

-- MAIN APPLICATION
addappid(2707300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707302,0,"593bdb1b0992957231e8ba33bcda688dd9e707f9727bb9456c1c75dd39bc4f31")
