-- Lua provided by RyzenAPI 
-- Game: AppID 1472960
addappid(1472960)
addappid(1472961, 1, "c528916519bed8a4b3dcacea3a1938163ef50c6dba4a6990ddb77d31305a0ced")
