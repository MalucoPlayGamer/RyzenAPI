-- Lua provided by RyzenAPI
-- Game: Fabulous - Angela's Fashion Fever

-- MAIN APPLICATION
addappid(540060)
addappid(549960)

-- MAIN APP DEPOTS / PACKAGES
addappid(540061, 1, "99ce312a1cdf41e4c776d2892b16686f6d0144911b02a59b24135e4e3f9a3d26")
addappid(540062, 1, "1fd1a6ec71d0c429e77da65d1ec444dbc9d8952d67e653f7a81a9132e7d43427")

