-- Lua provided by RyzenAPI
-- Game: addappid(2012420)

-- MAIN APPLICATION
addappid(2012420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2012421, 1, "e5b7b47ef96df69fffd7d8cf710a2fc2560bc65b7969fc9b2cc4a1fe11e50e3c")
