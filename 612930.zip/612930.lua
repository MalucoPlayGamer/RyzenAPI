-- Lua provided by RyzenAPI 
-- Game: Fight of Gods
addappid(612930)
addappid(612931, 1, "82300cdaf47aa3f2a7591463173a4e22ea5a9cd50be44cfeea106c7e80fd5494")
addappid(782620, 1, "49cfe15c49090f69816ad6470c18e5d8b44fb072d9b00f3baea16976f94789e2")
addappid(654190)
