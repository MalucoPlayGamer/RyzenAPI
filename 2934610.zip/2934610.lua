-- Lua provided by RyzenAPI
-- Game: Bober Constructions

-- MAIN APPLICATION
addappid(2934610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934611, 1, "ba277d107d2558f2f17af73285c5c430976a504cdf538bf6ceef0d6499cff22f")
