-- Lua provided by RyzenAPI
-- Game: I Can't Believe It's Not Gambling GOTY Edition

-- MAIN APPLICATION
addappid(733990)

-- MAIN APP DEPOTS / PACKAGES
addappid(733991, 1, "66b64e7a0b502e793377ddda339b3036b3a6701731d390a1fe6ee83d173b9321")
addappid(733993, 1, "0c74e154005f607772a169242c6385ee79fa3520038a2620ef04771a7f5e8eb3")

