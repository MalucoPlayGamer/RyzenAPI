-- Lua provided by RyzenAPI
-- Game: inZOI

-- MAIN APPLICATION
addappid(2456740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2456741, 1, "e91cba2d1d471bdfb115bee76ac997858f84e6ab0a82af5f17d0054f8a3c9686")
addappid(3887680, 0, "25ed1bd4d03ac4fd1a739171c82248fe6db511beea87dccfe33721091039e9c8")

