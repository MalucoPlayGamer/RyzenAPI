-- Lua provided by RyzenAPI
-- Game: 586620

-- MAIN APPLICATION
addappid(586620)
-- Game: addappid(586620)

-- MAIN APP DEPOTS / PACKAGES
addappid(586621, 1, "76e5e98b570b0cbc3cbbacc07121b7eeb5344681724d9a66f02ccb026954eb07")
