-- Lua provided by RyzenAPI 
-- Game: AppID 586620
addappid(586620)
addappid(586621, 1, "76e5e98b570b0cbc3cbbacc07121b7eeb5344681724d9a66f02ccb026954eb07")
