-- Lua provided by RyzenAPI 
-- Game: Apocalive
addappid(1989800)
addappid(1989801, 1, "3ef0ed04bc16ed654f2addf9bd7e5038f36f4c8a8992ade4f4660cbc8f960cf1")
