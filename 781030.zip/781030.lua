-- Lua provided by RyzenAPI
-- Game: DK Online

-- MAIN APPLICATION
addappid(781030)
-- Game: addappid(781030)

-- MAIN APP DEPOTS / PACKAGES
addappid(781031, 1, "74ce13b1a812b04f539853e106dde560649c458c94592d4f8bf2cf810a776823")
