-- Lua provided by RyzenAPI
-- Game: DK Online

-- MAIN APPLICATION
addappid(781030)

-- MAIN APP DEPOTS / PACKAGES
addappid(781031, 1, "74ce13b1a812b04f539853e106dde560649c458c94592d4f8bf2cf810a776823")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2216020)
addappid(2216021)
addappid(2216022)
addappid(2216023)
addappid(2216024)
addappid(2691770)
addappid(2732120)
addappid(2732130)
addappid(2732140)
addappid(2752540)
addappid(2752550)
addappid(3332290)
addappid(3332300)
addappid(4115630)
addappid(4115640)
addappid(4115650)
addappid(4115660)
addappid(4115670)
addappid(4310060)
addappid(4310070)
