-- Lua provided by RyzenAPI 
-- Game: DK Online
addappid(781030)
addappid(781031, 1, "74ce13b1a812b04f539853e106dde560649c458c94592d4f8bf2cf810a776823")
