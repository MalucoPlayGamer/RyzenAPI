-- Lua provided by RyzenAPI
-- Game: Game: Kaodi

-- MAIN APPLICATION
addappid(3325570)
-- Game: addappid(3325570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3325571, 1, "d70aee716a0b7c675413abf222e42186d7f182305ca95643aca362740d39021b")
