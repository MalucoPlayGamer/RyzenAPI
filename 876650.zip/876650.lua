-- Lua provided by RyzenAPI
-- Game: Aground

-- MAIN APPLICATION
addappid(876650)

-- MAIN APP DEPOTS / PACKAGES
addappid(876651, 1, "51839908ab76ff543b63bc94d1d74a75931d453eb14c113b57e168df3fbbf382")
addappid(876652, 1, "f30f53c32eff36b1f5c87c8031438bab2762337d3f12600023d1e0d4330fff8a")
addappid(876653, 1, "4c184ded5deafa43eb4bea5ce88affb5ecc3574bb7cc574101e0d4376eecb960")
addappid(876654, 1, "0180086f402ebb4cd72e8b817ed515bd7f6874c27b8d7cd6c5488b3495859268")
addappid(876655, 1, "1b051f826d2356d07908e28fabf1fa9e537940f9a74c3975683866b2cbaa365d")
addappid(876656, 1, "1799dc6bdfe55cb5f40ad3e9b65279803f2fa7274404114985beb76f92f91c86")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2382320)
