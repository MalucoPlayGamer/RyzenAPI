-- Lua provided by RyzenAPI
-- Game: addappid(2343710)

-- MAIN APPLICATION
addappid(2343710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343711, 1, "58654840de1c15a98299bdbac30944e45db2cb06cb833e059c0dd852026a28d0")
