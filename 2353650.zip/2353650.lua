-- Lua provided by RyzenAPI
-- Game: DobbyxEscape: Pirate Adventure

-- MAIN APPLICATION
addappid(2353650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353651, 1, "2c9d6ddb2afbcf270a60686fcfe37a9af60e48094e9fa6f6210146bc045b3e51")
