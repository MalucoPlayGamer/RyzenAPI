-- Lua provided by RyzenAPI
-- Game: Stirring Abyss

-- MAIN APPLICATION
addappid(1178210)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1178211, 1, "cadf0cbad96b458f1b53c28a36e868f61dafd32dccb834a1f4304decb9e5fae4")
addappid(1178212, 1, "adae6b8e3cef3afe9cf4e941c02493bdb5d5fdda98ed3449027728105aaecd21")
