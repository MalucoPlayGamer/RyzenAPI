-- Lua provided by RyzenAPI
-- Game: Ettrian - The Elf Prince

-- MAIN APPLICATION
addappid(2326510)
-- Game: addappid(2326510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326511, 1, "1cab6a5056cda715f92308cc6efb6aed5e60609421a561859c80bcc7f9ba3b01")
addappid(2326512, 1, "33ff85f9fb0343b48fa3eb766e1d556a7aa02c288f02f980759b0eedc3f56d32")
