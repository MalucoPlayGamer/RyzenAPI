-- Lua provided by RyzenAPI
-- Game: Game: AppID 787510

-- MAIN APPLICATION
addappid(787510)
-- Game: addappid(787510)

-- MAIN APP DEPOTS / PACKAGES
addappid(787511, 1, "ebe4e0aff13a1158c1bfa0252b693bc2a75d2eeae4886fd321ed6e062352c4d7")
