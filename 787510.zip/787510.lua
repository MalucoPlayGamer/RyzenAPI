-- Lua provided by RyzenAPI
-- Game: Muv-Luv Alternative Total Eclipse

-- MAIN APPLICATION
addappid(787510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(787511, 1, "ebe4e0aff13a1158c1bfa0252b693bc2a75d2eeae4886fd321ed6e062352c4d7")
