-- Lua provided by RyzenAPI
-- Game: Dunk It (VR Basketball)

-- MAIN APPLICATION
addappid(581920)

-- MAIN APP DEPOTS / PACKAGES
addappid(581921,0,"c80a851d13a4641ee15fc4c5cf7d7de0c9f0ab05233e47bdacbcaa92f90a98af")

