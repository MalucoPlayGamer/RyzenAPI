-- Lua provided by RyzenAPI
-- Game: Noctem

-- MAIN APPLICATION
addappid(1701740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701741, 1, "f7fda8a59b1898dfa9b17e3f9642b4b2f8655f5e3695ec5d6ba1dd70c58ba76c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
