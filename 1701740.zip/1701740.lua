-- Lua provided by RyzenAPI 
-- Game: Noctem
addappid(1701740)
addappid(1701741, 1, "f7fda8a59b1898dfa9b17e3f9642b4b2f8655f5e3695ec5d6ba1dd70c58ba76c")
