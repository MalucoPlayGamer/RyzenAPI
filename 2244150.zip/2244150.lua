-- Lua provided by SkyAPI 
-- Game: Tristia:restore
addappid(2244150)
addappid(2244151, 1, "f0d4377de0db51727ab217ee246ab4dfc23121d4b069e39b48d97eef43fffeb1")
