-- Lua provided by RyzenAPI
-- Game: 2244150

-- MAIN APPLICATION
addappid(2244150)
-- Game: addappid(2244150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244151, 1, "f0d4377de0db51727ab217ee246ab4dfc23121d4b069e39b48d97eef43fffeb1")
