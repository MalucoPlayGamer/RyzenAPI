-- Lua provided by RyzenAPI
-- Game: Tetra Project - 原石计划

-- MAIN APPLICATION
addappid(1017410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017411, 1, "5e652c3128a23b918478361b48b5443b923e499f76d4e2eb77b7aea21bbd06aa")
