-- Lua provided by RyzenAPI
-- Game: 1394100

-- MAIN APPLICATION
addappid(1394100)
-- Game: addappid(1394100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394101, 1, "03658f06687f568913af13ba249bf7b56f1a93a54c5294e516fb9adf0bb14fb9")
