-- Lua provided by RyzenAPI
-- Game: setManifestid(1756152,"8951238776732719013")

-- MAIN APPLICATION
addappid(1756150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756152,0,"a14b7d83de92daca34de64d7ca4024c2707dcd2da12d3c4dae44c347ed7a937f")

