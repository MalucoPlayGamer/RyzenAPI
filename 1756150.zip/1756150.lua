-- Lua provided by RyzenAPI
-- Game: SCP: Keter

-- MAIN APPLICATION
addappid(1756150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756152,0,"a14b7d83de92daca34de64d7ca4024c2707dcd2da12d3c4dae44c347ed7a937f")

