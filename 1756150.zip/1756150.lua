-- Lua provided by RyzenAPI
-- Game: SCP: Keter

-- MAIN APPLICATION
addappid(1756150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1756152,0,"a14b7d83de92daca34de64d7ca4024c2707dcd2da12d3c4dae44c347ed7a937f")

