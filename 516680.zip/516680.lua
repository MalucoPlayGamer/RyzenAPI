-- Lua provided by RyzenAPI
-- Game: AppID 516680

-- MAIN APPLICATION
addappid(516680)

-- MAIN APP DEPOTS / PACKAGES
addappid(516681, 1, "c17a06618c2f3fef5b1a94f4a0304f5f8f6b81917905937505ebdb21bcaaa33d")

