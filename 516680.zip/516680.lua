-- Lua provided by RyzenAPI
-- Game: AppID 516680

-- MAIN APPLICATION
addappid(516680)

-- MAIN APP DEPOTS / PACKAGES
addappid(516681, 1, "c17a06618c2f3fef5b1a94f4a0304f5f8f6b81917905937505ebdb21bcaaa33d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
