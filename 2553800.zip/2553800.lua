-- Lua provided by RyzenAPI
-- Game: 负罪者：方石

-- MAIN APPLICATION
addappid(2553800)
-- Game: addappid(2553800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553801, 1, "51f51058747be6025e322d4ab4939ad9c0148c9b99356bd084ece5d4842ea7b1")
