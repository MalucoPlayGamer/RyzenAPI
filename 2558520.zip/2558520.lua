-- Lua provided by RyzenAPI
-- Game: Slay the Dragon! The Fire-Breathing Tyrant Meets Her Match!

-- MAIN APPLICATION
addappid(2558520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2558521,0,"76bb9da9b68508775ed3b25d8fbb540dbb673cea6cd7caf85857379d8ea5fe33")

