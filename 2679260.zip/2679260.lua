-- Lua provided by RyzenAPI
-- Game: Game: Impact Trial: First Encounter

-- MAIN APPLICATION
addappid(2679260)
-- Game: addappid(2679260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2679261, 1, "77992cf3cf5c706a0fcff9bc860f334ea7b10220a208161779cfcc3590398e4b")
