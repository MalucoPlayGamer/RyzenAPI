-- Lua provided by RyzenAPI
-- Game: AppID 2415910

-- MAIN APPLICATION
addappid(2415910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415911, 1, "dc401cdc235301724bfae6beac758cc8d3096efef4a7ba5ca7e61729a1c86b28")

