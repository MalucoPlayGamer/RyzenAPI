-- Lua provided by RyzenAPI
-- Game: Game: AppID 654300

-- MAIN APPLICATION
addappid(654300)
-- Game: addappid(654300)

-- MAIN APP DEPOTS / PACKAGES
addappid(654301, 1, "77cdeaf227e2a8d5823e10c76103f7be20d0ab93a7811dafb87375962b5793e3")
