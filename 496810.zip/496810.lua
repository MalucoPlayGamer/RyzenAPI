-- Lua provided by RyzenAPI
-- Game: 496810

-- MAIN APPLICATION
addappid(496810)
-- Game: addappid(496810)

-- MAIN APP DEPOTS / PACKAGES
addappid(496811, 1, "6ef522608ec3691f9a3daffab5a9c2d1c4fee9b74c958bdfcf251f6e300addf0")
addappid(530580, 0, "7b747cc444451032398d9fa3473796e17e9ff536325fa5b3982c80148e7e22d7")
