-- Lua provided by RyzenAPI
-- Game: MegaTagmension Blanc + Neptune VS Zombies (Neptunia)

-- MAIN APPLICATION
addappid(496810)

-- MAIN APP DEPOTS / PACKAGES
addappid(496811, 1, "6ef522608ec3691f9a3daffab5a9c2d1c4fee9b74c958bdfcf251f6e300addf0")
addappid(530580, 0, "7b747cc444451032398d9fa3473796e17e9ff536325fa5b3982c80148e7e22d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
