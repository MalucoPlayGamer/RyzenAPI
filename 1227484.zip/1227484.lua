-- Lua provided by RyzenAPI
-- Game: RetroArch - Gearsystem

-- MAIN APPLICATION
addappid(1227484)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227484,0,"de0ded72e2d2541d274e45f8dec050ee7407e9fb68de9cf8fadc2976dcfa28c9")
addappid(1789790,0,"2d3d351f3b9c08a0eb56a71c085447cff34b8f43da10f070b16ca7626069c898")
addappid(1789791,0,"1800f64b6afbdad65d882b26e7e9ed6a34d5692de39a24123bbab746c0245048")

