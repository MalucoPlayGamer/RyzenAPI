-- Lua provided by RyzenAPI
-- Game: The Lonely Helmet

-- MAIN APPLICATION
addappid(1730310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730311, 1, "1888c330be4c20376bb89e83cbafda963e086b90d5812634bef0fde953afbbd4")
addappid(1730312, 1, "7180a2b6687e4fae2926bc3ceebfab8e9e5d26cc6931d6313c67763bfa5f0825")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
