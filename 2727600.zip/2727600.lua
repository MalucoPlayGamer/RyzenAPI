-- Lua provided by RyzenAPI
-- Game: 搜查一刻 Demo

-- MAIN APPLICATION
addappid(2727600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727601, 1, "5d2afa3cafe62f126b33d09b9422d12200e29bddfc663b8ad4dd94703d4582b9")

