-- Lua provided by RyzenAPI
-- Game: Game: AppID 1073490

-- MAIN APPLICATION
addappid(1073490)
-- Game: addappid(1073490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073491, 1, "3f883aecdfcbb31cffa9475a8d0361c94f37e310925fdb56838c6fb3030c0d86")
