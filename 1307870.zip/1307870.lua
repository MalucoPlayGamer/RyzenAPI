-- Lua provided by SkyAPI 
-- Game: AppID 1307870
addappid(1307870)
addappid(1307871, 1, "0ae29042276bba492741b04c8cb417cfa37fef21a2220ca9655b67139a27fb82")
