-- Lua provided by RyzenAPI
-- Game: addappid(1307870)

-- MAIN APPLICATION
addappid(1307870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307871, 1, "0ae29042276bba492741b04c8cb417cfa37fef21a2220ca9655b67139a27fb82")
