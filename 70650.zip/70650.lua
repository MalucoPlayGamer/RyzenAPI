-- Lua provided by RyzenAPI
-- Game: 70650

-- MAIN APPLICATION
addappid(70650)
-- Game: addappid(70650)

-- MAIN APP DEPOTS / PACKAGES
addappid(70651, 1, "d7449e5e166486044d81a2e7f9c5ef34009eeb58e2a2ad78daf23b34e0c286a4")
