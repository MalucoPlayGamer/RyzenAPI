-- Lua provided by RyzenAPI
-- Game: Dirty Girls

-- MAIN APPLICATION
addappid(1899170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899171, 1, "b014ffc50b6c52c5389a6943d47bbf4bac610beb9ac2ea09f5d9c6f79a53a4e8")
