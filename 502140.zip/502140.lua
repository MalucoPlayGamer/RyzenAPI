-- Lua provided by RyzenAPI
-- Game: Drayt Empire

-- MAIN APPLICATION
addappid(502140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(502141, 1, "43ff38b1aaa28288c82c8a13dae5982d53e1156240e424ddab36a4886d084c69")
