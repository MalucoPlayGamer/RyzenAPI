-- Lua provided by RyzenAPI
-- Game: 502140

-- MAIN APPLICATION
addappid(502140)
-- Game: addappid(502140)

-- MAIN APP DEPOTS / PACKAGES
addappid(502141, 1, "43ff38b1aaa28288c82c8a13dae5982d53e1156240e424ddab36a4886d084c69")
