-- Lua provided by RyzenAPI
-- Game: Ones and Zeroes

-- MAIN APPLICATION
addappid(879600)

-- MAIN APP DEPOTS / PACKAGES
addappid(879601,0,"f347cee539af06f661f5211264309bb35d14a247f426483c4242dec228a65a91")

