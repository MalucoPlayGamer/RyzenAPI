-- Lua provided by RyzenAPI
-- Game: Bee: The Knight

-- MAIN APPLICATION
addappid(1778630)
-- Game: addappid(1778630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778631, 1, "fd187cbd87fdcaaf6696109e594fc7f2c233e551fd8b67318b901ba1cd941814")
