-- Lua provided by RyzenAPI
-- Game: Skully

-- MAIN APPLICATION
addappid(1249110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249111, 1, "f3ae3085eb0909be8fd29e01d9e5e93b772bae8772a1063f66939dc569e45e68")

