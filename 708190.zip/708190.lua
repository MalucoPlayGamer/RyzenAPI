-- Lua provided by RyzenAPI
-- Game: Game: Code World

-- MAIN APPLICATION
addappid(708190)
-- Game: addappid(708190)

-- MAIN APP DEPOTS / PACKAGES
addappid(708191, 1, "e0834e0d4604bb1a2a128f008ac72263d5df30f5c3433c0f464e4e74acd7a698")
