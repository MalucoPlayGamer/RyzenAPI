-- Lua provided by RyzenAPI
-- Game: Code World

-- MAIN APPLICATION
addappid(708190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(708191, 1, "e0834e0d4604bb1a2a128f008ac72263d5df30f5c3433c0f464e4e74acd7a698")

