-- Lua provided by RyzenAPI
-- Game: Cathedral 3-D

-- MAIN APPLICATION
addappid(1091590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1091591, 1, "42e972373dc06a53434b7abf643a1ac34adc36f9d6e596409c3354cb96a5b6d4")
addappid(1091592, 1, "66959f873876f15aa8ff6cec3660df7950ff4685039ddbdfe25775bfc4a7e864")
addappid(1091593, 1, "b6cdaa6c091a91c15407fd7d6b54ff08e6af19b1f4cb86184098db0906cf7f1a")
