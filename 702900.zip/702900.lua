-- Lua provided by RyzenAPI
-- Game: Time Barbarian Extreme!!

-- MAIN APPLICATION
addappid(702900)

-- MAIN APP DEPOTS / PACKAGES
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(702901, 1, "30de44489780f24bf49227e52dd138ca621cdd4a29b20e067d30caf84135e9e1")

