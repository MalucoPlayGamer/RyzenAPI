-- Lua provided by RyzenAPI
-- Game: Time Barbarian Extreme!!

-- MAIN APPLICATION
addappid(702900)

-- MAIN APP DEPOTS / PACKAGES
addappid(702901, 1, "30de44489780f24bf49227e52dd138ca621cdd4a29b20e067d30caf84135e9e1")
