-- Lua provided by RyzenAPI
-- Game: The Bonerooms

-- MAIN APPLICATION
addappid(2719940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719941, 1, "8d8e0f3d7449fcd5ae078bd2b469b66a9e61a35fc93acc07f45d9d62dfa77be1")
