-- Lua provided by RyzenAPI
-- Game: 693890

-- MAIN APPLICATION
addappid(693890)
-- Game: addappid(693890)

-- MAIN APP DEPOTS / PACKAGES
addappid(693891, 1, "f377a676a0e191e41c133d8649eef2bf49558573d5d9de09575a80dddf59b755")
