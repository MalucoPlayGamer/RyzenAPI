-- Lua provided by RyzenAPI
-- Game: 397150

-- MAIN APPLICATION
addappid(397150)
-- Game: addappid(397150)

-- MAIN APP DEPOTS / PACKAGES
addappid(397154,0,"aba1ffffa7796220cc3ad8af295906e718bed57fa25bf26da5a939c0c4aa49f2")
addappid(543200,0,"72be6ab07a20b04d217d1d329003bd824b4142d00aa56bd3801d97b20326a7c6")
