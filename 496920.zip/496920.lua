-- Lua provided by SkyAPI 
-- Game: AppID 496920
addappid(496920)
addappid(496921, 1, "6f45a53fcc01dffc7227a94ed8be6ac9019f14cdf378c9801d0610a92d30f6a9")
addappid(496922, 1, "4b51929de222b4c685609b35e3bcc446b93c276ee34e4729b8d6ae524b4b0064")
addappid(496923, 1, "e0e7b5f4bc00144bb112f7a6fde14167eb816d2bafe2f264e40be48bbf9b4c0a")
