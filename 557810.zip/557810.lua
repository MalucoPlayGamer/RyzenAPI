-- Lua provided by RyzenAPI
-- Game: Clicker Guild

-- MAIN APPLICATION
addappid(557810)
-- Game: addappid(557810)

-- MAIN APP DEPOTS / PACKAGES
addappid(557811, 1, "dae0e40a5a0d69dd2a959d528a4038b7c93a5056a73a0d4bdc2f1b67a27933bf")
