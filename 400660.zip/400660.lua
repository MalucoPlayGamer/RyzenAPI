-- Lua provided by RyzenAPI 
-- Game: AppID 400660
addappid(400660)
addappid(400661, 1, "debbd93471c8f8bd25817c2910c968c41e820d059d1583379b2a8ddcbf9d221c")
addappid(400662, 1, "4067aaf1ba9c4ffef27e5e84c48da48cb22fe58f71e1baa4b3b55fd99c22aeee")
