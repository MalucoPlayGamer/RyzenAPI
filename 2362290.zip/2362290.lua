-- Lua provided by RyzenAPI
-- Game: addappid(2362290)

-- MAIN APPLICATION
addappid(2362290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362290,0,"fc871fd35388373eb8fd06bdc77e24890ba67230ae7beff586d70c8d73cac68e")
