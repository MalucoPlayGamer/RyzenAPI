-- Lua provided by RyzenAPI
-- Game: addappid(3030760)

-- MAIN APPLICATION
addappid(3030760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3030761, 1, "5e668a50f5b440bba7dfcdc7396e3a08981514fb3442cc8a34c4c1a7bce4957d")
