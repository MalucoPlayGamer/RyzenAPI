-- Lua provided by SkyAPI 
-- Game: Horror Manor
addappid(3030760)
addappid(3030761, 1, "5e668a50f5b440bba7dfcdc7396e3a08981514fb3442cc8a34c4c1a7bce4957d")
