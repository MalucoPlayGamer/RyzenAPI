-- Lua provided by RyzenAPI
-- Game: AppID 337270

-- MAIN APPLICATION
addappid(337270)
-- Game: addappid(337270)

-- MAIN APP DEPOTS / PACKAGES
addappid(337271, 1, "8d2ab87b1299eb9eabffadf86ce05f6b4dd013a45b26718d08cf42399a39b390")
addappid(337272, 1, "5aa98d683712dcee97db0618b99f7fbdf96f1831a154c0fcc86f4ab049ad5647")
addappid(337273, 1, "2f4b16d4e0eac5cda0bcf83ed6c7dcf804e468c73c111483afe44481494e987f")
addappid(337274, 1, "72d69eec666db63bee8840870b29db984cb1cebd0163adb815e3af504d892785")
