-- Lua provided by SkyAPI 
-- Game: MOLEK-SYNTEZ
addappid(1168880)
addappid(1168881, 1, "0dc54dcd847210aff8459b3b9d662016d7752b1fde5556796ff24df9ca17548c")
addappid(1168882, 1, "e1fcab67de24890ed73343617362fc3a3e2f4d0de8028cc3ce1e5684ecdfcfce")
addappid(1168883, 1, "2c706085108b974d4b4d92b77d37129792a8f926141c2d7f903e82d17d25eebd")
