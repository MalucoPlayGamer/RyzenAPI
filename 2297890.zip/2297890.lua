-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - KR Alien Worlds Tileset

-- MAIN APPLICATION
addappid(2297890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2297890,0,"b499cdfce9e4dae84f7ea65383786359b14bd929e8d90eb87ca9784703657f55")
