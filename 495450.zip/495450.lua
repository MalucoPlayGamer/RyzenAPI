-- Lua provided by RyzenAPI
-- Game: Game: Fractasia

-- MAIN APPLICATION
addappid(495450)
-- Game: addappid(495450)

-- MAIN APP DEPOTS / PACKAGES
addappid(495451, 1, "c431a64f826da2514b6d6e44adab6dfa48ceef3f7cac20ccbd38e809fe1fd6d1")
