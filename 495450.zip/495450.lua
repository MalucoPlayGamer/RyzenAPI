-- Lua provided by SkyAPI 
-- Game: Fractasia
addappid(495450)
addappid(495451, 1, "c431a64f826da2514b6d6e44adab6dfa48ceef3f7cac20ccbd38e809fe1fd6d1")
