-- Lua provided by RyzenAPI
-- Game: Furcifer's Fungeon Demo

-- MAIN APPLICATION
addappid(2195840)
-- Game: addappid(2195840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195841, 1, "7c6b49375b7d1df8983edadb544a3f3977a3659be4e7e940c2a61fb9cd9b315a")
