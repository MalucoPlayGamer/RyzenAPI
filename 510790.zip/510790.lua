-- Lua provided by RyzenAPI
-- Game: 510790

-- MAIN APPLICATION
addappid(510790)
-- Game: addappid(510790)

-- MAIN APP DEPOTS / PACKAGES
addappid(510791, 1, "88d4a6b8a6b06c670b98e641f5d5551874d8641fbb8d98f94f8acbf637e9dc38")
addappid(510792, 1, "284fbd5011931af467a8d8c3b9d783654074f0d80bcdbd5f0d8c4da53381031d")
