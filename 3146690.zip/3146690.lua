-- Lua provided by RyzenAPI
-- Game: No Fap Island

-- MAIN APPLICATION
addappid(3146690)
addappid(4260880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146691, 1, "4c76a363016fe94211a0693c0338a96f61f6af0c09b1dedfa466b75ce9576179")
addappid(4260880, 1, "e03566c70fae1c6ad0201406e7292c0c958ad502826ee5c1f0fecbe74148edbd")

