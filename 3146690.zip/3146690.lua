-- Generated with Luie @ https://lua.tools/
-- 3146690 - No Fap Island
-- Generated 2026-08-29 06:58:07 UTC
-- # Depots (Total/DLC/Shared): 2/1/0

-- Main AppID
addappid(3146690)

-- Main Depots
addappid(3146691, 1, "4c76a363016fe94211a0693c0338a96f61f6af0c09b1dedfa466b75ce9576179")
setManifestid(3146691, "6497218756913546237", 2152594327)

-- DLC's (with depot keys)
-- No Fap Island - BONUS Pack (AppID: 4260880)
addappid(4260880)
addappid(4260880, 1, "e03566c70fae1c6ad0201406e7292c0c958ad502826ee5c1f0fecbe74148edbd")
setManifestid(4260880, "2731876914291269572", 456821343)
