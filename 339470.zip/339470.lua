-- Lua provided by RyzenAPI
-- Game: Retention

-- MAIN APPLICATION
addappid(339470)

-- MAIN APP DEPOTS / PACKAGES
addappid(339471, 1, "da1cb37a8845c6e8a44eaa14faa3656dcb806069671bd5bd4216cb14c56ac4c5")

