-- Lua provided by RyzenAPI
-- Game: Escape the House

-- MAIN APPLICATION
addappid(4966860) -- Escape the House

-- MAIN APP DEPOTS / PACKAGES
addappid(4966861, 1, "a85675eb62eeaf78ad44e2a57400dbe0b735c5bc4b695edbcd08fd860c9d171f") -- Depot 4966861

