-- 4966860's Lua and Manifest Created by Hubcap Manifest
-- Escape the House
-- Created: August 01, 2026 at 09:13:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4966860) -- Escape the House
-- MAIN APP DEPOTS
addappid(4966861, 1, "a85675eb62eeaf78ad44e2a57400dbe0b735c5bc4b695edbcd08fd860c9d171f") -- Depot 4966861
setManifestid(4966861, "4488169647238281926", 227669579)