-- Lua provided by RyzenAPI
-- Game: addappid(736260)

-- MAIN APPLICATION
addappid(736260)

-- MAIN APP DEPOTS / PACKAGES
addappid(736261, 1, "410c70fef86e8f5cf276b33125a7ea483ea83d86e1d68441996f1fc7c100f660")
addappid(736262, 1, "4d0d21a1ef7fa4d22ccc1a9fad105d3fe1a3d0974ec3bc2737b6df22cb456f6f")
addappid(736263, 1, "ecd6193b5c2ad8855abf4d383ed3d8cc1cc36f2caffa2cd8e2826fa7bea89cc5")
