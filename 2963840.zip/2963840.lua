-- Lua provided by RyzenAPI
-- Game: 2963840

-- MAIN APPLICATION
addappid(2963840)
-- Game: addappid(2963840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963841, 1, "c1cace5e51644cee948b47effcf938011332a34f540219a0465add8f400e4492")
