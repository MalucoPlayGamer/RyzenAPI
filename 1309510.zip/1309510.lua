-- Lua provided by RyzenAPI
-- Game: Glaze Cup: Journey to the West

-- MAIN APPLICATION
addappid(1309510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309511, 1, "a7e2b7f58bf35273c13d908e638d9e4b726b3ab0ce948640f8a5ea7e8ae13a96")

