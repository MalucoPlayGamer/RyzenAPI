-- Lua provided by RyzenAPI
-- Game: 405970

-- MAIN APPLICATION
addappid(405970)
addappid(405971)
addappid(405974)
addappid(405975)
addappid(407371)
addappid(457560)
-- Game: addappid(405970)

-- MAIN APP DEPOTS / PACKAGES
addappid(405976,0,"fa25c5a6e8d834fbe2ae52e1b364555912b601a134541419b7bf2dc297ce4aac")
