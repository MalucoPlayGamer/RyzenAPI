-- Lua provided by RyzenAPI
-- Game: 1025500

-- MAIN APPLICATION
addappid(1025500)
-- Game: addappid(1025500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025501, 1, "38577d5a31c33b1d64b4fa2f3a60cf6b03a3f9b23f857d7201bfcd495a4a4884")
