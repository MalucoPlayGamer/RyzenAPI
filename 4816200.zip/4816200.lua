-- 4816200's Lua and Manifest Created by Hubcap Manifest
-- Endless Defense
-- Created: June 23, 2026 at 10:06:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4816200) -- Endless Defense
-- MAIN APP DEPOTS
addappid(4816201, 1, "7f74dc5c1c33323e5dad438389e36429c697d00f2851dfdfad1abd30c7dcc32e") -- Depot 4816201
setManifestid(4816201, "9212420651147802612", 1581776338)