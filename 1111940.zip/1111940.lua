-- Lua provided by RyzenAPI
-- Game: Game: AppID 1111940

-- MAIN APPLICATION
addappid(1111940)
-- Game: addappid(1111940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111941, 1, "82f542d688584cc4767d78ce6899a9ddd9237cccc3ad3fa630b28f8110a8cf0f")
addappid(1111942, 1, "c1ceee28916d7df34a5f70158959cab1df976e90ddb7e08f9b63cc4ac5d1f90c")
addappid(1111943, 1, "5be727be122fb767028e2d037fa107236fb9dc9ddb710eb2e9d24dcc9554a68a")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")
