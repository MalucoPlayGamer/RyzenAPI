-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Leopard's Leap

-- MAIN APPLICATION
addappid(1158491)
-- Game: addappid(1158491)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158491,0,"4fc71fec991e9641e11d5cb5b552e5aea93edf749d7590feb63e2bbd339a392d")
