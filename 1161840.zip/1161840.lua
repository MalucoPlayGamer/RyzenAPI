-- Lua provided by RyzenAPI 
-- Game: Funny Archery
addappid(1161840)
addappid(1161841, 1, "435555be8c7e8e491fa33eed77037727b6dd133040859c11cd5d54d0de357e29")
