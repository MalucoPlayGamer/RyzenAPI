-- Lua provided by RyzenAPI
-- Game: 1161840

-- MAIN APPLICATION
addappid(1161840)
-- Game: addappid(1161840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161841, 1, "435555be8c7e8e491fa33eed77037727b6dd133040859c11cd5d54d0de357e29")
