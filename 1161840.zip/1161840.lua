-- Lua provided by RyzenAPI
-- Game: Funny Archery

-- MAIN APPLICATION
addappid(1161840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1161841, 1, "435555be8c7e8e491fa33eed77037727b6dd133040859c11cd5d54d0de357e29")

