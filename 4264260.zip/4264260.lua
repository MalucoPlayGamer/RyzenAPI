-- Lua provided by RyzenAPI
-- Game: Utawarerumono: Past and Present Rediscovered

-- MAIN APPLICATION
addappid(4264260)

-- MAIN APP DEPOTS / PACKAGES
addappid(4264261, 1, "ebbf04a52e2cb93169990d81a62b8d89fc4e1363555efbd09c1849f738465421")
addappid(4264262, 1, "1d528237b9fdac6fbcb8d896e77332348b49769af6eb9e61e6a7450d5e72812a")
addappid(4264263, 1, "d4b60830af9474f46447120c855a3f983e50e86621fee5a4ce38bec666923c13")
addappid(4264264, 1, "0c25236b8a989e35ef26f457cd6ac93d94c744b5a0f156ac85c35109f6904cca")
addappid(4264265, 1, "d41a012c78bffc9e7f0ae77c1e2de3d202b61375ab53118ecc513fb9dc782f8b")
