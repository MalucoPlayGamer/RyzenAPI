-- Lua provided by RyzenAPI
-- Game: On Your Tail Demo

-- MAIN APPLICATION
addappid(2963170)
-- Game: addappid(2963170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963171, 1, "b31c829e38c61aedf06a9f6f544f5eb9185aeab7a05aeab7911a7b6a06a31302")
