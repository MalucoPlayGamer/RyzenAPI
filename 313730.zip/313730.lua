-- Lua provided by SkyAPI 
-- Game: AppID 313730
addappid(313730)
addappid(313731, 1, "7d18472dee570ea2a903ba18ba5252e04866469cc8667c752aab94caf88e7fb8")
