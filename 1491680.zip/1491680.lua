-- Lua provided by RyzenAPI
-- Game: 1491680

-- MAIN APPLICATION
addappid(1491680)
-- Game: addappid(1491680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491681, 1, "d203c350257fc7ac3e49e0734ca74d6d787594eed28393fd966fab4faee745ce")
