-- Lua provided by RyzenAPI 
-- Game: Fiendish Thieves
addappid(1491680)
addappid(1491681, 1, "d203c350257fc7ac3e49e0734ca74d6d787594eed28393fd966fab4faee745ce")
