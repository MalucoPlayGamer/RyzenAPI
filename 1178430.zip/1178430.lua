-- Lua provided by RyzenAPI
-- Game: Summer Games Heroes

-- MAIN APPLICATION
addappid(1178430)
addappid(1209340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1178431, 1, "a28edddf5eb4339554c5f3483820d060763df436ac1a373b78ef7995f42f4d51")

