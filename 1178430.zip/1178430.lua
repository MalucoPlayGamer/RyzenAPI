-- Lua provided by RyzenAPI
-- Game: Summer Games Heroes

-- MAIN APPLICATION
addappid(1178430)
addappid(1209340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178431, 1, "a28edddf5eb4339554c5f3483820d060763df436ac1a373b78ef7995f42f4d51")

