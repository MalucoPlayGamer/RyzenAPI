-- Lua provided by SkyAPI 
-- Game: JET HERO
addappid(586060)
addappid(586061, 1, "c15908a34c26f23919bdaab99d4f0689a4611c953eea02006cfcd620f6a305b3")
addappid(586062, 1, "8067544f60e4d338e81c0875f0f3a0c9a602ce0806c252cf33776faa9a877de5")
