-- Lua provided by RyzenAPI
-- Game: addappid(1733250)

-- MAIN APPLICATION
addappid(1733250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733251, 1, "8ee37cc41be1ce7e013b6dc8b216f4b0d871ef4f3347a4c5f20f9060f75aaebb")
