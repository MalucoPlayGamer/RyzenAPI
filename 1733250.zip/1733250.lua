-- Lua provided by RyzenAPI
-- Game: Turbo Kid

-- MAIN APPLICATION
addappid(1733250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733251, 1, "8ee37cc41be1ce7e013b6dc8b216f4b0d871ef4f3347a4c5f20f9060f75aaebb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
