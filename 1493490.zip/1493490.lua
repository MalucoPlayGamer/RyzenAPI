-- Lua provided by SkyAPI 
-- Game: Demonicute
addappid(1493490)
addappid(1493491, 1, "cd42b7413925adbdc7c0bd8e0e776e88ae2fea6bbfde70909465b26042ecc591")
