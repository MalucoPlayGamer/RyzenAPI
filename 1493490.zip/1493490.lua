-- Lua provided by RyzenAPI
-- Game: Demonicute

-- MAIN APPLICATION
addappid(1493490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493491, 1, "cd42b7413925adbdc7c0bd8e0e776e88ae2fea6bbfde70909465b26042ecc591")
