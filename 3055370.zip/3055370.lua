-- Lua provided by RyzenAPI
-- Game: addappid(3055370)

-- MAIN APPLICATION
addappid(3055370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3055371, 1, "17fbeb07a853c45c7e77e590ab7fa65500b8528f070b15ba1b28561ec73e5415")
