-- Lua provided by RyzenAPI
-- Game: Game: Megamagic: Wizards of the Neon Age

-- MAIN APPLICATION
addappid(422650)
-- Game: addappid(422650)

-- MAIN APP DEPOTS / PACKAGES
addappid(422651, 1, "45f35cde09b944344207cc0020e7cd0ed0c7e19fbba034de979f22cbc0a73380")
addappid(422652, 1, "27a3734a4d711849b040d51215bdf8e6daf2910d85bfca78fb94a0423029cec7")
addappid(422654, 1, "ed233e2c46985fe2dc88a9b24b3de5b3f766cbee41a48320d92045a9cb49e509")
