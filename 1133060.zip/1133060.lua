-- Lua provided by RyzenAPI
-- Game: Anarchy: Wolf's law

-- MAIN APPLICATION
addappid(1133060)
addappid(1735890)
addappid(2205210)
addappid(2262920)
addappid(2314320)
addappid(2457690)
addappid(2566080)
addappid(2735650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133061,0,"3f0b3712d8ac72fb7e595a6901757c333c8d3d5fcb54b86ba7b232a3136d2c08")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
