-- Lua provided by RyzenAPI 
-- Game: AppID 1133060
addappid(1133060)
addappid(1133061, 1, "3f0b3712d8ac72fb7e595a6901757c333c8d3d5fcb54b86ba7b232a3136d2c08")
