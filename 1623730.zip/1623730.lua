-- Lua provided by RyzenAPI
-- Game: Palworld

-- MAIN APPLICATION
addappid(1623730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1623730, 1, "214e5bcf1036d2bc62193cf2bc15e148899db0ed4799c3a2c0d41f2490d136f5") -- Palworld
addappid(1623731, 1, "7a422988135296505205dd489945d4b17ed7414734dd627744adac84aade7b73")
addappid(1623731, 1, "7a422988135296505205dd489945d4b17ed7414734dd627744adac84aade7b73") -- Depot 1623731

