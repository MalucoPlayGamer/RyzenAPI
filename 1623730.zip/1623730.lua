-- Lua provided by RyzenAPI 
-- Game: Palworld
addappid(1623730)
addappid(1623731, 1, "7a422988135296505205dd489945d4b17ed7414734dd627744adac84aade7b73")
