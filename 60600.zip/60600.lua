-- Lua provided by SkyAPI 
-- Game: ProtoGalaxy
addappid(60600)
addappid(60601, 1, "fda6fe3a8960ec25feb432c23fc17e1b3e5c7ca9dca070e967c5dc7f1954500b")
addappid(60602, 1, "9965c8902d6242016949a74eee8ae38f508158736e372ce289baf07cf96d5731")
