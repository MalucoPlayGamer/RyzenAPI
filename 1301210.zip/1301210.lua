-- Lua provided by RyzenAPI
-- Game: Knockout City™

-- MAIN APPLICATION
addappid(1301210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301211, 1, "22d68952727f5a510f742fd5ddac737695bd89563f1fa038c13dbf8257eda8a0")
addappid(1301212, 1, "3cf5fee2f0c0d50239f8a9e7a6872a729068acac6e674937a069bc04a8817b9c")
addappid(1301213, 1, "ad89e59d1acf5e2e3f1344dea5f8c77c620747b8d5faf42e415d6054d482f625")
addappid(1301217, 1, "ad4b25bc140ccae67580f5410a805278ef21e92ba32905979906487b45dde9c5")
addappid(1301218, 1, "b539647da4d1ef783ba41700b359baa2a56e71dc343de2bfb64ec2edb3878d10")
addappid(1388202, 0, "c77bc5899bed911a12015924ef691343e1dd71523139bf83fd8c0083a1757047")
addappid(1388203, 0, "233de6c4e47aff90c35d134f4ff7b68d48c1b4246f531321c0d10d307a29f49c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1388200)
addappid(1539550)
addappid(1539560)
addappid(1539561)
addappid(1539562)
addappid(2086020)
