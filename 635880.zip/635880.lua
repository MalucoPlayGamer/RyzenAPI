-- Lua provided by RyzenAPI
-- Game: 635880

-- MAIN APPLICATION
addappid(635880)
-- Game: addappid(635880)

-- MAIN APP DEPOTS / PACKAGES
addappid(635881, 1, "5d30477521bfacfe8d2c8246577b8c28cbd556efc06430da3395fd7f167e46a2")
