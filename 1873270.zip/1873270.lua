-- Lua provided by RyzenAPI
-- Game: ColdSun

-- MAIN APPLICATION
addappid(1873270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873271, 1, "d6581607416ab062dcce6af60ab43273e25a14ba26ac23be179a9852c87d76b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
