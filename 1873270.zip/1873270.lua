-- Lua provided by RyzenAPI
-- Game: Game: ColdSun

-- MAIN APPLICATION
addappid(1873270)
-- Game: addappid(1873270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873271, 1, "d6581607416ab062dcce6af60ab43273e25a14ba26ac23be179a9852c87d76b5")
