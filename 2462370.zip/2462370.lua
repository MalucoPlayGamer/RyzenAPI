-- Lua provided by RyzenAPI
-- Game: AppID 2462370

-- MAIN APPLICATION
addappid(2462370)
-- Game: addappid(2462370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462371, 1, "188002f184257602e26cc05a0fd2006d607d2c66fb66e570cdafe6ab0a1c925c")
