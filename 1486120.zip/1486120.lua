-- Lua provided by RyzenAPI
-- Game: 2020: The Ride

-- MAIN APPLICATION
addappid(1486120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1486121, 1, "c4614fe0bb956df807417a63378f13fb4566bb1d44fbc15df5300f49d7461f46")
