-- Lua provided by RyzenAPI
-- Game: 1486120

-- MAIN APPLICATION
addappid(1486120)
-- Game: addappid(1486120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486121, 1, "c4614fe0bb956df807417a63378f13fb4566bb1d44fbc15df5300f49d7461f46")
