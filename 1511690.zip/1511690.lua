-- Lua provided by RyzenAPI
-- Game: addappid(1511690)

-- MAIN APPLICATION
addappid(1511690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511691, 1, "5288c18f9672ece85c71f012e347189d4e85e12870c7ebc6b58a707dfd85068f")
