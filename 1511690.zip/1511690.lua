-- Lua provided by SkyAPI 
-- Game: Fragmented Mind
addappid(1511690)
addappid(1511691, 1, "5288c18f9672ece85c71f012e347189d4e85e12870c7ebc6b58a707dfd85068f")
