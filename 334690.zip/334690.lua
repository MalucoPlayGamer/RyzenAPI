-- Lua provided by SkyAPI 
-- Game: AppID 334690
addappid(334690)
addappid(334691, 1, "4e6f0fe25fc2c4f05c3c9a94434147f2a31455142598d2a32d6bc488d6816a8e")
