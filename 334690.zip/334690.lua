-- Lua provided by RyzenAPI
-- Game: Game: AppID 334690

-- MAIN APPLICATION
addappid(334690)
-- Game: addappid(334690)

-- MAIN APP DEPOTS / PACKAGES
addappid(334691, 1, "4e6f0fe25fc2c4f05c3c9a94434147f2a31455142598d2a32d6bc488d6816a8e")
