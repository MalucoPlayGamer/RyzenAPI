-- Lua provided by RyzenAPI
-- Game: Game: Smart Thief

-- MAIN APPLICATION
addappid(1439170)
-- Game: addappid(1439170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439171, 1, "522ee239240620b18d16b36cc26bf2b7f4df4f5c081484cd812624df89fff3d4")
