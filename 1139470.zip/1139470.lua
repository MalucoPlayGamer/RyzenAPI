-- Lua provided by RyzenAPI
-- Game: THE ART - Metamorphosis

-- MAIN APPLICATION
addappid(1139470)
-- Game: addappid(1139470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139471, 1, "690c6a7046eb433284b6b79fa80616e09dd58f63344f4601d3b23fd53743af3d")
