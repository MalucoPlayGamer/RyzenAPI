-- Lua provided by RyzenAPI
-- Game: Boid

-- MAIN APPLICATION
addappid(229004)
addappid(229012)
addappid(314010)
addappid(314011)
addappid(314012)

-- MAIN APP DEPOTS / PACKAGES
addappid(314013,0,"777c9bb3f67e9f6e01017cd3dcaa39780ec1a37d1342e407fd39da3962da3f25")
