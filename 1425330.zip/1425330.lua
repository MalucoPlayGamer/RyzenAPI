-- Lua provided by RyzenAPI
-- Game: Eye of the Beholder

-- MAIN APPLICATION
addappid(1425330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425333,0,"aab09e263b2903fe573e47c6327805c001ccf628c0ac0699437458dbd375f209")

