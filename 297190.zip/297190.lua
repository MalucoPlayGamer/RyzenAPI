-- Lua provided by RyzenAPI
-- Game: Grayland

-- MAIN APPLICATION
addappid(297190)

-- MAIN APP DEPOTS / PACKAGES
addappid(297192,0,"70284b269b31fe5355ae8bad6b243115309fca4ba0341e0ca90186df38493196")
