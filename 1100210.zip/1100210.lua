-- Lua provided by RyzenAPI
-- Game: Game: AppID 1100210

-- MAIN APPLICATION
addappid(1100210)
-- Game: addappid(1100210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100211, 1, "b6a4b02ca648e5de8e1a193d1c68200f09befabba833176e086d4f76ec6914f5")
