-- Lua provided by RyzenAPI
-- Game: Game: Stellar Ghosts Settlers

-- MAIN APPLICATION
addappid(2578790)
-- Game: addappid(2578790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578791, 1, "d2051ef731301711c7fbea988f7a97408b6e09c3383ae77d4b6c8668f887e67d")
