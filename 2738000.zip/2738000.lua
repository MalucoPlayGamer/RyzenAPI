-- Lua provided by RyzenAPI
-- Game: Game: FINAL FANTASY XVI DEMO

-- MAIN APPLICATION
addappid(2738000)
-- Game: addappid(2738000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738001, 1, "9dbbffbe4ef052726c5e85122e0089da01551e37c2d5f776b5c174dd3c2a8aac")
