-- Lua provided by RyzenAPI
-- Game: Game: The Last Saviour

-- MAIN APPLICATION
addappid(1339870)
-- Game: addappid(1339870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339871, 1, "5d327679205b0a6cd8cee99332cd90342939439e1f3e7ad1ed354e6f199396df")
