-- Lua provided by RyzenAPI
-- Game: addappid(3388780)

-- MAIN APPLICATION
addappid(3388780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388781,0,"a11a78eec6152470b62a13ee8eb0ac903858c5c8e094edb947aab59bd16c2db8")
