-- eu sou jesus cristo
addappid(3388780)
addappid(3388781,0,"a11a78eec6152470b62a13ee8eb0ac903858c5c8e094edb947aab59bd16c2db8")