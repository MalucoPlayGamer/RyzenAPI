-- Lua provided by SkyAPI 
-- Game: Beer Factory - Prologue
addappid(2173600)
addappid(2173601, 1, "107e14008b269eb109a15af7b257f66087e01837ecdf09a92b4d9981468fe511")
