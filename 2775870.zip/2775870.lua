-- Lua provided by RyzenAPI
-- Game: Stalked in Solitude

-- MAIN APPLICATION
addappid(2775870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775871, 1, "5ed6b4b98dca415ff4886c574b43c38f0a8dbbb71ed03ff1c1dbc93311d61ecb")

