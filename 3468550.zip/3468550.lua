-- Lua provided by RyzenAPI
-- Game: Kingdom Come: Deliverance II Soundtrack

-- MAIN APPLICATION
addappid(3468550)
-- Game: addappid(3468550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3468551, 1, "25b35bae1bb9e7a4cce9c03f6de8e02f15249954fc825b32b3d36db9844e04f2")
addappid(3468552, 1, "1af88e054ff8a58910611d28559791d4cf5f49bf9f51d60536284f2ce725d341")
