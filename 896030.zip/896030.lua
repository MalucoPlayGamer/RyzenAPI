-- Lua provided by RyzenAPI
-- Game: Fortissimo FA INTL Ver

-- MAIN APPLICATION
addappid(896030)
-- Game: addappid(896030)

-- MAIN APP DEPOTS / PACKAGES
addappid(896031, 1, "499adebfe965f5f282caa1218e0733d785657c1ba5d4d71a0df35c86cc793fcb")
addappid(896032, 1, "77c33894c2a75738698cfa13cafb775f34ae28c9830ad5a2c0a4578b6702ae73")
addappid(909330, 0, "8ce19b2d59adbb95113d3bd0d6529c5ed640b14df7498050481deb70fb77e0a7")
