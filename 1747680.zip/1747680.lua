-- Lua provided by RyzenAPI
-- Game: Faraway: Jungle Escape

-- MAIN APPLICATION
addappid(1747680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747681, 1, "763930acc6916812f47e95b78c93c73be3fe2c00a69f817c4533a33850030ece")

