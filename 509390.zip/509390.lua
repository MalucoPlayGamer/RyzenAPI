-- Lua provided by RyzenAPI
-- Game: 509390

-- MAIN APPLICATION
addappid(509390)
-- Game: addappid(509390)

-- MAIN APP DEPOTS / PACKAGES
addappid(509391, 1, "aa25921a11f47f2eab507ec240f57015e31262ac056860d41379e6b38089ca5b")
