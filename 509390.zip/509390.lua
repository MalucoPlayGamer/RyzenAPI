-- Lua provided by RyzenAPI
-- Game: AppID 509390

-- MAIN APPLICATION
addappid(509390)

-- MAIN APP DEPOTS / PACKAGES
addappid(509391, 1, "aa25921a11f47f2eab507ec240f57015e31262ac056860d41379e6b38089ca5b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
