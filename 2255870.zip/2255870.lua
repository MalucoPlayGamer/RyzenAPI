-- Lua provided by RyzenAPI
-- Game: Game: AppID 2255870

-- MAIN APPLICATION
addappid(2255870)
-- Game: addappid(2255870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255871, 1, "b7f8e876c46e07a33e167b2adcfe0ee495f49b79f50b633e898602c1dbac781f")
