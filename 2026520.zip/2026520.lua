-- Lua provided by RyzenAPI
-- Game: addappid(2026520)

-- MAIN APPLICATION
addappid(2026520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026521, 1, "93f2ce82dc24db312df791c3c12bec8e76f095c5c1c4aad66f0447cdf06f453f")
