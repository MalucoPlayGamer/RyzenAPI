-- Lua provided by RyzenAPI
-- Game: Beyond The Underworld

-- MAIN APPLICATION
addappid(1223380)
-- Game: addappid(1223380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223381, 1, "9a880860aefd149a973c83f719d525639e7b4c9c8b3459e8f196c8fe5f65d83c")
