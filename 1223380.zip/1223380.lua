-- Lua provided by RyzenAPI
-- Game: Beyond The Underworld

-- MAIN APPLICATION
addappid(1223380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1223381, 1, "9a880860aefd149a973c83f719d525639e7b4c9c8b3459e8f196c8fe5f65d83c")

