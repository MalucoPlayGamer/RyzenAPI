-- Lua provided by RyzenAPI 
-- Game: The Seeker
addappid(503680)
addappid(503681, 1, "47aa8f3d94eb1dc4b27781e32e51026c860d4ebcc4a9df55e9d87988271f7541")
