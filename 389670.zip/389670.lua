-- Lua provided by RyzenAPI
-- Game: Pacer

-- MAIN APPLICATION
addappid(228985)
addappid(228986)
addappid(228988)
addappid(228990)
addappid(229020)
addappid(389670)
addappid(389671)
addappid(389673)

-- MAIN APP DEPOTS / PACKAGES
addappid(389674,0,"351e7b8c165e841ac64d6b4d87fb125dabbfd9126204e74c19ca15b154fe3793")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(677600)
addappid(677660)
addappid(768380)
