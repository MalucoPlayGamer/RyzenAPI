-- Lua provided by RyzenAPI
-- Game: Sector 452

-- MAIN APPLICATION
addappid(757780)

-- MAIN APP DEPOTS / PACKAGES
addappid(757781,0,"0fa6ff1f202f16d259aa9c55862bb64db53d057b53b395d5d6b900457116c38e")

