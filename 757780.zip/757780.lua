-- Lua provided by RyzenAPI
-- Game: Sector 452

-- MAIN APPLICATION
addappid(757780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(757781,0,"0fa6ff1f202f16d259aa9c55862bb64db53d057b53b395d5d6b900457116c38e")

