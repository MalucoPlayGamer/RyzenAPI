-- Lua provided by RyzenAPI
-- Game: The Cat Games

-- MAIN APPLICATION
addappid(603260)

-- MAIN APP DEPOTS / PACKAGES
addappid(603261, 1, "51a5e9b9446f86c03d51219c88907da140812d84633387e9b9531cca8bde1291")
