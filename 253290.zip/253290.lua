-- Lua provided by RyzenAPI 
-- Game: FOTONICA
addappid(253290)
addappid(253291, 1, "a314613da8ab1d3b72b14f2d9d5f28845fd3bd8a475c634a2dec2afd1facf5b8")
addappid(253292, 1, "cff40484ec12ab2b67a2dacb8351cc81ccb49069bbb7854f333e150865876102")
addappid(253293, 1, "48e5cdbcc8dca44b32361182f75aeb571e2d1f5af7700197e3748168d769e611")
