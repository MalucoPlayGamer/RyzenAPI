-- Lua provided by RyzenAPI
-- Game: addappid(933560)

-- MAIN APPLICATION
addappid(933560)

-- MAIN APP DEPOTS / PACKAGES
addappid(933560,0,"29de99fa46395455d463f5b078e3fa64ae58b39530b9387493a28d6848eaad2c")
