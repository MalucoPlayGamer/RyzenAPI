-- Lua provided by RyzenAPI
-- Game: Gloomsday

-- MAIN APPLICATION
addappid(2721710)
-- Game: addappid(2721710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2721711, 1, "56a04b97e9462833c98e8988f12ac941a8375310157b1c5c7e1ee07775779bec")
