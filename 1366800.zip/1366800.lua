-- Lua provided by RyzenAPI
-- Game: Crosshair X

-- MAIN APPLICATION
addappid(1366800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1366801, 1, "c5417c02a22d0961ede2808e93da40d019b1d1f88131568488d7659bdc01ddcf")

