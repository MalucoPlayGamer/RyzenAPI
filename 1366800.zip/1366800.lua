-- Lua provided by RyzenAPI
-- Game: Crosshair X

-- MAIN APPLICATION
addappid(1366800)
-- Game: addappid(1366800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366801, 1, "c5417c02a22d0961ede2808e93da40d019b1d1f88131568488d7659bdc01ddcf")
