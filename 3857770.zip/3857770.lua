-- Lua provided by RyzenAPI
-- Game: Game: Backmooms

-- MAIN APPLICATION
addappid(3857770)
-- Game: addappid(3857770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3857771, 1, "2b3ad5b6decdb78986132b46ade471f1db5663545506ffbb7ef7b6a1545e935f")
