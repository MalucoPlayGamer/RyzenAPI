-- Lua provided by RyzenAPI
-- Game: Movavi Video Suite 2023 Steam Edition - An all-in-one video maker: an editor, converter, screen recorder, and more!

-- MAIN APPLICATION
addappid(2171290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171291, 1, "0374597f3a0900c9b88c4bd7696ac93bd43cab13e2113424573350e15b486dc8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2179230)
addappid(2179231)
addappid(2179232)
addappid(2179233)
addappid(2179234)
addappid(2179235)
addappid(2179236)
addappid(2179237)
addappid(2179238)
addappid(2179239)
addappid(2214580)
addappid(2317490)
addappid(2317710)
addappid(2317740)
