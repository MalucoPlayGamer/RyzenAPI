-- Lua provided by RyzenAPI
-- Game: Game: Rolled Out!

-- MAIN APPLICATION
addappid(873270)
-- Game: addappid(873270)

-- MAIN APP DEPOTS / PACKAGES
addappid(873271, 1, "0c8a1d0395add5c9ed819bf09794b41f4df2f5e7cee6024734f18dc1decf1b02")
