-- Lua provided by RyzenAPI
-- Game: Rolled Out!

-- MAIN APPLICATION
addappid(873270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(873271, 1, "0c8a1d0395add5c9ed819bf09794b41f4df2f5e7cee6024734f18dc1decf1b02")

