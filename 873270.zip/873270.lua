-- Lua provided by SkyAPI 
-- Game: Rolled Out!
addappid(873270)
addappid(873271, 1, "0c8a1d0395add5c9ed819bf09794b41f4df2f5e7cee6024734f18dc1decf1b02")
