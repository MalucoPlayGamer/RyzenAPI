-- Lua provided by RyzenAPI
-- Game: Shop Life Simulator

-- MAIN APPLICATION
addappid(3396090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3396091, 1, "36177f5ca21233fcdd2cea7339e23a3e606ccdc43762a89b9f9589078354acf1")

