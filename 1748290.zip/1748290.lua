-- Lua provided by RyzenAPI
-- Game: 1748290

-- MAIN APPLICATION
addappid(1748290)
addappid(1942830)
addappid(1942831)
-- Game: addappid(1748290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748291, 1, "29624f834a67434a34774a577f48d99d7ce9e0ce4fdf526914af94a0db859164")
