-- Lua provided by SkyAPI 
-- Game: Lily´s Epic Quest
addappid(507270)
addappid(507271, 1, "44d156098da7e7a644a3f1265478e414a5d792ff7bb5a8a2f99c9c7328f16318")
addappid(507272, 1, "857a0c8951695e01edf224661ae188c07c223880368bede5e019274d0576d553")
