-- Lua provided by RyzenAPI
-- Game: The Oregon Trail

-- MAIN APPLICATION
addappid(2013360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2013361, 1, "9643afa3acb621adbeb971d73541c1f34acec3a900acd47fad34fa7f29286cb7")
addappid(2316610, 0, "6466a3da267a52fe833cef91956d9d65ed9cf45726c3917194970ab040375fae")

