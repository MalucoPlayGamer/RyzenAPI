-- Lua provided by RyzenAPI
-- Game: addappid(2013360)

-- MAIN APPLICATION
addappid(2013360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013361, 1, "9643afa3acb621adbeb971d73541c1f34acec3a900acd47fad34fa7f29286cb7")
addappid(2316610, 0, "6466a3da267a52fe833cef91956d9d65ed9cf45726c3917194970ab040375fae")
