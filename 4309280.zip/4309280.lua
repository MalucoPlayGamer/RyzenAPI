-- 4309280's Lua and Manifest Created by Hubcap Manifest
-- Caravan Village: Farming Life
-- Created: June 24, 2026 at 06:14:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4309280) -- Caravan Village: Farming Life
-- MAIN APP DEPOTS
addappid(4309281, 1, "81de419aae5022ddb5faa6f7d874628c8863b2b996300ad2605f20b042f40fb9") -- Depot 4309281
-- setManifestid(4309281, "5481589699869826744", 216341207)