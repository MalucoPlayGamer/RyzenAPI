-- Lua provided by RyzenAPI
-- Game: Fantasy Adventure

-- MAIN APPLICATION
addappid(1547050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547051, 1, "cb9e6c7c3541449e56525130f0fb705f3574025cb7b2d7cebfe904d671be14a5")
