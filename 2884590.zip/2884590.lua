-- Lua provided by RyzenAPI
-- Game: addappid(2884590)

-- MAIN APPLICATION
addappid(2884590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884591, 1, "351dc77fd4cd53731fce8ac2986da24911ec9e3b945e63c2ee9f53437e0d3ea7")
