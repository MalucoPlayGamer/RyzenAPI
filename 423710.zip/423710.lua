-- Lua provided by RyzenAPI
-- Game: Invasion: Brain Craving

-- MAIN APPLICATION
addappid(423710)

-- MAIN APP DEPOTS / PACKAGES
addappid(423711, 1, "dcfd4903517e6c2134d2ffb62ba0a1a7025a59baa68ddb384f3d1019f9e6d82f")

