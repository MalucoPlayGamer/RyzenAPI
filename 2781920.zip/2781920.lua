-- Lua provided by RyzenAPI
-- Game: 2781920

-- MAIN APPLICATION
addappid(2781920)
-- Game: addappid(2781920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2781921, 1, "38df9152dfe12bf5a29829890a8e6d2d6d026b4d0b5b490506bfddb2b44731fc")
addappid(2781922, 1, "0d5c04a9387759a78098dce1c879dc80f241a5d0362b2d7c6bbabc62ccab89b6")
