-- Lua provided by RyzenAPI
-- Game: Embraced by Autumn

-- MAIN APPLICATION
addappid(1639920)
-- Game: addappid(1639920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639921, 1, "42e7c92a86bc9f58e029766024a24651bbeab529a71278734d36472b72e14678")
