-- Lua provided by RyzenAPI
-- Game: JOY OF PROGRAMMING - Software Engineering Simulator

-- MAIN APPLICATION
addappid(2216770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216771, 1, "141bcb6e19497179aa576f0e408d2e3ce26877d77ba1ef75fdbdda9e8393a8ef")
