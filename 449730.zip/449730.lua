-- Lua provided by RyzenAPI
-- Game: Ahnayro: The Dream World

-- MAIN APPLICATION
addappid(449730)
addappid(572780)

-- MAIN APP DEPOTS / PACKAGES
addappid(449731, 1, "09290dbbd5fb73b436b302fe971b30f8017552421f4b47ff4d9658b38c1b2f77")
addappid(449732, 1, "5d876a3de6821af07e4c683ec65b46b322c7eee323f816bc3234037fe88c1e71")
addappid(449733, 1, "254a440c648a9bc38c2d824fe61f9387e4d6976be2e06672acb8675b76c85ae8")
