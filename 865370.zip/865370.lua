-- Lua provided by RyzenAPI
-- Game: El Hincha - El Videojuego

-- MAIN APPLICATION
addappid(865370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(865371, 1, "e33d84ee0f21a00c7a8f67e4322cecb330b43e8b9be907520491d058e46dcbaa")

