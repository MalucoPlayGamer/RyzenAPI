-- Lua provided by RyzenAPI
-- Game: El Hincha - El Videojuego

-- MAIN APPLICATION
addappid(865370)
-- Game: addappid(865370)

-- MAIN APP DEPOTS / PACKAGES
addappid(865371, 1, "e33d84ee0f21a00c7a8f67e4322cecb330b43e8b9be907520491d058e46dcbaa")
