-- Lua provided by RyzenAPI 
-- Game: TheTravelGame
addappid(2123800)
addappid(2123801, 1, "d85f28bbf2e32287b2d76b08c0a2867bcb6936b2871aff21a9b48dadf164a68a")
