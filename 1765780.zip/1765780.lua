-- Lua provided by RyzenAPI 
-- Game: ADACA
addappid(1765780)
addappid(1765781, 1, "a2b4bbb80a4ba8398cac7652d458aad4e9999e347481f040b145352b0ff1b3f5")
