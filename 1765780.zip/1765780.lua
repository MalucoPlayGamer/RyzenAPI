-- Lua provided by RyzenAPI
-- Game: ADACA

-- MAIN APPLICATION
addappid(1765780)
-- Game: addappid(1765780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765781, 1, "a2b4bbb80a4ba8398cac7652d458aad4e9999e347481f040b145352b0ff1b3f5")
