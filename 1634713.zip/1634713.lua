-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Scenario & BGM Set 6

-- MAIN APPLICATION
addappid(1634713)
-- Game: addappid(1634713)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634713,0,"fd5cb9903472c07da75727589ed7f131cd073f83ad49082ec9660da5b67ece2b")
