-- Lua provided by RyzenAPI
-- Game: Game: Vivat Sloboda (2019)

-- MAIN APPLICATION
addappid(2294790)
-- Game: addappid(2294790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294791, 1, "f0534544e78ede51060c3ccb0295de84d7eb7de98543678c09a9ade107649bf2")
