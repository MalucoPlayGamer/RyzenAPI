-- Lua provided by SkyAPI 
-- Game: AppID 572230
addappid(572230)
addappid(572231, 1, "c6a48d8eb71f08f65f2a75048dd823cdc82245cf378593367cccc3f0134443df")
