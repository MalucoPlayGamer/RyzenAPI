-- Lua provided by RyzenAPI
-- Game: AppID 572230

-- MAIN APPLICATION
addappid(572230)
-- Game: addappid(572230)

-- MAIN APP DEPOTS / PACKAGES
addappid(572231, 1, "c6a48d8eb71f08f65f2a75048dd823cdc82245cf378593367cccc3f0134443df")
