-- Lua provided by RyzenAPI
-- Game: Game: Gunsmith Simulator Playtest

-- MAIN APPLICATION
addappid(1914150)
-- Game: addappid(1914150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914151, 1, "c0e148baa0dc5297e72577895094de42b1c71aa12bc4f3df3dfb767083d6c5ff")
