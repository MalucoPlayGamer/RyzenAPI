-- Lua provided by RyzenAPI
-- Game: Lethal League Blaze

-- MAIN APPLICATION
addappid(553310)

-- MAIN APP DEPOTS / PACKAGES
addappid(553311, 1, "18bc20fa81ac54e8a21972ccb0bb1ea544f5114601bc5935db04a666290c82d1")
addappid(553312, 1, "4553f00d45260e808fc63b37276a91f85240bb69663db2abc4f84718a9b58693")
addappid(553313, 1, "69fed17d7422bf8e906f6be58f9d9c52f07f03c667ba83a66c872827d434072b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1174410)
addappid(1204070)
addappid(1244880)
addappid(1269880)
addappid(1399790)
addappid(1399791)
addappid(1431700)
addappid(1431701)
addappid(1431702)
addappid(1431710)
addappid(1431711)
addappid(1431712)
