-- Lua provided by RyzenAPI
-- Game: Gurney to Gurney

-- MAIN APPLICATION
addappid(1486880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486881, 1, "ffda58b53c216cb791559adc4516c1c44c0e1a3db447d2a72e348ed9d4f7dd15")
