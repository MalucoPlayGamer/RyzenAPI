-- Lua provided by RyzenAPI
-- Game: Coaster of Carnage VR

-- MAIN APPLICATION
addappid(737260)
-- Game: addappid(737260)

-- MAIN APP DEPOTS / PACKAGES
addappid(737261, 1, "24218333c835895ddf6552b79ab49117716d2bd783cc84e130cec628a7bef5ca")
