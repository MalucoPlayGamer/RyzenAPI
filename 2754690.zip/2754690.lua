-- Lua provided by SkyAPI 
-- Game: I've Fallen For You!
addappid(2754690)
addappid(2754691, 1, "ecc0e3b9398961f854694debcf5bf0c3a66fb1e901794f648195abce8e6f24c0")
addappid(2754695, 1, "c16f51ffd10cbb9973c2a783df9b47c65fd24088fa4f4f5cf65158dbac600a76")
