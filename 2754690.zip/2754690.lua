-- Lua provided by RyzenAPI
-- Game: I've Fallen For You!

-- MAIN APPLICATION
addappid(2754690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2754691, 1, "ecc0e3b9398961f854694debcf5bf0c3a66fb1e901794f648195abce8e6f24c0")
addappid(2754695, 1, "c16f51ffd10cbb9973c2a783df9b47c65fd24088fa4f4f5cf65158dbac600a76")

