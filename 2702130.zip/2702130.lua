-- Lua provided by RyzenAPI
-- Game: 2702130

-- MAIN APPLICATION
addappid(2702130)
-- Game: addappid(2702130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702131, 1, "aa4b9f7091c8ad11b13e560ef65af583094c86a1c74b4bff1dfe0da3334134fd")
