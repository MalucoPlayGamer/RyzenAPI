-- Lua provided by RyzenAPI
-- Game: SCARLET NEXUS - Digital Artbook

-- MAIN APPLICATION
addappid(1590551)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590551,0,"5fb3cac1db8825ad7ae70fd945ee45406207acaad40f2c66cd3de89ec761a408")

