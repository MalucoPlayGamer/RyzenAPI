-- Lua provided by RyzenAPI
-- Game: Balloon Blowout

-- MAIN APPLICATION
addappid(542740)

-- MAIN APP DEPOTS / PACKAGES
addappid(542741, 1, "dc03904e6d3dfb9966a97f070a6b39482e430757b35d7db2fcd9366fb356743c")

