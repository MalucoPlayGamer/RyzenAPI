-- Lua provided by RyzenAPI
-- Game: addappid(2209780)

-- MAIN APPLICATION
addappid(2209780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209781, 1, "ee60d98c1b15b9f8d0815f0720611e64ba01f903fdb562ad652f5d48778d1ccb")
