-- Lua provided by RyzenAPI
-- Game: STELLATUM

-- MAIN APPLICATION
addappid(691630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(691631, 1, "5ca38a03e534ddac709d0e4865cbd7db08531e098349fb1f1f68c68fe9e9f92d")

