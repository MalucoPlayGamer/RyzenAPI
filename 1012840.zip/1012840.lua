-- Lua provided by RyzenAPI
-- Game: addappid(1012840)

-- MAIN APPLICATION
addappid(1012840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012841, 1, "757c1c2eef78cb0186c8b2e75d32c5a7a981fc97ea92bf042014c83bbc607445")
