-- Lua provided by RyzenAPI 
-- Game: Decks Of Power
addappid(2216700)
addappid(2216701, 1, "53b66f4e80cee01d010bb4a32ff78c1cdced48757452600e2bb6f6a297562056")
