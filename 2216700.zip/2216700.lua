-- Lua provided by RyzenAPI
-- Game: Game: Decks Of Power

-- MAIN APPLICATION
addappid(2216700)
-- Game: addappid(2216700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216701, 1, "53b66f4e80cee01d010bb4a32ff78c1cdced48757452600e2bb6f6a297562056")
