-- Lua provided by RyzenAPI
-- Game: Guns, Gore & Cannoli

-- MAIN APPLICATION
addappid(322210)
-- Game: addappid(322210)

-- MAIN APP DEPOTS / PACKAGES
addappid(322212,0,"6cc2551f8d640dcef22e3b8e42ef73ecc99eab7746cef840452c81402a803885")
addappid(322213,0,"6ae067adc26cb651c142b5d607c4133a8421286b4a97bb1924d0d6549087b34c")
