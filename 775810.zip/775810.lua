-- Lua provided by RyzenAPI
-- Game: 775810

-- MAIN APPLICATION
addappid(775810)
-- Game: addappid(775810)

-- MAIN APP DEPOTS / PACKAGES
addappid(775811, 1, "8b3e54d3378a1979ff8cc53e85be70539ce8d0e2e6d7cf4fb81a11d2d20f8aa9")
