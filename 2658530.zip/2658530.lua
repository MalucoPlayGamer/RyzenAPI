-- Lua provided by RyzenAPI
-- Game: addappid(2658530)

-- MAIN APPLICATION
addappid(2658530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658531, 1, "64f6d3ba8f6bcd149de511c230c7af1cd9fe48ab0e4d6fac321b3b3753bf8d78")
