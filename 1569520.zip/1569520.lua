-- Lua provided by RyzenAPI
-- Game: Game: IRMÃO Grande & Brasileiro 2

-- MAIN APPLICATION
addappid(1569520)
-- Game: addappid(1569520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569521, 1, "3cf80fa8a4618508646172b8463e162009fdd1be6be5812b2cead15c22855c48")
