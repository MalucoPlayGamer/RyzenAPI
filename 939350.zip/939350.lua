-- Lua provided by RyzenAPI
-- Game: 939350

-- MAIN APPLICATION
addappid(939350)
-- Game: addappid(939350)

-- MAIN APP DEPOTS / PACKAGES
addappid(939351, 1, "d2c2daae960546ebb462448ded99aded4d8882b50a3784e50ece006d41e07767")
