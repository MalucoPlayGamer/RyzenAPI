-- Lua provided by RyzenAPI
-- Game: NEKOPALIVE

-- MAIN APPLICATION
addappid(469990)

-- MAIN APP DEPOTS / PACKAGES
addappid(469991, 1, "07bc91442bc6e5407ba8bd72e061a8e18c4d7f1c009c9d59cb37f51047aff766")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
