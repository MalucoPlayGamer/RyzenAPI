-- Lua provided by RyzenAPI
-- Game: Game: NEKOPALIVE

-- MAIN APPLICATION
addappid(469990)
-- Game: addappid(469990)

-- MAIN APP DEPOTS / PACKAGES
addappid(469991, 1, "07bc91442bc6e5407ba8bd72e061a8e18c4d7f1c009c9d59cb37f51047aff766")
