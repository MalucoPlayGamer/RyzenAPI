-- Lua provided by RyzenAPI
-- Game: addappid(3568450)

-- MAIN APPLICATION
addappid(3568450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3568451, 1, "aea71f4d6ab62306b1fc04d9b8fff352bec428f35a7cc116a0caccc8cc5fc95e")
