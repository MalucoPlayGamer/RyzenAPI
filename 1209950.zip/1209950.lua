-- Lua provided by RyzenAPI
-- Game: Game: Race Condition

-- MAIN APPLICATION
addappid(1209950)
-- Game: addappid(1209950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209951, 1, "2be7f14b09c2c85b14601b800cfe063c3d5a0a51adcdcf5283d970e3830c4f18")
