-- Lua provided by RyzenAPI
-- Game: Game: CHAQS

-- MAIN APPLICATION
addappid(2183200)
-- Game: addappid(2183200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183201, 1, "874366c7b575a7cbb6d4ea3789b41633d32180b6fcdb2b13880453816862940b")
