-- Lua provided by SkyAPI 
-- Game: CHAQS
addappid(2183200)
addappid(2183201, 1, "874366c7b575a7cbb6d4ea3789b41633d32180b6fcdb2b13880453816862940b")
