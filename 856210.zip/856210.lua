-- Lua provided by RyzenAPI
-- Game: bit Dungeon III

-- MAIN APPLICATION
addappid(856210)
addappid(1080810)

-- MAIN APP DEPOTS / PACKAGES
addappid(856211, 1, "067d38de4e3ba30d38bc655cad09e62bf2f6d6e835db9a0976f372c71fe69e4e")
