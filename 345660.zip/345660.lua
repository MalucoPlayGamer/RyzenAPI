-- Lua provided by RyzenAPI
-- Game: RIDE

-- MAIN APPLICATION
addappid(345660)

-- MAIN APP DEPOTS / PACKAGES
addappid(345661, 1, "e8f50246f5d90632fe6963ce8e7ed7cd242c514771f8d56928cc2cd0fe8e8e2e")
addappid(345900, 0, "f21e8546519f60099e57f381bc5b599f7029da4aa9f7449406482dad4b6dcf5d")
addappid(347450, 0, "d640f5d4b67955b393f54566c0e4001bc2050622d3cdfe5975cfb0042d4a7ae9")
addappid(392880, 0, "1227b828c146a6a5913adb72eee06fd353348ec690d6db70ac6c0e813e080d2e")
addappid(392900, 0, "389455b3c707e870a0814912d6ce1432f7914cd51a57e5da4d18cd4cffec0b6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(352570)
