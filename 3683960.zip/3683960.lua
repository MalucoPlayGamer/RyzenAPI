-- Lua provided by RyzenAPI 
-- Game: Magical Runes
addappid(3683960)
addappid(3683961, 1, "5e96f48b0d15c315aacc2f8bf309f8b9aca8fd85250e6d4f11447a8d3a1e0fa8")
