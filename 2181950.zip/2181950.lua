-- Lua provided by SkyAPI 
-- Game: Zero Division
addappid(2181950)
addappid(2181951, 1, "0dc1bbb61ef526c6414a658bfc273f863bcc19294d006b130f3119b807e0b475")
