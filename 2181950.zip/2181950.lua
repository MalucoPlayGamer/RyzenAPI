-- Lua provided by RyzenAPI
-- Game: Game: Zero Division

-- MAIN APPLICATION
addappid(2181950)
-- Game: addappid(2181950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181951, 1, "0dc1bbb61ef526c6414a658bfc273f863bcc19294d006b130f3119b807e0b475")
