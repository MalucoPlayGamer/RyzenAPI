-- Lua provided by RyzenAPI 
-- Game: AppID 1368430
addappid(1368430)
addappid(1368431, 1, "7d711af587800455413f11899badecff39b5735068ee6ae13decccd1e85de628")
