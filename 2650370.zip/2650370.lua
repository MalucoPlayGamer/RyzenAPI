-- Lua provided by RyzenAPI
-- Game: Jennifer's Fragments Demo

-- MAIN APPLICATION
addappid(2650370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650371, 1, "aa0344814b220b79b672a1f748403eef6140fb14f73c0dd26ddf4eac0e678f12")

