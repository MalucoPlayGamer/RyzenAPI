-- Lua provided by SkyAPI 
-- Game: Backpack Hero Soundtrack
addappid(2109040)
addappid(2109041, 1, "a29772d165d49b2ddf71ccc2c2e76d2cfcabf6143c08ac9f7dde1b42319fd48f")
addappid(2109042, 1, "4702a7144541d0acf9240c490b24a26853bd80218d919fa8872e2ccc2eb22a2f")
