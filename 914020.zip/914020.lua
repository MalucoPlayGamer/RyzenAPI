-- Lua provided by RyzenAPI
-- Game: Game: AppID 914020

-- MAIN APPLICATION
addappid(914020)
addappid(1133190)
addappid(1133220)
-- Game: addappid(914020)

-- MAIN APP DEPOTS / PACKAGES
addappid(914021, 1, "72e992c9ccc882a0af28db31e0f588b156bbfc3627077e55b97f61d326c485f2")
addappid(914022, 1, "179aa5f3cd04264627664667e056b918ac9e56bc2408ad1cc59339a7878d2b93")
addappid(914023, 1, "1e06b27ce40d919df0ca58de4255e94eb47adb4d613d5c723bbbb418cd11338c")
addappid(914024, 1, "38234df98efe3ba4fa0929ccda00ade26c7b225ad8321af5c722c0a7a6dcfc01")
addappid(1133160, 0, "77da6896dcdb8a212aba44a2c9addb732bf4deedaaeea0b63853aabed68a2291")
addappid(1133170, 0, "2b073fd2ecd8193c9a5b247a05974db98e488b9a71599616ee9371e2aaf33ba6")
