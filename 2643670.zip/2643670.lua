-- Lua provided by RyzenAPI
-- Game: Game: 女拳主義F-ist！一般向版 Soundtrack

-- MAIN APPLICATION
addappid(2643670)
-- Game: addappid(2643670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2643671, 1, "82e05e71349295691654b5757cf854c6d18253f671d97a96397056fb87900038")
