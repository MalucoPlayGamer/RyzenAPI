-- Lua provided by RyzenAPI
-- Game: I'm on Observation Duty 6

-- MAIN APPLICATION
addappid(2137700)
-- Game: addappid(2137700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137701, 1, "9b3075859192dff61b3969516dcefdda9a988367fe647fc8d03fb36ff9731554")
addappid(2137702, 1, "f6f566318ace444903e4060b6cb258b55f410d53a3f4c50560dec1bdb5b62bc2")
addappid(2137703, 1, "bb1eea330fc0b72199468c39ad090273fec258e1b9572b36b4559db02a4b23d2")
