-- Lua provided by RyzenAPI
-- Game: WAR Pig - Big Bang

-- MAIN APPLICATION
addappid(736610)

-- MAIN APP DEPOTS / PACKAGES
addappid(736611,0,"56186e5d7741f40b9ba171b913fb1634946d17e082cc4f7c147a205f95d81983")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
