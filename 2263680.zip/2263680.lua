-- Lua provided by RyzenAPI
-- Game: 2263680

-- MAIN APPLICATION
addappid(2263680)
-- Game: addappid(2263680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263681, 1, "9fcb0c589ebcd2c577b1b653b5bb36e556bc926e57f48de32b8e1d3f3426e533")
