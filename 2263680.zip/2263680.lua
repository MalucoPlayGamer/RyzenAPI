-- Lua provided by SkyAPI 
-- Game: Furry OwO
addappid(2263680)
addappid(2263681, 1, "9fcb0c589ebcd2c577b1b653b5bb36e556bc926e57f48de32b8e1d3f3426e533")
