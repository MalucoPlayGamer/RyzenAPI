-- Lua provided by RyzenAPI
-- Game: Gathering Sky

-- MAIN APPLICATION
addappid(356250)
addappid(393640)

-- MAIN APP DEPOTS / PACKAGES
addappid(356251, 1, "8b8bcd15c777c1fe6c4a1605147beeb899e78cc0d53d69015d81516b5f726dec")

