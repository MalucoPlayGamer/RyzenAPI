-- Lua provided by RyzenAPI
-- Game: Lost At Sea

-- MAIN APPLICATION
addappid(1278750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278751, 1, "9fc1f03656b0eb3bd11defa63e0c4de901ef31fe5a3c37c304d7b3ac8d3e4c2e")
