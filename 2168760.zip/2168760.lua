-- Lua provided by RyzenAPI
-- Game: Attic Panic

-- MAIN APPLICATION
addappid(2168760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168761, 1, "2cb56f3ab085463a0f732e918640c20ce87f02edb9b34e586421151ab26bba35")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
