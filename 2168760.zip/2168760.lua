-- Lua provided by RyzenAPI
-- Game: Attic Panic

-- MAIN APPLICATION
addappid(2168760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2168761, 1, "2cb56f3ab085463a0f732e918640c20ce87f02edb9b34e586421151ab26bba35")

