-- Lua provided by SkyAPI 
-- Game: Bandit Point
addappid(1105430)
addappid(1105431, 1, "11989005063a2357c418082c4c531c8d7353abcb6dd09e8f91d273f26b78354d")
