-- Lua provided by RyzenAPI
-- Game: 2931750

-- MAIN APPLICATION
addappid(2931750)
-- Game: addappid(2931750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2931751, 1, "aeb13259c1582136a9cc085b58c07b43fd9bc3287c725fac54e55cdf17b972ca")
