-- Lua provided by RyzenAPI
-- Game: AppID 847650

-- MAIN APPLICATION
addappid(847650)
-- Game: addappid(847650)

-- MAIN APP DEPOTS / PACKAGES
addappid(847651, 1, "8cd36e844861e1d91e5b16c623c382fc32c17c0c1f3e0f6f4dabc2c599a0616a")
