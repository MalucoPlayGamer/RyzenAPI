-- Lua provided by RyzenAPI
-- Game: You Must

-- MAIN APPLICATION
addappid(1726730)
-- Game: addappid(1726730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726731, 1, "047718a8778b0553f6edff4de290ad01317979e978bdf3c235a92b8026d2334a")
