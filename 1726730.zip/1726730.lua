-- Lua provided by SkyAPI 
-- Game: You Must
addappid(1726730)
addappid(1726731, 1, "047718a8778b0553f6edff4de290ad01317979e978bdf3c235a92b8026d2334a")
