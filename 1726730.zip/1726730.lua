-- Lua provided by RyzenAPI
-- Game: You Must

-- MAIN APPLICATION
addappid(1726730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726731, 1, "047718a8778b0553f6edff4de290ad01317979e978bdf3c235a92b8026d2334a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
