-- Lua provided by RyzenAPI
-- Game: 2725540

-- MAIN APPLICATION
addappid(2725540)
-- Game: addappid(2725540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725540,0,"20b4cbc7052583138526ea8c21a3c809713ba68bfc751231cc04ff22b0eab950")
