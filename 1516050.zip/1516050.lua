-- Lua provided by RyzenAPI
-- Game: 1516050

-- MAIN APPLICATION
addappid(1516050)
-- Game: addappid(1516050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1516051, 1, "96151a246dc4a04e6d2e2481aa98a60faa9e57bf60027058fc5fc752c06d8a43")
