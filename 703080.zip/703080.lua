-- Lua provided by RyzenAPI
-- Game: Game: AppID 703080

-- MAIN APPLICATION
addappid(703080)
-- Game: addappid(703080)

-- MAIN APP DEPOTS / PACKAGES
addappid(703081, 1, "bc33ccdea0df8610185dab43ef1f141daecf265e379acb2feb58fde38212796c")
addappid(1098120, 0, "9decae9ea2fe2d9055772fecad34b56835f0464dff8d4159d7457fc3586d2994")
