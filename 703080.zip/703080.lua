-- Generated with Luie @ https://lua.tools/
-- 703080 - Planet Zoo
-- Generated 2026-08-08 17:05:35 UTC
-- # Depots (Total/DLC/Shared): 5/3/1

-- Main AppID
addappid(703080, 1, "519fa2ea9c9a1cca0bbd6cd0c7a7f8c220812ec10ef3f7402764d03bc6e8121c")

-- Main Depots
addappid(703081, 1, "bc33ccdea0df8610185dab43ef1f141daecf265e379acb2feb58fde38212796c") -- (windows, 64-bit)
setManifestid(703081, "6607940512589780813", 21984738007)

-- DLC's (no depot keys required)
addappid(1098121) -- DLC 1098121
addappid(1196770) -- Planet Zoo: Arctic Pack
addappid(1238440) -- Planet Zoo: South America Pack
addappid(1349400) -- Planet Zoo: Australia Pack
addappid(1471590) -- Planet Zoo: Aquatic Pack
addappid(1567110) -- Planet Zoo: Southeast Asia Animal Pack
addappid(1647620) -- Planet Zoo: Africa Pack
addappid(1726150) -- Planet Zoo: Europe Pack
addappid(1747960) -- Planet Zoo: North America Animal Pack
addappid(1934140) -- Planet Zoo: Wetlands Animal Pack
addappid(2013290) -- Planet Zoo: Conservation Pack
addappid(2150050) -- Planet Zoo: Twilight Pack
addappid(2199210) -- Planet Zoo: Grasslands Animal Pack
addappid(2346830) -- Planet Zoo: Tropical Pack
addappid(2436600) -- Planet Zoo: Arid Animal Pack
addappid(2502240) -- Planet Zoo: Oceania Pack
addappid(2675740) -- Planet Zoo: Eurasia Animal Pack
addappid(2837730) -- Planet Zoo: Barnyard Animal Pack
addappid(3146420) -- Planet Zoo: Zookeepers Animal Pack
addappid(3473820) -- Planet Zoo: Americas Animal Pack
addappid(3586990) -- Planet Zoo: Asia Animal Pack

-- DLC's (with depot keys)
-- Deluxe Edition Extras (AppID: 1098120)
addappid(1098120)
addappid(1098120, 1, "9decae9ea2fe2d9055772fecad34b56835f0464dff8d4159d7457fc3586d2994") -- (64-bit)
setManifestid(1098120, "10163085496252241", 796802319)
-- Planet Zoo Soundtrack (AppID: 1383610)
addappid(1383610)
addappid(1383611, 1, "7f6c35897448b21336cece1d72e8d98086e52e1f3321e7f21a0fdcf754b205e5")
setManifestid(1383611, "920395403518652583", 78633927)
addappid(1383612, 1, "60e9cb821b764d13f54d002f93c9bac4eda0da0afee5cd41ebe6f4d0304f7e9e")
setManifestid(1383612, "8061495413215669178", 704417818)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
