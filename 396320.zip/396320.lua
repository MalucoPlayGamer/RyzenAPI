-- Lua provided by RyzenAPI
-- Game: Tank Battle: 1944

-- MAIN APPLICATION
addappid(396320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(396321, 1, "985ac4270db2fc755aa6bd6aca31e5a593e58523ae71f5b2c3a8b9c5e6cc12d1")
