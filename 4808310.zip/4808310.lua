-- Lua provided by RyzenAPI
-- Game: Water Margin Online

-- MAIN APPLICATION
addappid(4808310)

