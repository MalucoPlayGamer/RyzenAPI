-- Lua provided by RyzenAPI
-- Game: 1866970

-- MAIN APPLICATION
addappid(1866970)
-- Game: addappid(1866970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866971, 1, "5cb5f097370c481be7410ed66a5384f94e2829267ae3500f00d9f9b26ab0e0bd")
