-- Lua provided by RyzenAPI
-- Game: Gremlins, Inc.

-- MAIN APPLICATION
addappid(369990)

-- MAIN APP DEPOTS / PACKAGES
addappid(369991, 1, "534b5beaad35355d46d32578854588a8a12e256a227d6af56643edbab2fb4a3e")
addappid(369992, 1, "ad045829679383a71655fdd92629e2f3cefdfac79596755a30e07364fda4293b")
addappid(369993, 1, "1f7fc9d5204aa79384151c69b69ac1d57adf3be6e28c7fb53e6be2ab5e8fb8f8")
addappid(369997, 1, "d90a7d03e205e63214fce340a5564524a3f2dc418749e125b618a8c42ccd583e")
addappid(459850, 0, "642c77cf81e4232eb6fd6440aec5ccd0b083b711e4193960106288f80bed501e")
addappid(748260, 0, "6141e4e63285cd11dd78edfdc1da90d44974b5cd03a125ffb8964d9539154b63")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(723650)
addappid(1438000)
