-- Lua provided by RyzenAPI
-- Game: 名城BGM合辑

-- MAIN APPLICATION
addappid(1086930)
-- Game: addappid(1086930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086931, 1, "22c376472344edda762fa56eb33e4637eb5c9181537c245148b9cd93129aa04f")
