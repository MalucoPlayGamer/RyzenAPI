-- Lua provided by RyzenAPI
-- Game: Hell Let Loose (Public Testing)

-- MAIN APPLICATION
addappid(1504860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504861, 1, "7ee72a319b695503ce98c5906a2d3904476bd5984c71c65eb2c569a2c5316466")

