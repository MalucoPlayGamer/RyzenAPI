-- Lua provided by RyzenAPI
-- Game: Game: Lunar's Chosen - Episode 2

-- MAIN APPLICATION
addappid(2697200)
-- Game: addappid(2697200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697201, 1, "cf5102de16e633442d20f7406291225f6562678d652f35702a67998b4592f2b2")
