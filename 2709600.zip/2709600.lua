-- Lua provided by RyzenAPI
-- Game: SynthwaveZ

-- MAIN APPLICATION
addappid(2709600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709601, 1, "72e0a2307c7ce08e95b11300a3b624fa5bfc2d627231317c6c51b8a1b5f8c3eb")

