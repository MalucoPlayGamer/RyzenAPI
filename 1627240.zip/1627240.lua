-- Lua provided by RyzenAPI
-- Game: At the behest of the Pike: Time To Run

-- MAIN APPLICATION
addappid(1627240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1627241, 1, "315c36312d749238b9bc863ca8c7694b16f5b99e102360303415c17c64e33239")
