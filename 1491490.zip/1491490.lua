-- Lua provided by RyzenAPI 
-- Game: AppID 1491490
addappid(1491490)
addappid(1491491, 1, "1f43db1ba4f74aa5b7e34adcc849fffd153d4d7fcc7f5dd84c58083ea1e4097c")
