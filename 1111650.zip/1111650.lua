-- Lua provided by RyzenAPI
-- Game: Never BreakUp

-- MAIN APPLICATION
addappid(1111650)
-- Game: addappid(1111650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111651, 1, "1265e58e4879b9d404f760446123810a2e06e8a46d383538003a98e2bf3bd596")
