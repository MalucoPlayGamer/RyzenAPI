-- Lua provided by RyzenAPI 
-- Game: Subsistence
addappid(418030)
addappid(418031, 1, "8d66bdcb4dab122aa828e7fb3d4c3212e75f48250b2e87b3e65fd07559a62746")
