-- Lua provided by RyzenAPI
-- Game: addappid(1599180)

-- MAIN APPLICATION
addappid(1599180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599180,0,"aaeff3311f31a7ddc0e96e5e8b68dbf470632414492e341c5d1eb43d4f052b05")
