-- Lua provided by RyzenAPI
-- Game: 2969900

-- MAIN APPLICATION
addappid(2969900)
-- Game: addappid(2969900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969900,0,"0f81b41ef5f3cfc4d4e228ceaf594961e86756586f8105927cfab44755d622f5")
