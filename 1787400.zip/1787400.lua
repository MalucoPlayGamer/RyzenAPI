-- Lua provided by RyzenAPI
-- Game: Mandala

-- MAIN APPLICATION
addappid(1787400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787401, 1, "8403604e7b2693fdd9ed4e754f211572e953e07d8921bb9bd149c5924fd9c368")
