-- Lua provided by RyzenAPI
-- Game: The Invincible: Art Book & Comic Book

-- MAIN APPLICATION
addappid(2622920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622920,0,"14917a90d1ac4fc46a4819fac3edaa31e63643f67fa7e33af624d7893a36e89a")

