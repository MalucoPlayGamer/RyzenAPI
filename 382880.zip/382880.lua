-- Lua provided by RyzenAPI
-- Game: Game: Feudalism

-- MAIN APPLICATION
addappid(382880)
-- Game: addappid(382880)

-- MAIN APP DEPOTS / PACKAGES
addappid(382881, 1, "815a3c0c9c676bd23a92543012738152eb97cb56b93555541b63fa91b5db6ee8")
