-- Lua provided by RyzenAPI
-- Game: 368650

-- MAIN APPLICATION
addappid(368650)
-- Game: addappid(368650)

-- MAIN APP DEPOTS / PACKAGES
addappid(368651, 1, "e5cbc89acc7aeccb4b7f28ada24f43c323712ef6894daaef49b8c8d00c92f2d2")
