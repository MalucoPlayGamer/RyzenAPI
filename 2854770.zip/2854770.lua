-- Lua provided by RyzenAPI
-- Game: Game: Faceless

-- MAIN APPLICATION
addappid(2854770)
-- Game: addappid(2854770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854771, 1, "af311e20e2cf52139a55ac51ea04af50ed3d366933a85607897f7aa9e4a1447f")
