-- Lua provided by RyzenAPI
-- Game: Faceless

-- MAIN APPLICATION
addappid(2854770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2854771, 1, "af311e20e2cf52139a55ac51ea04af50ed3d366933a85607897f7aa9e4a1447f")

