-- Lua provided by RyzenAPI
-- Game: The story of Bill Bear

-- MAIN APPLICATION
addappid(1689310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689311,0,"1114f4dd8e9bd1cd1ead000a386b35d1b865efaad7f2c3705b3feedb36786445")

