-- Lua provided by RyzenAPI
-- Game: Starlights / 별빛 아래

-- MAIN APPLICATION
addappid(2425420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2425421, 1, "8414c404d761eed9a69b184626504958c39879857ee1e8527d7faffa445375fc")

