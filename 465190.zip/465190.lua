-- Lua provided by RyzenAPI
-- Game: Space Survival

-- MAIN APPLICATION
addappid(465190)

-- MAIN APP DEPOTS / PACKAGES
addappid(465191, 1, "f39895f4b6c1dd555e5ef1e9e29004c1ed4b8cc81ff79e91144d17f876fa4198")
