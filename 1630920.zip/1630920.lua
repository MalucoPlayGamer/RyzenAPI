-- Lua provided by RyzenAPI
-- Game: Bright Lights of Svetlov

-- MAIN APPLICATION
addappid(1630920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630921, 1, "0e90a13fb5032cfbbb3e17fa9711e74550eabf3f8e45acfb1d0c5f58ee731c70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
