-- Lua provided by RyzenAPI
-- Game: 1465210

-- MAIN APPLICATION
addappid(1465210)
-- Game: addappid(1465210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465212,0,"b018f26d42ca8da3e0f53113d5e80e9f56e74fc5b798ec543b4f2da6ccb4000d")
