-- Lua provided by RyzenAPI
-- Game: Zerowood

-- MAIN APPLICATION
addappid(1276300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276301, 1, "8a5277f32756118c8bede809d4f3c1648fb9393ecfd53a32a5e3d3fb905e6524")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
