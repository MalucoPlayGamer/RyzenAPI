-- Lua provided by RyzenAPI
-- Game: 3453390

-- MAIN APPLICATION
addappid(3453390)
-- Game: addappid(3453390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453391, 1, "d44c263ba9c6062871a648cb0e08ec2473dda45f76c3ef33c26c88269559b4fa")
