-- Lua provided by SkyAPI 
-- Game: SQUASER 3
addappid(3453390)
addappid(3453391, 1, "d44c263ba9c6062871a648cb0e08ec2473dda45f76c3ef33c26c88269559b4fa")
