-- Lua provided by RyzenAPI
-- Game: Demon Runner The Forsaken

-- MAIN APPLICATION
addappid(1777130)
-- Game: addappid(1777130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777134,0,"96822940c0261bf4f86648d3e03d4c70e4831342940392a9eef945d34e9dc49d")
