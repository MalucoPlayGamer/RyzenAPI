-- Lua provided by RyzenAPI 
-- Game: AppID 2402820
addappid(2402820)
addappid(2402821, 1, "15948d8d3e9678b6a2c4f14a9810005935704768f119e3f681b2d396a3bcb85b")
