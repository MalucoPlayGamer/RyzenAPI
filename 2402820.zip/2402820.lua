-- Lua provided by RyzenAPI
-- Game: Hololive Room Visitor

-- MAIN APPLICATION
addappid(2402820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402821, 1, "15948d8d3e9678b6a2c4f14a9810005935704768f119e3f681b2d396a3bcb85b")

