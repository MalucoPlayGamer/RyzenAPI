-- Lua provided by RyzenAPI
-- Game: 剑与桃花 the sword and peachblossom

-- MAIN APPLICATION
addappid(1883320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883321, 1, "845ed75df3852925c4ea441190aa304561cc28ea5c67c21cc26e2956a7552b61")

