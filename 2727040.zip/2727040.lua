-- Lua provided by RyzenAPI
-- Game: Blood Sins

-- MAIN APPLICATION
addappid(2727040)
-- Game: addappid(2727040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2727041, 1, "25bc8f88705369f262d210bfb576068144492604d3bc556bdc9f05287e16f708")
