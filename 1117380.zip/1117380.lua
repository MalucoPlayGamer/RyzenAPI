-- Lua provided by RyzenAPI
-- Game: Project Cappuccino

-- MAIN APPLICATION
addappid(1117380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117382,0,"d3367e2f7a280a15fc61cf5b7f0eedbe3c3eefc12cbfa4a204cada80697995ee")
