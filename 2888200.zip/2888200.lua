-- Lua provided by RyzenAPI
-- Game: Same Room Same Day

-- MAIN APPLICATION
addappid(2888200)
-- Game: addappid(2888200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888201, 1, "a55aab1c25d4b066eca972989d2cb2e710d40ae803422fd9611c659b384547ec")
