-- Lua provided by SkyAPI 
-- Game: AppID 3170780
addappid(3170780)
addappid(3170781, 1, "07a03b5500c44c0165f92b44a0c05ef84391d98f21b6f4da62b881e42959c4e5")
