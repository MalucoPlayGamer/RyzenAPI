-- Lua provided by RyzenAPI
-- Game: Game: HEXAROMA: Village Builder

-- MAIN APPLICATION
addappid(3056580)
-- Game: addappid(3056580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056581, 1, "b0356baaaf926fe9395c4eea611a9b4c1fd3e3a46325bf29c4522188faea319a")
addappid(3056582, 1, "5c8986d4c03a89e80209e9947cbc40486fd213c89a16574017a7f627407633a1")
addappid(3056583, 1, "513638bb5cf7d5121e95d17f840c5eb60a4af75ebe28a11db3837b6c17bde2b0")
