-- Lua provided by SkyAPI 
-- Game: Dungeon Scavenger
addappid(1065880)
addappid(1065881, 1, "5c190abfa6f4fcda9aca23c717dc698b2d7a82c061e3879344890ce82c967308")
addappid(1261190, 0, "1685d5c2ec657eebc596b0b88b9e7738cc579dcbd31a4954c0be14c3a3434b8c")
