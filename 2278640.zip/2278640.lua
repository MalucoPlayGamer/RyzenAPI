-- Lua provided by RyzenAPI
-- Game: Game: Love on Leave

-- MAIN APPLICATION
addappid(2278640)
-- Game: addappid(2278640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278641, 1, "9d879805f5058c588b3f0b104df7303245e168f2973c8d016532c1c5118d7b11")
