-- Lua provided by RyzenAPI
-- Game: 898580

-- MAIN APPLICATION
addappid(898580)
-- Game: addappid(898580)

-- MAIN APP DEPOTS / PACKAGES
addappid(898581, 1, "339637c6f246111ff4ded245726ff874fb03ccaea1ef3afe940e1f79970885b4")
