-- Lua provided by RyzenAPI
-- Game: Premium Bowling

-- MAIN APPLICATION
addappid(898580)
addappid(3484900)
addappid(4159370)

-- MAIN APP DEPOTS / PACKAGES
addappid(898581,0,"339637c6f246111ff4ded245726ff874fb03ccaea1ef3afe940e1f79970885b4")

