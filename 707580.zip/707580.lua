-- Lua provided by RyzenAPI 
-- Game: AFFECTED: The Manor - The Complete Edition
addappid(707580)
addappid(707581, 1, "b38c28506ee134636745ef4e210420e92d5219118c73807c2a8f2ceca255c2af")
