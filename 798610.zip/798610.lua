-- Lua provided by RyzenAPI
-- Game: Game: AppID 798610

-- MAIN APPLICATION
addappid(798610)
-- Game: addappid(798610)

-- MAIN APP DEPOTS / PACKAGES
addappid(798611, 1, "80694577ae6489cba64d1ca57b553244f943e6567d6834e9e41f83a1f7a39511")
addappid(798612, 1, "a161d8bc1a87b16a2a541de320fcf83b53d32d3b0ab37e11a0fd7b2a003d2dfb")
addappid(798613, 1, "dcb75b45c9c938c35b6f13b4302886680dc861985f90c980e1ada19f98cebe7e")
