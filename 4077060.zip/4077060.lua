-- Lua provided by RyzenAPI
-- Game: Void Pachinko

-- MAIN APPLICATION
addappid(4077060) -- Void Pachinko

-- MAIN APP DEPOTS / PACKAGES
addappid(4077061, 1, "cb49b0a9b8a2d0d99de1ac82b1d86cbefb26185dd350349e03672f61dd5191ee") -- Depot 4077061

