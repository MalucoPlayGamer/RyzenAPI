-- 4077060's Lua and Manifest Created by Hubcap Manifest
-- Void Pachinko
-- Created: August 17, 2026 at 18:53:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4077060) -- Void Pachinko
-- MAIN APP DEPOTS
addappid(4077061, 1, "cb49b0a9b8a2d0d99de1ac82b1d86cbefb26185dd350349e03672f61dd5191ee") -- Depot 4077061
setManifestid(4077061, "5150615534068501406", 424948447)