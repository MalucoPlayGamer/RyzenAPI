-- Lua provided by RyzenAPI
-- Game: Love Duction! The Guide for Galactic Lovers

-- MAIN APPLICATION
addappid(1709210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709211, 1, "a64c494c3bbf84bbac8006f6ce1a0597f6eff340055af549b14504334ef87cef")
addappid(1709212, 1, "07971de6808799c4c47358b39d9cdb79f53d74c489b2d3efdb001ab3e7bf48b2")
addappid(1709213, 1, "5e5a1aedd4df714767779d085c771ccb0d3f77984784442b7482639083560a25")

