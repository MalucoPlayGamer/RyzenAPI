-- Lua provided by RyzenAPI
-- Game: Ingression

-- MAIN APPLICATION
addappid(1966970)
-- Game: addappid(1966970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966971, 1, "990b685fa72a70b100c18f813f97628473e661a1b749599e516a27f15ff44ffb")
