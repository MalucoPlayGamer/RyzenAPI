-- Lua provided by RyzenAPI
-- Game: Emergency Call - The Firefighting Simulation 3

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3447070, 1, "c6af6f263f0c60e3150f05b4ba22b45436372c0c79b3829d7befc20bd9747df3") -- Emergency Call - The Firefighting Simulation 3
addappid(3447071, 1, "41dade49d60136ed8e722896bf5fc6ffe2a6f69603e44729ea8864b21397e185") -- Depot 3447071

