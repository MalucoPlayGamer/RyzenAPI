-- Lua provided by RyzenAPI
-- Game: 1710890

-- MAIN APPLICATION
addappid(1710890)
-- Game: addappid(1710890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1710891, 1, "098e7e6ca83a887beda1b0c34e2c84e526980d6279e42790017d1593fcef56b6")
