-- Lua provided by RyzenAPI
-- Game: Mini Attack Submarine

-- MAIN APPLICATION
addappid(473630)

-- MAIN APP DEPOTS / PACKAGES
addappid(473631, 1, "f5a0bf14edbe2eee398727b9b6d4f7e15c87d8829f91b5dddd0bc9a12fc9963e")

