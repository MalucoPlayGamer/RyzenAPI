-- Lua provided by RyzenAPI
-- Game: AppID 738060

-- MAIN APPLICATION
addappid(738060)
-- Game: addappid(738060)

-- MAIN APP DEPOTS / PACKAGES
addappid(738061, 1, "51b7bc204a3706259c7bd67fe0d8d1108402ec4c747106dbf1927ebf9d507d47")
