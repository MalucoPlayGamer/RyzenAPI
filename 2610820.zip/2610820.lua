-- Lua provided by RyzenAPI
-- Game: addappid(2610820)

-- MAIN APPLICATION
addappid(2610820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610821, 1, "c3f762d347c43e744e46c4a34aacd034a31690fabe5d99c6c62afe1f0089b78b")
