-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Shop Materials Tileset - Interior / Exterior

-- MAIN APPLICATION
addappid(2003831)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003831,0,"651bc7e4356ea55ed56aeff5dae116adf8151960b19f81d7d30ad4288ecce689")
