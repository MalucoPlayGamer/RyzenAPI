-- Lua provided by RyzenAPI
-- Game: Six Braves 🕌

-- MAIN APPLICATION
addappid(1821570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821571, 1, "37badfe3c62bce36e29292c6d1f7aa959c568ee874e7cbf98fd0131481caffff")
addappid(1821572, 1, "14a00efa5e2fc43388cd664a6d4e49558dc6a1a7bc288d738d572a3d11182741")
addappid(1821573, 1, "8f68b3d358c9285dd6d4e4993fe4f4d03b72b8fb1ab4883903ca5e1190eaa3ff")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2063380)
addappid(2063381)
addappid(2063382)
addappid(2063383)
addappid(2063384)
addappid(2078900)
addappid(2078901)
addappid(2078902)
addappid(2078903)
addappid(3004820)
addappid(3004830)
addappid(3004840)
addappid(3004850)
addappid(3974670)
addappid(3974700)
addappid(3974710)
addappid(3974720)
