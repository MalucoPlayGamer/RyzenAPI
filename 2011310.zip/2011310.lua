-- Lua provided by RyzenAPI
-- Game: 2011310

-- MAIN APPLICATION
addappid(2011310)
addappid(2856860)
-- Game: addappid(2011310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011311, 1, "1ff8aab09974031ae2d2704a47763494d209035bd8fc907d3ac0474ae1d92e5d")
