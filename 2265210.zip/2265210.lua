-- Lua provided by RyzenAPI
-- Game: Sexy Milfs

-- MAIN APPLICATION
addappid(2265210)
-- Game: addappid(2265210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2265211, 1, "5960f8244a9240a5f016ac5a4103bad5c54523e41c4ffbabf46b818cab8ffd32")
