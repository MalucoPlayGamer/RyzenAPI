-- Lua provided by RyzenAPI
-- Game: Game: Homeseek

-- MAIN APPLICATION
addappid(2093000)
-- Game: addappid(2093000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093001, 1, "d349fa04978298822770f259221a3362e0772727776f4e7ade2b5afc9ce1142b")
