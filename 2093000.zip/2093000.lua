-- Lua provided by RyzenAPI 
-- Game: Homeseek
addappid(2093000)
addappid(2093001, 1, "d349fa04978298822770f259221a3362e0772727776f4e7ade2b5afc9ce1142b")
