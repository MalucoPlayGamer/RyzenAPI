-- Lua provided by RyzenAPI
-- Game: Full Fathom Demo

-- MAIN APPLICATION
addappid(3027290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027291, 1, "1891085d5d87411ad34d19a0b00f517006a3e5fd6b7b1c365205fdb3e3471137")
