-- Lua provided by RyzenAPI
-- Game: 3369360

-- MAIN APPLICATION
addappid(3369360)
-- Game: addappid(3369360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3369361, 1, "421826905c217b8ce6ba05bde89c4728993c198ce4b1ec8f4b10b81d596d9758")
