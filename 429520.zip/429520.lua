-- Lua provided by RyzenAPI
-- Game: Falcon Gold

-- MAIN APPLICATION
addappid(429520)

-- MAIN APP DEPOTS / PACKAGES
addappid(429522,0,"1bea2404f9978d47477d978d2cb5ba24acd8dcbef8f0a7cc4815f5f977d49d8f")
addappid(429523,0,"ce13e335104a60731fdee0febeeca968a07df7c0c435ac478169ada98b6bd788")
addappid(429524,0,"838974d8acdba2d055207027dae7ce1539fef704298bf8fddda0b85bfd35d736")

