-- Lua provided by RyzenAPI
-- Game: Game: AppID 898180

-- MAIN APPLICATION
addappid(898180)
-- Game: addappid(898180)

-- MAIN APP DEPOTS / PACKAGES
addappid(898181, 1, "66d80a8b94e98804010b2714f2620a6eb4952bc47d77936bf9728ce9330d4e34")
