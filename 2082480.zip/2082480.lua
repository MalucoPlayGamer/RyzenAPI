-- Lua provided by RyzenAPI
-- Game: 露娜传

-- MAIN APPLICATION
addappid(2082480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082481, 1, "4bfa86a94a9b4dc856eb561ac161f97e99cd1cd10315f152ad12382de9989036")

