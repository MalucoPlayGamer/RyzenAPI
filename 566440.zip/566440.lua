-- Lua provided by RyzenAPI
-- Game: Necromunda: Underhive Wars

-- MAIN APPLICATION
addappid(566440)

-- MAIN APP DEPOTS / PACKAGES
addappid(566441, 1, "7f7962d6904643d4302c51761c1c9011a1f3917da55447f3b6e5537cc44fa430")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1413520)
addappid(1437130)
addappid(1503980)
