-- Lua provided by RyzenAPI
-- Game: Dubio

-- MAIN APPLICATION
addappid(2780790)
-- Game: addappid(2780790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780791, 1, "cb6a23fb1af09ca12915faa4db6a89bb34cc88cfb711dec760297763edf06ffd")
