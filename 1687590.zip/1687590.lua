-- Lua provided by SkyAPI 
-- Game: Mars Base
addappid(1687590)
addappid(1687591, 1, "563ccc9eb5b6ae90dc1353a757afe2e74b0e62e10545053121c36e0be48dac8d")
addappid(1687592, 1, "19ad8fb3574daba6bf6309d459beac5db71021160fa9a4f5b21908395d1f93e2")
