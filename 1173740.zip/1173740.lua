-- Lua provided by SkyAPI 
-- Game: AppID 1173740
addappid(1173740)
addappid(1173741, 1, "399e0839ff1f9aca33aa0736bda50e0d45f39c5e7dafd392cc8b2994d56fab0c")
addappid(1173742, 1, "efe24ab8d44fb49f3b464d3ed2eb025b66ff43f20714b29d9883878ce9ae5edc")
addappid(1173743, 1, "73793c8692fdcd08c0c40a41e5af5cc4d45ca560608e38cfc634a15b8ac17a15")
