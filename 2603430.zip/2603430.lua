-- Lua provided by SkyAPI 
-- Game: Shell's Kitchen
addappid(2603430)
addappid(2603431, 1, "f80e334942fa753e428ac542d59c9da28b8e3274752231b78d320fad42157263")
