-- Lua provided by RyzenAPI
-- Game: Shell's Kitchen

-- MAIN APPLICATION
addappid(2603430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2603431, 1, "f80e334942fa753e428ac542d59c9da28b8e3274752231b78d320fad42157263")
