-- Lua provided by RyzenAPI
-- Game: PAKO 4

-- MAIN APPLICATION
addappid(3425320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3425321, 1, "e026ce5eb071913df9fdda35c4681d2aa4cdeea50b5c261ca6134e3e6af4fedf")
