-- Lua provided by SkyAPI 
-- Game: Can't You Run?
addappid(3618470)
addappid(3618471, 1, "fd7889d5819af27e35d82de04de41c5bcb88ba8ddb7976dc5acbef93b53c4adf")
