-- Lua provided by RyzenAPI
-- Game: Can't You Run?

-- MAIN APPLICATION
addappid(3618470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3618471, 1, "fd7889d5819af27e35d82de04de41c5bcb88ba8ddb7976dc5acbef93b53c4adf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
