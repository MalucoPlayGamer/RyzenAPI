-- Lua provided by RyzenAPI
-- Game: 3618470

-- MAIN APPLICATION
addappid(3618470)
-- Game: addappid(3618470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3618471, 1, "fd7889d5819af27e35d82de04de41c5bcb88ba8ddb7976dc5acbef93b53c4adf")
