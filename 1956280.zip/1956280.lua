-- Lua provided by RyzenAPI
-- Game: K3LVN

-- MAIN APPLICATION
addappid(1956280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1956281, 1, "7e30eefe7ec7dcc26280b092431bf9e25f846910c2c14903da516e5a7ffbc1b7")

