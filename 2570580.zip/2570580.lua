-- 2570580's Lua and Manifest Created by Hubcap Manifest
-- Ground Zero Hero
-- Created: August 21, 2026 at 14:10:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2570580) -- Ground Zero Hero
-- MAIN APP DEPOTS
addappid(2570581, 1, "fd5430468c69a620ba748c06c7c6728aac38910004079db345f9ce12cfe4ff61") -- Depot 2570581
setManifestid(2570581, "7655119505103895185", 1432397866)
addappid(2570584, 1, "4e2bdc8d0a95e87f82267dd9a0100977144fabd80294d4165e0cf83ca6033550") -- Depot 2570584
setManifestid(2570584, "6578143657923283404", 1455204459)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2570583) -- Depot 2570583 (empty depot)