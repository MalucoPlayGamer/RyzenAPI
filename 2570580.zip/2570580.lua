-- Lua provided by RyzenAPI
-- Game: Ground Zero Hero

-- MAIN APPLICATION
addappid(2570580) -- Ground Zero Hero
-- addappid(2570583) -- Depot 2570583 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570581, 1, "fd5430468c69a620ba748c06c7c6728aac38910004079db345f9ce12cfe4ff61") -- Depot 2570581
addappid(2570584, 1, "4e2bdc8d0a95e87f82267dd9a0100977144fabd80294d4165e0cf83ca6033550") -- Depot 2570584

