-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2743690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743690,0,"645740873c4328fe187ae90d539c9fea2e6808da8887c9c5da47edc04b52b32b")

