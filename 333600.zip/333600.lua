-- Lua provided by RyzenAPI
-- Game: Game: NEKOPARA Vol. 1

-- MAIN APPLICATION
addappid(333600)
-- Game: addappid(333600)

-- MAIN APP DEPOTS / PACKAGES
addappid(333601, 1, "bdf5b06a88583b3fbbf04c0981445513402f6bf3829b481ae22c2fc94aaa2239")
addappid(774071, 0, "761c64a8ef6b3df6e759840afcd412bcca2a90ebddef137c902f5a1753876747")
addappid(774081, 0, "7bfd2799098778336a5fcbf5f9fe0069d1ac449f2a897913b6f7ae7d2cec85f2")
addappid(947650, 0, "b1041cb48540022c18ac837d59f947c12ae2e0ca81d764ecb2a6588a7d5b79e9")
