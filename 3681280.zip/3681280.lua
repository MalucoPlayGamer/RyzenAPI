-- Lua provided by RyzenAPI
-- Game: Anime Girls Fantasy Desire [UNCENSORED]

-- MAIN APPLICATION
addappid(3681280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3681281, 1, "a3a8830f75b9bac22f96a00266497ceea9efb74f525b1f5bdca4f0d24300d6cd")

