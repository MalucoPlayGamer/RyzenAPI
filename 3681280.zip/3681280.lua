-- Lua provided by RyzenAPI
-- Game: Anime Girls Fantasy Desire [UNCENSORED]

-- MAIN APPLICATION
addappid(3681280)
-- Game: addappid(3681280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3681281, 1, "a3a8830f75b9bac22f96a00266497ceea9efb74f525b1f5bdca4f0d24300d6cd")
