-- Lua provided by RyzenAPI
-- Game: Doll Explorer

-- MAIN APPLICATION
addappid(2164930)
addappid(2425900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2164931, 1, "14746443226615c521b3f9e453ecc493976e6a17018ca09d33f20113fcb83dc7")
