-- Lua provided by RyzenAPI
-- Game: addappid(3169030)

-- MAIN APPLICATION
addappid(3169030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169031, 1, "8ce67eaf525ba5a3a0d7afc4790d735eca98d53b6ec6cd85a2d3c62d048b99f8")
