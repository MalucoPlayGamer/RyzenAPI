-- Lua provided by RyzenAPI
-- Game: Project Looking Glass

-- MAIN APPLICATION
addappid(4461730) -- Project Looking Glass

-- MAIN APP DEPOTS / PACKAGES
addappid(4461731, 1, "8858ad90bd99465404967189c54b179e0b7f09776d4170d0dd954699c6f60e63") -- Depot 4461731
addappid(4461732, 1, "45560165af039ac508df9f3f445e518eb6fc53ed557c70ad333f6bcc36d82a09") -- Depot 4461732

