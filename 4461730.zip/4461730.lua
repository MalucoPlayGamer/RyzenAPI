-- 4461730's Lua and Manifest Created by Hubcap Manifest
-- Project Looking Glass
-- Created: August 11, 2026 at 23:25:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4461730) -- Project Looking Glass
-- MAIN APP DEPOTS
addappid(4461731, 1, "8858ad90bd99465404967189c54b179e0b7f09776d4170d0dd954699c6f60e63") -- Depot 4461731
setManifestid(4461731, "956881890569125896", 1929668954)
addappid(4461732, 1, "45560165af039ac508df9f3f445e518eb6fc53ed557c70ad333f6bcc36d82a09") -- Depot 4461732
setManifestid(4461732, "6789660926782648283", 1961665308)