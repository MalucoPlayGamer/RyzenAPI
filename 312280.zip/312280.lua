-- Lua provided by RyzenAPI
-- Game: Simply Chess

-- MAIN APPLICATION
addappid(312280)
addappid(451690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(312281, 1, "69a2fb2dc2adc867ad24e9241f1aedaea96db70a23e455e04345e20a6cfb1077")
addappid(312282, 1, "49df50d71b1724a2abb85607e4965936e5829cdaec5c4296d87a699483cb303d")
addappid(312283, 1, "7506a5a2d120af2dd36bfea3049f3456a78731c705097f0452105aa0be188306")
addappid(312284, 1, "2c608a806e4a2c42ba1beeaf2d78590394f6e4767e1257f29d363a143fd1cc29")
addappid(312285, 1, "50e9bcb52c4f628c49a307d52b1f2cb3d68b7858e41603605dacfe8e3c792c77")

