-- Lua provided by RyzenAPI
-- Game: Firefight

-- MAIN APPLICATION
addappid(500190)

-- MAIN APP DEPOTS / PACKAGES
addappid(500191, 1, "8b95e697d05fe7d25c1c6b1bbe7e5dc87aa4b4a52da72fc60a4c1cc9f77def49")

