-- Lua provided by RyzenAPI
-- Game: 溶鉄のマルフーシャアートブック

-- MAIN APPLICATION
addappid(1512080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512080,0,"e9f6028233437a7743c327a099cf17162a93b23bb265ff098b3230e8ba32317e")

