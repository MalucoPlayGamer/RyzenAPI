-- Lua provided by RyzenAPI
-- Game: Aces Wild: Manic Brawling Action!

-- MAIN APPLICATION
addappid(269230)

-- MAIN APP DEPOTS / PACKAGES
addappid(269231, 1, "718f84bf20742f8e6a2dd7cd6e2adb9b181a92d9a0cc97c1ee914b4f54d5d83a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
