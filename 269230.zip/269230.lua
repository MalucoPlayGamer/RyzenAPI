-- Lua provided by RyzenAPI
-- Game: addappid(269230)

-- MAIN APPLICATION
addappid(269230)

-- MAIN APP DEPOTS / PACKAGES
addappid(269231, 1, "718f84bf20742f8e6a2dd7cd6e2adb9b181a92d9a0cc97c1ee914b4f54d5d83a")
