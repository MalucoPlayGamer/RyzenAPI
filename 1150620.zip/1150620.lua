-- Lua provided by SkyAPI 
-- Game: AppID 1150620
addappid(1150620)
addappid(1150621, 1, "c83bd5397394fec6878a3ebed5dd73e07a89ce1466e8c693bd176b0f00e7d08b")
addappid(1220610, 0, "d175449f9f0c12de1a1d1d2ddcdae29e71555701d6369aa2faad4e64a8f31327")
