-- Lua provided by RyzenAPI
-- Game: AppID 1042550

-- MAIN APPLICATION
addappid(1042550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1042551, 1, "bd80c7bd28d5cacbe5cc2dfafa6a9464b0e7fd8e769b04750ed0892ce11a162e")
addappid(1042552, 1, "96a03909c7aef73b6e510b6ac8b569f9792d7652e01175a5a374ee275deffda3")

