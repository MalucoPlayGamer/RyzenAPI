-- Lua provided by RyzenAPI
-- Game: 挂机修仙

-- MAIN APPLICATION
addappid(4343400)

-- MAIN APP DEPOTS / PACKAGES
addappid(4343401,0,"eea1f24c8dc2db61f1434d0018b3bd7ca5d6bb38f5b2f104d5ce1f6066695c96")

