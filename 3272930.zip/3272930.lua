-- Lua provided by RyzenAPI
-- Game: addappid(3272930)

-- MAIN APPLICATION
addappid(3272930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3272931, 1, "5497435ad57d66e673db7a1a652c86d0b5db54ad2071010d21805bbb7fe186b5")
