-- Lua provided by RyzenAPI
-- Game: Slash Quest

-- MAIN APPLICATION
addappid(2718010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718012,0,"6bed8ea89f5ae9c9ebf60e2596683f5365fc725d5061ffc150764c87341aa8c3")

