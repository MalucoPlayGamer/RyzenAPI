-- Lua provided by RyzenAPI
-- Game: addappid(2755330)

-- MAIN APPLICATION
addappid(2755330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755331, 1, "210347fd10d9ff3eabefdfca3a4471e392a3a9e1d70689e63953f055a30e2b99")
