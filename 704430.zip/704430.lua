-- Lua provided by RyzenAPI
-- Game: Space Survivors I: The Reckoning

-- MAIN APPLICATION
addappid(704430)

-- MAIN APP DEPOTS / PACKAGES
addappid(704431, 1, "ec220f6150785271fe87a9b064a26b864bd5c8a0b4ae902698b9e3f07cc48d78")

