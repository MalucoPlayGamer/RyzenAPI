-- Lua provided by RyzenAPI
-- Game: addappid(2689230)

-- MAIN APPLICATION
addappid(2689230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2689232,0,"3c86ce926b0e1af5d28774b3ed6109af98f6416d8c28b0f932a94760ea4e08b6")
