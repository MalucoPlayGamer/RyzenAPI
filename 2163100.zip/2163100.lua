-- Lua provided by RyzenAPI
-- Game: Divided Skies

-- MAIN APPLICATION
addappid(2163100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2163101, 1, "61028cfbad1a145c04210ba82f5838dff7ca24eca380d530e462f3ff14e40b5f")

