-- Lua provided by RyzenAPI
-- Game: Game: Garden Trills Demo

-- MAIN APPLICATION
addappid(3144650)
-- Game: addappid(3144650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144651, 1, "fdceff5775b98adbc9c2bafc8eca4af7e3d5a83a594b628936dc12f811dfb5ae")
