-- Lua provided by RyzenAPI
-- Game: 2594540

-- MAIN APPLICATION
addappid(2594540)
-- Game: addappid(2594540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594541, 1, "40b6afd176345586002abcd8bd747ce855610e6b83f2c426714b60d277d23b5c")
