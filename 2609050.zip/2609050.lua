-- Lua provided by RyzenAPI
-- Game: addappid(2609050)

-- MAIN APPLICATION
addappid(2609050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2609051, 1, "278870abf372cd3669d3a892d7d2aff8c120e9a611c27578b88e99929626ff4c")
