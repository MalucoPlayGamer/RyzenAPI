-- Lua provided by RyzenAPI
-- Game: Game: Colossus Down

-- MAIN APPLICATION
addappid(1394810)
-- Game: addappid(1394810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394811, 1, "73a623856919a7e75520416b7f98aec279e521b14ef8244fbd2a95b1704dc796")
