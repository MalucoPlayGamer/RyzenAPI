-- Lua provided by RyzenAPI
-- Game: PGA TOUR 2K21

-- MAIN APPLICATION
addappid(1016120)
addappid(1278950)
addappid(1278951)
addappid(1322120)
addappid(1715810)
addappid(1715811)
addappid(1715812)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016121,0,"e56e25231303fe96b29730d02302d47f0de4218e21a5480f0c6e3a79b3d2ca36")

