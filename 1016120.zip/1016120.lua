-- Lua provided by RyzenAPI
-- Game: Game: PGA TOUR 2K21

-- MAIN APPLICATION
addappid(1016120)
-- Game: addappid(1016120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016121, 1, "e56e25231303fe96b29730d02302d47f0de4218e21a5480f0c6e3a79b3d2ca36")
