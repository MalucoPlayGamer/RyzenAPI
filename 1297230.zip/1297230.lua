-- Lua provided by RyzenAPI
-- Game: Game: My Jigsaw Adventures - A Lost Story

-- MAIN APPLICATION
addappid(1297230)
-- Game: addappid(1297230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297231, 1, "3b43171fb2de88bdd692ea52e43496de6f69f9fba3cbde01473b7af54ceb56fe")
