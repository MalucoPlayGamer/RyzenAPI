-- Lua provided by RyzenAPI
-- Game: addappid(379640)

-- MAIN APPLICATION
addappid(379640)

-- MAIN APP DEPOTS / PACKAGES
addappid(379641, 1, "c61782d48db70395e1c3d61a49d0f0db4955fe3be7cfe45864c7b41fcdfb2306")
