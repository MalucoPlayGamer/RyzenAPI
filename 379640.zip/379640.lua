-- Lua provided by RyzenAPI
-- Game: Bloo Kid 2

-- MAIN APPLICATION
addappid(379640)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(379641, 1, "c61782d48db70395e1c3d61a49d0f0db4955fe3be7cfe45864c7b41fcdfb2306")

