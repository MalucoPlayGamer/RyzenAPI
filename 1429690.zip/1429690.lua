-- Lua provided by RyzenAPI
-- Game: Game: AppID 1429690

-- MAIN APPLICATION
addappid(1429690)
-- Game: addappid(1429690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429691, 1, "9137a89290f14b4ee1dd05dbe06fb51c240eeba50b48c3dfad7cfb51fd36af70")
