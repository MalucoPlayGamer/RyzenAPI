-- Lua provided by RyzenAPI
-- Game: Game: Bramble: The Mountain King Demo

-- MAIN APPLICATION
addappid(2161880)
-- Game: addappid(2161880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161881, 1, "e25dcadeed1b33860b993e25986acf8ab10bf0224567cb004bd98623e10b22f2")
