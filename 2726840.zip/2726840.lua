-- Lua provided by RyzenAPI
-- Game: Shadow of the Ninja - Reborn Demo

-- MAIN APPLICATION
addappid(2726840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2726841, 1, "031e71e928029bd29babfad2de2869c5345e8e11263caddec67d73c3fd202467")
