-- Lua provided by RyzenAPI 
-- Game: Protocol Xeno
addappid(2076430)
addappid(2076431, 1, "0f598b5bd32278f44db81b8b2f7f4a2de0db32ae1b7c8371e44d23c09d6efa18")
