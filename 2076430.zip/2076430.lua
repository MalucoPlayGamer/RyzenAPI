-- Lua provided by RyzenAPI
-- Game: Game: Protocol Xeno

-- MAIN APPLICATION
addappid(2076430)
-- Game: addappid(2076430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076431, 1, "0f598b5bd32278f44db81b8b2f7f4a2de0db32ae1b7c8371e44d23c09d6efa18")
