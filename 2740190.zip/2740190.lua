-- Lua provided by RyzenAPI
-- Game: Escape Qinglong Mountain Re

-- MAIN APPLICATION
addappid(2740190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2740191, 1, "487184fb778dfba47fd444281d3de1ad69a9dca791810e252b5a8d5a51b6e9ab")
