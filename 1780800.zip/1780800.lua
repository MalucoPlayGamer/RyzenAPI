-- Lua provided by RyzenAPI
-- Game: 1780800

-- MAIN APPLICATION
addappid(1780800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780800,0,"f456d8c431b78c65b06ec799f957cfbfeb8e46167cd83bd5f3987dca02b715fd")

