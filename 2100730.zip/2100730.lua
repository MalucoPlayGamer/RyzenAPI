-- Lua provided by RyzenAPI
-- Game: Tiles II - Multiplayer

-- MAIN APPLICATION
addappid(2100730)
-- Game: addappid(2100730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100731, 1, "a670489bd9c8043dbbfda07c45b2cc932792df778a4d730308a5bd7139f75ae6")
addappid(2100732, 1, "a2ff1aff46bfd3acdcf435498fac9b563cf3f470040b3d0e49b112ab9aa738a7")
