-- Lua provided by RyzenAPI
-- Game: INFINITY - Patch 18+

-- MAIN APPLICATION
addappid(1289910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289910,0,"cbccc872861af4df38c2701835465b196128d32bfbb52e5b6fc0b0a172a6e5bc")
