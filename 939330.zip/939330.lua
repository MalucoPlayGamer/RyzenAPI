-- Lua provided by RyzenAPI
-- Game: Tailor Tales

-- MAIN APPLICATION
addappid(1206450)
addappid(1206451)
addappid(1784030)
addappid(1784031)
addappid(1784032)
addappid(1784033)
addappid(4328740)
-- addappid(939332) -- Depot 939332 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(939330, 1, "0968ef3c84d5a7a41c9e665d59c26fb59b5b0f7836d27b6b9453ded7214a32c8") -- Tailor Tales
addappid(939331, 1, "b74ff7d851f165d2c1702be18c47c48a9a0722b083093bc38f06dd5349a7e229") -- Tailor Tales Content
addappid(1206450, 1, "a41a8bb0a1bbb7747189327aa614bd867ff214323c5cfcbf646a7fee979ac6a5") -- Tailor Tales - Neil Plus - Tailor Tales - Neil Plus (1206450) Depot
addappid(1206451, 1, "0596c984ea30b364ba208d7c648f0f008ec17162b34f7dca69b2180ed814da12") -- Tailor Tales - Dimitri Plus - Tailor Tales - Dimitri Plus (1206451) Depot
addappid(1784030, 1, "d43505e1a41c4bc57ed169a62aa9a48f87de8cbb5d39dd717612ca427f69bbc2") -- Tailor Tales - Caine Plus - Tailor Tales - Caine Plus (1784030) Depot
addappid(1784031, 1, "db4150c5c3d9344994ae080a1b9b8b8ecd941a6e21f033d5287fcbb9e6aa20dc") -- Tailor Tales - James Plus - Depot 1784031
addappid(1784032, 1, "d1b363f5a971f14c30b192ce977bb96c7482c364c54721e5b55776af07b42e3a") -- Tailor Tales - Gray Plus - Depot 1784032
addappid(1784033, 1, "9b1913a00b206f0bf244e082efb207b30ad2601da87d6533599c6142808585db") -- Tailor Tales - Aiden Plus - Depot 1784033
addappid(4328740, 1, "0b006fd07eb71fd0864d48c77dceb522bc368f625ac77698e7dad7c3647a0a72") -- Tailor Tales - Eeyok Plus - Depot 4328740

