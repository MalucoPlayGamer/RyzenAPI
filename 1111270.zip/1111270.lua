-- Lua provided by RyzenAPI
-- Game: AppID 1111270

-- MAIN APPLICATION
addappid(1111270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1111271, 1, "ba2b31c67eb03f4c07966b72fea45a307f8172b298585afcbfe6603593bfecaf")
