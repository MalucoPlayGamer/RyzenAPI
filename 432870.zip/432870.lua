-- Lua provided by RyzenAPI
-- Game: Special Tactics Online

-- MAIN APPLICATION
addappid(432870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(432871, 1, "dab3a6e661a9b0f4410eaaf4fb04081bc33a474491de6dace5d87514b631c397")

