-- Lua provided by RyzenAPI
-- Game: Game: AppID 432870

-- MAIN APPLICATION
addappid(432870)
-- Game: addappid(432870)

-- MAIN APP DEPOTS / PACKAGES
addappid(432871, 1, "dab3a6e661a9b0f4410eaaf4fb04081bc33a474491de6dace5d87514b631c397")
