-- Lua provided by RyzenAPI
-- Game: Dark Forest: The Horror

-- MAIN APPLICATION
addappid(1787600)
-- Game: addappid(1787600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787601, 1, "4561dd286a99f957da07d8eeaefc4f16a7e98317987e6093a34bff7d587c5fba")
