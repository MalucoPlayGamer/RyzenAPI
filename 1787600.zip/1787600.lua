-- Lua provided by RyzenAPI
-- Game: Dark Forest: The Horror

-- MAIN APPLICATION
addappid(1787600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1787601, 1, "4561dd286a99f957da07d8eeaefc4f16a7e98317987e6093a34bff7d587c5fba")

