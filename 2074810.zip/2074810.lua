-- Lua provided by RyzenAPI
-- Game: Game: 8-Bit Farm

-- MAIN APPLICATION
addappid(2074810)
-- Game: addappid(2074810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2074811, 1, "5eb0659157427f9f437a7e281ea5396d6e0d59f9233d7d8f177fc30e8099abf1")
