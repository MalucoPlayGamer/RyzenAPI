-- Lua provided by RyzenAPI
-- Game: Game: HeadSquare - Multiplayer VR Ball Game

-- MAIN APPLICATION
addappid(746340)
-- Game: addappid(746340)

-- MAIN APP DEPOTS / PACKAGES
addappid(746341, 1, "d21b2df5954917f589c8ae2ad158731e8dd91deaaf79b355658d15355aaacc87")
