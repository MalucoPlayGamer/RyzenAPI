-- 1714510's Lua and Manifest Created by Hubcap Manifest
-- Kusan : City of Wolves
-- Created: July 30, 2026 at 14:12:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1714510) -- Kusan : City of Wolves
addtoken(1714510, "12402117388446164269")
-- MAIN APP DEPOTS
addappid(1714511, 1, "53976ae31cd38a59921750ba0e8e0718b6b8475ed717838d780c57cc371cd27f") -- Depot 1714511
setManifestid(1714511, "3957563688958495815", 1682420108)