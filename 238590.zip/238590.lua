-- Lua provided by RyzenAPI
-- Game: Loadout Campaign Beta

-- MAIN APPLICATION
addappid(238590)
addappid(334380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(238591, 1, "412d0ccfd9ab1756149aee4761fd1f1d6950547eda946b2ea60fcffb3ec03358")
