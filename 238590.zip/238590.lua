-- Lua provided by RyzenAPI
-- Game: 238590

-- MAIN APPLICATION
addappid(238590)
-- Game: addappid(238590)

-- MAIN APP DEPOTS / PACKAGES
addappid(238591, 1, "412d0ccfd9ab1756149aee4761fd1f1d6950547eda946b2ea60fcffb3ec03358")
