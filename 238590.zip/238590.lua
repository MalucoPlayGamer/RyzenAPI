-- Lua provided by RyzenAPI
-- Game: AppID 238590

-- MAIN APPLICATION
addappid(238590)

-- MAIN APP DEPOTS / PACKAGES
addappid(238591, 1, "412d0ccfd9ab1756149aee4761fd1f1d6950547eda946b2ea60fcffb3ec03358")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(334380)
