-- Lua provided by RyzenAPI
-- Game: Furry Sex Madness

-- MAIN APPLICATION
addappid(1782970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782971, 1, "da592e74876eaa95f3a25710bb45917cf4c016d881cc126ff8c16ac32e8b291d")

