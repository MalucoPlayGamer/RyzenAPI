-- Lua provided by RyzenAPI
-- Game: PockeDate! - Pocket Dating Simulator

-- MAIN APPLICATION
addappid(3107350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107351, 1, "7c043d490c5e6bdf7387e138424a1256bae95788e0c0c8fbb2935c62c7867832")

