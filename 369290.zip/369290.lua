-- Lua provided by RyzenAPI
-- Game: Airport Madness: World Edition

-- MAIN APPLICATION
addappid(369290)

-- MAIN APP DEPOTS / PACKAGES
addappid(369291, 1, "afd6e8d0432e239a3fbefa78acccd8862863663ef77b5ace0e7ccedb7ae63e3d")
addappid(369292, 1, "d56f5373db354b2e09fad15ddaa29a4de5c48afe98d948af3adf4284c6543faf")
