-- Lua provided by SkyAPI 
-- Game: Bang Bang Fruit
addappid(587810)
addappid(587811, 1, "6dda1e285853fa53ddb83018dbe453a791f98a195f1c8b12f8e050fe3e4571ee")
