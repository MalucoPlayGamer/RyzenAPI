-- Lua provided by RyzenAPI
-- Game: addappid(485290)

-- MAIN APPLICATION
addappid(485290)

-- MAIN APP DEPOTS / PACKAGES
addappid(485291, 1, "7126e0713f0e620e2be31c59d652cd32fd3589f18e4b57a24781ee47311985bb")
