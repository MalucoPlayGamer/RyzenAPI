-- Lua provided by SkyAPI 
-- Game: AppID 485290
addappid(485290)
addappid(485291, 1, "7126e0713f0e620e2be31c59d652cd32fd3589f18e4b57a24781ee47311985bb")
