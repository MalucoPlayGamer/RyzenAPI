-- Lua provided by RyzenAPI
-- Game: Edge Of Eternity

-- MAIN APPLICATION
addappid(228982)
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228986)
addappid(228987)
addappid(228988)
addappid(228990)
addappid(229002)
addappid(229003)
addappid(229004)
addappid(269190)
addappid(1000400)
addappid(1654380)
addappid(1654381)

-- MAIN APP DEPOTS / PACKAGES
addappid(269192,0,"3be0d693bfabadf5da3ba2ddd078734d8e96f14a208a4d09c6badce98ab4eaa3")
addappid(269193,0,"30c612fb3378af1e486efc2f83629dfe36a6c8df3c5ed694871008381ffc5641")
addappid(1000407,0,"9b2a21f1cf04ff47ab7b6cf569025417edc66c0c78660fbb4d351b77e348da0f")
addappid(1000409,0,"7ffc6771f82f1536e873b7da59cc4cb4d5d9c1adfb2a0c77540cb4e347175bdd")

