-- Lua provided by RyzenAPI
-- Game: Let's Cook Together 2 Demo

-- MAIN APPLICATION
addappid(2003720)
-- Game: addappid(2003720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003721, 1, "ec0d952453e38c1b4761e58f8908de263ef029b8d84db7dff10172ec51746ac6")
