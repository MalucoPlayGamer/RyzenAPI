-- Lua provided by RyzenAPI
-- Game: Joint Task Force

-- MAIN APPLICATION
addappid(6400)
-- Game: addappid(6400)

-- MAIN APP DEPOTS / PACKAGES
addappid(6401, 1, "95a1efa40da4fd82fd8292707792ce43fc0f240911c285dd4248385acf9238a2")
addappid(6402, 1, "07615b2da527d8b6f0ccc19b17fad985ddbfaf2b4e4bc6f94a7d220074b03e95")
addappid(6403, 1, "16c717c71c2c808af622abf254050594494516152b5e960a18b33d088586782b")
addappid(6404, 1, "8ef3e46781586ecd4912a5fa31198d6df4e8033e64e8603e54f33d927dd0b8fc")
addappid(6405, 1, "22c59b41c4d249fbb3ed710c2a01d4d595d47d9b95a73dee0c97560bea488dbb")
addappid(6406, 1, "24af3dbb10d7b21ecff1107521b0f25cc6cea74b91dc8f7b540bb61cb52d7875")
addappid(6407, 1, "cee9837903c0ebd47c7147322e2cee901fc53bc902a411b007230d3a2c81bc76")
