-- Lua provided by RyzenAPI
-- Game: DFF NT: Platinum Fists, Tifa Lockhart's 4th Weapon

-- MAIN APPLICATION
addappid(1103742)
-- Game: addappid(1103742)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103742,0,"a6218e78146c0e9167ba362ca6c9503d007fa32361ae4a9b7583f2de746baebe")
