-- Lua provided by RyzenAPI
-- Game: Game: Quad Battle Playtest

-- MAIN APPLICATION
addappid(2532140)
-- Game: addappid(2532140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532141, 1, "3a898dac8d610b747dcefd10dcca208c0d03c926a0a464d51201765616250123")
