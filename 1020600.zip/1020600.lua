-- Lua provided by RyzenAPI
-- Game: Extreme Truck Simulator

-- MAIN APPLICATION
addappid(1020600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020601, 1, "5a7429e78a3995a10a3d320176ddf6144d9da78120196123eaa73bc5a4633fe7")
