-- Lua provided by RyzenAPI
-- Game: AppID 1233780

-- MAIN APPLICATION
addappid(1233780)
-- Game: addappid(1233780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233781, 1, "fd64ec6b9aa5144da6ec42a7c8134fff99a99c1fcd8432bf1a846471f467f86e")
