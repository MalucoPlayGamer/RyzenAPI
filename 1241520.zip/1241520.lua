-- Lua provided by RyzenAPI
-- Game: The Horrorscope

-- MAIN APPLICATION
addappid(1241520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1241521, 1, "23eb414d45bd896b4b3c49e45426d4c15e02f75aff0d5a6d31436f6c4c24c980")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
