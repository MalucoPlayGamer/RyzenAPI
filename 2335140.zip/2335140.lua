-- Lua provided by RyzenAPI
-- Game: Machine Armor Zero

-- MAIN APPLICATION
addappid(2335140)
addappid(2774060)
addappid(2774070)
addappid(2774080)
-- Game: addappid(2335140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335141, 1, "12f1ab2abdc8b6940e9f820b84c15f95ee0ac8ca3be2d8a422b20a39ed81ac64")
