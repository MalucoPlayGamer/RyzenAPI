-- Lua provided by RyzenAPI
-- Game: AppID 431750

-- MAIN APPLICATION
addappid(431750)
addappid(515171)
addappid(515950)

-- MAIN APP DEPOTS / PACKAGES
addappid(431751, 1, "1de66a1561a5eb78d1e9634bb0abcfb6ec04b72d57dbb9c85516816dd977528a")
addappid(515170, 0, "f454238a13322247b00407cd8e6dee0b0a37f4f6b8e1ba70f3b5ff2b57db0d12")
