-- Lua provided by RyzenAPI
-- Game: ROG CITADEL XV

-- MAIN APPLICATION
addappid(1472250)
addappid(1938470)
-- Game: addappid(1472250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472251, 1, "9571ada78f950ec450993e541648bc0c8a4740aee84e35726f7003dd43b4cc0c")
