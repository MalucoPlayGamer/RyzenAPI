-- Lua provided by RyzenAPI
-- Game: Dan Sing Sing AMV Maker for Vroid VRM and MMD

-- MAIN APPLICATION
addappid(1688750)
-- Game: addappid(1688750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688751, 1, "c3c865475d662a7a66a549638e703d9daafe53ba1b1711751b5441899340ca3d")
