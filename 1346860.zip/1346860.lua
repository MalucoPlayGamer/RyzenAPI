-- Lua provided by RyzenAPI
-- Game: Spirit of dungeon

-- MAIN APPLICATION
addappid(1346860)
-- Game: addappid(1346860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346861, 1, "5e83884c0589db1ba3aaa32dfc54124006d535b2ba2e553a77d8bc5829369a04")
