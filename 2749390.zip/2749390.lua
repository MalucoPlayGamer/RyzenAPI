-- Lua provided by RyzenAPI
-- Game: Notes To Myself Soundtrack

-- MAIN APPLICATION
addappid(2749390)
-- Game: addappid(2749390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2749391, 1, "e7cdd7e9192980242af14922b4fdbbe44a690597b4e146135a638e498315af04")
