-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Skyline Simulations - Billy Bishop Toronto City Airport

-- MAIN APPLICATION
addappid(2970670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2970670,0,"a8fe15dbd63ed93c32f1f0eb6c522f0ab2783704fb08ff25088cabb06ad00e22")

