-- Lua provided by RyzenAPI
-- Game: Game: AppID 1245380

-- MAIN APPLICATION
addappid(1245380)
-- Game: addappid(1245380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245381, 1, "66fc211f007d13097c2f47cc9ec7a0bc20fa1912492f831135e5673621fd90b8")
