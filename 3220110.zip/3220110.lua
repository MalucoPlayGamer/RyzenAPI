-- Lua provided by RyzenAPI
-- Game: addappid(3220110)

-- MAIN APPLICATION
addappid(3220110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3220111, 1, "c581f346a7c2b183a05c9cd67445d2e5c178fb707d834872356fa3fe4e56c8f0")
