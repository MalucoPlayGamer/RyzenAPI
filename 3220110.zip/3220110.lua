-- Lua provided by SkyAPI 
-- Game: AppID 3220110
addappid(3220110)
addappid(3220111, 1, "c581f346a7c2b183a05c9cd67445d2e5c178fb707d834872356fa3fe4e56c8f0")
