-- Lua provided by RyzenAPI
-- Game: Rain of Arrows

-- MAIN APPLICATION
addappid(740330)

-- MAIN APP DEPOTS / PACKAGES
addappid(740331,0,"89755ef2d5b3472d2dd8abbe807a348af753da689be298e9efa33e2e76520f57")

