-- Lua provided by RyzenAPI
-- Game: Game: Loop

-- MAIN APPLICATION
addappid(2057790)
-- Game: addappid(2057790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057791, 1, "95ac98f3555dfdb65a6d8774e29a07577c408930cca0d53b6c2d44c28c05eb11")
addappid(2057792, 1, "8d0fe2dd1e949b732384d9e8cb2234b35a49358d2a91505ed4c141017a3c4ea0")
addappid(2057793, 1, "52e1cc1a01e01b9864409107bf90d446166b13c1d17feddb8a4fb95bb711c5ae")
