-- 4914620's Lua and Manifest Created by Hubcap Manifest
-- Echoes of Kyria
-- Created: August 12, 2026 at 00:07:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4914620) -- Echoes of Kyria
-- MAIN APP DEPOTS
addappid(4914621, 1, "cc277a3def2a8c83e161a4af8419fc3417f4ca65280fdd67268826dc6d93c2bc") -- Depot 4914621
setManifestid(4914621, "1166003444247717957", 7591286485)