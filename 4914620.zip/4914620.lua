-- Generated with Luie @ https://lua.tools/
-- 4914620 - Echoes of Kyria
-- Generated 2026-08-10 12:49:12 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4914620)

-- Main Depots
addappid(4914621, 1, "cc277a3def2a8c83e161a4af8419fc3417f4ca65280fdd67268826dc6d93c2bc")
setManifestid(4914621, "1846092264670192600", 11334626206)
