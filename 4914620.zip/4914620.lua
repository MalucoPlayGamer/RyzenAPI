-- Lua provided by RyzenAPI
-- Game: Echoes of Kyria

-- MAIN APPLICATION
addappid(4914620) -- Echoes of Kyria

-- MAIN APP DEPOTS / PACKAGES
addappid(4914621, 1, "cc277a3def2a8c83e161a4af8419fc3417f4ca65280fdd67268826dc6d93c2bc") -- Depot 4914621

