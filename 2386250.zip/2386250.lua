-- Lua provided by RyzenAPI
-- Game: It gets so lonely here

-- MAIN APPLICATION
addappid(2386250)
-- Game: addappid(2386250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386251, 1, "2189f0f12b383b863d711bf110af7fd502f4cc215cffb3c33f9d4337a3d2ff8a")
