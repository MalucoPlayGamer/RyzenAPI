-- Lua provided by SkyAPI 
-- Game: The Anomaly
addappid(938050)
addappid(938051, 1, "4a10d55957e9f5ecd34e99d27e614bc8e5d0f66a3176a0470fd39a316318fcf1")
