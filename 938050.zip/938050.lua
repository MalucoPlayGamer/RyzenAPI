-- Lua provided by RyzenAPI
-- Game: The Anomaly

-- MAIN APPLICATION
addappid(938050)
-- Game: addappid(938050)

-- MAIN APP DEPOTS / PACKAGES
addappid(938051, 1, "4a10d55957e9f5ecd34e99d27e614bc8e5d0f66a3176a0470fd39a316318fcf1")
