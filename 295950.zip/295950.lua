-- Lua provided by RyzenAPI
-- Game: 新流星搜劍錄

-- MAIN APPLICATION
addappid(295950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(295951, 1, "677ff1aa8e81c4b41c4a5c543cbc52690c847fb9d3b14b77a82c1949f8a6b46c")

