-- Lua provided by RyzenAPI
-- Game: 新流星搜劍錄

-- MAIN APPLICATION
addappid(295950)

-- MAIN APP DEPOTS / PACKAGES
addappid(295951, 1, "677ff1aa8e81c4b41c4a5c543cbc52690c847fb9d3b14b77a82c1949f8a6b46c")
