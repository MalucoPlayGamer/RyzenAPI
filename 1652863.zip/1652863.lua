-- Lua provided by RyzenAPI
-- Game: addappid(1652863)

-- MAIN APPLICATION
addappid(1652863)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652863,0,"179cccf56d74973881187286fccfcd3f63af159c86f48f41f297f9cbcfb517f0")
