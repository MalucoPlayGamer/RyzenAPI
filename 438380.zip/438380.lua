-- Lua provided by RyzenAPI
-- Game: AppID 438380

-- MAIN APPLICATION
addappid(438380)

-- MAIN APP DEPOTS / PACKAGES
addappid(438381, 1, "25100ed836f9ea23ec4a82359439aecb93cb54cfbbb942631a40e68c418deb52")

