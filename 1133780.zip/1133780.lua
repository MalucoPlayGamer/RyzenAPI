-- Lua provided by RyzenAPI
-- Game: 1133780

-- MAIN APPLICATION
addappid(1133780)
-- Game: addappid(1133780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133781, 1, "e32c2eddad58a51699debfc72810c3fa43c2937cf1302f0f5df88c4aee403e11")
