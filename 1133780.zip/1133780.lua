-- Lua provided by RyzenAPI
-- Game: Bandit the game

-- MAIN APPLICATION
addappid(1133780)
addappid(1893730)
addappid(4187590)
addappid(4187630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1133781, 1, "e32c2eddad58a51699debfc72810c3fa43c2937cf1302f0f5df88c4aee403e11")
