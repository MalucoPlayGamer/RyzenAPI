-- Lua provided by RyzenAPI
-- Game: Grimm of the Dome

-- MAIN APPLICATION
addappid(2354730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354731, 1, "c9842ea33934bb298ed61cd9275c2e3f744382cc2adb4aa44145bc30f8661983")
