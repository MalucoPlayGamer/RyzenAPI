-- Lua provided by RyzenAPI
-- Game: 2935840

-- MAIN APPLICATION
addappid(2935840)
-- Game: addappid(2935840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2935841, 1, "4f66553bb73292c8d943736edcde48c16b7d9ed93b4b8ee075685ffd407de229")
