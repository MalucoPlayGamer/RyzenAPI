-- Lua provided by RyzenAPI
-- Game: Maestro

-- MAIN APPLICATION
addappid(2701700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701701, 1, "b76ebf3606bcb620ac016cbd1b82209d33f969e6b2208f59946f2d562d0f1c06")
addappid(3352570, 0, "022fe7cb197b2917937fbdf1d8b2570c68cb40f132e43e12da84d73201e49090")
addappid(3645630, 0, "ea989b494e203fee4f27d10f6f0bf96e8c3f33c7493bdced6a929e4f851f71f9")
addappid(3762030, 0, "2056e764d70d4ab9bdb04a32255015ea1dcf321d3887bb1e7b26feb1bfc9c699")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4024720)
addappid(4197260)
addappid(5058630)
