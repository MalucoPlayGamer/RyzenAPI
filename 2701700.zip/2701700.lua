-- Lua provided by RyzenAPI
-- Game: Game: Maestro

-- MAIN APPLICATION
addappid(2701700)
-- Game: addappid(2701700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701701, 1, "b76ebf3606bcb620ac016cbd1b82209d33f969e6b2208f59946f2d562d0f1c06")
addappid(3352570, 0, "022fe7cb197b2917937fbdf1d8b2570c68cb40f132e43e12da84d73201e49090")
addappid(3645630, 0, "ea989b494e203fee4f27d10f6f0bf96e8c3f33c7493bdced6a929e4f851f71f9")
addappid(3762030, 0, "2056e764d70d4ab9bdb04a32255015ea1dcf321d3887bb1e7b26feb1bfc9c699")
