-- Lua provided by RyzenAPI
-- Game: RetroArch - CrocoDS

-- MAIN APPLICATION
addappid(1227482)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227482,0,"fec1cb02cc11aed0bab1f9c63739520f444a8eb47bb8e4736a1c771830c719d3")
addappid(1789810,0,"521d4b3d31122c9d0141b5a6dfabaa8b3017e7cc4e861d36fd1d45e67f0ed5a9")
addappid(1789811,0,"0834da2c46627ad85b76a004279e7b57099a965d4fdd6c3dac44b45bd639d5e6")

