-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Bass - Easy Pull-off Exercise 2

-- MAIN APPLICATION
addappid(1089231)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089231,0,"e757fb81524c9678ac28f8851acf45fe562434b60f860703cedc1e457cbccd24")

