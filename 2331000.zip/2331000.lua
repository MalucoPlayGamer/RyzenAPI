-- Lua provided by RyzenAPI
-- Game: Dirty Room

-- MAIN APPLICATION
addappid(2331000)
addappid(2433980)
addappid(2485380)
addappid(2541570)
addappid(2622480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331002,0,"c2863351dcbb08db6525e450541c70d3b129d3223473c83fb562c34ca404fb02")
addappid(2390800,0,"8d71f35ebd80e697291161c782d5ba8b29853f097dbd0ca1b94bee67a2a03396")

