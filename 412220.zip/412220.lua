-- Lua provided by RyzenAPI
-- Game: DDNet

-- MAIN APPLICATION
addappid(412220)
-- Game: addappid(412220)

-- MAIN APP DEPOTS / PACKAGES
addappid(412221, 1, "70189e8bc8e580b79d64aaad93cd87a463f16395b1e0eb2ccbbaf0659f274df0")
addappid(412222, 1, "9b3d84a1ba1f09b9d86b38646590d911adce77b6e2520104f1205d619fcb3134")
addappid(412223, 1, "c95fb311ac79072b15fbcd2167358fda35fc5aceac7426d0be6c863b34d53d17")
addappid(412224, 1, "e42e162ea064724277b0b8699c42aa0fb32a1eb0700799e17e3ac123ade797b1")
addappid(412225, 1, "59ee5d42713d260ce136c6f5fa01b2400afebc094b486bd80c91e1860884b3d5")
addappid(412226, 1, "1b0e4a127fd7c0e68ba36b181ae3dc8aaaf08a5bbde622731dae44a2c07a62ea")
