-- Lua provided by SkyAPI 
-- Game: John Wick Hex
addappid(1405790)
addappid(1405791, 1, "a5c7cc34782eea2d3443c697e6dc81cc12a9b7061bd973f770cd10c2bb095630")
addappid(1405792, 1, "dccc50a3e4ffb1ef5f900bbe2bea434192fd4ebd1f5a6eaa1c39e4f62027641a")
