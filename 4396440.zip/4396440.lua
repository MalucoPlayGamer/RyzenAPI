-- 4396440's Lua and Manifest Created by Hubcap Manifest
-- Dead Stop - No Vacancy
-- Created: August 14, 2026 at 13:46:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4396440) -- Dead Stop - No Vacancy
-- MAIN APP DEPOTS
addappid(4396441, 1, "076bc052188eedbda27e19dedb1cbcdb7b49f9c9e817bcab45cc634a6861b868") -- Depot 4396441
setManifestid(4396441, "1526053190567375910", 6397311770)