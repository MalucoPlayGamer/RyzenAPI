-- Lua provided by RyzenAPI
-- Game: Dead Stop - No Vacancy

-- MAIN APPLICATION
addappid(4396440) -- Dead Stop - No Vacancy

-- MAIN APP DEPOTS / PACKAGES
addappid(4396441, 1, "076bc052188eedbda27e19dedb1cbcdb7b49f9c9e817bcab45cc634a6861b868") -- Depot 4396441

