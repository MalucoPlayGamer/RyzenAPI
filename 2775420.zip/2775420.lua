-- Lua provided by RyzenAPI
-- Game: 2775420

-- MAIN APPLICATION
addappid(2775420)
-- Game: addappid(2775420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775421, 1, "441b0151e02f52ec7f0dda15f6193d7852eec74930f4d40ddf14cb25b5600c20")
