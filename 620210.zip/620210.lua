-- Lua provided by RyzenAPI
-- Game: Fatal Twelve

-- MAIN APPLICATION
addappid(620210)
addappid(2416310)

-- MAIN APP DEPOTS / PACKAGES
addappid(620211, 1, "73905704c3b652cac12e832523c96b0f04e358087cc42f276b52aa65330c1c8e")
addappid(620212, 1, "a524f3dbdf1638823390a351a23e14c0ac088ec86be273065fbb1f7a4c7702be")
addappid(620213, 1, "654415eab08cf08da6235f28924964b0cbfa2c48f9cda7789111dd58ab29b23c")
addappid(838140, 0, "76eff396de5d7c28fb074eea4b85228eef0cbd9e12a23e62ee4a6f2984b85b87")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
