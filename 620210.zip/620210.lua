-- Lua provided by RyzenAPI
-- Game: Game: Fatal Twelve

-- MAIN APPLICATION
addappid(620210)
addappid(2416310)
-- Game: addappid(620210)

-- MAIN APP DEPOTS / PACKAGES
addappid(620211, 1, "73905704c3b652cac12e832523c96b0f04e358087cc42f276b52aa65330c1c8e")
addappid(620212, 1, "a524f3dbdf1638823390a351a23e14c0ac088ec86be273065fbb1f7a4c7702be")
addappid(620213, 1, "654415eab08cf08da6235f28924964b0cbfa2c48f9cda7789111dd58ab29b23c")
addappid(838140, 0, "76eff396de5d7c28fb074eea4b85228eef0cbd9e12a23e62ee4a6f2984b85b87")
