-- Lua provided by RyzenAPI
-- Game: SkiFy

-- MAIN APPLICATION
addappid(656060)

-- MAIN APP DEPOTS / PACKAGES
addappid(656061, 1, "d489587899fb7960822ee7c12c82bdd45c7f3a3ad401d472871c1b753e863949")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
