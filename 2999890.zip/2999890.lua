-- Lua provided by RyzenAPI
-- Game: Mirthwood Demo

-- MAIN APPLICATION
addappid(2999890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999891, 1, "0ef11674fd584a0bdd8495ef3d2d4a0149215407fc6b3db37420c8de5264619a")

