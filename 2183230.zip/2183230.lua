-- Lua provided by RyzenAPI
-- Game: Talent Club ~ Match 3 Puzzle

-- MAIN APPLICATION
addappid(2183230)
-- Game: addappid(2183230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183231, 1, "418e02d32637496642db7f138800d5487c29762e25b1312f6e35a49f15dd9081")
