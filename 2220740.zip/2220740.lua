-- Lua provided by RyzenAPI
-- Game: GameVRoom

-- MAIN APPLICATION
addappid(2220740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220741, 1, "eb8f656f549708b274b4e4ffa834f685e79d2a713fe78e5c084fe7f0227e6ce9")
