-- Lua provided by RyzenAPI
-- Game: 2908490

-- MAIN APPLICATION
addappid(2908490)
-- Game: addappid(2908490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2908491, 1, "3feb9e2e70e9b1704477eab764cbc25af7a70ca23143f0f0940403b208577ba8")
