-- Lua provided by RyzenAPI
-- Game: FORGE SIMULATOR

-- MAIN APPLICATION
addappid(2908490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2908491, 1, "3feb9e2e70e9b1704477eab764cbc25af7a70ca23143f0f0940403b208577ba8")

