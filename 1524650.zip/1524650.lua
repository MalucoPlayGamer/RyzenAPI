-- Lua provided by RyzenAPI
-- Game: Sakura Forest Girls

-- MAIN APPLICATION
addappid(1524650)
-- Game: addappid(1524650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524651, 1, "9b7e717c637a4ad695b951d769ff1a10dd4021469b9759a3277e3095bd30d83d")
