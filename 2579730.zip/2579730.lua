-- Lua provided by RyzenAPI
-- Game: My Bimbo Dream

-- MAIN APPLICATION
addappid(2579730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579732,0,"93fd1b09ac60725904f817bca4b07d5706ae95a8288750cb7a0e6c2a49a78383")
