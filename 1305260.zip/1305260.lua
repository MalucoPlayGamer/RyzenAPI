-- Lua provided by RyzenAPI
-- Game: 1305260

-- MAIN APPLICATION
addappid(1305260)
-- Game: addappid(1305260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305261, 1, "c3b24ff82fcda00f8bbf83e5fc14b6add3903fd0c3bfc5d5824f26950c39ff3a")
