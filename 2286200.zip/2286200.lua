-- Lua provided by RyzenAPI
-- Game: 2286200

-- MAIN APPLICATION
addappid(2286200)
-- Game: addappid(2286200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2286201, 1, "20ecfb38148261ca03f405bfe25fb5a089b4b09815a353a9d687c252c0f524b7")
