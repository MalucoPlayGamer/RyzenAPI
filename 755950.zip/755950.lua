-- Lua provided by RyzenAPI
-- Game: AppID 755950

-- MAIN APPLICATION
addappid(755950)
-- Game: addappid(755950)

-- MAIN APP DEPOTS / PACKAGES
addappid(755951, 1, "75d02ecf9616083271c80d121baec47126201c7ce3ab89a6b00f55da714170a7")
