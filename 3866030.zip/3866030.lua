-- 3866030's Lua and Manifest Created by Hubcap Manifest
-- Escoba
-- Created: August 06, 2026 at 11:24:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3866030) -- Escoba
-- MAIN APP DEPOTS
addappid(3866031, 1, "ffdc53d5ce740322900757deadd8e246045ee613a3d16f8a59d4803b8646361e") -- Depot 3866031
setManifestid(3866031, "3367794444640534559", 169770920)