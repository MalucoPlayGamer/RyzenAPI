-- Lua provided by RyzenAPI
-- Game: Escoba

-- MAIN APPLICATION
addappid(3866030) -- Escoba

-- MAIN APP DEPOTS / PACKAGES
addappid(3866031, 1, "ffdc53d5ce740322900757deadd8e246045ee613a3d16f8a59d4803b8646361e") -- Depot 3866031

