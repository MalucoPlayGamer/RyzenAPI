-- Lua provided by RyzenAPI
-- Game: The Voluptuous DEMON QUEEN and our Shoebox Apartment Life

-- MAIN APPLICATION
addappid(1823320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823321, 1, "a947324403eb43805d3cd01f35ff7116d6b61e8e7778aa0fb8171cd85c5ca9ef")
addappid(1823322, 1, "7c84795b9bd79253469fda5355e45a012a75edda5e3fef4c214cdf1c45915857")

