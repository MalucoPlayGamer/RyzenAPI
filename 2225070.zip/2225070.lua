-- Lua provided by RyzenAPI
-- Game: 2225070

-- MAIN APPLICATION
addappid(2225070)
-- Game: addappid(2225070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225071, 1, "685b3883864d183e0a520b940b9eaa5a3ffd8e045d46666bda9a7b87001c058a")
