-- Lua provided by RyzenAPI
-- Game: Game: MudRunner VR

-- MAIN APPLICATION
addappid(3188340)
-- Game: addappid(3188340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3188341, 1, "7cf03d1235ff97d14759ae5547821d0df82d604f6f62ac4bed76ed17c6865fa3")
