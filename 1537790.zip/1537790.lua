-- Lua provided by SkyAPI 
-- Game: King of Seas Original Soundtrack
addappid(1537790)
addappid(1537791, 1, "0f57db00095a17353d2c3cfcebd880c23170cc91183d180eb0f7277f2b723507")
addappid(1537792, 1, "49f0e46f008daefb66f5e18ab65c0ae5d964cd1d5bd178735f18e63e0891cef0")
