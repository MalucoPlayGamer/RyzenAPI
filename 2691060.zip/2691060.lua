-- Lua provided by RyzenAPI
-- Game: 2691060

-- MAIN APPLICATION
addappid(2691060)
-- Game: addappid(2691060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691061, 1, "7dce7e15aed1f824bd471747bbc0d733c55b4a50907415d00f1065b9103ab208")
