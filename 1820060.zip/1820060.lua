-- Lua provided by RyzenAPI
-- Game: My University Girlfriend

-- MAIN APPLICATION
addappid(1820060)
-- Game: addappid(1820060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820061, 1, "34027db6e3555f581479211baa4504b3786674b30616fca52c13cc6ee941f744")
