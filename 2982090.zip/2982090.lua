-- Lua provided by RyzenAPI
-- Game: AppID 2982090

-- MAIN APPLICATION
addappid(2982090)
-- Game: addappid(2982090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2982091, 1, "1353d9e6fcc5165430723afa2c429acb66e42fd00a8ad6cefff196bf135fba9a")
