-- Lua provided by RyzenAPI
-- Game: addappid(2368180)

-- MAIN APPLICATION
addappid(2368180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368181, 1, "74fdb5fa60082c2feee0cef873bb166cfa68fdc33e4ad1366643c75608caed06")
