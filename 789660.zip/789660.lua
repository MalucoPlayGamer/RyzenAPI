-- Lua provided by RyzenAPI
-- Game: addappid(789660)

-- MAIN APPLICATION
addappid(789660)

-- MAIN APP DEPOTS / PACKAGES
addappid(789662,0,"9d74b5a2393fedda4972be0e5e05ad002cba768d87474ba0480c87c2bc170b0e")
