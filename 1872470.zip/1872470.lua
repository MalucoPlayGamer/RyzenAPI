-- Lua provided by RyzenAPI
-- Game: HardWorker Simulator

-- MAIN APPLICATION
addappid(1872470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872471, 1, "f01c5081130fbc4558da74dc1f80d4232e805d92c12fc6cc1de3bb8874b2475d")

