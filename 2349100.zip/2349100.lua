-- Lua provided by RyzenAPI 
-- Game: Flipper Soccer
addappid(2349100)
addappid(2349101, 1, "36361bc40dabe6be4241f5864451b1d12e6037e65ccf4d58c88262bd3e16c17c")
