-- Lua provided by RyzenAPI
-- Game: Jumpah

-- MAIN APPLICATION
addappid(2470690)
-- Game: addappid(2470690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470691, 1, "ff7bd40e6c298d69110767a8530d1db5d8e350aeac26818e6471e57a68082e36")
