-- Lua provided by RyzenAPI
-- Game: Jumpah

-- MAIN APPLICATION
addappid(2470690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2470691, 1, "ff7bd40e6c298d69110767a8530d1db5d8e350aeac26818e6471e57a68082e36")

