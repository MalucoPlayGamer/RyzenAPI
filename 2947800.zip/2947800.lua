-- Lua provided by RyzenAPI
-- Game: Paranormal place

-- MAIN APPLICATION
addappid(2947800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947801, 1, "f87e2a3e7665b4495e143a8d2cc281b488eba20eec10adbff91c7bdcf0bedfde")

