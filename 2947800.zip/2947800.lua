-- Lua provided by RyzenAPI
-- Game: Paranormal place

-- MAIN APPLICATION
addappid(2947800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2947801, 1, "f87e2a3e7665b4495e143a8d2cc281b488eba20eec10adbff91c7bdcf0bedfde")

