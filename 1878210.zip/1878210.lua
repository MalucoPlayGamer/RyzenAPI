-- Lua provided by RyzenAPI
-- Game: Pirate Jam

-- MAIN APPLICATION
addappid(1878210)
addappid(2574890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878211, 1, "43def0cd46201bef59ea46acdbb0033f922580a9d37a2d31a09e95711355a018")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
