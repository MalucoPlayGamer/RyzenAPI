-- Lua provided by RyzenAPI
-- Game: Pirate Jam

-- MAIN APPLICATION
addappid(1878210)
addappid(2574890)
-- Game: addappid(1878210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878211, 1, "43def0cd46201bef59ea46acdbb0033f922580a9d37a2d31a09e95711355a018")
