-- Lua provided by RyzenAPI
-- Game: Trap Genesis Theme Songs

-- MAIN APPLICATION
addappid(1719840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719841, 1, "22bf7d24a2b88c4cc8561e65b8560a25a2023a1845d855c2ddb513276df9413f")
addappid(1719842, 1, "a06c1b80c7e4ef20fc591fb8aa6679962e353b44aa18d77521941cc1df5de532")

