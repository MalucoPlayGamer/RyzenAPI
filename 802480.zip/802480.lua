-- Lua provided by RyzenAPI
-- Game: baby game plan 0-3

-- MAIN APPLICATION
addappid(802480)

-- MAIN APP DEPOTS / PACKAGES
addappid(802481,0,"3fa57e18716340c7264e3b94bb9caa3381d5ad471f451d957afca4e47b4e81a4")

