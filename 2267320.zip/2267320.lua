-- Lua provided by RyzenAPI
-- Game: addappid(2267320)

-- MAIN APPLICATION
addappid(2267320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267321, 1, "99553d312b2f3e53dfd2228acc845bddbdc9b6ce9d1bd2d817202a33f889e08a")
