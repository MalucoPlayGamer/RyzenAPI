-- Lua provided by RyzenAPI
-- Game: Game: Master of Orion 2

-- MAIN APPLICATION
addappid(410980)
-- Game: addappid(410980)

-- MAIN APP DEPOTS / PACKAGES
addappid(410981, 1, "0c80a43b9d0d6334b4b494aab8d91af111d8e12bbac26418f1978880acef6611")
addappid(410982, 1, "3f12885562efd15b5552b3bc3b6d4febed7342d5b0b006e3b2eed56b7ab4e9cf")
addappid(410983, 1, "9666be2edaa122bc087f2c113ad120f50568743b6dad08230b0107813ad8c08c")
addappid(410984, 1, "57d81af71aea47677fe5909a3e0c3bbc981442358f6baca2f52feaa883c9f88b")
addappid(410985, 1, "eb534e11c78dc29016336039281248ed53230260318b4c820f6fadd4d61881d3")
