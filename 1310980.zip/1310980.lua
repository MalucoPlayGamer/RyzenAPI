-- Lua provided by RyzenAPI
-- Game: addappid(1310980)

-- MAIN APPLICATION
addappid(1310980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310981, 1, "8aec93c5b83cbaa1780a37bbcb56f483f706146001cabed9e6029f6f90b43745")
