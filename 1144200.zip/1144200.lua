-- Lua provided by SkyAPI 
-- Game: Ready or Not
addappid(1144200)
addappid(1144201, 1, "b9236894ba071d12dd117ce16220fefeb20574d7c6f7d2170e3113346867f3d6")
addappid(1844910)
addappid(3015760)
addappid(3174120)
