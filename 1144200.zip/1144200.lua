-- Lua provided by RyzenAPI
-- Game: Ready or Not

-- MAIN APPLICATION
addappid(1144200)
addappid(1844910)
addappid(3015760)
addappid(3174120)
addappid(4224910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1144201, 1, "b9236894ba071d12dd117ce16220fefeb20574d7c6f7d2170e3113346867f3d6")

