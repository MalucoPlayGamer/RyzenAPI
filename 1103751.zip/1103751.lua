-- Lua provided by RyzenAPI
-- Game: DFF NT: Imperial Court Attire Appearance Set for Zenos yae Galvus

-- MAIN APPLICATION
addappid(1103751)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103751,0,"a0f09030848aa20a9ef3ad7edc96a71e3ea5a4dacc7312a40270142309555bb1")
