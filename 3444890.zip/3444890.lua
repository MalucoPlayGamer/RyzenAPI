-- Lua provided by RyzenAPI
-- Game: Trading Card Shop Simulator

-- MAIN APPLICATION
addappid(3444890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3444891,0,"0046c5e9c886b0543293d592247a8418b1ee64f77dbd52963f5b17ee699268bf")

