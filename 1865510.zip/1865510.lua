-- Lua provided by RyzenAPI
-- Game: Notebook Entries Vol. 1

-- MAIN APPLICATION
addappid(1865510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865511, 1, "b7dda4c7a89dddd38ae517087cea860c5dd91fb81c1c3e4475aa194dc8a85063")
