-- Lua provided by RyzenAPI
-- Game: Bacterium

-- MAIN APPLICATION
addappid(798330)

-- MAIN APP DEPOTS / PACKAGES
addappid(798331,0,"991e08c04721d556d532fd52894d6d9aa931509517b127be8d2eddf3c6d0b5c8")

