-- Lua provided by RyzenAPI
-- Game: 出張2 Next Business Trip

-- MAIN APPLICATION
addappid(3659150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3659151, 1, "af78fc62ad9331ea8b13192b9e5dce3f78e1c037341ae014115507be5d75e64b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
