-- Lua provided by RyzenAPI
-- Game: 3659150

-- MAIN APPLICATION
addappid(3659150)
-- Game: addappid(3659150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3659151, 1, "af78fc62ad9331ea8b13192b9e5dce3f78e1c037341ae014115507be5d75e64b")
