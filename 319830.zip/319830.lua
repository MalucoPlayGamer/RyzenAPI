-- Lua provided by RyzenAPI
-- Game: Game: AX:EL - Air XenoDawn

-- MAIN APPLICATION
addappid(319830)
-- Game: addappid(319830)

-- MAIN APP DEPOTS / PACKAGES
addappid(319831, 1, "3a0e5cb2b83269f10df2a5e660731f45a9a13cd45330af26feca8f429ee11fb1")
