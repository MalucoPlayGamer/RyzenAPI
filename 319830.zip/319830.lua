-- Lua provided by RyzenAPI
-- Game: AX:EL - Air XenoDawn

-- MAIN APPLICATION
addappid(319830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(319831, 1, "3a0e5cb2b83269f10df2a5e660731f45a9a13cd45330af26feca8f429ee11fb1")

