-- Lua provided by RyzenAPI
-- Game: Happy Summer Quest

-- MAIN APPLICATION
addappid(1781230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781231, 1, "69e7a8acb621143ed944c601557c8d0752fadbab443d7245df1a4ad3b36e5511")
