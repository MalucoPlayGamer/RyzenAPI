-- Lua provided by RyzenAPI
-- Game: addappid(991067)

-- MAIN APPLICATION
addappid(991067)

-- MAIN APP DEPOTS / PACKAGES
addappid(991067,0,"17f810ba9ffc143df772b1f493c20e347788008e113652236a2cfcf5316f7ee4")
