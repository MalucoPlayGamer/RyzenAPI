-- Lua provided by RyzenAPI
-- Game: Game: CheeseCube

-- MAIN APPLICATION
addappid(1393490)
-- Game: addappid(1393490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393491, 1, "1079e2b02ec1888a315e29ea476a6d509635c04329ba26fc4266d279209f7e5e")
