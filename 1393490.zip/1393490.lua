-- Lua provided by SkyAPI 
-- Game: CheeseCube
addappid(1393490)
addappid(1393491, 1, "1079e2b02ec1888a315e29ea476a6d509635c04329ba26fc4266d279209f7e5e")
