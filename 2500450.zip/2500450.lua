-- Lua provided by RyzenAPI
-- Game: Anx Defense

-- MAIN APPLICATION
addappid(2500450)
-- Game: addappid(2500450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500451, 1, "419840d2ace4d1213ba68d1cc4cef553503139e46d1408dfe2660882d32f0350")
