-- Lua provided by RyzenAPI
-- Game: Left 4 Dead 2 Dedicated Server

-- MAIN APPLICATION
addappid(222860)

-- MAIN APP DEPOTS / PACKAGES
addappid(222861, 1, "1b12a0c0e444d2d7c4565b605dc90e2b321ff22974ba26e521cfec4903f29416")
addappid(222862, 1, "74972d6d723e24f3d579f035db53ac2f98a3a27d7c1b9446571dec933a9762d2")
addappid(222863, 1, "d26680c7e070340e0e05bc82a00de791d94d26a15206d86ecfeec97af600e842")

