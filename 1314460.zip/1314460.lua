-- Lua provided by RyzenAPI
-- Game: Flicker of Hope

-- MAIN APPLICATION
addappid(1314460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314462,0,"0da47d05714f281ebf9e19fa9ff1171c53fd8e24de96d05940bcd4c6fc7c1b14")
addappid(1314463,0,"235e9d1c24e02ab5148a034ea8f381640d026a0ab374502dc2db72607ace5c66")

