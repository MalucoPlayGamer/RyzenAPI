-- Lua provided by RyzenAPI
-- Game: Flicker of Hope

-- MAIN APPLICATION
addappid(1314460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1314462,0,"0da47d05714f281ebf9e19fa9ff1171c53fd8e24de96d05940bcd4c6fc7c1b14")
addappid(1314463,0,"235e9d1c24e02ab5148a034ea8f381640d026a0ab374502dc2db72607ace5c66")

