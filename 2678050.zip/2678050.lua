-- Lua provided by RyzenAPI
-- Game: Sins Of Treatment

-- MAIN APPLICATION
addappid(2678050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678051, 1, "30c34114c59e98d82fc248a0114cf5c5fbc30c19b9482cbe7389399ec43118d5")

