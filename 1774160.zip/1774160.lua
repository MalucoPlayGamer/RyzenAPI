-- Lua provided by RyzenAPI
-- Game: Frog Ball Rerolled

-- MAIN APPLICATION
addappid(1774160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774161, 1, "139ca5331ec897253f0fd6c840375738374c98921ea21c1e6658543b41baf486")

