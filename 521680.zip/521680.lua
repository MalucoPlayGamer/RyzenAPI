-- Lua provided by SkyAPI 
-- Game: Bandit Kings of Ancient China
addappid(521680)
addappid(521681, 1, "f26bf97a6734fe27fa1080bcdd9c258a9e7722d3846f5a21f2b8fd93d6dbc840")
