-- Lua provided by RyzenAPI
-- Game: 1459970

-- MAIN APPLICATION
addappid(1459970)
-- Game: addappid(1459970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459970,0,"f4c864ee25e7d40c5edaa80b581ad59be773d2f9c7c67887c79f1da932be7e54")
