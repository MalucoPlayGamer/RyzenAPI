-- Lua provided by RyzenAPI
-- Game: Game: The House Sitter's 5 Nights

-- MAIN APPLICATION
addappid(2294600)
-- Game: addappid(2294600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294601, 1, "d1de51d8e12b18990a3a2c03ee040ce2b7739900ae6febe6589a83dddf27e9c3")
