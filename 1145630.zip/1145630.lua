-- Lua provided by RyzenAPI
-- Game: BEAST

-- MAIN APPLICATION
addappid(1145630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1145631, 1, "f0708b5e7fda6c602abd3d191dcb0def4f7b6005d0d022949233db4652766405")
