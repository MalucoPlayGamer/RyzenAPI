-- Lua provided by RyzenAPI
-- Game: Game: AppID 3374610

-- MAIN APPLICATION
addappid(3374610)
-- Game: addappid(3374610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3374611, 1, "9e988009a5656df132b3191f3a12f1a8723781b17fd8bfe2a689ae18a22d2735")
