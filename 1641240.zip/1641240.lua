-- Lua provided by RyzenAPI
-- Game: 1641240

-- MAIN APPLICATION
addappid(1641240)
-- Game: addappid(1641240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641241, 1, "8e52862193c91273023115a5a2624fdbb1affefabe3ddfcc52aa53081557ba54")
