-- Lua provided by RyzenAPI
-- Game: Hero's Quest

-- MAIN APPLICATION
addappid(1641240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1641241, 1, "8e52862193c91273023115a5a2624fdbb1affefabe3ddfcc52aa53081557ba54")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
