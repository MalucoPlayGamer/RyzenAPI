-- Lua provided by RyzenAPI
-- Game: Dead of Night

-- MAIN APPLICATION
addappid(656630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(656631,0,"75c564545e3f6622d5568ec15e035fc07e8eb7a7332d7f3b9689e59d795707e0")

