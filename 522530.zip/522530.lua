-- Lua provided by RyzenAPI
-- Game: 522530

-- MAIN APPLICATION
addappid(522530)
-- Game: addappid(522530)

-- MAIN APP DEPOTS / PACKAGES
addappid(522531, 1, "246e63a20481e223e1abc089220304360268acf3e0601bc72d10cc91f16b4c82")
