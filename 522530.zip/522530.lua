-- Lua provided by SkyAPI 
-- Game: AppID 522530
addappid(522530)
addappid(522531, 1, "246e63a20481e223e1abc089220304360268acf3e0601bc72d10cc91f16b4c82")
