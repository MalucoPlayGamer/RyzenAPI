-- Lua provided by RyzenAPI
-- Game: Erenshor Demo

-- MAIN APPLICATION
addappid(2522260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522261, 1, "ed6405bbb9da894ca23ebc98528f73c5d65df4a24a09ad349fcf210c8d222ef9")
