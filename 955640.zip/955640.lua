-- Lua provided by RyzenAPI
-- Game: 955640

-- MAIN APPLICATION
addappid(955640)
-- Game: addappid(955640)

-- MAIN APP DEPOTS / PACKAGES
addappid(955641, 1, "5652be2ce63b6d30dce34cc2cb00b45a865257da9332aade1db1a0aec73393e1")
