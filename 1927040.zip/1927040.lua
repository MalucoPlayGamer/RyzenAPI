-- Lua provided by RyzenAPI 
-- Game: Survirus
addappid(1927040)
addappid(1927041, 1, "51c6964797301485200034d59fe99f46681dadf19b045eb5724593c036934613")
