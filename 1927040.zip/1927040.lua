-- Lua provided by RyzenAPI
-- Game: Game: Survirus

-- MAIN APPLICATION
addappid(1927040)
-- Game: addappid(1927040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927041, 1, "51c6964797301485200034d59fe99f46681dadf19b045eb5724593c036934613")
