-- Lua provided by RyzenAPI
-- Game: Royal Hentai - Boobs & Pussies

-- MAIN APPLICATION
addappid(1832690)
addappid(1878940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832691, 1, "2585b7af470e69fa6a3bdcede07a8a7fab563d10885ec610a95f921cef0cc74c")

