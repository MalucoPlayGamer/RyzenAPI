-- Lua provided by RyzenAPI
-- Game: addappid(3262220)

-- MAIN APPLICATION
addappid(3262220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262221, 1, "26a7c7c773ad8c54113a8bcd98ccb16ee255473501ff91653653dcc2ab139eca")
