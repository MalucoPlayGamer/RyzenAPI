-- Lua provided by RyzenAPI
-- Game: Red Blue Cell

-- MAIN APPLICATION
addappid(3262220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3262221, 1, "26a7c7c773ad8c54113a8bcd98ccb16ee255473501ff91653653dcc2ab139eca")

