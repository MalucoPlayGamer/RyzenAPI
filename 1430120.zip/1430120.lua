-- Lua provided by RyzenAPI
-- Game: Moving Letters

-- MAIN APPLICATION
addappid(1430120)
-- Game: addappid(1430120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430121, 1, "3826c88c6426d31ba6b2a7a220ffdcd10c36f8d57d9ccad05b88cd533cc4f48c")
addappid(1430122, 1, "0486f5e82427e268b381944fbf05569796a8edbae96b19f706c50f81d3b36cfe")
