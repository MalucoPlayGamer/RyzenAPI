-- Lua provided by RyzenAPI
-- Game: Nine Sols

-- MAIN APPLICATION
addappid(1809540)
-- Game: addappid(1809540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809541, 1, "6c41504f601faddc7ec40aff4688b9ee9e34c37f2ab46b882880cbcc76a8eb40")
addappid(1809542, 1, "39cff11ed94d5fb43612916d75ca9d971b35caeca4fa3bda91610e1118927ec3")
addappid(3362590, 0, "8393593da990f6cd827af13ecb9d42c653dabc0101e53dd927e7e55ae2fa4aa1")
addappid(3362591, 1, "0d84cc89dc3f66b203521c09e53075478305ba8702859948d892ba9c3bf0d9d0")
