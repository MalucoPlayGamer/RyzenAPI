-- Lua provided by RyzenAPI
-- Game: Eternal Man: Village

-- MAIN APPLICATION
addappid(808130)
-- Game: addappid(808130)

-- MAIN APP DEPOTS / PACKAGES
addappid(808131, 1, "d7bd2ba7b7c0a6b4ed4c3d08ef4b476400856352357f5ff5fafea60488899aac")
