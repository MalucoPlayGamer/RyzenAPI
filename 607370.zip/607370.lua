-- Lua provided by RyzenAPI
-- Game: 607370

-- MAIN APPLICATION
addappid(607370)
-- Game: addappid(607370)

-- MAIN APP DEPOTS / PACKAGES
addappid(607371, 1, "68f7e07c11f6504bb75f2f49db8ff6f58b923ebb2293f38fac43d8a2bb0eded2")
addappid(607372, 1, "8849af33aa52d8705b4a2aae58e62e66eefca5a564dc98721a692515e4d3839d")
