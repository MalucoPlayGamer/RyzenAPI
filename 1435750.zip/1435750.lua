-- Lua provided by RyzenAPI
-- Game: 1435750

-- MAIN APPLICATION
addappid(1435750)
addappid(1435751)
-- Game: addappid(1435750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435752,0,"ab0cbb11d63116c8b328b49126ac409e61d76de644bca0e7c88dc0939a2cff0e")
