-- Lua provided by RyzenAPI
-- Game: addappid(991960)

-- MAIN APPLICATION
addappid(991960)

-- MAIN APP DEPOTS / PACKAGES
addappid(991961, 1, "bf1ee740312b529ad8341f1a7a63bfe85d1a14dc485998aff10e91ba92a52b8d")
addappid(991962, 1, "17e2e950c7808c2e5db6f43c5a9fa02efc07a45065ddd4d4fc6716f557adfe12")
