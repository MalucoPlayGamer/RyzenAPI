-- Lua provided by RyzenAPI
-- Game: addappid(1522150)

-- MAIN APPLICATION
addappid(1522150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522151, 1, "dea05170909c4cbafd2c05bd1ebdb5ff7ce43694a2e22a1b647ef6cbb006e40e")
