-- Lua provided by RyzenAPI
-- Game: addappid(1748230)

-- MAIN APPLICATION
addappid(1748230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748231, 1, "78a98f1a7b5edb93c21fd501884b365c82916cb6b49d5d67e85e9116f74ff57f")
