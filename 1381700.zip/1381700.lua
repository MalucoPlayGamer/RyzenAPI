-- Lua provided by RyzenAPI
-- Game: Game: AppID 1381700

-- MAIN APPLICATION
addappid(1381700)
-- Game: addappid(1381700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381701, 1, "18aa8237b4656cdbf13fe00f3db3c9dd974837cdde1206f6685f8f9195080e56")
