-- Lua provided by RyzenAPI
-- Game: Lawnmower Day

-- MAIN APPLICATION
addappid(3445700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3445701, 1, "deb4d5daee6afe4c82db4f06fd3db7391c8f963e3d3ad96dc156ae9756ebb07b")
