-- Lua provided by SkyAPI 
-- Game: Lawnmower Day
addappid(3445700)
addappid(3445701, 1, "deb4d5daee6afe4c82db4f06fd3db7391c8f963e3d3ad96dc156ae9756ebb07b")
