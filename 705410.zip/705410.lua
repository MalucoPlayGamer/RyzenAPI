-- Lua provided by RyzenAPI
-- Game: World War Party: Game Of Trump

-- MAIN APPLICATION
addappid(705410)

-- MAIN APP DEPOTS / PACKAGES
addappid(705411, 1, "60120899d7832273dd06ca5fcfe311eb32bcb1a6f22b3355c201659811bfb536")
addappid(705412, 1, "3749612d1b0a5311002ff37fae08f1c20a4c1d42641b0c94f71653b79bb1ba06")

