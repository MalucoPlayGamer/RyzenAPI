-- Lua provided by RyzenAPI
-- Game: 699510

-- MAIN APPLICATION
addappid(699510)
-- Game: addappid(699510)

-- MAIN APP DEPOTS / PACKAGES
addappid(699511, 1, "cc454c587bad73a6dfbfe8e7f9acc667edf4cfdc0151fa2f04f7851124d1ce54")
