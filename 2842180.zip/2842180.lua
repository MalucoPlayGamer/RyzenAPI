-- Lua provided by RyzenAPI
-- Game: 2842180

-- MAIN APPLICATION
addappid(2842180)
-- Game: addappid(2842180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842180,0,"89ad55c8ea3ea497e1351392578a4b21ea6a03f3199fbc9954849a7c75b035dc")
