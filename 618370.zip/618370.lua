-- Lua provided by RyzenAPI
-- Game: Game: AppID 618370

-- MAIN APPLICATION
addappid(618370)
-- Game: addappid(618370)

-- MAIN APP DEPOTS / PACKAGES
addappid(618371, 1, "b26fb5d12b647ffaad7f0ae2ced668dd5fa16fb9c79863df7a6d18631e5deb08")
