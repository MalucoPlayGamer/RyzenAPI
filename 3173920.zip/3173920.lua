-- Lua provided by RyzenAPI
-- Game: 报答老板

-- MAIN APPLICATION
addappid(3173920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173921, 1, "dc69972f67cb11746ca7f529abbb8bdf4e3fba17c144d9d4466758a489677fa2")
