-- Lua provided by SkyAPI 
-- Game: 报答老板
addappid(3173920)
addappid(3173921, 1, "dc69972f67cb11746ca7f529abbb8bdf4e3fba17c144d9d4466758a489677fa2")
