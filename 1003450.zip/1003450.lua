-- Lua provided by RyzenAPI
-- Game: setManifestid(1003455,"2933795728784714943")

-- MAIN APPLICATION
addappid(1003450)
addappid(2244720)
-- Game: addappid(1003450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003455,0,"379e164413e538c3ab70ed8de594eb2aff46742057f7f88ae1de5a0ccf12051c")
