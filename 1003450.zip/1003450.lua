-- Lua provided by RyzenAPI
-- Game: Terrorarium

-- MAIN APPLICATION
addappid(1003450)
addappid(2244720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003455,0,"379e164413e538c3ab70ed8de594eb2aff46742057f7f88ae1de5a0ccf12051c")

