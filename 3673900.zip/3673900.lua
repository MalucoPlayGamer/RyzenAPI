-- Lua provided by RyzenAPI
-- Game: Game: Re: Gals Panic 2

-- MAIN APPLICATION
addappid(3673900)
-- Game: addappid(3673900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3673901, 1, "dc5585d3574024ba5a96a681b9aaf2cfd72234fe231cae3f9b19fed5f6db2b85")
