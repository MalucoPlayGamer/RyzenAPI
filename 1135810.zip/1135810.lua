-- Lua provided by RyzenAPI
-- Game: Vault of the Void

-- MAIN APPLICATION
addappid(1135810)
addappid(3011240)
addappid(4047440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135812,0,"77b938bb983bfec671e0c15440300d51c4660081579cc6373fbe0ab12d783f31")
addappid(1135813,0,"f570b850206127ca4a66d82c2e455900cf665ca32973a1cbdcf4ae1bd34d6eef")

