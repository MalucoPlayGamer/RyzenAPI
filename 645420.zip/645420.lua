-- Lua provided by RyzenAPI
-- Game: addappid(645420)

-- MAIN APPLICATION
addappid(645420)

-- MAIN APP DEPOTS / PACKAGES
addappid(645421, 1, "e254e91fe1c9578b9d3385974d10b22ee81be674d009852550fdb1a9b216cfba")
