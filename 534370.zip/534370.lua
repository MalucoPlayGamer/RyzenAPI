-- Lua provided by RyzenAPI
-- Game: Pure Farming 2018

-- MAIN APPLICATION
addappid(534370)
addappid(647630)
addappid(647631)
addappid(647632)
addappid(647633)
addappid(647634)
addappid(650300)
addappid(675470)
addappid(738570)
addappid(748200)
addappid(748210)

-- MAIN APP DEPOTS / PACKAGES
addappid(534371, 1, "d1e8784188e7d830d01e76ec27c3f9910ddf50e95f335a9c60f2e1abbe0cc770")
addappid(534372, 1, "3e2a327975acb9e6eb0347f8c2edbafa0b567786a9c4d52acf3a902409914d1d")
addappid(534373, 1, "e5d3ed6cb6669dccd097c169bea9b7032859bc823fad6881e75e8c9f3db62883")
addappid(534374, 1, "cc717b96907b55cc0f81569125a1b0868987d41f576de8f448a92afaa56cf39c")
addappid(534375, 1, "335434618ee18ec4ffa529392c880c13d36cc6a4d8fc8515bdfa6d61c0dea594")
addappid(534376, 1, "b4fe675ae8d87705de70cd594f50e32fefb9a0b5d2c58024f1feb3579298a255")
addappid(534377, 1, "33970bb8dea81f86122d08e0abde5d8be12121ab1f173b15d1d57d77be15f403")
addappid(534378, 1, "4e5e191d5a5a426790bfd875814a62772a1552fea66599dc5ce6f64f1be50f1a")
addappid(534379, 1, "02277a5f3e7ac805286d8b0535ea4ddd41fccee6c10b189ac99ac7c7c2738870")
addappid(647635, 0, "a39e5f091fda510c64a99bb8eb5c570d5143bd8305050369f32ce696f255cf9f")
addappid(647636, 0, "9e38bfb26c0c612b552fe414c2c5d6db8770bb36ee954703cfff639b351e8912")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(809170)
addappid(872540)
addappid(889830)
addappid(889840)
