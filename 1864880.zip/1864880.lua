-- Lua provided by RyzenAPI
-- Game: Roman Triumph: Survival City Builder

-- MAIN APPLICATION
addappid(1864880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864881, 1, "d28e6e4ef6e0ea3e64e4fcf6b30932ee4ccbbfbfee4b66d0c8c85f47f1979e74")

