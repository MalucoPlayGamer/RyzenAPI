-- Lua provided by RyzenAPI
-- Game: The Hepatica Spring

-- MAIN APPLICATION
addappid(1883990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883991, 1, "48873068b1f0b2d5d2494d984faee1a1a23068a692c8dffe8f544aba9ea34596")
addappid(1883992, 1, "1f3aa61f15215c96a43d12f75c572d6a0fd6f225b51e54c66d251d6e6a832985")
addappid(1883993, 1, "1598e3fa81da4bb4d45fceb7d4cb82fac7d21aefd1910cb0fee2643847a62268")
