-- Lua provided by RyzenAPI
-- Game: A Summer's End - Hong Kong 1986 Original Soundtrack

-- MAIN APPLICATION
addappid(1386600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386601, 1, "d9e1af32db94663a4f0d40b0692619d463150212198734552c06cf21137d52c7")
addappid(1386602, 1, "3856eff6bf1bfb07261b75e441ba48c041d7d74987b205b26558cb9a257d7919")
