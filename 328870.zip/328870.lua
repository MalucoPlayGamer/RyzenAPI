-- Lua provided by RyzenAPI
-- Game: Game: AppID 328870

-- MAIN APPLICATION
addappid(328870)
-- Game: addappid(328870)

-- MAIN APP DEPOTS / PACKAGES
addappid(328871, 1, "e83b5f34b529bd99922587c1d2126e4c06fd74880d65315dab3e3bcc42268724")
