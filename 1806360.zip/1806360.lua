-- Lua provided by RyzenAPI
-- Game: 1806360

-- MAIN APPLICATION
addappid(1806360)
-- Game: addappid(1806360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806361, 1, "2f1d602a1b9e9ba693a367ed646ba79426f51705dbe016f24ce820693c72b969")
