-- Lua provided by SkyAPI 
-- Game: StarDrive 2
addappid(252450)
addappid(252451, 1, "71324860ed2b2344dd5f801307d91323beee83c615f2e2840304455056b672d0")
addappid(356980, 0, "c64769a681752424715966d94cc80dcb6ea1a108a0e9977fbffb4b010da61d3a")
addappid(445690)
