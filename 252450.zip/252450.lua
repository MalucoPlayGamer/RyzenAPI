-- Lua provided by RyzenAPI
-- Game: StarDrive 2

-- MAIN APPLICATION
addappid(252450)
addappid(356900)
addappid(445690)
addappid(494140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(252451, 1, "71324860ed2b2344dd5f801307d91323beee83c615f2e2840304455056b672d0")
addappid(356980, 0, "c64769a681752424715966d94cc80dcb6ea1a108a0e9977fbffb4b010da61d3a")

