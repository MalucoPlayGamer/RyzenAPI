-- Lua provided by RyzenAPI
-- Game: 2544480

-- MAIN APPLICATION
addappid(2544480)
-- Game: addappid(2544480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544481, 1, "92e85b2bc67208496ca61da00f6688aa1ba72bbbe182f388640cc1a7080ce291")
