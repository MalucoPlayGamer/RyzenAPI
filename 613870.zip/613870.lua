-- Lua provided by RyzenAPI
-- Game: Tank On Tank Digital - East Front Battlepack 1

-- MAIN APPLICATION
addappid(613870)
addappid(613871)
-- Game: addappid(613870)

-- MAIN APP DEPOTS / PACKAGES
addappid(613872,0,"8822b5f8fe36c5211f22b68e903e3a433851f4734241d6ae01fbdba06810b7ff")
