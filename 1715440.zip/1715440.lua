-- Lua provided by RyzenAPI
-- Game: 1715440

-- MAIN APPLICATION
addappid(1715440)
-- Game: addappid(1715440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715440,0,"8e9a7555e7b46a61a99a4da8396c2e3a8b2c97060f093576edb1a2d5b2bbea43")
