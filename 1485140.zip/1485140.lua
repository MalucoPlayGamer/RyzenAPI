-- Lua provided by RyzenAPI
-- Game: Ultrawings 2

-- MAIN APPLICATION
addappid(1485140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485141, 1, "3fd863789052c35f398e1bf310f0eb5eeddd5d42060264c2223882b8aa53e387")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
