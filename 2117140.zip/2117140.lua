-- Lua provided by RyzenAPI
-- Game: Sports Babes

-- MAIN APPLICATION
addappid(2117140)
addappid(2134000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2117141, 1, "2ccdea96d4f99d9c68be80623e6933cf895166a05a16abc088e4ca35477a1f0e")

