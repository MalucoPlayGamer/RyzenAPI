-- Lua provided by RyzenAPI
-- Game: 926860

-- MAIN APPLICATION
addappid(926860)
addappid(926861)
addappid(926863)
addappid(926864)
addappid(926865)

-- MAIN APP DEPOTS / PACKAGES
addappid(926862,0,"ab2391e42878c5401b3f9878ac8c4ed7b188270bcce8290a8020c327d3944efd")

