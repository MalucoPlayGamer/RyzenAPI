-- Lua provided by RyzenAPI
-- Game: addappid(1213650)

-- MAIN APPLICATION
addappid(1213650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213652,0,"06743a90640ba955a86a8fc34cc287f84f0a912a2e87e1cd7d54f3da4cf2730e")
