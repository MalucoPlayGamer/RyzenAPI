-- Lua provided by RyzenAPI
-- Game: Diner Bros

-- MAIN APPLICATION
addappid(846800)
addappid(1095500)
addappid(1252980)

-- MAIN APP DEPOTS / PACKAGES
addappid(846801,0,"bc3d69981590b243a5626b0d3f12c0d4a38f357ffa56e44db91292b628b5945b")

