-- Lua provided by RyzenAPI
-- Game: 846800

-- MAIN APPLICATION
addappid(846800)
-- Game: addappid(846800)

-- MAIN APP DEPOTS / PACKAGES
addappid(846801, 1, "bc3d69981590b243a5626b0d3f12c0d4a38f357ffa56e44db91292b628b5945b")
