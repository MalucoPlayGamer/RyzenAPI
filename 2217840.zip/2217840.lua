-- Lua provided by SkyAPI 
-- Game: In The Backrooms
addappid(2217840)
addappid(2217841, 1, "b8cc469acbacdd282a4868c876027707a9849fbb401be7f437a4e9ae377686c0")
