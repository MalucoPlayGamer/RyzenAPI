-- Lua provided by RyzenAPI
-- Game: 2217840

-- MAIN APPLICATION
addappid(2217840)
-- Game: addappid(2217840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217841, 1, "b8cc469acbacdd282a4868c876027707a9849fbb401be7f437a4e9ae377686c0")
