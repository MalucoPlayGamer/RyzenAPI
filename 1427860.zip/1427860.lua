-- Lua provided by RyzenAPI
-- Game: Paradise Lust

-- MAIN APPLICATION
addappid(1427860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427861, 1, "ab15aa044941148b4c543afffb280c5e5c41a971f14a4c3408800acf60ef3794")
addappid(1427862, 1, "338fe92102ec2c5fc894e1188a7aebf2a97d56e085e016588b373ed4062fc9d8")

