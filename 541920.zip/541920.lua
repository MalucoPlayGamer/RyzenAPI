-- Lua provided by RyzenAPI
-- Game: 541920

-- MAIN APPLICATION
addappid(541920)
-- Game: addappid(541920)

-- MAIN APP DEPOTS / PACKAGES
addappid(541921, 1, "53c6fa674f9980954b21a646f1ae06046ddd0d9fdeb020702ea1995f18a03563")
