-- Lua provided by RyzenAPI
-- Game: 8D Character Creator Demo

-- MAIN APPLICATION
addappid(2464390)
-- Game: addappid(2464390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464391, 1, "917e612f70887283f3f471c00cc1c308f31093bd68c2496102b06dd1363f2e77")
