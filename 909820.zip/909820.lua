-- Lua provided by RyzenAPI
-- Game: Songbird Symphony

-- MAIN APPLICATION
addappid(909820)

-- MAIN APP DEPOTS / PACKAGES
addappid(909821, 1, "e7cae1ed28e78babe4e7f2d87ea74c2301bf8f052148918bc7570cb49975b992")
addappid(909822, 1, "be924682c83453d46f8891ff3b83e640eb17ed59cef6e6a91ee8e0d5afb5e921")
