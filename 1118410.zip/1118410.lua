-- Lua provided by RyzenAPI
-- Game: GLADIUM

-- MAIN APPLICATION
addappid(1118410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118411, 1, "ab7d60f4aa37d52c2a2b311c81bbf51d3bf37bfd4bd8ad30eaf1faa5db8cdd52")

