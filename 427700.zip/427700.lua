-- Lua provided by RyzenAPI
-- Game: Zwei: The Ilvard Insurrection

-- MAIN APPLICATION
addappid(427700)

-- MAIN APP DEPOTS / PACKAGES
addappid(427701, 1, "47f129ee81c28383621200722728f1111bd62b03ada3dc33315ec2260c257f36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
