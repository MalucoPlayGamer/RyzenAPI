-- Lua provided by RyzenAPI
-- Game: Game: Zwei: The Ilvard Insurrection

-- MAIN APPLICATION
addappid(427700)
-- Game: addappid(427700)

-- MAIN APP DEPOTS / PACKAGES
addappid(427701, 1, "47f129ee81c28383621200722728f1111bd62b03ada3dc33315ec2260c257f36")
