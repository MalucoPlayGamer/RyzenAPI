-- Lua provided by RyzenAPI
-- Game: Battle Of Tarlis

-- MAIN APPLICATION
addappid(2515540)
addappid(2545440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2515541, 1, "0ed7e25a71342dddab9f8ef291f0b92577df0a97d79baa3fd10e517ba898e4eb")
