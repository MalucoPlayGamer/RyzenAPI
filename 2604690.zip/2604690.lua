-- Lua provided by RyzenAPI
-- Game: addappid(2604690)

-- MAIN APPLICATION
addappid(2604690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604691, 1, "13296a58f6dcc80abc9435037005e817d8bf7c55bdfc41cfa7b69dcf209b7a0d")
