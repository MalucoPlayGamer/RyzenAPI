-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(293560)
addappid(293561)
addappid(293562)
addappid(293563)
addappid(293566)
addappid(333030)
addappid(333060)

-- MAIN APP DEPOTS / PACKAGES
addappid(293564,0,"e562dc1436e692c09eade119259ea3ed4bc1925691ac728a30afd29814588c2a")

