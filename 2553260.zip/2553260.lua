-- Lua provided by RyzenAPI
-- Game: Mad Viking Games: VR Experience

-- MAIN APPLICATION
addappid(2553260)
-- Game: addappid(2553260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553261, 1, "37b33869d5df39ecbba01024ef899959050611a5f95ebdbc4916ec85974791fb")
