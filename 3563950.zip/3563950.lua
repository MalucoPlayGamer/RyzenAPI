-- Lua provided by RyzenAPI
-- Game: 3563950

-- MAIN APPLICATION
addappid(3563950)
-- Game: addappid(3563950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3563951, 1, "d79c72cb1aeac2590f28b6c0c23a7f4ee64d94f89e67c5e97898ac84150e8b25")
