-- Lua provided by SkyAPI 
-- Game: AppID 3563950
addappid(3563950)
addappid(3563951, 1, "d79c72cb1aeac2590f28b6c0c23a7f4ee64d94f89e67c5e97898ac84150e8b25")
