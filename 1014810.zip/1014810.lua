-- Lua provided by RyzenAPI
-- Game: 1014810

-- MAIN APPLICATION
addappid(1014810)
-- Game: addappid(1014810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014811, 1, "36b382e610730dcfbf5029e8fea86c621b87d7b38e3bac949860819826dc2f67")
