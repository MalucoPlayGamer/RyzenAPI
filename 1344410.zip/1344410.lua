-- Lua provided by RyzenAPI
-- Game: AppID 1344410

-- MAIN APPLICATION
addappid(1344410)
-- Game: addappid(1344410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344411, 1, "6e310c01b24b67c2b626dd0afe11fbab211eed8c67e6612c6f2b7598c971fec8")
