-- Lua provided by RyzenAPI
-- Game: Game: Fuga: Melodies of Steel 2 OST Vol. 1

-- MAIN APPLICATION
addappid(3027370)
-- Game: addappid(3027370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027371, 1, "3aa8d22a2805e57ce811849a5117771e0921d2eb5c31439ea161ea42d3691281")
addappid(3027373, 1, "aa4c6ecbeef94b97c0b4ba6f8dd943815fdea702bb7b826c34e387cfebbd6f64")
