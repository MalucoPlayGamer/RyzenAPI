-- Lua provided by RyzenAPI
-- Game: The Past Within Soundtrack

-- MAIN APPLICATION
addappid(2249650)
-- Game: addappid(2249650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249651, 1, "d769df9f7651dab37e7050c33460a09aa5fef9efaadc6303f1930687e4495168")
addappid(2249652, 1, "6de05122bf1701b96071ed43f2591e39f3c3def01838685311a1171f6ca01982")
