-- Lua provided by RyzenAPI
-- Game: Surviving Soldier

-- MAIN APPLICATION
addappid(2397020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397021, 1, "17c5b418106ad28e993661369d880ea0ef9ec2c7f242d17894b6e75450503a38")

