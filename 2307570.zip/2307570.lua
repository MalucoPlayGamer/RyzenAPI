-- Lua provided by RyzenAPI
-- Game: Speedrush

-- MAIN APPLICATION
addappid(2307570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307571, 1, "8bf6fc99d0288d0fd2580a8f34e848340f0b0c3c2f58ea25a63ae4bd3abf59da")
