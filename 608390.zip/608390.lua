-- Lua provided by RyzenAPI
-- Game: Game: AppID 608390

-- MAIN APPLICATION
addappid(608390)
-- Game: addappid(608390)

-- MAIN APP DEPOTS / PACKAGES
addappid(608391, 1, "da4cc2d253e16e839c026208f27b2864acc587fdab30356d542edd1162692d58")
