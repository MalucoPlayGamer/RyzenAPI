-- Lua provided by RyzenAPI
-- Game: Game: UNCURSED

-- MAIN APPLICATION
addappid(3316910)
-- Game: addappid(3316910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3316911, 1, "7a9112c50dd5d1e921865096bf95f0d406e68c82db31d7cc20b80292829db541")
