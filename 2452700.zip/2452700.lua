-- Lua provided by RyzenAPI
-- Game: Game: Jump Space Playtest

-- MAIN APPLICATION
addappid(2452700)
-- Game: addappid(2452700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452701, 1, "0bc2dc2cb263960a332f84d545aabbb6342b11547c59cd9115ed263714d3022a")
