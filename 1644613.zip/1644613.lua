-- Lua provided by RyzenAPI
-- Game: addappid(1644613)

-- MAIN APPLICATION
addappid(1644613)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644613,0,"567214e085edd75d8e0a6e46095aee00a6675fa66f2f6a98bacd45530dbfa223")
