-- Lua provided by RyzenAPI
-- Game: addappid(1595310)

-- MAIN APPLICATION
addappid(1595310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1595311, 1, "4028a4214cad20fdf8a9cccc18d89ef2063452cb8ed1062df5d19158c3e6b06e")
