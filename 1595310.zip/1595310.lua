-- Lua provided by RyzenAPI 
-- Game: Barbarian Legend
addappid(1595310)
addappid(1595311, 1, "4028a4214cad20fdf8a9cccc18d89ef2063452cb8ed1062df5d19158c3e6b06e")
