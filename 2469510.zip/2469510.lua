-- Lua provided by RyzenAPI
-- Game: Graploteer Demo

-- MAIN APPLICATION
addappid(2469510)
-- Game: addappid(2469510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469511, 1, "645d4c9dcf098877702a317c3debe79b4a957e6249ccf2f85223b13b2bd8c605")
