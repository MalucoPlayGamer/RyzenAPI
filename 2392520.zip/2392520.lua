-- Lua provided by RyzenAPI
-- Game: Power & Revolution 2023 Edition

-- MAIN APPLICATION
addappid(2392520)
addappid(2443810)
addappid(2443811)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392521, 1, "5fe2acd6c9e0b497bc273e267189872448b181a7f02c3949802eded4d43aeb73")
addappid(2392522, 1, "d6f63a9fd392914b1da4212b7c7b23aaca5071a527c36483eb8c881c98579dfe")
addappid(2392523, 1, "24d7c7684992b951129d91fc65b32ae98d4763ac2ed1edb55d0f57bc2758f6a6")
addappid(2392524, 1, "1daa8f171e10bd38f36d9ecb97c8f101f5f81ac2782d84632f44793ec1fd2d38")

