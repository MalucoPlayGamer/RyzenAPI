-- Lua provided by RyzenAPI
-- Game: Close To The Sun

-- MAIN APPLICATION
addappid(968870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(968871, 1, "a890fa120f7ee1d7cc6a55b6839213f9e3e27e23eecb35c357b050b92fccd8b1")
addappid(1293591, 0, "e445a7ba63a93d4efc537da21c50309365368145effcdec519e0ed49e757d5dc")

