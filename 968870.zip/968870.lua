-- Lua provided by RyzenAPI
-- Game: 968870

-- MAIN APPLICATION
addappid(968870)
-- Game: addappid(968870)

-- MAIN APP DEPOTS / PACKAGES
addappid(968871, 1, "a890fa120f7ee1d7cc6a55b6839213f9e3e27e23eecb35c357b050b92fccd8b1")
addappid(1293591, 0, "e445a7ba63a93d4efc537da21c50309365368145effcdec519e0ed49e757d5dc")
