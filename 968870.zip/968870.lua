-- Lua provided by SkyAPI 
-- Game: AppID 968870
addappid(968870)
addappid(968871, 1, "a890fa120f7ee1d7cc6a55b6839213f9e3e27e23eecb35c357b050b92fccd8b1")
addappid(1293591, 0, "e445a7ba63a93d4efc537da21c50309365368145effcdec519e0ed49e757d5dc")
