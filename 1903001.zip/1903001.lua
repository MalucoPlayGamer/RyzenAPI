-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Ann – Art School Tilesets

-- MAIN APPLICATION
addappid(1903001)
-- Game: addappid(1903001)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903001,0,"3a2a7826990b76ff0dbf59b9b96147c9c2d68eb3f0b74f560930c4cef4a683d2")
