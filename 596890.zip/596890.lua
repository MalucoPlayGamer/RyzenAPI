-- Lua provided by RyzenAPI
-- Game: Life of a Mobster

-- MAIN APPLICATION
addappid(596890)

-- MAIN APP DEPOTS / PACKAGES
addappid(596891, 1, "ebc1af5e311d26e2f38282c4ce6edfcb6026d67dc63f360db4248a2faed7fcfe")
