-- Lua provided by RyzenAPI 
-- Game: Life of a Mobster
addappid(596890)
addappid(596891, 1, "ebc1af5e311d26e2f38282c4ce6edfcb6026d67dc63f360db4248a2faed7fcfe")
