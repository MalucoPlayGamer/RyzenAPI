-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1432146)
-- Game: addappid(1432146)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432146,0,"11157dbf002d70abe564b49d4e5d4f721ef8beb5396addc827abbb5ddc497679")
