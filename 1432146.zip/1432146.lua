-- Lua provided by RyzenAPI
-- Game: addappid(1432146)

-- MAIN APPLICATION
addappid(1432146)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432146,0,"11157dbf002d70abe564b49d4e5d4f721ef8beb5396addc827abbb5ddc497679")
