-- Lua provided by RyzenAPI
-- Game: addappid(2416750)

-- MAIN APPLICATION
addappid(2416750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2416750,0,"a7f677c3b08c1bf29f2b2e431664edf02472c2fb28d9f4ffd21c3bc99bd40e2d")
