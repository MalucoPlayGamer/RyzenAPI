-- Lua provided by RyzenAPI
-- Game: addappid(1986480)

-- MAIN APPLICATION
addappid(1986480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986481, 1, "8d57cc7ebd60c0c495dddcd53c41e172c6bbcfad1b8f3dbed9cac05be68b75d2")
