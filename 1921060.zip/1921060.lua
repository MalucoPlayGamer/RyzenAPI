-- Lua provided by RyzenAPI
-- Game: addappid(1921060)

-- MAIN APPLICATION
addappid(1921060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921061, 1, "eaabf64a45780a1810928cea71009849f9646a19955d7bd23e4a77d20f318d0d")
