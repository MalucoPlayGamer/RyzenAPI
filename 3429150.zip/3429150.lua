-- Lua provided by RyzenAPI
-- Game: Game: AppID 3429150

-- MAIN APPLICATION
addappid(3429150)
-- Game: addappid(3429150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3429151, 1, "d50138d9d021ac304b95f4f51b97df69ca17746d90c7b8b83b2fa9eecd961e02")
