-- Lua provided by RyzenAPI
-- Game: Vampire Slayer

-- MAIN APPLICATION
addappid(3043210)
-- Game: addappid(3043210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043211, 1, "77f995c54369cae5c1a86c526a1466e89d339560cc14e8e9186e9e06d3621011")
