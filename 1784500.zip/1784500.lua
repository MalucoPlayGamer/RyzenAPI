-- Lua provided by RyzenAPI
-- Game: addappid(1784500)

-- MAIN APPLICATION
addappid(1784500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784500,0,"2ec518e640c9faab5045e736a2a9d7c6e6b67852f0b04497427ebdbfd84ef4de")
