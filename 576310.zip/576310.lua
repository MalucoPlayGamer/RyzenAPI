-- Lua provided by RyzenAPI
-- Game: Oracle

-- MAIN APPLICATION
addappid(576310)

-- MAIN APP DEPOTS / PACKAGES
addappid(576311, 1, "ee7ece8f5094cc1d73643f6f1a81b1f3e5d2c3895de5b270c81fe1e570144644")

