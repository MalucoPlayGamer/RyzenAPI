-- Lua provided by RyzenAPI
-- Game: Little World Of Creatures

-- MAIN APPLICATION
addappid(934800)

-- MAIN APP DEPOTS / PACKAGES
addappid(934801, 1, "556860bc16efe4d96c7e96cfaeaa5781d26311a07a972ea0fc856309cf72b8e9")

