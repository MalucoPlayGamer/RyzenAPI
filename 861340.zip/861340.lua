-- Lua provided by RyzenAPI
-- Game: 861340

-- MAIN APPLICATION
addappid(861340)
-- Game: addappid(861340)

-- MAIN APP DEPOTS / PACKAGES
addappid(861341, 1, "a1e51fb86f175eac5d93e42a7f782e6c517a80c364e088df29f1278d2a27a7f5")
