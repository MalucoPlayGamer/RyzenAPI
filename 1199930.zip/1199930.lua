-- Lua provided by RyzenAPI
-- Game: Prens Cavid The Game

-- MAIN APPLICATION
addappid(1199930)
-- Game: addappid(1199930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199931, 1, "9c9487b46ee887cb4102cbc3d38714144cf73c45037478110f347625c0b94140")
