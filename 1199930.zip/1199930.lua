-- Lua provided by SkyAPI 
-- Game: Prens Cavid The Game
addappid(1199930)
addappid(1199931, 1, "9c9487b46ee887cb4102cbc3d38714144cf73c45037478110f347625c0b94140")
