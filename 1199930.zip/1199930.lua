-- Lua provided by RyzenAPI
-- Game: Prens Cavid The Game

-- MAIN APPLICATION
addappid(1199930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1199931, 1, "9c9487b46ee887cb4102cbc3d38714144cf73c45037478110f347625c0b94140")

