-- Lua provided by RyzenAPI
-- Game: TSE: Reloaded

-- MAIN APPLICATION
addappid(2055790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2055791, 1, "d0ca31e307cb43d4723231894914e165cdad74a301c3aba7c938adb4db397d95")

