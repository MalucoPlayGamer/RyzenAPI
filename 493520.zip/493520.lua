-- Lua provided by RyzenAPI
-- Game: GTFO

-- MAIN APPLICATION
addappid(493520)
-- Game: addappid(493520)

-- MAIN APP DEPOTS / PACKAGES
addappid(493521, 1, "dac76445821ad71b40b4267a00bfeec912f64305c14e9350c8a16976a827dd26")
