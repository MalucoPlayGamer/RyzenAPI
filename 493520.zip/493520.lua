-- Lua provided by RyzenAPI
-- Game: GTFO

-- MAIN APPLICATION
addappid(493520)

-- MAIN APP DEPOTS / PACKAGES
addappid(493521, 1, "dac76445821ad71b40b4267a00bfeec912f64305c14e9350c8a16976a827dd26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
