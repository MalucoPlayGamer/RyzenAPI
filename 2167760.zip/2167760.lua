-- Lua provided by RyzenAPI
-- Game: Shong

-- MAIN APPLICATION
addappid(2167760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2167761, 1, "2af8f6ecf35c6906f873e7a207c9a4f5397f5e8124816039fda7427c13cecb69")

