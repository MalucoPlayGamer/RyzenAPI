-- Lua provided by RyzenAPI
-- Game: Game: Shong

-- MAIN APPLICATION
addappid(2167760)
-- Game: addappid(2167760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167761, 1, "2af8f6ecf35c6906f873e7a207c9a4f5397f5e8124816039fda7427c13cecb69")
