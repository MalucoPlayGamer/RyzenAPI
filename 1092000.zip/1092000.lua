-- Lua provided by RyzenAPI
-- Game: addappid(1092000)

-- MAIN APPLICATION
addappid(1092000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1092001, 1, "20667f73c6369d6c0fb4d1d1d0e0b9a4c3f6794f3b2d59047aece426073ef49f")
