-- Lua provided by RyzenAPI 
-- Game: Escape Dungeon 2 Demo
addappid(1706010)
addappid(1706011, 1, "ed2e80257ee84d230ccb0ce8b768956b83a1b88f89433f80b78d171fc9a5998a")
