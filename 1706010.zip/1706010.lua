-- Lua provided by RyzenAPI
-- Game: addappid(1706010)

-- MAIN APPLICATION
addappid(1706010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706011, 1, "ed2e80257ee84d230ccb0ce8b768956b83a1b88f89433f80b78d171fc9a5998a")
