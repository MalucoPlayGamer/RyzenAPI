-- Lua provided by RyzenAPI
-- Game: addappid(6210)

-- MAIN APPLICATION
addappid(6210)

-- MAIN APP DEPOTS / PACKAGES
addappid(6211, 1, "3e4ecff6bc6c9c0f53e9da3b158acd13ae02288f85c92c623624bbde400ae34b")
