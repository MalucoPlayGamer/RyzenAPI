-- Lua provided by RyzenAPI 
-- Game: AppID 986080
addappid(986080)
addappid(986081, 1, "ae5e875e0b1bebb69bf925de9a76a2a4cc8ba50c8c4111f20d9a142e22c6a5b4")
