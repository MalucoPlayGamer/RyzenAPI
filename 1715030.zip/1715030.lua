-- Lua provided by RyzenAPI 
-- Game: Godstone
addappid(1715030)
addappid(1715031, 1, "d56b94fdf0aee88da1c34da598e96c56dc6c68144014fd78bc8af85b082a2bd2")
