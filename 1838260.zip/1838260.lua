-- Lua provided by RyzenAPI
-- Game: Game: Medics for Clip maker

-- MAIN APPLICATION
addappid(1838260)
-- Game: addappid(1838260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838261, 1, "939b12bf8676ff6366a38c8214403ba3a079c0481166eca0f4170e5a75d832f7")
