-- Lua provided by RyzenAPI
-- Game: Illusion Carnival

-- MAIN APPLICATION
addappid(2796340)

