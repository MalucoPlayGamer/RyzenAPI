-- Lua provided by RyzenAPI
-- Game: addappid(3033520)

-- MAIN APPLICATION
addappid(3033520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3033521, 1, "8b0c6303c7d699ec5744e34977ab29e7b324ff1d72ce25d97fd18e2a7b3243b8")
