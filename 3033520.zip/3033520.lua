-- Lua provided by RyzenAPI 
-- Game: OYASUMII
addappid(3033520)
addappid(3033521, 1, "8b0c6303c7d699ec5744e34977ab29e7b324ff1d72ce25d97fd18e2a7b3243b8")
