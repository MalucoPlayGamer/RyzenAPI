-- Lua provided by RyzenAPI
-- Game: AppID 1614270

-- MAIN APPLICATION
addappid(1614270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614271, 1, "f4002d2dcfe3ea94b994170a28f08b8d5a9a660d54be5fb65cd797f73f13dbe6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
