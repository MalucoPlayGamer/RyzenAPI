-- Lua provided by RyzenAPI
-- Game: AppID 1614270

-- MAIN APPLICATION
addappid(1614270)
-- Game: addappid(1614270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614271, 1, "f4002d2dcfe3ea94b994170a28f08b8d5a9a660d54be5fb65cd797f73f13dbe6")
