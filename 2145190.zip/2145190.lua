-- Lua provided by RyzenAPI
-- Game: Energy Survivors

-- MAIN APPLICATION
addappid(2145190) -- Energy Survivors

-- MAIN APP DEPOTS / PACKAGES
addappid(2145191, 1, "46778f854afa8221745aceabd6ef22f756c5144bc65f323caf1d6bcd42556061") -- Depot 2145191

