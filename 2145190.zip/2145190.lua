-- 2145190's Lua and Manifest Created by Hubcap Manifest
-- Energy Survivors
-- Created: August 17, 2026 at 13:43:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2145190) -- Energy Survivors
-- MAIN APP DEPOTS
addappid(2145191, 1, "46778f854afa8221745aceabd6ef22f756c5144bc65f323caf1d6bcd42556061") -- Depot 2145191
setManifestid(2145191, "8703438700465566053", 1241295497)