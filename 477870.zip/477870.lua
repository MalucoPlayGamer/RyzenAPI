-- Lua provided by RyzenAPI
-- Game: addappid(477870)

-- MAIN APPLICATION
addappid(477870)

-- MAIN APP DEPOTS / PACKAGES
addappid(477871, 1, "edaf481d0285207caf29f7932ea8a5304ef850a012a097fb6f03747bebaa75f4")
addappid(477880, 1, "828ff21e336b8ed12ff212e3623e3c68e4e203f5e594fdce2a45506c74ecea7f")
addappid(477881, 1, "c88c1b69618a608a9339c7b80c2e00badbeb60c7703cc7b3c2c33cad2a3b87ce")
