-- Lua provided by RyzenAPI
-- Game: Bunny Flush

-- MAIN APPLICATION
addappid(1659670)
-- Game: addappid(1659670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659671, 1, "283cf36cb6b40114ba189c09b88bdcbfe88e9986b63540e6c1f53c01cfc666dd")
