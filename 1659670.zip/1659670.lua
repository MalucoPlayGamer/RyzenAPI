-- Lua provided by SkyAPI 
-- Game: Bunny Flush
addappid(1659670)
addappid(1659671, 1, "283cf36cb6b40114ba189c09b88bdcbfe88e9986b63540e6c1f53c01cfc666dd")
