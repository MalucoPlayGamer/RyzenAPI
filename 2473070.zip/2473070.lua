-- Lua provided by RyzenAPI 
-- Game: Absorber
addappid(2473070)
addappid(2473071, 1, "acca70231e3645f7db9b2a6b9ad4f5de0e87e7e5cea77ca7b84313d19a7fe681")
