-- Lua provided by RyzenAPI
-- Game: Absorber

-- MAIN APPLICATION
addappid(2473070)
-- Game: addappid(2473070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2473071, 1, "acca70231e3645f7db9b2a6b9ad4f5de0e87e7e5cea77ca7b84313d19a7fe681")
