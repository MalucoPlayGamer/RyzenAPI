-- Lua provided by SkyAPI 
-- Game: Incredibox Tracks
addappid(1549040)
addappid(1549041, 1, "eb26d4f92e9c85cc8e3def9e36760004d842df2ac627df7c53c19ae67f4114b0")
addappid(1549042, 1, "21de1786e6cbee469c57f716e7bcaab94562a4a712d76b216356b595574aa8c4")
