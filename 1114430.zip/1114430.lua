-- Lua provided by RyzenAPI
-- Game: Ballex

-- MAIN APPLICATION
addappid(1114430)
-- Game: addappid(1114430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114431, 1, "595081955c36d7a4ef56c6e546f231b2a7d0fbc6c0e7fd316e5d6e202c953c1b")
addappid(1114432, 1, "62220743c2026542f51eee07ff626c4d6a47d7e90dfe810d3f9187817f922c11")
