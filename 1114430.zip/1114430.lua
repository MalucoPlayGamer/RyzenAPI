-- Lua provided by RyzenAPI
-- Game: Ballex

-- MAIN APPLICATION
addappid(1114430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(1114431, 1, "595081955c36d7a4ef56c6e546f231b2a7d0fbc6c0e7fd316e5d6e202c953c1b")
addappid(1114432, 1, "62220743c2026542f51eee07ff626c4d6a47d7e90dfe810d3f9187817f922c11")

