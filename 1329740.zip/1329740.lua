-- Lua provided by RyzenAPI
-- Game: Police Stories – Level Editor

-- MAIN APPLICATION
addappid(1329740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329741, 1, "1ab3d1dad991f00f0200832afdbf70475d4b4215f7be67f2d80cb9a30892a5d3")
addappid(1329742, 1, "9aaaf52bc5fc0e6b5bc5f0d157fba372975c6b097d0ab3de7abeb0ac6c63ba34")
addappid(1329743, 1, "3d683b9128c6551dab6163701cc22449051657575c04195e920ab224799269db")
addappid(1329744, 1, "fbcd6d52907a2355a9eb9affb21c2383fdb9f6c4460539fdd5ff4d1586399afb")

