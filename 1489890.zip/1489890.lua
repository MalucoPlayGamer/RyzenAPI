-- Lua provided by RyzenAPI
-- Game: Game: AppID 1489890

-- MAIN APPLICATION
addappid(1489890)
-- Game: addappid(1489890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489891, 1, "e652d357f3264fc168f95b65af691069fb91d1cfae7847f20054157b83750fe5")
