-- Lua provided by RyzenAPI
-- Game: 346610

-- MAIN APPLICATION
addappid(346610)
-- Game: addappid(346610)

-- MAIN APP DEPOTS / PACKAGES
addappid(346611, 1, "cebb0d4dcdd1227a8db29454d4b3b61ff6f68eb7032b66f2d75144e55aea9faf")
