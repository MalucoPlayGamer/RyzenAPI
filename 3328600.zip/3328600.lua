-- Lua provided by RyzenAPI 
-- Game: AppID 3328600
addappid(3328600)
addappid(3328601, 1, "c153290fc3fa00e37110656fbde4066f829689939f31e4b6c36ed31539160da0")
