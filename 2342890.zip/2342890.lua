-- Lua provided by RyzenAPI
-- Game: Tank Simulator Demo

-- MAIN APPLICATION
addappid(2342890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342891, 1, "bee548f88afa50114e3b4fbd4b63544682844abbbbeb2f7b86097b5b30d5db46")
