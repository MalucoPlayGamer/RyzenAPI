-- Lua provided by RyzenAPI
-- Game: Game: FaceWorld

-- MAIN APPLICATION
addappid(1588390)
addappid(2068330)
-- Game: addappid(1588390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588391, 1, "5480942d7ff963703d47407a131a251ae8c056de2c37be5e4490697fc6ff846f")
