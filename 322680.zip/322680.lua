-- Lua provided by RyzenAPI
-- Game: AppID 322680

-- MAIN APPLICATION
addappid(322680)

-- MAIN APP DEPOTS / PACKAGES
addappid(322681, 1, "c66ac585de3d71892942403a69058f7745d2bc4580e9905aaf221a72961e016b")
addappid(322683, 1, "01a5bfbc7aac7e891c6fcf733f4bbf9bbb252517eba65524da5498d0ccf42fa0")
addappid(322684, 1, "4dfd00a546ac3b6df09379e57e10b970e7fb882b7cc1f2c9e44851db83073c17")
addappid(323650, 0, "7dc6d8d67a6538be596e053416ef8137c60df8352670e2cafc9b224820546b4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(322700)
addappid(487520)
