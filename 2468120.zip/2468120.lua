-- Lua provided by RyzenAPI 
-- Game: Slimegeon
addappid(2468120)
addappid(2468121, 1, "1ec2894a0008e51a6f8d053cc3e7039748a3b629463a6d1ef598e70ff2aab216")
