-- Lua provided by RyzenAPI 
-- Game: Lost Awakening
addappid(1745530)
addappid(1745531, 1, "bea632a41f438cc62ca7721ebee7f5017c9d15befe5f293390532cc366897f6e")
