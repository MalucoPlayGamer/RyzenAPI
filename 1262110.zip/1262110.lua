-- Lua provided by RyzenAPI
-- Game: 1262110

-- MAIN APPLICATION
addappid(1262110)
-- Game: addappid(1262110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262111, 1, "7af9c2a4c7254370fdea982e0884cf8be7876a89ad714cd5c5b843b3afd1364a")
