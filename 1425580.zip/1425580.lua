-- Lua provided by RyzenAPI 
-- Game: Last Soul - Prologue
addappid(1425580)
addappid(1425581, 1, "ca209930e91a4f7f6dc8aa800d1c4353f4cc2891a0804dc2780043c7792df777")
addappid(1425582, 1, "b2f784949ac702d2b0ef6978dbee7a5e55a3bcd559d0dd3e3d54f616747dc627")
addappid(1425583, 1, "f23212d11ab950fa3cab56c19cf3e628e731449061aa51466d846109d9a00aa5")
