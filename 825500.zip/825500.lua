-- Lua provided by RyzenAPI
-- Game: Dead Ground:Arena

-- MAIN APPLICATION
addappid(825500)

-- MAIN APP DEPOTS / PACKAGES
addappid(825501,0,"a5dd0ddb942d7bbe6aa0d4c47d34bc32b92e5db0989b2d6fb5497bebe9a785ec")

