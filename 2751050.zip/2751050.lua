-- Lua provided by RyzenAPI 
-- Game: clickyland
addappid(2751050)
addappid(2751051, 1, "90e65908e07e6c3eeb890d99f92b5ac9cb16a9e67d2877e3c89577cd1101c067")
addappid(2751052, 1, "34176660e2d63771fb96d9f48f414afdf734bba6d27c7b8ed7b724a9fa5021b7")
