-- Lua provided by SkyAPI 
-- Game: Himegashima Island
addappid(2991400)
addappid(2991401, 1, "fc2d321abb17a3f960533fca3a1d795b2e7e61325139e2796dc7b608212ccacc")
addappid(2991402, 1, "b8a941d6898133ba8e19e16eca6f1b71909ab66b4e231f04ee876cbb7d24c77b")
addappid(2991403, 1, "8de9f2516f05eb3d04de8f1f7d811e8396684a99df7064730072e37af8441907")
