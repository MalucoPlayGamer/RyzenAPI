-- Lua provided by RyzenAPI
-- Game: The Life Of Greather

-- MAIN APPLICATION
addappid(503830)
addappid(1102520)
-- Game: addappid(503830)

-- MAIN APP DEPOTS / PACKAGES
addappid(503831, 1, "f4518f9cf36d0c6fdfc246541bf622ab810c0bf2aaaa0938fbc04a37ea84f7d8")
