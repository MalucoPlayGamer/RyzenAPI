-- Lua provided by RyzenAPI
-- Game: VR Secretary: Ailey Edition

-- MAIN APPLICATION
addappid(3384220)

