-- Lua provided by RyzenAPI
-- Game: addappid(382350)

-- MAIN APPLICATION
addappid(382350)

-- MAIN APP DEPOTS / PACKAGES
addappid(382351, 1, "b14f6afa9f3e2f218b9932b3c50f247d6516288499d467559a2fd7999c61db4e")
