-- Lua provided by RyzenAPI
-- Game: 乡间

-- MAIN APPLICATION
addappid(1689480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689482,0,"cbde1b4ac5354ec747805bb5181f99c92ecf8421455960d6d34e5c6e820decb4")

