-- Lua provided by RyzenAPI
-- Game: addappid(2020230)

-- MAIN APPLICATION
addappid(2020230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2020231, 1, "973e6d6fd1db98aa6575af4662b1a83a07dbe96fdc14681d34f58b859dd1966e")
