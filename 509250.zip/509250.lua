-- Lua provided by RyzenAPI
-- Game: TO THE TOP

-- MAIN APPLICATION
addappid(509250)
-- Game: addappid(509250)

-- MAIN APP DEPOTS / PACKAGES
addappid(509251, 1, "8d23f60a583707c8704e314e71738767dacc5444f88407b58cd114ef014a6f5f")
