-- Lua provided by RyzenAPI
-- Game: Game: Nine Treasures of Liuyin

-- MAIN APPLICATION
addappid(2949580)
-- Game: addappid(2949580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949581, 1, "85081af97dd5e355512fb526cd99075f1f2a1631b0285fd9412eec3e9195d498")
