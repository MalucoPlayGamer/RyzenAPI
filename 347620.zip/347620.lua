-- Lua provided by RyzenAPI
-- Game: Gaokao.Love.100Days

-- MAIN APPLICATION
addappid(347620)

-- MAIN APP DEPOTS / PACKAGES
addappid(347621, 1, "61d9744815c29c3567d175e98654e57ffa0859c8dfec37b1cc095837fb5ca850")
addappid(378400, 0, "64fe4cfe2b8e690e46ca89436ab8f4613f62a2e90be35bd6b82ad5e28b41c2aa")
addappid(396960, 0, "4e1c0a33355f4897b3693786ff6da3180837f23579e1e51ad6cde66851e9f1b9")
addappid(747900, 0, "c83493324fc46ba84d1c878caf8d126d5014f3c39f977736fef4bb8d5069545d")
addappid(3588910, 0, "7866d67d699f3daf316aaae67381dfe173fc14948425451d54b8e571920f6df4")
addappid(3588920, 0, "e2c8c893bd10a28598f6920ff7eeec77084f0ae0322e817fbc0ba2f4fdb3fb04")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
