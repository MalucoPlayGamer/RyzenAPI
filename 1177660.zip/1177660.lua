-- Lua provided by RyzenAPI
-- Game: 1177660

-- MAIN APPLICATION
addappid(1177660)
addappid(1412230)
-- Game: addappid(1177660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1177661, 1, "393ba5a9892f5aaa76eaadeeaf4a7aacbb1b3952cf33d3d6bf457e33f8944355")
