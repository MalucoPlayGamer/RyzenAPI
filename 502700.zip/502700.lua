-- Lua provided by RyzenAPI
-- Game: Laser Lasso BALL

-- MAIN APPLICATION
addappid(502700)

-- MAIN APP DEPOTS / PACKAGES
addappid(502701, 1, "179c54c61e2ab941a5158842ce7733dcbc593476ac84db9d66c2215a2b1b5e5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
