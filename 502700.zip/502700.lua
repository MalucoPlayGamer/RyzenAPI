-- Lua provided by RyzenAPI
-- Game: 502700

-- MAIN APPLICATION
addappid(502700)
-- Game: addappid(502700)

-- MAIN APP DEPOTS / PACKAGES
addappid(502701, 1, "179c54c61e2ab941a5158842ce7733dcbc593476ac84db9d66c2215a2b1b5e5f")
