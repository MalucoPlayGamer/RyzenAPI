-- Lua provided by RyzenAPI 
-- Game: Mechanical Survivor
addappid(2334490)
addappid(2334491, 1, "4e5ef9bb9c1c346a23005d8db7bf7598330b5db59eac8f9a2cd303fc80eab96a")
