-- Lua provided by RyzenAPI
-- Game: Mechanical Survivor

-- MAIN APPLICATION
addappid(2334490)
-- Game: addappid(2334490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334491, 1, "4e5ef9bb9c1c346a23005d8db7bf7598330b5db59eac8f9a2cd303fc80eab96a")
