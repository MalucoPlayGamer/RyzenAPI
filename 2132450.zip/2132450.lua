-- Lua provided by RyzenAPI
-- Game: Spectator

-- MAIN APPLICATION
addappid(2132450)
addappid(2309850)
-- Game: addappid(2132450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2132451, 1, "20ca4c3fc7566b862b5742c3afb1a57162e13f958b99550d10fb12c6163d2ebe")
addappid(2132452, 1, "f1428f1f8c40e5feef09bc9ce435b947c5cedf5895369f23b9c7d7a801e18465")
addappid(2132453, 1, "ee43a633b0b7e4a27985c354f3cf4776e4b72d8f4ad79aa5de951cb029629a17")
addappid(2132454, 1, "a6f2a50c0e0c5b88cdb9d07d65fda7b52e74bb6080c7415c48758ab3c7ebcb88")
