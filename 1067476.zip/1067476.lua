-- Lua provided by RyzenAPI
-- Game: Crystar - Uniform

-- MAIN APPLICATION
addappid(1067476)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067476,0,"5375ff69b395014c1cd5bc08109e13c4f881f093700505ffb1195400c30e5d98")

