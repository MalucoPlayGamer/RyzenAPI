-- Lua provided by RyzenAPI
-- Game: 951480

-- MAIN APPLICATION
addappid(951480)

-- MAIN APP DEPOTS / PACKAGES
addappid(951482,0,"30aa6bbf711d473adcea5978bc8b57c2cefb209f2698da5e8ffae60e0177a02f")
