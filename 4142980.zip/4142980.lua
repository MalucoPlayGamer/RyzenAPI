-- Lua provided by RyzenAPI
-- Game: Toilet 8

-- MAIN APPLICATION
addappid(4142980)
addappid(4586100)

-- MAIN APP DEPOTS / PACKAGES
addappid(4142981, 1, "91656b74ec7f0bda9ac97e8f75317e274770c608e0f429afc981c537b075f220")
