-- Lua provided by RyzenAPI
-- Game: PowerWash Simulator Demo

-- MAIN APPLICATION
addappid(2633700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633701, 1, "f6e5e07f5b33fe37c8cdda79b767b9054a3e55a0adbc4bd4602a730ce3b5df08")

