-- Lua provided by RyzenAPI
-- Game: Darwin's Paradox!

-- MAIN APPLICATION
addappid(2989180)
addappid(3990600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989181,0,"51cd23f2f591d2786878933882bf37d6dc8887678b82a909dedae4a9ae6e4ebf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
