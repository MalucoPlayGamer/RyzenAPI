-- Lua provided by RyzenAPI
-- Game: LIBRITOPIA: Librarian Simulator

-- MAIN APPLICATION
addappid(3372420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372421, 1, "91e80ef6816786129900aef7915ab66da7913c958ed6bbf675e904127d57583b")

