-- Lua provided by RyzenAPI
-- Game: 1255640

-- MAIN APPLICATION
addappid(1255640)
-- Game: addappid(1255640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255641, 1, "eee5c00f0cd33d063e1f15ac528ed1f4a8e7c061bab7049451a15255308318fc")
