-- Lua provided by SkyAPI 
-- Game: Wish You All The Best
addappid(3685540)
addappid(3685541, 1, "a46727d49f7123a4bd98bb52a7971c894fdd006c3fa2da336334a896db4e9dea")
