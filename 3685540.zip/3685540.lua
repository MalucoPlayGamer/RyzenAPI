-- Lua provided by RyzenAPI
-- Game: Wish You All The Best

-- MAIN APPLICATION
addappid(3685540)
-- Game: addappid(3685540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3685541, 1, "a46727d49f7123a4bd98bb52a7971c894fdd006c3fa2da336334a896db4e9dea")
