-- Lua provided by RyzenAPI
-- Game: 580700

-- MAIN APPLICATION
addappid(580700)
-- Game: addappid(580700)

-- MAIN APP DEPOTS / PACKAGES
addappid(580700,0,"d14fdf4707dbbf067fe5cf8a8965e66f9db9cb4be9fea7e6a7c3f686199036a0")
