-- Lua provided by RyzenAPI
-- Game: Game: Evochron Mercenary

-- MAIN APPLICATION
addappid(71000)
-- Game: addappid(71000)

-- MAIN APP DEPOTS / PACKAGES
addappid(71001, 1, "2b081239c5e65cfc2bbeefbaea44ac9ae9045097cddced5a4159ad90dfc2f4b2")
