-- Lua provided by RyzenAPI
-- Game: Irrational Exuberance: Prologue

-- MAIN APPLICATION
addappid(343730)

-- MAIN APP DEPOTS / PACKAGES
addappid(343731, 1, "30d157d702108de273db73b98ba82f73249a011106f5ec0b05f0051fcb64b039")
