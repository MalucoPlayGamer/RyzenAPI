-- Lua provided by RyzenAPI
-- Game: Quadrata

-- MAIN APPLICATION
addappid(2066950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066951, 1, "f25d4e46d8193c3f056da7ef3d74f41104593d59f6fae71b976ba838bff29a4c")
addappid(2066952, 1, "2720787353fb926b14d446fb173d0c33a5bed6e119985482789363a79359dc67")
addappid(2066953, 1, "72e64bff35e7e13c9f67c5e7290be863dc30c37b8d94a84f340b5105380caeb9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3676950)
