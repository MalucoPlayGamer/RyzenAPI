-- Lua provided by RyzenAPI
-- Game: Way of Hero

-- MAIN APPLICATION
addappid(581720)

-- MAIN APP DEPOTS / PACKAGES
addappid(581721, 1, "1fb73b19b3bb20e5adcb9d7661544dba2b6d4e6654b2aedb1ac157d11d86b11f")
