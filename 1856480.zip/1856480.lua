-- Lua provided by RyzenAPI
-- Game: Game: KamiYaba: Destiny on a Dicey Deadline

-- MAIN APPLICATION
addappid(1856480)
-- Game: addappid(1856480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856481, 1, "ad3d6e645fa12f6aa5c19f28da4911453ea56e99e88a88021f2087c5588837b8")
