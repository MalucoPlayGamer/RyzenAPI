-- Lua provided by RyzenAPI
-- Game: Game: AppID 1816680

-- MAIN APPLICATION
addappid(1816680)
-- Game: addappid(1816680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816681, 1, "b4e499f2ed97de3a2e305c8130fa521457145b60cc500da7df043f4c01584e1f")
