-- Lua provided by RyzenAPI
-- Game: Fantasy Online 2

-- MAIN APPLICATION
addappid(2957110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957112,0,"4ae54768ba7750727350c71367f512dbdc0673bc64f8367dc41738365f42af73")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
