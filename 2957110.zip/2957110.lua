-- Lua provided by RyzenAPI
-- Game: Fantasy Online 2

-- MAIN APPLICATION
addappid(2957110)
-- Game: addappid(2957110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2957112,0,"4ae54768ba7750727350c71367f512dbdc0673bc64f8367dc41738365f42af73")
