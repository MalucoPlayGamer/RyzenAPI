-- Lua provided by RyzenAPI
-- Game: Armored Brigade II

-- MAIN APPLICATION
addappid(1934300)
addappid(4042860)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1934301, 1, "7ce31204842d3231f5bddfa9413eec7c56a2be2e1501715523f96f88c86e1588")
addappid(1934302, 1, "417d89135739ceccddbbe3f41c93facb7c1d8b14e2931b69783da4ec59102d94")

