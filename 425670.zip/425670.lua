-- Lua provided by RyzenAPI
-- Game: AppID 425670

-- MAIN APPLICATION
addappid(425670)
addappid(538570)
addappid(563880)
addappid(567180)
addappid(567850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(425671, 1, "4ea2faf0ef1977caefd4bdcedf51fc62a2c79eec3d0e50924adfaa88ba275d87")
addappid(425672, 1, "a79bf5198118d9380340dbc26fe5ad71a96952ff59769086c4660a649eff07d2")
addappid(425673, 1, "4d1a56fdb9842ff939ff71e38002d8f0a6aad8b61685ff34f7b27ba86ed67f47")

