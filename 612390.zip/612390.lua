-- Lua provided by RyzenAPI
-- Game: 612390

-- MAIN APPLICATION
addappid(612390)
-- Game: addappid(612390)

-- MAIN APP DEPOTS / PACKAGES
addappid(612391, 1, "e22c72df4a6d9311ef606ad657a1bf2d89fbdb011c78c80e36f9ce550816aff6")
