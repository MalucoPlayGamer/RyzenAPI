-- Lua provided by RyzenAPI
-- Game: Virtual Families 3

-- MAIN APPLICATION
addappid(2303740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303741, 1, "1196bbed45c293d723b45372905233489ef4ae3fce3a2ac5f7501846e08d2800")
