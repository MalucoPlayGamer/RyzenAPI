-- Lua provided by SkyAPI 
-- Game: Lunar Stone - Origin of Blood
addappid(553800)
addappid(553801, 1, "442715ca5520bfbf581b2891ce7c80bbaae96a9f74293eafd5e9deab02c1f7b2")
