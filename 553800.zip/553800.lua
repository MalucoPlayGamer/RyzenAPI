-- Lua provided by RyzenAPI
-- Game: addappid(553800)

-- MAIN APPLICATION
addappid(553800)

-- MAIN APP DEPOTS / PACKAGES
addappid(553801, 1, "442715ca5520bfbf581b2891ce7c80bbaae96a9f74293eafd5e9deab02c1f7b2")
