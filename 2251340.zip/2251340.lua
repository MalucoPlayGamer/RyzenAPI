-- Lua provided by RyzenAPI
-- Game: Royal Affairs

-- MAIN APPLICATION
addappid(2251340)
addappid(2299000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251341, 1, "d4060720885e8e725d81f3427b2b6b8c54b4eac1723b63955cea75131a4e6f5b")

