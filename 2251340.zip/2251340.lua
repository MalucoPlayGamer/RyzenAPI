-- Lua provided by RyzenAPI
-- Game: Game: AppID 2251340

-- MAIN APPLICATION
addappid(2251340)
-- Game: addappid(2251340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251341, 1, "d4060720885e8e725d81f3427b2b6b8c54b4eac1723b63955cea75131a4e6f5b")
