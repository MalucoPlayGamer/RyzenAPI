-- Lua provided by RyzenAPI
-- Game: POG 3

-- MAIN APPLICATION
addappid(1651450)
-- Game: addappid(1651450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1651451, 1, "70f2e2928bb7b5a81e3e3315d1913b1d58a7dff740a22c4d238da369c910b1d9")
