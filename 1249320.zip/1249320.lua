-- Lua provided by RyzenAPI
-- Game: AUDICA - "Stook" - Simaniac

-- MAIN APPLICATION
addappid(1249320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249320,0,"d0e2df0b8533c94a988e1547e01b0688671f6cef5c8670e76d90dfa0561e0911")
