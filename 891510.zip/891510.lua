-- Lua provided by RyzenAPI
-- Game: Love's Sweet Garnish

-- MAIN APPLICATION
addappid(891510)

-- MAIN APP DEPOTS / PACKAGES
addappid(891511, 1, "0729302694d7f9e267ff32ede64eca1d8f97e572d4748bdf6a7d683e00fae023")
addappid(947700, 0, "9839aecf53357939101c324b8666c1add543525de7b9968735f03321db4f9477")

