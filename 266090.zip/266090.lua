-- Lua provided by RyzenAPI
-- Game: Starlite: Astronaut Rescue - Developed in Collaboration with NASA

-- MAIN APPLICATION
addappid(266090)

-- MAIN APP DEPOTS / PACKAGES
addappid(266091, 1, "01fa6e94bf7dcef12a0c72d78911d21cb02dcfbf75121d4611e319a32dac6f3f")

