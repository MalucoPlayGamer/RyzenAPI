-- Lua provided by RyzenAPI
-- Game: Armoured Commander II

-- MAIN APPLICATION
addappid(1292020)
-- Game: addappid(1292020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292021, 1, "cf2ef861e600d5792765e63e9aa54305f6478b59f10acaf7087bd4d191e026f5")
