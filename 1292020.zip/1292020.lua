-- Lua provided by SkyAPI 
-- Game: Armoured Commander II
addappid(1292020)
addappid(1292021, 1, "cf2ef861e600d5792765e63e9aa54305f6478b59f10acaf7087bd4d191e026f5")
