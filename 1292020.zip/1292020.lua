-- Lua provided by RyzenAPI
-- Game: Armoured Commander II

-- MAIN APPLICATION
addappid(1292020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292021, 1, "cf2ef861e600d5792765e63e9aa54305f6478b59f10acaf7087bd4d191e026f5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
