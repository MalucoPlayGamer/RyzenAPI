-- Lua provided by RyzenAPI
-- Game: AppID 817690

-- MAIN APPLICATION
addappid(817690)
-- Game: addappid(817690)

-- MAIN APP DEPOTS / PACKAGES
addappid(817691, 1, "d3afe21c60b420a4d4bc364e9dc9ea906a209829346de55ae6fda9933400f231")
