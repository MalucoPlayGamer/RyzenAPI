-- Lua provided by RyzenAPI
-- Game: Storming master

-- MAIN APPLICATION
addappid(1943670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943671, 1, "7cd7bd8512e04e064dd70242d096a0187eb0ca88d5c47c88b35fb9ba83187022")

