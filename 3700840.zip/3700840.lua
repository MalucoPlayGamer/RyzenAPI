-- Lua provided by RyzenAPI
-- Game: Car Tuning Garage Simulator

-- MAIN APPLICATION
addappid(3700840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3700841,0,"d0adf9058f3ced01d6dcb18f5c1410097bd4805e4968be8770e41094c39e1aaf")

