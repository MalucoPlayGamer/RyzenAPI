-- Lua provided by RyzenAPI
-- Game: Punch! ViaCAD 2D/3D v9 + 3D Printing PowerPack LT

-- MAIN APPLICATION
addappid(275030)
addappid(275031)
addappid(275032)

-- MAIN APP DEPOTS / PACKAGES
addappid(504120,0,"f956d581d7f51240388578bc37ecbb59c0929ef48c58c2f02c4baa4ffa9cd0e1")
