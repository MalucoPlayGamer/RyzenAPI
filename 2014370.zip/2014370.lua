-- Lua provided by RyzenAPI
-- Game: Game: 魔塔三国之群雄争霸

-- MAIN APPLICATION
addappid(2014370)
-- Game: addappid(2014370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2014371, 1, "88670a9162023a5b412104f81d8d5a5a2fc9d69e1fd233054d465752088639ab")
