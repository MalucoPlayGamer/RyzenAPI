-- Lua provided by RyzenAPI
-- Game: AppID 2057310

-- MAIN APPLICATION
addappid(2057310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057311, 1, "6cd2b97d428b97400371bca55f1b7005799949abf9a6f9cdd33a9aebdbfb8a73")

