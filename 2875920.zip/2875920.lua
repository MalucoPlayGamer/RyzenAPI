-- Lua provided by RyzenAPI 
-- Game: AppID 2875920
addappid(2875920)
addappid(2875921, 1, "416b7f213a1748a6803a07ad46aebed30c047ba0e5cefa910385d29253af4a24")
