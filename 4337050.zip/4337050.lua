-- Lua provided by RyzenAPI
-- Game: Colosseum Clothes-Ripper: The Erotic Arena RPG

-- MAIN APPLICATION
addappid(4337050) -- Colosseum Clothes-Ripper: The Erotic Arena RPG

-- MAIN APP DEPOTS / PACKAGES
addappid(4337051, 1, "889f496c710cea0815328aae4f2249cd21588c8b1deeb8b76fe67a11c33e50f3") -- Depot 4337051
addappid(4337052, 1, "ffbee3e4810b67d988c354d4bc559055d94455ff2dca572ebddab51c20dda43b") -- Depot 4337052
addappid(4337053, 1, "5cb6302676f7699dc5be1442b7fd97bfd48021a6aa432bfc8a861de4631f6356") -- Depot 4337053
addappid(4337054, 1, "de4aceca8b179dca49fbefcd87535bc0b8f953c321d2be1547972c8ecd02ebe0") -- Depot 4337054
