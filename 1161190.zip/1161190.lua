-- Lua provided by RyzenAPI
-- Game: AppID 1161190

-- MAIN APPLICATION
addappid(1161190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1161191, 1, "e0f52c7c737088b7794e320cc7e5bb6034e8b931e434d469781532cbcadaccd5")
addappid(1161192, 1, "f7df927854d07658d7a8ad3c62fa3eb132e9dc5c7a1b62bc3abd807d1f98f170")

