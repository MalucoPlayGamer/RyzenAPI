-- Lua provided by RyzenAPI
-- Game: AppID 1161190

-- MAIN APPLICATION
addappid(1161190)
-- Game: addappid(1161190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161191, 1, "e0f52c7c737088b7794e320cc7e5bb6034e8b931e434d469781532cbcadaccd5")
addappid(1161192, 1, "f7df927854d07658d7a8ad3c62fa3eb132e9dc5c7a1b62bc3abd807d1f98f170")
