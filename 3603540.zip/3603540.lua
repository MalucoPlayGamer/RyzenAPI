-- Lua provided by RyzenAPI
-- Game: 전설의 반팅

-- MAIN APPLICATION
addappid(3603540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3603541, 1, "c1986936d03db2ee8464a781c38343fbf678c6df790592a3304b2a4777ac007f")

