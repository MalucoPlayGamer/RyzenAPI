-- Lua provided by RyzenAPI
-- Game: Slackers - Carts of Glory

-- MAIN APPLICATION
addappid(2354000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354001, 1, "58cb30bea27ac9a9ebada223076288b2fed6909a307190d3e00784768c5f8244")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
