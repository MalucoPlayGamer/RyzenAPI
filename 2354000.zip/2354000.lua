-- Lua provided by RyzenAPI 
-- Game: Slackers - Carts of Glory
addappid(2354000)
addappid(2354001, 1, "58cb30bea27ac9a9ebada223076288b2fed6909a307190d3e00784768c5f8244")
