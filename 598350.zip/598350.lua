-- Lua provided by RyzenAPI
-- Game: Alien Insanity

-- MAIN APPLICATION
addappid(598350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(598351, 1, "9642dc6f46b106f5c3c4805aa4d92e04e02ceb1a26526c5b5d8681b68ed2ce18")

