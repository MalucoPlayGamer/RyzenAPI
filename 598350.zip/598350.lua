-- Lua provided by RyzenAPI
-- Game: Game: AppID 598350

-- MAIN APPLICATION
addappid(598350)
-- Game: addappid(598350)

-- MAIN APP DEPOTS / PACKAGES
addappid(598351, 1, "9642dc6f46b106f5c3c4805aa4d92e04e02ceb1a26526c5b5d8681b68ed2ce18")
