-- Lua provided by RyzenAPI
-- Game: Idle interstellar Factory 2

-- MAIN APPLICATION
addappid(2218570)
-- Game: addappid(2218570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218571, 1, "20b7f1203e46e583492acbbf6f4e46be8414cd625898c4d35421e5099179c946")
