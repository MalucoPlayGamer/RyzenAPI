-- Lua provided by RyzenAPI
-- Game: 3617600

-- MAIN APPLICATION
addappid(3617600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3617602,0,"a5e24eb8510e88c74fe65c3d6b9ef9ba295f9547f3ec8c13cb6d63584e83e4dd")

