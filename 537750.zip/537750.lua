-- Lua provided by RyzenAPI
-- Game: Dungeon of Doom Puzzle

-- MAIN APPLICATION
addappid(537750)

-- MAIN APP DEPOTS / PACKAGES
addappid(537751,0,"c8d2d26f0e51d9cff7b6e47c535d486a7d0864c83abccd3c524f857dbb0f07df")

