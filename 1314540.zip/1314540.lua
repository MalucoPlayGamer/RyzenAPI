-- Lua provided by RyzenAPI
-- Game: AppID 1314540

-- MAIN APPLICATION
addappid(1314540)
-- Game: addappid(1314540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314541, 1, "e78e08c957e9e9d832f0df90d38054080ee6e66e2ef39846d884efb4ef3d1e69")
