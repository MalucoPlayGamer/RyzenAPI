-- Lua provided by RyzenAPI
-- Game: Ad Fundum Demo

-- MAIN APPLICATION
addappid(2807930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807931, 1, "24ad64816b7c7dd4cebaf7da077fd45506a2fbf28190032faa0b9f52a973a704")
