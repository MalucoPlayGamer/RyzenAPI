-- Lua provided by RyzenAPI
-- Game: addappid(1411180)

-- MAIN APPLICATION
addappid(1411180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411181, 1, "4bb5bc7748eca93effe69f98c7a21e98183fa7ccba374b6d4ec37eac80299c9a")
