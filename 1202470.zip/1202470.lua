-- Lua provided by RyzenAPI
-- Game: AppID 1202470

-- MAIN APPLICATION
addappid(1202470)
-- Game: addappid(1202470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202471, 1, "13739a36ef508d04b88eb43c2a4d71fc0e38abfe4c9ac57d41c18936b2b1525c")
