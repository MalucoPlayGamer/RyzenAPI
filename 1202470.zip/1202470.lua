-- Lua provided by SkyAPI 
-- Game: AppID 1202470
addappid(1202470)
addappid(1202471, 1, "13739a36ef508d04b88eb43c2a4d71fc0e38abfe4c9ac57d41c18936b2b1525c")
