-- Lua provided by RyzenAPI
-- Game: tiny & Tall: Gleipnir

-- MAIN APPLICATION
addappid(431280)
addappid(944160)

-- MAIN APP DEPOTS / PACKAGES
addappid(431281, 1, "14a168890417621279636dcddba8d5751d52b3185a2231aa21659435bc867309")
addappid(431282, 1, "0dd658903c57585e7af737ed4e1075d354f1674bd7b57a6e74ba351b8d2bc510")

