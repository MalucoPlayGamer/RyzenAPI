-- Lua provided by RyzenAPI 
-- Game: Witching Hour
addappid(1563730)
addappid(1563731, 1, "8641895a741ef55cb27a17917ace4107399b1c2e7de429f424d04ff27d96a68c")
