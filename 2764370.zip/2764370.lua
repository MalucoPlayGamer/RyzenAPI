-- Lua provided by RyzenAPI
-- Game: 2764370

-- MAIN APPLICATION
addappid(2764370)
-- Game: addappid(2764370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764372,0,"10a3c1b620b23a7ab6bea99de45e334a877cf9a06f9a9fb2b152a783faffaafc")
addappid(2764373,0,"b7eed4b3e7579b2a14e3d6d9f10d89c8078fd9b481aff610bf0c1bcece5220d6")
