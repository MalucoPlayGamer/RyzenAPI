-- Lua provided by RyzenAPI
-- Game: Cities: Skylines II - Creator Pack: Dragon Gate

-- MAIN APPLICATION
addappid(2945640)
-- Game: addappid(2945640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945640,0,"e1c2ffe0f3139d1e9dcce3914e56e42316024a30f289013e5b0a76181bf18325")
