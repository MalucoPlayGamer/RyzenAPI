-- Lua provided by RyzenAPI
-- Game: Bus Simulator 27

-- MAIN APP DEPOTS / PACKAGES
addappid(2397320, 1, "fd63a031b6494251093208b9d22023564ca45795708eebf17e2914e18457d9c7") -- Bus Simulator 27
addtoken(2397320, "10734217932922145273")
addappid(2397321, 1, "68f5e2da7f45dbde75df56661f7c514a0a65bf37f7d916aa17f690c8ae68a6e0") -- Depot 2397321
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
