-- Lua provided by RyzenAPI
-- Game: AppID 1774050

-- MAIN APPLICATION
addappid(1774050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774051, 1, "ce702550e64c9364da26a8570d4c5e8a5ddff3da345b1b4ce0333c33bad6d823")
