-- Lua provided by RyzenAPI
-- Game: Emma's Armaments

-- MAIN APPLICATION
addappid(2073050)
addappid(2222230)
-- Game: addappid(2073050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073051, 1, "60203b4ae7fbe8f1e6af9f1c7fb4918355ecf88379863716a06e8b727c456b0c")
