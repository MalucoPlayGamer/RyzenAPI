-- Lua provided by RyzenAPI
-- Game: addappid(1472930)

-- MAIN APPLICATION
addappid(1472930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472931, 1, "7f23e6c455084a3fd048dd3756d924de4c7d14584508dfd8acc5c7c0a8d1c9e5")
