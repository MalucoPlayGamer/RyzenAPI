-- Lua provided by RyzenAPI
-- Game: AppID 1472930

-- MAIN APPLICATION
addappid(1472930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472931, 1, "7f23e6c455084a3fd048dd3756d924de4c7d14584508dfd8acc5c7c0a8d1c9e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
