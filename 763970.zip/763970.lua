-- Lua provided by RyzenAPI
-- Game: 763970

-- MAIN APPLICATION
addappid(763970)
-- Game: addappid(763970)

-- MAIN APP DEPOTS / PACKAGES
addappid(763971, 1, "081520e280c07da5e33b7faba400b49cd0caef52b6401bc52cf9fa4b4231ba15")
