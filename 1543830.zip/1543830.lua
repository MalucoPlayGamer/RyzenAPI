-- Lua provided by RyzenAPI
-- Game: The Addams Family: Mansion Mayhem

-- MAIN APPLICATION
addappid(1543830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543831, 1, "56fec3a86e753b29e3d18769230fdba69f6dbefd8bacc92eeb5e542412af3bb9")

