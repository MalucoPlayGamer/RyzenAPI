-- Lua provided by RyzenAPI
-- Game: Ballistic Overkill

-- MAIN APPLICATION
addappid(296300)
addappid(562870)
addappid(563100)
addappid(563101)
addappid(563102)
addappid(563103)
addappid(563104)
addappid(563105)
addappid(563106)
addappid(563107)
addappid(969260)
addappid(969261)
addappid(969262)
addappid(973770)
addappid(988870)

-- MAIN APP DEPOTS / PACKAGES
addappid(296301, 1, "40095da53b7e8496ef50b0d33220aa0f6251d629d3b3063dfca23e23d372d2b5")
addappid(296302, 1, "fa733c1a9082396ea725882b174e92a350fa7b2a8cb8c74d55980e9f84c69455")
addappid(296303, 1, "233afb21675d646c99fb9e9e1a5e5d118321bb48b1ab7e4d1086ea2e0e4b515d")

