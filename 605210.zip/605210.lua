-- Lua provided by RyzenAPI
-- Game: The Last Tree

-- MAIN APPLICATION
addappid(605210)

-- MAIN APP DEPOTS / PACKAGES
addappid(605211, 1, "d293206ec87541790ff702fecda29f5f73985928ea1ec6d7d5e4fde4256be556")
addappid(646140, 0, "bf8b1d51fa4ce203b63776d38408f75fa0a15e11cd1f88f6f193784d34383b80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
