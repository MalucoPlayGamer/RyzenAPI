-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1718320)
addappid(1718321)
addappid(1718322)
addappid(1718324)
-- Game: addappid(1718320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718323,0,"65a0a14d0e32757168660f57a0aa808dc3aa5a91711c0ef27720e3b8a556012e")
addtoken(1718320,8544115055082142784)
