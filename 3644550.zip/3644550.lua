-- Lua provided by RyzenAPI
-- Game: Bestia Forge

-- MAIN APPLICATION
addappid(3644550)
-- Game: addappid(3644550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3644551, 1, "c2b799221b197d0ac24b0e4aa18ff919f137fded3b46b8c0f9e2efbef411cb7c")
