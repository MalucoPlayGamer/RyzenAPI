-- Lua provided by RyzenAPI
-- Game: 479260

-- MAIN APPLICATION
addappid(479260)
-- Game: addappid(479260)

-- MAIN APP DEPOTS / PACKAGES
addappid(479261, 1, "f405e784bca83d1556c571a61be41c308566aa305ad434bafec488949eba3efc")
