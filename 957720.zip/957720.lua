-- Lua provided by RyzenAPI
-- Game: Game: Strategic Command WWII: World at War

-- MAIN APPLICATION
addappid(957720)
-- Game: addappid(957720)

-- MAIN APP DEPOTS / PACKAGES
addappid(957721, 1, "f43fabbf8b293ec68ed5dcb98dd9c4ab634345557d6574e993641dc4f6decec8")
