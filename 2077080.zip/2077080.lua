-- Lua provided by RyzenAPI
-- Game: 2077080

-- MAIN APPLICATION
addappid(2077080)
-- Game: addappid(2077080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077081, 1, "860bcf98ff9385d95f4957e2d6a39affaedf9ed2b2464f4f3437be14568cd6b0")
