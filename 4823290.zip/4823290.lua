-- 4823290's Lua and Manifest Created by Hubcap Manifest
-- Giant Horse Feeding
-- Created: August 05, 2026 at 22:45:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4823290) -- Giant Horse Feeding
-- MAIN APP DEPOTS
addappid(4823291, 1, "718009599355e4b2efa6af42876aced5d46dabd8ce6a65b92756f3e0f144af8f") -- Depot 4823291
setManifestid(4823291, "9021845878972721448", 14215421)
addappid(4823292, 1, "12ead1202884f3010fa177cc4aab63c920ee09ec174b9303e51080fabb8597cf") -- Depot 4823292
setManifestid(4823292, "4407951131035279909", 306514975)
addappid(4823293, 1, "38ea583a7f71f4564df8a3139927518008806eb7f877d370b0bdea833424cd25") -- Depot 4823293
setManifestid(4823293, "3522944591543893343", 14708559)