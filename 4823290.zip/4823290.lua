-- Lua provided by RyzenAPI
-- Game: Giant Horse Feeding

-- MAIN APPLICATION
addappid(4823290) -- Giant Horse Feeding

-- MAIN APP DEPOTS / PACKAGES
addappid(4823291, 1, "718009599355e4b2efa6af42876aced5d46dabd8ce6a65b92756f3e0f144af8f") -- Depot 4823291
addappid(4823292, 1, "12ead1202884f3010fa177cc4aab63c920ee09ec174b9303e51080fabb8597cf") -- Depot 4823292
addappid(4823293, 1, "38ea583a7f71f4564df8a3139927518008806eb7f877d370b0bdea833424cd25") -- Depot 4823293

