-- Lua provided by RyzenAPI
-- Game: Rugrats: Adventures in Gameland

-- MAIN APPLICATION
addappid(2633950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633951, 1, "8f8a9539cde31ed58bf968f05f88445abe2609954c6080fde303df0925a256ab")

