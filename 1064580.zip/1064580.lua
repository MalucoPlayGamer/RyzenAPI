-- Lua provided by RyzenAPI
-- Game: CaptainMarlene

-- MAIN APPLICATION
addappid(1064580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064581, 1, "1721af3229f0f63b5a58b1ceabe0adc039424c8e3fe32bf7197f19a73399dcaa")
