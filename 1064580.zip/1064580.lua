-- Lua provided by SkyAPI 
-- Game: CaptainMarlene
addappid(1064580)
addappid(1064581, 1, "1721af3229f0f63b5a58b1ceabe0adc039424c8e3fe32bf7197f19a73399dcaa")
