-- Lua provided by RyzenAPI
-- Game: Slackjaw

-- MAIN APPLICATION
addappid(3073900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073901,0,"70ed7ac1412c60f6461818b5b4e12c9966d011fd6b551158c5a2c057e19dee21")

