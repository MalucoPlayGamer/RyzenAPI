-- Lua provided by RyzenAPI
-- Game: Slackjaw

-- MAIN APPLICATION
addappid(3073900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073901,0,"70ed7ac1412c60f6461818b5b4e12c9966d011fd6b551158c5a2c057e19dee21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
