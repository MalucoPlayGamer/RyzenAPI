-- Lua provided by RyzenAPI
-- Game: 1666450

-- MAIN APPLICATION
addappid(1666450)
-- Game: addappid(1666450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1666450,0,"b0528acc2ec0ee97ba90971c4de0491fdf054399bb19c50f26f9e4d347f57dce")
