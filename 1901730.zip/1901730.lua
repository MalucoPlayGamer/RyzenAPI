-- Lua provided by RyzenAPI
-- Game: 1901730

-- MAIN APPLICATION
addappid(1901730)
-- Game: addappid(1901730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901733,0,"807baa44587b536bc03bf1044dbc84f29540b8cbbc26e146d79a0b913a324fd8")
