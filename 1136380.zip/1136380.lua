-- Lua provided by RyzenAPI
-- Game: Ultimate Fishing® Simulator 2

-- MAIN APPLICATION
addappid(1136380)
addappid(2830830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136381, 1, "f6ab2eb01876bb0a71ed82d311cff335764127e35b53358cbf95733bacb1d2f6")

