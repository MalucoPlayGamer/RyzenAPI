-- Lua provided by RyzenAPI 
-- Game: Travellers Rest
addappid(1139980)
addappid(1139981, 1, "5000690224c07f71fdad3bea4c6307e8e6ed6b0d61c71179f169ff6dc1f90b61")
