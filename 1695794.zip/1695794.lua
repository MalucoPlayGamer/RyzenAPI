-- Lua provided by RyzenAPI
-- Game: Halo 3: ODST Mod Tools - MCC

-- MAIN APPLICATION
addappid(1695794)
-- Game: addappid(1695794)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701270,0,"886272213a42a5577242bada04441c7b2bc6648f430c7138527360863cbb77c0")
