-- Lua provided by RyzenAPI
-- Game: NetStars - VR Goalie Trainer

-- MAIN APPLICATION
addappid(800670)

-- MAIN APP DEPOTS / PACKAGES
addappid(800671,0,"aa7cc78d791e6736359726b076077ea5d0c845c3a8203a6ce3e3a5ba523334d6")

