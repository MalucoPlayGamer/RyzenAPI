-- Lua provided by RyzenAPI
-- Game: Undead Development

-- MAIN APPLICATION
addappid(682140)
-- Game: addappid(682140)

-- MAIN APP DEPOTS / PACKAGES
addappid(682141, 1, "1831399a53a2d9b92a7146e50a7a5fd00db4ac5e8c39c9d6740a7ca58a2be11a")
