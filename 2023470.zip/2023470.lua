-- Lua provided by SkyAPI 
-- Game: AppID 2023470
addappid(2023470)
addappid(2023471, 1, "442674e24ed9572f369838f27a32ecb1179efd3fd22b736879fe87be313f69eb")
