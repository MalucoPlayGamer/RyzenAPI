-- Lua provided by RyzenAPI
-- Game: Do Not Feed the Monkeys 2099 Demo

-- MAIN APPLICATION
addappid(2023470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023471, 1, "442674e24ed9572f369838f27a32ecb1179efd3fd22b736879fe87be313f69eb")

