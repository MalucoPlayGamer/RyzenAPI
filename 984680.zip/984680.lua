-- Lua provided by RyzenAPI
-- Game: addappid(984680)

-- MAIN APPLICATION
addappid(984680)

-- MAIN APP DEPOTS / PACKAGES
addappid(984681, 1, "73ad2e6f2ebb5aa5346e5d7b620ce5cd45d0a362b42edf546f729a1e61843898")
