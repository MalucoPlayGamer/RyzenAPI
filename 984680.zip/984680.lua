-- Lua provided by SkyAPI 
-- Game: Interstellar Space: Genesis
addappid(984680)
addappid(984681, 1, "73ad2e6f2ebb5aa5346e5d7b620ce5cd45d0a362b42edf546f729a1e61843898")
