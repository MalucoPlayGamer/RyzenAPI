-- Lua provided by RyzenAPI
-- Game: Interstellar Space: Genesis

-- MAIN APPLICATION
addappid(984680)
addappid(1419960)
addappid(1974170)
addappid(2783160)

-- MAIN APP DEPOTS / PACKAGES
addappid(984681,0,"73ad2e6f2ebb5aa5346e5d7b620ce5cd45d0a362b42edf546f729a1e61843898")

