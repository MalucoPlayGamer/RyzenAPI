-- Lua provided by RyzenAPI
-- Game: 1051310

-- MAIN APPLICATION
addappid(1051310)
-- Game: addappid(1051310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051311, 1, "7703818b7761602a9381f5fc9e6aaa500b7497414ecd56d40ce1ceed9485157e")
