-- Lua provided by RyzenAPI
-- Game: 1387310

-- MAIN APPLICATION
addappid(1387310)
addappid(1387311)

-- MAIN APP DEPOTS / PACKAGES
addappid(1387310,0,"ea4541eece31905a2072971c5bfecf6cb7270e4f60cfc926b2648233b21f6ab2")

