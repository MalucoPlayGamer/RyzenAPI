-- Lua provided by RyzenAPI 
-- Game: AppID 690500
addappid(690500)
addappid(690501, 1, "427b5af7ed232d702af4110067c9436ba262c365e78fec25f99a6864fb2ad8ed")
