-- Lua provided by RyzenAPI
-- Game: 561580

-- MAIN APPLICATION
addappid(561580)
-- Game: addappid(561580)

-- MAIN APP DEPOTS / PACKAGES
addappid(561581, 1, "656621ba5147cb2aa51451b7c40b8f8618e4584751405ee36a86c455a711acc1")
