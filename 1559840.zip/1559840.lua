-- Lua provided by RyzenAPI 
-- Game: 只是一座楼
addappid(1559840)
addappid(1559841, 1, "c375950306e443160ecd16f96b31f89ee50cb8eaf4a44a6695ff6e81887e0ff9")
