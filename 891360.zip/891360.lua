-- Lua provided by RyzenAPI 
-- Game: Hellcoming
addappid(891360)
addappid(891361, 1, "9fdb82251a5a2935db1c2495197e41614cb2ed07d357b4074503754cec69b248")
