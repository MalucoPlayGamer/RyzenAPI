-- Lua provided by RyzenAPI
-- Game: Hellcoming

-- MAIN APPLICATION
addappid(891360)

-- MAIN APP DEPOTS / PACKAGES
addappid(891361, 1, "9fdb82251a5a2935db1c2495197e41614cb2ed07d357b4074503754cec69b248")

