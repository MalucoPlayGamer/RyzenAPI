-- Lua provided by RyzenAPI
-- Game: Inside Her (bedroom)

-- MAIN APPLICATION
addappid(1292490)
addappid(1327770)
-- Game: addappid(1292490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292491, 1, "af4c45d71ac544d9de6bc025e3ad346a6ea50b080a9d62fe198100372674bde3")
