-- Lua provided by RyzenAPI
-- Game: Game: AppID 1066460

-- MAIN APPLICATION
addappid(1066460)
-- Game: addappid(1066460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066461, 1, "29ecd8b5cdfa6856d8969dea84e35cb591d59adc0a443a3a0f486591149a70b2")
