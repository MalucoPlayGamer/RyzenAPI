-- Lua provided by RyzenAPI
-- Game: Total War™: WARHAMMER® - Assembly Kit BETA

-- MAIN APPLICATION
addappid(463690)

-- MAIN APP DEPOTS / PACKAGES
addappid(463691, 1, "496ce98e341b992253c82e96e65449fde8747d18a1dc3713e5d3c8321401f82c")

