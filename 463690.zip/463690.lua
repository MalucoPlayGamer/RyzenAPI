-- Lua provided by RyzenAPI
-- Game: 463690

-- MAIN APPLICATION
addappid(463690)
-- Game: addappid(463690)

-- MAIN APP DEPOTS / PACKAGES
addappid(463691, 1, "496ce98e341b992253c82e96e65449fde8747d18a1dc3713e5d3c8321401f82c")
