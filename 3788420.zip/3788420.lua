-- Lua provided by RyzenAPI
-- Game: Scratch Inc.

-- MAIN APPLICATION
addappid(3788420)
