-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(853770)
-- Game: addappid(853770)

-- MAIN APP DEPOTS / PACKAGES
addappid(853772,0,"53c1772a0047854e89906f1914bcd04606772018d2ab83c1a7ef3bc821d265c5")
addappid(853773,0,"1054459c27e1f2c10f5e55c1b557d75150b46b715ec964140cc6f698b36360c5")
