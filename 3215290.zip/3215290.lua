-- Lua provided by RyzenAPI
-- Game: Game: Alien Market Simulator

-- MAIN APPLICATION
addappid(3215290)
-- Game: addappid(3215290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3215291, 1, "411cf083db3ea10924eb012d4e80c9de534b121b022f207cac587d1062399557")
