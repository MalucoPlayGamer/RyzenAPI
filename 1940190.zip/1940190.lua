-- Lua provided by RyzenAPI
-- Game: AppID 1940190

-- MAIN APPLICATION
addappid(1940190)
-- Game: addappid(1940190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940191, 1, "6d6fd07f2612d2ecf0aaf86975bcb112e919360d1e5b278f21eb0c9e6e64e34c")
