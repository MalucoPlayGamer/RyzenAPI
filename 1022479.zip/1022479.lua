-- Lua provided by RyzenAPI
-- Game: 1022479

-- MAIN APPLICATION
addappid(1022479)
-- Game: addappid(1022479)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022479,0,"06862c5f570a34d8f0d69cec27f74835ecd973f4b8ae254be92ba345812fa120")
