-- Lua provided by RyzenAPI
-- Game: Shallow Sea Roaming

-- MAIN APPLICATION
addappid(2919110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919111, 1, "0a84b23baf8bc149458f59b63900e7709e308159a117a354f051c3a6ec041b3a")

