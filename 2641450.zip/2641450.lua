-- Lua provided by RyzenAPI
-- Game: Selfie Girls

-- MAIN APPLICATION
addappid(2641450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641451,0,"d4ef4bdfb425935c4a7d6e28186a728668cf0ddc2bac2cca6c9cab444d6e21de")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2664210)
