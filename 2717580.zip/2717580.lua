-- Lua provided by RyzenAPI
-- Game: addappid(2717580)

-- MAIN APPLICATION
addappid(2717580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717580,0,"d44b178f515893a22d66d9c6636e1a5f81976b69fe6cffa4d2e640ab2633bf63")
