-- Lua provided by RyzenAPI
-- Game: 5-in-1 Pack - Monument Builders: Destination USA

-- MAIN APPLICATION
addappid(564340)

-- MAIN APP DEPOTS / PACKAGES
addappid(564341,0,"f49772886a127020eea192b11f26e3760274d0a8153bf8428dbef481ba3326e9")

