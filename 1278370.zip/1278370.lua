-- Lua provided by RyzenAPI 
-- Game: AppID 1278370
addappid(1278370)
addappid(1278371, 1, "3c04f74d41d5dd5ec98d50a6ff0083213e61c496fdc03557b3e015daabe03b57")
