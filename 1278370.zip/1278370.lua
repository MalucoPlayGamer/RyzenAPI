-- Lua provided by RyzenAPI
-- Game: Game: AppID 1278370

-- MAIN APPLICATION
addappid(1278370)
-- Game: addappid(1278370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278371, 1, "3c04f74d41d5dd5ec98d50a6ff0083213e61c496fdc03557b3e015daabe03b57")
