-- Lua provided by RyzenAPI
-- Game: addappid(466290)

-- MAIN APPLICATION
addappid(466290)

-- MAIN APP DEPOTS / PACKAGES
addappid(466291, 1, "4e9de987ed96347e51a83026a204aa93d10481b12f74998b44664cfb4b12f10c")
