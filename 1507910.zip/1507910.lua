-- Lua provided by SkyAPI 
-- Game: Survival Engine
addappid(1507910)
addappid(1507911, 1, "9c39d92b922e75086396db665cbeb33f609a2db0041ff7931abf8a40b06a9af3")
