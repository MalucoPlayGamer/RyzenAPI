-- Lua provided by RyzenAPI
-- Game: Survival Engine

-- MAIN APPLICATION
addappid(1507910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507911, 1, "9c39d92b922e75086396db665cbeb33f609a2db0041ff7931abf8a40b06a9af3")

