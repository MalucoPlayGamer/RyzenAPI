-- Lua provided by RyzenAPI
-- Game: Sex Simulator - Love Room

-- MAIN APPLICATION
addappid(2185080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185081, 1, "2d1b700d8c8c40a11c7fb2e331ff5f90086a8347a88a38144a8c593dcd7217b0")
