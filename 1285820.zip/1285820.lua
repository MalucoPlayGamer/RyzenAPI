-- Lua provided by RyzenAPI
-- Game: Virus Kombat

-- MAIN APPLICATION
addappid(1285820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285821, 1, "19e441cfd32c120bcd616b138403e7330b382f537ad4e3918029d8195942ac63")

