-- Lua provided by RyzenAPI
-- Game: Puzzle Box: 10-in-1 Puzzle Collection

-- MAIN APPLICATION
addappid(1715950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715951, 1, "b1227e25572e1db0a28e391253d07091e5583fa734cf88de6d6d53fb072438e3")

