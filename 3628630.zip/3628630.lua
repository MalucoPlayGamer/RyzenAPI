-- Lua provided by RyzenAPI
-- Game: Game: Parking Lot Simulator: Car Collector

-- MAIN APPLICATION
addappid(3628630)
-- Game: addappid(3628630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3628631, 1, "4262a12db92bd5ce71c1040d4ef93a0259922aaad29344ca7f301248de7c60a7")
