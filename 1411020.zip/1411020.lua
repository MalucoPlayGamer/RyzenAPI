-- Lua provided by RyzenAPI
-- Game: Perennial Order

-- MAIN APPLICATION
addappid(1411020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411021, 1, "d21223a396aa3d3aa50c0b5bf867a977017ad4fd4d42ae29f5aad46adb0ac952")
