-- Lua provided by RyzenAPI
-- Game: Game: AppID 1728770

-- MAIN APPLICATION
addappid(1728770)
-- Game: addappid(1728770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1728771, 1, "1d18bad42c7318c9c83bc36763c761188bd48008d66a2427a95f487fdb2a0264")
