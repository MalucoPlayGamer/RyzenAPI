-- Lua provided by RyzenAPI
-- Game: addappid(2275150)

-- MAIN APPLICATION
addappid(2275150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275151, 1, "f883a0d69ecc31bf66a7d4ca52cc62ef61d7a8c9442e78b29016746655f2e030")
addappid(2275152, 1, "df6e6abbce5fd73c99473a1e2d712dc652f25ee6f478a2a84340f99ca764c3cb")
