-- Lua provided by RyzenAPI
-- Game: AppID 321890

-- MAIN APPLICATION
addappid(321890)
-- Game: addappid(321890)

-- MAIN APP DEPOTS / PACKAGES
addappid(321891, 1, "34669fdf849a50f7598c1c57e3d402af7593efa51f2180876656f61af94e73bc")
