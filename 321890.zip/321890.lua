-- Lua provided by RyzenAPI
-- Game: Aveyond 3-4: The Darkthrop Prophecy

-- MAIN APPLICATION
addappid(321890)

-- MAIN APP DEPOTS / PACKAGES
addappid(321891, 1, "34669fdf849a50f7598c1c57e3d402af7593efa51f2180876656f61af94e73bc")

