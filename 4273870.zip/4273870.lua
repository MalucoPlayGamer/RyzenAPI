-- Lua provided by RyzenAPI
-- Game: River Runners

-- MAIN APPLICATION
addappid(4273870)

-- MAIN APP DEPOTS / PACKAGES
addappid(4273871,0,"debc6e7bcb4309ffd47234ab222851620820551fb2722b02394d991eb3130da1")

