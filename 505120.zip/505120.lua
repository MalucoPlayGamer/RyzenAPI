-- Lua provided by RyzenAPI
-- Game: Valentino Rossi The Game Compact

-- MAIN APPLICATION
addappid(505120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(505121, 1, "5ecec3ba223525291e2eaa0e8abf50dd57d477649633b123f8b658320af0b83a")

