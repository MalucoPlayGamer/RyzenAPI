-- Lua provided by RyzenAPI
-- Game: Game: AppID 505120

-- MAIN APPLICATION
addappid(505120)
-- Game: addappid(505120)

-- MAIN APP DEPOTS / PACKAGES
addappid(505121, 1, "5ecec3ba223525291e2eaa0e8abf50dd57d477649633b123f8b658320af0b83a")
