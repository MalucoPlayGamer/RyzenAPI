-- Lua provided by RyzenAPI
-- Game: Best Life Simulator

-- MAIN APPLICATION
addappid(949960)

-- MAIN APP DEPOTS / PACKAGES
addappid(949961, 1, "1cc80c1eb9a8cb6442e83a5ba0b19e35e7e3bda2cdf1a739efbeaac1b211e4fd")
