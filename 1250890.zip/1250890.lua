-- Lua provided by RyzenAPI
-- Game: 1250890

-- MAIN APPLICATION
addappid(1250890)
-- Game: addappid(1250890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250891, 1, "1f16ac54f3e02d0c013403cfd71a1bb5a5895358bda186ccef33da47630b8308")
addappid(1250892, 1, "9e522b4f14bbb1b833b2603b336efd50bda02f238fd1cdb4ffb2dec2613b3073")
