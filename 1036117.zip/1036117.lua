-- Lua provided by RyzenAPI
-- Game: Dusk Diver-Stage costumes PACK

-- MAIN APPLICATION
addappid(1036117)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036117,0,"2797c6f55f53bc5498b34a500be9ed80cd9f56ee0a0e688b9991a2f1b33bee12")

