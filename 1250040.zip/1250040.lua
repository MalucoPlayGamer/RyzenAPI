-- Lua provided by RyzenAPI
-- Game: AppID 1250040

-- MAIN APPLICATION
addappid(1250040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250041, 1, "555ea64356a0c2435d254f3c11a587787ea1f0aa9e846a7f4083d8fa8994453f")
addappid(1250043, 1, "a38f0cab7aa02439d7126283bc09910a92f3a68f8b5502a0a4f92e5035246f47")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
