-- Lua provided by RyzenAPI
-- Game: Hooligan Vasja: Christmas

-- MAIN APPLICATION
addappid(667360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(667361, 1, "23fec2eed8603ac7cf6777ed68a75478c75a34afddf96b7d2d3fad167409aad0")

