-- Lua provided by RyzenAPI
-- Game: Hooligan Vasja: Christmas

-- MAIN APPLICATION
addappid(667360)

-- MAIN APP DEPOTS / PACKAGES
addappid(667361, 1, "23fec2eed8603ac7cf6777ed68a75478c75a34afddf96b7d2d3fad167409aad0")

