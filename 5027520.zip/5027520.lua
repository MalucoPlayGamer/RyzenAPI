-- Lua provided by RyzenAPI
-- Game: Megastore: Tidy Up Together

-- MAIN APPLICATION
addappid(5027520)

-- MAIN APP DEPOTS / PACKAGES
addappid(5027521, 1, "0b4bece51fa05789c4172e6faed43d360d0db528622312bc27b424ae4d608651")
