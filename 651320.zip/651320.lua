-- Lua provided by RyzenAPI
-- Game: addappid(651320)

-- MAIN APPLICATION
addappid(651320)

-- MAIN APP DEPOTS / PACKAGES
addappid(651321, 1, "4c569bc74d0b436bc7b2011b8e430b3fd046fdb6848c03237be216adf604060e")
