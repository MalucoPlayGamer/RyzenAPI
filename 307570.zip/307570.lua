-- Lua provided by SkyAPI 
-- Game: AppID 307570
addappid(307570)
addappid(307571, 1, "750636a1d537dc0d98ac5391d81b97af07f6e9e422fbddd7563cb245409c821d")
addappid(307572, 1, "1aaf075fd502ece138b74512ab96492b42fd6cc82eba1b4872c17b7ca5355ebb")
addappid(307573, 1, "cfc4f46f84740edcceea40477804da2983e5ff9674ce64e9cc411783f587923b")
