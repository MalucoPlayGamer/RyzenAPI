-- Lua provided by RyzenAPI
-- Game: Fallen Angel

-- MAIN APPLICATION
addappid(1124560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124561, 1, "993c3faf82fbee1d9ac10022af59b3a5fe3ee260bdc29ed0d590c54590eedf6a")
