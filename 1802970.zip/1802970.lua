-- Lua provided by RyzenAPI
-- Game: Starflex-VR

-- MAIN APPLICATION
addappid(1802970)
-- Game: addappid(1802970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802971, 1, "5e6742036794f443e10295755156f676dd7f275a7386a66a09b3ca7b0bc7524a")
