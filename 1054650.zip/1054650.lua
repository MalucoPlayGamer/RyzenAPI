-- Lua provided by RyzenAPI
-- Game: addappid(1054650)

-- MAIN APPLICATION
addappid(1054650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054651, 1, "387fc5e1efcba8c6c08dc149bdf3a1c3ab557989ef77411054cd464eaec28095")
