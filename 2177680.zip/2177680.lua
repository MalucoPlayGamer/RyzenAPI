-- Lua provided by RyzenAPI
-- Game: Missing Pictures: Tsai Ming-Liang

-- MAIN APPLICATION
addappid(2177680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177681, 1, "ee9a2b8499bd5d87936c341fd1501407809b1dfdf90c267013b2d6cfabc1862a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
