-- Lua provided by RyzenAPI
-- Game: addappid(2177680)

-- MAIN APPLICATION
addappid(2177680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177681, 1, "ee9a2b8499bd5d87936c341fd1501407809b1dfdf90c267013b2d6cfabc1862a")
