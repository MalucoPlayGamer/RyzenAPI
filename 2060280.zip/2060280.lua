-- Lua provided by RyzenAPI
-- Game: 2060280

-- MAIN APPLICATION
addappid(2060280)
-- Game: addappid(2060280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060280,0,"8f210ec51cad794270eddc55022b23a70e688e715909c17bf7778d3fe8ccef71")
