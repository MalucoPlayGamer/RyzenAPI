-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2921910)
-- Game: addappid(2921910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921913,0,"17fb3cc074294653f934c62a280789530dc01d2bad183c1d1a49c52c1019a0cf")
