-- 2597080's Lua and Manifest Created by Hubcap Manifest
-- Realm of Ink
-- Created: July 29, 2026 at 04:58:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2597080, 1, "04b432ab57a87689ee15e32998283d45a9791293dc7c4f20450eae95bfc65600") -- Realm of Ink
addtoken(2597080, "13497506901935481773")
-- MAIN APP DEPOTS
addappid(2597081, 1, "30b38a65aea230571a237b595825b0e4500f6c3717546e14cf300291af6b4891") -- Depot 2597081
setManifestid(2597081, "6991211255193703581", 5981851616)
addappid(2597082, 1, "823d9917bc63d8708be7167f2c46eb5f3bf528bf4cccffa5b1a5efa13336a429") -- Depot 2597082
setManifestid(2597082, "6987573082333451708", 5931995327)