-- Lua provided by RyzenAPI
-- Game: Game: Realm of Ink

-- MAIN APPLICATION
addappid(2597080)
-- Game: addappid(2597080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597081, 1, "30b38a65aea230571a237b595825b0e4500f6c3717546e14cf300291af6b4891")
