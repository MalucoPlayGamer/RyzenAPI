-- Lua provided by RyzenAPI
-- Game: Game: 1,000 Heads Among the Trees

-- MAIN APPLICATION
addappid(406730)
-- Game: addappid(406730)

-- MAIN APP DEPOTS / PACKAGES
addappid(406731, 1, "6efafbd586f516dc8ff7c1ac45f5bda0336cceb12f6411e6c90f8179eb329e20")
