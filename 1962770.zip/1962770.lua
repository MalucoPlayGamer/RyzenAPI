-- Lua provided by RyzenAPI
-- Game: Nova Empire

-- MAIN APPLICATION
addappid(1962770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1962771, 1, "e276a325685d489fc7bd1aa55d354dfa7075353179f7f0349d3c539adcd4f189")

