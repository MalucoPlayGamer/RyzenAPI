-- Lua provided by RyzenAPI
-- Game: NEDEN?

-- MAIN APPLICATION
addappid(1808630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1808631, 1, "93590404748500173d01478668621497ed3c0b1292dc9e7cb2b554d635dd3e87")

