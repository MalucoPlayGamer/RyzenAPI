-- Lua provided by RyzenAPI
-- Game: Koliseum Soccer VR

-- MAIN APPLICATION
addappid(921960)

-- MAIN APP DEPOTS / PACKAGES
addappid(921961, 1, "41cd72f98a46e0ce66acca1ffdf8302f87eae2bec606946380f67a40ea85ae2b")
