-- Lua provided by RyzenAPI
-- Game: Koliseum Soccer VR

-- MAIN APPLICATION
addappid(921960)

-- MAIN APP DEPOTS / PACKAGES
addappid(921961, 1, "41cd72f98a46e0ce66acca1ffdf8302f87eae2bec606946380f67a40ea85ae2b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(997150)
