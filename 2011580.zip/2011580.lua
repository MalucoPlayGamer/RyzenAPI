-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 It's a Night Magic Welcome Master Set Vol.03

-- MAIN APPLICATION
addappid(2011580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011581, 1, "8593ab3865d8057c80dbc120c86dde51e1284cb824941427e436dd219b75f39c")
addappid(2011582, 1, "b2b9f665f2cea1ec6b4b143e333fde47e9bfd951b5102baceaff2e7e62dd1580")

