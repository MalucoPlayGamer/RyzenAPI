-- Lua provided by RyzenAPI
-- Game: AppID 685420

-- MAIN APPLICATION
addappid(685420)

-- MAIN APP DEPOTS / PACKAGES
addappid(685421, 1, "1f24a6abbc0065951bc0d8739a89cb240d24b93fd7ba6768d4f9ff5956d06ddb")
