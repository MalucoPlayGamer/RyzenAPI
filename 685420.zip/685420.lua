-- Lua provided by RyzenAPI
-- Game: AppID 685420

-- MAIN APPLICATION
addappid(685420)

-- MAIN APP DEPOTS / PACKAGES
addappid(685421, 1, "1f24a6abbc0065951bc0d8739a89cb240d24b93fd7ba6768d4f9ff5956d06ddb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
