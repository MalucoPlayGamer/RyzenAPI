-- Lua provided by RyzenAPI
-- Game: Incremental Birds

-- MAIN APPLICATION
addappid(4965770) -- Incremental Birds

-- MAIN APP DEPOTS / PACKAGES
addappid(4965771, 1, "ce3f7e575d4ab0c1a5ea488b850efc42fb17a854d0843d178b557094f6903b05") -- Depot 4965771

