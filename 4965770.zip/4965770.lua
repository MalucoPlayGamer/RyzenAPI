-- 4965770's Lua and Manifest Created by Hubcap Manifest
-- Incremental Birds
-- Created: August 05, 2026 at 13:40:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4965770) -- Incremental Birds
-- MAIN APP DEPOTS
addappid(4965771, 1, "ce3f7e575d4ab0c1a5ea488b850efc42fb17a854d0843d178b557094f6903b05") -- Depot 4965771
setManifestid(4965771, "2141197682006269535", 22125475)