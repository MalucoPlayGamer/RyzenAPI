-- Lua provided by RyzenAPI
-- Game: Phantom Halls

-- MAIN APPLICATION
addappid(587920)

-- MAIN APP DEPOTS / PACKAGES
addappid(587921,0,"288ad15de465025a986aac689d76f54265b13852f4827d4f7ac6fb72cfcd5c7c")

