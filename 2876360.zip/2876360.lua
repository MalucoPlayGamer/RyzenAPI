-- Lua provided by RyzenAPI
-- Game: Game: Hello Stranger

-- MAIN APPLICATION
addappid(2876360)
-- Game: addappid(2876360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2876361, 1, "18141422508c93c2c47840d82259d335953a42145afce92135429d4485859bfd")
