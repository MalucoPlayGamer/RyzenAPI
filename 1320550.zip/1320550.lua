-- Lua provided by RyzenAPI
-- Game: The Call of Karen

-- MAIN APPLICATION
addappid(1320550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1320551, 1, "3839a3c206763d1c43c9d8c8d56e0501334fbdd6023ff233b139a2f1476c4009")

