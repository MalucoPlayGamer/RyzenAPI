-- Lua provided by RyzenAPI
-- Game: The Call of Karen

-- MAIN APPLICATION
addappid(1320550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320551, 1, "3839a3c206763d1c43c9d8c8d56e0501334fbdd6023ff233b139a2f1476c4009")
