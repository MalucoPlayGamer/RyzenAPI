-- Lua provided by RyzenAPI
-- Game: FUSER™ - Lil Uzi Vert - "XO Tour Llif3"

-- MAIN APPLICATION
addappid(1460360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460360,0,"2382972dac2f723ccb7242d7116b4058465868d53c1327ad345c59a0cd04566b")

