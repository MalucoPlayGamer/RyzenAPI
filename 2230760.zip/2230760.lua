-- Lua provided by SkyAPI 
-- Game: Vampire Survivors: Legacy of the Moonspell
addappid(2230760)
addappid(2230761, 1, "26cf4b06368265325ad0ab20b00118e4a2c1af2a291be8589017fcb6fbb3b42f")
addappid(2230762, 1, "637f60f36d912d8ec9b7e5709787d344cf90850231d771501e903c47c4dd7391")
addappid(2230763, 1, "6a08bb534780032b81fac9fd77e339d7691e64978534c04ee5ce80342112e510")
