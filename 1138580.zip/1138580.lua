-- Lua provided by SkyAPI 
-- Game: AppID 1138580
addappid(1138580)
addappid(1138581, 1, "1fb41d479ffd59d486ea7657cddb2b648826e5559dcf9e827810873623a3e65f")
addappid(1138582, 1, "be7b7227dc118e1e981355dab337d183a0538097067a479ab0ba9c5dad8157ee")
