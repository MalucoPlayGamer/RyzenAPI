-- Lua provided by RyzenAPI
-- Game: The Thaumaturge

-- MAIN APPLICATION
addappid(1684350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684351, 1, "ee43cc0e393840ecaac611a0073adbc587d24dddbadc78b4f9eaa4c734e05db8")
addappid(2777010, 0, "50a8ec9ef2bd894138ee8b3ec55a17c94786242be5d687bf93c6464ee7d0ba6a")

