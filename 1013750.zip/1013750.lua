-- Lua provided by RyzenAPI 
-- Game: AppID 1013750
addappid(1013750)
addappid(1013751, 1, "8e05bd3c18ee519d2297224def99e2bfd9144847cdb530d44bc929eb0daad413")
addappid(1050530, 0, "2081eb4d236831e7f47e42dc41eb3c47734a05ae3c3137fb7451c90291252652")
