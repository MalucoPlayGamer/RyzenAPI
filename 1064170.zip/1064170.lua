-- Lua provided by SkyAPI 
-- Game: AppID 1064170
addappid(1064170)
addappid(1064171, 1, "c6e89d849922108ebdf8b72c2795d3ac51729e203c2d1824ef2ca4444067218e")
