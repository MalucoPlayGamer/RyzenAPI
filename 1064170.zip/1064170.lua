-- Lua provided by RyzenAPI
-- Game: Avast Ye: Antventure be Calling

-- MAIN APPLICATION
addappid(1064170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1064171, 1, "c6e89d849922108ebdf8b72c2795d3ac51729e203c2d1824ef2ca4444067218e")
