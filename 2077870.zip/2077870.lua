-- Lua provided by RyzenAPI
-- Game: My Dad Left Me

-- MAIN APPLICATION
addappid(2077870)
-- Game: addappid(2077870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077871, 1, "9ce8cd1de69c919be39346ad30b243785887235b679281bb0270a92602708e83")
