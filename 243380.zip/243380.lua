-- Lua provided by RyzenAPI
-- Game: addappid(243380)

-- MAIN APPLICATION
addappid(243380)

-- MAIN APP DEPOTS / PACKAGES
addappid(243381, 1, "2bca845a0ebcbfd5e4b780ff5801f4a11a7900cda530eedca1f38e3c2839c719")
