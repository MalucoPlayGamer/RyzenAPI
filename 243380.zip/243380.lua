-- Lua provided by RyzenAPI
-- Game: Might & Magic VI

-- MAIN APPLICATION
addappid(243380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(243381, 1, "2bca845a0ebcbfd5e4b780ff5801f4a11a7900cda530eedca1f38e3c2839c719")

