-- Lua provided by RyzenAPI
-- Game: Touhou: Fading Illusion - Underworld Chapter

-- MAIN APPLICATION
addappid(3095760)
-- Game: addappid(3095760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095760,0,"610f737fd450ea00607451ac54e6c18fcd47a2b0feafbc0fbfe86d43ba140b36")
