-- Lua provided by RyzenAPI
-- Game: Dymension:Scary Horror Survival Shooter

-- MAIN APPLICATION
addappid(1887490)
-- Game: addappid(1887490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887491, 1, "d88122cd937420ab3fc9ecffa8ea7f6578f1230a1c7747578cc411146507453f")
