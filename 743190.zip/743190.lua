-- Lua provided by RyzenAPI
-- Game: Zap Zap Zombie Cats

-- MAIN APPLICATION
addappid(743190)

-- MAIN APP DEPOTS / PACKAGES
addappid(743191, 1, "f05786ef69c4f3043535dc07795d17a4a5730deed90cc18d0e5f096ed53f0aa7")
