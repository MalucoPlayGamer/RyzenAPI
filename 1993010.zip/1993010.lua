-- Lua provided by RyzenAPI
-- Game: Clown Theft Auto: Woke City

-- MAIN APPLICATION
addappid(1993010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993011, 1, "668dc08d71cc392b1caf9756b103af8ca73d9e6e2f77a9c26e4fe56320422c79")

