-- Lua provided by RyzenAPI
-- Game: Inkulinati - Original Soundtrack

-- MAIN APPLICATION
addappid(2273610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273611, 1, "abeaf2839bb2f53d8fab7f63e3addb7a343c793e1692c73c4166514252be12a9")
addappid(2273612, 1, "ed3b468489aec267130f9d0e4b080862433f8bb5be50cf86a1338fbfc06773c7")
