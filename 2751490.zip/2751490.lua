-- Lua provided by RyzenAPI
-- Game: addappid(2751490)

-- MAIN APPLICATION
addappid(2751490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751491, 1, "ad6aae81c910eb203775072a8cb9ab6d23237ade1990bdf3769e0762dcce19f9")
