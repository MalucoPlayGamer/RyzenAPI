-- Lua provided by RyzenAPI
-- Game: Hot Milf 8

-- MAIN APPLICATION
addappid(2120950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120951, 1, "8f0e55b64344d0a0f1db9d5b6e113a8a6d5ae114ad7bd2eb0285365ef7b71d1e")

