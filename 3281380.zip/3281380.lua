-- Lua provided by RyzenAPI
-- Game: addappid(3281380)

-- MAIN APPLICATION
addappid(3281380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3281382,0,"60248980d2986d3ae79cac6d9c16a1215abba08d85abca83a4c6ccb9f5d0a6f8")
