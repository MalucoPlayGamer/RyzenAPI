-- Lua provided by RyzenAPI
-- Game: addappid(2122330)

-- MAIN APPLICATION
addappid(2122330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122331, 1, "b9fd8a690b2b70580d2935a0a692bbc1d34d92f3751c6be61b86f6e03e00f100")
