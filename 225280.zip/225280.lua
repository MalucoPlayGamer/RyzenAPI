-- Lua provided by RyzenAPI
-- Game: Full Mojo Rampage

-- MAIN APPLICATION
addappid(225280)
addappid(228982)
addappid(228990)
-- Game: addappid(225280)

-- MAIN APP DEPOTS / PACKAGES
addappid(225281, 1, "49ae166c821b0a9f6251b359d88350c64aff4f2d9e0aeae1b05725b98a82e291")
