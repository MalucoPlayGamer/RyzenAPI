-- Lua provided by RyzenAPI
-- Game: NTR LIFE

-- MAIN APPLICATION
addappid(3787960)
-- Game: addappid(3787960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3787961, 1, "956b70239e4d9e1a15f02703bfcb9c6c0aa8268e4200cf3ba8c9b95867242b73")
