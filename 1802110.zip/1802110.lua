-- Lua provided by RyzenAPI
-- Game: Take Over Body

-- MAIN APPLICATION
addappid(1802110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802111, 1, "c599cc532aed80b33460a7d5e99f51252514ccd3d09866d9cc778517055988eb")
