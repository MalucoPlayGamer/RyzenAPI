-- Lua provided by RyzenAPI
-- Game: 490940

-- MAIN APPLICATION
addappid(490940)
-- Game: addappid(490940)

-- MAIN APP DEPOTS / PACKAGES
addappid(490941, 1, "19f4c2a1ac3d67f831bf1df81975779c52fd8c409302aa2e6c67f7b5db2a6673")
