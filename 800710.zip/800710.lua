-- Lua provided by RyzenAPI
-- Game: Mad Zombie

-- MAIN APPLICATION
addappid(800710)

-- MAIN APP DEPOTS / PACKAGES
addappid(800711,0,"a9066ee5f1e5279c8fb153117360ca3db681f6087e59a3db82d33ec8696806c0")

