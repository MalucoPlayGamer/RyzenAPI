-- Lua provided by RyzenAPI
-- Game: Game: ⁤Square Wars

-- MAIN APPLICATION
addappid(3125270)
-- Game: addappid(3125270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125271, 1, "cf414efcb1e35a3302aee5ef433a03091397440aa726386609bb6518b03f6f98")
