-- Lua provided by RyzenAPI
-- Game: addappid(1324390)

-- MAIN APPLICATION
addappid(1324390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324390,0,"e6acba7434066362dfe143946dec78cceab713f40f77020759fd17a45e383574")
