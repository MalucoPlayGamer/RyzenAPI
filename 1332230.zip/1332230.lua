-- Lua provided by RyzenAPI
-- Game: Spark and Sparkle Soundtrack: Extra Sounds

-- MAIN APPLICATION
addappid(1332230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332232,0,"fc2cf9cfa3f3f126db267327634559c3aef579e59076b304a17084123aaf0a7e")

