-- Lua provided by SkyAPI 
-- Game: Please Fix The Road
addappid(1383250)
addappid(1383251, 1, "e4298d437b6193e4fb06fd75950f12d2e38ac57010a222f4e9f8108a14c7abfd")
addappid(1383252, 1, "631710d38b7818a8154d955b1523fee23ecd3243bb31b6fb7852eb2fc232f6d7")
addappid(1383254, 1, "e186779d871e19dfba680967a6a1ee04a5761515c184d3d36be5aa2fa89035ab")
