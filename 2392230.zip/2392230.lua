-- Lua provided by RyzenAPI
-- Game: 2392230

-- MAIN APPLICATION
addappid(2392230)
-- Game: addappid(2392230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392231, 1, "e22ec70bbc5ca5c12018d44fba6f1c0c0e553c50b3aad7574379d7e5c0cb8c5f")
