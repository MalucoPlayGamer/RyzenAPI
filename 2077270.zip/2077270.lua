-- Lua provided by RyzenAPI
-- Game: Koa: The Forgotten Gods

-- MAIN APPLICATION
addappid(2077270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077271, 1, "66d95d7671b93e0f7c22121e98d72fa8e0d59ed752ac950ef6e3683843fae27e")

