-- Lua provided by RyzenAPI
-- Game: Dangerous Skies 80's edition

-- MAIN APPLICATION
addappid(896220)

-- MAIN APP DEPOTS / PACKAGES
addappid(896221, 1, "2336e2df7527006faa49d65185c3867b26e0e45b472384a5e8600b01c50ceee4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
