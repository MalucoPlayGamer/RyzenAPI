-- Lua provided by RyzenAPI
-- Game: 2663080

-- MAIN APPLICATION
addappid(2663080)
-- Game: addappid(2663080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663080,0,"6fac0601ba53aba18c4d2c52c58fa0618fd19aad82a8c65e3acfcaf6b09a3f96")
