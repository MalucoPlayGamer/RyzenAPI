-- Lua provided by RyzenAPI
-- Game: AppID 2533830

-- MAIN APPLICATION
addappid(2533830)
-- Game: addappid(2533830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533831, 1, "b4b1faf1012156aa9b829b6052e0f11387aec8d98d5ef3c32a97c4ae092c26cc")
