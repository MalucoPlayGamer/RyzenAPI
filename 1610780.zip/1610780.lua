-- Lua provided by RyzenAPI
-- Game: Out of Space Demo

-- MAIN APPLICATION
addappid(1610780)
-- Game: addappid(1610780)

-- MAIN APP DEPOTS / PACKAGES
addappid(400081,0,"3c2356bba23bf132550c9445c9cd520e20a1228b74481eea67da1aae2eaef054")
addappid(400082,0,"45bc59b02f47c224a5604fa871cf1d1f05204023d597a5d4e4fdd58200348fe3")
addappid(400083,0,"05042ac4f54d913e1b6a95ce762afda6095f604dfb2091b021a95d0047add060")
