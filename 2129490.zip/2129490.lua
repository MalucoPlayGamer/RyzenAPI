-- Lua provided by RyzenAPI
-- Game: Memory Lost: Chapter One

-- MAIN APPLICATION
addappid(2129490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129491, 1, "0ac983068109aa74cad8b4fa2abbe4638e0438f3cd7b539378a2506f77de5ff1")
addappid(2129492, 1, "a5a4a676a09e672f082440e1245954cf6c8e2d166d72a75415d6d9d55d3a4d49")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
