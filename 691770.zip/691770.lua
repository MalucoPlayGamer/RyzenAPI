-- Lua provided by RyzenAPI
-- Game: Eiyu*Senki - The World Conquest

-- MAIN APPLICATION
addappid(691770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(691771, 1, "e7c6159310a68a2abb94b79c8029a7d62d7c39ef83c57f5cb5235b4ea4d30a29")
addappid(691772, 1, "6a04d03b46e9cff5ac9cec79679840596ad808cfc17f5030de33de7b725cdf14")
