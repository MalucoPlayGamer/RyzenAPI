-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2635270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635270,0,"6eb2fb52045e91044bcd33f91b4e0f073108df20e011c7550c8b0efa7c234d97")
