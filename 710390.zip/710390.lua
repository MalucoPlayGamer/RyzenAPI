-- Lua provided by RyzenAPI
-- Game: 710390

-- MAIN APPLICATION
addappid(710390)
-- Game: addappid(710390)

-- MAIN APP DEPOTS / PACKAGES
addappid(710391, 1, "461292f5d5219166cfb945657a27951790cf313e6e71c33c9e94cefad7a4efb0")
