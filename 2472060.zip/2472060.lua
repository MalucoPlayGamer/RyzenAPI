-- Lua provided by RyzenAPI
-- Game: Formula Evolution 2024 Demo

-- MAIN APPLICATION
addappid(2472060)
-- Game: addappid(2472060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472061, 1, "62cef6a6c79bd3130ca04d74461dde090e4e1f7700957079305b55ea51453e41")
