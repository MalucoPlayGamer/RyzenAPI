-- Lua provided by RyzenAPI
-- Game: Intercolonies Demo

-- MAIN APPLICATION
addappid(3264450)
-- Game: addappid(3264450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264451, 1, "5f280d6153a336f6685d1fb7c94048fdcf59187e97553ea2329b7f58905b3128")
