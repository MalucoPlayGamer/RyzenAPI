-- Lua provided by RyzenAPI
-- Game: Game: AppID 239090

-- MAIN APPLICATION
addappid(239090)
-- Game: addappid(239090)

-- MAIN APP DEPOTS / PACKAGES
addappid(239091, 1, "087d9f240a2b41e592d0a2055e825b7fe352a863f53d8853f21346098a21f0f9")
