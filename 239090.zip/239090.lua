-- Lua provided by RyzenAPI
-- Game: Samurai GUNN

-- MAIN APPLICATION
addappid(239090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(239091, 1, "087d9f240a2b41e592d0a2055e825b7fe352a863f53d8853f21346098a21f0f9")

