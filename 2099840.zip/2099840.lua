-- Lua provided by RyzenAPI
-- Game: Drain Mansion Demo

-- MAIN APPLICATION
addappid(2099840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099841, 1, "3d4eead9db9d1790277810adbe6f8b456dabfca45884e2a4682025988b71a01d")

