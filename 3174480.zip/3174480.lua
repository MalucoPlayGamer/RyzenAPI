-- Lua provided by RyzenAPI
-- Game: Return to campus

-- MAIN APPLICATION
addappid(3174480)
addappid(3458590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(3174481, 1, "a140bb4e6d072166d021458cdfe289633960864b3dbd9d4e8449608a2f88e5e0")

