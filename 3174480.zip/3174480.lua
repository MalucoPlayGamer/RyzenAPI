-- Lua provided by RyzenAPI
-- Game: Return to campus

-- MAIN APPLICATION
addappid(3174480)
addappid(3458590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3174481, 1, "a140bb4e6d072166d021458cdfe289633960864b3dbd9d4e8449608a2f88e5e0")

