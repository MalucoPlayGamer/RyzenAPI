-- Lua provided by RyzenAPI
-- Game: Beat Saber - Imagine Dragons - "Machine"

-- MAIN APPLICATION
addappid(1099580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099580,0,"c54837f4b76c8f983c35468170bde05c8865935255fa8acb27f1a50d221a46e4")

