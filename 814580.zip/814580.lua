-- Lua provided by RyzenAPI
-- Game: AppID 814580

-- MAIN APPLICATION
addappid(814580)

-- MAIN APP DEPOTS / PACKAGES
addappid(814581, 1, "1c83dea17c051adccbd971dcad0483456a79061db2b39ef1b8899d0406e2f09f")

