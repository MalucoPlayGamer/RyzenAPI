-- Lua provided by RyzenAPI
-- Game: addappid(2701210)

-- MAIN APPLICATION
addappid(2701210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701212,0,"fe8fca091154c728b6b010b4efb7f2f0672ab6eb159888d77e9727dfd3f85ccf")
