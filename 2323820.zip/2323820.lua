-- Lua provided by RyzenAPI 
-- Game: DEFENDUN Demo
addappid(2323820)
addappid(2323821, 1, "de086617cfd6bf746ce081026e050e2e5b2c27d3da026c1013fa5c4e427d8270")
