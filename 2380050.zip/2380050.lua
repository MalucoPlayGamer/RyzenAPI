-- Lua provided by RyzenAPI
-- Game: Star Trucker

-- MAIN APPLICATION
addappid(2380050)
addappid(2873570)
addappid(3088950)
addappid(3218640)
addappid(3285520)
addappid(3933200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380051,0,"a692f8ffe9b6df42b1c9344a8d1f0f92109fc67c1d094414b767b5e6a641d27a")
addappid(2873570,0,"0112e9dce211b80465433d8f75f2aaddb769530350f876f1fbc6be52efc5ab11")
addappid(3088950,0,"360ccc21ba2392f48bb79f55743a3883e02b09f007ab33d464b425f8378a326e")
addappid(3933200,0,"9d449a98594ddf34570f09eab17b67d5339f2371c53780614a891329312624e1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3617450)
