-- Lua provided by RyzenAPI
-- Game: Star Trucker

-- MAIN APPLICATION
addappid(2380050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380051, 1, "a692f8ffe9b6df42b1c9344a8d1f0f92109fc67c1d094414b767b5e6a641d27a")
