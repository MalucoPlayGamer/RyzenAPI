-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2353770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353770,0,"408a97725b8e34520747bf1c85f71aaa1b32d41aadea7e9f81a1586ec351b148")

