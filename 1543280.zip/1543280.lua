-- Lua provided by RyzenAPI
-- Game: 1543280

-- MAIN APPLICATION
addappid(1543280)
-- Game: addappid(1543280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1543281, 1, "0536eb75d7368e9c2a4065cd48fd9476e294b9a5fb380bb20c6b8ad6f5a8b0d1")
