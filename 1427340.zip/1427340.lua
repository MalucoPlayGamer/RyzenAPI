-- Lua provided by RyzenAPI
-- Game: Witchy Life Story

-- MAIN APPLICATION
addappid(1427340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427341, 1, "d34bd97cfedbb52cc77e3c4d0606ad4b71a4de56c820542f0277943ca097d0c6")

