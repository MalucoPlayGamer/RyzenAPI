-- Lua provided by RyzenAPI
-- Game: Gunship Battle Total Warfare

-- MAIN APPLICATION
addappid(3029540)
