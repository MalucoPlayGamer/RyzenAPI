-- Lua provided by RyzenAPI
-- Game: addappid(1682970)

-- MAIN APPLICATION
addappid(1682970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682971, 1, "b624e2fc8bd702706ce1a60197150203bca12f0b0b1eb6b19232061dc24b05d2")
