-- Lua provided by SkyAPI 
-- Game: Uncrashed : FPV Drone Simulator
addappid(1682970)
addappid(1682971, 1, "b624e2fc8bd702706ce1a60197150203bca12f0b0b1eb6b19232061dc24b05d2")
