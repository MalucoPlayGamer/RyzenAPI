-- Lua provided by RyzenAPI
-- Game: Uncrashed : FPV Drone Simulator

-- MAIN APPLICATION
addappid(1682970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682971, 1, "b624e2fc8bd702706ce1a60197150203bca12f0b0b1eb6b19232061dc24b05d2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
