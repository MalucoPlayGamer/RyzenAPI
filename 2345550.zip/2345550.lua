-- Lua provided by RyzenAPI
-- Game: Meow Legion

-- MAIN APPLICATION
addappid(2345550)
-- Game: addappid(2345550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2345551, 1, "be73ae3a6d0d6009cbe618d96e1ece2f2e1ade37cd6d6c3c4bc5be647b2cbeb8")
addappid(2345555, 1, "775e6c8fe58cd2b875b31b918a2e7376d4bffb1c807a7a46a03368ca278a4fa4")
