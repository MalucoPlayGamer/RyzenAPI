-- Lua provided by SkyAPI 
-- Game: AppID 3064050
addappid(3064050)
addappid(3064051, 1, "1d769d60e66e95687d90ec0def7581a41724353c05cefab85788d7916a68370f")
