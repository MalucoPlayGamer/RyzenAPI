-- Lua provided by RyzenAPI
-- Game: Home Office Tasker

-- MAIN APPLICATION
addappid(1727670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727671, 1, "21d7782985019a162539a168d4569e2fbbf1fc0a0bded924b957f61bbfaae39a")
