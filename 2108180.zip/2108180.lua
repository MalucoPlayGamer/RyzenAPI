-- Lua provided by RyzenAPI
-- Game: Swordhaven: Iron Conspiracy

-- MAIN APPLICATION
addappid(2108180)
addappid(4205670)
addappid(4205680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108181, 1, "a37535e60a7271c54be954c0153730a979fc027cad187830c9bd0490f3e53710")

