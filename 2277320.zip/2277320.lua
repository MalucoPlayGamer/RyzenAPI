-- Lua provided by RyzenAPI
-- Game: Necrosmith 2

-- MAIN APPLICATION
addappid(2277320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277321, 1, "548bb7d556b0cfb098f82e41ee2d494e66184d1b9f2fe9fc074d6b0eb100de80")
addappid(2277322, 1, "f4db2132735ef88c0d55c9e9ae80eb646a452d8730d7707ee1d4397461db0791")
