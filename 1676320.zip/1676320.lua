-- Lua provided by RyzenAPI
-- Game: addappid(1676320)

-- MAIN APPLICATION
addappid(1676320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676321, 1, "b86fe28f2da72936a177c4b4e86858ef5629eac0be329e45fab2fcccc21f647c")
