-- Lua provided by RyzenAPI
-- Game: Ship Surveyor Through the Ages - VR

-- MAIN APPLICATION
addappid(1228470)
-- Game: addappid(1228470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228471, 1, "60028644bebd08d61d965e76546be4b880c3a7c9dc06539f7d26469b1f95ba8f")
