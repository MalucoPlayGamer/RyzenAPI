-- Lua provided by RyzenAPI
-- Game: Cliff Hanger

-- MAIN APPLICATION
addappid(515200)

-- MAIN APP DEPOTS / PACKAGES
addappid(515201, 1, "ba6bd3862978f13963e2fc792d6f2008bf35f80745462db8daff2f2f609a3ff6")
