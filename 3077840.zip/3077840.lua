-- Lua provided by RyzenAPI
-- Game: 出牌吧冒险家 Go Poker Demo

-- MAIN APPLICATION
addappid(3077840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077841, 1, "1ff8392c107c13d85aae76d562c421413940c82326f56a065a78ece40679d0c5")
