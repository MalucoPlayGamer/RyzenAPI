-- Lua provided by RyzenAPI 
-- Game: AppID 2966950
addappid(2966950)
addappid(2966951, 1, "76018e6bda31097c5a6e96d297aa4abe4aeef88904f1654d90be76b05e438dda")
