-- Lua provided by RyzenAPI
-- Game: Space industrial empire

-- MAIN APPLICATION
addappid(2423620)
addappid(2520270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423621, 1, "b1b7e4ebe046e148d9c5d11798c0adafc4fcae6fe8f35aa8094e52fad05a2932")
addappid(2423622, 1, "fbd03bb07a5a769475ffddb4ae8e3a52d00111d2bc6a93044563117e7819f5cb")
