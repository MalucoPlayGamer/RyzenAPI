-- Lua provided by RyzenAPI 
-- Game: ShadowBringer
addappid(1976490)
addappid(1976491, 1, "0499adf93df1e86688ebf636114404ac3a26f59d8c572ef774fc8b19a0c0c9d5")
