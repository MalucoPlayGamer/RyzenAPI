-- Lua provided by RyzenAPI
-- Game: ShadowBringer

-- MAIN APPLICATION
addappid(1976490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1976491, 1, "0499adf93df1e86688ebf636114404ac3a26f59d8c572ef774fc8b19a0c0c9d5")

