-- Lua provided by RyzenAPI
-- Game: AppID 891220

-- MAIN APPLICATION
addappid(891220)

-- MAIN APP DEPOTS / PACKAGES
addappid(891221, 1, "297ec75963efdbec59fe402f744833af08679739f15957958e49ee619265ce71")
addappid(891223, 1, "6806fb00e89a42dba65375441835fb50d3c9c68515bc5bc86e3b32fe51313611")
addappid(891225, 1, "d3442e0327a34c3e6a9745f4cdc2e883cd00f22ce2a110bf077928164df38be7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(908130)
