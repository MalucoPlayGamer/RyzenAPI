-- Lua provided by RyzenAPI
-- Game: Pancake Patrol

-- MAIN APPLICATION
addappid(2587840)
addappid(2622590)
addappid(2622610)
addappid(2622620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587841, 1, "b67066fb518503bf8db98add0a324f47f14b65c1f1c8d0a76aefde7e29a05514")
