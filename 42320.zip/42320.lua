-- Lua provided by RyzenAPI
-- Game: 42320

-- MAIN APPLICATION
addappid(42320)
-- Game: addappid(42320)

-- MAIN APP DEPOTS / PACKAGES
addappid(42321, 1, "de34eea4e65e9db80f71532ed93b0f051a67673fa711dbae4ef95a243186244f")
