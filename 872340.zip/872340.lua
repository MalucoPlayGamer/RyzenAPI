-- Lua provided by RyzenAPI
-- Game: 872340

-- MAIN APPLICATION
addappid(872340)
-- Game: addappid(872340)

-- MAIN APP DEPOTS / PACKAGES
addappid(872341, 1, "0eb6ebbb2054ad6f398933c9dfd6ddbdb164765ef6a16732ba294db73f8dcea0")
