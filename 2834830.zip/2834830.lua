-- Lua provided by RyzenAPI
-- Game: AppID 2834830

-- MAIN APPLICATION
addappid(2834830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834831, 1, "bbad99476ff9263250ad9b7e7bd667616546e1aa8de6b16c54a57fced677fb41")

