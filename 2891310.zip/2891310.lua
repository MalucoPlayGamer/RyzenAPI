-- Lua provided by RyzenAPI
-- Game: addappid(2891310)

-- MAIN APPLICATION
addappid(2891310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2891311, 1, "34a5853f3137451b58cbf5c4c335dcf39541f070cbfe7d5d24d51466f2bfd86f")
