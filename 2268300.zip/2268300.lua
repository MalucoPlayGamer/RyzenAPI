-- Lua provided by RyzenAPI
-- Game: 心灵连线-心靈連線 -Angel Link -エンジェルリンク -엔젤 링크

-- MAIN APPLICATION
addappid(2268300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2268302,0,"571bb48c3c9ffa74da4c3b20691109063d30cfab95d5e0b6db662275eb94884c")
addappid(2268303,0,"28b8b043060c0d08742242b7e0fa15c2d283125f7354b7b262ce65be32668444")
addappid(2268304,0,"7f2181add7479c4b02de7d79e790f83f01a19e90a4cd7bd397bbdc6be7422f6e")

