-- Lua provided by RyzenAPI
-- Game: Toy Soldiers: HD

-- MAIN APPLICATION
addappid(1446160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1446161, 1, "c6a8f4bd96a39fdd907536ea6babe226eda6da508d9f70da5abea36064e89f51")

