-- Lua provided by RyzenAPI
-- Game: Toy Soldiers: HD

-- MAIN APPLICATION
addappid(1446160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446161, 1, "c6a8f4bd96a39fdd907536ea6babe226eda6da508d9f70da5abea36064e89f51")

