-- Lua provided by RyzenAPI
-- Game: addappid(1465500)

-- MAIN APPLICATION
addappid(1465500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465501, 1, "051c1b0db43ac82641168af92b52ab18acd79ecf604b61f02a701e3fbf905f71")
