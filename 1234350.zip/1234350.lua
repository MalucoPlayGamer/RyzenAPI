-- Lua provided by RyzenAPI
-- Game: RetroArch - PPSSPP

-- MAIN APPLICATION
addappid(1234350)
-- Game: addappid(1234350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234350,0,"37bf44f61dd2dee923b2a7c30ba277554bd9c9425f57ea8f6e9ec74cf532c193")
addappid(1234352,0,"312718c6f3db3b6a438737d2d8a4db0bbc841a9fb7494ad20abc676a5f0c4d72")
addappid(1234353,0,"75f3694845b0fc2190d18f04f59519f60ed0d2113db5bd7cd0ad58ca3ed9c5c8")
