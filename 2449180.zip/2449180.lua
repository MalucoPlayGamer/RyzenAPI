-- Lua provided by RyzenAPI
-- Game: Game: 环形杀手 Circle Killer

-- MAIN APPLICATION
addappid(2449180)
-- Game: addappid(2449180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449181, 1, "4befcd139b7fc7f084b8ab77ad27e60178a11f64f56206699bb7e06e2059b526")
