-- Lua provided by RyzenAPI
-- Game: 环形杀手 Circle Killer

-- MAIN APPLICATION
addappid(2449180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2449181, 1, "4befcd139b7fc7f084b8ab77ad27e60178a11f64f56206699bb7e06e2059b526")

