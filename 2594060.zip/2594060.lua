-- Lua provided by RyzenAPI
-- Game: Beat Saber - Mike Shinoda & Kaliee Morgue - In My Head

-- MAIN APPLICATION
addappid(2594060)
-- Game: addappid(2594060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594060,0,"b2ef2ddbba9494897b30dbd8d58e6ed47f7e0f6a04e35005aeb9cd6c5c9a0eb8")
