-- Lua provided by RyzenAPI
-- Game: Arctic Anxiety

-- MAIN APPLICATION
addappid(1276470)
-- Game: addappid(1276470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276471, 1, "11ff969d5b7d7a8689f822bd406eac4511fb9069f081ad81669e3797957197b9")
