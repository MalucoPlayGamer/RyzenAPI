-- Lua provided by RyzenAPI 
-- Game: Grog
addappid(2631240)
addappid(2631241, 1, "939af30a316383cb1732ffcc9fd2f077f57937a638a6a018204a3e14355dc844")
