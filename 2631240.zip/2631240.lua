-- Lua provided by RyzenAPI
-- Game: Game: Grog

-- MAIN APPLICATION
addappid(2631240)
-- Game: addappid(2631240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631241, 1, "939af30a316383cb1732ffcc9fd2f077f57937a638a6a018204a3e14355dc844")
