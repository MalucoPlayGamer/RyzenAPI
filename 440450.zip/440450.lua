-- Lua provided by RyzenAPI
-- Game: AppID 440450

-- MAIN APPLICATION
addappid(440450)
-- Game: addappid(440450)

-- MAIN APP DEPOTS / PACKAGES
addappid(440451, 1, "4b280f456648f9974891d419d92bd1b63fae3dc06e098b77fd60aeece0729774")
