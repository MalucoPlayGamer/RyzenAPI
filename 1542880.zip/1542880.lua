-- Lua provided by RyzenAPI 
-- Game: Kinkoi Demo
addappid(1542880)
addappid(1542881, 1, "ac869a7ae96a37dfb0a197d5f7fb90be1c64a5244a06790d6e1cb8629994fc54")
