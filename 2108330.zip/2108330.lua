-- Lua provided by RyzenAPI
-- Game: F1® 23

-- MAIN APPLICATION
addappid(2108330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108331, 1, "9b7c17f4c9dc84e556c2df053aad13dc7291d2a53f5a21cc6dd81f777c623295")
addappid(2108332, 1, "be52dc2ad64d97ba0255f3d422a115534db8cbd20d996cc716c6c343a4c10d63")
addappid(2108333, 1, "aae26fdc4f2cbee4bbcd2b0023583d9d9f9fad04279d9bc49e534e2c108b5315")
addappid(2108334, 1, "84650ee9f4fbc025c83d5a5e48909f0fd2c59868868fc01257f9221d0c0fefc5")
addappid(2108335, 1, "51b71e9ea1cf18c9ebef4e5035b1ebb3b30ad5f4e7c6d77ec2c71d9bb027e48d")
addappid(2108336, 1, "d97eed20767b856acc3756265dc773a05ad763b57dbf77b9dd56d152c7dc32b5")
addappid(2108337, 1, "f641a084b692cad52e6f0d4018415c68019f2a02f3f1b2340be398be294e0964")
addappid(2108338, 1, "8ba26ca00cda33df3dccc47cbd64fc6ea75ed69c09fd44f3c3b0ffbea07b57ed")
addappid(2108339, 1, "9bc8066cbe4c4b744d93f94c9b4291c01c4929e464fc651a643a88d389767d4f")
addappid(2163910, 0, "cf84ff70d4b92529811ec76a58524bd761ae58a7d76f0b98fc4d0b0cc52df00b")
addappid(2163911, 0, "27ddbf4304c483b269fe4ededb060cf2265b6344762d9ccf7b67ff10689e6cc1")
addappid(2163912, 0, "4168af0f96c4440229411f59c9c5326c3b7c1d0970f328a8a570ef814f88c569")
addappid(2163913, 0, "93da07f1c3cedf7af1c1be6e5d1505114cbb905fd1b1af0483934400be7c5065")
addappid(2163914, 0, "da79eea163f019194ada6c00a0c3d6ac778cf9ffc7ddccbda0d522710258777b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2283420)
addappid(2283421)
addappid(2283422)
addappid(2283423)
addappid(2321670)
addappid(2321671)
addappid(2502610)
addappid(2751200)
addappid(2751210)
