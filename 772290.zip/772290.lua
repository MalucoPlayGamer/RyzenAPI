-- Lua provided by RyzenAPI
-- Game: addappid(772290)

-- MAIN APPLICATION
addappid(772290)

-- MAIN APP DEPOTS / PACKAGES
addappid(772291, 1, "228e380d853b0b937e36afa0eacb3e6785485c923c7daf045eeb3ef07eae5723")
addappid(772292, 1, "d9b27a8c2a84dc8ea721936112aedf86e859a7125477bdd1aae6d2330fa7899e")
addappid(772293, 1, "04c8b0d74e4534d6580961beed0984a1f8653d27d301a5bb4b4ad260cf08b0ae")
addappid(772294, 1, "cd565b15cf58e05234e6f0fce8de1abf436c333cebed6013480e29112cdbc76d")
addappid(1080880, 0, "6ae652dda8510f2814c292bd00558fa475ef9a388f1e3616c201df9c6d7fad3f")
