-- Lua provided by RyzenAPI
-- Game: addappid(2257510)

-- MAIN APPLICATION
addappid(2257510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257511, 1, "ac170188c1ef06ae457309c211077aabce14fd1984d447a5271892c72bd32b74")
