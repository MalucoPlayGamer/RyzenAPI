-- Lua provided by RyzenAPI
-- Game: Beat the Blitz

-- MAIN APPLICATION
addappid(748420)

-- MAIN APP DEPOTS / PACKAGES
addappid(748421, 1, "984f7734db1ce6773ea974b5cf1d9ecf55a2d5c0aba88d91fb648fb0619e9b63")

