-- Lua provided by SkyAPI 
-- Game: Beat the Blitz
addappid(748420)
addappid(748421, 1, "984f7734db1ce6773ea974b5cf1d9ecf55a2d5c0aba88d91fb648fb0619e9b63")
