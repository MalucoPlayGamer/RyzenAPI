-- Lua provided by RyzenAPI
-- Game: Tea Girls Demo

-- MAIN APPLICATION
addappid(3163100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163101, 1, "77c9086e7076491204c158313caff953dc2f835dda285112c48d060e495cba2b")
