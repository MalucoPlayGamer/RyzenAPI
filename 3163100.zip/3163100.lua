-- Lua provided by SkyAPI 
-- Game: AppID 3163100
addappid(3163100)
addappid(3163101, 1, "77c9086e7076491204c158313caff953dc2f835dda285112c48d060e495cba2b")
