-- Lua provided by RyzenAPI
-- Game: AppID 552590

-- MAIN APPLICATION
addappid(552590)
addappid(612350)

-- MAIN APP DEPOTS / PACKAGES
addappid(552591, 1, "3a1be3f3d292a11a379f6751406422aa60acdc1ded895202d51291e5fec88364")

