-- Lua provided by RyzenAPI
-- Game: 552590

-- MAIN APPLICATION
addappid(552590)
-- Game: addappid(552590)

-- MAIN APP DEPOTS / PACKAGES
addappid(552591, 1, "3a1be3f3d292a11a379f6751406422aa60acdc1ded895202d51291e5fec88364")
