-- Lua provided by RyzenAPI
-- Game: Rhythia

-- MAIN APPLICATION
addappid(2250500)
addappid(4018960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250502,0,"abcdacfdd298bd11058c6e08fa32e0ff0d398467ffb9d99520a9a2fd04ac0bb9")
addappid(2250503,0,"363dc89a44c1617dc26ee81bf6b3ed6b0e6789efb90ade4cb1cb387110da3f54")
addappid(2250504,0,"e93ac2cd5e40811b05f0e044fb3f84a31ce10e266ce9c90731ed9ea96872710d")

