-- Lua provided by RyzenAPI
-- Game: 881190

-- MAIN APPLICATION
addappid(881190)

-- MAIN APP DEPOTS / PACKAGES
addappid(905250,0,"c25c953be55eac837d76a6ce52d952de4c6fecd45ab1518ef8c7a571ef3de5ff")

