-- Lua provided by RyzenAPI
-- Game: Game: Dice To Pay

-- MAIN APPLICATION
addappid(3631830)
-- Game: addappid(3631830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3631831, 1, "f4121927c4090834b582e5b43ce91f94785e8c0393fd6a343d494206a2be8853")
