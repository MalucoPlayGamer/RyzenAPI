-- Lua provided by RyzenAPI 
-- Game: EARTH DEFENSE FORCE 5
addappid(1007040)
addappid(1007041, 1, "9e97f916bd62116e247cbac00bdde6ee17ef433c1f275e1bf91ced2f4bec5106")
addappid(1007042, 1, "59820074274e4bba44d87dab26511cbfe7dec04cb3cf08690641dc57ca9f75cf")
