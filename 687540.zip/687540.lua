-- Lua provided by RyzenAPI
-- Game: Game: AppID 687540

-- MAIN APPLICATION
addappid(687540)
-- Game: addappid(687540)

-- MAIN APP DEPOTS / PACKAGES
addappid(687541, 1, "060cd7ae12da570bd34bf46a3a59a9f6306b37dcf7c37dabeb758cd3affc1bd2")
addappid(687542, 1, "10d1ad3a5df346e1599851220b2e9c78f26a10919728e2bd4cf11ddf018ac422")
