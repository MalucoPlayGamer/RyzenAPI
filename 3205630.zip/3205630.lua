-- Lua provided by RyzenAPI
-- Game: 3205630

-- MAIN APPLICATION
addappid(3205630)
-- Game: addappid(3205630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205631, 1, "495dff71f16fa1db8753c96fa1361dab4764c59f28e6caa31ce1f2df0e9dbfb1")
