-- Lua provided by RyzenAPI
-- Game: Game: Paranormal Detective: Escape from the 80's

-- MAIN APPLICATION
addappid(1114460)
-- Game: addappid(1114460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114461, 1, "75cd37581a8f6794978207bf106346917ef396f1da2406311b3822e74458feb1")
