-- Lua provided by RyzenAPI
-- Game: Game: Small World

-- MAIN APPLICATION
addappid(235620)
-- Game: addappid(235620)

-- MAIN APP DEPOTS / PACKAGES
addappid(235621, 1, "42d7b0ec99a314ca7dcdcaef8eedd6e95e5498a409fa766730b7f61cb1d7f1ea")
addappid(235622, 1, "6f1c38894c1b7f386a6f0c3d5936cd00744468bd495e3a0bc95fcbd519f440f6")
addappid(235623, 1, "b805c16c8deea30e6904b61a366d76b25e83b05a576db79dbd61adafe2827c9e")
addappid(235624, 1, "c5a218cfd75b80479f60c755db91066d6252917ba29fe5ad64f44d4b9affa30b")
addappid(235625, 1, "3e36779a454f24a952fe345f3464001d269d7a0e4c5a7efb9cc5fee0d2577de0")
addappid(235626, 1, "c3ef008b70fe9c42c442266ea444ce3a8eac7cd8711d5643b971a58899da87b4")
addappid(235627, 1, "fe89f462d5e3152fcf914482e11fbcd25cff89221525a3349a1995645aedc706")
addappid(235628, 1, "3719b99ee9aefd8a4b318ae9ada1825a25861ce37f155bca8dca17fa0453c335")
addappid(235629, 1, "824c6250db0fd0e5e077d7520c4a71c33c493cb34e3d2dd628e83fcc79cfb7d3")
