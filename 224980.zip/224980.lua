-- Lua provided by RyzenAPI
-- Game: addappid(224980)

-- MAIN APPLICATION
addappid(224980)

-- MAIN APP DEPOTS / PACKAGES
addappid(224981, 1, "3e1a7b127da35a84e3a9eec8906b99258420401b0fe13c8fd2e1fe73d1f0beb5")
