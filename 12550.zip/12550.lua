-- Lua provided by RyzenAPI
-- Game: Are You Smarter than a 5th Grader?

-- MAIN APPLICATION
addappid(12550)

-- MAIN APP DEPOTS / PACKAGES
addappid(12551, 1, "1523470d6ded0bfc42e6712f53efa36aecf04a2b8068915b0b5c986d6aa941fd")
