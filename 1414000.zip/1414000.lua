-- Lua provided by RyzenAPI
-- Game: Game: Obscurite Magie: The City of Sin

-- MAIN APPLICATION
addappid(1414000)
-- Game: addappid(1414000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414001, 1, "afd43ad874fd4ea752b145657d509d5907ae512751520161eab4b4ce22dc0207")
addappid(1414002, 1, "8b33d397fa071538fc0e2b1e244e6a6fb76e0493d7bc597cda469bcb1f3ff7c6")
addappid(1414003, 1, "b78adf4ff0e2d4db8760601513f4690bc2f4783bb3b96b1ca37a20495945d227")
