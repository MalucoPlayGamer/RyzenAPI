-- Lua provided by SkyAPI 
-- Game: Rising Dusk
addappid(848930)
addappid(848931, 1, "2af14dee616f4aff508adce3b7e542ed2a267093e3b4c7eabca09e06dd85f1f5")
addappid(848932, 1, "51247c0200a4dd4c9ed13d501f5070716d81da9a7e88f43d98f4628fd09b79fb")
