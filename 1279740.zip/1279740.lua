-- Lua provided by RyzenAPI
-- Game: AppID 1279740

-- MAIN APPLICATION
addappid(1279740)
-- Game: addappid(1279740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279741, 1, "ad0343802246cd41a95710a7e9a115f5c89f49992506f3e9daa789ea0cd3b96e")
