-- Lua provided by RyzenAPI
-- Game: AppID 1970800

-- MAIN APPLICATION
addappid(1970800)
-- Game: addappid(1970800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970801, 1, "8f8c4770b40a5c31950e0e684047d80c979fb9dc0bb76c63d2b0ffcc531d1be4")
