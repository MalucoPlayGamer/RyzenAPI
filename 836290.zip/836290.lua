-- Lua provided by RyzenAPI
-- Game: Achievement Lurker: Ballad of the Shimapan Warrior - King of Panties

-- MAIN APPLICATION
addappid(836290)
-- Game: addappid(836290)

-- MAIN APP DEPOTS / PACKAGES
addappid(836291, 1, "b4ea4027de5da7aa6323f1606c9a7dd69e2b11beed4692c15c3bdb56a45506d6")
