-- Lua provided by RyzenAPI
-- Game: FUSER™ - Post Malone - "Circles"

-- MAIN APPLICATION
addappid(1432173)
-- Game: addappid(1432173)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432173,0,"e05a903aa0095534db3f0c482d8e4c908eaa40ef3f319cb12f5e28eae24deab6")
