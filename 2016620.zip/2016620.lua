-- Lua provided by RyzenAPI
-- Game: Game: AppID 2016620

-- MAIN APPLICATION
addappid(2016620)
-- Game: addappid(2016620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2016621, 1, "1847f1e5e21b69bdd784dd8294489bf56c0bf478a88e545ce91e3f2bf953463b")
