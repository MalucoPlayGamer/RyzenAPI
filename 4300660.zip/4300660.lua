-- Lua provided by RyzenAPI
-- Game: Fire Pit: Throw Things Into The Fire

-- MAIN APPLICATION
addappid(4300660)

-- MAIN APP DEPOTS / PACKAGES
addappid(4300661,0,"2ea89275f63be7c269d12bac3a626fcc588a53524f3858361a681adb99cad74c")

