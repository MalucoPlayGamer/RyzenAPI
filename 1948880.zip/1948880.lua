-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(1948880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948882,0,"2a93496fc2ffd8ce6acec96ae296ff7c70c5b3c155d710e7326e6d9fc50d6f17")
