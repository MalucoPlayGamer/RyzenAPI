-- Lua provided by RyzenAPI
-- Game: Game: Lord of the Click: Interstellar Wars

-- MAIN APPLICATION
addappid(2423960)
-- Game: addappid(2423960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423961, 1, "a48caa2d76f6691aad23db3359afa4ba020a314bea9dfc07ebea0d853a259f01")
