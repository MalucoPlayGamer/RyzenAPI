-- Lua provided by RyzenAPI
-- Game: SAMURAI WARRIORS 5 - Additional Scenario & BGM Set 1

-- MAIN APPLICATION
addappid(1634708)
-- Game: addappid(1634708)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634708,0,"f6bfdc7782b955f840a30769c2d98d32d9f7f4030578b19acb0121decfaf747a")
