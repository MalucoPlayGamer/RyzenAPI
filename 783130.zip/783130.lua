-- Lua provided by RyzenAPI
-- Game: 783130

-- MAIN APPLICATION
addappid(783130)
-- Game: addappid(783130)

-- MAIN APP DEPOTS / PACKAGES
addappid(783131, 1, "b3d60a8fbea1d4c1df40b1e1b4be3c9a3fab4484130de072a0196d13f6a417ef")
