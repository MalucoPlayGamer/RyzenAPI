-- Lua provided by RyzenAPI
-- Game: Blade Assault

-- MAIN APPLICATION
addappid(1367300)
-- Game: addappid(1367300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367301, 1, "d1be7912054b86bb00b26607d988dd17f212431610a64d1a7d4347ba7d5de13d")
