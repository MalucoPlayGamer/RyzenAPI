-- Lua provided by RyzenAPI
-- Game: 3670750

-- MAIN APPLICATION
addappid(3670750)
-- Game: addappid(3670750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3670751, 1, "f9e0e6c37990b4136e33c16843531c5dd5b8deacc1f2f220f3358bf59ee545cb")
