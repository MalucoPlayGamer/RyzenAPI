-- Lua provided by RyzenAPI
-- Game: Afterglow-The fifth ending

-- MAIN APPLICATION
addappid(3670750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3670751, 1, "f9e0e6c37990b4136e33c16843531c5dd5b8deacc1f2f220f3358bf59ee545cb")

