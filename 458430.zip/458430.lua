-- Lua provided by RyzenAPI
-- Game: Steel Seed

-- MAIN APPLICATION
addappid(458430)
addappid(3626520)
addappid(3626530)
-- Game: addappid(458430)

-- MAIN APP DEPOTS / PACKAGES
addappid(458432,0,"676d0c262af24e6cd734932d053a9997f4e69a5226ac436b337b04054884257a")
addappid(3626520,0,"9e6ccdec2df7d0d334069f38327098dd7fad54e37fc15d75f364187201721c2d")
