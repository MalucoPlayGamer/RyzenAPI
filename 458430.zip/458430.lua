-- Lua provided by RyzenAPI
-- Game: Steel Seed

-- MAIN APPLICATION
addappid(458430)
addappid(3626520)
addappid(3626530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(458432,0,"676d0c262af24e6cd734932d053a9997f4e69a5226ac436b337b04054884257a")
addappid(3626520,0,"9e6ccdec2df7d0d334069f38327098dd7fad54e37fc15d75f364187201721c2d")

