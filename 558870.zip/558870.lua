-- Lua provided by RyzenAPI
-- Game: 558870

-- MAIN APPLICATION
addappid(558870)
-- Game: addappid(558870)

-- MAIN APP DEPOTS / PACKAGES
addappid(558871, 1, "cdcfac32170f28c7f6b73e58e44ee2b0cdfadba9c9759a8a9b2b57447fa9f082")
