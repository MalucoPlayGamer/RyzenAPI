-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3353850)
-- Game: addappid(3353850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3353852,0,"9a0366b9c7ffad1d76ae375786d2e7810a0e417982823995b050b1131f5cb8f2")
