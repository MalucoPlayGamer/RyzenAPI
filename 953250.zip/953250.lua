-- Lua provided by RyzenAPI 
-- Game: War Machines: Free to Play
addappid(953250)
addappid(953251, 1, "7f260af3b6dd00cd27a5d49aa540f2d4608a8a38ae9769359b8145ef0d1adafb")
