-- Lua provided by SkyAPI 
-- Game: sCATter
addappid(1014710)
addappid(1014711, 1, "17f984d96a718bcf68b9ab2ae405cd8945c810024b1407d7a12531142eb6b727")
