-- Lua provided by RyzenAPI
-- Game: sCATter

-- MAIN APPLICATION
addappid(1014710)
-- Game: addappid(1014710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014711, 1, "17f984d96a718bcf68b9ab2ae405cd8945c810024b1407d7a12531142eb6b727")
