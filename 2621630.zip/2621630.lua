-- Lua provided by RyzenAPI
-- Game: AppID 2621630

-- MAIN APPLICATION
addappid(2621630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2621631, 1, "4de5b1e714f898f535c2c25136d24abc6e554d454c77f0ebc9dddc23b6bbef3b")
