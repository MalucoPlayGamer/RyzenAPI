-- Lua provided by RyzenAPI
-- Game: Animus - Stand Alone

-- MAIN APPLICATION
addappid(918110)

-- MAIN APP DEPOTS / PACKAGES
addappid(918111, 1, "29832d3c922639c053c251cccd0d140e08b4a8fe12e197fcd607a8e4909c1355")

