-- Lua provided by RyzenAPI
-- Game: addappid(1901950)

-- MAIN APPLICATION
addappid(1901950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901951, 1, "a5c4c3d02b1f0dbf051700d1e0130c4db032fb1dfcffe6e5004ffef5451e0dc3")
