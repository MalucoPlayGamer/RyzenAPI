-- Lua provided by RyzenAPI
-- Game: Raid on Taihoku

-- MAIN APPLICATION
addappid(1901950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901951, 1, "a5c4c3d02b1f0dbf051700d1e0130c4db032fb1dfcffe6e5004ffef5451e0dc3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2265890)
