-- Lua provided by RyzenAPI
-- Game: AppID 1417640

-- MAIN APPLICATION
addappid(1417640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1417641, 1, "3246c56c5e9d0effe00cd209fc73abceac3a35152257d30f0c2332af824cc436")

