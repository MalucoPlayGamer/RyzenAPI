-- Lua provided by RyzenAPI 
-- Game: Varial
addappid(2069340)
addappid(2069341, 1, "4e005a60ab7c821d26390088ddec7b5ad88fe3b61b21b854e49117d76d583024")
