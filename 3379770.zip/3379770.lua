-- Lua provided by RyzenAPI
-- Game: Quartermain and the Cult of Cthulhu

-- MAIN APPLICATION
addappid(3379770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3379771, 1, "8b43a11d57a4e6a77d222ea1a68cd58566975e156cd76039d4239feb006eeeb8")

