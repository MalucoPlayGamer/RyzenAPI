-- Lua provided by RyzenAPI
-- Game: Raise the Colours

-- MAIN APPLICATION
addappid(4008340)
