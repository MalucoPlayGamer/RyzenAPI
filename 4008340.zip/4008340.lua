-- Lua provided by RyzenAPI
-- Game: Raise the Colours

-- MAIN APPLICATION
addappid(4008340)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4137190)
addappid(4137200)
addappid(4672210)
addappid(4672220)
addappid(4672240)
addappid(4672250)
addappid(4672260)
addappid(4672270)
addappid(4672280)
addappid(4672290)
