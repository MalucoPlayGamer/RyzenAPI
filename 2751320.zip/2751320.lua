-- Lua provided by RyzenAPI
-- Game: Johnny Trigger

-- MAIN APPLICATION
addappid(2751320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751321, 1, "3e7cd8ad11ea3904f9fb7a09c53c2fd3210f9be3f33c45146ce3c4dadc4fec41")
addappid(2821540, 0, "1404ddaec72c4c9db4369271fbe09b3edaa30cdcbb13398518a770ba4dfaf5d2")
addappid(2821560, 0, "2481165507a914109eec747fc5831b1e4f26c92222386fc48471c4e0d1cd15e2")
