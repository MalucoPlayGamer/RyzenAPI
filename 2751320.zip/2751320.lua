-- Lua provided by RyzenAPI
-- Game: Johnny Trigger

-- MAIN APPLICATION
addappid(2751320) -- Johnny Trigger
addappid(2821540)
addappid(2821550)
addappid(2821560)
addappid(2821570)
addappid(2821580)
addappid(2821590)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
addappid(2751321, 1, "3e7cd8ad11ea3904f9fb7a09c53c2fd3210f9be3f33c45146ce3c4dadc4fec41") -- Depot 2751321
addappid(2821540, 1, "1404ddaec72c4c9db4369271fbe09b3edaa30cdcbb13398518a770ba4dfaf5d2") -- Johnny Trigger Lunatic DLC - Depot 2821540
addappid(2821550, 1, "fddaa90a130fbdb06487c2bba82ac5a480618f114d7374c25ceceeb2a831601f") -- Johnny Trigger Butcher DLC - Depot 2821550
addappid(2821560, 1, "2481165507a914109eec747fc5831b1e4f26c92222386fc48471c4e0d1cd15e2") -- Johnny Trigger Avenger DLC - Depot 2821560
addappid(2821570, 1, "22e56924815d20525115e7b1dcaa819baa9394af3bf41a92ab766e798c9af770") -- Johnny Trigger Hunter DLC - Depot 2821570
addappid(2821580, 1, "fd879849264c00fdf8dde6a2fe1690b6d1092b76c0723cd5053aa6f0f91cd057") -- Johnny Trigger Johnnybee DLC - Depot 2821580
addappid(2821590, 1, "0c10962232d5481d2baac1ba0f2427022fe488663ff3162b708e29293b31744b") -- Johnny Trigger Hotshot DLC - Depot 2821590

