-- Lua provided by RyzenAPI 
-- Game: Tinykin Soundtrack
addappid(2110850)
addappid(2110851, 1, "af528b355f456f60f111d9da3bcc7ee239e4fe0e6e4d8e98dd6203a07ba05718")
