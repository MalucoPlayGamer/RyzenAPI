-- Lua provided by RyzenAPI
-- Game: Carter Story / 卡特冒险

-- MAIN APPLICATION
addappid(1690180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690181, 1, "c5dddfeb8057475773950a6352cd27a0b18fe28a26cd017a48c2197dca530bea")

