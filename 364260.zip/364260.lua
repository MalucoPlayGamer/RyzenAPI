-- Lua provided by RyzenAPI
-- Game: AppID 364260

-- MAIN APPLICATION
addappid(364260)
-- Game: addappid(364260)

-- MAIN APP DEPOTS / PACKAGES
addappid(364261, 1, "57a3e199efabc0a83623c96fc25a5b5da65ad8dec6bb7f3f698edd13261f33a8")
