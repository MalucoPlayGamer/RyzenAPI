-- Lua provided by RyzenAPI
-- Game: AppID 716340

-- MAIN APPLICATION
addappid(716340)

-- MAIN APP DEPOTS / PACKAGES
addappid(716341, 1, "bd15126fc962dbb6c0a4ec9a42b6e18a6a0b2e811b58be392e437f73b38bbddc")
addappid(1075720, 0, "bff260b646418deae614e18a6e4d34d49c08e7d7fd34695a4b3d94c6ccaf9da8")
