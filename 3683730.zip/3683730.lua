-- Lua provided by RyzenAPI
-- Game: Roulette Wheel

-- MAIN APPLICATION
addappid(3683730)
addappid(3683810)
-- Game: addappid(3683730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3683731, 1, "2f007df23df4d0f812e52a21cd1c59a3a6070dc5c384fe8af5dd466180a2cc59")
