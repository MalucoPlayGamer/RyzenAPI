-- Lua provided by RyzenAPI
-- Game: Roulette Wheel

-- MAIN APPLICATION
addappid(3683730)
addappid(3683810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3683731, 1, "2f007df23df4d0f812e52a21cd1c59a3a6070dc5c384fe8af5dd466180a2cc59")

