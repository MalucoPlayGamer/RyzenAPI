-- Lua provided by RyzenAPI
-- Game: 366610

-- MAIN APPLICATION
addappid(366610)
-- Game: addappid(366610)

-- MAIN APP DEPOTS / PACKAGES
addappid(366611, 1, "0bbadfb59f09c3f4116b6092a2590087e5cdf078d63c55ad4cc072a0e9276064")
