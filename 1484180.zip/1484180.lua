-- Lua provided by RyzenAPI
-- Game: 1484180

-- MAIN APPLICATION
addappid(1484180)
-- Game: addappid(1484180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484181, 1, "c98d788818dfa00955e2299c6db3d208e51e18eca866e5b34abff373e159dd2c")
