-- Lua provided by RyzenAPI
-- Game: Black Myth: Wukong Benchmark Tool

-- MAIN APPLICATION
addappid(3132990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132991, 1, "a76096f781e0c6b4496779df4773cfcf92053906873fcaa9003f0e9f95b2ea98")

