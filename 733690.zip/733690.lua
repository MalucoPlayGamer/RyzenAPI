-- Lua provided by RyzenAPI
-- Game: addappid(733690)

-- MAIN APPLICATION
addappid(733690)

-- MAIN APP DEPOTS / PACKAGES
addappid(733691, 1, "aa75a5521a6f421aad8fe9f3a5f8f2399779c3ecf5656460276132b81cf76234")
