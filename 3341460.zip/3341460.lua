-- Lua provided by SkyAPI 
-- Game: Metathrone
addappid(3341460)
addappid(3341461, 1, "a9343a30bab4ed32f53456e313c7ec9e3b5379a9901d8d7d77832820055427ad")
addappid(3341462, 1, "006ba1e3f19c218c94a637e5e7e63c0d0bd1ff477a5ac050c7199646354b8f7f")
