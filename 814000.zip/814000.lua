-- Lua provided by RyzenAPI
-- Game: ONE PIECE ODYSSEY

-- MAIN APPLICATION
addappid(814000)
addappid(2004600)
addappid(2004601)
addappid(2004602)
addappid(2004603)
addappid(2004604)
addappid(2004605)
addappid(2004606)
addappid(2004607)
addappid(2114010)
addappid(2114030)
addappid(2281180)
addappid(2281181)
addappid(2282610)
-- Game: addappid(814000)

-- MAIN APP DEPOTS / PACKAGES
addappid(814001, 1, "42d84d2e42b1e4103fb7597c5044385c294167829b1e033d894530ec3e3c4456")
addappid(1888180, 0, "9b6b1e02076f2b3b11efddeddcf5f205f632842421696481a24be1cbfbd6a46a")
