-- Lua provided by RyzenAPI
-- Game: Worms

-- MAIN APPLICATION
addappid(70640)
-- Game: addappid(70640)

-- MAIN APP DEPOTS / PACKAGES
addappid(70641, 1, "2929ec716ea9977eaaa7b17a1b4d02ae3101d5568cb743958a5e06feb2a2ad7d")
