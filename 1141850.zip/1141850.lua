-- Lua provided by RyzenAPI
-- Game: Radial

-- MAIN APPLICATION
addappid(1141850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1141851, 1, "0bd5ac1071923981ee8181f321a42fbd9c22df2b8d8f05fa9fe49ba06797d1db")
