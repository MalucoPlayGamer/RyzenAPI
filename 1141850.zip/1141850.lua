-- Lua provided by RyzenAPI
-- Game: Game: AppID 1141850

-- MAIN APPLICATION
addappid(1141850)
-- Game: addappid(1141850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141851, 1, "0bd5ac1071923981ee8181f321a42fbd9c22df2b8d8f05fa9fe49ba06797d1db")
