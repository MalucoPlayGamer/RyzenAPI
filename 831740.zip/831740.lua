-- Lua provided by RyzenAPI
-- Game: Circles of hell

-- MAIN APPLICATION
addappid(831740)

-- MAIN APP DEPOTS / PACKAGES
addappid(831741, 1, "f3c229adf55df8b934fbe01518f099c2c91b750f099c7466afc7421f7715e782")
