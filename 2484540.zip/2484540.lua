-- Lua provided by SkyAPI 
-- Game: Save My Sister
addappid(2484540)
addappid(2484541, 1, "a4bec2846c49ee6c816af81094f356a6849cf4754ec863d958092d77b45bab5f")
addappid(2484542, 1, "124ec27ac6fa2ad36691b3a584d8dda1c7f916c67b8978ba8a9acb4e1650040d")
