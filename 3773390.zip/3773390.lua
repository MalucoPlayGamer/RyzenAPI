-- Lua provided by RyzenAPI
-- Game: Super Kingcrab Simulator

-- MAIN APPLICATION
addappid(3773390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3773391, 1, "034ec026e64f410bb5a5725e01ec1492f4f30098d8e015690a240756c5d715ab")

