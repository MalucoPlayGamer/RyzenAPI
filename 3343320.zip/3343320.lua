-- Lua provided by RyzenAPI 
-- Game: Lustborn
addappid(3343320)
addappid(3343321, 1, "8f0d08ff220cf9dcd58cb6680701d3b09aeb337b0a8edcfed976a682340dfe0d")
