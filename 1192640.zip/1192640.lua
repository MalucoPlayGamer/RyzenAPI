-- Lua provided by RyzenAPI
-- Game: Game: Mosaique Neko Waifus

-- MAIN APPLICATION
addappid(1192640)
-- Game: addappid(1192640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192641, 1, "97f9f9d4279bcc116a1fcc2edec5c1b0de04bd07313262a27746905cb3ced919")
addappid(1192644, 1, "2c86ba36c78da28ffc0249a825a2479f3aa878aebeaac35a5d05770742f80a2a")
addappid(1206820, 0, "776b62fdca6d56286f9b01728c739137345a1653ca762c2de3d6fcbfe44ba599")
addappid(1206821, 0, "1f5f1bf8641c0e6f11ff4b81814f3cf697d2086a0058723b41c249511f5d3ca2")
