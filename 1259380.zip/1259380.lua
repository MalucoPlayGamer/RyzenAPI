-- Lua provided by RyzenAPI
-- Game: 1259380

-- MAIN APPLICATION
addappid(1259380)
-- Game: addappid(1259380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259381, 1, "58500298a66eb8aabcfe25ed76f530c9aa4ba98d23ea57f807b3c95104eb2f1e")
