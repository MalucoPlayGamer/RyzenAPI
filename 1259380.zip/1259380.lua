-- Lua provided by RyzenAPI
-- Game: Submarine Titans

-- MAIN APPLICATION
addappid(1259380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1259381, 1, "58500298a66eb8aabcfe25ed76f530c9aa4ba98d23ea57f807b3c95104eb2f1e")

