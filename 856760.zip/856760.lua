-- Lua provided by RyzenAPI
-- Game: AppID 856760

-- MAIN APPLICATION
addappid(856760)
-- Game: addappid(856760)

-- MAIN APP DEPOTS / PACKAGES
addappid(856761, 1, "a1a14362a9931f4936bcaf6c14a0161e3617ff611197c3acdc133836ca3f98d5")
addappid(858270, 0, "f00acd96e920fc2ac7da8cdd50c5e8d67d92d45db76b9942cbed1b7def266701")
