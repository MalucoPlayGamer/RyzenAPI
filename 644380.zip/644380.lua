-- Lua provided by RyzenAPI
-- Game: Game: Hegis' Grasp: Evil Resurrected

-- MAIN APPLICATION
addappid(644380)
-- Game: addappid(644380)

-- MAIN APP DEPOTS / PACKAGES
addappid(644381, 1, "a4e8a2537a96574504eab4d16c7a6371d0c14fb77a07e574e2e8b2ac4b914a2a")
addappid(644382, 1, "7506665de6c2ba59441393fc2bcb28cb03922619b67d50d62f76cfc98383d671")
addappid(644383, 1, "dab27c87a3fc3bdcb561b2ae4425a6c85f01d2e70ba60d3f6bcc92ce4acc6742")
addappid(953140, 0, "09668cf9ac4eb2a25f3b2bd87c5c0d813c0393efe27b0cd71f8c34f76ad91d83")
