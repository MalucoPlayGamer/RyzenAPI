-- Lua provided by RyzenAPI
-- Game: Hegis' Grasp: Evil Resurrected

-- MAIN APPLICATION
addappid(644380)
addappid(729440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(644381, 1, "a4e8a2537a96574504eab4d16c7a6371d0c14fb77a07e574e2e8b2ac4b914a2a")
addappid(644382, 1, "7506665de6c2ba59441393fc2bcb28cb03922619b67d50d62f76cfc98383d671")
addappid(644383, 1, "dab27c87a3fc3bdcb561b2ae4425a6c85f01d2e70ba60d3f6bcc92ce4acc6742")
addappid(953140, 0, "09668cf9ac4eb2a25f3b2bd87c5c0d813c0393efe27b0cd71f8c34f76ad91d83")

