-- Lua provided by RyzenAPI
-- Game: Reigns: Game of Thrones

-- MAIN APPLICATION
addappid(897820)

-- MAIN APP DEPOTS / PACKAGES
addappid(897821, 1, "deb66c9cc47efd135c6b27f5a6f65f73d859b4f9d74f092eafa98899a7c23e85")
addappid(897822, 1, "f2ff23127aa1ae9ddb138f1929a881a507a98c7115c226109b29bca02dd2b023")
addappid(897823, 1, "045f0f6baadff2ee659bab31daab2982e2acee4e6fe211db4fb0a16a42942951")
addappid(897824, 1, "6b2749e617a64fdd3d6bd8041b694d0ee8471de1f2e844e73fe9f6320cacf0a9")

