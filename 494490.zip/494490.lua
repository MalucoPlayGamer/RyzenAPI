-- Lua provided by RyzenAPI
-- Game: 坦克大战

-- MAIN APPLICATION
addappid(494490)
-- Game: addappid(494490)

-- MAIN APP DEPOTS / PACKAGES
addappid(494492,0,"4d1eece001b93bbef22721f42c81d40379c50cb78d254131184c72c6cb525b38")
