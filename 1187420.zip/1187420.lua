-- Lua provided by RyzenAPI
-- Game: AppID 1187420

-- MAIN APPLICATION
addappid(1187420)
-- Game: addappid(1187420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187421, 1, "f68d1a4cd8391095e25686aa0cd28841d9eca752f93ab41633ccb08d47341330")
