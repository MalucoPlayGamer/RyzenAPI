-- Lua provided by RyzenAPI
-- Game: AppID 1187420

-- MAIN APPLICATION
addappid(1187420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187421, 1, "f68d1a4cd8391095e25686aa0cd28841d9eca752f93ab41633ccb08d47341330")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
