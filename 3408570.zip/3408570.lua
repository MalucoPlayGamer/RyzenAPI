-- Lua provided by RyzenAPI 
-- Game: Harmony Of Fear
addappid(3408570)
addappid(3408571, 1, "c70bfe0b7c52fb90fd7e465354417c4cbd1617494219c3a3150cfc2ec341e1ef")
