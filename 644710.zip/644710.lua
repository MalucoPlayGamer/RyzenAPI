-- Lua provided by RyzenAPI
-- Game: Gary Grigsby's War in the West

-- MAIN APPLICATION
addappid(644710)
addappid(644780)

-- MAIN APP DEPOTS / PACKAGES
addappid(644711, 1, "8b8c6a1d9a8eec1ff6d249f16cc5188a2a1a00ffd611009fcd20bab8f6c60b37")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
