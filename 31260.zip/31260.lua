-- Lua provided by RyzenAPI
-- Game: Sam & Max 305: The City that Dares not Sleep

-- MAIN APPLICATION
addappid(31260)

-- MAIN APP DEPOTS / PACKAGES
addappid(31261, 1, "d0735c8ed6663a95456edbbe784031c88c1a6db9bf5a87e2543e81e8dbce872f")
addappid(31262, 1, "e2ad0ce4bf093212cd75ac8da88a94185c7e388eb9b18e3dc4dd857f5154a423")
