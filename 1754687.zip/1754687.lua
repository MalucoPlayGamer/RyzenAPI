-- Lua provided by RyzenAPI
-- Game: addappid(1754687)

-- MAIN APPLICATION
addappid(1754687)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754687,0,"d2234ecbeb4b503ae106df5680d0c6c613b421027bade9352299d6dc6fe432ca")
