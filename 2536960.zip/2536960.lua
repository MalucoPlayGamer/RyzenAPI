-- Lua provided by RyzenAPI
-- Game: Shadowveil: Legend of The Five Rings

-- MAIN APPLICATION
addappid(2536960)
-- Game: addappid(2536960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536961, 1, "3df080decc628928621080b03652e6b736eb4d35e609da5e4d94a2c8877c5457")
addappid(3555070, 0, "17d516b829c95ccfb54a8690e24c515e629bb475b04a081ac04ccc774bd7a61b")
addappid(3555080, 0, "56ba79018bfed9302183ec1fec3e9893a85faaeb61f02895d9037650586155e3")
