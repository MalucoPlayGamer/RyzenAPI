-- Lua provided by RyzenAPI
-- Game: Shadowveil: Legend of The Five Rings

-- MAIN APPLICATION
addappid(2536960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536961, 1, "3df080decc628928621080b03652e6b736eb4d35e609da5e4d94a2c8877c5457")
addappid(3555070, 0, "17d516b829c95ccfb54a8690e24c515e629bb475b04a081ac04ccc774bd7a61b")
addappid(3555080, 0, "56ba79018bfed9302183ec1fec3e9893a85faaeb61f02895d9037650586155e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
