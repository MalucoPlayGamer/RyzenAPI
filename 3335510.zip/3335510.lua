-- Lua provided by RyzenAPI
-- Game: Limbot

-- MAIN APPLICATION
addappid(3335510) -- Limbot

-- MAIN APP DEPOTS / PACKAGES
addappid(3335511, 1, "55008ecb57989e62a3f9894c17cdd55d0bb306d8e4bcd3564495b4e6be53e004") -- Depot 3335511

