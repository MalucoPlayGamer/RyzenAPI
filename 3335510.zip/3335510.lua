-- 3335510's Lua and Manifest Created by Hubcap Manifest
-- Limbot
-- Created: August 12, 2026 at 22:55:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3335510) -- Limbot
-- MAIN APP DEPOTS
addappid(3335511, 1, "55008ecb57989e62a3f9894c17cdd55d0bb306d8e4bcd3564495b4e6be53e004") -- Depot 3335511
setManifestid(3335511, "5364463288890167235", 1761871056)