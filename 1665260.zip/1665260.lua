-- Lua provided by RyzenAPI
-- Game: addappid(1665260)

-- MAIN APPLICATION
addappid(1665260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665261, 1, "2d282dcf2b6b84a1648f47c8b407ee2865753cf58b6e5645230c1215cbf3970f")
