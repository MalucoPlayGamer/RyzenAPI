-- Lua provided by RyzenAPI
-- Game: addappid(556060)

-- MAIN APPLICATION
addappid(556060)

-- MAIN APP DEPOTS / PACKAGES
addappid(556061, 1, "0065df6d2cdfee24db38d42d3c2c45147ecd33a8bbe3d257e698db346ce28860")
