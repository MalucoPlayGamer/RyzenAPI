-- Lua provided by RyzenAPI
-- Game: Detective Gallo

-- MAIN APPLICATION
addappid(556060)
addappid(1980290)
addappid(1980320)
addappid(1980340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(556061, 1, "0065df6d2cdfee24db38d42d3c2c45147ecd33a8bbe3d257e698db346ce28860")

