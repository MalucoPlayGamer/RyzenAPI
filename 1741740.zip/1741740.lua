-- Lua provided by RyzenAPI 
-- Game: Eternal Warfare Demo
addappid(1741740)
addappid(1741741, 1, "f071a5e307a7cad44c760c0165b2d75207ba7e841b94e5b549cf3af42d694a50")
