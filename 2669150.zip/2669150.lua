-- Lua provided by RyzenAPI
-- Game: Mindlock - The Apartment

-- MAIN APPLICATION
addappid(2669150)
-- Game: addappid(2669150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669152,0,"942f719ef077b28da08ede695bf551f7a189e17e6cd4fe171223fab07cb5c304")
