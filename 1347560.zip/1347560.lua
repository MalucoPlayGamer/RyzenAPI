-- Lua provided by RyzenAPI
-- Game: Let Bions Be Bygones

-- MAIN APPLICATION
addappid(1347560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347563,0,"b277df466d6f13b25517d52833231d9f178ef00a04d62d55c0496d9efc97762b")

