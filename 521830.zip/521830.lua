-- Lua provided by RyzenAPI
-- Game: 521830

-- MAIN APPLICATION
addappid(521830)
-- Game: addappid(521830)

-- MAIN APP DEPOTS / PACKAGES
addappid(521831, 1, "7f66a658e44abf47e8614f51abad0dd73e698bf14c2b82a77c048710cad0ff8a")
