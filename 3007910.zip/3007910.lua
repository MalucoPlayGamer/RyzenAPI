-- Lua provided by RyzenAPI 
-- Game: SHADOW MANSION
addappid(3007910)
addappid(3007911, 1, "93097f5c64212cd558754ac356b760a7e87276fcc0d8edc7c1d324b81689c530")
