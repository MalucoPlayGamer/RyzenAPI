-- Lua provided by RyzenAPI
-- Game: SHADOW MANSION

-- MAIN APPLICATION
addappid(3007910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3007911, 1, "93097f5c64212cd558754ac356b760a7e87276fcc0d8edc7c1d324b81689c530")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
