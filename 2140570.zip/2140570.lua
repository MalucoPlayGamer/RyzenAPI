-- Lua provided by RyzenAPI
-- Game: Time Is Honey

-- MAIN APPLICATION
addappid(2140570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140572,0,"3c5d5fc59d344b6066d774153652f9a9b63eb4a2a40c87068ab517a50a000c7d")

