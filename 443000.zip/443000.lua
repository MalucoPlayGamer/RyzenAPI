-- Lua provided by RyzenAPI
-- Game: addappid(443000)

-- MAIN APPLICATION
addappid(443000)

-- MAIN APP DEPOTS / PACKAGES
addappid(443002,0,"d9231dc4a12f8e5de5dc5e0116129d8a019c716178877ddcfff1ae25825d3b2f")
