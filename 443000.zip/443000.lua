-- Lua provided by RyzenAPI
-- Game: DUAL GEAR

-- MAIN APPLICATION
addappid(443000)

-- MAIN APP DEPOTS / PACKAGES
addappid(443002,0,"d9231dc4a12f8e5de5dc5e0116129d8a019c716178877ddcfff1ae25825d3b2f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
