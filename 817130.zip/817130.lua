-- Lua provided by RyzenAPI
-- Game: WWE 2K19

-- MAIN APPLICATION
addappid(817130)
addappid(884870)
addappid(943830)
addappid(943831)
addappid(943840)
addappid(943841)
addappid(943842)
addappid(943843)
addappid(943844)
-- Game: addappid(817130)

-- MAIN APP DEPOTS / PACKAGES
addappid(817131, 1, "a197fc330ad99ddec4701ceafbb425522193aface6f72253286e7dc8d18bf995")
