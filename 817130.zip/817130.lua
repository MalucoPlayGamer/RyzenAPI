-- Lua provided by RyzenAPI
-- Game: WWE 2K19

-- MAIN APPLICATION
addappid(817130)
addappid(884870)
addappid(943830)
addappid(943831)
addappid(943840)
addappid(943841)
addappid(943842)
addappid(943843)
addappid(943844)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(817131, 1, "a197fc330ad99ddec4701ceafbb425522193aface6f72253286e7dc8d18bf995")

