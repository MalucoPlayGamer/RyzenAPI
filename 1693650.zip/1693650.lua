-- Lua provided by RyzenAPI 
-- Game: COPPER ODYSSEY
addappid(1693650)
addappid(1693651, 1, "773061810de2612f299c29989cfd4e4ed87308a7f542ff71f5766d1c051051d9")
