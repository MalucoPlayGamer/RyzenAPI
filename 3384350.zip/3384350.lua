-- Lua provided by RyzenAPI
-- Game: 3384350

-- MAIN APPLICATION
addappid(3384350)
-- Game: addappid(3384350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3384351, 1, "84a8d639ffccb2557f8b2acac092f6d007ff660c84c040612234c36ec6323809")
