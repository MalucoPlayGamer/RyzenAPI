-- Lua provided by RyzenAPI
-- Game: Game: PACIFICATION LIGHT

-- MAIN APPLICATION
addappid(3025820)
-- Game: addappid(3025820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025821, 1, "22ebc8eb0d3127d5bbe6d63b736755bbb34ba7fde1c5ceae44d26ff386fbdd0a")
