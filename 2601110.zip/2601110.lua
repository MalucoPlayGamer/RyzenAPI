-- Lua provided by RyzenAPI
-- Game: CheckOut

-- MAIN APPLICATION
addappid(2601110)
-- Game: addappid(2601110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601111, 1, "a3acb90b0574ff04dd072130d1978722178267426c9abb676ea418de6344fd45")
