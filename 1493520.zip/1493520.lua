-- Lua provided by RyzenAPI
-- Game: Game: Beat Hazard 3

-- MAIN APPLICATION
addappid(1493520)
-- Game: addappid(1493520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493521, 1, "771a115ee311d564b716046e3c28e507f053d9b9296618370bad24abf6c70793")
