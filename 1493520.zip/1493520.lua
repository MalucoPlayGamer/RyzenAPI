-- Lua provided by RyzenAPI
-- Game: Beat Hazard 3

-- MAIN APPLICATION
addappid(1493520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493521, 1, "771a115ee311d564b716046e3c28e507f053d9b9296618370bad24abf6c70793")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
