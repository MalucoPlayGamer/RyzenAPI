-- Lua provided by RyzenAPI
-- Game: Hollowreach - Alone

-- MAIN APPLICATION
addappid(4162580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4162581,0,"b1b72ea0f2cb57694a92d40982280a131cb8f8033e978c3a3aab5f6648ffcb7f")

