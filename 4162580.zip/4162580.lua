-- Lua provided by RyzenAPI
-- Game: Hollowreach - Alone

-- MAIN APPLICATION
addappid(4162580)

-- MAIN APP DEPOTS / PACKAGES
addappid(4162581,0,"b1b72ea0f2cb57694a92d40982280a131cb8f8033e978c3a3aab5f6648ffcb7f")

