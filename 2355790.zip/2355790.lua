-- Lua provided by RyzenAPI
-- Game: addappid(2355790)

-- MAIN APPLICATION
addappid(2355790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355791, 1, "21266cc1407e2d5d36c62280ea8f36cbf416e591ae8be38bdd260d3ac48adc62")
