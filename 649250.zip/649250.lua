-- Lua provided by RyzenAPI
-- Game: addappid(649250)

-- MAIN APPLICATION
addappid(649250)

-- MAIN APP DEPOTS / PACKAGES
addappid(582551,0,"119e2cd14812bb2be5863809284cce653590f676840b6919a68cdda5bd7f24fe")
