-- Lua provided by RyzenAPI
-- Game: Bronze Age

-- MAIN APPLICATION
addappid(686900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(686901, 1, "4a06ea53252cd175155a161a767e41d1fcc9332c7ccc113143c4ba33e4ce70d0")
addappid(686902, 1, "19eb833b044a2e54ed1794a74fca47fb1606b489f0d07a1bdc2ca01e59c4585a")
addappid(686903, 1, "f0ba77681fe2dfd7e2ca38c75de81a4bcc021b7333e73e24bd3053ce222f0de9")
addappid(686904, 1, "2f63b3c9d0fd3575c97a7b75fc2f0eb9676251ee2b749ec88bf31c64b0ffbe24")

