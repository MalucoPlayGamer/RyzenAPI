-- Lua provided by RyzenAPI
-- Game: Double Dragon IV

-- MAIN APPLICATION
addappid(528610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(528611, 1, "427a39a22d14f155db7495f9375bb374246a14730324220867bf5cf9ca34bc75")

