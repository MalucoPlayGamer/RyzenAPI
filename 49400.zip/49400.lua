-- Lua provided by RyzenAPI
-- Game: addappid(49400)

-- MAIN APPLICATION
addappid(49400)

-- MAIN APP DEPOTS / PACKAGES
addappid(49401, 1, "57995a09a784dd36b00ae71266597737af32a4d44256f3c81f98f6d4fcda5675")
