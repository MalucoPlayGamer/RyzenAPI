-- Lua provided by RyzenAPI
-- Game: AppID 49400

-- MAIN APPLICATION
addappid(49400)

-- MAIN APP DEPOTS / PACKAGES
addappid(49401, 1, "57995a09a784dd36b00ae71266597737af32a4d44256f3c81f98f6d4fcda5675")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(49402)
addappid(49403)
addappid(49404)
addappid(49406)
addappid(49407)
addappid(49408)
addappid(49409)
addappid(49410)
addappid(49411)
addappid(49412)
addappid(49413)
addappid(49414)
addappid(49415)
addappid(49416)
addappid(49417)
addappid(49418)
addappid(49419)
addappid(49421)
addappid(49422)
addappid(49423)
addappid(49424)
addappid(49425)
addappid(49426)
addappid(49427)
addappid(49428)
addappid(49429)
addappid(49430)
addappid(49431)
addappid(49432)
addappid(49433)
addappid(49434)
addappid(49435)
addappid(49436)
addappid(49437)
addappid(49438)
addappid(49439)
addappid(49440)
addappid(49441)
addappid(49442)
addappid(49443)
