-- Lua provided by RyzenAPI
-- Game: Wanda - A Beautiful Apocalypse

-- MAIN APPLICATION
addappid(386490)
addappid(497930)

-- MAIN APP DEPOTS / PACKAGES
addappid(386491, 1, "c1cf9fe9bcd94d927d60783b7f196e51218f27f79879a338abb9bd9a36416e62")

