-- Lua provided by RyzenAPI
-- Game: Crude Hearts

-- MAIN APPLICATION
addappid(4741860) -- Crude Hearts

-- MAIN APP DEPOTS / PACKAGES
addappid(4741861, 1, "4d789ab56ac8465e74e7c684244ed03dcb8a4567a1acfa642e435fb3603555bb") -- Depot 4741861
addappid(4741862, 1, "be59a881358cbdde8a6f9fc9286136634b9d25f8dd9d3e7a513f107191bf3e0d") -- Depot 4741862

