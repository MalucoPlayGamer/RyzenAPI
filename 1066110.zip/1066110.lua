-- Lua provided by RyzenAPI
-- Game: Game: AppID 1066110

-- MAIN APPLICATION
addappid(1066110)
-- Game: addappid(1066110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066111, 1, "254ef638f159d516ebe5d33c3b10947d76e5380ff2e830dfb4c45b9f2c1dbe89")
