-- Lua provided by RyzenAPI
-- Game: Operation Lovecraft: Fallen Doll Demo

-- MAIN APPLICATION
addappid(1811180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811181, 1, "37fc3f39a60d7980d1bc0397021f0dcce4ba59dc456c0cb42ed6c3eda53e7b13")
