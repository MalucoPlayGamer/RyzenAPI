-- Lua provided by RyzenAPI
-- Game: 2175430

-- MAIN APPLICATION
addappid(2175430)
-- Game: addappid(2175430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175431, 1, "c5071bb3d2adf290d82f2ecfac819c08c549c2f622595028c6eeedae4b0ea7d6")
