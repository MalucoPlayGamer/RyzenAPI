-- Lua provided by RyzenAPI
-- Game: Barrage

-- MAIN APPLICATION
addappid(2879570)
addappid(2940090)
addappid(3037220)
addappid(3037230)
addappid(3154370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879571, 1, "f5db8d8abacffeb4128ea60446b82daa6b2710961d872a56ef702a5b1d17fec1")

