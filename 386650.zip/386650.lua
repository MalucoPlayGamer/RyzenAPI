-- Lua provided by RyzenAPI
-- Game: addappid(386650)

-- MAIN APPLICATION
addappid(228983)
addappid(228986)
addappid(228990)
addappid(229004)
addappid(386650)
addappid(386651)
addappid(386654)

-- MAIN APP DEPOTS / PACKAGES
addappid(386653,0,"415e7ca25c2a5064956297876eeee52932baaff2f2af7c239d473bdd482f51e9")
