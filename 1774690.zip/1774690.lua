-- Lua provided by SkyAPI 
-- Game: AppID 1774690
addappid(1774690)
addappid(1774691, 1, "ce9f122a134c1168b4dcf1884f4c93453c4e1968c9160b3fe3c6125d50675780")
