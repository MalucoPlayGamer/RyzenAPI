-- Lua provided by RyzenAPI
-- Game: Game: AppID 1774690

-- MAIN APPLICATION
addappid(1774690)
-- Game: addappid(1774690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774691, 1, "ce9f122a134c1168b4dcf1884f4c93453c4e1968c9160b3fe3c6125d50675780")
