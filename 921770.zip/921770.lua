-- Lua provided by RyzenAPI
-- Game: AppID 921770

-- MAIN APPLICATION
addappid(921770)
-- Game: addappid(921770)

-- MAIN APP DEPOTS / PACKAGES
addappid(921771, 1, "37453a78822feea6740720f68cf1d6e62ee209b7584270383bff424b7efe1a72")
