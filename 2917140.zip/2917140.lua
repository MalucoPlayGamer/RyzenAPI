-- Lua provided by RyzenAPI
-- Game: Game: Bored Wife

-- MAIN APPLICATION
addappid(2917140)
-- Game: addappid(2917140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2917141, 1, "5a02d862179259627ff48210ff71bdc6c6ae484af8a7acd12783a63a2edadbcb")
