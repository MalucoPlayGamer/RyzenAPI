-- Lua provided by RyzenAPI 
-- Game: Pogglewash
addappid(2417620)
addappid(2417621, 1, "00e5e3b82d4d43dc7735b66f002a3cb1cdd31168403a292a46556d282e69396a")
