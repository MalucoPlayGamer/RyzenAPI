-- Lua provided by RyzenAPI
-- Game: 2182660

-- MAIN APPLICATION
addappid(2182660)
-- Game: addappid(2182660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182660,0,"48a3cb3242a629b4587baa6bac5b863b93952d8ee1d42328ba44682cf84aec1a")
