-- Lua provided by RyzenAPI 
-- Game: AppID 1179780
addappid(1179780)
addappid(1179781, 1, "a44275467a626a1f36f74248ba6e4e7b6966a78b218ac64b8438c0173f476d23")
