-- Lua provided by RyzenAPI
-- Game: addappid(555160)

-- MAIN APPLICATION
addappid(555160)

-- MAIN APP DEPOTS / PACKAGES
addappid(555161, 1, "a735c234a21b56c19d12783ed863a989479bace230efa2b8dc0c7098c99706eb")
