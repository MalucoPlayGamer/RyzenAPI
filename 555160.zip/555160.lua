-- Lua provided by SkyAPI 
-- Game: Pavlov
addappid(555160)
addappid(555161, 1, "a735c234a21b56c19d12783ed863a989479bace230efa2b8dc0c7098c99706eb")
