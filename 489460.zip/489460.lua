-- Lua provided by RyzenAPI
-- Game: The Last Leviathan

-- MAIN APPLICATION
addappid(489460)

-- MAIN APP DEPOTS / PACKAGES
addappid(489461, 1, "5f6328309271f63c62f353f64691f945ddb0256d645f2940740c6a6566ffd80b")
addappid(489462, 1, "34129f1e0dfd25d28cba93bfdaf742baa93ca74b8e6087a46689746544d21bea")
addappid(489463, 1, "ed1320c9980ebd918985196dcdc415012b9e81300e7397639b251e364e44fa15")
addappid(489464, 1, "4c1ad290c8f5e83a66c53d3f875d16823a700d181c17ba955049b4e43b8b6f2d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(524950)
addappid(585470)
addappid(585471)
addappid(585472)
