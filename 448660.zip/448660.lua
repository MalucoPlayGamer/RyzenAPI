-- Lua provided by RyzenAPI
-- Game: Shake Your Money Simulator 2016

-- MAIN APPLICATION
addappid(448660)

-- MAIN APP DEPOTS / PACKAGES
addappid(448661, 1, "73fba6b7144e9ac9c5131f738a6e8e36e3e45f8c60bc98f01200964a47683d84")
