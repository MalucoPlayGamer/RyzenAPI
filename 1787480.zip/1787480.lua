-- Lua provided by RyzenAPI
-- Game: Game: Metro Simulator 2

-- MAIN APPLICATION
addappid(1787480)
-- Game: addappid(1787480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787481, 1, "2bc8ec13f9484951f947990bd0dad9caf53b336a0b7c23da0d7fc17becedd78a")
