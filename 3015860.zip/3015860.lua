-- Lua provided by RyzenAPI
-- Game: BACKROOMS THE COMPANY

-- MAIN APPLICATION
addappid(3015860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015861, 1, "eac83fcf62b2fe4e99dad9f66d4105a5000472a2ed5342993b9f9f5c53095015")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
