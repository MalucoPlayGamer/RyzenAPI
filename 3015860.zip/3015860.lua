-- Lua provided by RyzenAPI
-- Game: addappid(3015860)

-- MAIN APPLICATION
addappid(3015860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015861, 1, "eac83fcf62b2fe4e99dad9f66d4105a5000472a2ed5342993b9f9f5c53095015")
