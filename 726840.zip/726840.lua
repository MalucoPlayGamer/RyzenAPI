-- Lua provided by RyzenAPI
-- Game: AppID 726840

-- MAIN APPLICATION
addappid(726840)
addappid(2893100)

-- MAIN APP DEPOTS / PACKAGES
addappid(726841, 1, "eb838de9f804f1b700891f70e0606e30fcaae0c6e180c653396bb478f37bb98b")
addappid(726842, 1, "2d308a50e5eeba5e71eec2712fcb79c7274c3f02b35369d56b1be67a1d5f8a61")
addappid(726843, 1, "fd3c00aaff43436ad2c4f903f09068ad5ec63e70a3fa90814ccb2d52ed0630f3")
addappid(726844, 1, "cbe477aab7ce09bfebf6c5c4096023b76e4bb51a8599feea893c80eaaa51de71")

