-- Lua provided by RyzenAPI
-- Game: Prison Princess

-- MAIN APPLICATION
addappid(1151740)
-- Game: addappid(1151740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151741, 1, "7ea2b1b1007d5cf1b881ffc3ddc16573d52bc0593ea8276241621f892d0e752c")
