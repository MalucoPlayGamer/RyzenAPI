-- Lua provided by SkyAPI 
-- Game: Prison Princess
addappid(1151740)
addappid(1151741, 1, "7ea2b1b1007d5cf1b881ffc3ddc16573d52bc0593ea8276241621f892d0e752c")
