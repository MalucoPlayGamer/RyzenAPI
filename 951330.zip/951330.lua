-- Lua provided by RyzenAPI
-- Game: Weaponry Dealer VR

-- MAIN APPLICATION
addappid(951330)

-- MAIN APP DEPOTS / PACKAGES
addappid(951331, 1, "1f03db359b0795dfa6426845f3e4151db1ca5fecff010b5764ee24e47755e863")

