-- Lua provided by RyzenAPI
-- Game: AppID 1089140

-- MAIN APPLICATION
addappid(1089140)
-- Game: addappid(1089140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089141, 1, "c69d38b25a6d5bcbd0cec67e8fe246916f25bd1baddf3e633ece6a4a1d9b5316")
