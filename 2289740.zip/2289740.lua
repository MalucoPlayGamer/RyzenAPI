-- Lua provided by SkyAPI 
-- Game: Power Sink
addappid(2289740)
addappid(2289741, 1, "f7e748078db0ef2c3387882150f5bfe63e118e8ee01c53477c47767b4342893b")
