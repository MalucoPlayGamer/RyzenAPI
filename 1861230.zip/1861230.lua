-- Lua provided by RyzenAPI
-- Game: addappid(1861230)

-- MAIN APPLICATION
addappid(1861230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861231, 1, "7ed15e544b2aa6ef34b368d253fc47990fa6c15df22ed192f895a8b59d2e4ca6")
