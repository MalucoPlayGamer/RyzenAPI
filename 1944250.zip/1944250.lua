-- Lua provided by RyzenAPI
-- Game: Hana no No ni Saku Utakata no

-- MAIN APPLICATION
addappid(1944250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1944251, 1, "ec8d09819af8bf8d2a6cc385070112d407619f36fcb03fac356c279e8e9c9b58")
addappid(1944252, 1, "68daf0afbb421b9e300df340075378504fdf7711b5e6169ea29c50953c320f3b")
addappid(1944253, 1, "bf9d8a5a1e041873958e9f7fe41092c6a7315bd46133609e1d5e8bcccfe14c1d")

