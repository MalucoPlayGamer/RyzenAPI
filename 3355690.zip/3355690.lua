-- Lua provided by RyzenAPI
-- Game: Hamachi the Psychotic Killer

-- MAIN APPLICATION
addappid(3355690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3355691,0,"1af8d5f7c79dab7fc208c033fde0d6293bd1994166d3fe4a745a9359f5c703d6")

