-- Lua provided by RyzenAPI
-- Game: Love at Work

-- MAIN APPLICATION
addappid(3883970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3883971,0,"48da3481435110927ccc6bb427fd01207bd386f1331d8a66dd43db4abfdfd9b9")
addappid(4880070,0,"29f201c4a0b23a55938ba5b2bd6e2604c09e3be52ca8f7383db8d846fd624d54")

