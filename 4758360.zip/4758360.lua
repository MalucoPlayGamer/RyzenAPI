-- 4758360's Lua and Manifest Created by Hubcap Manifest
-- Escape The Sex Room
-- Created: July 26, 2026 at 03:41:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4758360) -- Escape The Sex Room
-- MAIN APP DEPOTS
addappid(4758361, 1, "f9e58d5cd76059501ba680017781787e8ad6182bdac9e992b7cc5d86f6ad5960") -- Depot 4758361
setManifestid(4758361, "6971981340285600220", 1636756043)