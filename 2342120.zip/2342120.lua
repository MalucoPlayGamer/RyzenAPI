-- Lua provided by RyzenAPI
-- Game: Ultimate Anime Jigsaw Puzzle - Artwork

-- MAIN APPLICATION
addappid(2342120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342120,0,"49db108ba80019d9a427bb41d1cf310710920390c45f5687fd1dfd69e96b710e")

