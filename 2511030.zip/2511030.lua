-- Lua provided by RyzenAPI 
-- Game: AppID 2511030
addappid(2511030)
addappid(2511031, 1, "52f722560e8bfa23310435d27bbdcec2cd6767608af72b3211ef229a4f42bf80")
addappid(2543580, 0, "6e9820384091b21822d609f1262716f44b63efda6ba77526ddf3f1f07fec6fb6")
