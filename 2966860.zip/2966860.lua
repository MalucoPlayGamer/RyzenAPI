-- Lua provided by RyzenAPI
-- Game: Shotgun Cop Man Soundtrack

-- MAIN APPLICATION
addappid(2966860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2966861, 1, "32ca75cf20771093f293eae70bba0e660c3c16bdfff60f1e53283c0fb121c8df")
addappid(2966862, 1, "2545f1dbbe942a462d37388600eacd7cf6207425d6b8042d04651ac9cc02faf3")

