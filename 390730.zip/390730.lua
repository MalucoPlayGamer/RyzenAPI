-- Lua provided by RyzenAPI
-- Game: Sora

-- MAIN APPLICATION
addappid(390730)

-- MAIN APP DEPOTS / PACKAGES
addappid(390731, 1, "e4cef77f5906672b01fbc6716d4dd386b821f139fb3cae2a82ed427dffbc1e80")
addappid(390732, 1, "def5423043236dd2a01f75fab2245d8dde23c2ca5ba22afe58044065fce68524")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
