-- Lua provided by RyzenAPI
-- Game: 1659470

-- MAIN APPLICATION
addappid(1659470)
-- Game: addappid(1659470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659471, 1, "f5759e2a6ef3b6a39145b1f8665c880675ed520792f02ef5ffc75d3c4d854fff")
