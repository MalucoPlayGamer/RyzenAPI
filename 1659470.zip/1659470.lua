-- Lua provided by SkyAPI 
-- Game: Mouse Hunter
addappid(1659470)
addappid(1659471, 1, "f5759e2a6ef3b6a39145b1f8665c880675ed520792f02ef5ffc75d3c4d854fff")
