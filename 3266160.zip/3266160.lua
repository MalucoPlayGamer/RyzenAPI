-- Lua provided by RyzenAPI
-- Game: Don't Be Afraid 2 Demo

-- MAIN APPLICATION
addappid(3266160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3266161, 1, "d7a5482fd4db4b65bba2ea6a8982e28e4dda2aff5f52ff2c67d86709dd515e4d")

