-- Lua provided by SkyAPI 
-- Game: AppID 3266160
addappid(3266160)
addappid(3266161, 1, "d7a5482fd4db4b65bba2ea6a8982e28e4dda2aff5f52ff2c67d86709dd515e4d")
