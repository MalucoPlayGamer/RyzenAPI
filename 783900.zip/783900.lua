-- Lua provided by RyzenAPI
-- Game: AppID 783900

-- MAIN APPLICATION
addappid(783900)
-- Game: addappid(783900)

-- MAIN APP DEPOTS / PACKAGES
addappid(783901, 1, "cfcdbe8104113506d0b67a678685c39530624be4be71b603d62d60ffd9598021")
