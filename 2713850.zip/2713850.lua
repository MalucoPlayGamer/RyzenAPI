-- Lua provided by RyzenAPI 
-- Game: Birdminton Demo
addappid(2713850)
addappid(2713851, 1, "5312463fb6b48cc3f2f003958f8b1e2516e3d0da9e6bdfc9abb6193883b228f1")
