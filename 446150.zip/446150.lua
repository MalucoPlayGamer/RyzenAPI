-- Lua provided by RyzenAPI
-- Game: 446150

-- MAIN APPLICATION
addappid(446150)
-- Game: addappid(446150)

-- MAIN APP DEPOTS / PACKAGES
addappid(446151, 1, "e81e1bf415f4601dea4c1b97c0dec23dd5fee18725fd0ffb9ae27f9276f4ea9f")
