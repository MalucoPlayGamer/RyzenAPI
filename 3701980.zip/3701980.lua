-- Lua provided by RyzenAPI
-- Game: 3701980

-- MAIN APPLICATION
addappid(3701980)
-- Game: addappid(3701980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3701981, 1, "51d9ce7429c3ae55dfecc2eb2afeb65994a6a3f37f89044e7e75544f608544d5")
