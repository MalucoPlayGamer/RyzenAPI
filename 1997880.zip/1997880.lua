-- Lua provided by RyzenAPI
-- Game: Lawnmower game: Mortal Race

-- MAIN APPLICATION
addappid(1997880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997881,0,"ba5916bf4b5a1ff85685bba6f2c23307fabf80401407f6164e57fb810d4328c8")

