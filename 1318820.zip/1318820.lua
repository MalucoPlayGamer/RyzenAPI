-- Lua provided by RyzenAPI
-- Game: Cyberpulse

-- MAIN APPLICATION
addappid(1318820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318822,0,"521ec324819dbdf30e4f30c0f0beb35a1d8074627a72fbfa8cd54efd7b8eb4e1")

