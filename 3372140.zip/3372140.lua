-- Lua provided by RyzenAPI
-- Game: addappid(3372140)

-- MAIN APPLICATION
addappid(3372140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372141, 1, "513af8190bf391deab1b5c9c07b2801e515a4218a4b453e0a998a33597bbce8e")
