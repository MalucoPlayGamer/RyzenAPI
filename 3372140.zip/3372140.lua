-- Lua provided by SkyAPI 
-- Game: FINAL FANTASY XIII Original Soundtrack
addappid(3372140)
addappid(3372141, 1, "513af8190bf391deab1b5c9c07b2801e515a4218a4b453e0a998a33597bbce8e")
