-- Lua provided by RyzenAPI
-- Game: Octogeddon

-- MAIN APPLICATION
addappid(525620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(525621, 1, "57a26d40ffc979d8e5ca00a87092de66da7f2adc6f767e21c697ab53ce6c3def")

