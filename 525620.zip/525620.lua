-- Lua provided by RyzenAPI
-- Game: addappid(525620)

-- MAIN APPLICATION
addappid(525620)

-- MAIN APP DEPOTS / PACKAGES
addappid(525621, 1, "57a26d40ffc979d8e5ca00a87092de66da7f2adc6f767e21c697ab53ce6c3def")
