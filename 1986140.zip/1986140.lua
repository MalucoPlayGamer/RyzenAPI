-- Lua provided by SkyAPI 
-- Game: Last Time I Saw You - Demo
addappid(1986140)
addappid(1986141, 1, "79e27324356ad726ab2dd47c9012eb4e6cd5e92b91c10f3096dcc2131901007b")
