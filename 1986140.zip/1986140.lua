-- Lua provided by RyzenAPI
-- Game: 1986140

-- MAIN APPLICATION
addappid(1986140)
-- Game: addappid(1986140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986141, 1, "79e27324356ad726ab2dd47c9012eb4e6cd5e92b91c10f3096dcc2131901007b")
