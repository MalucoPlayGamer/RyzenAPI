-- Lua provided by RyzenAPI
-- Game: [Chilla's Art] The Closing Shift | 閉店事件

-- MAIN APPLICATION
addappid(1843090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843091, 1, "c1a0c39274653d2d932e3db799364b4ca717df8f9bd2994d75615a6b42602a10")

