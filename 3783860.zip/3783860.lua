-- Lua provided by RyzenAPI
-- Game: Anime Dream Match: Cats

-- MAIN APPLICATION
addappid(3783860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3783861, 1, "67d8537140f48f506d0788659945d4d66b0cf671a11b6f0beb18642c758b6f8c")
