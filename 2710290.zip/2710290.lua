-- Lua provided by RyzenAPI
-- Game: 2710290

-- MAIN APPLICATION
addappid(2710290)
-- Game: addappid(2710290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710291, 1, "8dea57f092375a1a8006b9ff56e0dab2ed281f50709d4db786a34a5188c767a8")
