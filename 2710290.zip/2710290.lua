-- Lua provided by RyzenAPI
-- Game: G WARRIOR

-- MAIN APPLICATION
addappid(2710290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2710291, 1, "8dea57f092375a1a8006b9ff56e0dab2ed281f50709d4db786a34a5188c767a8")
