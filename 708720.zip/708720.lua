-- Lua provided by RyzenAPI
-- Game: GridIron

-- MAIN APPLICATION
addappid(708720)
addappid(1977680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(708721, 1, "7fcfb0b21b6298fd795c78b1a435b83b6652c844176358574ba1ad53c43cceed")
addappid(708722, 1, "e3fe8ecc2f7b1f655b6ffd1bff89e7e0061e158790bd09e29f09b61e64e4f62a")

