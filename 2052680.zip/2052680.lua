-- Lua provided by RyzenAPI
-- Game: Game: Colorful Recolor

-- MAIN APPLICATION
addappid(2052680)
-- Game: addappid(2052680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052681, 1, "66d326010c5662b7915eaba1f2ba84d7914c66c7be0846bd2a83e7762acb8d7e")
