-- Lua provided by RyzenAPI
-- Game: Homam: An Inventor's Fist

-- MAIN APPLICATION
addappid(3150690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3150691, 1, "564a81c1266a78ad54f7c2c35b73ff94e4f985325c62bc484409231856ee5e2c")

