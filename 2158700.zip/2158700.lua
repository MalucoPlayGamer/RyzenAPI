-- Lua provided by RyzenAPI
-- Game: AppID 2158700

-- MAIN APPLICATION
addappid(2158700)
-- Game: addappid(2158700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158701, 1, "adff4094c63d1e84c4e882dc17a2f3d988fbaab3385a302838fad7a8a69651c3")
