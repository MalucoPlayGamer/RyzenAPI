-- Lua provided by RyzenAPI
-- Game: ISOLAND3: Dust of the Universe

-- MAIN APPLICATION
addappid(1249010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249011, 1, "68099763b13aa13173238b597e29583d5b9c6667d94e08744f3bcd2c92e3db86")
