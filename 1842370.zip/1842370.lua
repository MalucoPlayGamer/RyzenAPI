-- Lua provided by RyzenAPI
-- Game: Milf Puzzle

-- MAIN APPLICATION
addappid(1842370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842371, 1, "de477829bae159f94b907f1b226378640b7eac42979e868e0c7e83f643df6821")

