-- Lua provided by SkyAPI 
-- Game: AppID 1375530
addappid(1375530)
addappid(1375531, 1, "d0008939b335a092e1fb66bf1b75900801d8a25d77614d90d1c7472660d8325d")
