-- Lua provided by RyzenAPI
-- Game: 814540

-- MAIN APPLICATION
addappid(814540)
-- Game: addappid(814540)

-- MAIN APP DEPOTS / PACKAGES
addappid(814541, 1, "d111c72dd7e3a7697654dcbb19a84e7b2e26e6968c9a8632335f8d652c144f06")
