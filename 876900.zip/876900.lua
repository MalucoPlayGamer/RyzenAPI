-- Lua provided by RyzenAPI 
-- Game: Climb
addappid(876900)
addappid(876901, 1, "15c8626750134cc248810e3601cb6708281c6467383b56461ee9110aa6817dad")
