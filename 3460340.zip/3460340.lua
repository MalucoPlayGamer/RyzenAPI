-- Lua provided by RyzenAPI
-- Game: 3460340

-- MAIN APPLICATION
addappid(3460340)
-- Game: addappid(3460340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460341, 1, "09c32bf874dd57ee4097caa1b351b63b0ec3f086d75d48bf6c55be8187046e7c")
