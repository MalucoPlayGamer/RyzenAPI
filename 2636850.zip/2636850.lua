-- Lua provided by RyzenAPI
-- Game: schoolLife_GuiYu

-- MAIN APPLICATION
addappid(2636850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636850,0,"3f2623abd0874b628cd5cf06cb5922eb4a95ed950ec619f217e905946f8e1910")

