-- Lua provided by RyzenAPI
-- Game: Battle Sister Leah Demo

-- MAIN APPLICATION
addappid(2922190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2922192,0,"bf3da3819afee30104117e810c1b8d46d48be799b17a5675bb80f6b5298ca9d6")
addappid(2922193,0,"b37c9f3e09cf11a96addfa9bcf8052571db712a7184455119b0d41b51495012a")

