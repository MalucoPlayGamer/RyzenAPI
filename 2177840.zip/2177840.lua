-- Lua provided by RyzenAPI
-- Game: Come Home - Adrian Clothing Expansion

-- MAIN APPLICATION
addappid(2177840)
-- Game: addappid(2177840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177841, 1, "083c0068672152f41873ce41b6db167b51f1f562184aad54d1e1402219e05ceb")
