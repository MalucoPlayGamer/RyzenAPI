-- Lua provided by RyzenAPI
-- Game: Love in Login Demo

-- MAIN APPLICATION
addappid(2758310)
-- Game: addappid(2758310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758311, 1, "5fe6d29e338f0a884ffe2c2a6d053f323bc623a35283287b7bdd7aab50be30a2")
