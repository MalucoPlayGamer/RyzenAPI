-- Lua provided by RyzenAPI
-- Game: 2969790

-- MAIN APPLICATION
addappid(2969790)
-- Game: addappid(2969790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969790,0,"c0a69d0c9e05defb48b0e969c9ee717f2c921f33cd823becff6a12c8708fcd0d")
