-- Lua provided by RyzenAPI
-- Game: Game: Need For Drink

-- MAIN APPLICATION
addappid(613730)
-- Game: addappid(613730)

-- MAIN APP DEPOTS / PACKAGES
addappid(613731, 1, "142a025e7162352d987dd1e02314ccb36d75ff6ea7a463673c604789a6d4b54f")
