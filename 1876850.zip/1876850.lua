-- Lua provided by SkyAPI 
-- Game: Babushka's Glitch Dungeon
addappid(1876850)
addappid(1876851, 1, "5e4a5c85e7f492961bfcfae46d26d68b0606204222358a8c4f9f54411140e18c")
