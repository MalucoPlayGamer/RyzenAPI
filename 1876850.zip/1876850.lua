-- Lua provided by RyzenAPI
-- Game: Babushka's Glitch Dungeon

-- MAIN APPLICATION
addappid(1876850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876851, 1, "5e4a5c85e7f492961bfcfae46d26d68b0606204222358a8c4f9f54411140e18c")
