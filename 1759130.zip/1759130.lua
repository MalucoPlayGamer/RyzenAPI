-- Lua provided by RyzenAPI
-- Game: Time Idle RPG

-- MAIN APPLICATION
addappid(1759130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759131, 1, "29f5fcd30d91932a0c57a5328c938483cb768fd74e96590c284afc9dd6e4e85a")

