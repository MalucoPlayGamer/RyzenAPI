-- Lua provided by RyzenAPI
-- Game: Game: IKEA VR Experience

-- MAIN APPLICATION
addappid(447270)
-- Game: addappid(447270)

-- MAIN APP DEPOTS / PACKAGES
addappid(447271, 1, "b7b2182a4287a29c792507a40f3e991eff6be2702cfa8346de9b253098cd9980")
