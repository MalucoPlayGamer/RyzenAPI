-- Lua provided by SkyAPI 
-- Game: IKEA VR Experience
addappid(447270)
addappid(447271, 1, "b7b2182a4287a29c792507a40f3e991eff6be2702cfa8346de9b253098cd9980")
