-- Lua provided by RyzenAPI
-- Game: 1591150

-- MAIN APPLICATION
addappid(1591150)
-- Game: addappid(1591150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591151, 1, "4582f48c259a5fc500fa23c6fa7ea95af584872053e0b4924e594bf983a20d65")
