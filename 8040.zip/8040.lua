-- Lua provided by RyzenAPI
-- Game: Championship Manager 2007

-- MAIN APPLICATION
addappid(8040)

-- MAIN APP DEPOTS / PACKAGES
addappid(8041, 1, "141cbc773b2fb740c19d416544348f38a068a4a0329de4732498d52ee4561337")
addappid(8042, 1, "5f87eddd5ad601f76cba060e2bb22eeb5375cac8ceb018f537636acee977513f")
addappid(8045, 1, "875057470188ec85cd0d2e338c690cd866754f6f1a8ac0fda0a5e5990f62e5b3")

