-- Lua provided by RyzenAPI
-- Game: Mekkablood: Quarry Assault

-- MAIN APPLICATION
addappid(3056270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056271, 1, "0a700a6c69869ea7df8393a83cb1d2e45e5f7ed0e56c12284970fc89df4f454a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
