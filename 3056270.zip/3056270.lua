-- Lua provided by RyzenAPI
-- Game: addappid(3056270)

-- MAIN APPLICATION
addappid(3056270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3056271, 1, "0a700a6c69869ea7df8393a83cb1d2e45e5f7ed0e56c12284970fc89df4f454a")
