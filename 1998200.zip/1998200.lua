-- Lua provided by RyzenAPI
-- Game: Game: God Edge

-- MAIN APPLICATION
addappid(1998200)
-- Game: addappid(1998200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998201, 1, "d007bca1299169ac6eb85ed56e1b57a3abce07cdb63b32119e11419227ffeaf7")
