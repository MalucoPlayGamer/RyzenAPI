-- Lua provided by RyzenAPI
-- Game: Pluto

-- MAIN APPLICATION
addappid(389980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(389981, 1, "ee51d47071d3e1740fd1b5e07f55032b3891a6a00c5a36314f2922679fc818fb")
