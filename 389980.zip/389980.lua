-- Lua provided by RyzenAPI
-- Game: 389980

-- MAIN APPLICATION
addappid(389980)
-- Game: addappid(389980)

-- MAIN APP DEPOTS / PACKAGES
addappid(389981, 1, "ee51d47071d3e1740fd1b5e07f55032b3891a6a00c5a36314f2922679fc818fb")
