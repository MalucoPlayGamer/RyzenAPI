-- Lua provided by RyzenAPI
-- Game: SuperImage Pro

-- MAIN APPLICATION
addappid(3115390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115391, 1, "48f204e64a70b0c425f7e812fa17cea89cc9e0c6cd75f7b35ba19584e5cd02e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
