-- Lua provided by RyzenAPI
-- Game: SuperImage Pro

-- MAIN APPLICATION
addappid(3115390)
-- Game: addappid(3115390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3115391, 1, "48f204e64a70b0c425f7e812fa17cea89cc9e0c6cd75f7b35ba19584e5cd02e2")
