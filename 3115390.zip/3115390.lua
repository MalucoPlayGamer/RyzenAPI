-- Lua provided by SkyAPI 
-- Game: SuperImage Pro
addappid(3115390)
addappid(3115391, 1, "48f204e64a70b0c425f7e812fa17cea89cc9e0c6cd75f7b35ba19584e5cd02e2")
