-- Lua provided by SkyAPI 
-- Game: The Quivering
addappid(345290)
addappid(345291, 1, "c5eab6f9635a944ea79abd01d532d8d039ff9bab36bcabbb219798c9b9f3f9a0")
