-- Lua provided by RyzenAPI
-- Game: 345290

-- MAIN APPLICATION
addappid(345290)
-- Game: addappid(345290)

-- MAIN APP DEPOTS / PACKAGES
addappid(345291, 1, "c5eab6f9635a944ea79abd01d532d8d039ff9bab36bcabbb219798c9b9f3f9a0")
