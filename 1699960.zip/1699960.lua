-- Lua provided by RyzenAPI
-- Game: addappid(1699960)

-- MAIN APPLICATION
addappid(1699960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699961, 1, "32fbacbb313500b4d9fab0c674ad59d7a5fb0eff5e894586e332f629030526f5")
