-- Lua provided by RyzenAPI
-- Game: Game: Hentai beautiful girls 3

-- MAIN APPLICATION
addappid(1292280)
-- Game: addappid(1292280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292281, 1, "66731457b31eb4243aee48478b6c4d9877703b017a35fe8f405069a60f252da8")
addappid(1306000, 0, "d8b9923664583322951cebd39691b415edcc5741d973e0746f498f8fad14cef4")
addappid(1306001, 0, "bbd8ca93f1829b300ea83df9d841fcc87dea801c21f894e878852c4fc619e4d1")
