-- Lua provided by SkyAPI 
-- Game: AppID 1339530
addappid(1339530)
addappid(1339531, 1, "f51544021c256a943d9341d9b9890b9e6b176a8d9504fd749b12ab206765bfdb")
