-- Lua provided by RyzenAPI
-- Game: 1978500

-- MAIN APPLICATION
addappid(1978500)
-- Game: addappid(1978500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978501, 1, "ea1b6903cea4ce324b7c7749d8ec617250e46dfccd27d07e657254d9662af55a")
