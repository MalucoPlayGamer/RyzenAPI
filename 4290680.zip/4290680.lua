-- Lua provided by RyzenAPI
-- Game: Flock of the Seraphim

-- MAIN APPLICATION
addappid(4290680) -- Flock of the Seraphim

-- MAIN APP DEPOTS / PACKAGES
addappid(4290681, 1, "5b765652620434aedced075a616781be4db7ffa1236bec7dd657a9d4a3aa9ac2") -- Depot 4290681

