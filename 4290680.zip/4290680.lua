-- 4290680's Lua and Manifest Created by Hubcap Manifest
-- Flock of the Seraphim
-- Created: August 14, 2026 at 03:58:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4290680) -- Flock of the Seraphim
-- MAIN APP DEPOTS
addappid(4290681, 1, "5b765652620434aedced075a616781be4db7ffa1236bec7dd657a9d4a3aa9ac2") -- Depot 4290681
setManifestid(4290681, "3638443733478457655", 1521777876)