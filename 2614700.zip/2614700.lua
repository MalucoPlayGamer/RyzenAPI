-- Lua provided by RyzenAPI 
-- Game: Infrared
addappid(2614700)
addappid(2614701, 1, "f63d0c615f5ba37f03a6df3c34a4c1771172a40efb915c9ce4f48148b605f27d")
