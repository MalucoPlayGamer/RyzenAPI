-- Lua provided by RyzenAPI
-- Game: Game: Infrared

-- MAIN APPLICATION
addappid(2614700)
-- Game: addappid(2614700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614701, 1, "f63d0c615f5ba37f03a6df3c34a4c1771172a40efb915c9ce4f48148b605f27d")
