-- Lua provided by RyzenAPI 
-- Game: AppID 633370
addappid(633370)
addappid(633371, 1, "9136d3bb304d83ff9b23424229fd485c1d80c137b5a2510f58b387cf0634a92f")
addappid(633372, 1, "198c73b6c20acc98bee85f9a8a3af622d7f14ea1b30d5c1c6036282d16bd63c0")
