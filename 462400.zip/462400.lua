-- Lua provided by RyzenAPI
-- Game: Game: AppID 462400

-- MAIN APPLICATION
addappid(462400)
-- Game: addappid(462400)

-- MAIN APP DEPOTS / PACKAGES
addappid(462401, 1, "8aa7a66df1d2e567d89701cd66c8cefa4e75fee9eb887bd45813940d90867668")
