-- Lua provided by RyzenAPI
-- Game: Game: AppID 1500000

-- MAIN APPLICATION
addappid(1500000)
-- Game: addappid(1500000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1500001, 1, "ce181ada9351d1f585feb5f5cd3b71e0837b319b4930581a47a04f788082a039")
