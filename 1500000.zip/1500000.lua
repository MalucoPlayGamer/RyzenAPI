-- Lua provided by SkyAPI 
-- Game: AppID 1500000
addappid(1500000)
addappid(1500001, 1, "ce181ada9351d1f585feb5f5cd3b71e0837b319b4930581a47a04f788082a039")
