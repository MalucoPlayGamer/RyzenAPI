-- Lua provided by RyzenAPI
-- Game: 2694000

-- MAIN APPLICATION
addappid(2694000)
-- Game: addappid(2694000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2694001, 1, "388eed0587a8760f90a7c6bd2aefa98c5739fee66dfdffc6bd11316f3a83169a")
