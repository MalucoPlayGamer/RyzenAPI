-- Lua provided by RyzenAPI
-- Game: ANCIENT RUS VS LIZARDS

-- MAIN APPLICATION
addappid(2694000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2694001, 1, "388eed0587a8760f90a7c6bd2aefa98c5739fee66dfdffc6bd11316f3a83169a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
