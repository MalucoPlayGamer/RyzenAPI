-- Lua provided by RyzenAPI
-- Game: addappid(711770)

-- MAIN APPLICATION
addappid(711770)

-- MAIN APP DEPOTS / PACKAGES
addappid(711771, 1, "1b3fc404f859586491b52dcad8c01201b2064f6dadd32da81d4f9f910150f2fb")
