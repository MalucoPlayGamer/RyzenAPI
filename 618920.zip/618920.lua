-- Lua provided by RyzenAPI
-- Game: Dungeon Escape VR

-- MAIN APPLICATION
addappid(618920)

-- MAIN APP DEPOTS / PACKAGES
addappid(618921, 1, "0c1ee16fb2aaaad512f55cc4695cb9e89c1abbc4249ed2ad8e2fb3d04dc2125c")

