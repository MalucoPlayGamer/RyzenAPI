-- Lua provided by RyzenAPI
-- Game: addappid(968970)

-- MAIN APPLICATION
addappid(968970)

-- MAIN APP DEPOTS / PACKAGES
addappid(968972,0,"c5d23a2724aac23affe3dff0ccc16110ad25ce00e2294c0dfdb5b35acfad20e1")
addappid(1523470,0,"fcf029e90fc84d66d0556fb28514771db961c7c8317e1a0682e8fa16b9423741")
