-- Lua provided by RyzenAPI
-- Game: addappid(425690)

-- MAIN APPLICATION
addappid(425690)

-- MAIN APP DEPOTS / PACKAGES
addappid(425691, 1, "f08c5dc82aa12ba7c705a31bbb6a28844bb188b999c7667c561cbb4b91ca2bf1")
