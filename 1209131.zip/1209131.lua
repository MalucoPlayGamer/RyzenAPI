-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1209131)
-- Game: addappid(1209131)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209131,0,"f01575ce876d2a2cf949ef8c005340db7332d306a8fd963e373e26bf219dee06")
