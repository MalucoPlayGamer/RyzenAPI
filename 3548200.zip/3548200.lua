-- Lua provided by RyzenAPI
-- Game: addappid(3548200)

-- MAIN APPLICATION
addappid(3548200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3548201, 1, "6586d0ff38365e8774b6cae3c06ae784bcd6ed72f3165247d0cff38f66d225f0")
