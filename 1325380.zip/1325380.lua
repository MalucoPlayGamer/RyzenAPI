-- Lua provided by RyzenAPI
-- Game: Game: Live Empire

-- MAIN APPLICATION
addappid(1325380)
-- Game: addappid(1325380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325381, 1, "44d6a4df82303256529e45e93727e316f755f9c9cb86a6432e8838734ea4796c")
addappid(1429560, 0, "1998dce64de3e82ce8e4f7b528b01c05d08026aeae93918baef3783d2b8209be")
