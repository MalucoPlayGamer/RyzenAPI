-- Lua provided by RyzenAPI
-- Game: V-Katsu

-- MAIN APPLICATION
addappid(856620)

-- MAIN APP DEPOTS / PACKAGES
addappid(856621, 1, "e91fabf4b3a412182d65e0a7de85c030443eb9f37ecc207399b9a1ffbde76f8b")
