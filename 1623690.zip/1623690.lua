-- Lua provided by RyzenAPI
-- Game: addappid(1623690)

-- MAIN APPLICATION
addappid(1623690)
addappid(1623693)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623692,0,"482a55e1885930ea8460cbb7c478cf955739a9effede04d622bf91c81995439a")
