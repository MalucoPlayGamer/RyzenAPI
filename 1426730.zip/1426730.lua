-- Lua provided by RyzenAPI 
-- Game: AppID 1426730
addappid(1426730)
addappid(1426731, 1, "0ec0ac72c38a0b9cdc2d425cc816d7616b72dbc87b2bbbad975f930c6b947706")
addappid(2561130, 0, "fdc6bd91cab0d7b736b1a3c21f10f54d906c40094aee5d6e1a3ccfd724d3f325")
addappid(2901400, 0, "ea07d7081a80c0045698697511f85ed192c70cd0cbc54f174dbfdd81dd9081fc")
