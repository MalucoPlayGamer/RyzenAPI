-- Lua provided by RyzenAPI
-- Game: 976010

-- MAIN APPLICATION
addappid(976010)
-- Game: addappid(976010)

-- MAIN APP DEPOTS / PACKAGES
addappid(976011, 1, "a4fee6bcddb555c9ee0f7376b211d9187e3c65a6e195f8c0958e54a61ffe0b50")
addappid(1045490, 0, "197eef6daf7c0477bd70b9a339bb32f15b137e3f7995d16cc79eb5bcd3ad04a0")
