-- Lua provided by RyzenAPI 
-- Game: The Operator
addappid(1771980)
addappid(1771981, 1, "a132c1c3d884ac55a44f68c500d37d3562afab6e6642d3051469f09a097274c3")
