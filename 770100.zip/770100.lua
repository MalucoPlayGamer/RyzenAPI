-- Lua provided by RyzenAPI
-- Game: One Deck Dungeon

-- MAIN APPLICATION
addappid(770100)

-- MAIN APP DEPOTS / PACKAGES
addappid(770101, 1, "93bdad3a8acbb69bd83225c7e01d1680872bd62af386f00956edbf1e475864e7")
addappid(770102, 1, "518784016a7ad6313ac2b7ccf077939659451a28b971c83bd78a443a0ec6e271")
addappid(770103, 1, "2763dd597df6bdac95fcdf91334e77871d885cd7180ccd7ef0506c3c18401c49")
addappid(860980, 0, "ee768817afb3c265577f3f7472fb596c40b634f5c759eb8a4952f15f593b7b0d")
addappid(860981, 0, "f22c5239b039ee5700b3bbb508ba51dafc1545db8c68c806bcec8aa7dfb0312c")
addappid(870620, 0, "384c4c60be8bf86e19104e416cf8758eae528c7a9f7a3a3b5ef813469d1bf676")
addappid(870621, 0, "2f5a2deae1131e8d4d4ce2182cb78d7438ded39938e0acd8b49236feb96ba3a8")
addappid(889380, 0, "07046cab34ff4f4d6761d5019f301173d1cb25840f598283ad4a8560b93d53e1")
addappid(894970, 0, "65faf5b025da109806816241ec158e5c22077dd31dacc00a2e3b501319b63e98")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1418480)
addappid(4336620)
