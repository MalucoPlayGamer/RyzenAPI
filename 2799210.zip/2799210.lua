-- Lua provided by RyzenAPI
-- Game: 2799210

-- MAIN APPLICATION
addappid(2799210)
-- Game: addappid(2799210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799211, 1, "fae3763105dd1174aa517621dca5778763c85890d8f51ac87c73dac3a1a7ffcd")
