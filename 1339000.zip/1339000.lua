-- Lua provided by RyzenAPI
-- Game: Aquarium Designer

-- MAIN APPLICATION
addappid(1339000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1339001, 1, "79f2b8b5fa266ea2f429988c0f994a678f215cf066802189f9db0809d341b285")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1939750)
addappid(2295420)
addappid(2433780)
