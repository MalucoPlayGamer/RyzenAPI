-- Lua provided by RyzenAPI
-- Game: Game: Wraith: The Oblivion - Afterlife

-- MAIN APPLICATION
addappid(1386870)
-- Game: addappid(1386870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1386871, 1, "907cdb786b295569d9a785e642812a1dd2dc23cea94d7931a04acd2a3d7efb1a")
