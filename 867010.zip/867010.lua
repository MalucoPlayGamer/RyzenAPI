-- Lua provided by RyzenAPI
-- Game: Game: Adventure Delivery Service

-- MAIN APPLICATION
addappid(867010)
-- Game: addappid(867010)

-- MAIN APP DEPOTS / PACKAGES
addappid(867011, 1, "e9eadcd69868bdd2fab40f557303cae76253af750871fa863bbe6cbe1d48a724")
