-- Lua provided by RyzenAPI 
-- Game: Melon Journey: Bittersweet Memories
addappid(1074030)
addappid(1074031, 1, "b73385d137f82ffcabcf2a314c985170b8cb533fb696095a213adf8048ec86d4")
