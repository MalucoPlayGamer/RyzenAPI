-- Lua provided by RyzenAPI
-- Game: Melon Journey: Bittersweet Memories

-- MAIN APPLICATION
addappid(1074030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074031, 1, "b73385d137f82ffcabcf2a314c985170b8cb533fb696095a213adf8048ec86d4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
