-- Lua provided by RyzenAPI
-- Game: A Plot Story

-- MAIN APPLICATION
addappid(699160)
-- Game: addappid(699160)

-- MAIN APP DEPOTS / PACKAGES
addappid(699161, 1, "6de6a584e4a5bc48c7320c2f0815216c3148fbb9e2498de8cee7f13bf6eda579")
