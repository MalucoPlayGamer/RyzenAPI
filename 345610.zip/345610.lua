-- Lua provided by RyzenAPI
-- Game: The Fruit of Grisaia

-- MAIN APPLICATION
addappid(345610)

-- MAIN APP DEPOTS / PACKAGES
addappid(345611, 1, "6987f0d9fb4b5eab0867aa07f882b5c97651dbbe14d7fbf98c5a757b0b7c7804")
