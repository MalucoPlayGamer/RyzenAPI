-- Lua provided by RyzenAPI
-- Game: The Fruit of Grisaia

-- MAIN APPLICATION
addappid(345610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(345611, 1, "6987f0d9fb4b5eab0867aa07f882b5c97651dbbe14d7fbf98c5a757b0b7c7804")

