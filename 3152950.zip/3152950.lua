-- Lua provided by RyzenAPI
-- Game: 邪神的遗产 Demo

-- MAIN APPLICATION
addappid(3152950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152953,0,"e0bd9fc703f39b64286fa9540e113fc436ee9c99ff44aad63b8e061e1297fcf3")

