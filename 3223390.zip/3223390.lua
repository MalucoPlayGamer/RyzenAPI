-- Lua provided by SkyAPI 
-- Game: AppID 3223390
addappid(3223390)
addappid(3223391, 1, "4036bdc314ed64ad1efaef4cd271ca400910b4048fcec7a40b2bf0ac4cb18989")
