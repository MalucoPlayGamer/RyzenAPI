-- Lua provided by RyzenAPI
-- Game: AppID 3223390

-- MAIN APPLICATION
addappid(3223390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3223391, 1, "4036bdc314ed64ad1efaef4cd271ca400910b4048fcec7a40b2bf0ac4cb18989")
