-- Lua provided by RyzenAPI 
-- Game: Octohill Ski Tycoon
addappid(3302160)
addappid(3302161, 1, "11f91e00b2ddc360f187f5cf0c07571e46d63c7997ee56e0c499858f18e3fecc")
