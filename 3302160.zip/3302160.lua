-- Lua provided by RyzenAPI
-- Game: addappid(3302160)

-- MAIN APPLICATION
addappid(3302160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3302161, 1, "11f91e00b2ddc360f187f5cf0c07571e46d63c7997ee56e0c499858f18e3fecc")
