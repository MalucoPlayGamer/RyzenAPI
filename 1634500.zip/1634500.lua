-- Lua provided by RyzenAPI
-- Game: Company of Heroes 3: Mission Alpha

-- MAIN APPLICATION
addappid(1634500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1634501, 1, "00bd151e7b1ce24c934a460c4b4a9bd29ee8579f8cfb22974f3345e3b733c447")

