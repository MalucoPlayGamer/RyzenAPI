-- Lua provided by RyzenAPI 
-- Game: AppID 1634500
addappid(1634500)
addappid(1634501, 1, "00bd151e7b1ce24c934a460c4b4a9bd29ee8579f8cfb22974f3345e3b733c447")
