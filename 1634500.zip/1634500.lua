-- Lua provided by RyzenAPI
-- Game: Game: AppID 1634500

-- MAIN APPLICATION
addappid(1634500)
-- Game: addappid(1634500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634501, 1, "00bd151e7b1ce24c934a460c4b4a9bd29ee8579f8cfb22974f3345e3b733c447")
