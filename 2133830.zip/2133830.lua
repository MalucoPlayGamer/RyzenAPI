-- Lua provided by RyzenAPI
-- Game: BrokenLore: UNFOLLOW

-- MAIN APPLICATION
addappid(2133830)
addappid(4114580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2133831, 1, "e5d1c8cd2921865aae9a3dff027d32e0cba6b6d61f5c0b3e315a954180c73bb5")

