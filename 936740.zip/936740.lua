-- Lua provided by RyzenAPI
-- Game: Orogenesis

-- MAIN APPLICATION
addappid(936740)

-- MAIN APP DEPOTS / PACKAGES
addappid(936741, 1, "319a27ad9de53325f2e2f02724cb21f8796d9915420fa914cc404fc08cb51ade")
