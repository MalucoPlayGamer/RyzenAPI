-- Lua provided by RyzenAPI
-- Game: Suppressed

-- MAIN APPLICATION
addappid(541560)

-- MAIN APP DEPOTS / PACKAGES
addappid(541562,0,"e60c47db582010e171a4ff8de28bef68355c2c8d1b35837ada1c3188444eddaf")

