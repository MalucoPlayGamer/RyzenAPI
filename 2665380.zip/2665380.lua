-- Lua provided by RyzenAPI
-- Game: 2665380

-- MAIN APPLICATION
addappid(2665380)
-- Game: addappid(2665380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2665381, 1, "5196f92211bf72c70802853cd1951c11e76ae8cdb7428c0d77fea36d130b26c1")
