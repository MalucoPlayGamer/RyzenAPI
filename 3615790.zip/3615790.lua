-- Lua provided by RyzenAPI
-- Game: Game: A Sexy Tour With : Yeona

-- MAIN APPLICATION
addappid(3615790)
-- Game: addappid(3615790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3615791, 1, "ca526773c75b40c2664cdaac99a47859578ba45f79d3840ec928d5b500bcc807")
