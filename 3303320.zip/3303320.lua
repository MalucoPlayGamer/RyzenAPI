-- Lua provided by SkyAPI 
-- Game: AppID 3303320
addappid(3303320)
addappid(3303321, 1, "7fe88585c2b6178d6fa39c02a62d464bc3ea6e257eb1f105b5cb918aaaed066a")
