-- Lua provided by RyzenAPI
-- Game: Enigmoon

-- MAIN APPLICATION
addappid(406090)

-- MAIN APP DEPOTS / PACKAGES
addappid(406091, 1, "24a943f3fcff61fb045a034ae231385884f22fa7c8228f8d939657e871cef442")
