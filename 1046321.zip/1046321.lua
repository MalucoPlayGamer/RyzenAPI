-- Lua provided by RyzenAPI
-- Game: addappid(1046321)

-- MAIN APPLICATION
addappid(1046321)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046321,0,"99528d23fc159e485306006e31a6a40afb71cb55aaac8427b2de49b07be82534")
