-- Lua provided by RyzenAPI
-- Game: addappid(1905640)

-- MAIN APPLICATION
addappid(228989)
addappid(1905640)
addappid(1905641)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905642,0,"ff7efd3781e0c671281944fe77b6e1a5a6e61220be737aade1463f3eabcd95d0")
