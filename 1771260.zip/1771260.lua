-- Lua provided by SkyAPI 
-- Game: Conquest!
addappid(1771260)
addappid(1771261, 1, "eb57185324b21009252b2dd850639b6f1a516e17d02b3c4551bedc7bf5a064da")
