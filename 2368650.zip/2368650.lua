-- Lua provided by RyzenAPI
-- Game: GUNSHIP

-- MAIN APPLICATION
addappid(2368650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2368651, 1, "b5c0a966e198cb25e997b0581210ed3208eef10ce125808a5a10f3e9d23384f8")

