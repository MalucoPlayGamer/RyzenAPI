-- Lua provided by RyzenAPI
-- Game: GUNSHIP

-- MAIN APPLICATION
addappid(2368650)
-- Game: addappid(2368650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368651, 1, "b5c0a966e198cb25e997b0581210ed3208eef10ce125808a5a10f3e9d23384f8")
