-- Lua provided by RyzenAPI
-- Game: The Symbiant Re:Union

-- MAIN APPLICATION
addappid(2355140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355141, 1, "5e65acbffbcf90bf1bd2c40cd28be0853b9d7b05ae518e81079ad5f686d4f0d2")
