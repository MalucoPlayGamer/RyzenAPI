-- Lua provided by SkyAPI 
-- Game: Isyium
addappid(555080)
addappid(555081, 1, "ff32401d084e356f7d5588986339c32ac1e04e8369b0db7a807d1e6ec480f9f4")
