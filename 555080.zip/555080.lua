-- Lua provided by RyzenAPI
-- Game: Game: Isyium

-- MAIN APPLICATION
addappid(555080)
-- Game: addappid(555080)

-- MAIN APP DEPOTS / PACKAGES
addappid(555081, 1, "ff32401d084e356f7d5588986339c32ac1e04e8369b0db7a807d1e6ec480f9f4")
