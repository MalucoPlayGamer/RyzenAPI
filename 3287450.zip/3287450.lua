-- Lua provided by RyzenAPI
-- Game: Game: AppID 3287450

-- MAIN APPLICATION
addappid(3287450)
-- Game: addappid(3287450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3287451, 1, "0636124f98e44678d6a2554bcb28903f0f313a53d1091a5c422d4de01b4f0bb3")
