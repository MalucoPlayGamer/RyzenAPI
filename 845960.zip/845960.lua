-- Lua provided by RyzenAPI
-- Game: Furries & Scalies & Bears OH MY!

-- MAIN APPLICATION
addappid(845960)
addappid(940670)
addappid(940671)
addappid(1078400)
addappid(3262130)
addappid(3262140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(845961,0,"8c337f37cc9d5d63a04c0be1c107552ca8155592c48de178f07b82ab6ea55acc")
addappid(940672,0,"03c939c47396533678a825bb8cf6db1f5fb569c8e60013db5e8b7d050aedbb9f")
addappid(1095690,0,"9ed50e8bc349bb13352f93b81edd817f2136eea3516fec11d94b694669309c86")
addappid(1349180,0,"b919ef9a918a33f6231ee55180aa44febf5785b8b40b970572499a264c3c846b")

