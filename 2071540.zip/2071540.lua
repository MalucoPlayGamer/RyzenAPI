-- Lua provided by RyzenAPI 
-- Game: Timmy Types
addappid(2071540)
addappid(2071541, 1, "ea1f414d39d8eab64dc920d95d2396a9676ee078e97c40aecac678c7f5245dfd")
