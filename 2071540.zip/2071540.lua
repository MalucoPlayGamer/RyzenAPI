-- Lua provided by RyzenAPI
-- Game: Timmy Types

-- MAIN APPLICATION
addappid(2071540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2071541, 1, "ea1f414d39d8eab64dc920d95d2396a9676ee078e97c40aecac678c7f5245dfd")

