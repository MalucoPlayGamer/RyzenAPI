-- Lua provided by RyzenAPI
-- Game: addappid(2503830)

-- MAIN APPLICATION
addappid(2503830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2503831, 1, "691f4d7b79cddbb7a674b1db9a36c2f9936f00adcd112c1e33efb5a4b18c33aa")
