-- Lua provided by RyzenAPI
-- Game: Game: boom faster

-- MAIN APPLICATION
addappid(1563110)
-- Game: addappid(1563110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563111, 1, "da41e143a99474d192fa64f37085d115446bdab7a96a597209a25a4eabdff6ba")
