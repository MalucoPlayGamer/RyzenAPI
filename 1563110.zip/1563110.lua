-- Lua provided by RyzenAPI
-- Game: addappid(1563110)

-- MAIN APPLICATION
addappid(1563110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563111, 1, "da41e143a99474d192fa64f37085d115446bdab7a96a597209a25a4eabdff6ba")
