-- Lua provided by RyzenAPI
-- Game: Tom Clancy's Ghost Recon® Desert Siege™

-- MAIN APPLICATION
addappid(13620)
addappid(15301)
-- Game: addappid(13620)

-- MAIN APP DEPOTS / PACKAGES
addappid(13621, 1, "a41a39c4857f5a97f9d6bb32b9445e7d829fb1bbe4bf8d08103e11af7b4d54ae")
