-- Lua provided by RyzenAPI
-- Game: addappid(487530)

-- MAIN APPLICATION
addappid(487530)

-- MAIN APP DEPOTS / PACKAGES
addappid(487531, 1, "f1ff63bbc8fa9d6bf129eef19fd45a8cf212acbabc2bf036083525408b1fd194")
