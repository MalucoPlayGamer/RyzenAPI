-- Lua provided by RyzenAPI
-- Game: かいき LoopDown

-- MAIN APPLICATION
addappid(2706950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706951, 1, "68f66318f3820cdabd124e4bd67202e2e2ab81857739fd4562b904ff854791bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
