-- Lua provided by RyzenAPI
-- Game: Boundary Master

-- MAIN APPLICATION
addappid(3071370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071371, 1, "5600be61b09cddbd4c65cd001aad21f8dd59db08995c0e663a3ab14b23044ffc")
