-- Lua provided by RyzenAPI
-- Game: 2388520

-- MAIN APPLICATION
addappid(2388520)
-- Game: addappid(2388520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388521, 1, "e5dac9a7472ba3bad736dc57f4786d248aba71b58d73c3da013d8de22a82ef0f")
