-- Lua provided by RyzenAPI
-- Game: Kessler Syndrome

-- MAIN APPLICATION
addappid(2388520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388521, 1, "e5dac9a7472ba3bad736dc57f4786d248aba71b58d73c3da013d8de22a82ef0f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
