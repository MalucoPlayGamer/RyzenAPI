-- Lua provided by RyzenAPI
-- Game: 1933990

-- MAIN APPLICATION
addappid(1933990)
-- Game: addappid(1933990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933991, 1, "7aef3c0211d717437b0f30edbefbd96d8b38fcfbc2368f9e162ea019e73255f1")
