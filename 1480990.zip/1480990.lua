-- Lua provided by RyzenAPI
-- Game: addappid(1480990)

-- MAIN APPLICATION
addappid(1480990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480991, 1, "030da2a87dafc50171e3aaab171cf80c2e7906abe52631babdc30a93fd306cbe")
