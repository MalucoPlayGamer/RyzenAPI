-- Lua provided by RyzenAPI
-- Game: MAFIA: Sex Noir

-- MAIN APPLICATION
addappid(1876470)
-- Game: addappid(1876470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876471, 1, "676024fd1b56e6700fc450e923fb437fdf09b4f9536d6709051f376a0bf949d0")
