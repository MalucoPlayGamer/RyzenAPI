-- Lua provided by RyzenAPI
-- Game: Aerolicious

-- MAIN APP DEPOTS / PACKAGES
addappid(4774170, 1, "b932a45b9cf5c0b25e76e45795cab5c3c32b7209bd7d96c67ef33776169b34ba") -- Aerolicious
addappid(4774171, 1, "30a3839a0b6c583dac4b7f182c30ee6246fa958f7703b66d9c34cf7aa8b533ef") -- Depot 4774171

