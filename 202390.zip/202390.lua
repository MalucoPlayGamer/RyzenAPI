-- Lua provided by RyzenAPI
-- Game: Vessel Demo

-- MAIN APPLICATION
addappid(202390)

-- MAIN APP DEPOTS / PACKAGES
addappid(202391, 1, "91dcb959d412d22b67cd830651dd0a958ce3376e8ef8c26fa71c4b50961f6b5d")
