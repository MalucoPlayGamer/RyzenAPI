-- Lua provided by RyzenAPI
-- Game: Word Crystal

-- MAIN APPLICATION
addappid(1924100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924101, 1, "099927455859dc16d7c0c5550d18c064e00abdee2d9e489d741d5382e46d82e8")
