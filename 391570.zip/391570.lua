-- Lua provided by RyzenAPI
-- Game: UNDERTALE Soundtrack

-- MAIN APPLICATION
addappid(391570)
-- Game: addappid(391570)

-- MAIN APP DEPOTS / PACKAGES
addappid(391570,0,"379685b5bcb58da172ca9a75fffa16d7cef1420dc239fa3d0a091da80975c798")
