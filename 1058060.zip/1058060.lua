-- Lua provided by RyzenAPI 
-- Game: Princesses Never Lose!
addappid(1058060)
addappid(1058061, 1, "863951836db85c4eeca6f56133012e95787864e22e38e446acc0833f3f2efa25")
addappid(1058062, 1, "6e2ff9efaeb5afecb7a98a280b5988b6ede52f7d44c6604a3621598d6df3e627")
addappid(1058063, 1, "a401488b7127fa285ec6b6e40cdc4721fc9a9b77db3a26dced7a868c8365af39")
