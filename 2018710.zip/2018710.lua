-- Lua provided by RyzenAPI
-- Game: Game: Desktop Hacker Demo

-- MAIN APPLICATION
addappid(2018710)
-- Game: addappid(2018710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018711, 1, "6493f9b2d5ac55b3b1a2be5a9158bc9dbca28ea5c2279dd170e38ce0363c7875")
