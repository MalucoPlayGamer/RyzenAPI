-- Lua provided by RyzenAPI
-- Game: Caverns of Mars: Recharged

-- MAIN APPLICATION
addappid(2213980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213981, 1, "c642b7a7d8aefdaae078e9c541d9561c97e2d0c65470fde2244d45ac42623d98")
