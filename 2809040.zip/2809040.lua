-- Lua provided by RyzenAPI
-- Game: PANICORE Demo

-- MAIN APPLICATION
addappid(2809040)
-- Game: addappid(2809040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809041, 1, "cea8d7784aa9be0c739eea90aa65d5227d4351360a4a961f377fd87e46695636")
