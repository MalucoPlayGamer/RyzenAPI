-- Lua provided by RyzenAPI
-- Game: Vtuber Animator

-- MAIN APPLICATION
addappid(2810100)
-- Game: addappid(2810100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810101, 1, "f058ca3a1c4abc9d3a3591bc984b2fde152120fee339cac29c371a976e01b1dc")
