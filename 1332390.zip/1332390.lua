-- Lua provided by RyzenAPI
-- Game: Game: F.I.S.T.:Forged In Shadow Torch Demo

-- MAIN APPLICATION
addappid(1332390)
-- Game: addappid(1332390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332391, 1, "1e54bc86ca91a71c0a6b2259d9c19665b869e53b90eb3e4a56dbe218172d4e4c")
