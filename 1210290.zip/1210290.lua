-- Lua provided by RyzenAPI
-- Game: World of relish - Artbook 18+

-- MAIN APPLICATION
addappid(1210290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210290,0,"9f439c5b2cff35854ac378467d7263225307b5c1747ff1b860b86f4a92d4acd3")

