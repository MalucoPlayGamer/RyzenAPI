-- Lua provided by RyzenAPI
-- Game: Blackwell Convergence

-- MAIN APPLICATION
addappid(80350)
-- Game: addappid(80350)

-- MAIN APP DEPOTS / PACKAGES
addappid(80351, 1, "5f9a9773c02646980a0f05877d6c8f95a84f03f4f27d327bce552ac6a9206616")
addappid(80352, 1, "c35475ed30854ccfb6c03a3632e15644568d82d16c822279a4a680d5d966cd0c")
addappid(80353, 1, "226ce4efce3f215578f44637683ccb6ddab5a034f5200b9c2901128ffe1e86e4")
addappid(2051780, 0, "db97a604734d3bc6aaa267a41e5290696dca5eac028114e3f30a11c579da7cac")
