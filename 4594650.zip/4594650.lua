-- 4594650's Lua and Manifest Created by Hubcap Manifest
-- Galaxy Cadet
-- Created: July 24, 2026 at 06:09:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4594650) -- Galaxy Cadet
-- MAIN APP DEPOTS
addappid(4594651, 1, "efba73f0012ebc3cbdc3eedd95ae81f070bebb63af759882e67d3eafc366fc9d") -- Depot 4594651
setManifestid(4594651, "5426505817917481031", 742669826)