-- Lua provided by RyzenAPI
-- Game: 3569400

-- MAIN APPLICATION
addappid(3569400)
-- Game: addappid(3569400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3569401, 1, "046e002844eb263fbc457de41501876a0d8f773acc9ad97cce30a6002c3ad7df")
