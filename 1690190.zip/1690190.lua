-- Lua provided by RyzenAPI
-- Game: Game: Portal Walk

-- MAIN APPLICATION
addappid(1690190)
-- Game: addappid(1690190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690191, 1, "2fa62f07e6821e70652363a03a7ca882345e63c55604f409e049a40d9fbafc35")
