-- Lua provided by RyzenAPI
-- Game: 2355050

-- MAIN APPLICATION
addappid(2355050)
-- Game: addappid(2355050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355051, 1, "c9a894f7adfa9dfd39e27eea5cab6dcaff872a55d8f78cafb98f440cac783d04")
