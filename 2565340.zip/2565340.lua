-- Lua provided by SkyAPI 
-- Game: Split Echo: Demo
addappid(2565340)
addappid(2565341, 1, "968c3fe98647ca15866025e000d1cdcfeaab0d116ddb6895bcaad0effbf63eaf")
