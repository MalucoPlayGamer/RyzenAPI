-- Lua provided by RyzenAPI
-- Game: Game: Hentai Castle

-- MAIN APPLICATION
addappid(3211210)
-- Game: addappid(3211210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3211211, 1, "15920b9d2618917d629a1e98b7d947169fd00f7fcba43f996978ccced9bd1150")
