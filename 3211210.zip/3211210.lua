-- Lua provided by SkyAPI 
-- Game: Hentai Castle
addappid(3211210)
addappid(3211211, 1, "15920b9d2618917d629a1e98b7d947169fd00f7fcba43f996978ccced9bd1150")
