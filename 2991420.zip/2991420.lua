-- Lua provided by RyzenAPI
-- Game: Neko Odyssey Demo

-- MAIN APPLICATION
addappid(2991420)
-- Game: addappid(2991420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2991421, 1, "33694a4aca911a06b63713755ea47b281f941401c9967f964568bd875db6da0f")
