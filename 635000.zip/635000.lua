-- Lua provided by RyzenAPI
-- Game: Edge of Hearts

-- MAIN APPLICATION
addappid(635000)

-- MAIN APP DEPOTS / PACKAGES
addappid(635001, 1, "b1475fe2e697ed80349278a75d7dc89cb3cc895a1eb19f77937768a6cb303548")

