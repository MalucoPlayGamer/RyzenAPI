-- Lua provided by RyzenAPI
-- Game: No Rest for the Wicked

-- MAIN APPLICATION
addappid(1371980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1371981, 1, "9598cfe06b948f9eca5cbd915b40bec41730f61f6349bbd41d5ee6e86c47a3f6")
addappid(1371982, 1, "d2a7d91fcd80393c3bf0c9e55165cba9c37c264dbe3eddb717215de20508e607")

