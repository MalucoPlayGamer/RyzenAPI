-- Lua provided by RyzenAPI
-- Game: 2739950

-- MAIN APPLICATION
addappid(2739950)
-- Game: addappid(2739950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739951, 1, "7f6d6ca91501d792e76909edabac5f07b9b5be60609209aa2d4692357e68fc3d")
