-- Lua provided by RyzenAPI
-- Game: Tales of Kenzera™: ZAU Demo

-- MAIN APPLICATION
addappid(2739950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739951, 1, "7f6d6ca91501d792e76909edabac5f07b9b5be60609209aa2d4692357e68fc3d")
