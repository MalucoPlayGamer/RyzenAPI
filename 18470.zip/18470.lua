-- Lua provided by RyzenAPI
-- Game: 18470

-- MAIN APPLICATION
addappid(18470)
-- Game: addappid(18470)

-- MAIN APP DEPOTS / PACKAGES
addappid(18471, 1, "7f66c170a5950c4eddd816f105190cf801320fbe7802ccb437769dfcd238a402")
addappid(18472, 1, "4f010a3f652aee321d5e8898f0b32939b352e89d7a52746393c1bd05739f434a")
addappid(18473, 1, "86ee9f0560cffd3af0fe570fca5a920304a0f6336cc0d6364ce51b5ab7b5d5ee")
addappid(18474, 1, "5594bfd4eda3716b3a0c248cbefa672c62ca65522d1620eb44b5a5ef85a757a0")
