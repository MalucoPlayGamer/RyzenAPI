-- Lua provided by RyzenAPI
-- Game: Game: AppID 571520

-- MAIN APPLICATION
addappid(571520)
-- Game: addappid(571520)

-- MAIN APP DEPOTS / PACKAGES
addappid(571521, 1, "bbd7e3b1a95944d47ef2056def82ecd327f919cc88a0417a617cd19e737b7547")
