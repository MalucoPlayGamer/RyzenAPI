-- Lua provided by RyzenAPI
-- Game: 2140320

-- MAIN APPLICATION
addappid(2140320)
addappid(2140321)
-- Game: addappid(2140320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879951,0,"ca0459a2a86d27cfc530091fa46a367d52f30ea10967ac6f548446372dd86a28")
