-- Lua provided by RyzenAPI
-- Game: Psychroma Demo

-- MAIN APPLICATION
addappid(2140320)
addappid(2140321)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879951,0,"ca0459a2a86d27cfc530091fa46a367d52f30ea10967ac6f548446372dd86a28")

