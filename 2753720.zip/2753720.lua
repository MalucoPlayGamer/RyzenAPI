-- Lua provided by RyzenAPI
-- Game: False Dream

-- MAIN APPLICATION
addappid(2753720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753721, 1, "cf2a6841150083f458887b577b1e8b454037151d008a37b5cf0375b2f37af547")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
