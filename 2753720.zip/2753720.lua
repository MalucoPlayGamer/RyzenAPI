-- Lua provided by RyzenAPI
-- Game: False Dream

-- MAIN APPLICATION
addappid(2753720)
-- Game: addappid(2753720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753721, 1, "cf2a6841150083f458887b577b1e8b454037151d008a37b5cf0375b2f37af547")
