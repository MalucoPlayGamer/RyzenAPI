-- Lua provided by RyzenAPI 
-- Game: 突然＊恋人
addappid(2510810)
addappid(2510811, 1, "02eae2e20e8b209b4bcb1f2667b4019447964966e706a9951305e2eb10a1a968")
