-- Lua provided by RyzenAPI
-- Game: 5 Minute Climb

-- MAIN APPLICATION
addappid(2375740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375741, 1, "0f80f7aa862cc9b448b0bfae6549784c43c2a5feb6be86291a988b3a3da74de9")

