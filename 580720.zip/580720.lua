-- Lua provided by RyzenAPI
-- Game: Carrier Deck

-- MAIN APPLICATION
addappid(580720)

-- MAIN APP DEPOTS / PACKAGES
addappid(580721, 1, "aa81ea57f9eff3b1a697f630702aaf4b48c85dc6fa24fd6d4b1f9c3021f88706")

