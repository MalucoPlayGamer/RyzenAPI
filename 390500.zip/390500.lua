-- Lua provided by RyzenAPI
-- Game: Arma 3 Samples

-- MAIN APPLICATION
addappid(390500)

-- MAIN APP DEPOTS / PACKAGES
addappid(390501, 1, "5a27a4ab29a120a36d3939a1531f7070510781ee303a052c30616a301dfda0e7")

