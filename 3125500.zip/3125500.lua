-- 3125500's Lua and Manifest Created by Hubcap Manifest
-- Reality Core
-- Created: June 26, 2026 at 17:40:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3125500) -- Reality Core
-- MAIN APP DEPOTS
addappid(3125501, 1, "3fd62de76c9e30f2c468961adeef118fe47e47e180b83e02fea022f58f5ade27") -- Depot 3125501
setManifestid(3125501, "8529049430823200527", 306287819)