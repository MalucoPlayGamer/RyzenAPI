-- Lua provided by RyzenAPI
-- Game: Tyrion Cuthbert: Attorney of the Arcane

-- MAIN APPLICATION
addappid(1590230)
addappid(4302040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1590231, 1, "2d64c29f624b03ab2a4bd212bb56549853479487f6b54f262fb7f40f1d5f5e61")

