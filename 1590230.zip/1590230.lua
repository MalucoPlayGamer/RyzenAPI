-- Lua provided by RyzenAPI
-- Game: Game: Tyrion Cuthbert: Attorney of the Arcane

-- MAIN APPLICATION
addappid(1590230)
-- Game: addappid(1590230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1590231, 1, "2d64c29f624b03ab2a4bd212bb56549853479487f6b54f262fb7f40f1d5f5e61")
