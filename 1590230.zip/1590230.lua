-- Lua provided by SkyAPI 
-- Game: Tyrion Cuthbert: Attorney of the Arcane
addappid(1590230)
addappid(1590231, 1, "2d64c29f624b03ab2a4bd212bb56549853479487f6b54f262fb7f40f1d5f5e61")
