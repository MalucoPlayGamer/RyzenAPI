-- Lua provided by RyzenAPI
-- Game: Game: Isolate ME!

-- MAIN APPLICATION
addappid(1964540)
-- Game: addappid(1964540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964541, 1, "e8b9bb970412e9e0c20968e7bdfb407b6747c30aad623b446fca489bd6a0ce17")
