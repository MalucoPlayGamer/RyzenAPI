-- Lua provided by RyzenAPI
-- Game: AppID 940290

-- MAIN APPLICATION
addappid(940290)
-- Game: addappid(940290)

-- MAIN APP DEPOTS / PACKAGES
addappid(940291, 1, "1d5f0251b78ff4f75b4b1ebf2034d45827e01dad6b553a54aacc279fd2174b03")
