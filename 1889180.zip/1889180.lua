-- Lua provided by RyzenAPI
-- Game: TombStar Demo

-- MAIN APPLICATION
addappid(1889180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889181, 1, "79d07d339692b5739c28328c2fcb29cdf401cc16b883f15c7bd19010476df9bb")
