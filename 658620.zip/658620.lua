-- Lua provided by RyzenAPI
-- Game: addappid(658620)

-- MAIN APPLICATION
addappid(658620)

-- MAIN APP DEPOTS / PACKAGES
addappid(658621, 1, "302911e178f6741460eb3404ad1fc88eaeae4650cd71719b39f6f845aaba9310")
