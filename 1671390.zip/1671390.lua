-- Lua provided by RyzenAPI
-- Game: addappid(1671390)

-- MAIN APPLICATION
addappid(1671390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671391, 1, "101ed264fe4ff0ce356d01bd6aa63995d59ca372673d97bbc39a22800d5beddc")
