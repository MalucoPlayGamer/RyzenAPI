-- Lua provided by RyzenAPI 
-- Game: Ancient Dino Runner
addappid(1671390)
addappid(1671391, 1, "101ed264fe4ff0ce356d01bd6aa63995d59ca372673d97bbc39a22800d5beddc")
