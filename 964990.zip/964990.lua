-- Lua provided by RyzenAPI
-- Game: Game: AppID 964990

-- MAIN APPLICATION
addappid(964990)
-- Game: addappid(964990)

-- MAIN APP DEPOTS / PACKAGES
addappid(964991, 1, "823183aced6099b7e1a605e19464ea29efbb9a8a7bfc92277eed6df427fe7eab")
