-- Lua provided by RyzenAPI
-- Game: Sniper Fodder

-- MAIN APPLICATION
addappid(880840)

-- MAIN APP DEPOTS / PACKAGES
addappid(880841, 1, "39e42fe2eb52f537c6e8efc3a4ca09f0918178b383fd9c46b14b0681380b5262")

