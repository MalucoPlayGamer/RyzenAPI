-- Lua provided by RyzenAPI
-- Game: 2065840

-- MAIN APPLICATION
addappid(2065840)
-- Game: addappid(2065840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2065841, 1, "a71d6e44b78d888c98b4ff8da9e88a6e0cb9bc44a817fe1b542cffb7c0cb002e")
