-- Lua provided by RyzenAPI
-- Game: Blocksworld

-- MAIN APPLICATION
addappid(642390)
addappid(642391)
addappid(642393)
-- Game: addappid(642390)

-- MAIN APP DEPOTS / PACKAGES
addappid(642392,0,"ec9f788fa548c729b48e8c61f10ef12fb00e3652b43104ed1a2b089be8c36a1b")
