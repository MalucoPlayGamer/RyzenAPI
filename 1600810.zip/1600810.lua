-- Lua provided by RyzenAPI
-- Game: addappid(1600810)

-- MAIN APPLICATION
addappid(1600810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600815,0,"9101c0f8b5bc81a8be00e2c28ea2eab92c3868955ba016cee65cfbd31bac4681")
addappid(1600816,0,"fc79d85902befdded0e18205c8b31b23b010e2cef873a0b010e800db1d7d4d57")
