-- Lua provided by RyzenAPI
-- Game: Viral Cry

-- MAIN APPLICATION
addappid(795530)
addappid(795531)
addappid(795532)

-- MAIN APP DEPOTS / PACKAGES
addappid(795533,0,"521ec8ff3e7e71cbd8701586f20f2f4f0c845dd45b6ece3cd43287901014f490")

