-- Lua provided by RyzenAPI
-- Game: addappid(1628390)

-- MAIN APPLICATION
addappid(1628390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628391, 1, "01a73eb64ef7cdc3f54724b95ed24edc8bb92e6745106e2ef44c82760283a3a4")
