-- Lua provided by RyzenAPI
-- Game: EA SPORTS™ Madden NFL 27

-- MAIN APPLICATION
addappid(3940610) -- EA SPORTS™ Madden NFL 27
addappid(4113760) -- Madden NFL 27 - Madden Points
addappid(4115160) -- Madden NFL 27 - EA Play Trial Key
addappid(4681420) -- EA SPORTS MVP Bundle (College Football 27 Deluxe Edition  Madden NFL 27 Deluxe Edition) Pre-order Content
addappid(4973150) -- Madden NFL 27 Press Offer Edition Key

-- MAIN APP DEPOTS / PACKAGES
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
addappid(3893181, 1, "7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6") -- Depot 3893181 (Shared from App 3893180)
addappid(3940611, 1, "417d28ae0ec17dfcf969da22bb48c964e121731ec311766832d94d497981e686") -- Depot 3940611
addappid(3940612, 1, "2a21563d2c92c1c8d9fd4f3714d79761aa9322bb7a67860483889c2222c1632b") -- Depot 3940612

