-- 3940610's Lua and Manifest Created by Hubcap Manifest
-- EA SPORTS™ Madden NFL 27
-- Created: August 06, 2026 at 17:44:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3940610) -- EA SPORTS™ Madden NFL 27
-- MAIN APP DEPOTS
addappid(3940611, 1, "417d28ae0ec17dfcf969da22bb48c964e121731ec311766832d94d497981e686") -- Depot 3940611
setManifestid(3940611, "5814151865261907913", 59039936048)
addappid(3940612, 1, "2a21563d2c92c1c8d9fd4f3714d79761aa9322bb7a67860483889c2222c1632b") -- Depot 3940612
setManifestid(3940612, "1850347466532527115", 7368644791)
-- SHARED DEPOTS (from other apps)
addappid(3893181, 1, "7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6") -- Depot 3893181 (Shared from App 3893180)
setManifestid(3893181, "1558442456104985494", 333590753)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "2111133955805833191", 241196903)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4113760) -- Madden NFL 27 - Madden Points
addappid(4115160) -- Madden NFL 27 - EA Play Trial Key
addappid(4681420) -- EA SPORTS MVP Bundle (College Football 27 Deluxe Edition  Madden NFL 27 Deluxe Edition) Pre-order Content
addappid(4973150) -- Madden NFL 27 Press Offer Edition Key