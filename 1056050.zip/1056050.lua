-- Lua provided by RyzenAPI
-- Game: addappid(1056050)

-- MAIN APPLICATION
addappid(1056050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056051, 1, "d5840a2766bb4e7dfcb9e24b79d696e32650a25a38042a1b47f5928dc730cbc4")
