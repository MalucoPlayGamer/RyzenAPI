-- Lua provided by RyzenAPI 
-- Game: Dice Kingdoms Demo
addappid(2136540)
addappid(2136541, 1, "959bd325382139487dd7c3da4c0b339eb0d8d8dd96f9b0d6ca8b698e615463ba")
addappid(2136542, 1, "0136b9b8055be632e6de3755a60d7be557c4547a374374a589c067500603e16e")
