-- Lua provided by RyzenAPI
-- Game: Game: Baldur's Gate: Enhanced Edition

-- MAIN APPLICATION
addappid(228280)
addappid(228982)
addappid(229020)
-- Game: addappid(228280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228281, 1, "4ccf8f28b07eacbfb0320da73abf7788fc518b7033c62add7d18f78ca3515d41")
addappid(228282, 1, "9cdf4cfa2a2094c6d1185d0a9af745b5a756009379807dbc6fd0f67e66f7021c")
addappid(228283, 1, "4f7ed9dcac7787ecaa8afed35c4c507395a02729b94ff10e4a714ba32c769774")
addappid(228284, 1, "0abb087e1849124c069599acf1c23799f2c092ad60715192a499686d3274c07c")
addappid(385970, 0, "bf55252acfbe28dd4bdb5a7ae0ca72062da2ec4f25f1ec98de97dd462711437a")
addappid(687500, 0, "6d9e2461ecf9c235d6dfcce8611dba21cdcc9161d7bc8c2ef4c08caa67ff9a14")
addappid(2488970, 0, "eb868fb93e0936f72260320071124dcf050e11fdaefcc2aee9919b6787bc133b")
