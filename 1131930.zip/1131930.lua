-- Lua provided by SkyAPI 
-- Game: BARRICADEZ
addappid(1131930)
addappid(1131931, 1, "1986bd63b8022a80cc559829fef1687b7634e45a02a01f3b35e8d3c81e11937f")
