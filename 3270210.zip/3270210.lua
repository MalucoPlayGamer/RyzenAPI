-- Lua provided by RyzenAPI
-- Game: Abolish

-- MAIN APPLICATION
addappid(3270210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3270211, 1, "75254390528f254524332ac70da1eace770d7f4c45e3b446f334c0dbeedb0743")
