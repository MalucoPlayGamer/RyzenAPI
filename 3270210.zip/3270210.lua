-- Lua provided by RyzenAPI 
-- Game: Abolish
addappid(3270210)
addappid(3270211, 1, "75254390528f254524332ac70da1eace770d7f4c45e3b446f334c0dbeedb0743")
