-- Lua provided by RyzenAPI
-- Game: Electronic Universe

-- MAIN APPLICATION
addappid(1801560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801561, 1, "c04398c0dbc20c73ff502c562e8aaf0d58701d63223f9c3cc2cff6563036ea4c")

