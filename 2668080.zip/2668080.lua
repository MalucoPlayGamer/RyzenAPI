-- Lua provided by RyzenAPI
-- Game: Game: Snowbreak: Containment Zone

-- MAIN APPLICATION
addappid(2668080)
-- Game: addappid(2668080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668081, 1, "08a4f7f6d4398eca33e57a0ebd41aff377e7bd72ef5fa37ee5e8895d1b82f50f")
