-- Lua provided by RyzenAPI 
-- Game: AppID 988330
addappid(988330)
addappid(988331, 1, "c9ce5c8f8e768533876a680db91e6bea7a91ec31bac4c1575e4def7fd87c26dd")
