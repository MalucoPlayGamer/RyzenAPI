-- Lua provided by RyzenAPI
-- Game: Game: Angels That Kill - The Final Cut

-- MAIN APPLICATION
addappid(383240)
-- Game: addappid(383240)

-- MAIN APP DEPOTS / PACKAGES
addappid(383241, 1, "97a81f04bd54bdfbfd34cba4fc5fe1fdd1808eb046f1014b9482f7510ee6afd8")
addappid(383242, 1, "111b13296e7d496b8c59a39fd268573a6bfc12e62bedac80aefea50082c1490b")
addappid(383243, 1, "1b7013223846ef2a484cee679d451fde498b67cc7c84ec7120378429d0423681")
addappid(406100, 0, "51d9b25a35c3afbe271e3ad9438f332e4028ce6465048eb6d7b11f34321f561b")
