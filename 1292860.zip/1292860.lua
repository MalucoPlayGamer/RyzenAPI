-- Lua provided by RyzenAPI
-- Game: 1292860

-- MAIN APPLICATION
addappid(1292860)
-- Game: addappid(1292860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292861, 1, "f85ec26566f46192cd44f291f44a8b7e10281c6d8acd013880761e1c9fda0f48")
