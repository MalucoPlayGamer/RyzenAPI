-- Lua provided by RyzenAPI 
-- Game: Where is Paradise ?
addappid(1746620)
addappid(1746621, 1, "03f5197d9a45a22e1fce002246d0b7fed0428108cbb52b5998d4f1e3404f27cf")
