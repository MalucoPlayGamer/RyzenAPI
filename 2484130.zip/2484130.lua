-- Lua provided by RyzenAPI
-- Game: Fruitbus

-- MAIN APPLICATION
addappid(2484130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484131, 1, "e06ca0a7a669b63236ebd790bc956b0bb72bdc09bbdc69e3be2b90ea4e42ab31")

