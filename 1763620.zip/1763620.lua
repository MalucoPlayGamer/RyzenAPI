-- Lua provided by RyzenAPI 
-- Game: Obama
addappid(1763620)
addappid(1763621, 1, "c146b396e07094f27f8217ef21926f718b69794a258dece72cb98123c7128b4a")
