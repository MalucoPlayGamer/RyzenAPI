-- Lua provided by RyzenAPI
-- Game: addappid(1022492)

-- MAIN APPLICATION
addappid(1022492)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022492,0,"44c3675f2d28b4eb6842cd5612f9dd629d9b447ce77e700bf81b7f46f6807c7b")
