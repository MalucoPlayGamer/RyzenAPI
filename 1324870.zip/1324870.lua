-- Lua provided by RyzenAPI
-- Game: Game: AppID 1324870

-- MAIN APPLICATION
addappid(1324870)
-- Game: addappid(1324870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324871, 1, "132a89efa905eca8bad2dafb4ba6e0fa50568b31038243883d756cc180f08120")
