-- Lua provided by SkyAPI 
-- Game: AppID 1324870
addappid(1324870)
addappid(1324871, 1, "132a89efa905eca8bad2dafb4ba6e0fa50568b31038243883d756cc180f08120")
