-- Lua provided by RyzenAPI
-- Game: Drift King

-- MAIN APPLICATION
addappid(1469690)
-- Game: addappid(1469690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469691, 1, "7beee145d06ef48d64f690ddb5b69761a52d6215174898467e24ebfa74cdbc4d")
addappid(1469692, 1, "16465a182a294b2be3ede3467bdeb1137e1393b4421182aa5db887eac4937202")
