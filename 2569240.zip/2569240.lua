-- Lua provided by RyzenAPI
-- Game: addappid(2569240)

-- MAIN APPLICATION
addappid(2569240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569241, 1, "5d2a23915eee9c3222af7e607b0a89450bedcef53e93c22bd54f41d38600d9ac")
