-- Lua provided by RyzenAPI
-- Game: 710190

-- MAIN APPLICATION
addappid(710190)
addappid(749790)
-- Game: addappid(710190)

-- MAIN APP DEPOTS / PACKAGES
addappid(710191, 1, "3fe63bc3feb6f981dbf4d6c1574ff569b94c6cd0827cf95b420dc18d62896d9e")
