-- Lua provided by RyzenAPI
-- Game: Game: AppID 1909290

-- MAIN APPLICATION
addappid(1909290)
-- Game: addappid(1909290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909291, 1, "1e277bf0eae74994ddaba84daf5ebf8ce0c17ab5e26795740d08a9e8a2e60ec3")
