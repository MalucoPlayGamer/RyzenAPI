-- Lua provided by RyzenAPI
-- Game: AppID 703030

-- MAIN APPLICATION
addappid(703030)

-- MAIN APP DEPOTS / PACKAGES
addappid(703031, 1, "abf0d05ced50980a7495b0e2b6af829369963aa1c47629ad572260557bd5b069")
addappid(703032, 1, "88764c6fed7d6ca066d1b538aef0abd2e6fb5cb716fc7550aaeccc951ffa1511")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
