-- Lua provided by RyzenAPI
-- Game: Madhouse Madness: Streamer's Fate

-- MAIN APPLICATION
addappid(2358420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358421, 1, "2380fee8402b0c3de51d95129baa3053bad539f46d3cf1f227045d91ce357378")

