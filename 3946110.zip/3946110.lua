-- 3946110's Lua and Manifest Created by Hubcap Manifest
-- Fracture Field
-- Created: April 27, 2026 at 19:32:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3946110) -- Fracture Field
-- MAIN APP DEPOTS
addappid(3946111, 1, "1289c01d4dab9fc716f2590cec8294a1554f51333aadc8aaf9e03287ad0e69f8") -- Depot 3946111
setManifestid(3946111, "5110422667059102450", 251809996)