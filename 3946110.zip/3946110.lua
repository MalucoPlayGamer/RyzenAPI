-- Lua provided by RyzenAPI
-- Game: Fracture Field

-- MAIN APPLICATION
addappid(3946110) -- Fracture Field

-- MAIN APP DEPOTS / PACKAGES
addappid(3946111, 1, "1289c01d4dab9fc716f2590cec8294a1554f51333aadc8aaf9e03287ad0e69f8") -- Depot 3946111

