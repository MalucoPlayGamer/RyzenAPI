-- Lua provided by RyzenAPI
-- Game: addappid(2151700)

-- MAIN APPLICATION
addappid(2151700)
addappid(2201120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151701, 1, "a95706090534e6469528ecf5bb762a89c3b771716ae52d059d3f3adf09f6a83f")
