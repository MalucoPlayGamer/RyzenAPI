-- Lua provided by RyzenAPI
-- Game: Landlord's Super

-- MAIN APPLICATION
addappid(1127840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127841, 1, "0a229277ffcf451d070a5b31294f21f90b66c3a36eb1190d3a6682b5907c6183")
