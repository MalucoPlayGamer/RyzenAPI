-- Lua provided by RyzenAPI
-- Game: Model Melissa

-- MAIN APPLICATION
addappid(1160580)
-- Game: addappid(1160580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160581, 1, "68e3fcc027264cb76a9187c79fc283139e780675370295d89d54c30e78c00410")
