-- Lua provided by RyzenAPI
-- Game: Battle Life Online

-- MAIN APPLICATION
addappid(1068350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1068351, 1, "39373badd0856028a0a700aacd006bbf6d5423df67f7a158e8489ca92b06f351")

