-- Lua provided by RyzenAPI 
-- Game: Battle Life Online
addappid(1068350)
addappid(1068351, 1, "39373badd0856028a0a700aacd006bbf6d5423df67f7a158e8489ca92b06f351")
