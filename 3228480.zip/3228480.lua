-- Lua provided by RyzenAPI
-- Game: Game: AppID 3228480

-- MAIN APPLICATION
addappid(3228480)
-- Game: addappid(3228480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228481, 1, "0588ae1da0bde4c4b655bc64255feac9aee5c7f2c318d4094782ab62196a77a4")
