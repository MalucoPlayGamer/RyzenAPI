-- Lua provided by RyzenAPI
-- Game: 2402450

-- MAIN APPLICATION
addappid(2402450)
-- Game: addappid(2402450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402452,0,"9eec9a3cc70edb8bf6c47e78139f403be6a5c0fe90dadcdab9e22846da60a5e8")
addappid(2402453,0,"f75ea45679e2863432e212a5550bb6886748adc9c15324ae1429f892c89ae6e1")
