-- Lua provided by RyzenAPI
-- Game: AppID 2219660

-- MAIN APPLICATION
addappid(2219660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219661, 1, "76106ec1e3235669b2b4aaafb24e4d1e1b310de0109d294d7099381f81a48867")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2414100)
addappid(2414130)
addappid(2414830)
addappid(2414831)
addappid(2414832)
addappid(2414833)
addappid(2414960)
addappid(2421940)
addappid(2425390)
addappid(2433030)
addappid(2478630)
