-- Lua provided by SkyAPI 
-- Game: AppID 2219660
addappid(2219660)
addappid(2219661, 1, "76106ec1e3235669b2b4aaafb24e4d1e1b310de0109d294d7099381f81a48867")
