-- Lua provided by RyzenAPI
-- Game: Game: AppID 2219660

-- MAIN APPLICATION
addappid(2219660)
-- Game: addappid(2219660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219661, 1, "76106ec1e3235669b2b4aaafb24e4d1e1b310de0109d294d7099381f81a48867")
