-- Lua provided by SkyAPI 
-- Game: Path of Ra Soundtrack
addappid(2213320)
addappid(2213321, 1, "234cb81413e1315abd20fa8a13ff0c44d275f416a27189ba0e0100c451e3c623")
addappid(2213322, 1, "2fbab0a5b55192b876f4fa69c1cc03698ebba28506845af4eeec911a8f9cacba")
