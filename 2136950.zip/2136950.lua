-- Lua provided by RyzenAPI
-- Game: Forklift Extreme: Deluxe Edition

-- MAIN APPLICATION
addappid(2136950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2136951, 1, "2245ae1464afea266a78990919c66c1d405567b643de7a79f1385a3921b691cc")

