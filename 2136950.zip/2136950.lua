-- Lua provided by RyzenAPI 
-- Game: Forklift Extreme: Deluxe Edition
addappid(2136950)
addappid(2136951, 1, "2245ae1464afea266a78990919c66c1d405567b643de7a79f1385a3921b691cc")
