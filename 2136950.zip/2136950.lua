-- Lua provided by RyzenAPI
-- Game: Game: Forklift Extreme: Deluxe Edition

-- MAIN APPLICATION
addappid(2136950)
-- Game: addappid(2136950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136951, 1, "2245ae1464afea266a78990919c66c1d405567b643de7a79f1385a3921b691cc")
