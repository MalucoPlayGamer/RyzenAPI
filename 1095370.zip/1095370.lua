-- Lua provided by SkyAPI 
-- Game: AppID 1095370
addappid(1095370)
addappid(1095371, 1, "0cc63a7b211b9fb36760f2a5781c1a4e8188bca8a086eeaaefe0768039ee716f")
addappid(1102450)
