-- Lua provided by RyzenAPI
-- Game: March of Empires

-- MAIN APPLICATION
addappid(702320)

-- MAIN APP DEPOTS / PACKAGES
addappid(702321, 1, "39bb9e80daa8e2e44630d2623627b9c46e3b854ef6e5893423ecd5c5ce64300b")

