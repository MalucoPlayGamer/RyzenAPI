-- Lua provided by RyzenAPI
-- Game: addappid(368740)

-- MAIN APPLICATION
addappid(368740)
addappid(437620)

-- MAIN APP DEPOTS / PACKAGES
addappid(368741, 1, "e29f6f8e3978e81c17c77951fd9f952e9eac48e5f1200cdb3f84834f126144dc")
