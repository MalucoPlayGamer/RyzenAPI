-- Lua provided by RyzenAPI
-- Game: Sol Cesto

-- MAIN APPLICATION
addappid(2738490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738491, 1, "27cff6c7bfcd289e04d87efd458564e1cb038e14ccd8fa71717536a221c7f0d5")
