-- Lua provided by RyzenAPI 
-- Game: Sol Cesto
addappid(2738490)
addappid(2738491, 1, "27cff6c7bfcd289e04d87efd458564e1cb038e14ccd8fa71717536a221c7f0d5")
