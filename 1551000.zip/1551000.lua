-- Lua provided by RyzenAPI
-- Game: Captain Pawsome

-- MAIN APPLICATION
addappid(1551000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551001, 1, "9ce503bfffdacbe8b6d29608c339b308dfa49e8f74fb92576bd7daafa3ae6598")

