-- Lua provided by RyzenAPI
-- Game: 686640

-- MAIN APPLICATION
addappid(686640)
-- Game: addappid(686640)

-- MAIN APP DEPOTS / PACKAGES
addappid(686641, 1, "119b3dc62642d337c34286a2d6c9f9abd88ce8f79834f81464ab95a99e3dd891")
