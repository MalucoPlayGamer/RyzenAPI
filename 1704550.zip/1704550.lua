-- Lua provided by SkyAPI 
-- Game: TEST RE
addappid(1704550)
addappid(1704551, 1, "9d4f106a64d3b5e74609c3abe5e19f5b3e457ef4efded9ada1dc64f3f7375124")
addappid(3588720)
