-- Lua provided by RyzenAPI
-- Game: Meat Grinder: Hotdog Simulator

-- MAIN APPLICATION
addappid(3994680) -- Meat Grinder: Hotdog Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(3994681, 1, "f15d02c88c4e81f4bc4c3daeab2c9ec445d7406d71c9c247fd6a3daee32f4a0f") -- Depot 3994681

