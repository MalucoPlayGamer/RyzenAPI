-- 3994680's Lua and Manifest Created by Hubcap Manifest
-- Meat Grinder: Hotdog Simulator
-- Created: August 11, 2026 at 23:24:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3994680) -- Meat Grinder: Hotdog Simulator
-- MAIN APP DEPOTS
addappid(3994681, 1, "f15d02c88c4e81f4bc4c3daeab2c9ec445d7406d71c9c247fd6a3daee32f4a0f") -- Depot 3994681
setManifestid(3994681, "7370857606315914869", 341312789)