-- Lua provided by RyzenAPI
-- Game: Game: AppID 762880

-- MAIN APPLICATION
addappid(762880)
-- Game: addappid(762880)

-- MAIN APP DEPOTS / PACKAGES
addappid(762881, 1, "0f5ea9aaf8a5ccdb247228f78503c38161f6cd10990b3621c79b12b06b6a29d7")
