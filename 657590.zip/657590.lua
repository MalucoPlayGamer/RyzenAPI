-- Lua provided by RyzenAPI
-- Game: AppID 657590

-- MAIN APPLICATION
addappid(657590)

-- MAIN APP DEPOTS / PACKAGES
addappid(657591, 1, "88607638a76df0d597bb3e8a3b916efadd19f47e32cedb98ddda09ab1878187f")
