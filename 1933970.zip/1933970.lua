-- Lua provided by SkyAPI 
-- Game: Anime Studio Story
addappid(1933970)
addappid(1933971, 1, "cb262b3b24903f21820e8d84f1cc20269be37b74d418a46fe372f489f8a6c9d8")
