-- Lua provided by RyzenAPI
-- Game: Game: Anime Studio Story

-- MAIN APPLICATION
addappid(1933970)
-- Game: addappid(1933970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933971, 1, "cb262b3b24903f21820e8d84f1cc20269be37b74d418a46fe372f489f8a6c9d8")
