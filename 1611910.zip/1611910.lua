-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Chaos Gate - Daemonhunters

-- MAIN APPLICATION
addappid(1611910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611911, 1, "86237e0895ee119ad5f6adfe0435ea25f199a14eb12f10f69cd84330b6d22720")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1804350)
addappid(1883510)
addappid(2126610)
addappid(2421890)
