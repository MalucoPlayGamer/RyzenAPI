-- Lua provided by RyzenAPI
-- Game: Game: Warhammer 40,000: Chaos Gate - Daemonhunters

-- MAIN APPLICATION
addappid(1611910)
-- Game: addappid(1611910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611911, 1, "86237e0895ee119ad5f6adfe0435ea25f199a14eb12f10f69cd84330b6d22720")
