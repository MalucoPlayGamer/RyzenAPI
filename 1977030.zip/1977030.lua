-- Lua provided by RyzenAPI
-- Game: Game: Abort, Retry, Fail

-- MAIN APPLICATION
addappid(1977030)
-- Game: addappid(1977030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977031, 1, "464b360c0f528649bc5e5aadaf49d78059b6603f0a3a21610e40ce3275299326")
