-- Lua provided by RyzenAPI 
-- Game: Dark Man
addappid(949720)
addappid(949721, 1, "259f20fd97ffee28bd9043219255aa41b1d13e06308d8267222813aa2f22205b")
