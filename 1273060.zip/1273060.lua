-- Lua provided by RyzenAPI
-- Game: Aliens Love Beefs

-- MAIN APPLICATION
addappid(1273060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273061, 1, "77dd014ac912fb342e4700d8a1dac868e247e977fd6b4c42126d9b8f77b5154b")

