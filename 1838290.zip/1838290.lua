-- Lua provided by SkyAPI 
-- Game: LOUD: My Road to Fame
addappid(1838290)
addappid(1838291, 1, "2ff17d0131c2233f6543e878eec8d75207ede1696537a9b3a0026508d8ec58c9")
addappid(2165800)
