-- Lua provided by RyzenAPI
-- Game: LOUD: My Road to Fame

-- MAIN APPLICATION
addappid(1838290)
addappid(2165800)
-- Game: addappid(1838290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838291, 1, "2ff17d0131c2233f6543e878eec8d75207ede1696537a9b3a0026508d8ec58c9")
