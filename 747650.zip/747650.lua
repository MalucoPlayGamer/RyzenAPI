-- Lua provided by RyzenAPI
-- Game: Game: The Padre

-- MAIN APPLICATION
addappid(747650)
-- Game: addappid(747650)

-- MAIN APP DEPOTS / PACKAGES
addappid(747651, 1, "473d585cb35c3e1b53adc548e0244efe10006c4dc806c6c10066863fa0216607")
addappid(747652, 1, "7607ab962ee9740dbf23f1f91f27b3b4839d468d75fc66b94d5f8ca68e2f6831")
addappid(747653, 1, "3b44cf66d044a051d44442d843a98c16e2fb3f9c6e6c4af9709a302a575690bb")
