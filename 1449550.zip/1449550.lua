-- Lua provided by RyzenAPI
-- Game: Chinese Empire

-- MAIN APPLICATION
addappid(1449550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449551, 1, "436d2abb3fd5eefe9963a54ce87e2b2d78e014d94ed77661c31a333c5e3a50b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
