-- Lua provided by RyzenAPI
-- Game: Game: Chinese Empire

-- MAIN APPLICATION
addappid(1449550)
-- Game: addappid(1449550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449551, 1, "436d2abb3fd5eefe9963a54ce87e2b2d78e014d94ed77661c31a333c5e3a50b0")
