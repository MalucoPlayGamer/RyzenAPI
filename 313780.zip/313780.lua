-- Lua provided by RyzenAPI
-- Game: Game: Conarium

-- MAIN APPLICATION
addappid(313780)
addappid(651510)
-- Game: addappid(313780)

-- MAIN APP DEPOTS / PACKAGES
addappid(313781, 1, "ee2ee391cd9021988fb50c4fe904697513b511740123188476b3721ed4af9d2f")
addappid(313782, 1, "a65d9fce309566c486a6da7c0830bbaaf15ce1c992464076cd078fd3c3849bda")
addappid(313783, 1, "9f0c8b8143b28258df255bdd20809503637cad29436e8db58e3feec2c3055462")
addappid(313784, 1, "31c1986a05d78339a20f734189af44ee35d6b0f6b31a0dbe7e753f3db1a7ee51")
