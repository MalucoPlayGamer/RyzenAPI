-- Lua provided by RyzenAPI
-- Game: Game: Breath of Ghosts

-- MAIN APPLICATION
addappid(1991900)
-- Game: addappid(1991900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991901, 1, "fe568c04a5b350ca359c5d28b993fbaf7e35cb74cf67ceb221fe3e1ebf98dfb9")
