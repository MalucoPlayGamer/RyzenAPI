-- Lua provided by RyzenAPI
-- Game: addappid(2707900)

-- MAIN APPLICATION
addappid(2707900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707901, 1, "2e0e60376cde0146aa0a48e89dc6cb0910d25cd67ce1dc4fc5e6f69b8796f2e2")
