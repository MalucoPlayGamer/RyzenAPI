-- Lua provided by SkyAPI 
-- Game: AppID 1237330
addappid(1237330)
addappid(1237331, 1, "91409a4bf1c56c8c4996eda7f92d6c77e50fd9fe46b6bd6f47b76086a9cb2851")
