-- Lua provided by RyzenAPI
-- Game: AppID 279640

-- MAIN APPLICATION
addappid(279640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(279641, 1, "4869a59e4ce264be229a30115e986c2beedf4a2dcb025192c460d5fa3a900f09")

