-- Lua provided by RyzenAPI
-- Game: Possessed

-- MAIN APPLICATION
addappid(607210)

-- MAIN APP DEPOTS / PACKAGES
addappid(607211, 1, "abf440056407e35fad7bbce132a7b3ec5a4fd1b2e27af757726c5c40c668b29a")
