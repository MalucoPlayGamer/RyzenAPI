-- Lua provided by RyzenAPI
-- Game: 2825300

-- MAIN APPLICATION
addappid(2825300)
-- Game: addappid(2825300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825301, 1, "130db56aad99d6715c33705838e29a5dfb84a2ea39635e743c4f0b4f81ffb7de")
