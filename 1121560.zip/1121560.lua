-- Lua provided by RyzenAPI
-- Game: AppID 1121560

-- MAIN APPLICATION
addappid(1121560)
addappid(1154590)
addappid(1154591)
addappid(1154592)
addappid(1154593)
addappid(1154594)
addappid(1154595)
addappid(1154596)
addappid(1154597)
addappid(1188600)
addappid(1188602)
addappid(1188603)
addappid(1188604)
addappid(1188605)
addappid(1188606)
addappid(1188607)
addappid(1188608)
addappid(1188609)
addappid(1188610)
addappid(1188611)
addappid(1188612)
addappid(1188613)
addappid(1188614)
addappid(1188615)
addappid(1188616)
addappid(1188617)
addappid(1188618)
addappid(1188619)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121561, 1, "c25c7c608f0a0a502f4c292abd2728c319fe27ad39145d6da7e5976ba83d2fa2")
addappid(1188601, 0, "7378106d64320a9c03f2fd6e1aea2e03d6d809532719c9446511990185f8b158")
addappid(1188620, 0, "ef158d5a2d6acc5ce19051ddd1324ba81da79117b78324d67437dd4392cd0505")
addappid(1604860, 0, "178b311809b024a9aa8cc6557ebea125a96f72d93d184a5980b2d66349f7ec3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
