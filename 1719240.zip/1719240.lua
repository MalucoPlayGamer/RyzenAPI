-- Lua provided by RyzenAPI
-- Game: addappid(1719240)

-- MAIN APPLICATION
addappid(1719240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719241, 1, "a06717f83f7121db82af97390c9fb589bb4d5ae1495ab05638531600ff3dfa29")
