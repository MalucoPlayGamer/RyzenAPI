-- Lua provided by RyzenAPI
-- Game: Combat Mission: Final Blitzkrieg

-- MAIN APPLICATION
addappid(2676000)
addappid(2736420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2676001, 1, "d8326e7c0e6b4313f2a51be4b322e263fea8304f2d272755bfb200295e027736")
addappid(2676002, 1, "ce27422d3bd5979ec919a1ecbaa0710654cf2847f2be05942a861a0a01a7dccc")

