-- Lua provided by RyzenAPI
-- Game: Saleblazers Dedicated Server (Beta)

-- MAIN APPLICATION
addappid(3099600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099601, 1, "f770bbb0462c051987e8f43ae57019e28a5352b3b8a6fc046912fdf5ccd79318")

