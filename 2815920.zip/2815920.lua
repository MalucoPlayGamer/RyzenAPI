-- Lua provided by SkyAPI 
-- Game: AppID 2815920
addappid(2815920)
addappid(2815921, 1, "a6d521c67892c462ac316360737482e84af3d3420d2e34d2a1e590c6de3dd61f")
