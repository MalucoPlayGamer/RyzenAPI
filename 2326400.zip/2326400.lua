-- Lua provided by RyzenAPI 
-- Game: Bombing!! 2: A Graffiti Paradise Demo
addappid(2326400)
addappid(2326401, 1, "2cd88f93f02bd1928832e673b71b81ff80fe7b08a1616e9e6ab4aca97dfbe4fb")
