-- Lua provided by RyzenAPI
-- Game: Protect My Cheese

-- MAIN APPLICATION
addappid(2027130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027131, 1, "8fb7949d5985c208b6e940038f6863faeebc35293fe549c9d6f99456c82aabc9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
