-- Lua provided by RyzenAPI
-- Game: addappid(2027130)

-- MAIN APPLICATION
addappid(2027130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027131, 1, "8fb7949d5985c208b6e940038f6863faeebc35293fe549c9d6f99456c82aabc9")
