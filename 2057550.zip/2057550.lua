-- Lua provided by RyzenAPI
-- Game: Game: 我在地球修仙有系统

-- MAIN APPLICATION
addappid(2057550)
-- Game: addappid(2057550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057551, 1, "68b5dbf092adbf04a973b5b1fff2d125bbc206ae50c13932ee9d0512ab23af6f")
