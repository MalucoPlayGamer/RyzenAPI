-- Lua provided by RyzenAPI
-- Game: addappid(2641460)

-- MAIN APPLICATION
addappid(2641460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641461, 1, "1d82e241139cbd2f907c93d611308b174feec8e9b9069fdc00c1bf12fe6d78a4")
