-- Lua provided by RyzenAPI 
-- Game: Roll the Ball
addappid(2641460)
addappid(2641461, 1, "1d82e241139cbd2f907c93d611308b174feec8e9b9069fdc00c1bf12fe6d78a4")
