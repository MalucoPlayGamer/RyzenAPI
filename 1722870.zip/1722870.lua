-- Lua provided by RyzenAPI
-- Game: AppID 1722870

-- MAIN APPLICATION
addappid(1722870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722871, 1, "8af2fdee75724efcc53f8c0ba0bbc226840f6c0395aabbdbdfa781ea1995bb51")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3550040)
addappid(4356510)
