-- Lua provided by RyzenAPI 
-- Game: Muerte's Arena
addappid(863170)
addappid(863171, 1, "37a8928926307c8cc93323864a2795832a3525465ab817526ab2a339e42b97cf")
