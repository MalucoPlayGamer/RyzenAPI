-- Lua provided by RyzenAPI
-- Game: Game: Muerte's Arena

-- MAIN APPLICATION
addappid(863170)
-- Game: addappid(863170)

-- MAIN APP DEPOTS / PACKAGES
addappid(863171, 1, "37a8928926307c8cc93323864a2795832a3525465ab817526ab2a339e42b97cf")
