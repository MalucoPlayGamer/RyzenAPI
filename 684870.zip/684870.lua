-- Lua provided by RyzenAPI
-- Game: Game: Spiral Splatter

-- MAIN APPLICATION
addappid(684870)
-- Game: addappid(684870)

-- MAIN APP DEPOTS / PACKAGES
addappid(684871, 1, "ae15782812347d489a3538a684f91b45d0f731bf7c788752d1380062f2fc3e13")
addappid(684872, 1, "de9971736a0f9d513d28d40e3049b7f443cd2dfc0bb2380514b6e96e80f3a8d3")
addappid(684873, 1, "32a2379aa79d44513ba9e59bf9b006af1842d0b08b88b2baba20e60ca9dc3408")
