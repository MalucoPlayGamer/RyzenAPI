-- Lua provided by RyzenAPI
-- Game: Putt-Putt® and Pep's Balloon-o-Rama

-- MAIN APPLICATION
addappid(284000)

-- MAIN APP DEPOTS / PACKAGES
addappid(284001, 1, "c051b4ca4d82e7466a61d77d61f5d88cf0cd4107683c7513028cd10973774cc4")
addappid(284004, 1, "33f79c5cf3bfc88cdbf321e0260b83003000e59c91faaae991513621b981461d")
addappid(284005, 1, "5e17a44d73e1b673bbbad91cbe237d201bf62668d3154d17c3364828344313be")

