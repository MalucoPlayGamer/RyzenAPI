-- Lua provided by RyzenAPI
-- Game: 2919660

-- MAIN APPLICATION
addappid(2919660)
-- Game: addappid(2919660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919661, 1, "fffb0c1766e4e0e618b9c24d4066beaa43b3852d2579b6adda88dc1f6b02d238")
