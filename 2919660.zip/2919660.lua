-- Lua provided by RyzenAPI
-- Game: JudgeSim

-- MAIN APPLICATION
addappid(2919660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919661, 1, "fffb0c1766e4e0e618b9c24d4066beaa43b3852d2579b6adda88dc1f6b02d238")

