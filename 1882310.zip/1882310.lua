-- Lua provided by RyzenAPI
-- Game: 1882310

-- MAIN APPLICATION
addappid(1882310)
-- Game: addappid(1882310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882311, 1, "75673ec62ee2a06cfbc680990033377e5d1dd8a82b895bb82e1cf467bbf91dde")
