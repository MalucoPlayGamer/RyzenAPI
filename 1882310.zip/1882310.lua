-- Lua provided by SkyAPI 
-- Game: Creature Lab Demo
addappid(1882310)
addappid(1882311, 1, "75673ec62ee2a06cfbc680990033377e5d1dd8a82b895bb82e1cf467bbf91dde")
