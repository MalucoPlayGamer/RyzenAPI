-- Lua provided by RyzenAPI
-- Game: Logic World Dedicated Server

-- MAIN APPLICATION
addappid(1252670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252671, 1, "b610d96dcb376f9d3270d3ea7ebf55dfd1d383b238b20410c9ae759d5fa4fb4c")
