-- Lua provided by RyzenAPI
-- Game: 1104710

-- MAIN APPLICATION
addappid(1104710)
-- Game: addappid(1104710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104711, 1, "b8bc2bd455e54d046723646f109cda054427435781b00ecb223da14a3acf344b")
