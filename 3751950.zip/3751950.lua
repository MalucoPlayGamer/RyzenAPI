-- Lua provided by RyzenAPI 
-- Game: Assassin's Creed Black Flag Resynced
addappid(3751950)
addappid(3751951,1,"?")