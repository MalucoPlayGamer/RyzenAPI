-- Lua provided by RyzenAPI
-- Game: addappid(3751950)

-- MAIN APPLICATION
addappid(3751950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751951,1,"?")
