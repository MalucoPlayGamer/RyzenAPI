-- Lua provided by RyzenAPI
-- Game: Assassin's Creed Black Flag Resynced

-- MAIN APPLICATION
addappid(3751950)
-- Game: addappid(3751950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751951,1,"?")
