-- Lua provided by RyzenAPI
-- Game: 3751950

-- MAIN APPLICATION
addappid(3751950)
-- Game: addappid(3751950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751951,1,"?")
