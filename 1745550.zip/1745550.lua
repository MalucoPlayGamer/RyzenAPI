-- Lua provided by RyzenAPI
-- Game: Axilon: Legend of Artifacts - Prologue

-- MAIN APPLICATION
addappid(1745550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745551, 1, "4eed9a2a918b7185258b4797a795fc88df3cca15fa5ee9e5cf01d316d2742ed8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
