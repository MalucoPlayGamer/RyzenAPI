-- Lua provided by RyzenAPI
-- Game: addappid(1745550)

-- MAIN APPLICATION
addappid(1745550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745551, 1, "4eed9a2a918b7185258b4797a795fc88df3cca15fa5ee9e5cf01d316d2742ed8")
