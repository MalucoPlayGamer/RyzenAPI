-- Lua provided by RyzenAPI
-- Game: 1202640

-- MAIN APPLICATION
addappid(1202640)
addappid(1202641)
-- Game: addappid(1202640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202642,0,"f59a7926d9e9533b26c705dd8825d50944a845171e980684ceb86ce13b0cb1dc")
