-- Lua provided by RyzenAPI
-- Game: 492400

-- MAIN APPLICATION
addappid(492400)
-- Game: addappid(492400)

-- MAIN APP DEPOTS / PACKAGES
addappid(492401, 1, "8f0a533877b4c6e24096d1f794e0879f0e8ab522b38ff1a6408b2c26cddba73f")
