-- Lua provided by RyzenAPI
-- Game: AppID 345370

-- MAIN APPLICATION
addappid(345370)
-- Game: addappid(345370)

-- MAIN APP DEPOTS / PACKAGES
addappid(345371, 1, "ec67d7097f3cbd7b2b2fbfcbaadd805fb26f28f043eed4203619ca5773dd824d")
addappid(345373, 1, "c4f9df83aa8475583cb43158b1affd24494481c9f54602f98e6ec1e6c56817a8")
