-- Lua provided by RyzenAPI
-- Game: PunjiVR: The Vietnam War

-- MAIN APPLICATION
addappid(1900020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900021, 1, "9dea3ca9c33f13c7b61ef8b4e2a06ffb51f55e580488bf8ec7318a628afaa4da")
