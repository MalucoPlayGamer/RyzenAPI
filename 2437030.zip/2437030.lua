-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: FSDesigns - Pensacola International Airport

-- MAIN APPLICATION
addappid(2437030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437030,0,"3d8629cd436059b78764ff21b5c14d6a39e04ba6514b7d35adb0ec633b97d043")

