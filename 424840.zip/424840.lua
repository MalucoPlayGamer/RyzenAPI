-- Lua provided by RyzenAPI
-- Game: AppID 424840

-- MAIN APPLICATION
addappid(424840)
addappid(584090)
addappid(584091)
addappid(584092)
addappid(584094)
addappid(584095)
addappid(584096)
addappid(584097)
addappid(640920)

-- MAIN APP DEPOTS / PACKAGES
addappid(424841, 1, "1823f166b7f7161144cc3fb35ba96c0c8526183cf77e66127c44b152c1fcad7e")
addappid(584093, 0, "55a230ea8309169f6d9a419934d5451c5a403fd07d721794c43e2ec41317d9ea")
addappid(601710, 0, "6ef5cd05ac17d226a1897c8bd1cee696e7ecd67372f84f357a61b1df8aa69949")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
