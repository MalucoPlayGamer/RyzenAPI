-- Lua provided by RyzenAPI
-- Game: AppID 2000300

-- MAIN APPLICATION
addappid(2000300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000301, 1, "4cb27ce84233b4cfa168175d8b8e6f46e273ba65d67b77eec024ffd6ce873b24")

