-- Lua provided by RyzenAPI
-- Game: 1351500

-- MAIN APPLICATION
addappid(1351500)
-- Game: addappid(1351500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351501, 1, "1044fcaa75fbdf67678abf9244c9d1b5080b6cb4ae9102238dff50fce4b04947")
