-- Lua provided by RyzenAPI
-- Game: Mana Chess

-- MAIN APPLICATION
addappid(1911640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1911641, 1, "216544496ffb36e50cb065e89d6eed66165698372621e011dabbbe692b84bc62")

