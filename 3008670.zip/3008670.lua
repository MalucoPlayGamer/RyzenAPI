-- Lua provided by RyzenAPI
-- Game: Poppy Playtime - Chapter 4

-- MAIN APPLICATION
addappid(3008670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3008670,0,"05af48230917e5f7df38d99935306907947f276d13191bc0853a0338fc295fa7")
