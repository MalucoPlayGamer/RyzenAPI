-- Lua provided by RyzenAPI
-- Game: 残世界的鸢尾花

-- MAIN APPLICATION
addappid(1669330)
-- Game: addappid(1669330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669331, 1, "1b9f0a4f8349d4365a8f8b338c55579275b85ed1d3880999c08322e3fbf4862d")
