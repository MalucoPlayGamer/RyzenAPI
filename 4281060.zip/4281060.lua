-- 4281060's Lua and Manifest Created by Hubcap Manifest
-- Police Officer
-- Created: August 26, 2026 at 12:22:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4281060) -- Police Officer
-- MAIN APP DEPOTS
addappid(4281061, 1, "e3641aac8c628b8c06445994bc366962018ac491ae4e72578a63ee45f0e8550b") -- Depot 4281061
setManifestid(4281061, "2205971080125955834", 5149078775)