-- Lua provided by RyzenAPI
-- Game: Police Officer

-- MAIN APPLICATION
addappid(4281060) -- Police Officer

-- MAIN APP DEPOTS / PACKAGES
addappid(4281061, 1, "e3641aac8c628b8c06445994bc366962018ac491ae4e72578a63ee45f0e8550b") -- Depot 4281061

