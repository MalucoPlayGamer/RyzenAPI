-- Lua provided by RyzenAPI
-- Game: StreetCraft

-- MAIN APPLICATION
addappid(463540)

-- MAIN APP DEPOTS / PACKAGES
addappid(463541, 1, "54fa19436667741efb12036ed0bab296cd834e2c930c4fe8ace636d555da14ed")
