-- Lua provided by RyzenAPI
-- Game: Prehistoric Kingdom: Soundtrack, Vol. 1

-- MAIN APPLICATION
addappid(2563080)
-- Game: addappid(2563080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563081, 1, "289938b70cf7122be427ebb2022fd328488ce441f60555c2104279d9768e76d9")
addappid(2563082, 1, "adcbc7238b98b33055bfb7ee198bec66e7975b6565140a0f04d7716e9acd7ca4")
