-- Lua provided by RyzenAPI
-- Game: Game: Pickup One

-- MAIN APPLICATION
addappid(2004200)
-- Game: addappid(2004200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004201, 1, "47db7b0d4e11c1fa6675281a685cad9dbc6e4b409852f4f3c66d54a3cc1da8e8")
