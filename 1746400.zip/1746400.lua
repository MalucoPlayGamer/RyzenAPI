-- Lua provided by RyzenAPI
-- Game: addappid(1746400)

-- MAIN APPLICATION
addappid(1746400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746401, 1, "8019f15f3c3deae553eb558fff03f80a5e3aa4de74d3075da7f2bd45decceb1b")
