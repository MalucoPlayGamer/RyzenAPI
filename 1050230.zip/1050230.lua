-- Lua provided by RyzenAPI 
-- Game: Dodge Bubble
addappid(1050230)
addappid(1050231, 1, "82d6717d81d2b15bbdd2c96350e9f1ba311733e7d0c0c4efd918d65b3c3b1af5")
