-- Lua provided by RyzenAPI
-- Game: Potionomics

-- MAIN APPLICATION
addappid(1874490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874491, 1, "a12f0091b98d8f7f947a5967cc17f029dbe9b491e834e3fac1e0b446bbb933e1")

