-- Lua provided by RyzenAPI
-- Game: 最后的仙门 The last Practice Sect

-- MAIN APPLICATION
addappid(1942440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942441, 1, "8ddd156bd3bf1ab85224bdb5e8f57c9b9ecb0c0a86105b5bc61fcfaabbd7c5e3")

