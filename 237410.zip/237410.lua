-- Lua provided by RyzenAPI
-- Game: Insurgency Dedicated Server

-- MAIN APPLICATION
addappid(237410)

-- MAIN APP DEPOTS / PACKAGES
addappid(237411, 1, "9cab8b2aee545fb0bd6558cf69bf0dc6e9453b7cf8881d64989662d934991a40")

