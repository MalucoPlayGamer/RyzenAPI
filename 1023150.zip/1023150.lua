-- Lua provided by RyzenAPI
-- Game: Cyborg Invasion Shooter 3: Savior Of The World

-- MAIN APPLICATION
addappid(1023150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023151, 1, "6d2153a9848b73b7dee201a9b8b2a116665b02d82ee31f1425928db194d13d6b")
