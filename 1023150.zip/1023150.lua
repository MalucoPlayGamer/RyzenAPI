-- Lua provided by RyzenAPI
-- Game: Cyborg Invasion Shooter 3: Savior Of The World

-- MAIN APPLICATION
addappid(1023150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023151, 1, "6d2153a9848b73b7dee201a9b8b2a116665b02d82ee31f1425928db194d13d6b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
