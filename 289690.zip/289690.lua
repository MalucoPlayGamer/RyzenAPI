-- Lua provided by RyzenAPI
-- Game: Lara Croft and the Temple of Osiris

-- MAIN APPLICATION
addappid(289690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(289691, 1, "b10f698174f4dbeecce8fb2cd9ea61540d3dbc4e54746c1043dba9a4b923425d")
addappid(289692, 1, "a29f2d33a6ca78b72e7535a55d29c7e08b8c5a815f642b90d98c1c8d4b2e9dcd")
addappid(318870, 0, "6a0d064a338952b978ac921419b4504be201c64c6fc15a45751ce180318d066c")
addappid(318871, 0, "7ceacba22e66e45520702a1b964117521d01fe03c9c16d6c1df75f72deaccbd2")
addappid(318872, 0, "f82d4e01e307caf2a294c14938dac12476fe2f092e6b7c350bc0ea3575727182")
addappid(318873, 0, "f8f0daf78b28820f90ccbc39cdfef09407697c664681327e1f5fec1ae9c1b622")
addappid(318874, 0, "858e1fa2d5bb45a52764e186b4370823f5631fa2b305b275e33a3c7be6457212")
addappid(318875, 0, "199afb7f4db9eb40f8e84cb070023a9412a7b055ebf3633189adb287239a2b7e")
