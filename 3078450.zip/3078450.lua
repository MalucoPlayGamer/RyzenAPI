-- Lua provided by RyzenAPI
-- Game: Lethal Women: World of Femdom and Espionage Demo

-- MAIN APPLICATION
addappid(3078450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078453,0,"b0d6a63d747769fec7a05f37e7b27823535bb6b136965c7b7cf85d72f041e1d8")
