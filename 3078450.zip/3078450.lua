-- Lua provided by RyzenAPI
-- Game: 3078450

-- MAIN APPLICATION
addappid(3078450)
-- Game: addappid(3078450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078453,0,"b0d6a63d747769fec7a05f37e7b27823535bb6b136965c7b7cf85d72f041e1d8")
