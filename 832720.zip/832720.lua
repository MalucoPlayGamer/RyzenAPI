-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Brewmaster

-- MAIN APPLICATION
addappid(832720)
-- Game: addappid(832720)

-- MAIN APP DEPOTS / PACKAGES
addappid(832721, 1, "ccbeced1efa8ecca20a2ebc09ff9923250e22409791400aae57a8db4dda8dc65")
