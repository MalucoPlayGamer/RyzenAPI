-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228988)
addappid(444970)
addappid(444971)
-- Game: addappid(444970)

-- MAIN APP DEPOTS / PACKAGES
addappid(444972,0,"44d370f5a13b71de59ae5a37af0204521823d57bdefabb580731f57149971096")
