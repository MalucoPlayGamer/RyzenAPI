-- Lua provided by RyzenAPI
-- Game: 808190

-- MAIN APPLICATION
addappid(808190)
-- Game: addappid(808190)

-- MAIN APP DEPOTS / PACKAGES
addappid(808191, 1, "1f8a0ef02601f6fa88419c63e960ed6b4a720bc46be697537482876f8def7a27")
