-- Lua provided by RyzenAPI
-- Game: Super Sonic Racer

-- MAIN APPLICATION
addappid(808190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(808191, 1, "1f8a0ef02601f6fa88419c63e960ed6b4a720bc46be697537482876f8def7a27")
