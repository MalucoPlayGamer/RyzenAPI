-- Lua provided by RyzenAPI
-- Game: 1433680

-- MAIN APPLICATION
addappid(1433680)
-- Game: addappid(1433680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433680,0,"4b4be265cf6556d14fb0119e7df29c233fb1451fd67943de2d9015b493d3f6da")
