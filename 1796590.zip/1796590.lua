-- Lua provided by SkyAPI 
-- Game: Adult Puzzles - Pole Dancer
addappid(1796590)
addappid(1796591, 1, "6289769c14be0d385bb51103561465fdfb7bd0d29c9f42250ae71bbcbb7dd910")
addappid(1797730, 0, "f51e16bbdbdefd58131d798181b2a42e2f3734e34614c9ae7f115ea3e6c747f7")
