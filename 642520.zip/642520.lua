-- Lua provided by RyzenAPI
-- Game: addappid(642520)

-- MAIN APPLICATION
addappid(642520)

-- MAIN APP DEPOTS / PACKAGES
addappid(642521, 1, "2e3e84d5127fb6da819b2975d769210f13e270f533e9f61b774c8df30be7b10f")
