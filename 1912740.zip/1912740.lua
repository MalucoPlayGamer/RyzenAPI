-- Lua provided by RyzenAPI
-- Game: Word Game Official Art Book

-- MAIN APPLICATION
addappid(1912740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912740,0,"0dac5bdfa4b604b2d33b612ea2b8b7646f6870bb2fc846a5fe95b0822eed8639")

