-- Lua provided by RyzenAPI
-- Game: ESports Club

-- MAIN APPLICATION
addappid(656200)
addappid(853840)
addappid(1010440)

-- MAIN APP DEPOTS / PACKAGES
addappid(656201, 1, "cbf5d41a254e849bd1d217ee52191c6ffb42051e844f647e0ba964e28f12bd6a")
addappid(656202, 1, "399808ef39abd836a9384f8f5d9e2c20066d97c7384858dc666ae55bdae35501")
