-- Lua provided by RyzenAPI
-- Game: Wormies

-- MAIN APPLICATION
addappid(4058290)

-- MAIN APP DEPOTS / PACKAGES
addappid(4058291,0,"618f6c6215de6145bb3b3b55ce968d93f85345b62b34f4dfb9b45c981901b423")

