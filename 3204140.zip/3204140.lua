-- Lua provided by RyzenAPI
-- Game: Novel Rogue

-- MAIN APPLICATION
addappid(3204140)
addappid(3662160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3204141,0,"ce7274bc0fd32e642a1848f43f0e20d8e6489ccb88e9f97fcc6e30aa7b80e07f")

