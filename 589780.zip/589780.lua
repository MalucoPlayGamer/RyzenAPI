-- Lua provided by RyzenAPI
-- Game: The Red Strings Club

-- MAIN APPLICATION
addappid(589780)

-- MAIN APP DEPOTS / PACKAGES
addappid(589781, 1, "8fc9a1e1ef850da5c54781ffa11737b286ae543226598bfebedc6c21a142144d")
addappid(589782, 1, "62d612dcce61c8ed1127040f6309b28b4c5e7c27b7aa61b897ed5fca67595bac")
addappid(589783, 1, "fd00821f95ccb33bb01823594786b206f78e0a75340b11571a7cc7bf205da5de")

