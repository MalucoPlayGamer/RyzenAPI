-- Lua provided by RyzenAPI 
-- Game: Rocket Bot Royale
addappid(1748390)
addappid(1748391, 1, "584daa2a12961d9e4c190ee5f59596e20ece2b52e55fbb6c0e828fc6d435e413")
addappid(1748392, 1, "52d7226294898dfff7be38d80856f239d24a241c338dd3c0534845adeb3ed943")
