-- Lua provided by RyzenAPI
-- Game: Flats Full of Cats

-- MAIN APPLICATION
addappid(4098230)
addappid(4155080)
addappid(4155090)
addappid(4155100)
addappid(4155110)
addappid(4728300)
addappid(4728310)
addappid(4728320)
addappid(4728330)

