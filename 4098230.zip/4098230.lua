-- Lua provided by RyzenAPI
-- Game: Flats Full of Cats

-- MAIN APPLICATION
addappid(4098230)
