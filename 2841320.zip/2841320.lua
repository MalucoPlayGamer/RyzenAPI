-- Lua provided by RyzenAPI
-- Game: Foobar Zero

-- MAIN APPLICATION
addappid(2841320)
