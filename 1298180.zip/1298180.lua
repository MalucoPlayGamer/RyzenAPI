-- Lua provided by RyzenAPI
-- Game: Pair Matching Puzzle Connect

-- MAIN APPLICATION
addappid(1298180)
addappid(1303830)
addappid(1307170)
addappid(1311260)
addappid(1316810)
addappid(1319490)
addappid(1326300)
addappid(1328550)
addappid(1333550)
addappid(1334410)
addappid(1334930)
addappid(1337450)
addappid(1339910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298181, 1, "de09ab254035855238036f8def4600cdecd3204bf0efb78b228635a2cedcf6aa")
