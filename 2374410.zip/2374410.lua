-- Lua provided by RyzenAPI
-- Game: Game: My Hero After the Fall

-- MAIN APPLICATION
addappid(2374410)
-- Game: addappid(2374410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374411, 1, "abb6f6ab0c0eb7a38d56bb3fe8895169cc5f06a09955c78e284578387628989e")
