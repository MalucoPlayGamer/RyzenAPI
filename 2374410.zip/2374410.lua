-- Lua provided by RyzenAPI 
-- Game: My Hero After the Fall
addappid(2374410)
addappid(2374411, 1, "abb6f6ab0c0eb7a38d56bb3fe8895169cc5f06a09955c78e284578387628989e")
