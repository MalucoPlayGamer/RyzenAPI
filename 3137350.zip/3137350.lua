-- Lua provided by RyzenAPI
-- Game: VMX

-- MAIN APPLICATION
addappid(3137350)
addappid(3137350) -- Motion Soccer

-- MAIN APP DEPOTS / PACKAGES
addappid(3137351,0,"2bb669932b7cf25317e237bf24377236c0ec3d19f455e83e0b178d0d8ddd8e95")
addappid(3137351, 1, "2bb669932b7cf25317e237bf24377236c0ec3d19f455e83e0b178d0d8ddd8e95") -- Depot 3137351

