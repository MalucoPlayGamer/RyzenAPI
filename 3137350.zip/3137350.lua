-- Lua provided by RyzenAPI
-- Game: Motion Soccer PRO

-- MAIN APPLICATION
addappid(3137350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137351,0,"2bb669932b7cf25317e237bf24377236c0ec3d19f455e83e0b178d0d8ddd8e95")

