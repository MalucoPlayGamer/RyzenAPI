-- Lua provided by RyzenAPI
-- Game: Sky Is Arrows

-- MAIN APPLICATION
addappid(576670)
addappid(2435700)
addappid(2485630)
addappid(3430900)

-- MAIN APP DEPOTS / PACKAGES
addappid(576671, 1, "f73bbe23032980bf23bbe7f3556147696ead10ad671aa65c859dd369825709ff")
addappid(576672, 1, "e7ec94310361a56c0f73374f8f47bee7110b7dcd4eac0682b04a2aeb2b067113")
addappid(576673, 1, "09cce97615ee99ed4f8df6e2640126a90cab6bc78bf873b6266add977e0f0fd0")
