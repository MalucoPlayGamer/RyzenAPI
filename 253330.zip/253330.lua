-- Lua provided by RyzenAPI
-- Game: Neverending Nightmares

-- MAIN APPLICATION
addappid(253330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(253331, 1, "9601ec56c0a2b5fefeb9ff0c884d2a1c745f7e6accca54bcfb330df4d0a35ff2")
addappid(253332, 1, "d7901d00afbaff9977be15edd732a856091572fddad6c3a4e6dec02c88de08e4")
addappid(253333, 1, "83286110ec055a14537854991d121d18a51138334b00ee11a1d82ef6fed196a0")

