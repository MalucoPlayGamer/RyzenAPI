-- Lua provided by RyzenAPI
-- Game: addappid(2756770)

-- MAIN APPLICATION
addappid(2756770)
addappid(3387950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756771, 1, "0c1c614022f82e0e0bd88cecdff31567aece1953e21109bd4e7d91b1d304f67f")
addappid(2756772, 1, "c5c4a4c8cb3322c1d1ff087adcf81e06729df57f37ba64586782ec5e2bd64e46")
