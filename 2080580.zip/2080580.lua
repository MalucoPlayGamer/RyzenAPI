-- Lua provided by RyzenAPI
-- Game: 2080580

-- MAIN APPLICATION
addappid(2080580)
-- Game: addappid(2080580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2080581, 1, "62deaff15c502916bbe6824977abcd4dd081e9662d511eed4b4d3677c4dcfbbe")
