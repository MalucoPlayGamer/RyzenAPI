-- Lua provided by RyzenAPI 
-- Game: Hell Madness
addappid(2080580)
addappid(2080581, 1, "62deaff15c502916bbe6824977abcd4dd081e9662d511eed4b4d3677c4dcfbbe")
