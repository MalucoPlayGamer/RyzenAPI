-- Lua provided by SkyAPI 
-- Game: Magazine Mogul
addappid(2054800)
addappid(2054801, 1, "e7fdcbe61984fb1961a0a860b6a8995043caa1cf5b4cc19af9189b23191de2d4")
