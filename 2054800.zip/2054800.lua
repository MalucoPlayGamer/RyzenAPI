-- Lua provided by RyzenAPI
-- Game: Magazine Mogul

-- MAIN APPLICATION
addappid(2054800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054801, 1, "e7fdcbe61984fb1961a0a860b6a8995043caa1cf5b4cc19af9189b23191de2d4")
