-- Lua provided by RyzenAPI
-- Game: Watermelon Simulator

-- MAIN APPLICATION
addappid(3361220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3361221, 1, "5e7c39fb5c76246e2e3f4afd93638af52ac757db6278d2ee0effac4a3da1cc15")
