-- Lua provided by SkyAPI 
-- Game: Fear Of Nightmares: Madness Descent
addappid(692830)
addappid(692831, 1, "87ffbccfd69c60ba33247f7b8fd18e97964ae23bbce05a4af7f1875a8f177957")
