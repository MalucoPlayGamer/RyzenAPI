-- Lua provided by RyzenAPI
-- Game: Game: Fear Of Nightmares: Madness Descent

-- MAIN APPLICATION
addappid(692830)
-- Game: addappid(692830)

-- MAIN APP DEPOTS / PACKAGES
addappid(692831, 1, "87ffbccfd69c60ba33247f7b8fd18e97964ae23bbce05a4af7f1875a8f177957")
