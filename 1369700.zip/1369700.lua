-- Lua provided by RyzenAPI
-- Game: Solar Expanse - Space Exploration Manager

-- MAIN APPLICATION
addappid(1369700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369701,0,"fe48e5a5ffc346b569f0f993f42403f5e1c53bc87068ac9eb8e123a069b9873e")

