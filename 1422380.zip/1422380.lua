-- Lua provided by RyzenAPI
-- Game: Witches x Warlocks

-- MAIN APPLICATION
addappid(1422380)

