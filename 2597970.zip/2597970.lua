-- Lua provided by RyzenAPI
-- Game: Finding Frankie

-- MAIN APPLICATION
addappid(2597970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597971, 1, "bcc51d89a45d304706c7741701fbf0d6b3ad9de2efbfecbc9a990d9ced20f2a6")
