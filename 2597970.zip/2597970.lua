-- Lua provided by RyzenAPI
-- Game: Finding Frankie

-- MAIN APPLICATION
addappid(2597970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597971, 1, "bcc51d89a45d304706c7741701fbf0d6b3ad9de2efbfecbc9a990d9ced20f2a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
