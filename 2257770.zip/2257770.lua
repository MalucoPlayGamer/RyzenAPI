-- Lua provided by RyzenAPI
-- Game: Not For Broadcast VR

-- MAIN APPLICATION
addappid(2257770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257771, 1, "93d32938334b00d21e6e3b2585aa38502c7c9dcd6ae00e79e4b23dfdb19a5bdf")
