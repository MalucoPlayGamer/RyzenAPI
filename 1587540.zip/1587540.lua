-- Lua provided by RyzenAPI
-- Game: Game: Anvil Saga

-- MAIN APPLICATION
addappid(1587540)
-- Game: addappid(1587540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587541, 1, "da7ff0b6ee036d14e58c2aca69462b3d605ad4ec85070c6f3e919a22350f9a21")
