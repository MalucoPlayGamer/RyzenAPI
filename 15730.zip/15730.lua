-- Lua provided by SkyAPI 
-- Game: Oddworld: Abe's Oddysee® Demo
addappid(15730)
addappid(15731, 1, "22e3daa5ac683b2598876e1d19c670061e01e318013580934a8a7b04cc6bb630")
