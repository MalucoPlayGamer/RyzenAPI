-- Lua provided by RyzenAPI
-- Game: Oddworld: Abe's Oddysee® Demo

-- MAIN APPLICATION
addappid(15730)

-- MAIN APP DEPOTS / PACKAGES
addappid(15731, 1, "22e3daa5ac683b2598876e1d19c670061e01e318013580934a8a7b04cc6bb630")

