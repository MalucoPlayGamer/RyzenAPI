-- Lua provided by RyzenAPI
-- Game: Magic Research 2 Demo

-- MAIN APPLICATION
addappid(2920360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920361, 1, "903b72c2429833b80f27dd84d614eb1f17ba8be701710012817668ae91d54b26")

