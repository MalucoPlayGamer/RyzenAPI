-- Lua provided by RyzenAPI
-- Game: Tower Miners

-- MAIN APPLICATION
addappid(690260)

-- MAIN APP DEPOTS / PACKAGES
addappid(690261, 1, "34730d4f1079dabe40eb5da25c82f94038e5bb32dbb0392d847a41a8451e15fd")

