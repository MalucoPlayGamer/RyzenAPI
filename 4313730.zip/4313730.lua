-- 4313730's Lua and Manifest Created by Hubcap Manifest
-- Fishful Days
-- Created: July 30, 2026 at 14:11:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4313730) -- Fishful Days
-- MAIN APP DEPOTS
addappid(4313731, 1, "88ff81944f19693d438ea2b9fbeff644885356a0ae674878cf788dd2801c0dc7") -- Depot 4313731
setManifestid(4313731, "8604255358329034230", 315612179)
addappid(4313732, 1, "d512fc8b954618c86fd8179197fdc7c2bb146d89d980a0be89e1568683751080") -- Depot 4313732
setManifestid(4313732, "9098162311905997469", 339823831)