-- Lua provided by RyzenAPI
-- Game: 3724800

-- MAIN APPLICATION
addappid(3724800)
-- Game: addappid(3724800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3724801, 1, "76500ffccea2445ac8e3a690dd30117a232d8d5e6b30b63dd3a13f2ae812fc32")
