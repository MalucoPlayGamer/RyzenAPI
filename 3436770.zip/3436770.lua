-- Lua provided by RyzenAPI
-- Game: 极乐不羡仙

-- MAIN APPLICATION
addappid(3436770)
-- Game: addappid(3436770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3436771, 1, "1d06b3df8d9c98ec8d376431c579692f69fc2ce20fe7e165644f5b84b88c2f35")
