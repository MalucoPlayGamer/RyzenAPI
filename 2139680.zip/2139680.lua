-- Lua provided by RyzenAPI
-- Game: 2139680

-- MAIN APPLICATION
addappid(2139680)
-- Game: addappid(2139680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139681, 1, "b752489d04d7dae86cc9f742fb56af0075efc87d4d028fa4167b970da36e33c0")
