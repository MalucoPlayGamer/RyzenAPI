-- Lua provided by RyzenAPI
-- Game: Guardians of Life VR

-- MAIN APPLICATION
addappid(694160)

-- MAIN APP DEPOTS / PACKAGES
addappid(694161, 1, "2c53601c9b9ae88b65edc21c60716710dd13f525cdd9efd88024dbba754fcfe4")

