-- Lua provided by RyzenAPI
-- Game: addappid(3201330)

-- MAIN APPLICATION
addappid(3201330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3201331, 1, "3f3a24242698b92d807b5d6578c1b9cf5f648d8d20be39a8e34a6dd7fe152353")
