-- Lua provided by RyzenAPI 
-- Game: AppID 1904410
addappid(1904410)
addappid(1904411, 1, "321c52d9b2fc74e5cbc388464720c5ff0a3939a71878cb79ea4561093c2e394d")
