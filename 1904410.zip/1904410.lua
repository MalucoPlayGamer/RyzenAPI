-- Lua provided by RyzenAPI
-- Game: AppID 1904410

-- MAIN APPLICATION
addappid(1904410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1904411, 1, "321c52d9b2fc74e5cbc388464720c5ff0a3939a71878cb79ea4561093c2e394d")

