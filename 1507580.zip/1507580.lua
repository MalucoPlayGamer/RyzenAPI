-- Lua provided by RyzenAPI 
-- Game: Enigma of Fear
addappid(1507580)
addappid(1507581, 1, "02e59ed98b50bb3d26c8b5b17256f6c452dafba9a36e7500911c1f2a2cb1a745")
