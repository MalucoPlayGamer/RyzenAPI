-- Lua provided by RyzenAPI 
-- Game: Sushi For Robots
addappid(2160240)
addappid(2160241, 1, "14c23e26602442c8607f6338a22bb79dd84111c8f1dcd0e9929c7ab9d8e09872")
