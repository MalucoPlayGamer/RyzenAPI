-- Lua provided by RyzenAPI
-- Game: Sushi For Robots

-- MAIN APPLICATION
addappid(2160240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2160241, 1, "14c23e26602442c8607f6338a22bb79dd84111c8f1dcd0e9929c7ab9d8e09872")

