-- Lua provided by RyzenAPI
-- Game: Game: Sushi For Robots

-- MAIN APPLICATION
addappid(2160240)
-- Game: addappid(2160240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2160241, 1, "14c23e26602442c8607f6338a22bb79dd84111c8f1dcd0e9929c7ab9d8e09872")
