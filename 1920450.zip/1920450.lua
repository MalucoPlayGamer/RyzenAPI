-- Lua provided by RyzenAPI
-- Game: Colors! Maze 2

-- MAIN APPLICATION
addappid(1920450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920451, 1, "0e88073893dd04d60133eccb6301bda010dfce6d097f590e7ea1c63bcd062a82")
