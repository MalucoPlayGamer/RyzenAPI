-- Lua provided by RyzenAPI
-- Game: Zippy Detective: Cats Hidden

-- MAIN APPLICATION
addappid(2330970)
-- Game: addappid(2330970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330972,0,"d1ff186c340df5c3ed4539592663823e41d953dee4382a622f2b225e0fec4618")
