-- Lua provided by RyzenAPI
-- Game: 1833940

-- MAIN APPLICATION
addappid(1833940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833940,0,"9144dc530e67cd56ce09c727e4723aac3503f6f582f57b7c44dbccab63e2bd0a")
