-- Lua provided by RyzenAPI
-- Game: Game: Resident Evil 2 (1998)

-- MAIN APPLICATION
addappid(4249110)
-- Game: addappid(4249110)

-- MAIN APP DEPOTS / PACKAGES
addappid(4249111, 1, "7e6d6cb1a6e136160805cc707943680e3b949fcd4614a89874f8f9005c22f69f")
addappid(4249112, 1, "f311e48330d6eb5320456deb32ff0dfc4afa77462ab3ef4f03c712976fd27013")
addappid(4249113, 1, "4e7a4a237210d1cd940175c55d7e47eed5cd69489edafba115a6477d2f15123b")
