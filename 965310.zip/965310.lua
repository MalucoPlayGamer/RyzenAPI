-- Lua provided by RyzenAPI
-- Game: AppID 965310

-- MAIN APPLICATION
addappid(965310)

-- MAIN APP DEPOTS / PACKAGES
addappid(965311, 1, "bbc4f2e59392261df4a9c5c563d0136e4803afac20f0aceb8b1a0532b3478476")

