-- Lua provided by RyzenAPI
-- Game: The Settlers : Rise of an Empire - History Edition

-- MAIN APPLICATION
addappid(965310)
addappid(1001420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(965311, 1, "bbc4f2e59392261df4a9c5c563d0136e4803afac20f0aceb8b1a0532b3478476")

