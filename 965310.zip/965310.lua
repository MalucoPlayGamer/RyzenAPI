-- Lua provided by RyzenAPI
-- Game: AppID 965310

-- MAIN APPLICATION
addappid(965310)

-- MAIN APP DEPOTS / PACKAGES
addappid(965311, 1, "bbc4f2e59392261df4a9c5c563d0136e4803afac20f0aceb8b1a0532b3478476")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1001420)
