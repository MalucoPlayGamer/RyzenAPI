-- Lua provided by RyzenAPI
-- Game: The Jiang Shi 2 ：Curse of  Soul

-- MAIN APPLICATION
addappid(3016520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3016521, 1, "5125d821993dd12ceaa114dfa0b1f22c385c40a89902e5bbcf3e98d1fa00283d")

