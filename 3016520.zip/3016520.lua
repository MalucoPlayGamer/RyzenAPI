-- Lua provided by RyzenAPI
-- Game: The Jiang Shi 2 ：Curse of  Soul

-- MAIN APPLICATION
addappid(3016520)
-- Game: addappid(3016520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3016521, 1, "5125d821993dd12ceaa114dfa0b1f22c385c40a89902e5bbcf3e98d1fa00283d")
