-- Lua provided by RyzenAPI
-- Game: Kings of Israel

-- MAIN APPLICATION
addappid(428460)

-- MAIN APP DEPOTS / PACKAGES
addappid(428461, 1, "925ba37719af0880537fafcdd8aaaeaed86612352daadc6af6eda837ad6e37d4")

