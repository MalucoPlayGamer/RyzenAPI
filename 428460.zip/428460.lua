-- Lua provided by RyzenAPI
-- Game: Kings of Israel

-- MAIN APPLICATION
addappid(428460)

-- MAIN APP DEPOTS / PACKAGES
addappid(428461, 1, "925ba37719af0880537fafcdd8aaaeaed86612352daadc6af6eda837ad6e37d4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
