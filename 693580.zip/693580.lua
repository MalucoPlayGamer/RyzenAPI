-- Lua provided by RyzenAPI
-- Game: 693580

-- MAIN APPLICATION
addappid(693580)
-- Game: addappid(693580)

-- MAIN APP DEPOTS / PACKAGES
addappid(693581, 1, "13488232df8b34641effb551861bfd89026946ec14ca1faf001ee61f3bc6d822")
