-- Lua provided by RyzenAPI
-- Game: Goblins of Elderstone

-- MAIN APPLICATION
addappid(693580)
addappid(2773900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(693581, 1, "13488232df8b34641effb551861bfd89026946ec14ca1faf001ee61f3bc6d822")

