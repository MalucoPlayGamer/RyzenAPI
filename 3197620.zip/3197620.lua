-- Lua provided by RyzenAPI
-- Game: AppID 3197620

-- MAIN APPLICATION
addappid(3197620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197621, 1, "e0a4de15cfce85e1ca450eff835401b49539aa021ad9a5c28b0bf3d62585b6d6")
