-- Lua provided by RyzenAPI
-- Game: Leap of Champions

-- MAIN APPLICATION
addappid(650740)

-- MAIN APP DEPOTS / PACKAGES
addappid(650741,0,"e24037ededdc7034ea00ebeff93652c72e2e58241fecb983bcb7f3eea561dc3f")

