-- Lua provided by RyzenAPI
-- Game: Leap of Champions

-- MAIN APPLICATION
addappid(650740)

-- MAIN APP DEPOTS / PACKAGES
addappid(650741,0,"e24037ededdc7034ea00ebeff93652c72e2e58241fecb983bcb7f3eea561dc3f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
