-- Lua provided by RyzenAPI
-- Game: addappid(2887340)

-- MAIN APPLICATION
addappid(2887340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2887341, 1, "f283d9a9a36fcaf93a18f6ccfd5b291207a20908754254833b1661cafa76618a")
