-- Lua provided by RyzenAPI
-- Game: Elypse

-- MAIN APPLICATION
addappid(1725340)
-- Game: addappid(1725340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725341, 1, "c792127aad5a59e6541bb7b614aa8191ea647b412fa4dcb59e0a60e9ef211dfb")
