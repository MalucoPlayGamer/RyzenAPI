-- Lua provided by RyzenAPI
-- Game: Rail Adventures - VR Tech Demo

-- MAIN APPLICATION
addappid(222500)

-- MAIN APP DEPOTS / PACKAGES
addappid(222501, 1, "bc89697b498021823714f09551c66da5c91823a8775136e38eb0c30a9f9cc682")
