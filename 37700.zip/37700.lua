-- Lua provided by RyzenAPI
-- Game: Darkest of Days

-- MAIN APPLICATION
addappid(37700)

-- MAIN APP DEPOTS / PACKAGES
addappid(37701, 1, "51f6419505a29a14a686df4acd34e9f0e5faf1c6c1d3878e27f2833ff4017877")

