-- Lua provided by SkyAPI 
-- Game: Darkest of Days
addappid(37700)
addappid(37701, 1, "51f6419505a29a14a686df4acd34e9f0e5faf1c6c1d3878e27f2833ff4017877")
