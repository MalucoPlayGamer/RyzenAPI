-- Lua provided by RyzenAPI
-- Game: addappid(1513030)

-- MAIN APPLICATION
addappid(1513030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513032,0,"17cb26fd207678129ed3610538c4b404213ba4aa9318b2f852e85ebaaf7f559c")
