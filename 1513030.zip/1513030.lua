-- Lua provided by RyzenAPI
-- Game: Soar: Pillars of Tasneem

-- MAIN APPLICATION
addappid(1513030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513032,0,"17cb26fd207678129ed3610538c4b404213ba4aa9318b2f852e85ebaaf7f559c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
