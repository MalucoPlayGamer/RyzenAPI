-- Lua provided by RyzenAPI
-- Game: Game: LINGERING

-- MAIN APPLICATION
addappid(1343220)
-- Game: addappid(1343220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343221, 1, "2c8743ece6fbc56194335a3e42a4d5780db1cc793c586f69527a26044132ec97")
