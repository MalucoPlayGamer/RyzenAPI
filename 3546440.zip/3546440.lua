-- Lua provided by RyzenAPI
-- Game: addappid(3546440)

-- MAIN APPLICATION
addappid(3546440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3546441, 1, "f303e6656cf9ab575ee79e1a326af48358d9efb35bf85df55ccf125a2079f491")
