-- Lua provided by RyzenAPI
-- Game: Game: TSA Frisky

-- MAIN APPLICATION
addappid(805150)
-- Game: addappid(805150)

-- MAIN APP DEPOTS / PACKAGES
addappid(805151, 1, "5c4d1f466429e81d05aa3a4234e22c84e17e85c6711e52d36409f248c274e07e")
