-- Lua provided by RyzenAPI
-- Game: Game: THE KING OF FIGHTERS 2002 UNLIMITED MATCH

-- MAIN APPLICATION
addappid(222440)
addappid(228982)
-- Game: addappid(222440)

-- MAIN APP DEPOTS / PACKAGES
addappid(222441, 1, "ecc4bf27f87ee88b4bb037ee5747c78dea710c160d950c9204f19d7e6a8deff6")
