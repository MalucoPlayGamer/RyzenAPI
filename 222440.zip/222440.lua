-- Lua provided by RyzenAPI
-- Game: THE KING OF FIGHTERS 2002 UNLIMITED MATCH

-- MAIN APPLICATION
addappid(222440)
addappid(228982)

-- MAIN APP DEPOTS / PACKAGES
addappid(222441, 1, "ecc4bf27f87ee88b4bb037ee5747c78dea710c160d950c9204f19d7e6a8deff6")
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

