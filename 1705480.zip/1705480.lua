-- Lua provided by RyzenAPI
-- Game: Game: Escape from DuFo

-- MAIN APPLICATION
addappid(1705480)
-- Game: addappid(1705480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705481, 1, "d6f6fc2a2b3d5f461f7f62c233599e0096a9ca67a7bc596e3a6bacbdf26b4297")
