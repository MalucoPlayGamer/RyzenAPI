-- Lua provided by RyzenAPI 
-- Game: Bounty: Drag Racing
addappid(1803390)
addappid(1803391, 1, "fffdefd891499699c5fdc41f582b08103072a59c681c871ed592e88d8849791c")
