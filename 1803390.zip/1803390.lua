-- Lua provided by RyzenAPI
-- Game: Bounty: Drag Racing

-- MAIN APPLICATION
addappid(1803390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803391, 1, "fffdefd891499699c5fdc41f582b08103072a59c681c871ed592e88d8849791c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2471270)
addappid(2472680)
addappid(2472681)
addappid(2472682)
addappid(2539590)
addappid(2598830)
addappid(2598850)
addappid(2673140)
addappid(2724070)
addappid(2724080)
addappid(2978900)
addappid(2978920)
addappid(3038570)
addappid(3108150)
addappid(3108160)
addappid(3180350)
addappid(3261790)
addappid(3357330)
addappid(3395940)
addappid(3547840)
addappid(3622160)
addappid(3622170)
addappid(3839290)
addappid(3859760)
addappid(3955100)
addappid(4029920)
addappid(4179810)
addappid(4267550)
addappid(4694650)
addappid(5023680)
