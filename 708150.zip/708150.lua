-- Lua provided by RyzenAPI
-- Game: Lost Artifacts

-- MAIN APPLICATION
addappid(708150)
addappid(983480)

-- MAIN APP DEPOTS / PACKAGES
addappid(708151, 1, "579605acd38ff1715d77e6526cf7c67494934ed58e6ec7847885b20fdc5298ea")
