-- Lua provided by RyzenAPI 
-- Game: AppID 708150
addappid(708150)
addappid(708151, 1, "579605acd38ff1715d77e6526cf7c67494934ed58e6ec7847885b20fdc5298ea")
addappid(983480)
