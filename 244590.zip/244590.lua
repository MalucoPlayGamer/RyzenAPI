-- Lua provided by RyzenAPI
-- Game: addappid(244590)

-- MAIN APPLICATION
addappid(244590)

-- MAIN APP DEPOTS / PACKAGES
addappid(244591, 1, "8a77827680397c52e525274e5fc5f3116b75e6e87f4b3bc943b08a6c80f8fce2")
