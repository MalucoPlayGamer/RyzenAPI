-- Lua provided by RyzenAPI
-- Game: Epigenesis

-- MAIN APPLICATION
addappid(244590)

-- MAIN APP DEPOTS / PACKAGES
addappid(244591, 1, "8a77827680397c52e525274e5fc5f3116b75e6e87f4b3bc943b08a6c80f8fce2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
