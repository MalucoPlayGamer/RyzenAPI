-- Lua provided by RyzenAPI
-- Game: Fishbowl

-- MAIN APPLICATION
addappid(1638070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638071,0,"3542495949f9c41eb2c3b49a31552edbcb0088ffdbff844b91bfdfff915a657e")

