-- Lua provided by RyzenAPI
-- Game: Sacred Gold

-- MAIN APPLICATION
addappid(12320)

-- MAIN APP DEPOTS / PACKAGES
addappid(12321, 1, "47d9b30cbbaae20345058acf2967468c6e8fc571e2693f1a4149a4bf9ae1a729")
addappid(12322, 1, "7db73eb7a433d4989ea7f24a9c66063d411dc8fa3bda0feb566ab5b0b0c4efd1")
