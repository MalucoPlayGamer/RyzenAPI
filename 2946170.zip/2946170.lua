-- Lua provided by RyzenAPI
-- Game: Game: Pitfall Protocol

-- MAIN APPLICATION
addappid(2946170)
-- Game: addappid(2946170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946171, 1, "6cd3f40f74db0def313d5353678533c276e0862012c65e033f37a1caf0fd53e9")
