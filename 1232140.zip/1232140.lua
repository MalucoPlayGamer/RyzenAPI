-- Lua provided by RyzenAPI
-- Game: AppID 1232140

-- MAIN APPLICATION
addappid(1232140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1232141, 1, "07da2d8d0e68cd707123b76ed7499b48e579fb6fff9bb8352226ddb0ec845f94")
addappid(1232142, 1, "445127eebc95eab6c1d8757d9ea655fe57b0689cbe9f73ec0f1b7038e92f785a")

