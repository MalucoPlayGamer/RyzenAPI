-- Lua provided by RyzenAPI
-- Game: addappid(1232140)

-- MAIN APPLICATION
addappid(1232140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232141, 1, "07da2d8d0e68cd707123b76ed7499b48e579fb6fff9bb8352226ddb0ec845f94")
addappid(1232142, 1, "445127eebc95eab6c1d8757d9ea655fe57b0689cbe9f73ec0f1b7038e92f785a")
