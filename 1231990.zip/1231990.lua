-- Lua provided by RyzenAPI
-- Game: Gestalt: Steam & Cinder

-- MAIN APPLICATION
addappid(1231990)
-- Game: addappid(1231990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231991, 1, "37cf8778c2369206caa425208e81c630dfb0755d780ac70787bf390ef3c34470")
