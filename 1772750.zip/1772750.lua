-- Lua provided by RyzenAPI
-- Game: 知更鸟-The Robin

-- MAIN APPLICATION
addappid(1772750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772751, 1, "0503da90b3ae6239597e5c705fb43dd0e5e61377e3f56569af08260367939cac")
