-- Lua provided by RyzenAPI
-- Game: addappid(3050340)

-- MAIN APPLICATION
addappid(3050340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3050340,0,"6f6447dc7a61b61eae5f5f24f0086ef6c4519a6a90f6c61eab5a16b2dd70f38a")
