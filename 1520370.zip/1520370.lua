-- Lua provided by RyzenAPI
-- Game: 1520370

-- MAIN APPLICATION
addappid(1520370)
-- Game: addappid(1520370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520371, 1, "75eef3fd6c1168dae8861e584dc3f7a5784592a127eba4bab4246ac1b77053f9")
