-- Lua provided by RyzenAPI
-- Game: Game: AppID 681810

-- MAIN APPLICATION
addappid(681810)
-- Game: addappid(681810)

-- MAIN APP DEPOTS / PACKAGES
addappid(681811, 1, "bb8d4a38f1769172b56dd4237f9a9855937bd1093978123fa987706511bf003a")
