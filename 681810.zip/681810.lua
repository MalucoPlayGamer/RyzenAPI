-- Lua provided by RyzenAPI
-- Game: AppID 681810

-- MAIN APPLICATION
addappid(681810)

-- MAIN APP DEPOTS / PACKAGES
addappid(681811, 1, "bb8d4a38f1769172b56dd4237f9a9855937bd1093978123fa987706511bf003a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
