-- Lua provided by RyzenAPI
-- Game: Arcanium: Rise of Akhan

-- MAIN APPLICATION
addappid(1056840)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1056841, 1, "0a24f9a0a3c19b70329209a293cbcbf6dcdf266f74a718f616aff1c69d38d630")

