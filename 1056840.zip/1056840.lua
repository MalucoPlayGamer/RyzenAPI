-- Lua provided by RyzenAPI
-- Game: 1056840

-- MAIN APPLICATION
addappid(1056840)
-- Game: addappid(1056840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056841, 1, "0a24f9a0a3c19b70329209a293cbcbf6dcdf266f74a718f616aff1c69d38d630")
