-- Lua provided by RyzenAPI
-- Game: Dark Fairy Tale: Dreamland Survivors

-- MAIN APPLICATION
addappid(3288300)
addappid(3902110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3288301, 1, "54e8719fe2d4ca369a41e7c8bbe6db4dea81fbcac6cdd4ccd064d7dda6f7548e")

