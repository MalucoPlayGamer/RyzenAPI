-- Lua provided by RyzenAPI
-- Game: Dark Fairy Tale: Dreamland Survivors

-- MAIN APPLICATION
addappid(3288300)
addappid(3902110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288301, 1, "54e8719fe2d4ca369a41e7c8bbe6db4dea81fbcac6cdd4ccd064d7dda6f7548e")

