-- Lua provided by RyzenAPI
-- Game: Game: Furry Feet Girls

-- MAIN APPLICATION
addappid(2982590)
-- Game: addappid(2982590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2982591, 1, "d7dae6497c056f31ae50f4ab3c32e83d2935f04346ee9880dab85ef46f829709")
