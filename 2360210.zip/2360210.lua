-- Lua provided by RyzenAPI
-- Game: Rune Coliseum

-- MAIN APPLICATION
addappid(2360210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360211, 1, "1696b5cd888286bb56e4c212ad6050e26d06f6cd2360159f6166350ef9bdc3ae")

