-- Lua provided by RyzenAPI
-- Game: Bomber Bother

-- MAIN APPLICATION
addappid(1153170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153171, 1, "d0ecc67893614a9fa2a61e1fe4eb023073ea625cdd3efb5c18b71fabae626f2a")
addappid(1153172, 1, "81a5b977b905d1aa333cb858860291b0c6cb11c65cb6f60c242ef384f53388a4")
addappid(1153173, 1, "d1a8866e31f530d2c37d610dc6442c3a577823e45caddfc5bd3fe5dc78dd8bfe")
addappid(1153174, 1, "fde64ba6580d04188abb15f1455e511d0d4b8914fcbd897e4d26011d10b36300")
