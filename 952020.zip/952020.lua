-- Lua provided by RyzenAPI
-- Game: addappid(952020)

-- MAIN APPLICATION
addappid(952020)

-- MAIN APP DEPOTS / PACKAGES
addappid(952021, 1, "ddba3d14eff3036d1d7518f14eaa8ef959d321391188205454e3c200452d4325")
