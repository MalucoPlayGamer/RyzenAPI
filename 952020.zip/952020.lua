-- Lua provided by SkyAPI 
-- Game: Love at Elevation
addappid(952020)
addappid(952021, 1, "ddba3d14eff3036d1d7518f14eaa8ef959d321391188205454e3c200452d4325")
