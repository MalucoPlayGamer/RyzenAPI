-- Lua provided by RyzenAPI
-- Game: Game: Bakumatsu Renka SHINSENGUMI

-- MAIN APPLICATION
addappid(1451160)
-- Game: addappid(1451160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451161, 1, "0109edbe233c943f992c04e9e7bb0f1a8778cd1ce90a477137cf677e8480ca26")
