-- Lua provided by RyzenAPI
-- Game: Bandits Demo

-- MAIN APPLICATION
addappid(2235700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235701, 1, "0286fa7492e21a3fb9701b0742e55d69811620f920b7c1b7fb5869f6eefc25ac")

