-- Lua provided by RyzenAPI
-- Game: Chorus of Carcosa

-- MAIN APPLICATION
addappid(2987750)
addappid(3551220)
-- Game: addappid(2987750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987751, 1, "35d631cb97a91e51ad4b17e8434aebd9a5d7f5f41903738d8bd9bb027aaf6f37")
