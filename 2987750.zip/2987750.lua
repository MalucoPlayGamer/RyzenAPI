-- Lua provided by RyzenAPI
-- Game: Chorus of Carcosa

-- MAIN APPLICATION
addappid(2987750)
addappid(3551220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987751, 1, "35d631cb97a91e51ad4b17e8434aebd9a5d7f5f41903738d8bd9bb027aaf6f37")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
