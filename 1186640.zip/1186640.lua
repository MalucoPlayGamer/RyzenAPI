-- Lua provided by RyzenAPI
-- Game: Game: Pumpkin Jack

-- MAIN APPLICATION
addappid(1186640)
-- Game: addappid(1186640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186641, 1, "7d75a6d1073711ac621a8f6ac4764f449333ad6e818d692852af0cdad8f04a46")
