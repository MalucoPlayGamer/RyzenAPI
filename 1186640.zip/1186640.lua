-- Lua provided by RyzenAPI
-- Game: Pumpkin Jack

-- MAIN APPLICATION
addappid(1186640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186641, 1, "7d75a6d1073711ac621a8f6ac4764f449333ad6e818d692852af0cdad8f04a46")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
