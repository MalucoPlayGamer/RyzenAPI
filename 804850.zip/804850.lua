-- Lua provided by RyzenAPI
-- Game: Pax Nova

-- MAIN APPLICATION
addappid(804850)
addappid(1582050)
addappid(1688990)
addappid(1796420)

-- MAIN APP DEPOTS / PACKAGES
addappid(804851,0,"8b26d473ded61846b4fabdb04f1e897e919479002c463f186e81a00ae6e5cc71")
addappid(1688990,0,"0d59bd6ee94875d5bb4a1909d2b9fe26134fe1a0c820c7f6ad01b86a501188c1")
addappid(1796420,0,"6d69a88c59b73951cedb6efdc4e9a7daf009a4412251b5a339127ac7ffb343a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
