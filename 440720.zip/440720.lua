-- Lua provided by RyzenAPI
-- Game: Game: Pandora`s room

-- MAIN APPLICATION
addappid(440720)
-- Game: addappid(440720)

-- MAIN APP DEPOTS / PACKAGES
addappid(440721, 1, "65293b8cf6f0372261b6601cd4285b8b315460dbe9a116776f4e0be2457b2b2c")
