-- Lua provided by RyzenAPI
-- Game: Blue sky fighter

-- MAIN APPLICATION
addappid(1220360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220361, 1, "28fe406651ace1c88f5f1b2d7c2f95fdcebfdb3cb9ecf2a35ac153526b956d3e")
