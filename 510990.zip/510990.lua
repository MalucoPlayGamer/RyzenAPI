-- Lua provided by RyzenAPI
-- Game: addappid(510990)

-- MAIN APPLICATION
addappid(510990)

-- MAIN APP DEPOTS / PACKAGES
addappid(510991, 1, "d7a3f77867b92f687b66a861ad277aa8d3ea0382d34fb8d6da5acebd1b7ddd63")
