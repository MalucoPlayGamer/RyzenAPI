-- Lua provided by RyzenAPI
-- Game: Ancient Wars: Medieval Crusades

-- MAIN APPLICATION
addappid(1925620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925621, 1, "fa1d7214956b3d94d2655450a6611d52f176b3edfe56bf8bf09b0f6836dcde3e")
addappid(1925622, 1, "9e3082b02687aa3254cf2d757c140b2ea160ac4ddb175b77b1b88e514a32db30")
addappid(1925627, 1, "979aa615725f97a34e4dc77c1be23606edce349b05ecf373adef8485c4be5233")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
