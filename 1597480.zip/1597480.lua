-- Lua provided by RyzenAPI
-- Game: Zombie Gunship Survival

-- MAIN APPLICATION
addappid(1597480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597481, 1, "59d11043aaf9e823cd5bd2796a3c1f4470b304f20a720d1c64709587fbaf6451")
