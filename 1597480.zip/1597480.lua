-- Lua provided by SkyAPI 
-- Game: Zombie Gunship Survival
addappid(1597480)
addappid(1597481, 1, "59d11043aaf9e823cd5bd2796a3c1f4470b304f20a720d1c64709587fbaf6451")
