-- Lua provided by RyzenAPI
-- Game: Zombie Gunship Survival

-- MAIN APPLICATION
addappid(1597480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597481, 1, "59d11043aaf9e823cd5bd2796a3c1f4470b304f20a720d1c64709587fbaf6451")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
