-- Lua provided by RyzenAPI
-- Game: AppID 1128900

-- MAIN APPLICATION
addappid(1128900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128901, 1, "90d24f911424b4dbc7f8950aa33c11bf0fd95a13ff9f484c90ca88dc9efd9099")

