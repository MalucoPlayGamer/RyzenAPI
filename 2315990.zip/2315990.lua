-- Lua provided by RyzenAPI
-- Game: 2315990

-- MAIN APPLICATION
addappid(2315990)
-- Game: addappid(2315990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315991, 1, "afaaafc043b611618adc16af399fe5275856fe2a15c2508519e9477b253f0a27")
