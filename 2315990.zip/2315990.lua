-- Lua provided by RyzenAPI
-- Game: 孵化之地 wild eclosion

-- MAIN APPLICATION
addappid(2315990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2315991, 1, "afaaafc043b611618adc16af399fe5275856fe2a15c2508519e9477b253f0a27")

