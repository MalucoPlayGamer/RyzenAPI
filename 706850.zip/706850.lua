-- Lua provided by RyzenAPI
-- Game: Devader

-- MAIN APPLICATION
addappid(706850)

-- MAIN APP DEPOTS / PACKAGES
addappid(706851,0,"30bf4cc9667ad76a01625d60a9d7e4f8231ead93a94ac034a6415eddc95fb384")

