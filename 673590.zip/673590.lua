-- Lua provided by RyzenAPI
-- Game: Amazing Thailand VR Experience

-- MAIN APPLICATION
addappid(673590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(673591, 1, "1f9dbe1b89c97af43cea1f825d205b3dfefad47d02ab2d212da3e9623b480c11")
addappid(748470, 0, "837a8b67232966efc7e117ff7d3a089e05edb5966f58fd8b9e1f7d4f3761926a")
addappid(748471, 0, "d3161c8e967a6a1c057ef5a3c39f141c54fe1ddcf66024f59a4c214b32bec280")
addappid(748472, 0, "4e0df0f68f10e508b1066713685b50c9fe2bce2a3df57512465af636900bc92e")
addappid(748473, 0, "982faedf5ff3142d0682324b4606c86936b3dcc73ce0ab3bd5df11de9a7cab51")

