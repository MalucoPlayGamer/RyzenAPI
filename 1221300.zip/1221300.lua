-- Lua provided by RyzenAPI
-- Game: addappid(1221300)

-- MAIN APPLICATION
addappid(1221300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221301, 1, "4c1cb50d682201ca59b3d3d16b6e04fe122971b516537fbc6629ab7e2bb715be")
