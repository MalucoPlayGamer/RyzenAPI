-- Lua provided by RyzenAPI
-- Game: 741380

-- MAIN APPLICATION
addappid(741380)
addappid(741381)
-- Game: addappid(741380)

-- MAIN APP DEPOTS / PACKAGES
addappid(741380,0,"039d7451dd5bacad985d5be44dfa51979ec07819e247c47a46e01ca1988a16a1")
