-- Lua provided by RyzenAPI
-- Game: 2178340

-- MAIN APPLICATION
addappid(2178340)
-- Game: addappid(2178340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178341, 1, "ffa1016d0952218ca4d5151c45b7a7b2e601952116954fcafd616e1ce854861c")
