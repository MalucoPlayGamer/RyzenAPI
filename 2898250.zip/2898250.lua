-- Lua provided by RyzenAPI 
-- Game: Rent A Car Simulator 24: Prologue
addappid(2898250)
addappid(2898251, 1, "f0ec4fd554b79b812d6d955c0567e460c9ff5acfd1c49e0cbad201b82e9633fd")
