-- Lua provided by RyzenAPI
-- Game: Rent A Car Simulator 24: Prologue

-- MAIN APPLICATION
addappid(2898250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2898251, 1, "f0ec4fd554b79b812d6d955c0567e460c9ff5acfd1c49e0cbad201b82e9633fd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
