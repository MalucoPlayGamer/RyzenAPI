-- Lua provided by RyzenAPI
-- Game: PlanetDrop - A Tiny Space Adventure

-- MAIN APPLICATION
addappid(1793060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793061, 1, "9c21802c959ef1f91c60c3fb611a61938164ec839f4fa8157c513b6943ec0976")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
