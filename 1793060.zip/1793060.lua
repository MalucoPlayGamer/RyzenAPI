-- Lua provided by RyzenAPI
-- Game: Game: PlanetDrop - A Tiny Space Adventure

-- MAIN APPLICATION
addappid(1793060)
-- Game: addappid(1793060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793061, 1, "9c21802c959ef1f91c60c3fb611a61938164ec839f4fa8157c513b6943ec0976")
