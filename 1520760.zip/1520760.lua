-- Lua provided by RyzenAPI
-- Game: Tyrant's Blessing

-- MAIN APPLICATION
addappid(1520760)
-- Game: addappid(1520760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1520762,0,"c401e7a38c43d6f7d0f0a7c49b9b5c62949344f6bda8551c66d4a50fd1327cb9")
addappid(1520763,0,"8f10f2ae0e8b2e7793ee637f0716a830a3e297a4b165e3e341af87c3e1d4c529")
addappid(1520764,0,"c0af415c9d85e1e1b8d6b5544056585230ba333d81ae4d557db3abf08af7b971")
