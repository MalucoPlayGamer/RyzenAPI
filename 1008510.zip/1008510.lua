-- Lua provided by RyzenAPI
-- Game: Who Is This Man

-- MAIN APPLICATION
addappid(1008510)
-- Game: addappid(1008510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008511, 1, "8b8609df4aaea69f5a1160a826046b7c5fd9a8ba37e61bacd166fdc933a6bcc7")
