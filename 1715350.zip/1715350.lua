-- Lua provided by RyzenAPI
-- Game: 1715350

-- MAIN APPLICATION
addappid(1715350)
-- Game: addappid(1715350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715351, 1, "3c7db6652b16fb1bc4769948770899a13c06cdd21659ae193b6ddbfd7cdbc766")
