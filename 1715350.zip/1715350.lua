-- Lua provided by SkyAPI 
-- Game: UNDETECTED
addappid(1715350)
addappid(1715351, 1, "3c7db6652b16fb1bc4769948770899a13c06cdd21659ae193b6ddbfd7cdbc766")
