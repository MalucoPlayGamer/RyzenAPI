-- Lua provided by RyzenAPI
-- Game: UNDETECTED

-- MAIN APPLICATION
addappid(1715350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715351, 1, "3c7db6652b16fb1bc4769948770899a13c06cdd21659ae193b6ddbfd7cdbc766")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
