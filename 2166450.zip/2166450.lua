-- Lua provided by RyzenAPI 
-- Game: Stay Out Of The Farm
addappid(2166450)
addappid(2166451, 1, "c3f85a00828f6dac543be904ae71c975673de56e85ae88ac5f59ef8208c7c93c")
