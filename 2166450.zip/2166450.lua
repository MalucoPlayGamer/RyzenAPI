-- Lua provided by RyzenAPI
-- Game: Stay Out Of The Farm

-- MAIN APPLICATION
addappid(2166450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166451, 1, "c3f85a00828f6dac543be904ae71c975673de56e85ae88ac5f59ef8208c7c93c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
