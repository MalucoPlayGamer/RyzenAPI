-- Lua provided by RyzenAPI
-- Game: Brothel Simulator II 💋

-- MAIN APPLICATION
addappid(2338000)
-- Game: addappid(2338000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338001, 1, "0c214b0e5b4434ea994c6e5a74680672507bdf655c0dc04cae913e1747732e0b")
