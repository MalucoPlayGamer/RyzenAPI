-- Lua provided by RyzenAPI
-- Game: Dungeon Golf

-- MAIN APPLICATION
addappid(2144040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144041, 1, "5a5accc55a440ea20890e415632fadf105ea95892a1d348ea419d16f5ba6fc38")

