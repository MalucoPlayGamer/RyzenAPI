-- Lua provided by SkyAPI 
-- Game: Gnomes Garden Lost King
addappid(823640)
addappid(823641, 1, "5ccfd7192fb7d015edc4bb7cbe77a0f9427c82b4cea1baf8bbab43ae6315beb6")
addappid(954670, 0, "fff7d7ea4436944922d4e8145143768c21c3d40cb6b672b090b4409b09ac5f1d")
