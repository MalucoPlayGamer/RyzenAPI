-- Lua provided by RyzenAPI
-- Game: Game: 恶灵退散 Go Back to Hell

-- MAIN APPLICATION
addappid(1600890)
-- Game: addappid(1600890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600891, 1, "c1d165296ca7dbb03591c6ccaff9c8982b0cce03a38dd7d287e4a5a432723118")
