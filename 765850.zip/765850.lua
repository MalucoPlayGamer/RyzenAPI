-- Lua provided by RyzenAPI
-- Game: Game: Leisure Suit Larry 3 - Passionate Patti in Pursuit of the Pulsating Pectorals

-- MAIN APPLICATION
addappid(765850)
-- Game: addappid(765850)

-- MAIN APP DEPOTS / PACKAGES
addappid(765851, 1, "9170decbfa2e8ae7e6499d3c44089d42a2bb95aa7c4cd08a85e66dd616f48803")
