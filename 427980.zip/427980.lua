-- Lua provided by RyzenAPI
-- Game: Game: Aozora Meikyuu

-- MAIN APPLICATION
addappid(427980)
-- Game: addappid(427980)

-- MAIN APP DEPOTS / PACKAGES
addappid(427981, 1, "86153a66aed5507180b77cb451705fc4ee178aea2532a2198e4556ee59f15ca8")
