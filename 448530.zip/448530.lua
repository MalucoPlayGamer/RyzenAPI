-- Lua provided by RyzenAPI
-- Game: 448530

-- MAIN APPLICATION
addappid(448530)
-- Game: addappid(448530)

-- MAIN APP DEPOTS / PACKAGES
addappid(448531, 1, "82b92d657ad1de83c3c1d961c47fc64585067d023456d1b74ae4b5a8b77e9dc9")
addappid(448532, 1, "3f25939d31fabf1f328e8b8a95ef0ebeefca36442661c6604c6dc6216cc1d789")
