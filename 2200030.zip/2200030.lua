-- Lua provided by RyzenAPI
-- Game: addappid(2200030)

-- MAIN APPLICATION
addappid(2200030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200031, 1, "f5fa65ea5b871a07bea43dc7b8566dbbc8a4b9f6c06acb7eed6be6b89031a4a4")
