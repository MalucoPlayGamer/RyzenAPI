-- Lua provided by RyzenAPI
-- Game: Melon Man

-- MAIN APPLICATION
addappid(2928490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928491, 1, "0a1fb342a283dc5c0f96b5bb7dd6f6fff1535d42b62a269ec539ef95bebfec7b")
