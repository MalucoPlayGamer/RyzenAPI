-- Lua provided by RyzenAPI
-- Game: Zombie Road Rider

-- MAIN APPLICATION
addappid(1175640)
-- Game: addappid(1175640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175641, 1, "1d1e9b00db124c031678704401a209cc0045418003aa225e085706a40cda2781")
addappid(1175642, 1, "f61496163d2df87c7a173fdc64c370ee77c36b16bf0c3b63c4109a7d30f9ef80")
