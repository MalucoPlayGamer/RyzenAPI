-- Lua provided by RyzenAPI
-- Game: Zombie Road Rider

-- MAIN APPLICATION
addappid(1175640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175641, 1, "1d1e9b00db124c031678704401a209cc0045418003aa225e085706a40cda2781")
addappid(1175642, 1, "f61496163d2df87c7a173fdc64c370ee77c36b16bf0c3b63c4109a7d30f9ef80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
