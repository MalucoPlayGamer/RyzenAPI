-- Lua provided by RyzenAPI
-- Game: Game: AppID 1290070

-- MAIN APPLICATION
addappid(1290070)
-- Game: addappid(1290070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290071, 1, "e5847d1f92c6a1eefab8a83f625d1f91ed86ed5c4c569fb7d87d15c23e0ebdb5")
addappid(1319450, 0, "b7282022b0eec4e9cb916cc16500249619029bcd304ffce0c4b510dd129c5c76")
