-- Lua provided by RyzenAPI
-- Game: Namaiki Dark Elf Sisters

-- MAIN APPLICATION
addappid(1689000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689001, 1, "dccd8bf9b4820b85ca965846d2b673b9240cc6f8ed15a8dd29d4224b5dadd0ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
