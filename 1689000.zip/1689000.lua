-- Lua provided by RyzenAPI
-- Game: Game: Namaiki Dark Elf Sisters

-- MAIN APPLICATION
addappid(1689000)
-- Game: addappid(1689000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689001, 1, "dccd8bf9b4820b85ca965846d2b673b9240cc6f8ed15a8dd29d4224b5dadd0ab")
