-- Lua provided by RyzenAPI
-- Game: Airlock Arena

-- MAIN APPLICATION
addappid(1111920) -- Airlock Arena

-- MAIN APP DEPOTS / PACKAGES
addappid(1111921, 1, "5248fada7c9886e04838675a5ad67d5f5cbbaa0c9195b0188799e1ee6c12d09e") -- Depot 1111921

