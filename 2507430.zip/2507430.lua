-- Lua provided by RyzenAPI 
-- Game: PuPu's Adventure Park Soundtrack
addappid(2507430)
addappid(2507431, 1, "77866c437838f803de9a0ecc63e63fd4e568ac4ba939359424b60014fc21c28a")
addappid(2507432, 1, "7622b1a0d9254e9f5a0e142eb3ace4bde7980095981de97e6c893cc71ee13774")
