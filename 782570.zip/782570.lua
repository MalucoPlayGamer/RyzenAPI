-- Lua provided by RyzenAPI 
-- Game: AppID 782570
addappid(782570)
addappid(782571, 1, "5043a4823fcb38159d609ff68a3354b56252bb6f53dd069c86a05849b03aba56")
