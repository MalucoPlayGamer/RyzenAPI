-- Lua provided by RyzenAPI
-- Game: Foxhaven

-- MAIN APPLICATION
addappid(2596750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2596751, 1, "ee51aa405dbee3238a73d393034c6ed43bfbf421bcb0d4c512def450e9525f22")

