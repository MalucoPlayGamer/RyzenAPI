-- Lua provided by RyzenAPI
-- Game: Game: Midnight Ramen

-- MAIN APPLICATION
addappid(2543030)
-- Game: addappid(2543030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543031, 1, "e12a7b0583864ae58c7953c8981930b12eb9e05221be1271bc77e160ccf53243")
