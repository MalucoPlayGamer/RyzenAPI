-- Lua provided by SkyAPI 
-- Game: Midnight Ramen
addappid(2543030)
addappid(2543031, 1, "e12a7b0583864ae58c7953c8981930b12eb9e05221be1271bc77e160ccf53243")
