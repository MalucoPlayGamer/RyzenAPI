-- Lua provided by RyzenAPI
-- Game: "Glow Ball" - The billiard puzzle game

-- MAIN APPLICATION
addappid(388390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(388391, 1, "8faad78a4922775d7b6ee76003653138f4bc83e5cdb10b63516e532d18d00d55")
addappid(388392, 1, "5b67555a4faf32dddcc3e09a7c31151c117ac6ba34aa4c49e8c15c3177af7f46")

