-- Lua provided by RyzenAPI
-- Game: AppID 388390

-- MAIN APPLICATION
addappid(388390)
-- Game: addappid(388390)

-- MAIN APP DEPOTS / PACKAGES
addappid(388391, 1, "8faad78a4922775d7b6ee76003653138f4bc83e5cdb10b63516e532d18d00d55")
addappid(388392, 1, "5b67555a4faf32dddcc3e09a7c31151c117ac6ba34aa4c49e8c15c3177af7f46")
