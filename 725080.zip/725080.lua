-- Lua provided by RyzenAPI
-- Game: Fearful Symmetry & The Cursed Prince

-- MAIN APPLICATION
addappid(725080)

-- MAIN APP DEPOTS / PACKAGES
addappid(725081,0,"c1b0f37a7791b32da69e95e0853f1e7c59288c9bfe4c01ecb7610bc442ac33e6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
