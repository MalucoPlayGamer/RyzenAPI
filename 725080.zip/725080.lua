-- Lua provided by RyzenAPI
-- Game: Fearful Symmetry & The Cursed Prince

-- MAIN APPLICATION
addappid(725080)

-- MAIN APP DEPOTS / PACKAGES
addappid(725081,0,"c1b0f37a7791b32da69e95e0853f1e7c59288c9bfe4c01ecb7610bc442ac33e6")

