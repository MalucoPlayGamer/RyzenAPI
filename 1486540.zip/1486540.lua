-- Lua provided by RyzenAPI
-- Game: 1486540

-- MAIN APPLICATION
addappid(1486540)
-- Game: addappid(1486540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486541, 1, "a35249cde0d5c1d9b0cd23ccbb6b24eb11cfaf399675b75df632b61d4b0c6f17")
