-- Lua provided by SkyAPI 
-- Game: City Bus Manager
addappid(1364210)
addappid(1364211, 1, "3748007409a9ce4382259fe6320aff7ea846f18eba5a9c4a9ec7bab1a6864761")
addappid(1364212, 1, "e0d499227945f83fa2e9654ea918bc00d4e33990786e4eb6b16a3abefd1f2263")
