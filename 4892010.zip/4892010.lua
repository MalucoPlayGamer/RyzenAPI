-- Lua provided by RyzenAPI
-- Game: Bomb Farm

-- MAIN APPLICATION
addappid(4892010)

