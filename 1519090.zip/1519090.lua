-- Lua provided by RyzenAPI 
-- Game: Welcome to ParadiZe
addappid(1519090)
addappid(1519091, 1, "2d5077ab4a12bbbd2531a63465252235dfe5a29fda2bc1d15f32f45ad845fb34")
addappid(2832290, 0, "5886d673672152bd314c5736b0484cfb125791de45597f85a688f351fd18bdfb")
