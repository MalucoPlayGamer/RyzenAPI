-- 1519090's Lua and Manifest Created by Hubcap Manifest
-- Welcome to ParadiZe
-- Created: October 01, 2025 at 07:07:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 8
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1519090) -- Welcome to ParadiZe
-- MAIN APP DEPOTS
addappid(1519091, 1, "2d5077ab4a12bbbd2531a63465252235dfe5a29fda2bc1d15f32f45ad845fb34") -- Depot 1519091
setManifestid(1519091, "2214979011220795898", 32365541178)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Welcome to ParadiZe - 4K Textures (AppID: 2832290)
addappid(2832290)
addappid(2832290, 1, "5886d673672152bd314c5736b0484cfb125791de45597f85a688f351fd18bdfb") -- Welcome to ParadiZe - 4K Textures - Depot 2832290
setManifestid(2832290, "765992466201707095", 70199563867)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2581990) -- Welcome to ParadiZe - Military Cosmetic Pack
addappid(2582000) -- Welcome to ParadiZe - Holidays Cosmetic Pack
addappid(2582010) -- Welcome to ParadiZe - Phantasm Cosmetic Pack
addappid(2582020) -- Welcome to ParadiZe - Dark Fantasy Cosmetic Pack
addappid(2582030) -- Welcome to ParadiZe - Uniforms Cosmetic Pack
addappid(2582040) -- Welcome to ParadiZe - Archeology Quest
addappid(2643230) -- Welcome to ParadiZe - ParadiZe Zombot Skin