-- Lua provided by RyzenAPI
-- Game: Re:|THM - once upon a time

-- MAIN APPLICATION
addappid(2154940)
-- Game: addappid(2154940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154941, 1, "27d9d5edbfa05494a0c35a48bfa106dd69298ff95ea6cb960e450d770ba20e2a")
addappid(2154942, 1, "2b13529b81902c135801154d148b5637d42d9b0de61354e4464cef15eb95730e")
