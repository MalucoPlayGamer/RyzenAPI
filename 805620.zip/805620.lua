-- Lua provided by RyzenAPI
-- Game: 805620

-- MAIN APPLICATION
addappid(805620)
-- Game: addappid(805620)

-- MAIN APP DEPOTS / PACKAGES
addappid(805621, 1, "6e284f081afcf56a88aedb0e33c1bc8fa561599f1f0a902141909a1b41b2f472")
