-- Lua provided by RyzenAPI
-- Game: AppID 1967620

-- MAIN APPLICATION
addappid(1967620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967621, 1, "5a4ada6b82b389acea4cb451ce4f5ccab1f2f4a5302504d19dddfd7a00e2b181")
