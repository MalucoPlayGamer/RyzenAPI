-- Lua provided by RyzenAPI
-- Game: addappid(3700910)

-- MAIN APPLICATION
addappid(3700910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3700911, 1, "f3130d2f8e1f2c2e436e3e00de698c8ce441cdae21f06358aa9d578f93044c7e")
