-- Lua provided by SkyAPI 
-- Game: ender theater Playtest
addappid(2915270)
addappid(2915271, 1, "c313f63cc478b101ba48c870c7a255ab8d3e576c1e5c5c2e14cc3f0de59f0e7d")
