-- Lua provided by RyzenAPI
-- Game: Re:Kuroi

-- MAIN APPLICATION
addappid(1566350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566351, 1, "9c1b31857c371e3b654db327d68a6660c9fc87a3e3920092a97df3ee5d1963f7")

