-- Lua provided by RyzenAPI
-- Game: Carmageddon: Rogue Shift

-- MAIN APPLICATION
addappid(1712100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712101, 1, "0f5ee71fdc07136d363d44242df487ac0a5c6d831a49361c3fda646388c23f88")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
