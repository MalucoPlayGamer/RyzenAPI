-- Lua provided by RyzenAPI
-- Game: AppID 202930

-- MAIN APPLICATION
addappid(202930)

-- MAIN APP DEPOTS / PACKAGES
addappid(202931, 1, "c2a352b502b0b6e3a2ac2ff41d9e4f4228a18021ccd1db2b33a9bfe8c7b38a8c")

