-- Lua provided by RyzenAPI 
-- Game: Taboos: Cracks
addappid(1060670)
addappid(1060671, 1, "1390abcfefc4ee287f2d8c61a14da848f32ccbb18d1168383c08c58208cb2bd5")
addappid(1110320, 0, "9b516377089198530023b99ef085dbad29079f892ab447730104a02c0bc50d15")
