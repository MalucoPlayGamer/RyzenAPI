-- Lua provided by RyzenAPI
-- Game: Alien 911 Prologue

-- MAIN APPLICATION
addappid(1232980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232981, 1, "38ec65922d265f814b91fd61632e6ae9f340cdd993b7140e83a294e90033a04a")
