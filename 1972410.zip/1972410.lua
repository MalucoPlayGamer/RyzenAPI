-- Lua provided by RyzenAPI
-- Game: addappid(1972410)

-- MAIN APPLICATION
addappid(1972410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972411, 1, "8e2eb4b462aea5c905aa2fa0acb1456242cde96d55a102e7925b8ead5f720370")
