-- Lua provided by RyzenAPI
-- Game: Need for Drive - Open World Multiplayer Racing

-- MAIN APPLICATION
addappid(1531720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531721, 1, "7861a01b9e3d585ae48e3f177daa4faeee8ed5d75054aa087a6d957e712b0fff")
addappid(1531722, 1, "d87aa75193c782d26afc01fc4d679552e6763d697fcde2b71b0d29e63ff3527f")

