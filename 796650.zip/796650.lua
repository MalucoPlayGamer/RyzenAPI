-- Lua provided by RyzenAPI
-- Game: 796650

-- MAIN APPLICATION
addappid(796650)
-- Game: addappid(796650)

-- MAIN APP DEPOTS / PACKAGES
addappid(796651, 1, "447b2d4158f3abbc88ef239d5e42a567b41ce6654f07b5d6278c5e86e2fbd363")
