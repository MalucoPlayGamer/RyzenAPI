-- Lua provided by RyzenAPI
-- Game: Dark Adelita

-- MAIN APPLICATION
addappid(3575650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575651,0,"ebd3352a3628f4df1e4a1534a77c3a1f595e0faec78184e77279c8d454c68d43")

