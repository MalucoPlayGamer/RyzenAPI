-- Lua provided by RyzenAPI
-- Game: addappid(635310)

-- MAIN APPLICATION
addappid(635310)

-- MAIN APP DEPOTS / PACKAGES
addappid(635311, 1, "d21fa25f2a6d5c927f26a418fc8ca504358037fd119c85a875f2d171a490b75e")
