-- Lua provided by RyzenAPI
-- Game: addappid(1349960)

-- MAIN APPLICATION
addappid(1349960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349961, 1, "5385890225b4ecf26b6cf2455952902e06810dbdf38f5b18f7f6d0dfd91f79a5")
