-- 3841430's Lua and Manifest Created by Hubcap Manifest
-- Chaos Constructors
-- Created: August 08, 2026 at 22:54:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3841430) -- Chaos Constructors
-- MAIN APP DEPOTS
addappid(3841431, 1, "72086e012e4f8072e6ae31aa5a4eccf77e4a0dd2b0767bca7d4f5ce4a1304f1b") -- Depot 3841431
setManifestid(3841431, "2598896167012874620", 1530084653)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)