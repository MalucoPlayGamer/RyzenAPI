-- Lua provided by RyzenAPI
-- Game: Chaos Constructors

-- MAIN APPLICATION
addappid(3841430) -- Chaos Constructors

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3841431, 1, "72086e012e4f8072e6ae31aa5a4eccf77e4a0dd2b0767bca7d4f5ce4a1304f1b") -- Depot 3841431

