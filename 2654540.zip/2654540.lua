-- Lua provided by RyzenAPI 
-- Game: 无休仙途
addappid(2654540)
addappid(2654541, 1, "593e4681bf6fca95ddd5ce89407908fa324bdbeb85e7a28dfb1356afb44dc55f")
