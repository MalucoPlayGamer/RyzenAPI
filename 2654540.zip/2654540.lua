-- Lua provided by RyzenAPI
-- Game: addappid(2654540)

-- MAIN APPLICATION
addappid(2654540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654541, 1, "593e4681bf6fca95ddd5ce89407908fa324bdbeb85e7a28dfb1356afb44dc55f")
