-- Lua provided by RyzenAPI
-- Game: 無休仙途/EndlessJourney

-- MAIN APPLICATION
addappid(2654540)
addappid(3367330)
addappid(3367340)
addappid(4148560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654541,0,"593e4681bf6fca95ddd5ce89407908fa324bdbeb85e7a28dfb1356afb44dc55f")

