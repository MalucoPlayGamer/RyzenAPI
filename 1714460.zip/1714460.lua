-- Lua provided by RyzenAPI
-- Game: 1714460

-- MAIN APPLICATION
addappid(1714460)
-- Game: addappid(1714460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1714461, 1, "f0596fc525aada890a746b5608bca3f13f2b303a9562bc7821d7b04f285b61ff")
