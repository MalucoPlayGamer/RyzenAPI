-- Lua provided by SkyAPI 
-- Game: Starry Knight
addappid(1714460)
addappid(1714461, 1, "f0596fc525aada890a746b5608bca3f13f2b303a9562bc7821d7b04f285b61ff")
