-- Lua provided by RyzenAPI
-- Game: Game: AppID 1497230

-- MAIN APPLICATION
addappid(1497230)
-- Game: addappid(1497230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497231, 1, "96e85329fae76de542768cfd9d62b292dd37ca033f0708ada65c39c5e2f6db9a")
