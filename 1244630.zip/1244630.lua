-- Lua provided by RyzenAPI
-- Game: House Builder

-- MAIN APPLICATION
addappid(1244630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1244631, 1, "ba806487fbb3c4c74be56020cc45597f544a05be23107ee399efb2418e43e149")
