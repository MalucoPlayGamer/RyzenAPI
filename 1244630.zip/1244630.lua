-- Lua provided by RyzenAPI
-- Game: House Builder

-- MAIN APPLICATION
addappid(2802330) -- House Builder - The Atomic Age DLC
addappid(3024210) -- House Builder - Medieval DLC
addappid(3151430) -- House Builder - Electric City Expansion Pack
addappid(3151460) -- House Builder - Garden DLC
addappid(3348130) -- House Builder - Deconstruction DLC
addappid(3698910) -- House Builder - Mechitecture Edition DLC
addappid(3967780) -- House Builder - Egyptian DLC
addappid(4218810) -- House Builder - Tiny Houses DLC
addappid(4548780) -- House Builder - Paving & Driveways DLC

-- MAIN APP DEPOTS / PACKAGES
addappid(1244630, 1, "393feff359e86d26bd69d6c642e87351d9e7f864475440b3c911f4ef376f107a")
addappid(1244631, 1, "ba806487fbb3c4c74be56020cc45597f544a05be23107ee399efb2418e43e149")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3392290)
