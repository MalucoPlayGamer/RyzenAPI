-- Generated with Luie @ https://lua.tools/
-- 1244630 - House Builder
-- Generated 2026-08-07 01:44:04 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(1244630, 1, "393feff359e86d26bd69d6c642e87351d9e7f864475440b3c911f4ef376f107a")

-- Main Depots
addappid(1244631, 1, "ba806487fbb3c4c74be56020cc45597f544a05be23107ee399efb2418e43e149")
setManifestid(1244631, "4329690950320444643", 41872088935)

-- DLC's (no depot keys required)
addappid(2802330) -- House Builder - The Atomic Age DLC
addappid(3024210) -- House Builder - Medieval DLC
addappid(3151430) -- House Builder - Electric City Expansion Pack
addappid(3151460) -- House Builder - Garden DLC
addappid(3348130) -- House Builder - Deconstruction DLC
addappid(3698910) -- House Builder - Mechitecture Edition DLC
addappid(3967780) -- House Builder - Egyptian DLC
addappid(4218810) -- House Builder - Tiny Houses DLC
addappid(4548780) -- House Builder - Paving & Driveways DLC

-- Token-locked DLCs (couldn't read depots): 3392290
