-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3409100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3409100,0,"022c53af8a11b97bb814ebdafbe6e8607a0a5044bc27202e340e3094dd4d6198")
