-- Lua provided by RyzenAPI
-- Game: addappid(533710)

-- MAIN APPLICATION
addappid(533710)

-- MAIN APP DEPOTS / PACKAGES
addappid(533711, 1, "1ac515b9cc1ef319c870f17f1bf9e517ebcdbf66d89dab833ac5740100630864")
