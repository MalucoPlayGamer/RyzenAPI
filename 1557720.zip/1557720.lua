-- Lua provided by RyzenAPI
-- Game: Game: RoboDunk

-- MAIN APPLICATION
addappid(1557720)
-- Game: addappid(1557720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557721, 1, "85510acbb4e0f8b0d52a1bdc200f92518fd23520eff42d5a5caef6eb79fc806d")
