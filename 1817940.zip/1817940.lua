-- Lua provided by RyzenAPI
-- Game: Love Delivery

-- MAIN APPLICATION
addappid(1817940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817941, 1, "f26af5c4bc5a400655e5539f7d88b1ef817a638c4d1766f58eec7dcea8f84bb8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3482910)
addappid(5018850)
addappid(5018860)
addappid(5018870)
