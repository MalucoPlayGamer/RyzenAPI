-- Lua provided by RyzenAPI
-- Game: Soulcaster

-- MAIN APPLICATION
addappid(1389300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1389301, 1, "6f484ca9d4133384d56228f257380fadd6c43f0ad7cf79201de50b3272bbffca")

