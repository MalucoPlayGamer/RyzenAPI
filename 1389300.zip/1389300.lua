-- Lua provided by RyzenAPI
-- Game: Soulcaster

-- MAIN APPLICATION
addappid(1389300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389301, 1, "6f484ca9d4133384d56228f257380fadd6c43f0ad7cf79201de50b3272bbffca")

