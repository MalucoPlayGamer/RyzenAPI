-- Lua provided by RyzenAPI
-- Game: Tom Clancy's Rainbow Six: Lockdown

-- MAIN APPLICATION
addappid(15000)

-- MAIN APP DEPOTS / PACKAGES
addappid(15001, 1, "d496db72edb3fefcb19da1f5fac0b8d01fb9e4af9aeec978beca241b2b78f501")
addappid(15002, 1, "8b25be7300a5dde6b588e0c1938e533266d0210f52660307ba995f91c0e32b1f")
addappid(15003, 1, "c0c2e456ff2fc4c3efbe24d902bf4753a389e0954233aa6e03af250896bbd539")
addappid(15004, 1, "2707863407c42628bfe89180597fd557ef75dad6d9b604180c24a768c6b842ac")
