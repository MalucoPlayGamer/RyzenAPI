-- Lua provided by RyzenAPI
-- Game: Game: AppID 3148680

-- MAIN APPLICATION
addappid(3148680)
-- Game: addappid(3148680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148681, 1, "f6dcd8a9cde74424bf8719d81c53fed0212950374ef92f841a1abab7cdc342b5")
