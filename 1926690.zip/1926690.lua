-- Lua provided by RyzenAPI
-- Game: This Time - Part One

-- MAIN APPLICATION
addappid(1926690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926691, 1, "cf4028e7191021b3cca1d4dc5c77acb0dd1f168c90911b0ad25726a636e2366d")
addappid(1955190, 0, "f6abec27c552d1c755bbad53d09f1c2427eb60c19c442ba32571c7d5687f6b82")
addappid(1955198, 0, "555c1aba665604b89f90e133b8cb5bcf2343ad0e7332ca6ad0ea1a8b52f719a4")
addappid(1955199, 0, "b006de7138fcbe6f83db7c69c315da7bccf98c67865b089cb361c2fa9b0f3301")
addappid(2025020, 0, "9d44e6560360245e5e43598661374c2e664038e2ab4951a3561b3e2ccd5d5fde")
addappid(2025024, 0, "d4e09f960c2607660d1cd178ccf0b7a78d03844112ca242857e9800ea6fca053")
addappid(2093260, 0, "a302cdd1372313d8f9581b00354363b3266f5c618119271e6164b3afa7140faa")
addappid(2249710, 0, "055ce6c241651de14def6beea17c65f87262e359bc26bcd1d0d98f9336ff368d")
addappid(2249719, 0, "f6f11682d95acf665ff991d6d408029de5bdc4c5c10f9ca8688b5f78bf57059d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4356910)
addappid(4356940)
addappid(4356950)
addappid(4356960)
addappid(4356970)
