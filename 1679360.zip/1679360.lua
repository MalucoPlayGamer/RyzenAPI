-- Lua provided by RyzenAPI
-- Game: addappid(1679360)

-- MAIN APPLICATION
addappid(1679360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679362,0,"a29889bba6b006057643e3704cccbd1d2bf6c17b2ee68a06459b15701812f72c")
