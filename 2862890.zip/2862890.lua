-- Lua provided by RyzenAPI
-- Game: Become the Moon

-- MAIN APPLICATION
addappid(2862890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862891, 1, "10ad0dd8db263898d9bc82c8320d0b7f6cf85b2a36c1d28144eba335dda40122")
