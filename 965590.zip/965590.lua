-- Lua provided by RyzenAPI
-- Game: AppID 965590

-- MAIN APPLICATION
addappid(965590)
-- Game: addappid(965590)

-- MAIN APP DEPOTS / PACKAGES
addappid(965591, 1, "0a5eae0931afc048c5a5e8dda7db0d9b452ab42f6b2012132ea5624bf91abb55")
addappid(965592, 1, "cb2c6fe1072608eeff1c89077eb46032216f286377ff9b36b949bb479468f02f")
