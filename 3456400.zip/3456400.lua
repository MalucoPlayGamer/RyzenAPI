-- Lua provided by RyzenAPI
-- Game: The Attic 18th - Paranormal Anomaly Hunting Demo

-- MAIN APPLICATION
addappid(3456400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456401, 1, "1d3521c7f9290be7f9786f18a4d059b16be00f0a5be0538c8956570deff37722")
