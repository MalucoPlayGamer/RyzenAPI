-- Lua provided by RyzenAPI
-- Game: Creature Lab

-- MAIN APPLICATION
addappid(1309990)
addappid(2447620)
-- Game: addappid(1309990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309991, 1, "37de12adce2c809e03b101c520c6bc54acb04df7e6a9c7890108e1e0dbc00f1f")
