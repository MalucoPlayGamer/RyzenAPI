-- Lua provided by RyzenAPI
-- Game: Creature Lab

-- MAIN APPLICATION
addappid(1309990)
addappid(2447620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1309991, 1, "37de12adce2c809e03b101c520c6bc54acb04df7e6a9c7890108e1e0dbc00f1f")

