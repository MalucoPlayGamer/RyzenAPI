-- Lua provided by RyzenAPI
-- Game: Monster City: A Monster College Story

-- MAIN APPLICATION
addappid(3530770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3530771, 1, "83553cd2e6d4841db3948fdeed43718e46a19a14e601ca1c49c4f6525d33d159")

