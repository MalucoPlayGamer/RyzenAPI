-- Lua provided by RyzenAPI
-- Game: AppID 956240

-- MAIN APPLICATION
addappid(956240)
-- Game: addappid(956240)

-- MAIN APP DEPOTS / PACKAGES
addappid(956241, 1, "08a8aed2f22320bd2c996be47074e47f17ec538410efc078d752366eca0e3f2b")
