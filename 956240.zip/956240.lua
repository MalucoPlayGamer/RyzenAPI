-- Lua provided by RyzenAPI
-- Game: Simson Tuningwerkstatt 3D

-- MAIN APPLICATION
addappid(956240)
addappid(1061810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(956241, 1, "08a8aed2f22320bd2c996be47074e47f17ec538410efc078d752366eca0e3f2b")

