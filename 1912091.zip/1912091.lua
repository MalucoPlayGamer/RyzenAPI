-- Lua provided by RyzenAPI
-- Game: addappid(1912091)

-- MAIN APPLICATION
addappid(1912091)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912091,0,"b77da2817675e57418864ccebf40945d9a32f723b658e5879a69fdd5fa984bba")
