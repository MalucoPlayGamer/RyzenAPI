-- Lua provided by RyzenAPI
-- Game: Boo Bunny Plague

-- MAIN APPLICATION
addappid(313590)

-- MAIN APP DEPOTS / PACKAGES
addappid(313592,0,"48fab49619b4239b61d857e8c0a3537141468d7953687197178f241986815889")
addappid(313593,0,"bea459f1994ad1ca85caf9acc66b5b9f49aef5918b8d495f3aace9f47ff282b3")
addappid(315890,0,"05218fa3e771054b5e2543ee49a45e172eb20a2ee967cf6895116989c9dc8908")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
