-- Lua provided by RyzenAPI
-- Game: Gyelfars

-- MAIN APPLICATION
addappid(1873300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873301, 1, "d31c49f9d96366a8c7c6717edb3e8c77a58d869789485cf149d7a15bad15dc07")
