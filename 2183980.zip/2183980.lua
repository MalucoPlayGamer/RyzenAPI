-- Lua provided by RyzenAPI 
-- Game: AppID 2183980
addappid(2183980)
addappid(2183981, 1, "43c364ea7f16618ddcd43a4499b69d6a270007f63a1ea91a7eefbe1e156e3e99")
