-- Lua provided by RyzenAPI
-- Game: Mighty Fling

-- MAIN APPLICATION
addappid(1343920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343921, 1, "4e6d3a1a73718e007a6f99c8bb08be67255d24979d0d142104f6d33b070fd020")
