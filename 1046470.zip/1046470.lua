-- Lua provided by RyzenAPI
-- Game: Deep the Game

-- MAIN APPLICATION
addappid(1046470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046471, 1, "fe4bf720ca4002788ea165965d067a85caaa430babdb234c4f3eced178db0eec")
addappid(1046472, 1, "ba13afb92e78bd4edafc0776f1ac2dac4106291abbd4d63082775951e57e1a43")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1245390)
addappid(1411530)
