-- Lua provided by RyzenAPI
-- Game: 1046470

-- MAIN APPLICATION
addappid(1046470)
-- Game: addappid(1046470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046471, 1, "fe4bf720ca4002788ea165965d067a85caaa430babdb234c4f3eced178db0eec")
addappid(1046472, 1, "ba13afb92e78bd4edafc0776f1ac2dac4106291abbd4d63082775951e57e1a43")
