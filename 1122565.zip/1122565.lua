-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – Death - “Crystal Mountain”

-- MAIN APPLICATION
addappid(1122565)
-- Game: addappid(1122565)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122565,0,"15ec1501dcb2c715abe26443ec3c1f34208562687762657bb2358448768b111b")
