-- Lua provided by RyzenAPI
-- Game: Game: Pixel Town: Akanemachi Mystery 2

-- MAIN APPLICATION
addappid(2279310)
-- Game: addappid(2279310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279311, 1, "9d94d85dffdb64626a82b4741f52f9c21a85a37cf3d4a31eadb3eccf265d7446")
addappid(2279312, 1, "6bc6275f228f5df08c028696d9d0f1d399e2a754ffe0b476b6c79eb5e88d4e4f")
addappid(2279313, 1, "5a1f1fa15aeb916bb7837aa0e8af4c7f123346749a9113059a8f5b53f85a7738")
