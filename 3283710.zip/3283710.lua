-- Lua provided by RyzenAPI
-- Game: 3283710

-- MAIN APPLICATION
addappid(3283710)
-- Game: addappid(3283710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3283710,0,"cc74b881e3d2d78f5d8c62ba58c97752988f87d0110f588d62092a73ac4b84df")
