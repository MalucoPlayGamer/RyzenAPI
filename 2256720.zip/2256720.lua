-- Lua provided by SkyAPI 
-- Game: Elder Trial：Prologue
addappid(2256720)
addappid(2256721, 1, "de3be9abc5a8b373162bb571707d49228175bcdb729cd090d9c423fda9b41662")
addappid(2282280)
