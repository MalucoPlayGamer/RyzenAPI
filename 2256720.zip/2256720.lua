-- Lua provided by RyzenAPI
-- Game: addappid(2256720)

-- MAIN APPLICATION
addappid(2256720)
addappid(2282280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256721, 1, "de3be9abc5a8b373162bb571707d49228175bcdb729cd090d9c423fda9b41662")
