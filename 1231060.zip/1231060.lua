-- Lua provided by RyzenAPI
-- Game: 1231060

-- MAIN APPLICATION
addappid(1231060)
-- Game: addappid(1231060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231060,0,"57c96d96ed099f46e3d7174e26bcfdb377ae60470762ef2e56b1db35569117b3")
