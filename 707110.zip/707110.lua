-- Lua provided by SkyAPI 
-- Game: AppID 707110
addappid(707110)
addappid(707111, 1, "c3ead62966112b4945bc4dd8362e27b6e5777e3778aabdeddeeb6a7a7d42daa3")
