-- Lua provided by RyzenAPI
-- Game: Wings! Remastered Edition

-- MAIN APPLICATION
addappid(320840)

-- MAIN APP DEPOTS / PACKAGES
addappid(320841, 1, "90e1aa93d92ee644f4eee09769de4e4c3ea5bcee5183688c8ebe9703df91f9d0")
addappid(320842, 1, "340b483b36e95fda62c5548902149537eea7085d51e96cc5418ad15ee12e1f72")
addappid(320845, 1, "5d82332cc6cc6fe11a8b0f25ee1d54020fd9ef9765a6772809420188c34e8fc2")
