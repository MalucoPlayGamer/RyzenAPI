-- Lua provided by SkyAPI 
-- Game: AppID 1236760
addappid(1236760)
addappid(1236761, 1, "633f647c10c93f1e8cdab3fa80540ce5e02d7db9d3f3a0937efc23fcac3c5f20")
