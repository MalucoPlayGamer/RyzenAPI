-- Lua provided by RyzenAPI
-- Game: Puzzle Game: Lee inside TV

-- MAIN APPLICATION
addappid(1170110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170111, 1, "2a06e66c267fe47c3f73738e5fcbdb5a76e20b01722af1f2a5f78df69e4fdcd0")
