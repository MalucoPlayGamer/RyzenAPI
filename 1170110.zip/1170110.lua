-- Lua provided by RyzenAPI
-- Game: Puzzle Game: Lee inside TV

-- MAIN APPLICATION
addappid(1170110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1170111, 1, "2a06e66c267fe47c3f73738e5fcbdb5a76e20b01722af1f2a5f78df69e4fdcd0")

