-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1751590)
-- Game: addappid(1751590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751590,0,"5bee4d490072dbf2ac4e16d6f49f57bbbdf14c60e055c1fed847ac53e4499722")
