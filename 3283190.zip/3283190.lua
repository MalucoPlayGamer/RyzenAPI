-- Lua provided by RyzenAPI
-- Game: 3283190

-- MAIN APPLICATION
addappid(3283190)
-- Game: addappid(3283190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3283191, 1, "cd49ab9ee3cf46c98d62fc42b8079f7f741a838003eac99c2dc4c97704974af1")
