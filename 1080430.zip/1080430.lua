-- Lua provided by RyzenAPI
-- Game: 1080430

-- MAIN APPLICATION
addappid(1080430)
-- Game: addappid(1080430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080430,0,"7d0d7a3f0141f8165123ec95c6b75dc181ff41ae0dd5f16f6c56f81cca6bf813")
