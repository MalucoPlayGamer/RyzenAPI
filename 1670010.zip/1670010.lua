-- Lua provided by RyzenAPI
-- Game: 1670010

-- MAIN APPLICATION
addappid(1670010)
-- Game: addappid(1670010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670011, 1, "3fc588c1a171bec84bacf0776c15cfa98bed3908035d842294064b702e8a06bb")
