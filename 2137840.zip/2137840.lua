-- Lua provided by RyzenAPI
-- Game: AppID 2137840

-- MAIN APPLICATION
addappid(2137840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137841, 1, "346989e2a7f2b8cdc86edc42808ef6198770a072af8ccd4ff74af5bbdb24296f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
