-- Lua provided by RyzenAPI
-- Game: AppID 2137840

-- MAIN APPLICATION
addappid(2137840)
-- Game: addappid(2137840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137841, 1, "346989e2a7f2b8cdc86edc42808ef6198770a072af8ccd4ff74af5bbdb24296f")
