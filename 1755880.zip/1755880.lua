-- Lua provided by RyzenAPI
-- Game: Island of Lust

-- MAIN APPLICATION
addappid(1755880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755881, 1, "7002daf482738e7067f34a952ac3542141f978945be0e73d84cb947e93f43fb1")

