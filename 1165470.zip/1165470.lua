-- Lua provided by RyzenAPI
-- Game: 1165470

-- MAIN APPLICATION
addappid(1165470)
-- Game: addappid(1165470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165471, 1, "729df57e724c5f92cda2f8c01ca7012f00e3e18db5841504188a6d521dcc7f8c")
