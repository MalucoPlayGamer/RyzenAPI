-- Lua provided by RyzenAPI
-- Game: Survivor Mercs

-- MAIN APPLICATION
addappid(2141520)
-- Game: addappid(2141520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141521, 1, "e1a9dbd6086605f9927671be457d84bc54801cfa77bd0657fef24460f2a76b43")
