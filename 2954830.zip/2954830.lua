-- Lua provided by RyzenAPI
-- Game: addappid(2954830)

-- MAIN APPLICATION
addappid(2954830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2954831, 1, "4e3e1465723e0c744bebbae0b9b0a03b78753f435800c1aa3addaac3c93c9bb1")
