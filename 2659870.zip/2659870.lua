-- Lua provided by RyzenAPI
-- Game: 2659870

-- MAIN APPLICATION
addappid(2659870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659873,0,"cb01e1856cdff662e2694fd9dc2f653c9623125cedc8c066ffca1961fde30df7")

