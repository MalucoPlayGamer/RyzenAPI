-- Lua provided by RyzenAPI
-- Game: 三国乱传 Demo

-- MAIN APPLICATION
addappid(1368250)
-- Game: addappid(1368250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368251, 1, "90b1a6cd1ac0613562b391b5f0e809a6c263195c0fabfae2cb82cd17af1134e8")
