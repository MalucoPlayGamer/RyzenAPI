-- Lua provided by RyzenAPI
-- Game: addappid(2771380)

-- MAIN APPLICATION
addappid(2771380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771381, 1, "1a0297591717dcf26a544af48286ad8f21bfda7bab21e0ed34b5f5769364fa02")
