-- Lua provided by RyzenAPI
-- Game: 奇妙大富翁(Wonderful Richman)

-- MAIN APPLICATION
addappid(2771380)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2771381, 1, "1a0297591717dcf26a544af48286ad8f21bfda7bab21e0ed34b5f5769364fa02")

