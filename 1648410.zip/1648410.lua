-- Lua provided by RyzenAPI
-- Game: addappid(1648410)

-- MAIN APPLICATION
addappid(1648410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648410,0,"8df8c450e0c32f45b9f8cf8f28fb40e842469ed05508eb5381222acd4028a65b")
