-- Lua provided by RyzenAPI 
-- Game: Jewels of the Mysterious Woodland
addappid(685370)
addappid(685371, 1, "60bc243f7723a45d60a30401ec60e09deb93f2634e484893472440031b8a6542")
addappid(741090)
addappid(743520)
addappid(744310)
addappid(745440)
