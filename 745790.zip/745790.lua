-- Lua provided by RyzenAPI
-- Game: Chambara

-- MAIN APPLICATION
addappid(745790)

-- MAIN APP DEPOTS / PACKAGES
addappid(745791,0,"4c8f4ffb56039fdcd36863f5110df683c4ea4aa89ad0f80dfc9f1bf78283abb5")

