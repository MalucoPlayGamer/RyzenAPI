-- Lua provided by RyzenAPI
-- Game: IMM Defense

-- MAIN APPLICATION
addappid(801150)

-- MAIN APP DEPOTS / PACKAGES
addappid(801151, 1, "e59e4c00680fd03509783ec6ef24d6ad1308dc0028cdb92f0f58a270ac8afa75")
