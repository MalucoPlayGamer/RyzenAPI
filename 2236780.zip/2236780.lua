-- Lua provided by RyzenAPI
-- Game: AppID 2236780

-- MAIN APPLICATION
addappid(2236780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236781, 1, "895a8a6ca5148e0c4fa462c653c30dc2a5ea037d57280bc5b47ffe6b4aebe49d")

