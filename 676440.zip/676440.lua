-- Lua provided by RyzenAPI
-- Game: addappid(676440)

-- MAIN APPLICATION
addappid(676440)

-- MAIN APP DEPOTS / PACKAGES
addappid(676441, 1, "24b11cb720fd07129c2f4b2bbd6ac01704634fc81759471a4c7d01a19fe91959")
