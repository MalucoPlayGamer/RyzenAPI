-- Lua provided by RyzenAPI
-- Game: Sex of Thrones 👑 Prologue

-- MAIN APPLICATION
addappid(2756820)
-- Game: addappid(2756820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756821, 1, "45f15a07be02c4ae09172af492cb169235dd2a02271ecea40d5791858269a71b")
