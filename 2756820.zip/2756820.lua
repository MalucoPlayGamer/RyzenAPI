-- Lua provided by RyzenAPI
-- Game: Sex of Thrones 👑 Prologue

-- MAIN APPLICATION
addappid(2756820)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(2756821, 1, "45f15a07be02c4ae09172af492cb169235dd2a02271ecea40d5791858269a71b")

