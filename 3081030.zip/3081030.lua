-- Lua provided by RyzenAPI
-- Game: 束縛彼女とペットな僕 - I'm Your Pet -

-- MAIN APPLICATION
addappid(3081030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081031, 1, "d25c1cb3bb85eace9b72aaf4145a8f7558ac26e46557715e33934af5ad648c69")
