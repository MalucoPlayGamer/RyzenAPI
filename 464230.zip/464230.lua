-- Lua provided by RyzenAPI
-- Game: Colours of Magic: Aqua Teeter

-- MAIN APPLICATION
addappid(464230)

-- MAIN APP DEPOTS / PACKAGES
addappid(464231, 1, "dcf6a15d5341c22954e0009401e2734fc4b293372f8d95fc9f19e7ba9a204dc9")
addappid(464232, 1, "0339b2758c66334d43a4fe85c9bf48cba074433022b578eb893567e5339d1bf8")
addappid(464233, 1, "ae2fd339e7363d6534aa9c56e684e8e3c4ba19279de6abad8b6d24e7b928ac22")

