-- Lua provided by RyzenAPI
-- Game: Game: Alliance Peacefighter

-- MAIN APPLICATION
addappid(3538210)
-- Game: addappid(3538210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3538211, 1, "1f84a5860012dd2cd53854d5322207a162b8b88c5b8f4e0b3333e485e6daa414")
