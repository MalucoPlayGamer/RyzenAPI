-- 4294490's Lua and Manifest Created by Hubcap Manifest
-- KOTAMON: My Sis Found A Super-Rare Card In Her Cereal Box, So I Became A Garbage Man To Find The Entire Collection And Earn $1,000,000
-- Created: August 20, 2026 at 12:05:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(4294490) -- KOTAMON: My Sis Found A Super-Rare Card In Her Cereal Box, So I Became A Garbage Man To Find The Entire Collection And Earn $1,000,000
-- MAIN APP DEPOTS
addappid(4294491, 1, "e83098292c96c3780bd4db1e95c7b37fccfada8df56629ed81142179291ce66c") -- Depot 4294491
setManifestid(4294491, "6431291434694189533", 885819288)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- KOTAMON - Supporter Pack (AppID: 5015110) - missing depot keys
-- addappid(5015110)