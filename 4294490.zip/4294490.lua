-- Lua provided by RyzenAPI
-- Game: KOTAMON: My Sis Found A Super-Rare Card In Her Cereal Box, So I Became A Garbage Man To Find The Entire Collection And Earn $1,000,000

-- MAIN APPLICATION
addappid(5015110)

-- MAIN APP DEPOTS / PACKAGES
addappid(4294490, 1, "641359621dca9cdc6350136563224c4d46a4bff91f576279ae7f2f4914be5f88") -- KOTAMON: My Sis Found A Super-Rare Card In Her Cereal Box, So I Became A Garbage Man To Find The Entire Collection And Earn $1,000,000
addappid(4294491, 1, "e83098292c96c3780bd4db1e95c7b37fccfada8df56629ed81142179291ce66c") -- Depot 4294491
addappid(5015110, 1, "48d3bcb60b7b68187a801a58c622f5db4ed74090647842985c8f93ff360b53e4") -- KOTAMON - Supporter Pack - Depot 5015110

