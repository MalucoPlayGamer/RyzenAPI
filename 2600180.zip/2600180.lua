-- Lua provided by SkyAPI 
-- Game: Night Grove
addappid(2600180)
addappid(2600181, 1, "9fd30d64aace539e0819f6ea668c2e38d8b20724ac3a8384b7804614987c0bd9")
