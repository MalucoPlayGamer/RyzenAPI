-- Lua provided by RyzenAPI
-- Game: Game: Night Grove

-- MAIN APPLICATION
addappid(2600180)
-- Game: addappid(2600180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600181, 1, "9fd30d64aace539e0819f6ea668c2e38d8b20724ac3a8384b7804614987c0bd9")
