-- Lua provided by RyzenAPI
-- Game: AppID 622630

-- MAIN APPLICATION
addappid(622630)

-- MAIN APP DEPOTS / PACKAGES
addappid(622631, 1, "3dde865e88c8187a07881bd292c1af19bc6d99b0dbae50a6787eb111afb517af")
