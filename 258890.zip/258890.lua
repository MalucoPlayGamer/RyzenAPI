-- Lua provided by RyzenAPI
-- Game: Type:Rider

-- MAIN APPLICATION
addappid(258890)
-- Game: addappid(258890)

-- MAIN APP DEPOTS / PACKAGES
addappid(258891, 1, "16d478a42114838f79113cc60def5029ffaf1711b74e1f3d5b6ed2198e8e4dbd")
addappid(258892, 1, "8d9c74ccd59cc5171c70375497c1f81a1c690eb0ddb68a0e411560344f675863")
addappid(258893, 1, "8f43e6e72033e8ebfdaa312aad54a42872650f63d27605f58cee1f6700ca3d30")
