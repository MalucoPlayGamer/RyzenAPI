-- Lua provided by RyzenAPI
-- Game: AppID 436230

-- MAIN APPLICATION
addappid(436230)

-- MAIN APP DEPOTS / PACKAGES
addappid(436231, 1, "69eb0d458d1681ca7d17aba34293b4ea75155938e3b5b24c64da1264ca44473f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
