-- Lua provided by RyzenAPI
-- Game: AppID 436230

-- MAIN APPLICATION
addappid(436230)
-- Game: addappid(436230)

-- MAIN APP DEPOTS / PACKAGES
addappid(436231, 1, "69eb0d458d1681ca7d17aba34293b4ea75155938e3b5b24c64da1264ca44473f")
