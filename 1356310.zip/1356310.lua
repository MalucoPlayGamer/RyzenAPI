-- Lua provided by RyzenAPI
-- Game: A Total War Saga: Troy – Assembly Kit

-- MAIN APPLICATION
addappid(1356310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1356311, 1, "6b89f9fd75bb795354e246fe85d77bb7a73e6fb63339dbca562f8b9c7b3c39b5")
