-- Lua provided by RyzenAPI
-- Game: addappid(918380)

-- MAIN APPLICATION
addappid(918380)

-- MAIN APP DEPOTS / PACKAGES
addappid(918381, 1, "71c412dc554ae14f32091cba7fc0822ca5ed25bb3a41adde2e6548caf504fcbc")
