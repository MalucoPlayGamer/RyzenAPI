-- Lua provided by RyzenAPI 
-- Game: Salamander County Public Television
addappid(1521810)
addappid(1521811, 1, "9d7047b088711f4dfc8b5a232855e1c7b669fde23eb09398587660a36b7c617d")
