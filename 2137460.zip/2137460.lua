-- Lua provided by SkyAPI 
-- Game: Jawbreaker
addappid(2137460)
addappid(2137461, 1, "bac3fc1b070d64933c3ff1d8e516e1ad265af353236f910914f87fc50705dd55")
