-- Lua provided by RyzenAPI
-- Game: Game: Narcosis

-- MAIN APPLICATION
addappid(366870)
addappid(821340)
-- Game: addappid(366870)

-- MAIN APP DEPOTS / PACKAGES
addappid(366871, 1, "118a5e7c6f31f0c69ff133c1b9f475d58d7521c77db90ce5272af6bdd4ef4a88")
addappid(366872, 1, "d59fda9ec145a196eb83e9b5bb24cab37308786bae4a26047d97768918dc712e")
addappid(366873, 1, "f8e92cbb487f0271eaac79ee8a6e93bc29ca7087b8728e902cfec5c5c133b048")
