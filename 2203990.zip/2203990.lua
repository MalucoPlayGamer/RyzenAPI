-- Lua provided by RyzenAPI
-- Game: AppID 2203990

-- MAIN APPLICATION
addappid(2203990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203991, 1, "3c4d749132d00865f58801d745f2166b6261561d767999c9935d3cad3ae45fa4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
