-- Lua provided by RyzenAPI
-- Game: Mika's Battle S 2

-- MAIN APPLICATION
addappid(3378640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3378641, 1, "94c1a46614a6ac4b850e8d94e179949f95a6ecdba8ce7d75bfedf5e7661483e7")
