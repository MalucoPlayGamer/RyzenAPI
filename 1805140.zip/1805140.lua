-- Lua provided by RyzenAPI 
-- Game: ARAIGNEES
addappid(1805140)
addappid(1805141, 1, "e2226dda6020569f16156f33a4a82354ec22e2007257c4def87f26dd592085e0")
