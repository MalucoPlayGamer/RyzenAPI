-- Lua provided by RyzenAPI 
-- Game: SAVE
addappid(3123290)
addappid(3123291, 1, "8b9407097f449af2699306a838f2412ba2c897736787a641f8a5f8cd44cbe00d")
