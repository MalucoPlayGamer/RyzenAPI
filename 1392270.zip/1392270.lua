-- Lua provided by RyzenAPI
-- Game: Lynn , ArtBook + Commentary

-- MAIN APPLICATION
addappid(1392270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392270,0,"b9b000e34dd1de90466422e4ae9b1e8d01d78ef01b37f71aa80893285b2bff04")
