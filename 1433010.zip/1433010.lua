-- Lua provided by RyzenAPI
-- Game: Tennis Manager 2021

-- MAIN APPLICATION
addappid(1433010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433011, 1, "d4a8a591ce946739c22617c5459795ef6d9c18a8916f772c679b39ce58503ff7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
