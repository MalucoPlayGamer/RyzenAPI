-- Lua provided by RyzenAPI
-- Game: Tennis Manager 2021

-- MAIN APPLICATION
addappid(1433010)
-- Game: addappid(1433010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433011, 1, "d4a8a591ce946739c22617c5459795ef6d9c18a8916f772c679b39ce58503ff7")
