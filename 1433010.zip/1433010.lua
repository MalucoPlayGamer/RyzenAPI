-- Lua provided by SkyAPI 
-- Game: Tennis Manager 2021
addappid(1433010)
addappid(1433011, 1, "d4a8a591ce946739c22617c5459795ef6d9c18a8916f772c679b39ce58503ff7")
