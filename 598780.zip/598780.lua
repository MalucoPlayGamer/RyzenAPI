-- Lua provided by RyzenAPI
-- Game: AppID 598780

-- MAIN APPLICATION
addappid(598780)

-- MAIN APP DEPOTS / PACKAGES
addappid(598781, 1, "d082f1da010555c2772dd5e33e191c71ebd1129090113b432bf2e901e20e7766")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
