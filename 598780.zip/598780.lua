-- Lua provided by RyzenAPI
-- Game: Game: AppID 598780

-- MAIN APPLICATION
addappid(598780)
-- Game: addappid(598780)

-- MAIN APP DEPOTS / PACKAGES
addappid(598781, 1, "d082f1da010555c2772dd5e33e191c71ebd1129090113b432bf2e901e20e7766")
