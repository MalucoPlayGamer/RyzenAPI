-- Lua provided by RyzenAPI
-- Game: Game: 后室：彼阳的晚意(序章)-Backrooms:Beyond one year(Prologue)

-- MAIN APPLICATION
addappid(2888730)
-- Game: addappid(2888730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888731, 1, "a7159e0484a62e8a5c66e17f77c1533b2f37137909c4542ef3395bc1ea197723")
