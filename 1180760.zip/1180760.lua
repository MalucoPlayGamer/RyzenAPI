-- Lua provided by RyzenAPI
-- Game: Risk of Rain 2 Dedicated Server

-- MAIN APPLICATION
addappid(1180760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180761, 1, "3b0d7b5e164da8fe020c9690614bdbfd2276aa8f97b6e199f3c7131b60494459")
