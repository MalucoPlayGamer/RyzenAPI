-- Lua provided by RyzenAPI
-- Game: Jelly

-- MAIN APPLICATION
addappid(1705500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705501, 1, "12cac7c882254f7db1ae6c43da62d10c434b9b83fcb5ba99205a3993623ef384")

