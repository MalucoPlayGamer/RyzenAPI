-- Lua provided by RyzenAPI
-- Game: Rasvyat Nuclear Power Station

-- MAIN APPLICATION
addappid(2873620)
-- Game: addappid(2873620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873621, 1, "bd6a67cab6df920ae8bf671f2a42a4b527619d514428072241ec8a94006418c0")
