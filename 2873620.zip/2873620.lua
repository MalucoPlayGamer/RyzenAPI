-- Lua provided by RyzenAPI
-- Game: Rasvyat Nuclear Power Station

-- MAIN APPLICATION
addappid(2873620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2873621, 1, "bd6a67cab6df920ae8bf671f2a42a4b527619d514428072241ec8a94006418c0")

