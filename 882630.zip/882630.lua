-- Lua provided by RyzenAPI
-- Game: addappid(882630)

-- MAIN APPLICATION
addappid(882630)

-- MAIN APP DEPOTS / PACKAGES
addappid(882631, 1, "d52cd28441dd72e487811558892424c6d10994c40a8e93c1a6cfef862c8339de")
