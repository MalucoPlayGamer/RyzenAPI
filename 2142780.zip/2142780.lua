-- Lua provided by RyzenAPI
-- Game: Game: Hentai Heaven's Slutty Salvation

-- MAIN APPLICATION
addappid(2142780)
-- Game: addappid(2142780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142781, 1, "ce8132eec6f6e1aa712edef45044830dd9148ccab25fbde4a362858ef4aaa155")
