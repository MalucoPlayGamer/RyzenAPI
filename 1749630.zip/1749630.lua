-- Lua provided by RyzenAPI
-- Game: Chill Corner

-- MAIN APPLICATION
addappid(1749630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749631, 1, "dd6da482a1932494817d0bf65e831bdd2b7cbab81e84373a4e424f26fa754803")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1780790)
addappid(1780800)
addappid(1780810)
addappid(1780820)
addappid(1871960)
addappid(2092460)
addappid(2092461)
addappid(3142340)
