-- Lua provided by RyzenAPI
-- Game: 1749630

-- MAIN APPLICATION
addappid(1749630)
-- Game: addappid(1749630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749631, 1, "dd6da482a1932494817d0bf65e831bdd2b7cbab81e84373a4e424f26fa754803")
