-- Lua provided by RyzenAPI
-- Game: Zombies Ate My Femboy

-- MAIN APPLICATION
addappid(3365000)
-- Game: addappid(3365000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365001, 1, "9fee11fef8d1c6d5c01d23d6854a9a17fa980d02b8b236f10e1c1e66757120f2")
