-- Lua provided by RyzenAPI
-- Game: Game: Rooftops & Alleys: The Parkour Game

-- MAIN APPLICATION
addappid(2703850)
-- Game: addappid(2703850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703851, 1, "e64721646710451cc632805df1472e27540a29c83d26bb7a225f91eb38d8e828")
