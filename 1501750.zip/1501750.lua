-- Lua provided by RyzenAPI
-- Game: Lords of the Fallen

-- MAIN APPLICATION
addappid(1501750)
addappid(2370550)
addappid(2387870)
addappid(2387880)
addappid(2387890)
addappid(2387920)
addappid(3563510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1501751, 1, "c86a5d17ac060ed8c27bc9840a5eb75890d5d8cf1908993635a947d13a30076b")
addappid(2387921, 0, "e69a9bfb62c1ca78c5fbb00518ff2251ada2f55dadfdbe8d842ee5174c83c3ac")

