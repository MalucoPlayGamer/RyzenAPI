-- Lua provided by RyzenAPI 
-- Game: Lords of the Fallen
addappid(1501750)
addappid(1501751, 1, "c86a5d17ac060ed8c27bc9840a5eb75890d5d8cf1908993635a947d13a30076b")
addappid(2370550)
addappid(2387870)
addappid(2387880)
addappid(2387890)
addappid(2387920)
addappid(2387921, 0, "e69a9bfb62c1ca78c5fbb00518ff2251ada2f55dadfdbe8d842ee5174c83c3ac")
addappid(3563510)
