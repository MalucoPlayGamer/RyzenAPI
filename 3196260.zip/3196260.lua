-- Lua provided by RyzenAPI
-- Game: Whispers Of The Shadow Demo

-- MAIN APPLICATION
addappid(3196260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3196261, 1, "7840eef847e119f0f3e298c72f1474ca6ce26b245d88d57bf37b3f1fd790d2c1")

