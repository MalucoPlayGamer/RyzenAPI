-- Lua provided by SkyAPI 
-- Game: RKGK / Rakugaki
addappid(2146570)
addappid(2146571, 1, "e62975d4582cffe6bd1d5d1c82ae7701f627dead1ff1c5a874a0367a76524ce9")
