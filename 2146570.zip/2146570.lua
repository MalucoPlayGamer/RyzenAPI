-- Lua provided by RyzenAPI
-- Game: Game: RKGK / Rakugaki

-- MAIN APPLICATION
addappid(2146570)
-- Game: addappid(2146570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146571, 1, "e62975d4582cffe6bd1d5d1c82ae7701f627dead1ff1c5a874a0367a76524ce9")
