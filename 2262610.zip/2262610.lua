-- Lua provided by RyzenAPI
-- Game: Game: Endless Monday: Dreams and Deadlines

-- MAIN APPLICATION
addappid(2262610)
-- Game: addappid(2262610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262611, 1, "6dcaffbc78aa5951f599de7972be0348674e2da77ea436e94ba4ca74d492f363")
