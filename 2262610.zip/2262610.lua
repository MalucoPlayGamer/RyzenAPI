-- Lua provided by SkyAPI 
-- Game: Endless Monday: Dreams and Deadlines
addappid(2262610)
addappid(2262611, 1, "6dcaffbc78aa5951f599de7972be0348674e2da77ea436e94ba4ca74d492f363")
