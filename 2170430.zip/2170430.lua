-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2170430)
-- Game: addappid(2170430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2170430,0,"e587cce17a5a7772c8befc21f75fb0fc00005d0ef09f5ac45eae946e0b11519b")
