-- Lua provided by RyzenAPI
-- Game: 1125250

-- MAIN APPLICATION
addappid(1125250)
-- Game: addappid(1125250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1125251, 1, "64c1c547c5a190594b1c8c75e26576a54c928c9b1adce3cc85ce304923aacd26")
