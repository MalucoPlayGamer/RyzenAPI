-- Lua provided by RyzenAPI
-- Game: Game: Escape Gaia

-- MAIN APPLICATION
addappid(3103970)
-- Game: addappid(3103970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103971, 1, "8304648da42e828d06b628c3ee68317171ccfc7861641d085caa9b5e838234b2")
