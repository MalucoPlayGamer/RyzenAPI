-- Lua provided by RyzenAPI
-- Game: 1432220

-- MAIN APPLICATION
addappid(1432220)
-- Game: addappid(1432220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432221, 1, "26105b5cdc9e384f4f0c749bfecc391c06faa33485fde95f1b8072eacf2c4111")
