-- Lua provided by RyzenAPI
-- Game: Danse Macabre: Crimson Cabaret Collector's Edition

-- MAIN APPLICATION
addappid(647930)

-- MAIN APP DEPOTS / PACKAGES
addappid(647931,0,"c4815bbfb6d6a11bd78a3bbc7caf6651b1ff4d43f312947e00769af6d6d3948b")

