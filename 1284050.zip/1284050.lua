-- Lua provided by RyzenAPI
-- Game: Dissection

-- MAIN APPLICATION
addappid(1284050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284051, 1, "2b781961685c7198ec10f478d6bf658327944feb703dfe9f089828bef018ae3a")

