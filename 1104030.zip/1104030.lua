-- Lua provided by RyzenAPI
-- Game: addappid(1104030)

-- MAIN APPLICATION
addappid(1104030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104033,0,"ada091432bb5705bb745220fccd90c6e6567ec1c4b935ca271380855bbfde8bc")
