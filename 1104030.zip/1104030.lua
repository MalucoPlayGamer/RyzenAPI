-- Lua provided by RyzenAPI
-- Game: Vermin Hunter

-- MAIN APPLICATION
addappid(1104030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104033,0,"ada091432bb5705bb745220fccd90c6e6567ec1c4b935ca271380855bbfde8bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
