-- Lua provided by RyzenAPI
-- Game: setManifestid(1104033,"3806533261208576009")

-- MAIN APPLICATION
addappid(1104030)
-- Game: addappid(1104030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104033,0,"ada091432bb5705bb745220fccd90c6e6567ec1c4b935ca271380855bbfde8bc")
