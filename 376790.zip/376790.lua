-- Lua provided by RyzenAPI
-- Game: addappid(376790)

-- MAIN APPLICATION
addappid(376790)

-- MAIN APP DEPOTS / PACKAGES
addappid(376791, 1, "87d5260470abae5dfffaa1b3f8aaf06a44965161dba92194e122eb184a3eb8b4")
