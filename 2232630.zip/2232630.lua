-- Lua provided by RyzenAPI
-- Game: addappid(2232630)

-- MAIN APPLICATION
addappid(2232630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232631, 1, "d7d3f79be165f7ea2d1e949895acfda78b5b5755c8b872b441d6deb660957e27")
