-- Lua provided by RyzenAPI
-- Game: Touhou Crisis

-- MAIN APPLICATION
addappid(1989990)
addappid(1990000)
-- Game: addappid(1989990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989991, 1, "35aff7b2ae48c066890b368f48d50aa8ed2ff530d248d8dc50dc6af733f9c216")
addappid(1989992, 1, "80106ecb07055b8fbf2ceafb7123b091d1e61488a6ec562a616e646615e50077")
addappid(1989993, 1, "1b27018a7247dc080030cf23128f95076cd3b44f7b647f2f133c36df2b8253ea")
addappid(1989994, 1, "f7f8000f8a9c5aafd969f903b84d1e2c6f81b781a8f48bdec062e163e2519f0a")
