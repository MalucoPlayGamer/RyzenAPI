-- Lua provided by RyzenAPI
-- Game: Galactic Battles

-- MAIN APPLICATION
addappid(776190)
-- Game: addappid(776190)

-- MAIN APP DEPOTS / PACKAGES
addappid(776191, 1, "5b79fd0dc509bccb9eab3c70364f82e330efa41ceb56c0db5ed9a15880f9843c")
