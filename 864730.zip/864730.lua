-- Lua provided by RyzenAPI
-- Game: Game: AppID 864730

-- MAIN APPLICATION
addappid(864730)
-- Game: addappid(864730)

-- MAIN APP DEPOTS / PACKAGES
addappid(864731, 1, "65e50d8aef7ac222b7fea9097634fcfeda4021c2787a18e60f2e9b0ae97fba17")
