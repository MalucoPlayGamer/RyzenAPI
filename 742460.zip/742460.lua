-- Lua provided by RyzenAPI
-- Game: Marble Skies

-- MAIN APPLICATION
addappid(742460)

-- MAIN APP DEPOTS / PACKAGES
addappid(742461, 1, "f3efa2f856da9e27a45796e30b9147230bbb602cb53f3c54da7626b0087fa8db")

