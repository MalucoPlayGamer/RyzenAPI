-- Lua provided by RyzenAPI
-- Game: Marble Skies

-- MAIN APPLICATION
addappid(742460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(742461, 1, "f3efa2f856da9e27a45796e30b9147230bbb602cb53f3c54da7626b0087fa8db")

