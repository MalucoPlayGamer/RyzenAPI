-- Lua provided by RyzenAPI
-- Game: AppID 389740

-- MAIN APPLICATION
addappid(389740)
-- Game: addappid(389740)

-- MAIN APP DEPOTS / PACKAGES
addappid(389741, 1, "c0c87f585adbf0645d2acc730ac8f4471be24ac2a2dee41ca46d3b485129b362")
addappid(389742, 1, "50a3a51975f6abe369f18b80a3c5d47a68dabe5e2653cddc62f98730b5264366")
