-- Lua provided by RyzenAPI
-- Game: 2278010

-- MAIN APPLICATION
addappid(2278010)
-- Game: addappid(2278010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278012,0,"520bb3ff88c37c0ead866efe6c0312fbe5003a20b25ce3128673ca84124820a1")
