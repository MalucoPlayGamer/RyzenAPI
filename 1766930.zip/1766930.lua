-- Lua provided by RyzenAPI
-- Game: Siege Up! Demo

-- MAIN APPLICATION
addappid(1766930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766931, 1, "8e128344ee31e4a48f82356477233e8dc1677cbfd991b76411723d96a4e7f514")

