-- Lua provided by RyzenAPI
-- Game: Car Detailing Simulator VR

-- MAIN APPLICATION
addappid(2527890)
-- Game: addappid(2527890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527892,0,"6ebcfbae4b4697a0307f809a1f88cc2faac42a4ce75917d02057f0841a487f27")
