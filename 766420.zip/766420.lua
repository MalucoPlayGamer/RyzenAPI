-- Lua provided by RyzenAPI
-- Game: Neckbeards: Silly Squadron

-- MAIN APPLICATION
addappid(766420)

-- MAIN APP DEPOTS / PACKAGES
addappid(766422,0,"0ee6466afbbaf9230f7f72009914c2a25ba8b3b9eec7e0bac167b283e775087d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
