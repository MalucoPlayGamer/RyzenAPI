-- Lua provided by RyzenAPI
-- Game: setManifestid(766422,"1587813417589952689")

-- MAIN APPLICATION
addappid(766420)
-- Game: addappid(766420)

-- MAIN APP DEPOTS / PACKAGES
addappid(766422,0,"0ee6466afbbaf9230f7f72009914c2a25ba8b3b9eec7e0bac167b283e775087d")
