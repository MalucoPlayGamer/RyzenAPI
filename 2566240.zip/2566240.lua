-- Lua provided by RyzenAPI
-- Game: addappid(2566240)

-- MAIN APPLICATION
addappid(2566240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2566241, 1, "319dc7703cf0bb63f406ba819f55ea14cea363847ad2d6854a64e69f32f85ea0")
