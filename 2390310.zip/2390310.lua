-- Lua provided by SkyAPI 
-- Game: Deadblast
addappid(2390310)
addappid(2390311, 1, "7c4b5662c177c18d7ffa1b214348562df91644b82d6490e1ecd409002478aa8c")
