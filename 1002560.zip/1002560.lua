-- Lua provided by RyzenAPI
-- Game: Game: Tiny Snow

-- MAIN APPLICATION
addappid(1002560)
-- Game: addappid(1002560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002561, 1, "9bf2045fbe88243a5cd5523b108ae14ad30d2f08a3a52e75592c0a06ed2e2ac8")
addappid(1008300, 0, "628a51b9b7d514427f622a7ca9ef881fedc997f68a3b45a12f0cf3e3453ea0d8")
