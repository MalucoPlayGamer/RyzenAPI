-- Lua provided by RyzenAPI
-- Game: Soulmask

-- MAIN APPLICATION
addappid(2646460)
addappid(3336600)
addappid(3731990)
addappid(3966020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646460,0,"b23ed007512964e7e8555f41e6bb10b5e69ea21eb12bbb01e396db6520b78d59")
addappid(2646461,0,"b888b7fdf975bfc80d87df6beb2c5d56ada854d2adb6537fce281905a5d74d2a")

