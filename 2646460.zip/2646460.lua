-- Lua provided by RyzenAPI
-- Game: Soulmask

-- MAIN APPLICATION
addappid(2646460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646461, 1, "b888b7fdf975bfc80d87df6beb2c5d56ada854d2adb6537fce281905a5d74d2a")

