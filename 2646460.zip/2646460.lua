-- Lua provided by RyzenAPI
-- Game: Soulmask

-- MAIN APPLICATION
addappid(2646460)
addappid(3336600)
addappid(3731990)
addappid(3966020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646460,0,"b23ed007512964e7e8555f41e6bb10b5e69ea21eb12bbb01e396db6520b78d59")
addappid(2646461,0,"b888b7fdf975bfc80d87df6beb2c5d56ada854d2adb6537fce281905a5d74d2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
