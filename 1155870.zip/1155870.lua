-- Lua provided by RyzenAPI
-- Game: WW2: Bunker Simulator

-- MAIN APPLICATION
addappid(1155870)
addappid(1155873)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155872,0,"564e39b8ef54ff1d504234b7bd5c165b38ef99f2ea551887e460577da520a50b")
addappid(2350300,0,"e91f6c561a4507052aa8c623b0ba312639bbf60eef5469b4478505943c177219")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2928470)
