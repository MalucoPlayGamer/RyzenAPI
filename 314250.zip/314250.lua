-- Lua provided by RyzenAPI
-- Game: addappid(314250)

-- MAIN APPLICATION
addappid(314250)

-- MAIN APP DEPOTS / PACKAGES
addappid(314251, 1, "a5062c25459f2017496f1a0c8f42b8de10e11658f9707b22c19abf333bd113ec")
