-- Lua provided by RyzenAPI
-- Game: 1852090

-- MAIN APPLICATION
addappid(1852090)
addappid(1852094)
addappid(1852095)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852096,0,"b66e729494f1cb3ac1560dcf4812a937f5449a0dd343af1fcd216c1bc335235b")
