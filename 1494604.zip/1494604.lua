-- Lua provided by RyzenAPI
-- Game: addappid(1494604)

-- MAIN APPLICATION
addappid(1494604)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494604,0,"91bbf6d70cb51dab6ef0990197ab89c62fc122587cc070f294ea192b12c28b45")
