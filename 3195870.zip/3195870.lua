-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3195870)
-- Game: addappid(3195870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195870,0,"580b026b6e6c81d7b70002edbc9a56fd33aca3aa94a5508d7552c9f3739e2822")
