-- Lua provided by RyzenAPI
-- Game: Game: Mega Man Legacy Collection

-- MAIN APPLICATION
addappid(363440)
-- Game: addappid(363440)

-- MAIN APP DEPOTS / PACKAGES
addappid(363441, 1, "1674f0c6f57185bb129f249a00553268a4f726c6908bc4ef60598f5abbc72e95")
