-- Lua provided by RyzenAPI
-- Game: The Square Key

-- MAIN APPLICATION
addappid(1381880)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1381881, 1, "f1c9235eef2c279e717b263b350661dbc1766221fed985fa27248b7dc2e91b55")

