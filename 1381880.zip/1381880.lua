-- Lua provided by RyzenAPI
-- Game: 1381880

-- MAIN APPLICATION
addappid(1381880)
-- Game: addappid(1381880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381881, 1, "f1c9235eef2c279e717b263b350661dbc1766221fed985fa27248b7dc2e91b55")
