-- Lua provided by SkyAPI 
-- Game: The Square Key
addappid(1381880)
addappid(1381881, 1, "f1c9235eef2c279e717b263b350661dbc1766221fed985fa27248b7dc2e91b55")
