-- Lua provided by RyzenAPI
-- Game: RoBoRumble

-- MAIN APPLICATION
addappid(420970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(420971, 1, "f3a9052091c9135c4038bafea84e37d6dbe19b9006d41a567accdcad96040bfa")
addappid(420972, 1, "ab11b6171c1f24296a61531e01819df0c0b1cc5ee3f60a7d90175c4f4397ac13")
addappid(420973, 1, "4dc6f5fa72e3acf0c5a6f65f3b494dad91792c5811c2d9e03dfe27a910a21003")
addappid(420974, 1, "d737139607a6ced499407a316f997f7a3c996d60926f8b7c13a3e0ba5b96076c")
addappid(420975, 1, "aa916c3190059b8ab92a1b77aaa961b950f28381fa8cc8c226dc34fcfaef7c50")

