-- Lua provided by RyzenAPI
-- Game: Game: Ellie's Travel Diary

-- MAIN APPLICATION
addappid(1450020)
-- Game: addappid(1450020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450021, 1, "973880f96ea74396a468ba2266e12eb543862a13261cbffbd1c56cedd87240b6")
