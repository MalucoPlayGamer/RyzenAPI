-- Lua provided by RyzenAPI
-- Game: Kingdoms Reborn

-- MAIN APPLICATION
addappid(1307890)
-- Game: addappid(1307890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307891, 1, "5fa0d724887dfa7ab13fbb10fc175fc32ffc82ba2ed329bace21eaa627b18343")
