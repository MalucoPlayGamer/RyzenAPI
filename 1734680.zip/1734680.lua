-- Lua provided by RyzenAPI
-- Game: INCISION

-- MAIN APPLICATION
addappid(1734680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734681, 1, "c3acfe71f8b50f48def20ca9a792ed95da18b22dc3646150964e4c26fba47fc5")
