-- Lua provided by RyzenAPI
-- Game: AppID 739190

-- MAIN APPLICATION
addappid(739190)
addappid(866120)

-- MAIN APP DEPOTS / PACKAGES
addappid(739191, 1, "aa5fbd9dea484a69db44cd81767abe8a5dd00028fb39cdc313472086cdf5c3c5")

