-- Lua provided by RyzenAPI
-- Game: 3171590

-- MAIN APPLICATION
addappid(3171590)
-- Game: addappid(3171590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3171591, 1, "a7e815d9579cf19975cd77f86842d0758e9a285785ff02c41433a6966a1adfab")
