-- Lua provided by RyzenAPI
-- Game: Up Hike

-- MAIN APPLICATION
addappid(2767280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2767281, 1, "bd1ef5df58f398866e5a755fed0bc333344048e4a0abfa250331ff837d2d305d")

