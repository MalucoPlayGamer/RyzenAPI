-- Lua provided by RyzenAPI
-- Game: Up Hike

-- MAIN APPLICATION
addappid(2767280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2767281, 1, "bd1ef5df58f398866e5a755fed0bc333344048e4a0abfa250331ff837d2d305d")
