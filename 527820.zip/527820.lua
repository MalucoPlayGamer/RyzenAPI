-- Lua provided by RyzenAPI
-- Game: addappid(527820)

-- MAIN APPLICATION
addappid(527820)

-- MAIN APP DEPOTS / PACKAGES
addappid(527821, 1, "cc71398a7af5570b4fd87ff575edcf87c0981b43fd33c5e36c4a47efb96587f0")
