-- Lua provided by RyzenAPI
-- Game: Witches Vs. Demon's

-- MAIN APPLICATION
addappid(1754170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754172,0,"33303406f0ed6c141c4ea4aa5dd3bad277c9b8ed5a21766a88b71e8edd6e0202")

