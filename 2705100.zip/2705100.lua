-- Lua provided by RyzenAPI
-- Game: breakfive

-- MAIN APPLICATION
addappid(2705100)
-- Game: addappid(2705100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2705101, 1, "d3f2f938fa88da95c622d210368233c5c4925f081672fde96e5ba4dc0f6986be")
