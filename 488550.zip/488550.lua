-- Lua provided by RyzenAPI
-- Game: AppID 488550

-- MAIN APPLICATION
addappid(488550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(488551, 1, "595676162a9cc2c725f2fb1e5bd600057e0d15ae731737feefa6b89629180953")
addappid(488552, 1, "ffa0b8c0bdb0bdcf77aeae8ed146c96b804421f68ae2820e274fd96e231f21ac")

