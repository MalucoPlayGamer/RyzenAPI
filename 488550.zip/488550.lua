-- Lua provided by RyzenAPI
-- Game: AppID 488550

-- MAIN APPLICATION
addappid(488550)
-- Game: addappid(488550)

-- MAIN APP DEPOTS / PACKAGES
addappid(488551, 1, "595676162a9cc2c725f2fb1e5bd600057e0d15ae731737feefa6b89629180953")
addappid(488552, 1, "ffa0b8c0bdb0bdcf77aeae8ed146c96b804421f68ae2820e274fd96e231f21ac")
