-- Lua provided by RyzenAPI
-- Game: Grimhook

-- MAIN APPLICATION
addappid(2667430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2667431, 1, "5ee472bfd11ead7ded06543e15b3d4f9393322bf0e3f3038ef78f26977752cb6")

