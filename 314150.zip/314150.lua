-- Lua provided by RyzenAPI
-- Game: Double Dragon Trilogy

-- MAIN APPLICATION
addappid(314150)

-- MAIN APP DEPOTS / PACKAGES
addappid(314151, 1, "01c8ad14db6e536061047eaf3d17cb5750118f2260d340b82f80cb7867a3dbf3")

