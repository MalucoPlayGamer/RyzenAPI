-- Lua provided by RyzenAPI
-- Game: SUPER DRINK BROS.

-- MAIN APPLICATION
addappid(1460750)
addappid(1505950)
addappid(1516930)
addappid(1524870)
addappid(2325910)
addappid(2325911)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1460751, 1, "07c03435a7b27d01de59ee3926060079d878a9cb501a6e9e239d5a431702327f")

