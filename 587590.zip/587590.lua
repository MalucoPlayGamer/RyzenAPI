-- Lua provided by RyzenAPI
-- Game: Unexpected Day

-- MAIN APPLICATION
addappid(587590)

-- MAIN APP DEPOTS / PACKAGES
addappid(587591, 1, "10107281de188477a108be7cf47c85c81a20640d739fa901a88189b8f8f0c0e0")

