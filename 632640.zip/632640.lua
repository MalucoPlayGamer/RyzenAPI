-- Lua provided by RyzenAPI
-- Game: 632640

-- MAIN APPLICATION
addappid(632640)
-- Game: addappid(632640)

-- MAIN APP DEPOTS / PACKAGES
addappid(632641, 1, "6cbe9486605ef3f4e0de34c70b2cbeec3b762fb3471e87b36776be14be89551f")
