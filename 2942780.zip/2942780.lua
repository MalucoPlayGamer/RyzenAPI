-- Lua provided by RyzenAPI
-- Game: AppID 2942780

-- MAIN APPLICATION
addappid(2942780)
-- Game: addappid(2942780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942781, 1, "8eada1f38a3edbb5d62411d8a653197ea407c92af9751308837b44e6d0e327f5")
