-- Lua provided by RyzenAPI
-- Game: Bloobs Adventure Idle

-- MAIN APPLICATION
addappid(2942780)
addappid(3263170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942781, 1, "8eada1f38a3edbb5d62411d8a653197ea407c92af9751308837b44e6d0e327f5")
