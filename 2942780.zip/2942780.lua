-- Lua provided by SkyAPI 
-- Game: AppID 2942780
addappid(2942780)
addappid(2942781, 1, "8eada1f38a3edbb5d62411d8a653197ea407c92af9751308837b44e6d0e327f5")
