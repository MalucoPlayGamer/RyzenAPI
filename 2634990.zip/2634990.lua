-- Lua provided by RyzenAPI
-- Game: Legeclo: Legend Clover

-- MAIN APPLICATION
addappid(2634990)
-- Game: addappid(2634990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2634992,0,"da7821123d503b161244c589672c796f80b9ceb0f7bad828d55f9ad343441645")
addappid(2634993,0,"5bdd39edb1e09e3790b3556c235edacd0c7e4e0d3729f624ef3f918ac348d5c3")
