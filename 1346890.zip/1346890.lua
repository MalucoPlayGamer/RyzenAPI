-- Lua provided by RyzenAPI
-- Game: Game: Motoride Rollercoaster VR

-- MAIN APPLICATION
addappid(1346890)
-- Game: addappid(1346890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346891, 1, "b00e9e108a412ffdf1a179028ea900396a04cece8cb41bafc85a527e40dd62b3")
