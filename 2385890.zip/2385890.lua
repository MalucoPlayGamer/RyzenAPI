-- Lua provided by RyzenAPI
-- Game: RoboDunk Prologue

-- MAIN APPLICATION
addappid(2385890)
-- Game: addappid(2385890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2385891, 1, "f924f51c2638af2a60b1f5e8dd7c111c32dcda997618ce1b36b3abdf02be5615")
