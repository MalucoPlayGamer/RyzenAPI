-- Lua provided by RyzenAPI
-- Game: Adult Puzzles - CamGirls

-- MAIN APPLICATION
addappid(1780780)
-- Game: addappid(1780780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780781, 1, "ac61caefbbde3bc3076d21cdf94a488550f15e1f31e0a3ea3971e54000486298")
addappid(1786020, 0, "9a78de9948024a947234286afc97725010a9026457b4d1102c1fad8a18400393")
