-- Lua provided by RyzenAPI
-- Game: AppID 1117050

-- MAIN APPLICATION
addappid(1117050)
-- Game: addappid(1117050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117051, 1, "827f552dd0bccbd36fc2c1df7054e1172d0b5015f20b966092dcf3b86df84f7b")
