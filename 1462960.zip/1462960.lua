-- Lua provided by RyzenAPI
-- Game: 1462960

-- MAIN APPLICATION
addappid(1462960)
-- Game: addappid(1462960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462961, 1, "d99444ac5dcfb99f7f2957d6c76084cfb6a19ed6d1d7d43b238662824b1f5cd8")
