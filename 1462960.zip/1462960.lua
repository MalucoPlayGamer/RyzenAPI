-- Lua provided by RyzenAPI
-- Game: Evade Zero

-- MAIN APPLICATION
addappid(1462960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1462961, 1, "d99444ac5dcfb99f7f2957d6c76084cfb6a19ed6d1d7d43b238662824b1f5cd8")

