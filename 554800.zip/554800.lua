-- Lua provided by RyzenAPI
-- Game: Masky

-- MAIN APPLICATION
addappid(554800)

-- MAIN APP DEPOTS / PACKAGES
addappid(554801, 1, "7096d47e2fe6e86ec98a215deb7a4cffd2fb98f440aabd6626ae31617eeed6fa")

