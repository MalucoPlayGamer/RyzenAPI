-- Lua provided by RyzenAPI
-- Game: 405950

-- MAIN APPLICATION
addappid(405950)
-- Game: addappid(405950)

-- MAIN APP DEPOTS / PACKAGES
addappid(405951, 1, "2b1876bf89b9938ac20dfb79a43ee9f2e7f9d5fe326694ce3cf5083a365329a1")
