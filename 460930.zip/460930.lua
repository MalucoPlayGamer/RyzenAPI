-- Lua provided by RyzenAPI
-- Game: Tom Clancy's Ghost Recon® Wildlands

-- MAIN APPLICATION
addappid(573830) -- Tom Clancys Ghost Recon Wildlands - Season Pass
addappid(573831)
addappid(573832)
addappid(594560) -- Tom Clancys Ghost Recon Wildlands - WW Uplay Activation
addappid(594561) -- Tom Clancys Ghost Recon Wildlands - RUCN Uplay Activation
addappid(601290) -- Tom Clancys Ghost Recon Wildlands - WW Pre-order Standard Uplay Activation
addappid(601291) -- Tom Clancys Ghost Recon Wildlands - RUCN Pre-order Standard Uplay Activation
addappid(601292) -- Tom Clancys Ghost Recon Wildlands - ASIA Pre-order Standard Uplay Activation
addappid(601293) -- Tom Clancys Ghost Recon Wildlands - WW Pre-order Deluxe Uplay Activation
addappid(601294) -- Tom Clancys Ghost Recon Wildlands - RUCN Pre-order Deluxe Uplay Activation
addappid(601295) -- Tom Clancys Ghost Recon Wildlands - ASIA Pre-order Deluxe Uplay Activation
addappid(601296) -- Tom Clancys Ghost Recon Wildlands - WW Pre-order Gold Uplay Activation
addappid(601297) -- Tom Clancys Ghost Recon Wildlands - RUCN Pre-order Gold Uplay Activation
addappid(601298) -- Tom Clancys Ghost Recon Wildlands - ASIA Pre-order Gold Uplay Activation
addappid(601300) -- Tom Clancys Ghost Recon Wildlands - WW Deluxe Uplay Activation
addappid(601301) -- Tom Clancys Ghost Recon Wildlands - RUCN Deluxe Uplay Activation
addappid(601302) -- Tom Clancys Ghost Recon Wildlands - WW Gold Uplay Activation
addappid(601303) -- Tom Clancys Ghost Recon Wildlands - RUCN Gold Uplay Activation
addappid(601310) -- Tom Clancys Ghost Recon Wildlands - Season Pass Uplay Activation
addappid(623780) -- Tom Clancys Ghost Recon Wildlands - Narco Road Uplay Activation
addappid(623781) -- Tom Clancys Ghost Recon Wildlands - Fallen Ghosts Uplay Activation
addappid(729730) -- Tom Clancys Ghost Recon Wildlands Free Weekend Ownership
addappid(733960) -- Tom Clancys Ghost Recon Wildlands Free Weekend Ownership RUCN
addappid(733970) -- Tom Clancys Ghost Recon Wildlands Full Game Ownership
addappid(750230) -- Tom Clancys Ghost Recon Wildlands - Ghost War Pass
addappid(751960) -- Tom Clancys Ghost Recon Wildlands - Ghost War Pass Uplay Activation
addappid(832700) -- Tom Clancys Ghost Recon Wildlands - Y2
addappid(832701) -- Tom Clancys Ghost Recon Wildlands - Y2 Uplay Activation
addappid(931190) -- Tom Clancys Ghost Recon Wildlands - WW Gold Year 2 Uplay Activation
addappid(931191) -- Tom Clancys Ghost Recon Wildlands - RUCN Gold Year 2 Uplay Activation
addappid(931192) -- Tom Clancys Ghost Recon Wildlands - WW Ultimate Year 2 Uplay Activation
addappid(931193) -- Tom Clancys Ghost Recon Wildlands - RUCN Ultimate Year 2 Uplay Activation
addappid(4784340) -- Tom Clancys Ghost Recon Wildlands - Definitive Edition Ubisoft Activation -WW
addappid(4784350) -- Tom Clancys Ghost Recon Wildlands - Definitive Edition Ubisoft Activation - RUCN
addappid(4784380) -- Tom Clancys Ghost Recon Wildlands Cold Eye Pack
addappid(4784390) -- Tom Clancys Ghost Recon Wildlands Cold Eye Pack Ubisoft Activation
addappid(4784400) -- Tom Clancys Ghost Recon Wildlands Nightfall Protocol Pack
addappid(4784410) -- Tom Clancys Ghost Recon Wildlands Nightfall Protocol Pack Ubisoft Activation
addappid(4784420) -- Tom Clancys Ghost Recon Wildlands - Predator Premium Pack
addappid(4784430) -- Tom Clancys Ghost Recon Wildlands - Predator Premium Pack Ubisoft Activation
addappid(4784440) -- Tom Clancys Ghost Recon Wildlands Definitive Edition Upgrade
addappid(4784450) -- Tom Clancys Ghost Recon Wildlands Definitive Edition Upgrade Ubisoft Activation

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(460930, 1, "c25d8c77b47191a3d41e556d99fe3adae1457c74f6f6bed925f6e57f3541cfda") -- Tom Clancy's Ghost Recon® Wildlands
addappid(460932, 1, "bde2110e49d13530ba0d862bf38a2f1da77ebca381bb46123dd94992b4566bbf") -- Retail Core
addappid(460933, 1, "90d2ad5b74312c5928a1ac0dcf3b30f071f44dc683c546aeb1ec515464aa442b") -- Depot 460933
addappid(460934, 1, "13ce87f397410fb2e07a8eec31bcd08d89ab99d3f69dc55bf992f2438fc85012") -- Maps - Common
addappid(460935, 1, "cb668cc06add491f81676b5b5e74ee1197422be29ce3613f2c74ecd0d1c699b8") -- Maps - WorldMap
addappid(460936, 1, "b544bb4108b7ae8c010295e4fac8a1479bb9e89da5df5af021d42b9c8a9b1d1d") -- Maps - Others
addappid(460937, 1, "d36441c770d9d5c8cf8d772e3b81ef84556fda68e52af96a9b0c5b16b1d04aa0") -- Video
addappid(460938, 1, "27d9c76eade84acdd844666a43364165287be4f612e8427e02c727d08bdb6576") -- Sound - Common
addappid(460939, 1, "5efd1f1fe70217560d4cff479ea20def14fec7279f1850a12435e7e5ec95e39f") -- Support
addappid(527050, 1, "f10cb78d153689ea0177527be3d7b93d805333df0d03eb32a724eda5fb62f7fb") -- Language - French
addappid(527051, 1, "7de4c108fe2624e7eb85d16984171d5646021b28efefdf0b48a9052fe5545d9b") -- Language - Italian
addappid(527052, 1, "0c465a66d1535d9a0ec9c0593150b6f097cf83cabee96700261ec0bc5d5a012e") -- Language - German
addappid(527053, 1, "1d5327ab8926812c42541b648727b19f5c5e4d6fe0b70edb05fed99d398e15fc") -- Language - Spanish
addappid(527054, 1, "4c99be4a2d810244c95983f997c9742ed450d274fc3d1753930af59f41c22b9f") -- Language - Brazilian
addappid(527055, 1, "e0e96bf59ed92e7db65e7c77059b9f141935835f52782d0351c27610a0a60f4d") -- Language - Russian
addappid(527056, 1, "6048699beac55e725b81369d008b8ab8252bc97c45e5eb0b608ef93c7d6f338d") -- Language - Japanese
addappid(527057, 1, "546beca62ef655656b5e3e7d7ef648cc78b3ece40c9b184ecd9802420b3e0acc") -- Language - Dutch
addappid(527058, 1, "7cc5e490129d7e39967b2f8968c2ec31525f6fb501401f6b16a4e1ae820c627f") -- Language - Polish
addappid(527059, 1, "bff5883e41209a1c1157f58739a8f4da75fec461f22b2a2151a60d575660ca57") -- Language - Czech
addappid(527060, 1, "e231cae9d9d2e2c8211dca82c0586807aaaa57939e81870e366dbf40c9c66f8b") -- Language - Korean
addappid(527061, 1, "532e7576df7da83b13254a9447e52174d79e2e93e3e32a67c9c77057ba4867ca") -- Language - Simplified Chinese
addappid(527062, 1, "c285d9099dea161bfabdea70627aa3d08883ef105bef6559a05c88c699f5fce1") -- Language - Traditional Chinese
addappid(527063, 1, "de7a5d543800eafbf2935b8ddddd530e74ded8abdcb238dcb4b876eb98ea6532") -- Language - English
addappid(527064, 1, "020c6de13a43f818050fdf62802aed3eafa69e14002e4128d4f4598784125700") -- Languge - Arabic
addappid(527065, 1, "4a4a61de29327f30e4246ffd40b77b6968e40965d4e2dd687b1942016b672276") -- Depot 527065
addappid(573831, 1, "b98f4b2691d92850b6dbd670b4259b24b37f748b2019344233308f1ac849ba0d") -- Tom Clancys Ghost Recon Wildlands - Narco Road - Tom Clancy's Ghost Recon Wildlands - Narco Road (573831) Depot
addappid(573832, 1, "8b0e38a0d31e60759feb1870c81f6a1e54b8373e109942f232ac04b886d6edd3") -- Tom Clancys Ghost Recon Wildlands - Fallen Ghosts - Tom Clancy's Ghost Recon Wildlands - Fallen Ghosts (573832) Depot
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
addtoken(573831, "2843020018421907384")
addtoken(623780, "6871850729114411039")
addtoken(623781, "16084786785819420607")
addtoken(733970, "13152026892702008725")
addtoken(751960, "15206237667257876809")
addtoken(832701, "981625427631188344")
addtoken(931190, "13750867402684765005")
addtoken(931192, "17287294552728189835")

