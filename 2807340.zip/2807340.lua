-- Lua provided by RyzenAPI
-- Game: Magic Runes

-- MAIN APPLICATION
addappid(2807340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807341, 1, "d961728a1eec27672ffd51078acae6c28a2e8bb289a130d8e9d9cdf1fbab5e09")

