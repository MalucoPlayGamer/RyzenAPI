-- Lua provided by RyzenAPI
-- Game: Disc Golf : Game On Demo

-- MAIN APPLICATION
addappid(2301350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2301351, 1, "884d01ebc2b6e71f55d426ff26295927a22ee325dee95c0ba943b290ccae49e5")
