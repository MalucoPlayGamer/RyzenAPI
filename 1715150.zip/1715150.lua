-- Lua provided by RyzenAPI
-- Game: Game: HUMANKIND™ - Music for the Ages, Vol. II

-- MAIN APPLICATION
addappid(1715150)
-- Game: addappid(1715150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715151, 1, "1ca0afe96809881d3701422e057171e687bbf6fa459247d78d90de8c64931c83")
addappid(1715152, 1, "88ceb451a2f3dd80ac4d2ec6dacc574655ec1e6d9a3b289f086dcd680f6945af")
