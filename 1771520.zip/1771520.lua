-- Lua provided by RyzenAPI
-- Game: Slap The Rocks

-- MAIN APPLICATION
addappid(1771520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771521, 1, "104afe79beba5285d45afde822a81063b5723f4738b72a1435bc237c4c4225bd")
