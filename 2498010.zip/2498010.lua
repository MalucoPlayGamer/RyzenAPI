-- Lua provided by RyzenAPI
-- Game: Doki Boki International Hentai Language School

-- MAIN APPLICATION
addappid(2498010)
addappid(2953080)
addappid(2953100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498012,0,"06008a7d8fd38b5e72653a22ce6b8b2024316bf846658511107f75060de5dfe8")
addappid(2498014,0,"4c6c0e722bb088f89ad9cf9b8b87fab1a4b9d9b8dab8fac224eb46020b8181d7")

