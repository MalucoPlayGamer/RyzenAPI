-- Lua provided by RyzenAPI
-- Game: addappid(2644600)

-- MAIN APPLICATION
addappid(2644600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644601, 1, "804cce602a4197271ab6e044569cec3a5edd07f340bcdbdd92cb251c4a30813a")
