-- Lua provided by RyzenAPI
-- Game: 1035270

-- MAIN APPLICATION
addappid(1035270)
-- Game: addappid(1035270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035271, 1, "e644df85bc9d92ea88f9e79dfee22d509cd8e0713e8982a99aaec838d6cc5395")
