-- Lua provided by SkyAPI 
-- Game: AppID 384200
addappid(384200)
addappid(384201, 1, "d0864c3a81d99d824448d48aca52d45d5eb670cf00dddfa692ce31fc4d1d4418")
addappid(384205, 1, "ecfd04a9cf2ae81200b81418425b67a68e90ec54e5f5ef7fb7b39f1890a82895")
