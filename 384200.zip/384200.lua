-- Lua provided by RyzenAPI
-- Game: Raging Justice

-- MAIN APPLICATION
addappid(384200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(384201, 1, "d0864c3a81d99d824448d48aca52d45d5eb670cf00dddfa692ce31fc4d1d4418")
addappid(384205, 1, "ecfd04a9cf2ae81200b81418425b67a68e90ec54e5f5ef7fb7b39f1890a82895")
