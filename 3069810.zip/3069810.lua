-- Lua provided by RyzenAPI
-- Game: Rocket Rats

-- MAIN APPLICATION
addappid(3069810)
-- Game: addappid(3069810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3069811, 1, "5d18432dd898d169016599b76cea321680cbafbbfcba19269e304b566ccdd754")
