-- Lua provided by RyzenAPI 
-- Game: The Long Journey Home
addappid(366910)
addappid(366911, 1, "d64440da30cab3924934badd4aafcfac3891f8bf095a20243e407dd166bf1cff")
addappid(366913, 1, "a5e75a233e15bb31ede49bfedb7c0e7a6501c3411e72b414740474a7b5e1b4e8")
addappid(648710, 0, "4b4b6bf42704d67b1412d6626819ef693feb2f1678f895d05a51b4b5f27656af")
