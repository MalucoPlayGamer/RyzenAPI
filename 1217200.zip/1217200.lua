-- Lua provided by RyzenAPI
-- Game: Game: AppID 1217200

-- MAIN APPLICATION
addappid(1217200)
-- Game: addappid(1217200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217201, 1, "13a3c05b62962dd1a601a4f53a29f27d38c00b8c4240d82a62d9909f3638f488")
