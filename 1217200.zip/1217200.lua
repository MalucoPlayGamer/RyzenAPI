-- Lua provided by RyzenAPI
-- Game: AppID 1217200

-- MAIN APPLICATION
addappid(1217200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217201, 1, "13a3c05b62962dd1a601a4f53a29f27d38c00b8c4240d82a62d9909f3638f488")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
