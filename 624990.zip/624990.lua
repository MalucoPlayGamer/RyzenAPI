-- Lua provided by RyzenAPI
-- Game: The Mimic

-- MAIN APPLICATION
addappid(624990)

-- MAIN APP DEPOTS / PACKAGES
addappid(624991, 1, "192e3af2f27d180b492484271b0e18d32513d9c31e74b5cbe044cf09149d3858")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
