-- Lua provided by RyzenAPI
-- Game: Game: The Mimic

-- MAIN APPLICATION
addappid(624990)
-- Game: addappid(624990)

-- MAIN APP DEPOTS / PACKAGES
addappid(624991, 1, "192e3af2f27d180b492484271b0e18d32513d9c31e74b5cbe044cf09149d3858")
