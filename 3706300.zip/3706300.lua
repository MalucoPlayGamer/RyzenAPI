-- Lua provided by RyzenAPI
-- Game: Veloria - Official Guidebook

-- MAIN APPLICATION
addappid(3706300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3706300,0,"29468cccc0b43d38152fd1f5838555f593c79bb1448009b8ce3e7109a86798f5")

