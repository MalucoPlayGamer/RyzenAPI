-- Lua provided by RyzenAPI
-- Game: Farming World

-- MAIN APPLICATION
addappid(277500)
addappid(317070)
addappid(317860)

-- MAIN APP DEPOTS / PACKAGES
addappid(277501, 1, "6292fbdef692528e7c9c1d8feb638c08f11fe6d7bd31863ef170dc5395eb1710")
addappid(277502, 1, "f48e253777d526a7f34b4d1d01b6086344ff53ccaad85d7d6e78f0387ecf430b")

