-- Lua provided by SkyAPI 
-- Game: Alvastia Chronicles
addappid(948660)
addappid(948661, 1, "2c2e946bc262eb02ffc71288dd179714d1df2268a4c63d7ab601a0952fe8e35e")
