-- Lua provided by RyzenAPI
-- Game: addappid(948660)

-- MAIN APPLICATION
addappid(948660)

-- MAIN APP DEPOTS / PACKAGES
addappid(948661, 1, "2c2e946bc262eb02ffc71288dd179714d1df2268a4c63d7ab601a0952fe8e35e")
