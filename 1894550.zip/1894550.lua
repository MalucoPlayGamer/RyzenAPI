-- Lua provided by RyzenAPI 
-- Game: Facility 386
addappid(1894550)
addappid(1894551, 1, "ac7627dd0a73bcd6822b6d67452c12a99c64b9684be9703e71cc14858c1d0347")
