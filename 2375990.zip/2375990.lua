-- Lua provided by RyzenAPI
-- Game: Coralina: a Memory Tale

-- MAIN APPLICATION
addappid(2375990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375991, 1, "72a65ab2d4d0ee0eda0ebb758307c8a520961f54fbda653bf3dbed36a1d89bbe")

