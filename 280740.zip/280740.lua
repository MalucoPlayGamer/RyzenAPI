-- Lua provided by RyzenAPI 
-- Game: Aperture Tag: The Paint Gun Testing Initiative
addappid(280740)
addappid(280741, 1, "35ee7e283200da3c20f00406efc63b079fd0a3ca3a192a20dc75de529412c940")
addappid(280742, 1, "10e743b57959375286f0e65c9a206fbe1f97e3e2582b9c4576bc2565628e12f9")
addappid(280743, 1, "be555c47e1c4bf78c38dc277eb05ced05f18d5cd14d5ff0270c20739ad59ae58")
addappid(280745, 1, "3d2ed44717e501343e15da0f71fbc1a08375914e549eabc9245f0896097fe8b6")
