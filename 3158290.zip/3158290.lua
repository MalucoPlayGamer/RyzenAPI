-- Lua provided by RyzenAPI
-- Game: addappid(3158290)

-- MAIN APPLICATION
addappid(3158290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3158293,0,"5a39bf4ae758ec0bdb64778aee59922f5997e4a596061a8702a5f34cff66be61")
addappid(3158294,0,"4f7f547cb5dac89620cd823fcf0a11cc8c1c0878564b491f8fab04bec4a38b9b")
