-- Lua provided by RyzenAPI
-- Game: Amazoom Blimp Jockey '69

-- MAIN APPLICATION
addappid(3226570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3226571, 1, "ce59ada415dfb5eee6189638de2fe0c1eba2a11ef9f14845d9281b1b86787c50")

