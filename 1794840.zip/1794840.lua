-- Lua provided by RyzenAPI
-- Game: Perceptio

-- MAIN APPLICATION
addappid(1794840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794841, 1, "816350e0df03b1c7cd3c262496c732d20fdb8999d14903654c592a4270e59f8e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
