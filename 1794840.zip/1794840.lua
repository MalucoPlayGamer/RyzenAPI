-- Lua provided by RyzenAPI
-- Game: Perceptio

-- MAIN APPLICATION
addappid(1794840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794841, 1, "816350e0df03b1c7cd3c262496c732d20fdb8999d14903654c592a4270e59f8e")

