-- Lua provided by RyzenAPI
-- Game: BookWorm Adventures Volume 2

-- MAIN APPLICATION
addappid(3630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3631, 1, "db116ede1051fb73250cd68cf89e1184fac4be67f7cfbe1fd486d8464119fcf0")

