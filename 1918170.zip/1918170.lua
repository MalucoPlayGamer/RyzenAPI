-- Lua provided by RyzenAPI
-- Game: Arclight of City

-- MAIN APPLICATION
addappid(1918170)
-- Game: addappid(1918170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918171, 1, "fe6cb9b808315c1e6e275e6f2d2fa2c5ab8f8ef03b9851ab96a8c1d8dbaf9b46")
