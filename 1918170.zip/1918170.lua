-- Lua provided by SkyAPI 
-- Game: Arclight of City
addappid(1918170)
addappid(1918171, 1, "fe6cb9b808315c1e6e275e6f2d2fa2c5ab8f8ef03b9851ab96a8c1d8dbaf9b46")
