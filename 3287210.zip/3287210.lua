-- Lua provided by RyzenAPI
-- Game: AppID 3287210

-- MAIN APPLICATION
addappid(3287210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3287211, 1, "2a4bec2942bd5650b2932c50fa09b51516a25b58a7568ee5dbad63e98d79fdb5")

