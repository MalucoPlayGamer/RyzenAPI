-- Lua provided by SkyAPI 
-- Game: AppID 3287210
addappid(3287210)
addappid(3287211, 1, "2a4bec2942bd5650b2932c50fa09b51516a25b58a7568ee5dbad63e98d79fdb5")
