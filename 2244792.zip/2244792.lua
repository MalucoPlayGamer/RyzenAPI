-- Lua provided by RyzenAPI
-- Game: addappid(2244792)

-- MAIN APPLICATION
addappid(2244792)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244792,0,"ebc565c2487acb719dbbab114ba77cfbee99e8719f5b2ee1af1b741f6c5e01c1")
