-- Lua provided by RyzenAPI
-- Game: Game: AppID 1120850

-- MAIN APPLICATION
addappid(1120850)
-- Game: addappid(1120850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120851, 1, "e3e362dce8c478e1ff0e09eadabf27793bf1536c8d886f2287e98ab56150dca2")
