-- Lua provided by RyzenAPI
-- Game: 1359970

-- MAIN APPLICATION
addappid(1359970)
-- Game: addappid(1359970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359971, 1, "bc2199ea22f53e8c5d72924b277f1f26c81ca1e0607b7eb5abb8434b8e62c133")
