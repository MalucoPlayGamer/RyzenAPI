-- Lua provided by RyzenAPI
-- Game: Game: AppID 2597170

-- MAIN APPLICATION
addappid(2597170)
-- Game: addappid(2597170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597171, 1, "b89310ff99df741c853d1f61ce673a439ca9ff2a4ac0e74a0614b8df583d8b98")
