-- Lua provided by SkyAPI 
-- Game: AppID 2597170
addappid(2597170)
addappid(2597171, 1, "b89310ff99df741c853d1f61ce673a439ca9ff2a4ac0e74a0614b8df583d8b98")
