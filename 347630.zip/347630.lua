-- Lua provided by SkyAPI 
-- Game: 16 Bit Arena
addappid(347630)
addappid(347631, 1, "bf76e9fa334a37d34ac2a971d193c7b93ca1923964eb5917eb8c3192b7f2b09f")
