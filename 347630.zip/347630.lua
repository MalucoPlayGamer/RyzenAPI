-- Lua provided by RyzenAPI
-- Game: 16 Bit Arena

-- MAIN APPLICATION
addappid(347630)

-- MAIN APP DEPOTS / PACKAGES
addappid(347631, 1, "bf76e9fa334a37d34ac2a971d193c7b93ca1923964eb5917eb8c3192b7f2b09f")
