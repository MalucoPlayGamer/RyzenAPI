-- Lua provided by RyzenAPI 
-- Game: Encoded War
addappid(2220070)
addappid(2220071, 1, "346841cf915d719d5fbf8c411810a7335d35e0023ed3c68f1495c1db5b98eee5")
