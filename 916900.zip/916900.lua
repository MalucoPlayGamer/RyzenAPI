-- Lua provided by RyzenAPI
-- Game: Paperbark

-- MAIN APPLICATION
addappid(916900)

-- MAIN APP DEPOTS / PACKAGES
addappid(916901, 1, "eb8a979e62666d8cbf99f0b3465f8b55c1f243a1e755db5780e749500f72acc0")
addappid(916902, 1, "c985ec3ac7d5b4b70335db02916d33827e5320ef0213fef56e2f4218bee9d1e1")

