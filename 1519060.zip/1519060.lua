-- Lua provided by RyzenAPI
-- Game: Game: SGS Taipings

-- MAIN APPLICATION
addappid(1519060)
-- Game: addappid(1519060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1519061, 1, "d71e484117b6089cb79db7134ecbb5deb824b0bd33082fce0dcce7702c1008d8")
addappid(1519063, 1, "2fc59e5930362585db817f15330767db015d18e0c9c601c8cb088055cd5b4844")
