-- Lua provided by RyzenAPI
-- Game: Game: AppID 616000

-- MAIN APPLICATION
addappid(616000)
-- Game: addappid(616000)

-- MAIN APP DEPOTS / PACKAGES
addappid(616001, 1, "95c8f6220e9e6f2ed4fc23987f20d09cb0ca4108c572ec8701be04cfa0ee8e87")
