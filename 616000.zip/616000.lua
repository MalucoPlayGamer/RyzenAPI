-- Lua provided by RyzenAPI
-- Game: AppID 616000

-- MAIN APPLICATION
addappid(616000)
addappid(632790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(616001, 1, "95c8f6220e9e6f2ed4fc23987f20d09cb0ca4108c572ec8701be04cfa0ee8e87")

