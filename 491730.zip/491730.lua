-- Lua provided by RyzenAPI
-- Game: Heavenly Battle

-- MAIN APPLICATION
addappid(491730)

-- MAIN APP DEPOTS / PACKAGES
addappid(491731, 1, "9fd2c9e37f451fea50e4785361ec7abff789d7afeb8c43333586ebed0e1cbbbf")

