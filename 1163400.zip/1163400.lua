-- Lua provided by RyzenAPI
-- Game: DFF NT: Gabranth Starter Pack

-- MAIN APPLICATION
addappid(1163400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163400,0,"d32f65cd7fba164030f93367ac175819b547a62a2a43e94321747bb1be6196c3")

