-- Lua provided by RyzenAPI
-- Game: Danse Macabre: Deadly Deception Collector's Edition

-- MAIN APPLICATION
addappid(796090)

-- MAIN APP DEPOTS / PACKAGES
addappid(796091,0,"cc913f194fcf14c9529f03401f0fdbeb51b10720b532c2450076801eb0e57178")

