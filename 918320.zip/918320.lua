-- Lua provided by RyzenAPI
-- Game: Swords with spice

-- MAIN APPLICATION
addappid(918320)

-- MAIN APP DEPOTS / PACKAGES
addappid(918321, 1, "37a5cc0e3c3a037d338853ea818d7d6214ed45b6f9cf359bcf764b60aea89dbd")

