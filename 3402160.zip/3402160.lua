-- Lua provided by RyzenAPI
-- Game: Prisoners of Ulag'Bol: A Dungeon Crawling Deckbuilder

-- MAIN APPLICATION
addappid(3402160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402161, 1, "deb4e761ddfd95d3865e7531295d64797a7c6a37f2ef65b29bf7831926eef158")
