-- Lua provided by RyzenAPI
-- Game: Prisoners of Ulag'Bol: A Dungeon Crawling Deckbuilder

-- MAIN APPLICATION
addappid(3402160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3402161, 1, "deb4e761ddfd95d3865e7531295d64797a7c6a37f2ef65b29bf7831926eef158")

