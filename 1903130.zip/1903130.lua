-- Lua provided by RyzenAPI 
-- Game: AppID 1903130
addappid(1903130)
addappid(1903131, 1, "d55918edcba3c6ef5ff852fea3c82117239f166e20d0948396b2635b8e0c6a23")
