-- Lua provided by RyzenAPI
-- Game: 1903130

-- MAIN APPLICATION
addappid(1903130)
-- Game: addappid(1903130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903131, 1, "d55918edcba3c6ef5ff852fea3c82117239f166e20d0948396b2635b8e0c6a23")
