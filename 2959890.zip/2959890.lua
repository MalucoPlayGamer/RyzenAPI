-- Lua provided by RyzenAPI
-- Game: Echoes of the Town

-- MAIN APPLICATION
addappid(2959890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2959891, 1, "02c3d66d4ed5f2a4dcb78744a81d87648fe74889bf4de5427ffda98eaf2bee4d")
