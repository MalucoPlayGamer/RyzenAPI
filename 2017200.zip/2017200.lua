-- Lua provided by RyzenAPI
-- Game: Leximan

-- MAIN APPLICATION
addappid(2017200)
-- Game: addappid(2017200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017201, 1, "f990371187259aad43bce7fa401af659cabdc52cfba3562cdc3d510f291ad358")
