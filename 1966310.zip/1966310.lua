-- Lua provided by RyzenAPI
-- Game: 1966310

-- MAIN APPLICATION
addappid(1966310)
-- Game: addappid(1966310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1966319,0,"7104035bfe25d0d670b6bd67aa561de854dbdca514ca32a06ab4f46ccea135ff")
