-- Lua provided by RyzenAPI
-- Game: AppID 3699550

-- MAIN APPLICATION
addappid(3699550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3699551, 1, "9c5c4477d10e9f257c9ef0e0c341ab0dd66d03d25b01abfe98f5cb9f4e30db50")

