-- Lua provided by RyzenAPI
-- Game: Game: AppID 1132860

-- MAIN APPLICATION
addappid(1132860)
-- Game: addappid(1132860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132861, 1, "1757e1be43f82c382cf825af7639372e229b7a0d3e8507cbd664271c0520e1f8")
