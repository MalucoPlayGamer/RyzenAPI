-- Lua provided by RyzenAPI
-- Game: Jera

-- MAIN APPLICATION
addappid(1132860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1132861, 1, "1757e1be43f82c382cf825af7639372e229b7a0d3e8507cbd664271c0520e1f8")

