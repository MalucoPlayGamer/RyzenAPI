-- Lua provided by SkyAPI 
-- Game: AppID 1132860
addappid(1132860)
addappid(1132861, 1, "1757e1be43f82c382cf825af7639372e229b7a0d3e8507cbd664271c0520e1f8")
