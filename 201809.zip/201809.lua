-- Lua provided by RyzenAPI
-- Game: Orcs Must Die! 2 - Soundtrack

-- MAIN APPLICATION
addappid(201809)
-- Game: addappid(201809)

-- MAIN APP DEPOTS / PACKAGES
addappid(201809,0,"a226e248d876fea32e72621706d4472ab627a573f2463e631f8a9f304e103f61")
