-- Lua provided by RyzenAPI
-- Game: FOUNDRY: Dedicated Server

-- MAIN APPLICATION
addappid(2915550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2915551, 1, "c351825f444ce7a649c47935036391c1f3420a12a422c54b5c55df9d86bb11da")

