-- Lua provided by RyzenAPI
-- Game: Desert of Vice

-- MAIN APPLICATION
addappid(796370)

-- MAIN APP DEPOTS / PACKAGES
addappid(796371, 1, "6ff0e35d2210b548673e3f50a7d35ff8c452dfb7fb5ea91aae07a87cb1d9c3ae")
