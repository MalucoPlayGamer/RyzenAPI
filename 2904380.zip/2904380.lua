-- Lua provided by RyzenAPI
-- Game: Game: AppID 2904380

-- MAIN APPLICATION
addappid(2904380)
-- Game: addappid(2904380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2904381, 1, "645cb9be3fe3ba76ab32bb09942d04456fb7cb8bbeb695e0fea636cd95b2b82c")
addappid(2904382, 1, "669fee97f9194bf1a51125315a67c20289ebc6c263e092682b2f7b8ea25d7fd6")
