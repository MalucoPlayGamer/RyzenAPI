-- Lua provided by SkyAPI 
-- Game: X-Angels Artbook
addappid(2985830)
addappid(2985831, 1, "fc7387b77145e8a13c606bb675a613e7c3ed952df5555dce21df47f88d4ac9d9")
