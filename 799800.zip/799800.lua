-- Lua provided by RyzenAPI
-- Game: Animals Memory: Cats

-- MAIN APPLICATION
addappid(799800)

-- MAIN APP DEPOTS / PACKAGES
addappid(799801,0,"89e9ac3e8a14382598cd703d7795b16d80708ccf35e928ea28b46d4452cbd2b5")

