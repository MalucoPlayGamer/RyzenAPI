-- Lua provided by RyzenAPI
-- Game: Epigraph

-- MAIN APPLICATION
addappid(2789770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2789771, 1, "331919b75499957be9df28b259fe8e4797510d5a9a55aa30d5e0175b9b2645ae")

