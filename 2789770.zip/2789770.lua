-- Lua provided by SkyAPI 
-- Game: Epigraph
addappid(2789770)
addappid(2789771, 1, "331919b75499957be9df28b259fe8e4797510d5a9a55aa30d5e0175b9b2645ae")
