-- Lua provided by RyzenAPI
-- Game: Wicked Paradise Demo

-- MAIN APPLICATION
addappid(1887110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887111, 1, "5d22ea4b6aa0f7312948594225d535c0e217f12d788f829213d643104b68b2e0")

