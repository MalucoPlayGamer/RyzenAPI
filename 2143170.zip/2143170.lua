-- Lua provided by RyzenAPI 
-- Game: Derp Souls
addappid(2143170)
addappid(2143171, 1, "83bef49dc23b3f75dffb96791f4680d59872d8c79bde12134348d7248aa06b2c")
