-- Lua provided by RyzenAPI
-- Game: Trivia Vault Basketball Trivia

-- MAIN APPLICATION
addappid(806610)
-- Game: addappid(806610)

-- MAIN APP DEPOTS / PACKAGES
addappid(806611, 1, "7440f3b79a36822f538aaaad9ab580692d0a994b9d8772484f2058d073bf577f")
