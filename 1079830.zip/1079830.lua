-- Lua provided by RyzenAPI
-- Game: addappid(1079830)

-- MAIN APPLICATION
addappid(1079830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079831, 1, "4dd8cbe4f3f9d8ea912c759d102d2377a8768139af9c5f319145020dc6f4aba1")
