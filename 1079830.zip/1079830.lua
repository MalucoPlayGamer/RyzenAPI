-- Lua provided by RyzenAPI 
-- Game: Cris Tales
addappid(1079830)
addappid(1079831, 1, "4dd8cbe4f3f9d8ea912c759d102d2377a8768139af9c5f319145020dc6f4aba1")
