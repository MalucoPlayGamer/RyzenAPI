-- Lua provided by RyzenAPI
-- Game: Drunken Dad Simulator

-- MAIN APPLICATION
addappid(1609090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1609091, 1, "b913128bf5eac725f96242f8c861ad0367a3e8200b6cb0caa56c69d23c79e7f2")

