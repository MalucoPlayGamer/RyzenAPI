-- Lua provided by RyzenAPI 
-- Game: Drunken Dad Simulator
addappid(1609090)
addappid(1609091, 1, "b913128bf5eac725f96242f8c861ad0367a3e8200b6cb0caa56c69d23c79e7f2")
