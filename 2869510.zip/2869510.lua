-- Lua provided by RyzenAPI
-- Game: addappid(2869510)

-- MAIN APPLICATION
addappid(2869510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2869511, 1, "dddcafbbead29fe12f8b01ff6c722f6e478e664cf62c66633e2dfed3928486b3")
