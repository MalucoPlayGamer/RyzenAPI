-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Demon Lord Army Set 1

-- MAIN APPLICATION
addappid(2945500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945500,0,"3ce0d98ce1e891b88ee64176a3619c79c7e635352dec88c91607688c22e794a1")
