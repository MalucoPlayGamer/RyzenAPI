-- Lua provided by RyzenAPI
-- Game: Nano Nebula

-- MAIN APPLICATION
addappid(818590)

-- MAIN APP DEPOTS / PACKAGES
addappid(818591,0,"57c1b0e8e61ea10cca529ca90ddbdce1e6a81d4809d70b12f42b77e43def67d9")

