-- Lua provided by RyzenAPI
-- Game: Game: AppID 1388860

-- MAIN APPLICATION
addappid(1388860)
-- Game: addappid(1388860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388861, 1, "a17dd009a6ebcc47999cf67eda8317ae131937285c4a12ecbc0007c44c40ccbd")
addappid(1388862, 1, "1f054f3b0caf204937eb5b668d8f3f5bdebcf1430827ba590b4fd72079cf35aa")
addappid(1388863, 1, "5ead9bee6cfba8f1528ae649b286211b1c69c1b81fa68f1a94288fd48ecff4c1")
