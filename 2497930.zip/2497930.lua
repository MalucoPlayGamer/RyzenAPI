-- Lua provided by RyzenAPI
-- Game: 2497930

-- MAIN APPLICATION
addappid(2497930)
addappid(3964510)
-- Game: addappid(2497930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497931, 1, "af80d4af1a25de8531c4635be4ee9237e8e5b2df826acb45008de83fdd34e40d")
