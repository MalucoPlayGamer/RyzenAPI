-- Lua provided by RyzenAPI
-- Game: Sheep's Symphony

-- MAIN APPLICATION
addappid(2919290)
-- Game: addappid(2919290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919291, 1, "1052771fe4fa18b39721a2b48fb05dfcd4eec33f1d4e2809590005a6283287b3")
