-- Lua provided by RyzenAPI
-- Game: TANKS

-- MAIN APPLICATION
addappid(866420)

-- MAIN APP DEPOTS / PACKAGES
addappid(866421, 1, "4c0eb1dd32013438ff2876f4d251637937557fa07e9839e424ff3a53e55e8ca7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
