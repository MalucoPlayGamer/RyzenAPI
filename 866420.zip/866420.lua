-- Lua provided by RyzenAPI
-- Game: TANKS

-- MAIN APPLICATION
addappid(866420)
-- Game: addappid(866420)

-- MAIN APP DEPOTS / PACKAGES
addappid(866421, 1, "4c0eb1dd32013438ff2876f4d251637937557fa07e9839e424ff3a53e55e8ca7")
