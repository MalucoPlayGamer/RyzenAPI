-- Lua provided by RyzenAPI 
-- Game: AppID 1118240
addappid(1118240)
addappid(1118241, 1, "e33cf686383a8d0e8befed02cb79f094d658ab2845e10db176e2d20e36d9d4f3")
addappid(2450860, 0, "09659ee04343ce4c46f62a1a049c47d97afe38cd2058ed7486b8818fc929a111")
