-- Lua provided by RyzenAPI
-- Game: addappid(1818960)

-- MAIN APPLICATION
addappid(1818960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818961, 1, "9630475e1251418d56f3abc6abdcc33157b9aa0813c1420fe03a5f9ab387027e")
