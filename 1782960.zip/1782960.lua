-- Lua provided by RyzenAPI 
-- Game: Laboratory of Nightmares
addappid(1782960)
addappid(1782961, 1, "d18ccb1dce646841b52b5b0322f621f8c77736bf22851cd23b3f21f91219db9d")
