-- Lua provided by RyzenAPI
-- Game: Game: Laboratory of Nightmares

-- MAIN APPLICATION
addappid(1782960)
-- Game: addappid(1782960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782961, 1, "d18ccb1dce646841b52b5b0322f621f8c77736bf22851cd23b3f21f91219db9d")
