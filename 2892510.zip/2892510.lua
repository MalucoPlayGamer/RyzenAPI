-- Lua provided by RyzenAPI
-- Game: Game: Simple Sanguo

-- MAIN APPLICATION
addappid(2892510)
-- Game: addappid(2892510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892511, 1, "e3c38af9b8d5fb02ae9c6003b46498b9043f1e65d1c43b9cbd676176849ba008")
