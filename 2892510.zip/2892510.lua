-- Lua provided by RyzenAPI 
-- Game: Simple Sanguo
addappid(2892510)
addappid(2892511, 1, "e3c38af9b8d5fb02ae9c6003b46498b9043f1e65d1c43b9cbd676176849ba008")
