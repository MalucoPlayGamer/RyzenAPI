-- Lua provided by RyzenAPI
-- Game: 2433950

-- MAIN APPLICATION
addappid(2433950)
-- Game: addappid(2433950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2433951, 1, "68cb638ff8c3367fa777f00ecf49ee8b956c136c8c2947ee7e5445399fc231e4")
