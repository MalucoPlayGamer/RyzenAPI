-- Lua provided by RyzenAPI
-- Game: addappid(2720430)

-- MAIN APPLICATION
addappid(2720430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720431, 1, "a0adcf6b01b626c25e550da7fdd09f1dd23f9681331609ac653de5fcb0275e85")
