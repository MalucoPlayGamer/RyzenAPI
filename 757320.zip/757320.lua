-- Lua provided by RyzenAPI
-- Game: addappid(757320)

-- MAIN APPLICATION
addappid(757320)

-- MAIN APP DEPOTS / PACKAGES
addappid(757321, 1, "2c983fc1fb84558e3f343a718ac0534034a8ed2c2a2780d47f56bee8a99565df")
