-- Lua provided by RyzenAPI
-- Game: Ender theater

-- MAIN APPLICATION
addappid(2915170)
-- Game: addappid(2915170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2915171, 1, "6775edccbc203ea653536c143d693527a1293253593331b11103a903e2a8361d")
