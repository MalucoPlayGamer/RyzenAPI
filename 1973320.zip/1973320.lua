-- Lua provided by RyzenAPI
-- Game: Road Defense: Outsiders

-- MAIN APPLICATION
addappid(1973320)
-- Game: addappid(1973320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1973321, 1, "1b3e9732c4e4533d0afa085148e1ad61de5b267de3ae00387f0481d6ba83c6aa")
