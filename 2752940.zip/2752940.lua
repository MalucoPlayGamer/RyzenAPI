-- Lua provided by RyzenAPI
-- Game: WANDERER: Broken Bed Demo

-- MAIN APPLICATION
addappid(2752940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752941, 1, "a09910a97d2a1da9f7e91263ec09a3703ee58fa1c2ffa99da5e81903a9d0c33e")
