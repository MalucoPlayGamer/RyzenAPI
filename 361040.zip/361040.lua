-- Lua provided by RyzenAPI
-- Game: addappid(361040)

-- MAIN APPLICATION
addappid(361040)

-- MAIN APP DEPOTS / PACKAGES
addappid(361041, 1, "1244dbf2052b2e8719f967b40baaef0df4d6efa37d2073ee671c118f92e2e55f")
addappid(361042, 1, "cee3c9025620ecccc2276aa2a2b516c8fd74aa9b4835634db892a1fdd55e1914")
addappid(361043, 1, "abaed4d122ebdc3b2611d166d433208ac68dbb326961f82161ca076bfdfc094f")
