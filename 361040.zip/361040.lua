-- Lua provided by RyzenAPI
-- Game: Doom & Destiny Advanced

-- MAIN APPLICATION
addappid(361040)

-- MAIN APP DEPOTS / PACKAGES
addappid(361041, 1, "1244dbf2052b2e8719f967b40baaef0df4d6efa37d2073ee671c118f92e2e55f")
addappid(361042, 1, "cee3c9025620ecccc2276aa2a2b516c8fd74aa9b4835634db892a1fdd55e1914")
addappid(361043, 1, "abaed4d122ebdc3b2611d166d433208ac68dbb326961f82161ca076bfdfc094f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
