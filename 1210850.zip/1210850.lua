-- Lua provided by RyzenAPI 
-- Game: Super Kickers League
addappid(1210850)
addappid(1210851, 1, "a635eae71d402dc15901e002b0bac1ed06d0a3edbc02f6887da6a48268e53ce5")
