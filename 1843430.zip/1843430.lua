-- Lua provided by RyzenAPI
-- Game: addappid(1843430)

-- MAIN APPLICATION
addappid(1843430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843431, 1, "a7e84edfc7b98deaac9e71f398ea56f7ec516110ca932c61856d2ff03c914881")
