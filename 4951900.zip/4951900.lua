-- 4951900's Lua and Manifest Created by Hubcap Manifest
-- DISCIPLINE
-- Created: August 10, 2026 at 14:56:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4951900) -- DISCIPLINE
-- MAIN APP DEPOTS
addappid(4951901, 1, "6af89dd5182460ff59fae6a6903e530240df71c75af51dea9ba3fcd5568ffbf9") -- Depot 4951901
setManifestid(4951901, "6844780085318232250", 21920424)