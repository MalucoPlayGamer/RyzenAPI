-- Lua provided by RyzenAPI 
-- Game: AppID 916950
addappid(916950)
addappid(916951, 1, "501a48d37c700755e13f9cd5bf13af108f377dffa26806db96c76875e5dc14e3")
