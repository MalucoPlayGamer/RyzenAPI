-- Lua provided by RyzenAPI
-- Game: Game: Cowboy Girl

-- MAIN APPLICATION
addappid(2017020)
-- Game: addappid(2017020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017021, 1, "71f4f1b6e8aaef27127adb799aeb44e21ad41d306808141c30849311779e0a29")
