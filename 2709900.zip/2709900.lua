-- Lua provided by RyzenAPI
-- Game: My Faithful and Loyal Wife Would Never Cheat on Me

-- MAIN APPLICATION
addappid(2709900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709901, 1, "1330d2e7ff4973925d4e6873c6b4bebc9043fa80fc032915bd378d95affc60c2")

