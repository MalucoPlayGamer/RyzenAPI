-- Lua provided by RyzenAPI
-- Game: Game: Ammo and Oxygen

-- MAIN APPLICATION
addappid(2549650)
-- Game: addappid(2549650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549651, 1, "f64f6fdd32088ec9f9c75e64b2ea4def6233ccdeab4e3ddea9318440c14182d0")
