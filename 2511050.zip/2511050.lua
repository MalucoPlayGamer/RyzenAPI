-- Lua provided by RyzenAPI
-- Game: 2511050

-- MAIN APPLICATION
addappid(2511050)
-- Game: addappid(2511050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511051, 1, "b5516dd21c8e0a96a63c3f8a29877ecdd6bfd0ddd2a960c76bc56bd4a5f02960")
