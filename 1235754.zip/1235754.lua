-- Lua provided by RyzenAPI
-- Game: The Sims™ 4 Роскошная вечеринка Каталог

-- MAIN APPLICATION
addappid(1235754)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235754,0,"7aa8a0384924f70690672a790c8dcc0bda83b72289db9c4042e62d0400d48be2")
addappid(1242220,0,"aa8dee9f289cddbbc377168cad0b10b7d8fb61c802efdbf72bcf3a58884490d3")
addappid(1242232,0,"526141e42a3dd57740da5553eca1e61a0962e15ddc3a40f3857e6d12bd6c1c98")
addappid(1242236,0,"735d44b33ae22e82b3fcd8a525ca388f1b8fbcfa91f521f687818df008622ee7")
addappid(1242237,0,"a77fc4d5437e76c50c2e3ec4cf29c61540767c872b035a3a8e1b52379f3876e5")

