-- Lua provided by RyzenAPI
-- Game: Nothing To God

-- MAIN APPLICATION
addappid(803520)

-- MAIN APP DEPOTS / PACKAGES
addappid(803521,0,"6f458b7916d9093f90d49a58d3bac4771145118c64754557d67d07a42bf2b8bd")

