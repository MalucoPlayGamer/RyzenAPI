-- Lua provided by RyzenAPI
-- Game: Long Story Short

-- MAIN APPLICATION
addappid(2538370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2538371, 1, "83fcafc23d4204b0dc577b6792eeb8f23240220e9851a1db4bbe4452b05e9307")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
