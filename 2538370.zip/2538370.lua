-- Lua provided by SkyAPI 
-- Game: Long Story Short
addappid(2538370)
addappid(2538371, 1, "83fcafc23d4204b0dc577b6792eeb8f23240220e9851a1db4bbe4452b05e9307")
