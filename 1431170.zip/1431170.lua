-- Lua provided by RyzenAPI
-- Game: Game: Pepo

-- MAIN APPLICATION
addappid(1431170)
-- Game: addappid(1431170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431171, 1, "25f73d3f2acdc1daf0c96ddb29923250b9e16e338b5efceec409a32b9ce01bce")
