-- Lua provided by SkyAPI 
-- Game: Pepo
addappid(1431170)
addappid(1431171, 1, "25f73d3f2acdc1daf0c96ddb29923250b9e16e338b5efceec409a32b9ce01bce")
