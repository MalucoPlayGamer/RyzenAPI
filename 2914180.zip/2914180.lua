-- Lua provided by SkyAPI 
-- Game: Lust Academy Season  3 - Forbidden Fantasies
addappid(2914180)
addappid(2914181, 1, "9149c2204e859ec8c68c2313b73b6d59f0588751fcb2936588b77b1ac4e62c0e")
