-- Lua provided by SkyAPI 
-- Game: Sky Resort 3
addappid(3452170)
addappid(3452171, 1, "9930c0a71847a0f67a011d674236002a8f833f90b7838c82c287c980149ba44c")
addappid(3452172, 1, "1d892acbf3064cb0b4e227d2d77bb948d4b07c4a9dabd6468c2b4c9eee227128")
addappid(3482740)
