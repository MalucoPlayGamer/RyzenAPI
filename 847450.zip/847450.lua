-- Lua provided by RyzenAPI
-- Game: Solenars Edge Heroes

-- MAIN APPLICATION
addappid(847450)

-- MAIN APP DEPOTS / PACKAGES
addappid(847451, 1, "adc4ab6ed2f9dc57bab44365953606983e286620c83fcda395b198a64831f53e")

