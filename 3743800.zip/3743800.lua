-- Lua provided by SkyAPI 
-- Game: Hozy Playtest
addappid(3743800)
addappid(3743801, 1, "b03bde1a555521807cec9c66e12e3f8a49c9f72bb643c55459095035d87dd9c5")
addappid(3743802, 1, "79443380b30b4c771eb9cd4381a9b74af2e675b125cfd71fca8814d0185debfe")
