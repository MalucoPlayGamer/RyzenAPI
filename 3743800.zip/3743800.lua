-- Lua provided by RyzenAPI
-- Game: Hozy Playtest

-- MAIN APPLICATION
addappid(3743800)
-- Game: addappid(3743800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3743801, 1, "b03bde1a555521807cec9c66e12e3f8a49c9f72bb643c55459095035d87dd9c5")
addappid(3743802, 1, "79443380b30b4c771eb9cd4381a9b74af2e675b125cfd71fca8814d0185debfe")
