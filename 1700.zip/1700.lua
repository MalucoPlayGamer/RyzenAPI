-- Lua provided by RyzenAPI
-- Game: Arx Fatalis

-- MAIN APPLICATION
addappid(1700)
-- Game: addappid(1700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701, 1, "2040cea390fa171a89a5496009140ab2231a40843f83d3dd1924ab08071e2916")
addappid(1702, 1, "8482f7dca2b322008e484d0b23d8dd87c915fbf4891fb281fa232641fb8730b6")
addappid(1703, 1, "8698e5b3c0d0533ff1e7dedb8946170b496b0ace3a8748bdfd3ad999b2470f7f")
addappid(1705, 1, "5c39ea2dbc40b6c695438b886762ff669c9db0ee84fc8a248b289aab39d7fdc0")
addappid(1706, 1, "4a19038fa318ec3c3d34b6a736e6be06efc18fa358f709ccb9c93ea44ec61fc2")
addappid(1707, 1, "62b6b74d4ae963d87b969e08296b89fdc073154ece49ba7a9bcbe768e1343892")
