-- Lua provided by RyzenAPI
-- Game: Zenkcraft

-- MAIN APPLICATION
addappid(2098510)
addappid(3216970)
-- Game: addappid(2098510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098511, 1, "24c58def09179dd0b37c9151a32fbc01d558d0247c5675097d4737738badd4ed")
