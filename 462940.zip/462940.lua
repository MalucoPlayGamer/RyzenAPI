-- Lua provided by RyzenAPI
-- Game: AppID 462940

-- MAIN APPLICATION
addappid(462940)

-- MAIN APP DEPOTS / PACKAGES
addappid(462941, 1, "b9f5ed1c991d1165b358f79dbf1e0d57a339ed9a8c5bb997d791d2daa58f52a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
