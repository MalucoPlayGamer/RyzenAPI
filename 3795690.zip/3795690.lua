-- Lua provided by RyzenAPI
-- Game: Seasons of Chiba

-- MAIN APPLICATION
addappid(3795690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3795691, 1, "f1acb08613b7e55fc941b772280d5346dd1befd562060e884ea366e8127f6691")

