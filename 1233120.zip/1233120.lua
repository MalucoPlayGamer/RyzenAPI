-- Lua provided by RyzenAPI
-- Game: AppID 1233120

-- MAIN APPLICATION
addappid(1233120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233121, 1, "e85c6e62b802dae988e0a9d1f45dcb373fb89795c8c2d0ccc19c77fe3b506b18")
