-- Lua provided by RyzenAPI
-- Game: Street Racing 2020

-- MAIN APPLICATION
addappid(1233120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1233121, 1, "e85c6e62b802dae988e0a9d1f45dcb373fb89795c8c2d0ccc19c77fe3b506b18")

