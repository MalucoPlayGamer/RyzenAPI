-- Lua provided by RyzenAPI
-- Game: Project Z: The beginning of the end. Chapter I

-- MAIN APPLICATION
addappid(2514340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2514341, 1, "0d266dc11fef8cdebd0fdef29ea64255a6edfe77659c113d6fd1c1a6b53bc31d")

