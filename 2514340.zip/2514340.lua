-- Lua provided by RyzenAPI
-- Game: Game: Project Z: The beginning of the end. Chapter I

-- MAIN APPLICATION
addappid(2514340)
-- Game: addappid(2514340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514341, 1, "0d266dc11fef8cdebd0fdef29ea64255a6edfe77659c113d6fd1c1a6b53bc31d")
