-- Lua provided by RyzenAPI
-- Game: Mowin' & Throwin'

-- MAIN APPLICATION
addappid(762030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(762031,0,"254a2984c25629e7d12b703c0a68f6bc123db62b9c81c281bf6b6adbf7039a09")

