-- Lua provided by RyzenAPI
-- Game: Mowin' & Throwin'

-- MAIN APPLICATION
addappid(762030)

-- MAIN APP DEPOTS / PACKAGES
addappid(762031,0,"254a2984c25629e7d12b703c0a68f6bc123db62b9c81c281bf6b6adbf7039a09")

