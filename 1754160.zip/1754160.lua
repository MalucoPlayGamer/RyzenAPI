-- Lua provided by RyzenAPI
-- Game: Attack on Toys (Classic, 2019)

-- MAIN APPLICATION
addappid(1754160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754160,0,"a13e86cf7ee2fa891b7a36fb9852a21a7fea2ddf34188c4e07b860c990accbf9")

