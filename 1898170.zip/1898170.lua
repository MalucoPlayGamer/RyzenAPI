-- Lua provided by SkyAPI 
-- Game: AppID 1898170
addappid(1898170)
addappid(1898171, 1, "b4b9f790aa0236fd21a13173ff92e1a17e6072587ba75f736ef8d03e2581b85c")
