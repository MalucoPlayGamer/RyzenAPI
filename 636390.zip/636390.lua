-- Lua provided by RyzenAPI
-- Game: Game: Ticket to Earth

-- MAIN APPLICATION
addappid(636390)
-- Game: addappid(636390)

-- MAIN APP DEPOTS / PACKAGES
addappid(636391, 1, "83505ccb1d95d97ad2e9cd0fd95858f81936cf9def66cf15c25d7e5e541956dd")
addappid(636392, 1, "e2718d7f7776f566b47a5ab580f37dbd38b260a3c48101da1b7ac12c13b720e5")
addappid(636393, 1, "085778a8e5d1dace34aa9d54bf70c33f23802e29533a055c25a72232a7e880b4")
