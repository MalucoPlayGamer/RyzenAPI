-- Lua provided by RyzenAPI 
-- Game: AppID 3319590
addappid(3319590)
addappid(3319591, 1, "c4f6576238628a6711ea03922b248ed56b728b13d7420922c88dad087fbd3b2c")
