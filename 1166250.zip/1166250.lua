-- Lua provided by RyzenAPI
-- Game: Game: Mahjong Gold

-- MAIN APPLICATION
addappid(1166250)
-- Game: addappid(1166250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166251, 1, "d2498c8ed3d17dfa4465895429b6c4b25370726a520ff56f2569a17872a40c4f")
