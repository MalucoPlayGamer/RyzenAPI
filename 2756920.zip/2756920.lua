-- Lua provided by RyzenAPI
-- Game: Keep Driving

-- MAIN APPLICATION
addappid(2756920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2756921, 1, "10032716e9015079aeec2f3447817d6aa1fb0ae3dd8273de5703282a258f0d36")

