-- Lua provided by SkyAPI 
-- Game: Lost in a Forest
addappid(345280)
addappid(345281, 1, "03a68a07e28e4a58be35b18ee9833a257caf364c22d1d0da69abc4eb51c51a1a")
