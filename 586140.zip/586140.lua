-- Lua provided by RyzenAPI
-- Game: Game: AppID 586140

-- MAIN APPLICATION
addappid(586140)
-- Game: addappid(586140)

-- MAIN APP DEPOTS / PACKAGES
addappid(586141, 1, "c99c2fc9ec1bf1a45fc4f91bbc02b59692e46294454be80955658b710f9659ed")
