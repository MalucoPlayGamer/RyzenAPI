-- Lua provided by RyzenAPI
-- Game: BlazBlue Centralfiction

-- MAIN APPLICATION
addappid(586140)
addappid(708880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(586141, 1, "c99c2fc9ec1bf1a45fc4f91bbc02b59692e46294454be80955658b710f9659ed")
