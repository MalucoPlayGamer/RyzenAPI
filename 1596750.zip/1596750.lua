-- Lua provided by RyzenAPI
-- Game: 1596750

-- MAIN APPLICATION
addappid(1596750)
-- Game: addappid(1596750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1596751, 1, "337b3f4e47a8666db6e346ccd939832cdeb679125e382198518ddb4763e1b3ef")
