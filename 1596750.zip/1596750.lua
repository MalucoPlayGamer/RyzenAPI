-- Lua provided by SkyAPI 
-- Game: AppID 1596750
addappid(1596750)
addappid(1596751, 1, "337b3f4e47a8666db6e346ccd939832cdeb679125e382198518ddb4763e1b3ef")
