-- Lua provided by RyzenAPI
-- Game: Rustil: Eternal Labyrinth Castle

-- MAIN APPLICATION
addappid(2162820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2162821, 1, "e11b8dde866fa18dd1ba6b5fa070ac5ae5f2863a788bf87318a0197533367e1b")

