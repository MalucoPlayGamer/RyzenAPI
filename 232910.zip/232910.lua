-- Lua provided by RyzenAPI
-- Game: TrackMania² Stadium

-- MAIN APPLICATION
addappid(232910)

-- MAIN APP DEPOTS / PACKAGES
addappid(232911, 1, "6194b91617c255976eabb2ee2da660faa2fe9407121c09fae30f36efcfa0417d")
