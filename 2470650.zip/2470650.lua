-- Lua provided by RyzenAPI
-- Game: 2470650

-- MAIN APPLICATION
addappid(2470650)
-- Game: addappid(2470650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470651, 1, "037a2e10cccf338b2e7cc1cf29956a2e5a08b5f34236404ba11339a925ed45cd")
