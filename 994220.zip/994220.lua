-- Generated with Luie @ https://lua.tools/
-- 994220 - NEOVERSE
-- Generated 2026-08-17 03:00:08 UTC
-- # Depots (Total/DLC/Shared): 2/0/0

-- Main AppID
addappid(994220, 1, "281a946fe213a7041d0626ffc444feb27f95bfa80662b333b4dea3b7670dfb98")

-- Main Depots
addappid(994221, 1, "16a38a30f155982552a9e7d3c3eb73de62c86e0d2f308b75315fff83a36c1c0c") -- (windows)
setManifestid(994221, "1334745261082354281", 4266168924)
addappid(994222, 1, "f23c011695e88b547a4284de8ee26abe7386ac134782c6ad8aba781d0b623bb3") -- (macos)
setManifestid(994222, "8956456217180101141", 4815379846)

-- DLC's (no depot keys required)
addappid(1343250) -- Neoverse - Cyberpunk Costume Pack
addappid(1375250) -- Neoverse - Hot Break Pack
addappid(1429010) -- Neoverse - Schoolgirl
addappid(1590520) -- Neoverse - Super Hero Pack
