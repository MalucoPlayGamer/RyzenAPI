-- Lua provided by RyzenAPI
-- Game: Game: NEOVERSE

-- MAIN APPLICATION
addappid(994220)
-- Game: addappid(994220)

-- MAIN APP DEPOTS / PACKAGES
addappid(994221, 1, "16a38a30f155982552a9e7d3c3eb73de62c86e0d2f308b75315fff83a36c1c0c")
addappid(994222, 1, "f23c011695e88b547a4284de8ee26abe7386ac134782c6ad8aba781d0b623bb3")
