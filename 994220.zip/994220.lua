-- Lua provided by RyzenAPI
-- Game: NEOVERSE

-- MAIN APPLICATION
addappid(1343250) -- Neoverse - Cyberpunk Costume Pack
addappid(1375250) -- Neoverse - Hot Break Pack
addappid(1429010) -- Neoverse - Schoolgirl
addappid(1590520) -- Neoverse - Super Hero Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(994220, 1, "281a946fe213a7041d0626ffc444feb27f95bfa80662b333b4dea3b7670dfb98")
addappid(994221, 1, "16a38a30f155982552a9e7d3c3eb73de62c86e0d2f308b75315fff83a36c1c0c") -- (windows)
addappid(994222, 1, "f23c011695e88b547a4284de8ee26abe7386ac134782c6ad8aba781d0b623bb3") -- (macos)

