-- Lua provided by RyzenAPI
-- Game: addappid(739260)

-- MAIN APPLICATION
addappid(739260)

-- MAIN APP DEPOTS / PACKAGES
addappid(739261, 1, "c166b071e5c9d5f73159d312bbad567f44197490ef697eabaf63650e04774f3b")
addappid(739262, 1, "a0d8aab00b8e6d7744408dd8ab5f2dbdcc3fd5db7f32afced487d6ae00c54094")
