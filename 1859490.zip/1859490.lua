-- Lua provided by SkyAPI 
-- Game: Planet TD
addappid(1859490)
addappid(1859491, 1, "7e69a6d17b5f851531a5c3b7a8b2fa4f70b7881a136db11e06b545c627e668df")
