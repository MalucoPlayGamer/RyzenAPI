-- Lua provided by RyzenAPI
-- Game: addappid(1859490)

-- MAIN APPLICATION
addappid(1859490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859491, 1, "7e69a6d17b5f851531a5c3b7a8b2fa4f70b7881a136db11e06b545c627e668df")
