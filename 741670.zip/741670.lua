-- Lua provided by RyzenAPI
-- Game: Easy Red

-- MAIN APPLICATION
addappid(741670)

-- MAIN APP DEPOTS / PACKAGES
addappid(741671, 1, "d0e640144590d1637f442353c887d83e81d3ff3e3e1ca0cb5245c1b6b66ef9f6")
addappid(741672, 1, "9378ba3b9618aae490a032f9976ad6f1eda2e7c5c12ee2b94cea29ce8872a459")
addappid(741673, 1, "082883d20ae1d5eda2cca4c25a2688af55dace5b5f847f29f491c56b08d6b409")

