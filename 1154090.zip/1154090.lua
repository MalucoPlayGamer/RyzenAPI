-- Lua provided by SkyAPI 
-- Game: AppID 1154090
addappid(1154090)
addappid(1154091, 1, "c406f3fcb0cd5c4a3aba03cf5cac62fc9ecdeb38633ec741b7625b26d0b477c3")
