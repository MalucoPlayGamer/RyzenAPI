-- Lua provided by RyzenAPI 
-- Game: GraFi St.Patrick
addappid(1259860)
addappid(1259861, 1, "130871cb17596af599573a9d341510ff3e8367bcfc1bbbcb09bd6a301742f5d3")
