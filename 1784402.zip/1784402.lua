-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - 90s Retro Sounds - Battle

-- MAIN APPLICATION
addappid(1784402)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784402,0,"73f557ed17ab0a2e351f99963c69e97c5f1d1a492ec6a1fe6ac12a50b99adc96")
