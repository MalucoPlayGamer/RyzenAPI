-- Lua provided by RyzenAPI
-- Game: Sunset Giant

-- MAIN APPLICATION
addappid(979350)

-- MAIN APP DEPOTS / PACKAGES
addappid(979351, 1, "6f369c6155bfb5298d78433c3edcbbe72cd48580fd25a7f293444a591e5192fc")

