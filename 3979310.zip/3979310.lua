-- Lua provided by RyzenAPI
-- Game: FIND KITTENS 6: After us

-- MAIN APPLICATION
addappid(3979310)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4096560)
addappid(4096570)
