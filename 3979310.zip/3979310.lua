-- Lua provided by RyzenAPI
-- Game: FIND KITTENS 6: After us

-- MAIN APPLICATION
addappid(3979310)

