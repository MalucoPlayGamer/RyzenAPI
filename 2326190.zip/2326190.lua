-- Lua provided by RyzenAPI
-- Game: Game: Goospace

-- MAIN APPLICATION
addappid(2326190)
-- Game: addappid(2326190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326191, 1, "ad2161680a6fb2a030806339f6db819b4600721d46919e76a340b1f7d01f328b")
