-- Lua provided by RyzenAPI 
-- Game: AppID 2864860
addappid(2864860)
addappid(2864861, 1, "c8712cbd169edeb00a2042f91c1e415f34fddb18925eaa4226e53fa75f81b80d")
addappid(2864862, 1, "6b7182a8ca00b43b18e185a9551ac25b3c25ad3c05b1db8803d65f745ae11278")
addappid(2864863, 1, "0a2b8a655b12e54a27efbcd0ab0b0e4f0a997fa5a60d4cbd8888fd0f32ea97b4")
