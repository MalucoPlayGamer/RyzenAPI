-- Lua provided by RyzenAPI
-- Game: 388550

-- MAIN APPLICATION
addappid(388550)
-- Game: addappid(388550)

-- MAIN APP DEPOTS / PACKAGES
addappid(388551, 1, "4c5665a741607d33c38fd23c796d5feb089d63700efbf7606b3adc22ad9bea11")
