-- Lua provided by RyzenAPI
-- Game: 星星水族馆~Star Aquarium

-- MAIN APPLICATION
addappid(3703090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3703091, 1, "de225f26123fab2e9f0271f69bc52177c4e7898afc17fc13949246f0fdfef543")
