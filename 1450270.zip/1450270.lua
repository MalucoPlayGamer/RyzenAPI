-- Lua provided by RyzenAPI
-- Game: Kill Fish

-- MAIN APPLICATION
addappid(1450270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450271, 1, "5039cbb2be0c400f28ffe6f2d5e407318308d51da335dfb2b475bfa5ef15b650")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
