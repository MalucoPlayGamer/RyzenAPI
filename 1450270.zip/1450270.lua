-- Lua provided by RyzenAPI
-- Game: addappid(1450270)

-- MAIN APPLICATION
addappid(1450270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450271, 1, "5039cbb2be0c400f28ffe6f2d5e407318308d51da335dfb2b475bfa5ef15b650")
