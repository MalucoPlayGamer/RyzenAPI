-- Lua provided by RyzenAPI
-- Game: 1750150

-- MAIN APPLICATION
addappid(1750150)
addappid(1750151)
addappid(1750152)
addappid(1750154)
addappid(1750155)
addappid(1750156)
addappid(1750157)
addappid(1750158)
-- Game: addappid(1750150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750153,0,"04c7fbef81fb599c2bfef702fb60e5889b6f5c22af365b6bb38eff076f4298c2")
addtoken(1750150,553857728466033998)
