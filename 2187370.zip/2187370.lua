-- Lua provided by RyzenAPI
-- Game: Blindsight: War of the Wardens

-- MAIN APPLICATION
addappid(2187370)
-- Game: addappid(2187370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187371, 1, "0936a7c33630dc4f8e5df66d62311793698f866034cc974603ee401fa19c6998")
