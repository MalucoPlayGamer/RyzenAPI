-- Lua provided by RyzenAPI
-- Game: UNO Demo

-- MAIN APPLICATION
addappid(471610)

-- MAIN APP DEPOTS / PACKAGES
addappid(471611, 1, "a8fea654f06acf8fed2ec2c30d0a8de6ab34117d4c66e1c6bb222cba3a47253d")
