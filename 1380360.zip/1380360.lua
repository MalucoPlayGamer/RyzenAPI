-- Lua provided by RyzenAPI
-- Game: Game: Battle Sweeper

-- MAIN APPLICATION
addappid(1380360)
-- Game: addappid(1380360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380361, 1, "f28e07cd112c8831ec5e56851a7a5bb1fb786d160c573cc3a88e79c4bd1efc6f")
