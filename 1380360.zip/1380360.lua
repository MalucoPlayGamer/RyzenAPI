-- Lua provided by RyzenAPI
-- Game: Battle Sweeper

-- MAIN APPLICATION
addappid(1380360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380361, 1, "f28e07cd112c8831ec5e56851a7a5bb1fb786d160c573cc3a88e79c4bd1efc6f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
