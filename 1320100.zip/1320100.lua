-- Lua provided by RyzenAPI
-- Game: Game: Wanted Raccoon

-- MAIN APPLICATION
addappid(1320100)
-- Game: addappid(1320100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320101, 1, "348651b3ab8f64ae5971d729f4e507372334fe7d304d6f94dc95063ff6be5bf0")
addappid(1320102, 1, "6569a93d44f42a152ff5a1826993ca1c5fcede19c49cbbc044c6faa959098f53")
addappid(1320103, 1, "baf7535a29a6846140be40177572ae39621e646b315395bfbcd859bcc1e5b6fe")
