-- Lua provided by RyzenAPI
-- Game: Gan Ning - Officer Ticket / 甘寧使用券

-- MAIN APPLICATION
addappid(956708)

-- MAIN APP DEPOTS / PACKAGES
addappid(956708,0,"b637468afdf667a31d9e888d0cd16e23b83f80aee8e0522cd42795df4dddb320")

