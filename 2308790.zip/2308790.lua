-- Lua provided by RyzenAPI
-- Game: UNDRESS!

-- MAIN APPLICATION
addappid(2308790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308791, 1, "eb29001c976def41f1db0f58bf2da2032061f834c4927e3ce8fac14c32cb4411")

