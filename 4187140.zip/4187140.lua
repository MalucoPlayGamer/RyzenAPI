-- Lua provided by RyzenAPI
-- Game: Don't Panic! It is Just Turbulence

-- MAIN APPLICATION
addappid(4187140)

-- MAIN APP DEPOTS / PACKAGES
addappid(4187141, 1, "45bfa6b3b7af407152dac002b68fe8cfc3c1b2a0918bacea0b67e2efeeeb40b1")

