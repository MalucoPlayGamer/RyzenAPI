-- 4696420's Lua and Manifest Created by Hubcap Manifest
-- Fabled Kingdoms
-- Created: July 23, 2026 at 07:33:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4696420) -- Fabled Kingdoms
-- MAIN APP DEPOTS
addappid(4696421, 1, "82136ea81aa55faf0a4240e6d925c2e0dcebf007bf09c2ca85e410b711973ae3") -- Depot 4696421
setManifestid(4696421, "8328888060530024047", 299416297)