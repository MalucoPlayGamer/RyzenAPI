-- Lua provided by RyzenAPI
-- Game: Immortal: Unchained

-- MAIN APPLICATION
addappid(369440)

-- MAIN APP DEPOTS / PACKAGES
addappid(369441, 1, "feb25c57cfec758d53d41579e1de18ba3ed9cfe7f0682394ae3f66099c915381")
