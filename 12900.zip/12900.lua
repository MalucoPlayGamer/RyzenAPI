-- Lua provided by RyzenAPI
-- Game: addappid(12900)

-- MAIN APPLICATION
addappid(12900)
addappid(228981)
addappid(228982)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(12902,0,"44f4f97c1899f42989a7337e1b1a92cfaa74eef044441f16c589b36dcc06da39")
addappid(12903,0,"cab4a1d94973956ee9a9ff3df89f0ad6a1514922a9595291d6cbf98c51e443ba")
addappid(98003,0,"26cddbe2d8503cc5315997d8b218a49738ca0a56f1d243511a51f8d74846f5cb")
