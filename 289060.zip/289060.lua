-- Lua provided by RyzenAPI
-- Game: addappid(289060)

-- MAIN APPLICATION
addappid(289060)

-- MAIN APP DEPOTS / PACKAGES
addappid(289061, 1, "d29b9d45013f1af41377ce263c7e2b69de68ba25dcc7ac31cce9885932edd832")
addappid(289062, 1, "2fad5f533cba4e85db43d36d055b61f238f6fb6626aefe943e491b84fd9da7ad")
