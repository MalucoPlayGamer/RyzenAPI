-- Lua provided by RyzenAPI
-- Game: 2121350

-- MAIN APPLICATION
addappid(2121350)
-- Game: addappid(2121350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2121351, 1, "d8ba13a9a26d23b4cc55836335d7fecb74e2a3fb1779e34b1326617efee1eeb0")
