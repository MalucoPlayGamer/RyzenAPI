-- Lua provided by RyzenAPI
-- Game: Game: AppID 422870

-- MAIN APPLICATION
addappid(422870)
-- Game: addappid(422870)

-- MAIN APP DEPOTS / PACKAGES
addappid(422871, 1, "a468ad672b67580e27d4500d86ccecb751e7a620ca114d45601e34ef0aacc040")
