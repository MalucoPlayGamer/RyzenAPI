-- Lua provided by RyzenAPI
-- Game: Turbo Chicken Simulator

-- MAIN APPLICATION
addappid(2569610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569611, 1, "a13eb449349c99d211d6d0daf87a1b3d7943e3bd33fb483cc7f3dfe2c007df2b")
