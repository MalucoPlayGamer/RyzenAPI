-- Lua provided by RyzenAPI 
-- Game: World of the dead Playtest
addappid(3214020)
addappid(3214021, 1, "5692af62c088e4a658bc6dfb69ba6c4535da5bb47d2570c3b76b2517e651008c")
