-- Lua provided by RyzenAPI
-- Game: Game: AppID 453020

-- MAIN APPLICATION
addappid(453020)
-- Game: addappid(453020)

-- MAIN APP DEPOTS / PACKAGES
addappid(453021, 1, "7e11df5799578686b3214dc5297feb331be06235653c68f5f0d06071bc987626")
