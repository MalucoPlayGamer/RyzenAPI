-- Lua provided by RyzenAPI
-- Game: Liuyin's world

-- MAIN APPLICATION
addappid(3689510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3689511, 1, "dc05b39be2d37984e29901be3f6ca492ee05d4e713d6fcdaed4dfb5d0e828ba2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
