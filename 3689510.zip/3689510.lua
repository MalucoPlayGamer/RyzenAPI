-- Lua provided by RyzenAPI
-- Game: Liuyin's world

-- MAIN APPLICATION
addappid(3689510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3689511, 1, "dc05b39be2d37984e29901be3f6ca492ee05d4e713d6fcdaed4dfb5d0e828ba2")

