-- Lua provided by RyzenAPI
-- Game: Game: Kyoto Colorful Days

-- MAIN APPLICATION
addappid(464080)
addappid(474260)
addappid(474420)
-- Game: addappid(464080)

-- MAIN APP DEPOTS / PACKAGES
addappid(464081, 1, "32283a87dc5d44ddf8cbfd2c725a429b869f525ede740e98ed8dcef944a6112b")
