-- Lua provided by RyzenAPI
-- Game: 重返现场：真人版

-- MAIN APPLICATION
addappid(3311560)
-- Game: addappid(3311560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3311561, 1, "62ffffd331a0b89045fc3e8a5b8477fc1dedaca549a8889553a3b2769d2f8f7a")
