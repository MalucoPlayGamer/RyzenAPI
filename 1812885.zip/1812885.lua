-- Lua provided by RyzenAPI
-- Game: 1812885

-- MAIN APPLICATION
addappid(1812885)
-- Game: addappid(1812885)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812885,0,"82d397b5abba91b16b644d465222fc1bd4dd539cac6f118ceb1a145b750730a5")
