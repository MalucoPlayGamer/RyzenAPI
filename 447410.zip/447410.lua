-- Lua provided by RyzenAPI
-- Game: addappid(447410)

-- MAIN APPLICATION
addappid(447410)

-- MAIN APP DEPOTS / PACKAGES
addappid(447410,0,"354be33073a04b1cdfbfc3407dd04eb7bbfe8ba51d462ca1e8b867834ea6f4c4")
