-- Lua provided by RyzenAPI
-- Game: Game: AppID 2797500

-- MAIN APPLICATION
addappid(2797500)
-- Game: addappid(2797500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797501, 1, "03861f955862b45c1fb20266d31d211a56d13eefa14011cbf93e2c40ed8a2ab0")
