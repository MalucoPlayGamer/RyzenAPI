-- Lua provided by RyzenAPI
-- Game: Toys of War

-- MAIN APPLICATION
addappid(437340)

-- MAIN APP DEPOTS / PACKAGES
addappid(437341, 1, "356bbb183247fa3d8b5c17cf1f4ec209c198ff65e1ce84af163411036d038e47")
