-- Lua provided by RyzenAPI
-- Game: Game: Crow Country

-- MAIN APPLICATION
addappid(1996010)
-- Game: addappid(1996010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996011, 1, "03fd552f6a3450a294492f8843ab72c7575d5196b28c686b118bd6d850a7f553")
