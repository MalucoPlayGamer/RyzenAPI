-- Lua provided by RyzenAPI 
-- Game: AppID 1029970
addappid(1029970)
addappid(1029971, 1, "c378cbb35423e92c1ab53665fe7d27c32bcd87395fbf62584a4934af2d958f8f")
addappid(1029972, 1, "45db708fd59e0464018260f057f4d76b2a76533e87a953c5e576f8dfc0716f8c")
