-- Lua provided by SkyAPI 
-- Game: Mars Colonization
addappid(2357130)
addappid(2357131, 1, "1d4ff2ec14762216de32e2bf077ec717e416600c45f9f31588eae1814630b6b8")
