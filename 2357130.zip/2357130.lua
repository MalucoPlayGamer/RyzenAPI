-- Lua provided by RyzenAPI
-- Game: addappid(2357130)

-- MAIN APPLICATION
addappid(2357130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357131, 1, "1d4ff2ec14762216de32e2bf077ec717e416600c45f9f31588eae1814630b6b8")
