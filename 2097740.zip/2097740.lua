-- Lua provided by RyzenAPI 
-- Game: AKAIITO HD REMASTER
addappid(2097740)
addappid(2097741, 1, "9be108248e896511945464cf68dde2e7e1183201b6a4a2dc2e77306b533f9224")
