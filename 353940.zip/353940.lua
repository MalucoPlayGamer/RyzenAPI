-- Lua provided by RyzenAPI
-- Game: Aces of the Luftwaffe

-- MAIN APPLICATION
addappid(353940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(353941, 1, "5da6b69271b6f1232383711305b4529263f57d60f9a34bfb5587b4aa7d7a564c")

