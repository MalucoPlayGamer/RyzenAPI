-- Lua provided by RyzenAPI
-- Game: 2772300

-- MAIN APPLICATION
addappid(2772300)
-- Game: addappid(2772300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772301, 1, "796795d17280f9de08d3d454fc675cfddd7615b8f7653a78298d3cef941c6384")
