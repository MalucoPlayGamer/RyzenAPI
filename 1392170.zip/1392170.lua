-- Lua provided by SkyAPI 
-- Game: Schastye
addappid(1392170)
addappid(1392171, 1, "9f7210a06d60a8ab068542b0e780a6ee18b3f8a03161ed3bee4bfcddd3c26d87")
