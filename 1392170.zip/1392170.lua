-- Lua provided by RyzenAPI
-- Game: Schastye

-- MAIN APPLICATION
addappid(1392170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392171, 1, "9f7210a06d60a8ab068542b0e780a6ee18b3f8a03161ed3bee4bfcddd3c26d87")

