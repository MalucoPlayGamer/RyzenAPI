-- Lua provided by RyzenAPI
-- Game: addappid(751340)

-- MAIN APPLICATION
addappid(751340)

-- MAIN APP DEPOTS / PACKAGES
addappid(751341, 1, "8fc2b71f7bc0f2654f6a4b200d8ed9e35a0f5990ea6ca68bf01d0f1e41c6e8de")
addappid(751342, 1, "c1516c5430e8e1912d53d3546c59cb7be956dc42faa588973540add0a8bffc42")
