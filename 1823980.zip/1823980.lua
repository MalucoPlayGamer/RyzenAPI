-- Lua provided by RyzenAPI
-- Game: POORLY drawn but HORNY

-- MAIN APPLICATION
addappid(1823980)
-- Game: addappid(1823980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823982,0,"603848242f3783674424dcb41dfe41c76d4c85c36389036c3fe64a7e4018ab48")
