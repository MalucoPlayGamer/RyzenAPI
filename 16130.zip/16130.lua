-- Lua provided by SkyAPI 
-- Game: Fish Tycoon
addappid(16130)
addappid(16131, 1, "7cf9864bb4f484114081f7347a25c74d157804b1896aef0c834e8f2da0d2052e")
