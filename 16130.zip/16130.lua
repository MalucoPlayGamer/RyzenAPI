-- Lua provided by RyzenAPI
-- Game: Game: Fish Tycoon

-- MAIN APPLICATION
addappid(16130)
-- Game: addappid(16130)

-- MAIN APP DEPOTS / PACKAGES
addappid(16131, 1, "7cf9864bb4f484114081f7347a25c74d157804b1896aef0c834e8f2da0d2052e")
