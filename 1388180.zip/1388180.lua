-- Lua provided by RyzenAPI
-- Game: AppID 1388180

-- MAIN APPLICATION
addappid(1388180)
-- Game: addappid(1388180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388181, 1, "59dd718e80501511ba4c3b228f51c707370d2c22dd52260b86ddc83f87c5e0e1")
