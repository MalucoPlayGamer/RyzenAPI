-- Lua provided by RyzenAPI
-- Game: My Bird

-- MAIN APPLICATION
addappid(3461210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461211, 1, "b6b5f35c54cd952b5a51cb3f3e9b796df2001a38098b0478324acc31ebe2046a")

