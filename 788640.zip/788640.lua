-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Stars

-- MAIN APPLICATION
addappid(788640)
-- Game: addappid(788640)

-- MAIN APP DEPOTS / PACKAGES
addappid(788641, 1, "53197a7f86b39fe2f3c30b8684ee4ba1daaa7153f498f9b217b9e4f4fdc898a8")
