-- Lua provided by SkyAPI 
-- Game: Dungeon Stars
addappid(788640)
addappid(788641, 1, "53197a7f86b39fe2f3c30b8684ee4ba1daaa7153f498f9b217b9e4f4fdc898a8")
