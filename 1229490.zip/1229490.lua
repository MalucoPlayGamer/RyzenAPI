-- Lua provided by RyzenAPI
-- Game: Game: ULTRAKILL

-- MAIN APPLICATION
addappid(1229490)
-- Game: addappid(1229490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229491, 1, "347634f48592b176da96c10b8afe6898527aa5c218d89930f9d6e5b6d5e7c8ba")
