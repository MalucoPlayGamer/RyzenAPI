-- Lua provided by RyzenAPI
-- Game: Murdered: Soul Suspect

-- MAIN APPLICATION
addappid(233290)

-- MAIN APP DEPOTS / PACKAGES
addappid(233291, 1, "722167e02dd208f5d6ff157295d9f6da7fb9b51d84d09fafef94e2d2ccc1edc3")
addappid(233292, 1, "918961022818f0da5ec1d2eeba493af8c42381ca54f4943daf9ad5cc3ae5e422")
addappid(233293, 1, "d456316a120459a1ae00492a2e5c0627b258c9a8e148d8e7bd121b7b3f131f3f")
addappid(233294, 1, "0b8c5f1db15831dc727cce56690476ae2837453dc516cee6864a424fdf095788")
addappid(233295, 1, "3b08e6cdf3eb34a4ab11e27e7e25d10381404aa4163b78521430c77fd6143415")
addappid(233296, 1, "2e5b4f4c4e46bd615760a396fb3374ca834ec24e82b710baa65af9e80a21fc22")
addappid(233297, 1, "256ba3f891f95541ef174520fa802e4de51432a53cdd05172b1a35723e7ef029")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(289170)
