-- Lua provided by SkyAPI 
-- Game: Duck Paradox
addappid(2058150)
addappid(2058151, 1, "22d2dd63b963b9e53b8225964f15ca30e9d72ebfc61b6f15131d733cd6a4d339")
