-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2967540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967543,0,"447ad9a5a7c2efb99e028adadf18ac83c8b0d1f0bbb2a4be268b4b1bfeb01386")
