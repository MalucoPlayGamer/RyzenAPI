-- Lua provided by RyzenAPI
-- Game: addappid(843710)

-- MAIN APPLICATION
addappid(843710)

-- MAIN APP DEPOTS / PACKAGES
addappid(843711, 1, "06de6ff854158ed9b882fbdcf57e2fd6ae24570baad81c13e1ceea6655885e90")
