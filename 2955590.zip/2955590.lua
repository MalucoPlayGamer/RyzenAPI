-- Lua provided by RyzenAPI
-- Game: addappid(2955590)

-- MAIN APPLICATION
addappid(2955590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2955591, 1, "408d08c9788da9c2abeff9f3668ecc9a6e50bcccac6f2c1dd5f12fe2e0cd5c6d")
