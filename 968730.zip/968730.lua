-- Lua provided by RyzenAPI
-- Game: Worlds Collide

-- MAIN APPLICATION
addappid(968730)

-- MAIN APP DEPOTS / PACKAGES
addappid(968731, 1, "9c37db0b961ed11ef34edaf7cc5d5a6f15e2abffc882a784373176a30b66a3a7")
