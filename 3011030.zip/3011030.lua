-- Lua provided by RyzenAPI
-- Game: Game: NO-SKIN

-- MAIN APPLICATION
addappid(3011030)
-- Game: addappid(3011030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011031, 1, "2cdd4aa4bbc72f79697ab80f6979ed6927919eac0cad4748b2cc09d2d8d77724")
