-- Lua provided by RyzenAPI
-- Game: That Flipping Mountain

-- MAIN APPLICATION
addappid(1072750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072752,0,"89d6df7338affe6886f9814a82e050201e6dba91c2df518a10f82affab488690")

