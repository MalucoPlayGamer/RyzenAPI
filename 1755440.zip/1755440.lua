-- Lua provided by RyzenAPI
-- Game: Game: DEATHLOOP Original Game Soundtrack Selections

-- MAIN APPLICATION
addappid(1755440)
-- Game: addappid(1755440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755441, 1, "0ff98450c0ad9620dc7c7625ee22d19a97836a41034302331ee4cb5a823325b5")
