-- Lua provided by RyzenAPI 
-- Game: Arizona Sunshine® VR 2
addappid(1540210)
addappid(1540211, 1, "48e0ed3ceb7763b463a818d07f6eb097b51f0b65901e178875dbe62e1f00b546")
