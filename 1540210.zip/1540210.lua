-- Lua provided by RyzenAPI
-- Game: Arizona Sunshine® VR 2

-- MAIN APPLICATION
addappid(2649010) -- Arizona Sunshine VR 2 - Biker Bark Vest
addappid(2649020) -- Arizona Sunshine VR 2 - Worker Watch
addappid(2649030) -- Arizona Sunshine VR 2 - Ducky Weapon Charm
addappid(2649050) -- Arizona Sunshine VR 2 - Undead Buddy Skin
addappid(2649060) -- Arizona Sunshine VR 2 - Freddy Flesh Hands Skin
addappid(2649070) -- Arizona Sunshine VR 2 - Doggy Weapon Charm

-- MAIN APP DEPOTS / PACKAGES
addappid(1540210, 1, "85ff2087b7b8694fa22c76d6a65fcb5883750dd757f891a904e3e68dda9c5185") -- Arizona Sunshine® VR 2
addappid(1540211, 1, "48e0ed3ceb7763b463a818d07f6eb097b51f0b65901e178875dbe62e1f00b546") -- Depot 1540211
addappid(1540212, 1, "a6a3781040157eeed4116fbb9f50796e8c7ccf15544373ed0684e3e4cb6bd2ed") -- Depot 1540212

