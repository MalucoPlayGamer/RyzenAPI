-- Lua provided by RyzenAPI
-- Game: Arizona Sunshine® VR 2

-- MAIN APPLICATION
addappid(1540210)
-- Game: addappid(1540210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540211, 1, "48e0ed3ceb7763b463a818d07f6eb097b51f0b65901e178875dbe62e1f00b546")
