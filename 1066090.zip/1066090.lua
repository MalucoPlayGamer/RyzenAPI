-- Lua provided by RyzenAPI
-- Game: 守护未来 GUARD THE FUTURE

-- MAIN APPLICATION
addappid(1066090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066091, 1, "ae5a882dc55e1aebed2cc3e99255e9df3f5b9e20de20182cd8f6be97a9bb6249")
