-- Lua provided by RyzenAPI
-- Game: Highland Warriors

-- MAIN APPLICATION
addappid(446460)

-- MAIN APP DEPOTS / PACKAGES
addappid(446461, 1, "03340cb308ab55a178e1b0634bd7c26972fa065d6f193330875c9c43bf300c2c")
addappid(446462, 1, "d7e3973c60e9880b25707be04369dc0fcbd0700d3e4c80c5818331d463baad0c")
addappid(446463, 1, "f8918b016965d8df108298895a5abedb9d7e8d64053bbb32baba4f4fab038aa3")

