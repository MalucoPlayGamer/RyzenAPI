-- Lua provided by RyzenAPI 
-- Game: Godless grove
addappid(1984000)
addappid(1984001, 1, "da5a3699539d6e367fdf74ae3b2696e931f9c4d1614634f7e5493ad7898b8c4c")
