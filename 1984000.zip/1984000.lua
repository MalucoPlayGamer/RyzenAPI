-- Lua provided by RyzenAPI
-- Game: Godless grove

-- MAIN APPLICATION
addappid(1984000)
-- Game: addappid(1984000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984001, 1, "da5a3699539d6e367fdf74ae3b2696e931f9c4d1614634f7e5493ad7898b8c4c")
