-- Lua provided by RyzenAPI
-- Game: Game: Shrink Rooms

-- MAIN APPLICATION
addappid(3409430)
-- Game: addappid(3409430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3409431, 1, "c494d6f65215b469585359c787bd64298370697caba7c866ddddebe916e218d3")
