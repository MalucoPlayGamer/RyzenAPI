-- Lua provided by RyzenAPI
-- Game: Game: EBOLA 3

-- MAIN APPLICATION
addappid(1547860)
-- Game: addappid(1547860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547861, 1, "ad0ebbb5aff9844ab24765057734a545b0d65016903e4043612d4e3d94cdf551")
