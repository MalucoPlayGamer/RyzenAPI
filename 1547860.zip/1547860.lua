-- Lua provided by RyzenAPI 
-- Game: EBOLA 3
addappid(1547860)
addappid(1547861, 1, "ad0ebbb5aff9844ab24765057734a545b0d65016903e4043612d4e3d94cdf551")
