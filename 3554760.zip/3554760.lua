-- Lua provided by RyzenAPI
-- Game: Mahjong 16 TW

-- MAIN APPLICATION
addappid(3554760)
-- Game: addappid(3554760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3554761, 1, "26caf89c38a771f0bea40f5a43860622300ee95c65602367b665ba4f4f9bfd24")
