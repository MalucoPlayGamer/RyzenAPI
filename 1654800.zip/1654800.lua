-- Lua provided by RyzenAPI
-- Game: addappid(1654800)

-- MAIN APPLICATION
addappid(1654800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654801, 1, "32d1088df67601dc223f2c55a63661d1400e4638bce7c9a8d6b17c97da1a80aa")
