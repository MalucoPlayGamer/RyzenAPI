-- Lua provided by RyzenAPI
-- Game: addappid(3092090)

-- MAIN APPLICATION
addappid(3092090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092091, 1, "ed2f104cad70975c23dcb277257ee91953c7c54b860d288238ccb51b8d1a427a")
