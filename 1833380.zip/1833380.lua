-- Lua provided by RyzenAPI
-- Game: Game: Izmir: An Independence Simulator

-- MAIN APPLICATION
addappid(1833380)
-- Game: addappid(1833380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833381, 1, "bf985d073c3a11027a830dbe8f2d84b14dd430bafe44a9b16dedacec253fee43")
