-- Lua provided by RyzenAPI
-- Game: The World is Your Weapon

-- MAIN APPLICATION
addappid(1056490)
-- Game: addappid(1056490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056491, 1, "79a430dddd602e9fd9abab744fb1a608df0e55634af743921cc5c218908e45be")
