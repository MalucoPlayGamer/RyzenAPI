-- Lua provided by RyzenAPI
-- Game: Snow Ash

-- MAIN APPLICATION
addappid(3367030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3367031, 1, "dc4dcc405752ceb49075137ababb1ea34307311fddd7e6ccef8032bb11e39db8")

