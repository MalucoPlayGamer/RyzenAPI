-- Lua provided by RyzenAPI
-- Game: Super Blowfish Castle

-- MAIN APPLICATION
addappid(2429460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429461,0,"ad2ed0a5fa7f5c3db35ab1e4e679d843097355726773121de2c6cca748fc2041")

