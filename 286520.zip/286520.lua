-- Lua provided by RyzenAPI
-- Game: Viking Brothers

-- MAIN APPLICATION
addappid(286520)

-- MAIN APP DEPOTS / PACKAGES
addappid(286521, 1, "7eef3a87f818ae4360afd4478ee246e1b807d38c53987f0fd532b203e580755b")
addappid(286529, 1, "3de5fcad3fb4741ba88526df5729c738c3db2152f367a890e544532a74cfaca4")
