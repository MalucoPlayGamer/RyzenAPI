-- Lua provided by SkyAPI 
-- Game: ADVANCED V.G. Saturn Tribute
addappid(3500510)
addappid(3500511, 1, "46de31d1022845616d1e0c41d42aa4c4dc9a703a962f3b91a61b0c780c0fed01")
