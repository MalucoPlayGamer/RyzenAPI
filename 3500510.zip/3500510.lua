-- Lua provided by RyzenAPI
-- Game: ADVANCED V.G. Saturn Tribute

-- MAIN APPLICATION
addappid(3500510)
addappid(3513780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3500511, 1, "46de31d1022845616d1e0c41d42aa4c4dc9a703a962f3b91a61b0c780c0fed01")

