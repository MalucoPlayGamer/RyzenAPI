-- Lua provided by RyzenAPI
-- Game: ADVANCED V.G. Saturn Tribute

-- MAIN APPLICATION
addappid(3500510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3500511, 1, "46de31d1022845616d1e0c41d42aa4c4dc9a703a962f3b91a61b0c780c0fed01")

