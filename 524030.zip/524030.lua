-- Lua provided by RyzenAPI
-- Game: addappid(524030)

-- MAIN APPLICATION
addappid(524030)

-- MAIN APP DEPOTS / PACKAGES
addappid(524031, 1, "665ea566c032ca9601a450075ddfbeb9b26aa273435520d13215277c9efb5b8c")
