-- Lua provided by RyzenAPI
-- Game: Circuit Breakers

-- MAIN APPLICATION
addappid(390870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(390871, 1, "ce6e25927244729e4378a1b53bb9ff692cf7eda6319cd46c7e833776e1009548")
addappid(390872, 1, "ff553dcd6665db1366b2bd8d0899f06e53d44327925a23078f16c25c915fc652")
addappid(390873, 1, "b383078577ba956a4e0aeca4b88f5d53a50cb1229cb021adf63741e06313f7b0")
