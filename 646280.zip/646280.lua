-- Lua provided by SkyAPI 
-- Game: AppID 646280
addappid(646280)
addappid(646281, 1, "a0d6debeb5d18e137bd560700ed6ade8c821eb8b56e688c93d7a10a322dacb60")
