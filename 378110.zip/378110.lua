-- Lua provided by RyzenAPI
-- Game: Game: Hack RUN

-- MAIN APPLICATION
addappid(378110)
-- Game: addappid(378110)

-- MAIN APP DEPOTS / PACKAGES
addappid(378111, 1, "3588da46b076d143e0a7e3e83f6b4943d8c45645a1308e5205a3285709740ef4")
