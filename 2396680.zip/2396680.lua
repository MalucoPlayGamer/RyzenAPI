-- Lua provided by RyzenAPI
-- Game: Game: Madness Chambers

-- MAIN APPLICATION
addappid(2396680)
-- Game: addappid(2396680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396681, 1, "5176db4ff5537998bab88d211acc229e0238a52db18bae3bc63611c938701a37")
