-- Lua provided by SkyAPI 
-- Game: Letifer
addappid(2294640)
addappid(2294641, 1, "8fd2c12c5ee0accec3dd212a1bb99e08ebc21c4830aafa620243202e4d75e1b1")
