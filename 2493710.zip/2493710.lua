-- Lua provided by RyzenAPI
-- Game: Hop Step Sing! Shikiri Shiishiba - By My Side

-- MAIN APPLICATION
addappid(2493710)
-- Game: addappid(2493710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493711, 1, "762694f6d5bc43ceb1ab539ed1f7afd947b2650ac1821fc68350fa83b7facf1f")
