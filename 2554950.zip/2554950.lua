-- Lua provided by RyzenAPI
-- Game: Raioh

-- MAIN APPLICATION
addappid(2554950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2554951, 1, "acaf3f526c51a91f2300d01d7be80eebd11afed4fcbf9de55459d4a7b69802db")
