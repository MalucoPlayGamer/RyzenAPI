-- Lua provided by RyzenAPI
-- Game: Bureau of Contacts

-- MAIN APPLICATION
addappid(2840210)
-- Game: addappid(2840210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2840211, 1, "9ae67112621aae9c775cc652ad9a6942a1d3e0119f665a420a14aea90f60fbb4")
