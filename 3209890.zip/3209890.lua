-- Lua provided by RyzenAPI
-- Game: Game: AppID 3209890

-- MAIN APPLICATION
addappid(3209890)
-- Game: addappid(3209890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209891, 1, "318312d3ea275a55fb979c252c8c1eb0708e51077c5dc22585d490cc8ea67705")
