-- Lua provided by RyzenAPI
-- Game: Responding

-- MAIN APPLICATION
addappid(2658040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2658041,0,"4436683e19267018195eec316344c8a056bdb2a83e739cb1488cdc3ef7caeafd")

