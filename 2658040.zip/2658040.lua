-- Lua provided by RyzenAPI
-- Game: Responding

-- MAIN APPLICATION
addappid(2658040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658041,0,"4436683e19267018195eec316344c8a056bdb2a83e739cb1488cdc3ef7caeafd")

