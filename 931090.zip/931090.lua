-- Lua provided by RyzenAPI
-- Game: Slither Link

-- MAIN APPLICATION
addappid(931090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(931091, 1, "c2d5a531b5305bb897951e9de2bb9bc88a4fce70dace3cb4dc0d15b94e896fb0")

