-- Lua provided by RyzenAPI
-- Game: 931090

-- MAIN APPLICATION
addappid(931090)
-- Game: addappid(931090)

-- MAIN APP DEPOTS / PACKAGES
addappid(931091, 1, "c2d5a531b5305bb897951e9de2bb9bc88a4fce70dace3cb4dc0d15b94e896fb0")
