-- Lua provided by RyzenAPI
-- Game: Game: Mizuchi 白蛇心傳

-- MAIN APPLICATION
addappid(1121300)
-- Game: addappid(1121300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121301, 1, "a88565e1b9c5c4f617625d1ce15db167fe51169c0472a745e9b48fc87a1070e3")
