-- 2859970's Lua and Manifest Created by Hubcap Manifest
-- Omen
-- Created: August 12, 2026 at 00:02:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2859970, 1, "8d80b092e1ef215635d325bc8f81521629c6dce79b09f917ed0ae1a8b20c9117") -- Omen
-- MAIN APP DEPOTS
addappid(2859971, 1, "13d8cff7ae09c8856b64cebf77fb1063be7185afd52ac29982e953921f65636f") -- Depot 2859971
setManifestid(2859971, "783701611536656854", 5335668598)