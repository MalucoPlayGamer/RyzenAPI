-- Lua provided by RyzenAPI
-- Game: 18岁清纯少萝

-- MAIN APPLICATION
addappid(3399430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3399432,0,"e51d57dac2216d0ab0ffc40f1a05fd55fd9c4aff3ee46b577c5793c6bb723d8b")
