-- Lua provided by RyzenAPI
-- Game: addappid(2868860)

-- MAIN APPLICATION
addappid(2868860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868861, 1, "184987f74fbd9ce7b4460cf727ca7d3eec737adec7aab9dc0e7e438a0a01841b")
