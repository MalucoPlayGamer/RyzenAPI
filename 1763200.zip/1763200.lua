-- Lua provided by RyzenAPI 
-- Game: AppID 1763200
addappid(1763200)
addappid(1763201, 1, "137fd997c8165a1a117af1a66f9d40f3052bc0d44c5a3bb2d8c35ef6629e26b7")
