-- Lua provided by RyzenAPI
-- Game: addappid(2877700)

-- MAIN APPLICATION
addappid(2877700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877701, 1, "f026c273fa659492ccdd4ded0343bbbade35f9eb0888d87629abf4afd8935e06")
