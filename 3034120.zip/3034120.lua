-- Lua provided by RyzenAPI
-- Game: I am Sorry

-- MAIN APPLICATION
addappid(3034120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034121, 1, "0c9ddfba09a4cd694dff06030a2350533085bb80307de27b29c23504f09c13ad")

