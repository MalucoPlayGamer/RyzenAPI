-- Lua provided by RyzenAPI
-- Game: Last Guest

-- MAIN APPLICATION
addappid(3732190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3732191, 1, "736c8ca12b2ea7547c93293dd11e3ba673ba3a49b5052787df317298a4058795")

