-- Lua provided by RyzenAPI
-- Game: 1210930

-- MAIN APPLICATION
addappid(1210930)
addappid(1885320)
-- Game: addappid(1210930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210931, 1, "8283cf7c744bf1c30e6564c76dc65597ab8f0faa18840cf9692ce838c81d05ff")
