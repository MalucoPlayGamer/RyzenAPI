-- Lua provided by RyzenAPI
-- Game: Tomokin Monsters

-- MAIN APPLICATION
addappid(3655520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655521, 1, "71eaa1d83c9e96bfb860e1af65b91e61b88f017028f4227f35cca20e2babf92d")
