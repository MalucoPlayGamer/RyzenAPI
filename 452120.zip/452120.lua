-- Lua provided by RyzenAPI
-- Game: addappid(452120)

-- MAIN APPLICATION
addappid(452120)

-- MAIN APP DEPOTS / PACKAGES
addappid(452121, 1, "a0831b0bd96fe62717963e2fe5ad02b8ba1a57ff349a19b9576213ca4d890d27")
