-- Lua provided by RyzenAPI
-- Game: The Diary Demo

-- MAIN APPLICATION
addappid(2439680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2439681, 1, "9c03f3e8adfdbd0a048a72c6abeeeff750f9e3759f01c9e2b890eb268ccbe329")

