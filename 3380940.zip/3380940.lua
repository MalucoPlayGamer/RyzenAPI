-- Lua provided by RyzenAPI
-- Game: Paw & Hop Jigsaw Quest

-- MAIN APPLICATION
addappid(3380940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380941, 1, "0d4db173fc4dbca2d183de7ae96b1b89ae34607e0a25b365c134a61f2c89042c")
addappid(3385630, 0, "c9821003ac07a5aa4dd378ddb386ba737d89beafb34fa227cd55596675af6bc0")
addappid(3390400, 0, "3efc71ef967a2469326b94ab80f97c4a243ab1e95ef4620887188769fed47fea")
addappid(3392540, 0, "6104d3a4c162cfdf913a30b3b5198b6fdb2e401fc1b32c29ab093bab7906e28d")
