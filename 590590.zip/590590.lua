-- Lua provided by RyzenAPI
-- Game: Remnants of Naezith

-- MAIN APPLICATION
addappid(590590)

-- MAIN APP DEPOTS / PACKAGES
addappid(590591, 1, "dcac1edc5c2a1f4aa66b241685f7feb50ecc31f9cbc4c5482bc223b2118ddf7f")
addappid(590592, 1, "00c9f817436b1179f55aac71c9d941d4c5f46de8ed5e8efebbe360eee7ee3b7d")
addappid(590593, 1, "d92df91c7aadcf76fcf3bd786612bc71202a58b215e3e007300c3f044e71552a")
addappid(590594, 1, "5cc0232019f451aa6ad6a959c1c386d5065b7534c65f555cba55483b199d14fb")
addappid(787500, 0, "7912dd389092a5b4110df0503615281748013f88b5eabd4ef39ecf4f59e98349")
