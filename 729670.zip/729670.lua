-- Lua provided by RyzenAPI
-- Game: 729670

-- MAIN APPLICATION
addappid(729670)
-- Game: addappid(729670)

-- MAIN APP DEPOTS / PACKAGES
addappid(729671, 1, "1112575e30a2350aa679bb2a6ec3198f748098bb01b31c8ba085c6ebc357b567")
addappid(729672, 1, "ddbdc93965243424503c905af417aac2b2e23a7e0fa7d7ccddbac742d8182d08")
addappid(729673, 1, "c3adebb1d5210d406ca8d72b9ae59e73cbb907a6d35a31be96efe03fe96cd537")
addappid(729674, 1, "bd33ba97deecc678ede0cbb276a8c5c6ff37767a0def9182a01d03b2faacfa7d")
