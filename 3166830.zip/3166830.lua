-- Lua provided by RyzenAPI
-- Game: Elements and Build Demo

-- MAIN APPLICATION
addappid(3166830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3166831, 1, "fb616a140bc1889a11f10448c65cbabe9624297e84ae4de921656618803f4c30")

