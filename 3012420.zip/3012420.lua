-- Lua provided by RyzenAPI
-- Game: addappid(3012420)

-- MAIN APPLICATION
addappid(3012420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012421, 1, "843b7d0a655641439b1cf2b9ec284b87bebebf8a621e8f4e48b636c582130831")
