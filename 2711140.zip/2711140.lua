-- Lua provided by SkyAPI 
-- Game: AppID 2711140
addappid(2711140)
addappid(2711141, 1, "ee3c30d2b2c73440fb2878a5d7ed7d0816bab74e6aaebc5336d992265dc79272")
