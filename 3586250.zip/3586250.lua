-- Lua provided by RyzenAPI
-- Game: Game: Empire Game

-- MAIN APPLICATION
addappid(3586250)
-- Game: addappid(3586250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3586251, 1, "cd3ac0795fb7457dbb247c4a160b052e397ff42d600d432ff5768f622b1ce71e")
