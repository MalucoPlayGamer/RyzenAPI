-- Lua provided by RyzenAPI
-- Game: Game: AppID 1012610

-- MAIN APPLICATION
addappid(1012610)
-- Game: addappid(1012610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012611, 1, "62bacdb835c60413b463552168a7a438e1a1617b7b0a39be67474ebfbee33737")
addappid(1012612, 1, "f3bde19f45bf17bcdb4cd3cefefb950668f8204b6caa803c796e48bcb3c33cdc")
addappid(1012613, 1, "815c917eb9212d9466d0996f09e9fa6570213ce112b3f3ea929cc31b811c7e44")
