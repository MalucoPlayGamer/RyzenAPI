-- Lua provided by RyzenAPI
-- Game: 581690

-- MAIN APPLICATION
addappid(581690)
-- Game: addappid(581690)

-- MAIN APP DEPOTS / PACKAGES
addappid(581691, 1, "c47e3718727d710932cc51a7082ef32b2930a5bf17f0b10ff7488efe9aa32289")
