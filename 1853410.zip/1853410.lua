-- Lua provided by RyzenAPI
-- Game: Game: The Shape of Things

-- MAIN APPLICATION
addappid(1853410)
-- Game: addappid(1853410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1853411, 1, "0ca6cc4b1be32d2c7e65e901bb4740938fc541552500df78e06fdc45f80c947d")
addappid(2506380, 0, "7c24f43f2bde35e8fbb3b855268ddfa0385750aae3d8454ace7b18cec3af10ab")
addappid(3155220, 0, "8952e6c00d4e96b5353a01b863caded5b7726abaf76443db0d485fc4062e1bb7")
