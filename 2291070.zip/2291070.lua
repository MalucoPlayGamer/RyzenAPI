-- Lua provided by RyzenAPI 
-- Game: AppID 2291070
addappid(2291070)
addappid(2291071, 1, "920053d76412ba6479583567884b4d73f4399e00343efc39d3582765c09b620c")
