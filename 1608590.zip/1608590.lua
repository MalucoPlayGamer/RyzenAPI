-- Lua provided by RyzenAPI
-- Game: Thyria

-- MAIN APPLICATION
addappid(1608590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608591, 1, "0c40ebd0998f1d8edde33827a76b689a4ca0d3dd931a109cff68f0cc0bbc0d6f")
