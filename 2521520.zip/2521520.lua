-- Lua provided by RyzenAPI
-- Game: Game: ELDRIMAR Demo

-- MAIN APPLICATION
addappid(2521520)
-- Game: addappid(2521520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521521, 1, "557c90487accd6d6b1e2b092f2343a5d7906708e7846a86d2750d7d3968f1e51")
