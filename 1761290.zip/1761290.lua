-- Lua provided by RyzenAPI
-- Game: Japanese Rail Sim: Journey to Kyoto

-- MAIN APPLICATION
addappid(1761290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1761291, 1, "88626a0ec604a408038057d8fe951a03e7bb8a3a5eef96f82b33b1f024575b46")

