-- Lua provided by RyzenAPI
-- Game: Japanese Rail Sim: Journey to Kyoto

-- MAIN APPLICATION
addappid(1761290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761291, 1, "88626a0ec604a408038057d8fe951a03e7bb8a3a5eef96f82b33b1f024575b46")

