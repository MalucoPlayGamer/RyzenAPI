-- Lua provided by RyzenAPI
-- Game: AppID 392110

-- MAIN APPLICATION
addappid(392110)

-- MAIN APP DEPOTS / PACKAGES
addappid(392111, 1, "16d757821d13aead2320ed2e117ccbafd3247021f1a37a26aa7d809a0269db13")
addappid(392112, 1, "1ee4c60af3651c69bb6d2af38fbfd75c07f2300d218c86c5a41aed0b817ec41a")
addappid(392113, 1, "83a04a5e223f6a99cbefe4dbde28f3683da484f1c3894bb470e9a511a2f4a5e7")
addappid(392114, 1, "f0616f403424c078f030cb75ef7c6aae74d5d07ba209e6135ea27ec4116d060d")
addappid(392115, 1, "f26def67cf8f9b04ffd81a5f836d4a992565ea1f53f6c9d62c909445e091efcd")
addappid(392116, 1, "7c474c3ad672919f3702212a0447a0f75023d4b6db064c9572c823ba0505d966")
addappid(392117, 1, "7ea1654bce9d5bd6064f54d7292ad7c2f77eafe1b7c38e74c95d9864c1e962fa")
addappid(392118, 1, "a4ac343831cecbaa5c30b4b8913be2c8dc46aebae005cab3e887486764965d70")
addappid(392119, 1, "098b6ef1885840f10fecc71d5438a8c16d1f22d92fd4fe0361628982e5791e90")
addappid(527501, 0, "7981304a45f4658b1ef86b600df8d521645fc94f7b88242a77b3611583fdd861")
addappid(527502, 0, "163c53a929130424b8fdd32bfad5fc067b374cf16ca044a0724cadfe963677c7")
addappid(527503, 0, "c90184ff39fb221969f9a2e164db5aca5d24fdf554e1f5c7eb79f950cc873daf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(527500)
addappid(539420)
addappid(539430)
addappid(733140)
addappid(751830)
addappid(751831)
addappid(751832)
addappid(751840)
addappid(763330)
addappid(785060)
addappid(806780)
addappid(806920)
addappid(813410)
addappid(813420)
addappid(841000)
addappid(921010)
addappid(949080)
addappid(949081)
addappid(988440)
addappid(1054280)
addappid(1128540)
addappid(1521000)
addappid(1523730)
