-- Lua provided by RyzenAPI
-- Game: Mobile Store Simulator

-- MAIN APPLICATION
addappid(2567490)
-- Game: addappid(2567490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567491, 1, "5449dceb75b170e0eb96726b968a96a07c67b7d8fb9db48a9d638646928ddffa")
