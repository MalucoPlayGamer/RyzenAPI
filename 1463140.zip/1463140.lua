-- Lua provided by RyzenAPI
-- Game: Destructo

-- MAIN APPLICATION
addappid(1463140)
-- Game: addappid(1463140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463141, 1, "c348b50c180c7282e4ab29b81bfb18b806c0df49e6647551f3362547b7ed06fe")
