-- Lua provided by RyzenAPI
-- Game: AppID 724450

-- MAIN APPLICATION
addappid(724450)
-- Game: addappid(724450)

-- MAIN APP DEPOTS / PACKAGES
addappid(724451, 1, "352b6b935fb9a18c12be7ab91fe9c1883bae44b47afc63cff46b05371ad115db")
