-- Lua provided by RyzenAPI
-- Game: addappid(1878090)

-- MAIN APPLICATION
addappid(1878090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878091, 1, "6c1a73b92b3a027538434a7d4a10035dc02f7499066d26ebd1a74058ea6d5bee")
