-- Lua provided by RyzenAPI
-- Game: Game: OMNIMUS

-- MAIN APPLICATION
addappid(1108640)
addappid(1187100)
-- Game: addappid(1108640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1108641, 1, "b47f215374ac6fccb0b0dffc5d368d669451860c9b2a24a839cd60eea0ada963")
addappid(1108642, 1, "52dbf770bda055c27a0b9f0eb166d66abb0c89af9af6dfe75e3ad09965b0f7a9")
