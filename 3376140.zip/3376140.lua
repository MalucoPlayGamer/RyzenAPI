-- Lua provided by RyzenAPI
-- Game: 武侠幸存者

-- MAIN APPLICATION
addappid(3376140)
-- Game: addappid(3376140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376141, 1, "8ba4c6c4d5135961f7afd4d78fda96bad2306363945c8c4388c2edb15f3236aa")
