-- Lua provided by SkyAPI 
-- Game: I Am Motherfucker
addappid(3381190)
addappid(3381191, 1, "2ee7f8fea3255e45451d02af15ce3f8059e09b13a90646c45691a20cefff9dc5")
