-- Lua provided by RyzenAPI
-- Game: Game: I Am Motherfucker

-- MAIN APPLICATION
addappid(3381190)
-- Game: addappid(3381190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381191, 1, "2ee7f8fea3255e45451d02af15ce3f8059e09b13a90646c45691a20cefff9dc5")
