-- Lua provided by RyzenAPI
-- Game: The North Pole

-- MAIN APPLICATION
addappid(1201880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201881, 1, "1f1c939e50fb61ca95e1b5dec6048c96c0838258f0c5d30e51afba17ea8621dd")

