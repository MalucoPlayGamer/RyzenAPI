-- Lua provided by RyzenAPI
-- Game: addappid(1229020)

-- MAIN APPLICATION
addappid(1229020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229021, 1, "a9a30b5ec87ce301eae5c1da407c049ea4ae000842936b6dfbc713b88ab123f0")
