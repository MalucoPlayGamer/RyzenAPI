-- Lua provided by RyzenAPI
-- Game: Weather Lord: Legendary Hero Collector's Edition

-- MAIN APPLICATION
addappid(500220)

-- MAIN APP DEPOTS / PACKAGES
addappid(500221, 1, "d54e94909f26556aa87c9d15d0ea12949fc6441bf5d1e3402bd68c2355a0c53a")
