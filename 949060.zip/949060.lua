-- Lua provided by RyzenAPI
-- Game: AppID 949060

-- MAIN APPLICATION
addappid(949060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(949061, 1, "b79ea68171323db3fc8162c722de0ed6b04532eeae16596083c62e63de1b17c6")
addappid(1087900, 0, "3da7785bc3298e829a39b3eca055a170ea7e48f6d453171b57dc79b961b5831d")

