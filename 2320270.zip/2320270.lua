-- Lua provided by RyzenAPI 
-- Game: I am The Exorcist
addappid(2320270)
addappid(2320271, 1, "5d7d4d581af97640c2bfcccc54e825f51b11502ccb34d62daace32dea37f13d8")
addappid(2324720, 0, "ab5ff41aa2959290c69697a536d07053713debb34bd03d22dd1e75dc2040fe25")
addappid(2335440)
