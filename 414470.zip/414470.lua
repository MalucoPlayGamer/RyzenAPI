-- Lua provided by RyzenAPI
-- Game: AppID 414470

-- MAIN APPLICATION
addappid(414470)

-- MAIN APP DEPOTS / PACKAGES
addappid(414471, 1, "a4e64bc4240842ff2d3ab424aa687d41597ccf1871ad9a9c1085b87fab7dbc6a")

