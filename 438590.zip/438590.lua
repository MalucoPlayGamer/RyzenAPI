-- Lua provided by RyzenAPI
-- Game: AppID 438590

-- MAIN APPLICATION
addappid(438590)

-- MAIN APP DEPOTS / PACKAGES
addappid(438591, 1, "03a047fd9b1125bf8a9d09ce88b986e0c4f5f9b2494ff23ec069d65b1946aee4")

