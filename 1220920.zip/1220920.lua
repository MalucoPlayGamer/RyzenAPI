-- Lua provided by RyzenAPI
-- Game: ERO Girl Painter

-- MAIN APPLICATION
addappid(1220920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220921,0,"aefcde1359222375b7b1de32313a747142ab568caed49b42db15e45ab3b86338")

