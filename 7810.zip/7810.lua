-- Lua provided by RyzenAPI
-- Game: Top Spin 2

-- MAIN APPLICATION
addappid(7810)
-- Game: addappid(7810)

-- MAIN APP DEPOTS / PACKAGES
addappid(7811, 1, "b416ac68ead9ff198f6636833adc914ef81be6577c6e2f9a99f2aff2c1ea96bd")
addappid(7812, 1, "74b80a603a7e33bc41b55003b057064a1da2841f4dbef1a559d771058a66276e")
addappid(7813, 1, "54e61ad62e095f2c5202b1fd8c19a34c5902b352f8a8292250d27d22cf07c597")
