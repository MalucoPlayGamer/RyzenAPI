-- Lua provided by RyzenAPI
-- Game: 1495000

-- MAIN APPLICATION
addappid(1495000)
-- Game: addappid(1495000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495001, 1, "70f7a3954301f149991fc1f956b2200b7861cf6f0f14ab42ba80c59ffcb9de8c")
