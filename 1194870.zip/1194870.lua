-- Lua provided by RyzenAPI
-- Game: AppID 1194870

-- MAIN APPLICATION
addappid(1194870)
-- Game: addappid(1194870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194871, 1, "cedcfd6640286f9395acbf574dbd9ae9308f282964fbc157b5f1d7cca23da73b")
addappid(1194872, 1, "98d7096ce7f5400117be03ea765e40ba306159c0af1471cfa55eb3488de52c0f")
