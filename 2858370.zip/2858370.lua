-- Lua provided by RyzenAPI
-- Game: Voxel Project VR

-- MAIN APPLICATION
addappid(2858370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2858371, 1, "0ba2a43eddd2720ce19d754de3ec5aedd2f850bb29ad1d61ffa4cedde17e0258")

