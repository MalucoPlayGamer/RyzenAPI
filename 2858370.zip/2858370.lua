-- Lua provided by RyzenAPI
-- Game: Voxel Project VR

-- MAIN APPLICATION
addappid(2858370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858371, 1, "0ba2a43eddd2720ce19d754de3ec5aedd2f850bb29ad1d61ffa4cedde17e0258")

