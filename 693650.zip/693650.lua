-- Lua provided by RyzenAPI
-- Game: LOGistICAL: Italy

-- MAIN APPLICATION
addappid(693650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(693651,0,"5c30bd885bf2a39793538294025ed44e1bf8de807cdd4ab18429da7b7e091263")

