-- Lua provided by RyzenAPI
-- Game: LOGistICAL: Italy

-- MAIN APPLICATION
addappid(693650)

-- MAIN APP DEPOTS / PACKAGES
addappid(693651,0,"5c30bd885bf2a39793538294025ed44e1bf8de807cdd4ab18429da7b7e091263")

