-- Lua provided by RyzenAPI
-- Game: Game: Apple Slash

-- MAIN APPLICATION
addappid(1127850)
-- Game: addappid(1127850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127851, 1, "8cee15981c81e0dc34aa48843306dba9fb0f8a07806c76882599652000d23996")
