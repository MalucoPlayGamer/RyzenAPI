-- Lua provided by RyzenAPI
-- Game: Pretty Girls Rivers (Shisen-Sho)

-- MAIN APPLICATION
addappid(1795770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795771, 1, "1373a36b4bb7242de322b0a18e31b5082309207a28934d877b8f7f59dcfc8234")
