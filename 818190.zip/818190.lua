-- Lua provided by RyzenAPI
-- Game: Clicker: Mining Simulator - Soundtrack

-- MAIN APPLICATION
addappid(818190)
-- Game: addappid(818190)

-- MAIN APP DEPOTS / PACKAGES
addappid(818190,0,"294123b3faa9f3b39ba4429a57d8a640d0d04d8c1f156ac8e4bed2a3d2b8b767")
