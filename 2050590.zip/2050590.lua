-- Lua provided by RyzenAPI
-- Game: Game: Fhtagn Simulator

-- MAIN APPLICATION
addappid(2050590)
-- Game: addappid(2050590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050591, 1, "3bd9c2ef117080d13272e79dfa1e7baaa5fbdf5370dcebd4316340b266099114")
