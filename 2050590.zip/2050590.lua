-- Lua provided by RyzenAPI 
-- Game: Fhtagn Simulator
addappid(2050590)
addappid(2050591, 1, "3bd9c2ef117080d13272e79dfa1e7baaa5fbdf5370dcebd4316340b266099114")
