-- Lua provided by RyzenAPI
-- Game: AppID 320590

-- MAIN APPLICATION
addappid(320590)
addappid(362641)
addappid(362642)
addappid(362643)

-- MAIN APP DEPOTS / PACKAGES
addappid(320591, 1, "a6db29ec261a3ebdc35a1c1c11ab72a951d3b244fc82da969e4a81678c49624a")
addappid(320592, 1, "e7f95f289cd8c47ec18a6d8d6b318719814fd18c4856f288a1598b3f965fe03b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(321250)
addappid(362640)
