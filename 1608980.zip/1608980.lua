-- Lua provided by RyzenAPI
-- Game: The Dream is Coming...

-- MAIN APPLICATION
addappid(1608980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608981, 1, "8f02b60a828d33edb0c961fc95f63e18beed69992a8bda1950e0f56202a630f5")

