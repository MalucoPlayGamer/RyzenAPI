-- Lua provided by RyzenAPI
-- Game: addappid(2544590)

-- MAIN APPLICATION
addappid(2544590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544591, 1, "a2a6282e724ebb6e35e21f6c300123192b0faec6d0d2118fdbe6239bceb47431")
