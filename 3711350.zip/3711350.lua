-- Lua provided by RyzenAPI
-- Game: addappid(3711350)

-- MAIN APPLICATION
addappid(3711350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3711351, 1, "c74cee12cd1a2aaf6dd1392ae0b1483ca736171ca1ba668106bb821b89f31e33")
