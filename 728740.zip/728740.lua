-- Lua provided by RyzenAPI
-- Game: Sniper Elite V2 Remastered

-- MAIN APPLICATION
addappid(728740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(728741, 1, "0185d4b4b7ce9d96d5ee1b8cd049697ec6e90bb0010290d1891b96117f57c18e")
