-- Lua provided by RyzenAPI
-- Game: AppID 728740

-- MAIN APPLICATION
addappid(728740)
-- Game: addappid(728740)

-- MAIN APP DEPOTS / PACKAGES
addappid(728741, 1, "0185d4b4b7ce9d96d5ee1b8cd049697ec6e90bb0010290d1891b96117f57c18e")
