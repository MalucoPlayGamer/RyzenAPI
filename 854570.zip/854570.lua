-- Lua provided by RyzenAPI
-- Game: Pamali: Indonesian Folklore Horror

-- MAIN APPLICATION
addappid(854570)
addappid(990931)
addappid(990932)

-- MAIN APP DEPOTS / PACKAGES
addappid(854571,0,"1239b84e7b20e78c4f6b353386a49b18a0a68e56907ac0c024d8d269fa4d3b18")
addappid(990930,0,"5d74cc23e735fad73f120b788c35d57d35a71fc71e976526fc8fc2cd0546944f")
addappid(1181680,0,"d6bb44a83235fdf50e25d7e7cd06c46da8b4b8b6e7a7ce8339789b5d306ca6ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
