-- Lua provided by RyzenAPI
-- Game: Game: AppID 854570

-- MAIN APPLICATION
addappid(854570)
-- Game: addappid(854570)

-- MAIN APP DEPOTS / PACKAGES
addappid(854571, 1, "1239b84e7b20e78c4f6b353386a49b18a0a68e56907ac0c024d8d269fa4d3b18")
addappid(990930, 0, "5d74cc23e735fad73f120b788c35d57d35a71fc71e976526fc8fc2cd0546944f")
addappid(1181680, 0, "d6bb44a83235fdf50e25d7e7cd06c46da8b4b8b6e7a7ce8339789b5d306ca6ef")
