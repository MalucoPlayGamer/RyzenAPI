-- Lua provided by RyzenAPI
-- Game: 永夜之冬

-- MAIN APPLICATION
addappid(1398030)
addappid(1968510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398031, 1, "bf5662e4c903defd908deabd1235b344bacaa4f026142db9a0b990985d56d2fa")
