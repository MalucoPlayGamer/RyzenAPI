-- Lua provided by RyzenAPI
-- Game: 東方资志疏 ~ Immortal Immanuel. (东方资志疏)

-- MAIN APPLICATION
addappid(2861740)
-- Game: addappid(2861740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2861741, 1, "4ff01022de9383e35b3e3b1a4653f26dd8bb0b1d04658bb40e8b4d86718f3a98")
