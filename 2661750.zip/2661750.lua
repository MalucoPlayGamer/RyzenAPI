-- Lua provided by RyzenAPI
-- Game: 小世界模拟器3

-- MAIN APPLICATION
addappid(2661750)
-- Game: addappid(2661750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661751, 1, "71b3f81ebe1b3511b8408005fdd3123269e68b3788a282b3a73ca98ed25a9a52")
