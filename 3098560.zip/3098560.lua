-- Lua provided by RyzenAPI
-- Game: Dice Dice Dice Demo

-- MAIN APPLICATION
addappid(3098560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3098561, 1, "f0ca750b2c7b20cd70ae9573014b7abd2cccc7743d9f6ca6b243c03b8b37b418")

