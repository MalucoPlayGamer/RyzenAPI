-- Lua provided by RyzenAPI
-- Game: 我和七个俏房客 - 心动影集

-- MAIN APPLICATION
addappid(2901510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901510,0,"2ed089623e765682785e7e5d9e383bc1e4fbf925b7c83bd8187b2eb084117660")

