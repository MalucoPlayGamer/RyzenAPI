-- Lua provided by RyzenAPI
-- Game: Distortions

-- MAIN APPLICATION
addappid(772500)
addappid(857970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(772501, 1, "9c89d5738613c56e834b824e5aa7199a243b1848c2f31a90f45f89d7e5e09911")

