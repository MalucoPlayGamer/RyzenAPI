-- Lua provided by RyzenAPI
-- Game: Distortions

-- MAIN APPLICATION
addappid(772500)
addappid(857970)

-- MAIN APP DEPOTS / PACKAGES
addappid(772501, 1, "9c89d5738613c56e834b824e5aa7199a243b1848c2f31a90f45f89d7e5e09911")

