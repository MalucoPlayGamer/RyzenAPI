-- Lua provided by RyzenAPI
-- Game: addappid(978861)

-- MAIN APPLICATION
addappid(978861)

-- MAIN APP DEPOTS / PACKAGES
addappid(978861,0,"420aa58748331d7d1ea95965ab9d059f482d78647d113edd55b9d376fa52dc69")
