-- Lua provided by RyzenAPI
-- Game: AppID 935700

-- MAIN APPLICATION
addappid(935700)
-- Game: addappid(935700)

-- MAIN APP DEPOTS / PACKAGES
addappid(935701, 1, "f568eac204097394f6921ba94d41a2d6f0e51d691434826775efed3c78b4ab60")
