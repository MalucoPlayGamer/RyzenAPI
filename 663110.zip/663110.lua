-- Lua provided by RyzenAPI
-- Game: Game: Sunrise: survival

-- MAIN APPLICATION
addappid(663110)
-- Game: addappid(663110)

-- MAIN APP DEPOTS / PACKAGES
addappid(663111, 1, "1a5b0b7424e8ad8317f5ff545adb6439fb3ec4c8cbb86ebe15e2c5a450cdfa52")
