-- Lua provided by RyzenAPI
-- Game: AppID 1021070

-- MAIN APPLICATION
addappid(1021070)
addappid(1162220)
addappid(1166870)
addappid(1166871)
addappid(1272940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021071, 1, "ac9b2868eb9877d1002ed4adb08625255e8907be5b87721bf0ec0b7300f32428")
