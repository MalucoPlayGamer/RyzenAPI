-- Lua provided by RyzenAPI
-- Game: Apex Heroines - Cherry Echo	嘤樱花

-- MAIN APPLICATION
addappid(2742420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742420,0,"3d0629f66c31d9f44eed909e455804a786c8201ae33051f6e83282154347c683")
