-- Lua provided by RyzenAPI
-- Game: 1... 2... 3... KICK IT! (Drop That Beat Like an Ugly Baby)

-- MAIN APPLICATION
addappid(15540)

-- MAIN APP DEPOTS / PACKAGES
addappid(15541, 1, "796c5f0ae8fb4ef1b2167a4e810bbe323dc34fa9d468068e6c43646877ad9f10")
addappid(98008, 0, "85084da342696d09129b68dce1667931b5720e7509bf95ac6c9cb99446def915")