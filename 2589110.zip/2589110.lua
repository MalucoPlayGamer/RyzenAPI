-- Lua provided by RyzenAPI
-- Game: Fishyphus

-- MAIN APPLICATION
addappid(2589110)
-- Game: addappid(2589110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589112,0,"6212d48ee6b577edc79122af4c7aabce7284eb84a351f9c55d2cf83c160c6730")
addappid(2589113,0,"a66b2076b0c804c1eae9cc388c0a3190244188347aef9b9ca85dab707d940c95")
