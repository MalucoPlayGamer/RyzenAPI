-- Lua provided by RyzenAPI
-- Game: AppID 942250

-- MAIN APPLICATION
addappid(942250)

-- MAIN APP DEPOTS / PACKAGES
addappid(942251, 1, "e7652845a8de36c792b2ca0680e5eaadeae286d6c1ad25be569d106f14a753b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
