-- Lua provided by RyzenAPI
-- Game: addappid(942250)

-- MAIN APPLICATION
addappid(942250)

-- MAIN APP DEPOTS / PACKAGES
addappid(942251, 1, "e7652845a8de36c792b2ca0680e5eaadeae286d6c1ad25be569d106f14a753b2")
