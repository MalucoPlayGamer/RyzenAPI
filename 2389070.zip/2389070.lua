-- Lua provided by RyzenAPI
-- Game: 2389070

-- MAIN APPLICATION
addappid(2389070)
-- Game: addappid(2389070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389070,0,"d7f2943c13d7349abda128751597daa0091887bfc630be84c3bb0d688b6e6e42")
