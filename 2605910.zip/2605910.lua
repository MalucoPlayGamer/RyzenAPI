-- Lua provided by RyzenAPI
-- Game: Mining Mechs Demo

-- MAIN APPLICATION
addappid(2605910)
-- Game: addappid(2605910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605911, 1, "d620d61efe736e93d339012b3d912b9f2d90708df2e2589972abb4deb968b854")
