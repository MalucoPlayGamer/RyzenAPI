-- Lua provided by RyzenAPI
-- Game: addappid(743410)

-- MAIN APPLICATION
addappid(743410)

-- MAIN APP DEPOTS / PACKAGES
addappid(743411, 1, "5342f558db0d8a75af8371d5902d781a61203c5ca99c565f6bd50eca7f859feb")
