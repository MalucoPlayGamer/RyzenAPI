-- Lua provided by RyzenAPI
-- Game: Snow Clearing Driving Simulator

-- MAIN APPLICATION
addappid(1155920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155921, 1, "288ae8521c2f674df9b48c0c4d30bcb247076c48d41e2501989aa96721529435")

