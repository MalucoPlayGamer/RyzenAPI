-- Lua provided by RyzenAPI
-- Game: Cryogear

-- MAIN APPLICATION
addappid(600520)

-- MAIN APP DEPOTS / PACKAGES
addappid(600521,0,"24d0e3d688aa63f12673b4ddfea5a90946f5ec8c733aeaea0ce01d70a9b4139a")

