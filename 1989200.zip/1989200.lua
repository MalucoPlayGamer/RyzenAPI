-- Lua provided by RyzenAPI
-- Game: 1989200

-- MAIN APPLICATION
addappid(1989200)
-- Game: addappid(1989200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989201, 1, "cd976d224d31036be386443ee1ccdadbf12b213deead3ff9e00ba37ebf3f718f")
