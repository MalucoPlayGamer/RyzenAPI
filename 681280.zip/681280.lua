-- Lua provided by RyzenAPI
-- Game: Game: AppID 681280

-- MAIN APPLICATION
addappid(681280)
-- Game: addappid(681280)

-- MAIN APP DEPOTS / PACKAGES
addappid(681281, 1, "593d7997a09340553e4e44320a5325875cdecb7056ce3d07639d1535c8e31e43")
