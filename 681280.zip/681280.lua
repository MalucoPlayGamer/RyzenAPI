-- Lua provided by RyzenAPI
-- Game: AppID 681280

-- MAIN APPLICATION
addappid(681280)

-- MAIN APP DEPOTS / PACKAGES
addappid(681281, 1, "593d7997a09340553e4e44320a5325875cdecb7056ce3d07639d1535c8e31e43")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
