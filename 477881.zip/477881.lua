-- Lua provided by RyzenAPI
-- Game: 477881

-- MAIN APPLICATION
addappid(477881)
-- Game: addappid(477881)

-- MAIN APP DEPOTS / PACKAGES
addappid(477881,0,"c88c1b69618a608a9339c7b80c2e00badbeb60c7703cc7b3c2c33cad2a3b87ce")
