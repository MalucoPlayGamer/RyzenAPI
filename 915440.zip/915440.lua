-- Lua provided by RyzenAPI
-- Game: Game: Fireflies

-- MAIN APPLICATION
addappid(915440)
-- Game: addappid(915440)

-- MAIN APP DEPOTS / PACKAGES
addappid(915441, 1, "33f8e697951f8dbc6042b28ab1ac524b01717778358f2e2ada4e5433d6af0f98")
