-- Lua provided by SkyAPI 
-- Game: Fireflies
addappid(915440)
addappid(915441, 1, "33f8e697951f8dbc6042b28ab1ac524b01717778358f2e2ada4e5433d6af0f98")
