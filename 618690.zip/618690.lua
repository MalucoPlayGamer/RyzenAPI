-- Lua provided by RyzenAPI 
-- Game: AppID 618690
addappid(618690)
addappid(618691, 1, "0af469f32679e76453e30a86e168b8120747d7297aec6e6bc1e6ec2a3d070fb8")
addappid(636530, 0, "a5967ab21d507974b2cf3dacf6c31e4bca1b7fa4ff0b14b96362e02337b51c7a")
