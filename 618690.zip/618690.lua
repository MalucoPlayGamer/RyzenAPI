-- Lua provided by RyzenAPI
-- Game: AppID 618690

-- MAIN APPLICATION
addappid(618690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(618691, 1, "0af469f32679e76453e30a86e168b8120747d7297aec6e6bc1e6ec2a3d070fb8")
addappid(636530, 0, "a5967ab21d507974b2cf3dacf6c31e4bca1b7fa4ff0b14b96362e02337b51c7a")

