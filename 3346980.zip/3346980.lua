-- Lua provided by RyzenAPI 
-- Game: AppID 3346980
addappid(3346980)
addappid(3346981, 1, "c000a0e64fe95aa1164d4b128f802ed82e896be0c57dd1e00c918b6f41342e59")
