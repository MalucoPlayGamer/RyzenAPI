-- Lua provided by RyzenAPI
-- Game: Game: AppID 3346980

-- MAIN APPLICATION
addappid(3346980)
-- Game: addappid(3346980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3346981, 1, "c000a0e64fe95aa1164d4b128f802ed82e896be0c57dd1e00c918b6f41342e59")
