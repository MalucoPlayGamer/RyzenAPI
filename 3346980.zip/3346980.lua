-- Lua provided by RyzenAPI
-- Game: AppID 3346980

-- MAIN APPLICATION
addappid(3346980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3346981, 1, "c000a0e64fe95aa1164d4b128f802ed82e896be0c57dd1e00c918b6f41342e59")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
