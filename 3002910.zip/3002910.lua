-- Lua provided by RyzenAPI
-- Game: Game: 奴隶商人

-- MAIN APPLICATION
addappid(3002910)
-- Game: addappid(3002910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002911, 1, "059aa5e94a7b3736297360a0f3e7157d5c920a3533bd87d23d87d086a616ca00")
