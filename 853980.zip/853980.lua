-- Lua provided by RyzenAPI
-- Game: Splash

-- MAIN APPLICATION
addappid(853980)

-- MAIN APP DEPOTS / PACKAGES
addappid(853981, 1, "8d9bebdbcf6e1f56405ce8505f5d3ed958ba696a75761a6b40199d6e701013b0")
addappid(853982, 1, "b4e6e63ef044eeb3cdd770d8aa7cb2b0eb299e1b4e17075303371b5a4b115cf3")
addappid(853983, 1, "c29fc28e6a7d1dfc9c9379a79d5152bfb20c469c775ff2f485c3987c1dc56594")

