-- Lua provided by RyzenAPI
-- Game: Home Store Simulator

-- MAIN APPLICATION
addappid(4361680) -- Home Store Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4361681, 1, "7b7012adcc6b2c1875bbafcc703c3bfc9943ab13f3e2935669861768aad978da") -- Depot 4361681

