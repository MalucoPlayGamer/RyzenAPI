-- 4361680's Lua and Manifest Created by Hubcap Manifest
-- Home Store Simulator
-- Created: August 17, 2026 at 16:14:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4361680) -- Home Store Simulator
-- MAIN APP DEPOTS
addappid(4361681, 1, "7b7012adcc6b2c1875bbafcc703c3bfc9943ab13f3e2935669861768aad978da") -- Depot 4361681
setManifestid(4361681, "4528731753559678281", 3564929405)