-- Lua provided by RyzenAPI
-- Game: Game: Hi-Fi RUSH Original Game Soundtrack

-- MAIN APPLICATION
addappid(2341310)
-- Game: addappid(2341310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341311, 1, "b19aefb0720d9ff7b8760f5270838c39043b7204a733e0ce4eaeab0abbb4bec2")
addappid(2341312, 1, "3bd7f8288c73d14966b7dbb9b32b36ac492baacfaf1b69e3de7d95bd05deea2c")
