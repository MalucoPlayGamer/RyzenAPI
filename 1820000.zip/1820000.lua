-- Lua provided by RyzenAPI
-- Game: Homura Hime

-- MAIN APPLICATION
addappid(1820000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820001, 1, "d2cd36f5c31810a42e9f6042ad4218698a686e24251cb65c3a3547b4dece81df")

