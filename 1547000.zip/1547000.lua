-- Lua provided by RyzenAPI
-- Game: Grand Theft Auto: San Andreas – The Definitive Edition

-- MAIN APPLICATION
addappid(1547000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547001, 1, "625ab457b256e557dc28337fec8a01b39731624ee6008b92670ac977c2691806")
addappid(1899671, 0, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")

