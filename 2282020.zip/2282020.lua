-- Lua provided by RyzenAPI 
-- Game: AppID 2282020
addappid(2282020)
addappid(2282021, 1, "00852034d0001844947c15cde5623645d46f47a19e78b7f2c3918797312ff6db")
