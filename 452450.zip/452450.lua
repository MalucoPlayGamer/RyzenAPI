-- Lua provided by RyzenAPI
-- Game: Rising Islands

-- MAIN APPLICATION
addappid(452450)

-- MAIN APP DEPOTS / PACKAGES
addappid(452451, 1, "c1f3b54d67b613143f1f6e22ce61190fafec2dafd288bb3a9180850d3f2e3521")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(501150)
addappid(501151)
