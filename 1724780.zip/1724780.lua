-- Lua provided by RyzenAPI
-- Game: Game: AppID 1724780

-- MAIN APPLICATION
addappid(1724780)
-- Game: addappid(1724780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724781, 1, "cc6239118c75ceb52cbba1e4716e7ef6bd42daf428d97ab442887b0ad88cee0a")
