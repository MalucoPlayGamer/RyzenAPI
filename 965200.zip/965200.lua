-- Lua provided by RyzenAPI
-- Game: Walking Zombie 2

-- MAIN APPLICATION
addappid(965200)
addappid(1221700)

-- MAIN APP DEPOTS / PACKAGES
addappid(965201, 1, "dd1564f6aded063eadd8c74d43664256d930cc3195f97c4a4e9eef7b3c4af0c6")

