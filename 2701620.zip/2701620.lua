-- Lua provided by RyzenAPI
-- Game: addappid(2701620)

-- MAIN APPLICATION
addappid(2701620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701621, 1, "35a11c54b6afade1d8ff6acfb916ba10a395c1caafa5fd3afe28f8ce195d7a87")
