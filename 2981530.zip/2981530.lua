-- Lua provided by RyzenAPI
-- Game: addappid(2981530)

-- MAIN APPLICATION
addappid(2981530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981531, 1, "aeebb809d66af204db199636d7dce370436cacf73009ef67844b09e04d0b75a4")
