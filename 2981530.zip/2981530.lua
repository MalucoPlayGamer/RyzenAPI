-- Lua provided by RyzenAPI
-- Game: 索罗灵魂之戒—神界篇

-- MAIN APPLICATION
addappid(2981530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981531, 1, "aeebb809d66af204db199636d7dce370436cacf73009ef67844b09e04d0b75a4")

