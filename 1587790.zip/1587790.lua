-- Lua provided by RyzenAPI
-- Game: Game: AppID 1587790

-- MAIN APPLICATION
addappid(1587790)
-- Game: addappid(1587790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1587791, 1, "d2e623a5c4f4f7746a2cba1fd8390a60e5e1d5fa4b6132ef6217ca43324b3aa5")
