-- Lua provided by RyzenAPI
-- Game: Game: Idle Monster Frontier

-- MAIN APPLICATION
addappid(1664060)
-- Game: addappid(1664060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664061, 1, "3c1f942e8ee5e682f5d39e087ba6a388cc2046d12da5cc5d9fef1f9cad2770b7")
