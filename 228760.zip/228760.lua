-- Lua provided by RyzenAPI
-- Game: Game: TrackMania² Canyon

-- MAIN APPLICATION
addappid(228760)
-- Game: addappid(228760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228761, 1, "965a9dcfb615d5937132bad85ca4eb5eb7cc1131db48ff0e99e456acee9d94e5")
