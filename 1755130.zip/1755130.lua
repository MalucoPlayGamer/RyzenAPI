-- Lua provided by RyzenAPI
-- Game: ELE RAMPAGE

-- MAIN APPLICATION
addappid(1755130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1755131, 1, "4b24c35c243338147479c6820cc536b7c93c46b46b7c1896b7fd2a7b694f92ae")

