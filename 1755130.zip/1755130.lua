-- Lua provided by RyzenAPI 
-- Game: ELE RAMPAGE
addappid(1755130)
addappid(1755131, 1, "4b24c35c243338147479c6820cc536b7c93c46b46b7c1896b7fd2a7b694f92ae")
