-- Lua provided by RyzenAPI
-- Game: Game: AppID 766560

-- MAIN APPLICATION
addappid(766560)
-- Game: addappid(766560)

-- MAIN APP DEPOTS / PACKAGES
addappid(766561, 1, "bd644be75116a4bb66ecf21d9038c23249342e3367e9fb80158ffd94c4b73984")
addappid(766562, 1, "6177c2631f3a0c964ec28ef4db856d86a0acd0a977986087bb730e2d9dba525b")
