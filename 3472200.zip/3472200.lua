-- Lua provided by RyzenAPI
-- Game: 3472200

-- MAIN APPLICATION
addappid(3472200)
-- Game: addappid(3472200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3472201, 1, "35959acad558f68ad1fc5b80cbc997e10e6ab8cf94d85e449da7f2391813a28b")
