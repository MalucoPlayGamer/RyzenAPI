-- Lua provided by RyzenAPI
-- Game: Uncensored DLC for MiMiMiShKa

-- MAIN APPLICATION
addappid(1184690)
-- Game: addappid(1184690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184690,0,"337273a06b5d4e463083b89b7572888c76da5b9021902c25598760faae3070a8")
