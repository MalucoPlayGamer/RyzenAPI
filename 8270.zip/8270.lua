-- Lua provided by RyzenAPI
-- Game: Sam & Max 202: Moai Better Blues

-- MAIN APPLICATION
addappid(8270)

-- MAIN APP DEPOTS / PACKAGES
addappid(8272,0,"dfba3bfa24be5f15552009c8ded972c5eae27724a3e30caced2bfbc2771f7e67")
addappid(8273,0,"4eb7e0ac698970bccfa3f250108384b0c09b2b79132818c08dc588021d61fd6e")
