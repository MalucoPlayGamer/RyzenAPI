-- Lua provided by RyzenAPI
-- Game: Sin Slayers: Reign of The 8th

-- MAIN APPLICATION
addappid(2790000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2790001, 1, "f23c810d3f887937c15f17006d21c1905041a007ee9913cc3e6f3e1fe55b853c")
addappid(2790003, 1, "aa609b73eb4f47cda7f43e44314c0acd6f2c7802569df27ac257ac6ddd703461")
addappid(3313990, 0, "31dfa1391278b513b1682e7fd9202ed850d7c5ce31e07610d4f4541202c4c037")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3313980)
