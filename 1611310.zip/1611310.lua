-- Lua provided by RyzenAPI
-- Game: 1611310

-- MAIN APPLICATION
addappid(1611310)
-- Game: addappid(1611310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611311, 1, "08798878beda3bfa5348ab44475478cfa084f7bb6f2043232717dbf7dfbb8df9")
addappid(1611312, 1, "17228917cc06d7d7ed72896e62b0673dab1febfe2cce7a1bd224c5c6fce23c70")
