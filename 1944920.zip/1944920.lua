-- Lua provided by SkyAPI 
-- Game: TVG (The Vox Games). Journey
addappid(1944920)
addappid(1944921, 1, "cc8ea677f9ebdbfd49f8156bfef88d86b6cf8f38c5274c6dd1fd74a05e6ae8d6")
