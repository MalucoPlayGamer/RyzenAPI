-- Lua provided by RyzenAPI
-- Game: TVG (The Vox Games). Journey

-- MAIN APPLICATION
addappid(1944920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944921, 1, "cc8ea677f9ebdbfd49f8156bfef88d86b6cf8f38c5274c6dd1fd74a05e6ae8d6")
