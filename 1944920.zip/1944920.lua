-- Lua provided by RyzenAPI
-- Game: TVG (The Vox Games). Journey

-- MAIN APPLICATION
addappid(1944920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944921, 1, "cc8ea677f9ebdbfd49f8156bfef88d86b6cf8f38c5274c6dd1fd74a05e6ae8d6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
