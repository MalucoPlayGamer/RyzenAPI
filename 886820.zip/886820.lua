-- Lua provided by RyzenAPI
-- Game: Nelke & the Legendary Alchemists ~Ateliers of the New World~

-- MAIN APPLICATION
addappid(886820)
addappid(1015850) -- Nelke & the LA: Facility Landmark "20th Anniversary"
addappid(1016550) -- Nelke & the LA: Facility Landmark "Sophie's statue"
addappid(1016560) -- Nelke & the LA: Additional resident "Gust-chan"
addappid(1047070) -- DLC 1047070
addappid(1055060) -- Nelke & the LA: Season Pass "Legendary Town Building Set"
addappid(1055061) -- Nelke & the LA: 37 Costume Pack
addappid(1055062) -- Nelke & the LA: Facility Pack: Salburg
addappid(1055063) -- Nelke & the LA: Facility Pack: Gramnad
addappid(1055064) -- Nelke & the LA: Facility Pack: Iris
addappid(1055065) -- Nelke & the LA: Facility Pack: Mana Khemia
addappid(1055066) -- Nelke & the LA: Facility Pack: Arland
addappid(1055067) -- Nelke & the LA: Facility Pack: Dusk
addappid(1055070) -- Nelke & the LA: Facility Pack: Mysterious
addappid(1055071) -- Nelke & the LA: Extra Stories
addappid(1055072)
addappid(1055073) -- Nelke & the LA: Helpful Development Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(886821, 1, "b9c8320a7f7362895e67bb2cb7f0be55f88eca43961d84596a0ce2a2bebdd024")
addappid(1055072, 1, "25272ea41175a2d2f1d473b945ef79906f2d23b810260c128e3bc6841fc9547d")
addtoken(1047070, "12020400458890378038")

