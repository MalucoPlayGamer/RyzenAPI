-- Lua provided by SkyAPI 
-- Game: LOST BUBBLES: Sweet mates
addappid(1794950)
addappid(1794951, 1, "72d1a6f9567ac4399b91d8221ba9a3f3ca8b7560ede4d7323668ef36b2e71b7b")
