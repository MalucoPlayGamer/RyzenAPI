-- Lua provided by SkyAPI 
-- Game: AppID 1916650
addappid(1916650)
addappid(1916651, 1, "b692765c60181d35027c94c57a3a7c00bc640293894de31f6aa2bb8c99716f4e")
