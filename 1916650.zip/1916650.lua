-- Lua provided by RyzenAPI
-- Game: Game: AppID 1916650

-- MAIN APPLICATION
addappid(1916650)
-- Game: addappid(1916650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1916651, 1, "b692765c60181d35027c94c57a3a7c00bc640293894de31f6aa2bb8c99716f4e")
