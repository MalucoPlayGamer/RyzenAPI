-- Lua provided by RyzenAPI 
-- Game: AppID 822610
addappid(822610)
addappid(822611, 1, "fa44c51ff22f418d651f5f4a23da31a62e05329294bb4e1580d25701a9f447a5")
addappid(822612, 1, "fa230b321fe66a7dc523e1bde2f8f8bf32c1fae1b1060c8e80590ba244d78f91")
