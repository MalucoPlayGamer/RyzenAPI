-- Lua provided by RyzenAPI
-- Game: addappid(356820)

-- MAIN APPLICATION
addappid(356820)

-- MAIN APP DEPOTS / PACKAGES
addappid(356821, 1, "9a964a4a98641a976971bcc025520d58471b0f2feb509a2a99e1bf6b56d3e454")
