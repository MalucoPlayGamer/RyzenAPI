-- Lua provided by RyzenAPI
-- Game: Bring The Chickens Home

-- MAIN APPLICATION
addappid(2529740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529741, 1, "a60237494f996ddbd85049ffe94f073c2abcf67611994765ca6fd1db7ce0c0bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
