-- Lua provided by RyzenAPI
-- Game: Game: Bring The Chickens Home

-- MAIN APPLICATION
addappid(2529740)
-- Game: addappid(2529740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529741, 1, "a60237494f996ddbd85049ffe94f073c2abcf67611994765ca6fd1db7ce0c0bd")
