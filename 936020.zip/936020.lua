-- Lua provided by RyzenAPI
-- Game: addappid(936020)

-- MAIN APPLICATION
addappid(936020)

-- MAIN APP DEPOTS / PACKAGES
addappid(936021, 1, "4f5c1c21cdffe4bf8f6bb739fc6edd5ce0b14b222af4b53467e3082bb34aeec5")
