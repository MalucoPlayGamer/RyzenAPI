-- Lua provided by RyzenAPI
-- Game: addappid(1347740)

-- MAIN APPLICATION
addappid(1347740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347741, 1, "be6d2dd24c187b3c8ef0b8cddb9c16ab84b393028ecbcf010ea4a45094443af9")
