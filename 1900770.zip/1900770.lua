-- Lua provided by RyzenAPI
-- Game: 1900770

-- MAIN APPLICATION
addappid(1900770)
-- Game: addappid(1900770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900771, 1, "56ccd9bebe674e5cdd2e449a9a868d6509ae72eb1cb0a96bf057811fcaaf8ecd")
