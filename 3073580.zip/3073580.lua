-- Lua provided by RyzenAPI
-- Game: Aquatic Store Simulator

-- MAIN APPLICATION
addappid(3073580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073581, 1, "48ef30c413229aaed2bb752bf7613f2083f09756f4cf404744dd1f31e6fb09a1")

