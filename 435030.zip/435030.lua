-- Lua provided by RyzenAPI
-- Game: Lost Lands: Mahjong

-- MAIN APPLICATION
addappid(435030)

