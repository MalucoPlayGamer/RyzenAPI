-- Lua provided by RyzenAPI
-- Game: 1836030

-- MAIN APPLICATION
addappid(1836030)
-- Game: addappid(1836030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836031, 1, "8636f31dbd562a9c9434ce8e76c0ab174ba27af8af3d1c4521838ceba2e5eb9b")
