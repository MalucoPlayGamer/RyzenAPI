-- Lua provided by RyzenAPI 
-- Game: Glasses Nightmare
addappid(1254440)
addappid(1254441, 1, "3d63f6180073d8a71200f7d3d0aba2dc03dd4801fcdc7e55d20e0f7d10f6714d")
addappid(1254442, 1, "dd6933dd7e5a93432e755b07891d4ade415c1f26619f14256d335088bef29831")
