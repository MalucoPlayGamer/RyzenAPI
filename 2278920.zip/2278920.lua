-- Lua provided by RyzenAPI
-- Game: Game: SUBNET - Escape Room Adventure

-- MAIN APPLICATION
addappid(2278920)
-- Game: addappid(2278920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278921, 1, "989430fa8dedafa2ac8222e64500553808702b15063446b4fd3061349e091036")
