-- Lua provided by SkyAPI 
-- Game: AppID 459550
addappid(459550)
addappid(459551, 1, "d19e6b853f689b08807259c778423a6265d750cdfa75d21e3f31caecb8251b11")
