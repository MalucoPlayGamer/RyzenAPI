-- Lua provided by RyzenAPI
-- Game: AppID 2310780

-- MAIN APPLICATION
addappid(2310780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310781, 1, "34a7a906fc04824867e9e1aaf1abe6e12d939e2cae83368f6d95c21ce0f58e36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
