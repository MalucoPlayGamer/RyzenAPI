-- Lua provided by RyzenAPI
-- Game: Game: AppID 2310780

-- MAIN APPLICATION
addappid(2310780)
-- Game: addappid(2310780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310781, 1, "34a7a906fc04824867e9e1aaf1abe6e12d939e2cae83368f6d95c21ce0f58e36")
