-- Lua provided by RyzenAPI
-- Game: addappid(559610)

-- MAIN APPLICATION
addappid(559610)

-- MAIN APP DEPOTS / PACKAGES
addappid(559611, 1, "ea66af4e7548ab67e854924971f606c05be97f25a6707bd99e17f6bd5ee0f08a")
addappid(943730, 0, "f9cf1cdd34b935c86c3c474ad6dedbb9ee4e4f6d45d63a8bda39676a4a75297c")
