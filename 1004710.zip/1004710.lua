-- Lua provided by RyzenAPI
-- Game: POCKET CAR : VRGROUND

-- MAIN APPLICATION
addappid(1004710)
-- Game: addappid(1004710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004711, 1, "529c23c3ef5af4daf0b8874252aa7eb936b8c1e16a1a08034f881146faad5d7b")
