-- Lua provided by RyzenAPI
-- Game: Dreadweave

-- MAIN APPLICATION
addappid(2765790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765791,0,"4ceae9c113c9868b8b9e67af4eb29733bafb32e77a3c709c531e62df504328cd")

