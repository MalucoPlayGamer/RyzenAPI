-- Lua provided by RyzenAPI
-- Game: Slaughter: The Lost Outpost

-- MAIN APPLICATION
addappid(2584050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584051, 1, "b4380326101cf94ef30190b3db5842f72cd528ecdd76633f08b34714b73677c8")
