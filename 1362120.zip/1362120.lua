-- Lua provided by RyzenAPI
-- Game: 1362120

-- MAIN APPLICATION
addappid(1362120)
-- Game: addappid(1362120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362121, 1, "e389a64aed53988355f69d2cfdf16230ab0902bd4829be9584b837ce497d5873")
