-- Lua provided by RyzenAPI
-- Game: addappid(1219890)

-- MAIN APPLICATION
addappid(1219890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219892,0,"f4dc1bb64d4a3fd2235aa5e082ce63cbf98f78d6ec641079dadacb77dac3a602")
