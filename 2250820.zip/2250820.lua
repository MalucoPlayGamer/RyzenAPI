-- Lua provided by RyzenAPI
-- Game: Party Party Time

-- MAIN APPLICATION
addappid(2250820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250821, 1, "c6325d3b7a640e6056fe18f458efa15ba17e164148f96d6142895610c3c6d1a3")
