-- Lua provided by RyzenAPI
-- Game: Party Party Time

-- MAIN APPLICATION
addappid(2250820)
addappid(2252060)
addappid(2291000)
addappid(2384180)
addappid(2416340)
addappid(2461250)
addappid(2488070)
addappid(2517980)
addappid(2667310)
addappid(2884710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250821, 1, "c6325d3b7a640e6056fe18f458efa15ba17e164148f96d6142895610c3c6d1a3")

