-- Lua provided by RyzenAPI 
-- Game: Undress Tournament
addappid(966460)
addappid(966461, 1, "6408cfd25ca060883f8c203bb48b7e33148ab498d574d568e8b15b69ad211059")
