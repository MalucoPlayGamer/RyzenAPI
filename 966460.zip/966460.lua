-- Lua provided by RyzenAPI
-- Game: 966460

-- MAIN APPLICATION
addappid(966460)
-- Game: addappid(966460)

-- MAIN APP DEPOTS / PACKAGES
addappid(966461, 1, "6408cfd25ca060883f8c203bb48b7e33148ab498d574d568e8b15b69ad211059")
