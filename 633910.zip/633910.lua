-- Lua provided by RyzenAPI
-- Game: Zombie Panic! Source Official Soundtrack

-- MAIN APPLICATION
addappid(633910)

-- MAIN APP DEPOTS / PACKAGES
addappid(633910,0,"6af33fdacc608c69fcfb7d322124f0bcacb48f15bdd2b75112e282d99319f292")
