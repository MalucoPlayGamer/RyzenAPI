-- Lua provided by RyzenAPI
-- Game: 632810

-- MAIN APPLICATION
addappid(632810)
-- Game: addappid(632810)

-- MAIN APP DEPOTS / PACKAGES
addappid(632811, 1, "1738562bd50e63ca6d614d974ef9cdbcc4712ff5e284d3a3f9482054c3b4bd27")
