-- Lua provided by RyzenAPI
-- Game: 713920

-- MAIN APPLICATION
addappid(713920)
-- Game: addappid(713920)

-- MAIN APP DEPOTS / PACKAGES
addappid(713921, 1, "b52baeaa33118f7f779d1946e7beda66dea583d1043d136f739d7edcfb22d64c")
