-- Lua provided by RyzenAPI
-- Game: Accurate Adjacent Ballistics Simulator

-- MAIN APPLICATION
addappid(2269970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269972,0,"96429e5953aca2ea35019c646691b15e7d1b2d1eb23248174620a00b2ab68485")
