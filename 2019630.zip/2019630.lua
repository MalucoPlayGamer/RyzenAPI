-- Lua provided by RyzenAPI
-- Game: addappid(2019630)

-- MAIN APPLICATION
addappid(2019630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019631, 1, "2e50d2de5472fbf45684c927680922ef5abae5252fbeaf1e52d8897c8deaa676")
