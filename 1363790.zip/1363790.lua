-- Lua provided by RyzenAPI
-- Game: AppID 1363790

-- MAIN APPLICATION
addappid(1363790)
-- Game: addappid(1363790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363791, 1, "b0203a5691a53395631b5ec6e535f5f59855fb9d3a316ca9d856a7a7b3612dfa")
