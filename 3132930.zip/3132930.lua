-- Lua provided by RyzenAPI
-- Game: Monument Valley 3

-- MAIN APPLICATION
addappid(3132930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132931, 1, "57e0afd11139b43336255c7e6bd21df5144f5b38b0f68a0b6604a88babe7c065")

