-- Lua provided by RyzenAPI
-- Game: 2285080

-- MAIN APPLICATION
addappid(2285080)
-- Game: addappid(2285080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285081, 1, "0a1e42adbaa8ebecee0a56a6dd248de527c64f2fb6d3ebaf183aff5a4d333753")
