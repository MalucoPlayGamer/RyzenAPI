-- Lua provided by RyzenAPI
-- Game: College Kings 2 - Episode 3 'Back To Basics'

-- MAIN APPLICATION
addappid(2267960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2267960,0,"64f391d91b960cf9c4982682621e78217d0c7f965e7a4bb7a9133bd10efc3318")

