-- Lua provided by RyzenAPI
-- Game: Dogs Organized Neatly

-- MAIN APPLICATION
addappid(1597730)
addappid(2741100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597731, 1, "20088895f412371b53cc964b684a732a6237b911c72a271fa85e81a67af0e1da")

