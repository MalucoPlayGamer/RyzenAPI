-- Lua provided by RyzenAPI
-- Game: Geometry Arena 2

-- MAIN APPLICATION
addappid(1667700)
-- Game: addappid(1667700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667701, 1, "8491d008067be11030e95e3af21d3caf96371ad6e490c6106ee54da74ff44123")
