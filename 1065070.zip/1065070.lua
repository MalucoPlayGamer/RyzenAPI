-- Lua provided by RyzenAPI 
-- Game: AppID 1065070
addappid(1065070)
addappid(1065071, 1, "c4044d0eba85c5e87ed1c1c8707085a8bd59edcdf2f9a0a44b7ddf983b0e5d1f")
