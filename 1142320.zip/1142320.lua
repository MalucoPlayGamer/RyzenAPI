-- Lua provided by RyzenAPI 
-- Game: AppID 1142320
addappid(1142320)
addappid(1142321, 1, "ec574277c7f29001a3a921a4ff7c779260032ee98e90c802141136f6b33e87e3")
