-- Lua provided by RyzenAPI
-- Game: Little Helper

-- MAIN APPLICATION
addappid(1142320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1142321, 1, "ec574277c7f29001a3a921a4ff7c779260032ee98e90c802141136f6b33e87e3")

