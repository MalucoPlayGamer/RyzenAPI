-- Lua provided by RyzenAPI
-- Game: Serious Sam Classics: Revolution Dedicated Server

-- MAIN APPLICATION
addappid(299310)

-- MAIN APP DEPOTS / PACKAGES
addappid(299311, 1, "feed8a613b79834c317ada12f95c965c1841fdbbeae707aa4172853e9ff501e5")

