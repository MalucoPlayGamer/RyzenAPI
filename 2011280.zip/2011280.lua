-- Lua provided by RyzenAPI
-- Game: AppID 2011280

-- MAIN APPLICATION
addappid(2011280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011281, 1, "9aa9af1d29118737aaf0daaf550ff8dcd4ddd002940c363a3ecd416a8132becf")
addappid(2011282, 1, "a806d1b528c010c0cf4932dfce1f2fd51ec37f306d4835ecd45c3e73f6e638f1")
