-- Lua provided by RyzenAPI
-- Game: Anime Artist: Tiffy’s Notty Secret

-- MAIN APPLICATION
addappid(1647940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647941, 1, "f7d861a69a94ca376258976fa061294af0a1c922230b4840fa24bb2ee7e9de6f")
addappid(1755630, 0, "0805c8336aa96cf5442c6aa51ec5efc94528528ccbbc2989c2a185ddfb7075cd")
addappid(1755631, 0, "2ffa8b16e85deab50640b10f8278bcc60349fe48f649f14ff1aecb6f2a9318ff")

