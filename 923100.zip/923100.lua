-- Lua provided by RyzenAPI
-- Game: Game: Moduwar

-- MAIN APPLICATION
addappid(923100)
-- Game: addappid(923100)

-- MAIN APP DEPOTS / PACKAGES
addappid(923101, 1, "4d633cb83924597c91bc78f7b2cfe2a3eecbf102272c166e720255f0c3144fc0")
addappid(923102, 1, "d201a0f36915ce46d95a08ccdf1bf1147f37f66d840b0e672cc40d1de088ac09")
addappid(923105, 1, "0df7be2261b6610ef43845a56219d487dc11827e7fab4cd76ae1dcdb2f888523")
addappid(3708270, 0, "b81c919b6be907c86f6045d9b1c83582c71111a4d0f702f0e5edfc696324ef99")
