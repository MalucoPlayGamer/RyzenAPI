-- Lua provided by RyzenAPI
-- Game: Farmer's Father: Save the Innocence

-- MAIN APPLICATION
addappid(1905980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905981, 1, "d9a24cdb9d1cfda663705adc3c69e1c941cc6d2f138ce87befa0a5763ab075ec")

