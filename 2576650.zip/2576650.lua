-- Lua provided by RyzenAPI
-- Game: Promenade Demo

-- MAIN APPLICATION
addappid(2576650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576651, 1, "89f1212ab0c3e0ab6112c2e292c31c7fb05f041c32ddaf12d3d8cffd69cdb4e0")
