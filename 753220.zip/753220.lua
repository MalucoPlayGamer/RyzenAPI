-- Lua provided by RyzenAPI
-- Game: Mhakna Gramura and Fairy Bell

-- MAIN APPLICATION
addappid(753220)

-- MAIN APP DEPOTS / PACKAGES
addappid(753221, 1, "26ed1897ca3e1c9fecd67b7e232ebb5b0e8fa708e39d393ecfce17d1ffa22126")
addappid(805970, 0, "a3660508e67038e61d4a09f9e72c67f8eb402859deaebda760271abc67eecd89")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
