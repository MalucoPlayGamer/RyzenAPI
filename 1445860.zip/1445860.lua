-- Lua provided by RyzenAPI
-- Game: Fabulous place

-- MAIN APPLICATION
addappid(1445860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445861, 1, "f5d00ce633e5b09c2f045e8ce57a4c2097e1bbb4704ffdb0bb74c256d9dfce5b")

