-- Lua provided by RyzenAPI
-- Game: addappid(314730)

-- MAIN APPLICATION
addappid(314730)

-- MAIN APP DEPOTS / PACKAGES
addappid(314731, 1, "2c9902f0864e2c14198b56b2e7350e2e8c4b83d8e230899b3a7c1ee12b38e5b1")
