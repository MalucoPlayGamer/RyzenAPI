-- Lua provided by RyzenAPI
-- Game: WorldCreator

-- MAIN APPLICATION
addappid(314730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(314731, 1, "2c9902f0864e2c14198b56b2e7350e2e8c4b83d8e230899b3a7c1ee12b38e5b1")

