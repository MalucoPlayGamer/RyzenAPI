-- Lua provided by RyzenAPI
-- Game: FAKE HEART Demo

-- MAIN APPLICATION
addappid(2203440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2203441, 1, "f11a0aceb55634edfd1ba7d819febc4522cfcb7768fcb78efc9750d25d6b1a07")

