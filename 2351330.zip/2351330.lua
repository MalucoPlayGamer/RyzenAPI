-- Lua provided by RyzenAPI
-- Game: BrokenLore: DON'T WATCH

-- MAIN APPLICATION
addappid(2351330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351331, 1, "63e0be979e19e309eb7ef366a4ac02a404ce3972054b256a8de46bee9824ee1a")
