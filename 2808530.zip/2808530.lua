-- Lua provided by RyzenAPI
-- Game: addappid(2808530)

-- MAIN APPLICATION
addappid(2808530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808531, 1, "a1577ebb7465e5390638cb8aa74809db15bb1cf21bfc72ea70701c943d02b7d5")
