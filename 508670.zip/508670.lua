-- Lua provided by RyzenAPI
-- Game: 508670

-- MAIN APPLICATION
addappid(508670)
-- Game: addappid(508670)

-- MAIN APP DEPOTS / PACKAGES
addappid(508671, 1, "9d93a8bdb400aebba3634b2cd57fe34a87f3a736c713ea6dd57416df0eb9ef93")
