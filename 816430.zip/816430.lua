-- Lua provided by RyzenAPI
-- Game: AppID 816430

-- MAIN APPLICATION
addappid(816430)
-- Game: addappid(816430)

-- MAIN APP DEPOTS / PACKAGES
addappid(816431, 1, "90294f3dcf5efbbf6b4e9e4ef44246d114798e3a60266223213c885af17f45a1")
