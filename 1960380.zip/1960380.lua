-- Lua provided by RyzenAPI
-- Game: čeke ceké

-- MAIN APPLICATION
addappid(1960380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960381, 1, "fafc9e927d122118230524f600f0ee3402272441f1f44f3aefe4b52cb4a03a1f")

