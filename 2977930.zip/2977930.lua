-- Lua provided by RyzenAPI
-- Game: Game: 观澜Magic Demo

-- MAIN APPLICATION
addappid(2977930)
-- Game: addappid(2977930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2977931, 1, "d8956ff45594c1c9f2d85f0f8e4fb81f262109e18a9348bcd3bb7453b8908b9a")
