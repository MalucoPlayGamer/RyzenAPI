-- Lua provided by RyzenAPI
-- Game: Infernax

-- MAIN APPLICATION
addappid(374190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(374191, 1, "8a1a4521066c018544c97158f213404f7f8d0d852b3362c9f9ac4f99f4eb11ce")

