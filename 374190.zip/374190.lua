-- Lua provided by RyzenAPI
-- Game: Game: Infernax

-- MAIN APPLICATION
addappid(374190)
-- Game: addappid(374190)

-- MAIN APP DEPOTS / PACKAGES
addappid(374191, 1, "8a1a4521066c018544c97158f213404f7f8d0d852b3362c9f9ac4f99f4eb11ce")
