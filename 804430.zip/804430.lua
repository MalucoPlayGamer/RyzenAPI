-- Lua provided by RyzenAPI
-- Game: Game: AppID 804430

-- MAIN APPLICATION
addappid(804430)
-- Game: addappid(804430)

-- MAIN APP DEPOTS / PACKAGES
addappid(804431, 1, "3d058b5bd53c47b4ebc2f74655562beabab74a484153c446fb3dbe147c088e29")
