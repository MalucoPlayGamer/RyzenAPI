-- Lua provided by RyzenAPI
-- Game: aMAZE Lunar

-- MAIN APPLICATION
addappid(1031540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031541, 1, "bf57676bcef9ef8cb51d4aefcdab8cb5befe1ae66863445b9a3acadd3cfe29b1")

