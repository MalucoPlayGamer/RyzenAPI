-- Lua provided by RyzenAPI
-- Game: addappid(1249990)

-- MAIN APPLICATION
addappid(1249990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249991, 1, "8ce114bd921b8e4adc9221b0f021370d757c7d4fd6e22ff104f5c2af895b9903")
