-- Lua provided by RyzenAPI
-- Game: Erin's Naughty Friday Prologue

-- MAIN APPLICATION
addappid(2352540)
-- Game: addappid(2352540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352541, 1, "381c7562d2c2b18c2a5279895fe24c42d871812bb50f8a8c2709947a700aa6f8")
