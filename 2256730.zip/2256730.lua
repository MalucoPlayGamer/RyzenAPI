-- Lua provided by RyzenAPI
-- Game: Yokai Art : Endless Four Seasons DLC

-- MAIN APPLICATION
addappid(2256730)
-- Game: addappid(2256730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256730,0,"58fbc71b420a736c818ef341ac9b7e0d91ab22fa1b9a5ee866050aea46c2244f")
