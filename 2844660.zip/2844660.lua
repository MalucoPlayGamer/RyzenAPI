-- Lua provided by RyzenAPI
-- Game: addappid(2844660)

-- MAIN APPLICATION
addappid(2844660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2844661, 1, "2302961f7fd72429bb9b4ce2394b878cae999f32ee0c8bb07dee55c2c88aa9bc")
