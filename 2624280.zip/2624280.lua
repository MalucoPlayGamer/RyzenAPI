-- Lua provided by RyzenAPI
-- Game: addappid(2624280)

-- MAIN APPLICATION
addappid(2624280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624281, 1, "14e69537f39dc7ed1d11d71d8a4c1e4abd47974f686cbb00f2ca617e8d0654bd")
