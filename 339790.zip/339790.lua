-- Lua provided by RyzenAPI
-- Game: rFactor

-- MAIN APPLICATION
addappid(339790)

-- MAIN APP DEPOTS / PACKAGES
addappid(339791, 1, "1edd990e4ef1884d5fb91722491ab7a5c5336bb313223a2a15deb0bf88c7b810")
