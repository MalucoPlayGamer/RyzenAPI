-- Lua provided by RyzenAPI
-- Game: Quasimorph

-- MAIN APPLICATION
addappid(2059170)
addappid(2522910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059171, 1, "25e2854f4569dfc0b7ed84a0c42b6726d69fa1b7c2157806c0827925d741eede")

