-- Lua provided by RyzenAPI
-- Game: AppID 568070

-- MAIN APPLICATION
addappid(568070)
-- Game: addappid(568070)

-- MAIN APP DEPOTS / PACKAGES
addappid(568071, 1, "484ef4f1fceeccb04686b089413c2ab28343d9013ea0ed3bf9fd03e25e3c0191")
