-- Lua provided by RyzenAPI
-- Game: Mable & The Wood

-- MAIN APPLICATION
addappid(568070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(568071, 1, "484ef4f1fceeccb04686b089413c2ab28343d9013ea0ed3bf9fd03e25e3c0191")
