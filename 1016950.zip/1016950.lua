-- Lua provided by RyzenAPI
-- Game: Game: Blood Bowl 3

-- MAIN APPLICATION
addappid(1016950)
addappid(2197250)
addappid(2197251)
addappid(2197252)
addappid(2197253)
addappid(2197254)
addappid(2245810)
-- Game: addappid(1016950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016951, 1, "f93ae1131d7bd8a01d305f157b3fa0efe69afc3d78535e3b5490d26012015350")
