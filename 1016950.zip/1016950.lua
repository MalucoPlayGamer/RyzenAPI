-- Lua provided by RyzenAPI
-- Game: Blood Bowl 3

-- MAIN APPLICATION
addappid(1016950)
addappid(2197250)
addappid(2197251)
addappid(2197252)
addappid(2197253)
addappid(2197254)
addappid(2245810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1016951, 1, "f93ae1131d7bd8a01d305f157b3fa0efe69afc3d78535e3b5490d26012015350")

