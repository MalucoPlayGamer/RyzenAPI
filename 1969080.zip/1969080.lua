-- Lua provided by RyzenAPI
-- Game: A Building Full of Cats

-- MAIN APPLICATION
addappid(1969080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969082,0,"d9f0c52daae12d661d7392a151fabd85604db12f6234f307008fc83e7f66b1d7")
addappid(1969083,0,"d457600891338a46e632da7e6424eebc7ab9b2b8b8f1df0bec712a461efc3842")
