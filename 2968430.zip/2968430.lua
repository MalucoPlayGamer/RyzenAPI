-- Lua provided by RyzenAPI
-- Game: Beer Simulator

-- MAIN APPLICATION
addappid(2968430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968431, 1, "b069536af19203cbeb508cf1f045b08920e698e957be9256a082bce2195d72e2")
