-- Lua provided by RyzenAPI
-- Game: Finnish Army Simulator

-- MAIN APPLICATION
addappid(1184250)
-- Game: addappid(1184250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1184251, 1, "06632ebf57f2bc1079bc647328341554b51f4a0143095306b2a7d422b4ea8707")
