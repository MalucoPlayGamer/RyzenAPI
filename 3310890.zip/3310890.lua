-- Lua provided by RyzenAPI
-- Game: Game: Pew Pew Gaem 3

-- MAIN APPLICATION
addappid(3310890)
-- Game: addappid(3310890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3310891, 1, "7cda5be3319d29e74316b257028780cdd572581185a9e37cdde44b1cd5030823")
