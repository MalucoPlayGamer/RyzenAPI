-- Lua provided by SkyAPI 
-- Game: The Archetype
addappid(391120)
addappid(391121, 1, "2b7c364356e6b238e0f6dc431ee8729b43fd6011437228c4202781f466c0e4f7")
