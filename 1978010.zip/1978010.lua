-- Lua provided by RyzenAPI
-- Game: Red Valley

-- MAIN APPLICATION
addappid(1978010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978012,0,"cff407b94cb4d84327e61cd0901f89a349dc61bb28ac06b7bf357c68a84455c4")
addappid(1978013,0,"a360ca03ad432c9b02c25a3c79e1f0a2a9c8402f47fdb50ad163d09d195b30fb")
