-- Lua provided by RyzenAPI
-- Game: addappid(688000)

-- MAIN APPLICATION
addappid(688000)

-- MAIN APP DEPOTS / PACKAGES
addappid(688001, 1, "eaf6fde4a02d16ce83351aa016ce083be16f04542a2b1ff7245fd13c504002a2")
