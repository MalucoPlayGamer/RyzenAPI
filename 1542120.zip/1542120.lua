-- Lua provided by RyzenAPI
-- Game: Game: AppID 1542120

-- MAIN APPLICATION
addappid(1542120)
-- Game: addappid(1542120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542121, 1, "61cff5e76f30e85e129afd6e7d119134e7ee1cbec244ac593f2c7217612529e4")
