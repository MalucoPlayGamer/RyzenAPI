-- Lua provided by RyzenAPI
-- Game: AppID 383530

-- MAIN APPLICATION
addappid(383530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(383531, 1, "de0686630195a65a01731463188975697533de4c5c0331c9196ddf7bae77253b")

