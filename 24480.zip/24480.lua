-- Lua provided by RyzenAPI
-- Game: King Arthur II - The Role-playing Wargame

-- MAIN APPLICATION
addappid(24480)
addappid(24483)
addappid(24485)
addappid(24487)
addappid(24490)
addappid(24491)
addappid(24493)

-- MAIN APP DEPOTS / PACKAGES
addappid(24484,0,"1b7252157e6c15cfc70f95154a4298ad68d308b80cde6d237b96a521ed48c5e9")
addappid(24486,0,"8124147ce1488e2b5bed65f0a1c8e69d6d7a453b49ad65826ed9ad86c9767ffd")
addappid(24488,0,"2ffdbfec47fe65b5573bd1e9a999e2ebcb8926432fdb66ed38902aaec43c5de6")
addappid(24489,0,"f5d61588ec2eded634e9d9485e01e36c79e39f55dc3f7613d0008efe8984453c")
addappid(24492,0,"52fb23196245f068489dc4d5998fd537839b9d920d6b0419a728e763ce7db728")
addappid(24494,0,"0c47ed1786d03c10bcc12d1a5184e9db0a9b3c6d70cdad97cf79fb15114dd920")
addappid(24495,0,"5ed8edd43b191cacbe28e15be61fc6770d3e211aae2278e99e9ce6e375645a43")
addappid(24496,0,"438b5d99b2a290dc61da3dc213931cddf5a359b16a1502cadd1c1cc31b916dab")
addappid(24498,0,"20048c9950c276d195db3c533d10c899438afb4610c9132dc8a0ff071bd9be53")
addappid(24499,0,"c565314acb1613ebc3ae9a4e2a47f88da4fc9c0b57284c2ad024f5acf19b8e16")
addappid(210330,0,"fe6ec1e56ccaf797fe46946ac65c85d2e57f7604536f1cb172d3d76f2a3e352c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(24497)
addappid(204820)
