-- Lua provided by RyzenAPI
-- Game: ECHOES OF WAR: The Last Heartbeat

-- MAIN APPLICATION
addappid(786710)

-- MAIN APP DEPOTS / PACKAGES
addappid(786711, 1, "94008330afea160f54766e5e67c65e9006a48b64a5efda3f40346eb3ee7d066d")
