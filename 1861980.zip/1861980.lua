-- Lua provided by RyzenAPI 
-- Game: Di-Da-Dobble
addappid(1861980)
addappid(1861981, 1, "6f51bc197e651eff8c76c5d2c7dff12a59e63fdd0ad6fdd5326bcf3696d67ddb")
addappid(1861982, 1, "1d3b764a3d40e0f3347177a70c32526e2a3386ee3479a8e0630e51bad3a682b6")
