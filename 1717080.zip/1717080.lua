-- Lua provided by SkyAPI 
-- Game: Combat Beans: Total Mayhem
addappid(1717080)
addappid(1717081, 1, "5691098b27c0020f645ffdef2c2835c07e8e2d8047393516a0bd6d17de041d8e")
