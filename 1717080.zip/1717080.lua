-- Lua provided by RyzenAPI
-- Game: Game: Combat Beans: Total Mayhem

-- MAIN APPLICATION
addappid(1717080)
-- Game: addappid(1717080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717081, 1, "5691098b27c0020f645ffdef2c2835c07e8e2d8047393516a0bd6d17de041d8e")
