-- Lua provided by RyzenAPI
-- Game: Combat Beans: Total Mayhem

-- MAIN APPLICATION
addappid(1717080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1717081, 1, "5691098b27c0020f645ffdef2c2835c07e8e2d8047393516a0bd6d17de041d8e")

