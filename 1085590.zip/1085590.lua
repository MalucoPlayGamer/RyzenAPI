-- Lua provided by RyzenAPI
-- Game: addappid(1085590)

-- MAIN APPLICATION
addappid(1085590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1085591, 1, "61c1ac99fe8b1c6952457edf4c18216a097a3887b84486b418af3d55e442fe02")
