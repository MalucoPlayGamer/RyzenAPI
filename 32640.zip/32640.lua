-- Lua provided by RyzenAPI
-- Game: addappid(32640)

-- MAIN APPLICATION
addappid(32640)

-- MAIN APP DEPOTS / PACKAGES
addappid(32641, 1, "16dd5186b5162d1898032670fa83929bcf6bfef8672ddbe2caad7699291b7609")
