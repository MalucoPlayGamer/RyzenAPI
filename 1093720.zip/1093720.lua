-- Lua provided by RyzenAPI
-- Game: SlipSlop: World's Hardest Platformer Game

-- MAIN APPLICATION
addappid(1093720)
-- Game: addappid(1093720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093721, 1, "c53b8c167004e5bf3389d95146260950638dbcb5c0b5cad6bb9713ff19613549")
addappid(1093722, 1, "1d5bbd4b890336dc26f8a562c38572a5148cad46df0668d9afb9304f5add994c")
