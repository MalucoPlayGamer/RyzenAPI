-- Lua provided by SkyAPI 
-- Game: Furry Fantasy
addappid(2015080)
addappid(2015081, 1, "3d6e24d9a997d915d9da555df05b2b57baf86897095d74e4c0f9a4441430ff4b")
