-- Lua provided by RyzenAPI
-- Game: 2381010

-- MAIN APPLICATION
addappid(2381010)
-- Game: addappid(2381010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381011, 1, "8c2bc81be738e0ebee7b757c83ab138f2e5f79c6634166e4bae40f7885d5a847")
