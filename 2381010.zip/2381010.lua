-- Lua provided by RyzenAPI
-- Game: Ashes to Ashes

-- MAIN APPLICATION
addappid(2381010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2381011, 1, "8c2bc81be738e0ebee7b757c83ab138f2e5f79c6634166e4bae40f7885d5a847")

