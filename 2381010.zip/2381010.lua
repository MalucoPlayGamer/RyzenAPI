-- Lua provided by RyzenAPI 
-- Game: Ashes to Ashes
addappid(2381010)
addappid(2381011, 1, "8c2bc81be738e0ebee7b757c83ab138f2e5f79c6634166e4bae40f7885d5a847")
