-- Lua provided by RyzenAPI
-- Game: AppID 859570

-- MAIN APPLICATION
addappid(859570)
-- Game: addappid(859570)

-- MAIN APP DEPOTS / PACKAGES
addappid(859571, 1, "d236aeba1a8481fd8cf29c7b3b29b9ba62bb203fc40000d4fab4e616f4d464b3")
