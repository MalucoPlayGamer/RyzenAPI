-- Lua provided by RyzenAPI
-- Game: Secret Neighbor

-- MAIN APPLICATION
addappid(859570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(859571, 1, "d236aeba1a8481fd8cf29c7b3b29b9ba62bb203fc40000d4fab4e616f4d464b3")
