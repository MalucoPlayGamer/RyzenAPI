-- Lua provided by RyzenAPI 
-- Game: Couple-Cultivation Saves the World
addappid(3257360)
addappid(3257361, 1, "574d77bc13a510e1a037adf7fec9e04ba8d4314656c1746a722ff5819be9f06d")
addappid(3257362, 1, "864cd1b8ee5595a984e046391238740d20476da266232616b553f4cc1ed98496")
addappid(3257363, 1, "d88c99bf4a37a65a289c4be06fe2ad1125c6fc754d4b90e4bc5c796565b4337a")
addappid(3257364, 1, "1ff4a1b1b7df4029d1dfd2e58616632b23fce33cd72416b85a4a7544fc49ec7d")
