-- Lua provided by RyzenAPI
-- Game: Game: AppID 1324750

-- MAIN APPLICATION
addappid(1324750)
-- Game: addappid(1324750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324751, 1, "0e932cb3ae421b0ae635c95ec4988501932e01a573b01ea6c3a71841fb3c7b3e")
