-- Lua provided by RyzenAPI 
-- Game: AppID 1324750
addappid(1324750)
addappid(1324751, 1, "0e932cb3ae421b0ae635c95ec4988501932e01a573b01ea6c3a71841fb3c7b3e")
