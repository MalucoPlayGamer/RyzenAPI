-- Lua provided by RyzenAPI
-- Game: No Hope

-- MAIN APPLICATION
addappid(1594370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594372,0,"c38cd9ec51f93f421f3a25de8e37a9c71c22446b7fc0449f1143746202c89c8c")

