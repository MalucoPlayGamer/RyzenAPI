-- Lua provided by SkyAPI 
-- Game: Skirmish Line
addappid(666820)
addappid(666821, 1, "c541d085bf978485d322e7bece54844c0c003ba0f9ae718804d1e1bdd6e7931e")
addappid(666825, 1, "deda75e45232b648e94b5955f85d340180b2075e7e9338a18b90bedf9e1df8a7")
