-- Lua provided by RyzenAPI
-- Game: Knights of the Crusades

-- MAIN APPLICATION
addappid(3440120)
-- Game: addappid(3440120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440121, 1, "7cc70acfc194ddb82e09fada54622a1eaa87031c9f147117a616a8cc2d727988")
