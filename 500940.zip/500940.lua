-- Lua provided by RyzenAPI 
-- Game: Get The Gems
addappid(500940)
addappid(500941, 1, "60b4d3dac5ab7f63743dff4e7fc372679c22c9e50e236e793e786cacfa9546e8")
