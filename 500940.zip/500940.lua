-- Lua provided by RyzenAPI
-- Game: Game: Get The Gems

-- MAIN APPLICATION
addappid(500940)
-- Game: addappid(500940)

-- MAIN APP DEPOTS / PACKAGES
addappid(500941, 1, "60b4d3dac5ab7f63743dff4e7fc372679c22c9e50e236e793e786cacfa9546e8")
