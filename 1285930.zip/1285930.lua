-- Lua provided by RyzenAPI
-- Game: addappid(1285930)

-- MAIN APPLICATION
addappid(1285930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285931, 1, "b42166b6f9199e86823e90af053adc9453f8a854fc9b16a8f420ff2fb172b09b")
