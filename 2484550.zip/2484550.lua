-- Lua provided by RyzenAPI
-- Game: addappid(2484550)

-- MAIN APPLICATION
addappid(2484550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484552,0,"d26c4dad4885a290ad1ee4dbcf6112b2c0b9c877ed27557363904f7b309a0fc7")
