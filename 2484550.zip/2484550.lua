-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2484550)
-- Game: addappid(2484550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2484552,0,"d26c4dad4885a290ad1ee4dbcf6112b2c0b9c877ed27557363904f7b309a0fc7")
