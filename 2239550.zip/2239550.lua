-- Lua provided by RyzenAPI
-- Game: Watch Dogs®: Legion

-- MAIN APPLICATION
addappid(2239550)
addappid(2239571)
addappid(2239573)
addappid(2239574)
addappid(2239575)
addappid(2239576)
addappid(2239577)
addappid(2239580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2239551, 1, "62572c9c866092b5d5c24f9d76b0d30e122ec188a384cf332863c2354a16e499")
addappid(2239553, 1, "aedafe5b1f90390eead5c8b1284c9135978cb376a92d63f3cc50f72cfc25c1b9")
addappid(2239554, 1, "7c56b1185c417eb03429ae8d45ac5f601ad32ea1b165aeb4e865d8be81b38057")
addappid(2239555, 1, "5264cd8b1760303e1252fddcd7c22b8737ee4072a06c949c17a70567c46f91d0")
addappid(2239556, 1, "cf5f6a46e9a1570e6233eb2635494823fbb6500438ff91f9d9bf5e15dd7f1015")
addappid(2239557, 1, "7ef880457a787df11e53915796a5683e5b4cecbdf13e652cf6b241258670fc46")
addappid(2239558, 1, "96a2343878739aa83ae1594e8308477aae7103b27c47275413b29faf2467962e")
addappid(2239559, 1, "6e573031c1f7df976ba2afd51dc5d9ad29867474e9c89336c319a28746479ba6")
addappid(2239578, 0, "ab14e233729a7f7aa201e66ca2561e17606d2b5ef892d3c3d5576393ad51a296")
addappid(2239579, 0, "c9a01759f720b3981960152bf9935ad070d46a90896d63866b2f5628c2cfda75")
addappid(2239581, 0, "8780ca840c8994c0aea640128c1627f27ed861e147aebcbe0b965a1645a1eb4e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2239570)
