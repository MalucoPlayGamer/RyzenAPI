-- Lua provided by RyzenAPI
-- Game: Game: Five Nights at Freddy's 4

-- MAIN APPLICATION
addappid(388090)
-- Game: addappid(388090)

-- MAIN APP DEPOTS / PACKAGES
addappid(388091, 1, "76cfb5c74bbd068d0d29e42c39f08a9ee51592ab7b83920028404234ca2637cc")
