-- Lua provided by RyzenAPI
-- Game: addappid(3100650)

-- MAIN APPLICATION
addappid(3100650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3100652,0,"363b2e1b8f8f809b6dc93f46beff80cddd300cb50b8afc128f8679fffb61ad0c")
