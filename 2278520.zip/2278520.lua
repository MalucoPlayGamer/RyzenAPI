-- Lua provided by RyzenAPI
-- Game: Enshrouded Dedicated Server

-- MAIN APPLICATION
addappid(2278520)
-- Game: addappid(2278520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2278521, 1, "46c777d3f6e1d41a45b5d7b9222fb11a7965d741e53fa08208423f2c771c0de3")
