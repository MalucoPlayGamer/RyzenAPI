-- Lua provided by RyzenAPI
-- Game: Legend of Heroes: Three Kingdoms

-- MAIN APPLICATION
addappid(3020510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020511, 1, "139eea24aed3d56dc572b215fc4ea1845c3238d246a98ccef727f3eec863f528")
