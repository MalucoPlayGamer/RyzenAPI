-- Lua provided by RyzenAPI
-- Game: Poop Plague in Fairyland

-- MAIN APPLICATION
addappid(1746340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746341, 1, "54a68c39a9a9feb9c87fa2dabdac9d9a2e06b8414e52054ac71abb4923e2cacf")

