-- Lua provided by RyzenAPI
-- Game: addappid(2246550)

-- MAIN APPLICATION
addappid(2246550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246551, 1, "7da7d3ae27f5ee37e00259b9e916adde65c28504b1074090284c0704d5967bf6")
