-- Lua provided by RyzenAPI
-- Game: Interkosmos 2000

-- MAIN APPLICATION
addappid(2246550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2246551, 1, "7da7d3ae27f5ee37e00259b9e916adde65c28504b1074090284c0704d5967bf6")

