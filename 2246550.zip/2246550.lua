-- Lua provided by SkyAPI 
-- Game: Interkosmos 2000
addappid(2246550)
addappid(2246551, 1, "7da7d3ae27f5ee37e00259b9e916adde65c28504b1074090284c0704d5967bf6")
