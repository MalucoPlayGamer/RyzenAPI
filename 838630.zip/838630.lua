-- Lua provided by RyzenAPI
-- Game: AppID 838630

-- MAIN APPLICATION
addappid(838630)

-- MAIN APP DEPOTS / PACKAGES
addappid(838631, 1, "a0c30e71dbef2a0a0e21a26049a45c9d9f86b90f7ee751441d6a1b9cddfc66ff")

