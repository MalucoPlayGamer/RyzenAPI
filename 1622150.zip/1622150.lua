-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - The Adventurer’s Journey II

-- MAIN APPLICATION
addappid(1622150)
-- Game: addappid(1622150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622150,0,"0943d90c8686b5802d6114179a9631d78e502a884c62c8d4e9ef2eca3f864029")
