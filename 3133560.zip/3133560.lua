-- Lua provided by RyzenAPI 
-- Game: Demon Quest
addappid(3133560)
addappid(3133561, 1, "803b0d12b456f0ee75c2d54c4a5ecd738150268b5530bc7260ad6d28998a1f20")
