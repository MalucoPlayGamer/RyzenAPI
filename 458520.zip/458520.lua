-- Lua provided by RyzenAPI
-- Game: 458520

-- MAIN APPLICATION
addappid(458520)
addappid(541630)

-- MAIN APP DEPOTS / PACKAGES
addappid(458522,0,"1bea19bba20f859975f959876ffecf7cc388fce2b5059fb0958153d8a198d4b6")

