-- Lua provided by RyzenAPI
-- Game: Game: Terrarium Land

-- MAIN APPLICATION
addappid(438780)
-- Game: addappid(438780)

-- MAIN APP DEPOTS / PACKAGES
addappid(438781, 1, "252511bebbca71085f773765406e4ffc5c826941184854697d0674d0ab72a94d")
