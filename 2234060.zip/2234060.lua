-- Lua provided by RyzenAPI
-- Game: Warrior Paint - 2005 GOTY Edition

-- MAIN APPLICATION
addappid(2234060)
-- Game: addappid(2234060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234061, 1, "4cf78dfe633d0108196040ddfb13e27f0b2f87d1a1277071d381b05e813cf844")
