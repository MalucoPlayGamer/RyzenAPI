-- Lua provided by RyzenAPI
-- Game: Hellkeeper

-- MAIN APPLICATION
addappid(3593910)
-- Game: addappid(3593910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3593912,0,"cbb94cc699835c0c3a7ec86db8942978507d7a30a9642863bed1774358b6d046")
