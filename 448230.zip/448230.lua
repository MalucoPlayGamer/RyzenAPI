-- Lua provided by RyzenAPI
-- Game: AsteroidsHD

-- MAIN APPLICATION
addappid(448230)
-- Game: addappid(448230)

-- MAIN APP DEPOTS / PACKAGES
addappid(448231, 1, "252b988fe7284c8540b381b479c18174fc29fe79f883337c7b507b2b240fa168")
