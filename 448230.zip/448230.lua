-- Lua provided by RyzenAPI
-- Game: AsteroidsHD

-- MAIN APPLICATION
addappid(448230)

-- MAIN APP DEPOTS / PACKAGES
addappid(448231, 1, "252b988fe7284c8540b381b479c18174fc29fe79f883337c7b507b2b240fa168")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
