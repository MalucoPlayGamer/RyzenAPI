-- Lua provided by RyzenAPI
-- Game: Game: Dodge

-- MAIN APPLICATION
addappid(1667800)
-- Game: addappid(1667800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1667801, 1, "fefca74ad59c65379c734d45eb90c9586361a85cdda3a7a78528845882517854")
