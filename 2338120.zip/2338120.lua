-- Lua provided by RyzenAPI
-- Game: addappid(2338120)

-- MAIN APPLICATION
addappid(2338120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338121, 1, "0555f2a03523c1dd926c83addb2d70d587be3354a5542f64fc080a97b6afdca0")
