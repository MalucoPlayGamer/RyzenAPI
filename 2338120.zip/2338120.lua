-- Lua provided by RyzenAPI 
-- Game: Outlive
addappid(2338120)
addappid(2338121, 1, "0555f2a03523c1dd926c83addb2d70d587be3354a5542f64fc080a97b6afdca0")
