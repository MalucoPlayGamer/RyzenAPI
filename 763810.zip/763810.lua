-- Lua provided by RyzenAPI
-- Game: AppID 763810

-- MAIN APPLICATION
addappid(763810)
-- Game: addappid(763810)

-- MAIN APP DEPOTS / PACKAGES
addappid(763811, 1, "1eaa72d409577877f07abcbe1dcf782c8764feff1780c4f5e377008a2bc91865")
