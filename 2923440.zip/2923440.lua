-- Lua provided by RyzenAPI
-- Game: addappid(2923440)

-- MAIN APPLICATION
addappid(2923440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923441, 1, "1fb9446cce544ca0083663ca29e5dadcd687338c4490b1107639e133d1a07fe6")
