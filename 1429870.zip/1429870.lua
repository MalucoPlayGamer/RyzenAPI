-- Lua provided by SkyAPI 
-- Game: Vectro Blast
addappid(1429870)
addappid(1429871, 1, "968463756603cda44397a20ff45c9d0716bde47d1fc3e0ab3c34fca29cd5ddfe")
