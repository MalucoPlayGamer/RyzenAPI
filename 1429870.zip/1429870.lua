-- Lua provided by RyzenAPI
-- Game: Vectro Blast

-- MAIN APPLICATION
addappid(1429870)
-- Game: addappid(1429870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1429871, 1, "968463756603cda44397a20ff45c9d0716bde47d1fc3e0ab3c34fca29cd5ddfe")
