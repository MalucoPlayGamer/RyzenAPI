-- Lua provided by RyzenAPI
-- Game: 1835560

-- MAIN APPLICATION
addappid(1835560)
-- Game: addappid(1835560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1835561, 1, "fa8fa01559ccb9ef1810d87a70bb4951349fa9a24e4cb6a99fcae8d936a42cda")
