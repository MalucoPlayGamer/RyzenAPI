-- Lua provided by RyzenAPI
-- Game: REMNANT II®

-- MAIN APPLICATION
addappid(1282100)
addappid(2384070)
addappid(2384071)
addappid(2384072)
addappid(2384073)
addappid(2384074)
addappid(2384075)
addappid(2384076)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282101, 1, "c44eaabd20d9d5479bea7e31ad0a7c0571d120c77b28814ed4175f6f790fdf7f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
