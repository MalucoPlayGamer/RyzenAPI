-- Lua provided by RyzenAPI
-- Game: 1282100

-- MAIN APPLICATION
addappid(1282100)
addappid(2384070)
addappid(2384071)
addappid(2384072)
addappid(2384073)
addappid(2384074)
addappid(2384075)
addappid(2384076)
-- Game: addappid(1282100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282101, 1, "c44eaabd20d9d5479bea7e31ad0a7c0571d120c77b28814ed4175f6f790fdf7f")
