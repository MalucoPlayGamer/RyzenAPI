-- Lua provided by RyzenAPI
-- Game: Cloudbuilt

-- MAIN APPLICATION
addappid(262390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(262391, 1, "d82713e6d89e1abd2cfa1cb1431507a08b687904b45190e5f0de3114144238b1")
addappid(307550, 0, "726bffa6e0f3292a1554fc6fa9b5fd3a113fd719c7ba013d0514d76541ced46e")
addappid(330730, 0, "5dddbfd04d20564f17bddcd70501b287cb0bfa84a88f8d5e559117cb868249fa")

