-- Lua provided by RyzenAPI
-- Game: Cloudbuilt

-- MAIN APPLICATION
addappid(262390)
-- Game: addappid(262390)

-- MAIN APP DEPOTS / PACKAGES
addappid(262391, 1, "d82713e6d89e1abd2cfa1cb1431507a08b687904b45190e5f0de3114144238b1")
addappid(307550, 0, "726bffa6e0f3292a1554fc6fa9b5fd3a113fd719c7ba013d0514d76541ced46e")
addappid(330730, 0, "5dddbfd04d20564f17bddcd70501b287cb0bfa84a88f8d5e559117cb868249fa")
