-- Lua provided by RyzenAPI
-- Game: ScootX

-- MAIN APPLICATION
addappid(3800340)
-- Game: addappid(3800340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3800341, 1, "2ab21efa32d5093ab0c39f5ddfe5d945bd30dc0d0d0ed1ce2d6a382f406e7f9b")
