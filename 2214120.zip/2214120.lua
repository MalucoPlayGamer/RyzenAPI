-- Lua provided by RyzenAPI 
-- Game: AppID 2214120
addappid(2214120)
addappid(2214121, 1, "09ab5d0e90378646f23802938dbb8171524c6a7bb742deff01e1761c44b5efc1")
