-- Lua provided by RyzenAPI
-- Game: Ada And Cal

-- MAIN APPLICATION
addappid(1719960)
-- Game: addappid(1719960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719961, 1, "0168da6d60c8c04e54f868d4ab101ecc65e43754969970fc8830c578b48be07a")
