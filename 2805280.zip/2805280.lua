-- Lua provided by RyzenAPI
-- Game: Colonization Simulator Demo

-- MAIN APPLICATION
addappid(2805280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805281, 1, "3f7f66c40e2fd845b5c4b06837eda316646dc6cd3f98e7d3adab8ae68418bada")
