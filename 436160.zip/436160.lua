-- Lua provided by RyzenAPI
-- Game: The Panic Room. House of secrets

-- MAIN APPLICATION
addappid(436160)

-- MAIN APP DEPOTS / PACKAGES
addappid(436161, 1, "a40baa34a0e7d470104563724c0d19a97cff56c57e06f643c56da380a1e8f236")
addappid(436162, 1, "180740695b5342fe4ceada3f57dc654836fff4a5ec1e76463e0c0c4057553844")

