-- Lua provided by RyzenAPI
-- Game: Overhatched

-- MAIN APPLICATION
addappid(4769490)

-- MAIN APP DEPOTS / PACKAGES
addappid(4769491, 1, "2e0f28e0d5118c5dc81b7c8c35cc117901bc1c838602585935cb2b8d1ff3e400") -- English (windows,linux)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
