-- Lua provided by RyzenAPI
-- Game: Game: Hentai Leaked!? Only for Fans

-- MAIN APPLICATION
addappid(2209860)
-- Game: addappid(2209860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209861, 1, "3053b09466205082653d19329e3cfacef88cfd54c383b3e4b29e349092f0d83b")
