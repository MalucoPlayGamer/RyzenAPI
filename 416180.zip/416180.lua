-- Lua provided by RyzenAPI
-- Game: Game: AppID 416180

-- MAIN APPLICATION
addappid(416180)
-- Game: addappid(416180)

-- MAIN APP DEPOTS / PACKAGES
addappid(416181, 1, "677fd46494d12c17fd0158fe27592a2f0238772a7e3805bee62e491a5e869753")
