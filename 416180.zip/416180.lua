-- Lua provided by SkyAPI 
-- Game: AppID 416180
addappid(416180)
addappid(416181, 1, "677fd46494d12c17fd0158fe27592a2f0238772a7e3805bee62e491a5e869753")
