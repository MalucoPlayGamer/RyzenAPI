-- Lua provided by RyzenAPI
-- Game: Game: Dragon's Dogma: Dark Arisen

-- MAIN APPLICATION
addappid(367500)
addappid(433560)
-- Game: addappid(367500)

-- MAIN APP DEPOTS / PACKAGES
addappid(367501, 1, "0ae14ef32d76a0870549aa50a0769e8db7acb8020b1cda0aee22705bc110435c")
addappid(367502, 1, "54904d1d1b1144d05c70fe0c89745b67140761167f27460a3dfba0ff75b1b4dc")
addappid(367503, 1, "5a5af31c2d17ab925a73d4bd4347d33551bab3a95c319eab08986dc8ff600c0f")
addappid(367505, 1, "84fff1334565f326bb97b11a1c5b8f87de8c3b4193ad71e082976573f9407a38")
addappid(422230, 0, "4ba142f9037655a882eea0ab84ce0df89ac47503b68f825f31be44aac5441b4a")
addappid(441290, 0, "c12a12fa1a094136a31d3ca0f853544d03654c7ddba2fe5749fd2c94ea2a45bc")
