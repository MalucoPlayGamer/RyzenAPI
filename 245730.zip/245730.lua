-- Lua provided by RyzenAPI
-- Game: Flashback

-- MAIN APPLICATION
addappid(245730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(245731, 1, "8d971573ab8fbe4840c759b35b84bb7917f81d5c065f2040d3218cb7e0ad5738")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

