-- Lua provided by RyzenAPI
-- Game: Just Skill Shooter 4

-- MAIN APPLICATION
addappid(2999790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999791, 1, "74309f5166ce0ba7de4f8f43704c41868becfeca5c9b4176479831b849a999b9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
