-- Lua provided by RyzenAPI
-- Game: Just Skill Shooter 4

-- MAIN APPLICATION
addappid(2999790)
-- Game: addappid(2999790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999791, 1, "74309f5166ce0ba7de4f8f43704c41868becfeca5c9b4176479831b849a999b9")
