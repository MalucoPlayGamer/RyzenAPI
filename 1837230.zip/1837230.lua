-- Lua provided by RyzenAPI 
-- Game: Jerez's Arena Ⅱ
addappid(1837230)
addappid(1837231, 1, "03b812d685ba86031cb79bc0599a47ea3d411a70579bfad74d191ed0bafe54a9")
