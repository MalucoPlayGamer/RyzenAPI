-- Lua provided by RyzenAPI
-- Game: addappid(2089120)

-- MAIN APPLICATION
addappid(2089120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089121, 1, "4e450465cf81ded146da70ffaf79dec1b0d500a4237673bd6d374acea1adc069")
