-- Lua provided by RyzenAPI
-- Game: Disney•Pixar Toy Story Mania!

-- MAIN APPLICATION
addappid(317580)

-- MAIN APP DEPOTS / PACKAGES
addappid(317581, 1, "ab3c70244f406e2e5240257a97aa901a9192767d15f9dcf4e6d3a23e0b41cd76")
addappid(317582, 1, "badd41a363e80019c1638ee34203bb42ed5e7bc54688da7b18c8349ad0e3d05c")
addappid(317583, 1, "332075b914f089db841fd4c00a526e9acb251b2a72aaf9499e274c3b7e770ff7")
addappid(317584, 1, "c41ca8a52f2c43f7f9a04a11aaff2f993f7419e6c032b987d0a48e14d85be60a")
addappid(317585, 1, "749906f4ae4988e293d92e547050b8255a47fffa1d57394c747b6a8e4dc9d06c")
addappid(317586, 1, "66c20f2b78ea39f5d1236ba3290d9d088fc8ca579852f3c95acb3ed232f664fb")
addappid(317587, 1, "69b870fb4e0c3646515133fda4ec8d994bf6f08396783ae09160188e30d76fe0")
addappid(317588, 1, "5a52d45a2e0877bef613ca7f21f8a87421c56dc5655077770c95abced3df77c3")
addappid(317589, 1, "30ece44f3fc81ccb20de37f8601da23d8b6d0e3649a5144a7338e475e37bee99")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
