-- Lua provided by SkyAPI 
-- Game: Lumi Trek
addappid(3363410)
addappid(3363411, 1, "e8553ff4d8dbaf8819b0571314508b50c93c9fac90ee24ffff0bc5ae6379a431")
