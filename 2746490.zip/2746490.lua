-- Lua provided by RyzenAPI
-- Game: Chronicle Survivors

-- MAIN APPLICATION
addappid(2746490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746491, 1, "e2a701f7018d1391b0cb878d0e80b051f1dad9b0b9ba984733d8f3dbfaca6f1b")
