-- Lua provided by RyzenAPI
-- Game: Armoured Commander

-- MAIN APPLICATION
addappid(1361580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361581, 1, "ccee66600e605e0b16b4ff91f9c951c8d2572d5a3325e176f352582d2070e669")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
