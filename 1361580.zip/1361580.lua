-- Lua provided by RyzenAPI 
-- Game: Armoured Commander
addappid(1361580)
addappid(1361581, 1, "ccee66600e605e0b16b4ff91f9c951c8d2572d5a3325e176f352582d2070e669")
