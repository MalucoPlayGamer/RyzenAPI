-- Lua provided by RyzenAPI
-- Game: Why Taoism Playtest

-- MAIN APPLICATION
addappid(2782780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782781, 1, "d261e71c617169dc649947c5cd795265793f063a9006e4a2ae40cf1e71ceb978")
