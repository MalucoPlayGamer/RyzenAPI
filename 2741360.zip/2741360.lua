-- Lua provided by RyzenAPI
-- Game: Valiant Hearts: Coming Home

-- MAIN APPLICATION
addappid(2741360)
addappid(2741370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2741361, 1, "bdf619a0696d63c3f117ca0ee19d9cafd50b5f42396506f674aa947b728c8d57")

