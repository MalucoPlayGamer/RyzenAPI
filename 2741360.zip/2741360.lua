-- Lua provided by RyzenAPI
-- Game: 2741360

-- MAIN APPLICATION
addappid(2741360)
-- Game: addappid(2741360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741361, 1, "bdf619a0696d63c3f117ca0ee19d9cafd50b5f42396506f674aa947b728c8d57")
