-- Lua provided by RyzenAPI 
-- Game: AppID 1585090
addappid(1585090)
addappid(1585091, 1, "370a949201acb6d7ad66e2b77f324b3ff180b4f3ec8bdae898c7f444e63fb1f3")
