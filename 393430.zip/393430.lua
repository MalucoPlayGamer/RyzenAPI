-- Lua provided by RyzenAPI
-- Game: Ice Lakes

-- MAIN APPLICATION
addappid(393430)
-- Game: addappid(393430)

-- MAIN APP DEPOTS / PACKAGES
addappid(393431, 1, "56965ae10f81371faedee0e1816282920347647870d2bedc325db2a46573d5ca")
addappid(393432, 1, "9de60f066bd50c0ed3a7b7c19252ec07dde260fee90db149a26ed95af311609b")
addappid(393433, 1, "5d81f05cc1da7ce537b2d84c1257c771e2aa90592165b7b99a9b5458a3d7a4fb")
