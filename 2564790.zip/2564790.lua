-- Lua provided by RyzenAPI
-- Game: addappid(2564790)

-- MAIN APPLICATION
addappid(2564790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564791, 1, "2252fb25c69d39e910cef99eb4904e20aca9a1ce18b5e50d44c3a7341b847ea2")
