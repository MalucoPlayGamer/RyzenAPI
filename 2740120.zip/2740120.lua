-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2740120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2740125,0,"ed8ac37fe9c8ea6a6cab88a4e71853f2d5131544102aca272ea06866fcd6bb0a")
