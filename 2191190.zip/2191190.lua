-- Lua provided by RyzenAPI
-- Game: Game: FIND ALL 4: Magic

-- MAIN APPLICATION
addappid(2191190)
-- Game: addappid(2191190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191191, 1, "fd6d1a40dfcde042e5db0ba3840ea721586047ef31331eab09b9824537c096d9")
