-- Lua provided by RyzenAPI
-- Game: HexWind

-- MAIN APPLICATION
addappid(2739340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739341, 1, "dade24adef44bd3372dcfb9cee1c6b07b2aef1b84c89a504f454fa783b456457")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
