-- Lua provided by RyzenAPI
-- Game: HexWind

-- MAIN APPLICATION
addappid(2739340)
-- Game: addappid(2739340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739341, 1, "dade24adef44bd3372dcfb9cee1c6b07b2aef1b84c89a504f454fa783b456457")
