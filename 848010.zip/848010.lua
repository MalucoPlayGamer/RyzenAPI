-- Lua provided by RyzenAPI
-- Game: addappid(848010)

-- MAIN APPLICATION
addappid(848010)

-- MAIN APP DEPOTS / PACKAGES
addappid(848011, 1, "28549d17b7476ea1df74b9a8c0d2a2dbd8eabcf65973cf8cbe67fef5fec15ac2")
