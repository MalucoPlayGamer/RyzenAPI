-- Lua provided by SkyAPI 
-- Game: OPG: Clan Wars
addappid(1610430)
addappid(1610431, 1, "a2432e44aaa7fd3e2914d37cc5b286358f43fbcb998fdb70f3dd48344cdb7398")
