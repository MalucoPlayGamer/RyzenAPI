-- Lua provided by RyzenAPI
-- Game: OPG: Clan Wars

-- MAIN APPLICATION
addappid(1610430)
-- Game: addappid(1610430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610431, 1, "a2432e44aaa7fd3e2914d37cc5b286358f43fbcb998fdb70f3dd48344cdb7398")
