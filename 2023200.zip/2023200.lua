-- Lua provided by RyzenAPI
-- Game: 2023200

-- MAIN APPLICATION
addappid(2023200)
-- Game: addappid(2023200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023201, 1, "3bcf7fd030a44783710b833f65a6c9da40f291b7811608a3643d6faf3e84043f")
