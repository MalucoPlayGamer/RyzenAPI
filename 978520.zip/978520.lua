-- Lua provided by SkyAPI 
-- Game: Legend of Keepers: Career of a Dungeon Manager
addappid(978520)
addappid(978521, 1, "0cdd9d8e3f940e06eab38bb9124fe190f1a7c757055519abaafb24bbd58cd66b")
addappid(978522, 1, "4f5ba9c45321c78e0cc8746e0a18d7d74d2ebb69bcdf6d52f770a0b72c77cb8f")
addappid(978523, 1, "f932fa2a0efbafc7c03c76c0e682c7cd707c5ba0b0982f8a9c62867a7a3f7527")
addappid(1247010, 0, "1c6fcc8dd4859c354ac2114a28b969b5e2ff5ed732c8c302a71fc4267d15770e")
