-- Lua provided by RyzenAPI
-- Game: Game: Twilight Tails

-- MAIN APPLICATION
addappid(2826140)
-- Game: addappid(2826140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2826141, 1, "4fd27313aebac3201f0f91d6e488f83de7a777098a3933b584b2f89645b2cd4d")
