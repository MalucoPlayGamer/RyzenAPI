-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Mixed Trivia 2

-- MAIN APPLICATION
addappid(796900)

-- MAIN APP DEPOTS / PACKAGES
addappid(796901, 1, "71abe3faf82bdb76a93f6e3075077f6b8fb7ba7e65cf92df94251ae7ee4413a4")

