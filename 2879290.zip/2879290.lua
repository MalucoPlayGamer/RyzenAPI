-- Lua provided by RyzenAPI
-- Game: Game: KILL THE WITCH Demo

-- MAIN APPLICATION
addappid(2879290)
-- Game: addappid(2879290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879291, 1, "675521f33808432dcc54346b0c971450cf051ff807ad93cb2438a06b647d4cdc")
