-- Lua provided by RyzenAPI 
-- Game: SRX: The Game
addappid(1542790)
addappid(1542791, 1, "545cedf4ecc1213efb9d0850329d7310846cc674e1139a371102e6a74cbdc106")
addappid(1669680, 0, "b850f02422944232c45f34d4c0c8d878e5299d1e9452219771f3c4910a69709e")
