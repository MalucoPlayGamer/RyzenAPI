-- Lua provided by RyzenAPI
-- Game: 1164930

-- MAIN APPLICATION
addappid(1164930)
-- Game: addappid(1164930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1164931, 1, "ad8b3c7368f0d91d0a07c684c19c5aa1df772de9fea6b1813e7ea5ab26e0ae04")
