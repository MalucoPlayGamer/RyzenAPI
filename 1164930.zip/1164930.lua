-- Lua provided by RyzenAPI
-- Game: Lustful Survival

-- MAIN APPLICATION
addappid(1164930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1164931, 1, "ad8b3c7368f0d91d0a07c684c19c5aa1df772de9fea6b1813e7ea5ab26e0ae04")
