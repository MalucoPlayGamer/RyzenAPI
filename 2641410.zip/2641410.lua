-- Lua provided by RyzenAPI
-- Game: Game: Woten DX - Traveller's Dream [DEMO]

-- MAIN APPLICATION
addappid(2641410)
-- Game: addappid(2641410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641411, 1, "94cd8b79c7ee95cb67349685a4467e106a558dac88edbba799e45a0e06ccae52")
