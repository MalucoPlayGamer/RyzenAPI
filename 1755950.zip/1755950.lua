-- Lua provided by RyzenAPI
-- Game: 1755950

-- MAIN APPLICATION
addappid(1755950)
-- Game: addappid(1755950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755951, 1, "265840a3ade022cbbe9ffb523f14db04547526eb2dcd67be90ce51273fbcf43d")
