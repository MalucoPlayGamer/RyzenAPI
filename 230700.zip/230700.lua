-- Lua provided by RyzenAPI
-- Game: AppID 230700

-- MAIN APPLICATION
addappid(230700)
addappid(1279250)
addappid(1279251)
addappid(1279252)
addappid(1281900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(230701, 1, "1495bee7fdfce903697c1b4fed277a0c235d79ec99d56778b2908241c8dd4e55")
addappid(230702, 1, "6009d51196d35a931ad40719a072d31880e1d680e866bab99994533768e72dd8")
addappid(230703, 1, "fd2c6241a498e6b05fcda1bf6b710a21c48b9afbf06ff4e01294de7ec26e4271")

