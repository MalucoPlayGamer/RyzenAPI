-- Lua provided by RyzenAPI 
-- Game: Ancient Stories: Gods of Egypt
addappid(1093280)
addappid(1093281, 1, "40b4ff43de3241404279415e1228a472836078983025e22a1b5e6c17b46f9665")
addappid(1093283, 1, "2e808e9362f223de4da52e8a30bd55bc28b1d9b11cd76fe06095868dad17a8ee")
