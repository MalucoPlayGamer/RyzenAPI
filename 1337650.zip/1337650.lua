-- Lua provided by RyzenAPI 
-- Game: AppID 1337650
addappid(1337650)
addappid(1337651, 1, "4f94cbd30e040a110dc53da9162651d6e2293e7340819853318e5cb601f730b4")
