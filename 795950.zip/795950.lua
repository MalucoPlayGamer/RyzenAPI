-- Lua provided by RyzenAPI
-- Game: Deathly Storm: The Edge of Life

-- MAIN APPLICATION
addappid(795950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(795951,0,"4169ae5702020b16276f85cf7669886004c56c1bc00271848ae37c9a130d936c")

