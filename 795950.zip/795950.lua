-- Lua provided by RyzenAPI
-- Game: Deathly Storm: The Edge of Life

-- MAIN APPLICATION
addappid(795950)

-- MAIN APP DEPOTS / PACKAGES
addappid(795951,0,"4169ae5702020b16276f85cf7669886004c56c1bc00271848ae37c9a130d936c")

