-- Lua provided by SkyAPI 
-- Game: AppID 638110
addappid(638110)
addappid(638111, 1, "b2dc2b5c1b9a3338efc42b2ea64b51dcc9df160a9cc124a00bf98593a4c3174b")
