-- Lua provided by RyzenAPI
-- Game: Desert Bus VR

-- MAIN APPLICATION
addappid(638110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(638111, 1, "b2dc2b5c1b9a3338efc42b2ea64b51dcc9df160a9cc124a00bf98593a4c3174b")

