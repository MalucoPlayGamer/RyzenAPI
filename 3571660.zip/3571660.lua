-- Lua provided by RyzenAPI
-- Game: ROOM FOOTBALL - Petrol Station

-- MAIN APPLICATION
addappid(3571660)
-- Game: addappid(3571660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3571661, 1, "75e45c327f8181060a68bcd2feb6aece70638808562247349a9810ac886e104a")
