-- Lua provided by RyzenAPI
-- Game: 1361470

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1361470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361472,0,"edaa8dd06e189c5ffc9f44d2f632d41682dd2747166699ec8897c38f334a74e8")
