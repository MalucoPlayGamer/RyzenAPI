-- Lua provided by RyzenAPI
-- Game: Kidnapped

-- MAIN APPLICATION
addappid(228985)
addappid(228990)
addappid(229004)
addappid(382300)
addappid(382307)
addappid(382308)
addappid(382309)

-- MAIN APP DEPOTS / PACKAGES
addappid(382302,0,"7b671531d529f0d3e418cf1af74359b89ed9efeb58be3322cabbfa1b78f1ff17")
addappid(382303,0,"5a30ebd1ea99312829554a01d58766f954e2e549b97fff01217b569f9ae12048")
addappid(382304,0,"bdb3073450d15e84e66d9d81c59bda98b3d6c22eefdb746cd9bb69e7cc52b72b")
