-- Lua provided by RyzenAPI
-- Game: 2569710

-- MAIN APPLICATION
addappid(2569710)
-- Game: addappid(2569710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569711, 1, "209f8c8e94e37bcb28818fdda0b78a6c78e43b9becb5c4c2909adaa691172d47")
