-- Lua provided by RyzenAPI
-- Game: Beyond a Steel Sky

-- MAIN APPLICATION
addappid(1146310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1146311, 1, "82b5631117e585c70bc2ec981e702ba1eb3a279e5a4e402013f735712442182f")
addappid(1146312, 1, "358eab7c6f9fc9b3283b8766e417390698c80002137093dd4850c2e679e1669c")
addappid(1368360, 0, "6f8bd8f553d8ac0a77c1e7bd8ced741fedce382bf90ba4a8c3bbb28f784c0d79")

