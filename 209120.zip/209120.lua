-- Lua provided by RyzenAPI
-- Game: addappid(209120)

-- MAIN APPLICATION
addappid(209120)

-- MAIN APP DEPOTS / PACKAGES
addappid(209121, 1, "0638bdee8eeb485748b2dbf5d588ccaa81c4b28aebfb0bf1ed90f09ac6d4908d")
addappid(209122, 1, "183cc3173c5be7b4d01e77957a10b812250a9c40722c05b807f5487c9570bc01")
