-- Lua provided by RyzenAPI
-- Game: Fortified

-- MAIN APPLICATION
addappid(334210)

-- MAIN APP DEPOTS / PACKAGES
addappid(334211, 1, "6533b5eeca9b49bf0a98b33b27271d5e675a17e604711f83095331148f5e94dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
