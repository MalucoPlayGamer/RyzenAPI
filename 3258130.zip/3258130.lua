-- Lua provided by RyzenAPI
-- Game: AppID 3258130

-- MAIN APPLICATION
addappid(3258130)
-- Game: addappid(3258130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3258131, 1, "4d4ee278da0758837759e43ae523d4fc2b81fc961e1ad09dbdf3a5980db7d86b")
