-- Lua provided by RyzenAPI
-- Game: iPi Recorder 2

-- MAIN APPLICATION
addappid(221220)

-- MAIN APP DEPOTS / PACKAGES
addappid(221221, 1, "02f6b8fd67d444125f5997c62f3908d216b1a69ac106b51e6f95890ca54e8d6d")

