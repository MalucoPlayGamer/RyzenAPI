-- Lua provided by RyzenAPI
-- Game: Santhai

-- MAIN APPLICATION
addappid(1812930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812931, 1, "325b721d9cda96676ca14dc3e28dcb2c56f93cc9b41439d752b3ae786e581091")
