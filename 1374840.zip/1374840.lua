-- Lua provided by RyzenAPI
-- Game: Dark Deity

-- MAIN APPLICATION
addappid(1374840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374842,0,"355d6d55eda8cfbdd5263aa15df26788c00042d19765efb85a183c20412f72d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1650640)
addappid(2024880)
