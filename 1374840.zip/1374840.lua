-- Lua provided by RyzenAPI
-- Game: addappid(1374840)

-- MAIN APPLICATION
addappid(1374840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374842,0,"355d6d55eda8cfbdd5263aa15df26788c00042d19765efb85a183c20412f72d9")
