-- 3344180's Lua and Manifest Created by Hubcap Manifest
-- SECRET HORNY SANTA
-- Created: August 12, 2026 at 00:03:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3344180) -- SECRET HORNY SANTA
-- MAIN APP DEPOTS
addappid(3344181, 1, "e4e86bc0078b819b1ea2b50161de3b056f05977e0fb6d059c74a195aad046bbb") -- Depot 3344181
setManifestid(3344181, "1160566958512756525", 428328124)