-- Lua provided by RyzenAPI
-- Game: Psychonauts in the Rhombus of Ruin

-- MAIN APPLICATION
addappid(788690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(788691, 1, "e103d4c36296c0585a337769082f9ed0ebc7b8dffe25b7822ef7a8c8a4b5360c")

