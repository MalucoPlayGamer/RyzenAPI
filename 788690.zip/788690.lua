-- Lua provided by RyzenAPI
-- Game: Game: Psychonauts in the Rhombus of Ruin

-- MAIN APPLICATION
addappid(788690)
-- Game: addappid(788690)

-- MAIN APP DEPOTS / PACKAGES
addappid(788691, 1, "e103d4c36296c0585a337769082f9ed0ebc7b8dffe25b7822ef7a8c8a4b5360c")
