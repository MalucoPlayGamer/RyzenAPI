-- Lua provided by RyzenAPI
-- Game: Candy Roller

-- MAIN APPLICATION
addappid(2993070)
-- Game: addappid(2993070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2993071, 1, "8e0be633421cc742e0e60f1b25ac505dc3c471dfee5e74de929c6c025e2e4bea")
