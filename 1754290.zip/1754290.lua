-- Lua provided by RyzenAPI
-- Game: 1754290

-- MAIN APPLICATION
addappid(1754290)
-- Game: addappid(1754290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754291, 1, "7761d9e35d9c22c5a4c210dfdfaf8ad3c1b92f6407f644bcb00522d41636f3fa")
