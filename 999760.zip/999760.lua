-- Lua provided by RyzenAPI
-- Game: AppID 999760

-- MAIN APPLICATION
addappid(999760)

-- MAIN APP DEPOTS / PACKAGES
addappid(999761, 1, "3dab8170551fbbdd6c5a3762d2bdb2b02c25b973267bf42e7a2119bab1fc97a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
