-- Lua provided by RyzenAPI
-- Game: 999760

-- MAIN APPLICATION
addappid(999760)
-- Game: addappid(999760)

-- MAIN APP DEPOTS / PACKAGES
addappid(999761, 1, "3dab8170551fbbdd6c5a3762d2bdb2b02c25b973267bf42e7a2119bab1fc97a1")
