-- Lua provided by SkyAPI 
-- Game: AppID 999760
addappid(999760)
addappid(999761, 1, "3dab8170551fbbdd6c5a3762d2bdb2b02c25b973267bf42e7a2119bab1fc97a1")
