-- Lua provided by RyzenAPI
-- Game: Pixel bomb! bomb!!

-- MAIN APPLICATION
addappid(566810)

-- MAIN APP DEPOTS / PACKAGES
addappid(566811,0,"e4fd932d19a49d56202cbd569cb455bf78a0613edb2a2e852527fe92f6740904")

