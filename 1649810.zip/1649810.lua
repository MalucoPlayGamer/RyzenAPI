-- Lua provided by RyzenAPI
-- Game: Happy Guy : Memories

-- MAIN APPLICATION
addappid(1649810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649810,0,"0795dd77403671996ebf50a19882033e8a0e22ba96a1c279afdb14634c350d22")

