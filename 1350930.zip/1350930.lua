-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - FES Resource Pack

-- MAIN APPLICATION
addappid(1350930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350930,0,"92fd78952af55afb7c0d52d34f1e1ec4613c74b09b39a05c62a8839a8b65de4d")
addtoken(1350930,"17195215361648695113")

