-- Lua provided by RyzenAPI
-- Game: addappid(2281870)

-- MAIN APPLICATION
addappid(2281870)
addappid(2281871)
addappid(2281873)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281872,0,"8b2fc382c02ead378fb896768e380a5dba74a2e791d4e38099838181194b8b67")
