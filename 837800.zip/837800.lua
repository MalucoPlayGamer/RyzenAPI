-- Lua provided by RyzenAPI
-- Game: AppID 837800

-- MAIN APPLICATION
addappid(837800)

-- MAIN APP DEPOTS / PACKAGES
addappid(837801, 1, "82dc6ecbfb586e7a2991e9472091657f35123d0bb8b29c65c3fc43cba7f5c21d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
