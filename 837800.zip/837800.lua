-- Lua provided by RyzenAPI
-- Game: AppID 837800

-- MAIN APPLICATION
addappid(837800)
-- Game: addappid(837800)

-- MAIN APP DEPOTS / PACKAGES
addappid(837801, 1, "82dc6ecbfb586e7a2991e9472091657f35123d0bb8b29c65c3fc43cba7f5c21d")
