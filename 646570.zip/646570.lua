-- Lua provided by RyzenAPI
-- Game: Slay the Spire

-- MAIN APPLICATION
addappid(646570)

-- MAIN APP DEPOTS / PACKAGES
addappid(646571, 1, "af36e1914da16f3e4556bedf7e46a76646b670c91bb6e1d3cca380e16ceb2df6")
addappid(646572, 1, "d46524b47e7a9384e6b575394a6e96940634c8db3f58e829182eb486ca60e425")
addappid(646573, 1, "7b0997618ad03031136f9caa6811f5d2c08ee7e0ac4b9c745675f12fd0354ee4")
addappid(646574, 1, "85867004baa33349870d65ae84baac02f1a0e0280462a7b6f41912a30e008955")
addappid(877621, 0, "9aebfbce314584af6e967104be1d5060284feca4baef886010adc9c4a983b4fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
