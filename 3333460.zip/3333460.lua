-- Lua provided by RyzenAPI
-- Game: No Space For All

-- MAIN APPLICATION
addappid(3333460)
-- Game: addappid(3333460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333461, 1, "b0bb348fd97d467b0eb1aff31a0ad5ad9067839156a7a70cbac55ada9a0bbd73")
