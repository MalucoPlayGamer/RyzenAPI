-- Lua provided by RyzenAPI
-- Game: Dark spell

-- MAIN APPLICATION
addappid(2180410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180411, 1, "38584ff62b86b314435cec5e3f0a05945fb6d3ed56e39612f34574c4691f6b4d")

