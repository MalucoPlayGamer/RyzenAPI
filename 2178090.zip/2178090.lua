-- Lua provided by RyzenAPI
-- Game: The Kinky Kitsune and The Tantalizing Tanuki

-- MAIN APPLICATION
addappid(2178090)
-- Game: addappid(2178090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178091, 1, "a21d6b513dd9fab4e8702558f7ada6a60fb4fb3b782f0f55f17b6d5c25a4a159")
