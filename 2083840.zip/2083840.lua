-- Lua provided by RyzenAPI
-- Game: Game: Her Name Was Fire

-- MAIN APPLICATION
addappid(2083840)
-- Game: addappid(2083840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083841, 1, "1bb895c0241bf6271a21969301f2826b3a2c91d9540c41e08af859f9513ac915")
