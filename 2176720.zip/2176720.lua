-- Lua provided by RyzenAPI
-- Game: M.E.A.T. II Demo

-- MAIN APPLICATION
addappid(2176720)
-- Game: addappid(2176720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176721, 1, "62a033454cce8430c5c4ab345554430b34a2a4bfba33091b15c065a5ca4f5ab1")
