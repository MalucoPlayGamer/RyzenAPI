-- Lua provided by RyzenAPI
-- Game: AppID 503390

-- MAIN APPLICATION
addappid(503390)

-- MAIN APP DEPOTS / PACKAGES
addappid(503391, 1, "63a00b27e544d00548ee55ecdbca5d25137bb97eb39d8f484f96f020dead4d4d")
