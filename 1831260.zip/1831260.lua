-- Lua provided by RyzenAPI
-- Game: Game: My Therapist is a Futanari

-- MAIN APPLICATION
addappid(1831260)
-- Game: addappid(1831260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831261, 1, "f3b3bd5bea027f50bd9efb8d145c8da925a0b65b05a74e463cc345ea69cbbb9d")
