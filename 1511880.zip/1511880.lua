-- Lua provided by RyzenAPI
-- Game: Slime Heroes

-- MAIN APPLICATION
addappid(1511880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511881, 1, "c98880f6217a68ceaf09d0bfa4b10dc8bdd13e6928ddfd472f9ce9356deddf73")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
