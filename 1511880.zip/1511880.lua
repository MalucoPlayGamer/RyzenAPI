-- Lua provided by RyzenAPI
-- Game: 1511880

-- MAIN APPLICATION
addappid(1511880)
-- Game: addappid(1511880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511881, 1, "c98880f6217a68ceaf09d0bfa4b10dc8bdd13e6928ddfd472f9ce9356deddf73")
