-- Lua provided by RyzenAPI
-- Game: addappid(2325520)

-- MAIN APPLICATION
addappid(2325520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325521, 1, "23dc10af9bb1f8c6385d91918fb18479a142a921de6690c73067ad504c43e8a0")
addappid(2325522, 1, "2a19fee49bf723dedc40d82b5aa5d65ebca91c58a6156d83f77f91b933d1ff62")
