-- Lua provided by RyzenAPI
-- Game: addappid(1432350)

-- MAIN APPLICATION
addappid(1432350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432351, 1, "54087f027d44ea910c036fe07140dd0f59f73508c9c2beda00e444eadadef071")
