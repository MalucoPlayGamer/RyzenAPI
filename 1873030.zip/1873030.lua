-- Lua provided by RyzenAPI
-- Game: Wolfenstein: Enemy Territory

-- MAIN APPLICATION
addappid(1873030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1873031, 1, "dda898242320becd50c4d9d644f364d84e2acbb9734ecb1d528485764fc25935")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
