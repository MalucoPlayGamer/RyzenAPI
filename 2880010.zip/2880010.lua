-- Lua provided by RyzenAPI
-- Game: Din's Champion

-- MAIN APPLICATION
addappid(2880010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2880011,0,"1c0f6ed5adb2e88d872ff166812bfee3fc0c2151e5059815c3586d069f0dcf9b")
addappid(2880012,0,"f452aac96acde2ebeb2222de4b6960cfeaaf619f7f68ef7aa2a26e0643d73e6e")
addappid(2880013,0,"11cd0e898a4852015b52c3260454a6e5adfb92c2dfbbd636047db0088e5ce50e")

