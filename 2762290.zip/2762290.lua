-- Lua provided by RyzenAPI
-- Game: Billy's Game Show

-- MAIN APPLICATION
addappid(2762290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762291, 1, "2ea5b098600b567d72e8b9fcc893b31fdac7ae090fdad106de6ec519711261e5")

