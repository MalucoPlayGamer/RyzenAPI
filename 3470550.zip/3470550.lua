-- 3470550's Lua and Manifest Created by Hubcap Manifest
-- We, Junk Artists
-- Created: August 07, 2026 at 08:28:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3470550) -- We, Junk Artists
-- MAIN APP DEPOTS
addappid(3470551, 1, "a7a20e1beb0adf423182885a2b1d8a620a88513e1033831dc8b010d188499ce9") -- Depot 3470551
setManifestid(3470551, "3458882949258266263", 951946302)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4789910) -- We, Junk Artists - Supporter Pack