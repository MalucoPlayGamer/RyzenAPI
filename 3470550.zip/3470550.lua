-- Lua provided by RyzenAPI
-- Game: We, Junk Artists

-- MAIN APP DEPOTS / PACKAGES
addappid(3470550) -- We, Junk Artists
addappid(3470551, 1, "a7a20e1beb0adf423182885a2b1d8a620a88513e1033831dc8b010d188499ce9") -- Depot 3470551
addappid(4789910) -- We, Junk Artists - Supporter Pack

