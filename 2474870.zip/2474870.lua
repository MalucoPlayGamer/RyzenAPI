-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2474870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474870,0,"b3ccca24f84d6e1a4b74fbf1429d1714c6a399a20618588b0b89c48e9911ed28")
