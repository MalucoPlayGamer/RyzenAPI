-- Lua provided by RyzenAPI
-- Game: Game: Midnight Prowl

-- MAIN APPLICATION
addappid(2556950)
-- Game: addappid(2556950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556951, 1, "6745e42744f0ea3b34dbf350a3c59ff532510fd655df8e10caa57f13b435dbf8")
