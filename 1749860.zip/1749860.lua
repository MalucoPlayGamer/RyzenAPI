-- Lua provided by RyzenAPI
-- Game: Lushfoil Photography Sim

-- MAIN APPLICATION
addappid(1749860)
addappid(3887900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1749861, 1, "be2a418138404d2f8797c9edbe07b9bbf450d569b5ce59649288a97a78e2178e")

