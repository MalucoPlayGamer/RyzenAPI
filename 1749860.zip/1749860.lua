-- Lua provided by RyzenAPI
-- Game: Lushfoil Photography Sim

-- MAIN APPLICATION
addappid(1749860)
addappid(3887900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749861, 1, "be2a418138404d2f8797c9edbe07b9bbf450d569b5ce59649288a97a78e2178e")
