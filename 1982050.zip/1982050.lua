-- Lua provided by RyzenAPI
-- Game: Watercolor Hell

-- MAIN APPLICATION
addappid(1982050)
-- Game: addappid(1982050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982051, 1, "5a5fe814b81ca8ceea32deafeace0df609780b0f9628de05f710fd529d1ef3f5")
