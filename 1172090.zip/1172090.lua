-- Lua provided by RyzenAPI
-- Game: 1172090

-- MAIN APPLICATION
addappid(1172090)
-- Game: addappid(1172090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172091, 1, "40f6472e4de731e7f7ae150cd4c821344f174c921f74c0b1851e0a17e853d3ca")
