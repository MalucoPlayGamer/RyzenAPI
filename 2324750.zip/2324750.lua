-- Lua provided by RyzenAPI 
-- Game: Planeta 55
addappid(2324750)
addappid(2324751, 1, "b59ac0995f7c1732136f96d88365ac96cf276a6df18e1460069e9373d25a69e2")
