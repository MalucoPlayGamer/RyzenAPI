-- Lua provided by RyzenAPI
-- Game: How Much Items - Vegetation

-- MAIN APPLICATION
addappid(3548400)
-- Game: addappid(3548400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3548401, 1, "fb583b4f18760739286781d6c929f0272c04cb41f1c3ffcd036801d27b79e047")
