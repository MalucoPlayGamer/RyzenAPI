-- Lua provided by RyzenAPI
-- Game: Showing Tonight: Mindhunters Incident

-- MAIN APPLICATION
addappid(416370)

-- MAIN APP DEPOTS / PACKAGES
addappid(416371, 1, "bb2c7cacca8ea130a244969498fa72346857c4bd9b459544c2e6fa2ef704f867")
addappid(416372, 1, "ceb4685c5a22c21eb854c4ea1b2e31416477fc2d6b34c09e343b380aa3579b95")
addappid(416373, 1, "3228887e5b690b4f5fbe984e90282bc5585745c6d9be9d09371f263c5c1e5f9b")
