-- Lua provided by RyzenAPI
-- Game: Game: Outdoor Adventures With Marisa Kirisame

-- MAIN APPLICATION
addappid(1899620)
addappid(2221590)
-- Game: addappid(1899620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1899621, 1, "df11293f230c5af4d8b090dde4328991701dfa2f268fdc699dac2e0aa0aa7b50")
