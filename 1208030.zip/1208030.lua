-- Lua provided by RyzenAPI
-- Game: Let's Learn Japanese! Vocabulary

-- MAIN APPLICATION
addappid(1208030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1208031, 1, "d5918243660f5db7a3ac7f3bdb854dc1f8942bd79abe89170398fe586a6d9b7f")
