-- Lua provided by RyzenAPI
-- Game: AppID 1208030

-- MAIN APPLICATION
addappid(1208030)
-- Game: addappid(1208030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208031, 1, "d5918243660f5db7a3ac7f3bdb854dc1f8942bd79abe89170398fe586a6d9b7f")
