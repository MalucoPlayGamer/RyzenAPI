-- Lua provided by RyzenAPI
-- Game: addappid(2003050)

-- MAIN APPLICATION
addappid(2003050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003051, 1, "8f2b8deb4126a734260ce7a467645c0bca05d2c8cbc87fd207faf63687084ee1")
