-- Lua provided by RyzenAPI
-- Game: AppID 3168470

-- MAIN APPLICATION
addappid(3168470)
-- Game: addappid(3168470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3168471, 1, "f2bdda1067dc52b9b9006bd2f21c3ab5b1cff196c111382d6f38e71512dfe17a")
