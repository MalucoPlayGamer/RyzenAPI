-- Lua provided by RyzenAPI
-- Game: 2089300

-- MAIN APPLICATION
addappid(2089300)
-- Game: addappid(2089300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089301, 1, "69cfe27da1b2e6e3698a5008071dd7a5e8ab0c720088eeb395379f1950868b30")
