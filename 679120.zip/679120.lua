-- Lua provided by RyzenAPI
-- Game: DEEP SPACE ANOMALY

-- MAIN APPLICATION
addappid(679120)
addappid(846360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(679121, 1, "5895079cbb0ba2628d2b70b692dfc4ca59c5d45d208c59e768a58943f42c958e")
