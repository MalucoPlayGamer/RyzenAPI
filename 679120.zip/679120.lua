-- Lua provided by SkyAPI 
-- Game: AppID 679120
addappid(679120)
addappid(679121, 1, "5895079cbb0ba2628d2b70b692dfc4ca59c5d45d208c59e768a58943f42c958e")
addappid(846360)
