-- Lua provided by SkyAPI 
-- Game: MarsVR: Mars Desert Research Station VR
addappid(1618720)
addappid(1618721, 1, "50184a72643c2c696dddb68876327dc27dd0420554967c0d333bf1a981f280b5")
