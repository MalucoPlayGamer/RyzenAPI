-- Lua provided by RyzenAPI
-- Game: MarsVR: Mars Desert Research Station VR

-- MAIN APPLICATION
addappid(1618720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1618721, 1, "50184a72643c2c696dddb68876327dc27dd0420554967c0d333bf1a981f280b5")
