-- Lua provided by RyzenAPI
-- Game: Murim Survival

-- MAIN APPLICATION
addappid(3449590)
-- Game: addappid(3449590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3449591, 1, "80c64ca6bb584e1917ae422b2136a7f6b64847fa8f40f0270b8cee2ef33b08fd")
