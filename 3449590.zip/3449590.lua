-- Lua provided by SkyAPI 
-- Game: Murim Survival
addappid(3449590)
addappid(3449591, 1, "80c64ca6bb584e1917ae422b2136a7f6b64847fa8f40f0270b8cee2ef33b08fd")
