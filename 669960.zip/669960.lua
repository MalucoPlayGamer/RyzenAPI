-- Lua provided by RyzenAPI
-- Game: The Dungeon Power

-- MAIN APPLICATION
addappid(669960)

-- MAIN APP DEPOTS / PACKAGES
addappid(669961,0,"fec9b9f4e7c2e496b5e44c512f0fd0291e900f16934fd50dee93543132bedcc7")

