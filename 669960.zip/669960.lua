-- Lua provided by RyzenAPI
-- Game: The Dungeon Power

-- MAIN APPLICATION
addappid(669960)

-- MAIN APP DEPOTS / PACKAGES
addappid(669961,0,"fec9b9f4e7c2e496b5e44c512f0fd0291e900f16934fd50dee93543132bedcc7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
