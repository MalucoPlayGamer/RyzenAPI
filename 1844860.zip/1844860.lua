-- Lua provided by RyzenAPI
-- Game: Game: Into the Waves

-- MAIN APPLICATION
addappid(1844860)
addappid(1850820)
-- Game: addappid(1844860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844861, 1, "b7b8cac563617fa096b7908d2de2e1aed3c81bda462ca40aaf935c0acc40e072")
