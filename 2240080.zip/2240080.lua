-- Lua provided by RyzenAPI
-- Game: Game: Spilled!

-- MAIN APPLICATION
addappid(2240080)
-- Game: addappid(2240080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240081, 1, "2aab4b5ac975aee6d53611059181406432a724fe809e34d51c765ba70ad343d7")
addappid(2240082, 1, "e9b1fa8787117af5aabb8248a9939a7b789862cc05d48aab4e21d8c21eb1d876")
