-- Lua provided by RyzenAPI
-- Game: Game: Love Sucks: Night Two

-- MAIN APPLICATION
addappid(1719310)
-- Game: addappid(1719310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719311, 1, "8d0773f9b60ef0208efa3e3bb8580289af1bac002dba5daaebb73f15c151a32a")
addappid(2920350, 0, "3668e0f47962999c499d976b7dbc7bc43ca192ad461c94375e45bb9a7924e4f5")
