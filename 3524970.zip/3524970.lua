-- Lua provided by RyzenAPI
-- Game: 美女公寓

-- MAIN APPLICATION
addappid(3524970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3524971, 1, "793005674d8cabbd8e1fcfe9f6725cd798ed6df93d534e6f5b514abecc2ff80a")
addappid(3572890, 0, "f02c439f24d444cdb77ae64e20da9bf97a3dbcfba433c61a2f41c7cc94023870")

