-- Lua provided by RyzenAPI
-- Game: Fight School Simulator

-- MAIN APPLICATION
addappid(2884190)
addappid(3789800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884191, 1, "8e1f1e373e6f08062fe37eec26ef0bf7ce25b0adfb9e0c7b8ad023698b6aabe7")
