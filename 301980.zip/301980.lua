-- Lua provided by RyzenAPI
-- Game: Disney Pirates of the Caribbean: At Worlds End

-- MAIN APPLICATION
addappid(301980)
-- Game: addappid(301980)

-- MAIN APP DEPOTS / PACKAGES
addappid(301981, 1, "863c4b65c338841c9c20fd38184ac3100e3459ecf8dbafe5eafc41dfbb9a42f0")
addappid(301982, 1, "475f3647eb71fba3cc72efb5378e6dc1f03c106d1b248fbb1e9fe97dda3e4415")
addappid(301983, 1, "166ddfdac974d6fdb961e47171bae2ec0c932bdfdd0c9c132a7986d3637c369d")
addappid(301984, 1, "c65e9d10374bfd7132e1ec4a442b60ad3414857cad49b7adb40981768eba19dc")
addappid(301985, 1, "eeefd85062904e928526dda6f6a26bae578317ec91785088900241b8b9a3413f")
addappid(301986, 1, "f44b6766f0acb194255bb8af98ac444e5598125a2dabef69dbc71dc57eac3072")
addappid(301987, 1, "e2fd7fba0e22c2cf6d23d10e46d48a3eb4d7741daddc62b99215d5ee2634b7fd")
addappid(301988, 1, "e1635ba544a4730496df49a544788409c7850a1c1434cfc9e623e73beafe49d1")
addappid(301989, 1, "e439b69780ce5387f0b4c5a9e11b82b76d9714766af1962f5376d0199895f7ea")
addappid(330330, 0, "caaf35325907ae46316d1b6b1653deda417e4cf1e56ddf0ff9a1d85ff760a39f")
addappid(330331, 0, "8e92187b73e4cefcff4925e232666b7ee2635b9c4c23a2e765b61b9ac50c40af")
