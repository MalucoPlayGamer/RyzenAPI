-- Lua provided by RyzenAPI
-- Game: Game: Dead Motherland: Zombie Co-op

-- MAIN APPLICATION
addappid(1211640)
-- Game: addappid(1211640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211641, 1, "7f5f94e3c58a3f910075a8d342dca5f2484a993ec842cb609a2e52dbd3e4b0c8")
