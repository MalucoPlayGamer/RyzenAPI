-- Lua provided by RyzenAPI
-- Game: Dead Motherland: Zombie Co-op

-- MAIN APPLICATION
addappid(1211640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211641, 1, "7f5f94e3c58a3f910075a8d342dca5f2484a993ec842cb609a2e52dbd3e4b0c8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
