-- Lua provided by RyzenAPI
-- Game: Natsuno-Kanata: Beyond Summer

-- MAIN APPLICATION
addappid(2597260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597261, 1, "e210d5b5985fa5ece3e3f843fe103119fcde9889a1e27e1508833ed7682d8a4e")
