-- Lua provided by RyzenAPI
-- Game: The Director's Disorder: Pilot Episode

-- MAIN APPLICATION
addappid(2073640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073641, 1, "0879c8c2ba389d4f47a385dfb3d4f14ab99b5f439041177e8bc8f6471cbe1d1f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
