-- Lua provided by RyzenAPI
-- Game: The Director's Disorder: Pilot Episode

-- MAIN APPLICATION
addappid(2073640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073641, 1, "0879c8c2ba389d4f47a385dfb3d4f14ab99b5f439041177e8bc8f6471cbe1d1f")
