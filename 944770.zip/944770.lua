-- Lua provided by RyzenAPI
-- Game: sheepChat

-- MAIN APPLICATION
addappid(944770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(944771, 1, "b7f6633a57a61339726d6dec99855b090a1e032b29c56c2941e837685adcccd1")
addappid(944775, 1, "c0282a8b8dd157120813890689f24deee202f634e2ff7813b21e93edfbf0bf13")

