-- Lua provided by RyzenAPI
-- Game: Rainbow Hero

-- MAIN APPLICATION
addappid(343570)

-- MAIN APP DEPOTS / PACKAGES
addappid(343571, 1, "90521f8c169cb2abe679361f0c7471e41738ba8f899397c7addac093cc4c1175")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
