-- Lua provided by RyzenAPI
-- Game: Rainbow Hero

-- MAIN APPLICATION
addappid(343570)
-- Game: addappid(343570)

-- MAIN APP DEPOTS / PACKAGES
addappid(343571, 1, "90521f8c169cb2abe679361f0c7471e41738ba8f899397c7addac093cc4c1175")
