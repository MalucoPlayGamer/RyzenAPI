-- Lua provided by RyzenAPI
-- Game: Alaska Gold Fever

-- MAIN APPLICATION
addappid(1674200)
addappid(4578230)
addappid(4856070)
addappid(4856090)
addappid(4856110)
addappid(4978170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674201,0,"9804e57792e850549d9fbe261b8ef6b2e87cd7823a141a114291be845090df86")

