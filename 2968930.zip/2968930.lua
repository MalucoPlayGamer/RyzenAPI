-- Lua provided by RyzenAPI
-- Game: Realms of Wilorth Demo

-- MAIN APPLICATION
addappid(2968930)
-- Game: addappid(2968930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968931, 1, "2248d88348d2603d3a55923c811bb8ec6acc0e789d4f5e7181401ddfb8f4baba")
