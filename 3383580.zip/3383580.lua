-- Lua provided by RyzenAPI
-- Game: 3383580

-- MAIN APPLICATION
addappid(3383580)
-- Game: addappid(3383580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3383581, 1, "f68377cc65613bdcea75bfcc7891f9ab28e4c1398e54160f2ff480a038a8cafd")
