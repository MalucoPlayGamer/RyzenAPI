-- Lua provided by RyzenAPI
-- Game: Game: Disciples III - Resurrection

-- MAIN APPLICATION
addappid(200670)
-- Game: addappid(200670)

-- MAIN APP DEPOTS / PACKAGES
addappid(200671, 1, "1640424a54b0c55434d3cc072400f3212e9c5355eaf97affa60fe6b2e5e3f8d8")
addappid(200672, 1, "cbe9993e67e1d2a9642c572279cef43ca67abca48ebce0965d6daf485d638b5c")
addappid(200673, 1, "2ba8af2b0201976c30e7b50bfefb66da07f0185565d3cea82bfafe7ac1be5799")
