-- Lua provided by RyzenAPI
-- Game: Necrophosis

-- MAIN APPLICATION
addappid(2019760)
addappid(3837860)
addappid(4769800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2019761, 1, "8f8acee5e26a3229f755f338c1a3268e923929e686b8c7b4f7d243d76f99b19a")

