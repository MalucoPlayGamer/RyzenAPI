-- Lua provided by RyzenAPI
-- Game: Necrophosis

-- MAIN APPLICATION
addappid(2019760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019761, 1, "8f8acee5e26a3229f755f338c1a3268e923929e686b8c7b4f7d243d76f99b19a")
