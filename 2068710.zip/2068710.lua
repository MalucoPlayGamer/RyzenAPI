-- Lua provided by RyzenAPI
-- Game: Hot Lap League: Deluxe Edition

-- MAIN APPLICATION
addappid(2068710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2068711, 1, "05fdea0319a0c9f4ec20d444c798e6b13733abc18c551977199cdf9e04d145c2")

