-- Lua provided by RyzenAPI
-- Game: Worlds of Nyx

-- MAIN APPLICATION
addappid(2059350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059351, 1, "4cbfe6ce3e2521c5def525948665e33df0feaf4e061cd19fc6f32cf01a454092")
