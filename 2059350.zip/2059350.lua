-- Lua provided by RyzenAPI
-- Game: Worlds of Nyx

-- MAIN APPLICATION
addappid(2059350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2059351, 1, "4cbfe6ce3e2521c5def525948665e33df0feaf4e061cd19fc6f32cf01a454092")

