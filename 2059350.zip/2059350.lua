-- Lua provided by SkyAPI 
-- Game: Worlds of Nyx
addappid(2059350)
addappid(2059351, 1, "4cbfe6ce3e2521c5def525948665e33df0feaf4e061cd19fc6f32cf01a454092")
