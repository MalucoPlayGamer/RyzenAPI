-- Lua provided by RyzenAPI
-- Game: Chicken Hill

-- MAIN APPLICATION
addappid(1422650)
-- Game: addappid(1422650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422651, 1, "766190b91a85887993a539fb55452d00a6c576b81861b41cb8c99565f5956a51")
