-- Lua provided by RyzenAPI
-- Game: 624970

-- MAIN APPLICATION
addappid(624970)
-- Game: addappid(624970)

-- MAIN APP DEPOTS / PACKAGES
addappid(624971, 1, "8336cd937fbd3f08a9a9eabf7951b60ee81abebc93f3452805523d8afa1f91f6")
