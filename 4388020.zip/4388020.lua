-- Lua provided by RyzenAPI
-- Game: МЕМАСИКИ ПО КЛАССИКЕ 2

-- MAIN APPLICATION
addappid(4388020)

-- MAIN APP DEPOTS / PACKAGES
addappid(4388021,0,"bec2959e964723f3793f3565892bdb6bc2aba3e38242ed2d6edb58022dd44cbd")

