-- Lua provided by RyzenAPI
-- Game: Game: Harem Academy: Tales of the Titty Tamer

-- MAIN APPLICATION
addappid(3708180)
-- Game: addappid(3708180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3708181, 1, "d58f5e1270d170ff9ca50e2db4881db83a837cbe68a021baa61f6c5cc4413d64")
