-- Lua provided by RyzenAPI
-- Game: addappid(211580)

-- MAIN APPLICATION
addappid(211580)
addappid(228982)

-- MAIN APP DEPOTS / PACKAGES
addappid(211581, 1, "93ffd969e8c84192e54e81263adfd77a8b9770a39170bb6a9cd227f2c3e272ec")
