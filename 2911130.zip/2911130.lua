-- Lua provided by SkyAPI 
-- Game: The Demon Lord Dungeon
addappid(2911130)
addappid(2911131, 1, "37656022a680305f5ebb0212d9c5bdc7afd641bb957c8fa92da69b7634074b9b")
