-- Lua provided by RyzenAPI
-- Game: Family Mysteries 3: Criminal Mindset

-- MAIN APPLICATION
addappid(1309860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309861, 1, "4d1ae249873854545e105942ee5d5ea51f2833a6f2c04bf72882f8e36a958539")

