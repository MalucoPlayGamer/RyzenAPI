-- Lua provided by RyzenAPI 
-- Game: AppID 1309860
addappid(1309860)
addappid(1309861, 1, "4d1ae249873854545e105942ee5d5ea51f2833a6f2c04bf72882f8e36a958539")
