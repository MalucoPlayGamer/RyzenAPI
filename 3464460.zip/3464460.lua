-- Lua provided by RyzenAPI
-- Game: addappid(3464460)

-- MAIN APPLICATION
addappid(3464460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464461, 1, "b4aaa84692964c41eb1eab33b14d418c74abfde18e60e6537815c6729ae09cd3")
