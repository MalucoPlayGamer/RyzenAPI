-- Lua provided by RyzenAPI
-- Game: Awakening

-- MAIN APPLICATION
addappid(707340)

-- MAIN APP DEPOTS / PACKAGES
addappid(707341, 1, "9b5f4bd9cc2d5289a02a6e0efb500b93a283deb6e3a27c4e8fcad9b61af8d3ca")

