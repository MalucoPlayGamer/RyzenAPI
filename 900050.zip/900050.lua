-- Lua provided by RyzenAPI
-- Game: 900050

-- MAIN APPLICATION
addappid(900050)
-- Game: addappid(900050)

-- MAIN APP DEPOTS / PACKAGES
addappid(900051, 1, "7290c86aebc73e643e6d07d9e47b68351ed2de59ab22613811a7d33f6c1a7f5d")
