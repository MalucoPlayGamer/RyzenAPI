-- Lua provided by RyzenAPI
-- Game: Game: Just Deserts

-- MAIN APPLICATION
addappid(488660)
-- Game: addappid(488660)

-- MAIN APP DEPOTS / PACKAGES
addappid(488661, 1, "170fedb37261e3829ce62aef4b5cfdbcb3f08880c9c8fe703e368098090904df")
addappid(517290, 0, "d645edf4bc59d0f0bd13bab84eba0264397315247fd6deba6751daad0113b51b")
addappid(517291, 0, "5a21a004bc004120e9b0253e20a539abf31f6b5921f0ba9ee37d3c8e5ee88bc0")
addappid(517292, 0, "e1a8f5d8e8b70cce7344838d1194ad6097c23c327c1cbe218b39ca94db496281")
addappid(1394950, 0, "eb6e6251d30a7825b23d72b101fb9bf62a619748d908333558a0887561cc9995")
