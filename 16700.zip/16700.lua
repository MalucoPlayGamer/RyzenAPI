-- Lua provided by RyzenAPI
-- Game: Game: Stronghold Crusader Extreme

-- MAIN APPLICATION
addappid(16700)
addappid(40971)
addappid(40972)
addappid(40973)
addappid(40974)
addappid(40975)
addappid(40976)
addappid(40977)
addappid(40978)
addappid(40979)
addappid(588520)
addappid(588521)
addappid(588522)
-- Game: addappid(16700)

-- MAIN APP DEPOTS / PACKAGES
addappid(16701, 1, "6e716b40a6bc0fa7722c0f8b55717e8f65bac30c0823fe8a01615fd0061d7aa8")
addappid(16702, 1, "6d44ba7cd104513b8c138efa4262b59fdcd20effe836bc4e6698b1c9a15d73e1")
addappid(16703, 1, "4b49dfd5e1a4f2ef5f07c4da3ee5293cc7a3aabd7da80bd9294f2d9c216fce80")
addappid(16704, 1, "0359c39332ddb79f901f57197e6df520be235ea785d6d53b12f7bd9cfdc81b1f")
addappid(16705, 1, "d63be86263a9905e2ea1f15b44891b1313196a6b5c9a0b7cf7157202e003bdc5")
addappid(16706, 1, "aa0ba327f153bdea19d590695f8fa57ca2b3af4dcd29c16cd9e7db3948d29a18")
addappid(16707, 1, "1273cbf410fd70a0bce4aa58881058d357d1d41bb3d461587084b9700d17d7ca")
addappid(16708, 1, "85fbf8d971fa015652d26b8f1123c00272ff5b65208aa008e09c16174b44cb25")
addappid(16709, 1, "a6a2b0b40c661116c5c900d84e947820b2e49756ba51bb0bc07de40dd1756754")
addappid(589000, 0, "4bb7197f481b2d05e5ad129d5253b2a23ec820c41bed80b7c4b6053b81dff738")
addappid(589001, 0, "679ef23e1947379fa0aa07a7b11621fa22a37976056f536823d78e0293c95366")
addappid(589002, 0, "0197ddcf4b47eff7469ee63d94f6a367d75d7201af89f4782fc6c264651e39ac")
