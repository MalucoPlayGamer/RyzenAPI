-- Lua provided by SkyAPI 
-- Game: AppID 3296850
addappid(3296850)
addappid(3296851, 1, "f7175a5e4f8e30b43da701ff319f248ed236f380e5a6b8de6adbc4b3ff61430d")
addappid(3296852, 1, "9331fbf82322048dd2bff2eea1e9dc9aede787c7219e429428e86b815493bbb6")
