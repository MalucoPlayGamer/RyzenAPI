-- Lua provided by RyzenAPI 
-- Game: Lost In The Shadows
addappid(2425090)
addappid(2425091, 1, "cd92ec47c8290f998b3ff13297137f165ba5b570da0b9d12ac4fdaabab49b22f")
