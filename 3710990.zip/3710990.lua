-- Lua provided by RyzenAPI
-- Game: Game: NO LOGIC INC.

-- MAIN APPLICATION
addappid(3710990)
-- Game: addappid(3710990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3710991, 1, "837b1f363ddaccf246f6b07f40102df29a97087784c553614d3d9042939e6ffc")
