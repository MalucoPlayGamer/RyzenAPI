-- Lua provided by RyzenAPI
-- Game: 1894220

-- MAIN APPLICATION
addappid(1894220)
-- Game: addappid(1894220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894221, 1, "f68a67dfd64064f84f7a42e23ee3e78095d493fc261e9cbf6a1df705c7a84036")
