-- Lua provided by RyzenAPI
-- Game: SCP: Escape Together Dedicated Server

-- MAIN APPLICATION
addappid(1433270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433271, 1, "fe2e74f8428833a266c5a0bd013d16e1dfcded78ebf4c586ee8a33b1cba7a7fc")
addappid(1433272, 1, "ffee6aea4067dd804aac9d64601c37d1b4f747f7a170a58fbaebd3611391822a")

