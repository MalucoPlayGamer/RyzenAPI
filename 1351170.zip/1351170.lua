-- Lua provided by RyzenAPI
-- Game: 東方催狐譚 ～ Servants of Harvest Wish

-- MAIN APPLICATION
addappid(1351170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1351171, 1, "8c5d458c320ed5fd9f3ebdf50b4f31325c15c518665d514d015c1819107045c9")

