-- Lua provided by RyzenAPI
-- Game: WRC 10 FIA World Rally Championship Demo

-- MAIN APPLICATION
addappid(1642150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642151, 1, "f7397ddfafc7dbbf5edf76eebfa3758d2d83557d9883f11927092362bc841291")
