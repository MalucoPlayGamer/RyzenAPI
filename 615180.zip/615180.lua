-- Lua provided by RyzenAPI
-- Game: Firewood

-- MAIN APPLICATION
addappid(615180)
addappid(693910)

-- MAIN APP DEPOTS / PACKAGES
addappid(615181, 1, "03866073244fc2d33dbad51fbfb5c1f5745d1e65aebd6b33780aff807ae11599")

