-- Lua provided by RyzenAPI
-- Game: AppID 615180

-- MAIN APPLICATION
addappid(615180)
-- Game: addappid(615180)

-- MAIN APP DEPOTS / PACKAGES
addappid(615181, 1, "03866073244fc2d33dbad51fbfb5c1f5745d1e65aebd6b33780aff807ae11599")
