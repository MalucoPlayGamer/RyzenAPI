-- Lua provided by RyzenAPI
-- Game: 35150

-- MAIN APPLICATION
addappid(35150)

-- MAIN APP DEPOTS / PACKAGES
addappid(35133,0,"29d597bafb55aad4f38fe00ecdababd9a7131cf1d9f82dd27c1ea0d930f7960d")
