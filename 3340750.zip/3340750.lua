-- Lua provided by RyzenAPI
-- Game: 3340750

-- MAIN APPLICATION
addappid(3340750)
-- Game: addappid(3340750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3340751, 1, "525bbaa8c4d2549a4b6e9764c677eb3a9f35842338f76ce1fb50765141e39c11")
