-- Lua provided by RyzenAPI
-- Game: 100 New Year Cats

-- MAIN APPLICATION
addappid(3340750)
addappid(3368440)
addappid(3368450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3340751, 1, "525bbaa8c4d2549a4b6e9764c677eb3a9f35842338f76ce1fb50765141e39c11")