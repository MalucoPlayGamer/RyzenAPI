-- Lua provided by RyzenAPI
-- Game: Grayscale Memories

-- MAIN APPLICATION
addappid(1645780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645781, 1, "57f32755a07c10c9f536c1e0924b8c06cd4f9db39839a2c0a1a686527df2b671")
