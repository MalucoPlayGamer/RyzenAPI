-- Lua provided by SkyAPI 
-- Game: Grayscale Memories
addappid(1645780)
addappid(1645781, 1, "57f32755a07c10c9f536c1e0924b8c06cd4f9db39839a2c0a1a686527df2b671")
