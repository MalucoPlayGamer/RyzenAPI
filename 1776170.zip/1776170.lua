-- Lua provided by RyzenAPI
-- Game: Barton Lynch Pro Surfing

-- MAIN APPLICATION
addappid(1776170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1776171, 1, "2aad217043129deb8cae4d093d44457257505ce57ae63b628e8bd10242fa92d9")

