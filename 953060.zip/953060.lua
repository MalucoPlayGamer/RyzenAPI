-- Lua provided by RyzenAPI
-- Game: 953060

-- MAIN APPLICATION
addappid(953060)
-- Game: addappid(953060)

-- MAIN APP DEPOTS / PACKAGES
addappid(953062,0,"108dcbeb4d8806eddbf0c936527a557bdd6a9aab470cf9e0ba5da70fd358ca14")
