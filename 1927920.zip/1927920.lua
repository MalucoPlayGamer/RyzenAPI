-- Lua provided by RyzenAPI
-- Game: 1927920

-- MAIN APPLICATION
addappid(1927920)
-- Game: addappid(1927920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927921, 1, "ae4f5c05afa47aff89c23065c5ae07b82c9070ca172b06fdf7549bea18a39d0c")
