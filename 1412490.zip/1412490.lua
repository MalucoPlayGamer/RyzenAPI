-- Lua provided by RyzenAPI 
-- Game: Atomicrops Soundtrack
addappid(1412490)
addappid(1412491, 1, "065413db420d565d529a6fc45db38b19868ceb5219ae841fd0cb89754f0ec896")
addappid(1412492, 1, "9ad50d97418596ff1467e7c2d6e87e0768f84a995944aed2bb5ecb5d580e7f15")
