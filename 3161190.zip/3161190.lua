-- Lua provided by RyzenAPI
-- Game: 3161190

-- MAIN APPLICATION
addappid(3161190)
-- Game: addappid(3161190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3161191, 1, "095b4cad63191935b8801bf78ac473704b34ebec272031410ccc9c3233d6a2ee")
