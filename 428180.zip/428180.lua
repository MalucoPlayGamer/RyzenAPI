-- Lua provided by RyzenAPI
-- Game: addappid(428180)

-- MAIN APPLICATION
addappid(428180)
addappid(493850)

-- MAIN APP DEPOTS / PACKAGES
addappid(428181, 1, "667b9139de0b15a8a389eec0db89d64ef460ca1d170872965db5dc1e95675406")
