-- Lua provided by RyzenAPI
-- Game: Game: METAGAL

-- MAIN APPLICATION
addappid(467850)
-- Game: addappid(467850)

-- MAIN APP DEPOTS / PACKAGES
addappid(467851, 1, "9cab54497c003f4395dd0520baa167413901a0bb670547217f03ae62945235c0")
