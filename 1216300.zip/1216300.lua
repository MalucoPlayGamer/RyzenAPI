-- Lua provided by SkyAPI 
-- Game: My Diggy Dog 2
addappid(1216300)
addappid(1216301, 1, "1f35697e63cfee3242cd6e6ac2cc78127e77187711304957b1c67fa3385026c5")
addappid(1216302, 1, "a1f2daf4e9420251c33f7d1294b11f0387aee010a9b4976d21f36eb3ec649539")
