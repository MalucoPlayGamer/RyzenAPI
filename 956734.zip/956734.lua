-- Lua provided by RyzenAPI
-- Game: 956734

-- MAIN APPLICATION
addappid(956734)
-- Game: addappid(956734)

-- MAIN APP DEPOTS / PACKAGES
addappid(956734,0,"0d2d440517018a2cf867f6b86c01bda04f25b015af12c9b4085c240796e5e690")
