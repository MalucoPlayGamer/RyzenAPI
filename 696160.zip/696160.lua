-- Lua provided by RyzenAPI
-- Game: Necromancer Accountant

-- MAIN APPLICATION
addappid(696160)

-- MAIN APP DEPOTS / PACKAGES
addappid(696161, 1, "54e90d352745ea40111f68ede0d9ec4466091a860baefc1090e233ce7e32b6b2")
