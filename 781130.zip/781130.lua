-- Lua provided by RyzenAPI
-- Game: Creatura

-- MAIN APPLICATION
addappid(781130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(781131, 1, "1169ffcdf763b6ae746a864b733831db3d32003cff5fb0cc573439fa9ee9cce7")
addappid(781132, 1, "ea4992d61397af3d68f45398e11ae45b8d1feeb7fd5f2e6f40fc677844d60378")
addappid(781133, 1, "de1f629fd2c67c835bee741d5a6ebb62c0c3dc484a50c08efcab5558d503016c")

