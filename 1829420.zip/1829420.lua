-- Lua provided by RyzenAPI
-- Game: addappid(1829420)

-- MAIN APPLICATION
addappid(1829420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829421, 1, "997f3d9a5aaa0185b4aad5ff01f0e73379dce365e02ae4ed6d11a83938b85f6c")
