-- Lua provided by RyzenAPI
-- Game: Game: Othercide - Soundtrack

-- MAIN APPLICATION
addappid(1330380)
-- Game: addappid(1330380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330381, 1, "618618561970af797e6b1bbc2936c5ff2a8442766d2c6f0cde394a92ef65d7a9")
addappid(1330382, 1, "cdd9eb1cfaaadb14918f226ea090342e9130c4c23d55467b722de16c17edea2d")
