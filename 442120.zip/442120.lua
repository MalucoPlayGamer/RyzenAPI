-- Lua provided by RyzenAPI
-- Game: Pinball FX Classic

-- MAIN APPLICATION
addappid(442120)

-- MAIN APP DEPOTS / PACKAGES
addappid(442121, 1, "08f0e8392d005c3071af9f81d139539c81112a47be754f2b16cf2fa317887b31")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(646660)
addappid(646661)
addappid(646662)
addappid(646663)
addappid(646664)
addappid(646665)
addappid(646666)
addappid(646667)
addappid(646668)
addappid(646669)
addappid(646670)
addappid(646671)
addappid(646672)
addappid(646673)
addappid(657420)
addappid(657421)
addappid(657422)
addappid(657423)
addappid(657424)
addappid(657430)
addappid(657431)
addappid(715110)
addappid(718800)
addappid(750060)
addappid(782110)
addappid(836820)
addappid(931640)
addappid(947000)
addappid(984180)
addappid(1044440)
addappid(1086760)
addappid(1167870)
addappid(1203510)
addappid(1450220)
addappid(1849550)
