-- Lua provided by RyzenAPI
-- Game: FIVE NIGHTS AT FREDDY'S: HELP WANTED

-- MAIN APPLICATION
addappid(732690)
-- Game: addappid(732690)

-- MAIN APP DEPOTS / PACKAGES
addappid(732691, 1, "b4972b9211a9122fe96abb6bb708a3599068d83d579fa1daf5a8ead8a6a530fb")
addappid(1126200, 0, "3d97e77b4de77cfa51b9b69d1dc971fe0b5c636529b440c12b1c2c5adbf3bb57")
