-- Lua provided by SkyAPI 
-- Game: Wrong Bullet
addappid(3064750)
addappid(3064751, 1, "c0b1236b1bf2aaf53d6eb01671392fc5e8c9a55e64cbc12c67192e25f085f643")
