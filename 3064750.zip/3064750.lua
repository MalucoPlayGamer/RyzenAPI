-- Lua provided by RyzenAPI
-- Game: Wrong Bullet

-- MAIN APPLICATION
addappid(3064750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064751, 1, "c0b1236b1bf2aaf53d6eb01671392fc5e8c9a55e64cbc12c67192e25f085f643")

