-- Lua provided by RyzenAPI
-- Game: Game: Midnight Horde Demo

-- MAIN APPLICATION
addappid(3360800)
-- Game: addappid(3360800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3360801, 1, "2aff8a8d306742e380ba42e4f839693701c4e084741865c3932ab6ccdb288712")
