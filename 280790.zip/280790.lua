-- Lua provided by RyzenAPI
-- Game: Creativerse

-- MAIN APPLICATION
addappid(228983)
addappid(228985)
addappid(228989)
addappid(228990)
addappid(229004)
addappid(280790)

-- MAIN APP DEPOTS / PACKAGES
addappid(280792,0,"08500c0712ea40650b8842899707459fe7485542f71d8b52a40a73bb832d59c5")
addappid(280793,0,"9cdfb0a261b5c9049c62c4bcb6ad8eea4c960bedb5fdad8bdf190f1e424c7c79")
addappid(280794,0,"3fe116467fdab5632a23ce297105d9599d8fe26991969ffe4e92bb92a9fa5884")
addappid(280795,0,"d33e754f1b4c9429e3b5fa6cb7fdc98a4b68ee95c5fe775e5e13b19fcb5e6640")

