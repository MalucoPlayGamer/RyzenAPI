-- Lua provided by RyzenAPI
-- Game: AppID 574640

-- MAIN APPLICATION
addappid(574640)

-- MAIN APP DEPOTS / PACKAGES
addappid(574641, 1, "09daf95f01cb53186dab8bc91e8ad52e955b0097fea97ff65fa732e3f16a0d84")
