-- Lua provided by RyzenAPI
-- Game: AppID 1723560

-- MAIN APPLICATION
addappid(1723560)
addappid(2208640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723561, 1, "89a07eaee80b943b98af1bc7f986fb9a2c824f9d2367a9adbd09cced4b219b19")

