-- Lua provided by RyzenAPI
-- Game: addappid(1104870)

-- MAIN APPLICATION
addappid(1104870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104871, 1, "2ccd9657b1c5eee53799dbb2f607ed1a1a01ef7b4ac2996497ad6368f6dea2f0")
