-- Lua provided by RyzenAPI
-- Game: Goblin Gangbang 🧟🍆👩

-- MAIN APPLICATION
addappid(2576040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2576041, 1, "04bdcf0f1ab5e0bbf2cd3380052f2917797f0f91da6782a6f497340e97f3b8cc")

