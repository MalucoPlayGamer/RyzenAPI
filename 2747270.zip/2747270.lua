-- Lua provided by RyzenAPI
-- Game: AppID 2747270

-- MAIN APPLICATION
addappid(2747270)
-- Game: addappid(2747270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747271, 1, "71c7cd8b2b1fb9e1797c9bf850f864b43ede9ef6d8cae57921214728fe75de3b")
