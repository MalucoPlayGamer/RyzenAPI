-- Lua provided by RyzenAPI
-- Game: Wander Hero

-- MAIN APPLICATION
addappid(1741400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741401, 1, "f530e8ce3c3764854c48bf1734d754b3d3b522adabf8b9f2711932f474a9b3e6")

