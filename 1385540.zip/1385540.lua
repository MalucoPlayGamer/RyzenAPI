-- Lua provided by RyzenAPI
-- Game: Game: AppID 1385540

-- MAIN APPLICATION
addappid(1385540)
-- Game: addappid(1385540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385541, 1, "ce243b2239d0998a36a6ff884ae09e0d694c993f2907d56190c6484b1d46f691")
