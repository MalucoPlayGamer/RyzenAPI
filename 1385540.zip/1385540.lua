-- Lua provided by RyzenAPI
-- Game: AppID 1385540

-- MAIN APPLICATION
addappid(1385540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1385541, 1, "ce243b2239d0998a36a6ff884ae09e0d694c993f2907d56190c6484b1d46f691")

