-- Lua provided by RyzenAPI
-- Game: 欢乐消消乐

-- MAIN APPLICATION
addappid(1296720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296721, 1, "200798a161bbbbd908ad8c1e9c99e0c0c9a38fc4310bafcad52da9c6c4ca1989")
