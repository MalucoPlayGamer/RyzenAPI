-- Lua provided by SkyAPI 
-- Game: DYSCHRONIA: Chronos Alternate - Dual Edition Demo
addappid(2463580)
addappid(2463581, 1, "1fd7f661efa43335fc637c6025cb9baa91203563a2482ad72f37f70c1a06c8e0")
