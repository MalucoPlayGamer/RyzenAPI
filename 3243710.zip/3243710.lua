-- Lua provided by RyzenAPI
-- Game: KOTARO Survivor

-- MAIN APPLICATION
addappid(3243710)
-- Game: addappid(3243710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243711, 1, "27919ce792149e2edaf162a76317ac888b91bb746e554b4706acf7a006dc8b94")
