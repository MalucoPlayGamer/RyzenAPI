-- Lua provided by SkyAPI 
-- Game: KOTARO Survivor
addappid(3243710)
addappid(3243711, 1, "27919ce792149e2edaf162a76317ac888b91bb746e554b4706acf7a006dc8b94")
