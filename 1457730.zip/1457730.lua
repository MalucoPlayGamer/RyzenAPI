-- Lua provided by RyzenAPI
-- Game: addappid(1457730)

-- MAIN APPLICATION
addappid(1457730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1457731, 1, "bcfbc6a2362b351b97c6e36d16fbca0f7ac300a76b1654d0542c10259121fc58")
