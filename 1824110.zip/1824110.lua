-- Lua provided by RyzenAPI 
-- Game: HOSTLIGHT
addappid(1824110)
addappid(1824111, 1, "95d1f924852c225097f88855985a8a96ca820de9db10a8353a872b5f9683aa96")
