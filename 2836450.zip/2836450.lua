-- Lua provided by RyzenAPI
-- Game: Casino Simulator 2024

-- MAIN APPLICATION
addappid(2836450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2836451, 1, "cb049175a1a9522047c9a3480a75517e34dd03973560261d964c96f9ee0bba94")

