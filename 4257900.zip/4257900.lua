-- Lua provided by RyzenAPI
-- Game: 棋桜

-- MAIN APPLICATION
addappid(4257900)
