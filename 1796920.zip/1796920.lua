-- Lua provided by RyzenAPI
-- Game: Game: Sword of Elpisia

-- MAIN APPLICATION
addappid(1796920)
addappid(1797120)
addappid(1797121)
addappid(1797122)
-- Game: addappid(1796920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796921, 1, "0e88e8a5f3d1aeaa200c53a35fcedd59a47c39e86af94137dc9f800845457bec")
