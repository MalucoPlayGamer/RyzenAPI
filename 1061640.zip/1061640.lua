-- Lua provided by RyzenAPI
-- Game: How To Be A Real Dude

-- MAIN APPLICATION
addappid(1061640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061641, 1, "6363f0e8a2f1e8c93f2060794f2118699b9b129f02a3d3d92b8653b220dee791")
