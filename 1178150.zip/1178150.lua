-- Lua provided by RyzenAPI
-- Game: AppID 1178150

-- MAIN APPLICATION
addappid(1178150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1178151, 1, "575f3b2e93514d58d224170b3a1bdd9ac08ff31e34888d6ec9fa14decdf38a7d")
