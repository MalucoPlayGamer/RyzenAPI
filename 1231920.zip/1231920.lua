-- Lua provided by RyzenAPI
-- Game: Convoy Mod Tools

-- MAIN APPLICATION
addappid(1231920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231921, 1, "776be94043d38e3844b5e900c54f0247c37399a95e20a25f9744a79bd17bdc49")
