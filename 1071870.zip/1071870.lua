-- Lua provided by RyzenAPI
-- Game: addappid(1071870)

-- MAIN APPLICATION
addappid(1071870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071871, 1, "d6f3b571a1143307c6948afc03f2d3da402871af1602410cf9e270d993eeb303")
