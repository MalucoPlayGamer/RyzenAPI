-- Lua provided by RyzenAPI
-- Game: Retro Game Crunch Soundtrack

-- MAIN APPLICATION
addappid(374260)

-- MAIN APP DEPOTS / PACKAGES
addappid(374260,0,"3bbd3bdfeaf2c6e9e6ba3e2e4f3d5483ea6dfb027f6b8a0d0477a9c6c2ba1109")
