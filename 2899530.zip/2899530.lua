-- Lua provided by RyzenAPI 
-- Game: AppID 2899530
addappid(2899530)
addappid(2899531, 1, "7334e1b1179afc9228db59ee1611ecc3f2662a11b0c0e3c33a925725cafaa654")
