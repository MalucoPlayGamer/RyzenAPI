-- Lua provided by RyzenAPI
-- Game: Comrade-in-Arms

-- MAIN APPLICATION
addappid(1245900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245901, 1, "6a2fdd06aa9477b97516a3ce4a3a7227c1e70a557e079f80adb4ad304ee1af10")
