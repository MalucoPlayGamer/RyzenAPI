-- Lua provided by RyzenAPI
-- Game: addappid(743640)

-- MAIN APPLICATION
addappid(743640)

-- MAIN APP DEPOTS / PACKAGES
addappid(743641, 1, "7c676f40b7b23b8d28a46463d45503dafc60031db68af1e85af39ad8747b6888")
