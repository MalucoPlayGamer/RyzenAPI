-- Lua provided by RyzenAPI
-- Game: 猫头鹰和灯塔

-- MAIN APPLICATION
addappid(1591500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591501, 1, "5913d9f18b3f9eb7347671e58cc6d79028d911c79a2cfc100d73da5bebe34f55")
