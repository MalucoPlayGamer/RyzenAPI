-- Lua provided by RyzenAPI
-- Game: 3629040

-- MAIN APPLICATION
addappid(3629040)
-- Game: addappid(3629040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629041, 1, "4fc209b77fc488a3f57057fad3d96b796efdeff1ac0052517a51137c1349f3f6")
