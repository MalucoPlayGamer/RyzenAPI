-- Lua provided by RyzenAPI
-- Game: 3060280

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(3060280)
-- Game: addappid(3060280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3060282,0,"321ee9f3d49960571c1de2981d3df65c6d86d73a4c10367a0052f4938d7e39ab")
