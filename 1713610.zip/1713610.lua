-- Lua provided by SkyAPI 
-- Game: Purrgatory
addappid(1713610)
addappid(1713611, 1, "bbef8b93a41eca02c0408ccfabefff509a4a2b8a10bda93e9c235d6e18005293")
