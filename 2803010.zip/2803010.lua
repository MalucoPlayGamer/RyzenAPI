-- Lua provided by SkyAPI 
-- Game: 100 Robo Cats
addappid(2803010)
addappid(2803011, 1, "db958f8b3480c49fb3b342fda283db1cb63f1d29d1d5d3ff13413d98d8794afc")
