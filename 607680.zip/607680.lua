-- Lua provided by RyzenAPI
-- Game: AppID 607680

-- MAIN APPLICATION
addappid(607680)
-- Game: addappid(607680)

-- MAIN APP DEPOTS / PACKAGES
addappid(607681, 1, "343e51dd73a45e6b464d0a58039ed3b6d8929276ccc6fb0341ab0ab09ec0e27e")
