-- Lua provided by SkyAPI 
-- Game: AppID 840930
addappid(840930)
addappid(840931, 1, "89a21033a3a4c3ab52277f1a636d645a4274c5f589f172e625169c1cc06f6075")
