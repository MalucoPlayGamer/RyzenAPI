-- Lua provided by RyzenAPI
-- Game: Game: AppID 2060400

-- MAIN APPLICATION
addappid(2060400)
-- Game: addappid(2060400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060401, 1, "2157f6e662be4739ec6e7b95d1e6d26ded9c0ae6f7e12fee6c1dba3e3f71ae6c")
addappid(2060403, 1, "83165a8e38a2245dc85366e7846e4fb16c54c918802e4b248b1f5f1bbcd9f518")
addappid(2060404, 1, "95743b8b9ec8ca79d5500da706370ac6d39a6a4570b5367f635486efbfec0a13")
