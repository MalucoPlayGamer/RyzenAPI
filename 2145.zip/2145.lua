-- Lua provided by RyzenAPI
-- Game: addappid(2145)

-- MAIN APPLICATION
addappid(2145)

-- MAIN APP DEPOTS / PACKAGES
addappid(2132,0,"feaa43e6fb2ffb462eb7992381cbaa8436cfbb22eefc321ed55d8f1eb83f2c8e")
addappid(2133,0,"90709d9ae1e3b6d32da9bbcfd4c7e893ce32a7dcb57a3419d9428817924685a7")
addappid(2134,0,"1f2c065f543cd43489619670329e815def0d791f444bd758a4ddef58fdd082d0")
addappid(2135,0,"1c8ad478d3eec6ba7564e202b0d7a7ba84168656c43523b9126efd4b85830c9d")
addappid(2144,0,"15de3240c3273fb3c11c6bc45446be5e2336b8f7dbd843eca2c64eb7bb062d9f")
