-- Lua provided by RyzenAPI
-- Game: Game: Flight Of Nova

-- MAIN APPLICATION
addappid(1069190)
-- Game: addappid(1069190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069191, 1, "6fd9fdecb27dcede2dccccd28f303f2e2f23e91045af6f2385ae629e86ec3472")
addappid(1069194, 1, "e2f17d5fab2c5a1c1a265c272aa8e3ec94427f69883cdcaef29da4fdd58f3020")
