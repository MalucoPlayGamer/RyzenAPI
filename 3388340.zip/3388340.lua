-- Lua provided by RyzenAPI
-- Game: addappid(3388340)

-- MAIN APPLICATION
addappid(3388340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388341, 1, "98c88b947c35686e9b71567e0f251a8bce888d9e5041c00795dcd474c90c4e1d")
