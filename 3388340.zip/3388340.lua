-- Lua provided by RyzenAPI
-- Game: Laundromat Manager Simulator

-- MAIN APPLICATION
addappid(3388340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3388341, 1, "98c88b947c35686e9b71567e0f251a8bce888d9e5041c00795dcd474c90c4e1d")

