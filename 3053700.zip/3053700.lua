-- Lua provided by RyzenAPI
-- Game: Smash Girls Artbook

-- MAIN APPLICATION
addappid(3053700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3053701, 1, "bb6853f10f2447d40bf70b305bae13e275b73c58ee0a4f7d23006eb520860224")

