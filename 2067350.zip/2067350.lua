-- Lua provided by RyzenAPI
-- Game: Phantom Breaker: Battle Grounds Ultimate

-- MAIN APPLICATION
addappid(2067350)
addappid(3852960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2067351, 1, "1a8b74534d1d5ec46124cacb6c94dc54a7cf24c361e401d2bef7ccebb70012a8")

