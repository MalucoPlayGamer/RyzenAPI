-- Lua provided by RyzenAPI
-- Game: Phantom Breaker: Battle Grounds Ultimate

-- MAIN APPLICATION
addappid(2067350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067351, 1, "1a8b74534d1d5ec46124cacb6c94dc54a7cf24c361e401d2bef7ccebb70012a8")

