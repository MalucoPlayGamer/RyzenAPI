-- Lua provided by RyzenAPI
-- Game: BULLET YEETERS Playtest

-- MAIN APPLICATION
addappid(3645690)
-- Game: addappid(3645690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645691, 1, "adaecaf702b0415d9b4b4f62ad6d745ff83b48fba2ef70af7770f3d91922728b")
