-- Lua provided by RyzenAPI
-- Game: 14 Minesweeper Variants Demo

-- MAIN APPLICATION
addappid(2021450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2021451, 1, "8789d955e5ab16e0d9e01064f2cd6fa11408b74364661bb78ea6a985c71d0ddc")
