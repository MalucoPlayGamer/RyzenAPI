-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Modern Item Icons

-- MAIN APPLICATION
addappid(3106130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3106130,0,"9cd415591db7db64da7559abc913a06ca7ffd73d89228557e285c7b8a6b443ca")

