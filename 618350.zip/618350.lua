-- Lua provided by RyzenAPI
-- Game: Game: AppID 618350

-- MAIN APPLICATION
addappid(618350)
-- Game: addappid(618350)

-- MAIN APP DEPOTS / PACKAGES
addappid(618351, 1, "46262ea34b59120cd3204c5019d2cb817663010a0aedafb1f2b206d00c34081f")
