-- Lua provided by RyzenAPI
-- Game: Game: AppID 555430

-- MAIN APPLICATION
addappid(555430)
addappid(564870)
addappid(565400)
addappid(566300)
-- Game: addappid(555430)

-- MAIN APP DEPOTS / PACKAGES
addappid(555431, 1, "6f7283d3c6e207cfeb83226e676feea1454d149f74210364492740cde19c8e56")
addappid(555432, 1, "9a4692d0439dc5ca064b2dea7257d3ed432e614c6ef5a2ed14e73fd73ef7ffcf")
