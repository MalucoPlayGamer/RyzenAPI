-- Lua provided by RyzenAPI
-- Game: TRON 2.0

-- MAIN APPLICATION
addappid(327740)

-- MAIN APP DEPOTS / PACKAGES
addappid(327741, 1, "652cbe0bb7ca56ad92d236a86058e440a24cfdb31a067b398edefa573065c359")
addappid(327742, 1, "8aa226a65d654ca452249e959918e06d2678f0ba738dddbf90e074c31ff10a33")
addappid(327743, 1, "39c56ae3877234a74140568f2813ed38ff3bebd38a17b9fb7bd9dc1171a2a299")
addappid(327744, 1, "acba441f160872b469045478d515708e73af873c109611d967ddd765108ba311")
addappid(327745, 1, "45cc4c01bf2080f3c4ee4af22e5b5f9b8e2953c8aaf7dbd3c90dec6e390516ab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
