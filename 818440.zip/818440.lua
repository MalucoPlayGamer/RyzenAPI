-- Lua provided by RyzenAPI 
-- Game: Forgotten Places: Lost Circus
addappid(818440)
addappid(818441, 1, "e8f3ef2dd5226afbd977950bd0682ab812cd3a3074d12438588470406a3a214c")
addappid(818442, 1, "d1667ab45678f65748e44922693a6e5c44c60b219307dfe2d9629834c492a160")
