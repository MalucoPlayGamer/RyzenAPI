-- Lua provided by RyzenAPI
-- Game: addappid(3028300)

-- MAIN APPLICATION
addappid(3028300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028301, 1, "1284590e57c5c5155c0a00f9e7d85ec1089a371c32b0de6fcf9ee081d0ec21ff")
