-- Lua provided by RyzenAPI
-- Game: Hero Barrier

-- MAIN APPLICATION
addappid(580560)

-- MAIN APP DEPOTS / PACKAGES
addappid(580561, 1, "35229dddf97391e142a65708a02ba1eafad3e7d8952ff7c1207a1cf9a248605c")
