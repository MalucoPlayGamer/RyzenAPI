-- Lua provided by RyzenAPI
-- Game: Challenge of the Five Realms

-- MAIN APPLICATION
addappid(347240)

-- MAIN APP DEPOTS / PACKAGES
addappid(347241, 1, "5b4c74fbee0b232a553ab15381837b49f4932c9a191806fcb7d843d7b666deb3")
addappid(347242, 1, "2b3d394cb215e642ac5bb5d85b8afaea5fb290ef20cabeeb83faaf6c1e59cd68")
addappid(347244, 1, "1018433f51e294ff9276f6849d3e2b939960b04493ea6e0a63558f5e3c066f7a")
