-- Lua provided by RyzenAPI
-- Game: Maze Art: Rainbow

-- MAIN APPLICATION
addappid(1818820)
-- Game: addappid(1818820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818821, 1, "bf2488cfbcae30b621f27fd3e1e5f6e5cf41bda2360cba5071ac6cd71a319dcd")
