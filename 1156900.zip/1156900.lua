-- Lua provided by SkyAPI 
-- Game: AppID 1156900
addappid(1156900)
addappid(1156901, 1, "f53a48902784df025d201dc0c0b1710e9c7ccd730e41b66b1a86bf5d856826b9")
