-- Lua provided by RyzenAPI
-- Game: Output Pasture

-- MAIN APPLICATION
addappid(1156900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1156901, 1, "f53a48902784df025d201dc0c0b1710e9c7ccd730e41b66b1a86bf5d856826b9")

