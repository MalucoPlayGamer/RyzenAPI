-- Lua provided by RyzenAPI
-- Game: Game: AppID 1156900

-- MAIN APPLICATION
addappid(1156900)
-- Game: addappid(1156900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156901, 1, "f53a48902784df025d201dc0c0b1710e9c7ccd730e41b66b1a86bf5d856826b9")
