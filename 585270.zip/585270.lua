-- Lua provided by RyzenAPI
-- Game: 585270

-- MAIN APPLICATION
addappid(585270)
-- Game: addappid(585270)

-- MAIN APP DEPOTS / PACKAGES
addappid(585273,0,"f7239293cbf6ebe3faf22336a38eef7197970ef5b991290e8ab886eaf36c84b8")
