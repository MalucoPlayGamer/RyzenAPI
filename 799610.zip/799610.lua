-- Lua provided by RyzenAPI
-- Game: 799610

-- MAIN APPLICATION
addappid(799610)
-- Game: addappid(799610)

-- MAIN APP DEPOTS / PACKAGES
addappid(799611, 1, "66342bd0bd0a17f836da6783e9d01a5a09f2b087e65c54236125297671d5a1a3")
