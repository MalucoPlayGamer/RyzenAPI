-- Lua provided by RyzenAPI
-- Game: Drill Arena

-- MAIN APPLICATION
addappid(799610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(799611, 1, "66342bd0bd0a17f836da6783e9d01a5a09f2b087e65c54236125297671d5a1a3")

