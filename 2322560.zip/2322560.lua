-- Lua provided by RyzenAPI
-- Game: 2322560

-- MAIN APPLICATION
addappid(2322560)
-- Game: addappid(2322560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322561, 1, "f8ae938c87b21add3212afdb3a3ff3ce10006f418b44f8ba151efab5fa3645ba")
addappid(2322562, 1, "4c7fe6457c86ff503ae1c48175bdf14b66e7aeace01051dd0c2ebe8c193eb826")
addappid(2322563, 1, "43e70d7f01def87e3f7da43d52cfab4355d2df1140aaf190894a9b834f97b5dd")
addappid(2322564, 1, "ffba65bebbbe85488c3fc3327d568c07b9fd02bdd5c4a8a988e2b6056561b9b8")
addappid(2322565, 1, "4e3c98a38e395106c2ae7b7158a0d71d196f67fb233f6ad104c76d6e93c6f9b9")
addappid(2322566, 1, "143539fbc7eb0af9ab5d61ab19123942fefcfef35d51e3a3d221db46ffdc39aa")
addappid(2322567, 1, "7d0e7a2f4fe4b913552a2e98b1ef0e0b59d0f6704c6aa17f6338b32f998410f4")
