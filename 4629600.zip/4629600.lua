-- Lua provided by RyzenAPI
-- Game: POTENTIAL MAN

-- MAIN APPLICATION
addappid(4629600)

-- MAIN APP DEPOTS / PACKAGES
addappid(4629601, 1, "09b3bb5753fc78787d024c4b007e46476b5b76676baf719caa53353ac22c88cd")
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
