-- Lua provided by RyzenAPI
-- Game: Puppetmaster - Pose Viewer

-- MAIN APPLICATION
addappid(2251040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2251041, 1, "c5817872d573d11bf85a7b995a43a77035519c5d20303a843880b2d9f71ebe77")

