-- Lua provided by SkyAPI 
-- Game: Puppetmaster - Pose Viewer
addappid(2251040)
addappid(2251041, 1, "c5817872d573d11bf85a7b995a43a77035519c5d20303a843880b2d9f71ebe77")
