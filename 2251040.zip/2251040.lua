-- Lua provided by RyzenAPI
-- Game: Puppetmaster - Pose Viewer

-- MAIN APPLICATION
addappid(2251040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251041, 1, "c5817872d573d11bf85a7b995a43a77035519c5d20303a843880b2d9f71ebe77")

