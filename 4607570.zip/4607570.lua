-- Lua provided by RyzenAPI
-- Game: Eternal Spring: Oblivion

-- MAIN APPLICATION
addappid(4607570) -- Eternal Spring: Oblivion

-- MAIN APP DEPOTS / PACKAGES
addappid(4607571, 1, "90a5c3cc656e884c88f18acc962f955b544e1b5d345e037a62e6c1d9a6bff5c0") -- Depot 4607571

