-- 4607570's Lua and Manifest Created by Hubcap Manifest
-- Eternal Spring: Oblivion
-- Created: August 01, 2026 at 09:12:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4607570) -- Eternal Spring: Oblivion
-- MAIN APP DEPOTS
addappid(4607571, 1, "90a5c3cc656e884c88f18acc962f955b544e1b5d345e037a62e6c1d9a6bff5c0") -- Depot 4607571
setManifestid(4607571, "4505261252494612222", 15283387564)