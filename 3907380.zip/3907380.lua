-- Lua provided by RyzenAPI
-- Game: The Prince of Tennis Doki Doki Survival ~eternal passion! Tie break ♡ game~

-- MAIN APPLICATION
addappid(3907380)
addappid(4190540)
addappid(4214990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3907381,0,"95a7a5431c48be0a0f301e0c1d8c629ac0cc1eb04e8d87256d24a231ec875411")

