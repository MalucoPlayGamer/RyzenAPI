-- Lua provided by RyzenAPI
-- Game: Unicycle Together

-- MAIN APPLICATION
addappid(4286040)
addappid(4946210)

-- MAIN APP DEPOTS / PACKAGES
addappid(4286041,0,"b4a3961140cd6c8ec8fb7adca349c30ffd7c2bb970e2f8a556668bc786b3be59")

