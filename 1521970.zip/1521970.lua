-- Lua provided by RyzenAPI
-- Game: Goblin Stone

-- MAIN APPLICATION
addappid(1521970)
-- Game: addappid(1521970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521971, 1, "90fe110db57320188816b901f99f089da088b50b8d3f53e56cc2658118b8bf9d")
addappid(1521972, 1, "92a56bc47de40e387425ee7c24bd9fb27d09ac93c81ce38c7059fed7c94f6446")
