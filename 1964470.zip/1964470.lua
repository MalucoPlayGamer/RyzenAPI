-- Lua provided by RyzenAPI
-- Game: Game: My Stepmom is a Futanari Chemist

-- MAIN APPLICATION
addappid(1964470)
-- Game: addappid(1964470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964471, 1, "48e28015a7c9352fd133e99363558545601442df838f3990f596063f33939f1b")
