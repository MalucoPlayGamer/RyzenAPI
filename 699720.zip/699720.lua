-- Lua provided by SkyAPI 
-- Game: Timension
addappid(699720)
addappid(699721, 1, "594ae050b0e8d6a334a34a9684f9d3baf22e4106ce7607cabe121a3ee8f17056")
