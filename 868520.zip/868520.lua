-- Lua provided by SkyAPI 
-- Game: killer7
addappid(868520)
addappid(868521, 1, "94a7416d8d9b1d2995633d78d009751f54ba7c1b111d4d483a82badc0fd22a0a")
