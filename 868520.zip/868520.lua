-- Lua provided by RyzenAPI
-- Game: killer7

-- MAIN APPLICATION
addappid(868520)
addappid(909850)
addappid(909851)

-- MAIN APP DEPOTS / PACKAGES
addappid(868521,0,"94a7416d8d9b1d2995633d78d009751f54ba7c1b111d4d483a82badc0fd22a0a")
addappid(909850,0,"144d6b5ea550cd93df107ba4d35fc59dddc78a48ab0d2f8c27a7bbdd10a144c8")
addappid(909851,0,"52fe131b929f773098fa3f516295d60808224b97eb435b16d96df71729902f38")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
