-- Lua provided by RyzenAPI
-- Game: GIGANTIC ARMY

-- MAIN APPLICATION
addappid(278930)

-- MAIN APP DEPOTS / PACKAGES
addappid(278931, 1, "b8a44e11f73a389ee9726748167a01784fca062de430b7b2ee5e822ad6ddbc75")
addappid(278933, 1, "0eb6c8689f0a851a78bfc891617f6f1d50bff6ca519876642155ace02518115e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
