-- Lua provided by RyzenAPI
-- Game: Fey

-- MAIN APPLICATION
addappid(3441160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3441161, 1, "56fdcac536f3023bc9b365ee6908978ef63162dab9fd5c0735ea7c4124a82288")
