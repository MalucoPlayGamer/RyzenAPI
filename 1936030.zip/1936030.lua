-- Lua provided by RyzenAPI
-- Game: AppID 1936030

-- MAIN APPLICATION
addappid(1936030)
-- Game: addappid(1936030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1936031, 1, "9109349b71b7a131a31d54881adda9f11f0eddc4ccf277ad1c1b0c32f162f469")
