-- Lua provided by RyzenAPI
-- Game: Game: Helicopter Simulator 2020 Demo

-- MAIN APPLICATION
addappid(1542240)
-- Game: addappid(1542240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542241, 1, "7dd786f41fee8dd5aeee9b83e3be30bdeb4f095150d334841773fc661e8c99f3")
