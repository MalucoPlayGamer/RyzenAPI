-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1295719)
addappid(1295719,0,"c987f38ba2dc87afe4ae1c7d074f00668585d9544d85933481a0128031a36bec")
-- setManifestid(1295719,"8583645749393344846")
addappid(1296090,0,"77b0f17b632c69a9af4d0ae8f318dcf6776a38d88d1496b94cb8068f6890b52b")
-- setManifestid(1296090,"7171506742989078775")
addappid(1296091,0,"cec1a37f85b2c20759238d5f85bb7891d4c40e0b5fa7536ef2a4127f769221bd")
-- setManifestid(1296091,"6251109760566879892")
addappid(1296092,0,"e9b5aec7f3fc09fb91a148d7e65cc6de8f627daac447f4fc8e209e46fc38f84e")
-- setManifestid(1296092,"3660426443437729123")
addappid(1296093,0,"6a238637b298abc4936609de62de385472977a76c1bc353c09f4f50027d6180d")
-- setManifestid(1296093,"6682100053197675644")
addappid(1296094,0,"1ecd2e6292e3e6e7aa86000fce7c8b8ada4cd626e1c84b3d00096ae2cadae812")
-- setManifestid(1296094,"1684520506538004359")
addappid(1296095,0,"b8d74291e2c806fd31346ae186fa3da78d2ec0c223dc1d1d661ce9bcfc0639df")
-- setManifestid(1296095,"842474879727568755")
addappid(1296096,0,"e339e313ce51d151c8250cb51c1960cd01232626d8b6b54a511125d1529a2387")
-- setManifestid(1296096,"8410267466154471585")