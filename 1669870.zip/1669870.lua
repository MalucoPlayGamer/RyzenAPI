-- Lua provided by RyzenAPI
-- Game: Game: 大亨传奇

-- MAIN APPLICATION
addappid(1669870)
-- Game: addappid(1669870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669871, 1, "41484bafe9b53150279a5047bc2590208ecd1619c391eb00722deeff88fe94d8")
