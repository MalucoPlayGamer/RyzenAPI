-- Lua provided by RyzenAPI
-- Game: 2410300

-- MAIN APPLICATION
addappid(2410300)
-- Game: addappid(2410300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2410300,0,"9646b84719fba9dd577fd6a25e14077775cf2ac97ec3355ba3e2d9cc309313b9")
