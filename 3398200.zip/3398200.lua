-- Lua provided by RyzenAPI
-- Game: Pacifish: Recast

-- MAIN APPLICATION
addappid(3398200) -- Pacifish: Recast

-- MAIN APP DEPOTS / PACKAGES
addappid(3398201, 1, "4924d06cf7eaa2175a080083af6906709c37350bf0df72529144de888566ec52") -- Depot 3398201

