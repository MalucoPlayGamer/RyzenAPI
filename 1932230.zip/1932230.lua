-- Lua provided by RyzenAPI 
-- Game: 100 hidden hares
addappid(1932230)
addappid(1932231, 1, "55741b43648b865f2c4a7b1461bc3aa252a03c43293a62e51713bfdb8f42f232")
