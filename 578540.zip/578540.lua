-- Lua provided by RyzenAPI
-- Game: Perfect Gold - Yuri Visual Novel

-- MAIN APPLICATION
addappid(578540)
-- Game: addappid(578540)

-- MAIN APP DEPOTS / PACKAGES
addappid(578541, 1, "3ef4f4bb480eaf0ead5d04db0eabf71b92915aa65b5ebac4f012527fe1d88eed")
addappid(578542, 1, "8d2938ab0c800f06e814a3479ff71332b87011a784fc8154d3498fb44a6db0db")
addappid(578543, 1, "bd393662c38127fd4ee3513d833e28cb52ba79eef3a596bb2a16d7606debf672")
addappid(1554350, 0, "33bfc12bf2738ac7c7fc6414745013635358c2660b5caec3efa69b30b75e4061")
