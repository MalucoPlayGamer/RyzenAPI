-- Lua provided by RyzenAPI
-- Game: AppID 1267470

-- MAIN APPLICATION
addappid(1267470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1267471, 1, "d102fe7b5f8bd3273989af2e4a744e2ef7caeacfcbb1a0a87c469d499d5fa895")

