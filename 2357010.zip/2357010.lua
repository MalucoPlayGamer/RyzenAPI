-- Lua provided by SkyAPI 
-- Game: AppID 2357010
addappid(2357010)
addappid(2357011, 1, "0e319fbbd540bd1426be9bc78d39c49f0495c742a646872d6f727eba8b110e10")
