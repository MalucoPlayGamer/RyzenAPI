-- Lua provided by RyzenAPI
-- Game: Game: AppID 2357010

-- MAIN APPLICATION
addappid(2357010)
-- Game: addappid(2357010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357011, 1, "0e319fbbd540bd1426be9bc78d39c49f0495c742a646872d6f727eba8b110e10")
