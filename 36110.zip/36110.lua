-- Lua provided by RyzenAPI
-- Game: 36110

-- MAIN APPLICATION
addappid(36110)
-- Game: addappid(36110)

-- MAIN APP DEPOTS / PACKAGES
addappid(36111, 1, "f617fc880055badbeb97372eb1495ce09e2bcd333dbd4a85b00b6fda2672c71c")
