-- Lua provided by RyzenAPI
-- Game: 1406690

-- MAIN APPLICATION
addappid(1406690)
-- Game: addappid(1406690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406691, 1, "56d4169c5ab3a0851bbb555745041b8c1a0fdd39a348ea976d31f6aeb7e594b9")
