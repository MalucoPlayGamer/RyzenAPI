-- Lua provided by RyzenAPI
-- Game: Kasi

-- MAIN APPLICATION
addappid(1406690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1406691, 1, "56d4169c5ab3a0851bbb555745041b8c1a0fdd39a348ea976d31f6aeb7e594b9")

