-- Lua provided by RyzenAPI
-- Game: Game: AppID 1302090

-- MAIN APPLICATION
addappid(1302090)
-- Game: addappid(1302090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1302091, 1, "a67b5af8757bc9c3da9096e759d18ff46603631bd5d8bcc5284d0029f478b41d")
