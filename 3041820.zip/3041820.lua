-- Lua provided by RyzenAPI 
-- Game: Lilia: The Fallen Flower in the Prison City
addappid(3041820)
addappid(3041821, 1, "1774cc267afce6d89ab3042f335b82d785dd05ae90df2c1b314559ea3e4bb934")
addappid(3041822, 1, "1a68ff98a7817e24bd5c2c2633076e2a46aac753e47351dd4cf61bcfbea07277")
addappid(3661540, 0, "5ecdf521dcceb1c8e7c2e72a634dabcdfd8a1bd331fd72e4203ddb098abb5610")
